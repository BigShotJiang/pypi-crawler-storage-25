"""inference — Multi-backend LLM dispatch.

Supports: mlx (text), mlx-vlm (vision), ollama (HTTP fallback).

Usage:
    from metal_guard.inference import call_model

    text = call_model("Analyze this", model="mlx-community/Phi-4-mini-instruct-4bit", backend="mlx")
    text = call_model("Describe", model="phi4", backend="ollama")
"""

from __future__ import annotations

import base64
import functools
import gc
import os
import re
import threading
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator, Tuple

from metal_guard._constants import log
from metal_guard.memory import MetalOOMError
from metal_guard import metal_guard
from metal_guard.model_cache import get_mlx_model, get_mlx_vlm_model, unload_all
from metal_guard.prefill import (
    describe_prefill_plan,
    lookup_dims,
    require_prefill_fit,
)

# Pre-load load_gate refusal. Set to "1" to skip
# ``load_gate.gate_or_raise`` (emergency rollback). When unset (default),
# ``_call_mlx`` / ``_call_mlx_vlm`` invoke ``load_gate.gate_or_raise(model)``
# BEFORE ``get_mlx_model`` / ``get_mlx_vlm_model`` which actually loads the
# model into Metal memory.
_LOAD_GATE_DISABLED_ENV = "MLX_LOAD_GATE_DISABLED"


def _check_load_gate(model: str) -> None:
    """Refuse model load pre-spawn via ``load_gate.gate_or_raise(model)``.

    Wire site rationale: MUST run OUTSIDE the ``@retry`` decorator
    boundary on ``_call_mlx`` / ``_call_mlx_vlm`` because ``MLXLoadGateError``
    inherits from ``RuntimeError`` and the retry decorator's ``on=(RuntimeError,
    OSError, TimeoutError)`` would otherwise catch + retry the deliberate
    refusal — silently bypassing the gate and returning "" on retry exhaust.
    Caller (``call_model`` dispatch) invokes this BEFORE selecting the
    ``@retry``'d ``_call_mlx*`` path so the refusal propagates as documented.

    Defensive ImportError fall-through: if ``load_gate`` module is absent
    (deploy partial / minimal install), log debug and proceed — gate is
    advisory; metal_guard ``require_fit`` carries downstream risk.

    Skip via env ``MLX_LOAD_GATE_DISABLED=1`` for emergency rollback.
    """
    if os.environ.get(_LOAD_GATE_DISABLED_ENV) == "1":
        return
    try:
        from metal_guard.load_gate import gate_or_raise as _gate_or_raise
    except ImportError as exc:
        log.debug(
            "inference._check_load_gate: load_gate import failed; "
            "skipping pre-load refusal gate for %s (%s)", model, exc,
        )
        return
    _gate_or_raise(model)


# ── Constants ────────────────────────────────────────────────────────────────


def _prefill_guard_check(
    *,
    model: str,
    tokenizer: Any,
    formatted_prompt: str,
    max_tokens: int,
) -> None:
    """Pre-generate check: refuse prompts whose prefill would risk IOGPU panic.

    Auto-wires R4 (``prefill.require_prefill_fit``) into the actual
    call path. Silently skips if:

    * model is not in :data:`prefill.KNOWN_MODELS` — we can't
      estimate without dims
    * tokenizer doesn't expose a reasonable encode path — fall back to
      char-count heuristic
    * memory_stats() returns zero limit (MLX not yet loaded)

    Raises :class:`metal_guard.memory.MetalOOMError` if the prefill
    peak allocation would exceed the single-allocation ceiling (5 GB)
    or exceed available memory headroom. The caller's ``call_model()``
    path already has ``oom_protected_context`` + retry handling around
    this, so a raise propagates as a normal error return path, not an
    abort.
    """
    dims = lookup_dims(model)
    if dims is None:
        log.debug("_prefill_guard_check: unknown model dims for %s — skip", model)
        return

    # Tokenize the formatted prompt to get exact token count.
    try:
        prompt_tokens = tokenizer.encode(formatted_prompt)
        prompt_len = len(prompt_tokens)
    except Exception as exc:  # defensive: tokenizer API varies across families
        # Fall back to rough 4-chars-per-token heuristic rather than skipping.
        log.debug(
            "_prefill_guard_check: tokenizer.encode failed for %s (%s) — "
            "using char-count fallback", model, exc,
        )
        prompt_len = max(1, len(formatted_prompt) // 4)

    context_tokens = prompt_len + max_tokens

    stats = metal_guard.memory_stats()
    if stats.limit_bytes <= 0:
        log.debug(
            "_prefill_guard_check: memory_stats not yet populated — skip"
        )
        return

    available_gb = stats.available_gb

    # Does not raise on unknown dims; require_prefill_fit raises MetalOOMError
    # on ceiling breach so caller sees a normal error instead of a panic.
    require_prefill_fit(
        context_tokens=context_tokens,
        dims=dims,
        available_gb=available_gb,
    )
    metal_guard.breadcrumb(
        f"PREFILL_GUARD: OK model={model} ctx={context_tokens} "
        f"avail={available_gb:.1f}GB"
    )


_DEFAULT_NUM_CTX = 4096
_DEFAULT_TEMPERATURE = 0.3
_DEFAULT_TIMEOUT = 120
_DEFAULT_MAX_TOKENS = 4096
_MAX_PROMPT_CHARS = 32_000
_MAX_IMAGE_BYTES = 10 * 1024 * 1024
_MAX_IMAGES = 20
_MLX_GENERATE_TIMEOUT = 120  # 2 minutes max per text generate
_VLM_GENERATE_TIMEOUT = 180  # 3 minutes max per vision generate

_BASE64_RE = re.compile(r"^[A-Za-z0-9+/=]+$")
_BASE64_MIN_LEN = 100

# ── MetalGuard Layer 5: long-sequence bench guard ───────────────────────────
# Layers 1-4 (in-process RLock, cross-process lock, thread registry,
# wait_for_threads timeout) all target concurrency / stale-thread hazards.
# They do NOT protect a single-threaded, single-process harness that loads
# 4+ large MLX models sequentially within one Python lifetime — the exact
# scenario that crashed the Stage 1 Track A benchmark on 2026-04-12 at
# 06:01:29 with completeMemory() underflow @IOGPUMemory.cpp:492.
#
# L5 closes that gap via ``bench_scoped_load``: every entry forces a fresh
# ``metal_guard.require_fit`` (via _ensure_fit_before_load in model_cache),
# every exit runs unload_all() + extra cooldown + memory-drop verification.
# If the post-unload active memory does not drop below the expected
# threshold, we log a warning (without hard-failing the harness) so the
# next iteration's require_fit can still catch it.
# Empirical: Metal lazy release needs ~8s on M1 Ultra 64GB after unloading
# a 24GB model before the buffer pool pages are actually returned to the OS.
# safe_cleanup's internal 1s cooldown is insufficient; 5s (escalated) is
# borderline; 8s lets the OS reclaimer catch up in almost all cases.
# 2026-04-12 smoke test: Mistral-24B-8bit → active 25GB after 3s cooldown,
# active 2.2GB only after the *next* model loaded and unloaded.
_BENCH_POST_UNLOAD_COOLDOWN_SEC = 8.0

# Post-unload active memory above this threshold triggers a warning (but
# does NOT hard-fail; the next iteration's require_fit escalated retry will
# handle it). Metal lazy release means a warning here is expected behavior
# for 20+GB models — what matters is that require_fit catches it before
# the NEXT model load pushes past the 48GB working set.
_BENCH_POST_UNLOAD_ACTIVE_LIMIT_GB = 4.0


# ── Typed panic signal ──────────────────────────────────────────────────────


class MLXDispatchBlockedError(RuntimeError):
    """Raised when ``call_model`` refuses to start a new MLX generate because
    a prior GPU thread is still alive.

    Callers MUST propagate this (not swallow) — continuing would let the
    still-alive generate thread race the new one on Metal and trigger the
    IOGPUMemory underflow kernel panic (@IOGPUMemory.cpp:492). Wrappers that
    downgrade generic mlx-lm ``RuntimeError`` to empty-string for Ollama
    parity must catch ``MLXDispatchBlockedError`` separately and re-raise —
    swallowing it would silently permit the race condition this guard exists
    to prevent.

    Subclasses ``RuntimeError`` for back-compat: any existing ``except
    RuntimeError`` still catches it, but type-checked handlers can now
    distinguish this signal from random mlx-lm internal failures.
    """

    def __init__(self, still_alive: int, wait_budget_secs: float) -> None:
        self.still_alive = still_alive
        self.wait_budget_secs = wait_budget_secs
        super().__init__(
            f"MLX dispatch blocked: {still_alive} GPU thread(s) still alive "
            f"after {wait_budget_secs:.0f}s — refusing to start a new generate "
            f"(would trigger IOGPUMemory underflow panic)"
        )


# ── Panic-safety primitives ──────────────────────────────────────────────────
#
# Four holes identified in the 2026-04-10 Metal kernel panic
# (completeMemory() prepare count underflow @ IOGPUMemory.cpp:492):
#
#   #1 wait_for_threads(timeout=5) too short vs 120s generate timeout
#   #2 no global lock serializing concurrent MLX calls (ThreadPoolExecutor
#      callers like consensus.py could hit Metal from 3 threads at once)
#   #3 no cross-process coordination (backend daemon + task_runner subprocess
#      + CLI all init Metal independently)
#   #4 register_thread racing thread.start() — μs window where a newly-started
#      thread is not yet tracked
#
# This lock closes #2.
#
# MUST be an RLock, not Lock: @retry on _call_mlx / _call_mlx_vlm re-enters
# this lock from inside call_model's ``with _MLX_CALL_LOCK:`` block on
# transient RuntimeError/OSError/TimeoutError. A plain Lock would self-deadlock
# on the first retry. Do not "simplify" to threading.Lock().
_MLX_CALL_LOCK = threading.RLock()


class _NullContext:
    """No-op context manager used by observer mode to bypass the RLock.

    Returns from __enter__ are unused by call_model — the lock is only
    held for its side effect of serializing generate() invocations.
    """
    def __enter__(self):
        return self
    def __exit__(self, exc_type, exc, tb):
        return False


_NULL_CALL_LOCK = _NullContext()


def _mlx_call_lock():
    """Return the active call-lock context manager for the current mode.

    Defensive mode (default): returns ``_MLX_CALL_LOCK`` (threading.RLock)
    which serializes all MLX generate() calls within this process — the
    Hole #2 protection against Metal concurrent-generate kernel panic.

    Observer mode (opt-in, post-#3348): returns a null context so
    callers can run MLX generate() in parallel. Requires mlx ≥ 0.31.2
    with #3348 CommandEncoder thread-local fix released. Enabling
    observer mode on older mlx will reintroduce the kernel panic.
    """
    # Lazy import to avoid circular dependency: process_mode.py is a sibling
    # that will itself not import inference.py.
    from metal_guard.process_mode import is_observer
    if is_observer():
        return _NULL_CALL_LOCK
    return _MLX_CALL_LOCK

# Grace period added on top of _VLM_GENERATE_TIMEOUT when waiting for zombie
# GPU threads to finish. This covers the window between the join timeout
# firing and the daemon thread actually clearing its Metal buffers.
_THREAD_CLEANUP_GRACE_SECS = 10

# Advisory-only breadcrumb that logs the current pid holding MLX. Reader
# can detect "another process is using Metal" but we do not block — a hard
# cross-process mutex needs launchd-level coordination (#3, out of scope).
#
# Path is configurable via MLX_BREADCRUMB_PATH env var. Default is
# ``~/.metal-guard/logs/mlx_active_pid``.
_MLX_BREADCRUMB_ENV = os.getenv("MLX_BREADCRUMB_PATH")
_MLX_PROCESS_BREADCRUMB = (
    Path(_MLX_BREADCRUMB_ENV).expanduser()
    if _MLX_BREADCRUMB_ENV
    else Path.home() / ".metal-guard" / "logs" / "mlx_active_pid"
)


def _check_other_mlx_process() -> None:
    """Log a warning if another Python pid is currently holding the MLX slot.

    Writes current pid to the breadcrumb regardless.  Non-fatal on any error —
    this is diagnostic, not a lock.
    """
    try:
        _MLX_PROCESS_BREADCRUMB.parent.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        log.debug("cannot create breadcrumb dir: %s", exc)
        return

    try:
        raw = _MLX_PROCESS_BREADCRUMB.read_text().strip()
    except (FileNotFoundError, OSError):
        raw = ""

    if raw:
        try:
            other_pid = int(raw)
        except ValueError:
            other_pid = 0
        if other_pid and other_pid != os.getpid():
            try:
                os.kill(other_pid, 0)  # signal 0 = liveness check
            except ProcessLookupError:
                pass  # stale breadcrumb
            except PermissionError:
                # Process exists but is owned by another user — still alive.
                log.warning(
                    "Another MLX process active (pid=%d, owned by other user). "
                    "Current pid=%d. Metal may panic — consider serializing "
                    "at launchd level.",
                    other_pid, os.getpid(),
                )
            else:
                log.warning(
                    "Another MLX process active (pid=%d). Current pid=%d. "
                    "Metal may panic — consider serializing at launchd level.",
                    other_pid, os.getpid(),
                )

    # Atomic single-syscall write: O_CREAT|O_TRUNC|O_WRONLY opens and
    # truncates in one shot, os.write is a single syscall. Avoids the
    # read-modify-write race of Path.write_text across concurrent processes.
    try:
        fd = os.open(
            str(_MLX_PROCESS_BREADCRUMB),
            os.O_WRONLY | os.O_CREAT | os.O_TRUNC,
            0o644,
        )
        try:
            os.write(fd, str(os.getpid()).encode("ascii"))
        finally:
            os.close(fd)
    except OSError as exc:
        log.debug("cannot write breadcrumb: %s", exc)


# ── Retry Decorator ──────────────────────────────────────────────────────────


def retry(
    max_attempts: int = 2,
    backoff: float = 5.0,
    on: Tuple[type, ...] = (TimeoutError, ConnectionError, OSError),
):
    """Retry decorator with exponential backoff for transient failures."""
    def decorator(fn):  # type: ignore[type-arg]
        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            last_exc: BaseException = RuntimeError("unreachable")
            for attempt in range(max_attempts + 1):
                try:
                    return fn(*args, **kwargs)
                except on as exc:
                    last_exc = exc
                    if attempt < max_attempts:
                        wait = backoff * (2 ** attempt)
                        log.warning(
                            "Retry %d/%d for %s after %s: %.1fs",
                            attempt + 1, max_attempts, fn.__name__, exc, wait,
                        )
                        time.sleep(wait)
            raise last_exc
        return wrapper
    return decorator


# ── Image Helpers ────────────────────────────────────────────────────────────


def encode_image(source: str | Path) -> str:
    """Encode image to base64. Accepts path, base64 string, or data: URI."""
    source_str = str(source)

    if source_str.startswith("data:"):
        _, _, encoded = source_str.partition(",")
        return encoded

    if (
        not isinstance(source, Path)
        and len(source_str) >= _BASE64_MIN_LEN
        and _BASE64_RE.match(source_str)
    ):
        return source_str

    candidate = Path(source_str)
    if candidate.exists() and candidate.is_file():
        raw = candidate.read_bytes()
        if len(raw) > _MAX_IMAGE_BYTES:
            raise ValueError(f"Image too large: {len(raw)} bytes")
        return base64.b64encode(raw).decode("ascii")

    raise FileNotFoundError(f"Image not found: {source_str}")


def _prepare_images(images: list[str | Path] | None) -> list[str]:
    """Normalize images to base64 strings, skipping failures."""
    if not images:
        return []
    encoded: list[str] = []
    for idx, src in enumerate(images[:_MAX_IMAGES]):
        try:
            encoded.append(encode_image(src))
        except (FileNotFoundError, ValueError) as e:
            log.warning("Skipping image #%d: %s", idx, e)
    return encoded


# ── Chat Template ────────────────────────────────────────────────────────────

_CHAT_TEMPLATES: dict[str, str] = {
    "gemma": "<start_of_turn>user\n{system}{prompt}<end_of_turn>\n<start_of_turn>model\n",
    "mistral": "[INST] {system}{prompt} [/INST]",
    "phi": "<|user|>\n{system}{prompt}<|end|>\n<|assistant|>\n",
    "default": "{system}\n\n{prompt}",
}


def _apply_chat_template(tokenizer: Any, prompt: str, system: str = "") -> str:
    """Apply chat template to prompt. Tries tokenizer's template first, falls back to manual."""
    system_block = f"{system}\n\n" if system else ""

    # Try tokenizer's built-in chat template
    try:
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})
        formatted = tokenizer.apply_chat_template(
            messages, add_generation_prompt=True, tokenize=False,
        )
        if formatted and len(formatted) > len(prompt):
            return formatted
    except (ValueError, AttributeError, TypeError):
        pass

    # Fallback: detect model family from tokenizer name/config
    tok_name = getattr(tokenizer, "name_or_path", "") or str(type(tokenizer)).lower()
    tok_lower = tok_name.lower()

    for family, template in _CHAT_TEMPLATES.items():
        if family in tok_lower:
            return template.format(system=system_block, prompt=prompt)

    return _CHAT_TEMPLATES["default"].format(system=system_block, prompt=prompt)


# ── Backend: MLX (text) ─────────────────────────────────────────────────────


@retry(max_attempts=1, backoff=3.0, on=(RuntimeError, OSError, TimeoutError))
def _call_mlx(
    prompt: str,
    model: str,
    *,
    max_tokens: int,
    temperature: float,
    system: str = "",
) -> str:
    """Call mlx-lm for text generation with threading timeout."""
    try:
        from mlx_lm import generate as mlx_generate
        from mlx_lm.sample_utils import make_sampler
    except ImportError:
        log.error("mlx-lm not installed. pip install mlx-lm")
        return ""

    mlx_model, tokenizer = get_mlx_model(model)
    sampler = make_sampler(temperature)

    formatted_prompt = _apply_chat_template(tokenizer, prompt, system)

    # R4 auto-wire (2026-04-16): refuse prefills whose estimated peak
    # allocation would risk IOGPUFamily kernel panic. Raises MetalOOMError
    # which propagates through oom_protected_context as a normal error.
    _prefill_guard_check(
        model=model, tokenizer=tokenizer,
        formatted_prompt=formatted_prompt, max_tokens=max_tokens,
    )

    result_holder: list[Any] = [None]
    error_holder: list[BaseException | None] = [None]

    def _run_generate() -> None:
        try:
            result_holder[0] = mlx_generate(
                mlx_model, tokenizer, prompt=formatted_prompt,
                max_tokens=max_tokens, sampler=sampler,
            )
        except Exception as exc:
            error_holder[0] = exc

    # Hole #4: register BEFORE start() to close the μs window where a
    # freshly-started thread is not yet in the registry.
    #
    # The OOM-protected context manager catches std::runtime_error from
    # Metal completion queue (Insufficient Memory / fPendingMemorySet),
    # runs safe_cleanup, and raises MetalOOMError instead of aborting
    # the process. See Layer 3 smoke postmortem for the pre-wiring
    # SIGABRT crash pattern.
    with metal_guard.oom_protected_context():
        thread = threading.Thread(target=_run_generate, daemon=True)
        metal_guard.register_thread(thread)
        metal_guard.breadcrumb(f"GENERATE: thread start model={model}")
        thread.start()
        thread.join(timeout=_MLX_GENERATE_TIMEOUT)

        if thread.is_alive():
            metal_guard.breadcrumb(f"GENERATE: TIMEOUT model={model}")
            log.error(
                "MLX generate timeout after %ds for %s — thread still alive, "
                "skipping unload to prevent Metal panic",
                _MLX_GENERATE_TIMEOUT, model,
            )
            raise TimeoutError(
                f"MLX generate exceeded {_MLX_GENERATE_TIMEOUT}s timeout (model={model})"
            )

        metal_guard.breadcrumb(f"GENERATE: thread done model={model}")

        if error_holder[0] is not None:
            raise error_holder[0]  # type: ignore[misc]

        response = result_holder[0]

    # Force GPU synchronization — Metal command buffers may still be in-flight
    try:
        import mlx.core as mx
        metal_guard.breadcrumb("GENERATE: mx.eval sync START")
        mx.eval(mx.zeros(1))
        metal_guard.breadcrumb("GENERATE: mx.eval sync DONE")
    except (ImportError, AttributeError):
        pass

    return response.strip() if isinstance(response, str) else str(response).strip()


# ── Backend: MLX-VLM (vision) ────────────────────────────────────────────────


@retry(max_attempts=1, backoff=3.0, on=(RuntimeError, OSError, TimeoutError))
def _call_mlx_vlm(
    prompt: str,
    model: str,
    *,
    max_tokens: int,
    temperature: float,
    images_b64: list[str] | None = None,
) -> str:
    """Call mlx-vlm for vision+text generation with threading timeout."""
    try:
        from mlx_vlm import generate as vlm_generate
        from mlx_vlm.prompt_utils import apply_chat_template as vlm_chat_template
    except ImportError:
        log.error("mlx-vlm not installed. pip install mlx-vlm")
        return ""

    temp_paths: list[Path] = []
    try:
        vlm_model, processor = get_mlx_vlm_model(model)

        # Convert base64 images to temp files (mlx-vlm expects paths)
        image_arg: str | list[str] | None = None
        num_images = 0
        if images_b64:
            import tempfile
            for _i, b64 in enumerate(images_b64):
                fd = tempfile.NamedTemporaryFile(suffix=".jpg", delete=False)
                fd.write(base64.b64decode(b64))
                fd.close()
                temp_paths.append(Path(fd.name))

            paths = [str(p) for p in temp_paths]
            image_arg = paths if len(paths) > 1 else paths[0]
            num_images = len(paths)

        formatted_prompt = vlm_chat_template(
            processor, vlm_model.config, prompt, num_images=num_images,
        )

        # R4 auto-wire (2026-04-16): same prefill guard as the text path.
        # VLM tokenizer is the processor's text tokenizer — try both shapes.
        vlm_tokenizer = getattr(processor, "tokenizer", processor)
        _prefill_guard_check(
            model=model, tokenizer=vlm_tokenizer,
            formatted_prompt=formatted_prompt, max_tokens=max_tokens,
        )

        result_holder: list[Any] = [None]
        error_holder: list[BaseException | None] = [None]

        def _run_vlm_generate() -> None:
            try:
                result_holder[0] = vlm_generate(
                    vlm_model, processor,
                    prompt=formatted_prompt,
                    image=image_arg,
                    max_tokens=max_tokens,
                    temp=temperature,
                )
            except Exception as exc:
                error_holder[0] = exc

        # Hole #4 + OOM protection — see _call_mlx for rationale.
        with metal_guard.oom_protected_context():
            thread = threading.Thread(target=_run_vlm_generate, daemon=True)
            metal_guard.register_thread(thread)
            metal_guard.breadcrumb(f"VLM_GENERATE: thread start model={model}")
            thread.start()
            thread.join(timeout=_VLM_GENERATE_TIMEOUT)

            if thread.is_alive():
                metal_guard.breadcrumb(f"VLM_GENERATE: TIMEOUT model={model}")
                log.error(
                    "MLX-VLM generate timeout after %ds for %s",
                    _VLM_GENERATE_TIMEOUT, model,
                )
                raise TimeoutError(
                    f"MLX-VLM generate exceeded {_VLM_GENERATE_TIMEOUT}s timeout (model={model})"
                )

            metal_guard.breadcrumb(f"VLM_GENERATE: thread done model={model}")

            if error_holder[0] is not None:
                raise error_holder[0]  # type: ignore[misc]

            text = getattr(result_holder[0], "text", str(result_holder[0]))

        # Force GPU synchronization
        try:
            import mlx.core as mx
            metal_guard.breadcrumb("VLM_GENERATE: mx.eval sync START")
            mx.eval(mx.zeros(1))
            metal_guard.breadcrumb("VLM_GENERATE: mx.eval sync DONE")
        except (ImportError, AttributeError):
            pass

        return text.strip()

    except ImportError:
        log.error("mlx-vlm import failed during VLM inference")
        return ""
    finally:
        for p in temp_paths:
            p.unlink(missing_ok=True)


# ── Backend: Ollama HTTP ─────────────────────────────────────────────────────


@retry()
def _call_ollama_http(
    prompt: str,
    model: str,
    *,
    max_tokens: int,
    temperature: float,
    num_ctx: int = _DEFAULT_NUM_CTX,
    json_mode: bool = False,
    system: str = "",
    timeout: int = _DEFAULT_TIMEOUT,
) -> str:
    """Call Ollama HTTP API (simplified fallback).

    Uses stdlib ``urllib`` — metal-guard ships zero third-party runtime
    dependencies (see pyproject.toml).
    """
    import json as _json
    import urllib.error
    import urllib.request

    url = os.getenv("OLLAMA_URL", "http://localhost:11434/api/generate")
    payload: dict = {
        "model": model,
        "prompt": prompt,
        "stream": False,
        "options": {
            "num_predict": max_tokens,
            "temperature": temperature,
            "num_ctx": num_ctx,
        },
    }
    if json_mode:
        payload["format"] = "json"
    if system:
        payload["system"] = system

    data = _json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url, data=data, method="POST",
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read().decode("utf-8")
        return _json.loads(body).get("response", "").strip()
    except urllib.error.HTTPError as e:
        log.error("Ollama HTTP %s (model=%s)", e.code, model)
        return ""
    except (urllib.error.URLError, TimeoutError, ConnectionError, OSError):
        raise  # transient connection failure — let @retry handle it
    except Exception as e:  # noqa: BLE001
        log.error("Ollama failed (model=%s): %s", model, e)
        return ""


# ── Main Dispatch ────────────────────────────────────────────────────────────


def call_model(
    prompt: str,
    *,
    model: str,
    backend: str = "mlx",
    images: list[str] | None = None,
    max_tokens: int = _DEFAULT_MAX_TOKENS,
    temperature: float = _DEFAULT_TEMPERATURE,
    num_ctx: int = _DEFAULT_NUM_CTX,
    json_mode: bool = False,
    timeout: int = _DEFAULT_TIMEOUT,
    system: str = "",
    max_prompt_chars: int = _MAX_PROMPT_CHARS,
) -> str:
    """Call LLM with backend dispatch.

    Explicit-parameter dispatcher — model and backend are passed in by the
    caller, no role-based routing performed here. Intended as a thin layer
    for downstream projects that maintain their own role→model mappings.
    """
    if len(prompt) > max_prompt_chars:
        log.warning("Prompt truncated: %d → %d chars", len(prompt), max_prompt_chars)
        prompt = prompt[:max_prompt_chars]

    if backend in ("mlx", "mlx-lm", "mlx-vlm"):
        # Hole #1: must outlast the longest generate timeout, otherwise a
        # still-alive generate thread + a new generate = IOGPUMemory underflow.
        _wait_budget = _VLM_GENERATE_TIMEOUT + _THREAD_CLEANUP_GRACE_SECS
        still_alive = metal_guard.wait_for_threads(timeout=_wait_budget)
        if still_alive:
            metal_guard.breadcrumb(
                f"DISPATCH_BLOCKED: {still_alive} thread(s) alive after {_wait_budget}s"
            )
            raise MLXDispatchBlockedError(still_alive, _wait_budget)

        # Hole #2: serialize all MLX backend calls within this process.
        # Metal does not support concurrent mlx_generate. Held around the
        # entire generate (not just dispatch) so ThreadPoolExecutor callers
        # funnel through here.
        #
        # In observer mode (METALGUARD_MODE=observer, post-#3348), the
        # _mlx_call_lock() helper returns a null context so parallel
        # generate() is allowed. Defensive mode (default) returns the
        # real RLock.
        with _mlx_call_lock():
            # Hole #3: cross-process mutual exclusion via file lock.
            # Previously advisory-only (pid breadcrumb). Now enforced:
            # acquire_mlx_lock() raises MLXLockConflict if another
            # process (e.g. mlx_lm.server, another benchmark) holds
            # the lock.  The lock is released in finally so it never
            # leaks even on generate() crash.
            #
            # 2026-04-13: upgraded from advisory breadcrumb to
            # enforceable lock.  This closes the gap where external
            # processes (mlx_lm.server wrapper, direct mlx_lm.generate)
            # cooperatively acquire the lock but call_model() never
            # checked it.
            from metal_guard.mlx_lock import (
                acquire_mlx_lock,
                release_mlx_lock,
                MLXLockConflict,
            )
            try:
                acquire_mlx_lock("call_model")
            except MLXLockConflict:
                # Also write breadcrumb for diagnostics.
                _check_other_mlx_process()
                raise
            try:
                # Note (2026-04-20): cadence guard NOT wired here even
                # though it seemed like the obvious spot. Reason — the
                # IOGPUMemory.cpp:492 underflow is triggered by
                # *unload→load* cycles (``completeMemory`` tries to free
                # buffers a second unload already reclaimed). Pure
                # additive loads into ModelCache do not trigger it.
                # Wiring the guard here false-positives any co-resident
                # batch workload (e.g. a vision pipeline loading 3
                # debaters within ~45s on cold cache). Guard lives in
                # ``bench_scoped_load`` (long sequential bench harnesses
                # that DO cycle load/unload) and
                # ``subprocess_runner._worker_main`` (cross-process
                # per-model worker). Callers that explicitly unload_all()
                # before reloading must invoke require_cadence_clear()
                # themselves.

                # Pre-inference stale-cache guard. Credit @alexpekarovsky on
                # ml-explore/mlx-lm#1015 (2026-03-21): when a worker process
                # is SIGKILL'd mid-generate, its finally{} never runs and
                # mx.clear_cache() doesn't fire. Stale Metal buffers
                # accumulate across retries, slowing each subsequent call
                # and eventually cascading into SIGABRT. Clearing the
                # allocator cache before each dispatch breaks that cascade.
                # Validated by @alexpekarovsky with 3,600 inferences / 72h
                # zero-crash production deployment. Overhead is ~10-50ms.
                try:
                    import mlx.core as mx
                    mx.clear_cache()
                    metal_guard.breadcrumb("PRE_INFERENCE: mx.clear_cache()")
                except (ImportError, AttributeError):
                    pass

                if backend in ("mlx", "mlx-lm"):
                    # Pre-load gate OUTSIDE `_call_mlx`'s @retry boundary so
                    # MLXLoadGateError isn't silently retried. See
                    # `_check_load_gate` docstring for boundary rationale.
                    _check_load_gate(model)
                    return _call_mlx(
                        prompt, model,
                        max_tokens=max_tokens, temperature=temperature,
                        system=system,
                    )
                # backend == "mlx-vlm"
                _check_load_gate(model)
                images_b64 = _prepare_images(images) if images else None
                return _call_mlx_vlm(
                    prompt, model,
                    max_tokens=max_tokens, temperature=temperature,
                    images_b64=images_b64,
                )
            finally:
                release_mlx_lock()

    if backend == "ollama":
        # Ollama HTTP handles its own serialization — stay unlocked for throughput.
        return _call_ollama_http(
            prompt, model,
            max_tokens=max_tokens, temperature=temperature,
            num_ctx=num_ctx, json_mode=json_mode, timeout=timeout,
            system=system,
        )

    raise ValueError(f"Unknown backend: {backend}")


# ── MetalGuard L5: bench_scoped_load ─────────────────────────────────────────


@contextmanager
def bench_scoped_load(
    model_id: str,
    *,
    backend: str = "mlx",
) -> Iterator[Tuple[Any, Any]]:
    """Safe sequential model loading for long-running benchmark harnesses.

    MetalGuard Layer 5. Wraps ``get_mlx_model()`` / ``get_mlx_vlm_model()`` so
    any harness that must load 4+ large MLX models inside one Python process
    gets the full existing defensive stack — ``metal_guard.require_fit``
    (with escalated retry + cache clear callback), thread registry,
    ``wait_for_threads``, and ``safe_cleanup`` — automatically on every
    iteration, plus an explicit post-unload memory-drop verification and
    additional cooldown beyond ``safe_cleanup``'s internal sleep.

    Rationale: benchmark harnesses that bypass this library (calling
    ``mlx_lm.load`` + ``mlx_lm.generate`` directly in a loop) can drift above
    the working-set limit on 64GB Apple Silicon after loading 6+ large models
    sequentially — residual Metal driver buffer accounting keeps stale
    allocations visible even after ``mx.clear_cache()``. This has been
    observed to trigger an IOGPUMemory.cpp:492 ``completeMemory() prepare
    count underflow`` kernel panic. ``bench_scoped_load`` routes every
    iteration through the same defensive stack ``call_model`` uses, plus
    extra post-unload verification.

    Usage::

        from metal_guard.inference import bench_scoped_load

        for model_id in candidate_models:  # 8 large models
            with bench_scoped_load(model_id) as (model, tokenizer):
                score = run_tmmlu_mmlu(model, tokenizer, items)
                save_atomic_checkpoint(model_id, score)

    Parameters
    ----------
    model_id:
        Hugging Face model ID that ``mlx_lm.load`` / ``mlx_vlm.load`` accepts,
        e.g. ``"mlx-community/Mistral-Small-3.2-24B-Instruct-2506-8bit"``.
    backend:
        ``"mlx"`` / ``"mlx-lm"`` → text model via ``get_mlx_model``.
        ``"mlx-vlm"`` → vision model via ``get_mlx_vlm_model``.

    Yields
    ------
    The ``(model, tokenizer)`` tuple returned by the underlying loader.

    Raises
    ------
    MemoryError
        If ``require_fit`` fails even after escalated cleanup.
    ValueError
        If ``backend`` is not a supported MLX backend.

    Notes
    -----
    Does NOT replace any of Layers 1-4. It delegates to them and adds the
    post-unload verification step. Safe to use alongside the existing
    ``call_model`` dispatch; they share the same ``ModelCache`` singleton.
    """
    from metal_guard.mlx_lock import (
        acquire_mlx_lock,
        release_mlx_lock,
    )

    metal_guard.breadcrumb(f"BENCH_SCOPED_LOAD: ENTER {model_id} backend={backend}")
    log.info("bench_scoped_load: entering %s (backend=%s)", model_id, backend)

    # R4 advisory (2026-04-16): if the model has known dims, log the prefill
    # safety envelope at the biggest common bench context (131 072) so the
    # caller sees ahead of time which cells will trip require_prefill_fit.
    # Advisory only — bench may legitimately load a model then run at short
    # context; this logs what 131k would cost, not what the caller plans.
    try:
        stats = metal_guard.memory_stats()
        plan = describe_prefill_plan(
            context_tokens=131072, model_id=model_id,
            available_gb=stats.available_gb if stats.limit_bytes > 0 else None,
        )
        if plan["dims_known"]:
            if plan["fits_ceiling"] is False:
                log.warning(
                    "bench_scoped_load: %s at 131k ctx would alloc ~%s GB > 5 GB "
                    "ceiling — R4 will refuse; recommend chunk=%s",
                    model_id, plan["peak_alloc_gb"],
                    plan["recommended_chunk_size"],
                )
            else:
                log.info(
                    "bench_scoped_load: %s prefill plan OK at 131k "
                    "(peak ~%s GB)", model_id, plan["peak_alloc_gb"],
                )
    except Exception as exc:  # defensive: never let advisory disturb bench
        log.debug("bench_scoped_load: prefill plan advisory failed: %s", exc)

    # Acquire cross-process lock for the entire bench scope (load + yield + unload).
    # Unlike call_model() which acquires per-call, bench holds the lock across
    # multiple generate() calls on the same model — preventing other processes
    # from loading a competing model mid-benchmark.
    acquire_mlx_lock("bench_scoped_load")

    # Pre-load stale-cache guard (see call_model() for full rationale —
    # credit @alexpekarovsky on mlx-lm#1015). Protects against a previous
    # bench iteration that was SIGKILL'd or crashed without exit cleanup.
    try:
        import mlx.core as mx
        mx.clear_cache()
        metal_guard.breadcrumb(
            f"BENCH_SCOPED_LOAD: pre-load mx.clear_cache() {model_id}"
        )
    except (ImportError, AttributeError):
        pass

    # Direct load, bypassing _ensure_fit_before_load. In bench scope we
    # manage the full lifecycle (load → yield → unload) sequentially, and
    # Metal's lazy page reclaimer only returns stale pages to the OS when
    # the next load() actually allocates new buffers — a require_fit
    # pre-check using memory_stats() will report the stale pages as
    # "active" and incorrectly block legitimate back-to-back loads of
    # 25GB+ models on 64GB M1 Ultra. Observed 2026-04-13: Gemma4-26b
    # unload → 26.8GB stale, Mistral-24B load refused by require_fit
    # even though Metal would have reclaimed during mlx_lm.load() itself.
    #
    # Skipping require_fit is safe here because bench_scoped_load holds
    # the cross-process MLX lock for the entire scope and ran a full
    # unload_all() + safe_cleanup on the previous iteration. The call_model()
    # path keeps its require_fit gate — that's where arbitrary callers
    # need the protection.
    # L9 cadence guard (2026-04-16): Refuse back-to-back loads of the
    # same model within 180s. This is the in-process path (bench /
    # dev-mode); subprocess_runner has its own cadence check in
    # _worker_main. Raising here lets bench iterations surface the
    # violation explicitly rather than kernel-panic the machine.
    try:
        from metal_guard.cadence import (
            CadenceViolation,
            require_cadence_clear,
        )
        require_cadence_clear(model_id)
    except CadenceViolation:
        release_mlx_lock()
        raise
    except ImportError:
        pass

    # Bench path ALSO runs the pre-load gate. Bench harness benefits from
    # VRAM prediction refusal — loading 26B-bf16 on a pressured system would
    # otherwise silently OOM-pressure the IOGPU under bench. Operator can
    # opt out with ``MLX_LOAD_GATE_DISABLED=1`` for "I really want to bench
    # under pressure" intent. Mirrors the explicit `require_fit` bypass
    # documentation pattern above — but for the load gate we default-gate,
    # default-bypass `require_fit`, intentional asymmetry.
    #
    # Gate refusal MUST release the cross-process MLX lock acquired above;
    # otherwise next caller deadlocks until process exit. Mirror the
    # CadenceViolation handling pattern just above.
    try:
        _check_load_gate(model_id)
    except Exception:
        release_mlx_lock()
        raise

    if backend in ("mlx", "mlx-lm"):
        from mlx_lm import load as _mlx_load
        metal_guard.breadcrumb(f"BENCH_SCOPED_LOAD: direct load {model_id}")
        loaded = _mlx_load(model_id)
    elif backend == "mlx-vlm":
        from mlx_vlm import load as _vlm_load
        metal_guard.breadcrumb(f"BENCH_SCOPED_LOAD: direct vlm load {model_id}")
        loaded = _vlm_load(model_id)
    else:
        release_mlx_lock()
        raise ValueError(
            f"bench_scoped_load: unsupported backend {backend!r} "
            f"(expected 'mlx', 'mlx-lm', or 'mlx-vlm')"
        )

    try:
        yield loaded
    finally:
        metal_guard.breadcrumb(
            f"BENCH_SCOPED_LOAD: EXIT {model_id} — unloading + cooldown"
        )
        log.info("bench_scoped_load: exiting %s, unloading", model_id)
        # unload_all() delegates to safe_cleanup (wait_for_threads + gc +
        # flush_gpu + internal cooldown). Add an extra cooldown because
        # Metal's lazy release can take a few more seconds to return pages
        # to the OS.
        unload_all()
        gc.collect()
        # Reset peak tracker so the NEXT iteration's memory_stats().peak_gb
        # reflects only that model, not a stale high-water mark from a
        # previous large model that Metal hasn't fully released yet.
        try:
            import mlx.core as mx
            mx.reset_peak_memory()
        except (ImportError, AttributeError):
            pass

        time.sleep(_BENCH_POST_UNLOAD_COOLDOWN_SEC)

        # Diagnostic only: Metal lazy release means active memory may still
        # report high here — the pages are reclaimed when the NEXT load()
        # allocates. This warning is informational, no longer load-blocking
        # (bench_scoped_load bypasses require_fit — see load section above).
        stats = metal_guard.memory_stats()
        active_after_gb = stats.active_gb
        if active_after_gb > _BENCH_POST_UNLOAD_ACTIVE_LIMIT_GB:
            log.info(
                "bench_scoped_load: %s active memory %.1fGB after unload "
                "(expected eventually < %.1fGB via Metal lazy release on next load)",
                model_id, active_after_gb, _BENCH_POST_UNLOAD_ACTIVE_LIMIT_GB,
            )
        metal_guard.breadcrumb(
            f"BENCH_SCOPED_LOAD: EXIT {model_id} done, active={active_after_gb:.1f}GB"
        )
        log.info(
            "bench_scoped_load: exited %s, active memory %.1fGB peak %.1fGB",
            model_id, active_after_gb, stats.peak_gb,
        )
        release_mlx_lock()


# ── Explicit pre-inference guard primitive ─────────────────────────────────
# Public helper for callers that bypass call_model / bench_scoped_load but
# still want the stale-cache protection. Example: a custom harness that
# calls mlx_lm.generate directly but manages its own dispatch semantics.


@contextmanager
def pre_inference_guard() -> Iterator[None]:
    """Context manager that clears stale Metal allocator cache on entry.

    Addresses the failure mode documented by @alexpekarovsky on
    ml-explore/mlx-lm#1015 (2026-03-21): when a previous inference was
    SIGKILL'd mid-generate (timeout, OOM, host kill), its cleanup never
    ran and stale Metal buffers accumulate. Clearing the allocator cache
    before dispatch breaks the cascade into SIGABRT.

    Usage::

        from metal_guard.inference import pre_inference_guard

        with pre_inference_guard():
            result = mlx_lm.generate(model, tokenizer, prompt=prompt)

    Safe to nest inside ``call_model`` or ``bench_scoped_load`` (both
    already fire ``mx.clear_cache()`` internally — redundant calls are
    harmless, allocator cache is just an optimization).

    Yields
    ------
    None. The guard has no per-call state.

    Notes
    -----
    This clears ONLY MLX's internal allocator cache. It does NOT:
        * Clear KV caches maintained by the caller
        * Force unload of loaded models
        * Reset peak memory counters

    For those, use ``metal_guard.safe_cleanup()`` or
    ``mx.reset_peak_memory()`` explicitly.
    """
    try:
        import mlx.core as mx
        mx.clear_cache()
        metal_guard.breadcrumb("PRE_INFERENCE_GUARD: mx.clear_cache() entered")
    except (ImportError, AttributeError):
        pass

    try:
        yield
    finally:
        # Symmetric post-clear, matching @alexpekarovsky's recommended
        # "clear before AND after" pattern. The pre-clear guards against
        # stale cache from a previous killed inference; the post-clear
        # is the normal cleanup that would have run in a finally{} block
        # if this call completed normally.
        try:
            import mlx.core as mx
            mx.clear_cache()
            metal_guard.breadcrumb("PRE_INFERENCE_GUARD: mx.clear_cache() exited")
        except (ImportError, AttributeError):
            pass


def safe_generate(
    prompt: str,
    model: str,
    *,
    backend: str = "mlx",
    system: str = "",
    images: list[str | Path] | None = None,
    max_tokens: int = _DEFAULT_MAX_TOKENS,
    temperature: float = _DEFAULT_TEMPERATURE,
    timeout: int = _DEFAULT_TIMEOUT,
) -> dict[str, Any]:
    """Server-friendly wrapper around ``call_model``.

    Converts Metal-related failures into a structured result instead of
    propagating. Designed for HTTP handlers (FastAPI / Flask / Sanic)
    and queue workers that must never crash the parent process on a
    GPU event.

    Result shape::

        {
            "ok": bool,
            "text": str | None,     # present on success
            "http_status": int,     # 200 | 503 | 500
            "error": str | None,    # present on failure
            "error_kind": str | None,  # "oom" | "dispatch_blocked" | "other"
        }

    The caller picks the framework-specific rendering. For FastAPI::

        result = safe_generate(prompt, model)
        if not result["ok"]:
            raise HTTPException(result["http_status"], result["error"])
        return {"text": result["text"]}

    503 is returned for MetalOOMError and for MLXDispatchBlockedError,
    because both are recoverable by retry once GPU pressure subsides —
    retry-after semantics fit HTTP 503. 500 is returned for everything
    else so the caller can log/alert a non-GPU bug.
    """
    try:
        text = call_model(
            prompt,
            model=model,
            backend=backend,
            system=system,
            images=images,
            max_tokens=max_tokens,
            temperature=temperature,
            timeout=timeout,
        )
        return {
            "ok": True,
            "text": text,
            "http_status": 200,
            "error": None,
            "error_kind": None,
        }
    except MetalOOMError as exc:
        metal_guard.breadcrumb(f"SAFE_GENERATE: MetalOOMError → 503 ({exc})")
        return {
            "ok": False,
            "text": None,
            "http_status": 503,
            "error": str(exc),
            "error_kind": "oom",
        }
    except MLXDispatchBlockedError as exc:
        metal_guard.breadcrumb(
            f"SAFE_GENERATE: MLXDispatchBlockedError → 503 ({exc})"
        )
        return {
            "ok": False,
            "text": None,
            "http_status": 503,
            "error": str(exc),
            "error_kind": "dispatch_blocked",
        }
    except RuntimeError as exc:
        if metal_guard.is_metal_oom(exc):
            metal_guard.breadcrumb(
                f"SAFE_GENERATE: raw Metal OOM RuntimeError → 503 ({exc})"
            )
            return {
                "ok": False,
                "text": None,
                "http_status": 503,
                "error": str(exc),
                "error_kind": "oom",
            }
        log.exception("safe_generate: unexpected RuntimeError")
        return {
            "ok": False,
            "text": None,
            "http_status": 500,
            "error": str(exc),
            "error_kind": "other",
        }
    except Exception as exc:
        log.exception("safe_generate: unexpected exception")
        return {
            "ok": False,
            "text": None,
            "http_status": 500,
            "error": str(exc),
            "error_kind": "other",
        }
