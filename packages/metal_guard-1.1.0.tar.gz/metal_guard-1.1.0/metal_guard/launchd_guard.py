"""launchd_guard — protect against KeepAlive crash-loop on Apple Silicon.

Background:

* macOS launchd respawns daemons on exit. ``KeepAlive=true`` retries
  unconditionally; ``ThrottleInterval`` adds a minimum delay between
  retries (default 10s).
* When a daemon crashes immediately on import (e.g. a heavy ML framework
  during a resource-constrained window, port already bound, secret decrypt
  failed), it can re-launch every ~10s and burn GPU descriptors / DB locks
  / model loader resources.
* Worse: if the crash is panic-related, each retry pulls the gate's
  threshold closer to triggering a kernel panic re-occurrence.

This behaviour is a documented macOS launchd property: a ``KeepAlive``
daemon that exits in under ``ThrottleInterval`` (default 10 s) will be
re-launched indefinitely, cycling the same crash without any built-in
loop-breaker.

This module provides:

1. :func:`detect_launchd_context` — reads ``XPC_SERVICE_NAME`` /
   ``LAUNCH_DAEMON`` env vars to identify if we're running under
   launchd, and which label.
2. :func:`record_crash` — append-only crash log so subsequent restarts
   can count recent failures.
3. :func:`check_keepalive_guard` — returns a verdict telling the
   process whether it should self-bootout (call out to launchctl) to
   break the crash loop.
4. :func:`request_self_bootout` — best-effort ``launchctl bootout``
   subprocess to halt the daemon.

The crash counter is per-label, stored under
``~/.metal-guard/state/launchd_crashes/<label>.jsonl``. Fully isolated
from :mod:`panic_corpus` so a corrupt corpus cannot poison crash counts.
"""
from __future__ import annotations

import json
import logging
import os
import subprocess
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path

log = logging.getLogger(__name__)

_DEFAULT_CRASH_DIR = "~/.metal-guard/state/launchd_crashes"
_CRASH_DIR_ENV = "METALGUARD_LAUNCHD_CRASH_DIR"
_GUARD_DISABLED_ENV = "METALGUARD_LAUNCHD_GUARD_DISABLED"

# Default crash-loop thresholds: 3 crashes within 5 minutes → bootout.
# Empirical: 1-2s exit races at default 10s ThrottleInterval would fire
# 3+ within 5 min before launchd backs off further.
_DEFAULT_CRASH_WINDOW_SEC = 300.0
_DEFAULT_CRASH_THRESHOLD = 3

# launchd sets these env vars when a process is spawned via plist.
# XPC_SERVICE_NAME is the most reliable across macOS versions
# (com.apple.* for system; user-defined Label for user plists).
_LAUNCHD_ENV_KEYS: tuple[str, ...] = ("XPC_SERVICE_NAME",)


@dataclass(frozen=True)
class LaunchdContext:
    """Result of :func:`detect_launchd_context`.

    Attributes:
        running_under_launchd: True iff at least one launchd env marker
            present.
        label: The XPC_SERVICE_NAME (or other detected label). May be
            None even when ``running_under_launchd=True`` if env stripped.
    """
    running_under_launchd: bool
    label: str | None


@dataclass(frozen=True)
class KeepAliveVerdict:
    """Result of :func:`check_keepalive_guard`.

    Attributes:
        label: Same as :class:`LaunchdContext.label`.
        recent_crashes: Count within ``window_sec`` of ``now``.
        threshold: Threshold used for the decision.
        should_self_bootout: True iff caller should invoke
            ``launchctl bootout``.
        reason: Human-readable string for logs / corpus.
    """
    label: str | None
    recent_crashes: int
    threshold: int
    should_self_bootout: bool
    reason: str


def _crash_dir() -> Path:
    raw = os.environ.get(_CRASH_DIR_ENV) or _DEFAULT_CRASH_DIR
    return Path(os.path.expanduser(raw))


def _crash_log_for(label: str) -> Path:
    # Sanitize label so an injected slash can't escape the crash dir.
    # Replace anything non-alphanum/.-_ with underscore.
    safe = "".join(c if c.isalnum() or c in "._-" else "_" for c in label)
    return _crash_dir() / f"{safe}.jsonl"


def detect_launchd_context() -> LaunchdContext:
    """Best-effort detection. Returns running_under_launchd=False when
    none of the markers are set."""
    label: str | None = None
    for key in _LAUNCHD_ENV_KEYS:
        val = os.environ.get(key)
        if val:
            label = val
            break
    return LaunchdContext(
        running_under_launchd=label is not None,
        label=label,
    )


def record_crash(
    *,
    label: str | None = None,
    reason: str = "",
    now: datetime | None = None,
) -> bool:
    """Append a crash event to the per-label log.

    No-op when:
    - guard disabled via ``METALGUARD_LAUNCHD_GUARD_DISABLED=1``
    - label is None / empty (not under launchd, nothing to track)

    Returns True on successful append, False otherwise. Never raises.
    """
    if os.environ.get(_GUARD_DISABLED_ENV) == "1":
        return False
    if label is None:
        ctx = detect_launchd_context()
        label = ctx.label
    if not label:
        return False

    record = {
        "ts": (now or datetime.now()).isoformat(timespec="seconds"),
        "label": label,
        "reason": reason[:500] if isinstance(reason, str) else "",
    }
    path = _crash_log_for(label)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        data = (json.dumps(record, ensure_ascii=False) + "\n").encode("utf-8")
        fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
        try:
            os.write(fd, data)
            os.fsync(fd)
        finally:
            os.close(fd)
    except OSError as exc:
        log.debug("launchd_guard: record_crash failed: %s", exc)
        return False
    return True


def _read_recent_crashes(
    label: str, *, since: datetime,
) -> int:
    path = _crash_log_for(label)
    if not path.exists():
        return 0
    n = 0
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                except json.JSONDecodeError:
                    continue
                ts_raw = rec.get("ts") if isinstance(rec, dict) else None
                if not isinstance(ts_raw, str):
                    continue
                try:
                    ts = datetime.fromisoformat(ts_raw)
                except ValueError:
                    continue
                if ts >= since:
                    n += 1
    except OSError as exc:
        log.debug("launchd_guard: read_recent_crashes failed: %s", exc)
    return n


def check_keepalive_guard(
    *,
    label: str | None = None,
    window_sec: float = _DEFAULT_CRASH_WINDOW_SEC,
    threshold: int = _DEFAULT_CRASH_THRESHOLD,
    now: datetime | None = None,
) -> KeepAliveVerdict:
    """Decide whether to recommend self-bootout based on recent crashes.

    Counter is read from the per-label crash log. Caller decides whether
    to actually invoke :func:`request_self_bootout` based on the verdict.

    Defaults: ≥3 crashes within 5 minutes → recommend bootout.
    """
    if label is None:
        ctx = detect_launchd_context()
        label = ctx.label
    now = now or datetime.now()
    if not label:
        return KeepAliveVerdict(
            label=None, recent_crashes=0, threshold=threshold,
            should_self_bootout=False,
            reason="not running under launchd",
        )
    cutoff = now - timedelta(seconds=window_sec)
    n = _read_recent_crashes(label, since=cutoff)
    if n >= threshold:
        return KeepAliveVerdict(
            label=label, recent_crashes=n, threshold=threshold,
            should_self_bootout=True,
            reason=(
                f"{n} crashes in last {window_sec/60:.1f} min "
                f"(threshold={threshold}); recommend bootout to break loop"
            ),
        )
    return KeepAliveVerdict(
        label=label, recent_crashes=n, threshold=threshold,
        should_self_bootout=False,
        reason=f"{n} crashes (under threshold {threshold})",
    )


from contextlib import contextmanager


@contextmanager
def auto_record_on_failure(
    *, label: str | None = None, now: datetime | None = None,
):
    """Context manager: record a crash if the body raises.

    SCOPE: catches any uncaught Python exception. Does NOT cover
    SIGSEGV / SIGABRT / kernel panic — those bypass Python's exception
    handling. The crash counter is therefore biased toward "soft"
    failure modes (import errors, port-busy, secret-decrypt, config
    parse). For hard panics we rely on :mod:`panic_cooldown` reading
    the kernel panic logs directly.

    Usage::

        from metal_guard.launchd_guard import auto_record_on_failure

        with auto_record_on_failure(label="com.example.my-daemon"):
            main()  # any raise here gets recorded then re-raised
    """
    try:
        yield
    except BaseException as exc:  # noqa: BLE001 boundary helper
        try:
            record_crash(
                label=label,
                reason=f"{type(exc).__name__}: {exc}",
                now=now,
            )
        except Exception:  # noqa: BLE001 best-effort
            pass
        raise


def daemon_guard(
    *,
    label: str | None = None,
    bootout_on_loop: bool = True,
    threshold: int = _DEFAULT_CRASH_THRESHOLD,
    window_sec: float = _DEFAULT_CRASH_WINDOW_SEC,
    now: datetime | None = None,
) -> KeepAliveVerdict:
    """One-shot startup guard for launchd-managed daemons.

    Order:
      1. Detect launchd context (no-op if not under launchd).
      2. Read crash log; if ≥threshold within window, recommend bootout.
      3. If ``bootout_on_loop=True`` AND crash-loop detected, actually
         invoke ``launchctl bootout`` so launchd stops respawning.
         Caller should ``sys.exit(0)`` immediately after to release the
         process.

    Returns the :class:`KeepAliveVerdict` so callers can inspect or log.
    Idempotent — safe to call once per startup. The bootout subprocess
    failure does not raise; verdict carries reason for forensics.
    """
    if label is None:
        ctx = detect_launchd_context()
        label = ctx.label
    verdict = check_keepalive_guard(
        label=label, window_sec=window_sec,
        threshold=threshold, now=now,
    )
    if verdict.should_self_bootout and bootout_on_loop and verdict.label:
        ok = request_self_bootout(verdict.label)
        log.warning(
            "daemon_guard[%s]: crash-loop detected (%s); bootout %s",
            verdict.label, verdict.reason,
            "issued" if ok else "FAILED",
        )
    return verdict


def request_self_bootout(label: str, *, timeout: float = 10.0) -> bool:
    """Best-effort ``launchctl bootout gui/$UID/<label>``.

    Returns True on rc=0, False on any failure. Never raises.
    Caller should call this BEFORE actually exiting so launchd does
    not respawn the daemon.
    """
    if not label:
        return False
    uid = os.geteuid()
    target = f"gui/{uid}/{label}"
    try:
        result = subprocess.run(
            ["launchctl", "bootout", target],
            capture_output=True, text=True, timeout=timeout, check=False,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
        log.warning("launchd_guard: bootout failed (%s)", exc)
        return False
    except Exception as exc:  # noqa: BLE001 defensive
        log.warning("launchd_guard: bootout crashed (%s)", exc)
        return False
    if result.returncode != 0:
        log.warning(
            "launchd_guard: launchctl bootout %s rc=%s stderr=%r",
            target, result.returncode, (result.stderr or "")[:200],
        )
        return False
    return True
