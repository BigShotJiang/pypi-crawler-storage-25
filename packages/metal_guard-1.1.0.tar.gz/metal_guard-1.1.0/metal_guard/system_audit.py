"""System / hardware probes — wired-limit, GPU driver version, Apple GPU family, bench-scoped load."""

from __future__ import annotations

import datetime
import gc
import glob
import json
import logging
import multiprocessing
import os
import pathlib
import re
import shutil
import signal
import sys
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from multiprocessing.connection import Connection
from pathlib import Path
from typing import Any, Callable, Generator, Iterator, Tuple, TypeVar

from metal_guard._constants import log
from metal_guard.mlx_lock import acquire_mlx_lock, release_mlx_lock

# ---------------------------------------------------------------------------
# Layer 5: bench_scoped_load — sequential benchmark harness guard (v0.5.0)
# ---------------------------------------------------------------------------
# Layers 1-4 target concurrency and stale-thread hazards. They do NOT
# protect a single-threaded, single-process harness that loads 4+ large
# MLX models sequentially within one Python lifetime — the scenario
# where residual Metal driver buffer accounting drifts above the working
# set recommended limit and triggers an IOGPUMemory.cpp:492 kernel panic.
#
# L5 closes that gap via ``bench_scoped_load``: every entry acquires
# the cross-process lock and loads fresh; every exit runs safe_cleanup +
# extra cooldown + post-unload memory verification.
#
# Empirical: Metal lazy release needs ~8s on 64GB Apple Silicon after
# unloading a 24GB model before the buffer pool pages return to the OS.
# safe_cleanup's internal 1s cooldown is insufficient; 8s lets the OS
# reclaimer catch up in almost all cases.

_BENCH_POST_UNLOAD_COOLDOWN_SEC = 8.0

# ---------------------------------------------------------------------------
# System-level audits (R2 / R3 — 2026-04-15)
# ---------------------------------------------------------------------------
#
# Read-only audits of the runtime host that can be correlated with known
# kernel-panic patterns. Purely informational — results are logged at
# startup and exposed via dashboard endpoints; nothing here changes
# system state.

_WIRED_LIMIT_WARN_RATIO = 0.85


def _sysctl(name: str, *, timeout: float = 2.0) -> str | None:
    """Run ``sysctl -n <name>`` and return stdout stripped, or None on failure."""
    import subprocess
    try:
        out = subprocess.run(
            ["sysctl", "-n", name],
            capture_output=True, text=True, timeout=timeout, check=False,
        )
    except (subprocess.SubprocessError, OSError) as exc:
        log.debug("sysctl -n %s failed: %s", name, exc)
        return None
    if out.returncode != 0:
        return None
    return out.stdout.strip() or None


def audit_wired_limit() -> dict[str, Any]:
    """Audit the ``iogpu.wired_limit_mb`` sysctl for panic-prone values.

    Returns a dict with keys ``limit_mb`` / ``total_gb`` / ``ratio`` /
    ``mode`` (``"default"`` | ``"override"`` | ``"unknown"``) / ``advisory``.

    Rationale: mlx-lm maintainer ``angeloskath`` commented on issue
    ``ml-explore/mlx-lm#1047`` that IOGPUFamily kernel panics are often
    correlated with too-high wired-memory overrides. Values >
    ``_WIRED_LIMIT_WARN_RATIO`` (85%) of physical memory stress the
    allocator path implicated in the #3186 panic signature.

    Never raises. Subprocess failures return ``mode="unknown"``.
    """
    raw_limit = _sysctl("iogpu.wired_limit_mb")
    raw_total = _sysctl("hw.memsize")

    limit_mb: int | None = None
    if raw_limit is not None:
        try:
            limit_mb = int(raw_limit)
        except ValueError:
            pass

    total_gb: float | None = None
    if raw_total is not None:
        try:
            total_gb = int(raw_total) / (1024 ** 3)
        except ValueError:
            pass

    if limit_mb is None or total_gb is None or total_gb <= 0:
        return {
            "limit_mb": limit_mb,
            "total_gb": total_gb,
            "ratio": 0.0,
            "mode": "unknown",
            "advisory": None,
        }

    if limit_mb == 0:
        return {
            "limit_mb": 0,
            "total_gb": total_gb,
            "ratio": 0.0,
            "mode": "default",
            "advisory": None,
        }

    ratio = (limit_mb / 1024.0) / total_gb
    advisory: str | None = None
    if ratio > _WIRED_LIMIT_WARN_RATIO:
        advisory = (
            f"iogpu.wired_limit_mb={limit_mb}MB is {ratio:.0%} of "
            f"{total_gb:.0f}GB unified memory. Too-high overrides have "
            f"been correlated with IOGPUFamily kernel panics "
            f"(mlx-lm#1047 maintainer comment). Consider: "
            f"sudo sysctl iogpu.wired_limit_mb=0 to return to Apple "
            f"default, or pick a value < "
            f"{int(total_gb * _WIRED_LIMIT_WARN_RATIO * 1024)}MB."
        )

    return {
        "limit_mb": limit_mb,
        "total_gb": total_gb,
        "ratio": ratio,
        "mode": "override",
        "advisory": advisory,
    }


def read_gpu_driver_version(*, timeout: float = 3.0) -> str | None:
    """Return the ``IOGPUFamily`` kext bundle version, or None if unreadable.

    Panic reports on ``ml-explore/mlx#3186`` pin the fault to the
    ``com.apple.iokit.IOGPUFamily`` kext. Logging the driver revision
    at startup is useful forensic context for future crash correlation.

    Probes ``kextstat`` first; falls back to
    ``ioreg -rc IOGPUFamily -d 1`` CFBundleVersion. First non-empty
    reading wins. Never raises.
    """
    import subprocess
    try:
        out = subprocess.run(
            ["kextstat"], capture_output=True, text=True,
            timeout=timeout, check=False,
        )
    except (subprocess.SubprocessError, OSError) as exc:
        log.debug("kextstat failed: %s", exc)
    else:
        if out.returncode == 0:
            for line in out.stdout.splitlines():
                if "com.apple.iokit.IOGPUFamily" not in line:
                    continue
                lo, _, _ = line.partition(")")
                _, _, rhs = lo.rpartition("(")
                version = rhs.strip()
                if version:
                    return version

    try:
        out = subprocess.run(
            ["ioreg", "-rc", "IOGPUFamily", "-d", "1"],
            capture_output=True, text=True, timeout=timeout, check=False,
        )
    except (subprocess.SubprocessError, OSError) as exc:
        log.debug("ioreg IOGPUFamily failed: %s", exc)
        return None
    if out.returncode != 0:
        return None
    for line in out.stdout.splitlines():
        if "CFBundleVersion" not in line:
            continue
        _, _, rhs = line.partition("=")
        value = rhs.strip().strip('"').strip()
        if value:
            return value
    return None


def log_system_audit_at_startup() -> dict[str, Any]:
    """Run all host-level audits and WARNING-log any advisory.

    Returns the combined audit dict. Intended for program entry points
    (CLI ``main()``, FastAPI lifespan) so operators see host-level
    stability warnings in routine logs.
    """
    wired = audit_wired_limit()
    kext = read_gpu_driver_version()

    if wired.get("advisory"):
        log.warning("system audit: %s", wired["advisory"])
    else:
        log.info(
            "system audit: wired_limit mode=%s limit_mb=%s total_gb=%s",
            wired.get("mode"), wired.get("limit_mb"), wired.get("total_gb"),
        )

    if kext:
        log.info("system audit: IOGPUFamily kext version=%s", kext)
    else:
        log.debug("system audit: IOGPUFamily kext version unreadable")

    return {
        "wired_limit": wired,
        "gpu_driver_version": kext,
    }


# Post-unload active memory above this threshold logs an informational
# message (not a failure). Metal's lazy page reclaimer only returns
# pages when the NEXT load() allocates — stale-looking memory here is
# expected behaviour, not a leak.
_BENCH_POST_UNLOAD_ACTIVE_LIMIT_GB = 4.0


@contextmanager
def bench_scoped_load(
    model_id: str,
    *,
    backend: str = "mlx",
) -> Iterator[Tuple[Any, Any]]:
    """Safe sequential model loading for long-running benchmark harnesses.

    MetalGuard Layer 5. Wraps ``mlx_lm.load`` / ``mlx_vlm.load`` so a
    harness that must load many large MLX models inside one Python
    process gets the full defensive stack — cross-process lock, thread
    registry via safe_cleanup, gc + mx.clear_cache + cooldown — on
    every iteration, plus post-unload memory-drop verification.

    Rationale: benchmark harnesses that bypass this library (calling
    ``mlx_lm.load`` + ``mlx_lm.generate`` directly in a loop) can drift
    above the working-set limit on 64GB Apple Silicon after loading 6+
    large models sequentially — residual Metal driver buffer accounting
    keeps stale allocations visible even after ``mx.clear_cache()``.
    This has been observed to trigger an IOGPUMemory.cpp:492
    ``completeMemory() prepare count underflow`` kernel panic.

    Usage::

        from metal_guard import bench_scoped_load

        for model_id in candidate_models:  # 8 large models
            with bench_scoped_load(model_id) as (model, tokenizer):
                score = run_eval(model, tokenizer, items)
                save_atomic_checkpoint(model_id, score)

    Parameters
    ----------
    model_id:
        Hugging Face model ID that ``mlx_lm.load`` / ``mlx_vlm.load`` accepts,
        e.g. ``"mlx-community/Mistral-Small-3.2-24B-Instruct-2506-8bit"``.
    backend:
        ``"mlx"`` / ``"mlx-lm"`` → text model via ``mlx_lm.load``.
        ``"mlx-vlm"`` → vision model via ``mlx_vlm.load``.

    Yields
    ------
    The ``(model, tokenizer)`` tuple returned by the underlying loader.

    Raises
    ------
    ValueError
        If ``backend`` is not a supported MLX backend.
    MLXLockConflict
        If another process already holds the MLX exclusive lock.

    Notes
    -----
    Does NOT replace Layers 1-4. It delegates to them and adds
    post-unload verification specific to sequential benchmark loops.
    """
    from metal_guard.guard import metal_guard

    metal_guard.breadcrumb(f"BENCH_SCOPED_LOAD: ENTER {model_id} backend={backend}")
    log.info("bench_scoped_load: entering %s (backend=%s)", model_id, backend)

    # R4 advisory (v0.7.0): if model has known dims, log prefill safety
    # envelope at 131 072 context so the caller sees which cells would
    # trip require_prefill_fit. Advisory only; never blocks load.
    try:
        _stats = metal_guard.memory_stats()
        from metal_guard import describe_prefill_plan  # noqa: PLC0415 — lazy avoids cycle
        _plan = describe_prefill_plan(
            context_tokens=131072, model_id=model_id,
            available_gb=_stats.available_gb if _stats.limit_bytes > 0 else None,
        )
        if _plan["dims_known"]:
            if _plan["fits_ceiling"] is False:
                log.warning(
                    "bench_scoped_load: %s at 131k ctx would alloc ~%s GB "
                    "> 5 GB ceiling — R4 will refuse; recommend chunk=%s",
                    model_id, _plan["peak_alloc_gb"],
                    _plan["recommended_chunk_size"],
                )
            else:
                log.info(
                    "bench_scoped_load: %s prefill plan OK at 131k "
                    "(peak ~%s GB)", model_id, _plan["peak_alloc_gb"],
                )
    except Exception as _exc:
        log.debug("bench_scoped_load: prefill plan advisory failed: %s", _exc)

    # Acquire cross-process lock for the entire bench scope (load + yield + unload).
    # Unlike per-call acquisition, bench holds the lock across multiple
    # generate() calls on the same model — preventing other processes from
    # loading a competing model mid-benchmark.
    acquire_mlx_lock("bench_scoped_load")

    # Direct load. In bench scope we manage the full lifecycle
    # (load → yield → unload) sequentially, and Metal's lazy page reclaimer
    # only returns stale pages to the OS when the next load() actually
    # allocates. Pre-checking memory_stats() here would report stale pages
    # as "active" and incorrectly block legitimate back-to-back loads of
    # 25GB+ models on 64GB machines.
    if backend in ("mlx", "mlx-lm"):
        from mlx_lm import load as _mlx_load
        metal_guard.breadcrumb(f"BENCH_SCOPED_LOAD: direct load {model_id}")
        loaded = _mlx_load(model_id)
    elif backend == "mlx-vlm":
        from mlx_vlm import load as _vlm_load
        metal_guard.breadcrumb(f"BENCH_SCOPED_LOAD: direct vlm load {model_id}")
        loaded = _vlm_load(model_id)
    else:
        release_mlx_lock()
        raise ValueError(
            f"bench_scoped_load: unsupported backend {backend!r} "
            f"(expected 'mlx', 'mlx-lm', or 'mlx-vlm')"
        )

    try:
        yield loaded
    finally:
        metal_guard.breadcrumb(
            f"BENCH_SCOPED_LOAD: EXIT {model_id} — unloading + cooldown"
        )
        log.info("bench_scoped_load: exiting %s, unloading", model_id)

        # Full cleanup: wait_for_threads + gc + flush_gpu + internal cooldown.
        metal_guard.safe_cleanup()
        gc.collect()

        # Reset peak tracker so the NEXT iteration's memory_stats().peak_gb
        # reflects only that model, not a stale high-water mark from a
        # previous large model that Metal hasn't fully released yet.
        try:
            import mlx.core as mx
            mx.reset_peak_memory()
        except (ImportError, AttributeError):
            pass

        time.sleep(_BENCH_POST_UNLOAD_COOLDOWN_SEC)

        # Diagnostic only: Metal lazy release means active memory may still
        # report high here — the pages are reclaimed when the NEXT load()
        # allocates. This is informational, not load-blocking.
        stats = metal_guard.memory_stats()
        active_after_gb = stats.active_gb
        if active_after_gb > _BENCH_POST_UNLOAD_ACTIVE_LIMIT_GB:
            log.info(
                "bench_scoped_load: %s active memory %.1fGB after unload "
                "(expected eventually < %.1fGB via Metal lazy release on next load)",
                model_id, active_after_gb, _BENCH_POST_UNLOAD_ACTIVE_LIMIT_GB,
            )
        metal_guard.breadcrumb(
            f"BENCH_SCOPED_LOAD: EXIT {model_id} done, active={active_after_gb:.1f}GB"
        )
        log.info(
            "bench_scoped_load: exited %s, active memory %.1fGB peak %.1fGB",
            model_id, active_after_gb, stats.peak_gb,
        )
        release_mlx_lock()


_APPLE_GPU_FAMILY_MAP = {
    "applegpu_g13": "M1",       # M1 base / Pro / Max / Ultra (g13/g13c/g13d/g13s)
    "applegpu_g14": "M2",       # M2 base / Pro / Max / Ultra
    "applegpu_g15": "M3",       # M3 base / Pro / Max / Ultra
    "applegpu_g16": "M4",       # M4 base / Pro / Max
    "applegpu_g17": "M5",       # M5 base / Pro / Max (g17/g17s, mlx-lm#1206)
}


def _classify_gpu_family(architecture: str) -> str:
    """Map architecture string (e.g. ``applegpu_g13d``) → family (``M1``).

    Returns the architecture string itself when no prefix matches — caller
    should treat as ``"unknown"``-class without raising. Empty/None → "unknown".
    """
    arch = (architecture or "").strip().lower()
    if not arch:
        return "unknown"
    for prefix, family in _APPLE_GPU_FAMILY_MAP.items():
        if arch.startswith(prefix):
            return family
    return arch


def apple_gpu_family() -> dict[str, Any]:
    """Return Apple GPU family info from ``mlx.core.device_info()``.

    Falls back to graceful no-op dict when MLX isn't importable. Never
    raises into caller — diagnostic only.

    Schema::

        {
          "available": bool,
          "device_name": str | None,           # e.g. "Apple M1 Ultra"
          "architecture": str | None,          # e.g. "applegpu_g13d"
          "family": str,                       # "M1" / ... / "M5" / "unknown"
          "resource_limit_descriptors": int | None,  # mlx-lm#1185 limit
          "max_buffer_length_gb": float | None,
          "max_recommended_working_set_gb": float | None,
          "memory_size_gb": float | None,
          "error": str | None,                 # only on failure
        }
    """
    out: dict[str, Any] = {
        "available": False,
        "device_name": None,
        "architecture": None,
        "family": "unknown",
        "resource_limit_descriptors": None,
        "max_buffer_length_gb": None,
        "max_recommended_working_set_gb": None,
        "memory_size_gb": None,
    }
    try:
        import mlx.core as mx  # type: ignore[import-not-found]
    except ImportError as exc:
        out["error"] = f"mlx.core import failed: {exc}"
        return out
    except Exception as exc:  # noqa: BLE001 — cooldown env may be wedged
        out["error"] = f"mlx.core import error: {type(exc).__name__}: {exc}"
        return out

    try:
        info = mx.device_info()
    except Exception as exc:  # noqa: BLE001
        out["error"] = f"mx.device_info failed: {type(exc).__name__}: {exc}"
        return out

    out["available"] = True
    out["device_name"] = info.get("device_name")
    out["architecture"] = info.get("architecture")
    out["family"] = _classify_gpu_family(info.get("architecture", ""))
    out["resource_limit_descriptors"] = info.get("resource_limit")
    if "max_buffer_length" in info:
        out["max_buffer_length_gb"] = round(info["max_buffer_length"] / 1e9, 2)
    if "max_recommended_working_set_size" in info:
        out["max_recommended_working_set_gb"] = round(
            info["max_recommended_working_set_size"] / 1e9, 2,
        )
    if "memory_size" in info:
        out["memory_size_gb"] = round(info["memory_size"] / 1e9, 2)
    return out
