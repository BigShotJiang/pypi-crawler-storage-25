"""ModelCache — MLX model load + cache with Metal-safe lifecycle.

Caches loaded mlx-lm / mlx-vlm models and delegates all Metal GPU
cleanup to MetalGuard so repeated load/unload cycles do not trip the
IOGPUFamily driver panic.
"""

from __future__ import annotations

import time

from metal_guard import metal_guard
from metal_guard._constants import log


# ── Model Cache ──────────────────────────────────────────────────────────────


class ModelCache:
    """Manages MLX model lifecycle with explicit state."""

    def __init__(self) -> None:
        self._text: dict[str, tuple] = {}
        self._vision: dict[str, tuple] = {}

    def get_text(self, key: str) -> tuple | None:
        return self._text.get(key)

    def set_text(self, key: str, value: tuple) -> None:
        self._text[key] = value

    def get_vision(self, key: str) -> tuple | None:
        return self._vision.get(key)

    def set_vision(self, key: str, value: tuple) -> None:
        self._vision[key] = value

    def clear(self) -> None:
        """Unload all models and free Metal GPU memory.

        Short-circuits when no models are cached — avoids unnecessary Metal
        GPU initialization that can trigger IOGPUFamily driver panics.
        Delegates all Metal cleanup to MetalGuard.safe_cleanup().
        """
        had_models = bool(self._text) or bool(self._vision)
        metal_guard.breadcrumb("CLEAR: dict.clear() START")
        self._text.clear()
        self._vision.clear()
        if not had_models:
            metal_guard.breadcrumb("CLEAR: no models loaded, skipping Metal cleanup")
            return
        metal_guard.safe_cleanup()


# Module-level singleton
_model_cache = ModelCache()


# ── Memory Management ────────────────────────────────────────────────────────


def _check_metal_memory(model_name: str) -> None:
    """Check Metal memory before loading a model.

    Uses MetalGuard for memory stats and cleanup.  If active memory exceeds
    75% after two cleanup attempts, raises MemoryError.
    """
    metal_guard.wait_for_threads()
    metal_guard.log_memory("before loading", model_name)

    # Peak pressure check (fragmented buffers)
    metal_guard.ensure_headroom(model_name, threshold_pct=60.0)

    # Active memory check — if truly full, aggressive cleanup
    for attempt in range(2):
        stats = metal_guard.memory_stats()
        if not stats.limit_bytes:
            return
        if stats.active_pct <= 75:
            return  # Safe to load

        if attempt == 0:
            log.warning(
                "Metal active memory at %.0f%% — proactively unloading before %s",
                stats.active_pct, model_name,
            )
            _model_cache.clear()
            time.sleep(5)
            try:
                import mlx.core as mx
                mx.reset_peak_memory()
            except (ImportError, AttributeError):
                pass
            continue  # Re-check

        raise MemoryError(
            f"Metal memory still at {stats.active_pct:.0f}% after cleanup. "
            f"Cannot safely load {model_name} (active={stats.active_gb:.1f}GB, "
            f"limit={stats.limit_gb:.0f}GB)"
        )


# ── Model Loading ────────────────────────────────────────────────────────────


# Extra cooldown (beyond safe_cleanup's internal sleep) to give Metal time
# to return buffers to the OS after a full cache clear. Apple Metal's lazy
# release means even after unload_all() + gc + flush, the resident memory
# may take several seconds to drop. 5s is empirical — shorter values leave
# the next large-model load failing by ~1-2GB.
# Empirical: a ~24GB mistral load was blocked by stale ~26.8GB resident memory.
_ESCALATED_COOLDOWN_SEC = 5.0


def _ensure_fit_before_load(model_name: str) -> None:
    """Predictive memory gate, delegating escalated retry to MetalGuard v0.2.3.

    Model-agnostic: driven entirely by runtime size estimation so swapping
    models requires no code changes (size estimation is name-driven). The
    ``estimated_gb is None`` branch falls back to the legacy threshold
    check for exotic names the estimator can't parse.

    MetalGuard 0.2.3's ``require_fit`` now handles the two-tier retry
    internally when we pass ``cache_clear_cb`` + ``escalated_cooldown_sec``
    — we just tell it to clear our Python-side ModelCache dict on the
    escalated path and how long to sleep for Metal's lazy release.
    """
    estimated_gb = metal_guard.estimate_model_size_from_name(model_name)
    if estimated_gb is None:
        _check_metal_memory(model_name)
        return

    metal_guard.require_fit(
        estimated_gb,
        model_name=model_name,
        cache_clear_cb=_model_cache.clear,
        escalated_cooldown_sec=_ESCALATED_COOLDOWN_SEC,
    )


def get_mlx_model(model_name: str) -> tuple:
    """Load and cache MLX text model."""
    cached = _model_cache.get_text(model_name)
    if cached is not None:
        return cached
    _ensure_fit_before_load(model_name)
    from mlx_lm import load as mlx_load
    metal_guard.breadcrumb(f"LOAD: {model_name} START")
    log.info("Loading MLX text model: %s", model_name)
    loaded = mlx_load(model_name)
    _model_cache.set_text(model_name, loaded)
    metal_guard.breadcrumb(f"LOAD: {model_name} DONE")
    log.info("MLX text model loaded: %s", model_name)
    return loaded


def get_mlx_vlm_model(model_name: str) -> tuple:
    """Load and cache MLX vision model."""
    cached = _model_cache.get_vision(model_name)
    if cached is not None:
        return cached
    _ensure_fit_before_load(model_name)
    from mlx_vlm import load as vlm_load
    metal_guard.breadcrumb(f"LOAD_VLM: {model_name} START")
    log.info("Loading MLX vision model: %s", model_name)
    loaded = vlm_load(model_name)
    _model_cache.set_vision(model_name, loaded)
    metal_guard.breadcrumb(f"LOAD_VLM: {model_name} DONE")
    log.info("MLX vision model loaded: %s", model_name)
    return loaded


# ── Public Cleanup API ───────────────────────────────────────────────────────


def unload_all() -> None:
    """Release all cached models and force Metal GPU memory reclamation.

    Delegates thread safety and GPU cleanup to MetalGuard.
    """
    metal_guard.breadcrumb("UNLOAD_ALL: START")
    metal_guard.wait_for_threads()
    _model_cache.clear()
    metal_guard.breadcrumb("UNLOAD_ALL: DONE")
    log.info("All cached models unloaded + Metal cache cleared")


def flush_kv_cache() -> None:
    """Flush KV cache without unloading models.

    Lightweight cleanup between generate calls (~50ms vs ~2s for unload_all).
    """
    metal_guard.wait_for_threads()
    metal_guard.flush_gpu()


def check_metal_pressure() -> None:
    """Lightweight pressure check for use inside scoring loops.

    Flushes cache and resets peak when pressure > 80%.
    """
    metal_guard.wait_for_threads()
    stats = metal_guard.memory_stats()
    if not stats.limit_bytes:
        return
    if stats.peak_pct > 90:
        log.warning(
            "Metal peak pressure %.0f%% (%.1fGB/%.0fGB) — flushing + cooldown",
            stats.peak_pct, stats.peak_gb, stats.limit_gb,
        )
        metal_guard.flush_gpu()
        try:
            import mlx.core as mx
            mx.reset_peak_memory()
        except (ImportError, AttributeError):
            pass
        time.sleep(1)
    elif stats.peak_pct > 80:
        log.info("Metal peak pressure %.0f%% — flushing cache", stats.peak_pct)
        metal_guard.flush_gpu()
        try:
            import mlx.core as mx
            mx.reset_peak_memory()
        except (ImportError, AttributeError):
            pass
