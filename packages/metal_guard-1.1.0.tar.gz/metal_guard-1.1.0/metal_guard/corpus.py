"""corpus — append-only incident log for cross-stage forensics.

Append-only single source of truth for "what happened" in the GPU-panic
ecosystem. Modules emit small JSON events; downstream tools (autopsy,
dashboards, post-mortem helpers) consume them.

Path: ``~/.cache/metal-guard/events.jsonl``
Override: ``METALGUARD_PANIC_CORPUS_PATH`` env (test fixture / relocation)
Disable: ``METALGUARD_PANIC_CORPUS_DISABLED=1``

Schema (one JSON object per line, ``ensure_ascii=False`` UTF-8)::

    {
      "ts":         "2026-05-02T23:15:00",   # local-time isoformat seconds
      "event":      "spawn_refused",         # see EVENT_KINDS
      "model_id":   "mlx-community/...",     # optional
      "gpu_family": "M1",                    # optional
      "tier":       "panic",                 # optional
      "extra":      {...}                    # caller-defined dict
    }

Design rules:

- **Best-effort**: ``append_event`` NEVER raises to caller. A broken
  corpus must not break the panic gate / spawn gate.
- **Atomic single-write**: ``os.write`` with ``O_APPEND`` is atomic for
  payloads ≤ PIPE_BUF (4096B on macOS). Records are typically <1KB so
  one event = one atomic line. fsync forces durability.
- **Append-only**: no rotation, no truncation in this module. Operators
  rotate via launchd / cron when file exceeds size threshold.
- **Read-back portable**: ``iter_events`` skips malformed lines so an
  abrupt power-loss mid-write never poisons the iterator.
"""
from __future__ import annotations

import json
import os
from collections.abc import Iterator
from datetime import datetime
from pathlib import Path
from typing import Any

from metal_guard._constants import log

# Public constants (overridable in tests via monkeypatch).
DEFAULT_CORPUS_PATH = "~/.cache/metal-guard/events.jsonl"
_CORPUS_PATH_ENV = "METALGUARD_PANIC_CORPUS_PATH"
_CORPUS_DISABLED_ENV = "METALGUARD_PANIC_CORPUS_DISABLED"

# Canonical event kinds — any other string is allowed (forward-compat
# for new wire points) but these are the documented ones for autopsy.
EVENT_KINDS: frozenset[str] = frozenset({
    "panic_observed",     # panic_cooldown detected new IOGPU panic
    "ack_written",        # ack_panic_lockout(reason=...) success
    "ack_rejected",       # ack_panic_lockout raised ValueError on bad reason
    "spawn_refused",      # subprocess_runner SpawnRefused raised
    "spawn_override",     # METALGUARD_LOCAL_PANIC_MODEL_BLOCK_DISABLED=1 path
    "cooldown_active",    # gate returned exit_code=2 (informational)
    "sentinel_marked",    # mark_sentinel_cooldown invoked
    # 2026-05-04 Wave A/B: prefill exposure tracker + worker_rotation
    "worker_high_water_prefill_recorded",  # prefill ≥ HIGH_WATER_TOKENS
    "worker_prefill_budget_exceeded",       # cumulative ≥ BUDGET_TOKENS
    "worker_rotation_recommended",          # should_rotate_worker verdict True
    # 2026-05-05 Phase 3 wire (subprocess_runner Phase 3 caller-side)
    "auto_rotation_started",          # call_model_isolated picked rotation
    "auto_rotation_completed",        # shutdown OK, fresh worker on next call
    "auto_rotation_shutdown_failed",  # shutdown raised; possible orphan
    "auto_rotation_race_noop",        # pool race — already rotated; legal no-op
    # Autopsy module-main path. The "autopsy_*" string values are retained
    # as forward-compat taxonomy labels — they name event kinds, not paths
    # or imports, so removing them would be a schema/BC break.
    "autopsy_run",
    "autopsy_skipped_panic_gate_lockout",
    # 2026-05-02 P1-2 safe_inference_shutdown
    "safe_shutdown_complete",
    # 2026-05-02 P1-1 oom_precheck
    "oom_precheck_blocked",
    "oom_precheck_warned",
    # MLX upgrade-gate CLI (pre-flight 5-step pipeline). The
    # "mlx_upgrade_gate_*" string values are retained as forward-compat
    # taxonomy labels — they name event kinds, not paths or imports, so
    # removing them would be a schema/BC break.
    "mlx_upgrade_gate_started",
    "mlx_upgrade_gate_step",
    "mlx_upgrade_gate_completed",
    "mlx_upgrade_gate_aborted",
    # 2026-05-09 Wave A Day 1-3 Spec #2 Done frame protocol
    "subprocess_no_done",         # parent recv timeout / EOFError / BrokenPipeError sans done frame
    "frame_protocol_mismatch",    # protocol_version missing or unknown
    "subprocess_malformed_done",  # done frame received but structurally invalid
    # 2026-05-09 Wave A Day 4-5 Spec #3 VRAM recovery short lockout
    "subprocess_crashed",         # recovery_lockout.trigger_crash_lockout entered
    "recovery_needed",            # caller-side wire signals lockout-driven retry path
    "worker_killed_for_lockout",  # lockout / panic_gate / atomic-ack revoked terminated worker
    # 2026-05-09 Wave A Day 6-7 Spec #5 Memory prediction load gate
    "load_gate_refused",          # predicted size + headroom > available VRAM
    "load_gate_skipped_unknown_vm",  # vm_stat AND system_profiler both parse-fail (safe-on-skip)
    # 2026-05-09 Wave A Day 8 Spec #6 Early child-death detection
    "subprocess_early_death",     # ≤200ms detect via Process.sentinel + select.select
    # 2026-05-09 Wave B Spec #4 Engine fallback chain
    "fallback_attempted",         # call_with_fallback per-tier attempt (success / skip / fail)
    "workload_chains_tampered",   # sha256 mismatch between live workload_chains.json and baseline
    # 2026-05-18 W4 display_guard
    "lora_display_advisory",      # display_guard: LoRA run while display active (mlx#3267)
})


def _resolve_path() -> Path:
    """Return the effective corpus file path, expanding ``~`` and env override."""
    raw = os.environ.get(_CORPUS_PATH_ENV) or DEFAULT_CORPUS_PATH
    return Path(os.path.expanduser(raw))


def append_event(
    event: str,
    *,
    model_id: str | None = None,
    gpu_family: str | None = None,
    tier: str | None = None,
    extra: dict[str, Any] | None = None,
    now: datetime | None = None,
) -> bool:
    """Append a single event line to the corpus. Best-effort, never raises.

    Returns True on success, False on any failure (corpus disabled, write
    error, encoding error, etc.). Failure is logged at DEBUG only — corpus
    visibility is itself an event-stream concern, not the caller's.

    Args:
        event: One of ``EVENT_KINDS`` or any custom string for forward-
            compatible wire points. Empty / non-string → False.
        model_id: HuggingFace model identifier (optional).
        gpu_family: e.g. ``"M1"`` (optional).
        tier: ``"panic"`` / ``"abort"`` / ``"degradation"`` (optional).
        extra: Caller-defined payload. Must be JSON-serialisable. Non-
            serialisable values silently degrade to repr() to keep the
            corpus open.
        now: Override timestamp (testing).
    """
    if os.environ.get(_CORPUS_DISABLED_ENV) == "1":
        return False
    if not isinstance(event, str) or not event:
        return False

    record: dict[str, Any] = {
        "ts": (now or datetime.now()).isoformat(timespec="seconds"),
        "event": event,
    }
    if model_id is not None:
        record["model_id"] = model_id
    if gpu_family is not None:
        record["gpu_family"] = gpu_family
    if tier is not None:
        record["tier"] = tier
    if extra:
        record["extra"] = extra

    try:
        data = (json.dumps(record, ensure_ascii=False, default=repr) + "\n").encode("utf-8")
    except (TypeError, ValueError) as exc:
        log.debug("corpus serialize failed: %s", exc)
        return False

    path = _resolve_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        # O_APPEND atomic for ≤ PIPE_BUF; fsync for durability across reboot.
        fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
        try:
            os.write(fd, data)
            os.fsync(fd)
        finally:
            os.close(fd)
    except OSError as exc:
        log.debug("corpus append failed: %s", exc)
        return False
    return True


def emit_event(
    *,
    event_kind: str,
    payload: dict[str, Any] | None = None,
    model_id: str | None = None,
    gpu_family: str | None = None,
    tier: str | None = None,
    now: datetime | None = None,
) -> bool:
    """Keyword-only alias around ``append_event`` with ``event_kind``/``payload`` names.

    Some callers prefer this signature for clarity: ``event_kind`` mirrors
    the ``EVENT_KINDS`` frozenset semantic; ``payload`` is the structured
    extra dict. Same best-effort guarantee — never raises.
    """
    return append_event(
        event_kind,
        model_id=model_id,
        gpu_family=gpu_family,
        tier=tier,
        extra=payload,
        now=now,
    )


def iter_events(since: datetime | None = None) -> Iterator[dict[str, Any]]:
    """Iterate corpus events, optionally filtered by timestamp.

    Malformed JSON lines are silently skipped so abrupt-stop writes
    (power loss mid-line) cannot break the reader. ``since`` filter is
    applied after parse so unparseable rows do not affect cutoff.
    """
    path = _resolve_path()
    if not path.exists():
        return
    try:
        # encoding="utf-8" matches writer; errors="replace" defends against
        # rare half-byte writes (shouldn't happen with single os.write but
        # cheap insurance).
        with open(path, encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if not isinstance(rec, dict):
                    continue
                if since is not None:
                    raw_ts = rec.get("ts")
                    if not isinstance(raw_ts, str):
                        continue
                    try:
                        rec_ts = datetime.fromisoformat(raw_ts)
                    except ValueError:
                        continue
                    if rec_ts < since:
                        continue
                yield rec
    except OSError as exc:
        log.debug("corpus read failed: %s", exc)


def count_events(*, event: str | None = None, since: datetime | None = None) -> int:
    """Convenience counter for autopsy / dashboards."""
    n = 0
    for rec in iter_events(since=since):
        if event is None or rec.get("event") == event:
            n += 1
    return n
