"""Apple panic-report parse/ingest, feedback formatter, circuit breaker, inference guards."""
from __future__ import annotations

import json
import os
import re
import time
from contextlib import contextmanager
from typing import Any, Generator

from metal_guard._constants import log
from metal_guard.error_classifier import classify_mlx_error, ErrorClass
from metal_guard.guard import metal_guard
from metal_guard.cadence import require_cadence_clear, _is_gemma4_family


# ---------------------------------------------------------------------------
# R8 — Apple Feedback Assistant panic report formatter (2026-04-16)
# ---------------------------------------------------------------------------
#
# ``ml-explore/mlx#3186`` (FB22091885) is the canonical template Apple
# accepts for IOGPUFamily kernel panics. This function converts a
# forensics dict into a ready-to-paste Feedback Assistant report so
# operators don't hand-stitch it during a reboot recovery. Pure
# formatting, no I/O.


def format_panic_for_apple_feedback(
    forensics: dict[str, Any],
    *,
    include_breadcrumb: bool = True,
    max_breadcrumb_lines: int = 60,
) -> str:
    """Return a multi-line string ready to paste into Feedback Assistant.

    Expected ``forensics`` keys (all optional — missing values render
    as ``unknown``): ``panic_string``, ``panic_time``, ``hardware``,
    ``gpu_driver``, ``os_version``, ``kernel_version``, ``mlx_versions``,
    ``repro_steps``, ``breadcrumbs``, ``advisories``.
    """
    hw = forensics.get("hardware", {}) or {}
    panic = forensics.get("panic_string", "unknown")
    panic_time = forensics.get("panic_time", "unknown")
    kext = forensics.get("gpu_driver", "unknown")
    os_ver = forensics.get("os_version", "unknown")
    kernel = forensics.get("kernel_version", "unknown")
    repro = forensics.get("repro_steps", []) or []
    breadcrumbs = (
        forensics.get("breadcrumbs", []) or [] if include_breadcrumb else []
    )
    advisories = forensics.get("advisories", []) or []
    mlx_versions = forensics.get("mlx_versions", {}) or {}

    lines: list[str] = []
    lines.append(f"**PANIC STRING:** {panic}")
    lines.append(f"**TIME:** {panic_time}")
    lines.append("")

    lines.append("## System")
    lines.append(f"- Hardware: {hw.get('chip', 'unknown')} "
                 f"({hw.get('gpu_memory_gb', '?')} GB unified)")
    lines.append(f"- macOS: {os_ver}")
    lines.append(f"- Kernel: {kernel}")
    lines.append(f"- IOGPUFamily kext: {kext}")
    if mlx_versions:
        lines.append("- MLX stack:")
        for pkg, ver in sorted(mlx_versions.items()):
            lines.append(f"  - {pkg}: {ver}")
    lines.append("")

    lines.append("## Reproducer")
    if repro:
        for i, step in enumerate(repro, 1):
            lines.append(f"{i}. {step}")
    else:
        lines.append("(No reproducer supplied — see breadcrumb tail below)")
    lines.append("")

    if advisories:
        lines.append("## Active advisories at panic time")
        for a in advisories:
            sev = a.get("severity", "?")
            pkg = a.get("package", "?")
            ver = a.get("installed_version", "?")
            url = a.get("url", "")
            title = a.get("title", "")
            lines.append(f"- [{sev}] {pkg} {ver} — {title} ({url})")
        lines.append("")

    if include_breadcrumb and breadcrumbs:
        tail = breadcrumbs[-max_breadcrumb_lines:]
        lines.append(f"## Breadcrumb tail (last {len(tail)} lines)")
        lines.append("```")
        lines.extend(str(b).rstrip() for b in tail)
        lines.append("```")
        lines.append("")

    lines.append("## What MetalGuard observed")
    lines.append("MetalGuard is a Python-side defensive layer for MLX on "
                 "Apple Silicon. At the time of the panic it was enforcing "
                 "the defensive-mode MLX process lock, subprocess worker "
                 "isolation, prefill allocation guard, and per-request KV "
                 "growth tracking. The panic still occurred despite these "
                 "guards, which suggests an in-kernel IOGPUFamily state "
                 "issue rather than a Python-side race.")
    lines.append("")
    lines.append("## Related upstream issues")
    lines.append("- mlx#3186 (canonical IOGPUFamily panic)")
    lines.append("- mlx#3348 (CommandEncoder thread-local)")
    lines.append("- mlx#3346 (merged into #3186)")
    lines.append("- mlx-lm#1047 (wired_limit correlation)")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# L9 — Panic Report Ingest (2026-04-16)
# ---------------------------------------------------------------------------

_PANIC_REPORT_DIR = "/Library/Logs/DiagnosticReports"
# Modern macOS (Sequoia / macOS 15) moved kernel-panic logs toward
# /var/db/PanicReporter and emits .ips alongside legacy .panic. Scan all
# known locations when no explicit directory is given.
_PANIC_REPORT_DIRS = (
    "/Library/Logs/DiagnosticReports",                       # legacy system
    "/var/db/PanicReporter",                                 # modern (Sequoia+)
    os.path.expanduser("~/Library/Logs/DiagnosticReports"),  # per-user reports
)
_PANIC_FILE_SUFFIXES = (".panic", ".ips")
_PANIC_JSONL_PATH = os.path.expanduser("~/.cache/metal-guard/panics.jsonl")
_PANIC_CALENDAR_RE = re.compile(r"Calendar:\s*0x([0-9a-fA-F]+)\s+0x([0-9a-fA-F]+)")
_PANIC_PID_RE = re.compile(r"pid\s+(\d+):\s*\S+")
_PANIC_FILE_MAX_READ = 200_000  # chars — panic files can be 500k+, only need header + signatures


def _parse_panic_timestamp(text: str) -> float | None:
    """Extract ``Calendar: 0x<sec> 0x<usec>`` as float seconds-since-epoch."""
    m = _PANIC_CALENDAR_RE.search(text)
    if not m:
        return None
    try:
        sec = int(m.group(1), 16)
        usec = int(m.group(2), 16)
        return float(sec) + usec / 1_000_000.0
    except ValueError:
        return None


def _parse_panic_pid(text: str) -> int | None:
    m = _PANIC_PID_RE.search(text)
    if not m:
        return None
    try:
        return int(m.group(1))
    except ValueError:
        return None


def parse_panic_reports(
    directory: str | None = None,
    *,
    since_ts: float | None = None,
) -> list[dict[str, Any]]:
    """Scan kernel-panic reports and classify them.

    When ``directory`` is given, only that directory (and its ``Retired/``
    subdir) is scanned — backward compatible. When omitted, all known
    macOS panic-report locations in ``_PANIC_REPORT_DIRS`` are scanned.

    Both legacy ``.panic`` and modern ``.ips`` files are read. ``.ips``
    files are JSON but still plain text, so the existing text-signature
    classifier works unchanged; ``.ips`` files are only considered when
    the filename marks them as kernel/panic reports (an ordinary
    app-crash ``.ips`` is not a kernel panic).

    Silently skips directories it cannot read (admin-only paths are
    common on modern macOS). Callers should also inspect application-side
    panic text when available.
    """
    from metal_guard.error_classifier import detect_panic_signature

    if directory is not None:
        base_dirs: tuple[str, ...] = (directory,)
    else:
        base_dirs = _PANIC_REPORT_DIRS

    results: list[dict[str, Any]] = []
    scanned: set[str] = set()

    for base in base_dirs:
        for scan_dir in (base, os.path.join(base, "Retired")):
            if scan_dir in scanned:
                continue
            scanned.add(scan_dir)
            try:
                entries = sorted(os.listdir(scan_dir))
            except OSError:
                continue

            for name in entries:
                lname = name.lower()
                if not lname.endswith(_PANIC_FILE_SUFFIXES):
                    continue
                # .ips reports also cover ordinary app crashes — only a
                # kernel-panic .ips (its filename says so) counts here.
                if lname.endswith(".ips") and not (
                    "kernel" in lname or "panic" in lname
                ):
                    continue

                path = os.path.join(scan_dir, name)
                try:
                    with open(path, encoding="utf-8", errors="ignore") as fh:
                        text = fh.read(_PANIC_FILE_MAX_READ)
                except OSError:
                    continue

                ts = _parse_panic_timestamp(text)
                if ts is None:
                    try:
                        ts = os.path.getmtime(path)
                    except OSError:
                        continue
                if since_ts is not None and ts < since_ts:
                    continue

                signature, explanation = detect_panic_signature(text)
                results.append({
                    "ts": ts,
                    "signature": signature or "unknown",
                    "explanation": explanation,
                    "pid": _parse_panic_pid(text),
                    "source_file": path,
                })
    return results


def ingest_panics_jsonl(
    *,
    report_dir: str | None = None,
    jsonl_path: str | None = None,
) -> int:
    """Append any new panic records to the JSONL archive.

    Dedupes by ``source_file`` **and** ``(ts_bucket, pid)`` event key.
    Idempotent: repeated calls append zero new records once the archive
    catches up. Returns number of new records written. Never raises —
    best-effort; panic archival must never itself crash the caller.

    Note: this function scans only the single directory passed as
    ``report_dir`` (default: the legacy ``_PANIC_REPORT_DIR`` constant),
    not all locations in ``_PANIC_REPORT_DIRS``. Multi-directory ingest
    is out of scope for this function; use ``parse_panic_reports()``
    directly for that.
    """
    report_dir = report_dir or _PANIC_REPORT_DIR
    jsonl_path = os.path.expanduser(jsonl_path or _PANIC_JSONL_PATH)
    seen_paths: set[str] = set()
    seen_events: set[tuple[int, int | None]] = set()

    def _event_key(rec: dict[str, Any]) -> tuple[int, int | None]:
        """Deduplicate across multiple DiagnosticReports copies of the same
        panic (macOS writes both ``.contents.panic`` and
        ``panic-full-...`` for the most recent event — both parse to the
        same ts+pid).
        """
        ts = rec.get("ts")
        pid = rec.get("pid")
        ts_bucket = int(ts) if isinstance(ts, (int, float)) else 0
        return (ts_bucket, pid if isinstance(pid, int) else None)

    try:
        with open(jsonl_path, encoding="utf-8") as fh:
            for line in fh:
                try:
                    rec = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if not isinstance(rec, dict):
                    continue
                src = rec.get("source_file")
                if isinstance(src, str):
                    seen_paths.add(src)
                seen_events.add(_event_key(rec))
    except OSError:
        pass

    new_records: list[dict[str, Any]] = []
    for rec in parse_panic_reports(report_dir):
        if rec.get("source_file") in seen_paths:
            continue
        key = _event_key(rec)
        if key in seen_events:
            continue
        seen_events.add(key)
        new_records.append(rec)
    if not new_records:
        return 0

    dirname = os.path.dirname(jsonl_path)
    if dirname:
        try:
            os.makedirs(dirname, exist_ok=True)
        except OSError:
            pass

    try:
        with open(jsonl_path, "a", encoding="utf-8") as fh:
            for rec in new_records:
                fh.write(json.dumps(rec, sort_keys=True))
                fh.write("\n")
            fh.flush()
            os.fsync(fh.fileno())
    except OSError as exc:
        log.warning("ingest_panics_jsonl: write failed path=%s err=%s", jsonl_path, exc)
        return 0

    return len(new_records)


# ---------------------------------------------------------------------------
# L9 — Circuit Breaker (2026-04-16)
# ---------------------------------------------------------------------------


class MLXCooldownActive(RuntimeError):
    """Raised when MetalGuard refuses to spawn a worker during a cooldown.

    Callers should surface this (HTTP 503, task runner decline, CLI
    exit) rather than silently fall through — the kernel is in a bad
    state and another load is likely to panic the machine again.
    """

    def __init__(self, panic_count: int, window_sec: float, cooldown_until: float) -> None:
        self.panic_count = panic_count
        self.window_sec = window_sec
        self.cooldown_until = cooldown_until
        self.remaining_sec = max(0.0, cooldown_until - time.time())
        super().__init__(
            f"MLX cooldown active — {panic_count} panics in last "
            f"{window_sec / 3600:.0f}h. Retry in {self.remaining_sec:.0f}s "
            f"(until {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(cooldown_until))})."
        )


_BREAKER_STATE_PATH = os.path.expanduser("~/.cache/metal-guard/breaker.json")


class CircuitBreaker:
    """Refuse new MLX workers after repeated panics within a rolling window.

    Default policy: ≥2 kernel panics within **1h** → 1h cooldown. Tuned
    around the empirical observation that CadenceGuard (L9 sibling)
    already enforces ≥180s between same-model loads — so two panics
    within a single hour means cadence guard failed AND the kernel's
    IOGPU accounting is compromised. A wider window (e.g. 24h) was
    tried first but tripped chronically on a machine that averages
    ~1.4 panics/day over a week: over-defensive to the point of
    blocking all MLX work. The 1h window catches catastrophic
    clusters without punishing the steady-state background rate.

    Humans should still reboot + investigate after any cooldown trip.
    """

    def __init__(
        self,
        *,
        jsonl_path: str | None = None,
        state_path: str | None = None,
        window_sec: float = 3600,
        panic_threshold: int = 2,
        cooldown_sec: float = 3600,
    ) -> None:
        self._jsonl_path = os.path.expanduser(jsonl_path or _PANIC_JSONL_PATH)
        self._state_path = os.path.expanduser(state_path or _BREAKER_STATE_PATH)
        self._window = float(window_sec)
        self._threshold = int(panic_threshold)
        self._cooldown = float(cooldown_sec)

    def _load_state(self) -> dict[str, Any]:
        try:
            with open(self._state_path, encoding="utf-8") as fh:
                data = json.load(fh)
            return data if isinstance(data, dict) else {}
        except (OSError, json.JSONDecodeError):
            return {}

    def _save_state(self, data: dict[str, Any]) -> None:
        dirname = os.path.dirname(self._state_path)
        if dirname:
            try:
                os.makedirs(dirname, exist_ok=True)
            except OSError:
                return
        tmp = f"{self._state_path}.tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(data, fh, sort_keys=True)
                fh.flush()
                os.fsync(fh.fileno())
            os.replace(tmp, self._state_path)
        except OSError as exc:
            log.debug("CircuitBreaker save_state failed: %s", exc)

    def _recent_panic_count(self, now: float) -> int:
        cutoff = now - self._window
        count = 0
        try:
            with open(self._jsonl_path, encoding="utf-8") as fh:
                for line in fh:
                    try:
                        rec = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    ts = rec.get("ts") if isinstance(rec, dict) else None
                    if isinstance(ts, (int, float)) and ts >= cutoff:
                        count += 1
        except OSError:
            return 0
        return count

    def check(self, *, now: float | None = None) -> None:
        """Raise MLXCooldownActive if the breaker is currently tripped."""
        current = now if now is not None else time.time()
        state = self._load_state()
        cooldown_until = state.get("cooldown_until")
        if isinstance(cooldown_until, (int, float)) and cooldown_until > current:
            raise MLXCooldownActive(
                int(state.get("panic_count", self._threshold)),
                self._window,
                float(cooldown_until),
            )

        count = self._recent_panic_count(current)
        if count >= self._threshold:
            until = current + self._cooldown
            self._save_state({
                "cooldown_until": until,
                "panic_count": count,
                "entered_at": current,
                "window_sec": self._window,
                "threshold": self._threshold,
            })
            raise MLXCooldownActive(count, self._window, until)

    def clear(self) -> None:
        """Operator override — remove the current cooldown state."""
        try:
            os.remove(self._state_path)
        except OSError:
            pass

    def status(self, *, now: float | None = None) -> dict[str, Any]:
        current = now if now is not None else time.time()
        state = self._load_state()
        cooldown_until = state.get("cooldown_until")
        in_cooldown = isinstance(cooldown_until, (int, float)) and cooldown_until > current
        return {
            "in_cooldown": bool(in_cooldown),
            "cooldown_until": float(cooldown_until) if in_cooldown else None,
            "cooldown_remaining_sec": max(0.0, float(cooldown_until) - current) if in_cooldown else 0.0,
            "panic_threshold": self._threshold,
            "window_sec": self._window,
            "recent_panic_count": self._recent_panic_count(current),
        }


# ---------------------------------------------------------------------------
# B2 — subprocess_inference_guard (per-inference Metal flush)
# ---------------------------------------------------------------------------
#
# Background: if you use subprocess isolation for MLX inference (a common
# pattern to contain C++ crashes — see L7 in Harper's internal fork), the
# worker process runs ``gen_fn(...)`` in its own address space. Parent-
# process hooks such as ``mx.clear_cache()`` or post-generate
# ``mx.eval(result)`` do NOT reach the subprocess. Empirically this
# reproduces the ``IOGPUMemory.cpp:492 "completeMemory() prepare count
# underflow"`` kernel panic: the GPU command buffer is still in flight
# when the subprocess releases its memory, and Metal accounting drifts
# until the next load trips an underflow → kernel panic.
#
# See upstream reports:
#   - mlx-lm: ml-explore/mlx-lm#1128  (prefill guard design)
#   - mlx:    ml-explore/mlx#3186     (subprocess isolation guidance)
#   - mlx:    ml-explore/mlx#3346     (kernel panic reproducers)
#
# Fix: wrap every ``gen_fn`` call in the worker with this guard. Order:
#
#   PRE  — mx.clear_cache()          release prior iter's cached buffers
#   body — generate runs
#   POST — mx.synchronize()          block until GPU command buffer drained
#   POST — mx.clear_cache()          release this iter's buffers
#
# ``mx.synchronize()`` is chosen over ``mx.eval(result)`` because generate
# return types vary (``str`` for mlx-lm, ``GenerateResult`` for mlx-vlm).
# ``synchronize`` is return-type agnostic and semantically correct: wait
# for all pending GPU ops to complete.
#
# This API is a pure addition — no breaking changes. It is useful to any
# project doing subprocess-based MLX isolation; Harper's internal B1 fix
# ended a streak of 6 panics in 3 days after wiring this into the worker.
@contextmanager
def subprocess_inference_guard(model_id: str) -> Generator[None, None, None]:
    """Per-inference Metal flush for subprocess workers.

    Wrap each ``gen_fn(...)`` call inside your subprocess worker::

        from metal_guard import subprocess_inference_guard

        with subprocess_inference_guard(model_id):
            result = gen_fn(model, processor, prompt=..., ...)

    The guard is best-effort: if ``mlx.core`` cannot be imported (test
    environment without MLX) the context manager no-ops. PRE hook
    failures do NOT block the body — a broken guard is worse than no
    guard because it would silently stop all inference. POST hook
    failures are logged but never mask a body exception.

    Args:
        model_id: model identifier used only for breadcrumb forensics.
            A post-mortem of a kernel panic can grep the breadcrumb log
            for ``SUBPROC_PRE`` / ``SUBPROC_POST`` entries to confirm
            whether the guard was engaged on the fatal call.
    """
    try:
        import mlx.core as mx
    except ImportError:
        yield
        return
    except Exception as exc:
        log.warning(
            "subprocess_inference_guard: mlx.core import failed (%s); "
            "guard disabled for %s", exc, model_id,
        )
        yield
        return

    # PRE: release any cached buffers from the previous iteration before
    # starting the new generate. Best-effort — a failure here must not
    # block the body (see docstring rationale).
    try:
        mx.clear_cache()
    except Exception as exc:
        log.warning(
            "subprocess_inference_guard PRE clear_cache failed for %s: %s",
            model_id, exc,
        )
    try:
        metal_guard.breadcrumb(f"SUBPROC_PRE: {model_id}")
    except Exception as exc:
        log.debug(
            "subprocess_inference_guard PRE breadcrumb failed for %s: %s",
            model_id, exc,
        )

    try:
        yield
    finally:
        # POST: synchronize FIRST so the command buffer is fully drained
        # before we release the cache. Reversing this order reproduces
        # the IOGPUMemory.cpp:492 underflow this guard exists to prevent.
        try:
            mx.synchronize()
        except Exception as exc:
            log.warning(
                "subprocess_inference_guard POST synchronize failed for %s: %s",
                model_id, exc,
            )
        try:
            mx.clear_cache()
        except Exception as exc:
            log.warning(
                "subprocess_inference_guard POST clear_cache failed for %s: %s",
                model_id, exc,
            )
        try:
            metal_guard.breadcrumb(f"SUBPROC_POST: {model_id}")
        except Exception as exc:
            log.debug(
                "subprocess_inference_guard POST breadcrumb failed for %s: %s",
                model_id, exc,
            )


# ---------------------------------------------------------------------------
# v0.9.0 — Gemma-4 first-generate settle (C7, 2026-04-25)
# ---------------------------------------------------------------------------
#
# Empirical analysis of Harper's 8-panic timeline: 7 of 8 panics landed on
# the FIRST ``generate()`` call of a gemma-4 family model, within 7–66s of
# the worker becoming ready. Four pre-existing flush barriers (parent-side
# clear_cache, subprocess_inference_guard PRE, load barrier, shutdown
# barrier) failed to catch these — the race is between Metal command buffer
# completion on model load and the first forward pass.
#
# ``gemma4_generation_flush`` inserts a mandatory synchronize + clear_cache
# + sleep window between worker load and first generate. It is NOT a block:
# it cannot stop a panic that is already in flight at the kernel level.
# What it does is extend the settle window so the kernel has time to finish
# its own bookkeeping before the first user-space Metal allocation. In
# combination with cross-model cadence (v0.9.0 C5) it meaningfully reduces
# panic frequency on gemma-4 loads but does not eliminate it — see
# KNOWN_PANIC_MODELS for the escape hatch when metal-guard is not enough.
#
# Env knobs:
#   METALGUARD_GEMMA4_FIRSTGEN_DISABLED=1   -> disable entirely
#   METALGUARD_GEMMA4_FIRSTGEN_SLEEP_SEC    -> override sleep (default 3.0)
def gemma4_generation_flush(model_id: str, generate_call_count: int) -> None:
    """First-generate Metal settle window for the gemma-4 family.

    Call this immediately before the *first* ``generate()`` on a freshly
    loaded worker. Subsequent calls (``generate_call_count != 0``) are
    no-ops. Non-gemma-4 models are no-ops.

    The function performs a best-effort ``mx.synchronize()`` +
    ``mx.clear_cache()`` + ``time.sleep(3.0)``. All steps are optional;
    the function never raises and never blocks on failure of any step.

    Args:
        model_id: the model identifier to match against the gemma-4 family.
        generate_call_count: number of prior successful generate calls on
            this worker. ``0`` means this call will be the first.

    Renamed in v0.9.0 from ``gemma4_firstgen_guard`` — the name "guard"
    incorrectly suggested a block; the function is a flush + settle window,
    not a gate. If you need a gate, use :class:`CircuitBreaker` or
    :func:`require_cadence_clear`.
    """
    if os.environ.get("METALGUARD_GEMMA4_FIRSTGEN_DISABLED") == "1":
        return
    if generate_call_count != 0:
        return
    if not _is_gemma4_family(model_id):
        return

    try:
        import mlx.core as mx
    except ImportError:
        return
    except Exception as exc:
        log.warning(
            "gemma4_generation_flush: mlx.core import failed (%s); "
            "flush disabled for %s", exc, model_id,
        )
        return

    try:
        metal_guard.breadcrumb(f"GEMMA4_FLUSH: {model_id}")
    except Exception as exc:
        log.debug("gemma4_generation_flush breadcrumb PRE failed: %s", exc)

    try:
        mx.synchronize()
    except Exception as exc:
        # log.debug rather than warning: failures of the best-effort
        # flush are dominated by the kernel-panic signal itself.
        # Emitting warnings per-load produces log spam when the driver
        # is already in trouble.
        log.debug(
            "gemma4_generation_flush synchronize failed for %s: %s",
            model_id, exc,
        )
    try:
        mx.clear_cache()
    except Exception as exc:
        log.debug(
            "gemma4_generation_flush clear_cache failed for %s: %s",
            model_id, exc,
        )

    try:
        sleep_sec = float(
            os.environ.get("METALGUARD_GEMMA4_FIRSTGEN_SLEEP_SEC", "3.0")
        )
    except ValueError:
        sleep_sec = 3.0
    time.sleep(max(0.0, sleep_sec))

    try:
        metal_guard.breadcrumb(f"GEMMA4_FLUSH_DONE: {model_id}")
    except Exception as exc:
        log.debug("gemma4_generation_flush breadcrumb POST failed: %s", exc)
