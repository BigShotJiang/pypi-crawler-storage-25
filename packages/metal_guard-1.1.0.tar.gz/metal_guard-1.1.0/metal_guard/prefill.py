"""Prefill memory-budget math + KV-cache growth tracker."""

from __future__ import annotations

import datetime
import gc
import glob
import json
import logging
import multiprocessing
import os
import pathlib
import re
import shutil
import signal
import sys
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from multiprocessing.connection import Connection
from pathlib import Path
from typing import Any, Callable, Generator, Iterator, Tuple, TypeVar

from metal_guard._constants import log
from metal_guard.memory import MetalOOMError

# ---------------------------------------------------------------------------
# R4 + R7 — Prefill allocation guard (2026-04-16)
# ---------------------------------------------------------------------------
#
# Single-allocation ceiling guard: for context_tokens × model attention
# geometry, estimate the peak Metal buffer a prefill pass would need
# and refuse the load if it risks IOGPUFamily state corruption
# (mlx#3186 cluster). ``require_fit`` guards model weights;
# ``require_prefill_fit`` guards the single-pass attention tensor which
# scales quadratically with context.
#
# A 131 k context on a 32-head 4-bit model allocates a score tensor
# ~55 GB in one dispatch — IOGPUFamily panics even when the device
# has 60+ GB free. Hard-cap at 5 GB single-allocation by default.
# ``recommend_chunk_size`` (R7) answers "if a full prefill would blow,
# what chunk would fit?" via binary search.


@dataclass(frozen=True)
class ModelDims:
    """Attention geometry needed to estimate prefill peak allocation.

    GQA / MQA aware: ``n_kv_heads ≤ n_heads`` for grouped variants;
    ``n_kv_heads == n_heads`` for MHA.
    """

    n_layers: int
    n_heads: int
    n_kv_heads: int
    head_dim: int
    dtype_bytes: int = 2  # fp16 / bf16 default; 1 for int8, 0.5 for int4


# Curated table of popular Apple-Silicon-deployed model dimensions.
# Not a complete catalog — only well-known shapes likely to appear
# in real workloads. Users can extend at runtime by inserting into
# ``KNOWN_MODELS`` or passing dims directly to ``require_prefill_fit``.
#
# Sources: HuggingFace model cards + mlx-community repacks (2026-04-16).
KNOWN_MODELS: dict[str, ModelDims] = {
    "gemma-4-26b-a4b-it-4bit": ModelDims(n_layers=62, n_heads=16, n_kv_heads=16, head_dim=256),
    "gemma-4-e2b-it-4bit": ModelDims(n_layers=30, n_heads=8, n_kv_heads=4, head_dim=256),
    "gemma-4-e4b-it-4bit": ModelDims(n_layers=34, n_heads=16, n_kv_heads=8, head_dim=256),
    "gemma-4-31b-it-8bit": ModelDims(n_layers=48, n_heads=32, n_kv_heads=16, head_dim=256),
    "Mistral-Small-3.2-24B": ModelDims(n_layers=56, n_heads=32, n_kv_heads=8, head_dim=128),
    "pixtral-12b-4bit": ModelDims(n_layers=40, n_heads=32, n_kv_heads=8, head_dim=128),
    "Hermes-3-Llama-3.1-8B-4bit": ModelDims(n_layers=32, n_heads=32, n_kv_heads=8, head_dim=128),
    "LFM2-VL-3B-4bit": ModelDims(n_layers=24, n_heads=16, n_kv_heads=16, head_dim=128),
}


def lookup_dims(model_id: str) -> ModelDims | None:
    """Best-effort lookup by substring — ``mlx-community/<model>`` prefix ok."""
    basename = model_id.rsplit("/", 1)[-1]
    if basename in KNOWN_MODELS:
        return KNOWN_MODELS[basename]
    for key, dims in KNOWN_MODELS.items():
        if key in model_id:
            return dims
    return None


def estimate_prefill_peak_alloc_gb(
    *, context_tokens: int, dims: ModelDims,
) -> float:
    """Estimate peak single-allocation during prefill, in GB.

    Returns the larger of:

    * Per-layer attention score tensor
      ``n_heads × ctx × ctx × dtype_bytes`` (one fused dispatch)
    * Whole-model KV cache
      ``2 × n_layers × n_kv_heads × ctx × head_dim × dtype_bytes``

    Attention scores scale quadratically in context; KV linearly.
    Scores overtake KV around long contexts on deep models.
    Either can be what tips IOGPUFamily.
    """
    scores_bytes = dims.n_heads * context_tokens * context_tokens * dims.dtype_bytes
    kv_bytes = (
        2 * dims.n_layers * dims.n_kv_heads
        * context_tokens * dims.head_dim * dims.dtype_bytes
    )
    return max(scores_bytes, kv_bytes) / 1e9


def require_prefill_fit(
    *,
    context_tokens: int,
    dims: ModelDims,
    available_gb: float,
    single_alloc_ceiling_gb: float = 5.0,
    headroom_pct: float = 0.30,
) -> None:
    """Raise :class:`MetalOOMError` if a prefill pass risks kernel panic.

    Two fail paths:

    * ``peak > single_alloc_ceiling_gb`` — IOGPUFamily state corruption
      risk (``ml-explore/mlx#3186`` root cause). Hard cap regardless of
      total memory available.
    * ``peak > available_gb × (1 - headroom_pct)`` — not enough headroom
      for the actual generate pass + KV cache overhead + scratch.

    Never called on an unknown model (``dims`` is required). Caller
    responsibility to either ``lookup_dims(model_id)`` or pass dims;
    if dims are unknown, caller should ``log.info`` and skip.
    """
    peak = estimate_prefill_peak_alloc_gb(context_tokens=context_tokens, dims=dims)

    if peak > single_alloc_ceiling_gb:
        raise MetalOOMError(
            f"Prefill peak alloc {peak:.1f} GB > single-alloc ceiling "
            f"{single_alloc_ceiling_gb:.1f} GB at context={context_tokens}. "
            f"IOGPUFamily state corruption risk (mlx#3186). "
            f"Use recommend_chunk_size() for safe segmentation."
        )

    threshold = available_gb * (1.0 - headroom_pct)
    if peak > threshold:
        raise MetalOOMError(
            f"Prefill peak alloc {peak:.1f} GB > {threshold:.1f} GB "
            f"(available {available_gb:.1f} GB × {1 - headroom_pct:.0%} "
            f"headroom) at context={context_tokens}."
        )

    log.debug(
        "require_prefill_fit OK: peak=%.2f GB avail=%.1f GB ctx=%d",
        peak, available_gb, context_tokens,
    )


def recommend_chunk_size(
    *,
    context_tokens: int,
    dims: ModelDims,
    single_alloc_ceiling_gb: float = 4.0,
    min_chunk: int = 512,
) -> int:
    """Return a chunk size whose peak alloc estimate fits the ceiling.

    If the full ``context_tokens`` already fits, returns
    ``context_tokens`` unchanged. Otherwise binary-searches the largest
    chunk that satisfies ``estimate ≤ ceiling``.

    Purely advisory — metal-guard does not chunk on behalf of the
    caller. A batched prefill wrapper picks up the recommendation and
    does its own segmentation.

    Uses a tighter default ceiling (4 GB) than
    :func:`require_prefill_fit` (5 GB) so post-chunk slack remains for
    downstream dispatches.
    """
    if estimate_prefill_peak_alloc_gb(
        context_tokens=context_tokens, dims=dims,
    ) <= single_alloc_ceiling_gb:
        return context_tokens

    lo, hi = min_chunk, context_tokens
    while hi - lo > min_chunk:
        mid = (lo + hi) // 2
        if estimate_prefill_peak_alloc_gb(
            context_tokens=mid, dims=dims,
        ) <= single_alloc_ceiling_gb:
            lo = mid
        else:
            hi = mid
    return lo


def describe_prefill_plan(
    *,
    context_tokens: int,
    model_id: str | None = None,
    dims: ModelDims | None = None,
    available_gb: float | None = None,
) -> dict[str, Any]:
    """Dashboard-ready dict summarising prefill safety for a plan.

    Null-safe for unknown models — never raises. Keys::

        model_id / context_tokens / dims_known /
        peak_alloc_gb / fits_ceiling / fits_headroom /
        recommended_chunk_size / advisory
    """
    resolved_dims = dims
    if resolved_dims is None and model_id is not None:
        resolved_dims = lookup_dims(model_id)

    if resolved_dims is None:
        return {
            "model_id": model_id,
            "context_tokens": context_tokens,
            "dims_known": False,
            "peak_alloc_gb": None,
            "fits_ceiling": None,
            "fits_headroom": None,
            "recommended_chunk_size": None,
            "advisory": (
                "model dims unknown — add to KNOWN_MODELS to enable check"
            ),
        }

    peak = estimate_prefill_peak_alloc_gb(
        context_tokens=context_tokens, dims=resolved_dims,
    )
    fits_ceiling = peak <= 5.0
    fits_headroom: bool | None = None
    if available_gb is not None:
        fits_headroom = peak <= available_gb * 0.70

    advisory: str | None = None
    chunk: int | None = None
    if not fits_ceiling:
        chunk = recommend_chunk_size(
            context_tokens=context_tokens, dims=resolved_dims,
        )
        advisory = (
            f"peak {peak:.1f} GB > 5 GB ceiling — recommend chunk_size={chunk}"
        )
    elif fits_headroom is False:
        advisory = (
            f"peak {peak:.1f} GB > {available_gb * 0.70:.1f} GB headroom"
        )

    return {
        "model_id": model_id,
        "context_tokens": context_tokens,
        "dims_known": True,
        "peak_alloc_gb": round(peak, 3),
        "fits_ceiling": fits_ceiling,
        "fits_headroom": fits_headroom,
        "recommended_chunk_size": chunk,
        "advisory": advisory,
    }


# ---------------------------------------------------------------------------
# R5 — Per-request KV cumulative byte tracker (2026-04-16)
# ---------------------------------------------------------------------------
#
# ``MetalGuard.start_kv_cache_monitor`` watches *global* Metal pressure —
# which is late: a long-running request that steadily grows its KV
# cache can push the device past the IOGPUFamily threshold while the
# global metric still looks fine. Per-request tracking catches that
# specific request early, before the global metric crosses.
#
# Caller opts in; no automatic instrumentation. Pattern::
#
#     from metal_guard import kv_tracker
#     kv_tracker.start(request_id, ceiling_gb=10.0)
#     try:
#         for token in generate(...):
#             kv_tracker.add_bytes(request_id, bytes_for_this_step)
#             yield token
#     finally:
#         kv_tracker.finalize(request_id)


@dataclass
class _RequestRecord:
    """Mutable per-request state for :class:`KVGrowthTracker`."""

    ceiling_bytes: int
    cumulative_bytes: int = 0
    step_count: int = 0
    aborted: bool = False


@dataclass
class KVGrowthTracker:
    """Thread-safe registry of per-request KV growth.

    Not a singleton by type — callers that want a shared registry use
    the module-level :data:`kv_tracker`. Tests can construct their own
    to stay isolated.
    """

    def __post_init__(self) -> None:
        self._requests: dict[str, _RequestRecord] = {}
        self._lock = threading.Lock()

    def start(self, request_id: str, *, ceiling_gb: float = 20.0) -> None:
        """Begin tracking ``request_id``. Overwrites any stale entry."""
        if ceiling_gb <= 0:
            raise ValueError(f"ceiling_gb must be > 0, got {ceiling_gb}")
        with self._lock:
            self._requests[request_id] = _RequestRecord(
                ceiling_bytes=int(ceiling_gb * 1e9),
            )
        log.debug("kv_tracker: started %s ceiling=%.1f GB", request_id, ceiling_gb)

    def add_bytes(self, request_id: str, bytes_added: int) -> int:
        """Record ``bytes_added`` for ``request_id``.

        Returns new cumulative byte count. Raises
        :class:`MetalOOMError` if cumulative would exceed the ceiling;
        the record is marked ``aborted`` and future ``add_bytes`` calls
        re-raise immediately.

        Silently no-ops if ``request_id`` was never ``start``-ed — so
        opt-in instrumentation does not error out of the generate loop.
        """
        if bytes_added < 0:
            raise ValueError(f"bytes_added must be ≥ 0, got {bytes_added}")

        with self._lock:
            rec = self._requests.get(request_id)
            if rec is None:
                return 0
            if rec.aborted:
                self._raise_oom(request_id, rec)
            rec.cumulative_bytes += bytes_added
            rec.step_count += 1
            if rec.cumulative_bytes > rec.ceiling_bytes:
                rec.aborted = True
                self._raise_oom(request_id, rec)
            return rec.cumulative_bytes

    def finalize(self, request_id: str) -> dict[str, Any] | None:
        """Stop tracking; return the final record as a dict (or None)."""
        with self._lock:
            rec = self._requests.pop(request_id, None)
        if rec is None:
            return None
        log.debug(
            "kv_tracker: finalized %s cumulative=%.2f GB steps=%d aborted=%s",
            request_id, rec.cumulative_bytes / 1e9, rec.step_count, rec.aborted,
        )
        return {
            "request_id": request_id,
            "cumulative_gb": round(rec.cumulative_bytes / 1e9, 3),
            "ceiling_gb": round(rec.ceiling_bytes / 1e9, 3),
            "step_count": rec.step_count,
            "aborted": rec.aborted,
        }

    def snapshot(self) -> list[dict[str, Any]]:
        """Return currently tracked requests (dashboard helper)."""
        with self._lock:
            return [
                {
                    "request_id": rid,
                    "cumulative_gb": round(rec.cumulative_bytes / 1e9, 3),
                    "ceiling_gb": round(rec.ceiling_bytes / 1e9, 3),
                    "step_count": rec.step_count,
                    "aborted": rec.aborted,
                }
                for rid, rec in self._requests.items()
            ]

    @staticmethod
    def _raise_oom(request_id: str, rec: _RequestRecord) -> None:
        raise MetalOOMError(
            f"Request {request_id!r} KV cache "
            f"{rec.cumulative_bytes / 1e9:.1f} GB > ceiling "
            f"{rec.ceiling_bytes / 1e9:.1f} GB after {rec.step_count} steps. "
            f"Aborting to prevent Metal kernel panic."
        )


# Module-level shared instance for most callers.
kv_tracker = KVGrowthTracker()
