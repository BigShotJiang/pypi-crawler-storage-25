"""Early child-death detection.

Detects a subprocess crash mid-inference within ~100-200 ms via
``multiprocessing.Process.sentinel`` (a kernel-backed fd) + ``select.select``
polling both the sentinel and the parent end of the pipe simultaneously.

Race-free across the spawn / fork start methods and callable from
non-main threads — neither path uses ``signal.signal(SIGCHLD, ...)``,
which would race with multiprocessing's internal reaper and only works on
the main thread.

On detection it triggers ``recovery_lockout.trigger_crash_lockout`` and
emits a ``subprocess_early_death`` corpus event.

Public API:
    - ``SubprocessEarlyDeathError`` — raised when the child dies early.
    - ``poll_for_early_death(*, process, parent_recv_fd, timeout_sec) -> None``
      raises ``SubprocessEarlyDeathError`` on death; returns on timeout.
    - ``is_detector_enabled() -> bool`` — env ``MLX_EARLY_DEATH_DETECT=0``
      rolls the detector back to a no-op.

Detection paths (event payload ``detection_path``):
    - ``"sigchld"`` — sentinel fd ready (kernel-signalled process death).
    - ``"pipe_eof"`` — parent end of the pipe ready and child end closed.

Env vars:
    - ``MLX_EARLY_DEATH_DETECT`` (default ``"1"``) — ``"0"`` disables.
    - ``MLX_EARLY_DEATH_POLL_INTERVAL_MS`` (default 100).
"""
from __future__ import annotations

import os
import select
import signal
import time
from typing import Any

from metal_guard import corpus
from metal_guard import recovery_lockout
from metal_guard._constants import log

_DEFAULT_POLL_INTERVAL_MS = 100


class SubprocessEarlyDeathError(RuntimeError):
    """Raised by ``poll_for_early_death`` when child process dies before done frame.

    Attributes:
        detection_path: ``"sigchld"`` (sentinel fd) or ``"pipe_eof"`` (pipe close).
        signal_or_status: Descriptive token (``"SIGABRT"``, ``"SIGKILL"``,
            ``"exit=1"``, ``"pipe_closed"``, ``"signal=N"`` for unmapped).
    """

    def __init__(self, detection_path: str, signal_or_status: str):
        super().__init__(
            f"subprocess early death: {detection_path}/{signal_or_status}"
        )
        self.detection_path = detection_path
        self.signal_or_status = signal_or_status


# ── Env config (AC6.8) ───────────────────────────────────────────────


def _get_poll_interval_ms() -> int:
    """Poll interval ms (default 100, env ``MLX_EARLY_DEATH_POLL_INTERVAL_MS``)."""
    raw = os.environ.get("MLX_EARLY_DEATH_POLL_INTERVAL_MS")
    if raw is None or raw == "":
        return _DEFAULT_POLL_INTERVAL_MS
    try:
        v = int(raw)
    except (TypeError, ValueError):
        return _DEFAULT_POLL_INTERVAL_MS
    if v < 1:
        return _DEFAULT_POLL_INTERVAL_MS
    return v


def is_detector_enabled() -> bool:
    """Env-driven rollback (``MLX_EARLY_DEATH_DETECT=0`` disables).

    Default ``"1"`` (enabled). Falsey values: ``"0"``, ``"false"``,
    ``"False"``, ``"no"``, empty. All other values enabled.
    """
    raw = os.environ.get("MLX_EARLY_DEATH_DETECT", "1").strip()
    return raw not in ("0", "false", "False", "no", "")


# ── Internal helpers ─────────────────────────────────────────────────


def _signal_or_status_from_exitcode(exitcode: int | None) -> str:
    """Convert ``Process.exitcode`` to descriptive token.

    multiprocessing convention:
        - None: process not yet joined (exitcode unset)
        - Negative N: child died from signal ``-N`` (e.g. ``-6 → SIGABRT``)
        - Positive N: child exited with code N (uncaught exception → 1)
    """
    if exitcode is None:
        return "exit=unknown"
    # R1 P1 fix: future caller may pass a process-like object (test mock,
    # protocol stub) where `.exitcode` is non-int — guard explicitly so a
    # `TypeError` does not bypass `_emit_safe`/`_trigger_lockout_safe` and
    # surface to the caller in place of the documented exception type.
    if not isinstance(exitcode, int):
        return "exit=unknown"
    if exitcode < 0:
        sig = -exitcode
        try:
            return signal.Signals(sig).name
        except ValueError:
            return f"signal={sig}"
    return f"exit={exitcode}"


def _emit_safe(event_kind: str, payload: dict[str, Any]) -> None:
    """Best-effort emit; never raises. Failures logged at DEBUG."""
    try:
        corpus.emit_event(event_kind=event_kind, payload=payload)
    except Exception as exc:
        log.debug("child_death_detector: panic_corpus emit failed: %s", exc)


def _trigger_lockout_safe(reason: str) -> None:
    """Best-effort recovery_lockout trigger; never raises. Failures logged."""
    try:
        recovery_lockout.trigger_crash_lockout(reason=reason)
    except Exception as exc:
        log.debug("child_death_detector: trigger_crash_lockout failed: %s", exc)


# ── Public API ────────────────────────────────────────────────────────


def poll_for_early_death(
    *,
    process: Any,
    parent_recv_fd: int | None,
    timeout_sec: float,
) -> None:
    """Block until child dies (raise) or ``timeout_sec`` elapses (return).

    Uses ``select.select`` over ``process.sentinel`` and ``parent_recv_fd``
    simultaneously. On either fd ready (sentinel signal or pipe EOF),
    emits ``subprocess_early_death`` corpus event, triggers
    ``recovery_lockout.trigger_crash_lockout``, and raises
    ``SubprocessEarlyDeathError``. Single-emission idempotent guard ensures
    AC6.6 (race between paths emits exactly once).

    Args:
        process: ``multiprocessing.Process`` (must expose ``.sentinel`` int
            fd; ``-1`` means sentinel unavailable, e.g. for unit-test mocks).
        parent_recv_fd: parent end ``fileno()`` of ``multiprocessing.Pipe``
            or ``None`` (omits pipe-EOF watch).
        timeout_sec: Max wall time to poll. On expiry returns silently.

    Raises:
        SubprocessEarlyDeathError: child died (sentinel or pipe-EOF).

    Notes:
        - When ``MLX_EARLY_DEATH_DETECT=0``, returns immediately (AC6.8).
        - Sentinel takes priority over pipe-EOF when both are ready in the
          same ``select`` return — sentinel = process death (kernel),
          pipe-EOF could just mean child closed pipe early.
        - **Single-emission guard is per-call** (R1 P2 doc nudge): the
          ``detection_emitted`` flag is local. Callers MUST NOT re-invoke
          ``poll_for_early_death`` after a ``SubprocessEarlyDeathError`` for
          the same dead process — re-invocation will re-emit the corpus
          event and re-trigger ``recovery_lockout.trigger_crash_lockout``.
    """
    if not is_detector_enabled():
        return

    poll_interval_sec = _get_poll_interval_ms() / 1000.0
    deadline = time.monotonic() + timeout_sec
    detection_emitted = False

    # Build watch list — only valid (int, ≥0) fds enter select.
    watch_fds: list[int] = []
    sentinel_fd = getattr(process, "sentinel", None)
    sentinel_valid = isinstance(sentinel_fd, int) and sentinel_fd >= 0
    if sentinel_valid:
        watch_fds.append(sentinel_fd)  # type: ignore[arg-type]
    if parent_recv_fd is not None and parent_recv_fd >= 0:
        watch_fds.append(parent_recv_fd)

    if not watch_fds:
        # Nothing to watch — degrade to no-op return (caller's responsibility
        # to provide at least one valid fd).
        return

    while True:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return  # timeout — caller decides next step
        wait = min(poll_interval_sec, remaining)
        try:
            ready, _, _ = select.select(watch_fds, [], [], wait)
        except (OSError, ValueError):
            # fd became invalid mid-poll — bail out gracefully.
            return

        if not ready:
            continue

        # Sentinel takes priority. Fall back to pipe-EOF.
        detection_path: str | None = None
        signal_or_status: str | None = None

        if sentinel_valid and sentinel_fd in ready:
            detection_path = "sigchld"
            # Brief join to populate process.exitcode (multiprocessing reaper
            # sets it asynchronously after sentinel signals).
            try:
                process.join(timeout=0.1)
            except Exception as exc:  # pragma: no cover — best-effort
                # R1 P1 fix: bare ``except: pass`` violates Harper rule S110.
                # join() failures are non-fatal here — exitcode probe falls
                # back to ``"exit=unknown"`` — but stay observable in DEBUG.
                log.debug("child_death_detector: process.join failed: %s", exc)
            signal_or_status = _signal_or_status_from_exitcode(
                getattr(process, "exitcode", None)
            )
        elif parent_recv_fd is not None and parent_recv_fd in ready:
            detection_path = "pipe_eof"
            signal_or_status = "pipe_closed"

        if detection_path is None:
            # Defensive — select returned ready but neither known fd matched.
            continue

        if not detection_emitted:
            detection_emitted = True
            # Trigger recovery_lockout FIRST so its internal corpus event
            # (`subprocess_crashed` from `trigger_crash_lockout`) is followed
            # by our `subprocess_early_death` — last-call inspection by
            # callers/tests then surfaces the early-death event payload as
            # the most recent. Order matters because both paths route
            # through the same `panic_corpus.emit_event`.
            _trigger_lockout_safe(
                f"early_death_{detection_path}_{signal_or_status}"
            )
            payload = {
                "detection_path": detection_path,
                "signal_or_status": signal_or_status,
                "pid": getattr(process, "pid", None),
            }
            _emit_safe("subprocess_early_death", payload)

        raise SubprocessEarlyDeathError(
            detection_path, signal_or_status or "unknown"
        )
