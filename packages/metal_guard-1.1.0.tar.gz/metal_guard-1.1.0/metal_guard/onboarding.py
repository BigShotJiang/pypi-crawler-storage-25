"""First-run onboarding for metal-guard.

Target user: someone who installed MLX, hit a kernel panic, and just ran
`pip install metal-guard`. The wizard scans for the recent panic,
explains it in plain language, and offers to install the shell guard.
"""
from __future__ import annotations

import sys
import time
from typing import Any, TextIO

_KNOWN_PANIC_HOURS = 720.0  # 30 days


def _recent_panics(since_hours: float) -> list[dict[str, Any]]:
    """Scan for kernel panics; never raises (onboarding must not crash)."""
    from metal_guard.panic_reports import parse_panic_reports
    since_ts = time.time() - since_hours * 3600.0
    try:
        return parse_panic_reports(since_ts=since_ts)
    except Exception:  # noqa: BLE001
        return []


def _known_panic_models() -> list[str]:
    try:
        from metal_guard.panic_registry import KNOWN_PANIC_MODELS
        return sorted(
            mid for mid, info in KNOWN_PANIC_MODELS.items()
            if isinstance(info, dict) and info.get("tier") == "panic"
        )
    except Exception:  # noqa: BLE001
        return []


def run_diagnose(stream: TextIO | None = None) -> bool:
    """Scan + explain recent panics. Returns True if a GPU panic was found."""
    stream = stream or sys.stdout
    panics = _recent_panics(_KNOWN_PANIC_HOURS)

    if not panics:
        stream.write(
            "No recent kernel panics found in the last 30 days.\n"
            "metal-guard can still protect you proactively.\n\n"
        )
        found = False
    else:
        newest = max(panics, key=lambda p: p.get("ts", 0.0))
        when = time.strftime(
            "%Y-%m-%d %H:%M", time.localtime(newest.get("ts", 0.0)))
        stream.write(
            f"Found {len(panics)} kernel panic(s) in the last 30 days.\n"
            f"  Most recent: {when}\n"
        )
        gpu = [p for p in panics
               if p.get("signature") not in (None, "unknown")]
        if gpu:
            newest_gpu = max(gpu, key=lambda p: p.get("ts", 0.0))
            expl = newest_gpu.get("explanation") \
                or "Apple GPU driver bug triggered by MLX."
            stream.write(
                f"  Signature: {newest_gpu.get('signature')}\n"
                f"  {expl}\n"
                "  This is an Apple GPU driver bug — not a hardware fault, "
                "and not your mistake.\n\n"
            )
            found = True
        else:
            path = newest.get("source_file", "the panic report file")
            stream.write(
                "  No GPU-specific signature matched.\n"
                f"  Inspect manually: {path}\n\n"
            )
            found = False

    models = _known_panic_models()
    if models:
        stream.write("Models known to trigger this panic — avoid loading:\n")
        for m in models:
            stream.write(f"  - {m}\n")
        stream.write("\n")
    return found


def _prompt_yes(question: str, *, interactive: bool, stream: TextIO) -> bool:
    if not interactive or not sys.stdin.isatty():
        stream.write(f"{question} [skipped — non-interactive]\n")
        return False
    try:
        ans = input(f"{question} [Y/n] ").strip().lower()
    except EOFError:
        return False
    return ans in ("", "y", "yes")


def run_onboarding(stream: TextIO | None = None, *,
                   interactive: bool = True) -> int:
    """Run the first-run onboarding wizard. Returns a process exit code."""
    stream = stream or sys.stdout
    stream.write(
        "metal-guard — Apple Silicon MLX kernel-panic protection\n"
        + "=" * 56 + "\n\n"
    )
    run_diagnose(stream)

    from metal_guard import shell_guard
    st = shell_guard.status()
    if st["installed"]:
        stream.write(
            "Shell guard is already installed — you're protected.\n"
            f"  (config file: {st['rc']})\n"
        )
        return 0

    stream.write(
        "The shell guard routes `python` through metal-guard so a recent\n"
        "panic automatically pauses risky MLX runs. It adds one block to\n"
        "your shell config and is fully reversible "
        "(`metal-guard guard uninstall`).\n\n"
    )
    if _prompt_yes("Install the shell guard now?",
                   interactive=interactive, stream=stream):
        r = shell_guard.install()
        stream.write(
            f"\nShell guard installed. "
            f"Open a new terminal or run: source {r['rc']}\n"
        )
    else:
        stream.write(
            "\nSkipped. To protect a single run manually:\n"
            "  mlx-safe-python your_script.py\n"
            "To install the shell guard later:\n"
            "  metal-guard guard install\n"
        )
    stream.write(
        "\nNote: the shell guard covers interactive terminals only "
        "(Terminal, iTerm, VS Code).\n"
        "For launchd jobs, Jupyter app kernels, or shebang scripts, "
        "run `mlx-safe-python` directly.\n"
    )
    return 0
