"""The MetalGuard class + the module-level ``metal_guard`` singleton.

OVERSIZE EXCEPTION: this module is ~1200 lines, over the ~800-line
coding-style target. MetalGuard is a single cohesive class; splitting
it across modules is not a mechanical move. Per the Phase 1 refactor
spec the class is kept whole here.
"""
from __future__ import annotations

import datetime
import gc
import glob
import json
import logging
import multiprocessing
import os
import pathlib
import re
import shutil
import signal
import sys
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from multiprocessing.connection import Connection
from pathlib import Path
from typing import Any, Callable, Generator, Iterator, Tuple, TypeVar

from metal_guard._constants import log, T
from metal_guard.memory import MemoryStats, MetalOOMError
from metal_guard.error_classifier import _METAL_OOM_PATTERN

class MetalGuard:
    """Centralized Metal GPU safety for MLX on Apple Silicon.

    Five responsibilities:
      1. **Thread tracking** — ensure no GPU thread is alive before cleanup
      2. **Safe cleanup** — gc + GPU sync + cache clear + cooldown
      3. **Memory pressure** — monitor and preemptively clean before overload
      4. **OOM recovery** — catch Metal OOM, cleanup, and raise recoverable error
      5. **Periodic maintenance** — background flush for long-running processes

    The breadcrumb log is fsync'd before every dangerous Metal operation.
    After a kernel panic, the last breadcrumb shows which op crashed.

    Parameters:
        cooldown_secs: Sleep duration after GPU flush to let Metal driver
            reclaim buffers.  2s is safe for M1/M2/M3/M4 Ultra.
        thread_timeout_secs: Max time to wait for GPU threads before
            proceeding with cleanup.
        breadcrumb_path: File path for crash-safe breadcrumb log.
            Set to None to disable breadcrumbs.
    """

    def __init__(
        self,
        cooldown_secs: float = 2.0,
        thread_timeout_secs: float = 30.0,
        breadcrumb_path: str | None = "logs/metal_breadcrumb.log",
    ) -> None:
        self._threads: list[threading.Thread] = []
        self._lock = threading.RLock()  # Reentrant — safe if cleanup calls nest
        self._cooldown = cooldown_secs
        self._thread_timeout = thread_timeout_secs
        self._breadcrumb_path = breadcrumb_path
        self._flush_timer: threading.Timer | None = None
        self._flush_interval: float = 0
        self._tick_fn: Callable[[], None] = self._periodic_flush_tick
        self._watchdog_warn_pct: float = 70.0
        self._watchdog_critical_pct: float = 85.0
        self._watchdog_on_critical: Callable[[], None] | None = None
        self._watchdog_baseline: int | None = None
        # KV cache monitor state (initialized by start_kv_cache_monitor)
        self._kv_growth_rate_warn: float = 1.0
        self._kv_headroom_gb: float = 4.0
        self._kv_on_pressure: Callable[[float, float], None] | None = None
        self._kv_samples: list[tuple[float, float]] = []
        self._kv_interval: float = 30.0
        self._kv_timer: threading.Timer | None = None

    # ── Hardware-aware auto-configuration ────────────────────────────
    # Addresses: community feedback that users with different hardware
    # (8GB MBA to 512GB Mac Studio) need different safety thresholds.

    @staticmethod
    def detect_hardware() -> dict[str, Any]:
        """Detect Apple Silicon hardware and return safety-relevant info.

        Returns a dict with:
          - gpu_memory_gb: Total GPU memory (unified memory on Apple Silicon)
          - chip: Chip name (e.g. "Apple M1 Ultra")
          - recommended_working_set_gb: Apple's recommended working set limit
          - tier: "low" (8-16GB), "mid" (32-64GB), "high" (96-512GB)

        Works without MLX installed (falls back to sysctl).
        """
        gpu_memory_gb = 0.0
        chip = "unknown"
        recommended_gb = 0.0

        # Try MLX first (most accurate)
        try:
            import mlx.core as mx
            info = mx.device_info()
            recommended = info.get("max_recommended_working_set_size", 0)
            recommended_gb = recommended / (1024 ** 3)
            # Total memory ≈ recommended / 0.75 (Apple reserves ~25%)
            gpu_memory_gb = recommended_gb / 0.75
        except (ImportError, Exception):
            pass

        # Fallback: sysctl for total memory
        if gpu_memory_gb == 0:
            try:
                import subprocess
                result = subprocess.run(
                    ["sysctl", "-n", "hw.memsize"],
                    capture_output=True, text=True, timeout=5,
                )
                if result.returncode == 0:
                    gpu_memory_gb = int(result.stdout.strip()) / (1024 ** 3)
                    recommended_gb = gpu_memory_gb * 0.75
            except Exception:
                pass

        # Detect chip name
        try:
            import subprocess
            result = subprocess.run(
                ["sysctl", "-n", "machdep.cpu.brand_string"],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode == 0:
                chip = result.stdout.strip()
        except Exception:
            pass

        # Classify tier
        if gpu_memory_gb <= 16:
            tier = "low"
        elif gpu_memory_gb <= 64:
            tier = "mid"
        else:
            tier = "high"

        # IOGPUFamily kext version. mlx#3186 pins the panic fault to
        # this specific kext, so recording the driver revision gives
        # forensic context for future crash correlation. Never raises
        # — returns None on any failure. Forward reference is fine;
        # the function is module-level and resolved lazily at call
        # time.
        gpu_driver_version: str | None = None
        try:
            from metal_guard.system_audit import read_gpu_driver_version
            gpu_driver_version = read_gpu_driver_version()
        except Exception as exc:  # pragma: no cover — defensive
            log.debug("read_gpu_driver_version failed: %s", exc)

        return {
            "gpu_memory_gb": round(gpu_memory_gb, 1),
            "chip": chip,
            "recommended_working_set_gb": round(recommended_gb, 1),
            "tier": tier,
            "gpu_driver_version": gpu_driver_version,
        }

    @classmethod
    def recommended_config(cls) -> dict[str, Any]:
        """Return hardware-appropriate configuration values.

        Call this to get safe defaults for your machine, then pass them
        to the relevant MetalGuard methods.

        Returns a dict with recommended values for:
          - watchdog_warn_pct / watchdog_critical_pct
          - kv_headroom_gb / kv_growth_rate_warn
          - cooldown_secs
          - max_concurrent_models
          - overhead_gb (for require_fit)

        Example::

            config = MetalGuard.recommended_config()
            print(f"Your {config['chip']} ({config['gpu_memory_gb']}GB)")
            print(f"Recommended watchdog: warn={config['watchdog_warn_pct']}%")

            metal_guard.start_watchdog(
                warn_pct=config["watchdog_warn_pct"],
                critical_pct=config["watchdog_critical_pct"],
            )
            metal_guard.start_kv_cache_monitor(
                headroom_gb=config["kv_headroom_gb"],
            )
        """
        hw = cls.detect_hardware()
        mem = hw["gpu_memory_gb"]
        tier = hw["tier"]

        if tier == "low":  # 8-16GB (MBA, base MBP)
            config = {
                "watchdog_warn_pct": 60.0,
                "watchdog_critical_pct": 75.0,
                "kv_headroom_gb": 2.0,
                "kv_growth_rate_warn": 0.5,
                "cooldown_secs": 3.0,
                "max_concurrent_models": 1,
                "overhead_gb": 3.0,
            }
        elif tier == "mid":  # 32-64GB (Mac Studio M1/M2/M4, MBP Max)
            config = {
                "watchdog_warn_pct": 67.0,
                "watchdog_critical_pct": 82.0,
                "kv_headroom_gb": 4.0,
                "kv_growth_rate_warn": 1.0,
                "cooldown_secs": 2.0,
                "max_concurrent_models": 2,
                "overhead_gb": 2.0,
            }
        else:  # 96-512GB (Ultra, Max Pro)
            config = {
                "watchdog_warn_pct": 70.0,
                "watchdog_critical_pct": 85.0,
                "kv_headroom_gb": 8.0,
                "kv_growth_rate_warn": 2.0,
                "cooldown_secs": 2.0,
                "max_concurrent_models": 3,
                "overhead_gb": 2.0,
            }

        config.update(hw)
        return config

    # ── Thread tracking ──────────────────────────────────────────────

    def register_thread(self, thread: threading.Thread) -> None:
        """Register a daemon thread that holds Metal GPU buffers.

        Call this immediately after starting any thread that runs
        mlx_lm.generate() or mlx_vlm.generate().  MetalGuard will
        ensure the thread finishes before any cleanup operation.
        """
        with self._lock:
            self._threads = [t for t in self._threads if t.is_alive()]
            self._threads.append(thread)

    def wait_for_threads(self, timeout: float | None = None) -> int:
        """Block until all registered GPU threads finish.

        Returns the number of threads still alive after timeout (0 = clean).
        """
        timeout = timeout if timeout is not None else self._thread_timeout
        with self._lock:
            alive = [t for t in self._threads if t.is_alive()]
        if not alive:
            return 0

        self.breadcrumb(f"WAIT_GPU: {len(alive)} thread(s) alive, waiting {timeout}s")
        for t in alive:
            t.join(timeout=timeout)

        with self._lock:
            still_alive = [t for t in self._threads if t.is_alive()]
            self._threads = still_alive

        if still_alive:
            self.breadcrumb(f"WAIT_GPU: WARNING — {len(still_alive)} still alive")
            log.warning(
                "GPU threads: %d still alive after %.0fs timeout",
                len(still_alive), timeout,
            )
        else:
            self.breadcrumb("WAIT_GPU: all threads finished")
        return len(still_alive)

    # ── GPU cleanup ──────────────────────────────────────────────────

    def flush_gpu(self) -> None:
        """Flush Metal GPU buffers.

        Performs: mx.eval(sync) -> mx.clear_cache().
        MUST only be called after wait_for_threads() — calling this while
        a generate thread is still running WILL trigger the kernel panic.

        No-op if MLX is not installed.
        """
        try:
            import mlx.core as mx
        except ImportError:
            return
        self.breadcrumb("FLUSH: mx.eval sync")
        mx.eval(mx.zeros(1))
        self.breadcrumb("FLUSH: mx.clear_cache()")
        mx.clear_cache()
        self.breadcrumb("FLUSH: done")

    def safe_cleanup(self) -> None:
        """Full cleanup: wait for threads -> GC -> flush GPU -> cooldown.

        This is the ONLY correct way to release Metal GPU memory.
        Never call mx.clear_cache() directly — always go through this.
        """
        self.breadcrumb("CLEANUP: START")
        self.wait_for_threads()
        gc.collect()
        self.flush_gpu()
        time.sleep(self._cooldown)
        self.breadcrumb("CLEANUP: DONE")

    @contextmanager
    def guarded_cleanup(self) -> Generator[None, None, None]:
        """Context manager that runs safe_cleanup on exit.

        Usage:
            with metal_guard.guarded_cleanup():
                model_cache.clear()
        """
        try:
            yield
        finally:
            self.safe_cleanup()

    # ── OOM recovery (v0.2) ──────────────────────────────────────────
    # Addresses: mlx-lm#1015 (generate OOM crash), #854 (server OOM crash)

    @staticmethod
    def is_metal_oom(exc: BaseException) -> bool:
        """Check if an exception is a Metal GPU out-of-memory error.

        Metal OOM surfaces as RuntimeError with a specific message pattern
        from the C++ runtime.  This detects it reliably.
        """
        return isinstance(exc, RuntimeError) and bool(
            _METAL_OOM_PATTERN.search(str(exc))
        )

    def oom_protected(
        self,
        fn: Callable[..., T],
        *args: Any,
        max_retries: int = 1,
        **kwargs: Any,
    ) -> T:
        """Run a function with Metal OOM protection.

        If the function raises a Metal OOM error:
          1. Catch it (prevent process termination)
          2. Run safe_cleanup() to recover GPU state
          3. Retry once (if max_retries > 0)
          4. If still OOM, raise MetalOOMError (catchable, not fatal)

        Usage:
            result = metal_guard.oom_protected(
                generate, model, tokenizer, prompt=prompt, max_tokens=4096
            )

        For servers, catch MetalOOMError and return HTTP 503:
            try:
                result = metal_guard.oom_protected(generate, ...)
            except MetalOOMError:
                return Response(status_code=503, body="GPU memory exhausted")
        """
        last_exc: BaseException | None = None

        for attempt in range(max_retries + 1):
            try:
                return fn(*args, **kwargs)
            except RuntimeError as exc:
                if not self.is_metal_oom(exc):
                    raise  # Not OOM — don't swallow other errors
                last_exc = exc
                stats = self.memory_stats()
                log.error(
                    "Metal OOM caught (attempt %d/%d): %s | %s",
                    attempt + 1, max_retries + 1, exc, stats,
                )
                self.breadcrumb(f"OOM_RECOVERY: attempt {attempt + 1}, cleaning up")
                self.safe_cleanup()

                if attempt < max_retries:
                    log.info("Retrying after OOM cleanup...")

        stats = self.memory_stats()
        raise MetalOOMError(
            f"Metal GPU out of memory after {max_retries + 1} attempts. "
            f"Memory: {stats}. Original error: {last_exc}",
            stats=stats,
        )

    @contextmanager
    def oom_protected_context(self) -> Generator[None, None, None]:
        """Context manager version of OOM protection.

        Usage:
            with metal_guard.oom_protected_context():
                result = generate(model, tokenizer, prompt=prompt)
        """
        try:
            yield
        except RuntimeError as exc:
            if not self.is_metal_oom(exc):
                raise
            stats = self.memory_stats()
            log.error("Metal OOM caught in context: %s | %s", exc, stats)
            self.breadcrumb("OOM_RECOVERY: context manager cleanup")
            self.safe_cleanup()
            raise MetalOOMError(
                f"Metal GPU out of memory. Memory: {stats}. Original: {exc}",
                stats=stats,
            ) from exc

    # ── Pre-load memory check (v0.2) ─────────────────────────────────
    # Addresses: mlx-lm#427 (M1 MBA crash), #1047 (KV cache OOM)

    def can_fit(
        self,
        model_size_gb: float,
        overhead_gb: float = 2.0,
    ) -> bool:
        """Check if a model of the given size can fit in available Metal memory.

        Accounts for currently active memory + a safety overhead (default 2GB
        for KV cache, OS, and other allocations).

        Note: model_size_gb uses decimal gigabytes (1 GB = 1e9 bytes), which
        matches mx.get_active_memory() and HuggingFace model card sizes.
        Binary GiB (1024^3) would overestimate by ~7%.

        Usage:
            if not metal_guard.can_fit(model_size_gb=24.0):
                metal_guard.safe_cleanup()  # Try freeing first
                if not metal_guard.can_fit(model_size_gb=24.0):
                    raise MemoryError("Cannot fit 24GB model")
            model = load("my-24gb-model")
        """
        stats = self.memory_stats()
        if not stats.limit_bytes:
            return True  # Can't check — assume OK

        needed_bytes = (model_size_gb + overhead_gb) * 1e9
        available_bytes = stats.limit_bytes - stats.active_bytes
        fits = available_bytes >= needed_bytes

        if not fits:
            log.warning(
                "Model needs %.1fGB (%.1f + %.1f overhead) but only %.1fGB available "
                "(active=%.1fGB, limit=%.0fGB)",
                model_size_gb + overhead_gb, model_size_gb, overhead_gb,
                available_bytes / 1e9, stats.active_gb, stats.limit_gb,
            )
        return fits

    def require_fit(
        self,
        model_size_gb: float,
        model_name: str = "",
        overhead_gb: float = 2.0,
        *,
        cache_clear_cb: Callable[[], None] | None = None,
        escalated_cooldown_sec: float = 0.0,
    ) -> None:
        """Ensure a model can fit, cleaning up first if needed.

        Two-tier retry strategy:

        1. **Standard** — if ``can_fit`` fails, run ``safe_cleanup`` once and
           re-check. This handles transient GPU buffer pressure where a
           ``wait_for_threads + gc + flush + internal cooldown`` is enough.

        2. **Escalated** (opt-in via ``escalated_cooldown_sec > 0``) — if the
           standard retry still can't fit, invoke the caller-supplied
           ``cache_clear_cb`` to drop Python-side references (their model
           dict), run a second ``safe_cleanup``, reset ``mlx.core.reset_peak_memory``,
           sleep ``escalated_cooldown_sec`` to let Metal's internal pool
           actually return pages to the OS, then re-check a final time.

        Escalation is **opt-in** because the cache clear callback is
        application-specific (MetalGuard has no global knowledge of your
        ModelCache implementation). Pass ``escalated_cooldown_sec=5.0`` and
        ``cache_clear_cb=my_cache.clear`` to enable.

        Raises ``MemoryError`` if the model still doesn't fit after the
        highest-level retry that was enabled.

        Usage::

            # Standard (no escalation):
            metal_guard.require_fit(24.0, model_name="Mistral-24B-8bit")

            # Escalated retry for tight-memory ensembles:
            metal_guard.require_fit(
                24.0,
                model_name="Mistral-24B-8bit",
                cache_clear_cb=my_model_cache.clear,
                escalated_cooldown_sec=5.0,
            )
        """
        if self.can_fit(model_size_gb, overhead_gb):
            return

        log.info("Cleaning up to make room for %s (%.1fGB)...", model_name, model_size_gb)
        self.safe_cleanup()

        if self.can_fit(model_size_gb, overhead_gb):
            return

        # Standard cleanup insufficient. Raise now unless caller opted into
        # escalated retry.
        if escalated_cooldown_sec <= 0:
            stats = self.memory_stats()
            raise MemoryError(
                f"Cannot fit {model_name or 'model'} ({model_size_gb:.1f}GB) "
                f"even after cleanup. Available: {stats.available_gb:.1f}GB, "
                f"needed: {model_size_gb + overhead_gb:.1f}GB"
            )

        # Escalated retry: drop caller's cache references, second cleanup,
        # longer sleep to force Metal page release, re-check.
        log.warning(
            "Standard cleanup insufficient for %s — escalating "
            "(cache_clear_cb=%s, cooldown=%.1fs)",
            model_name or "model",
            "yes" if cache_clear_cb else "no",
            escalated_cooldown_sec,
        )
        if cache_clear_cb is not None:
            try:
                cache_clear_cb()
            except Exception as exc:  # noqa: BLE001 — caller failure must not abort escalation
                log.warning("cache_clear_cb raised: %s (continuing escalation)", exc)
        self.safe_cleanup()
        try:
            import mlx.core as mx
            mx.reset_peak_memory()
        except (ImportError, AttributeError):
            pass
        time.sleep(escalated_cooldown_sec)

        if self.can_fit(model_size_gb, overhead_gb):
            log.info(
                "Escalated cleanup succeeded — %s (%.1fGB) now fits",
                model_name or "model", model_size_gb,
            )
            return

        stats = self.memory_stats()
        raise MemoryError(
            f"Cannot fit {model_name or 'model'} ({model_size_gb:.1f}GB) "
            f"even after escalated cleanup ({escalated_cooldown_sec}s cooldown). "
            f"active={stats.active_gb:.1f}GB "
            f"available={stats.available_gb:.1f}GB "
            f"needed={model_size_gb + overhead_gb:.1f}GB. "
            f"Consider reducing max loaded models or switching to a smaller quant."
        )

    def dynamic_headroom_gb(
        self,
        base_gb: float = 2.0,
        per_concurrent_gb: float = 1.0,
        growth_rate_bonus_gb: float = 2.0,
        growth_rate_trigger_gb_per_min: float = 0.5,
    ) -> float:
        """Compute a safety headroom that scales with current load.

        Servers handling many concurrent requests (or with fast-growing
        KV caches) need more headroom than a single-request batch job.
        Call this right before ``can_fit`` / ``require_fit`` to derive
        an ``overhead_gb`` that matches the actual pressure.

        Formula::

            headroom = base
                     + per_concurrent * (active_gpu_threads)
                     + (growth_rate > trigger ? growth_rate_bonus : 0)

        Args:
            base_gb: Minimum headroom under zero load. Default 2 GB is
                enough for most single-request workloads.
            per_concurrent_gb: Added per active GPU thread tracked by
                MetalGuard. Default 1 GB per thread mirrors typical
                context-window growth under 4-bit quantization.
            growth_rate_bonus_gb: Added once when KV cache growth rate
                exceeds the trigger. Default 2 GB.
            growth_rate_trigger_gb_per_min: Threshold to apply the bonus.

        Returns:
            Recommended headroom in GB. Always at least ``base_gb``.
        """
        headroom = base_gb

        with self._lock:
            active_threads = sum(1 for t in self._threads if t.is_alive())
        headroom += per_concurrent_gb * active_threads

        # Most recent KV growth rate from monitor samples, if any
        if len(self._kv_samples) >= 2:
            oldest_t, oldest_v = self._kv_samples[0]
            newest_t, newest_v = self._kv_samples[-1]
            elapsed_min = (newest_t - oldest_t) / 60.0
            if elapsed_min > 0.1:
                growth = (newest_v - oldest_v) / elapsed_min
                if growth > growth_rate_trigger_gb_per_min:
                    headroom += growth_rate_bonus_gb

        return headroom

    @staticmethod
    def estimate_model_size_from_name(model_name: str) -> float | None:
        """Heuristically estimate a model's Metal footprint from its name.

        Parses patterns like ``Mistral-Small-24B-8bit`` → ``24 * 1.0 = 24 GB``
        or ``Phi-4-mini-instruct-4bit`` → ``4 * 0.5 = 2 GB`` (mini-class fallback
        estimate). Returns ``None`` when no size hint is found — callers should
        treat that as "unknown, skip the fit check" and fall back to the
        threshold-based ``ensure_headroom`` path.

        Designed to pair with ``require_fit`` so multi-model batch workloads
        (e.g. an MLX ensemble that loads several debaters sequentially) can
        proactively evict cached models before hitting the Metal working-set
        limit, instead of failing with an uncaught ``std::runtime_error``
        from the Metal completion queue.

        Supported param-count patterns (case-insensitive):
          <N>B    → N billion parameters   (e.g. "24B", "31B")
          <N>M    → N million parameters (×0.001 GB)
          mini    → 4 billion fallback (phi-4-mini class)
          small   → 7 billion fallback
          medium  → 13 billion fallback
          large   → 70 billion fallback
          xl      → 13 billion fallback

        Supported quantization multipliers (bytes per parameter, decimal GB):
          16bit / fp16 / bf16  → 2.0
          8bit / int8          → 1.0
          6bit                 → 0.75
          4bit / int4 / q4 / mxfp4 / TQ4 / UD-MLX-4bit → 0.5
          3bit / int3 / TQ3    → 0.375
          2bit / int2          → 0.25
          (default when unspecified: 2.0, assumes fp16)

        TurboQuant (TQ) models use quantized KV cache compression. The model
        weights themselves follow the same per-parameter sizing, but TQ models
        can sustain much longer context windows (50K-200K tokens) due to
        compressed KV cache.  The estimator reports *model weight* footprint
        only — actual runtime memory will be higher with long contexts.

        The result is a rough upper bound intended for pre-load gating —
        callers should not use it for precise accounting.

        Usage::

            size = MetalGuard.estimate_model_size_from_name(
                "mlx-community/Mistral-Small-24B-8bit"
            )
            if size is not None:
                metal_guard.require_fit(size, model_name="Mistral-24B")
            model = load("mlx-community/Mistral-Small-24B-8bit")

        """
        if not model_name:
            return None
        name = model_name.lower()

        # Quantization multiplier (bytes per param)
        bit_mult: float | None = None
        for pat, mult in (
            (r"16bit|fp16|bf16", 2.0),
            (r"8bit|int8", 1.0),
            (r"6bit", 0.75),
            (r"4bit|int4|(?<![a-z])q4|mxfp4|tq4|ud-mlx-4bit", 0.5),
            (r"3bit|int3|tq3", 0.375),
            (r"2bit|int2", 0.25),
        ):
            if re.search(pat, name):
                bit_mult = mult
                break

        # Parameter count (billions)
        # Explicit B/M suffix: "24b", "31b", "350m" — word-boundary anchors
        # require the token to be standalone, which rejects things like
        # "8bit" (where 'b' is inside "bit") and "some-24beauty" while
        # still matching "24b", "1.5B", "350m" when they appear as full
        # tokens. More robust than the earlier (?![a-z]) lookahead.
        params_b: float | None = None
        match = re.search(r"\b(\d+(?:\.\d+)?)\s*([bm])\b", name)
        if match:
            value = float(match.group(1))
            unit = match.group(2)
            params_b = value if unit == "b" else value / 1000.0
        else:
            # Size class fallback when the name has a keyword but no explicit
            # parameter count (e.g. "phi-4-mini-instruct-4bit").
            for pat, size in (
                ("mini", 4.0),
                ("small", 7.0),
                ("medium", 13.0),
                ("large", 70.0),
                ("xl", 13.0),
            ):
                if pat in name:
                    params_b = size
                    break

        if params_b is None:
            # Without a param count, we can't estimate at all — let the
            # caller fall back to ensure_headroom threshold checks.
            return None

        # Default to fp16 (conservative upper bound) when bits are unspecified.
        if bit_mult is None:
            bit_mult = 2.0

        return params_b * bit_mult

    # ── Memory pressure ──────────────────────────────────────────────

    def memory_stats(self) -> MemoryStats:
        """Get current Metal GPU memory stats.

        Returns a zero MemoryStats if MLX is not available.
        """
        try:
            import mlx.core as mx
        except ImportError:
            return MemoryStats()
        info = mx.device_info()
        return MemoryStats(
            active_bytes=mx.get_active_memory(),
            peak_bytes=mx.get_peak_memory(),
            limit_bytes=info.get("max_recommended_working_set_size", 0),
        )

    def is_pressure_high(
        self,
        threshold_pct: float = 67.0,
        model_name: str = "",
    ) -> bool:
        """Check if Metal peak memory exceeds threshold."""
        stats = self.memory_stats()
        if not stats.limit_bytes:
            return False
        if stats.peak_pct > threshold_pct:
            log.warning(
                "Metal peak %.0f%% (%.1fGB/%.0fGB) — cleanup needed%s",
                stats.peak_pct, stats.peak_gb, stats.limit_gb,
                f" before {model_name}" if model_name else "",
            )
            return True
        return False

    def ensure_headroom(
        self,
        model_name: str = "",
        threshold_pct: float = 67.0,
    ) -> None:
        """Clean up if memory pressure is high, then reset peak counter.

        Call before loading a new model.  If pressure is below threshold,
        this is a no-op (zero overhead on the hot path).
        """
        if not self.is_pressure_high(threshold_pct, model_name):
            return
        self.safe_cleanup()
        try:
            import mlx.core as mx
            mx.reset_peak_memory()
        except (ImportError, AttributeError):
            pass

    def log_memory(self, label: str, model_name: str = "") -> None:
        """Log current Metal memory state.  Lightweight, no cleanup."""
        stats = self.memory_stats()
        if stats.limit_bytes:
            log.info("Metal memory %s %s: %s", label, model_name, stats)

    # ── Periodic flush (v0.2) ────────────────────────────────────────
    # Addresses: mlx-lm#854 (server memory leak), mlx-examples#1124

    def start_periodic_flush(self, interval_secs: float = 300.0) -> None:
        """Start a background timer that flushes GPU cache periodically.

        Prevents memory accumulation in long-running servers/daemons.
        The flush only runs if no GPU threads are active (safe).

        Call stop_periodic_flush() to cancel.

        Usage:
            metal_guard.start_periodic_flush(interval_secs=300)  # Every 5 min
        """
        self.stop_periodic_flush()
        self._flush_interval = interval_secs
        self._tick_fn = self._periodic_flush_tick
        self._schedule_next_flush()
        log.info("Periodic Metal flush started (every %.0fs)", interval_secs)

    def stop_periodic_flush(self) -> None:
        """Stop the background periodic flush timer."""
        if self._flush_timer is not None:
            self._flush_timer.cancel()
            self._flush_timer = None
        self._flush_interval = 0
        self._tick_fn = self._periodic_flush_tick  # Reset to default

    def _schedule_next_flush(self) -> None:
        """Schedule the next periodic flush."""
        if self._flush_interval <= 0:
            return
        self._flush_timer = threading.Timer(
            self._flush_interval, self._tick_fn,
        )
        self._flush_timer.daemon = True
        self._flush_timer.start()

    def _periodic_flush_tick(self) -> None:
        """Execute one periodic flush cycle."""
        try:
            with self._lock:
                alive = [t for t in self._threads if t.is_alive()]
            if alive:
                log.debug(
                    "Periodic flush skipped: %d GPU thread(s) active", len(alive),
                )
            else:
                stats = self.memory_stats()
                if stats.active_bytes > 0 or stats.peak_pct > 50:
                    log.info(
                        "Periodic flush: %s", stats,
                    )
                    self.flush_gpu()
        except Exception as exc:
            log.debug("Periodic flush error (non-fatal): %s", exc)
        finally:
            self._schedule_next_flush()

    # ── Memory drift watchdog (v0.2) ───────────────────────────────
    # For long-running processes (LLM agent loops, mlx_lm.server,
    # 24/7 daemons) where memory drifts upward over hours/days.

    def start_watchdog(
        self,
        interval_secs: float = 300.0,
        warn_pct: float = 70.0,
        critical_pct: float = 85.0,
        on_critical: Callable[[], None] | None = None,
    ) -> None:
        """Start a background watchdog that monitors memory drift.

        Combines periodic flush with escalating memory pressure response:
          - Below warn_pct: periodic flush only (lightweight)
          - Above warn_pct: flush + log warning
          - Above critical_pct: full safe_cleanup + call on_critical callback

        The on_critical callback is where you put your app-level response:
        e.g. drop the oldest conversation, shrink KV cache, restart worker.

        Usage:
            def on_critical():
                kv_cache.clear()
                log.error("Memory critical — KV cache dropped")

            metal_guard.start_watchdog(
                interval_secs=60,
                warn_pct=70.0,
                critical_pct=85.0,
                on_critical=on_critical,
            )
        """
        self._watchdog_warn_pct = warn_pct
        self._watchdog_critical_pct = critical_pct
        self._watchdog_on_critical = on_critical
        self._watchdog_baseline = None
        # Reuse periodic flush infrastructure with watchdog tick
        self.stop_periodic_flush()
        self._flush_interval = interval_secs
        self._tick_fn = self._watchdog_tick
        self._schedule_next_flush()
        log.info(
            "Memory watchdog started (every %.0fs, warn=%.0f%%, critical=%.0f%%)",
            interval_secs, warn_pct, critical_pct,
        )

    def _watchdog_tick(self) -> None:
        """Execute one watchdog cycle with escalating response."""
        try:
            with self._lock:
                alive = [t for t in self._threads if t.is_alive()]
            if alive:
                log.debug("Watchdog skipped: %d GPU thread(s) active", len(alive))
                return

            stats = self.memory_stats()
            if not stats.limit_bytes:
                return

            # Track baseline for drift detection
            if self._watchdog_baseline is None:
                self._watchdog_baseline = stats.active_bytes
                log.info("Watchdog baseline: %.1fGB active", stats.active_gb)

            drift_gb = (stats.active_bytes - self._watchdog_baseline) / 1e9

            if stats.active_pct > self._watchdog_critical_pct:
                log.error(
                    "WATCHDOG CRITICAL: active=%.1fGB (%.0f%%), drift=+%.1fGB — "
                    "full cleanup + callback",
                    stats.active_gb, stats.active_pct, drift_gb,
                )
                self.breadcrumb(
                    f"WATCHDOG: CRITICAL active={stats.active_pct:.0f}% "
                    f"drift={drift_gb:+.1f}GB"
                )
                self.safe_cleanup()
                if self._watchdog_on_critical:
                    try:
                        self._watchdog_on_critical()
                    except Exception as exc:
                        log.error("Watchdog on_critical callback error: %s", exc)
                # Reset baseline after critical cleanup
                new_stats = self.memory_stats()
                self._watchdog_baseline = new_stats.active_bytes

            elif stats.active_pct > self._watchdog_warn_pct:
                log.warning(
                    "WATCHDOG WARN: active=%.1fGB (%.0f%%), drift=+%.1fGB — flushing",
                    stats.active_gb, stats.active_pct, drift_gb,
                )
                self.flush_gpu()

            elif stats.active_bytes > 0 or stats.peak_pct > 50:
                self.flush_gpu()

        except Exception as exc:
            log.debug("Watchdog error (non-fatal): %s", exc)
        finally:
            self._schedule_next_flush()

    # ── KV cache memory monitor (v0.3.1) ────────────────────────────
    # Addresses: mlx-lm#1047 (KV cache OOM on 512GB Mac Studio)
    # KV cache grows unbounded during long conversations. Standard memory
    # watchdog only sees total Metal active bytes, but KV cache growth
    # rate is the leading indicator of imminent OOM. This monitor tracks
    # the growth rate and fires a callback before the cache fills memory.

    def start_kv_cache_monitor(
        self,
        interval_secs: float = 30.0,
        growth_rate_warn_gb_per_min: float = 1.0,
        headroom_gb: float = 4.0,
        on_pressure: Callable[[float, float], None] | None = None,
    ) -> None:
        """Start a background monitor that tracks memory growth rate.

        Designed for long-running servers (mlx_lm.server, agent loops) where
        KV cache grows unbounded across conversations.  Detects rapid
        memory growth *before* it hits OOM, giving the application time
        to rotate caches or reject new requests.

        Args:
            interval_secs: How often to sample memory (default 30s).
            growth_rate_warn_gb_per_min: Warn when memory is growing
                faster than this rate (GB/min).  Default 1.0 GB/min.
            headroom_gb: Trigger on_pressure when available memory drops
                below this threshold.  Default 4.0 GB.
            on_pressure: Callback(available_gb, growth_rate_gb_per_min)
                called when headroom is low or growth rate is high.
                Typical action: clear KV cache, reject new requests, or
                restart the inference server gracefully.

        Usage::

            def handle_pressure(available_gb, growth_rate):
                log.warning("KV cache pressure: %.1fGB free, growing %.1fGB/min",
                            available_gb, growth_rate)
                kv_cache.clear()

            metal_guard.start_kv_cache_monitor(
                interval_secs=30,
                headroom_gb=8.0,
                on_pressure=handle_pressure,
            )
        """
        self._kv_growth_rate_warn = growth_rate_warn_gb_per_min
        self._kv_headroom_gb = headroom_gb
        self._kv_on_pressure = on_pressure
        self._kv_samples: list[tuple[float, float]] = []  # (timestamp, active_gb)
        self._kv_interval = interval_secs
        self._kv_timer: threading.Timer | None = None
        self._schedule_kv_tick()
        log.info(
            "KV cache monitor started (every %.0fs, warn_rate=%.1fGB/min, "
            "headroom=%.1fGB)",
            interval_secs, growth_rate_warn_gb_per_min, headroom_gb,
        )

    def stop_kv_cache_monitor(self) -> None:
        """Stop the KV cache monitor."""
        if self._kv_timer is not None:
            self._kv_timer.cancel()
            self._kv_timer = None
            log.info("KV cache monitor stopped")

    def _schedule_kv_tick(self) -> None:
        self._kv_timer = threading.Timer(self._kv_interval, self._kv_tick)
        self._kv_timer.daemon = True
        self._kv_timer.start()

    def _kv_tick(self) -> None:
        try:
            stats = self.memory_stats()
            now = time.monotonic()
            active_gb = stats.active_gb
            available_gb = stats.available_gb

            # Keep a sliding window of samples (last 5 minutes)
            self._kv_samples.append((now, active_gb))
            cutoff = now - 300  # 5-minute window
            self._kv_samples = [
                (t, v) for t, v in self._kv_samples if t >= cutoff
            ]

            # Calculate growth rate (GB/min) via linear slope
            growth_rate = 0.0
            if len(self._kv_samples) >= 2:
                oldest_t, oldest_v = self._kv_samples[0]
                elapsed_min = (now - oldest_t) / 60.0
                if elapsed_min > 0.1:
                    growth_rate = (active_gb - oldest_v) / elapsed_min

            # Check conditions
            pressure = False
            if available_gb < self._kv_headroom_gb:
                log.warning(
                    "KV MONITOR: low headroom %.1fGB (threshold %.1fGB), "
                    "growth_rate=%.2fGB/min",
                    available_gb, self._kv_headroom_gb, growth_rate,
                )
                self.breadcrumb(
                    f"KV_MONITOR: LOW_HEADROOM available={available_gb:.1f}GB "
                    f"rate={growth_rate:.2f}GB/min"
                )
                pressure = True

            if growth_rate > self._kv_growth_rate_warn:
                log.warning(
                    "KV MONITOR: rapid growth %.2fGB/min (threshold %.1f), "
                    "available=%.1fGB",
                    growth_rate, self._kv_growth_rate_warn, available_gb,
                )
                if not pressure:
                    self.breadcrumb(
                        f"KV_MONITOR: RAPID_GROWTH rate={growth_rate:.2f}GB/min "
                        f"available={available_gb:.1f}GB"
                    )
                pressure = True

            if pressure and self._kv_on_pressure:
                try:
                    self._kv_on_pressure(available_gb, growth_rate)
                except Exception as exc:
                    log.error("KV monitor on_pressure callback error: %s", exc)

        except Exception as exc:
            log.debug("KV monitor error (non-fatal): %s", exc)
        finally:
            self._schedule_kv_tick()

    # ── Pre-generate Metal health probe ─────────────────────────────

    def probe_metal_health(self) -> bool:
        """Run a tiny Metal operation to verify the command queue is alive.

        Call this before starting a generate() call. If the Metal driver
        is in a bad state from a prior crash (stale command queue, leaked
        buffers), this probe will crash *here* rather than during a long
        generate that has already consumed minutes of work.

        Returns True if the probe succeeded, False if MLX is not installed.
        Raises whatever Metal/MLX raises if the GPU is unhealthy — callers
        should wrap this in try/except if they want to handle the failure.

        Introduced after observing production SIGABRT (2026-04-12 18:30)
        where ``mlx::core::gpu::check_error(MTL::CommandBuffer*)`` threw a
        C++ exception on the Metal CompletionQueueDispatch queue. A health
        probe before generate would have caught this at a controlled point
        instead of mid-inference.

        Usage::

            metal_guard.probe_metal_health()  # crash here, not mid-generate
            result = generate(model, tokenizer, prompt=prompt)
        """
        try:
            import mlx.core as mx
        except ImportError:
            return False
        self.breadcrumb("PROBE: Metal health check START")
        mx.eval(mx.zeros(1))  # ~1ms — exercises command queue round-trip
        self.breadcrumb("PROBE: Metal health check OK")
        return True

    # ── SIGABRT signal handler (crash forensics) ─────────────────────

    def install_abort_handler(self) -> None:
        """Install a SIGABRT handler for crash forensics.

        When MLX's ``check_error(MTL::CommandBuffer*)`` detects a Metal
        command buffer error, it throws a C++ exception from inside the
        Metal GCD CompletionQueueDispatch queue. Since this happens outside
        any Python try/except scope, the C++ runtime calls
        ``std::terminate`` → ``abort()`` → SIGABRT.

        Python **cannot prevent** this crash (the C++ throw → terminate
        path is not catchable from Python), but it **can** install a
        ``signal.SIGABRT`` handler that runs before the process dies.

        This handler:
          1. Writes a breadcrumb with the last known context
          2. Logs the event at CRITICAL level
          3. Does NOT attempt recovery (Metal state is corrupt)
          4. Re-raises SIGABRT with the default handler to produce a
             proper core dump / crash report

        Call this once at process startup (before any MLX work)::

            metal_guard.install_abort_handler()

        .. note::

           The handler may not run in all cases — if ``abort()`` is called
           from a non-main thread (which is the case for Metal's
           CompletionQueueDispatch), Python's signal handling has
           limitations. On macOS, ``signal.signal`` handlers are only
           guaranteed to run on the main thread. For GCD queue crashes,
           the breadcrumb from ``probe_metal_health()`` or the last
           ``breadcrumb()`` call is more reliable for forensics.
        """
        self._original_sigabrt = signal.getsignal(signal.SIGABRT)

        def _abort_handler(signum: int, frame: Any) -> None:
            # Best-effort forensics — Metal state is already corrupt.
            try:
                self.breadcrumb(
                    "SIGABRT: Metal command buffer error detected. "
                    "This is a C++ exception from mlx::core::gpu::check_error() "
                    "on the Metal CompletionQueueDispatch queue. "
                    "Cannot recover — writing forensic breadcrumb."
                )
                log.critical(
                    "SIGABRT caught by MetalGuard. Metal GPU state is corrupt. "
                    "Last breadcrumb written. Process will terminate."
                )
            except Exception:
                pass  # Cannot risk another exception during signal handling
            # Restore default handler and re-raise for proper crash report
            signal.signal(signal.SIGABRT, signal.SIG_DFL)
            os.kill(os.getpid(), signal.SIGABRT)

        signal.signal(signal.SIGABRT, _abort_handler)
        self.breadcrumb("SIGABRT handler installed")
        log.info("MetalGuard SIGABRT handler installed (crash forensics)")

    # ── Breadcrumb ───────────────────────────────────────────────────

    def breadcrumb(self, msg: str) -> None:
        """Write a crash-safe breadcrumb to disk.

        Uses fsync to ensure the line survives a kernel panic.
        After a crash, read the last line of the breadcrumb log to
        identify which Metal operation triggered the panic.
        """
        if not self._breadcrumb_path:
            return
        line = f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}\n"
        try:
            dirname = os.path.dirname(self._breadcrumb_path)
            if dirname:
                os.makedirs(dirname, exist_ok=True)
            with open(self._breadcrumb_path, "a") as f:
                f.write(line)
                f.flush()
                os.fsync(f.fileno())
        except OSError:
            pass

    def breadcrumb_with_meta(
        self,
        tag: str,
        payload: str = "",
        **meta,
    ) -> None:
        """v0.11.0 — crash-safe breadcrumb with structured metadata.

        Format::

            [YYYY-MM-DD HH:MM:SS] <TAG>: <payload> | k1=v1 k2=v2 ...

        Backward-compatible with :data:`_BREADCRUMB_LINE_RE` parser (lazy
        payload + optional meta capture group, v0.11.0). Old `breadcrumb()`
        callers continue to work; new callers can attach inflight metadata
        for richer postmortem forensics::

            mg.breadcrumb_with_meta("SUBPROC_PRE", model_id, ctx=2048, kv_bytes=12_000_000)
            ...
            mg.breadcrumb_with_meta("SUBPROC_POST", model_id, elapsed_ms=8421, tok_out=512)

        Recommended fields (caller-controlled vocabulary):

            ctx                 prompt token count at SUBPROC_PRE
            kv_bytes            cumulative KV cache bytes
            elapsed_ms          generate wall time at SUBPROC_POST
            tok_out             tokens emitted
            error_class         classify_mlx_error() name on abort
            descriptor_used     resource_tracker count at this point
        """
        if not self._breadcrumb_path:
            return
        # critic R1 P1-3: pipe is the meta separator; replace any `|` in
        # caller-supplied payload to avoid silent FIFO mis-pairing on the
        # reader side. Replace with `/` (visually similar, safe in URL/path).
        if "|" in payload:
            payload = payload.replace("|", "/")
        meta_str = ""
        if meta:
            # Sort keys for stable parsing; format `k=v` separated by space.
            # Sanitize values too — pipe in value would also break parser.
            meta_pairs = sorted(
                (k, str(v).replace("|", "/")) for k, v in meta.items()
            )
            meta_str = " | " + " ".join(f"{k}={v}" for k, v in meta_pairs)
        prefix = f"{tag}: {payload}" if payload else tag
        line = (
            f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] "
            f"{prefix}{meta_str}\n"
        )
        try:
            dirname = os.path.dirname(self._breadcrumb_path)
            if dirname:
                os.makedirs(dirname, exist_ok=True)
            with open(self._breadcrumb_path, "a") as f:
                f.write(line)
                f.flush()
                os.fsync(f.fileno())
        except OSError:
            pass


metal_guard = MetalGuard()
