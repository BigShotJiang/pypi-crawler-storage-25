"""subprocess_runner — Crash-isolated MLX inference via subprocess workers.

MetalGuard Layer 7: When MLX's C++ runtime throws an exception from Metal's
GCD CompletionQueueDispatch queue (mlx::core::gpu::check_error), Python
cannot catch it — std::terminate calls abort() and the process dies.

Subprocess isolation is the only way to protect the parent process:
  - Each MLX model runs in its own subprocess
  - Worker loads model once, accepts multiple prompts via pipe
  - If worker crashes (SIGABRT) → pipe breaks → parent detects → creates new worker
  - Parent's Python/Metal state is never corrupted

Production trigger: an uncatchable SIGABRT from a Metal GCD completion thread
can kill the whole parent process; subprocess isolation contains the blast
radius to one worker. With L7, only the single worker's call fails; the parent
logs and continues with the next item.

Usage::

    from metal_guard.subprocess_runner import MLXSubprocessRunner

    # Create a worker for a specific model (loads model in subprocess)
    runner = MLXSubprocessRunner("mlx-community/Mistral-Small-3.2-24B-8bit")

    # Send multiple prompts (model stays loaded)
    for prompt in prompts:
        result = runner.generate(prompt, max_tokens=4096)

    # If worker crashes, runner.generate raises SubprocessCrashError
    # Parent can create a new runner and continue

    # Clean shutdown
    runner.shutdown()
"""
from __future__ import annotations

import multiprocessing
import os
import select  # Wave A wire #3b sentinel-aware select.select sigchld arm
import signal
from datetime import datetime, timezone
from multiprocessing.connection import Connection
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from metal_guard.worker_rotation import RotationVerdict

from metal_guard._constants import log
from metal_guard.error_classifier import classify_mlx_error
from metal_guard.mlx_lock import acquire_mlx_lock, release_mlx_lock
from metal_guard.prefill import lookup_dims, require_prefill_fit

# Default timeout for waiting on worker response (seconds).
# MLX text generate rarely exceeds 120s; VLM can take 180s.
# Add generous buffer for model loading on first call.
_DEFAULT_GENERATE_TIMEOUT = 300.0
_DEFAULT_LOAD_TIMEOUT = 120.0


class SubprocessCrashError(RuntimeError):
    """Raised when the MLX worker subprocess crashed (SIGABRT / unexpected exit).

    On construction, classify ``detail`` (typically captured stderr / panic
    reason) via ``error_classifier.classify_mlx_error`` and expose
    ``self.error_class``. Caller can route retry strategy::

        try:
            ...
        except SubprocessCrashError as exc:
            if exc.error_class and exc.error_class.severity == "descriptor_leak":
                # Force cold-restart now, don't wait for next call
                runner.shutdown()
            elif exc.error_class and exc.error_class.severity == "kernel_panic":
                # Will be caught by panic_gate next launchd respawn
                raise
            else:
                # Generic respawn (process_abort / gpu_hang / unknown)
                pass
    """

    def __init__(self, model_id: str, exitcode: int | None, detail: str = ""):
        self.model_id = model_id
        self.exitcode = exitcode
        # Classify detail string against known MLX error patterns. None =
        # unknown abort (e.g. plain SIGKILL with no stderr).
        self.error_class = None
        try:
            self.error_class = classify_mlx_error(detail) if detail else None
        except ImportError:
            pass
        sig_name = ""
        if exitcode is not None and exitcode < 0:
            try:
                sig_name = f" ({signal.Signals(-exitcode).name})"
            except (ValueError, AttributeError):
                pass
        cls_tag = ""
        if self.error_class is not None:
            cls_tag = f" [{self.error_class.severity}/{self.error_class.name}]"
        msg = (
            f"MLX worker subprocess for {model_id!r} crashed "
            f"(exit code {exitcode}{sig_name}{cls_tag})"
        )
        if detail:
            msg += f": {detail}"
        super().__init__(msg)

    @property
    def recovery_hint(self) -> str:
        """Suggested retry strategy. ``"unknown"`` when classification failed."""
        if self.error_class is None:
            return "unknown"
        return self.error_class.recovery_hint


class SubprocessTimeoutError(TimeoutError):
    """Raised when the worker subprocess did not respond within the timeout."""


class SpawnRefused(RuntimeError):
    """Raised when MLXSubprocessRunner construction is refused due to a
    hard-block advisory.

    The local-panic-advisory gate upgrades a known-panic model from
    warn-only to hard-block when its advisory tier is ``panic``
    (machine-rebooting). Lower tiers (abort / degradation) remain
    warn-only.

    Override:
        Set env ``METALGUARD_LOCAL_PANIC_MODEL_BLOCK_DISABLED=1`` to
        downgrade to warn (e.g. for a controlled bench / debugging a
        known issue). The override is logged at WARNING level — never
        silent.

    Attributes:
        model_id: HuggingFace-style model identifier that was refused.
        gpu_family: Detected GPU family at refusal time.
        tier: Advisory tier (always 'panic' for this exception class —
            other tiers do not raise).
        recommendation: Caller-actionable mitigation from the advisory.
        upstream_refs: Tuple of upstream issue URLs for context.
    """

    def __init__(
        self,
        *,
        model_id: str,
        gpu_family: str | None,
        tier: str,
        recommendation: str,
        upstream_refs: tuple[str, ...] = (),
    ):
        self.model_id = model_id
        self.gpu_family = gpu_family
        self.tier = tier
        self.recommendation = recommendation
        self.upstream_refs = upstream_refs
        gpu = gpu_family or "any"
        msg = (
            f"MLX subprocess spawn REFUSED for {model_id!r} on gpu_family={gpu} "
            f"(tier={tier}) — {recommendation[:300]}"
        )
        if upstream_refs:
            msg += f" [refs: {', '.join(upstream_refs[:3])}]"
        msg += (
            " | override: set METALGUARD_LOCAL_PANIC_MODEL_BLOCK_DISABLED=1 "
            "for controlled bench (logged)"
        )
        super().__init__(msg)


# Wave A wire #1: load_gate pre-spawn integration. Set to "1" to skip
# ``load_gate.gate_or_raise`` (emergency rollback). When unset (default),
# `MLXSubprocessRunner.__init__` invokes ``load_gate.gate_or_raise`` BEFORE
# ``_start_worker``.
_LOAD_GATE_DISABLED_ENV = "MLX_LOAD_GATE_DISABLED"
# Wave A wire #2: recovery_lockout pre-spawn gate. Set to "1" to skip
# ``recovery_lockout.is_locked_out()`` check (emergency rollback). When unset
# (default), `__init__` raises ``MLXRecoveryLockedError`` if a system-wide
# crash-burst lockout is active — short-circuiting BEFORE load_gate.
_RECOVERY_LOCKOUT_GATE_DISABLED_ENV = "MLX_RECOVERY_LOCKOUT_GATE_DISABLED"
# Wave A wire #3a: child-death detection cross-spec wire. Existing recv()
# EOFError/OSError path raises SubprocessCrashError; wire #3a additionally
# emits ``subprocess_early_death`` corpus event + triggers
# ``recovery_lockout.trigger_crash_lockout``. Set to "1" to skip — emergency
# rollback.
_CHILD_DEATH_DETECT_DISABLED_ENV = "MLX_CHILD_DEATH_DETECT_DISABLED"
# Wave A wire #3b sigchld arm — finer-grained env knob. Unlike
# ``_CHILD_DEATH_DETECT_DISABLED_ENV`` which umbrellas wire #3a + #3b together,
# this knob disables ONLY the sigchld arm so the wire #3a EOF arm keeps
# working. Either env set to "1" disables wire #3b.
_SENTINEL_DETECT_DISABLED_ENV = "MLX_SENTINEL_DETECT_DISABLED"
# Wave A wire #4a: parent-side protocol_version recognition. Set to "1" to
# skip done_frame.validate_frame on incoming worker messages — falls through
# to legacy ``msg.get("type")`` dispatch unchanged. Wire is opt-in by the
# worker emitting ``protocol_version`` field; pre-#4b workers never set it,
# so default (env unset) is a no-op for legacy traffic.
_DONE_FRAME_WIRE_DISABLED_ENV = "MLX_DONE_FRAME_WIRE_DISABLED"
# W13 local-panic-advisory gate: kill switch to downgrade a tier='panic'
# hard-block back to warn-only. Default OFF (= block enabled). Set to "1"
# for a controlled bench / debugging a known-panic model (override is
# logged at WARNING level).
_LOCAL_PANIC_BLOCK_DISABLED_ENV = "METALGUARD_LOCAL_PANIC_MODEL_BLOCK_DISABLED"


def _signal_name_from_exitcode(exitcode: int | None) -> str:
    """Map ``Process.exitcode`` to autopsy ``signal_or_status`` token.

    multiprocessing convention:
        - None: process not yet joined
        - Negative N: died from signal -N (e.g. -6 → SIGABRT, -9 → SIGKILL)
        - Non-negative: exited with that code (uncaught exception → 1)
    """
    if exitcode is None:
        return "exit=unknown"
    if not isinstance(exitcode, int):
        return "exit=unknown"
    if exitcode < 0:
        sig = -exitcode
        try:
            import signal as _signal_mod
            return _signal_mod.Signals(sig).name
        except (ValueError, ImportError):
            return f"signal={sig}"
    return f"exit={exitcode}"


# ---------------------------------------------------------------------------
# Worker process entry point (runs in subprocess)
# ---------------------------------------------------------------------------


def _worker_main(
    model_id: str,
    backend: str,
    recv_conn: Connection,
    send_conn: Connection,
) -> None:
    """Worker loop running in a forked subprocess.

    Loads the model once, then processes prompts until shutdown or crash.
    All MLX / Metal operations happen here — if Metal SIGABRT fires,
    only this process dies.
    """
    # Suppress TOKENIZERS_PARALLELISM warning in subprocess
    os.environ["TOKENIZERS_PARALLELISM"] = "false"

    # Root cause stopgap (mlx#3390 / #3224 / #3317): zcbenz's endorsed
    # workaround for the Metal completion-handler abort path — reduces the
    # GPU watchdog false-positives that most commonly trigger the
    # uncatchable SIGABRT. ``setdefault`` intentional so an operator can
    # pass AGX_RELAX_CDM_CTXSTORE_TIMEOUT=0 to disable the stopgap for a
    # debug / repro run.
    os.environ.setdefault("AGX_RELAX_CDM_CTXSTORE_TIMEOUT", "1")

    # Process-mode marker: let metal_guard's process-mode detection classify
    # this child as ``subprocess_worker`` so any code that reads mode-specific
    # defaults inside the worker gets the right config (skip_process_lock=True
    # — parent owns the cross-process lock). Internal marker — always hard-set
    # by this library, no caller override.
    os.environ["MLX_CLIENT_SUBPROCESS_WORKER"] = "1"

    # Install MetalGuard's SIGABRT handler for forensic breadcrumb
    try:
        from metal_guard import metal_guard
        metal_guard.install_abort_handler()
        metal_guard.breadcrumb(f"SUBPROCESS_WORKER: loading {model_id}")
    except Exception:
        pass

    # Cadence Guard. Refuse back-to-back loads of the same model within
    # ``METALGUARD_CADENCE_MIN_SEC`` seconds. Apple's IOGPU kernel panics on
    # back-to-back load/unload, and the panic is at kernel level so SIGABRT
    # handlers never fire. Only prevention is to not do back-to-back loads.
    # Disable via ``METALGUARD_CADENCE_GUARD=0``.
    if os.environ.get("METALGUARD_CADENCE_GUARD", "1").strip() != "0":
        try:
            from metal_guard.cadence import (
                CadenceGuard,
                CadenceViolation,
                require_cadence_clear,
            )
            try:
                min_interval = float(os.environ.get("METALGUARD_CADENCE_MIN_SEC", "180"))
            except ValueError:
                min_interval = 180.0
            try:
                idle_threshold = float(
                    os.environ.get("METALGUARD_IDLE_THRESHOLD_SEC", "1800")
                )
            except ValueError:
                idle_threshold = 1800.0
            try:
                idle_warmup = float(
                    os.environ.get("METALGUARD_IDLE_WARMUP_SEC", "2.0")
                )
            except ValueError:
                idle_warmup = 2.0
            # Wire cross_model cadence into the subprocess-side guard.
            # Without this the env-resolved default 60s + gemma-4 90s floor
            # never fire for the subprocess inference path.
            try:
                from metal_guard.cadence import _resolve_cross_model_interval
                _cross_model_sec = _resolve_cross_model_interval(None)
            except Exception as _exc:
                log.warning("resolve cross_model_interval failed: %s", _exc)
                _cross_model_sec = 0.0
            try:
                require_cadence_clear(
                    model_id,
                    guard=CadenceGuard(
                        min_interval_sec=min_interval,
                        idle_threshold_sec=idle_threshold,
                        idle_warmup_sec=idle_warmup,
                        cross_model_interval_sec=_cross_model_sec,
                    ),
                )
            except CadenceViolation as exc:
                try:
                    from metal_guard import metal_guard as _mg
                    _mg.breadcrumb(
                        f"CADENCE_VIOLATION: {model_id} last cycle "
                        f"{exc.delta:.1f}s ago < min {exc.min_interval:.0f}s "
                        f"(panic-avoidance exit)"
                    )
                except Exception:
                    pass
                send_conn.send({
                    "type": "error",
                    "error": f"cadence_violation: {exc}",
                })
                return
        except ImportError:
            pass

    try:
        if backend in ("mlx", "mlx-lm"):
            from mlx_lm import load, generate
            model, tokenizer = load(model_id)
            processor = None  # text path — no VLM processor
            gen_fn = generate
        elif backend == "mlx-vlm":
            from mlx_vlm import load, generate
            # mlx-vlm returns (model, processor) — NOT (model, tokenizer).
            # The processor owns image preprocessing + the chat template.
            # Storing it in a var named `tokenizer` would hide the
            # distinction and lead to vlm_generate being called without the
            # image argument.
            model, processor = load(model_id)
            tokenizer = getattr(processor, "tokenizer", processor)
            gen_fn = generate
        else:
            send_conn.send({"type": "error", "error": f"unsupported backend: {backend}"})
            return
    except Exception as exc:
        send_conn.send({"type": "error", "error": f"load failed: {type(exc).__name__}: {exc}"})
        return

    # ── Layer F — DEAD ─────────────────────────────────────────────────
    # Two S3 benches (old `mx.metal.*` API + new `mx.*` API after migrate)
    # both showed the cap is **ignored on Apple unified memory** —
    # ``mx.zeros`` lands on CPU-visible shared heap which
    # ``set_memory_limit`` does not govern. The relevant kernel panic root
    # cause is ``IOGPUMemory.cpp:492 prepare_count_underflow`` (an IOGPU
    # refcount race), NOT Metal OOM — so a cap was never the right defense
    # in the first place. The wire is neutralized to a no-op that still
    # emits the ``layer_f_status`` field on the ready message so existing
    # readers don't AttributeError. Field is now a pure constant and
    # carries no MLX side effect.
    _layer_f_status = "deprecated_dead"
    _layer_f_active_bytes_after_load = None

    # Peak memory after load — captured unconditionally for ALL models
    # (not gated by Layer F profile). Phase 1 consumer is the
    # metal_guard.breadcrumb jsonl audit trail; future Phase 2 may surface
    # to caller for OOM headroom planning.
    #
    # CAVEAT: mx.get_peak_memory() is process-lifetime. Safe today because
    # workers are spawned fresh per model (not pooled). If a persistent
    # worker pool ever lands, this capture will see the prior model's high
    # water — must add mx.reset_peak_memory() right before this block then.
    _peak_bytes_after_load: int | None = None
    try:
        import mlx.core as _mx_peak
        _peak_bytes_after_load = int(_mx_peak.get_peak_memory())
    except Exception:  # pragma: no cover — older mlx API or import fail
        pass

    # Signal ready to parent — include layer_f_status so callers who
    # require Layer F can assert before issuing inference.
    send_conn.send({
        "type": "ready",
        "model_id": model_id,
        "pid": os.getpid(),
        "layer_f_status": _layer_f_status,
        "layer_f_active_bytes_after_load": _layer_f_active_bytes_after_load,
        "peak_bytes_after_load": _peak_bytes_after_load,
    })

    try:
        from metal_guard import metal_guard as mg
        # Include peak in breadcrumb so the jsonl audit trail captures
        # post-load peak headwater for every worker.
        mg.breadcrumb(
            f"SUBPROCESS_WORKER: {model_id} ready, pid={os.getpid()} "
            f"peak_after_load={_peak_bytes_after_load}"
        )
    except Exception:
        pass

    # First-gen counter for gemma4_generation_flush. Empirical data shows
    # panics most often land on the first WORKER_GENERATE of a gemma-4
    # model. This counter gates the guard's one-shot settle.
    generate_call_count = 0

    # Main loop: receive prompts, generate, send results
    while True:
        try:
            if not recv_conn.poll(timeout=600):  # 10 min idle timeout
                break  # No work for 10 minutes → self-terminate
            request = recv_conn.recv()
        except (EOFError, OSError):
            break  # Parent closed pipe → exit

        if request is None or request.get("type") == "shutdown":
            break

        prompt = request.get("prompt", "")
        max_tokens = request.get("max_tokens", 4096)
        temperature = request.get("temperature", 0.3)
        system_prompt = request.get("system", "")
        # Base64-encoded images for mlx-vlm. None/empty for text backends.
        # Without this the vision path silently drops images and every
        # vision call produces empty output.
        images_b64 = request.get("images") or []

        # Per-request temp-file list (mlx-vlm `generate(image=...)` expects
        # filesystem paths, not base64). Cleaned up in the finally block
        # so each generate() call is self-contained — no cross-prompt leak.
        temp_image_paths: list[str] = []
        input_error_sent = False  # set True when we respond with a per-request
        # error from inside the image-prep block and must SKIP sending a
        # second error frame in the outer except (prevents IPC stream
        # corruption).

        try:
            # ── Image prep (mlx-vlm only) ─────────────────────────────────
            # Hardening:
            # - append temp_path BEFORE any raise so finally can clean up
            # - respond-and-continue (no raise) so IPC stream stays in sync
            # - magic-bytes extension sniff (JPEG/PNG/WebP/GIF/BMP)
            # - per-image size cap to defend against bypass callers
            image_arg = None
            _MAX_IMAGE_BYTES = 20 * 1024 * 1024  # 20MB per image
            _MAX_IMAGES = 32
            if backend == "mlx-vlm" and images_b64:
                import base64
                import tempfile

                if len(images_b64) > _MAX_IMAGES:
                    send_conn.send({
                        "type": "error",
                        "error": f"too many images: {len(images_b64)} > {_MAX_IMAGES}",
                    })
                    input_error_sent = True
                    continue

                for idx, b64 in enumerate(images_b64):
                    try:
                        raw = base64.b64decode(b64, validate=True)
                    except (ValueError, TypeError) as exc:
                        send_conn.send({
                            "type": "error",
                            "error": f"bad base64 image #{idx}: {exc}",
                        })
                        input_error_sent = True
                        break

                    if len(raw) > _MAX_IMAGE_BYTES:
                        send_conn.send({
                            "type": "error",
                            "error": (
                                f"image #{idx} too large: "
                                f"{len(raw)} > {_MAX_IMAGE_BYTES}"
                            ),
                        })
                        input_error_sent = True
                        break

                    # Magic-bytes sniff so mlx-vlm / PIL can dispatch the
                    # right codec. Image CDNs return a mix of JPEG and WebP;
                    # hard-coding ``.jpg`` causes decode errors downstream.
                    if raw.startswith(b"\xff\xd8\xff"):
                        suffix = ".jpg"
                    elif raw.startswith(b"\x89PNG\r\n\x1a\n"):
                        suffix = ".png"
                    elif raw.startswith(b"RIFF") and raw[8:12] == b"WEBP":
                        suffix = ".webp"
                    elif raw.startswith(b"GIF8"):
                        suffix = ".gif"
                    elif raw.startswith(b"BM"):
                        suffix = ".bmp"
                    else:
                        # Unknown — let PIL auto-detect. mlx-vlm accepts
                        # anything PIL can open.
                        suffix = ".bin"

                    fd = tempfile.NamedTemporaryFile(suffix=suffix, delete=False)
                    try:
                        fd.write(raw)
                    finally:
                        fd.close()
                    # Register for cleanup IMMEDIATELY after file creation
                    # (must append before any raise).
                    temp_image_paths.append(fd.name)

                if input_error_sent:
                    # Keep worker alive; parent already got a single error
                    # frame. Continue waits for the next request.
                    continue

                # Always pass a list — several mlx-vlm model families
                # (pixtral multi-image, llama-vision) expect list[str]
                # even for a single image.
                image_arg = list(temp_image_paths)

            # ── Chat template ─────────────────────────────────────────────
            # Apply chat template if available. Fall back to model-family
            # templates when tokenizer.chat_template is unset (observed on
            # some Mistral/Gemma4 quantized variants where the mlx-community
            # upload strips the template). Falling back to raw `prompt`
            # causes the model to treat the text as completion continuation
            # and produce empty / incoherent output.
            formatted = None
            vlm_template_fell_back = False
            if backend == "mlx-vlm" and processor is not None:
                # Use mlx-vlm's prompt_utils which knows the per-family
                # image-token placement (gemma4 / pixtral / llama vision
                # need different insertions).
                try:
                    from mlx_vlm.prompt_utils import (
                        apply_chat_template as vlm_chat_template,
                    )
                    # Use the authoritative count from the decoded image
                    # list — not the raw input — so a partial decode
                    # failure (should be impossible after the continue
                    # above) cannot desync template tokens vs actual
                    # images.
                    formatted = vlm_chat_template(
                        processor, model.config, prompt,
                        num_images=len(image_arg) if image_arg else 0,
                    )
                except Exception as exc:
                    # If vlm's own chat template fails and there ARE
                    # images, falling back to the plain tokenizer
                    # template will silently strip image tokens and
                    # reproduce the empty-vision-output bug. Warn loudly so
                    # the drift is detectable in post-mortem.
                    formatted = None
                    if image_arg:
                        vlm_template_fell_back = True
                        try:
                            from metal_guard import metal_guard as _mg_warn
                            _mg_warn.breadcrumb(
                                f"VLM_TEMPLATE_FALLBACK: model={model_id} "
                                f"num_images={len(image_arg)} err={exc!r} "
                                f"— image tokens may be stripped, expect "
                                f"empty vision output"
                            )
                        except Exception:
                            pass

            if formatted is None:
                try:
                    formatted = tokenizer.apply_chat_template(
                        [{"role": "user", "content": prompt}],
                        add_generation_prompt=True,
                        tokenize=False,
                    )
                except Exception:
                    mid = model_id.lower()
                    if "gemma" in mid:
                        formatted = (
                            f"<start_of_turn>user\n{prompt}<end_of_turn>\n"
                            f"<start_of_turn>model\n"
                        )
                    elif "mistral" in mid:
                        formatted = f"[INST] {prompt} [/INST]"
                    elif "phi" in mid:
                        formatted = f"<|user|>\n{prompt}<|end|>\n<|assistant|>\n"
                    else:
                        formatted = prompt

            # Refuse prefills whose estimated peak allocation would risk
            # IOGPUFamily kernel panic. Silently skips if model dims aren't
            # in the prefill registry. Raises MetalOOMError on breach →
            # caught by the except below and returned as an error reply,
            # not a crash.
            _dims = lookup_dims(model_id)
            if _dims is not None:
                try:
                    _prompt_tok = tokenizer.encode(formatted)
                    _prompt_len = len(_prompt_tok)
                except Exception:
                    _prompt_len = max(1, len(formatted) // 4)
                from metal_guard import metal_guard as _mg_prefill
                _stats = _mg_prefill.memory_stats()
                if _stats.limit_bytes > 0:
                    require_prefill_fit(
                        context_tokens=_prompt_len + max_tokens,
                        dims=_dims,
                        available_gb=_stats.available_gb,
                    )
                    _mg_prefill.breadcrumb(
                        f"PREFILL_GUARD: OK model={model_id} "
                        f"ctx={_prompt_len + max_tokens}"
                    )

            # MetalGuard breadcrumb so post-mortem forensics can identify
            # vision vs text calls when a SIGABRT lands.
            try:
                from metal_guard import metal_guard as _mg
                _mg.breadcrumb(
                    f"WORKER_GENERATE: backend={backend} "
                    f"model={model_id} images={len(temp_image_paths)} "
                    f"template_fallback={vlm_template_fell_back} "
                    f"max_tokens={max_tokens}"
                )
            except Exception:
                pass

            # ── Dispatch ──────────────────────────────────────────────────
            # B1: wrap every gen_fn call in subprocess_inference_guard so the
            # Metal command buffer is drained between generates. Without this
            # the worker hits IOGPUMemory.cpp:492 ``prepare_count_underflow``.
            try:
                from metal_guard.panic_reports import subprocess_inference_guard
            except ImportError:
                # Fallback no-op context manager keeps the worker running
                # in degraded test environments.
                from contextlib import nullcontext
                subprocess_inference_guard = lambda _m: nullcontext()  # noqa: E731

            # gemma-4 first-gen generation flush — direct attack on the
            # observed first-generate panic pattern. No-op for non-gemma-4
            # or for generate_call_count > 0.
            try:
                from metal_guard.panic_reports import gemma4_generation_flush
                gemma4_generation_flush(model_id, generate_call_count)
            except ImportError:
                pass  # graceful in stripped test envs
            except Exception as _flush_exc:
                log.warning("gemma4_generation_flush failed for %s: %s",
                            model_id, _flush_exc)

            with subprocess_inference_guard(model_id):
                if backend == "mlx-vlm":
                    # vlm_generate signature: (model, processor, prompt=, image=, ...)
                    # image is optional only when a vision model is asked for
                    # a pure-text response — vision callers ALWAYS send
                    # images, so a missing image here is a recurring bug.
                    kwargs: dict[str, Any] = {
                        "prompt": formatted,
                        "max_tokens": max_tokens,
                        "temp": temperature,  # mlx-vlm uses `temp` not `temperature`
                        "verbose": False,
                    }
                    if image_arg is not None:
                        kwargs["image"] = image_arg
                    result = gen_fn(model, processor, **kwargs)
                else:
                    # mlx / mlx-lm text path.
                    result = gen_fn(
                        model, tokenizer,
                        prompt=formatted,
                        max_tokens=max_tokens,
                        verbose=False,
                    )

            # mlx-vlm's generate() returns a GenerateResult object with a
            # .text attribute — `str(result)` produces the repr, not the
            # generated text, which silently nukes the output.
            result_text = getattr(result, "text", None)
            if not isinstance(result_text, str):
                # mlx-lm older versions return str directly; fall through
                # to str() as last resort but prefer the attribute.
                result_text = str(result) if not isinstance(result, str) else result
            # Phase 3 wire: prefill_tokens for prefill_exposure_tracker
            # cross-request panic correlation (Wave A consumer, mlx#3186
            # delayed-trigger M4 base panic).
            #
            # Avoid the hot-path tokenizer.encode and sanity-gate the value:
            #   1. result.prompt_tokens (mlx-lm GenerateResult 0.21+ gives it)
            #   2. result.input_tokens (older variants)
            #   3. fallback len(formatted) // 4 — **mlx-lm path only**; the
            #      vlm path is skipped because base64/image placeholders
            #      inflate the estimate ~50x
            #   - empty prompt skip
            #   - sanity cap 200K (mlx#3186 hard-block line — anything over
            #     should be caught by oom_precheck, not inflate the budget
            #     tracker)
            _prefill_tokens: int | None = None
            for _attr in ("prompt_tokens", "input_tokens"):
                _val = getattr(result, _attr, None)
                if isinstance(_val, int) and _val > 0:
                    _prefill_tokens = _val
                    break
            if _prefill_tokens is None:
                # vlm path: skip estimate. ``formatted`` contains image
                # base64 / placeholders that would inflate the estimate
                # ~50x; processor.tokenize would be accurate but is too
                # expensive for the hot path.
                if backend == "mlx-vlm":
                    _prefill_tokens = None
                elif not formatted:
                    # empty prompt — health check / probe scenario
                    _prefill_tokens = None
                else:
                    _prefill_tokens = max(1, len(formatted) // 4)
                    # sanity cap — anything over 200K should be caught by
                    # oom_precheck and must not pollute the budget tracker
                    if _prefill_tokens > 200_000:
                        log.warning(
                            "WORKER_GENERATE: prefill estimate %d exceeds "
                            "200K cap, clamping (formatted_chars=%d) — caller "
                            "should run oom_precheck pre-flight",
                            _prefill_tokens, len(formatted),
                        )
                        _prefill_tokens = 200_000
            # Wave A wire #4b: emit the Wave A canonical dict frame —
            # protocol_version + phase + result + nested prefill_payload.
            # The parent's wire #4a recognizes ``protocol_version`` and
            # routes through done_frame.validate_frame + Phase 3 helpers.
            # Env ``MLX_WORKER_LEGACY_FRAMES=1`` reverts the worker to the
            # legacy ``{"type": "result", "text": ...}`` shape for emergency
            # rollback (the parent handles both — legacy still works).
            if os.environ.get("MLX_WORKER_LEGACY_FRAMES") == "1":
                payload: dict[str, Any] = {
                    "type": "result",
                    "text": result_text.strip(),
                }
                if _prefill_tokens is not None:
                    payload["prefill_tokens"] = _prefill_tokens
            else:
                payload = {
                    "protocol_version": 1,
                    "phase": "done",
                    "result": result_text.strip(),
                }
                if _prefill_tokens is not None:
                    payload["prefill_payload"] = {"tokens": _prefill_tokens}
            send_conn.send(payload)
            # Increment AFTER send succeeds. If send raises BrokenPipeError
            # the counter must not advance so the next request (on a new
            # pipe) still triggers the first-gen guard. send failure
            # propagates to the outer except and skips this line.
            generate_call_count += 1
        except Exception as exc:
            # Skip the send if we already responded from the image-prep
            # block — otherwise the parent reads two frames for one request
            # and the entire pipe stream desyncs.
            if not input_error_sent:
                send_conn.send({
                    "type": "error",
                    "error": f"{type(exc).__name__}: {exc}",
                })
        finally:
            # Always clean up temp image files, even on error. Leaking
            # these would accumulate into /tmp over a long-running worker.
            # SIGKILL-based process death is handled by the per-worker
            # OS cleanup since tempfile paths are process-scoped.
            for p in temp_image_paths:
                try:
                    os.unlink(p)
                except OSError:
                    pass

    # Clean exit
    send_conn.send({"type": "shutdown_ack"})


# ---------------------------------------------------------------------------
# Parent-side runner
# ---------------------------------------------------------------------------


class MLXSubprocessRunner:
    """Manage an isolated MLX worker subprocess for a specific model.

    The worker loads the model once and stays alive for multiple generate
    calls. If it crashes (Metal SIGABRT), the parent detects the broken
    pipe and can create a new runner.

    Thread-safe: uses a lock to serialize generate calls (Metal cannot
    handle concurrent generate in a single process anyway).
    """

    def __init__(
        self,
        model_id: str,
        *,
        backend: str = "mlx",
        load_timeout: float = _DEFAULT_LOAD_TIMEOUT,
        generate_timeout: float = _DEFAULT_GENERATE_TIMEOUT,
    ) -> None:
        self.model_id = model_id
        self.backend = backend
        self._load_timeout = load_timeout
        self._generate_timeout = generate_timeout
        self._lock = multiprocessing.Lock()
        self._process: multiprocessing.Process | None = None
        self._parent_send: Connection | None = None
        self._parent_recv: Connection | None = None
        self._worker_pid: int | None = None
        self._worker_started_at: datetime | None = None  # set in _start_worker
        self._started = False
        self._holds_mlx_lock = False
        # Phase 3 wire: prefill_exposure_tracker / worker_rotation surface —
        # track the last threshold we warned at. An env raise of the budget
        # mid-run can drop cumulative back under-budget; a later breach of a
        # new budget should re-emit, so a once-only bool would leave the
        # caller in the dark. None = never warned; a number = the threshold
        # value at the last warn.
        self._prefill_last_warned_threshold: int | None = None
        # Surface for caller poll (batch / generation loops) — does not
        # touch the hot path but lets the caller query the verdict anytime.
        self._prefill_last_verdict: Any = None  # RotationVerdict | None
        # Layer F status surfaced from the worker ready message. Initialised
        # to "pending" so defensive readers / __repr__ / __del__ never hit
        # AttributeError if _start_worker fails before the ready message
        # arrives.
        self.layer_f_status: str = "pending"
        self.layer_f_active_bytes_after_load: int | None = None
        # Peak memory after load — captured for ALL models regardless of
        # Layer F profile presence. Useful for OOM headroom estimation;
        # peak typically exceeds active by 30-50% for large MoE during the
        # alloc burst.
        self.peak_bytes_after_load: int | None = None

        # Wave A wire #2: recovery_lockout pre-spawn gate. Run BEFORE
        # everything else — cheapest check (~1ms file stat + JSON parse) and
        # most fundamental: if a system-wide crash-burst lockout is active,
        # no subsequent pre-spawn work is worth doing. Disable via env
        # ``MLX_RECOVERY_LOCKOUT_GATE_DISABLED=1`` for rollback.
        #
        # Safe-on-I/O-error contract: both ``is_locked_out`` and
        # ``time_remaining`` in recovery_lockout.py catch corrupt JSON,
        # OSError, FileNotFoundError, and ValueError internally — returning
        # ``False`` / ``0`` respectively on any failure. So the only
        # exception this block can leak uncaught is the deliberate
        # ``MLXRecoveryLockedError`` raise (which is the documented contract).
        if os.environ.get(_RECOVERY_LOCKOUT_GATE_DISABLED_ENV) != "1":
            try:
                from metal_guard.recovery_lockout import (
                    MLXRecoveryLockedError as _MLXRecoveryLockedError,
                    is_locked_out as _is_locked_out,
                    time_remaining as _time_remaining,
                )
                if _is_locked_out():
                    remaining = _time_remaining()
                    log.warning(
                        "recovery_lockout active for %s: %ds remaining",
                        model_id, remaining,
                    )
                    raise _MLXRecoveryLockedError(
                        f"recovery lockout active for {model_id}: "
                        f"{remaining}s remaining"
                    )
            except ImportError:
                log.debug(
                    "recovery_lockout import failed; skipping pre-spawn lockout gate for %s",
                    model_id,
                )

        # Wave A wire #1: load_gate pre-spawn check. Run BEFORE
        # ``_start_worker`` so an oversized load short-circuits subprocess
        # startup cost (~hundreds of ms saved per refusal). load_gate is
        # panic_gate-cooldown safe (no mlx.core import) and best-effort
        # (safe-on-skip when probes fail). Disable via env
        # ``MLX_LOAD_GATE_DISABLED=1`` for emergency rollback.
        if os.environ.get(_LOAD_GATE_DISABLED_ENV) != "1":
            try:
                from metal_guard.load_gate import gate_or_raise as _load_gate_or_raise
                _load_gate_or_raise(model_id)
            except ImportError:
                # Defensive — load_gate is part of metal_guard; a missing
                # import means the package is broken. Don't block on
                # degraded deps.
                log.debug(
                    "load_gate import failed; skipping pre-spawn gate for %s",
                    model_id,
                )

        # W13: local-panic-advisory gate. Surfaces the KNOWN_PANIC_MODELS
        # advisory and hard-blocks construction when tier='panic'
        # (machine-rebooting). Lower tiers remain warn-only.
        #
        # Order of operations (load-bearing):
        #   1. Detect gpu_family (defensive — None if mlx not importable)
        #   2. Query advisory (defensive — None if not a registry hit)
        #   3. If tier='panic': hard-block via SpawnRefused unless
        #      METALGUARD_LOCAL_PANIC_MODEL_BLOCK_DISABLED=1 (logged override)
        #   4. Lower tiers: warn-only
        #
        # ImportError on the helper imports → degrade to None advisory,
        # NEVER block (deps missing means we can't make a safe block).
        self.local_panic_advisory = None
        try:
            from metal_guard.panic_registry import check_known_panic_model_for_gpu
            from metal_guard.system_audit import apple_gpu_family
            gpu_info = apple_gpu_family()
            gpu_family = gpu_info.get("family") if gpu_info.get("available") else None
            self.local_panic_advisory = check_known_panic_model_for_gpu(
                model_id, gpu_family=gpu_family,
            )
            if self.local_panic_advisory is not None:
                tier = self.local_panic_advisory.get("tier", "unknown")
                # Public KNOWN_PANIC_MODELS entries use "recommendation"
                # (most entries) or "reason" (newer entries) for the
                # human-readable mitigation text.
                rec = (
                    self.local_panic_advisory.get("recommendation")
                    or self.local_panic_advisory.get("reason")
                    or ""
                )
                # Public schema stores refs under "upstream" (a list).
                refs_raw = self.local_panic_advisory.get("upstream", ())
                refs = tuple(refs_raw) if refs_raw else ()

                # Hard-block path.
                if tier == "panic":
                    override = os.environ.get(_LOCAL_PANIC_BLOCK_DISABLED_ENV) == "1"
                    if override:
                        log.warning(
                            "OVERRIDE: tier='panic' for %s on %s — "
                            "BLOCK DISABLED via %s=1; proceeding (audit). rec=%s",
                            model_id, gpu_family or "?",
                            _LOCAL_PANIC_BLOCK_DISABLED_ENV, rec[:200],
                        )
                        # Emit override audit (best-effort).
                        try:
                            from metal_guard.corpus import append_event
                            append_event(
                                "spawn_override",
                                model_id=model_id,
                                gpu_family=gpu_family,
                                tier=tier,
                                extra={"recommendation": rec[:300]},
                            )
                        except Exception as exc:  # noqa: BLE001 corpus best-effort
                            log.debug("spawn_override corpus emit failed: %s", exc)
                    else:
                        # Emit refusal BEFORE raise so the corpus has the
                        # event even if the caller doesn't catch.
                        try:
                            from metal_guard.corpus import append_event
                            append_event(
                                "spawn_refused",
                                model_id=model_id,
                                gpu_family=gpu_family,
                                tier=tier,
                                extra={"recommendation": rec[:300]},
                            )
                        except Exception as exc:  # noqa: BLE001 corpus best-effort
                            log.debug("spawn_refused corpus emit failed: %s", exc)
                        raise SpawnRefused(
                            model_id=model_id,
                            gpu_family=gpu_family,
                            tier=tier,
                            recommendation=rec,
                            upstream_refs=refs,
                        )
                else:
                    # tier in ('abort', 'degradation', 'unknown') — warn only.
                    log.warning(
                        "MLXSubprocessRunner: known issue tier=%s for %s on %s — %s",
                        tier, model_id, gpu_family or "?", rec[:200],
                    )
        except SpawnRefused:
            # Must propagate. The defensive Exception catch below would
            # otherwise swallow the block (caught self).
            raise
        except ImportError:
            # metal_guard deps missing → degrade silently (cannot safely
            # decide block vs warn without the registry).
            pass
        except Exception as exc:  # noqa: BLE001 defensive on advisory path
            log.debug("local panic advisory check failed: %s", exc)

        # Wire ResourceTracker into generate() so descriptor leak gets
        # accumulated visibility. WARN-only — auto cold-restart logic is
        # deferred; for now the caller reads
        # `runner.resource_tracker.snapshot()` to decide.
        try:
            from metal_guard.resource_tracker import ResourceTracker
            self.resource_tracker = ResourceTracker()
        except ImportError:
            self.resource_tracker = None
        # Track whether we've already warned about the cold-restart
        # threshold — avoid log spam once per runner lifetime.
        self._cold_restart_warned = False

        # Ingest any new kernel-panic reports into the archive, then consult
        # the circuit breaker. We refuse new workers if 2+ panics occurred
        # in the last 24h. Silently skip when the panic_reports helpers are
        # unavailable (test environments that monkey-patch the module).
        try:
            from metal_guard.panic_reports import (
                CircuitBreaker,
                MLXCooldownActive,
                ingest_panics_jsonl,
            )
        except ImportError:
            MLXCooldownActive = None  # type: ignore[assignment]
        else:
            try:
                ingest_panics_jsonl()
            except Exception as exc:  # pragma: no cover — best-effort archive
                log.debug("ingest_panics_jsonl failed: %s", exc)
            try:
                CircuitBreaker().check()
            except MLXCooldownActive:
                # Surface cooldown directly — do NOT take the MLX lock or
                # spawn a worker.
                raise

        # Acquire the cross-process MLX lock BEFORE spawning the worker.
        # Without this, any concurrent MLX acquirer (a second bench CLI, an
        # acceptance test) can legally overwrite the lock mid-run while we
        # are still holding Metal buffers. Two processes sharing IOGPU = the
        # IOGPUMemory.cpp:492 kernel-panic path (see CHANGELOG for the
        # 2026-04-15 incident).
        acquire_mlx_lock(f"mlx_subprocess_runner:{self.model_id}")
        self._holds_mlx_lock = True

        try:
            self._start_worker()
        except BaseException:
            # Worker failed to load / timed out — release the lock so the
            # next caller is not locked out by a dead runner.
            self._release_mlx_lock_if_held()
            raise

    def _start_worker(self) -> None:
        """Fork the worker subprocess and wait for 'ready' signal."""
        # Create two unidirectional pipes for clean separation
        parent_recv, child_send = multiprocessing.Pipe(duplex=False)
        child_recv, parent_send = multiprocessing.Pipe(duplex=False)

        self._parent_send = parent_send
        self._parent_recv = parent_recv

        self._process = multiprocessing.Process(
            target=_worker_main,
            args=(self.model_id, self.backend, child_recv, child_send),
            daemon=True,
        )
        self._process.start()
        log.info(
            "MLXSubprocessRunner: started worker pid=%d for %s",
            self._process.pid, self.model_id,
        )

        # Wait for 'ready' or 'error'
        if not parent_recv.poll(timeout=self._load_timeout):
            self.kill()
            raise SubprocessTimeoutError(
                f"Worker for {self.model_id} did not respond within "
                f"{self._load_timeout}s during model load"
            )

        msg = parent_recv.recv()
        if msg.get("type") == "error":
            self.kill()
            raise RuntimeError(
                f"Worker for {self.model_id} failed to load: {msg.get('error')}"
            )
        if msg.get("type") == "ready":
            self._worker_pid = msg.get("pid")
            self._started = True
            # Phase 3 wire: capture spawn time as a generation discriminator
            # for prefill_exposure_tracker (pid recycle safe). tz-aware
            # datetime REQUIRED — the tracker raises ValueError on naive.
            self._worker_started_at = datetime.now(timezone.utc)
            # Layer F status surfaced from the worker. "applied" means
            # set_memory_limit succeeded. Anything else the caller may need
            # to know about — expose as an attribute.
            self.layer_f_status = msg.get("layer_f_status", "unknown")
            self.layer_f_active_bytes_after_load = msg.get(
                "layer_f_active_bytes_after_load"
            )
            self.peak_bytes_after_load = msg.get("peak_bytes_after_load")
            log.info(
                "MLXSubprocessRunner: worker pid=%d ready for %s "
                "(layer_f=%s active_after_load=%s peak_after_load=%s)",
                self._worker_pid, self.model_id,
                self.layer_f_status, self.layer_f_active_bytes_after_load,
                self.peak_bytes_after_load,
            )

    def generate(
        self,
        prompt: str,
        *,
        max_tokens: int = 4096,
        temperature: float = 0.3,
        system: str = "",
        timeout: float | None = None,
        images_b64: list[str] | None = None,
    ) -> str:
        """Send a prompt to the worker and return the generated text.

        Args:
            images_b64: Optional list of base64-encoded image bytes. Only
                meaningful when ``backend == "mlx-vlm"``. For ``mlx`` /
                ``mlx-lm`` text backends the images are forwarded but
                ignored by the worker. Without this the subprocess path
                silently drops images and causes every vision call to
                produce empty output (see CHANGELOG).

        Raises:
            SubprocessCrashError: Worker process died (SIGABRT, etc.)
            SubprocessTimeoutError: Worker did not respond in time
            RuntimeError: Worker returned an error
        """
        if not self.is_alive():
            raise SubprocessCrashError(
                self.model_id,
                self._process.exitcode if self._process else None,
                "worker not alive at generate() entry",
            )

        effective_timeout = timeout if timeout is not None else self._generate_timeout

        with self._lock:
            payload: dict[str, Any] = {
                "type": "generate",
                "prompt": prompt,
                "max_tokens": max_tokens,
                "temperature": temperature,
                "system": system,
            }
            if images_b64:
                # Only include the `images` key when there are actual
                # images — keeps the pipe payload small for text-only
                # traffic and makes it obvious in tracing which calls
                # carry vision data.
                payload["images"] = list(images_b64)
            try:
                self._parent_send.send(payload)
            except (BrokenPipeError, OSError) as exc:
                raise SubprocessCrashError(
                    self.model_id,
                    self._process.exitcode if self._process else None,
                    f"send failed: {exc}",
                ) from exc

            # Wave A wire #3b: sentinel-aware select.select sigchld arm.
            # Catches process death without pipe-close (rare SIGKILL
            # pre-flush) in ≤200ms vs the legacy 300s effective_timeout.
            #
            # Fallback to legacy ``parent_recv.poll(timeout)`` when:
            #   - env ``MLX_CHILD_DEATH_DETECT_DISABLED=1`` (rollback)
            #   - sentinel is invalid (< 0 or non-int — test mocks /
            #     partial init) so existing wire #3a fixtures with
            #     ``sentinel = -1`` keep working.
            _sentinel = (
                self._process.sentinel if self._process is not None else None
            )
            # The ``_sentinel >= 0`` gate is the load-bearing mechanism that
            # keeps wire #3a (legacy poll fixtures with ``sentinel=-1``) and
            # wire #3b (sentinel-aware select fixtures with ``sentinel>=0``)
            # on separate code paths. If a future refactor drops the
            # ``>= 0`` guard, wire #3a tests will silently start exercising
            # the wire #3b path and may mask regressions.
            # Two env knobs disable wire #3b (either fires legacy fallback):
            #   - ``MLX_CHILD_DEATH_DETECT_DISABLED=1`` shared with wire #3a
            #     (rolls back BOTH arms together — emergency umbrella switch)
            #   - ``MLX_SENTINEL_DETECT_DISABLED=1`` finer-grained — disables
            #     the sigchld arm only; the wire #3a EOF arm keeps working
            _sigchld_active = (
                os.environ.get(_CHILD_DEATH_DETECT_DISABLED_ENV) != "1"
                and os.environ.get(_SENTINEL_DETECT_DISABLED_ENV) != "1"
                and isinstance(_sentinel, int)
                and _sentinel >= 0
            )
            if _sigchld_active:
                _recv_fd = self._parent_recv.fileno()
                try:
                    _ready, _, _ = select.select(
                        [_recv_fd, _sentinel], [], [], effective_timeout
                    )
                except (OSError, ValueError) as _sel_exc:
                    # A bare select.select can raise EBADF if recv_fd or
                    # sentinel becomes invalid mid-call (e.g. the process
                    # reaper closed the sentinel). Treat as sigchld
                    # detection — the process is gone, so force the same
                    # crash path so the caller sees SubprocessCrashError
                    # not a bare OSError.
                    log.debug(
                        "select.select raised %s for %s; forcing sigchld path",
                        type(_sel_exc).__name__, self.model_id,
                    )
                    _ready = [_sentinel]  # synthesize sentinel-only ready
                    _recv_fd = -1  # ensure recv_fd not in _ready
                if not _ready:
                    log.error(
                        "MLXSubprocessRunner: worker pid=%s timed out after %.0fs for %s",
                        self._worker_pid, effective_timeout, self.model_id,
                    )
                    self.kill()
                    raise SubprocessTimeoutError(
                        f"Worker for {self.model_id} did not respond within "
                        f"{effective_timeout}s"
                    )
                if _recv_fd not in _ready:
                    # sentinel ready, recv_fd NOT — the process died without
                    # flushing the pipe (rare SIGKILL race). Cross-spec wire
                    # parallels wire #3a EOF arm: emit early-death corpus
                    # event + trigger recovery_lockout BEFORE re-raise.
                    #
                    # kill() called BEFORE raise is intentional here (the
                    # process is already dead, eager cleanup is correct).
                    # Wire #3a's recv() EOFError path does NOT call kill()
                    # because a pipe-close may indicate a graceful shutdown
                    # where the process is still cleaning up (caller
                    # decides). The asymmetry is by design — this arm has
                    # stronger evidence (a kernel sentinel signal) that the
                    # process is gone.
                    _exitcode = self._process.exitcode if self._process else None
                    _signal_or_status = (
                        _signal_name_from_exitcode(_exitcode)
                    )
                    try:
                        from metal_guard import corpus as _pc
                        _pc.emit_event(
                            event_kind="subprocess_early_death",
                            payload={
                                "model_id": self.model_id,
                                "pid": self._worker_pid,
                                "detection_path": "sigchld",
                                "signal_or_status": _signal_or_status,
                                "exitcode": _exitcode,
                            },
                        )
                    except Exception as _emit_exc:
                        log.debug(
                            "subprocess_early_death sigchld emit failed for %s: %s",
                            self.model_id, _emit_exc,
                        )
                    try:
                        from metal_guard import recovery_lockout as _rl
                        _rl.trigger_crash_lockout(
                            reason=f"early_death_sigchld_{self.model_id}",
                        )
                    except Exception as _trig_exc:
                        log.debug(
                            "recovery_lockout sigchld trigger failed for %s: %s",
                            self.model_id, _trig_exc,
                        )
                    self.kill()
                    raise SubprocessCrashError(
                        self.model_id,
                        _exitcode,
                        f"sigchld detected (signal_or_status={_signal_or_status})",
                    )
                # _recv_fd in ready (with or without sentinel) → fall through
                # to recv() below. The existing wire #3a EOFError catch
                # handles the graceful pipe-close case.
            elif not self._parent_recv.poll(timeout=effective_timeout):
                # Legacy fallback path (env disabled or invalid sentinel).
                log.error(
                    "MLXSubprocessRunner: worker pid=%s timed out after %.0fs for %s",
                    self._worker_pid, effective_timeout, self.model_id,
                )
                self.kill()
                raise SubprocessTimeoutError(
                    f"Worker for {self.model_id} did not respond within "
                    f"{effective_timeout}s"
                )

            try:
                msg = self._parent_recv.recv()
            except (EOFError, OSError) as exc:
                # Wave A wire #3a: cross-spec wire to recovery_lockout +
                # corpus. The existing crash path now ALSO emits
                # ``subprocess_early_death`` event + triggers
                # recovery_lockout so a future same-invocation retry walks
                # the fallback chain past this locked-out mlx tier.
                # Best-effort: failures swallowed at log.debug to never
                # break the documented SubprocessCrashError contract.
                #
                # Order: emit BEFORE trigger (forensics-first surface —
                # corpus has subprocess_early_death first, then any
                # internal events from trigger_crash_lockout). NOTE for
                # caller-e2e tests: filter on event_kind in
                # ``call_args_list``, not ``call_args`` (last), because if
                # real recovery_lockout fires its own corpus event the
                # last-call would be that event.
                # Read exitcode ONCE at the top of the block so the corpus
                # event payload and the SubprocessCrashError below carry
                # identical values — two ``self._process.exitcode`` reads
                # otherwise have a microsecond window where the kernel
                # could update exitcode between them (autopsy forensic
                # consistency risk).
                _exitcode = self._process.exitcode if self._process else None
                if os.environ.get(_CHILD_DEATH_DETECT_DISABLED_ENV) != "1":
                    try:
                        from metal_guard import corpus as _pc
                        _pc.emit_event(
                            event_kind="subprocess_early_death",
                            payload={
                                "model_id": self.model_id,
                                "pid": self._worker_pid,
                                "detection_path": "pipe_eof",
                                "signal_or_status": (
                                    "pipe_closed"
                                    if isinstance(exc, EOFError)
                                    else f"os_error:{type(exc).__name__}"
                                ),
                                "exitcode": _exitcode,
                            },
                        )
                    except Exception as _emit_exc:
                        log.debug(
                            "subprocess_early_death emit failed for %s: %s",
                            self.model_id, _emit_exc,
                        )
                    try:
                        from metal_guard import recovery_lockout as _rl
                        _rl.trigger_crash_lockout(
                            reason=(
                                f"early_death_pipe_eof_{self.model_id}"
                            ),
                        )
                    except Exception as _trig_exc:
                        log.debug(
                            "recovery_lockout trigger failed for %s: %s",
                            self.model_id, _trig_exc,
                        )
                raise SubprocessCrashError(
                    self.model_id,
                    _exitcode,
                    f"recv failed (worker likely crashed): {exc}",
                ) from exc

        # Wave A wire #4a: parent-side protocol_version recognition. When
        # the worker emits a dict with ``protocol_version``, validate via
        # done_frame and return ``msg["result"]``. Pre-#4b workers never set
        # ``protocol_version`` → fall through to the existing
        # ``msg.get("type") == "result"`` legacy dispatch below. Disabled
        # when ``MLX_DONE_FRAME_WIRE_DISABLED=1`` (rollback path).
        if (
            isinstance(msg, dict)
            and "protocol_version" in msg
            and os.environ.get(_DONE_FRAME_WIRE_DISABLED_ENV) != "1"
        ):
            try:
                from metal_guard.done_frame import (
                    FrameProtocolMismatch as _FrameProtocolMismatch,
                    InvalidFrame as _InvalidFrame,
                    validate_frame as _validate_frame,
                )
                _validate_frame(msg)  # raises InvalidFrame / FrameProtocolMismatch
                _phase = msg.get("phase")
                if _phase == "done":
                    # Wave A wire #4b: the Phase 3 helpers must fire for
                    # protocol_version frames too. Synthesize a legacy-shape
                    # compat msg lifting ``prefill_payload.tokens`` to a
                    # top-level ``prefill_tokens`` so the existing helper's
                    # ``msg.get("prefill_tokens")`` lookup works unchanged.
                    _prefill_payload = msg.get("prefill_payload") or {}
                    _legacy_compat = {
                        "type": "result",
                        "text": msg["result"],
                        "prefill_tokens": _prefill_payload.get("tokens"),
                    }
                    self._record_prefill_and_check_rotation(_legacy_compat)
                    if self.resource_tracker is not None:
                        self.resource_tracker.record_inference()
                        if (
                            not self._cold_restart_warned
                            and self.resource_tracker.should_cold_restart()
                        ):
                            _snap = self.resource_tracker.snapshot()
                            log.warning(
                                "MLXSubprocessRunner[%s]: resource_tracker hit "
                                "cold-restart threshold (%d/%d, %.0f%%); caller "
                                "should shutdown() + spawn new runner to release "
                                "Metal descriptors (mlx-lm#1185)",
                                self.model_id,
                                _snap["current_count"],
                                _snap["threshold"],
                                _snap["fraction_used"] * 100,
                            )
                            self._cold_restart_warned = True
                    return msg["result"]
                if _phase == "error":
                    raise RuntimeError(
                        f"Worker error for {self.model_id}: "
                        f"{msg.get('msg', msg.get('error_kind', 'unknown'))}"
                    )
                # progress / request phases unexpected at this recv site;
                # fall through to legacy dispatch which will raise
                # "Unexpected".
            except _FrameProtocolMismatch:
                # Propagate; validate_frame already emitted the
                # frame_protocol_mismatch corpus event before raising.
                raise
            except _InvalidFrame:
                raise
            except ImportError:
                log.debug(
                    "done_frame import failed; skipping wire #4a validation for %s",
                    self.model_id,
                )

        if msg.get("type") == "result":
            # Phase 3 wire: helper-based for testability — keeping the logic
            # in a helper lets tests call the production code path directly
            # rather than copying inline logic (drift risk).
            self._record_prefill_and_check_rotation(msg)
            # ResourceTracker wired into the generate() success path. Counts
            # inferences-since-cold-restart; heuristic threshold 4000 (env
            # override). On hit, log a warning once — the caller is expected
            # to inspect `runner.resource_tracker.snapshot()` and call
            # `runner.shutdown()` + create a new runner for a cold restart.
            # Auto-restart is NOT done here because the parent owns the
            # lifecycle (auto-shutdown would surprise callers mid-batch).
            if self.resource_tracker is not None:
                self.resource_tracker.record_inference()
                if (
                    not self._cold_restart_warned
                    and self.resource_tracker.should_cold_restart()
                ):
                    snap = self.resource_tracker.snapshot()
                    log.warning(
                        "MLXSubprocessRunner[%s]: resource_tracker hit "
                        "cold-restart threshold (%d/%d, %.0f%%); caller "
                        "should shutdown() + spawn new runner to release "
                        "Metal descriptors (mlx-lm#1185)",
                        self.model_id,
                        snap["current_count"],
                        snap["threshold"],
                        snap["fraction_used"] * 100,
                    )
                    self._cold_restart_warned = True
            return msg["text"]
        if msg.get("type") == "error":
            raise RuntimeError(
                f"Worker error for {self.model_id}: {msg.get('error')}"
            )
        raise RuntimeError(f"Unexpected message from worker: {msg}")

    def _record_prefill_and_check_rotation(self, msg: dict) -> None:
        """Wire helper — record prefill + poll rotation verdict.

        Called by the generate() success path. Best-effort, never raises
        into the caller. The env kill-switch
        ``METALGUARD_PREFILL_WIRE_DISABLED=1`` skips the entire wire and
        clears the stale verdict to prevent a caller misread. Re-emits a
        warning if the budget threshold changes mid-run, up OR down.

        **Threading contract**: ``should_rotate`` / ``rotation_verdict`` /
        ``generate`` MUST be called from the same thread; cleanup races the
        verdict clear against a caller poll if multi-threaded. Caller-side
        guard via a batch loop or an explicit lock.
        """
        if os.environ.get("METALGUARD_PREFILL_WIRE_DISABLED") == "1":
            # Clear the stale verdict so a caller poll does not see the
            # previous True.
            self._prefill_last_verdict = None
            return
        if self._worker_started_at is None or self._worker_pid is None:
            return
        _prefill = msg.get("prefill_tokens")
        if isinstance(_prefill, int) and _prefill > 0:
            try:
                from metal_guard.prefill_exposure_tracker import record_prefill
                record_prefill(
                    worker_pid=self._worker_pid,
                    worker_started_at=self._worker_started_at,
                    prefill_tokens=_prefill,
                    model_id=self.model_id,
                )
            except Exception as _e:  # noqa: BLE001 best-effort tracker
                log.debug("record_prefill failed: %s", _e)
        # rotation verdict — re-emit if the threshold CHANGES (up or down)
        # since the last warn; a tightened budget is also worth a forensic
        # emit.
        try:
            from metal_guard.worker_rotation import should_rotate_worker
            verdict = should_rotate_worker(
                worker_pid=self._worker_pid,
                worker_started_at=self._worker_started_at,
            )
            self._prefill_last_verdict = verdict
            if verdict.should_rotate:
                last = self._prefill_last_warned_threshold
                if last is None or verdict.threshold != last:
                    direction = (
                        "first" if last is None
                        else "tightened" if verdict.threshold < last
                        else "raised"
                    )
                    log.warning(
                        "MLXSubprocessRunner[%s]: prefill rotation "
                        "recommended (%s threshold) — reason=%s cum_tokens=%d "
                        "threshold=%d (was %s) worker_pid=%d. Caller should "
                        "shutdown() + spawn new worker (mlx#3186 "
                        "delayed-trigger panic defense).",
                        self.model_id, direction, verdict.reason,
                        verdict.cumulative_tokens, verdict.threshold,
                        last, self._worker_pid,
                    )
                    self._prefill_last_warned_threshold = verdict.threshold
        except Exception as _e:  # noqa: BLE001 best-effort
            log.debug("should_rotate_worker poll failed: %s", _e)

    @property
    def should_rotate(self) -> bool:
        """Caller-poll surface — a caller batch loop reads this between
        generates to decide rotation. Returns False if the wire is disabled,
        the worker is not ready, or there is no breach yet. Never raises.

        **Note**: the verdict reflects state AFTER the last generate;
        pre-flight panic prevention must go through oom_precheck rather than
        should_rotate (race window: caller polls False → generate 5K → cum
        crosses the threshold → caller polls True, but the panic may already
        have fired during that generate).

        **Threading**: must be called from the same thread as generate().
        """
        if os.environ.get("METALGUARD_PREFILL_WIRE_DISABLED") == "1":
            return False
        v = self._prefill_last_verdict
        return bool(getattr(v, "should_rotate", False))

    def rotation_verdict(self) -> "RotationVerdict | None":
        """Full RotationVerdict from the last generate.

        Returns None if the wire is disabled / there is no generate yet / a
        lookup race. Caller inspects: ``.should_rotate``
        ``.cumulative_tokens`` ``.threshold`` ``.reason`` ``.worker_pid``
        ``.worker_started_at``. Never raises.

        **Threading**: must be called from the same thread as generate().
        """
        if os.environ.get("METALGUARD_PREFILL_WIRE_DISABLED") == "1":
            return None
        return self._prefill_last_verdict

    def is_alive(self) -> bool:
        """Check if the worker subprocess is still running."""
        return self._process is not None and self._process.is_alive()

    def shutdown(self, timeout: float = 10.0) -> None:
        """Gracefully shut down the worker subprocess."""
        if self._process is None:
            return
        if not self._process.is_alive():
            self._cleanup()
            return

        try:
            self._parent_send.send({"type": "shutdown"})
        except (BrokenPipeError, OSError):
            pass

        self._process.join(timeout=timeout)
        if self._process.is_alive():
            log.warning(
                "MLXSubprocessRunner: worker pid=%s did not exit gracefully, killing",
                self._worker_pid,
            )
            self._process.kill()
            self._process.join(timeout=5)

        self._cleanup()
        log.info("MLXSubprocessRunner: worker for %s shut down", self.model_id)

    def kill(self) -> None:
        """Force-kill the worker subprocess."""
        if self._process is not None and self._process.is_alive():
            self._process.kill()
            self._process.join(timeout=5)
        self._cleanup()

    def _cleanup(self) -> None:
        """Close pipes, clear references, and release the MLX lock."""
        # Phase 3 wire: forget_worker strict generation match. MUST run
        # before clearing _worker_pid / _worker_started_at so the tracker
        # gets the correct (pid, started_at) tuple. Best-effort — never
        # raises.
        if (
            os.environ.get("METALGUARD_PREFILL_WIRE_DISABLED") != "1"
            and self._worker_pid is not None
            and self._worker_started_at is not None
        ):
            try:
                from metal_guard.prefill_exposure_tracker import forget_worker
                forget_worker(
                    worker_pid=self._worker_pid,
                    worker_started_at=self._worker_started_at,
                )
            except Exception as _e:  # noqa: BLE001 best-effort
                log.debug("forget_worker failed: %s", _e)

        for conn in (self._parent_send, self._parent_recv):
            if conn is not None:
                try:
                    conn.close()
                except OSError:
                    pass
        self._parent_send = None
        self._parent_recv = None
        self._process = None
        self._worker_pid = None
        self._worker_started_at = None
        self._started = False
        self._prefill_last_warned_threshold = None
        self._prefill_last_verdict = None
        self._release_mlx_lock_if_held()

    def _release_mlx_lock_if_held(self) -> None:
        """Release the MLX lock if this runner acquired it. Idempotent.

        Best-effort: ``release_mlx_lock`` never raises, so we can safely
        call this from ``__del__``, error handlers, and normal cleanup
        paths without masking the original failure.
        """
        if not self._holds_mlx_lock:
            return
        try:
            release_mlx_lock()
        except Exception as exc:  # pragma: no cover — defensive
            log.warning(
                "MLXSubprocessRunner: release_mlx_lock failed for %s: %s",
                self.model_id, exc,
            )
        self._holds_mlx_lock = False

    @property
    def worker_pid(self) -> int | None:
        """PID of the worker subprocess, or None if not running."""
        return self._worker_pid if self.is_alive() else None

    def __del__(self) -> None:
        try:
            self.kill()
        except Exception:
            pass

    def __repr__(self) -> str:
        alive = "alive" if self.is_alive() else "dead"
        return (
            f"MLXSubprocessRunner(model={self.model_id!r}, "
            f"pid={self._worker_pid}, {alive})"
        )


# ---------------------------------------------------------------------------
# Convenience: auto-managed runner pool
# ---------------------------------------------------------------------------


_runner_pool: dict[str, MLXSubprocessRunner] = {}
# The pool dict is a per-process module global (it does not cross processes).
# A multiprocessing.Lock would cross processes but the dict does not — that
# surface mismatch misleads readers and introduces unnecessary cross-process
# contention (after a fork each child owns its own copy of the lock anyway).
# A per-process threading.Lock is the correct fit.
import threading as _threading
_pool_lock = _threading.Lock()


def call_model_isolated(
    prompt: str,
    model: str,
    *,
    backend: str = "mlx",
    max_tokens: int = 4096,
    temperature: float = 0.3,
    system: str = "",
    timeout: float | None = None,
    images_b64: list[str] | None = None,
) -> str:
    """Like ``call_model`` but runs MLX inference in a subprocess.

    Automatically manages a pool of worker subprocesses — one per model.
    If a worker crashes (Metal SIGABRT), it is replaced on the next call.

    Args:
        images_b64: Optional list of base64-encoded images for mlx-vlm
            backends. Without this the subprocess path silently drops
            vision inputs, which makes every vision call produce empty
            output.

    Returns an empty string on crash, matching the error-handling
    convention of direct in-process calls.
    """
    key = f"{model}:{backend}"

    with _pool_lock:
        runner = _runner_pool.get(key)
        if runner is not None and not runner.is_alive():
            exitcode = runner._process.exitcode if runner._process else None
            log.warning(
                "call_model_isolated: previous worker for %s crashed "
                "(exitcode=%s), creating new one",
                model, exitcode,
            )
            runner.kill()
            runner = None

        if runner is None:
            try:
                runner = MLXSubprocessRunner(model, backend=backend)
                _runner_pool[key] = runner
            except SubprocessTimeoutError as exc:
                log.error("call_model_isolated: failed to start worker for %s: %s", model, exc)
                return ""
            except RuntimeError as exc:
                # MLXCooldownActive (the circuit breaker) is also a
                # RuntimeError. Surface it prominently so the operator knows
                # why MLX is idle.
                try:
                    from metal_guard.panic_reports import MLXCooldownActive
                    if isinstance(exc, MLXCooldownActive):
                        log.error(
                            "call_model_isolated: MetalGuard cooldown active — "
                            "%s (refusing to spawn worker for %s)", exc, model,
                        )
                        return ""
                except ImportError:
                    pass
                log.error("call_model_isolated: failed to start worker for %s: %s", model, exc)
                return ""

    try:
        result = runner.generate(
            prompt,
            max_tokens=max_tokens,
            temperature=temperature,
            system=system,
            timeout=timeout,
            images_b64=images_b64,
        )
    except SubprocessCrashError as exc:
        log.error("call_model_isolated: %s", exc)
        with _pool_lock:
            runner.kill()
            _runner_pool.pop(key, None)
        return ""
    except SubprocessTimeoutError as exc:
        log.error("call_model_isolated: %s", exc)
        with _pool_lock:
            runner.kill()
            _runner_pool.pop(key, None)
        return ""

    # Caller-side wire: auto-rotate when the prefill_exposure_tracker reports
    # that the worker has crossed the budget threshold (the mlx#3186
    # cross-request delayed-trigger M4 base panic defense). Wired once at the
    # high-level entry — individual callers do not need to change code.
    #
    # Design:
    # - rotate = pop the pool (fast, inside the lock) + shutdown the runner
    #   (OUTSIDE the lock to avoid a ~15s block on concurrent callers); the
    #   next call automatically spawns a fresh worker
    # - the current result is already obtained — rotation is "the next call
    #   uses a new worker" and does not affect this return
    # - race window: during this generate, if the prefill already crossed
    #   the budget the worker may still panic (a single-request burst); this
    #   wire is effective for the cross-request case but not for a single
    #   burst; a caller wanting to block a single burst must use
    #   ``precheck_inference``
    #
    # **Env truth-table**:
    # - METALGUARD_PREFILL_WIRE_DISABLED=1: the whole wire stops (the worker
    #   does not emit prefill_tokens, the parent does not record, the verdict
    #   is always None)
    # - METALGUARD_AUTO_ROTATE_DISABLED=1: the tracker still emits (forensics
    #   OK), but call_model_isolated does not perform the rotation; the
    #   caller can still read should_rotate itself
    # - neither env set = auto-rotate enabled by default
    _wire_disabled = (
        os.environ.get("METALGUARD_PREFILL_WIRE_DISABLED") == "1"
        or os.environ.get("METALGUARD_AUTO_ROTATE_DISABLED") == "1"
    )
    if not _wire_disabled:
        try:
            if runner.should_rotate:
                # Poll pool ownership + emit the started event inside the
                # lock so a concurrent caller B that enters the lock after A
                # popped sees the runner already swapped → it silently skips
                # and does not double-emit the started event (forensic
                # noise). The pop stays inside the lock (fast); the shutdown
                # runs outside the lock to avoid the ~15s block.
                _common_extra: dict | None = None
                popped = None
                with _pool_lock:
                    if _runner_pool.get(key) is runner:
                        verdict = runner.rotation_verdict()
                        cum = getattr(verdict, "cumulative_tokens", None)
                        threshold = getattr(verdict, "threshold", None)
                        reason = getattr(verdict, "reason", None) or "unknown"
                        v_pid = getattr(verdict, "worker_pid", None)
                        v_started = getattr(verdict, "worker_started_at", None)
                        v_started_iso = (
                            v_started.isoformat() if v_started else None
                        )
                        _common_extra = {
                            "reason": str(reason),
                            "cumulative_tokens": cum,
                            "threshold": threshold,
                            "trigger": "call_model_isolated",
                            "backend": backend,
                            "worker_pid": v_pid,
                            "worker_started_at": v_started_iso,
                        }
                        log.warning(
                            "call_model_isolated: auto-rotating worker for %s "
                            "(backend=%s pid=%s) — reason=%s cum_tokens=%s "
                            "threshold=%s; next call will spawn fresh worker "
                            "(mlx#3186 defense)",
                            model, backend, v_pid, reason, cum, threshold,
                        )
                        try:
                            from metal_guard.corpus import append_event
                            append_event(
                                "auto_rotation_started",
                                model_id=model,
                                extra=_common_extra,
                            )
                        except Exception as _e:  # noqa: BLE001
                            log.debug("auto_rotation_started corpus emit failed: %s", _e)
                        popped = _runner_pool.pop(key)
                    else:
                        # A concurrent caller already swapped the pool —
                        # silently skip without emitting.
                        log.debug("auto-rotate: pool already swapped for %s, skip", model)
                # After the in-lock guard, ``popped is None`` means a
                # concurrent caller already swapped the pool (no started
                # event emitted), so the whole shutdown / event emit is
                # skipped. The race_noop event kind stays reserved in
                # EVENT_KINDS for any future fallback scenario (e.g. a
                # legacy caller path that does not go through the in-lock
                # guard).
                if popped is None:
                    pass  # silent skip — pool already swapped
                else:
                    shutdown_ok = False
                    shutdown_err: str | None = None
                    raised: BaseException | None = None
                    # Catch BaseException so KeyboardInterrupt / SystemExit
                    # also emit the failed event before re-raising — the
                    # autopsy must see a dangling started → failed, not a
                    # started with no resolution.
                    try:
                        popped.shutdown()
                        shutdown_ok = True
                    except Exception as _e:  # noqa: BLE001 best-effort
                        shutdown_err = repr(_e)
                        log.warning("shutdown during auto-rotate failed: %s", _e)
                        try:
                            popped.kill()
                            shutdown_ok = True
                        except Exception as _ke:  # noqa: BLE001
                            shutdown_err = f"{shutdown_err}; kill: {_ke!r}"
                    except BaseException as _be:  # KeyboardInterrupt / SystemExit
                        shutdown_err = f"interrupted: {type(_be).__name__}"
                        raised = _be

                    # emit forensic event
                    try:
                        from metal_guard.corpus import append_event
                        if shutdown_ok:
                            append_event(
                                "auto_rotation_completed",
                                model_id=model,
                                extra=_common_extra,
                            )
                        else:
                            append_event(
                                "auto_rotation_shutdown_failed",
                                model_id=model,
                                extra={**_common_extra, "error": shutdown_err},
                            )
                    except Exception as _e:  # noqa: BLE001
                        log.debug("rotation completion event emit failed: %s", _e)

                    if raised is not None:
                        # Emit first, then re-raise the interrupt signal.
                        raise raised
        except Exception as _e:  # noqa: BLE001 — never block result return
            log.debug("auto-rotate check failed: %s", _e)

    return result


def shutdown_all_workers() -> None:
    """Gracefully shut down all worker subprocesses in the pool."""
    with _pool_lock:
        for key, runner in list(_runner_pool.items()):
            runner.shutdown()
        _runner_pool.clear()
