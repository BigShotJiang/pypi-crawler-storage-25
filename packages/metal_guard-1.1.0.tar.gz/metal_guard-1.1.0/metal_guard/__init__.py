"""MetalGuard — GPU safety layer for MLX on Apple Silicon.

Centralized workaround for the IOGPUFamily driver bug that causes kernel
panics (completeMemory() prepare count underflow @IOGPUMemory.cpp:492)
instead of graceful process termination when Metal GPU memory management
fails on Apple Silicon.

This affects any workload that repeatedly loads and unloads MLX models —
the Metal driver's internal reference count can underflow when GPU buffers
are freed while inference threads are still running, or when cleanup
operations race with lazy evaluation.

Reference: https://github.com/ml-explore/mlx-lm/issues/883

Usage:
    from metal_guard import metal_guard

    metal_guard.register_thread(thread)        # track GPU-bound threads
    metal_guard.wait_for_threads()             # before any mx.clear_cache()
    metal_guard.safe_cleanup()                 # wait -> gc -> flush -> cooldown
    metal_guard.ensure_headroom(model_name=m)  # memory pressure check
    metal_guard.breadcrumb("LOAD: ... START")  # crash-safe forensics

Phase 1 refactor (v0.13.0): the former single-file ``metal_guard.py`` is
now a package of 17 focused submodules. This ``__init__`` is a re-export
facade — ``import metal_guard`` / ``from metal_guard import X`` /
``metal_guard.X`` attribute access are unchanged. ``__all__`` below is the
locked public API surface. 0 breaking changes.

License: MIT
"""
from __future__ import annotations

# _constants FIRST — importing it runs the AGX env import-time side-effect
# exactly once, before any other submodule touches os.environ.
from metal_guard._constants import T, __version__, log

from metal_guard.error_classifier import (
    ErrorClass,
    classify_mlx_error,
    detect_panic_signature,
    is_kernel_panic_signature,
    is_process_abort_signature,
)
from metal_guard.memory import (
    MemoryStats,
    MetalOOMError,
    kv_cache_clear_on_pressure,
)
from metal_guard.guard import MetalGuard, metal_guard
from metal_guard.mlx_lock import (
    MLXLockConflict,
    acquire_mlx_lock,
    mlx_exclusive_lock,
    read_mlx_lock,
    release_mlx_lock,
)
from metal_guard.version_advisories import (
    check_version_advisories,
    install_upstream_defensive_patches,
)
from metal_guard.system_audit import (
    apple_gpu_family,
    audit_wired_limit,
    bench_scoped_load,
    log_system_audit_at_startup,
    read_gpu_driver_version,
)
from metal_guard.process_mode import (
    DEFENSIVE,
    OBSERVER,
    ProcessMode,
    apply_mode_defaults,
    check_observer_requirements,
    current_mode,
    describe_mode,
    describe_process_mode,
    detect_process_mode,
    is_defensive,
    is_observer,
)
from metal_guard.panic_registry import (
    KNOWN_PANIC_MODELS,
    MLX_LM_VERSION_BLOCKLIST,
    MLX_VERSION_BLOCKLIST,
    WORKLOAD_ADVISORIES,
    check_known_panic_model,
    check_known_panic_model_for_gpu,
    check_mlx_lm_version_blocked,
    check_mlx_version_blocked,
    check_workload_advisory,
    models_affecting_gpu_family,
    models_by_tier,
    warn_if_known_panic_model,
)
from metal_guard.cadence import (
    GEMMA4_MIN_CROSS_MODEL_INTERVAL_SEC,
    CadenceGuard,
    CadenceViolation,
    CrossModelCadenceViolation,
    require_cadence_clear,
)
from metal_guard.prefill import (
    KNOWN_MODELS,
    KVGrowthTracker,
    ModelDims,
    describe_prefill_plan,
    estimate_prefill_peak_alloc_gb,
    kv_tracker,
    lookup_dims,
    recommend_chunk_size,
    require_prefill_fit,
)
from metal_guard.panic_reports import (
    CircuitBreaker,
    MLXCooldownActive,
    format_panic_for_apple_feedback,
    gemma4_generation_flush,
    ingest_panics_jsonl,
    parse_panic_reports,
    subprocess_inference_guard,
)
from metal_guard.panic_gate import (
    PANIC_REPORTS_GLOBS,
    AbortRecord,
    CooldownVerdict,
    PanicRecord,
    ack_panic_lockout,
    clear_panic_ack,
    clear_panic_sentinel,
    evaluate_panic_cooldown,
    mark_panic_sentinel_cooldown,
    scan_recent_aborts,
    scan_recent_panics,
)
from metal_guard.forensics import (
    STATUS_SNAPSHOT_SCHEMA_VERSION,
    OrphanPre,
    get_status_snapshot,
    run_postmortem,
    scan_orphan_subproc_pre,
    write_status_snapshot,
)
from metal_guard.subprocess_runner import (
    MLXSubprocessRunner,
    SpawnRefused,
    SubprocessCrashError,
    SubprocessTimeoutError,
    call_model_isolated,
    shutdown_all_workers,
)
from metal_guard.resource_tracker import ResourceTracker, global_resource_tracker
from metal_guard.spawn_authorization import SpawnVerdict, authorize_mlx_spawn
from metal_guard.corpus import (
    EVENT_KINDS,
    append_event,
    count_events,
    emit_event,
    iter_events,
)
from metal_guard.import_gate import (
    WATCHED_PREFIXES,
    ImportGateBlocked,
    install as install_import_gate,
    uninstall as uninstall_import_gate,
)
from metal_guard.display_guard import (
    AGX_RELAX_ENV_KEY,
    AGX_RELAX_ENV_VALUE,
    LoRAVerdict,
    apply_agx_mitigation,
    is_display_active,
    precheck_lora_workload,
)
from metal_guard.launchd_guard import (
    KeepAliveVerdict,
    LaunchdContext,
    auto_record_on_failure,
    check_keepalive_guard,
    daemon_guard,
    detect_launchd_context,
    record_crash,
    request_self_bootout,
)
from metal_guard.model_cache import (
    ModelCache,
    check_metal_pressure,
    flush_kv_cache,
    get_mlx_model,
    get_mlx_vlm_model,
    unload_all,
)
from metal_guard.model_profile import (
    GuardMode,
    KvQuantMode,
    ModelProfile,
    get_profile,
    list_profiles,
    register_profile,
)
from metal_guard.done_frame import (
    ChildCrashed,
    FrameProtocolMismatch,
    InvalidFrame,
    extract_prefill_from_done,
    is_strict_mode,
    normalize_legacy_frame,
    recv_frame_or_crash,
    validate_frame,
)
from metal_guard.recovery_lockout import (
    MLXRecoveryLockedError,
    acquire_lockout,
    is_locked_out,
    release_lockout,
    time_remaining,
    trigger_crash_lockout,
)
from metal_guard.load_gate import MLXLoadGateError, can_load, gate_or_raise
from metal_guard.child_death_detector import (
    SubprocessEarlyDeathError,
    is_detector_enabled,
    poll_for_early_death,
)
from metal_guard.safe_shutdown import ShutdownReport, safe_inference_shutdown
from metal_guard.oom_precheck import (
    OOMVerdict,
    precheck_inference,
    precheck_inference_or_raise,
)
from metal_guard.prefill_exposure_tracker import (
    WorkerPrefillState,
    all_states,
    forget_worker,
    get_state,
    record_prefill,
)
from metal_guard.worker_rotation import (
    REASON_DISABLED,
    REASON_NO_STATE,
    REASON_PREFILL_BUDGET_EXCEEDED,
    REASON_UNDER_BUDGET,
    RotationVerdict,
    should_rotate_worker,
)

# ---------------------------------------------------------------------------
# Private re-exports — underscore-prefixed names that existing tests / callers
# reach via ``metal_guard._x`` attribute access. NOT part of __all__ (they
# stay conventionally private), but re-bound here so the attribute resolves
# for 0-BC. Patching a private internal must target its defining submodule.
# ---------------------------------------------------------------------------
from metal_guard.error_classifier import _METAL_OOM_PATTERN  # noqa: F401
from metal_guard.mlx_lock import _is_pid_alive, _is_zombie  # noqa: F401
from metal_guard.version_advisories import (  # noqa: F401
    _installed_version,
    _spec_matches,
)
from metal_guard.system_audit import _classify_gpu_family  # noqa: F401
from metal_guard.panic_registry import _WARNED_PANIC_MODELS  # noqa: F401
from metal_guard.cadence import (  # noqa: F401
    _C5_DEFAULT_CROSS_MODEL_INTERVAL_SEC,
    _CROSS_MODEL_ENV_VAR,
    _is_gemma4_family,
    _resolve_cross_model_interval,
)
from metal_guard.panic_reports import _PANIC_JSONL_PATH  # noqa: F401
from metal_guard.panic_gate import (  # noqa: F401
    _ABORT_REPORTS_GLOBS,
    _PANIC_LOCKOUT_ACK_PATH,
    _PANIC_SENTINEL_PATH,
)
from metal_guard.forensics import _BREADCRUMB_LINE_RE  # noqa: F401
from metal_guard.resource_tracker import _reset_global_resource_tracker  # noqa: F401
from metal_guard.spawn_authorization import (  # noqa: F401
    _KNOWN_SEVERITIES,
    _KNOWN_WORKLOAD_TYPES,
    _OVERRIDE_MIN_CHARS,
    _OVERRIDE_REQUIRED_TOKENS,
    _audit_spawn_override,
    _check_known_panic_gate,
    _check_mlx_version_blocklist_gate,
    _check_mlx_version_soft_advisory,
    _check_panic_cooldown_gate,
    _check_workload_advisory_gate,
    _check_workload_soft_advisory,
    _detect_gpu_family_for_gate,
    _validate_override_reason,
)

# Locked public API surface — identical to the pre-Phase-1 single-file
# module's public surface (stdlib-import leakage excluded). See
# tests/test_phase1_facade.py.
__all__ = [
    "__version__",
    "log",
    "T",
    # error_classifier
    "detect_panic_signature",
    "ErrorClass",
    "classify_mlx_error",
    "is_kernel_panic_signature",
    "is_process_abort_signature",
    # memory
    "MemoryStats",
    "MetalOOMError",
    "kv_cache_clear_on_pressure",
    # guard
    "MetalGuard",
    "metal_guard",
    # mlx_lock
    "MLXLockConflict",
    "read_mlx_lock",
    "acquire_mlx_lock",
    "release_mlx_lock",
    "mlx_exclusive_lock",
    # version_advisories
    "check_version_advisories",
    "install_upstream_defensive_patches",
    # system_audit
    "audit_wired_limit",
    "read_gpu_driver_version",
    "log_system_audit_at_startup",
    "bench_scoped_load",
    "apple_gpu_family",
    # process_mode
    "DEFENSIVE",
    "OBSERVER",
    "current_mode",
    "is_defensive",
    "is_observer",
    "describe_mode",
    "ProcessMode",
    "detect_process_mode",
    "apply_mode_defaults",
    "describe_process_mode",
    # panic_registry
    "KNOWN_PANIC_MODELS",
    "MLX_VERSION_BLOCKLIST",
    "MLX_LM_VERSION_BLOCKLIST",
    "WORKLOAD_ADVISORIES",
    "check_mlx_lm_version_blocked",
    "check_workload_advisory",
    "check_mlx_version_blocked",
    "check_known_panic_model",
    "warn_if_known_panic_model",
    "check_known_panic_model_for_gpu",
    "models_by_tier",
    "models_affecting_gpu_family",
    # cadence
    "CadenceViolation",
    "CrossModelCadenceViolation",
    "CadenceGuard",
    "require_cadence_clear",
    "GEMMA4_MIN_CROSS_MODEL_INTERVAL_SEC",
    # prefill
    "ModelDims",
    "KNOWN_MODELS",
    "lookup_dims",
    "estimate_prefill_peak_alloc_gb",
    "require_prefill_fit",
    "recommend_chunk_size",
    "describe_prefill_plan",
    "KVGrowthTracker",
    "kv_tracker",
    # panic_reports
    "format_panic_for_apple_feedback",
    "parse_panic_reports",
    "ingest_panics_jsonl",
    "MLXCooldownActive",
    "CircuitBreaker",
    "subprocess_inference_guard",
    "gemma4_generation_flush",
    # panic_gate
    "PANIC_REPORTS_GLOBS",
    "PanicRecord",
    "CooldownVerdict",
    "scan_recent_panics",
    "evaluate_panic_cooldown",
    "mark_panic_sentinel_cooldown",
    "ack_panic_lockout",
    "clear_panic_ack",
    "clear_panic_sentinel",
    "AbortRecord",
    "scan_recent_aborts",
    # forensics
    "OrphanPre",
    "scan_orphan_subproc_pre",
    "run_postmortem",
    "STATUS_SNAPSHOT_SCHEMA_VERSION",
    "get_status_snapshot",
    "write_status_snapshot",
    # subprocess_runner
    "SpawnRefused",
    "SubprocessCrashError",
    "SubprocessTimeoutError",
    "MLXSubprocessRunner",
    "call_model_isolated",
    "shutdown_all_workers",
    # resource_tracker
    "ResourceTracker",
    "global_resource_tracker",
    # spawn_authorization
    "SpawnVerdict",
    "authorize_mlx_spawn",
    # corpus (W3)
    "append_event",
    "emit_event",
    "iter_events",
    "count_events",
    "EVENT_KINDS",
    # import_gate (W4)
    "WATCHED_PREFIXES",
    "ImportGateBlocked",
    "install_import_gate",
    "uninstall_import_gate",
    # display_guard (W4)
    "AGX_RELAX_ENV_KEY",
    "AGX_RELAX_ENV_VALUE",
    "LoRAVerdict",
    "is_display_active",
    "precheck_lora_workload",
    "apply_agx_mitigation",
    # launchd_guard (W4)
    "LaunchdContext",
    "KeepAliveVerdict",
    "detect_launchd_context",
    "record_crash",
    "check_keepalive_guard",
    "auto_record_on_failure",
    "daemon_guard",
    "request_self_bootout",
    # process_mode observer gate (W4)
    "check_observer_requirements",
    # model_cache (W5)
    "ModelCache",
    "get_mlx_model",
    "get_mlx_vlm_model",
    "unload_all",
    "flush_kv_cache",
    "check_metal_pressure",
    # model_profile (W5)
    "ModelProfile",
    "GuardMode",
    "KvQuantMode",
    "get_profile",
    "register_profile",
    "list_profiles",
    # done_frame (W6)
    "validate_frame",
    "is_strict_mode",
    "normalize_legacy_frame",
    "recv_frame_or_crash",
    "extract_prefill_from_done",
    "InvalidFrame",
    "FrameProtocolMismatch",
    "ChildCrashed",
    # recovery_lockout (W6)
    "is_locked_out",
    "acquire_lockout",
    "release_lockout",
    "time_remaining",
    "trigger_crash_lockout",
    "MLXRecoveryLockedError",
    # load_gate (W6)
    "can_load",
    "gate_or_raise",
    "MLXLoadGateError",
    # child_death_detector (W6)
    "poll_for_early_death",
    "is_detector_enabled",
    "SubprocessEarlyDeathError",
    # safe_shutdown (W6)
    "safe_inference_shutdown",
    "ShutdownReport",
    # oom_precheck (W7)
    "OOMVerdict",
    "precheck_inference",
    "precheck_inference_or_raise",
    # prefill_exposure_tracker (W7)
    "WorkerPrefillState",
    "record_prefill",
    "get_state",
    "forget_worker",
    "all_states",
    # worker_rotation (W7)
    "should_rotate_worker",
    "RotationVerdict",
    "REASON_DISABLED",
    "REASON_NO_STATE",
    "REASON_UNDER_BUDGET",
    "REASON_PREFILL_BUDGET_EXCEEDED",
]
