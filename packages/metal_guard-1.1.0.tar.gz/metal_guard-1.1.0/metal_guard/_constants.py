"""Shared module-wide singletons for the metal_guard package.

``__version__`` / the package logger / the AGX env import-time side-effect.
Imported (directly or transitively) by every other submodule, so it is the
leaf of the package dependency DAG.
"""
from __future__ import annotations

import logging
import os
from typing import TypeVar

__version__ = "1.1.0"

log = logging.getLogger("metal_guard")

T = TypeVar("T")

# ── Apple GPU driver workaround ─────────────────────────────────────────
# Suggested by @zcbenz (MLX maintainer) in mlx#3267:
# Relaxes the command buffer context store timeout to reduce kernel panics
# on long-running GPU workloads.  Zero-cost — just an env var hint to the
# IOGPUFamily driver.  Safe to set unconditionally.
if "AGX_RELAX_CDM_CTXSTORE_TIMEOUT" not in os.environ:
    os.environ["AGX_RELAX_CDM_CTXSTORE_TIMEOUT"] = "1"
