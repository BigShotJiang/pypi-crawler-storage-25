"""Done-frame protocol — typed subprocess result frames.

Frame transport: a picklable Python dict over ``multiprocessing.Pipe``.
Per-call subprocess crash detection via ``EOFError`` / ``BrokenPipeError``
/ timeout on the parent ``recv``.

All four phase frames (``request`` / ``progress`` / ``done`` / ``error``)
carry a ``protocol_version``; a child/parent version skew raises
``FrameProtocolMismatch`` and emits a ``frame_protocol_mismatch`` corpus
event.

Public API
----------
``validate_frame(frame) -> None``
    Structural validation; raises ``InvalidFrame`` / ``FrameProtocolMismatch``.
``is_strict_mode() -> bool``
    Env-driven; default True (``MLX_DONE_FRAME_STRICT`` defaults to "1").
``normalize_legacy_frame(raw_or_dict) -> dict``
    STRICT=0 backward-compat synthesis of a ``protocol_version=0`` sentinel
    for raw legacy ``result_str`` outputs.
``recv_frame_or_crash(parent_recv, timeout_sec=None) -> Any``
    Blocking receive on a ``multiprocessing.Pipe``; raises ``ChildCrashed``
    on EOF / BrokenPipe / timeout, after emitting a ``subprocess_no_done``
    corpus event.
``extract_prefill_from_done(frame) -> dict | None``
    Pull a nested ``prefill_payload`` dict from a done frame.

Env vars
--------
- ``MLX_DONE_FRAME_STRICT`` (default ``"1"``) — set ``"0"`` to accept raw
  legacy ``result_str`` (synthetic v0 frame) during a transition window.
- ``MLX_DONE_FRAME_TIMEOUT_SEC`` (default ``300``) — production recv timeout.
"""
from __future__ import annotations

import multiprocessing.connection as mp_conn
import os
from typing import Any

from metal_guard import corpus
from metal_guard._constants import log

# Canonical protocol versions parent accepts.
#  0 = legacy raw-string sentinel (STRICT=0 carve-out only)
#  1 = Wave A canonical dict frame
KNOWN_PROTOCOL_VERSIONS: frozenset[int] = frozenset({0, 1})
CURRENT_PROTOCOL_VERSION: int = 1

VALID_PHASES: frozenset[str] = frozenset({"request", "progress", "done", "error"})

_STRICT_ENV = "MLX_DONE_FRAME_STRICT"
_TIMEOUT_ENV = "MLX_DONE_FRAME_TIMEOUT_SEC"
DEFAULT_TIMEOUT_SEC: float = 300.0


# ── Exceptions ────────────────────────────────────────────────────────


class InvalidFrame(ValueError):
    """Frame structure invalid (not dict / wrong phase / missing required field)."""


class FrameProtocolMismatch(ValueError):
    """``protocol_version`` missing or unknown — child/parent version skew."""


class ChildCrashed(RuntimeError):
    """Child died before sending done frame: EOFError / BrokenPipeError / timeout."""


# ── Strict mode + timeout helpers ─────────────────────────────────────


def is_strict_mode() -> bool:
    """Return True when ``MLX_DONE_FRAME_STRICT`` is not ``"0"`` (default strict).

    AC2.1: STRICT=1 default — child not sending done frame counts as crash.
    AC2.4: STRICT=0 enables 14d transition window for raw-string legacy frames.
    """
    return os.environ.get(_STRICT_ENV, "1") != "0"


def _timeout_default() -> float:
    """Production timeout (env override).

    Tests should pass ``timeout_sec`` explicit for speed (~1s).
    """
    raw = os.environ.get(_TIMEOUT_ENV, "")
    if raw:
        try:
            return float(raw)
        except ValueError:
            log.debug("invalid %s=%r; falling back to default", _TIMEOUT_ENV, raw)
    return DEFAULT_TIMEOUT_SEC


# ── Validation ────────────────────────────────────────────────────────


def validate_frame(frame: Any) -> None:
    """Structural-validate dict frame + protocol_version. Raises on invalid.

    AC2.3: dict structural validation (NOT jsonschema). Frame is picklable
    Python dict over ``multiprocessing.Pipe``.
    AC2.6: All 4 phase frames carry ``protocol_version``; unknown raises
    ``FrameProtocolMismatch`` and emits panic_corpus event_kind=
    ``frame_protocol_mismatch``.

    Args:
        frame: Expected dict matching ``{"protocol_version": int, "phase": str, ...}``.

    Raises:
        InvalidFrame: ``frame`` is not a dict, or ``phase`` missing/unknown.
        FrameProtocolMismatch: ``protocol_version`` missing or unknown.
    """
    if not isinstance(frame, dict):
        raise InvalidFrame(
            f"frame must be dict; got {type(frame).__name__}"
        )

    if "protocol_version" not in frame:
        _emit_protocol_mismatch(received=None)
        raise FrameProtocolMismatch("frame missing protocol_version field")

    version = frame["protocol_version"]
    if version not in KNOWN_PROTOCOL_VERSIONS:
        _emit_protocol_mismatch(received=version)
        raise FrameProtocolMismatch(
            f"unknown protocol_version={version!r}; expected one of "
            f"{sorted(KNOWN_PROTOCOL_VERSIONS)}"
        )

    phase = frame.get("phase")
    if phase not in VALID_PHASES:
        raise InvalidFrame(
            f"unknown phase={phase!r}; expected one of {sorted(VALID_PHASES)}"
        )


def _emit_protocol_mismatch(*, received: Any) -> None:
    """Best-effort emit panic_corpus ``frame_protocol_mismatch`` (AC2.6)."""
    try:
        corpus.emit_event(
            event_kind="frame_protocol_mismatch",
            payload={
                "received_version": received,
                "expected_version": sorted(KNOWN_PROTOCOL_VERSIONS),
            },
        )
    except Exception as exc:  # corpus must never break caller
        log.debug("panic_corpus emit failed: %s", exc)


# ── Legacy normalization (STRICT=0 carve-out) ─────────────────────────


def normalize_legacy_frame(raw_or_dict: Any) -> dict[str, Any]:
    """STRICT=0 backward-compat: synthesize ``protocol_version=0`` sentinel for
    raw ``result_str`` (non-dict) legacy child output.

    Under STRICT=1 (default), non-dict input raises ``FrameProtocolMismatch``
    — no carve-out.

    AC2.4: 14d transition window opt-out via ``MLX_DONE_FRAME_STRICT=0``.
    AC2.6 carve-out: raw non-dict synthesizes
    ``{protocol_version: 0, phase: "done", result: <raw>}``.

    Args:
        raw_or_dict: Either a dict (validated + passed through) or any non-dict.

    Returns:
        dict frame: validated input or synthesized legacy sentinel.

    Raises:
        FrameProtocolMismatch: under STRICT=1 when input is not a dict.
        InvalidFrame: input dict fails structural validation.
    """
    if isinstance(raw_or_dict, dict):
        validate_frame(raw_or_dict)
        return raw_or_dict

    if is_strict_mode():
        raise FrameProtocolMismatch(
            f"STRICT=1 rejects non-dict legacy frame; got {type(raw_or_dict).__name__}"
        )

    log.warning(
        "legacy raw-string frame accepted under STRICT=0 transition window: %r",
        type(raw_or_dict).__name__,
    )
    return {
        "protocol_version": 0,
        "phase": "done",
        "result": raw_or_dict,
    }


# ── Pipe recv with crash detection ────────────────────────────────────


def recv_frame_or_crash(
    parent_recv: mp_conn.Connection,
    timeout_sec: float | None = None,
) -> Any:
    """Receive next frame from child; raise ``ChildCrashed`` on crash signals.

    AC2.2: ``kill -9`` simulation → parent ≤ timeout detect EOFError.
    AC2.5: Separate child crash from clean done frame; emits panic_corpus
    event_kind=``subprocess_no_done`` only on crash path (NOT happy path).

    Production callers should pass ``None`` to use env-driven default
    ``MLX_DONE_FRAME_TIMEOUT_SEC`` (300s, matches Ollama
    ``OLLAMA_LOAD_TIMEOUT`` semantics). Tests pass explicit ``timeout_sec``
    kwarg for speed (~1s).

    Args:
        parent_recv: parent_recv side of ``multiprocessing.Pipe(duplex=False)``.
        timeout_sec: Override receive timeout in seconds. ``None`` → env default.

    Returns:
        Whatever object the child sent over the Pipe. **No schema validation is
        performed here** — return type is ``Any`` (not ``dict``) because a
        misbehaving / legacy child may send a non-dict payload. Caller MUST
        pass the result through :func:`validate_frame` (STRICT=1) or
        :func:`normalize_legacy_frame` (STRICT=0) before relying on dict shape.

    Raises:
        ChildCrashed: EOFError / BrokenPipeError / OSError / timeout.
    """
    effective_timeout = timeout_sec if timeout_sec is not None else _timeout_default()

    try:
        ready = parent_recv.poll(effective_timeout)
    except (EOFError, BrokenPipeError, OSError) as exc:
        kind = type(exc).__name__
        _emit_subprocess_no_done(exit_kind=kind, timeout_sec=effective_timeout)
        raise ChildCrashed(
            f"child crashed during poll: {kind}: {exc}"
        ) from exc

    if not ready:
        _emit_subprocess_no_done(exit_kind="timeout", timeout_sec=effective_timeout)
        raise ChildCrashed(
            f"no done frame within {effective_timeout}s timeout"
        )

    try:
        frame = parent_recv.recv()
    except (EOFError, BrokenPipeError, OSError) as exc:
        kind = type(exc).__name__
        _emit_subprocess_no_done(exit_kind=kind, timeout_sec=effective_timeout)
        raise ChildCrashed(
            f"child crashed during recv: {kind}: {exc}"
        ) from exc

    return frame


def _emit_subprocess_no_done(*, exit_kind: str, timeout_sec: float) -> None:
    """Best-effort emit panic_corpus ``subprocess_no_done`` (AC2.2)."""
    try:
        corpus.emit_event(
            event_kind="subprocess_no_done",
            payload={
                "exit_kind": exit_kind,
                "timeout_sec": timeout_sec,
            },
        )
    except Exception as exc:
        log.debug("panic_corpus emit failed: %s", exc)


# ── Wave A prefill_exposure_tracker integration ───────────────────────


def extract_prefill_from_done(frame: dict[str, Any]) -> dict[str, Any] | None:
    """Pull nested ``prefill_payload`` dict from done frame; ``None`` if absent.

    AC2.5: Wave A backward-compat. Child not yet emitting ``prefill_payload``
    returns ``None`` gracefully (no raise) — supports mid-Wave-A rolling deploy.

    Args:
        frame: done frame dict.

    Returns:
        prefill_payload dict, or None if absent or malformed.
    """
    payload = frame.get("prefill_payload")
    if payload is None:
        return None
    if not isinstance(payload, dict):
        log.warning(
            "prefill_payload is %s; expected dict — treating as absent",
            type(payload).__name__,
        )
        return None
    return payload
