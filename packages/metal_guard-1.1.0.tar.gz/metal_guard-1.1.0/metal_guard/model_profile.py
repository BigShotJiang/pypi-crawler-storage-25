"""Per-model profile registry.

Single source of truth for per-model overrides — cadence intervals,
persistent-worker pool sizing, KV-cache quantization mode, and the
first-gen guard mode.

Invariants:
- ``ModelProfile`` MUST stay ``frozen=True``. ``get_profile`` /
  ``list_profiles`` release the registry lock before returning, which
  is only safe because profile values are immutable.
- ``register_profile`` MUST use copy-on-write rebind (never mutate
  ``_REGISTRY`` in place) so readers see atomic old-or-new snapshots.

Requires Python 3.10+ (``@dataclass(kw_only=True)``).
"""
from __future__ import annotations

import threading
from dataclasses import dataclass, field
from typing import Literal, get_args


GuardMode = Literal["prepare", "block", "off"]
"""C7 firstgen guard mode.

- ``prepare``: current live behavior — ``mx.synchronize + mx.clear_cache
  + sleep 3.0s`` before load; does NOT abort.
- ``block``: raise ``FirstGenGuardBlocked`` on load attempt; requires
  new code path in ``gemma4_firstgen_guard``.
- ``off``: skip guard entirely; equivalent to the existing env
  kill-switch ``METALGUARD_GEMMA4_FIRSTGEN_DISABLED=1``.
"""


KvQuantMode = Literal["off", "v3", "mixed_k8v4"]
"""Per-model KV cache quantization mode (Layer A').

- ``off``: stock mlx-lm ``make_prompt_cache`` (no compression).
- ``v3``: ``VOnlyTurboQuantCache(bits=3)`` drop-in; K fp16 + V 3-bit;
  works with stock mlx-lm, no fork required.
- ``mixed_k8v4``: K 8-bit + V 4-bit via Apple's ``mx.quantized_matmul``;
  requires arozanov/mlx-lm fork ``feature/turboquant-kv-cache`` with
  ``mixed_quantized_scaled_dot_product_attention``.
"""


# Constants derived from panic #11 remediation plan — centralised so
# registry overrides and subprocess_runner defaults stay aligned.
# (critic P1-3 fix: single source of truth for the scoped wall cap.)
PANIC11_GEMMA4_POOL_WALL_SEC = 600
PANIC11_GEMMA4_CROSS_MODEL_INTERVAL_SEC = 300.0
# DEPRECATED 2026-04-24 (DEAD per P2-2 / 2026-05-02): see field
# ``ModelProfile.metal_memory_limit_gb`` for rationale. Constant retained
# only because tests reference it; new code should not read this value.
PANIC11_GEMMA4_METAL_MEMORY_LIMIT_GB = 48.0


@dataclass(frozen=True, kw_only=True)
class ModelProfile:
    """Frozen per-model config consumed by subprocess_runner + metal_guard.

    Fields map 1:1 to Layer B/C/F/A'/D panic #11 remediation knobs. Any
    field set to ``None`` means "fall back to global default" (env var
    or code default). Do not mutate instances — use ``register_profile``
    to add new entries, never rebind existing ones while workers run.

    Using ``kw_only=True`` (critic P0-2 + M-4) so future fields can be
    added without breaking pickle order, and so callers cannot
    positionally mis-bind overrides (every override is explicit).
    """

    model_id: str
    # Layer B: CadenceGuard overrides (seconds). None = env/default.
    cross_model_interval_sec: float | None = None
    min_interval_sec: float | None = None
    # Layer C: C4 PersistentWorkerPool. All None = env fallback
    # (critic P0-2 fix: no bool-vs-None mixed sentinels).
    persistent_worker: bool | None = None
    pool_max_inference: int | None = None
    pool_max_wall_sec: int | None = None
    pool_min_headroom_gb: float | None = None
    # Layer A': KV cache quantization. "off" is explicit (not fallback).
    kv_quant: KvQuantMode = "off"
    # Layer F — DEPRECATED 2026-04-24 (DEAD per P2-2 / 2026-05-02):
    # ``mx.set_memory_limit`` does NOT govern Apple unified memory's
    # CPU-visible shared heap; both S3 benches confirmed the cap is
    # silently ignored. panic #11 root cause is IOGPUMemory.cpp:492
    # refcount race, not Metal OOM, so a cap was never the right
    # defense. Field retained for backward compat with tests + smoke
    # scripts; subprocess_runner Layer F wire is now no-op (reports
    # ``layer_f_status="deprecated_dead"`` only).
    # Was: mx.set_memory_limit safety net (GB).
    metal_memory_limit_gb: float | None = None
    # Layer D: C7 gemma4_firstgen_guard behavior.
    # FIXME(panic#11 + critic R2-P1-5): current C7 "prepare" mode did
    # NOT block gemma-4-31b-8bit at panic #11 — CLAUDE.md audit
    # 2026-04-24 flags this. Phase 1 wire strategy: do NOT let
    # subprocess_runner / metal_guard read this field yet.
    # gemma4_firstgen_guard keeps running its current prepare-mode path
    # driven by env METALGUARD_GEMMA4_FIRSTGEN_DISABLED. Flip to
    # profile-driven wiring only after block-mode code lands in
    # metal_guard.py AND Layer B+C canary stabilises. Until then this
    # field is advisory / breadcrumb only.
    firstgen_guard_mode: GuardMode = "prepare"
    # Diagnostic tags (not read by any code path; operator breadcrumbs only).
    tags: frozenset[str] = field(default_factory=frozenset)

    def __post_init__(self) -> None:
        """Validate Literal fields so typos fail-fast at construction.

        ``typing.Literal`` is a type-check hint only; without this guard,
        a typo like ``kv_quant="v33"`` would survive pickle/subprocess
        transit and silently skip the quant path (critic R1-P1-2).
        """
        self._validate()

    def _validate(self) -> None:
        kv_choices = get_args(KvQuantMode)
        if self.kv_quant not in kv_choices:
            raise ValueError(
                f"kv_quant={self.kv_quant!r} not in {kv_choices}"
            )
        guard_choices = get_args(GuardMode)
        if self.firstgen_guard_mode not in guard_choices:
            raise ValueError(
                f"firstgen_guard_mode={self.firstgen_guard_mode!r} "
                f"not in {guard_choices}"
            )

    def __setstate__(self, state: dict) -> None:
        """Re-validate on pickle unmarshal (critic R3-P0-A fix).

        Python's default pickle path bypasses ``__post_init__``. A
        profile crossing a subprocess boundary (C4 pool worker) without
        this re-check could bypass the Literal guard. Force validation
        on every deserialisation.
        """
        self.__dict__.update(state)
        self._validate()


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

_REGISTRY: dict[str, ModelProfile] = {
    # mlx-community/gemma-4-31b-it-8bit — repeat kernel-panic offender.
    # Panic signature: completeMemory() prepare_count_underflow at
    # IOGPUMemory.cpp:492 (Apple driver bug — mlx#3186 / #3346 / mlx-lm#883).
    # 8-bit quantization on a 31B dense model produces ~2.4x the buffer
    # allocation density of a 26b-a4b-4bit model, compounding the IOGPU
    # refcount race on cross-model teardown. Remediation: longer cross-
    # model cadence + persistent-worker pool with a wall-time cap.
    "mlx-community/gemma-4-31b-it-8bit": ModelProfile(
        model_id="mlx-community/gemma-4-31b-it-8bit",
        cross_model_interval_sec=PANIC11_GEMMA4_CROSS_MODEL_INTERVAL_SEC,
        persistent_worker=True,
        pool_max_wall_sec=PANIC11_GEMMA4_POOL_WALL_SEC,
        kv_quant="off",
        metal_memory_limit_gb=PANIC11_GEMMA4_METAL_MEMORY_LIMIT_GB,
        firstgen_guard_mode="prepare",
        tags=frozenset({
            "gemma-4", "first-gen", "panic-prone", "8bit-dense",
            "repeat-offender-2026-04",
        }),
    ),
}

# Lock protecting concurrent register/read on _REGISTRY (critic P0-1 fix).
# Reads take the lock too to pair with copy-on-write rebind so
# subprocess workers + metal_guard never observe a half-updated entry.
_REGISTRY_LOCK = threading.RLock()


def get_profile(model_id: str) -> ModelProfile:
    """Return profile for ``model_id``; fall back to empty default.

    The empty default (no fields set) means every hook reads its
    env/code default, so unknown models behave identically to
    pre-profile code.

    TODO(critic R2-P1-1): unknown path rebuilds ``ModelProfile(model_id=..)``
    per call (incl. ``__post_init__`` validation). If wired to a hot
    inference loop, memoize via a module-level LRU or rebind from a
    pre-built empty template. Acceptable for now while inert.
    """
    with _REGISTRY_LOCK:
        existing = _REGISTRY.get(model_id)
    if existing is not None:
        return existing
    return ModelProfile(model_id=model_id)


def register_profile(profile: ModelProfile) -> None:
    """Runtime extension point for tests / operator canary overrides.

    Copy-on-write rebind under lock so concurrent readers either see
    the old registry state or the new one, never a torn update
    (critic P0-1 fix).

    Prefer adding entries to ``_REGISTRY`` directly in code review; use
    this only for one-shot test scaffolding or operator overrides during
    canary.
    """
    global _REGISTRY
    with _REGISTRY_LOCK:
        new_reg = dict(_REGISTRY)
        new_reg[profile.model_id] = profile
        _REGISTRY = new_reg


def list_profiles() -> list[str]:
    """Return model_ids currently in the registry. Used for diagnostics."""
    with _REGISTRY_LOCK:
        return sorted(_REGISTRY.keys())


# ---------------------------------------------------------------------------
# Design notes (not runtime code) — move to docs/ when wired.
# ---------------------------------------------------------------------------
#
# Why dataclass(frozen=True)
# --------------------------
# Workers read profiles across thread/process boundaries via pickle
# (C4 pool may share config into subprocess). Frozen means pickle is
# deterministic and nobody can mutate a shared profile mid-inference.
#
# Why module-level _REGISTRY over JSON config file
# ------------------------------------------------
# Harper operator surface is code-review driven, not hot-reload driven.
# A JSON config would add stat/read overhead per worker spawn and one
# more thing to keep in sync with runtime.
#
# Why frozenset for tags
# ----------------------
# Tags are advisory (log breadcrumbs, diagnostic filtering); frozen
# prevents operators from accidentally stuffing invariants into tags
# where hook code would later depend on them.
#
# Gemma4 KV quant status
# ----------------------
# An earlier internal config marked gemma kv_bits_ok=false citing
# "RotatingKVCache NYI in mlx-lm 0.31". arozanov/turboquant-mlx
# commit 7dea9d1 (2026-04-16) added window_size support to
# TurboQuantKVCache.make_mask. Whether VOnlyTurboQuantCache correctly
# forwards window_size through its internal KVCache (for sliding layers)
# is not empirically verified. Until a greedy-identical smoke passes on
# gemma-4-31b-8bit, kv_quant stays "off" for this profile.
