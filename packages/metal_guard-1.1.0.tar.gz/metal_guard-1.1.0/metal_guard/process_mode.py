"""Process-mode classification + defensive/observer toggle."""

from __future__ import annotations

import datetime
import gc
import glob
import json
import logging
import multiprocessing
import os
import pathlib
import re
import shutil
import signal
import sys
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from multiprocessing.connection import Connection
from pathlib import Path
from typing import Any, Callable, Generator, Iterator, Tuple, TypeVar

from metal_guard._constants import log

ProcessMode = str  # literal: "server" | "embedded" | "notebook" | "cli" | "subprocess_worker"

# ---------------------------------------------------------------------------
# Layer 6: Dual-mode switcher — defensive / observer (v0.5.0)
# ---------------------------------------------------------------------------
# MetalGuard has two operating modes:
#
#   - Defensive (default): actively block dangerous Metal GPU operations.
#     process_lock refuses conflicting runs, sequential dispatch enforced.
#
#   - Observer: monitor and log, let the caller proceed. Used after
#     upstream MLX ships #3348 (CommandEncoder thread-local) and empirical
#     validation confirms parallel inference is safe on the target hardware.
#
# The five long-term primitives (safe_cleanup, daemon thread registry,
# oom_protected_context, breadcrumb logging, memory_stats) are active
# in BOTH modes — they address concerns orthogonal to thread safety.
#
# Set METALGUARD_MODE env var to switch:
#   export METALGUARD_MODE=defensive    # default
#   export METALGUARD_MODE=observer     # opt-in after #3348

DEFENSIVE = "defensive"
OBSERVER = "observer"

_VALID_MODES = frozenset({DEFENSIVE, OBSERVER})
_MODE_ENV_VAR = "METALGUARD_MODE"

# ── Observer mode version gate ─────────────────────────────────────────────
#
# Observer mode only drops the MLX call lock safely when both the mlx
# C++ runtime AND the mlx-lm Python layer carry the thread-local stream
# changes. Without both, a ThreadPoolExecutor parallelizing multiple
# callers will race on one CommandEncoder and reproduce the kernel panic
# the defensive mode is protecting against.
#
# Thresholds, with upstream PR references:
#   mlx     ≥ 0.31.2 — ml-explore/mlx#3348 CommandEncoder thread-local
#   mlx-lm  ≥ 0.31.3 — ml-explore/mlx-lm#1090 Thread local generation stream
#
# Both shipped on 2026-04-22. If an operator sets METALGUARD_MODE=observer
# without upgrading, current_mode() falls back to defensive + logs a
# WARNING naming the package that is too old.

_OBSERVER_MIN_VERSIONS: dict[str, str] = {
    "mlx": "0.31.2",
    "mlx-lm": "0.31.3",
}


def _installed_versions() -> dict[str, str | None]:
    """Return ``{package: version_str_or_None}`` for observer gate lookup.

    Kept as a module-level function so tests can monkey-patch it without
    touching ``importlib.metadata`` state. Returns ``None`` for a package
    when ``importlib.metadata`` cannot find it — treated as "too old" by
    the gate (fail-safe).
    """
    try:
        from importlib.metadata import PackageNotFoundError, version
    except ImportError:  # pragma: no cover — Python < 3.8, unreachable here
        return {pkg: None for pkg in _OBSERVER_MIN_VERSIONS}
    result: dict[str, str | None] = {}
    for pkg in _OBSERVER_MIN_VERSIONS:
        try:
            result[pkg] = version(pkg)
        except PackageNotFoundError:
            result[pkg] = None
    return result


def _version_ok(installed: str | None, minimum: str) -> bool:
    """True iff ``installed`` is a valid PEP 440 version ≥ ``minimum``."""
    if not installed:
        return False
    try:
        from packaging.version import InvalidVersion, Version
    except ImportError:
        # Extreme fallback — string-compare prefix. Not ideal but keeps
        # the gate from silently passing if `packaging` is missing.
        return installed >= minimum
    try:
        return Version(installed) >= Version(minimum)
    except (InvalidVersion, ValueError):
        return False


def check_observer_requirements() -> list[str]:
    """Return a list of human-readable problems blocking observer mode.

    Empty list means observer mode is safe to activate. Each entry names
    the package, installed version, and minimum required version, suitable
    for logging or surfacing on a dashboard. Called by ``current_mode()``
    when the operator requests observer mode, and also exposed as a
    public helper so callers can pre-flight check without flipping the
    env var.
    """
    problems: list[str] = []
    installed = _installed_versions()
    for pkg, minimum in _OBSERVER_MIN_VERSIONS.items():
        got = installed.get(pkg)
        if not _version_ok(got, minimum):
            got_str = got if got else "<not installed>"
            problems.append(
                f"{pkg} {got_str} is below the observer-mode minimum "
                f"{minimum} — upgrade required"
            )
    return problems


def current_mode() -> str:
    """Return the current MetalGuard operating mode.

    Reads the ``METALGUARD_MODE`` environment variable fresh on every
    call. Values are case-insensitive. Unknown values fall back to
    ``defensive`` (fail-safe default).

    Observer mode additionally checks that mlx ≥ 0.31.2 and mlx-lm ≥
    0.31.3 are installed. If not, falls back to defensive with a
    WARNING log naming the package that is too old.
    """
    raw = os.environ.get(_MODE_ENV_VAR, DEFENSIVE).strip().lower()
    if raw not in _VALID_MODES:
        log.warning(
            "Unknown %s value %r — falling back to 'defensive'. "
            "Valid values: %s",
            _MODE_ENV_VAR, raw, sorted(_VALID_MODES),
        )
        return DEFENSIVE

    # Defensive path: return immediately, do NOT consult version lookup.
    if raw == DEFENSIVE:
        return DEFENSIVE

    # Observer requested — enforce the version gate.
    problems = check_observer_requirements()
    if problems:
        log.warning(
            "METALGUARD_MODE=observer requested but version gate failed; "
            "falling back to 'defensive'. Problems: %s",
            " | ".join(problems),
        )
        return DEFENSIVE
    return OBSERVER


def is_defensive() -> bool:
    """True when defensive mode is active (the default)."""
    return current_mode() == DEFENSIVE


def is_observer() -> bool:
    """True when observer mode is active (opt-in via env var)."""
    return current_mode() == OBSERVER


def describe_mode() -> dict[str, str | None]:
    """Return a structured description suitable for health endpoints.

    Example output::

        {
            "mode": "defensive",
            "description": "Actively blocks dangerous Metal operations",
            "env_var": "METALGUARD_MODE=<unset> (default → defensive)",
            "requested": None,           # or "observer" if downgraded
            "downgrade_reason": None,    # populated when gate failed
        }
    """
    env_raw = os.environ.get(_MODE_ENV_VAR)
    if env_raw is None:
        env_display = f"{_MODE_ENV_VAR}=<unset> (default → defensive)"
        requested: str | None = None
    else:
        env_display = f"{_MODE_ENV_VAR}={env_raw!r}"
        requested_lower = env_raw.strip().lower()
        requested = requested_lower if requested_lower in _VALID_MODES else None

    mode = current_mode()

    # If user requested observer but we returned defensive, the gate failed.
    downgrade_reason: str | None = None
    if requested == OBSERVER and mode == DEFENSIVE:
        problems = check_observer_requirements()
        if problems:
            downgrade_reason = " | ".join(problems)

    descriptions = {
        DEFENSIVE: (
            "Actively blocks dangerous Metal operations — process_lock refuses "
            "conflicts, sequential dispatch enforced."
        ),
        OBSERVER: (
            "Monitoring only — process_lock logs warnings but does not refuse, "
            "parallel dispatch permitted. Requires mlx >= 0.31.2 (includes "
            "#3348 CommandEncoder thread-local)."
        ),
    }
    return {
        "mode": mode,
        "description": descriptions.get(mode, "(unknown)"),
        "env_var": env_display,
        "requested": requested if requested != mode else None,
        "downgrade_reason": downgrade_reason,
    }


# ---------------------------------------------------------------------------
# R6 — Process-mode detection (2026-04-16)
# ---------------------------------------------------------------------------
#
# Different runtime contexts need different MetalGuard defaults:
#
# * ``server`` — multi-tenant, short-lived requests, tight budgets.
#   mlx-lm#883 / #854 clustered panic reports around long-lived server
#   loops that never flushed between concurrent requests.
# * ``subprocess_worker`` — spawned by :class:`MLXSubprocessRunner`;
#   parent already owns the cross-process MLX lock, child must skip.
# * ``notebook`` — human-driven, relaxed timeouts.
# * ``cli`` — one-shot script; library defaults.
# * ``embedded`` — imported by a host application; defaults match server.
#
# Detection is heuristic and cheap. Never raises; unknown → ``cli``.

# Set by MLXSubprocessRunner in the spawned child before it imports
# metal_guard — opt-in explicit marker is more reliable than grepping
# sys.argv for process IDs.
_SUBPROCESS_WORKER_ENV = "METALGUARD_SUBPROCESS_WORKER"


def detect_process_mode() -> ProcessMode:
    """Classify the current process. Called on demand — no caching."""
    argv = sys.argv if sys.argv else []
    argv_str = " ".join(argv)
    argv0 = os.path.basename(argv[0]) if argv else ""

    if os.environ.get(_SUBPROCESS_WORKER_ENV) == "1":
        return "subprocess_worker"

    if "mlx_lm.server" in argv_str or "mlx.server" in argv_str:
        return "server"

    if any(
        token in argv0 or token in argv_str.split()
        for token in ("uvicorn", "gunicorn", "hypercorn", "fastapi")
    ):
        return "server"

    if "ipykernel" in sys.modules or "ipykernel_launcher" in argv_str:
        return "notebook"

    if "pytest" in argv0 or argv0.endswith("_pytest"):
        return "cli"

    if argv0.endswith(".py") or argv0 == "python" or argv0.startswith("python"):
        return "cli"

    return "embedded"


_MODE_DEFAULTS: dict[str, dict[str, Any]] = {
    "server": {
        "generate_timeout_sec": 60.0,
        "periodic_flush_interval_sec": 60.0,
        "kv_ceiling_gb": 10.0,
        "prefill_single_alloc_ceiling_gb": 4.0,
    },
    "embedded": {
        "generate_timeout_sec": 120.0,
        "periodic_flush_interval_sec": 120.0,
        "kv_ceiling_gb": 15.0,
        "prefill_single_alloc_ceiling_gb": 4.5,
    },
    "notebook": {
        "generate_timeout_sec": 600.0,
        "periodic_flush_interval_sec": 900.0,
        "kv_ceiling_gb": 30.0,
        "prefill_single_alloc_ceiling_gb": 5.0,
    },
    "cli": {
        "generate_timeout_sec": 300.0,
        "periodic_flush_interval_sec": 300.0,
        "kv_ceiling_gb": 20.0,
        "prefill_single_alloc_ceiling_gb": 5.0,
    },
    "subprocess_worker": {
        "generate_timeout_sec": 300.0,
        "periodic_flush_interval_sec": 300.0,
        "kv_ceiling_gb": 20.0,
        "prefill_single_alloc_ceiling_gb": 5.0,
        # Worker inherits parent's cross-process lock ownership and
        # must not re-acquire.
        "skip_process_lock": True,
    },
}


def apply_mode_defaults(mode: ProcessMode | None = None) -> dict[str, Any]:
    """Return recommended config dict for ``mode``.

    If ``mode`` is ``None``, detects via :func:`detect_process_mode`.
    Returned dict is a fresh copy.
    """
    resolved = mode if mode is not None else detect_process_mode()
    defaults = _MODE_DEFAULTS.get(resolved, _MODE_DEFAULTS["cli"])
    result = dict(defaults)
    result["mode"] = resolved
    return result


def describe_process_mode() -> dict[str, Any]:
    """Dashboard-ready summary of current process classification."""
    mode = detect_process_mode()
    return {
        "mode": mode,
        "argv0": os.path.basename(sys.argv[0]) if sys.argv else "",
        "has_ipykernel": "ipykernel" in sys.modules,
        "subprocess_worker_env": os.environ.get(_SUBPROCESS_WORKER_ENV, ""),
        "defaults": apply_mode_defaults(mode),
    }
