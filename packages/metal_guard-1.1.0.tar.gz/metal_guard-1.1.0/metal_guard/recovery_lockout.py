"""Recovery short-lockout — seconds-grade soft isolation for crash bursts.

A secondary panic-isolation gate complementing the panic-cooldown hard
lockout: when subprocesses crash in a tight burst, this writes a short
(seconds-grade) lockout state file so callers back off before the next
spawn.

Adaptive escalation (60s sliding window, per crash):
    1st crash → 10 s lockout
    2nd crash → 30 s lockout
    3rd crash → 120 s lockout + a 2 h sentinel cooldown
                (``panic_gate.mark_panic_sentinel_cooldown``)

State files (atomic ``tmp + os.replace``):
    - Lockout state — default ``~/.cache/metal-guard/recovery_lockout.json``
      (override env ``MLX_RECOVERY_LOCKOUT_STATE_PATH``).
    - Crash history — sibling file tracking timestamps for the window.

Public API:
    - ``is_locked_out() -> bool``
    - ``acquire_lockout(reason, duration_sec=30, *, pid=None, model=None)``
    - ``release_lockout()`` — idempotent file remove
    - ``time_remaining() -> int`` — seconds until expiry (0 if unlocked)
    - ``trigger_crash_lockout(reason, *, pid=None, model=None) -> int``
      — adaptive duration, returns the lockout duration applied (10|30|120)

Exceptions:
    - ``MLXRecoveryLockedError`` — raised by gated callers when locked out.
"""
from __future__ import annotations

import json
import os
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from metal_guard import corpus
from metal_guard import panic_gate
from metal_guard._constants import log

DEFAULT_STATE_PATH = "~/.cache/metal-guard/recovery_lockout.json"
_STATE_PATH_ENV = "MLX_RECOVERY_LOCKOUT_STATE_PATH"
_HISTORY_FILENAME = "mlx_recovery_crash_history.json"

# Adaptive escalation knobs (per Doc 1 § 3.3.2).
WINDOW_SEC: int = 60
DURATION_FIRST_SEC: int = 10
DURATION_SECOND_SEC: int = 30
DURATION_THIRD_PLUS_SEC: int = 120
SENTINEL_COOLDOWN_HOURS: float = 2.0
SENTINEL_REASON: str = "recovery_lockout_third_strike"

DEFAULT_LOCKOUT_DURATION_SEC: int = 30


class MLXRecoveryLockedError(RuntimeError):
    """Raised by gated callers when a recovery lockout is currently active.

    Caller pattern (per AC3.3): catch this and either retry post-``time_remaining()``
    or escalate to the next fallback tier (Spec #4 chain).
    """


# ── Path resolution ───────────────────────────────────────────────────


def _state_path() -> Path:
    """Resolve lockout state file path (env override + ``~`` expansion)."""
    raw = os.environ.get(_STATE_PATH_ENV) or DEFAULT_STATE_PATH
    return Path(os.path.expanduser(raw))


def _history_path() -> Path:
    """Crash history sibling file (same dir as lockout state)."""
    return _state_path().parent / _HISTORY_FILENAME


# ── Time helper (mockable for tests) ──────────────────────────────────


def _now() -> datetime:
    """Return tz-aware UTC now. Tests monkeypatch via ``patch(... ,_now, ...)``."""
    return datetime.now(timezone.utc)


def _iso(ts: datetime) -> str:
    """ISO8601 with trailing ``Z`` for cross-tool readability."""
    if ts.tzinfo is None:
        ts = ts.replace(tzinfo=timezone.utc)
    return ts.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _parse_iso(value: str) -> datetime:
    """Parse ISO8601 ``Z`` / ``+00:00`` suffix into tz-aware datetime."""
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


# ── Atomic JSON write helper ──────────────────────────────────────────


def _atomic_write_json(path: Path, payload: dict[str, Any]) -> None:
    """Write ``payload`` to ``path`` atomically via tempfile + ``os.replace``.

    Per AC3.1 / 3.5: state file MUST never be observed mid-write — concurrent
    readers see either prior content or full new content.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(
        prefix=path.name + ".",
        suffix=".tmp",
        dir=str(path.parent),
    )
    fd_owned_by_fdopen = False
    try:
        fh = os.fdopen(fd, "w", encoding="utf-8")
        fd_owned_by_fdopen = True  # ownership transferred; ``with`` will close.
        with fh:
            json.dump(payload, fh)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp_name, path)
    except Exception:
        # R1 P1 fix: close raw fd only if fdopen never took ownership.
        if not fd_owned_by_fdopen:
            try:
                os.close(fd)
            except OSError:
                pass
        try:
            os.unlink(tmp_name)
        except FileNotFoundError:
            pass
        raise


# ── Lockout state read / write ────────────────────────────────────────


def _read_state() -> dict[str, Any] | None:
    """Read lockout state file. Returns None if absent / corrupt / unreadable.

    AC3.5: corrupt JSON does NOT crash callers — auto-treat as absent.
    """
    path = _state_path()
    try:
        raw = path.read_text(encoding="utf-8")
    except FileNotFoundError:
        return None
    except OSError as exc:
        log.warning("recovery_lockout: state read failed: %s", exc)
        return None
    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:
        log.warning("recovery_lockout: state corrupt (%s); treating as absent", exc)
        return None


def is_locked_out() -> bool:
    """Return True iff state file exists and ``until`` > now (AC3.3).

    Auto-cleans stale lockout (``until`` past) by silently treating as not-locked.
    Corrupt state file → False (AC3.5 graceful fallback).
    """
    state = _read_state()
    if state is None:
        return False
    until_raw = state.get("until")
    if not isinstance(until_raw, str):
        return False
    try:
        until = _parse_iso(until_raw)
    except ValueError:
        return False
    return until > _now()


def time_remaining() -> int:
    """Return integer seconds until lockout expires (0 if not currently locked)."""
    state = _read_state()
    if state is None:
        return 0
    until_raw = state.get("until")
    if not isinstance(until_raw, str):
        return 0
    try:
        until = _parse_iso(until_raw)
    except ValueError:
        return 0
    delta = (until - _now()).total_seconds()
    return max(0, int(round(delta)))


def acquire_lockout(
    reason: str,
    duration_sec: int = DEFAULT_LOCKOUT_DURATION_SEC,
    *,
    pid: int | None = None,
    model: str | None = None,
) -> None:
    """Write lockout state file with ``until = now + duration_sec`` (AC3.1).

    Args:
        reason: Free-form caller tag (e.g., ``"subprocess_crashed"``, ``"oom"``).
        duration_sec: Lockout duration in seconds (default 30).
        pid: Worker PID (optional forensic).
        model: Model identifier (optional forensic).
    """
    now = _now()
    until = now + timedelta(seconds=duration_sec)
    state: dict[str, Any] = {
        "until": _iso(until),
        "reason": reason,
        "subprocess_pid": pid,
        "model": model,
        "started_at": _iso(now),
    }
    _atomic_write_json(_state_path(), state)


def release_lockout() -> None:
    """Remove lockout state file. Idempotent — no-op when file already absent."""
    path = _state_path()
    try:
        path.unlink()
    except FileNotFoundError:
        return


# ── Crash history (adaptive escalation window) ────────────────────────


def _read_history() -> list[datetime]:
    """Read crash timestamps from sibling history file.

    Filters out timestamps that fail ISO parse (forward-compat / corruption-safe).
    """
    path = _history_path()
    try:
        raw = path.read_text(encoding="utf-8")
    except FileNotFoundError:
        return []
    except OSError as exc:
        log.warning("recovery_lockout: history read failed: %s", exc)
        return []
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        log.warning("recovery_lockout: history corrupt (%s); resetting", exc)
        return []
    if not isinstance(data, dict):
        log.warning("recovery_lockout: history root not a dict; resetting")
        return []
    crashes_raw = data.get("crashes", [])
    # R1 P1 fix: a non-list ``crashes`` field would silently iterate (dict keys
    # / int chars / etc.) and silently reset strike count. Reject explicitly.
    if not isinstance(crashes_raw, list):
        log.warning("recovery_lockout: history 'crashes' field not a list; resetting")
        return []
    out: list[datetime] = []
    for ts_raw in crashes_raw:
        if not isinstance(ts_raw, str):
            continue
        try:
            out.append(_parse_iso(ts_raw))
        except ValueError:
            continue
    return out


def _write_history(crashes: list[datetime]) -> None:
    """Persist crash timestamps to history file (atomic write)."""
    payload = {"crashes": [_iso(ts) for ts in crashes]}
    _atomic_write_json(_history_path(), payload)


def _duration_for_strike(strike: int) -> int:
    """Map strike count → lockout duration per AC3.2 (1=10s, 2=30s, 3+=120s)."""
    if strike <= 1:
        return DURATION_FIRST_SEC
    if strike == 2:
        return DURATION_SECOND_SEC
    return DURATION_THIRD_PLUS_SEC


# ── Public adaptive trigger ───────────────────────────────────────────


def trigger_crash_lockout(
    reason: str,
    *,
    pid: int | None = None,
    model: str | None = None,
) -> int:
    """Record a crash, escalate adaptively, and acquire lockout. Returns duration.

    AC3.2: window-based escalation 10s → 30s → 120s.
    AC3.6: third-strike additionally calls ``panic_gate.mark_panic_sentinel_cooldown(
    duration_hours=2.0, reason="recovery_lockout_third_strike")`` — does NOT
    synthesize kernel panic events (panic_gate reads real kernel diagnostics).

    Args:
        reason: Caller tag persisted in lockout state.
        pid: Worker PID (optional).
        model: Model id (optional).

    Returns:
        int seconds: lockout duration applied (10 / 30 / 120).
    """
    now = _now()
    cutoff = now - timedelta(seconds=WINDOW_SEC)

    # Filter prior crashes to those within the 60s sliding window.
    history = [ts for ts in _read_history() if ts > cutoff]
    history.append(now)
    _write_history(history)

    strike = len(history)
    duration_sec = _duration_for_strike(strike)

    acquire_lockout(reason, duration_sec=duration_sec, pid=pid, model=model)

    # Best-effort corpus emit (AC contract test pins event_kind in EVENT_KINDS).
    try:
        corpus.emit_event(
            event_kind="subprocess_crashed",
            payload={
                "strike": strike,
                "duration_sec": duration_sec,
                "reason": reason,
                "pid": pid,
                "model": model,
            },
        )
    except Exception as exc:  # corpus must never break gate
        log.debug("panic_corpus emit failed: %s", exc)

    # AC3.6: third-strike escalation — sentinel cooldown (NOT synthetic panic).
    # Triggers when ``strike == 3`` within a single 60s window. A 4th/5th
    # crash in the same window has strike=4/5 and skips re-marking. After
    # window expiry the history filters back to empty, so a fresh burst can
    # legitimately re-trigger sentinel — that is intended (new escalation
    # event), not a duplicate of the prior one.
    if strike == 3:
        try:
            panic_gate.mark_panic_sentinel_cooldown(
                duration_hours=SENTINEL_COOLDOWN_HOURS,
                reason=SENTINEL_REASON,
            )
        except Exception as exc:
            log.warning("recovery_lockout: sentinel mark failed: %s", exc)

    return duration_sec
