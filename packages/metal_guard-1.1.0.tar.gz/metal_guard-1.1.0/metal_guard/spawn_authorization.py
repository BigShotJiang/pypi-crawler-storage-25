"""v0.12.0 pre-spawn authorization gate — authorize_mlx_spawn() + hard gates."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from metal_guard._constants import log
from metal_guard.panic_gate import evaluate_panic_cooldown
from metal_guard.panic_registry import (
    MLX_VERSION_BLOCKLIST,
    WORKLOAD_ADVISORIES,
    check_known_panic_model_for_gpu,
)
from metal_guard.system_audit import apple_gpu_family
from metal_guard.version_advisories import _installed_version


# ===========================================================================
# v0.12.0 — Subprocess spawn authorization gate (2026-05-02)
#
# Pre-spawn authorization that hard-blocks unsafe MLX subprocess invocations.
# Caller integrates by calling :func:`authorize_mlx_spawn()` BEFORE every
# ``subprocess.run([..., 'python', '-c', 'import mlx_lm.generate...'])``.
#
# Rationale: existing ``check_known_panic_model()`` and
# ``warn_if_known_panic_model()`` are advisory only — caller must remember
# to query and act. ``authorize_mlx_spawn()`` returns a structured
# ``SpawnVerdict`` and forces caller to see all blocking reasons before
# proceeding. The override path requires an audit trail.
#
# Gates (any blocker → ``allowed=False``):
#   G1. panic cooldown active (panic-cooldown gate via
#       ``panic_gate.evaluate_panic_cooldown`` — an always-on package gate)
#   G2. KNOWN_PANIC_MODELS hit for current GPU family
#   G3. MLX_VERSION_BLOCKLIST hit (current mlx version flagged)
#   G4. WORKLOAD_ADVISORIES tier=critical for caller's workload type
#
# Soft advisories (do NOT block, surface in SpawnVerdict.advisories):
#   W1. WORKLOAD_ADVISORIES tier != critical for caller's workload type
#   W2. MLX_VERSION_BLOCKLIST hit at severity != {critical, high}
#   W3. workload_type not in _KNOWN_WORKLOAD_TYPES (G4 cannot fire)
#
# Override: caller passes ``override_with_reason`` (≥20 chars). Verdict
# returns ``allowed=True`` but ``override_used=True`` and the reason is
# written to the audit log. NEVER silent override.
# ===========================================================================

@dataclass(frozen=True)
class SpawnVerdict:
    """Result of :func:`authorize_mlx_spawn`.

    Attributes:
        allowed: True if spawn is authorized.
        blockers: Tuple of (gate_id, reason) for each failing hard gate.
        advisories: Tuple of (advisory_id, reason) for soft warnings.
        gpu_family: GPU family detected at check time (e.g. ``"applegpu_g13d"``).
        override_used: True if caller bypassed blockers via
            ``override_with_reason``.
    """
    allowed: bool
    blockers: tuple[tuple[str, str], ...]
    advisories: tuple[tuple[str, str], ...]
    gpu_family: str | None
    override_used: bool


def _check_panic_cooldown_gate() -> tuple[str, str] | None:
    """G1: panic-cooldown gate via :func:`panic_gate.evaluate_panic_cooldown`.

    Returns:
        (gate_id, reason) tuple if a cooldown is active and spawn must
        block, otherwise None (cooldown clear or gate broken).

    ``evaluate_panic_cooldown`` is a sibling package module — always
    present — so this gate is always on. A verdict ``exit_code == 2`` means
    a cooldown is active and spawn must block; ``0`` clears; ``>= 3`` means
    the gate itself is broken (fail-open — never block on a broken gate).
    """
    try:
        verdict = evaluate_panic_cooldown()
    except Exception as e:  # noqa: BLE001 — defensive; cooldown gate must never crash spawn
        log.warning("panic_gate.evaluate_panic_cooldown crashed: %s", e)
        return None
    if verdict.exit_code == 2:
        until = (
            verdict.cooldown_until.isoformat(timespec="seconds")
            if verdict.cooldown_until is not None else "?"
        )
        return (
            "G1_panic_cooldown",
            f"panic cooldown active ({verdict.reason}, until={until}) — "
            "running mlx subprocess now risks recurrent kernel panic",
        )
    return None


def _check_known_panic_gate(
    model_id: str,
    gpu_family: str | None,
) -> tuple[str, str] | None:
    """G2: KNOWN_PANIC_MODELS denylist gate."""
    advisory = check_known_panic_model_for_gpu(model_id, gpu_family=gpu_family)
    if advisory is None:
        return None
    tier = advisory.get("tier", "panic")
    return (
        "G2_known_panic_model",
        f"model {model_id!r} flagged in KNOWN_PANIC_MODELS "
        f"(tier={tier}, gpu_family={gpu_family or 'any'}) — "
        f"reason: {advisory.get('reason', 'see registry')}",
    )


def _check_mlx_version_blocklist_gate() -> tuple[str, str] | None:
    """G3: MLX_VERSION_BLOCKLIST gate against installed mlx version.

    Only severity ∈ {critical, high} blocks. Medium/low severity surfaces
    as soft advisory via :func:`_check_mlx_version_soft_advisory` (M5 R1
    fix — restores parity with G4 advisory pattern).
    """
    version = _installed_version("mlx")
    if version is None:
        return None  # mlx not installed → no version to block
    advise = MLX_VERSION_BLOCKLIST.get(version)
    if advise is None:
        return None
    severity = advise.get("severity", "medium")
    if severity not in ("critical", "high"):
        return None  # medium/low surfaces as advisory in _check_mlx_version_soft_advisory
    return (
        "G3_mlx_version_blocklist",
        f"mlx=={version} flagged severity={severity} "
        f"({advise.get('reason', 'see blocklist')}) — "
        f"ref={advise.get('ref', 'metal_guard.MLX_VERSION_BLOCKLIST')}",
    )


# R2 polish: severity vocabulary — defends against typos like "medium-high"
# that would emit non-canonical advisory ids (W_mlx_version_medium-high).
_KNOWN_SEVERITIES: frozenset[str] = frozenset({"critical", "high", "medium", "low", "info"})


def _check_mlx_version_soft_advisory() -> tuple[str, str] | None:
    """Soft advisory variant of G3 — surfaces medium/low/info severity hits.

    M5 R1 fix: previously medium/low severity entries silently disappeared
    (gate returned None, no advisory raised). Now they appear in
    :attr:`SpawnVerdict.advisories` so caller sees the full picture.

    R2 polish: severity normalized to canonical vocabulary; off-vocab
    entries (typo / format error in BLOCKLIST) surface as
    ``W_mlx_version_unknown`` so callers can pattern-match reliably.
    """
    version = _installed_version("mlx")
    if version is None:
        return None
    advise = MLX_VERSION_BLOCKLIST.get(version)
    if advise is None:
        return None
    severity = advise.get("severity", "medium")
    if severity in ("critical", "high"):
        return None  # already handled by hard gate
    label = severity if severity in _KNOWN_SEVERITIES else "unknown"
    return (
        f"W_mlx_version_{label}",
        f"mlx=={version} flagged severity={severity}: "
        f"{advise.get('reason', 'see MLX_VERSION_BLOCKLIST')}",
    )


# M3 R1 fix: known workload types — typo ('text-generation' with hyphen
# vs underscore) silently no-ops G4. Validate at entry + log.warning so
# caller has signal. NOT a blocker (forward-compat) — soft advisory only.
_KNOWN_WORKLOAD_TYPES: frozenset[str] = frozenset({
    "text_generation",
    "long_context_text",
    "vision_ocr",
    "speech_asr",
    "lora_training",
    "embedding",
    "short_text_classify",
})


# M4 R1 fix: override `≥20 chars` is gameable ("trust me bro xxxxxxxx" 24c
# passes). Token requirement directly inherits the panic #11 lesson (manual
# touch ack empty-content bypass). Reason MUST reference one of these
# operational tokens to demonstrate intentional override under known context.
_OVERRIDE_REQUIRED_TOKENS: tuple[str, ...] = (
    "panic_gate",
    "cooldown",
    "ack=",
    "bench",
    "monitoring",
    "issue:",
    "panic_acknowledged",
)
# R2 polish: tokens MUST be lowercase (reason matched via .lower()).
assert all(t == t.lower() for t in _OVERRIDE_REQUIRED_TOKENS), (
    "_OVERRIDE_REQUIRED_TOKENS entries must be lowercase"
)
_OVERRIDE_MIN_CHARS: int = 20


def _validate_override_reason(reason: str) -> str | None:
    """Return error message if override reason is invalid, else None.

    Two checks (both must pass):
      1. ≥ ``_OVERRIDE_MIN_CHARS`` chars (defends against blank/whitespace)
      2. Must reference one of ``_OVERRIDE_REQUIRED_TOKENS`` (operational
         context — defends against "trust me bro" bypass)
    """
    if len(reason) < _OVERRIDE_MIN_CHARS:
        return (
            f"override_with_reason must be ≥{_OVERRIDE_MIN_CHARS} chars "
            f"(got {len(reason)} chars)"
        )
    lower = reason.lower()
    if not any(tok in lower for tok in _OVERRIDE_REQUIRED_TOKENS):
        return (
            f"override_with_reason must reference one of "
            f"{list(_OVERRIDE_REQUIRED_TOKENS)} (operational context required) — "
            "see CHANGELOG v0.12 'Override' section for examples"
        )
    return None


def _check_workload_advisory_gate(
    workload_type: str,
) -> tuple[str, str] | None:
    """G4: WORKLOAD_ADVISORIES tier=critical gate.

    Soft advisories (tier != critical) become :attr:`SpawnVerdict.advisories`.
    """
    advisory = WORKLOAD_ADVISORIES.get(workload_type)
    if advisory is None:
        return None
    if advisory.get("tier") != "critical":
        return None
    return (
        "G4_workload_critical",
        f"workload {workload_type!r} flagged tier=critical: "
        f"{advisory.get('reason', 'see WORKLOAD_ADVISORIES')}",
    )


def _check_workload_soft_advisory(
    workload_type: str,
) -> tuple[str, str] | None:
    """Soft advisory variant (tier != critical → returned as advisory)."""
    advisory = WORKLOAD_ADVISORIES.get(workload_type)
    if advisory is None or advisory.get("tier") == "critical":
        return None
    return (
        f"W_workload_{advisory.get('tier', 'advisory')}",
        f"workload {workload_type!r} advisory: "
        f"{advisory.get('reason', '')}",
    )


def _detect_gpu_family_for_gate() -> str | None:
    """Best-effort GPU family detection via :func:`apple_gpu_family`.

    Returns family string (e.g. ``"M5"``) or None if detection fails (mlx
    not importable or non-Apple Silicon).
    """
    try:
        info = apple_gpu_family()
    except Exception as e:  # noqa: BLE001 — detection must never crash gate
        log.debug("apple_gpu_family detection failed: %s", e)
        return None
    return info.get("family") if isinstance(info, dict) else None


def authorize_mlx_spawn(
    *,
    model_id: str,
    workload_type: str = "text_generation",
    gpu_family: str | None = None,
    override_with_reason: str | None = None,
    audit_log_path: Path | str | None = None,
) -> SpawnVerdict:
    """Pre-spawn authorization for MLX subprocess invocations.

    Evaluates 4 hard gates (G1-G4, any failure → ``allowed=False``) plus
    soft advisories (W1-W3, surfaced in ``SpawnVerdict.advisories`` but
    never blocking). See the module-level banner above ``SpawnVerdict``
    for the gate roster.

    Args:
        model_id: HuggingFace-style model identifier (e.g.
            ``"mlx-community/gemma-4-31b-it-8bit"``).
        workload_type: Caller-declared workload class. Common values:
            ``"text_generation"``, ``"long_context_text"``,
            ``"vision_ocr"``, ``"speech_asr"``, ``"lora_training"``.
            Used for WORKLOAD_ADVISORIES lookup.
        gpu_family: Override GPU family detection (mainly for testing).
            Auto-detected via :func:`apple_gpu_family` when None.
        override_with_reason: Bypass blockers when caller provides reason
            ≥20 chars. Verdict still records the override; audit log is
            written. NEVER silent override.
        audit_log_path: Where to append override events. Defaults to
            ``~/.cache/metal-guard/spawn_audit.jsonl`` when None.

    Returns:
        :class:`SpawnVerdict` with structured blockers / advisories.

    Example:
        >>> verdict = authorize_mlx_spawn(
        ...     model_id="mlx-community/Phi-4-mini-instruct-4bit",
        ...     workload_type="text_generation",
        ... )
        >>> if not verdict.allowed:
        ...     for gate, reason in verdict.blockers:
        ...         print(f"BLOCKED [{gate}]: {reason}")
        ...     raise RuntimeError("metal-guard blocked spawn")
        >>> # spawn subprocess here

    Override (use sparingly — every override is audited):
        >>> verdict = authorize_mlx_spawn(
        ...     model_id="dangerous-model",
        ...     override_with_reason="research bench under controlled "
        ...                          "conditions, monitoring panic_gate",
        ... )
        >>> assert verdict.allowed and verdict.override_used
    """
    if gpu_family is None:
        gpu_family = _detect_gpu_family_for_gate()

    # M3 R1 fix: validate workload_type — typo silently no-ops G4 otherwise.
    if workload_type not in _KNOWN_WORKLOAD_TYPES:
        log.warning(
            "authorize_mlx_spawn: unknown workload_type=%r — G4 gate will no-op. "
            "Known types: %s",
            workload_type,
            sorted(_KNOWN_WORKLOAD_TYPES),
        )

    blockers: list[tuple[str, str]] = []
    advisories: list[tuple[str, str]] = []

    # Hard gates (any → blocked). All evaluated for full visibility — short-
    # circuit would hide downstream gates (G2-G4 still problematic post-G1).
    for gate_fn in (
        lambda: _check_panic_cooldown_gate(),
        lambda: _check_known_panic_gate(model_id, gpu_family),
        lambda: _check_mlx_version_blocklist_gate(),
        lambda: _check_workload_advisory_gate(workload_type),
    ):
        result = gate_fn()
        if result is not None:
            blockers.append(result)

    # Soft advisories (do NOT block).
    if (soft := _check_workload_soft_advisory(workload_type)) is not None:
        advisories.append(soft)
    if (soft := _check_mlx_version_soft_advisory()) is not None:
        advisories.append(soft)
    if workload_type not in _KNOWN_WORKLOAD_TYPES:
        advisories.append((
            "W_unknown_workload_type",
            f"workload_type {workload_type!r} not in _KNOWN_WORKLOAD_TYPES — "
            f"G4 gate cannot fire; consider one of {sorted(_KNOWN_WORKLOAD_TYPES)}",
        ))

    # Override path.
    override_used = False
    allowed = not blockers
    if blockers and override_with_reason is not None:
        # M4 R1 fix: token requirement (was just len ≥20 — gameable).
        err = _validate_override_reason(override_with_reason)
        if err is not None:
            blockers.append(("G_override_reason_invalid", err))
        else:
            override_used = True
            allowed = True
            _audit_spawn_override(
                model_id=model_id,
                workload_type=workload_type,
                gpu_family=gpu_family,
                blockers=blockers,
                reason=override_with_reason,
                audit_log_path=audit_log_path,
            )

    return SpawnVerdict(
        allowed=allowed,
        blockers=tuple(blockers),
        advisories=tuple(advisories),
        gpu_family=gpu_family,
        override_used=override_used,
    )


def _audit_spawn_override(
    *,
    model_id: str,
    workload_type: str,
    gpu_family: str | None,
    blockers: list[tuple[str, str]],
    reason: str,
    audit_log_path: Path | str | None,
) -> None:
    """Append override event to JSONL audit log. Never raises (best-effort).

    M1 R1 fix: atomic single-write via os.write + fsync (was buffered file
    handle which loses records on crash + can interleave on concurrent
    writers when payload >PIPE_BUF). Mode 0o600 (audit log may contain
    sensitive model_id / workload).
    """
    import json as _json
    import os as _os
    from datetime import datetime, timezone

    if audit_log_path is None:
        audit_dir = Path.home() / ".cache" / "metal-guard"
        audit_log_path = audit_dir / "spawn_audit.jsonl"
    audit_path = Path(audit_log_path)
    try:
        audit_path.parent.mkdir(parents=True, exist_ok=True)
        record = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "event": "spawn_override",
            "model_id": model_id,
            "workload_type": workload_type,
            "gpu_family": gpu_family,
            "blockers": [list(b) for b in blockers],
            "override_reason": reason,
        }
        data = (_json.dumps(record, ensure_ascii=False) + "\n").encode("utf-8")
        # POSIX O_APPEND atomic for writes ≤ PIPE_BUF (4096B on macOS) —
        # records are typically <1KB so single write is atomic. fsync
        # forces durability before returning so process crash doesn't
        # lose the record (audit trail invariant).
        fd = _os.open(str(audit_path), _os.O_WRONLY | _os.O_CREAT | _os.O_APPEND, 0o600)
        try:
            _os.write(fd, data)
            _os.fsync(fd)
        finally:
            _os.close(fd)
    except Exception as e:  # noqa: BLE001 — audit must never block spawn
        log.warning("audit log append failed: %s", e)
