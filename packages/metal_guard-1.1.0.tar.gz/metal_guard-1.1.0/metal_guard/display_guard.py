"""display_guard — LoRA + display-active panic precheck.

Direct mitigation for `mlx#3267
<https://github.com/ml-explore/mlx/issues/3267>`_. zcbenz's only
upstream advice is the env var ``AGX_RELAX_CDM_CTXSTORE_TIMEOUT=1``
(or sleep the display via ``caffeinate -d off``). The bug: when LoRA
training runs while the display is active, the GPU watchdog kills
inference in the middle of a kernel.

This module:

1. Detects display state via ``pmset`` (0 dependency, 0 cost).
2. Precheck for LoRA workloads — surfaces a critical advisory + the
   AGX env mitigation if display is active.
3. Optional auto-setenv helper that callers wrap subprocess invocations
   with so the AGX flag propagates to the worker's environ.

Best-effort: detection failures default to ``True`` (assume display ON,
err on the side of issuing the advisory).
"""
from __future__ import annotations

import logging
import os
import subprocess
from dataclasses import dataclass
from typing import Mapping

log = logging.getLogger(__name__)

# pmset reports DevicePowerState=4 when display is on / lit. State=1 is
# dim/idle, state=0 is fully off. Treat dim as "active enough" for the
# mlx#3267 watchdog: the watchdog operates on display-server presence,
# not brightness.
_PMSET_ACTIVE_TOKENS: tuple[str, ...] = (
    "DevicePowerState=4",
    "DevicePowerState=3",
)
_PMSET_TIMEOUT_SEC = 2.0

# Cache the answer for a short interval — pmset shells out and the
# answer changes on the order of seconds at fastest. Caller can pass
# force=True to bypass.
_CACHE_TTL_SEC = 5.0
_cache_ts: float = 0.0
_cache_active: bool = True  # pessimistic default

# zcbenz's recommended env var (mlx#3267). When set in the worker
# environment, it relaxes the GPU watchdog timeout enough for LoRA
# kernels to complete during display activity. Trade-off: a hung kernel
# takes longer to be reaped, but the panic class is avoided.
AGX_RELAX_ENV_KEY = "AGX_RELAX_CDM_CTXSTORE_TIMEOUT"
AGX_RELAX_ENV_VALUE = "1"


@dataclass(frozen=True)
class LoRAVerdict:
    """Result of :func:`precheck_lora_workload`.

    Attributes:
        safe: True iff caller should proceed without modifying spawn env.
        display_active: pmset reading at check time.
        advisory: Single human-readable string when not safe (None when safe).
        env_mitigation: dict to merge into subprocess env if proceeding
            anyway (caller decision).
        upstream_refs: Tuple of relevant upstream issue URLs.
    """
    safe: bool
    display_active: bool
    advisory: str | None
    env_mitigation: dict[str, str]
    upstream_refs: tuple[str, ...] = ()


def is_display_active(*, force: bool = False) -> bool:
    """Best-effort: True if the display is on / dim (mlx#3267 watchdog active).

    Uses ``pmset -g powerstate IODisplayWrangler``. Cached 5s to avoid
    shelling out per call. ``force=True`` bypasses cache.

    On failure (pmset missing, timeout, parse error) returns ``True``
    so the precheck errs toward issuing the advisory.
    """
    global _cache_ts, _cache_active
    import time as _time

    if not force:
        now = _time.monotonic()
        if (now - _cache_ts) < _CACHE_TTL_SEC and _cache_ts > 0:
            return _cache_active

    try:
        result = subprocess.run(
            ["pmset", "-g", "powerstate", "IODisplayWrangler"],
            capture_output=True,
            text=True,
            timeout=_PMSET_TIMEOUT_SEC,
            check=False,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
        log.debug("display_guard: pmset query failed (%s) — assume active", exc)
        return True
    except Exception as exc:  # noqa: BLE001 defensive
        log.debug("display_guard: pmset crashed (%s) — assume active", exc)
        return True

    # R2 P1: pmset returncode != 0 OR stdout lacking any DevicePowerState=
    # token → unparseable answer. Default conservative (active=True) so the
    # precheck errs toward issuing the advisory rather than falsely
    # clearing it. Without this guard, an empty / malformed stdout slips
    # through the `any(...)` check as ``False`` (display reported inactive).
    stdout = result.stdout or ""
    if result.returncode != 0 or "DevicePowerState=" not in stdout:
        log.debug(
            "display_guard: pmset rc=%s stdout-token-missing — assume active. "
            "stdout-head=%r",
            result.returncode, stdout[:80],
        )
        active = True
    else:
        active = any(tok in stdout for tok in _PMSET_ACTIVE_TOKENS)
    _cache_ts = _time.monotonic()
    _cache_active = active
    return active


def precheck_lora_workload(
    *,
    model_id: str | None = None,
    force_display_check: bool = False,
) -> LoRAVerdict:
    """Refuse LoRA-style workloads while display is active (mlx#3267).

    Returns a :class:`LoRAVerdict`. If display is active:
    - ``safe=False``
    - ``advisory`` describes mitigation options
    - ``env_mitigation`` carries the AGX flag the caller can apply
      to the subprocess env if they proceed anyway

    Caller flow::

        v = precheck_lora_workload(model_id="...")
        if not v.safe:
            log.warning(v.advisory)
            env = {**os.environ, **v.env_mitigation}
            subprocess.run(..., env=env)
    """
    active = is_display_active(force=force_display_check)
    if not active:
        return LoRAVerdict(
            safe=True,
            display_active=False,
            advisory=None,
            env_mitigation={},
        )

    advisory = (
        "LoRA workload requested while display is ACTIVE — mlx#3267 GPU "
        "watchdog will kill the training kernel. Mitigations:\n"
        f"  (a) Set env {AGX_RELAX_ENV_KEY}={AGX_RELAX_ENV_VALUE} in the "
        "subprocess (relaxes watchdog timeout).\n"
        "  (b) Run `caffeinate -d` then sleep display via System Settings, "
        "OR `pmset displaysleepnow`, before invoking.\n"
        "  (c) Switch to remote SSH session with display sleep timer reached."
    )

    # Best-effort corpus emit (never raises)
    try:
        from metal_guard.corpus import append_event
        append_event(
            "lora_display_advisory",
            model_id=model_id,
            extra={"display_active": True, "agx_env_recommended": True},
        )
    except Exception:  # noqa: BLE001 corpus best-effort
        pass

    return LoRAVerdict(
        safe=False,
        display_active=True,
        advisory=advisory,
        env_mitigation={AGX_RELAX_ENV_KEY: AGX_RELAX_ENV_VALUE},
        upstream_refs=("https://github.com/ml-explore/mlx/issues/3267",),
    )


def apply_agx_mitigation(env: Mapping[str, str] | None = None) -> dict[str, str]:
    """Return a fresh env dict with the AGX_RELAX env var injected.

    Helper for callers that already have a base env (e.g. from
    ``os.environ.copy()``) and want to merge in the mitigation without
    the verbose dict-spread pattern.

    Does NOT mutate the input mapping (immutable-data convention).
    """
    out: dict[str, str] = dict(env) if env is not None else dict(os.environ)
    out[AGX_RELAX_ENV_KEY] = AGX_RELAX_ENV_VALUE
    return out
