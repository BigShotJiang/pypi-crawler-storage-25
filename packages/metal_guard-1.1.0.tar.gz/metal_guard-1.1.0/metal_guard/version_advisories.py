"""Version-advisory database + upstream defensive-patch installer."""

from __future__ import annotations

import datetime
import gc
import glob
import json
import logging
import multiprocessing
import os
import pathlib
import re
import shutil
import signal
import sys
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from multiprocessing.connection import Connection
from pathlib import Path
from typing import Any, Callable, Generator, Iterator, Tuple, TypeVar

from metal_guard._constants import log

# ---------------------------------------------------------------------------
# Version advisory system (v0.6.0)
# ---------------------------------------------------------------------------
# Static database of known-bad (mlx, mlx-lm, mlx-vlm) version combos
# mapped to upstream issue numbers + severity. Use
# ``check_version_advisories()`` to get the active advisories for the
# packages installed in the current environment.
#
# Maintenance policy:
#   * Only list issues that are OPEN upstream, or CLOSED but not yet
#     fixed in a shipped release. Remove entries once the fix reaches
#     a PyPI release.
#   * Severity: "critical" — crash / kernel panic / data loss
#                "high"    — feature broken, workaround exists
#                "medium"  — warning noise, correctness preserved
#                "info"    — observability note
#   * Keep entries short; link to the upstream issue for detail.
# ---------------------------------------------------------------------------

# Each entry is (package, version_spec, advisory_dict).
# version_spec is a string compared with ``packaging.specifiers.SpecifierSet``;
# e.g. "==0.31.2" matches only that exact version, ">=0.31.2,<0.32"
# matches that range.
_VERSION_ADVISORIES: list[tuple[str, str, dict[str, Any]]] = [
    (
        "mlx-lm",
        "==0.31.2",
        {
            "issue": "ml-explore/mlx-lm#1128",
            "severity": "high",
            "title": "TokenizerWrapper.think_start_id crashes when _think_start_tokens is None",
            "url": "https://github.com/ml-explore/mlx-lm/issues/1128",
            "symptom": "TypeError: object of type 'NoneType' has no len()",
            "mitigation": (
                "Call ``install_upstream_defensive_patches()`` to install "
                "a safe accessor, or downgrade to mlx-lm 0.31.1."
            ),
        },
    ),
    (
        "mlx-lm",
        "==0.31.2",
        {
            "issue": "ml-explore/mlx-lm#1139",
            "severity": "high",
            "title": "0.31.2 regression: broadcast errors under multi-agent voting",
            "url": "https://github.com/ml-explore/mlx-lm/issues/1139",
            "symptom": "broadcast error after second voting round in 0.31.2 (not 0.31.1)",
            "mitigation": "Downgrade to mlx-lm 0.31.1 until upstream fix ships.",
        },
    ),
    (
        "mlx-lm",
        "==0.31.2",
        {
            "issue": "ml-explore/mlx-lm#1081",
            "severity": "medium",
            "title": "ArraysCache.is_trimmable() returns True but trim() method missing",
            "url": "https://github.com/ml-explore/mlx-lm/issues/1081",
            "symptom": (
                "AttributeError on speculative-decoding MTP perfect cache hits"
            ),
            "mitigation": (
                "Affects speculative-decoding callers only. Guard with "
                "``hasattr(cache, 'trim')`` before invoking."
            ),
        },
    ),
    (
        "mlx",
        "<0.31.2",
        {
            "issue": "ml-explore/mlx#3348",
            "severity": "info",
            "title": "CommandEncoder thread-local fix merged 2026-04-01 but not in this release",
            "url": "https://github.com/ml-explore/mlx/pull/3348",
            "symptom": (
                "Concurrent MLX dispatches across threads still risk the "
                "IOGPUFamily kernel panic on Apple Silicon."
            ),
            "mitigation": (
                "Keep METALGUARD_MODE defensive (default). Observer mode "
                "is only safe once mlx ships a release containing #3348."
            ),
        },
    ),
    # ── 2026-04-15 mlx-vlm 0.4.4 cluster ──────────────────────────────────
    (
        "mlx-vlm",
        "<0.4.5",
        {
            "issue": "Blaizzy/mlx-vlm#967",
            "severity": "critical",
            "title": "TurboQuant fused quantize race condition (decode T=1 silent corruption)",
            "url": "https://github.com/Blaizzy/mlx-vlm/pull/967",
            "symptom": (
                "Race on Metal threadgroup `packed_shared[w] |= idx_val << shift` "
                "(non-atomic) corrupts decode-time T=1 kernels. 4-bit "
                "TurboQuant output measurably worse than 2-bit; existing "
                "tests (T>1 prefill path) pass unchanged, making this a "
                "silent regression."
            ),
            "mitigation": (
                "Upgrade to mlx-vlm >= 0.4.5 when released (fix merged "
                "2026-04-07). Until then, avoid kv_quant_scheme=\"turboquant\" "
                "for decode-heavy workloads. Recommend PPL / logit cosine "
                "quality gate before trusting any TQ speedup numbers."
            ),
        },
    ),
    (
        "mlx-vlm",
        "==0.4.4",
        {
            "issue": "Blaizzy/mlx-vlm#1016",
            "severity": "high",
            "title": "prefill_attention always returns None after #909 (silent full dequantize)",
            "url": "https://github.com/Blaizzy/mlx-vlm/issues/1016",
            "symptom": (
                "Downstream projects that create TurboQuantKVCache instances "
                "*before* prefill silently dequantize the entire KV to fp16 "
                "during prefill (~31 GB activation memory at 128K context "
                "on gemma-4-31B per PR #939 benchmarks)."
            ),
            "mitigation": (
                "Only affects callers that build TQ caches externally. "
                "mlx-vlm's own generate() uses post-conversion and is "
                "unaffected. If affected, pin mlx-vlm < the upgrade "
                "containing the fix PR or keep TQ disabled at prefill-time."
            ),
        },
    ),
    (
        "mlx-vlm",
        "==0.4.4",
        {
            "issue": "Blaizzy/mlx-vlm#1011",
            "severity": "high",
            "title": "Gemma 4 loading fails with transformers 5.5.x (ReasoningEffort ImportError)",
            "url": "https://github.com/Blaizzy/mlx-vlm/issues/1011",
            "symptom": (
                "ImportError: cannot import name 'ReasoningEffort' from "
                "'transformers' when loading any Gemma 4 variant via "
                "mlx_vlm.load()."
            ),
            "mitigation": (
                "Pin transformers < 5.5 in venvs that load Gemma 4 via "
                "mlx-vlm. No monkey-patch available — transformers API "
                "removed the attribute."
            ),
        },
    ),
    (
        "mlx-vlm",
        "==0.4.4",
        {
            "issue": "Blaizzy/mlx-vlm#943",
            "severity": "critical",
            "title": "Gemma 4 26b-a4b-it-4bit vision produces garbage (text-only unaffected)",
            "url": "https://github.com/Blaizzy/mlx-vlm/issues/943",
            "symptom": (
                "NaN propagation in all-masked SDPA padding rows on Gemma 4 "
                "vision branch → degenerate output on mlx-community/"
                "gemma-4-26b-a4b-it-4bit image inputs. Text-only path OK."
            ),
            "mitigation": (
                "Avoid gemma-4-26b-a4b-it-4bit for vision tasks until PR "
                "#1006 ships. Substitute pixtral-12b-4bit or "
                "gemma-4-e4b-it-4bit for vision."
            ),
            "scope": "model:mlx-community/gemma-4-26b-a4b-it-4bit backend:mlx-vlm",
        },
    ),
    # ── 2026-04-16 community survey additions ─────────────────────────────
    # Scanned every MLX / mlx-lm / mlx-vlm issue since mlx-lm 0.31.2
    # released (2026-02-01+). These five are actionable safety /
    # correctness reports affecting typical MLX usage patterns.
    (
        "mlx",
        "<=0.31.1",
        {
            "issue": "ml-explore/mlx#3384",
            "severity": "critical",
            "title": "fast.scaled_dot_product_attention numerical divergence on 4-bit quantized models",
            "url": "https://github.com/ml-explore/mlx/issues/3384",
            "symptom": (
                "Token repetition / divergent logits from the fused SDPA "
                "kernel when inputs are 4-bit quantized. Silent — "
                "generation does not crash, just produces worse output. "
                "Non-quantised correctness tests pass unchanged; this is "
                "a regression only visible at the 4-bit decode step."
            ),
            "mitigation": (
                "4-bit is the default deployment format for many users. "
                "No safe in-place shim; fall back to a non-fused attention "
                "path or avoid affected sizes if quality regression "
                "appears. Monitor PPL / logit cosine before trusting "
                "4-bit speedups until a fix lands."
            ),
            "scope": "backend:mlx",
        },
    ),
    (
        "mlx-lm",
        ">=0.31.0,<=0.31.2",
        {
            "issue": "ml-explore/mlx-lm#897",
            "severity": "high",
            "title": "mlx_lm.server: chat completions crash with transformers >= 5.0 (return_dict=False missing)",
            "url": "https://github.com/ml-explore/mlx-lm/issues/897",
            "symptom": (
                "Server chat endpoint raises because call to HF transformers "
                "no longer accepts the positional signature used here. "
                "Only affects `mlx_lm.server`; CLI `generate` is unaffected."
            ),
            "mitigation": (
                "Pin transformers < 5.0 in venvs that launch the HTTP "
                "server, or wait for a mlx-lm release that includes the "
                "server-side fix."
            ),
            "scope": "backend:mlx-lm component:server",
        },
    ),
    (
        "mlx-vlm",
        "==0.4.4",
        {
            "issue": "Blaizzy/mlx-vlm#999",
            "severity": "high",
            "title": "server clears Metal cache after every request — destroys KV prefix cache",
            "url": "https://github.com/Blaizzy/mlx-vlm/issues/999",
            "symptom": (
                "`mlx_vlm` server calls `mx.clear_cache()` (and sync "
                "barriers) at the end of every request handler. The "
                "per-conversation KV prefix cache is dropped, forcing "
                "full re-prefill every turn — major latency plus Metal "
                "allocator thrash that can cascade into IOGPUFamily "
                "pressure."
            ),
            "mitigation": (
                "If running the HTTP server, disable per-request cache "
                "clears and rely on a between-model cooldown policy "
                "instead. Upstream fix pending."
            ),
            "scope": "backend:mlx-vlm component:server",
        },
    ),
    (
        "mlx",
        "<=0.31.2",
        {
            "issue": "ml-explore/mlx#3350",
            "severity": "high",
            "title": "Metal allocator buffer pool grows unboundedly on monotonic-size allocations",
            "url": "https://github.com/ml-explore/mlx/issues/3350",
            "symptom": (
                "MetalAllocator::free() unconditionally recycles freed "
                "buffers into buffer_cache_ until max_pool_size_ (~1.5 × "
                "max_rec_size ≈ 192 GB on a 128 GB Mac). Sequential "
                "increasing-size allocations (monotonic KV cache growth "
                "across long-context requests) can never reuse cached "
                "buffers — process footprint grows unbounded. Reporter "
                "observed 108 GB used where 34 GB was expected."
            ),
            "mitigation": (
                "Maintainer closed won't-fix 2026-04-04 (framework-level "
                "eviction would kill inference perf). Caller-side: "
                "1) Call `mx.set_cache_limit(N)` at subprocess startup "
                "sized to the model's working set (2-4× weight bytes) "
                "instead of the 192 GB default. "
                "2) Call `mx.clear_cache()` when KV growth crosses a "
                "threshold (e.g. >64k tokens). "
                "3) The one-model-per-subprocess pattern in "
                "`MLXSubprocessRunner` avoids the pool-growth path because "
                "each subprocess exits entirely between models."
            ),
            "scope": "backend:mlx",
        },
    ),
    (
        "mlx",
        "<=0.31.2",
        {
            "issue": "ml-explore/mlx#3390",
            "severity": "high",
            "title": "Metal completion-handler check_error throws → std::terminate → uncatchable SIGABRT",
            "url": "https://github.com/ml-explore/mlx/issues/3390",
            "symptom": (
                "`mlx/backend/metal/eval.cpp::check_error(MTL::CommandBuffer*)` "
                "throws std::runtime_error when "
                "`cbuf->status() == CommandBufferStatusError`. Invoked from "
                "3 sites registered via `addCompletedHandler(...)`, "
                "executing on Apple's `com.Metal.CompletionQueueDispatch` "
                "(libdispatch/GCD) queue. libdispatch blocks are not "
                "exception-safe — throw hits __cxa_throw → std::terminate "
                "→ abort() → SIGABRT. Python cannot catch this; try/except "
                "around `mx.eval()` never fires. Duplicate reports: #3224 "
                "(M3 Ultra 6 hr), #3317 (M2 Ultra asyncio race). Umbrella: "
                "ml-explore/mlx#2670. This is the 7th kernel-panic "
                "root-cause class; metal-guard only partially mitigates "
                "(subprocess isolation keeps parent alive + module-import "
                "AGX_RELAX stopgap reduces trigger frequency)."
            ),
            "mitigation": (
                "PR #3318 (check_error_deferred pattern) CLOSED without "
                "merge — maintainer declined on the grounds that process "
                "state is undefined post-throw. No release targets this "
                "fix. metal-guard auto-sets `AGX_RELAX_CDM_CTXSTORE_TIMEOUT=1` "
                "at module import (reduces GPU watchdog false-positives "
                "that most commonly trigger the abort). Subprocess "
                "isolation (MLXSubprocessRunner) mitigates blast radius: "
                "parent survives, sibling subprocesses unaffected; "
                "in-flight request is lost. Do NOT attempt a C++ "
                "terminate handler — state is undefined post-throw."
            ),
            "scope": "backend:mlx",
        },
    ),
    # ── W9 forward-drift sync (2026-05-18) ────────────────────────────────
    # Three advisories present in the upstream source-of-truth advisory
    # database but previously missing here. Mitigation text uses neutral,
    # deployment-agnostic wording.
    (
        "mlx-lm",
        "<0.31.3",
        {
            "issue": "ml-explore/mlx-lm#1090",
            "severity": "info",
            "title": "Thread-local generation stream shipped in mlx-lm 0.31.3 — this env is older",
            "url": "https://github.com/ml-explore/mlx-lm/pull/1090",
            "symptom": (
                "Every ``generate_step`` in this mlx-lm version shares one "
                "global CommandEncoder stream — observer-mode ThreadPool "
                "parallelization will race on Metal without 0.31.3's "
                "``mx.new_thread_local_stream`` wrapper."
            ),
            "mitigation": (
                "Upgrade to mlx-lm >= 0.31.3 (released 2026-04-22) — it "
                "bundles #1158 (Gemma 4 KV-shared unused projections) and "
                "#1167 (TokenizerWrapper.think_start_id NoneType). mlx#3348 "
                "is the companion mlx-side change. NOTE: 0.31.3 does NOT by "
                "itself make observer-mode ThreadPool parallelization safe "
                "— PR #1090's thread-local stream fix is incomplete (see the "
                "mlx-lm#1256 ``>=0.31.3`` advisory below)."
            ),
        },
    ),
    (
        "mlx-lm",
        ">=0.31.3",
        {
            "issue": "ml-explore/mlx-lm#1256",
            "severity": "high",
            "title": "mlx-lm 0.31.3 thread-local stream fix (#1090) incomplete — non-import-thread generation still crashes",
            "url": "https://github.com/ml-explore/mlx-lm/issues/1256",
            "symptom": (
                "mlx_lm.server — or any caller that runs generation on a "
                "thread other than the one that imported mlx-lm — crashes "
                "on the first request with ``RuntimeError: There is no "
                "Stream(gpu, 1) in current thread``. PR #1090's thread-local "
                "generation stream fix is incomplete: ``generation_stream`` "
                "is still module-scoped. Reported on sliding-window models "
                "(Gemma 4 RotatingKVCache) and independently reproduced on "
                "non-sliding-window models."
            ),
            "mitigation": (
                "Supersedes the optimistic ``<0.31.3`` #1090 advisory: "
                "0.31.3 does NOT make observer-mode ThreadPool "
                "parallelization safe. Until upstream ships a structural "
                "fix, run generation only on the thread that imported "
                "mlx-lm, or keep observer mode disabled. A caller using the "
                "library API on the main thread is unaffected; this gates "
                "any observer-mode ThreadPool parallelization."
            ),
            "scope": "backend:mlx-lm component:server",
        },
    ),
    (
        "transformers",
        ">=5.5.0.dev0,<5.6",
        {
            "issue": "Blaizzy/mlx-vlm#1011",
            "severity": "high",
            "title": "transformers 5.5.x removed ReasoningEffort — breaks Gemma 4 via mlx-vlm",
            "url": "https://github.com/Blaizzy/mlx-vlm/issues/1011",
            "symptom": (
                "ImportError: cannot import name 'ReasoningEffort' from "
                "'transformers' on any mlx-vlm load() of a Gemma 4 variant. "
                "transformers 5.5 removed the symbol; mlx-vlm has not yet "
                "shipped a compat shim. Detected at the package level here "
                "so the advisory fires regardless of mlx-vlm version."
            ),
            "mitigation": (
                "Pin transformers < 5.5 (e.g. 5.4.x) in environments that "
                "load Gemma 4 via mlx-vlm. Verify with ``pip show "
                "transformers`` before any Gemma-4 vision call. No "
                "monkey-patch available — transformers removed the attribute."
            ),
            "fixed_in": "5.6.0",
            "affected_models": ["gemma-4-*"],
            "scope": "backend:mlx-vlm models:gemma-4",
        },
    ),
]


def _installed_version(package: str) -> str | None:
    """Return the installed version of ``package`` or None if not installed."""
    try:
        import importlib.metadata as metadata
    except ImportError:  # pragma: no cover — Python ≥ 3.8 has this
        return None
    try:
        return metadata.version(package)
    except metadata.PackageNotFoundError:
        return None
    except Exception as exc:  # noqa: BLE001 — diagnostic fallback
        log.debug("_installed_version(%s) failed: %s", package, exc)
        return None


def _spec_matches(version: str, spec: str) -> bool:
    """Return True if ``version`` satisfies ``spec`` (PEP 440 specifier)."""
    try:
        from packaging.specifiers import SpecifierSet
        from packaging.version import Version, InvalidVersion
    except ImportError:
        # packaging is a pip/setuptools transitive dep — nearly universal —
        # but fall back to exact string match if it is missing.
        return version == spec.lstrip("=")
    try:
        return Version(version) in SpecifierSet(spec)
    except (InvalidVersion, ValueError):
        return False


def check_version_advisories(
    *, packages: dict[str, str] | None = None,
) -> list[dict[str, Any]]:
    """Return active advisories for the packages installed in this env.

    Args:
        packages: optional override map of ``{package_name: version}``
            to bypass ``importlib.metadata`` lookup. Useful in tests.

    Returns:
        List of advisory dicts. Each dict has keys ``package``,
        ``installed_version``, ``issue``, ``severity``, ``title``,
        ``url``, ``symptom``, ``mitigation``. Empty list if no known
        issues apply to the current environment.

    Example::

        for a in check_version_advisories():
            print(f"[{a['severity']}] {a['package']} {a['installed_version']} — {a['title']}")
            print(f"    {a['url']}")
    """
    resolved = packages or {}
    active: list[dict[str, Any]] = []
    for pkg, spec, advisory in _VERSION_ADVISORIES:
        installed = resolved.get(pkg) if packages is not None else _installed_version(pkg)
        if installed is None:
            continue
        if not _spec_matches(installed, spec):
            continue
        entry = dict(advisory)
        entry["package"] = pkg
        entry["installed_version"] = installed
        entry["affected_spec"] = spec
        active.append(entry)
    return active


# ---------------------------------------------------------------------------
# Upstream defensive patches (v0.6.0)
# ---------------------------------------------------------------------------
# Narrow, version-gated monkey-patches that install safe shims for known
# mlx-lm bugs without modifying upstream code. Opt-in only — callers
# invoke ``install_upstream_defensive_patches()`` explicitly at program
# start. Each patch is idempotent (tagged on first install, skipped on
# subsequent calls) and auto-skips when the installed package version
# is outside the affected range, so once upstream ships a fix this
# becomes a no-op without any caller change.
# ---------------------------------------------------------------------------


def install_upstream_defensive_patches(*, force: bool = False) -> dict[str, bool]:
    """Install safe accessors for known upstream bugs.

    Each patch is version-gated against the installed package version
    and skipped when upstream has shipped a fix. Idempotent — safe to
    call multiple times. Emits a WARNING log for each patch applied so
    operators can confirm what was installed.

    Args:
        force: bypass the installed-version check. Tests only.

    Returns:
        Dict of ``{patch_name: was_applied}``. ``False`` means the patch
        was skipped (already applied, package missing, version outside
        affected range, or upstream already fixed).

    Example::

        from metal_guard import install_upstream_defensive_patches
        status = install_upstream_defensive_patches()
        # {'mlx_lm_1128_think_start_id': True}
    """
    return {
        "mlx_lm_1128_think_start_id": _patch_mlx_lm_1128(force=force),
    }


def _patch_mlx_lm_1128(*, force: bool) -> bool:
    """Apply defensive shim for ml-explore/mlx-lm#1128.

    ``TokenizerWrapper.think_start_id`` calls ``len(self._think_start_tokens)``
    but ``_infer_thinking()`` can leave that attribute as ``None``, which
    raises ``TypeError`` rather than signalling no think tokens. We
    replace the property with one that returns ``None`` in that case.
    """
    mlx_lm_version = _installed_version("mlx-lm")
    if mlx_lm_version is None:
        return False
    if not force and not _spec_matches(mlx_lm_version, "==0.31.2"):
        return False

    # Resolve via sys.modules so test fixtures that inject a fake
    # ``mlx_lm.tokenizer_utils`` can intercept. A naive
    # ``from mlx_lm import tokenizer_utils`` reads the attribute off
    # the already-imported parent package and bypasses sys.modules.
    _tu = sys.modules.get("mlx_lm.tokenizer_utils")
    if _tu is None:
        try:
            import importlib
            _tu = importlib.import_module("mlx_lm.tokenizer_utils")
        except ImportError:
            return False

    TW = getattr(_tu, "TokenizerWrapper", None)
    if TW is None:
        return False

    existing = getattr(TW, "think_start_id", None)
    if not isinstance(existing, property):
        return False
    if getattr(existing.fget, "_metal_guard_safe", False):
        return False  # idempotent

    def safe_think_start_id(self):  # type: ignore[no-untyped-def]
        tokens = getattr(self, "_think_start_tokens", None)
        if tokens is None:
            return None
        if len(tokens) > 1:
            raise ValueError(
                "multiple think start tokens in TokenizerWrapper — ambiguous"
            )
        return tokens[0] if tokens else None

    safe_think_start_id._metal_guard_safe = True  # type: ignore[attr-defined]
    TW.think_start_id = property(safe_think_start_id)
    log.warning(
        "metal_guard: installed defensive patch for mlx-lm#1128 "
        "(think_start_id None-safety) on mlx-lm %s", mlx_lm_version,
    )
    return True
