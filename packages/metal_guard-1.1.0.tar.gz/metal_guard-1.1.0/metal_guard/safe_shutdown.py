"""safe_shutdown — ordered MLX teardown helper.

Packages the load-bearing per-worker teardown sequence into a reusable
helper.

Background:

* The per-worker teardown order is load-bearing: ``del model ->
  gc.collect() -> mx.clear_cache()`` MUST happen inside the inference
  guard context. Reverse order can reproduce the
  ``IOGPUMemory.cpp:492 prepare_count_underflow`` kernel panic.

* `mlx-lm#1208 <https://github.com/ml-explore/mlx-lm/issues/1208>`_ —
  ``mlx_lm.server`` crashes in a tight loop with "cannot schedule new
  futures after interpreter shutdown" when a ThreadPoolExecutor is not
  drained before model unload during interpreter teardown.

The helper enforces the canonical ordering callers must follow:

    1. Drain the ThreadPoolExecutor (if any) -> ``shutdown(wait=True)``.
    2. ``del`` the model reference (caller passes via a callback).
    3. ``gc.collect()`` to force a generation-0/1/2 sweep.
    4. ``mx.clear_cache()`` to release pooled Metal buffers.
    5. ``mx.synchronize()`` to drain the command buffer.
    6. Optional cooldown sleep so IOGPU pages return to the OS.

Best-effort: every step is wrapped so a single failure (e.g. mlx not
importable in tests) does not break the rest of the sequence. Returns a
:class:`ShutdownReport` summarising what fired so the caller can audit.
"""
from __future__ import annotations

import gc
import time
from dataclasses import dataclass, field
from typing import Any, Callable

from metal_guard._constants import log

_DEFAULT_COOLDOWN_SEC = 2.0
_DEFAULT_THREADPOOL_TIMEOUT_SEC = 5.0


@dataclass
class ShutdownReport:
    """Per-step success/failure record for forensics.

    Attributes:
        threadpool_drained: True if pool.shutdown(wait=True) succeeded
            (None if no pool provided).
        gc_collected: gc.collect() return value (object count freed),
            None if collect raised.
        mx_clear_cache_ok: True if mx.clear_cache() ran without error.
        mx_synchronize_ok: True if mx.synchronize() ran without error.
        cooldown_seconds: Actual sleep duration applied.
        errors: List of (step_name, exception_repr) for any failure.
        elapsed_sec: Total time spent in shutdown.
    """
    threadpool_drained: bool | None = None
    gc_collected: int | None = None
    mx_clear_cache_ok: bool = False
    mx_synchronize_ok: bool = False
    cooldown_seconds: float = 0.0
    errors: list[tuple[str, str]] = field(default_factory=list)
    elapsed_sec: float = 0.0


def safe_inference_shutdown(
    *,
    unload_callback: Callable[[], None] | None = None,
    threadpool: Any | None = None,
    threadpool_timeout: float = _DEFAULT_THREADPOOL_TIMEOUT_SEC,
    cooldown_seconds: float = _DEFAULT_COOLDOWN_SEC,
    model_id: str | None = None,
) -> ShutdownReport:
    """Tear down an MLX model in the canonical safe order.

    Args:
        unload_callback: A zero-arg callable that drops the caller's
            reference to the model (e.g. ``lambda: globals().pop('model', None)``).
            ``None`` means caller has already released the reference and
            wants the helper for the gc + Metal flush only.
        threadpool: Optional ``concurrent.futures.ThreadPoolExecutor``
            (or anything with ``.shutdown(wait=True)``). Drained FIRST
            to avoid the mlx-lm#1208 deadlock.
        threadpool_timeout: Soft warning threshold; we don't enforce a
            hard cancel, but log if shutdown blocked longer than this.
        cooldown_seconds: Sleep applied after Metal clear/sync. Typical
            M1 Ultra needs ~2-3s for IOGPU pages to actually return.
        model_id: Forensic tag for logs / panic_corpus emit. Optional.

    Returns:
        :class:`ShutdownReport` with per-step status. Never raises.
    """
    report = ShutdownReport()
    t0 = time.monotonic()

    # Step 1 — drain threadpool (mlx-lm#1208 guard).
    #
    # R2 P1: bare ``shutdown(wait=True)`` blocks FOREVER on stuck tasks
    # (mlx-lm#1208 itself is a stuck-pool scenario). ``cancel_futures=True``
    # (Python 3.9+) drops pending work so only currently-running tasks
    # have to finish. ``threadpool_timeout`` is now real: we attempt
    # cancel-aware shutdown and fall back if the pool API is non-stdlib.
    if threadpool is not None:
        report.threadpool_drained = False
        try:
            tp_t0 = time.monotonic()
            try:
                threadpool.shutdown(wait=True, cancel_futures=True)
            except TypeError:
                # Pre-3.9 Executor or non-stdlib pool without cancel_futures
                # kwarg — fall back to plain shutdown (caller risk).
                threadpool.shutdown(wait=True)
            report.threadpool_drained = True
            tp_elapsed = time.monotonic() - tp_t0
            if tp_elapsed > threadpool_timeout:
                log.warning(
                    "safe_inference_shutdown[%s]: threadpool drain took "
                    "%.1fs (> %.1fs threshold) — pool may have had pending "
                    "futures; mlx-lm#1208 territory",
                    model_id or "?", tp_elapsed, threadpool_timeout,
                )
        except Exception as exc:  # noqa: BLE001 best-effort
            report.errors.append(("threadpool.shutdown", repr(exc)))
            log.warning(
                "safe_inference_shutdown[%s]: threadpool drain failed: %s",
                model_id or "?", exc,
            )

    # Step 2 — caller drops the model reference
    if unload_callback is not None:
        try:
            unload_callback()
        except Exception as exc:  # noqa: BLE001 best-effort
            report.errors.append(("unload_callback", repr(exc)))
            log.warning(
                "safe_inference_shutdown[%s]: unload_callback failed: %s",
                model_id or "?", exc,
            )

    # Step 3 — force gc to drop the now-unreferenced model graph
    try:
        report.gc_collected = gc.collect()
    except Exception as exc:  # noqa: BLE001 best-effort
        report.errors.append(("gc.collect", repr(exc)))

    # Step 4 + 5 — Metal flush (clear_cache then synchronize)
    try:
        import mlx.core as mx  # type: ignore
    except ImportError:
        # No MLX in test env → skip Metal steps; report fields stay False.
        pass
    except Exception as exc:  # noqa: BLE001 defensive on mlx import
        report.errors.append(("mlx.core import", repr(exc)))
    else:
        try:
            mx.clear_cache()
            report.mx_clear_cache_ok = True
        except Exception as exc:  # noqa: BLE001
            report.errors.append(("mx.clear_cache", repr(exc)))
        try:
            mx.synchronize()
            report.mx_synchronize_ok = True
        except Exception as exc:  # noqa: BLE001
            report.errors.append(("mx.synchronize", repr(exc)))

    # Step 6 — cooldown so IOGPU pages return to OS before next load
    if cooldown_seconds > 0:
        try:
            time.sleep(cooldown_seconds)
            report.cooldown_seconds = cooldown_seconds
        except Exception as exc:  # noqa: BLE001
            report.errors.append(("cooldown sleep", repr(exc)))

    report.elapsed_sec = time.monotonic() - t0

    # Optional corpus emit (best-effort)
    try:
        from metal_guard.corpus import append_event
        append_event(
            "safe_shutdown_complete",
            model_id=model_id,
            extra={
                "threadpool_drained": report.threadpool_drained,
                "gc_collected": report.gc_collected,
                "mx_clear_cache_ok": report.mx_clear_cache_ok,
                "mx_synchronize_ok": report.mx_synchronize_ok,
                "cooldown_seconds": report.cooldown_seconds,
                "errors": [list(e) for e in report.errors],
                "elapsed_sec": round(report.elapsed_sec, 3),
            },
        )
    except Exception as exc:  # noqa: BLE001 corpus is best-effort
        log.debug("safe_shutdown: corpus emit failed: %s", exc)

    return report
