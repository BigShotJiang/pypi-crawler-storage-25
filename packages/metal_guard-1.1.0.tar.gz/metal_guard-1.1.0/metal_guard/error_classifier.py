"""Kernel-panic / MLX-error signature regex tables and classifiers."""

from __future__ import annotations

import datetime
import gc
import glob
import json
import logging
import multiprocessing
import os
import pathlib
import re
import shutil
import signal
import sys
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from multiprocessing.connection import Connection
from pathlib import Path
from typing import Any, Callable, Generator, Iterator, Tuple, TypeVar

from metal_guard._constants import log

# Pattern to detect Metal GPU errors from the C++ runtime.
# Sources:
#   - "Command buffer execution failed...Insufficient Memory" (mlx-lm#883, #1015)
#   - "kIOGPUCommandBufferCallbackErrorOutOfMemory" (mlx-lm#854)
#   - "fPendingMemorySet" (mlx#3346 @yoyaku155 — IOGPUGroupMemory race)
#   - "ImpactingInteractivity" (mlx#3267 @zackedds — GPU watchdog kills
#     MLX when command buffers block WindowServer compositing on MacBook)
_METAL_OOM_PATTERN = re.compile(
    r"Command buffer execution failed.*Insufficient Memory"
    r"|kIOGPUCommandBufferCallbackErrorOutOfMemory"
    r"|fPendingMemorySet"
    r"|ImpactingInteractivity",
    re.IGNORECASE | re.DOTALL,
)


# Kernel-panic classifier.  Maps a human-readable signature name to the
# regex that fingerprints it in `kernel.log` / `log show` output after a
# reboot.  Used by `detect_panic_signature()` so incidents can be tagged
# and triaged rather than lumped together as "panic".
#
# Each entry is keyed by signature name → (regex, short explanation).
# Regexes are case-insensitive and matched with DOTALL so multi-line
# panic backtraces work.
_KERNEL_PANIC_SIGNATURES: dict[str, tuple[re.Pattern[str], str]] = {
    # mlx-lm#883 / #1015 — the original panic reported in summer 2025.
    # Underflow when Metal's IOGPUMemory prepare count drops below zero
    # because a command buffer was released before its dependent ops
    # finished. MetalGuard mitigates via cooldown + thread tracking.
    "prepare_count_underflow": (
        re.compile(
            r"completeMemory\(\)\s*prepare\s*count\s*underflow",
            re.IGNORECASE | re.DOTALL,
        ),
        "IOGPUMemory.cpp:492 — command buffer released before Metal "
        "finished. Reproduces under back-to-back load/unload cycles.",
    ),
    # mlx#3346 @yoyaku155 — second panic signature (IOGPUGroupMemory.cpp:219).
    # Lingering entries in the pending-memory set when a new command
    # buffer is submitted. Typically triggered by rapid model swaps
    # without sufficient cooldown.
    "pending_memory_set": (
        re.compile(
            r"fPendingMemorySet"
            r"|IOGPUGroupMemory\.cpp:219",
            re.IGNORECASE | re.DOTALL,
        ),
        "IOGPUGroupMemory.cpp:219 — pending memory set not drained "
        "before reuse. Mitigation: longer post-unload cooldown.",
    ),
    # mlx#3267 @zcbenz — command-buffer context store timeout on long
    # GPU workloads. Partial fix is AGX_RELAX_CDM_CTXSTORE_TIMEOUT=1
    # (set above at import time).
    "ctxstore_timeout": (
        re.compile(
            r"IOGPUCommandQueue.*context\s*store\s*timeout",
            re.IGNORECASE | re.DOTALL,
        ),
        "AGX command-buffer context store timeout. MetalGuard sets "
        "AGX_RELAX_CDM_CTXSTORE_TIMEOUT=1 at import.",
    ),
    # Generic OOM / command buffer execution failure from the C++ layer.
    # Falls through here if none of the more specific patterns match but
    # the panic still talks about IOGPU + OOM wording.
    "metal_oom": (
        re.compile(
            r"kIOGPUCommandBufferCallbackErrorOutOfMemory"
            r"|Command\s+buffer\s+execution\s+failed.*Insufficient\s+Memory",
            re.IGNORECASE | re.DOTALL,
        ),
        "Metal OOM at command-buffer callback. Raise headroom or "
        "reduce active model footprint.",
    ),
}


def detect_panic_signature(text: str) -> tuple[str | None, str | None]:
    """Classify a kernel-panic log snippet into a known signature.

    Args:
        text: Raw text from ``log show --predicate 'eventMessage CONTAINS "panic"'``,
            ``sudo dmesg``, or the contents of ``/Library/Logs/DiagnosticReports/*.panic``.

    Returns:
        ``(signature_name, explanation)`` — or ``(None, None)`` if no known
        pattern matched. Callers can route unknown panics to a catch-all
        bucket.
    """
    for name, (pattern, explanation) in _KERNEL_PANIC_SIGNATURES.items():
        if pattern.search(text):
            return name, explanation
    return None, None


# ---------------------------------------------------------------------------
# Error classifier (v0.11.0)
#
# Central regex table covering the MLX-related error signatures observed in
# the 2026-04 community sweep. Used by:
#   - SubprocessCrashError to classify stderr → recovery_hint
#   - L10 panic gate (kernel_panic flavour) and L10b abort scanner (process_abort)
#   - L11 orphan monitor (uses signature constants for filter)
#
# Severity vocabulary:
#   "kernel_panic"        — IOGPUMemory.cpp underflow / fPendingMemorySet (reboots Mac)
#   "process_abort"       — generic SIGABRT from MetalStream
#   "command_buffer_oom"  — kIOGPUCommandBufferCallbackErrorOutOfMemory (mlx-lm#1206)
#   "gpu_hang"            — kIOGPUCommandBufferCallbackErrorHang (mlx-vlm#1064)
#   "gpu_page_fault"      — kIOGPUCommandBufferCallbackErrorPageFault
#   "descriptor_leak"     — Resource limit (NNNNNN) exceeded (mlx-lm#1185)
#
# Recovery hints:
#   "wait_lockout"  — kernel panic → defer 2h+ via panic gate
#   "respawn_now"   — process abort → restart subprocess immediately
#   "force_reload"  — descriptor leak → cold-start now (don't wait)
#
# INVARIANT: kernel_panic entries MUST appear before process_abort in the
# table — `classify_mlx_error` is first-match-wins, so when a `.panic` file
# carries both signatures (command-buffer OOM cascading into kernel panic),
# the kernel match wins and the abort counter doesn't trip when reboot
# already happened. Covered by `test_kernel_panic_priority_over_abort`.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ErrorClass:
    """Classification result for an MLX-emitted error string."""
    name: str
    severity: str
    recovery_hint: str
    upstream_refs: tuple[str, ...]
    pattern_str: str


_CLASSIFIER_TABLE: tuple[tuple[re.Pattern[str], ErrorClass], ...] = (
    # ─── Kernel-level panics (reboot machine) — MUST come first ───
    (
        re.compile(
            r"(prepare[_ ]count[_ ]underflow.*(IOGPUMemory\.cpp|completeMemory\(\)))|"
            r"((IOGPUMemory\.cpp|completeMemory\(\)).*prepare[_ ]count[_ ]underflow)",
            re.IGNORECASE | re.DOTALL,
        ),
        ErrorClass(
            name="iogpu_prepare_count_underflow",
            severity="kernel_panic",
            recovery_hint="wait_lockout",
            upstream_refs=(
                "ml-explore/mlx#3186",
                "ml-explore/mlx#3346",
                "ml-explore/mlx-lm#883",
            ),
            pattern_str=r"prepare_count_underflow + (IOGPUMemory.cpp|completeMemory())",
        ),
    ),
    (
        re.compile(
            r"IOGPUGroupMemory\.cpp.*pending.*memory.*set|fPendingMemorySet",
            re.IGNORECASE | re.DOTALL,
        ),
        ErrorClass(
            name="iogpu_pending_memory_set",
            severity="kernel_panic",
            recovery_hint="wait_lockout",
            upstream_refs=("ml-explore/mlx#3186",),
            pattern_str=r"IOGPUGroupMemory.cpp pending_memory_set",
        ),
    ),
    # IOGPUGroupMemory.cpp remove_memory_object() teardown-path panic.
    # ferraro 2026-05-11 (mlx#3186 comment, M3 Ultra 256GB): sibling of the
    # pending_memory_set signature — same IOGPUFamily kext, different
    # teardown path. prepare_count_underflow is the prefill path
    # (completeMemory); this is the object-removal path. Memory not
    # exhausted — GPU-memory-accounting-state corruption. Without this
    # entry the panic falls through to None → misclassified as unknown
    # abort → no wait_lockout. Kept BEFORE the process_abort entries per
    # the kernel-before-abort invariant.
    (
        re.compile(
            r"IOGPUGroupMemory::remove_memory_object|"
            r"IOGPUGroupMemory\.cpp.*memory object not found",
            re.IGNORECASE | re.DOTALL,
        ),
        ErrorClass(
            name="iogpu_remove_memory_object",
            severity="kernel_panic",
            recovery_hint="wait_lockout",
            upstream_refs=("ml-explore/mlx#3186",),
            pattern_str=r"IOGPUGroupMemory::remove_memory_object",
        ),
    ),
    # ─── GPU command-buffer errors (process abort, no reboot) ───
    (
        re.compile(r"kIOGPUCommandBufferCallbackErrorOutOfMemory", re.IGNORECASE),
        ErrorClass(
            name="cmd_buffer_oom",
            severity="command_buffer_oom",
            recovery_hint="respawn_now",
            upstream_refs=("ml-explore/mlx-lm#1206", "ml-explore/mlx-lm#854"),
            pattern_str=r"kIOGPUCommandBufferCallbackErrorOutOfMemory",
        ),
    ),
    (
        re.compile(r"kIOGPUCommandBufferCallbackErrorHang", re.IGNORECASE),
        ErrorClass(
            name="gpu_hang",
            severity="gpu_hang",
            recovery_hint="respawn_now",
            upstream_refs=("Blaizzy/mlx-vlm#1064",),
            pattern_str=r"kIOGPUCommandBufferCallbackErrorHang",
        ),
    ),
    (
        re.compile(
            r"kIOGPUCommandBufferCallbackErrorPageFault|GPU Address Fault Error",
            re.IGNORECASE,
        ),
        ErrorClass(
            name="gpu_page_fault",
            severity="gpu_page_fault",
            recovery_hint="respawn_now",
            upstream_refs=("Blaizzy/mlx-vlm#1064",),
            pattern_str=r"kIOGPUCommandBufferCallbackErrorPageFault",
        ),
    ),
    # ─── Metal descriptor leak (slow degradation) ───
    (
        re.compile(
            r"\[metal::malloc\]\s+Resource limit\s*\(\s*(\d+)\s*\)\s*exceeded|"
            r"Resource limit \(\d+\) exceeded",
            re.IGNORECASE,
        ),
        ErrorClass(
            name="metal_descriptor_leak",
            severity="descriptor_leak",
            recovery_hint="force_reload",
            upstream_refs=("ml-explore/mlx-lm#1185",),
            pattern_str=r"Resource limit (N) exceeded",
        ),
    ),
    # ─── SIGABRT from MetalStream completion handler ───
    (
        re.compile(
            r"std::terminate.*MetalStream::add_temporary|"
            r"check_error.*Metal.*SIGABRT|"
            r"libc\+\+abi.*MetalStream",
            re.IGNORECASE | re.DOTALL,
        ),
        ErrorClass(
            name="metal_completion_sigabrt",
            severity="process_abort",
            recovery_hint="respawn_now",
            upstream_refs=(
                "ml-explore/mlx#3390", "ml-explore/mlx#3224", "ml-explore/mlx#3317",
            ),
            pattern_str=r"MetalStream / check_error std::terminate",
        ),
    ),
    # ─── Generic Metal abort (fallback) ───
    (
        re.compile(r"\[METAL\]\s+Command buffer execution failed", re.IGNORECASE),
        ErrorClass(
            name="metal_command_buffer_failed",
            severity="process_abort",
            recovery_hint="respawn_now",
            upstream_refs=("Blaizzy/mlx-vlm#1064",),
            pattern_str=r"[METAL] Command buffer execution failed",
        ),
    ),
)


def classify_mlx_error(text: str) -> ErrorClass | None:
    """Classify a stderr / panic-file body into an :class:`ErrorClass`.

    Returns None if no known pattern matches. Caller should treat None as
    "unknown abort" — neither kernel panic nor recognized recovery class —
    and default to conservative respawn. First-match-wins on the priority-
    ordered :data:`_CLASSIFIER_TABLE`.
    """
    if not text:
        return None
    for pattern, cls in _CLASSIFIER_TABLE:
        if pattern.search(text):
            return cls
    return None


def is_kernel_panic_signature(text: str) -> bool:
    """True iff text matches a kernel-panic signature (vs process abort)."""
    cls = classify_mlx_error(text)
    return cls is not None and cls.severity == "kernel_panic"


def is_process_abort_signature(text: str) -> bool:
    """True iff text matches a non-kernel abort (subprocess died but Mac OK)."""
    cls = classify_mlx_error(text)
    if cls is None:
        return False
    return cls.severity in (
        "process_abort", "command_buffer_oom", "gpu_hang",
        "gpu_page_fault", "descriptor_leak",
    )
