"""Prefill-budget-driven worker rotation gate.

A consumer of :mod:`metal_guard.prefill_exposure_tracker`. Addresses
the delayed-trigger Metal buffer lifecycle race (mlx#3186 thread): a
kernel panic can fire minutes after a large prefill completed, and
neither a per-request KV ceiling nor an inference-count budget catches
it.

This module exposes an advisory *gate* on top of the cumulative
prefill-tokens metric: the caller queries ``should_rotate_worker`` and,
if the verdict recommends it, rotates the worker (shutdown + respawn)
to release accumulated Metal buffer state. The gate is purely advisory
— it never spawns or kills processes; the caller owns the lifecycle.

Tracker vs rotation are kept separate on purpose: the tracker is
observation (store + emit), rotation is policy (read + threshold +
verdict).

Tunables:

- ``METALGUARD_WORKER_ROTATION_DISABLED=1`` — gate always returns
  ``should_rotate=False, reason="disabled"`` (no corpus emit).
- ``METALGUARD_PREFILL_BUDGET_TOKENS=N`` — shared with the tracker;
  default 50000. The gate compares ``cumulative_tokens >= budget``.

Emits a ``worker_rotation_recommended`` corpus event on every call
that returns ``should_rotate=True``.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from metal_guard import corpus
from metal_guard import prefill_exposure_tracker
from metal_guard.prefill_exposure_tracker import _budget_threshold, _require_aware
from metal_guard._constants import log

_DISABLED_ENV = "METALGUARD_WORKER_ROTATION_DISABLED"

EVENT_ROTATION_RECOMMENDED = "worker_rotation_recommended"

# Stable enum-like reason codes — keep in sync with corpus consumer
# expectations. New reasons append-only; never reuse strings.
REASON_DISABLED = "disabled"
REASON_NO_STATE = "no_state"
REASON_UNDER_BUDGET = "under_budget"
REASON_PREFILL_BUDGET_EXCEEDED = "prefill_budget_exceeded"


@dataclass(frozen=True)
class RotationVerdict:
    """Immutable verdict returned by :func:`should_rotate_worker`.

    Fields:

    :should_rotate: caller should rotate the worker (shutdown + respawn).
    :reason: stable string identifier — see ``REASON_*`` constants.
    :worker_pid: echoed from input for caller logging convenience.
    :worker_started_at: echoed for generation-key bookkeeping.
    :cumulative_tokens: tracker's cumulative as of decision; ``None`` when
        no state was found (caller never recorded a prefill, or pid was
        recycled and the new generation has no state yet).
    :threshold: budget value (in tokens) used for the decision; ``None``
        when gate is disabled or no state was queried (e.g. early exit).
    """

    should_rotate: bool
    reason: str
    worker_pid: int
    worker_started_at: datetime | None
    cumulative_tokens: int | None
    threshold: int | None


def _is_disabled() -> bool:
    return os.environ.get(_DISABLED_ENV, "").strip().lower() in {"1", "true", "yes"}


def should_rotate_worker(
    *,
    worker_pid: int,
    worker_started_at: datetime,
) -> RotationVerdict:
    """Decide whether the caller should rotate this worker.

    Behavior:

    1. ``METALGUARD_WORKER_ROTATION_DISABLED=1`` → ``should_rotate=False,
       reason="disabled"`` (cheap early exit, no corpus emit).
    2. Naive ``worker_started_at`` raises ``ValueError`` — caller MUST
       pass a tz-aware datetime (matches tracker's contract).
    3. ``prefill_exposure_tracker.get_state(pid, worker_started_at=...)``
       returns ``None`` (state unknown / pid recycled / disabled) →
       ``should_rotate=False, reason="no_state"``. No corpus emit.
    4. ``cumulative_tokens < budget`` → ``should_rotate=False,
       reason="under_budget"``. No corpus emit.
    5. ``cumulative_tokens >= budget`` → ``should_rotate=True,
       reason="prefill_budget_exceeded"``. **Corpus emit fires** with
       full verdict payload. The verdict is fresh each call; caller may
       ignore the recommendation and the next call will re-emit. This
       is intentional — gate is stateless wrt previous recommendations,
       so caller restarts and tracker resets are both clean.

    The advisory contract: this function never mutates the tracker, never
    kills processes, never sleeps. Caller is responsible for ordering:

      verdict = should_rotate_worker(pid=p, worker_started_at=s)
      if verdict.should_rotate:
          safe_inference_shutdown(...)        # 6-step canonical shutdown
          spawn_new_worker(...)               # caller's responsibility
          forget_worker(p, worker_started_at=s)  # release tracker state
    """
    if _is_disabled():
        return RotationVerdict(
            should_rotate=False,
            reason=REASON_DISABLED,
            worker_pid=worker_pid,
            worker_started_at=worker_started_at,
            cumulative_tokens=None,
            threshold=None,
        )

    _require_aware("worker_started_at", worker_started_at)

    # Strict generation-aware lookup — None when pid recycled or unknown.
    state = prefill_exposure_tracker.get_state(
        worker_pid, worker_started_at=worker_started_at,
    )
    if state is None:
        return RotationVerdict(
            should_rotate=False,
            reason=REASON_NO_STATE,
            worker_pid=worker_pid,
            worker_started_at=worker_started_at,
            cumulative_tokens=None,
            threshold=None,
        )

    budget = _budget_threshold()

    if state.cumulative_tokens < budget:
        return RotationVerdict(
            should_rotate=False,
            reason=REASON_UNDER_BUDGET,
            worker_pid=worker_pid,
            worker_started_at=worker_started_at,
            cumulative_tokens=state.cumulative_tokens,
            threshold=budget,
        )

    # ≥ budget → recommend rotation.
    verdict = RotationVerdict(
        should_rotate=True,
        reason=REASON_PREFILL_BUDGET_EXCEEDED,
        worker_pid=worker_pid,
        worker_started_at=worker_started_at,
        cumulative_tokens=state.cumulative_tokens,
        threshold=budget,
    )

    _emit_decision(verdict, model_id=state.model_id)
    return verdict


def _emit_decision(verdict: RotationVerdict, *, model_id: str | None) -> None:
    """Best-effort corpus append; never raises out of telemetry."""
    payload: dict[str, Any] = {
        "worker_pid": verdict.worker_pid,
        "worker_started_at": (
            verdict.worker_started_at.isoformat()
            if verdict.worker_started_at is not None else None
        ),
        "cumulative_tokens": verdict.cumulative_tokens,
        "threshold": verdict.threshold,
        "reason": verdict.reason,
    }
    try:
        corpus.append_event(
            EVENT_ROTATION_RECOMMENDED,
            model_id=model_id,
            extra=payload,
        )
    except Exception as e:  # pragma: no cover — telemetry best-effort
        log.warning("worker_rotation corpus emit failed: %s", e)
