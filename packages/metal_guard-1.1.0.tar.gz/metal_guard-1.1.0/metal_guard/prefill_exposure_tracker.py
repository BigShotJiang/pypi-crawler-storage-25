"""Per-worker cumulative prefill-tokens lifetime tracker.

Addresses a delayed-trigger failure mode (mlx#3186 thread): a kernel
panic can fire minutes after a single large prefill completed cleanly,
during subsequent short-prompt generation — a delayed Metal buffer
lifecycle race. Per-request KV trackers reset each request and an
inference-count tracker is token-blind, so neither catches cumulative
prefill exposure across a worker's lifetime.

This module tracks, per worker (pid + spawn-time keyed), the
cumulative prefill tokens absorbed and the single-prefill high-water
mark, and emits corpus events when thresholds are crossed.

Design constraints:

- In-memory state only — worker state dies with the worker;
  persistence is via the corpus event log.
- Immutable records (``frozen=True`` dataclass).
- Thread-safe (RLock-guarded module-level dict).
- Best-effort — corpus emit failures are swallowed (warned, not raised).
- Env disable: ``METALGUARD_PREFILL_EXPOSURE_DISABLED=1``.
- Configurable thresholds: ``METALGUARD_PREFILL_HIGH_WATER_TOKENS``
  (default 10000) and ``METALGUARD_PREFILL_BUDGET_TOKENS``
  (default 50000).

Public API: ``record_prefill``, ``get_state``, ``forget_worker``,
``all_states``, ``WorkerPrefillState``.

``worker_started_at`` (tz-aware) is the generation discriminator
alongside pid — macOS recycles pids, so pid alone cannot key state
across worker lifetimes.
"""
from __future__ import annotations

import os
import threading
from dataclasses import dataclass, replace
from datetime import datetime, timezone
from typing import Any

from metal_guard import corpus
from metal_guard._constants import log

# ─── Env tunables ────────────────────────────────────────────────────────

_DISABLED_ENV = "METALGUARD_PREFILL_EXPOSURE_DISABLED"

# Public schema contract — autopsy reader uses these field names directly.
# critic R1 P1-2: prevent silent "?" fallback when tracker payload schema
# drifts. Single source of truth for both emit (this module) and consume
# (panic_autopsy.write_autopsy_report timeline section).
AUTOPSY_FIELDS: tuple[str, ...] = (
    "cumulative_tokens",
    "max_single_prefill_tokens",
    "prefill_count",
    "worker_pid",
)
_HIGH_WATER_ENV = "METALGUARD_PREFILL_HIGH_WATER_TOKENS"
_BUDGET_ENV = "METALGUARD_PREFILL_BUDGET_TOKENS"

DEFAULT_HIGH_WATER_TOKENS = 10_000
DEFAULT_BUDGET_TOKENS = 50_000

# Forward-compat event kinds (panic_corpus.EVENT_KINDS frozenset documents
# canonical names but accepts any string per its docstring).
EVENT_HIGH_WATER_RECORDED = "worker_high_water_prefill_recorded"
EVENT_BUDGET_EXCEEDED = "worker_prefill_budget_exceeded"


def _high_water_threshold() -> int:
    """Resolve high-water emit threshold from env, with safe default."""
    raw = os.environ.get(_HIGH_WATER_ENV)
    if raw is None:
        return DEFAULT_HIGH_WATER_TOKENS
    try:
        v = int(raw)
        return v if v > 0 else DEFAULT_HIGH_WATER_TOKENS
    except ValueError:
        log.warning(
            "%s=%r is not a positive int; using default %d",
            _HIGH_WATER_ENV, raw, DEFAULT_HIGH_WATER_TOKENS,
        )
        return DEFAULT_HIGH_WATER_TOKENS


def _budget_threshold() -> int:
    """Resolve cumulative-budget threshold from env, with safe default."""
    raw = os.environ.get(_BUDGET_ENV)
    if raw is None:
        return DEFAULT_BUDGET_TOKENS
    try:
        v = int(raw)
        return v if v > 0 else DEFAULT_BUDGET_TOKENS
    except ValueError:
        log.warning(
            "%s=%r is not a positive int; using default %d",
            _BUDGET_ENV, raw, DEFAULT_BUDGET_TOKENS,
        )
        return DEFAULT_BUDGET_TOKENS


def _is_disabled() -> bool:
    return os.environ.get(_DISABLED_ENV, "").strip().lower() in {"1", "true", "yes"}


# ─── State record ────────────────────────────────────────────────────────

@dataclass(frozen=True)
class WorkerPrefillState:
    """Immutable snapshot of a worker's prefill exposure.

    Fields:

    :worker_pid: subprocess pid; matches ``MLXSubprocessRunner._worker_pid``.
    :worker_started_at: caller-supplied subprocess spawn time. Used as
        the *generation discriminator* alongside pid: macOS recycles
        pids, so `pid` alone cannot key state across worker lifetimes.
        ``record_prefill`` requires this and auto-forgets stale state
        when a fresh ``worker_started_at`` arrives for an existing pid.
    :cumulative_tokens: total prefill tokens absorbed across all calls
        in this worker's lifetime.
    :max_single_prefill_tokens: largest individual prefill ever sent to
        this worker; useful for autopsy "did this worker ever see >X?".
    :prefill_count: number of ``record_prefill`` calls for this worker.
    :model_id: most recent model_id passed; ``None`` if never provided.
        Conservative: don't track per-model cumulative because subprocess
        workers in this codebase are pinned to one model_id at spawn —
        reusing a worker for a different model would warrant separate
        tracking but currently never happens.
    :first_recorded_at: timestamp of first ``record_prefill`` for this
        worker (separate from ``worker_started_at`` because the
        subprocess can spawn before any prefill is sent).
    :last_updated_at: timestamp of most recent update.
    :budget_emitted_at_threshold: budget value (in tokens) at which the
        most recent ``worker_prefill_budget_exceeded`` corpus emit fired,
        or ``None`` if never emitted. Replaces the prior boolean flag so
        operators can raise the env-tunable budget mid-run without
        permanently suppressing future emits at the new higher threshold.
        Lowering the budget will re-emit on next call past the new bar.
    """

    worker_pid: int
    worker_started_at: datetime
    cumulative_tokens: int
    max_single_prefill_tokens: int
    prefill_count: int
    model_id: str | None
    first_recorded_at: datetime
    last_updated_at: datetime
    budget_emitted_at_threshold: int | None


# ─── Module-level state ──────────────────────────────────────────────────

_lock = threading.RLock()
_workers: dict[int, WorkerPrefillState] = {}


def _now() -> datetime:
    return datetime.now(timezone.utc)


# ─── Public API ──────────────────────────────────────────────────────────

def _require_aware(name: str, ts: datetime) -> None:
    """Reject naive datetimes at module entry.

    R2 P1: subprocess_runner wires might pass ``datetime.fromtimestamp(t)``
    (naive). Allowing naive datetimes through silently:
      - Lock-branch comparison still works naive==naive within this module
      - But any future op that subtracts state.worker_started_at from
        ``_now()`` (which is tz-aware) TypeErrors.
      - Mixing naive + aware across calls produces nonsensical equality
        (datetime.timestamp() interprets naive as local time, aware as
        absolute UTC). Two callers with different time zones end up with
        the same wall-clock seeing different stored values.
    Reject early — caller must use ``datetime.now(timezone.utc)`` or
    explicit ``tzinfo``.
    """
    if ts.tzinfo is None or ts.tzinfo.utcoffset(ts) is None:
        raise ValueError(
            f"{name} must be timezone-aware "
            f"(use datetime.now(timezone.utc) or set tzinfo); got naive {ts!r}"
        )


def record_prefill(
    *,
    worker_pid: int,
    worker_started_at: datetime,
    prefill_tokens: int,
    model_id: str | None = None,
    now: datetime | None = None,
) -> WorkerPrefillState | None:
    """Record a prefill against a worker's lifetime cumulative.

    Returns the updated immutable :class:`WorkerPrefillState`. Returns
    ``None`` when the tracker is disabled (env override) so callers can
    cheaply check ``if state is not None:`` without branching elsewhere.

    Caller contract:

    - ``worker_started_at`` is REQUIRED — caller (typically
      ``MLXSubprocessRunner``) must pass the subprocess spawn time. This
      is the generation discriminator: when ``record_prefill`` sees an
      existing entry for ``worker_pid`` whose ``worker_started_at`` does
      NOT match, it auto-forgets the stale state and starts fresh.
      Without this, macOS pid recycling silently merges generations.
    - Caller is encouraged to call :func:`forget_worker` on subprocess
      shutdown so panic-paths that bypass it (SIGKILL) are the *only*
      route through pid-recycling auto-forget.

    Side effects:

    - Emits ``worker_high_water_prefill_recorded`` corpus event when
      ``prefill_tokens >= high_water_threshold`` (each occurrence).
    - Emits ``worker_prefill_budget_exceeded`` corpus event when
      ``cumulative_tokens >= current_budget`` AND the budget value at the
      most recent emit (``budget_emitted_at_threshold``) is below the
      current budget. This means raising the env budget mid-run only
      re-emits when cumulative crosses the new higher bar; lowering the
      budget will re-emit on next call. Replaces an earlier boolean flag
      that was sticky across env changes.
    - Both emits are best-effort — corpus failures logged at WARNING but
      do not raise.

    Negative ``prefill_tokens`` is a caller bug (logged at WARNING) but
    does not raise; treated as 0 to avoid corrupting cumulative.

    Pid recycling is reported at INFO level when detected.
    """
    if _is_disabled():
        return None
    _require_aware("worker_started_at", worker_started_at)
    if now is not None:
        _require_aware("now", now)
    if prefill_tokens < 0:
        log.warning(
            "record_prefill: negative prefill_tokens=%d for pid=%d clamped to 0",
            prefill_tokens, worker_pid,
        )
        prefill_tokens = 0

    ts = now or _now()
    high_water = _high_water_threshold()
    budget = _budget_threshold()

    with _lock:
        prev = _workers.get(worker_pid)
        # Detect pid recycling: same pid, different spawn time → fresh worker.
        if prev is not None and prev.worker_started_at != worker_started_at:
            log.info(
                "prefill_exposure: pid=%d recycled "
                "(prev started_at=%s, new started_at=%s); resetting cumulative.",
                worker_pid, prev.worker_started_at.isoformat(),
                worker_started_at.isoformat(),
            )
            prev = None

        if prev is None:
            new_state = WorkerPrefillState(
                worker_pid=worker_pid,
                worker_started_at=worker_started_at,
                cumulative_tokens=prefill_tokens,
                max_single_prefill_tokens=prefill_tokens,
                prefill_count=1,
                model_id=model_id,
                first_recorded_at=ts,
                last_updated_at=ts,
                budget_emitted_at_threshold=None,
            )
        else:
            new_state = replace(
                prev,
                cumulative_tokens=prev.cumulative_tokens + prefill_tokens,
                max_single_prefill_tokens=max(
                    prev.max_single_prefill_tokens, prefill_tokens,
                ),
                prefill_count=prev.prefill_count + 1,
                model_id=model_id if model_id is not None else prev.model_id,
                last_updated_at=ts,
            )

        # Determine corpus emits before updating dict so we hold lock
        # for the minimum window. Emit is best-effort outside the lock.
        emit_high_water = prefill_tokens >= high_water
        prior_emit = new_state.budget_emitted_at_threshold
        emit_budget = (
            new_state.cumulative_tokens >= budget
            and (prior_emit is None or prior_emit < budget)
        )
        if emit_budget:
            new_state = replace(new_state, budget_emitted_at_threshold=budget)

        _workers[worker_pid] = new_state

    # Emit outside lock — corpus.append_event acquires its own fcntl lock.
    if emit_high_water:
        _emit(
            EVENT_HIGH_WATER_RECORDED,
            new_state,
            extra={
                "prefill_tokens": prefill_tokens,
                "threshold": high_water,
            },
        )
    if emit_budget:
        _emit(
            EVENT_BUDGET_EXCEEDED,
            new_state,
            extra={
                "budget": budget,
                "high_water_threshold": high_water,
            },
        )

    return new_state


def get_state(
    worker_pid: int,
    *,
    worker_started_at: datetime | None = None,
) -> WorkerPrefillState | None:
    """Return current state for ``worker_pid`` or ``None`` if unknown.

    When ``worker_started_at`` is provided, return ``None`` if the stored
    state's spawn time differs (pid was recycled to a different worker).
    R2 P1 fix — without the generation check, a Wave B caller cached against
    worker A's (pid, started_at) tuple would silently read worker B's data
    after pid recycling.

    For backward compat / non-strict callers, ``worker_started_at`` is
    optional. Strict callers (Wave B rotation gate) must always pass it.
    """
    if _is_disabled():
        return None
    if worker_started_at is not None:
        _require_aware("worker_started_at", worker_started_at)
    with _lock:
        state = _workers.get(worker_pid)
        if state is None:
            return None
        if worker_started_at is not None and state.worker_started_at != worker_started_at:
            return None  # pid recycled — caller asked for a different generation
        return state


def forget_worker(
    worker_pid: int,
    *,
    worker_started_at: datetime | None = None,
) -> WorkerPrefillState | None:
    """Drop tracking state for ``worker_pid`` (called on worker shutdown).

    When ``worker_started_at`` is provided, only pop if the stored state's
    spawn time matches; otherwise the call is a no-op and an INFO log is
    emitted "forget skipped: pid recycled". R2 P1 fix — prevents a
    deferred cleanup for a long-dead worker A from silently wiping the
    accumulated state of worker B that just inherited the pid.

    For backward compat / non-strict callers (no spawn time tracked),
    ``worker_started_at`` is optional and forget remains pid-only.

    Returns the removed state for caller logging; ``None`` when unknown,
    disabled, or generation-mismatched. Idempotent — safe to call
    multiple times.
    """
    if _is_disabled():
        return None
    if worker_started_at is not None:
        _require_aware("worker_started_at", worker_started_at)
    with _lock:
        state = _workers.get(worker_pid)
        if state is None:
            return None
        if worker_started_at is not None and state.worker_started_at != worker_started_at:
            log.info(
                "prefill_exposure: forget_worker skipped — "
                "pid=%d generation mismatch (stored started_at=%s, "
                "caller's started_at=%s); pid likely recycled.",
                worker_pid,
                state.worker_started_at.isoformat(),
                worker_started_at.isoformat(),
            )
            return None
        return _workers.pop(worker_pid, None)


def all_states() -> tuple[WorkerPrefillState, ...]:
    """Snapshot of all known worker states. Returns a tuple (immutable)."""
    if _is_disabled():
        return ()
    with _lock:
        return tuple(_workers.values())


def reset_all() -> None:
    """Clear all tracked workers. Test helper; not for production use."""
    with _lock:
        _workers.clear()


# ─── Internal ────────────────────────────────────────────────────────────

def _emit(
    event: str,
    state: WorkerPrefillState,
    *,
    extra: dict[str, Any],
) -> None:
    """Best-effort corpus append; never raises out of telemetry."""
    payload = {
        "worker_pid": state.worker_pid,
        "worker_started_at": state.worker_started_at.isoformat(),
        "cumulative_tokens": state.cumulative_tokens,
        "max_single_prefill_tokens": state.max_single_prefill_tokens,
        "prefill_count": state.prefill_count,
        **extra,
    }
    try:
        corpus.append_event(
            event,
            model_id=state.model_id,
            extra=payload,
        )
    except Exception as e:  # pragma: no cover — telemetry best-effort
        log.warning("prefill_exposure corpus emit failed (event=%s): %s", event, e)
