"""Cross-model cadence guard (C5)."""

from __future__ import annotations

import datetime
import gc
import glob
import json
import logging
import multiprocessing
import os
import pathlib
import re
import shutil
import signal
import sys
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from multiprocessing.connection import Connection
from pathlib import Path
from typing import Any, Callable, Generator, Iterator, Tuple, TypeVar

from metal_guard._constants import log

# ---------------------------------------------------------------------------
# L9 — Cadence Guard (2026-04-16)
#
# Eighth-hole patch. Production kernel panic at 2026-04-16 23:33:27 was
# IOGPUMemory.cpp:492 "completeMemory() prepare count underflow" during
# the first generate() after a freshly-loaded subprocess worker — i.e.
# the SIGABRT handler was installed (L6) but the panic happened at
# kernel level before any user-space signal could fire. Root-cause
# matches the Apple backend log note: "Reproduces under back-to-back
# load/unload cycles". Only way to avoid it is to not do back-to-back
# loads.
# ---------------------------------------------------------------------------


class CadenceViolation(RuntimeError):
    """Raised when a back-to-back MLX load would risk IOGPU underflow."""

    def __init__(self, model_id: str, last_ts: float, min_interval: float) -> None:
        self.model_id = model_id
        self.last_ts = last_ts
        self.min_interval = min_interval
        self.delta = max(0.0, time.time() - last_ts)
        super().__init__(
            f"CadenceGuard blocked load of {model_id!r}: last cycle "
            f"{self.delta:.1f}s ago < min_interval {min_interval:.0f}s"
        )


class CrossModelCadenceViolation(CadenceViolation):
    """Raised when loading a *different* model too soon after another.

    Added v0.9.0 (2026-04-25). Harper's panic timeline (8 IOGPU kernel
    panics between 2026-04-16 and 2026-04-24, see CHANGELOG) showed that
    back-to-back loads of **different** models trigger the same
    ``IOGPUMemory.cpp:492 prepare_count_underflow`` panic as back-to-back
    same-model loads. The classic same-model ``min_interval`` check let
    these through because every ``model_id`` was different.

    Inherits from :class:`CadenceViolation` so ``except CadenceViolation``
    still catches both variants.
    """

    def __init__(
        self,
        model_id: str,
        last_model: str,
        last_ts: float,
        cross_model_interval: float,
    ) -> None:
        self.last_model = last_model
        self.cross_model_interval = cross_model_interval
        super().__init__(model_id, last_ts, cross_model_interval)
        self.args = (
            f"CadenceGuard blocked cross-model load of {model_id!r}: "
            f"last load was {last_model!r} {self.delta:.1f}s ago "
            f"< cross_model_interval {cross_model_interval:.0f}s",
        )


_CADENCE_PATH_DEFAULT = os.path.expanduser("~/.cache/metal-guard/cadence.json")
_CADENCE_FILE_LOCK = threading.Lock()
_CADENCE_MAX_AGE_SEC = 14400.0  # GC entries older than 4h — far past any min_interval

# --- Cross-model cadence (v0.9.0, C5 phase-1, 2026-04-25) ------------------
# Non-gemma-4 baseline cadence between loads of *different* models. Set to 0
# to disable. Env var ``METALGUARD_CROSS_MODEL_INTERVAL`` overrides default.
_CROSS_MODEL_ENV_VAR = "METALGUARD_CROSS_MODEL_INTERVAL"
_C5_DEFAULT_CROSS_MODEL_INTERVAL_SEC = 60.0

# Gemma-4 family floor (v0.9.0, C5+C7, 2026-04-25). 8/8 IOGPUMemory.cpp:492
# panics in Harper's timeline had at-panic model in the gemma-4 family; panic
# #6 landed 66s after prior unload, so 90s = 66s + ~36% safety margin. Floor
# applies regardless of configured base (users who set cross_model_interval=0
# still get this minimum for gemma-4).
GEMMA4_MIN_CROSS_MODEL_INTERVAL_SEC = 90.0

# Size-anchored regex for gemma-4 family match. Anchors prevent false-positive
# matches on ``gemma-4b-*`` (4 billion, not Gen4) or ``google/gemma-4-*`` (not
# a real model) while admitting both standard and MoE variants:
#   mlx-community/gemma-4-26b-a4b-it-4bit
#   mlx-community/gemma-4-31b-it-8bit
#   mlx-community/gemma-4-e4b-it-4bit
#   unsloth/gemma-4-31b-it-UD-MLX-4bit
_GEMMA4_NAME_PATTERN = re.compile(
    r"^gemma-4-(?:\d+b|e\d+b)-"    # size-anchored: digits+b or e+digit+b
    r"[a-z0-9\-]*"                 # variant tail
    r"$",
    re.IGNORECASE,
)
_GEMMA4_VENDOR_ALLOWLIST = frozenset({"mlx-community", "unsloth", "mlx-models"})


def _is_gemma4_family(model_id: str) -> bool:
    """Return True for known gemma-4 family model identifiers.

    Vendor allowlist + size-anchored basename match. Used by
    :class:`CadenceGuard` to enforce the 90s floor on cross-model cadence
    and by :func:`gemma4_generation_flush` to decide whether to insert a
    first-generate settle window.
    """
    if not model_id or "/" not in model_id:
        return False
    vendor, _, name = model_id.lower().partition("/")
    if vendor not in _GEMMA4_VENDOR_ALLOWLIST:
        return False
    return bool(_GEMMA4_NAME_PATTERN.match(name))


class CadenceGuard:
    """Per-model load timestamp store + min-interval enforcement.

    Persisted to JSON on disk so timestamps survive subprocess spawn and
    kernel panics. Cross-process safe via atomic write (``os.replace``).

    Typical use (inside the worker subprocess, right before
    ``mlx_lm.load``)::

        from metal_guard import require_cadence_clear, CadenceViolation
        try:
            require_cadence_clear(model_id)
        except CadenceViolation:
            # Exit cleanly — the parent will propagate as a worker error
            sys.exit(2)
    """

    def __init__(
        self,
        path: str | None = None,
        *,
        min_interval_sec: float = 180.0,
        cross_model_interval_sec: float = 0.0,
    ) -> None:
        # Resolve default at call time so test monkeypatches of the
        # module-level constant take effect.
        self._path = os.path.expanduser(path or _CADENCE_PATH_DEFAULT)
        self._min_interval = float(min_interval_sec)
        # Zero disables the check (backwards-compat default). Non-zero means
        # reject any load of a *different* model_id within this many seconds
        # of the most-recent load. gemma-4 family is always floored at
        # GEMMA4_MIN_CROSS_MODEL_INTERVAL_SEC regardless of this value.
        self._cross_model_interval = max(0.0, float(cross_model_interval_sec))

    @property
    def path(self) -> str:
        return self._path

    @property
    def min_interval_sec(self) -> float:
        return self._min_interval

    @property
    def cross_model_interval_sec(self) -> float:
        return self._cross_model_interval

    def _effective_cross_model_interval(self, model_id: str) -> float:
        """Return effective cross-model cadence for target model.

        Gemma-4 family floor is ``GEMMA4_MIN_CROSS_MODEL_INTERVAL_SEC``
        regardless of the configured base (see class docstring for why).
        """
        base = self._cross_model_interval
        if _is_gemma4_family(model_id):
            return max(base, GEMMA4_MIN_CROSS_MODEL_INTERVAL_SEC)
        return base

    def _read(self) -> dict[str, float]:
        try:
            with open(self._path, encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, json.JSONDecodeError, ValueError):
            return {}
        if not isinstance(data, dict):
            return {}
        result: dict[str, float] = {}
        for k, v in data.items():
            if isinstance(v, (int, float)):
                result[str(k)] = float(v)
        return result

    def _write(self, data: dict[str, float]) -> None:
        dirname = os.path.dirname(self._path)
        if dirname:
            try:
                os.makedirs(dirname, exist_ok=True)
            except OSError:
                return
        tmp = f"{self._path}.tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, sort_keys=True)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, self._path)
        except OSError as exc:
            log.debug("CadenceGuard write failed: %s", exc)

    def _gc_stale(self, data: dict[str, float], now: float) -> dict[str, float]:
        return {k: v for k, v in data.items() if now - v < _CADENCE_MAX_AGE_SEC}

    def last_ts(self, model_id: str) -> float | None:
        with _CADENCE_FILE_LOCK:
            return self._read().get(model_id)

    def mark_load(self, model_id: str, *, ts: float | None = None) -> None:
        now = ts if ts is not None else time.time()
        with _CADENCE_FILE_LOCK:
            data = self._gc_stale(self._read(), now)
            data[model_id] = now
            self._write(data)

    def check(self, model_id: str) -> None:
        """Raise CadenceViolation / CrossModelCadenceViolation if unsafe.

        Two independent checks (same-model has priority):

        1. ``min_interval_sec`` — same ``model_id`` within that window.
        2. cross-model interval — any *different* ``model_id`` within
           ``_effective_cross_model_interval(model_id)``. gemma-4 family
           enforces a 90s floor regardless of configured base.
        """
        with _CADENCE_FILE_LOCK:
            data = self._read()
        now = time.time()
        # 1. Same-model back-to-back (classic L9).
        last = data.get(model_id)
        if last is not None and now - last < self._min_interval:
            raise CadenceViolation(model_id, last, self._min_interval)
        # 2. Cross-model back-to-back (v0.9.0 C5).
        effective_cross = self._effective_cross_model_interval(model_id)
        if effective_cross > 0.0:
            most_recent_other: tuple[str, float] | None = None
            for other_id, other_ts in data.items():
                if other_id == model_id:
                    continue
                if most_recent_other is None or other_ts > most_recent_other[1]:
                    most_recent_other = (other_id, other_ts)
            if most_recent_other is not None:
                other_id, other_ts = most_recent_other
                if now - other_ts < effective_cross:
                    raise CrossModelCadenceViolation(
                        model_id, other_id, other_ts, effective_cross,
                    )


def _resolve_cross_model_interval(explicit: float | None) -> float:
    """Explicit arg wins; else env var; else default.

    Resolution order:

    1. Explicit ``explicit`` argument (including ``0.0`` to disable).
    2. ``METALGUARD_CROSS_MODEL_INTERVAL`` environment variable.
    3. ``_C5_DEFAULT_CROSS_MODEL_INTERVAL_SEC`` (60s).

    Invalid env var values fall back to the default with a warning.
    """
    if explicit is not None:
        return max(0.0, float(explicit))
    raw = os.getenv(_CROSS_MODEL_ENV_VAR, "").strip()
    if not raw:
        return _C5_DEFAULT_CROSS_MODEL_INTERVAL_SEC
    try:
        return max(0.0, float(raw))
    except ValueError:
        log.warning(
            "Invalid %s=%r, falling back to default %.0fs",
            _CROSS_MODEL_ENV_VAR, raw, _C5_DEFAULT_CROSS_MODEL_INTERVAL_SEC,
        )
        return _C5_DEFAULT_CROSS_MODEL_INTERVAL_SEC


def require_cadence_clear(
    model_id: str,
    *,
    min_interval_sec: float = 180.0,
    cross_model_interval_sec: float = 0.0,
    guard: CadenceGuard | None = None,
) -> None:
    """Check + mark atomic helper.

    Checks cadence; on pass, marks the load timestamp (so the NEXT call
    within ``min_interval`` will be blocked, including retries after a
    kernel panic since the mark is persisted to disk before the crash).

    v0.9.0 additions:

    - ``cross_model_interval_sec`` (new): seconds required between loads
      of *different* models. Default is ``0.0`` (disabled) to preserve
      backwards-compatibility with v0.8.x callers. To opt in globally
      without code changes, set ``METALGUARD_CROSS_MODEL_INTERVAL=<sec>``
      in the environment; the CadenceGuard this helper creates will read
      that env value. Explicit ``cross_model_interval_sec`` argument
      takes priority over the env var when non-zero; pass ``0.0`` (or
      omit) to defer to the env var. Ignored when ``guard`` is supplied
      (the guard's own ``cross_model_interval_sec`` wins).
    - Raises :class:`CrossModelCadenceViolation` (subclass of
      :class:`CadenceViolation`) when a cross-model violation fires.

    Note on subclassing: in v0.9.0 ``CadenceGuard.check()`` reads the
    JSON store directly under ``_CADENCE_FILE_LOCK`` instead of calling
    ``self.last_ts()``, so subclasses that overrode ``last_ts()`` to
    customise the read path will no longer be invoked by ``check()``.
    This is a tiny subclassing-contract change; the public API on the
    instance is unchanged.
    """
    if guard is None:
        # v0.9.0: explicit arg wins when non-zero; zero defers to env var
        # (which itself falls back to disabled when unset).
        resolved_cross = (
            cross_model_interval_sec
            if cross_model_interval_sec > 0
            else _resolve_cross_model_interval_for_require()
        )
        cg = CadenceGuard(
            min_interval_sec=min_interval_sec,
            cross_model_interval_sec=resolved_cross,
        )
    else:
        cg = guard
    cg.check(model_id)
    cg.mark_load(model_id)


def _resolve_cross_model_interval_for_require() -> float:
    """v0.9.0 require_cadence_clear env-var fallback.

    Returns env var value when set (including explicit ``0`` to disable),
    else ``0.0`` to preserve v0.8.x behaviour. This intentionally differs
    from :func:`_resolve_cross_model_interval` (which defaults to 60s)
    because :func:`require_cadence_clear` is the back-compat entry point;
    the 60s C5 default is opt-in via ``CadenceGuard`` constructor or env.
    """
    raw = os.getenv(_CROSS_MODEL_ENV_VAR, "").strip()
    if not raw:
        return 0.0
    try:
        return max(0.0, float(raw))
    except ValueError:
        log.warning(
            "Invalid %s=%r, falling back to 0.0 (disabled)",
            _CROSS_MODEL_ENV_VAR, raw,
        )
        return 0.0
