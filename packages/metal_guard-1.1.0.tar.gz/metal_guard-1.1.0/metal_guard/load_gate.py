"""Memory-prediction load gate.

Refuses a model load when the predicted Metal footprint plus headroom
exceeds available VRAM, short-circuiting OOM-induced kernel panics before
a subprocess is even spawned.

Critical design constraint: this module never loads the MLX runtime — it
must work under a panic-gate cooldown, so VRAM is probed via subprocess
shell-outs only:
- Primary probe: ``vm_stat`` (page size x free pages).
- Secondary probe: ``system_profiler SPMemoryDataType`` (total memory).
- Both parse-fail -> safe-allow + a ``load_gate_skipped_unknown_vm``
  telemetry event (do not block; let the downstream fit check carry it).

Public API:
    - ``MLXLoadGateError`` — raised by ``gate_or_raise()`` on refuse.
    - ``can_load(model_id) -> tuple[bool, dict]`` — predict + check.
    - ``gate_or_raise(model_id) -> None`` — convenience caller wire.

Env vars:
    - ``MLX_LOAD_HEADROOM_RATIO`` (default 0.2) — headroom fraction.

This gate is per-process advisory — cross-process arbitration is the job
of the lock layer, not this module.
"""
from __future__ import annotations

import os
import re
import subprocess
from typing import Any

from metal_guard import corpus
from metal_guard._constants import log
from metal_guard.guard import MetalGuard

# AC5.2: reuse the canonical size estimator — no double-bookkeeping.
# Module-level alias so callers (and test monkeypatches) hit one name.
estimate_model_size_from_name = MetalGuard.estimate_model_size_from_name

_DEFAULT_HEADROOM_RATIO = 0.2
_MIN_HEADROOM_GB = 2.0
_SMALL_MODEL_GB_THRESHOLD = 2.0  # AC5.3 small-model carve-out
_PROBE_TIMEOUT_SEC = 5.0


class MLXLoadGateError(RuntimeError):
    """Raised by ``gate_or_raise()`` when predicted size + headroom > available VRAM."""

    def __init__(self, message: str, *, info: dict[str, Any]):
        super().__init__(message)
        self.info = info


# ── Headroom config (env-driven per § 3.5.4 risk #2) ──────────────────


def _get_headroom_ratio() -> float:
    """Headroom ratio (default 0.2 = 20%, env ``MLX_LOAD_HEADROOM_RATIO``)."""
    raw = os.environ.get("MLX_LOAD_HEADROOM_RATIO")
    if raw is None or raw == "":
        return _DEFAULT_HEADROOM_RATIO
    try:
        v = float(raw)
    except (TypeError, ValueError):
        return _DEFAULT_HEADROOM_RATIO
    if v < 0:
        return _DEFAULT_HEADROOM_RATIO
    return v


def _compute_headroom_gb(predicted_gb: float) -> float:
    """Headroom = max(predicted × ratio, 2 GB floor) per § 3.5.4 risk #2."""
    return max(predicted_gb * _get_headroom_ratio(), _MIN_HEADROOM_GB)


# ── VRAM availability probes (vm_stat primary, system_profiler secondary) ──


_PAGE_SIZE_RE = re.compile(r"page size of (\d+) bytes")
_FREE_PAGES_RE = re.compile(r"Pages free:\s+(\d+)\.?")
_SP_MEMORY_RE = re.compile(r"Memory:\s+(\d+)\s*GB")


def _parse_vm_stat(stdout: str) -> float | None:
    """Parse vm_stat stdout → free GB (decimal). None on parse failure."""
    page_size_m = _PAGE_SIZE_RE.search(stdout)
    free_pages_m = _FREE_PAGES_RE.search(stdout)
    if not page_size_m or not free_pages_m:
        return None
    try:
        page_size = int(page_size_m.group(1))
        free_pages = int(free_pages_m.group(1))
    except (TypeError, ValueError):
        return None
    return (page_size * free_pages) / 1e9


def _get_available_gb_via_vm_stat() -> float | None:
    """Run ``vm_stat`` and parse → free GB, or None on any failure."""
    try:
        result = subprocess.run(
            ["vm_stat"],
            capture_output=True, text=True, timeout=_PROBE_TIMEOUT_SEC,
        )
    except (FileNotFoundError, OSError, subprocess.SubprocessError):
        return None
    if result.returncode != 0:
        return None
    return _parse_vm_stat(result.stdout)


def _get_available_gb_via_system_profiler() -> float | None:
    """Secondary fallback: parse ``system_profiler SPMemoryDataType``.

    Returns coarse estimate (60% of total) since SPMemoryDataType reports
    installed memory, not free; OS plus running processes consume the rest.
    Used only when vm_stat fails (rare). vm_stat 'Pages free' is the
    accurate path.
    """
    try:
        result = subprocess.run(
            ["system_profiler", "SPMemoryDataType"],
            capture_output=True, text=True, timeout=_PROBE_TIMEOUT_SEC,
        )
    except (FileNotFoundError, OSError, subprocess.SubprocessError):
        return None
    if result.returncode != 0:
        return None
    m = _SP_MEMORY_RE.search(result.stdout)
    if not m:
        return None
    try:
        total_gb = float(m.group(1))
    except (TypeError, ValueError):
        return None
    return total_gb * 0.6  # coarse — assume 40% OS overhead


# ── Public API ────────────────────────────────────────────────────────


def _emit_safe(event_kind: str, payload: dict[str, Any]) -> None:
    """Best-effort emit; never raises out of telemetry path.

    R1 P1 fix: silent ``except Exception: pass`` violates Harper Python rule
    S110. Catch broadly (telemetry must never break gate decision) but log
    at DEBUG so failures stay observable in forensic traces — same pattern
    as ``panic_corpus.append_event`` itself.
    """
    try:
        corpus.emit_event(event_kind=event_kind, payload=payload)
    except Exception as exc:
        log.debug("load_gate: panic_corpus emit failed: %s", exc)


def can_load(model_id: str) -> tuple[bool, dict[str, Any]]:
    """Predict Metal footprint vs available VRAM; return ``(allowed, info)``.

    Always safe-on-skip (returns ``allowed=True``) when prediction or
    available-VRAM probing fails — let ``metal_guard.require_fit()`` carry
    the residual risk.

    info dict keys:
        - ``predicted_size_gb`` (float | None) — from
          ``metal_guard.estimate_model_size_from_name`` (AC5.2 reuse)
        - ``available_vram_gb`` (float | None)
        - ``headroom_gb`` (float)
        - ``reason`` (str): one of
            ``small_model`` | ``unknown_model_size`` | ``unknown_vm_stat`` |
            ``passes_headroom`` | ``insufficient_vram``

    Emits:
        - ``load_gate_refused`` when refused
        - ``load_gate_skipped_unknown_vm`` when both VRAM probes fail

    Args:
        model_id: HuggingFace-style model identifier (e.g.
            ``"mlx-community/gemma-4-31b-it-8bit"``).
    """
    info: dict[str, Any] = {
        "predicted_size_gb": None,
        "available_vram_gb": None,
        "headroom_gb": 0.0,
        "reason": "",
    }

    # 1. Probe available VRAM (vm_stat primary, system_profiler secondary).
    #    Always probed first — even when predicted size is unknown, we want
    #    safe-on-skip telemetry when both probes fail.
    available = _get_available_gb_via_vm_stat()
    if available is None:
        available = _get_available_gb_via_system_profiler()

    if available is None:
        # Both probes failed → safe-on-skip per § 3.5.4 risk #4.
        info["reason"] = "unknown_vm_stat"
        info["predicted_size_gb"] = estimate_model_size_from_name(model_id)
        _emit_safe(
            "load_gate_skipped_unknown_vm",
            {"model_id": model_id, "predicted_size_gb": info["predicted_size_gb"]},
        )
        return True, info

    info["available_vram_gb"] = available

    # 2. Predict size via shared estimator (AC5.2 reuse — no double-bookkeeping).
    predicted = estimate_model_size_from_name(model_id)
    info["predicted_size_gb"] = predicted

    if predicted is None:
        # No size hint in name → safe-allow with diagnostic reason.
        info["reason"] = "unknown_model_size"
        return True, info

    # 3. Small-model carve-out (AC5.3 — no edge-case false-deny).
    if predicted < _SMALL_MODEL_GB_THRESHOLD:
        info["reason"] = "small_model"
        return True, info

    # 4. Compute headroom + decide.
    headroom = _compute_headroom_gb(predicted)
    info["headroom_gb"] = headroom

    if predicted + headroom > available:
        info["reason"] = "insufficient_vram"
        _emit_safe(
            "load_gate_refused",
            {
                "model_id": model_id,
                "predicted_size_gb": predicted,
                "available_vram_gb": available,
                "headroom_gb": headroom,
            },
        )
        return False, info

    info["reason"] = "passes_headroom"
    return True, info


def gate_or_raise(model_id: str) -> None:
    """Raise ``MLXLoadGateError`` when ``can_load()`` returns False.

    Use BEFORE subprocess spawn (per Spec #1 caller wire) to short-circuit
    OOM-induced kernel panic risk without paying subprocess startup cost.

    Raises:
        MLXLoadGateError: with ``.info`` dict from ``can_load()``.
    """
    allowed, info = can_load(model_id)
    if not allowed:
        # Defensive None-guard: today only the insufficient_vram branch sets
        # allowed=False (predicted+available both populated), but a future
        # refuse path could short-circuit earlier — render '?' rather than
        # crash with TypeError on `.1f` against None.
        def _fmt_gb(v: float | None) -> str:
            return f"{v:.1f}GB" if v is not None else "?GB"
        msg = (
            f"load_gate refused {model_id}: "
            f"predicted={_fmt_gb(info['predicted_size_gb'])} "
            f"+ headroom={_fmt_gb(info['headroom_gb'])} "
            f"> available={_fmt_gb(info['available_vram_gb'])}"
        )
        raise MLXLoadGateError(msg, info=info)
