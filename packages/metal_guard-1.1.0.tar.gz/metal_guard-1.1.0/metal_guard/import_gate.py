"""Import-level panic gate for metal_guard.

Ad-hoc ``python -c "import sentence_transformers"`` can trigger
IOGPUMemory.cpp:492 prepare_count_underflow during torch MPS teardown.
The Apple IOGPU driver bug is **not limited to mlx**. Any framework that
initializes Metal (torch MPS, mlx, mlx-vlm, diffusers on MPS, etc.) can
trigger the same underflow on process exit race.

Extends the panic cooldown scope from launchd MLX plist wrappers to
"any Python process importing Metal-touching libraries" via a
``sys.meta_path`` finder installed by ``sitecustomize.py``.

Default mode: **warn** (log but do not block). Promote to ``block`` via
env once daemons have been whitelisted. Kill switch:
``MLX_IMPORT_GATE_DISABLED=1``.

Design constraints (brick-proof):

- Any exception inside the finder is swallowed — the finder must never
  prevent ``python3`` from starting. Pass-through is the safe default.
- Only top-level module names are matched; submodule imports are not
  re-evaluated (cache in ``sys.modules`` handles those anyway).
- Gate re-evaluated on every matching import, so long-running processes
  that re-enter after cooldown expiry work correctly.
"""
from __future__ import annotations

import logging
import os
import sys
from typing import Iterable

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Watched packages
# ---------------------------------------------------------------------------

# Top-level module names whose import triggers Metal initialization either
# directly or transitively. Keep this list tight — every entry is a finder
# callback on every import that matches the prefix.
WATCHED_PREFIXES: frozenset[str] = frozenset({
    "torch",
    "mlx",
    "mlx_lm",
    "mlx_vlm",
    "mlx_whisper",
    "mlx_embeddings",
    "sentence_transformers",
    "diffusers",
    "accelerate",
})

# ---------------------------------------------------------------------------
# Env vars
# ---------------------------------------------------------------------------

_ENV_DISABLED = "MLX_IMPORT_GATE_DISABLED"   # "1" → finder not installed
_ENV_MODE = "MLX_IMPORT_GATE_MODE"           # "warn" (default) | "block" | "off"
_ENV_ALLOW = "MLX_IMPORT_GATE_ALLOW"         # "1" → per-process bypass
_ENV_WHITELIST = "MLX_IMPORT_GATE_WHITELIST" # comma-separated prefixes to allow

_DEFAULT_MODE = "warn"
_VALID_MODES = {"warn", "block", "off"}


# ---------------------------------------------------------------------------
# Gate evaluation
# ---------------------------------------------------------------------------

class ImportGateBlocked(ImportError):
    """Raised when an import is blocked by the panic cooldown gate."""


def _read_mode() -> str:
    raw = (os.environ.get(_ENV_MODE) or _DEFAULT_MODE).strip().lower()
    if raw not in _VALID_MODES:
        log.warning(
            "import_gate: invalid %s=%r, falling back to %r",
            _ENV_MODE, raw, _DEFAULT_MODE,
        )
        return _DEFAULT_MODE
    return raw


def _read_whitelist() -> frozenset[str]:
    raw = os.environ.get(_ENV_WHITELIST, "")
    if not raw.strip():
        return frozenset()
    return frozenset(p.strip() for p in raw.split(",") if p.strip())


def _is_watched(top_name: str, whitelist: Iterable[str]) -> bool:
    if top_name in whitelist:
        return False
    return top_name in WATCHED_PREFIXES


def _cooldown_active() -> tuple[bool, str]:
    """Return (active, reason). Fail-open on any error."""
    try:
        # Import lazily — avoids circular import during package startup.
        from metal_guard.panic_gate import evaluate_panic_cooldown
    except Exception as exc:  # noqa: BLE001 — must never brick python
        log.debug("import_gate: panic_cooldown unavailable: %s", exc)
        return (False, f"panic_cooldown import failed: {exc}")
    try:
        verdict = evaluate_panic_cooldown()
    except Exception as exc:  # noqa: BLE001
        log.warning("import_gate: evaluate_cooldown broke: %s", exc)
        return (False, f"evaluate_cooldown broke: {exc}")
    # exit_code 2 == cooldown/lockout active
    return (verdict.exit_code == 2, verdict.reason)


def _decide(
    module_name: str,
    *,
    mode: str,
    allow: bool,
    cooldown_on: bool,
    cooldown_reason: str,
) -> tuple[bool, str]:
    """Pure decision function for testability.

    Returns ``(should_block, message)``.
    """
    if mode == "off":
        return (False, "mode=off")
    if allow:
        return (False, f"bypassed via {_ENV_ALLOW}=1")
    if not cooldown_on:
        return (False, f"no cooldown ({cooldown_reason})")
    if mode == "warn":
        return (
            False,
            f"WARN import {module_name} during cooldown "
            f"({cooldown_reason}) — set {_ENV_MODE}=block to enforce",
        )
    if mode == "block":
        return (
            True,
            f"BLOCK import {module_name} during cooldown ({cooldown_reason}); "
            f"set {_ENV_ALLOW}=1 to override or {_ENV_MODE}=warn for log-only",
        )
    # Unknown mode — fail-open defensively
    return (False, f"unknown mode={mode!r}, failing open")


# ---------------------------------------------------------------------------
# Meta path finder
# ---------------------------------------------------------------------------

class _ImportGateFinder:
    """``sys.meta_path`` finder that evaluates the panic cooldown gate.

    Only inspects top-level module names in :data:`WATCHED_PREFIXES`.
    Always returns ``None`` so real finders handle actual loading; the
    gate's effect is purely a potential :class:`ImportGateBlocked`
    raised before returning.
    """

    # Re-entrancy guard: if evaluate_cooldown itself imports a watched
    # package (e.g. via transitive dependency), skip to avoid infinite
    # recursion.
    _in_progress: set[str] = set()

    def find_spec(self, fullname, path=None, target=None):  # noqa: ARG002
        try:
            top = fullname.split(".", 1)[0]
            if top in self._in_progress:
                return None
            allow = os.environ.get(_ENV_ALLOW) == "1"
            whitelist = _read_whitelist()
            if not _is_watched(top, whitelist):
                return None
            self._in_progress.add(top)
            try:
                mode = _read_mode()
                cooldown_on, cooldown_reason = _cooldown_active()
                should_block, msg = _decide(
                    top,
                    mode=mode,
                    allow=allow,
                    cooldown_on=cooldown_on,
                    cooldown_reason=cooldown_reason,
                )
            finally:
                self._in_progress.discard(top)
            if cooldown_on:
                # Always log when cooldown is active, regardless of block/warn.
                log.warning("[metal-guard/import-gate] %s", msg)
            else:
                log.debug("[metal-guard/import-gate] %s", msg)
            if should_block:
                raise ImportGateBlocked(msg)
        except ImportGateBlocked:
            raise
        except Exception as exc:  # noqa: BLE001 — must not brick python
            log.debug("import_gate: finder swallowed %s: %s", type(exc).__name__, exc)
        return None


# ---------------------------------------------------------------------------
# Installation
# ---------------------------------------------------------------------------

def install() -> bool:
    """Install the finder into ``sys.meta_path`` if not disabled.

    Returns ``True`` if newly installed, ``False`` if disabled or already
    present. Never raises — sitecustomize must survive any failure.
    """
    try:
        if os.environ.get(_ENV_DISABLED) == "1":
            return False
        # Idempotent: skip if a finder of the same class is already present.
        for existing in sys.meta_path:
            if isinstance(existing, _ImportGateFinder):
                return False
        sys.meta_path.insert(0, _ImportGateFinder())
        return True
    except Exception as exc:  # noqa: BLE001
        # Never brick python startup.
        try:
            sys.stderr.write(
                f"[metal-guard/import-gate] install failed (non-fatal): {exc}\n"
            )
        except Exception:  # noqa: BLE001
            pass
        return False


def uninstall() -> int:
    """Remove all installed finders. Returns count removed (for tests)."""
    new_list = []
    removed = 0
    for f in sys.meta_path:
        if isinstance(f, _ImportGateFinder):
            removed += 1
        else:
            new_list.append(f)
    sys.meta_path[:] = new_list
    return removed
