"""Panic-model / version-blocklist / workload-advisory registries + query API."""

from __future__ import annotations

import datetime
import gc
import glob
import json
import logging
import multiprocessing
import os
import pathlib
import re
import shutil
import signal
import sys
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from multiprocessing.connection import Connection
from pathlib import Path
from typing import Any, Callable, Generator, Iterator, Tuple, TypeVar

from metal_guard._constants import log

# ---------------------------------------------------------------------------
# v0.9.0 — Known panic models (2026-04-25)
# ---------------------------------------------------------------------------
#
# When the same model kernel-panics multiple times in production even with
# every metal-guard defence engaged, we record it here. metal-guard narrows
# the race window; it does NOT fix the underlying Apple IOGPU driver bug,
# and for some models the race window is wide enough that narrowing is not
# enough. For those models, the right operational answer is to switch
# backends (Ollama / llama.cpp) or pivot to a different model family (MoE
# variants have a smaller active-param footprint and are markedly safer).
#
# Callers should invoke :func:`check_known_panic_model(model_id)` at load
# time and escalate — log, refuse, or re-route — based on their own policy.
# :func:`warn_if_known_panic_model` is provided as a fire-and-forget
# convenience that emits a single ``log.warning`` per process per model_id.

KNOWN_PANIC_MODELS: dict[str, dict[str, Any]] = {
    # ─── kernel-panic flagship (gemma-4-31b-8bit) ───
    "mlx-community/gemma-4-31b-it-8bit": {
        # v0.11.0 schema additions: tier + error_classes + verified_safe_alternative
        "tier": "panic",
        "error_classes": [
            {
                "type": "kernel_panic",
                "signature": "IOGPUMemory.cpp:492 prepare_count_underflow",
                "first_seen_via": "Harper production",
                "hardware": ["M1 Ultra 64GB"],
                "gpu_family": ["M1", "M3", "M4"],
                "workload": "OCR consensus debater (sequential model load)",
                "mitigation": (
                    "metal-guard v0.9+ narrows race window via cross-model "
                    "cadence (C5) + gemma4_generation_flush (C7) + "
                    "subprocess_inference_guard (B1), but DOES NOT eliminate. "
                    "Switch backend (Ollama / llama.cpp) or pivot to MoE variant."
                ),
            },
        ],
        "verified_safe_alternative": "mlx-community/gemma-4-26b-a4b-it-4bit",
        # Legacy fields preserved for backward-compat with v0.9 / v0.10 callers
        "panic_signature": "IOGPUMemory.cpp:492 prepare_count_underflow",
        "first_observed": "2026-04-23",
        "last_observed": "2026-04-24",
        "reproductions": [
            "Harper production 2026-04-23 03:14 local, PID 67840, "
            "~6 min worker-ready to panic, pre-cross-model-cadence",
            "Harper production 2026-04-24 03:14 local, PID 26608, "
            "~1.5 min worker-ready to panic, same pipeline as prior",
        ],
        "community": [
            "Hannecke — M4 Max 64GB — ml-explore/mlx#3186, "
            "pivoted to Qwen3-Coder-30B-A3B MoE",
            "lmstudio bug #1740 — hybrid attention (50 sliding + 10 global) "
            "KV cache 8-bit weights 34GB + full ctx KV 20GB+ > 54GB",
            "ml-explore/mlx-lm#883 (M3 Ultra 96GB)",
        ],
        "recommendation": (
            "metal-guard v0.9+ narrows the race window via cross-model "
            "cadence (C5) + gemma4_generation_flush (C7) + "
            "subprocess_inference_guard (B1), but does NOT eliminate "
            "panic on this model in production workloads. If you see "
            "repeat panics with metal-guard fully engaged, switch backend "
            "(Ollama / llama.cpp) or pivot to MoE variant "
            "(e.g. mlx-community/gemma-4-26b-a4b-it-4bit)."
        ),
        # v0.11.7: variant policy — only the upstream-vendor build is
        # treated as confirmed-panic. Re-quantized / re-packaged forks
        # (PLE-safe, RotorQuant-tuned, TurboQuant-KV variants, custom
        # bitwidths) are PRESUMED to share the same Apple IOGPU bug
        # surface because the kernel-side defect is below the model
        # layer — but each variant is unverified individually. metal-
        # guard does NOT auto-match variant model_ids; community
        # contributors who confirm a panic on a specific variant should
        # add a separate KNOWN_PANIC_MODELS entry.
        "variant_policy": "confirmed_for_upstream_id_only",
        "presumed_affected_variants": (
            "Any fork or re-quantization of gemma-4-31b at any bitwidth "
            "is presumed to inherit the panic surface (Apple IOGPU "
            "kext bug, not model-layer). Examples observed in the wild "
            "include PLE-safe / RotorQuant / TurboQuant-KV variants. "
            "Treat as panic-prone until proven otherwise on your "
            "specific hardware + workload."
        ),
        "upstream": [
            "https://github.com/ml-explore/mlx/issues/3186",
            "https://github.com/ml-explore/mlx-lm/issues/883",
            "https://github.com/ml-explore/mlx/issues/3346",
        ],
    },

    # ─── v0.11.0 additions: 2026-04-27 community sweep ───
    "mlx-community/Qwen3.5-27B-4bit": {
        "tier": "degradation",
        "error_classes": [
            {
                "type": "metal_descriptor_leak",
                "signature": "[metal::malloc] Resource limit (499000) exceeded",
                "first_seen_via": "ml-explore/mlx-lm#1185",
                "hardware": ["M4 Max 128GB"],
                "gpu_family": ["M4"],
                "workload": "LoRA training (mlx_lm.lora)",
                "mitigation": (
                    "Lower clear_cache_threshold delays but doesn't eliminate. "
                    "Use ResourceTracker(cold_restart_after=4000) (L14) to force "
                    "subprocess respawn before hitting the descriptor limit. "
                    "Peak memory stable ~60GB so this is descriptor accumulation, "
                    "not RAM exhaustion."
                ),
            },
        ],
        "verified_safe_alternative": None,
        "first_observed": "2026-04-26",
        "last_observed": "2026-04-26",
        "panic_signature": "[metal::malloc] Resource limit (499000) exceeded",
        "reproductions": [],
        "community": ["Ogilthorp3 — ml-explore/mlx-lm#1185 (M4 Max 128GB LoRA)"],
        "recommendation": (
            "Inference (non-training) workloads less affected. For LoRA training, "
            "wire metal_guard.ResourceTracker into your training loop and "
            "subprocess.shutdown() + spawn new runner before threshold."
        ),
        "upstream": ["https://github.com/ml-explore/mlx-lm/issues/1185"],
    },

    "mlx-community/Qwen3.5-35B-A3B-8bit": {
        "tier": "degradation",
        "error_classes": [
            {
                "type": "metal_descriptor_leak",
                "signature": "[metal::malloc] Resource limit (499000) exceeded",
                "first_seen_via": "ml-explore/mlx-lm#1185",
                "hardware": ["M4 Max 128GB"],
                "gpu_family": ["M4"],
                "workload": "LoRA training (qwen3_5 architecture)",
                "mitigation": "Same as Qwen3.5-27B-4bit; pre-emptive cold restart.",
            },
            {
                "type": "process_abort",
                "signature": "GeneratorExit / prefill interrupted",
                "first_seen_via": "jundot/omlx#578",
                "hardware": ["M4 Max 64GB"],
                "gpu_family": ["M4"],
                "workload": (
                    "Long-context agent streaming (Claude Code) even with "
                    "SpecPrefill OFF + TurboQuant OFF"
                ),
                "mitigation": (
                    "metal-guard L11 orphan_monitor will detect SUBPROC_PRE "
                    "without matching POST after 90s — caller can SIGKILL "
                    "worker. No upstream fix yet."
                ),
            },
        ],
        "verified_safe_alternative": None,
        "first_observed": "2026-04-22",
        "last_observed": "2026-04-26",
        "panic_signature": "[metal::malloc] Resource limit (499000) exceeded",
        "reproductions": [],
        "community": [
            "Ogilthorp3 — ml-explore/mlx-lm#1185 (M4 Max 128GB LoRA)",
            "fparrav — jundot/omlx#578 (M4 Max 64GB long-context streaming)",
        ],
        "recommendation": (
            "MoE 35B variant has two distinct failure modes: descriptor leak "
            "during training (#1185) AND streaming prefill interruption "
            "(omlx#578). Avoid for production LoRA. For inference, use L7 "
            "subprocess isolation + L11 orphan monitor."
        ),
        "upstream": [
            "https://github.com/ml-explore/mlx-lm/issues/1185",
            "https://github.com/jundot/omlx/issues/578",
        ],
    },

    "mlx-community/Qwen3.6-35B-A3B-8bit": {
        "tier": "abort",
        "error_classes": [
            {
                "type": "process_abort",
                "signature": "DFlash drafter abort + client drop",
                "first_seen_via": "jundot/omlx#902",
                "hardware": ["M4 Max"],
                "gpu_family": ["M4"],
                "workload": "DFlash speculative decoding enabled",
                "mitigation": (
                    "Disable DFlash for this model. Plain decoding works; "
                    "DFlash drafter has unresolved kernel issue specific to "
                    "MoE A3B 8-bit quant."
                ),
            },
        ],
        "verified_safe_alternative": None,
        "first_observed": "2026-04-22",
        "last_observed": "2026-04-22",
        "panic_signature": "DFlash drafter abort + client drop",
        "reproductions": [],
        "community": ["jundot/omlx#902 (DFlash drafter abort)"],
        "recommendation": "Run with DFlash disabled, or pivot to non-A3B variant.",
        "upstream": ["https://github.com/jundot/omlx/issues/902"],
    },

    "mlx-community/Qwen3-VL-2B-Instruct": {
        "tier": "abort",
        "error_classes": [
            {
                "type": "gpu_hang",
                "signature": "kIOGPUCommandBufferCallbackErrorHang",
                "first_seen_via": "Blaizzy/mlx-vlm#1064",
                "hardware": ["M5 Max"],
                "gpu_family": ["M5"],
                "workload": "VLM prefill + generate (mlx-vlm 0.4.5 + mlx 0.32.0.dev)",
                "mitigation": (
                    "M5 Max applegpu_g17s specific. metal-guard L7 subprocess "
                    "isolation contains the abort. No known mitigation on M5 "
                    "hardware until upstream fix."
                ),
            },
            {
                "type": "gpu_page_fault",
                "signature": "kIOGPUCommandBufferCallbackErrorPageFault",
                "first_seen_via": "Blaizzy/mlx-vlm#1064 (Qwen3-VL-2B-Thinking-bf16)",
                "hardware": ["M5 Max"],
                "gpu_family": ["M5"],
                "workload": "VLM prefill on Thinking-bf16 variant",
                "mitigation": "Same as above — M5 Max specific.",
            },
        ],
        "verified_safe_alternative": "mlx-community/gemma-4-26b-a4b-it-4bit",
        "first_observed": "2026-04-24",
        "last_observed": "2026-04-24",
        "panic_signature": "kIOGPUCommandBufferCallbackErrorHang",
        "reproductions": [],
        "community": ["jrp2014 — Blaizzy/mlx-vlm#1064 (M5 Max VLM)"],
        "recommendation": (
            "Avoid Qwen3-VL family on M5 Max applegpu_g17s. M1-M4 untested "
            "but no reports yet."
        ),
        "upstream": ["https://github.com/Blaizzy/mlx-vlm/issues/1064"],
    },

    # ─── v0.11.4 additions: 2026-04-28 community sweep ───
    # Sources: ml-explore/mlx#3457 / mlx-lm#1206 #1208 #1197 / mlx-lm#1047
    "mlx-community/Qwen3.5-122B-A10B-VLM-MTP-5bit": {
        "tier": "abort",
        "error_classes": [
            {
                "type": "metal_cmd_buffer_timeout",
                "signature": "Metal command-buffer timeout (sparse prefill)",
                "first_seen_via": "ml-explore/mlx#3457",
                "hardware": ["M2 Ultra 128GB"],
                "gpu_family": ["M2"],
                "workload": "MoE 256x10 prefill ~19K tokens @ 64K context",
                "mitigation": (
                    "Reduce context window or split prefill into smaller chunks. "
                    "metal-guard L7 subprocess isolation contains the abort. "
                    "Issue closed upstream — no in-MLX fix planned."
                ),
            },
        ],
        "verified_safe_alternative": None,
        "first_observed": "2026-04-26",
        "last_observed": "2026-04-26",
        "panic_signature": "Metal command-buffer timeout (sparse prefill)",
        "reproductions": [],
        "community": ["ml-explore/mlx#3457 (M2 Ultra 128GB MoE prefill timeout)"],
        "recommendation": (
            "Avoid 64K-context sparse prefill on this MoE quant. Prefer "
            "shorter contexts or a non-MoE variant for long-form work."
        ),
        "upstream": ["https://github.com/ml-explore/mlx/issues/3457"],
    },

    "mlx-community/Qwen3-Coder-Next-4bit": {
        "tier": "abort",
        "error_classes": [
            {
                "type": "process_abort",
                "signature": "cannot schedule new futures after interpreter shutdown",
                "first_seen_via": "ml-explore/mlx-lm#1208",
                "hardware": ["unspecified"],
                "gpu_family": ["M1", "M2", "M3", "M4"],
                "workload": "mlx_lm.server load_default snapshot_download race",
                "mitigation": (
                    "metal-guard v0.11.3 scan_recent_aborts (5min/3-strike) "
                    "quarantines KeepAlive churn. Pin mlx-lm < 0.31.3 until "
                    "upstream lands a fix. L11 orphan_monitor catches the "
                    "SUBPROC_PRE without POST signature."
                ),
            },
        ],
        "verified_safe_alternative": None,
        "first_observed": "2026-04-27",
        "last_observed": "2026-04-27",
        "panic_signature": "cannot schedule new futures after interpreter shutdown",
        "reproductions": [],
        "community": [
            "ml-explore/mlx-lm#1208 (~420 crash-restarts in 2.5h on Coder-Next-4bit)",
        ],
        "recommendation": (
            "Affected by mlx-lm 0.31.3 server lifecycle bug. Pin mlx-lm "
            "earlier or use scan_recent_aborts to short-circuit KeepAlive "
            "respawn loops until upstream fix."
        ),
        "upstream": ["https://github.com/ml-explore/mlx-lm/issues/1208"],
    },

    "mlx-community/Qwen3.5-9B-4bit": {
        "tier": "abort",
        "error_classes": [
            {
                "type": "cmd_buffer_oom",
                "signature": "kIOGPUCommandBufferCallbackErrorOutOfMemory",
                "first_seen_via": "ml-explore/mlx-lm#1206",
                "hardware": ["M5 Max"],
                "gpu_family": ["M5"],
                "workload": "LoRA training first backward pass",
                "mitigation": (
                    "Does not reproduce on Qwen3-8B-4bit, so this is "
                    "9B-4bit-specific on applegpu_g17s. metal-guard L7 "
                    "subprocess isolation contains the abort. No M5 fix "
                    "until upstream."
                ),
            },
        ],
        "verified_safe_alternative": None,
        "first_observed": "2026-04-27",
        "last_observed": "2026-04-27",
        "panic_signature": "kIOGPUCommandBufferCallbackErrorOutOfMemory",
        "reproductions": [],
        "community": ["ml-explore/mlx-lm#1206 (M5 Max LoRA first-backward OOM)"],
        "recommendation": (
            "Avoid 9B-4bit LoRA on M5 Max applegpu_g17s. Prefer 8B-4bit "
            "or pivot to a different quant tier."
        ),
        "upstream": ["https://github.com/ml-explore/mlx-lm/issues/1206"],
    },

    "mlx-community/Qwen3.6-35B-A3B-VLM-MTP-8bit": {
        "tier": "degradation",
        "error_classes": [
            {
                "type": "silent_corruption",
                "signature": "VLM checkpoint loaded text-only returns garbage",
                "first_seen_via": "ml-explore/mlx-lm#1197",
                "hardware": ["unspecified"],
                "gpu_family": ["M1", "M2", "M3", "M4", "M5"],
                "workload": "mlx_lm.load() on a model with vision_config",
                "mitigation": (
                    "Detect at load time: if model card has vision_config "
                    "but loader is mlx-lm (not mlx-vlm), refuse or warn loud. "
                    "No process abort — output is incoherent but appears "
                    "successful, so this is a silent class metal-guard "
                    "currently flags via warn_if_known_panic_model only."
                ),
            },
        ],
        "verified_safe_alternative": None,
        "first_observed": "2026-04-27",
        "last_observed": "2026-04-27",
        "panic_signature": "VLM checkpoint loaded text-only returns garbage",
        "reproductions": [],
        "community": ["ml-explore/mlx-lm#1197 (VLM-as-text silent garbage)"],
        "recommendation": (
            "Use mlx-vlm to load this checkpoint. Loading via mlx-lm "
            "succeeds without error but yields incoherent output."
        ),
        "upstream": ["https://github.com/ml-explore/mlx-lm/issues/1197"],
    },

    "workflow:gemma4-fused-via-mlx_lm.fuse": {
        "tier": "degradation",
        "error_classes": [
            {
                "type": "fuse_round_trip_swift_incompatible",
                "signature": (
                    "Gemma 4 attention-shape divergence: fused checkpoint "
                    "fails to load in mlx-swift-lm"
                ),
                "first_seen_via": "ml-explore/mlx-lm#1210",
                "hardware": ["any"],
                "gpu_family": ["M1", "M2", "M3", "M4", "M5"],
                "workload": (
                    "mlx_lm.fuse round-trip: LoRA adapter merged into "
                    "Gemma 4 base, deployed via mlx-swift-lm consumer"
                ),
                "mitigation": (
                    "mlx-lm Python only writes k_proj / v_proj on layers "
                    "with has_kv=True; mlx-swift-lm expects them on every "
                    "layer. Until upstream alignment, deploy fused Gemma "
                    "4 LoRAs only via Python mlx-lm consumers (not Swift)."
                ),
            },
        ],
        "verified_safe_alternative": None,
        "first_observed": "2026-04-27",
        "last_observed": "2026-04-27",
        "panic_signature": (
            "Gemma 4 attention-shape divergence: fused checkpoint "
            "fails to load in mlx-swift-lm"
        ),
        "reproductions": [],
        "community": ["ml-explore/mlx-lm#1210 (fuse round-trip Swift incompat)"],
        "recommendation": (
            "Skip mlx_lm.fuse for Gemma 4 LoRA → Swift deployment paths "
            "until #1210 lands. Python-side consumers unaffected."
        ),
        "upstream": ["https://github.com/ml-explore/mlx-lm/issues/1210"],
    },

    "mlx-community/kimi-k2.5": {
        "tier": "abort",
        "error_classes": [
            {
                "type": "kv_cache_oom",
                "signature": "kIOGPUCommandBufferCallbackErrorOutOfMemory (KV cache)",
                "first_seen_via": "ml-explore/mlx-lm#1047",
                "hardware": ["Mac Studio M3 Ultra"],
                "gpu_family": ["M3"],
                "workload": "Inference with extended context",
                "mitigation": (
                    "Limit context length, lower kv_cache precision, or "
                    "subprocess-isolate via metal-guard L7. No upstream fix "
                    "for the model's KV cache memory profile on M3 Ultra."
                ),
            },
        ],
        "verified_safe_alternative": None,
        "first_observed": "2026-04-12",
        "last_observed": "2026-04-12",
        "panic_signature": "kIOGPUCommandBufferCallbackErrorOutOfMemory (KV cache)",
        "reproductions": [],
        "community": ["ml-explore/mlx-lm#1047 (Mac Studio M3 Ultra KV cache OOM)"],
        "recommendation": (
            "Constrain context length on M3 Ultra; use L7 subprocess "
            "isolation. No fix available."
        ),
        "upstream": ["https://github.com/ml-explore/mlx-lm/issues/1047"],
    },
}

# v0.11.4: MLX-version-level blocklist (separate from per-model registry).
# Some panic/crash classes are caused by the MLX library version itself,
# regardless of model. Callers should query before spawning workers.
MLX_VERSION_BLOCKLIST: dict[str, dict[str, Any]] = {
    "0.31.2": {
        "severity": "critical",
        "error_class": "process_abort",
        "signature": "mx.clear_cache() SIGSEGV (PR #3282 smart-pointer regression)",
        "reason": (
            "mx.clear_cache() segfaults when streaming decoders hold state "
            "across calls. Affects any workload calling clear_cache between "
            "eval() invocations. Reproduces on M1 Pro and later."
        ),
        "first_observed": "2026-04-27",
        "upstream": ["https://github.com/ml-explore/mlx/issues/3450"],
        "workaround": "Pin mlx==0.31.1 or wait for 0.31.4+.",
    },
}

# v0.11.6: mlx-lm version blocklist (separate from mlx core blocklist).
# mlx-lm and mlx are versioned independently; a bad mlx-lm release can
# crash callers even when mlx core is fine.
MLX_LM_VERSION_BLOCKLIST: dict[str, dict[str, Any]] = {
    "0.31.3": {
        "severity": "high",
        "error_class": "process_abort",
        "signature": (
            "Multiple server-lifecycle bugs (3 distinct crash-loops "
            "filed in 24h on this version)"
        ),
        "reason": (
            "mlx-lm 0.31.3 has three concurrent server-crash issues: "
            "ml-explore/mlx-lm#1208 (load_default → snapshot_download → "
            "thread_map at interpreter shutdown), #1215 (prompt-cache "
            "exact-hit empties segments → IndexError in insert_segments), "
            "and #1206 / #1185 LoRA OOM patterns also active in this "
            "release line. Avoid for production server workloads."
        ),
        "first_observed": "2026-04-27",
        "upstream": [
            "https://github.com/ml-explore/mlx-lm/issues/1208",
            "https://github.com/ml-explore/mlx-lm/issues/1215",
            "https://github.com/ml-explore/mlx-lm/issues/1206",
        ],
        "workaround": "Pin mlx-lm==0.31.2 or wait for 0.31.4+.",
    },
}


def check_mlx_lm_version_blocked(version: str) -> dict[str, Any] | None:
    """Return blocklist entry for an mlx-lm library version, else ``None``.

    Mirrors :func:`check_mlx_version_blocked` but for the separately-
    versioned `mlx-lm` package. Caller policy: refuse / downgrade / warn.
    """
    return MLX_LM_VERSION_BLOCKLIST.get(version)


# v0.11.6: workload-level advisories (orthogonal to model and library
# version). Some panics are caused by host environment, not the model.
WORKLOAD_ADVISORIES: dict[str, dict[str, Any]] = {
    "lora_with_display_active": {
        "severity": "high",
        "error_class": "gpu_watchdog_kill",
        "signature": "kIOGPUCommandBufferCallbackErrorImpactingInteractivity",
        "reason": (
            "Apple's IOGPU watchdog kills LoRA training when it competes "
            "for GPU time with the active display. Reproduces 4/4 on "
            "macOS 26.2 / 26.3.1. Affects ALL LoRA workloads regardless "
            "of model — orthogonal to KNOWN_PANIC_MODELS."
        ),
        "first_observed": "2026-04-12",
        "upstream": ["https://github.com/ml-explore/mlx/issues/3267"],
        "workaround": (
            "Run training with display sleep active, or via SSH from "
            "another machine. `caffeinate -s` keeps the system awake "
            "without forcing the display on. Alternatively, dim brightness "
            "to zero so WindowServer yields GPU. metal-guard L7 subprocess "
            "isolation does NOT help — the kill is at IOGPU layer above "
            "process boundary."
        ),
    },
}


def check_workload_advisory(workload_id: str) -> dict[str, Any] | None:
    """Return advisory for a known panic-prone workload, else ``None``.

    Workload IDs are stable strings like ``"lora_with_display_active"``.
    Callers can wire this into training launchers to surface mitigation
    advice before kicking off a job that's likely to die.
    """
    return WORKLOAD_ADVISORIES.get(workload_id)


def check_mlx_version_blocked(version: str) -> dict[str, Any] | None:
    """Return blocklist entry for an MLX library version, else ``None``.

    Caller policy: refuse to spawn workers, downgrade, or warn loud.
    metal-guard does not refuse on its own — this is advisory only.

    Typical pattern::

        import mlx.core as mx
        block = metal_guard.check_mlx_version_blocked(mx.__version__)
        if block is not None:
            log.error("MLX %s is blocklisted: %s", mx.__version__,
                      block["workaround"])
    """
    return MLX_VERSION_BLOCKLIST.get(version)


_WARNED_PANIC_MODELS: set[str] = set()


def check_known_panic_model(model_id: str) -> dict[str, Any] | None:
    """Return the advisory dict for a known-panic model, else ``None``.

    Policy is the caller's — metal-guard does not refuse loads on its own.
    Typical pattern::

        advisory = metal_guard.check_known_panic_model(model_id)
        if advisory is not None:
            log.warning(
                "Loading known-panic model %s: %s",
                model_id, advisory["recommendation"],
            )
    """
    return KNOWN_PANIC_MODELS.get(model_id)


def warn_if_known_panic_model(model_id: str) -> bool:
    """Emit a single ``log.warning`` per process per model_id.

    Returns True if a warning was emitted (or would have been on a prior
    call), False if the model is not in the known-panic list. Safe to
    call on every load — idempotent via a module-level set.
    """
    advisory = check_known_panic_model(model_id)
    if advisory is None:
        return False
    if model_id in _WARNED_PANIC_MODELS:
        return True
    _WARNED_PANIC_MODELS.add(model_id)
    log.warning(
        "metal-guard: %s is in KNOWN_PANIC_MODELS — %s",
        model_id, advisory["recommendation"],
    )
    return True


# v0.11.0 helpers — filter / index by the new schema dimensions

def check_known_panic_model_for_gpu(
    model_id: str,
    *,
    gpu_family: str | None = None,
) -> dict[str, Any] | None:
    """Return advisory for ``model_id``, optionally filtered by GPU family.

    When ``gpu_family`` (e.g. ``"M1"``, ``"M5"``) is provided, ``error_classes``
    not confirmed on that family are filtered out — caller sees only what
    actually affects their hardware. Returns None if the filtered list is
    empty (model affected on other families but not yours).

    Falls back to :func:`check_known_panic_model` when ``gpu_family`` is
    None (legacy unfiltered behaviour).
    """
    if gpu_family is None:
        return check_known_panic_model(model_id)
    advisory = KNOWN_PANIC_MODELS.get(model_id)
    if advisory is None:
        return None
    error_classes = advisory.get("error_classes")
    if not error_classes:
        # Entry without v0.11.0 schema — return as-is (no per-family filter)
        return advisory
    filtered = [
        ec for ec in error_classes
        if not ec.get("gpu_family") or gpu_family in ec["gpu_family"]
    ]
    if not filtered:
        return None
    return {**advisory, "error_classes": filtered}


def models_by_tier(tier: str) -> tuple[str, ...]:
    """All KNOWN_PANIC_MODELS IDs at a given tier.

    Tier vocabulary: ``"panic"`` (kernel-level, reboots Mac) /
    ``"abort"`` (process-level SIGABRT or hang) /
    ``"degradation"`` (slow descriptor leak, no abort).

    Entries without ``tier`` (legacy schema) are excluded.
    """
    return tuple(sorted(
        m for m, advise in KNOWN_PANIC_MODELS.items()
        if advise.get("tier") == tier
    ))


def models_affecting_gpu_family(gpu_family: str) -> tuple[str, ...]:
    """All model IDs with at least one error_class confirmed on ``gpu_family``.

    Entries without ``error_classes`` (legacy schema) are excluded — call
    :func:`check_known_panic_model` directly to access them.
    """
    out: list[str] = []
    for m, advise in KNOWN_PANIC_MODELS.items():
        for ec in advise.get("error_classes", []):
            if gpu_family in ec.get("gpu_family", []):
                out.append(m)
                break
    return tuple(sorted(out))
