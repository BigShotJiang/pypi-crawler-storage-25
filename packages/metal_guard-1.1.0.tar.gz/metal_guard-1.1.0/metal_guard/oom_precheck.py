"""High-level pre-call OOM gate.

Wraps the prefill-allocation math (``metal_guard.prefill``) with
ergonomic auto-fetch of model dims + GPU memory + corpus emit, so a
caller can do a one-liner pre-call check without wiring four modules.

``precheck_inference`` returns a structured :class:`OOMVerdict` with
``advisory`` / ``blocker`` instead of raising, so callers can log and
downgrade gracefully. ``precheck_inference_or_raise`` is the strict
variant that raises ``MetalOOMError`` on a blocker.

Upstream references encoded in advisories:

* `mlx#3186 <https://github.com/ml-explore/mlx/issues/3186>`_ —
  kernel panic on a ~173K-token prefill.
* `mlx-lm#854 <https://github.com/ml-explore/mlx-lm/issues/854>`_ —
  ``mlx_lm.server`` SIGABRT on Metal OOM instead of an HTTP error.
* `mlx-lm#1015 <https://github.com/ml-explore/mlx-lm/issues/1015>`_ —
  ``generate()`` crashes on Metal OOM rather than recovering.
* `mlx-lm#1047 <https://github.com/ml-explore/mlx-lm/issues/1047>`_ —
  KV-cache OOM crash on M3 Ultra.

Override: ``METALGUARD_OOM_PRECHECK_DISABLED=1`` short-circuits
``precheck_inference`` to an always-safe verdict.
"""
from __future__ import annotations

import os
import re
import subprocess
from dataclasses import dataclass
from typing import Any

from metal_guard._constants import log

# Long-context advisory threshold (mlx#3186 hit at ~173K on M4 Max;
# Harper M1 Ultra typical ceiling lower, but advisory at 100K gives
# operator early warning to consider chunking).
_LONG_CONTEXT_TOKENS_WARN = 100_000
_LONG_CONTEXT_TOKENS_BLOCK = 200_000  # absolute hard block, no model fits

# Default IOGPUFamily single-alloc ceiling. Above this, Metal driver state
# corruption risk regardless of headroom (mlx#3186 root cause is the
# IOGPUMemory.cpp completeMemory() refcount path, not pure OOM).
_SINGLE_ALLOC_CEILING_GB_DEFAULT = 5.0
_HEADROOM_PCT_DEFAULT = 0.30

_DISABLED_ENV = "METALGUARD_OOM_PRECHECK_DISABLED"

# P3 (2026-05-02 night) — system pressure precheck (community-inspired).
# vm_stat reading thresholds. Wired ratio > 70% means kernel pages
# heavily pinned → Metal command buffer queue may stall under
# contention. <2GB free pages → unified memory headroom for subprocess
# respawn / Metal alloc bursts is exhausted. Both surface as soft
# advisories (do NOT block) — caller decides whether to defer the run.
_PRESSURE_WIRED_RATIO_WARN = 0.70
_PRESSURE_FREE_GB_WARN = 2.0
_VM_STAT_TIMEOUT_SEC = 2.0
# Apple Silicon page size (16KB on M1+; verified at runtime via the
# header line so older Intel macs would Just Work — though we don't
# target those).
_DEFAULT_PAGE_SIZE_BYTES = 16384
_VM_STAT_PAGE_SIZE_RE = re.compile(r"page size of (\d+) bytes")
_VM_STAT_FIELD_RE = re.compile(r"^Pages\s+([\w\s-]+?):\s+(\d+)\.?$")


@dataclass(frozen=True)
class OOMVerdict:
    """Result of :func:`precheck_inference`.

    Attributes:
        safe: True iff caller should proceed without modifying request.
        peak_alloc_gb: Estimated peak single-allocation in GB (max of
            attention-score tensor and whole-model KV cache).
        available_gb: Detected available unified memory headroom.
        headroom_pct: Configured fraction of available_gb required free.
        context_tokens: Effective context length checked.
        advisories: Tuple of (id, message) — soft warnings, do NOT block.
        blocker: Single-string blocker reason if safe=False, else None.
        upstream_refs: Tuple of relevant upstream issue URLs.
    """
    safe: bool
    peak_alloc_gb: float
    available_gb: float
    headroom_pct: float
    context_tokens: int
    advisories: tuple[tuple[str, str], ...] = ()
    blocker: str | None = None
    upstream_refs: tuple[str, ...] = ()


def _detect_available_gb() -> float | None:
    """Best-effort unified memory headroom detection.

    Order of preference:
      1. ``mlx.core.metal.get_active_memory()`` + memory_size from
         ``apple_gpu_family()`` — most accurate (Metal-side accounting).
      2. ``/usr/bin/vm_stat`` free pages — stdlib fallback (no psutil).
      3. None — caller falls back to skip (cannot make informed gate).

    Returns None when neither source available so caller can degrade
    gracefully (no false-positive blocks on environments without vm_stat).
    """
    # MLX-aware path
    try:
        from metal_guard.system_audit import apple_gpu_family
        info = apple_gpu_family()
        if isinstance(info, dict) and info.get("available"):
            mem_gb = info.get("memory_size_gb")
            if isinstance(mem_gb, (int, float)) and mem_gb > 0:
                # Try to subtract currently-active Metal allocation for
                # tighter headroom. Defensive — mlx may not be loaded.
                try:
                    import mlx.core as mx  # type: ignore
                    active = float(mx.metal.get_active_memory())
                    return max(0.0, float(mem_gb) - active / 1e9)
                except Exception:  # noqa: BLE001 — mlx import / API drift
                    return float(mem_gb)
    except ImportError:
        pass
    except Exception as exc:  # noqa: BLE001 defensive
        log.debug("apple_gpu_family detection failed: %s", exc)

    # stdlib fallback — derive available memory from vm_stat (no psutil
    # dependency). _detect_system_pressure() parses /usr/bin/vm_stat and
    # returns free_gb = free + inactive + speculative + purgeable pages.
    # Note: compressed pages are excluded from free_gb, so it can read
    # slightly higher than the old psutil.virtual_memory().available under
    # memory pressure — acceptable for this soft advisory gate.
    pressure = _detect_system_pressure()
    if pressure is not None:
        free_gb = pressure.get("free_gb")
        if isinstance(free_gb, (int, float)) and free_gb >= 0:
            return float(free_gb)
    return None


def _detect_system_pressure() -> dict[str, Any] | None:
    """Best-effort vm_stat snapshot for system memory pressure.

    Returns dict with ``free_gb`` / ``wired_gb`` / ``active_gb`` /
    ``wired_ratio``, or ``None`` on parse failure / vm_stat missing.

    Uses absolute path ``/usr/bin/vm_stat`` so test environments with
    PATH stripping still hit the binary. Conservative on failure: caller
    treats None as "no pressure data" — does not block.
    """
    try:
        result = subprocess.run(
            ["/usr/bin/vm_stat"],
            capture_output=True, text=True,
            timeout=_VM_STAT_TIMEOUT_SEC, check=False,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
        log.debug("oom_precheck: vm_stat failed (%s)", exc)
        return None
    except Exception as exc:  # noqa: BLE001 defensive
        log.debug("oom_precheck: vm_stat crashed (%s)", exc)
        return None
    if result.returncode != 0:
        return None

    stdout = result.stdout or ""
    page_size = _DEFAULT_PAGE_SIZE_BYTES
    m = _VM_STAT_PAGE_SIZE_RE.search(stdout)
    if m:
        try:
            page_size = int(m.group(1))
        except ValueError:
            pass

    fields: dict[str, int] = {}
    for line in stdout.splitlines():
        fm = _VM_STAT_FIELD_RE.match(line)
        if fm:
            key = fm.group(1).strip().lower().replace(" ", "_").replace("-", "_")
            try:
                fields[key] = int(fm.group(2))
            except ValueError:
                continue
    if not fields:
        return None

    # "Free" effective = directly free + reclaimable inactive +
    # speculative + purgeable. Pages active are user-task working
    # set — counted toward "in use" not "available".
    free_pages = (
        fields.get("free", 0)
        + fields.get("inactive", 0)
        + fields.get("speculative", 0)
        + fields.get("purgeable", 0)
    )
    wired_pages = fields.get("wired_down", 0)
    active_pages = fields.get("active", 0)
    # Compressed pages live in the compressor pool — count toward "in use"
    # because they cost CPU to decompress. Not always present in older
    # vm_stat versions; .get() defaults to 0.
    compressed_pages = fields.get(
        "occupied_by_compressor", fields.get("compressed", 0)
    )
    total_pages = max(
        free_pages + wired_pages + active_pages + compressed_pages, 1,
    )
    return {
        "free_gb": round(free_pages * page_size / 1e9, 2),
        "wired_gb": round(wired_pages * page_size / 1e9, 2),
        "active_gb": round(active_pages * page_size / 1e9, 2),
        "compressed_gb": round(compressed_pages * page_size / 1e9, 2),
        "wired_ratio": round(wired_pages / total_pages, 3),
    }


def precheck_inference(
    *,
    model_id: str,
    context_tokens: int,
    max_new_tokens: int = 0,
    headroom_pct: float = _HEADROOM_PCT_DEFAULT,
    single_alloc_ceiling_gb: float = _SINGLE_ALLOC_CEILING_GB_DEFAULT,
    available_gb: float | None = None,
) -> OOMVerdict:
    """Pre-call OOM gate. Returns structured verdict, never raises.

    Args:
        model_id: HuggingFace-style identifier (used to look up dims).
        context_tokens: Prompt token count (caller is responsible for
            tokenisation; pass `len(tokenizer.encode(prompt))`).
        max_new_tokens: Number of tokens caller plans to generate. Added
            to ``context_tokens`` for end-of-generation worst-case.
        headroom_pct: Fraction of available memory to keep free
            (default 30%; tighter for batch / loose for interactive).
        single_alloc_ceiling_gb: Hard cap on single-allocation peak
            (default 5GB; mlx#3186 IOGPU state corruption risk).
        available_gb: Override auto-detection (testing / known constraint).

    Returns:
        :class:`OOMVerdict`. ``safe=False`` iff a blocker fires;
        advisories surface soft warnings (long context, unknown dims).
    """
    if os.environ.get(_DISABLED_ENV) == "1":
        return OOMVerdict(
            safe=True,
            peak_alloc_gb=0.0,
            available_gb=available_gb or 0.0,
            headroom_pct=headroom_pct,
            context_tokens=context_tokens,
            advisories=(("OOM_precheck_disabled", f"{_DISABLED_ENV}=1"),),
        )

    advisories: list[tuple[str, str]] = []
    refs: list[str] = []
    effective_ctx = context_tokens + max(0, max_new_tokens)

    # L1 — long context advisory / hard block
    if effective_ctx >= _LONG_CONTEXT_TOKENS_BLOCK:
        return OOMVerdict(
            safe=False,
            peak_alloc_gb=0.0,
            available_gb=available_gb or 0.0,
            headroom_pct=headroom_pct,
            context_tokens=effective_ctx,
            blocker=(
                f"context={effective_ctx} ≥ {_LONG_CONTEXT_TOKENS_BLOCK} "
                "absolute hard block (mlx#3186 territory; chunk required)"
            ),
            upstream_refs=("https://github.com/ml-explore/mlx/issues/3186",),
        )
    if effective_ctx >= _LONG_CONTEXT_TOKENS_WARN:
        advisories.append((
            "W_long_context",
            f"context={effective_ctx} ≥ {_LONG_CONTEXT_TOKENS_WARN}: "
            f"approaching mlx#3186 prefill panic territory",
        ))
        refs.append("https://github.com/ml-explore/mlx/issues/3186")

    # L2 — lookup model dims (advisory if unknown)
    try:
        from metal_guard.prefill import lookup_dims, estimate_prefill_peak_alloc_gb
    except ImportError:
        return OOMVerdict(
            safe=True,
            peak_alloc_gb=0.0,
            available_gb=available_gb or 0.0,
            headroom_pct=headroom_pct,
            context_tokens=effective_ctx,
            advisories=tuple(advisories) + (
                ("W_prefill_guard_missing",
                 "prefill_guard module unavailable; cannot estimate peak"),
            ),
            upstream_refs=tuple(refs),
        )

    dims = lookup_dims(model_id)
    if dims is None:
        advisories.append((
            "W_unknown_model_dims",
            f"model_id {model_id!r} not in KNOWN_MODELS; cannot estimate "
            f"peak alloc — proceeding without OOM gate",
        ))
        return OOMVerdict(
            safe=True,  # cannot block without dims
            peak_alloc_gb=0.0,
            available_gb=available_gb or 0.0,
            headroom_pct=headroom_pct,
            context_tokens=effective_ctx,
            advisories=tuple(advisories),
            upstream_refs=tuple(refs),
        )

    # L3 — peak alloc estimate (delegate to prefill_guard math)
    peak_gb = estimate_prefill_peak_alloc_gb(
        context_tokens=effective_ctx, dims=dims,
    )

    # L4 — single-alloc ceiling
    if peak_gb > single_alloc_ceiling_gb:
        return OOMVerdict(
            safe=False,
            peak_alloc_gb=peak_gb,
            available_gb=available_gb or 0.0,
            headroom_pct=headroom_pct,
            context_tokens=effective_ctx,
            advisories=tuple(advisories),
            blocker=(
                f"peak alloc {peak_gb:.1f} GB > single-alloc ceiling "
                f"{single_alloc_ceiling_gb:.1f} GB at ctx={effective_ctx}; "
                "IOGPUFamily state corruption risk"
            ),
            upstream_refs=tuple(refs) + (
                "https://github.com/ml-explore/mlx/issues/3186",
            ),
        )

    # L5 — headroom check (auto-detect if not provided)
    if available_gb is None:
        available_gb = _detect_available_gb()
    if available_gb is None:
        # Cannot make informed call — surface as advisory.
        advisories.append((
            "W_available_unknown",
            "could not auto-detect available memory (mlx + vm_stat unavailable); "
            "headroom gate skipped",
        ))
        return OOMVerdict(
            safe=True,
            peak_alloc_gb=peak_gb,
            available_gb=0.0,
            headroom_pct=headroom_pct,
            context_tokens=effective_ctx,
            advisories=tuple(advisories),
            upstream_refs=tuple(refs),
        )

    threshold_gb = available_gb * (1.0 - headroom_pct)
    if peak_gb > threshold_gb:
        return OOMVerdict(
            safe=False,
            peak_alloc_gb=peak_gb,
            available_gb=available_gb,
            headroom_pct=headroom_pct,
            context_tokens=effective_ctx,
            advisories=tuple(advisories),
            blocker=(
                f"peak alloc {peak_gb:.1f} GB > {threshold_gb:.1f} GB "
                f"({available_gb:.1f} GB × {1 - headroom_pct:.0%}) at "
                f"ctx={effective_ctx}"
            ),
            upstream_refs=tuple(refs) + (
                "https://github.com/ml-explore/mlx-lm/issues/854",
                "https://github.com/ml-explore/mlx-lm/issues/1015",
            ),
        )

    # L6 — system pressure soft advisory (community-inspired, P3).
    # vm_stat readings overlay our MLX-only view: a system under wired/
    # compressor pressure can stall Metal command queue dispatch enough
    # to widen the IOGPU race window. Soft only — pressure ebbs/flows.
    pressure = _detect_system_pressure()
    if pressure is not None:
        if pressure["wired_ratio"] > _PRESSURE_WIRED_RATIO_WARN:
            advisories.append((
                "W_system_wired_high",
                f"system wired ratio {pressure['wired_ratio']:.0%} "
                f"(>{_PRESSURE_WIRED_RATIO_WARN:.0%}); MLX command "
                f"buffer queue may stall under contention",
            ))
        if pressure["free_gb"] < _PRESSURE_FREE_GB_WARN:
            advisories.append((
                "W_system_low_free",
                f"system free memory {pressure['free_gb']:.1f}GB "
                f"(<{_PRESSURE_FREE_GB_WARN:.0f}GB); unified memory "
                f"headroom for subprocess respawn / Metal alloc bursts "
                f"is exhausted",
            ))

    return OOMVerdict(
        safe=True,
        peak_alloc_gb=peak_gb,
        available_gb=available_gb,
        headroom_pct=headroom_pct,
        context_tokens=effective_ctx,
        advisories=tuple(advisories),
        upstream_refs=tuple(refs),
    )


def precheck_inference_or_raise(**kwargs: Any) -> OOMVerdict:
    """Strict variant of :func:`precheck_inference` — raises ``MetalOOMError``
    when ``safe=False``. Soft advisories logged at WARNING."""
    verdict = precheck_inference(**kwargs)

    # Emit corpus event regardless of safe/blocked (best-effort).
    try:
        from metal_guard.corpus import append_event
        if not verdict.safe:
            append_event(
                "oom_precheck_blocked",
                model_id=kwargs.get("model_id"),
                extra={
                    "blocker": verdict.blocker,
                    "peak_gb": round(verdict.peak_alloc_gb, 2),
                    "available_gb": round(verdict.available_gb, 2),
                    "context_tokens": verdict.context_tokens,
                },
            )
        elif verdict.advisories:
            append_event(
                "oom_precheck_warned",
                model_id=kwargs.get("model_id"),
                extra={
                    "advisories": [list(a) for a in verdict.advisories],
                    "peak_gb": round(verdict.peak_alloc_gb, 2),
                },
            )
    except Exception as exc:  # noqa: BLE001 corpus best-effort
        log.debug("oom_precheck: corpus emit failed: %s", exc)

    for advisory_id, msg in verdict.advisories:
        log.warning("oom_precheck advisory [%s]: %s", advisory_id, msg)

    if not verdict.safe:
        try:
            from metal_guard.memory import MetalOOMError
        except ImportError:
            raise RuntimeError(f"OOM precheck blocked: {verdict.blocker}")
        raise MetalOOMError(verdict.blocker or "OOM precheck blocked")
    return verdict
