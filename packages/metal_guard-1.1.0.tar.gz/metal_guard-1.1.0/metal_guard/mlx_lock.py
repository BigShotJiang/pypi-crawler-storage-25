"""Cross-process MLX exclusive lock (Layer 8)."""

from __future__ import annotations

import datetime
import gc
import glob
import json
import logging
import multiprocessing
import os
import pathlib
import platform
import re
import shutil
import signal
import socket
import sys
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from multiprocessing.connection import Connection
from pathlib import Path
from typing import Any, Callable, Generator, Iterator, Tuple, TypeVar

from metal_guard._constants import log

# ---------------------------------------------------------------------------
# Cross-process mutual exclusion (Layer 8)
# ---------------------------------------------------------------------------

# Lock file path — configurable via MLX_LOCK_PATH env var.
# Default: ~/.metal-guard/locks/mlx_exclusive.lock
_LOCK_PATH_ENV = os.getenv("MLX_LOCK_PATH")
_PROCESS_LOCK_PATH = (
    Path(_LOCK_PATH_ENV).expanduser()
    if _LOCK_PATH_ENV
    else Path.home() / ".metal-guard" / "locks" / "mlx_exclusive.lock"
)

# How long to wait for the previous lock holder to exit after receiving
# SIGTERM during a ``force=True`` acquire. A well-behaved MLX process
# takes a few seconds to flush Metal buffers and run atexit hooks.
# Anything beyond this is hung or actively ignoring SIGTERM, in which
# case we abort rather than silently unlink — unlinking while the peer
# still holds Metal buffers is the kernel-panic path (see FORCE hardening
# notes in CHANGELOG v0.6.0). Tunable via env var for tests / tight CI.
_FORCE_WAIT_SEC = float(os.getenv("MLX_FORCE_WAIT_SEC", "30"))
_FORCE_POLL_INTERVAL_SEC = 0.25

# After a FORCE acquire has SIGTERM'd the previous holder and confirmed
# it exited, sleep this long before returning — gives the kernel's Metal
# buffer GC a window to release the peer's VRAM allocations before the
# new process starts loading models into the same GPU. Without this gap
# the new model load can race the buffer GC and still recreate the panic
# conditions. Only applies when we actually reclaimed from a live peer;
# normal (lock-free) acquires stay zero-latency. Set to 0 in tests.
_RECLAIM_COOLDOWN_SEC = float(os.getenv("MLX_RECLAIM_COOLDOWN_SEC", "8"))


class MLXLockConflict(RuntimeError):
    """Raised when another live process already holds the MLX lock.

    The exception message includes the holder's label, pid, timestamp,
    and cmdline so operators can decide whether to wait or intervene.
    The holder info is exposed via ``.holder`` as a dict.

    When raised from the ``force=True`` path, ``.holder`` may include:
      * ``force_timeout=True`` — SIGTERM was delivered but the peer did
        not exit within ``MLX_FORCE_WAIT_SEC``. Lock deliberately left
        intact so that Metal buffers are not double-allocated.
      * ``force_permission_denied=True`` — we lack permission to signal
        the peer (e.g. pid 1, different user). Lock deliberately left
        intact. Caller should escalate manually rather than retry.
    """

    def __init__(self, holder: dict[str, Any]):
        self.holder = holder
        label = holder.get("label", "unknown")
        pid = holder.get("pid", "?")
        elapsed = _format_elapsed(holder.get("started_at", ""))
        cmdline = holder.get("cmdline", "")
        super().__init__(
            f"MLX lock held by {label} (pid={pid}, running for {elapsed}). "
            f"cmdline: {cmdline!r}. "
            f"Concurrent MLX workloads trigger Metal kernel panics — "
            f"wait for the other process to finish, or pass force=True "
            f"if you know the other process is hung."
        )


def _is_pid_alive(pid: int) -> bool:
    """True if ``pid`` is a running, non-zombie process.

    A process that has called ``exit()`` but has not yet been reaped by
    its parent shows up as a zombie in ``ps``. ``os.kill(pid, 0)``
    succeeds for zombies, but they have already released every kernel
    resource including Metal buffers. For the purposes of the
    kernel-panic invariant ("is it safe to take this MLX lock?"),
    zombies must be treated as dead — otherwise FORCE override would
    block forever waiting for a peer whose Metal buffers are already
    freed.
    """
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        # Process exists but owned by another user. We cannot inspect
        # its state, so conservatively say alive.
        return True
    if _is_zombie(pid):
        return False
    return True


def _is_zombie(pid: int) -> bool:
    """Return True if ``ps`` reports the pid is a zombie (state 'Z').

    macOS and Linux both expose this via ``ps -p <pid> -o state=``; the
    first character is the process state, 'Z' for zombies. Falls back
    to False on exotic platforms without ``ps`` — the conservative
    choice, preserving pre-v0.6.0 behaviour.
    """
    try:
        import subprocess

        out = subprocess.run(
            ["ps", "-p", str(pid), "-o", "state="],
            capture_output=True,
            text=True,
            timeout=2,
        )
    except (FileNotFoundError, OSError):
        return False
    except Exception as exc:  # noqa: BLE001 — diagnostic fallback
        log.debug("_is_zombie: ps failed for pid %d: %s", pid, exc)
        return False
    state = out.stdout.strip()
    return bool(state) and state[0].upper() == "Z"


def _force_terminate_and_wait(existing: dict[str, Any]) -> None:
    """SIGTERM the previous lock holder and wait for it to exit.

    Raises ``MLXLockConflict`` when the holder does not exit within
    ``_FORCE_WAIT_SEC`` or when we lack permission to signal it. The
    caller only unlinks the lock after this returns cleanly —
    unlinking while the holder is still alive is the kernel-panic
    path (Metal buffers double-allocated across two live MLX
    processes → ``IOGPUMemory.cpp:492`` underflow).
    """
    existing_pid = existing.get("pid")
    if not isinstance(existing_pid, int) or existing_pid <= 0:
        log.warning(
            "_force_terminate_and_wait: invalid pid %r in lock, "
            "unlinking anyway", existing_pid,
        )
        return

    log.warning(
        "acquire_mlx_lock: FORCE requested, sending SIGTERM to %s "
        "(pid %s) and waiting up to %.1fs for Metal buffer release",
        existing.get("label", "?"), existing_pid, _FORCE_WAIT_SEC,
    )
    try:
        os.kill(existing_pid, signal.SIGTERM)
    except ProcessLookupError:
        # Already dead — nothing to wait for, safe to unlink.
        log.info(
            "_force_terminate_and_wait: pid %d already exited before SIGTERM",
            existing_pid,
        )
        return
    except PermissionError as exc:
        # Process exists but we cannot signal it. We must not unlink
        # because we cannot guarantee the peer released Metal buffers.
        raise MLXLockConflict({
            **existing,
            "force_permission_denied": True,
            "message": (
                f"FORCE override cannot signal pid {existing_pid}: {exc}. "
                f"Peer's MLX buffer state is unknown — refusing to unlink "
                f"the lock to avoid a kernel panic. Stop the peer "
                f"manually, or run with elevated privileges if you are "
                f"certain it is safe to kill."
            ),
        }) from exc

    deadline = time.monotonic() + _FORCE_WAIT_SEC
    while time.monotonic() < deadline:
        if not _is_pid_alive(existing_pid):
            log.info(
                "_force_terminate_and_wait: pid %d exited after SIGTERM",
                existing_pid,
            )
            return
        time.sleep(_FORCE_POLL_INTERVAL_SEC)

    raise MLXLockConflict({
        **existing,
        "force_timeout": True,
        "message": (
            f"FORCE override sent SIGTERM to pid {existing_pid} but it "
            f"did not exit within {_FORCE_WAIT_SEC:.1f}s. MLX buffers "
            f"are still allocated on the GPU — aborting to avoid a "
            f"kernel panic. Kill pid {existing_pid} manually (SIGKILL) "
            f"and retry."
        ),
    })


def _format_elapsed(started_at_iso: str) -> str:
    """Human-readable elapsed time since an ISO8601 UTC timestamp.

    Returns ``"unknown"`` for an empty string and echoes back any value
    that does not parse as ``%Y-%m-%dT%H:%M:%SZ`` (the format
    ``acquire_mlx_lock`` writes), so a corrupt lock file degrades to a
    raw-string display rather than raising.
    """
    if not started_at_iso:
        return "unknown"
    try:
        started = datetime.datetime.strptime(
            started_at_iso, "%Y-%m-%dT%H:%M:%SZ"
        ).replace(tzinfo=datetime.timezone.utc)
    except ValueError:
        return started_at_iso
    elapsed_sec = (
        datetime.datetime.now(datetime.timezone.utc) - started
    ).total_seconds()
    if elapsed_sec < 60:
        return f"{int(elapsed_sec)}s"
    if elapsed_sec < 3600:
        return f"{int(elapsed_sec / 60)}m {int(elapsed_sec % 60)}s"
    return f"{int(elapsed_sec / 3600)}h {int((elapsed_sec % 3600) / 60)}m"


def _current_cmdline() -> str:
    """Best-effort capture of the current command line for the lock file.

    Uses ``sys.argv`` with ``argv[0]`` reduced to its basename for
    readability, truncated to 300 chars to keep the lock file small.
    Falls back to ``pid:<pid>`` if ``sys.argv`` is unavailable.
    """
    try:
        argv = list(sys.argv)
        if argv:
            argv[0] = os.path.basename(argv[0])
            return " ".join(argv)[:300]
    except Exception as exc:  # noqa: BLE001 — diagnostic fallback
        log.debug("_current_cmdline: sys.argv unavailable: %s", exc)
    return f"pid:{os.getpid()}"


def _try_unlink(path: Path) -> None:
    """Best-effort unlink that swallows FileNotFoundError and PermissionError."""
    try:
        path.unlink()
    except (FileNotFoundError, PermissionError) as exc:
        log.debug("_try_unlink(%s): %s", path, exc)


def read_mlx_lock() -> dict[str, Any] | None:
    """Return the current lock holder's info dict, or None if free.

    Self-healing: if the recorded pid is dead (including zombies that
    have released their Metal buffers), the stale lock is removed and
    None is returned.
    """
    if not _PROCESS_LOCK_PATH.exists():
        return None
    try:
        raw = _PROCESS_LOCK_PATH.read_text()
    except OSError as exc:
        log.debug("read_mlx_lock: cannot read %s: %s", _PROCESS_LOCK_PATH, exc)
        return None
    try:
        info = json.loads(raw)
    except json.JSONDecodeError as exc:
        log.warning(
            "read_mlx_lock: corrupt lock file %s: %s", _PROCESS_LOCK_PATH, exc
        )
        _try_unlink(_PROCESS_LOCK_PATH)
        return None
    pid = info.get("pid")
    if not isinstance(pid, int):
        log.warning("read_mlx_lock: malformed lock (missing pid): %s", info)
        _try_unlink(_PROCESS_LOCK_PATH)
        return None
    if not _is_pid_alive(pid):
        log.info(
            "read_mlx_lock: stale lock (pid %d no longer exists), reclaiming",
            pid,
        )
        _try_unlink(_PROCESS_LOCK_PATH)
        return None
    return info


def acquire_mlx_lock(label: str, *, force: bool = False) -> dict[str, Any]:
    """Acquire the cross-process MLX exclusive lock.

    Raises ``MLXLockConflict`` when another live process holds the lock
    and ``force=False``.

    When ``force=True`` (v0.6.0 hardened semantics): sends ``SIGTERM``
    to the current holder, polls up to ``MLX_FORCE_WAIT_SEC`` seconds
    for it to exit, then reclaims the lock. Raises ``MLXLockConflict``
    with ``holder["force_timeout"]=True`` if the peer does not exit,
    or ``holder["force_permission_denied"]=True`` if the SIGTERM was
    denied. **Never unlinks while the holder is still alive** — that
    is the documented kernel-panic path. After a successful reclaim
    from a live peer, sleeps ``MLX_RECLAIM_COOLDOWN_SEC`` to allow
    Metal buffer GC to finish before returning.

    Args:
        label: short identifier for the caller (e.g. ``"bench_harness"``,
            ``"long_running_job"``). Shown to any other process that
            attempts to acquire while you hold it.
        force: if True, terminate the existing holder (see above).
            Use only when you have independently verified that killing
            the other holder is safe.

    Returns:
        The info dict written to the lock file.

    Raises:
        MLXLockConflict: see above for the three failure modes.
    """
    # Lazy import — process_mode is a sibling submodule consulted only on
    # a lock conflict. Lazy keeps the import off the module-load path.
    from metal_guard.process_mode import is_observer

    _PROCESS_LOCK_PATH.parent.mkdir(parents=True, exist_ok=True)

    force_reclaimed = False

    if not force:
        holder = read_mlx_lock()
        if holder is not None and holder.get("pid") != os.getpid():
            if is_observer():
                # Observer mode: log a warning but do not raise or
                # overwrite. The dashboard keeps showing the original
                # holder; our "acquisition" is purely advisory, and
                # release_mlx_lock() will no-op because the lock is not
                # ours. Used after upstream MLX ships the CommandEncoder
                # thread-local fix and cross-process coordination becomes
                # advisory rather than enforced.
                log.warning(
                    "MLX lock held by %s (pid=%s) — observer mode, "
                    "continuing without blocking. Our label: %s",
                    holder.get("label", "?"),
                    holder.get("pid", "?"),
                    label,
                )
                return {
                    "pid": os.getpid(),
                    "label": label,
                    "started_at": time.strftime(
                        "%Y-%m-%dT%H:%M:%SZ", time.gmtime()
                    ),
                    "cmdline": _current_cmdline(),
                    "host": socket.gethostname(),
                    "python": sys.version.split()[0],
                    "platform": platform.system(),
                    "mode": "observer",
                    "advisory": True,
                    "actual_holder": holder,
                }
            raise MLXLockConflict(holder)
    else:
        existing = read_mlx_lock()
        force_reclaimed = (
            existing is not None and existing.get("pid") != os.getpid()
        )
        if force_reclaimed:
            _force_terminate_and_wait(existing)
            _PROCESS_LOCK_PATH.unlink(missing_ok=True)

    info: dict[str, Any] = {
        "pid": os.getpid(),
        "label": label,
        "started_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "cmdline": _current_cmdline(),
        "host": socket.gethostname(),
        "python": sys.version.split()[0],
        "platform": platform.system(),
    }
    tmp = _PROCESS_LOCK_PATH.with_suffix(f".tmp.{os.getpid()}")
    try:
        tmp.write_text(json.dumps(info, indent=2))
        os.replace(str(tmp), str(_PROCESS_LOCK_PATH))
    except OSError:
        tmp.unlink(missing_ok=True)
        raise

    log.info(
        "acquired MLX lock: label=%s pid=%d started=%s",
        label, info["pid"], info["started_at"],
    )

    # Post-reclaim cooldown — let the kernel's Metal buffer GC catch up
    # before the caller starts loading new models into the same GPU.
    if force_reclaimed and _RECLAIM_COOLDOWN_SEC > 0:
        log.info(
            "acquire_mlx_lock: post-reclaim cooldown %.1fs (Metal buffer GC)",
            _RECLAIM_COOLDOWN_SEC,
        )
        time.sleep(_RECLAIM_COOLDOWN_SEC)

    return info


def release_mlx_lock() -> bool:
    """Release the MLX lock if this process holds it.

    Returns True if a lock owned by this process was removed, False if
    no lock existed or it was held by another process. Never raises —
    release is best-effort because the process is usually exiting.
    """
    info = read_mlx_lock()
    if info is None:
        return False
    if info.get("pid") != os.getpid():
        log.warning(
            "release_mlx_lock: lock held by pid %s, not us (%d). Leaving intact.",
            info.get("pid"), os.getpid(),
        )
        return False
    _try_unlink(_PROCESS_LOCK_PATH)
    log.info("released MLX lock (pid %d)", os.getpid())
    return True


@contextmanager
def mlx_exclusive_lock(
    label: str,
    *,
    force: bool = False,
) -> Generator[dict[str, Any], None, None]:
    """Context manager: acquire on enter, always release on exit.

    See ``acquire_mlx_lock`` for ``force=True`` hardened semantics
    (SIGTERM-and-wait, never silent unlink).

    Example::

        with mlx_exclusive_lock("my_script"):
            model, tokenizer = mlx_lm.load("mlx-community/gemma-4-31b-it-8bit")
            result = mlx_lm.generate(model, tokenizer, prompt="Hello")
    """
    info = acquire_mlx_lock(label, force=force)
    try:
        yield info
    finally:
        release_mlx_lock()
