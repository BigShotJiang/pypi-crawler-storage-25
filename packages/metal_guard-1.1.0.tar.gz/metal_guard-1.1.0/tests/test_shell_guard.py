"""Part 3 — shell guard install/uninstall/status."""
from metal_guard import shell_guard


def _home(tmp_path, monkeypatch, shell="/bin/zsh"):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("SHELL", shell)


def test_install_creates_block_and_managed_file(tmp_path, monkeypatch):
    _home(tmp_path, monkeypatch)
    (tmp_path / ".zshrc").write_text("# user rc\nexport FOO=1\n", encoding="utf-8")
    r = shell_guard.install()
    assert r["action"] == "installed"
    rc = (tmp_path / ".zshrc").read_text(encoding="utf-8")
    assert "# >>> metal-guard >>>" in rc
    assert (tmp_path / ".metal-guard" / "shell-guard.zsh").exists()


def test_install_is_idempotent(tmp_path, monkeypatch):
    _home(tmp_path, monkeypatch)
    (tmp_path / ".zshrc").write_text("# rc\n", encoding="utf-8")
    shell_guard.install()
    r2 = shell_guard.install()
    assert r2["action"] == "updated"
    rc = (tmp_path / ".zshrc").read_text(encoding="utf-8")
    assert rc.count("# >>> metal-guard >>>") == 1


def test_install_then_uninstall_restores_rc(tmp_path, monkeypatch):
    _home(tmp_path, monkeypatch)
    original = "# user rc\nexport FOO=1\n"
    (tmp_path / ".zshrc").write_text(original, encoding="utf-8")
    shell_guard.install()
    shell_guard.uninstall()
    assert (tmp_path / ".zshrc").read_text(encoding="utf-8") == original
    assert not (tmp_path / ".metal-guard" / "shell-guard.zsh").exists()


def test_uninstall_on_rc_without_trailing_newline(tmp_path, monkeypatch):
    _home(tmp_path, monkeypatch)
    original = "export FOO=1"  # no trailing newline
    (tmp_path / ".zshrc").write_text(original, encoding="utf-8")
    shell_guard.install()
    shell_guard.uninstall()
    # install() normalises the rc to end with a newline (intended,
    # POSIX-standard); everything else is restored exactly.
    assert (tmp_path / ".zshrc").read_text(encoding="utf-8") == original + "\n"


def test_status_reflects_state(tmp_path, monkeypatch):
    _home(tmp_path, monkeypatch)
    (tmp_path / ".zshrc").write_text("# rc\n", encoding="utf-8")
    assert shell_guard.status()["installed"] is False
    shell_guard.install()
    assert shell_guard.status()["installed"] is True


def test_bash_shell_uses_bashrc(tmp_path, monkeypatch):
    _home(tmp_path, monkeypatch, shell="/bin/bash")
    (tmp_path / ".bashrc").write_text("# bash rc\n", encoding="utf-8")
    shell_guard.install()
    assert "# >>> metal-guard >>>" in (tmp_path / ".bashrc").read_text(encoding="utf-8")
    assert (tmp_path / ".metal-guard" / "shell-guard.sh").exists()


def test_uninstall_when_no_block_present(tmp_path, monkeypatch):
    _home(tmp_path, monkeypatch)
    (tmp_path / ".zshrc").write_text("# clean rc\n", encoding="utf-8")
    r = shell_guard.uninstall()
    assert r["action"] == "absent"
    assert (tmp_path / ".zshrc").read_text(encoding="utf-8") == "# clean rc\n"


def test_install_when_rc_absent(tmp_path, monkeypatch):
    _home(tmp_path, monkeypatch)  # no .zshrc created
    r = shell_guard.install()
    assert r["action"] == "installed"
    assert "# >>> metal-guard >>>" in (tmp_path / ".zshrc").read_text(encoding="utf-8")


def test_uninstall_is_shell_independent(tmp_path, monkeypatch):
    # Install under zsh...
    _home(tmp_path, monkeypatch, shell="/bin/zsh")
    (tmp_path / ".zshrc").write_text("# rc\n", encoding="utf-8")
    shell_guard.install()
    # ...then the user's default shell changes to bash; uninstall must
    # still clean the .zshrc block.
    monkeypatch.setenv("SHELL", "/bin/bash")
    shell_guard.uninstall()
    assert "# >>> metal-guard >>>" not in (tmp_path / ".zshrc").read_text(encoding="utf-8")
    assert not (tmp_path / ".metal-guard" / "shell-guard.zsh").exists()


def test_guard_script_has_mlx_safe_python_fallback():
    # If mlx-safe-python is not on PATH the guard must fall back to plain
    # python3 rather than break the user's interactive shell (exit 127).
    script = shell_guard._GUARD_SCRIPT
    assert "command -v mlx-safe-python" in script
    assert "command python3" in script
