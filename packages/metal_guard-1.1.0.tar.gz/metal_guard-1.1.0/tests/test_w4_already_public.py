"""W4 — verify the modules the inventory expected but that are already public.

The W4 prep analysis found `apple_feedback` and `kv_tracker` already ship
inside `panic_reports` / `prefill` (Phase 1) — porting them as new modules
would duplicate. `resource_tracker` / `process_mode` are clean forward
ports already. These tests lock those facts so a future wave does not
re-port them.
"""
import metal_guard
from metal_guard import panic_reports, prefill, process_mode, resource_tracker


def test_apple_feedback_already_public():
    """format_panic_for_apple_feedback ships via panic_reports — no W4 port."""
    assert callable(metal_guard.format_panic_for_apple_feedback)
    assert (
        metal_guard.format_panic_for_apple_feedback
        is panic_reports.format_panic_for_apple_feedback
    )


def test_kv_tracker_already_public():
    """KVGrowthTracker + kv_tracker ship via prefill — no W4 duplicate module."""
    assert isinstance(metal_guard.kv_tracker, metal_guard.KVGrowthTracker)
    assert metal_guard.KVGrowthTracker is prefill.KVGrowthTracker


def test_resource_tracker_no_harper_strings():
    """Public resource_tracker is a clean forward port — no Harper project names."""
    text = open(resource_tracker.__file__, encoding="utf-8").read()
    assert "consensus_ocr" not in text
    assert "fugan" not in text


def test_process_mode_subprocess_worker_env_canonical():
    """Phase 1 renamed the env var into the METALGUARD_ namespace."""
    assert process_mode._SUBPROCESS_WORKER_ENV == "METALGUARD_SUBPROCESS_WORKER"


def test_check_observer_requirements_public_api():
    """W4 observer gate is reachable from the package facade."""
    assert callable(metal_guard.check_observer_requirements)
