"""W7 — metal_guard.worker_rotation."""
from datetime import datetime, timezone

import pytest

from metal_guard import prefill_exposure_tracker as pet
from metal_guard import worker_rotation
from metal_guard.worker_rotation import (
    REASON_DISABLED,
    REASON_NO_STATE,
    REASON_PREFILL_BUDGET_EXCEEDED,
    REASON_UNDER_BUDGET,
    RotationVerdict,
    should_rotate_worker,
)

_T0 = datetime(2026, 5, 18, 12, 0, 0, tzinfo=timezone.utc)
_T1 = datetime(2026, 5, 18, 13, 0, 0, tzinfo=timezone.utc)


@pytest.fixture(autouse=True)
def _isolate(monkeypatch):
    monkeypatch.setenv("METALGUARD_PANIC_CORPUS_DISABLED", "1")
    monkeypatch.delenv("METALGUARD_WORKER_ROTATION_DISABLED", raising=False)
    monkeypatch.delenv("METALGUARD_PREFILL_BUDGET_TOKENS", raising=False)
    monkeypatch.delenv("METALGUARD_PREFILL_EXPOSURE_DISABLED", raising=False)
    pet.reset_all()
    yield
    pet.reset_all()


def test_disabled_env_no_rotate(monkeypatch):
    monkeypatch.setenv("METALGUARD_WORKER_ROTATION_DISABLED", "1")
    v = should_rotate_worker(worker_pid=100, worker_started_at=_T0)
    assert v.should_rotate is False
    assert v.reason == REASON_DISABLED


def test_no_state_no_rotate():
    v = should_rotate_worker(worker_pid=999, worker_started_at=_T0)
    assert v.should_rotate is False
    assert v.reason == REASON_NO_STATE


def test_under_budget_no_rotate():
    pet.record_prefill(worker_pid=100, worker_started_at=_T0, prefill_tokens=10_000)
    v = should_rotate_worker(worker_pid=100, worker_started_at=_T0)
    assert v.should_rotate is False
    assert v.reason == REASON_UNDER_BUDGET


def test_over_budget_recommends_rotation():
    pet.record_prefill(worker_pid=100, worker_started_at=_T0, prefill_tokens=60_000)
    v = should_rotate_worker(worker_pid=100, worker_started_at=_T0)
    assert v.should_rotate is True
    assert v.reason == REASON_PREFILL_BUDGET_EXCEEDED
    assert v.cumulative_tokens == 60_000
    assert v.threshold == 50_000


def test_budget_env_override(monkeypatch):
    monkeypatch.setenv("METALGUARD_PREFILL_BUDGET_TOKENS", "5000")
    pet.record_prefill(worker_pid=100, worker_started_at=_T0, prefill_tokens=8000)
    v = should_rotate_worker(worker_pid=100, worker_started_at=_T0)
    assert v.should_rotate is True
    assert v.threshold == 5000


def test_pid_recycle_no_state():
    pet.record_prefill(worker_pid=100, worker_started_at=_T0, prefill_tokens=60_000)
    v = should_rotate_worker(worker_pid=100, worker_started_at=_T1)
    assert v.should_rotate is False
    assert v.reason == REASON_NO_STATE  # generation mismatch


def test_naive_datetime_rejected():
    with pytest.raises(ValueError):
        should_rotate_worker(worker_pid=100, worker_started_at=datetime(2026, 5, 18))


def test_verdict_is_frozen():
    v = should_rotate_worker(worker_pid=999, worker_started_at=_T0)
    assert isinstance(v, RotationVerdict)
    with pytest.raises(Exception):
        v.should_rotate = True  # type: ignore[misc]


def test_reason_constants_stable():
    assert REASON_DISABLED == "disabled"
    assert REASON_NO_STATE == "no_state"
    assert REASON_UNDER_BUDGET == "under_budget"
    assert REASON_PREFILL_BUDGET_EXCEEDED == "prefill_budget_exceeded"


def test_module_no_harper_coupling():
    src = open(worker_rotation.__file__, encoding="utf-8").read()
    assert "mlx_client" not in src
    assert ".harper" not in src
    assert "~/.claude" not in src
