"""Tests for metal_guard.model_cache (W5 port)."""
from __future__ import annotations

import metal_guard.model_cache as model_cache_mod
from metal_guard.model_cache import (
    ModelCache,
    _model_cache,
    get_mlx_model,
    get_mlx_vlm_model,
    unload_all,
    flush_kv_cache,
    check_metal_pressure,
)


def _fresh_cache() -> ModelCache:
    """Return a fresh, isolated ModelCache for each test."""
    return ModelCache()


# ── Cache get/set ─────────────────────────────────────────────────────────────


def test_cache_get_set_text():
    cache = _fresh_cache()
    assert cache.get_text("model/x") is None
    cache.set_text("model/x", ("model", "tokenizer"))
    assert cache.get_text("model/x") == ("model", "tokenizer")


def test_cache_get_set_vision():
    cache = _fresh_cache()
    assert cache.get_vision("vlm/y") is None
    cache.set_vision("vlm/y", ("vmodel", "vproc"))
    assert cache.get_vision("vlm/y") == ("vmodel", "vproc")


# ── clear() behaviour ─────────────────────────────────────────────────────────


def test_clear_empty_short_circuits():
    cache = _fresh_cache()
    # Must not raise even when both dicts are empty
    cache.clear()


def test_clear_with_models():
    cache = _fresh_cache()
    cache.set_text("model/a", ("m", "t"))
    cache.clear()
    assert cache.get_text("model/a") is None


# ── get_mlx_model / get_mlx_vlm_model cache-hit paths ────────────────────────


def test_get_mlx_model_cache_hit(monkeypatch):
    """get_mlx_model returns cached tuple without calling mlx_lm.load."""
    sentinel = ("cached_model", "cached_tokenizer")
    # Inject directly into the module-level singleton's _text dict
    monkeypatch.setitem(_model_cache._text, "text/cached", sentinel)
    result = get_mlx_model("text/cached")
    assert result is sentinel


def test_get_mlx_vlm_model_cache_hit(monkeypatch):
    """get_mlx_vlm_model returns cached tuple without calling mlx_vlm.load."""
    sentinel = ("vlm_model", "vlm_processor")
    monkeypatch.setitem(_model_cache._vision, "vlm/cached", sentinel)
    result = get_mlx_vlm_model("vlm/cached")
    assert result is sentinel


# ── Public cleanup helpers ────────────────────────────────────────────────────


def test_unload_all_runs():
    """unload_all() completes without raising."""
    unload_all()


def test_flush_kv_cache_runs():
    """flush_kv_cache() completes without raising."""
    flush_kv_cache()


def test_check_metal_pressure_runs():
    """check_metal_pressure() completes without raising."""
    check_metal_pressure()


# ── Provenance guard ──────────────────────────────────────────────────────────


def test_module_no_harper_strings():
    """Ported module must contain no harper-finance or mlx_client references."""
    with open(model_cache_mod.__file__, encoding="utf-8") as fh:
        source = fh.read()
    assert "harper-finance" not in source, "harper-finance found in model_cache source"
    assert "mlx_client" not in source, "mlx_client found in model_cache source"
