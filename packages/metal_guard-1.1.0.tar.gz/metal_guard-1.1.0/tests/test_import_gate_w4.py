"""W4 tests for metal_guard.import_gate."""
from __future__ import annotations

import sys
import os
import pytest


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def restore_meta_path():
    """Ensure sys.meta_path is restored after each test."""
    original = list(sys.meta_path)
    yield
    sys.meta_path[:] = original


@pytest.fixture(autouse=True)
def clean_env(monkeypatch):
    """Remove gate env vars so tests start from a clean env."""
    for var in (
        "MLX_IMPORT_GATE_DISABLED",
        "MLX_IMPORT_GATE_MODE",
        "MLX_IMPORT_GATE_ALLOW",
        "MLX_IMPORT_GATE_WHITELIST",
    ):
        monkeypatch.delenv(var, raising=False)


# ---------------------------------------------------------------------------
# Helpers — import names from the ported module
# ---------------------------------------------------------------------------

from metal_guard.import_gate import (
    WATCHED_PREFIXES,
    ImportGateBlocked,
    _decide,
    _cooldown_active,
    install,
    uninstall,
)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_watched_prefixes_frozenset():
    assert isinstance(WATCHED_PREFIXES, frozenset)
    assert "torch" in WATCHED_PREFIXES
    assert "mlx" in WATCHED_PREFIXES


def test_decide_mode_off():
    blocked, msg = _decide(
        "torch",
        mode="off",
        allow=False,
        cooldown_on=True,
        cooldown_reason="test cooldown",
    )
    assert not blocked


def test_decide_warn_during_cooldown():
    blocked, msg = _decide(
        "mlx",
        mode="warn",
        allow=False,
        cooldown_on=True,
        cooldown_reason="72h lockout",
    )
    assert not blocked
    assert "WARN" in msg


def test_decide_block_during_cooldown():
    blocked, msg = _decide(
        "torch",
        mode="block",
        allow=False,
        cooldown_on=True,
        cooldown_reason="72h lockout",
    )
    assert blocked
    assert "BLOCK" in msg


def test_decide_no_cooldown():
    for mode in ("warn", "block"):
        blocked, msg = _decide(
            "torch",
            mode=mode,
            allow=False,
            cooldown_on=False,
            cooldown_reason="no panic",
        )
        assert not blocked, f"mode={mode} should not block when cooldown inactive"


def test_install_idempotent():
    result1 = install()
    assert result1 is True

    result2 = install()
    assert not result2  # falsey on second install

    from metal_guard.import_gate import _ImportGateFinder
    finders = [f for f in sys.meta_path if isinstance(f, _ImportGateFinder)]
    assert len(finders) == 1


def test_uninstall():
    install()
    from metal_guard.import_gate import _ImportGateFinder
    assert any(isinstance(f, _ImportGateFinder) for f in sys.meta_path)

    removed = uninstall()
    assert removed >= 1
    assert not any(isinstance(f, _ImportGateFinder) for f in sys.meta_path)


def test_install_disabled_env(monkeypatch):
    monkeypatch.setenv("MLX_IMPORT_GATE_DISABLED", "1")
    result = install()
    assert not result  # no-op

    from metal_guard.import_gate import _ImportGateFinder
    assert not any(isinstance(f, _ImportGateFinder) for f in sys.meta_path)


def test_cooldown_active_rebind(monkeypatch):
    """monkeypatch evaluate_panic_cooldown to return exit_code=2 → active."""
    import metal_guard.panic_gate as pg

    class _FakeVerdict:
        exit_code = 2
        reason = "mocked lockout"

    monkeypatch.setattr(pg, "evaluate_panic_cooldown", lambda: _FakeVerdict())

    active, reason = _cooldown_active()
    assert active is True


def test_cooldown_active_fail_open(monkeypatch):
    """If panic_gate import raises, _cooldown_active returns not-active (fail-open)."""
    import metal_guard.import_gate as ig

    def _raise():
        raise RuntimeError("simulated import failure")

    # Patch the lazy import inside _cooldown_active by making the module
    # raise when evaluate_panic_cooldown is accessed.
    import metal_guard.panic_gate as pg
    monkeypatch.setattr(pg, "evaluate_panic_cooldown", _raise)

    active, reason = _cooldown_active()
    assert not active  # fail-open


def test_import_gate_blocked_is_import_error():
    assert isinstance(ImportGateBlocked("x"), ImportError)
