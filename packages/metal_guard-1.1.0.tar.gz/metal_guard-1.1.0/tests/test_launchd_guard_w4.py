"""W4 — launchd_guard submodule port tests."""
from __future__ import annotations

import json
import os
import subprocess
from datetime import datetime, timedelta
from pathlib import Path

import pytest

from metal_guard import launchd_guard
from metal_guard.launchd_guard import (
    _DEFAULT_CRASH_DIR,
    _GUARD_DISABLED_ENV,
    LaunchdContext,
    KeepAliveVerdict,
    auto_record_on_failure,
    check_keepalive_guard,
    daemon_guard,
    detect_launchd_context,
    record_crash,
    request_self_bootout,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _override_crash_dir(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Point the crash dir at a tmp path via the env override."""
    crash_dir = tmp_path / "launchd_crashes"
    crash_dir.mkdir()
    monkeypatch.setenv(launchd_guard._CRASH_DIR_ENV, str(crash_dir))
    return crash_dir


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_detect_no_launchd(monkeypatch):
    """No launchd env vars → context reports not-under-launchd."""
    monkeypatch.delenv("XPC_SERVICE_NAME", raising=False)
    ctx = detect_launchd_context()
    assert isinstance(ctx, LaunchdContext)
    assert ctx.running_under_launchd is False
    assert ctx.label is None


def test_detect_xpc_service(monkeypatch):
    """XPC_SERVICE_NAME set → context reports under-launchd with label captured."""
    monkeypatch.setenv("XPC_SERVICE_NAME", "com.example.d")
    ctx = detect_launchd_context()
    assert ctx.running_under_launchd is True
    assert ctx.label == "com.example.d"


def test_record_crash_no_label(monkeypatch, tmp_path):
    """No label and no XPC env → returns falsey, no file written."""
    monkeypatch.delenv("XPC_SERVICE_NAME", raising=False)
    _override_crash_dir(tmp_path, monkeypatch)
    result = record_crash()  # no label arg, no XPC env
    assert not result
    assert list(tmp_path.glob("**/*.jsonl")) == []


def test_record_crash_writes_file(monkeypatch, tmp_path):
    """crash dir → tmp, label given → a JSONL line is written."""
    _override_crash_dir(tmp_path, monkeypatch)
    monkeypatch.delenv("XPC_SERVICE_NAME", raising=False)
    ok = record_crash(label="com.example.test-daemon", reason="test crash")
    assert ok is True
    files = list(tmp_path.glob("**/*.jsonl"))
    assert len(files) == 1
    line = files[0].read_text().strip()
    rec = json.loads(line)
    assert rec["label"] == "com.example.test-daemon"
    assert rec["reason"] == "test crash"
    assert "ts" in rec


def test_record_crash_disabled_env(monkeypatch, tmp_path):
    """The module's disable env var set → record_crash no-ops."""
    _override_crash_dir(tmp_path, monkeypatch)
    monkeypatch.setenv(_GUARD_DISABLED_ENV, "1")
    result = record_crash(label="com.example.daemon")
    assert not result
    assert list(tmp_path.glob("**/*.jsonl")) == []


def test_keepalive_below_threshold(monkeypatch, tmp_path):
    """2 recorded crashes, threshold 3 → guard does not advise self-bootout."""
    _override_crash_dir(tmp_path, monkeypatch)
    monkeypatch.delenv("XPC_SERVICE_NAME", raising=False)
    label = "com.example.below"
    now = datetime.now()
    # write 2 crashes within the window
    for i in range(2):
        record_crash(label=label, reason=f"crash {i}", now=now - timedelta(seconds=i))
    verdict = check_keepalive_guard(label=label, threshold=3, window_sec=300.0, now=now)
    assert isinstance(verdict, KeepAliveVerdict)
    assert verdict.should_self_bootout is False
    assert verdict.recent_crashes == 2


def test_keepalive_at_threshold(monkeypatch, tmp_path):
    """3 crashes within the window → guard advises self-bootout."""
    _override_crash_dir(tmp_path, monkeypatch)
    monkeypatch.delenv("XPC_SERVICE_NAME", raising=False)
    label = "com.example.at-threshold"
    now = datetime.now()
    for i in range(3):
        record_crash(label=label, reason=f"crash {i}", now=now - timedelta(seconds=i * 10))
    verdict = check_keepalive_guard(label=label, threshold=3, window_sec=300.0, now=now)
    assert verdict.should_self_bootout is True
    assert verdict.recent_crashes >= 3


def test_keepalive_outside_window(monkeypatch, tmp_path):
    """3 crashes all older than the window → no self-bootout."""
    _override_crash_dir(tmp_path, monkeypatch)
    monkeypatch.delenv("XPC_SERVICE_NAME", raising=False)
    label = "com.example.old-crashes"
    now = datetime.now()
    # write crashes that are 600+ seconds old, outside a 300s window
    for i in range(3):
        record_crash(label=label, reason=f"crash {i}",
                     now=now - timedelta(seconds=600 + i * 10))
    verdict = check_keepalive_guard(label=label, threshold=3, window_sec=300.0, now=now)
    assert verdict.should_self_bootout is False
    assert verdict.recent_crashes == 0


def test_auto_record_success(monkeypatch, tmp_path):
    """auto_record_on_failure context body raises nothing → no crash file."""
    _override_crash_dir(tmp_path, monkeypatch)
    monkeypatch.delenv("XPC_SERVICE_NAME", raising=False)
    with auto_record_on_failure(label="com.example.ok"):
        pass  # no exception
    assert list(tmp_path.glob("**/*.jsonl")) == []


def test_auto_record_exception(monkeypatch, tmp_path):
    """Body raises RuntimeError → crash recorded AND exception re-raised."""
    _override_crash_dir(tmp_path, monkeypatch)
    monkeypatch.delenv("XPC_SERVICE_NAME", raising=False)
    with pytest.raises(RuntimeError, match="boom"):
        with auto_record_on_failure(label="com.example.fail"):
            raise RuntimeError("boom")
    files = list(tmp_path.glob("**/*.jsonl"))
    assert len(files) == 1
    rec = json.loads(files[0].read_text().strip())
    assert "RuntimeError" in rec["reason"]


def test_request_self_bootout_ok(monkeypatch):
    """monkeypatch subprocess.run → rc 0 → returns True."""
    import metal_guard.launchd_guard as lg

    class _FakeResult:
        returncode = 0
        stderr = ""

    monkeypatch.setattr(lg.subprocess, "run", lambda *a, **kw: _FakeResult())
    assert request_self_bootout("com.example.daemon") is True


def test_request_self_bootout_fail(monkeypatch):
    """subprocess.run → rc≠0 → returns False, no raise."""
    import metal_guard.launchd_guard as lg

    class _FakeResult:
        returncode = 1
        stderr = "error"

    monkeypatch.setattr(lg.subprocess, "run", lambda *a, **kw: _FakeResult())
    result = request_self_bootout("com.example.daemon")
    assert result is False


def test_default_crash_dir_neutral():
    """_DEFAULT_CRASH_DIR does not contain 'harper'."""
    assert "harper" not in _DEFAULT_CRASH_DIR
