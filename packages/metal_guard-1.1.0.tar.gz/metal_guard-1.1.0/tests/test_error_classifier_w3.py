"""W3 — regression lock for the iogpu_remove_memory_object signature port."""
from metal_guard import classify_mlx_error, is_kernel_panic_signature


_REMOVE_OBJ_PANIC = (
    "panic(cpu 5): IOGPUGroupMemory::remove_memory_object — memory object "
    "not found in group during teardown @IOGPUGroupMemory.cpp"
)


def test_remove_memory_object_classified_kernel_panic():
    cls = classify_mlx_error(_REMOVE_OBJ_PANIC)
    assert cls is not None
    assert cls.name == "iogpu_remove_memory_object"
    assert cls.severity == "kernel_panic"
    assert cls.recovery_hint == "wait_lockout"
    assert "ml-explore/mlx#3186" in cls.upstream_refs


def test_remove_memory_object_is_kernel_panic_signature():
    assert is_kernel_panic_signature(_REMOVE_OBJ_PANIC) is True


def test_remove_memory_object_alt_phrasing():
    alt = "IOGPUGroupMemory.cpp: memory object not found"
    cls = classify_mlx_error(alt)
    assert cls is not None and cls.name == "iogpu_remove_memory_object"
