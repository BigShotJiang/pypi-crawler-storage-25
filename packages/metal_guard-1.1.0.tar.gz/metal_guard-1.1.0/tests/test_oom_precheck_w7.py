"""W7 — metal_guard.oom_precheck."""
import pytest

from metal_guard import oom_precheck
from metal_guard.memory import MetalOOMError
from metal_guard.oom_precheck import OOMVerdict, precheck_inference, precheck_inference_or_raise


@pytest.fixture(autouse=True)
def _isolate(monkeypatch):
    monkeypatch.setenv("METALGUARD_PANIC_CORPUS_DISABLED", "1")
    monkeypatch.delenv("METALGUARD_OOM_PRECHECK_DISABLED", raising=False)


def test_returns_oom_verdict():
    v = precheck_inference(model_id="gemma-4-31b-it-8bit", context_tokens=1000, available_gb=64.0)
    assert isinstance(v, OOMVerdict)


def test_safe_small_context_known_model():
    v = precheck_inference(model_id="gemma-4-31b-it-8bit", context_tokens=2000, available_gb=64.0)
    assert v.safe is True


def test_long_context_hard_block():
    v = precheck_inference(model_id="gemma-4-31b-it-8bit", context_tokens=250_000, available_gb=64.0)
    assert v.safe is False
    assert "hard block" in v.blocker


def test_long_context_warn_advisory():
    v = precheck_inference(model_id="gemma-4-31b-it-8bit", context_tokens=120_000, available_gb=512.0)
    assert any(aid == "W_long_context" for aid, _ in v.advisories)


def test_unknown_model_safe_with_advisory():
    v = precheck_inference(model_id="nobody/unknown-model", context_tokens=1000, available_gb=64.0)
    assert v.safe is True
    assert any(aid == "W_unknown_model_dims" for aid, _ in v.advisories)


def test_single_alloc_ceiling_block():
    v = precheck_inference(model_id="gemma-4-31b-it-8bit", context_tokens=180_000, available_gb=512.0)
    assert v.safe is False
    assert "single-alloc ceiling" in v.blocker


def test_headroom_block():
    """Small context (peak under the 5GB ceiling) but available memory too low."""
    v = precheck_inference(model_id="gemma-4-31b-it-8bit", context_tokens=2000, available_gb=2.0)
    assert v.safe is False
    assert "single-alloc ceiling" not in v.blocker  # this is the headroom path


def test_disabled_env_always_safe(monkeypatch):
    monkeypatch.setenv("METALGUARD_OOM_PRECHECK_DISABLED", "1")
    v = precheck_inference(model_id="gemma-4-31b-it-8bit", context_tokens=250_000, available_gb=1.0)
    assert v.safe is True


def test_precheck_or_raise_passes():
    v = precheck_inference_or_raise(model_id="gemma-4-31b-it-8bit", context_tokens=2000, available_gb=64.0)
    assert v.safe is True


def test_precheck_or_raise_raises_on_block():
    with pytest.raises(MetalOOMError):
        precheck_inference_or_raise(
            model_id="gemma-4-31b-it-8bit", context_tokens=250_000, available_gb=64.0,
        )


def test_module_no_harper_coupling():
    src = open(oom_precheck.__file__, encoding="utf-8").read()
    assert "mlx_client" not in src
    assert ".harper" not in src
    assert "~/.claude" not in src
