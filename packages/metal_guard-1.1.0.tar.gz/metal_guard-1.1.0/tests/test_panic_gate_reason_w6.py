"""W6 — mark_panic_sentinel_cooldown reason kwarg (0-BC additive extension)."""
import json

from metal_guard import panic_gate


def test_reason_persisted_as_third_key(monkeypatch, tmp_path):
    path = tmp_path / "panic-sentinel.json"
    monkeypatch.setattr(panic_gate, "_PANIC_SENTINEL_PATH", str(path))
    panic_gate.mark_panic_sentinel_cooldown(2.0, reason="recovery_lockout_third_strike")
    data = json.loads(path.read_text(encoding="utf-8"))
    assert data["reason"] == "recovery_lockout_third_strike"
    assert "cooldown_until" in data and "created_at" in data


def test_reason_omitted_keeps_two_key_payload(monkeypatch, tmp_path):
    """0-BC: reason=None keeps the original 2-key shape for pre-W6 readers."""
    path = tmp_path / "panic-sentinel.json"
    monkeypatch.setattr(panic_gate, "_PANIC_SENTINEL_PATH", str(path))
    panic_gate.mark_panic_sentinel_cooldown(2.0)
    data = json.loads(path.read_text(encoding="utf-8"))
    assert set(data.keys()) == {"cooldown_until", "created_at"}


def test_reader_unaffected_by_reason_key(monkeypatch, tmp_path):
    """evaluate_panic_cooldown still treats a 3-key sentinel as an active cooldown."""
    path = tmp_path / "panic-sentinel.json"
    monkeypatch.setattr(panic_gate, "_PANIC_SENTINEL_PATH", str(path))
    monkeypatch.delenv("METALGUARD_PANIC_GATE_DISABLED", raising=False)
    panic_gate.mark_panic_sentinel_cooldown(2.0, reason="third_strike")
    verdict = panic_gate.evaluate_panic_cooldown()
    assert verdict.exit_code == 2
    assert "sentinel cooldown" in verdict.reason
