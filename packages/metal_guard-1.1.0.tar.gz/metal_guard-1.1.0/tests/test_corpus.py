"""W3 — metal_guard.corpus append-only JSONL event log."""
from metal_guard import corpus


def _patch_path(monkeypatch, tmp_path):
    """Point the corpus at a tmp file and ensure it is enabled."""
    monkeypatch.setattr(corpus, "DEFAULT_CORPUS_PATH", str(tmp_path / "events.jsonl"))
    monkeypatch.delenv("METALGUARD_PANIC_CORPUS_PATH", raising=False)
    monkeypatch.delenv("METALGUARD_PANIC_CORPUS_DISABLED", raising=False)


def test_append_then_iter_roundtrip(monkeypatch, tmp_path):
    _patch_path(monkeypatch, tmp_path)
    assert corpus.append_event("panic_observed", model_id="m/x", tier="panic") is True
    events = list(corpus.iter_events())
    assert len(events) == 1
    assert events[0]["event"] == "panic_observed"
    assert events[0]["model_id"] == "m/x"
    assert events[0]["tier"] == "panic"
    assert "ts" in events[0]


def test_append_rejects_empty_event(monkeypatch, tmp_path):
    _patch_path(monkeypatch, tmp_path)
    assert corpus.append_event("") is False
    assert corpus.append_event(None) is False  # type: ignore[arg-type]


def test_disabled_env_suppresses_write(monkeypatch, tmp_path):
    _patch_path(monkeypatch, tmp_path)
    monkeypatch.setenv("METALGUARD_PANIC_CORPUS_DISABLED", "1")
    assert corpus.append_event("panic_observed") is False
    assert list(corpus.iter_events()) == []


def test_path_env_override(monkeypatch, tmp_path):
    _patch_path(monkeypatch, tmp_path)
    override = tmp_path / "sub" / "other.jsonl"
    monkeypatch.setenv("METALGUARD_PANIC_CORPUS_PATH", str(override))
    assert corpus.append_event("spawn_refused") is True
    assert override.exists()


def test_emit_event_alias(monkeypatch, tmp_path):
    _patch_path(monkeypatch, tmp_path)
    assert corpus.emit_event(event_kind="load_gate_refused", payload={"k": 1}) is True
    events = list(corpus.iter_events())
    assert events[0]["event"] == "load_gate_refused"
    assert events[0]["extra"] == {"k": 1}


def test_count_events(monkeypatch, tmp_path):
    _patch_path(monkeypatch, tmp_path)
    corpus.append_event("panic_observed")
    corpus.append_event("panic_observed")
    corpus.append_event("spawn_refused")
    assert corpus.count_events() == 3
    assert corpus.count_events(event="panic_observed") == 2


def test_iter_skips_malformed_lines(monkeypatch, tmp_path):
    _patch_path(monkeypatch, tmp_path)
    corpus.append_event("panic_observed")
    path = tmp_path / "events.jsonl"
    with open(path, "a", encoding="utf-8") as f:
        f.write("this is not json\n")
        f.write('{"event": "spawn_refused", "ts": "2026-05-18T00:00:00"}\n')
    events = list(corpus.iter_events())
    assert [e["event"] for e in events] == ["panic_observed", "spawn_refused"]


def test_append_non_serialisable_extra_degrades(monkeypatch, tmp_path):
    _patch_path(monkeypatch, tmp_path)
    assert corpus.append_event("panic_observed", extra={"obj": object()}) is True
    events = list(corpus.iter_events())
    assert len(events) == 1  # repr() fallback kept the corpus open


def test_event_kinds_is_frozenset():
    assert isinstance(corpus.EVENT_KINDS, frozenset)
    assert "panic_observed" in corpus.EVENT_KINDS
    assert "fallback_attempted" in corpus.EVENT_KINDS


def test_event_kinds_includes_lora_display_advisory():
    assert "lora_display_advisory" in corpus.EVENT_KINDS


def test_default_path_is_neutral():
    """Public corpus must NOT default to a ~/.harper path."""
    assert ".harper" not in corpus.DEFAULT_CORPUS_PATH
    assert "metal-guard" in corpus.DEFAULT_CORPUS_PATH
