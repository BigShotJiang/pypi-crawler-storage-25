"""W10 — lock reconcile: observer mode, info-dict diagnostics, helpers.

Pure stdlib lock logic — these tests never import mlx.core or touch Metal.
The lock file is redirected to a tmp_path via the _isolated_lock fixture.
"""

import json
import os
import subprocess
import sys
import textwrap
import time

import pytest

from metal_guard import mlx_lock
from metal_guard.mlx_lock import (
    MLXLockConflict,
    acquire_mlx_lock,
    mlx_exclusive_lock,
    read_mlx_lock,
    release_mlx_lock,
)


@pytest.fixture(autouse=True)
def _isolated_lock(tmp_path, monkeypatch):
    """Redirect the lock file to a tmp path so tests never collide with a
    real MLX workload on the dev machine or with each other."""
    fake_lock = tmp_path / "mlx_exclusive.lock"
    monkeypatch.setattr(mlx_lock, "_PROCESS_LOCK_PATH", fake_lock)
    yield fake_lock
    if fake_lock.exists():
        fake_lock.unlink()


# ── Task 2: internal helpers ────────────────────────────────────────────


def test_format_elapsed_empty_returns_unknown():
    assert mlx_lock._format_elapsed("") == "unknown"


def test_format_elapsed_garbage_echoes_input():
    assert mlx_lock._format_elapsed("not a date") == "not a date"


def test_format_elapsed_seconds_minutes_hours():
    from datetime import datetime, timedelta, timezone

    def _iso(delta):
        return (datetime.now(timezone.utc) - delta).strftime(
            "%Y-%m-%dT%H:%M:%SZ"
        )

    assert mlx_lock._format_elapsed(_iso(timedelta(seconds=5))).endswith("s")
    minutes = mlx_lock._format_elapsed(_iso(timedelta(minutes=3)))
    assert "m" in minutes and "s" in minutes
    hours = mlx_lock._format_elapsed(_iso(timedelta(hours=2)))
    assert "h" in hours and "m" in hours


def test_current_cmdline_returns_basenamed_string():
    cmdline = mlx_lock._current_cmdline()
    assert isinstance(cmdline, str)
    assert cmdline  # non-empty
    assert len(cmdline) <= 300
    # argv[0] must be basenamed — no directory separator in the first token.
    assert "/" not in cmdline.split(" ")[0]


def test_try_unlink_missing_file_does_not_raise(tmp_path):
    ghost = tmp_path / "does_not_exist.lock"
    # Must not raise even though the file is absent.
    mlx_lock._try_unlink(ghost)


def test_try_unlink_removes_existing_file(tmp_path):
    victim = tmp_path / "victim.lock"
    victim.write_text("x")
    mlx_lock._try_unlink(victim)
    assert not victim.exists()


# ── Task 3: info-dict diagnostic keys ───────────────────────────────────


def test_acquire_writes_diagnostic_keys():
    info = acquire_mlx_lock("diag_test")
    try:
        assert info["label"] == "diag_test"
        assert info["pid"] == os.getpid()
        assert info["host"]      # socket.gethostname() — non-empty
        assert info["python"]    # e.g. "3.14.4"
        assert info["platform"]  # e.g. "Darwin"
        # cmdline went through _current_cmdline — argv[0] basenamed.
        assert "/" not in info["cmdline"].split(" ")[0]
        on_disk = read_mlx_lock()
        assert on_disk is not None
        assert on_disk["host"] == info["host"]
        assert on_disk["python"] == info["python"]
        assert on_disk["platform"] == info["platform"]
    finally:
        release_mlx_lock()


def test_acquire_logs_success(caplog):
    with caplog.at_level("INFO", logger="metal_guard"):
        acquire_mlx_lock("log_test")
    try:
        assert any(
            "acquired MLX lock" in r.getMessage() for r in caplog.records
        )
    finally:
        release_mlx_lock()


# ── Task 4: conflict message ────────────────────────────────────────────


def test_conflict_message_uses_running_for(_isolated_lock):
    other = {
        "pid": 1,  # init — always alive on Unix
        "label": "other_process",
        "started_at": "2026-04-10T00:00:00Z",
        "cmdline": "init",
    }
    _isolated_lock.write_text(json.dumps(other))
    with pytest.raises(MLXLockConflict) as exc_info:
        acquire_mlx_lock("me")
    msg = str(exc_info.value)
    assert "MLX lock held by other_process" in msg
    assert "running for" in msg
    assert exc_info.value.holder["label"] == "other_process"


# ── Task 5: granular logging ────────────────────────────────────────────


def test_read_logs_warning_on_corrupt_lock(_isolated_lock, caplog):
    _isolated_lock.write_text("not json at all {{{")
    with caplog.at_level("WARNING", logger="metal_guard"):
        assert read_mlx_lock() is None
    assert not _isolated_lock.exists()
    assert any("corrupt lock file" in r.getMessage() for r in caplog.records)


def test_read_logs_warning_on_missing_pid(_isolated_lock, caplog):
    _isolated_lock.write_text(json.dumps({"label": "no_pid"}))
    with caplog.at_level("WARNING", logger="metal_guard"):
        assert read_mlx_lock() is None
    assert not _isolated_lock.exists()
    assert any("missing pid" in r.getMessage() for r in caplog.records)


def test_read_logs_info_on_stale_reclaim(_isolated_lock, caplog):
    stale = {
        "pid": 2147483646,  # positive, almost certainly dead
        "label": "dead_process",
        "started_at": "2026-04-10T00:00:00Z",
        "cmdline": "ghost",
    }
    _isolated_lock.write_text(json.dumps(stale))
    with caplog.at_level("INFO", logger="metal_guard"):
        assert read_mlx_lock() is None
    assert not _isolated_lock.exists()
    assert any("stale lock" in r.getMessage() for r in caplog.records)


def test_release_logs_warning_when_not_ours(_isolated_lock, caplog):
    foreign = {
        "pid": 1,  # init — alive but not us
        "label": "foreign_holder",
        "started_at": "2026-04-10T00:00:00Z",
        "cmdline": "init",
    }
    _isolated_lock.write_text(json.dumps(foreign))
    with caplog.at_level("WARNING", logger="metal_guard"):
        assert release_mlx_lock() is False
    assert _isolated_lock.exists()  # not our lock — left intact
    assert any("not us" in r.getMessage() for r in caplog.records)


def test_release_logs_info_on_success(caplog):
    acquire_mlx_lock("release_log_test")
    with caplog.at_level("INFO", logger="metal_guard"):
        assert release_mlx_lock() is True
    assert any("released MLX lock" in r.getMessage() for r in caplog.records)


# ── Task 6: observer mode ───────────────────────────────────────────────


def _mock_observer_versions_ok(monkeypatch):
    """Stub process_mode._installed_versions so the observer version gate
    passes regardless of what mlx / mlx-lm are actually installed (the
    public metal-guard test env may have neither)."""
    from metal_guard import process_mode
    monkeypatch.setattr(
        process_mode, "_installed_versions",
        lambda: {"mlx": "0.31.2", "mlx-lm": "0.31.3"},
    )


def test_observer_mode_conflict_does_not_raise(_isolated_lock, monkeypatch):
    other = {
        "pid": 1,  # init — always alive on Unix
        "label": "other_process",
        "started_at": "2026-04-10T00:00:00Z",
        "cmdline": "init",
    }
    _isolated_lock.write_text(json.dumps(other))
    monkeypatch.setenv("METALGUARD_MODE", "observer")
    _mock_observer_versions_ok(monkeypatch)

    info = acquire_mlx_lock("me")
    assert info["label"] == "me"
    assert info["mode"] == "observer"
    assert info["advisory"] is True
    assert info["actual_holder"]["label"] == "other_process"
    # Observer "acquisition" is advisory — it carries the same diagnostic
    # keys a real acquire writes.
    assert info["host"] and info["python"] and info["platform"]

    # The lock file still belongs to the original holder — not overwritten.
    current = read_mlx_lock()
    assert current is not None
    assert current["label"] == "other_process"


def test_observer_mode_release_is_noop(_isolated_lock, monkeypatch):
    other = {
        "pid": 1,
        "label": "other_process",
        "started_at": "2026-04-10T00:00:00Z",
        "cmdline": "init",
    }
    _isolated_lock.write_text(json.dumps(other))
    monkeypatch.setenv("METALGUARD_MODE", "observer")
    _mock_observer_versions_ok(monkeypatch)

    acquire_mlx_lock("me")  # advisory — lock isn't ours
    # release must no-op: the lock belongs to pid 1, not us.
    assert release_mlx_lock() is False
    assert _isolated_lock.exists()


def test_defensive_mode_still_raises_on_conflict(_isolated_lock, monkeypatch):
    """Regression guard — default (defensive) mode must still raise."""
    monkeypatch.delenv("METALGUARD_MODE", raising=False)
    other = {
        "pid": 1,
        "label": "defender_test",
        "started_at": "2026-04-10T00:00:00Z",
        "cmdline": "init",
    }
    _isolated_lock.write_text(json.dumps(other))
    with pytest.raises(MLXLockConflict):
        acquire_mlx_lock("me")


def test_observer_mode_no_conflict_acquires_normally(_isolated_lock, monkeypatch):
    """Observer mode with a FREE lock acquires for real (no advisory dict)."""
    monkeypatch.setenv("METALGUARD_MODE", "observer")
    _mock_observer_versions_ok(monkeypatch)
    info = acquire_mlx_lock("solo_observer")
    try:
        assert info["label"] == "solo_observer"
        assert info["pid"] == os.getpid()
        assert "advisory" not in info  # real acquire, not advisory
        assert read_mlx_lock()["label"] == "solo_observer"
    finally:
        release_mlx_lock()


# ── Task 7: parity regression coverage ──────────────────────────────────


def test_acquire_release_round_trip():
    info = acquire_mlx_lock("round_trip")
    assert info["pid"] == os.getpid()
    current = read_mlx_lock()
    assert current is not None and current["label"] == "round_trip"
    assert release_mlx_lock() is True
    assert read_mlx_lock() is None


def test_stale_pid_is_auto_reclaimed(_isolated_lock):
    stale = {
        "pid": 2147483646,
        "label": "dead_process",
        "started_at": "2026-04-10T00:00:00Z",
        "cmdline": "ghost",
    }
    _isolated_lock.write_text(json.dumps(stale))
    assert read_mlx_lock() is None
    assert not _isolated_lock.exists()
    info = acquire_mlx_lock("live")
    try:
        assert info["label"] == "live"
    finally:
        release_mlx_lock()


def test_context_manager_releases_on_exception():
    class Boom(Exception):
        pass

    with pytest.raises(Boom):
        with mlx_exclusive_lock("ctx_exc"):
            assert read_mlx_lock() is not None
            raise Boom("simulated")
    assert read_mlx_lock() is None


_CHILD_NORMAL_SCRIPT = textwrap.dedent(
    """
    import json, os, signal, sys, time
    from pathlib import Path

    signal.signal(signal.SIGTERM, signal.SIG_DFL)
    lock_path, label, sleep_sec = sys.argv[1], sys.argv[2], float(sys.argv[3])
    info = {
        "pid": os.getpid(),
        "label": label,
        "started_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "cmdline": "child_normal",
    }
    p = Path(lock_path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(info))
    time.sleep(sleep_sec)
    """
).strip()


def _wait_for_lock_pid(lock_path, timeout_sec=5.0):
    deadline = time.monotonic() + timeout_sec
    while time.monotonic() < deadline:
        if lock_path.exists():
            try:
                info = json.loads(lock_path.read_text())
                if isinstance(info.get("pid"), int):
                    return info
            except json.JSONDecodeError:
                pass
        time.sleep(0.05)
    raise TimeoutError(f"child did not write lock within {timeout_sec}s")


def test_force_override_terminates_holder_and_replaces(
    _isolated_lock, monkeypatch,
):
    """FORCE must SIGTERM the live holder, wait for exit, then reclaim —
    regression guard for the kernel-panic incident where the lock was
    unlinked while the peer still held Metal buffers."""
    monkeypatch.setattr(mlx_lock, "_FORCE_WAIT_SEC", 5.0)
    monkeypatch.setattr(mlx_lock, "_RECLAIM_COOLDOWN_SEC", 0.0)

    child = subprocess.Popen(
        [sys.executable, "-c", _CHILD_NORMAL_SCRIPT,
         str(_isolated_lock), "peer_workload", "60"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    try:
        holder = _wait_for_lock_pid(_isolated_lock)
        assert holder["pid"] == child.pid

        info = acquire_mlx_lock("rescuer", force=True)
        assert info["label"] == "rescuer"
        assert info["pid"] == os.getpid()
        assert child.wait(timeout=2) is not None  # child exited

        current = read_mlx_lock()
        assert current is not None and current["label"] == "rescuer"
    finally:
        if child.poll() is None:
            child.kill()
            child.wait(timeout=2)
        release_mlx_lock()
