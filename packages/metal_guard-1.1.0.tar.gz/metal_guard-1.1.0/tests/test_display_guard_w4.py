"""W4 tests for metal_guard.display_guard."""
from __future__ import annotations

import subprocess
import pytest

import metal_guard.display_guard as dg
from metal_guard.display_guard import (
    is_display_active,
    precheck_lora_workload,
    apply_agx_mitigation,
    AGX_RELAX_ENV_KEY,
)


# ---------------------------------------------------------------------------
# Fixture: reset module-level cache before each test
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def reset_display_cache():
    """Reset the pmset result cache so tests don't interfere."""
    dg._cache_ts = 0.0
    dg._cache_active = True
    yield
    dg._cache_ts = 0.0
    dg._cache_active = True


# ---------------------------------------------------------------------------
# is_display_active tests
# ---------------------------------------------------------------------------

def test_display_active_pmset_on(monkeypatch):
    class FakeResult:
        returncode = 0
        stdout = "IODisplayWrangler DevicePowerState=4\n"

    monkeypatch.setattr(subprocess, "run", lambda *a, **kw: FakeResult())
    assert is_display_active(force=True) is True


def test_display_active_pmset_off(monkeypatch):
    class FakeResult:
        returncode = 0
        stdout = "IODisplayWrangler DevicePowerState=0\n"

    monkeypatch.setattr(subprocess, "run", lambda *a, **kw: FakeResult())
    assert is_display_active(force=True) is False


def test_display_active_pmset_timeout(monkeypatch):
    def _raise(*a, **kw):
        raise subprocess.TimeoutExpired(cmd="pmset", timeout=2.0)

    monkeypatch.setattr(subprocess, "run", _raise)
    assert is_display_active(force=True) is True  # fail-safe


def test_display_active_pmset_missing(monkeypatch):
    def _raise(*a, **kw):
        raise FileNotFoundError("pmset not found")

    monkeypatch.setattr(subprocess, "run", _raise)
    assert is_display_active(force=True) is True  # fail-safe


def test_display_active_cache(monkeypatch):
    call_count = 0

    class FakeResult:
        returncode = 0
        stdout = "IODisplayWrangler DevicePowerState=4\n"

    def _fake_run(*a, **kw):
        nonlocal call_count
        call_count += 1
        return FakeResult()

    monkeypatch.setattr(subprocess, "run", _fake_run)

    # First call — should shell out
    is_display_active(force=True)
    assert call_count == 1

    # Second call within TTL — should use cache (no new subprocess.run)
    is_display_active()
    assert call_count == 1


# ---------------------------------------------------------------------------
# precheck_lora_workload tests
# ---------------------------------------------------------------------------

def test_precheck_display_off(monkeypatch):
    monkeypatch.setattr(dg, "is_display_active", lambda force=False: False)
    verdict = precheck_lora_workload()
    assert verdict.safe is True


def test_precheck_display_on(monkeypatch):
    monkeypatch.setattr(dg, "is_display_active", lambda force=False: True)
    verdict = precheck_lora_workload()
    assert verdict.safe is False
    assert verdict.advisory is not None
    assert "AGX" in verdict.advisory


def test_precheck_emits_corpus_event(monkeypatch):
    monkeypatch.setattr(dg, "is_display_active", lambda force=False: True)

    calls = []

    def _fake_append(event_kind, **kwargs):
        calls.append(event_kind)

    import metal_guard.corpus as corpus_mod
    monkeypatch.setattr(corpus_mod, "append_event", _fake_append)

    precheck_lora_workload()
    assert len(calls) == 1
    assert calls[0] == "lora_display_advisory"


def test_precheck_corpus_error_swallowed(monkeypatch):
    monkeypatch.setattr(dg, "is_display_active", lambda force=False: True)

    def _raise(*a, **kw):
        raise RuntimeError("corpus exploded")

    import metal_guard.corpus as corpus_mod
    monkeypatch.setattr(corpus_mod, "append_event", _raise)

    # Must not raise — corpus errors are best-effort
    verdict = precheck_lora_workload()
    assert verdict is not None


# ---------------------------------------------------------------------------
# apply_agx_mitigation test
# ---------------------------------------------------------------------------

def test_apply_agx_mitigation_no_mutate():
    base_env = {"PATH": "/usr/bin", "HOME": "/tmp"}
    result = apply_agx_mitigation(base_env)

    # Result has the AGX key
    assert result[AGX_RELAX_ENV_KEY] == "1"

    # Input dict is NOT mutated
    assert AGX_RELAX_ENV_KEY not in base_env
