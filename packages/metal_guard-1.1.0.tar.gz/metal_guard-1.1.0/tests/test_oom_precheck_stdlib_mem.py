"""Part 1 — available-memory detection uses stdlib vm_stat, not psutil."""
from pathlib import Path
from metal_guard import oom_precheck


def _block_mlx_path(monkeypatch):
    """Patch `apple_gpu_family` to report `available=False`, so
    `_detect_available_gb` skips the MLX branch (because
    `info.get("available")` is False) and falls through to the vm_stat
    fallback.  Does NOT trigger an ImportError."""
    import metal_guard.system_audit as _sa  # noqa: PLC0415

    monkeypatch.setattr(_sa, "apple_gpu_family", lambda: {"available": False})


def test_falls_back_to_vm_stat_free_gb(monkeypatch):
    # Block the MLX-aware path so the vm_stat branch is exercised.
    _block_mlx_path(monkeypatch)
    monkeypatch.setattr(oom_precheck, "_detect_system_pressure",
                        lambda: {"free_gb": 12.5, "wired_gb": 4.0})
    # apple_gpu_family returns available=False -> skipped; vm_stat path used.
    assert oom_precheck._detect_available_gb() == 12.5


def test_returns_none_when_vm_stat_unavailable(monkeypatch):
    # Block the MLX-aware path, then make vm_stat also fail.
    _block_mlx_path(monkeypatch)
    monkeypatch.setattr(oom_precheck, "_detect_system_pressure", lambda: None)
    assert oom_precheck._detect_available_gb() is None


def test_import_error_path_falls_through_to_vm_stat(monkeypatch):
    """When metal_guard.system_audit cannot be imported, _detect_available_gb
    must still fall through to the vm_stat fallback (not crash)."""
    import builtins
    real_import = builtins.__import__

    def _fake_import(name, *args, **kwargs):
        if name == "metal_guard.system_audit" or name.endswith("system_audit"):
            raise ImportError("simulated: system_audit unavailable")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", _fake_import)
    monkeypatch.setattr(oom_precheck, "_detect_system_pressure",
                        lambda: {"free_gb": 7.0})
    assert oom_precheck._detect_available_gb() == 7.0


def test_no_psutil_import_anywhere_in_package():
    pkg = Path(oom_precheck.__file__).parent
    offenders = []
    for py in pkg.glob("*.py"):
        src = py.read_text(encoding="utf-8")
        if "import psutil" in src or "import requests" in src:
            offenders.append(py.name)
    assert offenders == [], f"third-party import found in: {offenders}"
