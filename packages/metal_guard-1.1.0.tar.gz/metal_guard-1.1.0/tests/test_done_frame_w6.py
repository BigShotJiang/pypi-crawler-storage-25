"""W6 — metal_guard.done_frame."""
import multiprocessing as mp

import pytest

from metal_guard import done_frame
from metal_guard.done_frame import (
    ChildCrashed,
    FrameProtocolMismatch,
    InvalidFrame,
    extract_prefill_from_done,
    is_strict_mode,
    normalize_legacy_frame,
    recv_frame_or_crash,
    validate_frame,
)


@pytest.fixture(autouse=True)
def _silence_corpus(monkeypatch):
    monkeypatch.setenv("METALGUARD_PANIC_CORPUS_DISABLED", "1")


def test_validate_frame_accepts_canonical_done():
    validate_frame({"protocol_version": 1, "phase": "done", "result": "x"})


def test_validate_frame_rejects_non_dict():
    with pytest.raises(InvalidFrame):
        validate_frame("not a dict")


def test_validate_frame_missing_protocol_version():
    with pytest.raises(FrameProtocolMismatch):
        validate_frame({"phase": "done"})


def test_validate_frame_unknown_protocol_version():
    with pytest.raises(FrameProtocolMismatch):
        validate_frame({"protocol_version": 99, "phase": "done"})


def test_validate_frame_unknown_phase():
    with pytest.raises(InvalidFrame):
        validate_frame({"protocol_version": 1, "phase": "bogus"})


def test_is_strict_mode_default_true(monkeypatch):
    monkeypatch.delenv("MLX_DONE_FRAME_STRICT", raising=False)
    assert is_strict_mode() is True


def test_is_strict_mode_zero_disables(monkeypatch):
    monkeypatch.setenv("MLX_DONE_FRAME_STRICT", "0")
    assert is_strict_mode() is False


def test_normalize_legacy_frame_strict_rejects_non_dict(monkeypatch):
    monkeypatch.delenv("MLX_DONE_FRAME_STRICT", raising=False)
    with pytest.raises(FrameProtocolMismatch):
        normalize_legacy_frame("raw legacy string")


def test_normalize_legacy_frame_lenient_synthesizes_v0(monkeypatch):
    monkeypatch.setenv("MLX_DONE_FRAME_STRICT", "0")
    frame = normalize_legacy_frame("raw legacy string")
    assert frame == {"protocol_version": 0, "phase": "done", "result": "raw legacy string"}


def test_extract_prefill_from_done():
    assert extract_prefill_from_done({"prefill_payload": {"tokens": 5}}) == {"tokens": 5}
    assert extract_prefill_from_done({}) is None
    assert extract_prefill_from_done({"prefill_payload": "bad"}) is None


def test_recv_frame_or_crash_happy_path():
    parent_recv, child_send = mp.Pipe(duplex=False)
    child_send.send({"protocol_version": 1, "phase": "done", "result": "ok"})
    frame = recv_frame_or_crash(parent_recv, timeout_sec=2.0)
    assert frame["phase"] == "done"


def test_recv_frame_or_crash_timeout_raises():
    parent_recv, _child_send = mp.Pipe(duplex=False)  # keep _child_send alive -> no EOF
    with pytest.raises(ChildCrashed):
        recv_frame_or_crash(parent_recv, timeout_sec=0.2)


def test_module_no_harper_coupling():
    src = open(done_frame.__file__, encoding="utf-8").read()
    assert "mlx_client" not in src
    assert ".harper" not in src
    assert "~/.claude" not in src
