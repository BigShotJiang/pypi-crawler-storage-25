"""W6 — metal_guard.load_gate."""
import pytest

from metal_guard import load_gate
from metal_guard.load_gate import MLXLoadGateError, can_load, gate_or_raise


@pytest.fixture(autouse=True)
def _silence_corpus(monkeypatch):
    monkeypatch.setenv("METALGUARD_PANIC_CORPUS_DISABLED", "1")


def test_small_model_always_passes(monkeypatch):
    monkeypatch.setattr(load_gate, "_get_available_gb_via_vm_stat", lambda: 8.0)
    monkeypatch.setattr(load_gate, "estimate_model_size_from_name", lambda m: 1.0)
    allowed, info = can_load("tiny/model")
    assert allowed is True
    assert info["reason"] == "small_model"


def test_unknown_model_size_passes(monkeypatch):
    monkeypatch.setattr(load_gate, "_get_available_gb_via_vm_stat", lambda: 64.0)
    monkeypatch.setattr(load_gate, "estimate_model_size_from_name", lambda m: None)
    allowed, info = can_load("mystery/model")
    assert allowed is True
    assert info["reason"] == "unknown_model_size"


def test_passes_headroom(monkeypatch):
    monkeypatch.setattr(load_gate, "_get_available_gb_via_vm_stat", lambda: 64.0)
    monkeypatch.setattr(load_gate, "estimate_model_size_from_name", lambda m: 20.0)
    allowed, info = can_load("big/model")
    assert allowed is True
    assert info["reason"] == "passes_headroom"


def test_insufficient_vram_refused(monkeypatch):
    monkeypatch.setattr(load_gate, "_get_available_gb_via_vm_stat", lambda: 10.0)
    monkeypatch.setattr(load_gate, "estimate_model_size_from_name", lambda m: 31.0)
    allowed, info = can_load("huge/model")
    assert allowed is False
    assert info["reason"] == "insufficient_vram"


def test_safe_on_skip_when_probes_fail(monkeypatch):
    monkeypatch.setattr(load_gate, "_get_available_gb_via_vm_stat", lambda: None)
    monkeypatch.setattr(load_gate, "_get_available_gb_via_system_profiler", lambda: None)
    monkeypatch.setattr(load_gate, "estimate_model_size_from_name", lambda m: 31.0)
    allowed, info = can_load("huge/model")
    assert allowed is True
    assert info["reason"] == "unknown_vm_stat"


def test_gate_or_raise_passes(monkeypatch):
    monkeypatch.setattr(load_gate, "_get_available_gb_via_vm_stat", lambda: 64.0)
    monkeypatch.setattr(load_gate, "estimate_model_size_from_name", lambda m: 5.0)
    gate_or_raise("ok/model")  # must not raise


def test_gate_or_raise_refuses(monkeypatch):
    monkeypatch.setattr(load_gate, "_get_available_gb_via_vm_stat", lambda: 10.0)
    monkeypatch.setattr(load_gate, "estimate_model_size_from_name", lambda m: 31.0)
    with pytest.raises(MLXLoadGateError):
        gate_or_raise("huge/model")


def test_headroom_ratio_env_override(monkeypatch):
    monkeypatch.setenv("MLX_LOAD_HEADROOM_RATIO", "0.5")
    assert load_gate._get_headroom_ratio() == 0.5


def test_headroom_floor_2gb(monkeypatch):
    monkeypatch.delenv("MLX_LOAD_HEADROOM_RATIO", raising=False)
    assert load_gate._compute_headroom_gb(3.0) == 2.0  # max(0.6, 2.0 floor)


def test_load_gate_never_imports_mlx_core():
    """AC5.6 — load_gate must work under panic cooldown without an MLX import."""
    src = open(load_gate.__file__, encoding="utf-8").read()
    assert "mlx.core" not in src
    assert "import mlx" not in src


def test_module_no_harper_coupling():
    src = open(load_gate.__file__, encoding="utf-8").read()
    assert "mlx_client" not in src
    assert ".harper" not in src
    assert "~/.claude" not in src
