"""Part 2 — `metal-guard` (no args) runs onboarding; `diagnose` subcommand."""
import metal_guard_cli
from metal_guard import onboarding


def test_no_args_runs_onboarding(monkeypatch, capsys):
    monkeypatch.setattr(onboarding, "_recent_panics", lambda h: [])
    monkeypatch.setattr("metal_guard.shell_guard.status",
                        lambda: {"installed": False, "rc": "/x/.zshrc"})
    rc = metal_guard_cli.main([])
    assert rc == 0
    assert "MLX kernel-panic protection" in capsys.readouterr().out


def test_diagnose_subcommand(monkeypatch, capsys):
    monkeypatch.setattr(onboarding, "_recent_panics", lambda h: [])
    rc = metal_guard_cli.main(["diagnose"])
    assert rc == 0
    assert "No recent kernel panics" in capsys.readouterr().out


def test_status_subcommand_still_works(capsys):
    rc = metal_guard_cli.main(["status"])
    assert rc in (0, 2)  # exit_code from payload; just must not crash
    assert capsys.readouterr().out  # rendered something
