"""W4 — observer-mode version gate merged from mlx_client mode.py."""
from metal_guard import process_mode


def test_version_ok_equal():
    assert process_mode._version_ok("0.31.2", "0.31.2") is True


def test_version_ok_newer():
    assert process_mode._version_ok("0.32.0", "0.31.2") is True


def test_version_ok_older():
    assert process_mode._version_ok("0.30.0", "0.31.2") is False


def test_version_ok_none():
    assert process_mode._version_ok(None, "0.31.2") is False


def test_check_observer_requirements_all_ok(monkeypatch):
    monkeypatch.setattr(process_mode, "_installed_versions",
                        lambda: {"mlx": "0.31.2", "mlx-lm": "0.31.3"})
    assert process_mode.check_observer_requirements() == []


def test_check_observer_requirements_too_old(monkeypatch):
    monkeypatch.setattr(process_mode, "_installed_versions",
                        lambda: {"mlx": "0.30.0", "mlx-lm": "0.31.3"})
    problems = process_mode.check_observer_requirements()
    assert len(problems) == 1 and "mlx" in problems[0]


def test_check_observer_requirements_missing(monkeypatch):
    monkeypatch.setattr(process_mode, "_installed_versions",
                        lambda: {"mlx": None, "mlx-lm": "0.31.3"})
    assert any("not installed" in p for p in process_mode.check_observer_requirements())


def test_current_mode_observer_gate_blocks(monkeypatch):
    monkeypatch.setenv("METALGUARD_MODE", "observer")
    monkeypatch.setattr(process_mode, "_installed_versions",
                        lambda: {"mlx": "0.30.0", "mlx-lm": "0.31.3"})
    assert process_mode.current_mode() == "defensive"


def test_current_mode_observer_gate_passes(monkeypatch):
    monkeypatch.setenv("METALGUARD_MODE", "observer")
    monkeypatch.setattr(process_mode, "_installed_versions",
                        lambda: {"mlx": "0.31.2", "mlx-lm": "0.31.3"})
    assert process_mode.current_mode() == "observer"


def test_describe_mode_downgrade_reason(monkeypatch):
    monkeypatch.setenv("METALGUARD_MODE", "observer")
    monkeypatch.setattr(process_mode, "_installed_versions",
                        lambda: {"mlx": "0.30.0", "mlx-lm": "0.31.3"})
    assert process_mode.describe_mode()["downgrade_reason"] is not None


def test_describe_mode_no_downgrade_when_ok(monkeypatch):
    monkeypatch.setenv("METALGUARD_MODE", "observer")
    monkeypatch.setattr(process_mode, "_installed_versions",
                        lambda: {"mlx": "0.31.2", "mlx-lm": "0.31.3"})
    assert process_mode.describe_mode()["downgrade_reason"] is None
