"""Part 0 — panic scanner must see modern-macOS panic locations/extensions."""
import os
from metal_guard import panic_reports

_SIG_TEXT = (
    "panic: prepare_count_underflow detected\n"
    "at IOGPUMemory.cpp:492 completeMemory()\n"
)


def _write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text)


def test_scans_multiple_dirs_and_extensions(tmp_path, monkeypatch):
    legacy = tmp_path / "DiagnosticReports"
    modern = tmp_path / "PanicReporter"
    _write(str(legacy / "Foo-2026.panic"), _SIG_TEXT)
    _write(str(modern / "Kernel-2026-05-19-000000.ips"), '{"x":1}\n' + _SIG_TEXT)
    # An ordinary app-crash .ips must NOT be reported as a panic.
    _write(str(legacy / "SomeApp-2026-05-19.ips"), '{"app":"crash"}\n')
    monkeypatch.setattr(panic_reports, "_PANIC_REPORT_DIRS",
                         (str(legacy), str(modern)))

    results = panic_reports.parse_panic_reports()
    files = {os.path.basename(r["source_file"]) for r in results}
    assert "Foo-2026.panic" in files
    assert "Kernel-2026-05-19-000000.ips" in files
    assert "SomeApp-2026-05-19.ips" not in files


def test_explicit_directory_still_scans_only_that(tmp_path, monkeypatch):
    one = tmp_path / "only"
    _write(str(one / "Bar.panic"), _SIG_TEXT)
    other = tmp_path / "other"
    _write(str(other / "Baz.panic"), _SIG_TEXT)
    monkeypatch.setattr(panic_reports, "_PANIC_REPORT_DIRS", (str(other),))
    results = panic_reports.parse_panic_reports(directory=str(one))
    files = {os.path.basename(r["source_file"]) for r in results}
    assert files == {"Bar.panic"}


def test_unreadable_dir_is_skipped(tmp_path, monkeypatch):
    good = tmp_path / "good"
    _write(str(good / "Ok.panic"), _SIG_TEXT)
    monkeypatch.setattr(panic_reports, "_PANIC_REPORT_DIRS",
                        (str(good), "/nonexistent/path/xyz"))
    results = panic_reports.parse_panic_reports()
    assert len(results) == 1


def test_since_ts_filters_across_multiple_dirs(tmp_path, monkeypatch):
    import time
    d1 = tmp_path / "d1"
    d2 = tmp_path / "d2"
    _write(str(d1 / "Old.panic"), _SIG_TEXT)
    _write(str(d2 / "New.panic"), _SIG_TEXT)
    old_ts = time.time() - 90 * 24 * 3600   # 90 days ago
    new_ts = time.time() - 1 * 3600         # 1 hour ago
    os.utime(str(d1 / "Old.panic"), (old_ts, old_ts))
    os.utime(str(d2 / "New.panic"), (new_ts, new_ts))
    monkeypatch.setattr(panic_reports, "_PANIC_REPORT_DIRS", (str(d1), str(d2)))
    results = panic_reports.parse_panic_reports(since_ts=time.time() - 7 * 24 * 3600)
    files = {os.path.basename(r["source_file"]) for r in results}
    assert files == {"New.panic"}
