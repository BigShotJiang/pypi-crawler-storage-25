"""W12 — regression suite for the top-level dispatch layer.

Covers the two ported submodules ``metal_guard.fallback_chain`` (Wave B
engine fallback chain) and ``metal_guard.inference`` (in-process MLX
dispatch path). No test imports ``mlx.core`` or spawns a worker — every
real-backend boundary is monkeypatched.
"""
from __future__ import annotations

import inspect
import json
import re

import pytest

from metal_guard import corpus
from metal_guard import fallback_chain as fc
from metal_guard import inference as inf
from metal_guard.fallback_chain import (
    BackendTier,
    BackendTierLayerViolationError,
    ModelSubstitutionForbiddenError,
    call_with_fallback,
    load_chain,
    update_chain_config_baseline,
    verify_chain_config,
)
from metal_guard.inference import (
    MLXDispatchBlockedError,
    _apply_chat_template,
    encode_image,
    retry,
)


@pytest.fixture(autouse=True)
def _silence_corpus(monkeypatch):
    """Keep the corpus event stream out of the real filesystem."""
    monkeypatch.setenv("METALGUARD_PANIC_CORPUS_DISABLED", "1")


# ── fallback_chain: BackendTier construction ─────────────────────────


def test_backend_tier_valid_mlx_ollama():
    mlx_tier = BackendTier(name="t1", backend="mlx", model="phi4")
    ollama_tier = BackendTier(name="t2", backend="ollama", model="phi4:q4_K_M")
    assert mlx_tier.backend == "mlx"
    assert ollama_tier.backend == "ollama"


def test_backend_tier_cloud_backend_raises():
    with pytest.raises(BackendTierLayerViolationError):
        BackendTier(name="cloud", backend="openai", model="gpt-4")


def test_backend_tier_string_numeric_fields_raise_type_error():
    with pytest.raises(TypeError):
        BackendTier(name="t", backend="mlx", model="m", max_attempts="3")
    with pytest.raises(TypeError):
        BackendTier(name="t", backend="mlx", model="m", timeout_sec="60")


# ── fallback_chain: call_with_fallback ───────────────────────────────


def test_call_with_fallback_falls_through_to_second_tier(monkeypatch):
    chain = [
        BackendTier(name="first", backend="ollama", model="m1"),
        BackendTier(name="second", backend="ollama", model="m1"),
    ]
    monkeypatch.setattr(fc, "_is_ollama_daemon_reachable", lambda url: True)

    def _dispatch(tier, prompt, **params):
        if tier.name == "first":
            raise RuntimeError("first tier down")
        return "ok-from-second", {}

    monkeypatch.setattr(fc, "_dispatch_tier", _dispatch)
    result, used_tier, telemetry = call_with_fallback("wc", "prompt", chain)
    assert result == "ok-from-second"
    assert used_tier.name == "second"
    assert ("first", "fail", "RuntimeError") in telemetry["attempts"]


def test_call_with_fallback_all_tiers_fail_returns_empty(monkeypatch):
    chain = [BackendTier(name="only", backend="ollama", model="m1")]
    monkeypatch.setattr(fc, "_is_ollama_daemon_reachable", lambda url: True)
    monkeypatch.setattr(
        fc, "_dispatch_tier",
        lambda tier, prompt, **p: (_ for _ in ()).throw(RuntimeError("down")),
    )
    result, used_tier, telemetry = call_with_fallback("wc", "prompt", chain)
    assert result == ""
    assert used_tier is None
    assert telemetry["all_local_failed"] is True


def test_call_with_fallback_success_returns_tuple(monkeypatch):
    chain = [BackendTier(name="good", backend="ollama", model="m1")]
    monkeypatch.setattr(fc, "_is_ollama_daemon_reachable", lambda url: True)
    monkeypatch.setattr(
        fc, "_dispatch_tier", lambda tier, prompt, **p: ("hello", {"k": 1})
    )
    result, used_tier, telemetry = call_with_fallback("wc", "prompt", chain)
    assert result == "hello"
    assert used_tier.name == "good"
    assert ("good", "success", None) in telemetry["attempts"]


# ── fallback_chain: model substitution policy ────────────────────────


def test_model_substitution_forbidden_without_flag(monkeypatch):
    chain = [
        BackendTier(name="a", backend="ollama", model="model-A"),
        BackendTier(name="b", backend="ollama", model="model-B"),
    ]
    monkeypatch.setattr(fc, "_is_ollama_daemon_reachable", lambda url: True)
    # First tier fails (still counts as attempted) → second tier with a
    # different model identity must raise.
    monkeypatch.setattr(
        fc, "_dispatch_tier",
        lambda tier, prompt, **p: (_ for _ in ()).throw(RuntimeError("down")),
    )
    with pytest.raises(ModelSubstitutionForbiddenError):
        call_with_fallback("wc", "prompt", chain)


def test_model_substitution_allowed_with_flag(monkeypatch):
    chain = [
        BackendTier(name="a", backend="ollama", model="model-A"),
        BackendTier(name="b", backend="ollama", model="model-B"),
    ]
    monkeypatch.setattr(fc, "_is_ollama_daemon_reachable", lambda url: True)
    monkeypatch.setattr(
        fc, "_dispatch_tier", lambda tier, prompt, **p: ("done", {})
    )
    result, used_tier, _ = call_with_fallback(
        "wc", "prompt", chain, allow_model_substitution=True
    )
    assert result == "done"
    assert used_tier.name == "a"


# ── fallback_chain: load_chain ───────────────────────────────────────


def test_load_chain_reads_json(tmp_path):
    cfg = tmp_path / "chains.json"
    cfg.write_text(json.dumps({
        "wc": [
            {"name": "t1", "backend": "ollama", "model": "m1"},
            {"name": "t2", "backend": "mlx", "model": "m2", "timeout_sec": 90},
        ]
    }))
    chain = load_chain("wc", config_path=cfg)
    assert [t.name for t in chain] == ["t1", "t2"]
    assert chain[1].timeout_sec == 90


def test_load_chain_cloud_backend_raises(tmp_path):
    cfg = tmp_path / "chains.json"
    cfg.write_text(json.dumps({
        "wc": [{"name": "bad", "backend": "anthropic", "model": "claude"}]
    }))
    with pytest.raises(BackendTierLayerViolationError):
        load_chain("wc", config_path=cfg, verify=False)


def test_load_chain_verify_false_skips_sha256(tmp_path):
    cfg = tmp_path / "chains.json"
    cfg.write_text(json.dumps({
        "wc": [{"name": "t1", "backend": "ollama", "model": "m1"}]
    }))
    # No baseline file written — verify=False must not raise / seed.
    chain = load_chain("wc", config_path=cfg, verify=False)
    assert len(chain) == 1
    assert not (tmp_path / "chains.json.sha256").exists()


# ── fallback_chain: sha256 watchdog ──────────────────────────────────


def test_verify_chain_config_tofu_seeds_baseline(tmp_path):
    cfg = tmp_path / "chains.json"
    cfg.write_text(json.dumps({"wc": []}))
    verified, current, baseline_hex = verify_chain_config(config_path=cfg)
    assert verified is True
    assert baseline_hex is None  # TOFU first-seed
    # Second call now compares against the seeded baseline.
    verified2, _, baseline_hex2 = verify_chain_config(config_path=cfg)
    assert verified2 is True
    assert baseline_hex2 == current


def test_verify_chain_config_tampered_file_fails(tmp_path):
    cfg = tmp_path / "chains.json"
    cfg.write_text(json.dumps({"wc": []}))
    update_chain_config_baseline(config_path=cfg)
    # Tamper with the file after the baseline is set.
    cfg.write_text(json.dumps({"wc": [{"injected": True}]}))
    verified, _, _ = verify_chain_config(config_path=cfg)
    assert verified is False


# ── fallback_chain: mlx tier availability + stub ─────────────────────


def test_is_mlx_tier_available_returns_bool(monkeypatch):
    tier = BackendTier(name="t", backend="mlx", model="m")

    class _Verdict:
        exit_code = 0

    from metal_guard import panic_gate
    monkeypatch.setattr(panic_gate, "evaluate_panic_cooldown", lambda **kw: _Verdict())
    result = fc._is_mlx_tier_available(tier)
    assert isinstance(result, bool)
    assert result is True


def test_is_mlx_tier_available_skips_on_cooldown(monkeypatch):
    tier = BackendTier(name="t", backend="mlx", model="m")

    class _Verdict:
        exit_code = 2

    from metal_guard import panic_gate
    monkeypatch.setattr(panic_gate, "evaluate_panic_cooldown", lambda **kw: _Verdict())
    assert fc._is_mlx_tier_available(tier) is False


def test_mlx_tier_dispatch_stub_raises_not_implemented():
    tier = BackendTier(name="t", backend="mlx", model="m")
    with pytest.raises(NotImplementedError):
        fc._dispatch_tier(tier, "prompt")


# ── fallback_chain: EVENT_KINDS contract ─────────────────────────────


def test_event_kinds_contains_fallback_event_kinds():
    assert "fallback_attempted" in corpus.EVENT_KINDS
    assert "workload_chains_tampered" in corpus.EVENT_KINDS


# ── inference: encode_image ──────────────────────────────────────────


def test_encode_image_round_trips_png(tmp_path):
    import base64
    # Minimal 1x1 PNG.
    png_bytes = base64.b64decode(
        "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAC0lEQVR4nGNgAAIAAAUA"
        "AeImBZsAAAAASUVORK5CYII="
    )
    img = tmp_path / "tiny.png"
    img.write_bytes(png_bytes)
    encoded = encode_image(img)
    assert base64.b64decode(encoded) == png_bytes


# ── inference: chat template fallback ────────────────────────────────


def test_apply_chat_template_falls_back_to_model_family():
    class _BareTokenizer:
        name_or_path = "mlx-community/gemma-2-9b"

    out = _apply_chat_template(_BareTokenizer(), "hello")
    assert "<start_of_turn>" in out  # gemma template selected


def test_apply_chat_template_default_when_unknown_family():
    class _BareTokenizer:
        name_or_path = "some/unknown-model"

    out = _apply_chat_template(_BareTokenizer(), "hello", system="sys")
    assert "hello" in out and "sys" in out


# ── inference: retry decorator ───────────────────────────────────────


def test_retry_succeeds_after_transient_failures():
    calls = {"n": 0}

    @retry(max_attempts=2, backoff=0.0, on=(OSError,))
    def _flaky():
        calls["n"] += 1
        if calls["n"] < 3:
            raise OSError("transient")
        return "ok"

    assert _flaky() == "ok"
    assert calls["n"] == 3


def test_retry_reraises_after_exhaustion():
    @retry(max_attempts=1, backoff=0.0, on=(OSError,))
    def _always_fails():
        raise OSError("permanent")

    with pytest.raises(OSError):
        _always_fails()


# ── inference: MLXDispatchBlockedError ───────────────────────────────


def test_mlx_dispatch_blocked_error_is_runtime_error():
    assert issubclass(MLXDispatchBlockedError, RuntimeError)
    exc = MLXDispatchBlockedError(2, 190.0)
    assert exc.still_alive == 2
    assert exc.wait_budget_secs == 190.0


# ── inference: _check_load_gate ──────────────────────────────────────


def test_check_load_gate_noop_when_disabled(monkeypatch):
    monkeypatch.setenv("MLX_LOAD_GATE_DISABLED", "1")
    # Must not raise / must not touch load_gate at all.
    inf._check_load_gate("any/model")


def test_check_load_gate_delegates_to_gate_or_raise(monkeypatch):
    monkeypatch.delenv("MLX_LOAD_GATE_DISABLED", raising=False)
    called = {}
    from metal_guard import load_gate
    monkeypatch.setattr(
        load_gate, "gate_or_raise", lambda m: called.setdefault("model", m)
    )
    inf._check_load_gate("test/model")
    assert called["model"] == "test/model"


# ── module hygiene — no Harper leakage ───────────────────────────────


def test_modules_have_no_mlx_client_references():
    assert "mlx_client" not in inspect.getsource(inf)
    assert "mlx_client" not in inspect.getsource(fc)


def test_modules_have_no_harper_path_references():
    assert ".harper" not in inspect.getsource(inf)
    assert ".harper" not in inspect.getsource(fc)


def test_modules_have_no_cjk_characters():
    cjk = re.compile(r"[一-鿿]")
    assert not cjk.search(inspect.getsource(inf))
    assert not cjk.search(inspect.getsource(fc))
