"""W8 — orphan_monitor + postmortem are already public via metal_guard.forensics
(verify-only).

mlx_client `orphan_monitor.py` / `postmortem.py` / `postmortem_collect.py`
needed no port: the Phase 1 metal_guard.py->package split already carried
the L11 (orphan) + L12 (postmortem) + L13 (status) layer into
`metal_guard/forensics.py` in de-Harper-ified form — config-driven
breadcrumb path, neutral panic-jsonl path, and a GitHub-issue cross-ref in
the postmortem index instead of a ~/.claude memory path. The
`python -m postmortem_collect` shim is superseded by the
`metal-guard postmortem` CLI subcommand. These tests regression-lock that
surface so a future change cannot silently drop it or re-introduce Harper
coupling.
"""
import datetime

import pytest

from metal_guard import OrphanPre, panic_gate, run_postmortem, scan_orphan_subproc_pre


@pytest.fixture(autouse=True)
def _isolate(monkeypatch, tmp_path):
    # run_postmortem writes a real sentinel cooldown if a recent panic is
    # found — redirect it onto a tmp path so the test is side-effect-free.
    monkeypatch.setattr(panic_gate, "_PANIC_SENTINEL_PATH", str(tmp_path / "sentinel.json"))
    monkeypatch.delenv("METALGUARD_SUBPROC_ORPHAN_WATCH_DISABLED", raising=False)
    monkeypatch.delenv("METALGUARD_POSTMORTEM_DISABLED", raising=False)


def test_orphan_monitor_surface_is_public():
    assert callable(scan_orphan_subproc_pre)
    assert isinstance(OrphanPre, type)


def test_postmortem_surface_is_public():
    assert callable(run_postmortem)


def test_scan_orphan_empty_when_no_breadcrumb(tmp_path):
    """No breadcrumb file -> empty orphan list (no raise)."""
    out = scan_orphan_subproc_pre(breadcrumb_path=str(tmp_path / "nope.log"))
    assert out == []


def test_scan_orphan_detects_unpaired_pre(tmp_path):
    """A SUBPROC_PRE with no POST, older than threshold, is flagged."""
    bc = tmp_path / "breadcrumb.log"
    bc.write_text("[2026-05-18 12:00:00] SUBPROC_PRE: some/model\n", encoding="utf-8")
    now = datetime.datetime(2026, 5, 18, 12, 5, 0)  # 5 min later
    orphans = scan_orphan_subproc_pre(threshold_sec=90.0, now=now, breadcrumb_path=str(bc))
    assert len(orphans) == 1
    assert orphans[0].model_id == "some/model"


def test_scan_orphan_pre_post_paired_is_clean(tmp_path):
    """A SUBPROC_PRE matched by a SUBPROC_POST is not an orphan."""
    bc = tmp_path / "breadcrumb.log"
    bc.write_text(
        "[2026-05-18 12:00:00] SUBPROC_PRE: some/model\n"
        "[2026-05-18 12:00:30] SUBPROC_POST: some/model\n",
        encoding="utf-8",
    )
    now = datetime.datetime(2026, 5, 18, 12, 5, 0)
    assert scan_orphan_subproc_pre(threshold_sec=90.0, now=now, breadcrumb_path=str(bc)) == []


def test_scan_orphan_disabled_env(monkeypatch, tmp_path):
    monkeypatch.setenv("METALGUARD_SUBPROC_ORPHAN_WATCH_DISABLED", "1")
    bc = tmp_path / "breadcrumb.log"
    bc.write_text("[2026-05-18 12:00:00] SUBPROC_PRE: some/model\n", encoding="utf-8")
    now = datetime.datetime(2026, 5, 18, 12, 5, 0)
    assert scan_orphan_subproc_pre(threshold_sec=90.0, now=now, breadcrumb_path=str(bc)) == []


def test_run_postmortem_writes_bundle(tmp_path):
    """run_postmortem writes an index.md bundle and never raises."""
    out_dir = tmp_path / "bundle"
    result = run_postmortem(out_dir)
    assert result["status"] == "collected"
    assert (out_dir / "index.md").exists()


def test_run_postmortem_disabled_env(monkeypatch, tmp_path):
    monkeypatch.setenv("METALGUARD_POSTMORTEM_DISABLED", "1")
    result = run_postmortem(tmp_path / "bundle")
    assert result["status"] == "disabled"


def test_postmortem_index_no_harper_cross_ref(tmp_path):
    """The de-Harper-ified index.md must NOT reference a ~/.claude memory path."""
    out_dir = tmp_path / "bundle"
    run_postmortem(out_dir)
    index_text = (out_dir / "index.md").read_text(encoding="utf-8")
    assert "~/.claude" not in index_text
    assert ".harper" not in index_text


def test_forensics_module_no_harper_coupling():
    """forensics.py — the public home of orphan_monitor + postmortem — is clean."""
    from metal_guard import forensics
    src = open(forensics.__file__, encoding="utf-8").read()
    assert "mlx_client" not in src
    assert "~/.harper" not in src
    assert "~/.claude" not in src
