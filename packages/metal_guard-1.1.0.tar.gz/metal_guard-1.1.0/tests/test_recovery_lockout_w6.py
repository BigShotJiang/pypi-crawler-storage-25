"""W6 — metal_guard.recovery_lockout."""
import pytest

from metal_guard import panic_gate, recovery_lockout
from metal_guard.recovery_lockout import (
    MLXRecoveryLockedError,
    acquire_lockout,
    is_locked_out,
    release_lockout,
    time_remaining,
    trigger_crash_lockout,
)


@pytest.fixture(autouse=True)
def _isolate(monkeypatch, tmp_path):
    """Isolate corpus, lockout state, and the panic sentinel onto tmp paths."""
    monkeypatch.setenv("METALGUARD_PANIC_CORPUS_DISABLED", "1")
    monkeypatch.setenv("MLX_RECOVERY_LOCKOUT_STATE_PATH", str(tmp_path / "lockout.json"))
    monkeypatch.setattr(panic_gate, "_PANIC_SENTINEL_PATH", str(tmp_path / "sentinel.json"))


def test_not_locked_out_initially():
    assert is_locked_out() is False
    assert time_remaining() == 0


def test_acquire_then_locked_out():
    acquire_lockout("test", duration_sec=60)
    assert is_locked_out() is True
    assert time_remaining() > 0


def test_release_lockout_idempotent():
    acquire_lockout("test", duration_sec=60)
    release_lockout()
    assert is_locked_out() is False
    release_lockout()  # idempotent — must not raise


def test_expired_lockout_reads_as_unlocked():
    acquire_lockout("test", duration_sec=-10)  # until in the past
    assert is_locked_out() is False


def test_corrupt_state_file_graceful(monkeypatch, tmp_path):
    (tmp_path / "lockout.json").write_text("not json", encoding="utf-8")
    assert is_locked_out() is False  # AC3.5 — corrupt JSON treated as absent


def test_trigger_crash_lockout_first_strike_10s():
    assert trigger_crash_lockout("crash") == 10


def test_trigger_crash_lockout_escalates():
    assert trigger_crash_lockout("crash") == 10
    assert trigger_crash_lockout("crash") == 30
    assert trigger_crash_lockout("crash") == 120


def test_third_strike_marks_sentinel_cooldown(monkeypatch):
    """AC3.6 — the third strike calls panic_gate.mark_panic_sentinel_cooldown."""
    calls = []
    monkeypatch.setattr(
        panic_gate, "mark_panic_sentinel_cooldown",
        lambda duration_hours, **kw: calls.append((duration_hours, kw)),
    )
    trigger_crash_lockout("crash")
    trigger_crash_lockout("crash")
    trigger_crash_lockout("crash")
    assert len(calls) == 1
    assert calls[0][0] == 2.0
    assert calls[0][1]["reason"] == "recovery_lockout_third_strike"


def test_mlx_recovery_locked_error_is_runtime_error():
    assert issubclass(MLXRecoveryLockedError, RuntimeError)


def test_default_state_path_is_neutral():
    assert ".harper" not in recovery_lockout.DEFAULT_STATE_PATH
    assert "metal-guard" in recovery_lockout.DEFAULT_STATE_PATH


def test_module_no_harper_coupling():
    src = open(recovery_lockout.__file__, encoding="utf-8").read()
    assert "mlx_client" not in src
    assert ".harper" not in src
    assert "panic_cooldown" not in src  # rebound to panic_gate
