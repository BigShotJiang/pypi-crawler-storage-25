"""Part 2 — first-run onboarding wizard."""
import io
from metal_guard import onboarding


_PANIC = {
    "ts": 1_700_000_000.0,
    "signature": "iogpu_prepare_count_underflow",
    "explanation": "Apple GPU driver refcount underflow.",
    "pid": 123,
    "source_file": "/x/Kernel-2026.ips",
}


def test_diagnose_reports_recent_panic(monkeypatch):
    monkeypatch.setattr(onboarding, "_recent_panics", lambda h: [_PANIC])
    buf = io.StringIO()
    result = onboarding.run_diagnose(buf)
    out = buf.getvalue()
    assert "1 kernel panic" in out
    assert "iogpu_prepare_count_underflow" in out
    assert "not your mistake" in out
    assert result is True


def test_diagnose_handles_no_panics(monkeypatch):
    monkeypatch.setattr(onboarding, "_recent_panics", lambda h: [])
    buf = io.StringIO()
    onboarding.run_diagnose(buf)
    assert "No recent kernel panics" in buf.getvalue()


def test_onboarding_non_interactive_does_not_install(monkeypatch):
    monkeypatch.setattr(onboarding, "_recent_panics", lambda h: [])
    monkeypatch.setattr(
        "metal_guard.shell_guard.status",
        lambda: {"installed": False, "rc": "/x/.zshrc"})
    called = []
    monkeypatch.setattr(
        "metal_guard.shell_guard.install",
        lambda: called.append(True) or {"action": "installed", "rc": "/x"})
    buf = io.StringIO()
    rc = onboarding.run_onboarding(buf, interactive=False)
    assert rc == 0
    assert called == []  # never installs without interactive consent
    assert "mlx-safe-python" in buf.getvalue()


def test_onboarding_already_installed_short_circuits(monkeypatch):
    monkeypatch.setattr(onboarding, "_recent_panics", lambda h: [])
    monkeypatch.setattr(
        "metal_guard.shell_guard.status",
        lambda: {"installed": True, "rc": "/x/.zshrc"})
    buf = io.StringIO()
    onboarding.run_onboarding(buf, interactive=False)
    assert "already installed" in buf.getvalue()


def test_onboarding_installs_on_yes(monkeypatch):
    monkeypatch.setattr(onboarding, "_recent_panics", lambda h: [])
    monkeypatch.setattr(
        "metal_guard.shell_guard.status",
        lambda: {"installed": False, "rc": "/x/.zshrc"})
    installed = []
    monkeypatch.setattr(
        "metal_guard.shell_guard.install",
        lambda: installed.append(True) or {"action": "installed", "rc": "/x/.zshrc"})
    # Patch sys.stdin on the onboarding module so isatty() returns True
    monkeypatch.setattr(onboarding.sys, "stdin", type("FakeStdin", (), {"isatty": lambda self: True})())
    monkeypatch.setattr("builtins.input", lambda prompt="": "y")
    buf = io.StringIO()
    rc = onboarding.run_onboarding(buf, interactive=True)
    assert rc == 0
    assert installed == [True], "shell_guard.install() was never called"
    assert "installed" in buf.getvalue().lower()
