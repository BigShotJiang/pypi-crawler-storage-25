"""Part 1 — Ollama HTTP fallback uses stdlib urllib, no `requests`."""
import io
import json
import urllib.error
from unittest.mock import patch
import pytest
from metal_guard import inference


class _FakeResp:
    def __init__(self, payload):
        self._b = json.dumps(payload).encode("utf-8")
    def read(self):
        return self._b
    def __enter__(self):
        return self
    def __exit__(self, *a):
        return False


def test_ollama_success_returns_response_text():
    with patch("urllib.request.urlopen", return_value=_FakeResp({"response": " hi "})):
        out = inference._call_ollama_http(
            "p", "m", max_tokens=8, temperature=0.0)
    assert out == "hi"


def test_ollama_http_error_returns_empty_string():
    err = urllib.error.HTTPError("u", 500, "err", {}, io.BytesIO(b""))
    with patch("urllib.request.urlopen", side_effect=err):
        out = inference._call_ollama_http(
            "p", "m", max_tokens=8, temperature=0.0)
    assert out == ""
