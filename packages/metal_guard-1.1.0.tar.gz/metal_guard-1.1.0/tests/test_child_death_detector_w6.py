"""W6 — metal_guard.child_death_detector."""
import os

import pytest

from metal_guard import child_death_detector
from metal_guard.child_death_detector import (
    SubprocessEarlyDeathError,
    is_detector_enabled,
    poll_for_early_death,
)


class _FakeProcess:
    """Process stand-in: ``sentinel=-1`` means no sentinel fd to watch."""

    def __init__(self, sentinel=-1, pid=4242, exitcode=None):
        self.sentinel = sentinel
        self.pid = pid
        self.exitcode = exitcode

    def join(self, timeout=None):
        pass


@pytest.fixture(autouse=True)
def _isolate(monkeypatch, tmp_path):
    monkeypatch.setenv("METALGUARD_PANIC_CORPUS_DISABLED", "1")
    monkeypatch.setenv("MLX_RECOVERY_LOCKOUT_STATE_PATH", str(tmp_path / "lockout.json"))


def test_is_detector_enabled_default(monkeypatch):
    monkeypatch.delenv("MLX_EARLY_DEATH_DETECT", raising=False)
    assert is_detector_enabled() is True


def test_is_detector_enabled_zero_disables(monkeypatch):
    monkeypatch.setenv("MLX_EARLY_DEATH_DETECT", "0")
    assert is_detector_enabled() is False


def test_disabled_detector_returns_immediately(monkeypatch):
    monkeypatch.setenv("MLX_EARLY_DEATH_DETECT", "0")
    poll_for_early_death(process=_FakeProcess(), parent_recv_fd=None, timeout_sec=5.0)


def test_no_watchable_fds_returns(monkeypatch):
    monkeypatch.delenv("MLX_EARLY_DEATH_DETECT", raising=False)
    poll_for_early_death(process=_FakeProcess(sentinel=-1), parent_recv_fd=None, timeout_sec=1.0)


def test_timeout_returns_without_raise(monkeypatch):
    monkeypatch.delenv("MLX_EARLY_DEATH_DETECT", raising=False)
    r_fd, w_fd = os.pipe()  # write end stays open -> pipe never EOFs -> poll times out
    try:
        poll_for_early_death(
            process=_FakeProcess(sentinel=-1), parent_recv_fd=r_fd, timeout_sec=0.3,
        )
    finally:
        os.close(r_fd)
        os.close(w_fd)


def test_pipe_eof_raises_early_death(monkeypatch):
    monkeypatch.delenv("MLX_EARLY_DEATH_DETECT", raising=False)
    r_fd, w_fd = os.pipe()
    os.close(w_fd)  # writer closed -> reader sees EOF immediately
    try:
        with pytest.raises(SubprocessEarlyDeathError) as exc:
            poll_for_early_death(
                process=_FakeProcess(sentinel=-1), parent_recv_fd=r_fd, timeout_sec=2.0,
            )
        assert exc.value.detection_path == "pipe_eof"
    finally:
        os.close(r_fd)


def test_poll_interval_env_override(monkeypatch):
    monkeypatch.setenv("MLX_EARLY_DEATH_POLL_INTERVAL_MS", "250")
    assert child_death_detector._get_poll_interval_ms() == 250


def test_poll_interval_invalid_falls_back(monkeypatch):
    monkeypatch.setenv("MLX_EARLY_DEATH_POLL_INTERVAL_MS", "garbage")
    assert child_death_detector._get_poll_interval_ms() == 100


def test_early_death_error_attrs():
    e = SubprocessEarlyDeathError("sigchld", "SIGABRT")
    assert e.detection_path == "sigchld"
    assert e.signal_or_status == "SIGABRT"


def test_module_no_harper_coupling():
    src = open(child_death_detector.__file__, encoding="utf-8").read()
    assert "mlx_client" not in src
    assert ".harper" not in src
    assert "~/.claude" not in src
