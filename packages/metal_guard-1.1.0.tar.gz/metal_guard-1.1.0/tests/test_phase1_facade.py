"""Phase 1 facade locks.

Regression-locks the v0.13.0 facade refactor: the public API surface, the
AGX import-time side-effect, and the absence of a module-level mlx_client
import. ``_EXPECTED_PUBLIC_API`` is the public surface of the pre-Phase-1
single-file ``metal_guard.py`` (captured from the v0.12.0 module's
``dir()``, with stdlib-import leakage excluded). The facade must expose
exactly this set — no drops (a breaking change) and no accidental
additions.
"""
import os
import subprocess
import sys
import types

import metal_guard

# 165 names — 93 pre-refactor public API + 5 (W3 corpus) + 19 (W4
# import_gate / display_guard / launchd_guard / observer gate) + 12 (W5
# model_cache / model_profile) + 22 added in W6 (done_frame /
# recovery_lockout / load_gate / child_death_detector / safe_shutdown)
# + 14 added in W7 (oom_precheck / prefill_exposure_tracker / worker_rotation).
# (The old single file also leaked 26 stdlib / typing import names — os,
# re, json, dataclass, Any, … — into its namespace; those were never API
# and the facade does not re-export them.)
_EXPECTED_PUBLIC_API = frozenset({
    "log", "T",
    "detect_panic_signature", "ErrorClass", "classify_mlx_error",
    "is_kernel_panic_signature", "is_process_abort_signature",
    "MemoryStats", "MetalOOMError", "kv_cache_clear_on_pressure",
    "MetalGuard", "metal_guard",
    "MLXLockConflict", "read_mlx_lock", "acquire_mlx_lock",
    "release_mlx_lock", "mlx_exclusive_lock",
    "check_version_advisories", "install_upstream_defensive_patches",
    "audit_wired_limit", "read_gpu_driver_version",
    "log_system_audit_at_startup", "bench_scoped_load", "apple_gpu_family",
    "DEFENSIVE", "OBSERVER", "current_mode", "is_defensive", "is_observer",
    "describe_mode", "ProcessMode", "detect_process_mode",
    "apply_mode_defaults", "describe_process_mode",
    "KNOWN_PANIC_MODELS", "MLX_VERSION_BLOCKLIST", "MLX_LM_VERSION_BLOCKLIST",
    "WORKLOAD_ADVISORIES", "check_mlx_lm_version_blocked",
    "check_workload_advisory", "check_mlx_version_blocked",
    "check_known_panic_model", "warn_if_known_panic_model",
    "check_known_panic_model_for_gpu", "models_by_tier",
    "models_affecting_gpu_family",
    "CadenceViolation", "CrossModelCadenceViolation", "CadenceGuard",
    "require_cadence_clear", "GEMMA4_MIN_CROSS_MODEL_INTERVAL_SEC",
    "ModelDims", "KNOWN_MODELS", "lookup_dims",
    "estimate_prefill_peak_alloc_gb", "require_prefill_fit",
    "recommend_chunk_size", "describe_prefill_plan", "KVGrowthTracker",
    "kv_tracker",
    "format_panic_for_apple_feedback", "parse_panic_reports",
    "ingest_panics_jsonl", "MLXCooldownActive", "CircuitBreaker",
    "subprocess_inference_guard", "gemma4_generation_flush",
    "PANIC_REPORTS_GLOBS", "PanicRecord", "CooldownVerdict",
    "scan_recent_panics", "evaluate_panic_cooldown",
    "mark_panic_sentinel_cooldown", "ack_panic_lockout", "clear_panic_ack",
    "clear_panic_sentinel", "AbortRecord", "scan_recent_aborts",
    "OrphanPre", "scan_orphan_subproc_pre", "run_postmortem",
    "STATUS_SNAPSHOT_SCHEMA_VERSION", "get_status_snapshot",
    "write_status_snapshot",
    "SpawnRefused", "SubprocessCrashError", "SubprocessTimeoutError",
    "MLXSubprocessRunner",
    "call_model_isolated", "shutdown_all_workers",
    "ResourceTracker", "global_resource_tracker",
    "SpawnVerdict", "authorize_mlx_spawn",
    # corpus (W3 — public surface grew here)
    "append_event", "emit_event", "iter_events", "count_events", "EVENT_KINDS",
    # W4 — import_gate / display_guard / launchd_guard / process_mode observer gate
    "WATCHED_PREFIXES", "ImportGateBlocked",
    "install_import_gate", "uninstall_import_gate",
    "AGX_RELAX_ENV_KEY", "AGX_RELAX_ENV_VALUE", "LoRAVerdict",
    "is_display_active", "precheck_lora_workload", "apply_agx_mitigation",
    "LaunchdContext", "KeepAliveVerdict", "detect_launchd_context",
    "record_crash", "check_keepalive_guard", "auto_record_on_failure",
    "daemon_guard", "request_self_bootout",
    "check_observer_requirements",
    # W5 — model_cache / model_profile
    "ModelCache", "get_mlx_model", "get_mlx_vlm_model",
    "unload_all", "flush_kv_cache", "check_metal_pressure",
    "ModelProfile", "GuardMode", "KvQuantMode",
    "get_profile", "register_profile", "list_profiles",
    # W6 — done_frame / recovery_lockout / load_gate / child_death_detector / safe_shutdown
    "validate_frame", "is_strict_mode", "normalize_legacy_frame",
    "recv_frame_or_crash", "extract_prefill_from_done",
    "InvalidFrame", "FrameProtocolMismatch", "ChildCrashed",
    "is_locked_out", "acquire_lockout", "release_lockout",
    "time_remaining", "trigger_crash_lockout", "MLXRecoveryLockedError",
    "can_load", "gate_or_raise", "MLXLoadGateError",
    "poll_for_early_death", "is_detector_enabled", "SubprocessEarlyDeathError",
    "safe_inference_shutdown", "ShutdownReport",
    # W7 — oom_precheck / prefill_exposure_tracker / worker_rotation
    "OOMVerdict", "precheck_inference", "precheck_inference_or_raise",
    "WorkerPrefillState", "record_prefill", "get_state",
    "forget_worker", "all_states",
    "should_rotate_worker", "RotationVerdict",
    "REASON_DISABLED", "REASON_NO_STATE",
    "REASON_UNDER_BUDGET", "REASON_PREFILL_BUDGET_EXCEEDED",
})


def test_version_is_1_1_0():
    assert metal_guard.__version__ == "1.1.0"


def test_all_matches_pre_refactor_surface():
    """__all__ is exactly the pre-refactor public surface + __version__."""
    assert set(metal_guard.__all__) == _EXPECTED_PUBLIC_API | {"__version__"}


def test_every_all_name_is_a_real_attribute():
    missing = [n for n in metal_guard.__all__ if not hasattr(metal_guard, n)]
    assert missing == [], f"__all__ names not reachable: {missing}"


def test_no_all_name_is_none():
    """Re-export wiring did not bind a public name to None."""
    nulls = [n for n in metal_guard.__all__ if getattr(metal_guard, n) is None]
    assert nulls == [], f"public names bound to None: {nulls}"


def test_no_undeclared_public_attribute():
    """No public (non-underscore, non-submodule) attr is missing from __all__.

    Catches a public symbol that got re-exported but left out of __all__.
    Submodule attributes (metal_guard.guard, metal_guard.panic_gate, …) are
    excluded — they are package structure, not API.
    """
    public_attrs = {
        n for n in dir(metal_guard)
        if not n.startswith("_")
        and n != "annotations"  # `from __future__ import annotations` artifact
        and not isinstance(getattr(metal_guard, n), types.ModuleType)
    }
    undeclared = public_attrs - set(metal_guard.__all__)
    assert undeclared == set(), f"public attrs missing from __all__: {undeclared}"


def test_singleton_instance_reexported():
    """metal_guard.metal_guard is the MetalGuard singleton (CLI depends on it)."""
    assert isinstance(metal_guard.metal_guard, metal_guard.MetalGuard)


def test_agx_env_side_effect_ran_on_import():
    """_constants sets AGX_RELAX_CDM_CTXSTORE_TIMEOUT at import time."""
    assert os.environ.get("AGX_RELAX_CDM_CTXSTORE_TIMEOUT") is not None


def test_no_mlx_client_import_at_module_load():
    """No submodule imports mlx_client at module top level.

    The package has no mlx_client reference at all (W14 J1 rebound the G1
    panic-cooldown gate to the package's own panic_gate). Verified in a
    fresh interpreter so a pre-loaded mlx_client in this process cannot
    mask a regression.
    """
    result = subprocess.run(
        [sys.executable, "-c",
         "import metal_guard, sys; "
         "sys.exit(1 if 'mlx_client' in sys.modules else 0)"],
        capture_output=True, text=True, timeout=60,
    )
    assert result.returncode == 0, (
        f"importing metal_guard pulled in mlx_client at module load: "
        f"{result.stdout} {result.stderr}"
    )
