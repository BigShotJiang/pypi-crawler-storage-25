"""Part 3 — `metal-guard guard ...` CLI subcommand."""
import metal_guard_cli


def _home(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("SHELL", "/bin/zsh")
    (tmp_path / ".zshrc").write_text("# rc\n", encoding="utf-8")


def test_guard_status_when_absent(tmp_path, monkeypatch, capsys):
    _home(tmp_path, monkeypatch)
    rc = metal_guard_cli.main(["guard", "status"])
    assert rc == 0
    assert "not installed" in capsys.readouterr().out


def test_guard_install_then_status(tmp_path, monkeypatch, capsys):
    _home(tmp_path, monkeypatch)
    assert metal_guard_cli.main(["guard", "install"]) == 0
    capsys.readouterr()
    metal_guard_cli.main(["guard", "status"])
    assert "installed" in capsys.readouterr().out
