"""W13 — final reconcile: dynamic_headroom_gb + SpawnRefused spawn gate."""

import os

import pytest

from metal_guard.guard import MetalGuard


# ── Sub-item 1: dynamic_headroom_gb ─────────────────────────────────────


def test_dynamic_headroom_gb_is_a_method():
    assert hasattr(MetalGuard, "dynamic_headroom_gb")
    assert callable(MetalGuard.dynamic_headroom_gb)


def test_dynamic_headroom_gb_returns_positive_float():
    mg = MetalGuard()
    result = mg.dynamic_headroom_gb()
    assert isinstance(result, float)
    assert result > 0.0


def test_dynamic_headroom_gb_grows_with_concurrency():
    """A larger base_gb yields larger headroom (load-adaptive contract).

    The ported signature reads live thread state for the per-concurrent
    term; with no live threads that term is zero, so the monotonic
    contract is exercised here via the documented ``base_gb`` parameter.
    """
    mg = MetalGuard()
    low = mg.dynamic_headroom_gb(base_gb=2.0)
    high = mg.dynamic_headroom_gb(base_gb=8.0)
    assert low > 0.0
    assert high > low


# ── Sub-item 3: SpawnRefused + local-panic-advisory spawn gate ───────────


def test_spawn_refused_class_exists_and_is_runtime_error():
    from metal_guard.subprocess_runner import SpawnRefused
    assert issubclass(SpawnRefused, RuntimeError)


def test_spawn_refused_carries_attributes():
    from metal_guard.subprocess_runner import SpawnRefused
    exc = SpawnRefused(
        model_id="some/model",
        gpu_family="M1",
        tier="panic",
        recommendation="do not run this",
        upstream_refs=("https://example.com/issue/1",),
    )
    assert exc.model_id == "some/model"
    assert exc.gpu_family == "M1"
    assert exc.tier == "panic"
    assert "some/model" in str(exc)


def test_spawn_refused_exported_from_facade():
    import metal_guard
    assert "SpawnRefused" in metal_guard.__all__
    assert metal_guard.SpawnRefused is not None


def test_local_panic_block_disabled_env_constant():
    from metal_guard import subprocess_runner as sr
    assert sr._LOCAL_PANIC_BLOCK_DISABLED_ENV == (
        "METALGUARD_LOCAL_PANIC_MODEL_BLOCK_DISABLED"
    )


def test_panic_tier_model_is_hard_blocked(monkeypatch):
    """A model whose advisory is tier='panic' raises SpawnRefused at
    MLXSubprocessRunner construction (defensive default).

    The advisory gate runs BEFORE _start_worker, so no real MLX worker
    is spawned for this case.
    """
    from metal_guard import subprocess_runner as sr
    from metal_guard.subprocess_runner import MLXSubprocessRunner, SpawnRefused

    # Stub the advisory lookup so no real registry entry is needed.
    # Public KNOWN_PANIC_MODELS entries use "recommendation" (or "reason")
    # for the human-readable text and "upstream" (a list) for refs.
    monkeypatch.setattr(
        "metal_guard.panic_registry.check_known_panic_model_for_gpu",
        lambda model_id, *, gpu_family=None: {
            "tier": "panic",
            "recommendation": "blocked for test",
            "upstream": [],
        },
    )
    monkeypatch.delenv(sr._LOCAL_PANIC_BLOCK_DISABLED_ENV, raising=False)
    with pytest.raises(SpawnRefused):
        MLXSubprocessRunner("test/panic-model")


def test_panic_tier_override_env_downgrades_to_warn(monkeypatch):
    """With the override env set, a tier='panic' advisory does NOT raise
    SpawnRefused (it still proceeds to spawn — which fails here for an
    unrelated, monkeypatched reason; we only assert SpawnRefused is not
    raised)."""
    from metal_guard import subprocess_runner as sr
    from metal_guard.subprocess_runner import MLXSubprocessRunner, SpawnRefused

    monkeypatch.setattr(
        "metal_guard.panic_registry.check_known_panic_model_for_gpu",
        lambda model_id, *, gpu_family=None: {
            "tier": "panic", "recommendation": "x", "upstream": [],
        },
    )
    monkeypatch.setenv(sr._LOCAL_PANIC_BLOCK_DISABLED_ENV, "1")

    # Prevent a real MLX worker spawn — the gate is exercised in isolation.
    def _no_worker(self):
        raise RuntimeError("stubbed _start_worker — not a SpawnRefused")

    monkeypatch.setattr(MLXSubprocessRunner, "_start_worker", _no_worker)
    try:
        MLXSubprocessRunner("test/panic-model")
    except SpawnRefused:
        pytest.fail("override env must downgrade tier='panic' to warn-only")
    except Exception:
        pass  # any other failure (stubbed spawn) is fine — only SpawnRefused is the contract
