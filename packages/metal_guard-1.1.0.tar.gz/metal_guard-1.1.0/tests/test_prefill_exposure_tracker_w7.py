"""W7 — metal_guard.prefill_exposure_tracker."""
from datetime import datetime, timezone

import pytest

from metal_guard import prefill_exposure_tracker as pet
from metal_guard.prefill_exposure_tracker import (
    WorkerPrefillState,
    all_states,
    forget_worker,
    get_state,
    record_prefill,
)

_T0 = datetime(2026, 5, 18, 12, 0, 0, tzinfo=timezone.utc)
_T1 = datetime(2026, 5, 18, 13, 0, 0, tzinfo=timezone.utc)


@pytest.fixture(autouse=True)
def _isolate(monkeypatch):
    monkeypatch.setenv("METALGUARD_PANIC_CORPUS_DISABLED", "1")
    monkeypatch.delenv("METALGUARD_PREFILL_EXPOSURE_DISABLED", raising=False)
    monkeypatch.delenv("METALGUARD_PREFILL_HIGH_WATER_TOKENS", raising=False)
    monkeypatch.delenv("METALGUARD_PREFILL_BUDGET_TOKENS", raising=False)
    pet.reset_all()
    yield
    pet.reset_all()


def test_record_prefill_returns_state():
    s = record_prefill(worker_pid=100, worker_started_at=_T0, prefill_tokens=5000)
    assert isinstance(s, WorkerPrefillState)
    assert s.cumulative_tokens == 5000
    assert s.prefill_count == 1


def test_cumulative_accumulates():
    record_prefill(worker_pid=100, worker_started_at=_T0, prefill_tokens=5000)
    s = record_prefill(worker_pid=100, worker_started_at=_T0, prefill_tokens=8000)
    assert s.cumulative_tokens == 13000
    assert s.max_single_prefill_tokens == 8000
    assert s.prefill_count == 2


def test_pid_recycle_resets():
    record_prefill(worker_pid=100, worker_started_at=_T0, prefill_tokens=9000)
    s = record_prefill(worker_pid=100, worker_started_at=_T1, prefill_tokens=1000)
    assert s.cumulative_tokens == 1000  # recycled — fresh generation


def test_get_state_generation_strict():
    record_prefill(worker_pid=100, worker_started_at=_T0, prefill_tokens=5000)
    assert get_state(100, worker_started_at=_T0) is not None
    assert get_state(100, worker_started_at=_T1) is None  # different generation


def test_forget_worker_generation_strict():
    record_prefill(worker_pid=100, worker_started_at=_T0, prefill_tokens=5000)
    assert forget_worker(100, worker_started_at=_T1) is None  # generation mismatch — no-op
    assert get_state(100) is not None  # still there
    assert forget_worker(100, worker_started_at=_T0) is not None  # matches — popped
    assert get_state(100) is None


def test_naive_datetime_rejected():
    with pytest.raises(ValueError):
        record_prefill(worker_pid=100, worker_started_at=datetime(2026, 5, 18), prefill_tokens=1)


def test_negative_tokens_clamped_to_zero():
    s = record_prefill(worker_pid=100, worker_started_at=_T0, prefill_tokens=-50)
    assert s.cumulative_tokens == 0


def test_disabled_env_returns_none(monkeypatch):
    monkeypatch.setenv("METALGUARD_PREFILL_EXPOSURE_DISABLED", "1")
    assert record_prefill(worker_pid=100, worker_started_at=_T0, prefill_tokens=5000) is None
    assert get_state(100) is None
    assert all_states() == ()


def test_all_states_snapshot():
    record_prefill(worker_pid=100, worker_started_at=_T0, prefill_tokens=1000)
    record_prefill(worker_pid=200, worker_started_at=_T0, prefill_tokens=2000)
    states = all_states()
    assert len(states) == 2
    assert {s.worker_pid for s in states} == {100, 200}


def test_state_is_frozen():
    s = record_prefill(worker_pid=100, worker_started_at=_T0, prefill_tokens=1000)
    with pytest.raises(Exception):
        s.cumulative_tokens = 999  # type: ignore[misc]


def test_budget_threshold_env(monkeypatch):
    monkeypatch.setenv("METALGUARD_PREFILL_BUDGET_TOKENS", "12345")
    assert pet._budget_threshold() == 12345


def test_module_no_harper_coupling():
    src = open(pet.__file__, encoding="utf-8").read()
    assert "mlx_client" not in src
    assert ".harper" not in src
    assert "~/.claude" not in src
