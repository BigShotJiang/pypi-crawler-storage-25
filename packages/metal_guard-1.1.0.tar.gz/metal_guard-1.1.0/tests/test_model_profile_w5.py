"""Tests for metal_guard.model_profile (W5 port)."""
from __future__ import annotations

import pickle

import pytest

import metal_guard.model_profile as model_profile_mod
from metal_guard.model_profile import (
    ModelProfile,
    get_profile,
    list_profiles,
    register_profile,
)

_GEMMA_ID = "mlx-community/gemma-4-31b-it-8bit"


def test_get_profile_known():
    p = get_profile(_GEMMA_ID)
    assert p.model_id == _GEMMA_ID
    assert p.persistent_worker is True


def test_get_profile_unknown_returns_empty_default():
    p = get_profile("some/unknown")
    assert p.model_id == "some/unknown"
    assert p.persistent_worker is None
    assert p.kv_quant == "off"


def test_model_profile_is_frozen():
    p = ModelProfile(model_id="x")
    with pytest.raises((AttributeError, TypeError)):
        p.model_id = "y"  # type: ignore[misc]


def test_invalid_kv_quant_rejected():
    with pytest.raises(ValueError, match="kv_quant"):
        ModelProfile(model_id="x", kv_quant="bogus")  # type: ignore[arg-type]


def test_invalid_firstgen_guard_mode_rejected():
    with pytest.raises(ValueError, match="firstgen_guard_mode"):
        ModelProfile(model_id="x", firstgen_guard_mode="bogus")  # type: ignore[arg-type]


def test_register_profile_copy_on_write():
    new_profile = ModelProfile(model_id="test/cow", min_interval_sec=42.0)
    register_profile(new_profile)
    retrieved = get_profile("test/cow")
    assert retrieved.min_interval_sec == 42.0
    assert "test/cow" in list_profiles()


def test_pickle_roundtrip_revalidates():
    p = ModelProfile(model_id="x", kv_quant="v3")
    p2 = pickle.loads(pickle.dumps(p))
    assert p2.kv_quant == "v3"


def test_metal_memory_limit_gb_field_retained_deprecated():
    """Layer F is DEAD — the field + constant are retained with DEPRECATED
    markers, not removed and not revived."""
    p = ModelProfile(model_id="x")
    assert hasattr(p, "metal_memory_limit_gb")
    with open(model_profile_mod.__file__, encoding="utf-8") as fh:
        source = fh.read()
    assert "DEPRECATED" in source
    assert "metal_memory_limit_gb" in source
    assert "PANIC11_GEMMA4_METAL_MEMORY_LIMIT_GB" in source


def test_module_no_harper_provenance():
    with open(model_profile_mod.__file__, encoding="utf-8") as fh:
        source = fh.read()
    assert "rezivot" not in source
    assert "fugan" not in source
    assert "~/.claude/plans" not in source
