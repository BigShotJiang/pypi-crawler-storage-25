"""W6 — metal_guard.safe_shutdown."""
from concurrent.futures import ThreadPoolExecutor

import pytest

from metal_guard import safe_shutdown
from metal_guard.safe_shutdown import ShutdownReport, safe_inference_shutdown


@pytest.fixture(autouse=True)
def _silence_corpus(monkeypatch):
    monkeypatch.setenv("METALGUARD_PANIC_CORPUS_DISABLED", "1")


def test_returns_shutdown_report():
    report = safe_inference_shutdown(cooldown_seconds=0.0)
    assert isinstance(report, ShutdownReport)


def test_no_pool_no_callback():
    report = safe_inference_shutdown(cooldown_seconds=0.0)
    assert report.threadpool_drained is None
    assert report.gc_collected is not None


def test_unload_callback_fires():
    fired = []
    safe_inference_shutdown(unload_callback=lambda: fired.append(1), cooldown_seconds=0.0)
    assert fired == [1]


def test_unload_callback_error_recorded():
    def boom():
        raise RuntimeError("boom")
    report = safe_inference_shutdown(unload_callback=boom, cooldown_seconds=0.0)
    assert any(step == "unload_callback" for step, _ in report.errors)


def test_threadpool_drained():
    pool = ThreadPoolExecutor(max_workers=1)
    report = safe_inference_shutdown(threadpool=pool, cooldown_seconds=0.0)
    assert report.threadpool_drained is True


def test_cooldown_applied():
    report = safe_inference_shutdown(cooldown_seconds=0.05)
    assert report.cooldown_seconds == 0.05


def test_gc_collected_is_int():
    report = safe_inference_shutdown(cooldown_seconds=0.0)
    assert isinstance(report.gc_collected, int)


def test_never_raises_on_bad_callback():
    report = safe_inference_shutdown(unload_callback=lambda: 1 / 0, cooldown_seconds=0.0)
    assert isinstance(report, ShutdownReport)  # swallowed into report.errors, not raised


def test_module_no_harper_coupling():
    src = open(safe_shutdown.__file__, encoding="utf-8").read()
    assert "mlx_client" not in src
    assert ".harper" not in src
    assert "~/.claude" not in src
