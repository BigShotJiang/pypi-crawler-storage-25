"""W7 — prefill_guard is already public via metal_guard.prefill (verify-only).

mlx_client `prefill_guard.py` needed no port: its entire surface
(ModelDims / KNOWN_MODELS / lookup_dims / estimate_prefill_peak_alloc_gb /
require_prefill_fit / recommend_chunk_size / describe_prefill_plan) already
lives in `metal_guard/prefill.py` from the Phase 1 refactor. These tests
regression-lock that the surface stays reachable + behaves.
"""
from metal_guard import (
    KNOWN_MODELS,
    ModelDims,
    describe_prefill_plan,
    estimate_prefill_peak_alloc_gb,
    lookup_dims,
    recommend_chunk_size,
    require_prefill_fit,
)


def test_prefill_guard_surface_is_public():
    """All prefill_guard public symbols are reachable via the facade."""
    assert callable(lookup_dims)
    assert callable(estimate_prefill_peak_alloc_gb)
    assert callable(require_prefill_fit)
    assert callable(recommend_chunk_size)
    assert callable(describe_prefill_plan)
    assert isinstance(KNOWN_MODELS, dict)


def test_known_models_has_curated_entries():
    """KNOWN_MODELS carries the curated model-dims table."""
    assert "gemma-4-31b-it-8bit" in KNOWN_MODELS
    dims = KNOWN_MODELS["gemma-4-31b-it-8bit"]
    assert dims.n_layers == 48 and dims.n_heads == 32


def test_lookup_dims_substring_match():
    dims = lookup_dims("mlx-community/gemma-4-26b-a4b-it-4bit")
    assert dims is not None
    assert dims.n_layers == 62


def test_estimate_prefill_peak_alloc_grows_with_context():
    d = ModelDims(n_layers=48, n_heads=32, n_kv_heads=16, head_dim=256)
    small = estimate_prefill_peak_alloc_gb(context_tokens=1000, dims=d)
    large = estimate_prefill_peak_alloc_gb(context_tokens=100_000, dims=d)
    assert large > small


def test_recommend_chunk_size_caps_huge_context():
    d = ModelDims(n_layers=48, n_heads=32, n_kv_heads=16, head_dim=256)
    chunk = recommend_chunk_size(context_tokens=200_000, dims=d)
    assert chunk < 200_000
