"""Tests for v0.12.0 ``authorize_mlx_spawn`` 6-gate pre-spawn authorization.

Context: ``check_known_panic_model()`` / ``warn_if_known_panic_model()`` are
advisory only — caller must remember to query and act. v0.12.0 adds
``authorize_mlx_spawn()`` as a hard gate that returns structured ``SpawnVerdict``
to force caller acknowledgment of all blockers before subprocess.run().

Use case: a path back from Ollama-only to MLX requires process-level
enforcement that prevents recurrent kernel panic via:
- panic-cooldown gate (panic_gate.evaluate_panic_cooldown)
- KNOWN_PANIC_MODELS denylist
- MLX_VERSION_BLOCKLIST
- WORKLOAD_ADVISORIES tier=critical
"""
from __future__ import annotations

import datetime
import json

import pytest

from metal_guard.panic_gate import CooldownVerdict


def _cooldown_verdict(exit_code: int) -> CooldownVerdict:
    """Build a CooldownVerdict for G1-gate tests.

    exit_code == 2 → cooldown active (G1 blocks); 0 → clear (G1 passes).
    """
    until = (
        datetime.datetime(2026, 5, 3, 0, 0, 0)
        if exit_code == 2 else None
    )
    return CooldownVerdict(
        exit_code=exit_code,
        reason="cooldown active" if exit_code == 2 else "no recent panics",
        recent_panics_24h=0,
        recent_panics_72h=0,
        cooldown_until=until,
    )


@pytest.fixture
def fake_audit_path(tmp_path):
    return tmp_path / "spawn_audit.jsonl"


# ── SpawnVerdict shape ────────────────────────────────────────────────


class TestSpawnVerdictShape:
    def test_dataclass_importable_from_module(self):
        from metal_guard import SpawnVerdict, authorize_mlx_spawn  # noqa: F401

    def test_verdict_is_frozen(self):
        from metal_guard import SpawnVerdict
        v = SpawnVerdict(
            allowed=True, blockers=(), advisories=(),
            gpu_family="M5", override_used=False,
        )
        with pytest.raises(Exception):  # frozen=True → FrozenInstanceError
            v.allowed = False  # type: ignore[misc]


# ── Happy path ────────────────────────────────────────────────────────


class TestHappyPath:
    def test_safe_model_no_blockers(self, monkeypatch, fake_audit_path):
        """Phi-4-mini (not in KNOWN_PANIC_MODELS) on safe mlx version → allowed."""
        from metal_guard import authorize_mlx_spawn

        # No mlx version installed → version gate degrades to no-op.
        monkeypatch.setattr("metal_guard.spawn_authorization._installed_version", lambda pkg: None)
        # No panic cooldown.
        monkeypatch.setattr("metal_guard.spawn_authorization._check_panic_cooldown_gate", lambda: None)

        verdict = authorize_mlx_spawn(
            model_id="mlx-community/Phi-4-mini-instruct-4bit",
            workload_type="text_generation",
            gpu_family="M5",
            audit_log_path=fake_audit_path,
        )
        assert verdict.allowed is True
        assert verdict.blockers == ()
        assert verdict.gpu_family == "M5"
        assert verdict.override_used is False


# ── G1 panic cooldown gate ────────────────────────────────────────────


class TestG1PanicCooldown:
    """W14 J1: G1 is now backed by the package's own
    ``panic_gate.evaluate_panic_cooldown`` (no optional mlx_client dep).
    A verdict ``exit_code == 2`` → cooldown active → G1 blocks; ``0`` → passes.
    """

    def test_cooldown_active_blocks_spawn(self, monkeypatch, fake_audit_path):
        from metal_guard import authorize_mlx_spawn

        monkeypatch.setattr(
            "metal_guard.spawn_authorization.evaluate_panic_cooldown",
            lambda: _cooldown_verdict(2),
        )

        verdict = authorize_mlx_spawn(
            model_id="mlx-community/Phi-4-mini-instruct-4bit",
            gpu_family="M5",
            audit_log_path=fake_audit_path,
        )
        assert verdict.allowed is False
        assert any(g[0] == "G1_panic_cooldown" for g in verdict.blockers)

    def test_cooldown_clear_passes_g1(self, monkeypatch, fake_audit_path):
        """exit_code == 0 → cooldown clear → G1 contributes no blocker."""
        from metal_guard import authorize_mlx_spawn

        monkeypatch.setattr(
            "metal_guard.spawn_authorization.evaluate_panic_cooldown",
            lambda: _cooldown_verdict(0),
        )
        monkeypatch.setattr("metal_guard.spawn_authorization._installed_version", lambda pkg: None)

        verdict = authorize_mlx_spawn(
            model_id="mlx-community/Phi-4-mini-instruct-4bit",
            gpu_family="M5",
            audit_log_path=fake_audit_path,
        )
        assert not any(g[0] == "G1_panic_cooldown" for g in verdict.blockers)

    def test_evaluate_cooldown_crash_does_not_break_gate(self, monkeypatch):
        from metal_guard import _check_panic_cooldown_gate

        def crashing_fn():
            raise RuntimeError("boom")

        monkeypatch.setattr(
            "metal_guard.spawn_authorization.evaluate_panic_cooldown", crashing_fn
        )
        # Must NOT raise.
        result = _check_panic_cooldown_gate()
        assert result is None


# ── G2 KNOWN_PANIC_MODELS gate ────────────────────────────────────────


class TestG2KnownPanic:
    def test_known_panic_model_blocked(self, monkeypatch, fake_audit_path):
        from metal_guard import authorize_mlx_spawn, KNOWN_PANIC_MODELS

        # Need a model that's in KNOWN_PANIC_MODELS for any GPU family. Use
        # the first one we find.
        if not KNOWN_PANIC_MODELS:
            pytest.skip("KNOWN_PANIC_MODELS empty")

        model_id, advisory = next(iter(KNOWN_PANIC_MODELS.items()))
        # Pick a GPU family that's actually flagged for this model (or
        # bypass via gpu_family=None to use legacy unfiltered match).
        gpu_family = None
        for ec in advisory.get("error_classes", []):
            families = ec.get("gpu_family", [])
            if families:
                gpu_family = families[0]
                break

        # Disable other gates to isolate G2.
        monkeypatch.setattr("metal_guard.spawn_authorization._check_panic_cooldown_gate", lambda: None)
        monkeypatch.setattr("metal_guard.spawn_authorization._installed_version", lambda pkg: None)

        verdict = authorize_mlx_spawn(
            model_id=model_id,
            gpu_family=gpu_family,
            audit_log_path=fake_audit_path,
        )
        assert verdict.allowed is False
        assert any(g[0] == "G2_known_panic_model" for g in verdict.blockers)

    def test_safe_model_passes_g2(self, monkeypatch, fake_audit_path):
        from metal_guard import authorize_mlx_spawn

        monkeypatch.setattr("metal_guard.spawn_authorization._check_panic_cooldown_gate", lambda: None)
        monkeypatch.setattr("metal_guard.spawn_authorization._installed_version", lambda pkg: None)

        verdict = authorize_mlx_spawn(
            model_id="mlx-community/definitely-not-panicked",
            gpu_family="M5",
            audit_log_path=fake_audit_path,
        )
        # G2 must not contribute a blocker for unknown model.
        assert not any(g[0] == "G2_known_panic_model" for g in verdict.blockers)


# ── G3 MLX_VERSION_BLOCKLIST gate ─────────────────────────────────────


class TestG3VersionBlocklist:
    def test_critical_version_blocks(self, monkeypatch, fake_audit_path):
        from metal_guard import authorize_mlx_spawn, MLX_VERSION_BLOCKLIST

        # Find a critical/high severity entry in real blocklist.
        critical_versions = [
            v for v, info in MLX_VERSION_BLOCKLIST.items()
            if info.get("severity") in ("critical", "high")
        ]
        if not critical_versions:
            pytest.skip("MLX_VERSION_BLOCKLIST has no critical/high entries")

        target_version = critical_versions[0]
        monkeypatch.setattr(
            "metal_guard.spawn_authorization._installed_version",
            lambda pkg: target_version if pkg == "mlx" else None,
        )
        monkeypatch.setattr("metal_guard.spawn_authorization._check_panic_cooldown_gate", lambda: None)

        verdict = authorize_mlx_spawn(
            model_id="mlx-community/Phi-4-mini-instruct-4bit",
            gpu_family="M5",
            audit_log_path=fake_audit_path,
        )
        assert verdict.allowed is False
        assert any(g[0] == "G3_mlx_version_blocklist" for g in verdict.blockers)

    def test_medium_severity_does_not_block(self, monkeypatch, fake_audit_path):
        from metal_guard import authorize_mlx_spawn

        # Mock a medium-severity hit.
        monkeypatch.setattr(
            "metal_guard.spawn_authorization._installed_version",
            lambda pkg: "mock_medium_version",
        )
        monkeypatch.setattr(
            "metal_guard.spawn_authorization.MLX_VERSION_BLOCKLIST",
            {"mock_medium_version": {"severity": "medium", "reason": "test", "ref": "test"}},
        )
        monkeypatch.setattr("metal_guard.spawn_authorization._check_panic_cooldown_gate", lambda: None)

        verdict = authorize_mlx_spawn(
            model_id="mlx-community/Phi-4-mini-instruct-4bit",
            gpu_family="M5",
            audit_log_path=fake_audit_path,
        )
        # Medium severity → should NOT contribute blocker.
        assert not any(g[0] == "G3_mlx_version_blocklist" for g in verdict.blockers)


# ── G4 WORKLOAD_ADVISORIES gate ───────────────────────────────────────


class TestG4WorkloadAdvisory:
    def test_critical_tier_blocks(self, monkeypatch, fake_audit_path):
        from metal_guard import authorize_mlx_spawn

        monkeypatch.setattr(
            "metal_guard.spawn_authorization.WORKLOAD_ADVISORIES",
            {"crash_inducing_workload": {
                "tier": "critical",
                "reason": "test critical workload",
            }},
        )
        monkeypatch.setattr("metal_guard.spawn_authorization._check_panic_cooldown_gate", lambda: None)
        monkeypatch.setattr("metal_guard.spawn_authorization._installed_version", lambda pkg: None)

        verdict = authorize_mlx_spawn(
            model_id="mlx-community/Phi-4-mini-instruct-4bit",
            workload_type="crash_inducing_workload",
            gpu_family="M5",
            audit_log_path=fake_audit_path,
        )
        assert verdict.allowed is False
        assert any(g[0] == "G4_workload_critical" for g in verdict.blockers)

    def test_warn_tier_surfaces_as_advisory_not_blocker(self, monkeypatch, fake_audit_path):
        from metal_guard import authorize_mlx_spawn

        monkeypatch.setattr(
            "metal_guard.spawn_authorization.WORKLOAD_ADVISORIES",
            {"warn_workload": {
                "tier": "warn",
                "reason": "soft advisory",
            }},
        )
        monkeypatch.setattr("metal_guard.spawn_authorization._check_panic_cooldown_gate", lambda: None)
        monkeypatch.setattr("metal_guard.spawn_authorization._installed_version", lambda pkg: None)

        verdict = authorize_mlx_spawn(
            model_id="mlx-community/Phi-4-mini-instruct-4bit",
            workload_type="warn_workload",
            gpu_family="M5",
            audit_log_path=fake_audit_path,
        )
        assert verdict.allowed is True  # warn does NOT block
        assert verdict.advisories  # but DOES surface advisory


# ── Override path ─────────────────────────────────────────────────────


class TestOverride:
    def test_override_with_reason_unblocks(self, monkeypatch, fake_audit_path):
        from metal_guard import authorize_mlx_spawn

        monkeypatch.setattr(
            "metal_guard.spawn_authorization.WORKLOAD_ADVISORIES",
            {"crash_workload": {"tier": "critical", "reason": "test"}},
        )
        monkeypatch.setattr("metal_guard.spawn_authorization._check_panic_cooldown_gate", lambda: None)
        monkeypatch.setattr("metal_guard.spawn_authorization._installed_version", lambda pkg: None)

        verdict = authorize_mlx_spawn(
            model_id="mlx-community/Phi-4-mini-instruct-4bit",
            workload_type="crash_workload",
            gpu_family="M5",
            override_with_reason="bench run under monitoring, panic_gate watched",
            audit_log_path=fake_audit_path,
        )
        assert verdict.allowed is True
        assert verdict.override_used is True
        # Audit log must contain the override event.
        assert fake_audit_path.exists()
        content = fake_audit_path.read_text()
        assert "spawn_override" in content
        assert "bench run under monitoring" in content

    def test_override_too_short_still_blocks(self, monkeypatch, fake_audit_path):
        """Override <20 chars rejected — adds ANOTHER blocker, not unblocks."""
        from metal_guard import authorize_mlx_spawn

        monkeypatch.setattr(
            "metal_guard.spawn_authorization.WORKLOAD_ADVISORIES",
            {"crash_workload": {"tier": "critical", "reason": "test"}},
        )
        monkeypatch.setattr("metal_guard.spawn_authorization._check_panic_cooldown_gate", lambda: None)
        monkeypatch.setattr("metal_guard.spawn_authorization._installed_version", lambda pkg: None)

        verdict = authorize_mlx_spawn(
            model_id="mlx-community/Phi-4-mini-instruct-4bit",
            workload_type="crash_workload",
            gpu_family="M5",
            override_with_reason="too short",  # 9 chars
            audit_log_path=fake_audit_path,
        )
        assert verdict.allowed is False
        # M4 R1 fix: gate id renamed from `_too_short` to `_invalid`
        # (covers both length AND token check failures).
        assert any(g[0] == "G_override_reason_invalid" for g in verdict.blockers)
        assert verdict.override_used is False
        # Audit must NOT record (short reason rejected).
        if fake_audit_path.exists():
            assert "spawn_override" not in fake_audit_path.read_text()

    def test_audit_failure_does_not_break_gate(self, monkeypatch, tmp_path):
        """Audit log write must NEVER raise/block spawn authorization."""
        from metal_guard import authorize_mlx_spawn

        monkeypatch.setattr(
            "metal_guard.spawn_authorization.WORKLOAD_ADVISORIES",
            {"crash_workload": {"tier": "critical", "reason": "test"}},
        )
        monkeypatch.setattr("metal_guard.spawn_authorization._check_panic_cooldown_gate", lambda: None)
        monkeypatch.setattr("metal_guard.spawn_authorization._installed_version", lambda pkg: None)

        # Point audit at unwritable path (a regular file used as directory).
        bad_path = tmp_path / "blocking_file"
        bad_path.write_text("blocker")  # exists as file, can't be parent
        unwritable = bad_path / "spawn_audit.jsonl"

        # Must not raise even though audit write will fail.
        # M4 R1 fix: reason must contain operational token — "monitoring".
        verdict = authorize_mlx_spawn(
            model_id="mlx-community/Phi-4-mini-instruct-4bit",
            workload_type="crash_workload",
            gpu_family="M5",
            override_with_reason="audit failure resilience test under monitoring",
            audit_log_path=unwritable,
        )
        assert verdict.allowed is True


# ── Multiple blockers aggregate ───────────────────────────────────────


class TestM3WorkloadTypeValidation:
    """M3 R1 fix: typo'd workload_type silently no-ops G4 — now warned."""

    def test_unknown_workload_type_surfaces_advisory(self, monkeypatch, fake_audit_path):
        from metal_guard import authorize_mlx_spawn

        monkeypatch.setattr("metal_guard.spawn_authorization._check_panic_cooldown_gate", lambda: None)
        monkeypatch.setattr("metal_guard.spawn_authorization._installed_version", lambda pkg: None)

        verdict = authorize_mlx_spawn(
            model_id="mlx-community/Phi-4-mini-instruct-4bit",
            workload_type="text-generation",  # typo: hyphen
            gpu_family="M5",
            audit_log_path=fake_audit_path,
        )
        # Caller sees W_unknown_workload_type advisory.
        assert any(a[0] == "W_unknown_workload_type" for a in verdict.advisories)

    def test_known_workload_no_unknown_advisory(self, monkeypatch, fake_audit_path):
        from metal_guard import authorize_mlx_spawn

        monkeypatch.setattr("metal_guard.spawn_authorization._check_panic_cooldown_gate", lambda: None)
        monkeypatch.setattr("metal_guard.spawn_authorization._installed_version", lambda pkg: None)

        verdict = authorize_mlx_spawn(
            model_id="mlx-community/Phi-4-mini-instruct-4bit",
            workload_type="text_generation",  # correct
            gpu_family="M5",
            audit_log_path=fake_audit_path,
        )
        assert not any(a[0] == "W_unknown_workload_type" for a in verdict.advisories)


class TestM4OverrideTokenRequirement:
    """M4 R1 fix: ≥20 chars alone is gameable. Token requirement enforces
    operational context per panic #11 lesson."""

    def test_long_but_no_token_rejected(self, monkeypatch, fake_audit_path):
        """'trust me bro xxxxxxxxxxxxxxx' is long enough but no operational token."""
        from metal_guard import authorize_mlx_spawn

        monkeypatch.setattr(
            "metal_guard.spawn_authorization.WORKLOAD_ADVISORIES",
            {"crash_workload": {"tier": "critical", "reason": "test"}},
        )
        monkeypatch.setattr("metal_guard.spawn_authorization._check_panic_cooldown_gate", lambda: None)
        monkeypatch.setattr("metal_guard.spawn_authorization._installed_version", lambda pkg: None)

        verdict = authorize_mlx_spawn(
            model_id="mlx-community/Phi-4-mini-instruct-4bit",
            workload_type="crash_workload",
            gpu_family="M5",
            override_with_reason="trust me bro xxxxxxxxxxxxxxx",  # 28 chars no token
            audit_log_path=fake_audit_path,
        )
        assert verdict.allowed is False
        assert verdict.override_used is False
        assert any(g[0] == "G_override_reason_invalid" for g in verdict.blockers)
        # Audit must NOT record (rejected).
        if fake_audit_path.exists():
            assert "spawn_override" not in fake_audit_path.read_text()

    def test_long_with_token_accepted(self, monkeypatch, fake_audit_path):
        from metal_guard import authorize_mlx_spawn

        monkeypatch.setattr(
            "metal_guard.spawn_authorization.WORKLOAD_ADVISORIES",
            {"crash_workload": {"tier": "critical", "reason": "test"}},
        )
        monkeypatch.setattr("metal_guard.spawn_authorization._check_panic_cooldown_gate", lambda: None)
        monkeypatch.setattr("metal_guard.spawn_authorization._installed_version", lambda pkg: None)

        # Reason contains 'panic_gate' token.
        verdict = authorize_mlx_spawn(
            model_id="mlx-community/Phi-4-mini-instruct-4bit",
            workload_type="crash_workload",
            gpu_family="M5",
            override_with_reason="bench under monitoring with panic_gate watched",
            audit_log_path=fake_audit_path,
        )
        assert verdict.allowed is True
        assert verdict.override_used is True


class TestM5MediumSeverityAdvisory:
    """M5 R1 fix: medium/low severity in MLX_VERSION_BLOCKLIST now surfaces
    as soft advisory (was silently disappearing)."""

    def test_medium_severity_surfaces_as_advisory(self, monkeypatch, fake_audit_path):
        from metal_guard import authorize_mlx_spawn

        monkeypatch.setattr(
            "metal_guard.spawn_authorization._installed_version",
            lambda pkg: "mock_medium_version" if pkg == "mlx" else None,
        )
        monkeypatch.setattr(
            "metal_guard.spawn_authorization.MLX_VERSION_BLOCKLIST",
            {"mock_medium_version": {"severity": "medium", "reason": "minor compat issue", "ref": "test"}},
        )
        monkeypatch.setattr("metal_guard.spawn_authorization._check_panic_cooldown_gate", lambda: None)

        verdict = authorize_mlx_spawn(
            model_id="mlx-community/Phi-4-mini-instruct-4bit",
            gpu_family="M5",
            audit_log_path=fake_audit_path,
        )
        # Medium severity → NOT a blocker.
        assert not any(g[0] == "G3_mlx_version_blocklist" for g in verdict.blockers)
        # But IS surfaced as advisory.
        assert any(a[0].startswith("W_mlx_version_") for a in verdict.advisories)


class TestM1AuditJSONLAtomic:
    """M1 R1 fix: audit log writes via atomic os.write + fsync."""

    def test_audit_log_is_valid_jsonl(self, monkeypatch, fake_audit_path):
        from metal_guard import authorize_mlx_spawn

        monkeypatch.setattr(
            "metal_guard.spawn_authorization.WORKLOAD_ADVISORIES",
            {"crash_workload": {"tier": "critical", "reason": "test"}},
        )
        monkeypatch.setattr("metal_guard.spawn_authorization._check_panic_cooldown_gate", lambda: None)
        monkeypatch.setattr("metal_guard.spawn_authorization._installed_version", lambda pkg: None)

        for i in range(3):
            authorize_mlx_spawn(
                model_id=f"mlx-community/test-{i}",
                workload_type="crash_workload",
                gpu_family="M5",
                override_with_reason=f"bench iteration {i} with panic_gate watched",
                audit_log_path=fake_audit_path,
            )

        # All 3 records must be parseable JSON lines.
        lines = fake_audit_path.read_text().strip().split("\n")
        assert len(lines) == 3
        for line in lines:
            record = json.loads(line)  # would raise on corruption
            assert record["event"] == "spawn_override"
            assert "ts" in record
            assert "blockers" in record

    def test_audit_log_perms_0o600(self, monkeypatch, fake_audit_path):
        """M1 R1: audit log created with 0o600 (owner read/write only)."""
        from metal_guard import authorize_mlx_spawn
        import os

        monkeypatch.setattr(
            "metal_guard.spawn_authorization.WORKLOAD_ADVISORIES",
            {"crash_workload": {"tier": "critical", "reason": "test"}},
        )
        monkeypatch.setattr("metal_guard.spawn_authorization._check_panic_cooldown_gate", lambda: None)
        monkeypatch.setattr("metal_guard.spawn_authorization._installed_version", lambda pkg: None)

        authorize_mlx_spawn(
            model_id="mlx-community/test",
            workload_type="crash_workload",
            gpu_family="M5",
            override_with_reason="audit perm test panic_gate watched",
            audit_log_path=fake_audit_path,
        )
        mode = os.stat(fake_audit_path).st_mode & 0o777
        # Note: os.open mode is masked by umask; expect at most 0o600.
        # On default umask 022, effective is 0o600 (clean).
        assert mode <= 0o600


class TestGpuFamilyDetectionFailure:
    """End-to-end: gpu_family auto-detect fails → verdict still produced."""

    def test_apple_gpu_family_raises_returns_none_family(self, monkeypatch, fake_audit_path):
        from metal_guard import authorize_mlx_spawn

        monkeypatch.setattr(
            "metal_guard.spawn_authorization.apple_gpu_family",
            lambda: (_ for _ in ()).throw(RuntimeError("not apple silicon")),
        )
        monkeypatch.setattr("metal_guard.spawn_authorization._check_panic_cooldown_gate", lambda: None)
        monkeypatch.setattr("metal_guard.spawn_authorization._installed_version", lambda pkg: None)

        verdict = authorize_mlx_spawn(
            model_id="mlx-community/Phi-4-mini-instruct-4bit",
            workload_type="text_generation",
            gpu_family=None,  # trigger auto-detect
            audit_log_path=fake_audit_path,
        )
        # Verdict still produced, gpu_family captured as None.
        assert verdict.gpu_family is None
        assert verdict.allowed is True


class TestMultipleBlockers:
    def test_multiple_blockers_all_surface(self, monkeypatch, fake_audit_path):
        """User must see ALL blocking gates, not just first."""
        from metal_guard import authorize_mlx_spawn

        # Set up two simultaneous blockers: an active panic cooldown (G1)
        # and a critical workload advisory (G4).
        monkeypatch.setattr(
            "metal_guard.spawn_authorization.evaluate_panic_cooldown",
            lambda: _cooldown_verdict(2),
        )
        monkeypatch.setattr(
            "metal_guard.spawn_authorization.WORKLOAD_ADVISORIES",
            {"bad_workload": {"tier": "critical", "reason": "test"}},
        )
        monkeypatch.setattr("metal_guard.spawn_authorization._installed_version", lambda pkg: None)

        verdict = authorize_mlx_spawn(
            model_id="mlx-community/Phi-4-mini-instruct-4bit",
            workload_type="bad_workload",
            gpu_family="M5",
            audit_log_path=fake_audit_path,
        )
        assert verdict.allowed is False
        gate_ids = {g[0] for g in verdict.blockers}
        # User sees both gates — not just first.
        assert "G1_panic_cooldown" in gate_ids
        assert "G4_workload_critical" in gate_ids
