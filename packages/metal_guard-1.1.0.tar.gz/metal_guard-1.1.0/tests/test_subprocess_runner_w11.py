"""W11 regression suite for the ported subprocess_runner Wave A wire.

Focused contract lock for the surface ported in W11 — NOT a 1:1 port of the
upstream 50+ test suite. Covers: SubprocessCrashError classification,
_signal_name_from_exitcode, the wire env kill-switches, the prefill /
rotation poll helpers, the call_model_isolated pool, and the de-Harper /
preserve-list carve-out locks.

No real MLX subprocess is ever spawned — runners are constructed via
``object.__new__`` or with a monkeypatched worker.
"""
from __future__ import annotations

import inspect
import os
import signal
from datetime import datetime, timezone

import pytest

import metal_guard.subprocess_runner as sr
from metal_guard.subprocess_runner import (
    MLXSubprocessRunner,
    SubprocessCrashError,
    SubprocessTimeoutError,
    call_model_isolated,
    shutdown_all_workers,
    _signal_name_from_exitcode,
)
from metal_guard.worker_rotation import RotationVerdict


# ── Helpers ─────────────────────────────────────────────────────────────────


def _bare_runner(model_id: str = "test/model-x") -> MLXSubprocessRunner:
    """Construct an MLXSubprocessRunner without running __init__ / spawning.

    Sets only the attributes the helper methods under test read.
    """
    runner = object.__new__(MLXSubprocessRunner)
    runner.model_id = model_id
    runner.backend = "mlx"
    runner._worker_pid = 12345
    runner._worker_started_at = datetime.now(timezone.utc)
    runner._prefill_last_verdict = None
    runner._prefill_last_warned_threshold = None
    runner.resource_tracker = None
    runner._cold_restart_warned = False
    return runner


# ── 1. SubprocessCrashError classification ──────────────────────────────────


class TestSubprocessCrashErrorClassification:
    """SubprocessCrashError auto-classifies the detail string on construction."""

    def test_kernel_panic_detail_populates_error_class(self) -> None:
        exc = SubprocessCrashError(
            "test/model-x",
            -6,
            "IOGPUMemory.cpp:492 prepare_count_underflow kernel panic",
        )
        assert exc.error_class is not None
        assert exc.recovery_hint != "unknown"

    def test_empty_detail_leaves_error_class_none(self) -> None:
        exc = SubprocessCrashError("test/model-x", -9, "")
        assert exc.error_class is None
        assert exc.recovery_hint == "unknown"

    def test_negative_exitcode_includes_signal_name(self) -> None:
        exc = SubprocessCrashError("test/model-x", -6, "")
        assert "SIGABRT" in str(exc)

    def test_model_id_and_exitcode_preserved(self) -> None:
        exc = SubprocessCrashError("test/model-y", 1, "")
        assert exc.model_id == "test/model-y"
        assert exc.exitcode == 1


# ── 2. _signal_name_from_exitcode ───────────────────────────────────────────


class TestSignalNameFromExitcode:
    """_signal_name_from_exitcode autopsy taxonomy mapping."""

    def test_none_returns_exit_unknown(self) -> None:
        assert _signal_name_from_exitcode(None) == "exit=unknown"

    def test_sigabrt_negative_six(self) -> None:
        assert _signal_name_from_exitcode(-6) == "SIGABRT"

    def test_positive_exitcode(self) -> None:
        assert _signal_name_from_exitcode(1) == "exit=1"

    def test_non_int_returns_exit_unknown(self) -> None:
        assert _signal_name_from_exitcode("oops") == "exit=unknown"  # type: ignore[arg-type]


# ── 3. Wire env kill-switches ───────────────────────────────────────────────


class TestWireEnvKillSwitches:
    """The module defines the documented wire kill-switch env constants.

    The local-panic-advisory symbols deferred by W11 were landed in W13;
    the last two tests now lock their presence (see test_w13_reconcile.py
    for the full W13 contract)."""

    def test_load_gate_disabled_env(self) -> None:
        assert sr._LOAD_GATE_DISABLED_ENV == "MLX_LOAD_GATE_DISABLED"

    def test_recovery_lockout_gate_disabled_env(self) -> None:
        assert (
            sr._RECOVERY_LOCKOUT_GATE_DISABLED_ENV
            == "MLX_RECOVERY_LOCKOUT_GATE_DISABLED"
        )

    def test_child_death_detect_disabled_env(self) -> None:
        assert (
            sr._CHILD_DEATH_DETECT_DISABLED_ENV
            == "MLX_CHILD_DEATH_DETECT_DISABLED"
        )

    def test_sentinel_detect_disabled_env(self) -> None:
        assert sr._SENTINEL_DETECT_DISABLED_ENV == "MLX_SENTINEL_DETECT_DISABLED"

    def test_done_frame_wire_disabled_env(self) -> None:
        assert sr._DONE_FRAME_WIRE_DISABLED_ENV == "MLX_DONE_FRAME_WIRE_DISABLED"

    def test_spawn_refused_defined(self) -> None:
        # Landed in W13 — SpawnRefused is now in the module namespace.
        assert hasattr(sr, "SpawnRefused")
        assert issubclass(sr.SpawnRefused, RuntimeError)

    def test_local_panic_block_disabled_env_defined(self) -> None:
        # Landed in W13 — the local-panic-block kill-switch constant.
        assert (
            sr._LOCAL_PANIC_BLOCK_DISABLED_ENV
            == "METALGUARD_LOCAL_PANIC_MODEL_BLOCK_DISABLED"
        )


# ── 4. _record_prefill_and_check_rotation ───────────────────────────────────


class TestRecordPrefillAndCheckRotation:
    """The prefill-record / rotation-poll helper."""

    def test_records_prefill_and_polls_verdict(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.delenv("METALGUARD_PREFILL_WIRE_DISABLED", raising=False)
        runner = _bare_runner()

        recorded: list[dict] = []

        def _fake_record_prefill(**kwargs):
            recorded.append(kwargs)
            return None

        verdict = RotationVerdict(
            should_rotate=False,
            reason="under_budget",
            worker_pid=runner._worker_pid,
            worker_started_at=runner._worker_started_at,
            cumulative_tokens=100,
            threshold=50_000,
        )

        import metal_guard.prefill_exposure_tracker as pet
        import metal_guard.worker_rotation as wr

        monkeypatch.setattr(pet, "record_prefill", _fake_record_prefill)
        monkeypatch.setattr(wr, "should_rotate_worker", lambda **kw: verdict)

        runner._record_prefill_and_check_rotation({"prefill_tokens": 23_000})

        assert len(recorded) == 1
        assert recorded[0]["prefill_tokens"] == 23_000
        assert runner._prefill_last_verdict is verdict

    def test_wire_disabled_clears_verdict_and_returns_early(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("METALGUARD_PREFILL_WIRE_DISABLED", "1")
        runner = _bare_runner()
        runner._prefill_last_verdict = "stale-verdict"

        runner._record_prefill_and_check_rotation({"prefill_tokens": 23_000})

        assert runner._prefill_last_verdict is None

    def test_missing_worker_started_at_returns_early_without_raising(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.delenv("METALGUARD_PREFILL_WIRE_DISABLED", raising=False)
        runner = _bare_runner()
        runner._worker_started_at = None

        # Must not raise.
        runner._record_prefill_and_check_rotation({"prefill_tokens": 23_000})


# ── 5. should_rotate / rotation_verdict ─────────────────────────────────────


class TestRotationPollSurface:
    """The should_rotate property and rotation_verdict() poll surface."""

    def test_disabled_wire_should_rotate_false(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("METALGUARD_PREFILL_WIRE_DISABLED", "1")
        runner = _bare_runner()
        runner._prefill_last_verdict = RotationVerdict(
            should_rotate=True,
            reason="prefill_budget_exceeded",
            worker_pid=1,
            worker_started_at=datetime.now(timezone.utc),
            cumulative_tokens=99_999,
            threshold=50_000,
        )
        assert runner.should_rotate is False

    def test_disabled_wire_rotation_verdict_none(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("METALGUARD_PREFILL_WIRE_DISABLED", "1")
        runner = _bare_runner()
        runner._prefill_last_verdict = "anything"
        assert runner.rotation_verdict() is None

    def test_enabled_wire_reflects_verdict(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.delenv("METALGUARD_PREFILL_WIRE_DISABLED", raising=False)
        runner = _bare_runner()
        verdict = RotationVerdict(
            should_rotate=True,
            reason="prefill_budget_exceeded",
            worker_pid=1,
            worker_started_at=datetime.now(timezone.utc),
            cumulative_tokens=99_999,
            threshold=50_000,
        )
        runner._prefill_last_verdict = verdict
        assert runner.should_rotate is True
        assert runner.rotation_verdict() is verdict

    def test_no_verdict_should_rotate_false_never_raises(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.delenv("METALGUARD_PREFILL_WIRE_DISABLED", raising=False)
        runner = _bare_runner()
        runner._prefill_last_verdict = None
        assert runner.should_rotate is False
        assert runner.rotation_verdict() is None


# ── 6. call_model_isolated pool ─────────────────────────────────────────────


class _FakeRunner:
    """Stand-in for MLXSubprocessRunner — no subprocess, no MLX."""

    def __init__(self, model: str, *, backend: str = "mlx") -> None:
        self.model_id = model
        self.backend = backend
        self._alive = True
        self._process = None
        self.generate_calls = 0
        self.killed = False
        self.shutdown_called = False
        self.should_rotate = False

    def is_alive(self) -> bool:
        return self._alive

    def generate(self, prompt: str, **kwargs) -> str:
        self.generate_calls += 1
        return f"fake-result:{prompt[:10]}"

    def rotation_verdict(self):
        return None

    def kill(self) -> None:
        self.killed = True
        self._alive = False

    def shutdown(self, timeout: float = 10.0) -> None:
        self.shutdown_called = True
        self._alive = False


class TestCallModelIsolatedPool:
    """The auto-managed runner pool in call_model_isolated."""

    @pytest.fixture(autouse=True)
    def _clean_pool(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.setattr(sr, "MLXSubprocessRunner", _FakeRunner)
        sr._runner_pool.clear()
        yield
        sr._runner_pool.clear()

    def test_runner_reused_across_calls(self) -> None:
        r1 = call_model_isolated("prompt one", "test/model-x")
        r2 = call_model_isolated("prompt two", "test/model-x")
        assert r1.startswith("fake-result")
        assert r2.startswith("fake-result")
        pooled = sr._runner_pool["test/model-x:mlx"]
        assert pooled.generate_calls == 2

    def test_dead_runner_replaced(self) -> None:
        call_model_isolated("prompt", "test/model-x")
        pooled = sr._runner_pool["test/model-x:mlx"]
        pooled._alive = False  # simulate crash between calls
        call_model_isolated("prompt again", "test/model-x")
        new_pooled = sr._runner_pool["test/model-x:mlx"]
        assert new_pooled is not pooled
        assert new_pooled.is_alive()

    def test_shutdown_all_workers_clears_pool(self) -> None:
        call_model_isolated("prompt", "test/model-x")
        call_model_isolated("prompt", "test/model-y")
        assert len(sr._runner_pool) == 2
        shutdown_all_workers()
        assert len(sr._runner_pool) == 0


# ── 7. Preserved prefill-guard block ────────────────────────────────────────


class TestPreservedPrefillGuard:
    """Regression lock for Preserve-list carve-out 2 — the public worker's
    inline prefill-fit guard must remain."""

    def test_module_imports_prefill_guard_symbols(self) -> None:
        src = inspect.getsource(sr)
        assert "lookup_dims" in src
        assert "require_prefill_fit" in src
        assert "from metal_guard.prefill import" in src

    def test_prefill_guard_breadcrumb_present(self) -> None:
        src = inspect.getsource(sr)
        assert "PREFILL_GUARD: OK" in src


# ── 8. De-Harper lock ───────────────────────────────────────────────────────


class TestDeHarperLock:
    """The ported file carries zero mlx_client references and zero CJK
    characters."""

    def test_no_mlx_client_references(self) -> None:
        src = inspect.getsource(sr)
        assert "mlx_client" not in src

    def test_no_cjk_characters(self) -> None:
        src = inspect.getsource(sr)
        cjk = [ch for ch in src if "一" <= ch <= "鿿"]
        assert not cjk, f"unexpected CJK characters: {cjk[:20]}"

    def test_gemma4_generation_flush_used_not_firstgen_guard(self) -> None:
        src = inspect.getsource(sr)
        assert "gemma4_generation_flush" in src
        assert "gemma4_firstgen_guard" not in src
