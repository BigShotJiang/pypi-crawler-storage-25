"""W9 — version_advisories forward-drift sync + upstream_patches verify-only.

3 advisory entries (mlx-lm#1090, mlx-lm#1256, transformers#1011) were
present in the mlx_client source-of-truth advisory DB but missing from
public metal-guard — W9 appends them, de-Harper-ified. `upstream_patches`
needs no port: `install_upstream_defensive_patches` / `_patch_mlx_lm_1128`
are already public in `metal_guard.version_advisories` (Phase 1).
"""
from metal_guard import check_version_advisories, install_upstream_defensive_patches
from metal_guard import version_advisories as va


def _issues(packages):
    return {a["issue"] for a in check_version_advisories(packages=packages)}


def test_advisory_db_has_16_entries():
    assert len(va._VERSION_ADVISORIES) == 16


def test_mlx_lm_1090_fires_below_0_31_3():
    assert "ml-explore/mlx-lm#1090" in _issues({"mlx-lm": "0.31.0"})


def test_mlx_lm_1090_clears_at_0_31_3():
    issues = _issues({"mlx-lm": "0.31.3"})
    assert "ml-explore/mlx-lm#1090" not in issues
    # the >=0.31.3 successor advisory takes over
    assert "ml-explore/mlx-lm#1256" in issues


def test_mlx_lm_1256_fires_at_0_31_3_plus():
    assert "ml-explore/mlx-lm#1256" in _issues({"mlx-lm": "0.31.5"})


def test_mlx_lm_1256_absent_below_0_31_3():
    assert "ml-explore/mlx-lm#1256" not in _issues({"mlx-lm": "0.31.0"})


def test_transformers_1011_fires_on_5_5():
    advisories = check_version_advisories(packages={"transformers": "5.5.3"})
    hit = [a for a in advisories if a["issue"] == "Blaizzy/mlx-vlm#1011"]
    assert len(hit) == 1
    assert hit[0]["severity"] == "high"
    assert hit[0]["package"] == "transformers"


def test_transformers_1011_clears_on_5_4():
    assert "Blaizzy/mlx-vlm#1011" not in _issues({"transformers": "5.4.0"})


def test_transformers_1011_fires_on_prerelease():
    """The >=5.5.0.dev0 anchor catches prereleases of the 5.5 line."""
    assert "Blaizzy/mlx-vlm#1011" in _issues({"transformers": "5.5.0rc1"})


def test_upstream_patches_already_public():
    """install_upstream_defensive_patches + _patch_mlx_lm_1128 are public."""
    assert callable(install_upstream_defensive_patches)
    assert hasattr(va, "_patch_mlx_lm_1128")


def test_module_no_harper_coupling():
    src = open(va.__file__, encoding="utf-8").read()
    assert "mlx_client" not in src
    assert "harper-finance" not in src
    assert "rezivot" not in src
    assert "FUGAN" not in src
    assert "~/.harper" not in src
