"""
FERAL LLM Provider — Pluggable AI Backend
=====================================================
Supports: OpenAI API, Ollama (local), LM Studio (local),
and any OpenAI-compatible endpoint.
Now with streaming support for real-time token delivery.
"""

from __future__ import annotations
import asyncio
import os
import json
import logging
import time
import httpx
from enum import Enum
from typing import Optional, AsyncGenerator

from config.runtime import ollama_base_url, ollama_openai_base_url

logger = logging.getLogger("feral.llm")


def _gemini_api_key() -> str | None:
    """Return Gemini API key. Prefers GEMINI_API_KEY; falls back to GOOGLE_API_KEY."""
    return os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")


MAX_RETRIES = 3
RETRY_DELAYS = [1, 2, 4]  # seconds
_RETRIABLE_CODES = ("429", "500", "502", "503", "504", "timeout", "connection")


async def _retry_llm_call(coro_factory):
    """Retry an LLM HTTP call with exponential backoff on transient errors."""
    for attempt in range(MAX_RETRIES):
        try:
            return await coro_factory()
        except Exception as e:
            err_str = str(e).lower()
            retriable = any(code in err_str for code in _RETRIABLE_CODES)
            if not retriable or attempt == MAX_RETRIES - 1:
                raise
            logger.warning("LLM call failed (attempt %d/%d): %s — retrying in %ds",
                           attempt + 1, MAX_RETRIES, e, RETRY_DELAYS[attempt])
            await asyncio.sleep(RETRY_DELAYS[attempt])

VISION_READY_OLLAMA_MODELS = (
    "llava",
    "moondream",
    "qwen2-vl",
    "minicpm-v",
    "bakllava",
    "gemma3",
)


def _apply_openai_reasoning_fork(model: str, body: dict) -> dict:
    """Rewrite *body* for OpenAI's reasoning-family contract.

    gpt-5, gpt-5.4*, gpt-5.5*, o1/o3/o4: Chat Completions rejects
    ``max_tokens`` and non-1 ``temperature`` / ``top_p`` / penalty
    params with a 400 (this is the exact shape of the v2026.5.0 shipped
    400s). The fix: rename to ``max_completion_tokens`` and strip.
    Non-reasoning models (gpt-4o, gpt-4.1) pass through untouched.

    Imported locally to keep module-load order simple — providers.model_classes
    has no side-effects beyond regex compilation.
    """
    from providers.model_classes import classify
    if classify("openai", model) != "reasoning":
        return body
    if "max_tokens" in body and "max_completion_tokens" not in body:
        body["max_completion_tokens"] = body.pop("max_tokens")
    else:
        body.pop("max_tokens", None)
    temp = body.get("temperature")
    if temp is not None and temp != 1 and temp != 1.0:
        body.pop("temperature", None)
    for key in ("top_p", "presence_penalty", "frequency_penalty"):
        body.pop(key, None)
    body.setdefault("reasoning_effort", "medium")
    return body


def _apply_deepseek_reasoning_fork(model: str, body: dict) -> dict:
    """Rewrite *body* for DeepSeek's thinking-mode contract.

    v4-pro / deepseek-reasoner demand ``extra_body.thinking`` enabled
    and reject sampling params in strict mode. v4-flash / deepseek-chat
    are pass-through.
    """
    from providers.model_classes import classify
    if classify("deepseek", model) != "reasoning":
        return body
    extra = body.setdefault("extra_body", {})
    if not isinstance(extra, dict):
        extra = {}
        body["extra_body"] = extra
    extra.setdefault("thinking", {"type": "enabled"})
    body.setdefault("reasoning_effort", "high")
    for key in ("temperature", "top_p", "presence_penalty", "frequency_penalty"):
        body.pop(key, None)
    return body


def _apply_gemini_reasoning_fork(model: str, body: dict) -> dict:
    """Rewrite *body* for Gemini's thinkingConfig contract.

    ``-thinking`` variants accept ``generationConfig.thinkingConfig.enabled=true``.
    Non-thinking Gemini 3.x rejects the block with a 400.
    """
    from providers.model_classes import classify
    if classify("gemini", model) != "reasoning":
        return body
    gen_cfg = body.setdefault("generationConfig", {})
    thinking_cfg = gen_cfg.setdefault("thinkingConfig", {})
    thinking_cfg.setdefault("enabled", True)
    return body


def _apply_anthropic_reasoning_fork(model: str, body: dict) -> dict:
    """Rewrite *body* for Anthropic's thinking contract.

    Extended-thinking models (Sonnet 4.6, Haiku 4.5, Sonnet / Opus 4.5)
    accept ``thinking={"type":"enabled","budget_tokens":N}`` and require
    ``temperature=1``. Adaptive-thinking models (Opus 4.7) decline the
    explicit block — the model chooses its own depth.
    """
    from providers.model_classes import classify
    if classify("anthropic", model) != "reasoning":
        return body
    # Import lazily to avoid circular import at module load.
    from providers.anthropic_provider import (
        AnthropicProvider,
        _default_budget_tokens,
    )
    probe = AnthropicProvider(api_key="_probe_")
    if probe.supports_extended_thinking(model):
        budget = _default_budget_tokens(model)
        if budget:
            body.setdefault("thinking", {
                "type": "enabled",
                "budget_tokens": int(budget),
            })
            body.pop("temperature", None)
    elif probe.supports_adaptive_thinking(model):
        body.pop("thinking", None)
    return body


def _apply_groq_reasoning_fork(model: str, body: dict) -> dict:
    """Mirror the OpenAI fork for Groq-hosted reasoning models."""
    from providers.model_classes import classify
    if classify("groq", model) != "reasoning":
        return body
    if "max_tokens" in body and "max_completion_tokens" not in body:
        body["max_completion_tokens"] = body.pop("max_tokens")
    temp = body.get("temperature")
    if temp is not None and temp != 1 and temp != 1.0:
        body.pop("temperature", None)
    for key in ("top_p", "presence_penalty", "frequency_penalty"):
        body.pop(key, None)
    body.setdefault("reasoning_effort", "medium")
    return body


def apply_reasoning_fork(provider: str, model: str, body: dict) -> dict:
    """Provider-router wrapper around the per-provider reasoning forks.

    Called at every chat-body assembly site in this module so the
    outbound wire-shape matches the selected model's reasoning contract.
    Non-reasoning models pass through untouched. ``body`` is mutated
    in-place AND returned for caller convenience. See
    ``docs/mintlify/providers/reasoning-models.mdx`` for the full
    per-provider param table.
    """
    pid = (provider or "").lower()
    if pid == "openai":
        return _apply_openai_reasoning_fork(model, body)
    if pid == "deepseek":
        return _apply_deepseek_reasoning_fork(model, body)
    if pid == "gemini":
        return _apply_gemini_reasoning_fork(model, body)
    if pid == "anthropic":
        return _apply_anthropic_reasoning_fork(model, body)
    if pid == "groq":
        return _apply_groq_reasoning_fork(model, body)
    return body


# DeepSeek's streaming SSE keeps the connection open by sending
# ``: keep-alive`` comment lines (per the 2026-04-26 spec, the
# connection may stay open up to 10 minutes during thinking). The
# streaming path must treat these as liveness signals, not terminators.
_SSE_KEEPALIVE_PREFIXES = (": ", ":", ": keep-alive", ":OPENROUTER PROCESSING")


def _openrouter_route_supports_vision(model: str) -> tuple[bool, str]:
    """Check whether the selected OpenRouter route handles vision.

    When the router catalog has a capability snapshot for *model* we
    consult it. Otherwise we trust the router-level superset (which
    now includes vision) and return True — sending an image to a
    non-vision route will still 400 upstream, but that's a targeted
    error instead of our old "openrouter does not support vision"
    blanket ban.
    """
    try:
        from providers.catalog import get_shared_catalog
        catalog = get_shared_catalog()
        adapter = catalog.get_adapter("openrouter")
    except Exception:
        adapter = None
    if adapter is None:
        return True, ""
    caps_for = getattr(adapter, "_capabilities_for_model", None)
    if callable(caps_for) and model:
        caps = set(caps_for(model) or ())
        if caps and "vision" not in caps:
            return False, (
                f"Selected OpenRouter route {model!r} does not accept image "
                "inputs. Pick a vision-capable route (e.g. "
                "'anthropic/claude-opus-4-7', 'openai/gpt-5.5', "
                "'google/gemini-3.1-pro')."
            )
    return True, ""

# Empty ``model`` strings tell ``apply_preset`` → ``switch_provider``
# to resolve the default via the shared catalog (Roadmap §3.5 P0).
# Hardcoding a frontier name here drifts every quarter — the catalog
# does not.
LLM_PRESETS = {
    "ollama_text": {
        "provider": "ollama",
        "model": "",
        "description": "Local text path on Ollama (uses first installed text model)",
        "vision_supported": False,
    },
    "ollama_vision": {
        "provider": "ollama",
        "model": "llava",
        "description": "Local vision path on Ollama VLM",
        "vision_supported": True,
    },
    "openai_default": {
        "provider": "openai",
        "model": "",
        "description": "Cloud default for balanced latency/quality",
        "vision_supported": True,
    },
}


# ── Failover Error Classification ─────────────────────────────


class FailoverReason(str, Enum):
    RATE_LIMIT = "rate_limit"
    AUTH = "auth"
    AUTH_PERMANENT = "auth_permanent"
    BILLING = "billing"
    MODEL_NOT_FOUND = "model_not_found"
    CONTEXT_OVERFLOW = "context_overflow"
    TIMEOUT = "timeout"
    OVERLOADED = "overloaded"
    UNKNOWN = "unknown"


def classify_error(error: Exception) -> FailoverReason:
    """Classify an LLM error into a failover reason for routing decisions."""
    err_str = str(error).lower()
    status = getattr(error, "status_code", 0) or 0
    if hasattr(error, "response"):
        status = getattr(error.response, "status_code", status) or status

    if status == 429 or "rate" in err_str or "quota" in err_str:
        return FailoverReason.RATE_LIMIT
    # 401/403 with an explicit "invalid" or "incorrect" API-key message is a
    # permanent-while-current-key-is-in-place failure. Promote so the cooldown
    # tracker keeps the broken provider out of rotation for 24 h — otherwise
    # we'd probe it every 30 s and the user would see an error log stream.
    hard_key = (
        "invalid api key" in err_str
        or "incorrect api key" in err_str
        or "invalid_api_key" in err_str
        or "api key not valid" in err_str
    )
    if status in (401, 403) and hard_key:
        return FailoverReason.AUTH_PERMANENT
    if status in (401, 403) or "unauthorized" in err_str or "invalid api key" in err_str:
        return FailoverReason.AUTH
    if "billing" in err_str or "payment" in err_str or "insufficient" in err_str:
        return FailoverReason.BILLING
    if status == 404 or ("model" in err_str and "not found" in err_str):
        return FailoverReason.MODEL_NOT_FOUND
    if "context" in err_str and ("length" in err_str or "overflow" in err_str or "too long" in err_str):
        return FailoverReason.CONTEXT_OVERFLOW
    if "timeout" in err_str or status == 408 or "timed out" in err_str:
        return FailoverReason.TIMEOUT
    if status in (500, 502, 503) or "overloaded" in err_str or "server error" in err_str:
        return FailoverReason.OVERLOADED
    return FailoverReason.UNKNOWN


class ProviderCooldownTracker:
    """Tracks per-provider cooldown state for failover decisions."""

    _COOLDOWN_MAP: dict[FailoverReason, int] = {
        FailoverReason.RATE_LIMIT: 60,
        FailoverReason.AUTH: 300,
        FailoverReason.AUTH_PERMANENT: 86400,
        FailoverReason.BILLING: 3600,
        FailoverReason.OVERLOADED: 30,
        FailoverReason.TIMEOUT: 15,
    }
    _PROBE_INTERVAL = 30.0

    def __init__(self):
        self._cooldowns: dict[str, float] = {}
        self._last_probe: dict[str, float] = {}

    def record_failure(self, provider: str, reason: FailoverReason):
        cooldown_seconds = self._COOLDOWN_MAP.get(reason, 10)
        self._cooldowns[provider] = time.time() + cooldown_seconds

    def is_available(self, provider: str) -> bool:
        return time.time() >= self._cooldowns.get(provider, 0)

    def should_probe(self, provider: str) -> bool:
        if self.is_available(provider):
            return True
        last = self._last_probe.get(provider, 0)
        if time.time() - last >= self._PROBE_INTERVAL:
            self._last_probe[provider] = time.time()
            return True
        return False

    def record_success(self, provider: str):
        self._cooldowns.pop(provider, None)


# Per-provider HTTP base URL + credential env var. Default model used to
# live in this tuple — it has been stripped because hardcoded model
# literals here drift the moment a provider ships a new frontier name
# (Roadmap §3.5 P0). The runtime now resolves the default model lazily
# through ``get_shared_catalog().default_model_for(pid)`` (see
# ``_default_model_for``) so the catalog's bundled / live model list is
# the single source of truth.
_PROVIDER_REGISTRY: dict[str, tuple[str, str]] = {
    "openai": ("https://api.openai.com/v1", "OPENAI_API_KEY"),
    "groq": ("https://api.groq.com/openai/v1", "GROQ_API_KEY"),
    "anthropic": ("https://api.anthropic.com/v1", "ANTHROPIC_API_KEY"),
    "gemini": ("https://generativelanguage.googleapis.com/v1beta/openai", "GEMINI_API_KEY"),
    "openrouter": ("https://openrouter.ai/api/v1", "OPENROUTER_API_KEY"),
    "deepseek": ("https://api.deepseek.com", "DEEPSEEK_API_KEY"),
    "kimi": ("https://api.moonshot.cn/v1", "MOONSHOT_API_KEY"),
    "qwen": ("https://dashscope.aliyuncs.com/compatible-mode/v1", "DASHSCOPE_API_KEY"),
    "lmstudio": ("http://localhost:1234/v1", ""),
}


# Catalog id ↔ legacy llm_provider id. The catalog only knows
# "anthropic", "moonshot" etc. but llm_provider historically used
# "anthropic", "kimi" — keep this map small and explicit so no caller
# has to remember the translation.
_CATALOG_PROVIDER_MAP: dict[str, str] = {
    "kimi": "moonshot",
}


def _default_model_for(provider_name: str) -> str:
    """Return the catalog's current default model id for *provider_name*.

    Returns ``""`` when the catalog is unavailable or the provider is
    unknown. Callers MUST NOT substitute a hardcoded literal — surface
    the empty string back to the user / settings UI so the picker
    renders an honest "no model selected" state instead of a stale
    guess like ``gpt-4o-mini``. The roadmap §3.5 P0 ban on hardcoded
    defaults exists because those literals went stale every quarter
    and shipped to production unnoticed.
    """
    pid = _CATALOG_PROVIDER_MAP.get(provider_name, provider_name)
    try:
        from providers.catalog import get_shared_catalog
        return get_shared_catalog().default_model_for(pid) or ""
    except Exception as exc:  # pragma: no cover - defensive
        logger.debug("_default_model_for(%s) failed: %s", provider_name, exc)
        return ""


class LLMProvider:
    """
    Pluggable LLM interface.
    
    Supports:
    - OpenAI API (GPT-4o, GPT-4o-mini)
    - Ollama local (llama3, mistral, etc.)
    - Any OpenAI-compatible endpoint (Groq, Together, etc.)
    - Local on-device inference (MLX on Apple Silicon, llama.cpp elsewhere)
    - Hybrid mode (local for routing, cloud for reasoning)
    """

    def __init__(self):
        self.provider = os.getenv("FERAL_LLM_PROVIDER", "openai")
        # Resolve the default model lazily from the shared
        # ``ProviderCatalog`` rather than burning a literal here. The
        # catalog reads ``model_catalog.json`` + each adapter's bundled
        # list, so this picks up frontier IDs (gpt-5.5, claude-opus-4-7,
        # gemini-3.1-pro-preview) without an llm_provider.py edit. If
        # the catalog hasn't booted yet (offline ``feral setup``,
        # tests), fall back to the env override or empty so the picker
        # surfaces an honest "choose a model" state.
        self.model = os.getenv("FERAL_LLM_MODEL", "") or _default_model_for(self.provider)
        self.api_key = os.getenv("OPENAI_API_KEY", "")
        self.base_url = os.getenv("FERAL_LLM_BASE_URL", "")
        self.available = True
        self._config: dict = {}
        self._cooldown = ProviderCooldownTracker()

        # Local inference engine (for provider=local or hybrid)
        self._local_engine = None
        self._hybrid_cloud_provider = None

        if self.provider in ("local", "hybrid"):
            self._init_local_engine()
            if self.provider == "hybrid":
                self._init_hybrid_cloud()
            if self._local_engine:
                logger.info(f"LLM Provider: {self.provider} | Local Model: {self._local_engine.model_id}")
                return
            else:
                logger.warning("Local engine init failed, falling back to cloud")
                self.provider = "openai"

        # Set defaults based on provider. Model defaults always come
        # from the catalog (`_default_model_for`) so frontier IDs land
        # without code edits.
        if self.provider == "ollama":
            self.base_url = self.base_url or ollama_openai_base_url()
            # Ollama exposes the loaded model list via /api/tags; the
            # detected name in __init__ is preferred. Fall back only if
            # the user shipped no model.
            self.model = self.model or _default_model_for("ollama")
            self.api_key = "ollama"
        elif self.provider == "groq":
            self.base_url = self.base_url or "https://api.groq.com/openai/v1"
            self.api_key = os.getenv("GROQ_API_KEY", self.api_key)
            self.model = self.model or _default_model_for("groq")
        elif self.provider == "anthropic":
            self.base_url = self.base_url or "https://api.anthropic.com/v1"
            self.api_key = os.getenv("ANTHROPIC_API_KEY", self.api_key)
            self.model = self.model or _default_model_for("anthropic")
        elif self.provider == "gemini":
            self.base_url = self.base_url or "https://generativelanguage.googleapis.com/v1beta/openai"
            self.api_key = _gemini_api_key() or self.api_key
            self.model = self.model or _default_model_for("gemini")
        elif self.provider == "openrouter":
            self.base_url = self.base_url or "https://openrouter.ai/api/v1"
            self.api_key = os.getenv("OPENROUTER_API_KEY", self.api_key)
            self.model = self.model or _default_model_for("openrouter")
        elif self.provider == "deepseek":
            self.base_url = self.base_url or "https://api.deepseek.com"
            self.api_key = os.getenv("DEEPSEEK_API_KEY", self.api_key)
            self.model = self.model or _default_model_for("deepseek")
        elif self.provider == "kimi":
            self.base_url = self.base_url or "https://api.moonshot.cn/v1"
            self.api_key = os.getenv("MOONSHOT_API_KEY", self.api_key)
            self.model = self.model or _default_model_for("kimi")
        elif self.provider == "qwen":
            self.base_url = self.base_url or "https://dashscope.aliyuncs.com/compatible-mode/v1"
            self.api_key = os.getenv("DASHSCOPE_API_KEY", self.api_key)
            self.model = self.model or _default_model_for("qwen")
        elif self.provider == "lmstudio":
            self.base_url = self.base_url or "http://localhost:1234/v1"
            self.api_key = "lm-studio"
            self.model = self.model or _default_model_for("lmstudio")
        else:
            self.base_url = self.base_url or "https://api.openai.com/v1"
            self.model = self.model or _default_model_for("openai")

        # Check if API key is available — if not, try local fallbacks
        if not self.api_key and self.provider not in ("ollama", "lmstudio"):
            logger.warning(f"No API key for provider '{self.provider}'. Trying local fallbacks...")
            ollama_model = self._detect_ollama()
            if ollama_model:
                self.provider = "ollama"
                self.base_url = ollama_openai_base_url()
                self.model = ollama_model
                self.api_key = "ollama"
                logger.info(f"Ollama detected — using model '{ollama_model}'")
            else:
                lmstudio_model = self._detect_lmstudio()
                if lmstudio_model:
                    self.provider = "lmstudio"
                    self.base_url = "http://localhost:1234/v1"
                    self.model = lmstudio_model
                    self.api_key = "lm-studio"
                    logger.info(f"LM Studio detected — using model '{lmstudio_model}'")
                else:
                    logger.warning(
                        "No LLM available. Set OPENAI_API_KEY or run Ollama (`ollama serve`) "
                        "or LM Studio. Brain will operate in direct-execution mode "
                        "(no reasoning, skill matching only)."
                    )
                    self.available = False
                    self.api_key = "none"

        self.client = self._build_client()

        status = "READY" if self.available else "DIRECT-EXECUTION MODE (no LLM)"
        logger.info(f"LLM Provider: {self.provider} | Model: {self.model} | Status: {status}")

    @staticmethod
    def list_presets() -> list[dict]:
        return [{"id": k, **v} for k, v in LLM_PRESETS.items()]

    def _build_client(self) -> httpx.AsyncClient:
        headers = {"Content-Type": "application/json"}
        if self.provider == "anthropic":
            headers["x-api-key"] = self.api_key
            headers["anthropic-version"] = "2023-06-01"
        elif self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return httpx.AsyncClient(base_url=self.base_url, headers=headers, timeout=60.0)

    @staticmethod
    def _detect_ollama() -> Optional[str]:
        """Probe Ollama for running models. Returns best model name or None."""
        preferred = ["llama3.1", "llama3", "mistral", "gemma2", "phi3", "qwen2"]
        try:
            import urllib.request
            resp = urllib.request.urlopen(f"{ollama_base_url().rstrip('/')}/api/tags", timeout=3)
            data = json.loads(resp.read())
            models = [m.get("name", "").split(":")[0] for m in data.get("models", [])]
            if not models:
                logger.info("Ollama running but no models pulled. Try: ollama pull llama3.1")
                return None
            for pref in preferred:
                if pref in models:
                    return pref
            return models[0]
        except Exception:
            return None

    @staticmethod
    def _detect_lmstudio() -> Optional[str]:
        """Probe LM Studio for loaded models. Returns model id or None."""
        try:
            import httpx
            r = httpx.get("http://localhost:1234/v1/models", timeout=2)
            if r.status_code == 200:
                models = r.json().get("data", [])
                if models:
                    return models[0].get("id", "local-model")
        except Exception:
            pass
        return None

    def _init_local_engine(self):
        try:
            from agents.local_inference import create_local_engine
            self._local_engine = create_local_engine()
            self.available = True
        except Exception as e:
            logger.warning(f"Local LLM engine init failed: {e}")
            self._local_engine = None

    def _init_hybrid_cloud(self):
        """In hybrid mode, cloud is used for complex reasoning."""
        cloud_key = os.getenv("OPENAI_API_KEY", "")
        if cloud_key:
            self._hybrid_cloud_provider = httpx.AsyncClient(
                base_url="https://api.openai.com/v1",
                headers={"Authorization": f"Bearer {cloud_key}", "Content-Type": "application/json"},
                timeout=30.0,
            )

    async def chat(
        self,
        messages: list[dict],
        tools: Optional[list[dict]] = None,
        temperature: float = 0.7,
        max_tokens: int = 1024,
    ) -> dict:
        """
        Send a chat completion request.
        Returns the full response dict.

        When ``fallback_providers`` is configured in ``self._config``,
        transparently delegates to :meth:`chat_with_failover` so every
        caller (digital twin, proactive, ideas engine, wherever) gains
        cross-provider failover without knowing about the distinction.
        """
        fallbacks = self._config.get("fallback_providers") if isinstance(self._config, dict) else None
        if fallbacks and not (self._local_engine and self.provider in ("local", "hybrid")):
            try:
                return await self.chat_with_failover(
                    messages, tools,
                    temperature=temperature, max_tokens=max_tokens,
                )
            except Exception as exc:
                logger.warning("chat_with_failover exhausted: %s", exc)
                return {"error": str(exc), "choices": []}

        if self._messages_contain_vision(messages):
            ok, reason = self._vision_support_status()
            if not ok:
                logger.warning(reason)
                return {"error": reason, "choices": []}

        # Local inference path
        if self._local_engine and self.provider in ("local", "hybrid"):
            use_local = self.provider == "local" or not self._hybrid_cloud_provider
            if self.provider == "hybrid" and tools:
                use_local = False

            if use_local:
                return await self._chat_local(messages, tools, temperature, max_tokens)

        if self.provider == "anthropic":
            return await self._chat_anthropic(messages, tools, temperature, max_tokens)

        body: dict = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        if tools:
            clean_tools = []
            for tool in tools:
                clean = {k: v for k, v in tool.items() if k != "_feral_meta"}
                clean_tools.append(clean)
            body["tools"] = clean_tools
            body["tool_choice"] = "auto"

        # Reasoning-family param fork: ``/v1/chat/completions`` rejects
        # ``max_tokens`` + free-form ``temperature`` on gpt-5* / o1 /
        # DeepSeek v4-pro / thinking-capable Claude / Gemini -thinking.
        # This is the exact shape of the v2026.5.0 400s in the shipped
        # terminal log (§A5 of docs/WAVE5_HARDENING_PROMPT.md).
        apply_reasoning_fork(self.provider, self.model, body)

        from observability.metrics import increment, measure
        increment("feral.llm.calls_total", attributes={"provider": self.provider, "model": self.model})
        try:
            async def _do_chat():
                resp = await self.client.post("/chat/completions", json=body)
                resp.raise_for_status()
                return resp.json()

            with measure("feral.llm.latency", {"provider": self.provider, "model": self.model}):
                result = await _retry_llm_call(_do_chat)
            return result
        except httpx.HTTPStatusError as e:
            increment("feral.llm.errors_total", attributes={"provider": self.provider, "model": self.model})
            logger.error(f"LLM API error: {e.response.status_code} — {e.response.text[:500]}")
            return {"error": str(e), "choices": []}
        except Exception as e:
            increment("feral.llm.errors_total", attributes={"provider": self.provider, "model": self.model})
            logger.error(f"LLM call failed: {e}")
            return {"error": str(e), "choices": []}

    def extract_response(self, data: dict) -> tuple[Optional[str], list[dict]]:
        """
        Extract the text response and tool calls from an LLM response.
        Returns: (text_content, tool_calls)
        """
        if "error" in data or not data.get("choices"):
            return data.get("error", "No response from LLM"), []

        choice = data["choices"][0]
        message = choice.get("message", {})
        text = message.get("content", "")
        tool_calls = message.get("tool_calls", [])

        parsed_tools = []
        for tc in tool_calls:
            func = tc.get("function", {})
            try:
                args = json.loads(func.get("arguments", "{}"))
            except json.JSONDecodeError:
                args = {}
            parsed_tools.append({
                "id": tc.get("id", ""),
                "name": func.get("name", ""),
                "args": args,
            })

        return text, parsed_tools

    @staticmethod
    def _messages_contain_vision(messages: list[dict]) -> bool:
        for msg in messages:
            content = msg.get("content")
            if isinstance(content, list):
                for block in content:
                    if isinstance(block, dict):
                        block_type = str(block.get("type", ""))
                        if block_type in ("image_url", "input_image", "image", "image_base64"):
                            return True
                        if "image_url" in block:
                            return True
            elif isinstance(content, dict):
                block_type = str(content.get("type", ""))
                if block_type in ("image_url", "input_image", "image", "image_base64"):
                    return True
                if "image_url" in content:
                    return True
        return False

    def _vision_support_status(self) -> tuple[bool, str]:
        if self.provider in ("openai", "gemini"):
            return True, ""

        # OpenRouter is a router — vision capability is per-route, not
        # per-provider. The v2026.5.0 terminal log showed this call
        # early-returning "does not support vision" on every image send
        # because the adapter's _capabilities omitted "vision". The
        # adapter fix adds vision to the superset; here we consult the
        # narrower ``_capabilities_for_model`` when the catalog knows
        # the route's modality, and otherwise trust the superset.
        if self.provider == "openrouter":
            ok, narrow_reason = _openrouter_route_supports_vision(self.model)
            if ok:
                return True, ""
            return False, narrow_reason

        # Anthropic, DeepSeek, Groq all support vision on their
        # frontier chat models; the provider registry already carries
        # that signal in the bundled ``_capabilities`` set. If we
        # ever ship a text-only Anthropic build the per-model hook
        # ``_capabilities_for_model`` narrows this.
        if self.provider in ("anthropic", "deepseek", "groq"):
            return True, ""

        if self.provider == "ollama":
            model_lower = (self.model or "").lower()
            if any(hint in model_lower for hint in VISION_READY_OLLAMA_MODELS):
                return True, ""
            return (
                False,
                "Current Ollama model does not appear vision-capable. "
                "Use a VLM model such as 'llava' or apply preset 'ollama_vision'.",
            )

        if self.provider in ("local", "hybrid") and self._local_engine:
            if getattr(self._local_engine, "supports_vision", False):
                return True, ""
            return (
                False,
                "Local inference engine is text-only and cannot process images. "
                "Use Ollama VLM for local vision (`provider=ollama`, model `llava`).",
            )

        return False, f"Provider '{self.provider}' does not support vision input."

    async def _chat_anthropic(
        self, messages: list[dict], tools: Optional[list[dict]],
        temperature: float, max_tokens: int,
    ) -> dict:
        """Anthropic Messages API → normalized to OpenAI format."""
        system_text = ""
        conv_messages = []
        for m in messages:
            if m["role"] == "system":
                system_text += m.get("content", "") + "\n"
            else:
                conv_messages.append({"role": m["role"], "content": m.get("content", "")})

        body: dict = {
            "model": self.model,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "messages": conv_messages,
        }
        if system_text.strip():
            body["system"] = system_text.strip()

        if tools:
            anthropic_tools = []
            for t in tools:
                if t.get("type") == "function":
                    fn = t["function"]
                    anthropic_tools.append({
                        "name": fn["name"],
                        "description": fn.get("description", ""),
                        "input_schema": fn.get("parameters", {"type": "object", "properties": {}}),
                    })
            if anthropic_tools:
                body["tools"] = anthropic_tools

        # Reasoning-family fork for Claude thinking-capable models.
        apply_reasoning_fork("anthropic", self.model, body)

        try:
            async def _do_anthropic():
                resp = await self.client.post("/messages", json=body)
                resp.raise_for_status()
                return resp.json()

            data = await _retry_llm_call(_do_anthropic)

            text_parts = []
            tool_calls = []
            for block in data.get("content", []):
                if block.get("type") == "text":
                    text_parts.append(block["text"])
                elif block.get("type") == "tool_use":
                    tool_calls.append({
                        "id": block["id"],
                        "type": "function",
                        "function": {
                            "name": block["name"],
                            "arguments": json.dumps(block.get("input", {})),
                        },
                    })

            msg: dict = {"role": "assistant", "content": "\n".join(text_parts)}
            if tool_calls:
                msg["tool_calls"] = tool_calls

            return {"choices": [{"message": msg, "finish_reason": data.get("stop_reason", "end_turn")}]}
        except httpx.HTTPStatusError as e:
            logger.error(f"Anthropic API error: {e.response.status_code} — {e.response.text[:500]}")
            return {"error": str(e), "choices": []}
        except Exception as e:
            logger.error(f"Anthropic call failed: {e}")
            return {"error": str(e), "choices": []}

    async def _chat_local(
        self, messages: list[dict], tools: Optional[list[dict]],
        temperature: float, max_tokens: int,
    ) -> dict:
        """Run inference through the local engine."""
        try:
            if not self._local_engine.loaded:
                await self._local_engine.load_model()

            prompt = self._local_engine.format_chat(messages, tools)
            text = await self._local_engine.generate(prompt, max_tokens=max_tokens, temperature=temperature)

            clean_text, tool_calls = self._local_engine.parse_tool_calls(text)
            response_msg: dict = {"role": "assistant", "content": clean_text}

            if tool_calls:
                response_msg["tool_calls"] = [
                    {"id": tc["id"], "type": "function",
                     "function": {"name": tc["name"], "arguments": json.dumps(tc["args"])}}
                    for tc in tool_calls
                ]

            return {"choices": [{"message": response_msg, "finish_reason": "stop"}]}
        except Exception as e:
            logger.error(f"Local inference failed: {e}")
            return {"error": str(e), "choices": []}

    async def chat_stream(
        self,
        messages: list[dict],
        tools: Optional[list[dict]] = None,
        temperature: float = 0.7,
        max_tokens: int = 1024,
    ) -> AsyncGenerator[dict, None]:
        """
        Stream a chat completion. Yields delta dicts:
          {"type": "text_delta", "content": "..."}
          {"type": "tool_call_delta", "tool_call": {...}}
          {"type": "done"}
        """
        if self._messages_contain_vision(messages):
            ok, reason = self._vision_support_status()
            if not ok:
                yield {"type": "error", "content": reason}
                return

        # Local streaming path
        if self._local_engine and self.provider in ("local", "hybrid"):
            use_local = self.provider == "local" or not self._hybrid_cloud_provider
            if self.provider == "hybrid" and tools:
                use_local = False
            if use_local:
                try:
                    if not self._local_engine.loaded:
                        await self._local_engine.load_model()
                    prompt = self._local_engine.format_chat(messages, tools)
                    async for token in self._local_engine.generate_stream(prompt, max_tokens=max_tokens, temperature=temperature):
                        yield {"type": "text_delta", "content": token}
                    yield {"type": "done"}
                except Exception as e:
                    yield {"type": "error", "content": str(e)}
                return

        # Anthropic native streaming (Messages API with SSE)
        if self.provider == "anthropic":
            async for delta in self._chat_stream_anthropic(messages, tools, temperature, max_tokens):
                yield delta
            return

        body: dict = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": True,
        }

        if tools:
            clean_tools = [{k: v for k, v in t.items() if k != "_feral_meta"} for t in tools]
            body["tools"] = clean_tools
            body["tool_choice"] = "auto"

        apply_reasoning_fork(self.provider, self.model, body)

        stream_cm = None
        try:
            for _attempt in range(MAX_RETRIES):
                try:
                    stream_cm = self.client.stream("POST", "/chat/completions", json=body)
                    resp = await stream_cm.__aenter__()
                    resp.raise_for_status()
                    break
                except Exception as e:
                    if stream_cm:
                        try:
                            await stream_cm.__aexit__(type(e), e, e.__traceback__)
                        except Exception:
                            pass
                        stream_cm = None
                    err_str = str(e).lower()
                    retriable = any(c in err_str for c in _RETRIABLE_CODES)
                    if not retriable or _attempt == MAX_RETRIES - 1:
                        raise
                    logger.warning("LLM stream connect failed (attempt %d/%d) — retrying",
                                   _attempt + 1, MAX_RETRIES)
                    await asyncio.sleep(RETRY_DELAYS[_attempt])

            accumulated_tool_calls: dict[int, dict] = {}
            async for line in resp.aiter_lines():
                # Tolerate SSE keep-alive comment lines ("keep-alive"
                # ``: ...`` comments and empty lines). DeepSeek's
                # thinking-mode stream, OpenRouter's queue, and some
                # Anthropic variants send these during long reasoning
                # windows; treating them as termination kills the
                # stream prematurely. Per DeepSeek's 2026-04-26 docs
                # the keep-alive can run up to 10 minutes.
                if line is None or line == "" or line.startswith(":"):
                    continue
                if not line.startswith("data: "):
                    continue
                data_str = line[6:].strip()
                if data_str == "[DONE]":
                    for _, tc in sorted(accumulated_tool_calls.items()):
                        try:
                            tc["args"] = json.loads(tc.get("arguments", "{}"))
                        except json.JSONDecodeError:
                            tc["args"] = {}
                        yield {"type": "tool_call_delta", "tool_call": tc}
                    yield {"type": "done"}
                    return

                try:
                    chunk = json.loads(data_str)
                except json.JSONDecodeError:
                    continue

                delta = chunk.get("choices", [{}])[0].get("delta", {})

                if delta.get("content"):
                    yield {"type": "text_delta", "content": delta["content"]}

                for tc_delta in delta.get("tool_calls", []):
                    idx = tc_delta.get("index", 0)
                    if idx not in accumulated_tool_calls:
                        accumulated_tool_calls[idx] = {
                            "id": tc_delta.get("id", ""),
                            "name": "",
                            "arguments": "",
                        }
                    entry = accumulated_tool_calls[idx]
                    func = tc_delta.get("function", {})
                    if func.get("name"):
                        entry["name"] = func["name"]
                    if func.get("arguments"):
                        entry["arguments"] += func["arguments"]
                    if tc_delta.get("id"):
                        entry["id"] = tc_delta["id"]

        except httpx.HTTPStatusError as e:
            logger.error(f"LLM stream error: {e.response.status_code}")
            yield {"type": "error", "content": str(e)}
        except Exception as e:
            logger.error(f"LLM stream failed: {e}")
            yield {"type": "error", "content": str(e)}
        finally:
            if stream_cm:
                try:
                    await stream_cm.__aexit__(None, None, None)
                except Exception:
                    pass

    async def _chat_stream_anthropic(
        self,
        messages: list[dict],
        tools: Optional[list[dict]] = None,
        temperature: float = 0.7,
        max_tokens: int = 1024,
    ) -> AsyncGenerator[dict, None]:
        """Native Anthropic Messages API streaming via SSE."""
        api_key = os.getenv("ANTHROPIC_API_KEY", "")
        system_prompt = ""
        anthropic_messages = []
        for m in messages:
            if m["role"] == "system":
                system_prompt = m["content"] if isinstance(m["content"], str) else str(m["content"])
            else:
                anthropic_messages.append({"role": m["role"], "content": m["content"]})

        body: dict = {
            "model": self.model,
            "messages": anthropic_messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "stream": True,
        }
        if system_prompt:
            body["system"] = system_prompt
        # Thinking-capable Claude models demand ``thinking`` + drop
        # ``temperature`` when streaming; adaptive (Opus 4.7) passes
        # through unchanged.
        apply_reasoning_fork("anthropic", self.model, body)
        if tools:
            body["tools"] = [
                {
                    "name": t.get("function", {}).get("name", t.get("name", "")),
                    "description": t.get("function", {}).get("description", ""),
                    "input_schema": t.get("function", {}).get("parameters", {}),
                }
                for t in tools if t.get("type") == "function" or "function" in t
            ]

        accumulated_tool_calls: dict[str, dict] = {}
        try:
            async with httpx.AsyncClient(timeout=120.0) as client:
                async with client.stream(
                    "POST", "https://api.anthropic.com/v1/messages",
                    headers={
                        "x-api-key": api_key,
                        "anthropic-version": "2023-06-01",
                        "content-type": "application/json",
                    },
                    json=body,
                ) as resp:
                    resp.raise_for_status()
                    current_tool_id = ""
                    async for line in resp.aiter_lines():
                        if not line.startswith("data: "):
                            continue
                        data_str = line[6:].strip()
                        if not data_str:
                            continue
                        try:
                            event = json.loads(data_str)
                        except json.JSONDecodeError:
                            continue

                        event_type = event.get("type", "")

                        if event_type == "content_block_start":
                            block = event.get("content_block", {})
                            if block.get("type") == "tool_use":
                                current_tool_id = block.get("id", "")
                                accumulated_tool_calls[current_tool_id] = {
                                    "id": current_tool_id,
                                    "name": block.get("name", ""),
                                    "arguments": "",
                                }

                        elif event_type == "content_block_delta":
                            delta = event.get("delta", {})
                            if delta.get("type") == "text_delta":
                                yield {"type": "text_delta", "content": delta.get("text", "")}
                            elif delta.get("type") == "input_json_delta":
                                if current_tool_id in accumulated_tool_calls:
                                    accumulated_tool_calls[current_tool_id]["arguments"] += delta.get("partial_json", "")

                        elif event_type == "message_delta":
                            pass

                        elif event_type == "message_stop":
                            for tc in accumulated_tool_calls.values():
                                try:
                                    tc["args"] = json.loads(tc.get("arguments", "{}"))
                                except json.JSONDecodeError:
                                    tc["args"] = {}
                                yield {"type": "tool_call_delta", "tool_call": tc}
                            yield {"type": "done"}
                            return

            yield {"type": "done"}
        except httpx.HTTPStatusError as e:
            logger.error(f"Anthropic stream error: {e.response.status_code}")
            yield {"type": "error", "content": str(e)}
        except Exception as e:
            logger.error(f"Anthropic stream failed: {e}")
            yield {"type": "error", "content": str(e)}

    async def switch_provider(
        self,
        provider: str,
        model: str = "",
        api_key: str = "",
        base_url: str = "",
    ):
        """Hot-swap the LLM provider at runtime.

        ``base_url`` is an optional override; when empty, the adapter
        looks up the default base URL from ``PROVIDER_BASES`` below.
        The override path is what lets the v2 Settings page's
        Save-&-switch endpoint point a user at a self-hosted inference
        URL (lmstudio, ollama, a custom OpenAI-compatible gateway)
        without shipping that literal in the adapter's defaults.

        NOTE: this kwarg was added after W1 in response to the shipped
        v2026.5.0 crash (``api/routes/config.py::update_config`` was
        already passing ``base_url=`` but ``switch_provider`` did not
        accept it -> TypeError -> every Save-&-switch 500'd). The
        regression test lives in
        ``tests/test_switch_provider_base_url.py``.
        """
        client = getattr(self, "client", None)
        if client is not None:
            await client.aclose()

        self.provider = provider
        if model:
            self.model = model

        # Per-provider base URL + env-var lookup. Default model is
        # resolved through the catalog so a switch never lands the
        # user on a deprecated frontier ID.
        PROVIDER_BASES = {
            "ollama": (ollama_openai_base_url(), "OLLAMA_DUMMY"),
            "groq": ("https://api.groq.com/openai/v1", "GROQ_API_KEY"),
            "openai": ("https://api.openai.com/v1", "OPENAI_API_KEY"),
            "anthropic": ("https://api.anthropic.com/v1", "ANTHROPIC_API_KEY"),
            "gemini": ("https://generativelanguage.googleapis.com/v1beta/openai", "_GEMINI_HELPER"),
            "lmstudio": ("http://localhost:1234/v1", ""),
        }

        # Honor the explicit override before the lookup. An empty
        # string is treated as "no override" so legacy callers that
        # always omitted the kwarg keep the auto-resolved default.
        _base_url_override = base_url or ""

        if provider == "lmstudio":
            self.base_url = _base_url_override or "http://localhost:1234/v1"
            self.api_key = "lm-studio"
            if not model:
                detected = self._detect_lmstudio()
                self.model = detected or _default_model_for("lmstudio")
        elif provider == "ollama":
            self.base_url = _base_url_override or ollama_openai_base_url()
            self.api_key = "ollama"
            if not model:
                detected = self._detect_ollama()
                self.model = detected or _default_model_for("ollama")
        elif provider == "local":
            self._init_local_engine()
            if self._local_engine:
                self.available = True
                logger.info(f"Switched to local inference: {self._local_engine.model_id}")
                return
            else:
                logger.warning("Local engine unavailable")
                self.available = False
                return
        elif provider in PROVIDER_BASES:
            base, env_key = PROVIDER_BASES[provider]
            self.base_url = _base_url_override or base
            if env_key == "_GEMINI_HELPER":
                self.api_key = api_key or _gemini_api_key() or ""
            else:
                self.api_key = api_key or os.getenv(env_key, "")
            if not model:
                self.model = _default_model_for(provider)
        else:
            self.base_url = _base_url_override or os.getenv("FERAL_LLM_BASE_URL", "https://api.openai.com/v1")
            self.api_key = api_key
            if not model:
                self.model = _default_model_for(provider)

        self.client = self._build_client()
        self.available = bool(self.api_key)
        logger.info(f"Switched LLM to {provider}/{self.model} (available={self.available})")

    async def reconfigure(
        self,
        *,
        provider: str,
        model: str = "",
        api_key: str = "",
        base_url: str = "",
    ) -> dict:
        """Hot-swap provider / model / key / base_url in one call.

        Same wire as ``switch_provider`` but:
          * accepts ``base_url`` so local providers (LM Studio, custom
            Ollama port) can land end-to-end from the Settings form;
          * returns a structured result the REST layer can surface to
            the UI (``{provider, model, available, reason}``);
          * emits a supervisor event so the swap lands in the audit
            log right alongside user commands.
        """
        if base_url:
            os.environ["FERAL_LLM_BASE_URL"] = base_url
        previous_provider = self.provider
        try:
            await self.switch_provider(provider=provider, model=model, api_key=api_key)
        except Exception as exc:
            logger.warning("reconfigure(%s) failed: %s", provider, exc)
            return {
                "ok": False,
                "provider": provider,
                "model": model,
                "available": False,
                "reason": str(exc),
            }

        reason = "ok" if self.available else "no_api_key"
        try:
            from api.state import state as _state
            sup = getattr(_state, "supervisor", None)
            if sup is not None:
                sup.record(
                    source="config",
                    kind="llm_reconfigure",
                    actor="user",
                    payload={
                        "from": previous_provider,
                        "to": self.provider,
                        "model": self.model,
                        "has_key": bool(self.api_key),
                    },
                    decision="allowed" if self.available else "queued",
                    detail={"reason": reason, "base_url": self.base_url},
                )
        except Exception as exc:
            logger.debug("supervisor.record(llm_reconfigure) failed: %s", exc)

        return {
            "ok": True,
            "provider": self.provider,
            "model": self.model,
            "available": bool(self.available),
            "base_url": self.base_url,
            "reason": reason,
        }

    async def apply_preset(self, preset_id: str) -> dict:
        preset = LLM_PRESETS.get(preset_id)
        if not preset:
            return {"ok": False, "error": f"Unknown preset: {preset_id}"}
        await self.switch_provider(
            provider=preset["provider"],
            model=preset.get("model", ""),
            api_key="",
        )
        return {
            "ok": True,
            "preset": preset_id,
            "provider": self.provider,
            "model": self.model,
            "vision_supported": bool(preset.get("vision_supported", False)),
        }

    # ── Failover ───────────────────────────────────────────

    def set_config(self, config: dict):
        """Accept external config (e.g. from ConfigLoader) for fallback routing."""
        self._config = config

    def set_catalog(self, catalog) -> None:
        """Attach the shared :class:`ProviderCatalog` for metadata lookups.

        Commit 1 only stores the reference; the runtime keeps reading
        its primary config from env vars exactly as before so this is
        backward-compatible. Commit 3 flips the primary source over to
        the catalog once every adapter has been reviewed.
        """
        self._catalog = catalog

    @staticmethod
    def _normalize_anthropic_response(data: dict) -> dict:
        """Convert raw Anthropic Messages API response to OpenAI-shaped dict."""
        text_parts: list[str] = []
        tool_calls: list[dict] = []
        for block in data.get("content", []):
            if block.get("type") == "text":
                text_parts.append(block["text"])
            elif block.get("type") == "tool_use":
                tool_calls.append({
                    "id": block["id"],
                    "type": "function",
                    "function": {
                        "name": block["name"],
                        "arguments": json.dumps(block.get("input", {})),
                    },
                })
        msg: dict = {"role": "assistant", "content": "\n".join(text_parts)}
        if tool_calls:
            msg["tool_calls"] = tool_calls
        return {"choices": [{"message": msg, "finish_reason": data.get("stop_reason", "end_turn")}]}

    def _get_provider_config(self, provider_name: str) -> dict:
        """Resolve base_url / api_key / model for a named provider.

        The model is always resolved through the shared catalog so the
        failover candidate list never contains a stale literal.
        """
        if provider_name == "ollama":
            return {
                "base_url": ollama_openai_base_url(),
                "api_key": "ollama",
                "model": _default_model_for("ollama") or self._detect_ollama() or "",
            }
        if provider_name == "lmstudio":
            detected = self._detect_lmstudio()
            return {
                "base_url": "http://localhost:1234/v1",
                "api_key": "lm-studio",
                "model": detected or _default_model_for("lmstudio"),
            }
        reg = _PROVIDER_REGISTRY.get(
            provider_name,
            ("https://api.openai.com/v1", "OPENAI_API_KEY"),
        )
        base_url, env_key = reg
        if provider_name == "gemini":
            api_key = _gemini_api_key() or ""
        else:
            api_key = os.getenv(env_key, "")
        return {
            "base_url": base_url,
            "api_key": api_key,
            "model": _default_model_for(provider_name),
        }

    def _build_candidate_list(self) -> list[tuple[str, dict]]:
        """Ordered list of (provider_name, config) — primary first, then fallbacks."""
        candidates: list[tuple[str, dict]] = [
            (self.provider, {"base_url": self.base_url, "api_key": self.api_key, "model": self.model}),
        ]
        for fb in self._config.get("fallback_providers", []):
            if fb != self.provider:
                candidates.append((fb, self._get_provider_config(fb)))
        return candidates

    @staticmethod
    def _build_anthropic_body(
        model: str, messages: list[dict], tools: Optional[list[dict]],
        temperature: float, max_tokens: int,
    ) -> dict:
        """Build Anthropic Messages API request body."""
        system_text = ""
        conv: list[dict] = []
        for m in messages:
            if m["role"] == "system":
                system_text += m.get("content", "") + "\n"
            else:
                conv.append({"role": m["role"], "content": m.get("content", "")})
        body: dict = {
            "model": model,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "messages": conv,
        }
        if system_text.strip():
            body["system"] = system_text.strip()
        if tools:
            anthropic_tools = []
            for t in tools:
                if t.get("type") == "function":
                    fn = t["function"]
                    anthropic_tools.append({
                        "name": fn["name"],
                        "description": fn.get("description", ""),
                        "input_schema": fn.get("parameters", {"type": "object", "properties": {}}),
                    })
            if anthropic_tools:
                body["tools"] = anthropic_tools
        apply_reasoning_fork("anthropic", model, body)
        return body

    async def _call_provider(
        self,
        provider_name: str,
        config: dict,
        messages: list[dict],
        tools: Optional[list[dict]],
        **kwargs,
    ) -> dict:
        """Make a chat request to a specific provider. Raises on error."""
        temperature = kwargs.get("temperature", 0.7)
        max_tokens = kwargs.get("max_tokens", 1024)

        # Primary provider — reuse existing client
        if provider_name == self.provider:
            if provider_name == "anthropic":
                body = self._build_anthropic_body(
                    self.model, messages, tools, temperature, max_tokens,
                )

                async def _do_primary_anthropic():
                    resp = await self.client.post("/messages", json=body)
                    resp.raise_for_status()
                    return resp.json()

                data = await _retry_llm_call(_do_primary_anthropic)
                return self._normalize_anthropic_response(data)

            body = {
                "model": self.model,
                "messages": messages,
                "temperature": temperature,
                "max_tokens": max_tokens,
            }
            if tools:
                body["tools"] = [{k: v for k, v in t.items() if k != "_feral_meta"} for t in tools]
                body["tool_choice"] = "auto"

            apply_reasoning_fork(self.provider, self.model, body)

            async def _do_primary():
                resp = await self.client.post("/chat/completions", json=body)
                resp.raise_for_status()
                return resp.json()

            return await _retry_llm_call(_do_primary)

        # Fallback provider — build a temporary client
        base_url = config["base_url"]
        api_key = config["api_key"]
        model = config["model"]
        if not api_key:
            raise RuntimeError(f"No API key configured for fallback provider '{provider_name}'")

        headers: dict[str, str] = {"Content-Type": "application/json"}
        if provider_name == "anthropic":
            headers["x-api-key"] = api_key
            headers["anthropic-version"] = "2023-06-01"
        else:
            headers["Authorization"] = f"Bearer {api_key}"

        async with httpx.AsyncClient(base_url=base_url, headers=headers, timeout=60.0) as tmp:
            if provider_name == "anthropic":
                body = self._build_anthropic_body(
                    model, messages, tools, temperature, max_tokens,
                )

                async def _do_fb_anthropic():
                    resp = await tmp.post("/messages", json=body)
                    resp.raise_for_status()
                    return resp.json()

                data = await _retry_llm_call(_do_fb_anthropic)
                return self._normalize_anthropic_response(data)

            body = {
                "model": model,
                "messages": messages,
                "temperature": temperature,
                "max_tokens": max_tokens,
            }
            if tools:
                body["tools"] = [{k: v for k, v in t.items() if k != "_feral_meta"} for t in tools]
                body["tool_choice"] = "auto"

            apply_reasoning_fork(provider_name, model, body)

            async def _do_fb():
                resp = await tmp.post("/chat/completions", json=body)
                resp.raise_for_status()
                return resp.json()

            return await _retry_llm_call(_do_fb)

    async def chat_with_failover(
        self,
        messages: list[dict],
        tools: Optional[list[dict]] = None,
        **kwargs,
    ) -> dict:
        """Call chat() with automatic failover across configured providers.

        Same-provider transient retries are handled by ``_retry_llm_call``.
        Cross-provider routing is handled here based on error classification.
        """
        if self._messages_contain_vision(messages):
            ok, reason = self._vision_support_status()
            if not ok:
                logger.warning(reason)
                return {"error": reason, "choices": []}

        if self._local_engine and self.provider in ("local", "hybrid"):
            return await self.chat(messages, tools, **kwargs)

        from observability.metrics import increment, measure

        candidates = self._build_candidate_list()
        last_error: Optional[Exception] = None

        for provider_name, config in candidates:
            if not self._cooldown.should_probe(provider_name):
                continue
            increment("feral.llm.calls_total", attributes={"provider": provider_name, "model": config.get("model", self.model)})
            try:
                with measure("feral.llm.latency", {"provider": provider_name, "model": config.get("model", self.model)}):
                    result = await self._call_provider(provider_name, config, messages, tools, **kwargs)
                self._cooldown.record_success(provider_name)
                return result
            except Exception as e:
                increment("feral.llm.errors_total", attributes={"provider": provider_name})
                reason = classify_error(e)
                self._cooldown.record_failure(provider_name, reason)
                logger.warning("Provider %s failed (%s): %s", provider_name, reason.value, e)
                last_error = e
                if reason == FailoverReason.CONTEXT_OVERFLOW:
                    raise
                continue

        if last_error:
            raise last_error
        raise RuntimeError("All LLM providers exhausted")

    def health_snapshot(self) -> dict:
        """Return a snapshot of every candidate provider's availability.

        Used by `GET /api/llm/health` to power the v2 "Fallbacks" card —
        the user can see which providers are live, which are in cooldown,
        and why, without having to dig through server logs.
        """
        now = time.time()
        primary = {
            "provider": self.provider,
            "model": self.model,
            "has_key": bool(self.api_key) and self.api_key not in ("none", ""),
            "available": bool(self.available),
            "base_url": self.base_url,
        }
        candidates = []
        try:
            candidate_list = self._build_candidate_list()
        except Exception:
            candidate_list = [(self.provider, {
                "base_url": self.base_url, "api_key": self.api_key, "model": self.model,
            })]
        for name, cfg in candidate_list:
            until = self._cooldown._cooldowns.get(name, 0.0)
            in_cooldown = until > now
            candidates.append({
                "provider": name,
                "model": cfg.get("model") or "",
                "base_url": cfg.get("base_url") or "",
                "has_key": bool(cfg.get("api_key")) and cfg.get("api_key") not in ("none", ""),
                "in_cooldown": in_cooldown,
                "cooldown_until": until if in_cooldown else None,
                "cooldown_remaining": max(0.0, until - now) if in_cooldown else 0.0,
            })
        fallbacks = list(self._config.get("fallback_providers", [])) if isinstance(self._config, dict) else []
        return {
            "active": primary,
            "candidates": candidates,
            "fallback_providers": fallbacks,
            "total_available": sum(1 for c in candidates if c["has_key"] and not c["in_cooldown"]),
        }

    def is_available(self) -> bool:
        """True if at least one provider has a valid key and is not in cooldown."""
        if not self.available:
            return False
        if self._local_engine and self.provider in ("local", "hybrid"):
            return True
        if self.provider in ("ollama", "lmstudio"):
            return True
        if self.api_key and self.api_key not in ("none", ""):
            if self._cooldown.is_available(self.provider):
                return True
        for fb in self._config.get("fallback_providers", []):
            if fb == self.provider:
                continue
            cfg = self._get_provider_config(fb)
            if cfg.get("api_key") and self._cooldown.is_available(fb):
                return True
        return False

    async def close(self):
        client = getattr(self, "client", None)
        if client is not None:
            await client.aclose()
