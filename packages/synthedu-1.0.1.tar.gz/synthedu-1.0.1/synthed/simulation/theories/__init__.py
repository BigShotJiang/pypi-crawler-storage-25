"""Theory-specific modules extracted from SimulationEngine."""
from __future__ import annotations

from .tinto import TintoIntegration
from .bean_metzner import BeanMetznerPressure
from .kember import KemberCostBenefit
from .baulke import BaulkeDropoutPhase
from .garrison_coi import GarrisonCoI
from .moore_td import MooreTransactionalDistance
from .epstein_axtell import EpsteinAxtellPeerInfluence
from .rovai import RovaiPersistence
from .sdt_motivation import SDTMotivationDynamics, SDTNeedSatisfaction
from .positive_events import PositiveEventHandler
from .academic_exhaustion import GonzalezExhaustion, ExhaustionState
from .unavoidable_withdrawal import UnavoidableWithdrawal

__all__ = [
    "TintoIntegration",
    "BeanMetznerPressure",
    "KemberCostBenefit",
    "BaulkeDropoutPhase",
    "GarrisonCoI",
    "MooreTransactionalDistance",
    "EpsteinAxtellPeerInfluence",
    "RovaiPersistence",
    "SDTMotivationDynamics",
    "SDTNeedSatisfaction",
    "PositiveEventHandler",
    "GonzalezExhaustion",
    "ExhaustionState",
    "UnavoidableWithdrawal",
]
