"""Standard SPIFFE Workload API gRPC client.

Wraps the generated gRPC stub in the ergonomic surface described by the README
and the TypeScript SDK: an ``x509`` source, a ``jwt`` source, and
:meth:`watch_x509_context` for long-running workloads.
"""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from typing import Any

import grpc

from .._generated import workloadapi_pb2, workloadapi_pb2_grpc
from .._internal.channel import build_channel
from ..errors import SpiffeError, SpiffeErrorCode
from ..jwtsvid.types import JwtBundle, JwtSVID
from ..spiffe_id import TrustDomain
from ..workload_api.context import X509Context
from ..x509svid.types import X509SVID, X509Bundle
from .helpers import (
    parse_first_jwt_svid,
    parse_jwt_bundles_map,
    parse_x509_bundles_map,
    parse_x509_svid_response,
    wrap_rpc_error,
)
from .options import ClientOptions, resolve_client_options

_SPIFFE_HEADER = ("workload.spiffe.io", "true")
_RECONNECT_INITIAL_BACKOFF = 0.1  # seconds
_RECONNECT_MAX_BACKOFF = 5.0


class _X509Source:
    """Namespace-style handle exposed as ``client.x509``."""

    __slots__ = ("_client",)

    def __init__(self, client: LocalWorkloadAPIClient) -> None:
        self._client = client

    async def get_svid(self) -> X509SVID:
        ctx = await self._client._fetch_x509_context()
        return ctx.default_svid()

    async def get_bundle_for_trust_domain(self, trust_domain: TrustDomain) -> X509Bundle:
        return await self._client._get_x509_bundle(trust_domain)

    def watch_svid(self) -> AsyncIterator[X509SVID]:
        async def _iter() -> AsyncIterator[X509SVID]:
            async for ctx in self._client.watch_x509_context():
                yield ctx.default_svid()

        return _iter()


class _JwtSource:
    """Namespace-style handle exposed as ``client.jwt``."""

    __slots__ = ("_client",)

    def __init__(self, client: LocalWorkloadAPIClient) -> None:
        self._client = client

    async def fetch_svid(self, audiences: list[str]) -> JwtSVID:
        return await self._client._fetch_jwt_svid(audiences)

    async def get_bundle_for_trust_domain(self, trust_domain: TrustDomain) -> JwtBundle:
        return await self._client._get_jwt_bundle(trust_domain)


class LocalWorkloadAPIClient:
    """Client for the standard SPIFFE Workload API.

    Speaks gRPC to a locally-running SPIRE agent (or any compliant SPIFFE
    agent) over a Unix domain socket or TCP, and exposes two namespaces:

    - :attr:`x509` — X.509 SVIDs and trust bundles.
    - :attr:`jwt` — JWT SVIDs and trust bundles.

    For long-running workloads, :meth:`watch_x509_context` returns an async
    iterator that yields a new :class:`X509Context` on every rotation, with
    automatic reconnect when the underlying stream ends cleanly.

    Use the client as an async context manager (``async with``) to ensure the
    gRPC channel is closed when you're done.
    """

    x509: _X509Source
    jwt: _JwtSource

    def __init__(self, options: ClientOptions | None = None) -> None:
        resolved = resolve_client_options(options)
        self._channel = build_channel(resolved)
        self._stub = workloadapi_pb2_grpc.SpiffeWorkloadAPIStub(self._channel)
        self._closed = False
        self._active_streams: set[grpc.aio.StreamStreamCall | grpc.aio.UnaryStreamCall] = set()

        self.x509 = _X509Source(self)
        self.jwt = _JwtSource(self)

    # ------------------------------------------------------------------ X.509
    async def _fetch_x509_context(self) -> X509Context:
        first = await self._first_of(
            self._stub.FetchX509SVID(
                workloadapi_pb2.X509SVIDRequest(),
                metadata=(_SPIFFE_HEADER,),
            )
        )
        if first is None:
            raise SpiffeError(
                SpiffeErrorCode.WORKLOAD_API_ERROR,
                "No response from Workload API",
            )
        svids, bundles = parse_x509_svid_response(list(first.svids), first.federated_bundles)
        return X509Context(svids=svids, bundles=bundles)

    async def _get_x509_bundle(self, trust_domain: TrustDomain) -> X509Bundle:
        first = await self._first_of(
            self._stub.FetchX509Bundles(
                workloadapi_pb2.X509BundlesRequest(),
                metadata=(_SPIFFE_HEADER,),
            )
        )
        if first is None:
            raise SpiffeError(
                SpiffeErrorCode.WORKLOAD_API_ERROR,
                "No response from Workload API",
            )
        bundles = parse_x509_bundles_map(first.bundles)
        bundle = bundles.get(trust_domain.name)
        if bundle is None:
            raise SpiffeError(
                SpiffeErrorCode.BUNDLE_NOT_FOUND,
                f"No X.509 bundle found for trust domain {trust_domain.name!r}",
            )
        return bundle

    # ------------------------------------------------------------------ JWT
    async def _fetch_jwt_svid(self, audiences: list[str]) -> JwtSVID:
        try:
            resp = await self._stub.FetchJWTSVID(
                workloadapi_pb2.JWTSVIDRequest(audience=audiences),
                metadata=(_SPIFFE_HEADER,),
            )
        except grpc.aio.AioRpcError as exc:
            raise wrap_rpc_error(exc) from exc
        return parse_first_jwt_svid(list(resp.svids))

    async def _get_jwt_bundle(self, trust_domain: TrustDomain) -> JwtBundle:
        first = await self._first_of(
            self._stub.FetchJWTBundles(
                workloadapi_pb2.JWTBundlesRequest(),
                metadata=(_SPIFFE_HEADER,),
            )
        )
        if first is None:
            raise SpiffeError(
                SpiffeErrorCode.WORKLOAD_API_ERROR,
                "No response from Workload API",
            )
        bundles = parse_jwt_bundles_map(first.bundles)
        bundle = bundles.get(trust_domain.name)
        if bundle is None:
            raise SpiffeError(
                SpiffeErrorCode.BUNDLE_NOT_FOUND,
                f"No JWT bundle found for trust domain {trust_domain.name!r}",
            )
        return bundle

    # ------------------------------------------------------------------ watch
    async def watch_x509_context(self) -> AsyncIterator[X509Context]:
        """Yield a new :class:`X509Context` each time the SVID is rotated.

        The server-streaming RPC reconnects automatically when the stream ends
        cleanly. A small jittered backoff between reconnects prevents a
        misbehaving agent from turning this into a busy loop. Transport errors
        are raised to the caller. Iteration ends when :meth:`close` is called.
        """
        yielded_any = False
        backoff = _RECONNECT_INITIAL_BACKOFF
        while not self._closed:
            stream = self._stub.FetchX509SVID(
                workloadapi_pb2.X509SVIDRequest(),
                metadata=(_SPIFFE_HEADER,),
            )
            self._active_streams.add(stream)
            try:
                async for resp in stream:
                    if self._closed:
                        return
                    svids, bundles = parse_x509_svid_response(
                        list(resp.svids), resp.federated_bundles
                    )
                    yielded_any = True
                    backoff = _RECONNECT_INITIAL_BACKOFF
                    yield X509Context(svids=svids, bundles=bundles)
            except grpc.aio.AioRpcError as exc:
                if self._closed:
                    return
                raise wrap_rpc_error(exc) from exc
            finally:
                self._active_streams.discard(stream)
            # Stream ended cleanly. If the agent never sent anything, back off
            # before reconnecting so we don't spin a tight loop.
            if not yielded_any:
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, _RECONNECT_MAX_BACKOFF)
            yielded_any = False

    # ------------------------------------------------------------------ cleanup
    async def close(self) -> None:
        """Cancel in-flight streams and close the underlying gRPC channel."""
        if self._closed:
            return
        self._closed = True
        for stream in list(self._active_streams):
            stream.cancel()
        self._active_streams.clear()
        await self._channel.close()

    async def __aenter__(self) -> LocalWorkloadAPIClient:
        return self

    async def __aexit__(self, *_exc_info: object) -> None:
        await self.close()

    async def _first_of(self, stream: Any) -> Any:
        self._active_streams.add(stream)
        try:
            async for item in stream:
                stream.cancel()
                return item
        except grpc.aio.AioRpcError as exc:
            raise wrap_rpc_error(exc) from exc
        finally:
            self._active_streams.discard(stream)
        return None
