"""SPIFFE Workload API client for local SPIRE agents."""

from .client import LocalWorkloadAPIClient
from .options import ClientOptions, TcpOptions, UnixOptions

__all__ = ["ClientOptions", "LocalWorkloadAPIClient", "TcpOptions", "UnixOptions"]
