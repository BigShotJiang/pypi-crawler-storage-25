"""Azure ``TokenCredential`` implementation backed by a SPIFFE JWT SVID.

Requires the ``azure`` optional dependency::

    pip install 'spiffe-defakto[azure]'
"""

from .credential import SPIFFECredential, SPIFFECredentialOptions

__all__ = ["SPIFFECredential", "SPIFFECredentialOptions"]
