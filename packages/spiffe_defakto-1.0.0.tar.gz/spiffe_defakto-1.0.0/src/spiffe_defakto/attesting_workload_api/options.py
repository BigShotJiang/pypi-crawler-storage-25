"""Options for :class:`AttestingWorkloadAPIClient`."""

from __future__ import annotations

from dataclasses import dataclass, field

from ..attestation.types import Attestor
from ..local_workload_api.options import ClientOptions


@dataclass(frozen=True, slots=True)
class AttestingClientOptions:
    """Configuration for the Defakto attesting client.

    - ``attestors`` holds the evidence sources to use. If empty, the client
      consults ``DEFAKTO_ATTESTORS`` instead.
    - ``trust_domain_id`` is your Defakto trust-domain identifier. When set
      and no ``transport`` is supplied, the endpoint resolves to
      ``<trust_domain_id>.agent.spirl.com:443`` over TLS.
    - ``transport`` overrides the resolved endpoint for advanced setups
      (self-hosted endpoints, local testing, etc.).
    """

    attestors: tuple[Attestor, ...] = field(default_factory=tuple)
    trust_domain_id: str | None = None
    transport: ClientOptions | None = None
