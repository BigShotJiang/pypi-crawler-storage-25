"""Response parsing for Defakto's serverless attestation API.

The schema wraps the underlying SVID/bundle payloads in an optional "result"
message that is only populated when every required attestation is satisfied.
"""

from __future__ import annotations

from typing import Any

from ..errors import SpiffeError, SpiffeErrorCode
from ..jwtsvid.types import JwtBundle, JwtSVID
from ..local_workload_api.helpers import (
    parse_jwt_bundles_map,
    parse_jwt_svid_from_proto,
    parse_x509_bundle,
    parse_x509_svid_response,
)
from ..spiffe_id import TrustDomain
from ..x509svid.types import X509SVID, X509Bundle


def parse_serverless_x509_response(
    response: Any,
) -> tuple[tuple[X509SVID, ...], dict[str, X509Bundle]]:
    if not response.HasField("x509_svids"):
        raise SpiffeError(
            SpiffeErrorCode.ATTESTATION_FAILED,
            "Endpoint did not return X.509 SVIDs — attestation likely incomplete",
        )
    result = response.x509_svids
    return parse_x509_svid_response(list(result.svids), result.federated_bundles)


def parse_serverless_x509_bundles(response: Any) -> dict[str, X509Bundle]:
    if not response.HasField("bundles"):
        raise SpiffeError(
            SpiffeErrorCode.ATTESTATION_FAILED,
            "Endpoint did not return X.509 bundles — attestation likely incomplete",
        )
    result: dict[str, X509Bundle] = {}
    for domain_name, der_bytes in response.bundles.bundles.items():
        try:
            td = TrustDomain.parse(domain_name)
            result[td.name] = parse_x509_bundle(td, bytes(der_bytes))
        except SpiffeError:
            continue
    return result


def parse_serverless_jwt_svid(response: Any) -> JwtSVID:
    if not response.HasField("jwt_svids"):
        raise SpiffeError(
            SpiffeErrorCode.ATTESTATION_FAILED,
            "Endpoint did not return JWT SVIDs — attestation likely incomplete",
        )
    result = response.jwt_svids
    if not result.svids:
        raise SpiffeError(SpiffeErrorCode.WORKLOAD_API_ERROR, "No JWT SVIDs in response")
    return parse_jwt_svid_from_proto(result.svids[0])


def parse_serverless_jwt_bundles(response: Any) -> dict[str, JwtBundle]:
    if not response.HasField("bundles"):
        raise SpiffeError(
            SpiffeErrorCode.ATTESTATION_FAILED,
            "Endpoint did not return JWT bundles — attestation likely incomplete",
        )
    return parse_jwt_bundles_map(response.bundles.bundles)
