from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class MethodAttestation(_message.Message):
    __slots__ = ("method_type", "method_version", "evidence")
    METHOD_TYPE_FIELD_NUMBER: _ClassVar[int]
    METHOD_VERSION_FIELD_NUMBER: _ClassVar[int]
    EVIDENCE_FIELD_NUMBER: _ClassVar[int]
    method_type: str
    method_version: str
    evidence: bytes
    def __init__(
        self,
        method_type: _Optional[str] = ...,
        method_version: _Optional[str] = ...,
        evidence: _Optional[bytes] = ...,
    ) -> None: ...

class FetchX509SVIDRequest(_message.Message):
    __slots__ = ("attestations",)
    ATTESTATIONS_FIELD_NUMBER: _ClassVar[int]
    attestations: _containers.RepeatedCompositeFieldContainer[MethodAttestation]
    def __init__(
        self, attestations: _Optional[_Iterable[_Union[MethodAttestation, _Mapping]]] = ...
    ) -> None: ...

class FetchX509SVIDResponse(_message.Message):
    __slots__ = ("x509_svids",)
    X509_SVIDS_FIELD_NUMBER: _ClassVar[int]
    x509_svids: X509SVIDResult
    def __init__(self, x509_svids: _Optional[_Union[X509SVIDResult, _Mapping]] = ...) -> None: ...

class X509SVIDResult(_message.Message):
    __slots__ = ("svids", "federated_bundles")
    class FederatedBundlesEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: bytes
        def __init__(self, key: _Optional[str] = ..., value: _Optional[bytes] = ...) -> None: ...

    SVIDS_FIELD_NUMBER: _ClassVar[int]
    FEDERATED_BUNDLES_FIELD_NUMBER: _ClassVar[int]
    svids: _containers.RepeatedCompositeFieldContainer[X509SVID]
    federated_bundles: _containers.ScalarMap[str, bytes]
    def __init__(
        self,
        svids: _Optional[_Iterable[_Union[X509SVID, _Mapping]]] = ...,
        federated_bundles: _Optional[_Mapping[str, bytes]] = ...,
    ) -> None: ...

class X509SVID(_message.Message):
    __slots__ = ("spiffe_id", "x509_svid", "x509_svid_key", "bundle", "hint")
    SPIFFE_ID_FIELD_NUMBER: _ClassVar[int]
    X509_SVID_FIELD_NUMBER: _ClassVar[int]
    X509_SVID_KEY_FIELD_NUMBER: _ClassVar[int]
    BUNDLE_FIELD_NUMBER: _ClassVar[int]
    HINT_FIELD_NUMBER: _ClassVar[int]
    spiffe_id: str
    x509_svid: bytes
    x509_svid_key: bytes
    bundle: bytes
    hint: str
    def __init__(
        self,
        spiffe_id: _Optional[str] = ...,
        x509_svid: _Optional[bytes] = ...,
        x509_svid_key: _Optional[bytes] = ...,
        bundle: _Optional[bytes] = ...,
        hint: _Optional[str] = ...,
    ) -> None: ...

class FetchX509BundlesRequest(_message.Message):
    __slots__ = ("attestations",)
    ATTESTATIONS_FIELD_NUMBER: _ClassVar[int]
    attestations: _containers.RepeatedCompositeFieldContainer[MethodAttestation]
    def __init__(
        self, attestations: _Optional[_Iterable[_Union[MethodAttestation, _Mapping]]] = ...
    ) -> None: ...

class FetchX509BundlesResponse(_message.Message):
    __slots__ = ("bundles",)
    BUNDLES_FIELD_NUMBER: _ClassVar[int]
    bundles: X509BundlesResult
    def __init__(self, bundles: _Optional[_Union[X509BundlesResult, _Mapping]] = ...) -> None: ...

class X509BundlesResult(_message.Message):
    __slots__ = ("bundles",)
    class BundlesEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: bytes
        def __init__(self, key: _Optional[str] = ..., value: _Optional[bytes] = ...) -> None: ...

    BUNDLES_FIELD_NUMBER: _ClassVar[int]
    bundles: _containers.ScalarMap[str, bytes]
    def __init__(self, bundles: _Optional[_Mapping[str, bytes]] = ...) -> None: ...

class FetchJWTSVIDRequest(_message.Message):
    __slots__ = ("attestations", "audience", "spiffe_id")
    ATTESTATIONS_FIELD_NUMBER: _ClassVar[int]
    AUDIENCE_FIELD_NUMBER: _ClassVar[int]
    SPIFFE_ID_FIELD_NUMBER: _ClassVar[int]
    attestations: _containers.RepeatedCompositeFieldContainer[MethodAttestation]
    audience: _containers.RepeatedScalarFieldContainer[str]
    spiffe_id: str
    def __init__(
        self,
        attestations: _Optional[_Iterable[_Union[MethodAttestation, _Mapping]]] = ...,
        audience: _Optional[_Iterable[str]] = ...,
        spiffe_id: _Optional[str] = ...,
    ) -> None: ...

class FetchJWTSVIDResponse(_message.Message):
    __slots__ = ("jwt_svids",)
    JWT_SVIDS_FIELD_NUMBER: _ClassVar[int]
    jwt_svids: JWTSVIDResult
    def __init__(self, jwt_svids: _Optional[_Union[JWTSVIDResult, _Mapping]] = ...) -> None: ...

class JWTSVIDResult(_message.Message):
    __slots__ = ("svids",)
    SVIDS_FIELD_NUMBER: _ClassVar[int]
    svids: _containers.RepeatedCompositeFieldContainer[JWTSVID]
    def __init__(self, svids: _Optional[_Iterable[_Union[JWTSVID, _Mapping]]] = ...) -> None: ...

class JWTSVID(_message.Message):
    __slots__ = ("spiffe_id", "svid", "hint")
    SPIFFE_ID_FIELD_NUMBER: _ClassVar[int]
    SVID_FIELD_NUMBER: _ClassVar[int]
    HINT_FIELD_NUMBER: _ClassVar[int]
    spiffe_id: str
    svid: str
    hint: str
    def __init__(
        self,
        spiffe_id: _Optional[str] = ...,
        svid: _Optional[str] = ...,
        hint: _Optional[str] = ...,
    ) -> None: ...

class FetchJWTBundlesRequest(_message.Message):
    __slots__ = ("attestations",)
    ATTESTATIONS_FIELD_NUMBER: _ClassVar[int]
    attestations: _containers.RepeatedCompositeFieldContainer[MethodAttestation]
    def __init__(
        self, attestations: _Optional[_Iterable[_Union[MethodAttestation, _Mapping]]] = ...
    ) -> None: ...

class FetchJWTBundlesResponse(_message.Message):
    __slots__ = ("bundles",)
    BUNDLES_FIELD_NUMBER: _ClassVar[int]
    bundles: JWTBundlesResult
    def __init__(self, bundles: _Optional[_Union[JWTBundlesResult, _Mapping]] = ...) -> None: ...

class JWTBundlesResult(_message.Message):
    __slots__ = ("bundles",)
    class BundlesEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: bytes
        def __init__(self, key: _Optional[str] = ..., value: _Optional[bytes] = ...) -> None: ...

    BUNDLES_FIELD_NUMBER: _ClassVar[int]
    bundles: _containers.ScalarMap[str, bytes]
    def __init__(self, bundles: _Optional[_Mapping[str, bytes]] = ...) -> None: ...
