from google.protobuf import struct_pb2 as _struct_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class X509SVIDRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class X509SVIDResponse(_message.Message):
    __slots__ = ("svids", "crl", "federated_bundles")
    class FederatedBundlesEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: bytes
        def __init__(self, key: _Optional[str] = ..., value: _Optional[bytes] = ...) -> None: ...

    SVIDS_FIELD_NUMBER: _ClassVar[int]
    CRL_FIELD_NUMBER: _ClassVar[int]
    FEDERATED_BUNDLES_FIELD_NUMBER: _ClassVar[int]
    svids: _containers.RepeatedCompositeFieldContainer[X509SVID]
    crl: _containers.RepeatedScalarFieldContainer[bytes]
    federated_bundles: _containers.ScalarMap[str, bytes]
    def __init__(
        self,
        svids: _Optional[_Iterable[_Union[X509SVID, _Mapping]]] = ...,
        crl: _Optional[_Iterable[bytes]] = ...,
        federated_bundles: _Optional[_Mapping[str, bytes]] = ...,
    ) -> None: ...

class X509SVID(_message.Message):
    __slots__ = ("spiffe_id", "x509_svid", "x509_svid_key", "bundle", "hint")
    SPIFFE_ID_FIELD_NUMBER: _ClassVar[int]
    X509_SVID_FIELD_NUMBER: _ClassVar[int]
    X509_SVID_KEY_FIELD_NUMBER: _ClassVar[int]
    BUNDLE_FIELD_NUMBER: _ClassVar[int]
    HINT_FIELD_NUMBER: _ClassVar[int]
    spiffe_id: str
    x509_svid: bytes
    x509_svid_key: bytes
    bundle: bytes
    hint: str
    def __init__(
        self,
        spiffe_id: _Optional[str] = ...,
        x509_svid: _Optional[bytes] = ...,
        x509_svid_key: _Optional[bytes] = ...,
        bundle: _Optional[bytes] = ...,
        hint: _Optional[str] = ...,
    ) -> None: ...

class X509BundlesRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class X509BundlesResponse(_message.Message):
    __slots__ = ("crl", "bundles")
    class BundlesEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: bytes
        def __init__(self, key: _Optional[str] = ..., value: _Optional[bytes] = ...) -> None: ...

    CRL_FIELD_NUMBER: _ClassVar[int]
    BUNDLES_FIELD_NUMBER: _ClassVar[int]
    crl: _containers.RepeatedScalarFieldContainer[bytes]
    bundles: _containers.ScalarMap[str, bytes]
    def __init__(
        self, crl: _Optional[_Iterable[bytes]] = ..., bundles: _Optional[_Mapping[str, bytes]] = ...
    ) -> None: ...

class JWTSVIDRequest(_message.Message):
    __slots__ = ("audience", "spiffe_id")
    AUDIENCE_FIELD_NUMBER: _ClassVar[int]
    SPIFFE_ID_FIELD_NUMBER: _ClassVar[int]
    audience: _containers.RepeatedScalarFieldContainer[str]
    spiffe_id: str
    def __init__(
        self, audience: _Optional[_Iterable[str]] = ..., spiffe_id: _Optional[str] = ...
    ) -> None: ...

class JWTSVIDResponse(_message.Message):
    __slots__ = ("svids",)
    SVIDS_FIELD_NUMBER: _ClassVar[int]
    svids: _containers.RepeatedCompositeFieldContainer[JWTSVID]
    def __init__(self, svids: _Optional[_Iterable[_Union[JWTSVID, _Mapping]]] = ...) -> None: ...

class JWTSVID(_message.Message):
    __slots__ = ("spiffe_id", "svid", "hint")
    SPIFFE_ID_FIELD_NUMBER: _ClassVar[int]
    SVID_FIELD_NUMBER: _ClassVar[int]
    HINT_FIELD_NUMBER: _ClassVar[int]
    spiffe_id: str
    svid: str
    hint: str
    def __init__(
        self,
        spiffe_id: _Optional[str] = ...,
        svid: _Optional[str] = ...,
        hint: _Optional[str] = ...,
    ) -> None: ...

class JWTBundlesRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class JWTBundlesResponse(_message.Message):
    __slots__ = ("bundles",)
    class BundlesEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: bytes
        def __init__(self, key: _Optional[str] = ..., value: _Optional[bytes] = ...) -> None: ...

    BUNDLES_FIELD_NUMBER: _ClassVar[int]
    bundles: _containers.ScalarMap[str, bytes]
    def __init__(self, bundles: _Optional[_Mapping[str, bytes]] = ...) -> None: ...

class ValidateJWTSVIDRequest(_message.Message):
    __slots__ = ("audience", "svid")
    AUDIENCE_FIELD_NUMBER: _ClassVar[int]
    SVID_FIELD_NUMBER: _ClassVar[int]
    audience: str
    svid: str
    def __init__(self, audience: _Optional[str] = ..., svid: _Optional[str] = ...) -> None: ...

class ValidateJWTSVIDResponse(_message.Message):
    __slots__ = ("spiffe_id", "claims")
    SPIFFE_ID_FIELD_NUMBER: _ClassVar[int]
    CLAIMS_FIELD_NUMBER: _ClassVar[int]
    spiffe_id: str
    claims: _struct_pb2.Struct
    def __init__(
        self,
        spiffe_id: _Optional[str] = ...,
        claims: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...,
    ) -> None: ...
