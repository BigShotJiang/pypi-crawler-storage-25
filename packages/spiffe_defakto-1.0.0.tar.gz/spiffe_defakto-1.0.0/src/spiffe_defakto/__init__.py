"""Defakto Python SDK for SPIFFE workload identity.

Top-level re-exports mirror the TypeScript SDK so applications written against
one translate cleanly to the other.
"""

from __future__ import annotations

from .attestation.types import AttestationEvidence, Attestor
from .attesting_workload_api import AttestingClientOptions, AttestingWorkloadAPIClient
from .attestors import (
    AwsTokenAttestor,
    AwsTokenAttestorOptions,
    AzureMSIAttestor,
    AzureMSIAttestorOptions,
    GcpIITAttestor,
    GcpIITAttestorOptions,
)
from .errors import SpiffeError, SpiffeErrorCode
from .jwtsvid import (
    JwtBundle,
    JwtBundleSource,
    JwtClaims,
    JwtSVID,
    JwtSVIDSource,
    parse_and_validate_jwt_svid,
)
from .local_workload_api import (
    ClientOptions,
    LocalWorkloadAPIClient,
    TcpOptions,
    UnixOptions,
)
from .spiffe_id import SpiffeID, TrustDomain
from .workload_api import WorkloadAPIClient, X509Context
from .x509svid import (
    X509SVID,
    MarshaledX509SVID,
    VerifyX509SVIDOptions,
    X509Bundle,
    X509BundleSource,
    X509SVIDSource,
    marshal_x509_svid,
    parse_marshaled_x509_svid,
    verify_x509_svid,
)

__all__ = [
    "X509SVID",
    "AttestationEvidence",
    "AttestingClientOptions",
    "AttestingWorkloadAPIClient",
    "Attestor",
    "AwsTokenAttestor",
    "AwsTokenAttestorOptions",
    "AzureMSIAttestor",
    "AzureMSIAttestorOptions",
    "ClientOptions",
    "GcpIITAttestor",
    "GcpIITAttestorOptions",
    "JwtBundle",
    "JwtBundleSource",
    "JwtClaims",
    "JwtSVID",
    "JwtSVIDSource",
    "LocalWorkloadAPIClient",
    "MarshaledX509SVID",
    "SpiffeError",
    "SpiffeErrorCode",
    "SpiffeID",
    "TcpOptions",
    "TrustDomain",
    "UnixOptions",
    "VerifyX509SVIDOptions",
    "WorkloadAPIClient",
    "X509Bundle",
    "X509BundleSource",
    "X509Context",
    "X509SVIDSource",
    "marshal_x509_svid",
    "parse_and_validate_jwt_svid",
    "parse_marshaled_x509_svid",
    "verify_x509_svid",
]

__version__ = "1.0.0"
