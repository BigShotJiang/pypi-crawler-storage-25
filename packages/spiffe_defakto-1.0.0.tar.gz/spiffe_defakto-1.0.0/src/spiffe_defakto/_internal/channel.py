"""Shared gRPC channel construction for the local and attesting clients."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import grpc

from ..errors import SpiffeError, SpiffeErrorCode

if TYPE_CHECKING:
    from ..local_workload_api.options import ClientOptions

_log = logging.getLogger(__name__)


def build_channel(options: ClientOptions) -> grpc.aio.Channel:
    """Construct a ``grpc.aio.Channel`` for the given transport options.

    Emits a warning on insecure TCP channels targetting non-loopback addresses
    — those are almost always a misconfiguration in production.
    """
    # Local import avoids a circular import at package load time: the options
    # module lives alongside the local Workload API client, which imports us.
    from ..local_workload_api.options import TcpOptions, UnixOptions

    if isinstance(options, UnixOptions):
        return grpc.aio.insecure_channel(
            f"unix:{options.socket_path}",
            options=[("grpc.default_authority", "localhost")],
        )
    if isinstance(options, TcpOptions):
        target = f"{options.address}:{options.port}"
        if options.insecure_skip_tls:
            if options.address not in {"127.0.0.1", "::1", "localhost"}:
                _log.warning(
                    "insecure_skip_tls=True against non-loopback address %r — "
                    "intended for local development only",
                    options.address,
                )
            return grpc.aio.insecure_channel(target)
        return grpc.aio.secure_channel(target, grpc.ssl_channel_credentials())
    raise SpiffeError(
        SpiffeErrorCode.SOCKET_PATH_NOT_CONFIGURED,
        f"Unknown transport type: {type(options).__name__}",
    )
