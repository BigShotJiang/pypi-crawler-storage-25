"""Event-loop bridge for the sync facade.

``SyncRunner`` runs a dedicated ``asyncio`` event loop on a background thread
and exposes two methods for calling async code from sync contexts:

- :meth:`run` — run a coroutine to completion and return its result.
- :meth:`iterate` — turn an async iterator into a blocking iterator.

The runner owns the loop: calling :meth:`close` stops the loop and joins the
thread cleanly.
"""

from __future__ import annotations

import asyncio
import threading
from concurrent.futures import Future
from typing import TYPE_CHECKING, TypeVar

if TYPE_CHECKING:
    from collections.abc import AsyncIterator, Awaitable, Iterator

_T = TypeVar("_T")


class SyncRunner:
    """A single background event loop used to bridge async SDK code to sync callers."""

    def __init__(self) -> None:
        self._loop: asyncio.AbstractEventLoop | None = None
        self._thread: threading.Thread | None = None
        self._ready = threading.Event()
        self._start()

    def _start(self) -> None:
        def _target() -> None:
            loop = asyncio.new_event_loop()
            self._loop = loop
            asyncio.set_event_loop(loop)
            self._ready.set()
            try:
                loop.run_forever()
            finally:
                loop.close()

        self._thread = threading.Thread(target=_target, daemon=True, name="spiffe-sync-loop")
        self._thread.start()
        self._ready.wait()

    def run(self, coro: Awaitable[_T]) -> _T:
        """Run ``coro`` on the background loop and block for the result."""
        assert self._loop is not None
        future: Future[_T] = asyncio.run_coroutine_threadsafe(coro, self._loop)  # type: ignore[arg-type]
        return future.result()

    def iterate(self, agen: AsyncIterator[_T]) -> Iterator[_T]:
        """Return a blocking iterator that yields from an async iterable."""
        assert self._loop is not None
        loop = self._loop
        sentinel = object()

        async def _next() -> object:
            try:
                return await agen.__anext__()
            except StopAsyncIteration:
                return sentinel

        while True:
            value = asyncio.run_coroutine_threadsafe(_next(), loop).result()
            if value is sentinel:
                return
            yield value  # type: ignore[misc]

    def close(self) -> None:
        """Stop the background loop and join the thread.

        Cancels any in-flight tasks before stopping so the loop has a chance
        to run their cancellation handlers — prevents "Task was destroyed but
        it is pending" warnings on interpreter shutdown.
        """
        loop = self._loop
        thread = self._thread
        if loop is None or thread is None:
            return

        def _shutdown() -> None:
            for task in asyncio.all_tasks(loop):
                task.cancel()
            loop.call_later(0.1, loop.stop)

        loop.call_soon_threadsafe(_shutdown)
        thread.join(timeout=5.0)
        self._loop = None
        self._thread = None
