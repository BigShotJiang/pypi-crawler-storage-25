"""Process-wide :class:`SyncRunner` used to drive async SVID fetches from sync code.

The cloud credential integrations (:mod:`spiffe_defakto.aws`,
:mod:`spiffe_defakto.azure`, :mod:`spiffe_defakto.gcp`) all need to satisfy
synchronous refresh callbacks from the respective cloud SDKs. Each call must:

* succeed even when invoked from a thread that already owns an event loop
  (``asyncio.run`` raises ``RuntimeError`` in that case);
* reuse any previously-created ``WorkloadAPIClient`` — otherwise the gRPC
  channel is bound to a transient loop that has already been torn down.

The solution is a single long-lived background event-loop thread shared across
the three integrations. It is started on first use and never torn down for the
lifetime of the process.
"""

from __future__ import annotations

import atexit
import threading
from typing import TYPE_CHECKING, TypeVar

from .loop import SyncRunner

if TYPE_CHECKING:
    from collections.abc import Awaitable


_T = TypeVar("_T")

_runner: SyncRunner | None = None
_lock = threading.Lock()


def _ensure_runner() -> SyncRunner:
    global _runner  # noqa: PLW0603 - this module owns the singleton
    with _lock:
        if _runner is None:
            _runner = SyncRunner()
            atexit.register(_runner.close)
        return _runner


def run_coro(coro: Awaitable[_T]) -> _T:
    """Schedule ``coro`` on the shared background loop and block for its result."""
    return _ensure_runner().run(coro)
