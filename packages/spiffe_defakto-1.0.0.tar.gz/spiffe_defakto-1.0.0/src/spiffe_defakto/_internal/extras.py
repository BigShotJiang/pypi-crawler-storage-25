"""Friendly error messages for missing optional dependencies.

Sub-packages like :mod:`spiffe_defakto.aws` carry heavy optional dependencies
(boto3, azure-identity, google-auth). Rather than surfacing cryptic
``ModuleNotFoundError``s, we raise a clear :class:`ImportError` pointing the
user at the right install extra.
"""

from __future__ import annotations

from typing import NoReturn


def missing_extra(extra: str, module: str) -> NoReturn:
    """Raise an :class:`ImportError` telling the user which extra to install."""
    raise ImportError(
        f"{module} requires the optional {extra!r} dependency.\n"
        f"Install it with:\n"
        f"    pip install 'spiffe-defakto[{extra}]'"
    )
