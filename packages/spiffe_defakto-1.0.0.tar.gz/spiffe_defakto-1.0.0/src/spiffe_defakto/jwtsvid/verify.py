"""Verification of JWT SVIDs against a JWT bundle source."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import TYPE_CHECKING

import jwt
from jwt.algorithms import ECAlgorithm, RSAAlgorithm

from ..errors import SpiffeError, SpiffeErrorCode
from ..spiffe_id import SpiffeID
from .types import JwtSVID

if TYPE_CHECKING:
    from .types import JwtBundleSource

# Algorithms permitted by the SPIFFE JWT-SVID spec.
_ALLOWED_ALGORITHMS = frozenset(
    {"RS256", "RS384", "RS512", "ES256", "ES384", "ES512", "PS256", "PS384", "PS512"}
)


def _key_from_jwk(jwk: dict[str, object], alg: str) -> object:
    kty = jwk.get("kty")
    if kty == "RSA":
        return RSAAlgorithm.from_jwk(jwk)
    if kty == "EC":
        return ECAlgorithm.from_jwk(jwk)
    raise SpiffeError(
        SpiffeErrorCode.JWT_SIGNATURE_INVALID,
        f"Unsupported JWK kty {kty!r} for alg {alg!r}",
    )


async def parse_and_validate_jwt_svid(
    token: str,
    bundle_source: JwtBundleSource,
    expected_audiences: list[str],
) -> JwtSVID:
    """Parse, signature-check, and audience/expiry-validate a JWT SVID.

    Parameters
    ----------
    token:
        The compact JWT string.
    bundle_source:
        Source used to look up the signing bundle by the token's trust domain.
    expected_audiences:
        The token must list at least one of these in its ``aud`` claim.

    Raises :class:`SpiffeError` on any validation failure.
    """
    try:
        header = jwt.get_unverified_header(token)
        unverified = jwt.decode(token, options={"verify_signature": False})
    except jwt.PyJWTError as exc:
        raise SpiffeError(SpiffeErrorCode.JWT_PARSE_ERROR, "Cannot decode JWT", cause=exc) from exc

    sub = unverified.get("sub")
    if not isinstance(sub, str) or not sub:
        raise SpiffeError(
            SpiffeErrorCode.JWT_PARSE_ERROR,
            'JWT missing or invalid "sub" claim',
        )
    try:
        spiffe_id = SpiffeID.parse(sub)
    except SpiffeError as exc:
        raise SpiffeError(
            SpiffeErrorCode.JWT_PARSE_ERROR,
            f'JWT "sub" is not a valid SPIFFE ID: {sub}',
            cause=exc,
        ) from exc

    if not isinstance(unverified.get("exp"), (int, float)):
        raise SpiffeError(SpiffeErrorCode.JWT_PARSE_ERROR, 'JWT missing "exp" claim')

    raw_aud = unverified.get("aud")
    if isinstance(raw_aud, str):
        audience: tuple[str, ...] = (raw_aud,)
    elif isinstance(raw_aud, list):
        audience = tuple(a for a in raw_aud if isinstance(a, str))
    else:
        audience = ()

    if not any(expected in audience for expected in expected_audiences):
        raise SpiffeError(
            SpiffeErrorCode.SVID_AUDIENCE_MISMATCH,
            f"JWT audience {list(audience)} does not include any of {expected_audiences}",
        )

    alg = header.get("alg")
    if not isinstance(alg, str):
        raise SpiffeError(SpiffeErrorCode.JWT_PARSE_ERROR, 'JWT header missing "alg" claim')
    if alg not in _ALLOWED_ALGORITHMS:
        raise SpiffeError(
            SpiffeErrorCode.JWT_PARSE_ERROR,
            f'JWT "alg" header value {alg!r} is not permitted',
        )

    typ = header.get("typ")
    if typ is not None and typ not in {"JWT", "JOSE"}:
        raise SpiffeError(
            SpiffeErrorCode.JWT_PARSE_ERROR,
            f'JWT "typ" header value {typ!r} is not permitted',
        )

    kid = header.get("kid")
    if not isinstance(kid, str) or not kid:
        raise SpiffeError(SpiffeErrorCode.JWT_PARSE_ERROR, 'JWT header missing "kid" claim')

    bundle = await bundle_source.get_bundle_for_trust_domain(spiffe_id.trust_domain)
    jwk = bundle.jwt_authorities.get(kid)
    if jwk is None:
        raise SpiffeError(
            SpiffeErrorCode.JWT_SIGNATURE_INVALID,
            f"No key found in bundle for kid {kid!r}",
        )

    try:
        public_key = _key_from_jwk(dict(jwk), alg)
    except SpiffeError:
        raise
    except Exception as exc:
        raise SpiffeError(
            SpiffeErrorCode.JWT_SIGNATURE_INVALID,
            "Cannot import JWT signing key",
            cause=exc,
        ) from exc

    try:
        claims = jwt.decode(
            token,
            key=public_key,  # type: ignore[arg-type]
            algorithms=[alg],
            audience=expected_audiences,
            options={"require": ["exp", "sub"]},
        )
    except jwt.ExpiredSignatureError as exc:
        raise SpiffeError(
            SpiffeErrorCode.SVID_EXPIRED,
            "JWT-SVID has expired",
            cause=exc,
        ) from exc
    except jwt.InvalidAudienceError as exc:
        raise SpiffeError(
            SpiffeErrorCode.SVID_AUDIENCE_MISMATCH,
            "JWT audience does not match",
            cause=exc,
        ) from exc
    except jwt.PyJWTError as exc:
        raise SpiffeError(
            SpiffeErrorCode.JWT_SIGNATURE_INVALID,
            "JWT signature is invalid",
            cause=exc,
        ) from exc

    expires_at = datetime.fromtimestamp(float(claims["exp"]), tz=timezone.utc)

    return JwtSVID(
        id=spiffe_id,
        audience=audience,
        expires_at=expires_at,
        token=token,
        claims=claims,
    )
