"""Public data types for JWT SVIDs and JWT trust bundles."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from datetime import datetime
from typing import TYPE_CHECKING, Any, Protocol, TypedDict, runtime_checkable

if TYPE_CHECKING:
    from ..spiffe_id import SpiffeID, TrustDomain


class JwtClaims(TypedDict, total=False):
    """Standard JWT-SVID claims with typed fields.

    All keys are optional (``total=False``) — SPIFFE only mandates ``sub`` and
    ``exp``, enforced by :func:`parse_and_validate_jwt_svid`. Custom claims
    are permitted because :class:`JwtSVID.claims` is typed as
    ``Mapping[str, Any]``; this :class:`TypedDict` exists for IDE autocomplete
    and static typing on the well-known claim names.
    """

    sub: str
    aud: str | list[str]
    exp: int
    iat: int
    iss: str
    jti: str
    nbf: int


@dataclass(frozen=True, slots=True)
class JwtSVID:
    """A parsed and (where applicable) verified JWT SVID."""

    id: SpiffeID
    audience: tuple[str, ...]
    expires_at: datetime
    token: str
    """The raw compact JWT, ready to use in an ``Authorization`` header."""

    claims: Mapping[str, Any]
    """All decoded claims, including any custom ones. Standard SPIFFE JWT
    claims follow the :class:`JwtClaims` shape."""


@dataclass(frozen=True, slots=True)
class JwtBundle:
    """A JWT trust bundle: signing keys for a single trust domain, keyed by ``kid``."""

    trust_domain: TrustDomain
    jwt_authorities: Mapping[str, Mapping[str, Any]]
    """``{kid: jwk}`` mapping. Values follow the JWK dict shape."""


@runtime_checkable
class JwtSVIDSource(Protocol):
    """Anything that can fetch a JWT SVID for a list of audiences."""

    async def fetch_svid(self, audiences: list[str]) -> JwtSVID:
        """Return a JWT SVID for the requested audiences.

        At least one audience must be provided.
        """


@runtime_checkable
class JwtBundleSource(Protocol):
    """Anything that can resolve JWT trust bundles by trust domain."""

    async def get_bundle_for_trust_domain(self, trust_domain: TrustDomain) -> JwtBundle:
        """Return the JWT bundle for ``trust_domain``.

        Raises :class:`~spiffe_defakto.errors.SpiffeError` with code
        ``BUNDLE_NOT_FOUND`` if no bundle is available.
        """
