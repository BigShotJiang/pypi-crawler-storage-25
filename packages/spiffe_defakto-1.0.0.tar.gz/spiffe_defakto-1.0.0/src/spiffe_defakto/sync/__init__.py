"""Synchronous facade over the async Workload API clients."""

from .client import SyncWorkloadAPIClient

__all__ = ["SyncWorkloadAPIClient"]
