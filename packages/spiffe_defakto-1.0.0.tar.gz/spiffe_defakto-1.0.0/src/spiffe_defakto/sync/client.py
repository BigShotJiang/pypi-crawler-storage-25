"""Synchronous :class:`SyncWorkloadAPIClient`.

A thin blocking facade over :class:`WorkloadAPIClient` for scripts, CLIs, and
non-async frameworks. Streaming methods become regular blocking iterators.

Prefer the async :class:`WorkloadAPIClient` when running inside an event loop
(FastAPI, aiohttp, Starlette, etc.); this class exists for the cases where
``asyncio`` is unavailable or inconvenient.
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import TYPE_CHECKING

from .._internal.loop import SyncRunner
from ..workload_api.client import WorkloadAPIClient

if TYPE_CHECKING:
    from ..jwtsvid.types import JwtBundle, JwtSVID
    from ..spiffe_id import TrustDomain
    from ..workload_api.context import X509Context
    from ..x509svid.types import X509SVID, X509Bundle


class SyncWorkloadAPIClient:
    """Blocking counterpart of :class:`WorkloadAPIClient`.

    Instantiating this class spawns a daemon thread running a private
    ``asyncio`` loop that serves all requests. Call :meth:`close` (or use the
    sync context manager protocol) to stop the loop.
    """

    def __init__(self) -> None:
        self._runner = SyncRunner()
        try:
            # Construct the async client on the runner's loop so any gRPC
            # channel / transport wiring associates with the right event loop.
            self._inner = self._runner.run(_create_inner())
        except BaseException:
            self._runner.close()
            raise

    # ------------------------------------------------------------------ API
    def get_svid(self) -> X509SVID:
        return self._runner.run(self._inner.x509.get_svid())

    def get_bundle_for_trust_domain(self, trust_domain: TrustDomain) -> X509Bundle:
        return self._runner.run(self._inner.x509.get_bundle_for_trust_domain(trust_domain))

    def fetch_jwt_svid(self, audiences: list[str]) -> JwtSVID:
        return self._runner.run(self._inner.jwt.fetch_svid(audiences))

    def get_jwt_bundle(self, trust_domain: TrustDomain) -> JwtBundle:
        return self._runner.run(self._inner.jwt.get_bundle_for_trust_domain(trust_domain))

    def watch_x509_context(self) -> Iterator[X509Context]:
        """Blocking iterator that yields a new context on each rotation.

        Break out of the loop or call :meth:`close` to stop watching.
        """
        return self._runner.iterate(self._inner.watch_x509_context())

    def close(self) -> None:
        try:
            self._runner.run(self._inner.close())
        finally:
            self._runner.close()

    def __enter__(self) -> SyncWorkloadAPIClient:
        return self

    def __exit__(self, *_exc_info: object) -> None:
        self.close()


async def _create_inner() -> WorkloadAPIClient:
    """Construct the async client on the calling loop's thread."""
    return WorkloadAPIClient()
