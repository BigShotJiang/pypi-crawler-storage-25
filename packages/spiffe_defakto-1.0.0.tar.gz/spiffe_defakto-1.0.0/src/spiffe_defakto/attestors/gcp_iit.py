"""GCP Instance Identity Token (IIT) attestor.

Uses only :mod:`httpx` (a core dependency) — the GCP metadata service is a
plain HTTP endpoint, so no optional cloud SDK is required.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from urllib.parse import quote

import httpx

from ..attestation.types import AttestationEvidence
from ..errors import SpiffeError, SpiffeErrorCode

_DEFAULT_METADATA_HOST = "metadata.google.internal"
_DEFAULT_SERVICE_ACCOUNT = "default"
_DEFAULT_AUDIENCE = "urn:defakto:security:server"
_PLUGIN_NAME = "gcp_iit"
_PLUGIN_VERSION = "1.0"


@dataclass(frozen=True, slots=True)
class GcpIITAttestorOptions:
    """Options for :class:`GcpIITAttestor`."""

    identity_token_host: str = _DEFAULT_METADATA_HOST
    service_account: str = _DEFAULT_SERVICE_ACCOUNT
    audience: str = _DEFAULT_AUDIENCE


class GcpIITAttestor:
    """Attests a GCP workload by fetching a signed IIT from the metadata service.

    The IIT is a JWT issued by Google that proves the workload is running on a
    specific GCE instance, Cloud Run service, GKE pod, and so on.
    """

    plugin_name = _PLUGIN_NAME
    plugin_version = _PLUGIN_VERSION

    def __init__(self, options: GcpIITAttestorOptions | None = None) -> None:
        self._options = options or GcpIITAttestorOptions()

    async def collect_evidence(self) -> AttestationEvidence:
        try:
            token = await self._fetch_identity_token()
        except httpx.HTTPError as exc:
            raise SpiffeError(
                SpiffeErrorCode.ATTESTOR_COLLECTION_FAILED,
                "Cannot obtain GCP instance identity token",
                cause=exc,
            ) from exc

        payload = json.dumps({"token": token}).encode("utf-8")
        return AttestationEvidence(
            plugin_name=self.plugin_name,
            plugin_version=self.plugin_version,
            payload=payload,
        )

    async def _fetch_identity_token(self) -> str:
        opts = self._options
        url = (
            f"http://{opts.identity_token_host}"
            f"/computeMetadata/v1/instance/service-accounts/{opts.service_account}/identity"
            f"?audience={quote(opts.audience, safe='')}&format=full"
        )
        async with httpx.AsyncClient() as client:
            response = await client.get(url, headers={"Metadata-Flavor": "Google"})
        if response.status_code != 200:
            raise SpiffeError(
                SpiffeErrorCode.ATTESTOR_COLLECTION_FAILED,
                f"Metadata service returned unexpected status {response.status_code}",
            )
        return response.text
