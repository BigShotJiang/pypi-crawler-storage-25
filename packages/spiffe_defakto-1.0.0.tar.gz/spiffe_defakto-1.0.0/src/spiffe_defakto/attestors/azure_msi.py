"""Azure Managed Identity attestor.

Requires the ``azure`` optional dependency::

    pip install 'spiffe-defakto[azure]'
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import TYPE_CHECKING

from .._internal.extras import missing_extra
from ..attestation.types import AttestationEvidence
from ..errors import SpiffeError, SpiffeErrorCode

if TYPE_CHECKING:
    from typing import Any


_DEFAULT_AUDIENCE = "api://AzureADTokenExchange"
_PLUGIN_NAME = "azure_msi"
_PLUGIN_VERSION = "1.0"


@dataclass(frozen=True, slots=True)
class AzureMSIAttestorOptions:
    """Options for :class:`AzureMSIAttestor`.

    At most one of ``client_id``, ``principal_id``, and ``resource_id`` may be
    set — they select between multiple user-assigned identities on the same
    resource. When none is set, the system-assigned identity is used.
    """

    audience: str = _DEFAULT_AUDIENCE
    client_id: str | None = None
    principal_id: str | None = None
    resource_id: str | None = None


class AzureMSIAttestor:
    """Attests an Azure workload using an Azure AD Managed Identity token.

    Works on any Azure compute resource with a managed identity assigned —
    App Service, Container Apps, AKS, VM, etc.
    """

    plugin_name = _PLUGIN_NAME
    plugin_version = _PLUGIN_VERSION

    def __init__(self, options: AzureMSIAttestorOptions | None = None) -> None:
        opts = options or AzureMSIAttestorOptions()
        selector_count = sum(1 for v in (opts.client_id, opts.principal_id, opts.resource_id) if v)
        if selector_count > 1:
            raise ValueError("At most one of client_id, principal_id, resource_id may be set")
        self._options = opts

        try:
            from azure.identity.aio import ManagedIdentityCredential
        except ImportError:
            missing_extra("azure", "AzureMSIAttestor")

        cred_kwargs: dict[str, Any] = {}
        if opts.client_id:
            cred_kwargs["client_id"] = opts.client_id
        elif opts.principal_id:
            cred_kwargs["object_id"] = opts.principal_id
        elif opts.resource_id:
            cred_kwargs["mi_res_id"] = opts.resource_id
        self._credential = ManagedIdentityCredential(**cred_kwargs)

    async def collect_evidence(self) -> AttestationEvidence:
        scope = self._scope()
        try:
            access_token = await self._credential.get_token(scope)
        except Exception as exc:
            raise SpiffeError(
                SpiffeErrorCode.ATTESTOR_COLLECTION_FAILED,
                "Cannot obtain Azure MSI token",
                cause=exc,
            ) from exc

        if access_token is None or not access_token.token:
            raise SpiffeError(
                SpiffeErrorCode.ATTESTOR_COLLECTION_FAILED,
                "Managed identity returned no token",
            )

        payload = json.dumps({"token": access_token.token}).encode("utf-8")
        return AttestationEvidence(
            plugin_name=self.plugin_name,
            plugin_version=self.plugin_version,
            payload=payload,
        )

    def _scope(self) -> str:
        audience = self._options.audience
        if audience == _DEFAULT_AUDIENCE:
            return audience
        return audience if audience.endswith("/.default") else f"{audience}/.default"

    async def close(self) -> None:
        """Release the underlying Azure credential's resources."""
        await self._credential.close()
