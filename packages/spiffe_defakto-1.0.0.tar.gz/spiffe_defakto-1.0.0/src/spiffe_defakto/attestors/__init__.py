"""Built-in attestors for the major public cloud platforms.

Each attestor is importable only when its respective optional dependency is
installed. The ``Attestor`` protocol is reusable for custom implementations.
"""

from .aws_token import AwsTokenAttestor, AwsTokenAttestorOptions
from .azure_msi import AzureMSIAttestor, AzureMSIAttestorOptions
from .gcp_iit import GcpIITAttestor, GcpIITAttestorOptions

__all__ = [
    "AwsTokenAttestor",
    "AwsTokenAttestorOptions",
    "AzureMSIAttestor",
    "AzureMSIAttestorOptions",
    "GcpIITAttestor",
    "GcpIITAttestorOptions",
]
