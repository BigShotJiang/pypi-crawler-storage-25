"""AWS STS web-identity attestor.

Requires the ``aws`` optional dependency::

    pip install 'spiffe-defakto[aws]'
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Literal

from .._internal.extras import missing_extra
from ..attestation.types import AttestationEvidence
from ..errors import SpiffeError, SpiffeErrorCode

if TYPE_CHECKING:
    from typing import Any


_DEFAULT_AUDIENCE = ("urn:defakto:security:server",)
_DEFAULT_DURATION_SECONDS = 60
_PLUGIN_NAME = "aws_token"
_PLUGIN_VERSION = "1.0"


@dataclass(frozen=True, slots=True)
class AwsTokenAttestorOptions:
    """Options for :class:`AwsTokenAttestor`."""

    audience: tuple[str, ...] = _DEFAULT_AUDIENCE
    """Intended recipients of the STS web identity JWT (``aud`` claim)."""

    signing_algorithm: Literal["RS256", "ES384"] = "RS256"

    duration_seconds: int = _DEFAULT_DURATION_SECONDS
    """Token validity in seconds (60–3600)."""

    tags: tuple[tuple[str, str], ...] = ()
    """``(key, value)`` pairs to attach as STS session tags."""

    sts_config: dict[str, object] = field(default_factory=dict)
    """Keyword arguments forwarded to ``boto3.client('sts', **sts_config)``."""


class AwsTokenAttestor:
    """Attests an AWS workload via STS ``GetWebIdentityToken``.

    Works in any environment with an attached IAM role — AWS Lambda, ECS,
    EC2, EKS pods with IRSA, etc. The resulting JWT is signed by AWS STS and
    carries the caller's IAM role identity.
    """

    plugin_name = _PLUGIN_NAME
    plugin_version = _PLUGIN_VERSION

    def __init__(self, options: AwsTokenAttestorOptions | None = None) -> None:
        self._options = options or AwsTokenAttestorOptions()
        try:
            import boto3  # noqa: F401  (imported for availability check)
        except ImportError:
            missing_extra("aws", "AwsTokenAttestor")
        self._client = self._build_client()

    def _build_client(self) -> Any:
        import boto3

        return boto3.client("sts", **self._options.sts_config)  # type: ignore[call-overload]

    async def collect_evidence(self) -> AttestationEvidence:
        try:
            token = await asyncio.to_thread(self._fetch_token_blocking)
        except Exception as exc:
            raise SpiffeError(
                SpiffeErrorCode.ATTESTOR_COLLECTION_FAILED,
                "Cannot obtain AWS web identity token from STS",
                cause=exc,
            ) from exc

        return AttestationEvidence(
            plugin_name=self.plugin_name,
            plugin_version=self.plugin_version,
            payload=token.encode("utf-8"),
        )

    def _fetch_token_blocking(self) -> str:
        opts = self._options
        kwargs: dict[str, Any] = {
            "Audience": list(opts.audience),
            "SigningAlgorithm": opts.signing_algorithm,
            "DurationSeconds": opts.duration_seconds,
        }
        if opts.tags:
            kwargs["Tags"] = [{"Key": k, "Value": v} for k, v in opts.tags]

        resp = self._client.get_web_identity_token(**kwargs)
        token = resp.get("WebIdentityToken")
        if not token:
            raise RuntimeError("STS returned empty WebIdentityToken")
        return str(token)
