"""Smart Workload API client and shared X.509 context type.

The ``WorkloadAPIClient`` re-export is lazy so downstream modules can import
:class:`X509Context` without pulling in the local/attesting client transitively
and causing import cycles.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from .context import X509Context

if TYPE_CHECKING:
    from .client import WorkloadAPIClient

__all__ = ["WorkloadAPIClient", "X509Context"]


def __getattr__(name: str) -> object:  # pragma: no cover - thin lazy-import shim
    if name == "WorkloadAPIClient":
        from .client import WorkloadAPIClient

        return WorkloadAPIClient
    raise AttributeError(f"module 'spiffe_defakto.workload_api' has no attribute {name!r}")
