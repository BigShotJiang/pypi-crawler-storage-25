"""Shared X.509 context type returned by both Workload API clients."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass

from ..errors import SpiffeError, SpiffeErrorCode
from ..x509svid import X509SVID, X509Bundle


@dataclass(frozen=True, slots=True)
class X509Context:
    """A snapshot of every X.509 SVID and trust bundle visible to the workload.

    Emitted once per rotation by :meth:`LocalWorkloadAPIClient.watch_x509_context`
    and :meth:`AttestingWorkloadAPIClient.watch_x509_context`.
    """

    svids: tuple[X509SVID, ...]
    """All SVIDs issued to this workload — usually one, sometimes multiple."""

    bundles: Mapping[str, X509Bundle]
    """Trust bundles keyed by trust-domain name."""

    def default_svid(self) -> X509SVID:
        """Return the first SVID — the conventional "default" for the workload.

        Raises :class:`SpiffeError` with code ``SVID_INVALID`` if the context
        carries no SVIDs.
        """
        if not self.svids:
            raise SpiffeError(SpiffeErrorCode.SVID_INVALID, "No SVIDs available in context")
        return self.svids[0]
