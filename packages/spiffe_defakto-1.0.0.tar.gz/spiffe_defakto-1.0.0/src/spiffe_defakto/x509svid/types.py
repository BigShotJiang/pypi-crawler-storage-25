"""Public data types for X.509 SVIDs and trust bundles."""

from __future__ import annotations

from collections.abc import AsyncIterator
from dataclasses import dataclass
from datetime import datetime
from typing import TYPE_CHECKING, Protocol, runtime_checkable

if TYPE_CHECKING:
    from cryptography.hazmat.primitives.asymmetric.types import PrivateKeyTypes
    from cryptography.x509 import Certificate

    from ..spiffe_id import SpiffeID, TrustDomain


@dataclass(frozen=True, slots=True)
class X509SVID:
    """An X.509 SVID — a certificate chain plus its private key."""

    id: SpiffeID
    """The SPIFFE ID the certificate attests to."""

    certificates: tuple[Certificate, ...]
    """The SVID certificate chain, leaf first, intermediates following."""

    private_key: PrivateKeyTypes
    """The private key corresponding to the leaf certificate."""

    expires_at: datetime
    """Expiry of the leaf certificate (timezone-aware UTC)."""


@dataclass(frozen=True, slots=True)
class X509Bundle:
    """An X.509 trust bundle: the CA certificates for a single trust domain."""

    trust_domain: TrustDomain
    x509_authorities: tuple[Certificate, ...]


@runtime_checkable
class X509SVIDSource(Protocol):
    """Anything that can produce an X.509 SVID for the current workload."""

    async def get_svid(self) -> X509SVID:
        """Return the current X.509 SVID."""

    def watch_svid(self) -> AsyncIterator[X509SVID]:
        """Yield a new SVID each time the workload's certificate is rotated."""


@runtime_checkable
class X509BundleSource(Protocol):
    """Anything that can resolve X.509 trust bundles by trust domain."""

    async def get_bundle_for_trust_domain(self, trust_domain: TrustDomain) -> X509Bundle:
        """Return the X.509 bundle for ``trust_domain``.

        Raises :class:`~spiffe_defakto.errors.SpiffeError` with code
        ``BUNDLE_NOT_FOUND`` if no bundle is available.
        """
