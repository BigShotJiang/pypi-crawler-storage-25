"""Verification of an X.509 SVID chain against a trust bundle source.

Given a peer's DER-encoded certificate chain (leaf first) and a
:class:`X509BundleSource`, :func:`verify_x509_svid` performs the full SPIFFE
verification:

1. Expiry check on every certificate in the chain.
2. Extraction of the SPIFFE ID from the leaf's SubjectAlternativeName.
3. SPIFFE leaf-SVID constraints (spec §2, §3.1, §4.1, §4.3).
4. Chain signature verification up to one of the bundle's trust authorities.

Returns the verified :class:`SpiffeID` on success, or raises
:class:`SpiffeError` with an appropriate code.
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Literal

from cryptography import x509
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec, ed25519, padding, rsa
from cryptography.x509.oid import ExtensionOID

from ..errors import SpiffeError, SpiffeErrorCode
from .marshal import extract_spiffe_id_from_cert

if TYPE_CHECKING:
    from ..spiffe_id import SpiffeID
    from .types import X509BundleSource


@dataclass(frozen=True, slots=True)
class VerifyX509SVIDOptions:
    """Options for :func:`verify_x509_svid`.

    Reserved for future use — mirrors the TypeScript SDK's option shape so
    callers can adopt the arg without a breaking change when we add
    side-specific semantics.
    """

    side: Literal["client", "server"] = "client"


def _check_expiry(cert: x509.Certificate) -> None:
    now = datetime.now(tz=timezone.utc)
    if cert.not_valid_after_utc < now:
        raise SpiffeError(SpiffeErrorCode.SVID_EXPIRED, "Certificate has expired")
    if cert.not_valid_before_utc > now:
        raise SpiffeError(SpiffeErrorCode.SVID_INVALID, "Certificate is not yet valid")


def _basic_constraints(cert: x509.Certificate) -> x509.BasicConstraints | None:
    try:
        return cert.extensions.get_extension_for_oid(ExtensionOID.BASIC_CONSTRAINTS).value  # type: ignore[return-value]
    except x509.ExtensionNotFound:
        return None


def _key_usage(cert: x509.Certificate) -> x509.KeyUsage | None:
    try:
        return cert.extensions.get_extension_for_oid(ExtensionOID.KEY_USAGE).value  # type: ignore[return-value]
    except x509.ExtensionNotFound:
        return None


def _verify_signature(cert: x509.Certificate, issuer: x509.Certificate) -> None:
    """Verify that ``cert`` is signed by ``issuer``'s public key.

    Raises :class:`SpiffeError` ``SVID_INVALID`` on mismatch. Supports RSA,
    ECDSA, and Ed25519 — the key families that the SPIFFE spec and cryptography
    library agree on.
    """
    public_key = issuer.public_key()
    tbs = cert.tbs_certificate_bytes
    signature = cert.signature
    hash_alg = cert.signature_hash_algorithm

    try:
        if isinstance(public_key, rsa.RSAPublicKey):
            if hash_alg is None:
                raise SpiffeError(
                    SpiffeErrorCode.SVID_INVALID,
                    "RSA certificate has no signature hash algorithm",
                )
            public_key.verify(signature, tbs, padding.PKCS1v15(), hash_alg)
        elif isinstance(public_key, ec.EllipticCurvePublicKey):
            if hash_alg is None:
                raise SpiffeError(
                    SpiffeErrorCode.SVID_INVALID,
                    "EC certificate has no signature hash algorithm",
                )
            public_key.verify(signature, tbs, ec.ECDSA(hash_alg))
        elif isinstance(public_key, ed25519.Ed25519PublicKey):
            public_key.verify(signature, tbs)
        else:
            raise SpiffeError(
                SpiffeErrorCode.SVID_INVALID,
                f"Unsupported issuer public-key type: {type(public_key).__name__}",
            )
    except InvalidSignature as exc:
        raise SpiffeError(
            SpiffeErrorCode.SVID_INVALID,
            "Certificate chain signature verification failed",
            cause=exc,
        ) from exc


def _signed_by(cert: x509.Certificate, ca: x509.Certificate) -> bool:
    try:
        _verify_signature(cert, ca)
    except SpiffeError:
        return False
    return True


def _fingerprint(cert: x509.Certificate) -> bytes:
    return cert.fingerprint(hashes.SHA256())


def _verify_cert_chain(chain: list[x509.Certificate], cas: Iterable[x509.Certificate]) -> None:
    # Verify each cert is signed by the next one in the chain.
    for i in range(len(chain) - 1):
        cert = chain[i]
        issuer = chain[i + 1]

        bc = _basic_constraints(issuer)
        if bc is None or not bc.ca:
            raise SpiffeError(
                SpiffeErrorCode.SVID_INVALID,
                "Intermediate certificate is not a CA",
            )
        ku = _key_usage(issuer)
        if ku is not None and not ku.key_cert_sign:
            raise SpiffeError(
                SpiffeErrorCode.SVID_INVALID,
                "Intermediate certificate missing keyCertSign usage",
            )

        _verify_signature(cert, issuer)

    chain_root = chain[-1]
    root_fp = _fingerprint(chain_root)
    for ca in cas:
        if _fingerprint(ca) == root_fp:
            return
        if _signed_by(chain_root, ca):
            return

    raise SpiffeError(
        SpiffeErrorCode.SVID_INVALID,
        "Certificate chain root is not trusted by any bundle CA",
    )


def _check_leaf_svid_constraints(leaf: x509.Certificate, spiffe_id: SpiffeID) -> None:
    if spiffe_id.path in ("", "/"):
        raise SpiffeError(
            SpiffeErrorCode.SVID_INVALID,
            "Leaf SVID must have a non-root path",
        )

    bc = _basic_constraints(leaf)
    if bc is not None and bc.ca:
        raise SpiffeError(
            SpiffeErrorCode.SVID_INVALID,
            "Leaf SVID must not be a CA certificate",
        )

    ku = _key_usage(leaf)
    if ku is not None and (ku.key_cert_sign or ku.crl_sign):
        raise SpiffeError(
            SpiffeErrorCode.SVID_INVALID,
            "Leaf SVID must not have keyCertSign or cRLSign key usage",
        )


async def verify_x509_svid(
    raw_certs: Iterable[bytes],
    bundle_source: X509BundleSource,
    options: VerifyX509SVIDOptions | None = None,
) -> SpiffeID:
    """Verify a peer's X.509 SVID chain and return its SPIFFE ID.

    Parameters
    ----------
    raw_certs:
        DER-encoded certificates, leaf first. Accepts any iterable of
        ``bytes``; in practice this is the chain handed to you by a TLS
        transport or a peer-verification callback.
    bundle_source:
        Source used to look up the trust bundle for the peer's trust domain.
    options:
        Reserved for future use — accepting the argument today lets callers
        adopt side-specific semantics without a breaking change.

    Returns
    -------
    The peer's verified :class:`SpiffeID`.

    Raises
    ------
    SpiffeError
        With one of: ``SVID_EXPIRED``, ``SVID_INVALID``, or ``BUNDLE_NOT_FOUND``.
    """
    der_list = list(raw_certs)
    if not der_list:
        raise SpiffeError(SpiffeErrorCode.SVID_INVALID, "No certificates provided")

    chain: list[x509.Certificate] = []
    for der in der_list:
        try:
            chain.append(x509.load_der_x509_certificate(bytes(der)))
        except ValueError as exc:
            raise SpiffeError(
                SpiffeErrorCode.SVID_INVALID,
                "Failed to parse DER certificate",
                cause=exc,
            ) from exc

    leaf = chain[0]

    for cert in chain:
        _check_expiry(cert)

    spiffe_id = extract_spiffe_id_from_cert(leaf)
    _check_leaf_svid_constraints(leaf, spiffe_id)

    bundle = await bundle_source.get_bundle_for_trust_domain(spiffe_id.trust_domain)
    _verify_cert_chain(chain, bundle.x509_authorities)

    return spiffe_id
