"""PEM serialisation of :class:`X509SVID` instances.

Use :func:`marshal_x509_svid` to encode and :func:`parse_marshaled_x509_svid`
to decode. The SPIFFE ID is extracted from (and validated against) the leaf
certificate's SubjectAlternativeName URI entry.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from cryptography import x509
from cryptography.hazmat.primitives import serialization

from ..errors import SpiffeError, SpiffeErrorCode
from ..spiffe_id import SpiffeID
from .types import X509SVID

if TYPE_CHECKING:
    from cryptography.x509 import Certificate


@dataclass(frozen=True, slots=True)
class MarshaledX509SVID:
    """A PEM-encoded SVID suitable for writing to disk or feeding TLS libraries."""

    cert_chain_pem: str
    """PEM-encoded certificate chain (leaf first)."""

    private_key_pem: str
    """PEM-encoded PKCS#8 private key."""


def extract_spiffe_id_from_cert(cert: Certificate) -> SpiffeID:
    """Return the sole SPIFFE URI from the certificate's SAN extension.

    Raises :class:`SpiffeError` with code ``SVID_INVALID`` if the extension is
    missing, contains no SPIFFE URI, or contains more than one.
    """
    try:
        san_ext = cert.extensions.get_extension_for_class(x509.SubjectAlternativeName)
    except x509.ExtensionNotFound as exc:
        raise SpiffeError(
            SpiffeErrorCode.SVID_INVALID,
            "Certificate has no SubjectAlternativeName extension",
            cause=exc,
        ) from exc

    # URI schemes are case-insensitive (RFC 3986 §3.1), so match lowercased.
    spiffe_uris = [
        uri
        for uri in san_ext.value.get_values_for_type(x509.UniformResourceIdentifier)
        if uri.lower().startswith("spiffe://")
    ]
    if not spiffe_uris:
        raise SpiffeError(
            SpiffeErrorCode.SVID_INVALID,
            "Certificate SAN contains no SPIFFE URI",
        )
    if len(spiffe_uris) > 1:
        raise SpiffeError(
            SpiffeErrorCode.SVID_INVALID,
            "Certificate has multiple SPIFFE URI SANs",
        )
    return SpiffeID.parse(spiffe_uris[0])


def marshal_x509_svid(svid: X509SVID) -> MarshaledX509SVID:
    """Serialise ``svid`` to PEM strings."""
    cert_chain_pem = "".join(
        cert.public_bytes(serialization.Encoding.PEM).decode("ascii") for cert in svid.certificates
    )
    private_key_pem = svid.private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    ).decode("ascii")
    return MarshaledX509SVID(cert_chain_pem=cert_chain_pem, private_key_pem=private_key_pem)


def parse_marshaled_x509_svid(marshaled: MarshaledX509SVID) -> X509SVID:
    """Deserialise PEM strings back into an :class:`X509SVID`."""
    cert_bytes = marshaled.cert_chain_pem.encode("ascii")
    try:
        certificates = tuple(x509.load_pem_x509_certificates(cert_bytes))
    except ValueError as exc:
        raise SpiffeError(
            SpiffeErrorCode.SVID_INVALID,
            "No certificates found in PEM",
            cause=exc,
        ) from exc
    if not certificates:
        raise SpiffeError(SpiffeErrorCode.SVID_INVALID, "No certificates found in PEM")

    leaf = certificates[0]
    spiffe_id = extract_spiffe_id_from_cert(leaf)

    try:
        private_key = serialization.load_pem_private_key(
            marshaled.private_key_pem.encode("ascii"),
            password=None,
        )
    except (ValueError, TypeError) as exc:
        raise SpiffeError(
            SpiffeErrorCode.SVID_INVALID,
            "Cannot parse PEM private key",
            cause=exc,
        ) from exc

    return X509SVID(
        id=spiffe_id,
        certificates=certificates,
        private_key=private_key,
        expires_at=leaf.not_valid_after_utc,
    )
