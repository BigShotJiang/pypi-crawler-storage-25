"""GCP credential client backed by a SPIFFE JWT SVID.

Requires the ``gcp`` optional dependency::

    pip install 'spiffe-defakto[gcp]'
"""

from .identity_pool import SPIFFEIdentityPoolClient, SPIFFEIdentityPoolClientOptions

__all__ = ["SPIFFEIdentityPoolClient", "SPIFFEIdentityPoolClientOptions"]
