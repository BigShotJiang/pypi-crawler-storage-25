"""Structured errors raised by the Defakto SPIFFE SDK.

All exceptions raised by the public API are instances of :class:`SpiffeError`.
Each carries a :class:`SpiffeErrorCode` so callers can branch on kind without
string matching, and an optional ``cause`` preserving the original exception.
"""

from __future__ import annotations

from enum import Enum


class SpiffeErrorCode(str, Enum):
    """Stable identifiers for every error condition the SDK raises."""

    # Identity
    INVALID_SPIFFE_ID = "INVALID_SPIFFE_ID"
    INVALID_TRUST_DOMAIN = "INVALID_TRUST_DOMAIN"

    # Bundles
    BUNDLE_NOT_FOUND = "BUNDLE_NOT_FOUND"

    # SVIDs
    SVID_EXPIRED = "SVID_EXPIRED"
    SVID_INVALID = "SVID_INVALID"
    SVID_AUDIENCE_MISMATCH = "SVID_AUDIENCE_MISMATCH"

    # Workload API
    SOCKET_PATH_NOT_CONFIGURED = "SOCKET_PATH_NOT_CONFIGURED"
    WORKLOAD_API_UNAVAILABLE = "WORKLOAD_API_UNAVAILABLE"
    WORKLOAD_API_ERROR = "WORKLOAD_API_ERROR"

    # JWT
    JWT_PARSE_ERROR = "JWT_PARSE_ERROR"
    JWT_SIGNATURE_INVALID = "JWT_SIGNATURE_INVALID"

    # Attestation
    NO_ATTESTORS_CONFIGURED = "NO_ATTESTORS_CONFIGURED"
    ATTESTOR_COLLECTION_FAILED = "ATTESTOR_COLLECTION_FAILED"
    ATTESTATION_FAILED = "ATTESTATION_FAILED"

    def __str__(self) -> str:
        return self.value


class SpiffeError(Exception):
    """The single error type raised by this SDK.

    Attributes
    ----------
    code:
        A :class:`SpiffeErrorCode` categorising the failure.
    __cause__:
        The original exception, if any. Set automatically when ``cause`` is
        passed so ``raise ... from ...`` semantics and tracebacks both work.
    """

    __slots__ = ("code",)

    def __init__(
        self,
        code: SpiffeErrorCode,
        message: str,
        cause: BaseException | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        if cause is not None:
            self.__cause__ = cause

    def __repr__(self) -> str:
        return f"SpiffeError(code={self.code.value}, message={self.args[0]!r})"
