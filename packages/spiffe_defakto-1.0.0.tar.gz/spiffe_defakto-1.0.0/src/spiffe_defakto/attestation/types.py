"""The :class:`Attestor` protocol and its evidence payload."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, runtime_checkable


@dataclass(frozen=True, slots=True)
class AttestationEvidence:
    """The proof payload produced by a single :class:`Attestor`.

    Multiple attestors' evidence is combined by
    :class:`AttestingWorkloadAPIClient` and sent together in a single request.
    """

    plugin_name: str
    """Must match :attr:`Attestor.plugin_name`."""

    plugin_version: str

    payload: bytes
    """Raw proof bytes — e.g. a signed JWT, a Kubernetes service account token,
    or an EC2 instance identity document."""


@runtime_checkable
class Attestor(Protocol):
    """Collects attestation evidence from the current workload's environment.

    Implement this protocol to add a custom attestation source. Built-in
    attestors for AWS, Azure, and GCP live in :mod:`spiffe_defakto.attestors`.

    Example::

        class KubernetesAttestor:
            plugin_name = "k8s_sat"
            plugin_version = "1.0.0"

            async def collect_evidence(self) -> AttestationEvidence:
                with open("/var/run/secrets/.../token", "rb") as f:
                    return AttestationEvidence(
                        plugin_name=self.plugin_name,
                        plugin_version=self.plugin_version,
                        payload=f.read(),
                    )
    """

    plugin_name: str
    plugin_version: str

    async def collect_evidence(self) -> AttestationEvidence:
        """Produce evidence for a single attestation handshake.

        May be called multiple times: once per request for the attesting
        client, and again on every SVID rotation.
        """
