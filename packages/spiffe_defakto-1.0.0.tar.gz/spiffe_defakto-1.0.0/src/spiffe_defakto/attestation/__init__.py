"""Types used to plug workload attestation into the attesting Workload API client."""

from .types import AttestationEvidence, Attestor

__all__ = ["AttestationEvidence", "Attestor"]
