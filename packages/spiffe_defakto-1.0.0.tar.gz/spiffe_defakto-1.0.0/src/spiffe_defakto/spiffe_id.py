"""Immutable SPIFFE ID and trust-domain value types.

A SPIFFE ID is a URI of the form ``spiffe://<trust-domain>[/<path>]`` that
names a workload. Trust domains identify the authority issuing SVIDs.

Use :meth:`SpiffeID.parse` and :meth:`TrustDomain.parse` to construct instances
rather than calling the dataclass initialisers directly — parsing enforces the
character set defined by the SPIFFE specification.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from .errors import SpiffeError, SpiffeErrorCode

_SPIFFE_SCHEME = "spiffe://"
_VALID_TRUST_DOMAIN = re.compile(r"^[a-z0-9._\-]+$")


@dataclass(frozen=True, slots=True)
class TrustDomain:
    """A SPIFFE trust domain (for example ``example.org``).

    The value is the bare domain name without the ``spiffe://`` scheme. Use
    :meth:`parse` to validate and normalise input.
    """

    name: str

    @classmethod
    def parse(cls, value: str) -> TrustDomain:
        """Parse a bare trust-domain name or a SPIFFE URI into a :class:`TrustDomain`.

        Accepts ``"example.org"`` and ``"spiffe://example.org"`` (any trailing
        path is ignored). Raises :class:`SpiffeError` with code
        ``INVALID_TRUST_DOMAIN`` if the input does not conform.
        """
        name = value.strip()
        if name.startswith(_SPIFFE_SCHEME):
            name = name[len(_SPIFFE_SCHEME) :]
            slash = name.find("/")
            if slash != -1:
                name = name[:slash]

        if not name or not _VALID_TRUST_DOMAIN.match(name):
            raise SpiffeError(
                SpiffeErrorCode.INVALID_TRUST_DOMAIN,
                f"Invalid trust domain: {value!r}",
            )
        return cls(name=name)

    def __str__(self) -> str:
        return f"{_SPIFFE_SCHEME}{self.name}"


@dataclass(frozen=True, slots=True)
class SpiffeID:
    """A parsed SPIFFE ID such as ``spiffe://example.org/service/api``.

    ``path`` includes the leading ``/`` when present, or is empty when the
    identifier names only a trust domain.
    """

    trust_domain: TrustDomain
    path: str

    @classmethod
    def parse(cls, value: str) -> SpiffeID:
        """Parse a SPIFFE ID URI.

        Raises :class:`SpiffeError` with code ``INVALID_SPIFFE_ID`` if the
        input is malformed.
        """
        trimmed = value.strip()
        if not trimmed.startswith(_SPIFFE_SCHEME):
            raise SpiffeError(
                SpiffeErrorCode.INVALID_SPIFFE_ID,
                f'SPIFFE ID must start with "spiffe://": {value!r}',
            )

        without_scheme = trimmed[len(_SPIFFE_SCHEME) :]
        slash_idx = without_scheme.find("/")
        if slash_idx == -1:
            domain_name, path = without_scheme, ""
        else:
            domain_name = without_scheme[:slash_idx]
            path = without_scheme[slash_idx:]

        if not domain_name:
            raise SpiffeError(
                SpiffeErrorCode.INVALID_SPIFFE_ID,
                f"SPIFFE ID has empty trust domain: {value!r}",
            )

        try:
            trust_domain = TrustDomain.parse(domain_name)
        except SpiffeError as exc:
            raise SpiffeError(
                SpiffeErrorCode.INVALID_SPIFFE_ID,
                f"SPIFFE ID has invalid trust domain: {value!r}",
                cause=exc,
            ) from exc

        return cls(trust_domain=trust_domain, path=path)

    def __str__(self) -> str:
        return f"{_SPIFFE_SCHEME}{self.trust_domain.name}{self.path}"

    def member_of(self, trust_domain: TrustDomain) -> bool:
        """Return whether this ID is issued by ``trust_domain``."""
        return self.trust_domain == trust_domain
