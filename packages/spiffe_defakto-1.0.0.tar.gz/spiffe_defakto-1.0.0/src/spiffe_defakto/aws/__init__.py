"""AWS credential provider backed by a SPIFFE JWT SVID.

Requires the ``aws`` optional dependency::

    pip install 'spiffe-defakto[aws]'
"""

from .credentials import FromSpiffeOptions, from_spiffe

__all__ = ["FromSpiffeOptions", "from_spiffe"]
