"""AWS credential provider that exchanges a SPIFFE JWT SVID for STS credentials.

The returned object is a :class:`botocore.credentials.RefreshableCredentials`
instance, so it drops straight into any ``boto3.client(..., credentials=...)``
call path used by the AWS SDK.
"""

from __future__ import annotations

import asyncio
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import TYPE_CHECKING

from .._internal.extras import missing_extra
from .._internal.sync_bridge import run_coro
from ..jwtsvid.types import JwtSVIDSource
from ..workload_api.client import WorkloadAPIClient

if TYPE_CHECKING:
    from typing import Any


_DEFAULT_AUDIENCE = "urn:defakto:security:server"
_DEFAULT_SESSION_NAME = "spiffe-session"
_DEFAULT_DURATION_SECONDS = 3600


@dataclass(frozen=True, slots=True)
class FromSpiffeOptions:
    """Options for :func:`from_spiffe`."""

    source: JwtSVIDSource | None = None
    """JWT SVID source. Defaults to ``WorkloadAPIClient().jwt`` created lazily."""

    role_arn: str | None = None
    """Target IAM role. Falls back to ``AWS_ROLE_ARN`` environment variable."""

    svid_audience: str | tuple[str, ...] = _DEFAULT_AUDIENCE
    role_session_name: str = _DEFAULT_SESSION_NAME
    provider_id: str | None = None
    policy_arns: tuple[dict[str, str], ...] = field(default_factory=tuple)
    policy: str | None = None
    duration_seconds: int = _DEFAULT_DURATION_SECONDS
    client_config: dict[str, object] = field(default_factory=dict)


def from_spiffe(options: FromSpiffeOptions | None = None) -> Any:
    """Return a :class:`botocore.credentials.RefreshableCredentials` object.

    Pass the result directly to ``boto3.client(..., aws_access_key_id=...)``
    is not the preferred path — instead wire it into a session::

        credentials = from_spiffe(FromSpiffeOptions(role_arn=...))
        session = boto3.Session(botocore_session=botocore.session.get_session())
        session._session._credentials = credentials
        s3 = session.client("s3")

    For most apps, though, use the higher-level ``boto3.Session`` helper that
    wraps the same primitive — see the README for a copy-paste example.
    """
    try:
        from botocore.credentials import RefreshableCredentials
    except ImportError:
        missing_extra("aws", "spiffe_defakto.aws.from_spiffe")

    opts = options or FromSpiffeOptions()
    role_arn = opts.role_arn or os.environ.get("AWS_ROLE_ARN")
    if not role_arn:
        raise ValueError(
            "role_arn must be provided via options or AWS_ROLE_ARN environment variable"
        )

    audiences = _ensure_list(opts.svid_audience)

    # Lazily resolve the SVID source — matches the TS SDK's behaviour so the
    # caller only pays for a WorkloadAPIClient if refresh actually fires.
    _source_box: list[JwtSVIDSource | None] = [opts.source]

    def _resolve_source() -> JwtSVIDSource:
        if _source_box[0] is None:
            _source_box[0] = WorkloadAPIClient().jwt
        return _source_box[0]  # type: ignore[return-value]

    def _refresh_sync() -> dict[str, Any]:
        return run_coro(_refresh_async(opts, role_arn, audiences, _resolve_source()))

    return RefreshableCredentials.create_from_metadata(
        metadata=_refresh_sync(),
        refresh_using=_refresh_sync,
        method="spiffe-defakto",
    )


def _ensure_list(value: str | tuple[str, ...]) -> list[str]:
    return [value] if isinstance(value, str) else list(value)


async def _refresh_async(
    opts: FromSpiffeOptions,
    role_arn: str,
    audiences: list[str],
    source: JwtSVIDSource,
) -> dict[str, Any]:
    import boto3

    svid = await source.fetch_svid(audiences)

    sts = boto3.client("sts", **opts.client_config)  # type: ignore[call-overload]
    kwargs: dict[str, Any] = {
        "RoleArn": role_arn,
        "RoleSessionName": opts.role_session_name,
        "WebIdentityToken": svid.token,
        "DurationSeconds": opts.duration_seconds,
    }
    if opts.provider_id:
        kwargs["ProviderId"] = opts.provider_id
    if opts.policy_arns:
        kwargs["PolicyArns"] = [dict(p) for p in opts.policy_arns]
    if opts.policy:
        kwargs["Policy"] = opts.policy

    resp = await asyncio.to_thread(sts.assume_role_with_web_identity, **kwargs)
    creds = resp["Credentials"]
    expiry = creds["Expiration"]
    if isinstance(expiry, datetime) and expiry.tzinfo is None:
        expiry = expiry.replace(tzinfo=timezone.utc)
    return {
        "access_key": creds["AccessKeyId"],
        "secret_key": creds["SecretAccessKey"],
        "token": creds["SessionToken"],
        "expiry_time": expiry.isoformat() if isinstance(expiry, datetime) else expiry,
    }
