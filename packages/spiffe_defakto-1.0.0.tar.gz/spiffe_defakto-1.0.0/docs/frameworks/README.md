# Framework integration guides

`spiffe-defakto` is async-first (`asyncio`), with a `SyncWorkloadAPIClient`
facade for sync code. Everything built on top of `asyncio` — which is
most of the Python async ecosystem — works natively. Trio requires a
bridge.

## Compatibility matrix

| Framework / runtime | Status | Which client | Guide |
| --- | --- | --- | --- |
| `asyncio` (stdlib)          | ✅ native         | `WorkloadAPIClient`             | [asyncio](asyncio.md) |
| [FastAPI](fastapi.md)       | ✅ native         | `WorkloadAPIClient` (lifespan)  | [fastapi](fastapi.md) |
| [Starlette](starlette.md)   | ✅ native         | `WorkloadAPIClient` (lifespan)  | [starlette](starlette.md) |
| [aiohttp](aiohttp.md)       | ✅ native         | `WorkloadAPIClient` (on_startup) | [aiohttp](aiohttp.md) |
| [Quart](quart.md)           | ✅ native         | `WorkloadAPIClient` (before_serving) | [quart](quart.md) |
| [Django](django.md)         | ✅ native         | Sync view → `SyncWorkloadAPIClient`, Async view → `WorkloadAPIClient` | [django](django.md) |
| [Flask](flask.md)           | ✅ sync facade    | `SyncWorkloadAPIClient`         | [flask](flask.md) |
| [Celery](celery.md)         | ✅ sync facade    | `SyncWorkloadAPIClient`         | [celery](celery.md) |
| [AnyIO](anyio.md)           | ✅ on asyncio backend | `WorkloadAPIClient`         | [anyio](anyio.md) |
| [Trio](trio.md)             | ⚠️ via `trio-asyncio` bridge or sync facade | `SyncWorkloadAPIClient` or `trio_asyncio.aio_as_trio(...)` | [trio](trio.md) |
| [uvloop](https://github.com/MagicStack/uvloop) | ✅ drop-in | `WorkloadAPIClient` (unchanged) | — |
| `ASGI` servers (uvicorn, hypercorn, daphne)  | ✅ | `WorkloadAPIClient` via the framework's lifespan | see ASGI framework guides |

## Which client should I use?

```
┌─ Are you inside an asyncio event loop?
│
├── Yes (FastAPI, aiohttp, Starlette, Django async views, Quart…)
│   └─► WorkloadAPIClient (async with)
│
├── No — sync code (Flask, Django sync views, Celery workers, scripts…)
│   └─► SyncWorkloadAPIClient (with)
│
└── Trio?
    ├─► Bridge via trio-asyncio, or
    └─► Use SyncWorkloadAPIClient (it owns its own loop thread)
```

## How rotation integrates with long-running servers

For server applications, prefer `watch_x509_context()` over polling
`get_svid()` — the SDK handles rotation and reconnects, and delivers a
fresh SVID exactly when SPIRE issues one. Each framework guide shows how
to run the watcher as a background task tied to the server's lifecycle,
so your TLS context or JWT source always reflects the current identity.

## Testing your integration

Every guide includes a smoke test recipe that spins up an in-process
fake SPIFFE agent — identical to what the SDK's own test suite uses,
so you can assert framework integration without a real SPIRE agent.
See [`tests/frameworks/`](../../tests/frameworks/) for working examples.
