# SPIFFE demo app

A runnable FastAPI service that shows off what `spiffe-defakto` can do:

- A clickable browser UI at `/` with the current SPIFFE ID, an expiry
  countdown, trust-bundle details, a rotation log, and a form to mint
  JWT SVIDs for any audience.
- JSON endpoints for every piece of that UI so you can poke it with
  `curl`/`xh`/etc.
- A background task subscribed to `watch_x509_context` — rotations show up
  on the page as they happen.

## Prereqs

- The SPIRL Tilt cluster running (`cd ~/Code/spirl && tilt up`).
- `kubectl` configured against the `kind-spirl-customer-k8s` context.
- Docker (for building the image) and `kind` (for loading it).
- `uv` in the repo root (only for building the SDK wheel we bake into the image).

## One-liner deploy

From the repository root:

```sh
# 1. Build the current SDK wheel and drop it next to the demo app.
uv build && cp dist/spiffe_defakto-*.whl examples/demo-app/

# 2. Build the image locally.
cd examples/demo-app
docker build -t spiffe-demo-python:latest .

# 3. Load it into the kind cluster so the Deployment can pull it.
kind load docker-image spiffe-demo-python:latest --name spirl-customer-k8s
# …or without the kind CLI on your PATH:
# docker save spiffe-demo-python:latest | \
#   docker exec -i spirl-customer-k8s-control-plane \
#     ctr --namespace=k8s.io images import --base-name docker.io/library/spiffe-demo-python -

# 4. Deploy.
kubectl --context kind-spirl-customer-k8s apply -f k8s.yaml
kubectl --context kind-spirl-customer-k8s wait --for=condition=Available \
    deployment/spiffe-demo-python -n spiffe-demo --timeout=60s

# 5. Open it in your browser.
kubectl --context kind-spirl-customer-k8s port-forward -n spiffe-demo \
    svc/spiffe-demo-python 8080:80
# → http://localhost:8080/
```

## Play with it

The browser page auto-refreshes every 15 s and shows a live expiry
countdown. Try:

- Click **Fetch JWT** with any audience — the agent signs a JWT scoped
  to it. The raw token and the decoded payload are both rendered.
- Expand **X.509 trust bundle** to see the trust authorities the agent
  advertises.
- Wait for a rotation; it shows up in the rotation-watcher card with a
  timestamp.

Programmatic pokes:

```sh
PF=http://localhost:8080

curl -s $PF/api/whoami | jq .
curl -s "$PF/api/jwt?audience=https://api.example.org" | jq .
curl -s $PF/api/bundle | jq '.authorities | length'
curl -s $PF/api/rotations | jq .
curl -s $PF/healthz | jq .
```

## Run locally without the cluster

Pointed at any SPIRE / spirl-agent socket on your host:

```sh
cd examples/demo-app
uv pip install -r requirements.txt
SPIFFE_ENDPOINT_SOCKET=unix:///run/spire/agent.sock uvicorn app:app --reload
```

Without a socket configured the landing page renders a clear startup
error instead of crashing — useful for eyeballing the UI itself.

## Iterate

The app is one `app.py` plus a single HTML template. When you change
something:

```sh
# From examples/demo-app/ after any SDK / app.py edit.
cd ../.. && uv build && cp dist/spiffe_defakto-*.whl examples/demo-app/
cd examples/demo-app
docker build -t spiffe-demo-python:latest .
kind load docker-image spiffe-demo-python:latest --name spirl-customer-k8s
kubectl --context kind-spirl-customer-k8s rollout restart \
    deployment/spiffe-demo-python -n spiffe-demo
```

## Clean up

```sh
kubectl --context kind-spirl-customer-k8s delete -f k8s.yaml
```
