# Changelog

All notable changes to `spiffe-defakto` are documented here.
The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/)
and the project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.0.0] — 2026-04-21

First stable release. Published to PyPI as
[`spiffe-defakto`](https://pypi.org/project/spiffe-defakto/).

### Added

#### Core clients
- `WorkloadAPIClient` — smart wrapper that auto-selects between the local
  and the attesting clients based on the environment
  (`SPIFFE_ENDPOINT_SOCKET` → local, `DEFAKTO_ATTESTORS` → attesting).
- `LocalWorkloadAPIClient` — SPIFFE Workload API gRPC client over Unix
  socket or TCP, with streaming `watch_x509_context()` and automatic
  reconnect with jittered backoff.
- `AttestingWorkloadAPIClient` — inline attestation for serverless and
  ephemeral environments, with polling rotation at 85 % of the SVID
  lifetime.
- `SyncWorkloadAPIClient` — blocking facade over the async API for
  scripts, Flask, Django sync views, Celery workers, and other non-async
  frameworks.

#### Attestation
- Built-in attestors: `AwsTokenAttestor` (STS `GetWebIdentityToken`),
  `AzureMSIAttestor` (Azure Managed Identity), `GcpIITAttestor` (GCE
  Instance Identity Token).
- Custom attestor support via the `Attestor` protocol (concurrent
  evidence collection through `asyncio.gather`).

#### SVID types and utilities
- X.509 and JWT SVID value types (frozen dataclasses), trust-bundle
  types, and source protocols (`X509SVIDSource`, `X509BundleSource`,
  `JwtSVIDSource`, `JwtBundleSource`).
- `X509Context` with `default_svid()`.
- PEM marshal/parse (`marshal_x509_svid`, `parse_marshaled_x509_svid`).
- `verify_x509_svid(raw_certs, bundle_source, options=None)` — validate
  a peer's X.509 SVID chain against a trust bundle. Enforces the SPIFFE
  leaf-SVID constraints (non-root path, non-CA leaf, no `keyCertSign` /
  `cRLSign` key usage), expiry on every certificate in the chain, and
  chain-signature verification back to one of the bundle's trust
  authorities. Supports RSA, ECDSA, and Ed25519 leaf keys.
- `parse_and_validate_jwt_svid(token, bundle_source, expected_audiences)`
  — JWT-SVID verification with the SPIFFE algorithm allowlist.
- `JwtClaims` — `TypedDict` for the standard JWT-SVID claim shape
  (`sub`, `aud`, `exp`, `iat`, `iss`, `jti`, `nbf`). Gives IDE
  autocomplete and static typing for the well-known claim names;
  custom claims stay accessible via `JwtSVID.claims`.

#### Identity value types
- `SpiffeID` and `TrustDomain` with strict parsing.
- `SpiffeError` + `SpiffeErrorCode` (14-code enum) for structured error
  handling.

#### Cloud credential integrations (optional extras)
- `spiffe_defakto.aws.from_spiffe` → `botocore.RefreshableCredentials`
  via STS `AssumeRoleWithWebIdentity` (`pip install 'spiffe-defakto[aws]'`).
- `spiffe_defakto.azure.SPIFFECredential` → Azure `TokenCredential`
  backed by `ClientAssertionCredential`
  (`pip install 'spiffe-defakto[azure]'`).
- `spiffe_defakto.gcp.SPIFFEIdentityPoolClient` → `google-auth`
  identity-pool credentials with optional service-account impersonation
  (`pip install 'spiffe-defakto[gcp]'`).

#### Tooling and docs
- Framework integration guides for FastAPI, Starlette, aiohttp, Quart,
  Flask, Django (sync + async), Celery, AnyIO, Trio, and plain
  `asyncio`, with runnable examples.
- Demo app at `examples/demo-app/` — a FastAPI service with a browser
  UI that renders the current SPIFFE ID, a live expiry countdown,
  trust-bundle details, and a JWT-SVID minting form.
- Real-agent end-to-end test scripts at `scripts/e2e/` that run against
  a real `spirl-agent` in a kind cluster.
- `py.typed` marker shipped; strict `mypy` enforcement across the SDK,
  tests, examples, and scripts.
- CI matrix across Python 3.10 – 3.13 on Ubuntu and macOS, plus a
  dedicated framework-integration job and a full-repo strict-typecheck
  job.

### Security hardening (vs. the TypeScript SDK)
- Cross-check the declared SPIFFE ID in each X509 SVID response against
  the leaf certificate's SubjectAltName — rejects tampered responses.
- Regex-validate `DEFAKTO_TRUST_DOMAIN_ID` before hostname
  interpolation into the attesting endpoint.
- Warn on `insecure_skip_tls` against non-loopback addresses.
- Case-insensitive SPIFFE URI scheme matching (RFC 3986 § 3.1).
- Reconnect backoff on `watch_x509_context` to prevent CPU-spinning
  against a misbehaving agent.
