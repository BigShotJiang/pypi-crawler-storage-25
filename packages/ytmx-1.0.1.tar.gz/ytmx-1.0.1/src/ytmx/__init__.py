"""ytmx: A full-featured YouTube Music TUI client."""

from __future__ import annotations

__version__ = "1.0.1"
