"""Configuration management for ytm-player."""

from __future__ import annotations

from ytmx.config.keymap import Action, KeyMap, MatchResult, get_keymap
from ytmx.config.settings import Settings, get_settings

__all__ = ["Settings", "get_settings", "KeyMap", "Action", "MatchResult", "get_keymap"]
