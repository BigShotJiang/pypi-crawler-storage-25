"""Sidebar toggling and playlist sidebar event handling mixin for YTMPlayerApp."""

from __future__ import annotations

import logging

from ytmx.ui.header_bar import HeaderBar
from ytmx.ui.popups.actions import ActionsPopup
from ytmx.ui.sidebars.lyrics_sidebar import LyricsSidebar
from ytmx.ui.sidebars.playlist_sidebar import PlaylistSidebar
from ytmx.utils.formatting import strip_vl_prefix

logger = logging.getLogger(__name__)


class SidebarMixin:
    """Sidebar toggling and playlist sidebar event handlers."""

    # ── Sidebar toggling ────────────────────────────────────────────

    def _toggle_playlist_sidebar(self) -> None:
        """Toggle the playlist sidebar for the current page."""
        page = self._current_page or "library"
        current = self._sidebar_per_page.get(page, self._sidebar_default)
        new_state = not current
        self._sidebar_per_page[page] = new_state
        self._apply_playlist_sidebar(new_state)

    def _toggle_lyrics_sidebar(self) -> None:
        """Toggle the lyrics sidebar globally."""
        self._lyrics_sidebar_open = not self._lyrics_sidebar_open
        self._apply_lyrics_sidebar(self._lyrics_sidebar_open)

    def _apply_playlist_sidebar(self, visible: bool) -> None:
        """Set playlist sidebar visibility and update header bar state."""
        try:
            ps = self.query_one("#playlist-sidebar", PlaylistSidebar)
            if visible:
                ps.remove_class("hidden")
            else:
                ps.add_class("hidden")
        except Exception:
            logger.debug("Failed to apply playlist sidebar visibility", exc_info=True)
        try:
            header = self.query_one("#app-header", HeaderBar)
            header.set_playlist_state(visible)
        except Exception:
            pass

    def _apply_lyrics_sidebar(self, visible: bool) -> None:
        """Set lyrics sidebar visibility and update header bar state."""
        try:
            ls = self.query_one("#lyrics-sidebar", LyricsSidebar)
            if visible:
                ls.remove_class("hidden")
                ls.activate()
            else:
                ls.add_class("hidden")
        except Exception:
            logger.debug("Failed to apply lyrics sidebar visibility", exc_info=True)
        try:
            header = self.query_one("#app-header", HeaderBar)
            header.set_lyrics_state(visible)
        except Exception:
            pass

    def _toggle_album_art(self) -> None:
        """Toggle album art visibility in the playback bar."""
        try:
            from ytmx.ui.widgets.album_art import AlbumArt

            art = self.query_one("#pb-art", AlbumArt)
            art.display = not art.display
        except Exception:
            logger.debug("Failed to toggle album art visibility", exc_info=True)

    # ── Sidebar message handlers ─────────────────────────────────────

    def on_header_bar_toggle_playlist_sidebar(
        self, message: HeaderBar.TogglePlaylistSidebar
    ) -> None:
        self._toggle_playlist_sidebar()

    def on_header_bar_toggle_lyrics_sidebar(self, message: HeaderBar.ToggleLyricsSidebar) -> None:
        self._toggle_lyrics_sidebar()

    async def on_playlist_sidebar_playlist_selected(
        self, message: PlaylistSidebar.PlaylistSelected
    ) -> None:
        """Navigate to library with the selected playlist."""
        item = message.item_data
        playlist_id = item.get("playlistId") or item.get("browseId")
        if playlist_id:
            await self.navigate_to("library", playlist_id=playlist_id)

    # First batch size for progressive playlist loading.
    _SIDEBAR_FIRST_BATCH = 300

    async def on_playlist_sidebar_playlist_double_clicked(
        self, message: PlaylistSidebar.PlaylistDoubleClicked
    ) -> None:
        """Queue all tracks from double-clicked playlist and start playback."""
        from ytmx.utils.formatting import normalize_tracks

        item = message.item_data
        playlist_id = item.get("playlistId") or item.get("browseId")
        if not playlist_id or not self.ytmusic:
            return
        try:
            data = await self.ytmusic.get_playlist(
                playlist_id, limit=self._SIDEBAR_FIRST_BATCH, order="recently_added"
            )
            raw_tracks = data.get("tracks", [])
            tracks = normalize_tracks(raw_tracks)
            if not tracks:
                self.notify("Playlist is empty", severity="warning")
                return
            self.queue.clear()
            self.queue.add_multiple(tracks)
            self.queue.jump_to(0)
            self._active_library_playlist_id = playlist_id
            await self.play_track(self.queue.current_track)

            # Background-fetch remaining tracks and append to queue.
            total_count = data.get("trackCount") or len(raw_tracks)
            if total_count > len(raw_tracks):
                self.run_worker(
                    self._fetch_remaining_for_queue(playlist_id, len(raw_tracks)),
                    name="sidebar-fetch-remaining",
                )
        except Exception:
            logger.exception("Failed to load playlist %s for playback", playlist_id)
            self.notify("Failed to load playlist", severity="error")

    async def _fetch_remaining_for_queue(self, playlist_id: str, already_have: int) -> None:
        """Background fetch remaining tracks and append to the queue."""
        from ytmx.utils.formatting import normalize_tracks

        try:
            remaining = await self.ytmusic.get_playlist_remaining(
                playlist_id, already_have, order="recently_added"
            )
            if remaining:
                tracks = normalize_tracks(remaining)
                self.queue.add_multiple(tracks)
        except Exception:
            logger.debug("Failed to fetch remaining playlist tracks for queue", exc_info=True)

    async def _add_playlist_to_queue(self, playlist_id: str) -> None:
        """Fetch playlist tracks and add them to the queue."""
        from ytmx.utils.formatting import normalize_tracks

        if not self.ytmusic:
            return
        try:
            data = await self.ytmusic.get_playlist(playlist_id)
            tracks = normalize_tracks(data.get("tracks", []))
            if tracks:
                self.queue.add_multiple(tracks)
                self._refresh_queue_page()
                self.notify(f"Added {len(tracks)} tracks to queue", timeout=2)
            else:
                self.notify("Playlist is empty", severity="warning", timeout=2)
        except Exception:
            logger.debug("Failed to add playlist to queue", exc_info=True)
            self.notify("Failed to add to queue", severity="error", timeout=2)

    def on_playlist_sidebar_playlist_right_clicked(
        self, message: PlaylistSidebar.PlaylistRightClicked
    ) -> None:
        """Open context menu for right-clicked playlist."""
        item = message.item_data
        if item is not None:
            self._open_playlist_context_menu(item)
        else:
            self._prompt_create_playlist()

    async def on_playlist_sidebar_nav_item_clicked(
        self, message: PlaylistSidebar.NavItemClicked
    ) -> None:
        """Navigate to liked_songs or recently_played from sidebar pinned nav."""
        await self.navigate_to(message.nav_id)

    def _open_playlist_context_menu(self, item: dict) -> None:
        """Push ActionsPopup for a sidebar playlist item."""

        def _handle_action(action_id: str | None) -> None:
            if action_id is None:
                return
            if action_id in ("play_all", "shuffle_play"):
                pid = item.get("playlistId") or item.get("browseId")
                if pid:
                    self.run_worker(self.navigate_to("library", playlist_id=pid))
            elif action_id == "add_to_queue":
                pid = item.get("playlistId") or item.get("browseId")
                if pid:
                    self.run_worker(self._add_playlist_to_queue(pid))
                else:
                    self.notify("No playlist ID found", severity="error", timeout=2)
            elif action_id == "edit":
                self._prompt_edit_playlist(item)
            elif action_id == "delete":
                from ytmx.ui.popups.confirm_popup import ConfirmPopup

                title = item.get("title", "this playlist")

                def _on_confirm(confirmed: bool) -> None:
                    if confirmed:
                        self.run_worker(self._delete_sidebar_playlist(item))

                self.push_screen(
                    ConfirmPopup(f"Are you sure you want to delete '{title}'?"),
                    _on_confirm,
                )
            elif action_id == "copy_link":
                try:
                    ps = self.query_one("#playlist-sidebar", PlaylistSidebar)
                    ps.copy_item_link(item)
                except Exception:
                    pass

        self.push_screen(ActionsPopup(item, item_type="playlist"), _handle_action)

    # ── Panel focus (Alt+h / Alt+l) ─────────────────────────────────

    def _panel_focus(self, direction: int) -> None:
        """Shift focus one panel left (direction=-1) or right (direction=1)."""
        panels = self._get_visible_panels()
        if not panels:
            return
        current = self._focused_panel_index(panels)
        self._activate_panel(panels[(current + direction) % len(panels)])

    def _get_visible_panels(self) -> list[str]:
        """Ordered list of panel IDs that are currently visible."""
        panels: list[str] = []
        try:
            if not self.query_one("#playlist-sidebar").has_class("hidden"):
                panels.append("sidebar")
        except Exception:
            pass
        panels.append("main")
        # LyricsSidebar has no focusable widgets — excluded intentionally.
        return panels

    def _focused_panel_index(self, panels: list[str]) -> int:
        """Return index of the panel that currently contains focus."""
        from ytmx.ui.sidebars.playlist_sidebar import PlaylistSidebar

        widget = self.focused
        while widget is not None:
            if isinstance(widget, PlaylistSidebar):
                try:
                    return panels.index("sidebar")
                except ValueError:
                    pass
                break
            widget = widget.parent
        try:
            return panels.index("main")
        except ValueError:
            return 0

    def _activate_panel(self, panel_id: str) -> None:
        if panel_id == "sidebar":
            self._focus_playlist_sidebar()
        else:
            self._focus_main_content()

    def _focus_playlist_sidebar(self) -> None:
        """Move focus to the playlist list in the sidebar."""
        from textual.widgets import ListView

        try:
            lv = self.query_one("#ps-playlists-list", ListView)
            lv.focus()
        except Exception:
            logger.debug("Failed to focus playlist sidebar", exc_info=True)

    @staticmethod
    def _is_on_screen(w: object) -> bool:
        """Return True if the widget and ALL its ancestors have display=True.

        Textual's w.display only reflects the widget's own CSS/reactive state,
        not whether a parent has been hidden. Walk the full ancestor chain so
        we never focus a widget whose parent section is hidden (e.g. an
        inactive Browse tab).
        """
        node = w
        while node is not None:
            if not getattr(node, "display", True):
                return False
            node = getattr(node, "parent", None)
        return True

    def _focus_main_content(self) -> None:
        """Move focus to the primary interactive widget in the current page."""
        from textual.widgets import DataTable, ListView

        from ytmx.ui.widgets.track_table import TrackTable

        try:
            content = self.query_one("#main-content")
            # TrackTable first (extends DataTable; most feature-rich pages use it).
            for w in content.query(TrackTable):
                if self._is_on_screen(w):
                    w.focus()
                    return
            # Plain DataTable (LikedSongs, Queue, RecentlyPlayed).
            for w in content.query(DataTable):
                if self._is_on_screen(w):
                    w.focus()
                    return
            # ListView fallback (Browse → For You / Moods sections).
            for w in content.query(ListView):
                if self._is_on_screen(w):
                    w.focus()
                    return
        except Exception:
            logger.debug("Failed to focus main content", exc_info=True)

    async def _refresh_playlist_sidebar(self) -> None:
        """Force-reload the playlist sidebar."""
        try:
            ps = self.query_one("#playlist-sidebar", PlaylistSidebar)
            await ps.refresh_playlists()
            self.notify("Playlists refreshed", timeout=2)
        except Exception:
            logger.debug("Failed to refresh playlist sidebar", exc_info=True)

    def _prompt_create_playlist(self) -> None:
        """Show an input screen to create a new playlist."""
        from ytmx.ui.popups.create_playlist_popup import CreatePlaylistPopup

        def _on_result(result: tuple[str, str, str] | None) -> None:
            if result:
                name, description, privacy = result
                self.run_worker(self._create_sidebar_playlist(name, description, privacy))

        self.push_screen(CreatePlaylistPopup(), _on_result)

    def _prompt_edit_playlist(self, item: dict) -> None:
        """Fetch playlist detail then show the edit popup pre-filled."""
        self.run_worker(self._fetch_playlist_meta_for_edit(item))

    async def _fetch_playlist_meta_for_edit(self, item: dict) -> None:
        """Fetch description/privacy from the API, then open the edit popup."""
        current_name = item.get("title", "")
        current_description = ""
        current_privacy = "PRIVATE"

        playlist_id = item.get("playlistId") or item.get("browseId", "")
        if playlist_id and self.ytmusic:
            try:
                data = await self.ytmusic.get_playlist(strip_vl_prefix(playlist_id), limit=1)
                current_description = data.get("description") or ""
                current_privacy = data.get("privacy", "PRIVATE")
            except Exception:
                logger.debug("Failed to fetch playlist detail for edit popup", exc_info=True)

        self._open_edit_popup(item, current_name, current_description, current_privacy)

    def _open_edit_popup(self, item: dict, name: str, description: str, privacy: str) -> None:
        """Push the edit popup pre-filled with the given metadata."""
        from ytmx.ui.popups.create_playlist_popup import CreatePlaylistPopup

        def _on_result(result: tuple[str, str, str] | None) -> None:
            if result:
                new_name, new_description, new_privacy = result
                self.run_worker(
                    self._edit_sidebar_playlist(item, new_name, new_description, new_privacy)
                )

        self.push_screen(
            CreatePlaylistPopup(
                initial_name=name,
                initial_description=description,
                initial_privacy=privacy,
                edit_mode=True,
            ),
            _on_result,
        )

    async def _create_sidebar_playlist(
        self, name: str, description: str = "", privacy: str = "PRIVATE"
    ) -> None:
        """Create a new playlist and refresh the sidebar."""
        if not self.ytmusic:
            return
        try:
            playlist_id = await self.ytmusic.create_playlist(name, description, privacy=privacy)
            if playlist_id:
                self.notify(f"Created '{name}'", timeout=2)
                ps = self.query_one("#playlist-sidebar", PlaylistSidebar)
                panel = ps.query_one("#ps-playlists")
                panel.prepend_item({"playlistId": playlist_id, "title": name, "count": 0})
            else:
                self.notify("Failed to create playlist", severity="error", timeout=3)
        except Exception:
            logger.exception("Failed to create playlist %r", name)
            self.notify("Failed to create playlist", severity="error", timeout=3)

    async def _edit_sidebar_playlist(
        self, item: dict, name: str, description: str, privacy: str
    ) -> None:
        """Call the API to edit playlist metadata, then update the UI if successful."""
        if not self.ytmusic:
            return
        playlist_id = item.get("playlistId") or item.get("browseId", "")
        if not playlist_id:
            self.notify("Cannot determine playlist ID", severity="error", timeout=3)
            return
        raw_id = strip_vl_prefix(playlist_id)
        try:
            await self.ytmusic.edit_playlist(
                raw_id, title=name, description=description, privacy_status=privacy
            )
            self.notify(f"Updated '{name}'", timeout=2)
            await self._apply_playlist_edit_to_ui(
                item, playlist_id, raw_id, name, description, privacy
            )
        except Exception:
            logger.exception("Failed to edit playlist %r", playlist_id)
            self.notify("Failed to edit playlist", severity="error", timeout=3)

    async def _apply_playlist_edit_to_ui(
        self,
        item: dict,
        playlist_id: str,
        raw_id: str,
        name: str,
        description: str,
        privacy: str,
    ) -> None:
        """Update the sidebar panel and library header to reflect a successful edit."""
        try:
            ps = self.query_one("#playlist-sidebar", PlaylistSidebar)
            panel = ps.query_one("#ps-playlists")
            for stored in panel._items:
                pid = stored.get("playlistId") or stored.get("browseId", "")
                if pid in (playlist_id, raw_id, f"VL{raw_id}"):
                    stored["title"] = name
                    stored["description"] = description
                    stored["privacy"] = privacy
                    break
            panel._rebuild_list(panel._filtered_items)
        except Exception:
            logger.debug("Failed to update sidebar panel after edit", exc_info=True)

        try:
            from ytmx.ui.pages.library import LibraryPage

            active_pid = self._current_page_kwargs.get("playlist_id", "")
            if self._current_page == "library" and active_pid in (playlist_id, raw_id):
                library = self.query_one(LibraryPage)
                await library.refresh_header(name, description, privacy)
        except Exception:
            logger.debug("Failed to refresh library header after playlist edit", exc_info=True)

    async def _delete_sidebar_playlist(self, item: dict) -> None:
        """Delete or remove a playlist and refresh the sidebar."""
        if not self.ytmusic:
            return
        playlist_id = item.get("playlistId") or item.get("browseId", "")
        title = item.get("title", "playlist")
        if not playlist_id:
            self.notify("Cannot determine playlist ID", severity="error", timeout=3)
            return
        raw_id = strip_vl_prefix(playlist_id)
        try:
            # Try delete first (owned playlists), fall back to remove from library.
            success = False
            try:
                success = await self.ytmusic.delete_playlist(playlist_id)
            except Exception:
                pass
            if not success:
                success = await self.ytmusic.remove_album_from_library(raw_id)
            if success:
                self.notify(f"Removed '{title}'", timeout=2)
                ps = self.query_one("#playlist-sidebar", PlaylistSidebar)
                ps.query_one("#ps-playlists").remove_item(raw_id)
                # If the deleted playlist is currently open, navigate to plain library.
                active_pid = self._current_page_kwargs.get("playlist_id", "")
                if self._current_page == "library" and active_pid in (playlist_id, raw_id):
                    await self.navigate_to("library", playlist_id=None)
            else:
                self.notify("Failed to remove playlist", severity="error", timeout=3)
        except Exception:
            logger.exception("Failed to remove playlist %r", playlist_id)
            self.notify("Failed to remove playlist", severity="error", timeout=3)
