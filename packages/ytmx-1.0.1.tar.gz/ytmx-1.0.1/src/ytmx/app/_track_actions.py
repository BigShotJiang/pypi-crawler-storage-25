"""Track action handling mixin for YTMPlayerApp."""

from __future__ import annotations

import logging

from ytmx.ui.playback_bar import PlaybackBar
from ytmx.ui.popups.actions import ActionsPopup
from ytmx.ui.popups.playlist_picker import PlaylistPicker
from ytmx.ui.widgets.track_table import TrackTable
from ytmx.utils.formatting import copy_to_clipboard, get_video_id

logger = logging.getLogger(__name__)


class TrackActionsMixin:
    """Track table integration and actions popup wiring."""

    async def on_track_table_track_selected(self, message: TrackTable.TrackSelected) -> None:
        """Handle track selection from any TrackTable widget."""
        track = message.track
        index = message.index

        # Set the queue position and play.
        self.queue.jump_to_real(index)
        await self.play_track(track)

    def _get_focused_track(self) -> dict | None:
        """Try to get a track dict from the currently focused widget."""
        focused = self.focused
        if focused is None:
            return None

        # Walk up looking for a TrackTable or any widget exposing get_selected_track().
        widget = focused
        while widget is not None:
            if isinstance(widget, TrackTable):
                return widget.selected_track
            if hasattr(widget, "get_selected_track"):
                return widget.get_selected_track()  # type: ignore[attr-defined]
            widget = widget.parent
        return None

    async def _open_add_to_playlist(self) -> None:
        """Open PlaylistPicker for the currently playing track."""
        track = None

        # Prefer the currently playing track.
        if self.player and self.player.current_track:
            track = self.player.current_track

        if not track:
            self.notify("No track is playing.", severity="warning", timeout=2)
            return

        video_id = get_video_id(track)
        if not video_id:
            self.notify("Track has no video ID.", severity="warning", timeout=2)
            return

        self.push_screen(PlaylistPicker(video_ids=[video_id]))

    @staticmethod
    def _infer_item_type(item: dict) -> str:
        """Detect ActionsPopup item_type from a raw item dict.

        Browse's ForYou shelves can contain songs, playlists, albums or
        artists — inspect the dict to pick the right popup type.
        """
        result_type = (item.get("resultType") or item.get("type") or "").lower()
        if result_type in ("song", "video", "flat_song"):
            return "track"
        if result_type in ("album", "single"):
            return "album"
        if result_type == "artist":
            return "artist"
        if result_type == "playlist":
            return "playlist"
        # Fall back to field presence when resultType is absent.
        if item.get("video_id") or item.get("videoId"):
            return "track"
        if item.get("playlistId") or item.get("audioPlaylistId"):
            return "playlist"
        browse_id = item.get("browseId", "")
        if browse_id.startswith("MPREb_"):
            return "album"
        return "track"

    async def _open_track_actions(self) -> None:
        """Open ActionsPopup for the focused item (track, playlist, album…)."""
        item = self._get_focused_track()
        if not item:
            # Fall back to currently playing track.
            if self.player and self.player.current_track:
                item = self.player.current_track
            else:
                self.notify("No track selected.", severity="warning", timeout=2)
                return

        item_type = self._infer_item_type(item)
        self._open_actions_for_track(item, item_type=item_type)

    def _open_actions_for_track(self, track: dict, item_type: str = "track") -> None:
        """Push ActionsPopup for a specific item dict."""

        def _handle_action_result(action_id: str | None) -> None:
            """Callback when the user picks an action from the popup."""
            if action_id is None:
                return

            if action_id == "add_to_playlist":
                video_id = get_video_id(track)
                if video_id:
                    self.push_screen(PlaylistPicker(video_ids=[video_id]))
                return

            if action_id == "play":
                self.run_worker(self.play_track(track))
            elif action_id == "download":
                self.run_worker(self._download_track(track))
            elif action_id == "play_next":
                self.queue.add_next(track)
                self._refresh_queue_page()
                self.notify("Playing next", timeout=2)
            elif action_id == "add_to_queue":
                self.queue.add(track)
                self._refresh_queue_page()
                self.notify("Added to queue", timeout=2)
            elif action_id == "start_radio":
                self.run_worker(self._start_radio_for(track))
            elif action_id == "go_to_artist":
                artists = track.get("artists", [])
                if isinstance(artists, list) and artists:
                    artist = artists[0]
                    artist_id = artist.get("id") or artist.get("browseId", "")
                    if artist_id:
                        self.run_worker(
                            self.navigate_to("context", context_type="artist", context_id=artist_id)
                        )
            elif action_id == "go_to_album":
                album = track.get("album", {})
                album_id = (
                    track.get("album_id")
                    or (album.get("id") if isinstance(album, dict) else None)
                    or ""
                )
                if album_id:
                    self.run_worker(
                        self.navigate_to("context", context_type="album", context_id=album_id)
                    )
            elif action_id == "toggle_like":
                video_id = get_video_id(track)
                if video_id and self.ytmusic:
                    is_liked = track.get("likeStatus") == "LIKE" or track.get("liked", False)
                    rating = "INDIFFERENT" if is_liked else "LIKE"
                    label = "Unliked" if is_liked else "Liked"

                    async def _rate(vid: str, r: str, lbl: str) -> None:
                        try:
                            await self.ytmusic.rate_song(vid, r)
                            track["likeStatus"] = r
                            self.notify(lbl, timeout=2)
                        except Exception:
                            self.notify(
                                f"Failed to {lbl.lower()} track", severity="error", timeout=3
                            )

                    self.run_worker(_rate(video_id, rating, label))
            elif action_id == "copy_link":
                video_id = get_video_id(track)
                if video_id:
                    link = f"https://music.youtube.com/watch?v={video_id}"
                    if copy_to_clipboard(link):
                        self.notify("Link copied", timeout=2)
                    else:
                        self.notify(link, timeout=5)

        self.push_screen(ActionsPopup(track, item_type=item_type), _handle_action_result)

    def _refresh_queue_page(self) -> None:
        """Refresh the queue page if it's currently displayed."""
        try:
            from ytmx.ui.pages.queue import QueuePage

            queue_page = self.query_one(QueuePage)
            queue_page._refresh_queue()
        except Exception:
            pass

    def on_track_table_track_right_clicked(self, message: TrackTable.TrackRightClicked) -> None:
        """Handle right-click on any TrackTable -- open actions popup."""
        self._open_actions_for_track(message.track)

    def on_playback_bar_track_right_clicked(self, message: PlaybackBar.TrackRightClicked) -> None:
        """Handle right-click on the playback bar -- open actions popup."""
        self._open_actions_for_track(message.track)

    async def _start_radio_for(self, track: dict) -> None:
        """Start radio from a specific track."""
        video_id = get_video_id(track)
        if not video_id or not self.ytmusic:
            return

        self.notify("Starting radio...", timeout=3)
        try:
            from ytmx.utils.formatting import normalize_tracks

            radio_tracks = normalize_tracks(await self.ytmusic.get_radio(video_id))
        except Exception:
            logger.exception("Failed to start radio")
            self.notify("Failed to start radio", severity="error")
            return

        if radio_tracks:
            self.queue.clear()
            self.queue.set_radio_tracks(radio_tracks)
            first = self.queue.next_track()
            if first:
                await self.play_track(first)
