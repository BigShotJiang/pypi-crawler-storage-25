"""Entry point for `python -m ytmx`."""

from __future__ import annotations

from ytmx.cli import main

if __name__ == "__main__":
    main()
