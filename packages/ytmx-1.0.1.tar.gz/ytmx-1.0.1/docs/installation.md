# Installation

## Requirements

- **Python 3.12+**
- **[mpv](https://mpv.io/)** — audio playback backend, must be installed system-wide
- A **YouTube Music** account (free or Premium)

## 1. Install mpv

```bash
# Arch / CachyOS / Manjaro
sudo pacman -S mpv

# Ubuntu / Debian
sudo apt install mpv

# Fedora
sudo dnf install mpv

# macOS (Homebrew)
brew install mpv

# Windows
scoop install mpv
# Windows requires extra setup — see Windows section below
```

## 2. Install ytmx

### pip

```bash
pip install ytmx
```

### uv (recommended)

```bash
uv tool install ytmx
```

[uv](https://docs.astral.sh/uv/) installs ytmx in an isolated environment and adds `ytmx` to your PATH automatically.

### pipx

```bash
pipx install ytmx
```

[pipx](https://pipx.pypa.io/) also handles PATH automatically and works well on systems that restrict global pip installs (e.g. Arch, newer Ubuntu).

### AUR (Arch Linux / CachyOS / EndeavourOS / Manjaro)

```bash
yay -S ytmx-git
```

### Gentoo ([GURU](https://wiki.gentoo.org/wiki/Project:GURU))

Enable the GURU repository then:

```bash
emerge --ask media-sound/ytmx
```

### NixOS (Flake)

**Try without installing:**

```bash
nix run github:Villoh/ytmx
```

**Add to your system flake:**

```nix
{
  inputs.ytmx.url = "github:Villoh/ytmx";

  outputs = { nixpkgs, ytmx, ... }: {
    nixosConfigurations.myhost = nixpkgs.lib.nixosSystem {
      modules = [
        {
          nixpkgs.overlays = [ ytmx.overlays.default ];
          environment.systemPackages = with pkgs; [
            ytmx        # core
            # ytmx-full  # all features (Discord, Last.fm, Spotify import)
          ];
        }
      ];
    };
  };
}
```

**Imperatively:**

```bash
nix profile install github:Villoh/ytmx
nix profile install github:Villoh/ytmx#ytmx-full
```

> If installing via `pip` on NixOS, add to your shell config:
> ```bash
> export LD_LIBRARY_PATH="/run/current-system/sw/lib:$LD_LIBRARY_PATH"
> ```
> The flake handles this automatically.

### From source

```bash
git clone https://github.com/Villoh/ytmx.git
cd ytmx
python -m venv .venv
source .venv/bin/activate
pip install -e .
```

## Optional extras

### pip

```bash
pip install "ytmx[spotify]"        # Spotify playlist import
pip install "ytmx[mpris]"          # MPRIS media keys (Linux)
pip install "ytmx[discord]"        # Discord Rich Presence
pip install "ytmx[lastfm]"         # Last.fm scrobbling
pip install "ytmx[transliteration]" # Lyrics transliteration (non-Latin → ASCII)
pip install "ytmx[spotify,mpris,discord,lastfm,transliteration]"  # All
```

### AUR

On Arch, use pacman/yay instead of pip ([PEP 668](https://peps.python.org/pep-0668/)):

```bash
sudo pacman -S python-dbus-next   # MPRIS
yay -S python-pylast              # Last.fm
yay -S python-pypresence          # Discord
yay -S python-spotipy python-thefuzz  # Spotify import
```

## Windows Setup

On Windows, `scoop install mpv` only installs the player executable — `libmpv-2.dll` must be downloaded separately.

1. Install mpv: `scoop install mpv`
2. Install 7zip: `scoop install 7zip`
3. Download **`mpv-dev-x86_64-*.7z`** from [shinchiro's mpv builds](https://github.com/shinchiro/mpv-winbuild-cmake/releases)
4. Extract `libmpv-2.dll` into your mpv directory:

```powershell
7z e "$env:TEMP\mpv-dev-x86_64-*.7z" -o"$env:USERPROFILE\scoop\apps\mpv\current" libmpv-2.dll -y
```

ytmx automatically searches common install locations (scoop, chocolatey, Program Files) for the DLL.

## 3. Authenticate

```bash
ytmx setup                    # Auto-detect browser cookies
ytmx setup --browser firefox  # Target a specific browser
ytmx setup --manual           # Paste headers manually
```

**Automatic:** Scans Chrome, Chromium, Brave, Firefox, Edge, Vivaldi, Opera for YouTube Music cookies.

**Manual:**
1. Open [music.youtube.com](https://music.youtube.com) in your browser
2. DevTools (F12) → Network tab → Refresh → filter `/browse`
3. Right-click a `music.youtube.com` request → Copy request headers
4. Paste into the wizard and press Enter on an empty line

Credentials are stored in `~/.config/ytmx/auth.json` with `0o600` permissions.
