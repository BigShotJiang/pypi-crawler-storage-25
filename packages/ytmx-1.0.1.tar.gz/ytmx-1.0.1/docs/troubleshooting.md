# Troubleshooting

## "mpv not found" or playback doesn't start

Ensure mpv is installed and in your `$PATH`:

```bash
mpv --version
```

If installed but not found, check the shared library is available:

```bash
# Arch
pacman -Qs mpv

# Ubuntu/Debian
sudo apt install libmpv-dev
```

## Authentication fails

- Make sure you're signed in to YouTube Music in your browser
- Try a different browser: `ytmx setup --browser firefox`
- If auto-detection fails, use manual mode: `ytmx setup --manual`
- Re-run `ytmx setup` to re-authenticate

## No sound / wrong audio device

mpv uses your system's default audio output. To change it, create `~/.config/mpv/mpv.conf`:

```
audio-device=pulse/your-device-name
```

List available devices with `mpv --audio-device=help`.

## macOS media keys open Apple Music instead of ytmx

- Start playback in ytmx first — macOS routes media keys to the active Now Playing app.
- Grant Accessibility and Input Monitoring permission to your terminal app in System Settings → Privacy & Security.
- If Apple Music still steals keys, fully quit Music.app and press play/pause once in ytmx.

## MPRIS / media keys not working (Linux)

Install the optional MPRIS dependency:

```bash
pip install "ytmx[mpris]"
```

Requires D-Bus (standard on most Linux desktops). Verify with:

```bash
dbus-send --session --print-reply --dest=org.freedesktop.DBus /org/freedesktop/DBus org.freedesktop.DBus.ListNames
```

## Cache taking too much space

```bash
ytmx cache status
ytmx cache clear
```

Or reduce the limit in `config.toml`:

```toml
[cache]
max_size_mb = 512
```

## Logs and diagnostics

Log file locations:

- Linux/macOS: `~/.config/ytmx/logs/ytm.log`
- Windows: `%APPDATA%\ytmx\logs\ytm.log`

Crash tracebacks are saved to the `crashes/` directory next to the log file.

Verbose logging:

```bash
ytmx --debug
```

When reporting a bug, run:

```bash
ytmx doctor
```

and paste the output into your GitHub issue. It includes version, Python and mpv versions, paths, the last 50 log lines, and the most recent crash trace.
