# Configuration

Config files live in `~/.config/ytmx/` (respects `$XDG_CONFIG_HOME`; on Windows `%APPDATA%\ytmx\`):

| File | Purpose |
|------|---------|
| `config.toml` | General settings, playback, cache, UI |
| `keymap.toml` | Custom keybinding overrides |
| `themes/` | User-defined custom themes |
| `auth.json` | YouTube Music credentials (auto-generated) |

Open the config directory:

```bash
ytmx config
```

## config.toml

```toml
[general]
startup_page = "library"     # library, search, browse
brand_account_id = ""        # YouTube Brand Account ID (21-digit, find at myaccount.google.com/brandaccounts)
check_for_updates = true

[playback]
audio_quality = "high"       # high, medium, low
default_volume = 80          # 0-100
autoplay = true
seek_step = 5                # seconds per seek

[cache]
enabled = true
max_size_mb = 1024           # 1GB default
prefetch_next = true

[yt_dlp]
cookies_file = ""            # Optional: path to yt-dlp Netscape cookies.txt
remote_components = ""       # Optional: ejs:npm/ejs:github
js_runtimes = ""             # Optional: bun or bun:/path/to/bun

[ui]
album_art = true
theme = "ytm-dark"           # e.g. catppuccin-mocha, dracula, nord, tokyo-night
progress_style = "block"     # block or line
sidebar_width = 30
col_index = 4                # 0 = auto-fill
col_title = 0
col_artist = 30
col_album = 25
col_duration = 8
bidi_mode = "auto"           # auto, reorder, passthrough (RTL text handling)

[notifications]
enabled = true
timeout_seconds = 5

[mpris]
enabled = true

[discord]
enabled = false              # Requires pypresence

[lastfm]
enabled = false              # Requires pylast
api_key = ""
api_secret = ""
session_key = ""
username = ""
```

## Custom themes

Drop `.toml` files in `~/.config/ytmx/themes/` to define your own themes. They appear in the `Ctrl+P` picker alongside built-in Textual themes.

Only `name` and `primary` are required:

```toml
name    = "my-theme"
primary = "#cba6f7"
```

Full palette with ytmx-specific color overrides:

```toml
name       = "my-theme"
primary    = "#cba6f7"
secondary  = "#aaaaaa"
accent     = "#b07ad4"
success    = "#a6e3a1"
warning    = "#f9e2af"
error      = "#f38ba8"
foreground = "#cdd6f4"
background = "#1e1e2e"
surface    = "#313244"
dark       = true

[variables]
playback-bar-bg = "#181825"
active-tab      = "#cdd6f4"
inactive-tab    = "#6c7086"
selected-item   = "#45475a"
progress-filled = "#cba6f7"
progress-empty  = "#45475a"
lyrics-played   = "#6c7086"
lyrics-current  = "#a6e3a1"
lyrics-upcoming = "#cdd6f4"
```

## keymap.toml

Override any default keybinding in `~/.config/ytmx/keymap.toml`. See the in-app help (`?`) for the full list of available actions.
