# Keybindings

## Keyboard

| Key | Action |
|-----|--------|
| `space` | Play/Pause |
| `n` | Next track |
| `p` | Previous track |
| `+` / `-` | Volume up/down |
| `j` / `k` | Move down/up |
| `enter` | Select/play |
| `g l` | Go to Library |
| `g s` | Go to Search |
| `g b` | Go to Browse |
| `z` | Go to Queue |
| `g L` | Toggle lyrics sidebar |
| `Ctrl+e` | Toggle playlist sidebar |
| `g y` | Go to Liked Songs |
| `g r` | Go to Recently Played |
| `?` | Help (full keybinding reference) |
| `Alt+h` / `Alt+←` | Move focus to left panel (sidebar) |
| `Alt+l` / `Alt+→` | Move focus to right panel (main content) |
| `tab` / `shift+tab` | Cycle focus between widgets |
| `[` / `]` | Previous / next tab (Browse page) |
| `a` | Track actions menu |
| `/` | Filter current list |
| `Ctrl+r` | Cycle repeat mode |
| `Ctrl+s` | Toggle shuffle |
| `backspace` | Go back |
| `s t` / `s a` / `s A` / `s d` | Sort by Title / Artist / Album / Duration |
| `s r` | Reverse current sort |
| `T` | Toggle lyrics transliteration (ASCII) |
| `Ctrl+a` | Toggle album art |
| `Ctrl+p` | Open command palette (change theme, clear queue, …) |
| `Ctrl+x` | Clear queue |
| `q` | Quit |

## Mouse

| Action | Where | Effect |
|--------|-------|--------|
| Click | Progress bar | Seek to position |
| Scroll up/down | Progress bar | Scrub forward/backward (commits after 0.6s pause) |
| Scroll up/down | Volume display | Adjust volume by 5% |
| Click | Repeat button | Cycle repeat mode (off → all → one) |
| Click | Shuffle button | Toggle shuffle on/off |
| Click | Footer buttons | Navigate pages, play/pause, prev/next |
| Right-click | Track row | Open context menu (play, queue, add to playlist, etc.) |

## Custom keybindings

Edit `~/.config/ytmx/keymap.toml` to override any default binding. The full list of available actions is shown in the in-app help page (`?`).
