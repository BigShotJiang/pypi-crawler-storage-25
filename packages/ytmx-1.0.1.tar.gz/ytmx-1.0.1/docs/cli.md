# CLI reference

## Launch the TUI

```bash
ytmx
ytmx --debug   # verbose logging
```

## Headless commands

These work without the TUI running:

```bash
# Search YouTube Music
ytmx search "daft punk"
ytmx search "bohemian rhapsody" --filter songs --json

# Listening stats
ytmx stats
ytmx stats --json

# Play history
ytmx history
ytmx history search

# Cache management
ytmx cache status
ytmx cache clear

# Spotify import
ytmx import "https://open.spotify.com/playlist/..."

# Authentication
ytmx setup
ytmx setup --browser firefox
ytmx setup --manual

# Open config directory
ytmx config

# Diagnostics
ytmx doctor
```

## IPC control (requires TUI running)

Control the running TUI from another terminal:

```bash
ytmx play          # Resume playback
ytmx pause         # Pause playback
ytmx next          # Skip to next track
ytmx prev          # Previous track
ytmx seek +10      # Seek forward 10 seconds
ytmx seek -5       # Seek backward 5 seconds
ytmx seek 1:30     # Seek to 1:30

ytmx like          # Like current track
ytmx dislike       # Dislike current track
ytmx unlike        # Remove like/dislike

ytmx now           # Current track info (JSON)
ytmx status        # Player status (JSON)
ytmx queue         # Queue contents (JSON)
ytmx queue add ID  # Add track by video ID
ytmx queue clear   # Clear queue
```
