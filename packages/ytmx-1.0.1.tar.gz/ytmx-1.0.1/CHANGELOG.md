# Changelog

All notable changes to ytmx are documented here.

Format follows [Keep a Changelog](https://keepachangelog.com/).

---

### v1.0.1 (2026-04-19)

**Fixes**

- Update check now queries the correct PyPI package (`ytmx` instead of `ytm-player`)

---

### v1.0.0 (2026-04-19)

Initial release of ytmx — a hard fork of [ytm-player](https://github.com/peternaame-boop/ytm-player) with an independent direction.

**New features**

- User-defined themes via `~/.config/ytmx/themes/` — drop `.toml` files and they appear in the `Ctrl+P` picker
- Theme setting persisted to `config.toml` `[ui]` section instead of session state
- Default theme `ytm-dark` configured out of the box
- Privacy selector in the create playlist popup
- Description field in the create playlist popup
- Create/Cancel buttons in the create playlist popup
- ➕ button in the sidebar playlist panel header to create playlists directly
- Edit Playlist option in the sidebar context menu
- Refresh button and `r` keybinding to reload the playlist sidebar
- Library header enriched with description, privacy badge, year, and subtitle
- Clear queue action integrated into the command palette
- Panel navigation — `Alt+h`/`Alt+l` to move focus between sidebar and main content
- Browse improvements — single-click to play, better panel navigation

**Fixes**

- Right-click opens context menu in Queue, Liked Songs, and Browse pages
- Sidebar playlist count syncs when tracks are added via picker or new playlist created
- Navigate to library automatically when the active playlist is deleted
- `_BouncingLabel` uses actual rendered width to prevent text clipping
- `_theme_initialized` guard restored and correctly ordered in `__init__`
- Duplicate stale color refs in `progress_bar` removed after upstream merge

**Rebrand from ytm-player**

- Package renamed to `ytmx`, CLI command `ytm` → `ytmx`
- Config paths migrated to `~/.config/ytmx/`
- New README, documentation structure, assets folder
