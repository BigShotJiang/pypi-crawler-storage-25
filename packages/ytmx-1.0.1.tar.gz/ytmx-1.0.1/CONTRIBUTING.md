# Contributing to ytmx

Thanks for considering a contribution! This document covers what you need
to know to get a PR merged.

## Development setup

```bash
git clone https://github.com/Villoh/ytmx.git
cd ytmx
python -m venv .venv
source .venv/bin/activate
pip install -e ".[spotify,mpris,discord,lastfm,transliteration,dev]"
```

System dependency: `mpv` must be installed system-wide (`sudo pacman -S mpv` on Arch, `brew install mpv` on macOS).

## Pre-commit checklist

**MANDATORY before every commit — run BOTH in this order:**

```bash
ruff format src/ tests/
ruff check src/ tests/
```

`ruff check` alone is NOT enough. `ruff format` catches line-length and
style issues `ruff check` does not.

## Testing

```bash
pytest                                          # full suite
pytest --cov=ytmx --cov-report=term-missing    # with coverage
pytest tests/test_services/test_queue.py        # one file
pytest tests/test_services/test_queue.py::test_add_track -v  # one test
```

UI code (`src/ytmx/ui/*`) is excluded from coverage; services and
config are covered.

## Logging

Logs go to `~/.config/ytmx/logs/ytm.log`. **Never use `print()`**
in non-CLI code — Textual's alt-screen swallows stderr.

For caught exceptions you want to surface in bug reports, use
`logger.exception("descriptive message")` — *not* `logger.debug(...,
exc_info=True)`, which silently routes to debug.

## Track dict

All services use a standardised track dict: `video_id`, `title`, `artist`,
`artists` (list of `{name, id}` dicts), `album`, `album_id`, `duration`
(seconds, int or None), `thumbnail_url`, `is_video`. Use
`normalize_tracks()` from `utils/formatting.py` when ingesting raw
ytmusicapi data.

## RTL text

Any user-supplied text fragment concatenated into a line with other
fragments (table cells, playback bar widgets) MUST be wrapped with
`isolate_bidi()` from `utils/bidi.py` AFTER `truncate()`. Otherwise RTL
text bleeds across visual boundaries on some terminals. There's a
regression test (`TestIsolateBidiCallSites`) that fails CI if a render
site stops calling `isolate_bidi`.

## PR norms

- One concern per PR. Don't bundle "fix bug + add feature + refactor".
- Reference the issue in the PR description (`Closes #123`).
- Update `CHANGELOG.md` if your change is user-visible.
- The CI matrix runs Ubuntu + macOS + Windows on Python 3.12 and 3.13. Make sure all green before requesting review.

## Architecture pointers

- `app/` — main app split into mixins (lifecycle, playback, navigation, etc.)
- `services/` — backend singletons (Player, QueueManager, YTMusicService, etc.)
- `ui/` — Textual widgets (pages, sidebars, popups, widgets)
- `config/` — settings, keymap, theme, paths

For deeper context, read `CLAUDE.md` in the repo root — it's the
project's living architecture doc.
