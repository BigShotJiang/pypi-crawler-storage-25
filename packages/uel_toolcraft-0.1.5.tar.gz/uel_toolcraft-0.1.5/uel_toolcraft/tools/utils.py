"""
utils.py
工具函数模块
"""
import argparse


def build_base_parser(version: str = "default", description: str = "使用命令行参数") -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=description)

    parser.add_argument("--config", type=str, required=True, help="配置文件路径", dest="config")
    parser.add_argument("--version", action="version", version=f"%(prog)s {version}")

    return parser


def get_args(parser: argparse.ArgumentParser | None = None, version: str = "default", description: str = "使用命令行参数") -> argparse.Namespace:
    """
    解析命令行参数，返回解析后的参数对象。
    :param parser: ArgumentParser 对象，如果为 None，则使用 build_base_parser 构建一个基础的 ArgumentParser。
    :param version: str, 程序版本号。
    :param description: str, 程序描述。
    :return: 解析后的参数对象 (Namespace)
    """
    if parser is None:
        parser = build_base_parser(version=version, description=description)

    # 解析参数
    parser_args = parser.parse_args()

    return parser_args
