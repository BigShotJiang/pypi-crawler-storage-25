from supabase import create_client, Client
from typing import Optional, Tuple
import logging

# 获取日志记录器
logger: logging.Logger = logging.getLogger(__name__)


def create_supabase_client(supabase_api: str, supabase_key: str, user: Optional[str] = None, password: Optional[str] = None) -> Tuple[Client, Optional[str]]:
    """
    创建 supabase 客户端。
    如果提供 user 和 password，则返回登录后的 client 和 user_id；
    否则返回匿名 client 和 None。
    :param supabase_api: Supabase 项目的 URL。
    :param supabase_key: Supabase 项目的 API 密钥。
    :param user: 可选的用户名（电子邮件）。
    :param password: 可选的密码。
    :return: 返回一个元组，包含 Supabase Client 和 user_id（如果已登录）。
    """
    supabase_client: Client = create_client(supabase_api, supabase_key)

    if user and password:
        auth_response = supabase_client.auth.sign_in_with_password({"email": user, "password": password})
        if auth_response.user is None:
            logger.error("登录失败：请检查用户名或密码")
            raise Exception("登录失败：请检查用户名或密码")
        user_id = auth_response.user.id
        return supabase_client, user_id
    else:
        return supabase_client, None
