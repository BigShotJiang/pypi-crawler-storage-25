import re
import base64
from pathlib import Path


def read_txt_lines(txt_file_path: str | Path) -> str | list:
    """
    从 txt 中读取内容。
    :param txt_file_path: str, 文件的路径。
    :return contents str or list: 文件中的内容列表。
    """
    with open(txt_file_path, 'r', encoding='utf-8') as file:
        contents = file.readlines()

    return contents


def read_txt(txt_file_path: str | Path) -> str:
    """
    从 txt 中读取内容。
    :param txt_file_path: str, 文件的路径。
    :return contents str or list: 文件中的内容列表。
    """
    with open(txt_file_path, 'r', encoding='utf-8') as file:
        contents = file.read()

    return contents


def write_txt(contents: str | list, txt_file_path: str | Path):
    """
    写入内容到 txt 中。
    :param contents: str or list, 要写入的内容列表。
    :param txt_file_path: str, 文件的路径
    """
    with open(txt_file_path, 'w', encoding='utf-8') as file:
        file.writelines(contents)


def extract_links(text: str) -> list:
    """
    从给定的文本中提取链接，并跳过空行。
    :param text: str, 输入的文本字符串。
    :return links: list, 提取出的链接列表。
    """
    # 定义匹配链接的正则表达式
    url_pattern = r'http[s]?://[^\s，]+'

    # 初始化一个列表来存储链接
    links = []

    # 按行分割输入的文本
    lines = text.splitlines()

    # 遍历每一行
    for line in lines:
        if line.strip():  # 跳过空行
            # 查找并提取链接
            target_links__ = re.findall(url_pattern, line)
            links.extend(target_links__)
    # 将结果返回
    return links


def join_lines(input_contents: list, connection_str: str = ' ') -> str:
    """
    使用指定的连接符连接每行的内容
    将输入文件中的每一行用连接符（默认为空格）连接，返回连接完成的结果。
    :param input_contents: str, 输入内容。
    :param connection_str: str, 连接符，默认为空格。
    :return joined_contents: str, 输出连接后的内容。
    """
    # 去除每行的换行符并用连接符连接
    joined_contents = connection_str.join(input_content.strip() for input_content in input_contents)

    return joined_contents


def extract_join_links_from_base64(base64_string: str, connection_str: str = ' ') -> tuple[list, str]:
    """
    从 base64 编码的字符串中提取链接，并使用指定的连接符连接每行的内容。
    :param base64_string: str, base64 编码的字符串。
    :param connection_str: str, 连接符，默认为空格。
    :return (links_extracted, links_joined): tuple[list, str], 输出连接后的内容。
    """
    # 解码 base64 字符串
    decoded_string = base64.b64decode(base64_string).decode('utf-8')
    # 提取链接
    links_extracted = extract_links(decoded_string)
    # 使用指定的连接符连接每行的内容
    links_joined = join_lines(links_extracted, connection_str)
    
    return links_extracted, links_joined


def remove_ad_chars(text: str, ad_patterns: list = []) -> str:
    """
    移除文本中的广告字符。
    :param text: str, 输入的文本字符串。
    :param ad_patterns: list, 要移除的广告字符列表。
    :return cleaned_text: str, 清理后的文本字符串。
    """
    # 定义要移除的广告字符
    if not ad_patterns:
        # 如果没有提供自定义的广告字符，则使用默认的广告字符
        ad_patterns = []
        ad_patterns.append(r'（[^）]*@ZYjia[^）]*）')

    # 把输入文本字符串分行
    text_list = text.splitlines()

    # 使用正则表达式替换广告字符为空字符串
    for ad_pattern in ad_patterns:
        for i in range(len(text_list)):
            # 使用 re.sub 替换广告字符
            text_list[i] = re.sub(ad_pattern, '', text_list[i], flags=re.IGNORECASE)

    # 去除空行
    text_list = [line for line in text_list if line.strip()]

    # 使用换行符连接清理后的文本
    cleaned_text = '\n'.join(text_list)

    return cleaned_text


def escape_markdown_chars(text: str) -> str:
    """
    转义 Markdown 特殊字符
    :param text: str, 输入文本
    :return: str, 转义后的文本
    """
    # 定义需要转义的 Markdown 特殊字符
    # 注意: 未转义 中括号 [] 和圆括号 (), 避免影响链接格式
    markdown_special_chars = r'\_*~`>#+-=|{}.!'
    # 使用正则表达式进行转义
    escaped_text = re.sub(r'([{}])'.format(re.escape(markdown_special_chars)), r'\\\1', text)
    return escaped_text
