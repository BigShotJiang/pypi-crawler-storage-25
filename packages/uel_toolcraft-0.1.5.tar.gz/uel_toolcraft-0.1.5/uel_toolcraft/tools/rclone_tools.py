from rclone_python import rclone
from pathlib import Path
import logging

# 获取日志记录器
logger: logging.Logger = logging.getLogger(__name__)


def is_rclone_installed():
    """
    检查 rclone 是否已安装。
    :return: 如果 rclone 已安装，则返回 True，否则返回 False。
    """
    return rclone.is_installed()


def get_rclone_version():
    """
    检查 rclone 的版本。
    :return: rclone 的版本字符串。例如: "rclone v1.57.0"
    """
    return rclone.version()


def get_rclone_remotes():
    """
    获取 rclone 配置的远程存储列表。
    :return: 远程存储的名称列表。
    """
    return rclone.get_remotes()


def rclone_run(source, destination, mode, args: list | None = None, dry_run: bool = False, show_progress: bool = False):
    """
    使用 rclone 复制文件或目录。
    :param source: 源路径，可以是本地路径或远程存储路径。
    :param destination: 目标路径，可以是本地路径或远程存储路径。
    :param mode: 运行模式，例如 "copy", "copyto", "move", "moveto", "sync"。
    :param args: 可选的 rclone 标志，例如 "--progress" 或 "--dry-run"。
    :param dry_run: 是否进行干运行（不实际执行复制），默认为 False。
    :param show_progress: 是否显示进度条，默认为 False。
    :return: rclone 执行的结果。
    """
    if args is None:
        args = []

    # 是否干运行
    if dry_run:
        args.append('--dry-run')

    # 运行 rclone 命令
    try:
        if mode == 'copy':
            rclone.copy(source, destination, args=args, show_progress=show_progress)
            return True
        elif mode == 'copyto':
            rclone.copyto(source, destination, args=args, show_progress=show_progress)
            return True
        elif mode == 'move':
            rclone.move(source, destination, args=args, show_progress=show_progress)
            return True
        elif mode == 'moveto':
            rclone.moveto(source, destination, args=args, show_progress=show_progress)
            return True
        elif mode == 'sync':
            rclone.sync(source, destination, args=args, show_progress=show_progress)
            return True
        else:
            logger.warning(f"Unsupported mode: '{mode}'")
            return None
    except Exception as e:
        logger.error(f"Error running rclone '{mode}': \n{e}")
        return None


def rclone_backup_db_file(db_file_local: str | Path, db_file_remote: str, args: list | None = None, dry_run: bool = False):
    """
    使用 rclone 备份数据库文件到远程存储。
    :param db_file_local: 本地数据库文件路径。
    :param db_file_remote: 远程数据库备份路径。
    :param args: 可选的 rclone 标志，例如 "--progress" 或 "--dry-run"。
    :param dry_run: 是否进行干运行（不实际执行复制），默认为 False。
    :return: rclone 执行的结果。
    """
    # 执行 rclone copyto 命令
    rclone_result = rclone_run(db_file_local, db_file_remote, mode="copyto", args=args, dry_run=dry_run, show_progress=False)
    if rclone_result:
        logger.info(f"已使用 rclone 备份数据库文件到 '{db_file_remote}'")
    else:
        logger.warning(f"rclone 备份数据库文件失败: {rclone_result}")
