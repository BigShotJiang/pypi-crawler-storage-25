import json5
import logging

# 获取日志记录器
logger: logging.Logger = logging.getLogger(__name__)


def read_config_file(config_file) -> dict:
    """
    读取 config JSON 文件
    :param config_file: 配置文件路径
    :return: 返回读取的配置数据，格式为字典
    """
    try:
        with open(config_file, 'r', encoding='utf-8') as f:
            data = json5.load(f)
        return data
    except Exception as e:
        logger.error(f"读取 JSON 文件时出错: {e}")
        return {}
