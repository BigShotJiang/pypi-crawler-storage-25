import requests
import logging

# 获取日志记录器
logger: logging.Logger = logging.getLogger(__name__)


def send_tg_msg(chat_id_tg, bot_token_tg, msg):
    # send message via telegram
    send_tg_msg_api = "https://api.telegram.org/bot{}/sendMessage"
    try:
        response = requests.get(
            send_tg_msg_api.format(bot_token_tg),
            params={"chat_id": chat_id_tg, "text": msg},
        )
        response.raise_for_status()  # check request success or not
        logger.info("Succeed to send message ^_^")
    except requests.exceptions.RequestException as e:
        logger.error(f"Failed to send message: {str(e)}")
