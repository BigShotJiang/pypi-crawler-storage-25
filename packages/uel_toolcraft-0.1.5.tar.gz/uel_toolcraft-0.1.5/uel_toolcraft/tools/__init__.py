from .config_tools import read_config_file
from .filesystem_tools import (
    ensure_path,
    get_subfolders,
    shutil_move,
    shutil_move_from_list,
    supported_media_extensions,
    check_file_type,
    scan_media_files,
    scan_txt_files,
    scan_json_files,
    convert_bytes_to_human_readable,
    convert_to_bytes,
    md5sum,
    expand_file,
    restore_file,
)
from .json_tools import format_json, read_json_file, write_json_file
from .pickle_tools import read_pickle_file, write_pickle_file
from .txt_tools import (
    read_txt_lines,
    read_txt,
    write_txt,
    extract_links,
    join_lines,
    extract_join_links_from_base64,
    remove_ad_chars,
    escape_markdown_chars,
)
from .time_tools import (
    convert_timestamp_to_readable,
    get_current_timestamp,
    get_current_timestamp_ms,
    current_datetime_str,
    check_date_format,
    format_datetime,
    get_datetime_obj_from_str,
    get_input_date,
    get_date_time_range_timestamp,
    move_date,
    get_ntp_time,
    set_system_time,
)
from .utils import build_base_parser, get_args
try:
    from .notification import send_tg_msg
except ImportError:
    send_tg_msg = None

# Optional: ffmpeg
try:
    from .ffmpeg_tools import (
        check_ffmpeg_encoder_available,
        get_codecs,
        check_faststart,
        check_faststart_ffmpeg,
        fix_faststart_ffmpeg,
        get_video_width_height_duration,
        convert_video_to_mp4,
        thumbnail_time_from_duration,
        extract_thumbnail_ffmpeg,
    )
except ImportError:
    check_ffmpeg_encoder_available = (
        get_codecs
    ) = check_faststart = check_faststart_ffmpeg = fix_faststart_ffmpeg = (
        get_video_width_height_duration
    ) = convert_video_to_mp4 = thumbnail_time_from_duration = (
        extract_thumbnail_ffmpeg
    ) = None

# Optional: git
try:
    from .git_worktree_tools import (
        create_worktree_temp_dir,
        create_worktree,
        delete_worktree,
        clean_repo_folder,
        reinit_commit,
        get_file_at_branch,
        copy_files_to_branch,
    )
except ImportError:
    create_worktree_temp_dir = create_worktree = delete_worktree = clean_repo_folder = (
        reinit_commit
    ) = get_file_at_branch = copy_files_to_branch = None

# Optional: github
try:
    from .github_tools import (
        subprocess_run,
        append_repo_to_list,
        check_wiki_page,
        check_has_wiki,
        get_repo_info,
        get_repo_sub_info,
        create_repo,
        change_repo_action_permission,
        compare_commit,
        sync_repo_subprocess,
        update_repo_default_branch,
        create_release,
        delete_old_releases,
        safe_shutil_rm_tree,
        git_clone_repo,
        safe_git_clone,
        git_clone_repo_wiki,
        structure_repo_files,
        git_push_repo,
    )
except ImportError:
    subprocess_run = append_repo_to_list = check_wiki_page = check_has_wiki = (
        get_repo_info
    ) = get_repo_sub_info = create_repo = change_repo_action_permission = compare_commit = (
        sync_repo_subprocess
    ) = update_repo_default_branch = create_release = delete_old_releases = (
        safe_shutil_rm_tree
    ) = git_clone_repo = safe_git_clone = git_clone_repo_wiki = structure_repo_files = (
        git_push_repo
    ) = None

# Optional: photo
try:
    from .photo_tools import (
        compress_photo_if_oversize,
        resize_photo,
    )
except ImportError:
    compress_photo_if_oversize = resize_photo = None

# Optional: rclone
try:
    from .rclone_tools import (
        is_rclone_installed,
        get_rclone_version,
        get_rclone_remotes,
        rclone_run,
        rclone_backup_db_file,
    )
except ImportError:
    is_rclone_installed = get_rclone_version = get_rclone_remotes = rclone_run = (
        rclone_backup_db_file
    ) = None

# Optional: supabase
try:
    from .supabase_tools import create_supabase_client
except ImportError:
    create_supabase_client = None

# Optional: PyQt6
try:
    from .ui_tools import select_path
except ImportError:
    select_path = None

# stdlib only
from .async_tools import run_async_task

# Optional: h5py, numpy
try:
    from .numpy_tools import pad_and_stack
except ImportError:
    pad_and_stack = None

# Optional: pyserial
try:
    from .serial_tools import list_serial_ports, filter_ports_by_hwid
except ImportError:
    list_serial_ports = filter_ports_by_hwid = None

__all__ = [
    "read_config_file",
    "ensure_path",
    "get_subfolders",
    "shutil_move",
    "shutil_move_from_list",
    "supported_media_extensions",
    "check_file_type",
    "scan_media_files",
    "scan_txt_files",
    "scan_json_files",
    "convert_bytes_to_human_readable",
    "convert_to_bytes",
    "md5sum",
    "expand_file",
    "restore_file",
    "format_json",
    "read_json_file",
    "write_json_file",
    "read_pickle_file",
    "write_pickle_file",
    "read_txt_lines",
    "read_txt",
    "write_txt",
    "extract_links",
    "join_lines",
    "extract_join_links_from_base64",
    "remove_ad_chars",
    "escape_markdown_chars",
    "convert_timestamp_to_readable",
    "get_current_timestamp",
    "get_current_timestamp_ms",
    "current_datetime_str",
    "check_date_format",
    "format_datetime",
    "get_datetime_obj_from_str",
    "get_input_date",
    "get_date_time_range_timestamp",
    "move_date",
    "get_ntp_time",
    "set_system_time",
    "build_base_parser",
    "get_args",
    "send_tg_msg",
    "check_ffmpeg_encoder_available",
    "get_codecs",
    "check_faststart",
    "check_faststart_ffmpeg",
    "fix_faststart_ffmpeg",
    "get_video_width_height_duration",
    "convert_video_to_mp4",
    "thumbnail_time_from_duration",
    "extract_thumbnail_ffmpeg",
    "create_worktree_temp_dir",
    "create_worktree",
    "delete_worktree",
    "clean_repo_folder",
    "reinit_commit",
    "get_file_at_branch",
    "copy_files_to_branch",
    "is_rclone_installed",
    "get_rclone_version",
    "get_rclone_remotes",
    "rclone_run",
    "rclone_backup_db_file",
    "create_supabase_client",
    "select_path",
    "run_async_task",
    "pad_and_stack",
    "list_serial_ports",
    "filter_ports_by_hwid",
    "compress_photo_if_oversize",
    "resize_photo",
    "subprocess_run",
    "append_repo_to_list",
    "check_wiki_page",
    "check_has_wiki",
    "get_repo_info",
    "get_repo_sub_info",
    "create_repo",
    "change_repo_action_permission",
    "compare_commit",
    "sync_repo_subprocess",
    "update_repo_default_branch",
    "create_release",
    "delete_old_releases",
    "safe_shutil_rm_tree",
    "git_clone_repo",
    "safe_git_clone",
    "git_clone_repo_wiki",
    "structure_repo_files",
    "git_push_repo",
]
