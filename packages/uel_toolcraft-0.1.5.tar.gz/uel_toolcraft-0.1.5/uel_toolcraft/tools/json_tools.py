import json
import logging
from pathlib import Path

# 获取日志记录器
logger: logging.Logger = logging.getLogger(__name__)


def format_json(data: dict | list | str, indent: int | None = 4, separator=(',', ':'), **kwargs):
    """
    格式化JSON数据，支持自定义缩进和分隔符
    :param data: 需要格式化的数据（字典或列表）
    :param indent: 缩进空格数，默认为 4
    :param separator: 分隔符，默认为 (',', ':')
    :param kwargs: 传递给json.dumps的可选参数
    :return: 格式化后的JSON字符串
    """
    # 设置默认参数
    default_args = {
        'indent': indent,
        'separators': separator,
        'ensure_ascii': False
    }
    # 合并用户参数（用户参数覆盖默认参数）
    merged_args = {**default_args, **kwargs}
    # 格式化 JSON 数据
    data_formated = json.dumps(data, **merged_args)  # 默认使用 4 个空格缩进
    return data_formated


def read_json_file(json_file: str | Path):
    """
    读取指定路径的 JSON 文件并返回其内容
    :param json_file: JSON 文件路径
    :return: 解析后的 JSON 数据（字典或列表），读取失败时返回 None
    """
    try:
        with open(json_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        logger.debug(f"已读取 JSON 文件：{json_file}")
        return data
    except Exception as e:
        logger.error(f"读取 JSON 文件时出错: {e}")
        return None


def write_json_file(data: dict | list | str, json_file: str | Path, indent: int | None = None):
    """
    写入 JSON 文件
    :param data: 需要写入的数据（字典或列表）
    :param json_file: 目标 JSON 文件路径
    :param indent: 缩进空格数，默认为 None（不缩进）
    :return: None
    """
    try:
        with open(json_file, 'w', encoding='utf-8') as f:
            data_formated = format_json(data, indent)
            f.write(data_formated)
        logger.debug(f"数据已写入：{json_file}")
    except Exception as e:
        logger.error(f"写入 JSON 文件时出错: {e}")


if __name__ == "__main__":
    input_json = "chat_chatID_date.json"  # 输入文件
    output_json = "chat_chatID_date_formated.json"  # 输出文件
    json_data = read_json_file(input_json)  # 读取 JSON 文件
    json_data = format_json(json_data, indent=4)  # 格式化 JSON 数据
    write_json_file(json_data, output_json, indent=None)  # 写入 JSON 文件（包含了格式化 JSON 功能）
