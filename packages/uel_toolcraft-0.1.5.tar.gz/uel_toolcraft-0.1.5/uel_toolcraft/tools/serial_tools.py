import logging
from serial.tools import list_ports

# 获取日志记录器
logger: logging.Logger = logging.getLogger(__name__)


def list_serial_ports() -> list:
    """
    列出所有可用的串口
    """
    # 获取所有可用的端口
    ports = list_ports.comports()
    return ports


def filter_ports_by_hwid(ports: list, hwid_substring: str) -> list:
    """
    根据硬件ID子字符串过滤端口
    :param ports: 串口列表
    :param hwid_substring: 硬件ID子字符串
    :return: 过滤后的串口列表
    """
    filtered_ports = [port for port in ports if hwid_substring in port.hwid]
    return filtered_ports


if __name__ == "__main__":
    com_ports = list_serial_ports()
    # 打印端口信息
    for com_port in com_ports:
        print(f"设备: {com_port.device}, 描述: {com_port.description}, 硬件ID: {com_port.hwid}")
        target_ports = filter_ports_by_hwid(com_ports, com_port.hwid)
        print(f"匹配到的端口: {[port.device for port in target_ports]}\n\n{'-'*40}\n")
