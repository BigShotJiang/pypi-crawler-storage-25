import calendar
import logging
import time
from datetime import datetime, timedelta, timezone

# 获取日志记录器
logger: logging.Logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# 基础时间戳 / 格式化
# ═══════════════════════════════════════════════════════════════

def convert_timestamp_to_readable(timestamp: int) -> str:
    """
    将时间戳转换为 ISO 8601 格式的可读字符串。
    """
    return datetime.fromtimestamp(timestamp).isoformat()


def get_current_timestamp() -> int:
    """
    获取当前时间的时间戳
    :return: int, 当前时间的时间戳
    """
    current_datetime = datetime.now()  # 获取当前日期
    current_timestamp = int(current_datetime.timestamp())
    return current_timestamp


def get_current_timestamp_ms() -> int:
    """
    获取当前时间的时间戳，单位为毫秒
    :return: int, 当前时间的时间戳（毫秒）
    """
    current_timestamp_ms = int(time.time_ns() // 1_000_000)
    return current_timestamp_ms


def current_datetime_str(datetime_format: str = "%Y-%m-%d %H:%M:%S") -> str:
    """
    获取当前日期时间的字符串表示，格式可自定义。
    :param datetime_format: 日期时间格式，默认为 "%Y-%m-%d %H:%M:%S"
    :return: 当前日期时间的字符串表示
    """
    if not datetime_format:
        datetime_format = "%Y-%m-%d %H:%M:%S"
    return datetime.now().strftime(datetime_format)


# ═══════════════════════════════════════════════════════════════
# 日期解析 / 校验 / 格式化
# ═══════════════════════════════════════════════════════════════

def check_date_format(date_str: str, date_format: str = "%Y-%m-%d") -> bool:
    """
    检查日期字符串是否符合指定的格式。
    :param date_str: 日期字符串
    :param date_format: 日期格式，默认为 "%Y-%m-%d"
    :return: bool, 如果符合格式则返回 True，否则返回 False
    """
    try:
        datetime.strptime(date_str, date_format).date()
        return True
    except ValueError:
        return False


def format_datetime(date_obj: datetime, date_format: str = "%Y-%m-%d") -> str:
    """
    将 datetime 对象格式化为指定的字符串格式。
    :param date_obj: datetime 对象
    :param date_format: 日期格式，默认为 "%Y-%m-%d"
    :return: 格式化后的日期字符串
    """
    return date_obj.strftime(date_format)


def get_datetime_obj_from_str(date_str: str, date_format: str = "%Y-%m-%d") -> datetime:
    """
    将日期字符串转换为 datetime 对象。
    :param date_str: 日期字符串
    :param date_format: 日期格式，默认为 "%Y-%m-%d"
    :return: datetime 对象
    """
    if not check_date_format(date_str, date_format):
        raise ValueError(f"日期字符串 '{date_str}' 格式不正确，应为 '{date_format}'")
    return datetime.strptime(date_str, date_format)


def get_input_date(prompt: str = "请输入日期 (格式 YYYY-MM-DD)，默认是昨天: ") -> str:
    """
    获取用户输入的日期，如果输入为空，则默认为昨天的日期。
    :param prompt: 提示用户输入的字符串
    :return: 字符串格式的日期 'YYYY-MM-DD'
    """
    date_str_format = "%Y-%m-%d"
    date_str_input = input(prompt).strip()  # 获取用户输入的日期字符串, 并去除首尾空格
    if date_str_input:
        try:
            date_obj = datetime.strptime(date_str_input, date_str_format).date()
            date_str = date_obj.strftime(date_str_format)
            return date_str
        except ValueError:
            raise ValueError("输入的日期格式不正确，应为 YYYY-MM-DD")
    else:
        # 如果用户没有输入日期，则默认为昨天的日期
        date_str = (datetime.today() - timedelta(days=1)).date().strftime(date_str_format)
        logger.info(f"没有输入日期，使用默认值：'{date_str}'")
        return date_str


def get_date_time_range_timestamp(date_begin_str: str, date_end_str: str) -> tuple[int, int]:
    """
    获取某一天的时间范围的时间戳
    :param date_begin_str: 日期字符串，格式 'YYYY-MM-DD'
    :param date_end_str:   日期字符串，格式 'YYYY-MM-DD'
    :return: 返回从开始日期00:00:00到结束日期23:59:59的时间戳，格式为 (start_timestamp, end_timestamp)
    """
    # 获取当天的起始时间（00:00:00）
    start_time_str = date_begin_str + ' 00:00:00'
    start_time = datetime.strptime(start_time_str, '%Y-%m-%d %H:%M:%S')
    start_timestamp = int(start_time.timestamp())

    # 获取当天的结束时间（23:59:59）
    end_time_str = date_end_str + ' 23:59:59'
    end_time = datetime.strptime(end_time_str, '%Y-%m-%d %H:%M:%S')
    end_timestamp = int(end_time.timestamp())

    return start_timestamp, end_timestamp


# ═══════════════════════════════════════════════════════════════
# 日期移动
# ═══════════════════════════════════════════════════════════════

def move_date(
    start_date: datetime,
    direction: str = "forward",
    target_digits: tuple = (1, 6),
    near_end_threshold: int = 3,
) -> tuple[datetime | None, int | None]:
    """
    从指定日期往前/后移动，直到日期的"天"的个位数属于 target_digits。

    参数：
    :param start_date: datetime, 起始日期
    :param direction: str, 移动方向，"forward" 表示往前 (过去的时间) 移动，"backward" 表示往后 (未来的时间) 移动
    :param target_digits: tuple, 希望匹配的"天"的个位数，例如 (1, 6)
    :param near_end_threshold: int, 如果距离月底不足该阈值天数，返回月底日期

    返回：
    :return: tuple:
            matched_date (datetime): 匹配的日期
            days_moved (int): 移动的天数
    """
    year, month, day = start_date.year, start_date.month, start_date.day
    # 该月的总天数
    days_in_month = calendar.monthrange(year, month)[1]

    if direction == "forward":
        current_date = start_date
        for _ in range(days_in_month):
            current_date -= timedelta(days=1)
            if current_date.day % 10 in target_digits:
                days_delta = start_date - current_date  # 计算实际移动的天数
                days_moved = days_delta.days  # 更新 days_moved
                return current_date, days_moved

        # 如果没有找到匹配的日期，返回本月第一天
        target_date = datetime(year, month, 1)
        days_delta = target_date - current_date  # 计算实际移动的天数
        days_moved = days_delta.days  # 更新 days_moved
        return target_date, days_moved

    elif direction == "backward":
        # 如果距离月底不足阈值天数，直接返回月底
        if (days_in_month - day) < near_end_threshold:
            target_date = datetime(year, month, days_in_month)
            days_delta = target_date - start_date  # 计算实际移动的天数
            days_moved = days_delta.days  # 更新 days_moved
            return target_date, days_moved

        # 向后找最近个位匹配的日期
        for d in range(day, days_in_month + 1):
            if d % 10 in target_digits:
                if (days_in_month - d) < near_end_threshold:
                    target_date = datetime(year, month, days_in_month)
                else:
                    target_date = datetime(year, month, d)
                days_delta = target_date - start_date  # 计算实际移动的天数
                days_moved = days_delta.days  # 更新 days_moved
                return target_date, days_moved

        # 没找到则使用月底
        target_date = datetime(year, month, days_in_month)
        days_delta = target_date - start_date  # 计算实际移动的天数
        days_moved = days_delta.days  # 更新 days_moved
        return target_date, days_moved
    else:
        return None, None


# ═══════════════════════════════════════════════════════════════
# NTP 网络时间 (需要 ntplib)
# ═══════════════════════════════════════════════════════════════

def get_ntp_time(server: str = "pool.ntp.org") -> float | None:
    """
    通过 NTP 获取时间，并计算网络延迟与时钟偏移补偿

    :param server: NTP 服务器地址，默认为 "pool.ntp.org"
    :return: 补偿后的精确时间戳，失败返回 None
    """
    try:
        import ntplib
    except ImportError:
        logger.error("❌ 无法导入 ntplib 模块，请安装: pip install uel-toolcraft[ntp]")
        return None

    client = ntplib.NTPClient()
    try:
        # 发送 NTP 请求 (version=3)
        response = client.request(server, version=3)

        # 打印底层计算出的网络补偿数据
        logger.info(f"📊 网络往返延迟: {response.delay * 1000:.2f} ms")
        logger.info(f"📊 本地时钟偏移: {response.offset * 1000:.2f} ms")

        # 核心逻辑：当前系统最准确的时间 = 获取响应这一刻的本地时间 + 计算出的偏差值
        # 注意：这里必须使用 time.time() 获取当下这一微秒的最新时间，再加偏移量
        true_now_timestamp = time.time() + response.offset

        return true_now_timestamp
    except Exception as e:
        logger.error(f"❌ 获取网络时间失败: {e}")
        return None


# ═══════════════════════════════════════════════════════════════
# 系统时间设置 (需管理员权限)
# ═══════════════════════════════════════════════════════════════

def _set_linux_time(timestamp_float: float) -> bool:
    """
    调用 Linux 底层 API (clock_settime) 实现毫秒/纳秒级无延迟写入
    注意：需要 root 权限才能成功修改系统时间。

    :param timestamp_float: 以秒为单位的时间戳，可以包含小数部分表示毫秒
    :return: 成功返回 True
    """
    import ctypes

    # 定义 C 语言的 timespec 结构体
    class timespec(ctypes.Structure):
        _fields_ = [
            ("tv_sec", ctypes.c_long),   # 秒
            ("tv_nsec", ctypes.c_long)   # 纳秒 (1毫秒 = 1,000,000 纳秒)
        ]

    # 加载 C 标准库 (在绝大多数 Linux 发行版中都是 libc.so.6)
    try:
        libc = ctypes.CDLL("libc.so.6")
    except OSError:
        logger.error("❌ 找不到 libc.so.6，可能不是标准的 Linux 环境。")
        return False

    # CLOCK_REALTIME 的常量值为 0 (系统范围内的实时时钟)
    CLOCK_REALTIME = 0

    # 拆分秒和纳秒
    sec = int(timestamp_float)
    nsec = int((timestamp_float - sec) * 1_000_000_000)

    ts = timespec()
    ts.tv_sec = sec
    ts.tv_nsec = nsec

    # 调用 clock_settime 写入内核
    # 成功返回 0，失败返回 -1
    result = libc.clock_settime(CLOCK_REALTIME, ctypes.byref(ts))

    if result == 0:
        logger.info(f"✅ 系统时间已精确更新为时间戳: {sec}.{nsec:03d}")
        # 同步到硬件时钟 (可选，取决于是否需要重启后保留)
        import subprocess
        subprocess.run(['hwclock', '-w'], stdout=subprocess.DEVNULL)
        return True
    else:
        logger.error("❌ 时间修改失败！请确保你使用了 sudo 运行此脚本。")
        return False


def _set_windows_time(dt_local: datetime) -> bool:
    """
    Windows: 通过 SetLocalTime API 修改系统时间。需要管理员。
    
    :param dt_local: 本地时间的 datetime 对象
    :return: 成功返回 True，失败返回 False
    """
    import ctypes

    # Windows 的 SetLocalTime 接口需要的结构体参数：
    # 年, 月, 星期(0=周日), 日, 时, 分, 秒, 毫秒
    day_of_week = dt_local.isoweekday() % 7
    SYSTEMTIME = ctypes.c_ushort * 8
    sys_time = SYSTEMTIME(
        dt_local.year,
        dt_local.month,
        day_of_week,
        dt_local.day,
        dt_local.hour,
        dt_local.minute,
        dt_local.second,
        dt_local.microsecond // 1000
    )

    # 调用 Windows API 修改本地时间
    result = ctypes.windll.kernel32.SetLocalTime(sys_time)
    if result:
        logger.info("✅ Windows 系统时间同步成功！")
        return True
    else:
        logger.error("❌ 同步失败：权限不足。请右键以【管理员身份】运行命令提示符或Python。")
        return False


def set_system_time(timestamp_ms: int) -> None:
    """
    根据服务器毫秒时间戳设置系统时间。支持 Windows / Linux，需要管理员权限。
    :param timestamp_ms: 毫秒时间戳
    """
    import platform

    tz_local = datetime.now().astimezone().tzinfo
    dt = datetime.fromtimestamp(timestamp_ms / 1000.0, tz=timezone.utc)
    dt_local = dt.astimezone(tz_local)

    system = platform.system()
    if system == "Windows":
        _set_windows_time(dt_local)
    elif system == "Linux":
        _set_linux_time(timestamp_ms / 1000.0)
    else:
        raise OSError(f"Unsupported platform: {system}")

    logger.info(f"System time set to: {dt_local.isoformat()}")
