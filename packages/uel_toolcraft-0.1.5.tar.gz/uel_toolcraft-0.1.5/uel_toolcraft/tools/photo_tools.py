import logging
from PIL import Image
from pathlib import Path

# 获取日志记录器
logger: logging.Logger = logging.getLogger(__name__)


def compress_photo_if_oversize(photo_path, output_dir, target_size=10 * 1024 * 1024, target_dimension=10000):
    """
    压缩图片文件，如果图片大小超过指定的目标大小或图片尺寸超过指定的目标尺寸，则进行压缩。
    :param photo_path:  str or Path, 图片文件路径
    :param output_dir:  str or Path, 压缩后的图片保存目录
    :param target_size:  int, 目标文件大小，单位为字节，默认值为 10 MB
    :param target_dimension:  int, 目标图片 长+宽 尺寸，单位为像素，默认值为 10000 像素
    :return:
    """
    photo_path = Path(photo_path)
    photo_size = photo_path.stat().st_size
    is_compressed = False
    compress_ratio_factor = 0.9
    # 打开图片
    with Image.open(photo_path) as img:
        width = img.width
        height = img.height
        photo_dimension = width + height

        if (photo_size > (target_size - 1)) or (photo_dimension > target_dimension):
            # 计算压缩比例
            compression_ratio = min((target_size / photo_size * compress_ratio_factor), 1)

            # 计算压缩后的图片尺寸
            resized_width = int(width * compression_ratio)
            resized_height = int(height * compression_ratio)
            resized_dimension = resized_width + resized_height
            # 如果压缩后的图片尺寸仍然大于目标尺寸，则进一步压缩
            if resized_dimension > target_dimension:
                compression_ratio = min((target_dimension / resized_dimension * compress_ratio_factor), 1)
                resized_width = int(width * compression_ratio)
                resized_height = int(height * compression_ratio)

            # 压缩图片 (保持宽高比, 降低图像大小)
            img = img.resize((resized_width, resized_height))

            # 创建输出目录
            photo_name = photo_path.name
            output_dir = Path(output_dir)
            # 确保输出目录存在
            output_dir.mkdir(parents=True, exist_ok=True)
            compressed_photo_path = output_dir / photo_name
            # 保存压缩后的图片
            img.save(compressed_photo_path, quality=90, optimize=True)
            compressed_photo_size = compressed_photo_path.stat().st_size
            logger.info(f"图片已压缩到 {compressed_photo_size / (1024 * 1024):3.1f} MB")
            logger.info(f"压缩后的图片路径: \"{compressed_photo_path}\"")
            is_compressed = True
            return compressed_photo_path, is_compressed
        else:
            # logger.info("图片大小在限制范围内，无需压缩")
            return photo_path, is_compressed


def resize_photo(photo_path: Path | str, output_path: Path | str, max_size: int = 320):
    """
    调整图片大小，使其最长边不超过指定的最大尺寸，同时保持宽高比。
    :param photo_path: Path or str, 图片文件路径
    :param output_path: Path or str, 调整大小后图片的保存路径
    :param max_size: int, 最大尺寸（宽或高），单位为像素，默认值为 320 像素
    :return: None
    """
    photo_path = Path(photo_path)
    output_path = Path(output_path)
    # 打开图片
    with Image.open(photo_path) as img:
        width = img.width
        height = img.height

        # 计算新的尺寸，保持宽高比
        if width > height:
            if width > max_size:
                new_width = max_size
                new_height = int((max_size / width) * height)
            else:
                new_width, new_height = width, height
        else:
            if height > max_size:
                new_height = max_size
                new_width = int((max_size / height) * width)
            else:
                new_width, new_height = width, height

        # 调整图片大小
        img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)  # 使用 LANCZOS 滤镜进行高质量缩放

        # 创建输出目录
        output_dir = output_path.parent
        output_dir.mkdir(parents=True, exist_ok=True)

        # 保存调整大小后的图片
        img.save(output_path, quality=90, optimize=True, dpi=(300, 300))
        logger.debug(f"调整大小后的图片已保存到: {output_path}")
