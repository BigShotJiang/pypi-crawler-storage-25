import asyncio
import logging

# 获取日志记录器
logger: logging.Logger = logging.getLogger(__name__)


def run_async_task(coro):
    """
    在同步函数中安全运行异步任务
    """
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop and loop.is_running():
        # 如果事件循环已在运行（例如 Jupyter / asyncio 内部）
        logger.debug("事件循环已在运行, 使用 ensure_future 调度任务")
        return asyncio.ensure_future(coro)
    else:
        # 如果没有事件循环，就新建一个3
        logger.debug("事件循环未运行, 使用 asyncio.run 运行任务")
        return asyncio.run(coro)
