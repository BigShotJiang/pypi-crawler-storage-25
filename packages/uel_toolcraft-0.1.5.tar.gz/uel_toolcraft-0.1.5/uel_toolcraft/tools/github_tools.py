import os
import git
import json
import shutil
import logging
import requests
import subprocess
from datetime import datetime

# GitHub API endpoint for getting the commits of a repository for a specific branch
api_latest_commit = "https://api.github.com/repos/{}/commits/{}"
# GitHub API endpoint for getting the information of a repository
api_repo_info = "https://api.github.com/repos/{}"
# GitHub API endpoint for getting the releases of the tag
api_release = "https://api.github.com/repos/{}/{}/releases"
api_release_id = "https://api.github.com/repos/{}/{}/releases/{}"

# 获取日志记录器
logger: logging.Logger = logging.getLogger(__name__)


def subprocess_run(cmd, suc_out=""):
    """
    使用 subprocess 运行 shell 命令，并捕获输出。
    如果命令成功执行，打印成功输出；否则打印错误信息。
    :param cmd: 要执行的 shell 命令
    :param suc_out: 成功时的输出信息
    :return: subprocess.CompletedProcess 对象，包含命令的执行结果
    """
    # subprocess run shell commands in python
    result = subprocess.run(cmd, shell=True, capture_output=True, encoding='utf-8')
    if result.returncode == 0:
        logger.info(suc_out or result.stdout)
    else:
        logger.info(f"Error: {result.stderr}")
    return result


def append_repo_to_list(repo: str, repo_list: list, repo_type: str = "", attention_type: str = ""):
    """
    根据 repo_type 将 repo 添加到相应的列表中。
    :param repo: 包含 owner 的仓库全名, "owner/repo"
    :param repo_list: list, 需要添加到的列表
    :param repo_type: "update" / "conflict" / "attention"
    :param attention_type: "NOT_FOUND" / "WIKI" / "INITIATED", 仅当 repo_type 为 "attention" 时有效
    :return: 更新后的 repo_list
    """
    str1 = repo
    str1_splits = str1.split("/")
    # # append repo type  # update, attention, conflict
    # str1_splits.append(repo_type)
    if repo_type == 'attention':
        str1_splits.append(attention_type)
    repo_list.append(str1_splits)

    if repo_type == 'update':
        logger.info(f"Repo UPDATE: {str1} has been appended to {repo_type} list")
    elif repo_type == 'attention':
        logger.warning(f"Repo ATTENTION \"{attention_type}\": {str1} has been appended to {repo_type} list")
    elif repo_type == 'conflict':
        logger.warning(f"Repo CONFLICT: {str1} has been appended to {repo_type} list")
    else:
        logger.error("Please input correct repo type: \"update\" / \"conflict\" / \"attention\"")
    return repo_list


def check_wiki_page(repo: str) -> bool:
    """
    检查仓库是否有 wiki 页面, 如果有则添加到 wiki_repo_list 列表中
    :param repo: 包含 owner 的仓库全名, "owner/repo"
    :return: bool, 如果有 wiki 页面则返回 True，否则返回 False
    """
    # Check WiKi
    wiki_url = "https://github.com/{}/wiki"
    wiki_response = requests.head(wiki_url.format(repo))
    if wiki_response.status_code == 200:
        logger.info(f"[WIKI]: {repo} has wiki.")
        return True
    else:
        logger.info(f"[WIKI: {wiki_response.status_code}]: {repo} do not have wiki.")
        return False


def check_has_wiki(repo: str, repo_info: dict) -> bool:
    """
    根据仓库信息中的 has_wiki 字段检查仓库是否启用 wiki，并进一步检查是否有 wiki 页面
    :param repo: 包含 owner 的仓库全名, "owner/repo"
    :param repo_info: dict, 仓库信息的 JSON 对象
    :return: bool, 如果启用且有 wiki 页面则返回 True，否则返回 False
    """
    if repo_info["has_wiki"]:
        has_wiki = check_wiki_page(repo)
    else:
        has_wiki = False
        logger.info(f"[WIKI: has_wiki: false]: {repo} does not have wiki.")
    return has_wiki


def get_repo_info(repo: str, headers: dict | None) -> tuple[dict, bool]:
    """
    获取仓库信息，并根据是否启用 wiki 检查 wiki 页面
    :param repo: 包含 owner 的仓库全名, "owner/repo"
    :param headers: dict, 请求头
    :return: 仓库信息的 JSON 对象，如果请求失败则返回空字典
    """
    # Get repo info
    repo_info = requests.get(api_repo_info.format(repo), headers=headers)
    if repo_info.status_code == 200:
        repo_info_json = repo_info.json()
        repo_founded = True
        return repo_info_json, repo_founded
    else:
        logger.error(f"ERROR [{repo_info.status_code}]: No access to / NOT Found / Moved permanently the repo {repo}")
        repo_founded = False
        return {}, repo_founded


def get_repo_sub_info(repo_info_dict: dict | None, key: str) -> str:
    """
    获取仓库的子信息，如默认分支、描述或主页。
    目前支持的 sub_info_keywords 有: "branch", "description", "homepage"
    :param repo_info_dict: dict, 仓库信息的 JSON 对象
    :param key: str, 子信息关键词
    :return: 子信息内容，如果输入无效则返回 None
    """
    # Check if the repo_info_dict is None
    if repo_info_dict is None:
        logger.error("Please input correct repo_info_dict")
        return ""
    # Get the sub_info_content according to sub_info_keywords
    match key:
        case "branch":
            logger.debug("getting default branch...")
            sub_info_content = repo_info_dict["default_branch"]
            return sub_info_content
        case "description":
            logger.debug("getting description...")
            sub_info_content = repo_info_dict["description"]
            return sub_info_content
        case "homepage":
            logger.debug("getting homepage...")
            sub_info_content = repo_info_dict["homepage"]
            return sub_info_content
        case _:
            logger.error("Please input correct sub_info_keywords: \"branch\" / \"description\" / \"homepage\"")
            return ""


def create_repo(owner_name: str, repo_name: str, headers: dict | None, source_owner: str = "", source_repo_name: str = "", description: str = "", homepage: str = ""):
    """
    创建一个新的私有仓库，并禁用 Actions 权限。
    :param owner_name: 仓库所有者的用户名
    :param repo_name: 仓库名称
    :param headers: dict, 请求头
    :param source_owner: 源仓库所有者的用户名
    :param source_repo_name: 源仓库名称
    :param description: 仓库描述
    :param homepage: 仓库主页 URL
    :return: response 对象
    """
    # Create repo
    api_create_repo = "https://api.github.com/user/repos"

    if homepage:
        description_new = f"{description} ({homepage})"
    else:
        description_new = description

    if source_owner and source_repo_name:
        homepage_new = f"https://github.com/{source_owner}/{source_repo_name}"
    else:
        homepage_new = ""

    # Create the data for the new repository
    data = {
        "name": repo_name,
        "description": description_new,
        "homepage": homepage_new,
        "private": True,
        "has_wiki": True,
        "has_issues": True,
        "has_projects": False,
        "is_template": False
    }

    response = requests.post(api_create_repo, headers=headers, data=json.dumps(data))
    if response.status_code == 201:
        logger.info(f"Successfully created the repo {repo_name}!")
        # disable repo action permission
        change_repo_action_permission(f"{owner_name}/{repo_name}", headers)
    else:
        logger.error(f"Failed to create the repo {repo_name}!")
    return response


def change_repo_action_permission(repo, headers, enabled: bool = False):
    """
    更改仓库 Actions 的权限
    :param repo: 包含 owner 的仓库全名, "owner/repo"
    :param headers: dict, 请求头
    :param enabled: bool, 是否启用 Actions 权限，默认为 False（禁用）
    :return: response 对象
    """
    # Change repo action permission
    api_action_perm = f"https://api.github.com/repos/{repo}/actions/permissions"

    data = {
        "enabled": enabled
    }

    response = requests.put(api_action_perm, headers=headers, data=json.dumps(data))
    if response.status_code == 204:
        logger.info(f"Successfully changed the action permission of {repo}!")
    else:
        logger.error(f"Failed to change the action permission of {repo}!")
    return response


def compare_commit(
        dst_repo: str,
        src_repo: str,
        target_branch: str,
        headers: dict | None
) -> str | None:
    """
    比较两个仓库在指定分支上的提交差异，并根据差异情况将源仓库添加到相应的列表中。
    :param dst_repo: 包含 owner 的目标仓库全名, "owner/repo"
    :param src_repo: 包含 owner 的源仓库全名, "owner/repo"
    :param target_branch: 指定的分支名称
    :param headers: dict, 请求头
    :return: str, repo_status ["NEED_UPDATE", "CONFLICT", "OK", "INITIATED", "BRANCH_NOT_FOUND"]
    """

    # Define a function to compare commits between repos
    # dst_repo: destination repo (dest_owner/dest_repo)
    # src_repo: source repo (source_owner/source_repo)

    # Check if the specified branch is in the repo
    api_branch = "https://api.github.com/repos/{}/branches/{}"
    # GitHub API endpoint for getting the commits of a repository for a specific branch
    api_commit = "https://api.github.com/repos/{}/commits?sha={}&per_page=100"
    # GitHub API endpoint for getting the compare information between two repositories
    api_compare = "https://api.github.com/repos/{}/compare/{}...{}"

    branch_response = requests.get(api_branch.format(dst_repo, target_branch), headers=headers)
    # Check if the request was successful
    if branch_response.status_code == 200:
        logger.debug("The branch exists in the repository.")
        # Get the commits of the first repository for the specified branch
        dst_repo_commits = requests.get(api_commit.format(dst_repo, target_branch), headers=headers).json()
        # Get the SHA of the latest commit of the first repository
        dst_repo_latest_commit = dst_repo_commits[0]["sha"]

        # Get the commits of the second repository for the specified branch
        src_repo_commits = requests.get(api_commit.format(src_repo, target_branch), headers=headers).json()
        # Get the SHA of the latest commit of the second repository
        src_repo_latest_commit = src_repo_commits[0]["sha"]
        logger.debug(f"{dst_repo_latest_commit}...{src_repo_latest_commit}")

        # Compare the destination repo to source repo based on latest commit
        src_repo_compare_info = requests.get(api_compare.format(src_repo, dst_repo_latest_commit, src_repo_latest_commit), headers=headers)  # .json()
        if src_repo_compare_info.status_code == 200:
            # Get the number of commits ahead and behind for the second repository
            src_repo_ahead = src_repo_compare_info.json()['ahead_by']
            src_repo_behind = src_repo_compare_info.json()['behind_by']
            # Print the results
            logger.info(f"{src_repo} is ahead by {src_repo_ahead} commits and behind by {src_repo_behind} commits compared to {dst_repo}")

            # Save ahead source repo according to conditions
            if src_repo_ahead > 0 and src_repo_behind == 0:  # update repo
                repo_status = "NEED_UPDATE"
            elif src_repo_ahead > 0 and src_repo_behind > 0:  # conflict repo
                repo_status = "CONFLICT"
            else:
                repo_status = "OK"
                logger.info("This branch is up to date with upstream")
        else:
            logger.error(f"ERROR [{src_repo_compare_info.status_code}]: CANNOT compare {src_repo}, This repo might be initiated.")
            repo_status = "INITIATED"
        return repo_status
    else:
        logger.error(f"ERROR [{branch_response.status_code}]: The branch {target_branch} does not exist in the repository {dst_repo}")
        repo_status = "BRANCH_NOT_FOUND"
        return repo_status


def sync_repo_subprocess(

        source_repo: str,
        dest_repo: str,
        dest_ssh_private_key: str,
        is_sync_repo: bool = True,
        is_sync_tag: bool = True,
        docker_image_name: str = "git-sync",
        source_branch: str = "refs/remotes/source/*",
        dest_branch: str = "refs/heads/*",
        source_branch_tag: str = "refs/tags/*",
        dest_branch_tag: str = "refs/tags/*"
):
    """
    使用 subprocess 调用 Docker 容器中的 git-sync 或 git-sync-dev-tag 工具来同步仓库和标签。
    :param source_repo: 包含 owner 的源仓库全名, "owner/repo"
    :param dest_repo: 包含 owner 的目标仓库全名, "owner/repo"
    :param is_sync_repo: 是否同步仓库
    :param is_sync_tag: 是否同步标签
    :param dest_ssh_private_key: 目标仓库的 SSH 私钥
    :param docker_image_name: 使用的 Docker 镜像名称, "git-sync" / "git-sync-dev-tag"
    :param source_branch: 源仓库的分支引用
    :param dest_branch: 目标仓库的分支引用
    :param source_branch_tag: 源仓库的标签引用
    :param dest_branch_tag: 目标仓库的标签引用
    :return: 无
    """
    # subprocess.run will stop running the next command after run previous command, if the previous command fails
    if docker_image_name == "git-sync":
        # build docker image for git-sync
        # os.system("docker build -t git-sync:latest -q .")
        logger.info(f"Using docker image: {docker_image_name}")

        # sync repo with specified branch using git-sync
        if is_sync_repo and not is_sync_tag:
            # sync repo
            docker_command = f"docker run --rm -e DESTINATION_SSH_PRIVATE_KEY=\"{dest_ssh_private_key}\" --name sync-repo-branches git-sync:latest {source_repo} {source_branch} {dest_repo} {dest_branch}"
            subprocess_run(docker_command, f"Successfully sync repo for {dest_repo}!")
        elif is_sync_repo and is_sync_tag:
            # sync repo
            docker_command1 = f"docker run --rm -e DESTINATION_SSH_PRIVATE_KEY=\"{dest_ssh_private_key}\" --name sync-repo-branches git-sync:latest {source_repo} {source_branch} {dest_repo} {dest_branch}"
            docker_result1 = subprocess_run(docker_command1, f"Successfully sync repo for {dest_repo}, continue to sync tags...")
            if docker_result1.returncode == 0:
                # sync tags
                docker_command2 = f"docker run --rm -e DESTINATION_SSH_PRIVATE_KEY=\"{dest_ssh_private_key}\" --name sync-repo-tags git-sync:latest {source_repo} {source_branch_tag} {dest_repo} {dest_branch_tag}"
                subprocess_run(docker_command2, f"Successfully sync tags for {dest_repo}!")
        elif not is_sync_repo and is_sync_tag:
            logger.error(f"ERROR: Must sync repo first before sync tags for {dest_repo}")
        else:
            logger.info(f"Skip sync repo and tags for {dest_repo}")
        return None
    elif docker_image_name == "git-sync-dev-tag":
        # build docker image for git-sync-dev-tag
        # os.system("docker build -t git-sync:dev_tag -q .")
        logger.info(f"Using docker image: {docker_image_name}")

        # sync repo with specified branch and tag using git-sync-dev-tag
        if is_sync_repo and is_sync_tag:
            # sync repo and tags
            docker_command = f"docker run --rm -e DESTINATION_SSH_PRIVATE_KEY=\"{dest_ssh_private_key}\" -e SOURCE_BRANCH_TAG=\"{source_branch_tag}\" -e DESTINATION_BRANCH_TAG=\"{dest_branch_tag}\" --name sync-repo-branch-tag git-sync:dev_tag {source_repo} {source_branch} {dest_repo} {dest_branch}"
            subprocess_run(docker_command, f"Successfully sync repo and tags for {dest_repo}!")
        elif is_sync_repo and not is_sync_tag:
            # sync repo
            docker_command = f"docker run --rm -e DESTINATION_SSH_PRIVATE_KEY=\"{dest_ssh_private_key}\" --name sync-repo-branch git-sync:dev_tag {source_repo} {source_branch} {dest_repo} {dest_branch}"
            subprocess_run(docker_command, f"Successfully sync repo branch for {dest_repo}!")
        elif not is_sync_repo and is_sync_tag:
            logger.error(f"ERROR: Must sync repo first before sync tags for {dest_repo}")
        else:
            logger.info(f"Skip sync repo and tags for {dest_repo}")
        return None
    else:
        logger.error("Please input correct docker image name: \"git-sync\" / \"git-sync-dev-tag\"")
        return None


def update_repo_default_branch(repo: str, target_branch: str, headers: dict | None):
    """
    更新仓库的默认分支
    :param repo: 包含 owner 的仓库全名, "owner/repo"
    :param target_branch: 目标分支名称
    :param headers: dict, 请求头
    :return: response 对象
    """
    # update repo info

    # Set the data for updating the default branch
    update_data = {
        "default_branch": target_branch
    }
    update_response = requests.patch(api_repo_info.format(repo), headers=headers, data=json.dumps(update_data))
    # Check if the request was successful
    if update_response.status_code == 200:
        logger.info(f"Successfully updated the default branch \"{target_branch}\" for {repo}!")
    else:
        logger.error(f"Failed to update the default branch for {repo}!")
    return update_response


def create_release(repo: str, branch: str, headers: dict | None, release_feature: str = "Add Tags"):
    """
    创建一个新的 release, 名称为 release_feature, 目标分支为 branch。
    版本标签格式为 "YYYYMMDD"
    :param repo: 包含 owner 的仓库全名, "owner/repo"
    :param branch: 创建 release 使用的分支名称
    :param headers: dict, 请求头
    :param release_feature: release 名称
    :return:
    """
    # Create release
    api_repo_release = f"https://api.github.com/repos/{repo}/releases"
    tag_name = datetime.now().strftime("%Y%m%d")
    target_commitish = branch
    release_name = release_feature
    release_body = f"Add Tags for {branch}. {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} Updated."

    release_data = {
        "tag_name": tag_name,
        "target_commitish": target_commitish,
        "name": release_name,
        "body": release_body,
        "draft": False,
        "prerelease": False
    }

    response = requests.post(api_repo_release, headers=headers, data=json.dumps(release_data))
    if response.status_code == 201:
        logger.info(f"Successfully created the release for {repo}!")
    else:
        logger.error(f"Failed to create the release for {repo}!")
    return response


def delete_old_releases(owner: str, repo: str, headers: dict | None, keep_latest: int, release_feature: str = "Add Tags"):
    """
    删除旧的 release, 根据 release_feature 匹配, 保留最新的 keep_latest 个 release
    :param owner: 仓库所有者的用户名
    :param repo: 仓库名称
    :param headers: dict, 请求头
    :param keep_latest: int, 保留最新的 release 数量
    :param release_feature: release 名称
    :return: releases 列表 or None if error
    """
    # delete old releases according to the release feature and keep latest
    logger.info(f"Repo: {owner}/{repo}; Release feature: {release_feature}; Keep latest: {keep_latest}")
    # Get the releases for the repository
    response = requests.get(api_release.format(owner, repo), headers=headers)

    # Check if there was an error getting the releases
    if response.status_code != 200:
        logger.error(f"Error getting releases: {response.status_code} {response.reason}")
        return None

    # Parse the JSON response
    releases = response.json()

    # Loop through the releases and find the ones that match the release feature
    matching_releases = []
    for release in releases:
        # if release["tag_name"] == release_feature:  # matching according to tag name
        # if release["tag_name"].startswith(release_feature):  # matching according to tag name
        if release["name"] == release_feature:  # matching according to release name
            matching_releases.append(release)

    # Sort the matching releases by the creation date (newest first)
    matching_releases = sorted(matching_releases, key=lambda r: r["created_at"], reverse=True)
    releases_to_keep = matching_releases[:keep_latest]  # keep latest releases
    releases_to_delete = matching_releases[keep_latest:]  # delete old releases

    if releases_to_delete:
        # Delete all but the newest keep_latest releases
        logger.info(f"There are {len(releases_to_delete)} releases to delete...")
        logger.debug(f"There are {len(releases_to_keep)} releases to keep...")
        for release in releases_to_delete:
            logger.info(f"Deleting release {release['name']}...")
            delete_response = requests.delete(api_release_id.format(owner, repo, release['id']), headers=headers)
            if delete_response.status_code != 204:
                logger.error(f"Error deleting release {release['name']}: {delete_response.status_code} {delete_response.reason}")
        logger.info("Done!")
    else:
        logger.info("There is no release to delete.")
    return releases


def safe_shutil_rm_tree(directory: str):
    """
    安全地删除目录，避免误删根目录。
    :param directory: 要删除的目录路径
    :return: 无
    """
    if os.path.abspath(directory) == os.path.abspath('/'):
        # Avoid removing root directory
        logger.error("Error: Cannot remove the root directory.")
    else:
        # delete target directory
        shutil.rmtree(directory)


def git_clone_repo(owner_name: str, repo_name: str, repo_clone_path: str, github_token: str = ""):
    """
    克隆一个 GitHub 仓库到指定路径，如果路径已存在则先删除该路径。
    如果提供了 GitHub 访问令牌，则使用令牌进行身份验证。
    :param owner_name: 仓库所有者的用户名
    :param repo_name: 仓库名称
    :param repo_clone_path: 克隆到的本地路径
    :param github_token: GitHub 访问令牌（可选）
    :return: 无
    """
    # Clone the repository
    # Delete the path if it exists
    if os.path.exists(repo_clone_path):
        if os.path.isfile(repo_clone_path):
            os.remove(repo_clone_path)
        else:
            safe_shutil_rm_tree(repo_clone_path)
    # Set the URL for cloning the repository
    if github_token:
        repo_clone_url = f"https://{github_token}@github.com/{owner_name}/{repo_name}.git"
    else:
        repo_clone_url = f"https://github.com/{owner_name}/{repo_name}.git"
    # Clone the repository
    git.Repo.clone_from(repo_clone_url, repo_clone_path)


def safe_git_clone(repo_url: str, dest_path: str):
    try:
        git.Repo.clone_from(repo_url, dest_path)
        logger.debug(f"克隆成功: {repo_url}")
        return True
    except git.GitCommandError as e:
        # 判断是否是因为需要账号密码
        err_msg = str(e)
        if ("Authentication failed" in err_msg) or ("could not read Username" in err_msg) or ("Permission denied" in err_msg):
            logger.error(f"需要账号密码，跳过仓库: {repo_url}")
            return False
        else:
            logger.error(f"克隆失败: {repo_url}\nERROR: {e}")
            return False


def git_clone_repo_wiki(repo, repo_wiki_temp_path):
    """
    克隆一个 GitHub 仓库的 wiki 到指定的临时路径，并删除克隆后的 .git 目录。
    :param repo: 包含 owner 的仓库全名, "owner/repo"
    :param repo_wiki_temp_path: 克隆到的临时路径
    :return: 无
    """
    # Set the URL for cloning the repository
    repo_wiki_url = f"https://github.com/{repo}.wiki.git"
    new_repo_clone_path = f"{repo_wiki_temp_path}/{repo}.wiki"
    # 检查路径是否存在，存在则跳过
    if os.path.exists(new_repo_clone_path):
        logger.warning(f"The path {new_repo_clone_path} already exists, skip cloning the wiki {repo_wiki_url}.")
        return None

    # 克隆 wiki 仓库
    clone_status = safe_git_clone(repo_wiki_url, new_repo_clone_path)
    if clone_status:
        logger.debug(f"Successfully cloned the wiki {repo_wiki_url}!")
        # Delete .git folder
        safe_shutil_rm_tree(f"{new_repo_clone_path}/.git")
    else:
        # 克隆失败, 可能没有 wiki 页面
        logger.warning(f"Failed to clone the wiki {repo_wiki_url}, skip this wiki.")
    return clone_status


def structure_repo_files(repo_wiki_temp_path: str, repo_clone_path: str, mode: str = "rclone"):
    """
    结构化仓库文件，将临时路径下的所有文件和目录复制到目标路径，并删除临时路径。
    支持使用 rclone 或 shutil 进行复制。
    :param repo_wiki_temp_path: 临时路径
    :param repo_clone_path: 目标路径
    :param mode: "rclone" / "shutil"
    :return:  无
    """
    match mode:
        case "rclone":
            from tools import is_rclone_installed, rclone_run

            if not is_rclone_installed():
                logger.error("rclone is not installed, please install rclone first.")
                return None

            # set rclone flags
            # ignore .git folder
            rclone_args = ["--exclude .git/**", "--transfers=4"]
            # 使用 rclone 复制文件和目录
            rclone_result = rclone_run(repo_wiki_temp_path, repo_clone_path, mode="copy", args=rclone_args)
            if rclone_result:
                logger.info(f"Successfully copy files from \"{repo_wiki_temp_path}\" to \"{repo_clone_path}\"!")
                # Delete repo_wiki_temp_path
                safe_shutil_rm_tree(repo_wiki_temp_path)
            else:
                logger.error(f"Failed to copy files from \"{repo_wiki_temp_path}\" to \"{repo_clone_path}\"!")
            return rclone_result
        case "shutil":
            # Copy  all files and dirs in repo_wiki_temp_path to repo_clone_path
            shutil.copytree(f"{repo_wiki_temp_path}", repo_clone_path)
            # Delete repo_wiki_temp_path
            safe_shutil_rm_tree(repo_wiki_temp_path)
            return True
        case _:
            logger.error("Please input correct mode: \"rclone\" / \"shutil\"")
            return False


def git_push_repo(owner_name, repo_name, repo_path, owner_email="", owner_ssh_key="", use_ssh_key: bool = False, delete_after_push: bool = True):
    """
    推送本地仓库到远程，如果提供了 SSH 私钥，则使用该私钥进行身份验证。
    推送完成后，如果 delete_after_push 为 True，则删除本地仓库路径。
    该函数假设本地仓库已经存在并且已经配置了远程 origin。
    :param owner_name: 仓库所有者的用户名
    :param repo_name: 仓库名称
    :param repo_path: 本地仓库路径
    :param owner_email: 仓库所有者的电子邮件
    :param owner_ssh_key: 仓库所有者的 SSH 私钥
    :param use_ssh_key: 是否使用 SSH 私钥进行身份验证
    :param delete_after_push: 推送完成后是否删除本地仓库路径
    :return: 无
    """
    # 是否推送更改
    push = True

    # Push the repository
    repo = git.Repo(repo_path)
    # Set the owner name
    repo.config_writer().set_value('user', 'name', owner_name).release()
    # Set the owner email
    repo.config_writer().set_value('user', 'email', owner_email).release()
    if use_ssh_key:
        # Generate ssh key file
        owner_ssh_key_file = f"{repo_path}/.git/{repo_name}"
        with open(owner_ssh_key_file, 'w') as f:
            f.write(owner_ssh_key)
        # Set the ssh command
        ssh_command = f'/usr/bin/ssh -i {owner_ssh_key_file}'
        repo.config_writer().set_value('core', 'sshCommand', ssh_command).release()

    # 检查更改
    diffs = repo.head.commit.diff(None)  # 检查工作区是否有更改
    status = repo.git.status("--porcelain")  # 获取状态, 是否有更改
    logger.info(f"检查更改: {len(diffs)} 个差异, 状态: '{status.strip()}'")
    # 检查工作区和暂存区的更改
    if diffs:
        work_diffs = repo.git.diff()
        staged_diffs = repo.git.diff('--cached')
        logger.debug(f"工作区的更改: {work_diffs}")  # 输出详细的 diff 信息
        logger.debug(f"已暂存的更改: {staged_diffs}")  # 输出详细的 diff 信息

    # 提交更改
    if diffs or status or repo.untracked_files:
        message = f"Update at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        repo.git.add(A=True)  # 添加所有更改到暂存区
        repo.index.commit(message)
        new_commit = repo.commit('HEAD')
        logger.info(f"✅ 新提交 {new_commit.hexsha[:7]} 已生成")
        if push:
            # 推送到远程
            origin = repo.remote(name='origin')  # get the remote origin
            origin.push()  # push to the remote origin
            logger.info(f"✅ 成功推送到远程仓库 {owner_name}/{repo_name}")
    else:
        logger.info("没有需要提交的更改。")

    if delete_after_push:
        # Delete the repository
        safe_shutil_rm_tree(repo_path)
