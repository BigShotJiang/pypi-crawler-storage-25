from git import Repo
from pathlib import Path
import shutil
import tempfile
import logging

# 获取日志记录器
logger: logging.Logger = logging.getLogger(__name__)


def create_worktree_temp_dir() -> Path:
    """
    创建一个临时的 worktree 路径
    :return: 临时目录路径
    """
    # 为 worktree 创建临时目录
    tmpdir = Path(tempfile.mkdtemp(prefix="git-worktree-"))

    return tmpdir


def create_worktree(repo: Repo, branch: str, workdir: str | Path) -> Path:
    """
    创建一个临时的 worktree 路径，并添加到指定分支
    :param repo: Repo 对象
    :param branch: 分支名称
    :param workdir: 临时目录路径
    :return: 临时目录路径
    """
    tmpdir = Path(workdir)  # 临时目录路径

    try:
        # 添加 worktree
        repo.git.worktree("add", str(tmpdir), branch)
        logger.info(f"临时 worktree 已创建: {tmpdir}")
    except Exception as e:
        logger.error(f"❌ 创建临时 worktree 失败: {e}")
        raise e

    return tmpdir


def delete_worktree(repo: Repo, workdir: Path):
    """
    删除临时的 worktree 路径
    :param repo: Repo 对象
    :param workdir: worktree 工作目录路径
    """
    try:
        # 移除 worktree
        repo.git.worktree("remove", str(workdir), "--force")
        logger.info(f"worktree 已移除: {workdir}")
    except Exception as e:
        logger.error(f"❌ 移除 worktree 失败: {e}")


def clean_repo_folder(folder: Path, files_to_keep: list[str] = [".gitignore", ".gitattributes", ".git"]):
    """
    删除文件夹下所有内容，但保留指定文件
    :param folder: Path 对象，目标目录
    :param files_to_keep: 保留的文件列表
    """
    for item in folder.iterdir():
        if item.name in files_to_keep:
            continue
        if item.is_file():
            item.unlink()
        elif item.is_dir():
            shutil.rmtree(item)


def reinit_commit(repo: Repo, branch: str, message: str = "Initial commit"):
    """
    重新初始化分支，删除所有历史提交，保留当前文件
    :param repo: Repo 对象
    :param branch: 分支名称
    :param message: 提交信息
    """
    # 切换到目标分支
    repo.git.checkout(branch)

    # 1. 创建 orphan 分支
    orphan_branch = "latest_branch"
    repo.git.checkout("--orphan", orphan_branch)

    # 2. 添加所有文件
    repo.git.add(A=True)

    # 3. 提交
    repo.index.commit(message)

    # 4. 删除旧分支
    if branch in repo.heads:
        repo.git.branch("-D", branch)

    # 5. orphan 分支改名为目标分支
    repo.git.branch("-m", branch)

    # 6. 强制推送到远程
    repo.git.push("origin", branch, force=True)

    logger.info(f"✅ 分支 {branch} 已重新初始化并强制推送到远程仓库")


def get_file_at_branch(repo: Repo, branch: str, file_path: str):
    """
    获取指定分支下的文件内容, 不切换分支
    :param repo: Repo 对象
    :param branch: 分支名称
    :param file_path: 文件路径
    :return: 文件内容
    """
    # 获取对应分支的 commit
    commit = repo.commit(branch)

    # 读取 blob 对象
    blob = commit.tree / file_path
    # 读取文件内容
    content = blob.data_stream.read().decode("utf-8")

    return content


def copy_files_to_branch(repo: Repo, dst_branch: str, files_map: dict, relative_dir: Path, message: str | None = None, commit: bool = True, push: bool = True, remove_temp: bool = True):
    """
    把多个本地文件复制到指定分支，不切换当前分支

    :param repo: Repo 对象
    :param dst_branch: 目标分支名
    :param files_map: dict，键是本地文件路径，值是仓库内相对于仓库根目录的目标路径
    :param relative_dir: 目标路径的目录, 相对于仓库根目录
    :param message: 提交信息（可选）
    :param commit: 是否提交更改
    :param push: 是否推送到远程（需要 commit=True）
    :param remove_temp: 是否移除临时目录
    """
    # 为 worktree 创建临时目录
    tmpdir = create_worktree_temp_dir()

    try:
        # 添加 worktree
        repo.git.worktree("add", str(tmpdir), dst_branch)
        logger.info(f"临时 worktree 已创建: {tmpdir}")
        tmp_repo = Repo(tmpdir)  # 在临时目录中初始化 Repo 对象

        # 目标目录路径
        dst_dir = tmpdir / relative_dir  # 目标目录在临时 worktree 目录中的路径
        dst_dir.mkdir(parents=True, exist_ok=True)  # 确保目标目录存在
        clean_repo_folder(dst_dir)  # 清理目标目录
        logger.info(f"目标目录已清理: {dst_dir.name}")

        added_files = []
        for src_file, dst_repo_path in files_map.items():
            src_file = Path(src_file)
            dst_file = tmpdir / dst_repo_path  # 目标文件在临时 worktree 目录中的路径
            dst_file.parent.mkdir(parents=True, exist_ok=True)

            # 拷贝文件
            if dst_file.exists():
                logger.debug(f"目标文件已存在，覆盖 {dst_repo_path}")
            shutil.copy2(src_file, dst_file)
            # 添加到已暂存区
            added_files.append(dst_repo_path)

        if commit:
            if not message:
                message = f"Copy {len(added_files)} file(s) into {dst_branch}"

            # 检查更改
            diffs = tmp_repo.head.commit.diff(None)  # 检查工作区是否有更改
            status = tmp_repo.git.status("--porcelain")  # 获取状态, 是否有更改
            logger.info(f"检查更改: {len(diffs)} 个差异, 状态: '{status.strip()}'")
            # 检查工作区和暂存区的更改
            if diffs:
                work_diffs = tmp_repo.git.diff()
                staged_diffs = tmp_repo.git.diff('--cached')
                logger.debug(f"工作区的更改: {work_diffs}")  # 输出详细的 diff 信息
                logger.debug(f"已暂存的更改: {staged_diffs}")  # 输出详细的 diff 信息

            # 提交更改
            if diffs or status or tmp_repo.untracked_files:
                tmp_repo.git.add(A=True)  # 添加所有更改到暂存区
                tmp_repo.index.commit(message)
                new_commit = tmp_repo.commit(dst_branch)
                logger.info(f"✅ 已提交 {len(added_files)} 个文件到分支 {dst_branch}")
                logger.info(f"✅ 新提交 {new_commit.hexsha[:7]} 已生成")
                if push:
                    # 推送到远程
                    tmp_repo.git.push("origin", dst_branch)
                    logger.info(f"✅ 已推送到远程分支 {dst_branch}")
            else:
                logger.info("没有需要提交的更改。")
        else:
            logger.info(f"✅ 已同步 {len(added_files)} 个文件到分支 {dst_branch}, 但未提交, 请手动检查更改")
            logger.info(f"临时 worktree 路径: {tmpdir}")

        # 关闭临时仓库, 释放资源
        tmp_repo.close()

    except Exception as e:
        logger.error(f"❌ 发生错误: {e}")
    finally:
        if remove_temp:
            # 移除 worktree
            delete_worktree(repo, tmpdir)
        else:
            logger.info(f"临时 worktree 保留: {tmpdir}")
