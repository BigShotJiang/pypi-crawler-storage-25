import pickle
import logging

# 获取日志记录器
logger: logging.Logger = logging.getLogger(__name__)


def read_pickle_file(pickle_file):
    """
    读取 pickle 文件
    :param pickle_file: pickle 文件路径
    :return: 读取的数据，如果出错则返回 None
    """
    try:
        with open(pickle_file, "rb") as f:
            data = pickle.load(f)
        return data
    except Exception as e:
        logger.error(f"读取 pickle 文件时出错: {e}")
        return None


def write_pickle_file(data, pickle_file):
    """
    写入 pickle 文件
    :param data: 要写入的数据
    :param pickle_file: pickle 文件路径
    :return: None
    """
    try:
        with open(pickle_file, "wb") as f:
            pickle.dump(data, f)  # type: ignore
    except Exception as e:
        logger.error(f"写入 pickle 文件时出错: {e}")
