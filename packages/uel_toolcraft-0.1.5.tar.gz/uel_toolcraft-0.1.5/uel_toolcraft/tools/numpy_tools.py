import numpy as np
import logging

# 获取日志记录器
logger: logging.Logger = logging.getLogger(__name__)


def pad_and_stack(peak_dict, keys: list | None = None, is_pad: bool = False, fill_value=np.nan):
    """
    将长度不等的峰值列表对齐，用 np.nan 填充缺失值。
    """
    if keys is None:
        keys = ["peak_x", "peak_y", "trough_x", "trough_y"]

    arrays = [np.array(peak_dict.get(k, []), dtype=float) for k in keys]

    if is_pad:
        max_len = max(len(a) for a in arrays)
        padded = [
            np.pad(a, (0, max_len - len(a)), constant_values=fill_value)
            for a in arrays
        ]
        result = np.column_stack(padded)
    else:
        result = np.column_stack(arrays)

    return result
