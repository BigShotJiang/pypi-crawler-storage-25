import os
import hashlib
import shutil
import logging
from pathlib import Path

# 获取日志记录器
logger: logging.Logger = logging.getLogger(__name__)


def ensure_path(file_path):
    """
    确保文件路径为 `Path` 对象。
    :param file_path:
    :return:  `Path` 对象
    """
    if not isinstance(file_path, Path):
        file_path = Path(file_path)
    return file_path


def get_subfolders(directory: str | Path) -> list:
    """
    获取指定目录下的所有子文件夹名称列表。
    :param directory: 目录路径
    :return subfolder_list: 子文件夹名称列表
    """
    path = ensure_path(directory)
    subfolder_list = [folder.name for folder in path.iterdir() if folder.is_dir()]
    return subfolder_list


def shutil_move(file_or_folder_name, source_dir, dest_dir):
    """
    移动文件或文件夹到目标目录
    :param file_or_folder_name: str, 要移动的文件或文件夹名称
    :param source_dir: str, 源目录
    :param dest_dir: str, 目标目录
    """
    source_path = Path(source_dir) / file_or_folder_name
    dest_path = Path(dest_dir)

    # 检查目标目录是否存在，不存在则创建
    if not dest_path.exists():
        dest_path.mkdir(parents=True, exist_ok=True)

    # 检查文件是否存在
    if not source_path.exists():
        logger.warning(f"❌ 文件(夹) \"{file_or_folder_name}\" 不存在！")
        return

    try:
        shutil.move(source_path, dest_path)
        logger.debug(f"✅ 文件 \"{file_or_folder_name}\" 移动成功！")
    except Exception as e:
        logger.error(f"移动 {file_or_folder_name} 时出错: {e}")


def shutil_move_from_list(file_list, source_dir, dest_dir):
    """
    批量移动文件到目标目录
    :param file_list: list, 文件名列表
    :param source_dir: str, 源目录
    :param dest_dir: str, 目标目录
    """
    for file in file_list:
        shutil_move(file, source_dir, dest_dir)


def supported_media_extensions(media_type="all"):
    """
    支持的图片和视频格式
    :param media_type: str, 文件类型，可选值："image"/"photo", "video", "audio"
    :return: set, 文件扩展名集合
    """
    image_extensions = {".jpg", ".jpeg", ".png", ".gif", ".bmp", '.tiff', '.tif', '.webp', '.svg'}
    video_extensions = {".mp4", ".avi", ".mov", ".mkv", ".m4v", ".webm", ".flv", ".wmv"}
    audio_extensions = {".mp3", ".wav", ".flac", ".aac", ".m4a", ".wma"}
    if media_type == "image" or media_type == "photo":
        media_extensions = image_extensions
    elif media_type == "video":
        media_extensions = video_extensions
    elif media_type == "audio":
        media_extensions = audio_extensions
    else:
        media_extensions = image_extensions | video_extensions | audio_extensions

    return media_extensions


def check_file_type(filename):
    """
    根据文件名检查文件类型
    :param filename: str, 文件名
    :return: str, 文件类型
    """
    photo_extensions = supported_media_extensions("photo")
    video_extensions = supported_media_extensions("video")
    audio_extensions = supported_media_extensions("audio")

    file_ext = Path(filename).suffix.lower()  # 获取文件扩展名

    if file_ext in photo_extensions:
        file_type = "photo"
    elif file_ext in video_extensions:
        file_type = "video"
    elif file_ext in audio_extensions:
        file_type = "audio"
    else:
        file_type = "document"

    return file_type


def scan_media_files(directory, media_type="all") -> list:
    """
    扫描指定目录，返回图片和视频文件列表
    :param directory:  str | Path, 目录路径
    :param media_type: str, 文件类型，可选值："image"/"photo", "video", "audio", "all" (默认)
    :return: list, 符合格式的文件列表 (Path 对象)
    """
    # 支持的图片和视频格式
    media_extensions = supported_media_extensions(media_type=media_type)

    # 获取目录路径
    dir_path = Path(directory)

    # # 使用迭代器扫描目录，获取所有符合格式的文件
    # media_files_list = sorted(
    #     [file for file in dir_path.iterdir() if file.suffix.lower() in media_extensions],
    #     key=lambda x: x.stem  # 按文件名排序
    # )

    # **使用 `glob()` 直接筛选，提高效率**
    all_files_list = sorted(
        dir_path.glob("*"),  # 直接匹配所有文件
        key=lambda x: x.stem  # 按文件名排序
    )
    # **筛选符合格式的文件**
    media_files_list = [file for file in all_files_list if file.suffix.lower() in media_extensions]

    return media_files_list  # 返回 `Path` 对象列表


def scan_txt_files(directory) -> list:
    """
    扫描指定目录，返回图片和视频文件列表
    :param directory:  str | Path, 目录路径
    :return: list, 符合格式的文件列表 (Path 对象)
    """
    # 支持的图片和视频格式
    file_extensions = [".txt"]

    # 获取目录路径
    dir_path = Path(directory)

    # **使用 `glob()` 直接筛选，提高效率**
    all_files_list = sorted(
        dir_path.glob("*"),  # 直接匹配所有文件
        key=lambda x: x.stem  # 按文件名排序
    )
    # **筛选符合格式的文件**
    media_files_list = [file for file in all_files_list if file.suffix.lower() in file_extensions]

    return media_files_list  # 返回 `Path` 对象列表


def scan_json_files(directory: Path, is_filter: bool = True) -> list:
    """
    扫描指定目录中的 JSON 文件，并根据文件名进行过滤。
    :param directory:  Path
    :param is_filter:  bool
    :return:  list
    """
    all_file_list = sorted(
        [f for f in directory.iterdir() if f.suffix.lower() in ('.json', '.jsonc')],  # 匹配 JSON 和 JSONC 文件
        key=lambda x: x.stem  # 按文件名排序
    )
    if is_filter:
        json_files = [file for file in all_file_list
                      if ('success' in file.name or 'fail' in file.name)]  # 过滤出符合要求的 JSON 文件
    else:
        json_files = all_file_list
    return json_files


def convert_bytes_to_human_readable(size):
    """
    将字节大小转换为人类可读的文件大小单位。
    :param size: int
        文件大小，单位为 Bytes。
    :return: str
        人类可读的文件大小单位。
    """
    # 字节单位
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size < 1024.0:
            return f"{size:3.1f} {unit}"
        size /= 1024.0
    return f"{size:3.1f} PB"


def convert_to_bytes(size):
    """
    将文件大小单位转换为 Bytes。
    :param size: str
        文件大小，单位为 Bytes。
    :return: int
        文件大小，单位为 Bytes。
    """
    # 字节单位
    if size.endswith('B') and not size.endswith('KB') and not size.endswith('MB') and not size.endswith('GB') and not size.endswith('TB'):
        return int(float(size[:-1]))
    for unit in ['KB', 'MB', 'GB', 'TB']:
        if size.endswith(unit):
            return int(float(size[:-len(unit)]) * 1024 ** (['KB', 'MB', 'GB', 'TB'].index(unit) + 1))
    return int(size)


def md5sum(filepath: str | Path) -> str:
    """
    计算文件的 MD5 哈希
    :param filepath: 文件路径
    :return: MD5 哈希字符串
    """
    h = hashlib.md5()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def expand_file(filepath: str, size: int = 1024, mode: str = "fill"):
    """
    扩展文件大小
    :param filepath: 文件路径
    :param size: 扩展字节数
    :param mode: "sparse" = 稀疏扩展, "fill" = 实际写入 size 大小零字节
    """
    if not os.path.isfile(filepath):
        error_msg = f"文件不存在: {filepath}"
        raise FileNotFoundError(error_msg)

    if mode == "sparse":
        # 稀疏扩展文件, 只写最后一个字节
        with open(filepath, "ab") as f:
            f.seek(size - 1, os.SEEK_END)
            f.write(b"\0")  # 只写最后一个字节，扩展 size 字节（可能稀疏）
    elif mode == "fill":
        # 实际写零字节扩展文件
        with open(filepath, "ab") as f:
            f.write(b"\0" * size)  # 写满 size 个零字节，保证真实扩展
    else:
        raise ValueError("mode 必须是 'sparse' 或 'fill'")


def restore_file(filepath: str, size: int, mode: str = "fill"):
    """
    恢复文件到扩展前大小
    :param filepath: 文件路径
    :param size: 已扩展字节数
    :param mode: "sparse" = 稀疏扩展, "fill" = 实际写入 size 大小零字节
    """
    if not os.path.isfile(filepath):
        error_msg = f"文件不存在: {filepath}"
        raise FileNotFoundError(error_msg)

    file_size = os.path.getsize(filepath)
    if mode == "sparse":
        # 稀疏扩展文件, 逻辑大小增长了 size 字节
        original_size = file_size - size
    elif mode == "fill":
        # 实际扩展了 size 个零字节
        size_expanded = size  # 填充模式下，需截断 size 字节
        original_size = file_size - size_expanded
    else:
        raise ValueError("mode 必须是 'sparse' 或 'fill'")

    # 截断文件到原始大小
    with open(filepath, "rb+") as f:
        f.truncate(original_size)  # 截断文件
