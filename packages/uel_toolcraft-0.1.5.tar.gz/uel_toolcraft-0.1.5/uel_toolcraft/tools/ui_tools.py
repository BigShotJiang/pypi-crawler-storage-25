import sys
from pathlib import Path
from PyQt6.QtWidgets import QApplication, QFileDialog


def select_path(mode: str = "file"):
    """
    通过UI选择文件/文件夹/多个文件

    :param mode: "file" -> 选择单个文件
                 "files" -> 选择多个文件
                 "dir"/"folder" -> 选择文件夹
    :return: Path 对象 或 tuple[Path, ...]，若取消选择则返回 None
    """
    # 创建 QApplication 实例
    app = QApplication.instance() or QApplication(sys.argv)

    if mode == "file":
        file_path, _ = QFileDialog.getOpenFileName(
            None, "选择一个文件", "", "所有文件 (*.*)"
        )
        return Path(file_path) if file_path else None

    elif mode == "files":
        file_paths, _ = QFileDialog.getOpenFileNames(
            None, "选择多个文件", "", "所有文件 (*.*)"
        )
        return tuple(Path(p) for p in file_paths) if file_paths else None

    elif mode in ["dir", "folder"]:
        dir_path = QFileDialog.getExistingDirectory(
            None, "选择一个文件夹", ""
        )
        return Path(dir_path) if dir_path else None

    else:
        raise ValueError("mode 必须是 'file'、'files'、'dir' 或 'folder'")
