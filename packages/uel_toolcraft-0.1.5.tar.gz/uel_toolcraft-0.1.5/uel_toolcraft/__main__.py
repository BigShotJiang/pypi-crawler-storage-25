"""Entry point for `python -m uel_toolcraft`."""

import argparse
from importlib.metadata import version as _get_version


def main():
    parser = argparse.ArgumentParser(
        description="uel-toolcraft — A Unified Essential Library toolcraft"
    )
    parser.add_argument(
        "--version", action="version",
        version=f"uel-toolcraft {_get_version('uel-toolcraft')}"
    )
    parser.parse_args()


if __name__ == "__main__":
    main()
