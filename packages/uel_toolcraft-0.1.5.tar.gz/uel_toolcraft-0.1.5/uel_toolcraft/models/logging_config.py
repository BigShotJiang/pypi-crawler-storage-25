import logging
import sys
from pathlib import Path

_configured = False  # 用于防止重复配置

# 内置默认：总是屏蔽这些
_DEFAULT_BLOCK_LOGGERS = ["httpx", "urllib3"]


def _find_pyproject() -> Path | None:
    """从 CWD 向上查找 pyproject.toml"""
    cwd = Path.cwd().resolve()
    for parent in [cwd, *cwd.parents]:
        candidate = parent / "pyproject.toml"
        if candidate.is_file():
            return candidate
    return None


def _read_block_loggers() -> list[str]:
    """
    从 pyproject.toml 读取 
    [tool.uel-toolcraft.logging]
    block_loggers = ["logger1", "logger2"]
    """
    pyproject = _find_pyproject()
    if pyproject is None:
        return []

    try:
        # 使用 stdlib tomllib (3.11+) 或 tomli (3.10) 回退
        try:
            import tomllib  # type: ignore  # Python 3.11+
        except ImportError:
            import tomli as tomllib  # type: ignore  # Python 3.10
        data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
        return list(data.get("tool", {}).get("uel-toolcraft", {}).get("logging", {}).get("block_loggers", []))
    except Exception:
        return []


class LogConfig:
    """
    日志配置类，用于设置日志记录器的格式和处理器
    支持控制台输出和文件输出，支持彩色日志格式
    支持屏蔽第三方库的日志输出
    通过单例模式确保只配置一次
    通过全局变量 _configured 防止重复配置
    通过 get_logger 函数获取日志记录器实例
    """
    def __init__(self, level=logging.INFO, log_file=None, block_loggers=None):
        """
        :param level: 日志级别，默认为 logging.INFO
        :param log_file: 日志文件路径，如果为 None 则不输出到文件
        """
        global _configured
        if _configured:
            return  # 已配置过，直接跳过

        self.level = level
        self.log_file = Path(log_file) if log_file else None

        # 三源合并：内置默认 + pyproject.toml + 显式参数
        merged = set(_DEFAULT_BLOCK_LOGGERS)
        merged.update(_read_block_loggers())
        if block_loggers is not None:
            merged.update(block_loggers)
        self._block_loggers = merged

        self._configure_logging()
        _configured = True

    def _configure_logging(self):
        for noisy_logger in self._block_loggers:
            logging.getLogger(noisy_logger).setLevel(logging.WARNING)

        # 彩色日志格式
        class ColorFormatter(logging.Formatter):
            COLORS = {
                "DEBUG": "\033[37m",  # 白色
                "INFO": "\033[36m",  # 青色
                "WARNING": "\033[33m",  # 黄色
                "ERROR": "\033[31m",  # 红色
                "CRITICAL": "\033[41m",  # 红色背景
            }
            RESET = "\033[0m"

            def format(self, record):
                color = self.COLORS.get(record.levelname, self.RESET)
                message = super().format(record)
                return f"{color}{message}{self.RESET}"

        # 控制台 Handler
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(ColorFormatter("%(asctime)s [%(levelname)s]: %(message)s"))

        root_logger = logging.getLogger()
        root_logger.setLevel(self.level)
        root_logger.handlers.clear()
        root_logger.addHandler(console_handler)

        # 文件 Handler
        if self.log_file:
            self.log_file.parent.mkdir(parents=True, exist_ok=True)
            file_handler = logging.FileHandler(self.log_file, encoding="utf-8")
            file_handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s"))
            root_logger.addHandler(file_handler)


def get_logger(name=None, level=logging.INFO, log_file=None, block_loggers=None) -> logging.Logger:
    """
    获取日志记录器
    :param name: 日志记录器名称
    :param level: 日志级别
    :param log_file: 日志文件路径（可选）
    :return: logging.Logger 对象
    """
    LogConfig(level=level, log_file=log_file, block_loggers=block_loggers)
    return logging.getLogger(name)


if __name__ == "__main__":
    logger = get_logger(name=None, level=logging.DEBUG, log_file="logging_config_get_logger.log")
    logger.debug("调试信息")
    logger.info("普通信息")
    logger.warning("警告信息")
    logger.error("错误信息")
    logger.critical("致命错误")
    logger.info("配置日志记录器成功\n==========================\n")
