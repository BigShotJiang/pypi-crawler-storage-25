import h5py
import numpy as np
import queue
import time
import threading
import logging
from ..tools.numpy_tools import pad_and_stack

# 获取日志记录器
logger: logging.Logger = logging.getLogger(__name__)


class HDF5Logger:
    def __init__(self, file_path: str, n_channels: int, mode: str = "append"):
        """
        :param file_path: HDF5 文件路径
        :param n_channels: 通道数（例如 8）
        :param mode: 文件打开模式，"append" / "read"
        """
        self.file_path = file_path
        self.n_channels = n_channels
        self.peak_trough_fields = ["peak_x", "peak_y", "trough_x", "trough_y"]
        self.n_peak_trough_fields = 4  # 每个峰值记录的字段数：peak_x, peak_y, trough_x, trough_y
        self.peak_fields = ["peak_x", "peak_y"]
        self.n_peak_fields = 2
        self.trough_fields = ["trough_x", "trough_y"]
        self.n_trough_fields = 2
        self.lock = threading.Lock()  # 线程锁，确保线程安全
        if mode == "append":
            self.h5file = h5py.File(file_path, mode="a")  # 追加模式
        elif mode == "read":
            self.h5file = h5py.File(file_path, mode="r")  # 只读模式
        else:
            raise ValueError("mode must be 'append' or 'read'")
        self._init_file()

    def _init_file(self):
        """
        初始化或加载 HDF5 文件结构。
        注意: 数据表名的 channel 编号从 1 开始。
        """
        with self.lock:
            # --- 主数据表 ---
            if "data" not in self.h5file:
                self.h5file.create_dataset(
                    "data",
                    shape=(self.n_channels, 0),
                    maxshape=(self.n_channels, None),
                    chunks=(self.n_channels, 1000),
                    dtype="float64"
                )

            # --- 每个通道的峰值表 ---
            for ch in range(self.n_channels):
                ch_num = ch + 1
                name_list = [f"ch{ch_num}_peaks_troughs", f"ch{ch_num}_peaks", f"ch{ch_num}_troughs"]
                name_peak_trough = name_list[0]
                for name in name_list:
                    if name not in self.h5file:
                        if name == name_peak_trough:
                            num_cols = self.n_peak_trough_fields
                        else:
                            num_cols = self.n_peak_fields  # 仅 peak_x, peak_y 或 trough_x, trough_y
                        self.h5file.create_dataset(
                            name,
                            shape=(0, num_cols),
                            maxshape=(None, num_cols),
                            dtype="float64"
                        )

            # --- 文件属性 ---
            if "created" not in self.h5file.attrs:
                self.h5file.attrs["created"] = time.strftime("%Y-%m-%d %H:%M:%S")  # 创建时间

            if "peak_fields" not in self.h5file.attrs:
                self.h5file.attrs["peak_fields"] = ["peak_x", "peak_y", "trough_x", "trough_y"]  # 峰值字段名

    def _modify_file_attrs_last_update(self):
        """
        更新文件的最后修改时间属性。需要在 with self.lock 下调用。
        """
        self.h5file.attrs["last_update"] = time.strftime("%Y-%m-%d %H:%M:%S")

    def append_data(self, new_data: np.ndarray):
        """
        沿列方向追加 EEG 数据
        """
        new_data = np.asarray(new_data, dtype=float)
        if new_data.ndim == 1:
            if new_data.size % self.n_channels != 0:
                raise ValueError(
                    f"数据长度({new_data.size})不能被通道数({self.n_channels})整除"
                )
            new_data = new_data.reshape(self.n_channels, -1)

        if new_data.shape[0] != self.n_channels:
            raise ValueError(f"数据行数({new_data.shape[0]})不等于通道数({self.n_channels})")

        with self.lock:
            dset = self.h5file["data"]
            old_cols = dset.shape[1]
            new_cols = old_cols + new_data.shape[1]
            dset.resize((self.n_channels, new_cols))
            dset[:, old_cols:new_cols] = new_data
            dset.attrs["n_samples"] = new_cols
            self._modify_file_attrs_last_update()  # 更新最后修改时间
            self.h5file.flush()  # 确保数据写入磁盘
            logger.debug(f"追加数据: {new_data.shape[1]} 列")

    def append_peaks_troughs_sep(self, peak_result: list):
        """
        追加多通道峰值数据。峰值和谷值分开存储。
        说明: peak_result 列表长度应等于通道数，每个元素为该通道的峰值字典。
        """
        """
        peak_result 示例:
        [
            {"peak_x": [...], "peak_y": [...], "trough_x": [...], "trough_y": [...]},  # 通道 1
            {"peak_x": [...], "peak_y": [...], "trough_x": [...], "trough_y": [...]},  # 通道 2
            ...,
            {"peak_x": [...], "peak_y": [...], "trough_x": [...], "trough_y": [...]}   # 通道 n
        ]
        """

        with self.lock:
            num_cols = self.n_peak_fields  # 每个峰值记录的字段数：peak_x, peak_y 或 trough_x, trough_y
            for ch, peak_dict in enumerate(peak_result, start=1):
                name_list = [f"ch{ch}_peaks", f"ch{ch}_troughs"]
                name_peak = name_list[0]
                name_trough = name_list[1]
                for n, name in enumerate(name_list, 0):
                    if name not in self.h5file:
                        continue  # 跳过无效通道
                    dset = self.h5file[name]

                    # 根据名称选择数据
                    if name == name_peak:
                        # 仅取 peak_x, peak_y
                        peak_or_trough = {
                            "peak_x": peak_dict.get("peak_x", []),
                            "peak_y": peak_dict.get("peak_y", [])
                        }
                        keys = self.peak_fields
                        flag = "peak"
                    elif name == name_trough:
                        # 仅取 trough_x, trough_y
                        peak_or_trough = {
                            "trough_x": peak_dict.get("trough_x", []),
                            "trough_y": peak_dict.get("trough_y", [])
                        }
                        keys = self.trough_fields
                        flag = "trough"
                    else:
                        continue

                    # 检查峰值数据是否一一配对
                    first_len = len(peak_or_trough.get(keys[0], []))
                    if any(len(peak_or_trough.get(k, [])) != first_len for k in keys[1:]):
                        raise ValueError(
                            f"通道{ch} {flag} 数据长度不一致: "
                            + {k: len(peak_or_trough.get(k, [])) for k in keys}.__str__()
                        )

                    # 转换为二维数组，列顺序为 peak_x, peak_y, trough_x, trough_y
                    row = pad_and_stack(peak_dict=peak_or_trough, keys=keys, is_pad=False)
                    old_rows = dset.shape[0]
                    new_rows = old_rows + row.shape[0]
                    dset.resize((new_rows, num_cols))
                    dset[old_rows:new_rows] = row
                    dset.attrs["n_samples"] = new_rows
                    logger.debug(f"追加通道 {ch} {flag} 数据: {row.shape[0]} 行")
            self._modify_file_attrs_last_update()  # 更新最后修改时间
            self.h5file.flush()  # 确保数据写入磁盘

    def append_peaks(self, peak_result: list):
        """
        追加多通道峰值数据。
        说明: peak_result 列表长度应等于通道数，每个元素为该通道的峰值字典。
        """
        """
        peak_result 示例:
        [
            {"peak_x": [...], "peak_y": [...], "trough_x": [...], "trough_y": [...]},  # 通道 1
            {"peak_x": [...], "peak_y": [...], "trough_x": [...], "trough_y": [...]},  # 通道 2
            ...,
            {"peak_x": [...], "peak_y": [...], "trough_x": [...], "trough_y": [...]}   # 通道 n
        ]
        """

        with self.lock:
            for ch, peak_dict in enumerate(peak_result, start=1):
                name = f"ch{ch}_peaks_troughs"
                if name not in self.h5file:
                    continue  # 跳过无效通道
                dset = self.h5file[name]
                # 转换为二维数组，列顺序为 peak_x, peak_y, trough_x, trough_y
                row = pad_and_stack(peak_dict=peak_dict, keys=self.peak_trough_fields, is_pad=True, fill_value=np.nan)
                old_rows = dset.shape[0]
                new_rows = old_rows + row.shape[0]
                dset.resize((new_rows, self.n_peak_trough_fields))
                dset[old_rows:new_rows] = row
                dset.attrs["n_samples"] = new_rows
                logger.debug(f"追加通道 {ch} 峰值数据: {row.shape[0]} 行")
            self._modify_file_attrs_last_update()  # 更新最后修改时间
            self.h5file.flush()  # 确保数据写入磁盘

    def save_queues(self, data_queue: queue.Queue, peak_queue: queue.Queue, timeout: float = 1.0):
        """持续保存队列内容到 HDF5 文件"""
        while True:
            data_saved = peak_saved = False

            # --- 保存数据队列 ---
            try:
                data = data_queue.get(timeout=timeout)
                self.append_data(data)
                data_queue.task_done()
                data_saved = True
            except queue.Empty:
                pass

            # --- 保存峰值队列 ---
            try:
                peaks = peak_queue.get(timeout=timeout)
                self.append_peaks(peaks)
                peak_queue.task_done()
                peak_saved = True
            except queue.Empty:
                pass

            # 若两队列都空则退出
            if not data_saved and not peak_saved:
                break

    def read_dataset(self, name: str) -> np.ndarray:
        """
        读取指定数据集（如 'data', 'ch1_peaks_troughs' 等）
        :param name: 数据集名称
        :return: numpy.ndarray 数据
        """
        with self.lock:
            if name not in self.h5file:
                raise KeyError(f"Dataset '{name}' not found in {self.file_path}")

            dset = self.h5file[name]
            if dset.size == 0:
                logger.warning(f"Dataset '{name}' is empty.")
                return np.empty((0, dset.shape[1])) if len(dset.shape) > 1 else np.array([])

            data = dset[()]
            return data

    def read_main_data(self) -> np.ndarray:
        """
        读取主 EEG 数据表 (data)
        :return: np.ndarray, shape=(n_channels, n_samples)
        """
        return self.read_dataset("data")

    def read_peaks_troughs(self, channel: int) -> dict:
        """
        读取某通道的峰值、谷值和配对数据表。
        :param channel: 通道编号，从 1 开始。
        :return: dict, 包含 'peaks_troughs', 'peaks', 'troughs' 三个 numpy.ndarray
        """
        ch_num = int(channel)
        result = {}

        with self.lock:
            for name_suffix in ["peaks_troughs", "peaks", "troughs"]:
                name = f"ch{ch_num}_{name_suffix}"
                if name in self.h5file:
                    dset = self.h5file[name]
                    result[name_suffix] = dset[()]
                else:
                    result[name_suffix] = np.empty((0, self.n_peak_trough_fields if name_suffix == "peaks_troughs" else self.n_peak_fields))
        return result

    def read_all_peaks_troughs(self) -> dict:
        """
        读取所有通道的峰值与谷值数据。
        :return: dict，键为通道号，值为包含 peaks/troughs 的 dict
        """
        result = {}
        for ch in range(self.n_channels):
            ch_num = ch + 1
            ch_key = f"ch{ch_num}"
            result[ch_key] = self.read_peaks_troughs(ch_num)
        return result

    def close_file(self):
        with self.lock:
            self.h5file.close()


# === 测试示例 ===
if __name__ == "__main__":
    data_q = queue.Queue()
    peak_q = queue.Queue()

    hdf5_logger = HDF5Logger(".idea/data_saved/signal_log_multich_peak.h5", n_channels=5)

    # 模拟数据
    for i in range(3):
        data_q.put(np.random.randn(5, 20))  # 4 通道，不限列

        # 每个通道一个峰值列表
        peak_queue_result = [
            {"peak_x": [1.1, 2.1], "peak_y": [0.8, 1.0], "trough_x": [1.6, 2.6], "trough_y": [-0.6, -0.7]},
            {"peak_x": [1.2, 2.2], "peak_y": [1.1, 0.9], "trough_x": [1.7, 2.7], "trough_y": [-0.5, -0.8]},
            {"peak_x": [1.3], "peak_y": [0.7], "trough_x": [1.8], "trough_y": [-0.5]},
            {"peak_x": [1.4, 2.4], "peak_y": [1.0, 0.7], "trough_x": [1.9, 2.9], "trough_y": [-0.8, -0.9]},
            {"peak_x": [1.5, 2.5], "peak_y": [0.5, 0.9], "trough_x": [2.0, 3.0], "trough_y": [-0.4, -0.6]},
        ]
        peak_q.put(peak_queue_result)

    # 保存队列
    hdf5_logger.save_queues(data_q, peak_q)
    hdf5_logger.close_file()

    print("✅ 数据与多通道峰值保存完成 signal_log_multich_peak.h5")
