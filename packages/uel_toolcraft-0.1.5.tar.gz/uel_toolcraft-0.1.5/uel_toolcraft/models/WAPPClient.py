import os
import json
import logging
import requests
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)


class WAPPClient:
    """
    WAPPClient 用于与企业微信应用进行交互，主要功能包括获取 access_token 和发送消息。
    """
    def __init__(self, corp_id, corp_secret, agent_id, token_file="access_token.json", token_refresh_advance_seconds=1200):
        """
        初始化 WAPPClient 实例
        :param corp_id: 企业微信应用的 CorpID
        :param corp_secret: 企业微信应用的 Secret
        :param agent_id: 企业微信应用的 Agent ID
        :param token_file: 存储 access_token 的文件路径，默认为 "access_token.json"
        :param token_refresh_advance_seconds: 提前刷新 access_token 的时间，单位为秒，默认为 1200 秒（20 分钟）
        例如：如果 access_token 有效期为 7200 秒，则在剩余 600 秒时（即 10 分钟）刷新 access_token
        这样可以确保在发送消息时 access_token 不会过期。
        :return: None
        """
        self.corp_id = corp_id  # # 企业微信应用的 CorpID
        self.corp_secret = corp_secret  # 企业微信应用的 Secret
        self.agent_id = agent_id  # 企业微信应用的 Agent ID
        self.token_file = token_file  # 存储 access_token 的文件
        self.token_refresh_advance_seconds = token_refresh_advance_seconds  # 提前刷新 access_token 的时间，单位：秒
        self.access_token = None  # 用于消息发送的 access_token
        self.access_token_expires_at = None  # access_token 过期时间
        self.datetime_format = '%Y-%m-%d %H:%M:%S'  # 时间格式
        self.get_token_api = "https://qyapi.weixin.qq.com/cgi-bin/gettoken"  # 获取 access_token 的 URL
        self.send_msg_api = "https://qyapi.weixin.qq.com/cgi-bin/message/send"  # 发送消息的 URL

    # 验证 access_token 是否过期
    def _check_token(self, _access_token, _expires_at):
        """
        检查 access_token 是否过期，未过期返回 access_token, 过期返回 None
        :param _access_token: str
        :param _expires_at: str or datetime
        :return: access_token / None
        """
        if _access_token and _expires_at:
            if isinstance(_expires_at, str):
                expires_at = datetime.strptime(_expires_at, self.datetime_format)
            elif isinstance(_expires_at, datetime):
                expires_at = _expires_at
            else:
                expires_at = datetime.now()  # 如果 expires_at 格式不对，则重新赋值为现在的时间

            refresh_time = datetime.now() + timedelta(seconds=self.token_refresh_advance_seconds)
            if refresh_time < expires_at:
                # print("access_token is valid")
                return _access_token
            else:
                # print("access_token is expired")
                return None
        else:
            logger.error("Please provide both \"access_token\" and \"expires_at\" !")
            return None

    # 获取缓存的 access_token
    def _load_cached_token(self):
        """
        加载缓存的 access_token, 如果缓存文件不存在或已过期，则返回 None
        :return: str or None
        """
        if not os.path.exists(self.token_file):
            return None

        with open(self.token_file, 'r', encoding='utf-8') as f:
            try:
                data = json.load(f)
                access_token = data.get('access_token')
                expires_at = data.get('expires_at')
                access_token = self._check_token(access_token, expires_at)
                if access_token:
                    # 更新 access_token 及 过期时间 示例变量
                    self.access_token = access_token
                    self.access_token_expires_at = datetime.strptime(expires_at, self.datetime_format)
                    logger.info("Using cached access_token")
                    return access_token
            except Exception as e:
                logger.error(f"Error reading cached token: {e}")
        return None

    # 获取新的 access_token 并缓存
    def _fetch_new_token(self):
        """
        获取新的 access_token 并缓存到文件中
        :return: str, 新的 access_token
        """
        params = {
            'corpid': self.corp_id,
            'corpsecret': self.corp_secret
        }
        _response = requests.get(self.get_token_api, params=params, timeout=10)

        if _response.status_code == 200:
            data = _response.json()
            if 'access_token' in data:
                access_token = data['access_token']
                expires_in = data.get('expires_in', 7200)
                expires_at = datetime.now() + timedelta(seconds=expires_in)

                # 更新 access_token 及 过期时间 示例变量
                self.access_token = access_token
                self.access_token_expires_at = expires_at

                # 缓存 access_token 及 过期时间
                with open(self.token_file, 'w', encoding='utf-8') as f:
                    json_data = json.dumps({
                        'access_token': access_token,
                        'expires_at': expires_at.strftime(self.datetime_format)
                    }, indent=4)
                    f.write(json_data)

                logger.info("Fetched new access_token")
                return access_token
            else:
                raise Exception("access_token not found in response")
        else:
            raise Exception(f"HTTP Error {_response.status_code} while fetching token")

    # 获取 access_token (自动处理缓存和过期)
    def get_access_token(self):
        """
        获取 access_token, 优先使用缓存; 如果缓存不存在或已过期，则获取新的 access_token, 并更新缓存及实例变量
        :return: str, access_token
        """
        # 优先使用直接提供的 access_token
        if self.access_token and self.access_token_expires_at:
            _token = self._check_token(self.access_token, self.access_token_expires_at)
            if _token:
                logger.info("Using \"self\" provided access_token")
                return _token

        # 尝试从缓存中加载 access_token，如果缓存文件存在且未过期，则使用缓存的 access_token
        _token = self._load_cached_token()
        # 如果缓存文件不存在或已过期，则获取新的 access_token，并更新缓存
        if not _token:
            _token = self._fetch_new_token()

        return _token

    def send_message(self, to_user, msg_content):
        token = self.get_access_token()
        send_msg_url = f"{self.send_msg_api}?access_token={token}"

        payload = {
            "touser": to_user,
            "msgtype": "text",
            "agentid": self.agent_id,
            "text": {
                "content": msg_content
            },
            "safe": 0,
            "enable_id_trans": 0,
            "enable_duplicate_check": 0,
            "duplicate_check_interval": 1800
        }

        headers = {
            "Content-Type": "application/json"
        }

        _response = requests.post(send_msg_url, headers=headers, data=json.dumps(payload), timeout=10)
        res_json = _response.json()

        if _response.status_code == 200 and res_json.get('errcode') == 0:
            logger.info("Message sent successfully!")
        else:
            logger.error(f"Failed to send message: {res_json}")

        return res_json


if __name__ == "__main__":
    # 初始化客户端
    client = WAPPClient(
        corp_id="your_corp_id",  # 企业微信应用的 CorpID
        corp_secret="your_corp_secret",  # 企业微信应用的 Secret
        agent_id=1000002,  # 企业微信应用的 Agent ID
        token_file="access_token.json",   # 可选，默认值
        token_refresh_advance_seconds=1200  # 可选，默认提前 1200 秒刷新
    )

    # 发送消息
    response = client.send_message(
        to_user="@all",  # 发送给所有人
        msg_content=f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}: Hello, this is a test message!"
    )

    # 打印响应
    logger.info(f"Response: {response}")

