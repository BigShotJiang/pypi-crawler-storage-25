import asyncio
import logging
from threading import Thread
from PyQt6.QtCore import QObject, pyqtSignal, QCoreApplication
from PyQt6.QtWidgets import QMessageBox

# 获取日志记录器
logger: logging.Logger = logging.getLogger(__name__)


class AsyncRunner:
    """
    全局异步执行器，允许在非主线程中运行异步任务。
    使用 asyncio.run_coroutine_threadsafe 方法将协程提交到事件循环。
    通过线程安全的方式与 PyQt 信号系统交互。
    该类在初始化时创建一个新的事件循环，并在独立线程中运行该循环。
    可以通过 run_async 方法提交异步任务。
    该类适用于需要在 PyQt 应用程序中执行异步操作的场景。
    例如，可以在按钮点击事件中调用 run_async 方法来执行异步任务。
    该类的设计使得异步任务可以在后台线程中运行，而不会阻塞主线程的 UI 更新。
    通过使用 PyQt 的信号机制，可以在异步任务完成后安全地更新 UI。
    该类的使用方式如下：
    1. 创建 AsyncRunner 实例：`runner = AsyncRunner()`
    2. 定义异步任务：`async def my_async_task(): ...`
    3. 提交异步任务：`runner.run_async(my_async_task())`
    4. 在异步任务中使用 `self.signals.result_ready.emit(result)`
    来发送信号到主线程。
    5. 在主线程中连接信号：`self.signals.result_ready.connect(self.display_result)`
    6. 在 `display_result` 方法中处理结果并更新 UI。
    该类的设计使得异步任务可以在 PyQt 应用程序中安全地执行，同时保持 UI 的响应性。
    """
    def __init__(self):
        self._create_loop()
        self._logger_header = f"[AsyncRunner]"

    def _create_loop(self):
        self.loop = asyncio.new_event_loop()
        self.thread = Thread(target=self._start_loop, daemon=True)
        self.thread.start()

    def _start_loop(self):
        asyncio.set_event_loop(self.loop)
        self.loop.run_forever()

    def run_async(self, coro):
        # 如果 loop 已经挂了，重建一个
        if not self.loop.is_running() or not self.thread.is_alive():
            logger.debug(f"{self._logger_header} ⚠️ loop 已停止，重建事件循环...")
            self._create_loop()
        logger.debug(f"{self._logger_header} 当前事件循环： {id(asyncio.get_event_loop())}")
        return asyncio.run_coroutine_threadsafe(coro, self.loop)

    def stop(self):
        if self.loop.is_running():
            self.loop.call_soon_threadsafe(self.loop.stop)


class MessageBridge(QObject):
    """
    消息桥接类，用于在非主线程中显示警告消息框。
    该类继承自 QObject，并定义了一个信号 warning_signal。
    该信号在发射时会触发显示警告消息框的操作。
    使用该类可以实现线程安全的消息框显示，确保在 PyQt 应用程序中正确地显示消息框。
    该类的使用方式如下：
    1. 创建 MessageBridge 实例：`self.message_bridge = MessageBridge(parent=self)`
    2. 在非主线程中发出警告信号：`self.message_bridge.warning_signal.emit(title, text)`
    3. 该信号会在主线程中触发，显示警告消息框。
    该类的设计使得非主线程可以安全地请求显示消息框，而不会阻塞主线程的 UI 更新。
    """
    warning_signal = pyqtSignal(str, str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.warning_signal.connect(lambda title, text: QMessageBox.warning(parent, title, text))  # type: ignore


class SignalEmitter(QObject):
    """
    信号发射器类，用于在 PyQt 应用程序中发出信号。
    该类继承自 QObject，并定义了一个信号 result_ready。
    该信号可以在异步任务完成后发出结果，以便在主线程中处理。
    使用该类可以实现线程安全的信号发射，确保在 PyQt 应用程序中正确地更新 UI。
    该类的使用方式如下：
    1. 创建 SignalEmitter 实例：`self.signals = SignalEmitter()`
    2. 在异步任务中发出信号：`self.signals.result_ready.emit(result)`
    3. 在主线程中连接信号：`self.signals.result_ready.connect(self.display_result)`
    4. 在 `display_result` 方法中处理结果并更新 UI。
    该类的设计使得异步任务可以在后台线程中运行，而不会阻塞主线程的 UI 更新。
    通过使用 PyQt 的信号机制，可以在异步任务完成后安全地更新 UI。

    """
    result_ready = pyqtSignal(str)


class SignalEmitter2(QObject):
    """
    信号发射器类，用于在 PyQt 应用程序中发出信号。
    该类继承自 QObject，并定义了一个信号 result_ready。
    该信号可以在异步任务完成后发出结果，以便在主线程中处理。
    使用该类可以实现线程安全的信号发射，确保在 PyQt 应用程序中正确地更新 UI。
    该类的使用方式如下：
    1. 创建 SignalEmitter 实例：`self.signals = SignalEmitter()`
    2. 在异步任务中发出信号：`self.signals.result_ready.emit(result)`
    3. 在主线程中连接信号：`self.signals.result_ready.connect(self.display_result)`
    4. 在 `display_result` 方法中处理结果并更新 UI。
    该类的设计使得异步任务可以在后台线程中运行，而不会阻塞主线程的 UI 更新。
    通过使用 PyQt 的信号机制，可以在异步任务完成后安全地更新 UI。

    """
    result_ready = pyqtSignal(str, str)


class SignalEmitter3(QObject):
    """
    信号发射器类，用于在 PyQt 应用程序中发出信号。
    该类继承自 QObject，并定义了一个信号 result_ready。
    该信号可以在异步任务完成后发出结果，以便在主线程中处理。
    使用该类可以实现线程安全的信号发射，确保在 PyQt 应用程序中正确地更新 UI。
    该类的使用方式如下：
    1. 创建 SignalEmitter 实例：`self.signals = SignalEmitter()`
    2. 在异步任务中发出信号：`self.signals.result_ready.emit(result)`
    3. 在主线程中连接信号：`self.signals.result_ready.connect(self.display_result)`
    4. 在 `display_result` 方法中处理结果并更新 UI。
    该类的设计使得异步任务可以在后台线程中运行，而不会阻塞主线程的 UI 更新。
    通过使用 PyQt 的信号机制，可以在异步任务完成后安全地更新 UI。

    """
    result_ready = pyqtSignal(str, str, str)
