import base64
import logging
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes

# 获取日志记录器
logger: logging.Logger = logging.getLogger(__name__)


class AESCipher:
    def __init__(self, key, iv=None, mode: str = 'CBC', padding_style: str = 'pkcs7'):
        """
        初始化AES加密器

        :param key: 密钥 bytes (16/24/32字节分别对应AES-128/192/256)
        :param iv: 初始化向量 (CBC/GCM模式需要，16字节)
        :param mode: 加密模式 'CBC'/'ECB'/'GCM'
        """
        self.key = key if type(key) is bytes else key.encode('utf-8')  # 将字符串转换为字节
        self.mode_name = mode.upper()
        if self.mode_name == 'CBC':
            self.mode = AES.MODE_CBC
            if iv is None:
                raise ValueError("IV is required for CBC mode")
            self.iv = iv
        elif self.mode_name == 'ECB':
            self.mode = AES.MODE_ECB
            self.iv = None
        elif self.mode_name == 'GCM':
            self.mode = AES.MODE_GCM
            if iv is None:
                raise ValueError("IV is required for GCM mode")
            self.iv = iv
        else:
            raise ValueError(f"Unsupported AES mode: {mode}")
        if (self.iv is not None) and (type(self.iv) is str):
            self.iv = self.iv.encode('utf-8')  # 将字符串转换为字节
        self.padding_style = padding_style  # 默认填充方式

    def encrypt(self, plaintext: str) -> str:
        """
        加密数据并返回 base64 编码字符串

        :param plaintext: 原文字符串
        :return: base64加密结果
        """
        plaintext_bytes = plaintext.encode('utf-8')

        if self.mode_name in ['CBC', 'ECB']:
            padded_data = pad(plaintext_bytes, AES.block_size, style=self.padding_style)  # padding 填充
            # 创建 AES 加密器
            if self.iv:
                cipher = AES.new(self.key, self.mode, iv=self.iv)  # 忽略意外类型 "(Any, Literal[11], Any)"
            else:
                cipher = AES.new(self.key, self.mode)
            encrypted = cipher.encrypt(padded_data)  # 加密数据
        elif self.mode_name == 'GCM':
            # # GCM 模式不需要填充
            # padded_data = pad(plaintext_bytes, AES.block_size, style=self.padding_style)  # padding 填充
            cipher = AES.new(self.key, self.mode, nonce=self.iv)
            encrypted, tag = cipher.encrypt_and_digest(plaintext_bytes)  # 加密数据
            encrypted += tag  # 将tag附加到密文末尾
        else:
            raise ValueError("Unsupported encryption mode.")

        # 将加密结果转换为base64编码
        base64_encrypted = base64.b64encode(encrypted).decode('utf-8')

        return base64_encrypted

    def decrypt(self, encrypted_base64: str) -> str:
        """
        解密 base64 数据并返回原文字符串

        :param encrypted_base64: base64编码的加密数据
        :return: 解密后的原文
        """
        encrypted_bytes = base64.b64decode(encrypted_base64)

        if self.mode_name in ['CBC', 'ECB']:
            if self.iv:
                cipher = AES.new(self.key, self.mode, iv=self.iv)  # 忽略意外类型 "(Any, Literal[11], Any)"
            else:
                cipher = AES.new(self.key, self.mode)
            decrypted_padded = cipher.decrypt(encrypted_bytes)
            plaintext = unpad(decrypted_padded, AES.block_size, self.padding_style).decode('utf-8')  # 去除填充
        elif self.mode_name == 'GCM':
            cipher = AES.new(self.key, self.mode, nonce=self.iv)  # 忽略意外类型
            tag = encrypted_bytes[-AES.block_size:]
            encrypted_data = encrypted_bytes[:-AES.block_size]
            plaintext = cipher.decrypt_and_verify(encrypted_data, tag).decode('utf-8')
        else:
            raise ValueError("Unsupported decryption mode.")

        return plaintext

    @staticmethod
    def generate_key(bits: int = 128, output_format: str = "str") -> bytes|str:
        """
        生成随机AES密钥

        :param bits: 密钥长度（128/192/256）
        :param output_format: 输出格式（"bytes" 或 "str"）
        :return: 随机密钥 bytes 或 str
        """
        if bits not in [128, 192, 256]:
            raise ValueError("Key length must be 128, 192, or 256 bits.")
        # 生成随机密钥
        random_bytes = get_random_bytes(bits // 8)
        if output_format == "str":
            # 将字节转换为字符串, 使用 URL-safe base64 编码
            return base64.urlsafe_b64encode(random_bytes).decode('utf-8')
        else:
            return random_bytes
