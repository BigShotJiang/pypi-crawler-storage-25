from upstash_redis import Redis
import logging

# 获取日志记录器
logger: logging.Logger = logging.getLogger(__name__)


class RedisHelper:
    def __init__(self, api_url: str, token: str):
        """
        初始化 RedisHelper 实例并连接 Redis。
        :param api_url: Redis API URL
        :param token: Redis Token
        """
        self.redis = Redis(url=api_url, token=token)

    def get_value(self, key: str) -> str:
        """
        获取 Redis 中指定 key 对应的值。
        :param key: 键
        :return: 键对应的值
        """
        if not key:
            logger.error(f"Key '{key}' cannot be None or empty")
            raise ValueError(f"Key '{key}' cannot be None or empty")
        value = self.redis.get(key)
        if value is None:
            logger.error(f"Key '{key}' not found in Redis")
            raise KeyError(f"Key '{key}' not found in Redis")
        return value

    def get_key_value_dict(self, key_list: list) -> dict:
        """
        获取 Redis 中多个 key 对应的值，并以字典形式返回。
        :param key_list: 键的列表
        :return: 包含 key: value 的字典
        """
        result_dict = {}
        for key in key_list:
            value = self.get_value(key)
            result_dict[key] = value
        return result_dict
