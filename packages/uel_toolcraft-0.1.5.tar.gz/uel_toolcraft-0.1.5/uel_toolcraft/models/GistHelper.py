import requests


class GistHelper:
    """
    GitHub Gist helper for creating and updating gists.
    The helper returns the canonical gist page URL (``html_url``), which
    always shows the latest revision instead of a specific commit version.
    """

    def __init__(self, token, owner: str | None = None, api_base="https://api.github.com", session=None):
        if not token:
            raise ValueError("GitHub token is required")

        self.token = token
        self.owner = owner
        self.session = session or requests.Session()
        self.api_base = api_base.rstrip("/")
        self.raw_base = f"https://gist.githubusercontent.com".rstrip("/")
        self.last_gist_data = None
        self.last_gist_id = None

    def _headers(self):
        return {
            "Authorization": f"Bearer {self.token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        }

    def _gist_api_url(self, gist_id=None):
        """
        获取 GitHub gist api URL
        :param gist_id: 可选的 gist ID，如果提供则返回特定 gist 的 URL，否则返回创建 gist 的 URL
        :return: gist URL
        """
        if gist_id:
            gist_api = f"{self.api_base}/gists/{gist_id}"
        else:
            gist_api = f"{self.api_base}/gists"
        return gist_api

    @staticmethod
    def _build_files_payload(filename: str, content: str) -> dict[str, dict[str, str]]:
        """
        构建 files 字段的 payload
        :param filename: 文件名
        :param content: 文件内容
        :return: {"filename": {"content": "file content"}}
        """
        if not filename:
            raise ValueError("filename cannot be empty")
        # 创建 payload
        payload = {filename: {"content": str(content)}}
        return payload

    @staticmethod
    def _normalize_files(files_or_filename: str | dict[str, str], content=None) -> dict[str, dict[str, str]]:
        if isinstance(files_or_filename, dict) and content is None:
            if not files_or_filename:
                raise ValueError("files cannot be empty")
            return {name: {"content": str(file_content)} for name, file_content in files_or_filename.items()}

        filename = str(files_or_filename)
        if not filename:
            raise ValueError("filename cannot be empty")
        if content is None:
            raise ValueError("content cannot be empty")
        return {filename: {"content": str(content)}}

    def _update_owner(self, response_json):
        owner_info = response_json.get("owner")
        if not owner_info:
            raise ValueError("GitHub response does not contain owner information")
        self.owner = owner_info.get("login")
        return None

    def _store_latest_response(self, data):
        self.last_gist_data = data
        self.last_gist_id = data.get("id")
        if data.get("owner"):
            self._update_owner(data)

    def extract_latest_raw_link(self, gist_id, filename):
        """
        获取 gist raw link
        :param gist_id: gist ID
        :param filename: 文件名
        :return: raw link
        """
        if self.owner is None:
            raise ValueError("owner is not set; call create_gist/update_gist/get_gist first")
        raw_link = f"{self.raw_base}/{self.owner}/{gist_id}/raw/{filename}"
        return raw_link

    def create_gist(self, files_or_filename, content=None, description="", public=False):
        payload = {
            "description": description,
            "public": bool(public),
            "files": self._normalize_files(files_or_filename, content),
        }
        response = self.session.post(self._gist_api_url(), headers=self._headers(), json=payload)
        response.raise_for_status()
        data = response.json()
        self._store_latest_response(data)
        return data.get("html_url")

    def update_gist(self, gist_id, files=None, filename=None, content=None, description=None):
        if not gist_id:
            raise ValueError("gist_id is required")
        if files is None and filename is None and description is None:
            raise ValueError("files or description must be provided")

        payload = {}
        if description is not None:
            payload["description"] = description
        if files is not None:
            payload["files"] = self._normalize_files(files)
        elif filename is not None and content is not None:
            payload["files"] = self._build_files_payload(filename, content)

        response = self.session.patch(self._gist_api_url(gist_id), headers=self._headers(), json=payload)
        response.raise_for_status()
        data = response.json()

        self._store_latest_response(data)
        return data.get("html_url")

    def get_gist(self, gist_id):
        if not gist_id:
            raise ValueError("gist_id is required")

        response = self.session.get(self._gist_api_url(gist_id), headers=self._headers())
        response.raise_for_status()
        data = response.json()
        self._store_latest_response(data)
        return data

    def get_latest_link(self, gist_id):
        return self.get_gist(gist_id).get("html_url")
