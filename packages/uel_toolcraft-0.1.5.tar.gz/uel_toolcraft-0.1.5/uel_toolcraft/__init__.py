"""
uel-toolcraft — A Unified Essential Library toolcraft for personal usage.

Models: AES encryption, Bark push, Gist, HDF5 logging, PyQt async, Redis, SQLite, WeCom.
Tools: async, config, data, ffmpeg, filesystem, git, hdf5, json, pickle, rclone, serial, supabase, text, UI, utils.
"""
