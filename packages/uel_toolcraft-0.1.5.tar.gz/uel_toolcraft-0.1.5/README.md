# uel-toolcraft

A Unified Essential Library toolcraft for personal usage.

## Installation

```bash
pip install uel-toolcraft
```

Install with optional dependencies:

```bash
# Core only (explicit — same as pip install uel-toolcraft)
pip install uel-toolcraft[core]

# All optional dependencies (excludes PyQt6 — install [pyqt] separately if needed)
pip install uel-toolcraft[all]

# Specific extras
pip install uel-toolcraft[pyqt,ffmpeg,git]

# Everything including PyQt6
pip install uel-toolcraft[all,pyqt]

# NTP time sync (requires ntplib)
pip install uel-toolcraft[ntp]
```

Local development install:

```bash
git clone https://github.com/iShengren/uel-toolcraft.git
cd uel-toolcraft
uv pip install -e ".[all]"
```

---

## Usage

### Models

```python
from uel_toolcraft.models import AESCipher, SQLiteHelper, BarkClient

cipher = AESCipher("my-secret-key")
db = SQLiteHelper("mydb.sqlite")
bark = BarkClient("https://bark.example.com", "device_key")
```

### Tools

```python
from uel_toolcraft.tools import read_json_file, write_json_file, md5sum

data = read_json_file("config.json")
checksum = md5sum("large_file.bin")
write_json_file({"key": "value"}, "output.json")
```

### CLI

```bash
uel-toolcraft --version
python -m uel_toolcraft --version
```

### Time & NTP

```python
from uel_toolcraft.tools import get_current_timestamp, current_datetime_str, get_ntp_time, set_system_time

# 基础时间
ts = get_current_timestamp()          # Unix 时间戳（秒）
ts_ms = get_current_timestamp_ms()    # Unix 时间戳（毫秒）
now = current_datetime_str()          # "2026-05-22 10:37:28"

# NTP 网络时间同步
ntp_ts = get_ntp_time("pool.ntp.org") # 补偿延迟后的精确时间戳
set_system_time(int(ntp_ts * 1000))   # 同步到系统时钟（需管理员权限）
```

---

### Logging

`LogConfig` 提供彩色控制台日志 + 可选文件日志，并自动屏蔽吵杂的第三方库日志。

```python
from uel_toolcraft.models import LogConfig

LogConfig(level=logging.INFO, log_file="app.log", block_loggers=["noisy_lib_1", "noisy_lib_2"])
```

**屏蔽第三方库日志** — 在项目的 `pyproject.toml` 中配置：

```toml
[tool.uel-toolcraft.logging]
block_loggers = ["boto3", "azure.core", "googleapiclient"]
```

也可以通过参数显式传入：

```python
LogConfig(level=logging.INFO, log_file="app.log", block_loggers=["noisy_lib_1", "noisy_lib_2"])
```

合并规则：内置默认 (`httpx`, `urllib3`) + `pyproject.toml` 中的 + 参数传入的 → 三源并集自动去重。

> `get_logger` 在配置 `LogConfig` 的同时返回 `logging.Logger` 对象

---

## Optional Dependencies

| Extra | Packages | Used by |
|---|---|---|
| `core` | (none) | Explicit core-only install |
| `pyqt` | PyQt6 | `PyQtAsyncHelper`, `ui_tools` |
| `ffmpeg` | ffmpeg-python | `ffmpeg_tools` |
| `rclone` | rclone-python | `rclone_tools` |
| `supabase` | supabase | `supabase_tools` |
| `git` | GitPython | `git_tools` |
| `redis` | upstash-redis | `redis_upstash` |
| `ntp` | ntplib | `time_tools` |

---

## License

MIT
