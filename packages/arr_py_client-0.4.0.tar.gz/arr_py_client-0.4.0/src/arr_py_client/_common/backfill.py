"""Shared types and helpers for safe missing-content backfill loops.

Radarr and Sonarr both let you POST a search command — ``MoviesSearch`` /
``SeriesSearch`` / ``EpisodeSearch`` — with a list of IDs. Hammering these
endpoints in a tight loop will get you indexer-banned, so the practical
pattern (popularized by Huntarr) is: walk the list of missing items in
monitored-only mode, batch IDs, call the search command, wait, and stop
early if the download queue is already saturated.

This module hosts the brand-neutral primitives. The concrete ``backfill()``
methods on ``library`` thread in brand-specific iterators and commands.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Literal

BackfillSource = Literal["missing", "cutoff_unmet", "both"]


class BackfillStopReason(StrEnum):
    COMPLETED = "completed"
    MAX_ITEMS = "max_items"
    QUEUE_SATURATED = "queue_saturated"
    DRY_RUN = "dry_run"


@dataclass
class BackfillReport:
    """Outcome of a ``library.backfill()`` run.

    ``searched_ids`` is the ordered list of IDs passed to the search command
    across all batches. In ``dry_run`` mode it holds the IDs that *would* have
    been searched (up to ``max_items``), and ``stopped_reason`` is DRY_RUN.
    """

    source: BackfillSource
    searched_ids: list[int] = field(default_factory=list)
    batches_sent: int = 0
    stopped_reason: BackfillStopReason = BackfillStopReason.COMPLETED
    queue_checks: int = 0
    dry_run: bool = False

    @property
    def searched_count(self) -> int:
        return len(self.searched_ids)


def partition(ids: list[int], size: int) -> list[list[int]]:
    """Chunk ``ids`` into batches of at most ``size``. Never emits empty batches."""
    if size <= 0:
        msg = f"batch size must be positive, got {size}"
        raise ValueError(msg)
    return [ids[i : i + size] for i in range(0, len(ids), size)]
