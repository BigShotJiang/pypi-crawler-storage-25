"""Release-decision explainer.

"Why didn't it grab the 2160p remux?" is the single most-common question on
the Radarr/Sonarr forums. The server tells you — every release in
``/release`` comes back with ``approved``, ``rejected``, ``rejections`` (list
of human-readable reasons), ``customFormatScore``, ``qualityWeight``, and so
on. This module translates those raw fields into a structured, sorted verdict
table so callers (CLI, MCP agent, dashboard) can present a clear answer.

The rank key matches Radarr/Sonarr's own "Upgrade until CF-score" preference:
accepted-first, then custom-format-score desc, quality-weight desc, size asc.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, cast

if TYPE_CHECKING:
    from collections.abc import Sequence


def _lang_names(languages: object) -> list[str]:
    if not isinstance(languages, list):
        return []
    out: list[str] = []
    for lang in cast("list[object]", languages):
        name = getattr(lang, "name", None)
        if name is not None:
            out.append(str(name))
    return out


def _quality_name(quality_obj: object) -> str | None:
    if quality_obj is None:
        return None
    q = getattr(quality_obj, "quality", None)
    if q is None:
        return None
    return getattr(q, "name", None)


@dataclass(frozen=True)
class ReleaseVerdict:
    """One candidate release, annotated with the server's verdict."""

    title: str
    indexer: str | None
    quality: str | None
    quality_weight: int | None
    custom_format_score: int | None
    size: int | None
    seeders: int | None
    age_hours: float | None
    languages: list[str]
    release_group: str | None
    approved: bool
    rejected: bool
    rejections: list[str]
    guid: str | None
    indexer_id: int | None

    @property
    def status(self) -> str:
        """One-word verdict: ``accepted`` | ``rejected`` | ``temporarily_rejected``."""
        if self.rejected and not self.approved:
            return "rejected"
        if self.approved:
            return "accepted"
        return "temporarily_rejected"


def build_verdict(raw: object) -> ReleaseVerdict:
    """Convert a ``ReleaseResource`` (or compatible shape) to a :class:`ReleaseVerdict`."""
    rejections_raw = cast("list[object] | None", getattr(raw, "rejections", None)) or []
    rejections: list[str] = [str(r) for r in rejections_raw]
    return ReleaseVerdict(
        title=str(getattr(raw, "title", "") or ""),
        indexer=getattr(raw, "indexer", None),
        quality=_quality_name(getattr(raw, "quality", None)),
        quality_weight=getattr(raw, "quality_weight", None),
        custom_format_score=getattr(raw, "custom_format_score", None),
        size=getattr(raw, "size", None),
        seeders=getattr(raw, "seeders", None),
        age_hours=getattr(raw, "age_hours", None),
        languages=_lang_names(getattr(raw, "languages", None)),
        release_group=getattr(raw, "release_group", None),
        approved=bool(getattr(raw, "approved", False)),
        rejected=bool(getattr(raw, "rejected", False)),
        rejections=rejections,
        guid=getattr(raw, "guid", None),
        indexer_id=getattr(raw, "indexer_id", None),
    )


def _rank_key(v: ReleaseVerdict) -> tuple[int, int, int, int]:
    """Sort descending by status-acceptance, CF score, quality weight, then size asc."""
    accepted_rank = 0 if v.approved and not v.rejected else 1
    cf_score = v.custom_format_score if v.custom_format_score is not None else 0
    q_weight = v.quality_weight if v.quality_weight is not None else 0
    size = v.size if v.size is not None else 0
    return (accepted_rank, -cf_score, -q_weight, size)


@dataclass
class ReleaseExplanation:
    """Result of ``releases.explain(...)``. Human-readable and LLM-friendly."""

    item_id: int | None
    item_title: str | None
    current_quality: str | None
    current_custom_format_score: int | None
    verdicts: list[ReleaseVerdict] = field(default_factory=list)

    @property
    def accepted(self) -> list[ReleaseVerdict]:
        return [v for v in self.verdicts if v.approved and not v.rejected]

    @property
    def rejected(self) -> list[ReleaseVerdict]:
        return [v for v in self.verdicts if v.rejected and not v.approved]

    @property
    def best(self) -> ReleaseVerdict | None:
        return self.verdicts[0] if self.verdicts else None

    def summary(self) -> str:
        """A compact, English-readable summary — safe for CLI or chat output."""
        total = len(self.verdicts)
        acc = len(self.accepted)
        rej = len(self.rejected)
        lines = [
            f"{total} release candidate(s): {acc} accepted, {rej} rejected.",
        ]
        if self.current_quality is not None:
            cf = self.current_custom_format_score
            cf_suffix = f" (cf-score {cf})" if cf is not None else ""
            lines.append(f"Current file: {self.current_quality}{cf_suffix}.")
        if self.best is not None:
            top = self.best
            best_line = (
                f"Best candidate: {top.title!r} via {top.indexer or '?'}, "
                f"{top.quality or '?'}, cf-score {top.custom_format_score or 0}, "
                f"status={top.status}."
            )
            lines.append(best_line)
        rej_reasons: dict[str, int] = {}
        for v in self.rejected:
            for r in v.rejections:
                rej_reasons[r] = rej_reasons.get(r, 0) + 1
        if rej_reasons:
            top_reasons = sorted(rej_reasons.items(), key=lambda kv: -kv[1])[:3]
            lines.append(
                "Top rejection reasons: "
                + "; ".join(f"{n}x {reason}" for reason, n in top_reasons)
            )
        return " ".join(lines)


def build_explanation(
    *,
    item_id: int | None,
    item_title: str | None,
    current_quality: str | None,
    current_custom_format_score: int | None,
    raw_releases: Sequence[object],
) -> ReleaseExplanation:
    """Build a :class:`ReleaseExplanation` from a list of raw ``ReleaseResource`` objects."""
    verdicts = [build_verdict(r) for r in raw_releases]
    verdicts.sort(key=_rank_key)
    return ReleaseExplanation(
        item_id=item_id,
        item_title=item_title,
        current_quality=current_quality,
        current_custom_format_score=current_custom_format_score,
        verdicts=verdicts,
    )
