"""Build an MCP server exposing curated Radarr/Sonarr operations as tools.

Every list/get tool returns ``{"data": ..., "_meta": {fields_mode, resource[, hint]}}``.
``fields`` accepts ``"summary"`` (default for lists) | ``"all"`` (default for
single-record gets) | comma-separated subset like ``"id,title,year"``.

When ``fields="summary"``, the ``_meta.hint`` tells the calling LLM how to ask
for more — either ``fields='all'`` or via :func:`arr_describe_fields`.

Paged tools take ``limit`` (max records to return, default 20) and ``offset``
(records to skip, default 0). They return ``_meta.total`` and
``_meta.next_offset`` (``None`` when there are no more rows). ``offset`` is
rounded down to the nearest ``limit`` boundary because the upstream API is
page-based.
"""

# pyright: reportUnusedFunction=false, reportUnknownMemberType=false

from __future__ import annotations

from dataclasses import asdict
from typing import TYPE_CHECKING, Any, Literal, Protocol

from mcp.server.fastmcp import FastMCP

from arr_py_client import AsyncRadarrClient, AsyncSonarrClient
from arr_py_client._common.pagination import align_offset_to_page
from arr_py_client.mcp.projection import (
    RESOURCE_REGISTRY,
    describe,
    envelope,
    project,
)

if TYPE_CHECKING:
    from collections.abc import Awaitable

    from arr_py_client.radarr.v3.client import AsyncRadarrClientV3
    from arr_py_client.sonarr.v3.client import AsyncSonarrClientV3


class _Paging(Protocol):
    records: list[Any] | None
    total_records: int | None


def _wrap(
    value: Any,
    *,
    fields: str,
    resource: str,
    hints: list[str] | None = None,
) -> dict[str, Any]:
    """Project + envelope shorthand.

    When ``hints`` is non-empty, they're attached as
    ``_meta.action_hints`` — strings the calling LLM can evaluate as its
    next most-likely tool calls.
    """
    out = envelope(project(value, fields), fields=fields, resource=resource)
    if hints:
        out["_meta"]["action_hints"] = list(hints)
    return out


def _paged_wrap(
    records: list[Any],
    *,
    total: int | None,
    offset: int,
    limit: int,
    fields: str,
    resource: str,
) -> dict[str, Any]:
    """Wrap a page of records with pagination metadata in ``_meta``.

    ``next_offset`` is ``None`` when the cursor has reached the end of the
    collection. ``total`` may be ``None`` if upstream did not report it.
    """
    out = _wrap(records, fields=fields, resource=resource)
    out["_meta"]["total"] = total
    out["_meta"]["offset"] = offset
    out["_meta"]["limit"] = limit
    end = offset + len(records)
    has_more = total is not None and end < total
    out["_meta"]["next_offset"] = end if has_more else None
    return out


async def _run_paged(
    paging_awaitable: Awaitable[_Paging],
    *,
    aligned: int,
    size: int,
    fields: str,
    resource: str,
) -> dict[str, Any]:
    """Await a paging call and wrap the result with pagination metadata."""
    paging = await paging_awaitable
    records = list(paging.records or [])
    return _paged_wrap(
        records,
        total=paging.total_records,
        offset=aligned,
        limit=size,
        fields=fields,
        resource=resource,
    )


def _release_body(models: Any, **fields: Any) -> Any:
    """Build a validated ``ReleaseResource`` from flat kwargs.

    ``models`` is the brand-specific generated ``models`` module; the field
    names follow the upstream camelCase schema.
    """
    return models.ReleaseResource.model_validate(fields)


def _attach_radarr_tools(server: FastMCP, client: AsyncRadarrClientV3) -> None:
    @server.tool()
    async def radarr_ping() -> dict[str, Any]:
        """Verify Radarr is reachable. Returns ``{"ok": true}`` on success."""
        await client.ping()
        return {"ok": True}

    @server.tool()
    async def radarr_system_status(fields: str = "summary") -> dict[str, Any]:
        """Get Radarr system status. ``fields``: ``summary`` | ``all`` | comma-list."""
        return _wrap(
            await client.system.list_status(), fields=fields, resource="radarr.system"
        )

    @server.tool()
    async def radarr_movies_list(fields: str = "summary") -> dict[str, Any]:
        """List every movie. ``fields``: ``summary`` | ``all`` | comma-list."""
        return _wrap(await client.movies.list(), fields=fields, resource="radarr.movie")

    @server.tool()
    async def radarr_movies_get(movie_id: int, fields: str = "all") -> dict[str, Any]:
        """Get one Radarr movie by id. ``fields`` defaults to ``all``."""
        return _wrap(
            await client.movies.get(id=movie_id),
            fields=fields,
            resource="radarr.movie",
            hints=[
                "arr_find_release(title=..., app='radarr')",
                f"radarr_command_post(name='MoviesSearch', body={{'movieIds':[{movie_id}]}})",
            ],
        )

    @server.tool()
    async def radarr_movies_lookup(
        term: str, fields: str = "summary"
    ) -> dict[str, Any]:
        """Search TMDB via Radarr's lookup proxy."""
        return _wrap(
            await client.movies.lookup(term=term),
            fields=fields,
            resource="radarr.movie",
        )

    @server.tool()
    async def radarr_queue_list(
        limit: int = 20, offset: int = 0, fields: str = "summary"
    ) -> dict[str, Any]:
        """One page of the Radarr queue. ``offset`` is page-boundary aligned."""
        page, size, aligned = align_offset_to_page(offset, limit)
        result = await _run_paged(
            client.queue.list(page=page, page_size=size),
            aligned=aligned,
            size=size,
            fields=fields,
            resource="radarr.queue",
        )
        result["_meta"]["action_hints"] = [
            "arr_cleanup_queue(app='radarr', dry_run=True)",
            "radarr_blocklist_list()",
        ]
        return result

    @server.tool()
    async def radarr_history_list(
        limit: int = 20, offset: int = 0, fields: str = "summary"
    ) -> dict[str, Any]:
        """One page of Radarr history. ``offset`` is page-boundary aligned."""
        page, size, aligned = align_offset_to_page(offset, limit)
        return await _run_paged(
            client.history.list(page=page, page_size=size),
            aligned=aligned,
            size=size,
            fields=fields,
            resource="radarr.history",
        )

    @server.tool()
    async def radarr_command_post(
        name: str, body: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """Send a Radarr command (e.g. ``"MoviesSearch"``, ``"RefreshMovie"``)."""
        result = await client.commands.post(name=name, **(body or {}))
        return _wrap(result, fields="all", resource="radarr.command")

    @server.tool()
    async def radarr_tags_list(fields: str = "summary") -> dict[str, Any]:
        """List Radarr tags."""
        return _wrap(await client.tags.list(), fields=fields, resource="radarr.tag")

    @server.tool()
    async def radarr_blocklist_list(
        limit: int = 20, offset: int = 0, fields: str = "summary"
    ) -> dict[str, Any]:
        """One page of Radarr's blocklist."""
        page, size, aligned = align_offset_to_page(offset, limit)
        return await _run_paged(
            client.blocklist.list_(page=page, page_size=size),
            aligned=aligned,
            size=size,
            fields=fields,
            resource="radarr.blocklist",
        )

    @server.tool()
    async def radarr_blocklist_delete(blocklist_id: int) -> dict[str, Any]:
        """Remove a single blocklist entry."""
        await client.blocklist.delete_by_id(blocklist_id)
        return {"ok": True}

    @server.tool()
    async def radarr_log_list(
        limit: int = 20,
        offset: int = 0,
        level: str | None = None,
        fields: str = "summary",
    ) -> dict[str, Any]:
        """One page of Radarr's system log. ``level``: ``Info|Warn|Error|Fatal|Debug|Trace``."""
        page, size, aligned = align_offset_to_page(offset, limit)
        return await _run_paged(
            client.log.list_(page=page, page_size=size, level=level),
            aligned=aligned,
            size=size,
            fields=fields,
            resource="radarr.log",
        )

    @server.tool()
    async def radarr_backup_list(fields: str = "summary") -> dict[str, Any]:
        """List Radarr backups."""
        return _wrap(
            await client.backup.list_(), fields=fields, resource="radarr.backup"
        )

    @server.tool()
    async def radarr_backup_restore(backup_id: int) -> dict[str, Any]:
        """Restore a Radarr backup by id (Radarr will restart)."""
        await client.backup.post_restore_by_id(backup_id)
        return {"ok": True}

    @server.tool()
    async def radarr_manual_import_list(
        folder: str | None = None,
        download_id: str | None = None,
        movie_id: int | None = None,
        filter_existing_files: bool | None = None,
        fields: str = "summary",
    ) -> dict[str, Any]:
        """Inspect importable files. Pass ``folder`` *or* ``download_id``."""
        result = await client.manual_import.list_(
            folder=folder,
            download_id=download_id,
            movie_id=movie_id,
            filter_existing_files=filter_existing_files,
        )
        return _wrap(result, fields=fields, resource="radarr.manual_import")

    @server.tool()
    async def radarr_rename_list(
        movie_ids: list[int] | None = None, fields: str = "summary"
    ) -> dict[str, Any]:
        """Preview rename suggestions for given movies (``None`` = entire library)."""
        result = await client.rename_movie.list_(movie_id=movie_ids)
        return _wrap(result, fields=fields, resource="radarr.rename")

    @server.tool()
    async def radarr_release_push(
        title: str,
        download_url: str,
        protocol: str = "torrent",
        publish_date: str | None = None,
        size: int | None = None,
        indexer: str | None = None,
        fields: str = "summary",
    ) -> dict[str, Any]:
        """Push a release to Radarr's grabber. ``protocol``: ``torrent`` or ``usenet``."""
        from arr_py_client.radarr.v3._generated import models as r_models

        body = _release_body(
            r_models,
            title=title,
            downloadUrl=download_url,
            protocol=protocol,
            publishDate=publish_date,
            size=size,
            indexer=indexer,
        )
        return _wrap(
            await client.release_push.create(body=body),
            fields=fields,
            resource="radarr.release",
        )

    @server.tool()
    async def radarr_download_clients_list(fields: str = "summary") -> dict[str, Any]:
        """List configured Radarr download clients."""
        return _wrap(
            await client.download_clients.list(),
            fields=fields,
            resource="radarr.download_client",
        )


def _attach_sonarr_tools(server: FastMCP, client: AsyncSonarrClientV3) -> None:
    @server.tool()
    async def sonarr_ping() -> dict[str, Any]:
        """Verify Sonarr is reachable."""
        await client.ping()
        return {"ok": True}

    @server.tool()
    async def sonarr_system_status(fields: str = "summary") -> dict[str, Any]:
        """Sonarr system status."""
        return _wrap(
            await client.system.list_status(), fields=fields, resource="sonarr.system"
        )

    @server.tool()
    async def sonarr_series_list(fields: str = "summary") -> dict[str, Any]:
        """List every series."""
        return _wrap(
            await client.series.list(), fields=fields, resource="sonarr.series"
        )

    @server.tool()
    async def sonarr_series_get(series_id: int, fields: str = "all") -> dict[str, Any]:
        """Get one series by id."""
        return _wrap(
            await client.series.get(id=series_id),
            fields=fields,
            resource="sonarr.series",
            hints=[
                f"sonarr_episodes_list(series_id={series_id})",
                "arr_find_release(title=..., app='sonarr')",
            ],
        )

    @server.tool()
    async def sonarr_series_lookup(
        term: str, fields: str = "summary"
    ) -> dict[str, Any]:
        """Search TVDB via Sonarr's lookup proxy."""
        return _wrap(
            await client.series.lookup(term=term),
            fields=fields,
            resource="sonarr.series",
        )

    @server.tool()
    async def sonarr_episodes_list(
        series_id: int, fields: str = "summary"
    ) -> dict[str, Any]:
        """List episodes for a series."""
        return _wrap(
            await client.episodes.list(series_id=series_id),
            fields=fields,
            resource="sonarr.episode",
        )

    @server.tool()
    async def sonarr_queue_list(
        limit: int = 20, offset: int = 0, fields: str = "summary"
    ) -> dict[str, Any]:
        """One page of the Sonarr queue. ``offset`` is page-boundary aligned."""
        page, size, aligned = align_offset_to_page(offset, limit)
        result = await _run_paged(
            client.queue.list(page=page, page_size=size),
            aligned=aligned,
            size=size,
            fields=fields,
            resource="sonarr.queue",
        )
        result["_meta"]["action_hints"] = [
            "arr_cleanup_queue(app='sonarr', dry_run=True)",
            "sonarr_blocklist_list()",
        ]
        return result

    @server.tool()
    async def sonarr_history_list(
        limit: int = 20, offset: int = 0, fields: str = "summary"
    ) -> dict[str, Any]:
        """One page of Sonarr history. ``offset`` is page-boundary aligned."""
        page, size, aligned = align_offset_to_page(offset, limit)
        return await _run_paged(
            client.history.list(page=page, page_size=size),
            aligned=aligned,
            size=size,
            fields=fields,
            resource="sonarr.history",
        )

    @server.tool()
    async def sonarr_command_post(
        name: str, body: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """Send a Sonarr command."""
        result = await client.commands.post(name=name, **(body or {}))
        return _wrap(result, fields="all", resource="sonarr.command")

    @server.tool()
    async def sonarr_blocklist_list(
        limit: int = 20, offset: int = 0, fields: str = "summary"
    ) -> dict[str, Any]:
        """One page of Sonarr's blocklist."""
        page, size, aligned = align_offset_to_page(offset, limit)
        return await _run_paged(
            client.blocklist.list_(page=page, page_size=size),
            aligned=aligned,
            size=size,
            fields=fields,
            resource="sonarr.blocklist",
        )

    @server.tool()
    async def sonarr_log_list(
        limit: int = 20,
        offset: int = 0,
        level: str | None = None,
        fields: str = "summary",
    ) -> dict[str, Any]:
        """One page of Sonarr's system log."""
        page, size, aligned = align_offset_to_page(offset, limit)
        return await _run_paged(
            client.log.list_(page=page, page_size=size, level=level),
            aligned=aligned,
            size=size,
            fields=fields,
            resource="sonarr.log",
        )

    @server.tool()
    async def sonarr_backup_list(fields: str = "summary") -> dict[str, Any]:
        """List Sonarr backups."""
        return _wrap(
            await client.backup.list_(), fields=fields, resource="sonarr.backup"
        )

    @server.tool()
    async def sonarr_backup_restore(backup_id: int) -> dict[str, Any]:
        """Restore a Sonarr backup by id (Sonarr will restart)."""
        await client.backup.post_restore_by_id(backup_id)
        return {"ok": True}

    @server.tool()
    async def sonarr_manual_import_list(
        folder: str | None = None,
        download_id: str | None = None,
        series_id: int | None = None,
        filter_existing_files: bool | None = None,
        fields: str = "summary",
    ) -> dict[str, Any]:
        """Inspect importable files. Pass ``folder`` *or* ``download_id``."""
        result = await client.manual_import.list_(
            folder=folder,
            download_id=download_id,
            series_id=series_id,
            filter_existing_files=filter_existing_files,
        )
        return _wrap(result, fields=fields, resource="sonarr.manual_import")

    @server.tool()
    async def sonarr_rename_list(
        series_id: int, season_number: int | None = None, fields: str = "summary"
    ) -> dict[str, Any]:
        """Preview rename suggestions for a series."""
        result = await client.rename_episode.list_(
            series_id=series_id, season_number=season_number
        )
        return _wrap(result, fields=fields, resource="sonarr.rename")

    @server.tool()
    async def sonarr_release_push(
        title: str,
        download_url: str,
        protocol: str = "torrent",
        publish_date: str | None = None,
        size: int | None = None,
        indexer: str | None = None,
        fields: str = "summary",
    ) -> dict[str, Any]:
        """Push a release to Sonarr's grabber."""
        from arr_py_client.sonarr.v3._generated import models as s_models

        body = _release_body(
            s_models,
            title=title,
            downloadUrl=download_url,
            protocol=protocol,
            publishDate=publish_date,
            size=size,
            indexer=indexer,
        )
        return _wrap(
            await client.release_push.create(body=body),
            fields=fields,
            resource="sonarr.release",
        )

    @server.tool()
    async def sonarr_download_clients_list(fields: str = "summary") -> dict[str, Any]:
        """List configured Sonarr download clients."""
        return _wrap(
            await client.download_clients.list(),
            fields=fields,
            resource="sonarr.download_client",
        )


def _library_health_dict(summary: Any) -> dict[str, Any]:
    """Flatten a ``LibraryHealth`` into a JSON-ready dict for MCP payloads."""
    out = asdict(summary)
    # Flatten dataclass nested fields so LLMs don't have to navigate a tree.
    out["disks"] = [
        {
            **d,
            "free_percent": (
                round(100.0 * d["free_bytes"] / d["total_bytes"], 2)
                if d.get("free_bytes") is not None
                and d.get("total_bytes")
                and d["total_bytes"] > 0
                else None
            ),
        }
        for d in out.get("disks", [])
    ]
    return out


def _attach_composed_tools(
    server: FastMCP,
    *,
    radarr: AsyncRadarrClientV3 | None,
    sonarr: AsyncSonarrClientV3 | None,
) -> None:
    """Register the high-level, chat-friendly composed tools.

    These collapse multi-step workflows into one tool call and return
    structured payloads with ``_meta.action_hints`` — the next most useful
    tool calls from here — so LLMs can chain operations without guessing.
    """

    @server.tool()
    async def arr_add(
        title: str,
        app: Literal["auto", "radarr", "sonarr"] = "auto",
        quality: str | None = None,
        folder: str | None = None,
        tags: list[str] | None = None,
        monitored: bool = True,
        search_on_add: bool = True,
        if_exists: Literal["skip", "update", "error"] = "skip",
    ) -> dict[str, Any]:
        """Add a movie or series to Radarr/Sonarr by title, with name-based options.

        ``app="auto"`` uses whichever brand's lookup returns a match (Radarr
        first). ``quality`` accepts a profile name like ``"HD-1080p"`` or
        ``"4K-HDR"``. ``folder`` is a root-folder path; if omitted and only
        one is configured, it's auto-picked. ``tags`` accepts labels; missing
        ones are created. ``if_exists`` defaults to ``"skip"`` for chat safety
        — re-running the tool won't 409.
        """
        chosen_app: str | None = None
        resource: dict[str, Any] | None = None
        already_existed = False

        async def try_radarr() -> tuple[bool, dict[str, Any] | None]:
            if radarr is None:
                return False, None
            results = await radarr.movies.lookup(term=title)
            if not results:
                return False, None
            movie = await radarr.movies.add(
                title=title,
                quality=quality,
                root_folder=folder,
                tags=list(tags) if tags is not None else None,
                monitored=monitored,
                search_on_add=search_on_add,
                if_exists=if_exists,
            )
            return True, project(movie, "all")

        async def try_sonarr() -> tuple[bool, dict[str, Any] | None]:
            if sonarr is None:
                return False, None
            results = await sonarr.series.lookup(term=title)
            if not results:
                return False, None
            series = await sonarr.series.add(
                title=title,
                quality=quality,
                root_folder=folder,
                tags=list(tags) if tags is not None else None,
                monitored=monitored,
                search_on_add=search_on_add,
                if_exists=if_exists,
            )
            return True, project(series, "all")

        attempts: list[tuple[str, Any]] = []
        if app in ("auto", "radarr"):
            attempts.append(("radarr", try_radarr))
        if app in ("auto", "sonarr"):
            attempts.append(("sonarr", try_sonarr))

        errors: list[str] = []
        for brand, fn in attempts:
            try:
                hit, data = await fn()
            except Exception as exc:
                errors.append(f"{brand}: {exc}")
                continue
            if hit:
                chosen_app = brand
                resource = data
                # ``if_exists='skip'`` doesn't expose whether the row was new;
                # callers can compare ``resource.id`` against prior state.
                break

        if chosen_app is None:
            return {
                "ok": False,
                "error": f"no lookup match for {title!r}",
                "errors": errors,
                "_meta": {
                    "action_hints": [
                        "arr_list_resources()",
                        "radarr_movies_lookup(term=...)",
                        "sonarr_series_lookup(term=...)",
                    ]
                },
            }

        return {
            "ok": True,
            "app": chosen_app,
            "already_existed": already_existed,
            "data": resource,
            "_meta": {
                "action_hints": [
                    f"{chosen_app}_command_post(name='RescanMovie' | 'RescanSeries')",
                    "arr_health()",
                ],
            },
        }

    @server.tool()
    async def arr_health(
        app: Literal["both", "radarr", "sonarr"] = "both",
    ) -> dict[str, Any]:
        """One-shot library health: version, disks, queue, warnings, library count.

        Fans out to 5 endpoints per brand in parallel. Partial failures are
        surfaced in each brand's ``errors`` field rather than raised.
        """
        out: dict[str, Any] = {}
        hints: list[str] = []
        if app in ("both", "radarr") and radarr is not None:
            summary = await radarr.library.health_summary()
            out["radarr"] = _library_health_dict(summary)
            if summary.queue.stalled > 0:
                hints.append("arr_cleanup_queue(app='radarr', dry_run=True)")
            if not summary.healthy:
                hints.append("radarr_system_status(fields='all')")
        if app in ("both", "sonarr") and sonarr is not None:
            summary = await sonarr.library.health_summary()
            out["sonarr"] = _library_health_dict(summary)
            if summary.queue.stalled > 0:
                hints.append("arr_cleanup_queue(app='sonarr', dry_run=True)")
            if not summary.healthy:
                hints.append("sonarr_system_status(fields='all')")
        out["_meta"] = {"action_hints": hints}
        return out

    @server.tool()
    async def arr_upcoming(
        days: int = 7,
        app: Literal["both", "radarr", "sonarr"] = "both",
    ) -> dict[str, Any]:
        """Upcoming (or recently aired) calendar items across one or both apps.

        ``days > 0`` returns things airing in the next N days; ``days < 0``
        returns things that aired in the last |N| days. Pulls via the
        ``/calendar`` endpoint with brand-specific filters.
        """
        from datetime import UTC, datetime, timedelta

        now = datetime.now(UTC)
        start = now if days > 0 else now + timedelta(days=days)
        end = now + timedelta(days=days) if days > 0 else now
        items: dict[str, Any] = {}
        if app in ("both", "radarr") and radarr is not None:
            radarr_items = await radarr.calendar.list(start=start, end=end)
            items["radarr"] = [project(m, "summary") for m in radarr_items]
        if app in ("both", "sonarr") and sonarr is not None:
            sonarr_items = await sonarr.calendar.list(start=start, end=end)
            items["sonarr"] = [project(e, "summary") for e in sonarr_items]
        return {
            "data": items,
            "_meta": {
                "window_days": days,
                "action_hints": [
                    "arr_health()",
                    "arr_find_release(title=..., app=...)",
                ],
            },
        }

    @server.tool()
    async def arr_find_release(
        title: str,
        app: Literal["radarr", "sonarr"],
        min_seeders: int | None = None,
        prefer_codec: str | None = None,
        limit: int = 10,
    ) -> dict[str, Any]:
        """Look up a title, then query indexers for candidate releases.

        Resolves ``title`` → library id via the app's lookup, then calls
        ``releases.search()`` and returns up to ``limit`` candidates sorted by
        (seeders desc, quality desc, codec match, size asc). Pass ``guid`` +
        ``indexer_id`` from a candidate to :func:`arr_grab_release`.
        """
        if app == "radarr":
            if radarr is None:
                return {"ok": False, "error": "radarr not configured"}
            hits = await radarr.movies.lookup(term=title)
            if not hits or not hits[0].tmdb_id:
                return {"ok": False, "error": f"no movie lookup match for {title!r}"}
            resolved = await radarr.movies.list()
            target = next(
                (m for m in resolved if m.tmdb_id == hits[0].tmdb_id and m.id),
                None,
            )
            if target is None or target.id is None:
                return {
                    "ok": False,
                    "error": "movie not in library; add it first via arr_add(...)",
                }
            candidates = await radarr.releases.search(movie_id=target.id)
        else:
            if sonarr is None:
                return {"ok": False, "error": "sonarr not configured"}
            hits_s = await sonarr.series.lookup(term=title)
            if not hits_s or not hits_s[0].tvdb_id:
                return {"ok": False, "error": f"no series lookup match for {title!r}"}
            resolved_s = await sonarr.series.list()
            target_s = next(
                (s for s in resolved_s if s.tvdb_id == hits_s[0].tvdb_id and s.id),
                None,
            )
            if target_s is None or target_s.id is None:
                return {
                    "ok": False,
                    "error": "series not in library; add it first via arr_add(...)",
                }
            candidates = await sonarr.releases.search(series_id=target_s.id)

        if min_seeders is not None:
            candidates = [
                c
                for c in candidates
                if (getattr(c, "seeders", None) or 0) >= min_seeders
            ]

        def _k(r: Any) -> tuple[int, int, int]:
            seeders = int(getattr(r, "seeders", None) or 0)
            title_str = str(getattr(r, "title", "") or "").lower()
            codec = 1 if prefer_codec and prefer_codec.lower() in title_str else 0
            size = int(getattr(r, "size", None) or 0)
            return (-seeders, -codec, size)

        candidates.sort(key=_k)
        trimmed = candidates[:limit]
        return {
            "ok": True,
            "app": app,
            "candidates": [project(c, "summary") for c in trimmed],
            "_meta": {
                "count": len(trimmed),
                "action_hints": [
                    "arr_grab_release(guid=..., indexer_id=..., app=...)",
                ],
            },
        }

    @server.tool()
    async def arr_grab_release(
        guid: str,
        indexer_id: int,
        app: Literal["radarr", "sonarr"],
    ) -> dict[str, Any]:
        """Grab a specific release from :func:`arr_find_release`'s candidates.

        The release lands in the queue; poll via ``radarr_queue_list`` /
        ``sonarr_queue_list`` to track import progress.
        """
        if app == "radarr":
            if radarr is None:
                return {"ok": False, "error": "radarr not configured"}
            await radarr.releases.grab(guid=guid, indexer_id=indexer_id)
        else:
            if sonarr is None:
                return {"ok": False, "error": "sonarr not configured"}
            await sonarr.releases.grab(guid=guid, indexer_id=indexer_id)
        return {
            "ok": True,
            "app": app,
            "_meta": {
                "action_hints": [
                    f"{app}_queue_list()",
                    "arr_health()",
                ]
            },
        }

    @server.tool()
    async def arr_cleanup_queue(
        app: Literal["radarr", "sonarr"],
        dry_run: bool = True,
        blocklist: bool = True,
        search: bool = True,
    ) -> dict[str, Any]:
        """Find stuck downloads and (optionally) nuke + blocklist + re-search.

        **Defaults to ``dry_run=True``** for chat safety. Re-invoke with
        ``dry_run=False`` once the user confirms the plan.
        """
        if app == "radarr":
            if radarr is None:
                return {"ok": False, "error": "radarr not configured"}
            result = await radarr.queue.clear_stuck(
                blocklist=blocklist, search=search, dry_run=dry_run
            )
        else:
            if sonarr is None:
                return {"ok": False, "error": "sonarr not configured"}
            result = await sonarr.queue.clear_stuck(
                blocklist=blocklist, search=search, dry_run=dry_run
            )
        hints: list[str] = []
        if dry_run and result.ids:
            hints.append(
                f"arr_cleanup_queue(app={app!r}, dry_run=False) — rerun to actually remove"
            )
        if not result.ids:
            hints.append("arr_health()")
        return {
            "ok": True,
            "app": app,
            "dry_run": result.dry_run,
            "ids": result.ids,
            "count": len(result.ids),
            "blocklisted": result.blocklisted,
            "redownload": result.redownload,
            "_meta": {"action_hints": hints},
        }

    @server.tool()
    async def arr_janitor_run(
        app: Literal["radarr", "sonarr"],
        dry_run: bool = True,
        protected_trackers: list[str] | None = None,
    ) -> dict[str, Any]:
        """Policy-based queue cleanup. More flexible than :func:`arr_cleanup_queue`.

        Runs the default policy bundle (manual-interaction → ignore,
        import-blocked → blocklist+research, stalled-6h → blocklist+research,
        generic stuck → blocklist+research). Items on ``protected_trackers``
        are downgraded to IGNORE so private indexers aren't churned.

        **Defaults to ``dry_run=True``** for chat safety.
        """
        protected = tuple(protected_trackers or ())
        if app == "radarr":
            if radarr is None:
                return {"ok": False, "error": "radarr not configured"}
            report = await radarr.queue.janitor(
                dry_run=dry_run, protected_trackers=protected
            )
        else:
            if sonarr is None:
                return {"ok": False, "error": "sonarr not configured"}
            report = await sonarr.queue.janitor(
                dry_run=dry_run, protected_trackers=protected
            )
        hints: list[str] = []
        if dry_run and report.total_matches:
            hints.append(
                f"arr_janitor_run(app={app!r}, dry_run=False) — rerun to execute"
            )
        if not report.total_matches:
            hints.append("arr_health()")
        return {
            "ok": True,
            "app": app,
            "dry_run": report.dry_run,
            "total_matches": report.total_matches,
            "protected_skips": report.protected_skips,
            "executed_blocklist_ids": report.executed_blocklist_ids,
            "executed_remove_ids": report.executed_remove_ids,
            "matches": [
                {
                    "id": m.item_id,
                    "title": m.item_title,
                    "policy": m.policy_name,
                    "action": m.action.value,
                    "indexer": m.indexer,
                }
                for m in report.matches
            ],
            "_meta": {"action_hints": hints},
        }

    @server.tool()
    async def arr_explain_grab(
        title: str,
        app: Literal["radarr", "sonarr"],
        episode_id: int | None = None,
        season_number: int | None = None,
    ) -> dict[str, Any]:
        """Answer "why didn't it grab the better version?" for a library item.

        Resolves ``title`` → library id, fetches all current indexer releases,
        annotates each with accept/reject + reasons, and returns a ranked
        table plus a human-readable ``summary``. For Sonarr, pass
        ``episode_id`` or ``season_number`` to scope the explanation.
        """
        if app == "radarr":
            if radarr is None:
                return {"ok": False, "error": "radarr not configured"}
            hits = await radarr.movies.lookup(term=title)
            if not hits or not hits[0].tmdb_id:
                return {"ok": False, "error": f"no movie lookup match for {title!r}"}
            resolved = await radarr.movies.list()
            target = next(
                (m for m in resolved if m.tmdb_id == hits[0].tmdb_id and m.id),
                None,
            )
            if target is None or target.id is None:
                return {
                    "ok": False,
                    "error": "movie not in library; add it first via arr_add(...)",
                }
            explanation = await radarr.releases.explain(movie_id=target.id)
        else:
            if sonarr is None:
                return {"ok": False, "error": "sonarr not configured"}
            hits_s = await sonarr.series.lookup(term=title)
            if not hits_s or not hits_s[0].tvdb_id:
                return {"ok": False, "error": f"no series lookup match for {title!r}"}
            resolved_s = await sonarr.series.list()
            target_s = next(
                (s for s in resolved_s if s.tvdb_id == hits_s[0].tvdb_id and s.id),
                None,
            )
            if target_s is None or target_s.id is None:
                return {
                    "ok": False,
                    "error": "series not in library; add it first via arr_add(...)",
                }
            explanation = await sonarr.releases.explain(
                series_id=target_s.id,
                episode_id=episode_id,
                season_number=season_number,
            )
        hints = (
            [f"arr_grab_release(guid=..., indexer_id=..., app={app!r})"]
            if explanation.accepted
            else ["arr_health()"]
        )
        return {
            "ok": True,
            "app": app,
            "item_id": explanation.item_id,
            "item_title": explanation.item_title,
            "current_quality": explanation.current_quality,
            "current_custom_format_score": explanation.current_custom_format_score,
            "summary": explanation.summary(),
            "verdicts": [
                {
                    "title": v.title,
                    "indexer": v.indexer,
                    "quality": v.quality,
                    "quality_weight": v.quality_weight,
                    "custom_format_score": v.custom_format_score,
                    "size": v.size,
                    "seeders": v.seeders,
                    "age_hours": v.age_hours,
                    "languages": v.languages,
                    "release_group": v.release_group,
                    "status": v.status,
                    "rejections": v.rejections,
                    "guid": v.guid,
                    "indexer_id": v.indexer_id,
                }
                for v in explanation.verdicts
            ],
            "_meta": {
                "accepted_count": len(explanation.accepted),
                "rejected_count": len(explanation.rejected),
                "action_hints": hints,
            },
        }

    @server.tool()
    async def arr_backfill(
        app: Literal["radarr", "sonarr"],
        source: Literal["missing", "cutoff_unmet", "both"] = "missing",
        batch_size: int | None = None,
        delay_between_batches: float = 30.0,
        max_items: int | None = None,
        pause_if_queue_over: int | None = None,
        monitored_only: bool = True,
        dry_run: bool = True,
    ) -> dict[str, Any]:
        """Rate-limited safe missing-content search loop (Huntarr-shaped).

        Walks ``/wanted/missing`` (or ``/cutoff``, or both), batches IDs, and
        fires ``MoviesSearch`` (Radarr) / ``EpisodeSearch`` (Sonarr) with a
        delay between batches. ``pause_if_queue_over=N`` short-circuits when
        the download queue already has more than N items.

        **Defaults to ``dry_run=True``** for chat safety — re-invoke with
        ``dry_run=False`` to actually fire search commands. Default
        ``batch_size`` is 5 (Radarr) / 20 (Sonarr) per brand convention.
        """
        effective_batch = (
            batch_size if batch_size is not None else (5 if app == "radarr" else 20)
        )
        if app == "radarr":
            if radarr is None:
                return {"ok": False, "error": "radarr not configured"}
            report = await radarr.library.backfill(
                source=source,
                batch_size=effective_batch,
                delay_between_batches=delay_between_batches,
                max_items=max_items,
                pause_if_queue_over=pause_if_queue_over,
                monitored_only=monitored_only,
                dry_run=dry_run,
            )
        else:
            if sonarr is None:
                return {"ok": False, "error": "sonarr not configured"}
            report = await sonarr.library.backfill(
                source=source,
                batch_size=effective_batch,
                delay_between_batches=delay_between_batches,
                max_items=max_items,
                pause_if_queue_over=pause_if_queue_over,
                monitored_only=monitored_only,
                dry_run=dry_run,
            )
        hints: list[str] = []
        if dry_run and report.searched_count:
            hints.append(
                f"arr_backfill(app={app!r}, dry_run=False) — rerun to actually search"
            )
        if report.stopped_reason == "queue_saturated":
            hints.append(f"{app}_queue_list()")
        return {
            "ok": True,
            "app": app,
            "source": report.source,
            "dry_run": report.dry_run,
            "searched_count": report.searched_count,
            "batches_sent": report.batches_sent,
            "stopped_reason": report.stopped_reason.value,
            "queue_checks": report.queue_checks,
            "searched_ids": report.searched_ids,
            "_meta": {"action_hints": hints},
        }

    @server.tool()
    async def arr_sync_plan(
        app: Literal["radarr", "sonarr"],
        desired: dict[str, Any],
        strict: bool = False,
    ) -> dict[str, Any]:
        """Preview config-sync changes: diff ``desired`` against the live server.

        ``desired`` keys (all optional): ``tags`` (list of names),
        ``custom_formats`` (map name → spec), ``quality_profiles`` (map name
        → profile). ``strict=True`` adds DELETE actions for items on the
        server but not in ``desired`` — always preview before applying.

        Returns a list of planned actions with no mutations. Pair with
        :func:`arr_sync_apply` to execute.
        """
        from arr_py_client.config_sync import plan_async as _plan_async

        client = radarr if app == "radarr" else sonarr
        if client is None:
            return {"ok": False, "error": f"{app} not configured"}
        plan_ = await _plan_async(client, desired, strict=strict)
        hints: list[str] = []
        if plan_.changes:
            hints.append(f"arr_sync_apply(app={app!r}, desired=..., dry_run=False)")
        else:
            hints.append("arr_health()")
        return {
            "ok": True,
            "app": app,
            "strict": plan_.strict,
            "is_noop": plan_.is_noop,
            "summary": plan_.summary(),
            "changes": [
                {
                    "resource": c.resource,
                    "name": c.name,
                    "action": c.action,
                    "existing_id": c.existing_id,
                    "detail": c.detail,
                }
                for c in plan_.changes
            ],
            "_meta": {"action_hints": hints},
        }

    @server.tool()
    async def arr_sync_apply(
        app: Literal["radarr", "sonarr"],
        desired: dict[str, Any],
        strict: bool = False,
        dry_run: bool = True,
    ) -> dict[str, Any]:
        """Plan + apply a config-sync desired state. **Defaults to ``dry_run=True``.**

        Runs :func:`arr_sync_plan` internally, then applies every change
        (unless ``dry_run``). Per-change errors are captured in the report
        rather than aborting — one broken custom-format doesn't block the
        others.
        """
        from arr_py_client.config_sync import apply_async as _apply_async
        from arr_py_client.config_sync import plan_async as _plan_async

        client = radarr if app == "radarr" else sonarr
        if client is None:
            return {"ok": False, "error": f"{app} not configured"}
        plan_ = await _plan_async(client, desired, strict=strict)
        report = await _apply_async(client, plan_, dry_run=dry_run)
        hints: list[str] = []
        if dry_run and plan_.changes:
            hints.append(
                f"arr_sync_apply(app={app!r}, desired=..., dry_run=False) — rerun to execute"
            )
        if report.errors:
            hints.append("arr_list_resources()")
        return {
            "ok": not report.errors,
            "app": app,
            "dry_run": report.dry_run,
            "summary": plan_.summary(),
            "applied_count": len(report.applied),
            "skipped_count": len(report.skipped),
            "error_count": len(report.errors),
            "applied": [
                {"resource": c.resource, "name": c.name, "action": c.action}
                for c in report.applied
            ],
            "errors": [
                {
                    "resource": c.resource,
                    "name": c.name,
                    "action": c.action,
                    "error": err,
                }
                for c, err in report.errors
            ],
            "_meta": {"action_hints": hints},
        }


def _attach_describe_tool(server: FastMCP) -> None:
    @server.tool()
    async def arr_describe_fields(resource: str) -> dict[str, Any]:
        """Return ``{resource, all, summary}`` field names for a resource model.

        ``resource`` is the dotted name like ``"radarr.movie"``, ``"sonarr.series"``,
        ``"radarr.queue"``. Call this when you need to pass a custom comma-list to
        another tool's ``fields=`` arg. Use :func:`arr_list_resources` to discover
        valid resource names.
        """
        return describe(resource)

    @server.tool()
    async def arr_list_resources() -> list[str]:
        """List all dotted-name resource identifiers known to ``arr_describe_fields``."""
        return sorted(RESOURCE_REGISTRY.keys())


def build_server(
    *,
    radarr: AsyncRadarrClientV3 | None = None,
    sonarr: AsyncSonarrClientV3 | None = None,
    name: str = "arr-py-client",
) -> FastMCP:
    """Build a FastMCP server with the requested clients attached as tools.

    At least one of ``radarr`` or ``sonarr`` must be supplied.
    """
    if radarr is None and sonarr is None:
        msg = "build_server requires at least one of radarr= or sonarr="
        raise ValueError(msg)
    server = FastMCP(name)
    if radarr is not None:
        _attach_radarr_tools(server, radarr)
    if sonarr is not None:
        _attach_sonarr_tools(server, sonarr)
    _attach_composed_tools(server, radarr=radarr, sonarr=sonarr)
    _attach_describe_tool(server)
    return server


def make_clients(
    *, want_radarr: bool, want_sonarr: bool
) -> tuple[AsyncRadarrClientV3 | None, AsyncSonarrClientV3 | None]:
    """Construct async clients from environment settings."""
    r: AsyncRadarrClientV3 | None = None
    s: AsyncSonarrClientV3 | None = None
    if want_radarr:
        r = AsyncRadarrClient()
    if want_sonarr:
        s = AsyncSonarrClient()
    return r, s
