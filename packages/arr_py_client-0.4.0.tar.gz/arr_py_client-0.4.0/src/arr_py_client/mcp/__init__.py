"""MCP server adapter for arr-py-client.

Install with the ``mcp`` extra:

    pip install 'arr-py-client[mcp]'

Then run:

    arr-py-mcp                            # both apps via env vars
    arr-py-mcp --radarr-only              # Radarr only
    arr-py-mcp --sonarr-only              # Sonarr only

Environment variables: ``RADARR_BASE_URL``, ``RADARR_API_KEY``,
``SONARR_BASE_URL``, ``SONARR_API_KEY``.
"""

from arr_py_client.mcp.server import build_server, make_clients

__all__ = ["build_server", "make_clients"]
