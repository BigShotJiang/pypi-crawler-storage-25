"""CLI entry point for the arr-py-client MCP server."""

from __future__ import annotations

import argparse
import sys

from arr_py_client.mcp.server import build_server, make_clients


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="arr-py-mcp",
        description="Run an MCP server exposing Radarr and/or Sonarr as tools.",
    )
    parser.add_argument(
        "--radarr-only",
        action="store_true",
        help="Expose only Radarr tools (skip Sonarr).",
    )
    parser.add_argument(
        "--sonarr-only",
        action="store_true",
        help="Expose only Sonarr tools (skip Radarr).",
    )
    parser.add_argument(
        "--transport",
        choices=("stdio", "sse"),
        default="stdio",
        help="MCP transport (default: stdio for client integrations).",
    )
    args = parser.parse_args()

    if args.radarr_only and args.sonarr_only:
        sys.stderr.write("--radarr-only and --sonarr-only are mutually exclusive.\n")
        return 2

    want_radarr = not args.sonarr_only
    want_sonarr = not args.radarr_only
    radarr, sonarr = make_clients(want_radarr=want_radarr, want_sonarr=want_sonarr)
    server = build_server(radarr=radarr, sonarr=sonarr)
    server.run(transport=args.transport)
    return 0


if __name__ == "__main__":
    sys.exit(main())
