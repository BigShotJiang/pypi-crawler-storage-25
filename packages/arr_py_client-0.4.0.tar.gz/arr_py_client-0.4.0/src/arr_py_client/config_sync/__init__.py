"""Declarative config sync for Radarr/Sonarr (Recyclarr/Profilarr-shaped).

Users write the desired state of their server — tags, custom formats,
quality-profile CF-score maps — as a plain Python dict (usually loaded from
YAML/JSON/TOML). This module diffs desired-vs-actual and returns a
:class:`SyncPlan`; callers then :func:`apply` (or dry-run) it.

Scope of the first cut: ``tags``, ``custom_formats``, ``quality_profiles``.
These are the three resources Recyclarr+Profilarr drive ~100% of their
traffic against and cover the vast majority of config-as-code value. Other
resources (auto_tagging, delay_profiles, release_profiles) can be added
using the same :class:`SyncChange` / :class:`SyncPlan` primitives.

The module is brand-neutral: it duck-types the client's resource interface
via attribute lookup, so a Radarr or Sonarr client works with the same
``plan()`` / ``apply()`` entry points.

Example
-------

.. code-block:: python

    import yaml
    from arr_py_client.radarr.v3 import RadarrClientV3
    from arr_py_client.config_sync import plan, apply

    with RadarrClientV3() as client:
        desired = yaml.safe_load(open("config.yaml"))
        p = plan(client, desired)
        print(p.summary())
        report = apply(client, p, dry_run=False)
"""

from __future__ import annotations

from arr_py_client.config_sync.core import (
    SyncChange,
    SyncPlan,
    SyncReport,
    apply,
    apply_async,
    plan,
    plan_async,
)

__all__ = [
    "SyncChange",
    "SyncPlan",
    "SyncReport",
    "apply",
    "apply_async",
    "plan",
    "plan_async",
]
