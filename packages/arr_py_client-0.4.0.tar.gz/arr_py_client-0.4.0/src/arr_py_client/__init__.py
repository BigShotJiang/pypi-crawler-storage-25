"""arr-py-client — typed sync + async client for Radarr and Sonarr APIs."""

from arr_py_client.__version__ import __version__
from arr_py_client._common import errors
from arr_py_client._common.retry import RetryPolicy
from arr_py_client._common.settings import RadarrSettings, SonarrSettings
from arr_py_client.radarr import AsyncRadarrClient, RadarrClient
from arr_py_client.sonarr import AsyncSonarrClient, SonarrClient

__all__ = [
    "AsyncRadarrClient",
    "AsyncSonarrClient",
    "RadarrClient",
    "RadarrSettings",
    "RetryPolicy",
    "SonarrClient",
    "SonarrSettings",
    "__version__",
    "errors",
]
