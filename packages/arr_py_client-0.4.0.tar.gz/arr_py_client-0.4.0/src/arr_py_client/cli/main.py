"""``arr-py`` CLI entrypoint."""

# pyright: reportUnknownMemberType=false, reportUnknownVariableType=false, reportUnknownArgumentType=false

from __future__ import annotations

import argparse
import dataclasses
import json
import sys
from typing import TYPE_CHECKING, Any

from arr_py_client import RadarrClient, SonarrClient

if TYPE_CHECKING:
    from arr_py_client._common.library import LibraryHealth
    from arr_py_client.radarr.v3.client import RadarrClientV3
    from arr_py_client.sonarr.v3.client import SonarrClientV3


def _print(obj: Any, fmt: str) -> None:
    """Render a result to stdout as table (default), json, or tsv."""
    if fmt == "json":
        sys.stdout.write(json.dumps(_jsonable(obj), default=str, indent=2) + "\n")
        return
    if fmt == "tsv":
        rows = _as_rows(obj)
        if not rows:
            return
        headers = list(rows[0].keys())
        sys.stdout.write("\t".join(headers) + "\n")
        for row in rows:
            sys.stdout.write("\t".join(str(row.get(h, "")) for h in headers) + "\n")
        return
    # Default: table
    rows = _as_rows(obj)
    if not rows:
        sys.stdout.write("(no rows)\n")
        return
    headers = list(rows[0].keys())
    widths = {
        h: max(len(h), max((len(str(row.get(h, ""))) for row in rows), default=0))
        for h in headers
    }
    sep = "  "
    sys.stdout.write(sep.join(h.ljust(widths[h]) for h in headers) + "\n")
    sys.stdout.write(sep.join("-" * widths[h] for h in headers) + "\n")
    for row in rows:
        sys.stdout.write(
            sep.join(str(row.get(h, "")).ljust(widths[h]) for h in headers) + "\n"
        )


def _jsonable(obj: Any) -> Any:
    """Best-effort render arbitrary objects into JSON-safe types."""
    if hasattr(obj, "model_dump"):
        return obj.model_dump(by_alias=True, exclude_none=True)
    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        return {k: _jsonable(v) for k, v in dataclasses.asdict(obj).items()}
    if isinstance(obj, list):
        return [_jsonable(x) for x in obj]
    if isinstance(obj, dict):
        return {k: _jsonable(v) for k, v in obj.items()}
    return obj


def _as_rows(obj: Any) -> list[dict[str, Any]]:
    if isinstance(obj, list):
        return [_row(x) for x in obj]
    return [_row(obj)]


def _row(obj: Any) -> dict[str, Any]:
    data = _jsonable(obj)
    if isinstance(data, dict):
        # Flatten one level for legibility in table mode.
        return {k: v for k, v in data.items() if not isinstance(v, (list, dict))}
    return {"value": data}


def _radarr_client() -> RadarrClientV3:
    return RadarrClient()


def _sonarr_client() -> SonarrClientV3:
    return SonarrClient()


def _cmd_health(args: argparse.Namespace) -> int:
    out: dict[str, LibraryHealth | str] = {}
    if args.app in ("both", "radarr"):
        with _radarr_client() as c:
            out["radarr"] = c.library.health_summary()
    if args.app in ("both", "sonarr"):
        with _sonarr_client() as c:
            out["sonarr"] = c.library.health_summary()
    _print(out, args.format)
    return 0


def _cmd_movies_list(args: argparse.Namespace) -> int:
    with _radarr_client() as c:
        rows = list(c.movies.iter_all())
    if args.tag or args.monitored is not None or args.missing:
        with _radarr_client() as c:
            rows = list(
                c.movies.filter(
                    tag=args.tag,
                    monitored=args.monitored,
                    has_file=False if args.missing else None,
                )
            )
    _print(rows, args.format)
    return 0


def _cmd_movies_add(args: argparse.Namespace) -> int:
    with _radarr_client() as c:
        result = c.movies.add(
            title=args.title,
            tmdb_id=args.tmdb_id,
            quality=args.quality,
            root_folder=args.root,
            tags=args.tag or None,
            monitored=not args.unmonitored,
            search_on_add=not args.no_search,
            if_exists=args.if_exists,
        )
    _print(result, args.format)
    return 0


def _cmd_series_list(args: argparse.Namespace) -> int:
    with _sonarr_client() as c:
        rows = list(
            c.series.filter(
                tag=args.tag,
                monitored=args.monitored,
            )
            if args.tag is not None or args.monitored is not None
            else c.series.iter_all()
        )
    _print(rows, args.format)
    return 0


def _cmd_queue_stuck(args: argparse.Namespace) -> int:
    result: Any
    if args.app == "radarr":
        with _radarr_client() as c:
            result = (
                c.queue.clear_stuck(dry_run=not args.nuke)
                if args.nuke or args.dry_run
                else c.queue.stuck()
            )
    else:
        with _sonarr_client() as c:
            result = (
                c.queue.clear_stuck(dry_run=not args.nuke)
                if args.nuke or args.dry_run
                else c.queue.stuck()
            )
    _print(result, args.format)
    return 0


def _cmd_config(args: argparse.Namespace) -> int:  # noqa: ARG001
    """Show resolved config (redacts API key)."""
    from arr_py_client._common.settings import RadarrSettings, SonarrSettings

    out: dict[str, Any] = {}
    for name, cls in (("radarr", RadarrSettings), ("sonarr", SonarrSettings)):
        try:
            s = cls()  # pyright: ignore[reportCallIssue]
            out[name] = {"base_url": s.base_url, "api_key": "***"}
        except Exception as exc:
            out[name] = {"error": str(exc)}
    _print(out, "json")
    return 0


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="arr-py",
        description="CLI for arr-py-client — Radarr and Sonarr from the shell.",
    )
    parser.add_argument(
        "--format",
        "-f",
        choices=("table", "json", "tsv"),
        default="table",
        help="Output format (default: table).",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_health = sub.add_parser("health", help="Aggregate library health dashboard.")
    p_health.add_argument("--app", choices=("both", "radarr", "sonarr"), default="both")
    p_health.set_defaults(func=_cmd_health)

    p_config = sub.add_parser("config", help="Show resolved config (API key redacted).")
    p_config.set_defaults(func=_cmd_config)

    # ---- radarr subtree ----
    p_radarr = sub.add_parser("radarr", help="Radarr commands.")
    r_sub = p_radarr.add_subparsers(dest="rcommand", required=True)

    r_movies = r_sub.add_parser("movies", help="Movies operations.")
    r_movies_sub = r_movies.add_subparsers(dest="mcommand", required=True)

    r_list = r_movies_sub.add_parser("list", help="List movies with optional filters.")
    r_list.add_argument("--tag", help="Filter by tag label or id.")
    r_list.add_argument("--missing", action="store_true", help="Only missing files.")
    r_list.add_argument(
        "--monitored", type=lambda v: v.lower() in ("1", "true", "yes"), default=None
    )
    r_list.set_defaults(func=_cmd_movies_list)

    r_add = r_movies_sub.add_parser("add", help="Add a movie (name- or tmdbId-based).")
    r_add.add_argument("title", nargs="?", help="Movie title for TMDB lookup.")
    r_add.add_argument("--tmdb-id", type=int, help="TMDB id (alternative to title).")
    r_add.add_argument("--quality", help="Quality profile name or id.")
    r_add.add_argument("--root", help="Root folder path (auto-picks if only one).")
    r_add.add_argument(
        "--tag", action="append", help="Tag label (repeat for multiple)."
    )
    r_add.add_argument("--unmonitored", action="store_true")
    r_add.add_argument("--no-search", action="store_true")
    r_add.add_argument(
        "--if-exists", choices=("skip", "update", "error"), default="skip"
    )
    r_add.set_defaults(func=_cmd_movies_add)

    # ---- sonarr subtree ----
    p_sonarr = sub.add_parser("sonarr", help="Sonarr commands.")
    s_sub = p_sonarr.add_subparsers(dest="scommand", required=True)

    s_series = s_sub.add_parser("series", help="Series operations.")
    s_series_sub = s_series.add_subparsers(dest="scseries", required=True)

    s_list = s_series_sub.add_parser("list", help="List series with optional filters.")
    s_list.add_argument("--tag")
    s_list.add_argument(
        "--monitored", type=lambda v: v.lower() in ("1", "true", "yes"), default=None
    )
    s_list.set_defaults(func=_cmd_series_list)

    # ---- queue stuck (shared) ----
    p_queue = sub.add_parser("queue", help="Queue operations.")
    q_sub = p_queue.add_subparsers(dest="qcommand", required=True)
    q_stuck = q_sub.add_parser("stuck", help="List stuck queue items.")
    q_stuck.add_argument("--app", choices=("radarr", "sonarr"), required=True)
    q_stuck.add_argument(
        "--nuke", action="store_true", help="Remove + blocklist + re-search."
    )
    q_stuck.add_argument("--dry-run", action="store_true")
    q_stuck.set_defaults(func=_cmd_queue_stuck)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    sys.exit(main())
