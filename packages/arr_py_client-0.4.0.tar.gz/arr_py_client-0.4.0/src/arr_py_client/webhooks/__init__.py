"""Typed event models for Radarr/Sonarr webhook POSTs.

Radarr and Sonarr push JSON bodies to user-configured webhook URLs. The event
shape is **not** part of the OpenAPI spec — it's defined in server C# source
— so these models are permissive (extra fields ignored, most fields optional)
and intentionally scoped to the fields users actually care about.

Usage:

.. code-block:: python

    from arr_py_client.webhooks import parse_event, OnGrab

    event = parse_event(request.json())
    match event:
        case OnGrab(movie=m, release=r) if m:
            notify(f"Grabbed {m.title}: {r.title if r else ''}")

Unknown ``eventType`` values round-trip as :class:`UnknownEvent` so your
handler never silently drops a webhook the server added in a newer release.
"""

from __future__ import annotations

from arr_py_client.webhooks.events import (
    ArrEvent,
    EventBase,
    OnApplicationUpdate,
    OnDownload,
    OnEpisodeFileDelete,
    OnGrab,
    OnHealthIssue,
    OnManualInteractionRequired,
    OnMovieAdded,
    OnMovieDelete,
    OnMovieFileDelete,
    OnRename,
    OnSeriesAdd,
    OnSeriesDelete,
    OnTest,
    OnUpgrade,
    UnknownEvent,
    parse_event,
)

__all__ = [
    "ArrEvent",
    "EventBase",
    "OnApplicationUpdate",
    "OnDownload",
    "OnEpisodeFileDelete",
    "OnGrab",
    "OnHealthIssue",
    "OnManualInteractionRequired",
    "OnMovieAdded",
    "OnMovieDelete",
    "OnMovieFileDelete",
    "OnRename",
    "OnSeriesAdd",
    "OnSeriesDelete",
    "OnTest",
    "OnUpgrade",
    "UnknownEvent",
    "parse_event",
]
