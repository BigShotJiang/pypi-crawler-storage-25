"""Pydantic models for webhook event payloads.

The full Radarr/Sonarr event schema is large and shifts between versions. These
models cover the common core plus the fields most users read in handlers:

- ``eventType`` for dispatch
- ``movie`` / ``series`` / ``episodes`` / ``movieFile`` for the affected entity
- ``release`` for grab/download events
- ``healthIssue`` for on-health-issue events
- ``applicationUpdate`` for on-application-update events

Unrecognized ``eventType`` values are preserved as :class:`UnknownEvent` so
downstream code can still inspect the raw payload.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


class _PermissiveModel(BaseModel):
    """Base model — extra fields pass through silently.

    Webhook payloads vary between Radarr/Sonarr versions and the two brands
    agree on enough of the common fields to share these classes.
    """

    model_config = ConfigDict(extra="allow", populate_by_name=True)


class WebhookMovie(_PermissiveModel):
    id: int | None = None
    title: str | None = None
    year: int | None = None
    tmdb_id: int | None = Field(default=None, alias="tmdbId")
    imdb_id: str | None = Field(default=None, alias="imdbId")
    folder_path: str | None = Field(default=None, alias="folderPath")


class WebhookSeries(_PermissiveModel):
    id: int | None = None
    title: str | None = None
    tvdb_id: int | None = Field(default=None, alias="tvdbId")
    tv_maze_id: int | None = Field(default=None, alias="tvMazeId")
    imdb_id: str | None = Field(default=None, alias="imdbId")
    path: str | None = None


class WebhookEpisode(_PermissiveModel):
    id: int | None = None
    episode_number: int | None = Field(default=None, alias="episodeNumber")
    season_number: int | None = Field(default=None, alias="seasonNumber")
    title: str | None = None
    air_date: str | None = Field(default=None, alias="airDate")
    series_id: int | None = Field(default=None, alias="seriesId")


class WebhookMovieFile(_PermissiveModel):
    id: int | None = None
    relative_path: str | None = Field(default=None, alias="relativePath")
    path: str | None = None
    quality: str | None = None
    size: int | None = None


class WebhookRelease(_PermissiveModel):
    quality: str | None = None
    quality_version: int | None = Field(default=None, alias="qualityVersion")
    release_group: str | None = Field(default=None, alias="releaseGroup")
    release_title: str | None = Field(default=None, alias="releaseTitle")
    indexer: str | None = None
    size: int | None = None


class WebhookHealthIssue(_PermissiveModel):
    source: str | None = None
    type: str | None = None
    message: str | None = None
    wiki_url: str | None = Field(default=None, alias="wikiUrl")


class WebhookAppUpdate(_PermissiveModel):
    previous_version: str | None = Field(default=None, alias="previousVersion")
    new_version: str | None = Field(default=None, alias="newVersion")


class EventBase(_PermissiveModel):
    event_type: str = Field(alias="eventType")
    instance_name: str | None = Field(default=None, alias="instanceName")
    application_url: str | None = Field(default=None, alias="applicationUrl")


class OnGrab(EventBase):
    event_type: Literal["Grab"] = Field(default="Grab", alias="eventType")
    movie: WebhookMovie | None = None
    series: WebhookSeries | None = None
    episodes: list[WebhookEpisode] | None = None
    release: WebhookRelease | None = None


class OnDownload(EventBase):
    event_type: Literal["Download"] = Field(default="Download", alias="eventType")
    movie: WebhookMovie | None = None
    series: WebhookSeries | None = None
    episodes: list[WebhookEpisode] | None = None
    movie_file: WebhookMovieFile | None = Field(default=None, alias="movieFile")
    is_upgrade: bool | None = Field(default=None, alias="isUpgrade")


class OnUpgrade(EventBase):
    event_type: Literal["Upgrade"] = Field(default="Upgrade", alias="eventType")
    movie: WebhookMovie | None = None
    series: WebhookSeries | None = None
    movie_file: WebhookMovieFile | None = Field(default=None, alias="movieFile")


class OnRename(EventBase):
    event_type: Literal["Rename"] = Field(default="Rename", alias="eventType")
    movie: WebhookMovie | None = None
    series: WebhookSeries | None = None


class OnSeriesAdd(EventBase):
    event_type: Literal["SeriesAdd"] = Field(default="SeriesAdd", alias="eventType")
    series: WebhookSeries | None = None


class OnSeriesDelete(EventBase):
    event_type: Literal["SeriesDelete"] = Field(
        default="SeriesDelete", alias="eventType"
    )
    series: WebhookSeries | None = None
    deleted_files: bool | None = Field(default=None, alias="deletedFiles")


class OnMovieAdded(EventBase):
    event_type: Literal["MovieAdded"] = Field(default="MovieAdded", alias="eventType")
    movie: WebhookMovie | None = None


class OnMovieDelete(EventBase):
    event_type: Literal["MovieDelete"] = Field(default="MovieDelete", alias="eventType")
    movie: WebhookMovie | None = None
    deleted_files: bool | None = Field(default=None, alias="deletedFiles")


class OnMovieFileDelete(EventBase):
    event_type: Literal["MovieFileDelete"] = Field(
        default="MovieFileDelete", alias="eventType"
    )
    movie: WebhookMovie | None = None
    movie_file: WebhookMovieFile | None = Field(default=None, alias="movieFile")
    # ``reason`` is a free-form string from the server: e.g. "Upgrade", "MissingFromDisk",
    # "Manual". Kept raw so we don't fall behind new reasons.
    reason: str | None = None


class OnEpisodeFileDelete(EventBase):
    event_type: Literal["EpisodeFileDelete"] = Field(
        default="EpisodeFileDelete", alias="eventType"
    )
    series: WebhookSeries | None = None
    episodes: list[WebhookEpisode] | None = None
    episode_file: dict[str, Any] | None = Field(default=None, alias="episodeFile")
    reason: str | None = None


class OnManualInteractionRequired(EventBase):
    event_type: Literal["ManualInteractionRequired"] = Field(
        default="ManualInteractionRequired", alias="eventType"
    )
    # Fired when a download needs human decision (failed import, ambiguous match).
    # Radarr fills ``movie``, Sonarr fills ``series`` + ``episodes``.
    movie: WebhookMovie | None = None
    series: WebhookSeries | None = None
    episodes: list[WebhookEpisode] | None = None
    download_info: dict[str, Any] | None = Field(default=None, alias="downloadInfo")
    download_status_messages: list[dict[str, Any]] | None = Field(
        default=None, alias="downloadStatusMessages"
    )


class OnHealthIssue(EventBase):
    event_type: Literal["Health"] = Field(default="Health", alias="eventType")
    health_issue: WebhookHealthIssue | None = Field(default=None, alias="healthIssue")


class OnApplicationUpdate(EventBase):
    event_type: Literal["ApplicationUpdate"] = Field(
        default="ApplicationUpdate", alias="eventType"
    )
    application_update: WebhookAppUpdate | None = Field(
        default=None, alias="applicationUpdate"
    )


class OnTest(EventBase):
    event_type: Literal["Test"] = Field(default="Test", alias="eventType")


class UnknownEvent(EventBase):
    """Event whose ``eventType`` isn't in our typed union. Still carries raw fields."""

    raw: dict[str, Any] = Field(default_factory=dict)


ArrEvent = (
    OnGrab
    | OnDownload
    | OnUpgrade
    | OnRename
    | OnSeriesAdd
    | OnSeriesDelete
    | OnMovieAdded
    | OnMovieDelete
    | OnMovieFileDelete
    | OnEpisodeFileDelete
    | OnManualInteractionRequired
    | OnHealthIssue
    | OnApplicationUpdate
    | OnTest
    | UnknownEvent
)


_TYPE_MAP: dict[str, type[EventBase]] = {
    "Grab": OnGrab,
    "Download": OnDownload,
    "Upgrade": OnUpgrade,
    "Rename": OnRename,
    "SeriesAdd": OnSeriesAdd,
    "SeriesDelete": OnSeriesDelete,
    "MovieAdded": OnMovieAdded,
    "MovieDelete": OnMovieDelete,
    "MovieFileDelete": OnMovieFileDelete,
    "EpisodeFileDelete": OnEpisodeFileDelete,
    "ManualInteractionRequired": OnManualInteractionRequired,
    "Health": OnHealthIssue,
    "ApplicationUpdate": OnApplicationUpdate,
    "Test": OnTest,
}


def parse_event(payload: dict[str, Any]) -> ArrEvent:
    """Dispatch on ``payload['eventType']`` to the appropriate typed model.

    Unknown event types round-trip as :class:`UnknownEvent` with the full
    payload preserved under ``raw`` — your handlers never silently drop data.
    """
    event_type_raw = payload.get("eventType") or payload.get("event_type") or ""
    event_type = str(event_type_raw)
    cls = _TYPE_MAP.get(event_type)
    if cls is not None:
        return cls.model_validate(payload)  # type: ignore[return-value]
    return UnknownEvent.model_validate({**payload, "raw": dict(payload)})
