"""Stressor-flag construction and stressor-stack counting."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

STRESSOR_COLUMNS: tuple[str, ...] = (
    "stressor_bullying",
    "stressor_discrimination",
    "stressor_heavy_social_media",
    "stressor_low_connectedness",
)


def _yes_no_float(series: pd.Series, yrbss: bool) -> pd.Series:
    """Convert a variable to a float 0/1 indicator (NaN preserved).

    - ``yrbss=True``: YRBSS convention (1 = yes, 2 = no, NaN = missing).
    - ``yrbss=False``: generic convention (1 = yes, 0 = no, NaN/other = missing).
    """
    v = pd.to_numeric(series, errors="coerce").to_numpy(dtype=float)
    if yrbss:
        out = np.where(v == 1, 1.0, np.where(v == 2, 0.0, np.nan))
    else:
        out = np.where(v == 1, 1.0, np.where(v == 0, 0.0, np.nan))
    return pd.Series(out, index=series.index)


def _to_int8_nullable(series: pd.Series) -> pd.Series:
    """Convert a float 0/1/NaN series to nullable Int8 with pd.NA."""
    return pd.array(
        [pd.NA if pd.isna(x) else int(x) for x in series],
        dtype="Int8",
    )


def _or_flag(a: pd.Series | None, b: pd.Series | None, index) -> pd.Series:
    """OR of two 0/1 float series, NA only when both are NA. Returns Int8 nullable."""
    if a is None and b is None:
        return pd.Series(pd.array([pd.NA] * len(index), dtype="Int8"), index=index)
    arrs = [x for x in (a, b) if x is not None]
    stacked = np.vstack([x.to_numpy(dtype=float) for x in arrs])
    any_pos = np.nansum(stacked >= 1, axis=0) >= 1
    all_missing = np.all(np.isnan(stacked), axis=0)
    out = np.where(all_missing, np.nan, any_pos.astype(float))
    return pd.Series(_to_int8_nullable(pd.Series(out, index=index)), index=index)


def flag_stressors(
    df: pd.DataFrame,
    heavy_social_media_threshold: int = 5,
    low_connectedness_threshold: int = 2,
    yrbss: bool = False,
) -> pd.DataFrame:
    """Add binary stressor-flag columns.

    Flags produced (each 0/1 with <NA> for missing):

    - ``stressor_bullying`` — bullied at school or electronically.
    - ``stressor_discrimination`` — racism in school or unfair discipline.
    - ``stressor_heavy_social_media`` — social-media-hours code at or above
      ``heavy_social_media_threshold``.
    - ``stressor_low_connectedness`` — connectedness Likert at or below
      ``low_connectedness_threshold``.

    Parameters
    ----------
    yrbss : bool, default False
        If True, interpret the canonical variables using the YRBSS coding
        convention (1 = criterion met, 2 = not met, NaN = missing). The
        ``heavy_social_media_threshold`` and ``low_connectedness_threshold``
        arguments are ignored in this mode — the 2023 YRBSS items ``QN80``
        (social media "several times a day") and ``QN103`` (feels close to
        people at school) are already binary recodes, so flags are derived
        directly from "criterion met" / "criterion not met".

    Variables absent from ``df`` yield an all-NA flag rather than raising, so
    partial datasets still produce a usable stack count (missing is honored).
    """
    out = df.copy()

    if yrbss:
        bull_a = _yes_no_float(out["bullied_school"], True) if "bullied_school" in out else None
        bull_b = _yes_no_float(out["bullied_electronic"], True) if "bullied_electronic" in out else None
        out["stressor_bullying"] = _or_flag(bull_a, bull_b, out.index)

        disc_a = _yes_no_float(out["racism_school"], True) if "racism_school" in out else None
        disc_b = _yes_no_float(out["unfair_discipline"], True) if "unfair_discipline" in out else None
        out["stressor_discrimination"] = _or_flag(disc_a, disc_b, out.index)

        if "social_media_hours" in out:
            sm = _yes_no_float(out["social_media_hours"], True)
            out["stressor_heavy_social_media"] = _to_int8_nullable(sm)
        else:
            out["stressor_heavy_social_media"] = pd.array([pd.NA] * len(out), dtype="Int8")

        if "connectedness" in out:
            connected = _yes_no_float(out["connectedness"], True)
            low = pd.Series(
                np.where(connected == 1, 0.0, np.where(connected == 0, 1.0, np.nan)),
                index=out.index,
            )
            out["stressor_low_connectedness"] = _to_int8_nullable(low)
        else:
            out["stressor_low_connectedness"] = pd.array([pd.NA] * len(out), dtype="Int8")

        return out

    bull_a = _yes_no_float(out["bullied_school"], False) if "bullied_school" in out else None
    bull_b = _yes_no_float(out["bullied_electronic"], False) if "bullied_electronic" in out else None
    out["stressor_bullying"] = _or_flag(bull_a, bull_b, out.index)

    disc_a = _yes_no_float(out["racism_school"], False) if "racism_school" in out else None
    disc_b = _yes_no_float(out["unfair_discipline"], False) if "unfair_discipline" in out else None
    out["stressor_discrimination"] = _or_flag(disc_a, disc_b, out.index)

    if "social_media_hours" in out:
        v = pd.to_numeric(out["social_media_hours"], errors="coerce").to_numpy(dtype=float)
        flag = np.where(np.isnan(v), np.nan, (v >= heavy_social_media_threshold).astype(float))
        out["stressor_heavy_social_media"] = _to_int8_nullable(pd.Series(flag, index=out.index))
    else:
        out["stressor_heavy_social_media"] = pd.array([pd.NA] * len(out), dtype="Int8")

    if "connectedness" in out:
        v = pd.to_numeric(out["connectedness"], errors="coerce").to_numpy(dtype=float)
        flag = np.where(np.isnan(v), np.nan, (v <= low_connectedness_threshold).astype(float))
        out["stressor_low_connectedness"] = _to_int8_nullable(pd.Series(flag, index=out.index))
    else:
        out["stressor_low_connectedness"] = pd.array([pd.NA] * len(out), dtype="Int8")

    return out


@dataclass
class StressorStackSummary:
    counts: pd.Series
    prevalence: pd.Series
    mean_stack: float

    def summary(self) -> str:
        lines = [
            f"Mean stressors per respondent: {self.mean_stack:.2f}",
            "",
            "Stressor stack distribution (number of stressors -> count):",
        ]
        for k, v in self.counts.items():
            lines.append(f"  {k}: {v}")
        lines.append("")
        lines.append("Per-stressor prevalence:")
        for k, v in self.prevalence.items():
            lines.append(f"  {k}: {v:.1%}")
        return "\n".join(lines)


def count_stressor_stack(df: pd.DataFrame, complete_cases: bool = True) -> StressorStackSummary:
    """Return per-respondent stressor-count distribution and per-flag prevalence.

    Parameters
    ----------
    complete_cases : bool, default True
        If True, respondents missing any stressor flag are excluded from the
        stack distribution. If False, missing flags are treated as 0 (legacy
        behavior; may under-count stressors).
    """
    missing = [c for c in STRESSOR_COLUMNS if c not in df.columns]
    if missing:
        raise KeyError(
            f"Missing stressor flag columns: {missing}. Call flag_stressors(df) first."
        )
    sub = df[list(STRESSOR_COLUMNS)]
    if complete_cases:
        sub = sub.dropna()
    stack = sub.sum(axis=1)
    counts = stack.value_counts().sort_index()
    counts.index = counts.index.astype(int)
    prevalence = sub.astype("Float64").mean()
    return StressorStackSummary(
        counts=counts,
        prevalence=prevalence,
        mean_stack=float(stack.mean()),
    )


def find_stressor_clusters(df: pd.DataFrame, features: list[str] | None = None) -> StressorStackSummary:
    """Alias for count_stressor_stack with optional feature subset for forward compatibility."""
    if features:
        missing = [f for f in features if f not in df.columns]
        if missing:
            raise KeyError(f"Features not in df: {missing}")
    return count_stressor_stack(df)
