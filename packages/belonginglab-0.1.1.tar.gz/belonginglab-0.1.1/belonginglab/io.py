"""Data loading and variable standardization for YRBSS-style survey data."""

from __future__ import annotations

from pathlib import Path
from typing import Mapping

import numpy as np
import pandas as pd

from ._schema import CANONICAL_VARIABLES, get_schema


def load_yrbss(path: str | Path, **read_csv_kwargs) -> pd.DataFrame:
    """Load a YRBSS export into a DataFrame.

    Supports CSV and SAS transport files (.sas7bdat, .xpt) based on extension.
    Additional keyword arguments are forwarded to the underlying pandas reader.
    """
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix == ".csv":
        return pd.read_csv(path, **read_csv_kwargs)
    if suffix == ".sas7bdat":
        return pd.read_sas(path, format="sas7bdat", **read_csv_kwargs)
    if suffix == ".xpt":
        return pd.read_sas(path, format="xport", **read_csv_kwargs)
    raise ValueError(f"Unsupported file type: {suffix!r}. Use .csv, .sas7bdat, or .xpt.")


def map_variables(
    df: pd.DataFrame,
    schema: str | Mapping[str, str] = "yrbss_2023",
    keep_unmapped: bool = True,
) -> pd.DataFrame:
    """Rename raw survey columns to canonical belonginglab names.

    Parameters
    ----------
    df : DataFrame
        Raw survey data.
    schema : str or mapping
        Either a registered schema name (e.g. ``"yrbss_2023"``) or a dict
        mapping canonical name -> raw column name.
    keep_unmapped : bool
        If True, raw columns not referenced by the schema are kept unchanged.
        If False, only canonical variables are retained.
    """
    mapping = get_schema(schema) if isinstance(schema, str) else dict(schema)
    rename = {raw: canon for canon, raw in mapping.items() if raw in df.columns}
    out = df.rename(columns=rename)
    if not keep_unmapped:
        keep = [c for c in CANONICAL_VARIABLES if c in out.columns]
        out = out[keep]
    return out


def clean_yrbss(
    df: pd.DataFrame,
    subgroup: Mapping[str, object] | None = None,
    drop_missing: list[str] | None = None,
) -> pd.DataFrame:
    """Standardize missing values and optionally filter to a subgroup.

    YRBSS exports often use blank strings or sentinel codes for missing
    responses. This routine coerces those to NaN and optionally filters rows
    where required canonical variables are missing.
    """
    out = df.copy()
    out = out.replace({"": np.nan, " ": np.nan, ".": np.nan})

    for col in out.columns:
        if out[col].dtype == object:
            try:
                out[col] = pd.to_numeric(out[col])
            except (ValueError, TypeError):
                pass

    if subgroup:
        for col, value in subgroup.items():
            if col not in out.columns:
                raise KeyError(f"Subgroup filter column {col!r} not in data.")
            if isinstance(value, (list, tuple, set)):
                out = out[out[col].isin(list(value))]
            else:
                out = out[out[col] == value]

    if drop_missing:
        missing_cols = [c for c in drop_missing if c in out.columns]
        out = out.dropna(subset=missing_cols)

    return out.reset_index(drop=True)
