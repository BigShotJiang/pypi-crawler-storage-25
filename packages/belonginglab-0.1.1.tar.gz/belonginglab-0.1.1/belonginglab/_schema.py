"""Variable-name schemas for mapping raw YRBSS columns to canonical names.

CDC YRBSS question codes shift year to year. Each schema maps canonical
belonginglab names (used throughout the package) to the raw column names
expected in a given release. Users can override the mapping with their own
dict to support other datasets (state files, custom surveys).
"""

from __future__ import annotations

CANONICAL_VARIABLES: tuple[str, ...] = (
    "sex",
    "grade",
    "race_ethnicity",
    "connectedness",
    "bullied_school",
    "bullied_electronic",
    "racism_school",
    "unfair_discipline",
    "social_media_hours",
    "sad_hopeless",
    "supportive_adult",
)

YRBSS_2023: dict[str, str] = {
    "sex": "Q2",
    "grade": "Q3",
    "race_ethnicity": "RACEETH",
    "connectedness": "QN103",
    "bullied_school": "QN24",
    "bullied_electronic": "QN25",
    "racism_school": "QN23",
    "unfair_discipline": "QN105",
    "social_media_hours": "QN80",
    "sad_hopeless": "QN26",
    "supportive_adult": "QN99",
}

SCHEMAS: dict[str, dict[str, str]] = {
    "yrbss_2023": YRBSS_2023,
}


def get_schema(name: str) -> dict[str, str]:
    if name not in SCHEMAS:
        raise ValueError(
            f"Unknown schema {name!r}. Available: {sorted(SCHEMAS)}. "
            "Pass a dict directly to override variable mappings."
        )
    return dict(SCHEMAS[name])
