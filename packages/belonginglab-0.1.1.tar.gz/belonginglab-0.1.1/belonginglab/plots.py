"""Lightweight plotting helpers. Requires matplotlib (install ``belonginglab[plots]``)."""

from __future__ import annotations

import pandas as pd

from .stressors import STRESSOR_COLUMNS


def _require_matplotlib():
    try:
        import matplotlib.pyplot as plt  # noqa: F401
    except ImportError as e:
        raise ImportError(
            "Plotting requires matplotlib. Install with: pip install belonginglab[plots]"
        ) from e
    return plt


def plot_belonging_distribution(df: pd.DataFrame, score_col: str = "belonging_score", bins: int = 30):
    plt = _require_matplotlib()
    fig, ax = plt.subplots()
    df[score_col].dropna().plot.hist(bins=bins, ax=ax)
    ax.set_xlabel(score_col)
    ax.set_ylabel("respondents")
    ax.set_title("Belonging score distribution")
    return fig


def plot_stressor_prevalence(df: pd.DataFrame):
    plt = _require_matplotlib()
    cols = [c for c in STRESSOR_COLUMNS if c in df.columns]
    if not cols:
        raise ValueError("No stressor flag columns found. Call flag_stressors(df) first.")
    prev = df[cols].mean().sort_values()
    fig, ax = plt.subplots()
    prev.plot.barh(ax=ax)
    ax.set_xlabel("prevalence")
    ax.set_title("Stressor prevalence")
    fig.tight_layout()
    return fig
