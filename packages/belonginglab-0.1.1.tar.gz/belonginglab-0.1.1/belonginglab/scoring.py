"""Composite belonging-score computation.

The belonging score is a z-score composite combining positive contributors
(school connectedness, supportive-adult presence) with negative contributors
(bullying, racism, unfair discipline, heavy social media, sadness/hopelessness).

This is a research-oriented operationalization, not a clinical instrument.
See the README ethical note.
"""

from __future__ import annotations

from typing import Mapping

import numpy as np
import pandas as pd

DEFAULT_WEIGHTS: dict[str, float] = {
    "connectedness": 1.0,
    "supportive_adult": 0.5,
    "bullied_school": -0.75,
    "bullied_electronic": -0.5,
    "racism_school": -0.75,
    "unfair_discipline": -0.75,
    "social_media_hours": -0.5,
    "sad_hopeless": -1.0,
}


def _zscore(series: pd.Series) -> pd.Series:
    values = pd.to_numeric(series, errors="coerce")
    std = values.std(ddof=0)
    if std == 0 or np.isnan(std):
        return pd.Series(np.zeros(len(values)), index=values.index)
    return (values - values.mean()) / std


def compute_belonging_score(
    df: pd.DataFrame,
    method: str = "weighted",
    weights: Mapping[str, float] | None = None,
    output_col: str = "belonging_score",
    scale_0_100: bool = True,
) -> pd.DataFrame:
    """Attach a belonging score column to ``df``.

    Parameters
    ----------
    df : DataFrame
        Must contain a subset of the canonical variables listed in
        :data:`DEFAULT_WEIGHTS`. Missing variables are skipped, not errored.
    method : {"weighted"}
        Scoring method. Only "weighted" is implemented in v0.1.
    weights : mapping, optional
        Override the default variable weights. Positive weights contribute
        toward higher belonging; negative weights detract.
    output_col : str
        Name of the column to write.
    scale_0_100 : bool
        If True (default), the final score is percentile-ranked to 0-100 for
        interpretability. If False, raw z-score sums are returned.
    """
    if method != "weighted":
        raise ValueError(f"Unknown method {method!r}. Supported: 'weighted'.")

    w = dict(DEFAULT_WEIGHTS)
    if weights:
        w.update(weights)

    available = [v for v in w if v in df.columns]
    if not available:
        raise ValueError(
            "No belonging-score variables found in df. Run map_variables() first "
            f"or ensure columns include any of: {sorted(w)}."
        )

    components = pd.DataFrame(index=df.index)
    for var in available:
        components[var] = _zscore(df[var]) * w[var]

    raw = components.sum(axis=1, min_count=1)

    if scale_0_100:
        ranked = raw.rank(pct=True) * 100
        out = df.copy()
        out[output_col] = ranked
    else:
        out = df.copy()
        out[output_col] = raw

    out.attrs["belonging_score_components"] = available
    out.attrs["belonging_score_weights"] = {v: w[v] for v in available}
    return out
