"""belonginglab — measure school belonging and stressor patterns in youth survey data."""

from ._schema import CANONICAL_VARIABLES, SCHEMAS, get_schema
from ._synthetic import make_synthetic_yrbss
from .compare import compare_groups
from .io import clean_yrbss, load_yrbss, map_variables
from .report import ETHICAL_NOTE, generate_summary_report
from .scoring import DEFAULT_WEIGHTS, compute_belonging_score
from .stressors import (
    STRESSOR_COLUMNS,
    StressorStackSummary,
    count_stressor_stack,
    find_stressor_clusters,
    flag_stressors,
)
from .yrbss import load_yrbss_fixed_width, prepare_yrbss

__version__ = "0.1.1"

__all__ = [
    "__version__",
    "CANONICAL_VARIABLES",
    "DEFAULT_WEIGHTS",
    "ETHICAL_NOTE",
    "SCHEMAS",
    "STRESSOR_COLUMNS",
    "StressorStackSummary",
    "clean_yrbss",
    "compare_groups",
    "compute_belonging_score",
    "count_stressor_stack",
    "find_stressor_clusters",
    "flag_stressors",
    "generate_summary_report",
    "get_schema",
    "load_yrbss",
    "load_yrbss_fixed_width",
    "make_synthetic_yrbss",
    "map_variables",
    "prepare_yrbss",
]
