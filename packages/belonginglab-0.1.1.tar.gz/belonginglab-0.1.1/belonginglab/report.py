"""Plain-language summary reports."""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from .stressors import STRESSOR_COLUMNS, count_stressor_stack

ETHICAL_NOTE = (
    "belonginglab is for research and educational analysis. It does not "
    "diagnose mental health conditions or determine individual student risk."
)


def generate_summary_report(
    df: pd.DataFrame,
    output: str = "markdown",
    group_by: str | None = None,
    score_col: str = "belonging_score",
    path: str | Path | None = None,
) -> str:
    """Produce a plain-text or markdown summary of a scored, flagged dataset.

    Parameters
    ----------
    df : DataFrame
        Data that has already been passed through ``compute_belonging_score``
        and ``flag_stressors``.
    output : {"markdown", "text"}
        Output format.
    group_by : str, optional
        Column to compute subgroup summaries on.
    score_col : str
        Belonging-score column name.
    path : str or Path, optional
        If given, the report is also written to this file.
    """
    if output not in {"markdown", "text"}:
        raise ValueError("output must be 'markdown' or 'text'")

    h1 = "# " if output == "markdown" else ""
    h2 = "## " if output == "markdown" else ""
    bullet = "- " if output == "markdown" else "  * "

    lines: list[str] = []
    lines.append(f"{h1}belonginglab summary report")
    lines.append("")
    lines.append(f"Respondents: {len(df):,}")
    lines.append("")

    if score_col in df.columns:
        s = df[score_col].dropna()
        lines.append(f"{h2}Belonging score")
        lines.append(f"{bullet}mean: {s.mean():.1f}")
        lines.append(f"{bullet}median: {s.median():.1f}")
        lines.append(f"{bullet}std: {s.std():.1f}")
        lines.append(f"{bullet}n scored: {len(s):,}")
        lines.append("")

    stressor_cols = [c for c in STRESSOR_COLUMNS if c in df.columns]
    if stressor_cols:
        lines.append(f"{h2}Stressor prevalence")
        for c in stressor_cols:
            lines.append(f"{bullet}{c}: {df[c].mean():.1%}")
        lines.append("")

        stack = count_stressor_stack(df)
        lines.append(f"{h2}Stressor stack")
        lines.append(f"{bullet}mean stressors per respondent: {stack.mean_stack:.2f}")
        for k, v in stack.counts.items():
            lines.append(f"{bullet}{k} stressor(s): {v:,} respondents")
        lines.append("")

    if group_by and group_by in df.columns:
        lines.append(f"{h2}By {group_by}")
        grp = df.groupby(group_by, dropna=False)
        for name, sub in grp:
            lines.append(f"{bullet}{name}: n={len(sub):,}"
                         + (f", mean {score_col}={sub[score_col].mean():.1f}"
                            if score_col in sub.columns else ""))
        lines.append("")

    lines.append(f"{h2}Ethical note")
    lines.append(ETHICAL_NOTE)

    text = "\n".join(lines).rstrip() + "\n"

    if path is not None:
        Path(path).write_text(text, encoding="utf-8")

    return text
