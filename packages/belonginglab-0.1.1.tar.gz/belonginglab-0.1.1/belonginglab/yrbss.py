"""YRBSS-specific helpers: load the CDC 2023 fixed-width ASCII file and recode.

CDC YRBSS uses a "1 = criterion met, 2 = not met, NaN = missing" convention for
``QN``-prefix recoded variables. belonginglab's internal convention is
"1 = yes / criterion met, 0 = no, NaN = missing". ``prepare_yrbss`` converts
between the two so the rest of the pipeline works unmodified.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd

from ._schema import YRBSS_2023

_SAS_COL_RE = re.compile(
    r"^@(\d+)\s+([A-Za-z_][A-Za-z0-9_]*)\s+(\$?)(\d+)(?:\.(\d+))?\.?",
    re.IGNORECASE,
)


def load_yrbss_fixed_width(
    data_path: str | Path,
    sas_program_path: str | Path,
    encoding: str = "latin-1",
) -> pd.DataFrame:
    """Load a YRBSS ``.dat`` fixed-width file using the CDC-provided SAS program.

    The SAS program defines each variable's start column and width. Character
    variables are read as strings; numeric variables are coerced to numeric.
    """
    data_path = Path(data_path)
    sas_program_path = Path(sas_program_path)

    cols: list[tuple[str, int, int, bool]] = []
    in_input = False
    for line in sas_program_path.read_text().splitlines():
        s = line.strip()
        if s.lower().startswith("input"):
            in_input = True
            continue
        if in_input and s == ";":
            break
        if in_input:
            m = _SAS_COL_RE.match(s)
            if m:
                start = int(m.group(1))
                name = m.group(2)
                is_str = bool(m.group(3))
                width = int(m.group(4))
                cols.append((name, start, width, is_str))

    if not cols:
        raise ValueError(f"No variables parsed from SAS program at {sas_program_path}.")

    colspecs = [(s - 1, s - 1 + w) for _, s, w, _ in cols]
    names = [n for n, _, _, _ in cols]
    df = pd.read_fwf(data_path, colspecs=colspecs, names=names, dtype=str,
                     encoding=encoding, keep_default_na=False)

    for name, _, _, is_str in cols:
        if not is_str:
            df[name] = pd.to_numeric(df[name].str.strip().replace("", pd.NA),
                                     errors="coerce")
    for c in df.select_dtypes(include="object").columns:
        df[c] = df[c].str.strip().replace("", pd.NA)

    return df


def _recode_yes_no(series: pd.Series) -> pd.Series:
    v = pd.to_numeric(series, errors="coerce")
    arr = np.where(v == 1, 1, np.where(v == 2, 0, np.nan))
    return pd.Series(pd.array(arr, dtype="Int8"), index=series.index)


_REVERSE_CODED = {"connectedness", "supportive_adult"}

_POSITIVE_YN = {
    "bullied_school",
    "bullied_electronic",
    "racism_school",
    "unfair_discipline",
    "social_media_hours",
    "sad_hopeless",
}


def prepare_yrbss(
    df: pd.DataFrame,
    variables: Iterable[str] | None = None,
) -> pd.DataFrame:
    """Recode YRBSS ``QN``-style variables from 1/2/NaN to 1/0/NaN.

    After mapping raw Q-codes with ``map_variables``, call this to convert the
    canonical variables to belonginglab's internal convention. ``connectedness``
    and ``supportive_adult`` are kept in their "higher = more positive" form
    (1 = criterion met, 0 = not met), so that low-connectedness flagging via
    ``flag_stressors(..., low_connectedness_threshold=0)`` works.

    Parameters
    ----------
    df : DataFrame
        DataFrame that already has canonical column names (use ``map_variables``
        first).
    variables : iterable of str, optional
        Subset of canonical variables to recode. Defaults to all recognized
        YRBSS-coded variables present in ``df``.
    """
    out = df.copy()
    targets = list(variables) if variables else [
        v for v in (list(_POSITIVE_YN) + list(_REVERSE_CODED)) if v in out.columns
    ]
    for v in targets:
        if v in out.columns:
            out[v] = _recode_yes_no(out[v])
    return out


__all__ = [
    "YRBSS_2023",
    "load_yrbss_fixed_width",
    "prepare_yrbss",
]
