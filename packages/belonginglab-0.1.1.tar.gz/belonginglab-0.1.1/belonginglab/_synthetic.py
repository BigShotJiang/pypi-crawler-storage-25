"""Synthetic YRBSS-shaped data for tests, examples, and quickstart.

This is NOT real survey data. It produces a DataFrame with the same column
names and coding scheme belonginglab expects, so users can try the pipeline
end-to-end without downloading the CDC release.
"""

from __future__ import annotations

import numpy as np
import pandas as pd


def make_synthetic_yrbss(n: int = 500, seed: int = 0) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    return pd.DataFrame({
        "sex": rng.choice([1, 2], size=n),
        "grade": rng.choice([1, 2, 3, 4], size=n),
        "race_ethnicity": rng.choice([1, 2, 3, 4, 5, 6, 7], size=n),
        "connectedness": rng.choice([1, 2, 3, 4, 5], size=n, p=[0.08, 0.15, 0.25, 0.32, 0.20]),
        "bullied_school": rng.choice([0, 1], size=n, p=[0.80, 0.20]),
        "bullied_electronic": rng.choice([0, 1], size=n, p=[0.84, 0.16]),
        "racism_school": rng.choice([0, 1], size=n, p=[0.70, 0.30]),
        "unfair_discipline": rng.choice([0, 1], size=n, p=[0.82, 0.18]),
        "social_media_hours": rng.choice([0, 1, 2, 3, 4, 5, 6, 7], size=n,
                                         p=[0.05, 0.08, 0.12, 0.18, 0.22, 0.18, 0.10, 0.07]),
        "sad_hopeless": rng.choice([0, 1], size=n, p=[0.58, 0.42]),
        "supportive_adult": rng.choice([0, 1], size=n, p=[0.30, 0.70]),
    })
