"""Subgroup comparison utilities."""

from __future__ import annotations

import pandas as pd

from .stressors import STRESSOR_COLUMNS


def compare_groups(
    df: pd.DataFrame,
    by: str,
    score_col: str = "belonging_score",
) -> pd.DataFrame:
    """Summarize belonging score and stressor prevalence by a grouping column.

    Returns one row per group with: n, mean/median/std of the belonging score,
    and mean (prevalence) of each stressor flag that is present in ``df``.
    """
    if by not in df.columns:
        raise KeyError(f"Grouping column {by!r} not in df.")

    has_score = score_col in df.columns
    stressor_cols = [c for c in STRESSOR_COLUMNS if c in df.columns]

    rows = []
    for group_value, sub in df.groupby(by, dropna=False):
        row: dict[str, object] = {by: group_value, "n": len(sub)}
        if has_score:
            row[f"{score_col}_mean"] = sub[score_col].mean()
            row[f"{score_col}_median"] = sub[score_col].median()
            row[f"{score_col}_std"] = sub[score_col].std()
        for col in stressor_cols:
            row[f"{col}_prevalence"] = sub[col].mean()
        rows.append(row)

    return pd.DataFrame(rows).sort_values(by).reset_index(drop=True)
