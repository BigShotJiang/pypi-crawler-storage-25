import pytest

from belonginglab import (
    compare_groups,
    compute_belonging_score,
    flag_stressors,
    generate_summary_report,
    make_synthetic_yrbss,
)


def _pipeline(n=300, seed=20):
    df = make_synthetic_yrbss(n=n, seed=seed)
    df = compute_belonging_score(df)
    df = flag_stressors(df)
    return df


def test_compare_groups_basic():
    df = _pipeline()
    out = compare_groups(df, by="grade")
    assert "n" in out.columns
    assert "belonging_score_mean" in out.columns
    assert "stressor_bullying_prevalence" in out.columns
    assert out["n"].sum() == len(df)


def test_compare_groups_missing_column():
    df = _pipeline()
    with pytest.raises(KeyError):
        compare_groups(df, by="does_not_exist")


def test_generate_summary_report_markdown():
    df = _pipeline()
    md = generate_summary_report(df, output="markdown", group_by="sex")
    assert md.startswith("# belonginglab")
    assert "Ethical note" in md
    assert "Stressor prevalence" in md


def test_generate_summary_report_writes_file(tmp_path):
    df = _pipeline()
    p = tmp_path / "report.md"
    generate_summary_report(df, path=p)
    assert p.exists()
    assert "belonginglab" in p.read_text()


def test_generate_summary_report_invalid_output():
    df = _pipeline()
    with pytest.raises(ValueError):
        generate_summary_report(df, output="pdf")
