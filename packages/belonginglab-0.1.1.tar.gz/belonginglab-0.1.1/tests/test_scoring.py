import pytest

from belonginglab import compute_belonging_score, make_synthetic_yrbss


def test_belonging_score_added():
    df = make_synthetic_yrbss(n=200, seed=3)
    out = compute_belonging_score(df)
    assert "belonging_score" in out.columns
    assert out["belonging_score"].between(0, 100).all()


def test_belonging_score_raw():
    df = make_synthetic_yrbss(n=200, seed=4)
    out = compute_belonging_score(df, scale_0_100=False)
    assert not out["belonging_score"].between(0, 100).all() or out["belonging_score"].std() > 0


def test_belonging_score_higher_connectedness_higher_score():
    df = make_synthetic_yrbss(n=400, seed=5)
    out = compute_belonging_score(df, scale_0_100=False)
    corr = out["connectedness"].corr(out["belonging_score"])
    assert corr > 0


def test_belonging_score_higher_sadness_lower_score():
    df = make_synthetic_yrbss(n=400, seed=6)
    out = compute_belonging_score(df, scale_0_100=False)
    corr = out["sad_hopeless"].corr(out["belonging_score"])
    assert corr < 0


def test_belonging_score_custom_weights_recorded():
    df = make_synthetic_yrbss(n=100, seed=7)
    out = compute_belonging_score(df, weights={"connectedness": 2.0})
    assert out.attrs["belonging_score_weights"]["connectedness"] == 2.0


def test_belonging_score_unknown_method():
    df = make_synthetic_yrbss(n=10, seed=8)
    with pytest.raises(ValueError):
        compute_belonging_score(df, method="mystery")


def test_belonging_score_requires_any_component():
    import pandas as pd
    df = pd.DataFrame({"unrelated": [1, 2, 3]})
    with pytest.raises(ValueError):
        compute_belonging_score(df)
