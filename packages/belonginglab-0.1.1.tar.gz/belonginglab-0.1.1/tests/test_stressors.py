import pytest

from belonginglab import (
    STRESSOR_COLUMNS,
    count_stressor_stack,
    find_stressor_clusters,
    flag_stressors,
    make_synthetic_yrbss,
)


def test_flag_stressors_produces_all_flags():
    df = make_synthetic_yrbss(n=100, seed=10)
    flagged = flag_stressors(df)
    for col in STRESSOR_COLUMNS:
        assert col in flagged.columns
        assert flagged[col].isin([0, 1]).all()


def test_count_stressor_stack_summary():
    df = flag_stressors(make_synthetic_yrbss(n=300, seed=11))
    s = count_stressor_stack(df)
    assert 0 <= s.mean_stack <= len(STRESSOR_COLUMNS)
    assert s.counts.sum() == len(df)
    assert "Mean stressors" in s.summary()


def test_count_stressor_stack_missing_flags_raises():
    df = make_synthetic_yrbss(n=10, seed=12)
    with pytest.raises(KeyError):
        count_stressor_stack(df)


def test_find_stressor_clusters_alias():
    df = flag_stressors(make_synthetic_yrbss(n=50, seed=13))
    result = find_stressor_clusters(df, features=["bullied_school", "racism_school"])
    assert result.counts.sum() == len(df)


def test_flag_stressors_partial_data():
    import pandas as pd
    df = pd.DataFrame({"connectedness": [1, 2, 3, 4, 5]})
    out = flag_stressors(df)
    assert out["stressor_low_connectedness"].tolist() == [1, 1, 0, 0, 0]
    assert (out["stressor_bullying"] == 0).all()
