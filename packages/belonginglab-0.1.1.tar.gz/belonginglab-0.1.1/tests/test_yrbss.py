"""Tests for YRBSS-specific helpers and YRBSS-mode stressor flagging."""

import numpy as np
import pandas as pd
import pytest

from belonginglab import (
    count_stressor_stack,
    flag_stressors,
    map_variables,
    prepare_yrbss,
)


def _yrbss_frame():
    """Minimal YRBSS-coded frame with canonical column names."""
    return pd.DataFrame({
        "bullied_school":      [1, 2, 1, 2, np.nan, 1],
        "bullied_electronic":  [2, 2, 1, 1, 2, np.nan],
        "racism_school":       [1, 2, 2, 1, 2, 2],
        "unfair_discipline":   [2, 2, 1, 1, 2, np.nan],
        "social_media_hours":  [1, 2, 1, 2, 1, np.nan],
        "connectedness":       [1, 1, 2, 2, np.nan, 1],
        "sad_hopeless":        [1, 2, 1, 1, 2, np.nan],
    })


def test_prepare_yrbss_recodes_12_to_10():
    df = _yrbss_frame()
    out = prepare_yrbss(df)
    assert out["bullied_school"].tolist()[:4] == [1, 0, 1, 0]
    assert pd.isna(out["bullied_school"].iloc[4])
    assert out["sad_hopeless"].tolist()[:2] == [1, 0]


def test_flag_stressors_yrbss_mode_basic():
    df = _yrbss_frame()
    out = flag_stressors(df, yrbss=True)
    assert out["stressor_bullying"].iloc[0] == 1
    assert out["stressor_bullying"].iloc[1] == 0
    assert out["stressor_bullying"].iloc[2] == 1
    assert out["stressor_discrimination"].iloc[2] == 1
    assert out["stressor_discrimination"].iloc[1] == 0
    assert out["stressor_heavy_social_media"].iloc[0] == 1
    assert out["stressor_heavy_social_media"].iloc[1] == 0
    assert out["stressor_low_connectedness"].iloc[0] == 0
    assert out["stressor_low_connectedness"].iloc[2] == 1


def test_flag_stressors_yrbss_preserves_na():
    df = _yrbss_frame()
    out = flag_stressors(df, yrbss=True)
    assert pd.isna(out["stressor_heavy_social_media"].iloc[5])
    assert pd.isna(out["stressor_low_connectedness"].iloc[4])


def test_flag_stressors_generic_mode_preserves_na():
    df = pd.DataFrame({
        "bullied_school": [1, 0, np.nan],
        "bullied_electronic": [0, 0, np.nan],
        "connectedness": [5, 1, np.nan],
        "social_media_hours": [0, 7, np.nan],
    })
    out = flag_stressors(df, yrbss=False)
    assert out["stressor_bullying"].tolist()[:2] == [1, 0]
    assert pd.isna(out["stressor_bullying"].iloc[2])
    assert out["stressor_low_connectedness"].iloc[1] == 1
    assert out["stressor_low_connectedness"].iloc[0] == 0
    assert pd.isna(out["stressor_low_connectedness"].iloc[2])


def test_count_stressor_stack_complete_cases_only():
    df = _yrbss_frame()
    flagged = flag_stressors(df, yrbss=True)
    s = count_stressor_stack(flagged, complete_cases=True)
    assert s.counts.sum() <= len(df)
    assert s.counts.sum() >= 1


def test_map_then_flag_yrbss_mode_end_to_end():
    """Recommended flow for raw YRBSS data: map -> flag with yrbss=True."""
    raw = pd.DataFrame({
        "Q2": [1, 2, 1, 2],
        "Q3": [1, 2, 3, 4],
        "QN24": [1, 2, 1, 2],
        "QN25": [2, 2, 1, 2],
        "QN23": [1, 2, 1, 2],
        "QN105": [2, 2, 1, 1],
        "QN80":  [1, 2, 1, 2],
        "QN103": [1, 1, 2, 2],
        "QN26":  [1, 2, 1, 2],
    })
    mapped = map_variables(raw, schema="yrbss_2023")
    flagged = flag_stressors(mapped, yrbss=True)
    assert flagged["stressor_bullying"].tolist() == [1, 0, 1, 0]
    assert flagged["stressor_discrimination"].tolist() == [1, 0, 1, 1]
    assert flagged["stressor_heavy_social_media"].tolist() == [1, 0, 1, 0]
    assert flagged["stressor_low_connectedness"].tolist() == [0, 0, 1, 1]


def test_map_prepare_then_flag_with_binary_thresholds():
    """Alternative flow: if you call prepare_yrbss, you must pass binary thresholds."""
    raw = pd.DataFrame({
        "QN24": [1, 2, 1, 2],
        "QN25": [2, 2, 1, 2],
        "QN103": [1, 1, 2, 2],
        "QN80":  [1, 2, 1, 2],
    })
    mapped = map_variables(raw, schema="yrbss_2023")
    prepared = prepare_yrbss(mapped)
    flagged = flag_stressors(
        prepared,
        heavy_social_media_threshold=1,
        low_connectedness_threshold=0,
    )
    assert flagged["stressor_bullying"].tolist() == [1, 0, 1, 0]
    assert flagged["stressor_heavy_social_media"].tolist() == [1, 0, 1, 0]
    assert flagged["stressor_low_connectedness"].tolist() == [0, 0, 1, 1]
