import pandas as pd
import pytest

from belonginglab import clean_yrbss, load_yrbss, make_synthetic_yrbss, map_variables


def test_map_variables_renames_known_columns():
    raw = pd.DataFrame({"QN24": [1, 2], "QN26": [2, 1], "other": [1, 2]})
    out = map_variables(raw, schema="yrbss_2023")
    assert "bullied_school" in out.columns
    assert "sad_hopeless" in out.columns
    assert "other" in out.columns


def test_map_variables_drop_unmapped():
    raw = pd.DataFrame({"QN24": [1, 2], "other": [1, 2]})
    out = map_variables(raw, schema="yrbss_2023", keep_unmapped=False)
    assert list(out.columns) == ["bullied_school"]


def test_map_variables_accepts_custom_mapping():
    raw = pd.DataFrame({"BULLY": [0, 1]})
    out = map_variables(raw, schema={"bullied_school": "BULLY"})
    assert "bullied_school" in out.columns


def test_clean_yrbss_replaces_sentinels():
    raw = pd.DataFrame({"a": ["", " ", ".", "1"], "b": [1, 2, 3, 4]})
    cleaned = clean_yrbss(raw)
    assert cleaned["a"].isna().sum() == 3


def test_clean_yrbss_subgroup_filter():
    df = make_synthetic_yrbss(n=100, seed=1)
    filtered = clean_yrbss(df, subgroup={"grade": [3, 4]})
    assert set(filtered["grade"].unique()).issubset({3, 4})


def test_load_yrbss_unknown_extension(tmp_path):
    bad = tmp_path / "data.txt"
    bad.write_text("nope")
    with pytest.raises(ValueError):
        load_yrbss(bad)


def test_load_yrbss_csv_roundtrip(tmp_path):
    df = make_synthetic_yrbss(n=20, seed=2)
    p = tmp_path / "syn.csv"
    df.to_csv(p, index=False)
    loaded = load_yrbss(p)
    assert len(loaded) == 20
    assert set(df.columns).issubset(loaded.columns)
