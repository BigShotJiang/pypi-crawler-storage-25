"""End-to-end quickstart using synthetic data (no CDC download required)."""

from belonginglab import (
    compare_groups,
    compute_belonging_score,
    flag_stressors,
    generate_summary_report,
    make_synthetic_yrbss,
)


def main() -> None:
    df = make_synthetic_yrbss(n=1000, seed=42)
    df = compute_belonging_score(df)
    df = flag_stressors(df)

    print(df["belonging_score"].describe(), "\n")
    print(compare_groups(df, by="grade"), "\n")
    print(generate_summary_report(df, group_by="sex"))


if __name__ == "__main__":
    main()
