import os
from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()

SUPPORTED_PROVIDERS = {
    "openai":    "gpt-* / o*  (e.g. gpt-4o, gpt-4o-mini, o1, o3)",
    "anthropic": "claude-*    (e.g. claude-opus-4-6, claude-sonnet-4-6, claude-haiku-4-5)",
}

# Active model — set at startup via configure() from CLI args
MODEL: str = "claude-sonnet-4-6"

_chat_client: OpenAI | None = None
_embed_client: OpenAI | None = None


def _detect_provider(model: str) -> str | None:
    m = model.lower()
    if m.startswith("gpt") or m.startswith("o"):
        return "openai"
    if m.startswith("claude"):
        return "anthropic"
    return None


def configure(model: str) -> None:
    """Set the active model. Exits with an error if the provider is not supported."""
    provider = _detect_provider(model)
    if provider is None:
        lines = ["", f"  Unsupported model: {model!r}", "", "  Supported providers:"]
        for name, example in SUPPORTED_PROVIDERS.items():
            lines.append(f"    {name}: {example}")
        print("\n".join(lines))
        raise SystemExit(1)

    global MODEL, _chat_client
    MODEL = model
    _chat_client = None  # reset so get_client() rebuilds for the new model


def get_client() -> OpenAI:
    """Return the chat completion client for the active MODEL/provider."""
    global _chat_client
    if _chat_client is None:
        provider = _detect_provider(MODEL)
        if provider == "anthropic":
            _chat_client = OpenAI(
                api_key=os.getenv("ANTHROPIC_API_KEY"),
                base_url=os.getenv("ANTHROPIC_BASE_URL", "https://api.anthropic.com/v1/"),
                max_retries=3,
                timeout=60.0,
            )
        elif provider == "openai":
            _chat_client = OpenAI(
                api_key=os.getenv("OPENAI_API_KEY"),
                base_url=os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1"),
                max_retries=3,
                timeout=60.0,
            )
        else:
            lines = ["", f"  Unsupported model: {MODEL!r}", "", "  Supported providers:"]
            for name, example in SUPPORTED_PROVIDERS.items():
                lines.append(f"    {name}: {example}")
            print("\n".join(lines))
            raise SystemExit(1)
    return _chat_client


def get_embed_client() -> OpenAI:
    """Return an OpenAI client for embeddings (always OpenAI, regardless of chat provider)."""
    global _embed_client
    if _embed_client is None:
        _embed_client = OpenAI(
            api_key=os.getenv("OPENAI_API_KEY"),
            max_retries=3,
            timeout=60.0,
        )
    return _embed_client
