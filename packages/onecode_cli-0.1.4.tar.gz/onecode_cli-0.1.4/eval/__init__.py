"""Evaluation module — analyzes and evaluates modules in a codebase."""

from eval.module_analyzer import make_module_analyzer
from eval.golden_dataset_generator import (
    generate_golden_dataset,
    generate_datasets_batch,
)
from eval.ragas_metrics import create_ragas_evaluator

__all__ = [
    "make_module_analyzer",
    "generate_golden_dataset",
    "generate_datasets_batch",
    "create_ragas_evaluator",
]
