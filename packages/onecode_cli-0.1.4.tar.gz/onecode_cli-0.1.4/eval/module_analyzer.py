"""Module analyzer — identifies and categorizes modules/agents in a codebase."""

from kg.graph import KnowledgeGraph


def make_module_analyzer(kg: KnowledgeGraph):
    """Factory function that returns a module analyzer function."""

    def analyze(query: str) -> str:
        """Analyze and report on modules/agents in the codebase."""
        modules = _analyze_modules(kg)
        return _format_module_report(modules)

    return analyze


def _analyze_modules(kg: KnowledgeGraph) -> dict:
    """
    Analyze the knowledge graph to identify modules/agents.
    Returns a dict with counts, categorized lists, and detailed information.
    """
    modules = {
        "total_count": 0,
        "by_structure_type": {},
        "by_module_kind": {},
        "by_level": {},
        "modules_list": [],
    }

    class_nodes = [v for v in kg.vertices.values() if v.label == "class"]
    file_nodes = [v for v in kg.vertices.values() if v.label == "file"]

    # Identify agent-like classes
    agent_classes = [
        v
        for v in class_nodes
        if "agent" in v.properties.get("name", "").lower()
    ]

    # Identify all Python files with "agent" in name
    agent_files = [
        v
        for v in file_nodes
        if "agent" in v.properties.get("path", "").lower()
        and v.properties.get("path", "").endswith(".py")
    ]

    modules["total_count"] = len(agent_classes) + len(agent_files)

    # Process class-based modules
    for cls in agent_classes:
        name = cls.properties.get("name", "unknown")
        docstring = cls.properties.get("docstring", "")
        description = docstring.split("\n")[0] if docstring else "No description"
        methods = cls.properties.get("methods", [])

        # Analyze class for LLM and tool usage
        module_kind, details = _classify_module_kind_detailed(
            name, description, ""
        )

        modules["modules_list"].append(
            {
                "name": name,
                "structure_type": "class",
                "level": "component",
                "module_kind": module_kind,
                "description": description,
                "uses_llm": details.get("uses_llm", False),
                "uses_tools": details.get("uses_tools", False),
                "methods": len(methods),
            }
        )

        modules["by_structure_type"]["class"] = (
            modules["by_structure_type"].get("class", 0) + 1
        )
        modules["by_level"]["component"] = modules["by_level"].get("component", 0) + 1
        modules["by_module_kind"][module_kind] = (
            modules["by_module_kind"].get(module_kind, 0) + 1
        )

    # Process module-level files
    for file_node in agent_files:
        path = file_node.properties.get("path", "unknown")
        content = file_node.properties.get("content", "")
        description = _infer_module_description(path, content)

        # Analyze file for LLM and tool usage
        module_kind, details = _classify_module_kind_detailed(
            path, description, content
        )

        modules["modules_list"].append(
            {
                "name": path,
                "structure_type": "module",
                "level": "top-level",
                "module_kind": module_kind,
                "description": description,
                "uses_llm": details.get("uses_llm", False),
                "uses_tools": details.get("uses_tools", False),
            }
        )

        modules["by_structure_type"]["module"] = (
            modules["by_structure_type"].get("module", 0) + 1
        )
        modules["by_level"]["top-level"] = (
            modules["by_level"].get("top-level", 0) + 1
        )
        modules["by_module_kind"][module_kind] = (
            modules["by_module_kind"].get(module_kind, 0) + 1
        )

    return modules


def _classify_module_kind_detailed(
    name: str, description: str, content: str
) -> tuple[str, dict]:
    """
    Classify module kind based on LLM + tool usage.

    Classification rules:
    - LLM + tools/function calls → agentic
    - LLM (no tools) → genai
    - No LLM → non-agentic

    Returns: (module_kind, details_dict)
    """
    combined = (name + " " + description + " " + content).lower()

    # Analyze LLM and tool usage
    uses_llm = _uses_llm(combined)
    uses_tools = _uses_tools(content, combined)

    # Classify based on LLM + tool usage
    if uses_llm and uses_tools:
        return "agentic", {"uses_llm": True, "uses_tools": True}
    elif uses_llm:
        return "genai", {"uses_llm": True, "uses_tools": False}
    else:
        return "non-agentic", {"uses_llm": False, "uses_tools": False}


def _uses_llm(combined: str) -> bool:
    """
    Detect if module uses LLM by checking:
    - Imports from OpenAI, Anthropic
    - Function calls to LLM APIs
    - Keywords indicating LLM usage
    """
    llm_indicators = [
        "from openai",
        "from anthropic",
        "import openai",
        "import anthropic",
        "completion",
        "message(",
        "claude",
        "gpt",
    ]

    return any(indicator in combined for indicator in llm_indicators)


def _uses_tools(content: str, combined: str) -> bool:
    """
    Detect if module uses tools/function calling by checking:
    - Tool registration/schema definitions
    - Function calls to other agents
    - Tool execution patterns
    - Generator/factory functions that create callable tools
    """
    tool_indicators = [
        "make_",  # OneCode factory pattern
        "register(",
        "tool",
        "function_definitions",
        "schema",
        "callbacks",
        "fn=",  # OneCode pattern for function registration
        ".fn(",  # Calling registered functions
        "agent_spec",
    ]

    has_tool_patterns = any(indicator in combined for indicator in tool_indicators)

    # Check if module calls other agents (in OneCode context)
    has_agent_calls = "agent" in combined and ("(" in content or "fn" in content)

    return has_tool_patterns or has_agent_calls


def _infer_module_description(path: str, content: str) -> str:
    """
    Infer module description from docstring or factory function.
    """
    # Try to extract module docstring first
    docstring = _extract_module_docstring(content)
    if docstring and docstring.strip():
        return docstring.split("\n")[0]

    # Try to find make_* factory function and its docstring
    lines = content.split("\n")
    for i, line in enumerate(lines):
        if line.strip().startswith("def make_"):
            for j in range(i + 1, min(i + 10, len(lines))):
                next_line = lines[j].strip()
                if next_line.startswith('"""') or next_line.startswith("'''"):
                    quote = '"""' if next_line.startswith('"""') else "'''"
                    rest = next_line[3:]
                    if rest.endswith(quote):
                        desc = rest[: -len(quote)]
                    else:
                        desc = rest
                    return desc if desc else "Module factory function"

    # Fallback: infer from filename
    name = path.split("/")[-1].replace("_", " ").replace(".py", "")
    return f"{name.title()}"


def _extract_module_docstring(content: str) -> str:
    """Extract the first docstring from a Python module."""
    lines = content.split("\n")
    in_docstring = False
    docstring_lines = []

    for line in lines:
        stripped = line.strip()
        if not in_docstring and (stripped.startswith('"""') or stripped.startswith("'''")):
            in_docstring = True
            quote = '"""' if stripped.startswith('"""') else "'''"
            rest = stripped[3:]
            if rest.endswith(quote):
                return rest[: -len(quote)]
            docstring_lines.append(rest)
        elif in_docstring:
            if '"""' in stripped or "'''" in stripped:
                quote = '"""' if '"""' in stripped else "'''"
                idx = stripped.find(quote)
                docstring_lines.append(stripped[:idx])
                break
            else:
                docstring_lines.append(stripped)

    return "\n".join(docstring_lines)


def _format_module_report(modules: dict) -> str:
    """Format module analysis into a readable report."""
    lines = [
        "=" * 80,
        "MODULE/AGENT ANALYSIS REPORT",
        "=" * 80,
        f"\nTotal Modules/Agents: {modules['total_count']}",
    ]

    if modules["by_structure_type"]:
        lines.append("\nBy Structure Type:")
        for stype, count in sorted(modules["by_structure_type"].items()):
            lines.append(f"  - {stype}: {count}")

    if modules["by_module_kind"]:
        lines.append("\nBy Module Kind:")
        kind_order = ["agentic", "genai", "non-agentic"]
        for kind in kind_order:
            if kind in modules["by_module_kind"]:
                count = modules["by_module_kind"][kind]
                lines.append(f"  - {kind}: {count}")

    if modules["by_level"]:
        lines.append("\nBy Level:")
        for level, count in sorted(modules["by_level"].items()):
            lines.append(f"  - {level}: {count}")

    if modules["modules_list"]:
        lines.append("\n" + "-" * 80)
        lines.append("DETAILED LISTING")
        lines.append("-" * 80)
        for i, module in enumerate(modules["modules_list"], 1):
            lines.append(f"\n{i}. {module['name']}")
            lines.append(f"   Structure: {module['structure_type']}")
            lines.append(f"   Module Kind: {module['module_kind']}")
            lines.append(f"   Level: {module['level']}")

            # Show LLM and tool usage
            usage = []
            if module.get("uses_llm"):
                usage.append("uses LLM")
            if module.get("uses_tools"):
                usage.append("uses tools/calls")
            if usage:
                lines.append(f"   Capabilities: {', '.join(usage)}")

            lines.append(f"   Description: {module['description']}")
            if "methods" in module:
                lines.append(f"   Methods: {module['methods']}")

    lines.append("\n" + "=" * 80)
    return "\n".join(lines)
