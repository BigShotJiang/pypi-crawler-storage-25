"""Golden dataset generator — generates evaluation datasets for modules using LLM."""

import json
from dataclasses import dataclass
from typing import Optional
import config
from utils.retry import call_api


@dataclass
class GoldenDataset:
    """Container for golden evaluation dataset."""

    module_name: str
    module_kind: str
    questions: list[str]
    contexts: list[list[str]]
    answers: list[str]
    ground_truth: list[str]
    expected_tool_calls: Optional[list[list]] = None
    selected_tool_calls: Optional[list[list]] = None

    def to_dict(self) -> dict:
        """Convert dataset to dictionary."""
        return {
            "questions": self.questions,
            "contexts": self.contexts,
            "answers": self.answers,
            "ground_truth": self.ground_truth,
            "expected_tool_calls": self.expected_tool_calls,
            "selected_tool_calls": self.selected_tool_calls,
        }


def generate_golden_dataset(
    module_info: dict, num_samples: int = 5, module_content: str = "", codebase_root: str = ""
) -> GoldenDataset:
    """
    Generate or retrieve cached golden dataset for a module.

    First checks cache (based on module hash), returns cached dataset if valid.
    Otherwise generates using LLM and caches the result.

    Args:
        module_info: Module information from module_analyzer
            - name: Module name
            - module_kind: agentic, genai, or non-agentic
            - uses_llm: Whether module uses LLM
            - uses_tools: Whether module uses tools/calls
            - description: Module description
        num_samples: Number of samples to generate
        module_content: Optional module source code for deeper analysis
        codebase_root: Root path of codebase for cache location

    Returns:
        GoldenDataset object with test data (from cache or newly generated)
    """
    module_name = module_info.get("name", "unknown")
    module_kind = module_info.get("module_kind", "non-agentic")

    if module_kind == "non-agentic":
        return GoldenDataset(
            module_name=module_name,
            module_kind="non-agentic",
            questions=[],
            contexts=[],
            answers=[],
            ground_truth=[],
        )

    # Check cache first if codebase_root provided
    if codebase_root:
        from eval.dataset_cache import get_cached_dataset
        cached = get_cached_dataset(codebase_root, module_name, module_kind, module_content)
        if cached:
            # Slice cached dataset to match requested num_samples
            return GoldenDataset(
                module_name=cached.module_name,
                module_kind=cached.module_kind,
                questions=cached.questions[:num_samples],
                contexts=cached.contexts[:num_samples],
                answers=cached.answers[:num_samples],
                ground_truth=cached.ground_truth[:num_samples],
                expected_tool_calls=cached.expected_tool_calls[:num_samples] if cached.expected_tool_calls else None,
                selected_tool_calls=cached.selected_tool_calls[:num_samples] if cached.selected_tool_calls else None,
            )

    # Generate new dataset
    if module_kind == "genai":
        dataset = _generate_genai_dataset(module_info, num_samples, module_content)
    elif module_kind == "agentic":
        dataset = _generate_agentic_dataset(module_info, num_samples, module_content)
    else:
        dataset = GoldenDataset(
            module_name=module_name,
            module_kind=module_kind,
            questions=[],
            contexts=[],
            answers=[],
            ground_truth=[],
        )

    # Cache the result if codebase_root provided
    if codebase_root and dataset.questions:
        from eval.dataset_cache import save_dataset_cache
        save_dataset_cache(codebase_root, dataset, module_content)

    return dataset


def _generate_genai_dataset(
    module_info: dict, num_samples: int, module_content: str = ""
) -> GoldenDataset:
    """
    Generate golden dataset for GenAI modules using LLM.

    GenAI modules: Uses LLM but no tool calls.
    Generates questions, contexts, answers, and ground truth using the LLM
    to understand the module's purpose and behavior.
    """
    module_name = module_info.get("name", "unknown")
    description = module_info.get("description", "")

    # Step 1: Understand the module purpose
    module_analysis = _analyze_module_purpose(module_name, description, module_content)

    # Step 2: Generate test cases using LLM
    dataset_json = _generate_dataset_with_llm(
        module_name=module_name,
        module_purpose=module_analysis,
        num_samples=num_samples,
        module_kind="genai",
    )

    # Step 3: Parse and structure the dataset
    try:
        data = json.loads(dataset_json)
        questions = data.get("questions", [])
        contexts = data.get("contexts", [])
        answers = data.get("answers", [])
        ground_truth = data.get("ground_truth", [])

        # Ensure we have exactly num_samples
        questions = questions[:num_samples]
        contexts = contexts[:num_samples]
        answers = answers[:num_samples]
        ground_truth = ground_truth[:num_samples]

        return GoldenDataset(
            module_name=module_name,
            module_kind="genai",
            questions=questions,
            contexts=contexts,
            answers=answers,
            ground_truth=ground_truth,
        )
    except (json.JSONDecodeError, KeyError, IndexError) as e:
        print(f"[Warning] Failed to parse LLM response for {module_name}: {e}")
        return _fallback_dataset(module_name, num_samples, "genai")


def _generate_agentic_dataset(
    module_info: dict, num_samples: int, module_content: str = ""
) -> GoldenDataset:
    """
    Generate golden dataset for Agentic modules using LLM.

    Agentic modules: Uses LLM + tool/function calls.
    Generates questions, contexts, answers, ground truth, AND tool call sequences.
    """
    module_name = module_info.get("name", "unknown")
    description = module_info.get("description", "")

    # Step 1: Understand the module purpose and tools
    module_analysis = _analyze_module_purpose(module_name, description, module_content)
    tools_analysis = _extract_tool_signatures(module_name, module_content)

    # Step 2: Generate test cases with tool calls using LLM
    dataset_json = _generate_dataset_with_llm(
        module_name=module_name,
        module_purpose=module_analysis,
        tools=tools_analysis,
        num_samples=num_samples,
        module_kind="agentic",
    )

    # Step 3: Parse and structure the dataset
    try:
        if not dataset_json or not dataset_json.strip():
            raise ValueError("Empty LLM response")

        data = json.loads(dataset_json)
        questions = data.get("questions", [])
        contexts = data.get("contexts", [])
        answers = data.get("answers", [])
        ground_truth = data.get("ground_truth", [])
        expected_tools = data.get("expected_tool_calls", [])
        selected_tools = data.get("selected_tool_calls", [])

        # Ensure we have exactly num_samples
        questions = questions[:num_samples]
        contexts = contexts[:num_samples]
        answers = answers[:num_samples]
        ground_truth = ground_truth[:num_samples]
        expected_tools = expected_tools[:num_samples]
        selected_tools = selected_tools[:num_samples]

        return GoldenDataset(
            module_name=module_name,
            module_kind="agentic",
            questions=questions,
            contexts=contexts,
            answers=answers,
            ground_truth=ground_truth,
            expected_tool_calls=expected_tools,
            selected_tool_calls=selected_tools,
        )
    except (json.JSONDecodeError, KeyError, IndexError, ValueError) as e:
        print(f"[Warning] Failed to parse LLM response for {module_name}: {e}")
        if dataset_json and len(dataset_json) > 50:
            print(f"  Response preview: {dataset_json[:100]}...")
        return _fallback_dataset(module_name, num_samples, "agentic")


def _analyze_module_purpose(
    module_name: str, description: str, module_content: str = ""
) -> str:
    """
    Use LLM to analyze and understand the module's purpose.

    Returns a concise description of what the module does.
    """
    prompt = f"""Analyze this module and provide a concise description of its purpose:

Module: {module_name}
Description: {description}

{f"Code snippet: {module_content[:500]}" if module_content else ""}

Provide a 1-2 sentence summary of what this module does and its primary function."""

    def call_llm():
        client = config.get_client()
        response = client.chat.completions.create(
            model=config.MODEL,
            max_tokens=200,
            messages=[{"role": "user", "content": prompt}],
        )
        return response.choices[0].message.content

    try:
        analysis = call_api(call_llm)
        return analysis.strip()
    except Exception as e:
        print(f"[Warning] Failed to analyze module {module_name}: {e}")
        return description or f"{module_name} module"


def _extract_tool_signatures(module_name: str, module_content: str = "") -> str:
    """
    Extract and identify tool/function signatures from module content.

    For agentic modules, identifies what tools/functions the module might call.
    """
    if not module_content:
        return "No tool signatures available"

    prompt = f"""Extract the main tools, functions, or services that this module uses or calls.
Only include actual function definitions or tool calls, not imports.

Module code:
{module_content[:1000]}

Provide a list of tool/function names and their purposes."""

    def call_llm():
        client = config.get_client()
        response = client.chat.completions.create(
            model=config.MODEL,
            max_tokens=300,
            messages=[{"role": "user", "content": prompt}],
        )
        return response.choices[0].message.content

    try:
        tools = call_api(call_llm)
        return tools.strip()
    except Exception as e:
        print(f"[Warning] Failed to extract tools from {module_name}: {e}")
        return "Available tools not determined"


def _generate_dataset_with_llm(
    module_name: str,
    module_purpose: str,
    num_samples: int = 5,
    module_kind: str = "genai",
    tools: str = "",
) -> str:
    """
    Use LLM to generate diverse test cases for the module.

    Generates questions, contexts, answers, and ground truth that are
    realistic and representative of how the module would be used.
    """
    tool_calls_example = ""
    if module_kind == "agentic":
        tool_calls_example = """,
  "expected_tool_calls": [
    [{"name": "search", "args": {"query": "example"}}, {"name": "process", "args": {}}],
    [{"name": "fetch", "args": {}}]
  ],
  "selected_tool_calls": [
    [{"name": "search", "args": {"query": "example"}}, {"name": "process", "args": {}}],
    [{"name": "fetch", "args": {}}]
  ]"""

    prompt = f"""You MUST output ONLY a JSON object. Do NOT write any code, explanations, or markdown.

MODULE BEING TESTED:
- Name: {module_name}
- Module Type: {module_kind}
- Purpose: {module_purpose}

YOUR TASK:
Create a test dataset JSON with exactly {num_samples} samples for evaluating this module.
This is TEST DATA ONLY - not implementation code.

REQUIRED JSON STRUCTURE:
{{
  "questions": ["q1", "q2"],
  "contexts": [["context1", "context2", "context3"], ["context1", "context2", "context3"]],
  "answers": ["answer1", "answer2"],
  "ground_truth": ["truth1", "truth2"]{tool_calls_example}
}}

RULES:
1. Return ONLY valid JSON - nothing else
2. Each array must have exactly {num_samples} items
3. questions: example queries/inputs to the {module_name}
4. contexts: 3 supporting text chunks per question
5. answers: what the module outputs for each question
6. ground_truth: the expected correct result
{"7. expected_tool_calls & selected_tool_calls: sequences of tool calls for this agent" if module_kind == "agentic" else ""}

START IMMEDIATELY WITH {{ CHARACTER. NO OTHER TEXT."""

    def call_llm():
        # Hardcoded to gpt-4o-mini for dataset generation (independent of user's model)
        # Reason: Claude has JSON parsing issues; gpt-4o-mini is more reliable for structured output
        import os
        from openai import OpenAI
        client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            max_tokens=2000,
            temperature=0,  # Use temperature 0 for consistent JSON output
            messages=[{"role": "user", "content": prompt}],
        )
        content = response.choices[0].message.content
        if not content:
            raise ValueError("Empty response from LLM")

        # Clean up response - remove markdown code blocks if present
        if "```" in content:
            parts = content.split("```")
            if len(parts) >= 2:
                content = parts[1]
                if content.startswith("json"):
                    content = content[4:]

        # Remove trailing commas before closing brackets (invalid JSON syntax)
        import re
        content = re.sub(r',(\s*[\]}])', r'\1', content)

        return content.strip()

    try:
        dataset_json = call_api(call_llm)
        if not dataset_json or not dataset_json.strip():
            print(f"[Warning] LLM returned empty response for {module_name}")
            print(f"  Tip: Use gpt-4o-mini or gpt-4o for better JSON generation")
            return None
        return dataset_json
    except Exception as e:
        print(f"[Warning] Failed to generate dataset with LLM: {e}")
        print(f"  Tip: Use gpt-4o-mini or gpt-4o for better JSON generation")
        return None


def _fallback_dataset(
    module_name: str, num_samples: int, module_kind: str
) -> GoldenDataset:
    """
    Fallback dataset when LLM generation fails.

    Returns a basic dataset structure.
    """
    questions = [
        f"Test query {i} for {module_name}" for i in range(num_samples)
    ]
    contexts = [
        [f"Context section {j}" for j in range(3)] for _ in range(num_samples)
    ]
    answers = [f"Response to query {i}" for i in range(num_samples)]
    ground_truth = [f"Expected result {i}" for i in range(num_samples)]

    if module_kind == "agentic":
        expected_tools = [
            [{"name": "search", "args": {}}, {"name": "analyze", "args": {}}]
            for _ in range(num_samples)
        ]
        selected_tools = [
            [{"name": "search", "args": {}}, {"name": "analyze", "args": {}}]
            for _ in range(num_samples)
        ]
        return GoldenDataset(
            module_name=module_name,
            module_kind="agentic",
            questions=questions,
            contexts=contexts,
            answers=answers,
            ground_truth=ground_truth,
            expected_tool_calls=expected_tools,
            selected_tool_calls=selected_tools,
        )

    return GoldenDataset(
        module_name=module_name,
        module_kind=module_kind,
        questions=questions,
        contexts=contexts,
        answers=answers,
        ground_truth=ground_truth,
    )


def generate_datasets_batch(
    modules_list: list,
    num_samples: int = 5,
    module_contents: dict = None,
    codebase_root: str = "",
) -> dict[str, GoldenDataset]:
    """
    Generate or retrieve cached golden datasets for multiple modules in batch.

    Args:
        modules_list: List of module info dicts from module_analyzer
        num_samples: Number of samples per module
        module_contents: Optional dict mapping module names to source code
        codebase_root: Root path of codebase for cache location

    Returns:
        Dictionary mapping module name to GoldenDataset
    """
    module_contents = module_contents or {}
    datasets = {}

    for module_info in modules_list:
        module_name = module_info.get("name", "unknown")
        content = module_contents.get(module_name, "")

        dataset = generate_golden_dataset(module_info, num_samples, content, codebase_root)
        datasets[module_name] = dataset

        print(f"✓ Generated dataset for {module_name}")

    return datasets
