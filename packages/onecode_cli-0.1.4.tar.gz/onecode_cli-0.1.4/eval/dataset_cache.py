"""Golden dataset cache — stores and reuses generated test datasets."""

import json
import hashlib
from pathlib import Path
from typing import Optional
from eval.golden_dataset_generator import GoldenDataset


def _compute_module_hash(module_name: str, module_kind: str, module_content: str = "") -> str:
    """Compute hash of module for cache invalidation."""
    combined = f"{module_name}:{module_kind}:{module_content}"
    return hashlib.sha256(combined.encode()).hexdigest()[:16]


def _get_cache_dir(codebase_root: str) -> Path:
    """Get or create eval datasets cache directory."""
    cache_dir = Path(codebase_root) / ".onecode" / "eval_datasets"
    cache_dir.mkdir(parents=True, exist_ok=True)
    return cache_dir


def _get_cache_path(codebase_root: str, module_hash: str) -> Path:
    """Get path to cached dataset file."""
    return _get_cache_dir(codebase_root) / f"{module_hash}.json"


def _get_manifest_path(codebase_root: str) -> Path:
    """Get path to cache manifest."""
    return _get_cache_dir(codebase_root) / "manifest.json"


def _load_manifest(codebase_root: str) -> dict:
    """Load cache manifest."""
    manifest_path = _get_manifest_path(codebase_root)
    if manifest_path.exists():
        try:
            with open(manifest_path) as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return {}
    return {}


def _save_manifest(codebase_root: str, manifest: dict):
    """Save cache manifest."""
    manifest_path = _get_manifest_path(codebase_root)
    with open(manifest_path, "w") as f:
        json.dump(manifest, f, indent=2)


def get_cached_dataset(
    codebase_root: str,
    module_name: str,
    module_kind: str,
    module_content: str = "",
) -> Optional[GoldenDataset]:
    """
    Load cached golden dataset if available and valid.

    Returns None if cache miss or invalid.
    """
    module_hash = _compute_module_hash(module_name, module_kind, module_content)
    cache_path = _get_cache_path(codebase_root, module_hash)

    if not cache_path.exists():
        return None

    # Check manifest to validate cache
    manifest = _load_manifest(codebase_root)
    entry = manifest.get(module_name)

    if not entry or entry.get("hash") != module_hash:
        return None

    # Load cached dataset
    try:
        with open(cache_path) as f:
            data = json.load(f)
            return GoldenDataset(
                module_name=data["module_name"],
                module_kind=data["module_kind"],
                questions=data["questions"],
                contexts=data["contexts"],
                answers=data["answers"],
                ground_truth=data["ground_truth"],
                expected_tool_calls=data.get("expected_tool_calls"),
                selected_tool_calls=data.get("selected_tool_calls"),
            )
    except (json.JSONDecodeError, KeyError, IOError):
        return None


def save_dataset_cache(
    codebase_root: str,
    dataset: GoldenDataset,
    module_content: str = "",
):
    """
    Save golden dataset to cache.

    Updates manifest with module hash for future validation.
    """
    module_hash = _compute_module_hash(
        dataset.module_name, dataset.module_kind, module_content
    )
    cache_path = _get_cache_path(codebase_root, module_hash)

    # Save dataset
    with open(cache_path, "w") as f:
        json.dump(dataset.to_dict(), f, indent=2)

    # Update manifest
    manifest = _load_manifest(codebase_root)
    manifest[dataset.module_name] = {
        "hash": module_hash,
        "kind": dataset.module_kind,
        "num_samples": len(dataset.questions),
    }
    _save_manifest(codebase_root, manifest)


def clear_dataset_cache(codebase_root: str):
    """Clear all cached datasets."""
    cache_dir = _get_cache_dir(codebase_root)
    for f in cache_dir.glob("*.json"):
        f.unlink()
