import os
from pathlib import Path

SUPPORTED_EXTENSIONS = {
    ".py", ".js", ".ts", ".jsx", ".tsx", ".java", ".go", ".rs",
    ".cpp", ".c", ".h", ".cs", ".rb", ".php", ".swift", ".kt",
    ".md", ".txt", ".yaml", ".yml", ".json", ".toml",
}

IGNORE_DIRS = {
    ".git", "__pycache__", "node_modules", ".venv", "venv",
    "dist", "build", ".idea", ".vscode", ".mypy_cache",
}


def parse_codebase(root_path: str) -> list[dict]:
    """Walk root_path and return a list of file dicts with path and content."""
    root = Path(root_path).resolve()
    files = []

    for dirpath, dirnames, filenames in os.walk(root):
        # Prune ignored dirs in-place so os.walk skips them
        dirnames[:] = [d for d in dirnames if d not in IGNORE_DIRS]

        for filename in filenames:
            filepath = Path(dirpath) / filename
            if filepath.suffix not in SUPPORTED_EXTENSIONS:
                continue
            try:
                content = filepath.read_text(encoding="utf-8", errors="ignore")
                files.append({
                    "path": str(filepath.relative_to(root)),
                    "abs_path": str(filepath),
                    "extension": filepath.suffix,
                    "content": content,
                    "size": len(content),
                })
            except Exception:
                pass

    return files
