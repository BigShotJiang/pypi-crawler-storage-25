import openai
from typing import Callable, TypeVar

T = TypeVar("T")


def call_api(fn: Callable[[], T]) -> T:
    """
    Execute an API call with clear error messages.

    The SDK already retries transient errors (rate limits, server errors, timeouts)
    up to max_retries=3 with exponential back-off — so by the time an exception
    reaches here, retries are exhausted.  This wrapper translates raw SDK exceptions
    into human-readable RuntimeErrors that agents can catch and surface to the user.
    """
    try:
        return fn()
    except openai.AuthenticationError as e:
        raise RuntimeError(
            "API authentication failed — check your API key in .env "
            "(OPENAI_API_KEY / ANTHROPIC_API_KEY / GOOGLE_API_KEY)"
        ) from e
    except openai.RateLimitError as e:
        raise RuntimeError(
            "API rate limit exceeded after retries — please wait a moment and try again"
        ) from e
    except openai.APIConnectionError as e:
        raise RuntimeError(
            "Cannot connect to the API — check your internet connection"
        ) from e
    except openai.APITimeoutError as e:
        raise RuntimeError(
            "API request timed out — the model may be overloaded, try again"
        ) from e
    except openai.BadRequestError as e:
        raise RuntimeError(f"Bad API request (check prompt/model): {e}") from e
    except openai.APIError as e:
        raise RuntimeError(f"API error: {e}") from e
