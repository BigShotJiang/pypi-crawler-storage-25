import ast
import re
from pathlib import Path
from kg.graph import KnowledgeGraph, Vertex, Relationship
from kg.store import VectorStore
from kg.embedder import get_embedding
from utils.file_parser import parse_codebase, SUPPORTED_EXTENSIONS


# ── Text to embed per node type ──────────────────────────────────────────────

def _vertex_text(vertex: Vertex) -> str:
    p = vertex.properties
    if vertex.label == "file":
        return f"file: {p['path']}\n{p['content'][:500]}"
    if vertex.label == "class":
        return f"class {p['name']} in {p['file']}\n{p.get('docstring', '')}"
    if vertex.label == "function":
        return (
            f"def {p['name']} in {p['file']}\n"
            f"{p.get('signature', '')}\n{p.get('docstring', '')}"
        )
    return str(p)


# ── Python AST visitor ───────────────────────────────────────────────────────

class _PythonVisitor(ast.NodeVisitor):
    """Extract top-level classes and functions from a Python AST."""

    def __init__(self, file_path: str, kg: KnowledgeGraph):
        self.file_path = file_path
        self.kg = kg
        self._in_class = False

    def visit_ClassDef(self, node: ast.ClassDef):
        class_id = f"class:{self.file_path}:{node.name}"
        methods = [
            n.name for n in ast.walk(node)
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
        ]
        self.kg.add_vertex(Vertex(
            node_id=class_id,
            label="class",
            properties={
                "name": node.name,
                "file": self.file_path,
                "docstring": ast.get_docstring(node) or "",
                "methods": methods,
            },
        ))
        self.kg.add_relationship(Relationship(
            from_id=f"file:{self.file_path}",
            to_id=class_id,
            rel_type="CONTAINS",
        ))
        # Visit class body with flag set so methods are skipped at top level
        prev = self._in_class
        self._in_class = True
        self.generic_visit(node)
        self._in_class = prev

    def visit_FunctionDef(self, node: ast.FunctionDef):
        if self._in_class:
            return  # methods are captured via class node; skip here
        func_id = f"func:{self.file_path}:{node.name}"
        args = [a.arg for a in node.args.args]
        self.kg.add_vertex(Vertex(
            node_id=func_id,
            label="function",
            properties={
                "name": node.name,
                "file": self.file_path,
                "signature": f"def {node.name}({', '.join(args)})",
                "docstring": ast.get_docstring(node) or "",
            },
        ))
        self.kg.add_relationship(Relationship(
            from_id=f"file:{self.file_path}",
            to_id=func_id,
            rel_type="CONTAINS",
        ))
        self.generic_visit(node)

    visit_AsyncFunctionDef = visit_FunctionDef


# ── Import extraction ────────────────────────────────────────────────────────

def _python_imports(content: str) -> list[str]:
    imports = []
    for line in content.splitlines():
        m = re.match(r"^\s*(?:import|from)\s+([\w.]+)", line)
        if m:
            imports.append(m.group(1).replace(".", "/"))
    return imports


# ── Main builder ─────────────────────────────────────────────────────────────

def build_kg(root_path: str) -> tuple[KnowledgeGraph, VectorStore]:
    """
    Parse root_path codebase into a KnowledgeGraph + a FAISS VectorStore.

    Returns:
        kg    – vertex table + relationship table
        store – FAISS index with node_id metadata
    """
    files = parse_codebase(root_path)
    kg = KnowledgeGraph()

    # 1. Add file vertices and sub-nodes (classes, functions)
    for f in files:
        file_id = f"file:{f['path']}"
        kg.add_vertex(Vertex(
            node_id=file_id,
            label="file",
            properties={
                "path": f["path"],
                "abs_path": f["abs_path"],
                "extension": f["extension"],
                "content": f["content"],
            },
        ))
        if f["extension"] == ".py":
            try:
                tree = ast.parse(f["content"])
                _PythonVisitor(f["path"], kg).visit(tree)
            except SyntaxError:
                pass

    # 2. Add IMPORTS edges between file nodes
    file_ids = {vid for vid in kg.vertices if vid.startswith("file:")}
    for vid in file_ids:
        vertex = kg.vertices[vid]
        if vertex.properties["extension"] != ".py":
            continue
        for imp in _python_imports(vertex.properties["content"]):
            for target_id in file_ids:
                if imp in target_id:
                    kg.add_relationship(Relationship(
                        from_id=vid,
                        to_id=target_id,
                        rel_type="IMPORTS",
                    ))

    # 3. Embed every vertex and insert into FAISS store
    store = VectorStore()
    total = len(kg.vertices)
    print(f"Embedding {total} nodes...", flush=True)
    for i, vertex in enumerate(kg.vertices.values(), 1):
        emb = get_embedding(_vertex_text(vertex))
        store.add(vertex.node_id, emb)
        if i % 10 == 0 or i == total:
            print(f"  {i}/{total}", end="\r", flush=True)
    print()

    return kg, store


# ── Incremental refresh ───────────────────────────────────────────────────────

def _nodes_for_file(all_ids: set[str], rel_path: str) -> set[str]:
    """Return all node IDs associated with a file (file, class, func nodes)."""
    prefixes = (f"file:{rel_path}", f"class:{rel_path}:", f"func:{rel_path}:")
    return {nid for nid in all_ids if any(nid.startswith(p) for p in prefixes)}


def refresh_kg(
    kg: KnowledgeGraph,
    store: VectorStore,
    root_path: str,
    changed: list[str],   # relative paths that were created or modified
    deleted: list[str],   # relative paths that were removed
) -> None:
    """
    Incrementally update the KG and vector store after filesystem changes.
    - Removes stale nodes for deleted/changed files.
    - Re-parses and re-embeds changed/created files.
    - Rebuilds the FAISS index from the updated embedding cache (no extra API calls).
    """
    root = Path(root_path).resolve()
    all_ids = set(kg.vertices.keys())

    # Collect node IDs to remove (deleted files + old versions of changed files)
    to_remove: set[str] = set()
    for rel_path in deleted + changed:
        to_remove |= _nodes_for_file(all_ids, rel_path)

    # Remove from vertex table and embedding cache
    for nid in to_remove:
        kg.vertices.pop(nid, None)
        store.remove(nid)

    # Rebuild relationship table (drop any edge that referenced a removed node)
    kg.relationships = [
        r for r in kg.relationships
        if r.from_id not in to_remove and r.to_id not in to_remove
    ]
    kg._adj = {}
    for r in kg.relationships:
        kg._adj.setdefault(r.from_id, []).append((r.to_id, r.rel_type))

    # Re-parse and re-embed changed/created files
    new_node_ids: set[str] = set()
    for rel_path in changed:
        file_path = root / rel_path
        if not file_path.exists() or file_path.suffix not in SUPPORTED_EXTENSIONS:
            continue
        try:
            content = file_path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue

        file_id = f"file:{rel_path}"
        kg.add_vertex(Vertex(
            node_id=file_id,
            label="file",
            properties={
                "path": rel_path,
                "abs_path": str(file_path),
                "extension": file_path.suffix,
                "content": content,
            },
        ))
        new_node_ids.add(file_id)

        if file_path.suffix == ".py":
            before = set(kg.vertices.keys())
            try:
                _PythonVisitor(rel_path, kg).visit(ast.parse(content))
            except SyntaxError:
                pass
            new_node_ids |= set(kg.vertices.keys()) - before

    # Embed new nodes (only the freshly added ones)
    for nid in new_node_ids:
        vertex = kg.vertices.get(nid)
        if vertex:
            store._embeddings[nid] = get_embedding(_vertex_text(vertex))

    # Rebuild FAISS index from updated cache (no API calls)
    store.rebuild()
    print(f"  [kg] refreshed — removed: {len(to_remove)}, re-indexed: {len(new_node_ids)}")
