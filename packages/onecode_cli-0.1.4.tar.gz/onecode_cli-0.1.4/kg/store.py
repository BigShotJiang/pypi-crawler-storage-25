import faiss
import numpy as np


class VectorStore:
    """
    FAISS-backed vector store with an embedding cache.
    The cache allows removing individual nodes and rebuilding the index
    without making new embedding API calls.
    """

    def __init__(self):
        self._index: faiss.Index | None = None
        self._node_ids: list[str] = []
        self._embeddings: dict[str, list[float]] = {}  # node_id -> embedding (cache)

    def add(self, node_id: str, embedding: list[float]):
        self._embeddings[node_id] = embedding
        vec = np.array([embedding], dtype=np.float32)
        if self._index is None:
            self._index = faiss.IndexFlatIP(vec.shape[1])
        faiss.normalize_L2(vec)
        self._index.add(vec)
        self._node_ids.append(node_id)

    def remove(self, node_id: str):
        """Remove a node from the cache. Call rebuild() to apply to the FAISS index."""
        self._embeddings.pop(node_id, None)

    def rebuild(self):
        """Rebuild the FAISS index from the embedding cache (no API calls)."""
        if not self._embeddings:
            self._index = None
            self._node_ids = []
            return

        node_ids = list(self._embeddings.keys())
        vecs = np.array(list(self._embeddings.values()), dtype=np.float32)
        faiss.normalize_L2(vecs)

        self._index = faiss.IndexFlatIP(vecs.shape[1])
        self._index.add(vecs)
        self._node_ids = node_ids

    def search(self, query_embedding: list[float], top_k: int = 5) -> list[str]:
        """Return up to top_k node_ids most similar to query_embedding."""
        if self._index is None or self._index.ntotal == 0:
            return []
        vec = np.array([query_embedding], dtype=np.float32)
        faiss.normalize_L2(vec)
        k = min(top_k, self._index.ntotal)
        _, indices = self._index.search(vec, k)
        return [self._node_ids[i] for i in indices[0] if i >= 0]

    @property
    def size(self) -> int:
        return len(self._embeddings)
