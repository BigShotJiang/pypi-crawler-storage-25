import config
from utils.retry import call_api

EMBED_MODEL = "text-embedding-3-small"


def get_embedding(text: str) -> list[float]:
    """Return a normalized embedding vector for the given text."""
    text = text.replace("\n", " ")[:8000]
    response = call_api(
        lambda: config.get_embed_client().embeddings.create(model=EMBED_MODEL, input=text)
    )
    return response.data[0].embedding
