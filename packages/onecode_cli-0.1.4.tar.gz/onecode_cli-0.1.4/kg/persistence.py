import json
from pathlib import Path

from kg.graph import KnowledgeGraph, Vertex, Relationship
from kg.store import VectorStore
from utils.file_parser import SUPPORTED_EXTENSIONS, IGNORE_DIRS

CACHE_DIR = ".onecode"


# ── Helpers ───────────────────────────────────────────────────────────────────

def _cache_dir(root_path: str) -> Path:
    return Path(root_path).resolve() / CACHE_DIR


def _build_manifest(root_path: str) -> dict[str, float]:
    """Return {relative_path: mtime} for every indexed file under root_path."""
    root = Path(root_path).resolve()
    manifest: dict[str, float] = {}
    for filepath in root.rglob("*"):
        if any(part in IGNORE_DIRS for part in filepath.parts):
            continue
        if not filepath.is_file() or filepath.suffix not in SUPPORTED_EXTENSIONS:
            continue
        rel = str(filepath.relative_to(root))
        manifest[rel] = filepath.stat().st_mtime
    return manifest


# ── Save / Load ───────────────────────────────────────────────────────────────

def save_kg(kg: KnowledgeGraph, store: VectorStore, root_path: str) -> None:
    """Persist KG vertices, relationships, embeddings, and file manifest to disk."""
    cache = _cache_dir(root_path)
    cache.mkdir(exist_ok=True)

    vertices = [
        {"node_id": v.node_id, "label": v.label, "properties": v.properties}
        for v in kg.vertices.values()
    ]
    (cache / "vertices.json").write_text(
        json.dumps(vertices), encoding="utf-8"
    )

    rels = [
        {"from_id": r.from_id, "to_id": r.to_id, "rel_type": r.rel_type}
        for r in kg.relationships
    ]
    (cache / "relationships.json").write_text(
        json.dumps(rels), encoding="utf-8"
    )

    (cache / "embeddings.json").write_text(
        json.dumps(store._embeddings), encoding="utf-8"
    )

    (cache / "manifest.json").write_text(
        json.dumps(_build_manifest(root_path)), encoding="utf-8"
    )


def _load_raw(root_path: str) -> tuple[KnowledgeGraph, VectorStore] | None:
    """Load KG and store from disk. Returns None if cache is missing or corrupt."""
    cache = _cache_dir(root_path)
    required = ["vertices.json", "relationships.json", "embeddings.json", "manifest.json"]
    if not all((cache / f).exists() for f in required):
        return None
    try:
        vertices = json.loads((cache / "vertices.json").read_text())
        rels = json.loads((cache / "relationships.json").read_text())
        embeddings = json.loads((cache / "embeddings.json").read_text())
    except Exception:
        return None

    kg = KnowledgeGraph()
    for v in vertices:
        kg.add_vertex(Vertex(
            node_id=v["node_id"],
            label=v["label"],
            properties=v["properties"],
        ))
    for r in rels:
        kg.add_relationship(Relationship(
            from_id=r["from_id"],
            to_id=r["to_id"],
            rel_type=r["rel_type"],
        ))

    store = VectorStore()
    store._embeddings = embeddings
    store.rebuild()
    return kg, store


def _get_changes(root_path: str) -> tuple[list[str], list[str]]:
    """Compare current file mtimes to the saved manifest. Returns (changed, deleted)."""
    manifest_path = _cache_dir(root_path) / "manifest.json"
    try:
        old = json.loads(manifest_path.read_text())
    except Exception:
        return [], []

    current = _build_manifest(root_path)
    changed = [p for p, mtime in current.items() if old.get(p) != mtime]
    deleted = [p for p in old if p not in current]
    return changed, deleted


# ── Public entry point ────────────────────────────────────────────────────────

def load_or_build_kg(root_path: str) -> tuple[KnowledgeGraph, VectorStore]:
    """
    Load KG from cache when possible, refreshing only changed/deleted files.
    Falls back to a full build when no cache exists.
    Saves state to disk before returning.
    """
    # Defer import to avoid circular dependency (builder imports from here indirectly)
    from kg.builder import build_kg, refresh_kg

    cached = _load_raw(root_path)

    if cached is not None:
        kg, store = cached
        changed, deleted = _get_changes(root_path)

        if changed or deleted:
            print(
                f"  Cache found — {len(changed)} changed, {len(deleted)} deleted. "
                "Refreshing..."
            )
            refresh_kg(kg, store, root_path, changed, deleted)
        else:
            print(f"  Loaded from cache — no changes detected.")

        save_kg(kg, store, root_path)
        return kg, store

    # No cache — full build
    kg, store = build_kg(root_path)
    save_kg(kg, store, root_path)
    return kg, store
