from dataclasses import dataclass, field


@dataclass
class Vertex:
    node_id: str            # e.g. "file:kg/graph.py", "class:kg/graph.py:KnowledgeGraph"
    label: str              # "file" | "class" | "function"
    properties: dict        # label-specific metadata


@dataclass
class Relationship:
    from_id: str
    to_id: str
    rel_type: str           # "CONTAINS" | "IMPORTS"


class KnowledgeGraph:
    def __init__(self):
        # Vertex table: node_id -> Vertex
        self.vertices: dict[str, Vertex] = {}
        # Relationship table: append-only list
        self.relationships: list[Relationship] = []
        # Adjacency index for fast neighbor lookup: from_id -> [(to_id, rel_type)]
        self._adj: dict[str, list[tuple[str, str]]] = {}

    def add_vertex(self, vertex: Vertex):
        self.vertices[vertex.node_id] = vertex

    def add_relationship(self, rel: Relationship):
        self.relationships.append(rel)
        self._adj.setdefault(rel.from_id, []).append((rel.to_id, rel.rel_type))

    def neighbors(self, node_id: str) -> list[tuple[str, str]]:
        """Return outgoing edges as [(to_id, rel_type), ...]."""
        return self._adj.get(node_id, [])

    def summary(self) -> str:
        label_counts: dict[str, int] = {}
        for v in self.vertices.values():
            label_counts[v.label] = label_counts.get(v.label, 0) + 1
        label_str = ", ".join(f"{l}:{c}" for l, c in sorted(label_counts.items()))
        return f"{len(self.vertices)} nodes ({label_str}) | {len(self.relationships)} edges"
