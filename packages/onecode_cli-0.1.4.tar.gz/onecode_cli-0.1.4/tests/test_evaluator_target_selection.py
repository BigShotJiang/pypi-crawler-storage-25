"""Tests for evaluation target selection logic."""

import pytest


class TestTargetSelection:
    """Test target module selection and filtering logic."""

    @pytest.fixture
    def mock_modules(self):
        """Mock module info as returned by module analyzer (both file paths and class names)."""
        return [
            {"name": "agents/evaluator.py", "kind": "agentic"},
            {"name": "EvaluatorAgent", "kind": "agentic"},  # Class-based module
            {"name": "agents/supervisor.py", "kind": "agentic"},
            {"name": "SupervisorAgent", "kind": "agentic"},  # Class-based module
            {"name": "agents/reader.py", "kind": "agentic"},
            {"name": "ReaderAgent", "kind": "agentic"},  # Class-based module
            {"name": "agents/coder.py", "kind": "agentic"},
            {"name": "CoderAgent", "kind": "agentic"},  # Class-based module
            {"name": "agents/executor.py", "kind": "agentic"},
            {"name": "agents/summarizer.py", "kind": "genai"},
            {"name": "eval/ragas_metrics.py", "kind": "non-agentic"},
            {"name": "kg/graph.py", "kind": "non-agentic"},
        ]

    def filter_modules(self, modules_info, target):
        """Apply the target filtering logic from evaluator.py (updated with better matching)."""
        filtered = []
        if target != "codebase":
            target_lower = target.lower()
            for m in modules_info:
                module_name_raw = m["name"].lower()
                module_name = module_name_raw.split("/")[-1].replace(".py", "")

                # Try removing "agent" suffix for class names
                module_name_no_agent = module_name[:-5] if module_name.endswith("agent") else module_name

                # Try removing "_agent" suffix from target
                target_without_agent = target_lower[:-6] if target_lower.endswith("_agent") else target_lower

                # Try adding "_agent" suffix to target
                target_with_agent = target_lower if target_lower.endswith("_agent") else target_lower + "_agent"

                # Match if target appears anywhere in:
                # - Exact filename match (with/without _agent in target)
                # - Substring in filename
                # - Class names (with/without "agent" suffix)
                # - Full path
                matches = (
                    target_lower == module_name or
                    target_without_agent == module_name or
                    target_with_agent == module_name or
                    target_lower in module_name or
                    target_without_agent in module_name or
                    target_lower in module_name_no_agent or
                    target_lower in module_name_raw
                )

                if matches:
                    filtered.append(m)
        else:
            filtered = modules_info
        return filtered

    def test_exact_filename_match(self, mock_modules):
        """Test exact filename matching for summarizer."""
        filtered = self.filter_modules(mock_modules, "summarizer")

        assert len(filtered) == 1
        assert filtered[0]["name"] == "agents/summarizer.py"

    def test_evaluator_exact_match(self, mock_modules):
        """Test exact match for evaluator (should match both file and class)."""
        filtered = self.filter_modules(mock_modules, "evaluator")

        # Should match both "agents/evaluator.py" and "EvaluatorAgent"
        assert len(filtered) == 2
        names = [m["name"] for m in filtered]
        assert "agents/evaluator.py" in names
        assert "EvaluatorAgent" in names

    def test_single_agent_match(self, mock_modules):
        """Test agent match for reader (should match both file and class)."""
        filtered = self.filter_modules(mock_modules, "reader")

        # Should match both "agents/reader.py" and "ReaderAgent"
        assert len(filtered) == 2
        names = [m["name"] for m in filtered]
        assert "agents/reader.py" in names
        assert "ReaderAgent" in names

    def test_codebase_no_filtering(self, mock_modules):
        """Test that 'codebase' target returns all modules."""
        filtered = self.filter_modules(mock_modules, "codebase")

        assert len(filtered) == len(mock_modules)
        assert filtered == mock_modules

    def test_class_based_module_match(self, mock_modules):
        """Test matching class-based modules (e.g., 'evaluator' matches 'EvaluatorAgent')."""
        filtered = self.filter_modules(mock_modules, "evaluator")

        # Should match both "agents/evaluator.py" and "EvaluatorAgent"
        assert len(filtered) == 2
        names = [m["name"] for m in filtered]
        assert "agents/evaluator.py" in names
        assert "EvaluatorAgent" in names

    def test_class_name_agent_suffix_removal(self, mock_modules):
        """Test that 'agent' suffix is removed from class names for matching."""
        filtered = self.filter_modules(mock_modules, "supervisor")

        # Should match both "agents/supervisor.py" and "SupervisorAgent"
        assert len(filtered) == 2
        names = [m["name"] for m in filtered]
        assert "agents/supervisor.py" in names
        assert "SupervisorAgent" in names

    def test_target_with_agent_suffix(self, mock_modules):
        """Test matching when target includes _agent suffix (e.g., 'coder_agent')."""
        filtered = self.filter_modules(mock_modules, "coder_agent")

        # Should match "agents/coder.py" and "CoderAgent" by removing _agent suffix
        assert len(filtered) == 2
        names = [m["name"] for m in filtered]
        assert "agents/coder.py" in names
        assert "CoderAgent" in names
