"""Tests for evaluation metrics filtering logic."""

import pytest


class TestMetricsFiltering:
    """Test metrics selection and filtering logic."""

    @pytest.fixture
    def mock_metrics(self):
        """Mock metrics data from evaluation."""
        return {
            "faithfulness_avg": 0.85,
            "hallucination_avg": 0.15,
            "answer_relevancy_avg": 0.92,
            "context_precision_avg": 0.88,
            "context_recall_avg": 0.78,
            "answer_accuracy_avg": 0.80,
            "response_groundedness_avg": 0.81,
            "agent_goal_accuracy_avg": 0.75,
            "tool_call_f1_avg": 0.70,
        }

    def filter_metrics_for_display(self, metrics, requested_metrics):
        """Apply metrics filtering logic from _format_evaluation_results."""
        displayed = []

        if requested_metrics:
            # Show only requested metrics
            for metric in requested_metrics:
                key = f"{metric}_avg"
                if key in metrics and metrics[key] is not None:
                    displayed.append(metric)
        else:
            # Show all available metrics
            possible_metrics = [
                "faithfulness",
                "hallucination",
                "answer_relevancy",
                "context_precision",
                "context_recall",
                "answer_accuracy",
                "response_groundedness",
                "agent_goal_accuracy",
                "tool_call_f1",
            ]
            for metric in possible_metrics:
                if metrics.get(f"{metric}_avg") is not None:
                    displayed.append(metric)

        return displayed

    def test_single_metric_request(self, mock_metrics):
        """Test filtering when single metric is requested."""
        displayed = self.filter_metrics_for_display(
            mock_metrics, ["answer_accuracy"]
        )

        assert displayed == ["answer_accuracy"]

    def test_multiple_metrics_request(self, mock_metrics):
        """Test filtering when multiple metrics are requested."""
        displayed = self.filter_metrics_for_display(
            mock_metrics, ["faithfulness", "hallucination"]
        )

        assert displayed == ["faithfulness", "hallucination"]

    def test_no_metrics_specified_shows_all(self, mock_metrics):
        """Test that empty metrics list shows all available metrics."""
        displayed = self.filter_metrics_for_display(mock_metrics, [])

        expected = [
            "faithfulness",
            "hallucination",
            "answer_relevancy",
            "context_precision",
            "context_recall",
            "answer_accuracy",
            "response_groundedness",
            "agent_goal_accuracy",
            "tool_call_f1",
        ]
        assert displayed == expected
