#!/usr/bin/env python3
"""Setup script for OneCode package."""

from setuptools import setup, find_packages

setup(
    packages=find_packages(),
)
