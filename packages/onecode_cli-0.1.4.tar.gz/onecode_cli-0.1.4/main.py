import argparse
import sys
from pathlib import Path
from kg.builder import refresh_kg
from kg.persistence import load_or_build_kg, save_kg
from agents.reader import retrieve
from agents.coder import make_coder
from agents.deleter import make_deleter
from agents.executor import make_executor
from agents.renamer import make_renamer
from agents.git_agent import make_git_agent
from agents.search import make_search
from agents.summarizer import make_summarizer
from agents.supervisor import Supervisor
from agents.evaluator import make_evaluation_agent
from eval.module_analyzer import make_module_analyzer
import config


def _parse_args():
    parser = argparse.ArgumentParser(
        prog="onecode",
        description="OneCode — natural-language codebase analysis and modification",
    )
    parser.add_argument(
        "codebase",
        nargs="?",
        help="Path to the codebase to analyse (default: current directory)",
    )
    parser.add_argument(
        "--model",
        default="claude-sonnet-4-6",
        metavar="MODEL",
        help=(
            "Model to use for chat completions "
            "(default: claude-sonnet-4-6). "
            "Examples: gpt-4o, gpt-4o-mini, claude-opus-4-6, claude-haiku-4-5"
        ),
    )
    return parser.parse_args()


def main():
    args = _parse_args()
    config.configure(args.model)

    print("OneCode - Codebase Analyzer")
    print("-" * 40)
    print(f"Model:    {args.model}")

    codebase_path = args.codebase or "."
    path = Path(codebase_path).expanduser().resolve()
    if not path.exists() or not path.is_dir():
        print(f"Error: '{path}' is not a valid directory.")
        sys.exit(1)

    print(f"Indexing: {path}")
    kg, store = load_or_build_kg(str(path))
    print(f"Ready:    {kg.summary()} | {store.size} embeddings")

    # KG refresh callback — called by coder/deleter/renamer after filesystem changes
    def on_kg_change(changed: list[str], deleted: list[str]):
        if changed or deleted:
            refresh_kg(kg, store, str(path), changed, deleted)
            save_kg(kg, store, str(path))  # persist updated state

    supervisor = Supervisor()

    supervisor.register(
        name="reader_agent",
        description=(
            "Semantic search over the codebase knowledge graph. "
            "Use for questions about code structure, logic, classes, and functions."
        ),
        fn=lambda q: retrieve(kg, store, q),
    )
    supervisor.register(
        name="search_agent",
        description=(
            "Exact or regex text search across all codebase files. "
            "Returns file:line matches. Use when you need to find a specific "
            "string, symbol, or pattern (e.g. all calls to a function)."
        ),
        fn=make_search(str(path)),
    )
    supervisor.register(
        name="coder_agent",
        description=(
            "Write new code or modify existing code and apply changes to disk. "
            "Provide a detailed instruction including what to create/change and "
            "relevant existing code (from reader_agent). User confirms before writing."
        ),
        fn=make_coder(str(path), on_change=on_kg_change),
    )
    supervisor.register(
        name="renamer_agent",
        description=(
            "Rename or move a file or directory within the codebase. "
            "Describe the source and destination (e.g. 'rename utils/parser.py to utils/file_parser.py'). "
            "User confirms before the operation."
        ),
        fn=make_renamer(str(path), on_change=on_kg_change),
    )
    supervisor.register(
        name="deleter_agent",
        description=(
            "Delete a file or directory from the codebase. "
            "Pass the relative path (e.g. 'tmp/scratch.py'). "
            "User confirms before deletion."
        ),
        fn=make_deleter(str(path), on_change=on_kg_change),
    )
    supervisor.register(
        name="executor_agent",
        description=(
            "Run a shell command from the codebase root and return exit code + stdout + stderr. "
            "Pass the exact command (e.g. 'python path/to/script.py' or 'python -m pytest'). "
            "If exit code is non-zero, the supervisor will fix and retry."
        ),
        fn=make_executor(str(path)),
    )
    supervisor.register(
        name="git_agent",
        description=(
            "Run git operations described in natural language "
            "(e.g. 'show status', 'commit with message X', 'show diff'). "
            "Read-only operations run directly; write operations require user confirmation."
        ),
        fn=make_git_agent(str(path)),
    )
    supervisor.register(
        name="summarizer_agent",
        description=(
            "Summarize long content (execution output, retrieved code, analysis results) "
            "into a concise summary. Use when output is too large to reason over directly."
        ),
        fn=make_summarizer(),
    )
    supervisor.register(
        name="module_analyzer",
        description=(
            "Analyze the codebase to identify, count, and categorize modules/agents. "
            "Returns a detailed report of all modules found, their types (class/module), "
            "levels (top-level/component), and descriptions. Use to understand codebase structure."
        ),
        fn=make_module_analyzer(kg),
    )
    supervisor.register(
        name="evaluator_agent",
        description=(
            "Evaluate modules in the codebase using RAGAS metrics (faithfulness, "
            "answer relevancy, context precision/recall, agent goal accuracy, tool call F1). "
            "Run natural language queries like 'evaluate the codebase', 'evaluate summarizer agent', "
            "or 'what is the faithfulness of coder agent'. Returns evaluation results with metric scores."
        ),
        fn=make_evaluation_agent(kg, codebase_root=str(path)),
    )

    print("\nType a question or task (or 'exit' to quit).")
    print("-" * 40)

    while True:
        try:
            question = input("\nYou: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye.")
            break

        if not question:
            continue
        if question.lower() in {"exit", "quit", "q"}:
            print("Goodbye.")
            break

        supervisor.run(question)  # supervisor streams the answer directly


if __name__ == "__main__":
    main()
