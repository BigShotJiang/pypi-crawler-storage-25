import json
import subprocess
from pathlib import Path
from typing import Callable
import config
from utils.retry import call_api

TIMEOUT_SECONDS = 30

# Git subcommands that only read state — no confirmation needed
_READ_ONLY = {"status", "diff", "log", "show", "ls-files", "describe", "shortlog"}

_GENERATE_PROMPT = """\
Convert the instruction to a single git command.
Return JSON: {"command": "git ..."}
Use only standard git commands. Do not chain commands with && or ;.
"""


def _needs_confirmation(command: str) -> bool:
    parts = command.strip().split()
    # Must start with 'git'
    if not parts or parts[0] != "git":
        return True
    subcmd = parts[1] if len(parts) > 1 else ""
    if subcmd in _READ_ONLY:
        return False
    # 'git branch' with no extra args just lists branches
    if subcmd == "branch" and len(parts) == 2:
        return False
    return True


def make_git_agent(root_path: str) -> Callable[[str], str]:
    """Return a git agent function bound to root_path."""
    root = Path(root_path).resolve()

    def git_op(instruction: str) -> str:
        # Use LLM to generate the git command
        try:
            resp = call_api(lambda: config.get_client().chat.completions.create(
                model=config.MODEL,
                messages=[
                    {"role": "system", "content": _GENERATE_PROMPT},
                    {"role": "user", "content": instruction},
                ],
                response_format={"type": "json_object"},
                temperature=0,
            ))
        except RuntimeError as e:
            return f"[git agent error] {e}"
        try:
            command = json.loads(resp.choices[0].message.content)["command"].strip()
        except (json.JSONDecodeError, KeyError):
            return "[git agent error] could not generate git command"

        # Confirm write operations before running
        if _needs_confirmation(command):
            print(f"\n{'='*60}")
            print(f"  Git command: {command}")
            print(f"{'='*60}")
            try:
                answer = input("Run this command? [y/N]: ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                answer = "n"
            if answer != "y":
                return f"Git command cancelled by user: {command}"

        try:
            result = subprocess.run(
                command,
                shell=True,
                cwd=root,
                capture_output=True,
                text=True,
                timeout=TIMEOUT_SECONDS,
            )
        except subprocess.TimeoutExpired:
            return f"[git agent] timed out after {TIMEOUT_SECONDS}s: {command}"
        except Exception as e:
            return f"[git agent] error: {e}"

        parts = [f"Command: {command}", f"Exit code: {result.returncode}"]
        if result.stdout.strip():
            parts.append(f"\n{result.stdout.strip()}")
        if result.stderr.strip():
            parts.append(f"\nSTDERR: {result.stderr.strip()}")
        return "\n".join(parts)

    return git_op
