import re
from pathlib import Path
from typing import Callable
import config
from utils.retry import call_api
from utils.file_parser import SUPPORTED_EXTENSIONS, IGNORE_DIRS

MAX_RESULTS = 60
MAX_LINE_CHARS = 300  # truncate very long lines (minified files, embedded data, etc.)

_EXTRACT_PROMPT = """\
Extract the exact search term or regex pattern from the user's query.
Return only the raw pattern string — no quotes, no explanation.
Examples:
  "search for all calls to build_kg"  →  build_kg
  "find TODO comments"                →  TODO
  "find all async def functions"      →  async def
  "where is VectorStore used"         →  VectorStore
"""


def _extract_pattern(query: str) -> str:
    """Use LLM to pull the actual search term out of a natural language query."""
    try:
        resp = call_api(lambda: config.get_client().chat.completions.create(
            model=config.MODEL,
            messages=[
                {"role": "system", "content": _EXTRACT_PROMPT},
                {"role": "user", "content": query},
            ],
            temperature=0,
        ))
        return resp.choices[0].message.content.strip().strip("\"'")
    except RuntimeError:
        return query  # fall back to using the raw query as the pattern


def make_search(root_path: str) -> Callable[[str], str]:
    """Return a search agent that does exact/regex text search across codebase files."""
    root = Path(root_path).resolve()

    def search(query: str) -> str:
        query = query.strip()

        # If the query is natural language (contains spaces), extract the pattern first
        pattern_str = _extract_pattern(query) if " " in query else query

        try:
            pattern = re.compile(pattern_str, re.IGNORECASE)
        except re.error:
            pattern = re.compile(re.escape(pattern_str), re.IGNORECASE)

        results: list[str] = []

        for filepath in sorted(root.rglob("*")):
            if any(part in IGNORE_DIRS for part in filepath.parts):
                continue
            if not filepath.is_file() or filepath.suffix not in SUPPORTED_EXTENSIONS:
                continue
            try:
                lines = filepath.read_text(encoding="utf-8", errors="ignore").splitlines()
            except Exception:
                continue

            rel = str(filepath.relative_to(root))
            for lineno, line in enumerate(lines, 1):
                if pattern.search(line):
                    snippet = line.strip()[:MAX_LINE_CHARS]
                    results.append(f"{rel}:{lineno}: {snippet}")
                    if len(results) >= MAX_RESULTS:
                        break
            if len(results) >= MAX_RESULTS:
                break

        if not results:
            return f"No matches found for: {pattern_str!r}"

        note = f"  (stopped at {MAX_RESULTS})" if len(results) == MAX_RESULTS else ""
        header = f"Found {len(results)} match(es) for {pattern_str!r}{note}:\n"
        return header + "\n".join(results)

    return search
