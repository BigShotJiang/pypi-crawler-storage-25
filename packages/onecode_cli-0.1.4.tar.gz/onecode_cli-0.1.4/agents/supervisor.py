import json
from dataclasses import dataclass
from typing import Callable
import config
from utils.retry import call_api

# Number of user/assistant exchange pairs to keep in conversation history
HISTORY_PAIRS = 10

# Hard cap on a single tool result appended to messages (~25k chars ≈ ~6k tokens)
MAX_TOOL_RESULT_CHARS = 25_000

# Agents that prompt the user — discard after one use per session to prevent re-prompting
USER_INTERACTION_AGENTS = {"coder_agent", "deleter_agent", "renamer_agent"}

SYSTEM_PROMPT = """\
You are a supervisor agent coordinating a codebase analysis system.

Available agents:
- reader_agent:      semantic search — finds relevant files, classes, and functions via knowledge graph
- search_agent:      exact/regex text search across codebase files, returns file:line matches
- coder_agent:       writes or modifies code and applies changes to disk
- renamer_agent:     renames or moves files and directories
- deleter_agent:     deletes files or directories
- executor_agent:    runs a shell command and returns exit code + stdout + stderr
- git_agent:         runs git operations (status, diff, log, commit, push, etc.)
- summarizer_agent:  condenses long content into a concise summary
- module_analyzer:   analyzes codebase to identify, count, and categorize modules/agents
- evaluation_agent:  evaluates modules using RAGAS metrics (faithfulness, relevancy, precision, recall, goal accuracy, tool F1)

Decision rules:
1. Questions about code structure/logic → reader_agent (semantic) or search_agent (exact term)
2. Writing or modifying code → reader_agent for context, then coder_agent with full details
3. Renaming or moving files → renamer_agent
4. Deleting files/dirs → deleter_agent
5. Running code or commands → executor_agent
6. Git operations → git_agent
7. Very long output needs condensing → summarizer_agent
8. Module evaluation (faithfulness, accuracy, metrics) → evaluation_agent
9. Executor returns non-zero exit code:
   a. Analyze stdout/stderr to understand the error
   b. Call reader_agent or search_agent for context if needed
   c. Call coder_agent to fix the bug
   d. Call executor_agent again to verify the fix
   e. Repeat until exit code is 0 or the error is unrecoverable
10. No agent needed → answer directly
"""


@dataclass
class AgentSpec:
    name: str
    description: str
    fn: Callable[[str], str]


class Supervisor:
    def __init__(self):
        self._agents: dict[str, AgentSpec] = {}
        self._history: list[dict] = []  # rolling user/assistant history

    def register(self, name: str, description: str, fn: Callable[[str], str]):
        self._agents[name] = AgentSpec(name=name, description=description, fn=fn)

    def _tool_schemas(self) -> list[dict]:
        return [
            {
                "type": "function",
                "function": {
                    "name": spec.name,
                    "description": spec.description,
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "query": {
                                "type": "string",
                                "description": "The specific query or instruction to pass to the agent.",
                            }
                        },
                        "required": ["query"],
                    },
                },
            }
            for spec in self._agents.values()
        ]

    def _call_agent(self, name: str, query: str) -> str:
        spec = self._agents.get(name)
        if spec is None:
            return f"[error] unknown agent: {name}"
        print(f"  [supervisor] → {name}")
        return spec.fn(query)

    def _trim_history(self):
        max_msgs = HISTORY_PAIRS * 2
        if len(self._history) > max_msgs:
            self._history = self._history[-max_msgs:]

    def run(self, user_query: str, max_rounds: int = 6) -> str:
        """
        Run the supervisor loop with streaming output and conversation history.
        Streams the final text answer to stdout in real time.
        Returns the full answer string.
        """
        messages = [
            {"role": "system", "content": SYSTEM_PROMPT},
            *self._history,
            {"role": "user", "content": user_query},
        ]
        all_tools = self._tool_schemas()
        active_tools = {spec["function"]["name"] for spec in all_tools}

        for _ in range(max_rounds):
            current_tools = [t for t in all_tools if t["function"]["name"] in active_tools]

            try:
                stream = call_api(lambda: config.get_client().chat.completions.create(
                    model=config.MODEL,
                    messages=messages,
                    tools=current_tools or None,
                    tool_choice="auto" if current_tools else None,
                    temperature=0.2,
                    stream=True,
                ))
            except RuntimeError as e:
                print(f"\n[error] {e}")
                return str(e)

            # Accumulate streamed response
            tool_calls_acc: dict[int, dict] = {}
            content_parts: list[str] = []
            streaming_to_user = False

            for chunk in stream:
                delta = chunk.choices[0].delta

                if delta.content:
                    # Only stream to user if no tool calls have appeared (final answer)
                    if not tool_calls_acc:
                        if not streaming_to_user:
                            print("\nAssistant: ", end="", flush=True)
                            streaming_to_user = True
                        print(delta.content, end="", flush=True)
                    content_parts.append(delta.content)

                if delta.tool_calls:
                    for tc in delta.tool_calls:
                        i = tc.index
                        if i not in tool_calls_acc:
                            tool_calls_acc[i] = {"id": "", "name": "", "args": ""}
                        if tc.id:
                            tool_calls_acc[i]["id"] = tc.id
                        if tc.function:
                            if tc.function.name:
                                tool_calls_acc[i]["name"] += tc.function.name
                            if tc.function.arguments:
                                tool_calls_acc[i]["args"] += tc.function.arguments

            content = "".join(content_parts)

            # No tool calls → this is the final answer (already streamed)
            if not tool_calls_acc:
                if streaming_to_user:
                    print()  # newline after streamed answer
                else:
                    print(f"\nAssistant: {content}")
                self._history.append({"role": "user", "content": user_query})
                self._history.append({"role": "assistant", "content": content})
                self._trim_history()
                return content

            # Tool-calling round — append assistant message and execute tools
            tool_calls = [tool_calls_acc[i] for i in sorted(tool_calls_acc)]
            messages.append({
                "role": "assistant",
                "content": content or None,
                "tool_calls": [
                    {
                        "id": tc["id"],
                        "type": "function",
                        "function": {"name": tc["name"], "arguments": tc["args"]},
                    }
                    for tc in tool_calls
                ],
            })

            stop_after_round = False
            for tc in tool_calls:
                result = self._call_agent(
                    tc["name"],
                    json.loads(tc["args"]).get("query", user_query),
                )
                if len(result) > MAX_TOOL_RESULT_CHARS:
                    result = result[:MAX_TOOL_RESULT_CHARS] + f"\n... [truncated — {len(result)} chars total]"
                messages.append({
                    "role": "tool",
                    "tool_call_id": tc["id"],
                    "content": result,
                })

                if tc["name"] in USER_INTERACTION_AGENTS:
                    active_tools.discard(tc["name"])
                if tc["name"] == "executor_agent":
                    stop_after_round = True

            if stop_after_round:
                break

        # max_rounds reached or executor finished — force final streamed answer
        try:
            final_stream = call_api(lambda: config.get_client().chat.completions.create(
                model=config.MODEL,
                messages=messages,
                temperature=0.2,
                stream=True,
            ))
        except RuntimeError as e:
            print(f"\n[error] {e}")
            return str(e)
        print("\nAssistant: ", end="", flush=True)
        parts: list[str] = []
        for chunk in final_stream:
            delta = chunk.choices[0].delta.content or ""
            if delta:
                print(delta, end="", flush=True)
                parts.append(delta)
        print()

        answer = "".join(parts)
        self._history.append({"role": "user", "content": user_query})
        self._history.append({"role": "assistant", "content": answer})
        self._trim_history()
        return answer
