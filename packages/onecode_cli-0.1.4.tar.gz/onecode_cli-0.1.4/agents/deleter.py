import shutil
from pathlib import Path
from typing import Callable


def make_deleter(
    root_path: str,
    on_change: Callable[[list[str], list[str]], None] | None = None,
) -> Callable[[str], str]:
    """
    Return a deleter agent function bound to root_path.
    Shows what will be deleted and asks [y/N] once before doing anything.
    on_change(changed, deleted) is called after deletion so the KG stays fresh.
    """
    root = Path(root_path).resolve()

    def delete(target: str) -> str:
        target = target.strip().strip("'\"")

        candidate = Path(target)
        file_path = candidate if candidate.is_absolute() else root / candidate
        file_path = file_path.resolve()

        try:
            file_path.relative_to(root)
        except ValueError:
            return f"[deleter] refused: '{file_path}' is outside the codebase root."

        if not file_path.exists():
            return f"[deleter] path not found: {file_path}"

        is_file = file_path.is_file()
        if is_file:
            preview = f"  Type : FILE\n  Path : {file_path}"
            all_file_rels = [str(file_path.relative_to(root))]
        else:
            all_files = [p for p in file_path.rglob("*") if p.is_file()]
            all_dirs = [p for p in file_path.rglob("*") if p.is_dir()]
            all_file_rels = [str(p.relative_to(root)) for p in all_files]
            preview = (
                f"  Type      : DIRECTORY\n"
                f"  Path      : {file_path}\n"
                f"  Contains  : {len(all_files)} file(s), {len(all_dirs)} subdirectory/ies"
            )

        print(f"\n{'='*60}")
        print(f"  Action: DELETE")
        print(preview)
        print(f"{'='*60}")

        try:
            answer = input("Delete this? [y/N]: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            answer = "n"

        if answer != "y":
            return f"Deletion cancelled by user: {file_path}"

        if is_file:
            file_path.unlink()
        else:
            shutil.rmtree(file_path)

        if on_change:
            on_change([], all_file_rels)

        return f"Deleted: {file_path}"

    return delete
