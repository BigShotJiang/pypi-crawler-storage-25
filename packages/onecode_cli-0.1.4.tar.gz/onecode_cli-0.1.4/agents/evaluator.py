"""Evaluation agent — evaluates modules using natural language queries."""

import asyncio
import json
from typing import Optional
import config
from kg.graph import KnowledgeGraph
from eval import (
    make_module_analyzer,
    generate_golden_dataset,
    create_ragas_evaluator,
)
from utils.retry import call_api


def make_evaluation_agent(kg: KnowledgeGraph, codebase_root: str = ""):
    """
    Factory function that returns an evaluation agent.

    Args:
        kg: Knowledge graph of the codebase
        codebase_root: Root path of codebase for dataset caching

    Returns:
        Evaluation agent function
    """

    def evaluate(query: str) -> str:
        """
        Evaluate modules based on natural language query.

        Args:
            query: Natural language query (e.g., "evaluate the codebase",
                   "evaluate summarizer agent",
                   "what is the faithfulness of coder agent")

        Returns:
            Formatted evaluation results
        """
        try:
            # Step 1: Analyze what the user is asking for
            evaluation_request = _parse_evaluation_query(query)

            if not evaluation_request:
                return "Unable to parse evaluation query. Try: 'evaluate the codebase', 'evaluate [agent_name]', or 'what metrics for [agent_name]'"

            print(f"\n[evaluator] Target: {evaluation_request['target']}")
            print(f"[evaluator] Metrics: {evaluation_request['metrics'] or 'all'}")
            print(f"[evaluator] Samples: {evaluation_request['num_samples']}")

            # Step 2: Get modules to evaluate
            print("[evaluator] Analyzing modules...")
            analyzer = make_module_analyzer(kg)
            analysis_output = analyzer("analyze modules")
            modules_info = _extract_modules_from_analysis(analysis_output)
            print(f"[evaluator] Found {len(modules_info)} evaluable modules")
            if modules_info:
                all_module_names = [m['name'] for m in modules_info]
                print(f"[evaluator] All modules: {all_module_names}")

            if not modules_info:
                return "No evaluable modules found in codebase"

            # Filter modules if specific agent requested
            if evaluation_request["target"] != "codebase":
                target_lower = evaluation_request["target"].lower()
                filtered = []

                for m in modules_info:
                    module_name_raw = m["name"].lower()

                    # Extract filename from path (e.g., "agents/summarizer.py" → "summarizer")
                    module_name = module_name_raw.split("/")[-1].replace(".py", "")

                    # Try removing "agent" suffix for class names (e.g., "readeragent" → "reader")
                    module_name_no_agent = module_name[:-5] if module_name.endswith("agent") else module_name

                    # Try removing "_agent" suffix from target (e.g., "summarizer_agent" → "summarizer")
                    target_without_agent = target_lower[:-6] if target_lower.endswith("_agent") else target_lower

                    # Try adding "_agent" suffix to target if not present (e.g., "reader" → "reader_agent")
                    target_with_agent = target_lower if target_lower.endswith("_agent") else target_lower + "_agent"

                    # Match if target appears anywhere in:
                    # - Exact filename match (with/without _agent in target)
                    # - Substring in filename
                    # - Class names (with/without "agent" suffix)
                    # - Full path

                    matches = (
                        target_lower == module_name or
                        target_without_agent == module_name or
                        target_with_agent == module_name or
                        target_lower in module_name or
                        target_without_agent in module_name or
                        target_lower in module_name_no_agent or
                        target_lower in module_name_raw
                    )

                    if matches:
                        filtered.append(m)

                modules_info = filtered
                print(f"[evaluator] Filtered to {len(modules_info)} module(s) for target '{evaluation_request['target']}'")

                if not modules_info:
                    return f"Module '{evaluation_request['target']}' not found"

            # Step 3: Run evaluation with proper async handling
            runner = asyncio.Runner()
            try:
                results = runner.run(
                    _evaluate_modules(
                        modules_info,
                        metrics=evaluation_request["metrics"],
                        num_samples=evaluation_request["num_samples"],
                        codebase_root=codebase_root,
                    )
                )
            finally:
                runner.close()

            # Step 4: Format results
            return _format_evaluation_results(results, evaluation_request)

        except Exception as e:
            return f"Evaluation error: {e}"

    return evaluate


def _parse_evaluation_query(query: str) -> Optional[dict]:
    """
    Parse natural language evaluation query using LLM to extract intent.

    Returns dict with:
    - target: "codebase" or agent name (reader, coder, executor, etc.)
    - metrics: list of metrics to compute (empty = all)
    - num_samples: number of test samples
    """

    # Agent descriptions for intelligent selection
    agent_descriptions = """
AVAILABLE AGENTS:
- reader_agent: Semantic search over codebase. Understands code structure, logic, classes, functions.
- search_agent: Exact/regex text search. Finds specific strings, symbols, patterns across files.
- coder_agent: Writes and modifies code. Creates new code or updates existing code.
- renamer_agent: Renames and moves files/directories within the codebase.
- deleter_agent: Deletes files and directories from the codebase.
- executor_agent: Runs shell commands. Executes code and returns output/errors.
- git_agent: Performs git operations (status, commit, diff, etc.).
- summarizer_agent: Condenses long content into summaries.
- module_analyzer: Identifies and categorizes modules/agents in the codebase.
- evaluator_agent: Evaluates modules using RAGAS metrics (faithfulness, accuracy, etc.).
- supervisor: Orchestrates all agents using natural language understanding.
"""

    prompt = f"""Extract the evaluation request from this query. Return ONLY valid JSON.

{agent_descriptions}

Query: "{query}"

INSTRUCTIONS:
1. Extract target agent based on user intent:
   - If user mentions a specific agent name → use that agent
   - If user describes what an agent does → match to appropriate agent(s)
   - If asking about "the codebase" or "all modules" → target is "codebase"
   - Examples: "code writer" → "coder", "code searcher" → "reader", "shell execution" → "executor"

2. Extract requested metrics (empty array = all metrics wanted):
   Metric names: faithfulness, hallucination, answer_relevancy, context_precision, context_recall, answer_accuracy, response_groundedness, agent_goal_accuracy, tool_call_f1
   Aliases:
   - "faithful", "truthfulness" → faithfulness
   - "hallucination", "hallucinate" → hallucination
   - "relevant", "relevance", "answer relevancy" → answer_relevancy
   - "precision", "context precision" → context_precision
   - "recall", "context recall" → context_recall
   - "accuracy", "answer accuracy" → answer_accuracy
   - "groundedness", "grounded", "response groundedness" → response_groundedness
   - "goal", "agent goal" → agent_goal_accuracy
   - "tool", "tool call" → tool_call_f1

3. Extract sample count:
   - "quick" or "few" → 2 samples
   - "comprehensive" or "detailed" → 10 samples
   - default → 5 samples

EXAMPLES:
- "quick evaluation" → {{"target": "codebase", "metrics": [], "num_samples": 2}}
- "which agent is best at code understanding?" → {{"target": "reader", "metrics": [], "num_samples": 5}}
- "evaluate the code modifier focusing on accuracy" → {{"target": "coder", "metrics": ["answer_accuracy"], "num_samples": 5}}
- "how faithful is the searcher?" → {{"target": "search", "metrics": ["faithfulness"], "num_samples": 5}}
- "comprehensive evaluation of all agents" → {{"target": "codebase", "metrics": [], "num_samples": 10}}

START WITH {{ CHARACTER. ONLY JSON."""

    try:
        # Use gpt-4o-mini for all evaluation-related LLM calls
        import os
        from openai import OpenAI
        client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            max_tokens=200,
            temperature=0,
            messages=[{"role": "user", "content": prompt}],
        )
        response_text = response.choices[0].message.content.strip()

        # Clean up response if it has markdown code blocks
        if "```" in response_text:
            parts = response_text.split("```")
            if len(parts) >= 2:
                response_text = parts[1]
                if response_text.startswith("json"):
                    response_text = response_text[4:]
        response_text = response_text.strip()

        # Parse JSON
        import json
        result = json.loads(response_text)

        return {
            "target": result.get("target", "codebase"),
            "metrics": result.get("metrics", []) or None,  # None means all metrics
            "num_samples": result.get("num_samples", 5),
        }
    except Exception as e:
        print(f"[evaluator] Warning: Failed to parse query with LLM: {e}")
        print(f"[evaluator] Using defaults: codebase, all metrics, 5 samples")
        return {
            "target": "codebase",
            "metrics": None,
            "num_samples": 5,
        }


def _extract_modules_from_analysis(analysis_output: str) -> list[dict]:
    """Extract module information from module analyzer output."""
    modules = []

    # Parse the analysis output to extract modules
    lines = analysis_output.split("\n")

    current_module = None
    for line in lines:
        stripped = line.strip()
        # Look for module entries (e.g., "1. agents/summarizer.py")
        if stripped and stripped[0].isdigit() and "." in stripped:
            parts = stripped.split(".", 1)
            if len(parts) > 1:
                module_name = parts[1].strip()
                current_module = {"name": module_name, "kind": "unknown"}

        # Extract module kind
        if current_module and "Module Kind:" in line:
            kind = line.split("Module Kind:")[-1].strip()
            current_module["kind"] = kind
            modules.append(current_module)
            current_module = None

    return modules


async def _evaluate_modules(
    modules: list[dict],
    metrics: Optional[list[str]] = None,
    num_samples: int = 5,
    codebase_root: str = "",
) -> list[dict]:
    """Evaluate modules asynchronously with dataset caching."""
    results = []
    print(f"[evaluator] Starting evaluation of {len(modules)} modules...\n")

    # Create evaluator once and reuse for all modules (avoids event loop cleanup issues)
    # Uses user's configured model (config.MODEL) for evaluation
    evaluator = create_ragas_evaluator()

    for idx, module in enumerate(modules, 1):
        try:
            print(f"[{idx}/{len(modules)}] {module['name']} ({module['kind']})...", end=" ")

            # Skip non-evaluable modules
            if module["kind"] == "non-agentic":
                print("⏭️  skipped (non-agentic)")
                results.append(
                    {
                        "name": module["name"],
                        "kind": module["kind"],
                        "status": "skipped",
                        "reason": "Non-agentic modules cannot be evaluated",
                    }
                )
                continue

            # Generate golden dataset
            print("generating dataset...", end=" ")
            module_info = {
                "name": module["name"],
                "module_kind": module["kind"],
                "description": f"{module['name']} module",
                "uses_llm": module["kind"] in ("genai", "agentic"),
                "uses_tools": module["kind"] == "agentic",
            }

            dataset = generate_golden_dataset(
                module_info,
                num_samples=num_samples,
                module_content="",
                codebase_root=codebase_root,
            )

            if not dataset.questions:
                print("❌ failed (dataset generation)")
                results.append(
                    {
                        "name": module["name"],
                        "kind": module["kind"],
                        "status": "failed",
                        "reason": "Failed to generate golden dataset",
                    }
                )
                continue

            # Evaluate with RAGAS (using user's configured model)
            print("computing metrics...", end=" ")

            if module["kind"] == "genai":
                eval_metrics = await evaluator.evaluate_genai_module(
                    questions=dataset.questions,
                    contexts=dataset.contexts,
                    answers=dataset.answers,
                    ground_truth=dataset.ground_truth,
                    requested_metrics=metrics,
                )
            elif module["kind"] == "agentic":
                eval_metrics = await evaluator.evaluate_agentic_module(
                    questions=dataset.questions,
                    contexts=dataset.contexts,
                    answers=dataset.answers,
                    ground_truth=dataset.ground_truth,
                    expected_tool_calls=dataset.expected_tool_calls or [],
                    selected_tool_calls=dataset.selected_tool_calls or [],
                    requested_metrics=metrics,
                )
            else:
                continue

            print("✓")
            results.append(
                {
                    "name": module["name"],
                    "kind": module["kind"],
                    "status": "success",
                    "metrics": eval_metrics,
                    "num_samples": num_samples,
                }
            )

        except Exception as e:
            print(f"❌ error: {str(e)[:60]}")
            results.append(
                {
                    "name": module["name"],
                    "kind": module["kind"],
                    "status": "failed",
                    "error": str(e),
                }
            )

    print(f"\n[evaluator] Evaluation complete. Results: {len([r for r in results if r['status'] == 'success'])} passed, {len([r for r in results if r['status'] == 'failed'])} failed\n")
    return results


def _format_evaluation_results(
    results: list[dict], request: dict
) -> str:
    """Format evaluation results for display."""
    lines = ["\n" + "=" * 80, "EVALUATION RESULTS", "=" * 80]

    successful = [r for r in results if r["status"] == "success"]
    failed = [r for r in results if r["status"] == "failed"]
    skipped = [r for r in results if r["status"] == "skipped"]

    # Summary
    lines.append(
        f"\nSummary: {len(successful)} evaluated, {len(failed)} failed, {len(skipped)} skipped"
    )

    # Detailed results
    if successful:
        lines.append("\n" + "-" * 80)
        lines.append("SUCCESSFUL EVALUATIONS")
        lines.append("-" * 80)

        for result in successful:
            lines.append(f"\n📊 {result['name']} ({result['kind']})")
            lines.append(f"   Samples: {result['num_samples']}")

            metrics = result["metrics"]

            # Show requested metrics or all if none specified
            if request["metrics"]:
                # Show only requested metrics
                for metric in request["metrics"]:
                    key = f"{metric}_avg"
                    if key in metrics and metrics[key] is not None:
                        lines.append(f"   {metric.replace('_', ' ').title()}: {metrics[key]:.3f}")
            else:
                # Show all available metrics
                if metrics.get("faithfulness_avg") is not None:
                    lines.append(f"   Faithfulness: {metrics['faithfulness_avg']:.3f}")
                if metrics.get("hallucination_avg") is not None:
                    lines.append(f"   Hallucination: {metrics['hallucination_avg']:.3f}")
                if metrics.get("answer_relevancy_avg") is not None:
                    lines.append(f"   Answer Relevancy: {metrics['answer_relevancy_avg']:.3f}")
                if metrics.get("context_relevance_avg") is not None:
                    lines.append(f"   Context Relevance: {metrics['context_relevance_avg']:.3f}")
                if metrics.get("context_precision_avg") is not None:
                    lines.append(f"   Context Precision: {metrics['context_precision_avg']:.3f}")
                if metrics.get("context_recall_avg") is not None:
                    lines.append(f"   Context Recall: {metrics['context_recall_avg']:.3f}")
                if metrics.get("answer_accuracy_avg") is not None:
                    lines.append(f"   Answer Accuracy: {metrics['answer_accuracy_avg']:.3f}")
                if metrics.get("response_groundedness_avg") is not None:
                    lines.append(f"   Response Groundedness: {metrics['response_groundedness_avg']:.3f}")
                if metrics.get("agent_goal_accuracy_avg") is not None:
                    lines.append(
                        f"   Agent Goal Accuracy: {metrics['agent_goal_accuracy_avg']:.3f}"
                    )
                if metrics.get("tool_call_f1_avg") is not None:
                    lines.append(f"   Tool Call F1: {metrics['tool_call_f1_avg']:.3f}")

    if skipped:
        lines.append("\n" + "-" * 80)
        lines.append("SKIPPED")
        lines.append("-" * 80)
        for result in skipped:
            lines.append(f"\n⏭️  {result['name']}: {result['reason']}")

    if failed:
        lines.append("\n" + "-" * 80)
        lines.append("FAILED")
        lines.append("-" * 80)
        for result in failed:
            reason = result.get("error") or result.get("reason", "Unknown error")
            lines.append(f"\n❌ {result['name']}: {reason}")

    lines.append("\n" + "=" * 80 + "\n")

    return "\n".join(lines)
