import config
from kg.graph import KnowledgeGraph
from kg.store import VectorStore
from kg.embedder import get_embedding
from utils.retry import call_api

MAX_CONTEXT_CHARS = 8_000
MAX_FILE_CHARS = 2_000


def _retrieve_node_ids(
    kg: KnowledgeGraph,
    store: VectorStore,
    query: str,
    top_k: int = 5,
) -> list[str]:
    """
    1. Embed the query.
    2. Find top-k similar nodes from the FAISS store.
    3. Expand by 1-hop via the relationship table (e.g. a matched class pulls its file).
    """
    query_emb = get_embedding(query)
    seed_ids = store.search(query_emb, top_k=top_k)

    expanded: set[str] = set(seed_ids)
    for node_id in seed_ids:
        for neighbor_id, _ in kg.neighbors(node_id):
            expanded.add(neighbor_id)

    return list(expanded)


def _build_context(kg: KnowledgeGraph, node_ids: list[str]) -> str:
    """Format retrieved vertices as a context block for the LLM."""
    parts = []
    total = 0

    for node_id in node_ids:
        vertex = kg.vertices.get(node_id)
        if vertex is None:
            continue

        if vertex.label == "file":
            content = vertex.properties.get("content", "")[:MAX_FILE_CHARS]
            snippet = f"### {vertex.properties['path']}\n```\n{content}\n```\n"
        elif vertex.label == "class":
            p = vertex.properties
            snippet = (
                f"### class `{p['name']}` in `{p['file']}`\n"
                f"Methods: {', '.join(p.get('methods', []))}\n"
                f"Docstring: {p.get('docstring', '(none)')}\n"
            )
        elif vertex.label == "function":
            p = vertex.properties
            snippet = (
                f"### def `{p['name']}` in `{p['file']}`\n"
                f"Signature: {p.get('signature', '')}\n"
                f"Docstring: {p.get('docstring', '(none)')}\n"
            )
        else:
            continue

        if total + len(snippet) > MAX_CONTEXT_CHARS:
            break
        parts.append(snippet)
        total += len(snippet)

    return "\n".join(parts)


def retrieve(kg: KnowledgeGraph, store: VectorStore, query: str) -> str:
    """Return formatted code context for a query (no LLM call). Used as a supervisor tool."""
    node_ids = _retrieve_node_ids(kg, store, query)
    return _build_context(kg, node_ids)


def answer_question(kg: KnowledgeGraph, store: VectorStore, question: str) -> str:
    """Retrieve relevant nodes from KG via FAISS, then answer with LLM (standalone use)."""
    node_ids = _retrieve_node_ids(kg, store, question)
    context = _build_context(kg, node_ids)

    messages = [
        {
            "role": "system",
            "content": (
                "You are a senior software engineer analyzing a codebase. "
                "Answer the user's question using the provided code context. "
                "Be concise and precise. Reference file paths when relevant."
            ),
        },
        {
            "role": "user",
            "content": f"Codebase context:\n\n{context}\n\nQuestion: {question}",
        },
    ]

    try:
        response = call_api(lambda: config.get_client().chat.completions.create(
            model=config.MODEL,
            messages=messages,
            temperature=0.2,
        ))
        return response.choices[0].message.content
    except RuntimeError as e:
        return f"[reader error] {e}"
