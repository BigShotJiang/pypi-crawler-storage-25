from typing import Callable
import config
from utils.retry import call_api


def make_summarizer() -> Callable[[str], str]:
    """Return a summarizer agent function."""

    def summarize(content: str) -> str:
        try:
            response = call_api(lambda: config.get_client().chat.completions.create(
                model=config.MODEL,
                messages=[
                    {
                        "role": "system",
                        "content": (
                            "Summarize the following content concisely. "
                            "Focus on key points, outcomes, errors, and important findings."
                        ),
                    },
                    {"role": "user", "content": content[:12_000]},
                ],
                temperature=0.2,
            ))
            return response.choices[0].message.content
        except RuntimeError as e:
            return f"[summarizer error] {e}"

    return summarize
