import json
import shutil
from pathlib import Path
from typing import Callable
import config
from utils.retry import call_api

_EXTRACT_PROMPT = """\
Extract the source and destination paths from the rename/move instruction.
Return JSON: {"from_path": "relative/source", "to_path": "relative/destination"}
Paths must be relative to the project root (no leading slash).
"""


def make_renamer(
    root_path: str,
    on_change: Callable[[list[str], list[str]], None] | None = None,
) -> Callable[[str], str]:
    """
    Return a renamer agent function.
    on_change(changed, deleted) is called after a successful rename so the KG stays fresh.
    """
    root = Path(root_path).resolve()

    def rename(instruction: str) -> str:
        # Use LLM to extract from/to paths
        try:
            resp = call_api(lambda: config.get_client().chat.completions.create(
                model=config.MODEL,
                messages=[
                    {"role": "system", "content": _EXTRACT_PROMPT},
                    {"role": "user", "content": instruction},
                ],
                response_format={"type": "json_object"},
                temperature=0,
            ))
        except RuntimeError as e:
            return f"[renamer error] {e}"
        try:
            parsed = json.loads(resp.choices[0].message.content)
            from_rel = parsed["from_path"].lstrip("/")
            to_rel = parsed["to_path"].lstrip("/")
        except (json.JSONDecodeError, KeyError) as e:
            return f"[renamer error] could not parse paths: {e}"

        from_path = (root / from_rel).resolve()
        to_path = (root / to_rel).resolve()

        # Safety: both paths must stay within the codebase root
        try:
            from_path.relative_to(root)
            to_path.relative_to(root)
        except ValueError:
            return "[renamer] refused: paths must be within the codebase root"

        if not from_path.exists():
            return f"[renamer] source not found: {from_rel}"
        if to_path.exists():
            return f"[renamer] destination already exists: {to_rel}"

        is_dir = from_path.is_dir()
        kind = "DIRECTORY" if is_dir else "FILE"

        print(f"\n{'='*60}")
        print(f"  Action: RENAME / MOVE")
        print(f"  Type  : {kind}")
        print(f"  From  : {from_path}")
        print(f"  To    : {to_path}")
        print(f"{'='*60}")

        try:
            answer = input("Confirm rename/move? [y/N]: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            answer = "n"

        if answer != "y":
            return f"Rename cancelled by user: {from_rel} → {to_rel}"

        to_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(from_path), str(to_path))

        if on_change:
            if is_dir:
                new_rels = [str(p.relative_to(root)) for p in to_path.rglob("*") if p.is_file()]
                old_rels = [
                    str(Path(from_rel) / Path(nr).relative_to(to_rel)) for nr in new_rels
                ]
                on_change(new_rels, old_rels)
            else:
                on_change([to_rel], [from_rel])

        return f"Renamed: {from_rel} → {to_rel}"

    return rename
