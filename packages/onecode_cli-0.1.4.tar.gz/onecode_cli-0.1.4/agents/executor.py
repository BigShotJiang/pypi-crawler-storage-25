import subprocess
from pathlib import Path
from typing import Callable

TIMEOUT_SECONDS = 30
MAX_OUTPUT_CHARS = 4_000


def make_executor(root_path: str) -> Callable[[str], str]:
    """
    Return an executor agent function bound to root_path.
    The returned fn accepts a shell command string, runs it from root_path,
    and returns a structured result (exit code + stdout + stderr).
    """
    root = Path(root_path).resolve()

    def execute(command: str) -> str:
        """Run command from the codebase root and return the output."""
        command = command.strip()
        try:
            result = subprocess.run(
                command,
                shell=True,
                cwd=root,
                capture_output=True,
                text=True,
                timeout=TIMEOUT_SECONDS,
            )
        except subprocess.TimeoutExpired:
            return f"[executor] timed out after {TIMEOUT_SECONDS}s\nCommand: {command}"
        except Exception as e:
            return f"[executor] failed to run command: {e}\nCommand: {command}"

        stdout = result.stdout[:MAX_OUTPUT_CHARS]
        stderr = result.stderr[:MAX_OUTPUT_CHARS]

        parts = [f"Exit code: {result.returncode}", f"Command: {command}"]
        if stdout:
            parts.append(f"\nSTDOUT:\n{stdout}")
        if stderr:
            parts.append(f"\nSTDERR:\n{stderr}")
        if not stdout and not stderr:
            parts.append("\n(no output)")

        return "\n".join(parts)

    return execute
