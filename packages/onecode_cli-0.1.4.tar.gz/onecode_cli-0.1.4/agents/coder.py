import difflib
import json
from pathlib import Path
from typing import Callable
import config
from utils.retry import call_api

SYSTEM_PROMPT = """\
You are an expert software engineer. Write or modify code based on the given instruction.

You will receive:
- An instruction describing what to create or change
- Relevant existing code as context (if applicable)

Respond with a JSON object in this exact shape:
{
  "changes": [
    {
      "action": "create" | "modify",
      "file_path": "relative/path/to/file.py",
      "content": "<complete file content>"
    }
  ],
  "explanation": "<brief summary of what was done and why>"
}

Rules:
- For "modify", return the entire new file content (not a diff or partial snippet)
- Keep changes minimal and focused on the instruction
- file_path must be relative to the codebase root (no leading slash)
- Return valid, working code only
"""

PREVIEW_LINES = 30  # max lines shown for new files


def _changed_line_ranges(diff_lines: list[str]) -> list[str]:
    """Extract human-readable line range summaries from unified diff @@ headers."""
    ranges = []
    for line in diff_lines:
        if line.startswith("@@"):
            # e.g. "@@ -10,4 +10,7 @@ def foo():"
            ranges.append(line.split("@@")[1].strip() if "@@" in line[2:] else line)
    return ranges


def _show_change(file_path: Path, rel_path: str, action: str, new_content: str) -> str:
    """
    Return a human-readable preview of what will change.
    - New file: show first PREVIEW_LINES lines with '+' prefix.
    - Modified file: show unified diff with line numbers.
    """
    if action == "create" or not file_path.exists():
        lines = new_content.splitlines()
        preview_lines = lines[:PREVIEW_LINES]
        body = "\n".join(f"  + {l}" for l in preview_lines)
        suffix = f"\n  ... ({len(lines) - PREVIEW_LINES} more lines)" if len(lines) > PREVIEW_LINES else ""
        return (
            f"  Action : CREATE\n"
            f"  File   : {rel_path}\n"
            f"  Path   : {file_path}\n"
            f"\n{body}{suffix}"
        )

    # Modified file — compute unified diff
    old_content = file_path.read_text(encoding="utf-8")
    if old_content == new_content:
        return (
            f"  Action : MODIFY (no effective change detected)\n"
            f"  File   : {rel_path}\n"
            f"  Path   : {file_path}"
        )

    old_lines = old_content.splitlines(keepends=True)
    new_lines = new_content.splitlines(keepends=True)
    diff = list(difflib.unified_diff(
        old_lines, new_lines,
        fromfile=f"a/{rel_path}",
        tofile=f"b/{rel_path}",
        lineterm="",
    ))

    ranges = _changed_line_ranges(diff)
    range_str = ", ".join(ranges) if ranges else "unknown"
    body = "".join(diff)

    return (
        f"  Action       : MODIFY\n"
        f"  File         : {rel_path}\n"
        f"  Path         : {file_path}\n"
        f"  Changed lines: {range_str}\n"
        f"\n{body}"
    )


def _display_all(explanation: str, previews: list[tuple[str, str]]):
    """Print explanation and all change previews."""
    print(f"\n{'─'*60}")
    print(f"Coder explanation: {explanation}")
    print(f"{'─'*60}")
    for rel_path, preview in previews:
        print(f"\n{'='*60}")
        print(preview)
        print(f"{'='*60}")


def make_coder(
    root_path: str,
    on_change: Callable[[list[str], list[str]], None] | None = None,
) -> Callable[[str], str]:
    """
    Return a coder agent function bound to root_path.
    Shows ALL proposed changes first, then asks once:
      y = apply all changes
      N = reject all, nothing is written
    on_change(changed, deleted) is called after writes so the KG stays fresh.
    """
    root = Path(root_path).resolve()

    def write_code(instruction: str) -> str:
        try:
            response = call_api(lambda: config.get_client().chat.completions.create(
                model=config.MODEL,
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": instruction},
                ],
                response_format={"type": "json_object"},
                temperature=0.2,
            ))
        except RuntimeError as e:
            return f"[coder error] {e}"

        raw = response.choices[0].message.content
        try:
            result = json.loads(raw)
        except json.JSONDecodeError:
            return f"[coder error] failed to parse LLM output:\n{raw}"

        changes = result.get("changes", [])
        explanation = result.get("explanation", "")

        if not changes:
            return f"No changes proposed.\nExplanation: {explanation}"

        # Build previews for all changes upfront
        pending: list[tuple[Path, str, str, str]] = []  # (file_path, rel_path, action, content)
        previews: list[tuple[str, str]] = []            # (rel_path, preview_text)

        for change in changes:
            action = change.get("action", "create")
            rel_path = change.get("file_path", "").lstrip("/")
            content = change.get("content", "")
            if not rel_path or not content:
                continue
            file_path = root / rel_path
            pending.append((file_path, rel_path, action, content))
            previews.append((rel_path, _show_change(file_path, rel_path, action, content)))

        if not pending:
            return "No valid changes proposed."

        # Show all changes, then ask once
        _display_all(explanation, previews)
        try:
            answer = input("\nApply all changes? [y/N]: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            answer = "n"

        accepted = answer == "y"

        if not accepted:
            paths = ", ".join(rel for _, rel, _, _ in pending)
            return f"All changes rejected by user.\nFiles: {paths}\nExplanation: {explanation}"

        # Apply all approved changes
        applied: list[str] = []
        written_rels: list[str] = []
        for file_path, rel_path, action, content in pending:
            file_path.parent.mkdir(parents=True, exist_ok=True)
            file_path.write_text(content, encoding="utf-8")
            applied.append(f"  [{action}] {rel_path} ({file_path})")
            written_rels.append(rel_path)

        if on_change and written_rels:
            on_change(written_rels, [])

        lines = ["Files written (user approved):", *applied, f"\nExplanation: {explanation}"]
        return "\n".join(lines)

    return write_code
