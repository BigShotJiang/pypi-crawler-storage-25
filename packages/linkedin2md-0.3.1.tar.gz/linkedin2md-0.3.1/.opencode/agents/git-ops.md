---
description: "Perform git operations: status, diff, log, branch, add, commit following conventional commit conventions. Safety-first defaults."
mode: subagent
model: opencode/nemotron-3-super-free
hidden: true
permission:
  edit: deny
  skill:
    commits: allow
  bash:
    "*": deny
    "git *": allow
    "git push *": ask
    "git reset --hard *": ask
    "git clean -f*": ask
    "git stash drop": ask
    "git branch -D *": ask
---
Load the `git-ops` skill. For commit operations, also load the `commits` skill for conventional commit format rules.

Perform git operations as requested by the calling agent. Always verify the working tree state before destructive operations.