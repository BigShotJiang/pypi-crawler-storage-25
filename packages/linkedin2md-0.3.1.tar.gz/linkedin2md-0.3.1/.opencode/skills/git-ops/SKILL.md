---
name: git-ops
description: "Git operations: status, diff, log, branch, add, commit following conventional commit format. Safety-first: destructive ops require explicit confirmation."
compatibility: opencode
---

# Skill: git-ops

## When to Use

Use this skill when:
- Checking repository state (`git status`, `git log`, `git diff`)
- Creating commits following conventional commit format
- Managing branches (create, switch, list, delete)
- Staging changes (`git add`)
- Any git operation that doesn't require remote access (that's `github-ops` territory)

## Safety Rules

REQUIRE:
- Run `git status` before any destructive operation
- Never commit unless changes are explicitly staged by the user or calling agent
- Reject `git push --force` to `main`/`master` unless the calling agent provides explicit rationale
- Report to calling agent (do not proceed) if: dirty working tree blocks the operation, detached HEAD state, merge conflicts exist

REJECT if:
- Working tree is dirty and the operation would lose uncommitted changes
- The branch to be deleted has unmerged changes

## Workflow: Creating a Commit

1. `git status --short` — show current state
2. `git diff --stat` — summary of changes
3. `git diff` — review full diff (pipe to calling agent for review)
4. `git add <files>` — stage specific files (never `git add -A` blindly)
5. Load the `commits` skill for conventional commit format rules
6. `git commit -m "<type>(<scope>): <description>"` — conform to conventional commits

## Workflow: Branch Operations

1. `git branch --list` — list local branches
2. `git checkout -b <name>` — create and switch to new branch
3. `git checkout <name>` — switch to existing branch
4. Before deleting: verify branch is merged with `git branch --merged`

## Workflow: Inspecting State

- `git status` — working tree status
- `git log --oneline -n 20` — recent commits
- `git log --graph --oneline --all` — branch graph
- `git diff` — unstaged changes
- `git diff --staged` — staged changes
- `git show <ref>` — full details of a commit

## Edge Cases

- **Empty repo (no commits)**: `git rev-parse --verify HEAD` fails. Handle by explaining this is a fresh repo and suggesting `git add` + first commit.
- **Detached HEAD**: Warn calling agent before any commit or branch creation.
- **Large repos**: Use `git log --oneline -n 20` (limit output). Use `-- <path>` to scope diff/log to specific paths.
- **Merge conflicts**: Report to calling agent with conflicting files. Do not attempt resolution.