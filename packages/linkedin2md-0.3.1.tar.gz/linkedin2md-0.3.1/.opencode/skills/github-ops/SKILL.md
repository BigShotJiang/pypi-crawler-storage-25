---
name: github-ops
description: "GitHub operations via gh CLI: list/view/create/update issues and PRs, manage releases, check action runs. Destructive ops require confirmation."
compatibility: opencode
---

# Skill: github-ops

## When to Use

Use this skill when:
- Managing pull requests (`gh pr list`, `gh pr view`, `gh pr create`)
- Managing issues (`gh issue list`, `gh issue view`, `gh issue create`)
- Creating or managing releases (`gh release list`, `gh release create`)
- Checking CI/CD status (`gh run list`, `gh run view`)
- Any operation that interacts with the GitHub remote

## Safety Rules

REQUIRE:
- Run `gh auth status` before any operation — report to calling agent if not authenticated
- Never close or merge PRs without explicit instruction
- Never delete releases without explicit confirmation
- Validate that a PR has passed CI before merging (check `gh pr checks`)
- Report rate-limit errors clearly with retry-after information

REJECT if:
- The user is not authenticated (`gh auth status` fails)
- The operation targets a branch/repo the calling agent didn't specify
- CI checks are failing on a PR that should be merged

## Workflow: Creating a Pull Request

1. `gh pr status` — check for existing PRs on the current branch
2. `git log --oneline origin/main..HEAD` — review commits to include
3. `gh pr create --title "<title>" --body "$(cat <<'EOF' ... EOF)"` — create the PR
4. Report PR URL to calling agent

## Workflow: Reviewing a Pull Request

1. `gh pr list --state open` — list open PRs
2. `gh pr view <number>` — view PR details
3. `gh pr diff <number>` — view PR changes
4. `gh pr checks <number>` — check CI status
5. `gh pr review <number> --approve|--comment|--request-changes` — submit review

## Workflow: Managing Issues

- `gh issue list --state open` — list open issues
- `gh issue view <number>` — view issue details
- `gh issue create --title "<title>" --body "<body>"` — create issue
- `gh issue close <number>` — close issue
- `gh issue reopen <number>` — reopen issue

## Workflow: Releases

- `gh release list` — list releases
- `gh release view <tag>` — view release details
- `gh release create <tag> --title "<title>" --notes "<notes>"` — create release

## Workflow: CI/CD Checks

- `gh run list --limit 10` — recent workflow runs
- `gh run view <run-id>` — view run details
- `gh run watch <run-id>` — follow a running job

## Edge Cases

- **Not authenticated**: `gh auth status` returns non-zero. Report to calling agent, do not proceed.
- **Rate limited**: `gh` outputs HTTP 403/429. Report rate limit message and suggest retry delay.
- **No remote configured**: `git remote -v` shows no `origin`. Report to calling agent.
- **Missing gh CLI**: `command not found: gh`. Report that github-ops requires the GitHub CLI (`brew install gh` / `apt install gh`).
- **PR already exists for branch**: `gh pr status` shows existing PR. Report to calling agent instead of creating duplicate.