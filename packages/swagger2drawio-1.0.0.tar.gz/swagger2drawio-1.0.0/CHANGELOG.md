# Changelog

All notable changes to this project are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.0.0] — 2026-05-17

First stable release. The CLI surface (`generate`, `validate`, `diff`,
`init`, `themes list / show`), the typed exception hierarchy + exit
codes, the bundled themes, and the `swagger2drawio.layouts` entry-point
group are all considered API stable.

### Added — Phase 5 (Code Quality)

- `SpecParser` `Protocol` and `get_parser(raw_dict)` factory for parser
  polymorphism (`swagger2drawio/parser/base.py`).
- `OpenAPIParser.parse_dict()` + `OpenAPIParser.from_dict_factory()` so
  callers with an in-memory spec can skip the I/O layer.
- `LayoutStrategy` Protocol with two built-in strategies
  (`HierarchicalBFSLayout`, `GridLayout`) and entry-point discovery
  through the `swagger2drawio.layouts` group.
- `--layout` CLI flag and `build_endpoint_graph(layout=...)` parameter.

### Changed — Phase 5

- All diff dataclasses now use `slots=True`.
- `Parameter.__post_init__` validates `in` against the OpenAPI
  location set; `MethodDetail.__post_init__` validates `verb` against
  the HTTP-method set.
- `mypy --strict` now passes on the whole package, not just the
  parser / layout subpackages.

### Added — Phase 4 (CLI & UX)

- Bundled themes: `light`, `dark`, `pastel`, `high-contrast` under
  `swagger2drawio/themes/*.yaml`.
- `--theme <name>` flag on `generate`.
- `themes list` and `themes show <name>` subcommands.
- `init` subcommand that scaffolds a `.swagger2drawio.yaml` in CWD.
- Config discovery order: `--config` → `--theme` →
  `./.swagger2drawio.yaml` → `$XDG_CONFIG_HOME/swagger2drawio/config.yaml`
  → built-in defaults (deep-merged).
- `rich.progress` spinner + bar during `generate`, with a final summary
  line: `<file> written (X.X KB) — N path(s), M method(s), K schema(s)`.
- Shell completion via Typer's `--install-completion` / `--show-completion`.

### Added — Phase 3 (Feature Expansion)

- Richer endpoint rendering: parameters, request-body and response-ref
  links, deprecated flag, request/response refs inline in the method
  label, height auto-scales with content.
- Tag-based grouping (`--group-by tag|path|auto`).
- Schema composition: `allOf` / `oneOf` / `anyOf` / `discriminator`
  edges with distinct styles; enum types rendered as `«enum»` nodes.
- Security legend (`securitySchemes` → standalone node) and an info
  banner on the root with title / version / description / server URLs.
- **Diff mode** — new `swagger2drawio diff OLD NEW` subcommand
  producing a three-page (`Summary` / `Endpoints` / `Schemas`)
  side-by-side `.drawio` with green/red/yellow overlays and dashed
  connectors between changed pairs.

### Added — Phase 2 (Robustness)

- Typed exception hierarchy (`Swagger2DrawioError` and six subclasses)
  with a stable per-category exit code map (`EXIT_CODE`, codes 1–7).
- `openapi-spec-validator` integration. New `validate` subcommand and
  a `--no-validate` flag on `generate` (validation is on by default).
- `RefResolver` inlines external file / remote URL `$ref`s into
  `components.schemas` with cycle safety and per-document caching.
- Network options on `generate`: `--timeout`, `--header / -H`
  (repeatable), `--insecure`.
- Rich-based logging: `--verbose / -v` (count), `--quiet / -q`,
  `--log-file <path>`.

### Changed — Phase 2

- **Breaking** — `--version` no longer has the `-v` short alias.
  `-v` is now `--verbose` (count). `--version` still works.

### Added — Phase 1 (Foundations)

- Modern packaging via `hatchling` with dynamic version from
  `swagger2drawio/__init__.py`.
- Test infrastructure: 96.7% coverage on parser/layout/renderer.
- `ruff` + `mypy` + `pre-commit` configuration.
- GitHub Actions CI (Python 3.10 × 3 OS matrix) and trusted-publishing
  release workflow.

## [0.1.0] — 2026-02-20

Initial public release. Single `generate` command. OAS 3 + Swagger 2
support. Two-page output (Endpoints Map, Schema Map).
