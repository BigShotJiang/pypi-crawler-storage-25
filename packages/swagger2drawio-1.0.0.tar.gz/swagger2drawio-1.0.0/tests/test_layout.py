"""Tests for ``swagger2drawio.layout.graph_engine``."""

from __future__ import annotations

from itertools import pairwise
from pathlib import Path

import networkx as nx
import pytest

from swagger2drawio.layout.graph_engine import (
    LayoutResult,
    NodeInfo,
    build_endpoint_graph,
    build_schema_graph,
    compute_layout,
)
from swagger2drawio.parser.openapi_parser import (
    OpenAPIParser,
    ParsedSpec,
)

# ═══════════════════════════════════════════════════════════════
# Endpoint graph
# ═══════════════════════════════════════════════════════════════


class TestBuildEndpointGraph:
    """Tests for ``build_endpoint_graph`` in flat (path) mode."""

    @pytest.fixture(autouse=True)
    def _build(self, oas3_json_path: Path) -> None:
        self.spec = OpenAPIParser(source=str(oas3_json_path)).parse()
        self.result = build_endpoint_graph(self.spec, group_by="path")

    def test_returns_layout_result(self) -> None:
        assert isinstance(self.result, LayoutResult)
        assert isinstance(self.result.graph, nx.DiGraph)

    def test_root_node_present(self) -> None:
        assert "root" in self.result.nodes
        root = self.result.nodes["root"]
        assert root.kind == "root"
        assert "Petstore API" in root.label

    def test_node_count(self) -> None:
        # 1 root + 3 paths + 5 methods + 1 security legend = 10
        assert len(self.result.nodes) == 10

    def test_edge_count(self) -> None:
        # 3 root->path + 5 path->method + 1 root->security = 9
        assert self.result.graph.number_of_edges() == 9

    def test_path_nodes(self) -> None:
        path_ids = [n for n in self.result.nodes if n.startswith("path:")]
        assert len(path_ids) == 3

    def test_method_nodes_have_verb_kind(self) -> None:
        verbs = {self.result.nodes[n].kind for n in self.result.nodes if n.startswith("method:")}
        assert verbs <= {"GET", "POST", "PUT", "PATCH", "DELETE"}

    def test_method_summary_included_in_label(self) -> None:
        method_id = "method:/pets:GET"
        assert method_id in self.result.nodes
        assert "List all pets" in self.result.nodes[method_id].label

    def test_root_has_outgoing_edges_to_paths_and_security(self) -> None:
        successors = list(self.result.graph.successors("root"))
        # 3 paths + 1 security legend = 4
        assert len(successors) == 4
        path_children = [s for s in successors if s.startswith("path:")]
        assert len(path_children) == 3
        assert "security:legend" in successors


class TestEndpointGraphTagGrouped:
    """Tests for the new ``group_by='tag'`` mode."""

    @pytest.fixture(autouse=True)
    def _build(self, oas3_json_path: Path) -> None:
        self.spec = OpenAPIParser(source=str(oas3_json_path)).parse()
        self.result = build_endpoint_graph(self.spec, group_by="tag")

    def test_root_children_include_tags_and_security(self) -> None:
        successors = set(self.result.graph.successors("root"))
        # Fixture uses tags "pets" and "owners" plus a security legend.
        assert {"tag:pets", "tag:owners", "security:legend"} <= successors
        # Every non-security child is a tag.
        for s in successors - {"security:legend"}:
            assert s.startswith("tag:")

    def test_path_under_tag(self) -> None:
        # /pets should appear under the pets tag node.
        path_id = "path:pets:/pets"
        assert path_id in self.result.nodes
        # And be a successor of the pets tag.
        assert path_id in list(self.result.graph.successors("tag:pets"))

    def test_method_under_tag_path(self) -> None:
        method_id = "method:pets:/pets:GET"
        assert method_id in self.result.nodes

    def test_invalid_group_by_raises(self) -> None:
        with pytest.raises(ValueError, match="group_by"):
            build_endpoint_graph(self.spec, group_by="bogus")


class TestEndpointGraphAuto:
    """`auto` should pick tag mode when any tags exist, path mode otherwise."""

    def test_auto_picks_tag_when_tags_present(self, oas3_json_path: Path) -> None:
        spec = OpenAPIParser(source=str(oas3_json_path)).parse()
        result = build_endpoint_graph(spec, group_by="auto")
        successors = set(result.graph.successors("root"))
        # Tag children + the security legend.
        non_security = successors - {"security:legend"}
        assert all(s.startswith("tag:") for s in non_security)
        assert non_security  # at least one tag

    def test_auto_picks_path_when_no_tags(self) -> None:
        from swagger2drawio.parser.openapi_parser import (
            MethodDetail,
            ParsedSpec,
            PathItem,
        )

        spec = ParsedSpec(
            title="NoTags",
            version="1",
            paths=[PathItem(route="/x", methods=[MethodDetail(verb="GET")])],
        )
        result = build_endpoint_graph(spec, group_by="auto")
        successors = list(result.graph.successors("root"))
        assert all(s.startswith("path:") for s in successors)


class TestEndpointGraphEmpty:
    """A spec with no paths should still produce a valid root-only graph."""

    def test_empty_spec(self) -> None:
        spec = ParsedSpec(title="Empty", version="1.0.0")
        result = build_endpoint_graph(spec)
        assert len(result.nodes) == 1
        assert "root" in result.nodes
        assert result.graph.number_of_edges() == 0


# ═══════════════════════════════════════════════════════════════
# compute_layout — coordinate properties
# ═══════════════════════════════════════════════════════════════


class TestComputeLayout:
    """Direct tests against the deterministic BFS layout."""

    @pytest.fixture()
    def linear_graph(self) -> tuple[nx.DiGraph, dict[str, NodeInfo]]:
        g = nx.DiGraph()
        nodes: dict[str, NodeInfo] = {}
        for nid in ("a", "b", "c"):
            nodes[nid] = NodeInfo(node_id=nid, label=nid, kind="path")
            g.add_node(nid)
        g.add_edge("a", "b")
        g.add_edge("b", "c")
        return g, nodes

    def test_root_missing_returns_unchanged(self) -> None:
        g = nx.DiGraph()
        nodes: dict[str, NodeInfo] = {"x": NodeInfo("x", "x", "path")}
        # 'missing' is not in the graph
        result = compute_layout(g, nodes, "missing")
        assert result["x"].x == 0.0
        assert result["x"].y == 0.0

    def test_assigns_y_by_depth(self, linear_graph: tuple[nx.DiGraph, dict[str, NodeInfo]]) -> None:
        g, nodes = linear_graph
        compute_layout(g, nodes, "a", node_height=60, v_spacing=120)
        # depth 0,1,2 -> y = 0, 180, 360
        assert nodes["a"].y == 0
        assert nodes["b"].y == 180
        assert nodes["c"].y == 360

    def test_lr_swaps_axes(self, linear_graph: tuple[nx.DiGraph, dict[str, NodeInfo]]) -> None:
        g, nodes = linear_graph
        compute_layout(g, nodes, "a", rankdir="LR")
        # After swap, "depth" should drive x, not y
        assert nodes["a"].x < nodes["b"].x < nodes["c"].x

    def test_normalises_to_origin(
        self, linear_graph: tuple[nx.DiGraph, dict[str, NodeInfo]]
    ) -> None:
        g, nodes = linear_graph
        compute_layout(g, nodes, "a")
        assert min(n.x for n in nodes.values()) == 0
        assert min(n.y for n in nodes.values()) == 0

    def test_deterministic(self, linear_graph: tuple[nx.DiGraph, dict[str, NodeInfo]]) -> None:
        g, nodes_a = linear_graph
        # rebuild same shape
        g2, nodes_b = (
            nx.DiGraph(),
            {nid: NodeInfo(nid, nid, "path") for nid in ("a", "b", "c")},
        )
        for nid in nodes_b:
            g2.add_node(nid)
        g2.add_edge("a", "b")
        g2.add_edge("b", "c")

        compute_layout(g, nodes_a, "a")
        compute_layout(g2, nodes_b, "a")

        for nid in ("a", "b", "c"):
            assert nodes_a[nid].x == nodes_b[nid].x
            assert nodes_a[nid].y == nodes_b[nid].y


class TestNoOverlap:
    """End-to-end overlap check: no two boxes share the same (x, y) cell."""

    def test_endpoints_no_overlap(self, oas3_json_path: Path) -> None:
        spec = OpenAPIParser(source=str(oas3_json_path)).parse()
        result = build_endpoint_graph(
            spec, node_width=200, node_height=60, h_spacing=80, v_spacing=120
        )
        positions = [(n.x, n.y) for n in result.nodes.values()]
        # All positions must be unique
        assert len(positions) == len(set(positions))

    def test_endpoints_axis_aligned_no_collision(self, oas3_json_path: Path) -> None:
        """Within a row, boxes must not horizontally overlap."""
        spec = OpenAPIParser(source=str(oas3_json_path)).parse()
        result = build_endpoint_graph(spec, node_width=200, h_spacing=80)

        # group by y, check x distance >= node_width
        by_y: dict[float, list[float]] = {}
        for n in result.nodes.values():
            by_y.setdefault(n.y, []).append(n.x)
        for xs in by_y.values():
            xs.sort()
            for a, b in pairwise(xs):
                assert b - a >= 200, f"Overlap at row y: x={a} vs x={b}"


# ═══════════════════════════════════════════════════════════════
# Schema graph
# ═══════════════════════════════════════════════════════════════


class TestBuildSchemaGraph:
    """Tests for ``build_schema_graph``."""

    @pytest.fixture(autouse=True)
    def _build(self, oas3_json_path: Path) -> None:
        self.spec = OpenAPIParser(source=str(oas3_json_path)).parse()
        self.result = build_schema_graph(self.spec)

    def test_node_count_matches_schemas(self) -> None:
        assert len(self.result.nodes) == len(self.spec.schemas)

    def test_node_ids_prefixed(self) -> None:
        for nid in self.result.nodes:
            assert nid.startswith("schema:")

    def test_pet_owner_edge_exists(self) -> None:
        # Pet.owner -> Owner ref
        assert self.result.graph.has_edge("schema:Pet", "schema:Owner")

    def test_owner_pets_array_edge_exists(self) -> None:
        # Owner.pets[] -> Pet ref
        assert self.result.graph.has_edge("schema:Owner", "schema:Pet")

    def test_grid_layout_positions_assigned(self) -> None:
        for info in self.result.nodes.values():
            assert info.x >= 0
            assert info.y >= 0

    def test_no_duplicate_positions(self) -> None:
        positions = [(n.x, n.y) for n in self.result.nodes.values()]
        assert len(positions) == len(set(positions))


class TestSchemaGraphEmpty:
    def test_empty_schemas(self) -> None:
        spec = ParsedSpec(title="E", version="1")
        result = build_schema_graph(spec)
        assert len(result.nodes) == 0
        assert result.graph.number_of_nodes() == 0
