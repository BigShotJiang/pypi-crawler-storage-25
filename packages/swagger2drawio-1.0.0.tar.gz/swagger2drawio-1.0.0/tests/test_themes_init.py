"""Tests for built-in themes, the `themes` sub-app, and `init`."""

from __future__ import annotations

from pathlib import Path

import pytest
import yaml
from typer.testing import CliRunner

from swagger2drawio.cli import app
from swagger2drawio.config_loader import list_builtin_themes, load_config, read_theme
from swagger2drawio.exceptions import ConfigError

runner = CliRunner()


# ═══════════════════════════════════════════════════════════════
# Theme discovery
# ═══════════════════════════════════════════════════════════════


class TestThemeDiscovery:
    def test_list_includes_expected_names(self) -> None:
        names = set(list_builtin_themes())
        assert {"light", "dark", "pastel", "high-contrast"} <= names

    def test_read_known_theme(self) -> None:
        data = read_theme("dark")
        assert "endpoint_styles" in data
        assert "schema_styles" in data

    def test_read_unknown_theme_raises(self) -> None:
        with pytest.raises(ConfigError, match="Unknown theme"):
            read_theme("does-not-exist")


# ═══════════════════════════════════════════════════════════════
# load_config + theme layering
# ═══════════════════════════════════════════════════════════════


class TestThemeLayering:
    def test_theme_overrides_defaults(self) -> None:
        cfg = load_config(None, theme="dark")
        # Dark theme overrides the root fill colour.
        root_style = cfg["endpoint_styles"]["root"]["base_style"]
        assert "#1e3a5f" in root_style

    def test_explicit_config_overrides_theme(self, tmp_path: Path) -> None:
        explicit = tmp_path / "custom.yaml"
        explicit.write_text(
            yaml.dump({"layout": {"node_width": 999}}),
            encoding="utf-8",
        )
        cfg = load_config(explicit, theme="dark")
        # Explicit wins on node_width.
        assert cfg["layout"]["node_width"] == 999
        # Dark theme is still present for keys explicit didn't set.
        assert "#1e3a5f" in cfg["endpoint_styles"]["root"]["base_style"]


# ═══════════════════════════════════════════════════════════════
# `themes list` / `themes show` CLI
# ═══════════════════════════════════════════════════════════════


class TestThemesCommand:
    def test_themes_list_outputs_names(self) -> None:
        result = runner.invoke(app, ["themes", "list"])
        assert result.exit_code == 0
        # Every built-in theme appears.
        for name in list_builtin_themes():
            assert name in result.output

    def test_themes_show_known(self) -> None:
        result = runner.invoke(app, ["themes", "show", "light"])
        assert result.exit_code == 0
        assert "endpoint_styles" in result.output

    def test_themes_show_unknown_exits_with_config_code(self) -> None:
        from swagger2drawio.exceptions import EXIT_CODE, ConfigError

        result = runner.invoke(app, ["themes", "show", "no-such-theme"])
        assert result.exit_code == EXIT_CODE[ConfigError]


# ═══════════════════════════════════════════════════════════════
# `init` CLI
# ═══════════════════════════════════════════════════════════════


class TestInitCommand:
    def test_init_creates_file(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["init"])
        assert result.exit_code == 0
        target = tmp_path / ".swagger2drawio.yaml"
        assert target.exists()
        # Default theme is light → matches the light theme content.
        data = yaml.safe_load(target.read_text(encoding="utf-8"))
        assert "endpoint_styles" in data

    def test_init_refuses_to_overwrite_without_force(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.chdir(tmp_path)
        (tmp_path / ".swagger2drawio.yaml").write_text("# existing\n", encoding="utf-8")
        result = runner.invoke(app, ["init"])
        assert result.exit_code != 0
        combined = (result.stderr or "") + result.output
        assert "already exists" in combined

    def test_init_force_overwrites(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.chdir(tmp_path)
        target = tmp_path / ".swagger2drawio.yaml"
        target.write_text("# stale\n", encoding="utf-8")
        result = runner.invoke(app, ["init", "--force"])
        assert result.exit_code == 0
        assert "stale" not in target.read_text(encoding="utf-8")

    def test_init_with_theme(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["init", "--theme", "pastel"])
        assert result.exit_code == 0
        data = yaml.safe_load((tmp_path / ".swagger2drawio.yaml").read_text(encoding="utf-8"))
        # Pastel theme uses a distinctive root fill.
        assert "#fce4ec" in data["endpoint_styles"]["root"]["base_style"]


# ═══════════════════════════════════════════════════════════════
# Config discovery: cwd file + user xdg file
# ═══════════════════════════════════════════════════════════════


class TestConfigDiscovery:
    def test_cwd_file_is_loaded(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.chdir(tmp_path)
        (tmp_path / ".swagger2drawio.yaml").write_text(
            yaml.dump({"layout": {"node_width": 555}}),
            encoding="utf-8",
        )
        cfg = load_config()
        assert cfg["layout"]["node_width"] == 555

    def test_xdg_user_file_is_loaded(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        # Point XDG_CONFIG_HOME at our temp dir + drop a config file under it.
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
        # Make sure no cwd-local file interferes.
        monkeypatch.chdir(tmp_path / "elsewhere") if (tmp_path / "elsewhere").exists() else None
        cfg_dir = tmp_path / "swagger2drawio"
        cfg_dir.mkdir()
        (cfg_dir / "config.yaml").write_text(
            yaml.dump({"layout": {"node_width": 777}}),
            encoding="utf-8",
        )
        # Run from a clean cwd so the cwd-layer doesn't fire.
        clean = tmp_path / "work"
        clean.mkdir()
        monkeypatch.chdir(clean)
        cfg = load_config()
        assert cfg["layout"]["node_width"] == 777
