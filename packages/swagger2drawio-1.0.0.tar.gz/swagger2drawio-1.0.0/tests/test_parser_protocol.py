"""Tests for the parser protocol/factory and dataclass post-init validation."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from swagger2drawio.exceptions import SpecParseError
from swagger2drawio.parser.base import SpecParser, detect_version, get_parser
from swagger2drawio.parser.openapi_parser import MethodDetail, OpenAPIParser, Parameter

# ═══════════════════════════════════════════════════════════════
# detect_version + get_parser
# ═══════════════════════════════════════════════════════════════


class TestDetectVersion:
    def test_oas3(self) -> None:
        assert detect_version({"openapi": "3.0.3", "info": {}}) == "oas3"
        assert detect_version({"openapi": "3.1.0", "info": {}}) == "oas3"

    def test_swagger2(self) -> None:
        assert detect_version({"swagger": "2.0", "info": {}}) == "swagger2"

    def test_neither_raises(self) -> None:
        with pytest.raises(SpecParseError, match=r"neither OpenAPI 3\.x"):
            detect_version({"info": {}})

    def test_old_openapi_version_rejected(self) -> None:
        # "openapi: 2.x" is malformed; we want to reject it cleanly.
        with pytest.raises(SpecParseError):
            detect_version({"openapi": "2.0"})


class TestGetParser:
    def test_returns_protocol_satisfying_parser(self, oas3_json_path: Path) -> None:
        with oas3_json_path.open(encoding="utf-8") as fh:
            raw = json.load(fh)
        parser = get_parser(raw)
        assert isinstance(parser, SpecParser)
        spec = parser.parse_dict(raw)
        assert spec.title == "Petstore API"

    def test_get_parser_unknown_version_raises(self) -> None:
        with pytest.raises(SpecParseError):
            get_parser({"info": {"title": "X"}})


# ═══════════════════════════════════════════════════════════════
# Direct parse_dict on the OpenAPIParser
# ═══════════════════════════════════════════════════════════════


class TestParseDict:
    def test_parse_dict_bypasses_io(self, oas3_json_path: Path) -> None:
        with oas3_json_path.open(encoding="utf-8") as fh:
            raw = json.load(fh)
        parser = OpenAPIParser.from_dict_factory()
        spec = parser.parse_dict(raw)
        assert spec.title == "Petstore API"
        assert {p.route for p in spec.paths} == {"/pets", "/pets/{petId}", "/owners"}


# ═══════════════════════════════════════════════════════════════
# __post_init__ validation
# ═══════════════════════════════════════════════════════════════


class TestParameterPostInit:
    def test_empty_name_rejected(self) -> None:
        with pytest.raises(ValueError, match="cannot be empty"):
            Parameter(name="", location="query")

    def test_invalid_location_rejected(self) -> None:
        with pytest.raises(ValueError, match="location must be one of"):
            Parameter(name="x", location="banana")

    def test_valid_locations_accepted(self) -> None:
        for loc in ("path", "query", "header", "cookie", "body", "formData"):
            assert Parameter(name="x", location=loc).location == loc


class TestMethodDetailPostInit:
    def test_unknown_verb_rejected(self) -> None:
        with pytest.raises(ValueError, match="HTTP method"):
            MethodDetail(verb="WHAT")

    def test_lowercase_verb_rejected(self) -> None:
        # The parser uppercases before construction; mid-pipeline callers
        # should not slip through with mixed case unless they normalise.
        # The current rule accepts case-insensitive matches.
        MethodDetail(verb="get")  # should not raise — uppercased internally
