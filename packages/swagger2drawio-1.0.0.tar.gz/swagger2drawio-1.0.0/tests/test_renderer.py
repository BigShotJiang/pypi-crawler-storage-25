"""Tests for ``swagger2drawio.renderer.drawio_builder``."""

from __future__ import annotations

import xml.etree.ElementTree as ET
from pathlib import Path

import pytest

from swagger2drawio.config_loader import load_config
from swagger2drawio.layout.graph_engine import (
    build_endpoint_graph,
    build_schema_graph,
)
from swagger2drawio.parser.openapi_parser import OpenAPIParser
from swagger2drawio.renderer.drawio_builder import render

# ═══════════════════════════════════════════════════════════════
# Render pipeline integration
# ═══════════════════════════════════════════════════════════════


class TestRenderPipeline:
    """End-to-end: parse → layout → render → inspect XML."""

    @pytest.fixture()
    def rendered_path(self, oas3_json_path: Path, tmp_path: Path) -> Path:
        spec = OpenAPIParser(source=str(oas3_json_path)).parse()
        cfg = load_config(None)
        ep = build_endpoint_graph(spec)
        sc = build_schema_graph(spec)
        out = tmp_path / "out.drawio"
        return render(ep, sc, out, cfg)

    def test_file_exists(self, rendered_path: Path) -> None:
        assert rendered_path.exists()
        assert rendered_path.suffix == ".drawio"

    def test_file_nonempty(self, rendered_path: Path) -> None:
        assert rendered_path.stat().st_size > 0

    def test_file_is_valid_xml(self, rendered_path: Path) -> None:
        # Should not raise
        tree = ET.parse(rendered_path)
        root = tree.getroot()
        assert root.tag == "mxfile"

    def test_two_pages(self, rendered_path: Path) -> None:
        """A spec with both endpoints AND schemas yields 2 diagram pages."""
        tree = ET.parse(rendered_path)
        diagrams = tree.findall(".//diagram")
        assert len(diagrams) == 2

    def test_page_names(self, rendered_path: Path) -> None:
        tree = ET.parse(rendered_path)
        names = [d.get("name") for d in tree.findall(".//diagram")]
        assert "Endpoints Map" in names
        assert "Schema Map" in names

    def test_returns_path(self, rendered_path: Path) -> None:
        assert isinstance(rendered_path, Path)


class TestRenderObjectCounts:
    """Count mxCell objects to verify shapes/edges actually get emitted."""

    def test_objects_emitted(self, oas3_json_path: Path, tmp_path: Path) -> None:
        spec = OpenAPIParser(source=str(oas3_json_path)).parse()
        cfg = load_config(None)
        ep = build_endpoint_graph(spec)
        sc = build_schema_graph(spec)
        out = tmp_path / "objects.drawio"
        render(ep, sc, out, cfg)

        tree = ET.parse(out)
        # The drawio root has two implicit cells per page (id="0" and "1") plus
        # one cell per Object/Edge.
        cells = tree.findall(".//mxCell")
        # Endpoint nodes (9) + endpoint edges (8) + schema nodes (3) + schema
        # edges (2 Pet<->Owner) + 4 default cells (id=0,1 per page) = at least
        # 26 cells.
        assert len(cells) >= 22


class TestRenderEmptySchemas:
    """A spec with no schemas should still produce a valid single-page file."""

    def test_single_page_when_no_schemas(self, tmp_path: Path) -> None:
        from swagger2drawio.parser.openapi_parser import ParsedSpec

        spec = ParsedSpec(title="OnlyEndpoints", version="1")
        cfg = load_config(None)
        ep = build_endpoint_graph(spec)
        sc = build_schema_graph(spec)  # empty
        out = tmp_path / "onepage.drawio"
        render(ep, sc, out, cfg)

        tree = ET.parse(out)
        diagrams = tree.findall(".//diagram")
        assert len(diagrams) == 1
        assert diagrams[0].get("name") == "Endpoints Map"


class TestRenderCreatesParentDir:
    """``render`` should create missing parent directories."""

    def test_parent_dir_created(self, oas3_json_path: Path, tmp_path: Path) -> None:
        spec = OpenAPIParser(source=str(oas3_json_path)).parse()
        cfg = load_config(None)
        ep = build_endpoint_graph(spec)
        sc = build_schema_graph(spec)
        out = tmp_path / "nested" / "deep" / "result.drawio"
        result = render(ep, sc, out, cfg)
        assert result.exists()
        assert (tmp_path / "nested" / "deep").is_dir()
