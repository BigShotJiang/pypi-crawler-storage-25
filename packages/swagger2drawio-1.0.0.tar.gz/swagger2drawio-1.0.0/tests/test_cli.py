"""Tests for ``swagger2drawio.cli``."""

from __future__ import annotations

from pathlib import Path

from typer.testing import CliRunner

from swagger2drawio import __version__
from swagger2drawio.cli import app

runner = CliRunner()


# ═══════════════════════════════════════════════════════════════
# Version flag
# ═══════════════════════════════════════════════════════════════


class TestVersionFlag:
    """Tests for the ``--version / -v`` flag."""

    def test_long_flag(self) -> None:
        result = runner.invoke(app, ["--version"])
        assert result.exit_code == 0
        assert __version__ in result.output

    def test_short_v_is_verbose_not_version(self) -> None:
        """``-v`` is now reserved for verbosity, not the version banner."""
        result = runner.invoke(app, ["-v"])
        # No subcommand → Typer shows usage and exits with code 2.
        # The point of this test is that -v alone no longer prints the
        # version banner (that's only on --version).
        assert __version__ not in result.output


# ═══════════════════════════════════════════════════════════════
# generate — missing / bad arguments
# ═══════════════════════════════════════════════════════════════


class TestGenerateMissingArgs:
    """Tests that verify error handling for bad CLI inputs."""

    def test_missing_input_flag(self) -> None:
        """Omitting --input should produce an error exit."""
        result = runner.invoke(app, ["generate"])
        assert result.exit_code != 0
        assert "Missing" in result.output or "required" in result.output.lower()

    def test_nonexistent_file(self, tmp_path: Path) -> None:
        """Pointing --input at a missing file triggers a SpecLoadError exit."""
        result = runner.invoke(
            app,
            ["generate", "--input", str(tmp_path / "ghost.yaml")],
        )
        # SpecLoadError → exit code 2
        assert result.exit_code == 2
        combined = (result.stderr or "") + result.output
        assert "SpecLoadError" in combined
        assert "Spec file not found" in combined


# ═══════════════════════════════════════════════════════════════
# generate — happy path
# ═══════════════════════════════════════════════════════════════


class TestGenerateHappyPath:
    """Tests that run the generate command against real fixtures."""

    def test_oas3_json(self, oas3_json_path: Path, tmp_path: Path) -> None:
        out = tmp_path / "result.drawio"
        result = runner.invoke(
            app,
            [
                "generate",
                "--input",
                str(oas3_json_path),
                "--output",
                str(out),
            ],
        )
        assert result.exit_code == 0
        # New summary format: "<path> written (X.X KB) — N path(s), M method(s), K schema(s)."
        assert "5 method(s)" in result.output  # 2+2+1
        assert "3 path(s)" in result.output
        assert "3 schema(s)" in result.output

    def test_oas3_yaml(self, oas3_yaml_path: Path, tmp_path: Path) -> None:
        out = tmp_path / "result.drawio"
        result = runner.invoke(
            app,
            [
                "generate",
                "--input",
                str(oas3_yaml_path),
                "--output",
                str(out),
            ],
        )
        assert result.exit_code == 0
        assert "2 method(s)" in result.output
        assert "1 path(s)" in result.output

    def test_swagger2(self, swagger2_json_path: Path, tmp_path: Path) -> None:
        out = tmp_path / "result.drawio"
        result = runner.invoke(
            app,
            [
                "generate",
                "--input",
                str(swagger2_json_path),
                "--output",
                str(out),
            ],
        )
        assert result.exit_code == 0
        assert "2 schema(s)" in result.output

    def test_minimal_spec(self, minimal_json_path: Path, tmp_path: Path) -> None:
        out = tmp_path / "result.drawio"
        result = runner.invoke(
            app,
            [
                "generate",
                "--input",
                str(minimal_json_path),
                "--output",
                str(out),
            ],
        )
        assert result.exit_code == 0
        assert "0 method(s)" in result.output
        assert "0 schema(s)" in result.output


# ═══════════════════════════════════════════════════════════════
# generate — with --config
# ═══════════════════════════════════════════════════════════════


class TestGenerateWithConfig:
    """Tests that the --config flag is accepted and processed."""

    def test_with_custom_config(
        self,
        oas3_json_path: Path,
        custom_config_path: Path,
        tmp_path: Path,
    ) -> None:
        out = tmp_path / "themed.drawio"
        result = runner.invoke(
            app,
            [
                "generate",
                "--input",
                str(oas3_json_path),
                "--output",
                str(out),
                "--config",
                str(custom_config_path),
            ],
        )
        assert result.exit_code == 0

    def test_with_nonexistent_config_falls_back(
        self,
        oas3_json_path: Path,
        tmp_path: Path,
    ) -> None:
        """A missing config file should NOT crash — it falls back to defaults."""
        out = tmp_path / "fallback.drawio"
        result = runner.invoke(
            app,
            [
                "generate",
                "--input",
                str(oas3_json_path),
                "--output",
                str(out),
                "--config",
                str(tmp_path / "missing_config.yaml"),
            ],
        )
        assert result.exit_code == 0


# ═══════════════════════════════════════════════════════════════
# generate — output messages
# ═══════════════════════════════════════════════════════════════


class TestGenerateOutputMessages:
    """Verify the CLI prints the expected stage messages."""

    def test_summary_present(self, oas3_json_path: Path, tmp_path: Path) -> None:
        out = tmp_path / "msg_test.drawio"
        result = runner.invoke(
            app,
            ["generate", "--input", str(oas3_json_path), "--output", str(out)],
        )
        # Rich.Progress redraws in place; in non-tty captures only the
        # final frame ("Done") plus the summary line survive. We check
        # the user-facing summary, which is the contract that matters.
        assert "written" in result.output
        assert "schema(s)" in result.output
        assert "path(s)" in result.output


# ═══════════════════════════════════════════════════════════════
# Help text
# ═══════════════════════════════════════════════════════════════


class TestHelpText:
    """Verify that help output renders correctly."""

    def test_main_help(self) -> None:
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        assert "swagger2drawio" in result.output

    def test_generate_help(self) -> None:
        result = runner.invoke(app, ["generate", "--help"])
        assert result.exit_code == 0
        assert "--input" in result.output
        assert "--output" in result.output
        assert "--config" in result.output
