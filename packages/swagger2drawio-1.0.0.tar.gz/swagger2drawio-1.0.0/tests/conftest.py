"""Shared pytest fixtures and helpers for swagger2drawio tests."""

from __future__ import annotations

from pathlib import Path

import pytest

# ── Fixture directory ────────────────────────────────────────
FIXTURES_DIR: Path = Path(__file__).parent / "fixtures"


@pytest.fixture()
def fixtures_dir() -> Path:
    """Return the absolute path to the ``tests/fixtures/`` directory."""
    return FIXTURES_DIR


@pytest.fixture()
def oas3_json_path() -> Path:
    """Path to the OAS 3 JSON petstore fixture."""
    return FIXTURES_DIR / "petstore_oas3.json"


@pytest.fixture()
def oas3_yaml_path() -> Path:
    """Path to the OAS 3 YAML petstore fixture."""
    return FIXTURES_DIR / "petstore_oas3.yaml"


@pytest.fixture()
def swagger2_json_path() -> Path:
    """Path to the Swagger 2 JSON fixture."""
    return FIXTURES_DIR / "swagger2.json"


@pytest.fixture()
def minimal_json_path() -> Path:
    """Path to a minimal (empty paths/schemas) fixture."""
    return FIXTURES_DIR / "minimal.json"


@pytest.fixture()
def custom_config_path() -> Path:
    """Path to a custom config YAML fixture."""
    return FIXTURES_DIR / "custom_config.yaml"


@pytest.fixture()
def malformed_json_path() -> Path:
    """Path to an intentionally malformed JSON spec (truncated)."""
    return FIXTURES_DIR / "malformed.json"


@pytest.fixture()
def invalid_spec_path() -> Path:
    """Path to a spec that is well-formed JSON but invalid per the OpenAPI schema."""
    return FIXTURES_DIR / "invalid_spec.json"


@pytest.fixture()
def circular_spec_path() -> Path:
    """Path to a spec exercising local circular $refs (User.partner -> User)."""
    return FIXTURES_DIR / "circular.json"


@pytest.fixture()
def composition_spec_path() -> Path:
    """Path to a spec exercising allOf / oneOf / anyOf / discriminator / enum."""
    return FIXTURES_DIR / "composition.json"


@pytest.fixture()
def oas3_v2_path() -> Path:
    """Path to a deliberate v2 evolution of petstore_oas3.json (for diff tests)."""
    return FIXTURES_DIR / "petstore_oas3_v2.json"
