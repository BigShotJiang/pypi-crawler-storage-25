"""Tests for ``swagger2drawio._logging`` and the CLI verbosity flags."""

from __future__ import annotations

import logging
from pathlib import Path

import pytest
from typer.testing import CliRunner

from swagger2drawio._logging import configure
from swagger2drawio.cli import app

runner = CliRunner()


@pytest.fixture(autouse=True)
def _reset_logging() -> None:
    """Clear handlers between tests so leftover state doesn't bleed."""
    logging.getLogger("swagger2drawio").handlers.clear()


# ═══════════════════════════════════════════════════════════════
# configure()
# ═══════════════════════════════════════════════════════════════


class TestConfigure:
    def test_default_is_warning(self) -> None:
        configure(verbosity=0)
        root = logging.getLogger("swagger2drawio")
        # Exactly one console handler at WARNING.
        assert len(root.handlers) == 1
        assert root.handlers[0].level == logging.WARNING

    def test_v_is_info(self) -> None:
        configure(verbosity=1)
        assert logging.getLogger("swagger2drawio").handlers[0].level == logging.INFO

    def test_vv_is_debug(self) -> None:
        configure(verbosity=2)
        assert logging.getLogger("swagger2drawio").handlers[0].level == logging.DEBUG

    def test_vvv_clamps_to_debug(self) -> None:
        configure(verbosity=5)
        assert logging.getLogger("swagger2drawio").handlers[0].level == logging.DEBUG

    def test_quiet_overrides_verbose(self) -> None:
        configure(verbosity=2, quiet=True)
        assert logging.getLogger("swagger2drawio").handlers[0].level == logging.WARNING

    def test_log_file_adds_file_handler(self, tmp_path: Path) -> None:
        log_file = tmp_path / "out.log"
        configure(verbosity=0, log_file=log_file)
        root = logging.getLogger("swagger2drawio")
        # Console + file = 2 handlers
        assert len(root.handlers) == 2
        file_handlers = [h for h in root.handlers if isinstance(h, logging.FileHandler)]
        assert len(file_handlers) == 1
        assert file_handlers[0].level == logging.DEBUG

    def test_repeated_configure_does_not_stack_handlers(self) -> None:
        configure(verbosity=0)
        configure(verbosity=1)
        configure(verbosity=2)
        assert len(logging.getLogger("swagger2drawio").handlers) == 1

    def test_log_file_directory_is_created(self, tmp_path: Path) -> None:
        nested = tmp_path / "a" / "b" / "trace.log"
        configure(verbosity=0, log_file=nested)
        logger = logging.getLogger("swagger2drawio.test")
        logger.warning("hello world")
        # Close the FileHandler so Windows releases the lock before tmp_path cleanup.
        for h in logging.getLogger("swagger2drawio").handlers:
            if isinstance(h, logging.FileHandler):
                h.close()
        assert nested.exists()


# ═══════════════════════════════════════════════════════════════
# CLI verbosity flags
# ═══════════════════════════════════════════════════════════════


class TestCliVerbosity:
    def test_log_file_records_messages(self, oas3_json_path: Path, tmp_path: Path) -> None:
        log = tmp_path / "trace.log"
        out = tmp_path / "out.drawio"
        result = runner.invoke(
            app,
            [
                "--log-file",
                str(log),
                "-vv",
                "generate",
                "--input",
                str(oas3_json_path),
                "--output",
                str(out),
            ],
        )
        assert result.exit_code == 0
        # Close handlers so Windows releases the lock.
        for h in logging.getLogger("swagger2drawio").handlers:
            if isinstance(h, logging.FileHandler):
                h.close()
        contents = log.read_text(encoding="utf-8")
        # Parser should have emitted an INFO log about loading the spec.
        assert "Loading spec from file" in contents

    def test_version_flag_still_works(self) -> None:
        from swagger2drawio import __version__

        result = runner.invoke(app, ["--version"])
        assert result.exit_code == 0
        assert __version__ in result.output

    def test_short_v_no_longer_prints_version(self, oas3_json_path: Path, tmp_path: Path) -> None:
        """-v is now reserved for verbosity, not version."""
        out = tmp_path / "out.drawio"
        result = runner.invoke(
            app,
            ["-v", "generate", "--input", str(oas3_json_path), "--output", str(out)],
        )
        # -v should NOT exit immediately with the version; instead it just
        # increases verbosity for the rest of the invocation.
        assert result.exit_code == 0
        # Output is the normal generate flow ending in the summary line.
        assert "written" in result.output
