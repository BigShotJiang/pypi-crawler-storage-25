"""Tests for allOf / oneOf / anyOf / discriminator / enum support."""

from __future__ import annotations

import xml.etree.ElementTree as ET
from pathlib import Path

from swagger2drawio.config_loader import load_config
from swagger2drawio.layout.graph_engine import build_endpoint_graph, build_schema_graph
from swagger2drawio.parser.openapi_parser import OpenAPIParser
from swagger2drawio.renderer.drawio_builder import render


class TestParserComposition:
    """SchemaModel should capture allOf / oneOf / anyOf and discriminator."""

    def test_all_of_collected(self, composition_spec_path: Path) -> None:
        spec = OpenAPIParser(source=str(composition_spec_path)).parse()
        dog = next(s for s in spec.schemas if s.name == "Dog")
        assert "BasePet" in dog.all_of

    def test_one_of_collected(self, composition_spec_path: Path) -> None:
        spec = OpenAPIParser(source=str(composition_spec_path)).parse()
        any_pet = next(s for s in spec.schemas if s.name == "AnyPet")
        assert set(any_pet.one_of) == {"Dog", "Cat"}

    def test_any_of_collected(self, composition_spec_path: Path) -> None:
        spec = OpenAPIParser(source=str(composition_spec_path)).parse()
        maybe = next(s for s in spec.schemas if s.name == "MaybePet")
        assert set(maybe.any_of) == {"Dog", "Cat"}

    def test_discriminator_property_collected(self, composition_spec_path: Path) -> None:
        spec = OpenAPIParser(source=str(composition_spec_path)).parse()
        base = next(s for s in spec.schemas if s.name == "BasePet")
        assert base.discriminator == "kind"
        any_pet = next(s for s in spec.schemas if s.name == "AnyPet")
        assert any_pet.discriminator == "kind"

    def test_enum_detected(self, composition_spec_path: Path) -> None:
        spec = OpenAPIParser(source=str(composition_spec_path)).parse()
        pet_type = next(s for s in spec.schemas if s.name == "PetType")
        assert pet_type.is_enum is True
        assert pet_type.enum_values == ["dog", "cat", "bird"]

    def test_non_enum_schema_has_empty_enum_metadata(self, composition_spec_path: Path) -> None:
        spec = OpenAPIParser(source=str(composition_spec_path)).parse()
        base = next(s for s in spec.schemas if s.name == "BasePet")
        assert base.is_enum is False
        assert base.enum_values == []


class TestSchemaGraphCompositionEdges:
    """Composition relationships should produce distinctly-kinded edges."""

    def test_all_of_edge_kind(self, composition_spec_path: Path) -> None:
        spec = OpenAPIParser(source=str(composition_spec_path)).parse()
        layout = build_schema_graph(spec)
        edge = layout.graph.get_edge_data("schema:Dog", "schema:BasePet")
        assert edge is not None
        assert edge.get("edge_kind") == "allOf"

    def test_one_of_edge_kind(self, composition_spec_path: Path) -> None:
        spec = OpenAPIParser(source=str(composition_spec_path)).parse()
        layout = build_schema_graph(spec)
        for variant in ("Dog", "Cat"):
            edge = layout.graph.get_edge_data("schema:AnyPet", f"schema:{variant}")
            assert edge is not None
            assert edge.get("edge_kind") == "oneOf"

    def test_any_of_edge_kind(self, composition_spec_path: Path) -> None:
        spec = OpenAPIParser(source=str(composition_spec_path)).parse()
        layout = build_schema_graph(spec)
        for variant in ("Dog", "Cat"):
            edge = layout.graph.get_edge_data("schema:MaybePet", f"schema:{variant}")
            assert edge is not None
            assert edge.get("edge_kind") == "anyOf"

    def test_enum_node_kind(self, composition_spec_path: Path) -> None:
        spec = OpenAPIParser(source=str(composition_spec_path)).parse()
        layout = build_schema_graph(spec)
        assert layout.nodes["schema:PetType"].kind == "enum"

    def test_entity_node_kind(self, composition_spec_path: Path) -> None:
        spec = OpenAPIParser(source=str(composition_spec_path)).parse()
        layout = build_schema_graph(spec)
        assert layout.nodes["schema:BasePet"].kind == "entity"

    def test_discriminator_marked_in_label(self, composition_spec_path: Path) -> None:
        spec = OpenAPIParser(source=str(composition_spec_path)).parse()
        layout = build_schema_graph(spec)
        label = layout.nodes["schema:BasePet"].label
        assert "discriminator" in label


class TestCompositionRenderPipeline:
    """End-to-end smoke test exercising the allOf / oneOf / anyOf edge styles."""

    def test_full_render_with_composition_styles(
        self, composition_spec_path: Path, tmp_path: Path
    ) -> None:
        spec = OpenAPIParser(source=str(composition_spec_path)).parse()
        cfg = load_config(None)
        ep = build_endpoint_graph(spec)
        sc = build_schema_graph(spec)
        out = tmp_path / "composition.drawio"
        result = render(ep, sc, out, cfg)
        # Render must complete and produce valid XML; this would have
        # failed if any composition edge style had a non-settable
        # drawpyo property like `endFill`.
        assert result.exists()
        ET.parse(result)
