"""Tests for ``swagger2drawio.config_loader``."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from swagger2drawio.config_loader import _deep_merge, load_config

# ═══════════════════════════════════════════════════════════════
# _deep_merge
# ═══════════════════════════════════════════════════════════════


class TestDeepMerge:
    """Unit tests for the recursive _deep_merge helper."""

    def test_flat_override(self) -> None:
        """Override values replace base values for non-dict keys."""
        base = {"a": 1, "b": 2}
        override = {"b": 99}
        result = _deep_merge(base, override)
        assert result == {"a": 1, "b": 99}

    def test_nested_merge(self) -> None:
        """Nested dicts are merged recursively, not replaced wholesale."""
        base = {"layout": {"width": 100, "height": 50}}
        override = {"layout": {"width": 300}}
        result = _deep_merge(base, override)
        assert result["layout"]["width"] == 300
        assert result["layout"]["height"] == 50  # preserved

    def test_new_keys_added(self) -> None:
        """Keys present only in *override* are added to the result."""
        base = {"x": 1}
        override = {"y": 2}
        result = _deep_merge(base, override)
        assert result == {"x": 1, "y": 2}

    def test_base_not_mutated(self) -> None:
        """The original *base* dict must not be mutated."""
        base: dict[str, Any] = {"a": {"nested": 1}}
        override: dict[str, Any] = {"a": {"nested": 99}}
        _deep_merge(base, override)
        assert base["a"]["nested"] == 1

    def test_empty_override(self) -> None:
        """An empty override returns a copy of base."""
        base = {"k": "v"}
        assert _deep_merge(base, {}) == base

    def test_empty_base(self) -> None:
        """An empty base returns a copy of override."""
        override = {"k": "v"}
        assert _deep_merge({}, override) == override

    def test_override_replaces_dict_with_scalar(self) -> None:
        """A scalar in override replaces a dict in base."""
        base: dict[str, Any] = {"a": {"nested": True}}
        override: dict[str, Any] = {"a": "flat_now"}
        result = _deep_merge(base, override)
        assert result["a"] == "flat_now"


# ═══════════════════════════════════════════════════════════════
# load_config
# ═══════════════════════════════════════════════════════════════


class TestLoadConfig:
    """Tests for the public ``load_config`` function."""

    def test_none_returns_defaults(self) -> None:
        """Passing None returns the built-in defaults."""
        cfg = load_config(None)
        assert "layout" in cfg
        assert "endpoint_styles" in cfg
        assert "schema_styles" in cfg

    def test_defaults_match_known_values(self) -> None:
        """Spot-check specific built-in default values."""
        cfg = load_config(None)
        assert cfg["layout"]["node_width"] == 200
        assert cfg["layout"]["rankdir"] == "TB"

    def test_nonexistent_file_returns_defaults(self, tmp_path: Path) -> None:
        """A path that does not exist falls back to defaults silently."""
        missing = tmp_path / "no_such_file.yaml"
        cfg = load_config(missing)
        assert cfg == load_config(None)

    def test_custom_config_overrides(self, custom_config_path: Path) -> None:
        """A user config file partially overrides the defaults."""
        cfg = load_config(custom_config_path)

        # Overridden
        assert cfg["layout"]["node_width"] == 300
        assert cfg["layout"]["vertical_spacing"] == 200

        # Preserved from defaults (not in the custom file)
        assert cfg["layout"]["node_height"] == 60
        assert cfg["layout"]["horizontal_spacing"] == 80

    def test_custom_config_adds_new_keys(self, custom_config_path: Path) -> None:
        """A user config can introduce keys not present in defaults."""
        cfg = load_config(custom_config_path)
        # The fixture adds a "CUSTOM_METHOD" under endpoint_styles
        assert "CUSTOM_METHOD" in cfg["endpoint_styles"]

    def test_custom_config_deep_merges_styles(self, custom_config_path: Path) -> None:
        """Endpoint styles are deep-merged: overridden GET + preserved POST."""
        cfg = load_config(custom_config_path)
        assert "fillColor=#00ff00" in cfg["endpoint_styles"]["GET"]["base_style"]
        # POST was not overridden, should still be the default
        assert "POST" in cfg["endpoint_styles"]

    def test_empty_yaml_returns_defaults(self, tmp_path: Path) -> None:
        """A YAML file with no content (empty) returns defaults."""
        empty_file = tmp_path / "empty.yaml"
        empty_file.write_text("", encoding="utf-8")
        cfg = load_config(empty_file)
        assert cfg["layout"]["node_width"] == 200

    def test_partial_yaml_preserves_unrelated_sections(self, tmp_path: Path) -> None:
        """A YAML that only sets layout leaves styles untouched."""
        partial = tmp_path / "partial.yaml"
        partial.write_text(
            yaml.dump({"layout": {"node_width": 999}}),
            encoding="utf-8",
        )
        cfg = load_config(partial)
        assert cfg["layout"]["node_width"] == 999
        assert "schema_styles" in cfg  # untouched section remains
