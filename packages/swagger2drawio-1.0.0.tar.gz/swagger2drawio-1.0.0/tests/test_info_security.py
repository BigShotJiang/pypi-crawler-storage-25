"""Tests for the info banner + security legend (Phase 3.4)."""

from __future__ import annotations

from pathlib import Path

from swagger2drawio.layout.graph_engine import build_endpoint_graph
from swagger2drawio.parser.openapi_parser import OpenAPIParser


class TestParserSecurityAndServers:
    """ParsedSpec exposes server URLs and security schemes."""

    def test_servers_extracted(self, oas3_json_path: Path) -> None:
        spec = OpenAPIParser(source=str(oas3_json_path)).parse()
        assert "https://api.example.com/v1" in spec.servers
        assert "https://staging.example.com/v1" in spec.servers

    def test_description_extracted(self, oas3_json_path: Path) -> None:
        spec = OpenAPIParser(source=str(oas3_json_path)).parse()
        assert spec.description == "A sample Petstore API"

    def test_security_schemes_extracted(self, oas3_json_path: Path) -> None:
        spec = OpenAPIParser(source=str(oas3_json_path)).parse()
        names = {s.name for s in spec.security_schemes}
        assert {"bearerAuth", "apiKeyAuth"} == names

    def test_bearer_metadata(self, oas3_json_path: Path) -> None:
        spec = OpenAPIParser(source=str(oas3_json_path)).parse()
        bearer = next(s for s in spec.security_schemes if s.name == "bearerAuth")
        assert bearer.type == "http"
        assert bearer.scheme == "bearer"

    def test_api_key_location(self, oas3_json_path: Path) -> None:
        spec = OpenAPIParser(source=str(oas3_json_path)).parse()
        api_key = next(s for s in spec.security_schemes if s.name == "apiKeyAuth")
        assert api_key.type == "apiKey"
        assert api_key.location == "header"

    def test_swagger2_security_definitions(self, swagger2_json_path: Path) -> None:
        # The swagger2 fixture has no security defs, so the list should be empty.
        spec = OpenAPIParser(source=str(swagger2_json_path)).parse()
        assert spec.security_schemes == []

    def test_swagger2_servers_synth(self, swagger2_json_path: Path) -> None:
        # The swagger2 fixture has no `host`/`schemes`, so synth list is empty.
        spec = OpenAPIParser(source=str(swagger2_json_path)).parse()
        assert spec.servers == []


class TestInfoBanner:
    def test_root_banner_includes_title_version_description(self, oas3_json_path: Path) -> None:
        spec = OpenAPIParser(source=str(oas3_json_path)).parse()
        layout = build_endpoint_graph(spec, group_by="path")
        banner = layout.nodes["root"].label
        assert "Petstore API" in banner
        assert "v1.0.0" in banner
        assert "A sample Petstore API" in banner

    def test_root_banner_includes_servers(self, oas3_json_path: Path) -> None:
        spec = OpenAPIParser(source=str(oas3_json_path)).parse()
        layout = build_endpoint_graph(spec, group_by="path")
        banner = layout.nodes["root"].label
        assert "https://api.example.com/v1" in banner


class TestSecurityLegend:
    def test_legend_node_present_when_schemes_exist(self, oas3_json_path: Path) -> None:
        spec = OpenAPIParser(source=str(oas3_json_path)).parse()
        layout = build_endpoint_graph(spec, group_by="path")
        assert "security:legend" in layout.nodes
        legend = layout.nodes["security:legend"]
        assert legend.kind == "security"
        assert "bearerAuth" in legend.label
        assert "apiKeyAuth" in legend.label

    def test_no_legend_when_no_schemes(self, swagger2_json_path: Path) -> None:
        spec = OpenAPIParser(source=str(swagger2_json_path)).parse()
        layout = build_endpoint_graph(spec, group_by="path")
        assert "security:legend" not in layout.nodes
