"""Tests for the network-robustness options on _load_raw_spec and the CLI."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from swagger2drawio.cli import _parse_headers, app
from swagger2drawio.parser.openapi_parser import _load_raw_spec

runner = CliRunner()


VALID_SPEC = {
    "openapi": "3.0.3",
    "info": {"title": "T", "version": "1"},
    "paths": {},
}


# ═══════════════════════════════════════════════════════════════
# _parse_headers
# ═══════════════════════════════════════════════════════════════


class TestParseHeaders:
    def test_none_returns_none(self) -> None:
        assert _parse_headers(None) is None
        assert _parse_headers([]) is None

    def test_single_header(self) -> None:
        result = _parse_headers(["Authorization: Bearer abc"])
        assert result == {"Authorization": "Bearer abc"}

    def test_multiple_headers(self) -> None:
        result = _parse_headers(["X-A: 1", "X-B: two"])
        assert result == {"X-A": "1", "X-B": "two"}

    def test_strips_whitespace(self) -> None:
        result = _parse_headers(["  X-Foo  :   bar  "])
        assert result == {"X-Foo": "bar"}

    def test_value_with_colon(self) -> None:
        # JWT-style values often contain colons; only the first one splits.
        result = _parse_headers(["Authorization: Bearer abc:def:xyz"])
        assert result == {"Authorization": "Bearer abc:def:xyz"}

    def test_missing_colon_raises(self) -> None:
        import typer

        with pytest.raises(typer.BadParameter, match="Invalid --header"):
            _parse_headers(["bogus-no-colon"])


# ═══════════════════════════════════════════════════════════════
# _load_raw_spec: timeout, headers, verify_ssl
# ═══════════════════════════════════════════════════════════════


def _mock_response(spec: dict[str, object]) -> MagicMock:
    mock = MagicMock()
    mock.text = json.dumps(spec)
    mock.raise_for_status = MagicMock()
    return mock


class TestLoaderNetworkOptions:
    def test_default_timeout(self) -> None:
        with patch(
            "swagger2drawio.parser.openapi_parser.requests.get",
            return_value=_mock_response(VALID_SPEC),
        ) as mock_get:
            _load_raw_spec("https://example.com/api.json")
            kwargs = mock_get.call_args.kwargs
            assert kwargs["timeout"] == 10.0
            assert kwargs["verify"] is True
            assert kwargs["headers"] is None
            assert kwargs["allow_redirects"] is True

    def test_custom_timeout(self) -> None:
        with patch(
            "swagger2drawio.parser.openapi_parser.requests.get",
            return_value=_mock_response(VALID_SPEC),
        ) as mock_get:
            _load_raw_spec("https://example.com/api.json", timeout=3.5)
            assert mock_get.call_args.kwargs["timeout"] == 3.5

    def test_custom_headers(self) -> None:
        with patch(
            "swagger2drawio.parser.openapi_parser.requests.get",
            return_value=_mock_response(VALID_SPEC),
        ) as mock_get:
            _load_raw_spec("https://example.com/api.json", headers={"Authorization": "Bearer x"})
            assert mock_get.call_args.kwargs["headers"] == {"Authorization": "Bearer x"}

    def test_verify_ssl_false(self) -> None:
        with patch(
            "swagger2drawio.parser.openapi_parser.requests.get",
            return_value=_mock_response(VALID_SPEC),
        ) as mock_get:
            _load_raw_spec("https://example.com/api.json", verify_ssl=False)
            assert mock_get.call_args.kwargs["verify"] is False


# ═══════════════════════════════════════════════════════════════
# CLI plumbs --timeout / --header / --insecure through
# ═══════════════════════════════════════════════════════════════


class TestCliNetworkFlags:
    def test_cli_passes_headers_and_timeout(self, tmp_path: Path) -> None:
        out = tmp_path / "out.drawio"
        with patch(
            "swagger2drawio.parser.openapi_parser.requests.get",
            return_value=_mock_response(VALID_SPEC),
        ) as mock_get:
            result = runner.invoke(
                app,
                [
                    "generate",
                    "--input",
                    "https://example.com/api.json",
                    "--output",
                    str(out),
                    "--no-validate",
                    "--timeout",
                    "5",
                    "-H",
                    "Authorization: Bearer xyz",
                    "-H",
                    "X-Trace-Id: abc",
                ],
            )
            assert result.exit_code == 0, result.output
            kwargs = mock_get.call_args.kwargs
            assert kwargs["timeout"] == 5.0
            assert kwargs["headers"] == {
                "Authorization": "Bearer xyz",
                "X-Trace-Id": "abc",
            }

    def test_cli_insecure_disables_verify_and_warns(self, tmp_path: Path) -> None:
        out = tmp_path / "out.drawio"
        with patch(
            "swagger2drawio.parser.openapi_parser.requests.get",
            return_value=_mock_response(VALID_SPEC),
        ) as mock_get:
            result = runner.invoke(
                app,
                [
                    "generate",
                    "--input",
                    "https://example.com/api.json",
                    "--output",
                    str(out),
                    "--no-validate",
                    "--insecure",
                ],
            )
            assert result.exit_code == 0
            assert mock_get.call_args.kwargs["verify"] is False
            combined = (result.stderr or "") + result.output
            assert "TLS verification disabled" in combined

    def test_cli_bad_header_format_errors(self, tmp_path: Path) -> None:
        result = runner.invoke(
            app,
            [
                "generate",
                "--input",
                "https://example.com/api.json",
                "--output",
                str(tmp_path / "out.drawio"),
                "-H",
                "bogus_no_colon",
            ],
        )
        assert result.exit_code != 0
        combined = (result.stderr or "") + result.output
        assert "Invalid --header" in combined or "BadParameter" in combined
