"""Tests for ``swagger2drawio.refs`` and end-to-end $ref handling."""

from __future__ import annotations

import json
import xml.etree.ElementTree as ET
from pathlib import Path

import pytest

from swagger2drawio.config_loader import load_config
from swagger2drawio.exceptions import SpecLoadError
from swagger2drawio.layout.graph_engine import build_endpoint_graph, build_schema_graph
from swagger2drawio.parser.openapi_parser import OpenAPIParser
from swagger2drawio.refs import RefResolver
from swagger2drawio.renderer.drawio_builder import render

# ═══════════════════════════════════════════════════════════════
# Local circular refs — must terminate
# ═══════════════════════════════════════════════════════════════


class TestCircularRefs:
    """A spec where User refers to itself should parse and render without hanging."""

    def test_parser_terminates(self, circular_spec_path: Path) -> None:
        spec = OpenAPIParser(source=str(circular_spec_path)).parse()
        names = {s.name for s in spec.schemas}
        assert names == {"User", "Company"}

    def test_self_ref_edge_present(self, circular_spec_path: Path) -> None:
        spec = OpenAPIParser(source=str(circular_spec_path)).parse()
        layout = build_schema_graph(spec)
        # User has a self-edge via the `partner` ref AND `friends[]` ref.
        assert layout.graph.has_edge("schema:User", "schema:User")

    def test_mutual_ref_edges_present(self, circular_spec_path: Path) -> None:
        spec = OpenAPIParser(source=str(circular_spec_path)).parse()
        layout = build_schema_graph(spec)
        # User ↔ Company round-trip via User.company and Company.ceo.
        assert layout.graph.has_edge("schema:User", "schema:Company")
        assert layout.graph.has_edge("schema:Company", "schema:User")

    def test_render_pipeline_completes(self, circular_spec_path: Path, tmp_path: Path) -> None:
        spec = OpenAPIParser(source=str(circular_spec_path)).parse()
        cfg = load_config(None)
        ep = build_endpoint_graph(spec)
        sc = build_schema_graph(spec)
        out = tmp_path / "circular.drawio"
        result = render(ep, sc, out, cfg)
        # File exists and is valid XML
        assert result.exists()
        ET.parse(result)


# ═══════════════════════════════════════════════════════════════
# External file refs — RefResolver
# ═══════════════════════════════════════════════════════════════


class TestExternalFileRef:
    @pytest.fixture()
    def external_setup(self, tmp_path: Path) -> tuple[Path, Path]:
        """Build a root spec that $refs an Address schema in a sibling file."""
        address = {
            "type": "object",
            "properties": {
                "street": {"type": "string"},
                "city": {"type": "string"},
            },
        }
        (tmp_path / "schemas").mkdir()
        external = tmp_path / "schemas" / "address.json"
        external.write_text(json.dumps(address), encoding="utf-8")

        root = {
            "openapi": "3.0.3",
            "info": {"title": "WithExternal", "version": "1"},
            "paths": {},
            "components": {
                "schemas": {
                    "Person": {
                        "type": "object",
                        "properties": {
                            "name": {"type": "string"},
                            "home": {"$ref": "./schemas/address.json"},
                        },
                    }
                }
            },
        }
        root_path = tmp_path / "root.json"
        root_path.write_text(json.dumps(root), encoding="utf-8")
        return root_path, external

    def test_resolver_inlines_external_file(self, external_setup: tuple[Path, Path]) -> None:
        root_path, _ = external_setup
        with root_path.open(encoding="utf-8") as fh:
            raw = json.load(fh)
        resolver = RefResolver(source=str(root_path))
        resolver.resolve(raw)
        pending = resolver.pending_schemas()
        # Exactly one external schema should have been registered.
        assert len(pending) == 1
        assert any("address" in name.lower() for name in pending)

    def test_parser_resolves_external_by_default(self, external_setup: tuple[Path, Path]) -> None:
        root_path, _ = external_setup
        spec = OpenAPIParser(source=str(root_path)).parse()
        names = {s.name for s in spec.schemas}
        # Person should have a ref edge to the inlined Address schema.
        assert "Person" in names
        # The inlined schema appears with an External_* prefix.
        assert any(n.startswith("External_") for n in names)

    def test_parser_resolves_external_when_disabled(
        self, external_setup: tuple[Path, Path]
    ) -> None:
        root_path, _ = external_setup
        spec = OpenAPIParser(source=str(root_path)).parse(resolve_external_refs=False)
        # Without resolution, only the locally-declared schema is present.
        names = {s.name for s in spec.schemas}
        assert names == {"Person"}


class TestExternalRefMissingFile:
    def test_missing_external_file_raises_spec_load_error(self, tmp_path: Path) -> None:
        root = {
            "openapi": "3.0.3",
            "info": {"title": "Broken", "version": "1"},
            "paths": {},
            "components": {
                "schemas": {
                    "X": {"$ref": "./missing.yaml"},
                }
            },
        }
        root_path = tmp_path / "root.json"
        root_path.write_text(json.dumps(root), encoding="utf-8")
        with pytest.raises(SpecLoadError):
            OpenAPIParser(source=str(root_path)).parse()


# ═══════════════════════════════════════════════════════════════
# Caching: same external doc fetched twice → one fetch
# ═══════════════════════════════════════════════════════════════


class TestResolverCaching:
    def test_cache_avoids_duplicate_reads(self, tmp_path: Path) -> None:
        # Reference the same external file twice from two different fields.
        ext = tmp_path / "tag.json"
        ext.write_text(json.dumps({"type": "string"}), encoding="utf-8")

        root = {
            "openapi": "3.0.3",
            "info": {"title": "TwoRefs", "version": "1"},
            "paths": {},
            "components": {
                "schemas": {
                    "A": {
                        "type": "object",
                        "properties": {
                            "tag1": {"$ref": "./tag.json"},
                            "tag2": {"$ref": "./tag.json"},
                        },
                    }
                }
            },
        }
        root_path = tmp_path / "root.json"
        root_path.write_text(json.dumps(root), encoding="utf-8")

        with root_path.open(encoding="utf-8") as fh:
            raw = json.load(fh)
        resolver = RefResolver(source=str(root_path))
        resolver.resolve(raw)
        # Both refs map to the *same* generated local name.
        pending = resolver.pending_schemas()
        assert len(pending) == 1
