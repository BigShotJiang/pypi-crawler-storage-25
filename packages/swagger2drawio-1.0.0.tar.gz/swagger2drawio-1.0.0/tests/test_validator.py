"""Tests for ``swagger2drawio.validator`` and the ``validate`` CLI subcommand."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from typer.testing import CliRunner

from swagger2drawio.cli import app
from swagger2drawio.exceptions import EXIT_CODE, SpecValidationError
from swagger2drawio.validator import validate_spec

runner = CliRunner()


# ═══════════════════════════════════════════════════════════════
# validate_spec — direct call
# ═══════════════════════════════════════════════════════════════


class TestValidateSpec:
    def test_valid_oas3_passes(self, oas3_json_path: Path) -> None:
        with oas3_json_path.open(encoding="utf-8") as fh:
            spec = json.load(fh)
        # Must not raise
        validate_spec(spec)

    def test_valid_swagger2_passes(self, swagger2_json_path: Path) -> None:
        with swagger2_json_path.open(encoding="utf-8") as fh:
            spec = json.load(fh)
        validate_spec(spec)

    def test_invalid_spec_raises(self, invalid_spec_path: Path) -> None:
        with invalid_spec_path.open(encoding="utf-8") as fh:
            spec = json.load(fh)
        with pytest.raises(SpecValidationError, match="Spec validation failed"):
            validate_spec(spec)

    def test_error_message_includes_path(self, invalid_spec_path: Path) -> None:
        with invalid_spec_path.open(encoding="utf-8") as fh:
            spec = json.load(fh)
        with pytest.raises(SpecValidationError) as info:
            validate_spec(spec)
        # The validator reports the JSON pointer to the failing operation.
        # We just confirm the message is non-empty and human-readable.
        assert "/" in str(info.value)


# ═══════════════════════════════════════════════════════════════
# Parser.parse(validate=True)
# ═══════════════════════════════════════════════════════════════


class TestParserValidateFlag:
    def test_parser_validates_when_asked(self, invalid_spec_path: Path) -> None:
        from swagger2drawio.parser.openapi_parser import OpenAPIParser

        with pytest.raises(SpecValidationError):
            OpenAPIParser(source=str(invalid_spec_path)).parse(validate=True)

    def test_parser_skips_validation_by_default(self, invalid_spec_path: Path) -> None:
        from swagger2drawio.parser.openapi_parser import OpenAPIParser

        # Invalid per the schema, but the parser is lenient by default.
        spec = OpenAPIParser(source=str(invalid_spec_path)).parse()
        assert spec.title == "Invalid"


# ═══════════════════════════════════════════════════════════════
# `validate` CLI subcommand
# ═══════════════════════════════════════════════════════════════


class TestValidateCommand:
    def test_valid_spec_exits_zero(self, oas3_json_path: Path) -> None:
        result = runner.invoke(app, ["validate", str(oas3_json_path)])
        assert result.exit_code == 0
        assert "valid" in result.output.lower()

    def test_invalid_spec_exits_with_validation_code(self, invalid_spec_path: Path) -> None:
        result = runner.invoke(app, ["validate", str(invalid_spec_path)])
        assert result.exit_code == EXIT_CODE[SpecValidationError]
        combined = (result.stderr or "") + result.output
        assert "SpecValidationError" in combined

    def test_missing_file_exits_with_load_code(self, tmp_path: Path) -> None:
        from swagger2drawio.exceptions import SpecLoadError

        result = runner.invoke(app, ["validate", str(tmp_path / "ghost.json")])
        assert result.exit_code == EXIT_CODE[SpecLoadError]


# ═══════════════════════════════════════════════════════════════
# `generate` with / without --no-validate
# ═══════════════════════════════════════════════════════════════


class TestGenerateValidates:
    def test_generate_rejects_invalid_spec_by_default(
        self, invalid_spec_path: Path, tmp_path: Path
    ) -> None:
        result = runner.invoke(
            app,
            [
                "generate",
                "--input",
                str(invalid_spec_path),
                "--output",
                str(tmp_path / "out.drawio"),
            ],
        )
        assert result.exit_code == EXIT_CODE[SpecValidationError]

    def test_generate_accepts_invalid_spec_with_no_validate(
        self, invalid_spec_path: Path, tmp_path: Path
    ) -> None:
        result = runner.invoke(
            app,
            [
                "generate",
                "--input",
                str(invalid_spec_path),
                "--output",
                str(tmp_path / "out.drawio"),
                "--no-validate",
            ],
        )
        assert result.exit_code == 0
        assert (tmp_path / "out.drawio").exists()
