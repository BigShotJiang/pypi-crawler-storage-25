"""Tests for the diff computation and the polished diff renderer."""

from __future__ import annotations

import xml.etree.ElementTree as ET
from pathlib import Path

from typer.testing import CliRunner

from swagger2drawio.cli import app
from swagger2drawio.diff import (
    MethodKey,
    SchemaDiff,
    SpecDiff,
    compute_diff,
)
from swagger2drawio.parser.openapi_parser import OpenAPIParser
from swagger2drawio.renderer.diff_renderer import render_diff

runner = CliRunner()


# ═══════════════════════════════════════════════════════════════
# compute_diff
# ═══════════════════════════════════════════════════════════════


class TestComputeDiffEmpty:
    def test_self_diff_is_empty(self, oas3_json_path: Path) -> None:
        spec = OpenAPIParser(source=str(oas3_json_path)).parse()
        result = compute_diff(spec, spec)
        assert result.is_empty


class TestComputeDiffPathsAndMethods:
    """Compare petstore v1 → v2 (a deliberate breaking evolution)."""

    def _diff(self, old: Path, new: Path) -> SpecDiff:
        old_spec = OpenAPIParser(source=str(old)).parse(validate=False)
        new_spec = OpenAPIParser(source=str(new)).parse(validate=False)
        return compute_diff(old_spec, new_spec)

    def test_path_added(self, oas3_json_path: Path, oas3_v2_path: Path) -> None:
        result = self._diff(oas3_json_path, oas3_v2_path)
        # v2 adds /pets/{petId}/archive
        assert "/pets/{petId}/archive" in result.paths_added

    def test_path_removed(self, oas3_json_path: Path, oas3_v2_path: Path) -> None:
        result = self._diff(oas3_json_path, oas3_v2_path)
        # v2 drops /owners
        assert "/owners" in result.paths_removed

    def test_methods_for_removed_path_classified_removed(
        self, oas3_json_path: Path, oas3_v2_path: Path
    ) -> None:
        result = self._diff(oas3_json_path, oas3_v2_path)
        # The GET on /owners was removed because the path went away.
        keys = {(k.route, k.verb) for k in result.methods_removed}
        assert ("/owners", "GET") in keys

    def test_methods_added_within_existing_path(
        self, oas3_json_path: Path, oas3_v2_path: Path
    ) -> None:
        result = self._diff(oas3_json_path, oas3_v2_path)
        # v2 keeps /pets/{petId} but removes DELETE on it.
        keys = {(k.route, k.verb) for k in result.methods_removed}
        assert ("/pets/{petId}", "DELETE") in keys

    def test_changed_method_detected(self, oas3_json_path: Path, oas3_v2_path: Path) -> None:
        result = self._diff(oas3_json_path, oas3_v2_path)
        # GET /pets gained a `limit` query parameter AND changed summary.
        get_pets = next(
            m for m in result.methods_changed if m.key == MethodKey(route="/pets", verb="GET")
        )
        assert get_pets.parameters_changed
        assert get_pets.summary_changed


class TestComputeDiffSchemas:
    def test_schema_field_added(self, oas3_json_path: Path, oas3_v2_path: Path) -> None:
        old = OpenAPIParser(source=str(oas3_json_path)).parse(validate=False)
        new = OpenAPIParser(source=str(oas3_v2_path)).parse(validate=False)
        result = compute_diff(old, new)
        # Pet schema gained `archived`; Error gained `trace_id`.
        pet_diff = next(s for s in result.schemas_changed if s.name == "Pet")
        assert "archived" in pet_diff.fields_added
        error_diff = next(s for s in result.schemas_changed if s.name == "Error")
        assert "trace_id" in error_diff.fields_added

    def test_no_phantom_changes_on_unchanged_schema(
        self, oas3_json_path: Path, oas3_v2_path: Path
    ) -> None:
        old = OpenAPIParser(source=str(oas3_json_path)).parse(validate=False)
        new = OpenAPIParser(source=str(oas3_v2_path)).parse(validate=False)
        result = compute_diff(old, new)
        # Owner is unchanged in v2; it should not appear in schemas_changed.
        names = {s.name for s in result.schemas_changed}
        assert "Owner" not in names


class TestSchemaDiffEdgeCases:
    def test_empty_diff(self) -> None:
        d = SchemaDiff(name="X")
        assert d.any_change is False

    def test_composition_change_alone_counts(self) -> None:
        d = SchemaDiff(name="X", composition_changed=True)
        assert d.any_change is True


# ═══════════════════════════════════════════════════════════════
# Render pipeline
# ═══════════════════════════════════════════════════════════════


class TestDiffRenderer:
    def _render(self, old: Path, new: Path, out: Path) -> Path:
        old_spec = OpenAPIParser(source=str(old)).parse(validate=False)
        new_spec = OpenAPIParser(source=str(new)).parse(validate=False)
        result = compute_diff(old_spec, new_spec)
        return render_diff(old_spec, new_spec, result, out)

    def test_renders_three_pages(
        self, oas3_json_path: Path, oas3_v2_path: Path, tmp_path: Path
    ) -> None:
        out = tmp_path / "diff.drawio"
        result = self._render(oas3_json_path, oas3_v2_path, out)
        assert result.exists()
        tree = ET.parse(result)
        pages = [d.get("name") for d in tree.findall(".//diagram")]
        assert pages == ["Summary", "Endpoints", "Schemas"]

    def test_empty_diff_still_renders(self, oas3_json_path: Path, tmp_path: Path) -> None:
        out = tmp_path / "empty_diff.drawio"
        self._render(oas3_json_path, oas3_json_path, out)
        # Summary page should mention "No structural changes".
        tree = ET.parse(out)
        text_blobs = [
            cell.get("value", "") for cell in tree.findall(".//mxCell") if cell.get("value")
        ]
        assert any("No structural changes" in t for t in text_blobs)

    def test_added_color_present_in_xml(
        self, oas3_json_path: Path, oas3_v2_path: Path, tmp_path: Path
    ) -> None:
        out = tmp_path / "colors.drawio"
        self._render(oas3_json_path, oas3_v2_path, out)
        xml = out.read_text(encoding="utf-8")
        # Green addition fill.
        assert "#d5e8d4" in xml
        # Red removal fill.
        assert "#f8cecc" in xml
        # Yellow changed fill.
        assert "#fff2cc" in xml


# ═══════════════════════════════════════════════════════════════
# `diff` CLI subcommand
# ═══════════════════════════════════════════════════════════════


class TestDiffCommand:
    def test_diff_command_writes_file(
        self, oas3_json_path: Path, oas3_v2_path: Path, tmp_path: Path
    ) -> None:
        out = tmp_path / "out.drawio"
        result = runner.invoke(
            app,
            [
                "diff",
                str(oas3_json_path),
                str(oas3_v2_path),
                "--output",
                str(out),
            ],
        )
        assert result.exit_code == 0, result.output
        assert out.exists()
        assert "Diff diagram saved" in result.output

    def test_diff_command_self_compare_reports_no_changes(
        self, oas3_json_path: Path, tmp_path: Path
    ) -> None:
        out = tmp_path / "out.drawio"
        result = runner.invoke(
            app,
            [
                "diff",
                str(oas3_json_path),
                str(oas3_json_path),
                "--output",
                str(out),
            ],
        )
        assert result.exit_code == 0
        assert "No structural changes" in result.output

    def test_diff_command_missing_file_uses_load_exit_code(self, tmp_path: Path) -> None:
        from swagger2drawio.exceptions import EXIT_CODE, SpecLoadError

        result = runner.invoke(
            app,
            [
                "diff",
                str(tmp_path / "ghost_a.json"),
                str(tmp_path / "ghost_b.json"),
                "--output",
                str(tmp_path / "out.drawio"),
            ],
        )
        assert result.exit_code == EXIT_CODE[SpecLoadError]
