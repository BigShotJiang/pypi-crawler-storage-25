"""Tests for the pluggable layout strategies (Phase 5.3)."""

from __future__ import annotations

from pathlib import Path

import pytest

from swagger2drawio.exceptions import LayoutError
from swagger2drawio.layout.graph_engine import build_endpoint_graph
from swagger2drawio.layout.strategies import (
    GridLayout,
    HierarchicalBFSLayout,
    LayoutStrategy,
    available_strategies,
    get_strategy,
)
from swagger2drawio.parser.openapi_parser import OpenAPIParser


class TestStrategyRegistry:
    def test_builtins_registered(self) -> None:
        strategies = available_strategies()
        assert "hierarchical" in strategies
        assert "grid" in strategies

    def test_get_known_strategy(self) -> None:
        assert isinstance(get_strategy("hierarchical"), HierarchicalBFSLayout)
        assert isinstance(get_strategy("grid"), GridLayout)

    def test_get_unknown_strategy_raises(self) -> None:
        with pytest.raises(LayoutError, match="Unknown layout strategy"):
            get_strategy("warp-drive")

    def test_builtins_satisfy_protocol(self) -> None:
        assert isinstance(HierarchicalBFSLayout(), LayoutStrategy)
        assert isinstance(GridLayout(), LayoutStrategy)


class TestBuildEndpointGraphWithLayout:
    def test_hierarchical_layout_default(self, oas3_json_path: Path) -> None:
        spec = OpenAPIParser(source=str(oas3_json_path)).parse()
        result = build_endpoint_graph(spec, group_by="path", layout="hierarchical")
        # Root sits at y=0 and a path sits below it.
        assert result.nodes["root"].y == 0
        path_ys = [n.y for nid, n in result.nodes.items() if nid.startswith("path:")]
        assert all(y > 0 for y in path_ys)

    def test_grid_layout_places_everything_on_a_grid(self, oas3_json_path: Path) -> None:
        spec = OpenAPIParser(source=str(oas3_json_path)).parse()
        result = build_endpoint_graph(spec, group_by="path", layout="grid")
        # Every node should be at a non-negative integer-multiple of the cell width.
        xs = [n.x for n in result.nodes.values()]
        ys = [n.y for n in result.nodes.values()]
        assert all(x >= 0 for x in xs)
        assert all(y >= 0 for y in ys)
        # Unique coordinates (grid layout never overlaps).
        positions = [(n.x, n.y) for n in result.nodes.values()]
        assert len(positions) == len(set(positions))

    def test_unknown_layout_raises(self, oas3_json_path: Path) -> None:
        spec = OpenAPIParser(source=str(oas3_json_path)).parse()
        with pytest.raises(LayoutError):
            build_endpoint_graph(spec, layout="warp-drive")


class TestCliLayoutFlag:
    def test_cli_passes_layout_through(self, oas3_json_path: Path, tmp_path: Path) -> None:
        from typer.testing import CliRunner

        from swagger2drawio.cli import app

        out = tmp_path / "out.drawio"
        result = CliRunner().invoke(
            app,
            [
                "generate",
                "--input",
                str(oas3_json_path),
                "--output",
                str(out),
                "--layout",
                "grid",
                "--no-validate",
            ],
        )
        assert result.exit_code == 0, result.output
        assert out.exists()

    def test_cli_rejects_bad_layout(self, oas3_json_path: Path, tmp_path: Path) -> None:
        from typer.testing import CliRunner

        from swagger2drawio.cli import app
        from swagger2drawio.exceptions import EXIT_CODE

        out = tmp_path / "out.drawio"
        result = CliRunner().invoke(
            app,
            [
                "generate",
                "--input",
                str(oas3_json_path),
                "--output",
                str(out),
                "--layout",
                "warp-drive",
                "--no-validate",
            ],
        )
        assert result.exit_code == EXIT_CODE[LayoutError]
