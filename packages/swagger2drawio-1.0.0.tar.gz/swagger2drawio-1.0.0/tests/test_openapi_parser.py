"""Tests for ``swagger2drawio.parser.openapi_parser``."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from swagger2drawio.exceptions import SpecLoadError, SpecParseError
from swagger2drawio.parser.openapi_parser import (
    MethodDetail,
    OpenAPIParser,
    ParsedSpec,
    SchemaField,
    _is_url,
    _load_raw_spec,
    _resolve_ref_name,
)

# ═══════════════════════════════════════════════════════════════
# Helper functions
# ═══════════════════════════════════════════════════════════════


class TestResolveRefName:
    """Unit tests for ``_resolve_ref_name``."""

    def test_oas3_components_ref(self) -> None:
        assert _resolve_ref_name("#/components/schemas/Pet") == "Pet"

    def test_swagger2_definitions_ref(self) -> None:
        assert _resolve_ref_name("#/definitions/Category") == "Category"

    def test_deeply_nested_ref(self) -> None:
        assert _resolve_ref_name("#/a/b/c/d/DeepModel") == "DeepModel"

    def test_single_segment(self) -> None:
        assert _resolve_ref_name("JustAName") == "JustAName"


class TestIsUrl:
    """Unit tests for ``_is_url``."""

    def test_http(self) -> None:
        assert _is_url("http://example.com/spec.json") is True

    def test_https(self) -> None:
        assert _is_url("https://example.com/spec.yaml") is True

    def test_local_path(self) -> None:
        assert _is_url("./specs/api.yaml") is False

    def test_windows_path(self) -> None:
        assert _is_url("C:\\Users\\spec.json") is False

    def test_ftp_is_not_url(self) -> None:
        assert _is_url("ftp://files.example.com/spec.json") is False


# ═══════════════════════════════════════════════════════════════
# _load_raw_spec
# ═══════════════════════════════════════════════════════════════


class TestLoadRawSpec:
    """Tests for the ``_load_raw_spec`` file/URL loader."""

    def test_loads_json_file(self, oas3_json_path: Path) -> None:
        data = _load_raw_spec(str(oas3_json_path))
        assert data["openapi"] == "3.0.3"
        assert data["info"]["title"] == "Petstore API"

    def test_loads_yaml_file(self, oas3_yaml_path: Path) -> None:
        data = _load_raw_spec(str(oas3_yaml_path))
        assert data["openapi"] == "3.0.3"
        assert data["info"]["title"] == "Petstore YAML"

    def test_missing_file_raises(self, tmp_path: Path) -> None:
        with pytest.raises(SpecLoadError, match="Spec file not found"):
            _load_raw_spec(str(tmp_path / "does_not_exist.json"))

    def test_invalid_content_raises(self, tmp_path: Path) -> None:
        """A file that is not a valid JSON/YAML mapping raises SpecParseError."""
        bad_file = tmp_path / "bad.txt"
        bad_file.write_text("just a plain string", encoding="utf-8")
        # yaml.safe_load("just a plain string") returns str, not dict
        with pytest.raises(SpecParseError, match="could not be parsed"):
            _load_raw_spec(str(bad_file))

    def test_url_download_json(self) -> None:
        """Simulates downloading a JSON spec from a URL."""
        fake_spec = json.dumps({"openapi": "3.0.3", "info": {"title": "Remote"}})
        mock_resp = MagicMock()
        mock_resp.text = fake_spec
        mock_resp.raise_for_status = MagicMock()

        with patch(
            "swagger2drawio.parser.openapi_parser.requests.get", return_value=mock_resp
        ) as mock_get:
            data = _load_raw_spec("https://example.com/api.json")
            assert mock_get.call_args.args == ("https://example.com/api.json",)
            assert mock_get.call_args.kwargs["timeout"] == 10.0
            assert data["info"]["title"] == "Remote"

    def test_malformed_json_falls_back_to_yaml_and_raises(self, malformed_json_path: Path) -> None:
        """A truncated JSON file is wrapped as a SpecParseError."""
        with pytest.raises(SpecParseError):
            _load_raw_spec(str(malformed_json_path))

    def test_url_http_error_raises(self) -> None:
        """An HTTP error from a URL is wrapped as a SpecLoadError."""
        import requests as _req

        mock_resp = MagicMock()
        mock_resp.raise_for_status.side_effect = _req.HTTPError("404 Not Found")

        with (
            patch("swagger2drawio.parser.openapi_parser.requests.get", return_value=mock_resp),
            pytest.raises(SpecLoadError, match="Failed to fetch spec"),
        ):
            _load_raw_spec("https://example.com/missing.json")


# ═══════════════════════════════════════════════════════════════
# Dataclass construction
# ═══════════════════════════════════════════════════════════════


class TestDataclasses:
    """Verify dataclass construction and immutability."""

    def test_schema_field_defaults(self) -> None:
        f = SchemaField(name="id", type="integer")
        assert f.format is None
        assert f.ref_target is None
        assert f.is_array is False

    def test_schema_field_frozen(self) -> None:
        f = SchemaField(name="id", type="integer")
        with pytest.raises(AttributeError):
            f.name = "changed"  # type: ignore[misc]

    def test_method_detail_defaults(self) -> None:
        m = MethodDetail(verb="GET")
        assert m.summary is None
        assert m.operation_id is None
        assert m.tags == []
        assert m.parameters == []
        assert m.request_body_ref is None
        assert m.response_refs == {}
        assert m.deprecated is False

    def test_parsed_spec_defaults(self) -> None:
        s = ParsedSpec(title="T", version="1")
        assert s.paths == []
        assert s.schemas == []


# ═══════════════════════════════════════════════════════════════
# OpenAPIParser — OAS 3.x (JSON)
# ═══════════════════════════════════════════════════════════════


class TestOpenAPIParserOAS3JSON:
    """Integration tests parsing the OAS 3 JSON fixture."""

    @pytest.fixture(autouse=True)
    def _parse(self, oas3_json_path: Path) -> None:
        self.spec = OpenAPIParser(source=str(oas3_json_path)).parse()

    # ── Top-level metadata ───────────────────────────────────

    def test_title(self) -> None:
        assert self.spec.title == "Petstore API"

    def test_version(self) -> None:
        assert self.spec.version == "1.0.0"

    # ── Paths ────────────────────────────────────────────────

    def test_path_count(self) -> None:
        assert len(self.spec.paths) == 3

    def test_path_routes(self) -> None:
        routes = {p.route for p in self.spec.paths}
        assert routes == {"/pets", "/pets/{petId}", "/owners"}

    def test_pets_methods(self) -> None:
        pets = next(p for p in self.spec.paths if p.route == "/pets")
        verbs = {m.verb for m in pets.methods}
        assert verbs == {"GET", "POST"}

    def test_pets_petid_methods(self) -> None:
        pet_id = next(p for p in self.spec.paths if p.route == "/pets/{petId}")
        verbs = {m.verb for m in pet_id.methods}
        assert verbs == {"GET", "DELETE"}

    def test_method_summary(self) -> None:
        pets = next(p for p in self.spec.paths if p.route == "/pets")
        get_method = next(m for m in pets.methods if m.verb == "GET")
        assert get_method.summary == "List all pets"

    def test_method_operation_id(self) -> None:
        pets = next(p for p in self.spec.paths if p.route == "/pets")
        post_method = next(m for m in pets.methods if m.verb == "POST")
        assert post_method.operation_id == "createPet"

    def test_method_tags(self) -> None:
        owners = next(p for p in self.spec.paths if p.route == "/owners")
        get_method = next(m for m in owners.methods if m.verb == "GET")
        assert get_method.tags == ["owners"]

    def test_total_endpoint_count(self) -> None:
        total = sum(len(p.methods) for p in self.spec.paths)
        assert total == 5  # 2 + 2 + 1

    # ── Schemas ──────────────────────────────────────────────

    def test_schema_count(self) -> None:
        assert len(self.spec.schemas) == 3

    def test_schema_names(self) -> None:
        names = {s.name for s in self.spec.schemas}
        assert names == {"Pet", "Owner", "Error"}

    def test_pet_schema_fields(self) -> None:
        pet = next(s for s in self.spec.schemas if s.name == "Pet")
        field_names = [f.name for f in pet.fields]
        assert field_names == ["id", "name", "tag", "owner"]

    def test_pet_description(self) -> None:
        pet = next(s for s in self.spec.schemas if s.name == "Pet")
        assert pet.description == "A pet in the store"

    def test_pet_id_field(self) -> None:
        pet = next(s for s in self.spec.schemas if s.name == "Pet")
        id_field = next(f for f in pet.fields if f.name == "id")
        assert id_field.type == "integer"
        assert id_field.format == "int64"
        assert id_field.ref_target is None
        assert id_field.is_array is False

    def test_pet_owner_ref(self) -> None:
        """The ``owner`` field is a direct $ref to Owner."""
        pet = next(s for s in self.spec.schemas if s.name == "Pet")
        owner_field = next(f for f in pet.fields if f.name == "owner")
        assert owner_field.type == "$ref"
        assert owner_field.ref_target == "Owner"

    def test_owner_pets_array_ref(self) -> None:
        """The ``pets`` field is an array whose items $ref Pet."""
        owner = next(s for s in self.spec.schemas if s.name == "Owner")
        pets_field = next(f for f in owner.fields if f.name == "pets")
        assert pets_field.is_array is True
        assert pets_field.type == "$ref"
        assert pets_field.ref_target == "Pet"

    def test_error_schema_no_refs(self) -> None:
        error = next(s for s in self.spec.schemas if s.name == "Error")
        for f in error.fields:
            assert f.ref_target is None

    # ── Phase 3.1: richer endpoint details ───────────────────

    def test_pet_id_get_has_path_parameter(self) -> None:
        path = next(p for p in self.spec.paths if p.route == "/pets/{petId}")
        get_method = next(m for m in path.methods if m.verb == "GET")
        names = {p.name for p in get_method.parameters}
        assert "petId" in names
        pet_id_param = next(p for p in get_method.parameters if p.name == "petId")
        assert pet_id_param.location == "path"
        assert pet_id_param.required is True
        assert pet_id_param.type == "integer"

    def test_post_pets_has_request_body_ref(self) -> None:
        pets = next(p for p in self.spec.paths if p.route == "/pets")
        post = next(m for m in pets.methods if m.verb == "POST")
        assert post.request_body_ref == "Pet"

    def test_post_pets_has_response_refs(self) -> None:
        pets = next(p for p in self.spec.paths if p.route == "/pets")
        post = next(m for m in pets.methods if m.verb == "POST")
        assert post.response_refs == {"201": "Pet", "default": "Error"}

    def test_delete_pet_is_deprecated(self) -> None:
        path = next(p for p in self.spec.paths if p.route == "/pets/{petId}")
        delete = next(m for m in path.methods if m.verb == "DELETE")
        assert delete.deprecated is True

    def test_other_methods_not_deprecated(self) -> None:
        pets = next(p for p in self.spec.paths if p.route == "/pets")
        for m in pets.methods:
            assert m.deprecated is False


# ═══════════════════════════════════════════════════════════════
# OpenAPIParser — OAS 3.x (YAML)
# ═══════════════════════════════════════════════════════════════


class TestOpenAPIParserOAS3YAML:
    """Integration tests parsing the OAS 3 YAML fixture."""

    @pytest.fixture(autouse=True)
    def _parse(self, oas3_yaml_path: Path) -> None:
        self.spec = OpenAPIParser(source=str(oas3_yaml_path)).parse()

    def test_title(self) -> None:
        assert self.spec.title == "Petstore YAML"

    def test_version(self) -> None:
        assert self.spec.version == "2.0.0"

    def test_paths(self) -> None:
        assert len(self.spec.paths) == 1
        assert self.spec.paths[0].route == "/animals"

    def test_methods(self) -> None:
        verbs = {m.verb for m in self.spec.paths[0].methods}
        assert verbs == {"GET", "PUT"}

    def test_schema_primitive_array(self) -> None:
        """An array of primitives (string[]) should have no ref_target."""
        animal = next(s for s in self.spec.schemas if s.name == "Animal")
        nicknames = next(f for f in animal.fields if f.name == "nicknames")
        assert nicknames.is_array is True
        assert nicknames.type == "string"
        assert nicknames.ref_target is None


# ═══════════════════════════════════════════════════════════════
# OpenAPIParser — Swagger 2.x
# ═══════════════════════════════════════════════════════════════


class TestOpenAPIParserSwagger2:
    """Integration tests parsing the Swagger 2 fixture."""

    @pytest.fixture(autouse=True)
    def _parse(self, swagger2_json_path: Path) -> None:
        self.spec = OpenAPIParser(source=str(swagger2_json_path)).parse()

    def test_title(self) -> None:
        assert self.spec.title == "Legacy Petstore"

    def test_version(self) -> None:
        assert self.spec.version == "0.9.0"

    def test_paths(self) -> None:
        routes = {p.route for p in self.spec.paths}
        assert "/pets" in routes

    def test_schemas_from_definitions(self) -> None:
        """Swagger 2 uses ``definitions`` instead of ``components/schemas``."""
        names = {s.name for s in self.spec.schemas}
        assert names == {"Pet", "Category"}

    def test_category_pet_ref(self) -> None:
        cat = next(s for s in self.spec.schemas if s.name == "Category")
        pet_field = next(f for f in cat.fields if f.name == "pet")
        assert pet_field.type == "$ref"
        assert pet_field.ref_target == "Pet"


# ═══════════════════════════════════════════════════════════════
# OpenAPIParser — Minimal / edge cases
# ═══════════════════════════════════════════════════════════════


class TestOpenAPIParserMinimal:
    """Edge-case tests for empty or minimal specs."""

    def test_empty_paths_and_schemas(self, minimal_json_path: Path) -> None:
        spec = OpenAPIParser(source=str(minimal_json_path)).parse()
        assert spec.paths == []
        assert spec.schemas == []
        assert spec.title == "Minimal"

    def test_missing_info_uses_defaults(self, tmp_path: Path) -> None:
        """A spec without an ``info`` block gets fallback title/version."""
        raw: dict[str, Any] = {"openapi": "3.0.3", "paths": {}}
        spec_file = tmp_path / "no_info.json"
        spec_file.write_text(json.dumps(raw), encoding="utf-8")

        spec = OpenAPIParser(source=str(spec_file)).parse()
        assert spec.title == "Untitled API"
        assert spec.version == "0.0.0"

    def test_missing_file_raises(self, tmp_path: Path) -> None:
        with pytest.raises(SpecLoadError):
            OpenAPIParser(source=str(tmp_path / "ghost.json")).parse()

    def test_non_dict_path_values_skipped(self, tmp_path: Path) -> None:
        """Path values that are not dicts (e.g. ``x-extension``) are skipped."""
        raw: dict[str, Any] = {
            "openapi": "3.0.3",
            "info": {"title": "T", "version": "1"},
            "paths": {
                "/ok": {"get": {"summary": "works"}},
                "/bad": "not_a_dict",
            },
        }
        spec_file = tmp_path / "weird_paths.json"
        spec_file.write_text(json.dumps(raw), encoding="utf-8")

        spec = OpenAPIParser(source=str(spec_file)).parse()
        assert len(spec.paths) == 1  # non-dict path "/bad" is skipped
        ok_path = next(p for p in spec.paths if p.route == "/ok")
        assert len(ok_path.methods) == 1

    def test_non_http_keys_ignored(self, tmp_path: Path) -> None:
        """Keys like ``parameters`` or ``x-custom`` under a path are ignored."""
        raw: dict[str, Any] = {
            "openapi": "3.0.3",
            "info": {"title": "T", "version": "1"},
            "paths": {
                "/test": {
                    "get": {"summary": "yes"},
                    "parameters": [{"in": "query", "name": "q"}],
                    "x-custom": True,
                },
            },
        }
        spec_file = tmp_path / "extra_keys.json"
        spec_file.write_text(json.dumps(raw), encoding="utf-8")

        spec = OpenAPIParser(source=str(spec_file)).parse()
        path = spec.paths[0]
        assert len(path.methods) == 1
        assert path.methods[0].verb == "GET"


# ═══════════════════════════════════════════════════════════════
# OpenAPIParser._parse_properties (static method)
# ═══════════════════════════════════════════════════════════════


class TestParseProperties:
    """Focused tests on the static ``_parse_properties`` method."""

    @staticmethod
    def _parse(properties: dict[str, Any]) -> list[SchemaField]:
        return OpenAPIParser._parse_properties(properties)

    def test_primitive_field(self) -> None:
        props = {"name": {"type": "string"}}
        fields = self._parse(props)
        assert len(fields) == 1
        assert fields[0] == SchemaField(name="name", type="string")

    def test_field_with_format(self) -> None:
        props = {"ts": {"type": "string", "format": "date-time"}}
        fields = self._parse(props)
        assert fields[0].format == "date-time"

    def test_direct_ref(self) -> None:
        props = {"address": {"$ref": "#/components/schemas/Address"}}
        fields = self._parse(props)
        assert fields[0].type == "$ref"
        assert fields[0].ref_target == "Address"

    def test_array_with_ref_items(self) -> None:
        props = {
            "tags": {
                "type": "array",
                "items": {"$ref": "#/components/schemas/Tag"},
            }
        }
        fields = self._parse(props)
        assert fields[0].is_array is True
        assert fields[0].ref_target == "Tag"
        assert fields[0].type == "$ref"

    def test_array_with_primitive_items(self) -> None:
        props = {
            "emails": {
                "type": "array",
                "items": {"type": "string"},
            }
        }
        fields = self._parse(props)
        assert fields[0].is_array is True
        assert fields[0].type == "string"
        assert fields[0].ref_target is None

    def test_field_missing_type_defaults_to_object(self) -> None:
        """A property without a ``type`` key defaults to ``"object"``."""
        props = {"meta": {"description": "opaque"}}
        fields = self._parse(props)
        assert fields[0].type == "object"

    def test_non_dict_property_skipped(self) -> None:
        """Property values that are not dicts are silently skipped."""
        props: dict[str, Any] = {"good": {"type": "string"}, "bad": "not_a_dict"}
        fields = self._parse(props)
        assert len(fields) == 1
        assert fields[0].name == "good"

    def test_empty_properties(self) -> None:
        assert self._parse({}) == []

    def test_preserves_insertion_order(self) -> None:
        props = {
            "z_last": {"type": "string"},
            "a_first": {"type": "integer"},
            "m_mid": {"type": "boolean"},
        }
        fields = self._parse(props)
        assert [f.name for f in fields] == ["z_last", "a_first", "m_mid"]

    def test_array_with_empty_items(self) -> None:
        """An array property with empty ``items`` dict should not crash."""
        props = {"things": {"type": "array", "items": {}}}
        fields = self._parse(props)
        assert fields[0].is_array is True
        assert fields[0].ref_target is None
