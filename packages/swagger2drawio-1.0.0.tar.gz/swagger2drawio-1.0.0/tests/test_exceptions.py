"""Tests for ``swagger2drawio.exceptions``."""

from __future__ import annotations

from pathlib import Path

import pytest
import yaml
from typer.testing import CliRunner

from swagger2drawio.cli import app
from swagger2drawio.config_loader import load_config
from swagger2drawio.exceptions import (
    EXIT_CODE,
    ConfigError,
    LayoutError,
    RenderError,
    SpecLoadError,
    SpecParseError,
    SpecValidationError,
    Swagger2DrawioError,
)

runner = CliRunner()


# ═══════════════════════════════════════════════════════════════
# Hierarchy
# ═══════════════════════════════════════════════════════════════


class TestHierarchy:
    """Every concrete exception subclasses Swagger2DrawioError."""

    @pytest.mark.parametrize(
        "cls",
        [SpecLoadError, SpecParseError, SpecValidationError, LayoutError, RenderError, ConfigError],
    )
    def test_subclass(self, cls: type[Exception]) -> None:
        assert issubclass(cls, Swagger2DrawioError)
        assert issubclass(cls, Exception)


class TestExitCodes:
    """Exit codes are stable and unique per category."""

    def test_codes_are_unique(self) -> None:
        codes = list(EXIT_CODE.values())
        assert len(codes) == len(set(codes))

    def test_codes_are_nonzero(self) -> None:
        assert all(code > 0 for code in EXIT_CODE.values())

    def test_base_is_one(self) -> None:
        assert EXIT_CODE[Swagger2DrawioError] == 1


# ═══════════════════════════════════════════════════════════════
# config_loader — raises ConfigError
# ═══════════════════════════════════════════════════════════════


class TestConfigLoaderRaises:
    def test_invalid_yaml_raises_config_error(self, tmp_path: Path) -> None:
        bad = tmp_path / "broken.yaml"
        bad.write_text("layout: {invalid: [unclosed", encoding="utf-8")
        with pytest.raises(ConfigError, match="not valid YAML"):
            load_config(bad)

    def test_non_mapping_root_raises_config_error(self, tmp_path: Path) -> None:
        bad = tmp_path / "list.yaml"
        bad.write_text(yaml.dump(["a", "b"]), encoding="utf-8")
        with pytest.raises(ConfigError, match="must be a YAML mapping"):
            load_config(bad)


# ═══════════════════════════════════════════════════════════════
# CLI maps exceptions to distinct exit codes
# ═══════════════════════════════════════════════════════════════


class TestCliExitCodes:
    @staticmethod
    def _combined(result: object) -> str:
        return (getattr(result, "stderr", "") or "") + (getattr(result, "output", "") or "")

    def test_spec_load_error_exit_code(self, tmp_path: Path) -> None:
        result = runner.invoke(app, ["generate", "--input", str(tmp_path / "missing.json")])
        assert result.exit_code == EXIT_CODE[SpecLoadError]
        assert "SpecLoadError" in self._combined(result)

    def test_config_error_exit_code(self, oas3_json_path: Path, tmp_path: Path) -> None:
        bad_cfg = tmp_path / "bad.yaml"
        bad_cfg.write_text("layout: [\n", encoding="utf-8")
        result = runner.invoke(
            app,
            [
                "generate",
                "--input",
                str(oas3_json_path),
                "--config",
                str(bad_cfg),
                "--output",
                str(tmp_path / "out.drawio"),
            ],
        )
        assert result.exit_code == EXIT_CODE[ConfigError]
        assert "ConfigError" in self._combined(result)
