"""Subpackage for graph construction and layout computation."""
