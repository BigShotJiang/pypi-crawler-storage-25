"""Pluggable layout strategies for the endpoint graph.

Two built-in strategies ship with the package:

* :class:`HierarchicalBFSLayout` — the BFS / subtree-width algorithm
  used since v0.1; assigns each node to a depth layer and centres
  children beneath their parent. Best for trees rooted at a single
  node (the Root → … structure that ``build_endpoint_graph`` produces).
* :class:`GridLayout` — a deterministic grid placement, one row per
  weakly-connected component. Useful for graphs without a clear root
  (e.g. schema graphs with cycles).

Third-party strategies can register themselves via the entry-point
group ``swagger2drawio.layouts``. For example, in ``pyproject.toml``::

    [project.entry-points."swagger2drawio.layouts"]
    radial = "my_pkg.radial:RadialLayout"

The CLI surfaces strategies through ``--layout <name>``; values come
from :func:`available_strategies`.
"""

from __future__ import annotations

import logging
from importlib.metadata import entry_points
from typing import Protocol, runtime_checkable

import networkx as nx

from swagger2drawio.exceptions import LayoutError
from swagger2drawio.layout.graph_engine import NodeInfo, _grid_layout, compute_layout

logger = logging.getLogger(__name__)


@runtime_checkable
class LayoutStrategy(Protocol):
    """A pluggable graph-layout algorithm.

    Implementations populate ``x`` / ``y`` on the supplied
    :class:`NodeInfo` instances in place. Returning the same dict is
    also acceptable.
    """

    name: str

    def compute(
        self,
        graph: nx.DiGraph,
        nodes: dict[str, NodeInfo],
        *,
        node_width: float,
        node_height: float,
        h_spacing: float,
        v_spacing: float,
        rankdir: str,
        root: str | None,
    ) -> dict[str, NodeInfo]:
        """Assign coordinates to every node and return the same mapping."""
        ...


# ═══════════════════════════════════════════════════════════════
# Built-in strategies
# ═══════════════════════════════════════════════════════════════


class HierarchicalBFSLayout:
    """BFS-derived hierarchical layout (the default since v0.1)."""

    name = "hierarchical"

    def compute(
        self,
        graph: nx.DiGraph,
        nodes: dict[str, NodeInfo],
        *,
        node_width: float,
        node_height: float,
        h_spacing: float,
        v_spacing: float,
        rankdir: str,
        root: str | None,
    ) -> dict[str, NodeInfo]:
        """Run the BFS subtree-width algorithm rooted at *root*.

        If *root* is ``None`` the strategy falls back to grid placement
        (a tree with no root can't be laid out hierarchically).
        """
        if root is None or root not in graph:
            return _grid_layout_apply(graph, nodes, node_width, node_height, h_spacing, v_spacing)
        return compute_layout(
            graph,
            nodes,
            root,
            node_width=node_width,
            node_height=node_height,
            h_spacing=h_spacing,
            v_spacing=v_spacing,
            rankdir=rankdir,
        )


class GridLayout:
    """Deterministic grid placement, one row per weakly-connected component."""

    name = "grid"

    def compute(
        self,
        graph: nx.DiGraph,
        nodes: dict[str, NodeInfo],
        *,
        node_width: float,
        node_height: float,
        h_spacing: float,
        v_spacing: float,
        rankdir: str,
        root: str | None,
    ) -> dict[str, NodeInfo]:
        """Run the grid algorithm and return the same *nodes* dict."""
        return _grid_layout_apply(graph, nodes, node_width, node_height, h_spacing, v_spacing)


def _grid_layout_apply(
    graph: nx.DiGraph,
    nodes: dict[str, NodeInfo],
    node_width: float,
    node_height: float,
    h_spacing: float,
    v_spacing: float,
) -> dict[str, NodeInfo]:
    """Thin wrapper that runs the existing internal grid helper."""
    _grid_layout(graph, nodes, node_width, node_height, h_spacing, v_spacing)
    return nodes


# ═══════════════════════════════════════════════════════════════
# Registry
# ═══════════════════════════════════════════════════════════════


_BUILTIN: dict[str, LayoutStrategy] = {
    "hierarchical": HierarchicalBFSLayout(),
    "grid": GridLayout(),
}


def _load_third_party_strategies() -> dict[str, LayoutStrategy]:
    """Discover strategies registered via the ``swagger2drawio.layouts`` group.

    Returns:
        A mapping from strategy name to instance. Failed entries are
        logged at WARNING and skipped.
    """
    found: dict[str, LayoutStrategy] = {}
    try:
        eps = entry_points(group="swagger2drawio.layouts")
    except Exception:
        return found
    for ep in eps:
        try:
            cls = ep.load()
            instance = cls()
            if not isinstance(instance, LayoutStrategy):
                logger.warning(
                    "Entry point %s does not implement LayoutStrategy; skipping.", ep.name
                )
                continue
            found[ep.name] = instance
        except Exception as exc:
            logger.warning("Failed to load layout entry point %s: %s", ep.name, exc)
    return found


def available_strategies() -> dict[str, LayoutStrategy]:
    """Return all known strategies (built-ins + entry-point plugins).

    Returns:
        A dict mapping name → strategy instance. Built-ins win on name
        collision so a third-party plugin cannot silently shadow them.
    """
    merged = dict(_load_third_party_strategies())
    merged.update(_BUILTIN)
    return merged


def get_strategy(name: str) -> LayoutStrategy:
    """Look up a strategy by name.

    Args:
        name: Strategy identifier (e.g. ``"hierarchical"``).

    Returns:
        The strategy instance.

    Raises:
        LayoutError: If *name* is not registered.
    """
    strategies = available_strategies()
    if name not in strategies:
        raise LayoutError(f"Unknown layout strategy {name!r}. Available: {sorted(strategies)}")
    return strategies[name]
