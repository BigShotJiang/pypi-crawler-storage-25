"""Graph construction and hierarchical layout computation.

Builds directed :class:`networkx.DiGraph` instances for the two diagram
types (Endpoints Map and Schema ER Map) and computes ``(x, y)`` pixel
coordinates for every node using a clean, deterministic BFS-based
hierarchical layout.

The layout algorithm assigns each node to a **depth layer** (BFS level)
and spaces nodes evenly within each layer, producing a balanced
top-to-bottom (or left-to-right) tree with zero overlaps.

Public API:
    * :func:`build_endpoint_graph`  — Root → Paths → Methods tree.
    * :func:`build_schema_graph`    — Entity nodes + relational edges.
    * :func:`compute_layout`        — Generic hierarchical position solver.
"""

from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import Any

import networkx as nx

from swagger2drawio.parser.openapi_parser import MethodDetail, ParsedSpec

# ── Data containers ──────────────────────────────────────────


@dataclass(slots=True)
class NodeInfo:
    """Metadata attached to every graph node.

    Attributes:
        node_id: Unique string identifier (used as the graph node key).
        label: Display label rendered inside the Draw.io box.
        kind: Semantic kind — one of ``"root"``, ``"path"``, an HTTP
            verb (``"GET"``, ``"POST"``, …), ``"entity"``, or
            ``"field"``.
        x: Computed horizontal pixel coordinate.
        y: Computed vertical pixel coordinate.
        extra: Arbitrary extra data (e.g. summary text, field type).
    """

    node_id: str
    label: str
    kind: str
    x: float = 0.0
    y: float = 0.0
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class LayoutResult:
    """Container returned by the layout functions.

    Attributes:
        graph: The directed graph with edges describing parent → child
            or entity → entity relationships.
        nodes: Mapping from **node_id** → :class:`NodeInfo` (with
            populated ``x`` and ``y``).
    """

    graph: nx.DiGraph
    nodes: dict[str, NodeInfo]


# ── Hierarchical layout algorithm ────────────────────────────


def compute_layout(
    graph: nx.DiGraph,
    nodes: dict[str, NodeInfo],
    root: str,
    *,
    node_width: float = 200,
    node_height: float = 60,
    h_spacing: float = 80,
    v_spacing: float = 120,
    rankdir: str = "TB",
) -> dict[str, NodeInfo]:
    """Compute ``(x, y)`` coordinates for a hierarchical tree layout.

    Uses a deterministic BFS traversal from *root* to assign each node
    to a depth layer, then centres every layer's children beneath their
    parent.

    Args:
        graph: A :class:`networkx.DiGraph` whose edges point from
            parent → child.
        nodes: Mutable mapping of ``node_id`` → :class:`NodeInfo` that
            will have its ``x`` / ``y`` fields updated in-place.
        root: The ``node_id`` of the root node.
        node_width: Width of each box (pixels).
        node_height: Height of each box (pixels).
        h_spacing: Horizontal gap between sibling boxes.
        v_spacing: Vertical gap between depth layers.
        rankdir: Layout direction — ``"TB"`` (top→bottom) or
            ``"LR"`` (left→right).

    Returns:
        The same *nodes* dict with ``x`` and ``y`` populated.
    """
    if root not in graph:
        return nodes

    # ── 1. BFS to assign depth layers ────────────────────────
    layers: dict[int, list[str]] = defaultdict(list)
    visited: set[str] = set()
    queue: deque[tuple[str, int]] = deque([(root, 0)])
    visited.add(root)

    while queue:
        nid, depth = queue.popleft()
        layers[depth].append(nid)
        for child in graph.successors(nid):
            if child not in visited:
                visited.add(child)
                queue.append((child, depth + 1))

    # ── 2. Compute subtree widths (bottom-up) ────────────────
    max_depth = max(layers.keys()) if layers else 0
    cell_w = node_width + h_spacing

    subtree_width: dict[str, float] = {}

    for depth in range(max_depth, -1, -1):
        for nid in layers[depth]:
            children = [c for c in graph.successors(nid) if c in visited]
            if not children:
                subtree_width[nid] = cell_w
            else:
                subtree_width[nid] = sum(subtree_width[c] for c in children)

    # ── 3. Assign positions (top-down) ───────────────────────
    total_w = subtree_width.get(root, cell_w)
    _assign_x(graph, root, -total_w / 2, subtree_width, nodes, visited)

    cell_h = node_height + v_spacing
    for depth, nids in layers.items():
        for nid in nids:
            nodes[nid].y = depth * cell_h

    # ── 4. Normalise so minimum x is 0 ──────────────────────
    min_x = min(n.x for n in nodes.values()) if nodes else 0
    min_y = min(n.y for n in nodes.values()) if nodes else 0
    for n in nodes.values():
        n.x -= min_x
        n.y -= min_y

    # ── 5. Swap axes if LR ──────────────────────────────────
    if rankdir == "LR":
        for n in nodes.values():
            n.x, n.y = n.y, n.x

    return nodes


def _assign_x(
    graph: nx.DiGraph,
    nid: str,
    left_edge: float,
    subtree_width: dict[str, float],
    nodes: dict[str, NodeInfo],
    visited: set[str],
) -> None:
    """Recursively assign x-coordinates by distributing subtree widths.

    Args:
        graph: The directed graph.
        nid: Current node id.
        left_edge: The left boundary available for this subtree.
        subtree_width: Pre-computed subtree widths.
        nodes: Node info mapping (mutated).
        visited: Set of visited node ids.
    """
    width = subtree_width.get(nid, 0)
    nodes[nid].x = left_edge + width / 2

    children = [c for c in graph.successors(nid) if c in visited]
    cursor = left_edge
    for child in children:
        _assign_x(graph, child, cursor, subtree_width, nodes, visited)
        cursor += subtree_width[child]


def _root_banner_label(spec: ParsedSpec) -> str:
    """Render the API info block as the root node's label.

    Includes title, version, the first one or two sentences of the
    description, and up to three server URLs.
    """
    lines = [f"{spec.title}", f"v{spec.version}"]
    if spec.description:
        # Keep the banner compact — first paragraph only.
        para = spec.description.strip().split("\n\n", 1)[0].strip()
        if len(para) > 120:
            para = para[:117] + "…"
        lines.append(para)
    if spec.servers:
        lines.append("")  # blank line separator
        for url in spec.servers[:3]:
            lines.append(f"• {url}")
        if len(spec.servers) > 3:
            lines.append(f"(+{len(spec.servers) - 3} more servers)")
    return "\n".join(lines)


def _security_legend_label(spec: ParsedSpec) -> str:
    """Render the security-schemes legend as a single labeled node."""
    lines = ["Security schemes"]
    for scheme in spec.security_schemes:
        descriptor = scheme.type
        if scheme.scheme:
            descriptor += f"/{scheme.scheme}"
        if scheme.location:
            descriptor += f" in {scheme.location}"
        lines.append(f"• {scheme.name}: {descriptor}")
    return "\n".join(lines)


def _method_label(method: MethodDetail, *, max_params: int = 5) -> str:
    """Build the multi-line label for an HTTP-method node.

    Layout::

        VERB [DEPRECATED]
        summary line (optional)
        — params —
        location name: type
        ...

    Args:
        method: The parsed method to label.
        max_params: Cap on parameter rows; extras collapse to "(+N more)".

    Returns:
        A newline-separated label string ready for the renderer.
    """
    lines: list[str] = [method.verb + (" ⚠DEPRECATED" if method.deprecated else "")]
    if method.summary:
        lines.append(method.summary)
    if method.parameters:
        shown = method.parameters[:max_params]
        for param in shown:
            type_str = f": {param.type}" if param.type else ""
            req = "*" if param.required else ""
            lines.append(f"  {param.location} {param.name}{type_str}{req}")
        extra = len(method.parameters) - len(shown)
        if extra > 0:
            lines.append(f"  (+{extra} more)")
    if method.request_body_ref:
        lines.append(f"  ↑ body: {method.request_body_ref}")
    if method.response_refs:
        for status, ref in method.response_refs.items():
            lines.append(f"  ↓ {status}: {ref}")
    return "\n".join(lines)


# ── Endpoint graph builder ───────────────────────────────────


def build_endpoint_graph(
    spec: ParsedSpec,
    *,
    node_width: float = 200,
    node_height: float = 60,
    h_spacing: float = 80,
    v_spacing: float = 120,
    rankdir: str = "TB",
    group_by: str = "auto",
    layout: str = "hierarchical",
) -> LayoutResult:
    """Build the Endpoints Map graph.

    Two grouping modes are supported:

    * ``"path"`` — flat layout: Root → Path → Method.
    * ``"tag"``  — grouped layout: Root → Tag → Path → Method. Methods
      without tags fall under a synthetic ``"(untagged)"`` group.
    * ``"auto"`` (default) — picks ``"tag"`` if any operation declares
      a tag, otherwise ``"path"``.

    Args:
        spec: Parsed OpenAPI specification.
        node_width: Box width in pixels.
        node_height: Box height in pixels.
        h_spacing: Horizontal spacing.
        v_spacing: Vertical spacing.
        rankdir: ``"TB"`` or ``"LR"``.
        group_by: ``"path"``, ``"tag"``, or ``"auto"``.
        layout: Name of the layout strategy to use (``"hierarchical"`` or
            ``"grid"`` by default; third-party strategies register via
            the ``swagger2drawio.layouts`` entry point).

    Returns:
        A :class:`LayoutResult` with positioned nodes.

    Raises:
        ValueError: If *group_by* is not one of the documented values.
        LayoutError: If *layout* is not a registered strategy name.
    """
    if group_by not in {"auto", "path", "tag"}:
        raise ValueError(f"group_by must be 'auto', 'path', or 'tag'; got {group_by!r}")

    effective = group_by
    if group_by == "auto":
        has_tags = any(m.tags for p in spec.paths for m in p.methods)
        effective = "tag" if has_tags else "path"

    g = nx.DiGraph()
    nodes: dict[str, NodeInfo] = {}

    root_id = "root"
    root_label = _root_banner_label(spec)
    nodes[root_id] = NodeInfo(node_id=root_id, label=root_label, kind="root")
    g.add_node(root_id)

    if effective == "tag":
        _populate_tag_grouped(g, nodes, spec, root_id)
    else:
        _populate_path_flat(g, nodes, spec, root_id)

    # Security legend — disconnected helper node placed under the root.
    if spec.security_schemes:
        legend_id = "security:legend"
        nodes[legend_id] = NodeInfo(
            node_id=legend_id,
            label=_security_legend_label(spec),
            kind="security",
            extra={"schemes": list(spec.security_schemes)},
        )
        g.add_node(legend_id)
        g.add_edge(root_id, legend_id)

    # Delegate to a pluggable layout strategy (Phase 5.3).
    from swagger2drawio.layout.strategies import get_strategy

    strategy = get_strategy(layout)
    strategy.compute(
        g,
        nodes,
        node_width=node_width,
        node_height=node_height,
        h_spacing=h_spacing,
        v_spacing=v_spacing,
        rankdir=rankdir,
        root=root_id,
    )

    return LayoutResult(graph=g, nodes=nodes)


def _populate_path_flat(
    g: nx.DiGraph, nodes: dict[str, NodeInfo], spec: ParsedSpec, root_id: str
) -> None:
    """Populate *g* / *nodes* in flat Root → Path → Method order."""
    for path_item in spec.paths:
        path_id = f"path:{path_item.route}"
        nodes[path_id] = NodeInfo(node_id=path_id, label=path_item.route, kind="path")
        g.add_node(path_id)
        g.add_edge(root_id, path_id)

        for method in path_item.methods:
            _add_method_node(g, nodes, parent_id=path_id, route=path_item.route, method=method)


def _populate_tag_grouped(
    g: nx.DiGraph, nodes: dict[str, NodeInfo], spec: ParsedSpec, root_id: str
) -> None:
    """Populate *g* / *nodes* with a Root → Tag → Path → Method tree.

    A single operation appears under each of its declared tags
    (operations frequently belong to multiple tags). Methods with no
    tags are grouped under a synthetic ``"(untagged)"`` tag.
    """
    # tag → ordered list of (route, method) tuples
    by_tag: dict[str, list[tuple[str, Any]]] = {}
    for path_item in spec.paths:
        for method in path_item.methods:
            tags = list(method.tags) if method.tags else ["(untagged)"]
            for tag in tags:
                by_tag.setdefault(tag, []).append((path_item.route, method))

    for tag, route_methods in by_tag.items():
        tag_id = f"tag:{tag}"
        nodes[tag_id] = NodeInfo(node_id=tag_id, label=tag, kind="tag", extra={"tag": tag})
        g.add_node(tag_id)
        g.add_edge(root_id, tag_id)

        # Group routes under each tag so the same path doesn't repeat per method.
        seen_path_under_tag: dict[str, str] = {}
        for route, method in route_methods:
            path_node_id = f"path:{tag}:{route}"
            if route not in seen_path_under_tag:
                nodes[path_node_id] = NodeInfo(node_id=path_node_id, label=route, kind="path")
                g.add_node(path_node_id)
                g.add_edge(tag_id, path_node_id)
                seen_path_under_tag[route] = path_node_id
            _add_method_node(
                g,
                nodes,
                parent_id=seen_path_under_tag[route],
                route=route,
                method=method,
                id_prefix=f"method:{tag}:",
            )


def _add_method_node(
    g: nx.DiGraph,
    nodes: dict[str, NodeInfo],
    *,
    parent_id: str,
    route: str,
    method: MethodDetail,
    id_prefix: str = "method:",
) -> None:
    """Insert a single method node + parent edge."""
    method_id = f"{id_prefix}{route}:{method.verb}"
    nodes[method_id] = NodeInfo(
        node_id=method_id,
        label=_method_label(method),
        kind=method.verb,
        extra={
            "summary": method.summary,
            "operation_id": method.operation_id,
            "tags": method.tags,
            "parameters": method.parameters,
            "request_body_ref": method.request_body_ref,
            "response_refs": method.response_refs,
            "deprecated": method.deprecated,
        },
    )
    g.add_node(method_id)
    g.add_edge(parent_id, method_id)


# ── Schema graph builder ─────────────────────────────────────


def build_schema_graph(
    spec: ParsedSpec,
    *,
    node_width: float = 200,
    node_height: float = 60,
    h_spacing: float = 120,
    v_spacing: float = 160,
) -> LayoutResult:
    """Build the Schema / ER Map graph.

    Each schema becomes an entity node.  ``$ref`` relationships become
    directed edges from the referencing entity to the referenced entity.

    The layout places entities on a grid if no clear tree root exists,
    or uses the hierarchical solver when a single root is detected.

    Args:
        spec: Parsed OpenAPI specification.
        node_width: Box width in pixels.
        node_height: Box height in pixels.
        h_spacing: Horizontal spacing.
        v_spacing: Vertical spacing.

    Returns:
        A :class:`LayoutResult` with positioned entity nodes.
    """
    g = nx.DiGraph()
    nodes: dict[str, NodeInfo] = {}
    schema_names = {s.name for s in spec.schemas}

    for schema in spec.schemas:
        nid = f"schema:{schema.name}"

        if schema.is_enum:
            label = f"«enum»\n{schema.name}\n" + "\n".join(schema.enum_values[:8])
            if len(schema.enum_values) > 8:
                label += f"\n(+{len(schema.enum_values) - 8} more)"
            nodes[nid] = NodeInfo(
                node_id=nid,
                label=label,
                kind="enum",
                extra={
                    "schema_name": schema.name,
                    "description": schema.description,
                    "enum_values": schema.enum_values,
                },
            )
            g.add_node(nid)
            continue

        # Build field summary for the label
        field_lines = []
        for fld in schema.fields:
            type_str = fld.type
            if fld.is_array:
                type_str = f"{fld.ref_target or fld.type}[]"
            elif fld.ref_target:
                type_str = fld.ref_target
            if fld.format:
                type_str += f" ({fld.format})"
            disc = " «discriminator»" if fld.name == schema.discriminator else ""
            field_lines.append(f"{fld.name}: {type_str}{disc}")

        label = schema.name
        if field_lines:
            label += "\n" + "\n".join(field_lines)

        nodes[nid] = NodeInfo(
            node_id=nid,
            label=label,
            kind="entity",
            extra={
                "schema_name": schema.name,
                "description": schema.description,
                "fields": schema.fields,
                "discriminator": schema.discriminator,
                "all_of": schema.all_of,
                "one_of": schema.one_of,
                "any_of": schema.any_of,
            },
        )
        g.add_node(nid)

    # ── Edges ────────────────────────────────────────────────
    # Field-level $ref edges (existing behaviour).
    for schema in spec.schemas:
        src = f"schema:{schema.name}"
        for fld in schema.fields:
            if fld.ref_target and fld.ref_target in schema_names:
                tgt = f"schema:{fld.ref_target}"
                g.add_edge(src, tgt, label=fld.name, edge_kind="ref")

        # allOf → inheritance arrows (child → parent).
        for parent in schema.all_of:
            if parent in schema_names:
                g.add_edge(src, f"schema:{parent}", label="allOf", edge_kind="allOf")

        # oneOf / anyOf → union edges (base → variant).
        for variant in schema.one_of:
            if variant in schema_names:
                g.add_edge(src, f"schema:{variant}", label="oneOf", edge_kind="oneOf")
        for variant in schema.any_of:
            if variant in schema_names:
                g.add_edge(src, f"schema:{variant}", label="anyOf", edge_kind="anyOf")

    # Layout: grid-based for disconnected / cyclic graphs
    _grid_layout(g, nodes, node_width, node_height, h_spacing, v_spacing)

    return LayoutResult(graph=g, nodes=nodes)


def _grid_layout(
    graph: nx.DiGraph,
    nodes: dict[str, NodeInfo],
    node_width: float,
    node_height: float,
    h_spacing: float,
    v_spacing: float,
) -> None:
    """Place nodes on a simple grid, one row per connected component.

    Within each weakly-connected component nodes are sorted
    alphabetically.  This guarantees deterministic, non-overlapping
    placement even for cyclic or disconnected schema graphs.

    Args:
        graph: The schema graph.
        nodes: Node info mapping (mutated in-place).
        node_width: Box width.
        node_height: Box height.
        h_spacing: Horizontal gap.
        v_spacing: Vertical gap.
    """
    cell_w = node_width + h_spacing
    cell_h = node_height + v_spacing

    all_nids = sorted(nodes.keys())
    if not all_nids:
        return

    components = list(nx.weakly_connected_components(graph))
    components.sort(key=lambda c: min(c))

    cols_per_row = max(3, int(len(all_nids) ** 0.5) + 1)

    row = 0
    for comp in components:
        comp_nodes = sorted(comp)
        for idx, nid in enumerate(comp_nodes):
            if nid not in nodes:
                continue
            col = idx % cols_per_row
            nodes[nid].x = col * cell_w
            nodes[nid].y = row * cell_h
            if (idx + 1) % cols_per_row == 0:
                row += 1
        row += 1
