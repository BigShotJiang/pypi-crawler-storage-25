"""Configuration loader for swagger2drawio.

Resolves the active configuration in this precedence order:

1. ``--config <path>`` (explicit CLI flag)
2. ``--theme <name>`` (one of the bundled themes under
   :mod:`swagger2drawio.themes`)
3. ``./.swagger2drawio.yaml`` (current working directory)
4. ``~/.config/swagger2drawio/config.yaml`` (XDG home)
5. Built-in defaults (mirrored from the ``light`` theme)

Each layer is deep-merged onto the next so a partial user config only
overrides the keys it explicitly sets.

Public API:
    * :func:`load_config` — resolve + merge configuration.
    * :func:`list_builtin_themes` — discover bundled theme names.
    * :func:`read_theme` — read one theme file by name.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import yaml

from swagger2drawio.exceptions import ConfigError

logger = logging.getLogger(__name__)


# ── Built-in defaults ────────────────────────────────────────
# Kept in sync with swagger2drawio/themes/light.yaml.
_DEFAULTS: dict[str, Any] = {
    "layout": {
        "node_width": 200,
        "node_height": 60,
        "horizontal_spacing": 80,
        "vertical_spacing": 120,
        "rankdir": "TB",
    },
    "endpoint_styles": {
        "root": {
            "base_style": "rounded=1;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;fontStyle=1;fontSize=14;"
        },
        "tag": {
            "base_style": "rounded=1;whiteSpace=wrap;html=1;fillColor=#fff2cc;strokeColor=#d6b656;fontStyle=1;fontSize=13;"
        },
        "security": {
            "base_style": "rounded=0;whiteSpace=wrap;html=1;fillColor=#f5f5f5;strokeColor=#aaaaaa;dashed=1;fontSize=11;verticalAlign=top;"
        },
        "path": {
            "base_style": "rounded=1;whiteSpace=wrap;html=1;fillColor=#f5f5f5;strokeColor=#666666;fontSize=12;"
        },
        "GET": {
            "base_style": "rounded=1;whiteSpace=wrap;html=1;fillColor=#d5e8d4;strokeColor=#82b366;fontColor=#2d6a2e;fontSize=11;"
        },
        "POST": {
            "base_style": "rounded=1;whiteSpace=wrap;html=1;fillColor=#fff2cc;strokeColor=#d6b656;fontColor=#8c6d1f;fontSize=11;"
        },
        "PUT": {
            "base_style": "rounded=1;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;fontColor=#23537d;fontSize=11;"
        },
        "PATCH": {
            "base_style": "rounded=1;whiteSpace=wrap;html=1;fillColor=#e1d5e7;strokeColor=#9673a6;fontColor=#5b3a6e;fontSize=11;"
        },
        "DELETE": {
            "base_style": "rounded=1;whiteSpace=wrap;html=1;fillColor=#f8cecc;strokeColor=#b85450;fontColor=#9c2b2b;fontSize=11;"
        },
    },
    "schema_styles": {
        "entity": {
            "base_style": "rounded=1;whiteSpace=wrap;html=1;fillColor=#f5f5f5;strokeColor=#666666;fontStyle=1;fontSize=13;verticalAlign=top;"
        },
        "enum": {
            "base_style": "rounded=1;whiteSpace=wrap;html=1;fillColor=#e1d5e7;strokeColor=#9673a6;fontStyle=2;fontSize=12;verticalAlign=top;"
        },
        "field": {"base_style": "rounded=0;whiteSpace=wrap;html=1;fillColor=none;fontSize=11;"},
        "edge": {
            "base_style": "edgeStyle=orthogonalEdgeStyle;rounded=1;orthogonalLoop=1;jettySize=auto;html=1;strokeColor=#999999;"
        },
        "allOf_edge": {
            "base_style": "edgeStyle=orthogonalEdgeStyle;rounded=1;html=1;strokeColor=#2d6a2e;"
        },
        "oneOf_edge": {
            "base_style": "edgeStyle=orthogonalEdgeStyle;rounded=1;html=1;strokeColor=#b85450;dashed=1;"
        },
        "anyOf_edge": {
            "base_style": "edgeStyle=orthogonalEdgeStyle;rounded=1;html=1;strokeColor=#d6b656;dashed=1;"
        },
    },
}


_THEMES_DIR = Path(__file__).parent / "themes"
_CWD_CONFIG_NAME = ".swagger2drawio.yaml"
_USER_CONFIG_REL = Path("swagger2drawio") / "config.yaml"


# ── Helpers ──────────────────────────────────────────────────


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    """Recursively merge *override* into *base*, returning a new dict.

    Args:
        base: The base dictionary (not mutated).
        override: Values that should win over *base*.

    Returns:
        A new dictionary containing keys from both inputs, with nested
        dicts merged recursively.
    """
    merged: dict[str, Any] = dict(base)
    for key, value in override.items():
        if key in merged and isinstance(merged[key], dict) and isinstance(value, dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


def _read_yaml_mapping(path: Path) -> dict[str, Any]:
    """Read *path* as a YAML mapping or raise :class:`ConfigError`.

    Args:
        path: Filesystem path to a YAML file.

    Returns:
        The parsed mapping. An empty file returns ``{}``.

    Raises:
        ConfigError: If the YAML is invalid or its top-level value is
            not a mapping.
    """
    try:
        with path.open(encoding="utf-8") as fh:
            raw = yaml.safe_load(fh)
    except yaml.YAMLError as exc:
        raise ConfigError(f"Config file {path} is not valid YAML: {exc}") from exc
    if raw is None:
        return {}
    if not isinstance(raw, dict):
        raise ConfigError(f"Config file {path} must be a YAML mapping at the top level.")
    return raw


def _xdg_config_home() -> Path:
    """Return the XDG config home (``~/.config`` by default)."""
    import os

    env = os.environ.get("XDG_CONFIG_HOME")
    if env:
        return Path(env)
    return Path.home() / ".config"


# ── Theme discovery ──────────────────────────────────────────


def list_builtin_themes() -> list[str]:
    """Return the names of every bundled theme (without ``.yaml`` extensions).

    Returns:
        Sorted list, e.g. ``["dark", "high-contrast", "light", "pastel"]``.
    """
    if not _THEMES_DIR.exists():
        return []
    return sorted(p.stem for p in _THEMES_DIR.glob("*.yaml"))


def read_theme(name: str) -> dict[str, Any]:
    """Read one bundled theme by name.

    Args:
        name: Theme name (no extension), e.g. ``"dark"``.

    Returns:
        The parsed theme dict.

    Raises:
        ConfigError: If *name* doesn't match a bundled theme.
    """
    path = _THEMES_DIR / f"{name}.yaml"
    if not path.exists():
        available = ", ".join(list_builtin_themes()) or "(none)"
        raise ConfigError(f"Unknown theme: {name!r}. Available: {available}")
    return _read_yaml_mapping(path)


# ── Public loader ────────────────────────────────────────────


def load_config(
    config_path: Path | None = None,
    *,
    theme: str | None = None,
) -> dict[str, Any]:
    """Resolve the active configuration.

    Precedence (highest wins, deep-merged onto the previous layer):

    1. ``config_path`` if provided
    2. ``theme`` if provided
    3. ``./.swagger2drawio.yaml``
    4. ``$XDG_CONFIG_HOME/swagger2drawio/config.yaml``
       (``~/.config/swagger2drawio/config.yaml`` by default)
    5. Built-in defaults

    The source actually used is logged at INFO level.

    Args:
        config_path: Optional explicit path supplied by ``--config``.
            If the path does not exist a :class:`ConfigError` is
            raised (an explicit pointer to a missing file is almost
            always a typo).
        theme: Optional bundled theme name supplied by ``--theme``.

    Returns:
        The merged configuration dictionary.

    Raises:
        ConfigError: If a referenced file or theme is missing or invalid.
    """
    merged = dict(_DEFAULTS)
    sources_applied: list[str] = ["defaults"]

    # Layer: user XDG config
    user_cfg = _xdg_config_home() / _USER_CONFIG_REL
    if user_cfg.exists():
        merged = _deep_merge(merged, _read_yaml_mapping(user_cfg))
        sources_applied.append(f"user:{user_cfg}")

    # Layer: cwd-local config
    cwd_cfg = Path.cwd() / _CWD_CONFIG_NAME
    if cwd_cfg.exists():
        merged = _deep_merge(merged, _read_yaml_mapping(cwd_cfg))
        sources_applied.append(f"cwd:{cwd_cfg}")

    # Layer: named theme
    if theme is not None:
        merged = _deep_merge(merged, read_theme(theme))
        sources_applied.append(f"theme:{theme}")

    # Layer: explicit --config (highest)
    if config_path is not None:
        resolved = Path(config_path)
        if resolved.exists():
            merged = _deep_merge(merged, _read_yaml_mapping(resolved))
            sources_applied.append(f"explicit:{resolved}")
        else:
            # Preserve the historical silent-fallback for missing files.
            logger.warning("Config file not found: %s — using defaults.", resolved)

    logger.info("Configuration sources: %s", " <- ".join(sources_applied))
    return merged
