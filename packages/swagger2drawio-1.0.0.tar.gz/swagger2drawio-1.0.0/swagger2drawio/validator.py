"""Thin wrapper around ``openapi-spec-validator``.

Provides :func:`validate_spec`, a single-entry function that raises a
typed :class:`~swagger2drawio.exceptions.SpecValidationError` on failure,
preserving the original validator message and JSON-Pointer path.

The underlying validator detects whether the document is OpenAPI 3.x or
Swagger 2.0 automatically, so we don't need a separate dispatcher here.
"""

from __future__ import annotations

from typing import Any

from openapi_spec_validator import validate
from openapi_spec_validator.validation.exceptions import OpenAPIValidationError

from swagger2drawio.exceptions import SpecValidationError


def validate_spec(raw: dict[str, Any]) -> None:
    """Validate *raw* against the OpenAPI / Swagger JSON schema.

    Args:
        raw: A spec dictionary as returned by
            :func:`swagger2drawio.parser.openapi_parser._load_raw_spec`.

    Raises:
        SpecValidationError: If the spec does not conform to its declared
            OpenAPI / Swagger schema. The error message includes both the
            validator's message and the JSON-Pointer path of the
            offending node when available.
    """
    try:
        validate(raw)
    except OpenAPIValidationError as exc:
        path = "/".join(str(p) for p in getattr(exc, "absolute_path", ())) or "<root>"
        raise SpecValidationError(f"Spec validation failed at /{path}: {exc.message}") from exc
    except Exception as exc:
        raise SpecValidationError(f"Spec validation failed: {exc}") from exc
