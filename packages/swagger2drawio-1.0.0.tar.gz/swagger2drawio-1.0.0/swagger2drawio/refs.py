"""External and remote ``$ref`` resolver.

Walks a raw spec dictionary, finds every ``$ref`` value, and inlines any
*external* (file or HTTP) references into the spec's component schemas
so the rest of the pipeline only ever sees local ``#/components/...``
references.

Reference forms handled:

* **Local**  — ``#/components/schemas/User`` → left untouched.
* **External file** — ``./schemas/User.yaml#/User`` → resolved relative
  to the source spec's directory. Loaded with the same JSON-or-YAML
  detection used by the parser.
* **Remote HTTP(S)** — ``https://example.com/schemas.yaml#/User`` →
  fetched once and cached for the resolver's lifetime.

Inlining strategy: each external schema is renamed
``External_<filename>_<fragment>`` and dropped into
``components.schemas`` (creating the section if missing). The original
``$ref`` is rewritten in place to point at the new local name.

Cycle safety: a set of visited refs is threaded through every fetch so
that circular external chains terminate cleanly. Local circular refs
(e.g. ``User.partner → User``) are already cycle-safe because the parser
never recurses through them.
"""

from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import Any
from urllib.parse import urldefrag, urljoin

import requests
import yaml

from swagger2drawio.exceptions import SpecLoadError, SpecParseError

logger = logging.getLogger(__name__)

_LOCAL_REF_RE = re.compile(r"^#/")


def _is_url(uri: str) -> bool:
    return uri.startswith(("http://", "https://"))


def _safe_slug(text: str) -> str:
    """Convert a path/URI fragment into a valid schema-name segment."""
    return re.sub(r"[^A-Za-z0-9]+", "_", text).strip("_") or "ref"


class RefResolver:
    """Resolves external and remote ``$ref`` pointers into local refs.

    Args:
        source: The original spec source (path or URL). Used as the base
            for relative file refs and as the cache key for the root
            document.
        timeout: HTTP timeout for remote fetches, in seconds.

    Example::

        resolver = RefResolver(source="petstore.yaml")
        resolver.resolve(spec_dict)
    """

    def __init__(self, source: str, *, timeout: float = 10.0) -> None:
        """Initialise the resolver.

        Args:
            source: Path or URL of the root spec document.
            timeout: Per-request HTTP timeout in seconds.
        """
        self._source: str = source
        self._timeout: float = timeout
        self._cache: dict[str, dict[str, Any]] = {}
        # external-uri → generated local schema name
        self._inlined: dict[str, str] = {}

    # ── Public API ───────────────────────────────────────────

    def resolve(self, spec: dict[str, Any]) -> dict[str, Any]:
        """Inline every external ``$ref`` in *spec* in-place.

        Args:
            spec: The raw spec dictionary, possibly containing external
                or remote ``$ref`` pointers.

        Returns:
            The same dictionary, with external refs rewritten to local
            ones and the referenced schemas added under
            ``components.schemas``.

        Raises:
            SpecLoadError: If an external file or URL cannot be fetched.
            SpecParseError: If a fetched document is not valid JSON / YAML.
        """
        self._walk(spec, base_uri=self._source, visited=set())
        return spec

    # ── Recursion ────────────────────────────────────────────

    def _walk(
        self,
        node: Any,
        *,
        base_uri: str,
        visited: set[str],
    ) -> None:
        """Depth-first walk that rewrites every external ``$ref`` it finds."""
        if isinstance(node, dict):
            ref = node.get("$ref")
            if isinstance(ref, str) and not _LOCAL_REF_RE.match(ref):
                # External or remote — rewrite in place.
                new_local = self._inline_external(ref, base_uri=base_uri, visited=visited)
                node["$ref"] = new_local
                # Don't descend into a rewritten $ref node; the rest of
                # its keys (rare in OpenAPI) are ignored by spec convention.
                return
            for value in node.values():
                self._walk(value, base_uri=base_uri, visited=visited)
        elif isinstance(node, list):
            for item in node:
                self._walk(item, base_uri=base_uri, visited=visited)

    def _inline_external(
        self,
        ref: str,
        *,
        base_uri: str,
        visited: set[str],
    ) -> str:
        """Fetch an external schema, register it locally, return the new ref string."""
        absolute = self._absolutise(ref, base_uri=base_uri)
        if absolute in self._inlined:
            return f"#/components/schemas/{self._inlined[absolute]}"
        if absolute in visited:
            # Cycle in external refs → leave a placeholder so we don't recurse.
            placeholder = f"ExternalCycle_{_safe_slug(absolute)}"
            return f"#/components/schemas/{placeholder}"

        visited = visited | {absolute}
        doc_uri, fragment = urldefrag(absolute)
        doc = self._fetch(doc_uri)
        target = self._dereference_fragment(doc, fragment, ref=ref)

        # Pick a local name and recurse into the target so its own refs
        # (which may also be external) get processed.
        local_name = self._mint_local_name(absolute)
        self._inlined[absolute] = local_name

        # Resolve nested refs within the target *relative to the doc it
        # came from*, not the original spec's source.
        self._walk(target, base_uri=doc_uri, visited=visited)

        # Inject into the root spec's components/schemas. We mutate
        # via _root_spec_schemas() so nested resolutions stay attached.
        self._register_schema(local_name, target)
        return f"#/components/schemas/{local_name}"

    # ── Helpers ──────────────────────────────────────────────

    def _absolutise(self, ref: str, *, base_uri: str) -> str:
        """Convert *ref* into an absolute URI using *base_uri* as the anchor."""
        if _is_url(ref):
            return ref
        if _is_url(base_uri):
            return urljoin(base_uri, ref)
        # base_uri is a filesystem path → resolve ref relative to its dir
        base_path = Path(base_uri).resolve().parent
        doc_part, _, fragment = ref.partition("#")
        absolute_path = (base_path / doc_part).resolve()
        return f"{absolute_path}#{fragment}" if fragment else str(absolute_path)

    def _fetch(self, doc_uri: str) -> dict[str, Any]:
        """Fetch and JSON/YAML-decode the document at *doc_uri*."""
        if doc_uri in self._cache:
            return self._cache[doc_uri]

        logger.debug("Fetching external $ref doc: %s", doc_uri)
        try:
            if _is_url(doc_uri):
                response = requests.get(doc_uri, timeout=self._timeout)
                response.raise_for_status()
                text = response.text
            else:
                text = Path(doc_uri).read_text(encoding="utf-8")
        except requests.RequestException as exc:
            raise SpecLoadError(f"Failed to fetch external $ref: {doc_uri} ({exc})") from exc
        except OSError as exc:
            raise SpecLoadError(f"Cannot read external $ref file: {doc_uri} ({exc})") from exc

        try:
            data: Any = json.loads(text)
        except json.JSONDecodeError:
            try:
                data = yaml.safe_load(text)
            except yaml.YAMLError as exc:
                raise SpecParseError(f"External $ref is not valid JSON/YAML: {doc_uri}") from exc

        if not isinstance(data, dict):
            raise SpecParseError(f"External $ref must be a JSON/YAML object: {doc_uri}")

        self._cache[doc_uri] = data
        return data

    @staticmethod
    def _dereference_fragment(doc: dict[str, Any], fragment: str, *, ref: str) -> dict[str, Any]:
        """Walk a JSON-Pointer *fragment* into *doc* and return the target."""
        target: Any = doc
        if fragment:
            for part in fragment.split("/"):
                if not part:
                    continue
                # JSON Pointer un-escapes: ~1 → /, ~0 → ~
                part = part.replace("~1", "/").replace("~0", "~")
                if not isinstance(target, dict) or part not in target:
                    raise SpecLoadError(f"$ref fragment not found: {ref}")
                target = target[part]
        if not isinstance(target, dict):
            raise SpecLoadError(f"$ref target is not an object: {ref}")
        return target

    def _mint_local_name(self, absolute_uri: str) -> str:
        """Generate a unique components/schemas key for *absolute_uri*."""
        doc, fragment = urldefrag(absolute_uri)
        doc_part = _safe_slug(Path(doc).name or doc)
        frag_part = _safe_slug(fragment.split("/")[-1] if fragment else "root")
        base = f"External_{doc_part}_{frag_part}"
        # Avoid collisions if two different URIs slugify to the same name.
        candidate = base
        existing = set(self._inlined.values())
        counter = 2
        while candidate in existing:
            candidate = f"{base}_{counter}"
            counter += 1
        return candidate

    def _register_schema(self, name: str, schema: dict[str, Any]) -> None:
        """Stash *schema* under ``components.schemas[name]`` in a sidecar dict.

        The caller is responsible for merging this dict into the root
        spec's ``components.schemas`` after :meth:`resolve` returns.
        """
        self._pending_schemas.setdefault(name, schema)

    # ── Lifecycle ────────────────────────────────────────────

    @property
    def _pending_schemas(self) -> dict[str, dict[str, Any]]:
        if not hasattr(self, "_pending"):
            self._pending: dict[str, dict[str, Any]] = {}
        return self._pending

    def pending_schemas(self) -> dict[str, dict[str, Any]]:
        """Return the schemas that need to be merged into ``components.schemas``."""
        return dict(self._pending_schemas)
