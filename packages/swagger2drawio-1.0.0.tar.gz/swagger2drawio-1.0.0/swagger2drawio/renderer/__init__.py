"""Subpackage for rendering Draw.io XML output via drawpyo."""
