"""Draw.io XML renderer powered by drawpyo.

Consumes pre-computed :class:`LayoutResult` data from the graph engine
and the parsed OpenAPI dataclasses, then emits a ``.drawio`` XML file
with two pages:

* **Endpoints Map** — hierarchical tree from Root → Paths → Methods.
* **Schema (ER) Map** — entity boxes with relational edges.

Public API:
    * :func:`render` — One-shot function that writes the complete file.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import drawpyo
from drawpyo.diagram import Edge, Object

from swagger2drawio.exceptions import RenderError
from swagger2drawio.layout.graph_engine import LayoutResult

logger = logging.getLogger(__name__)

# ── Public entry point ───────────────────────────────────────


def render(
    endpoint_layout: LayoutResult,
    schema_layout: LayoutResult,
    output_path: Path | str,
    cfg: dict[str, Any],
    *,
    node_width: float = 200,
    node_height: float = 60,
) -> Path:
    """Render two Draw.io pages and write the ``.drawio`` file.

    Args:
        endpoint_layout: Positioned Endpoints Map graph.
        schema_layout: Positioned Schema (ER) Map graph.
        output_path: Destination ``.drawio`` file path.
        cfg: Merged configuration dictionary (from
            :func:`config_loader.load_config`).
        node_width: Default node width (pixels).
        node_height: Default node height (pixels).

    Returns:
        The resolved :class:`Path` of the written file.

    Raises:
        RenderError: If the underlying drawpyo / filesystem operation
            fails (e.g. cannot create the output directory, drawpyo
            raises, or the file cannot be written).
    """
    output_path = Path(output_path)
    try:
        output_path.parent.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise RenderError(f"Cannot create output directory {output_path.parent}: {exc}") from exc

    layout_cfg = cfg.get("layout", {})
    w = layout_cfg.get("node_width", node_width)
    h = layout_cfg.get("node_height", node_height)

    try:
        file = drawpyo.File(
            file_name=output_path.name,
            file_path=str(output_path.parent.resolve()),
        )

        # ── Page 1: Endpoints Map ────────────────────────────────
        ep_page = drawpyo.Page(file=file, name="Endpoints Map")
        _render_endpoint_page(ep_page, endpoint_layout, cfg, w, h)
        logger.debug("Rendered Endpoints Map: %d node(s)", len(endpoint_layout.nodes))

        # ── Page 2: Schema (ER) Map ──────────────────────────────
        if schema_layout.nodes:
            sc_page = drawpyo.Page(file=file, name="Schema Map")
            _render_schema_page(sc_page, schema_layout, cfg, w, h)
            logger.debug("Rendered Schema Map: %d node(s)", len(schema_layout.nodes))

        file.write()
        logger.info("Wrote .drawio file: %s", output_path)
    except RenderError:
        raise
    except Exception as exc:
        raise RenderError(f"Failed to render Draw.io file {output_path}: {exc}") from exc

    return output_path


# ── Endpoint page renderer ───────────────────────────────────


def _render_endpoint_page(
    page: drawpyo.Page,
    layout: LayoutResult,
    cfg: dict[str, Any],
    node_width: float,
    node_height: float,
) -> None:
    """Populate *page* with endpoint nodes and hierarchy edges.

    Args:
        page: The drawpyo Page to populate.
        layout: The positioned endpoint layout result.
        cfg: Configuration dictionary.
        node_width: Node box width.
        node_height: Node box height.
    """
    ep_styles = cfg.get("endpoint_styles", {})
    objects: dict[str, Object] = {}
    row_h = 14  # pixels per extra label row

    for nid, info in layout.nodes.items():
        style_key = info.kind
        style_str = ep_styles.get(style_key, ep_styles.get("path", {})).get("base_style", "")

        # Scale height by line count so parameter/response details fit.
        line_count = info.label.count("\n") + 1
        box_h = max(int(node_height), 30 + line_count * row_h)

        obj = Object(
            value=info.label,
            position=(int(info.x), int(info.y)),
            width=int(node_width),
            height=box_h,
            page=page,
        )
        if style_str:
            obj.apply_style_string(style_str)
        objects[nid] = obj

    # Edges follow the graph structure
    for u, v in layout.graph.edges():
        if u in objects and v in objects:
            Edge(source=objects[u], target=objects[v], page=page)


# ── Schema page renderer ─────────────────────────────────────


def _render_schema_page(
    page: drawpyo.Page,
    layout: LayoutResult,
    cfg: dict[str, Any],
    node_width: float,
    node_height: float,
) -> None:
    """Populate *page* with schema entity boxes and relationship edges.

    Each entity box height is scaled to accommodate its field list.

    Args:
        page: The drawpyo Page to populate.
        layout: The positioned schema layout result.
        cfg: Configuration dictionary.
        node_width: Base node box width.
        node_height: Base node box height (per-field row height).
    """
    sc_styles = cfg.get("schema_styles", {})
    entity_style = sc_styles.get("entity", {}).get("base_style", "")
    enum_style = sc_styles.get("enum", {}).get("base_style", entity_style)
    edge_style = sc_styles.get("edge", {}).get("base_style", "")
    all_of_style = sc_styles.get("allOf_edge", {}).get("base_style", edge_style)
    one_of_style = sc_styles.get("oneOf_edge", {}).get("base_style", edge_style)
    any_of_style = sc_styles.get("anyOf_edge", {}).get("base_style", edge_style)

    objects: dict[str, Object] = {}
    row_h = 22  # pixels per field row

    for nid, info in layout.nodes.items():
        if info.kind == "enum":
            box_h = max(int(node_height), 40 + (info.label.count("\n")) * 16)
            obj = Object(
                value=info.label,
                position=(int(info.x), int(info.y)),
                width=int(node_width),
                height=box_h,
                page=page,
            )
            if enum_style:
                obj.apply_style_string(enum_style)
            objects[nid] = obj
            continue

        fields = info.extra.get("fields", [])
        # Scale height: header + fields
        box_h = max(int(node_height), 40 + len(fields) * row_h)

        obj = Object(
            value=info.label,
            position=(int(info.x), int(info.y)),
            width=int(node_width),
            height=box_h,
            page=page,
        )
        if entity_style:
            obj.apply_style_string(entity_style)
        objects[nid] = obj

    # Relationship edges
    edge_styles_by_kind = {
        "ref": edge_style,
        "allOf": all_of_style,
        "oneOf": one_of_style,
        "anyOf": any_of_style,
    }
    for u, v, data in layout.graph.edges(data=True):
        if u in objects and v in objects:
            edge = Edge(
                source=objects[u],
                target=objects[v],
                label=data.get("label", ""),
                page=page,
            )
            kind = data.get("edge_kind", "ref")
            style = edge_styles_by_kind.get(kind, edge_style)
            if style:
                edge.apply_style_string(style)
