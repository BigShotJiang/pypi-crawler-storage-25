"""Polished side-by-side diff renderer.

Produces a three-page ``.drawio`` file:

* **Summary** — a header card with counts and a colour legend.
* **Endpoints** — side-by-side columns. Removed operations live on the
  left (red), additions on the right (green), and methods that exist in
  both but changed appear on both sides (yellow) connected by a dashed
  edge. Items are grouped by tag for readability.
* **Schemas** — same layout for component schemas. Each schema box
  lists its fields with per-field ``+`` / ``-`` / ``~`` markers in the
  new column.

Public API:
    * :func:`render_diff` — one-shot function that writes the file.
"""

from __future__ import annotations

import logging
from collections import defaultdict
from pathlib import Path
from typing import Any

import drawpyo
from drawpyo.diagram import Edge, Object

from swagger2drawio.diff import MethodDiff, SchemaDiff, SpecDiff
from swagger2drawio.exceptions import RenderError
from swagger2drawio.parser.openapi_parser import MethodDetail, ParsedSpec, SchemaModel

logger = logging.getLogger(__name__)


# ── Colour palette ───────────────────────────────────────────
ADDED_STYLE = (
    "rounded=1;whiteSpace=wrap;html=1;fillColor=#d5e8d4;strokeColor=#82b366;"
    "fontColor=#2d6a2e;fontSize=11;align=left;verticalAlign=top;"
)
REMOVED_STYLE = (
    "rounded=1;whiteSpace=wrap;html=1;fillColor=#f8cecc;strokeColor=#b85450;"
    "fontColor=#9c2b2b;fontSize=11;align=left;verticalAlign=top;"
)
CHANGED_STYLE = (
    "rounded=1;whiteSpace=wrap;html=1;fillColor=#fff2cc;strokeColor=#d6b656;"
    "fontColor=#8c6d1f;fontSize=11;align=left;verticalAlign=top;"
)
HEADER_STYLE = (
    "rounded=0;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;"
    "fontStyle=1;fontSize=14;align=center;"
)
TAG_STYLE = (
    "rounded=0;whiteSpace=wrap;html=1;fillColor=#f5f5f5;strokeColor=#aaaaaa;"
    "fontStyle=1;fontSize=12;align=left;"
)
LEGEND_STYLE = (
    "rounded=0;whiteSpace=wrap;html=1;fillColor=#ffffff;strokeColor=#aaaaaa;"
    "fontSize=11;align=left;verticalAlign=top;"
)
CONNECTOR_STYLE = "edgeStyle=orthogonalEdgeStyle;rounded=1;dashed=1;strokeColor=#d6b656;html=1;"


# ── Layout constants ─────────────────────────────────────────
BOX_W = 280
BOX_H = 50
COL_GAP = 200
ROW_GAP = 16
TAG_HEIGHT = 28
PAGE_LEFT_MARGIN = 40
PAGE_TOP_MARGIN = 100


# ═══════════════════════════════════════════════════════════════
# Public entry point
# ═══════════════════════════════════════════════════════════════


def render_diff(
    old: ParsedSpec,
    new: ParsedSpec,
    diff: SpecDiff,
    output_path: Path | str,
) -> Path:
    """Render the diff into a multi-page ``.drawio`` file.

    Args:
        old: The earlier :class:`ParsedSpec`.
        new: The later :class:`ParsedSpec`.
        diff: A :class:`SpecDiff` produced by
            :func:`swagger2drawio.diff.compute_diff`.
        output_path: Destination ``.drawio`` file path.

    Returns:
        The resolved :class:`Path` of the written file.

    Raises:
        RenderError: If the output directory cannot be created or the
            drawpyo write fails.
    """
    output_path = Path(output_path)
    try:
        output_path.parent.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise RenderError(f"Cannot create output directory {output_path.parent}: {exc}") from exc

    try:
        file = drawpyo.File(
            file_name=output_path.name,
            file_path=str(output_path.parent.resolve()),
        )

        _render_summary_page(file, old, new, diff)
        _render_endpoints_page(file, old, new, diff)
        _render_schemas_page(file, old, new, diff)

        file.write()
        logger.info("Wrote diff .drawio file: %s", output_path)
    except RenderError:
        raise
    except Exception as exc:
        raise RenderError(f"Failed to render diff .drawio: {exc}") from exc

    return output_path


# ═══════════════════════════════════════════════════════════════
# Page 1 — Summary
# ═══════════════════════════════════════════════════════════════


def _render_summary_page(
    file: drawpyo.File, old: ParsedSpec, new: ParsedSpec, diff: SpecDiff
) -> None:
    """Render the summary header + counts + colour legend on page 1."""
    page = drawpyo.Page(file=file, name="Summary")

    title = (
        f"API Diff\n{old.title} v{old.version}  →  {new.title} v{new.version}"
        if old.title != new.title or old.version != new.version
        else f"API Diff: {new.title} v{old.version} → v{new.version}"
    )
    _box(page, title, x=PAGE_LEFT_MARGIN, y=40, w=720, h=70, style=HEADER_STYLE)

    # Counts panel
    counts_text = (
        f"Paths:   +{len(diff.paths_added)}  -{len(diff.paths_removed)}\n"
        f"Methods: +{len(diff.methods_added)}  "
        f"-{len(diff.methods_removed)}  ~{len(diff.methods_changed)}\n"
        f"Schemas: +{len(diff.schemas_added)}  "
        f"-{len(diff.schemas_removed)}  ~{len(diff.schemas_changed)}"
    )
    _box(page, counts_text, x=PAGE_LEFT_MARGIN, y=140, w=350, h=120, style=LEGEND_STYLE)

    # Legend
    legend_x = PAGE_LEFT_MARGIN + 380
    _box(page, "Added (+)", x=legend_x, y=140, w=160, h=32, style=ADDED_STYLE)
    _box(page, "Removed (-)", x=legend_x, y=180, w=160, h=32, style=REMOVED_STYLE)
    _box(page, "Changed (~)", x=legend_x, y=220, w=160, h=32, style=CHANGED_STYLE)

    # Empty-diff banner
    if diff.is_empty:
        _box(
            page,
            "✓  No structural changes detected.",
            x=PAGE_LEFT_MARGIN,
            y=300,
            w=540,
            h=50,
            style=HEADER_STYLE,
        )


# ═══════════════════════════════════════════════════════════════
# Page 2 — Endpoints
# ═══════════════════════════════════════════════════════════════


def _render_endpoints_page(
    file: drawpyo.File, old: ParsedSpec, new: ParsedSpec, diff: SpecDiff
) -> None:
    """Side-by-side endpoint comparison, grouped by tag.

    Layout:
        ┌─── Old ──────┐         ┌─── New ──────┐
        │ tag header   │         │ tag header   │
        │ method box   │ ──────  │ method box   │
        │ method box   │         │ method box   │
    """
    page = drawpyo.Page(file=file, name="Endpoints")

    # Column headers
    left_x = PAGE_LEFT_MARGIN
    right_x = PAGE_LEFT_MARGIN + BOX_W + COL_GAP
    _box(
        page, f"OLD: {old.title} v{old.version}", x=left_x, y=40, w=BOX_W, h=40, style=HEADER_STYLE
    )
    _box(
        page, f"NEW: {new.title} v{new.version}", x=right_x, y=40, w=BOX_W, h=40, style=HEADER_STYLE
    )

    # Group operations by tag (use the new spec's tag set as the master order;
    # operations only in old are still shown under their old tags).
    old_by_tag = _group_methods_by_tag(old)
    new_by_tag = _group_methods_by_tag(new)
    all_tags = list(new_by_tag.keys()) + [t for t in old_by_tag if t not in new_by_tag]

    diff_removed_keys = {(m.route, m.verb) for m in diff.methods_removed}
    diff_added_keys = {(m.route, m.verb) for m in diff.methods_added}
    diff_changed_by_key: dict[tuple[str, str], MethodDiff] = {
        (m.key.route, m.key.verb): m for m in diff.methods_changed
    }

    y_cursor = PAGE_TOP_MARGIN
    changed_pairs: list[tuple[Object, Object]] = []

    for tag in all_tags:
        # Tag header on each side
        _box(page, tag, x=left_x, y=y_cursor, w=BOX_W, h=TAG_HEIGHT, style=TAG_STYLE)
        _box(page, tag, x=right_x, y=y_cursor, w=BOX_W, h=TAG_HEIGHT, style=TAG_STYLE)
        y_cursor += TAG_HEIGHT + ROW_GAP

        old_methods = old_by_tag.get(tag, [])
        new_methods = new_by_tag.get(tag, [])

        # Build a stable ordering across both sides: union of (route, verb)
        # tuples sorted alphabetically.
        keys = sorted({(r, m.verb) for r, m in old_methods} | {(r, m.verb) for r, m in new_methods})

        for route, verb in keys:
            key = (route, verb)
            old_match = next((m for r, m in old_methods if r == route and m.verb == verb), None)
            new_match = next((m for r, m in new_methods if r == route and m.verb == verb), None)

            left_obj: Object | None = None
            right_obj: Object | None = None

            if old_match is not None and new_match is None and key in diff_removed_keys:
                left_obj = _method_box(page, route, old_match, left_x, y_cursor, REMOVED_STYLE)
            elif new_match is not None and old_match is None and key in diff_added_keys:
                right_obj = _method_box(page, route, new_match, right_x, y_cursor, ADDED_STYLE)
            else:
                # Either present in both (possibly changed) or in both unchanged.
                style_left = style_right = LEGEND_STYLE
                if key in diff_changed_by_key:
                    style_left = style_right = CHANGED_STYLE
                if old_match is not None:
                    left_obj = _method_box(page, route, old_match, left_x, y_cursor, style_left)
                if new_match is not None:
                    right_obj = _method_box(page, route, new_match, right_x, y_cursor, style_right)
                if left_obj is not None and right_obj is not None and key in diff_changed_by_key:
                    changed_pairs.append((left_obj, right_obj))

            y_cursor += BOX_H + ROW_GAP

        y_cursor += ROW_GAP  # extra gap between tag groups

    # Draw connector edges last so they sit on top.
    for left_obj, right_obj in changed_pairs:
        edge = Edge(source=left_obj, target=right_obj, page=page, label="changed")
        edge.apply_style_string(CONNECTOR_STYLE)


def _method_box(
    page: drawpyo.Page,
    route: str,
    method: MethodDetail,
    x: int,
    y: int,
    style: str,
) -> Object:
    """One method-detail box at (x, y) with the given background style."""
    badge = " ⚠DEPRECATED" if method.deprecated else ""
    lines = [f"{method.verb} {route}{badge}"]
    if method.summary:
        lines.append(method.summary[:80])
    if method.request_body_ref:
        lines.append(f"↑ body: {method.request_body_ref}")
    for status, ref in list(method.response_refs.items())[:2]:
        lines.append(f"↓ {status}: {ref}")
    return _box(page, "\n".join(lines), x=x, y=y, w=BOX_W, h=BOX_H, style=style)


def _group_methods_by_tag(spec: ParsedSpec) -> dict[str, list[tuple[str, MethodDetail]]]:
    """Bucket all (route, method) pairs in *spec* by their (first) tag."""
    buckets: dict[str, list[tuple[str, MethodDetail]]] = defaultdict(list)
    for path in spec.paths:
        for method in path.methods:
            tag = method.tags[0] if method.tags else "(untagged)"
            buckets[tag].append((path.route, method))
    # Sort each bucket for determinism.
    for tag in buckets:
        buckets[tag].sort(key=lambda rm: (rm[0], rm[1].verb))
    return dict(buckets)


# ═══════════════════════════════════════════════════════════════
# Page 3 — Schemas
# ═══════════════════════════════════════════════════════════════


def _render_schemas_page(
    file: drawpyo.File, old: ParsedSpec, new: ParsedSpec, diff: SpecDiff
) -> None:
    """Side-by-side schema comparison."""
    page = drawpyo.Page(file=file, name="Schemas")

    left_x = PAGE_LEFT_MARGIN
    right_x = PAGE_LEFT_MARGIN + BOX_W + COL_GAP
    _box(
        page, f"OLD schemas ({len(old.schemas)})", x=left_x, y=40, w=BOX_W, h=40, style=HEADER_STYLE
    )
    _box(
        page,
        f"NEW schemas ({len(new.schemas)})",
        x=right_x,
        y=40,
        w=BOX_W,
        h=40,
        style=HEADER_STYLE,
    )

    old_by_name = {s.name: s for s in old.schemas}
    new_by_name = {s.name: s for s in new.schemas}
    all_names = sorted(set(old_by_name) | set(new_by_name))

    removed_set = set(diff.schemas_removed)
    added_set = set(diff.schemas_added)
    changed_by_name = {s.name: s for s in diff.schemas_changed}

    y_cursor = PAGE_TOP_MARGIN
    changed_pairs: list[tuple[Object, Object]] = []

    for name in all_names:
        old_schema = old_by_name.get(name)
        new_schema = new_by_name.get(name)
        sub = changed_by_name.get(name)

        # Determine row height: tallest of the two sides.
        old_lines = _schema_lines(old_schema) if old_schema else []
        new_lines = _schema_lines(new_schema, diff_sub=sub) if new_schema else []
        row_h = max(BOX_H, 28 + max(len(old_lines), len(new_lines)) * 14)

        left_obj: Object | None = None
        right_obj: Object | None = None

        if name in removed_set and old_schema is not None:
            left_obj = _box(
                page,
                "\n".join(old_lines),
                x=left_x,
                y=y_cursor,
                w=BOX_W,
                h=row_h,
                style=REMOVED_STYLE,
            )
        elif name in added_set and new_schema is not None:
            right_obj = _box(
                page,
                "\n".join(new_lines),
                x=right_x,
                y=y_cursor,
                w=BOX_W,
                h=row_h,
                style=ADDED_STYLE,
            )
        else:
            style = CHANGED_STYLE if sub is not None else LEGEND_STYLE
            if old_schema is not None:
                left_obj = _box(
                    page,
                    "\n".join(old_lines),
                    x=left_x,
                    y=y_cursor,
                    w=BOX_W,
                    h=row_h,
                    style=style,
                )
            if new_schema is not None:
                right_obj = _box(
                    page,
                    "\n".join(new_lines),
                    x=right_x,
                    y=y_cursor,
                    w=BOX_W,
                    h=row_h,
                    style=style,
                )
            if left_obj is not None and right_obj is not None and sub is not None:
                changed_pairs.append((left_obj, right_obj))

        y_cursor += row_h + ROW_GAP

    for left_obj, right_obj in changed_pairs:
        edge = Edge(source=left_obj, target=right_obj, page=page, label="changed")
        edge.apply_style_string(CONNECTOR_STYLE)


def _schema_lines(
    schema: SchemaModel | None,
    *,
    diff_sub: SchemaDiff | None = None,
) -> list[str]:
    """Build the row-by-row label for a schema box.

    When *diff_sub* is provided, fields are prefixed with ``+`` / ``-`` /
    ``~`` markers based on the per-field diff. Otherwise the field list
    is rendered unadorned.
    """
    if schema is None:
        return []

    lines = [schema.name]
    if schema.is_enum:
        lines.append("«enum»")
        for value in schema.enum_values[:6]:
            lines.append(f"  {value}")
        if len(schema.enum_values) > 6:
            lines.append(f"  (+{len(schema.enum_values) - 6} more)")
        return lines

    added = set(diff_sub.fields_added) if diff_sub else set()
    removed = set(diff_sub.fields_removed) if diff_sub else set()
    changed = set(diff_sub.fields_changed) if diff_sub else set()

    for fld in schema.fields:
        prefix = "  "
        if fld.name in added:
            prefix = "+ "
        elif fld.name in changed:
            prefix = "~ "
        type_str = fld.type
        if fld.is_array:
            type_str = f"{fld.ref_target or fld.type}[]"
        elif fld.ref_target:
            type_str = fld.ref_target
        lines.append(f"{prefix}{fld.name}: {type_str}")

    # Removed field placeholders only make sense on the new-side schema
    # but we don't always have one — diff_sub being None means we're on
    # the old side, so just skip.
    for name in sorted(removed):
        lines.append(f"- {name} (removed)")

    return lines


# ═══════════════════════════════════════════════════════════════
# Helpers
# ═══════════════════════════════════════════════════════════════


def _box(
    page: drawpyo.Page,
    value: str,
    *,
    x: int,
    y: int,
    w: int,
    h: int,
    style: str,
) -> Object:
    """Create a single styled rectangle on *page*."""
    obj = Object(value=value, position=(int(x), int(y)), width=int(w), height=int(h), page=page)
    obj.apply_style_string(style)
    return obj


def _ignored(_: Any) -> None:  # pragma: no cover
    """Sentinel so type-checkers don't flag the local Any import."""
    return None
