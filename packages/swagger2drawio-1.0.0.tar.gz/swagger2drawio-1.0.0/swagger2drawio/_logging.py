"""Logging configuration for the CLI.

A single :func:`configure` entrypoint sets up the root ``swagger2drawio``
logger so that all module-level loggers obtained via
``logging.getLogger(__name__)`` honour the user's ``-v / -vv / -q /
--log-file`` choices.

Console output goes through Rich's :class:`~rich.logging.RichHandler`
(colourised, with the module path). File output (when ``--log-file`` is
set) uses a plain text formatter so the log is grep-friendly.
"""

from __future__ import annotations

import logging
from pathlib import Path

from rich.logging import RichHandler

_ROOT_LOGGER = "swagger2drawio"


def configure(verbosity: int = 0, quiet: bool = False, log_file: Path | None = None) -> None:
    """Configure the package's root logger.

    Args:
        verbosity: ``0`` for default (WARNING+ on stderr), ``1`` for
            INFO, ``2+`` for DEBUG.
        quiet: When ``True``, force the console level to WARNING+ even
            if *verbosity* is non-zero.
        log_file: Optional path. When supplied, DEBUG-and-up messages
            are appended to this file regardless of console verbosity.
    """
    root = logging.getLogger(_ROOT_LOGGER)
    # Reset on every call so repeated CLI invocations in the same
    # process (e.g. inside tests) don't stack handlers.
    for handler in list(root.handlers):
        root.removeHandler(handler)

    # ── Console handler ──────────────────────────────────────
    if quiet:
        console_level = logging.WARNING
    elif verbosity >= 2:
        console_level = logging.DEBUG
    elif verbosity == 1:
        console_level = logging.INFO
    else:
        console_level = logging.WARNING

    console = RichHandler(
        rich_tracebacks=True,
        show_path=False,
        markup=False,
        show_time=False,
        show_level=True,
    )
    console.setLevel(console_level)
    console.setFormatter(logging.Formatter("%(message)s"))
    root.addHandler(console)

    # ── File handler (always DEBUG) ──────────────────────────
    if log_file is not None:
        log_file.parent.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(log_file, encoding="utf-8")
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(
            logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
        )
        root.addHandler(file_handler)

    # Root level is the minimum so handlers can filter upward.
    root.setLevel(min(console_level, logging.DEBUG if log_file else console_level))
    root.propagate = False
