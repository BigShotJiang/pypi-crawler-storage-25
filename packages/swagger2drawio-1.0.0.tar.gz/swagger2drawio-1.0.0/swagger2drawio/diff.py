"""Compute structural diffs between two :class:`ParsedSpec` instances.

The diff is **structural**: it answers "what API contract changed?" not
"what bytes changed?". The output is a :class:`SpecDiff` containing three
buckets — ``added`` / ``removed`` / ``changed`` — for each of three
domains: paths, methods (operations), schemas.

For *changed* methods, a per-field :class:`MethodDiff` records exactly
which sub-attribute moved (summary text, request body ref, response
refs, deprecated flag, parameter list). The renderer in
:mod:`swagger2drawio.renderer.diff_renderer` uses these granular flags
to drive its color overlay.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from swagger2drawio.parser.openapi_parser import (
    MethodDetail,
    ParsedSpec,
    PathItem,
    SchemaModel,
)

# ═══════════════════════════════════════════════════════════════
# Result dataclasses
# ═══════════════════════════════════════════════════════════════


@dataclass(frozen=True, slots=True)
class MethodKey:
    """Identity tuple for an operation: (route, verb)."""

    route: str
    verb: str

    def __str__(self) -> str:
        """Render as e.g. ``"GET /pets"`` for log messages."""
        return f"{self.verb} {self.route}"


@dataclass(frozen=True, slots=True)
class MethodDiff:
    """Granular diff for a single method that exists in both specs.

    Attributes:
        key: ``(route, verb)`` identity tuple.
        summary_changed: ``True`` if ``summary`` text differs.
        deprecated_changed: ``True`` if the deprecated flag flipped.
        request_body_changed: ``True`` if the request-body $ref target
            changed (added, removed, or different schema).
        response_refs_changed: ``True`` if any status→schema mapping
            differs.
        parameters_changed: ``True`` if the parameter set differs (by
            ``(name, location)`` keys or required-ness).
        tags_changed: ``True`` if the tag set differs.
    """

    key: MethodKey
    summary_changed: bool = False
    deprecated_changed: bool = False
    request_body_changed: bool = False
    response_refs_changed: bool = False
    parameters_changed: bool = False
    tags_changed: bool = False

    @property
    def any_change(self) -> bool:
        """Whether any sub-attribute differs."""
        return any(
            (
                self.summary_changed,
                self.deprecated_changed,
                self.request_body_changed,
                self.response_refs_changed,
                self.parameters_changed,
                self.tags_changed,
            )
        )


@dataclass(frozen=True, slots=True)
class SchemaDiff:
    """Granular diff for a schema that exists in both specs.

    Attributes:
        name: Schema name.
        fields_added: Property names present only in *new*.
        fields_removed: Property names present only in *old*.
        fields_changed: Property names whose type / ref / array-ness
            differs between *old* and *new*.
        composition_changed: ``True`` if allOf / oneOf / anyOf /
            discriminator differ.
    """

    name: str
    fields_added: list[str] = field(default_factory=list)
    fields_removed: list[str] = field(default_factory=list)
    fields_changed: list[str] = field(default_factory=list)
    composition_changed: bool = False

    @property
    def any_change(self) -> bool:
        """Whether any sub-attribute differs."""
        return bool(
            self.fields_added
            or self.fields_removed
            or self.fields_changed
            or self.composition_changed
        )


@dataclass(frozen=True, slots=True)
class SpecDiff:
    """Top-level diff result returned by :func:`compute_diff`.

    Attributes:
        paths_added: Routes present only in *new*.
        paths_removed: Routes present only in *old*.
        methods_added: ``(route, verb)`` operations present only in *new*.
        methods_removed: ``(route, verb)`` operations present only in *old*.
        methods_changed: Operations whose body / response / params /
            metadata changed.
        schemas_added: Schema names present only in *new*.
        schemas_removed: Schema names present only in *old*.
        schemas_changed: Schemas with field-level changes.
    """

    paths_added: list[str] = field(default_factory=list)
    paths_removed: list[str] = field(default_factory=list)
    methods_added: list[MethodKey] = field(default_factory=list)
    methods_removed: list[MethodKey] = field(default_factory=list)
    methods_changed: list[MethodDiff] = field(default_factory=list)
    schemas_added: list[str] = field(default_factory=list)
    schemas_removed: list[str] = field(default_factory=list)
    schemas_changed: list[SchemaDiff] = field(default_factory=list)

    @property
    def is_empty(self) -> bool:
        """``True`` when *old* and *new* are structurally identical."""
        return not any(
            (
                self.paths_added,
                self.paths_removed,
                self.methods_added,
                self.methods_removed,
                self.methods_changed,
                self.schemas_added,
                self.schemas_removed,
                self.schemas_changed,
            )
        )


# ═══════════════════════════════════════════════════════════════
# compute_diff
# ═══════════════════════════════════════════════════════════════


def compute_diff(old: ParsedSpec, new: ParsedSpec) -> SpecDiff:
    """Produce a :class:`SpecDiff` summarising changes from *old* to *new*.

    Args:
        old: The earlier :class:`ParsedSpec`.
        new: The later :class:`ParsedSpec`.

    Returns:
        A populated :class:`SpecDiff`. Use :attr:`SpecDiff.is_empty` to
        check whether anything changed.
    """
    diff = SpecDiff()

    # ── Paths & methods ──────────────────────────────────────
    old_paths = {p.route: p for p in old.paths}
    new_paths = {p.route: p for p in new.paths}

    diff.paths_added.extend(sorted(set(new_paths) - set(old_paths)))
    diff.paths_removed.extend(sorted(set(old_paths) - set(new_paths)))

    # Per-method diff for shared routes.
    for route in sorted(set(old_paths) & set(new_paths)):
        _diff_methods(old_paths[route], new_paths[route], diff)

    # Methods on routes that were entirely added/removed: bulk-classify.
    for route in diff.paths_added:
        for m in new_paths[route].methods:
            diff.methods_added.append(MethodKey(route=route, verb=m.verb))
    for route in diff.paths_removed:
        for m in old_paths[route].methods:
            diff.methods_removed.append(MethodKey(route=route, verb=m.verb))

    # ── Schemas ──────────────────────────────────────────────
    old_schemas = {s.name: s for s in old.schemas}
    new_schemas = {s.name: s for s in new.schemas}

    diff.schemas_added.extend(sorted(set(new_schemas) - set(old_schemas)))
    diff.schemas_removed.extend(sorted(set(old_schemas) - set(new_schemas)))

    for name in sorted(set(old_schemas) & set(new_schemas)):
        sub = _diff_schema(old_schemas[name], new_schemas[name])
        if sub.any_change:
            diff.schemas_changed.append(sub)

    return diff


def _diff_methods(old: PathItem, new: PathItem, diff: SpecDiff) -> None:
    """Diff the method sets of two same-route :class:`PathItem`s."""
    old_methods = {m.verb: m for m in old.methods}
    new_methods = {m.verb: m for m in new.methods}

    for verb in sorted(set(new_methods) - set(old_methods)):
        diff.methods_added.append(MethodKey(route=new.route, verb=verb))
    for verb in sorted(set(old_methods) - set(new_methods)):
        diff.methods_removed.append(MethodKey(route=old.route, verb=verb))

    for verb in sorted(set(old_methods) & set(new_methods)):
        sub = _diff_one_method(new.route, old_methods[verb], new_methods[verb])
        if sub.any_change:
            diff.methods_changed.append(sub)


def _diff_one_method(route: str, old: MethodDetail, new: MethodDetail) -> MethodDiff:
    """Compare a pair of same-(route, verb) methods, attribute by attribute."""
    return MethodDiff(
        key=MethodKey(route=route, verb=old.verb),
        summary_changed=old.summary != new.summary,
        deprecated_changed=old.deprecated != new.deprecated,
        request_body_changed=old.request_body_ref != new.request_body_ref,
        response_refs_changed=dict(old.response_refs) != dict(new.response_refs),
        parameters_changed=_parameters_differ(old, new),
        tags_changed=sorted(old.tags) != sorted(new.tags),
    )


def _parameters_differ(old: MethodDetail, new: MethodDetail) -> bool:
    """Return ``True`` if the (name, location, required, type) sets differ."""

    def fingerprint(method: MethodDetail) -> set[tuple[str, str, bool, str | None]]:
        return {(p.name, p.location, p.required, p.type) for p in method.parameters}

    return fingerprint(old) != fingerprint(new)


def _diff_schema(old: SchemaModel, new: SchemaModel) -> SchemaDiff:
    """Compare two same-named schemas field-by-field."""
    old_fields = {f.name: f for f in old.fields}
    new_fields = {f.name: f for f in new.fields}

    added = sorted(set(new_fields) - set(old_fields))
    removed = sorted(set(old_fields) - set(new_fields))

    changed: list[str] = []
    for name in sorted(set(old_fields) & set(new_fields)):
        o, n = old_fields[name], new_fields[name]
        if (o.type, o.ref_target, o.is_array, o.format) != (
            n.type,
            n.ref_target,
            n.is_array,
            n.format,
        ):
            changed.append(name)

    composition_changed = (
        sorted(old.all_of) != sorted(new.all_of)
        or sorted(old.one_of) != sorted(new.one_of)
        or sorted(old.any_of) != sorted(new.any_of)
        or old.discriminator != new.discriminator
        or sorted(old.enum_values) != sorted(new.enum_values)
    )

    return SchemaDiff(
        name=old.name,
        fields_added=added,
        fields_removed=removed,
        fields_changed=changed,
        composition_changed=composition_changed,
    )
