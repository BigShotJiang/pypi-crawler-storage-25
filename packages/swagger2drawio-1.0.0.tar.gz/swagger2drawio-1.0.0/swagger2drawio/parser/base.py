"""Common interface for OpenAPI / Swagger spec parsers.

A parser is anything that, given a raw spec dictionary, returns a
:class:`~swagger2drawio.parser.openapi_parser.ParsedSpec`.

Currently we ship one concrete implementation (the unified parser in
:mod:`swagger2drawio.parser.openapi_parser` that handles both OAS 3 and
Swagger 2 via internal dispatch). The :class:`SpecParser` protocol +
:func:`get_parser` factory exist so that future variants (or third-party
parsers registered via entry points) plug in without changing callers.
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

from swagger2drawio.exceptions import SpecParseError


@runtime_checkable
class SpecParser(Protocol):
    """A pluggable spec → :class:`ParsedSpec` adapter.

    Implementations should be stateless or stash state on the instance,
    not as module globals.
    """

    def parse_dict(self, raw: dict[str, Any]) -> Any:
        """Convert a raw spec dict into a :class:`ParsedSpec`.

        Args:
            raw: The decoded spec as a Python dict.

        Returns:
            A populated :class:`~swagger2drawio.parser.openapi_parser.ParsedSpec`.
        """
        ...


def detect_version(raw: dict[str, Any]) -> str:
    """Return ``"oas3"`` for OpenAPI 3.x, ``"swagger2"`` for Swagger 2.0.

    Args:
        raw: The decoded spec dict.

    Returns:
        ``"oas3"`` if the ``openapi`` key is present and starts with
        ``"3."``; ``"swagger2"`` if ``swagger == "2.0"``.

    Raises:
        SpecParseError: If neither marker is present (the spec is
            neither OAS 3 nor Swagger 2).
    """
    openapi = raw.get("openapi")
    if isinstance(openapi, str) and openapi.startswith("3."):
        return "oas3"
    if raw.get("swagger") == "2.0":
        return "swagger2"
    raise SpecParseError(
        "Spec is neither OpenAPI 3.x (`openapi: 3.x.y`) nor Swagger 2.0 "
        "(`swagger: '2.0'`); cannot determine parser."
    )


def get_parser(raw: dict[str, Any]) -> SpecParser:
    """Return an appropriate :class:`SpecParser` for the spec dict.

    The current implementation always returns the unified parser
    (which itself dispatches on version internally). The factory exists
    so future per-version classes or third-party parsers can plug in.

    Args:
        raw: The decoded spec dict.

    Returns:
        A :class:`SpecParser` instance.

    Raises:
        SpecParseError: If the spec version cannot be detected.
    """
    # Validate the version early so callers get a clear error before parse.
    detect_version(raw)

    # Lazy import to avoid a circular dependency.
    from swagger2drawio.parser.openapi_parser import OpenAPIParser

    return OpenAPIParser.from_dict_factory()
