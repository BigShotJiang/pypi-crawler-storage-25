"""OpenAPI / Swagger specification parser.

Reads an OpenAPI 3.x (or Swagger 2.x) specification from a **local file**
or a **remote URL**, and extracts the information required for diagram
generation into a set of strongly-typed dataclasses.

Supported formats:
    * JSON  (``.json``)
    * YAML  (``.yaml`` / ``.yml``)

Supported sources:
    * Local filesystem paths
    * HTTP / HTTPS URLs

Typical usage::

    parser = OpenAPIParser(source="https://petstore3.swagger.io/api/v3/openapi.json")
    spec = parser.parse()

    for path in spec.paths:
        print(path.route, [m.verb for m in path.methods])

    for schema in spec.schemas:
        print(schema.name, schema.fields)
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import requests
import yaml

from swagger2drawio.exceptions import SpecLoadError, SpecParseError

logger = logging.getLogger(__name__)

# ── Data-classes ─────────────────────────────────────────────


@dataclass(frozen=True, slots=True)
class SchemaField:
    """A single property inside a component schema.

    Attributes:
        name: Property name (e.g. ``"id"``, ``"email"``).
        type: JSON-Schema type string (``"string"``, ``"integer"``, …).
            When the property is a ``$ref``, this is set to
            ``"$ref"`` and ``ref_target`` holds the referenced schema
            name.
        format: Optional JSON-Schema ``format`` (``"int64"``,
            ``"date-time"``, …).
        ref_target: If the field references another schema via
            ``$ref``, this stores the **short** schema name
            (e.g. ``"Address"``).  ``None`` for primitive fields.
        is_array: ``True`` when the property is an ``array`` whose
            ``items`` may carry a ``$ref``.
    """

    name: str
    type: str
    format: str | None = None
    ref_target: str | None = None
    is_array: bool = False


@dataclass(frozen=True, slots=True)
class SchemaModel:
    """Represents one entry under ``components/schemas`` or ``definitions``.

    Used uniformly for OpenAPI 3.x (``components.schemas``) and Swagger
    2.x (``definitions``).

    Attributes:
        name: Schema / model name (e.g. ``"Pet"``, ``"Order"``).
        fields: Ordered list of properties parsed from the schema.
        description: Optional human-readable description.
        all_of: Schema names this model inherits via ``allOf``.
        one_of: Schema names this model can be one of (``oneOf``).
        any_of: Schema names this model can be any of (``anyOf``).
        discriminator: Field name used to discriminate ``oneOf`` /
            ``anyOf`` variants.
        is_enum: ``True`` when the schema is a primitive enum.
        enum_values: Enum literal values when ``is_enum`` is set.
    """

    name: str
    fields: list[SchemaField] = field(default_factory=list)
    description: str | None = None
    all_of: list[str] = field(default_factory=list)
    one_of: list[str] = field(default_factory=list)
    any_of: list[str] = field(default_factory=list)
    discriminator: str | None = None
    is_enum: bool = False
    enum_values: list[str] = field(default_factory=list)


_VALID_PARAMETER_LOCATIONS: frozenset[str] = frozenset(
    {"path", "query", "header", "cookie", "body", "formData"}
)


@dataclass(frozen=True, slots=True)
class Parameter:
    """A single operation-level parameter (path / query / header / cookie).

    Attributes:
        name: Parameter name (e.g. ``"petId"``, ``"limit"``).
        location: Where the parameter is passed — ``"path"``, ``"query"``,
            ``"header"``, ``"cookie"``, or ``"body"`` (Swagger 2 only).
        type: JSON-Schema primitive type when known; ``None`` for
            $ref-only parameters.
        required: ``True`` if the parameter is required.
    """

    name: str
    location: str
    type: str | None = None
    required: bool = False

    def __post_init__(self) -> None:
        """Reject empty names and unknown ``in`` values early.

        Raises:
            ValueError: If ``name`` is empty or ``location`` is not one
                of the recognised OpenAPI parameter locations.
        """
        if not self.name:
            raise ValueError("Parameter.name cannot be empty")
        if self.location not in _VALID_PARAMETER_LOCATIONS:
            raise ValueError(
                f"Parameter.location must be one of "
                f"{sorted(_VALID_PARAMETER_LOCATIONS)}, got {self.location!r}"
            )


@dataclass(frozen=True, slots=True)
class MethodDetail:
    """A single HTTP method on a specific path.

    Attributes:
        verb: Uppercase HTTP verb (``"GET"``, ``"POST"``, …).
        summary: Short summary string from the spec, if present.
        operation_id: The ``operationId`` value, if present.
        tags: Tags associated with this operation.
        parameters: Path / query / header / cookie parameters.
        request_body_ref: Short schema name referenced by the request
            body (e.g. ``"Pet"``); ``None`` if no body or no ref.
        response_refs: Mapping of status code (``"200"``, ``"default"``)
            to the referenced schema name. Only entries that actually
            $ref a component schema are included.
        deprecated: ``True`` if the spec marks this operation as
            deprecated.
    """

    verb: str
    summary: str | None = None
    operation_id: str | None = None
    tags: list[str] = field(default_factory=list)
    parameters: list[Parameter] = field(default_factory=list)
    request_body_ref: str | None = None
    response_refs: dict[str, str] = field(default_factory=dict)
    deprecated: bool = False

    def __post_init__(self) -> None:
        """Reject unknown HTTP verbs at construction time.

        Raises:
            ValueError: If ``verb`` is not an uppercase recognised
                HTTP method.
        """
        if self.verb.upper() not in {v.upper() for v in _HTTP_METHODS}:
            raise ValueError(f"MethodDetail.verb must be an HTTP method, got {self.verb!r}")


@dataclass(frozen=True, slots=True)
class PathItem:
    """A single API path (e.g. ``/users/{id}``) and its methods.

    Attributes:
        route: The URL path string.
        methods: All HTTP methods defined on this path.
    """

    route: str
    methods: list[MethodDetail] = field(default_factory=list)


@dataclass(frozen=True, slots=True)
class SecurityScheme:
    """A single entry from ``securitySchemes`` (OAS 3) or ``securityDefinitions`` (Swagger 2).

    Attributes:
        name: The key under ``securitySchemes`` (e.g. ``"bearerAuth"``).
        type: ``apiKey``, ``http``, ``oauth2``, ``openIdConnect``, etc.
        scheme: For ``type=http`` — ``"basic"`` / ``"bearer"``.
        location: ``in`` for ``apiKey`` schemes (``"header"`` / ``"query"`` / ``"cookie"``).
        description: Optional human description.
    """

    name: str
    type: str
    scheme: str | None = None
    location: str | None = None
    description: str | None = None


@dataclass(frozen=True, slots=True)
class ParsedSpec:
    """Top-level container returned by :meth:`OpenAPIParser.parse`.

    Attributes:
        title: The ``info.title`` from the specification.
        version: The ``info.version`` from the specification.
        paths: All extracted path items with their methods.
        schemas: All extracted component schemas / definitions.
        description: ``info.description`` if present.
        servers: List of server URLs (OAS 3) or the synthetic
            ``schemes://host/basePath`` URLs from Swagger 2.
        security_schemes: Declared authentication schemes.
    """

    title: str
    version: str
    paths: list[PathItem] = field(default_factory=list)
    schemas: list[SchemaModel] = field(default_factory=list)
    description: str | None = None
    servers: list[str] = field(default_factory=list)
    security_schemes: list[SecurityScheme] = field(default_factory=list)


# ── Helpers ──────────────────────────────────────────────────

_HTTP_METHODS: frozenset[str] = frozenset(
    {"get", "post", "put", "patch", "delete", "options", "head", "trace"}
)


def _resolve_ref_name(ref: str) -> str:
    """Extract the short schema name from a JSON ``$ref`` pointer.

    Args:
        ref: A JSON-Reference string such as
            ``"#/components/schemas/Pet"`` or ``"#/definitions/Pet"``.

    Returns:
        The last segment of the reference path (e.g. ``"Pet"``).

    Examples:
        >>> _resolve_ref_name("#/components/schemas/Pet")
        'Pet'
    """
    return ref.rsplit("/", maxsplit=1)[-1]


def _extract_request_body_ref(op_data: dict[str, Any]) -> str | None:
    """Return the short schema name referenced by an operation's request body.

    Supports both OpenAPI 3.x (``requestBody.content.<media>.schema.$ref``)
    and Swagger 2.x (``parameters[in=body].schema.$ref``).

    Args:
        op_data: The raw operation dict (the value under a verb key).

    Returns:
        The short schema name (e.g. ``"Pet"``) if a $ref is present,
        otherwise ``None``.
    """
    # OpenAPI 3.x — first media type wins.
    request_body = op_data.get("requestBody")
    if isinstance(request_body, dict):
        content = request_body.get("content")
        if isinstance(content, dict):
            for media in content.values():
                if isinstance(media, dict):
                    schema = media.get("schema", {})
                    if isinstance(schema, dict) and "$ref" in schema:
                        return _resolve_ref_name(schema["$ref"])
                    # array of ref
                    if isinstance(schema, dict) and schema.get("type") == "array":
                        items = schema.get("items", {})
                        if isinstance(items, dict) and "$ref" in items:
                            return _resolve_ref_name(items["$ref"])

    # Swagger 2.x — look for parameters[in=body].
    for param in op_data.get("parameters", []) or []:
        if isinstance(param, dict) and param.get("in") == "body":
            schema = param.get("schema", {})
            if isinstance(schema, dict) and "$ref" in schema:
                return _resolve_ref_name(schema["$ref"])
    return None


def _extract_response_refs(op_data: dict[str, Any]) -> dict[str, str]:
    """Return a mapping of HTTP status → referenced schema name.

    Only entries whose response schema (or array-of-schema items)
    contains a ``$ref`` are included.

    Args:
        op_data: The raw operation dict.

    Returns:
        Mapping like ``{"200": "Pet", "default": "Error"}``. Empty when
        no responses reference component schemas.
    """
    refs: dict[str, str] = {}
    responses = op_data.get("responses", {})
    if not isinstance(responses, dict):
        return refs

    for status, resp in responses.items():
        if not isinstance(resp, dict):
            continue

        # OAS 3: response.content.<media>.schema
        content = resp.get("content")
        if isinstance(content, dict):
            for media in content.values():
                if not isinstance(media, dict):
                    continue
                schema = media.get("schema", {})
                ref_name = _ref_name_from_schema(schema)
                if ref_name:
                    refs[str(status)] = ref_name
                    break

        # Swagger 2: response.schema directly
        if status not in refs:
            schema = resp.get("schema", {})
            ref_name = _ref_name_from_schema(schema)
            if ref_name:
                refs[str(status)] = ref_name

    return refs


def _ref_name_from_schema(schema: Any) -> str | None:
    """Pull a $ref short name out of a schema object (handles array-of-ref)."""
    if not isinstance(schema, dict):
        return None
    if "$ref" in schema:
        return _resolve_ref_name(schema["$ref"])
    if schema.get("type") == "array":
        items = schema.get("items", {})
        if isinstance(items, dict) and "$ref" in items:
            return _resolve_ref_name(items["$ref"])
    return None


def _extract_composition(schema_obj: dict[str, Any]) -> dict[str, Any]:
    """Pull allOf / oneOf / anyOf / discriminator metadata from a schema.

    Each composition keyword yields a list of *short* referenced schema
    names — inline (non-$ref) subschemas are skipped here because they
    don't correspond to an entity node in the schema graph.

    Args:
        schema_obj: The raw schema dict.

    Returns:
        A dict with keys ``allOf``, ``oneOf``, ``anyOf`` (each a list of
        short names) and ``discriminator`` (str | None).
    """

    def refs(items: Any) -> list[str]:
        if not isinstance(items, list):
            return []
        out: list[str] = []
        for entry in items:
            if isinstance(entry, dict) and "$ref" in entry:
                out.append(_resolve_ref_name(entry["$ref"]))
        return out

    discriminator: str | None = None
    raw_discriminator = schema_obj.get("discriminator")
    if isinstance(raw_discriminator, dict):
        # OAS 3 form: {"propertyName": "type", "mapping": {...}}
        prop = raw_discriminator.get("propertyName")
        if isinstance(prop, str):
            discriminator = prop
    elif isinstance(raw_discriminator, str):
        # Swagger 2 form: bare string.
        discriminator = raw_discriminator

    return {
        "allOf": refs(schema_obj.get("allOf")),
        "oneOf": refs(schema_obj.get("oneOf")),
        "anyOf": refs(schema_obj.get("anyOf")),
        "discriminator": discriminator,
    }


def _extract_enum(schema_obj: dict[str, Any]) -> dict[str, Any]:
    """Detect whether a schema is a primitive enum and capture its values.

    Args:
        schema_obj: The raw schema dict.

    Returns:
        ``{"is_enum": bool, "enum_values": [...]}``. A schema counts as
        an enum when it has an ``enum`` array and is *not* an object
        type (object enums are unusual and don't render well).
    """
    raw_enum = schema_obj.get("enum")
    if not isinstance(raw_enum, list) or not raw_enum:
        return {"is_enum": False, "enum_values": []}
    if schema_obj.get("type") == "object":
        return {"is_enum": False, "enum_values": []}
    return {"is_enum": True, "enum_values": [str(v) for v in raw_enum]}


def _is_url(source: str) -> bool:
    """Check whether *source* looks like an HTTP(S) URL.

    Args:
        source: A string that is either a URL or a filesystem path.

    Returns:
        ``True`` if the string starts with ``http://`` or ``https://``.
    """
    return source.startswith("http://") or source.startswith("https://")


def _load_raw_spec(
    source: str,
    *,
    timeout: float = 10.0,
    headers: dict[str, str] | None = None,
    verify_ssl: bool = True,
) -> dict[str, Any]:
    """Load the raw specification dict from a file or URL.

    The function transparently handles JSON and YAML based on content
    inspection (tries JSON first, then falls back to YAML).

    Args:
        source: Filesystem path **or** HTTP(S) URL to the spec.
        timeout: HTTP timeout in seconds (URLs only). Default 10s.
        headers: Optional HTTP headers to attach to the GET request
            (e.g. ``{"Authorization": "Bearer ..."}``).
        verify_ssl: When ``False``, skip TLS certificate verification.
            Useful for self-signed internal APIs but should never be
            used against untrusted hosts.

    Returns:
        The parsed specification as a plain Python dictionary.

    Raises:
        SpecLoadError: If the local file is missing, unreadable, or the
            remote URL fails to fetch.
        SpecParseError: If the fetched content cannot be decoded as
            JSON or YAML.
    """
    if _is_url(source):
        logger.info("Fetching spec from URL: %s (timeout=%ss)", source, timeout)
        try:
            response = requests.get(
                source,
                timeout=timeout,
                headers=headers or None,
                allow_redirects=True,
                verify=verify_ssl,
            )
            response.raise_for_status()
        except requests.RequestException as exc:
            raise SpecLoadError(f"Failed to fetch spec from URL: {source} ({exc})") from exc
        logger.debug("Fetched %d bytes from %s", len(response.text), source)
        text = response.text
    else:
        logger.info("Loading spec from file: %s", source)
        path = Path(source)
        if not path.exists():
            raise SpecLoadError(f"Spec file not found: {path}")
        try:
            text = path.read_text(encoding="utf-8")
        except OSError as exc:
            raise SpecLoadError(f"Cannot read spec file {path}: {exc}") from exc

    # Try JSON first (faster & unambiguous), then fall back to YAML.
    try:
        return json.loads(text)  # type: ignore[no-any-return]
    except json.JSONDecodeError:
        pass

    try:
        data = yaml.safe_load(text)
    except yaml.YAMLError as exc:
        raise SpecParseError(f"Spec content is not valid JSON or YAML: {exc}") from exc

    if not isinstance(data, dict):
        raise SpecParseError("Spec content could not be parsed as a JSON/YAML object.")
    return data


# ── Parser class ─────────────────────────────────────────────


class OpenAPIParser:
    """Stateless parser that converts an OpenAPI spec into typed dataclasses.

    The parser auto-detects whether the spec is **OpenAPI 3.x** (looks
    for ``components/schemas``) or **Swagger 2.x** (looks for
    ``definitions``).

    Args:
        source: Local file path **or** HTTP(S) URL pointing to a valid
            OpenAPI / Swagger specification.

    Example::

        parser = OpenAPIParser("petstore.yaml")
        spec = parser.parse()
        print(spec.title, spec.version)
    """

    def __init__(
        self,
        source: str,
        *,
        timeout: float = 10.0,
        headers: dict[str, str] | None = None,
        verify_ssl: bool = True,
    ) -> None:
        """Initialise the parser.

        Args:
            source: Local file path or HTTP(S) URL to the spec.
            timeout: HTTP timeout in seconds for URL sources.
            headers: Optional HTTP headers (e.g. for auth).
            verify_ssl: Whether to verify TLS certificates.
        """
        self._source: str = source
        self._timeout: float = timeout
        self._headers: dict[str, str] | None = headers
        self._verify_ssl: bool = verify_ssl
        self._raw: dict[str, Any] | None = None

    # ── Public API ───────────────────────────────────────────

    def parse(self, *, validate: bool = False, resolve_external_refs: bool = True) -> ParsedSpec:
        """Parse the specification and return a :class:`ParsedSpec`.

        Args:
            validate: When ``True``, run the spec through
                ``openapi-spec-validator`` before extraction. Defaults to
                ``False`` so the parser stays a pure-format operation.
            resolve_external_refs: When ``True`` (default), external file
                and remote ``$ref`` pointers are fetched and inlined into
                the spec under ``components.schemas`` before extraction.

        Returns:
            A fully-populated :class:`ParsedSpec` instance containing
            paths, methods, and schema models.

        Raises:
            SpecLoadError: If the local file is missing, the URL fetch
                fails, or an external ``$ref`` cannot be fetched.
            SpecParseError: If the content cannot be decoded as
                JSON / YAML.
            SpecValidationError: If ``validate=True`` and the spec does
                not conform to its declared OpenAPI / Swagger schema.
        """
        self._raw = _load_raw_spec(
            self._source,
            timeout=self._timeout,
            headers=self._headers,
            verify_ssl=self._verify_ssl,
        )

        if resolve_external_refs:
            from swagger2drawio.refs import RefResolver

            resolver = RefResolver(source=self._source)
            resolver.resolve(self._raw)
            pending = resolver.pending_schemas()
            if pending:
                components = self._raw.setdefault("components", {})
                schemas_section = components.setdefault("schemas", {})
                for name, schema in pending.items():
                    schemas_section.setdefault(name, schema)

        if validate:
            # Local import keeps the validator (and its jsonschema deps)
            # out of the import-time graph for the common no-validate path.
            from swagger2drawio.validator import validate_spec

            validate_spec(self._raw)

        return self._extract_parsed_spec()

    def parse_dict(self, raw: dict[str, Any]) -> ParsedSpec:
        """Parse a pre-loaded spec dict, skipping the I/O step.

        Useful for callers that already have the raw document in
        memory (e.g. the diff workflow, tests, or callers that obtained
        the spec from a non-file source like a database).

        Args:
            raw: The decoded spec dictionary.

        Returns:
            A populated :class:`ParsedSpec`.
        """
        self._raw = raw
        return self._extract_parsed_spec()

    @classmethod
    def from_dict_factory(cls) -> OpenAPIParser:
        """Build a parser instance without binding it to a file/URL source.

        Used by :func:`swagger2drawio.parser.base.get_parser` to hand
        out a parser when the caller has already loaded the raw dict.

        Returns:
            A parser whose :meth:`parse_dict` is the intended entry
            point. Calling :meth:`parse` on this instance is undefined
            (no source bound).
        """
        return cls(source="")

    def _extract_parsed_spec(self) -> ParsedSpec:
        """Run the dict → :class:`ParsedSpec` extraction step.

        Returns:
            The populated :class:`ParsedSpec`.
        """
        assert self._raw is not None
        info: dict[str, Any] = self._raw.get("info", {})
        title: str = info.get("title", "Untitled API")
        version: str = info.get("version", "0.0.0")
        description: str | None = info.get("description") if isinstance(info, dict) else None

        paths = self._extract_paths()
        schemas = self._extract_schemas()
        servers = self._extract_servers()
        security_schemes = self._extract_security_schemes()

        return ParsedSpec(
            title=title,
            version=version,
            paths=paths,
            schemas=schemas,
            description=description,
            servers=servers,
            security_schemes=security_schemes,
        )

    # ── Server + security extraction ─────────────────────────

    def _extract_servers(self) -> list[str]:
        """Return server URLs, normalising OAS 3 and Swagger 2 forms."""
        assert self._raw is not None
        servers_raw = self._raw.get("servers")
        if isinstance(servers_raw, list):
            return [s["url"] for s in servers_raw if isinstance(s, dict) and "url" in s]

        # Swagger 2: combine schemes + host + basePath
        host = self._raw.get("host")
        base_path = self._raw.get("basePath", "")
        schemes = self._raw.get("schemes")
        if isinstance(host, str):
            scheme_list = schemes if isinstance(schemes, list) and schemes else ["https"]
            return [f"{s}://{host}{base_path}" for s in scheme_list]
        return []

    def _extract_security_schemes(self) -> list[SecurityScheme]:
        """Pull authentication schemes from either OAS 3 or Swagger 2."""
        assert self._raw is not None
        raw = self._raw.get("components", {}).get("securitySchemes")
        if not isinstance(raw, dict):
            raw = self._raw.get("securityDefinitions")
        if not isinstance(raw, dict):
            return []

        schemes: list[SecurityScheme] = []
        for name, entry in raw.items():
            if not isinstance(entry, dict):
                continue
            scheme_type = entry.get("type")
            if not isinstance(scheme_type, str):
                continue
            schemes.append(
                SecurityScheme(
                    name=name,
                    type=scheme_type,
                    scheme=entry.get("scheme") if isinstance(entry.get("scheme"), str) else None,
                    location=entry.get("in") if isinstance(entry.get("in"), str) else None,
                    description=entry.get("description")
                    if isinstance(entry.get("description"), str)
                    else None,
                )
            )
        return schemes

    # ── Path extraction ──────────────────────────────────────

    def _extract_paths(self) -> list[PathItem]:
        """Walk the ``paths`` section and build :class:`PathItem` objects.

        Returns:
            A list of :class:`PathItem`, one per distinct route, each
            containing its :class:`MethodDetail` children.
        """
        assert self._raw is not None
        raw_paths: dict[str, Any] = self._raw.get("paths", {})
        items: list[PathItem] = []

        for route, operations in raw_paths.items():
            if not isinstance(operations, dict):
                continue

            # Path-level `parameters` apply to every operation under it.
            shared_params = self._parse_parameters(operations.get("parameters", []))

            methods: list[MethodDetail] = []
            for key, op_data in operations.items():
                if key.lower() not in _HTTP_METHODS:
                    continue
                if not isinstance(op_data, dict):
                    continue

                op_params = self._parse_parameters(op_data.get("parameters", []))
                merged_params = self._merge_parameters(shared_params, op_params)

                methods.append(
                    MethodDetail(
                        verb=key.upper(),
                        summary=op_data.get("summary"),
                        operation_id=op_data.get("operationId"),
                        tags=op_data.get("tags", []),
                        parameters=merged_params,
                        request_body_ref=_extract_request_body_ref(op_data),
                        response_refs=_extract_response_refs(op_data),
                        deprecated=bool(op_data.get("deprecated", False)),
                    )
                )

            items.append(PathItem(route=route, methods=methods))

        return items

    @staticmethod
    def _parse_parameters(raw_params: Any) -> list[Parameter]:
        """Convert a raw ``parameters`` list into :class:`Parameter` objects.

        Args:
            raw_params: The ``parameters`` value from a path-item or
                operation object. Anything that isn't a list is skipped.

        Returns:
            A list of :class:`Parameter` instances, preserving order.
        """
        params: list[Parameter] = []
        if not isinstance(raw_params, list):
            return params
        for entry in raw_params:
            if not isinstance(entry, dict):
                continue
            name = entry.get("name")
            location = entry.get("in")
            if not isinstance(name, str) or not isinstance(location, str):
                continue
            # OAS 3: type is under entry["schema"]["type"]. Swagger 2: top-level.
            schema = entry.get("schema") if isinstance(entry.get("schema"), dict) else None
            type_str = (schema or entry).get("type") if schema or "type" in entry else None
            params.append(
                Parameter(
                    name=name,
                    location=location,
                    type=type_str if isinstance(type_str, str) else None,
                    required=bool(entry.get("required", location == "path")),
                )
            )
        return params

    @staticmethod
    def _merge_parameters(shared: list[Parameter], specific: list[Parameter]) -> list[Parameter]:
        """Merge path-level and operation-level parameters.

        Per the OpenAPI spec, an operation-level parameter with the same
        ``(name, in)`` pair as a path-level one overrides it.

        Args:
            shared: Parameters declared on the path item.
            specific: Parameters declared on the individual operation.

        Returns:
            The merged list, with operation overrides taking precedence
            and shared-only parameters listed first.
        """
        specific_keys = {(p.name, p.location) for p in specific}
        return [p for p in shared if (p.name, p.location) not in specific_keys] + list(specific)

    # ── Schema extraction ────────────────────────────────────

    def _extract_schemas(self) -> list[SchemaModel]:
        """Walk the spec's schema section and build :class:`SchemaModel` objects.

        Looks under ``components/schemas`` (OAS 3) first, then falls back
        to ``definitions`` (Swagger 2).

        Returns:
            A list of :class:`SchemaModel`, each with its parsed
            :class:`SchemaField` children.
        """
        assert self._raw is not None

        # OAS 3.x
        schemas_section: dict[str, Any] = self._raw.get("components", {}).get("schemas", {})

        # Fallback: Swagger 2.x
        if not schemas_section:
            schemas_section = self._raw.get("definitions", {})

        models: list[SchemaModel] = []

        for name, schema_obj in schemas_section.items():
            if not isinstance(schema_obj, dict):
                continue

            fields = self._parse_properties(schema_obj.get("properties", {}))
            composition = _extract_composition(schema_obj)
            enum_meta = _extract_enum(schema_obj)
            models.append(
                SchemaModel(
                    name=name,
                    fields=fields,
                    description=schema_obj.get("description"),
                    all_of=composition["allOf"],
                    one_of=composition["oneOf"],
                    any_of=composition["anyOf"],
                    discriminator=composition["discriminator"],
                    is_enum=enum_meta["is_enum"],
                    enum_values=enum_meta["enum_values"],
                )
            )

        return models

    # ── Property-level helpers ───────────────────────────────

    @staticmethod
    def _parse_properties(
        properties: dict[str, Any],
    ) -> list[SchemaField]:
        """Convert a JSON-Schema ``properties`` mapping into typed fields.

        Handles:
        * Primitive types (``string``, ``integer``, …)
        * Direct ``$ref`` pointers
        * ``array`` types whose ``items`` carry a ``$ref``

        Args:
            properties: The ``properties`` dict from a JSON-Schema
                object definition.

        Returns:
            A list of :class:`SchemaField` instances preserving the
            insertion order of the original mapping.
        """
        fields: list[SchemaField] = []

        for prop_name, prop_def in properties.items():
            if not isinstance(prop_def, dict):
                continue

            # ── Direct $ref ──────────────────────────────────
            if "$ref" in prop_def:
                fields.append(
                    SchemaField(
                        name=prop_name,
                        type="$ref",
                        ref_target=_resolve_ref_name(prop_def["$ref"]),
                    )
                )
                continue

            prop_type: str = prop_def.get("type", "object")
            prop_format: str | None = prop_def.get("format")

            # ── Array with potential $ref items ──────────────
            if prop_type == "array":
                items = prop_def.get("items", {})
                ref_target: str | None = None
                if "$ref" in items:
                    ref_target = _resolve_ref_name(items["$ref"])
                fields.append(
                    SchemaField(
                        name=prop_name,
                        type=items.get("type", "$ref") if ref_target is None else "$ref",
                        format=prop_format,
                        ref_target=ref_target,
                        is_array=True,
                    )
                )
                continue

            # ── Primitive / nested object ────────────────────
            fields.append(
                SchemaField(
                    name=prop_name,
                    type=prop_type,
                    format=prop_format,
                )
            )

        return fields
