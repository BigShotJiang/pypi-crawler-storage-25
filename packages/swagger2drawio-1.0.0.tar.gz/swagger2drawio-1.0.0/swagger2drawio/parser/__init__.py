"""Subpackage for parsing OpenAPI/Swagger specification files."""
