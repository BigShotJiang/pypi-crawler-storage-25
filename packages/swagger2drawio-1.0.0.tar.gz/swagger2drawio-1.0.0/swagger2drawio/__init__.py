"""swagger2drawio — Generate Draw.io diagrams from OpenAPI/Swagger specifications."""

__version__ = "1.0.0"
