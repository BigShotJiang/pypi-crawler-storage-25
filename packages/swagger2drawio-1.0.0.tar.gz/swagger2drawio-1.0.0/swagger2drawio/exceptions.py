"""Typed exception hierarchy for swagger2drawio.

All public-facing failures inherit from :class:`Swagger2DrawioError`, so
callers (including the CLI) can either catch the base type for blanket
handling or one of the specific subclasses for granular control.

Each subclass corresponds to a stage of the pipeline:

* :class:`SpecLoadError`       — file / URL fetch failures.
* :class:`SpecParseError`      — malformed JSON / YAML or version detection.
* :class:`SpecValidationError` — fails OpenAPI / Swagger schema validation.
* :class:`LayoutError`         — graph construction or layout computation.
* :class:`RenderError`         — drawpyo / XML emission failures.
* :class:`ConfigError`         — bad theme or config YAML.

The CLI maps each category to a distinct non-zero exit code so that
shell scripts can react differently to a network failure vs. a malformed
spec — see :mod:`swagger2drawio.cli`.
"""

from __future__ import annotations


class Swagger2DrawioError(Exception):
    """Base class for every error raised by this package."""


class SpecLoadError(Swagger2DrawioError):
    """Raised when the spec file or URL cannot be read."""


class SpecParseError(Swagger2DrawioError):
    """Raised when the spec content cannot be decoded as JSON / YAML."""


class SpecValidationError(Swagger2DrawioError):
    """Raised when the spec fails OpenAPI / Swagger schema validation."""


class LayoutError(Swagger2DrawioError):
    """Raised when graph construction or layout computation fails."""


class RenderError(Swagger2DrawioError):
    """Raised when the Draw.io XML cannot be emitted."""


class ConfigError(Swagger2DrawioError):
    """Raised when the user-supplied theme / config YAML is invalid."""


EXIT_CODE: dict[type[Swagger2DrawioError], int] = {
    SpecLoadError: 2,
    SpecParseError: 3,
    SpecValidationError: 4,
    LayoutError: 5,
    RenderError: 6,
    ConfigError: 7,
    Swagger2DrawioError: 1,
}
"""Mapping from exception class to the CLI exit code it should produce.

Exit codes are stable contract: do not renumber once a release is out.
``Swagger2DrawioError`` (code 1) is the fallback for the bare base.
"""
