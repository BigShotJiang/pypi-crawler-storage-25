# kelviq_sdk/enums.py
"""
Enum helpers for the Kelviq SDK.

Provides standard Python Enum classes for required string parameters,
improving developer experience and preventing typos.
"""

from enum import Enum


class ChargePeriod(str, Enum):
    """The billing cycle for a subscription or checkout session."""
    ONE_TIME = "ONE_TIME"
    MONTHLY = "MONTHLY"
    YEARLY = "YEARLY"
    WEEKLY = "WEEKLY"
    DAILY = "DAILY"
    THREE_MONTHS = "THREE_MONTHS"
    SIX_MONTHS = "SIX_MONTHS"


class CancellationType(str, Enum):
    """The type of subscription cancellation to perform."""
    IMMEDIATE = "IMMEDIATE"
    CURRENT_PERIOD_ENDS = "CURRENT_PERIOD_ENDS"
    SPECIFIC_DATE = "SPECIFIC_DATE"
