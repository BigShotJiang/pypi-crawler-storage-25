# kelviq_sdk/models/entitlements.py
from typing import Optional, List, Dict, Any, Literal
from pydantic import BaseModel, Field, ConfigDict
import datetime


class CheckEntitlementsPayload(BaseModel):
    """
    Payload for checking customer entitlements.
    """
    customerId: str = Field(..., description="The ID of the customer whose entitlements are being checked.")
    featureId: Optional[str] = Field(None, description="Optional. A specific feature ID to check entitlements for.")

    model_config = ConfigDict(extra='forbid')


class EntitlementDetail(BaseModel):
    """
    Represents a single raw entitlement entry for a feature, as returned by the API.
    Uses the exact keys returned by the backend: featureId, featureType, currentUsage, usageLimit.
    """
    featureId: str = Field(..., description="The ID of the feature.")
    featureType: Optional[str] = Field(None, description="The type of the feature (e.g., METER, BOOLEAN, CUSTOMIZABLE).")
    hasAccess: bool = Field(..., description="Whether the customer has access to this feature.")
    resetAt: Optional[str] = Field(None,
                         description="Timestamp indicating when the usage for this feature resets. Null if not applicable.")
    hardLimit: Optional[bool] = Field(None, description="Indicates if the usage limit is a hard limit.")
    usageLimit: Optional[int] = Field(None,
                                        description="The configured usage limit for the feature. Null if not applicable (e.g., for BOOLEAN features).")
    currentUsage: Optional[int] = Field(None,
                                          description="The current usage recorded for the feature. Null if not applicable.")
    remaining: Optional[int] = Field(None,
                                       description="The remaining usage allowed for the feature. Null if not applicable.")

    model_config = ConfigDict(
        extra='ignore',
        use_enum_values=True
    )


class Entitlement(BaseModel):
    """
    Represents an aggregated entitlement for a feature.

    If the customer has multiple subscriptions, there can be multiple raw entries for the same
    featureId. The SDK aggregates these into a single model and keeps the raw entries accessible
    via the `items` attribute.

    Aggregation logic:
    - For METER types: usageLimit and currentUsage are summed across items.
    - hasAccess: True if any item grants access.
    - remaining: computed from the aggregated usageLimit - currentUsage.
    - hardLimit: True if any item has a hard limit.
    - resetAt is not aggregated — each item may have a different reset date, so access it via items.
    """
    featureId: str = Field(..., description="The ID of the feature.")
    featureType: Optional[str] = Field(None, description="The type of the feature (e.g., METER, BOOLEAN, CUSTOMIZABLE).")
    hasAccess: bool = Field(..., description="Whether the customer has access to this feature (True if any item grants access).")
    hardLimit: Optional[bool] = Field(None, description="True if any item has a hard limit.")
    usageLimit: Optional[int] = Field(None, description="Aggregated usage limit (summed for METER types).")
    currentUsage: Optional[int] = Field(None, description="Aggregated current usage (summed for METER types).")
    remaining: Optional[int] = Field(None, description="Aggregated remaining usage.")
    items: List[EntitlementDetail] = Field(..., description="The raw entitlement entries that were aggregated into this model.")

    model_config = ConfigDict(extra='ignore')


class CheckEntitlementsResponse(BaseModel):
    """
    Response for the check entitlements operation.
    Returns the raw API response without aggregation.
    """
    customerId: str = Field(..., description="The ID of the customer.")
    entitlements: List[EntitlementDetail] = Field(..., description="A list of raw entitlements for the customer.")

    model_config = ConfigDict(extra='ignore')
