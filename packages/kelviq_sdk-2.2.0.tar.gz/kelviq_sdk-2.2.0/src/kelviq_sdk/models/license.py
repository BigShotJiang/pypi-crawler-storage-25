# kelviq_sdk/models/license.py
from typing import Optional, Dict, Any
from pydantic import BaseModel, Field, ConfigDict

from .subscription import SubscriptionData


class LicenseCustomer(BaseModel):
    customerId: str = Field(..., description="External customer ID.")
    name: Optional[str] = Field(None, description="Customer name.")
    email: Optional[str] = Field(None, description="Customer email.")

    model_config = ConfigDict(extra='ignore')


class LicensePlanProduct(BaseModel):
    id: str = Field(..., description="UUID of the product.")
    identifier: str = Field(..., description="Product identifier.")
    name: str = Field(..., description="Product name.")
    taxCode: Optional[str] = Field(None, description="Tax code for the product.")
    createdOn: Optional[str] = Field(None, description="ISO 8601 datetime the product was created.")
    modifiedOn: Optional[str] = Field(None, description="ISO 8601 datetime the product was last modified.")

    model_config = ConfigDict(extra='ignore')


class LicensePlan(BaseModel):
    identifier: str = Field(..., description="Plan identifier.")
    name: Optional[str] = Field(None, description="Plan name.")
    description: Optional[str] = Field(None, description="Plan description.")
    product: Optional[LicensePlanProduct] = Field(None, description="Product this plan belongs to.")
    version: Optional[int] = Field(None, description="Plan version number.")
    isLatest: Optional[bool] = Field(None, description="Whether this is the latest version of the plan.")

    model_config = ConfigDict(extra='ignore')


class LicenseDetails(BaseModel):
    id: str = Field(..., description="UUID of the license.")
    licenseKey: str = Field(..., description="The license key.")
    activatedOn: Optional[str] = Field(None, description="Datetime the license was first activated.")
    expiresOn: Optional[str] = Field(None, description="Datetime the license expires.")
    activationUsage: int = Field(..., description="Number of active instances.")
    activationLimit: int = Field(..., description="Maximum allowed activations.")
    enabled: bool = Field(..., description="Whether the license is enabled.")
    customer: Optional[LicenseCustomer] = Field(None, description="Customer associated with the license.")
    plan: Optional[LicensePlan] = Field(None, description="Plan associated with the license.")
    subscription: Optional[SubscriptionData] = Field(None, description="Subscription associated with the license.")

    model_config = ConfigDict(extra='ignore')


class LicenseActivatePayload(BaseModel):
    licenseKey: str = Field(..., min_length=1, alias="license_key", description="The license key to activate.")
    customerId: Optional[str] = Field(None, alias="customer_id", description="External customer ID.")
    instanceName: Optional[str] = Field(None, alias="instance_name", description="Name for this instance.")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Additional metadata.")

    model_config = ConfigDict(extra='forbid', populate_by_name=True)


class LicenseActivateResponse(BaseModel):
    instanceId: str = Field(..., description="UUID of the activated instance.")
    activatedAt: str = Field(..., description="Datetime the instance was activated.")
    expiresOn: Optional[str] = Field(None, description="Datetime the license expires.")
    license: LicenseDetails = Field(..., description="The license details.")

    model_config = ConfigDict(extra='ignore')


class LicenseDeactivatePayload(BaseModel):
    licenseKey: str = Field(..., alias="license_key", description="The license key to deactivate.")
    instanceId: str = Field(..., alias="instance_id", description="UUID of the instance to deactivate.")

    model_config = ConfigDict(extra='forbid', populate_by_name=True)


class LicenseDeactivateResponse(BaseModel):
    message: str = Field(..., description="Confirmation message.")
    deactivatedAt: str = Field(..., description="Datetime the instance was deactivated.")

    model_config = ConfigDict(extra='ignore')


class LicenseValidatePayload(BaseModel):
    licenseKey: str = Field(..., alias="license_key", description="The license key to validate.")
    instanceId: Optional[str] = Field(None, alias="instance_id", description="UUID of the instance to validate.")

    model_config = ConfigDict(extra='forbid', populate_by_name=True)


class LicenseValidateResponse(BaseModel):
    valid: bool = Field(..., description="Whether the license is valid.")
    code: str = Field(..., description="Validation result code.")
    detail: str = Field(..., description="Human-readable validation detail.")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Additional metadata from validation.")
    license: Optional[LicenseDetails] = Field(None, description="The license details if valid.")

    model_config = ConfigDict(extra='ignore')
