# kelviq_sdk/models/__init__.py
"""
Pydantic Models for the Kelviq SDK.

This package contains Pydantic models used for data validation,
serialization, and deserialization for API requests and responses.
"""

# Import models from submodules to make them accessible
# directly from kelviq_sdk.models
# e.g., from kelviq_sdk.models import ReportUsagePayload

from .reporting import (
    BaseResponse,
    ReportUsagePayload,
    ReportUsageResponse,
    ReportEventPayload,
    ReportEventResponse,
)

from .entitlements import (
    EntitlementDetail,
    Entitlement,
    CheckEntitlementsResponse,
)

from .portal import (
    CreatePortalSessionPayload,
    CreatePortalSessionResponse,
)

from .subscription import (
    SubscriptionData,
    CancelSubscriptionPayload,
    CancelSubscriptionResponse,
    UpdateSubscriptionPayload,
    UpdateSubscriptionResponse,
)

from .license import (
    LicenseCustomer,
    LicensePlan,
    LicenseDetails,
    LicenseActivatePayload,
    LicenseActivateResponse,
    LicenseDeactivatePayload,
    LicenseDeactivateResponse,
    LicenseValidatePayload,
    LicenseValidateResponse,
)

__all__ = [
    "BaseResponse",
    "ReportUsagePayload",
    "ReportUsageResponse",
    "ReportEventPayload",
    "ReportEventResponse",
    "EntitlementDetail",
    "Entitlement",
    "CheckEntitlementsResponse",
    "CreatePortalSessionPayload",
    "CreatePortalSessionResponse",
    "SubscriptionData",
    "CancelSubscriptionPayload",
    "CancelSubscriptionResponse",
    "UpdateSubscriptionPayload",
    "UpdateSubscriptionResponse",
    "LicenseCustomer",
    "LicensePlan",
    "LicenseDetails",
    "LicenseActivatePayload",
    "LicenseActivateResponse",
    "LicenseDeactivatePayload",
    "LicenseDeactivateResponse",
    "LicenseValidatePayload",
    "LicenseValidateResponse",
]
