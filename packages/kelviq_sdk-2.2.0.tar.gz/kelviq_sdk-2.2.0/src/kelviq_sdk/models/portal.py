# kelviq_sdk/models/portal.py
from pydantic import BaseModel, Field, ConfigDict


class CreatePortalSessionPayload(BaseModel):
    """
    Pydantic model for the payload to create a customer portal session.
    """
    customerId: str = Field(
        ...,
        description="The unique identifier of the customer for whom the portal session is being created."
    )

    model_config = ConfigDict(
        extra='forbid',
    )


class CreatePortalSessionResponse(BaseModel):
    """
    Pydantic model for the response when a customer portal session is created.
    """
    token: str = Field(..., description="The session token for authenticating the customer portal session.")
    email: str = Field(..., description="The email address of the customer.")
    customerPortalUrl: str = Field(..., description="The URL to redirect the customer to their billing portal.")

    model_config = ConfigDict(
        extra='ignore',
    )
