# kelviq_sdk/portal.py

from typing import TYPE_CHECKING

from .models.portal import (
    CreatePortalSessionPayload,
    CreatePortalSessionResponse,
)
from .exceptions import InvalidRequestError
from pydantic import ValidationError

if TYPE_CHECKING:
    from .client import Kelviq

# Define the base path for portal-related endpoints.
PORTAL_MODULE_PREFIX = "/portal"


class PortalSyncOperations:
    """
    Handles synchronous 'portal' related API operations.
    """

    def __init__(self, main_client: 'Kelviq'):
        self._main_client = main_client
        self._main_client.logger.debug("PortalSyncOperations initialized.")

    def create_session(
            self,
            customerId: str,
    ) -> CreatePortalSessionResponse:
        """
        Creates a new customer portal session synchronously.
        The API endpoint is POST /api/{version}/portal/session/
        """
        endpoint_module_path = f"{PORTAL_MODULE_PREFIX}/session/"

        logger = self._main_client.logger
        logger.info(
            f"Initiating synchronous create_portal_session for customerId: {customerId}"
        )

        try:
            payload_model = CreatePortalSessionPayload(customerId=customerId)
            logger.debug(
                f"Create portal session payload validated: {payload_model.model_dump_json(exclude_none=True)}")
        except ValidationError as e:
            logger.warning(
                f"Pydantic validation failed for create_portal_session. customerId: {customerId}, "
                f"Errors: {e.errors(include_context=False)}"
            )
            raise InvalidRequestError(
                message="Invalid parameters for create_portal_session",
                details=e.errors(include_context=False)
            ) from e

        request_data = payload_model.model_dump(exclude_none=True)

        response_dict = self._main_client._request(
            method="POST",
            endpoint_module_path=endpoint_module_path,
            data=request_data
        )
        return CreatePortalSessionResponse.model_validate(response_dict)


class PortalAsyncOperations:
    """
    Handles asynchronous 'portal' related API operations.
    """

    def __init__(self, main_client: 'Kelviq'):
        self._main_client = main_client
        self._main_client.logger.debug("PortalAsyncOperations initialized.")

    async def create_session(
            self,
            customerId: str,
    ) -> CreatePortalSessionResponse:
        """
        Creates a new customer portal session asynchronously.
        The API endpoint is POST /api/{version}/portal/session/
        """
        endpoint_module_path = f"{PORTAL_MODULE_PREFIX}/session/"

        logger = self._main_client.logger
        logger.info(
            f"Initiating asynchronous create_portal_session for customerId: {customerId}"
        )

        try:
            payload_model = CreatePortalSessionPayload(customerId=customerId)
            logger.debug(
                f"Create async portal session payload validated: {payload_model.model_dump_json(exclude_none=True)}")
        except ValidationError as e:
            logger.warning(
                f"Pydantic validation failed for async create_portal_session. customerId: {customerId}, "
                f"Errors: {e.errors(include_context=False)}"
            )
            raise InvalidRequestError(
                message="Invalid parameters for async create_portal_session",
                details=e.errors(include_context=False)
            ) from e

        request_data = payload_model.model_dump(exclude_none=True)

        response_dict = await self._main_client._async_request(
            method="POST",
            endpoint_module_path=endpoint_module_path,
            data=request_data
        )
        return CreatePortalSessionResponse.model_validate(response_dict)
