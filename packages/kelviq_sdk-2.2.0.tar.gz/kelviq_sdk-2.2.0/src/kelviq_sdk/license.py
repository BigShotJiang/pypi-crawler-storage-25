# kelviq_sdk/license.py

from typing import TYPE_CHECKING, Dict, Any, Optional

from . import logger
from .models.license import (
    LicenseActivatePayload,
    LicenseActivateResponse,
    LicenseDeactivatePayload,
    LicenseDeactivateResponse,
    LicenseValidatePayload,
    LicenseValidateResponse,
)
from .exceptions import InvalidRequestError
from pydantic import ValidationError

if TYPE_CHECKING:
    from .client import Kelviq

LICENSE_MODULE_PREFIX = "/license"


class LicenseSyncOperations:
    """Handles synchronous license API operations."""

    def __init__(self, main_client: 'Kelviq'):
        self._main_client = main_client
        self._main_client.logger.debug("LicenseSyncOperations initialized.")

    def activate(
            self,
            licenseKey: str,
            customerId: Optional[str] = None,
            instanceName: Optional[str] = None,
            metadata: Optional[Dict[str, Any]] = None,
    ) -> LicenseActivateResponse:
        """
        Activates a license key, creating a new instance.
        API endpoint: POST /api/{version}/license/activate/
        """
        self._main_client.logger.info(f"Activating license: {licenseKey}")
        try:
            payload_model = LicenseActivatePayload(
                licenseKey=licenseKey,
                customerId=customerId,
                instanceName=instanceName,
                metadata=metadata,
            )
        except ValidationError as e:
            raise InvalidRequestError("Invalid parameters for license activation", details=e.errors(include_context=False)) from e
        request_data = payload_model.model_dump(exclude_none=True, by_alias=True)
        response_dict = self._main_client._request(method="POST", endpoint_module_path=f"{LICENSE_MODULE_PREFIX}/activate/", data=request_data)
        return LicenseActivateResponse.model_validate(response_dict)

    def deactivate(
            self,
            licenseKey: str,
            instanceId: str,
    ) -> LicenseDeactivateResponse:
        """
        Deactivates a specific license instance.
        API endpoint: POST /api/{version}/license/deactivate/
        """
        self._main_client.logger.info(f"Deactivating license: {licenseKey}, instance: {instanceId}")
        try:
            payload_model = LicenseDeactivatePayload(licenseKey=licenseKey, instanceId=instanceId)
        except ValidationError as e:
            raise InvalidRequestError("Invalid parameters for license deactivation", details=e.errors(include_context=False)) from e
        request_data = payload_model.model_dump(exclude_none=True, by_alias=True)
        response_dict = self._main_client._request(method="POST", endpoint_module_path=f"{LICENSE_MODULE_PREFIX}/deactivate/", data=request_data)
        return LicenseDeactivateResponse.model_validate(response_dict)

    def validate(
            self,
            licenseKey: str,
            instanceId: Optional[str] = None,
    ) -> LicenseValidateResponse:
        """
        Validates a license key, optionally checking a specific instance.
        API endpoint: POST /api/{version}/license/validate/
        """
        self._main_client.logger.info(f"Validating license: {licenseKey}")
        try:
            payload_model = LicenseValidatePayload(licenseKey=licenseKey, instanceId=instanceId)
        except ValidationError as e:
            raise InvalidRequestError("Invalid parameters for license validation", details=e.errors(include_context=False)) from e
        request_data = payload_model.model_dump(exclude_none=True, by_alias=True)
        response_dict = self._main_client._request(method="POST", endpoint_module_path=f"{LICENSE_MODULE_PREFIX}/validate/", data=request_data)
        return LicenseValidateResponse.model_validate(response_dict)


class LicenseAsyncOperations:
    """Handles asynchronous license API operations."""

    def __init__(self, main_client: 'Kelviq'):
        self._main_client = main_client
        self._main_client.logger.debug("LicenseAsyncOperations initialized.")

    async def activate(
            self,
            licenseKey: str,
            customerId: Optional[str] = None,
            instanceName: Optional[str] = None,
            metadata: Optional[Dict[str, Any]] = None,
    ) -> LicenseActivateResponse:
        """
        Activates a license key, creating a new instance.
        API endpoint: POST /api/{version}/license/activate/
        """
        self._main_client.logger.info(f"Activating license: {licenseKey}")
        try:
            payload_model = LicenseActivatePayload(
                licenseKey=licenseKey,
                customerId=customerId,
                instanceName=instanceName,
                metadata=metadata,
            )
        except ValidationError as e:
            raise InvalidRequestError("Invalid parameters for license activation", details=e.errors(include_context=False)) from e
        request_data = payload_model.model_dump(exclude_none=True, by_alias=True)
        response_dict = await self._main_client._async_request(method="POST", endpoint_module_path=f"{LICENSE_MODULE_PREFIX}/activate/", data=request_data)
        return LicenseActivateResponse.model_validate(response_dict)

    async def deactivate(
            self,
            licenseKey: str,
            instanceId: str,
    ) -> LicenseDeactivateResponse:
        """
        Deactivates a specific license instance.
        API endpoint: POST /api/{version}/license/deactivate/
        """
        self._main_client.logger.info(f"Deactivating license: {licenseKey}, instance: {instanceId}")
        try:
            payload_model = LicenseDeactivatePayload(licenseKey=licenseKey, instanceId=instanceId)
        except ValidationError as e:
            raise InvalidRequestError("Invalid parameters for license deactivation", details=e.errors(include_context=False)) from e
        request_data = payload_model.model_dump(exclude_none=True, by_alias=True)
        response_dict = await self._main_client._async_request(method="POST", endpoint_module_path=f"{LICENSE_MODULE_PREFIX}/deactivate/", data=request_data)
        return LicenseDeactivateResponse.model_validate(response_dict)

    async def validate(
            self,
            licenseKey: str,
            instanceId: Optional[str] = None,
    ) -> LicenseValidateResponse:
        """
        Validates a license key, optionally checking a specific instance.
        API endpoint: POST /api/{version}/license/validate/
        """
        self._main_client.logger.info(f"Validating license: {licenseKey}")
        try:
            payload_model = LicenseValidatePayload(licenseKey=licenseKey, instanceId=instanceId)
        except ValidationError as e:
            raise InvalidRequestError("Invalid parameters for license validation", details=e.errors(include_context=False)) from e
        request_data = payload_model.model_dump(exclude_none=True, by_alias=True)
        response_dict = await self._main_client._async_request(method="POST", endpoint_module_path=f"{LICENSE_MODULE_PREFIX}/validate/", data=request_data)
        return LicenseValidateResponse.model_validate(response_dict)
