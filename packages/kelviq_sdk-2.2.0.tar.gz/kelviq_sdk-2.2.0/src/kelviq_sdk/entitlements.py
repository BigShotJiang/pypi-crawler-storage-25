# kelviq_sdk/entitlements.py

from typing import TYPE_CHECKING, Dict, Any, Optional, List
from collections import defaultdict

from . import logger, APIError

from .models.entitlements import (
    CheckEntitlementsPayload,
    CheckEntitlementsResponse,
    EntitlementDetail,
    Entitlement,
)
from .exceptions import InvalidRequestError
from pydantic import ValidationError

if TYPE_CHECKING:
    from .client import Kelviq  # Main client class

ENTITLEMENTS_MODULE_PREFIX = "/entitlements"


def _aggregate_entitlements(raw_entitlements: List[EntitlementDetail]) -> Dict[str, Entitlement]:
    """
    Aggregates raw entitlement entries by featureId.

    For METER types: sums usageLimit and currentUsage across items.
    For hasAccess: True if any item grants access.
    For hardLimit: True if any item has a hard limit.
    resetAt is NOT aggregated — each item may have a different reset date.

    Returns a dict keyed by featureId.
    """
    grouped: Dict[str, List[EntitlementDetail]] = defaultdict(list)
    for entry in raw_entitlements:
        grouped[entry.featureId].append(entry)

    aggregated: Dict[str, Entitlement] = {}
    for feature_id, items in grouped.items():
        feature_type = items[0].featureType

        if feature_type == "METER":
            usage_limit = sum(
                item.usageLimit for item in items if item.usageLimit is not None
            ) if any(item.usageLimit is not None for item in items) else None

            current_usage = sum(
                item.currentUsage for item in items if item.currentUsage is not None
            ) if any(item.currentUsage is not None for item in items) else None

            if usage_limit is not None and current_usage is not None:
                remaining = usage_limit - current_usage
            else:
                remaining = None

            hard_limit_val: Optional[bool] = False
            for item in items:
                if item.hardLimit is True:
                    hard_limit_val = True
                    break

            has_access = remaining is None or remaining > 0
        elif feature_type == "CUSTOMIZABLE":
            # Use first item's values (config value like retention days — not summed)
            first = items[0]
            usage_limit = first.usageLimit
            current_usage = first.currentUsage if first.currentUsage is not None else 0
            remaining = first.remaining
            hard_limit_val = first.hardLimit is True
            has_access = any(item.hasAccess for item in items)
        else:
            # BOOLEAN — no metered fields
            usage_limit = None
            current_usage = 0
            remaining = None
            hard_limit_val = False
            has_access = any(item.hasAccess for item in items)

        aggregated[feature_id] = Entitlement(
            featureId=feature_id,
            featureType=feature_type,
            hasAccess=has_access,
            hardLimit=hard_limit_val,
            usageLimit=usage_limit,
            currentUsage=current_usage,
            remaining=remaining,
            items=items,
        )

    return aggregated


class EntitlementsSyncOperations:
    """
    Handles synchronous 'entitlements' related API operations.
    """

    def __init__(self, main_client: 'Kelviq'):
        self._main_client = main_client
        self._main_client.logger.debug("EntitlementsSyncOperations initialized.")

    def has_access(
            self,
            customerId: str,
            featureId: str
    ) -> bool:
        """
        Checks if a customer has access to a specific feature, synchronously.
        Returns True if access is granted, False otherwise.
        This operation targets the EDGE_API_URL.
        """
        self._main_client.logger.info(
            f"Initiating synchronous entitlements check (has_access) for customerId: {customerId}, featureId: {featureId}"
        )

        entitlement = self.get_entitlement(customerId=customerId, featureId=featureId)

        if entitlement is None:
            self._main_client.logger.warning(
                f"FeatureId '{featureId}' not found in entitlements response for customerId: {customerId}. Returning hasAccess=False.")
            return False

        self._main_client.logger.info(
            f"Access check for customerId: {customerId}, featureId: {featureId} - Result: {entitlement.hasAccess}"
        )
        return entitlement.hasAccess

    def get_entitlement(
            self,
            customerId: str,
            featureId: str
    ) -> Optional[Entitlement]:
        """
        Retrieves a single aggregated entitlement for a specific feature, synchronously.
        Returns an aggregated Entitlement model with an `.items` list containing all raw
        entries for that featureId, or None if the feature is not found.
        This operation targets the EDGE_API_URL.
        """
        endpoint_module_path = f"{ENTITLEMENTS_MODULE_PREFIX}"

        self._main_client.logger.info(
            f"Initiating synchronous get_entitlement for customerId: {customerId}, featureId: {featureId}"
        )
        query_params = {
            "customer_id": customerId,
            "feature_id": featureId
        }

        response_dict = self._main_client._request(
            method="GET",
            endpoint_module_path=endpoint_module_path,
            params=query_params,
            base_url_override=self._main_client.edge_api_url_to_use
        )
        response_model = CheckEntitlementsResponse.model_validate(response_dict)
        aggregated = _aggregate_entitlements(response_model.entitlements)
        return aggregated.get(featureId)

    def get_entitlements(
            self,
            customerId: str
    ) -> Dict[str, Entitlement]:
        """
        Retrieves all entitlements for a given customer, synchronously.
        Returns a dict keyed by featureId where each value is an aggregated
        Entitlement model with an `.items` list containing the raw entries.
        This operation targets the EDGE_API_URL.
        """
        endpoint_module_path = f"{ENTITLEMENTS_MODULE_PREFIX}"

        query_params = {
            "customer_id": customerId
        }

        self._main_client.logger.info(
            f"Initiating synchronous get_entitlements for customerId: {customerId}"
        )

        response_dict = self._main_client._request(
            method="GET",
            endpoint_module_path=endpoint_module_path,
            params=query_params,
            base_url_override=self._main_client.edge_api_url_to_use
        )
        response_model = CheckEntitlementsResponse.model_validate(response_dict)
        return _aggregate_entitlements(response_model.entitlements)

    def get_raw_entitlement(
            self,
            customerId: str,
            featureId: str
    ) -> CheckEntitlementsResponse:
        """
        Retrieves the raw entitlement response for a specific feature, synchronously.
        Returns the API response as-is with the customerId wrapper.
        This operation targets the EDGE_API_URL.
        """
        endpoint_module_path = f"{ENTITLEMENTS_MODULE_PREFIX}"

        self._main_client.logger.info(
            f"Initiating synchronous get_raw_entitlement for customerId: {customerId}, featureId: {featureId}"
        )
        query_params = {
            "customer_id": customerId,
            "feature_id": featureId
        }

        response_dict = self._main_client._request(
            method="GET",
            endpoint_module_path=endpoint_module_path,
            params=query_params,
            base_url_override=self._main_client.edge_api_url_to_use
        )
        return CheckEntitlementsResponse.model_validate(response_dict)

    def get_raw_entitlements(
            self,
            customerId: str
    ) -> CheckEntitlementsResponse:
        """
        Retrieves all raw entitlements for a given customer, synchronously.
        Returns the API response as-is with the customerId wrapper.
        This operation targets the EDGE_API_URL.
        """
        endpoint_module_path = f"{ENTITLEMENTS_MODULE_PREFIX}"

        query_params = {
            "customer_id": customerId
        }

        self._main_client.logger.info(
            f"Initiating synchronous get_raw_entitlements for customerId: {customerId}"
        )

        response_dict = self._main_client._request(
            method="GET",
            endpoint_module_path=endpoint_module_path,
            params=query_params,
            base_url_override=self._main_client.edge_api_url_to_use
        )
        return CheckEntitlementsResponse.model_validate(response_dict)


class EntitlementsAsyncOperations:
    """
    Handles asynchronous 'entitlements' related API operations.
    """

    def __init__(self, main_client: 'Kelviq'):
        self._main_client = main_client
        self._main_client.logger.debug("EntitlementsAsyncOperations initialized.")

    async def has_access(
            self,
            customerId: str,
            featureId: str
    ) -> bool:
        """
        Checks if a customer has access to a specific feature, asynchronously.
        Returns True if access is granted, False otherwise.
        This operation targets the EDGE_API_URL.
        """

        self._main_client.logger.info(
            f"Initiating asynchronous entitlements check (has_access) for customerId: {customerId}, featureId: {featureId}"
        )

        entitlement = await self.get_entitlement(customerId=customerId, featureId=featureId)

        if entitlement is None:
            self._main_client.logger.warning(
                f"FeatureId '{featureId}' not found in entitlements response for customerId: {customerId}. Returning hasAccess=False.")
            return False

        self._main_client.logger.info(
            f"Access check for customerId: {customerId}, featureId: {featureId} - Result: {entitlement.hasAccess}"
        )
        return entitlement.hasAccess

    async def get_entitlement(
            self,
            customerId: str,
            featureId: str
    ) -> Optional[Entitlement]:
        """
        Retrieves a single aggregated entitlement for a specific feature, asynchronously.
        Returns an aggregated Entitlement model with an `.items` list containing all raw
        entries for that featureId, or None if the feature is not found.
        This operation targets the EDGE_API_URL.
        """
        endpoint_module_path = f"{ENTITLEMENTS_MODULE_PREFIX}"

        self._main_client.logger.info(
            f"Initiating asynchronous get_entitlement for customerId: {customerId}, featureId: {featureId}"
        )

        query_params = {
            "customer_id": customerId,
            "feature_id": featureId
        }

        response_dict = await self._main_client._async_request(
            method="GET",
            endpoint_module_path=endpoint_module_path,
            params=query_params,
            base_url_override=self._main_client.edge_api_url_to_use
        )
        response_model = CheckEntitlementsResponse.model_validate(response_dict)
        aggregated = _aggregate_entitlements(response_model.entitlements)
        return aggregated.get(featureId)

    async def get_entitlements(
            self,
            customerId: str
    ) -> Dict[str, Entitlement]:
        """
        Retrieves all entitlements for a given customer, asynchronously.
        Returns a dict keyed by featureId where each value is an aggregated
        Entitlement model with an `.items` list containing the raw entries.
        This operation targets the EDGE_API_URL.
        """
        endpoint_module_path = f"{ENTITLEMENTS_MODULE_PREFIX}"

        self._main_client.logger.info(
            f"Initiating asynchronous get_entitlements for customerId: {customerId}"
        )

        query_params = {
            "customer_id": customerId
        }

        response_dict = await self._main_client._async_request(
            method="GET",
            endpoint_module_path=endpoint_module_path,
            params=query_params,
            base_url_override=self._main_client.edge_api_url_to_use
        )
        response_model = CheckEntitlementsResponse.model_validate(response_dict)
        return _aggregate_entitlements(response_model.entitlements)

    async def get_raw_entitlement(
            self,
            customerId: str,
            featureId: str
    ) -> CheckEntitlementsResponse:
        """
        Retrieves the raw entitlement response for a specific feature, asynchronously.
        Returns the API response as-is with the customerId wrapper.
        This operation targets the EDGE_API_URL.
        """
        endpoint_module_path = f"{ENTITLEMENTS_MODULE_PREFIX}"

        self._main_client.logger.info(
            f"Initiating asynchronous get_raw_entitlement for customerId: {customerId}, featureId: {featureId}"
        )

        query_params = {
            "customer_id": customerId,
            "feature_id": featureId
        }

        response_dict = await self._main_client._async_request(
            method="GET",
            endpoint_module_path=endpoint_module_path,
            params=query_params,
            base_url_override=self._main_client.edge_api_url_to_use
        )
        return CheckEntitlementsResponse.model_validate(response_dict)

    async def get_raw_entitlements(
            self,
            customerId: str
    ) -> CheckEntitlementsResponse:
        """
        Retrieves all raw entitlements for a given customer, asynchronously.
        Returns the API response as-is with the customerId wrapper.
        This operation targets the EDGE_API_URL.
        """
        endpoint_module_path = f"{ENTITLEMENTS_MODULE_PREFIX}"

        self._main_client.logger.info(
            f"Initiating asynchronous get_raw_entitlements for customerId: {customerId}"
        )

        query_params = {
            "customer_id": customerId
        }

        response_dict = await self._main_client._async_request(
            method="GET",
            endpoint_module_path=endpoint_module_path,
            params=query_params,
            base_url_override=self._main_client.edge_api_url_to_use
        )
        return CheckEntitlementsResponse.model_validate(response_dict)
