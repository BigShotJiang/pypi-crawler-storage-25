"""
@FileName: pool.py
@Description: Worker池 - 管理任务执行器，支持预取器
@Author: HiPeng
@Time: 2026/4/8 00:00
"""

import asyncio
import time
from dataclasses import dataclass
from datetime import datetime
from typing import Optional, Dict

from neotask.common.logger import debug, warning, error
from neotask.core.lifecycle import TaskLifecycleManager
from neotask.event.bus import EventBus, TaskEvent
from neotask.executor.base import TaskExecutor
from neotask.models.task import TaskStatus
from neotask.queue.queue_scheduler import QueueScheduler
from neotask.storage.base import TaskRepository
from neotask.worker.prefetcher import TaskPrefetcher, PrefetchConfig, PrefetchStrategy


@dataclass
class WorkerStats:
    """Worker统计信息"""
    worker_id: int
    active_tasks: int
    completed_tasks: int = 0
    failed_tasks: int = 0
    last_active: Optional[datetime] = None
    is_busy: bool = False


class WorkerPool:
    """Worker池

    管理多个worker协程，控制并发执行。

    支持两种模式：
    - 预取模式：使用 TaskPrefetcher 批量预取任务到本地队列
    - 直接模式：直接从共享队列获取任务
    """

    def __init__(
            self,
            executor: TaskExecutor,
            task_repo: TaskRepository,
            queue_scheduler: QueueScheduler,
            event_bus: EventBus,
            lifecycle_manager: TaskLifecycleManager,
            concurrency: int = 10,
            prefetch_size: int = 20,
            task_timeout: Optional[float] = None,
            enable_prefetch: bool = True  # 新增：是否启用预取器
    ):
        self._executor = executor
        self._task_repo = task_repo
        self._queue = queue_scheduler
        self._event_bus = event_bus
        self._lifecycle = lifecycle_manager
        self._concurrency = concurrency
        self._prefetch_size = prefetch_size
        self._task_timeout = task_timeout
        self._enable_prefetch = enable_prefetch

        self._workers: Dict[int, asyncio.Task] = {}
        self._running_tasks: Dict[str, asyncio.Task] = {}
        self._worker_stats: Dict[int, WorkerStats] = {}
        self._semaphore = asyncio.Semaphore(concurrency)
        self._running = False
        self._lock = asyncio.Lock()

        # 重试配置
        self._max_retries = 3
        self._retry_delay = 1.0

        # 预取器（仅在启用时创建）
        self._prefetcher: Optional[TaskPrefetcher] = None
        if enable_prefetch:
            prefetch_config = PrefetchConfig(
                prefetch_size=prefetch_size,
                local_queue_size=prefetch_size * 5,
                min_threshold=max(1, prefetch_size // 4),
                max_threshold=prefetch_size * 3,
                enable_batch_pop=True,
                strategy=PrefetchStrategy.HYBRID
            )
            self._prefetcher = TaskPrefetcher(queue_scheduler, prefetch_config)

    async def start(self) -> None:
        """启动worker池"""
        if self._running:
            return

        self._running = True

        # 启动预取器
        if self._prefetcher:
            await self._prefetcher.start()
            debug(f"Prefetcher started with size={self._prefetcher._config.prefetch_size}")

        # 启动所有worker
        for i in range(self._concurrency):
            worker_task = asyncio.create_task(self._worker_loop(i))
            self._workers[i] = worker_task
            self._worker_stats[i] = WorkerStats(worker_id=i, active_tasks=0)

        debug(f"Started {self._concurrency} workers (prefetch={self._enable_prefetch})")

    async def stop(self, graceful: bool = True, timeout: float = 30) -> None:
        """停止worker池

        Args:
            graceful: 是否优雅停止（等待当前任务完成）
            timeout: 优雅停止超时时间
        """
        self._running = False

        # 停止预取器
        if self._prefetcher:
            await self._prefetcher.stop(graceful, timeout)

        if graceful and self._running_tasks:
            # 等待当前任务完成
            try:
                await asyncio.wait_for(
                    asyncio.gather(*self._running_tasks.values(), return_exceptions=True),
                    timeout=timeout
                )
            except asyncio.TimeoutError:
                # 超时后强制取消
                for task in self._running_tasks.values():
                    if not task.done():
                        task.cancel()

        # 取消所有worker
        for worker_id, worker_task in self._workers.items():
            if not worker_task.done():
                worker_task.cancel()

        # 等待worker完成
        if self._workers:
            await asyncio.gather(*self._workers.values(), return_exceptions=True)

        self._workers.clear()
        self._running_tasks.clear()
        debug("All workers stopped")

    async def cancel_task(self, task_id: str) -> bool:
        """取消运行中的任务"""
        if task_id in self._running_tasks:
            self._running_tasks[task_id].cancel()
            return True
        return False

    def active_count(self) -> int:
        """获取活跃worker数量"""
        return len(self._running_tasks)

    def get_stats(self) -> Dict[int, WorkerStats]:
        """获取worker统计信息"""
        stats = self._worker_stats.copy()

        # 添加预取器统计
        # if self._prefetcher:
        #     stats[0] = self._prefetcher.get_stats()

        return stats

    def set_retry_config(self, max_retries: int, retry_delay: float) -> None:
        """设置重试配置"""
        self._max_retries = max_retries
        self._retry_delay = retry_delay

    async def _worker_loop(self, worker_id: int) -> None:
        """Worker主循环（支持预取器）"""
        debug(f"Worker {worker_id} started (prefetch={self._enable_prefetch})")
        consecutive_empty = 0

        while self._running:
            try:
                if self._prefetcher:
                    # ========== 预取模式 ==========
                    # 从预取器获取任务（非阻塞）
                    task_id = await self._prefetcher.get(timeout=0.1)

                    if task_id:
                        consecutive_empty = 0
                        # 执行任务
                        exec_task = asyncio.create_task(
                            self._execute_task(worker_id, task_id)
                        )
                        async with self._lock:
                            self._running_tasks[task_id] = exec_task
                            self._worker_stats[worker_id].active_tasks += 1
                            self._worker_stats[worker_id].is_busy = True
                    else:
                        # 没有任务时，指数退避
                        consecutive_empty += 1
                        sleep_time = min(0.01 * (1 << min(consecutive_empty, 6)), 0.5)
                        await asyncio.sleep(sleep_time)
                        continue

                else:
                    # ========== 直接模式（原有逻辑）==========
                    task_ids = await self._queue.pop(self._prefetch_size)

                    if task_ids:
                        consecutive_empty = 0
                        for task_id in task_ids:
                            exec_task = asyncio.create_task(
                                self._execute_task(worker_id, task_id)
                            )
                            async with self._lock:
                                self._running_tasks[task_id] = exec_task
                                self._worker_stats[worker_id].active_tasks += 1
                                self._worker_stats[worker_id].is_busy = True
                    else:
                        consecutive_empty += 1
                        sleep_time = min(0.01 * (1 << min(consecutive_empty, 6)), 0.5)
                        await asyncio.sleep(sleep_time)
                        continue

                # 清理已完成的任务
                await self._cleanup_completed_tasks()

            except asyncio.CancelledError:
                break
            except Exception as e:
                error(f"Worker {worker_id} error: {e}")
                await asyncio.sleep(0.1)

        debug(f"Worker {worker_id} stopped")


    async def _execute_task(self, worker_id: int, task_id: str) -> None:
        """执行单个任务（支持进度回调）"""
        async with self._semaphore:
            debug(f"Worker {worker_id} executing task {task_id}")

            # 获取任务
            task = await self._lifecycle.get_task(task_id)
            if not task:
                warning(f"Task {task_id} not found")
                return

            # 检查任务状态
            if task.status != TaskStatus.PENDING:
                warning(f"Task {task_id} status is {task.status}, not PENDING, skipping")
                return

            # 开始执行
            success = await self._lifecycle.start_task(task_id, f"worker-{worker_id}")
            if not success:
                error(f"Failed to start task {task_id}")
                return

            # 获取当前重试次数
            current_retry = task.retry_count

            try:
                # 定义进度回调函数
                async def progress_callback(progress: float, message: str = ""):
                    """更新任务进度"""
                    await self._update_task_progress(task_id, progress, message)

                # 检查执行器是否支持进度回调
                if hasattr(self._executor, 'execute_with_progress'):
                    # 使用支持进度的执行方法
                    result = await self._executor.execute_with_progress(task.data, progress_callback)
                else:
                    # 使用标准执行方法
                    if self._task_timeout:
                        result = await asyncio.wait_for(
                            self._executor.execute(task.data),
                            timeout=self._task_timeout
                        )
                    else:
                        result = await self._executor.execute(task.data)
                # ========== 进度回调支持结束 ==========

                # 标记完成
                await self._lifecycle.complete_task(task_id, result)

                # 更新统计
                self._worker_stats[worker_id].completed_tasks += 1
                debug(f"Worker {worker_id} completed task {task_id}")

            except asyncio.CancelledError:
                debug(f"Task {task_id} was cancelled")
                await self._lifecycle.cancel_task(task_id)
                return

            except asyncio.TimeoutError:
                err = f"Task execution timeout after {self._task_timeout}s"
                error(f"Task {task_id} timeout: {err}")
                await self._handle_task_failure(task_id, err, current_retry, worker_id)

            except Exception as e:
                err = str(e)
                error(f"Task {task_id} failed: {err}")
                await self._handle_task_failure(task_id, err, current_retry, worker_id)

            finally:
                # 更新worker统计
                async with self._lock:
                    self._worker_stats[worker_id].active_tasks = max(
                        0, self._worker_stats[worker_id].active_tasks - 1
                    )
                    self._worker_stats[worker_id].is_busy = self._worker_stats[worker_id].active_tasks > 0
                    self._worker_stats[worker_id].last_active = datetime.now()

    async def _update_task_progress(self, task_id: str, progress: float, message: str = "") -> None:
        """更新任务进度

        Args:
            task_id: 任务ID
            progress: 进度 (0.0 - 1.0)
            message: 进度消息
        """
        try:
            # 更新存储中的任务进度
            if hasattr(self._task_repo, 'update_progress'):
                await self._task_repo.update_progress(task_id, progress, message)

            # 发送进度事件
            await self._event_bus.emit(TaskEvent(
                "task.progress",
                task_id,
                {"progress": progress, "message": message, "timestamp": time.time()}
            ))

            debug(f"Task {task_id} progress: {progress * 100:.1f}% - {message}")
        except Exception as e:
            debug(f"Failed to update progress for task {task_id}: {e}")


    async def _handle_task_failure(self, task_id: str, error_msg: str, retry_count: int, worker_id: int) -> None:
        """处理任务失败和重试"""
        # 重新获取最新任务状态
        task = await self._lifecycle.get_task(task_id)
        if not task:
            return

        debug(f"Handling failure for task {task_id}, retry_count={retry_count}, max_retries={self._max_retries}")

        if retry_count < self._max_retries:
            # 需要重试
            new_retry_count = retry_count + 1

            debug(f"Retrying task {task_id} (attempt {new_retry_count}/{self._max_retries})")

            # 更新重试计数，重置状态为 PENDING
            task.retry_count = new_retry_count
            task.error = error_msg
            task.status = TaskStatus.PENDING
            task.node_id = ""
            await self._task_repo.save(task)

            # 更新缓存
            if self._lifecycle._cache_enabled:
                async with self._lifecycle._lock:
                    self._lifecycle._cache[task_id] = task

            # 重新入队（带延迟）
            delay = self._retry_delay * new_retry_count
            await self._queue.push(task_id, task.priority.value, delay=delay)

            # 发送重试事件
            await self._event_bus.emit(TaskEvent(
                "task.retry",
                task_id,
                {"error": error_msg, "retry_count": new_retry_count, "max_retries": self._max_retries}
            ))
        else:
            # 超过最大重试次数，标记为失败
            debug(f"Task {task_id} exceeded max retries ({self._max_retries}), marking as FAILED")
            await self._lifecycle.fail_task(task_id, error_msg)
            self._worker_stats[worker_id].failed_tasks += 1

    async def _cleanup_completed_tasks(self) -> None:
        """清理已完成的任务"""
        async with self._lock:
            completed = [
                (tid, t) for tid, t in self._running_tasks.items()
                if t.done()
            ]

            for task_id, task in completed:
                self._running_tasks.pop(task_id, None)

    # ========== 预取器管理方法 ==========

    async def get_prefetcher_stats(self) -> Optional[Dict]:
        """获取预取器统计信息"""
        if self._prefetcher:
            return self._prefetcher.get_stats()
        return None

    async def reset_prefetcher_stats(self) -> None:
        """重置预取器统计"""
        if self._prefetcher:
            self._prefetcher.reset_stats()

    def is_prefetch_enabled(self) -> bool:
        """检查预取器是否启用"""
        return self._enable_prefetch and self._prefetcher is not None