import numpy as np
import point3d_rigid_match
from solve_rigid_point_set_rt import compute_best_rigid_transform

def listify(arr: np.ndarray) -> list[list[float]]:
    final_ans = []
    for i in range(arr.shape[0]):
        new_arr = []
        for j in range(arr.shape[1]):
            new_arr.append(arr[i, j])
        final_ans.append(new_arr)
    return final_ans

def compute_best_rigid_transform_pro(P: np.ndarray, Q: np.ndarray, assume_p_center_zero:bool=False):
    """
    Compute the optimal 3D rotation matrix R and translation vector t
    that satisfies: Q = R @ P + t (minimum mean square error)
    Parameters:
        P: Source point set, shape (N, 3), N is the number of points
        Q: Target point set, shape (N, 3), in one-to-one correspondence with P
    Returns:
        R: 3x3 optimal rotation matrix
        t: 3x1 optimal translation vector
    """
    # 1. Validate input
    assert P.shape == Q.shape, "The number and dimensions of the two point sets must be identical!"
    assert P.shape[1] == 3, "Must be 3D point coordinates (x,y,z)"
    
    # 2. Compute centroids of the two point sets
    if assume_p_center_zero:
        centroid_P = np.array([0, 0, 0])
    else:
        centroid_P = np.mean(P, axis=0)
    centroid_Q = np.mean(Q, axis=0)
    
    # 3. Center the points (subtract centroids to eliminate translation effect)
    P_centered = P - centroid_P
    Q_centered = Q - centroid_Q

    # 4. Get correspondence
    idx_list = point3d_rigid_match.find_correspondence(listify(P), listify(Q))
    new_Q_list = []
    for idx in idx_list:
        new_Q_list.append(Q[idx, :])
    new_Q = np.array(new_Q_list)

    # 5. Solve rigid transform
    return compute_best_rigid_transform(P, new_Q, assume_p_center_zero)

if __name__ == "__main__":
    from solve_rigid_point_set_rt import compute_best_rigid_transform
    from solve_rigid_point_set_rt import apply_transform
    import numpy as np

    P = np.array([
        [ 20.606943,  -0.005458,  0.040331], # line 0
        [ -4.885081, -26.211561, -0.023027], # line 1
        [ 12.012958,  20.049110, -0.035819], # line 2
        [-27.734814,   6.167912,  0.018507]  # line 3
    ])

    Q = np.array([
        [-115.37230320753432, 126.89401508498568, 790.1637162115628], # line 2
        [ -137.8636773243661,  96.44871350623225, 808.1944560570211], # line 3
        [-132.94031926182967,  137.4289669332182, 782.6069181107938], # line 0
        [-164.12739196778332, 120.93405919807722, 791.4971644346351]  # line 1
    ])

    # 2. Compute optimal rotation and translation
    R_est, t_est = compute_best_rigid_transform_pro(P, Q)

    # 3. Apply transformation and calculate error
    P_transformed = apply_transform(P, R_est, t_est)
    print(P_transformed)
