"""Tests for the Family Bugle MCP server tool handlers.

Strategy:
- Tool handler functions in tools.py are tested directly with mocked clients.
- respx mocks the httpx transport layer to validate client behaviour.
- The context budget test imports the server and lists tools via FastMCP's
  list_tools() coroutine, then asserts total schema JSON < 1500 tokens.

Test categories:
    Happy path   -- correct inputs, well-formed API responses
    API errors   -- 429, 4xx, 5xx and network errors from the client
    Validation   -- invalid type values, missing required fields
    Response shape -- search returns compact {id, type, name, summary, url}
    Context budget -- combined tool schemas estimate < 1500 tokens
"""

from __future__ import annotations

import json
from typing import Any

import httpx
import pytest
import respx

from familybugle_mcp.client import FamilyBugleClient
from familybugle_mcp.tools import handle_ask, handle_get, handle_school_breaks, handle_search, handle_tuition


@pytest.fixture(autouse=True)
def _no_stdout_writes(capsys: pytest.CaptureFixture[str]) -> Any:
    """Fail any test that writes to stdout.

    stdout is reserved for the MCP JSON-RPC wire format. Any print() leaking
    to stdout will corrupt the protocol for real clients, so we guard against
    it in tests.
    """
    yield
    captured = capsys.readouterr()
    assert captured.out == "", (
        f"Nothing should be written to stdout during tool handling; got: {captured.out!r}"
    )


# ---------------------------------------------------------------------------
# Sample API response fixtures
# ---------------------------------------------------------------------------

_ACTIVITY_ITEM: dict[str, Any] = {
    "id": "aaaa0000-0000-0000-0000-000000000001",
    "title": "Youth Ski Camp",
    "provider_name": "Park City Mountain",
    "category": "Sports",
    "age_min": 5,
    "age_max": 12,
    "age_display": "5-12 years",
    "start_date": "2026-01-15",
    "end_date": "2026-01-19",
    "price": "250.00",
    "price_display": "$250",
    "source_url": "https://parkcitymountain.com/ski-camp",
    "description": "5-day ski camp for kids.",
}

_PROVIDER_ITEM: dict[str, Any] = {
    "id": "bbbb0000-0000-0000-0000-000000000002",
    "name": "Basin Recreation",
    "type": "recreation",
    "location_area": "Park City",
    "website": "https://basinrec.com",
    "description": "Park City's premier recreation provider.",
}

_ACTIVITY_LIST_RESPONSE: dict[str, Any] = {
    "data": [_ACTIVITY_ITEM],
    "total": 1,
    "page": 1,
    "limit": 10,
    "pages": 1,
}

_PROVIDER_LIST_RESPONSE: dict[str, Any] = {
    "data": [_PROVIDER_ITEM],
    "total": 1,
    "page": 1,
    "limit": 10,
    "pages": 1,
}

_ASK_RESPONSE: dict[str, Any] = {
    "answer": "Spring break runs April 6–10, 2026.",
    "citations": [
        {
            "type": "activity",
            "id": "aaaa0000-0000-0000-0000-000000000001",
            "name": "Spring Break Ski Camp",
            "url": "https://parkcitymountain.com/spring-camp",
        }
    ],
}

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_BASE = "http://test.local"


def _make_client(api_key: str | None = None) -> FamilyBugleClient:
    return FamilyBugleClient(base_url=_BASE, api_key=api_key)


# ---------------------------------------------------------------------------
# search tool — happy path
# ---------------------------------------------------------------------------


@respx.mock
@pytest.mark.asyncio
async def test_search_activity_type() -> None:
    """search with type='activity' should only hit the activities endpoint."""
    respx.get(f"{_BASE}/api/v1/activities").mock(
        return_value=httpx.Response(200, json=_ACTIVITY_LIST_RESPONSE)
    )
    client = _make_client()
    result = await handle_search(client, query="ski lessons", type="activity")

    assert result["total"] == 1
    assert len(result["results"]) == 1
    item = result["results"][0]
    assert item["type"] == "activity"
    assert item["id"] == _ACTIVITY_ITEM["id"]
    assert item["name"] == "Youth Ski Camp"
    assert "summary" in item
    assert "url" in item


@respx.mock
@pytest.mark.asyncio
async def test_search_provider_type() -> None:
    """search with type='provider' should only hit the providers endpoint."""
    respx.get(f"{_BASE}/api/v1/providers").mock(
        return_value=httpx.Response(200, json=_PROVIDER_LIST_RESPONSE)
    )
    client = _make_client()
    result = await handle_search(client, query="recreation", type="provider")

    assert result["total"] == 1
    item = result["results"][0]
    assert item["type"] == "provider"
    assert item["id"] == _PROVIDER_ITEM["id"]
    assert item["name"] == "Basin Recreation"


@respx.mock
@pytest.mark.asyncio
async def test_search_any_type_queries_both() -> None:
    """search with type='any' should query both activities and providers."""
    act_route = respx.get(f"{_BASE}/api/v1/activities").mock(
        return_value=httpx.Response(200, json=_ACTIVITY_LIST_RESPONSE)
    )
    prov_route = respx.get(f"{_BASE}/api/v1/providers").mock(
        return_value=httpx.Response(200, json=_PROVIDER_LIST_RESPONSE)
    )
    client = _make_client()
    result = await handle_search(client, query="park city", type="any")

    assert act_route.called
    assert prov_route.called
    # Combined: 1 activity + 1 provider = 2 results (capped at 10)
    assert len(result["results"]) == 2
    assert result["total"] == 2


@respx.mock
@pytest.mark.asyncio
async def test_search_applies_filters() -> None:
    """Filters object should be forwarded to the activities endpoint."""
    route = respx.get(f"{_BASE}/api/v1/activities").mock(
        return_value=httpx.Response(200, json=_ACTIVITY_LIST_RESPONSE)
    )
    client = _make_client()
    await handle_search(
        client,
        query="ski",
        type="activity",
        filters={"age": 7, "category": "Sports", "price_max": 300.0},
    )

    url = str(route.calls.last.request.url)
    assert "age=7" in url
    assert "category=Sports" in url
    assert "price_max=300" in url


@respx.mock
@pytest.mark.asyncio
async def test_search_location_not_sent_to_activities() -> None:
    """The activities endpoint does not accept location_area — we must not forward it."""
    route = respx.get(f"{_BASE}/api/v1/activities").mock(
        return_value=httpx.Response(200, json=_ACTIVITY_LIST_RESPONSE)
    )
    client = _make_client()
    await handle_search(
        client,
        query="ski",
        type="activity",
        filters={"location": "Old Town"},
    )

    url = str(route.calls.last.request.url)
    assert "location_area" not in url
    assert "location" not in url


@respx.mock
@pytest.mark.asyncio
async def test_search_price_max_sent_as_int() -> None:
    """price_max must be forwarded as an integer, not a float."""
    route = respx.get(f"{_BASE}/api/v1/activities").mock(
        return_value=httpx.Response(200, json=_ACTIVITY_LIST_RESPONSE)
    )
    client = _make_client()
    await handle_search(
        client,
        query="ski",
        type="activity",
        filters={"price_max": 300},
    )

    url = str(route.calls.last.request.url)
    assert "price_max=300" in url
    assert "price_max=300.0" not in url


@respx.mock
@pytest.mark.asyncio
async def test_search_caps_at_ten_results() -> None:
    """search should return at most 10 results even if both endpoints return data."""
    # 6 activities + 6 providers = 12 before cap
    many_activities = [dict(_ACTIVITY_ITEM, id=f"a-{i}") for i in range(6)]
    many_providers = [dict(_PROVIDER_ITEM, id=f"p-{i}") for i in range(6)]

    respx.get(f"{_BASE}/api/v1/activities").mock(
        return_value=httpx.Response(
            200, json={"data": many_activities, "total": 6, "page": 1, "limit": 10, "pages": 1}
        )
    )
    respx.get(f"{_BASE}/api/v1/providers").mock(
        return_value=httpx.Response(
            200, json={"data": many_providers, "total": 6, "page": 1, "limit": 10, "pages": 1}
        )
    )
    client = _make_client()
    result = await handle_search(client, query="anything", type="any")

    assert len(result["results"]) == 10


# ---------------------------------------------------------------------------
# search tool — response shape check
# ---------------------------------------------------------------------------


@respx.mock
@pytest.mark.asyncio
async def test_search_returns_compact_shape() -> None:
    """search results must have exactly {id, type, name, summary, url} — not full records."""
    respx.get(f"{_BASE}/api/v1/activities").mock(
        return_value=httpx.Response(200, json=_ACTIVITY_LIST_RESPONSE)
    )
    client = _make_client()
    result = await handle_search(client, query="ski", type="activity")

    item = result["results"][0]
    expected_keys = {"id", "type", "name", "summary", "url"}
    assert set(item.keys()) == expected_keys, (
        f"Expected keys {expected_keys}, got {set(item.keys())}"
    )
    # Must NOT include full record fields like description or price
    assert "description" not in item
    assert "price" not in item
    assert "age_min" not in item


# ---------------------------------------------------------------------------
# search tool — API error handling
# ---------------------------------------------------------------------------


@respx.mock
@pytest.mark.asyncio
async def test_search_returns_error_on_api_failure() -> None:
    """search should return an error dict (not raise) when the API fails."""
    respx.get(f"{_BASE}/api/v1/activities").mock(
        return_value=httpx.Response(500, text="Internal Server Error")
    )
    client = _make_client()
    result = await handle_search(client, query="ski", type="activity")

    assert "error" in result
    assert result["results"] == []
    assert result["total"] == 0


@respx.mock
@pytest.mark.asyncio
async def test_search_rate_limit_error() -> None:
    """search with 429 response should return the rate-limit error message."""
    respx.get(f"{_BASE}/api/v1/activities").mock(
        return_value=httpx.Response(429, json={"detail": "Too Many Requests"})
    )
    client = _make_client()
    result = await handle_search(client, query="ski", type="activity")

    assert "error" in result
    assert "Rate limit" in result["error"]


# ---------------------------------------------------------------------------
# get tool — happy path
# ---------------------------------------------------------------------------


@respx.mock
@pytest.mark.asyncio
async def test_get_activity_returns_full_record() -> None:
    """get with type='activity' should return the full activity record."""
    respx.get(f"{_BASE}/api/v1/activities/{_ACTIVITY_ITEM['id']}").mock(
        return_value=httpx.Response(200, json=_ACTIVITY_ITEM)
    )
    client = _make_client()
    result = await handle_get(client, type="activity", id=_ACTIVITY_ITEM["id"])

    assert result["id"] == _ACTIVITY_ITEM["id"]
    assert result["title"] == "Youth Ski Camp"
    assert "description" in result  # full record, not trimmed


@respx.mock
@pytest.mark.asyncio
async def test_get_provider_returns_full_record() -> None:
    """get with type='provider' should return the full provider record."""
    respx.get(f"{_BASE}/api/v1/providers/{_PROVIDER_ITEM['id']}").mock(
        return_value=httpx.Response(200, json=_PROVIDER_ITEM)
    )
    client = _make_client()
    result = await handle_get(client, type="provider", id=_PROVIDER_ITEM["id"])

    assert result["id"] == _PROVIDER_ITEM["id"]
    assert result["name"] == "Basin Recreation"


# ---------------------------------------------------------------------------
# get tool — API error handling
# ---------------------------------------------------------------------------


@respx.mock
@pytest.mark.asyncio
async def test_get_returns_error_on_not_found() -> None:
    """get with a 404 response should return an error dict."""
    respx.get(f"{_BASE}/api/v1/activities/missing-id").mock(
        return_value=httpx.Response(404, json={"detail": "Activity not found"})
    )
    client = _make_client()
    result = await handle_get(client, type="activity", id="missing-id")

    assert "error" in result
    assert "Activity not found" in result["error"]


# ---------------------------------------------------------------------------
# ask tool — happy path
# ---------------------------------------------------------------------------


@respx.mock
@pytest.mark.asyncio
async def test_ask_returns_answer_and_citations() -> None:
    """ask should return {answer, citations} from the API."""
    respx.post(f"{_BASE}/api/v1/ask").mock(return_value=httpx.Response(200, json=_ASK_RESPONSE))
    client = _make_client()
    result = await handle_ask(client, question="when is spring break?")

    assert result["answer"] == _ASK_RESPONSE["answer"]
    assert len(result["citations"]) == 1
    citation = result["citations"][0]
    assert citation["type"] == "activity"
    assert citation["name"] == "Spring Break Ski Camp"


@respx.mock
@pytest.mark.asyncio
async def test_ask_sends_question_in_body() -> None:
    """ask should POST the question in the JSON body."""
    route = respx.post(f"{_BASE}/api/v1/ask").mock(
        return_value=httpx.Response(200, json=_ASK_RESPONSE)
    )
    client = _make_client()
    await handle_ask(client, question="what are good ski camps?")

    body = json.loads(route.calls.last.request.content)
    assert body["question"] == "what are good ski camps?"


# ---------------------------------------------------------------------------
# ask tool — API error handling
# ---------------------------------------------------------------------------


@respx.mock
@pytest.mark.asyncio
async def test_ask_returns_error_on_api_failure() -> None:
    """ask should return an error dict when the API fails."""
    respx.post(f"{_BASE}/api/v1/ask").mock(
        return_value=httpx.Response(500, text="Internal Server Error")
    )
    client = _make_client()
    result = await handle_ask(client, question="test question")

    assert "error" in result
    assert result["answer"] == ""
    assert result["citations"] == []


# ---------------------------------------------------------------------------
# Client: auth header tests
# ---------------------------------------------------------------------------


@respx.mock
@pytest.mark.asyncio
async def test_api_key_sent_when_configured() -> None:
    """Client should include X-API-Key when configured."""
    route = respx.get(f"{_BASE}/api/v1/activities").mock(
        return_value=httpx.Response(200, json=_ACTIVITY_LIST_RESPONSE)
    )
    client = _make_client(api_key="fb_live_testkey123")
    await handle_search(client, query="ski", type="activity")

    req = route.calls.last.request
    assert req.headers.get("x-api-key") == "fb_live_testkey123"


@respx.mock
@pytest.mark.asyncio
async def test_api_key_absent_when_not_configured() -> None:
    """Client must NOT include X-API-Key when no key is set."""
    route = respx.get(f"{_BASE}/api/v1/activities").mock(
        return_value=httpx.Response(200, json=_ACTIVITY_LIST_RESPONSE)
    )
    client = _make_client(api_key=None)
    await handle_search(client, query="ski", type="activity")

    req = route.calls.last.request
    assert "x-api-key" not in req.headers


# ---------------------------------------------------------------------------
# Context budget check
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tool_schemas_within_context_budget() -> None:
    """Combined tool schemas must estimate < 2500 tokens.

    Token estimate: len(json.dumps(schemas)) // 4
    This ensures MCP clients don't burn excessive context loading our tools.
    Budget was updated from 1500 to 2500 when school_breaks and tuition were added.
    """
    # Import inside test to avoid server-level side effects at collection time.
    from familybugle_mcp.server import mcp

    tools = await mcp.list_tools()

    assert len(tools) == 5, f"Expected exactly 5 tools, got {len(tools)}: {[t.name for t in tools]}"

    # Serialize to JSON as the MCP wire format would deliver it.
    schemas_json = json.dumps([t.model_dump() for t in tools])
    estimated_tokens = len(schemas_json) // 4

    # Log for debugging — stdout is reserved for MCP wire format.
    import sys

    sys.stderr.write(f"\nTool schema JSON length: {len(schemas_json)} chars\n")
    sys.stderr.write(f"Estimated tokens: {estimated_tokens}\n")
    for t in tools:
        tool_json = json.dumps(t.model_dump())
        sys.stderr.write(f"  {t.name}: {len(tool_json)} chars (~{len(tool_json) // 4} tokens)\n")

    assert estimated_tokens < 2500, (
        f"Combined tool schemas estimate {estimated_tokens} tokens — exceeds 2500 budget. "
        f"Shorten tool descriptions or input schemas. JSON:\n{schemas_json}"
    )


# ---------------------------------------------------------------------------
# Input validation — filters object
# ---------------------------------------------------------------------------


@respx.mock
@pytest.mark.asyncio
async def test_search_invalid_filters_field_ignored() -> None:
    """Unknown fields in filters should not cause a crash — Pydantic ignores them."""
    respx.get(f"{_BASE}/api/v1/activities").mock(
        return_value=httpx.Response(200, json=_ACTIVITY_LIST_RESPONSE)
    )
    client = _make_client()
    # Pydantic model uses ignore for extra fields by default; this should not raise.
    result = await handle_search(
        client,
        query="ski",
        type="activity",
        filters={"age": 7, "unknown_field": "should be ignored"},
    )
    assert "results" in result


@respx.mock
@pytest.mark.asyncio
async def test_search_empty_filters() -> None:
    """None filters should behave the same as passing no filters."""
    respx.get(f"{_BASE}/api/v1/activities").mock(
        return_value=httpx.Response(200, json=_ACTIVITY_LIST_RESPONSE)
    )
    client = _make_client()
    result = await handle_search(client, query="ski", type="activity", filters=None)
    assert "results" in result


# ---------------------------------------------------------------------------
# Network error handling
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_search_network_error_returns_error_dict() -> None:
    """Transport errors should be caught and returned as error dicts."""
    with respx.mock:
        respx.get(f"{_BASE}/api/v1/activities").mock(
            side_effect=httpx.ConnectError("connection refused")
        )
        client = _make_client()
        result = await handle_search(client, query="ski", type="activity")

    assert "error" in result
    assert "Network error" in result["error"]


@pytest.mark.asyncio
async def test_ask_network_error_returns_error_dict() -> None:
    """Transport errors in ask should be caught and returned as error dicts."""
    with respx.mock:
        respx.post(f"{_BASE}/api/v1/ask").mock(side_effect=httpx.ConnectError("connection refused"))
        client = _make_client()
        result = await handle_ask(client, question="test?")

    assert "error" in result
    assert "Network error" in result["error"]


# ---------------------------------------------------------------------------
# school_breaks tool — sample data
# ---------------------------------------------------------------------------

_BREAKS_LIST: list[dict[str, Any]] = [
    {
        "id": "cccc0000-0000-0000-0000-000000000003",
        "provider_id": "bbbb0000-0000-0000-0000-000000000002",
        "provider_name": "Park City School District",
        "name": "Spring Break",
        "break_type": "vacation",
        "start_date": "2026-04-06",
        "end_date": "2026-04-10",
        "school_year": "2025-2026",
        "notes": None,
        "created_at": "2026-01-01T00:00:00Z",
        "updated_at": "2026-01-01T00:00:00Z",
    }
]


# ---------------------------------------------------------------------------
# school_breaks tool — happy path
# ---------------------------------------------------------------------------


@respx.mock
@pytest.mark.asyncio
async def test_school_breaks_returns_compact_shape() -> None:
    """school_breaks should return {breaks, total} with compact fields."""
    respx.get(f"{_BASE}/api/v1/school-breaks").mock(
        return_value=httpx.Response(200, json=_BREAKS_LIST)
    )
    client = _make_client()
    result = await handle_school_breaks(client)

    assert result["total"] == 1
    assert len(result["breaks"]) == 1
    brk = result["breaks"][0]
    assert brk["name"] == "Spring Break"
    assert brk["provider_name"] == "Park City School District"
    assert brk["break_type"] == "vacation"
    assert brk["start_date"] == "2026-04-06"
    assert brk["end_date"] == "2026-04-10"
    assert "id" in brk
    # Must not include verbose fields
    assert "school_year" not in brk
    assert "created_at" not in brk


@respx.mock
@pytest.mark.asyncio
async def test_school_breaks_passes_limit() -> None:
    """handle_school_breaks should forward the limit parameter to the API."""
    route = respx.get(f"{_BASE}/api/v1/school-breaks").mock(
        return_value=httpx.Response(200, json=_BREAKS_LIST)
    )
    client = _make_client()
    await handle_school_breaks(client, limit=5)

    url = str(route.calls.last.request.url)
    assert "limit=5" in url


@respx.mock
@pytest.mark.asyncio
async def test_school_breaks_caps_limit_at_100() -> None:
    """Limit values over 100 should be capped to 100 before forwarding."""
    route = respx.get(f"{_BASE}/api/v1/school-breaks").mock(
        return_value=httpx.Response(200, json=_BREAKS_LIST)
    )
    client = _make_client()
    await handle_school_breaks(client, limit=999)

    url = str(route.calls.last.request.url)
    assert "limit=100" in url
    assert "limit=999" not in url


@respx.mock
@pytest.mark.asyncio
async def test_school_breaks_empty_list() -> None:
    """An empty response from the API should return breaks=[] and total=0."""
    respx.get(f"{_BASE}/api/v1/school-breaks").mock(
        return_value=httpx.Response(200, json=[])
    )
    client = _make_client()
    result = await handle_school_breaks(client)

    assert result["breaks"] == []
    assert result["total"] == 0


# ---------------------------------------------------------------------------
# school_breaks tool — error handling
# ---------------------------------------------------------------------------


@respx.mock
@pytest.mark.asyncio
async def test_school_breaks_returns_error_on_api_failure() -> None:
    """API errors should be caught and returned as error dicts."""
    respx.get(f"{_BASE}/api/v1/school-breaks").mock(
        return_value=httpx.Response(500, text="Internal Server Error")
    )
    client = _make_client()
    result = await handle_school_breaks(client)

    assert "error" in result
    assert result["breaks"] == []
    assert result["total"] == 0


@pytest.mark.asyncio
async def test_school_breaks_network_error_returns_error_dict() -> None:
    """Transport errors should be caught and returned as error dicts."""
    with respx.mock:
        respx.get(f"{_BASE}/api/v1/school-breaks").mock(
            side_effect=httpx.ConnectError("connection refused")
        )
        client = _make_client()
        result = await handle_school_breaks(client)

    assert "error" in result
    assert "Network error" in result["error"]


# ---------------------------------------------------------------------------
# tuition tool — sample data
# ---------------------------------------------------------------------------

_TUITION_RATE: dict[str, Any] = {
    "id": "dddd0000-0000-0000-0000-000000000004",
    "program_name": "Full Day Preschool",
    "program_type": "preschool",
    "age_group": "3_to_4",
    "age_display": "3-4 years",
    "amount": "1200.00",
    "rate_type": "monthly",
    "category": "tuition",
    "days_per_week": 5,
    "notes": None,
}

_TUITION_SCHEDULE: dict[str, Any] = {
    "id": "eeee0000-0000-0000-0000-000000000005",
    "provider_id": "bbbb0000-0000-0000-0000-000000000002",
    "provider_name": "Little Sprouts Preschool",
    "name": "2026-2027 Tuition",
    "season": "academic_year",
    "school_year": "2026-2027",
    "effective_date": "2026-09-01",
    "end_date": None,
    "payment_frequency": "monthly",
    "payment_notes": "Due on the 1st of each month.",
    "source_url": "https://littlesprouts.com/tuition",
    "notes": None,
    "rates": [_TUITION_RATE],
    "created_at": "2026-01-01T00:00:00Z",
    "updated_at": "2026-01-01T00:00:00Z",
}

_TUITION_LIST: list[dict[str, Any]] = [_TUITION_SCHEDULE]

_PROVIDER_UUID = "bbbb0000-0000-0000-0000-000000000002"


# ---------------------------------------------------------------------------
# tuition tool — happy path
# ---------------------------------------------------------------------------


@respx.mock
@pytest.mark.asyncio
async def test_tuition_returns_schedules_and_total() -> None:
    """tuition should return {schedules, total} with the full schedule objects."""
    respx.get(f"{_BASE}/api/v1/tuition").mock(
        return_value=httpx.Response(200, json=_TUITION_LIST)
    )
    client = _make_client()
    result = await handle_tuition(client, provider_id=_PROVIDER_UUID)

    assert result["total"] == 1
    assert len(result["schedules"]) == 1
    schedule = result["schedules"][0]
    assert schedule["name"] == "2026-2027 Tuition"
    assert len(schedule["rates"]) == 1
    assert schedule["rates"][0]["program_name"] == "Full Day Preschool"


@respx.mock
@pytest.mark.asyncio
async def test_tuition_passes_provider_id_to_api() -> None:
    """handle_tuition should forward provider_id as a query parameter."""
    route = respx.get(f"{_BASE}/api/v1/tuition").mock(
        return_value=httpx.Response(200, json=_TUITION_LIST)
    )
    client = _make_client()
    await handle_tuition(client, provider_id=_PROVIDER_UUID)

    url = str(route.calls.last.request.url)
    assert _PROVIDER_UUID in url


@respx.mock
@pytest.mark.asyncio
async def test_tuition_empty_list() -> None:
    """An empty response should return schedules=[] and total=0."""
    respx.get(f"{_BASE}/api/v1/tuition").mock(
        return_value=httpx.Response(200, json=[])
    )
    client = _make_client()
    result = await handle_tuition(client, provider_id=_PROVIDER_UUID)

    assert result["schedules"] == []
    assert result["total"] == 0


# ---------------------------------------------------------------------------
# tuition tool — error handling
# ---------------------------------------------------------------------------


@respx.mock
@pytest.mark.asyncio
async def test_tuition_returns_error_on_api_failure() -> None:
    """API errors should be caught and returned as error dicts."""
    respx.get(f"{_BASE}/api/v1/tuition").mock(
        return_value=httpx.Response(500, text="Internal Server Error")
    )
    client = _make_client()
    result = await handle_tuition(client, provider_id=_PROVIDER_UUID)

    assert "error" in result
    assert result["schedules"] == []
    assert result["total"] == 0


@respx.mock
@pytest.mark.asyncio
async def test_tuition_returns_error_on_not_found() -> None:
    """404 for an unknown provider_id should return an error dict."""
    respx.get(f"{_BASE}/api/v1/tuition").mock(
        return_value=httpx.Response(404, json={"detail": "Provider not found"})
    )
    client = _make_client()
    result = await handle_tuition(client, provider_id="no-such-id")

    assert "error" in result
    assert "Provider not found" in result["error"]


@pytest.mark.asyncio
async def test_tuition_network_error_returns_error_dict() -> None:
    """Transport errors should be caught and returned as error dicts."""
    with respx.mock:
        respx.get(f"{_BASE}/api/v1/tuition").mock(
            side_effect=httpx.ConnectError("connection refused")
        )
        client = _make_client()
        result = await handle_tuition(client, provider_id=_PROVIDER_UUID)

    assert "error" in result
    assert "Network error" in result["error"]
