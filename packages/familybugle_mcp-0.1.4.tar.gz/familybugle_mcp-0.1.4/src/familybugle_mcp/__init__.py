"""familybugle-mcp — Model Context Protocol server for Park City Families."""

__version__ = "0.1.4"
