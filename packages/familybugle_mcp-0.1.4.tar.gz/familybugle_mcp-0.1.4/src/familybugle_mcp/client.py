"""Async HTTP client for the Family Bugle public API v1.

Uses async httpx so it can be awaited from MCP tool handlers without blocking
the event loop. All methods raise ``FamilyBugleAPIError`` on 4xx/5xx responses
so tool handlers can catch one exception type and return a clean error string.

Error mapping:
    429 → rate limit message with hint to add an API key
    4xx → body detail from the JSON error response
    5xx → generic "server error, please try again"
    transport error → network connectivity message

Usage::

    async with FamilyBugleClient() as client:
        result = await client.search_activities(query="ski lessons", age=7)
"""

from __future__ import annotations

from typing import Any

import httpx

from familybugle_mcp import __version__

_USER_AGENT = f"familybugle-mcp/{__version__}"
_API_PREFIX = "/api/v1"


class FamilyBugleAPIError(Exception):
    """Raised for any API or transport error encountered in a tool handler.

    The message is suitable for returning directly to the MCP client.
    """


class FamilyBugleClient:
    """Async HTTP client wrapping the Family Bugle REST API v1.

    Args:
        base_url: Base URL of the API (default: https://familybugle.com).
        api_key:  Optional ``fb_live_...`` key sent as ``X-API-Key``.
        timeout:  Request timeout in seconds (default: 30).
    """

    def __init__(
        self,
        base_url: str = "https://api.familybugle.com",
        api_key: str | None = None,
        timeout: float = 30,
    ) -> None:
        headers: dict[str, str] = {"User-Agent": _USER_AGENT}
        if api_key:
            headers["X-API-Key"] = api_key

        self._client = httpx.AsyncClient(
            base_url=base_url.rstrip("/"),
            headers=headers,
            timeout=timeout,
        )

    async def __aenter__(self) -> FamilyBugleClient:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self._client.aclose()

    async def aclose(self) -> None:
        """Close the underlying httpx client."""
        await self._client.aclose()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        """Send a GET request and return the parsed JSON body.

        Raises:
            FamilyBugleAPIError: on any HTTP 4xx/5xx or transport failure.
        """
        url = f"{_API_PREFIX}{path}"
        clean_params = {k: v for k, v in (params or {}).items() if v is not None}
        try:
            resp = await self._client.get(url, params=clean_params)
        except httpx.TransportError as exc:
            raise FamilyBugleAPIError(
                f"Network error — could not reach the Family Bugle API: {exc}"
            ) from exc

        self._raise_for_status(resp)
        return resp.json()

    async def _post(self, path: str, body: dict[str, Any]) -> Any:
        """Send a POST request with JSON body and return the parsed JSON body."""
        url = f"{_API_PREFIX}{path}"
        try:
            resp = await self._client.post(url, json=body)
        except httpx.TransportError as exc:
            raise FamilyBugleAPIError(
                f"Network error — could not reach the Family Bugle API: {exc}"
            ) from exc

        self._raise_for_status(resp)
        return resp.json()

    @staticmethod
    def _raise_for_status(resp: httpx.Response) -> None:
        """Map HTTP error status codes to FamilyBugleAPIError."""
        if resp.is_success:
            return

        if resp.status_code == 429:
            raise FamilyBugleAPIError(
                "Rate limit reached. Set FAMILYBUGLE_API_KEY for higher limits "
                "(see https://familybugle.com/ai)."
            )

        if 400 <= resp.status_code < 500:
            try:
                detail = resp.json().get("detail", resp.text)
            except Exception:
                detail = resp.text or f"HTTP {resp.status_code}"
            raise FamilyBugleAPIError(f"API error ({resp.status_code}): {detail}")

        raise FamilyBugleAPIError(f"Server error (HTTP {resp.status_code}), please try again.")

    # ------------------------------------------------------------------
    # API methods
    # ------------------------------------------------------------------

    async def search_activities(
        self,
        *,
        query: str | None = None,
        age: int | None = None,
        category: str | None = None,
        date_from: str | None = None,
        date_to: str | None = None,
        price_max: int | None = None,
        limit: int = 10,
    ) -> dict[str, Any]:
        """Search activities with optional filters. Returns paginated results."""
        return await self._get(
            "/activities",
            {
                "search": query,
                "age": age,
                "category": category,
                "date_from": date_from,
                "date_to": date_to,
                "price_max": price_max,
                "limit": limit,
            },
        )

    async def search_providers(
        self,
        *,
        query: str | None = None,
        location: str | None = None,
        limit: int = 10,
    ) -> dict[str, Any]:
        """Search providers with optional filters. Returns paginated results."""
        return await self._get(
            "/providers",
            {
                "search": query,
                "location_area": location,
                "limit": limit,
            },
        )

    async def get_activity(self, activity_id: str) -> dict[str, Any]:
        """Fetch a single activity by UUID."""
        return await self._get(f"/activities/{activity_id}")

    async def get_provider(self, provider_id: str) -> dict[str, Any]:
        """Fetch a single provider by UUID."""
        return await self._get(f"/providers/{provider_id}")

    async def get_school_breaks(self, *, limit: int = 10) -> list[dict[str, Any]]:
        """Fetch upcoming school calendar breaks ordered by start date."""
        return await self._get("/school-breaks", {"limit": limit})  # type: ignore[return-value]

    async def get_tuition(self, provider_id: str) -> list[dict[str, Any]]:
        """Fetch tuition schedules for a provider by UUID."""
        return await self._get("/tuition", {"provider_id": provider_id})  # type: ignore[return-value]

    async def ask(self, question: str) -> dict[str, Any]:
        """Send a natural-language question and receive an answer with citations."""
        return await self._post("/ask", {"question": question})
