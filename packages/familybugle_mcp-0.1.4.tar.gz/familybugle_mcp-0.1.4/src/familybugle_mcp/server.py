"""Family Bugle MCP server — entry point and tool registration.

Runs as a stdio MCP server. The server exposes 5 tools:

    search        -- find activities and providers
    get           -- fetch full details for a single record
    ask           -- natural-language Q&A with citations
    school_breaks -- list upcoming school calendar breaks
    tuition       -- get tuition rates for a daycare or school

Transport: stdio only (launched via `uvx familybugle-mcp` or direct `python -m`).
Logging:   stderr only — stdout is reserved for the MCP protocol wire format.

Environment variables:
    FAMILYBUGLE_API_KEY   Optional fb_live_... key for authenticated tier.
    FAMILYBUGLE_API_URL   Override base URL (default: https://api.familybugle.com).
"""

from __future__ import annotations

import logging
import os
import sys
from typing import Any, Literal

from mcp.server import FastMCP

from familybugle_mcp import __version__
from familybugle_mcp.client import FamilyBugleClient
from familybugle_mcp.tools import (
    handle_ask,
    handle_get,
    handle_school_breaks,
    handle_search,
    handle_tuition,
)

# ---------------------------------------------------------------------------
# Startup — read config from environment
# ---------------------------------------------------------------------------

_API_KEY: str | None = os.environ.get("FAMILYBUGLE_API_KEY")
_API_URL: str = os.environ.get("FAMILYBUGLE_API_URL", "https://api.familybugle.com")

# Log to stderr — stdout carries MCP protocol data and must not be polluted.
if not logging.root.handlers:
    logging.basicConfig(
        stream=sys.stderr,
        level=logging.INFO,
        format="[%(name)s] %(levelname)s %(message)s",
    )
_log = logging.getLogger("familybugle-mcp")
_log.info(
    "Starting familybugle-mcp v%s (%s tier)",
    __version__,
    "authenticated" if _API_KEY else "public",
)

# ---------------------------------------------------------------------------
# MCP server setup
# ---------------------------------------------------------------------------

mcp = FastMCP(
    name="familybugle",
    instructions=(
        "Family Bugle gives you Park City family activity data. "
        "Use `search` to find activities or providers, `get` for full details, "
        "`ask` for open-ended questions, `school_breaks` for school calendar breaks, "
        "and `tuition` for daycare/school pricing."
    ),
)

# Shared client — created once at import time, reused across all tool calls.
# httpx.AsyncClient is safe to share across coroutines.
_client = FamilyBugleClient(base_url=_API_URL, api_key=_API_KEY)

# ---------------------------------------------------------------------------
# Tool: search
# ---------------------------------------------------------------------------


@mcp.tool(
    name="search",
    description=(
        "Find Park City activities and providers. "
        "Use `filters` for structured criteria (age, date range, price, category) "
        "and leave `query` empty or broad — do NOT put ages or dates in `query` "
        "(e.g. for a 3-year-old, pass filters={\"age\":3}, not query=\"toddler\"). "
        "Returns up to 10 compact results; call `get` for full details."
    ),
)
async def search(
    query: str = "",
    type: Literal["activity", "provider", "any"] = "any",
    filters: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Search Park City activities and/or providers.

    Args:
        query:   Optional keyword text matched against name/description.
                 Leave empty when filtering by age/date/price — those belong in
                 `filters`. Good: query="ski", filters={"age":7}. Bad: query="7 year old".
        type:    Restrict to "activity", "provider", or search "any" (default).
        filters: Structured filters. Supported keys:
                 - age (int): child's age in years — use this for age queries
                 - category (str): e.g. "Sports", "Arts"
                 - location (str): area name (providers only), e.g. "Old Town"
                 - date_from (ISO 8601 str): e.g. "2026-06-01"
                 - date_to (ISO 8601 str): e.g. "2026-08-31"
                 - price_max (number): maximum price in USD

    Returns:
        {results: [{id, type, name, summary, url}], total: int}
    """
    return await handle_search(_client, query=query, type=type, filters=filters)


# ---------------------------------------------------------------------------
# Tool: get
# ---------------------------------------------------------------------------


@mcp.tool(
    name="get",
    description="Fetch full details for a specific activity or provider by id.",
)
async def get(
    type: Literal["activity", "provider"],
    id: str,
) -> dict[str, Any]:
    """Fetch the full record for a single activity or provider.

    Args:
        type: Entity type — "activity" or "provider".
        id:   UUID returned by `search`.

    Returns:
        Full record with all fields from the API.
    """
    return await handle_get(_client, type=type, id=id)


# ---------------------------------------------------------------------------
# Tool: ask
# ---------------------------------------------------------------------------


@mcp.tool(
    name="ask",
    description=(
        "Ask a natural-language question about Park City family life. "
        "Returns an answer with source citations."
    ),
)
async def ask(question: str) -> dict[str, Any]:
    """Ask a free-form question about Park City family resources.

    Args:
        question: Natural-language question, e.g. "when is spring break?"

    Returns:
        {answer: str, citations: [{type, id, name, url}]}
    """
    return await handle_ask(_client, question=question)


# ---------------------------------------------------------------------------
# Tool: school_breaks
# ---------------------------------------------------------------------------


@mcp.tool(
    name="school_breaks",
    description=(
        "List upcoming Park City school calendar breaks (spring break, holidays, teacher days). "
        "Returns break name, dates, and which school/provider it applies to."
    ),
)
async def school_breaks(
    limit: int = 10,
) -> dict[str, Any]:
    """List upcoming school calendar breaks.

    Args:
        limit: Max breaks to return (1-100, default 10).

    Returns:
        {breaks: [{id, name, provider_name, break_type, start_date, end_date}], total: int}
    """
    return await handle_school_breaks(_client, limit=limit)


# ---------------------------------------------------------------------------
# Tool: tuition
# ---------------------------------------------------------------------------


@mcp.tool(
    name="tuition",
    description=(
        "Get tuition rates for a daycare or school by provider id. "
        "Returns schedules with rates by program, age group, and days per week. "
        "Use `search` with type='provider' first to get a provider id."
    ),
)
async def tuition(
    provider_id: str,
) -> dict[str, Any]:
    """Fetch tuition schedules for a specific provider.

    Args:
        provider_id: UUID of the provider (daycare or school). Get this from `search`.

    Returns:
        {schedules: [TuitionV1 with rates array], total: int}
    """
    return await handle_tuition(_client, provider_id=provider_id)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    """Run the MCP server over stdio transport.

    Called by the `familybugle-mcp` console script entry point.
    Blocks until stdin is closed or the process is killed.
    """
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
