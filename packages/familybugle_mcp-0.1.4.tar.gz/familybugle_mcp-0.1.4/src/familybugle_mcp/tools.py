"""Tool handler implementations for the Family Bugle MCP server.

Each function maps directly to one MCP tool. Handlers are async and use the
shared FamilyBugleClient passed in at server startup. All errors from the
client are caught and returned as plain error strings so the MCP client
receives a well-formed (if failed) response rather than an uncaught exception.

Tools:
    search        -- unified search across activities and/or providers
    get           -- fetch full details for a single activity or provider
    ask           -- natural-language Q&A with cited sources
    school_breaks -- list upcoming school calendar breaks
    tuition       -- fetch tuition rate schedules for a provider
"""

from __future__ import annotations

from datetime import date
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

from familybugle_mcp.client import FamilyBugleAPIError, FamilyBugleClient

# ---------------------------------------------------------------------------
# Input models — Pydantic validates MCP tool arguments before handlers run.
# ---------------------------------------------------------------------------

_BASE_URL = "https://familybugle.com"


class SearchFilters(BaseModel):
    """Optional filter object for the search tool."""

    model_config = ConfigDict(extra="ignore")

    age: int | None = Field(default=None, description="Child age in years")
    category: str | None = Field(default=None, description="Activity category, e.g. Sports")
    location: str | None = Field(
        default=None,
        description="Location area (providers only), e.g. Old Town",
    )
    date_from: str | None = Field(default=None, description="ISO 8601 date, e.g. 2026-06-01")
    date_to: str | None = Field(default=None, description="ISO 8601 date, e.g. 2026-08-31")
    price_max: int | None = Field(default=None, description="Maximum price in USD")


# ---------------------------------------------------------------------------
# Response builders — trim fields to keep search results compact.
# ---------------------------------------------------------------------------


def _activity_summary(item: dict[str, Any]) -> dict[str, Any]:
    """Return a compact representation of an activity for search results."""
    item_id = item.get("id", "")
    return {
        "id": item_id,
        "type": "activity",
        "name": item.get("title", ""),
        "summary": _activity_summary_text(item),
        "url": item.get("source_url") or f"{_BASE_URL}/activities/{item_id}",
    }


def _activity_summary_text(item: dict[str, Any]) -> str:
    """Build a one-line summary string for an activity."""
    parts: list[str] = []
    if item.get("provider_name"):
        parts.append(item["provider_name"])
    if item.get("age_display"):
        parts.append(item["age_display"])
    if item.get("price_display"):
        parts.append(item["price_display"])
    if item.get("start_date"):
        parts.append(item["start_date"])
    return " · ".join(parts)


def _provider_summary(item: dict[str, Any]) -> dict[str, Any]:
    """Return a compact representation of a provider for search results."""
    item_id = item.get("id", "")
    return {
        "id": item_id,
        "type": "provider",
        "name": item.get("name", ""),
        "summary": _provider_summary_text(item),
        "url": item.get("website") or f"{_BASE_URL}/providers/{item_id}",
    }


def _provider_summary_text(item: dict[str, Any]) -> str:
    """Build a one-line summary string for a provider."""
    parts: list[str] = []
    if item.get("type"):
        parts.append(item["type"])
    if item.get("location_area"):
        parts.append(item["location_area"])
    return " · ".join(parts)


# ---------------------------------------------------------------------------
# Tool handlers
# ---------------------------------------------------------------------------


async def handle_search(
    client: FamilyBugleClient,
    query: str,
    type: Literal["activity", "provider", "any"] = "any",
    filters: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Implement the `search` tool.

    Searches activities and/or providers depending on the ``type`` parameter.
    Returns at most 10 compact result items.

    Args:
        client:  Shared API client instance.
        query:   Natural-language search text.
        type:    Which entity type to search ("activity", "provider", or "any").
        filters: Optional dict matching SearchFilters fields.

    Returns:
        Dict with ``results`` list and ``total`` count.
    """
    # Parse and validate optional filters.
    f = SearchFilters(**(filters or {}))

    # Default date_from to today so "search activities" means "upcoming
    # activities" — past events are almost never what the caller wants.
    # Callers can pass an explicit older date_from to override.
    effective_date_from = f.date_from or date.today().isoformat()

    results: list[dict[str, Any]] = []
    total = 0

    try:
        if type in ("activity", "any"):
            data = await client.search_activities(
                query=query,
                age=f.age,
                category=f.category,
                date_from=effective_date_from,
                date_to=f.date_to,
                price_max=f.price_max,
                limit=10,
            )
            items = data.get("data", [])
            results.extend(_activity_summary(a) for a in items)
            total += data.get("total", len(items))

        if type in ("provider", "any"):
            data = await client.search_providers(
                query=query,
                location=f.location,
                limit=10,
            )
            items = data.get("data", [])
            results.extend(_provider_summary(p) for p in items)
            total += data.get("total", len(items))

    except FamilyBugleAPIError as exc:
        return {"error": str(exc), "results": [], "total": 0}

    # Cap at 10 total items so the context payload stays small.
    return {"results": results[:10], "total": total}


async def handle_get(
    client: FamilyBugleClient,
    type: Literal["activity", "provider"],
    id: str,
) -> dict[str, Any]:
    """Implement the `get` tool.

    Fetches the full record for a single activity or provider.

    Args:
        client: Shared API client instance.
        type:   Entity type — must be "activity" or "provider".
        id:     UUID of the entity to fetch.

    Returns:
        Full record dict from the API, or an ``error`` dict on failure.
    """
    try:
        if type == "activity":
            return await client.get_activity(id)
        else:
            return await client.get_provider(id)
    except FamilyBugleAPIError as exc:
        return {"error": str(exc)}


async def handle_school_breaks(
    client: FamilyBugleClient,
    limit: int = 10,
) -> dict[str, Any]:
    """Implement the `school_breaks` tool.

    Returns upcoming school calendar breaks ordered by start date.

    Args:
        client: Shared API client instance.
        limit:  Maximum number of breaks to return (default 10, max 100).

    Returns:
        Dict with ``breaks`` list and ``total`` count.
    """
    try:
        items = await client.get_school_breaks(limit=min(limit, 100))
        results = [
            {
                "id": b.get("id", ""),
                "name": b.get("name", ""),
                "provider_name": b.get("provider_name") or "",
                "break_type": b.get("break_type", ""),
                "start_date": b.get("start_date", ""),
                "end_date": b.get("end_date", ""),
            }
            for b in items
        ]
        return {"breaks": results, "total": len(results)}
    except FamilyBugleAPIError as exc:
        return {"error": str(exc), "breaks": [], "total": 0}


async def handle_tuition(
    client: FamilyBugleClient,
    provider_id: str,
) -> dict[str, Any]:
    """Implement the `tuition` tool.

    Returns tuition schedules with rate line items for a given provider.

    Args:
        client:      Shared API client instance.
        provider_id: UUID of the provider (daycare or school).

    Returns:
        Dict with ``schedules`` list and ``total`` count, or ``error`` on failure.
    """
    try:
        schedules = await client.get_tuition(provider_id)
        return {"schedules": schedules, "total": len(schedules)}
    except FamilyBugleAPIError as exc:
        return {"error": str(exc), "schedules": [], "total": 0}


async def handle_ask(
    client: FamilyBugleClient,
    question: str,
) -> dict[str, Any]:
    """Implement the `ask` tool.

    Sends the question to the Family Bugle AI endpoint and returns an answer
    with source citations.

    Args:
        client:   Shared API client instance.
        question: Natural-language question about Park City family resources.

    Returns:
        Dict with ``answer`` string and ``citations`` list, or ``error`` on failure.
    """
    try:
        result = await client.ask(question)
        return {
            "answer": result.get("answer", ""),
            "citations": result.get("citations", []),
        }
    except FamilyBugleAPIError as exc:
        return {"error": str(exc), "answer": "", "citations": []}
