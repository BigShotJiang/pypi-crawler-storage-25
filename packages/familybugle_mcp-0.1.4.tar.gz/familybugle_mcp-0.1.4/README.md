# familybugle-mcp

Model Context Protocol server for Park City Families — plug Family Bugle into Claude Desktop, Cursor, or any MCP-compatible client.

```
Claude: "Find ski camps for my 7-year-old in Park City"
→ calls search("ski camps", type="activity", filters={age: 7})
→ returns Youth Ski Camp, Basin Rec Snowsports, Park City Mountain Kids Camp
→ "Here are three ski camps available this winter..."
```

## Install

No installation required. Use `uvx` to run directly:

```bash
uvx familybugle-mcp
```

Or install permanently:

```bash
pip install familybugle-mcp
```

## Claude Desktop

Add to `~/Library/Application Support/Claude/claude_desktop_config.json` (macOS) or `%APPDATA%\Claude\claude_desktop_config.json` (Windows):

```json
{
  "mcpServers": {
    "familybugle": {
      "command": "uvx",
      "args": ["familybugle-mcp"],
      "env": {
        "FAMILYBUGLE_API_KEY": "fb_live_YOUR_KEY_HERE"
      }
    }
  }
}
```

Restart Claude Desktop after saving. You'll see "familybugle" in the tools panel.

## Cursor

Add to `.cursor/mcp.json` in your project root, or `~/.cursor/mcp.json` globally:

```json
{
  "mcpServers": {
    "familybugle": {
      "command": "uvx",
      "args": ["familybugle-mcp"],
      "env": {
        "FAMILYBUGLE_API_KEY": "fb_live_YOUR_KEY_HERE"
      }
    }
  }
}
```

## API Key

The server works without a key (public tier: 100 requests/hour). For higher limits, get a free key:

1. Sign in at [familybugle.com/account](https://familybugle.com/account) — Developer tab
2. Click **Create API key**, copy the `fb_live_...` value
3. Paste into the `env.FAMILYBUGLE_API_KEY` field in your config

See [familybugle.com/ai](https://familybugle.com/ai) for rate limit details.

## The 5 Tools

| Tool | What it does |
|------|-------------|
| `search` | Search activities and providers by keyword. Optional filters: age, category, location, date range, price. Returns up to 10 compact results. |
| `get` | Fetch full details for a specific activity or provider by id. Use after `search` to get the complete record. |
| `ask` | Ask a natural-language question about Park City family life. Returns an answer with source citations. |
| `school_breaks` | List upcoming school calendar breaks (spring break, holidays, teacher days) ordered by start date. |
| `tuition` | Get tuition rate schedules for a daycare or school by provider id. Use `search` first to find the id. |

**Combined tool schemas < 2500 tokens** — designed to be lean so you don't burn context budget just loading the server.

## Example prompts

```
"Find indoor activities for a 4-year-old this weekend"
"What daycares are available in Old Town Park City?"
"When is spring break and what camps are available?"
"Compare ski lessons for ages 6-10"
"What's the price range for swimming lessons?"
```

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `FAMILYBUGLE_API_KEY` | (none) | API key for authenticated tier |
| `FAMILYBUGLE_API_URL` | `https://api.familybugle.com` | Override API base URL (for local dev) |

## Local development

Point at a local backend:

```json
{
  "mcpServers": {
    "familybugle": {
      "command": "uvx",
      "args": ["familybugle-mcp"],
      "env": {
        "FAMILYBUGLE_API_URL": "http://localhost:8000"
      }
    }
  }
}
```

## Links

- [Developer hub](https://familybugle.com/ai) — MCP config, API docs, key management
- [Interactive API reference](https://familybugle.com/ai/reference) — try every endpoint in the browser
- [Family Bugle](https://familybugle.com) — the full site for Park City families
- [GitHub](https://github.com/park-city-families/familybugle-mcp) — source code
