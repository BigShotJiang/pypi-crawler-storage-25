"""
Total Recall — On-chain memory infrastructure for AI agents.
https://www.totalrecallagent.com
"""

from .client import TotalRecallClient, TotalRecallError, MemoryEntry

__all__ = ["TotalRecallClient", "TotalRecallError", "MemoryEntry"]
__version__ = "0.2.0"
