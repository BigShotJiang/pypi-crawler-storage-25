# ============================================================
# Total Recall — LangChain Integration
# Drop-in memory layer for LangChain agents
# https://www.totalrecallagent.com
# ============================================================
#
# Requires: pip install total-recall langchain-core
#

from __future__ import annotations

from typing import Any, Optional

from .client import TotalRecallClient

try:
    from langchain_core.memory import BaseMemory
    from langchain_core.messages import (
        AIMessage,
        BaseMessage,
        HumanMessage,
        SystemMessage,
    )
    _LANGCHAIN_AVAILABLE = True
except ImportError:
    _LANGCHAIN_AVAILABLE = False
    BaseMemory = object  # fallback so class definition doesn't crash


class TotalRecallMemory(BaseMemory):
    """
    LangChain-compatible memory backend powered by Total Recall on-chain storage.

    Drop this into any LangChain agent or chain to give it persistent,
    encrypted memory that survives across sessions — stored on ICP.

    Usage::

        from total_recall.langchain import TotalRecallMemory
        from langchain_openai import ChatOpenAI
        from langchain.chains import ConversationChain

        memory = TotalRecallMemory(
            api_key="tr_...",
            session_key="my_agent_session",
        )

        chain = ConversationChain(
            llm=ChatOpenAI(),
            memory=memory,
            verbose=True,
        )

        chain.predict(input="What's my last task?")

    The memory persists across Python processes, machine restarts, and
    model/provider changes. Your agent always remembers.
    """

    # LangChain BaseMemory requires these as class-level Pydantic fields,
    # but we implement via __init__ for simplicity.

    class Config:
        arbitrary_types_allowed = True

    def __init__(
        self,
        api_key:          str,
        *,
        session_key:      str = "lc_memory",
        memory_key:       str = "history",
        input_key:        Optional[str] = None,
        output_key:       Optional[str] = None,
        max_history:      int = 50,
        return_messages:  bool = True,
        **kwargs,
    ):
        """
        Args:
            api_key:         Total Recall API key.
            session_key:     Key under which conversation history is stored.
                             Use unique keys per agent/user to isolate sessions.
            memory_key:      Key used in the chain's input/output dict (default: "history").
            input_key:       Override the input variable name from the chain.
            output_key:      Override the output variable name from the chain.
            max_history:     Maximum number of messages to retain (rolling window).
            return_messages: If True, return list of BaseMessage; else return str.
        """
        if not _LANGCHAIN_AVAILABLE:
            raise ImportError(
                "langchain-core is required. Install it with: "
                "pip install total-recall[langchain]"
            )
        super().__init__(**kwargs)
        self._client       = TotalRecallClient(api_key=api_key)
        self._session_key  = session_key
        self._memory_key   = memory_key
        self._input_key    = input_key
        self._output_key   = output_key
        self._max_history  = max_history
        self._return_msgs  = return_messages
        self._cache: Optional[list] = None  # local cache to reduce calls

    # ── BaseMemory Interface ─────────────────────────────────

    @property
    def memory_variables(self) -> list[str]:
        return [self._memory_key]

    def load_memory_variables(self, inputs: dict[str, Any]) -> dict[str, Any]:
        """Load conversation history from Total Recall."""
        messages = self._load_messages()
        if self._return_msgs:
            return {self._memory_key: messages}
        return {self._memory_key: self._messages_to_str(messages)}

    def save_context(self, inputs: dict[str, Any], outputs: dict[str, Any]) -> None:
        """Persist the latest input/output turn to Total Recall."""
        human_text = self._extract(inputs,  self._input_key,  ["input", "human_input", "question"])
        ai_text    = self._extract(outputs, self._output_key, ["output", "response", "answer", "text"])

        messages = self._load_messages()
        messages.append({"role": "human", "content": human_text})
        messages.append({"role": "ai",    "content": ai_text})

        # Rolling window — keep last N messages
        if self._max_history and len(messages) > self._max_history:
            messages = messages[-self._max_history:]

        self._save_messages(messages)

    def clear(self) -> None:
        """Wipe conversation history for this session key."""
        self._client.delete(self._session_key)
        self._cache = None

    # ── Helpers ──────────────────────────────────────────────

    def _load_messages(self) -> list[dict]:
        if self._cache is not None:
            return list(self._cache)
        raw = self._client.get_json(self._session_key)
        messages = raw.get("messages", []) if isinstance(raw, dict) else []
        self._cache = messages
        return list(messages)

    def _save_messages(self, messages: list[dict]) -> None:
        self._client.store_json(
            self._session_key,
            {"messages": messages},
            tags=["langchain", "conversation"],
        )
        self._cache = messages

    @staticmethod
    def _messages_to_str(messages: list[dict]) -> str:
        lines = []
        for m in messages:
            role = "Human" if m["role"] == "human" else "AI"
            lines.append(f"{role}: {m['content']}")
        return "\n".join(lines)

    @staticmethod
    def _to_base_messages(messages: list[dict]) -> list[BaseMessage]:
        result = []
        for m in messages:
            if m["role"] == "human":
                result.append(HumanMessage(content=m["content"]))
            elif m["role"] == "ai":
                result.append(AIMessage(content=m["content"]))
            else:
                result.append(SystemMessage(content=m["content"]))
        return result

    def _load_messages(self) -> list[dict]:  # noqa: F811
        if self._cache is not None:
            return list(self._cache)
        raw = self._client.get_json(self._session_key)
        messages = raw.get("messages", []) if isinstance(raw, dict) else []
        self._cache = messages
        return list(messages)

    def load_memory_variables(self, inputs: dict[str, Any]) -> dict[str, Any]:  # noqa: F811
        messages = self._load_messages()
        if self._return_msgs:
            return {self._memory_key: self._to_base_messages(messages)}
        return {self._memory_key: self._messages_to_str(messages)}

    @staticmethod
    def _extract(d: dict, explicit_key: Optional[str], fallbacks: list[str]) -> str:
        if explicit_key and explicit_key in d:
            return str(d[explicit_key])
        for k in fallbacks:
            if k in d:
                return str(d[k])
        # Last resort: first value
        return str(next(iter(d.values()), ""))
