# Daimyo - Rules Server for Agents

Daimyo (大名) is an extensible Python server providing rules to AI agents through REST and MCP interfaces. Supports scope-based rules with inheritance, categories for filtering, and server federation for distributed rule management.

## Features

- **Multiple Interfaces**: REST API, MCP (Model Context Protocol), and CLI
- **Scope Inheritance**: Single and multiple parent inheritance with priority-based conflict resolution
- **Rule Types**: Commandments (MUST) and Suggestions (SHOULD)
- **Categories**: Organize rules into hierarchical categories for selective retrieval
- **Server Federation**: Distribute scopes across multiple servers with automatic merging
- **Multiple Formats**: Output as YAML, JSON, or Markdown
- **Clean Architecture**: Domain-driven design with clear separation of concerns
- **Templating System**: Rules can use Jinja2 templates to be defined as generic rules that change their form depending on the context
- **Extensibility via Plugins**: Plugins can extend the features of daimyo instances
- **Configurable Markdown Formatting**: Prologues/epilogues, XML tag wrapping, and aggregated display modes

## Installation

```bash
pip install daimyo
```

Or install from source:

```bash
git clone https://gitlab.com/Kencho1/daimyo.git
cd daimyo
pip install -e .
```

## Quick Start

### 1. Set Up Your Rules

```bash
mkdir -p .daimyo
cp -r example-daimyo-rules .daimyo/rules
```

### 2. Start the Server

```bash
daimyo serve
```

### 3. Access the API

Visit http://localhost:8000/docs for interactive API documentation.

```bash
curl http://localhost:8000/api/v1/scopes/python-general/rules
```

## Core Concepts

Rules are organized into **scopes** (e.g. company, team, project), each containing **commandments** (MUST) and **suggestions** (SHOULD). Scopes can inherit from parent scopes and organize rules into hierarchical **categories** for selective retrieval. Multiple servers can be federated to distribute scopes across deployments.

## Documentation

Full documentation is available at **https://daimyo.readthedocs.io/en/latest**, including:

- [Configuration reference](https://daimyo.readthedocs.io/en/latest/configuration/)
- [REST API & MCP usage](https://daimyo.readthedocs.io/en/latest/usage/)
- [Scope and category design best practices](https://daimyo.readthedocs.io/en/latest/best-practices/)
- [Advanced topics](https://daimyo.readthedocs.io/en/latest/advanced/) (federation, templates, sharding)
- [Plugin system](https://daimyo.readthedocs.io/en/latest/plugins/)
- [CLI reference](https://daimyo.readthedocs.io/en/latest/cli/)

## Development

### Running Tests

```bash
pip install -e ".[test]"
pytest
```

### Code Quality

```bash
mypy daimyo
ruff check daimyo
ruff format daimyo
```

## License

MIT
