"""Git plugins for Daimyo.

Provides Git repository information to Jinja2 templates.
"""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from git import GitCommandError, InvalidGitRepositoryError, Repo

from daimyo.domain import ContextProviderPlugin, FilterProviderPlugin, MergedScope


def _parse_git_url_domain(url: str | None) -> tuple[str | None, str | None]:
    """Parse Git URL and extract domain with and without port.

    :param url: Git URL (http/https/ssh format)
    :type url: str | None
    :returns: Tuple of (domain_with_port, domain_without_port)
    :rtype: tuple[str | None, str | None]
    """
    if not url:
        return None, None

    if url.startswith("git@"):
        parts = url.split("@")[1].split(":", 1)
        if parts:
            host = parts[0]
            if ":" in host:
                domain_without_port = host.rsplit(":", 1)[0]
                return host, domain_without_port
            return host, host
        return None, None

    parsed = urlparse(url)
    if not parsed.hostname:
        return None, None

    domain_without_port = parsed.hostname

    if parsed.port:
        domain_with_port = f"{parsed.hostname}:{parsed.port}"
    else:
        domain_with_port = parsed.hostname

    return domain_with_port, domain_without_port


class GitContextPlugin(ContextProviderPlugin):
    """Provides Git repository context for templates.

    Only available when running inside a Git repository.
    """

    @property
    def name(self) -> str:
        return "git.context"

    @property
    def description(self) -> str:
        return "Provides Git repository context for templates"

    def is_available(self) -> bool:
        """Check if cwd is inside a Git repository.

        :returns: True if cwd is inside a git repository
        :rtype: bool
        """
        try:
            Repo(Path.cwd(), search_parent_directories=True)
            return True
        except (InvalidGitRepositoryError, GitCommandError):
            return False

    def get_context(self, scope: MergedScope) -> dict[str, Any]:
        """Return Git repository context variables.

        :param scope: The merged scope being rendered
        :type scope: MergedScope
        :returns: Dictionary with Git repository information
        :rtype: dict[str, Any]
        """
        try:
            repo = Repo(Path.cwd(), search_parent_directories=True)

            try:
                branch = repo.active_branch.name
            except TypeError:
                branch = "HEAD"

            commit = repo.head.commit
            commit_sha = commit.hexsha
            commit_short = commit_sha[:7]

            author_name = commit.author.name
            author_email = commit.author.email

            try:
                remote = repo.remote()
                remote_name = remote.name
                remote_url = next(remote.urls, None)

                try:
                    push_url = remote.config_reader.get_value("pushurl", default=None)
                except Exception:
                    push_url = None
            except (ValueError, AttributeError):
                remote_name = None
                remote_url = None
                push_url = None

            remote_domain, remote_domain_no_port = _parse_git_url_domain(remote_url)
            push_domain, push_domain_no_port = _parse_git_url_domain(push_url)

            is_clean = not repo.is_dirty(untracked_files=True)

            try:
                tags = [tag.name for tag in repo.tags if tag.commit == commit]
                current_tag = tags[0] if tags else None
            except (GitCommandError, AttributeError):
                current_tag = None

            git_root = str(repo.working_dir)

            return {
                "git_branch": branch,
                "git_commit": commit_short,
                "git_commit_full": commit_sha,
                "git_author": author_name,
                "git_author_email": author_email,
                "git_remote": remote_url,
                "git_remote_name": remote_name,
                "git_remote_domain": remote_domain,
                "git_remote_domain_no_port": remote_domain_no_port,
                "git_push_url": push_url,
                "git_push_domain": push_domain,
                "git_push_domain_no_port": push_domain_no_port,
                "git_is_clean": is_clean,
                "git_tag": current_tag,
                "git_root": git_root,
            }
        except Exception:
            return {}


class GitFiltersPlugin(FilterProviderPlugin):
    """Provides Git-related Jinja2 filters and tests.

    Only available when running inside a Git repository.
    """

    @property
    def name(self) -> str:
        return "git.filters"

    @property
    def description(self) -> str:
        return "Provides Git-related Jinja2 filters and tests"

    def is_available(self) -> bool:
        """Check if cwd is inside a Git repository.

        :returns: True if cwd is inside a git repository
        :rtype: bool
        """
        try:
            Repo(Path.cwd(), search_parent_directories=True)
            return True
        except (InvalidGitRepositoryError, GitCommandError):
            return False

    def get_filters(self) -> dict[str, Callable[..., Any]]:
        """Return Git-related Jinja2 filters.

        :returns: Dictionary of filter name to callable
        :rtype: dict[str, Callable[..., Any]]
        """

        def git_short_sha(sha: str, length: int = 7) -> str:
            return sha[:length] if sha else ""

        def git_branch_name(ref: str) -> str:
            if ref.startswith("refs/heads/"):
                return ref[len("refs/heads/"):]
            return ref

        return {
            "git_short_sha": git_short_sha,
            "git_branch_name": git_branch_name,
        }

    def get_tests(self) -> dict[str, Callable[..., Any]]:
        """Return Git-related Jinja2 tests.

        :returns: Dictionary of test name to callable
        :rtype: dict[str, Callable[..., Any]]
        """

        def is_git_repo(path: str = ".") -> bool:
            try:
                Repo(path, search_parent_directories=False)
                return True
            except (InvalidGitRepositoryError, GitCommandError):
                return False

        def is_clean() -> bool:
            try:
                repo = Repo(Path.cwd(), search_parent_directories=True)
                return not repo.is_dirty(untracked_files=True)
            except (InvalidGitRepositoryError, GitCommandError):
                return False

        def has_uncommitted() -> bool:
            try:
                repo = Repo(Path.cwd(), search_parent_directories=True)
                return repo.is_dirty(untracked_files=True)
            except (InvalidGitRepositoryError, GitCommandError):
                return False

        def on_branch(branch_name: str) -> bool:
            try:
                repo = Repo(Path.cwd(), search_parent_directories=True)
                return repo.active_branch.name == branch_name
            except (TypeError, InvalidGitRepositoryError, GitCommandError):
                return False

        def has_remote(remote_name: str = "origin") -> bool:
            try:
                repo = Repo(Path.cwd(), search_parent_directories=True)
                return remote_name in [r.name for r in repo.remotes]
            except (InvalidGitRepositoryError, GitCommandError):
                return False

        return {
            "is_git_repo": is_git_repo,
            "is_clean": is_clean,
            "has_uncommitted": has_uncommitted,
            "on_branch": on_branch,
            "has_remote": has_remote,
        }
