"""Project metadata plugin for Daimyo.

Provides project metadata from .project-metadata.yml for Jinja2 templates.
"""

from pathlib import Path
from typing import Any

import yaml

from daimyo.domain import ContextProviderPlugin, MergedScope


class ProjectMetadataContextPlugin(ContextProviderPlugin):
    """Provides project metadata from .project-metadata.yml for templates.

    Reads the .project-metadata.yml file from the current working directory
    and exposes its contents as the ``project_metadata`` template variable.
    If the file does not exist, an empty dict is returned.
    """

    @property
    def name(self) -> str:
        return "prjmeta.context"

    @property
    def description(self) -> str:
        return "Provides project metadata from .project-metadata.yml for templates"

    def is_available(self) -> bool:
        """Always available."""
        return True

    def get_context(self, scope: MergedScope) -> dict[str, Any]:
        """Return project metadata context variables.

        :param scope: The merged scope being rendered
        :type scope: MergedScope
        :returns: Dictionary containing ``project_metadata`` key with parsed YAML content
        :rtype: dict[str, Any]
        """
        metadata_file = Path.cwd() / ".project-metadata.yml"

        if not metadata_file.exists():
            return {"project_metadata": {}}

        data = yaml.safe_load(metadata_file.read_text())
        return {"project_metadata": data or {}}
