"""Built-in plugins bundled with Daimyo."""
