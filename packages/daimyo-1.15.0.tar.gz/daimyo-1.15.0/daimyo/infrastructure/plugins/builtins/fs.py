"""Filesystem plugins for Daimyo.

Provides filesystem and system information to Jinja2 templates with security constraints.
All path operations are validated to prevent directory traversal attacks.
"""

import os
import platform
import socket
from collections.abc import Callable
from pathlib import Path
from typing import Any

from daimyo.domain import ContextProviderPlugin, FilterProviderPlugin, MergedScope


class FilesystemContextPlugin(ContextProviderPlugin):
    """Provides filesystem and system context for templates.

    Security: Only exposes safe context variables within the current working directory.
    Does NOT expose home_dir or temp_dir to prevent access outside the project.
    """

    @property
    def name(self) -> str:
        return "fs.context"

    @property
    def description(self) -> str:
        return "Provides filesystem and system context for templates"

    def is_available(self) -> bool:
        """Always available."""
        return True

    def get_context(self, scope: MergedScope) -> dict[str, Any]:
        """Return filesystem and system context variables.

        :param scope: The merged scope being rendered
        :type scope: MergedScope
        :returns: Dictionary with safe filesystem and system variables
        :rtype: dict[str, Any]
        """
        cwd = Path.cwd()

        return {
            "cwd": str(cwd),
            "project_root": str(cwd),
            "path_separator": os.sep,
            "is_windows": platform.system() == "Windows",
            "is_linux": platform.system() == "Linux",
            "is_macos": platform.system() == "Darwin",
            "hostname": socket.gethostname(),
        }


class FilesystemFiltersPlugin(FilterProviderPlugin):
    """Provides filesystem-related Jinja2 filters and tests.

    Security: All path operations are validated to ensure they stay within the
    current working directory. Any attempt to access parent directories or
    absolute paths outside cwd will raise ValueError.
    """

    @property
    def name(self) -> str:
        return "fs.filters"

    @property
    def description(self) -> str:
        return "Provides filesystem-related Jinja2 filters and tests"

    def is_available(self) -> bool:
        """Always available."""
        return True

    def _validate_path(self, path: str | Path) -> Path:
        """Validate that a path is within the current working directory.

        :param path: Path to validate (relative or absolute)
        :type path: str | Path
        :returns: Resolved absolute Path object
        :rtype: Path
        :raises ValueError: If path escapes the current working directory
        """
        cwd = Path.cwd().resolve()
        target = Path(path).resolve()

        try:
            target.relative_to(cwd)
        except ValueError:
            raise ValueError(
                f"Path traversal attempt detected: '{path}' resolves outside "
                f"current working directory. Only paths within {cwd} are allowed."
            ) from None

        return target

    def get_filters(self) -> dict[str, Callable[..., Any]]:
        """Return filesystem-related Jinja2 filters.

        :returns: Dictionary of filter name to callable
        :rtype: dict[str, Callable[..., Any]]
        """

        def basename(path: str) -> str:
            return os.path.basename(path)

        def dirname(path: str) -> str:
            validated = self._validate_path(path)
            result = validated.parent
            self._validate_path(result)
            return str(result)

        def relpath(path: str, start: str = ".") -> str:
            validated_path = self._validate_path(path)
            validated_start = self._validate_path(start)
            return str(validated_path.relative_to(validated_start))

        def joinpath(*paths: str) -> str:
            if not paths:
                return ""
            result = Path(paths[0])
            for p in paths[1:]:
                result = result / p
            validated = self._validate_path(result)
            return str(validated)

        def normpath(path: str) -> str:
            normalized = os.path.normpath(path)
            validated = self._validate_path(normalized)
            return str(validated)

        return {
            "basename": basename,
            "dirname": dirname,
            "relpath": relpath,
            "joinpath": joinpath,
            "normpath": normpath,
        }

    def get_tests(self) -> dict[str, Callable[..., Any]]:
        """Return filesystem-related Jinja2 tests.

        :returns: Dictionary of test name to callable
        :rtype: dict[str, Callable[..., Any]]
        """

        def file_exists(path: str) -> bool:
            try:
                validated = self._validate_path(path)
                return validated.is_file()
            except (ValueError, OSError):
                return False

        def path_exists(path: str) -> bool:
            try:
                validated = self._validate_path(path)
                return validated.exists()
            except (ValueError, OSError):
                return False

        def is_directory(path: str) -> bool:
            try:
                validated = self._validate_path(path)
                return validated.is_dir()
            except (ValueError, OSError):
                return False

        def is_file(path: str) -> bool:
            try:
                validated = self._validate_path(path)
                return validated.is_file()
            except (ValueError, OSError):
                return False

        def is_relative(path: str) -> bool:
            return not Path(path).is_absolute()

        return {
            "file_exists": file_exists,
            "path_exists": path_exists,
            "is_directory": is_directory,
            "is_file": is_file,
            "is_relative": is_relative,
        }
