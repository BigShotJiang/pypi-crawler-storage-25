"""Update check utilities for Daimyo."""

import httpx

_PYPI_URL = "https://pypi.org/pypi/daimyo/json"


def fetch_latest_version() -> str | None:
    """Fetch the latest published version of daimyo from PyPI.

    :returns: Latest version string, or ``None`` if the check could not be completed.
    :rtype: str | None
    """
    try:
        response = httpx.get(_PYPI_URL, timeout=5, follow_redirects=True)
        response.raise_for_status()
        return str(response.json()["info"]["version"])
    except Exception:
        return None
