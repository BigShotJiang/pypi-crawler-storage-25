"""Tests for update check functionality."""

from __future__ import annotations

import pytest

from daimyo.application.update_check import fetch_latest_version


class TestFetchLatestVersion:
    """Tests for fetch_latest_version."""

    @pytest.mark.unit
    def test_returns_version_string_on_success(self, httpx_mock) -> None:
        """Returns version string when PyPI responds successfully."""
        httpx_mock.add_response(json={"info": {"version": "2.0.0"}})

        result = fetch_latest_version()

        assert result == "2.0.0"

    @pytest.mark.unit
    def test_returns_none_on_http_error(self, httpx_mock) -> None:
        """Returns None when PyPI returns an HTTP error."""
        httpx_mock.add_response(status_code=503)

        result = fetch_latest_version()

        assert result is None

    @pytest.mark.unit
    def test_returns_none_on_network_error(self, httpx_mock) -> None:
        """Returns None when the network is unreachable."""
        import httpx

        httpx_mock.add_exception(httpx.ConnectError("connection refused"))

        result = fetch_latest_version()

        assert result is None

    @pytest.mark.unit
    def test_returns_none_on_timeout(self, httpx_mock) -> None:
        """Returns None when the request times out."""
        import httpx

        httpx_mock.add_exception(httpx.TimeoutException("timed out"))

        result = fetch_latest_version()

        assert result is None

    @pytest.mark.unit
    def test_returns_none_on_missing_version_key(self, httpx_mock) -> None:
        """Returns None when the JSON response lacks the expected structure."""
        httpx_mock.add_response(json={"unexpected": "structure"})

        result = fetch_latest_version()

        assert result is None

    @pytest.mark.unit
    def test_returns_none_on_invalid_json(self, httpx_mock) -> None:
        """Returns None when the response body is not valid JSON."""
        httpx_mock.add_response(text="not json", status_code=200)

        result = fetch_latest_version()

        assert result is None
