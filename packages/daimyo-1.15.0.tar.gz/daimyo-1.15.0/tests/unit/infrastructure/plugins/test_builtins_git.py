"""Tests for the built-in Git plugins."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from daimyo.infrastructure.plugins.builtins.git import (
    GitContextPlugin,
    GitFiltersPlugin,
    _parse_git_url_domain,
)


class TestParseGitUrlDomain:
    """Tests for _parse_git_url_domain helper."""

    @pytest.mark.unit
    @pytest.mark.parametrize(
        "url, expected_with_port, expected_no_port",
        [
            (None, None, None),
            ("", None, None),
            ("https://github.com/user/repo.git", "github.com", "github.com"),
            ("https://gitlab.com:8443/user/repo.git", "gitlab.com:8443", "gitlab.com"),
            ("git@github.com:user/repo.git", "github.com", "github.com"),
            ("git@gitlab.example.com:user/repo.git", "gitlab.example.com", "gitlab.example.com"),
            ("http://localhost:3000/user/repo.git", "localhost:3000", "localhost"),
        ],
    )
    def test_parse_git_url_domain(
        self,
        url: str | None,
        expected_with_port: str | None,
        expected_no_port: str | None,
    ) -> None:
        """Parses domain correctly from various Git URL formats."""
        result_with, result_no = _parse_git_url_domain(url)

        assert result_with == expected_with_port
        assert result_no == expected_no_port


class TestGitContextPlugin:
    """Tests for GitContextPlugin."""

    @pytest.fixture
    def plugin(self) -> GitContextPlugin:
        """Create plugin instance."""
        return GitContextPlugin()

    @pytest.mark.unit
    def test_name(self, plugin: GitContextPlugin) -> None:
        """Plugin name is git.context."""
        assert plugin.name == "git.context"

    @pytest.mark.unit
    def test_description_is_non_empty(self, plugin: GitContextPlugin) -> None:
        """Plugin has a non-empty description."""
        assert plugin.description

    @pytest.mark.unit
    def test_is_available_inside_git_repo(self, plugin: GitContextPlugin) -> None:
        """Plugin is available when cwd is a git repository."""
        with patch(
            "daimyo.infrastructure.plugins.builtins.git.Repo"
        ) as mock_repo_cls:
            mock_repo_cls.return_value = MagicMock()
            assert plugin.is_available() is True

    @pytest.mark.unit
    def test_is_not_available_outside_git_repo(self, plugin: GitContextPlugin) -> None:
        """Plugin is unavailable when cwd is not a git repository."""
        from git import InvalidGitRepositoryError

        with patch(
            "daimyo.infrastructure.plugins.builtins.git.Repo",
            side_effect=InvalidGitRepositoryError,
        ):
            assert plugin.is_available() is False

    @pytest.mark.unit
    def test_get_context_returns_expected_keys(self, plugin: GitContextPlugin) -> None:
        """get_context returns all expected git context keys."""
        mock_repo = MagicMock()
        mock_repo.active_branch.name = "main"
        mock_repo.head.commit.hexsha = "abc1234def5678901234567890123456789012345"
        mock_repo.head.commit.author.name = "Alice"
        mock_repo.head.commit.author.email = "alice@example.com"
        mock_remote = MagicMock()
        mock_remote.name = "origin"
        mock_remote.urls = iter(["https://github.com/user/repo.git"])
        mock_remote.config_reader.get_value.return_value = None
        mock_repo.remote.return_value = mock_remote
        mock_repo.is_dirty.return_value = False
        mock_repo.tags = []
        mock_repo.working_dir = "/some/path"

        with patch(
            "daimyo.infrastructure.plugins.builtins.git.Repo", return_value=mock_repo
        ):
            context = plugin.get_context(None)  # type: ignore[arg-type]

        expected_keys = {
            "git_branch",
            "git_commit",
            "git_commit_full",
            "git_author",
            "git_author_email",
            "git_remote",
            "git_remote_name",
            "git_remote_domain",
            "git_remote_domain_no_port",
            "git_push_url",
            "git_push_domain",
            "git_push_domain_no_port",
            "git_is_clean",
            "git_tag",
            "git_root",
        }
        assert set(context.keys()) == expected_keys

    @pytest.mark.unit
    def test_get_context_short_commit_is_7_chars(self, plugin: GitContextPlugin) -> None:
        """git_commit is the 7-char short SHA."""
        mock_repo = MagicMock()
        mock_repo.active_branch.name = "main"
        mock_repo.head.commit.hexsha = "abc1234def5678901234567890123456789012345"
        mock_repo.head.commit.author.name = "Alice"
        mock_repo.head.commit.author.email = "alice@example.com"
        mock_repo.remote.side_effect = ValueError
        mock_repo.is_dirty.return_value = False
        mock_repo.tags = []
        mock_repo.working_dir = "/some/path"

        with patch(
            "daimyo.infrastructure.plugins.builtins.git.Repo", return_value=mock_repo
        ):
            context = plugin.get_context(None)  # type: ignore[arg-type]

        assert context["git_commit"] == "abc1234"

    @pytest.mark.unit
    def test_get_context_returns_empty_dict_on_error(self, plugin: GitContextPlugin) -> None:
        """get_context returns empty dict when an unexpected error occurs."""
        with patch(
            "daimyo.infrastructure.plugins.builtins.git.Repo",
            side_effect=RuntimeError("unexpected"),
        ):
            context = plugin.get_context(None)  # type: ignore[arg-type]

        assert context == {}

    @pytest.mark.unit
    def test_get_context_detached_head_falls_back(self, plugin: GitContextPlugin) -> None:
        """Branch name falls back to 'HEAD' in detached HEAD state."""
        mock_repo = MagicMock()
        type(mock_repo.active_branch).name = property(
            MagicMock(side_effect=TypeError("detached HEAD"))
        )
        mock_repo.head.commit.hexsha = "abc1234def5678"
        mock_repo.head.commit.author.name = "Alice"
        mock_repo.head.commit.author.email = "alice@example.com"
        mock_repo.remote.side_effect = ValueError
        mock_repo.is_dirty.return_value = False
        mock_repo.tags = []
        mock_repo.working_dir = "/some/path"

        with patch(
            "daimyo.infrastructure.plugins.builtins.git.Repo", return_value=mock_repo
        ):
            context = plugin.get_context(None)  # type: ignore[arg-type]

        assert context["git_branch"] == "HEAD"


class TestGitFiltersPlugin:
    """Tests for GitFiltersPlugin."""

    @pytest.fixture
    def plugin(self) -> GitFiltersPlugin:
        """Create plugin instance."""
        return GitFiltersPlugin()

    @pytest.mark.unit
    def test_name(self, plugin: GitFiltersPlugin) -> None:
        """Plugin name is git.filters."""
        assert plugin.name == "git.filters"

    @pytest.mark.unit
    def test_get_filters_returns_expected_keys(self, plugin: GitFiltersPlugin) -> None:
        """get_filters returns all expected filter names."""
        filters = plugin.get_filters()

        assert set(filters.keys()) == {"git_short_sha", "git_branch_name"}

    @pytest.mark.unit
    def test_get_tests_returns_expected_keys(self, plugin: GitFiltersPlugin) -> None:
        """get_tests returns all expected test names."""
        tests = plugin.get_tests()

        assert set(tests.keys()) == {
            "is_git_repo",
            "is_clean",
            "has_uncommitted",
            "on_branch",
            "has_remote",
        }

    @pytest.mark.unit
    @pytest.mark.parametrize(
        "sha, length, expected",
        [
            ("abc1234def5678", 7, "abc1234"),
            ("abc1234def5678", 4, "abc1"),
            ("abc1234def5678", 40, "abc1234def5678"),
            ("", 7, ""),
        ],
    )
    def test_git_short_sha_filter(
        self,
        plugin: GitFiltersPlugin,
        sha: str,
        length: int,
        expected: str,
    ) -> None:
        """git_short_sha truncates SHA to specified length."""
        filters = plugin.get_filters()

        assert filters["git_short_sha"](sha, length) == expected

    @pytest.mark.unit
    @pytest.mark.parametrize(
        "ref, expected",
        [
            ("refs/heads/main", "main"),
            ("refs/heads/feature/foo", "feature/foo"),
            ("main", "main"),
            ("HEAD", "HEAD"),
        ],
    )
    def test_git_branch_name_filter(
        self, plugin: GitFiltersPlugin, ref: str, expected: str
    ) -> None:
        """git_branch_name strips the refs/heads/ prefix."""
        filters = plugin.get_filters()

        assert filters["git_branch_name"](ref) == expected

    @pytest.mark.unit
    def test_is_git_repo_returns_true_for_valid_repo(self, plugin: GitFiltersPlugin) -> None:
        """is_git_repo returns True when path is a git repository."""
        with patch(
            "daimyo.infrastructure.plugins.builtins.git.Repo"
        ) as mock_repo_cls:
            mock_repo_cls.return_value = MagicMock()
            tests = plugin.get_tests()

            assert tests["is_git_repo"](".") is True

    @pytest.mark.unit
    def test_is_git_repo_returns_false_for_non_repo(self, plugin: GitFiltersPlugin) -> None:
        """is_git_repo returns False when path is not a git repository."""
        from git import InvalidGitRepositoryError

        with patch(
            "daimyo.infrastructure.plugins.builtins.git.Repo",
            side_effect=InvalidGitRepositoryError,
        ):
            tests = plugin.get_tests()

            assert tests["is_git_repo"](".") is False
