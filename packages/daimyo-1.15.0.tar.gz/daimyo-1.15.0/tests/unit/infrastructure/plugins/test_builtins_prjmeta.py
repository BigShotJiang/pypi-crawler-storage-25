"""Tests for the built-in project metadata plugin."""

from __future__ import annotations

import pytest

from daimyo.infrastructure.plugins.builtins.prjmeta import ProjectMetadataContextPlugin


class TestProjectMetadataContextPlugin:
    """Tests for ProjectMetadataContextPlugin."""

    @pytest.fixture
    def plugin(self) -> ProjectMetadataContextPlugin:
        """Create plugin instance."""
        return ProjectMetadataContextPlugin()

    @pytest.mark.unit
    def test_name(self, plugin: ProjectMetadataContextPlugin) -> None:
        """Plugin name is prjmeta.context."""
        assert plugin.name == "prjmeta.context"

    @pytest.mark.unit
    def test_description_is_non_empty(self, plugin: ProjectMetadataContextPlugin) -> None:
        """Plugin has a non-empty description."""
        assert plugin.description

    @pytest.mark.unit
    def test_is_always_available(self, plugin: ProjectMetadataContextPlugin) -> None:
        """Plugin is always available regardless of environment."""
        assert plugin.is_available() is True

    @pytest.mark.unit
    def test_returns_empty_dict_when_file_missing(
        self, plugin: ProjectMetadataContextPlugin, tmp_path, monkeypatch
    ) -> None:
        """Returns empty project_metadata when .project-metadata.yml does not exist."""
        monkeypatch.chdir(tmp_path)

        context = plugin.get_context(None)  # type: ignore[arg-type]

        assert context == {"project_metadata": {}}

    @pytest.mark.unit
    def test_returns_parsed_yaml_when_file_exists(
        self, plugin: ProjectMetadataContextPlugin, tmp_path, monkeypatch
    ) -> None:
        """Returns parsed YAML content as project_metadata."""
        (tmp_path / ".project-metadata.yml").write_text("daimyo:\n  scope: test\n")
        monkeypatch.chdir(tmp_path)

        context = plugin.get_context(None)  # type: ignore[arg-type]

        assert context == {"project_metadata": {"daimyo": {"scope": "test"}}}

    @pytest.mark.unit
    def test_returns_empty_dict_for_empty_yaml_file(
        self, plugin: ProjectMetadataContextPlugin, tmp_path, monkeypatch
    ) -> None:
        """Returns empty project_metadata when .project-metadata.yml is empty."""
        (tmp_path / ".project-metadata.yml").write_text("")
        monkeypatch.chdir(tmp_path)

        context = plugin.get_context(None)  # type: ignore[arg-type]

        assert context == {"project_metadata": {}}
