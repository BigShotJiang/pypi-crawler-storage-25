"""Tests for the built-in filesystem plugins."""

from __future__ import annotations

import platform
import socket
from pathlib import Path

import pytest

from daimyo.infrastructure.plugins.builtins.fs import (
    FilesystemContextPlugin,
    FilesystemFiltersPlugin,
)


class TestFilesystemContextPlugin:
    """Tests for FilesystemContextPlugin."""

    @pytest.fixture
    def plugin(self) -> FilesystemContextPlugin:
        """Create plugin instance."""
        return FilesystemContextPlugin()

    @pytest.mark.unit
    def test_name(self, plugin: FilesystemContextPlugin) -> None:
        """Plugin name is fs.context."""
        assert plugin.name == "fs.context"

    @pytest.mark.unit
    def test_description_is_non_empty(self, plugin: FilesystemContextPlugin) -> None:
        """Plugin has a non-empty description."""
        assert plugin.description

    @pytest.mark.unit
    def test_is_always_available(self, plugin: FilesystemContextPlugin) -> None:
        """Plugin is always available."""
        assert plugin.is_available() is True

    @pytest.mark.unit
    def test_context_contains_cwd(self, plugin: FilesystemContextPlugin) -> None:
        """Context includes cwd equal to the current working directory."""
        context = plugin.get_context(None)  # type: ignore[arg-type]

        assert context["cwd"] == str(Path.cwd())

    @pytest.mark.unit
    def test_context_project_root_equals_cwd(self, plugin: FilesystemContextPlugin) -> None:
        """project_root is the same as cwd."""
        context = plugin.get_context(None)  # type: ignore[arg-type]

        assert context["project_root"] == context["cwd"]

    @pytest.mark.unit
    def test_context_contains_hostname(self, plugin: FilesystemContextPlugin) -> None:
        """Context includes the system hostname."""
        context = plugin.get_context(None)  # type: ignore[arg-type]

        assert context["hostname"] == socket.gethostname()

    @pytest.mark.unit
    def test_context_platform_flags_are_exclusive(self, plugin: FilesystemContextPlugin) -> None:
        """Exactly one platform flag is True."""
        context = plugin.get_context(None)  # type: ignore[arg-type]

        flags = [context["is_windows"], context["is_linux"], context["is_macos"]]
        assert sum(flags) == 1

    @pytest.mark.unit
    def test_context_platform_flag_matches_system(self, plugin: FilesystemContextPlugin) -> None:
        """Platform flag matches the actual OS."""
        context = plugin.get_context(None)  # type: ignore[arg-type]
        system = platform.system()

        assert context["is_windows"] == (system == "Windows")
        assert context["is_linux"] == (system == "Linux")
        assert context["is_macos"] == (system == "Darwin")


class TestFilesystemFiltersPlugin:
    """Tests for FilesystemFiltersPlugin."""

    @pytest.fixture
    def plugin(self) -> FilesystemFiltersPlugin:
        """Create plugin instance."""
        return FilesystemFiltersPlugin()

    @pytest.mark.unit
    def test_name(self, plugin: FilesystemFiltersPlugin) -> None:
        """Plugin name is fs.filters."""
        assert plugin.name == "fs.filters"

    @pytest.mark.unit
    def test_is_always_available(self, plugin: FilesystemFiltersPlugin) -> None:
        """Plugin is always available."""
        assert plugin.is_available() is True

    @pytest.mark.unit
    def test_get_filters_returns_expected_keys(self, plugin: FilesystemFiltersPlugin) -> None:
        """get_filters returns all expected filter names."""
        filters = plugin.get_filters()

        assert set(filters.keys()) == {"basename", "dirname", "relpath", "joinpath", "normpath"}

    @pytest.mark.unit
    def test_get_tests_returns_expected_keys(self, plugin: FilesystemFiltersPlugin) -> None:
        """get_tests returns all expected test names."""
        tests = plugin.get_tests()

        assert set(tests.keys()) == {
            "file_exists",
            "path_exists",
            "is_directory",
            "is_file",
            "is_relative",
        }

    @pytest.mark.unit
    def test_basename_filter(self, plugin: FilesystemFiltersPlugin) -> None:
        """basename returns the filename component."""
        filters = plugin.get_filters()

        assert filters["basename"]("/some/path/file.txt") == "file.txt"

    @pytest.mark.unit
    def test_is_relative_test_with_relative_path(self, plugin: FilesystemFiltersPlugin) -> None:
        """is_relative returns True for a relative path."""
        tests = plugin.get_tests()

        assert tests["is_relative"]("relative/path") is True

    @pytest.mark.unit
    def test_is_relative_test_with_absolute_path(self, plugin: FilesystemFiltersPlugin) -> None:
        """is_relative returns False for an absolute path."""
        tests = plugin.get_tests()

        assert tests["is_relative"]("/absolute/path") is False

    @pytest.mark.unit
    @pytest.mark.parametrize(
        "path, expected",
        [
            ("existing_file.txt", True),
            ("nonexistent_file.txt", False),
        ],
    )
    def test_file_exists_test(
        self, plugin: FilesystemFiltersPlugin, tmp_path, monkeypatch, path: str, expected: bool
    ) -> None:
        """file_exists returns True only when the file exists."""
        monkeypatch.chdir(tmp_path)
        if expected:
            (tmp_path / path).touch()
        tests = plugin.get_tests()

        assert tests["file_exists"](path) is expected

    @pytest.mark.unit
    def test_path_traversal_raises_value_error(self, plugin: FilesystemFiltersPlugin) -> None:
        """_validate_path raises ValueError for paths escaping cwd."""
        with pytest.raises(ValueError, match="Path traversal attempt detected"):
            plugin._validate_path("../../etc/passwd")

    @pytest.mark.unit
    @pytest.mark.parametrize(
        "check_name, path, expected_result",
        [
            ("file_exists", "../../etc/passwd", False),
            ("path_exists", "../../etc", False),
            ("is_directory", "../../etc", False),
            ("is_file", "../../etc/passwd", False),
        ],
    )
    def test_tests_return_false_on_traversal_attempt(
        self, plugin: FilesystemFiltersPlugin, check_name: str, path: str, expected_result: bool
    ) -> None:
        """Filesystem tests return False (not raise) for traversal paths."""
        tests = plugin.get_tests()

        assert tests[check_name](path) is expected_result

    @pytest.mark.unit
    def test_is_directory_test(
        self, plugin: FilesystemFiltersPlugin, tmp_path, monkeypatch
    ) -> None:
        """is_directory returns True for an existing directory within cwd."""
        monkeypatch.chdir(tmp_path)
        subdir = tmp_path / "subdir"
        subdir.mkdir()
        tests = plugin.get_tests()

        assert tests["is_directory"]("subdir") is True
        assert tests["is_directory"]("nonexistent") is False

    @pytest.mark.unit
    def test_joinpath_filter(
        self, plugin: FilesystemFiltersPlugin, tmp_path, monkeypatch
    ) -> None:
        """joinpath combines path components when the result is within cwd."""
        monkeypatch.chdir(tmp_path)
        subdir = tmp_path / "a"
        subdir.mkdir()
        filters = plugin.get_filters()

        result = filters["joinpath"](str(tmp_path), "a")
        assert result == str(tmp_path / "a")

    @pytest.mark.unit
    def test_joinpath_raises_on_traversal(
        self, plugin: FilesystemFiltersPlugin, tmp_path, monkeypatch
    ) -> None:
        """joinpath raises ValueError when result escapes cwd."""
        monkeypatch.chdir(tmp_path)
        filters = plugin.get_filters()

        with pytest.raises(ValueError, match="Path traversal attempt detected"):
            filters["joinpath"](str(tmp_path), "..", "outside")

    @pytest.mark.unit
    def test_joinpath_returns_empty_for_no_args(self, plugin: FilesystemFiltersPlugin) -> None:
        """joinpath returns empty string when called with no arguments."""
        filters = plugin.get_filters()

        assert filters["joinpath"]() == ""
