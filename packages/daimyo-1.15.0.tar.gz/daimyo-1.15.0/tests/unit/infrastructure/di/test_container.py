"""Tests for SSL configuration propagation in ServiceContainer."""

from unittest.mock import MagicMock, patch

import pytest

from daimyo.infrastructure.di.container import ServiceContainer


class TestServiceContainerSSL:
    """Tests verifying SSL settings are passed from ServiceContainer to HttpRemoteScopeClient."""

    def _get_client_ssl_kwargs(self, **container_overrides: object) -> dict:
        """Instantiate ServiceContainer, call remote_client(), and return the SSL kwargs
        passed to HttpRemoteScopeClient.

        :param container_overrides: Keyword arguments forwarded to ServiceContainer
        :returns: Dict with 'ssl_verify' and 'ssl_ca_bundle' keys
        :rtype: dict
        """
        with patch("daimyo.infrastructure.di.container.HttpRemoteScopeClient") as mock_cls:
            mock_cls.return_value = MagicMock()
            container = ServiceContainer(**container_overrides)
            container.remote_client()
            _, ctor_kwargs = mock_cls.call_args
            return {"ssl_verify": ctor_kwargs["ssl_verify"], "ssl_ca_bundle": ctor_kwargs["ssl_ca_bundle"]}

    @pytest.mark.parametrize(
        ("container_overrides", "expected_ssl_verify", "expected_ca_bundle"),
        [
            (
                {"remote_ssl_verify": False, "remote_ssl_ca_bundle": ""},
                False,
                "",
            ),
            (
                {"remote_ssl_verify": True, "remote_ssl_ca_bundle": "/etc/ssl/company-ca.pem"},
                True,
                "/etc/ssl/company-ca.pem",
            ),
            (
                {"remote_ssl_verify": True, "remote_ssl_ca_bundle": ""},
                True,
                "",
            ),
        ],
    )
    def test_ssl_settings_propagated_to_client(
        self,
        container_overrides: dict,
        expected_ssl_verify: bool,
        expected_ca_bundle: str,
    ) -> None:
        """SSL settings passed to ServiceContainer are forwarded to HttpRemoteScopeClient."""
        result = self._get_client_ssl_kwargs(**container_overrides)
        assert result["ssl_verify"] == expected_ssl_verify
        assert result["ssl_ca_bundle"] == expected_ca_bundle

    def test_default_ssl_settings_from_config(self) -> None:
        """When no SSL overrides are given, ServiceContainer reads defaults from settings."""
        with patch("daimyo.infrastructure.di.container.settings") as mock_settings:
            mock_settings.RULES_PATH = ".daimyo/rules"
            mock_settings.REMOTE_TIMEOUT_SECONDS = 5
            mock_settings.REMOTE_MAX_RETRIES = 3
            mock_settings.REMOTE_SSL_VERIFY = True
            mock_settings.REMOTE_SSL_CA_BUNDLE = ""
            mock_settings.MAX_INHERITANCE_DEPTH = 10
            result = self._get_client_ssl_kwargs()
        assert result["ssl_verify"] is True
        assert result["ssl_ca_bundle"] == ""

    def test_ssl_verify_false_from_config(self) -> None:
        """When settings.REMOTE_SSL_VERIFY is False, container passes ssl_verify=False."""
        with patch("daimyo.infrastructure.di.container.settings") as mock_settings:
            mock_settings.RULES_PATH = ".daimyo/rules"
            mock_settings.REMOTE_TIMEOUT_SECONDS = 5
            mock_settings.REMOTE_MAX_RETRIES = 3
            mock_settings.REMOTE_SSL_VERIFY = False
            mock_settings.REMOTE_SSL_CA_BUNDLE = ""
            mock_settings.MAX_INHERITANCE_DEPTH = 10
            result = self._get_client_ssl_kwargs()
        assert result["ssl_verify"] is False

    def test_ca_bundle_from_config(self) -> None:
        """When settings.REMOTE_SSL_CA_BUNDLE is set, container passes it to the client."""
        with patch("daimyo.infrastructure.di.container.settings") as mock_settings:
            mock_settings.RULES_PATH = ".daimyo/rules"
            mock_settings.REMOTE_TIMEOUT_SECONDS = 5
            mock_settings.REMOTE_MAX_RETRIES = 3
            mock_settings.REMOTE_SSL_VERIFY = True
            mock_settings.REMOTE_SSL_CA_BUNDLE = "/from/config/ca.pem"
            mock_settings.MAX_INHERITANCE_DEPTH = 10
            result = self._get_client_ssl_kwargs()
        assert result["ssl_verify"] is True
        assert result["ssl_ca_bundle"] == "/from/config/ca.pem"
