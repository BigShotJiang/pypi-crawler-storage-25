# CLAUDE.md — Quell v0.6.0

> This is the implementation spec for the new core direction.
> Everything in v0.5.0 (OAuth, PySpark, PR mode, --no-llm) stays.
> This file describes what to ADD on top of it.

---

## The Core Shift

v0.5.0 failed on real production code because it looked for
docstrings and type annotations. Real code has neither.

v0.6.0 reads the code itself. Every `if/raise`, every null check,
every guard clause is a requirement written in Python.
No docstrings needed. No Pydantic needed. Just the code.

---

## How Quell v0.6.0 Is Different From Every Competitor

| Tool | Finds logic gaps | Generates failing test | Suggests fix | Verifies fix works |
|------|-----------------|----------------------|--------------|-------------------|
| Snyk | ✅ security only | ❌ | ❌ | ❌ |
| Semgrep | ✅ security only | ❌ | ❌ | ❌ |
| CodeRabbit | ✅ PR review | ❌ | ❌ | ❌ |
| Corgea | ✅ logic + auth | ❌ | ✅ auto-PR | ❌ |
| Refactron | ❌ style only | ❌ | ✅ safe fix | ✅ |
| **Quell** | ✅ guard clauses | ✅ verified | ✅ LLM | ✅ two-phase |

**The exact gap Quell fills:**
Nobody generates a failing test that PROVES a logic gap exists,
then suggests a fix, then verifies the test passes after the fix.

**How it differs from Refactron:**
- Refactron input: linter output (style issues)
  Quell input: the code itself (business logic)
- Refactron output: style fix (formatting, imports, lint errors)
  Quell output: failing test + logic/security fix + proof it works
- Refactron scope: syntax level
  Quell scope: semantic level (business logic, security, correctness)

Refactron never touches business logic.
Quell never touches style.

---

## The Three-Step Loop (New Core Architecture)

```
STEP 1 — FIND
  Read production code via AST
  Detect guard clauses: if/raise, null checks, auth guards, etc.
  Classify each as a requirement

STEP 2 — PROVE (existing verifier, reused)
  Generate a failing test that proves the gap exists
  Run test: must FAIL on current code (proves vulnerability)
  This is the "test first" — you can see the bug before any fix

STEP 3 — FIX (new)
  LLM suggests a code change for the gap
  Shows diff — never auto-applies
  Run test: must PASS after applying the fix
  If test passes: fix is verified
  If test still fails: fix is rejected, try again
```

The key: every fix comes with proof. Not a suggestion. Proof.

---

## New File: `quell/spec/code_guard_reader.py`

This replaces the docstring reader as the PRIMARY reader.
Works on every Python file ever written.

```python
"""
Reads production code and extracts logic requirements from guard clauses.

What it detects (AST patterns):

Pattern 1: if condition: raise
  if amount <= 0:
      raise ValueError("must be positive")
  → BOUNDARY requirement: amount must be > 0

Pattern 2: if x is None: raise / return
  if user is None:
      raise ValueError("user not found")
  → NOT_NULL requirement: user must not be None

Pattern 3: if x not in collection: raise
  if currency not in VALID_CURRENCIES:
      raise ValueError("invalid currency")
  → ENUM_VALID requirement: currency must be in set

Pattern 4: assert statement
  assert amount > 0, "must be positive"
  → BOUNDARY requirement: amount must be > 0

Pattern 5: isinstance check with raise
  if not isinstance(amount, (int, float)):
      raise TypeError("must be numeric")
  → TYPE_CHECK requirement: amount must be numeric

Pattern 6: auth/permission check
  if not request.user.is_authenticated:
      raise PermissionError("login required")
  → AUTH requirement: user must be authenticated

Pattern 7: bare except / broad except (security smell)
  except Exception:
      pass
  → BARE_EXCEPT smell: catches everything silently

Pattern 8: empty return on failure
  if not result:
      return None   (without raising)
  → SILENT_FAILURE smell: fails silently, should raise

Pattern 9: hardcoded values in conditions
  if status == "admin":   # magic string
  → MAGIC_VALUE smell: hardcoded string in condition

Returns [] on any error — never raises.
No LLM. Pure AST. Works on every Python file.
"""
from __future__ import annotations
import ast
import uuid
from pathlib import Path
from quell.core.models import Requirement, ConstraintKind, SpecSource


class CodeGuardReader:
    """
    Primary reader for v0.6.0.
    Reads production code guards directly from AST.
    Zero config. Zero docstrings. Zero types needed.
    """

    def read(self, file_path: Path) -> list[Requirement]:
        try:
            source = file_path.read_text(encoding="utf-8")
            tree = ast.parse(source)
        except Exception:
            return []

        requirements = []
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                requirements.extend(
                    self._scan_function(node, file_path, source)
                )
        return requirements

    def _scan_function(
        self, func: ast.FunctionDef, path: Path, source: str
    ) -> list[Requirement]:
        reqs = []
        lines = source.splitlines()

        for node in ast.walk(func):
            # Pattern 1, 3, 4, 6: if <condition>: raise
            if isinstance(node, ast.If):
                raise_nodes = [
                    n for n in node.body
                    if isinstance(n, ast.Raise)
                ]
                if raise_nodes:
                    req = self._classify_if_raise(
                        node, raise_nodes[0], func, path, lines
                    )
                    if req:
                        reqs.append(req)

            # Pattern 4: assert
            if isinstance(node, ast.Assert):
                req = self._classify_assert(node, func, path, lines)
                if req:
                    reqs.append(req)

            # Pattern 7: bare except
            if isinstance(node, ast.ExceptHandler):
                if node.type is None:  # bare except:
                    reqs.append(self._bare_except_smell(node, func, path, lines))

        return reqs

    def _classify_if_raise(
        self,
        if_node: ast.If,
        raise_node: ast.Raise,
        func: ast.FunctionDef,
        path: Path,
        lines: list[str],
    ) -> Requirement | None:
        test = if_node.test
        raw = lines[if_node.lineno - 1].strip() if if_node.lineno <= len(lines) else ""

        # Pattern: if x is None or if not x
        if self._is_null_check(test):
            return Requirement(
                id=str(uuid.uuid4())[:8],
                description=f"must not be None — {raw}",
                constraint_kind=ConstraintKind.NOT_NULL,
                source=SpecSource.CODE_GUARD,
                target_function=func.name,
                target_file=path,
                raw_spec_text=raw,
                violation_input=self._extract_null_input(test),
            )

        # Pattern: if x <= 0 or if x < 0 or if x == 0 (boundary)
        if self._is_boundary_check(test):
            return Requirement(
                id=str(uuid.uuid4())[:8],
                description=f"boundary condition — {raw}",
                constraint_kind=ConstraintKind.BOUNDARY,
                source=SpecSource.CODE_GUARD,
                target_function=func.name,
                target_file=path,
                raw_spec_text=raw,
                violation_input=self._extract_boundary_input(test),
            )

        # Pattern: if x not in [...] (enum)
        if self._is_enum_check(test):
            return Requirement(
                id=str(uuid.uuid4())[:8],
                description=f"must be valid value — {raw}",
                constraint_kind=ConstraintKind.ENUM_VALID,
                source=SpecSource.CODE_GUARD,
                target_function=func.name,
                target_file=path,
                raw_spec_text=raw,
                violation_input=self._extract_enum_input(test),
            )

        # Pattern: if not isinstance(x, Type) (type check)
        if self._is_isinstance_check(test):
            return Requirement(
                id=str(uuid.uuid4())[:8],
                description=f"type check — {raw}",
                constraint_kind=ConstraintKind.TYPE_CHECK,
                source=SpecSource.CODE_GUARD,
                target_function=func.name,
                target_file=path,
                raw_spec_text=raw,
            )

        # Pattern: auth/permission check
        if self._is_auth_check(raw):
            return Requirement(
                id=str(uuid.uuid4())[:8],
                description=f"auth/permission check — {raw}",
                constraint_kind=ConstraintKind.AUTH_CHECK,
                source=SpecSource.CODE_GUARD,
                target_function=func.name,
                target_file=path,
                raw_spec_text=raw,
            )

        # Generic if/raise we couldn't classify
        return Requirement(
            id=str(uuid.uuid4())[:8],
            description=f"guard clause — {raw}",
            constraint_kind=ConstraintKind.CUSTOM,
            source=SpecSource.CODE_GUARD,
            target_function=func.name,
            target_file=path,
            raw_spec_text=raw,
        )

    def _classify_assert(
        self, node: ast.Assert, func: ast.FunctionDef, path: Path, lines: list[str]
    ) -> Requirement | None:
        raw = lines[node.lineno - 1].strip() if node.lineno <= len(lines) else ""
        if self._is_boundary_check(node.test):
            return Requirement(
                id=str(uuid.uuid4())[:8],
                description=f"assert boundary — {raw}",
                constraint_kind=ConstraintKind.BOUNDARY,
                source=SpecSource.CODE_GUARD,
                target_function=func.name,
                target_file=path,
                raw_spec_text=raw,
            )
        return Requirement(
            id=str(uuid.uuid4())[:8],
            description=f"assert — {raw}",
            constraint_kind=ConstraintKind.CUSTOM,
            source=SpecSource.CODE_GUARD,
            target_function=func.name,
            target_file=path,
            raw_spec_text=raw,
        )

    def _bare_except_smell(
        self, node: ast.ExceptHandler, func: ast.FunctionDef, path: Path, lines: list[str]
    ) -> Requirement:
        raw = lines[node.lineno - 1].strip() if node.lineno <= len(lines) else ""
        return Requirement(
            id=str(uuid.uuid4())[:8],
            description=f"bare except catches all errors silently — {raw}",
            constraint_kind=ConstraintKind.BARE_EXCEPT,
            source=SpecSource.CODE_GUARD,
            target_function=func.name,
            target_file=path,
            raw_spec_text=raw,
        )

    # ── helpers ─────────────────────────────────────────────────────────────

    def _is_null_check(self, test: ast.expr) -> bool:
        # x is None
        if isinstance(test, ast.Compare):
            for op in test.ops:
                if isinstance(op, (ast.Is, ast.IsNot)):
                    return True
        # not x
        if isinstance(test, ast.UnaryOp) and isinstance(test.op, ast.Not):
            return True
        return False

    def _is_boundary_check(self, test: ast.expr) -> bool:
        if isinstance(test, ast.Compare):
            for op in test.ops:
                if isinstance(op, (ast.Lt, ast.LtE, ast.Gt, ast.GtE, ast.Eq, ast.NotEq)):
                    return True
        return False

    def _is_enum_check(self, test: ast.expr) -> bool:
        # x not in [...]
        if isinstance(test, ast.Compare):
            for op in test.ops:
                if isinstance(op, ast.NotIn):
                    return True
        # not (x in [...])
        if isinstance(test, ast.UnaryOp) and isinstance(test.op, ast.Not):
            if isinstance(test.operand, ast.Compare):
                for op in test.operand.ops:
                    if isinstance(op, ast.In):
                        return True
        return False

    def _is_isinstance_check(self, test: ast.expr) -> bool:
        if isinstance(test, ast.UnaryOp) and isinstance(test.op, ast.Not):
            if isinstance(test.operand, ast.Call):
                func = test.operand.func
                if isinstance(func, ast.Name) and func.id == "isinstance":
                    return True
        return False

    def _is_auth_check(self, raw: str) -> bool:
        auth_keywords = [
            "authenticated", "authorized", "permission",
            "is_admin", "is_staff", "has_role",
            "token", "api_key", "auth",
        ]
        raw_lower = raw.lower()
        return any(kw in raw_lower for kw in auth_keywords)

    def _extract_null_input(self, test: ast.expr) -> dict | None:
        # Try to extract variable name being null-checked
        if isinstance(test, ast.Compare) and test.comparators:
            if isinstance(test.left, ast.Name):
                return {test.left.id: None}
        if isinstance(test, ast.UnaryOp) and isinstance(test.operand, ast.Name):
            return {test.operand.id: None}
        return None

    def _extract_boundary_input(self, test: ast.expr) -> dict | None:
        if isinstance(test, ast.Compare):
            if isinstance(test.left, ast.Name) and test.comparators:
                comparator = test.comparators[0]
                if isinstance(comparator, ast.Constant):
                    return {
                        "variable": test.left.id,
                        "boundary_value": comparator.value,
                    }
        return None

    def _extract_enum_input(self, test: ast.expr) -> dict | None:
        if isinstance(test, ast.Compare):
            if isinstance(test.left, ast.Name):
                for comp in test.comparators:
                    if isinstance(comp, (ast.List, ast.Tuple, ast.Set)):
                        values = [
                            elt.value for elt in comp.elts
                            if isinstance(elt, ast.Constant)
                        ]
                        return {"variable": test.left.id, "valid_values": values}
        return None

    @property
    def source_name(self) -> str:
        return "code_guard"
```

---

## Model Changes: Add to `quell/core/models.py`

```python
# Add to SpecSource enum:
CODE_GUARD = "code_guard"   # read from if/raise patterns in code

# Add to ConstraintKind enum:
AUTH_CHECK   = "auth_check"   # authentication/permission guard
BARE_EXCEPT  = "bare_except"  # bare except: smell
SILENT_FAIL  = "silent_fail"  # returns None instead of raising
MAGIC_VALUE  = "magic_value"  # hardcoded string/int in condition
```

---

## New File: `quell/fix/suggester.py`

```python
"""
LLM-powered code fix suggester.

ONLY runs after a verified failing test exists.
Never suggests a fix without first proving the bug with a test.

Flow:
  1. CodeGuardReader finds a gap (no test for this guard)
  2. Verifier generates + proves a failing test
  3. Suggester asks LLM for a code fix
  4. Suggester verifies: apply fix → test must now PASS
  5. Show diff to developer — never auto-apply

Different from Refactron:
  Refactron: linter output → safe style fix (syntax level)
  Suggester: logic gap + failing test → logic/security fix (semantic level)

Different from Corgea:
  Corgea: finds bug → auto-generates fix PR (no test proof)
  Suggester: finds bug → PROVES it with failing test → suggests fix
             → VERIFIES fix makes test pass → shows diff

You never apply a fix that isn't proven to work.
"""
from __future__ import annotations
import subprocess
import shutil
import time
import re
from pathlib import Path
from quell.core.models import (
    Requirement, GeneratedTest, VerificationResult,
    VerificationStatus, QuellConfig
)
from quell.llm.client import LLMClient


class FixSuggestion:
    def __init__(
        self,
        requirement: Requirement,
        failing_test: GeneratedTest,
        original_code: str,
        suggested_code: str,
        diff: str,
        verified: bool,
        explanation: str,
    ):
        self.requirement = requirement
        self.failing_test = failing_test
        self.original_code = original_code
        self.suggested_code = suggested_code
        self.diff = diff
        self.verified = verified
        self.explanation = explanation


class FixSuggester:
    """
    Suggests code fixes after a failing test is proven to exist.
    
    The test MUST be verified as failing before this is called.
    This ensures every suggestion has proven value.
    """

    def __init__(self, llm: LLMClient, config: QuellConfig):
        self.llm = llm
        self.config = config

    async def suggest(
        self,
        req: Requirement,
        failing_test: GeneratedTest,
    ) -> FixSuggestion | None:
        """
        Given a requirement with a failing test, suggest a code fix.
        Returns None if no good fix can be generated.
        """
        original_source = req.target_file.read_text()
        function_source = self._extract_function(original_source, req.target_function)

        prompt = self._build_prompt(req, failing_test, function_source)
        response = await self.llm.generate(prompt)
        suggested_function = self._extract_code_block(response)
        explanation = self._extract_explanation(response)

        if not suggested_function:
            return None

        # Apply the fix and verify the test now passes
        suggested_source = original_source.replace(
            function_source, suggested_function
        )
        verified = self._verify_fix_makes_test_pass(
            req, failing_test, suggested_source
        )

        diff = self._generate_diff(function_source, suggested_function)

        return FixSuggestion(
            requirement=req,
            failing_test=failing_test,
            original_code=function_source,
            suggested_code=suggested_function,
            diff=diff,
            verified=verified,
            explanation=explanation,
        )

    def _build_prompt(
        self, req: Requirement, test: GeneratedTest, function_source: str
    ) -> str:
        return f"""You are a Python security and correctness expert.

A test has PROVEN that this code has a logic gap:

FAILING TEST (proves the bug exists):
```python
{test.test_code}
```

CURRENT FUNCTION WITH THE GAP:
```python
{function_source}
```

GAP DESCRIPTION: {req.description}
GAP TYPE: {req.constraint_kind.value}
RAW GUARD: {req.raw_spec_text}

YOUR TASK:
Suggest a fix for the function that makes the failing test pass.

RULES:
- Fix ONLY the specific logic gap, nothing else
- Do NOT change function signature
- Do NOT add imports that don't exist in the file  
- Do NOT change behavior for valid inputs
- For security gaps: add the missing validation/check
- For null gaps: add None check with appropriate raise
- For boundary gaps: add the missing boundary check
- Keep the fix minimal — smallest change that fixes the gap

RESPONSE FORMAT:
First, one sentence explaining what the fix does.
Then the fixed function in a Python code block.

```python
# fixed function here
```"""

    def _verify_fix_makes_test_pass(
        self,
        req: Requirement,
        test: GeneratedTest,
        suggested_source: str,
    ) -> bool:
        """
        Apply the suggested fix to a temp file and run the failing test.
        The test must now PASS — proving the fix works.
        """
        backup_dir = self.config.backup_dir
        backup_dir.mkdir(parents=True, exist_ok=True)

        # Write suggested source to temp file
        temp_source = backup_dir / f"quell_fix_{req.id}.py"
        temp_test = backup_dir / f"quell_fix_test_{req.id}.py"

        original = req.target_file.read_text()
        try:
            req.target_file.write_text(suggested_source)
            temp_test.write_text(test.test_code)

            result = subprocess.run(
                ["python", "-m", "pytest", str(temp_test), "-v", "-q"],
                capture_output=True,
                text=True,
                timeout=self.config.verification_timeout_seconds,
                cwd=req.target_file.parent.parent,
            )
            return result.returncode == 0

        except Exception:
            return False
        finally:
            # ALWAYS restore original
            req.target_file.write_text(original)
            temp_test.unlink(missing_ok=True)
            temp_source.unlink(missing_ok=True)

    def _extract_function(self, source: str, function_name: str) -> str:
        """Extract just the function source from a file."""
        import ast
        try:
            tree = ast.parse(source)
            lines = source.splitlines(keepends=True)
            for node in ast.walk(tree):
                if (
                    isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
                    and node.name == function_name
                ):
                    return "".join(lines[node.lineno - 1 : node.end_lineno])
        except Exception:
            pass
        return source  # fallback: whole file

    def _generate_diff(self, original: str, suggested: str) -> str:
        """Generate a unified diff string."""
        import difflib
        diff = difflib.unified_diff(
            original.splitlines(keepends=True),
            suggested.splitlines(keepends=True),
            fromfile="original",
            tofile="suggested",
            lineterm="",
        )
        return "".join(diff)

    def _extract_code_block(self, response: str) -> str | None:
        match = re.search(r'```python\n(.*?)```', response, re.DOTALL)
        return match.group(1).strip() if match else None

    def _extract_explanation(self, response: str) -> str:
        lines = response.strip().splitlines()
        for line in lines:
            if line.strip() and not line.strip().startswith("```"):
                return line.strip()
        return "Fix suggested by Quell"
```

---

## New CLI Command: `quell scan`

This is the primary entry point for v0.6.0.
Replaces `quell check` as the headline command for production code.

```python
@app.command("scan")
def scan(
    target: Path = typer.Argument(Path("."), help="File or directory to scan"),
    fix: bool = typer.Option(False, "--fix", help="Generate tests for each gap"),
    suggest: bool = typer.Option(False, "--suggest", help="Also suggest code fixes via LLM"),
    no_llm: bool = typer.Option(False, "--no-llm", help="Rule-based only, no LLM"),
    project_root: Path = typer.Option(Path("."), "--root"),
):
    """
    Scan production code for untested logic gaps.

    Reads your if/raise patterns — no docstrings or types needed.
    Works on any Python file ever written.

    quell scan src/                  # find all logic gaps
    quell scan src/ --fix            # find gaps + generate failing tests
    quell scan src/ --fix --suggest  # find gaps + tests + suggest fixes
    quell scan src/ --no-llm         # rule-based only, zero network
    """
    asyncio.run(_scan_async(target, fix, suggest, no_llm, project_root))


async def _scan_async(target, fix, suggest, no_llm, project_root):
    from quell.spec.code_guard_reader import CodeGuardReader
    from quell.coverage.checker import CoverageChecker
    from quell.synthesis.rule_engine import RuleEngine
    from quell.synthesis.llm_engine import LLMSynthesizer
    from quell.core.verifier import Verifier
    from quell.core.writer import Writer
    from quell.core.models import VerificationStatus, QuellConfig
    from quell.llm.client import LLMClient

    config = _load_config(project_root)

    files = (
        [f for f in target.rglob("*.py")
         if "test" not in f.name and ".venv" not in str(f)
         and "__pycache__" not in str(f)]
        if target.is_dir() else [target]
    )

    console.print(Panel.fit(
        f"[bold blue]Quell Scan[/bold blue] — "
        f"reading guard clauses in {len(files)} file(s)\n"
        f"[dim]No docstrings needed. Reading your if/raise patterns.[/dim]"
    ))

    reader = CodeGuardReader()
    checker = CoverageChecker(project_root)
    rule_engine = RuleEngine()

    all_requirements = []
    for f in files:
        reqs = reader.read(f)
        all_requirements.extend(reqs)

    if not all_requirements:
        console.print("[yellow]No guard clauses found.[/yellow]")
        console.print("[dim]Quell reads if/raise patterns. If your code has none, nothing to check.[/dim]")
        return

    all_requirements = checker.check(all_requirements)
    gaps = [r for r in all_requirements if not r.is_covered]
    covered = [r for r in all_requirements if r.is_covered]

    # Display scan results
    table = Table(title=f"Logic Gaps Found ({len(gaps)} untested / {len(all_requirements)} total)")
    table.add_column("File", style="blue")
    table.add_column("Function", style="cyan")
    table.add_column("Guard Clause", style="white")
    table.add_column("Type", style="magenta")
    table.add_column("Method", style="dim")

    for req in gaps:
        tag = "[dim][rule-based, no network][/dim]"
        table.add_row(
            req.target_file.name,
            req.target_function,
            req.raw_spec_text[:50] if req.raw_spec_text else req.description[:50],
            req.constraint_kind.value,
            tag,
        )

    console.print(table)

    if not gaps:
        console.print("[green]✓ All guard clauses are tested.[/green]")
        return

    if not fix:
        console.print(
            f"\n[yellow]Run [bold]quell scan {target} --fix[/bold] to generate failing tests.[/yellow]"
        )
        if suggest:
            console.print(
                "[yellow]Add [bold]--suggest[/bold] to also get LLM-powered fix suggestions.[/yellow]"
            )
        return

    # Generate tests + optional fix suggestions
    llm = None if no_llm else LLMClient.from_config(config)
    synthesizer = None if no_llm else LLMSynthesizer(llm, config)
    verifier = Verifier(config)
    writer = Writer(config)

    if suggest and no_llm:
        console.print("[yellow]--suggest requires LLM. Ignoring --no-llm for suggestions.[/yellow]")
        llm = LLMClient.from_config(config)

    fixed = 0
    llm_used = False

    for i, req in enumerate(gaps, 1):
        console.print(f"\n[{i}/{len(gaps)}] [cyan]{req.target_function}()[/cyan] — {req.description[:60]}")
        console.print(f"  Guard: [dim]{req.raw_spec_text}[/dim]")

        # Generate test
        if rule_engine.can_handle(req):
            candidate = rule_engine.generate(req)
            generated_by_tag = "[dim][rule-based, no network][/dim]"
        elif synthesizer:
            candidate = await synthesizer.synthesize(req)
            generated_by_tag = "[dim][llm][/dim]"
            llm_used = True
        else:
            console.print("  [dim]Skipped (needs LLM, use without --no-llm)[/dim]")
            continue

        if not candidate:
            continue

        # Verify test fails on current code (proves the gap)
        with console.status("Verifying test fails on current code (proving gap)..."):
            result = verifier.verify(req, candidate)

        if result.status == VerificationStatus.VERIFIED:
            console.print(f"  [green]✓ Gap proven[/green] — test fails on current code {generated_by_tag}")
            console.print(Syntax(candidate.test_code, "python", theme="monokai"))

            # Suggest fix if requested
            if suggest and llm:
                from quell.fix.suggester import FixSuggester
                suggester = FixSuggester(llm, config)

                with console.status("Generating fix suggestion..."):
                    fix_suggestion = await suggester.suggest(req, candidate)

                if fix_suggestion and fix_suggestion.verified:
                    console.print("\n  [bold green]✓ Fix suggestion (verified to make test pass):[/bold green]")
                    console.print(f"  {fix_suggestion.explanation}")
                    console.print(Syntax(fix_suggestion.diff, "diff", theme="monokai"))

                    apply = typer.confirm("  Apply this fix?", default=False)
                    if apply:
                        req.target_file.write_text(
                            req.target_file.read_text().replace(
                                fix_suggestion.original_code,
                                fix_suggestion.suggested_code,
                            )
                        )
                        console.print("  [green]✓ Fix applied[/green]")
                elif fix_suggestion:
                    console.print("  [yellow]⚠ Fix suggested but not verified — review manually[/yellow]")
                    console.print(Syntax(fix_suggestion.diff, "diff", theme="monokai"))

            # Write the test
            write = typer.confirm("  Write this test?", default=True)
            if write:
                if writer.write(candidate, req.id):
                    console.print(f"  [green]✓ Test written to {candidate.test_file_path.name}[/green]")
                    fixed += 1

        elif result.status == VerificationStatus.DOESNT_CATCH_VIOLATION:
            console.print("  [yellow]⚠ Test generated but doesn't catch the gap — needs manual review[/yellow]")
        elif result.status == VerificationStatus.FAILS_ON_CORRECT:
            console.print("  [red]✗ Generated test breaks correct code — rejected[/red]")

    # Summary
    console.print(Panel.fit(
        f"[bold]Done![/bold] {fixed}/{len(gaps)} gaps have failing tests written\n"
        f"{'[dim]Your code never left your machine.[/dim]' if not llm_used else '[dim]LLM used for complex cases — only function signatures sent.[/dim]'}"
    ))
```

---

## Updated `quell check` — Keep for Types/Docstrings

`quell check` stays for type annotation and docstring users.
`quell scan` is the new primary command for production code.

Add this to the check command help:

```python
# In quell check command docstring:
"""
Check requirement coverage from type annotations and docstrings.

For production code without types/docstrings, use: quell scan
quell scan reads your if/raise patterns directly — no annotations needed.
"""
```

---

## CLI Output for `quell scan` — What Developers See

```
Quell v0.6.0  •  quell.buildsbyshashank.tech
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Quell Scan — reading guard clauses in 4 file(s)
No docstrings needed. Reading your if/raise patterns.

┌─────────────────────────────────────────────────────────────────┐
│ Logic Gaps Found (5 untested / 8 total)                         │
├──────────────┬──────────────────┬────────────────────┬──────────┤
│ File         │ Function         │ Guard Clause       │ Type     │
├──────────────┼──────────────────┼────────────────────┼──────────┤
│ payments.py  │ process_payment  │ if amount <= 0:    │ boundary │
│ payments.py  │ process_payment  │ if currency not in │ enum     │
│ auth.py      │ validate_token   │ if token is None:  │ not_null │
│ users.py     │ get_user         │ except Exception:  │ bare_exc │
│ orders.py    │ create_order     │ if not user.auth.. │ auth     │
└──────────────┴──────────────────┴────────────────────┴──────────┘

Run: quell scan src/ --fix            → generate failing tests
Run: quell scan src/ --fix --suggest  → tests + fix suggestions


[1/5] process_payment() — boundary condition — if amount <= 0:
  Guard: if amount <= 0: raise ValueError("Amount must be positive")

  ✓ Gap proven — test fails on current code [rule-based, no network]

  def test_quell_process_payment_boundary_a1b2c3d4():
      """Quell: boundary condition — if amount <= 0"""
      import pytest
      with pytest.raises(ValueError):
          process_payment(amount=0, currency="USD")

  ✓ Fix suggestion (verified to make test pass):
    Added validation: amount must be > 0 before processing

  --- original
  +++ suggested
  @@ -2,6 +2,8 @@
   def process_payment(amount: float, currency: str):
  +    if amount <= 0:
  +        raise ValueError(f"Amount must be positive, got {amount}")
       result = db.charge(amount)
       return result

  Apply this fix? [y/N]

Done! 5/5 gaps have failing tests written
Your code never left your machine.
```

---

## New File: `quell/fix/__init__.py`

```python
"""Fix suggestion module — suggests code changes for proven logic gaps."""
```

---

## Files to Create

```
quell/spec/code_guard_reader.py     ← primary reader, reads if/raise
quell/fix/__init__.py               ← empty init
quell/fix/suggester.py              ← LLM fix suggester with verification
```

## Files to Modify

```
quell/core/models.py
  + SpecSource.CODE_GUARD
  + ConstraintKind.AUTH_CHECK
  + ConstraintKind.BARE_EXCEPT
  + ConstraintKind.SILENT_FAIL
  + ConstraintKind.MAGIC_VALUE

quell/cli.py
  + quell scan command (full implementation above)
  + update quell check help to mention quell scan

pyproject.toml
  + bump version to 0.6.0
```

---

## What This Is vs Competitors

```
Snyk:      finds security bugs → shows them → you fix manually
Semgrep:   finds security bugs → shows them → you fix manually
CodeRabbit: reviews PRs → comments → you fix manually
Corgea:    finds bugs → auto-creates fix PR → no test proof
Refactron: linter says style issue → safely applies style fix

Quell:     reads if/raise in your code
           → generates failing test PROVING the gap exists
           → suggests fix via LLM
           → verifies fix makes test pass
           → shows diff, never auto-applies
           → developer approves both test and fix
```

Every other tool: find → report
Refactron: style find → style fix
Quell: logic find → prove with test → suggest fix → verify fix

---

## Implementation Order

1. `quell/core/models.py` — add new SpecSource and ConstraintKind values
2. `quell/spec/code_guard_reader.py` — create full implementation
3. `quell/fix/__init__.py` — empty file
4. `quell/fix/suggester.py` — create full implementation
5. `quell/cli.py` — add `quell scan` command
6. Write tests:
   - `tests/unit/test_code_guard_reader.py`
   - `tests/unit/test_fix_suggester.py`
7. Run on real production code (not fixtures):
   `quell scan quell/ --no-llm`
   Should find guard clauses in Quell's own source
8. Run with fix:
   `quell scan tests/fixtures/sample_project/src/ --fix --no-llm`
9. `uv run pytest tests/ -v`
10. Bump version to 0.6.0