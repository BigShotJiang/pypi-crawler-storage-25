"""2xPPg - Peer to Peer Playground.

Beginner-friendly helpers for building peer-to-peer systems.
"""

from .playground import Playground
from .state import SharedState

__all__ = ["Playground", "SharedState"]
__version__ = "0.1.0"
