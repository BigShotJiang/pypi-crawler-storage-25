"""Bundled package resources."""
