"""Bundled agent skills."""
