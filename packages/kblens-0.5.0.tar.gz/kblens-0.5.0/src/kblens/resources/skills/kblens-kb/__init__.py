"""Bundled kblens-kb skill."""
