from vulnly import main

main()
