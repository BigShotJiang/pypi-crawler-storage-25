from setuptools import setup, find_packages

setup(
    name="vulnly",
    version="0.1.0",
    description="Generate beautiful HTML vulnerability reports from Cloudsmith, Trivy, and Grype scan output",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Colin Moynes",
    license="Apache-2.0",
    python_requires=">=3.10",
    packages=find_packages(include=["vulnly*"]),
    package_data={"vulnly": ["report_template.html", "report_template_light.html"]},
    entry_points={
        "console_scripts": [
            "vulnly=vulnly:main",
        ],
    },
    keywords=["vulnerability", "security", "scanner", "report", "trivy", "grype", "cloudsmith"],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: System Administrators",
        "Programming Language :: Python :: 3",
        "Topic :: Security",
    ],
)
