"""Support `python -m ssg_bin` invocation."""
from ssg_bin import main

if __name__ == "__main__":
    main()
