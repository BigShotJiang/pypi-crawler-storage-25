"""
ssg — AI Agent Governance CLI meta-package.

Delegates to the platform-specific binary package installed for the current OS/arch.
"""

import os
import sys

__version__ = "0.4.0"

# Map (sys_platform, platform_machine) to the platform package name and binary path.
_PLATFORM_MAP = {
    ("linux", "x86_64"): ("ssg_linux_x64", "ssg"),
    ("linux", "aarch64"): ("ssg_linux_arm64", "ssg"),
    ("darwin", "arm64"): ("ssg_darwin_arm64", "ssg"),
    ("darwin", "x86_64"): ("ssg_darwin_x64", "ssg"),
    ("win32", "AMD64"): ("ssg_win32_x64", "ssg.exe"),
}


def _find_binary() -> str:
    """Return the absolute path to the ssg binary for the current platform."""
    key = (sys.platform, os.uname().machine if hasattr(os, "uname") else os.environ.get("PROCESSOR_ARCHITECTURE", "AMD64"))
    entry = _PLATFORM_MAP.get(key)
    if entry is None:
        raise RuntimeError(
            f"ssg: unsupported platform {sys.platform}/{key[1]}. "
            "See https://docs.sigmashake.com/cli for manual installation."
        )
    pkg_name, binary_name = entry
    try:
        pkg = __import__(pkg_name)
    except ImportError:
        raise RuntimeError(
            f"ssg: platform package '{pkg_name}' is not installed. "
            f"Try: pip install {pkg_name}"
        ) from None
    return pkg.BIN


def main() -> None:
    """Entry point: exec the native ssg binary, replacing this process."""
    binary = _find_binary()
    if not os.path.isfile(binary):
        raise RuntimeError(f"ssg binary not found at: {binary}")
    os.execv(binary, [binary] + sys.argv[1:])
