"""Command-line entrypoints for CyberDocExtractor.

The CLI depends on :mod:`typer` and :mod:`rich`, which live under the
``cli`` extra. The top-level :data:`app` attribute works either way —
if the dependencies are missing it becomes a function that prints a
clear install hint instead of raising an opaque :class:`ImportError`.
"""

from __future__ import annotations

import sys
from typing import Any

__all__ = ["app"]


def _cli_not_installed() -> None:
    """Fallback when ``cyberdocextractor[cli]`` extras are not installed."""
    message = (
        "The `cyberdoc` CLI requires optional dependencies.\n"
        "Install them with: pip install 'cyberdocextractor[cli]'"
    )
    print(message, file=sys.stderr)
    raise SystemExit(2)


app: Any
try:
    from ._app import app as _typer_app

    app = _typer_app
except ImportError:
    app = _cli_not_installed
