"""High-level factory for the default conversion pipeline.

Provides a single :func:`build_pipeline` convenience that wires sensible
defaults for every domain port:

- :class:`~cyberdocextractor.infra.DefaultPolicy` over all built-in
  extractors (lazy-imported — unavailable ones self-report via
  :meth:`~cyberdocextractor.domain.Extractor.supports`).
- :class:`~cyberdocextractor.infra.Jinja2Renderer` with an optional
  ``override_dir``.
- :class:`~cyberdocextractor.infra.HeuristicScorer` for quality scores.
- PDF + Office metadata probes.
- Optional :class:`~cyberdocextractor.infra.OpenAICompatibleImageDescriber`
  when the caller supplies an :class:`~cyberdocextractor.infra.LLMConfig`
  with a populated API key.

Advanced users who need fine-grained control should instantiate
:class:`~cyberdocextractor.app.ConversionPipeline` directly.
"""

from __future__ import annotations

from collections.abc import Sequence
from pathlib import Path

from .app import ConversionPipeline, SystemClock
from .domain import Extractor, ImageDescriber
from .infra import (
    CsvExtractor,
    DefaultPolicy,
    DoclingExtractor,
    HeuristicScorer,
    Jinja2Renderer,
    LibreOfficeDocExtractor,
    LLMConfig,
    OfficeMetadataProbe,
    OpenAICompatibleImageDescriber,
    OpenpyxlExtractor,
    PdfMetadataProbe,
    PdfplumberExtractor,
    Pymupdf4llmExtractor,
    PymupdfChunkedExtractor,
    XlrdExtractor,
)
from .infra.llm.openai_describer import ImageDescriberUnavailableError

__all__ = ["DEFAULT_EXTRACTOR_NAMES", "build_pipeline"]

DEFAULT_EXTRACTOR_NAMES: tuple[str, ...] = (
    CsvExtractor().name,
    PymupdfChunkedExtractor().name,
    Pymupdf4llmExtractor().name,
    PdfplumberExtractor().name,
    DoclingExtractor().name,
    OpenpyxlExtractor().name,
    XlrdExtractor().name,
    LibreOfficeDocExtractor().name,
)


def build_pipeline(
    *,
    llm_config: LLMConfig | None = None,
    template_dir: Path | None = None,
    extractor_names: Sequence[str] | None = None,
    size_aware_policy: bool = True,
) -> ConversionPipeline:
    """Build a :class:`ConversionPipeline` wired with default adapters.

    Args:
        llm_config: When provided and :attr:`~LLMConfig.is_configured`,
            the pipeline enables LLM-backed image enrichment.
        template_dir: Optional directory of Jinja2 templates that override
            the ones bundled with the package.
        extractor_names: Restrict to this subset of the built-in adapters
            (by :attr:`~cyberdocextractor.domain.Extractor.name`). When
            ``None``, all built-in adapters are included.
        size_aware_policy: Passes through to
            :class:`DefaultPolicy.size_aware`. Disable in tests that want
            deterministic extractor selection.

    Returns:
        A configured :class:`ConversionPipeline`. Adapters whose backing
        library is not installed remain in the chain but report
        ``supports(mime) == False`` for every MIME they nominally cover.
    """
    extractors: list[Extractor] = [
        CsvExtractor(),
        PymupdfChunkedExtractor(),
        Pymupdf4llmExtractor(),
        PdfplumberExtractor(),
        DoclingExtractor(),
        OpenpyxlExtractor(),
        XlrdExtractor(),
        LibreOfficeDocExtractor(),
    ]
    if extractor_names is not None:
        allowed = set(extractor_names)
        extractors = [e for e in extractors if e.name in allowed]

    image_describer: ImageDescriber | None = None
    max_images = 5
    context_lines = 100
    if llm_config is not None and llm_config.is_configured:
        max_images = llm_config.max_images_per_document
        context_lines = llm_config.context_lines
        try:
            image_describer = OpenAICompatibleImageDescriber(config=llm_config)
        except ImageDescriberUnavailableError:
            image_describer = None

    return ConversionPipeline(
        policy=DefaultPolicy(extractors=tuple(extractors), size_aware=size_aware_policy),
        renderer=Jinja2Renderer(override_dir=template_dir),
        scorer=HeuristicScorer(),
        metadata_probes=(PdfMetadataProbe(), OfficeMetadataProbe()),
        image_describer=image_describer,
        clock=SystemClock(),
        max_images_per_document=max_images,
        image_context_lines=context_lines,
    )
