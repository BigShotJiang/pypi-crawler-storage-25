"""Environment-driven LLM configuration for the image describer."""

from __future__ import annotations

import os
from collections.abc import Mapping
from dataclasses import dataclass

from ...domain import ValidationError

__all__ = ["LLMConfig"]

_DEFAULTS = {
    "base_url": "https://api.openai.com/v1",
    "model": "gpt-4o-mini",
    "max_images_per_document": 5,
    "context_lines": 100,
    "timeout_seconds": 30.0,
    "max_retries": 2,
    "retry_base_delay_seconds": 0.5,
}


@dataclass(frozen=True, slots=True)
class LLMConfig:
    """Configuration for the :class:`OpenAICompatibleImageDescriber`.

    All defaults are safe placeholders; nothing is sent over the wire
    until :attr:`api_key` is non-empty.
    """

    base_url: str = _DEFAULTS["base_url"]  # type: ignore[assignment]
    model: str = _DEFAULTS["model"]  # type: ignore[assignment]
    api_key: str = ""
    max_images_per_document: int = _DEFAULTS["max_images_per_document"]  # type: ignore[assignment]
    context_lines: int = _DEFAULTS["context_lines"]  # type: ignore[assignment]
    timeout_seconds: float = _DEFAULTS["timeout_seconds"]  # type: ignore[assignment]
    max_retries: int = _DEFAULTS["max_retries"]  # type: ignore[assignment]
    retry_base_delay_seconds: float = _DEFAULTS["retry_base_delay_seconds"]  # type: ignore[assignment]

    def __post_init__(self) -> None:
        if not self.base_url:
            raise ValidationError("LLMConfig.base_url must be non-empty")
        if not self.model:
            raise ValidationError("LLMConfig.model must be non-empty")
        if self.max_images_per_document < -1 or self.max_images_per_document == 0:
            raise ValidationError("max_images_per_document must be positive or -1 (unlimited)")
        if self.context_lines <= 0:
            raise ValidationError("context_lines must be positive")
        if self.timeout_seconds <= 0:
            raise ValidationError("timeout_seconds must be positive")
        if self.max_retries < 0:
            raise ValidationError("max_retries must be >= 0")
        if self.retry_base_delay_seconds < 0:
            raise ValidationError("retry_base_delay_seconds must be >= 0")

    @property
    def is_configured(self) -> bool:
        """Return ``True`` iff :attr:`api_key` is set."""
        return bool(self.api_key)

    @classmethod
    def from_env(cls, env: Mapping[str, str] | None = None) -> LLMConfig:
        """Build from environment variables (all prefixed ``CYBERDOC_LLM_``)."""
        source = env if env is not None else os.environ
        return cls(
            base_url=source.get("CYBERDOC_LLM_BASE_URL", _DEFAULTS["base_url"]),  # type: ignore[arg-type]
            model=source.get("CYBERDOC_LLM_MODEL", _DEFAULTS["model"]),  # type: ignore[arg-type]
            api_key=source.get("CYBERDOC_LLM_API_KEY", ""),
            max_images_per_document=_coerce_int(
                source.get("CYBERDOC_LLM_MAX_IMAGES"),
                _DEFAULTS["max_images_per_document"],  # type: ignore[arg-type]
            ),
            context_lines=_coerce_int(
                source.get("CYBERDOC_LLM_CONTEXT_LINES"),
                _DEFAULTS["context_lines"],  # type: ignore[arg-type]
            ),
            timeout_seconds=_coerce_float(
                source.get("CYBERDOC_LLM_TIMEOUT"),
                _DEFAULTS["timeout_seconds"],  # type: ignore[arg-type]
            ),
            max_retries=_coerce_int(
                source.get("CYBERDOC_LLM_MAX_RETRIES"),
                _DEFAULTS["max_retries"],  # type: ignore[arg-type]
            ),
            retry_base_delay_seconds=_coerce_float(
                source.get("CYBERDOC_LLM_RETRY_BASE_DELAY"),
                _DEFAULTS["retry_base_delay_seconds"],  # type: ignore[arg-type]
            ),
        )


def _coerce_int(raw: str | None, default: int) -> int:
    if raw is None or raw.strip() == "":
        return default
    try:
        return int(raw)
    except ValueError as exc:
        raise ValidationError(f"Expected integer, got {raw!r}") from exc


def _coerce_float(raw: str | None, default: float) -> float:
    if raw is None or raw.strip() == "":
        return default
    try:
        return float(raw)
    except ValueError as exc:
        raise ValidationError(f"Expected float, got {raw!r}") from exc
