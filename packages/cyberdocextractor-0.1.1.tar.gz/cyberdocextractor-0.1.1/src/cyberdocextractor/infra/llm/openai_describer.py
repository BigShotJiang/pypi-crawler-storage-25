"""OpenAI-compatible image describer (httpx + JSON).

Works with any endpoint speaking the Chat Completions API with vision
support — OpenAI, Azure OpenAI (with the right base_url), Ollama,
vLLM, LM Studio, and so on. Retries with exponential backoff on
transient HTTP errors; everything else is raised so the calling stage
can log and skip.
"""

from __future__ import annotations

import base64
import time
from dataclasses import dataclass
from typing import Any

from ..extractors._base import import_optional
from .config import LLMConfig

__all__ = ["OpenAICompatibleImageDescriber"]

_DEFAULT_SYSTEM_PROMPT = (
    "You describe images from documents in concise, factual prose. "
    "Use the surrounding text (if given) to stay on-topic. "
    "Answer in at most three sentences; no markdown."
)

_RETRYABLE_STATUS_CODES = frozenset({408, 425, 429, 500, 502, 503, 504})


class ImageDescriberUnavailableError(RuntimeError):
    """Raised at construction time when httpx is not installed."""


@dataclass(frozen=True, slots=True)
class OpenAICompatibleImageDescriber:
    """Adapter over the Chat Completions API with vision inputs."""

    config: LLMConfig
    system_prompt: str = _DEFAULT_SYSTEM_PROMPT

    def __post_init__(self) -> None:
        if import_optional("httpx") is None:
            raise ImageDescriberUnavailableError(
                "httpx is not installed; install with `pip install cyberdocextractor[llm]`"
            )
        if not self.config.is_configured:
            raise ImageDescriberUnavailableError("LLMConfig.api_key is empty")

    def describe(
        self,
        *,
        image_data: bytes,
        context_text: str,
        mime_type: str,
    ) -> str:
        """POST the image to the chat-completions endpoint and return the text."""
        httpx = import_optional("httpx")
        if httpx is None:  # pragma: no cover — guarded by __post_init__
            raise ImageDescriberUnavailableError("httpx unavailable at call time")

        body = _build_request_body(
            model=self.config.model,
            system_prompt=self.system_prompt,
            context=context_text,
            mime_type=mime_type,
            image_data=image_data,
        )
        url = self.config.base_url.rstrip("/") + "/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.config.api_key}",
            "Content-Type": "application/json",
        }

        response_json = _post_with_retries(
            httpx=httpx,
            url=url,
            headers=headers,
            body=body,
            timeout=self.config.timeout_seconds,
            max_retries=self.config.max_retries,
            base_delay=self.config.retry_base_delay_seconds,
        )
        return _extract_text(response_json)


def _build_request_body(
    *,
    model: str,
    system_prompt: str,
    context: str,
    mime_type: str,
    image_data: bytes,
) -> dict[str, Any]:
    encoded = base64.b64encode(image_data).decode("ascii")
    user_parts: list[dict[str, Any]] = []
    if context.strip():
        user_parts.append(
            {
                "type": "text",
                "text": f"Context from the surrounding document:\n\n{context}",
            }
        )
    user_parts.append({"type": "text", "text": "Describe the image."})
    user_parts.append(
        {
            "type": "image_url",
            "image_url": {"url": f"data:{mime_type};base64,{encoded}"},
        }
    )
    return {
        "model": model,
        "temperature": 0.2,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_parts},
        ],
    }


def _post_with_retries(
    *,
    httpx: Any,
    url: str,
    headers: dict[str, str],
    body: dict[str, Any],
    timeout: float,
    max_retries: int,
    base_delay: float,
) -> dict[str, Any]:
    last_exc: Exception | None = None
    for attempt in range(max_retries + 1):
        try:
            with httpx.Client(timeout=timeout) as client:
                response = client.post(url, json=body, headers=headers)
            if response.status_code in _RETRYABLE_STATUS_CODES and attempt < max_retries:
                time.sleep(base_delay * (2**attempt))
                continue
            response.raise_for_status()
            payload = response.json()
            if isinstance(payload, dict):
                return payload
            raise TypeError(f"LLM response must be a JSON object, got {type(payload).__name__}")
        except httpx.HTTPStatusError:  # non-retryable status
            raise
        except (httpx.TimeoutException, httpx.TransportError) as exc:
            last_exc = exc
            if attempt < max_retries:
                time.sleep(base_delay * (2**attempt))
                continue
            raise
    raise last_exc if last_exc is not None else RuntimeError("LLM call failed")


def _extract_text(payload: dict[str, Any]) -> str:
    choices = payload.get("choices")
    if not isinstance(choices, list) or not choices:
        raise ValueError("LLM response missing 'choices'")
    message = choices[0].get("message") if isinstance(choices[0], dict) else None
    if not isinstance(message, dict):
        raise TypeError("LLM response missing 'choices[0].message'")
    content = message.get("content")
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, list):
        parts = [
            part["text"]
            for part in content
            if isinstance(part, dict) and part.get("type") == "text" and "text" in part
        ]
        if parts:
            return "\n".join(parts).strip()
    raise ValueError("LLM response missing text content")
