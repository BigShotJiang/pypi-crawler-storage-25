"""LLM adapters (OpenAI-compatible image description)."""

from .config import LLMConfig
from .openai_describer import OpenAICompatibleImageDescriber

__all__ = ["LLMConfig", "OpenAICompatibleImageDescriber"]
