"""Heuristic :class:`QualityScorer` implementations.

The default implementation is deterministic, dependency-free, and
combines signals that correlate reasonably well with human judgments
of extraction quality — not a perfect metric, but good enough for
automatic gating in downstream RAG/data pipelines.
"""

from __future__ import annotations

from dataclasses import dataclass

from ..domain import BlockType, Document, NormalizedDoc, ValidationError

__all__ = ["HeuristicScorer"]


@dataclass(frozen=True, slots=True)
class HeuristicScorer:
    """Weighted sum of extraction-quality signals.

    The score is the sum of weighted, clamped signals — each normalised
    into ``[0, 1]`` — then the result is clamped to ``[0, 1]`` overall.
    Signals (and their default weights):

    - **text density** (``0.4``): characters per KiB of input,
      saturating at 300 chars/KiB.
    - **block diversity** (``0.2``): share of distinct block types
      present, out of the five meaningful ones.
    - **table bonus** (``0.1``): 1.0 when :attr:`NormalizedDoc.has_tables`
      and at least one table block is present.
    - **image bonus** (``0.1``): 1.0 when at least one image block is
      present and content is not empty.
    - **length floor** (``0.2``): 1.0 when the rendered Markdown is
      at least 500 characters, ramping linearly from 0 at empty.
    """

    text_density_weight: float = 0.4
    block_diversity_weight: float = 0.2
    table_weight: float = 0.1
    image_weight: float = 0.1
    length_floor_weight: float = 0.2

    _distinct_types: int = 5  # TEXT, HEADING, TABLE, LIST, IMAGE
    _density_saturation: float = 300.0
    _length_saturation: int = 500

    def __post_init__(self) -> None:
        weights = (
            self.text_density_weight,
            self.block_diversity_weight,
            self.table_weight,
            self.image_weight,
            self.length_floor_weight,
        )
        if any(w < 0 for w in weights):
            raise ValidationError("HeuristicScorer weights must be non-negative")
        total = sum(weights)
        if not 0.0 < total <= 1.0 + 1e-9:
            raise ValidationError(
                f"HeuristicScorer weights must sum to a value in (0, 1], got {total}"
            )

    def score(
        self,
        *,
        normalized_doc: NormalizedDoc,
        markdown: str,
        original: Document | None = None,
    ) -> float:
        """Compute the weighted-sum quality score."""
        size_bytes = original.size_bytes if original is not None else None
        signals = (
            (self.text_density_weight, self._text_density(markdown, size_bytes)),
            (self.block_diversity_weight, self._block_diversity(normalized_doc)),
            (self.table_weight, self._table_signal(normalized_doc)),
            (self.image_weight, self._image_signal(normalized_doc)),
            (self.length_floor_weight, self._length_floor(markdown)),
        )
        raw = sum(weight * value for weight, value in signals)
        return max(0.0, min(1.0, raw))

    # -------------------------------------------------------------------
    # signals
    # -------------------------------------------------------------------

    def _text_density(self, markdown: str, size_bytes: int | None) -> float:
        if size_bytes is None or size_bytes <= 0:
            return 1.0 if markdown else 0.0
        density = len(markdown) / (size_bytes / 1024.0)
        return min(1.0, density / self._density_saturation)

    def _block_diversity(self, ndoc: NormalizedDoc) -> float:
        meaningful = {
            BlockType.TEXT,
            BlockType.HEADING,
            BlockType.TABLE,
            BlockType.LIST,
            BlockType.IMAGE,
        }
        present = {b.type for b in ndoc.blocks} & meaningful
        return len(present) / self._distinct_types

    def _table_signal(self, ndoc: NormalizedDoc) -> float:
        if not ndoc.has_tables:
            return 0.0
        return 1.0 if ndoc.blocks_of(BlockType.TABLE) else 0.0

    def _image_signal(self, ndoc: NormalizedDoc) -> float:
        images = ndoc.blocks_of(BlockType.IMAGE)
        if not images:
            return 0.0
        return 1.0 if any(block.content.strip() for block in images) else 0.0

    def _length_floor(self, markdown: str) -> float:
        return min(1.0, len(markdown) / self._length_saturation)
