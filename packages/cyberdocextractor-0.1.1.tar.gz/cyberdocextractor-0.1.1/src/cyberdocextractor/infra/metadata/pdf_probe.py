"""Extract creation / author / title metadata from PDFs via PyMuPDF."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from datetime import UTC, datetime

from ...domain import Document, MimeType
from ..extractors._base import import_optional

__all__ = ["PdfMetadataProbe"]

_PDF_DATE_PREFIX = "D:"
_PDF_DATE_LENGTH = 14  # YYYYMMDDHHmmSS


@dataclass(frozen=True, slots=True)
class PdfMetadataProbe:
    """Reads the Info dictionary from a PDF via PyMuPDF."""

    def supports(self, mime: str) -> bool:
        """Return ``True`` for PDFs when PyMuPDF is importable."""
        if mime != MimeType.PDF.value:
            return False
        return import_optional("fitz") is not None or import_optional("pymupdf") is not None

    def probe(self, document: Document) -> Mapping[str, str]:
        """Return ``{"created_utc", "author", "title", ...}`` when present."""
        fitz = import_optional("fitz") or import_optional("pymupdf")
        if fitz is None:
            return {}

        try:
            pdf = fitz.open(stream=document.content, filetype="pdf")
            try:
                raw = dict(pdf.metadata or {})
            finally:
                pdf.close()
        except Exception:
            return {}

        return _clean_metadata(raw)


def _clean_metadata(raw: dict[str, object]) -> dict[str, str]:
    out: dict[str, str] = {}
    for key, mapped in (
        ("author", "author"),
        ("title", "title"),
        ("subject", "subject"),
        ("keywords", "keywords"),
        ("producer", "producer"),
        ("creator", "creator"),
    ):
        value = raw.get(key)
        if isinstance(value, str) and value.strip():
            out[mapped] = value.strip()

    created = _parse_pdf_date(raw.get("creationDate"))
    if created is not None:
        out["created_utc"] = created

    return out


def _parse_pdf_date(value: object) -> str | None:
    if not isinstance(value, str):
        return None
    stripped = value.strip()
    if stripped.startswith(_PDF_DATE_PREFIX):
        stripped = stripped[len(_PDF_DATE_PREFIX) :]
    if len(stripped) < _PDF_DATE_LENGTH:
        return None
    try:
        parsed = datetime.strptime(stripped[:_PDF_DATE_LENGTH], "%Y%m%d%H%M%S").replace(tzinfo=UTC)
    except ValueError:
        return None
    return parsed.isoformat()
