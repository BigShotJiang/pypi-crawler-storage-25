"""Extract core metadata from OOXML packages (DOCX / XLSX) via zipfile + XML.

Uses :mod:`defusedxml` when available to mitigate the XML-bomb and
entity-expansion attacks that make stdlib :mod:`xml.etree.ElementTree`
unsafe for untrusted input.
"""

from __future__ import annotations

import io
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any
from zipfile import BadZipFile, ZipFile

from ...domain import Document, MimeType
from ..extractors._base import import_optional

__all__ = ["OfficeMetadataProbe"]

_SUPPORTED_MIMES = frozenset({MimeType.DOCX.value, MimeType.XLSX.value})
_CORE_PATH = "docProps/core.xml"
_NAMESPACES = {
    "dc": "http://purl.org/dc/elements/1.1/",
    "dcterms": "http://purl.org/dc/terms/",
    "cp": "http://schemas.openxmlformats.org/package/2006/metadata/core-properties",
}
_FIELDS = (
    ("{http://purl.org/dc/elements/1.1/}creator", "author"),
    ("{http://purl.org/dc/elements/1.1/}title", "title"),
    ("{http://purl.org/dc/elements/1.1/}subject", "subject"),
    ("{http://purl.org/dc/elements/1.1/}description", "description"),
    ("{http://purl.org/dc/terms/}created", "created_utc"),
    ("{http://purl.org/dc/terms/}modified", "modified_utc"),
    (
        "{http://schemas.openxmlformats.org/package/2006/metadata/core-properties}lastModifiedBy",
        "last_modified_by",
    ),
)


@dataclass(frozen=True, slots=True)
class OfficeMetadataProbe:
    """Reads ``docProps/core.xml`` from a DOCX or XLSX package."""

    def supports(self, mime: str) -> bool:
        """Return ``True`` for DOCX/XLSX."""
        return mime in _SUPPORTED_MIMES

    def probe(self, document: Document) -> Mapping[str, str]:
        """Return a flat mapping of core properties (``author``, etc.)."""
        parser_module = _load_parser()
        if parser_module is None:
            return {}

        try:
            with ZipFile(io.BytesIO(document.content)) as zf:
                if _CORE_PATH not in zf.namelist():
                    return {}
                xml_bytes = zf.read(_CORE_PATH)
        except (BadZipFile, KeyError, OSError):
            return {}

        try:
            root = parser_module.fromstring(xml_bytes)
        except Exception:
            return {}

        result: dict[str, str] = {}
        for tag, mapped_key in _FIELDS:
            element = root.find(tag)
            if element is not None and element.text and element.text.strip():
                result[mapped_key] = element.text.strip()
        return result


def _load_parser() -> Any | None:
    """Prefer defusedxml for safety; fall back to stdlib ElementTree."""
    defused = import_optional("defusedxml.ElementTree")
    if defused is not None:
        return defused
    return import_optional("xml.etree.ElementTree")
