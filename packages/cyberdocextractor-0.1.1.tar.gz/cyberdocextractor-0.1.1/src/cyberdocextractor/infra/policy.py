"""Default :class:`SelectionPolicy` implementation.

Orders the available extractor chain for a given document using two
signals:

1. ``precision`` on the document (explicit caller intent).
2. Document size, when the caller passes
   :attr:`PrecisionLevel.BALANCED` (the default) — in which case
   :func:`default_precision_for_size` picks a smart default.

Only extractors that :meth:`supports` the MIME type are returned; the
chosen precision is tried first, followed by the others in descending
precision order as fallbacks.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field

from ..domain import (
    Extractor,
    PrecisionLevel,
    default_precision_for_size,
)

__all__ = ["DefaultPolicy"]


@dataclass
class DefaultPolicy:
    """Pick the extractor chain based on MIME and precision.

    Attributes:
        extractors: All extractors the host knows about. The policy
            filters by :meth:`~Extractor.supports` per call.
        size_aware: When ``True`` (default), :attr:`PrecisionLevel.BALANCED`
            is re-resolved using :func:`default_precision_for_size`
            so big files favour speed and small files favour quality.
    """

    extractors: Sequence[Extractor] = field(default_factory=tuple)
    size_aware: bool = True

    def choose(
        self,
        *,
        mime: str,
        size_bytes: int,
        has_tables: bool,
        precision: PrecisionLevel,
    ) -> Sequence[Extractor]:
        """Return the ordered chain of extractors for *mime*."""
        supporting = [e for e in self.extractors if e.supports(mime)]
        if not supporting:
            return ()

        effective = self._effective_precision(size_bytes, has_tables, precision)
        return tuple(sorted(supporting, key=self._ranking_key(effective)))

    def by_precision(self, precision: PrecisionLevel) -> Extractor | None:
        """Return the first extractor at ``precision``, regardless of MIME."""
        for extractor in self.extractors:
            if extractor.precision_level is precision:
                return extractor
        return None

    # -------------------------------------------------------------------
    # helpers
    # -------------------------------------------------------------------

    def _effective_precision(
        self,
        size_bytes: int,
        has_tables: bool,
        precision: PrecisionLevel,
    ) -> PrecisionLevel:
        if precision is not PrecisionLevel.BALANCED:
            return precision
        if has_tables:
            return PrecisionLevel.TABLE_OPTIMIZED
        if self.size_aware and size_bytes > 0:
            return default_precision_for_size(size_bytes)
        return PrecisionLevel.BALANCED

    @staticmethod
    def _ranking_key(preferred: PrecisionLevel):  # type: ignore[no-untyped-def]
        """Return a sort key that puts ``preferred`` first.

        Other extractors follow in descending precision order so a
        balanced request can fall back to the highest-quality
        extractor available before dropping to the fastest.
        """

        def key(extractor: Extractor) -> tuple[int, int]:
            # Two-tier sort: 0 for the preferred level, 1 otherwise.
            # Within each tier, larger precision values sort first so
            # falling back from BALANCED prefers quality over speed.
            preferred_tier = 0 if extractor.precision_level is preferred else 1
            return (preferred_tier, -int(extractor.precision_level))

        return key
