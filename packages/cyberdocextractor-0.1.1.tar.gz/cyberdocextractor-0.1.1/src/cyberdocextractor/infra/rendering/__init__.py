"""Rendering adapters (Jinja2-based TemplateRenderer)."""

from .jinja2_renderer import Jinja2Renderer

__all__ = ["Jinja2Renderer"]
