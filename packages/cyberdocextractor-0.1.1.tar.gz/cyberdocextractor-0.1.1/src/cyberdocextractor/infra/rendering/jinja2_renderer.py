"""Jinja2-based implementation of the :class:`TemplateRenderer` port.

Uses a sandboxed environment and ``autoescape=False`` (Markdown, not
HTML — we don't want every ``<``/``>`` to become ``&lt;``/``&gt;``).
Templates load from ``infra/rendering/templates/`` by default, with an
optional override directory for callers shipping their own templates.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from pathlib import Path

from jinja2 import (
    ChoiceLoader,
    FileSystemLoader,
    TemplateError,
    TemplateNotFound,
    select_autoescape,
)
from jinja2.sandbox import SandboxedEnvironment

from ...domain import RenderingError

__all__ = ["Jinja2Renderer"]

_DEFAULT_TEMPLATE_DIR = Path(__file__).parent / "templates"
_DEFAULT_EXTENSION = ".j2"


@dataclass
class Jinja2Renderer:
    """Render templates shipped with the package or provided by the caller.

    Attributes:
        override_dir: Optional user-supplied template directory. If
            present, it's searched before the built-in directory so
            callers can override any template by name.
    """

    override_dir: Path | None = None
    _environment: SandboxedEnvironment = field(init=False, repr=False)

    def __post_init__(self) -> None:
        loaders: list[FileSystemLoader] = []
        if self.override_dir is not None:
            if not self.override_dir.is_dir():
                raise RenderingError(
                    f"override_dir does not exist or is not a directory: {self.override_dir}"
                )
            loaders.append(FileSystemLoader(str(self.override_dir)))
        loaders.append(FileSystemLoader(str(_DEFAULT_TEMPLATE_DIR)))

        self._environment = SandboxedEnvironment(
            loader=ChoiceLoader(loaders),
            autoescape=select_autoescape(enabled_extensions=(), default=False),
            trim_blocks=True,
            lstrip_blocks=True,
            keep_trailing_newline=True,
        )

    def render(self, template_name: str, context: Mapping[str, object]) -> str:
        """Render ``template_name`` with ``context``.

        Adds the ``.j2`` extension automatically if absent. Wraps
        Jinja2 exceptions in :class:`RenderingError` with the template
        name attached.
        """
        resolved = (
            template_name
            if template_name.endswith(_DEFAULT_EXTENSION)
            else (f"{template_name}{_DEFAULT_EXTENSION}")
        )
        try:
            template = self._environment.get_template(resolved)
        except TemplateNotFound as exc:
            raise RenderingError(
                f"Template {template_name!r} not found (looked for {resolved!r})",
                template_name=template_name,
            ) from exc
        try:
            return template.render(**dict(context))
        except TemplateError as exc:
            raise RenderingError(
                f"Template {template_name!r} failed to render: {exc}",
                template_name=template_name,
            ) from exc

    def list_templates(self) -> Sequence[str]:
        """List template names (without the ``.j2`` suffix)."""
        names = self._environment.list_templates(extensions=["j2"])
        return tuple(sorted({n.removesuffix(_DEFAULT_EXTENSION) for n in names}))
