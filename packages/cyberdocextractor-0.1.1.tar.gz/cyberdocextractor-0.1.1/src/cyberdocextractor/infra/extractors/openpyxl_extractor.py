"""XLSX extractor using :mod:`openpyxl`.

Produces one ``TABLE`` block per worksheet, rendered as a Markdown
pipe table. Includes ``row_count``, ``column_count``, and
``sheet_name`` in the block metadata so templates can surface them.
"""

from __future__ import annotations

import io
import time
from dataclasses import dataclass
from typing import Any

from ...domain import (
    Block,
    BlockType,
    Document,
    ExtractionOutcome,
    MimeType,
    NormalizedDoc,
    PrecisionLevel,
)
from ._base import import_optional

__all__ = ["OpenpyxlExtractor"]

# openpyxl only reads the OOXML-based XLSX format. Legacy binary XLS
# (BIFF) requires a different library (e.g. xlrd) and is not supported
# in 0.1.0.
_SUPPORTED_MIMES = frozenset({MimeType.XLSX.value})


@dataclass(frozen=True, slots=True)
class OpenpyxlExtractor:
    """Adapter around ``openpyxl.load_workbook`` (read-only)."""

    name: str = "openpyxl"
    precision_level: PrecisionLevel = PrecisionLevel.BALANCED
    max_rows_per_sheet: int | None = None

    def supports(self, mime: str) -> bool:
        """Return ``True`` for XLSX when openpyxl is installed."""
        return mime in _SUPPORTED_MIMES and import_optional("openpyxl") is not None

    def extract(self, document: Document) -> ExtractionOutcome:
        """Iterate sheets, emitting one ``TABLE`` block each."""
        openpyxl = import_optional("openpyxl")
        if openpyxl is None:
            return ExtractionOutcome.fail(
                extractor_name=self.name,
                duration_seconds=0.0,
                error_message="openpyxl is not installed; install with `pip install cyberdocextractor[xlsx]`",
            )

        start = time.monotonic()
        blocks: list[Block] = []
        try:
            workbook = openpyxl.load_workbook(
                io.BytesIO(document.content),
                data_only=True,
                read_only=True,
            )
            try:
                for sheet_name in workbook.sheetnames:
                    sheet = workbook[sheet_name]
                    rows = _collect_rows(sheet, self.max_rows_per_sheet)
                    if not rows:
                        continue
                    markdown = _rows_to_markdown(rows)
                    header_length = len(rows[0]) if rows else 0
                    blocks.append(
                        Block(
                            type=BlockType.TABLE,
                            content=markdown,
                            metadata={
                                "sheet_name": sheet_name,
                                "row_count": max(len(rows) - 1, 0),
                                "column_count": header_length,
                            },
                        )
                    )
            finally:
                workbook.close()
        except Exception as exc:
            return ExtractionOutcome.fail(
                extractor_name=self.name,
                duration_seconds=time.monotonic() - start,
                error_message=f"openpyxl extraction failed: {exc}",
            )

        if not blocks:
            return ExtractionOutcome.fail(
                extractor_name=self.name,
                duration_seconds=time.monotonic() - start,
                error_message="openpyxl produced no content",
            )

        ndoc = NormalizedDoc(
            blocks=tuple(blocks),
            source_mime=document.mime,
            has_tables=True,
            extractor_name=self.name,
        )
        return ExtractionOutcome.ok(
            extractor_name=self.name,
            duration_seconds=time.monotonic() - start,
            normalized_doc=ndoc,
        )


def _collect_rows(sheet: Any, max_rows: int | None) -> list[list[str]]:
    rows: list[list[str]] = []
    limit = None if max_rows is None else max_rows + 1
    for index, row in enumerate(sheet.iter_rows(values_only=True)):
        if limit is not None and index >= limit:
            break
        rows.append(["" if cell is None else str(cell) for cell in row])
    return [r for r in rows if any(c.strip() for c in r)]


def _rows_to_markdown(rows: list[list[str]]) -> str:
    if not rows:
        return ""
    header, *body = rows
    width = len(header)
    normalised = [row + [""] * (width - len(row)) for row in body]
    lines = [
        "| " + " | ".join(_cell(c) for c in header) + " |",
        "| " + " | ".join(["---"] * width) + " |",
    ]
    lines.extend("| " + " | ".join(_cell(c) for c in row[:width]) + " |" for row in normalised)
    return "\n".join(lines)


def _cell(value: str) -> str:
    return value.replace("|", r"\|").replace("\n", " ").strip()
