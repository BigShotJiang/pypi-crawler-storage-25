"""Fastest-path PDF extractor using raw PyMuPDF text streaming.

Uses :mod:`fitz` directly (``PyMuPDF``) and returns one ``TEXT`` block
per page. Intended for :attr:`PrecisionLevel.FASTEST` — no layout, no
table detection, no image extraction. Best suited to very large files
where throughput matters more than fidelity.
"""

from __future__ import annotations

import time
from dataclasses import dataclass

from ...domain import (
    Block,
    BlockType,
    Document,
    ExtractionOutcome,
    MimeType,
    NormalizedDoc,
    PrecisionLevel,
)
from ._base import import_optional

__all__ = ["PymupdfChunkedExtractor"]


@dataclass(frozen=True, slots=True)
class PymupdfChunkedExtractor:
    """Streams text chunks out of PyMuPDF, one block per page."""

    name: str = "pymupdf-chunked"
    precision_level: PrecisionLevel = PrecisionLevel.FASTEST
    max_chars_per_page: int = 50_000

    def supports(self, mime: str) -> bool:
        """Return ``True`` when PDF and PyMuPDF is installed."""
        if mime != MimeType.PDF.value:
            return False
        return import_optional("fitz") is not None or import_optional("pymupdf") is not None

    def extract(self, document: Document) -> ExtractionOutcome:
        """Iterate pages, emitting one ``TEXT`` block each."""
        fitz = import_optional("fitz") or import_optional("pymupdf")
        if fitz is None:
            return ExtractionOutcome.fail(
                extractor_name=self.name,
                duration_seconds=0.0,
                error_message="PyMuPDF is not installed; install with `pip install cyberdocextractor[pdf]`",
            )

        start = time.monotonic()
        blocks: list[Block] = []
        try:
            doc = fitz.open(stream=document.content, filetype="pdf")
            try:
                for page_index in range(doc.page_count):
                    page = doc.load_page(page_index)
                    text = (page.get_text("text") or "").strip()
                    if not text:
                        continue
                    if len(text) > self.max_chars_per_page:
                        text = text[: self.max_chars_per_page]
                    blocks.append(
                        Block(
                            type=BlockType.TEXT,
                            content=text,
                            page_number=page_index + 1,
                        )
                    )
                page_count = doc.page_count
            finally:
                doc.close()
        except Exception as exc:
            return ExtractionOutcome.fail(
                extractor_name=self.name,
                duration_seconds=time.monotonic() - start,
                error_message=f"pymupdf-chunked extraction failed: {exc}",
            )

        if not blocks:
            return ExtractionOutcome.fail(
                extractor_name=self.name,
                duration_seconds=time.monotonic() - start,
                error_message="pymupdf-chunked produced no content",
            )

        ndoc = NormalizedDoc(
            blocks=tuple(blocks),
            source_mime=document.mime,
            page_count=page_count or None,
            extractor_name=self.name,
        )
        return ExtractionOutcome.ok(
            extractor_name=self.name,
            duration_seconds=time.monotonic() - start,
            normalized_doc=ndoc,
        )
