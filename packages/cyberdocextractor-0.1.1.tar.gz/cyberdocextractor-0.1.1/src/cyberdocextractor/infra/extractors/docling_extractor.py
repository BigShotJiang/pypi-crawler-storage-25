"""Highest-quality extractor backed by :mod:`docling`.

Supports PDF, DOCX, XLSX, and more. Slowest of the built-in chain — use
when fidelity trumps throughput. Requires the ``doc`` extra.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any

from ...domain import (
    Block,
    BlockType,
    Document,
    ExtractionOutcome,
    MimeType,
    NormalizedDoc,
    PrecisionLevel,
)
from ._base import import_optional

__all__ = ["DoclingExtractor"]

_SUPPORTED_MIMES = frozenset(
    {
        MimeType.PDF.value,
        MimeType.DOCX.value,
        MimeType.XLSX.value,
    }
)


@dataclass(frozen=True, slots=True)
class DoclingExtractor:
    """Adapter around ``docling.document_converter.DocumentConverter``."""

    name: str = "docling"
    precision_level: PrecisionLevel = PrecisionLevel.HIGHEST_QUALITY

    def supports(self, mime: str) -> bool:
        """Return ``True`` for office/PDF formats when Docling is installed."""
        if mime not in _SUPPORTED_MIMES:
            return False
        return import_optional("docling.document_converter") is not None

    def extract(self, document: Document) -> ExtractionOutcome:
        """Run Docling conversion against the document bytes."""
        module = import_optional("docling.document_converter")
        if module is None:
            return ExtractionOutcome.fail(
                extractor_name=self.name,
                duration_seconds=0.0,
                error_message="docling is not installed; install with `pip install cyberdocextractor[doc]`",
            )

        start = time.monotonic()
        try:
            converter = module.DocumentConverter()
            result = converter.convert(_as_stream(document.content, document.filename))
            docling_doc = getattr(result, "document", result)
            markdown = _export_markdown(docling_doc)
        except Exception as exc:
            return ExtractionOutcome.fail(
                extractor_name=self.name,
                duration_seconds=time.monotonic() - start,
                error_message=f"docling extraction failed: {exc}",
            )

        if not markdown.strip():
            return ExtractionOutcome.fail(
                extractor_name=self.name,
                duration_seconds=time.monotonic() - start,
                error_message="docling produced no content",
            )

        ndoc = NormalizedDoc(
            blocks=(Block(type=BlockType.TEXT, content=markdown.strip()),),
            source_mime=document.mime,
            has_tables="|" in markdown,
            extractor_name=self.name,
        )
        return ExtractionOutcome.ok(
            extractor_name=self.name,
            duration_seconds=time.monotonic() - start,
            normalized_doc=ndoc,
        )


def _as_stream(content: bytes, filename: str | None) -> Any:
    """Wrap raw bytes in a DocumentStream shaped as Docling expects."""
    module = import_optional("docling.datamodel.base_models")
    if module is not None and hasattr(module, "DocumentStream"):
        import io

        return module.DocumentStream(
            name=filename or "document",
            stream=io.BytesIO(content),
        )
    # Fallback — write to a temp file. Docling's convert() also
    # accepts a path.
    import tempfile
    from pathlib import Path

    suffix = Path(filename).suffix if filename else ".bin"
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    try:
        tmp.write(content)
        tmp.flush()
        return Path(tmp.name)
    finally:
        tmp.close()


def _export_markdown(docling_doc: Any) -> str:
    for method_name in ("export_to_markdown", "as_markdown", "to_markdown"):
        method = getattr(docling_doc, method_name, None)
        if callable(method):
            try:
                result = method()
            except Exception:
                continue
            if isinstance(result, str):
                return result
    return ""
