"""PDF extractor using :mod:`pdfplumber`.

Targets :attr:`PrecisionLevel.TABLE_OPTIMIZED` — slower than
``pymupdf4llm`` but with far better layout and table extraction.
"""

from __future__ import annotations

import io
import time
from dataclasses import dataclass
from typing import Any

from ...domain import (
    Block,
    BlockType,
    Document,
    ExtractionOutcome,
    MimeType,
    NormalizedDoc,
    PrecisionLevel,
)
from ._base import import_optional

__all__ = ["PdfplumberExtractor"]


@dataclass(frozen=True, slots=True)
class PdfplumberExtractor:
    """Adapter around ``pdfplumber.open``."""

    name: str = "pdfplumber"
    precision_level: PrecisionLevel = PrecisionLevel.TABLE_OPTIMIZED
    extract_tables: bool = True

    def supports(self, mime: str) -> bool:
        """Return ``True`` when PDF and the library is installed."""
        return mime == MimeType.PDF.value and import_optional("pdfplumber") is not None

    def extract(self, document: Document) -> ExtractionOutcome:
        """Walk each page, collecting text and (optionally) tables."""
        library = import_optional("pdfplumber")
        if library is None:
            return ExtractionOutcome.fail(
                extractor_name=self.name,
                duration_seconds=0.0,
                error_message="pdfplumber is not installed; install with `pip install cyberdocextractor[pdf]`",
            )

        start = time.monotonic()
        blocks: list[Block] = []
        page_count = 0
        has_tables = False
        try:
            with library.open(io.BytesIO(document.content)) as pdf:
                for page_index, page in enumerate(pdf.pages, start=1):
                    page_count = page_index
                    text = (page.extract_text() or "").strip()
                    if text:
                        blocks.append(
                            Block(type=BlockType.TEXT, content=text, page_number=page_index)
                        )
                    if self.extract_tables:
                        for table in _safe_extract_tables(page):
                            md = _table_to_markdown(table)
                            if md:
                                has_tables = True
                                blocks.append(
                                    Block(
                                        type=BlockType.TABLE,
                                        content=md,
                                        page_number=page_index,
                                    )
                                )
        except Exception as exc:
            return ExtractionOutcome.fail(
                extractor_name=self.name,
                duration_seconds=time.monotonic() - start,
                error_message=f"pdfplumber extraction failed: {exc}",
            )

        if not blocks:
            return ExtractionOutcome.fail(
                extractor_name=self.name,
                duration_seconds=time.monotonic() - start,
                error_message="pdfplumber produced no content",
            )

        ndoc = NormalizedDoc(
            blocks=tuple(blocks),
            source_mime=document.mime,
            page_count=page_count or None,
            has_tables=has_tables,
            extractor_name=self.name,
        )
        return ExtractionOutcome.ok(
            extractor_name=self.name,
            duration_seconds=time.monotonic() - start,
            normalized_doc=ndoc,
        )


def _safe_extract_tables(page: Any) -> list[list[list[str | None]]]:
    try:
        return list(page.extract_tables() or [])
    except Exception:
        return []


def _table_to_markdown(table: list[list[str | None]]) -> str:
    if not table or not table[0]:
        return ""
    header = [c or "" for c in table[0]]
    width = len(header)
    body = table[1:]
    lines = [
        "| " + " | ".join(_cell(c) for c in header) + " |",
        "| " + " | ".join(["---"] * width) + " |",
    ]
    lines.extend(
        "| " + " | ".join(_cell(c) for c in (row + [""] * (width - len(row)))[:width]) + " |"
        for row in body
    )
    return "\n".join(lines)


def _cell(value: str | None) -> str:
    return (value or "").replace("|", r"\|").replace("\n", " ").strip()
