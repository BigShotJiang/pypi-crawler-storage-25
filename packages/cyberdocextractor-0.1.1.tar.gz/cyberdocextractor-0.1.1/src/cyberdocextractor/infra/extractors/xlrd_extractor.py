"""Legacy XLS (BIFF) extractor using :mod:`xlrd`.

``xlrd`` >= 2.0 dropped XLSX support and now targets only the legacy
binary `.xls` (Excel 97-2003) format - exactly what we need. Emits
one ``TABLE`` block per sheet, mirroring the :class:`OpenpyxlExtractor`
shape so templates render both with the same Jinja2 path.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any

from ...domain import (
    Block,
    BlockType,
    Document,
    ExtractionOutcome,
    MimeType,
    NormalizedDoc,
    PrecisionLevel,
)
from ._base import import_optional

__all__ = ["XlrdExtractor"]


@dataclass(frozen=True, slots=True)
class XlrdExtractor:
    """Adapter around ``xlrd.open_workbook`` for legacy `.xls` files."""

    name: str = "xlrd"
    precision_level: PrecisionLevel = PrecisionLevel.BALANCED
    max_rows_per_sheet: int | None = None

    def supports(self, mime: str) -> bool:
        """Return ``True`` for legacy XLS when ``xlrd`` is installed."""
        return mime == MimeType.XLS.value and import_optional("xlrd") is not None

    def extract(self, document: Document) -> ExtractionOutcome:
        """Iterate sheets, emitting one ``TABLE`` block each."""
        xlrd = import_optional("xlrd")
        if xlrd is None:
            return ExtractionOutcome.fail(
                extractor_name=self.name,
                duration_seconds=0.0,
                error_message="xlrd is not installed; install with `pip install cyberdocextractor[xlsx]`",
            )

        start = time.monotonic()
        blocks: list[Block] = []
        try:
            workbook = xlrd.open_workbook(file_contents=document.content)
            try:
                for sheet in workbook.sheets():
                    rows = _collect_rows(sheet, self.max_rows_per_sheet)
                    if not rows:
                        continue
                    markdown = _rows_to_markdown(rows)
                    header_length = len(rows[0]) if rows else 0
                    blocks.append(
                        Block(
                            type=BlockType.TABLE,
                            content=markdown,
                            metadata={
                                "sheet_name": sheet.name,
                                "row_count": max(len(rows) - 1, 0),
                                "column_count": header_length,
                            },
                        )
                    )
            finally:
                _maybe_close(workbook)
        except Exception as exc:
            return ExtractionOutcome.fail(
                extractor_name=self.name,
                duration_seconds=time.monotonic() - start,
                error_message=f"xlrd extraction failed: {exc}",
            )

        if not blocks:
            return ExtractionOutcome.fail(
                extractor_name=self.name,
                duration_seconds=time.monotonic() - start,
                error_message="xlrd produced no content",
            )

        ndoc = NormalizedDoc(
            blocks=tuple(blocks),
            source_mime=document.mime,
            has_tables=True,
            extractor_name=self.name,
        )
        return ExtractionOutcome.ok(
            extractor_name=self.name,
            duration_seconds=time.monotonic() - start,
            normalized_doc=ndoc,
        )


def _collect_rows(sheet: Any, max_rows: int | None) -> list[list[str]]:
    """Materialise rows as lists of strings, dropping fully-empty rows."""
    rows: list[list[str]] = []
    limit = sheet.nrows if max_rows is None else min(sheet.nrows, max_rows + 1)
    for row_index in range(limit):
        raw = sheet.row_values(row_index)
        cells = ["" if cell is None else _stringify(cell) for cell in raw]
        if any(c.strip() for c in cells):
            rows.append(cells)
    return rows


def _stringify(value: Any) -> str:
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value)


def _rows_to_markdown(rows: list[list[str]]) -> str:
    if not rows:
        return ""
    header, *body = rows
    width = len(header)
    normalised = [row + [""] * (width - len(row)) for row in body]
    lines = [
        "| " + " | ".join(_cell(c) for c in header) + " |",
        "| " + " | ".join(["---"] * width) + " |",
    ]
    lines.extend("| " + " | ".join(_cell(c) for c in row[:width]) + " |" for row in normalised)
    return "\n".join(lines)


def _cell(value: str) -> str:
    return value.replace("|", r"\|").replace("\n", " ").strip()


def _maybe_close(workbook: Any) -> None:
    close = getattr(workbook, "release_resources", None)
    if callable(close):
        close()
