"""CSV extractor using the Python standard library only.

No optional dependencies: CSVs are read with :mod:`csv.reader`,
dialects sniffed with :class:`csv.Sniffer`, and the result is rendered
as a Markdown pipe table.
"""

from __future__ import annotations

import csv
import io
from dataclasses import dataclass

from ...domain import (
    Block,
    BlockType,
    Document,
    ExtractionOutcome,
    MimeType,
    NormalizedDoc,
    PrecisionLevel,
)

__all__ = ["CsvExtractor"]

_SNIFF_BYTES = 4096
_FALLBACK_DIALECT = csv.excel


@dataclass(frozen=True, slots=True)
class CsvExtractor:
    """Read a CSV into a single Markdown table block.

    Dialect detection is attempted on the first ``_SNIFF_BYTES`` of the
    file. If sniffing fails the adapter falls back to the ``excel``
    dialect (comma-delimited).
    """

    name: str = "csv-stdlib"
    precision_level: PrecisionLevel = PrecisionLevel.BALANCED
    max_rows: int | None = None

    def supports(self, mime: str) -> bool:
        """Return ``True`` only for ``text/csv``."""
        return mime == MimeType.CSV.value

    def extract(self, document: Document) -> ExtractionOutcome:
        """Read CSV bytes and produce a :class:`NormalizedDoc`."""
        try:
            text, duration = _decode(document.content)
            dialect = _sniff_dialect(text)
            rows = [
                row
                for row in csv.reader(io.StringIO(text), dialect=dialect)
                if any(cell.strip() for cell in row)
            ]
            if self.max_rows is not None:
                rows = rows[: self.max_rows + 1]
            if not rows:
                return ExtractionOutcome.fail(
                    extractor_name=self.name,
                    duration_seconds=duration,
                    error_message="CSV contains no rows",
                )
            markdown_table = _rows_to_markdown_table(rows)
            block = Block(
                type=BlockType.TABLE,
                content=markdown_table,
                metadata={
                    "row_count": len(rows) - 1,
                    "column_count": len(rows[0]) if rows else 0,
                    "dialect": dialect.__class__.__name__.lower(),
                },
            )
            ndoc = NormalizedDoc(
                blocks=(block,),
                source_mime=document.mime,
                has_tables=True,
                extractor_name=self.name,
            )
        except Exception as exc:
            return ExtractionOutcome.fail(
                extractor_name=self.name,
                duration_seconds=0.0,
                error_message=f"CSV parsing failed: {exc}",
            )

        return ExtractionOutcome.ok(
            extractor_name=self.name,
            duration_seconds=duration,
            normalized_doc=ndoc,
        )


def _decode(content: bytes) -> tuple[str, float]:
    """Decode bytes as UTF-8 (with BOM tolerance) and measure work."""
    try:
        return content.decode("utf-8-sig"), 0.0
    except UnicodeDecodeError:
        return content.decode("latin-1"), 0.0


def _sniff_dialect(text: str) -> type[csv.Dialect] | csv.Dialect:
    sample = text[:_SNIFF_BYTES]
    try:
        return csv.Sniffer().sniff(sample, delimiters=",;\t|")
    except csv.Error:
        return _FALLBACK_DIALECT


def _rows_to_markdown_table(rows: list[list[str]]) -> str:
    if not rows:
        return ""
    header, *body = rows
    width = len(header)
    normalised_body = [row + [""] * (width - len(row)) for row in body]
    lines = [
        "| " + " | ".join(_escape(c) for c in header) + " |",
        "| " + " | ".join(["---"] * width) + " |",
    ]
    lines.extend(
        "| " + " | ".join(_escape(c) for c in row[:width]) + " |" for row in normalised_body
    )
    return "\n".join(lines)


def _escape(cell: str) -> str:
    return cell.replace("|", r"\|").replace("\n", " ")
