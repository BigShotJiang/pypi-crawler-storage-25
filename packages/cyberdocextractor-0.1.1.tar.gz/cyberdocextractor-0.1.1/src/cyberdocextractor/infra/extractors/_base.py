"""Shared helpers for extractor adapters.

Keeps each adapter small and makes lazy-import behaviour uniform:
``import_optional("docling")`` returns the module or ``None``, and a
module-level cache avoids repeating the import attempt on every call.
"""

from __future__ import annotations

import importlib
from typing import Any, Final

__all__ = ["import_optional", "is_available"]

_UNSET: Final[object] = object()
_cache: dict[str, Any] = {}


def import_optional(module_name: str) -> Any | None:
    """Try to import *module_name*; return ``None`` if the import fails.

    Results are cached so repeated calls are cheap.
    """
    cached = _cache.get(module_name, _UNSET)
    if cached is not _UNSET:
        return cached
    try:
        module = importlib.import_module(module_name)
    except Exception:
        module = None
    _cache[module_name] = module
    return module


def is_available(module_name: str) -> bool:
    """Return ``True`` if :func:`import_optional` would succeed."""
    return import_optional(module_name) is not None
