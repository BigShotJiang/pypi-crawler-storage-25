"""Legacy ``.doc`` extractor via LibreOffice headless conversion.

The legacy Microsoft Word binary format (CFBF-based) has no robust
pure-Python parser. This adapter does what every production tool
eventually settles on:

1. Spawn ``soffice --headless --convert-to docx`` (LibreOffice's
   command-line entry point).
2. Read the converted ``.docx`` with :mod:`python-docx`.
3. Emit ``HEADING`` / ``TEXT`` / ``TABLE`` blocks.

The upside is broad compatibility (LibreOffice handles practically
any real-world ``.doc`` file). The downside is a ~500 MiB optional
runtime dependency — so this adapter reports itself unavailable when
neither ``soffice`` nor ``libreoffice`` is on ``PATH``.
"""

from __future__ import annotations

import shutil
import subprocess
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ...domain import (
    Block,
    BlockType,
    Document,
    ExtractionOutcome,
    MimeType,
    NormalizedDoc,
    PrecisionLevel,
)
from ._base import import_optional

__all__ = ["LibreOfficeDocExtractor"]

_CONVERSION_TIMEOUT_DEFAULT = 60.0


@dataclass(frozen=True, slots=True)
class LibreOfficeDocExtractor:
    """Convert a ``.doc`` via LibreOffice, then parse with ``python-docx``."""

    name: str = "libreoffice-doc"
    precision_level: PrecisionLevel = PrecisionLevel.BALANCED
    command_candidates: tuple[str, ...] = ("soffice", "libreoffice")
    timeout_seconds: float = _CONVERSION_TIMEOUT_DEFAULT

    def supports(self, mime: str) -> bool:
        """Return ``True`` for legacy DOC when LibreOffice + python-docx are available."""
        if mime != MimeType.DOC.value:
            return False
        if import_optional("docx") is None:
            return False
        return _resolve_binary(self.command_candidates) is not None

    def extract(self, document: Document) -> ExtractionOutcome:
        """Convert via LibreOffice, parse the DOCX, emit Markdown blocks."""
        python_docx = import_optional("docx")
        if python_docx is None:
            return ExtractionOutcome.fail(
                extractor_name=self.name,
                duration_seconds=0.0,
                error_message=(
                    "python-docx is not installed; install with "
                    "`pip install cyberdocextractor[docx]`"
                ),
            )
        binary = _resolve_binary(self.command_candidates)
        if binary is None:
            return ExtractionOutcome.fail(
                extractor_name=self.name,
                duration_seconds=0.0,
                error_message=(
                    "LibreOffice is not installed. Install it and ensure `soffice` "
                    "is on PATH to enable .doc conversion."
                ),
            )

        start = time.monotonic()
        try:
            with tempfile.TemporaryDirectory(prefix="cyberdoc-doc-") as workdir:
                workpath = Path(workdir)
                source = workpath / "input.doc"
                source.write_bytes(document.content)
                docx_path = _convert(source, workpath, binary, self.timeout_seconds)
                blocks = _parse_docx(docx_path, python_docx)
        except _ConversionError as exc:
            return ExtractionOutcome.fail(
                extractor_name=self.name,
                duration_seconds=time.monotonic() - start,
                error_message=str(exc),
            )
        except Exception as exc:
            return ExtractionOutcome.fail(
                extractor_name=self.name,
                duration_seconds=time.monotonic() - start,
                error_message=f"libreoffice-doc extraction failed: {exc}",
            )

        if not blocks:
            return ExtractionOutcome.fail(
                extractor_name=self.name,
                duration_seconds=time.monotonic() - start,
                error_message="libreoffice-doc produced no content",
            )

        ndoc = NormalizedDoc(
            blocks=tuple(blocks),
            source_mime=document.mime,
            has_tables=any(b.type is BlockType.TABLE for b in blocks),
            extractor_name=self.name,
        )
        return ExtractionOutcome.ok(
            extractor_name=self.name,
            duration_seconds=time.monotonic() - start,
            normalized_doc=ndoc,
        )


# ---------------------------------------------------------------------------
# internals
# ---------------------------------------------------------------------------


class _ConversionError(RuntimeError):
    """Marker exception used so the wrapper can distinguish expected failures."""


def _resolve_binary(candidates: tuple[str, ...]) -> str | None:
    for name in candidates:
        found = shutil.which(name)
        if found is not None:
            return found
    return None


def _convert(source: Path, workdir: Path, binary: str, timeout: float) -> Path:
    """Run LibreOffice headless to produce a DOCX next to ``source``."""
    result = subprocess.run(  # noqa: S603 — binary resolved via shutil.which; args are literals
        [
            binary,
            "--headless",
            "--convert-to",
            "docx",
            "--outdir",
            str(workdir),
            str(source),
        ],
        capture_output=True,
        timeout=timeout,
        check=False,
    )
    if result.returncode != 0:
        stderr = result.stderr.decode("utf-8", errors="replace").strip()
        raise _ConversionError(
            f"soffice exited with code {result.returncode}: {stderr or 'no stderr'}"
        )
    docx_path = workdir / (source.stem + ".docx")
    if not docx_path.exists():
        raise _ConversionError(
            f"soffice did not produce {docx_path.name!r}; output was: "
            f"{result.stdout.decode('utf-8', errors='replace')!r}"
        )
    return docx_path


def _parse_docx(docx_path: Path, python_docx: Any) -> list[Block]:
    """Walk paragraphs + tables from a python-docx Document, emit Blocks."""
    document = python_docx.Document(str(docx_path))
    blocks: list[Block] = []

    for paragraph in document.paragraphs:
        text = (paragraph.text or "").strip()
        if not text:
            continue
        style = getattr(paragraph.style, "name", "") if paragraph.style else ""
        if style.startswith("Heading"):
            blocks.append(Block(type=BlockType.HEADING, content=text))
        else:
            blocks.append(Block(type=BlockType.TEXT, content=text))

    for table in document.tables:
        rendered = _table_to_markdown(table)
        if rendered:
            blocks.append(
                Block(
                    type=BlockType.TABLE,
                    content=rendered,
                    metadata={
                        "row_count": max(len(table.rows) - 1, 0),
                        "column_count": len(table.columns),
                    },
                )
            )
    return blocks


def _table_to_markdown(table: Any) -> str:
    rows = [[cell.text or "" for cell in row.cells] for row in table.rows]
    if not rows or not rows[0]:
        return ""
    header, *body = rows
    width = len(header)
    normalised = [row + [""] * (width - len(row)) for row in body]
    lines = [
        "| " + " | ".join(_cell(c) for c in header) + " |",
        "| " + " | ".join(["---"] * width) + " |",
    ]
    lines.extend("| " + " | ".join(_cell(c) for c in row[:width]) + " |" for row in normalised)
    return "\n".join(lines)


def _cell(value: str) -> str:
    return value.replace("|", r"\|").replace("\n", " ").strip()
