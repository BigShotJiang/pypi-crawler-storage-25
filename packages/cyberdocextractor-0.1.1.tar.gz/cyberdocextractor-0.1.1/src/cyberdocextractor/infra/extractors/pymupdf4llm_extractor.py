"""PDF extractor using :mod:`pymupdf4llm`.

Targets :attr:`PrecisionLevel.BALANCED` — good text + table fidelity at
moderate speed. Requires the ``pdf`` extra.
"""

from __future__ import annotations

import time
from dataclasses import dataclass

from ...domain import (
    Block,
    BlockType,
    Document,
    ExtractionOutcome,
    MimeType,
    NormalizedDoc,
    PrecisionLevel,
)
from ._base import import_optional

__all__ = ["Pymupdf4llmExtractor"]


@dataclass(frozen=True, slots=True)
class Pymupdf4llmExtractor:
    """Adapter around ``pymupdf4llm.to_markdown``."""

    name: str = "pymupdf4llm"
    precision_level: PrecisionLevel = PrecisionLevel.BALANCED
    page_chunks: bool = True

    def supports(self, mime: str) -> bool:
        """Return ``True`` when PDF and the library is installed."""
        return mime == MimeType.PDF.value and import_optional("pymupdf4llm") is not None

    def extract(self, document: Document) -> ExtractionOutcome:
        """Run :func:`pymupdf4llm.to_markdown` against ``document.content``."""
        library = import_optional("pymupdf4llm")
        if library is None:
            return ExtractionOutcome.fail(
                extractor_name=self.name,
                duration_seconds=0.0,
                error_message="pymupdf4llm is not installed; install with `pip install cyberdocextractor[pdf]`",
            )

        fitz = import_optional("fitz") or import_optional("pymupdf")
        if fitz is None:
            return ExtractionOutcome.fail(
                extractor_name=self.name,
                duration_seconds=0.0,
                error_message="PyMuPDF (fitz) is required; install with `pip install cyberdocextractor[pdf]`",
            )

        start = time.monotonic()
        try:
            doc = fitz.open(stream=document.content, filetype="pdf")
            try:
                chunks = library.to_markdown(doc, page_chunks=self.page_chunks)
            finally:
                doc.close()
        except Exception as exc:
            return ExtractionOutcome.fail(
                extractor_name=self.name,
                duration_seconds=time.monotonic() - start,
                error_message=f"pymupdf4llm extraction failed: {exc}",
            )

        blocks = tuple(_build_blocks(chunks))
        if not blocks:
            return ExtractionOutcome.fail(
                extractor_name=self.name,
                duration_seconds=time.monotonic() - start,
                error_message="pymupdf4llm produced no content",
            )

        has_tables = any("|" in b.content for b in blocks)
        ndoc = NormalizedDoc(
            blocks=blocks,
            source_mime=document.mime,
            page_count=_page_count(chunks),
            has_tables=has_tables,
            extractor_name=self.name,
        )
        return ExtractionOutcome.ok(
            extractor_name=self.name,
            duration_seconds=time.monotonic() - start,
            normalized_doc=ndoc,
        )


def _build_blocks(chunks: object) -> list[Block]:
    """Normalise the library's output into :class:`Block` objects.

    ``to_markdown`` returns either a ``str`` (when ``page_chunks=False``)
    or a ``list[dict]`` where each entry has at least a ``"text"``
    key and typically ``"metadata"`` with page info.
    """
    blocks: list[Block] = []
    if isinstance(chunks, str):
        stripped = chunks.strip()
        if stripped:
            blocks.append(Block(type=BlockType.TEXT, content=stripped))
        return blocks
    if isinstance(chunks, list):
        for item in chunks:
            if not isinstance(item, dict):
                continue
            text = str(item.get("text", "")).strip()
            if not text:
                continue
            meta = item.get("metadata") if isinstance(item.get("metadata"), dict) else {}
            page = meta.get("page") if isinstance(meta, dict) else None
            blocks.append(
                Block(
                    type=BlockType.TEXT,
                    content=text,
                    page_number=page if isinstance(page, int) and page > 0 else None,
                )
            )
    return blocks


def _page_count(chunks: object) -> int | None:
    if isinstance(chunks, list):
        return len(chunks) or None
    return None
