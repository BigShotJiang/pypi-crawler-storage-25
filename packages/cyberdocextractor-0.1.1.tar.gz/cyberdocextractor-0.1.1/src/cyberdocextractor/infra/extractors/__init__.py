"""Extractor adapters.

Each module in this package wraps one upstream library behind the
:class:`~cyberdocextractor.domain.Extractor` port. Heavy dependencies
(PyMuPDF, pdfplumber, Docling, openpyxl) are imported **lazily** — so
``pip install cyberdocextractor`` (with no extras) still works, and an
adapter whose dependency is missing simply reports itself as
unavailable via :meth:`supports`.
"""

from __future__ import annotations

from .csv_extractor import CsvExtractor
from .docling_extractor import DoclingExtractor
from .libreoffice_doc_extractor import LibreOfficeDocExtractor
from .openpyxl_extractor import OpenpyxlExtractor
from .pdfplumber_extractor import PdfplumberExtractor
from .pymupdf4llm_extractor import Pymupdf4llmExtractor
from .pymupdf_chunked_extractor import PymupdfChunkedExtractor
from .xlrd_extractor import XlrdExtractor

__all__ = [
    "CsvExtractor",
    "DoclingExtractor",
    "LibreOfficeDocExtractor",
    "OpenpyxlExtractor",
    "PdfplumberExtractor",
    "Pymupdf4llmExtractor",
    "PymupdfChunkedExtractor",
    "XlrdExtractor",
]
