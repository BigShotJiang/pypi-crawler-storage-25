"""Pure domain rules: size-based defaults, tabular heuristics, etc.

These are *functions over value objects* — no I/O, no mutable state. A
good test for whether code belongs here: it should be trivially
testable with just data.
"""

from __future__ import annotations

from typing import Final

from .enums import PrecisionLevel
from .mime import MimeType, classify_mime
from .values import TemplateContext

__all__ = [
    "LARGE_DOCUMENT_BYTES",
    "SMALL_DOCUMENT_BYTES",
    "default_precision_for_size",
    "default_template_for",
    "is_tabular_mime",
    "merge_template_metadata",
]


# Thresholds expressed in bytes for readability. Tuned to match common
# RAG corpora: scanned statements (<2 MiB) are worth OCR-quality work,
# while archival scans (>20 MiB) have to prioritise throughput.
SMALL_DOCUMENT_BYTES: Final[int] = 2 * 1024 * 1024
LARGE_DOCUMENT_BYTES: Final[int] = 20 * 1024 * 1024


def default_precision_for_size(size_bytes: int) -> PrecisionLevel:
    """Return the default precision for a document of the given size.

    The built-in selection policy uses this to infer a sensible default
    when the caller passes :attr:`PrecisionLevel.BALANCED` (the default)
    and doesn't force anything else.

    Rules:
        - ``< 2 MiB`` → :attr:`PrecisionLevel.HIGHEST_QUALITY`
          (small docs are cheap to process at full quality).
        - ``> 20 MiB`` → :attr:`PrecisionLevel.FASTEST`
          (large scans would stall the pipeline at higher levels).
        - otherwise → :attr:`PrecisionLevel.BALANCED`.

    Args:
        size_bytes: Size of the document in bytes. Must be positive.

    Returns:
        The recommended :class:`PrecisionLevel`.

    Raises:
        ValueError: If ``size_bytes`` is not positive.
    """
    if size_bytes <= 0:
        raise ValueError(f"size_bytes must be positive, got {size_bytes!r}")
    if size_bytes < SMALL_DOCUMENT_BYTES:
        return PrecisionLevel.HIGHEST_QUALITY
    if size_bytes > LARGE_DOCUMENT_BYTES:
        return PrecisionLevel.FASTEST
    return PrecisionLevel.BALANCED


def is_tabular_mime(mime: str) -> bool:
    """Return ``True`` iff *mime* is a spreadsheet- or CSV-like format."""
    recognised = classify_mime(mime)
    return recognised is not None and recognised.is_tabular


def default_template_for(mime: str) -> str:
    """Return the template name that best fits *mime*.

    - Tabular MIME types (XLSX/XLS/CSV) default to ``"tabular"``.
    - Everything else defaults to ``"default"``.
    """
    return "tabular" if is_tabular_mime(mime) else "default"


def merge_template_metadata(
    base: TemplateContext,
    extra: dict[str, object],
) -> TemplateContext:
    """Return a new context whose ``metadata`` has ``extra`` merged on top.

    Later keys win. Other fields are unchanged.
    """
    merged: dict[str, object] = dict(base.metadata)
    merged.update(extra)
    return TemplateContext(
        blocks=base.blocks,
        metadata=merged,
        has_tables=base.has_tables,
        has_images=base.has_images,
        page_count=base.page_count,
        quality_score=base.quality_score,
    )


# Silence the "unused import" checker — MimeType is re-exported for
# convenience at the domain root.
_ = MimeType
