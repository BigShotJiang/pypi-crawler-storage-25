"""Ports (``typing.Protocol``) that infrastructure adapters must satisfy.

Ports are intentionally *structural* — adapters don't inherit from them.
This keeps infrastructure code decoupled from the domain package and
makes it trivial to swap implementations in tests.

``@runtime_checkable`` is applied sparingly: only to ports where we
need ``isinstance(x, P)`` at runtime. For pure type-checking we rely on
mypy.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from datetime import datetime
from typing import Protocol, runtime_checkable

from .enums import PrecisionLevel
from .values import Document, ExtractionOutcome, NormalizedDoc

__all__ = [
    "Cache",
    "Clock",
    "Extractor",
    "ImageDescriber",
    "MetadataProbe",
    "QualityScorer",
    "SelectionPolicy",
    "TableProfiler",
    "TemplateRenderer",
]


@runtime_checkable
class Extractor(Protocol):
    """Turn raw document bytes into a :class:`NormalizedDoc`."""

    @property
    def name(self) -> str:
        """Stable, human-readable identifier (e.g. ``"pymupdf4llm"``)."""
        ...

    @property
    def precision_level(self) -> PrecisionLevel:
        """Precision level this adapter operates at."""
        ...

    def supports(self, mime: str) -> bool:
        """Return ``True`` if this adapter can handle *mime*."""
        ...

    def extract(self, document: Document) -> ExtractionOutcome:
        """Extract content.

        Implementations MUST NOT raise — they wrap failures in
        :class:`ExtractionOutcome.fail`. The orchestrator treats an
        exception as a bug.
        """
        ...


class SelectionPolicy(Protocol):
    """Choose the ordered chain of extractors for a given document."""

    def choose(
        self,
        *,
        mime: str,
        size_bytes: int,
        has_tables: bool,
        precision: PrecisionLevel,
    ) -> Sequence[Extractor]:
        """Return extractors to try, highest priority first.

        An empty sequence means no extractor is willing to handle the
        document; the orchestrator raises
        :class:`UnsupportedFormatError` in that case.
        """
        ...

    def by_precision(self, precision: PrecisionLevel) -> Extractor | None:
        """Return a specific extractor pinned to *precision*, if any."""
        ...


class TemplateRenderer(Protocol):
    """Render a :class:`TemplateContext`-style mapping to Markdown."""

    def render(self, template_name: str, context: Mapping[str, object]) -> str:
        """Render ``template_name`` with ``context``.

        Raises:
            RenderingError: If the template is missing or rendering fails.
        """
        ...

    def list_templates(self) -> Sequence[str]:
        """List the names of available templates."""
        ...


class QualityScorer(Protocol):
    """Score the quality of a conversion in ``[0.0, 1.0]``."""

    def score(
        self,
        *,
        normalized_doc: NormalizedDoc,
        markdown: str,
        original: Document | None = None,
    ) -> float: ...


class TableProfiler(Protocol):
    """Enrich a :class:`NormalizedDoc` with table-level statistics."""

    def profile(self, normalized_doc: NormalizedDoc) -> NormalizedDoc: ...


class ImageDescriber(Protocol):
    """Produce a textual description of an image block.

    Typically backed by a multimodal LLM.
    """

    def describe(
        self,
        *,
        image_data: bytes,
        context_text: str,
        mime_type: str,
    ) -> str: ...


class MetadataProbe(Protocol):
    """Extract format-specific metadata (creation date, author, ...).

    Kept as its own port so we don't bury format sniffing inside the
    orchestrator the way earlier iterations did.
    """

    def supports(self, mime: str) -> bool: ...

    def probe(self, document: Document) -> Mapping[str, str]: ...


class Cache(Protocol):
    """Optional cache of :class:`NormalizedDoc` by content hash."""

    def get(self, key: str) -> NormalizedDoc | None: ...

    def set(
        self,
        key: str,
        value: NormalizedDoc,
        *,
        ttl_seconds: int | None = None,
    ) -> None: ...

    def clear(self) -> None: ...


class Clock(Protocol):
    """Time source port.

    Injected into stages that want to timestamp or compute durations,
    so tests can pin time deterministically.
    """

    def now(self) -> datetime:
        """Return the current wall-clock time (timezone-aware)."""
        ...

    def monotonic(self) -> float:
        """Return a monotonic seconds value for duration measurement."""
        ...
