"""MIME type classification.

Kept pure and dependency-free. Anything that needs ``python-magic`` or
similar content-sniffing libraries lives in :mod:`cyberdocextractor.infra`.
"""

from __future__ import annotations

from enum import StrEnum
from types import MappingProxyType
from typing import Final

__all__ = ["MimeType", "classify_mime", "extension_to_mime"]


class MimeType(StrEnum):
    """MIME types recognised by the built-in extractor chain.

    New extractors may add more types, but the built-in selection policy
    routes only on these. The string values are the canonical IANA
    identifiers.
    """

    PDF = "application/pdf"
    DOCX = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    DOC = "application/msword"
    XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    XLS = "application/vnd.ms-excel"
    CSV = "text/csv"
    PLAIN = "text/plain"
    MARKDOWN = "text/markdown"

    @property
    def is_pdf(self) -> bool:
        """Return ``True`` for ``application/pdf``."""
        return self is MimeType.PDF

    @property
    def is_office_word(self) -> bool:
        """Return ``True`` for DOCX or legacy DOC."""
        return self in _WORD_TYPES

    @property
    def is_spreadsheet(self) -> bool:
        """Return ``True`` for XLSX or XLS."""
        return self in _SPREADSHEET_TYPES

    @property
    def is_tabular(self) -> bool:
        """Return ``True`` for any spreadsheet or CSV."""
        return self in _TABULAR_TYPES


_WORD_TYPES: Final[frozenset[MimeType]] = frozenset(
    {MimeType.DOCX, MimeType.DOC},
)

_SPREADSHEET_TYPES: Final[frozenset[MimeType]] = frozenset(
    {MimeType.XLSX, MimeType.XLS},
)

_TABULAR_TYPES: Final[frozenset[MimeType]] = frozenset(
    {MimeType.XLSX, MimeType.XLS, MimeType.CSV},
)

_EXTENSION_MAP: Final[MappingProxyType[str, MimeType]] = MappingProxyType(
    {
        ".pdf": MimeType.PDF,
        ".docx": MimeType.DOCX,
        ".doc": MimeType.DOC,
        ".xlsx": MimeType.XLSX,
        ".xls": MimeType.XLS,
        ".csv": MimeType.CSV,
        ".txt": MimeType.PLAIN,
        ".md": MimeType.MARKDOWN,
    }
)


def classify_mime(value: str) -> MimeType | None:
    """Return the :class:`MimeType` for a raw string, or ``None``.

    Accepts both canonical values (``"application/pdf"``) and
    case-insensitive matches with surrounding whitespace.

    Args:
        value: MIME string to classify.

    Returns:
        The matching :class:`MimeType`, or ``None`` if unknown.
    """
    if not value:
        return None
    normalised = value.strip().lower()
    for member in MimeType:
        if member.value.lower() == normalised:
            return member
    return None


def extension_to_mime(extension: str) -> MimeType | None:
    """Return the :class:`MimeType` for a filename extension.

    Accepts ``".pdf"`` or ``"pdf"``; matching is case-insensitive.

    Args:
        extension: File extension, with or without the leading dot.

    Returns:
        The matching :class:`MimeType`, or ``None`` if unknown.
    """
    if not extension:
        return None
    normalised = extension.lower()
    if not normalised.startswith("."):
        normalised = f".{normalised}"
    return _EXTENSION_MAP.get(normalised)
