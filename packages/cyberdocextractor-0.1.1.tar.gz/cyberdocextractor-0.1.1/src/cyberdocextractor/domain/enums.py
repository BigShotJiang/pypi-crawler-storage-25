"""Enumerations used across the domain.

Kept separate from :mod:`.values` so consumers can import the enums
without pulling in dataclass machinery (and because enums tend to show
up in signatures everywhere).
"""

from __future__ import annotations

from enum import IntEnum, StrEnum

__all__ = ["BlockType", "PrecisionLevel"]


class PrecisionLevel(IntEnum):
    """Extraction precision / fidelity levels.

    Higher levels are slower but produce higher-quality output. The numeric
    values are part of the public API — they appear in CLI flags and
    persisted configs, so they MUST NOT be reordered.
    """

    FASTEST = 1
    """Fastest path. Minimal layout analysis, no table statistics."""

    BALANCED = 2
    """Default. Good text + table output at reasonable speed."""

    TABLE_OPTIMIZED = 3
    """Favours table fidelity. Slower on prose-heavy documents."""

    HIGHEST_QUALITY = 4
    """Best output. OCR, image layout, full structure — slowest."""

    @property
    def label(self) -> str:
        """Return a human-readable label (``"Fastest"``, ``"Balanced"``, …)."""
        return self.name.replace("_", " ").title()


class BlockType(StrEnum):
    """Kinds of semantic block a :class:`NormalizedDoc` can contain.

    String values are stable (written into templates, JSON, etc.) and
    MUST NOT change between minor releases.
    """

    TEXT = "text"
    HEADING = "heading"
    LIST = "list"
    TABLE = "table"
    IMAGE = "image"
    CODE = "code"
    METADATA = "metadata"
    SEPARATOR = "separator"
