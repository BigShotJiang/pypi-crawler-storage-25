"""Immutable value objects that flow through the pipeline.

Every dataclass in this module is ``frozen`` and ``slots=True`` — they
are hashable, cheap to copy by reference, and safe to share across
threads. Invariants are enforced in ``__post_init__`` and raise
:class:`ValidationError` (which subclasses ``ValueError``).

No I/O, no logging, no external library imports. This is part of the
pure domain core.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, Self

from .enums import BlockType, PrecisionLevel
from .errors import ValidationError

__all__ = [
    "Block",
    "ConversionReport",
    "Document",
    "ExtractionOutcome",
    "Markdown",
    "NormalizedDoc",
    "TemplateContext",
]


def _freeze_mapping(data: Mapping[str, Any] | None) -> Mapping[str, Any]:
    """Return an immutable view of ``data`` (``{}`` when ``None``).

    We wrap with :class:`MappingProxyType` so even though the outer
    dataclass is frozen, we do not hand callers a mutable dict they can
    silently mutate.
    """
    return MappingProxyType(dict(data) if data else {})


# ---------------------------------------------------------------------------
# Document — pipeline input
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class Document:
    """Raw input to the conversion pipeline.

    Attributes:
        content: The raw bytes of the source document.
        mime: IANA MIME type. Must be non-empty.
        size_bytes: Size of ``content`` in bytes. Must be positive.
        precision: Desired extraction precision.
        filename: Original filename, if known. Used only for display and
            as an extractor hint — the MIME type is authoritative.
        metadata: Caller-supplied hints (``{"has_tables": True}``, …).
    """

    content: bytes
    mime: str
    size_bytes: int
    precision: PrecisionLevel = PrecisionLevel.BALANCED
    filename: str | None = None
    metadata: Mapping[str, Any] = field(default_factory=lambda: MappingProxyType({}))

    def __post_init__(self) -> None:
        if not self.content:
            raise ValidationError("Document content must not be empty")
        if not self.mime or not self.mime.strip():
            raise ValidationError("Document mime must be a non-empty string")
        if self.size_bytes <= 0:
            raise ValidationError("Document size_bytes must be positive")
        if self.size_bytes != len(self.content):
            raise ValidationError(
                f"size_bytes ({self.size_bytes}) does not match len(content) ({len(self.content)})"
            )
        object.__setattr__(self, "metadata", _freeze_mapping(self.metadata))

    @property
    def size_mb(self) -> float:
        """Document size in mebibytes (MiB)."""
        return self.size_bytes / (1024 * 1024)

    def with_precision(self, precision: PrecisionLevel) -> Self:
        """Return a copy with the precision overridden."""
        return type(self)(
            content=self.content,
            mime=self.mime,
            size_bytes=self.size_bytes,
            precision=precision,
            filename=self.filename,
            metadata=self.metadata,
        )


# ---------------------------------------------------------------------------
# Block — unit of extracted content
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class Block:
    """A single semantic unit extracted from a document.

    Attributes:
        type: What kind of block this is.
        content: The textual content (Markdown-ready for most types).
        metadata: Free-form extractor-specific metadata.
        page_number: 1-indexed page number when applicable.
        confidence: Extractor confidence in ``[0.0, 1.0]``.
        image_data: Raw image bytes for :attr:`BlockType.IMAGE` blocks.
    """

    type: BlockType
    content: str
    metadata: Mapping[str, Any] = field(default_factory=lambda: MappingProxyType({}))
    page_number: int | None = None
    confidence: float = 1.0
    image_data: bytes | None = None

    def __post_init__(self) -> None:
        if not 0.0 <= self.confidence <= 1.0:
            raise ValidationError(
                f"Block.confidence must be in [0.0, 1.0], got {self.confidence!r}"
            )
        if self.page_number is not None and self.page_number < 1:
            raise ValidationError(
                f"Block.page_number must be >= 1 or None, got {self.page_number!r}"
            )
        if self.type is not BlockType.IMAGE and self.image_data is not None:
            raise ValidationError("Only IMAGE blocks may carry image_data")
        object.__setattr__(self, "metadata", _freeze_mapping(self.metadata))


# ---------------------------------------------------------------------------
# NormalizedDoc — vendor-agnostic extractor output
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class NormalizedDoc:
    """Vendor-agnostic intermediate representation.

    Every extractor adapter produces one of these. Templates, scorers,
    and profilers operate exclusively on this type so they stay
    independent of the upstream library that produced the content.
    """

    blocks: tuple[Block, ...]
    source_mime: str
    page_count: int | None = None
    has_tables: bool = False
    has_images: bool = False
    extractor_name: str | None = None
    metadata: Mapping[str, Any] = field(default_factory=lambda: MappingProxyType({}))

    def __post_init__(self) -> None:
        if not self.blocks:
            raise ValidationError("NormalizedDoc must contain at least one Block")
        if self.page_count is not None and self.page_count < 1:
            raise ValidationError(
                f"NormalizedDoc.page_count must be >= 1 or None, got {self.page_count!r}"
            )
        if not self.source_mime or not self.source_mime.strip():
            raise ValidationError("NormalizedDoc.source_mime must be non-empty")
        object.__setattr__(self, "metadata", _freeze_mapping(self.metadata))

    @property
    def text_content(self) -> str:
        """Concatenated text of all :attr:`BlockType.TEXT` blocks."""
        return "\n\n".join(b.content for b in self.blocks if b.type is BlockType.TEXT)

    def blocks_of(self, block_type: BlockType) -> tuple[Block, ...]:
        """Return only blocks of the given type, in order."""
        return tuple(b for b in self.blocks if b.type is block_type)

    def with_blocks(self, blocks: Sequence[Block]) -> Self:
        """Return a copy with a replaced block sequence.

        Useful for pipeline stages that transform one block type
        (e.g. image enrichment) without touching other fields.
        """
        return type(self)(
            blocks=tuple(blocks),
            source_mime=self.source_mime,
            page_count=self.page_count,
            has_tables=self.has_tables,
            has_images=self.has_images,
            extractor_name=self.extractor_name,
            metadata=self.metadata,
        )


# ---------------------------------------------------------------------------
# Markdown — pipeline output
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class Markdown:
    """Final Markdown output of a conversion.

    Attributes:
        text: The rendered Markdown.
        quality_score: Scorer output in ``[0.0, 1.0]``.
        metadata: Extra fields (extractor name, timings, ...).
    """

    text: str
    quality_score: float
    metadata: Mapping[str, Any] = field(default_factory=lambda: MappingProxyType({}))

    def __post_init__(self) -> None:
        if not 0.0 <= self.quality_score <= 1.0:
            raise ValidationError(
                f"Markdown.quality_score must be in [0.0, 1.0], got {self.quality_score!r}"
            )
        object.__setattr__(self, "metadata", _freeze_mapping(self.metadata))

    @property
    def char_count(self) -> int:
        """Number of characters in :attr:`text`."""
        return len(self.text)

    @property
    def word_count(self) -> int:
        """Whitespace-split token count of :attr:`text`."""
        return len(self.text.split())


# ---------------------------------------------------------------------------
# ExtractionOutcome — result of a single extractor attempt
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class ExtractionOutcome:
    """Tagged result of a single extractor attempt.

    Prefer constructing via :meth:`ok` and :meth:`fail` factories —
    they enforce the discriminated-union invariant.
    """

    success: bool
    extractor_name: str
    duration_seconds: float
    normalized_doc: NormalizedDoc | None = None
    error_message: str | None = None

    def __post_init__(self) -> None:
        if self.duration_seconds < 0:
            raise ValidationError("duration_seconds cannot be negative")
        if not self.extractor_name:
            raise ValidationError("extractor_name must be non-empty")
        if self.success and self.normalized_doc is None:
            raise ValidationError("Successful outcome must carry a NormalizedDoc")
        if not self.success and not self.error_message:
            raise ValidationError("Failed outcome must carry an error_message")

    @classmethod
    def ok(
        cls,
        *,
        extractor_name: str,
        duration_seconds: float,
        normalized_doc: NormalizedDoc,
    ) -> Self:
        """Build a successful outcome carrying ``normalized_doc``."""
        return cls(
            success=True,
            extractor_name=extractor_name,
            duration_seconds=duration_seconds,
            normalized_doc=normalized_doc,
        )

    @classmethod
    def fail(
        cls,
        *,
        extractor_name: str,
        duration_seconds: float,
        error_message: str,
    ) -> Self:
        """Build a failed outcome carrying ``error_message``."""
        return cls(
            success=False,
            extractor_name=extractor_name,
            duration_seconds=duration_seconds,
            error_message=error_message,
        )


# ---------------------------------------------------------------------------
# TemplateContext — what the renderer sees
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class TemplateContext:
    """Pure-data view of a :class:`NormalizedDoc` passed to templates.

    Kept separate from :class:`NormalizedDoc` so templates cannot reach
    into domain internals, and so adding fields to the Markdown layer
    doesn't force a template-context bump.
    """

    blocks: tuple[Mapping[str, Any], ...]
    metadata: Mapping[str, Any]
    has_tables: bool
    has_images: bool
    page_count: int | None
    quality_score: float | None = None

    def __post_init__(self) -> None:
        if self.page_count is not None and self.page_count < 1:
            raise ValidationError("page_count must be >= 1 or None")
        if self.quality_score is not None and not 0.0 <= self.quality_score <= 1.0:
            raise ValidationError("quality_score must be in [0.0, 1.0] or None")
        object.__setattr__(
            self,
            "blocks",
            tuple(MappingProxyType(dict(b)) for b in self.blocks),
        )
        object.__setattr__(self, "metadata", _freeze_mapping(self.metadata))

    def as_mapping(self) -> Mapping[str, Any]:
        """Return a read-only mapping suitable for template engines."""
        return MappingProxyType(
            {
                "blocks": self.blocks,
                "metadata": self.metadata,
                "has_tables": self.has_tables,
                "has_images": self.has_images,
                "page_count": self.page_count,
                "quality_score": self.quality_score,
            }
        )

    @classmethod
    def from_normalized_doc(
        cls,
        normalized_doc: NormalizedDoc,
        *,
        original: Document | None = None,
        quality_score: float | None = None,
        extra_metadata: Mapping[str, Any] | None = None,
    ) -> Self:
        """Build a :class:`TemplateContext` from a :class:`NormalizedDoc`.

        Blocks are flattened into dicts that merge ``metadata`` into the
        top level so templates can write ``block.page_number`` without
        digging into a nested map.

        Args:
            normalized_doc: Source document.
            original: The original :class:`Document`, if available.
                Only its ``filename`` is consumed.
            quality_score: Pre-computed quality score for the render.
            extra_metadata: Extra metadata keys merged last (they win
                over both ``normalized_doc.metadata`` and any derived
                defaults).
        """
        blocks = tuple(
            {
                "type": block.type.value,
                "content": block.content,
                "page_number": block.page_number,
                "confidence": block.confidence,
                **block.metadata,
            }
            for block in normalized_doc.blocks
        )
        metadata: dict[str, Any] = dict(normalized_doc.metadata)
        if normalized_doc.extractor_name:
            metadata.setdefault("extractor", normalized_doc.extractor_name)
        if original is not None and original.filename:
            metadata.setdefault("filename", original.filename)
        if extra_metadata:
            metadata.update(extra_metadata)
        return cls(
            blocks=blocks,
            metadata=metadata,
            has_tables=normalized_doc.has_tables,
            has_images=normalized_doc.has_images,
            page_count=normalized_doc.page_count,
            quality_score=quality_score,
        )


# ---------------------------------------------------------------------------
# ConversionReport — full pipeline result
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class ConversionReport:
    """Everything a caller might want to know about a completed run.

    Returned by the application-layer pipeline. Includes the
    :class:`Markdown` output plus diagnostics (attempted chain, timings,
    final extractor).
    """

    markdown: Markdown
    extractor: str
    precision: PrecisionLevel
    attempted: tuple[str, ...]
    extraction_duration_seconds: float
    rendering_duration_seconds: float

    def __post_init__(self) -> None:
        if self.extraction_duration_seconds < 0 or self.rendering_duration_seconds < 0:
            raise ValidationError("Durations cannot be negative")
        if not self.extractor:
            raise ValidationError("extractor must be non-empty")
        if not self.attempted:
            raise ValidationError("attempted must list at least the chosen extractor")

    @property
    def total_duration_seconds(self) -> float:
        """Sum of extraction and rendering durations."""
        return self.extraction_duration_seconds + self.rendering_duration_seconds
