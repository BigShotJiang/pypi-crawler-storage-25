"""Domain layer — pure, dependency-free core.

This package contains the stable, vendor-free vocabulary of the
conversion pipeline:

- **Value objects** (:mod:`.values`): :class:`Document`, :class:`Block`,
  :class:`NormalizedDoc`, :class:`Markdown`, :class:`ExtractionOutcome`,
  :class:`TemplateContext`, :class:`ConversionReport`.
- **Enumerations** (:mod:`.enums`): :class:`PrecisionLevel`,
  :class:`BlockType`.
- **MIME classification** (:mod:`.mime`): :class:`MimeType`,
  :func:`classify_mime`, :func:`extension_to_mime`.
- **Ports** (:mod:`.ports`): the Protocols every adapter must satisfy.
- **Errors** (:mod:`.errors`): the typed exception hierarchy.
- **Rules** (:mod:`.rules`): pure-function heuristics.

Import directly from ``cyberdocextractor.domain`` to use the stable
public API. Importing from submodules is supported but discouraged —
submodule names may change, the re-exports listed here will not.
"""

from __future__ import annotations

from .enums import BlockType, PrecisionLevel
from .errors import (
    ConversionFailedError,
    CyberDocError,
    ExtractionError,
    FatalExtractionError,
    NoExtractorAvailableError,
    RecoverableExtractionError,
    RenderingError,
    UnsupportedFormatError,
    ValidationError,
)
from .mime import MimeType, classify_mime, extension_to_mime
from .ports import (
    Cache,
    Clock,
    Extractor,
    ImageDescriber,
    MetadataProbe,
    QualityScorer,
    SelectionPolicy,
    TableProfiler,
    TemplateRenderer,
)
from .rules import (
    LARGE_DOCUMENT_BYTES,
    SMALL_DOCUMENT_BYTES,
    default_precision_for_size,
    default_template_for,
    is_tabular_mime,
    merge_template_metadata,
)
from .values import (
    Block,
    ConversionReport,
    Document,
    ExtractionOutcome,
    Markdown,
    NormalizedDoc,
    TemplateContext,
)

__all__ = [
    "LARGE_DOCUMENT_BYTES",
    "SMALL_DOCUMENT_BYTES",
    "Block",
    "BlockType",
    "Cache",
    "Clock",
    "ConversionFailedError",
    "ConversionReport",
    "CyberDocError",
    "Document",
    "ExtractionError",
    "ExtractionOutcome",
    "Extractor",
    "FatalExtractionError",
    "ImageDescriber",
    "Markdown",
    "MetadataProbe",
    "MimeType",
    "NoExtractorAvailableError",
    "NormalizedDoc",
    "PrecisionLevel",
    "QualityScorer",
    "RecoverableExtractionError",
    "RenderingError",
    "SelectionPolicy",
    "TableProfiler",
    "TemplateContext",
    "TemplateRenderer",
    "UnsupportedFormatError",
    "ValidationError",
    "classify_mime",
    "default_precision_for_size",
    "default_template_for",
    "extension_to_mime",
    "is_tabular_mime",
    "merge_template_metadata",
]
