"""Typed error hierarchy.

All domain-originated exceptions derive from :class:`CyberDocError` so
callers can catch everything with a single ``except`` if they want. The
hierarchy also distinguishes *recoverable* errors (for which the pipeline
should fall back to the next extractor) from fatal ones.
"""

from __future__ import annotations

from collections.abc import Sequence

__all__ = [
    "ConversionFailedError",
    "CyberDocError",
    "ExtractionError",
    "FatalExtractionError",
    "NoExtractorAvailableError",
    "RecoverableExtractionError",
    "RenderingError",
    "UnsupportedFormatError",
    "ValidationError",
]


class CyberDocError(Exception):
    """Base class for all domain-originated errors."""


class ValidationError(CyberDocError, ValueError):
    """Raised when a value object fails its invariants."""


class ExtractionError(CyberDocError):
    """Base class for errors raised by extractor adapters."""

    def __init__(self, message: str, *, extractor_name: str | None = None) -> None:
        super().__init__(message)
        self.extractor_name = extractor_name


class RecoverableExtractionError(ExtractionError):
    """Extraction failed but the pipeline may try the next extractor.

    Use for upstream hiccups (transient I/O, one corrupt page in a long
    document, transient LLM timeouts, ...). The orchestrator treats this
    as a signal to *try the next candidate* in the policy chain.
    """


class FatalExtractionError(ExtractionError):
    """Extraction failed and no fallback should be attempted.

    Use when further extractors on the same document are guaranteed to
    fail too (e.g. the file is not really a PDF, password-protected, the
    caller explicitly passed ``allow_fallback=False``).
    """


class UnsupportedFormatError(CyberDocError):
    """Raised when no extractor supports the requested MIME type."""

    def __init__(self, mime: str) -> None:
        super().__init__(f"No extractor supports MIME type {mime!r}")
        self.mime = mime


class NoExtractorAvailableError(CyberDocError):
    """Raised when the policy chain resolved to an empty extractor list."""


class RenderingError(CyberDocError):
    """Raised when template rendering fails."""

    def __init__(self, message: str, *, template_name: str | None = None) -> None:
        super().__init__(message)
        self.template_name = template_name


class ConversionFailedError(CyberDocError):
    """Terminal error: every extractor in the chain failed.

    Carries the list of attempted extractors so callers can diagnose
    what was tried and in what order.
    """

    def __init__(
        self,
        message: str,
        *,
        attempted_extractors: Sequence[str] = (),
        last_error: str | None = None,
    ) -> None:
        super().__init__(message)
        self.attempted_extractors: tuple[str, ...] = tuple(attempted_extractors)
        self.last_error = last_error
