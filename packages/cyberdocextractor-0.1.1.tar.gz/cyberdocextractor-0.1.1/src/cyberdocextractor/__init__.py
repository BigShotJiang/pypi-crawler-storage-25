"""CyberDocExtractor — production-grade document-to-Markdown conversion.

Stable public API re-exports. Everything exported here is considered
part of the semver contract; modules not re-exported are internal and
may change between minor versions.

Typical usage::

    from pathlib import Path
    from cyberdocextractor import PrecisionLevel, build_pipeline, load_document

    pipeline = build_pipeline()
    document = load_document(Path("report.pdf"), precision=PrecisionLevel.BALANCED)
    report = pipeline.convert(document)
    print(report.markdown.text)
"""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("cyberdocextractor")
except PackageNotFoundError:  # pragma: no cover — editable/source trees only
    __version__ = "0.0.0+local"

from .app import (
    BatchFailure,
    BatchItem,
    BatchResult,
    BatchSuccess,
    ConversionPipeline,
    NullScorer,
    SystemClock,
    UnknownExtensionError,
    convert_batch,
    discover_batch,
    load_document,
)
from .domain import (
    Block,
    BlockType,
    ConversionFailedError,
    ConversionReport,
    CyberDocError,
    Document,
    ExtractionError,
    ExtractionOutcome,
    Markdown,
    MimeType,
    NormalizedDoc,
    PrecisionLevel,
    RenderingError,
    TemplateContext,
    UnsupportedFormatError,
    ValidationError,
)
from .factory import DEFAULT_EXTRACTOR_NAMES, build_pipeline

__all__ = [
    "DEFAULT_EXTRACTOR_NAMES",
    "BatchFailure",
    "BatchItem",
    "BatchResult",
    "BatchSuccess",
    "Block",
    "BlockType",
    "ConversionFailedError",
    "ConversionPipeline",
    "ConversionReport",
    "CyberDocError",
    "Document",
    "ExtractionError",
    "ExtractionOutcome",
    "Markdown",
    "MimeType",
    "NormalizedDoc",
    "NullScorer",
    "PrecisionLevel",
    "RenderingError",
    "SystemClock",
    "TemplateContext",
    "UnknownExtensionError",
    "UnsupportedFormatError",
    "ValidationError",
    "__version__",
    "build_pipeline",
    "convert_batch",
    "discover_batch",
    "load_document",
]
