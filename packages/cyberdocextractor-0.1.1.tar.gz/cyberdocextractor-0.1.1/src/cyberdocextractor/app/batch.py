"""Batch conversion helpers.

A thin orchestrator that runs :class:`ConversionPipeline.convert` over
many files and writes the Markdown outputs to disk. Failures are
captured in :class:`BatchResult` rather than raised, so a single bad
document doesn't abort an overnight batch.
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path

from ..domain import ConversionReport, PrecisionLevel
from .loader import load_document
from .pipeline import ConversionPipeline

__all__ = [
    "BatchFailure",
    "BatchItem",
    "BatchResult",
    "BatchSuccess",
    "convert_batch",
    "discover_batch",
]


@dataclass(frozen=True, slots=True)
class BatchItem:
    """Source path and desired output path for a single conversion."""

    source: Path
    target: Path


@dataclass(frozen=True, slots=True)
class BatchSuccess:
    """A conversion that produced output on disk."""

    source: Path
    target: Path
    report: ConversionReport


@dataclass(frozen=True, slots=True)
class BatchFailure:
    """A conversion that failed; captured so the batch can continue."""

    source: Path
    error: str
    error_type: str


@dataclass(frozen=True, slots=True)
class BatchResult:
    """Aggregate of a batch run.

    Attributes:
        succeeded: Tuple of per-file successes.
        failed: Tuple of per-file failures.
    """

    succeeded: tuple[BatchSuccess, ...]
    failed: tuple[BatchFailure, ...]

    @property
    def total(self) -> int:
        """Number of items processed."""
        return len(self.succeeded) + len(self.failed)

    @property
    def success_rate(self) -> float:
        """Successes over total; ``0.0`` when no items were processed."""
        return len(self.succeeded) / self.total if self.total else 0.0


def discover_batch(
    source_dir: Path,
    target_dir: Path,
    *,
    pattern: str = "*",
    target_suffix: str = ".md",
) -> tuple[BatchItem, ...]:
    """Walk *source_dir* and build :class:`BatchItem` entries.

    The output path mirrors the source directory tree relative to
    *source_dir* under *target_dir*, with the extension replaced by
    *target_suffix* (``".md"`` by default).

    Args:
        source_dir: Directory to scan. Must exist.
        target_dir: Directory where outputs are written.
        pattern: Glob pattern passed to :meth:`Path.rglob`.
        target_suffix: Suffix for the output files.
    """
    if not source_dir.is_dir():
        raise NotADirectoryError(f"Not a directory: {source_dir}")

    items: list[BatchItem] = []
    for path in sorted(source_dir.rglob(pattern)):
        if not path.is_file():
            continue
        relative = path.relative_to(source_dir).with_suffix(target_suffix)
        items.append(BatchItem(source=path, target=target_dir / relative))
    return tuple(items)


def convert_batch(
    pipeline: ConversionPipeline,
    items: Iterable[BatchItem],
    *,
    template_name: str | None = None,
    precision: PrecisionLevel = PrecisionLevel.BALANCED,
) -> BatchResult:
    """Convert every :class:`BatchItem` using *pipeline*.

    Writes each successful result to ``item.target``, creating parent
    directories as needed. Failures are accumulated in the returned
    :class:`BatchResult`.

    Args:
        pipeline: Configured :class:`ConversionPipeline`.
        items: Iterable of :class:`BatchItem`.
        template_name: Optional template override applied to every
            item.
        precision: Precision applied to every item.

    Returns:
        A :class:`BatchResult` summarising successes and failures.
    """
    successes: list[BatchSuccess] = []
    failures: list[BatchFailure] = []

    for item in items:
        try:
            document = load_document(item.source, precision=precision)
            report = pipeline.convert(document, template_name=template_name)
            item.target.parent.mkdir(parents=True, exist_ok=True)
            item.target.write_text(report.markdown.text, encoding="utf-8")
            successes.append(BatchSuccess(source=item.source, target=item.target, report=report))
        except Exception as exc:
            failures.append(
                BatchFailure(
                    source=item.source,
                    error=str(exc),
                    error_type=type(exc).__name__,
                )
            )

    return BatchResult(tuple(successes), tuple(failures))
