"""Composition root for the conversion pipeline.

:class:`ConversionPipeline` wires together the five stages and exposes
a single :meth:`convert` entrypoint. All dependencies are
domain ports, so the pipeline knows nothing about PyMuPDF, Jinja2, or
any other concrete library.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field

from ..domain import (
    Clock,
    ConversionReport,
    Document,
    ImageDescriber,
    Markdown,
    MetadataProbe,
    PrecisionLevel,
    QualityScorer,
    SelectionPolicy,
    TableProfiler,
    TemplateRenderer,
    default_template_for,
)
from .clock import SystemClock
from .scoring import NullScorer
from .stages import (
    ExtractionStage,
    ImageEnrichmentStage,
    MetadataStage,
    RenderingStage,
    TableProfilingStage,
)
from .state import PipelineState

__all__ = ["ConversionPipeline"]


@dataclass
class ConversionPipeline:
    """Convert documents to Markdown by composing domain ports.

    The pipeline is stateless across calls — the only "state" lives in
    the :class:`PipelineState` that flows through the stages. You can
    share a single pipeline across threads as long as the underlying
    adapters are thread-safe.

    Attributes:
        policy: Selects the ordered extractor chain per document.
        renderer: Concrete template renderer (Jinja2, etc.).
        scorer: Quality scorer. Defaults to :class:`NullScorer` (returns
            ``1.0`` regardless of content).
        table_profilers: Optional sequence of table profilers run in
            order after extraction.
        metadata_probes: Optional sequence of metadata probes; only
            probes whose :meth:`supports` returns ``True`` are queried.
        image_describer: Optional multimodal LLM adapter for image
            descriptions. When ``None``, :class:`ImageEnrichmentStage`
            is a no-op.
        clock: Time source for duration measurement. Defaults to
            :class:`SystemClock`.
        max_images_per_document: Upper bound on LLM calls per document
            (``-1`` disables the cap).
        image_context_lines: Window size fed to the image describer.
    """

    policy: SelectionPolicy
    renderer: TemplateRenderer
    scorer: QualityScorer = field(default_factory=NullScorer)
    table_profilers: Sequence[TableProfiler] = field(default_factory=tuple)
    metadata_probes: Sequence[MetadataProbe] = field(default_factory=tuple)
    image_describer: ImageDescriber | None = None
    clock: Clock = field(default_factory=SystemClock)
    max_images_per_document: int = 5
    image_context_lines: int = 100

    def convert(
        self,
        document: Document,
        *,
        template_name: str | None = None,
        allow_fallback: bool = True,
    ) -> ConversionReport:
        """Convert a document to Markdown.

        Args:
            document: The :class:`Document` to convert.
            template_name: Template to render with. When ``None``, the
                default is inferred from the document's MIME type
                (``"tabular"`` for spreadsheets/CSV, ``"default"``
                otherwise).
            allow_fallback: If ``True`` (the default), failures in the
                primary extractor cascade to the next candidate in the
                policy chain; if ``False``, only the top-ranked
                candidate is attempted.

        Returns:
            A :class:`ConversionReport` with the rendered Markdown and
            per-stage timing / attempt diagnostics.

        Raises:
            UnsupportedFormatError: If no extractor supports the MIME type.
            ConversionFailedError: If every candidate extractor failed.
            RenderingError: If the renderer raised.
        """
        chosen_template = template_name or default_template_for(document.mime)
        initial = PipelineState(
            document=document,
            template_name=chosen_template,
            allow_fallback=allow_fallback,
        )

        extraction = ExtractionStage(policy=self.policy, clock=self.clock)
        metadata = MetadataStage(probes=self.metadata_probes)
        image = ImageEnrichmentStage(
            describer=self.image_describer,
            max_images=self.max_images_per_document,
            context_lines=self.image_context_lines,
        )
        tables = TableProfilingStage(profilers=self.table_profilers)
        rendering = RenderingStage(renderer=self.renderer, scorer=self.scorer, clock=self.clock)

        state = extraction.run(initial)
        state = metadata.run(state)
        state = image.run(state)
        state = tables.run(state)
        state = rendering.run(state)

        return _build_report(state, document.precision)


def _build_report(
    state: PipelineState,
    precision: PrecisionLevel,
) -> ConversionReport:
    # These invariants are enforced by the preceding stages; asserting
    # them keeps the type checker happy and surfaces any regression
    # early, instead of failing deep inside :class:`Markdown`.
    if state.markdown_text is None or state.quality_score is None:
        raise RuntimeError("Rendering stage did not populate markdown_text / quality_score")
    if state.chosen_extractor is None:
        raise RuntimeError("Extraction stage did not populate chosen_extractor")

    markdown = Markdown(
        text=state.markdown_text,
        quality_score=state.quality_score,
        metadata={
            "extractor": state.chosen_extractor,
            "precision_level": precision.value,
            "attempted": list(state.attempted),
            "extraction_seconds": state.extraction_duration_seconds,
            "rendering_seconds": state.rendering_duration_seconds,
            "images_described": state.images_described,
        },
    )
    return ConversionReport(
        markdown=markdown,
        extractor=state.chosen_extractor,
        precision=precision,
        attempted=state.attempted,
        extraction_duration_seconds=state.extraction_duration_seconds,
        rendering_duration_seconds=state.rendering_duration_seconds,
    )
