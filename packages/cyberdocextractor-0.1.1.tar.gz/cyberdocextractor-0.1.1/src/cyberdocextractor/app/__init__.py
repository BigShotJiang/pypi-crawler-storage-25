"""Application layer — orchestration over domain ports.

Public API:

- :class:`ConversionPipeline` — the composition root.
- Stages: :class:`ExtractionStage`, :class:`MetadataStage`,
  :class:`ImageEnrichmentStage`, :class:`TableProfilingStage`,
  :class:`RenderingStage`. Exposed for callers that want to reuse
  individual stages.
- :class:`PipelineState` — the immutable value passed between stages.
- :class:`SystemClock`, :class:`NullScorer` — trivial default
  implementations of domain ports.
- :func:`load_document` — convenience loader from filesystem paths.
- :func:`convert_batch`, :func:`discover_batch`, :class:`BatchItem`,
  :class:`BatchResult`, :class:`BatchSuccess`, :class:`BatchFailure` —
  batch orchestration.

May depend on :mod:`cyberdocextractor.domain` but must **not** import
any infrastructure adapter or the CLI directly.
"""

from __future__ import annotations

from .batch import (
    BatchFailure,
    BatchItem,
    BatchResult,
    BatchSuccess,
    convert_batch,
    discover_batch,
)
from .clock import SystemClock
from .image_context import ImageContextTracker
from .loader import UnknownExtensionError, load_document
from .pipeline import ConversionPipeline
from .scoring import NullScorer
from .stages import (
    ExtractionStage,
    ImageEnrichmentStage,
    MetadataStage,
    RenderingStage,
    TableProfilingStage,
)
from .state import PipelineState

__all__ = [
    "BatchFailure",
    "BatchItem",
    "BatchResult",
    "BatchSuccess",
    "ConversionPipeline",
    "ExtractionStage",
    "ImageContextTracker",
    "ImageEnrichmentStage",
    "MetadataStage",
    "NullScorer",
    "PipelineState",
    "RenderingStage",
    "SystemClock",
    "TableProfilingStage",
    "UnknownExtensionError",
    "convert_batch",
    "discover_batch",
    "load_document",
]
