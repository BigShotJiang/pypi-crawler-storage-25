"""Stand-in :class:`QualityScorer` implementations for the app layer.

Production scorers live in :mod:`cyberdocextractor.infra` (Phase 4).
The :class:`NullScorer` here exists so that callers who don't care
about quality scoring — CLI quickstart, tests, one-off conversions —
still get a valid :class:`~cyberdocextractor.domain.Markdown`.
"""

from __future__ import annotations

from dataclasses import dataclass

from ..domain import Document, NormalizedDoc, ValidationError

__all__ = ["NullScorer"]


@dataclass(frozen=True, slots=True)
class NullScorer:
    """A scorer that returns a fixed value (default ``1.0``).

    Useful as a default so pipelines don't require an explicit scorer;
    swap in a real implementation (e.g. the infra-layer heuristics
    scorer) when you need meaningful numbers.
    """

    score_value: float = 1.0

    def __post_init__(self) -> None:
        if not 0.0 <= self.score_value <= 1.0:
            raise ValidationError(
                f"NullScorer.score_value must be in [0.0, 1.0], got {self.score_value!r}"
            )

    def score(
        self,
        *,
        normalized_doc: NormalizedDoc,
        markdown: str,
        original: Document | None = None,
    ) -> float:
        """Return :attr:`score_value`, ignoring all inputs."""
        _ = (normalized_doc, markdown, original)
        return self.score_value
