"""Default implementation of the :class:`Clock` port.

Lives in the app layer because the implementation is tiny and uses
nothing but the standard library. Tests that need deterministic time
pass their own implementation directly.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from datetime import UTC, datetime

__all__ = ["SystemClock"]


@dataclass(frozen=True, slots=True)
class SystemClock:
    """UTC wall-clock plus :func:`time.monotonic` seconds."""

    def now(self) -> datetime:
        """Return the current wall-clock time in UTC."""
        return datetime.now(UTC)

    def monotonic(self) -> float:
        """Return a monotonic seconds value for duration measurement."""
        return time.monotonic()
