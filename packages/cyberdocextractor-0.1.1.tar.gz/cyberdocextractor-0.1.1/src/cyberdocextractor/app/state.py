"""Frozen pipeline state passed between stages.

Every stage consumes a :class:`PipelineState` and returns a new one,
evolved via :func:`dataclasses.replace`. This keeps stages
compositional and trivially testable.
"""

from __future__ import annotations

import dataclasses
from dataclasses import dataclass
from typing import Any, Self

from ..domain import Document, NormalizedDoc

__all__ = ["PipelineState"]


@dataclass(frozen=True, slots=True)
class PipelineState:
    """Immutable snapshot of a conversion in progress.

    Attributes:
        document: The document being converted.
        template_name: Name of the template the renderer should use.
        allow_fallback: Whether the extraction stage may try the next
            candidate if the preferred one fails.
        normalized_doc: Populated once extraction succeeds.
        markdown_text: Populated by the rendering stage.
        quality_score: Populated by the rendering stage.
        chosen_extractor: The extractor whose output was accepted.
        attempted: All extractors tried so far, in order.
        extraction_duration_seconds: Wall time spent in extraction.
        rendering_duration_seconds: Wall time spent in rendering.
        images_described: Number of image blocks enriched by the LLM.
        extra_metadata: Miscellaneous metadata collected by stages
            (e.g. metadata-probe results).
    """

    document: Document
    template_name: str
    allow_fallback: bool = True
    normalized_doc: NormalizedDoc | None = None
    markdown_text: str | None = None
    quality_score: float | None = None
    chosen_extractor: str | None = None
    attempted: tuple[str, ...] = ()
    extraction_duration_seconds: float = 0.0
    rendering_duration_seconds: float = 0.0
    images_described: int = 0
    extra_metadata: tuple[tuple[str, Any], ...] = ()

    def evolve(self, **changes: Any) -> Self:
        """Return a copy with the given fields overridden.

        Args:
            **changes: Keyword arguments naming fields to replace.
        """
        return dataclasses.replace(self, **changes)
