"""Load :class:`Document` instances from filesystem paths.

Kept in the app layer because it's pure stdlib I/O and needs to be
callable both by the CLI and by library users who prefer to pass
paths rather than raw bytes.
"""

from __future__ import annotations

from collections.abc import Mapping
from pathlib import Path
from typing import Any

from ..domain import (
    Document,
    PrecisionLevel,
    extension_to_mime,
)

__all__ = ["UnknownExtensionError", "load_document"]


class UnknownExtensionError(ValueError):
    """Raised when a path's extension cannot be mapped to a known MIME type."""

    def __init__(self, extension: str) -> None:
        super().__init__(
            f"Cannot infer MIME type from extension {extension!r}. "
            f"Pass `mime=` explicitly or use a supported extension."
        )
        self.extension = extension


def load_document(
    path: Path,
    *,
    mime: str | None = None,
    precision: PrecisionLevel = PrecisionLevel.BALANCED,
    metadata: Mapping[str, Any] | None = None,
) -> Document:
    """Read ``path`` from disk and build a validated :class:`Document`.

    Args:
        path: Filesystem path to the source document.
        mime: Explicit MIME type; when ``None``, the extension is used.
        precision: Desired extraction precision.
        metadata: Optional caller-supplied hints.

    Returns:
        A freshly-validated :class:`Document`.

    Raises:
        FileNotFoundError: If ``path`` does not exist.
        UnknownExtensionError: If ``mime`` is ``None`` and the extension
            cannot be resolved.
        ValidationError: If the resulting :class:`Document` fails
            validation (empty content, zero-size file, ...).
    """
    if not path.exists():
        raise FileNotFoundError(f"No such file: {path}")
    if not path.is_file():
        raise IsADirectoryError(f"Not a regular file: {path}")

    content = path.read_bytes()

    if mime is None:
        inferred = extension_to_mime(path.suffix)
        if inferred is None:
            raise UnknownExtensionError(path.suffix)
        mime = inferred.value

    return Document(
        content=content,
        mime=mime,
        size_bytes=len(content),
        precision=precision,
        filename=path.name,
        metadata=dict(metadata) if metadata else {},
    )
