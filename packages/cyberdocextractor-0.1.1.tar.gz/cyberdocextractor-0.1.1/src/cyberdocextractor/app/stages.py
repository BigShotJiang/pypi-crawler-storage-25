"""Pipeline stages.

Every stage is a small dataclass with a single :meth:`run` method
``(PipelineState) -> PipelineState``. They are composed by
:class:`ConversionPipeline` in a fixed order:

    extraction → metadata → image enrichment → table profiling → rendering

Each stage is defensive about optional dependencies:

- :class:`ExtractionStage` and :class:`RenderingStage` are required and
  raise on failure (these *must* succeed for the pipeline to produce a
  result).
- :class:`MetadataStage`, :class:`ImageEnrichmentStage`, and
  :class:`TableProfilingStage` degrade gracefully — an individual probe
  / describer / profiler that raises is logged and skipped, never
  allowed to fail an otherwise-successful conversion.
"""

from __future__ import annotations

import dataclasses
import logging
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Any

from ..domain import (
    Block,
    BlockType,
    Clock,
    ConversionFailedError,
    Document,
    ImageDescriber,
    MetadataProbe,
    NormalizedDoc,
    QualityScorer,
    RenderingError,
    SelectionPolicy,
    TableProfiler,
    TemplateContext,
    TemplateRenderer,
    UnsupportedFormatError,
)
from .image_context import ImageContextTracker
from .state import PipelineState

__all__ = [
    "ExtractionStage",
    "ImageEnrichmentStage",
    "MetadataStage",
    "RenderingStage",
    "TableProfilingStage",
]

_log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Extraction
# ---------------------------------------------------------------------------


@dataclass(slots=True)
class ExtractionStage:
    """Run the policy-selected extractor chain with optional fallback.

    On success, populates :attr:`PipelineState.normalized_doc`,
    :attr:`chosen_extractor`, :attr:`attempted`, and
    :attr:`extraction_duration_seconds`.
    """

    policy: SelectionPolicy
    clock: Clock

    def run(self, state: PipelineState) -> PipelineState:
        """Execute the extraction stage.

        Raises:
            UnsupportedFormatError: If no extractor supports the MIME type.
            ConversionFailedError: If every attempted extractor failed.
        """
        document = state.document
        candidates = self.policy.choose(
            mime=document.mime,
            size_bytes=document.size_bytes,
            has_tables=bool(document.metadata.get("has_tables", False)),
            precision=document.precision,
        )
        if not candidates:
            raise UnsupportedFormatError(document.mime)

        attempted: list[str] = []
        last_error: str | None = None
        for extractor in candidates:
            attempted.append(extractor.name)
            start = self.clock.monotonic()
            outcome = extractor.extract(document)
            duration = self.clock.monotonic() - start

            if outcome.success and outcome.normalized_doc is not None:
                return state.evolve(
                    normalized_doc=outcome.normalized_doc,
                    chosen_extractor=extractor.name,
                    attempted=tuple(attempted),
                    extraction_duration_seconds=duration,
                )

            last_error = outcome.error_message
            _log.info(
                "Extractor %s failed (%.3fs): %s",
                extractor.name,
                duration,
                last_error,
            )
            if not state.allow_fallback:
                break

        raise ConversionFailedError(
            f"All extractors failed. Last error: {last_error}",
            attempted_extractors=attempted,
            last_error=last_error,
        )


# ---------------------------------------------------------------------------
# Metadata
# ---------------------------------------------------------------------------


@dataclass(slots=True)
class MetadataStage:
    """Run :class:`MetadataProbe` adapters and merge their results.

    Probes that don't :meth:`supports` the document MIME type are
    skipped. A probe that raises is logged at WARNING and its result
    discarded — metadata extraction never fails a conversion.
    """

    probes: Sequence[MetadataProbe] = field(default_factory=tuple)

    def run(self, state: PipelineState) -> PipelineState:
        """Query every supporting probe and merge its output into metadata."""
        if state.normalized_doc is None or not self.probes:
            return state

        document = state.document
        gathered: dict[str, str] = {}
        for probe in self.probes:
            if not probe.supports(document.mime):
                continue
            try:
                gathered.update(probe.probe(document))
            except Exception as exc:
                _log.warning(
                    "MetadataProbe %s failed: %s",
                    type(probe).__name__,
                    exc,
                )

        if not gathered:
            return state

        ndoc = state.normalized_doc
        merged_metadata: dict[str, Any] = {**ndoc.metadata, **gathered}
        return state.evolve(
            normalized_doc=dataclasses.replace(ndoc, metadata=merged_metadata),
            extra_metadata=tuple({**dict(state.extra_metadata), **gathered}.items()),
        )


# ---------------------------------------------------------------------------
# Image enrichment
# ---------------------------------------------------------------------------


@dataclass(slots=True)
class ImageEnrichmentStage:
    """Replace :class:`BlockType.IMAGE` contents with LLM-generated descriptions.

    No-op when :attr:`describer` is ``None``. Describes up to
    :attr:`max_images` blocks per document; pass ``-1`` for unlimited.
    """

    describer: ImageDescriber | None = None
    max_images: int = 5
    context_lines: int = 100
    image_mime: str = "image/jpeg"

    def run(self, state: PipelineState) -> PipelineState:
        """Enrich up to :attr:`max_images` image blocks with descriptions."""
        if state.normalized_doc is None or self.describer is None:
            return state

        tracker = ImageContextTracker(window_lines=self.context_lines)
        describer = self.describer
        new_blocks: list[Block] = []
        described_count = 0

        for block in state.normalized_doc.blocks:
            if block.type in (BlockType.TEXT, BlockType.HEADING):
                tracker.add_text(block.content)
                new_blocks.append(block)
                continue

            if block.type is not BlockType.IMAGE:
                new_blocks.append(block)
                continue

            within_budget = self.max_images == -1 or described_count < self.max_images
            if not within_budget or block.image_data is None:
                new_blocks.append(block)
                continue

            try:
                description = describer.describe(
                    image_data=block.image_data,
                    context_text=tracker.get_context(),
                    mime_type=str(block.metadata.get("image_mime", self.image_mime)),
                )
            except Exception as exc:
                _log.warning("Image description failed: %s", exc)
                new_blocks.append(block)
                continue

            described_count += 1
            new_blocks.append(
                dataclasses.replace(
                    block,
                    content=description,
                    metadata={
                        **block.metadata,
                        "llm_described": True,
                        "description_index": described_count,
                    },
                )
            )

        return state.evolve(
            normalized_doc=state.normalized_doc.with_blocks(new_blocks),
            images_described=described_count,
        )


# ---------------------------------------------------------------------------
# Table profiling
# ---------------------------------------------------------------------------


@dataclass(slots=True)
class TableProfilingStage:
    """Run :class:`TableProfiler` adapters in sequence.

    Each profiler receives the (possibly already-enriched)
    :class:`NormalizedDoc` and returns a new one. Profilers that raise
    are logged and skipped.
    """

    profilers: Sequence[TableProfiler] = field(default_factory=tuple)

    def run(self, state: PipelineState) -> PipelineState:
        """Run every configured profiler, ignoring individual failures."""
        if state.normalized_doc is None or not self.profilers:
            return state

        ndoc: NormalizedDoc = state.normalized_doc
        for profiler in self.profilers:
            try:
                ndoc = profiler.profile(ndoc)
            except Exception as exc:
                _log.warning(
                    "TableProfiler %s failed: %s",
                    type(profiler).__name__,
                    exc,
                )

        return state.evolve(normalized_doc=ndoc)


# ---------------------------------------------------------------------------
# Rendering
# ---------------------------------------------------------------------------


@dataclass(slots=True)
class RenderingStage:
    """Render the :class:`NormalizedDoc` to Markdown via the renderer port."""

    renderer: TemplateRenderer
    clock: Clock
    scorer: QualityScorer | None = None

    def run(self, state: PipelineState) -> PipelineState:
        """Render ``state.normalized_doc`` into Markdown and compute a score.

        Raises:
            RenderingError: If the renderer fails.
            RuntimeError: If invoked before extraction succeeded.
        """
        ndoc = state.normalized_doc
        if ndoc is None:
            raise RuntimeError("RenderingStage invoked before extraction produced a NormalizedDoc")

        document = state.document
        extra_metadata = _build_extra_template_metadata(
            document, state.chosen_extractor, state.extra_metadata
        )
        context = TemplateContext.from_normalized_doc(
            ndoc,
            original=document,
            extra_metadata=extra_metadata,
        )

        start = self.clock.monotonic()
        try:
            rendered = self.renderer.render(state.template_name, context.as_mapping())
        except RenderingError:
            raise
        except Exception as exc:
            raise RenderingError(
                f"Template rendering failed: {exc}",
                template_name=state.template_name,
            ) from exc
        duration = self.clock.monotonic() - start

        score = 1.0
        if self.scorer is not None:
            score = self.scorer.score(normalized_doc=ndoc, markdown=rendered, original=document)

        return state.evolve(
            markdown_text=rendered,
            quality_score=score,
            rendering_duration_seconds=duration,
        )


def _build_extra_template_metadata(
    document: Document,
    chosen_extractor: str | None,
    extra_state: tuple[tuple[str, Any], ...],
) -> dict[str, Any]:
    metadata: dict[str, Any] = {
        "precision_level": document.precision.value,
        "precision_label": document.precision.label,
        "source_mime": document.mime,
    }
    if chosen_extractor:
        metadata["extractor"] = chosen_extractor
    if extra_state:
        metadata.update(dict(extra_state))
    return metadata
