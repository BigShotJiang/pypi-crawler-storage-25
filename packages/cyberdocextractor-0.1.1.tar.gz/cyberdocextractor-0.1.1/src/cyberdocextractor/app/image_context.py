"""Sliding-window text tracker used by :class:`ImageEnrichmentStage`.

Keeps the last *N* lines of surrounding prose so a multimodal LLM can
produce on-topic image descriptions. Pure app logic, no I/O.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field

from ..domain import ValidationError

__all__ = ["ImageContextTracker"]


@dataclass(slots=True)
class ImageContextTracker:
    """Maintains a sliding window of the most recent text lines.

    Attributes:
        window_lines: Maximum number of lines to keep. Must be positive.
    """

    window_lines: int = 100
    _lines: deque[str] = field(default_factory=deque, init=False, repr=False)

    def __post_init__(self) -> None:
        if self.window_lines <= 0:
            raise ValidationError(f"window_lines must be positive, got {self.window_lines!r}")
        self._lines = deque(maxlen=self.window_lines)

    def add_text(self, text: str) -> None:
        """Feed a block of text; internal deque keeps the last ``window_lines``."""
        if not text:
            return
        for line in text.splitlines():
            self._lines.append(line)

    def get_context(self) -> str:
        """Return the tracked lines joined by newlines."""
        return "\n".join(self._lines)

    def __len__(self) -> int:
        """Return the number of tracked lines."""
        return len(self._lines)
