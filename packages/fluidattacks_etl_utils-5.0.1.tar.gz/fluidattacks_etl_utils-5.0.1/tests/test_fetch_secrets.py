import io
import tarfile
from pathlib import Path

import pytest
from fa_purity import (
    Cmd,
    Unsafe,
)

from fluidattacks_etl_utils.secrets import _git


def _fake_archive(path: str, data: bytes) -> Cmd[io.BytesIO]:
    def _action() -> io.BytesIO:
        tar_bytes = io.BytesIO()

        with tarfile.open(fileobj=tar_bytes, mode="w") as tar:
            ti = tarfile.TarInfo(name=path)
            ti.size = len(data)
            tar.addfile(ti, io.BytesIO(data))

        return tar_bytes

    return Cmd.wrap_impure(_action)


def test_file_extract() -> None:
    def _check(path: Path) -> None:
        try:
            assert path.exists()
            assert path.suffix == ".yaml"
            assert path.read_bytes() == data
        finally:
            path.unlink()

    file = "my_file.yaml"
    data = b"foo: bar\n"
    result = _fake_archive(file, data).bind(lambda b: _git._extract(b, file))  # noqa: SLF001

    cmd: Cmd[None] = result.map(lambda r: r.map(_check).alt(Unsafe.raise_exception).to_union())
    with pytest.raises(SystemExit):
        cmd.compute()
