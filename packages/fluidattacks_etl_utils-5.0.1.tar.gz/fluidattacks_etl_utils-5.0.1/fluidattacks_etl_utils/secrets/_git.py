import tarfile
import tempfile
from dataclasses import (
    dataclass,
)
from io import BytesIO
from pathlib import (
    Path,
)

import git
from fa_purity import (
    Cmd,
    CmdTransform,
    Result,
    ResultE,
)

from fluidattacks_etl_utils.smash import merge_coproduct


@dataclass(frozen=True, kw_only=True)
class RepoFile:
    repo_ssh_url: str
    ref: str
    path: str


def _fetch_git_tar(file: RepoFile) -> Cmd[ResultE[BytesIO]]:
    def _action() -> ResultE[BytesIO]:
        try:
            tar_bytes = BytesIO()
            git_cmd = git.cmd.Git()
            git_cmd.archive(
                "--remote=" + file.repo_ssh_url,
                "--format=tar",
                file.ref,
                file.path,
                output_stream=tar_bytes,
            )
            return Result.success(tar_bytes)
        except Exception as error:  # noqa: BLE001
            # catching all exceptions is intentional
            return Result.failure(error)

    return Cmd.wrap_impure(_action)


def _extract(tar_bytes: BytesIO, target_file: str) -> Cmd[ResultE[Path]]:
    def _action() -> ResultE[Path]:
        try:
            tar_bytes.seek(0)

            with tarfile.open(fileobj=tar_bytes) as tar:
                member = tar.extractfile(target_file)

                if member is None:
                    return Result.failure(FileNotFoundError(target_file))

                secret_data = member.read()

            with tempfile.NamedTemporaryFile(delete=False, suffix=".yaml") as file:
                file.write(secret_data)
                return Result.success(Path(file.name))
        except Exception as error:  # noqa: BLE001
            # catching all exceptions is intentional (network/auth/archive failures)
            return Result.failure(error)

    return Cmd.wrap_impure(_action)


def fetch_git_file(file: RepoFile) -> Cmd[ResultE[Path]]:
    return CmdTransform.chain_cmd_result(
        _fetch_git_tar(file),
        lambda b: _extract(b, file.path),
    ).map(lambda r: r.alt(merge_coproduct))
