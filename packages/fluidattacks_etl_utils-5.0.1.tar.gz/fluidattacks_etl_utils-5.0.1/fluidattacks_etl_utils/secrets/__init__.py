from dataclasses import (
    dataclass,
)
from pathlib import (
    Path,
)

from fa_purity import (
    Cmd,
    PureIterFactory,
    ResultE,
    ResultTransform,
)
from fa_purity.json import (
    JsonObj,
    JsonPrimitiveUnfolder,
    JsonUnfolder,
    Unfolder,
)

from fluidattacks_etl_utils.secrets._git import RepoFile, fetch_git_file

from ._core import (
    GenericSecret,
    SecretsManager,
    get_secrets,
)


def _extract_secret(secrets: JsonObj, key: str) -> ResultE[GenericSecret]:
    return JsonUnfolder.require(
        secrets,
        key,
        lambda v: Unfolder.to_primitive(v).bind(JsonPrimitiveUnfolder.to_str).map(GenericSecret),
    )


def _standard_implementation(secrets: Path) -> SecretsManager:
    return SecretsManager(
        get_secret=lambda k: get_secrets(secrets).map(
            lambda r: r.bind(
                lambda j: _extract_secret(j, k),
            ),
        ),
        get_secrets=lambda i: get_secrets(secrets).map(
            lambda r: r.bind(
                lambda j: ResultTransform.all_ok(
                    PureIterFactory.from_list(i).map(lambda k: _extract_secret(j, k)).to_list(),
                ),
            ),
        ),
    )


@dataclass(frozen=True)
class SecretsManagerFactory:
    @staticmethod
    def observes() -> Cmd[ResultE[SecretsManager]]:
        file = RepoFile(
            repo_ssh_url="git@gitlab.com:fluidattacks/universe.git",
            ref="trunk",
            path="observes/secrets/prod.yaml",
        )
        return fetch_git_file(file).map(lambda r: r.map(_standard_implementation))


__all__ = [
    "GenericSecret",
    "SecretsManager",
]
