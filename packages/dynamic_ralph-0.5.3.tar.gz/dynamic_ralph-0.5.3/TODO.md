
pyrefly or ty - for typechecking

replace `_cfg(...)` with some fixture, maybe we need several different fixtures for 
