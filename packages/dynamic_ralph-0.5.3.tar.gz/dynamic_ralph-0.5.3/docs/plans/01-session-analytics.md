---
title: Session analytics — mine ~/.claude/projects/*.jsonl
date: 2026-04-26
covers_ideas:
  - "Tool that finds and suggests particular work"
  - "Review of recent sessions and commits"
  - "Tools to write from sessions: retries, bad commands, long common steps"
  - "Slow start analysis"
  - "Previous sessions: what user said, $ spent, turns, duration"
---

# Session analytics

Five of the nine ideas in the brain-dump want the same thing: a structured view
of past Claude Code sessions. Build the substrate once, run several reports off
of it.

## What we already have to mine

- **Per-project session JSONLs**: `~/.claude/projects/<slug>/<sessionId>.jsonl`
  — one event per line: user msgs, attachments, tool uses, results, turn meta.
  Field shape (verified 2026-04-26): `type`, `role`, `message.content`,
  `uuid`, `parentUuid`, `timestamp`, `sessionId`, `gitBranch`, `cwd`,
  `version`, `permissionMode`. Tool calls appear as nested `content` blocks
  with `tool_use` / `tool_result` types and an `is_error` flag.
- **Telemetry**: `~/.claude/telemetry/*.json` — `tengu_config_cache_stats`
  events with `cache_hits`, `cache_misses`, model id, session id. Also
  `1p_failed_events.*.json` — failed retries we can mine for "bad command"
  patterns.
- **Sessions registry**: `~/.claude/sessions/*.json` — pid, sessionId, cwd,
  startedAt, status, version. Enough to match a session to a working tree.
- **Git history**: `git log` for the same time windows, joinable on `cwd` +
  `gitBranch` from JSONL events.

## Don't reinvent — borrow first

- **[ccusage](https://github.com/ryoppippi/ccusage)** — Node CLI, ~4.8k stars,
  the de facto JSONL cost analyzer. `npx ccusage daily | session | blocks`.
  Has a JSON output mode; we can shell out for cost rollups instead of
  re-implementing pricing tables (which drift).
- **[claude-code-log](https://github.com/daaain/claude-code-log)** — Python,
  JSONL → readable HTML. Useful for human review, less for analysis.
- **[claude-view](https://recca0120.github.io/en/2026/04/07/claude-view-mission-control/)**,
  **[clog](https://github.com/HillviewCap/clog)** — dashboards; reference only.

Strategy: lean on `ccusage` for cost/turn/duration aggregates; build our own
thin Python layer for *behavioral* analysis (retries, bad commands, slow
starts, work suggestions) — that's where ccusage doesn't help.

## Architecture sketch

```
multi_agent/
  analytics/                       # new package
    __init__.py
    parse.py        # event = dataclass; iter_events(jsonl_path) -> Iterator
    schema.py       # ToolUse, ToolResult, UserTurn, AssistantTurn typed views
    sessions.py    # group events into Sessions, Turns
    reports/
      cost.py       # wraps `ccusage --json`, joins to local sessions
      retries.py    # detect tool_result is_error → repeated tool_use
      hotcommands.py # most-used Bash invocations, Edit failures
      startup.py    # time-to-first-tool, what was Read/Grep'd in first N turns
      sluggish.py   # tool calls > p95 wall time
      asks.py       # cluster user messages by topic (rule-based first)
      worklist.py   # cross-session: TODO comments mentioned, abandoned threads
    cli.py          # entry: `uv run python -m multi_agent.analytics ...`
bin/
  analyze_sessions.py  # thin wrapper, prints reports
```

Use existing libs:

- `polars` (fast lazy frames, already common in dynamic_ralph adjacent stack
  if not, `pandas` is fine) for cross-session aggregates.
- `rich` / `textual` for output (`textual` per CLAUDE.md memory if we go TUI).
- `duckdb` for ad-hoc SQL over JSONL — unbeatable iteration speed; can
  `read_json_auto('~/.claude/projects/**/*.jsonl')` directly. Strongly
  recommend P0 starts here.

## Reports we want — concrete questions each answers

### 1. "What work needs my attention?" (idea 1)

Cross-session signal aggregation. Heuristics:

- User messages containing `"come back"`, `"later"`, `"TODO"`, `"don't forget"`
  + the assistant's reply (capture promise).
- Sessions that ended with `tool_result.is_error` in the last N events
  (likely abandoned mid-failure).
- Branches with uncommitted changes older than X days, surfaced from `git
  status` of dirs in `cwd` field.
- Files Read/Edited frequently but not committed (Claude touched them, you
  didn't ship).

Output: ranked markdown checklist, one item per signal, with session+timestamp
links.

### 2. Recent session/commit review (idea 2)

A "what happened in the last 7 days" digest:

- Sessions, branches, commits, tokens, $.
- Commits with assistant authorship vs human.
- Top files edited; top tools used.
- Session-to-commit correlation: did this 90-min session produce a commit?

Pulls from JSONL + `git log --since="7 days ago" --numstat --format=...`.

### 3. Tool ideas from retries / bad commands / long steps (idea 4)

The richest seam. For each session:

- **Retry chains**: same tool name + similar args within K turns, with at
  least one `is_error: true`. Output: per-tool error rates, top failing
  invocations. → suggests wrappers, fixers, or hooks to block.
- **Bash command frequency × failure**: `cmd_freq * (1 + error_rate)`.
  High-frequency successful commands → candidates for slash commands or
  `bin/` scripts. High failure ones → candidates for wrappers that fix the
  invocation (e.g. always add `uv run`).
- **Long pipelines**: tool sequences appearing in ≥3 sessions ≥4 calls long.
  → candidates for a single composite skill / script.

Concrete artifact: `docs/plans/derived/tool-suggestions-YYYY-MM-DD.md` — a
list of "if you wrote X, it would replace Y invocations".

### 4. Slow-start analysis (idea 5)

For each session, measure "time from first user message to first non-Read
tool call" and "tokens consumed before first edit". Then bucket by what was
read/grep'd in that window. Look for **recurring early reads** across
sessions — those should be pre-loaded into `CLAUDE.md` or a skill. Anything
read in the first 5 turns of ≥30% of sessions is a candidate.

This is the highest-ROI single report. Often the answer is "agent re-reads
the same 4 files every session" — fixable with a 20-line CLAUDE.md edit.

### 5. Per-session ledger (idea 6)

Trivial join over what we already collect: prompt count, total turns,
duration, tokens (in/out/cache-hit/cache-miss), cost, model used, branch,
final state (committed / dirty / abandoned). Mostly delegate to ccusage; add
the "abandoned vs. committed" outcome column.

## The hard parts

- **JSONL schema is undocumented and changes.** Keep `parse.py` permissive:
  `dataclass(frozen=False, slots=True)` with optional fields, never crash on
  unknown event types. Have a single integration test reading every JSONL
  in `~/.claude/projects/-home-kpi-devel-github-dynamic-ralph/` and asserting
  no parse errors.
- **Privacy.** These logs include user prompts and any data the agent saw.
  Reports must run locally; never upload. Add a top-level redaction pass for
  anything matching `[A-Za-z0-9]{32,}` (token-shaped strings) in any free
  text we surface.
- **Retry detection is fuzzy.** "Same tool, similar args" needs a notion of
  "similar". Start with exact-match on `(tool_name, hash(args))` and walk
  back if it under-fires.

## P0 / P1 / P2

### P0 — disposable, this afternoon

- `scripts/duckdb_session.sh`: one-liner that opens a DuckDB shell with
  `~/.claude/projects/**/*.jsonl` mounted as a view. Iterate report ideas
  in SQL; throw it away if a query proves uninteresting.
- `scripts/slow_start.py` (≤80 LOC): scan one project's JSONLs, emit a
  histogram of files Read in the first 5 events per session.
- Run `npx ccusage session > /tmp/cost.json` and eyeball it.

**Stop here for one week.** Do real work informed by the SQL queries before
investing in code.

### P1 — promote what proved useful

- `multi_agent/analytics/` package as sketched above.
- `bin/analyze_sessions.py weekly` produces `docs/reports/weekly-YYYY-MM-DD.md`
  (commit-friendly, diffable).
- One CLI: `uv run python -m multi_agent.analytics <report>`.
- Tests: parse-doesn't-crash, single golden small JSONL fixture.

### P2 — polish

- Wire into `dynamic_ralph` itself: at orchestrator start, run `slow_start`
  against the previous 30 days and inject "files commonly read in first 5
  turns" into the agent's initial context. Closes the loop on idea 5.
- Eval the work-suggestion ranker: did suggested items get acted on?
  (See `03-bad-to-good-harness.md` — same eval substrate.)
- Optionally a Textual TUI dashboard on top, but only if reading markdown
  reports proves insufficient.

## Sources

- [ccusage — CLI for Claude Code JSONL usage](https://github.com/ryoppippi/ccusage)
- [claude-code-log — JSONL → HTML](https://github.com/daaain/claude-code-log)
- [Shipyard: track Claude Code usage + analytics](https://shipyard.build/blog/claude-code-track-usage/)
- [phuryn/claude-usage — local dashboard](https://github.com/phuryn/claude-usage)
- [HillviewCap/clog — web JSONL viewer](https://github.com/HillviewCap/clog)
- [claude-view — Rust dashboard](https://recca0120.github.io/en/2026/04/07/claude-view-mission-control/)
