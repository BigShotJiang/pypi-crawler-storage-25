---
title: Test optimization — ergonomics & speed
date: 2026-04-26
covers_ideas:
  - "Optimize tests: ergonomics, execution time"
---

# Test optimization

Two axes, both worth attacking, in this order:

1. **Speed** — easy to measure, easy to fix, immediate dev-loop win.
2. **Ergonomics** — needs taste; do after speed work surfaces the worst
   fixtures.

Existing memory note: *Track test speed* — keep tests fast, avoid redundant
tests. This plan operationalizes that.

## Step 1: measure

Before any tuning, establish a baseline. Five minutes of work.

```bash
uv run pytest --durations=0 --durations-min=0.05 | tee /tmp/durations.txt
```

`--durations=0` shows every test; `--durations-min=0.05` filters chatter.
Read the output. Often the top 5 tests dominate.

For finer signal, install **pytest-durations** (March 2026 release —
[pypi.org/project/pytest-durations](https://pypi.org/project/pytest-durations/)).
It separates **fixture time** from **test body time** — usually fixtures are
the actual culprit and `--durations` hides this.

```bash
uv add --dev pytest-durations
uv run pytest --pytest-durations  # or whatever the activation flag is
```

Optional, when a single test is slow internally:

```bash
uv add --dev pytest-profiling
uv run pytest --profile-svg tests/test_slow_one.py
```

→ flame graph in `prof/`.

## Step 2: speed wins, ranked by ROI

### High-ROI

- **Promote fixture scope.** Per-test fixtures that build the same
  Docker/sqlite/PRD object → `scope="module"` or `"session"`. Profile first;
  only promote what dominates.
- **Avoid Docker in unit tests.** Anything touching `multi_agent/compose.py`
  or `multi_agent/docker.py` should be tagged and excluded from the default
  run. Use a marker like `@pytest.mark.docker` and run those in CI only.
- **Run in parallel** with [pytest-xdist](https://pypi.org/project/pytest-xdist/):
  `uv run pytest -n auto`. The `-n auto` flag uses one worker per CPU core.
  Caveat: requires test isolation; flaky tests will surface. That's a feature.
- **Cut the import surface.** `pytest --collect-only` — if collection takes
  >1s, an import is expensive. Lazy-import heavy modules inside fixtures.

### Medium-ROI

- **Replace `_cfg(...)` with named fixtures.** TODO.md already flags this.
  Likely several variants needed (minimal / docker-mode / workflow-mode);
  define them once in `conftest.py` with `pytest.fixture(params=...)` only
  if the matrix is genuinely needed.
- **Snapshot/golden tests for orchestrator output.** Faster than asserting
  field-by-field; use `syrupy` or stdlib assertions on stable JSON. Hand-edit
  the snapshot when intent changes.
- **Stop re-creating tmpdirs.** `tmp_path_factory` (session scope) for shared
  read-only fixtures.

### Low-ROI but cheap

- **Order randomization** — [pytest-randomly](https://pypi.org/project/pytest-randomly/)
  surfaces order-dependent tests early. Doesn't speed anything up but stops
  future surprises when xdist parallelism reshuffles things.
- **`--lf` / `--ff`** in your dev loop: rerun last-failed first. Stdlib.
- **Skip slow tests by default.** `pytest -m "not slow"` plus
  `@pytest.mark.slow` on the offenders.

## Step 3: ergonomics

After the speed pass, the *shape* of the fixture mess will be obvious. Then:

### Negative list — what makes a fixture annoying

- Silent dependencies (fixture A requires fixture B which sets an env var).
  Fix: make dependencies explicit in the signature.
- Fixtures that return tuples. Fix: return a small dataclass.
- Fixtures that mutate global state without teardown.
- "God-object" fixtures (`make_everything()` returning 8 things). Split.
- Fixtures that do I/O when not all tests need it. Split into pure +
  effectful variants.

### Positive list — the LaunchConfig pattern

`tests/test_backend.py` and the recent `LaunchConfig` parameter object move
(commit `aafe41e`) is the right direction: **value objects + builders**.

```python
# conftest.py
@pytest.fixture
def launch_config_factory():
    def make(**overrides) -> LaunchConfig:
        defaults = LaunchConfig(...)
        return replace(defaults, **overrides)
    return make
```

Tests get one verbose call: `cfg = launch_config_factory(image="alt:tag")`.
No more `_cfg(image="alt:tag", workdir=None, env={}, ...)` with 7 positional
defaults to remember.

Apply same pattern to: PRD fixtures, workflow step fixtures, mock backends.

### One-time cleanup commit shape

After running the speed pass, group changes into:

1. *infra: split unit and docker test markers*
2. *tests: introduce LaunchConfig factory fixture* (already in flight)
3. *tests: scope-promote N session fixtures*
4. *tests: remove redundant tests* (catalog with `pytest --collect-only`)

Don't combine these. Each is independently revertable.

## Suite-level invariants worth enforcing

- Suite under 30s on developer laptop in `-n auto` mode (target).
- No test depends on prior-test side effects (pytest-randomly enforces).
- No test takes >1s without a `@pytest.mark.slow` marker.
- Collection time under 0.5s.

These belong in `pyproject.toml` as comments + a CI gate that fails when the
total runtime regresses by more than X%.

## P0 / P1 / P2

### P0 — one sitting

- Run `pytest --durations=0`; copy the top 10 into TODO.md with a one-liner
  on the suspected fix.
- Install `pytest-xdist`; try `-n auto`; record any flakes.
- Install `pytest-randomly`; ditto.

### P1

- Implement TODO's `_cfg` → factory fixture migration.
- Apply the high-ROI list to the top 10 slow tests.
- Add `slow` and `docker` markers; configure default exclusion in
  `pyproject.toml`.

### P2

- CI gate on suite duration.
- pytest-durations report archived weekly into `docs/reports/test-speed-*.md`
  — same archive shape as `01-session-analytics.md` reports, so we can see
  drift.

## Sources

- [13 Proven Ways To Improve Test Runtime With Pytest (pytest-with-eric)](https://pytest-with-eric.com/pytest-advanced/pytest-improve-runtime/)
- [pytest-durations — fixture vs test timing](https://pypi.org/project/pytest-durations/)
- [zupo/awesome-pytest-speedup](https://github.com/zupo/awesome-pytest-speedup)
- [Niklas Meinzer — Profiling and improving the runtime of a large pytest suite](https://www.niklas-meinzer.de/post/2019-07_pytest-performance/)
- [BuildPulse — How to speed up pytest](https://buildpulse.io/blog/how-to-speed-up-pytest)
- [pytest docs — Basic patterns and examples](https://docs.pytest.org/en/stable/example/simple.html)
