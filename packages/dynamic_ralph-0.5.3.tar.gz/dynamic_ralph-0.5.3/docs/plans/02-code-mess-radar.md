---
title: Code mess radar — where to look first
date: 2026-04-26
covers_ideas:
  - "What code I need to check, where is mess"
---

# Code mess radar

Goal: one command that says "look at these N files first" — the highest-yield
review targets. Not another linter; this is a *prioritizer* over what linters
already say, weighted by churn and complexity.

## The classic insight (still the best)

**Hotspots = high churn × high complexity.** Code-Maat / CodeScene popularized
this; Adam Tornhill's argument is that LOC and cyclomatic complexity alone are
weak signals — what predicts defects is "complex code that *also* changes
often." Stable complex code (e.g. a parser) is fine; constantly-touched
complex code is where bugs live.

We don't need CodeScene. The math is one SQL-style join.

## Inputs we already have

- `git log --numstat --since=...` — commit churn per file.
- `radon cc -j .` or `lizard -X` — cyclomatic complexity per function/file
  (both Python-friendly; `lizard` is multi-language and fast).
- `ruff check --statistics` — current lint debt density.
- `pyrefly` (already in stack) — type errors per file.
- Test coverage from `pytest --cov` (if/when wired).

## Off-the-shelf tools surveyed

- **[smontanari/code-forensics](https://github.com/smontanari/code-forensics)**
  — Node/CLI; computes hotspots, knowledge maps, churn-vs-complexity scatter.
  Heavyweight (D3 dashboards) for our small repo.
- **[flacle/truegitcodechurn](https://github.com/flacle/truegitcodechurn)**
  — Python script for "true" churn (excludes immediate revert noise). Worth
  vendoring if churn signal looks noisy.
- **[CodeScene](https://codescene.com/)** — commercial; the gold standard but
  overkill for one-developer repo. Mention only as the reference design.
- **`lizard`**, **`radon`** — local complexity scanners. Ship-it-today.

## The radar — one script

```python
# bin/mess_radar.py (sketch)
# 1. Run `git log --numstat --since=$SINCE` → {file: (commits, additions, deletions)}
# 2. Run `lizard -X .` → {file: avg_ccn, max_ccn, function_count, nloc}
# 3. Run `ruff check --output-format=json .` → {file: lint_count}
# 4. Optional: `pyrefly check --json` → {file: type_error_count}
# 5. Score each file:
#       hotspot = churn_rank * complexity_rank          # Tornhill
#       debt    = lint_count + type_error_count
#       attention = hotspot + 0.5 * debt
# 6. Print top N with breakdown columns.
```

Outputs:

```
file                                      churn  ccn  lint  type  score
multi_agent/workflow/executor.py             14   28    4     1   ★★★★
multi_agent/backend.py                       11   19    1     0   ★★★
bin/run_dynamic_ralph.py                      9   22    0     2   ★★★
...
```

Add a `--explain <file>` mode that prints:

- last 10 commits touching it (subject + author)
- worst function by complexity (with line range)
- ruff/pyrefly findings with locations
- TODO/FIXME comments

That's *the* artifact for "where do I look first." Keeps you off the
SonarQube-as-a-service hamster wheel.

## What this is *not*

- Not a linter — leans on ruff/pyrefly for actual rules.
- Not a coverage tool — orthogonal; can be added as a column later.
- Not a security scanner — `/security-review` skill already covers that.
- Not a "fix it for me" — surface signal, human decides scope.

## Cross-link to session analytics

`01-session-analytics.md` already finds files Claude touches without commits,
and files that produce repeated edit failures. Wire those columns in:

- `claude_touches_no_commit` per file — agent activity without throughput.
- `agent_edit_failures` per file — places where Edit consistently misses.

These are soft "the agent struggles here" signals. Combined with churn ×
complexity, they triangulate the genuinely hairy code.

## P0 / P1 / P2

### P0 — afternoon

`bin/mess_radar.py`, ~150 LOC, no tests, top-20 list to stdout. Use `subprocess`
to call `git log` and `lizard`; parse JSON. Print a markdown table.

### P1 — promote

- Move into `multi_agent/analytics/mess.py` next to session analytics.
- Add `--explain <file>` mode.
- `--since` param defaulting to 90 days.
- One pytest covering the scoring math (mock subprocess outputs).

### P2 — wire into the loop

- Run on every PR / commit, write `docs/reports/mess-YYYY-WW.md`.
- Surface top-3 hotspots in the orchestrator's pre-task context (closes the
  loop with `01`'s slow-start improvements).
- Optional: a `pre-commit` hook that warns if a commit lands in the top-5
  mess file without a corresponding test change.

## Sources

- [Hotspot analysis (code-forensics wiki)](https://github.com/smontanari/code-forensics/wiki/Hotspot-analysis)
- [Focus refactoring on what matters with Hotspots Analysis (Understand Legacy Code)](https://understandlegacycode.com/blog/focus-refactoring-with-hotspots-analysis/)
- [truegitcodechurn — Python "true" churn](https://github.com/flacle/truegitcodechurn)
- [10 Code Quality Metrics for Large Engineering Orgs (Qodo, 2026)](https://www.qodo.ai/blog/code-quality-metrics-2026/)
