---
title: Bad → good code with fewer reviews — eval-driven harness improvement
date: 2026-04-26
covers_ideas:
  - "What to do, to effectively transform bad code into good code with fewer reviews and prompts"
---

# Bad → good with fewer reviews

The honest answer: this is a methodology problem, not a tool. But there's a
small set of mechanisms that demonstrably reduce review iterations on coding
agents in 2026. This plan picks the ones that fit `dynamic_ralph` and turns
each into a concrete artifact.

## Diagnosis: why does review take many rounds today?

Three failure modes (Drew Breunig's taxonomy, also Anthropic's evals post):

1. **Context drift** — agent forgets a constraint mid-session.
2. **Schema misalignment** — agent's model of "what good code looks like here"
   doesn't match the project's. Symptom: keeps adding error handling we don't
   want, abstractions we don't want, comments we don't want.
3. **State degradation** — what was true 30 turns ago no longer is, but the
   agent acts like it is.

The fix for *all three* is the same shape: **convert each correction into a
mechanical rule** so the same review never has to happen twice.

## The principle (from the field reports)

Mitchell Hashimoto and Jesse Vincent both converge here: when the agent fails,
**don't rewrite the prompt — change the environment**. Add a lint rule, a
test, a hook, an `AGENTS.md` line, a skill. Every review comment is a missed
mechanism.

OpenAI's harness-engineering post pushes this further: agents *review each
other* in the loop, and human review compresses to "did the agent reviewers
sign off correctly?" — not "is this code right?"

The Meta-Harness paper shows the optimization view: a coding agent given
filesystem access to *all prior attempts and execution traces* converges
~10× faster than running blind iterations. So the corollary is: *keep the
trace*.

## Mechanisms in priority order

### 1. Failure log as a first-class artifact

Append-only `docs/reviews/journal.md` (or similar). Every time you correct the
agent, log:

```
- 2026-04-26: agent added try/except around X. We don't catch internal errors
  (CLAUDE.md §error-handling). → added a one-line ruff rule? no — added an
  AGENTS.md bullet + a session-analytics regex that flags new bare-excepts in
  diffs.
```

This file becomes the input to mechanisms 2–5. Cheaper than maintaining a
spec; richer than commit messages.

### 2. Convert journal entries into hooks

For each repeated correction, ask: can a hook *block* the bad behavior?

- Pre-edit hook that rejects diffs introducing patterns we've outlawed
  (regex over patches; cheap and effective).
- Pre-commit hook that runs `ruff` *with the project's actual rule set* —
  agent gets an immediate signal in-loop.
- Stop hook (per `harness_research.md`) that holds the agent until lint+type
  pass.

Hooks are listed in `disler/claude-code-hooks-mastery`; this is the same
plumbing.

### 3. Acceptance test as the exit gate

Today we review by reading code. Replace as much as possible with: *did this
change make a failing test pass without breaking others?*

Steps:

- For non-trivial PRDs, write the test first (red), let the agent loop until
  green. Already in `CLAUDE.md` ("red/green TDD when it does make sense").
- Add a "definition of done" block to PRD prompts that explicitly lists the
  test command and expected pass count.

### 4. Self-review before human review

OpenAI's pattern: agents call agents to review. Cheap version we can copy:

- After each step, call a fresh subagent (`Agent` tool, `subagent_type=
  general-purpose` or a new code-review agent) with **only the diff** and a
  checklist (the project's negative list: no comments, no error handling
  beyond X, no abstractions, etc.).
- If the reviewer flags issues, the implementing agent fixes; loop until
  clean or budget exhausted.
- Human only sees diffs that passed both passes.

Wire this as a workflow step type in `multi_agent/workflow/steps.py`. PRD
authors opt in via a `review: subagent` field.

### 5. Eval harness on top of session analytics

From `01-session-analytics.md` we have per-session ledgers. Add metrics:

- **pass@1**: fraction of PRDs where the first agent run shipped without
  human edits to its diff. Anthropic's evals post calls this the right
  primary metric for coding agents.
- **review-rounds-to-merge**: count of agent ↔ human turns between first
  proposal and merge.
- **bad-pattern hits**: how often the rules we encoded in mechanism 2 fired.

A weekly cron writes these into `docs/reports/eval-YYYY-WW.md`. When the
numbers stop improving, the harness needs new rules — that's the signal,
not vibes.

### 6. Fresh context for big tasks

Long sessions degrade. Two cheap interventions:

- **Plan-then-build with split context**: planning agent writes a markdown
  plan; implementation agent reads only the plan, not the planning
  conversation. The workflow engine (`workflow/scratch.py`) already supports
  this shape — push more PRDs to use it.
- **Append-only scratchpad** the agent maintains across the loop with
  decisions and dead-ends. Survives compaction. (`harness_research.md`
  already covers `PreCompact` hook to protect long iterations.)

## What *not* to do

- **Don't write a giant CLAUDE.md.** Beyond ~200 lines, hit-rate drops
  steeply (multiple 2026 writeups agree). Push detail into skills and
  AGENTS.md per directory; CLAUDE.md is for cross-cutting policy only.
- **Don't add review checklists to the prompt.** Agents skim them. Encode the
  same constraints as hooks or tests where possible.
- **Don't chase "the right model".** Mechanism beats model on this axis.

## P0 / P1 / P2

### P0 — this week, no code changes required

- Start `docs/reviews/journal.md`. Two-week trial. Just write down every
  correction. *Do not* generalize yet.
- Read entries weekly. For each that recurred: convert to a rule (CLAUDE.md
  bullet, hook, test, lint rule). One per week is enough.

### P1

- New workflow step type `subagent_review` in `multi_agent/workflow/steps.py`
  + executor support; takes a checklist file path.
- Pre-commit hook that runs full `ruff` + `pyrefly` + `pytest -x` and blocks
  agent commits on failure (the agent is allowed to see the failure and
  retry; that's the whole point).
- Wire `pass@1` and `review-rounds-to-merge` into the analytics package.

### P2

- Agent-to-agent review wired in by default for any PRD over a size
  threshold.
- Eval gate: nightly run replays last week's PRDs against current harness;
  if pass@1 regresses, alert. (One-time CronCreate routine — quota-aware
  per `harness_research.md`.)

## Sources

- [Anthropic — Demystifying Evals for AI Agents](https://www.anthropic.com/engineering/demystifying-evals-for-ai-agents)
- [OpenAI — Harness Engineering: Codex in an agent-first world](https://openai.com/index/harness-engineering/)
- [Meta-Harness: End-to-End Optimization of Model Harnesses](https://yoonholee.com/meta-harness/)
- [Martin Fowler — Harness engineering for coding agent users](https://martinfowler.com/articles/harness-engineering.html)
- [HumanLayer — Skill Issue: Harness Engineering for Coding Agents](https://www.humanlayer.dev/blog/skill-issue-harness-engineering-for-coding-agents)
- [awesome-harness-engineering](https://github.com/ai-boost/awesome-harness-engineering)
- [Hamel Husain — Evals Skills for Coding Agents](https://hamel.dev/blog/posts/evals-skills/)
