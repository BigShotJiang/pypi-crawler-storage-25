---
title: Find and track books
date: 2026-04-26
covers_ideas:
  - "Find and track books"
---

# Books tracker

Unrelated to dynamic_ralph proper — a personal-tooling sidecar. Two questions
to answer up front:

1. **Find vs. track — which dominates your need?**
   - *Find*: you hear about a book, you want to look up details (ISBN, year,
     description) and decide whether to read.
   - *Track*: you want a list of "want to read / reading / read", with notes
     and ratings.
   The two needs share data sources but the UX differs sharply.
2. **Where does the data live?**
   - Plain markdown in a git repo (most portable, most extensible).
   - SQLite (best for queries, ranks, "books I started but didn't finish").
   - Self-hosted app (Jelu, Booklogr) — most polished but operationally
     heavier.

Recommendation: **markdown + a thin Python CLI**. Books are a small dataset
(hundreds, not millions); plaintext + git history beats a server you have to
maintain. Promote to SQLite only if you cross ~500 entries or want
non-trivial queries.

## Data sources surveyed

- **[Open Library API](https://openlibrary.org/developers/api)** — free, no
  key required, REST + JSON. Lookup by ISBN, title, author. Cover images via
  `covers.openlibrary.org`. Best default. ~30M titles.
- **[Hardcover.app](https://hardcover.app/)** — modern Goodreads alternative
  with a public **GraphQL API**; requires free account+token. Ratings and
  social data better than OpenLibrary; coverage of newer titles often better
  too. Use as a secondary source / for personal ratings sync.
- **Google Books API** — works without a key for low volume; good metadata
  fallback. Quotas tighten without billing enabled.
- **ISBNDB** — paid; skip unless the free sources fail you.

Self-hosted full apps to skip unless the markdown approach proves wrong:

- **[Jelu](https://github.com/bayang/jelu)** — Kotlin/Spring; Goodreads-
  style. Good but heavy.
- **[Booklogr](https://github.com/Mozzo1000/booklogr)** — simpler self-host.
- **[wars2k/booktracker](https://github.com/wars2k/booktracker)** — Flask app.

## The minimal CLI

```
bin/book.py            # entry point
multi_agent/books/     # if it grows; fine to keep in bin/ until then
  __init__.py
  search.py            # OpenLibrary search wrappers
  store.py             # markdown read/write
data/books/            # one .md per book or a single library.md
  library.md           # the whole list, append-only top
```

CLI surface (only what's actually useful):

```
book find "the dispossessed"        # search → numbered results, pick to add
book add 9780061054884                # by ISBN
book list                              # show want/reading/read columns
book log "the dispossessed" --done --rating 5 --notes "beat the lathe of heaven"
book recommend                         # see "future enhancements" below
```

Markdown shape (one row, easy to grep):

```markdown
| Title              | Author     | ISBN       | Status  | Started    | Finished   | ★ | Notes |
|--------------------|------------|------------|---------|------------|------------|---|-------|
| The Dispossessed   | Le Guin    | 0061054884 | read    | 2026-03-04 | 2026-04-12 | 5 | …     |
| A Memory Called…   | Martine    | 1250186439 | reading | 2026-04-20 |            |   |       |
```

The CLI just reads/writes this single table. Git tracks history.

## Optional (only if it earns its keep)

- **Wishlist scraping**: pull a public Goodreads RSS or hardcover.app's
  GraphQL into the wishlist column. One-shot, no scheduling.
- **Recommend**: read the "read + rated 4★+" rows, look up their
  OpenLibrary subjects, return books that share top-3 subjects but you
  haven't read. Crude collaborative-filtering-via-tags. ~80 LOC.
- **Reading goals**: a `goal: 24/year` line; CLI does the math. Pure
  cosmetic but pleasant.

## What to skip

- Don't build a UI yet — it's a single user, single file. CLI + your editor
  is enough.
- Don't sync with Goodreads — Goodreads' API is effectively dead since 2020.
- Don't try to handle multiple editions. ISBN-13 is the key; ignore the
  edition zoo.

## P0 / P1 / P2

### P0 — afternoon

- `bin/book.py` (≤200 LOC): `find`, `add`, `list`. OpenLibrary only. Markdown
  table at `data/books/library.md`.
- Use `httpx` (already common) or `urllib`. No abstractions.

### P1

- `--done`, `--rating`, `--notes` on add/log.
- Hardcover.app GraphQL fallback when OpenLibrary lacks recent titles.
- A `book stats` view: counts by year, average rating, longest reads.

### P2

- Recommendation command (subjects-based).
- Migrate to SQLite if/when markdown becomes painful (>500 books, or you
  start wanting joins). Keep markdown as the export format.

## Sources

- [Open Library APIs](https://openlibrary.org/developers/api)
- [Top 9 Book APIs in 2026 (ISBNDB Blog)](https://isbndb.com/blog/book-api/)
- [Jelu — self-hosted book tracker](https://github.com/bayang/jelu)
- [Booklogr](https://github.com/Mozzo1000/booklogr)
- [wars2k/booktracker](https://github.com/wars2k/booktracker)
- [Building ReadTrackr — Open Library API tutorial](https://dev.to/fonyuygita/your-gateway-to-building-readtrackr-mastering-the-open-library-api-j9n)
