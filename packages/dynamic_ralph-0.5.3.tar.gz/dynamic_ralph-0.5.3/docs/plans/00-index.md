---
title: Plans index
date: 2026-04-26
---

# docs/plans/ — what each plan is for

Distilled from a brain-dump of nine ideas. Grouped into five focused plans plus
one cross-cutting research note that already exists.

## Map of ideas → plans

| Idea (verbatim) | Plan |
|---|---|
| Tool that finds and suggests particular work to address | `01-session-analytics.md` |
| Get info from review of recent sessions and commits | `01-session-analytics.md` |
| Tools to write, from reviewing previous sessions, retries, bad commands, long common steps | `01-session-analytics.md` |
| Analysis of slow points during start — prepare better context, from what was retrieved | `01-session-analytics.md` |
| Previous sessions: what user said, $ spent, turns, duration, what is asked | `01-session-analytics.md` |
| What code I need to check, where is mess | `02-code-mess-radar.md` |
| What to do, to effectively transform bad code into good code with fewer reviews and prompts | `03-bad-to-good-harness.md` |
| Optimize tests: ergonomics, execution time | `04-test-optimization.md` |
| Find and track books | `05-books-tracker.md` |

## Existing inputs to lean on

- `docs/harness_research.md` — Ralph-style frameworks, hooks, observability
  (`agents-observe`, `disler/...-hooks-mastery`).
- `docs/workflow_field_report.md` — practitioner blogs/repos, "harness over
  prompt", evals, append-only scratchpads.

The plans below cite these where relevant rather than restating them.

## Reading order

1. **`01-session-analytics.md`** — biggest leverage. Five of the nine ideas
   collapse into one tool that mines `~/.claude/projects/*.jsonl`. Everything
   else benefits from the metrics this surfaces.
2. **`03-bad-to-good-harness.md`** — methodology layer over `01`. Once you can
   measure agent failure, you can convert each failure into a rule.
3. **`02-code-mess-radar.md`** — orthogonal but cheap; mostly off-the-shelf
   pieces wired together.
4. **`04-test-optimization.md`** — local, scoped, measurable. Quick wins.
5. **`05-books-tracker.md`** — unrelated personal tool; lowest priority unless
   you specifically want to pick it up.

## Common deliverable shape

Each plan ends with a "**P0 / P1 / P2**" ladder:

- **P0** — throwaway scripts, no abstractions, ship in an afternoon.
- **P1** — promote to `bin/` or `multi_agent/`, keep a CLI surface.
- **P2** — polish: tests, eval gate, docs, optionally publish.

Don't skip P0. The session-analytics plan in particular wants disposable
scripts first, because the JSONL schema will surprise us.
