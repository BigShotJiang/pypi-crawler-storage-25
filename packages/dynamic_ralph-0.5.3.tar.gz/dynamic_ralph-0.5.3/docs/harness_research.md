# Claude Code Harnesses for Long-Running / Autonomous Workflows

Research date: 2026-04-26. All recency confirmed via `gh` against `pushedAt`.
Focus: actively maintained repos providing skills, recipes, hooks, MCP servers,
or full orchestration frameworks — with emphasis on **long-running and autonomous**
patterns relevant to `dynamic_ralph`.

## A. Ralph-style loop frameworks

- **[snarktank/ralph](https://github.com/snarktank/ralph)** — PRD-driven autonomous
  loop (Amp + Claude Code). ~17.8k stars, push 2026-02-02. Memory persists via
  three channels: git history, `progress.txt`, `prd.json`. Ships `/prd` and
  `/ralph` as installable plugin-marketplace **skills** — borrowable packaging
  idea for `dynamic_ralph`.
- **[frankbria/ralph-claude-code](https://github.com/frankbria/ralph-claude-code)** —
  Polished bash-loop Ralph. ~8.8k stars, push 2026-04-13 (very active, 566
  tests). The exit/safety machinery is gold: **dual-condition exit gate**
  (completion indicators **AND** explicit `EXIT_SIGNAL`), **circuit breaker**,
  **rate limiter**, **three-layer API-limit detection**, and
  `--resume <session_id>` (not `--continue`) to avoid session hijacking.
  Directly liftable into `workflow/executor.py`.
- **[Th0rgal/open-ralph-wiggum](https://github.com/Th0rgal/open-ralph-wiggum)** —
  Cross-agent Ralph (Claude/Codex/OpenCode/Copilot). ~1.6k, push 2026-03-27.
  Backend-agnostic CLI shape — useful for keeping `multi_agent/backend.py`
  tool-neutral.
- **[coleam00/ralph-loop-quickstart](https://github.com/coleam00/ralph-loop-quickstart)** —
  Opinionated alternative to Anthropic's official Ralph plugin. ~150 stars,
  push 2026-01-21. Worth skimming for failure modes the official version has.

## B. Full orchestration harnesses

- **[SethGammon/Citadel](https://github.com/SethGammon/Citadel)** — Four-tier
  router (`/do`), parallel agents in worktrees. ~520 stars, push 2026-04-15.
  Patterns to steal: **tiered routing** (cheapest path wins), **discovery relay
  between waves** of parallel agents, and explicit warning about Anthropic's
  **15-routine/24h quota** for `CronCreate` / `ScheduleWakeup` /
  `RemoteTrigger`.
- **[Chachamaru127/claude-code-harness](https://github.com/Chachamaru127/claude-code-harness)** —
  Plan→Work→Review cycle, Go-native hook engine. ~590 stars, push 2026-04-24.
  Two excellent patterns: **`PreCompact` hook that blocks auto-compaction
  while work is mid-flight** (prevents silent context loss in long runs) and
  opt-in **1-hour prompt-cache TTL** via `enable-1h-cache.sh`
  (CC v2.1.108+) — big win for multi-minute loops.
- **[ruvnet/ruflo](https://github.com/ruvnet/ruflo)** (formerly claude-flow) —
  Multi-agent swarm. ~33k stars, push 2026-04-11. Kitchen-sink, hard to extract
  pieces, but recursive agent-cycle docs are solid.
- **[smtg-ai/claude-squad](https://github.com/smtg-ai/claude-squad)** — TUI for
  managing N parallel agents in isolated workspaces. ~7.2k stars,
  push 2026-03-28. Per-agent isolated workspace + tmux maps 1:1 onto a
  Docker-per-agent design.

## C. Hook patterns

- **[disler/claude-code-hooks-mastery](https://github.com/disler/claude-code-hooks-mastery)** —
  Reference repo for all 12 hook events. ~3.6k stars, push 2026-03-04. Key
  autonomy bit: **Stop hook with exit code 2 forces continuation** — cleanest
  published "auto-restart on idle" recipe. Covers `stop_hook_active` to break
  the resulting infinite loop.

## D. Observability

- **[simple10/agents-observe](https://github.com/simple10/agents-observe)** —
  Real-time hook-event dashboard via MCP. ~500 stars, push 2026-04-24. Drop-in
  plugin: hooks auto-stream to a Docker MCP server, dashboard at
  `localhost:4981`. Replaces log-file-parsing for multi-container runs.
  `/observe debug|status|logs` for in-loop introspection.
- **[disler/claude-code-hooks-multi-agent-observability](https://github.com/disler/claude-code-hooks-multi-agent-observability)** —
  ~1.4k stars, push 2026-02-08. Older sibling of agents-observe; reference only.

## E. Skill / recipe collections (cherry-pick, don't adopt wholesale)

- **[hesreallyhim/awesome-claude-code](https://github.com/hesreallyhim/awesome-claude-code)** —
  ~41k stars, push 2026-04-25. Canonical curated list.
- **[ai-boost/awesome-harness-engineering](https://github.com/ai-boost/awesome-harness-engineering)** —
  ~550 stars, push 2026-04-25. Narrower scope (memory, MCP, evals,
  observability) — better signal-to-noise than the generic awesome list.
- **[wshobson/agents](https://github.com/wshobson/agents)** — ~34k stars,
  push 2026-04-18. Role-specialized agent defs — useful if swapping a single
  PRD agent for role-tagged subagents.

## What's worth stealing for `dynamic_ralph`

- **Borrow frankbria's exit & safety machinery wholesale.** Dual-condition exit
  gate, three-layer API-limit detection, `--resume <session_id>` over
  `--continue`. The executor will hit these edge cases eventually; no point
  rediscovering them.
- **Add a `PreCompact` hook to protect long iterations.** Auto-compaction
  silently truncates mid-task. Refuse compaction while a workflow step is
  mid-flight or scratch state is dirty — pairs naturally with
  `multi_agent/workflow/scratch.py`.
- **Stream hook events to a local collector instead of (or alongside) log
  files.** The `agents-observe` pattern is a cleaner replacement for
  after-the-fact log parsing once multiple containers run in parallel. Docker
  is already in the stack, so one more service is cheap.
- **Package the workflow as installable skills, like `snarktank/ralph` does.**
  Distributing `/prd`, `/ralph`, `/retro` as a marketplace plugin lets users
  adopt pieces without the whole Docker stack — low-friction distribution
  channel.

## Skipped (stale / low-signal / off-topic)

- `harrymunro/ralph-wiggum` — 1 star, abandoned.
- `revfactory/harness` — meta-skill that generates skills, off-topic.
- `steipete/claude-code-mcp` — push 2026-01, mostly "Claude inside Claude"
  pattern, not autonomy-focused.
