# Coding-Agent Workflow Field Report — April 2026

A curated, recently-verified set of practitioner sources for someone building
a Python/Docker Claude Code orchestrator. Anything older than ~6 months is
excluded unless still load-bearing. No content farms, no listicles, no vendor
marketing.

## Personal blogs / newsletters

- **[Simon Willison — claude-code tag](https://simonwillison.net/tags/claude-code/)**
  — Daily-ish link blog with detailed annotations. Active April 2026 (recent
  posts on Anthropic's pricing reversal, Claude Code transcript extraction).
  Best single feed for catching new techniques the day they appear. Caveat:
  skim-format, not deep tutorials.
- **[Armin Ronacher — lucumr.pocoo.org](https://lucumr.pocoo.org/)** — Posts
  every few weeks. Recent: *Absurd In Production* (2026-04-04), *Mario and
  Earendil* (2026-04-08), *A Language For Agents* (2026-02-09), *Pi: The
  Minimal Agent Within OpenClaw* (2026-01-31). Runs a hand-built minimal agent
  (Pi) in production — directly relevant to anyone writing their own loop
  instead of using Claude Code's harness.
- **[Mitchell Hashimoto — mitchellh.com/writing](https://mitchellh.com/writing)**
  — *[My AI Adoption Journey](https://mitchellh.com/writing/my-ai-adoption-journey)*
  (Feb 2026) is the most-cited "how I actually work" post of the quarter. The
  "harness engineering" framing (every agent mistake becomes a lint rule /
  test / `AGENTS.md` entry) maps directly onto `dynamic_ralph`.
- **[Thorsten Ball — registerspill.thorstenball.com](https://registerspill.thorstenball.com/)**
  — Weekly *Joy & Curiosity* roundup plus longer essays. Works on Amp at
  Sourcegraph, so writes from inside an agent harness team. Very high signal
  on what happens when 100% of an org switches to agents.
- **[Hamel Husain — hamel.dev](https://hamel.dev/)** —
  *[Evals Skills for Coding Agents](https://hamel.dev/blog/posts/evals-skills/)*
  (2026-03-02) and the updated
  *[LLM Evals FAQ](https://hamel.dev/blog/posts/evals-faq/)* (2026-01-15).
  Go-to source for "how do I actually measure if my agent loop got better?"
- **[Drew Breunig — dbreunig.com](https://www.dbreunig.com/)** —
  *[How Claude Code Builds a System Prompt](https://www.dbreunig.com/2026/04/04/how-claude-code-builds-a-system-prompt.html)*
  (2026-04-04),
  *[The 2nd Phase of Agentic Development](https://www.dbreunig.com/2026/04/01/the-2nd-phase-of-agentic-development.html)*
  (2026-04-01). His four-mode taxonomy (poisoning / distraction / confusion /
  clash) is now the default vocabulary; the system-prompt teardown is
  must-read for orchestrators.
- **Hrishi Olickel — [hrishi.io](https://www.hrishi.io/) +
  [@hrishioa on X](https://x.com/hrishioa)** — Famous decompile of Claude
  Code's minified source. Active in 2026 on hankweave / proof-formalization.
  Caveat: most output is on X, blog is occasional. Best for one-off engineering
  tricks (append-only `scratchpad.md`, plan-with-Gemini-build-with-Claude).
- **[Jesse Vincent — blog.fsck.com](https://blog.fsck.com/)** — Author of
  *Superpowers*. Posts roughly monthly;
  *[Superpowers v4.3.0](https://blog.fsck.com/releases/2026/02/12/superpowers-v4-3-0/)*
  (2026-02-12) is the most recent substantive release writeup. Read his
  methodology essays to understand why a skills framework beats one big
  CLAUDE.md.
- **[Sankalp — sankalp.bearblog.dev](https://sankalp.bearblog.dev/my-experience-with-claude-code-20-and-how-to-get-better-at-using-coding-agents/)**
  — *A Guide to Claude Code 2.0 and Getting Better at Using Coding Agents*
  (late 2025, still canonical and updated). Practical, no-fluff,
  working-engineer voice. ~200k reads.
- **[Addy Osmani — addyosmani.com](https://addyosmani.com/blog/ai-coding-workflow/)**
  — *My LLM Coding Workflow Going Into 2026* (Dec 2025, the canonical
  "spec → small chunks → quality gates" reference). Borderline on the
  6-month rule, but still being updated and cited weekly.
- **[Steve Yegge — steve-yegge.medium.com](https://steve-yegge.medium.com/six-new-tips-for-better-coding-with-agents-d4e9c86e42a9)**
  — *Six New Tips for Better Coding With Agents* and the *Beads* / *Gas Town*
  multi-agent framework writeups (Jan 2026). Verbose but practitioner-driven —
  directly relevant if `dynamic_ralph` ever grows past one agent.
- **[Marco Lancini — blog.marcolancini.it](https://blog.marcolancini.it/2026/blog-my-claude-code-setup/)**
  — *My Claude Code Setup (2026 Edition)* — full end-to-end walkthrough of
  one engineer's `.claude/`, hooks, and skills.

## Setup repos / dotfiles

- **[obra/superpowers](https://github.com/obra/superpowers)** — Jesse
  Vincent's skills + methodology framework. ~121k stars, accepted into
  Anthropic's plugins marketplace Jan 2026. The single most-copied
  `.claude/skills/` source.
- **[hesreallyhim/awesome-claude-code](https://github.com/hesreallyhim/awesome-claude-code)**
  — Curated index of skills, hooks, slash-commands, orchestrators, plugins.
  Updated weekly. Discovery surface, not content itself.
- **[ChrisWiles/claude-code-showcase](https://github.com/ChrisWiles/claude-code-showcase)**
  — Complete project-level `.claude/` example: hooks, skills, agents,
  commands, GHA workflows. Notable for the "skill evaluation" hook that
  auto-suggests which skill to activate based on the prompt.
- **[zircote/.claude](https://github.com/zircote/.claude)** — Personal
  dotclaude with domain-specific agents (backend / frontend / devops /
  security / data-ML), Opus 4.5 optimizations.
- **[fairchild/dotclaude](https://github.com/fairchild/dotclaude)** — Clean
  `~/.claude/` with `CLAUDE.md`, `settings.json`, `commands/`, `skills/`,
  `agents/`, `hooks/`. Good minimal reference.
- **[poshan0126/dotclaude](https://github.com/poshan0126/dotclaude)** —
  "Standard `.claude/` folder structure for everyday development" —
  opinionated, lots of comments explaining choices.
- **[elizabethfuentes12/claude-code-dotfiles](https://github.com/elizabethfuentes12/claude-code-dotfiles)**
  — Notable for the auto-sync wrapper: pulls before launching Claude,
  commits/pushes after. Pattern worth stealing for any agent-fleet config.
- **[citypaul/.dotfiles](https://github.com/citypaul/.dotfiles)** — General
  dotfiles, but the `claude/` subtree is well-organized; popular reference.
- **[lavantien/dotfiles](https://github.com/lavantien/dotfiles)** — Cross-OS
  setup with Claude Code + git hooks integrated; useful for Linux/Windows
  parity.
- **[TonyCasey/ai-dotfiles-manager](https://github.com/TonyCasey/ai-dotfiles-manager)**
  — Centralizes dotfiles across `.claude/`, `.codex/`, `.roo/`, `.kilocode/`.
  Solves the "I use four agents and don't want to copy CLAUDE.md four times"
  problem.
- **[rohitg00/awesome-claude-code-toolkit](https://github.com/rohitg00/awesome-claude-code-toolkit)**
  — 135 agents / 35 skills / 42 commands / 20 hooks / 14 MCP configs. Buffet,
  not curated kit, but useful for copying specific patterns.

## Longform writeups & talks (last ~6 months)

- **[Mitchell Hashimoto — *My AI Adoption Journey*](https://mitchellh.com/writing/my-ai-adoption-journey)**
  (Feb 2026) — *the* end-to-end personal-workflow writeup of the quarter.
  Covers harness engineering, the "last 30 minutes of the day" agent kickoff,
  `AGENTS.md`.
- **[Fragmented Podcast Ep. 310](https://fragmentedpodcast.com/episodes/310/)**
  — *Mitchell Hashimoto on Ghostty & His Agentic Coding Workflow*. Audio
  companion to the post; show notes are substantive.
- **[Latent Space — Claude Code: Anthropic's Agent in Your Terminal](https://www.latent.space/p/claude-code)**
  — Cat Wu and Boris Cherny from Anthropic on internal Claude Code design
  choices. Useful if building *around* Claude Code rather than just using it.
- **[Pragmatic Engineer — Mitchell Hashimoto's New Way of Writing Code](https://newsletter.pragmaticengineer.com/p/mitchell-hashimoto)**
  + **[From IDEs to AI Agents with Steve Yegge](https://newsletter.pragmaticengineer.com/p/from-ides-to-ai-agents-with-steve)**
  — Gergely Orosz's syntheses; both 2026. Caveat: paid subscription for full
  content.
- **[Druce Vertes — Speedrunning the Claude Code Learning Curve](https://druce.ai/2026/02/claude-code)**
  (Feb 2026) — week-by-week "what I'd do differently."
- **[Hamel Husain — Evals Skills for Coding Agents](https://hamel.dev/blog/posts/evals-skills/)**
  (Mar 2026) — practical: how to wire evals into a Claude Code skills setup.
- **[masutaka — How I Currently Use Claude Code (2026-04)](https://dev.to/masutaka/2026-04-how-i-currently-use-claude-code-2nck)**
  — short, dated, repeats every few months, good for trend-spotting.
- **[psantanna — My Claude Code Setup](https://psantanna.com/claude-code-my-workflow/workflow-guide.html)**
  — full workflow guide with the actual configs.

## Communities

- **r/ClaudeCode** — ~4.2k weekly contributors as of late 2025; primary venue
  for hooks/skills/MCP threads. High signal-to-noise relative to other LLM
  subs.
- **r/ChatGPTCoding** — multi-tool subreddit where Claude Code / Codex /
  Cursor get compared; useful for "which agent for which task" discussions.
- **HN tag tracking via simonw** — Simon Willison's blog is, in practice,
  the best filter for HN agent-tooling threads worth reading.
- **GitHub Discussions on
  [obra/superpowers](https://github.com/obra/superpowers)** — active issue
  tracker doubles as a workflow forum (e.g.
  [issue #1260](https://github.com/obra/superpowers/issues/1260) on Plan
  Mode integration). Real practitioners debating real edge cases.
- **Anthropic Discord — `#claude-code` channel** — verified active in 2026;
  where new hook/skill/MCP patterns surface before they get blogged.
- **[Agentic Coding Weekly](https://www.agenticcodingweekly.com/p/workflow-of-the-week-collection)**
  — newsletter with a *Workflow of the Week* slot pulling from blogs above;
  single-feed digest if you don't want to follow 12 blogs.

## Patterns recurring in 2026 workflows

1. **Harness engineering over prompt engineering.** Mitchell Hashimoto, Jesse
   Vincent, and the Superpowers community all converge: when the agent fails,
   *don't rewrite the prompt — change the environment*. Add a lint rule, a
   test harness, a hook that blocks the bad behavior, an `AGENTS.md` /
   `CLAUDE.md` line. `dynamic_ralph` should treat each PRD-loop failure as a
   chance to grow the validation harness, not the prompt.

2. **Skills + hooks beat monolithic CLAUDE.md.** The `obra/superpowers` model
   (composable skills, ~200 LOC each, activated by metadata) is winning.
   Hooks live in `settings.json` and exist to *physically block* bad behavior
   (no direct `git push`, no `rm -rf`, mandatory test-run before commit).
   Memory/CLAUDE.md is for context the agent should *know*; hooks are for
   things the agent *cannot be allowed to do*. Don't conflate.

3. **Plan-then-build with split context.** Hrishi's "plan with Gemini, build
   with Claude" generalized: practitioners run a planning model into a
   markdown plan file, then hand that plan to a fresh-context implementation
   agent. Inside Claude Code, the same pattern manifests as Plan Mode →
   `ExitPlanMode` → execution. For `dynamic_ralph`, this argues for a
   separate "plan" step writing a scratch file the implementation step
   reads — which the existing workflow engine already accommodates.

4. **Append-only scratchpads + sub-agent fan-out.** Two patterns appear in
   nearly every recent setup: (a) an append-only `scratchpad.md` /
   `journal.md` the agent maintains across the loop (gotchas, decisions,
   dead ends — survives compaction), and (b) `Task`-tool fan-out to up to 10
   sub-agents for embarrassingly-parallel reads (audit, search,
   doc-comparison). Background runs (Hashimoto's "last 30 minutes of the
   day") are a third leg — and where a Docker-loop orchestrator like
   `dynamic_ralph` shines.

5. **Evals are catching up to coding agents.** Hamel Husain's *Evals Skills
   for Coding Agents* and the Pragmatic Engineer Summit takeaways agree:
   2026's differentiator is no longer "do you use an agent" but "can you
   measure whether your agent got better last week?" Worth wiring a thin
   eval harness into `dynamic_ralph` (PRD-pass-rate, diff-quality scoring,
   retro-derived regressions) before scaling to more parallel runs.
