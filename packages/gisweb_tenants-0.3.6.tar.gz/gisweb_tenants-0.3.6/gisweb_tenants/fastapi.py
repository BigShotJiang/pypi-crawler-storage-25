# fastapi.py
from typing import Literal

from fastapi import Header, HTTPException
from fastapi.requests import Request
from fastapi.responses import JSONResponse
from sqlalchemy.exc import DBAPIError, OperationalError, ProgrammingError, StatementError

from .internal_token import (
    InternalTokenClaims,
    InvalidInternalTokenError,
    MissingInternalTokenError,
    decode_internal_token,
    extract_bearer_token,
)


# =========================================================
# Middleware
# =========================================================

async def database_error_middleware(request: Request, call_next):
    try:
        return await call_next(request)

    except OperationalError:
        # Connessione al DB assente o interrotta — problema infrastrutturale
        return JSONResponse(
            status_code=503,
            content={"detail": "Database non disponibile"},
        )

    except ProgrammingError:
        # Errore strutturale (tabella mancante, colonna sbagliata) — bug del codice
        return JSONResponse(
            status_code=500,
            content={"detail": "Errore interno del server"},
        )

    except StatementError:
        # Tipo di dato non valido passato a SQLAlchemy — bug del codice o input malformato
        return JSONResponse(
            status_code=500,
            content={"detail": "Errore interno del server"},
        )

    except DBAPIError:
        # Catch-all per altri errori DB non classificati
        return JSONResponse(
            status_code=503,
            content={"detail": "Errore database"},
        )


# =========================================================
# Internal auth dependency factory
# =========================================================

def make_internal_auth_dependency(
    *,
    secret: str,
    audience: str,
    issuer: str = "fastapi-bff",
    algorithm: Literal["HS256", "HS384", "HS512"] = "HS256",
    leeway_seconds: int = 5,
    require_groups: list[str] | None = None,
):
    """
    Factory che restituisce una dependency FastAPI per verificare
    il token interno emesso dal BFF.

    Uso tipico nel microservizio:

        get_current_user = make_internal_auth_dependency(
            secret=settings.internal_token_secret,
            audience="nome-microservizio",
        )

        get_admin_user = make_internal_auth_dependency(
            secret=settings.internal_token_secret,
            audience="nome-microservizio",
            require_groups=["amministratori"],
        )

        @router.get("/risorsa")
        async def risorsa(user: InternalTokenClaims = Depends(get_current_user)):
            ...

        @router.get("/admin")
        async def admin(user: InternalTokenClaims = Depends(get_admin_user)):
            ...
    """

    async def _dependency(
        authorization: str | None = Header(default=None),
    ) -> InternalTokenClaims:
        try:
            token = extract_bearer_token(authorization)
            claims = decode_internal_token(
                token,
                secret=secret,
                expected_audience=audience,
                expected_issuer=issuer,
                algorithm=algorithm,
                leeway_seconds=leeway_seconds,
            )
        except MissingInternalTokenError:
            raise HTTPException(status_code=401, detail="missing_token")
        except InvalidInternalTokenError as exc:
            raise HTTPException(status_code=401, detail=str(exc))

        if require_groups:
            if not any(g in claims.groups for g in require_groups):
                raise HTTPException(status_code=403, detail="insufficient_permissions")

        return claims

    return _dependency