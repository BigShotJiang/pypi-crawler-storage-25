"""
Public signals fired by aa_skip_email.

The ``placeholder_email_replaced`` signal is sent when ``User.email``
transitions from a plugin-generated placeholder to a non-placeholder
address.

Receivers receive::

    sender   = User class
    user     = the User instance (already saved)
    old_email = previous (placeholder) value
    new_email = new (non-placeholder) value

The signal does **not** fire when:

- A blank / NULL email is filled with a placeholder (initial backfill).
- A placeholder is rewritten to another placeholder (e.g. management
  command ``--overwrite --only-placeholders``).
- A real email is overwritten with another real email (out of scope).

Connect via dispatch_uid to avoid double-registration::

    from aa_skip_email.signals import placeholder_email_replaced

    @receiver(placeholder_email_replaced, dispatch_uid="my_app.email_verified")
    def mark_verified(sender, user, old_email, new_email, **kwargs):
        ...
"""

from django.dispatch import Signal

placeholder_email_replaced = Signal()
