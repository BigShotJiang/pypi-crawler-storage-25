"""Django management commands shipped by aa_skip_email."""
