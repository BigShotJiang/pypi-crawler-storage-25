"""Allows you to skip entering your email after registering via EVE SSO."""

__all__ = (
    "__title__",
    "__version__",
    "is_placeholder_email",
    "make_placeholder_email",
)

__title__ = "Allianceauth Skip Email"
__version__ = "0.3.8"

from aa_skip_email.helpers import is_placeholder_email, make_placeholder_email
