"""
kairix.platform.llm — LLM backend abstraction layer.

Provides a ``LLMBackend`` protocol so kairix components can call
chat/embed APIs without a hard dependency on any specific provider.

Built-in backends:
  AzureOpenAIBackend — wraps kairix._azure (Azure OpenAI, Key Vault secrets)

Usage::

    from kairix.platform.llm import get_default_backend

    backend = get_default_backend()
    reply = backend.chat(messages=[{"role": "user", "content": "Hello"}])

Or inject a specific backend for testing::

    from kairix.platform.llm.backends import AzureOpenAIBackend
    backend = AzureOpenAIBackend()
"""

from kairix.platform.llm.backends import AzureOpenAIBackend
from kairix.platform.llm.protocol import LLMBackend

__all__ = ["AzureOpenAIBackend", "LLMBackend", "get_default_backend"]


def get_default_backend() -> LLMBackend:
    """Return the default backend (Azure OpenAI via _azure.py)."""
    return AzureOpenAIBackend()
