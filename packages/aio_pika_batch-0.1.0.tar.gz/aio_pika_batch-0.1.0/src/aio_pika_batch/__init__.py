"""aio-pika-batch: Batch consumer for aio-pika with per-message acknowledgment.

No Python library provides a batch consumer for RabbitMQ. aio-pika gives you
queue iterators and manual ack. This library adds the missing piece: reliable
batch collection with per-message ACK/NACK/REQUEUE, retry tracking, dead-letter
routing, and multi-worker scaling.

Quick start::

    from aio_pika_batch import BatchConsumer, BatchConsumerSettings, MessageResult

    class MyConsumer(BatchConsumer):
        async def process_messages(self, messages):
            for msg in messages:
                try:
                    data = json.loads(msg.body)
                    await publish(data)
                    yield MessageResult.ACK
                except Exception:
                    yield MessageResult.REQUEUE

    consumer = MyConsumer(BatchConsumerSettings(
        queue_name="my-queue",
        batch_size=50,
        batch_timeout=2.0,
    ))
    await consumer.run()
"""

from .batch_consumer import BatchConsumer
from .consumer import Consumer
from .result import RETRY_COUNT_HEADER, MessageResult
from .settings import BatchConsumerSettings, ConsumerSettings

__all__ = [
    "BatchConsumer",
    "BatchConsumerSettings",
    "Consumer",
    "ConsumerSettings",
    "MessageResult",
    "RETRY_COUNT_HEADER",
]

__version__ = "0.1.0"
