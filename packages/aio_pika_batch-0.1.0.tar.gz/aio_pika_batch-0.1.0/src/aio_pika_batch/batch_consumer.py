"""Batch consumer base class with size/timeout flushing and per-message results."""

import asyncio
import signal
from abc import ABC, abstractmethod
from collections.abc import AsyncIterator
from typing import Any

import structlog
from aio_pika import Channel
from aio_pika.abc import AbstractIncomingMessage, AbstractQueue

from .result import MessageResult
from .retry import handle_message_result
from .settings import BatchConsumerSettings
from .worker import WorkerManager


class BatchConsumer[TSettings: BatchConsumerSettings](ABC):
    """Base class for batch RabbitMQ consumers.

    Messages accumulate until ``batch_size`` is reached or ``batch_timeout``
    seconds have elapsed since the first message in the batch, whichever
    comes first. The batch is then passed to :meth:`process_messages`.

    :meth:`process_messages` is an async generator that yields one
    :class:`MessageResult` per message, in order. Each result is mapped
    back to the corresponding message for individual ack/nack/requeue.

    If an unhandled exception occurs mid-batch, already-yielded results are
    honored. Remaining messages receive ``unhandled_exception_action``
    (default: ``REQUEUE``).

    Example::

        class MyBatchConsumer(BatchConsumer):
            async def process_messages(self, messages):
                for msg in messages:
                    try:
                        data = json.loads(msg.body)
                        await publish(data)
                        yield MessageResult.ACK
                    except json.JSONDecodeError:
                        yield MessageResult.NACK

        consumer = MyBatchConsumer(BatchConsumerSettings(
            queue_name="events",
            batch_size=50,
            batch_timeout=2.0,
        ))
        await consumer.run()
    """

    def __init__(self, settings: TSettings):
        self.settings: TSettings = settings
        self._worker_manager: WorkerManager | None = None
        # Per-worker state (set during _run_internal)
        self._batch: list[AbstractIncomingMessage] = []
        self._batch_timer: asyncio.Task[Any] | None = None  # pyright: ignore[reportExplicitAny]

    @property
    def is_healthy(self) -> bool:
        """True if at least one worker has an active connection."""
        return self._worker_manager.is_healthy if self._worker_manager else False

    @property
    def is_running(self) -> bool:
        """True if consumer has started and not stopped."""
        return self._worker_manager.is_running if self._worker_manager else False

    async def on_start(self) -> None:  # noqa: B027
        """Called once before consuming begins. Override for setup logic."""

    async def on_stop(self) -> None:  # noqa: B027
        """Called once after consuming stops. Override for cleanup logic."""

    async def start(self) -> None:
        """Start consuming messages. Blocks until :meth:`stop` is called."""
        await self.on_start()
        self._worker_manager = WorkerManager(self.settings)
        tasks = await self._worker_manager.start_workers(self, self.settings)
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

    async def stop(self) -> None:
        """Gracefully stop all workers and close connections."""
        if self._worker_manager:
            await self._worker_manager.stop()
        await self.on_stop()

    async def run(self) -> None:
        """Start with signal handling (SIGINT/SIGTERM trigger graceful shutdown)."""
        loop = asyncio.get_running_loop()

        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(sig, lambda: asyncio.create_task(self.stop()))

        try:
            await self.start()
        finally:
            await self.on_stop()

    async def __aenter__(self) -> "BatchConsumer[TSettings]":
        await self.on_start()
        self._worker_manager = WorkerManager(self.settings)
        await self._worker_manager.start_workers(self, self.settings)
        return self

    async def __aexit__(self, *args: Any) -> None:  # pyright: ignore[reportExplicitAny]
        await self.stop()

    # -- Internal API (called by WorkerManager) --

    async def _run_internal(
        self,
        channel: Channel,
        queue: AbstractQueue,
        settings: TSettings,
        stop_event: asyncio.Event,
        log: structlog.typing.FilteringBoundLogger,
    ) -> None:
        """Internal batch consumption loop. Called by :class:`WorkerManager`."""
        self._batch = []
        self._batch_timer = None

        try:
            async with queue.iterator() as queue_iter:
                async for message in queue_iter:
                    if stop_event.is_set():
                        await self._flush_batch(channel, settings, stop_event, log)
                        break

                    self._batch.append(message)

                    if len(self._batch) >= settings.batch_size:
                        await self._flush_batch(channel, settings, stop_event, log)
                    elif len(self._batch) == 1:
                        self._start_timer(channel, settings, stop_event, log)

                    if stop_event.is_set():
                        break

            # Flush remaining
            await self._flush_batch(channel, settings, stop_event, log)

        except asyncio.CancelledError:
            log.info("Batch consumer cancelled")
            await self._flush_batch(channel, settings, stop_event, log)

    def _start_timer(
        self,
        channel: Channel,
        settings: TSettings,
        stop_event: asyncio.Event,
        log: structlog.typing.FilteringBoundLogger,
    ) -> None:
        if self._batch_timer and not self._batch_timer.done():
            self._batch_timer.cancel()
        self._batch_timer = asyncio.create_task(
            self._flush_after_timeout(channel, settings, stop_event, log)
        )
        log.debug(
            "Batch timer started",
            batch_timeout=settings.batch_timeout,
            batch_size=len(self._batch),
        )

    async def _flush_after_timeout(
        self,
        channel: Channel,
        settings: TSettings,
        stop_event: asyncio.Event,
        log: structlog.typing.FilteringBoundLogger,
    ) -> None:
        try:
            await asyncio.sleep(settings.batch_timeout)
            log.debug(
                "Batch timeout fired",
                batch_size=len(self._batch),
            )
            await self._flush_batch(channel, settings, stop_event, log)
        except asyncio.CancelledError:
            pass

    async def _flush_batch(
        self,
        channel: Channel,
        settings: TSettings,
        stop_event: asyncio.Event,
        log: structlog.typing.FilteringBoundLogger,
    ) -> None:
        if not self._batch:
            return

        batch = self._batch
        self._batch = []

        # Cancel timer if we're not being called from it
        current_task = asyncio.current_task()
        if (
            self._batch_timer
            and self._batch_timer is not current_task
            and not self._batch_timer.done()
        ):
            self._batch_timer.cancel()
        self._batch_timer = None

        # Collect results from process_messages
        results: list[MessageResult] = []
        processed_count = 0

        try:
            async for result in self.process_messages(batch):
                results.append(result)
                processed_count += 1

        except Exception as e:
            log.error(
                "Batch processing error after "
                f"{processed_count}/{len(batch)} messages: {e}",
            )
            default_action = settings.unhandled_exception_action
            remaining = len(batch) - processed_count
            results.extend([default_action] * remaining)
            log.info(
                f"Applying {default_action.value} to {remaining} unprocessed messages"
            )

        # Handle each message according to its result
        for i, (message, result) in enumerate(zip(batch, results, strict=False)):
            await handle_message_result(
                channel=channel,
                message=message,
                result=result,
                queue_name=settings.queue_name,
                max_requeue_attempts=settings.max_requeue_attempts,
                log=log,
                message_index=i,
                is_shutting_down=stop_event.is_set(),
            )

    @abstractmethod
    async def process_messages(
        self,
        messages: list[AbstractIncomingMessage],
    ) -> AsyncIterator[MessageResult]:
        """Process a batch of messages.

        Yield one :class:`MessageResult` per message, in order. If an
        exception is raised, the library applies ``unhandled_exception_action``
        to any remaining un-yielded messages.

        Args:
            messages: List of incoming RabbitMQ messages in the batch.

        Yields:
            :class:`MessageResult` for each message.

        Example::

            async def process_messages(self, messages):
                for message in messages:
                    try:
                        data = json.loads(message.body)
                        await self.publish(data)
                        yield MessageResult.ACK
                    except json.JSONDecodeError:
                        yield MessageResult.NACK
                    except DatabaseError:
                        yield MessageResult.REQUEUE
        """
        yield MessageResult.ACK  # pragma: no cover
