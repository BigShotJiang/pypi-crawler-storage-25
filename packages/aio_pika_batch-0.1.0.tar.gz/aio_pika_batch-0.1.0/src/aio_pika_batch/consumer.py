"""Single-message consumer base class."""

import asyncio
import signal
from abc import ABC, abstractmethod
from typing import Any

import structlog
from aio_pika import Channel
from aio_pika.abc import AbstractIncomingMessage, AbstractQueue

from .result import MessageResult
from .retry import handle_message_result
from .settings import ConsumerSettings
from .worker import WorkerManager


class Consumer[TSettings: ConsumerSettings](ABC):
    """Base class for single-message RabbitMQ consumers.

    Subclass and implement :meth:`process_message` to handle each message.

    Example::

        class MyConsumer(Consumer):
            async def process_message(self, message) -> MessageResult:
                data = json.loads(message.body)
                await save_to_db(data)
                return MessageResult.ACK

        consumer = MyConsumer(ConsumerSettings(queue_name="my-queue"))
        await consumer.run()
    """

    def __init__(self, settings: TSettings):
        self.settings: TSettings = settings
        self._worker_manager: WorkerManager | None = None

    @property
    def is_healthy(self) -> bool:
        """True if at least one worker has an active connection."""
        return self._worker_manager.is_healthy if self._worker_manager else False

    @property
    def is_running(self) -> bool:
        """True if consumer has started and not stopped."""
        return self._worker_manager.is_running if self._worker_manager else False

    async def on_start(self) -> None:  # noqa: B027
        """Called once before consuming begins. Override for setup logic."""

    async def on_stop(self) -> None:  # noqa: B027
        """Called once after consuming stops. Override for cleanup logic."""

    async def start(self) -> None:
        """Start consuming messages. Blocks until :meth:`stop` is called."""
        await self.on_start()
        self._worker_manager = WorkerManager(self.settings)
        tasks = await self._worker_manager.start_workers(self, self.settings)
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

    async def stop(self) -> None:
        """Gracefully stop all workers and close connections."""
        if self._worker_manager:
            await self._worker_manager.stop()
        await self.on_stop()

    async def run(self) -> None:
        """Start with signal handling (SIGINT/SIGTERM trigger graceful shutdown)."""
        loop = asyncio.get_running_loop()

        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(sig, lambda: asyncio.create_task(self.stop()))

        try:
            await self.start()
        finally:
            await self.on_stop()

    async def __aenter__(self) -> "Consumer[TSettings]":
        await self.on_start()
        self._worker_manager = WorkerManager(self.settings)
        await self._worker_manager.start_workers(self, self.settings)
        return self

    async def __aexit__(self, *args: Any) -> None:  # pyright: ignore[reportExplicitAny]
        await self.stop()

    # -- Internal API (called by WorkerManager) --

    async def _run_internal(
        self,
        channel: Channel,
        queue: AbstractQueue,
        settings: TSettings,
        stop_event: asyncio.Event,
        log: structlog.typing.FilteringBoundLogger,
    ) -> None:
        """Internal consumption loop. Called by :class:`WorkerManager`."""
        try:
            async with queue.iterator() as queue_iter:
                async for message in queue_iter:
                    if stop_event.is_set():
                        break

                    try:
                        result = await self.process_message(message)
                    except Exception as e:
                        log.error(f"Unhandled exception processing message: {e}")
                        result = settings.unhandled_exception_action

                    await handle_message_result(
                        channel=channel,
                        message=message,
                        result=result,
                        queue_name=settings.queue_name,
                        max_requeue_attempts=settings.max_requeue_attempts,
                        log=log,
                        is_shutting_down=stop_event.is_set(),
                    )

                    if stop_event.is_set():
                        break

        except asyncio.CancelledError:
            log.debug("Consumer cancelled")

    @abstractmethod
    async def process_message(
        self,
        message: AbstractIncomingMessage,
    ) -> MessageResult:
        """Process a single message.

        Args:
            message: The incoming RabbitMQ message.

        Returns:
            :class:`MessageResult` indicating how to acknowledge the message.
        """
        ...
