"""Worker management, connection establishment, and recovery logic."""

import asyncio
import contextlib
from typing import Any

import structlog
from aio_pika import Channel, connect_robust
from aio_pika.abc import AbstractRobustConnection
from aio_pika.exceptions import AMQPConnectionError, AMQPError, ChannelClosed

from .settings import BatchConsumerSettings, ConsumerSettings

logger = structlog.get_logger()


class WorkerManager:
    """Manages consumer worker tasks with connection recovery.

    Each worker gets its own channel and queue iterator. RabbitMQ distributes
    messages across workers via round-robin prefetch.
    """

    def __init__(self, settings: ConsumerSettings):
        self.settings = settings
        self._tasks: list[asyncio.Task[Any]] = []  # pyright: ignore[reportExplicitAny]
        self._stop_event = asyncio.Event()
        self._connection: AbstractRobustConnection | None = None
        self._connection_lock = asyncio.Lock()
        self._is_healthy = False

    @property
    def is_healthy(self) -> bool:
        """True if at least one worker has an active connection."""
        return self._is_healthy

    @property
    def is_running(self) -> bool:
        """True if workers have been started and not stopped."""
        return bool(self._tasks) and not self._stop_event.is_set()

    async def _get_connection(self) -> AbstractRobustConnection:
        """Get or create the shared connection (singleton per manager)."""
        async with self._connection_lock:
            if self._connection is None or self._connection.is_closed:
                logger.info(
                    "Establishing RabbitMQ connection",
                    url=_obfuscate_url(self.settings.url),
                )
                self._connection = await connect_robust(
                    self.settings.url,
                    timeout=10,
                )
                logger.info("RabbitMQ connection established")
            return self._connection

    async def start_workers(
        self,
        consumer_instance: "Any",  # pyright: ignore[reportExplicitAny]
        settings: ConsumerSettings | BatchConsumerSettings,
    ) -> list[asyncio.Task[Any]]:  # pyright: ignore[reportExplicitAny]
        """Spawn ``num_workers`` worker tasks.

        Worker 0 reuses ``consumer_instance`` so the caller retains a
        reference to the live consumer (important for state like
        ``received`` lists, counters, etc.). Workers 1+ get fresh
        instances created from ``type(consumer_instance)``.

        Args:
            consumer_instance: The consumer instance to run.
            settings: Consumer settings.

        Returns:
            List of started asyncio tasks.
        """
        consumer_factory = type(consumer_instance)

        for worker_index in range(settings.num_workers):
            if settings.num_workers > 1:
                name = f"{consumer_factory.__name__}[{worker_index}]"
            else:
                name = consumer_factory.__name__

            # Reuse the caller's instance for worker 0, create new for others
            instance = (
                consumer_instance if worker_index == 0 else consumer_factory(settings)
            )

            task = asyncio.create_task(
                self._run_worker(instance, settings, name, worker_index),
                name=name,
            )
            self._tasks.append(task)

        return self._tasks

    async def _run_worker(
        self,
        consumer_instance: "Any",  # pyright: ignore[reportExplicitAny]
        settings: ConsumerSettings | BatchConsumerSettings,
        name: str,
        worker_index: int,
    ) -> None:
        """Run a single worker with automatic reconnection."""
        retry_delay = 1.0
        max_retry_delay = 60.0
        retry_count = 0
        log = logger.bind(consumer=name, worker_index=worker_index)

        while not self._stop_event.is_set():
            channel: Channel | None = None

            try:
                if retry_count > 0:
                    log.info(f"Reconnecting (attempt {retry_count + 1})")
                else:
                    log.info(
                        "Starting worker",
                        queue=settings.queue_name,
                    )

                connection = await self._get_connection()
                channel = await connection.channel()  # pyright: ignore[reportAssignmentType]
                assert channel is not None
                await channel.set_qos(prefetch_count=settings.prefetch_count)

                # Declare queue
                queue = await channel.declare_queue(
                    settings.queue_name,
                    durable=settings.queue_durable,
                    arguments=settings.queue_arguments,
                )

                # Declare and bind exchange if configured
                if settings.exchange_name is not None:
                    exchange = await channel.declare_exchange(
                        settings.exchange_name,
                        type=settings.exchange_type,
                        durable=settings.exchange_durable,
                    )
                    await queue.bind(exchange, routing_key=settings.routing_key)

                retry_count = 0
                retry_delay = 1.0
                self._is_healthy = True

                # Run consumer
                await consumer_instance._run_internal(
                    channel=channel,
                    queue=queue,
                    settings=settings,
                    stop_event=self._stop_event,
                    log=log,
                )

                # Normal exit
                log.debug("Worker exited normally")
                break

            except asyncio.CancelledError:
                log.info("Worker cancelled")
                raise

            except (AMQPConnectionError, AMQPError, ChannelClosed) as e:
                self._is_healthy = False
                retry_count += 1
                log.warning(f"Connection error: {e}. Retrying in {retry_delay}s...")

                if channel is not None and not channel.is_closed:
                    with contextlib.suppress(Exception):
                        await channel.close()

                try:
                    await asyncio.sleep(retry_delay)
                except asyncio.CancelledError:
                    raise

                retry_delay = min(retry_delay * 2, max_retry_delay)

            except Exception as e:
                self._is_healthy = False
                log.error(f"Fatal error: {e}")
                raise

            finally:
                if channel is not None and not channel.is_closed:
                    with contextlib.suppress(Exception):
                        await channel.close()

    async def stop(self) -> None:
        """Signal all workers to stop and wait for them to finish."""
        self._stop_event.set()

        for task in self._tasks:
            task.cancel()

        if self._tasks:
            await asyncio.gather(*self._tasks, return_exceptions=True)

        self._tasks.clear()
        self._is_healthy = False

        # Close the shared connection
        if self._connection and not self._connection.is_closed:
            try:
                await self._connection.close()
                logger.info("RabbitMQ connection closed")
            except Exception:
                pass
            self._connection = None


def _obfuscate_url(url: str) -> str:
    """Obfuscate credentials in an AMQP URL for safe logging."""
    from urllib.parse import urlparse, urlunparse

    if not url:
        return url
    try:
        parsed = urlparse(url)
        if parsed.username or parsed.password:
            username = (
                parsed.username[:2] + "***"
                if parsed.username and len(parsed.username) > 2
                else "***"
            )
            netloc = f"{username}:***@{parsed.hostname}"
            if parsed.port:
                netloc += f":{parsed.port}"
            return urlunparse(parsed._replace(netloc=netloc))
        return url
    except Exception:
        return "[URL obfuscated]"
