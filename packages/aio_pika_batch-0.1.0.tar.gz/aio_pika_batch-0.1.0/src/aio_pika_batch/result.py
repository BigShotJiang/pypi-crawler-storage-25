"""Message result types for consumer acknowledgment."""

from enum import Enum

# Header name for tracking requeue attempts
RETRY_COUNT_HEADER = "x-retry-count"


class MessageResult(Enum):
    """Result of processing a message, returned by consumers to indicate outcome.

    ACK:
        Message processed successfully. Permanently removed from the queue.

    NACK:
        Bad data (malformed JSON, invalid schema, unknown type). Sent to the
        Dead Letter Exchange (DLX) if configured, or discarded. Will NOT be retried.

    REQUEUE:
        Transient failure (database down, service unavailable, rate limited).
        Republished to the BACK of the queue with an incremented retry counter
        in the ``x-retry-count`` header. Provides natural backoff as other
        messages are processed first.

        When ``retry_count >= max_requeue_attempts`` (default: 3), the message
        is sent to the DLX instead of being requeued.

    REQUEUE_IMMEDIATE:
        Native ``nack(requeue=True)`` — places the message at the FRONT of the
        queue for immediate redelivery.

        **WARNING:** Does NOT track retry counts. Messages retry indefinitely
        and ``max_requeue_attempts`` is ignored. Can cause retry storms on
        persistent failures. Prefer ``REQUEUE`` for production use.

    Example::

        async def process_message(self, message) -> MessageResult:
            try:
                data = json.loads(message.body)
            except json.JSONDecodeError:
                return MessageResult.NACK  # Bad data, don't retry

            try:
                await external_service.process(data)
            except ServiceTemporarilyUnavailable:
                return MessageResult.REQUEUE  # Transient, retry with backoff
            except ServicePermanentlyUnavailable:
                return MessageResult.NACK  # Service gone, don't retry

            return MessageResult.ACK  # Success
    """

    ACK = "ack"
    NACK = "nack"
    REQUEUE = "requeue"
    REQUEUE_IMMEDIATE = "requeue_immediate"
