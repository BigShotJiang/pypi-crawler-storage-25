"""Retry tracking and message republishing logic."""

from typing import Any

import structlog
from aio_pika import Channel, Message
from aio_pika.abc import AbstractIncomingMessage

from .result import RETRY_COUNT_HEADER, MessageResult

logger = structlog.get_logger()


def get_retry_count(message: AbstractIncomingMessage) -> int:
    """Get the retry count from message headers.

    Returns 0 if the header is missing or cannot be parsed.
    """
    if message.headers and RETRY_COUNT_HEADER in message.headers:
        try:
            header_value = message.headers[RETRY_COUNT_HEADER]
            if isinstance(header_value, int):
                return header_value
            if isinstance(header_value, str):
                return int(header_value)
            return 0
        except (ValueError, TypeError):
            return 0
    return 0


async def republish_with_retry_count(
    channel: Channel,
    message: AbstractIncomingMessage,
    new_retry_count: int,
    queue_name: str,
) -> None:
    """Republish message to back of queue with incremented retry count.

    1. Creates a new message with the same body and preserved headers
    2. Sets the ``x-retry-count`` header to ``new_retry_count``
    3. Publishes to the same queue via default exchange
    4. Acknowledges the original message

    The message goes to the BACK of the queue, providing natural backoff
    as other messages are processed first.
    """
    new_headers: dict[str, Any] = dict(message.headers) if message.headers else {}  # pyright: ignore[reportExplicitAny]
    new_headers[RETRY_COUNT_HEADER] = new_retry_count

    new_message = Message(
        body=message.body,
        headers=new_headers,
        content_type=message.content_type,
        content_encoding=message.content_encoding,
        delivery_mode=message.delivery_mode,
        priority=message.priority,
        correlation_id=message.correlation_id,
        reply_to=message.reply_to,
        expiration=message.expiration,
        message_id=message.message_id,
        timestamp=message.timestamp,
        type=message.type,
        user_id=None,  # Cannot preserve user_id on republish
        app_id=message.app_id,
    )

    await channel.default_exchange.publish(
        new_message,
        routing_key=queue_name,
    )
    await message.ack()


async def handle_message_result(
    channel: Channel,
    message: AbstractIncomingMessage,
    result: MessageResult,
    queue_name: str,
    max_requeue_attempts: int,
    log: structlog.typing.FilteringBoundLogger | None = None,
    message_index: int | None = None,
    is_shutting_down: bool = False,
) -> None:
    """Handle a single message based on its :class:`MessageResult`.

    Args:
        channel: The aio-pika channel for republishing.
        message: The original incoming message.
        result: The processing result.
        queue_name: Queue name for republishing on REQUEUE.
        max_requeue_attempts: Max retries before DLX.
        log: Optional structured logger.
        message_index: Optional index for batch logging.
        is_shutting_down: If True, suppress ack/nack errors during shutdown.
    """
    _log = log or logger
    idx = f" {message_index}" if message_index is not None else ""

    try:
        if result == MessageResult.ACK:
            await message.ack()

        elif result == MessageResult.NACK:
            await message.nack(requeue=False)

        elif result == MessageResult.REQUEUE:
            retry_count = get_retry_count(message)
            if retry_count >= max_requeue_attempts:
                _log.warning(
                    f"Message{idx} exceeded max requeue attempts "
                    f"({max_requeue_attempts}), sending to DLX",
                )
                await message.nack(requeue=False)
            else:
                _log.info(
                    f"Requeuing message{idx} "
                    f"(attempt {retry_count + 1}/{max_requeue_attempts})",
                )
                await republish_with_retry_count(
                    channel, message, retry_count + 1, queue_name
                )

        elif result == MessageResult.REQUEUE_IMMEDIATE:
            _log.debug(f"Immediate requeue for message{idx} (no retry tracking)")
            await message.nack(requeue=True)

    except Exception as e:
        if is_shutting_down:
            _log.debug(f"Could not ack/nack message{idx} during shutdown: {e}")
        else:
            _log.error(f"Failed to ack/nack message{idx}: {e}")
