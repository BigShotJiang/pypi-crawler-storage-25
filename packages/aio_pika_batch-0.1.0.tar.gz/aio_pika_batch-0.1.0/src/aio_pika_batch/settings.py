"""Consumer settings with pydantic-settings integration."""

from typing import Any

from pydantic_settings import BaseSettings

from .result import MessageResult


class ConsumerSettings(BaseSettings):
    """Base settings for RabbitMQ consumers.

    All settings can be loaded from environment variables. Subclass and set
    ``model_config`` with an ``env_prefix`` to namespace your variables::

        class MySettings(ConsumerSettings):
            model_config = SettingsConfigDict(env_prefix="MY_APP_")

    Attributes:
        url: AMQP connection URL.
        prefetch_count: QoS prefetch limit per channel. Prevents OOM by
            limiting in-flight messages.
        queue_name: Name of the queue to consume from.
        exchange_name: Exchange to declare and bind to (optional).
        exchange_type: Exchange type (direct, fanout, topic, headers).
        routing_key: Routing key for queue-to-exchange binding.
        queue_durable: Whether the queue survives broker restarts.
        exchange_durable: Whether the exchange survives broker restarts.
        queue_arguments: Extra queue arguments (TTL, DLX, etc.).
        num_workers: Number of parallel consumer workers.
        max_requeue_attempts: Max times to requeue before sending to DLX.
        unhandled_exception_action: Default action when ``process_message``
            raises an unhandled exception.
    """

    # Connection
    url: str = "amqp://guest:guest@localhost:5672/"
    prefetch_count: int = 10

    # Queue configuration
    queue_name: str
    exchange_name: str | None = None
    exchange_type: str = "direct"
    routing_key: str | None = None

    # Queue options
    queue_durable: bool = True
    exchange_durable: bool = True
    queue_arguments: dict[str, Any] | None = None  # pyright: ignore[reportExplicitAny]

    # Workers
    num_workers: int = 1

    # Error handling
    max_requeue_attempts: int = 3
    unhandled_exception_action: MessageResult = MessageResult.REQUEUE


class BatchConsumerSettings(ConsumerSettings):
    """Settings for batch consumers.

    Extends :class:`ConsumerSettings` with batch-specific options.

    Attributes:
        batch_size: Maximum messages per batch before flushing.
        batch_timeout: Seconds to wait before flushing an incomplete batch.
    """

    batch_size: int = 10
    batch_timeout: float = 5.0
