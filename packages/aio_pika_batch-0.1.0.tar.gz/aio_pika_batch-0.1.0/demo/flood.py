#!/usr/bin/env python3
"""
aio-pika-batch demo: Flood → Merge → Drain

Publishes thousands of messages across multiple source exchanges,
merges them through batch consumers into a single staging queue,
and drains them with a writer consumer. Shows live throughput stats.

Usage:
    python demo/flood.py [--messages 5000] [--exchanges 5] [--workers 4] [--batch-size 50]

Requires:
    pip install aio-pika-batch rich
    A running RabbitMQ instance on localhost:5672
"""

import argparse
import asyncio
import json
import time
from dataclasses import dataclass, field

from aio_pika import ExchangeType, Message, connect_robust
from aio_pika.abc import AbstractIncomingMessage
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from aio_pika_batch import BatchConsumer, BatchConsumerSettings, MessageResult


# ---------------------------------------------------------------------------
# Stats tracker (shared mutable state for the dashboard)
# ---------------------------------------------------------------------------
@dataclass
class Stats:
    messages_per_exchange: dict[str, int] = field(default_factory=dict)
    published_total: int = 0
    staging_received: int = 0
    staging_acked: int = 0
    writer_received: int = 0
    writer_acked: int = 0
    batches_processed: int = 0
    errors: int = 0
    start_time: float = 0.0
    publish_done: bool = False
    drain_done: bool = False

    @property
    def elapsed(self) -> float:
        return time.time() - self.start_time if self.start_time else 0.0

    @property
    def throughput(self) -> float:
        return self.writer_acked / self.elapsed if self.elapsed > 0 else 0.0


STATS = Stats()

# ---------------------------------------------------------------------------
# Consumers
# ---------------------------------------------------------------------------

STAGING_EXCHANGE = "demo.staging"


class SourceConsumer(BatchConsumer):
    """Reads from a source exchange, forwards to staging exchange."""

    def __init__(self, settings: BatchConsumerSettings):
        super().__init__(settings)
        self._staging_exchange = None

    async def on_start(self):
        # We'll set this up in _run_internal override via the channel
        pass

    async def process_messages(self, messages: list[AbstractIncomingMessage]):
        for msg in messages:
            try:
                # Wrap in staging envelope
                envelope = {
                    "source": self.settings.exchange_name or "unknown",
                    "payload": msg.body.decode(),
                }
                # Publish to staging via the message's channel
                if self._staging_exchange:
                    await self._staging_exchange.publish(
                        Message(body=json.dumps(envelope).encode()),
                        routing_key="",
                    )
                STATS.staging_received += 1
                yield MessageResult.ACK
            except Exception:
                STATS.errors += 1
                yield MessageResult.REQUEUE

    async def _run_internal(self, channel, queue, settings, stop_event, log):
        # Declare staging exchange on our channel
        self._staging_exchange = await channel.declare_exchange(
            STAGING_EXCHANGE,
            type=ExchangeType.FANOUT,
            durable=False,
        )
        await super()._run_internal(channel, queue, settings, stop_event, log)


class WriterConsumer(BatchConsumer):
    """Reads from staging queue, simulates writing to a sink (Pub/Sub, DB, etc)."""

    async def process_messages(self, messages: list[AbstractIncomingMessage]):
        # Simulate concurrent writes with a tiny delay
        STATS.writer_received += len(messages)

        async def write(msg: AbstractIncomingMessage) -> bool:
            await asyncio.sleep(0.001)  # Simulate I/O
            return True

        results = await asyncio.gather(
            *[write(m) for m in messages], return_exceptions=True
        )

        succeeded = 0
        for result in results:
            if result is True:
                succeeded += 1
                yield MessageResult.ACK
            else:
                STATS.errors += 1
                yield MessageResult.NACK

        STATS.writer_acked += succeeded
        STATS.batches_processed += 1


# ---------------------------------------------------------------------------
# Publisher
# ---------------------------------------------------------------------------


async def flood_messages(url: str, exchanges: list[str], messages_per_exchange: int):
    """Publish messages across all source exchanges."""
    conn = await connect_robust(url, timeout=10)
    channel = await conn.channel()

    for exchange_name in exchanges:
        exchange = await channel.declare_exchange(
            exchange_name,
            type=ExchangeType.FANOUT,
            durable=False,
        )
        STATS.messages_per_exchange[exchange_name] = messages_per_exchange

        for i in range(messages_per_exchange):
            body = json.dumps({"exchange": exchange_name, "seq": i, "ts": time.time()})
            await exchange.publish(Message(body=body.encode()), routing_key="")
            STATS.published_total += 1

    await channel.close()
    await conn.close()
    STATS.publish_done = True


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------


def build_dashboard(exchanges: list[str], total_messages: int) -> Table:
    """Build the rich dashboard layout."""
    # Header
    elapsed = STATS.elapsed
    throughput = STATS.throughput

    grid = Table.grid(padding=(0, 2))
    grid.add_column(justify="left", ratio=1)

    # Title
    grid.add_row(
        Text("  aio-pika-batch demo", style="bold cyan"),
    )
    grid.add_row(Text(f"  {elapsed:.1f}s elapsed", style="dim"))
    grid.add_row(Text(""))

    # Source exchanges
    source_table = Table(
        title="Source Exchanges",
        title_style="bold yellow",
        show_lines=False,
        padding=(0, 1),
    )
    source_table.add_column("Exchange", style="cyan", min_width=20)
    source_table.add_column("Published", justify="right", style="green")

    for name in exchanges:
        count = STATS.messages_per_exchange.get(name, 0)
        source_table.add_row(name, str(count))

    grid.add_row(source_table)
    grid.add_row(Text(""))

    # Pipeline stats
    pipeline = Table(
        title="Pipeline",
        title_style="bold magenta",
        show_lines=True,
        padding=(0, 1),
    )
    pipeline.add_column("Stage", style="bold", min_width=25)
    pipeline.add_column("Count", justify="right", min_width=10)
    pipeline.add_column("Status", min_width=15)

    # Published
    pub_status = (
        "[green]done[/green]" if STATS.publish_done else "[yellow]flooding...[/yellow]"
    )
    pipeline.add_row("Published", str(STATS.published_total), pub_status)

    # Staging
    staging_pct = (
        f"{STATS.staging_received / total_messages * 100:.0f}%"
        if total_messages > 0
        else "0%"
    )
    pipeline.add_row(
        "Staging (merged)",
        str(STATS.staging_received),
        f"[cyan]{staging_pct}[/cyan]",
    )

    # Written
    writer_pct = (
        f"{STATS.writer_acked / total_messages * 100:.0f}%"
        if total_messages > 0
        else "0%"
    )
    drain_status = (
        "[green]complete[/green]" if STATS.drain_done else f"[cyan]{writer_pct}[/cyan]"
    )
    pipeline.add_row("Written (sink)", str(STATS.writer_acked), drain_status)

    # Throughput
    pipeline.add_row(
        "Throughput",
        f"{throughput:.0f} msg/s",
        f"[cyan]{STATS.batches_processed} batches[/cyan]",
    )

    # Errors
    err_style = "[red]" if STATS.errors > 0 else "[green]"
    pipeline.add_row("Errors", f"{err_style}{STATS.errors}[/]", "")

    grid.add_row(pipeline)
    grid.add_row(Text(""))

    # Progress bar
    done = STATS.writer_acked
    bar_width = 40
    filled = int(bar_width * done / total_messages) if total_messages > 0 else 0
    bar = "[green]" + "█" * filled + "[/green]" + "[dim]░[/dim]" * (bar_width - filled)
    grid.add_row(Text.from_markup(f"  {bar}  {done}/{total_messages}"))

    return grid


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


async def run(args):
    # Suppress library logging — the rich dashboard shows progress
    import logging

    import structlog

    logging.basicConfig(level=logging.WARNING)
    structlog.configure(
        wrapper_class=structlog.make_filtering_bound_logger(logging.WARNING),
    )

    url = args.url
    num_exchanges = args.exchanges
    messages_per_exchange = args.messages // num_exchanges
    total_messages = messages_per_exchange * num_exchanges
    batch_size = args.batch_size
    num_workers = args.workers

    exchange_names = [f"demo.source.{i}" for i in range(num_exchanges)]

    console = Console()
    console.clear()

    STATS.start_time = time.time()

    # Phase 0: Pre-declare queues and bind to exchanges so messages aren't lost
    console.print("[dim]Setting up queues and exchanges...[/dim]")
    setup_conn = await connect_robust(url, timeout=10)
    setup_ch = await setup_conn.channel()

    # Declare staging exchange first
    staging_ex = await setup_ch.declare_exchange(
        STAGING_EXCHANGE,
        type=ExchangeType.FANOUT,
        durable=False,
    )

    # Declare source exchanges, queues, and bindings
    for name in exchange_names:
        ex = await setup_ch.declare_exchange(
            name,
            type=ExchangeType.FANOUT,
            durable=False,
        )
        queue_name = f"demo-source-{name.replace('.', '-')}"
        q = await setup_ch.declare_queue(queue_name, durable=False)
        await q.bind(ex)

    # Declare staging writer queue and bind
    writer_q = await setup_ch.declare_queue("demo-staging-writer", durable=False)
    await writer_q.bind(staging_ex)

    await setup_ch.close()
    await setup_conn.close()

    # Phase 1: Flood (queues exist, messages will be captured)
    console.print(
        f"[bold cyan]Flooding {total_messages} messages across "
        f"{num_exchanges} exchanges...[/bold cyan]"
    )
    await flood_messages(url, exchange_names, messages_per_exchange)
    console.print(
        f"[green]Published {STATS.published_total} messages in {STATS.elapsed:.1f}s[/green]"
    )

    # Phase 2: Start consumers to drain
    source_consumers: list[SourceConsumer] = []
    for name in exchange_names:
        queue_name = f"demo-source-{name.replace('.', '-')}"
        consumer = SourceConsumer(
            BatchConsumerSettings(
                url=url,
                queue_name=queue_name,
                exchange_name=name,
                exchange_type="fanout",
                queue_durable=False,
                exchange_durable=False,
                batch_size=batch_size,
                batch_timeout=0.5,
                prefetch_count=batch_size * num_workers * 2,
                num_workers=num_workers,
            )
        )
        source_consumers.append(consumer)

    writer = WriterConsumer(
        BatchConsumerSettings(
            url=url,
            queue_name="demo-staging-writer",
            exchange_name=STAGING_EXCHANGE,
            exchange_type="fanout",
            queue_durable=False,
            exchange_durable=False,
            batch_size=batch_size,
            batch_timeout=0.5,
            prefetch_count=batch_size * 4,
            num_workers=num_workers,
        )
    )

    # Start all consumers
    all_consumers = [*source_consumers, writer]
    tasks = []
    for c in all_consumers:
        tasks.append(asyncio.create_task(c.start()))

    # Live dashboard
    with Live(
        build_dashboard(exchange_names, total_messages),
        console=console,
        refresh_per_second=10,
    ) as live:
        while STATS.writer_acked < total_messages:
            live.update(build_dashboard(exchange_names, total_messages))
            await asyncio.sleep(0.1)

            # Safety timeout
            if STATS.elapsed > 120:
                console.print("[red]Timeout after 120s[/red]")
                break

        STATS.drain_done = True
        live.update(build_dashboard(exchange_names, total_messages))

    # Stop all consumers
    for c in all_consumers:
        await c.stop()

    # Wait for tasks
    await asyncio.gather(*tasks, return_exceptions=True)

    # Summary
    console.print("")
    console.print(
        Panel.fit(
            f"[bold green]Demo complete![/bold green]\n\n"
            f"  Messages:    {total_messages:,}\n"
            f"  Exchanges:   {num_exchanges}\n"
            f"  Workers:     {num_workers} per consumer\n"
            f"  Batch size:  {batch_size}\n"
            f"  Time:        {STATS.elapsed:.1f}s\n"
            f"  Throughput:  {STATS.throughput:,.0f} msg/s\n"
            f"  Batches:     {STATS.batches_processed:,}\n"
            f"  Errors:      {STATS.errors}",
            title="Results",
            border_style="green",
        )
    )

    # Cleanup: delete demo queues and exchanges
    conn = await connect_robust(url, timeout=10)
    ch = await conn.channel()
    for name in exchange_names:
        queue_name = f"demo-source-{name.replace('.', '-')}"
        try:
            q = await ch.declare_queue(queue_name, durable=False, passive=True)  # pyright: ignore[reportCallIssue]
            await q.delete()
        except Exception:
            pass
        try:
            ex = await ch.declare_exchange(
                name, type=ExchangeType.FANOUT, durable=False, passive=True
            )  # pyright: ignore[reportCallIssue]
            await ex.delete()
        except Exception:
            pass
    try:
        q = await ch.declare_queue("demo-staging-writer", durable=False, passive=True)  # pyright: ignore[reportCallIssue]
        await q.delete()
    except Exception:
        pass
    try:
        ex = await ch.declare_exchange(
            STAGING_EXCHANGE, type=ExchangeType.FANOUT, durable=False, passive=True
        )  # pyright: ignore[reportCallIssue]
        await ex.delete()
    except Exception:
        pass
    await ch.close()
    await conn.close()


def main():
    parser = argparse.ArgumentParser(
        description="aio-pika-batch demo: Flood → Merge → Drain"
    )
    parser.add_argument(
        "--messages",
        type=int,
        default=5000,
        help="Total messages to publish (default: 5000)",
    )
    parser.add_argument(
        "--exchanges",
        type=int,
        default=5,
        help="Number of source exchanges (default: 5)",
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=4,
        help="Workers per consumer (default: 4)",
    )
    parser.add_argument(
        "--batch-size",
        type=int,
        default=50,
        help="Batch size (default: 50)",
    )
    parser.add_argument(
        "--url",
        type=str,
        default="amqp://guest:guest@localhost:5672/",
        help="RabbitMQ URL",
    )
    args = parser.parse_args()
    asyncio.run(run(args))


if __name__ == "__main__":
    main()
