# Changelog

## 0.1.0 (2026-04-15)

Initial release.

- `BatchConsumer` base class with size + timeout flushing
- `Consumer` base class for single-message processing
- `MessageResult` enum: ACK, NACK, REQUEUE, REQUEUE_IMMEDIATE
- Per-message acknowledgment within batches
- Retry tracking via `x-retry-count` header with configurable max attempts
- Dead-letter routing when retries are exhausted
- Multi-worker scaling with `num_workers`
- Automatic connection recovery with exponential backoff
- Graceful shutdown with batch draining
- Signal handling (SIGINT/SIGTERM)
- Async context manager support
- `on_start` / `on_stop` lifecycle hooks
- `is_healthy` / `is_running` health check properties
- pydantic-settings integration for configuration
- structlog for structured logging
