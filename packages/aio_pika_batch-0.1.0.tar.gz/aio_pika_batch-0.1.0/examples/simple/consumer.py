"""Simple single-message consumer example."""

import json

from aio_pika.abc import AbstractIncomingMessage

from aio_pika_batch import Consumer, ConsumerSettings, MessageResult


class LoggingConsumer(Consumer):
    """Logs every message it receives."""

    async def process_message(self, message: AbstractIncomingMessage) -> MessageResult:
        try:
            data = json.loads(message.body)
            print(f"Received: {data}")
            return MessageResult.ACK
        except json.JSONDecodeError:
            print(f"Bad JSON: {message.body!r}")
            return MessageResult.NACK


async def main():
    consumer = LoggingConsumer(
        ConsumerSettings(
            url="amqp://guest:guest@localhost:5672/",
            queue_name="example-simple",
            exchange_name="example-exchange",
            exchange_type="fanout",
        )
    )
    await consumer.run()


if __name__ == "__main__":
    import asyncio

    asyncio.run(main())
