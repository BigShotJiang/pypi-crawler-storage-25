"""RabbitMQ to Google Cloud Pub/Sub pipeline using aio-pika-batch.

This example demonstrates a real-world ingestor that:
1. Consumes from multiple RabbitMQ fanout exchanges
2. Wraps messages in a staging envelope with source metadata
3. Publishes to Google Cloud Pub/Sub concurrently
4. Handles per-message failures (ACK/REQUEUE)

Requires: pip install aio-pika-batch google-cloud-pubsub
"""

import asyncio
import json
import os

from aio_pika.abc import AbstractIncomingMessage
from google.cloud import pubsub_v1  # pyright: ignore[reportAttributeAccessIssue]

from aio_pika_batch import BatchConsumer, BatchConsumerSettings, MessageResult


class PubSubIngestor(BatchConsumer):
    """Ingests RabbitMQ messages and publishes to Pub/Sub."""

    def __init__(self, settings: BatchConsumerSettings):
        super().__init__(settings)
        self._publisher: pubsub_v1.PublisherClient | None = None
        self._topic_path: str = ""
        self._messages_published = 0

    async def on_start(self):
        project_id = os.environ["PUBSUB_PROJECT_ID"]
        topic_id = os.environ.get("PUBSUB_TOPIC_ID", "raw-events")

        self._publisher = pubsub_v1.PublisherClient()
        self._topic_path = self._publisher.topic_path(project_id, topic_id)  # pyright: ignore[reportOptionalMemberAccess]
        print(f"Pub/Sub publisher ready: {self._topic_path}")

    async def on_stop(self):
        if self._publisher:
            self._publisher.transport.close()

    async def process_messages(self, messages: list[AbstractIncomingMessage]):
        if not self._publisher:
            raise RuntimeError("Publisher not initialized")

        # Phase 1: Build payloads
        payloads: list[bytes | None] = []
        for msg in messages:
            try:
                raw_body = msg.body.decode("utf-8")
                try:
                    raw_payload = json.loads(raw_body)
                except json.JSONDecodeError:
                    raw_payload = raw_body

                envelope = {
                    "source_exchange": self.settings.exchange_name or "",
                    "raw_payload": raw_payload,
                }
                payloads.append(json.dumps(envelope).encode())
            except Exception:
                payloads.append(None)

        # Phase 2: Publish concurrently
        loop = asyncio.get_running_loop()
        futures = []
        for payload in payloads:
            if payload is not None:
                future = self._publisher.publish(self._topic_path, data=payload)
                futures.append(future)
            else:
                futures.append(None)

        # Phase 3: Resolve and yield results
        for future in futures:
            if future is None:
                yield MessageResult.NACK
            else:
                try:
                    await loop.run_in_executor(None, future.result, 30)
                    self._messages_published += 1
                    yield MessageResult.ACK
                except Exception:
                    yield MessageResult.REQUEUE


async def main():
    url = os.environ.get("RABBITMQ_URL", "amqp://guest:guest@localhost:5672/")
    exchanges = os.environ.get("EXCHANGES", "my-exchange").split(",")

    # Start one consumer per exchange
    consumers = []
    for exchange in exchanges:
        exchange = exchange.strip()
        queue_name = f"ingestor:{exchange.lower().replace('.', '-')}"

        consumer = PubSubIngestor(
            BatchConsumerSettings(
                url=url,
                queue_name=queue_name,
                exchange_name=exchange,
                exchange_type="fanout",
                batch_size=50,
                batch_timeout=2.0,
                prefetch_count=300,
                num_workers=6,
                max_requeue_attempts=5,
            )
        )
        consumers.append(consumer)

    # Start all consumers concurrently
    print(f"Starting {len(consumers)} consumers for exchanges: {exchanges}")
    await asyncio.gather(*[c.run() for c in consumers])


if __name__ == "__main__":
    asyncio.run(main())
