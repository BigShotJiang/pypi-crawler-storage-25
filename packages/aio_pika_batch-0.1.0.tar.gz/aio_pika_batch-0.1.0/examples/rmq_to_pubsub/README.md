# RabbitMQ to Google Cloud Pub/Sub Example

This example shows how to use `aio-pika-batch` to build a high-throughput
pipeline that ingests messages from RabbitMQ exchanges and publishes them to
Google Cloud Pub/Sub for downstream processing (e.g., Dataflow to BigQuery).

## Architecture

```
RabbitMQ Exchanges           Pub/Sub
┌──────────────┐         ┌─────────────────┐
│ exchange-1   │──┐      │                 │
│ exchange-2   │──┤      │  raw-events     │──→ Dataflow → BigQuery
│ exchange-N   │──┘      │  (topic)        │
└──────────────┘  │      └─────────────────┘
                  │              ▲
                  ▼              │
           ┌─────────────┐      │
           │ BatchConsumer│──────┘
           │ (50 msg/batch│
           │  6 workers)  │
           └──────────────┘
```

## Setup

```bash
pip install aio-pika-batch google-cloud-pubsub
```

## Configuration

Set environment variables:

```bash
export RABBITMQ_URL=amqp://guest:guest@localhost:5672/
export PUBSUB_PROJECT_ID=my-gcp-project
export PUBSUB_TOPIC_ID=raw-events
export EXCHANGES=exchange-1,exchange-2,exchange-3
```

## Run

```bash
python consumer.py
```
