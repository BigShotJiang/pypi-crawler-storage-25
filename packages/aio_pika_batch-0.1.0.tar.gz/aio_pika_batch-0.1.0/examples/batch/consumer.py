"""Batch consumer example with concurrent processing."""

import asyncio
import json

from aio_pika.abc import AbstractIncomingMessage

from aio_pika_batch import BatchConsumer, BatchConsumerSettings, MessageResult


class HttpPublisher(BatchConsumer):
    """Batch consumer that publishes messages to an HTTP endpoint concurrently."""

    async def on_start(self):
        # In real code, you'd create an aiohttp.ClientSession here
        print("Starting HTTP publisher")

    async def on_stop(self):
        print("Stopping HTTP publisher")

    async def process_messages(self, messages: list[AbstractIncomingMessage]):
        # Phase 1: Parse all messages
        payloads: list[dict | None] = []
        for msg in messages:
            try:
                payloads.append(json.loads(msg.body))
            except json.JSONDecodeError:
                payloads.append(None)

        # Phase 2: Publish valid ones concurrently
        async def publish(payload: dict | None) -> bool:
            if payload is None:
                return False
            # Simulate HTTP POST
            await asyncio.sleep(0.01)
            return True

        results = await asyncio.gather(
            *[publish(p) for p in payloads],
            return_exceptions=True,
        )

        # Phase 3: Yield results
        for result in results:
            if result is True:
                yield MessageResult.ACK
            elif isinstance(result, Exception):
                yield MessageResult.REQUEUE
            else:
                yield MessageResult.NACK


async def main():
    consumer = HttpPublisher(
        BatchConsumerSettings(
            url="amqp://guest:guest@localhost:5672/",
            queue_name="example-batch",
            exchange_name="example-exchange",
            exchange_type="fanout",
            batch_size=50,
            batch_timeout=2.0,
            prefetch_count=300,
            num_workers=4,
            max_requeue_attempts=5,
        )
    )
    await consumer.run()


if __name__ == "__main__":
    import asyncio

    asyncio.run(main())
