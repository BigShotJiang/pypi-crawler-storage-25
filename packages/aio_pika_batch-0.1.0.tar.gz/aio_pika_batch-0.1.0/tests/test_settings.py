"""Tests for consumer settings."""

import pytest
from pydantic import ValidationError

from aio_pika_batch.result import MessageResult
from aio_pika_batch.settings import BatchConsumerSettings, ConsumerSettings


def test_consumer_settings_defaults():
    settings = ConsumerSettings(queue_name="test-queue")
    assert settings.url == "amqp://guest:guest@localhost:5672/"
    assert settings.prefetch_count == 10
    assert settings.queue_name == "test-queue"
    assert settings.exchange_name is None
    assert settings.exchange_type == "direct"
    assert settings.routing_key is None
    assert settings.queue_durable is True
    assert settings.exchange_durable is True
    assert settings.queue_arguments is None
    assert settings.num_workers == 1
    assert settings.max_requeue_attempts == 3
    assert settings.unhandled_exception_action == MessageResult.REQUEUE


def test_consumer_settings_custom():
    settings = ConsumerSettings(
        url="amqp://user:pass@rabbitmq:5672/vhost",
        queue_name="my-queue",
        exchange_name="my-exchange",
        exchange_type="fanout",
        routing_key="my-key",
        prefetch_count=100,
        num_workers=4,
        max_requeue_attempts=5,
        unhandled_exception_action=MessageResult.NACK,
        queue_arguments={"x-message-ttl": 60000},
    )
    assert settings.url == "amqp://user:pass@rabbitmq:5672/vhost"
    assert settings.queue_name == "my-queue"
    assert settings.exchange_name == "my-exchange"
    assert settings.exchange_type == "fanout"
    assert settings.routing_key == "my-key"
    assert settings.prefetch_count == 100
    assert settings.num_workers == 4
    assert settings.max_requeue_attempts == 5
    assert settings.unhandled_exception_action == MessageResult.NACK
    assert settings.queue_arguments == {"x-message-ttl": 60000}


def test_batch_consumer_settings_defaults():
    settings = BatchConsumerSettings(queue_name="test-queue")
    assert settings.batch_size == 10
    assert settings.batch_timeout == 5.0
    # Inherits from ConsumerSettings
    assert settings.num_workers == 1
    assert settings.max_requeue_attempts == 3


def test_batch_consumer_settings_custom():
    settings = BatchConsumerSettings(
        queue_name="batch-queue",
        batch_size=50,
        batch_timeout=2.0,
        num_workers=6,
        prefetch_count=300,
    )
    assert settings.batch_size == 50
    assert settings.batch_timeout == 2.0
    assert settings.num_workers == 6
    assert settings.prefetch_count == 300


def test_queue_name_required():
    with pytest.raises(ValidationError):
        ConsumerSettings()  # type: ignore[call-arg]
