"""Tests for MessageResult enum."""

from aio_pika_batch.result import RETRY_COUNT_HEADER, MessageResult


def test_message_result_values():
    assert MessageResult.ACK.value == "ack"
    assert MessageResult.NACK.value == "nack"
    assert MessageResult.REQUEUE.value == "requeue"
    assert MessageResult.REQUEUE_IMMEDIATE.value == "requeue_immediate"


def test_retry_count_header():
    assert RETRY_COUNT_HEADER == "x-retry-count"


def test_message_result_is_enum():
    assert len(MessageResult) == 4
