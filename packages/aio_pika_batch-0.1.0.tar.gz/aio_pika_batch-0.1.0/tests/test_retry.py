"""Tests for retry tracking logic."""

from unittest.mock import AsyncMock, MagicMock

import pytest

from aio_pika_batch.result import RETRY_COUNT_HEADER, MessageResult
from aio_pika_batch.retry import get_retry_count, handle_message_result


class FakeMessage:
    """Minimal mock of AbstractIncomingMessage for unit tests."""

    def __init__(self, headers: dict | None = None):
        self.headers = headers
        self.body = b"test"
        self.content_type = "application/json"
        self.content_encoding = None
        self.delivery_mode = 2
        self.priority = None
        self.correlation_id = None
        self.reply_to = None
        self.expiration = None
        self.message_id = None
        self.timestamp = None
        self.type = None
        self.user_id = None
        self.app_id = None
        self.ack = AsyncMock()
        self.nack = AsyncMock()


# -- get_retry_count tests --


def test_retry_count_no_headers():
    msg = FakeMessage(headers=None)
    assert get_retry_count(msg) == 0  # type: ignore[arg-type]


def test_retry_count_missing_header():
    msg = FakeMessage(headers={"other": "value"})
    assert get_retry_count(msg) == 0  # type: ignore[arg-type]


def test_retry_count_int():
    msg = FakeMessage(headers={RETRY_COUNT_HEADER: 3})
    assert get_retry_count(msg) == 3  # type: ignore[arg-type]


def test_retry_count_str():
    msg = FakeMessage(headers={RETRY_COUNT_HEADER: "5"})
    assert get_retry_count(msg) == 5  # type: ignore[arg-type]


def test_retry_count_invalid():
    msg = FakeMessage(headers={RETRY_COUNT_HEADER: "not-a-number"})
    assert get_retry_count(msg) == 0  # type: ignore[arg-type]


def test_retry_count_none_value():
    msg = FakeMessage(headers={RETRY_COUNT_HEADER: None})
    assert get_retry_count(msg) == 0  # type: ignore[arg-type]


# -- handle_message_result tests --


@pytest.mark.asyncio
async def test_handle_ack():
    msg = FakeMessage()
    channel = MagicMock()
    await handle_message_result(
        channel=channel,
        message=msg,  # type: ignore[arg-type]
        result=MessageResult.ACK,
        queue_name="test",
        max_requeue_attempts=3,
    )
    msg.ack.assert_awaited_once()


@pytest.mark.asyncio
async def test_handle_nack():
    msg = FakeMessage()
    channel = MagicMock()
    await handle_message_result(
        channel=channel,
        message=msg,  # type: ignore[arg-type]
        result=MessageResult.NACK,
        queue_name="test",
        max_requeue_attempts=3,
    )
    msg.nack.assert_awaited_once_with(requeue=False)


@pytest.mark.asyncio
async def test_handle_requeue_immediate():
    msg = FakeMessage()
    channel = MagicMock()
    await handle_message_result(
        channel=channel,
        message=msg,  # type: ignore[arg-type]
        result=MessageResult.REQUEUE_IMMEDIATE,
        queue_name="test",
        max_requeue_attempts=3,
    )
    msg.nack.assert_awaited_once_with(requeue=True)


@pytest.mark.asyncio
async def test_handle_requeue_under_limit():
    """REQUEUE with retry_count < max should republish."""
    msg = FakeMessage(headers={RETRY_COUNT_HEADER: 1})

    channel = MagicMock()
    default_exchange = AsyncMock()
    channel.default_exchange = default_exchange

    await handle_message_result(
        channel=channel,
        message=msg,  # type: ignore[arg-type]
        result=MessageResult.REQUEUE,
        queue_name="test-queue",
        max_requeue_attempts=3,
    )

    # Should publish to default exchange and ack original
    default_exchange.publish.assert_awaited_once()
    msg.ack.assert_awaited_once()
    msg.nack.assert_not_awaited()


@pytest.mark.asyncio
async def test_handle_requeue_at_limit():
    """REQUEUE with retry_count >= max should nack to DLX."""
    msg = FakeMessage(headers={RETRY_COUNT_HEADER: 3})
    channel = MagicMock()

    await handle_message_result(
        channel=channel,
        message=msg,  # type: ignore[arg-type]
        result=MessageResult.REQUEUE,
        queue_name="test-queue",
        max_requeue_attempts=3,
    )

    # Should nack (send to DLX), not republish
    msg.nack.assert_awaited_once_with(requeue=False)
    msg.ack.assert_not_awaited()
