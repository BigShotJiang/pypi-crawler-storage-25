"""Integration tests for Consumer and BatchConsumer.

These tests require a running RabbitMQ instance (via testcontainers or local).
"""

import asyncio
import uuid

import pytest
from aio_pika import Channel, Message
from aio_pika.abc import AbstractIncomingMessage, AbstractRobustConnection

from aio_pika_batch import (
    BatchConsumer,
    BatchConsumerSettings,
    Consumer,
    ConsumerSettings,
    MessageResult,
)

# -- Single Message Consumer --


class AckConsumer(Consumer):
    """Test consumer that ACKs everything and records messages."""

    def __init__(self, settings: ConsumerSettings):
        super().__init__(settings)
        self.received: list[bytes] = []

    async def process_message(self, message: AbstractIncomingMessage) -> MessageResult:
        self.received.append(message.body)
        return MessageResult.ACK


class NackConsumer(Consumer):
    """Test consumer that NACKs everything."""

    async def process_message(self, message: AbstractIncomingMessage) -> MessageResult:
        return MessageResult.NACK


class ErrorConsumer(Consumer):
    """Test consumer that raises on every message."""

    async def process_message(self, message: AbstractIncomingMessage) -> MessageResult:
        raise RuntimeError("boom")


# -- Batch Consumer --


class AckBatchConsumer(BatchConsumer):
    """Test batch consumer that ACKs everything."""

    def __init__(self, settings: BatchConsumerSettings):
        super().__init__(settings)
        self.batches: list[list[bytes]] = []

    async def process_messages(self, messages: list[AbstractIncomingMessage]):
        batch_bodies = []
        for msg in messages:
            batch_bodies.append(msg.body)
            yield MessageResult.ACK
        self.batches.append(batch_bodies)


class MixedResultBatchConsumer(BatchConsumer):
    """Test batch consumer that ACKs even messages, NACKs odd."""

    def __init__(self, settings: BatchConsumerSettings):
        super().__init__(settings)
        self.processed_count = 0

    async def process_messages(self, messages: list[AbstractIncomingMessage]):
        for i, _msg in enumerate(messages):
            self.processed_count += 1
            if i % 2 == 0:
                yield MessageResult.ACK
            else:
                yield MessageResult.NACK


class ErrorBatchConsumer(BatchConsumer):
    """Batch consumer that errors after first message."""

    async def process_messages(self, messages: list[AbstractIncomingMessage]):
        yield MessageResult.ACK  # First message succeeds
        raise RuntimeError("batch boom")


# -- Helper --


async def publish_messages(
    channel: Channel, queue_name: str, count: int, prefix: str = "msg"
) -> list[str]:
    """Publish N messages and return their bodies."""
    bodies = []
    for i in range(count):
        body = f"{prefix}-{i}"
        await channel.default_exchange.publish(
            Message(body=body.encode()),
            routing_key=queue_name,
        )
        bodies.append(body)
    return bodies


def unique_queue() -> str:
    """Generate a unique queue name for test isolation."""
    return f"test-{uuid.uuid4().hex[:8]}"


# -- Integration Tests --


@pytest.mark.asyncio
async def test_single_consumer_ack(
    connection: AbstractRobustConnection, channel: Channel, rabbitmq_url: str
):
    """Single consumer should ACK and remove messages."""
    queue_name = unique_queue()

    # Declare queue and publish
    await channel.declare_queue(queue_name, durable=True)
    await publish_messages(channel, queue_name, 3)

    settings = ConsumerSettings(url=rabbitmq_url, queue_name=queue_name)
    consumer = AckConsumer(settings)

    # Run consumer with a timeout
    async def run_and_stop():
        await asyncio.sleep(1.0)
        await consumer.stop()

    stopper = asyncio.create_task(run_and_stop())
    await consumer.start()
    await stopper

    assert len(consumer.received) == 3

    # Queue should be empty
    declared = await channel.declare_queue(queue_name, durable=True, passive=True)  # pyright: ignore[reportCallIssue]
    assert declared.declaration_result.message_count == 0  # pyright: ignore[reportOptionalMemberAccess]


@pytest.mark.asyncio
async def test_batch_consumer_size_flush(
    connection: AbstractRobustConnection, channel: Channel, rabbitmq_url: str
):
    """Batch consumer should flush when batch_size is reached."""
    queue_name = unique_queue()

    await channel.declare_queue(queue_name, durable=True)
    await publish_messages(channel, queue_name, 5)

    settings = BatchConsumerSettings(
        url=rabbitmq_url,
        queue_name=queue_name,
        batch_size=5,
        batch_timeout=10.0,  # High timeout — should flush by size
    )
    consumer = AckBatchConsumer(settings)

    async def run_and_stop():
        await asyncio.sleep(1.5)
        await consumer.stop()

    stopper = asyncio.create_task(run_and_stop())
    await consumer.start()
    await stopper

    assert len(consumer.batches) >= 1
    total = sum(len(b) for b in consumer.batches)
    assert total == 5


@pytest.mark.asyncio
async def test_batch_consumer_timeout_flush(
    connection: AbstractRobustConnection, channel: Channel, rabbitmq_url: str
):
    """Batch consumer should flush on timeout for incomplete batches."""
    queue_name = unique_queue()

    await channel.declare_queue(queue_name, durable=True)
    await publish_messages(channel, queue_name, 2)

    settings = BatchConsumerSettings(
        url=rabbitmq_url,
        queue_name=queue_name,
        batch_size=100,  # High batch size — should flush by timeout
        batch_timeout=0.5,
    )
    consumer = AckBatchConsumer(settings)

    async def run_and_stop():
        await asyncio.sleep(2.0)
        await consumer.stop()

    stopper = asyncio.create_task(run_and_stop())
    await consumer.start()
    await stopper

    assert len(consumer.batches) >= 1
    total = sum(len(b) for b in consumer.batches)
    assert total == 2


@pytest.mark.asyncio
async def test_batch_consumer_mixed_results(
    connection: AbstractRobustConnection, channel: Channel, rabbitmq_url: str
):
    """Batch consumer should handle mixed ACK/NACK in same batch."""
    queue_name = unique_queue()

    await channel.declare_queue(queue_name, durable=True)
    await publish_messages(channel, queue_name, 4)

    settings = BatchConsumerSettings(
        url=rabbitmq_url,
        queue_name=queue_name,
        batch_size=4,
        batch_timeout=10.0,
    )
    consumer = MixedResultBatchConsumer(settings)

    async def run_and_stop():
        await asyncio.sleep(1.5)
        await consumer.stop()

    stopper = asyncio.create_task(run_and_stop())
    await consumer.start()
    await stopper

    assert consumer.processed_count == 4


@pytest.mark.asyncio
async def test_batch_consumer_exception_handling(
    connection: AbstractRobustConnection, channel: Channel, rabbitmq_url: str
):
    """Unhandled exception should apply default action to remaining messages."""
    queue_name = unique_queue()

    await channel.declare_queue(queue_name, durable=True)
    await publish_messages(channel, queue_name, 3)

    settings = BatchConsumerSettings(
        url=rabbitmq_url,
        queue_name=queue_name,
        batch_size=3,
        batch_timeout=10.0,
        unhandled_exception_action=MessageResult.NACK,
    )
    consumer = ErrorBatchConsumer(settings)

    async def run_and_stop():
        await asyncio.sleep(1.5)
        await consumer.stop()

    stopper = asyncio.create_task(run_and_stop())
    await consumer.start()
    await stopper

    # First was ACKed, rest were NACKed — queue should be empty (NACKed messages
    # go to DLX or are discarded when no DLX is configured)
    declared = await channel.declare_queue(queue_name, durable=True, passive=True)  # pyright: ignore[reportCallIssue]
    assert declared.declaration_result.message_count == 0  # pyright: ignore[reportOptionalMemberAccess]


@pytest.mark.asyncio
async def test_consumer_nack(
    connection: AbstractRobustConnection, channel: Channel, rabbitmq_url: str
):
    """NACKed messages should be removed from queue (no DLX configured)."""
    queue_name = unique_queue()

    await channel.declare_queue(queue_name, durable=True)
    await publish_messages(channel, queue_name, 2)

    settings = ConsumerSettings(url=rabbitmq_url, queue_name=queue_name)
    consumer = NackConsumer(settings)

    async def run_and_stop():
        await asyncio.sleep(1.0)
        await consumer.stop()

    stopper = asyncio.create_task(run_and_stop())
    await consumer.start()
    await stopper

    declared = await channel.declare_queue(queue_name, durable=True, passive=True)  # pyright: ignore[reportCallIssue]
    assert declared.declaration_result.message_count == 0  # pyright: ignore[reportOptionalMemberAccess]
