"""Test fixtures for aio-pika-batch tests."""

from collections.abc import AsyncIterator

import pytest
import pytest_asyncio
from aio_pika import Channel, connect_robust
from aio_pika.abc import AbstractRobustConnection


def get_rabbitmq_url() -> str:
    """Get RabbitMQ URL, using testcontainers if available."""
    try:
        from testcontainers.rabbitmq import (
            RabbitMqContainer,  # pyright: ignore[reportMissingImports]
        )

        container = RabbitMqContainer("rabbitmq:3.13-management-alpine")
        container.start()

        # Store container reference so it doesn't get garbage collected
        get_rabbitmq_url._container = container  # type: ignore[attr-defined]

        host = container.get_container_host_ip()
        port = container.get_exposed_port(5672)
        return f"amqp://guest:guest@{host}:{port}/"

    except (ImportError, Exception):
        # Fall back to local RabbitMQ (Docker not available or testcontainers failed)
        return "amqp://guest:guest@localhost:5672/"


# Module-scoped URL so we only start one container
RABBITMQ_URL = get_rabbitmq_url()


@pytest_asyncio.fixture
async def connection() -> AsyncIterator[AbstractRobustConnection]:
    """Create a fresh RabbitMQ connection for each test."""
    conn = await connect_robust(RABBITMQ_URL, timeout=10)
    yield conn
    if not conn.is_closed:
        await conn.close()


@pytest_asyncio.fixture
async def channel(connection: AbstractRobustConnection) -> AsyncIterator[Channel]:  # pyright: ignore[reportReturnType]
    """Create a fresh channel for each test."""
    ch = await connection.channel()  # pyright: ignore[reportAssignmentType]
    await ch.set_qos(prefetch_count=10)  # pyright: ignore[reportOptionalMemberAccess]
    yield ch  # pyright: ignore[reportReturnType]
    if not ch.is_closed:  # pyright: ignore[reportOptionalMemberAccess]
        await ch.close()  # pyright: ignore[reportOptionalMemberAccess]


@pytest.fixture
def rabbitmq_url() -> str:
    """Return the RabbitMQ URL for settings."""
    return RABBITMQ_URL
