#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-04-13
################################################################

import os, traceback
import numpy as np
from dora import Node
from hex_util_runtime import get_dora_node_name, get_dora_bool
from hex_driver_robot import HexRobotHelloY6, HexRobotHelloY6Params

from .util import dict_encode, dict_decode


def main():
    node_name = get_dora_node_name(os.getenv('NODE_NAME', ""))
    params = HexRobotHelloY6Params(
        host=os.getenv('HOST', '192.168.1.100'),
        port=int(os.getenv('PORT', '8439')),
        ctrl_rate=float(os.getenv('CTRL_RATE', '1000')),
        state_buffer_size=int(os.getenv('STATE_BUFFER_SIZE', '200')),
        sens_ts=get_dora_bool(os.getenv('SEN_TS', 'True')),
        led_buffer_size=int(os.getenv('LED_BUFFER_SIZE', '10')),
    )
    robot = None
    try:
        robot = HexRobotHelloY6(params)
        robot.start()

        node = Node(node_name)
        for event in node:
            if event["type"] == "INPUT":
                event_id = event["id"]

                if event_id == "tick":
                    arm_motor = robot.get_arm_motor(latest=True)
                    if arm_motor is not None:
                        storage, metadata = dict_encode(
                            ["pos", "vel"],
                            arm_motor,
                            event["metadata"],
                        )
                        node.send_output("arm_motor", storage, metadata)

                    grip_motor = robot.get_grip_motor(latest=True)
                    if grip_motor is not None:
                        storage, metadata = dict_encode(
                            {
                                "pos": grip_motor["pos"],
                            },
                            event["metadata"],
                        )
                        node.send_output("grip_motor", storage, metadata)

                elif event_id == "grip_led_cmd":
                    cmd = dict_decode(event["value"], event["metadata"])
                    cmd["r"] = cmd["r"].astype(np.int64)
                    cmd["g"] = cmd["g"].astype(np.int64)
                    cmd["b"] = cmd["b"].astype(np.int64)
                    robot.set_grip_led_cmd(cmd)

            elif event["type"] == "ERROR":
                raise RuntimeError(event["error"])

    except Exception:
        traceback.print_exc()
    finally:
        if robot is not None:
            robot.stop()
            robot.deinit_robot()
