#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-04-13
################################################################

import os, traceback
import numpy as np
from dora import Node
from hex_util_runtime import get_dora_node_name, get_dora_bool
from hex_driver_robot import HexRobotArcherY6, HexRobotArcherY6Params

from .util import dict_encode, dict_decode


def main():
    node_name = get_dora_node_name(os.getenv('NODE_NAME', ""))
    params = HexRobotArcherY6Params(
        host=os.getenv('HOST', '192.168.1.100'),
        port=int(os.getenv('PORT', '8439')),
        ctrl_rate=float(os.getenv('CTRL_RATE', '1000')),
        state_buffer_size=int(os.getenv('STATE_BUFFER_SIZE', '200')),
        sens_ts=get_dora_bool(os.getenv('SEN_TS', 'True')),
        grip_type=os.getenv('GRIP_TYPE', 'gp80'),
        pose_end_in_flange=np.fromstring(
            os.getenv('POSE_END_IN_FLANGE',
                       '0.187,0.0,0.0,1.0,0.0,0.0,0.0'),
            sep=',',
        ),
    )
    robot = None
    try:
        robot = HexRobotArcherY6(params)
        robot.start()
        dofs = robot.get_dofs()
        grip_dof = dofs["grip"]

        node = Node(node_name)
        for event in node:
            if event["type"] == "INPUT":
                event_id = event["id"]

                if event_id == "tick":
                    arm_motor = robot.get_arm_motor(latest=True)
                    if arm_motor is not None:
                        storage, metadata = dict_encode(
                            {
                                "pos": arm_motor["pos"],
                                "vel": arm_motor["vel"],
                                "eff": arm_motor["eff"],
                            },
                            event["metadata"],
                        )
                        node.send_output("arm_motor", storage, metadata)

                    arm_end = robot.get_arm_end(latest=True)
                    if arm_end is not None:
                        storage, metadata = dict_encode(
                            {
                                "pos": arm_end["pos"],
                                "quat": arm_end["quat"],
                            },
                            event["metadata"],
                        )
                        node.send_output("arm_end", storage, metadata)

                    if grip_dof > 0:
                        grip_motor = robot.get_grip_motor(latest=True)
                        if grip_motor is not None:
                            storage, metadata = dict_encode(
                                {
                                    "pos": grip_motor["pos"],
                                    "vel": grip_motor["vel"],
                                    "eff": grip_motor["eff"],
                                },
                                event["metadata"],
                            )
                            node.send_output("grip_motor", storage, metadata)

                elif event_id == "arm_mit_cmd":
                    cmd = dict_decode(event["value"], event["metadata"])
                    robot.set_arm_mit_cmd(cmd)

                elif event_id == "arm_mit_comp_cmd":
                    cmd = dict_decode(event["value"], event["metadata"])
                    robot.set_arm_mit_comp_cmd(cmd)

                elif event_id == "arm_pos_cmd":
                    cmd = dict_decode(event["value"], event["metadata"])
                    robot.set_arm_pos_cmd(cmd)

                elif event_id == "arm_pose_cmd":
                    cmd = dict_decode(event["value"], event["metadata"])
                    robot.set_arm_pose_cmd(cmd)

                elif event_id == "grip_mit_cmd":
                    cmd = dict_decode(event["value"], event["metadata"])
                    robot.set_grip_mit_cmd(cmd)

                elif event_id == "grip_mit_comp_cmd":
                    cmd = dict_decode(event["value"], event["metadata"])
                    robot.set_grip_mit_comp_cmd(cmd)

                elif event_id == "grip_pos_cmd":
                    cmd = dict_decode(event["value"], event["metadata"])
                    robot.set_grip_pos_cmd(cmd)

            elif event["type"] == "ERROR":
                raise RuntimeError(event["error"])

    except Exception:
        traceback.print_exc()
    finally:
        if robot is not None:
            robot.stop()
            robot.deinit_robot()
