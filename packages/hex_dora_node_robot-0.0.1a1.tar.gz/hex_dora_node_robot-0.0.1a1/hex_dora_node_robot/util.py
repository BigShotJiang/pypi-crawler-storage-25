#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-04-13
################################################################

import numpy as np
import pyarrow as pa


def dict_encode(keys, data_dict, metadata):
    metadata.pop("timestamp", None)
    metadata["fields"] = ",".join(keys)

    parts = []
    for key in keys:
        val = np.atleast_1d(np.asarray(data_dict[key],
                                       dtype=np.float64)).ravel()
        parts.append(val)
        metadata[key] = str(len(val))

    storage = pa.array(np.concatenate(parts))
    return storage, metadata


def dict_decode(storage, metadata):
    data = storage.to_numpy().astype(np.float64)
    fields = metadata["fields"].split(",")
    result = {}
    offset = 0
    for f in fields:
        size = int(metadata[f])
        result[f] = data[offset:offset + size] if size > 1 else data[offset]
        offset += size
    return result
