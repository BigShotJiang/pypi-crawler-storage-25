"""SPARQL client for HM Land Registry Open Data endpoints.

Handles query construction, pagination via LIMIT/OFFSET, timeout enforcement,
and graceful error handling for the Price Paid Data and UKHPI SPARQL endpoints.
"""

from __future__ import annotations

import time
from typing import Any

import httpx


class SPARQLError(Exception):
    """Base exception for SPARQL client errors."""


class SPARQLTimeoutError(SPARQLError):
    """Raised when a SPARQL query times out."""


class SPARQLQueryError(SPARQLError):
    """Raised when the SPARQL endpoint returns an error response."""


DEFAULT_ENDPOINT = "http://landregistry.data.gov.uk/landregistry/query"
DEFAULT_TIMEOUT_SECONDS = 30
DEFAULT_BACKOFF_SECONDS = 1.0
DEFAULT_MAX_RESULTS = 1000


class SPARQLClient:
    """Minimal SPARQL client for HM Land Registry Open Data.

    Sends SPARQL SELECT queries via HTTP GET, handles pagination via
    LIMIT/OFFSET, enforces a per-request timeout, and applies backoff
    between consecutive requests.
    """

    def __init__(
        self,
        endpoint: str = DEFAULT_ENDPOINT,
        timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS,
        backoff_seconds: float = DEFAULT_BACKOFF_SECONDS,
        http_client: httpx.Client | None = None,
    ) -> None:
        self._endpoint = endpoint
        self._timeout = timeout_seconds
        self._backoff = backoff_seconds
        self._last_request_time: float = 0.0
        self._client = http_client or httpx.Client(
            headers={"Accept": "application/sparql-results+json"},
            timeout=timeout_seconds,
        )

    def _throttle(self) -> None:
        elapsed = time.monotonic() - self._last_request_time
        if elapsed < self._backoff:
            time.sleep(self._backoff - elapsed)

    def query(self, sparql: str) -> list[dict[str, Any]]:
        """Execute a SPARQL SELECT query and return the result rows.

        Returns a list of dicts mapping variable name → raw value string.
        Raises SPARQLTimeoutError on timeout, SPARQLQueryError on endpoint error.
        """
        self._throttle()
        try:
            response = self._client.get(
                self._endpoint,
                params={"query": sparql, "output": "json"},
            )
        except httpx.TimeoutException as exc:
            raise SPARQLTimeoutError(
                "Query timeout — try with more specific filters"
            ) from exc
        finally:
            self._last_request_time = time.monotonic()

        if response.status_code != 200:
            raise SPARQLQueryError(
                f"SPARQL endpoint returned HTTP {response.status_code}: {response.text[:200]}"
            )

        try:
            body = response.json()
        except Exception as exc:
            raise SPARQLQueryError(f"Malformed SPARQL response: {exc}") from exc

        bindings = body.get("results", {}).get("bindings", [])
        return [
            {k: v.get("value", "") for k, v in row.items()}
            for row in bindings
        ]

    def query_paginated(
        self,
        sparql_template: str,
        limit: int,
        max_results: int = DEFAULT_MAX_RESULTS,
    ) -> list[dict[str, Any]]:
        """Execute a SPARQL query with LIMIT/OFFSET pagination.

        `sparql_template` must contain ``__LIMIT__`` and ``__OFFSET__`` as literal
        placeholder strings (not Python format syntax). SPARQL's own ``{}`` block
        delimiters are preserved safely.

        Fetches pages until fewer than `limit` rows are returned or `max_results` is reached.
        """
        results: list[dict[str, Any]] = []
        offset = 0

        while True:
            page_sparql = (
                sparql_template
                .replace("__LIMIT__", str(limit))
                .replace("__OFFSET__", str(offset))
            )
            page = self.query(page_sparql)
            results.extend(page)

            if len(page) < limit or len(results) >= max_results:
                break

            offset += limit

        return results[:max_results]

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> SPARQLClient:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()
