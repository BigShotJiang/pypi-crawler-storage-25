"""Shared serve-layer helpers for Bartram Foundry MCP tools.

Eliminates boilerplate that was duplicated across every tool package's serve.py:
- Response envelope formatting (JSON with metadata)
- Error formatting (JSON with attribution)
- Metric recording (timing + success/failure to MetricsStore)

Each tool package creates a ToolServerConfig with its source-specific values
and passes it to these functions. Tool registration (@server.tool decorators),
docstrings, parameter signatures, and client init stay in each serve.py.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Callable

from bartram_foundry.monitoring import MetricsStore


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ToolServerConfig:
    """Source-specific values that differ between tool packages.

    Each serve.py creates one instance and passes it to the shared helpers.
    """

    source_name: str
    """Human-readable data source name, e.g. 'Companies House Public Data API'."""

    licence: str
    """Short licence identifier, e.g. 'Open Government Licence v3'."""

    attribution: str
    """Full attribution string included in every response."""


# ---------------------------------------------------------------------------
# Response formatting
# ---------------------------------------------------------------------------


def format_response(
    config: ToolServerConfig,
    data: Any,
    *,
    endpoint: str,
    cached: bool = False,
) -> str:
    """Format a cleaned API response as a JSON string with metadata envelope.

    Returns a JSON object with 'data' and 'metadata' keys. The metadata
    includes source, licence, retrieval timestamp, endpoint, cache status,
    and attribution.
    """
    envelope = {
        "data": data,
        "metadata": {
            "source": config.source_name,
            "licence": config.licence,
            "retrieved_at": datetime.now(tz=timezone.utc).isoformat(),
            "endpoint": endpoint,
            "cached": cached,
            "attribution": config.attribution,
        },
    }
    return json.dumps(envelope, indent=2, default=str)


def format_error(
    config: ToolServerConfig,
    error: Exception,
    *,
    error_type_fn: Callable[[Exception], str] | None = None,
    status_code: int | None = None,
) -> str:
    """Format an API error as a JSON string with attribution.

    Args:
        config: The tool server config for attribution.
        error: The exception to format.
        error_type_fn: Optional callback that maps the exception to a short
            error type string (e.g. 'not_found', 'rate_limited'). If not
            provided, uses the exception class name.
        status_code: Optional HTTP status code. If the error object has a
            `status_code` or `fca_status_code` attribute, those are used
            as fallbacks.
    """
    error_type = error_type_fn(error) if error_type_fn else type(error).__name__

    result: dict[str, Any] = {
        "error": error_type,
        "message": str(error),
        "attribution": config.attribution,
    }

    # Resolve status code: explicit arg > error.status_code > error.fca_status_code
    code = status_code
    if code is None:
        code = getattr(error, "status_code", None)
    if code is None:
        code = getattr(error, "fca_status_code", None)
    if code is not None:
        result["status_code"] = code

    return json.dumps(result)


# ---------------------------------------------------------------------------
# Metric recording
# ---------------------------------------------------------------------------


def record_call(
    metrics: MetricsStore,
    tool_name: str,
    start: float,
    *,
    success: bool,
    error: Exception | None = None,
) -> str | None:
    """Record a tool call metric to the monitoring store.

    Args:
        metrics: The MetricsStore instance.
        tool_name: Name of the tool that was called.
        start: The value of time.monotonic() when the call started.
        success: Whether the call succeeded.
        error: The exception, if the call failed.

    Returns:
        None. (Signature returns str | None for forward compat.)
    """
    duration_ms = (time.monotonic() - start) * 1000
    metrics.record_call(
        tool_name,
        duration_ms,
        success=success,
        error_type=type(error).__name__ if error else None,
        error_message=str(error)[:500] if error else None,
    )
    return None
