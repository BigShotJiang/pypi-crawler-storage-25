# Schema Reference — Environment Agency Open Data

Complete tool reference for the UK Environment Agency MCP server. Each tool follows the `access -> clean -> serve` pattern: raw API data is fetched, cleaned, and returned in a consistent envelope.

## Response envelope

Every successful response wraps data in this structure:

```json
{
  "data": { ... },
  "metadata": {
    "source": "Environment Agency Open Data",
    "licence": "Open Government Licence v3",
    "retrieved_at": "2026-04-05T10:00:00+00:00",
    "endpoint": "/flood-monitoring/id/floods",
    "cached": false,
    "attribution": "Contains Environment Agency information ... Licensed under the Open Government Licence v3.0."
  }
}
```

Error responses:

```json
{
  "error": "not_found",
  "message": "No permit found with number XYZ",
  "attribution": "Contains Environment Agency information ...",
  "status_code": 404
}
```

Note: Permit endpoints use `"licence": "EA Conditional Licence"` instead of OGL v3.

---

## uk_environment_agency_flood_warnings

Get current flood warnings and alerts for a location or area.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `location` | string | no | — | Location name (used as county search if county not given) |
| `county` | string | no | — | County name to filter warnings |
| `latitude` | float | no | — | Latitude for geographic search |
| `longitude` | float | no | — | Longitude for geographic search |
| `radius_km` | float | no | 5 | Search radius in km (with lat/long) |
| `min_severity` | int | no | — | Minimum severity: 1=Severe, 2=Warning, 3=Alert, 4=No Longer In Force |

At least one of `location`, `county`, or `latitude`+`longitude` is required.

### Returns

`data` contains `total_results` and `items` array. Each item includes `warning_id`, `description`, `severity`, `severity_code`, `issued_at`, `guidance`, and flood area details.

### Cleaning applied

- Severity codes (1-4) mapped to human-readable labels.
- Date fields normalised to ISO 8601.
- `_cleaning` annotations with `severity_mapped` flag.

### Example call

```json
{"name": "uk_environment_agency_flood_warnings", "arguments": {"county": "Somerset"}}
```

---

## uk_environment_agency_flood_areas

Get flood risk areas for property due diligence and risk assessment.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `search` | string | no | — | Search by area name or location (client-side filter) |

### Returns

`data` contains `total_results` and `items` array. Each item includes `area_id`, `area_name`, `centroid_latitude`, `centroid_longitude`, county, and river/sea details.

### Cleaning applied

- Area metadata extracted and normalised.
- Centroid coordinates extracted from flood area definition.
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_environment_agency_flood_areas", "arguments": {"search": "Thames"}}
```

---

## uk_environment_agency_flood_stations

Search flood monitoring stations near a location.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `latitude` | float | no | — | Latitude for geographic search |
| `longitude` | float | no | — | Longitude for geographic search |
| `radius_km` | float | no | 5 | Search radius in km |
| `parameter` | string | no | — | Measurement type: `waterLevel`, `rainfall`, `tideLevel` |
| `active_only` | bool | no | true | Only return active stations |

### Returns

`data` contains `total_results` and `items` array. Each item includes `station_id`, `station_name`, `latitude`, `longitude`, `status`, measurement types, and `links` to readings.

### Cleaning applied

- Station status values normalised and interpreted.
- Measurement parameters extracted and grouped.
- Links to readings endpoint provided.
- `_cleaning` annotations with `status_interpreted` flag.

### Example call

```json
{"name": "uk_environment_agency_flood_stations", "arguments": {"latitude": 51.5, "longitude": -0.1, "parameter": "waterLevel"}}
```

---

## uk_environment_agency_station_readings

Get recent readings (water level, rainfall, tidal) for a monitoring station.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `station_id` | string | yes | — | Station ID from the `flood_stations` tool |
| `limit` | int | no | 100 | Max readings to return (max 1000) |
| `since` | string | no | — | ISO 8601 datetime — only return readings after this time |

### Returns

`data` contains `total_readings` and `readings` array. Each reading includes `value`, `timestamp`, and measurement metadata.

### Cleaning applied

- Missing values detected and flagged with `has_missing_values` and `missing_indices`.
- Timestamps normalised to ISO 8601.
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_environment_agency_station_readings", "arguments": {"station_id": "531118", "limit": 50}}
```

---

## uk_environment_agency_water_quality_sites

Search water quality sampling points near a location.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `latitude` | float | no | — | Latitude for geographic search |
| `longitude` | float | no | — | Longitude for geographic search |
| `radius_km` | float | no | 5 | Search radius in km |
| `area` | string | no | — | EA area name (e.g. Thames, Severn) |

### Returns

`data` contains `total_results` and `items` array. Each item includes `sampling_point_id`, `sampling_point_name`, `region`, `easting`, `northing`, and links to measurements.

### Cleaning applied

- WKT POINT geometry parsed to easting/northing coordinates.
- Region and area fields extracted.
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_environment_agency_water_quality_sites", "arguments": {"latitude": 51.5, "longitude": -0.1}}
```

---

## uk_environment_agency_water_quality_results

Get water quality measurements (pH, dissolved oxygen, nitrates, etc.) for a sampling point.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `sampling_point_id` | string | yes | — | ID from the `water_quality_sites` tool |
| `determinand` | string | no | — | Specific measurement type (e.g. pH, Dissolved Oxygen, Nitrate) |
| `year` | int | no | — | Filter to a specific year (YYYY) |

### Returns

`data` contains `total_results` and `measurements` array. Each measurement includes `determinand`, `value`, `unit`, `measurement_date`, and compliance information.

### Cleaning applied

- Unit values handled whether string or dict (`hasUnit` format variation).
- Determinand names title-cased for consistency.
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_environment_agency_water_quality_results", "arguments": {"sampling_point_id": "SW-50840264", "determinand": "pH"}}
```

---

## uk_environment_agency_bathing_water

Get bathing water quality classifications for UK beaches and swimming areas.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `search` | string | no | — | Search by beach or area name |
| `year` | int | no | — | Classification year |

### Returns

`data` contains `total_results` and `items` array. Each item includes `name`, `notation`, coordinates, and classification data.

### Cleaning applied

- Classification codes (E/G/S/P) mapped to Excellent/Good/Sufficient/Poor.
- `_cleaning` annotations.

Note: This endpoint is currently returning 403 from EA infrastructure. The tool is built to the documented spec and will work when the service returns.

### Example call

```json
{"name": "uk_environment_agency_bathing_water", "arguments": {"search": "Brighton"}}
```

---

## uk_environment_agency_permits_search

Search environmental permits by company or location.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `company_name` | string | no | — | Company name to search for |
| `postcode` | string | no | — | Postcode to filter by |
| `permit_type` | string | no | — | Permit type: `waste`, `installations`, `water-discharge`, `abstraction` |

At least one of `company_name`, `postcode`, or `permit_type` is required.

### Returns

`data` contains `total_results` and `items` array. Each item includes `permit_number`, `permit_status`, `company_name`, permit type, and location details.

### Cleaning applied

- Permit status codes (A/R/V/S) decoded to Active/Revoked/Varied/Surrendered.
- Permit type determined from register label.
- Company names and postcodes normalised.
- `_cleaning` annotations with `licence: "EA Conditional Licence"`.

Note: Permit data is under EA Conditional Licence, not OGL v3.

### Example call

```json
{"name": "uk_environment_agency_permits_search", "arguments": {"company_name": "Thames Water"}}
```

---

## uk_environment_agency_permit_detail

Get full details of a specific environmental permit.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `permit_number` | string | yes | — | Permit reference number |

### Returns

`data` contains the permit's full details including `permit_number`, `company_name`, conditions, compliance history, and location.

### Cleaning applied

- Permit status decoded.
- Address and postcode normalised.
- `_cleaning` annotations with `licence: "EA Conditional Licence"`.

Note: Uses a two-step lookup (search then fetch), so some permits may not be found via cross-register search.

### Example call

```json
{"name": "uk_environment_agency_permit_detail", "arguments": {"permit_number": "EAWML65588"}}
```

---

## uk_environment_agency_catchment

Get Water Framework Directive catchment and waterbody classification data.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `search` | string | no | — | Search by catchment or waterbody name |
| `latitude` | float | no | — | Latitude (for future use) |
| `longitude` | float | no | — | Longitude (for future use) |

### Returns

`data` contains `total_results` and `items` array. Each item includes `waterbody_id`, `waterbody_name`, `management_catchment`, `operational_catchment`, `river_basin_district`, WFD classifications (overall, ecological, chemical), and management plan links.

### Cleaning applied

- CSV rows grouped by Water Body ID.
- Most recent overall classification extracted per waterbody.
- WFD classification codes (H/G/M/P/B) mapped to High/Good/Moderate/Poor/Bad.
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_environment_agency_catchment", "arguments": {"search": "Thames"}}
```
