#!/usr/bin/env python3
"""Stage 8 validation: run every EA tool against the live Environment Agency API.

Usage:
    python scripts/validate_live_ea.py

No API key required — Environment Agency data is public.
Tests all 10 tools with real data and verifies output matches the Tool Spec:
- Input handling (validation, error messages)
- Data retrieval (correct endpoints, caching)
- Data cleaning (annotations present and correct)
- Edge cases (empty results, invalid params)
- Response metadata (source, licence, attribution)
"""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from bartram_environment_agency import serve

# Test data — real locations to exercise all code paths
TEST_COUNTY = "Somerset"
TEST_LATITUDE = 51.3811
TEST_LONGITUDE = -2.3590  # Bath area
TEST_STATION_ID = "531118"  # A known station
TEST_SAMPLING_POINT = "SW-50840264"  # A known sampling point
TEST_COMPANY_NAME = "Thames Water"
TEST_PERMIT_NUMBER = "EAWML65588"

PASS = "PASS"
FAIL = "FAIL"
SKIP = "SKIP"


class ValidationReport:
    def __init__(self) -> None:
        self.results: list[dict] = []

    def add(self, tool: str, test: str, status: str, detail: str = "") -> None:
        self.results.append({
            "tool": tool, "test": test, "status": status, "detail": detail,
        })
        symbol = {"PASS": "+", "FAIL": "!", "SKIP": "-"}[status]
        print(f"  [{symbol}] {tool}: {test}" + (f" — {detail}" if detail else ""))

    def summary(self) -> None:
        total = len(self.results)
        passed = sum(1 for r in self.results if r["status"] == PASS)
        failed = sum(1 for r in self.results if r["status"] == FAIL)
        skipped = sum(1 for r in self.results if r["status"] == SKIP)
        print()
        print("=" * 60)
        print(f"  VALIDATION SUMMARY: {passed}/{total} passed, "
              f"{failed} failed, {skipped} skipped")
        print("=" * 60)
        if failed:
            print()
            print("  FAILURES:")
            for r in self.results:
                if r["status"] == FAIL:
                    print(f"    {r['tool']}: {r['test']} — {r['detail']}")
        print()


def check_metadata(parsed: dict, report: ValidationReport, tool: str,
                   *, licence: str = "Open Government Licence") -> None:
    """Verify response metadata matches the spec."""
    meta = parsed.get("metadata", {})
    if "Environment Agency" not in meta.get("source", ""):
        report.add(tool, "metadata.source", FAIL, f"Got: {meta.get('source')}")
    else:
        report.add(tool, "metadata.source", PASS)

    if licence not in meta.get("licence", ""):
        report.add(tool, "metadata.licence", FAIL, f"Got: {meta.get('licence')}")
    else:
        report.add(tool, "metadata.licence", PASS)

    if "retrieved_at" not in meta:
        report.add(tool, "metadata.retrieved_at", FAIL)
    else:
        report.add(tool, "metadata.retrieved_at", PASS)


async def validate_flood_warnings(report: ValidationReport) -> None:
    tool = "uk_environment_agency_flood_warnings"
    print(f"\n--- {tool} ---")

    result = await serve.uk_environment_agency_flood_warnings(county=TEST_COUNTY)
    parsed = json.loads(result)

    if "data" in parsed:
        total = parsed["data"].get("total_results", 0)
        report.add(tool, "returns data", PASS, f"{total} results")
    else:
        report.add(tool, "returns data", FAIL, parsed.get("error", ""))
        return

    # Cleaning annotations
    items = parsed["data"].get("items", [])
    if items and "_cleaning" in items[0]:
        report.add(tool, "_cleaning annotations", PASS)
    elif not items:
        report.add(tool, "_cleaning annotations", SKIP, "No active warnings")
    else:
        report.add(tool, "_cleaning annotations", FAIL)

    check_metadata(parsed, report, tool)

    # Validation: no filters
    result = await serve.uk_environment_agency_flood_warnings()
    parsed = json.loads(result)
    if "error" in parsed:
        report.add(tool, "no filters returns error", PASS)
    else:
        report.add(tool, "no filters returns error", FAIL)


async def validate_flood_areas(report: ValidationReport) -> None:
    tool = "uk_environment_agency_flood_areas"
    print(f"\n--- {tool} ---")

    result = await serve.uk_environment_agency_flood_areas()
    parsed = json.loads(result)

    if "data" in parsed and parsed["data"].get("total_results", 0) > 0:
        report.add(tool, "returns areas", PASS,
                   f"{parsed['data']['total_results']} total")
    else:
        report.add(tool, "returns areas", FAIL)
        return

    item = parsed["data"]["items"][0]
    if "area_id" in item and "area_name" in item:
        report.add(tool, "area fields present", PASS)
    else:
        report.add(tool, "area fields present", FAIL)

    check_metadata(parsed, report, tool)

    # Empty search
    result = await serve.uk_environment_agency_flood_areas(search="")
    parsed = json.loads(result)
    if "error" in parsed:
        report.add(tool, "empty search returns error", PASS)
    else:
        report.add(tool, "empty search returns error", FAIL)


async def validate_flood_stations(report: ValidationReport) -> None:
    tool = "uk_environment_agency_flood_stations"
    print(f"\n--- {tool} ---")

    result = await serve.uk_environment_agency_flood_stations(
        latitude=TEST_LATITUDE, longitude=TEST_LONGITUDE,
    )
    parsed = json.loads(result)

    if "data" in parsed and parsed["data"].get("total_results", 0) > 0:
        report.add(tool, "returns stations", PASS,
                   f"{parsed['data']['total_results']} total")
    else:
        report.add(tool, "returns stations", FAIL)
        return

    item = parsed["data"]["items"][0]
    if "station_id" in item and "station_name" in item:
        report.add(tool, "station fields present", PASS)
    else:
        report.add(tool, "station fields present", FAIL)

    if item.get("_cleaning", {}).get("status_interpreted"):
        report.add(tool, "status interpreted", PASS)
    else:
        report.add(tool, "status interpreted", FAIL)

    check_metadata(parsed, report, tool)

    # Invalid parameter
    result = await serve.uk_environment_agency_flood_stations(parameter="invalid")
    parsed = json.loads(result)
    if "error" in parsed:
        report.add(tool, "invalid parameter returns error", PASS)
    else:
        report.add(tool, "invalid parameter returns error", FAIL)


async def validate_station_readings(report: ValidationReport) -> None:
    tool = "uk_environment_agency_station_readings"
    print(f"\n--- {tool} ---")

    # First get a real station ID from the stations endpoint
    station_id = TEST_STATION_ID
    stations_result = await serve.uk_environment_agency_flood_stations(
        latitude=TEST_LATITUDE, longitude=TEST_LONGITUDE,
    )
    stations_parsed = json.loads(stations_result)
    stations_items = stations_parsed.get("data", {}).get("items", [])
    if stations_items:
        station_id = stations_items[0].get("station_id", station_id)

    result = await serve.uk_environment_agency_station_readings(
        station_id=station_id, limit=10,
    )
    parsed = json.loads(result)

    if "data" in parsed and parsed["data"].get("total_readings", 0) > 0:
        report.add(tool, "returns readings", PASS,
                   f"{parsed['data']['total_readings']} readings")
    else:
        report.add(tool, "returns readings", FAIL,
                   parsed.get("error", "No readings"))
        return

    reading = parsed["data"]["readings"][0]
    if "value" in reading and "timestamp" in reading:
        report.add(tool, "reading fields present", PASS)
    else:
        report.add(tool, "reading fields present", FAIL)

    check_metadata(parsed, report, tool)

    # Missing station ID
    result = await serve.uk_environment_agency_station_readings()
    parsed = json.loads(result)
    if "error" in parsed:
        report.add(tool, "missing station_id returns error", PASS)
    else:
        report.add(tool, "missing station_id returns error", FAIL)


async def validate_water_quality_sites(report: ValidationReport) -> None:
    tool = "uk_environment_agency_water_quality_sites"
    print(f"\n--- {tool} ---")

    result = await serve.uk_environment_agency_water_quality_sites(
        latitude=TEST_LATITUDE, longitude=TEST_LONGITUDE,
    )
    parsed = json.loads(result)

    if "data" in parsed and parsed["data"].get("total_results", 0) > 0:
        report.add(tool, "returns sites", PASS,
                   f"{parsed['data']['total_results']} total")
    else:
        report.add(tool, "returns sites", FAIL,
                   parsed.get("error", "No results"))
        return

    item = parsed["data"]["items"][0]
    if "sampling_point_id" in item and "sampling_point_name" in item:
        report.add(tool, "site fields present", PASS)
    else:
        report.add(tool, "site fields present", FAIL)

    check_metadata(parsed, report, tool)


async def validate_water_quality_results(report: ValidationReport) -> None:
    tool = "uk_environment_agency_water_quality_results"
    print(f"\n--- {tool} ---")

    # Get a real sampling point ID first
    sp_id = TEST_SAMPLING_POINT
    sites_result = await serve.uk_environment_agency_water_quality_sites(
        latitude=TEST_LATITUDE, longitude=TEST_LONGITUDE,
    )
    sites_parsed = json.loads(sites_result)
    sites_items = sites_parsed.get("data", {}).get("items", [])
    if sites_items:
        sp_id = sites_items[0].get("sampling_point_id", sp_id)

    result = await serve.uk_environment_agency_water_quality_results(
        sampling_point_id=sp_id,
    )
    parsed = json.loads(result)

    if "data" in parsed and parsed["data"].get("total_results", 0) > 0:
        report.add(tool, "returns measurements", PASS,
                   f"{parsed['data']['total_results']} total")
    else:
        report.add(tool, "returns measurements", FAIL,
                   parsed.get("error", "No results"))
        return

    m = parsed["data"]["measurements"][0]
    if "determinand" in m and "value" in m and "unit" in m:
        report.add(tool, "measurement fields present", PASS)
    else:
        report.add(tool, "measurement fields present", FAIL)

    check_metadata(parsed, report, tool)

    # Missing sampling point
    result = await serve.uk_environment_agency_water_quality_results()
    parsed = json.loads(result)
    if "error" in parsed:
        report.add(tool, "missing sampling_point returns error", PASS)
    else:
        report.add(tool, "missing sampling_point returns error", FAIL)


async def validate_bathing_water(report: ValidationReport) -> None:
    tool = "uk_environment_agency_bathing_water"
    print(f"\n--- {tool} ---")

    result = await serve.uk_environment_agency_bathing_water(search="Brighton")
    parsed = json.loads(result)

    if "data" in parsed:
        total = parsed["data"].get("total_results", 0)
        if total > 0:
            report.add(tool, "returns data", PASS, f"{total} results")
            check_metadata(parsed, report, tool)
        else:
            report.add(tool, "returns data", SKIP,
                       "Service may be down (known 403 issue)")
    elif "error" in parsed:
        # Known: bathing water API returns 403 (Azure WAF)
        report.add(tool, "returns data", SKIP,
                   f"Service unavailable: {parsed.get('error', 'unknown')}")
    else:
        report.add(tool, "returns data", FAIL)


async def validate_permits_search(report: ValidationReport) -> None:
    tool = "uk_environment_agency_permits_search"
    print(f"\n--- {tool} ---")

    result = await serve.uk_environment_agency_permits_search(
        company_name=TEST_COMPANY_NAME,
    )
    parsed = json.loads(result)

    if "data" in parsed and parsed["data"].get("total_results", 0) > 0:
        report.add(tool, "returns permits", PASS,
                   f"{parsed['data']['total_results']} total")
    else:
        report.add(tool, "returns permits", FAIL,
                   parsed.get("error", "No results"))
        return

    item = parsed["data"]["items"][0]
    if "permit_number" in item and "company_name" in item:
        report.add(tool, "permit fields present", PASS)
    else:
        report.add(tool, "permit fields present", FAIL)

    if item.get("_cleaning", {}).get("licence") == "EA Conditional Licence":
        report.add(tool, "licence annotation correct", PASS)
    else:
        report.add(tool, "licence annotation correct", FAIL)

    check_metadata(parsed, report, tool, licence="EA Conditional Licence")

    # No filters
    result = await serve.uk_environment_agency_permits_search()
    parsed = json.loads(result)
    if "error" in parsed:
        report.add(tool, "no filters returns error", PASS)
    else:
        report.add(tool, "no filters returns error", FAIL)

    # Invalid permit type
    result = await serve.uk_environment_agency_permits_search(permit_type="invalid")
    parsed = json.loads(result)
    if "error" in parsed:
        report.add(tool, "invalid permit_type returns error", PASS)
    else:
        report.add(tool, "invalid permit_type returns error", FAIL)


async def validate_permit_detail(report: ValidationReport) -> None:
    tool = "uk_environment_agency_permit_detail"
    print(f"\n--- {tool} ---")

    # Get a real permit number from search first
    permit_number = TEST_PERMIT_NUMBER
    search_result = await serve.uk_environment_agency_permits_search(
        company_name=TEST_COMPANY_NAME,
    )
    search_parsed = json.loads(search_result)
    search_items = search_parsed.get("data", {}).get("items", [])
    if search_items:
        permit_number = search_items[0].get("permit_number", permit_number)

    result = await serve.uk_environment_agency_permit_detail(
        permit_number=permit_number,
    )
    parsed = json.loads(result)

    if "data" in parsed and parsed["data"].get("permit_number"):
        report.add(tool, "returns detail", PASS, parsed["data"]["permit_number"])
    elif "error" in parsed and parsed.get("error") == "not_found":
        report.add(tool, "returns detail", SKIP,
                   f"Permit {permit_number} not found via cross-register search")
        # Still test the missing permit_number validation
        result = await serve.uk_environment_agency_permit_detail()
        parsed = json.loads(result)
        if "error" in parsed:
            report.add(tool, "missing permit_number returns error", PASS)
        else:
            report.add(tool, "missing permit_number returns error", FAIL)
        return
    else:
        report.add(tool, "returns detail", FAIL,
                   parsed.get("error", "No data"))
        return

    if parsed["data"].get("_cleaning", {}).get("licence") == "EA Conditional Licence":
        report.add(tool, "licence annotation correct", PASS)
    else:
        report.add(tool, "licence annotation correct", FAIL)

    check_metadata(parsed, report, tool, licence="EA Conditional Licence")

    # Missing permit number
    result = await serve.uk_environment_agency_permit_detail()
    parsed = json.loads(result)
    if "error" in parsed:
        report.add(tool, "missing permit_number returns error", PASS)
    else:
        report.add(tool, "missing permit_number returns error", FAIL)


async def validate_catchment(report: ValidationReport) -> None:
    tool = "uk_environment_agency_catchment"
    print(f"\n--- {tool} ---")

    result = await serve.uk_environment_agency_catchment()
    parsed = json.loads(result)

    if "data" in parsed and parsed["data"].get("total_results", 0) > 0:
        report.add(tool, "returns catchments", PASS,
                   f"{parsed['data']['total_results']} total")
    else:
        report.add(tool, "returns catchments", FAIL,
                   parsed.get("error", "No results"))
        return

    item = parsed["data"]["items"][0]
    if "waterbody_id" in item and "waterbody_name" in item:
        report.add(tool, "waterbody fields present", PASS)
    else:
        report.add(tool, "waterbody fields present", FAIL)

    if "_cleaning" in item:
        report.add(tool, "_cleaning annotations", PASS)
    else:
        report.add(tool, "_cleaning annotations", FAIL)

    check_metadata(parsed, report, tool)


async def main() -> None:
    print("=" * 60)
    print("  STAGE 8: Live API Validation")
    print("  Testing all 10 tools against Environment Agency API")
    print("  (No API key required — public data)")
    print("=" * 60)

    report = ValidationReport()

    await validate_flood_warnings(report)
    await validate_flood_areas(report)
    await validate_flood_stations(report)
    await validate_station_readings(report)
    await validate_water_quality_sites(report)
    await validate_water_quality_results(report)
    await validate_bathing_water(report)
    await validate_permits_search(report)
    await validate_permit_detail(report)
    await validate_catchment(report)

    report.summary()


if __name__ == "__main__":
    asyncio.run(main())
