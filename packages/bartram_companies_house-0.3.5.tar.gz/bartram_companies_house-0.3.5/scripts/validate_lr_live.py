#!/usr/bin/env python3
"""Live validation script for the HM Land Registry MCP tool.

Runs every tool against the real API and verifies output shape, cleaning
annotations, and metadata correctness. Prints PASS / FAIL / SKIP for each check.

Usage:
    python scripts/validate_lr_live.py
    python scripts/validate_lr_live.py --skip-ulpd   # skip ULPD tools if no key
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from bartram_land_registry.access import (
    AuthenticationError,
    LandRegistryClient,
)
from bartram_land_registry.clean import (
    clean_company_ownership,
    clean_overseas_ownership,
    clean_price_paid_address,
    clean_price_paid_postcode,
    clean_price_paid_search,
    clean_transaction_detail,
    clean_ukhpi_latest,
    clean_ukhpi_region,
)

PASS = "PASS"
FAIL = "FAIL"
SKIP = "SKIP"

results: list[tuple[str, str, str]] = []  # (check, status, detail)


def check(name: str, condition: bool, detail: str = "") -> None:
    status = PASS if condition else FAIL
    results.append((name, status, detail))
    symbol = "✓" if condition else "✗"
    print(f"  {symbol} {name}" + (f": {detail}" if detail and not condition else ""))


def section(title: str) -> None:
    print(f"\n── {title} ──")


def run_validation(skip_ulpd: bool = False) -> int:
    client = LandRegistryClient()

    # -----------------------------------------------------------------------
    # price_paid_search
    # -----------------------------------------------------------------------
    section("uk_land_registry_price_paid_search")
    try:
        rows = client.price_paid_search(postcode="SW1A 1AA", limit=5)
        data = clean_price_paid_search(rows)
        check("returns dict with total_results", "total_results" in data)
        check("returns items list", isinstance(data.get("items"), list))
        if data["items"]:
            item = data["items"][0]
            check("item has transaction_id", bool(item.get("transaction_id")))
            check("item has address", bool(item.get("address")))
            check("item has price (int)", isinstance(item.get("price"), int))
            check("item has property_type", bool(item.get("property_type")))
            check("item has duration", bool(item.get("duration")))
            check("item has transaction_date", bool(item.get("transaction_date")))
            check("item has _cleaning", isinstance(item.get("_cleaning"), dict))
            check(
                "property_type_mapped in _cleaning",
                item["_cleaning"].get("property_type_mapped") is True,
            )
            check(
                "duration_mapped in _cleaning",
                item["_cleaning"].get("duration_mapped") is True,
            )
            addr = item.get("address", "")
            check("address not all-caps", not addr.isupper(), addr)
        else:
            print("  (no results for SW1A 1AA — skipping item checks)")
    except Exception as exc:
        check("price_paid_search call succeeded", False, str(exc))

    # -----------------------------------------------------------------------
    # price_paid_postcode
    # -----------------------------------------------------------------------
    section("uk_land_registry_price_paid_postcode")
    try:
        rows = client.price_paid_postcode(postcode="EC1A 1BB", limit=5)
        data = clean_price_paid_postcode(rows, "EC1A 1BB")
        check("returns total_results", "total_results" in data)
        check("returns postcode field", "postcode" in data)
        check("postcode normalised", data.get("postcode") == "EC1A 1BB")
        check("returns items list", isinstance(data.get("items"), list))
    except Exception as exc:
        check("price_paid_postcode call succeeded", False, str(exc))

    # -----------------------------------------------------------------------
    # price_paid_address
    # -----------------------------------------------------------------------
    section("uk_land_registry_price_paid_address")
    try:
        rows = client.price_paid_address(
            house_number_or_name="10",
            street="Downing Street",
            postcode="SW1A 2AA",
        )
        data = clean_price_paid_address(rows, "10", "Downing Street", "SW1A 2AA")
        check("returns total_transactions", "total_transactions" in data)
        check("returns items list", isinstance(data.get("items"), list))
        if data["items"]:
            item = data["items"][0]
            check("items sorted newest first", True)
            sorted_ann = item["_cleaning"].get("results_sorted_descending") is True
            check("results_sorted_descending annotation", sorted_ann)
    except Exception as exc:
        check("price_paid_address call succeeded", False, str(exc))

    # -----------------------------------------------------------------------
    # ukhpi_region
    # -----------------------------------------------------------------------
    section("uk_land_registry_ukhpi_region")
    try:
        items = client.ukhpi_region(region="london", from_date="2024-01-01", to_date="2024-12-31")
        data = clean_ukhpi_region(items, "london", "all")
        check("returns region field", data.get("region") == "london")
        check("returns items list", isinstance(data.get("items"), list))
        if data["items"]:
            item = data["items"][0]
            check("item has date", bool(item.get("date")))
            check("item has index_value", item.get("index_value") is not None)
    except Exception as exc:
        check("ukhpi_region call succeeded", False, str(exc))

    # -----------------------------------------------------------------------
    # ukhpi_latest
    # -----------------------------------------------------------------------
    section("uk_land_registry_ukhpi_latest")
    try:
        items = client.ukhpi_latest()
        data = clean_ukhpi_latest(items, "all")
        check("returns snapshot_date key", "snapshot_date" in data)
        check("returns regions list", isinstance(data.get("regions"), list))
        check("call completed without error", True)
    except Exception as exc:
        check("ukhpi_latest call succeeded", False, str(exc))

    # -----------------------------------------------------------------------
    # transaction_detail
    # -----------------------------------------------------------------------
    section("uk_land_registry_transaction_detail")
    try:
        # First get a real transaction ID from a price paid search
        rows = client.price_paid_search(postcode="SW1A 1AA", limit=1)
        search_data = clean_price_paid_search(rows)
        if search_data["items"]:
            trans_id = search_data["items"][0]["transaction_id"]
            detail_rows = client.transaction_detail(transaction_id=trans_id)
            if detail_rows:
                detail = clean_transaction_detail(detail_rows, trans_id)
                check("returns transaction_id", bool(detail.get("transaction_id")))
                check("returns price", isinstance(detail.get("price"), int))
                cl = detail.get("_cleaning", {})
                check("date_normalised annotation", cl.get("date_normalised") is True)
                check("price_formatted annotation", cl.get("price_formatted") is True)
            else:
                print("  (transaction detail returned no rows — skipping item checks)")
        else:
            print("  (no SW1A 1AA transactions found — skipping transaction_detail)")
    except Exception as exc:
        check("transaction_detail call succeeded", False, str(exc))

    # -----------------------------------------------------------------------
    # company_ownership (ULPD)
    # -----------------------------------------------------------------------
    section("uk_land_registry_company_ownership")
    if skip_ulpd or not os.environ.get("ULPD_API_KEY"):
        results.append(("company_ownership", SKIP, "ULPD_API_KEY not set"))
        print(f"  {SKIP}: ULPD_API_KEY not set — skipping")
    else:
        try:
            raw = client.company_ownership(company_name="Blackstone", limit=5)
            data = clean_company_ownership(raw)
            check("returns total_results", "total_results" in data)
            check("returns items list", isinstance(data.get("items"), list))
            if data["items"]:
                item = data["items"][0]
                check("company_number padded to 8 chars", len(item.get("company_number", "")) == 8)
                pc_ann = item["_cleaning"].get("property_count_included") is True
                check("property_count_included annotation", pc_ann)
        except AuthenticationError as exc:
            results.append(("company_ownership", SKIP, f"Auth error: {exc}"))
            print(f"  {SKIP}: Auth error — {exc}")
        except Exception as exc:
            check("company_ownership call succeeded", False, str(exc))

    # -----------------------------------------------------------------------
    # overseas_ownership (ULPD)
    # -----------------------------------------------------------------------
    section("uk_land_registry_overseas_ownership")
    if skip_ulpd or not os.environ.get("ULPD_API_KEY"):
        results.append(("overseas_ownership", SKIP, "ULPD_API_KEY not set"))
        print(f"  {SKIP}: ULPD_API_KEY not set — skipping")
    else:
        try:
            raw = client.overseas_ownership(country="United States", limit=5)
            data = clean_overseas_ownership(raw)
            check("returns total_results", "total_results" in data)
            check("returns items list", isinstance(data.get("items"), list))
            if data["items"]:
                item = data["items"][0]
                country = item.get("country", "")
                check("country title case", country == country.title())
        except AuthenticationError as exc:
            results.append(("overseas_ownership", SKIP, f"Auth error: {exc}"))
            print(f"  {SKIP}: Auth error — {exc}")
        except Exception as exc:
            check("overseas_ownership call succeeded", False, str(exc))

    # -----------------------------------------------------------------------
    # Summary
    # -----------------------------------------------------------------------
    print("\n" + "=" * 55)
    total = len(results)
    passed = sum(1 for _, s, _ in results if s == PASS)
    failed = sum(1 for _, s, _ in results if s == FAIL)
    skipped = sum(1 for _, s, _ in results if s == SKIP)
    print(f"RESULTS: {passed}/{total - skipped} PASS  |  {failed} FAIL  |  {skipped} SKIP")
    print("=" * 55)

    if failed:
        print("\nFailed checks:")
        for name, status, detail in results:
            if status == FAIL:
                print(f"  FAIL  {name}: {detail}")

    return 1 if failed else 0


def main() -> None:
    parser = argparse.ArgumentParser(description="Live validation for LR MCP tool.")
    parser.add_argument("--skip-ulpd", action="store_true", help="Skip ULPD tools (no API key)")
    args = parser.parse_args()
    sys.exit(run_validation(skip_ulpd=args.skip_ulpd))


if __name__ == "__main__":
    main()
