#!/usr/bin/env python3
"""Run health checks across all deployed tools.

Usage: python scripts/health_check.py
       python scripts/health_check.py --db monitoring.db

Checks upstream API availability and records results to the monitoring database.
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

# Allow running from the repo root.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from bartram_foundry.monitoring import (
    MetricsStore,
    check_charity_health,
    check_companies_house_health,
    check_environment_agency_health,
    check_fca_health,
    check_land_registry_health,
)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run health checks for Bartram Foundry tools.")
    parser.add_argument(
        "--db",
        default="monitoring.db",
        help="Path to the monitoring SQLite database (default: monitoring.db)",
    )
    args = parser.parse_args()

    store = MetricsStore(args.db)

    # -- Companies House ---------------------------------------------------
    api_key = os.environ.get("COMPANIES_HOUSE_API_KEY", "")
    if api_key:
        print("Checking Companies House API...", end=" ", flush=True)
        result = check_companies_house_health(api_key)

        store.record_health_check(
            result.tool_name,
            healthy=result.healthy,
            response_ms=result.response_ms,
            status_code=result.status_code,
            error_message=result.error_message,
        )

        if result.healthy:
            print(f"OK ({result.response_ms:.0f}ms, HTTP {result.status_code})")
        else:
            print(f"FAIL ({result.error_message})")
    else:
        print("SKIP: Companies House (COMPANIES_HOUSE_API_KEY not set)")

    # -- FCA ---------------------------------------------------------------
    fca_email = os.environ.get("FCA_API_EMAIL", "")
    fca_key = os.environ.get("FCA_API_KEY", "")
    if fca_email and fca_key:
        print("Checking FCA API...", end=" ", flush=True)
        fca_result = check_fca_health(fca_email, fca_key)

        store.record_health_check(
            fca_result.tool_name,
            healthy=fca_result.healthy,
            response_ms=fca_result.response_ms,
            status_code=fca_result.status_code,
            error_message=fca_result.error_message,
        )

        if fca_result.healthy:
            print(f"OK ({fca_result.response_ms:.0f}ms, HTTP {fca_result.status_code})")
        else:
            print(f"FAIL ({fca_result.error_message})")
    else:
        print("SKIP: FCA (FCA_API_EMAIL / FCA_API_KEY not set)")

    # -- Charity Commission ------------------------------------------------
    charity_key = os.environ.get("CHARITY_COMMISSION_API_KEY", "")
    if charity_key:
        print("Checking Charity Commission API...", end=" ", flush=True)
        charity_result = check_charity_health(charity_key)

        store.record_health_check(
            charity_result.tool_name,
            healthy=charity_result.healthy,
            response_ms=charity_result.response_ms,
            status_code=charity_result.status_code,
            error_message=charity_result.error_message,
        )

        if charity_result.healthy:
            print(f"OK ({charity_result.response_ms:.0f}ms, HTTP {charity_result.status_code})")
        else:
            print(f"FAIL ({charity_result.error_message})")
    else:
        print("SKIP: Charity Commission (CHARITY_COMMISSION_API_KEY not set)")

    # -- Environment Agency ------------------------------------------------
    print("Checking Environment Agency API...", end=" ", flush=True)
    ea_result = check_environment_agency_health()

    store.record_health_check(
        ea_result.tool_name,
        healthy=ea_result.healthy,
        response_ms=ea_result.response_ms,
        status_code=ea_result.status_code,
        error_message=ea_result.error_message,
    )

    if ea_result.healthy:
        print(f"OK ({ea_result.response_ms:.0f}ms, HTTP {ea_result.status_code})")
    else:
        print(f"FAIL ({ea_result.error_message})")

    # -- Land Registry (no auth required) ---------------------------------
    print("Checking Land Registry SPARQL endpoint...", end=" ", flush=True)
    lr_result = check_land_registry_health()

    store.record_health_check(
        lr_result.tool_name,
        healthy=lr_result.healthy,
        response_ms=lr_result.response_ms,
        status_code=lr_result.status_code,
        error_message=lr_result.error_message,
    )

    if lr_result.healthy:
        print(f"OK ({lr_result.response_ms:.0f}ms, HTTP {lr_result.status_code})")
    else:
        print(f"FAIL ({lr_result.error_message})")

    # -- Error rate alerts -------------------------------------------------
    alerts = store.check_error_rate_alert(last_minutes=60, threshold=0.1)
    if alerts:
        print()
        print("ERROR RATE ALERTS:")
        for alert in alerts:
            print(f"  WARNING: {alert['alert']}")

    # -- Summary -----------------------------------------------------------
    print()
    latest = store.get_latest_health()
    all_healthy = all(h["healthy"] for h in latest)
    has_alerts = bool(alerts)
    if not all_healthy:
        print("Overall: ISSUES DETECTED")
        sys.exit(1)
    elif has_alerts:
        print("Overall: HEALTHY (with error rate warnings)")
        sys.exit(0)
    else:
        print("Overall: ALL HEALTHY")


if __name__ == "__main__":
    main()
