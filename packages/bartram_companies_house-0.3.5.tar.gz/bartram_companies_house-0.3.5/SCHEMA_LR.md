# Land Registry Schema Reference

Complete tool reference for the UK Land Registry MCP server. Each tool follows the `access → clean → serve` pattern: raw SPARQL/REST data is fetched, cleaned, and returned in a consistent envelope.

## Response envelope

Every successful response wraps data in this structure:

```json
{
  "data": { ... },
  "metadata": {
    "source": "HM Land Registry Open Data",
    "licence": "Open Government Licence v3",
    "retrieved_at": "2026-04-04T10:00:00+00:00",
    "endpoint": "price_paid_search",
    "cached": false,
    "attribution": "Contains HM Land Registry data © Crown copyright and database right 2024. Licensed under the Open Government Licence v3.0."
  }
}
```

Error responses:

```json
{
  "error": "Invalid UK postcode: 'NOTAPOSTCODE'",
  "status_code": 400,
  "attribution": "Contains HM Land Registry data © Crown copyright and database right 2024. Licensed under the Open Government Licence v3.0."
}
```

---

## uk_land_registry_price_paid_search

Search Price Paid transactions by postcode, street, town, price range, and property type.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `postcode` | string | * | — | UK postcode (e.g. `SW1A 1AA`) |
| `street` | string | * | — | Street name (partial match) |
| `town` | string | * | — | Town name (partial match) |
| `min_price` | int | no | — | Minimum sale price (GBP) |
| `max_price` | int | no | — | Maximum sale price (GBP) |
| `property_type` | string | no | — | One of: `detached`, `semi-detached`, `terraced`, `flat`, `other` |
| `from_date` | string | no | — | Start date filter (YYYY-MM-DD) |
| `to_date` | string | no | — | End date filter (YYYY-MM-DD) |
| `limit` | int | no | 50 | Max results (1–200) |

\* At least one of `postcode`, `street`, or `town` is required.

### Returns

`data` contains `total_results` (int) and `items` list. Each item includes:

| Field | Type | Description |
|-------|------|-------------|
| `transaction_id` | string | Unique transaction URI |
| `address` | string | Full address (Title Case) |
| `postcode` | string | Normalised postcode |
| `price` | int | Sale price in GBP |
| `transaction_date` | string | Date of sale (YYYY-MM-DD) |
| `property_type` | string | Decoded type (e.g. `Detached`) |
| `duration` | string | `Freehold` or `Leasehold` |
| `ppd_category` | string | `Standard` or `Additional` |
| `_cleaning` | dict | Transformation annotations |

### Cleaning applied

- Addresses normalised from ALL CAPS to Title Case (`address_normalised: true`).
- Property type decoded from URI/code to label (`property_type_mapped: true`).
- Duration decoded (`duration_mapped: true`).
- PPD category decoded (`pricepaid_category_mapped: true`).

---

## uk_land_registry_price_paid_postcode

All Price Paid transactions for a specific postcode.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `postcode` | string | yes | — | UK postcode (e.g. `EC1A 1BB`) |
| `from_date` | string | no | — | Start date (YYYY-MM-DD) |
| `to_date` | string | no | — | End date (YYYY-MM-DD) |
| `limit` | int | no | 100 | Max results (1–200) |

### Returns

`data` contains `total_results`, `postcode` (normalised), and `items` list with same structure as `price_paid_search`.

---

## uk_land_registry_price_paid_address

Full transaction history for a specific address.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `house_number_or_name` | string | yes | — | House number or name (e.g. `10` or `The Cottage`) |
| `street` | string | yes | — | Street name |
| `postcode` | string | yes | — | UK postcode |

### Returns

`data` contains `total_transactions` (int) and `items` list sorted newest-first. Each item has same fields as `price_paid_search`. The `_cleaning` dict includes `results_sorted_descending: true`.

---

## uk_land_registry_transaction_detail

Detailed record for a single Price Paid transaction.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `transaction_id` | string | yes | — | Transaction URI from a price paid result |

### Returns

`data` contains the full transaction record with all Price Paid fields plus `_cleaning` annotations including `date_normalised: true` and `price_formatted: true`.

---

## uk_land_registry_ukhpi_region

UK House Price Index time series for a standard region.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `region` | string | yes | — | Region slug (see valid values below) |
| `from_date` | string | no | — | Start date (YYYY-MM-DD) |
| `to_date` | string | no | — | End date (YYYY-MM-DD) |
| `property_type` | string | no | `all` | One of: `all`, `detached`, `semi-detached`, `terraced`, `flat` |

**Valid regions:** `england`, `london`, `south-east`, `east-of-england`, `south-west`, `west-midlands`, `east-midlands`, `yorkshire-and-the-humber`, `north-west`, `north-east`, `wales`, `scotland`, `northern-ireland`

### Returns

`data` contains:

| Field | Type | Description |
|-------|------|-------------|
| `region` | string | Region slug |
| `property_type` | string | Property type filter used |
| `items` | list | Monthly index data points |

Each item:

| Field | Type | Description |
|-------|------|-------------|
| `date` | string | Month (YYYY-MM) |
| `index_value` | float | House price index value |
| `annual_change_percent` | float | Year-on-year % change |
| `monthly_change_percent` | float | Month-on-month % change |

---

## uk_land_registry_ukhpi_latest

Latest HPI snapshot across all standard regions.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `property_type` | string | no | `all` | One of: `all`, `detached`, `semi-detached`, `terraced`, `flat` |

### Returns

`data` contains:

| Field | Type | Description |
|-------|------|-------------|
| `snapshot_date` | string | Month of the snapshot (YYYY-MM) |
| `property_type` | string | Property type filter used |
| `regions` | list | One entry per standard region |

Each region entry:

| Field | Type | Description |
|-------|------|-------------|
| `region` | string | Region slug |
| `index_value` | float | House price index value |
| `annual_change_percent` | float | Year-on-year % change |
| `monthly_change_percent` | float | Month-on-month % change |

---

## uk_land_registry_company_ownership

UK companies that own registered land or property (CCOD dataset).

**Requires `ULPD_API_KEY` environment variable.**

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `company_name` | string | * | — | Company name (partial match) |
| `company_number` | string | * | — | Companies House registration number |
| `postcode` | string | * | — | Postcode of owned property |
| `limit` | int | no | 50 | Max results (1–100) |

\* At least one required.

### Returns

`data` contains `total_results` and `items` list. Each item:

| Field | Type | Description |
|-------|------|-------------|
| `company_name` | string | Registered company name |
| `company_number` | string | 8-digit Companies House number |
| `property_address` | string | Address of the land/property |
| `tenure` | string | Tenure type |
| `registration_type` | string | Registration classification |
| `property_count` | int | Number of properties held |
| `_cleaning` | dict | Transformation annotations |

### Cleaning applied

- Company numbers zero-padded to 8 characters (`company_number_padded: true`).
- Company names normalised (`name_normalised: true`).
- Property count included from aggregation (`property_count_included: true`).

---

## uk_land_registry_overseas_ownership

Overseas entities that own UK registered land or property (OCOD dataset).

**Requires `ULPD_API_KEY` environment variable.**

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `entity_name` | string | * | — | Overseas entity name (partial match) |
| `country` | string | * | — | Country of registration |
| `postcode` | string | * | — | Postcode of owned property |
| `limit` | int | no | 50 | Max results (1–100) |

\* At least one required.

### Returns

`data` contains `total_results` and `items` list. Each item:

| Field | Type | Description |
|-------|------|-------------|
| `entity_name` | string | Overseas entity name |
| `country` | string | Country of registration (Title Case) |
| `property_address` | string | Address of the land/property |
| `tenure` | string | Tenure type |
| `registration_type` | string | Registration classification |
| `_cleaning` | dict | Transformation annotations |

### Cleaning applied

- Country names normalised to Title Case (`country_normalised: true`).
- Registration type decoded (`registration_type_mapped: true`).
