# UK Environment Agency MCP Server

Clean, structured Environment Agency data for AI agents — via the [Model Context Protocol](https://modelcontextprotocol.io/).

<!-- mcp-name: io.github.RobertAlsop/environment-agency -->

## What this does

This MCP server gives agents access to 10 Environment Agency endpoints — flood monitoring, water quality, environmental permits, bathing water, and WFD catchment data — with data cleaning that the raw API doesn't provide.

Environment Agency data has known quality issues: flood severity levels are numeric codes (1-4), station status uses inconsistent casing, water quality results mix string and dict formats for units, WKT geometry strings need parsing, permit status codes are opaque single characters, and CSV catchment data needs aggregation. This server fixes those problems before the data reaches your agent.

**No API key required** — Environment Agency data is public, licensed under the Open Government Licence v3 (except Public Registers: EA Conditional Licence).

**What the cleaning layer does:**

- **Severity mapping** — numeric flood severity codes (1-4) mapped to human-readable labels (Severe Flood Warning, Flood Warning, Flood Alert, Warning No Longer In Force).
- **Station status interpretation** — raw status values normalised and interpreted with active/closed/suspended/decommissioned labels.
- **WKT geometry parsing** — OSGB36 WKT POINT strings parsed to easting/northing coordinates.
- **WFD classification mapping** — single-character WFD status codes (H/G/M/P/B) mapped to High/Good/Moderate/Poor/Bad.
- **Permit status decoding** — opaque permit status codes (A/R/V/S) decoded to Active/Revoked/Varied/Surrendered.
- **Address and postcode normalisation** — using shared UK address utilities.
- **Unit format handling** — water quality `hasUnit` values handled whether string or dict.
- **CSV aggregation** — catchment data grouped by waterbody, most recent classification extracted.
- **Bathing water classifications** — coded values (E/G/S/P) mapped to Excellent/Good/Sufficient/Poor.
- **Data quality annotations** — every cleaned record carries `_cleaning` metadata so agents can see what was changed and why.

## Quick start

```bash
# Install
pip install bartram-companies-house

# Run the MCP server (no API key needed)
bartram-environment-agency
```

Or with [uvx](https://docs.astral.sh/uv/):

```bash
uvx bartram-environment-agency
```

### Configure with Claude Desktop

Add to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "environment-agency": {
      "command": "uvx",
      "args": ["bartram-environment-agency"]
    }
  }
}
```

## Tools

| Tool | Description |
|------|-------------|
| `uk_environment_agency_flood_warnings` | Current flood warnings and alerts for a location or area |
| `uk_environment_agency_flood_areas` | Flood risk areas for property due diligence |
| `uk_environment_agency_flood_stations` | Flood monitoring stations near a location |
| `uk_environment_agency_station_readings` | Water level, rainfall, and tidal readings |
| `uk_environment_agency_water_quality_sites` | Water quality sampling points near a location |
| `uk_environment_agency_water_quality_results` | Water quality measurements (pH, dissolved oxygen, nitrates) |
| `uk_environment_agency_bathing_water` | Bathing water quality classifications |
| `uk_environment_agency_permits_search` | Environmental permits by company or location |
| `uk_environment_agency_permit_detail` | Full permit details with conditions |
| `uk_environment_agency_catchment` | WFD catchment and waterbody classification data |

## Example prompts

- "Are there any flood warnings in Somerset right now?"
- "Find water quality sampling points near Bath and show the latest pH readings"
- "What environmental permits does Thames Water hold?"
- "What's the WFD classification for waterbodies in the Thames catchment?"
- "Show me flood monitoring stations within 10km of London Bridge"

## Data sources

| Endpoint group | API | Licence |
|---------------|-----|---------|
| Flood monitoring | environment.data.gov.uk/flood-monitoring | Open Government Licence v3 |
| Water quality | environment.data.gov.uk/water-quality | Open Government Licence v3 |
| Bathing water | environment.data.gov.uk/doc/bathing-water | Open Government Licence v3 |
| Permits | environment.data.gov.uk/public-register | EA Conditional Licence |
| Catchment | environment.data.gov.uk/catchment-planning | Open Government Licence v3 |

Contains Environment Agency information (c) Environment Agency and/or database right.

## Schema reference

See [SCHEMA_EA.md](SCHEMA_EA.md) for full parameter documentation and response formats.

## Development

```bash
# Install dev dependencies
pip install -e ".[dev]"

# Run tests (97 EA tests)
pytest bartram_environment_agency/tests/ -v

# Run live validation (no API key needed)
python scripts/validate_live_ea.py

# Lint
ruff check bartram_environment_agency/
```
