"""Tests for bartram_foundry.serve_helpers — shared serve-layer helpers."""

from __future__ import annotations

import json
import time
from unittest.mock import MagicMock, call

import pytest

from bartram_foundry.serve_helpers import (
    ToolServerConfig,
    format_error,
    format_response,
    record_call,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def config() -> ToolServerConfig:
    return ToolServerConfig(
        source_name="Test Data Source",
        licence="Test Licence v1",
        attribution="Test attribution string.",
    )


@pytest.fixture
def metrics() -> MagicMock:
    return MagicMock()


# ---------------------------------------------------------------------------
# ToolServerConfig
# ---------------------------------------------------------------------------


class TestToolServerConfig:
    def test_frozen(self, config: ToolServerConfig) -> None:
        with pytest.raises(AttributeError):
            config.source_name = "changed"  # type: ignore[misc]

    def test_fields(self, config: ToolServerConfig) -> None:
        assert config.source_name == "Test Data Source"
        assert config.licence == "Test Licence v1"
        assert config.attribution == "Test attribution string."


# ---------------------------------------------------------------------------
# format_response
# ---------------------------------------------------------------------------


class TestFormatResponse:
    def test_basic_envelope(self, config: ToolServerConfig) -> None:
        data = {"key": "value"}
        result = json.loads(format_response(config, data, endpoint="/test"))
        assert result["data"] == {"key": "value"}
        assert result["metadata"]["source"] == "Test Data Source"
        assert result["metadata"]["licence"] == "Test Licence v1"
        assert result["metadata"]["endpoint"] == "/test"
        assert result["metadata"]["cached"] is False
        assert result["metadata"]["attribution"] == "Test attribution string."
        assert "retrieved_at" in result["metadata"]

    def test_cached_flag(self, config: ToolServerConfig) -> None:
        result = json.loads(format_response(config, {}, endpoint="/x", cached=True))
        assert result["metadata"]["cached"] is True

    def test_list_data(self, config: ToolServerConfig) -> None:
        data = [1, 2, 3]
        result = json.loads(format_response(config, data, endpoint="/list"))
        assert result["data"] == [1, 2, 3]

    def test_none_data(self, config: ToolServerConfig) -> None:
        result = json.loads(format_response(config, None, endpoint="/none"))
        assert result["data"] is None

    def test_retrieved_at_is_utc_iso(self, config: ToolServerConfig) -> None:
        result = json.loads(format_response(config, {}, endpoint="/t"))
        ts = result["metadata"]["retrieved_at"]
        # Should end with +00:00 (UTC)
        assert "+00:00" in ts

    def test_non_serialisable_uses_default_str(self, config: ToolServerConfig) -> None:
        """Objects that aren't JSON-serialisable should be converted via str()."""
        from datetime import date

        data = {"date": date(2026, 1, 1)}
        result = json.loads(format_response(config, data, endpoint="/d"))
        assert result["data"]["date"] == "2026-01-01"


# ---------------------------------------------------------------------------
# format_error
# ---------------------------------------------------------------------------


class TestFormatError:
    def test_basic_error(self, config: ToolServerConfig) -> None:
        error = ValueError("something went wrong")
        result = json.loads(format_error(config, error))
        assert result["error"] == "ValueError"
        assert result["message"] == "something went wrong"
        assert result["attribution"] == "Test attribution string."

    def test_with_error_type_fn(self, config: ToolServerConfig) -> None:
        error = ValueError("bad")
        result = json.loads(
            format_error(config, error, error_type_fn=lambda _: "bad_request")
        )
        assert result["error"] == "bad_request"

    def test_status_code_from_arg(self, config: ToolServerConfig) -> None:
        error = ValueError("x")
        result = json.loads(format_error(config, error, status_code=404))
        assert result["status_code"] == 404

    def test_status_code_from_error_attr(self, config: ToolServerConfig) -> None:
        error = Exception("x")
        error.status_code = 500  # type: ignore[attr-defined]
        result = json.loads(format_error(config, error))
        assert result["status_code"] == 500

    def test_fca_status_code_fallback(self, config: ToolServerConfig) -> None:
        error = Exception("x")
        error.fca_status_code = "FSR-21"  # type: ignore[attr-defined]
        result = json.loads(format_error(config, error))
        assert result["status_code"] == "FSR-21"

    def test_explicit_status_code_overrides_attr(self, config: ToolServerConfig) -> None:
        error = Exception("x")
        error.status_code = 500  # type: ignore[attr-defined]
        result = json.loads(format_error(config, error, status_code=404))
        assert result["status_code"] == 404

    def test_no_status_code_when_absent(self, config: ToolServerConfig) -> None:
        error = ValueError("x")
        result = json.loads(format_error(config, error))
        assert "status_code" not in result


# ---------------------------------------------------------------------------
# record_call
# ---------------------------------------------------------------------------


class TestRecordCall:
    def test_success(self, metrics: MagicMock) -> None:
        start = time.monotonic()
        record_call(metrics, "test_tool", start, success=True)

        metrics.record_call.assert_called_once()
        args, kwargs = metrics.record_call.call_args
        assert args[0] == "test_tool"
        assert isinstance(args[1], float)
        assert args[1] >= 0
        assert kwargs["success"] is True
        assert kwargs["error_type"] is None
        assert kwargs["error_message"] is None

    def test_failure(self, metrics: MagicMock) -> None:
        start = time.monotonic()
        error = RuntimeError("boom")
        record_call(metrics, "test_tool", start, success=False, error=error)

        metrics.record_call.assert_called_once()
        _, kwargs = metrics.record_call.call_args
        assert kwargs["success"] is False
        assert kwargs["error_type"] == "RuntimeError"
        assert kwargs["error_message"] == "boom"

    def test_error_message_truncated(self, metrics: MagicMock) -> None:
        start = time.monotonic()
        error = RuntimeError("x" * 1000)
        record_call(metrics, "test_tool", start, success=False, error=error)

        _, kwargs = metrics.record_call.call_args
        assert len(kwargs["error_message"]) == 500

    def test_returns_none(self, metrics: MagicMock) -> None:
        result = record_call(metrics, "t", time.monotonic(), success=True)
        assert result is None
