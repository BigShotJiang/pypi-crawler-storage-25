"""Smoke tests — confirm the bartram_foundry package imports cleanly."""

import bartram_foundry


def test_version():
    """The bartram_foundry package has a version string."""
    assert bartram_foundry.__version__ == "0.3.1"


def test_submodule_imports():
    """All bartram_foundry submodules are importable."""
    import bartram_foundry.cache
    import bartram_foundry.cleaning
    import bartram_foundry.http
    import bartram_foundry.monitoring
    import bartram_foundry.types

    # Confirm each module loaded (not just imported).
    modules = [
        bartram_foundry.cache,
        bartram_foundry.cleaning,
        bartram_foundry.http,
        bartram_foundry.monitoring,
        bartram_foundry.types,
    ]
    assert len(modules) == 5


def test_http_module_has_retry():
    """The http module should export retry_request."""
    from bartram_foundry.http import retry_request
    assert callable(retry_request)


def test_types_module_has_uk_address():
    """The types module should export UKAddress."""
    from bartram_foundry.types import UKAddress
    addr = UKAddress(address_line_1="10 Downing Street", postal_code="SW1A 2AA")
    assert "10 Downing Street" in addr.one_line
