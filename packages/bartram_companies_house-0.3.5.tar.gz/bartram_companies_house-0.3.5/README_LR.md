# UK Land Registry MCP Server

Clean, structured UK property data for AI agents — via the [Model Context Protocol](https://modelcontextprotocol.io/).

<!-- mcp-name: io.github.RobertAlsop/land-registry -->

## What this does

This MCP server gives agents access to 8 HM Land Registry endpoints — property price history, house price indices, and corporate/overseas land ownership — with data cleaning that the raw API doesn't provide.

Land Registry data has known quality issues: addresses arrive in ALL CAPS, date formats are inconsistent, property type codes need decoding, and UK House Price Index data requires fetching across multiple SPARQL queries. This server fixes those problems before the data reaches your agent.

**What the cleaning layer does:**

- **Address normalisation** — ALL CAPS addresses converted to Title Case throughout.
- **Property type decoding** — raw codes (D/S/T/F/O) and URIs mapped to readable labels (Detached, Semi-detached, Terraced, Flat, Other).
- **Duration decoding** — F/L mapped to Freehold/Leasehold.
- **Date normalisation** — consistent YYYY-MM-DD format across all endpoints.
- **Postcode standardisation** — normalised to standard spaced format (e.g. `SW1A 1AA`).
- **`_cleaning` annotations** — each item includes a `_cleaning` dict recording exactly which transformations were applied.

## Tools available

| Tool | Description |
|------|-------------|
| `uk_land_registry_price_paid_search` | Search price paid transactions by postcode, street, town, price range, or property type |
| `uk_land_registry_price_paid_postcode` | Get all transactions for a specific postcode |
| `uk_land_registry_price_paid_address` | Full transaction history for a specific address |
| `uk_land_registry_transaction_detail` | Detailed record for a single transaction ID |
| `uk_land_registry_ukhpi_region` | House Price Index time series for a UK region |
| `uk_land_registry_ukhpi_latest` | Latest HPI snapshot across all standard regions |
| `uk_land_registry_company_ownership` | UK companies that own land/property (ULPD, requires API key) |
| `uk_land_registry_overseas_ownership` | Overseas entities that own UK land/property (ULPD, requires API key) |

## Data sources

- **Price Paid Data (PPD)** — HM Land Registry Open Data via SPARQL endpoint. No authentication required.
- **UK House Price Index (UKHPI)** — HM Land Registry Open Data via SPARQL endpoint. No authentication required.
- **CCOD/OCOD (ULPD)** — Use Land Property Data REST API. Requires `ULPD_API_KEY` env var. Register at https://use-land-property-data.service.gov.uk/

All data is licensed under the [Open Government Licence v3.0](https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/).

## Installation

```bash
pip install bartram-companies-house>=0.3.5
```

## Configuration (Claude Desktop / Claude Code)

```json
{
  "mcpServers": {
    "land-registry": {
      "command": "bartram-land-registry",
      "env": {
        "ULPD_API_KEY": "your-key-here"
      }
    }
  }
}
```

The SPARQL-backed tools (price paid, UKHPI) work without any API key. The ULPD ownership tools require registration at https://use-land-property-data.service.gov.uk/.

## Data licence

Contains HM Land Registry data © Crown copyright and database right 2024. This data is licensed under the [Open Government Licence v3.0](https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/).
