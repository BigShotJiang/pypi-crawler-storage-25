"""HM Land Registry MCP tool — Price Paid, UKHPI, CCOD, and OCOD datasets."""

__version__ = "0.3.5"
