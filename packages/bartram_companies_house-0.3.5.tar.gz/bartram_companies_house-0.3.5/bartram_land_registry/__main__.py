"""Entry point for running the Land Registry MCP server."""

from bartram_land_registry.serve import main

if __name__ == "__main__":
    main()
