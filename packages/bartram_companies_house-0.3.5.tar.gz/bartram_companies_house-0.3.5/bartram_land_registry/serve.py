"""HM Land Registry MCP server — 8 tools.

Tools:
  uk_land_registry_price_paid_search    — Search transactions by postcode/street/town
  uk_land_registry_price_paid_postcode  — All transactions in a specific postcode
  uk_land_registry_price_paid_address   — Transaction history for a specific property
  uk_land_registry_ukhpi_region         — UKHPI time series for a region
  uk_land_registry_ukhpi_latest         — Latest UKHPI values across all regions
  uk_land_registry_company_ownership    — CCOD company property ownership (requires ULPD_API_KEY)
  uk_land_registry_overseas_ownership   — OCOD overseas entity ownership (requires ULPD_API_KEY)
  uk_land_registry_transaction_detail   — Full detail for a single transaction
"""

from __future__ import annotations

import threading
import time

from mcp.server import FastMCP

from bartram_foundry.monitoring import MetricsStore
from bartram_foundry.serve_helpers import (
    ToolServerConfig,
    format_error,
    format_response,
    record_call,
)
from bartram_land_registry import clean as _clean
from bartram_land_registry.access import (
    AuthenticationError,
    BadRequestError,
    LandRegistryClient,
    LandRegistryError,
    NotFoundError,
    QueryTimeoutError,
    RateLimitError,
)

# ---------------------------------------------------------------------------
# Server + configuration
# ---------------------------------------------------------------------------

server = FastMCP("bartram-land-registry")

_CONFIG = ToolServerConfig(
    source_name="HM Land Registry Open Data & Use Land Property Data API",
    licence="Open Government Licence v3",
    attribution=(
        "Contains HM Land Registry data © Crown copyright and database right 2026. "
        "Licensed under the Open Government Licence v3.0."
    ),
)

_metrics = MetricsStore()

# ---------------------------------------------------------------------------
# Lazy client initialisation
# ---------------------------------------------------------------------------

_client: LandRegistryClient | None = None
_client_lock = threading.Lock()


def _get_client() -> LandRegistryClient:
    global _client
    if _client is None:
        with _client_lock:
            if _client is None:
                _client = LandRegistryClient()
    return _client


# ---------------------------------------------------------------------------
# Error type classifier
# ---------------------------------------------------------------------------

def _error_type(exc: Exception) -> str:
    if isinstance(exc, NotFoundError):
        return "not_found"
    if isinstance(exc, AuthenticationError):
        return "authentication_error"
    if isinstance(exc, RateLimitError):
        return "rate_limited"
    if isinstance(exc, QueryTimeoutError):
        return "timeout"
    if isinstance(exc, BadRequestError):
        return "validation_error"
    if isinstance(exc, LandRegistryError):
        return "api_error"
    return "internal_error"


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

@server.tool()
def uk_land_registry_price_paid_search(
    postcode: str = "",
    street: str = "",
    town: str = "",
    min_price: int = 0,
    max_price: int = 0,
    property_type: str = "",
    from_date: str = "",
    to_date: str = "",
    limit: int = 50,
) -> str:
    """Search HM Land Registry Price Paid Data by postcode, street, or town.

    Returns property transactions matching the filters. At least one of postcode,
    street, or town must be provided. Addresses are normalised from UPPER CASE to
    Title Case. Property type codes (D/S/T/F/O) are mapped to human-readable values.

    Args:
        postcode: UK postcode (e.g. 'SW1A 1AA'). Normalised internally.
        street: Street name or partial name.
        town: Town or city name.
        min_price: Minimum transaction price in GBP.
        max_price: Maximum transaction price in GBP.
        property_type: 'detached', 'semi-detached', 'terraced', 'flat', or 'other'.
        from_date: Transaction date from (YYYY-MM-DD).
        to_date: Transaction date to (YYYY-MM-DD).
        limit: Max results (1-200, default 50).
    """
    start = time.monotonic()
    client = _get_client()
    try:
        raw = client.price_paid_search(
            postcode=postcode.strip() or None,
            street=street.strip() or None,
            town=town.strip() or None,
            min_price=min_price if min_price > 0 else None,
            max_price=max_price if max_price > 0 else None,
            property_type=property_type.strip() or None,
            from_date=from_date.strip() or None,
            to_date=to_date.strip() or None,
            limit=limit,
        )
        data = _clean.clean_price_paid_search(raw)
        record_call(_metrics, "uk_land_registry_price_paid_search", start, success=True)
        return format_response(
            _CONFIG,
            data,
            endpoint="/landregistry/query (SPARQL)",
        )
    except Exception as exc:
        record_call(
            _metrics, "uk_land_registry_price_paid_search", start, success=False, error=exc
        )
        return format_error(_CONFIG, exc, error_type_fn=_error_type)


@server.tool()
def uk_land_registry_price_paid_postcode(
    postcode: str,
    from_date: str = "",
    to_date: str = "",
    limit: int = 100,
) -> str:
    """Get all property transactions in a specific UK postcode.

    Args:
        postcode: UK postcode (required).
        from_date: Filter from date (YYYY-MM-DD).
        to_date: Filter to date (YYYY-MM-DD).
        limit: Max results (1-200, default 100).
    """
    start = time.monotonic()
    client = _get_client()
    try:
        raw = client.price_paid_postcode(
            postcode=postcode,
            from_date=from_date.strip() or None,
            to_date=to_date.strip() or None,
            limit=limit,
        )
        data = _clean.clean_price_paid_postcode(raw, postcode)
        record_call(_metrics, "uk_land_registry_price_paid_postcode", start, success=True)
        return format_response(
            _CONFIG,
            data,
            endpoint="/landregistry/query (SPARQL)",
        )
    except Exception as exc:
        record_call(
            _metrics, "uk_land_registry_price_paid_postcode", start, success=False, error=exc
        )
        return format_error(_CONFIG, exc, error_type_fn=_error_type)


@server.tool()
def uk_land_registry_price_paid_address(
    house_number_or_name: str,
    street: str,
    postcode: str,
) -> str:
    """Get the complete transaction history for a specific property address.

    Returns all recorded sales at the address, sorted newest first. Requires
    house number/name, street, and postcode for unambiguous matching.

    Args:
        house_number_or_name: House number or name (e.g. '42' or 'Hillside Villa').
        street: Street name.
        postcode: UK postcode.
    """
    start = time.monotonic()
    client = _get_client()
    try:
        raw = client.price_paid_address(
            house_number_or_name=house_number_or_name,
            street=street,
            postcode=postcode,
        )
        data = _clean.clean_price_paid_address(raw, house_number_or_name, street, postcode)
        record_call(_metrics, "uk_land_registry_price_paid_address", start, success=True)
        return format_response(
            _CONFIG,
            data,
            endpoint="/landregistry/query (SPARQL)",
        )
    except Exception as exc:
        record_call(
            _metrics, "uk_land_registry_price_paid_address", start, success=False, error=exc
        )
        return format_error(_CONFIG, exc, error_type_fn=_error_type)


@server.tool()
def uk_land_registry_ukhpi_region(
    region: str,
    from_date: str = "",
    to_date: str = "",
    property_type: str = "all",
) -> str:
    """Get UK House Price Index data for a specific region over time.

    Args:
        region: Region slug — 'england', 'london', 'south-east', 'east-anglia',
            'south-west', 'west-midlands', 'east-midlands', 'yorkshire',
            'north-west', 'north', 'wales', 'scotland', 'northern-ireland'.
        from_date: Data from date (YYYY-MM-DD).
        to_date: Data to date (YYYY-MM-DD).
        property_type: 'all', 'detached', 'semi-detached', 'terraced', 'flat' (default 'all').
    """
    start = time.monotonic()
    client = _get_client()
    try:
        raw = client.ukhpi_region(
            region=region,
            from_date=from_date.strip() or None,
            to_date=to_date.strip() or None,
            property_type=property_type or "all",
        )
        data = _clean.clean_ukhpi_region(raw, region.strip().lower(), property_type or "all")
        record_call(_metrics, "uk_land_registry_ukhpi_region", start, success=True)
        return format_response(
            _CONFIG,
            data,
            endpoint=f"/data/ukhpi/region/{region}",
        )
    except Exception as exc:
        record_call(_metrics, "uk_land_registry_ukhpi_region", start, success=False, error=exc)
        return format_error(_CONFIG, exc, error_type_fn=_error_type)


@server.tool()
def uk_land_registry_ukhpi_latest(
    property_type: str = "all",
) -> str:
    """Get the latest UK House Price Index values across all regions.

    Args:
        property_type: 'all', 'detached', 'semi-detached', 'terraced', 'flat' (default 'all').
    """
    start = time.monotonic()
    client = _get_client()
    try:
        raw = client.ukhpi_latest(property_type=property_type or "all")
        data = _clean.clean_ukhpi_latest(raw, property_type or "all")
        record_call(_metrics, "uk_land_registry_ukhpi_latest", start, success=True)
        return format_response(
            _CONFIG,
            data,
            endpoint="/data/ukhpi/region",
        )
    except Exception as exc:
        record_call(_metrics, "uk_land_registry_ukhpi_latest", start, success=False, error=exc)
        return format_error(_CONFIG, exc, error_type_fn=_error_type)


@server.tool()
def uk_land_registry_company_ownership(
    company_name: str = "",
    company_number: str = "",
    postcode: str = "",
    limit: int = 50,
) -> str:
    """Search the CCOD (Companies that Own Property in England and Wales) dataset.

    Requires ULPD_API_KEY environment variable. Register at
    https://use-land-property-data.service.gov.uk/ to obtain a key.

    Args:
        company_name: Company name or partial name.
        company_number: Companies House registration number (auto zero-padded to 8 chars).
        postcode: Property postcode.
        limit: Max results (1-100, default 50).
    """
    start = time.monotonic()
    client = _get_client()
    try:
        raw = client.company_ownership(
            company_name=company_name.strip() or None,
            company_number=company_number.strip() or None,
            postcode=postcode.strip() or None,
            limit=limit,
        )
        data = _clean.clean_company_ownership(raw)
        record_call(_metrics, "uk_land_registry_company_ownership", start, success=True)
        return format_response(
            _CONFIG,
            data,
            endpoint="/api/v1/companies (ULPD)",
        )
    except Exception as exc:
        record_call(
            _metrics, "uk_land_registry_company_ownership", start, success=False, error=exc
        )
        return format_error(_CONFIG, exc, error_type_fn=_error_type)


@server.tool()
def uk_land_registry_overseas_ownership(
    entity_name: str = "",
    country: str = "",
    postcode: str = "",
    limit: int = 50,
) -> str:
    """Search the OCOD (Overseas Companies that Own Property in England and Wales) dataset.

    Requires ULPD_API_KEY environment variable. Register at
    https://use-land-property-data.service.gov.uk/ to obtain a key.

    Args:
        entity_name: Entity name or partial name.
        country: Country of incorporation (e.g. 'United States', 'Singapore').
        postcode: Property postcode.
        limit: Max results (1-100, default 50).
    """
    start = time.monotonic()
    client = _get_client()
    try:
        raw = client.overseas_ownership(
            entity_name=entity_name.strip() or None,
            country=country.strip() or None,
            postcode=postcode.strip() or None,
            limit=limit,
        )
        data = _clean.clean_overseas_ownership(raw)
        record_call(_metrics, "uk_land_registry_overseas_ownership", start, success=True)
        return format_response(
            _CONFIG,
            data,
            endpoint="/api/v1/overseas (ULPD)",
        )
    except Exception as exc:
        record_call(
            _metrics, "uk_land_registry_overseas_ownership", start, success=False, error=exc
        )
        return format_error(_CONFIG, exc, error_type_fn=_error_type)


@server.tool()
def uk_land_registry_transaction_detail(transaction_id: str) -> str:
    """Get full details of a specific property transaction by its unique identifier.

    Transaction IDs are returned by the price_paid_* tools.

    Args:
        transaction_id: Transaction unique identifier (from price paid search results).
    """
    start = time.monotonic()
    client = _get_client()
    try:
        rows = client.transaction_detail(transaction_id=transaction_id)
        if not rows:
            raise NotFoundError(f"Transaction {transaction_id!r} not found.")
        data = _clean.clean_transaction_detail(rows, transaction_id)
        record_call(_metrics, "uk_land_registry_transaction_detail", start, success=True)
        return format_response(
            _CONFIG,
            data,
            endpoint="/landregistry/query (SPARQL)",
        )
    except Exception as exc:
        record_call(
            _metrics, "uk_land_registry_transaction_detail", start, success=False, error=exc
        )
        return format_error(_CONFIG, exc, error_type_fn=_error_type)


def main() -> None:
    server.run()


if __name__ == "__main__":
    main()
