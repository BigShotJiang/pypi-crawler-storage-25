"""HM Land Registry data cleaning layer.

Cleaning operations:
- Address normalisation: UPPER CASE → Title Case (Price Paid Data)
- Property type code mapping: D/S/T/F/O → human-readable
- Duration (tenure) code mapping: F/L → Freehold/Leasehold
- PPD category code mapping: A/B → Standard/Additional Price
- Postcode normalisation: standard spaced format
- UKHPI: date normalisation, index value rounding
- ULPD: company number zero-padding, Unicode normalisation, property count
"""

from __future__ import annotations

import re
import unicodedata
from typing import Any

# ---------------------------------------------------------------------------
# Code maps
# ---------------------------------------------------------------------------

_PROPERTY_TYPE_MAP = {
    "D": "Detached",
    "S": "Semi-detached",
    "T": "Terraced",
    "F": "Flat",
    "O": "Other",
    # SPARQL returns full URI fragments — handle both forms
    "detached": "Detached",
    "semidetached": "Semi-detached",
    "semiDetached": "Semi-detached",
    "terraced": "Terraced",
    "flat": "Flat",
    "otherOrUnknown": "Other",
}

_DURATION_MAP = {
    "F": "Freehold",
    "L": "Leasehold",
    "freehold": "Freehold",
    "leasehold": "Leasehold",
}

_PPD_CATEGORY_MAP = {
    "A": "Standard Price",
    "B": "Additional Price",
    "additionalPricePaidTransaction": "Additional Price",
    "standardPricePaidEntry": "Standard Price",
    "standardPricePaidTransaction": "Standard Price",
}

# Regex for standard UK postcode spacing.
_POSTCODE_RE = re.compile(
    r"^([A-Z]{1,2}[0-9]{1,2}[A-Z]?)\s*([0-9][A-Z]{2})$", re.IGNORECASE
)


# ---------------------------------------------------------------------------
# Low-level helpers
# ---------------------------------------------------------------------------

def _normalise_address(raw: str | None) -> tuple[str | None, bool]:
    """Convert an UPPER CASE address string to Title Case.

    Returns (normalised_value, changed_flag).
    """
    if not raw:
        return raw, False
    if raw == raw.upper() and not raw.replace(" ", "").isnumeric():
        normalised = raw.title()
        return normalised, normalised != raw
    return raw, False


def _normalise_postcode(raw: str | None) -> tuple[str | None, bool]:
    """Ensure postcode has standard single space (e.g. 'SW1A 1AA').

    Returns (normalised_value, changed_flag). Returns original if unrecognised.
    """
    if not raw:
        return raw, False
    cleaned = raw.strip().upper().replace(" ", "")
    m = _POSTCODE_RE.match(cleaned)
    if not m:
        return raw, False
    normalised = f"{m.group(1)} {m.group(2)}"
    return normalised, normalised != raw.strip().upper()


def _extract_code_from_uri(uri: str | None) -> str:
    """Extract the local name from a URI fragment (after '#' or last '/')."""
    if not uri:
        return ""
    if "#" in uri:
        return uri.split("#")[-1]
    return uri.rstrip("/").split("/")[-1]


def _map_property_type(raw_uri: str | None) -> tuple[str, str]:
    """Return (human_readable, original_code) for a property type URI or code."""
    code = _extract_code_from_uri(raw_uri)
    # Try single-char code first, then full fragment name.
    human = _PROPERTY_TYPE_MAP.get(code, _PROPERTY_TYPE_MAP.get(code.upper(), "Unknown"))
    return human, code


def _map_duration(raw_uri: str | None) -> tuple[str, str]:
    """Return (human_readable, original_code) for a duration/tenure URI or code."""
    code = _extract_code_from_uri(raw_uri)
    human = _DURATION_MAP.get(code, _DURATION_MAP.get(code.upper(), "Unknown"))
    return human, code


def _map_ppd_category(raw_uri: str | None) -> tuple[str, str]:
    """Return (human_readable, original_code) for a PPD category URI or code."""
    code = _extract_code_from_uri(raw_uri)
    human = _PPD_CATEGORY_MAP.get(code, _PPD_CATEGORY_MAP.get(code.upper(), "Unknown"))
    return human, code


def _normalise_unicode(raw: str | None) -> tuple[str | None, bool]:
    """NFC-normalise a Unicode string. Returns (normalised, changed_flag)."""
    if not raw:
        return raw, False
    normalised = unicodedata.normalize("NFC", raw)
    return normalised, normalised != raw


def _pad_company_number(raw: str | None) -> tuple[str | None, bool]:
    """Zero-pad a Companies House number to 8 characters."""
    if not raw:
        return raw, False
    padded = raw.strip().zfill(8)
    return padded, padded != raw.strip()


def _build_address(row: dict[str, Any]) -> str:
    """Assemble a human-readable address from SPARQL PPD row fields."""
    parts = []
    for field in ("paon", "saon", "street", "locality", "town", "county"):
        val = row.get(field)
        if val:
            parts.append(str(val))
    postcode = row.get("postcode", "")
    if postcode:
        parts.append(str(postcode))
    return ", ".join(parts)


# ---------------------------------------------------------------------------
# Price Paid cleaning
# ---------------------------------------------------------------------------

def _clean_ppd_row(row: dict[str, Any]) -> dict[str, Any]:
    """Clean a single SPARQL Price Paid row into the canonical item shape."""
    cleaning: dict[str, Any] = {}

    # Build raw address from parts, then normalise.
    raw_addr = _build_address(row)
    norm_addr, addr_changed = _normalise_address(raw_addr)
    if addr_changed:
        cleaning["address_normalised"] = True

    # Postcode
    raw_postcode = row.get("postcode", "")
    norm_postcode, pc_changed = _normalise_postcode(raw_postcode)
    if pc_changed:
        cleaning["postcode_normalised"] = True

    # Property type
    prop_human, prop_code = _map_property_type(row.get("propertyType"))
    cleaning["property_type_mapped"] = True

    # Duration / tenure
    dur_human, dur_code = _map_duration(row.get("estateType"))
    cleaning["duration_mapped"] = True

    # PPD category
    cat_human, cat_code = _map_ppd_category(row.get("category"))
    cleaning["pricepaid_category_mapped"] = True

    # Price
    try:
        price = int(float(row.get("amount", 0)))
    except (ValueError, TypeError):
        price = 0

    # Transaction date: strip xsd type annotation if present
    raw_date = str(row.get("date", ""))
    trans_date = raw_date.split("^^")[0] if "^^" in raw_date else raw_date

    # Transaction ID: extract from URI
    trans_id = _extract_code_from_uri(row.get("tranid"))

    return {
        "transaction_id": trans_id,
        "address": norm_addr or raw_addr,
        "property_type": prop_human,
        "property_type_code": prop_code,
        "duration": dur_human,
        "duration_code": dur_code,
        "price": price,
        "price_paid_category": cat_human,
        "price_paid_category_code": cat_code,
        "transaction_date": trans_date,
        "postcode": norm_postcode or raw_postcode,
        "_cleaning": cleaning,
    }


def clean_price_paid_search(rows: list[dict[str, Any]]) -> dict[str, Any]:
    """Clean Price Paid search results."""
    items = [_clean_ppd_row(r) for r in rows]
    return {"total_results": len(items), "items": items}


def clean_price_paid_postcode(rows: list[dict[str, Any]], postcode: str) -> dict[str, Any]:
    """Clean Price Paid postcode results."""
    items = [_clean_ppd_row(r) for r in rows]
    norm_pc, _ = _normalise_postcode(postcode)
    return {
        "total_results": len(items),
        "postcode": norm_pc or postcode,
        "items": items,
    }


def clean_price_paid_address(
    rows: list[dict[str, Any]],
    house_number_or_name: str,
    street: str,
    postcode: str,
) -> dict[str, Any]:
    """Clean address transaction history — sorted newest first."""
    items = [_clean_ppd_row(r) for r in rows]
    # Sort descending by date (rows already ordered by SPARQL ORDER BY DESC, but be explicit)
    items.sort(key=lambda x: x.get("transaction_date", ""), reverse=True)

    norm_pc, _ = _normalise_postcode(postcode)
    norm_addr, _ = _normalise_address(f"{house_number_or_name} {street}, {postcode}".upper())

    # Add sort annotation if any items
    if items:
        for item in items:
            item["_cleaning"]["results_sorted_descending"] = True

    return {
        "address": norm_addr,
        "postcode": norm_pc or postcode,
        "total_transactions": len(items),
        "items": items,
    }


def clean_transaction_detail(rows: list[dict[str, Any]], transaction_id: str) -> dict[str, Any]:
    """Clean a single transaction detail record."""
    if not rows:
        return {}

    row = rows[0]
    item = _clean_ppd_row(row)
    item["_cleaning"]["date_normalised"] = True
    item["_cleaning"]["price_formatted"] = True
    item["_cleaning"]["linked_transaction"] = False
    item["transaction_unique_identifier"] = transaction_id
    item["linked_transaction"] = None
    return item


# ---------------------------------------------------------------------------
# UKHPI cleaning
# ---------------------------------------------------------------------------

def _clean_ukhpi_item(item: dict[str, Any]) -> dict[str, Any]:
    """Clean a single UKHPI data point."""
    cleaning: dict[str, Any] = {"date_normalised": True}

    # Date: may be a URI, an xsd:date literal, or a plain string.
    raw_date = item.get("refDate") or item.get("date") or item.get("refPeriod") or ""
    if isinstance(raw_date, dict):
        raw_date = raw_date.get("@value", "") or raw_date.get("value", "")
    date_str = str(raw_date).split("^^")[0].split("T")[0]

    def _safe_float(val: Any) -> float | None:
        try:
            return float(val) if val is not None and val != "" else None
        except (ValueError, TypeError):
            return None

    index_raw = (
        item.get("housePrice")
        or item.get("housePriceIndex")
        or item.get("averagePrice")
    )
    index_val = _safe_float(index_raw)

    annual_raw = item.get("percentageAnnualChange") or item.get("annualChange")
    monthly_raw = item.get("percentageMonthlyChange") or item.get("monthlyChange")
    annual = _safe_float(annual_raw)
    monthly = _safe_float(monthly_raw)

    # Round index value if needed
    if index_val is not None:
        rounded = round(index_val, 1)
        if rounded != index_val:
            cleaning["index_rounded"] = True
        index_val = rounded

    return {
        "date": date_str,
        "index_value": index_val,
        "annual_change_percent": annual,
        "monthly_change_percent": monthly,
    }


def clean_ukhpi_region(
    items: list[dict[str, Any]], region: str, property_type: str
) -> dict[str, Any]:
    """Clean UKHPI regional time series."""
    cleaned = [_clean_ukhpi_item(i) for i in items]
    cleaned.sort(key=lambda x: x.get("date", ""))
    return {
        "region": region,
        "property_type": property_type,
        "items": cleaned,
    }


def clean_ukhpi_latest(items: list[dict[str, Any]], property_type: str) -> dict[str, Any]:
    """Clean latest UKHPI snapshot across all regions."""
    snapshot_date = ""
    regions = []

    for item in items:
        cleaned = _clean_ukhpi_item(item)
        if not snapshot_date and cleaned["date"]:
            snapshot_date = cleaned["date"]
        region_val = item.get("refRegion") or item.get("region") or ""
        if isinstance(region_val, dict):
            region_val = region_val.get("@value", region_val.get("value", ""))
        region_slug = _extract_code_from_uri(str(region_val)).lower()
        regions.append({
            "region": region_slug,
            "index_value": cleaned["index_value"],
            "annual_change_percent": cleaned["annual_change_percent"],
            "monthly_change_percent": cleaned["monthly_change_percent"],
        })

    return {
        "snapshot_date": snapshot_date,
        "property_type": property_type,
        "regions": regions,
    }


# ---------------------------------------------------------------------------
# ULPD ownership cleaning
# ---------------------------------------------------------------------------

def _clean_company_item(raw: dict[str, Any]) -> dict[str, Any]:
    """Clean a single CCOD company ownership record."""
    cleaning: dict[str, Any] = {}

    company_name = raw.get("companyName") or raw.get("company_name") or ""
    norm_name, name_changed = _normalise_unicode(company_name)
    if name_changed:
        cleaning["name_normalised"] = True

    company_num = raw.get("companyRegistrationNo") or raw.get("company_number") or ""
    padded_num, num_padded = _pad_company_number(str(company_num) if company_num else None)
    if num_padded:
        cleaning["company_number_padded"] = True

    postcode = raw.get("postcode") or raw.get("regAddress_PostCode") or ""
    _, pc_changed = _normalise_postcode(str(postcode) if postcode else None)
    if pc_changed:
        cleaning["postcode_normalised"] = True

    properties = raw.get("properties") or raw.get("tenure") or []
    if not isinstance(properties, list):
        properties = [properties] if properties else []
    cleaning["property_count_included"] = True

    samples = []
    for prop in properties[:3]:
        if isinstance(prop, dict):
            prop_addr = prop.get("propertyAddress") or prop.get("address") or ""
            norm_prop_addr, _ = _normalise_address(prop_addr)
            prop_pc = prop.get("postcode") or ""
            norm_prop_pc, _ = _normalise_postcode(str(prop_pc) if prop_pc else None)
            acq = prop.get("dateOfAcquisition") or prop.get("date_of_acquisition") or None
            samples.append({
                "address": norm_prop_addr or prop_addr,
                "postcode": norm_prop_pc or str(prop_pc),
                "date_of_acquisition": acq,
            })

    return {
        "company_name": norm_name or company_name,
        "company_number": padded_num or str(company_num),
        "company_type": raw.get("companyCategory") or raw.get("company_type") or "unknown",
        "properties_owned": len(properties),
        "property_samples": samples,
        "_cleaning": cleaning,
    }


def clean_company_ownership(raw: dict[str, Any]) -> dict[str, Any]:
    """Clean CCOD company ownership response."""
    items_raw = raw.get("results") or raw.get("items") or raw.get("data") or []
    if not isinstance(items_raw, list):
        items_raw = [items_raw] if items_raw else []
    items = [_clean_company_item(r) for r in items_raw]
    return {
        "total_results": raw.get("totalResults") or raw.get("total_results") or len(items),
        "items": items,
    }


def _clean_overseas_item(raw: dict[str, Any]) -> dict[str, Any]:
    """Clean a single OCOD overseas ownership record."""
    cleaning: dict[str, Any] = {}

    entity_name = raw.get("proprietorName") or raw.get("entity_name") or ""
    norm_name, name_changed = _normalise_unicode(entity_name)
    if name_changed:
        cleaning["name_normalised"] = True

    country = raw.get("countryIncorporated") or raw.get("country") or ""
    norm_country = str(country).strip().title() if country else ""
    if norm_country != str(country).strip():
        cleaning["country_normalised"] = True

    postcode = raw.get("postcode") or ""
    _, pc_changed = _normalise_postcode(str(postcode) if postcode else None)
    if pc_changed:
        cleaning["postcode_normalised"] = True

    reg_type = raw.get("registrationType") or raw.get("registration_type") or ""
    if reg_type:
        cleaning["registration_type_mapped"] = True

    properties = raw.get("properties") or raw.get("tenure") or []
    if not isinstance(properties, list):
        properties = [properties] if properties else []

    samples = []
    for prop in properties[:3]:
        if isinstance(prop, dict):
            prop_addr = prop.get("propertyAddress") or prop.get("address") or ""
            norm_prop_addr, _ = _normalise_address(prop_addr)
            prop_pc = prop.get("postcode") or ""
            norm_prop_pc, _ = _normalise_postcode(str(prop_pc) if prop_pc else None)
            samples.append({
                "address": norm_prop_addr or prop_addr,
                "postcode": norm_prop_pc or str(prop_pc),
                "date_of_acquisition": prop.get("dateOfAcquisition") or None,
            })

    return {
        "entity_name": norm_name or entity_name,
        "country": norm_country or str(country),
        "company_number": raw.get("companyRegistrationNo") or raw.get("company_number") or "",
        "properties_owned": len(properties),
        "property_samples": samples,
        "_cleaning": cleaning,
    }


def clean_overseas_ownership(raw: dict[str, Any]) -> dict[str, Any]:
    """Clean OCOD overseas ownership response."""
    items_raw = raw.get("results") or raw.get("items") or raw.get("data") or []
    if not isinstance(items_raw, list):
        items_raw = [items_raw] if items_raw else []
    items = [_clean_overseas_item(r) for r in items_raw]
    return {
        "total_results": raw.get("totalResults") or raw.get("total_results") or len(items),
        "items": items,
    }
