"""HM Land Registry API client.

Two backends:
- SPARQL endpoint: Price Paid Data (PPD) and UK House Price Index (UKHPI)
- ULPD REST API: CCOD (Companies) and OCOD (Overseas) ownership datasets

SPARQL endpoints require no authentication. ULPD requires ULPD_API_KEY env var.
"""

from __future__ import annotations

import contextlib
import os
import re
import time
from pathlib import Path
from typing import Any, ClassVar

import httpx
import yaml

from bartram_foundry.cache import ResponseCache
from bartram_foundry.sparql_client import SPARQLClient, SPARQLQueryError, SPARQLTimeoutError

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

_DEFAULT_CACHE_TTLS: dict[str, int] = {
    "price_paid_search": 86400,
    "price_paid_postcode": 86400,
    "price_paid_address": 86400,
    "ukhpi_region": 86400,
    "ukhpi_latest": 86400,
    "company_ownership": 3600,
    "overseas_ownership": 3600,
    "transaction_detail": 86400,
}

SPARQL_ENDPOINT = "http://landregistry.data.gov.uk/landregistry/query"
REST_BASE_URL = "https://landregistry.data.gov.uk"
ULPD_BASE_URL = "https://use-land-property-data.service.gov.uk/api/v1"

# Valid UKHPI region slugs (must match LR SPARQL URIs exactly).
VALID_REGIONS = {
    "england", "london", "south-east", "east-of-england", "south-west",
    "west-midlands", "east-midlands", "yorkshire-and-the-humber",
    "north-west", "north-east", "wales", "scotland", "northern-ireland",
}

_UKHPI_REGION_BASE = "http://landregistry.data.gov.uk/id/region/"
_UKHPI_PREFIXES = "PREFIX ukhpi: <http://landregistry.data.gov.uk/def/ukhpi/>\n"

VALID_PROPERTY_TYPES = {"all", "detached", "semi-detached", "terraced", "flat"}

# SPARQL prefix block used by all PPD queries.
_PPD_PREFIXES = """\
PREFIX  lrppi: <http://landregistry.data.gov.uk/def/ppi/>
PREFIX  skos:  <http://www.w3.org/2004/02/skos/core#>
PREFIX  lrcommon: <http://landregistry.data.gov.uk/def/common/>
PREFIX  xsd:   <http://www.w3.org/2001/XMLSchema#>
PREFIX  rdf:   <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
"""


def _load_config() -> dict[str, Any]:
    config_path = Path(__file__).parent / "config.yaml"
    if config_path.exists():
        with open(config_path) as f:
            return yaml.safe_load(f) or {}
    return {}


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class LandRegistryError(Exception):
    """Base exception for Land Registry client errors."""


class NotFoundError(LandRegistryError):
    """Raised when a requested resource does not exist."""

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.status_code = 404


class AuthenticationError(LandRegistryError):
    """Raised when the ULPD API key is missing or invalid."""

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.status_code = 401


class RateLimitError(LandRegistryError):
    """Raised when rate limit is exceeded."""

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.status_code = 429


class BadRequestError(LandRegistryError):
    """Raised for invalid input parameters."""

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.status_code = 400


class QueryTimeoutError(LandRegistryError):
    """Raised when a SPARQL query times out."""

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.status_code = 504


# ---------------------------------------------------------------------------
# Postcode normalisation (access layer — for SPARQL filter construction)
# ---------------------------------------------------------------------------

_POSTCODE_RE = re.compile(
    r"^([A-Z]{1,2}[0-9]{1,2}[A-Z]?)\s*([0-9][A-Z]{2})$", re.IGNORECASE
)


def _normalise_postcode(raw: str) -> str:
    """Normalise a UK postcode to standard spaced format (e.g. 'SW1A 1AA').

    Raises BadRequestError if the format is unrecognisable.
    """
    cleaned = raw.strip().upper().replace(" ", "")
    m = _POSTCODE_RE.match(cleaned)
    if not m:
        raise BadRequestError(f"Invalid UK postcode: '{raw}'")
    return f"{m.group(1)} {m.group(2)}"


def _validate_date(date_str: str) -> None:
    import re as _re
    if not _re.match(r"^\d{4}-\d{2}-\d{2}$", date_str):
        raise BadRequestError(f"Date must be YYYY-MM-DD, got: '{date_str}'")


# ---------------------------------------------------------------------------
# PPD SPARQL query builder
# ---------------------------------------------------------------------------

def _build_ppd_select_query(
    *,
    postcode: str | None = None,
    street: str | None = None,
    town: str | None = None,
    paon: str | None = None,
    min_price: int | None = None,
    max_price: int | None = None,
    property_type_code: str | None = None,
    from_date: str | None = None,
    to_date: str | None = None,
    transaction_id: str | None = None,
    limit: int = 50,
    offset: int = 0,
) -> str:
    filters: list[str] = []

    if transaction_id:
        filters.append(f'FILTER(STR(?tranid) = "{transaction_id}")')
    if postcode:
        norm = postcode.strip().upper()
        filters.append(f'FILTER(STR(?postcode) = "{norm}")')
    if paon:
        filters.append(f'FILTER(CONTAINS(LCASE(STR(?paon)), LCASE("{paon}")))')
    if street:
        filters.append(f'FILTER(CONTAINS(LCASE(STR(?street)), LCASE("{street}")))')
    if town:
        filters.append(f'FILTER(CONTAINS(LCASE(STR(?town)), LCASE("{town}")))')
    if min_price is not None:
        filters.append(f"FILTER(?amount >= {min_price})")
    if max_price is not None:
        filters.append(f"FILTER(?amount <= {max_price})")
    if property_type_code:
        filters.append(
            f'FILTER(?propertyType = lrcommon:{property_type_code})'
        )
    if from_date:
        filters.append(f'FILTER(?date >= "{from_date}"^^xsd:date)')
    if to_date:
        filters.append(f'FILTER(?date <= "{to_date}"^^xsd:date)')

    filter_block = "\n  ".join(filters)

    return (
        f"{_PPD_PREFIXES}\n"
        "SELECT ?tranid ?paon ?saon ?street ?locality ?town ?county ?postcode\n"
        "       ?amount ?date ?propertyType ?estateType ?category\n"
        "WHERE {\n"
        "  ?tranid lrppi:pricePaid ?amount ;\n"
        "          lrppi:transactionDate ?date ;\n"
        "          lrppi:propertyAddress ?addr ;\n"
        "          lrppi:propertyType ?propertyType ;\n"
        "          lrppi:estateType ?estateType ;\n"
        "          lrppi:transactionCategory ?category .\n"
        "  ?addr lrcommon:postcode ?postcode .\n"
        "  OPTIONAL { ?addr lrcommon:paon ?paon }\n"
        "  OPTIONAL { ?addr lrcommon:saon ?saon }\n"
        "  OPTIONAL { ?addr lrcommon:street ?street }\n"
        "  OPTIONAL { ?addr lrcommon:locality ?locality }\n"
        "  OPTIONAL { ?addr lrcommon:town ?town }\n"
        "  OPTIONAL { ?addr lrcommon:county ?county }\n"
        f"  {filter_block}\n"
        "}\n"
        f"ORDER BY DESC(?date)\n"
        f"LIMIT {limit}\n"
        f"OFFSET {offset}\n"
    )


# ---------------------------------------------------------------------------
# Main client
# ---------------------------------------------------------------------------


class LandRegistryClient:
    """Combined client for HM Land Registry SPARQL and ULPD REST APIs."""

    NAMESPACE = "land_registry"

    def __init__(
        self,
        *,
        cache_enabled: bool = True,
        ulpd_api_key: str | None = None,
    ) -> None:
        config = _load_config()
        self._cache_ttls = config.get("cache", {}).get("ttl_seconds", _DEFAULT_CACHE_TTLS)
        sparql_cfg = config.get("sparql", {})
        rest_cfg = config.get("rest", {})
        ulpd_cfg = config.get("ulpd", {})

        self._cache: ResponseCache | None = ResponseCache() if cache_enabled else None

        self._sparql = SPARQLClient(
            endpoint=sparql_cfg.get("endpoint", SPARQL_ENDPOINT),
            timeout_seconds=sparql_cfg.get("timeout_seconds", 30),
            backoff_seconds=sparql_cfg.get("backoff_seconds", 1),
        )
        self._sparql_max_results = sparql_cfg.get("max_results", 1000)

        rest_timeout = rest_cfg.get("timeout_seconds", 30)
        self._rest_client = httpx.Client(
            base_url=REST_BASE_URL,
            timeout=rest_timeout,
            headers={"Accept": "application/json"},
        )

        # ULPD API key — may be absent (tools will error cleanly at call time).
        key_env = ulpd_cfg.get("api_key_env", "ULPD_API_KEY")
        self._ulpd_api_key: str | None = ulpd_api_key or os.environ.get(key_env)
        self._ulpd_backoff = ulpd_cfg.get("backoff_seconds", 0.1)
        self._ulpd_last_request: float = 0.0
        self._ulpd_client = httpx.Client(
            base_url=ULPD_BASE_URL,
            timeout=30,
            headers={"Accept": "application/json"},
        )

    # ------------------------------------------------------------------
    # Cache helpers
    # ------------------------------------------------------------------

    def _cache_get(
        self, endpoint_key: str, params: dict[str, Any] | None = None
    ) -> dict[str, Any] | None:
        if self._cache is None:
            return None
        return self._cache.get(self.NAMESPACE, endpoint_key, params)

    def _cache_put(
        self,
        endpoint_key: str,
        response: dict[str, Any],
        params: dict[str, Any] | None = None,
    ) -> None:
        if self._cache is None:
            return
        ttl = self._cache_ttls.get(endpoint_key, 3600)
        # Suppress cache write failures — large responses can exceed SQLite limits
        # (EA Lesson 15: catchment CSV overflow). Don't let a cache write break the call.
        with contextlib.suppress(Exception):
            self._cache.put(self.NAMESPACE, endpoint_key, response, ttl_seconds=ttl, params=params)

    # ------------------------------------------------------------------
    # ULPD REST helper
    # ------------------------------------------------------------------

    def _require_ulpd_key(self) -> str:
        if not self._ulpd_api_key:
            raise AuthenticationError(
                "ULPD_API_KEY environment variable is not set. "
                "Register at https://use-land-property-data.service.gov.uk/ to obtain an API key."
            )
        return self._ulpd_api_key

    def _ulpd_throttle(self) -> None:
        elapsed = time.monotonic() - self._ulpd_last_request
        if elapsed < self._ulpd_backoff:
            time.sleep(self._ulpd_backoff - elapsed)

    def _ulpd_get(self, path: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        api_key = self._require_ulpd_key()
        self._ulpd_throttle()
        try:
            response = self._ulpd_client.get(
                path,
                params=params,
                headers={"Authorization": f"Bearer {api_key}"},
            )
        finally:
            self._ulpd_last_request = time.monotonic()

        if response.status_code == 401:
            raise AuthenticationError("ULPD API key invalid or expired.")
        if response.status_code == 429:
            raise RateLimitError("ULPD API rate limit exceeded — please retry later.")
        if response.status_code == 404:
            raise NotFoundError(f"ULPD resource not found: {path}")
        if response.status_code >= 400:
            raise LandRegistryError(
                f"ULPD API error {response.status_code}: {response.text[:200]}"
            )

        return response.json()

    # ------------------------------------------------------------------
    # SPARQL helpers
    # ------------------------------------------------------------------

    def _run_sparql(self, query: str) -> list[dict[str, Any]]:
        try:
            return self._sparql.query(query)
        except SPARQLTimeoutError as exc:
            raise QueryTimeoutError(str(exc)) from exc
        except SPARQLQueryError as exc:
            raise LandRegistryError(str(exc)) from exc

    def _run_sparql_paginated(
        self, template: str, limit: int
    ) -> list[dict[str, Any]]:
        try:
            return self._sparql.query_paginated(
                template, limit=limit, max_results=self._sparql_max_results
            )
        except SPARQLTimeoutError as exc:
            raise QueryTimeoutError(str(exc)) from exc
        except SPARQLQueryError as exc:
            raise LandRegistryError(str(exc)) from exc

    # ------------------------------------------------------------------
    # Property type input → SPARQL code mapping
    # ------------------------------------------------------------------

    _PROP_TYPE_INPUT_MAP: ClassVar[dict[str, str]] = {
        "detached": "detached",
        "semi-detached": "semiDetached",
        "terraced": "terraced",
        "flat": "flat",
        "other": "otherOrUnknown",
    }

    # ------------------------------------------------------------------
    # Price Paid endpoints
    # ------------------------------------------------------------------

    def price_paid_search(
        self,
        *,
        postcode: str | None = None,
        street: str | None = None,
        town: str | None = None,
        min_price: int | None = None,
        max_price: int | None = None,
        property_type: str | None = None,
        from_date: str | None = None,
        to_date: str | None = None,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        if not any([postcode, street, town]):
            raise BadRequestError(
                "At least one of postcode, street, or town must be provided."
            )
        limit = min(max(1, limit), 200)

        norm_postcode: str | None = None
        if postcode:
            norm_postcode = _normalise_postcode(postcode)
        if from_date:
            _validate_date(from_date)
        if to_date:
            _validate_date(to_date)
        if min_price is not None and min_price < 0:
            raise BadRequestError("min_price must be a positive integer.")
        if max_price is not None and max_price < 0:
            raise BadRequestError("max_price must be a positive integer.")

        prop_code: str | None = None
        if property_type:
            prop_type_lower = property_type.lower()
            if prop_type_lower not in self._PROP_TYPE_INPUT_MAP:
                raise BadRequestError(
                    f"Unknown property_type '{property_type}'. "
                    "Use: detached, semi-detached, terraced, flat, other."
                )
            prop_code = self._PROP_TYPE_INPUT_MAP[prop_type_lower]

        cache_params = {
            "postcode": norm_postcode,
            "street": street,
            "town": town,
            "min_price": min_price,
            "max_price": max_price,
            "property_type": property_type,
            "from_date": from_date,
            "to_date": to_date,
            "limit": limit,
        }
        cached = self._cache_get("price_paid_search", cache_params)
        if cached is not None:
            return cached  # type: ignore[return-value]

        template = _build_ppd_select_query(
            postcode=norm_postcode,
            street=street,
            town=town,
            min_price=min_price,
            max_price=max_price,
            property_type_code=prop_code,
            from_date=from_date,
            to_date=to_date,
            limit="__LIMIT__",
            offset="__OFFSET__",
        )
        rows = self._run_sparql_paginated(template, limit=limit)
        self._cache_put("price_paid_search", rows, cache_params)  # type: ignore[arg-type]
        return rows

    def price_paid_postcode(
        self,
        *,
        postcode: str,
        from_date: str | None = None,
        to_date: str | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        if not postcode or not postcode.strip():
            raise BadRequestError("postcode is required.")
        norm_postcode = _normalise_postcode(postcode)
        limit = min(max(1, limit), 200)
        if from_date:
            _validate_date(from_date)
        if to_date:
            _validate_date(to_date)

        cache_params = {
            "postcode": norm_postcode,
            "from_date": from_date,
            "to_date": to_date,
            "limit": limit,
        }
        cached = self._cache_get("price_paid_postcode", cache_params)
        if cached is not None:
            return cached  # type: ignore[return-value]

        template = _build_ppd_select_query(
            postcode=norm_postcode,
            from_date=from_date,
            to_date=to_date,
            limit="__LIMIT__",
            offset="__OFFSET__",
        )
        rows = self._run_sparql_paginated(template, limit=limit)
        self._cache_put("price_paid_postcode", rows, cache_params)  # type: ignore[arg-type]
        return rows

    def price_paid_address(
        self,
        *,
        house_number_or_name: str,
        street: str,
        postcode: str,
    ) -> list[dict[str, Any]]:
        if not house_number_or_name.strip():
            raise BadRequestError("house_number_or_name is required.")
        if not street.strip():
            raise BadRequestError("street is required.")
        if not postcode.strip():
            raise BadRequestError("postcode is required.")

        norm_postcode = _normalise_postcode(postcode)

        cache_params = {
            "paon": house_number_or_name.strip(),
            "street": street.strip(),
            "postcode": norm_postcode,
        }
        cached = self._cache_get("price_paid_address", cache_params)
        if cached is not None:
            return cached  # type: ignore[return-value]

        query = _build_ppd_select_query(
            postcode=norm_postcode,
            street=street.strip(),
            paon=house_number_or_name.strip(),
            limit=200,
            offset=0,
        )
        rows = self._run_sparql(query)
        self._cache_put("price_paid_address", rows, cache_params)  # type: ignore[arg-type]
        return rows

    def transaction_detail(self, *, transaction_id: str) -> list[dict[str, Any]]:
        if not transaction_id.strip():
            raise BadRequestError("transaction_id is required.")

        cache_params = {"transaction_id": transaction_id.strip()}
        cached = self._cache_get("transaction_detail", cache_params)
        if cached is not None:
            return cached  # type: ignore[return-value]

        query = _build_ppd_select_query(
            transaction_id=transaction_id.strip(),
            limit=1,
            offset=0,
        )
        rows = self._run_sparql(query)
        self._cache_put("transaction_detail", rows, cache_params)  # type: ignore[arg-type]
        return rows

    # ------------------------------------------------------------------
    # UKHPI REST endpoints
    # ------------------------------------------------------------------

    def ukhpi_region(
        self,
        *,
        region: str,
        from_date: str | None = None,
        to_date: str | None = None,
        property_type: str = "all",
    ) -> list[dict[str, Any]]:
        region_lower = region.strip().lower()
        if region_lower not in VALID_REGIONS:
            raise BadRequestError(
                f"Unknown region '{region}'. "
                f"Valid regions: {', '.join(sorted(VALID_REGIONS))}."
            )
        prop_type_lower = property_type.strip().lower()
        if prop_type_lower not in VALID_PROPERTY_TYPES:
            raise BadRequestError(
                f"Unknown property_type '{property_type}'. "
                f"Valid values: {', '.join(sorted(VALID_PROPERTY_TYPES))}."
            )
        if from_date:
            _validate_date(from_date)
        if to_date:
            _validate_date(to_date)

        cache_params = {
            "region": region_lower,
            "from_date": from_date,
            "to_date": to_date,
            "property_type": prop_type_lower,
        }
        cached = self._cache_get("ukhpi_region", cache_params)
        if cached is not None:
            return cached  # type: ignore[return-value]

        region_uri = f"{_UKHPI_REGION_BASE}{region_lower}"
        date_filters = ""
        if from_date:
            date_filters += f'  FILTER(STR(?date) >= "{from_date[:7]}")\n'
        if to_date:
            date_filters += f'  FILTER(STR(?date) <= "{to_date[:7]}")\n'

        sparql = (
            _UKHPI_PREFIXES
            + "SELECT ?date ?averagePrice ?housePriceIndex "
            "?percentageMonthlyChange ?percentageAnnualChange\n"
            "WHERE {\n"
            "  ?obs a ukhpi:MonthlyIndicesByRegion ;\n"
            f"       ukhpi:refRegion <{region_uri}> ;\n"
            "       ukhpi:refMonth ?date ;\n"
            "       ukhpi:averagePrice ?averagePrice ;\n"
            "       ukhpi:housePriceIndex ?housePriceIndex ;\n"
            "       ukhpi:percentageChange ?percentageMonthlyChange ;\n"
            "       ukhpi:percentageAnnualChange ?percentageAnnualChange .\n"
            + date_filters
            + "}\n"
            "ORDER BY DESC(?date)\n"
            "LIMIT 500\n"
        )
        rows = self._run_sparql(sparql)
        self._cache_put("ukhpi_region", rows, cache_params)  # type: ignore[arg-type]
        return rows

    def ukhpi_latest(self, *, property_type: str = "all") -> list[dict[str, Any]]:
        prop_type_lower = property_type.strip().lower()
        if prop_type_lower not in VALID_PROPERTY_TYPES:
            raise BadRequestError(
                f"Unknown property_type '{property_type}'. "
                f"Valid values: {', '.join(sorted(VALID_PROPERTY_TYPES))}."
            )

        cache_params = {"property_type": prop_type_lower}
        cached = self._cache_get("ukhpi_latest", cache_params)
        if cached is not None:
            return cached  # type: ignore[return-value]

        # Step 1: find the most recent month where England has data.
        max_month_sparql = (
            _UKHPI_PREFIXES
            + "SELECT (MAX(?m) AS ?maxMonth) WHERE {\n"
            "  ?o a ukhpi:MonthlyIndicesByRegion ;\n"
            f"     ukhpi:refRegion <{_UKHPI_REGION_BASE}england> ;\n"
            "     ukhpi:refMonth ?m .\n"
            "}\n"
        )
        max_rows = self._run_sparql(max_month_sparql)
        if not max_rows or not max_rows[0].get("maxMonth"):
            return []
        latest_month = max_rows[0]["maxMonth"]

        # Step 2: get all standard regions for that month.
        region_uris = ", ".join(
            f"<{_UKHPI_REGION_BASE}{slug}>" for slug in sorted(VALID_REGIONS)
        )
        sparql = (
            _UKHPI_PREFIXES
            + "SELECT ?refRegion ?averagePrice ?housePriceIndex "
            "?percentageMonthlyChange ?percentageAnnualChange\n"
            "WHERE {\n"
            "  ?obs a ukhpi:MonthlyIndicesByRegion ;\n"
            f'       ukhpi:refMonth "{latest_month}" ;\n'
            "       ukhpi:refRegion ?refRegion ;\n"
            "       ukhpi:averagePrice ?averagePrice ;\n"
            "       ukhpi:housePriceIndex ?housePriceIndex ;\n"
            "       ukhpi:percentageChange ?percentageMonthlyChange ;\n"
            "       ukhpi:percentageAnnualChange ?percentageAnnualChange .\n"
            f"  FILTER(?refRegion IN ({region_uris}))\n"
            "}\n"
            "ORDER BY ?refRegion\n"
            "LIMIT 50\n"
        )
        rows = self._run_sparql(sparql)
        # Attach the snapshot month to each row for the clean layer.
        for row in rows:
            row["date"] = latest_month
        self._cache_put("ukhpi_latest", rows, cache_params)  # type: ignore[arg-type]
        return rows

    # ------------------------------------------------------------------
    # ULPD ownership endpoints
    # ------------------------------------------------------------------

    def company_ownership(
        self,
        *,
        company_name: str | None = None,
        company_number: str | None = None,
        postcode: str | None = None,
        limit: int = 50,
    ) -> dict[str, Any]:
        if not any([company_name, company_number, postcode]):
            raise BadRequestError(
                "At least one of company_name, company_number, or postcode must be provided."
            )
        limit = min(max(1, limit), 100)

        norm_postcode: str | None = None
        if postcode:
            norm_postcode = _normalise_postcode(postcode)

        norm_company_number: str | None = None
        if company_number:
            norm_company_number = company_number.strip().upper().zfill(8)

        cache_params = {
            "company_name": company_name,
            "company_number": norm_company_number,
            "postcode": norm_postcode,
            "limit": limit,
        }
        cached = self._cache_get("company_ownership", cache_params)
        if cached is not None:
            return cached  # type: ignore[return-value]

        params: dict[str, Any] = {"limit": limit}
        if company_name:
            params["companyName"] = company_name.strip()
        if norm_company_number:
            params["companyNumber"] = norm_company_number
        if norm_postcode:
            params["postcode"] = norm_postcode

        data = self._ulpd_get("/companies", params=params)
        self._cache_put("company_ownership", data, cache_params)
        return data

    def overseas_ownership(
        self,
        *,
        entity_name: str | None = None,
        country: str | None = None,
        postcode: str | None = None,
        limit: int = 50,
    ) -> dict[str, Any]:
        if not any([entity_name, country, postcode]):
            raise BadRequestError(
                "At least one of entity_name, country, or postcode must be provided."
            )
        limit = min(max(1, limit), 100)

        norm_postcode: str | None = None
        if postcode:
            norm_postcode = _normalise_postcode(postcode)

        norm_country: str | None = None
        if country:
            norm_country = country.strip().title()

        cache_params = {
            "entity_name": entity_name,
            "country": norm_country,
            "postcode": norm_postcode,
            "limit": limit,
        }
        cached = self._cache_get("overseas_ownership", cache_params)
        if cached is not None:
            return cached  # type: ignore[return-value]

        params: dict[str, Any] = {"limit": limit}
        if entity_name:
            params["entityName"] = entity_name.strip()
        if norm_country:
            params["country"] = norm_country
        if norm_postcode:
            params["postcode"] = norm_postcode

        data = self._ulpd_get("/overseas", params=params)
        self._cache_put("overseas_ownership", data, cache_params)
        return data

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def close(self) -> None:
        self._sparql.close()
        self._rest_client.close()
        self._ulpd_client.close()

    def __enter__(self) -> LandRegistryClient:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()
