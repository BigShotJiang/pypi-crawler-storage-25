"""Serve layer tests — end-to-end pipeline via mock transport."""

from __future__ import annotations

import json
from unittest.mock import patch

from bartram_land_registry import serve as _serve
from bartram_land_registry.access import (
    AuthenticationError,
    LandRegistryClient,
    QueryTimeoutError,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _parse(result: str) -> dict:
    return json.loads(result)


def _mock_ppd_rows():
    return [
        {
            "tranid": "http://landregistry.data.gov.uk/data/ppi/transaction/ABC123",
            "paon": "42",
            "saon": "",
            "street": "HIGH STREET",
            "locality": "",
            "town": "LONDON",
            "county": "GREATER LONDON",
            "postcode": "SW1A1AA",
            "amount": "500000",
            "date": "2023-06-15",
            "propertyType": "http://landregistry.data.gov.uk/def/common/detached",
            "estateType": "http://landregistry.data.gov.uk/def/common/freehold",
            "category": "http://landregistry.data.gov.uk/def/ppi/standardPricePaidEntry",
        }
    ]


def _mock_ukhpi_items():
    return [
        {
            "refDate": "2024-01-01",
            "housePrice": 510000.0,
            "percentageAnnualChange": 3.2,
            "percentageMonthlyChange": 0.5,
        }
    ]


# ---------------------------------------------------------------------------
# price_paid_search
# ---------------------------------------------------------------------------

def test_price_paid_search_full_pipeline():
    with patch.object(LandRegistryClient, "price_paid_search", return_value=_mock_ppd_rows()):
        result = _serve.uk_land_registry_price_paid_search(postcode="SW1A 1AA")
    parsed = _parse(result)
    assert "data" in parsed
    assert "metadata" in parsed
    assert parsed["data"]["total_results"] == 1
    item = parsed["data"]["items"][0]
    assert item["property_type"] == "Detached"
    assert item["duration"] == "Freehold"
    assert "High Street" in item["address"]
    # Metadata checks
    assert "HM Land Registry" in parsed["metadata"]["source"]
    assert "Open Government Licence" in parsed["metadata"]["licence"]
    assert "attribution" in parsed["metadata"]
    assert "retrieved_at" in parsed["metadata"]


def test_price_paid_search_validation_error():
    result = _serve.uk_land_registry_price_paid_search()  # no filters
    parsed = _parse(result)
    assert parsed["error"] == "validation_error"
    assert "attribution" in parsed


def test_price_paid_search_timeout():
    side = QueryTimeoutError("timeout")
    with patch.object(LandRegistryClient, "price_paid_search", side_effect=side):
        result = _serve.uk_land_registry_price_paid_search(postcode="SW1A 1AA")
    parsed = _parse(result)
    assert parsed["error"] == "timeout"


def test_price_paid_search_empty():
    with patch.object(LandRegistryClient, "price_paid_search", return_value=[]):
        result = _serve.uk_land_registry_price_paid_search(postcode="ZZ99 9ZZ")
    parsed = _parse(result)
    assert parsed["data"]["total_results"] == 0
    assert parsed["data"]["items"] == []


# ---------------------------------------------------------------------------
# price_paid_postcode
# ---------------------------------------------------------------------------

def test_price_paid_postcode_full_pipeline():
    with patch.object(LandRegistryClient, "price_paid_postcode", return_value=_mock_ppd_rows()):
        result = _serve.uk_land_registry_price_paid_postcode(postcode="SW1A 1AA")
    parsed = _parse(result)
    assert parsed["data"]["postcode"] == "SW1A 1AA"
    assert parsed["data"]["total_results"] == 1


def test_price_paid_postcode_invalid():
    result = _serve.uk_land_registry_price_paid_postcode(postcode="NOTVALID")
    parsed = _parse(result)
    assert parsed["error"] == "validation_error"


# ---------------------------------------------------------------------------
# price_paid_address
# ---------------------------------------------------------------------------

def test_price_paid_address_full_pipeline():
    with patch.object(LandRegistryClient, "price_paid_address", return_value=_mock_ppd_rows()):
        result = _serve.uk_land_registry_price_paid_address(
            house_number_or_name="42", street="High Street", postcode="SW1A 1AA"
        )
    parsed = _parse(result)
    assert parsed["data"]["total_transactions"] == 1
    assert parsed["data"]["items"][0]["_cleaning"]["results_sorted_descending"] is True


def test_price_paid_address_empty():
    with patch.object(LandRegistryClient, "price_paid_address", return_value=[]):
        result = _serve.uk_land_registry_price_paid_address(
            house_number_or_name="99", street="Unknown Road", postcode="ZZ1 1ZZ"
        )
    parsed = _parse(result)
    assert parsed["data"]["total_transactions"] == 0


# ---------------------------------------------------------------------------
# ukhpi_region
# ---------------------------------------------------------------------------

def test_ukhpi_region_full_pipeline():
    with patch.object(LandRegistryClient, "ukhpi_region", return_value=_mock_ukhpi_items()):
        result = _serve.uk_land_registry_ukhpi_region(region="london")
    parsed = _parse(result)
    assert parsed["data"]["region"] == "london"
    assert len(parsed["data"]["items"]) == 1
    assert parsed["data"]["items"][0]["date"] == "2024-01-01"


def test_ukhpi_region_invalid_region():
    result = _serve.uk_land_registry_ukhpi_region(region="atlantis")
    parsed = _parse(result)
    assert parsed["error"] == "validation_error"


# ---------------------------------------------------------------------------
# ukhpi_latest
# ---------------------------------------------------------------------------

def test_ukhpi_latest_full_pipeline():
    with patch.object(LandRegistryClient, "ukhpi_latest", return_value=[{
        "refDate": "2024-01-01",
        "refRegion": "http://landregistry.data.gov.uk/id/region/london",
        "housePrice": 510000.0,
        "percentageAnnualChange": 3.2,
        "percentageMonthlyChange": 0.5,
    }]):
        result = _serve.uk_land_registry_ukhpi_latest()
    parsed = _parse(result)
    assert parsed["data"]["snapshot_date"] == "2024-01-01"
    assert len(parsed["data"]["regions"]) == 1


# ---------------------------------------------------------------------------
# company_ownership
# ---------------------------------------------------------------------------

MOCK_COMPANY_DATA = {
    "results": [
        {
            "companyName": "TEST COMPANY LTD",
            "companyRegistrationNo": "12345",
            "companyCategory": "limited-company",
            "properties": [{"propertyAddress": "1 HIGH STREET", "postcode": "SW1A1AA"}],
        }
    ],
    "totalResults": 1,
}


def test_company_ownership_full_pipeline():
    with patch.object(LandRegistryClient, "company_ownership", return_value=MOCK_COMPANY_DATA):
        result = _serve.uk_land_registry_company_ownership(company_name="Test")
    parsed = _parse(result)
    assert parsed["data"]["total_results"] == 1
    item = parsed["data"]["items"][0]
    assert item["company_number"] == "00012345"


def test_company_ownership_no_filter():
    result = _serve.uk_land_registry_company_ownership()
    parsed = _parse(result)
    assert parsed["error"] == "validation_error"


def test_company_ownership_auth_error():
    side = AuthenticationError("no key")
    with patch.object(LandRegistryClient, "company_ownership", side_effect=side):
        result = _serve.uk_land_registry_company_ownership(company_name="Test")
    parsed = _parse(result)
    assert parsed["error"] == "authentication_error"


# ---------------------------------------------------------------------------
# overseas_ownership
# ---------------------------------------------------------------------------

MOCK_OVERSEAS_DATA = {
    "results": [
        {
            "proprietorName": "GLOBAL LLC",
            "countryIncorporated": "united states",
            "companyRegistrationNo": "US-999",
            "properties": [],
        }
    ],
    "totalResults": 1,
}


def test_overseas_ownership_full_pipeline():
    with patch.object(LandRegistryClient, "overseas_ownership", return_value=MOCK_OVERSEAS_DATA):
        result = _serve.uk_land_registry_overseas_ownership(country="United States")
    parsed = _parse(result)
    assert parsed["data"]["total_results"] == 1
    assert parsed["data"]["items"][0]["country"] == "United States"


def test_overseas_ownership_no_filter():
    result = _serve.uk_land_registry_overseas_ownership()
    parsed = _parse(result)
    assert parsed["error"] == "validation_error"


# ---------------------------------------------------------------------------
# transaction_detail
# ---------------------------------------------------------------------------

def test_transaction_detail_full_pipeline():
    mock_row = {
        "tranid": "http://landregistry.data.gov.uk/data/ppi/transaction/XYZ789",
        "paon": "10",
        "street": "BAKER STREET",
        "postcode": "NW1 6XE",
        "amount": "750000",
        "date": "2022-09-20",
        "propertyType": "http://landregistry.data.gov.uk/def/common/terraced",
        "estateType": "http://landregistry.data.gov.uk/def/common/leasehold",
        "category": "http://landregistry.data.gov.uk/def/ppi/standardPricePaidEntry",
    }
    with patch.object(LandRegistryClient, "transaction_detail", return_value=[mock_row]):
        result = _serve.uk_land_registry_transaction_detail(transaction_id="XYZ789")
    parsed = _parse(result)
    assert parsed["data"]["property_type"] == "Terraced"
    assert parsed["data"]["duration"] == "Leasehold"
    assert parsed["data"]["price"] == 750000
    assert parsed["data"]["_cleaning"]["date_normalised"] is True


def test_transaction_detail_not_found():
    with patch.object(LandRegistryClient, "transaction_detail", return_value=[]):
        result = _serve.uk_land_registry_transaction_detail(transaction_id="NOPE")
    parsed = _parse(result)
    assert parsed["error"] == "not_found"


def test_transaction_detail_empty_id():
    result = _serve.uk_land_registry_transaction_detail(transaction_id="")
    parsed = _parse(result)
    assert parsed["error"] == "validation_error"


# ---------------------------------------------------------------------------
# Metadata presence checks
# ---------------------------------------------------------------------------

def test_metadata_fields_present():
    with patch.object(LandRegistryClient, "price_paid_search", return_value=_mock_ppd_rows()):
        result = _serve.uk_land_registry_price_paid_search(postcode="SW1A 1AA")
    meta = _parse(result)["metadata"]
    assert meta["source"] == "HM Land Registry Open Data & Use Land Property Data API"
    assert meta["licence"] == "Open Government Licence v3"
    assert "Crown copyright" in meta["attribution"]
    assert "cached" in meta
    assert meta["endpoint"] == "/landregistry/query (SPARQL)"
