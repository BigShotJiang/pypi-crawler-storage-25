"""Access layer tests — mock transport, no live API calls."""

from __future__ import annotations

import json
import tempfile
from unittest.mock import MagicMock, patch

import pytest

from bartram_foundry.sparql_client import SPARQLTimeoutError
from bartram_land_registry.access import (
    AuthenticationError,
    BadRequestError,
    LandRegistryClient,
    QueryTimeoutError,
    _normalise_postcode,
)

# ---------------------------------------------------------------------------
# Postcode normalisation
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("raw,expected", [
    ("SW1A1AA", "SW1A 1AA"),
    ("sw1a1aa", "SW1A 1AA"),
    ("SW1A 1AA", "SW1A 1AA"),
    ("EC1A1BB", "EC1A 1BB"),
    ("W1A0AX", "W1A 0AX"),
    ("LS11AB", "LS1 1AB"),
    ("  SW1A 1AA  ", "SW1A 1AA"),
])
def test_normalise_postcode_valid(raw, expected):
    assert _normalise_postcode(raw) == expected


def test_normalise_postcode_invalid():
    with pytest.raises(BadRequestError, match="Invalid UK postcode"):
        _normalise_postcode("NOTAPOSTCODE")


def test_normalise_postcode_empty():
    with pytest.raises(BadRequestError):
        _normalise_postcode("")


# ---------------------------------------------------------------------------
# Client: input validation
# ---------------------------------------------------------------------------

def _make_client(cache_enabled=False) -> LandRegistryClient:
    return LandRegistryClient(cache_enabled=cache_enabled)


def test_price_paid_search_requires_filter():
    client = _make_client()
    with pytest.raises(BadRequestError, match="At least one"):
        client.price_paid_search()


def test_price_paid_search_invalid_property_type():
    client = _make_client()
    with pytest.raises(BadRequestError, match="Unknown property_type"):
        client.price_paid_search(postcode="SW1A 1AA", property_type="mansion")


def test_price_paid_search_invalid_date_format():
    client = _make_client()
    with pytest.raises(BadRequestError, match="Date must be YYYY-MM-DD"):
        client.price_paid_search(postcode="SW1A 1AA", from_date="01-01-2020")


def test_price_paid_search_negative_price():
    client = _make_client()
    with pytest.raises(BadRequestError, match="positive integer"):
        client.price_paid_search(postcode="SW1A 1AA", min_price=-1)


def test_price_paid_postcode_empty_postcode():
    client = _make_client()
    with pytest.raises(BadRequestError):
        client.price_paid_postcode(postcode="")


def test_price_paid_address_missing_fields():
    client = _make_client()
    with pytest.raises(BadRequestError):
        client.price_paid_address(house_number_or_name="", street="High St", postcode="SW1A 1AA")


def test_transaction_detail_empty_id():
    client = _make_client()
    with pytest.raises(BadRequestError, match="required"):
        client.transaction_detail(transaction_id="")


def test_ukhpi_region_invalid_region():
    client = _make_client()
    with pytest.raises(BadRequestError, match="Unknown region"):
        client.ukhpi_region(region="atlantis")


def test_ukhpi_region_invalid_property_type():
    client = _make_client()
    with pytest.raises(BadRequestError, match="Unknown property_type"):
        client.ukhpi_region(region="london", property_type="castle")


def test_company_ownership_requires_filter():
    client = _make_client()
    with pytest.raises(BadRequestError, match="At least one"):
        client.company_ownership()


def test_overseas_ownership_requires_filter():
    client = _make_client()
    with pytest.raises(BadRequestError, match="At least one"):
        client.overseas_ownership()


# ---------------------------------------------------------------------------
# ULPD: auth error when key missing
# ---------------------------------------------------------------------------

def test_company_ownership_no_api_key():
    with (
        patch.dict("os.environ", {}, clear=True),
        pytest.raises(AuthenticationError, match="ULPD_API_KEY"),
    ):
        client2 = LandRegistryClient(cache_enabled=False, ulpd_api_key=None)
        client2._ulpd_api_key = None
        client2.company_ownership(company_name="Test Ltd")


# ---------------------------------------------------------------------------
# SPARQL: mock responses
# ---------------------------------------------------------------------------

MOCK_PPD_ROW = {
    "tranid": "http://landregistry.data.gov.uk/data/ppi/transaction/12345",
    "paon": "42",
    "saon": "",
    "street": "HIGH STREET",
    "locality": "",
    "town": "LONDON",
    "county": "GREATER LONDON",
    "postcode": "SW1A 1AA",
    "amount": "500000",
    "date": "2023-06-15",
    "propertyType": "http://landregistry.data.gov.uk/def/common/detached",
    "estateType": "http://landregistry.data.gov.uk/def/common/freehold",
    "category": "http://landregistry.data.gov.uk/def/ppi/standardPricePaidEntry",
}


def test_price_paid_search_success():
    client = _make_client()
    with patch.object(client._sparql, "query_paginated", return_value=[MOCK_PPD_ROW]):
        results = client.price_paid_search(postcode="SW1A 1AA")
    assert isinstance(results, list)
    assert len(results) == 1
    assert results[0]["tranid"].endswith("12345")


def test_price_paid_postcode_success():
    client = _make_client()
    with patch.object(client._sparql, "query_paginated", return_value=[MOCK_PPD_ROW]):
        results = client.price_paid_postcode(postcode="SW1A 1AA")
    assert len(results) == 1


def test_price_paid_address_success():
    client = _make_client()
    with patch.object(client._sparql, "query", return_value=[MOCK_PPD_ROW]):
        results = client.price_paid_address(
            house_number_or_name="42", street="High Street", postcode="SW1A 1AA"
        )
    assert len(results) == 1


def test_transaction_detail_success():
    client = _make_client()
    with patch.object(client._sparql, "query", return_value=[MOCK_PPD_ROW]):
        results = client.transaction_detail(transaction_id="12345")
    assert len(results) == 1


def test_price_paid_search_timeout():
    client = _make_client()
    side = SPARQLTimeoutError("timeout")
    with (
        patch.object(client._sparql, "query_paginated", side_effect=side),
        pytest.raises(QueryTimeoutError),
    ):
        client.price_paid_search(postcode="SW1A 1AA")


def test_price_paid_search_empty_results():
    client = _make_client()
    with patch.object(client._sparql, "query_paginated", return_value=[]):
        results = client.price_paid_search(postcode="ZZ99 9ZZ")
    assert results == []


# ---------------------------------------------------------------------------
# UKHPI: mock REST responses
# ---------------------------------------------------------------------------

# SPARQL row format (all values are strings, variable names match query aliases).
MOCK_UKHPI_SPARQL_ROW = {
    "date": "2024-01",
    "averagePrice": "510000",
    "housePriceIndex": "97.5",
    "percentageMonthlyChange": "0.5",
    "percentageAnnualChange": "3.2",
}

MOCK_UKHPI_LATEST_SPARQL_ROW = {
    "refRegion": "http://landregistry.data.gov.uk/id/region/london",
    "averagePrice": "510000",
    "housePriceIndex": "97.5",
    "percentageMonthlyChange": "0.5",
    "percentageAnnualChange": "3.2",
    "date": "2026-02",
}


def _mock_rest_response(data: dict, status_code: int = 200):
    mock_resp = MagicMock()
    mock_resp.status_code = status_code
    mock_resp.json.return_value = data
    mock_resp.text = json.dumps(data)
    return mock_resp


def test_ukhpi_region_success():
    client = _make_client()
    with patch.object(client._sparql, "query", return_value=[MOCK_UKHPI_SPARQL_ROW]):
        items = client.ukhpi_region(region="london")
    assert len(items) == 1
    assert items[0]["housePriceIndex"] == "97.5"


def test_ukhpi_latest_success():
    client = _make_client()
    max_month_row = [{"maxMonth": "2026-02"}]
    region_rows = [MOCK_UKHPI_LATEST_SPARQL_ROW]
    with patch.object(client._sparql, "query", side_effect=[max_month_row, region_rows]):
        items = client.ukhpi_latest()
    assert len(items) == 1
    assert items[0]["date"] == "2026-02"


def test_ukhpi_region_sparql_timeout():
    client = _make_client()
    with (
        patch.object(client._sparql, "query", side_effect=SPARQLTimeoutError("timeout")),
        pytest.raises(QueryTimeoutError),
    ):
        client.ukhpi_region(region="london")


# ---------------------------------------------------------------------------
# Cache: hit and miss
# ---------------------------------------------------------------------------

def test_cache_miss_then_hit():
    with tempfile.NamedTemporaryFile(suffix=".db") as tmp:
        from bartram_foundry.cache import ResponseCache
        client = LandRegistryClient(cache_enabled=True)
        client._cache = ResponseCache(db_path=tmp.name)
        call_count = 0

        def fake_paginated(template, *, limit, max_results=1000):
            nonlocal call_count
            call_count += 1
            return [MOCK_PPD_ROW]

        with patch.object(client._sparql, "query_paginated", side_effect=fake_paginated):
            # First call — cache miss.
            client.price_paid_search(postcode="SW1A 1AA")
            # Second call — should hit cache.
            client.price_paid_search(postcode="SW1A 1AA")

    assert call_count == 1


# ---------------------------------------------------------------------------
# Limit clamping
# ---------------------------------------------------------------------------

def test_limit_clamped_to_max():
    client = _make_client()
    with patch.object(client._sparql, "query_paginated", return_value=[]) as mock_sparql:
        client.price_paid_search(postcode="SW1A 1AA", limit=9999)
    # The call should have used limit=200 (clamped).
    call_args = mock_sparql.call_args
    assert call_args[1]["limit"] == 200 or 200 in call_args[0]
