"""Clean layer tests — known-messy data, edge cases."""

from __future__ import annotations

import pytest

from bartram_land_registry.clean import (
    _clean_ppd_row,
    _map_duration,
    _map_ppd_category,
    _map_property_type,
    _normalise_address,
    _normalise_postcode,
    _pad_company_number,
    clean_company_ownership,
    clean_overseas_ownership,
    clean_price_paid_address,
    clean_price_paid_postcode,
    clean_price_paid_search,
    clean_transaction_detail,
    clean_ukhpi_latest,
    clean_ukhpi_region,
)

# ---------------------------------------------------------------------------
# Address normalisation
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("raw,expected,changed", [
    ("42 HIGH STREET", "42 High Street", True),
    ("FLAT 3, VICTORIA ROAD", "Flat 3, Victoria Road", True),
    ("42 High Street", "42 High Street", False),  # already Title Case
    ("", "", False),
    (None, None, False),
])
def test_normalise_address(raw, expected, changed):
    result, was_changed = _normalise_address(raw)
    assert result == expected
    assert was_changed == changed


def test_normalise_address_all_caps_with_numbers():
    result, changed = _normalise_address("12A CHURCH LANE")
    assert result == "12A Church Lane"
    assert changed is True


# ---------------------------------------------------------------------------
# Postcode normalisation (clean layer)
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("raw,expected,changed", [
    ("SW1A1AA", "SW1A 1AA", True),
    ("SW1A 1AA", "SW1A 1AA", False),
    ("ec1a1bb", "EC1A 1BB", True),
    ("", "", False),
    (None, None, False),
    ("NOTAPC", "NOTAPC", False),  # unrecognised — return as-is
])
def test_normalise_postcode(raw, expected, changed):
    result, was_changed = _normalise_postcode(raw)
    assert result == expected
    assert was_changed == changed


# ---------------------------------------------------------------------------
# Property type mapping
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("uri,expected_human,expected_code", [
    ("http://landregistry.data.gov.uk/def/common/detached", "Detached", "detached"),
    ("http://landregistry.data.gov.uk/def/common/semiDetached", "Semi-detached", "semiDetached"),
    ("http://landregistry.data.gov.uk/def/common/terraced", "Terraced", "terraced"),
    ("http://landregistry.data.gov.uk/def/common/flat", "Flat", "flat"),
    ("http://landregistry.data.gov.uk/def/common/otherOrUnknown", "Other", "otherOrUnknown"),
    ("D", "Detached", "D"),
    ("S", "Semi-detached", "S"),
    ("T", "Terraced", "T"),
    ("F", "Flat", "F"),
    ("O", "Other", "O"),
])
def test_map_property_type(uri, expected_human, expected_code):
    human, code = _map_property_type(uri)
    assert human == expected_human
    assert code == expected_code


def test_map_property_type_none():
    _, code = _map_property_type(None)
    assert code == ""


# ---------------------------------------------------------------------------
# Duration mapping
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("uri,expected_human", [
    ("http://landregistry.data.gov.uk/def/common/freehold", "Freehold"),
    ("http://landregistry.data.gov.uk/def/common/leasehold", "Leasehold"),
    ("F", "Freehold"),
    ("L", "Leasehold"),
])
def test_map_duration(uri, expected_human):
    human, _ = _map_duration(uri)
    assert human == expected_human


# ---------------------------------------------------------------------------
# PPD category mapping
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("uri,expected_human", [
    ("http://landregistry.data.gov.uk/def/ppi/standardPricePaidEntry", "Standard Price"),
    ("http://landregistry.data.gov.uk/def/ppi/standardPricePaidTransaction", "Standard Price"),
    ("http://landregistry.data.gov.uk/def/ppi/additionalPricePaidTransaction", "Additional Price"),
    ("A", "Standard Price"),
    ("B", "Additional Price"),
])
def test_map_ppd_category(uri, expected_human):
    human, _ = _map_ppd_category(uri)
    assert human == expected_human


# ---------------------------------------------------------------------------
# Full PPD row cleaning
# ---------------------------------------------------------------------------

MESSY_ROW = {
    "tranid": "http://landregistry.data.gov.uk/data/ppi/transaction/ABC123",
    "paon": "42",
    "saon": "",
    "street": "HIGH STREET",
    "locality": "",
    "town": "LONDON",
    "county": "GREATER LONDON",
    "postcode": "SW1A1AA",
    "amount": "500000",
    "date": "2023-06-15^^xsd:date",
    "propertyType": "http://landregistry.data.gov.uk/def/common/detached",
    "estateType": "http://landregistry.data.gov.uk/def/common/freehold",
    "category": "http://landregistry.data.gov.uk/def/ppi/standardPricePaidEntry",
}


def test_clean_ppd_row_address_normalisation():
    item = _clean_ppd_row(MESSY_ROW)
    assert "High Street" in item["address"]
    assert item["_cleaning"].get("address_normalised") is True


def test_clean_ppd_row_postcode_normalised():
    item = _clean_ppd_row(MESSY_ROW)
    assert item["postcode"] == "SW1A 1AA"
    assert item["_cleaning"].get("postcode_normalised") is True


def test_clean_ppd_row_property_type():
    item = _clean_ppd_row(MESSY_ROW)
    assert item["property_type"] == "Detached"
    assert item["property_type_code"] == "detached"
    assert item["_cleaning"]["property_type_mapped"] is True


def test_clean_ppd_row_duration():
    item = _clean_ppd_row(MESSY_ROW)
    assert item["duration"] == "Freehold"
    assert item["_cleaning"]["duration_mapped"] is True


def test_clean_ppd_row_ppd_category():
    item = _clean_ppd_row(MESSY_ROW)
    assert item["price_paid_category"] == "Standard Price"
    assert item["_cleaning"]["pricepaid_category_mapped"] is True


def test_clean_ppd_row_price_integer():
    item = _clean_ppd_row(MESSY_ROW)
    assert item["price"] == 500000
    assert isinstance(item["price"], int)


def test_clean_ppd_row_date_no_annotation():
    item = _clean_ppd_row(MESSY_ROW)
    assert item["transaction_date"] == "2023-06-15"
    assert "^^" not in item["transaction_date"]


def test_clean_ppd_row_transaction_id_extracted():
    item = _clean_ppd_row(MESSY_ROW)
    assert item["transaction_id"] == "ABC123"


def test_clean_ppd_row_empty_fields():
    sparse_row = {
        "tranid": "http://landregistry.data.gov.uk/data/ppi/transaction/X1",
        "postcode": "EC1A 1BB",
        "amount": "250000",
        "date": "2022-01-01",
        "propertyType": "http://landregistry.data.gov.uk/def/common/flat",
        "estateType": "http://landregistry.data.gov.uk/def/common/leasehold",
        "category": "http://landregistry.data.gov.uk/def/ppi/standardPricePaidEntry",
    }
    item = _clean_ppd_row(sparse_row)
    assert item["price"] == 250000
    assert item["property_type"] == "Flat"
    assert item["duration"] == "Leasehold"


# ---------------------------------------------------------------------------
# Price Paid search aggregate
# ---------------------------------------------------------------------------

def test_clean_price_paid_search_empty():
    result = clean_price_paid_search([])
    assert result["total_results"] == 0
    assert result["items"] == []


def test_clean_price_paid_search_count():
    result = clean_price_paid_search([MESSY_ROW, MESSY_ROW])
    assert result["total_results"] == 2
    assert len(result["items"]) == 2


# ---------------------------------------------------------------------------
# Price Paid postcode aggregate
# ---------------------------------------------------------------------------

def test_clean_price_paid_postcode():
    result = clean_price_paid_postcode([MESSY_ROW], postcode="SW1A1AA")
    assert result["postcode"] == "SW1A 1AA"
    assert result["total_results"] == 1


# ---------------------------------------------------------------------------
# Price Paid address: sorted descending
# ---------------------------------------------------------------------------

OLDER_ROW = {**MESSY_ROW, "date": "2015-03-10", "amount": "350000"}
NEWER_ROW = {**MESSY_ROW, "date": "2023-06-15", "amount": "500000"}


def test_clean_price_paid_address_sort_order():
    result = clean_price_paid_address(
        [OLDER_ROW, NEWER_ROW], "42", "High Street", "SW1A 1AA"
    )
    dates = [i["transaction_date"] for i in result["items"]]
    assert dates == sorted(dates, reverse=True)


def test_clean_price_paid_address_sort_annotation():
    result = clean_price_paid_address([MESSY_ROW], "42", "High Street", "SW1A 1AA")
    assert result["items"][0]["_cleaning"]["results_sorted_descending"] is True


# ---------------------------------------------------------------------------
# Transaction detail
# ---------------------------------------------------------------------------

def test_clean_transaction_detail_empty():
    result = clean_transaction_detail([], "ABC123")
    assert result == {}


def test_clean_transaction_detail_annotations():
    item = clean_transaction_detail([MESSY_ROW], "ABC123")
    assert item["_cleaning"]["date_normalised"] is True
    assert item["_cleaning"]["price_formatted"] is True
    assert item["_cleaning"]["linked_transaction"] is False
    assert item["linked_transaction"] is None


# ---------------------------------------------------------------------------
# UKHPI cleaning
# ---------------------------------------------------------------------------

UKHPI_ITEM = {
    "refDate": "2024-01-01",
    "housePrice": 510000.55,
    "percentageAnnualChange": 3.2,
    "percentageMonthlyChange": 0.5,
}


def test_clean_ukhpi_region_basic():
    result = clean_ukhpi_region([UKHPI_ITEM], "london", "all")
    assert result["region"] == "london"
    assert result["property_type"] == "all"
    assert len(result["items"]) == 1
    assert result["items"][0]["date"] == "2024-01-01"


def test_clean_ukhpi_region_rounding():
    result = clean_ukhpi_region([UKHPI_ITEM], "london", "all")
    # 510000.55 rounds to 510000.6 (1 dp)
    assert result["items"][0]["index_value"] == round(510000.55, 1)


def test_clean_ukhpi_region_empty():
    result = clean_ukhpi_region([], "england", "all")
    assert result["items"] == []


UKHPI_LATEST_ITEM = {
    "refDate": "2024-01-01",
    "refRegion": "http://landregistry.data.gov.uk/id/region/london",
    "housePrice": 510000.0,
    "percentageAnnualChange": 3.2,
    "percentageMonthlyChange": 0.5,
}


def test_clean_ukhpi_latest():
    result = clean_ukhpi_latest([UKHPI_LATEST_ITEM], "all")
    assert result["snapshot_date"] == "2024-01-01"
    assert len(result["regions"]) == 1
    assert result["regions"][0]["region"] == "london"


# ---------------------------------------------------------------------------
# ULPD company cleaning
# ---------------------------------------------------------------------------

MOCK_COMPANY_RAW = {
    "results": [
        {
            "companyName": "ACME PROPERTY LTD",
            "companyRegistrationNo": "12345",
            "companyCategory": "limited-company",
            "properties": [
                {
                    "propertyAddress": "1 HIGH STREET",
                    "postcode": "SW1A1AA",
                    "dateOfAcquisition": "2020-01-15",
                }
            ],
        }
    ],
    "totalResults": 1,
}


def test_clean_company_ownership_basic():
    result = clean_company_ownership(MOCK_COMPANY_RAW)
    assert result["total_results"] == 1
    item = result["items"][0]
    assert item["company_name"] == "ACME PROPERTY LTD"
    assert item["company_number"] == "00012345"  # zero-padded
    assert item["_cleaning"]["company_number_padded"] is True
    assert item["properties_owned"] == 1


def test_clean_company_ownership_property_address_normalised():
    result = clean_company_ownership(MOCK_COMPANY_RAW)
    sample = result["items"][0]["property_samples"][0]
    assert "High Street" in sample["address"]


def test_clean_company_ownership_empty():
    result = clean_company_ownership({"results": [], "totalResults": 0})
    assert result["total_results"] == 0
    assert result["items"] == []


# ---------------------------------------------------------------------------
# ULPD overseas cleaning
# ---------------------------------------------------------------------------

MOCK_OVERSEAS_RAW = {
    "results": [
        {
            "proprietorName": "GLOBAL HOLDINGS LLC",
            "countryIncorporated": "united states",
            "companyRegistrationNo": "US-12345",
            "registrationType": "overseas-company",
            "properties": [
                {
                    "propertyAddress": "PENTHOUSE, 1 TOWER BRIDGE",
                    "postcode": "SE1 2UP",
                    "dateOfAcquisition": "2019-06-01",
                }
            ],
        }
    ],
    "totalResults": 1,
}


def test_clean_overseas_ownership_country_title_case():
    result = clean_overseas_ownership(MOCK_OVERSEAS_RAW)
    item = result["items"][0]
    assert item["country"] == "United States"
    assert item["_cleaning"].get("country_normalised") is True


def test_clean_overseas_ownership_registration_type():
    result = clean_overseas_ownership(MOCK_OVERSEAS_RAW)
    item = result["items"][0]
    assert item["_cleaning"].get("registration_type_mapped") is True


def test_clean_overseas_ownership_empty():
    result = clean_overseas_ownership({"results": []})
    assert result["items"] == []


# ---------------------------------------------------------------------------
# Padding
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("raw,expected,changed", [
    ("12345", "00012345", True),
    ("00012345", "00012345", False),
    ("12345678", "12345678", False),
    ("1", "00000001", True),
])
def test_pad_company_number(raw, expected, changed):
    result, was_changed = _pad_company_number(raw)
    assert result == expected
    assert was_changed == changed
