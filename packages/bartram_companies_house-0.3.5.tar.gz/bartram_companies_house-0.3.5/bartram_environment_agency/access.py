"""Environment Agency Open Data API client.

Endpoints: 10 tools covering flood monitoring, water quality, permits, and catchment data.
Auth: None (public data).
Rate limit: 200 requests per minute.

Sub-APIs:
- Flood monitoring: /flood-monitoring/ (JSON, items-based pagination)
- Water quality: /water-quality/ (JSON-LD, skip/limit pagination)
- Public register (permits): /public-register/ (JSON, _limit/_offset pagination)
- Catchment planning: /catchment-planning/ (CSV downloads)
- Bathing water: /doc/bathing-water (JSON-LD — currently 403, may be decommissioned)
"""

from __future__ import annotations

import contextlib
import csv
import io
import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import httpx
import yaml

from bartram_foundry.cache import ResponseCache
from bartram_foundry.http import retry_request

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

DEFAULT_BASE_URL = "https://environment.data.gov.uk"
DEFAULT_RATE_LIMIT = 200
DEFAULT_RATE_PERIOD = 60  # seconds

_DEFAULT_CACHE_TTLS: dict[str, int] = {
    "flood_warnings": 60,
    "flood_areas": 3600,
    "flood_stations": 3600,
    "station_readings": 60,
    "water_quality_sites": 3600,
    "water_quality_results": 600,
    "bathing_water": 86400,
    "permits_search": 3600,
    "permit_detail": 3600,
    "catchment": 86400,
}

# Permit register types and their API path segments.
_PERMIT_REGISTERS: dict[str, str] = {
    "waste": "waste-operations",
    "installations": "industrial-installations",
    "water-discharge": "water-discharges",
    "abstraction": "water-discharges",  # abstraction is also under water-discharges
}


def _load_cache_ttls() -> dict[str, int]:
    """Load cache TTLs from config.yaml if it exists."""
    config_path = Path(__file__).parent / "config.yaml"
    if config_path.exists():
        with open(config_path) as f:
            config = yaml.safe_load(f)
        return config.get("cache", {}).get("ttl_seconds", _DEFAULT_CACHE_TTLS)
    return dict(_DEFAULT_CACHE_TTLS)


@dataclass
class EnvironmentAgencyConfig:
    """Configuration for the Environment Agency API client."""

    base_url: str = DEFAULT_BASE_URL
    rate_limit: int = DEFAULT_RATE_LIMIT
    rate_period: int = DEFAULT_RATE_PERIOD
    timeout: float = 30.0
    cache_enabled: bool = True

    @classmethod
    def from_env(cls) -> EnvironmentAgencyConfig:
        """Create config from environment variables.

        No API key required — Environment Agency data is public.
        """
        import os

        return cls(
            base_url=os.environ.get("EA_BASE_URL", DEFAULT_BASE_URL),
            rate_limit=int(os.environ.get("EA_RATE_LIMIT", DEFAULT_RATE_LIMIT)),
            rate_period=int(os.environ.get("EA_RATE_PERIOD", DEFAULT_RATE_PERIOD)),
            timeout=float(os.environ.get("EA_TIMEOUT", "30.0")),
        )


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class EnvironmentAgencyError(Exception):
    """Base exception for Environment Agency API errors."""

    def __init__(self, message: str, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


class NotFoundError(EnvironmentAgencyError):
    """Resource not found (404)."""


class RateLimitError(EnvironmentAgencyError):
    """Rate limit exceeded (429)."""


class ServerError(EnvironmentAgencyError):
    """Upstream server error (5xx)."""


class BadRequestError(EnvironmentAgencyError):
    """Invalid request parameters (400)."""


class ServiceUnavailableError(EnvironmentAgencyError):
    """Service temporarily unavailable (403 or similar)."""


# ---------------------------------------------------------------------------
# Input validation
# ---------------------------------------------------------------------------


def validate_coordinates(
    latitude: float | None, longitude: float | None,
) -> None:
    """Validate that coordinates are valid WGS84 if provided.

    Raises BadRequestError if only one coordinate is provided or values
    are out of range.
    """
    if latitude is not None and longitude is None:
        raise BadRequestError("Both latitude and longitude must be provided together.")
    if longitude is not None and latitude is None:
        raise BadRequestError("Both latitude and longitude must be provided together.")
    if latitude is not None and not -90 <= latitude <= 90:
        raise BadRequestError(f"Latitude must be between -90 and 90, got {latitude}.")
    if longitude is not None and not -180 <= longitude <= 180:
        raise BadRequestError(f"Longitude must be between -180 and 180, got {longitude}.")


# ---------------------------------------------------------------------------
# Rate limiter
# ---------------------------------------------------------------------------


class _RateLimiter:
    """Simple sliding-window rate limiter."""

    def __init__(self, max_requests: int, period_seconds: int) -> None:
        self._max = max_requests
        self._period = period_seconds
        self._timestamps: list[float] = []

    def wait(self) -> None:
        """Block until the next request is allowed."""
        now = time.monotonic()
        cutoff = now - self._period
        self._timestamps = [t for t in self._timestamps if t > cutoff]

        if len(self._timestamps) >= self._max:
            sleep_until = self._timestamps[0] + self._period
            time.sleep(max(0, sleep_until - now))

        self._timestamps.append(time.monotonic())


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------


class EnvironmentAgencyClient:
    """API client for Environment Agency Open Data endpoints.

    Uses multiple sub-APIs under https://environment.data.gov.uk:
    - Flood monitoring API (JSON)
    - Water Quality Archive API (JSON-LD)
    - Public Register API (JSON)
    - Catchment Planning (CSV)
    - Bathing Water Quality (JSON-LD, currently 403)
    """

    def __init__(
        self,
        config: EnvironmentAgencyConfig | None = None,
        *,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        self._config = config or EnvironmentAgencyConfig.from_env()
        self._limiter = _RateLimiter(self._config.rate_limit, self._config.rate_period)
        self._cache_ttls = _load_cache_ttls()
        self._cache = ResponseCache() if self._config.cache_enabled else None

        client_kwargs: dict[str, Any] = {
            "base_url": self._config.base_url,
            "timeout": self._config.timeout,
            "headers": {"Accept": "application/json"},
        }
        if transport is not None:
            client_kwargs["transport"] = transport
        self._http = httpx.Client(**client_kwargs)

    def close(self) -> None:
        """Close the HTTP client."""
        self._http.close()

    def __enter__(self) -> EnvironmentAgencyClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # -- internal helpers ---------------------------------------------------

    def _handle_status(self, response: httpx.Response, path: str) -> None:
        """Raise appropriate exceptions for non-200 status codes."""
        if response.status_code == 403:
            raise ServiceUnavailableError(
                f"Service unavailable (403) for {path}. "
                "The endpoint may be temporarily down or decommissioned.",
                status_code=403,
            )
        if response.status_code == 404:
            raise NotFoundError(f"Resource not found: {path}", status_code=404)
        if response.status_code == 429:
            raise RateLimitError("Rate limit exceeded", status_code=429)
        if response.status_code >= 500:
            raise ServerError(
                f"Server error: {response.status_code}", status_code=response.status_code,
            )
        if response.status_code >= 400:
            raise BadRequestError(
                f"Bad request: {response.status_code} — {response.text[:500]}",
                status_code=response.status_code,
            )

    def _get(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        cache_group: str | None = None,
    ) -> Any:
        """Make a GET request with rate limiting, caching, and retry."""
        ttl = self._cache_ttls.get(cache_group, 0) if cache_group else 0
        if self._cache and ttl > 0:
            cached = self._cache.get("environment_agency", path, params)
            if cached is not None:
                return cached

        self._limiter.wait()

        merged_headers = dict(headers) if headers else None

        def _do_request() -> httpx.Response:
            return self._http.get(path, params=params, headers=merged_headers)

        try:
            response = retry_request(_do_request)
        except httpx.TimeoutException as exc:
            raise EnvironmentAgencyError(
                f"Request to {path} timed out (after retries)",
            ) from exc
        except httpx.HTTPError as exc:
            raise EnvironmentAgencyError(
                f"HTTP error requesting {path}: {exc}",
            ) from exc

        self._handle_status(response, path)

        try:
            data = response.json()
        except ValueError as exc:
            raise EnvironmentAgencyError(
                f"Invalid JSON response from {path}",
            ) from exc

        if self._cache and ttl > 0:
            self._cache.put(
                "environment_agency", path, data, ttl_seconds=ttl, params=params,
            )

        return data

    def _get_csv(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        cache_group: str | None = None,
    ) -> list[dict[str, str]]:
        """GET a CSV endpoint and return as list of dicts."""
        ttl = self._cache_ttls.get(cache_group, 0) if cache_group else 0
        if self._cache and ttl > 0:
            cached = self._cache.get("environment_agency", path, params)
            if cached is not None:
                return cached

        self._limiter.wait()

        def _do_request() -> httpx.Response:
            return self._http.get(path, params=params)

        try:
            response = retry_request(_do_request)
        except httpx.TimeoutException as exc:
            raise EnvironmentAgencyError(
                f"Request to {path} timed out (after retries)",
            ) from exc
        except httpx.HTTPError as exc:
            raise EnvironmentAgencyError(
                f"HTTP error requesting {path}: {exc}",
            ) from exc

        self._handle_status(response, path)

        reader = csv.DictReader(io.StringIO(response.text))
        rows = list(reader)

        if self._cache and ttl > 0:
            with contextlib.suppress(sqlite3.DataError, sqlite3.OperationalError):
                self._cache.put(
                    "environment_agency", path, rows, ttl_seconds=ttl, params=params,
                )

        return rows

    # -- Flood monitoring ---------------------------------------------------
    # API: /flood-monitoring/ — standard JSON with "items" array

    def get_flood_warnings(
        self,
        *,
        county: str | None = None,
        latitude: float | None = None,
        longitude: float | None = None,
        radius_km: float = 5,
        min_severity: int | None = None,
    ) -> dict[str, Any]:
        """Get current flood warnings and alerts."""
        params: dict[str, Any] = {}
        if county:
            params["county"] = county
        if latitude is not None and longitude is not None:
            params["lat"] = latitude
            params["long"] = longitude
            params["dist"] = radius_km
        if min_severity is not None:
            params["min-severity"] = min_severity

        return self._get(
            "/flood-monitoring/id/floods",
            params=params,
            cache_group="flood_warnings",
        )

    def get_flood_areas(self, *, search: str | None = None) -> dict[str, Any]:
        """Get flood risk areas.

        Note: The floodAreas endpoint does not support a 'search' param.
        If search is provided, we fetch all areas and filter client-side
        by matching the label or description.
        """
        raw = self._get(
            "/flood-monitoring/id/floodAreas",
            cache_group="flood_areas",
        )

        if search and raw.get("items"):
            term = search.lower()
            raw["items"] = [
                item for item in raw["items"]
                if term in (item.get("label") or "").lower()
                or term in (item.get("description") or "").lower()
                or term in (item.get("county") or "").lower()
                or term in (item.get("riverOrSea") or "").lower()
            ]

        return raw

    def get_flood_stations(
        self,
        *,
        latitude: float | None = None,
        longitude: float | None = None,
        radius_km: float = 5,
        parameter: str | None = None,
        active_only: bool = True,
    ) -> dict[str, Any]:
        """Search flood monitoring stations."""
        params: dict[str, Any] = {}
        if latitude is not None and longitude is not None:
            params["lat"] = latitude
            params["long"] = longitude
            params["dist"] = radius_km
        if parameter:
            params["parameter"] = parameter
        if active_only:
            params["status"] = "Active"

        return self._get(
            "/flood-monitoring/id/stations",
            params=params,
            cache_group="flood_stations",
        )

    def get_station_readings(
        self,
        station_id: str,
        *,
        limit: int = 100,
        since: str | None = None,
    ) -> dict[str, Any]:
        """Get recent readings for a specific monitoring station."""
        params: dict[str, Any] = {"_sorted": "", "_limit": min(limit, 1000)}
        if since:
            params["since"] = since

        return self._get(
            f"/flood-monitoring/id/stations/{station_id}/readings",
            params=params,
            cache_group="station_readings",
        )

    # -- Water quality (new API) -------------------------------------------
    # API: /water-quality/ — JSON-LD with "member" array, skip/limit pagination
    # Requires Accept: application/ld+json header

    def get_water_quality_sites(
        self,
        *,
        latitude: float | None = None,
        longitude: float | None = None,
        radius_km: float = 5,
        area: str | None = None,
    ) -> dict[str, Any]:
        """Search water quality sampling points."""
        params: dict[str, Any] = {"limit": 250}
        if latitude is not None and longitude is not None:
            params["latitude"] = latitude
            params["longitude"] = longitude
            params["radius"] = radius_km
        if area:
            params["area"] = area

        return self._get(
            "/water-quality/sampling-point",
            params=params,
            headers={"Accept": "application/ld+json"},
            cache_group="water_quality_sites",
        )

    def get_water_quality_results(
        self,
        sampling_point_id: str,
        *,
        determinand: str | None = None,
        year: int | None = None,
    ) -> dict[str, Any]:
        """Get water quality observations for a sampling point."""
        params: dict[str, Any] = {"limit": 250}
        if determinand:
            params["determinand"] = determinand
        if year is not None:
            params["year"] = year

        return self._get(
            f"/water-quality/sampling-point/{sampling_point_id}/observation",
            params=params,
            headers={"Accept": "application/ld+json"},
            cache_group="water_quality_results",
        )

    # -- Bathing water -----------------------------------------------------
    # API: /doc/bathing-water — JSON-LD (currently returning 403)

    def get_bathing_water(
        self,
        *,
        search: str | None = None,
        year: int | None = None,
    ) -> dict[str, Any]:
        """Get bathing water quality classifications.

        Note: This endpoint is currently returning 403 from EA infrastructure.
        The method is built to the documented spec for when it returns.
        """
        params: dict[str, Any] = {"_pageSize": 50}
        if year is not None:
            params["year"] = year

        raw = self._get(
            "/doc/bathing-water.json",
            params=params,
            cache_group="bathing_water",
        )

        # Client-side search filter if needed.
        if search and raw.get("result", {}).get("items"):
            term = search.lower()
            raw["result"]["items"] = [
                item for item in raw["result"]["items"]
                if term in (item.get("name") or "").lower()
                or term in (item.get("label") or "").lower()
            ]

        return raw

    # -- Permits -----------------------------------------------------------
    # API: /public-register/ — JSON with "items" array, per-register endpoints

    def search_permits(
        self,
        *,
        company_name: str | None = None,
        postcode: str | None = None,
        permit_type: str | None = None,
    ) -> dict[str, Any]:
        """Search environmental permits.

        If permit_type is specified, searches that specific register.
        Otherwise, uses the cross-register search endpoint.
        """
        if permit_type and permit_type in _PERMIT_REGISTERS:
            register = _PERMIT_REGISTERS[permit_type]
            params: dict[str, Any] = {"_limit": 50}
            if company_name:
                params["name-search"] = company_name
            return self._get(
                f"/public-register/{register}/registration.json",
                params=params,
                cache_group="permits_search",
            )

        # Cross-register search.
        params = {}
        if company_name:
            params["name-search"] = company_name
        return self._get(
            "/public-register/api/search.json",
            params=params,
            cache_group="permits_search",
        )

    def get_permit_detail(self, permit_number: str) -> dict[str, Any]:
        """Get full details of a specific environmental permit.

        The permit_number encodes the register type in its URL path.
        We try cross-register search first to locate it.
        """
        # Try the cross-register search to find the permit's register
        search_result = self._get(
            "/public-register/api/search.json",
            params={"name-search": permit_number, "_limit": 1},
        )

        items = search_result.get("items", [])
        if items:
            item_id = items[0].get("@id", "")
            # Extract register and ID from the @id URL
            # e.g. ".../public-register/water-discharges/registration/TH-TEMP.0769-002"
            if "/public-register/" in item_id:
                path = item_id.split("/public-register/")[1]
                return self._get(
                    f"/public-register/{path}.json",
                    cache_group="permit_detail",
                )

        raise NotFoundError(
            f"No permit found with number {permit_number}", status_code=404,
        )

    # -- Catchment ---------------------------------------------------------
    # API: /catchment-planning/ — CSV downloads, no JSON endpoints

    def get_catchment(
        self,
        *,
        search: str | None = None,
        latitude: float | None = None,
        longitude: float | None = None,
    ) -> list[dict[str, str]]:
        """Get WFD catchment and waterbody classification data.

        Returns CSV rows as list of dicts. If search is provided,
        filters by Management Catchment, Operational Catchment,
        or Water Body name.
        """
        rows = self._get_csv(
            "/catchment-planning/England/classifications.csv",
            cache_group="catchment",
        )

        if search:
            term = search.lower()
            rows = [
                row for row in rows
                if term in (row.get("Management Catchment") or "").lower()
                or term in (row.get("Operational Catchment") or "").lower()
                or term in (row.get("Water Body") or "").lower()
                or term in (row.get("River Basin District") or "").lower()
            ]

        return rows
