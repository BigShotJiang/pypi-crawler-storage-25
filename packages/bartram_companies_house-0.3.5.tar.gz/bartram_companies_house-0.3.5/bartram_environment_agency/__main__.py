"""Entry point for running the Environment Agency MCP server.

Usage:
    python -m bartram_environment_agency
    uvx bartram-environment-agency
"""

from bartram_environment_agency.serve import main

if __name__ == "__main__":
    main()
