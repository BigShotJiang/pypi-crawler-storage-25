"""Tests for bartram_environment_agency.access — API client with mock transport."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import httpx
import pytest

from bartram_environment_agency.access import (
    BadRequestError,
    EnvironmentAgencyClient,
    EnvironmentAgencyConfig,
    EnvironmentAgencyError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ServiceUnavailableError,
    validate_coordinates,
)

FIXTURES = Path(__file__).parent / "fixtures"


def _load_fixture(name: str) -> Any:
    with open(FIXTURES / name) as f:
        if name.endswith(".csv"):
            return f.read()
        return json.load(f)


def _mock_transport(responses: dict[str, tuple[int, Any]]) -> httpx.MockTransport:
    """Create a mock transport that returns fixtures based on URL path."""

    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        # Check for exact match first, then prefix match.
        for pattern, (status, body) in responses.items():
            if path == pattern or path.startswith(pattern):
                if isinstance(body, str):
                    return httpx.Response(status, text=body)
                return httpx.Response(status, json=body)
        return httpx.Response(404, json={"error": "not_found"})

    return httpx.MockTransport(handler)


def _make_client(responses: dict[str, tuple[int, Any]]) -> EnvironmentAgencyClient:
    """Create a client with mock transport and caching disabled."""
    config = EnvironmentAgencyConfig(cache_enabled=False)
    return EnvironmentAgencyClient(config, transport=_mock_transport(responses))


# ---------------------------------------------------------------------------
# Input validation
# ---------------------------------------------------------------------------


class TestValidateCoordinates:
    def test_both_none_is_valid(self) -> None:
        validate_coordinates(None, None)

    def test_both_provided_valid(self) -> None:
        validate_coordinates(51.5, -0.1)

    def test_latitude_only_raises(self) -> None:
        with pytest.raises(BadRequestError, match="Both latitude and longitude"):
            validate_coordinates(51.5, None)

    def test_longitude_only_raises(self) -> None:
        with pytest.raises(BadRequestError, match="Both latitude and longitude"):
            validate_coordinates(None, -0.1)

    def test_latitude_out_of_range(self) -> None:
        with pytest.raises(BadRequestError, match="Latitude must be between"):
            validate_coordinates(91.0, 0.0)

    def test_longitude_out_of_range(self) -> None:
        with pytest.raises(BadRequestError, match="Longitude must be between"):
            validate_coordinates(0.0, 181.0)

    def test_boundary_values(self) -> None:
        validate_coordinates(90.0, 180.0)
        validate_coordinates(-90.0, -180.0)


# ---------------------------------------------------------------------------
# Exception hierarchy
# ---------------------------------------------------------------------------


class TestExceptionHierarchy:
    @pytest.mark.parametrize(
        "exc_cls",
        [NotFoundError, RateLimitError, ServerError, BadRequestError, ServiceUnavailableError],
    )
    def test_inherits_base(self, exc_cls: type) -> None:
        err = exc_cls("test", status_code=400)
        assert isinstance(err, EnvironmentAgencyError)
        assert err.status_code == 400


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------


class TestConfig:
    def test_defaults(self) -> None:
        config = EnvironmentAgencyConfig()
        assert config.base_url == "https://environment.data.gov.uk"
        assert config.rate_limit == 200
        assert config.rate_period == 60
        assert config.timeout == 30.0
        assert config.cache_enabled is True


# ---------------------------------------------------------------------------
# Flood monitoring endpoints
# ---------------------------------------------------------------------------


class TestFloodWarnings:
    def test_returns_items(self) -> None:
        fixture = _load_fixture("flood_warnings.json")
        client = _make_client({"/flood-monitoring/id/floods": (200, fixture)})
        result = client.get_flood_warnings(county="Somerset")
        assert "items" in result
        assert isinstance(result["items"], list)

    def test_items_have_expected_fields(self) -> None:
        fixture = _load_fixture("flood_warnings.json")
        client = _make_client({"/flood-monitoring/id/floods": (200, fixture)})
        result = client.get_flood_warnings(county="Somerset")
        if result["items"]:
            item = result["items"][0]
            assert "severityLevel" in item
            assert "description" in item
            assert "floodAreaID" in item

    def test_404_raises_not_found(self) -> None:
        client = _make_client({"/flood-monitoring/id/floods": (404, {"error": "not found"})})
        with pytest.raises(NotFoundError):
            client.get_flood_warnings(county="Nonexistent")

    def test_500_raises_server_error(self) -> None:
        client = _make_client({"/flood-monitoring/id/floods": (500, {"error": "internal"})})
        with pytest.raises(ServerError):
            client.get_flood_warnings(county="Somerset")


class TestFloodAreas:
    def test_returns_items(self) -> None:
        fixture = _load_fixture("flood_areas.json")
        client = _make_client({"/flood-monitoring/id/floodAreas": (200, fixture)})
        result = client.get_flood_areas()
        assert "items" in result

    def test_items_have_expected_fields(self) -> None:
        fixture = _load_fixture("flood_areas.json")
        client = _make_client({"/flood-monitoring/id/floodAreas": (200, fixture)})
        result = client.get_flood_areas()
        if result["items"]:
            item = result["items"][0]
            assert "county" in item
            assert "notation" in item
            assert "lat" in item
            assert "long" in item

    def test_search_filters_client_side(self) -> None:
        fixture = _load_fixture("flood_areas.json")
        client = _make_client({"/flood-monitoring/id/floodAreas": (200, fixture)})
        result = client.get_flood_areas(search="Lincoln")
        # Should only include items mentioning Lincoln
        for item in result["items"]:
            text = (
                (item.get("label") or "")
                + (item.get("description") or "")
                + (item.get("county") or "")
            ).lower()
            assert "lincoln" in text


class TestFloodStations:
    def test_returns_items(self) -> None:
        fixture = _load_fixture("flood_stations.json")
        client = _make_client({"/flood-monitoring/id/stations": (200, fixture)})
        result = client.get_flood_stations(latitude=51.5, longitude=-0.1)
        assert "items" in result

    def test_station_has_measures(self) -> None:
        fixture = _load_fixture("flood_stations.json")
        client = _make_client({"/flood-monitoring/id/stations": (200, fixture)})
        result = client.get_flood_stations(latitude=51.5, longitude=-0.1)
        if result["items"]:
            item = result["items"][0]
            assert "notation" in item
            assert "lat" in item
            assert "long" in item


class TestStationReadings:
    def test_returns_items(self) -> None:
        fixture = _load_fixture("station_readings.json")
        client = _make_client({"/flood-monitoring/id/stations/0006/readings": (200, fixture)})
        result = client.get_station_readings("0006")
        assert "items" in result

    def test_readings_have_value_and_datetime(self) -> None:
        fixture = _load_fixture("station_readings.json")
        client = _make_client({"/flood-monitoring/id/stations/0006/readings": (200, fixture)})
        result = client.get_station_readings("0006")
        if result["items"]:
            reading = result["items"][0]
            assert "value" in reading
            assert "dateTime" in reading

    def test_404_for_unknown_station(self) -> None:
        client = _make_client({})  # no matching routes
        with pytest.raises(NotFoundError):
            client.get_station_readings("NONEXISTENT")


# ---------------------------------------------------------------------------
# Water quality endpoints
# ---------------------------------------------------------------------------


class TestWaterQualitySites:
    def test_returns_members(self) -> None:
        fixture = _load_fixture("water_quality_sites.json")
        client = _make_client({"/water-quality/sampling-point": (200, fixture)})
        result = client.get_water_quality_sites(latitude=51.5, longitude=-0.1)
        assert "member" in result
        assert "totalItems" in result

    def test_site_has_notation_and_geometry(self) -> None:
        fixture = _load_fixture("water_quality_sites.json")
        client = _make_client({"/water-quality/sampling-point": (200, fixture)})
        result = client.get_water_quality_sites(latitude=51.5, longitude=-0.1)
        if result["member"]:
            site = result["member"][0]
            assert "notation" in site
            assert "prefLabel" in site


class TestWaterQualityResults:
    def test_returns_members(self) -> None:
        fixture = _load_fixture("water_quality_results.json")
        client = _make_client({
            "/water-quality/sampling-point/TH-PGPE0038/observation": (200, fixture),
        })
        result = client.get_water_quality_results("TH-PGPE0038")
        assert "member" in result
        assert "totalItems" in result


# ---------------------------------------------------------------------------
# Permits endpoints
# ---------------------------------------------------------------------------


class TestPermitsSearch:
    def test_cross_register_search(self) -> None:
        fixture = _load_fixture("permits_search.json")
        client = _make_client({"/public-register/api/search.json": (200, fixture)})
        result = client.search_permits(company_name="Thames Water")
        assert "items" in result

    def test_permit_has_holder_and_registration(self) -> None:
        fixture = _load_fixture("permits_search.json")
        client = _make_client({"/public-register/": (200, fixture)})
        result = client.search_permits(company_name="Thames Water", permit_type="waste")
        if result["items"]:
            item = result["items"][0]
            assert "holder" in item
            assert "registrationNumber" in item or "registration" in str(item.get("@id", ""))

    def test_per_register_search(self) -> None:
        fixture = _load_fixture("permits_search.json")
        client = _make_client({
            "/public-register/waste-operations/registration.json": (200, fixture),
        })
        result = client.search_permits(company_name="Thames", permit_type="waste")
        assert "items" in result


class TestPermitDetail:
    def test_returns_detail(self) -> None:
        search_fixture = {
            "items": [{
                "@id": "http://example.com/public-register/water-discharges/registration/TEST-001",
            }],
        }
        detail_fixture = _load_fixture("permit_detail.json")
        client = _make_client({
            "/public-register/api/search.json": (200, search_fixture),
            "/public-register/water-discharges/registration/TEST-001.json": (200, detail_fixture),
        })
        result = client.get_permit_detail("TEST-001")
        assert "items" in result

    def test_not_found_raises(self) -> None:
        client = _make_client({
            "/public-register/api/search.json": (200, {"items": []}),
        })
        with pytest.raises(NotFoundError, match="No permit found"):
            client.get_permit_detail("NONEXISTENT")


# ---------------------------------------------------------------------------
# Catchment endpoint
# ---------------------------------------------------------------------------


class TestCatchment:
    def test_returns_rows(self) -> None:
        csv_text = (FIXTURES / "catchment_classifications.csv").read_text()
        client = _make_client({
            "/catchment-planning/England/classifications.csv": (200, csv_text),
        })
        result = client.get_catchment()
        assert isinstance(result, list)
        assert len(result) > 0

    def test_row_has_expected_fields(self) -> None:
        csv_text = (FIXTURES / "catchment_classifications.csv").read_text()
        client = _make_client({
            "/catchment-planning/England/classifications.csv": (200, csv_text),
        })
        result = client.get_catchment()
        if result:
            row = result[0]
            assert "Water Body" in row
            assert "Management Catchment" in row
            assert "Status" in row

    def test_search_filters(self) -> None:
        csv_text = (FIXTURES / "catchment_classifications.csv").read_text()
        client = _make_client({
            "/catchment-planning/England/classifications.csv": (200, csv_text),
        })
        result = client.get_catchment(search="Adur")
        for row in result:
            text = (
                (row.get("Management Catchment") or "")
                + (row.get("Water Body") or "")
            ).lower()
            assert "adur" in text


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------


class TestErrorHandling:
    def test_403_raises_service_unavailable(self) -> None:
        client = _make_client({"/doc/bathing-water.json": (403, "Forbidden")})
        with pytest.raises(ServiceUnavailableError):
            client.get_bathing_water()

    def test_429_raises_rate_limit(self) -> None:
        client = _make_client({"/flood-monitoring/id/floods": (429, {"error": "rate limited"})})
        with pytest.raises(RateLimitError):
            client.get_flood_warnings(county="Test")
