"""Tests for bartram_environment_agency.serve — end-to-end MCP tool tests."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import httpx
import pytest

from bartram_environment_agency.access import EnvironmentAgencyClient, EnvironmentAgencyConfig
from bartram_environment_agency.serve import server

FIXTURES = Path(__file__).parent / "fixtures"


def _load_fixture(name: str) -> Any:
    with open(FIXTURES / name) as f:
        if name.endswith(".csv"):
            return f.read()
        return json.load(f)


def _mock_transport(responses: dict[str, tuple[int, Any]]) -> httpx.MockTransport:
    """Create a mock transport that returns fixtures based on URL path."""

    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        for pattern, (status, body) in responses.items():
            if path == pattern or path.startswith(pattern):
                if isinstance(body, str):
                    return httpx.Response(status, text=body)
                return httpx.Response(status, json=body)
        return httpx.Response(404, json={"error": "not_found"})

    return httpx.MockTransport(handler)


def _make_client(responses: dict[str, tuple[int, Any]]) -> EnvironmentAgencyClient:
    config = EnvironmentAgencyConfig(cache_enabled=False)
    return EnvironmentAgencyClient(config, transport=_mock_transport(responses))


# ---------------------------------------------------------------------------
# Server registration
# ---------------------------------------------------------------------------


class TestServerRegistration:
    def test_server_name(self) -> None:
        assert server.name == "bartram-environment-agency"

    def test_tool_count(self) -> None:
        tools = server._tool_manager._tools
        assert len(tools) == 10

    def test_tool_names(self) -> None:
        tools = server._tool_manager._tools
        expected = {
            "uk_environment_agency_flood_warnings",
            "uk_environment_agency_flood_areas",
            "uk_environment_agency_flood_stations",
            "uk_environment_agency_station_readings",
            "uk_environment_agency_water_quality_sites",
            "uk_environment_agency_water_quality_results",
            "uk_environment_agency_bathing_water",
            "uk_environment_agency_permits_search",
            "uk_environment_agency_permit_detail",
            "uk_environment_agency_catchment",
        }
        assert set(tools.keys()) == expected


# ---------------------------------------------------------------------------
# End-to-end tests — full access→clean→serve pipeline via mock transport
# ---------------------------------------------------------------------------


def _parse_response(raw: str) -> dict[str, Any]:
    """Parse a JSON response string from a serve function."""
    return json.loads(raw)


class TestFloodWarningsE2E:
    @pytest.fixture(autouse=True)
    def _patch_client(self) -> Any:
        fixture = _load_fixture("flood_warnings.json")
        client = _make_client({"/flood-monitoring/id/floods": (200, fixture)})
        with (
            patch("bartram_environment_agency.serve._get_client", return_value=client),
            patch("bartram_environment_agency.serve._get_metrics", return_value=MagicMock()),
        ):
            yield

    @pytest.mark.asyncio
    async def test_returns_data_and_metadata(self) -> None:
        from bartram_environment_agency.serve import uk_environment_agency_flood_warnings

        result = _parse_response(
            await uk_environment_agency_flood_warnings(county="Somerset")
        )
        assert "data" in result
        assert "metadata" in result
        assert result["metadata"]["source"] == "Environment Agency Open Data"
        assert result["data"]["total_results"] >= 1

    @pytest.mark.asyncio
    async def test_items_have_cleaning_annotations(self) -> None:
        from bartram_environment_agency.serve import uk_environment_agency_flood_warnings

        result = _parse_response(
            await uk_environment_agency_flood_warnings(county="Somerset")
        )
        for item in result["data"]["items"]:
            assert "_cleaning" in item

    @pytest.mark.asyncio
    async def test_validation_error(self) -> None:
        from bartram_environment_agency.serve import uk_environment_agency_flood_warnings

        result = _parse_response(
            await uk_environment_agency_flood_warnings()
        )
        assert "error" in result


class TestFloodAreasE2E:
    @pytest.fixture(autouse=True)
    def _patch_client(self) -> Any:
        fixture = _load_fixture("flood_areas.json")
        client = _make_client({"/flood-monitoring/id/floodAreas": (200, fixture)})
        with (
            patch("bartram_environment_agency.serve._get_client", return_value=client),
            patch("bartram_environment_agency.serve._get_metrics", return_value=MagicMock()),
        ):
            yield

    @pytest.mark.asyncio
    async def test_returns_areas(self) -> None:
        from bartram_environment_agency.serve import uk_environment_agency_flood_areas

        result = _parse_response(await uk_environment_agency_flood_areas())
        assert result["data"]["total_results"] >= 1

    @pytest.mark.asyncio
    async def test_empty_search_error(self) -> None:
        from bartram_environment_agency.serve import uk_environment_agency_flood_areas

        result = _parse_response(await uk_environment_agency_flood_areas(search=""))
        assert "error" in result


class TestFloodStationsE2E:
    @pytest.fixture(autouse=True)
    def _patch_client(self) -> Any:
        fixture = _load_fixture("flood_stations.json")
        client = _make_client({"/flood-monitoring/id/stations": (200, fixture)})
        with (
            patch("bartram_environment_agency.serve._get_client", return_value=client),
            patch("bartram_environment_agency.serve._get_metrics", return_value=MagicMock()),
        ):
            yield

    @pytest.mark.asyncio
    async def test_returns_stations(self) -> None:
        from bartram_environment_agency.serve import uk_environment_agency_flood_stations

        result = _parse_response(
            await uk_environment_agency_flood_stations(latitude=51.5, longitude=-0.1)
        )
        assert result["data"]["total_results"] >= 1

    @pytest.mark.asyncio
    async def test_invalid_parameter(self) -> None:
        from bartram_environment_agency.serve import uk_environment_agency_flood_stations

        result = _parse_response(
            await uk_environment_agency_flood_stations(parameter="invalid")
        )
        assert "error" in result


class TestStationReadingsE2E:
    @pytest.fixture(autouse=True)
    def _patch_client(self) -> Any:
        fixture = _load_fixture("station_readings.json")
        client = _make_client({"/flood-monitoring/id/stations/0006/readings": (200, fixture)})
        with (
            patch("bartram_environment_agency.serve._get_client", return_value=client),
            patch("bartram_environment_agency.serve._get_metrics", return_value=MagicMock()),
        ):
            yield

    @pytest.mark.asyncio
    async def test_returns_readings(self) -> None:
        from bartram_environment_agency.serve import uk_environment_agency_station_readings

        result = _parse_response(
            await uk_environment_agency_station_readings(station_id="0006")
        )
        assert result["data"]["total_readings"] >= 1

    @pytest.mark.asyncio
    async def test_missing_station_id(self) -> None:
        from bartram_environment_agency.serve import uk_environment_agency_station_readings

        result = _parse_response(await uk_environment_agency_station_readings())
        assert "error" in result


class TestWaterQualitySitesE2E:
    @pytest.fixture(autouse=True)
    def _patch_client(self) -> Any:
        fixture = _load_fixture("water_quality_sites.json")
        client = _make_client({"/water-quality/sampling-point": (200, fixture)})
        with (
            patch("bartram_environment_agency.serve._get_client", return_value=client),
            patch("bartram_environment_agency.serve._get_metrics", return_value=MagicMock()),
        ):
            yield

    @pytest.mark.asyncio
    async def test_returns_sites(self) -> None:
        from bartram_environment_agency.serve import uk_environment_agency_water_quality_sites

        result = _parse_response(
            await uk_environment_agency_water_quality_sites(latitude=51.5, longitude=-0.1)
        )
        assert result["data"]["total_results"] >= 1


class TestWaterQualityResultsE2E:
    @pytest.fixture(autouse=True)
    def _patch_client(self) -> Any:
        fixture = _load_fixture("water_quality_results.json")
        client = _make_client({
            "/water-quality/sampling-point/TH-PGPE0038/observation": (200, fixture),
        })
        with (
            patch("bartram_environment_agency.serve._get_client", return_value=client),
            patch("bartram_environment_agency.serve._get_metrics", return_value=MagicMock()),
        ):
            yield

    @pytest.mark.asyncio
    async def test_returns_measurements(self) -> None:
        from bartram_environment_agency.serve import uk_environment_agency_water_quality_results

        result = _parse_response(
            await uk_environment_agency_water_quality_results(
                sampling_point_id="TH-PGPE0038",
            )
        )
        assert result["data"]["total_results"] >= 1

    @pytest.mark.asyncio
    async def test_missing_sampling_point(self) -> None:
        from bartram_environment_agency.serve import uk_environment_agency_water_quality_results

        result = _parse_response(
            await uk_environment_agency_water_quality_results()
        )
        assert "error" in result


class TestPermitsSearchE2E:
    @pytest.fixture(autouse=True)
    def _patch_client(self) -> Any:
        fixture = _load_fixture("permits_search.json")
        client = _make_client({
            "/public-register/api/search.json": (200, fixture),
            "/public-register/waste-operations/registration.json": (200, fixture),
        })
        with (
            patch("bartram_environment_agency.serve._get_client", return_value=client),
            patch("bartram_environment_agency.serve._get_metrics", return_value=MagicMock()),
        ):
            yield

    @pytest.mark.asyncio
    async def test_returns_permits(self) -> None:
        from bartram_environment_agency.serve import uk_environment_agency_permits_search

        result = _parse_response(
            await uk_environment_agency_permits_search(company_name="Thames Water")
        )
        assert result["data"]["total_results"] >= 1
        assert result["metadata"]["licence"] == "EA Conditional Licence"

    @pytest.mark.asyncio
    async def test_no_filters_error(self) -> None:
        from bartram_environment_agency.serve import uk_environment_agency_permits_search

        result = _parse_response(await uk_environment_agency_permits_search())
        assert "error" in result

    @pytest.mark.asyncio
    async def test_invalid_permit_type(self) -> None:
        from bartram_environment_agency.serve import uk_environment_agency_permits_search

        result = _parse_response(
            await uk_environment_agency_permits_search(permit_type="invalid")
        )
        assert "error" in result


class TestPermitDetailE2E:
    @pytest.fixture(autouse=True)
    def _patch_client(self) -> Any:
        search_fixture = {
            "items": [{
                "@id": "http://example.com/public-register/water-discharges/registration/TEST",
            }],
        }
        detail_fixture = _load_fixture("permit_detail.json")
        client = _make_client({
            "/public-register/api/search.json": (200, search_fixture),
            "/public-register/water-discharges/registration/TEST.json": (200, detail_fixture),
        })
        with (
            patch("bartram_environment_agency.serve._get_client", return_value=client),
            patch("bartram_environment_agency.serve._get_metrics", return_value=MagicMock()),
        ):
            yield

    @pytest.mark.asyncio
    async def test_returns_detail(self) -> None:
        from bartram_environment_agency.serve import uk_environment_agency_permit_detail

        result = _parse_response(
            await uk_environment_agency_permit_detail(permit_number="TEST")
        )
        assert "data" in result
        assert result["metadata"]["licence"] == "EA Conditional Licence"

    @pytest.mark.asyncio
    async def test_missing_permit_number(self) -> None:
        from bartram_environment_agency.serve import uk_environment_agency_permit_detail

        result = _parse_response(await uk_environment_agency_permit_detail())
        assert "error" in result


class TestBathingWaterE2E:
    @pytest.fixture(autouse=True)
    def _patch_client(self) -> Any:
        fixture = {"result": {"items": [
            {"name": "Test Beach", "notation": "TB001", "lat": 50.0, "long": -1.0},
        ]}}
        client = _make_client({"/doc/bathing-water.json": (200, fixture)})
        with (
            patch("bartram_environment_agency.serve._get_client", return_value=client),
            patch("bartram_environment_agency.serve._get_metrics", return_value=MagicMock()),
        ):
            yield

    @pytest.mark.asyncio
    async def test_returns_data(self) -> None:
        from bartram_environment_agency.serve import uk_environment_agency_bathing_water

        result = _parse_response(await uk_environment_agency_bathing_water())
        assert "data" in result
        assert result["data"]["total_results"] >= 1

    @pytest.mark.asyncio
    async def test_empty_search_error(self) -> None:
        from bartram_environment_agency.serve import uk_environment_agency_bathing_water

        result = _parse_response(await uk_environment_agency_bathing_water(search=""))
        assert "error" in result


class TestBathingWater403E2E:
    """Test the known 403 case — bathing water API is currently down."""

    @pytest.fixture(autouse=True)
    def _patch_client(self) -> Any:
        client = _make_client({"/doc/bathing-water.json": (403, {"error": "forbidden"})})
        with (
            patch("bartram_environment_agency.serve._get_client", return_value=client),
            patch("bartram_environment_agency.serve._get_metrics", return_value=MagicMock()),
        ):
            yield

    @pytest.mark.asyncio
    async def test_403_returns_error(self) -> None:
        from bartram_environment_agency.serve import uk_environment_agency_bathing_water

        result = _parse_response(await uk_environment_agency_bathing_water())
        assert "error" in result


class TestAPIErrorPropagation:
    """Test that API errors are caught and formatted correctly through serve."""

    @pytest.fixture(autouse=True)
    def _patch_client(self) -> Any:
        client = _make_client({"/flood-monitoring/id/floods": (500, {"error": "internal"})})
        with (
            patch("bartram_environment_agency.serve._get_client", return_value=client),
            patch("bartram_environment_agency.serve._get_metrics", return_value=MagicMock()),
        ):
            yield

    @pytest.mark.asyncio
    async def test_500_returns_error_response(self) -> None:
        from bartram_environment_agency.serve import uk_environment_agency_flood_warnings

        result = _parse_response(
            await uk_environment_agency_flood_warnings(county="Test")
        )
        assert "error" in result
        assert "attribution" in result


class TestCatchmentE2E:
    @pytest.fixture(autouse=True)
    def _patch_client(self) -> Any:
        csv_text = (FIXTURES / "catchment_classifications.csv").read_text()
        client = _make_client({
            "/catchment-planning/England/classifications.csv": (200, csv_text),
        })
        with (
            patch("bartram_environment_agency.serve._get_client", return_value=client),
            patch("bartram_environment_agency.serve._get_metrics", return_value=MagicMock()),
        ):
            yield

    @pytest.mark.asyncio
    async def test_returns_catchments(self) -> None:
        from bartram_environment_agency.serve import uk_environment_agency_catchment

        result = _parse_response(await uk_environment_agency_catchment())
        assert result["data"]["total_results"] >= 1
        assert result["metadata"]["source"] == "Environment Agency Open Data"
