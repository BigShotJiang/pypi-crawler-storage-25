"""Tests for bartram_environment_agency.clean — data cleaning logic."""

from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any

from bartram_environment_agency.clean import (
    _BATHING_CLASSIFICATION_MAP,
    _PERMIT_STATUS_MAP,
    _SEVERITY_MAP,
    _WFD_CLASSIFICATION_MAP,
    _parse_wkt_point,
    clean_bathing_water,
    clean_catchment,
    clean_flood_areas,
    clean_flood_stations,
    clean_flood_warnings,
    clean_permit_detail,
    clean_permits_search,
    clean_station_readings,
    clean_water_quality_results,
    clean_water_quality_sites,
)

FIXTURES = Path(__file__).parent / "fixtures"


def _load(name: str) -> Any:
    with open(FIXTURES / name) as f:
        if name.endswith(".csv"):
            return list(csv.DictReader(f))
        return json.load(f)


# ---------------------------------------------------------------------------
# Mapping tables
# ---------------------------------------------------------------------------


class TestMappingTables:
    def test_severity_map_has_all_levels(self) -> None:
        assert set(_SEVERITY_MAP.keys()) == {1, 2, 3, 4}

    def test_wfd_map_has_all_statuses(self) -> None:
        assert set(_WFD_CLASSIFICATION_MAP.keys()) == {"H", "G", "M", "P", "B"}

    def test_bathing_map(self) -> None:
        assert set(_BATHING_CLASSIFICATION_MAP.keys()) == {"E", "G", "S", "P"}

    def test_permit_status_map(self) -> None:
        assert _PERMIT_STATUS_MAP["A"] == "Active"


# ---------------------------------------------------------------------------
# WKT parsing
# ---------------------------------------------------------------------------


class TestParseWktPoint:
    def test_valid_point(self) -> None:
        e, n = _parse_wkt_point("POINT(532410 183480) <http://example.com>")
        assert e == 532410.0
        assert n == 183480.0

    def test_none(self) -> None:
        assert _parse_wkt_point(None) == (None, None)

    def test_empty(self) -> None:
        assert _parse_wkt_point("") == (None, None)

    def test_invalid(self) -> None:
        assert _parse_wkt_point("LINESTRING(0 0, 1 1)") == (None, None)


# ---------------------------------------------------------------------------
# Flood warnings
# ---------------------------------------------------------------------------


class TestCleanFloodWarnings:
    def test_from_fixture(self) -> None:
        raw = _load("flood_warnings.json")
        result = clean_flood_warnings(raw)
        assert result["total_results"] >= 1
        assert isinstance(result["items"], list)

    def test_severity_mapped(self) -> None:
        raw = _load("flood_warnings.json")
        result = clean_flood_warnings(raw)
        for item in result["items"]:
            assert "severity" in item
            assert "severity_code" in item
            assert "_cleaning" in item
            assert item["_cleaning"]["severity_mapped"] is True

    def test_fields_present(self) -> None:
        raw = _load("flood_warnings.json")
        result = clean_flood_warnings(raw)
        for item in result["items"]:
            assert "warning_id" in item
            assert "description" in item
            assert "issued_at" in item
            assert "guidance" in item

    def test_empty_response(self) -> None:
        result = clean_flood_warnings({"items": []})
        assert result["total_results"] == 0
        assert result["items"] == []

    def test_null_items(self) -> None:
        result = clean_flood_warnings({"items": None})
        assert result["total_results"] == 0


# ---------------------------------------------------------------------------
# Flood areas
# ---------------------------------------------------------------------------


class TestCleanFloodAreas:
    def test_from_fixture(self) -> None:
        raw = _load("flood_areas.json")
        result = clean_flood_areas(raw)
        assert result["total_results"] >= 1

    def test_fields_present(self) -> None:
        raw = _load("flood_areas.json")
        result = clean_flood_areas(raw)
        for item in result["items"]:
            assert "area_id" in item
            assert "area_name" in item
            assert "centroid_latitude" in item
            assert "centroid_longitude" in item


# ---------------------------------------------------------------------------
# Flood stations
# ---------------------------------------------------------------------------


class TestCleanFloodStations:
    def test_from_fixture(self) -> None:
        raw = _load("flood_stations.json")
        result = clean_flood_stations(raw)
        assert result["total_results"] >= 1

    def test_station_fields(self) -> None:
        raw = _load("flood_stations.json")
        result = clean_flood_stations(raw)
        for item in result["items"]:
            assert "station_id" in item
            assert "station_name" in item
            assert "latitude" in item
            assert "longitude" in item
            assert "status" in item
            assert "links" in item

    def test_status_interpreted(self) -> None:
        raw = _load("flood_stations.json")
        result = clean_flood_stations(raw)
        for item in result["items"]:
            assert item["_cleaning"]["status_interpreted"] is True


# ---------------------------------------------------------------------------
# Station readings
# ---------------------------------------------------------------------------


class TestCleanStationReadings:
    def test_from_fixture(self) -> None:
        raw = _load("station_readings.json")
        result = clean_station_readings(raw)
        assert result["total_readings"] >= 1
        assert isinstance(result["readings"], list)

    def test_reading_has_value_and_timestamp(self) -> None:
        raw = _load("station_readings.json")
        result = clean_station_readings(raw)
        for reading in result["readings"]:
            assert "value" in reading
            assert "timestamp" in reading

    def test_missing_values_flagged(self) -> None:
        raw = {"items": [{"value": None, "dateTime": "2026-01-01T00:00:00Z"}]}
        result = clean_station_readings(raw)
        assert result["_cleaning"]["has_missing_values"] is True
        assert 0 in result["_cleaning"]["missing_indices"]

    def test_no_missing_values(self) -> None:
        raw = {"items": [{"value": 1.5, "dateTime": "2026-01-01T00:00:00Z"}]}
        result = clean_station_readings(raw)
        assert result["_cleaning"]["has_missing_values"] is False


# ---------------------------------------------------------------------------
# Water quality sites
# ---------------------------------------------------------------------------


class TestCleanWaterQualitySites:
    def test_from_fixture(self) -> None:
        raw = _load("water_quality_sites.json")
        result = clean_water_quality_sites(raw)
        assert result["total_results"] >= 1

    def test_site_fields(self) -> None:
        raw = _load("water_quality_sites.json")
        result = clean_water_quality_sites(raw)
        for item in result["items"]:
            assert "sampling_point_id" in item
            assert "sampling_point_name" in item
            assert "region" in item

    def test_wkt_parsed(self) -> None:
        raw = _load("water_quality_sites.json")
        result = clean_water_quality_sites(raw)
        for item in result["items"]:
            # WKT should have been parsed to easting/northing.
            if item["easting"] is not None:
                assert isinstance(item["easting"], float)


# ---------------------------------------------------------------------------
# Water quality results
# ---------------------------------------------------------------------------


class TestCleanWaterQualityResults:
    def test_from_fixture(self) -> None:
        raw = _load("water_quality_results.json")
        result = clean_water_quality_results(raw)
        assert result["total_results"] >= 1
        assert isinstance(result["measurements"], list)

    def test_measurement_fields(self) -> None:
        raw = _load("water_quality_results.json")
        result = clean_water_quality_results(raw)
        for m in result["measurements"]:
            assert "determinand" in m
            assert "value" in m
            assert "unit" in m
            assert "measurement_date" in m

    def test_empty_response(self) -> None:
        result = clean_water_quality_results({"member": []})
        assert result["total_results"] == 0
        assert result["measurements"] == []


# ---------------------------------------------------------------------------
# Bathing water
# ---------------------------------------------------------------------------


class TestCleanBathingWater:
    def test_empty_response(self) -> None:
        result = clean_bathing_water({"items": []})
        assert result["total_results"] == 0

    def test_with_items(self) -> None:
        raw = {"items": [{"name": "Test Beach", "notation": "TB001", "lat": 50.0, "long": -1.0}]}
        result = clean_bathing_water(raw)
        assert result["total_results"] == 1
        assert result["items"][0]["name"] == "Test Beach"


# ---------------------------------------------------------------------------
# Permits search
# ---------------------------------------------------------------------------


class TestCleanPermitsSearch:
    def test_from_fixture(self) -> None:
        raw = _load("permits_search.json")
        result = clean_permits_search(raw)
        assert result["total_results"] >= 1

    def test_permit_fields(self) -> None:
        raw = _load("permits_search.json")
        result = clean_permits_search(raw)
        for item in result["items"]:
            assert "permit_number" in item
            assert "permit_status" in item
            assert "company_name" in item
            assert "_cleaning" in item
            assert item["_cleaning"]["licence"] == "EA Conditional Licence"


# ---------------------------------------------------------------------------
# Permit detail
# ---------------------------------------------------------------------------


class TestCleanPermitDetail:
    def test_from_fixture(self) -> None:
        raw = _load("permit_detail.json")
        result = clean_permit_detail(raw)
        assert "permit_number" in result
        assert "company_name" in result

    def test_licence_annotation(self) -> None:
        raw = _load("permit_detail.json")
        result = clean_permit_detail(raw)
        assert result["_cleaning"]["licence"] == "EA Conditional Licence"

    def test_empty_items(self) -> None:
        result = clean_permit_detail({"items": []})
        assert result["error"] == "not_found"


# ---------------------------------------------------------------------------
# Catchment
# ---------------------------------------------------------------------------


class TestCleanCatchment:
    def test_from_fixture(self) -> None:
        rows = _load("catchment_classifications.csv")
        result = clean_catchment(rows)
        assert result["total_results"] >= 1

    def test_waterbody_fields(self) -> None:
        rows = _load("catchment_classifications.csv")
        result = clean_catchment(rows)
        for item in result["items"]:
            assert "waterbody_id" in item
            assert "waterbody_name" in item
            assert "management_catchment" in item
            assert "_cleaning" in item

    def test_empty(self) -> None:
        result = clean_catchment([])
        assert result["total_results"] == 0
        assert result["items"] == []
