"""MCP tool definitions for Environment Agency Open Data — what agents call.

10 tools exposed:
- uk_environment_agency_flood_warnings: Current flood warnings and alerts
- uk_environment_agency_flood_areas: Flood risk areas
- uk_environment_agency_flood_stations: Flood monitoring stations
- uk_environment_agency_station_readings: Station readings (water level, rainfall, tidal)
- uk_environment_agency_water_quality_sites: Water quality sampling points
- uk_environment_agency_water_quality_results: Water quality measurements
- uk_environment_agency_bathing_water: Bathing water quality classifications
- uk_environment_agency_permits_search: Environmental permits search
- uk_environment_agency_permit_detail: Permit full details
- uk_environment_agency_catchment: WFD catchment and waterbody data
"""

from __future__ import annotations

import threading
import time

from mcp.server.fastmcp import FastMCP

from bartram_environment_agency.access import (
    BadRequestError,
    EnvironmentAgencyClient,
    EnvironmentAgencyConfig,
    EnvironmentAgencyError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ServiceUnavailableError,
    validate_coordinates,
)
from bartram_environment_agency.clean import (
    clean_bathing_water,
    clean_catchment,
    clean_flood_areas,
    clean_flood_stations,
    clean_flood_warnings,
    clean_permit_detail,
    clean_permits_search,
    clean_station_readings,
    clean_water_quality_results,
    clean_water_quality_sites,
)
from bartram_foundry.monitoring import MetricsStore
from bartram_foundry.serve_helpers import (
    ToolServerConfig,
    format_error,
    format_response,
    record_call,
)

# ---------------------------------------------------------------------------
# Server setup
# ---------------------------------------------------------------------------

server = FastMCP(
    "bartram-environment-agency",
    instructions=(
        "Environment Agency Open Data — flood monitoring, water quality, "
        "environmental permits, and catchment data for England. 10 tools "
        "covering flood warnings, monitoring stations, water quality "
        "sampling, bathing water classifications, environmental permits, "
        "and WFD catchment data. "
        "Source: Environment Agency Open Data. "
        "Contains Environment Agency information © Environment Agency "
        "and/or database right. Licensed under the Open Government "
        "Licence v3.0."
    ),
)

_client: EnvironmentAgencyClient | None = None
_metrics: MetricsStore | None = None
_init_lock = threading.Lock()


def _get_client() -> EnvironmentAgencyClient:
    """Get or create the API client (lazy init, thread-safe)."""
    global _client
    if _client is None:
        with _init_lock:
            if _client is None:
                _client = EnvironmentAgencyClient(EnvironmentAgencyConfig.from_env())
    return _client


def _get_metrics() -> MetricsStore:
    """Get or create the metrics store (lazy init, thread-safe)."""
    global _metrics
    if _metrics is None:
        with _init_lock:
            if _metrics is None:
                _metrics = MetricsStore()
    return _metrics


# ---------------------------------------------------------------------------
# Server configuration
# ---------------------------------------------------------------------------

_CONFIG = ToolServerConfig(
    source_name="Environment Agency Open Data",
    licence="Open Government Licence v3",
    attribution=(
        "Contains Environment Agency information © Environment Agency "
        "and/or database right. Licensed under the Open Government "
        "Licence v3.0."
    ),
)

_PERMITS_CONFIG = ToolServerConfig(
    source_name="Environment Agency Open Data",
    licence="EA Conditional Licence",
    attribution=(
        "Contains Environment Agency information © Environment Agency "
        "and/or database right. Licensed under the Open Government "
        "Licence v3.0 (except Public Registers: EA Conditional Licence)."
    ),
)


def _error_type(error: EnvironmentAgencyError) -> str:
    """Map EA-specific exception classes to error type strings."""
    if isinstance(error, NotFoundError):
        return "not_found"
    if isinstance(error, BadRequestError):
        return "bad_request"
    if isinstance(error, RateLimitError):
        return "rate_limited"
    if isinstance(error, ServerError):
        return "server_error"
    if isinstance(error, ServiceUnavailableError):
        return "service_unavailable"
    return "api_error"


# ---------------------------------------------------------------------------
# Tools — Flood monitoring
# ---------------------------------------------------------------------------


@server.tool()
async def uk_environment_agency_flood_warnings(
    location: str | None = None,
    county: str | None = None,
    latitude: float | None = None,
    longitude: float | None = None,
    radius_km: float = 5,
    min_severity: int | None = None,
) -> str:
    """Get current flood warnings and alerts for a location or area.

    Provide at least one of: location, county, or latitude+longitude.
    Severity levels: 1=Severe Warning, 2=Warning, 3=Alert,
    4=Warning No Longer In Force.
    """
    start = time.monotonic()
    try:
        if not location and not county and latitude is None and longitude is None:
            return format_error(
                _CONFIG,
                BadRequestError(
                    "At least one of location, county, or latitude+longitude is required."
                ),
                error_type_fn=_error_type,
            )

        validate_coordinates(latitude, longitude)

        # Use location as county search if county not specified.
        search_county = county.strip() if county else None
        if not search_county and location:
            search_county = location.strip()

        raw = _get_client().get_flood_warnings(
            county=search_county,
            latitude=latitude,
            longitude=longitude,
            radius_km=radius_km,
            min_severity=min_severity,
        )
        data = clean_flood_warnings(raw)
        record_call(_get_metrics(), "flood_warnings", start, success=True)
        return format_response(_CONFIG, data, endpoint="/flood-monitoring/id/floods")
    except EnvironmentAgencyError as e:
        record_call(_get_metrics(), "flood_warnings", start, success=False, error=e)
        return format_error(_CONFIG, e, error_type_fn=_error_type)


@server.tool()
async def uk_environment_agency_flood_areas(
    search: str | None = None,
) -> str:
    """Get flood risk areas for property due diligence and risk assessment.

    Search by area name or location. Returns flood area definitions with
    risk levels.
    """
    start = time.monotonic()
    try:
        if search is not None and not search.strip():
            return format_error(
                _CONFIG,
                BadRequestError("search must be non-empty if provided."),
                error_type_fn=_error_type,
            )

        raw = _get_client().get_flood_areas(
            search=search.strip() if search else None,
        )
        data = clean_flood_areas(raw)
        record_call(_get_metrics(), "flood_areas", start, success=True)
        return format_response(_CONFIG, data, endpoint="/flood-monitoring/id/floodAreas")
    except EnvironmentAgencyError as e:
        record_call(_get_metrics(), "flood_areas", start, success=False, error=e)
        return format_error(_CONFIG, e, error_type_fn=_error_type)


@server.tool()
async def uk_environment_agency_flood_stations(
    latitude: float | None = None,
    longitude: float | None = None,
    radius_km: float = 5,
    parameter: str | None = None,
    active_only: bool = True,
) -> str:
    """Search flood monitoring stations near a location.

    Filter by measurement type: waterLevel, rainfall, tideLevel.
    Returns station details with links to readings.
    """
    start = time.monotonic()
    try:
        validate_coordinates(latitude, longitude)

        valid_params = {"waterlevel", "rainfall", "tidelevel"}
        if parameter and parameter.strip().lower() not in valid_params:
            return format_error(
                _CONFIG,
                BadRequestError(
                    f"parameter must be one of: waterLevel, rainfall, tideLevel. "
                    f"Got '{parameter}'."
                ),
                error_type_fn=_error_type,
            )

        raw = _get_client().get_flood_stations(
            latitude=latitude,
            longitude=longitude,
            radius_km=radius_km,
            parameter=parameter.strip() if parameter else None,
            active_only=active_only,
        )
        data = clean_flood_stations(raw)
        record_call(_get_metrics(), "flood_stations", start, success=True)
        return format_response(_CONFIG, data, endpoint="/flood-monitoring/id/stations")
    except EnvironmentAgencyError as e:
        record_call(_get_metrics(), "flood_stations", start, success=False, error=e)
        return format_error(_CONFIG, e, error_type_fn=_error_type)


@server.tool()
async def uk_environment_agency_station_readings(
    station_id: str = "",
    limit: int = 100,
    since: str | None = None,
) -> str:
    """Get recent readings (water level, rainfall, tidal) for a monitoring station.

    station_id: Station ID from the flood_stations tool.
    limit: Max readings to return (max 1000).
    since: ISO 8601 datetime — only return readings after this time.
    """
    start = time.monotonic()
    try:
        if not station_id or not station_id.strip():
            return format_error(
                _CONFIG,
                BadRequestError("station_id is required."),
                error_type_fn=_error_type,
            )

        raw = _get_client().get_station_readings(
            station_id.strip(),
            limit=limit,
            since=since,
        )
        data = clean_station_readings(raw)
        record_call(_get_metrics(), "station_readings", start, success=True)
        return format_response(
            _CONFIG, data,
            endpoint=f"/flood-monitoring/id/stations/{station_id.strip()}/readings",
        )
    except EnvironmentAgencyError as e:
        record_call(_get_metrics(), "station_readings", start, success=False, error=e)
        return format_error(_CONFIG, e, error_type_fn=_error_type)


# ---------------------------------------------------------------------------
# Tools — Water quality
# ---------------------------------------------------------------------------


@server.tool()
async def uk_environment_agency_water_quality_sites(
    latitude: float | None = None,
    longitude: float | None = None,
    radius_km: float = 5,
    area: str | None = None,
) -> str:
    """Search water quality sampling points near a location.

    Filter by EA area name (e.g. Thames, Severn).
    Returns sampling point details with links to measurements.
    """
    start = time.monotonic()
    try:
        validate_coordinates(latitude, longitude)

        raw = _get_client().get_water_quality_sites(
            latitude=latitude,
            longitude=longitude,
            radius_km=radius_km,
            area=area.strip() if area else None,
        )
        data = clean_water_quality_sites(raw)
        record_call(_get_metrics(), "water_quality_sites", start, success=True)
        return format_response(_CONFIG, data, endpoint="/water-quality/sampling-point")
    except EnvironmentAgencyError as e:
        record_call(_get_metrics(), "water_quality_sites", start, success=False, error=e)
        return format_error(_CONFIG, e, error_type_fn=_error_type)


@server.tool()
async def uk_environment_agency_water_quality_results(
    sampling_point_id: str = "",
    determinand: str | None = None,
    year: int | None = None,
) -> str:
    """Get water quality measurements (pH, dissolved oxygen, nitrates, etc.).

    sampling_point_id: ID from the water_quality_sites tool.
    determinand: Specific measurement type (e.g. pH, Dissolved Oxygen, Nitrate).
    year: Filter to a specific year (YYYY).
    """
    start = time.monotonic()
    try:
        if not sampling_point_id or not sampling_point_id.strip():
            return format_error(
                _CONFIG,
                BadRequestError("sampling_point_id is required."),
                error_type_fn=_error_type,
            )

        raw = _get_client().get_water_quality_results(
            sampling_point_id.strip(),
            determinand=determinand.strip().title() if determinand else None,
            year=year,
        )
        data = clean_water_quality_results(raw)
        record_call(_get_metrics(), "water_quality_results", start, success=True)
        return format_response(
            _CONFIG, data,
            endpoint=f"/water-quality/sampling-point/{sampling_point_id.strip()}/observation",
        )
    except EnvironmentAgencyError as e:
        record_call(_get_metrics(), "water_quality_results", start, success=False, error=e)
        return format_error(_CONFIG, e, error_type_fn=_error_type)


# ---------------------------------------------------------------------------
# Tools — Bathing water
# ---------------------------------------------------------------------------


@server.tool()
async def uk_environment_agency_bathing_water(
    search: str | None = None,
    year: int | None = None,
) -> str:
    """Get bathing water quality classifications for UK beaches and swimming areas.

    Classifications: Excellent, Good, Sufficient, Poor.
    Returns classification data with sample counts.
    """
    start = time.monotonic()
    try:
        if search is not None and not search.strip():
            return format_error(
                _CONFIG,
                BadRequestError("search must be non-empty if provided."),
                error_type_fn=_error_type,
            )

        raw = _get_client().get_bathing_water(
            search=search.strip() if search else None,
            year=year,
        )
        data = clean_bathing_water(raw)
        record_call(_get_metrics(), "bathing_water", start, success=True)
        return format_response(_CONFIG, data, endpoint="/doc/bathing-water")
    except EnvironmentAgencyError as e:
        record_call(_get_metrics(), "bathing_water", start, success=False, error=e)
        return format_error(_CONFIG, e, error_type_fn=_error_type)


# ---------------------------------------------------------------------------
# Tools — Permits
# ---------------------------------------------------------------------------


@server.tool()
async def uk_environment_agency_permits_search(
    company_name: str | None = None,
    postcode: str | None = None,
    permit_type: str | None = None,
) -> str:
    """Search environmental permits by company or location.

    Includes waste, installations, water discharge, and abstraction permits.
    permit_type: waste, installations, water-discharge, abstraction.
    Note: Permit data is under EA Conditional Licence.
    """
    start = time.monotonic()
    try:
        if not company_name and not postcode and not permit_type:
            return format_error(
                _PERMITS_CONFIG,
                BadRequestError(
                    "At least one of company_name, postcode, or permit_type is required."
                ),
                error_type_fn=_error_type,
            )

        valid_types = {"waste", "installations", "water-discharge", "abstraction"}
        if permit_type and permit_type.strip().lower() not in valid_types:
            return format_error(
                _PERMITS_CONFIG,
                BadRequestError(
                    f"permit_type must be one of: {', '.join(sorted(valid_types))}. "
                    f"Got '{permit_type}'."
                ),
                error_type_fn=_error_type,
            )

        from bartram_foundry.cleaning import normalise_postcode

        raw = _get_client().search_permits(
            company_name=company_name.strip().title() if company_name else None,
            postcode=normalise_postcode(postcode) if postcode else None,
            permit_type=permit_type.strip().lower() if permit_type else None,
        )
        data = clean_permits_search(raw)
        record_call(_get_metrics(), "permits_search", start, success=True)
        return format_response(_PERMITS_CONFIG, data, endpoint="/public-register/api/search")
    except EnvironmentAgencyError as e:
        record_call(_get_metrics(), "permits_search", start, success=False, error=e)
        return format_error(_PERMITS_CONFIG, e, error_type_fn=_error_type)


@server.tool()
async def uk_environment_agency_permit_detail(
    permit_number: str = "",
) -> str:
    """Get full details of a specific environmental permit.

    Includes conditions and compliance history.
    permit_number: Permit reference number.
    Note: Permit data is under EA Conditional Licence.
    """
    start = time.monotonic()
    try:
        if not permit_number or not permit_number.strip():
            return format_error(
                _PERMITS_CONFIG,
                BadRequestError("permit_number is required."),
                error_type_fn=_error_type,
            )

        raw = _get_client().get_permit_detail(permit_number.strip().upper())
        data = clean_permit_detail(raw)
        record_call(_get_metrics(), "permit_detail", start, success=True)
        return format_response(
            _PERMITS_CONFIG, data,
            endpoint=f"/public-register/registration/{permit_number.strip().upper()}",
        )
    except EnvironmentAgencyError as e:
        record_call(_get_metrics(), "permit_detail", start, success=False, error=e)
        return format_error(_PERMITS_CONFIG, e, error_type_fn=_error_type)


# ---------------------------------------------------------------------------
# Tools — Catchment
# ---------------------------------------------------------------------------


@server.tool()
async def uk_environment_agency_catchment(
    search: str | None = None,
    latitude: float | None = None,
    longitude: float | None = None,
) -> str:
    """Get Water Framework Directive catchment and waterbody data.

    Search by name or coordinates. Returns WFD classifications,
    ecological and chemical status, and management plan links.
    """
    start = time.monotonic()
    try:
        validate_coordinates(latitude, longitude)

        raw = _get_client().get_catchment(
            search=search.strip() if search else None,
            latitude=latitude,
            longitude=longitude,
        )
        data = clean_catchment(raw)
        record_call(_get_metrics(), "catchment", start, success=True)
        return format_response(_CONFIG, data, endpoint="/catchment-planning/")
    except EnvironmentAgencyError as e:
        record_call(_get_metrics(), "catchment", start, success=False, error=e)
        return format_error(_CONFIG, e, error_type_fn=_error_type)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    """Run the Environment Agency MCP server."""
    server.run()
