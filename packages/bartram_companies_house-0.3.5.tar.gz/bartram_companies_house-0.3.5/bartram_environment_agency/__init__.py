"""Environment Agency Open Data MCP tool — flood, water quality, permits, and catchment data."""

__version__ = "0.3.4"
