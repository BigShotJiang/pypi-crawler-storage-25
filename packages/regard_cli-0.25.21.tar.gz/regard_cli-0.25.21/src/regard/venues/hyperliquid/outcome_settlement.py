"""HIP-4 outcome settlement + near-expiry detection — pure logic.

Detects when held outcome positions transition from "active" to "settled"
across consecutive REST polls. Emits structured events suitable for
JSONL stdout consumption by Claude Code's Monitor tool.

Architecture:
- Pure logic. `SettlementWatcher.poll(...)` takes resolver state +
  `client.get_spot_balances()` + `get_all_mids()` and returns the list of
  events to emit. No network, no I/O — `commands/watch.py` drives the loop.
- State carried in memory across polls. Restart loses state — fresh
  watcher rediscovers held positions on first tick (no spurious settled
  events because tracking starts empty).

Detection paths (priority order, never double-emit):

  Path A — `settledNamedOutcomes` transition (HIP-4 multi-outcome questions).
    A question record carries `settled_named_outcomes: list[int]`. When that
    transitions from `[]` to `[winner_id]`, the question has settled and
    every named outcome's outcome is determined: winner → `yes` resolves,
    others → `no` resolves. Fires deterministic `implied_winning_side`
    without any USDH-delta inference. Authoritative source for question
    settlements; subsequent meta-removal is just cleanup.

  Path B — outcome removal from outcomeMeta (binary HIP-4, fallback for
    question-bound that escaped Path A). Validators auto-credit USDH at
    expiry and remove the outcome from the meta. Payout is computed from
    USDH delta between the poll that observed the position and the poll
    that observed the settlement. Paths where USDH delta is unobservable
    (first poll, simultaneous settlements) surface as
    `payout_usdh="unknown"` / `implied_winning_side="unknown"`.

A position that disappears from balance while the outcome stays in meta
is a sale (Cycle D pattern), NOT a settlement — does not emit.

Prediction (separate event class — `outcome_settlement_predicted`):

  Within `prediction_window_minutes` of expiry, the watcher reads the
  current mark price for the underlying and emits the predicted winner.
  For `priceBucket` questions: argmax-style — mark price falls into one
  bucket → that named outcome wins. For `priceBinary`: threshold-cross —
  mark ≥ target → Yes resolves, else No. Per CLAUDE.md fintech-accuracy
  doctrine, the event includes a `mark_price_basis` string disclosing the
  data source so the agent never confuses a prediction with a guaranteed
  outcome. The prediction is only emitted on entering the window AND on
  flips — quiet otherwise.

All numeric values in events are JSON strings (Article I).
"""

from datetime import datetime
from decimal import Decimal
from typing import Any


class SettlementWatcher:
    """Tracks held HIP-4 outcomes and detects settlements across polls.

    Usage:
        watcher = SettlementWatcher()
        events = watcher.poll(
            outcomes_meta=...,
            spot_balances=...,
            now_iso=...,
            questions_meta=...,            # optional, enables Path A
            mids=...,                       # optional, enables prediction
            now_utc=...,                    # optional, enables prediction
            prediction_window_minutes=60,
        )
        for ev in events: emit(ev)
    """

    def __init__(self):
        # outcome_id → tracked dict {side, side_name, size, name, expiry,
        #   target_price, question_id, bucket_label, is_fallback,
        #   underlying, price_thresholds (inherited from parent question)}
        self._tracked: dict[int, dict[str, Any]] = {}
        # question_id → last-seen settled_named_outcomes (list[int]). Empty
        # list before settlement; populated after. Tracked only for questions
        # whose at least one named outcome the user holds at any point in the
        # session — minimizes memory pressure.
        self._tracked_question_settled: dict[int, list[int]] = {}
        # Previous-poll USDH balance (Decimal). None on first poll.
        self._prev_usdh: Decimal | None = None
        # Last prediction per (kind, id) tuple — `("question", question_id)`
        # or `("binary", outcome_id)` — value: predicted_winner outcome id
        # (for question) or predicted side ("yes" | "no") for binary.
        # Used to suppress unchanged predictions across consecutive polls.
        self._last_prediction: dict[tuple[str, int], str | int] = {}

    def poll(
        self,
        outcomes_meta: list[dict[str, Any]],
        spot_balances: list[dict[str, Any]],
        now_iso: str,
        *,
        questions_meta: list[dict[str, Any]] | None = None,
        mids: dict[str, Any] | None = None,
        now_utc: datetime | None = None,
        prediction_window_minutes: int = 60,
    ) -> list[dict[str, Any]]:
        """Process one poll cycle. Return any settlement / prediction events.

        Args:
            outcomes_meta: result of resolver.get_outcomes() — list of dicts
                with keys outcome (int), name, parsed_description {expiry,
                target_price, ...}, sides, plus question linkage fields
                (`question_id`, `bucket_label`, `is_fallback`) when bound
                to a question.
            spot_balances: result of client.get_spot_balances() — list of
                dicts. Outcome rows have kind="outcome", outcome (int), side
                (int), side_name (str), balance (str). USDH row has
                token="USDH", balance (str).
            now_iso: current UTC time as ISO 8601 string. Caller passes in
                so the function stays pure.
            questions_meta: result of resolver.get_questions() — enables the
                authoritative `settledNamedOutcomes` detection path. Pass
                `None` (default) to fall back to outcome-removal detection
                only (binary-HIP-4 era / pre-question state).
            mids: dict of `{coin_or_underlying → mid_price_str}` from
                `client.get_all_mids()`. Required for prediction events.
            now_utc: current UTC datetime, mirrors `now_iso`. Required for
                prediction window calculation.
            prediction_window_minutes: emit predictions for outcomes /
                questions expiring within this many minutes. Default 60.
                <=0 disables predictions.
        """
        events: list[dict[str, Any]] = []

        current_outcome_ids = {o["outcome"] for o in outcomes_meta}
        outcomes_by_id = {o["outcome"]: o for o in outcomes_meta}
        questions_by_id: dict[int, dict[str, Any]] = {}
        if questions_meta:
            questions_by_id = {q["question"]: q for q in questions_meta}

        held: dict[int, dict[str, Any]] = {}
        usdh_balance: Decimal | None = None
        for b in spot_balances:
            if b.get("kind") == "outcome":
                oid = b.get("outcome")
                if not isinstance(oid, int):
                    continue
                size_str = str(b.get("balance", "0"))
                # Defensive: skip dust rows where balance is 0 or non-positive.
                try:
                    if Decimal(size_str) <= 0:
                        continue
                except Exception:
                    continue
                held[oid] = {
                    "side": b.get("side", 0),
                    "side_name": b.get("side_name", "yes" if b.get("side") == 0 else "no"),
                    "size": size_str,
                }
            elif b.get("token") == "USDH":
                try:
                    usdh_balance = Decimal(str(b.get("balance", "0")))
                except Exception:
                    pass

        # ---- Path C: period-rollover detection (peer-review v0.25.16 fix) ----
        # If a tracked outcome's expiry has changed in current outcomeMeta
        # vs what we last tracked, the validator has settled the prior period
        # and recycled the integer ID for the next period. We never observed
        # the settled_named_outcomes transition or the meta-removal because
        # both happened off-stage between polls. Emit a synthetic settlement
        # event for the prior period with payout/winner unknown, then drop
        # tracking so the held-loop below can re-track the new period cleanly.
        for oid, prior in list(self._tracked.items()):
            record = outcomes_by_id.get(oid)
            if record is None:
                continue  # absence handled by Path B below
            current_expiry = _resolve_effective_expiry(record, questions_by_id)
            prior_expiry = prior.get("expiry") or ""
            if prior_expiry and current_expiry and prior_expiry != current_expiry:
                events.append(
                    _build_settled_event(
                        outcome_id=oid,
                        tracked=prior,
                        payout_usdh="unknown",
                        implied_winning_side="unknown",
                        now_iso=now_iso,
                        settlement_source="period_rollover",
                        winning_outcome_ids=[],
                    )
                )
                del self._tracked[oid]
                self._cleanup_prediction_state(oid, prior.get("question_id"))

        # ---- Path A: settledNamedOutcomes-driven question settlement ----
        # For every tracked question, check if `settled_named_outcomes`
        # transitioned from `[]` to `[winner_id]`. If so, emit deterministic
        # `outcome_settled` for every NAMED outcome the user holds (winner =
        # `held` if they hold the winning outcome's YES, `opposite` for the
        # losing side; same logic mirrors for the other named outcomes).
        # This path drains tracking, so Path B below sees nothing for these.
        path_a_settled_outcomes: set[int] = set()
        for qid, prev_settled in list(self._tracked_question_settled.items()):
            current_q = questions_by_id.get(qid)
            if current_q is None:
                # Question vanished from meta entirely (post-cleanup stage).
                # Path B will handle any still-tracked outcomes via removal.
                continue
            current_settled = list(current_q.get("settled_named_outcomes") or [])
            if not prev_settled and current_settled:
                # Transition observed. HL convention is exactly one named
                # outcome resolves Yes; the field is a list to defend against
                # multi-resolution protocol extensions. We surface the full
                # list as `winning_outcome_ids` rather than picking [0], since
                # the boolean logic uses the full set.
                winning_set = set(current_settled)
                # Walk every tracked outcome bound to this question.
                for oid, tracked in list(self._tracked.items()):
                    if tracked.get("question_id") != qid:
                        continue
                    side_name = tracked["side_name"]
                    is_winner_outcome = oid in winning_set
                    # Held side wins if (this outcome won AND user held YES) OR
                    # (this outcome lost AND user held NO).
                    if is_winner_outcome:
                        implied = "held" if side_name == "yes" else "opposite"
                    else:
                        implied = "held" if side_name == "no" else "opposite"
                    events.append(
                        _build_settled_event(
                            outcome_id=oid,
                            tracked=tracked,
                            payout_usdh="unknown",  # per-outcome USDH delta unattributable
                            implied_winning_side=implied,
                            now_iso=now_iso,
                            settlement_source="settledNamedOutcomes",
                            winning_outcome_ids=list(current_settled),
                        )
                    )
                    path_a_settled_outcomes.add(oid)
                    del self._tracked[oid]
                    self._cleanup_prediction_state(oid, qid)
                # Stop tracking this question — already settled.
                del self._tracked_question_settled[qid]
            else:
                # Update prev to current (still empty or already-known list).
                self._tracked_question_settled[qid] = current_settled

        # ---- Path B: outcome removal from outcomeMeta ----
        # Any tracked outcome no longer in meta (and not already settled by
        # Path A this poll) is settled (validators remove outcomes after
        # auto-crediting). When >1 outcome settles in the same poll, OR Path
        # A also fired this poll, the wallet-level USDH delta is contaminated
        # and cannot be attributed to a single Path B outcome — force
        # `implied_winning_side: "unknown"` to avoid mis-tagging a loser as
        # `held` because a sibling's payout dominated the delta (peer-review
        # v0.23.3 + v0.25.16 ratchets — see TestSimultaneousSettlement and
        # TestPathAContaminatesPathB).
        to_settle = [
            oid for oid in self._tracked
            if oid not in current_outcome_ids and oid not in path_a_settled_outcomes
        ]
        multi_settle = len(to_settle) > 1 or len(path_a_settled_outcomes) > 0
        for oid in to_settle:
            tracked = self._tracked[oid]
            if multi_settle:
                if self._prev_usdh is not None and usdh_balance is not None:
                    payout = str(usdh_balance - self._prev_usdh)
                else:
                    payout = "unknown"
                implied_winning = "unknown"
            else:
                payout, implied_winning = _classify_settlement(
                    tracked["size"], self._prev_usdh, usdh_balance
                )
            events.append(
                _build_settled_event(
                    outcome_id=oid,
                    tracked=tracked,
                    payout_usdh=payout,
                    implied_winning_side=implied_winning,
                    now_iso=now_iso,
                    settlement_source="meta_removal",
                    winning_outcome_ids=[],
                )
            )
            del self._tracked[oid]
            self._cleanup_prediction_state(oid, tracked.get("question_id"))

        # ---- Update tracking from current holdings ----
        # New positions enter tracking silently (no event); positions cleared
        # while outcome is still active (sale path) leave tracking silently
        # too. We only emit on the settlement transition above. Outcomes that
        # Path A drained this poll are NOT re-tracked even if their balance
        # row is still present (validators may clear settledNamedOutcomes
        # before the balance row updates) — this prevents a double-emit on
        # the next poll's meta_removal (peer-review v0.25.16 fix).
        for oid, h in held.items():
            if oid in path_a_settled_outcomes:
                continue
            outcome_record = outcomes_by_id.get(oid)
            parsed = (outcome_record or {}).get("parsed_description") or {}
            held_qid: int | None = (outcome_record or {}).get("question_id")
            # Question-bound outcomes inherit underlying / price_thresholds /
            # expiry from the parent question; binary outcomes carry their
            # own. Inheritance is needed so prediction can read mark price
            # without a re-resolution round-trip.
            underlying = parsed.get("underlying")
            price_thresholds: list[str] = []
            expiry = parsed.get("expiry") or ""
            if held_qid is not None and questions_by_id:
                q_record = questions_by_id.get(held_qid)
                if q_record is not None:
                    q_parsed = q_record.get("parsed_description") or {}
                    underlying = underlying or q_parsed.get("underlying")
                    price_thresholds = list(q_parsed.get("price_thresholds") or [])
                    if not expiry:
                        expiry = q_parsed.get("expiry") or ""
            self._tracked[oid] = {
                "side": h["side"],
                "side_name": h["side_name"],
                "size": h["size"],
                "name": (outcome_record or {}).get("name", ""),
                "expiry": expiry,
                "target_price": parsed.get("target_price") or "",
                "question_id": held_qid,
                "bucket_label": (outcome_record or {}).get("bucket_label"),
                "is_fallback": (outcome_record or {}).get("is_fallback", False),
                "underlying": underlying,
                "price_thresholds": price_thresholds,
            }
            # If this outcome belongs to a question, track its settled state
            # so Path A can detect the transition next poll.
            if held_qid is not None and questions_by_id:
                q_record = questions_by_id.get(held_qid)
                if q_record is not None:
                    self._tracked_question_settled.setdefault(
                        held_qid, list(q_record.get("settled_named_outcomes") or [])
                    )

        # Drop tracking for outcomes that are still active in meta but no
        # longer in our balance (sale path).
        for oid in list(self._tracked.keys()):
            if oid not in held and oid in current_outcome_ids:
                # Don't drop tracking for the parent question — the user may
                # still hold a SIBLING outcome. Question-tracker pruning
                # happens when no remaining tracked outcome is bound to it.
                tracked_for_cleanup = self._tracked[oid]
                del self._tracked[oid]
                self._cleanup_prediction_state(oid, tracked_for_cleanup.get("question_id"))
        # Garbage-collect question trackers that no longer have any held
        # outcome bound to them.
        question_ids_with_held = {
            t.get("question_id") for t in self._tracked.values()
            if t.get("question_id") is not None
        }
        for qid in list(self._tracked_question_settled.keys()):
            if qid not in question_ids_with_held:
                del self._tracked_question_settled[qid]

        if usdh_balance is not None:
            self._prev_usdh = usdh_balance

        # ---- Prediction events ----
        if (
            mids is not None
            and now_utc is not None
            and prediction_window_minutes > 0
        ):
            events.extend(
                self._emit_predictions(
                    outcomes_by_id=outcomes_by_id,
                    questions_by_id=questions_by_id,
                    mids=mids,
                    now_utc=now_utc,
                    now_iso=now_iso,
                    window_minutes=prediction_window_minutes,
                )
            )

        return events

    def _emit_predictions(
        self,
        *,
        outcomes_by_id: dict[int, dict[str, Any]],
        questions_by_id: dict[int, dict[str, Any]],
        mids: dict[str, Any],
        now_utc: datetime,
        now_iso: str,
        window_minutes: int,
    ) -> list[dict[str, Any]]:
        """Emit settlement-prediction events for held positions near expiry.

        Quiet on stable predictions — only fires on entry into the window
        and on prediction flips. Prediction is computed from the current
        underlying mark price (`mids[underlying]`); the basis string is
        included on every event so the consumer can audit the source.
        """
        from regard.venues.hyperliquid.outcomes import parse_expiry

        events: list[dict[str, Any]] = []

        # 1. Predictions for question-bound holdings — keyed per question
        #    so we don't emit N events for N held buckets of one question.
        question_ids_seen: set[int] = set()
        for oid, tracked in self._tracked.items():
            qid = tracked.get("question_id")
            if qid is None or qid in question_ids_seen:
                continue
            question_ids_seen.add(qid)
            q_record = questions_by_id.get(qid)
            if q_record is None:
                continue
            q_parsed = q_record.get("parsed_description") or {}
            expiry_dt = parse_expiry(q_parsed.get("expiry"))
            if expiry_dt is None or expiry_dt <= now_utc:
                continue
            seconds_to_expiry = int((expiry_dt - now_utc).total_seconds())
            if seconds_to_expiry > window_minutes * 60:
                continue
            underlying = q_parsed.get("underlying")
            mark_price = _mark_price_for(underlying, mids)
            if mark_price is None:
                continue
            thresholds = list(q_parsed.get("price_thresholds") or [])
            bucket_idx = _which_bucket(mark_price, thresholds)
            if bucket_idx is None:
                continue
            named = list(q_record.get("named_outcomes") or [])
            if bucket_idx >= len(named):
                continue
            predicted_winner = named[bucket_idx]
            winner_record = outcomes_by_id.get(predicted_winner)
            predicted_label = (winner_record or {}).get("bucket_label")
            key = ("question", qid)
            if self._last_prediction.get(key) == predicted_winner:
                continue
            self._last_prediction[key] = predicted_winner
            events.append({
                "event": "outcome_settlement_predicted",
                "watcher": "outcomes",
                "kind": "question",
                "question_id": qid,
                "question_name": q_record.get("name", ""),
                "underlying": underlying or "",
                "predicted_winner": predicted_winner,
                "predicted_bucket_label": predicted_label,
                "mark_price": str(mark_price),
                "mark_price_basis": f"{underlying} mid via allMids endpoint at {now_iso}",
                "settlement_in_seconds": seconds_to_expiry,
                "expiry": q_parsed.get("expiry") or "",
                "predicted_at": now_iso,
            })

        # 2. Predictions for standalone binary held outcomes.
        for oid, tracked in self._tracked.items():
            if tracked.get("question_id") is not None:
                continue
            expiry_dt = parse_expiry(tracked.get("expiry"))
            if expiry_dt is None or expiry_dt <= now_utc:
                continue
            seconds_to_expiry = int((expiry_dt - now_utc).total_seconds())
            if seconds_to_expiry > window_minutes * 60:
                continue
            underlying = tracked.get("underlying")
            target_price_str = tracked.get("target_price") or ""
            mark_price = _mark_price_for(underlying, mids)
            if mark_price is None or not target_price_str:
                continue
            try:
                target_price = Decimal(str(target_price_str))
            except Exception:
                continue
            predicted_side = "yes" if mark_price >= target_price else "no"
            key = ("binary", oid)
            if self._last_prediction.get(key) == predicted_side:
                continue
            self._last_prediction[key] = predicted_side
            events.append({
                "event": "outcome_settlement_predicted",
                "watcher": "outcomes",
                "kind": "binary",
                "outcome": oid,
                "name": tracked.get("name", ""),
                "underlying": underlying or "",
                "predicted_side": predicted_side,
                "mark_price": str(mark_price),
                "target_price": target_price_str,
                "mark_price_basis": f"{underlying} mid via allMids endpoint at {now_iso}",
                "settlement_in_seconds": seconds_to_expiry,
                "expiry": tracked.get("expiry") or "",
                "predicted_at": now_iso,
            })

        return events

    def _cleanup_prediction_state(self, outcome_id: int, question_id: int | None) -> None:
        """Drop stale `_last_prediction` entries when an outcome leaves tracking.

        HL recurring markets re-use outcome (and possibly question) IDs across
        periods. Without cleanup, the prior period's `_last_prediction` entry
        suppresses the entry-into-window event of the new period if the
        prediction happens to match (peer-review v0.25.16 fix). For
        question-bound outcomes, the question-keyed entry is dropped only
        when the LAST sibling outcome bound to that question has left
        tracking — a single outcome leaving while siblings remain shouldn't
        forget the question's last prediction.
        """
        self._last_prediction.pop(("binary", outcome_id), None)
        if question_id is not None:
            still_bound = any(
                t.get("question_id") == question_id
                for t in self._tracked.values()
            )
            if not still_bound:
                self._last_prediction.pop(("question", question_id), None)


def _build_settled_event(
    *,
    outcome_id: int,
    tracked: dict[str, Any],
    payout_usdh: str,
    implied_winning_side: str,
    now_iso: str,
    settlement_source: str,
    winning_outcome_ids: list[int],
) -> dict[str, Any]:
    """Assemble an outcome_settled event with question-aware enrichment.

    Question-bound outcomes carry `question_id`, `bucket_label`, `is_fallback`,
    and `winning_outcome_ids` (the full list of named outcomes the question
    resolved to — empty list for standalones, single-element list for
    typical HL questions). Standalone binary outcomes get `question_id: None`
    and the question fields stay null. `settlement_source` distinguishes the
    detection path so consumers can audit which signal fired:
      - `settledNamedOutcomes` — Path A, deterministic question settlement
      - `meta_removal` — Path B, USDH-delta-inferred (binary or late-stage)
      - `period_rollover` — Path C, recycled outcome ID, off-stage settlement
    """
    return {
        "event": "outcome_settled",
        "watcher": "outcomes",
        "outcome": outcome_id,
        "name": tracked.get("name", ""),
        "side_held": tracked["side_name"],
        "size": tracked["size"],
        "payout_usdh": payout_usdh,
        "implied_winning_side": implied_winning_side,
        "settled_at": now_iso,
        "expiry": tracked.get("expiry", ""),
        "target_price": tracked.get("target_price", ""),
        "question_id": tracked.get("question_id"),
        "bucket_label": tracked.get("bucket_label"),
        "is_fallback": tracked.get("is_fallback", False),
        "winning_outcome_ids": list(winning_outcome_ids),
        "settlement_source": settlement_source,
    }


def _resolve_effective_expiry(
    outcome_record: dict[str, Any],
    questions_by_id: dict[int, dict[str, Any]],
) -> str:
    """Return the effective expiry for an outcome record.

    Standalone binary outcomes carry `expiry` directly on `parsed_description`.
    Question-bound outcomes (description=`index:N` or `other`) inherit it
    from the parent question's `parsed_description`. Returns empty string
    when the parent question is missing or the field is unset.
    """
    parsed = outcome_record.get("parsed_description") or {}
    expiry = parsed.get("expiry") or ""
    if expiry:
        return str(expiry)
    qid = outcome_record.get("question_id")
    if qid is None or not questions_by_id:
        return ""
    q_record = questions_by_id.get(qid)
    if q_record is None:
        return ""
    q_parsed = q_record.get("parsed_description") or {}
    return str(q_parsed.get("expiry") or "")


def _classify_settlement(
    size_held: str,
    prev_usdh: Decimal | None,
    curr_usdh: Decimal | None,
) -> tuple[str, str]:
    """Infer payout amount + winning side from USDH delta.

    Returns (payout_usdh_str, implied_winning_side).

    HIP-4 binary settlement pays full size in USDH to the winning side
    (1.0 USDH per contract) and 0 to the losing side. So:
      delta ≈ size  →  held side won
      delta ≈ 0     →  held side lost

    On first poll (prev_usdh=None) or missing USDH balance, payout is
    "unknown" — we can't tell from a single observation.
    """
    if prev_usdh is None or curr_usdh is None:
        return ("unknown", "unknown")

    delta = curr_usdh - prev_usdh
    if delta < 0:
        # USDH went down? Strange — possibly an unrelated send happened
        # during the same window. Don't infer winner.
        return (str(delta), "unknown")

    try:
        size = Decimal(size_held)
    except Exception:
        return (str(delta), "unknown")

    if size <= 0:
        return (str(delta), "unknown")

    # Held side won if payout reached >= 50% of full size (covers fee
    # haircuts, partial precision drift, multi-position aggregation).
    if delta >= size * Decimal("0.5"):
        return (str(delta), "held")
    return (str(delta), "opposite")


def _mark_price_for(underlying: str | None, mids: dict[str, Any]) -> Decimal | None:
    """Resolve a Decimal mark price for `underlying` from a mids dict.

    Returns None if missing or unparseable. Defensive against future protocol
    changes — never raises on garbage input.
    """
    if not underlying:
        return None
    raw = mids.get(underlying)
    if raw is None:
        return None
    try:
        return Decimal(str(raw))
    except Exception:
        return None


def _which_bucket(mark_price: Decimal, thresholds: list[str]) -> int | None:
    """Return the bucket index that `mark_price` falls into, given threshold list.

    For `priceThresholds: [P1, P2]` (3 buckets):
        mark_price < P1            → 0  (`<P1`)
        P1 <= mark_price < P2      → 1  (`[P1, P2)`)
        mark_price >= P2           → 2  (`≥P2`)

    Generalizes to N thresholds → N+1 buckets. Returns None for empty
    thresholds or unparseable values.
    """
    if not thresholds:
        return None
    parsed: list[Decimal] = []
    for t in thresholds:
        try:
            parsed.append(Decimal(str(t)))
        except Exception:
            return None
    for idx, threshold in enumerate(parsed):
        if mark_price < threshold:
            return idx
    return len(parsed)


def count_held_outcomes_near_expiry(
    spot_balances: list[dict[str, Any]],
    outcomes_meta: list[dict[str, Any]],
    threshold_minutes: int,
    now_utc,
    questions_meta: list[dict[str, Any]] | None = None,
) -> int:
    """Count held outcome positions expiring within `threshold_minutes`.

    Used by tilt's `outcome_near_expiry` indicator. Pure function — caller
    fetches state and passes the current UTC datetime.

    Constrained-risk handling for question-bound outcomes: when a user holds
    multiple buckets of one HIP-4 question, exactly one will pay out — so
    the user's actual risk is one question's worth of exposure, not N
    independent positions. Counting unique question_ids (instead of each
    held outcome separately) prevents tilt false-positives on multi-bucket
    hedges. Standalone binaries continue to count individually.

    Phase 5 fully-hedged exclusion (v0.25.19): a question position is
    "fully hedged" when the user holds ≥1 Yes of EVERY bound outcome (named
    + fallback). Such stacks have a deterministic exit path via
    `question-merge` (X Yes-of-every-bound-outcome → X USDH); they're not
    tilt risk regardless of orderbook depth or expiry proximity. Fully-
    hedged questions are skipped from the count. Partial hedges (Yes of
    some but not all bound outcomes) and concentrated bets still count.

    A held position contributes when:
      - balance row has `kind:outcome` and `balance > 0`
      - the corresponding outcome record is in outcomes_meta
      - the outcome's expiry (parent question's, for question-bound) is in
        the future AND <= threshold_minutes away from `now_utc`

    Question-bound outcomes (description=`index:N` or `other`) carry no
    expiry on the outcome itself — pass `questions_meta` so the parent
    question's spec can be looked up. Without `questions_meta`, question-bound
    outcomes are silently skipped (defensive — old callers still work).

    Outcomes that have already expired (expiry < now) do NOT count — those
    are pending settlement and the trader can't act on them. Threshold ≤ 0
    returns 0 (no detection window).
    """
    from regard.venues.hyperliquid.outcomes import parse_expiry

    if threshold_minutes <= 0:
        return 0

    outcomes_by_id: dict[int, dict[str, Any]] = {}
    for o in outcomes_meta:
        oid = o.get("outcome")
        if isinstance(oid, int):
            outcomes_by_id[oid] = o
    questions_by_id: dict[int, dict[str, Any]] = {}
    if questions_meta:
        for q in questions_meta:
            qid_raw = q.get("question")
            if isinstance(qid_raw, int):
                questions_by_id[qid_raw] = q

    # Phase 5: build a Yes-balance map first so we can check full-hedge status
    # for each question across the entire wallet (not just near-expiry rows).
    # Side 0 = Yes by HL convention.
    yes_balances: dict[int, Decimal] = {}
    for b in spot_balances:
        if b.get("kind") != "outcome":
            continue
        if b.get("side") != 0:
            continue
        oid = b.get("outcome")
        if not isinstance(oid, int):
            continue
        try:
            bal = Decimal(str(b.get("balance", "0")))
        except Exception:
            continue
        if bal > 0:
            yes_balances[oid] = bal

    standalone_count = 0
    near_question_ids: set[int] = set()
    for b in spot_balances:
        if b.get("kind") != "outcome":
            continue
        try:
            balance = Decimal(str(b.get("balance", "0")))
        except Exception:
            continue
        if balance <= 0:
            continue
        oid = b.get("outcome")
        if not isinstance(oid, int):
            continue
        record = outcomes_by_id.get(oid)
        if record is None:
            continue
        parsed = record.get("parsed_description") or {}
        qid = record.get("question_id")
        # Resolve the effective expiry: question-bound outcomes inherit from
        # the parent question's spec; standalone binaries carry it directly.
        expiry_str: str | None = parsed.get("expiry")
        if (not expiry_str) and qid is not None:
            q_record = questions_by_id.get(qid)
            if q_record is not None:
                expiry_str = (q_record.get("parsed_description") or {}).get("expiry")
        expiry_dt = parse_expiry(expiry_str)
        if expiry_dt is None:
            continue
        if expiry_dt <= now_utc:
            continue
        minutes_left = (expiry_dt - now_utc).total_seconds() / 60.0
        if minutes_left > threshold_minutes:
            continue
        if qid is None:
            standalone_count += 1
        else:
            near_question_ids.add(qid)

    # Phase 5: filter out fully-hedged questions from the tilt count.
    # Requires `questions_meta` to determine the bound-outcome set; without
    # it we can't compute hedge status, so all near-expiry questions count
    # (backward-compat behavior).
    counted_question_ids: set[int] = set()
    for qid in near_question_ids:
        q_record = questions_by_id.get(qid)
        if q_record is None:
            counted_question_ids.add(qid)
            continue
        # Prefer the resolver's full `outcomes` list (named + fallback);
        # fall back to assembling from `named_outcomes` + `fallback_outcome`
        # for callers passing leaner question records.
        bound_oids: list[int] = []
        outcomes_field = q_record.get("outcomes")
        if isinstance(outcomes_field, list) and outcomes_field:
            for o in outcomes_field:
                if isinstance(o, dict):
                    boid = o.get("outcome")
                    if isinstance(boid, int):
                        bound_oids.append(boid)
        if not bound_oids:
            for boid in q_record.get("named_outcomes") or []:
                if isinstance(boid, int):
                    bound_oids.append(boid)
        # Always cross-check `fallback_outcome` against the assembled set —
        # the resolver drops `fallback_rec` from `outcomes` when the
        # underlying record is missing (resolver.py:237), so the
        # `outcomes` list can omit fallback even when the question has
        # one. Append the integer fallback_outcome if not already present
        # (peer-review v0.25.20 ratchet — PARTIAL-OUTCOMES-LIST).
        fb = q_record.get("fallback_outcome")
        if isinstance(fb, int) and fb not in bound_oids:
            bound_oids.append(fb)
        if not bound_oids:
            counted_question_ids.add(qid)
            continue
        # "Fully hedged" requires Yes balances that are (a) >= 1 for every
        # bound outcome AND (b) EQUAL across all bound outcomes. The merge
        # primitive consumes `min(yes_balances)` per call (act.py:1170);
        # if Yes balances are imbalanced (e.g. 5/1/1/1), one max merge
        # zeros the smaller positions but leaves the larger as residual
        # tilt-exposure with no further merge partners. The stack is only
        # cleanly exitable to zero when every Yes is the same integer
        # ≥1 (peer-review v0.25.20 ratchet — RESIDUAL-YES-EXPOSURE).
        yes_values = [
            yes_balances.get(boid, Decimal("0"))
            for boid in bound_oids
        ]
        min_yes = min(yes_values)
        max_yes = max(yes_values)
        is_fully_hedged = min_yes >= 1 and min_yes == max_yes
        if not is_fully_hedged:
            counted_question_ids.add(qid)

    return standalone_count + len(counted_question_ids)
