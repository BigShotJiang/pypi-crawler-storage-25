"""Streaming renderer using rich.Live.

One Live context per assistant turn. Live exits BEFORE any user prompts
(permission gate) — never prompt while Live is active or you'll get
display corruption. Tool result panels print outside Live (post-dispatch
via ``tool_done`` → ``_render_tool_card``).

Commit-as-you-go reasoning: the thinking Panel commits to permanent
scrollback the moment reasoning is "done" — first text event, first
tool_call_start, or stream end (via ``render_final``). The commit uses
Rich's documented ``live.console.print(panel)`` pattern: Rich clears the
live frame, prints the renderable to scrollback above, then redraws the
live frame below. Idempotent via ``TurnState.reasoning_committed``.
After commit, the reasoning is no longer rendered inside the live
region — the live frame contains only the in-flight body Markdown and
tool-call status lines. ``render_final`` returns body-only for the
post-Live commit; tool-call lines are intentionally dropped because
each call's result Panel from ``_render_tool_card`` is the single
permanent artifact for that call.

The renderer is structured around a TurnState dataclass that owns
turn-scoped UI state (reasoning, text, per-call lifecycle). _LiveBuffer
mutates it on streaming events; agent.py drives status transitions
post-stream via tool_status / tool_done.

Headless mode (P2.1): subagents construct `Renderer(headless=True)` so
their iteration loop runs without opening a `rich.Live` region (no
concurrent Live regions vs the parent's renderer) and without printing
tool cards / info / error lines to the parent's console. Captured
strings are buffered on `headless_buffer` for the parent's
`subagent_card` Panel and for power-user `FRED_SHOW_SUBAGENTS=1`
forwarding. Existing renderer behavior is identical when
`headless=False` (the default).

Status line (P3.3): ``Renderer.status_line(...)`` formats a one-line
summary of model / mode / tokens / cost / cache / repo / todos and
``print_status_line(...)`` prints it after each turn finishes. The
line is mutually exclusive with the assistant ``rich.Live`` region —
print AFTER each ``run_turn`` returns, never inside an active Live
context. Honors ``FRED_REDUCED_MOTION=1`` to swap ``console.rule()``
for a plain dim print.
"""
from __future__ import annotations

import os
import time
from collections import deque
from contextlib import contextmanager
from typing import Any, Iterator

from rich.console import Console, Group, RenderableType
from rich.live import Live
from rich.markdown import Markdown
from rich.panel import Panel
from rich.text import Text

from fred.client import ToolCall
from fred.result_format import format_result
from fred.turn_state import CallState, CallStatus, TurnState

_SPIN_FRAMES = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"

# Cost preview rates are pulled from rates.get_active_card() so the CLI
# stays in lockstep with FredWeb's pricing.ts via /api/pricing. The
# bundled fallback in fred/bundled_rates.py covers offline/first-run.
# Numbers used here are *upstream* (what we pay DeepSeek) — that's
# what the existing display has shown historically.


def _glyph_for(s: CallStatus, spin: str) -> tuple[str, str]:
    return {
        CallStatus.QUEUED: ("◯", "grey50"),
        CallStatus.PERMISSION: ("?", "yellow"),
        CallStatus.RUNNING: (spin or "⠋", "cyan"),
        CallStatus.DONE_OK: ("✓", "green"),
        CallStatus.DONE_ERROR: ("✗", "red"),
        CallStatus.DENIED: ("⊘", "red"),
        # P2.2 plan-mode rejection: dim diamond, block reason in body.
        CallStatus.MODE_BLOCKED: ("◊", "grey50"),
    }[s]


# P2.1 subagent glyphs. The renderer uses these in `subagent_card` to
# show in-flight (`↳`) vs completed (`↲`) child sessions in the parent's
# transcript. They sit alongside the per-call CallStatus glyphs but are
# not part of the CallStatus enum because subagents own their own state
# machine (one Panel per child, not per-call lifecycle).
SUBAGENT_GLYPH_FLIGHT = "↳"
SUBAGENT_GLYPH_DONE = "↲"


def _waiting_verb(elapsed: float) -> str:
    # Renderer-side spinner verbs while we wait for the first stream
    # event. Distinct from the model's reasoning_content panel (which
    # has its own "thinking" / "thought for Xs" titles): the waiting
    # spinner fires whenever Live is open with no events yet, including
    # when `show_thinking=False`. Using non-"thinking" wording keeps the
    # two concepts separate so a user who opted out of thinking display
    # never sees the word.
    if elapsed < 5:
        return "waiting"
    if elapsed < 15:
        return "still waiting"
    return "taking a while"


def _format_tokens(n: int) -> str:
    """Compact token count for inline status lines (e.g. 12345 -> '12k')."""
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f}M"
    if n >= 1_000:
        return f"{n // 1_000}k"
    return str(n)


class _LiveBuffer:
    """Accepts streaming events and refreshes the Live display.

    Mutates the shared TurnState; reads it back to render frames.
    """

    def __init__(self, live: Live | None, console: Console, state: TurnState) -> None:
        self._live = live
        self._console = console
        self._state = state
        self._frame = 0

    def handle(self, ev_type: str, payload: Any) -> None:
        st = self._state
        if ev_type == "reasoning":
            st.reasoning += payload
            st.waiting_first_token = False
        elif ev_type == "text":
            st.text += payload
            st.waiting_first_token = False
            self._maybe_commit_reasoning()
            self._maybe_commit_paragraphs()
        elif ev_type == "tool_call_start":
            idx = payload["index"]
            st.calls[idx] = CallState(
                index=idx,
                call_id=payload.get("id") or "",
                name=payload["name"],
            )
            st.waiting_first_token = False
            self._maybe_commit_reasoning()
        elif ev_type == "tool_call_args_delta":
            idx = payload["index"]
            cs = st.calls.get(idx)
            if cs is not None:
                cs.args_str += payload["chunk"]
        if self._live is not None:
            self._live.update(self._render(), refresh=True)

    def _maybe_commit_paragraphs(self) -> None:
        """Stream completed Markdown paragraphs to scrollback as they arrive.

        Bodies render as Markdown — paragraph boundary is `\\n\\n`.  As soon
        as a complete paragraph appears past `committed_text_len`, render
        it as a Markdown block via ``live.console.print`` (Rich clears the
        live frame, prints, redraws) and advance the cursor.  The live
        frame then shows only the in-flight final paragraph.

        Why this exists: previously the entire body lived inside the Live
        region with ``vertical_overflow="ellipsis"`` and was re-printed
        in full via ``render_final`` after Live exited.  For responses
        taller than the terminal viewport, Rich's cursor-up-to-clear can't
        reach above the visible viewport, so the live frame's tail
        scrolled into scrollback before the post-Live full-body print
        added the same content again.  Result: visible duplication and a
        burst-feel because the body looked frozen during streaming and
        then "appeared" all at once when the final print landed.

        Streaming paragraph-by-paragraph eliminates both:
          - committed paragraphs flow into scrollback immediately, so the
            user sees genuine incremental output even past the viewport,
            and
          - render_final only emits the trailing in-flight paragraph
            (which Live just cleared), so there's nothing to duplicate.

        Markdown block boundaries respect `\\n\\n`, so paragraphs, code
        fences, lists, tables, and headings all commit cleanly.  A
        paragraph that *contains* code fences (open at start, close at
        end of paragraph) renders as a single Markdown block.
        """
        st = self._state
        if self._live is None:
            return
        # Find the last `\n\n` past the committed cursor; everything up
        # to (and including) that delimiter is a complete paragraph
        # block ready to commit.
        unfinished_start = st.committed_text_len
        idx = st.text.rfind("\n\n")
        if idx < unfinished_start:
            return
        # `idx + 2` includes the delimiter so committed text + remainder
        # reconstructs the full body byte-for-byte.
        commit_through = idx + 2
        block = st.text[unfinished_start:commit_through]
        # Refresh first so the in-flight live frame reflects the
        # post-commit (now shorter) renderable before Rich's
        # console.print clear-print-redraw cycle starts.  Without this,
        # `_live_render.renderable` still points at the pre-commit frame
        # and Rich would re-emit the just-printed content underneath
        # the new scrollback line — the same ghosting we avoid in
        # `_maybe_commit_reasoning`.
        st.committed_text_len = commit_through
        self._live.update(self._render(), refresh=True)
        self._live.console.print(Markdown(block))

    def _maybe_commit_reasoning(self) -> None:
        """Commit the reasoning Panel to scrollback as permanent output.

        Fires on the first event that means "reasoning is done" — first
        text chunk, first tool_call_start, or stream end (via render_final).
        Idempotent via ``st.reasoning_committed``: subsequent triggers are
        no-ops, so a stream that emits text and then a tool call doesn't
        produce two panels.

        Skipped when ``show_thinking=False`` or when there's no live region
        (headless subagents — the parent's ``subagent_card`` summarizes the
        child's reasoning instead).
        """
        st = self._state
        if not (st.reasoning and st.show_thinking) or st.reasoning_committed:
            return
        if not st.reasoning_done:
            st.reasoning_done = True
            st.reasoning_duration_s = time.perf_counter() - st.started_at
        st.reasoning_committed = True
        if self._live is None:
            return
        # Refresh the live region with the post-commit renderable BEFORE
        # printing the panel. Without `refresh=True`, Rich's `_live_render`
        # internal renderable still points at the in-flight thinking panel,
        # and the auto-redraw inside `live.console.print` would re-emit it
        # underneath the just-committed panel — producing a visible
        # thinking-panel ghost. Forcing a refresh now means
        # `_live_render.renderable` is the new (text-only) frame by the time
        # `console.print(panel)` triggers its scrollback-then-redraw cycle.
        self._live.update(self._render(), refresh=True)
        d = st.reasoning_duration_s or 0.0
        panel = Panel(
            Text(st.reasoning, style="dim italic"),
            title=f"[dim]thought for {d:0.1f}s[/]",
            title_align="left",
            border_style="grey50",
            padding=(0, 1),
            expand=False,
        )
        # `live.console.print` is the documented Rich pattern for emitting
        # permanent scrollback above an active Live region — Rich clears the
        # live frame, prints the renderable, then redraws the frame below.
        self._live.console.print(panel)

    def __rich__(self) -> RenderableType:
        # Hook for Rich's auto-refresh: when this _LiveBuffer is passed as
        # the Live renderable, Rich calls __rich__ on every refresh tick
        # (refresh_per_second=20 ⇒ 50 ms cadence). That makes the
        # `waiting_first_token` spinner animate during long TTFT windows
        # (e.g. v4-pro thinking server-side for 100+ s before the first
        # reasoning delta) — without this hook, Live re-renders the same
        # static frame and the user sees a blank line that looks hung.
        # `_render()` reads the live TurnState every call so reasoning
        # / text / tool-call lines update naturally too; explicit
        # `live.update(...)` calls in `handle` / `_maybe_commit_reasoning`
        # remain so events get an immediate (≤0 ms) repaint instead of
        # waiting for the next 50 ms tick.
        return self._render()

    def _render(self) -> RenderableType:
        st = self._state
        self._frame = (self._frame + 1) % len(_SPIN_FRAMES)
        spin = _SPIN_FRAMES[self._frame]
        parts: list[RenderableType] = []

        if st.waiting_first_token:
            elapsed = time.perf_counter() - st.started_at
            verb = _waiting_verb(elapsed)
            parts.append(Text(f"  {spin}  {verb}… {elapsed:0.1f}s",
                              style="dim italic"))

        # Live preview of the in-flight reasoning panel. Once committed
        # (first text / first tool call / stream end) the panel lives in
        # scrollback above the live region — `_maybe_commit_reasoning`
        # printed it via `live.console.print` — and we render nothing here.
        if st.reasoning and st.show_thinking and not st.reasoning_done:
            parts.append(Panel(
                Text(st.reasoning, style="dim italic"),
                title="[dim]thinking[/]",
                title_align="left",
                border_style="grey50",
                padding=(0, 1),
                expand=False,
            ))

        # Only the in-flight final paragraph lives in the live frame —
        # earlier paragraphs have already been committed to scrollback by
        # `_maybe_commit_paragraphs`.  This keeps the live frame bounded
        # to one paragraph (typically a few lines) so Rich's cursor-up
        # redraw stays inside the viewport, no overflow ghosting.
        unfinished = st.text[st.committed_text_len:]
        if unfinished:
            parts.append(Markdown(unfinished))

        for idx in sorted(st.calls):
            parts.append(self._render_call_line(st.calls[idx], spin))

        return Group(*parts) if parts else Text("")

    def _render_call_line(self, c: CallState, spin: str) -> Text:
        glyph, color = _glyph_for(c.status, spin)
        args_preview = c.args_str.strip().replace("\n", " ")
        if len(args_preview) > 60:
            args_preview = args_preview[:60] + "…"
        line = Text()
        line.append(f"  {glyph}  ", style=color)
        line.append(c.name, style=f"bold {color}")
        if args_preview:
            line.append(f"  {args_preview}", style="dim")
        if c.started_at and c.status == CallStatus.RUNNING:
            line.append(f"   {time.perf_counter() - c.started_at:0.1f}s", style="dim")
        elif c.started_at and c.ended_at:
            line.append(f"   {c.ended_at - c.started_at:0.1f}s", style="dim")
        return line

    def render_final(self) -> RenderableType:
        # Stream finished. If reasoning is still uncapped (e.g. KeyboardInterrupt
        # mid-thought, or a stream that emitted nothing but reasoning) commit
        # the panel now so it survives in scrollback. Then return ONLY the
        # trailing in-flight paragraph — everything before it has already
        # been streamed to scrollback paragraph-by-paragraph via
        # `_maybe_commit_paragraphs`. Returning `Markdown(st.text)` here
        # (the old behavior) would re-print the entire body, producing
        # the visible duplication that motivated this refactor.
        # Tool-call lines are intentionally dropped from the post-Live
        # commit because each call gets its own permanent result Panel
        # via `_render_tool_card` post-dispatch — leaving them here
        # would produce a stale `◯ queued` line stacked above the same
        # call's `✓ done` panel.
        self._maybe_commit_reasoning()
        st = self._state
        unfinished = st.text[st.committed_text_len:]
        return Markdown(unfinished) if unfinished else Text("")


class Renderer:
    def __init__(
        self,
        console: Console | None = None,
        stream: bool = True,
        show_thinking: bool = True,
        *,
        headless: bool = False,
    ) -> None:
        self.console = console or Console()
        self.stream = stream
        self.show_thinking = show_thinking
        # P2.1 headless mode: subagents pass `headless=True` so their
        # iteration loop drives `_LiveBuffer` without opening a `rich.Live`
        # region (mutually exclusive with the parent's Live) and without
        # printing tool cards or info/error lines. We still accept
        # streaming events (so tool_calls, reasoning, etc. populate the
        # TurnState the way `run_session` expects), and we still record
        # `recent_results` so `/last` can surface a subagent's outputs.
        self.headless = headless
        # Captured stand-in for stdout when headless. The parent's
        # `subagent_card` Panel reads this for the dim-bordered body
        # and `FRED_SHOW_SUBAGENTS=1` forwards it to stderr verbatim.
        self.headless_buffer: list[str] = []
        self._turn: TurnState | None = None
        self.last_reasoning: str | None = None
        self.recent_results: deque[tuple[str, str]] = deque(maxlen=10)

        # Per-slot session-cumulative usage counters (consumed by /cost).
        # Keyed by slot name. The aggregate `session_in`/`_out`/`_cached`/
        # `_cost`/`_turns` @properties below sum across slots for callers
        # that don't care about the per-slot breakdown.
        self.session_costs: dict[str, dict[str, Any]] = {
            slot: {
                "in": 0,
                "out": 0,
                "cached": 0,
                "cost": 0.0,
                "turns": 0,
                "model": None,
            }
            for slot in ("main", "editor", "weak", "subagent_main")
        }
        # Most recent main-slot call's deltas, used by the persistent
        # bottom toolbar to render `turn N $C` alongside session totals.
        # Editor/weak/subagent calls don't overwrite this — the toolbar
        # tracks the user's perceived turn, not auxiliary passes.
        self.last_turn: dict[str, Any] = {
            "model": None, "in": 0, "out": 0, "cached": 0, "cost": 0.0,
        }
        # Tracks whether `editor_failure_notice` has been printed this
        # session (one-time-per-session disclosure for misconfigured
        # editor models — see `fred.editor_pass`).
        self._editor_failure_notified = False

    # Cross-slot summary aggregates for callers that don't need the
    # per-slot breakdown (status line, tracer rollups, simple `/cost`).
    @property
    def session_in(self) -> int:
        return sum(s["in"] for s in self.session_costs.values())

    @property
    def session_out(self) -> int:
        return sum(s["out"] for s in self.session_costs.values())

    @property
    def session_cached(self) -> int:
        return sum(s["cached"] for s in self.session_costs.values())

    @property
    def session_cost(self) -> float:
        return sum(s["cost"] for s in self.session_costs.values())

    @property
    def session_turns(self) -> int:
        return sum(s["turns"] for s in self.session_costs.values())

    @contextmanager
    def assistant_turn(
        self,
        *,
        iteration: int = 0,
        max_iters: int = 50,
    ) -> Iterator[_LiveBuffer]:
        self._turn = TurnState(
            iteration=iteration,
            max_iters=max_iters,
            show_thinking=self.show_thinking,
        )
        if self.headless:
            # No Live region; the parent's renderer owns the only Live in
            # the process. We still drive `_LiveBuffer` so streaming events
            # update the TurnState normally — the parent will read assembled
            # text out of `_turn` after the subagent completes.
            buf = _LiveBuffer(None, self.console, self._turn)
            yield buf
        elif self.stream:
            # `vertical_overflow="ellipsis"` (not "visible") because rich.Live's
            # cursor-up redraw can't cross the terminal viewport boundary. With
            # "visible" + a response taller than the viewport, each refresh
            # appended another full copy of the frame to scrollback rather than
            # overwriting in place — a single tall reply produced tens of
            # thousands of duplicated lines. Bounding the frame to the viewport
            # keeps the cursor-up redraw working; we then commit the full
            # assembled body to scrollback once after Live exits.
            #
            # The renderable passed to Live is `buf` itself — `_LiveBuffer`
            # implements `__rich__` so Rich's auto-refresh re-renders the
            # current TurnState on every tick. That's what makes the
            # `waiting_first_token` spinner visibly tick during a long TTFT.
            # Constructing the buffer with `_live=None` and binding `live`
            # right after entering the context keeps explicit `live.update(...)`
            # calls in `handle` / `_maybe_commit_reasoning` working for the
            # immediate-repaint path.
            buf = _LiveBuffer(None, self.console, self._turn)
            with Live(
                buf,
                console=self.console,
                refresh_per_second=20,
                transient=True,
                vertical_overflow="ellipsis",
            ) as live:
                buf._live = live
                yield buf
            self.console.print(buf.render_final())
        else:
            buf = _LiveBuffer(None, self.console, self._turn)
            yield buf
            self.console.print(buf.render_final())
        self.last_reasoning = self._turn.reasoning or None

    # --- tool lifecycle (called from agent.py during dispatch) ---

    def find_call(self, openai_call_id: str) -> CallState | None:
        if self._turn is None:
            return None
        for cs in self._turn.calls.values():
            if cs.call_id == openai_call_id:
                return cs
        return None

    def tool_status(
        self,
        cs: CallState | None,
        status: CallStatus,
        *,
        lines: int | None = None,
    ) -> None:
        if cs is None:
            return
        cs.status = status
        if status == CallStatus.RUNNING and cs.started_at is None:
            cs.started_at = time.perf_counter()
        if lines is not None:
            cs.lines = lines

    def tool_done(
        self,
        cs: CallState | None,
        status: CallStatus,
        tc: ToolCall,
        result: str,
        *,
        checkpoint_sha: str | None = None,
    ) -> None:
        if cs is None:
            # Defensive: if streaming missed the call (shouldn't happen, but
            # don't crash) synthesize one so the user still sees the result.
            cs = CallState(index=-1, call_id=tc.id, name=tc.name)
        cs.status = status
        if cs.started_at is None:
            cs.started_at = time.perf_counter()
        cs.ended_at = time.perf_counter()
        cs.summary, cs.result_preview = format_result(tc.name, tc.arguments, result)
        cs.result_full = result
        # P4.3: stash the checkpoint SHA so `_render_tool_card` can emit
        # the dim ``↶ checkpoint <sha>`` line right after the result
        # Panel. ``None`` means "no checkpoint for this call" (read-only
        # tool, denied, debounced, or feature disabled) — the marker
        # is suppressed in that case.
        cs.checkpoint_sha = checkpoint_sha
        # P2.1: the `agent` tool already rendered a `subagent_card` Panel
        # from inside its handler; skip the generic tool-result panel for
        # it to avoid double-printing. Lifecycle bookkeeping (the
        # CallState mutations above) still happens so the parent's
        # in-frame glyph table reflects "subagent done."
        # PR-B2: same treatment for `attempt_completion` — the session
        # loop renders a distinct green completion panel after the
        # terminator fires; suppress the generic tool-result panel.
        if tc.name in ("agent", "attempt_completion"):
            return
        self._render_tool_card(cs)

    def _render_tool_card(self, c: CallState) -> None:
        glyph, color = _glyph_for(c.status, "")
        elapsed = (
            (c.ended_at - c.started_at)
            if (c.started_at is not None and c.ended_at is not None)
            else 0.0
        )
        title = (
            f"[{color}]{glyph}[/] [bold]{c.name}[/] · "
            f"{c.summary} · [dim]{elapsed:0.1f}s[/]"
        )
        body = c.result_preview if c.result_preview else "(empty)"
        # Always record the result for /last and for the parent's
        # subagent_card body — but in headless mode we suppress the
        # Panel print so the parent's transcript stays clean.
        if not self.headless:
            self.console.print(Panel(
                body,
                title=title,
                title_align="left",
                border_style=color,
                padding=(0, 1),
                expand=False,
            ))
            # P4.3: inline checkpoint marker. Single dim line beneath the
            # result Panel; lets the user `/restore <sha>` later. Skipped
            # for headless renderers (subagent transcripts stay clean).
            if c.checkpoint_sha:
                short = c.checkpoint_sha[:7]
                self.console.print(
                    f"[dim]  ↶ checkpoint {short}[/]", highlight=False,
                )
        else:
            self.headless_buffer.append(f"{title}\n{body}")
        self.recent_results.append((title, c.result_full))

    def completion_panel(self, result: str) -> None:
        """Render the model's `attempt_completion(result=...)` final summary.

        Distinct from a tool-result panel: green border + ``✓ done`` title
        signals turn termination unambiguously. Headless subagents skip
        the print but still get a buffered marker — the parent's
        ``subagent_card`` summarizes from ``final_text`` separately.
        """
        if self.headless:
            self.headless_buffer.append(f"DONE\n{result}")
            self.recent_results.append(("done", result))
            return
        self.console.print(Panel(
            Markdown(result),
            title="[green]✓[/] [bold]done[/]",
            title_align="left",
            border_style="green",
            padding=(0, 1),
            expand=False,
        ))
        self.recent_results.append(("done", result))

    # --- usage / cost ---

    def show_usage(
        self, usage: dict | None, model: str, *, slot: str = "main",
    ) -> None:
        if not usage:
            return
        from fred.cost import upstream_dollars

        in_tok = usage.get("prompt_tokens", 0) or 0
        out_tok = usage.get("completion_tokens", 0) or 0
        cached = (
            usage.get("prompt_cache_hit_tokens")
            or (usage.get("prompt_tokens_details") or {}).get("cached_tokens", 0)
            or 0
        )
        # cost.upstream_dollars routes through the same rate-card lookup
        # that fred.cost.billed_microcents (and therefore the telemetry
        # tracer) uses, so the user-visible /cost figure can't drift
        # from what telemetry records.
        cost = upstream_dollars(usage, model)
        bucket = self.session_costs.setdefault(
            slot,
            {"in": 0, "out": 0, "cached": 0, "cost": 0.0, "turns": 0, "model": None},
        )
        bucket["in"] += in_tok
        bucket["out"] += out_tok
        bucket["cached"] += cached
        bucket["cost"] += cost
        bucket["turns"] += 1
        bucket["model"] = model
        # Editor/weak/subagent calls accumulate session totals but don't
        # overwrite `last_turn` — the toolbar's `turn N $C` segment tracks
        # the user's perceived turn, not auxiliary passes.
        if slot == "main":
            self.last_turn = {
                "model": model, "in": in_tok, "out": out_tok,
                "cached": cached, "cost": cost,
            }

    def cost_summary(self) -> str:
        active = [
            (slot, bucket)
            for slot, bucket in self.session_costs.items()
            if bucket["turns"] > 0
        ]
        # When only main fired, render the legacy single-block summary so
        # users without editor/weak/subagent activity see the unchanged UI.
        if len(active) <= 1:
            lines = [
                f"Session totals across {self.session_turns} iteration(s):",
                f"  input tokens   : {self.session_in:,}  "
                f"({self.session_cached:,} cached)",
                f"  output tokens  : {self.session_out:,}",
                f"  estimated cost : ${self.session_cost:.4f}",
            ]
            if self.session_cached > 0 and self.session_in > 0:
                pct = 100.0 * self.session_cached / self.session_in
                lines.append(
                    f"  cache hit rate : {pct:.1f}% "
                    f"({self.session_cached:,} cached / {self.session_in:,} input)"
                )
            return "\n".join(lines)

        # Multi-slot breakdown: one row per slot that fired, then a total.
        lines = [
            f"Session totals across {self.session_turns} iteration(s):",
        ]
        # Stable ordering: main first, then editor / weak / subagent_main.
        order = {"main": 0, "editor": 1, "weak": 2, "subagent_main": 3}
        for slot, bucket in sorted(active, key=lambda kv: order.get(kv[0], 99)):
            model = bucket["model"] or "?"
            lines.append(
                f"  {slot:<14} ({model})"
                f" : {bucket['in']:,} in"
                f" ({bucket['cached']:,} cached)"
                f" · {bucket['out']:,} out"
                f" · ${bucket['cost']:.4f}"
            )
        lines.append(f"  {'total':<14} : ${self.session_cost:.4f}")
        if self.session_cached > 0 and self.session_in > 0:
            pct = 100.0 * self.session_cached / self.session_in
            lines.append(
                f"  cache hit rate : {pct:.1f}% "
                f"({self.session_cached:,} cached / {self.session_in:,} input)"
            )
        return "\n".join(lines)

    # --- todos ---

    def show_todos(self) -> None:
        # Lazy import keeps render.py free of tool-specific deps.
        from fred.tools.todo import get_todos
        if self.headless:
            return
        todos = get_todos()
        if not todos:
            return
        glyph = {
            "pending": "[dim]☐[/]",
            "in_progress": "[yellow]◐[/]",
            "completed": "[green]☑[/]",
        }
        line_style = {
            "pending": "",
            "in_progress": "bold",
            "completed": "dim strike",
        }
        self.console.print()
        self.console.print("[bold]Todos[/]")
        for t in todos:
            text = t.content.replace("[", r"\[")
            style = line_style.get(t.status, "")
            self.console.print(f"  {glyph[t.status]}  [{style}]{text}[/]"
                               if style else f"  {glyph[t.status]}  {text}")
        self.console.print()

    # --- subagents (P2.1) ---

    @contextmanager
    def subagent_running(self, agent_type: str) -> Iterator[None]:
        """Animated spinner that bridges streaming-end → subagent_card.

        The parent's Live region clears the in-flight tool-call line
        when the assistant stream ends. For the `agent` tool the
        replacement (`subagent_card`) only prints after `run_session`
        returns — which can be tens of seconds. Without this bridge the
        terminal goes silent in between, making the call look broken.

        Pairs with ``subagent_card``. Headless renderers (the
        subagent's own renderer) suppress this so the parent's status
        is the only one on screen.
        """
        if self.headless:
            yield
            return
        msg = (
            f"[grey50]{SUBAGENT_GLYPH_FLIGHT}[/] [bold]{agent_type} agent[/] "
            f"[dim]— running…[/]"
        )
        with self.console.status(msg, spinner="dots", spinner_style="grey50"):
            yield

    def subagent_card(
        self,
        *,
        agent_type: str,
        iterations: int,
        elapsed_s: float,
        total_tokens: int,
        summary: str,
        outcome: str = "ok",
    ) -> None:
        """Render the parent-side Panel summarizing one completed subagent.

        Mirrors Claude Code's `↳ explore agent · 3 iter · 0.4s · 1.2k tokens`
        title with the final summary in dim borders. Always rendered to the
        parent's console (this method is called from the parent's renderer,
        never the child's). The full summary is appended to `recent_results`
        so `/last` works on it.

        `outcome` is "ok" / "iter_cap" / "error"; controls the glyph and
        border color (red on error, dim grey otherwise).
        """
        glyph = SUBAGENT_GLYPH_DONE
        color = "grey50" if outcome == "ok" else "yellow" if outcome == "iter_cap" else "red"
        title = (
            f"[{color}]{glyph}[/] [bold]{agent_type} agent[/] · "
            f"{iterations} iter · [dim]{elapsed_s:0.1f}s[/] · "
            f"[dim]{_format_tokens(total_tokens)} tokens[/]"
        )
        body = summary or "[dim](no summary returned)[/]"
        self.console.print(Panel(
            body,
            title=title,
            title_align="left",
            border_style=color,
            padding=(0, 1),
            expand=False,
        ))
        self.recent_results.append((title, summary))

    # --- misc ---

    def info(self, msg: str) -> None:
        if self.headless:
            self.headless_buffer.append(msg)
            return
        self.console.print(f"[dim]{msg}[/]")

    def error(self, msg: str) -> None:
        if self.headless:
            self.headless_buffer.append(f"ERROR: {msg}")
            return
        self.console.print(f"[red]{msg}[/]")

    def editor_pass_starting(self, tool_name: str) -> None:
        """Dim heads-up before the editor pass blocks the main thread.

        The editor pass consumes a full streaming response synchronously
        between architect output and tool dispatch (see
        ``editor_pass.maybe_editor_repair``). On a slow editor model or
        a misrouted call this can take seconds with no UI signal — the
        Live region has already exited and tool dispatch hasn't started.
        Print a single dim line so the user knows the system is still
        working. Pairs with ``editor_pass_done``.
        """
        if self.headless:
            return
        self.console.print(
            f"[dim]  · editor reviewing {tool_name}…[/]", highlight=False,
        )

    def editor_pass_done(self, tool_name: str, elapsed_s: float) -> None:
        """Companion to ``editor_pass_starting`` — closes the loop with timing."""
        if self.headless:
            return
        self.console.print(
            f"[dim]    ↪ reviewed in {elapsed_s:0.1f}s[/]", highlight=False,
        )

    def natural_stop_notice(self) -> None:
        """One-line dim notice when the model emitted no tool_calls.

        Without this, a /pro architect that produces only reasoning + a
        stub like "Let me do this." with no tool_call looks identical to
        a hang — the cost line prints, the loop returns, and the user
        sees no signal that the model gave up rather than executed.
        Skipped when ``stream_result.text`` was substantive (the model
        gave a real answer); fired only when the response is short and
        empty of action.
        """
        if self.headless:
            return
        self.console.print(
            "[dim]  (model stopped without calling a tool)[/]", highlight=False,
        )

    def editor_failure_notice(self, model: str, error_type: str) -> None:
        """One-time-per-session warning when the editor pass fails.

        Misconfigured editor models (typo, missing tier, network outage)
        would otherwise be silent — the editor pass swallows exceptions
        and falls back to the architect's original tool_call args.
        Telemetry captures every failure, but the user sees nothing.

        We surface a single dim-yellow line on the first failure so the
        user can fix or unset their editor model. Subsequent failures
        the same session stay silent (telemetry alone) to avoid spam.
        """
        if self._editor_failure_notified or self.headless:
            return
        self._editor_failure_notified = True
        self.console.print(
            f"[yellow]editor pass unavailable[/] "
            f"[dim]({model}: {error_type}); "
            f"file edits proceeding without repair. "
            f"Set editor slot via /model or unset FRED_EDITOR_MODEL.[/]"
        )

    def compaction_notification(
        self, before_tokens: int, after_tokens: int, focus: str | None,
    ) -> None:
        """Emit a single dim line confirming a compaction pass landed.

        Called both from the auto-trigger inside `run_session` and from
        the `/compact` slash branch in `cli.py`. Format mirrors the
        spec in P2.5: `compacted N messages -> M tokens (focus: …)`.
        We print just one line so the user notices the savings without
        the surrounding agent-turn UI shifting under them.

        `before_tokens` and `after_tokens` come from `compact_messages`'s
        stats dict; the formatter here doesn't know how many MESSAGES
        collapsed into the summary because that detail isn't part of the
        stats contract — instead we surface the meaningful number
        (tokens before/after) so the user sees the actual context save.
        """
        focus_label = focus.strip() if (focus and focus.strip()) else "general"
        self.console.print(
            f"[dim]compacted {_format_tokens(before_tokens)} -> "
            f"{_format_tokens(after_tokens)} tokens (focus: {focus_label})[/]"
        )

    # --- status line (P3.3) ---

    def status_line(
        self,
        *,
        model_cfg: Any = None,
        mode: str | None = None,
        used_tokens: int | None = None,
        total_tokens: int | None = None,
        cost: float | None = None,
        cache_hit_rate: float | None = None,
        repo_map_size: int | None = None,
        todos_active: tuple[int, int, int] | None = None,
    ) -> str:
        """Format the bottom-of-turn status line.

        Returns the rendered line as a plain string (no Rich markup).
        Fields are joined with `" · "` separators; missing fields are
        skipped so the line stays compact when stats aren't available.

        Format (when all fields populated):
            ``model · mode · used/total (X% cached) · $cost · repo: N files · todos: A active · D done · P pending``

        - ``model_cfg`` may be a ``ModelConfig`` (we read ``main_model``)
          or a plain string. ``None`` omits the field.
        - ``cache_hit_rate`` is a 0..1 float; rendered as an integer
          percentage and only included when ``used_tokens`` is also set
          (so the cache figure has a denominator to attach to).
        - ``todos_active`` is ``(active_count, done_count, pending_count)``;
          omitted only when all three are zero (i.e. no todos exist).
          Zeros within an existing todo set are still rendered so the
          state breakdown is unambiguous.
        - The function is pure — no I/O, no rich calls. Use
          ``print_status_line`` to actually emit it.
        """
        parts: list[str] = []
        if model_cfg is not None:
            # Accept either a ModelConfig (preferred) or a bare model
            # name. Don't reach into rich/typer types — duck-type on
            # ``main_model`` so a fake from a unit test works.
            name = getattr(model_cfg, "main_model", None) or str(model_cfg)
            parts.append(name)
        if mode:
            parts.append(mode)
        if used_tokens is not None and total_tokens is not None and total_tokens > 0:
            seg = f"{_format_tokens(used_tokens)}/{_format_tokens(total_tokens)}"
            if cache_hit_rate is not None:
                pct = int(round(100 * max(0.0, min(1.0, cache_hit_rate))))
                seg += f" ({pct}% cached)"
            parts.append(seg)
        elif used_tokens is not None:
            seg = _format_tokens(used_tokens)
            if cache_hit_rate is not None:
                pct = int(round(100 * max(0.0, min(1.0, cache_hit_rate))))
                seg += f" ({pct}% cached)"
            parts.append(seg)
        if cost is not None:
            parts.append(f"${cost:.4f}" if cost < 0.01 else f"${cost:.2f}")
        if repo_map_size is not None and repo_map_size > 0:
            parts.append(f"repo: {repo_map_size} files")
        if todos_active is not None:
            active, done, pending = todos_active
            if active + done + pending > 0:
                parts.append(
                    f"todos: {active} active · {done} done · {pending} pending"
                )
        return " · ".join(parts)

    def print_status_line(
        self,
        *,
        model_cfg: Any = None,
        mode: str | None = None,
        used_tokens: int | None = None,
        total_tokens: int | None = None,
        cost: float | None = None,
        cache_hit_rate: float | None = None,
        repo_map_size: int | None = None,
        todos_active: tuple[int, int, int] | None = None,
    ) -> str:
        """Render the status line and print it to the console.

        This is the cli.py-facing entry point. Called AFTER each
        ``run_turn`` returns (never inside the assistant Live region —
        the two are mutually exclusive). Returns the rendered string so
        the caller can also feed it to telemetry without re-formatting.

        Reduced-motion behavior (``FRED_REDUCED_MOTION=1``): swaps
        ``console.rule()`` for a plain dim print on its own line. Both
        paths emit the same content; only the visual treatment differs.
        Headless renderers (subagents) skip output entirely so the
        parent's transcript stays clean — but we still return the
        formatted string for tracer payloads.
        """
        line = self.status_line(
            model_cfg=model_cfg,
            mode=mode,
            used_tokens=used_tokens,
            total_tokens=total_tokens,
            cost=cost,
            cache_hit_rate=cache_hit_rate,
            repo_map_size=repo_map_size,
            todos_active=todos_active,
        )
        if not line:
            return line
        if self.headless:
            return line
        if os.environ.get("FRED_REDUCED_MOTION") == "1":
            # Plain dim print — no horizontal rule, no spinner motion.
            # Mirrors the user's accessibility opt-out from the rich
            # animations that the rule line implies.
            self.console.print(f"[dim]{line}[/]", highlight=False)
        else:
            # `console.rule` writes a horizontal divider with the title
            # text inline, which gives a clear visual anchor for the
            # end-of-turn boundary without a second Live region.
            #
            # We force `\r\x1b[2K` (carriage-return + clear-line) before
            # the rule so any leftover cursor / partial input from
            # prompt_toolkit's input region or Rich's Live region gets
            # wiped. Without this, the rule character draws over the
            # mid-line cursor and leaves a visible white block embedded
            # in the divider.
            self.console.file.write("\r\x1b[2K")
            self.console.file.flush()
            self.console.rule(f"[dim]{line}[/]", style="dim", align="left")
        return line

    def footer_text(
        self,
        *,
        model_cfg: Any = None,
        mode: str | None = None,
        hotkey_hint: str | None = None,
    ) -> str:
        """Format the persistent bottom-toolbar string. Always non-empty (empty returns triggered a stray-bar bug on Terminal.app)."""
        parts: list[str] = []
        # Model: prefer the live ModelConfig, fall back to whatever the
        # last main-slot call recorded so the bar has a name on it
        # immediately after a /pro switch even before the next turn fires.
        name: str | None = None
        if model_cfg is not None:
            name = getattr(model_cfg, "main_model", None) or str(model_cfg)
        if not name:
            name = self.last_turn.get("model")
        if name:
            parts.append(name)
        if mode:
            parts.append(mode)

        def _money(c: float) -> str:
            return f"${c:.4f}" if c < 0.01 else f"${c:.2f}"

        if self.last_turn["in"] > 0 or self.last_turn["out"] > 0:
            t_tok = self.last_turn["in"] + self.last_turn["out"]
            parts.append(f"turn {_format_tokens(t_tok)} {_money(self.last_turn['cost'])}")

        if self.session_turns > 0:
            seg = (
                f"total {_format_tokens(self.session_in + self.session_out)} "
                f"{_money(self.session_cost)}"
            )
            if self.session_in > 0 and self.session_cached > 0:
                pct = int(round(100 * self.session_cached / self.session_in))
                if pct > 0:
                    seg += f" ({pct}% cached)"
            parts.append(seg)

        if hotkey_hint:
            parts.append(hotkey_hint)

        # Last-resort guard: if the caller passed nothing usable AND no
        # turn has fired yet (so model/mode were both None), keep the
        # bar non-empty to dodge the stray-bar rendering bug.
        if not parts:
            return "fred"
        return " · ".join(parts)
