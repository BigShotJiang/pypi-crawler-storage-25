import json
with open('graphify-out/.graphify_chunk_3.json') as f:
    d = json.load(f)
print('Keys:', list(d.keys()))
print('Nodes:', len(d['nodes']))
print('Edges:', len(d['edges']))
print('Hyperedges:', len(d['hyperedges']))
for n in d['nodes']:
    print('  Node: %s (%s)' % (n['id'], n['file_type']))
for e in d['edges']:
    print('  Edge: %s --[%s]--> %s (%s, %s)' % (e['source'], e['relation'], e['target'], e['confidence'], e['confidence_score']))
for h in d['hyperedges']:
    print('  Hyper: %s [%d nodes]' % (h['id'], len(h['nodes'])))
