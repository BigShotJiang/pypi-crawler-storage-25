"""WIDDX CLI configuration loader."""
from __future__ import annotations

import logging
import os
import sys
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger(__name__)

DEFAULT_CONFIG = Path(__file__).parent / "config.yaml"
USER_CONFIG = Path.home() / ".widdx" / "config.yaml"

DEFAULT_MEMORY_DB_PATH = "~/.widdx/memory.db"


def load_config() -> dict[str, Any]:
    config: dict[str, Any] = {}
    try:
        if DEFAULT_CONFIG.exists():
            with open(DEFAULT_CONFIG, encoding="utf-8") as fh:
                config = yaml.safe_load(fh) or {}
    except (yaml.YAMLError, OSError) as e:
        print(f"[widdx] Warning: Could not load default config: {e}", file=sys.stderr)
        config = {}
    try:
        if USER_CONFIG.exists():
            with open(USER_CONFIG, encoding="utf-8") as fh:
                user = yaml.safe_load(fh) or {}
            _deep_merge(config, user)
    except (yaml.YAMLError, OSError) as e:
        print(f"[widdx] Warning: Could not load user config: {e}", file=sys.stderr)
    # API key: env var takes priority, then config file
    config["__env__"] = {
        "deepseek_key": os.getenv("DEEPSEEK_API_KEY") or config.get("deepseek_api_key"),
        "google_key": os.getenv("GOOGLE_API_KEY") or config.get("google_api_key"),
    }
    return config


def save_config_key(key: str, value: Any) -> None:
    """Save a single key to ~/.widdx/config.yaml, preserving existing content.

    Sets file permissions to 600 (owner read/write only) for security.
    """
    existing: dict[str, Any] = {}
    try:
        if USER_CONFIG.exists():
            existing = yaml.safe_load(USER_CONFIG.read_text(encoding="utf-8")) or {}
    except Exception:
        logger.debug("Failed to load existing user config for key save", exc_info=True)
    existing[key] = value
    USER_CONFIG.parent.mkdir(parents=True, exist_ok=True)
    USER_CONFIG.write_text(yaml.dump(existing, allow_unicode=True, default_flow_style=False), encoding="utf-8")
    try:
        import stat
        os.chmod(USER_CONFIG, stat.S_IRUSR | stat.S_IWUSR)  # 600
    except Exception:
        logger.debug("Failed to set file permissions after save_config_key", exc_info=True)


def save_user_config(config: dict[str, Any]) -> None:
    """Save the full user config to ~/.widdx/config.yaml.

    Sets file permissions to 600 (owner read/write only) for security.
    """
    USER_CONFIG.parent.mkdir(parents=True, exist_ok=True)
    USER_CONFIG.write_text(yaml.dump(config, allow_unicode=True, default_flow_style=False), encoding="utf-8")
    try:
        import stat
        os.chmod(USER_CONFIG, stat.S_IRUSR | stat.S_IWUSR)  # 600
    except Exception:
        logger.debug("Failed to set file permissions after save_user_config", exc_info=True)


def _deep_merge(base: dict, overlay: dict) -> None:
    for key, value in overlay.items():
        if key in base and isinstance(base[key], dict) and isinstance(value, dict):
            _deep_merge(base[key], value)
        else:
            base[key] = value
