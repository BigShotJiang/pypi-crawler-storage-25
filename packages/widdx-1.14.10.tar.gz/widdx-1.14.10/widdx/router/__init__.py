"""AI Router — intelligent multi-provider routing with sequential review and parallel execution."""
from __future__ import annotations

import logging
import os
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any

import yaml

from .pricing import (
    PRICING,
    _estimate_tokens,
    _init_cost_tracking,
    _track_usage,
)
from .streaming import call_streaming, call_with_tools_streaming
from .tools_api import call_with_tools

logger = logging.getLogger(__name__)

# ── Executor model specialization ──────────────────────────────────
_EXECUTOR_SPECIALIZATION = {
    "deepseek-v4-flash-free": {"type": "coding", "desc": "general coding and edits"},
    "nemotron-3-super-free": {"type": "logic", "desc": "logic and complex algorithms"},
}

# Keywords that indicate a heavy task needing parallel execution
_HEAVY_TASK_KEYWORDS = {
    "build", "create", "generate", "implement", "scaffold",
    "full project", "complete system", "entire application",
    "migration", "refactor", "rewrite",
}


class AIRouter:
    """Routes tasks to providers with intelligent load balancing,
    sequential review, and parallel execution for heavy tasks."""

    # ── Injected methods from sub-modules ──────────────────────────
    call_streaming = call_streaming
    call_with_tools_streaming = call_with_tools_streaming
    call_with_tools = call_with_tools
    _estimate_tokens = _estimate_tokens
    _track_usage = _track_usage

    ARCHITECT_KEYWORDS = {
        "architecture", "design", "planning", "review", "validation",
        "architecture design", "system review", "refactoring plan",
        "security audit", "performance analysis", "code review",
    }

    EXECUTOR_KEYWORDS = {
        "code generation", "implementation", "boilerplate", "testing",
        "debugging", "fix", "build", "generate", "scaffold", "refactor",
    }

    ARCHITECT_PREFIX = (
        "You are a Senior Systems Architect and Principal Engineer.\n"
        "Your role is REASONING, PLANNING, and ARCHITECTURE DESIGN.\n"
        "Think step by step. Analyze deeply. Plan thoroughly.\n"
        "Output structured, clear plans — not implementation code.\n"
    )

    EXECUTOR_PREFIX = (
        "You are a Senior Software Engineer and Code Implementation Expert.\n"
        "Your role is IMPLEMENTATION and CODE GENERATION.\n"
        "Write clean, readable, production-ready code.\n"
        "Functions = verbs. Variables = nouns. Use guard clauses. Handle errors first.\n"
        "No trivial comments. No emojis. Focus on correctness and clarity.\n"
    )

    PRICING = PRICING
    _DEFAULT_OPENCODE_KEY = os.environ.get("OPENCODE_API_KEY", "")

    # OpenCode Zen provides free models but requires an API key
    # Get yours at: https://opencode.ai/auth
    # Without a key, rate limits are very low (~20-30 requests/session)
    @staticmethod
    def _opencode_key() -> str:
        key = os.environ.get("OPENCODE_API_KEY", "")
        if not key:
            try:
                from widdx.config import load_config
                config = load_config()
                key = config.get("__env__", {}).get("opencode_key", "")
            except Exception:
                pass
        return key

    # Fallback models — used when dynamic fetch fails
    # Only models confirmed FREE on OpenCode Zen pricing page
    _FALLBACK_FREE_MODELS = [
        {"role": "architect", "model": "big-pickle"},
        {"role": "executor", "model": "deepseek-v4-flash-free"},
        {"role": "executor", "model": "nemotron-3-super-free"},
    ]

    @staticmethod
    def _fetch_free_models(base_url: str = "https://opencode.ai/zen/v1") -> list[dict[str, str]]:
        """Fetch currently available FREE models from OpenCode Zen API.

        Returns a list of {role, model} dicts for models with FREE pricing.
        Falls back silently to hardcoded list on any error.
        """
        import urllib.request, json as _json
        try:
            url = f"{base_url.rstrip('/')}/models"
            req = urllib.request.Request(url, headers={"Accept": "application/json"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = _json.loads(resp.read().decode())
            models = []
            for m in data if isinstance(data, list) else data.get("data", []):
                mid = m.get("id", "")
                pricing = m.get("pricing", {}) if isinstance(m, dict) else {}
                inp = pricing.get("input", "")
                # Models with "Free" or "$0" pricing are free
                is_free = (
                    isinstance(inp, str) and ("free" in inp.lower() or "$0" in inp or inp == "0")
                ) or (
                    isinstance(inp, (int, float)) and inp == 0
                )
                if not is_free:
                    continue
                # Assign roles: if "pro" or "flash" or "big" → executores
                role = "architect" if "big" in mid or "pickle" in mid else "executor"
                models.append({"role": role, "model": mid})
            if models:
                logger.debug("Fetched %d free models from OpenCode Zen", len(models))
                return models
        except Exception as exc:
            logger.debug("Failed to fetch free models: %s", exc)
        return []  # Return empty → caller uses fallback

    FREE_PROVIDERS = (
        {
            "name": "opencode",
            "base_url": "https://opencode.ai/zen/v1",
            "api_key": "",
            "models": [],  # Filled dynamically via _fetch_free_models()
        },
    )

    def __init__(self, config: dict[str, Any], memory) -> None:
        self._config = config
        self._memory = memory
        deepseek_key = config.get("__env__", {}).get("deepseek_key")
        models = config.get("models", {})
        self._architect_model = models.get("architect", {}).get("model", "deepseek-v4-pro")
        self._executor_model = models.get("executor", {}).get("model", "deepseek-v4-flash")
        self._architect_thinking = models.get("architect", {}).get("thinking", False)
        self._architect_thinking_mode = models.get("architect", {}).get("thinking_mode", "enabled")
        self._session_input_tokens = 0
        self._session_output_tokens = 0
        self._session_cost = 0.0
        self._last_provider = ""
        self._last_model = ""
        self._provider_usage: dict[str, int] = {}
        self._has_api_key = bool(deepseek_key)
        self._providers = self._build_providers(deepseek_key)
        self._client = self._providers[0]["client"] if self._providers else None
        _init_cost_tracking(self)

    @property
    def memory(self):
        return self._memory

    @property
    def config(self):
        return self._config

    @property
    def executor_model(self):
        return self._executor_model

    @property
    def has_api_key(self) -> bool:
        return self._has_api_key

    # ── Provider building ─────────────────────────────────────────

    def _build_providers(self, deepseek_key: str | None) -> list[dict[str, Any]]:
        from openai import OpenAI

        providers: list[dict[str, Any]] = []

        if deepseek_key:
            providers.append({
                "name": "deepseek",
                "client": OpenAI(api_key=deepseek_key, base_url="https://api.deepseek.com"),
                "architect_model": self._architect_model,
                "executor_model": self._executor_model,
                "supports_thinking": True,
            })

        # Google Gemini (free API key from https://aistudio.google.com)
        google_key = self._config.get("__env__", {}).get("google_key")
        if google_key:
            providers.append({
                "name": "google",
                "client": OpenAI(
                    api_key=google_key,
                    base_url="https://generativelanguage.googleapis.com/v1beta/openai/",
                ),
                "architect_model": "gemini-2.5-pro",
                "executor_model": "gemini-2.0-flash",
                "supports_thinking": False,
            })
            providers.append({
                "name": "google",
                "client": OpenAI(
                    api_key=google_key,
                    base_url="https://generativelanguage.googleapis.com/v1beta/openai/",
                ),
                "architect_model": "gemini-2.5-pro",
                "executor_model": "gemini-2.5-flash",
                "supports_thinking": False,
            })

        free_config: dict[str, Any] = self._config.get("free_providers", {})
        for provider_def in self.FREE_PROVIDERS:
            name: str = str(provider_def["name"])
            configured: dict[str, Any] = free_config.get(name, {})
            base_url: str = str(configured.get("base_url", provider_def["base_url"]))
            # OpenCode Zen requires an API key from https://opencode.ai/auth
            # Without a key, rate limits are very restrictive (~20-30 req/session)
            api_key: str = self._opencode_key() if name == "opencode" else str(provider_def["api_key"])
            # OpenAI SDK 1.68+ requires non-empty api_key — use placeholder for anonymous access
            if not api_key:
                api_key = "anonymous"
            client = OpenAI(api_key=api_key, base_url=base_url)

            # Use dynamically fetched free models, fall back to hardcoded
            if name == "opencode":
                dynamic = self._fetch_free_models(base_url)
                model_list = dynamic if dynamic else list(self._FALLBACK_FREE_MODELS)
            else:
                model_list = list(provider_def["models"])
            first_arch = next((m["model"] for m in model_list if m["role"] == "architect"), model_list[0]["model"])
            first_exec = next((m["model"] for m in model_list if m["role"] == "executor"), model_list[0]["model"])
            seen: set[tuple[str, str]] = set()
            for model_entry in model_list:
                role = model_entry["role"]
                model = model_entry["model"]
                arch_m = model if role == "architect" else first_arch
                exec_m = model if role == "executor" else first_exec
                key = (arch_m, exec_m)
                if key in seen:
                    continue
                seen.add(key)
                providers.append({
                    "name": name,
                    "client": client,
                    "architect_model": arch_m,
                    "executor_model": exec_m,
                    "supports_thinking": False,
                })
        return providers

    # ── Provider management ───────────────────────────────────────

    def list_providers(self) -> list[dict]:
        disabled = set(self._config.get("disabled_providers", []))
        seen: dict[str, dict] = {}
        for p in self._providers:
            name = p["name"]
            if name not in seen:
                seen[name] = {
                    "name": name,
                    "architect_model": p["architect_model"],
                    "executor_model": p["executor_model"],
                    "enabled": name not in disabled,
                    "supports_thinking": p.get("supports_thinking", False),
                    "last_used": self._last_provider == name,
                    "model_count": 1,
                }
            else:
                seen[name]["model_count"] += 1
        return list(seen.values())

    def toggle_provider(self, name: str) -> bool:
        disabled = set(self._config.get("disabled_providers", []))
        if name in disabled:
            disabled.discard(name)
            self._config["disabled_providers"] = list(disabled)
            self._save_provider_config()
            return True
        disabled.add(name)
        self._config["disabled_providers"] = list(disabled)
        self._save_provider_config()
        return False

    def enable_only(self, name: str) -> None:
        all_names = [p["name"] for p in self._providers]
        disabled = [n for n in all_names if n != name]
        self._config["disabled_providers"] = disabled
        self._save_provider_config()

    def enable_all(self) -> None:
        self._config.pop("disabled_providers", None)
        self._save_provider_config()

    def _save_provider_config(self) -> None:
        user_path = Path.home() / ".widdx" / "config.yaml"
        try:
            existing: dict[str, Any] = {}
            if user_path.exists():
                existing = yaml.safe_load(user_path.read_text(encoding="utf-8")) or {}
            disabled = self._config.get("disabled_providers", [])
            if disabled:
                existing["disabled_providers"] = disabled
            else:
                existing.pop("disabled_providers", None)
            user_path.parent.mkdir(parents=True, exist_ok=True)
            user_path.write_text(yaml.dump(existing, allow_unicode=True, default_flow_style=False), encoding="utf-8")
        except Exception:
            logger.debug("Failed to persist provider status change", exc_info=True)

    def _providers_for_role(self, role: str) -> list[dict[str, Any]]:
        forced_provider = self._config.get("provider")
        role_cfg = self._config.get("models", {}).get(role, {})
        forced_provider = role_cfg.get("provider", forced_provider)
        if forced_provider and forced_provider != "auto":
            selected = [p for p in self._providers if p["name"] == forced_provider]
            if selected:
                return selected
        disabled = set(self._config.get("disabled_providers", []))
        return [p for p in self._providers if p["name"] not in disabled]

    def _model_for_provider(self, provider: dict[str, Any], role: str) -> str:
        forced_model = self._config.get("force_model")
        if forced_model:
            return str(forced_model)
        configured = self._config.get("models", {}).get(role, {}).get("model")
        if configured and provider["name"] == "deepseek":
            return str(configured)
        model = provider["architect_model"] if role == "architect" else provider["executor_model"]
        return str(model)

    def _remember_provider(self, provider_name: str, model: str) -> None:
        self._last_provider = provider_name
        self._last_model = model

    def _record_usage(self, provider_name: str, output_tokens: int) -> None:
        self._provider_usage[provider_name] = (
            self._provider_usage.get(provider_name, 0) + output_tokens
        )

    # ── Task classification ───────────────────────────────────────

    def classify(self, task_description: str) -> str:
        if self._providers:
            llm_result = self._classify_with_llm(task_description)
            if llm_result is not None:
                return llm_result
        return self._classify_with_keywords(task_description)

    def _classify_with_llm(self, task_description: str) -> str | None:
        for provider in self._providers_for_role("executor"):
            try:
                resp = provider["client"].chat.completions.create(
                    model=self._model_for_provider(provider, "executor"),
                    max_tokens=5,
                    messages=[
                        {
                            "role": "system",
                            "content": (
                                "You are a task classifier. Reply with exactly one word: "
                                "architect or executor.\n"
                                "architect = planning, design, review, analysis, architecture.\n"
                                "executor = coding, implementation, building, fixing, generating."
                            ),
                        },
                        {"role": "user", "content": task_description},
                    ],
                    temperature=0,
                )
                word = (resp.choices[0].message.content or "").strip().lower().split()[0]
                if word in ("architect", "executor"):
                    return word
            except Exception as e:
                logger.debug("LLM classification failed for provider %s: %s", provider['name'], e)
                continue
        return None

    def _classify_with_keywords(self, task_description: str) -> str:
        lowered = task_description.lower()
        arch_score = sum(1 for kw in self.ARCHITECT_KEYWORDS if kw in lowered)
        exec_score = sum(1 for kw in self.EXECUTOR_KEYWORDS if kw in lowered)
        if arch_score > exec_score:
            return "architect"
        if exec_score > arch_score:
            return "executor"
        stats = self._memory.routing_stats(self.infer_task_type(task_description))
        if stats:
            best = max(stats, key=lambda s: s["avg_score"])
            return str(best.get("model_selected", "executor"))
        return "executor"

    def infer_task_type(self, task: str) -> str:
        lowered = task.lower()
        if any(kw in lowered for kw in ["build", "create", "generate", "implement", "upgrade", "make", "add", "scaffold"]):
            return "build"
        if any(kw in lowered for kw in ["fix", "debug", "resolve", "repair", "correct", "bug"]):
            return "fix"
        if any(kw in lowered for kw in ["improve", "optimize", "refactor", "enhance", "tune", "clean"]):
            return "improve"
        if any(kw in lowered for kw in ["design", "architecture", "plan", "architect"]):
            return "design"
        return "general"

    def _is_heavy_task(self, task: str) -> bool:
        lowered = task.lower()
        return any(kw in lowered for kw in _HEAVY_TASK_KEYWORDS)

    def _classify_executor_task(self, task: str) -> str:
        """Classify executor task type for model specialization (Plan B)."""
        lowered = task.lower()
        if any(kw in lowered for kw in ["algorithm", "logic", "complex", "calculate", "compute", "math"]):
            return "logic"
        if any(kw in lowered for kw in ["large file", "long context", "many files", "entire project", "full codebase"]):
            return "context"
        return "coding"

    def _classify_step(self, message: str, messages_count: int = 0) -> str:
        """Classify a ToolLoop step for per-step model specialization.

        Categories: coding, review, logic, context
        """
        lowered = message.lower()
        review_kw = ["review", "test", "check", "lint", "verify", "fix", "bug",
                     "error", "debug", "quality", "refactor", "clean", "improve",
                     "format", "organize", "validate", "audit", "inspect"]
        if any(kw in lowered for kw in review_kw):
            return "review"
        logic_kw = ["algorithm", "logic", "complex", "calculate", "compute",
                    "math", "sort", "search", "optimize", "parse", "regex",
                    "transform", "convert", "encrypt", "hash"]
        if any(kw in lowered for kw in logic_kw):
            return "logic"
        context_kw = ["large", "entire", "whole", "full", "complete", "overview",
                      "all files", "many", "across", "summarize", "analyze project"]
        if any(kw in lowered for kw in context_kw):
            return "context"
        if messages_count > 15:
            return "context"
        return "coding"

    def _reorder_providers_for_step(self, step_type: str) -> list[dict]:
        """Reorder providers so the specialized model comes first for this step type.

        Paid providers (DeepSeek, Google) are always tried before free models.
        Among free models, the step-specialized model is tried first.
        """
        preferred = {
            "review": "deepseek-v4-flash-free",
            "logic": "nemotron-3-super-free",
            "context": "big-pickle",
            "coding": "deepseek-v4-flash-free",
        }
        preferred_model = preferred.get(step_type, "deepseek-v4-flash-free")

        # Separate paid and free providers
        paid_names = {"deepseek", "google"}
        paid = [p for p in self._providers if p["name"] in paid_names]
        free = [p for p in self._providers if p["name"] not in paid_names]

        # Among free providers, put the preferred model first
        preferred_free = [p for p in free if p.get("executor_model") == preferred_model]
        other_free = [p for p in free if p.get("executor_model") != preferred_model]

        return paid + preferred_free + other_free

    # ── Core call with fallback chain ─────────────────────────────

    def _single_call(self, provider: dict, model: str, system_prompt: str,
                     user_message: str, max_tokens: int, role: str,
                     retries: int = 2) -> dict:
        """Make a single API call with automatic retry on rate limits.

        Retries with exponential backoff on 429 (rate limit) and 5xx errors.
        Skips models that have been discontinued (promotion ended, needs subscription).
        """
        # Skip models known to be expired
        msg_lower = ""
        for attempt in range(retries + 1):
            try:
                return self._do_call(provider, model, system_prompt, user_message, max_tokens, role)
            except Exception as exc:
                msg_lower = str(exc).lower()
                is_rate_limit = "429" in msg_lower or "rate limit" in msg_lower or "too many requests" in msg_lower
                is_server_error = "500" in msg_lower or "502" in msg_lower or "503" in msg_lower or "server error" in msg_lower or "overloaded" in msg_lower
                is_expired = "promotion has ended" in msg_lower or "free promotion" in msg_lower or "needs subscription" in msg_lower or "subscription required" in msg_lower
                is_invalid = "invalid api key" in msg_lower or "auth" in msg_lower

                if is_expired:
                    # Don't retry — model is gone
                    raise RuntimeError(f"Model '{model}' is no longer free on OpenCode Zen") from exc
                if is_invalid:
                    raise RuntimeError(f"Invalid API key for {provider.get('name', '?')}. Get one at https://opencode.ai/auth or set OPENCODE_API_KEY.") from exc
                if is_rate_limit and attempt < 1:
                    # Single quick retry on rate limit, then give up
                    time.sleep(2)
                    continue
                if is_server_error and attempt < retries:
                    time.sleep((attempt + 1) * 3)
                    continue
                raise exc from None
        raise RuntimeError(str(msg_lower)) from None

    def _do_call(self, provider: dict, model: str, system_prompt: str,
                 user_message: str, max_tokens: int, role: str) -> dict:
        """Execute a single API call. Returns result dict or raises."""
        start = time.perf_counter()
        kwargs: dict = dict(
            model=model,
            max_tokens=max_tokens,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_message},
            ],
        )
        if role == "architect" and self._architect_thinking and provider.get("supports_thinking"):
            thinking_type = (
                self._architect_thinking_mode
                if self._architect_thinking_mode in ("enabled", "thinking_max")
                else "enabled"
            )
            kwargs["extra_body"] = {"thinking": {"type": thinking_type}}

        resp = provider["client"].chat.completions.create(**kwargs)
        elapsed_ms = int((time.perf_counter() - start) * 1000)
        choice = resp.choices[0]

        # For thinking models, content may be in reasoning_content
        text = choice.message.content or ""
        reasoning = getattr(choice.message, "reasoning_content", "") or ""
        if not text and reasoning:
            text = reasoning

        result: dict = {
            "text": text,
            "model": model,
            "provider": provider["name"],
            "role": role,
            "latency_ms": elapsed_ms,
            "usage": {
                "input": resp.usage.prompt_tokens if resp.usage else 0,
                "output": resp.usage.completion_tokens if resp.usage else 0,
            },
        }
        self._remember_provider(provider["name"], model)
        self._record_usage(provider["name"], result["usage"]["output"])
        self._track_usage(model, result["usage"]["input"], result["usage"]["output"])
        if reasoning:
            result["reasoning_content"] = reasoning
        return result

    # ── Sequential call (Plan A: architect review, Plan B: architect chain) ──

    def _call_sequential(self, providers_models: list[tuple[dict, str]],
                         system_prompt: str, user_message: str,
                         max_tokens: int, role: str) -> dict:
        """Call providers sequentially, each reviewing the previous output.

        providers_models: list of (provider, model) tuples in order.
        """
        errors: list[str] = []
        last_result: dict | None = None

        for i, (provider, model) in enumerate(providers_models):
            prompt = system_prompt
            msg = user_message
            if last_result:
                # Add review context
                prev_text = last_result["text"][:4000]
                prompt = (
                    f"{system_prompt}\n\n"
                    f"Review and improve the following output:\n"
                    f"---\n{prev_text}\n---\n"
                    f"Provide your improved version with clear reasoning."
                )
                msg = "Review and improve the previous output."

            try:
                last_result = self._single_call(provider, model, prompt, msg, max_tokens, role)
                last_result["sequential_step"] = i + 1
                last_result["sequential_total"] = len(providers_models)
            except Exception as exc:
                errors.append(f"{provider['name']} ({model}): {exc}")
                # If primary failed, continue to next
                # If reviewer failed, return primary result
                if last_result:
                    last_result["review_skipped"] = True
                    last_result["review_error"] = str(exc)
                    return last_result
                continue

        if last_result:
            return last_result
        return {"error": "All sequential providers failed: " + " | ".join(errors)}

    # ── Parallel call (Plan A: heavy task execution) ──────────────

    def _call_parallel(self, primary: tuple[dict, str],
                       reviewer: tuple[dict, str],
                       system_prompt: str, user_message: str,
                       max_tokens: int, role: str) -> dict:
        """Execute primary and reviewer in parallel, then combine.

        Primary writes code, reviewer checks quality simultaneously.
        """
        results: dict[str, dict | None] = {"primary": None, "reviewer": None}
        errors: list[str] = []

        def _call(label: str, prov: dict, mdl: str) -> dict | None:
            try:
                return self._single_call(prov, mdl, system_prompt, user_message, max_tokens, role)
            except Exception as exc:
                errors.append(f"{label} ({prov['name']} {mdl}): {exc}")
                return None

        with ThreadPoolExecutor(max_workers=2) as pool:
            f_primary = pool.submit(_call, "primary", primary[0], primary[1])
            f_reviewer = pool.submit(_call, "reviewer", reviewer[0], reviewer[1])

            results["primary"] = f_primary.result(timeout=120)
            results["reviewer"] = f_reviewer.result(timeout=120)

        primary_result = results["primary"]
        reviewer_result = results["reviewer"]

        if primary_result:
            if reviewer_result:
                # Combine: primary output + reviewer feedback
                primary_result["review_text"] = reviewer_result.get("text", "")
                primary_result["review_model"] = reviewer_result.get("model", "")
                primary_result["parallel"] = True
            return primary_result

        if reviewer_result:
            reviewer_result["parallel_fallback"] = True
            return reviewer_result

        return {"error": "All parallel providers failed: " + " | ".join(errors)}

    # ── Unified call with intelligent routing ─────────────────────

    def _call_deepseek(self, system_prompt: str, user_message: str,
                       max_tokens: int = 8192, role: str = "executor") -> dict:
        if not self._providers:
            return {"error": "No AI provider available"}

        if role == "architect":
            return self._call_architect_intelligent(system_prompt, user_message, max_tokens)
        else:
            return self._call_executor_intelligent(system_prompt, user_message, max_tokens, user_message)

    def _call_architect_intelligent(self, system_prompt: str, user_message: str,
                                    max_tokens: int) -> dict:
        """PLAN A: deepseek-v4-pro → big-pickle (sequential review)
        PLAN B: big-pickle → deepseek-v4-flash-free (sequential chain)
        """
        full_prompt = self.ARCHITECT_PREFIX + "\n" + system_prompt

        if self._has_api_key:
            # Plan A: Primary = deepseek-v4-pro, Fallback reviewer = big-pickle
            providers_models = []
            # Find deepseek provider
            for p in self._providers_for_role("architect"):
                if p["name"] == "deepseek":
                    providers_models.append((p, self._model_for_provider(p, "architect")))
                    break
            # Find big-pickle as reviewer
            for p in self._providers_for_role("architect"):
                if p["name"] != "deepseek" and p.get("architect_model") == "big-pickle":
                    providers_models.append((p, "big-pickle"))
                    break

            if len(providers_models) >= 2:
                return self._call_sequential(providers_models, full_prompt, user_message, max_tokens, "architect")
            elif providers_models:
                p, m = providers_models[0]
                try:
                    return self._single_call(p, m, full_prompt, user_message, max_tokens, "architect")
                except Exception as exc:
                    return {"error": f"Architect failed: {exc}"}
        else:
            # Plan B: big-pickle analyzes → deepseek-v4-flash-free plans
            providers_models = []
            for p in self._providers_for_role("architect"):
                if p.get("architect_model") == "big-pickle":
                    providers_models.append((p, "big-pickle"))
                    break
            for p in self._providers_for_role("architect"):
                if p.get("architect_model") == "deepseek-v4-flash-free":
                    providers_models.append((p, "deepseek-v4-flash-free"))
                    break

            if len(providers_models) >= 2:
                return self._call_sequential(providers_models, full_prompt, user_message, max_tokens, "architect")
            elif providers_models:
                p, m = providers_models[0]
                try:
                    return self._single_call(p, m, full_prompt, user_message, max_tokens, "architect")
                except Exception as exc:
                    return {"error": f"Architect failed: {exc}"}

        return {"error": "No architect provider available"}

    def _call_executor_intelligent(self, system_prompt: str, user_message: str,
                                   max_tokens: int, raw_task: str) -> dict:
        """PLAN A: deepseek-v4-flash primary, parallel review for heavy tasks
        PLAN B: task-type based routing to specialized free models
        """
        full_prompt = self.EXECUTOR_PREFIX + "\n" + system_prompt
        is_heavy = self._is_heavy_task(raw_task)

        if self._has_api_key:
            # Plan A: Primary = deepseek-v4-flash
            primary_provider = None
            for p in self._providers_for_role("executor"):
                if p["name"] == "deepseek":
                    primary_provider = (p, self._model_for_provider(p, "executor"))
                    break

            if not primary_provider:
                return {"error": "No executor provider available"}

            # For heavy tasks: parallel execution with deepseek-v4-flash-free review
            if is_heavy:
                reviewer_provider = None
                for p in self._providers_for_role("executor"):
                    if p.get("executor_model") == "deepseek-v4-flash-free":
                        reviewer_provider = (p, "deepseek-v4-flash-free")
                        break

                if reviewer_provider:
                    return self._call_parallel(primary_provider, reviewer_provider,
                                              full_prompt, user_message, max_tokens, "executor")

            # Normal task: direct call with fallback chain (deduplicated)
            fallback_models = ["deepseek-v4-flash-free", "nemotron-3-super-free", "big-pickle"]
            return self._call_with_fallback(full_prompt, user_message, max_tokens, "executor",
                                           [primary_provider], fallback_models)
        else:
            # Plan B: task-type based routing
            task_type = self._classify_executor_task(raw_task)
            model_for_type = {
                "coding": "deepseek-v4-flash-free",
                "context": "deepseek-v4-flash-free",
                "logic": "nemotron-3-super-free",
            }
            target_model = model_for_type.get(task_type, "deepseek-v4-flash-free")

            # Find the provider with this model
            for p in self._providers_for_role("executor"):
                if p.get("executor_model") == target_model:
                    try:
                        return self._single_call(p, target_model, full_prompt, user_message, max_tokens, "executor")
                    except Exception as exc:
                        logger.debug("Executor %s failed: %s", target_model, exc)
                        break

            # Fallback to next model in specialization order
            fallback_order = ["deepseek-v4-flash-free", "deepseek-v4-flash-free",
                            "deepseek-v4-flash-free", "nemotron-3-super-free"]
            if target_model in fallback_order:
                fallback_order.remove(target_model)
                fallback_order.insert(0, target_model)

            for model_name in fallback_order:
                for p in self._providers_for_role("executor"):
                    if p.get("executor_model") == model_name:
                        try:
                            return self._single_call(p, model_name, full_prompt, user_message, max_tokens, "executor")
                        except Exception as exc:
                            logger.debug("Executor fallback %s failed: %s", model_name, exc)
                            break

        return {"error": "No AI provider available. Add an API key to continue:\n\n  • DeepSeek (best): /key sk-your-key\n  • Google Gemini (free): /key YOUR_GOOGLE_KEY\n  • Get DeepSeek key: https://platform.deepseek.com\n  • Get Gemini key: https://aistudio.google.com"}

    def _call_with_fallback(self, system_prompt: str, user_message: str,
                            max_tokens: int, role: str,
                            primary_providers: list[tuple[dict, str]],
                            fallback_models: list[str]) -> dict:
        """Try primary providers first, then fallback chain."""
        errors: list[str] = []

        # Try primary providers
        for provider, model in primary_providers:
            try:
                return self._single_call(provider, model, system_prompt, user_message, max_tokens, role)
            except Exception as exc:
                errors.append(f"{provider['name']} ({model}): {exc}")
                logger.debug("Primary %s failed: %s", model, exc)

        # Try fallback models
        for model_name in fallback_models:
            for p in self._providers_for_role(role):
                if p.get("executor_model") == model_name or p.get("architect_model") == model_name:
                    try:
                        return self._single_call(p, model_name, system_prompt, user_message, max_tokens, role)
                    except Exception as exc:
                        errors.append(f"{p['name']} ({model_name}): {exc}")
                        logger.debug("Fallback %s failed: %s", model_name, exc)
                        break

        return {"error": "All AI providers unavailable. Free models are rate-limited or require an API key.\n\nGet started:\n  • /key sk-your-deepseek-key  (best quality)\n  • /key YOUR_GOOGLE_KEY  (free tier)\n  Or wait 60s and try again."}

    # ── Public API ────────────────────────────────────────────────

    def call_architect(self, system_prompt: str, user_message: str,
                       max_tokens: int = 8192) -> dict:
        return self._call_architect_intelligent(system_prompt, user_message, max_tokens)

    def call_executor(self, system_prompt: str, user_message: str,
                      max_tokens: int = 32768) -> dict:
        return self._call_executor_intelligent(system_prompt, user_message, max_tokens, user_message)

    def route(self, task_description: str, system_prompt: str,
              user_message: str) -> dict:
        classification = self.classify(task_description)
        if classification == "architect":
            result = self.call_architect(system_prompt, user_message)
        else:
            result = self.call_executor(system_prompt, user_message)

        if "error" not in result:
            self._memory.log_routing(
                task_type=self.infer_task_type(task_description),
                model_selected=result.get("role", "executor"),
                success_score=1.0,
                latency_ms=result.get("latency_ms", 0),
                tokens_used=(result.get("usage", {}).get("input", 0)
                             + result.get("usage", {}).get("output", 0)),
            )
        return result

    def _is_error_dict(self, result: dict) -> bool:
        return "error" in result

    # ── Cost tracking ─────────────────────────────────────────────

    @property
    def session_tokens(self) -> dict:
        return {"input": self._session_input_tokens,
                "output": self._session_output_tokens}

    @property
    def session_cost(self) -> float:
        return self._session_cost

    @property
    def is_ready(self) -> bool:
        return bool(self._providers)
