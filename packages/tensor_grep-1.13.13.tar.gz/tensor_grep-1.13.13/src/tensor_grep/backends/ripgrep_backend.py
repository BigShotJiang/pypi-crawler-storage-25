import subprocess
from pathlib import Path

from tensor_grep.backends.base import ComputeBackend
from tensor_grep.core.config import SearchConfig
from tensor_grep.core.result import MatchLine, SearchResult


class RipgrepBackend(ComputeBackend):
    """
    A backend that seamlessly delegates to the native `rg` (ripgrep) binary
    when installed on the system. Used for optimal single-threaded small-file
    searching and full parity with complex regex features.
    """

    def is_available(self) -> bool:
        return self._get_binary_name() is not None

    def _get_binary_name(self) -> str | None:
        from tensor_grep.cli.runtime_paths import resolve_ripgrep_binary

        path = resolve_ripgrep_binary()
        return str(path) if path else None

    def supports_pcre2(self) -> bool:
        """Check if the ripgrep binary was compiled with PCRE2 support."""
        binary = self._get_binary_name()
        if not binary:
            return False
        try:
            # Check help output or version info for PCRE2 support
            result = subprocess.run([binary, "--help"], capture_output=True, text=True)
            if "--pcre2" in result.stdout or "PCRE2" in result.stdout:
                # Also do a quick smoke test to be sure
                test_proc = subprocess.run(
                    [binary, "-P", "a(?=b)", "-V"], capture_output=True, text=True
                )
                return test_proc.returncode == 0
            return False
        except Exception:
            return False

    def search(
        self, file_path: str | list[str], pattern: str, config: SearchConfig | None = None
    ) -> SearchResult:
        if config and (config.count or config.count_matches):
            return self._search_counts(file_path=file_path, pattern=pattern, config=config)
        if config and config.files_with_matches:
            return self._search_files_with_matches(
                file_path=file_path, pattern=pattern, config=config
            )

        cmd = self._build_cmd(file_path=file_path, pattern=pattern, config=config, json_mode=True)
        try:
            # We use check=False because rg exits with 1 if no matches are found
            result = subprocess.run(
                cmd, capture_output=True, text=True, check=False, encoding="utf-8"
            )
            if result.returncode > 1:
                stderr = result.stderr.strip()
                raise RuntimeError(
                    f"rg failed with exit code {result.returncode}: {stderr or 'no stderr output'}"
                )

            import json

            matches = []

            for line in result.stdout.splitlines():
                if not line.strip():
                    continue
                try:
                    data = json.loads(line)
                    if data.get("type") == "match":
                        data_match = data["data"]
                        line_number = data_match.get("line_number", 0)
                        # We extract the pure text matched line
                        text = data_match.get("lines", {}).get("text", "").rstrip("\n\r")

                        path_str = data_match.get("path", {}).get("text", "")
                        if not path_str and isinstance(file_path, str):
                            path_str = file_path

                        # Note: Ripgrep JSON also outputs absolute offsets, but MatchLine requires line_num/text
                        matches.append(MatchLine(line_number=line_number, text=text, file=path_str))
                    elif data.get("type") == "context":
                        data_match = data["data"]
                        line_number = data_match.get("line_number", 0)
                        text = data_match.get("lines", {}).get("text", "").rstrip("\n\r")
                        path_str = data_match.get("path", {}).get("text", "")
                        if not path_str and isinstance(file_path, str):
                            path_str = file_path
                        matches.append(MatchLine(line_number=line_number, text=text, file=path_str))
                except json.JSONDecodeError:
                    pass

            files_set = {m.file for m in matches}

            return SearchResult(
                matches=matches,
                total_files=len(files_set),
                total_matches=len(matches),
                routing_backend="RipgrepBackend",
                routing_reason="rg_json",
                routing_distributed=False,
                routing_worker_count=1,
            )

        except Exception as e:
            raise RuntimeError(f"Ripgrep backend failed: {e}") from e

    def _search_files_with_matches(
        self, file_path: str | list[str], pattern: str, config: SearchConfig
    ) -> SearchResult:
        cmd = self._build_cmd(file_path=file_path, pattern=pattern, config=config, json_mode=False)
        try:
            result = subprocess.run(
                cmd, capture_output=True, text=True, check=False, encoding="utf-8"
            )
            if result.returncode > 1:
                stderr = result.stderr.strip()
                raise RuntimeError(
                    f"rg failed with exit code {result.returncode}: {stderr or 'no stderr output'}"
                )

            path_parts = result.stdout.split("\0") if config.null else result.stdout.splitlines()
            matched_file_paths = [path for path in path_parts if path]
            return SearchResult(
                matches=[],
                matched_file_paths=matched_file_paths,
                match_counts_by_file=dict.fromkeys(matched_file_paths, 1),
                total_files=len(matched_file_paths),
                total_matches=len(matched_file_paths),
                routing_backend="RipgrepBackend",
                routing_reason="rg_files_with_matches",
                routing_distributed=False,
                routing_worker_count=1,
            )
        except Exception as e:
            raise RuntimeError(f"Ripgrep backend failed: {e}") from e

    def _search_counts(
        self, file_path: str | list[str], pattern: str, config: SearchConfig
    ) -> SearchResult:
        cmd = self._build_cmd(file_path=file_path, pattern=pattern, config=config, json_mode=False)
        try:
            result = subprocess.run(
                cmd, capture_output=True, text=True, check=False, encoding="utf-8"
            )
            if result.returncode > 1:
                stderr = result.stderr.strip()
                raise RuntimeError(
                    f"rg failed with exit code {result.returncode}: {stderr or 'no stderr output'}"
                )

            lines = [line.strip() for line in result.stdout.splitlines() if line.strip()]
            total_matches = 0
            total_files = 0
            matched_file_paths: list[str] = []
            match_counts_by_file: dict[str, int] = {}

            multi_file = (
                (isinstance(file_path, (list, tuple)) and len(file_path) > 1)
                or (isinstance(file_path, str) and Path(file_path).is_dir())
                or (
                    isinstance(file_path, (list, tuple))
                    and len(file_path) == 1
                    and Path(file_path[0]).is_dir()
                )
            )
            for line in lines:
                matched_path: str | None = None
                if config.null and "\0" in line:
                    matched_path, count_text = line.rsplit("\0", 1)
                elif multi_file and ":" in line:
                    matched_path, count_text = line.rsplit(":", 1)
                else:
                    count_text = line
                try:
                    count_value = int(count_text.strip())
                except ValueError:
                    continue
                total_matches += count_value
                if count_value > 0:
                    total_files += 1
                    if matched_path:
                        matched_file_paths.append(matched_path)
                        match_counts_by_file[matched_path] = count_value
                    elif isinstance(file_path, str):
                        matched_file_paths.append(file_path)
                        match_counts_by_file[file_path] = count_value

            routing_reason = "rg_count_matches" if config.count_matches else "rg_count"
            return SearchResult(
                matches=[],
                matched_file_paths=matched_file_paths,
                match_counts_by_file=match_counts_by_file,
                total_files=total_files,
                total_matches=total_matches,
                routing_backend="RipgrepBackend",
                routing_reason=routing_reason,
                routing_distributed=False,
                routing_worker_count=1,
            )
        except Exception as e:
            raise RuntimeError(f"Ripgrep backend failed: {e}") from e

    def search_passthrough(
        self, file_path: str | list[str], pattern: str, config: SearchConfig | None = None
    ) -> int:
        """
        Execute ripgrep directly and stream output to stdout/stderr without JSON re-parsing.
        Returns rg's native exit code.
        """
        cmd = self._build_cmd(
            file_path=file_path,
            pattern=pattern,
            config=config,
            json_mode=bool(config and config.json_mode),
        )
        result = subprocess.run(cmd, check=False)
        return int(result.returncode)

    def _build_cmd(
        self,
        file_path: str | list[str],
        pattern: str,
        config: SearchConfig | None,
        *,
        json_mode: bool,
    ) -> list[str]:
        binary_name = self._get_binary_name()
        if binary_name is None:
            raise RuntimeError("RipgrepBackend requires the 'rg' binary to be installed.")

        cmd: list[str] = [binary_name]
        if json_mode:
            cmd.append("--json")

        # We enforce JSON output so we can seamlessly parse it back into our SearchResult dataclasses
        if config:
            if config.ignore_case:
                cmd.append("-i")
            if config.case_sensitive:
                cmd.append("-s")
            if config.invert_match:
                cmd.append("-v")
            if config.no_invert_match:
                cmd.append("--no-invert-match")
            if config.word_regexp:
                cmd.append("-w")
            if config.line_regexp:
                cmd.append("-x")
            if config.fixed_strings:
                cmd.append("-F")
            if config.no_fixed_strings:
                cmd.append("--no-fixed-strings")
            if config.crlf:
                cmd.append("--crlf")
            if config.no_crlf:
                cmd.append("--no-crlf")
            if config.encoding != "auto":
                cmd.extend(["--encoding", config.encoding])
            if config.no_encoding:
                cmd.append("--no-encoding")
            if not config.mmap:
                cmd.append("--no-mmap")
            if config.no_mmap:
                cmd.append("--no-mmap")
            if config.multiline:
                cmd.append("--multiline")
            if config.no_multiline:
                cmd.append("--no-multiline")
            if config.multiline_dotall:
                cmd.append("--multiline-dotall")
            if config.no_multiline_dotall:
                cmd.append("--no-multiline-dotall")
            if config.auto_hybrid_regex:
                cmd.append("--auto-hybrid-regex")
            if config.no_auto_hybrid_regex:
                cmd.append("--no-auto-hybrid-regex")
            if config.unicode:
                cmd.append("--unicode")
            if config.pcre2_unicode:
                cmd.append("--pcre2-unicode")
            if config.no_pcre2_unicode:
                cmd.append("--no-pcre2-unicode")
            if config.no_unicode:
                cmd.append("--no-unicode")
            if config.ignore:
                cmd.append("--ignore")
            if config.no_ignore:
                cmd.append("--no-ignore")
            if config.ignore_dot:
                cmd.append("--ignore-dot")
            if config.no_ignore_dot:
                cmd.append("--no-ignore-dot")
            if config.ignore_exclude:
                cmd.append("--ignore-exclude")
            if config.no_ignore_exclude:
                cmd.append("--no-ignore-exclude")
            if config.ignore_files:
                cmd.append("--ignore-files")
            if config.no_ignore_files:
                cmd.append("--no-ignore-files")
            if config.ignore_global:
                cmd.append("--ignore-global")
            if config.no_ignore_global:
                cmd.append("--no-ignore-global")
            if config.ignore_parent:
                cmd.append("--ignore-parent")
            if config.no_ignore_parent:
                cmd.append("--no-ignore-parent")
            if config.ignore_vcs:
                cmd.append("--ignore-vcs")
            if config.no_ignore_vcs:
                cmd.append("--no-ignore-vcs")
            if config.no_require_git:
                cmd.append("--no-require-git")
            if config.require_git:
                cmd.append("--require-git")
            if config.one_file_system:
                cmd.append("--one-file-system")
            if config.no_one_file_system:
                cmd.append("--no-one-file-system")
            if config.ignore_file:
                for ignore_path in config.ignore_file:
                    cmd.extend(["--ignore-file", ignore_path])
            if config.ignore_file_case_insensitive:
                cmd.append("--ignore-file-case-insensitive")
            if config.no_ignore_file_case_insensitive:
                cmd.append("--no-ignore-file-case-insensitive")
            if config.max_depth is not None:
                cmd.extend(["--max-depth", str(config.max_depth)])
            if config.no_config:
                cmd.append("--no-config")
            if config.only_matching:
                cmd.append("-o")
            if config.text:
                cmd.append("-a")
            if config.no_text:
                cmd.append("--no-text")
            if config.binary and not config.text:
                cmd.append("--binary")
            if config.no_binary:
                cmd.append("--no-binary")
            if config.hidden:
                cmd.append("--hidden")
            if config.no_hidden:
                cmd.append("--no-hidden")
            if config.follow:
                cmd.append("--follow")
            if config.no_follow:
                cmd.append("--no-follow")
            if config.line_number is not None and not json_mode:
                if config.line_number:
                    cmd.append("-n")
                else:
                    cmd.append("--no-line-number")
            if config.column and not json_mode:
                cmd.append("--column")
            if config.no_column and not json_mode:
                cmd.append("--no-column")
            if config.path_separator is not None and not json_mode:
                cmd.extend(["--path-separator", config.path_separator])
            if config.vimgrep and not json_mode:
                cmd.append("--vimgrep")
            if config.null and not json_mode:
                cmd.append("-0")
            if config.color:
                cmd.extend(["--color", config.color])
            if config.glob_case_insensitive:
                cmd.append("--glob-case-insensitive")
            if config.no_glob_case_insensitive:
                cmd.append("--no-glob-case-insensitive")
            if config.glob:
                for glob in config.glob:
                    cmd.extend(["-g", glob])
            if config.iglob:
                for glob in config.iglob:
                    cmd.extend(["--iglob", glob])
            if config.file_type:
                for file_type in config.file_type:
                    cmd.extend(["-t", file_type])
            if config.type_not:
                for file_type in config.type_not:
                    cmd.extend(["-T", file_type])
            if config.type_add:
                for type_spec in config.type_add:
                    cmd.extend(["--type-add", type_spec])
            if config.type_clear:
                cmd.extend(["--type-clear", config.type_clear])

            if config.context is not None:
                cmd.extend(["-C", str(config.context)])
            else:
                if config.before_context is not None:
                    cmd.extend(["-B", str(config.before_context)])
                if config.after_context is not None:
                    cmd.extend(["-A", str(config.after_context)])

            if config.max_count is not None:
                cmd.extend(["-m", str(config.max_count)])
            if config.count:
                cmd.append("-c")
            if config.count_matches:
                cmd.append("--count-matches")
            if config.files_with_matches and not (config.count or config.count_matches):
                cmd.append("--files-with-matches")
            if config.files_without_match:
                cmd.append("--files-without-match")
            if config.replace_str is not None and not json_mode:
                cmd.extend(["--replace", config.replace_str])
            if config.passthru and not json_mode:
                cmd.append("--passthru")
            if config.block_buffered and not json_mode:
                cmd.append("--block-buffered")
            if config.no_block_buffered and not json_mode:
                cmd.append("--no-block-buffered")
            if config.byte_offset and not json_mode:
                cmd.append("-b")
            if config.no_byte_offset and not json_mode:
                cmd.append("--no-byte-offset")
            if config.colors and not json_mode:
                for color_spec in config.colors:
                    cmd.extend(["--colors", color_spec])
            if config.context_separator != "--" and not json_mode:
                cmd.extend(["--context-separator", config.context_separator])
            if config.no_context_separator and not json_mode:
                cmd.append("--no-context-separator")
            if config.field_context_separator != "-" and not json_mode:
                cmd.extend(["--field-context-separator", config.field_context_separator])
            if config.field_match_separator != ":" and not json_mode:
                cmd.extend(["--field-match-separator", config.field_match_separator])
            if not config.heading and not json_mode:
                cmd.append("--no-heading")
            if config.include_zero and not json_mode:
                cmd.append("--include-zero")
            if config.no_include_zero and not json_mode:
                cmd.append("--no-include-zero")
            if config.line_buffered and not json_mode:
                cmd.append("--line-buffered")
            if config.no_line_buffered and not json_mode:
                cmd.append("--no-line-buffered")
            if config.max_columns is not None and not json_mode:
                cmd.extend(["--max-columns", str(config.max_columns)])
            if config.max_columns_preview and not json_mode:
                cmd.append("--max-columns-preview")
            if config.no_max_columns_preview and not json_mode:
                cmd.append("--no-max-columns-preview")
            if config.sort_by != "none" and not json_mode:
                cmd.extend(["--sort", config.sort_by])
            if config.sort_files and not json_mode:
                cmd.append("--sort-files")
            if config.sort_by_reverse != "none" and not json_mode:
                cmd.extend(["--sortr", config.sort_by_reverse])
            if config.trim and not json_mode:
                cmd.append("--trim")
            if config.no_trim and not json_mode:
                cmd.append("--no-trim")
            if config.with_filename and not json_mode:
                cmd.append("--with-filename")
            if config.no_filename and not json_mode:
                cmd.append("--no-filename")
            if config.debug:
                cmd.append("--debug")
            if config.trace:
                cmd.append("--trace")
            if config.stats:
                cmd.append("--stats")
            if config.no_stats:
                cmd.append("--no-stats")
            if config.ignore_messages:
                cmd.append("--ignore-messages")
            if config.no_ignore_messages:
                cmd.append("--no-ignore-messages")
            if config.no_messages:
                cmd.append("--no-messages")
            if config.messages:
                cmd.append("--messages")
            if config.pcre2:
                cmd.append("-P")
            if config.no_pcre2:
                cmd.append("--no-pcre2")
            if config.pre:
                cmd.extend(["--pre", config.pre])
            if config.no_pre:
                cmd.append("--no-pre")
            if config.pre_glob:
                for glob in config.pre_glob:
                    cmd.extend(["--pre-glob", glob])
            if config.search_zip:
                cmd.append("--search-zip")
            if config.no_search_zip:
                cmd.append("--no-search-zip")
            if config.no_json:
                cmd.append("--no-json")
            if config.max_filesize:
                cmd.extend(["--max-filesize", config.max_filesize])
            if config.threads > 0:
                cmd.extend(["-j", str(config.threads)])
            if config.list_files:
                cmd.append("--files")
                if isinstance(file_path, list):
                    cmd.extend(file_path)
                else:
                    cmd.append(file_path)
                return cmd

        pattern_files = list(config.file_patterns or []) if config else []
        for pattern_file in pattern_files:
            cmd.extend(["--file", pattern_file])
        patterns = list(config.regexp or []) if config and config.regexp else []
        if not pattern_files:
            patterns = patterns or [pattern]
        for current_pattern in patterns:
            if len(patterns) > 1 or current_pattern.startswith("-"):
                cmd.extend(["-e", current_pattern])
            else:
                cmd.append(current_pattern)
        if isinstance(file_path, list):
            cmd.extend(file_path)
        else:
            cmd.append(file_path)
        return cmd
