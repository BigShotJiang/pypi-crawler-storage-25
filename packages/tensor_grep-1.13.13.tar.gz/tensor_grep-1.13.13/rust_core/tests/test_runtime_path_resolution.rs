use std::fs;
use std::path::{Path, PathBuf};
use std::process::{Command, Output};
use std::sync::mpsc;
use std::thread;
use std::time::Duration;
#[cfg(unix)]
use std::time::Instant;

use tempfile::tempdir;

fn repo_root() -> PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .unwrap()
        .to_path_buf()
}

fn repo_python() -> PathBuf {
    let candidate = repo_root().join(".venv").join("Scripts").join("python.exe");
    if candidate.exists() {
        return candidate;
    }

    repo_root().join(".venv").join("bin").join("python")
}

fn run_with_timeout(mut command: Command, timeout: Duration) -> Output {
    let (tx, rx) = mpsc::channel();
    thread::spawn(move || {
        let _ = tx.send(command.output());
    });

    match rx.recv_timeout(timeout) {
        Ok(Ok(output)) => output,
        Ok(Err(err)) => panic!("command failed: {err}"),
        Err(_) => panic!("command timed out after {timeout:?}"),
    }
}

fn write_sample_log(dir: &Path) -> PathBuf {
    let file_path = dir.join("sample.log");
    fs::write(&file_path, "INFO ok\nERROR database failed\n").unwrap();
    file_path
}

fn configure_classify_env(command: &mut Command) {
    command
        .env("TENSOR_GREP_TRITON_TIMEOUT_SECONDS", "0.01")
        .env("HF_HUB_OFFLINE", "1")
        .env("TRANSFORMERS_OFFLINE", "1");
}

fn write_sidecar_probe_script(dir: &Path) -> PathBuf {
    let script = if cfg!(windows) {
        dir.join("sidecar_probe.py")
    } else {
        dir.join("sidecar_probe")
    };

    fs::write(
        &script,
        "import json\n"
            .to_string()
            + "import os\n"
            + "import sys\n"
            + "sys.stdin.buffer.read()\n"
            + "sys.stdout.write(json.dumps({\"stdout\": \"\", \"stderr\": \"\", \"exit_code\": 0, \"pid\": os.getpid()}))\n",
    )
    .unwrap();

    script
}

fn write_wrapper_script(dir: &Path, file_name: &str, body: &str) -> PathBuf {
    let script = dir.join(file_name);
    fs::write(&script, body).unwrap();

    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;

        let mut permissions = fs::metadata(&script).unwrap().permissions();
        permissions.set_mode(0o755);
        fs::set_permissions(&script, permissions).unwrap();
    }

    script
}

fn python_wrapper_script(dir: &Path, marker: &Path) -> PathBuf {
    let python = repo_python();

    if cfg!(windows) {
        write_wrapper_script(
            dir,
            "python-wrapper.cmd",
            &format!(
                "@echo off\r\necho python-override>>\"{}\"\r\n\"{}\" %*\r\n",
                marker.display(),
                python.display()
            ),
        )
    } else {
        write_wrapper_script(
            dir,
            "python-wrapper.sh",
            &format!(
                "#!/bin/sh\nprintf 'python-override\\n' >> '{}'\nexec '{}' \"$@\"\n",
                marker.display(),
                python.display()
            ),
        )
    }
}

fn python_passthrough_wrapper_script(dir: &Path, marker: &Path) -> PathBuf {
    if cfg!(windows) {
        write_wrapper_script(
            dir,
            "python-passthrough-wrapper.cmd",
            &format!(
                "@echo off\r\necho python-passthrough>>\"{}\"\r\nexit /b 0\r\n",
                marker.display()
            ),
        )
    } else {
        write_wrapper_script(
            dir,
            "python-passthrough-wrapper.sh",
            &format!(
                "#!/bin/sh\nprintf 'python-passthrough\\n' >> '{}'\nexit 0\n",
                marker.display()
            ),
        )
    }
}

fn pythonpath_validating_passthrough_wrapper_script(
    dir: &Path,
    marker: &Path,
    expected_src: &Path,
) -> PathBuf {
    if cfg!(windows) {
        write_wrapper_script(
            dir,
            "pythonpath-validating-wrapper.cmd",
            &format!(
                "@echo off\r\nsetlocal\r\nset \"CURRENT=%PYTHONPATH%\"\r\nset \"EXPECTED={}\"\r\necho %CURRENT%>\"{}\"\r\ncall set \"FOUND=%%CURRENT:%EXPECTED%=%%\"\r\nif \"%FOUND%\"==\"%CURRENT%\" exit /b 1\r\necho Usage: tensor_grep defs\r\nexit /b 0\r\n",
                expected_src.display(),
                marker.display()
            ),
        )
    } else {
        write_wrapper_script(
            dir,
            "pythonpath-validating-wrapper.sh",
            &format!(
                "#!/bin/sh\nprintf '%s' \"$PYTHONPATH\" > '{}'\nprintf '%s' \"$PYTHONPATH\" | grep -F -- '{}' >/dev/null || exit 1\nprintf 'Usage: tensor_grep defs\\n'\nexit 0\n",
                marker.display(),
                expected_src.display()
            ),
        )
    }
}

fn rg_wrapper_script(dir: &Path, marker: &Path) -> PathBuf {
    if cfg!(windows) {
        write_wrapper_script(
            dir,
            "rg-wrapper.cmd",
            &format!(
                "@echo off\r\necho rg-override>>\"{}\"\r\necho TG_RG_OVERRIDE_SENTINEL\r\n",
                marker.display()
            ),
        )
    } else {
        write_wrapper_script(
            dir,
            "rg-wrapper.sh",
            &format!(
                "#!/bin/sh\nprintf 'rg-override\\n' >> '{}'\nprintf 'TG_RG_OVERRIDE_SENTINEL\\n'\n",
                marker.display()
            ),
        )
    }
}

#[test]
fn test_help_documents_runtime_override_env_vars() {
    let mut tg = Command::new(env!("CARGO_BIN_EXE_tg"));
    tg.current_dir(repo_root()).arg("--help");
    let output = run_with_timeout(tg, Duration::from_secs(5));

    assert!(output.status.success());
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("TG_SIDECAR_PYTHON"), "stdout={stdout}");
    assert!(stdout.contains("TG_NATIVE_TG_BINARY"), "stdout={stdout}");
    assert!(stdout.contains("TG_RG_PATH"), "stdout={stdout}");
    assert!(stdout.contains("TG_FORCE_CPU"), "stdout={stdout}");
    assert!(stdout.contains("TG_SIDECAR_TIMEOUT_MS"), "stdout={stdout}");
    assert!(stdout.contains("TENSOR_GREP_DEVICE_IDS"), "stdout={stdout}");
    assert!(
        stdout.contains("TENSOR_GREP_CLASSIFY_PROVIDER"),
        "stdout={stdout}"
    );
    assert!(
        stdout.contains("TENSOR_GREP_TRITON_TIMEOUT_SECONDS"),
        "stdout={stdout}"
    );
    for expected in ["--smart-case", "--hidden", "--max-depth", "--text"] {
        assert!(stdout.contains(expected), "stdout={stdout}");
    }
    assert!(stdout.contains("repair-launcher"), "stdout={stdout}");
    assert!(stdout.contains("--allow-foreign-rename"), "stdout={stdout}");
    let normalized_stdout = stdout.split_whitespace().collect::<Vec<_>>().join(" ");
    let normalized_lower = normalized_stdout.to_lowercase();
    assert!(
        normalized_stdout.contains("native GPU falls back"),
        "stdout={stdout}"
    );
    assert!(
        normalized_lower.contains("validated common")
            && normalized_lower.contains("compatible subset"),
        "stdout={stdout}"
    );
    assert!(
        normalized_stdout.contains("--format rg --json"),
        "stdout={stdout}"
    );
}

#[test]
fn test_run_help_positions_ast_as_validated_slice_not_ast_grep_parity() {
    let mut tg = Command::new(env!("CARGO_BIN_EXE_tg"));
    tg.current_dir(repo_root()).arg("run").arg("--help");
    let output = run_with_timeout(tg, Duration::from_secs(5));

    assert!(output.status.success());
    let stdout = String::from_utf8_lossy(&output.stdout);
    let normalized_stdout = stdout.split_whitespace().collect::<Vec<_>>().join(" ");
    assert!(
        normalized_stdout.contains("validated AST slice"),
        "stdout={stdout}"
    );
    assert!(stdout.contains("--pattern"), "stdout={stdout}");
    assert!(stdout.contains("--files-with-matches"), "stdout={stdout}");
    assert!(stdout.contains("--selector"), "stdout={stdout}");
    assert!(stdout.contains("--strictness"), "stdout={stdout}");
    assert!(stdout.contains("--stdin"), "stdout={stdout}");
    assert!(stdout.contains("--globs"), "stdout={stdout}");
    assert!(!stdout.contains("ast-grep parity"), "stdout={stdout}");
    assert!(!stdout.contains("ast-grep replacement"), "stdout={stdout}");
}

#[test]
fn test_tg_classify_uses_tg_sidecar_python_override() {
    let dir = tempdir().unwrap();
    let file_path = write_sample_log(dir.path());
    let marker = dir.path().join("python-marker.txt");
    let python_wrapper = python_wrapper_script(dir.path(), &marker);
    let sidecar_script = write_sidecar_probe_script(dir.path());

    let mut tg = Command::new(env!("CARGO_BIN_EXE_tg"));
    tg.current_dir(repo_root())
        .arg("classify")
        .arg(&file_path)
        .env("TG_SIDECAR_PYTHON", &python_wrapper)
        .env("TG_SIDECAR_SCRIPT", &sidecar_script);

    let output = run_with_timeout(tg, Duration::from_secs(20));

    assert!(
        output.status.success(),
        "status={:?}\nstdout={}\nstderr={}",
        output.status.code(),
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    assert!(
        marker.exists(),
        "expected override wrapper marker at {}",
        marker.display()
    );
}

#[test]
fn test_tg_upgrade_uses_python_passthrough_override() {
    let dir = tempdir().unwrap();
    let marker = dir.path().join("python-upgrade-marker.txt");
    let python_wrapper = python_passthrough_wrapper_script(dir.path(), &marker);

    let mut tg = Command::new(env!("CARGO_BIN_EXE_tg"));
    tg.current_dir(repo_root())
        .arg("upgrade")
        .env("TG_SIDECAR_PYTHON", &python_wrapper);

    let output = run_with_timeout(tg, Duration::from_secs(10));

    assert!(
        output.status.success(),
        "status={:?}\nstdout={}\nstderr={}",
        output.status.code(),
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    assert!(
        marker.exists(),
        "expected passthrough override marker at {}",
        marker.display()
    );
}

#[test]
fn test_tg_update_alias_uses_python_passthrough_override() {
    let dir = tempdir().unwrap();
    let marker = dir.path().join("python-update-marker.txt");
    let python_wrapper = python_passthrough_wrapper_script(dir.path(), &marker);

    let mut tg = Command::new(env!("CARGO_BIN_EXE_tg"));
    tg.current_dir(repo_root())
        .arg("update")
        .env("TG_SIDECAR_PYTHON", &python_wrapper);

    let output = run_with_timeout(tg, Duration::from_secs(10));

    assert!(
        output.status.success(),
        "status={:?}\nstdout={}\nstderr={}",
        output.status.code(),
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    assert!(
        marker.exists(),
        "expected passthrough override marker at {}",
        marker.display()
    );
}

#[test]
fn test_tg_defs_help_injects_repo_src_into_pythonpath_for_passthrough() {
    let dir = tempdir().unwrap();
    let marker = dir.path().join("pythonpath-marker.txt");
    let expected_src = repo_root().join("src");
    let python_wrapper =
        pythonpath_validating_passthrough_wrapper_script(dir.path(), &marker, &expected_src);

    let mut tg = Command::new(env!("CARGO_BIN_EXE_tg"));
    tg.current_dir(repo_root())
        .arg("defs")
        .arg("--help")
        .env("TG_SIDECAR_PYTHON", &python_wrapper);

    let output = run_with_timeout(tg, Duration::from_secs(10));

    assert!(
        output.status.success(),
        "status={:?}\nstdout={}\nstderr={}",
        output.status.code(),
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );

    let combined = format!(
        "{}{}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    assert!(
        combined.to_lowercase().contains("usage:"),
        "combined={combined}"
    );

    let injected_pythonpath = fs::read_to_string(&marker).unwrap();
    assert!(
        injected_pythonpath.contains(expected_src.to_string_lossy().as_ref()),
        "pythonpath={injected_pythonpath}"
    );
}

#[cfg(unix)]
#[test]
fn test_search_help_timeout_fallback_terminates_passthrough_process_tree() {
    let dir = tempdir().unwrap();
    let wrapper = write_wrapper_script(
        dir.path(),
        "sleeping-help-wrapper.sh",
        "#!/bin/sh\nsleep 5\n",
    );

    let mut tg = Command::new(env!("CARGO_BIN_EXE_tg"));
    tg.current_dir(repo_root())
        .arg("search")
        .arg("--help")
        .env("TG_SIDECAR_PYTHON", &wrapper);

    let started = Instant::now();
    let output = run_with_timeout(tg, Duration::from_secs(10));
    let elapsed = started.elapsed();

    assert!(
        output.status.success(),
        "status={:?}\nstdout={}\nstderr={}",
        output.status.code(),
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    assert!(
        elapsed < Duration::from_secs(4),
        "public help timeout fallback took too long: {elapsed:?}"
    );

    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.to_lowercase().contains("usage:"), "stdout={stdout}");
    assert!(stdout.contains("search"), "stdout={stdout}");
}

#[test]
fn test_tg_search_uses_tg_rg_path_override_for_rg_fallback() {
    let dir = tempdir().unwrap();
    let file_path = write_sample_log(dir.path());
    let marker = dir.path().join("rg-marker.txt");
    let rg_wrapper = rg_wrapper_script(dir.path(), &marker);

    let mut tg = Command::new(env!("CARGO_BIN_EXE_tg"));
    tg.current_dir(repo_root())
        .arg("search")
        .arg("ERROR")
        .arg(&file_path)
        .env("TG_RG_PATH", &rg_wrapper)
        .env(
            "TG_TEST_NATIVE_SEARCH_FORCE_ERROR",
            "synthetic native CPU failure",
        );

    let output = run_with_timeout(tg, Duration::from_secs(10));

    assert!(
        output.status.success(),
        "status={:?}\nstdout={}\nstderr={}",
        output.status.code(),
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );

    let stdout = String::from_utf8_lossy(&output.stdout);
    assert_eq!(stdout.trim(), "TG_RG_OVERRIDE_SENTINEL", "stdout={stdout}");
    assert!(
        marker.exists(),
        "expected override wrapper marker at {}",
        marker.display()
    );
}

#[test]
fn test_tg_search_warns_when_tg_rg_path_override_is_missing() {
    let dir = tempdir().unwrap();
    let file_path = write_sample_log(dir.path());

    let mut tg = Command::new(env!("CARGO_BIN_EXE_tg"));
    tg.current_dir(repo_root())
        .arg("search")
        .arg("ERROR")
        .arg(&file_path)
        .env("TG_RG_PATH", dir.path().join("missing-rg.exe"))
        .env(
            "TG_TEST_NATIVE_SEARCH_FORCE_ERROR",
            "synthetic native CPU failure",
        );

    let output = run_with_timeout(tg, Duration::from_secs(10));
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(stderr.contains("TG_RG_PATH"), "stderr={stderr}");
    assert!(stderr.contains("is not a file"), "stderr={stderr}");
    if !output.status.success() {
        assert!(
            stderr.contains("native CPU search failed")
                || stderr.contains("synthetic native CPU failure"),
            "status={:?}\nstdout={}\nstderr={stderr}",
            output.status.code(),
            String::from_utf8_lossy(&output.stdout),
        );
    }
}

#[test]
fn test_tg_classify_warns_when_tg_sidecar_python_override_is_missing() {
    let dir = tempdir().unwrap();
    let file_path = write_sample_log(dir.path());
    let sidecar_script = write_sidecar_probe_script(dir.path());

    let mut tg = Command::new(env!("CARGO_BIN_EXE_tg"));
    tg.current_dir(repo_root())
        .arg("classify")
        .arg(&file_path)
        .env("TG_SIDECAR_PYTHON", dir.path().join("missing-python.exe"))
        .env("TG_SIDECAR_SCRIPT", &sidecar_script);
    configure_classify_env(&mut tg);

    let output = run_with_timeout(tg, Duration::from_secs(20));

    assert!(
        output.status.success(),
        "status={:?}\nstdout={}\nstderr={}",
        output.status.code(),
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );

    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(stderr.contains("TG_SIDECAR_PYTHON"), "stderr={stderr}");
    assert!(stderr.contains("is not a file"), "stderr={stderr}");
}
