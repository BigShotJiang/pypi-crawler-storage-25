"""Variant classes."""

__all__ = [
    'CALL_SOURCE',
    'REF_TRACE_COLUMNS',
    'Variant',
    'InsertionVariant',
    # 'TandemDuplicationVariant',
    'DeletionVariant',
    'InversionVariant',
    'ComplexVariant',
    'NullVariant',
    'PatchVariant',
    'DevVariant'
]

from abc import ABC
import polars as pl
from typing import Any, Optional

import Bio.Seq

from ..anno import perfect_homology
from ..region import Region
from ..inv import get_inv_qry_regions

from .interval import (
    AnchoredInterval,
    gap_sum_score,
    unaligned_switch_sum_score,
)
from .resources import CallerResources
from .region_kde import VarRegionKde
from .struct import get_ref_trace, smooth_ref_trace, qry_trace_str, ref_trace_str


CALL_SOURCE: str = 'INTER'
"""Variant call source column value."""

_REF_TRACE_COLUMNS_PRE = ['#CHROM', 'POS', 'END', 'DEPTH', 'QRY_ID', 'INDEX']
"""Head reference trace columns."""

_REF_TRACE_COLUMNS_POST = ['FWD_COUNT', 'REV_COUNT', 'TYPE', 'LEN']
"""Tail reference trace columns."""

REF_TRACE_COLUMNS = _REF_TRACE_COLUMNS_PRE + _REF_TRACE_COLUMNS_POST
"""Reference trace columns."""


class Variant(ABC):
    """Base class for variant call objects.

    :ivar interval: Variant interval. Only Null in NullVariant.
    :ivar caller_resources: Caller resources. Only Null in NullVariant.
    :ivar var_region_kde: Variant region KDE. Only Null in NullVariant.
    :ivar region_ref: Reference region. Only Null in NullVariant. Initialized to interval.region_ref, may be altered by
        variant call.
    :ivar region_qry: Query region. Only Null in NullVariant. Initialized to interval.region_qry, may be altered by
        variant call.
    :ivar region_ref_qrytrim: Reference region trimmed by query. Initially set to region_ref, but may be altered by
        the variant call. It is stored here to preserve the original reference region if it is changed.
    :ivar vartype: Variant type.
    :ivar varsubtype: Variant subtype (e.g. TANDEM).
    :ivar varlen: Variant length.
    :ivar filter_set: Set of filter strings initialized to alignment filters.
    :ivar call_source: Type of evidence supporting the variant call.
    :ivar var_score: Variant score.
    :ivar templ_res: Template resolution flag. Set to True if a variant is aligned across segments and False if variant
        segments are unaligned. Common in complex variants, smaller template switches are left unaligned.
    :ivar seq: Variant sequence.
    :ivar is_patch: Variant is a patch variant. It does not represent a variant call, but should be traversed during
        graph resolution.
    :ivar start_index: Start index of the variant in the alignment table.
    :ivar end_index: End index of the variant in the alignment table.
    :ivar df_ref_trace: Reference trace table set by complex variants (None if not complex).
    :ivar var_index: Set on variant objects to track order and give them a unique index. This is set externally, not by
        variant classes. The PAV variant caller assigns each complex variant a unique index linking it to a
        table of reference and segment traces. With this key, df_ref_trace and df_segment from each variant are
        concatenated into one trace table and one segment table for multiple variant calls, and this index is a
        unique key between the variant table and the concatenated tables.
    """

    interval: Optional[AnchoredInterval]
    caller_resources: Optional[CallerResources]
    var_region_kde: Optional[VarRegionKde]
    region_ref: Optional[Region]
    region_qry: Optional[Region]
    region_ref_qrytrim: Optional[Region]
    vartype: str
    varsubtype: Optional[str]
    varlen: int
    filter_set: set[str]
    call_source: str
    var_score: float
    templ_res: bool
    seq: Optional[str]
    is_patch: bool
    start_index: int
    end_index: int
    df_ref_trace: Optional[pl.DataFrame]
    var_index: Optional[int]

    def __init__(
            self,
            interval: Optional[AnchoredInterval],
            caller_resources: Optional[CallerResources],
            var_region_kde: Optional[VarRegionKde],
            is_null: bool = False,
            is_patch: bool = False,
            start_index: Optional[int] = None,
            end_index: Optional[int] = None,
    ) -> None:
        """Initialize a variant object.

        If `is_null`, then `interval`, `caller_resources`, and `var_region_kde` must be None. If `is_patch`, then
        `interval` must not be None. If neither `is_null` nor `is_patch` is set, then `interval`, `caller_resources`,
        and `var_region_kde` must not be None.

        :param interval: Variant interval.
        :param caller_resources: Caller resources.
        :param var_region_kde: Variant region KDE.
        :param is_null: Set to True for null variants.
        :param is_patch: Set to True for patch variants.
        """
        if is_null or is_patch:
            assert all([interval is None, caller_resources is None, var_region_kde is None])
            assert all([start_index is not None, end_index is not None])

            self.start_index = start_index
            self.end_index = end_index

        else:
            assert all([interval is not None, caller_resources is not None, var_region_kde is not None])

            self.start_index = interval.start_index
            self.end_index = interval.end_index

        # Key structures
        self.interval = interval
        self.caller_resources = caller_resources
        self.var_region_kde = var_region_kde

        # Get ref-trimmed breakpoints
        # df_segment_ref = (
        #     caller_resources.df_align_qryref
        #     .filter(
        #         pl.col('index').is_in(
        #             interval.df_segment
        #             .filter('is_anchor')
        #             .select('index')
        #             .to_series()
        #         )
        #     )
        #     .collect()
        # )

        # Variant fields
        self.region_ref = interval.region_ref if interval is not None else None  # Fields: chrom, pos, end
        self.region_qry = interval.region_qry if interval is not None else None  # Fields: qry_id, qry_pos, qry_end
        self.region_ref_qrytrim = self.region_ref

        self.vartype = 'NULL'
        self.varsubtype = None
        self.varlen = 0

        self.filter_set = set((
            interval.df_segment
            .filter(pl.col('is_anchor'))
            .select(pl.col('filter').explode().drop_nulls())
            .to_series().to_list()
        )) if interval is not None else set()

        self.call_source = CALL_SOURCE

        self.var_score = float('-inf')
        self.templ_res = False

        self.df_ref_trace = None
        self._seq = None  # Sequence cache

        self.var_index = None

        self._dup_list: list[dict[str, str | int]] = []

        # Non-variant fields
        self.is_patch = is_patch          # Set to True for patch variants

        # Private fields
        self._is_complete_anno = False  # Set to True after complete_anno() is called
        self._found_variant = False     # Null variant until set to True by the concrete variant class
        self._patch_start_index = None  # Set by patch variants to indicate the start index (no interval)
        self._patch_end_index = None    # Set by patch variants to indicate the end index (no interval)

    @property
    def chrom(self) -> str:
        """Reference chromosome."""
        if self.region_ref is None:
            raise ValueError('Property "chrom" is not set on a null variant')

        return self.region_ref.chrom

    @property
    def pos(self) -> int:
        """Reference start position."""
        if self.region_ref is None:
            raise ValueError('Property "pos" is not set on a null variant')

        return self.region_ref.pos

    @property
    def end(self) -> int:
        """Reference end position."""
        if self.region_ref is None:
            raise ValueError('Property "end" is not set on a null variant')

        return self.region_ref.end

    @property
    def chain_start_index(self) -> int:
        """Chain start index."""
        if self.interval is None:
            raise ValueError('Property "chain_start_index" is not set on a null variant')

        return self.interval.start_index

    @property
    def chain_end_index(self) -> int:
        """Chain end index."""
        if self.interval is None:
            raise ValueError('Property "chain_end_index" is not set on a null variant')

        return self.interval.end_index

    @property
    def seg_n(self) -> int:
        """Number of variant segments including anchors."""
        if self.interval is None:
            raise ValueError('Property "seg_n" is not set on a null variant')

        return self.interval.df_segment.height

    @property
    def df_segment(self) -> pl.DataFrame:
        """Table of segments including aligned and unaligned query segments."""
        if self.interval is None:
            raise ValueError('Property "df_segment" is not set on a null variant')

        return self.interval.df_segment

    @property
    def min_anchor_score(self) -> float:
        """Minimum score of both anchors."""
        return self.interval.min_anchor_score if self.interval is not None else float('-inf')

    @property
    def filter(self) -> list[str]:
        """Sorted list of filters."""
        return sorted(self.filter_set)

    @property
    def is_pass(self) -> bool:
        """Determine if there are no filters set for this variant."""
        return len(self.filter_set) == 0

    @property
    def qry_id(self) -> str:
        """Query sequence ID."""
        if self.region_qry is None:
            raise ValueError('Property "qry_id" cannot be accessed: Missing region_qry')

        return self.region_qry.chrom

    @property
    def qry_pos(self) -> int:
        """Query start position."""
        if self.region_qry is None:
            raise ValueError('Property "qry_pos" cannot be accessed: Missing region_qry')

        return self.region_qry.pos

    @property
    def qry_end(self) -> int:
        """Query end position."""
        if self.region_qry is None:
            raise ValueError('Property "qry_end" cannot be accessed: Missing region_qry')

        return self.region_qry.end

    @property
    def qry_rev(self) -> bool:
        """Query is in reverse orientation relative to the reference."""
        if self.interval is None:
            raise ValueError('Property "qry_rev" is not set on a null variant')

        return self.interval.is_rev

    @property
    def align_source(self) -> list[int]:
        """List of aligned segment indices."""
        if self.interval is None:
            raise ValueError('Property "align_source" is not set on a null variant')

        return (
            self.interval.df_segment
            .filter(pl.col('is_aligned'))
            .select(pl.col('align_index'))
        ).to_series().to_list()

    @property
    def dup(self) -> Optional[list[dict[str, str | int]]]:
        """Get a list of duplicated reference loci."""
        return list(self._dup_list) if self._dup_list is not None else None

    @property
    def seg(self) -> Optional[list[dict[str, str | int | bool]]]:
        """Get a list of templated reference loci."""
        if self.interval is None:
            return None

        return (
            self.interval.df_segment
            .filter(pl.col('is_aligned') & ~ pl.col('is_anchor'))
            .select(
                'chrom', 'pos', 'end',
                (pl.col('is_rev') ^ self.interval.is_rev).alias('is_rev'),
                'qry_id', 'qry_pos', 'qry_end'
            )
            .rows(named=True)
        )

    @property
    def variant_id(self) -> str:
        """Variant ID."""
        if self.is_null:
            return 'Null'

        return f'{self.chrom}-{self.vartype}-{self.pos}-{self.varlen}'

    @property
    def is_null(self) -> bool:
        """Determine if variant is a null call."""
        return (self.interval is None or not self._found_variant) and not self.is_patch

    @property
    def is_variant(self) -> bool:
        """Determine if a variant was found."""
        return self._found_variant

    @property
    def seq(self) -> str:
        """Variant sequence."""
        if self.is_null or self.is_patch:
            raise ValueError('Property "seq" is not set on a null or patch variant')

        if self._seq is None:

            if self.vartype == 'DEL':
                self._seq = self.caller_resources.cache_ref[
                    self.region_ref.chrom
                ][
                    self.region_ref.pos:self.region_ref.end
                ]

            else:

                self._seq = self.caller_resources.cache_qry[
                    self.region_qry.chrom
                ][
                    self.region_qry.pos:self.region_qry.end
                ]

                if self.qry_rev:
                    self._seq = str(Bio.Seq.Seq(self._seq).reverse_complement())

        return self._seq

    @property
    def hom_ref(self) -> dict[str, int]:
        """Reference homology."""
        hom = perfect_homology(
            seq_var=self.seq,
            seq_ref=self.caller_resources.cache_ref[self.region_ref.chrom],
            pos=self.region_ref.pos,
            end=self.region_ref.end,
            is_rev=False,
        )

        return {'up': hom[0], 'dn': hom[1]}

    @property
    def hom_qry(self) -> dict[str, int]:
        """Query homology."""
        hom = perfect_homology(
            seq_var=self.seq,
            seq_ref=self.caller_resources.cache_qry[self.region_qry.chrom],
            pos=self.region_qry.pos,
            end=self.region_qry.end,
            is_rev=self.qry_rev,
        )

        return {'up': hom[0], 'dn': hom[1]}

    def __repr__(self) -> str:
        """Get a string representation of a variant object."""
        state = 'NULL' if self.is_null else (
            'INCOMPLETE' if not self._found_variant else (
                'PATCH' if self.is_patch else 'FOUND'
            )
        )
        return (
            f'{type(self).__name__}('
            f'state={state} '
            f'vartype={self.vartype}, '
            f'ref={self.region_ref}, '
            f'qry={self.region_qry}, qry_rev={self.qry_rev if not (self.is_null or self.is_patch) else None}, '
            f'score={self.var_score}, filter=[{", ".join(self.filter)}])'
        )

    def complete_anno(self) -> None:
        """Complete annotations on this variant call setting all fields necessary to call row().

        Initial variant calls are not completed so they can be prioritized before spending the CPU cycles and IO time
        pulling sequences to complete annotations.
        """
        if self._is_complete_anno or self.is_null or self.is_patch:
            return

        # Variant type implementation
        self._complete_anno_variant()
        self._is_complete_anno = True

    @classmethod
    def row_set(
            cls,
            add_set: Optional[set[str]] = None
    ) -> set[str]:
        """Get a set of row names for this variant class.

        :param add_set: Optional set of additional row names to include.

        :returns: Set of row names for this variant class.
        """
        return (
            {
                'chrom', 'pos', 'end',
                'vartype', 'varlen', 'filter',
                'qry_id', 'qry_pos', 'qry_end', 'qry_rev',
                'call_source', 'var_score', 'align_source',
                'hom_ref', 'hom_qry', 'seq',
            } |
            cls._row_set() |
            (add_set if add_set is not None else set())
        )

    def row(
            self,
            add_set: Optional[set[str]] = None
    ) -> dict[str, Any]:
        """Get a dict of values representing a variant call record (not including "id").

        The order of records is undefined, the final table should be ordered by the variant schema. The "id" column
        should be set on the final table, it is not computed by the variant objects.

        :param add_set: Optional set of additional row names to include.

        :returns: Variant call record as a dict.
        """
        self.complete_anno()

        if self.is_null:
            raise ValueError(f'Cannot get row for null variant: {self}')

        return {k: getattr(self, k) for k in self.row_set(add_set)}

    def seg_aligned_to_dup(
            self,
            ref_overlap: bool = True,
    ) -> None:
        """Add aligned segments to duplicated loci.

        :param ref_overlap: If True, add the reference region if there is a tandem duplication at the variant site.
        """
        dup_regions = [
            Region(**row)
            for row in (
                self.interval.df_segment
                .filter(
                    pl.col('is_aligned'),
                    ~pl.col('is_anchor')
                )
                .with_columns(
                    (pl.col('is_rev') ^ self.qry_rev).alias('is_rev')
                )
                .select(
                    'chrom', 'pos', 'end',
                    pl.lit(False).alias('is_rev'),
                    pl.col('align_index').alias('pos_align_index'),
                    pl.col('align_index').alias('end_align_index'),
                )
            ).iter_rows(named=True)
        ]

        if ref_overlap and self.interval.len_ref < 0:
            dup_regions.append(self.region_ref_qrytrim)

        self._dup_list.extend([
            _.as_dict() for _ in sorted(dup_regions)
        ])


    #
    # To be overridden
    #

    def _complete_anno_variant(self) -> None:  # noqa: B027
        """Complete annotations. To be implemented by the variant subclass."""
        pass

    @classmethod
    def _row_set(cls) -> set[str]:
        """Get a set of row names for this variant call."""
        return set()


class InsertionVariant(Variant):
    """Insertion variant call."""

    # Simple insertion (INS = unaligned or aligned to another site)
    # INS:                           -------------------
    #                                        ||
    # Qry: --->--------->---------->---------> --------->-------->--------->--------->-----
    # Ref: --------------------------------------------------------------------------------
    #
    # Tandem duplication
    # Qry: --->--------->---------->--------->--------->
    #    :                                    --------->-------->--------->--------->-----
    # Ref: --------------------------------------------------------------------------------


    def __init__(
            self,
            interval: AnchoredInterval,
            caller_resources: CallerResources,
            var_region_kde: VarRegionKde,
            _try_td: bool = False,
    ) -> None:
        """Create variant call."""
        Variant.__init__(self, interval, caller_resources, var_region_kde)
        self.vartype = 'INS'

        # if _try_td:  # Called by TandemDuplicationVariant constructor, do not try to resolve INS variant
        #     return

        # Variant lengths
        seg_lens = sorted(interval.seg_len_or_dup + interval.seg_len_unaligned, reverse=True)

        if len(seg_lens) == 0:
            return

        len_aligned = sum(interval.seg_len_aligned)
        len_unaligned = sum(interval.seg_len_unaligned)
        len_dup = interval.len_outer_dup
        len_del = interval.len_outer_del

        self.varlen = len_aligned + len_unaligned + len_dup - len_del

        if self.varlen <= 0:
            # If deleted segment is larger than inserted/duplicated segments, never call INS
            return

        # Score
        score_model = self.caller_resources.score_model

        self.var_score = (
            # Gap: Longest of aligned, unaligned, or duplicated segments
            score_model.gap(seg_lens[0])

            # Gap: All other segments and/or outer duplication
            + sum(
                score_model.gap(_)
                for _ in seg_lens[1:]
            ) * score_model.off_variant()

            # Gap: Outer deletion
            + score_model.gap(len_del) * score_model.off_variant()
        )

        # Set breakpoints on reference-trimmed coordinates
        self.region_ref = interval.region_ref_qryref

        # Finalize
        self.seg_aligned_to_dup()

        if len_dup > 0 and (len_dup / self.varlen) >= 0.5:
            self.varsubtype = 'TD'

        self.region_ref = Region(
            chrom=interval.region_ref_qryref.chrom,
            pos=interval.region_ref_qryref.pos,
            end=interval.region_ref_qryref.pos + 1,
            is_rev=interval.region_ref_qryref.is_rev,
            pos_align_index=interval.region_ref_qryref.pos_align_index,
            end_align_index=interval.region_ref_qryref.end_align_index,
        )

        self.resolved_templ = interval.qry_aligned_pass_prop >= caller_resources.pav_params.lg_cpx_min_aligned_prop

        self._found_variant = True

    def _complete_anno_variant(self) -> None:
        """Complete annotations."""
        pass

    @classmethod
    def _row_set(cls) -> set[str]:
        """Get a set of row names for this variant call."""
        return {'varsubtype', 'dup'}


class DeletionVariant(Variant):
    """Deletion variant call."""

    # Simple deletion
    # Qry: ---->---------->--------->                  --------->-------->--------->-------
    # Ref: --------------------------------------------------------------------------------

    def __init__(
            self,
            interval: AnchoredInterval,
            caller_resources: CallerResources,
            var_region_kde: VarRegionKde,
    ) -> None:
        """Create variant call."""
        Variant.__init__(self, interval, caller_resources, var_region_kde)
        self.vartype = 'DEL'

        # Stop for incoempatible signatures
        if interval.len_outer_del - interval.len_qry <= 0:
            return

        self.varlen = interval.len_outer_del

        self.region_ref = interval.region_ref
        self.region_qry = interval.region_qry

        # Score
        score_model = self.caller_resources.score_model

        self.var_score = (
            # Deletion gap
            score_model.gap(self.varlen)

            # Query segements (off-variant)
            + sum([score_model.gap(_) for _ in interval.seg_len]) * score_model.off_variant()
        )

        self.resolved_templ = True
        self._found_variant = True

    @classmethod
    def _row_set(cls) -> set[str]:
        """Get a set of row names for this variant call."""
        return {'varsubtype', 'dup'}  # Same as INS, will be placed in the same table


class InversionVariant(Variant):
    """Balanced inversion variant call."""

    # Note: Breakpoints may not be placed consistently in inverted repeats on each end, the aligner makes an
    # alignment decision independently for each breakpoint. Therefore, the inverted segment may not align to the
    # reference gap between the repeats. An alignment penalty should be applied to discourage inversion calls
    # that do not fit the classic model (an inverted alignment in a reference gap), but not penalize alignment
    # this common alignment artifact.
    #
    #            [ > >  Repeat  > > ]                                        [ < <  Repeat  < < ]
    # Flank: --->--------->------->                                                          --->----
    #   INV:       <---------<---------<---------<---------<---------<---------
    # Trace:  NML    |   DUP      |                  INV                       |    DEL      |   NML
    #
    # The pattern above is apparent in trimmed alignments (by query trimming). The un-trimmed alignment will
    # typically align through both repeats:
    #
    #            [ > >  Repeat  > > ]                                        [ < <  Repeat  < < ]
    # Flank: --->--------->------->--                                        --------->------->------
    #   INV:     --<---------<---------<---------<---------<---------<---------<---------<-------
    # Trace:  NML    |   DUP      |                  INV                       |    DEL      |   NML
    #
    # These two sources of information are combined. The qry-trimmed alignment is used to score the inversion after
    # redundant alignments are removed so complex patterns can be penalized appropriately. The untrimmed alignment
    # is used for setting inner- and outer-breakpoint locations.

    def __init__(
            self,
            interval: AnchoredInterval,
            caller_resources: CallerResources,
            var_region_kde: VarRegionKde,
    ) -> None:
        """Create variant call."""
        Variant.__init__(self, interval, caller_resources, var_region_kde)
        self.vartype = 'INV'

        self.region_ref_outer = None  # Also a sentinel for a successful call when trying multiple approaches
        self.region_qry_outer = None
        self.size_gap = 0

        # Base inversion checks
        if self.interval.len_ref <= 0 or self.interval.len_qry <= 0:
            # Balanced inversions consume ref & query bases
            return

        if min(self.interval.len_ref, self.interval.len_qry) / max(self.interval.len_ref, self.interval.len_qry) < 0.5:
            # Neither ref nor query region may be 2x greater than the other
            return

        df_int = (
            interval.df_segment
            .filter(~ pl.col('is_anchor'))
            .with_columns(
                (
                    pl.col('is_aligned') &
                    (pl.col('pos') < self.interval.region_ref.end) &
                    (pl.col('end') > self.interval.region_ref.pos)
                ).alias('is_prox')
            )
            .with_columns(
                (~ pl.col('is_prox') & pl.col('is_aligned')).alias('is_dist')
            )
        )

        # Try inversion by untrimmed alignment
        if (
                self.interval.seg_n_aligned == 1
                and df_int.filter('is_aligned').select((pl.col('is_rev') != self.interval.is_rev).all()).item()
                and df_int.filter('is_aligned').select((pl.col('chrom') == self.interval.chrom).all()).item()
        ):
            # Get a table of pre-trimmed alignments in the same order as the aligned segments
            df_align_none = (
                caller_resources.df_align_none
                .select(['align_index', 'pos', 'end', 'qry_pos', 'qry_end'])
                .join(
                    (
                        self.interval.df_segment.filter('is_aligned')
                        .lazy()
                        .select(['align_index'])
                    ),
                    on='align_index',
                    how='inner',
                    maintain_order='right'
                )
                .sort('pos', 'end')
                .collect()
            )

            ref_pos_outer = df_align_none[1, 'pos']
            ref_end_outer = df_align_none[1, 'end']

            ref_pos_inner = df_align_none[0, 'end']
            ref_end_inner = df_align_none[2, 'pos']

            if not interval.is_rev:
                qry_pos_outer = df_align_none[1, 'qry_pos']
                qry_end_outer = df_align_none[1, 'qry_end']

                qry_pos_inner = df_align_none[0, 'qry_end']
                qry_end_inner = df_align_none[2, 'qry_pos']
            else:
                qry_pos_outer = df_align_none[1, 'qry_pos']
                qry_end_outer = df_align_none[1, 'qry_end']

                qry_pos_inner = df_align_none[2, 'qry_end']
                qry_end_inner = df_align_none[0, 'qry_pos']

            if (
                (ref_pos_outer <= ref_pos_inner)
                and (ref_end_outer >= ref_end_inner)
                and (ref_pos_inner <= ref_end_inner)
                and (qry_pos_outer <= qry_pos_inner)
                and (qry_end_outer >= qry_end_inner)
                and (qry_pos_inner <= qry_end_inner)
            ):

                self.region_ref_outer = Region(interval.chrom, ref_pos_outer, ref_end_outer)
                self.region_ref = Region(interval.chrom, ref_pos_inner, ref_end_inner)

                self.region_qry_outer = Region(interval.qry_id, qry_pos_outer, qry_end_outer)
                self.region_qry = Region(interval.qry_id, qry_pos_inner, qry_end_inner)

                self.align_gap = abs(interval.len_qry - interval.len_ref)
                self.resolved_templ = True

                self.res_type = 'ALIGN'

                self.var_score = (
                    # Penalize reference gap and inverted alignment diff
                    caller_resources.score_model.gap(self.align_gap)

                    # Penalized unaligned query sequences
                    + (
                            self.df_segment
                            .filter(~pl.col('is_aligned'))
                            .select(
                                pl.col('len_qry')
                                .map_elements(caller_resources.score_model.gap)
                                .sum()
                            ).item()
                    )

                    # Penalize template switches
                    + caller_resources.score_model.template_switch() * 2
                )


        # Try call by KDE
        if self.region_ref_outer is None:

            # Pre-checks before trying inversion by KDE
            if df_int.filter('is_dist').select('len_qry').sum().item() > self.interval.len_qry * 0.1:
                # No more than 10% aligned outside the inversion site (allow for small alignments)
                return

            if (
                not var_region_kde.try_inv_kde
                or df_int.filter('is_prox').select(
                    (
                        pl.col('len_qry').filter(pl.col('is_rev') == interval.is_rev).sum()
                        > pl.col('len_qry').filter(pl.col('is_rev') != interval.is_rev).sum()
                    )
                ).item()
            ):
                # Inverted by KDE, or Inverted segment lengths should outweigh the
                # non-inverted segments if the inversion is called by alignment.
                return

            # Call variant by KDE
            self.region_qry, self.region_qry_outer = get_inv_qry_regions(
                region_flag=self.interval.region_ref,
                ref_fa_filename=self.caller_resources.ref_fa_filename,
                qry_fa_filename=self.caller_resources.qry_fa_filename,
                df_ref_fai=self.caller_resources.df_ref_fai,
                df_qry_fai=self.caller_resources.df_qry_fai,
                align_lift=self.caller_resources.align_lift,
                pav_params=self.caller_resources.pav_params,
                k_util=self.caller_resources.k_util,
                kde_model=self.caller_resources.kde_model,
                stop_on_lift_fail=True,
                log_file=None,
            )

            if self.region_qry is not None and self.region_qry_outer is not None:
                # Found inversion by KDE

                # Lift to reference
                self.region_ref = caller_resources.align_lift.region_to_ref(self.region_qry, same_align=True)
                self.region_ref_outer = caller_resources.align_lift.region_to_ref(self.region_qry_outer, same_align=True)

                if self.region_ref is None:
                    # Lift failed on inner coordinates - breakpoints at the edge of an alignment record
                    self.region_ref = self.interval.region_ref

                if self.region_ref_outer is None or not self.region_ref_outer.contains(self.region_ref):
                    # Lift failed on inner coordinates - may be a short alignment record at the flanks
                    self.region_ref_outer = self.region_ref

                self.align_gap = 0
                self.resolved_templ = False

                self.res_type = 'KDE'

                self.var_score = self.caller_resources.score_model.template_switch() * 2

        # Call variant
        if self.region_ref_outer is None:
            # No variant by any method
            return

        self.varlen = len(self.region_ref)

        self.outer_ref = self.region_ref_outer.as_dict()
        self.outer_qry = self.region_qry_outer.as_dict()

        self._found_variant = True

        return

    @classmethod
    def _row_set(cls) -> set[str]:
        """Get a set of row names for this variant call."""
        return {'outer_ref', 'outer_qry', 'align_gap'}


class ComplexVariant(Variant):
    """Complex variant call."""

    def __init__(
            self,
            interval: AnchoredInterval,
            caller_resources: CallerResources,
            var_region_kde: VarRegionKde,
    ) -> None:
        """Create variant call."""
        Variant.__init__(self, interval, caller_resources, var_region_kde)

        # Check pre-conditions
        if interval.len_qry <= 0:
            return

        # Set base properties
        len_dup = interval.len_outer_dup
        len_del = interval.len_outer_del

        self.vartype = 'CPX'
        self.region_ref = interval.region_ref
        self.region_qry = interval.region_qry
        self.varlen = interval.len_qry + len_dup

        # Pre-score and check
        score_model = self.caller_resources.score_model
        ts = score_model.template_switch()

        ts_score = sum([
            min([score_model.gap(_), ts])
            for _ in interval.seg_len_unaligned_or_outer
        ])

        n_features = (
            # Aligned segments
            len(interval.seg_len_aligned)

            # Outer DEL or DUP
            + (interval.len_ref != 0)

            # Unaligned segments add up to more than template switches
            + sum([score_model.gap(_) < ts for _ in interval.seg_len_unaligned])
        )

        if n_features < 2:
            return

        # Compute variant score
        self.var_score = (
            # Aligned segments
            sum([score_model.gap(_) for _ in interval.seg_len_aligned])

            # Gap or template switch
            + sum([
                min([score_model.gap(_), ts])
                for _ in interval.seg_len_unaligned_or_outer
            ])

            # Template switch for aligned segments
            + score_model.template_switch(interval.seg_n_aligned + 1)
        )

        # Finalize
        self.df_ref_trace = get_ref_trace(
            interval=self.interval,
            df_ref_fai=self.caller_resources.df_ref_fai,
        )

        self.resolved_templ = interval.qry_aligned_pass_prop >= caller_resources.pav_params.lg_cpx_min_aligned_prop

        self.seg_aligned_to_dup()

        self._found_variant = True

    def _complete_anno_variant(self):
        """Complete variant annotations."""
        # Get smoothed segment table
        if self.caller_resources.pav_params.lg_smooth_segments > 0.0:
            self.ref_trace_smooth = smooth_ref_trace(
                df_ref_trace=self.df_ref_trace,
                varlen=self.varlen,
                smooth_factor=self.caller_resources.pav_params.lg_smooth_segments
            )
            ref_trace_smooth = self.ref_trace_smooth
        else:
            self.ref_trace_smooth = None
            ref_trace_smooth = self.df_ref_trace

        self.trace_qry = qry_trace_str(self.interval.df_segment, self.is_pass)
        self.trace_ref = ref_trace_str(self.df_ref_trace, with_len=True)
        self.varsubtype = ref_trace_str(ref_trace_smooth, with_len=False)

    @classmethod
    def _row_set(cls) -> set[str]:
        """Get a set of row names for this variant call."""
        return {'varsubtype', 'seg_n', 'trace_qry', 'trace_ref', 'seg', 'dup'}


class NullVariant(Variant):
    """Represents no variant call."""

    def __init__(
            self,
            start_index: int,
            end_index: int,
    ) -> None:
        """Create variant call."""
        Variant.__init__(
            self, None, None, None,
            is_null=True, start_index=start_index, end_index=end_index
        )
        self.vartype = 'NULL'

    @classmethod
    def _row_set(cls) -> set[str]:
        """No row sets, raisse an error."""
        raise ValueError('Null variant has no row')


class PatchVariant(Variant):
    """Patch variant call for spanning segments with no variant.

    Represents no-variant call around alignment errors that do not represent real variation. For example, alignment
    artifacts around inverted repeats often break the alignment into pieces, but inspection of the pieces finds that
    they are largely contiguous with the reference. This patch variant type has a score of 0 and is treated as a bridge
    from one alignment anchor to another by graph traversal and prevents it from being pushed down non-optimal paths.
    """

    def __init__(self, start_index: int, end_index: int) -> None:
        """Start and end indices of the patch variant."""
        Variant.__init__(
            self, None, None, None,
            is_patch=True, start_index=start_index, end_index=end_index
        )
        self.vartype = 'PATCH'

        self.var_score = 0.0
        self.is_patch = True

    @classmethod
    def _row_set(cls) -> set[str]:
        """No row sets, raisse an error."""
        raise RuntimeError('Null variant does not have a row')


class DevVariant(Variant):
    """A convenience class for development purposes. Not used by PAV."""

    def __init__(
            self,
            interval: AnchoredInterval,
            caller_resources: CallerResources,
            var_region_kde: VarRegionKde,
    ) -> None:
        """Create variant call."""
        Variant.__init__(self, interval, caller_resources, var_region_kde)

        self.vartype = 'DEV'

    @classmethod
    def _row_set(cls) -> set[str]:
        """No row sets, raisse an error."""
        raise ValueError('Dev variant does not have a row')
