"""
Quant Module

Provides quantitative analysis tools including factors (technical and fundamental), quotes, and backtesting.
Based on Mai-language syntax compatible with TongDaXin/TongHuaShun.

All technical indicators (RSI, MACD, KDJ, etc.) are now available as factors through the unified factors API.
"""

import json
import os
from typing import Any, Literal

import httpx
import pandas as pd

from reportify_sdk.exceptions import (
    APIError,
    AuthenticationError,
    NotFoundError,
    RateLimitError,
)


StockMarket = Literal["cn", "hk", "us"]


class QuantModule:
    """
    Quantitative analysis module

    Access factors (including technical indicators and fundamental factors), OHLCV quotes, and backtesting functionality.
    Uses Mai-language syntax for formulas.

    Technical indicators are now part of the unified factors system:
    - Level 0: Basic variables (CLOSE, OPEN, HIGH, LOW, VOLUME) and core functions (MA, EMA, REF, etc.)
    - Level 1: Application functions (CROSS, COUNT, EVERY, etc.)
    - Level 2: Technical indicators (RSI, MACD, KDJ, BOLL, etc.) and fundamental factors (PE, ROE, etc.)

    Example:
        >>> quant = client.quant
        >>> # List all available factors (including technical indicators)
        >>> factors = quant.factors()
        >>> # Compute RSI (now through factors API)
        >>> df = quant.factors_compute(["000001"], "RSI(14)")
        >>> # Screen stocks by formula
        >>> stocks = quant.factors_screen(formula="RSI(14) < 30")
    """

    def __init__(self, client):
        self._client = client

    # -------------------------------------------------------------------------
    # Factors (includes technical indicators and fundamental factors)
    # -------------------------------------------------------------------------

    def factors(self, *, market: StockMarket = "cn") -> list[dict[str, Any]]:
        """
        Get list of available factors (variables, functions, and indicators)

        Returns factors organized by level:
        - Level 0 Variables: CLOSE, OPEN, HIGH, LOW, VOLUME, AMOUNT (price data, no parentheses)
        - Level 0 Functions: MA(), EMA(), REF(), HHV(), LLV(), STD(), etc. (require parentheses)
        - Level 1 Functions: CROSS(), COUNT(), EVERY(), etc. (require parentheses)
        - Level 2 Functions: Technical indicators (MACD(), KDJ(), RSI(), BOLL(), etc.) and fundamental factors (PE(), ROE(), etc.)

        Variables vs Functions:
            - Variables (no parentheses): CLOSE, OPEN, HIGH, LOW, VOLUME, AMOUNT
            - Functions (TongDaXin style: col first, n second): MA(CLOSE, 20), PE(), ROE(), RSI(14), etc.

        Args:
            market: Stock market ("cn", "hk", "us"), default "cn"

        Returns:
            List of factor definitions with name, type, level, description, and optional fields

        Example:
            >>> factors = client.quant.factors()
            >>> factors = client.quant.factors(market="hk")
            >>> for f in factors:
            ...     print(f"{f['name']} ({f['type']}, level {f['level']})")
            ...     if 'fields' in f:
            ...         print(f"  Fields: {f['fields']}")
        """
        return self._client._get("/v1/quant/factors", params={"market": market})

    def factors_compute(
        self,
        symbols: list[str],
        formula: str,
        *,
        market: StockMarket = "cn",
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> pd.DataFrame:
        """
        Compute factor values for given symbols

        Uses Mai-language syntax compatible with TongDaXin/TongHuaShun.

        Variables vs Functions:
            - Variables (no parentheses): CLOSE, OPEN, HIGH, LOW, VOLUME, AMOUNT
            - Functions (TongDaXin style: col first, n second): MA(CLOSE, 20), PE(), ROE(), RSI(14), etc.

        Args:
            symbols: List of stock codes
            formula: Factor formula using Mai-language syntax
            market: Stock market ("cn", "hk", "us"), default "cn"
            start_date: Start date (YYYY-MM-DD), default 3 months ago
            end_date: End date (YYYY-MM-DD), default today

        Returns:
            DataFrame with factor values

        Example:
            >>> # Technical indicators (RSI, MACD, etc.)
            >>> df = client.quant.factors_compute(["000001"], "RSI(14)")
            >>> df = client.quant.factors_compute(["000001"], "MACD().dif")
            >>> df = client.quant.factors_compute(["000001"], "KDJ(9,3,3)")
            
            >>> # Core functions
            >>> df = client.quant.factors_compute(["000001"], "MA(CLOSE, 20)")
            >>> df = client.quant.factors_compute(["000001"], "STD(CLOSE, 20)")
            
            >>> # Boolean expressions
            >>> df = client.quant.factors_compute(["000001"], "CLOSE > MA(CLOSE, 20)")
            >>> df = client.quant.factors_compute(["000001"], "(CLOSE - MA(CLOSE, 20)) / MA(CLOSE, 20) * 100")
            
            >>> # Fundamental factors
            >>> df = client.quant.factors_compute(["000001"], "PE()")
            >>> df = client.quant.factors_compute(["000001"], "ROE()")

        Supported Operators:
            - Comparison: >, <, >=, <=, ==, !=
            - Logical: & or AND, | or OR, ~ or NOT (case-insensitive)
            - Arithmetic: +, -, *, /
            - Important: expressions on both sides of logical operators (&/|/AND/OR) must be wrapped in ()

        Supported Variables (no parentheses):
            - CLOSE, C: Close price
            - OPEN, O: Open price
            - HIGH, H: High price
            - LOW, L: Low price
            - VOLUME, V, VOL: Volume

        Supported Functions (require parentheses):
            - Technical: MA(), EMA(), RSI(), MACD(), BOLL(), etc.
            - Fundamental: PE(), PB(), ROE(), ROA(), etc.
        """
        data: dict[str, Any] = {
            "symbols": symbols,
            "formula": formula,
            "market": market,
        }
        if start_date:
            data["start_date"] = start_date
        if end_date:
            data["end_date"] = end_date

        response = self._client._post("/v1/quant/factors/compute", json=data)
        return self._to_dataframe(response.get("datas", []))

    def factors_screen(
        self,
        formula: str,
        *,
        market: StockMarket = "cn",
        check_date: str | None = None,
        symbols: list[str] | None = None,
    ) -> pd.DataFrame:
        """
        Screen stocks based on factor formula

        Returns stocks where the formula evaluates to True (for boolean formulas)
        or non-null (for numeric formulas).

        Variables vs Functions:
            - Variables (no parentheses): CLOSE, OPEN, HIGH, LOW, VOLUME, AMOUNT
            - Functions (TongDaXin style: col first, n second): MA(CLOSE, 20), PE(), ROE(), RSI(14), etc.

        Args:
            formula: Screening formula using Mai-language syntax
            market: Stock market ("cn", "hk", "us"), default "cn"
            check_date: Check date (YYYY-MM-DD), default latest trading day
            symbols: Stock codes to screen (None = full market)

        Returns:
            DataFrame with stocks that passed the filter

        Example:
            >>> # Technical screening
            >>> stocks = client.quant.factors_screen(formula="RSI(14) < 30")
            >>> stocks = client.quant.factors_screen(formula="CROSS(MA(CLOSE, 5), MA(CLOSE, 10))")
            >>> stocks = client.quant.factors_screen(formula="(CLOSE > MA(CLOSE, 20)) & (MA(CLOSE, 20) > MA(CLOSE, 60))")
            >>> stocks = client.quant.factors_screen(formula="CLOSE > BOLL(20, 2).upper")
            
            >>> # Fundamental screening
            >>> stocks = client.quant.factors_screen(formula="(PE() < 20) & (ROE() > 0.15)")
            
            >>> # Screen specific stocks
            >>> stocks = client.quant.factors_screen(
            ...     formula="RSI(14) < 30",
            ...     symbols=["000001", "600519", "000002"]
            ... )
        """
        data: dict[str, Any] = {
            "formula": formula,
            "market": market,
        }
        if check_date:
            data["check_date"] = check_date
        if symbols:
            data["symbols"] = symbols

        response = self._client._post("/v1/quant/factors/screen", json=data)
        return self._to_dataframe(response.get("datas", []))

    # -------------------------------------------------------------------------
    # Quotes
    # -------------------------------------------------------------------------

    def ohlcv(
        self,
        symbol: str,
        *,
        market: StockMarket = "cn",
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> pd.DataFrame:
        """
        Get OHLCV (Open, High, Low, Close, Volume) daily data for a single symbol

        Args:
            symbol: Stock code
            market: Stock market ("cn", "hk", "us"), default "cn"
            start_date: Start date (YYYY-MM-DD), default 1 month ago
            end_date: End date (YYYY-MM-DD), default today

        Returns:
            DataFrame with OHLCV data

        Example:
            >>> df = client.quant.ohlcv("000001")
            >>> print(df[["open", "high", "low", "close", "volume"]])
        """
        params: dict[str, Any] = {
            "symbol": symbol,
            "market": market,
        }
        if start_date:
            params["start_date"] = start_date
        if end_date:
            params["end_date"] = end_date

        response = self._client._get("/v1/quant/quotes/ohlcv", params=params)
        return self._to_dataframe(response.get("datas", []))

    def ohlcv_batch(
        self,
        symbols: list[str],
        *,
        market: StockMarket = "cn",
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> pd.DataFrame:
        """
        Get OHLCV data for multiple symbols

        Args:
            symbols: List of stock codes
            market: Stock market ("cn", "hk", "us"), default "cn"
            start_date: Start date (YYYY-MM-DD), default 1 month ago
            end_date: End date (YYYY-MM-DD), default today

        Returns:
            DataFrame with OHLCV data sorted by date (descending), then by symbol

        Example:
            >>> df = client.quant.ohlcv_batch(["000001", "600519"])
            >>> print(df[["symbol", "date", "close", "volume"]])
        """
        data: dict[str, Any] = {
            "symbols": symbols,
            "market": market,
        }
        if start_date:
            data["start_date"] = start_date
        if end_date:
            data["end_date"] = end_date

        response = self._client._post("/v1/quant/quotes/ohlcv/batch", json=data)
        return self._to_dataframe(response.get("datas", []))

    def kline(
        self,
        symbol: str,
        *,
        kline_type: str = "1D",
        market: StockMarket = "cn",
        stock_type: str = "stock",
        start_datetime: str | None = None,
        end_datetime: str | None = None,
    ) -> pd.DataFrame:
        """
        Get kline data for a single symbol

        Unified kline endpoint supporting all periods via kline_type parameter.

        Args:
            symbol: Stock code
            kline_type: Kline type — "1M", "5M", "15M", "30M", "60M" (intraday),
                "1D" (daily, default), "1W" (weekly), "1MO" (monthly)
            market: Stock market ("cn", "hk", "us"), default "cn"
            stock_type: Stock type ("stock", "etf", "index", "sw"), default "stock"
            start_datetime: Start datetime (YYYY-MM-DD HH:MM:SS), optional
            end_datetime: End datetime (YYYY-MM-DD HH:MM:SS), optional

        Returns:
            DataFrame with kline data

        Default date range when start_datetime is not specified:
            1M → 1 day | 5M/15M → 3 days | 30M/60M → 5 days |
            1D → 30 days | 1W → 180 days | 1MO → 365 days

        Example:
            >>> # Daily kline (default)
            >>> df = client.quant.kline("000001")
            >>> # 5-minute intraday
            >>> df = client.quant.kline("000001", kline_type="5M",
            ...     start_datetime="2026-04-09 09:30:00",
            ...     end_datetime="2026-04-09 15:00:00")
            >>> # Weekly kline
            >>> df = client.quant.kline("600519", kline_type="1W")
            >>> # ETF daily
            >>> df = client.quant.kline("510300", kline_type="1D", stock_type="etf")
        """
        params: dict[str, Any] = {
            "symbol": symbol,
            "kline_type": kline_type,
            "market": market,
            "stock_type": stock_type,
        }
        if start_datetime:
            params["start_datetime"] = start_datetime
        if end_datetime:
            params["end_datetime"] = end_datetime

        response = self._client._get("/v1/quant/quotes/kline", params=params)
        return self._to_dataframe(response.get("datas", []))

    def kline_batch(
        self,
        symbols: list[str],
        *,
        kline_type: str = "1D",
        market: StockMarket = "cn",
        stock_type: str = "stock",
        start_datetime: str | None = None,
        end_datetime: str | None = None,
    ) -> pd.DataFrame:
        """
        Get kline data for multiple symbols

        Args:
            symbols: List of stock codes
            kline_type: Kline type — "1M", "5M", "15M", "30M", "60M", "1D", "1W", "1MO"
            market: Stock market ("cn", "hk", "us"), default "cn"
            stock_type: Stock type ("stock", "etf", "index", "sw"), default "stock"
            start_datetime: Start datetime (YYYY-MM-DD HH:MM:SS), optional
            end_datetime: End datetime (YYYY-MM-DD HH:MM:SS), optional

        Returns:
            DataFrame with kline data for all symbols

        Example:
            >>> df = client.quant.kline_batch(["000001", "600519"], kline_type="1D")
            >>> df = client.quant.kline_batch(
            ...     ["000001", "600519"], kline_type="5M",
            ...     start_datetime="2026-04-09 09:30:00",
            ...     end_datetime="2026-04-09 15:00:00"
            ... )
        """
        data: dict[str, Any] = {
            "symbols": symbols,
            "kline_type": kline_type,
            "market": market,
            "stock_type": stock_type,
        }
        if start_datetime:
            data["start_datetime"] = start_datetime
        if end_datetime:
            data["end_datetime"] = end_datetime

        response = self._client._post("/v1/quant/quotes/kline/batch", json=data)
        return self._to_dataframe(response.get("datas", []))

    def minute(
        self,
        symbol: str,
        start_datetime: str,
        end_datetime: str,
        *,
        market: StockMarket = "cn",
    ) -> pd.DataFrame:
        """
        Get minute data for a single symbol

        Args:
            symbol: Stock code
            start_datetime: Start datetime (YYYY-MM-DD HH:MM:SS)
            end_datetime: End datetime (YYYY-MM-DD HH:MM:SS)
            market: Stock market ("cn", "hk", "us"), default "cn"

        Returns:
            DataFrame with minute data

        Example:
            >>> df = client.quant.minute(
            ...     symbol="000001",
            ...     start_datetime="2024-01-01 09:30:00",
            ...     end_datetime="2024-01-01 15:00:00"
            ... )
            >>> print(df[["datetime", "open", "high", "low", "close", "volume"]])
        """
        params: dict[str, Any] = {
            "symbol": symbol,
            "start_datetime": start_datetime,
            "end_datetime": end_datetime,
            "market": market,
        }
        response = self._client._get("/v1/quant/quotes/minute", params=params)
        return self._to_dataframe(response.get("datas", []))

    def minute_batch(
        self,
        symbols: list[str],
        start_datetime: str,
        end_datetime: str,
        *,
        market: StockMarket = "cn",
    ) -> pd.DataFrame:
        """
        Get batch minute data for multiple symbols

        Args:
            symbols: List of stock codes
            start_datetime: Start datetime (YYYY-MM-DD HH:MM:SS)
            end_datetime: End datetime (YYYY-MM-DD HH:MM:SS)
            market: Stock market ("cn", "hk", "us"), default "cn"

        Returns:
            DataFrame with minute data sorted by date (ascending), then by symbol

        Example:
            >>> df = client.quant.minute_batch(
            ...     symbols=["000001", "600519"],
            ...     start_datetime="2024-01-01 09:30:00",
            ...     end_datetime="2024-01-01 15:00:00"
            ... )
            >>> print(df[["symbol", "datetime", "close", "volume"]])
        """
        data: dict[str, Any] = {
            "symbols": symbols,
            "start_datetime": start_datetime,
            "end_datetime": end_datetime,
            "market": market,
        }
        response = self._client._post("/v1/quant/quotes/minute/batch", json=data)
        return self._to_dataframe(response.get("datas", []))

    # -------------------------------------------------------------------------
    # Backtest
    # -------------------------------------------------------------------------

    def backtest(
        self,
        start_date: str,
        end_date: str,
        *,
        symbols: list[str] | None = None,
        filter_formula: str | None = None,
        entry_formula: str | None = None,
        strategy_code: str | None = None,
        exit_formula: str | None = None,
        market: StockMarket = "cn",
        initial_cash: float = 100000.0,
        commission: float = 0.0,
        buy_commission: float = 0.0,
        sell_commission: float = 0.0,
        min_commission_amount: float = 0.0,
        slippage: float = 0.0,
        stop_loss: float = 0.0,
        position_size: float | None = None,
        max_positions: int | None = None,
        min_volume: int = 100,
        auto_close: bool = True,
        cheat_on_open: bool = False,
        signal_factors: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """
        Execute strategy backtest

        Variables vs Functions:
            - Variables (no parentheses): CLOSE, OPEN, HIGH, LOW, VOLUME, AMOUNT
            - Functions (TongDaXin style: col first, n second): MA(CLOSE, 20), PE(), ROE(), RSI(14), etc.

        Args:
            start_date: Backtest start date (YYYY-MM-DD)
            end_date: Backtest end date (YYYY-MM-DD)
            symbols: List of stock codes (optional if filter_formula is provided)
            filter_formula: Pre-filter formula, e.g., 'NOT(IS_ST)'
            entry_formula: Buy/long entry formula (result > 0 triggers buy)
            strategy_code: Custom backtest strategy Python code. Must define `def handle_data(context, datas):`
            exit_formula: Sell/close formula (result > 0 triggers sell), optional
            market: Stock market ("cn", "hk", "us"), default "cn"
            initial_cash: Initial capital (default: 100000.0)
            commission: Commission rate for both buy and sell (default: 0.0)
            buy_commission: Buy commission rate, takes priority over commission (default: 0.0)
            sell_commission: Sell commission rate, takes priority over commission (default: 0.0)
            min_commission_amount: Minimum commission per trade in CNY (default: 0.0)
            slippage: Slippage ratio, buy price up / sell price down (default: 0.0)
            stop_loss: Stop loss setting (default: 0.0, no stop loss)
            position_size: Max position size ratio per stock based on total assets (default: None, no limit)
            max_positions: Max number of holding stocks (default: None, no limit)
            min_volume: Minimum trading volume, e.g., 100 for A-shares (default: 100)
            auto_close: Auto close positions (default: True)
            cheat_on_open: Whether to execute T-day signals at T-day open (default: False, execute at T+1 open)
            signal_factors: Signal factors dictionary for custom strategy pre-computation

        Returns:
            Backtest results including:
            - success: Whether backtest succeeded
            - initial_cash: Initial capital
            - final_cash: Final capital
            - total_return: Total return
            - total_return_pct: Total return percentage
            - max_drawdown: Maximum drawdown
            - profit_factor: Profit factor
            - win_rate: Win rate
            - total_trades: Total number of trades
            - winning_trades: Number of winning trades
            - losing_trades: Number of losing trades
            - trades: List of trade details
            - portfolio_value: Daily portfolio values
            - benchmark_value: Daily benchmark values scaled to initial capital
            - benchmark_return_pct: Benchmark total return percentage
            - sharpe_ratio: Annualized Sharpe ratio with risk-free rate = 0
            - alpha: Annualized CAPM Jensen's Alpha with risk-free rate = 0
            - beta: Strategy beta relative to benchmark
            - max_drawdown_start: Start date of maximum drawdown period (peak)
            - max_drawdown_end: End date of maximum drawdown period (trough)
            - daily_returns: Daily return series (decimal values)
            - drawdown_series: Daily drawdown series (positive decimal values)
            - error_msg: Error message if failed

        Example:

            >>> # Simple golden cross strategy
            >>> result = client.quant.backtest(
            ...     start_date="2023-01-01",
            ...     end_date="2024-01-01",
            ...     symbols=["000001"],
            ...     entry_formula="CROSS(MA(CLOSE, 5), MA(CLOSE, 20))",  # Buy when MA5 crosses above MA20
            ...     initial_cash=100000
            ... )
            >>> print(f"Total Return: {result['total_return_pct']:.2%}")
            >>> print(f"Max Drawdown: {result['max_drawdown']:.2%}")
            >>> print(f"Win Rate: {result['win_rate']:.2%}")
            
            >>> # Strategy with entry and exit signals
            >>> result = client.quant.backtest(
            ...     start_date="2023-01-01",
            ...     end_date="2024-01-01",
            ...     symbols=["000001"],
            ...     entry_formula="CROSS(MA(CLOSE, 5), MA(CLOSE, 20))",  # Buy signal
            ...     exit_formula="CROSSDOWN(MA(CLOSE, 5), MA(CLOSE, 20))"  # Sell signal
            ... )
            
            >>> # With custom python strategy code
            >>> strategy = '''
            ... def handle_data(context, datas):
            ...     for data in datas:
            ...         symbol = data.name
            ...         if not context.portfolio.get_position(symbol):
            ...             if data.pe < 20 and data.rsi < 30:  # Use pre-calculated factors
            ...                 context.order_target_percent(symbol, 0.2)
            ...         elif data.rsi > 70:
            ...             context.order_target_percent(symbol, 0)
            ... '''
            >>> result = client.quant.backtest(
            ...     start_date="2023-01-01", end_date="2023-12-31",
            ...     symbols=["000001"],
            ...     signal_factors={"rsi": "RSI(14)", "pe": "PE_TTM()"},
            ...     strategy_code=strategy
            ... )
        """
        data: dict[str, Any] = {
            "start_date": start_date,
            "end_date": end_date,
            "market": market,
            "initial_cash": initial_cash,
            "commission": commission,
            "buy_commission": buy_commission,
            "sell_commission": sell_commission,
            "min_commission_amount": min_commission_amount,
            "slippage": slippage,
            "stop_loss": stop_loss,
            "min_volume": min_volume,
            "auto_close": auto_close,
            "cheat_on_open": cheat_on_open,
        }
        if position_size is not None:
            data["position_size"] = position_size
        if max_positions is not None:
            data["max_positions"] = max_positions
        if symbols is not None:
            data["symbols"] = symbols
        if filter_formula is not None:
            data["filter_formula"] = filter_formula
        if entry_formula is not None:
            data["entry_formula"] = entry_formula
        if strategy_code is not None:
            data["strategy_code"] = strategy_code
        if exit_formula is not None:
            data["exit_formula"] = exit_formula
        if signal_factors is not None:
            data["signal_factors"] = signal_factors

        return self._client._post(
            "/v1/quant/backtest",
            json=data,
        )

    def backtest_upload(
        self,
        file_path: str | None = None,
        file_content: bytes | None = None,
        *,
        file_name: str | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
        entry_formula: str | None = None,
        strategy_code: str | None = None,
        exit_formula: str | None = None,
        initial_cash: float = 100000.0,
        commission: float = 0.0,
        buy_commission: float = 0.0,
        sell_commission: float = 0.0,
        min_commission_amount: float = 0.0,
        slippage: float = 0.0,
        position_size: float | None = None,
        max_positions: int | None = None,
        min_volume: int = 1,
        auto_close: bool = True,
        cheat_on_open: bool = False,
        signal_factors: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """
        Upload an Excel file to run backtest

        Upload an Excel file (.xlsx/.xls) containing OHLCV data for backtesting.
        This allows you to use your own market data instead of the system's
        built-in data source.

        Excel file format requirements:
            - Required columns: date, open, high, low, close
            - Optional columns: symbol (required for multi-symbol), volume, amount
            - Custom fields: any ASCII-named columns with numeric values
              (e.g., pe, market_cap, pb_ratio) can be referenced in formulas

        Args:
            file_path: Path to Excel file (mutually exclusive with file_content)
            file_content: Raw Excel file bytes (mutually exclusive with file_path)
            file_name: Filename when using file_content (default: "upload.xlsx")
            start_date: Backtest start date (YYYY-MM-DD), filters data after indicator computation
            end_date: Backtest end date (YYYY-MM-DD), filters data after indicator computation
            entry_formula: Buy/long entry formula (result > 0 triggers buy)
            strategy_code: Custom backtest strategy Python code. Must define `def handle_data(context, datas):`
            exit_formula: Sell/close formula (result > 0 triggers sell), optional
            initial_cash: Initial capital (default: 100000.0)
            commission: Commission rate for both buy and sell (default: 0.0)
            buy_commission: Buy commission rate, takes priority over commission (default: 0.0)
            sell_commission: Sell commission rate, takes priority over commission (default: 0.0)
            min_commission_amount: Minimum commission per trade in CNY (default: 0.0)
            slippage: Slippage ratio, buy price up / sell price down (default: 0.0)
            position_size: Max position size ratio per stock (default: None, no limit)
            max_positions: Max number of holding stocks (default: None, no limit)
            min_volume: Minimum trading volume, e.g., 100 for A-shares (default: 1)
            auto_close: Auto close positions (default: True)
            cheat_on_open: Whether to execute T-day signals at T-day open (default: False, execute at T+1 open)
            signal_factors: Signal factors dictionary for custom strategy pre-computation

        Returns:
            Backtest results (same format as backtest() method)

        Example:
            >>> # Upload from file path
            >>> result = client.quant.backtest_upload(
            ...     file_path="my_data.xlsx",
            ...     start_date="2023-06-01",
            ...     end_date="2024-01-01",
            ...     entry_formula="CROSS(MA(CLOSE, 5), MA(CLOSE, 10))",
            ...     exit_formula="CROSS(MA(CLOSE, 10), MA(CLOSE, 5))",
            ...     initial_cash=100000
            ... )

            >>> # Upload from bytes
            >>> with open("my_data.xlsx", "rb") as f:
            ...     content = f.read()
            >>> result = client.quant.backtest_upload(
            ...     file_content=content,
            ...     file_name="my_data.xlsx",
            ...     entry_formula="RSI(14) < 30",
            ...     exit_formula="RSI(14) > 70"
            ... )
        """
        extra_data: dict[str, str] = {
            "initial_cash": str(initial_cash),
            "commission": str(commission),
            "buy_commission": str(buy_commission),
            "sell_commission": str(sell_commission),
            "min_commission_amount": str(min_commission_amount),
            "slippage": str(slippage),
            "min_volume": str(min_volume),
            "auto_close": str(auto_close).lower(),
            "cheat_on_open": str(cheat_on_open).lower(),
        }
        if position_size is not None:
            extra_data["position_size"] = str(position_size)
        if max_positions is not None:
            extra_data["max_positions"] = str(max_positions)
        if start_date is not None:
            extra_data["start_date"] = start_date
        if end_date is not None:
            extra_data["end_date"] = end_date
        if entry_formula is not None:
            extra_data["entry_formula"] = entry_formula
        if strategy_code is not None:
            extra_data["strategy_code"] = strategy_code
        if exit_formula is not None:
            extra_data["exit_formula"] = exit_formula
        if signal_factors is not None:
            extra_data["signal_factors"] = json.dumps(signal_factors)

        files = {}
        if file_path:
            # 打开文件
            file_handle = open(file_path, "rb")
            files = {"file": (
                    os.path.basename(file_path),
                    file_handle,
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                )
            }
        elif file_content:
            files = {"file": (
                    file_name or "upload.xlsx",
                    file_content,
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                )
            }
        else:
            raise ValueError("file_path or file_content must be provided")

        try:
            response = self._client._client.post(
                "/v1/quant/backtest/upload",
                files=files,
                data=extra_data,
            )

            if response.status_code == 401:
                raise AuthenticationError()
            elif response.status_code == 429:
                raise RateLimitError()
            elif response.status_code == 404:
                raise NotFoundError()
            elif response.status_code >= 400:
                error_msg = response.text
                try:
                    error_data = response.json()
                    error_msg = error_data.get(
                        "detail", error_data.get("message", error_msg)
                    )
                except Exception:

                    pass
                raise APIError(error_msg, status_code=response.status_code)

            return response.json()

        except httpx.TimeoutException:
            raise APIError("Request timeout", status_code=408)
        except httpx.RequestError as e:
            raise APIError(f"Request failed: {str(e)}")
        finally:
            if file_path and "file" in files:
                files["file"][1].close()

    # -------------------------------------------------------------------------
    # Helper Methods
    # -------------------------------------------------------------------------

    def _to_dataframe(self, data: list[dict[str, Any]]) -> pd.DataFrame:
        """Convert API response to DataFrame"""
        if not data:
            return pd.DataFrame()
        df = pd.DataFrame(data)
        # Convert date columns if present
        for col in ["date", "check_date", "trade_date"]:
            if col in df.columns:
                df[col] = pd.to_datetime(df[col])
        return df
