#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

from copy import copy

import numpy as np
import pandas as pd
from pvlib import solarposition


class Wall:
    def __init__(self, azimuth_deg=180, location: tuple = (53.0123, 7.0123), tilt_deg=90, sight_factor_sky=None):
        """

        Parameters
        ----------
        azimuth_deg : float
            Wall azimuth angle in degrees (0 = north, 90 = east, 180 = south, ...).
        location : tuple
            Latitude and longitude of the location in degrees.
        tilt_deg : float
            Tilt angle of the wall from horizontal in degrees (90 = vertical, 0 = flat).
        sight_factor_sky : float, optional
            The sight factor to the atmosphere (sky).
            If None, it is calculated.
        """
        self.azimuth = np.radians(azimuth_deg)
        self.location = location
        self.tilt = np.radians(tilt_deg)

        if sight_factor_sky is None:
            sight_factor_sky = 0.5 * (1 + np.cos(self.tilt))
        self.sight_factor_sky = sight_factor_sky

    def calculate_sight_factor_sky(self):
        self.sight_factor_sky = 0.5 * (1 + np.cos(self.tilt))

    def __copy__(self):
        return Wall(
            azimuth_deg=np.degrees(self.azimuth),
            location=copy(self.location),
            tilt_deg=np.degrees(self.tilt),
            sight_factor_sky=self.sight_factor_sky,
        )

    def __deepcopy__(self):
        return self.__copy__()

    @property
    def latitude(self):
        return self.location[0]

    @property
    def longitude(self):
        return self.location[1]

    def apply_direct_radiation(self, values: np.ndarray, dates: np.ndarray) -> np.ndarray:
        """
        Changes horizontal values to actual values.

        Parameters
        ----------
        values : np.ndarray
            The values of the direct solar radiation measures on a horizontal plane.
        dates : np.ndarray
            The date times of the values.

        Returns
        -------
        np.ndarray :
            The values of the direct solar radiation measures on the wall.
        """
        times = pd.DatetimeIndex(dates)
        solpos = solarposition.get_solarposition(times, self.latitude, self.longitude)

        zenith = np.radians(solpos["zenith"].values)
        azimuth = np.radians(solpos["azimuth"].values)

        cos_theta = np.cos(zenith) * np.cos(self.tilt) + np.sin(zenith) * np.sin(self.tilt) * np.cos(
            azimuth - self.azimuth
        )
        cos_theta = np.maximum(0, cos_theta)

        return values * cos_theta

    def apply_sky_radiation(self, values: np.ndarray) -> np.ndarray:
        """
        Like apply_direct_radiation but applies radiation to the sky.

        Parameters
        ----------
        values : np.ndarray
            The values of the diffuse solar radiation measures on a horizontal plane.
        dates : np.ndarray
            The date times of the values.

        Returns
        -------
        np.ndarray :
            The values of the diffuse solar radiation measures on the wall reduced by the sight factor of the wall.
        """
        return self.sight_factor_sky * values

    def apply_ground_radiation(self, values: np.ndarray) -> np.ndarray:
        """
        Like apply_direct_radiation but applies radiation to the ground.

        Parameters
        ----------
        values : np.ndarray
            The values of the diffuse solar radiation measures on a horizontal plane.
        dates : np.ndarray
            The date times of the values.

        Returns
        -------
        np.ndarray :
            The values of the diffuse solar radiation measures on the wall reduced by the sight factor of the wall.
        """
        return (1 - self.sight_factor_sky) * values
