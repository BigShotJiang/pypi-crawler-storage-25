#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

from importlib import resources
import numpy as np

from typing import Callable

initial_uniform_color_map = "managua"
initial_discrete_color_map = "managua10"

RGB = tuple[float, float, float]

# name -> either:
#   ("uniform", rgb[N,3])
#   ("explicit", t[N], rgb[N,3])
CMAPS: dict[str, tuple] = {}


def _parse_gradient(data: np.ndarray, name: str) -> tuple:
    if data.shape[1] == 3:
        return "uniform", data[:, :3]
    elif data.shape[1] >= 4:
        t = data[:, 0]
        rgb = data[:, 1:4]
        order = np.argsort(t)
        return "explicit", t[order], rgb[order]
    raise ValueError(f"Bad colormap file {name}: expected 3 or 4 columns")


def _load_txt_colormaps() -> None:
    pkg = __package__
    root = resources.files(pkg)

    for subfolder, kind in (("uniform", "gradient"), ("discrete", "discrete")):
        try:
            folder = root.joinpath(subfolder)
            entries = list(folder.iterdir())
        except (FileNotFoundError, NotADirectoryError):
            continue

        for p in entries:
            if not (p.is_file() and p.name.lower().endswith(".txt")):
                continue
            cmap_name = p.name.rsplit(".", 1)[0]
            lines = p.read_text(encoding="utf-8").splitlines()

            def _first_numeric_line(lines: list[str]) -> int:
                for i, line in enumerate(lines):
                    parts = line.split()
                    if parts and parts[0].lstrip("-").replace(".", "", 1).isdigit():
                        return i
                raise ValueError("No numeric line found")

            if kind == "discrete":
                skip = _first_numeric_line(lines)
                rgb_rows = []
                for line in lines[skip:]:
                    parts = line.split()
                    try:
                        r, g, b = float(parts[0]), float(parts[1]), float(parts[2])
                        if all(v <= 255 for v in (r, g, b)):
                            rgb_rows.append([r / 255.0, g / 255.0, b / 255.0])
                    except (ValueError, IndexError):
                        continue
                if not rgb_rows:
                    raise ValueError(f"No valid colours in discrete palette {p.name}")
                CMAPS[cmap_name] = ("discrete", np.array(rgb_rows, dtype=np.float32))
            else:
                skip = _first_numeric_line(lines)
                data = np.loadtxt(p, dtype=np.float32, skiprows=skip, encoding="utf-8")
                if data.ndim == 1:
                    data = data[None, :]
                CMAPS[cmap_name] = _parse_gradient(data, p.name)


_load_txt_colormaps()


def available(kind: str | None = None) -> tuple[str, ...]:
    """
    Return names of all loaded colormaps.

    Parameters
    ----------
    kind : str or None
        Filter by type: 'uniform', 'explicit', 'discrete', or None for all.
    """
    if kind is None:
        return tuple(sorted(CMAPS.keys()))
    return tuple(sorted(k for k, v in CMAPS.items() if v[0] == kind))


def value_to_rgb(value: float | int | np.ndarray, cmap: str = initial_uniform_color_map) -> np.ndarray:
    """
    Map relative value(s) in [0, 1] to RGB using a loaded colormap.

    Parameters
    ----------
    value : float, int, or np.ndarray
        Scalar or array of values in [0, 1].
    cmap : str
        Colormap name.

    Returns
    -------
    np.ndarray
        Shape (..., 3), dtype float32.
    """
    if cmap not in CMAPS:
        raise KeyError(f"Unknown colormap '{cmap}'. Available: {available()}")

    value = np.clip(np.asarray(value, dtype=np.float32), 0.0, 1.0)
    entry = CMAPS[cmap]
    kind = entry[0]

    if kind == "uniform":
        rgb = entry[1]
        n = rgb.shape[0]
        if n == 1:
            return np.broadcast_to(rgb[0], value.shape + (3,)).astype(np.float32, copy=False)
        x = value * (n - 1)
        i = np.floor(x).astype(np.int32)
        j = np.minimum(i + 1, n - 1)
        u = (x - i)[..., None]
        return (rgb[i] * (1.0 - u) + rgb[j] * u).astype(np.float32, copy=False)

    if kind == "explicit":
        t, rgb = entry[1], entry[2]
        r = np.interp(value, t, rgb[:, 0]).astype(np.float32, copy=False)
        g = np.interp(value, t, rgb[:, 1]).astype(np.float32, copy=False)
        b = np.interp(value, t, rgb[:, 2]).astype(np.float32, copy=False)
        return np.stack([r, g, b], axis=-1)

    # discrete: map value to nearest swatch index
    rgb = entry[1]
    n = rgb.shape[0]
    idx = np.clip(np.floor(value * n).astype(np.int32), 0, n - 1)
    return rgb[idx]


def get_palette(cmap: str = initial_discrete_color_map) -> np.ndarray:
    """
    Return all swatches of a discrete palette as (N, 3) float32 array.

    Parameters
    ----------
    cmap : str
        Name of a discrete colormap.

    Returns
    -------
    np.ndarray
        Shape (N, 3), dtype float32.

    Raises
    ------
    KeyError
        If cmap is not found.
    TypeError
        If cmap is not a discrete palette.
    """
    if cmap not in CMAPS:
        raise KeyError(f"Unknown colormap '{cmap}'. Available: {available()}")
    if CMAPS[cmap][0] != "discrete":
        raise TypeError(f"'{cmap}' is not a discrete palette.")
    return CMAPS[cmap][1]


def make_color_mapper(cmap: str = initial_uniform_color_map) -> Callable[[float | int | np.ndarray], np.ndarray]:
    """Convenience: returns f(v)->rgb for one colormap name."""
    return lambda v: value_to_rgb(v, cmap=cmap)


def cycle_palette(cmap: str = initial_discrete_color_map) -> "Generator[np.ndarray, None, None]":
    """
    Yield RGB colours from a colormap in order, cycling indefinitely.

    Parameters
    ----------
    cmap : str
        Colormap name.

    Yields
    ------
    np.ndarray
        Shape (3,), dtype float32.
    """
    if cmap not in CMAPS:
        raise KeyError(f"Unknown colormap '{cmap}'. Available: {available()}")
    entry = CMAPS[cmap]
    rgb = entry[1] if entry[0] in ("uniform", "discrete") else entry[2]
    i = 0
    n = rgb.shape[0]
    while True:
        yield rgb[i % n]
        i += 1
