#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

from typing import Generator
from vpython import vector
from pyrc.core.visualization.color.color import cycle_palette, initial_discrete_color_map


def cycle_palette_vpython(cmap: str = initial_discrete_color_map) -> Generator[vector, None, None]:
    """
    Yield VPython vector colours from a colormap, cycling indefinitely.

    Parameters
    ----------
    cmap : str
        Colormap name passed to cycle_palette.

    Yields
    ------
    vector
        VPython color vector with components (r, g, b) in [0, 1].

    Examples
    --------
    >>> generator = cycle_palette_vpython()
    >>> first_three_colors = [next(generator) for _ in range(3)])
    """
    for rgb in cycle_palette(cmap):
        yield vector(float(rgb[0]), float(rgb[1]), float(rgb[2]))
