#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

from __future__ import annotations

from typing import TYPE_CHECKING

from pyrc.core.visualization.color.vpython import cycle_palette_vpython
from pyrc.tools.functions import get_nested_attribute

if TYPE_CHECKING:
    from pyrc.core.components.templates import Cell


def color_cells_by_attribute(nodes: list[Cell], attribute: str, opacity: float | int = 0.3, *args, **kwargs):
    """
    Color nodes based on a specified attribute value.

    Parameters
    ----------
    nodes : list[Cell]
        List of Cell objects to color
    attribute : str
        Attribute path to use for coloring (e.g., 'material.name' or 'x')
    opacity : float, optional
        Opacity value that is set to every vbox.
    args, kwargs :
        Passed to cycle_palette_vpython
        Can be used to choose the color map like: cmap="managua50"
    """
    color_generator = cycle_palette_vpython(*args, **kwargs)

    # Map to track attribute values and their assigned colors
    attribute_colors = {}

    # Color each node
    node: Cell
    for node in nodes:
        value = get_nested_attribute(node, attribute)

        if value not in attribute_colors:
            # get new color from generator
            attribute_colors[value] = next(color_generator)

        # Apply color vector to vbox
        node.vbox.color = attribute_colors[value]
        node.vbox.opacity = opacity
