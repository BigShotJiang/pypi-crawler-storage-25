#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

from __future__ import annotations

from typing import Iterable, TYPE_CHECKING

from vpython import canvas, rate, color, vector, curve, arrow
import numpy as np


if TYPE_CHECKING:
    from pyrc.core.nodes import Node
    from pyrc.core.components.templates import Cell


class Viewer:
    def __init__(
        self,
        objects=None,
        title: str = "Cell Network",
        width: int = 1902,
        height: int = 963,
        background=color.black,
        autoscale: bool = False,
        wireframe: tuple[tuple[float | int, float | int, float | int], tuple[float | int, float | int, float | int]]
        | None = None,
        draw_coordinate_system: bool = True,
    ):
        """
        Draw cells using vPython.

        Parameters
        ----------
        objects : list, optional
            The objects to draw.
            They can be added later on.
        title : str, optional
            The title of the canvas.
        width : int, optional
            Width of the canvas.
        height : int, optional
            Height of the canvas.
        background : color, optional
            Background color.
        autoscale : bool, optional
            Autoscale canvas. For a lot of objects not recommended.
        wireframe : tuple[tuple[float | int, float | int, float | int], tuple[float | int, float | int, float | int]] | None, optional
            If given, edges are drawn to display the boundaries of the network.
            Should consist of two 3D tuples, first is position/center, second width, height and depth.
        draw_coordinate_system : bool, optional
            If True, a coordinate system is drawn.
        """
        self.scene = canvas(title=title, width=width, height=height, background=background)
        self.scene.autoscale = autoscale  # keep False for performance with many objects

        self.initial_color = (0.6, 0.6, 0.6)

        self.objects = []
        if objects:
            self.add(objects)

        self.wireframe_dimensions = None
        if wireframe is not None:
            self.draw_wireframe(*wireframe)
            self.wireframe_dimensions = wireframe[1]

        if draw_coordinate_system:
            self.draw_coordinate_system()

    def draw_wireframe(self, center, deltas, edge_color=color.white, edge_radius_factor=0.001):
        """
        Draw wireframe edges of the grid bounding box.

        Parameters
        ----------
        center : tuple[float | int, float | int]
            The center of the wireframe.
        deltas : tuple[float | int, float | int]
            The width, height and depth of the wireframe.
        edge_color : color, optional
            The color of the edges.
        edge_radius_factor : float, optional
            Determines the thickness of the edges drawn.
            Is multiplied by the maximum dimension (x/y/z value).
        """
        cx, cy, cz = center
        dx, dy, dz = deltas

        # Calculate corner positions
        half_dx, half_dy, half_dz = dx / 2, dy / 2, dz / 2

        corners = [
            vector(cx - half_dx, cy - half_dy, cz - half_dz),
            vector(cx + half_dx, cy - half_dy, cz - half_dz),
            vector(cx + half_dx, cy + half_dy, cz - half_dz),
            vector(cx - half_dx, cy + half_dy, cz - half_dz),
            vector(cx - half_dx, cy - half_dy, cz + half_dz),
            vector(cx + half_dx, cy - half_dy, cz + half_dz),
            vector(cx + half_dx, cy + half_dy, cz + half_dz),
            vector(cx - half_dx, cy + half_dy, cz + half_dz),
        ]

        # Define edges as pairs of corner indices
        edges = [
            (0, 1),
            (1, 2),
            (2, 3),
            (3, 0),  # Bottom face
            (4, 5),
            (5, 6),
            (6, 7),
            (7, 4),  # Top face
            (0, 4),
            (1, 5),
            (2, 6),
            (3, 7),  # Vertical edges
        ]

        # Draw each edge
        for i, j in edges:
            curve(pos=[corners[i], corners[j]], color=edge_color, radius=max(dx, dy, dz) * edge_radius_factor)

        # Set camera position and orientation
        # Position camera to look at grid from an angle
        distance = max(dx, dy, dz) * 2.5
        self.scene.camera.pos = vector(cx - distance, cy - distance, cz + distance * 0.7)
        self.scene.camera.axis = vector(cx, cy, cz) - self.scene.camera.pos

        # Set up vector so z points up
        self.scene.up = vector(0, 0, 1)

        # Set the center point
        self.scene.center = vector(cx, cy, cz)

        # Adjust range to fit the grid
        self.scene.range = max(dx, dy, dz) * 0.8

    def draw_coordinate_system(self):
        if self.wireframe_dimensions is not None:
            length = min(self.wireframe_dimensions) * 0.25
        else:
            length = 0.5

        arrow_color = color.orange
        for _dir in [(1, 0, 0), (0, 1, 0), (0, 0, 1)]:
            direction = np.array(_dir) * length
            arrow(pos=vector(0, 0, 0), axis=vector(*direction), color=arrow_color)

    def add(self, objects: list | tuple | Cell, rgb=None):
        if not isinstance(objects, list | tuple):
            objects = [objects]
        if rgb is None:
            rgb = self.initial_color

        o: Cell
        for o in objects:
            box = o.vbox
            box.pos = vector(*o.position)
            box.size = vector(*o.delta)
            box.color = vector(*rgb)
            box.opacity = o.opacity
            self.objects.append(o)

        rate(1000)

    def add_new_from_list(self, objects: list | tuple):
        """
        Like add_highlight, but first determine which of the objects are already added and only highlight new ones.

        Parameters
        ----------
        objects : list | tuple
            The list with objects, where new objects have been added and the new ones should be highlighted.
        """
        new_list = []
        for o in objects:
            if o not in self.objects:
                new_list.append(o)

        self.add_highlight(new_list)

    def add_highlight(
        self, new_objects: list | tuple | Cell, highlight_rgb=(1, 51 / 255, 99 / 255), opacity=1.0, old_opacity=0.5
    ):
        for o in self.objects:
            o.vbox.color = vector(*self.initial_color)
            o.opacity = old_opacity
            o.vbox.opacity = old_opacity

        if not isinstance(new_objects, list | tuple):
            new_objects = [new_objects]

        for o in new_objects:
            o.opacity = opacity
            self.add(o, rgb=highlight_rgb)

        rate(1000)

    @staticmethod
    def update_all_colors(
        nodes: Iterable[Node],
        *,
        t_min: float,
        t_max: float,
        fps: float = 60.0,
    ) -> None:
        """
        Color-only update pass. Use inside your simulation/animation loop.
        """
        rate(fps)
        for n in nodes:
            n.update_color(t_min=t_min, t_max=t_max)

    def update_all_geometry(self, fps: float = 60.0) -> None:
        """
        Geometry update pass (pos/size). Only use if geometry actually changes.
        """
        rate(fps)
        for c in self.objects:
            c.update_vbox_geometry()

    # def animate_temperature_series(
    #         self,
    #         cells: Sequence[Cell],
    #         temp_frames: Sequence[Sequence[float]],
    #         *,
    #         fps: float = 1.0,
    #         loop: bool = False,
    # ) -> None:
    #     """
    #     Animate temperatures over time.
    #
    #     temp_frames :
    #         Sequence of frames; each frame is a sequence of temperatures
    #         with length == len(cells).
    #         Example: one frame per 5 min sim step, displayed at 1 fps.
    #     fps :
    #         How many frames per second you want to display.
    #         Your example: fps=1.0 (1 second represents 5 minutes of simulation).
    #     """
    #     n = len(cells)
    #     if n == 0:
    #         return
    #
    #     # Ensure geometry exists before animating
    #     self.build_geometry(cells)
    #
    #     # Basic sanity check once (cheap)
    #     for k, frame in enumerate(temp_frames[:1]):
    #         if len(frame) != n:
    #             raise ValueError(f"Frame {k} length {len(frame)} != number of cells {n}")
    #
    #     while True:
    #         for frame in temp_frames:
    #             rate(fps)
    #             # assign temps
    #             # update colors only
    #             for c, T in zip(cells, frame):
    #                 c.update_color(temperature=T)
    #
    #         if not loop:
    #             break


# ----------------------------
# Example usage (remove in your project)
# ----------------------------

if __name__ == "__main__":
    # Build a toy grid of cells
    _cells: list[Cell] = []
    nx, ny, nz = 20, 20, 25  # 20*20*25 = 10,000 boxes
    spacing = 1.1
    size = (1.0, 1.0, 1.0)

    from pyrc.core.components.templates import Cell

    for ix in range(nx):
        for iy in range(ny):
            for iz in range(nz):
                _cells.append(Cell(position=np.array((ix * spacing, iy * spacing, iz * spacing)), delta=(1, 1, 1)))

    _viewer = Viewer(autoscale=False)

    # Fake temperature frames: 120 frames (e.g., 120 * 5min = 10 hours simulated)
    # One frame per second in the animation
    import math

    _frames = []
    for k in range(120):
        _frame = []
        for _i in range(len(_cells)):
            # arbitrary smooth variation
            _frame.append(50.0 + 50.0 * math.sin(0.02 * _i + 0.2 * k))
        _frames.append(_frame)

    # _viewer.animate_temperature_series(
    #     _cells,
    #     _frames,
    #     t_min=0.0,
    #     t_max=100.0,
    #     fps=1.0,  # 1 second per frame (your "5 min sim step" display)
    #     loop=True,
    # )
