#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------
from pyrc.core.connecting import connect_cells_with_resistors, check_contact_between_cells, visualize_contact_area
from pyrc.core.network import RCNetwork
from pyrc.core.simulation import Simulation, Parameterization
from pyrc.core.wall import Wall
from pyrc.core.heat_transfer import (
    alpha_gnielinski_forced_tube_flow_turbulent,
    nusselt_gnielinski_forced_tube_flow_turbulent,
    alpha_gnielinski_forced_tube_flow_laminar,
    nusselt_gnielinski_forced_tube_flow_laminar,
    alpha_gnielinski_forced_tube_flow_transition,
    alpha_forced_convection_in_pipe,
    alpha_free_convection_horizontal_wall,
)
from pyrc.core.inputs import (
    BoundaryCondition,
    BoundaryConditionGeometric,
    BoundaryConditionCell,
    FluidBoundaryCondition,
    FluidBoundaryConditionGeometric,
    FluidBoundaryConditionCell,
    InteriorBoundaryCondition,
    InteriorBoundaryConditionGeometric,
    InteriorBoundaryConditionCell,
    ExteriorTemperatureInputMixin,
    ExteriorBoundaryCondition,
    ExteriorBoundaryConditionGeometric,
    ExteriorBoundaryConditionCell,
    SolidBoundaryCondition,
    SolidBoundaryConditionGeometric,
    SolidBoundaryConditionCell,
    FlowBoundaryCondition,
    FlowBoundaryConditionGeometric,
    FlowBoundaryConditionCell,
    ExteriorInletFlow,
    ExteriorInletFlowGeometric,
    ExteriorInletFlowCell,
    ExteriorOutletFlow,
    ExteriorOutletFlowGeometric,
    ExteriorOutletFlowCell,
    InternalHeatSource,
    Radiation,
)
from pyrc.core.nodes import ConnectedFlowObject, Node, MassFlowNode, ChannelNode, AirNode
from pyrc.core.resistors import MassTransport, CombinedResistor, HeatTransfer, HeatConduction


__all__ = [
    "connect_cells_with_resistors",
    "check_contact_between_cells",
    "visualize_contact_area",
    "RCNetwork",
    "Simulation",
    "Parameterization",
    "Wall",
]
__all__.extend(
    [
        "alpha_gnielinski_forced_tube_flow_turbulent",
        "nusselt_gnielinski_forced_tube_flow_turbulent",
        "alpha_gnielinski_forced_tube_flow_laminar",
        "nusselt_gnielinski_forced_tube_flow_laminar",
        "alpha_gnielinski_forced_tube_flow_transition",
        "alpha_forced_convection_in_pipe",
        "alpha_free_convection_horizontal_wall",
    ]
)
__all__.extend(
    [
        "BoundaryCondition",
        "BoundaryConditionGeometric",
        "BoundaryConditionCell",
        "FluidBoundaryCondition",
        "FluidBoundaryConditionGeometric",
        "FluidBoundaryConditionCell",
        "InteriorBoundaryCondition",
        "InteriorBoundaryConditionGeometric",
        "InteriorBoundaryConditionCell",
        "ExteriorTemperatureInputMixin",
        "ExteriorBoundaryCondition",
        "ExteriorBoundaryConditionGeometric",
        "ExteriorBoundaryConditionCell",
        "SolidBoundaryCondition",
        "SolidBoundaryConditionGeometric",
        "SolidBoundaryConditionCell",
        "FlowBoundaryCondition",
        "FlowBoundaryConditionGeometric",
        "FlowBoundaryConditionCell",
        "ExteriorInletFlow",
        "ExteriorInletFlowGeometric",
        "ExteriorInletFlowCell",
        "ExteriorOutletFlow",
        "ExteriorOutletFlowGeometric",
        "ExteriorOutletFlowCell",
        "InternalHeatSource",
        "Radiation",
    ]
)
__all__.extend(["MassTransport", "CombinedResistor", "HeatTransfer", "HeatConduction"])
__all__.extend(["ConnectedFlowObject", "Node", "MassFlowNode", "ChannelNode", "AirNode"])

from .components import *
from .components import __all__ as _components_all_
__all__.extend(_components_all_)

from .solver import *
from .solver import __all__ as _solver_all_
__all__.extend(_solver_all_)

from .visualization import *
from .visualization import __all__ as _visualization_all_
__all__.extend(_visualization_all_)