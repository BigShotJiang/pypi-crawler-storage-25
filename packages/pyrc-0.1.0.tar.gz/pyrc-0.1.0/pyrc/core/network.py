#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

from __future__ import annotations
import os
import pickle
from abc import abstractmethod
from copy import copy
from typing import Any, TYPE_CHECKING, Callable

import numpy as np
from sympy import lambdify, latex, SparseMatrix, Matrix, diag, Symbol, Basic, ImmutableSparseMatrix, MutableSparseMatrix
import sympy as sym
import hashlib
import networkx as nx
from scipy.sparse import coo_matrix

from pyrc.paths import run_folder
from pyrc.core.components.resistor import Resistor
from pyrc.core.inputs import InternalHeatSource
from pyrc.core.settings import initial_settings, Settings
from pyrc.core.solver.symbolic import SparseSymbolicEvaluator
from pyrc.core.solver.handler import InhomogeneousSystemHandler, SolveIVPHandler, HomogeneousSystemHandler
from pyrc.tools.errors import HighCourantNumberError
from pyrc.tools.functions import add_leading_underscore

from pyrc.tools.science import build_jacobian
from pyrc.core.components.templates import RCObjects, RCSolution, EquationItem, initial_rc_objects, Cell
from pyrc.core.components.templates import solution_object
from pyrc.core.components.capacitor import Capacitor

if TYPE_CHECKING:
    from pyrc.core.nodes import MassFlowNode
    from pyrc.core.components.templates import EquationItemInput
    from scipy.sparse import spmatrix, sparray


class RCNetwork:
    def __init__(
        self,
        save_to_pickle: bool = True,
        load_from_pickle: bool = True,
        load_solution: bool = True,
        num_cores_jacobian: int = 1,  # TODO: Parallelization only works on linux currently (because it forks instead
        # of spawning it). Problem is: Sympy symbols are not picklable.
        settings: Settings = initial_settings,
        rc_objects: RCObjects = initial_rc_objects,
        rc_solution: RCSolution = solution_object,
        # strategy: str = "lambdify",
        continue_canceled: bool = True,
    ):
        """

        Parameters
        ----------
        save_to_pickle
        load_from_pickle
        load_solution
        num_cores_jacobian
        settings
        rc_objects
        rc_solution
        continue_canceled : bool, optional
            If True, continue canceled simulations.
            Overwrites load_solution
        """
        self.rc_objects: RCObjects = rc_objects
        self.settings = settings
        self._system_matrix_symbol: MutableSparseMatrix = None
        self._input_matrix_symbol: MutableSparseMatrix = None
        self._temperature_vector_symbol = None
        self._input_vector_symbol = None
        self._input_matrix = None
        self._system_matrix = None
        self.__hash = None
        self.rc_solution: RCSolution = rc_solution
        # link rc objects to rc solution
        self.rc_solution.rc_objects = rc_objects
        # self.strategy = strategy

        # For each time dependent symbol the following values are not allowed because they would make an entry in the
        # system matrix be infinity
        self.forbidden_values: dict[Symbol, set] = {}

        self.save_to_pickle: bool = save_to_pickle
        self.load_from_pickle: bool = load_from_pickle
        self.load_solution: bool = load_solution
        self.continue_canceled: bool = continue_canceled

        if num_cores_jacobian is None:
            num_cores_jacobian = os.cpu_count()
        self.num_cores_jacobian = min(max(num_cores_jacobian, 1), os.cpu_count())

        self.groups: dict[str:Capacitor] = {}

    def __getattr__(self, item):
        if getattr(self.rc_objects, item, None):
            return self.rc_objects.__getattribute__(item)
        return AttributeError

    def create_network(self, *args, **kwargs):
        EquationItem.reset_counter()
        Resistor.reset_counter()
        self.rc_objects.wipe_all()
        self._create_network(*args, **kwargs)
        assert self.nodes is not None

    @abstractmethod
    def _create_network(self, *args, **kwargs):
        pass

    def copy_dict(self):
        return {
            "save_to_pickle": self.save_to_pickle,
            "load_from_pickle": self.load_from_pickle,
            "load_solution": self.load_solution,
            "num_cores_jacobian": self.num_cores_jacobian,
            "settings": copy(self.settings),
        }

    def __copy__(self):
        return RCNetwork(**self.copy_dict())

    @property
    def nodes(self):
        return self.rc_objects.nodes

    @property
    def hash(self):
        """
        Compute a deterministic hash for the `RCNetwork` where node identity (class name + obj.id) and topology matter.

        For Capacitor instances, an optional internal_heat_source (identified by its id) is encoded as a node attribute.

        For Cell subclass instances, position and delta arrays are encoded.

        Returns
        -------
        str :
            SHA-256 hex digest of the canonical edge and node representation.
        """
        if self.__hash is None:

            def node_key(_obj) -> str:
                return f"{type(_obj).__name__}:{_obj.id}"

            def array_str(arr: np.ndarray) -> str:
                return ",".join(f"{v:.17g}" for v in arr.ravel())

            graph = nx.Graph()
            for obj in self.rc_objects.all:
                attrs = {}
                if isinstance(obj, Capacitor):
                    attrs["heat_source_id"] = (
                        obj.internal_heat_source.id if obj.internal_heat_source is not None else None
                    )
                if isinstance(obj, Cell):
                    attrs["position"] = array_str(obj.position)
                    attrs["delta"] = array_str(obj.delta)
                graph.add_node(node_key(obj), **attrs)

            # loop over all linked/connected network objects
            for obj in self.rc_objects.all:
                for neighbour in obj.neighbours:
                    graph.add_edge(node_key(obj), node_key(neighbour))

            node_str = "|".join(
                f"{nid}#{data}"
                for nid, data in sorted((nid, str(sorted(data.items()))) for nid, data in graph.nodes(data=True))
            )
            edge_str = "|".join(sorted(f"{min(u, v)}-{max(u, v)}" for u, v in graph.edges()))
            canonical = f"nodes:{node_str};edges:{edge_str}"
            self.__hash = hashlib.sha256(canonical.encode()).hexdigest()
        return self.__hash

    @property
    def time_steps(self) -> list:
        """
        Returns a list with all time steps.

        Returns
        -------
        list :
            The time steps.
        """
        return self.rc_solution.time_steps

    def reset_properties(self):
        self._temperature_vector_symbol = None

    @property
    def inputs(self) -> list[EquationItemInput]:
        return self.rc_objects.inputs

    def change_static_dynamic(self, calculate_static: bool | str):
        if isinstance(calculate_static, str):
            match calculate_static.lower():
                case "static" | "statisch" | "s":
                    calculate_static = True
                case _:
                    calculate_static = False
        self.settings.calculate_static = calculate_static

    def get_node_by_id(self, _id: str | int):
        """
        Returns the node with the given id.

        Parameters
        ----------
        _id : str | int
            The id of the node.

        Returns
        -------
        TemperatureNode | InternalHeatSource :
        """
        if isinstance(_id, str):
            _id = int(_id)
        return next((x for x in self.rc_objects.all_equation_objects if x.id == _id), None)

    def no_infinity(self, sp_matrix: SparseMatrix | spmatrix | sparray) -> bool:
        """
        Checks the given sparse matrix for infinity entries and symbolic singularities.

        Notes
        -----
        Saves a dict, which maps each free sympy symbol to a set of values at which at least one symbolic entry
        diverges. Empty if no symbolic entries exist.

        Parameters
        ----------
        sp_matrix : SparseMatrix | spmatrix | sparray
            A sparse matrix/vector to check, may contain numeric values or sympy
            expressions.

        Returns
        -------
        tuple[bool, dict] :
            bool : True if no numeric infinity was found.
        """
        sp_matrix: SparseMatrix | spmatrix | sparray
        if isinstance(sp_matrix, SparseMatrix) or isinstance(sp_matrix, ImmutableSparseMatrix):
            entries = sp_matrix.todok().values()
        else:
            sp_matrix: spmatrix | sparray
            entries = sp_matrix.data

        for entry in entries:
            if isinstance(entry, Basic):
                if not entry.free_symbols:
                    if entry in (sym.oo, -sym.oo, sym.zoo, sym.nan):
                        return False
                else:
                    _, denominator = sym.fraction(sym.cancel(entry))
                    if denominator != sym.Integer(1):
                        for s in denominator.free_symbols:
                            solution = sym.solve(denominator, s)
                            self.forbidden_values.setdefault(s, set()).update(solution)
            else:
                if np.isinf(entry):
                    return False

        return True

    def _get_matrix_symbol(self, key: str) -> SparseMatrix | ImmutableSparseMatrix:
        """
        Returns the desired matrix in symbolic notation.

        Parameters
        ----------
        key : str
            Either "symbol" or "input" to determine the matrix type.

        Returns
        -------
        SparseMatrix | ImmutableSparseMatrix :
            The (sympy) symbolic notation of the matrix.
        """
        attr = f"_{key}_matrix_symbol"
        if getattr(self, attr) is None:
            self.make_system_matrices()
        return getattr(self, attr)

    def _build_matrix_function(self, key: str) -> Callable:
        """
        Builds the desired matrix lambda function using the symbols matrix, respectively.

        Parameters
        ----------
        key : str
            Either "symbol" or "input" to determine the matrix type.

        Returns
        -------
        Callable :
            The function of the matrix.
        """
        matrix_symbol = self._get_matrix_symbol(key)
        all_symbols = self.get_symbols()
        if self.get_time_dependent_symbols():
            ordered_symbols = [
                next((s for s in matrix_symbol.free_symbols if s.name == symbol.name), symbol) for symbol in all_symbols
            ]
            return lambdify(ordered_symbols, matrix_symbol, "sympy")
        return lambdify(all_symbols, matrix_symbol, "scipy")

    def _build_matrix_direct(self, key: str) -> spmatrix:
        """
        Bypasses lambdify by substituting all symbol values via name-based xreplace.

        Parameters
        ----------
        key : str
            Either "symbol" or "input" to determine the matrix type.

        Notes
        -----
        The replace must be done using the name of the symbols and not the objects itself because they might be loaded
        from disk and might not match, but the names do.

        Returns
        -------
        scipy.spmatrix :
            A scipy sparse matrix with all values substituted.
        """
        matrix_symbol = self._get_matrix_symbol(key)
        name_to_value = {s.name: v for s, v in zip(self.get_symbols(), self.get_values())}
        free = matrix_symbol.free_symbols
        substitution_map = {s: name_to_value[s.name] for s in free if s.name in name_to_value}

        dok = matrix_symbol.todok()
        rows, cols, data = [], [], []
        for (i, j), expr in dok.items():
            rows.append(i)
            cols.append(j)
            data.append(float(expr.xreplace(substitution_map)))

        return coo_matrix((data, (rows, cols)), shape=matrix_symbol.shape).tocsr()

    # import warnings
    # import logging
    # import pickle
    # from concurrent.futures import ProcessPoolExecutor
    # from pathlib import Path
    # from typing import Callable
    #
    # import numba
    # import numpy as np
    # from scipy.sparse import coo_matrix, csr_matrix
    # from sympy import lambdify
    # from sympy.printing import ccode
    #
    # def _xreplace_element(args: tuple) -> object:
    #     """Apply xreplace to a single expression."""
    #     expr, static_map = args
    #     return expr.xreplace(static_map)
    #
    # def _build_c_source(reduced_exprs: list, td_ordered: list, func_name: str) -> str:
    #     """
    #     Generates a C source file with a single function iterating over all nonzero
    #     expressions.
    #
    #     Parameters
    #     ----------
    #     reduced_exprs : list
    #         Sympy expressions with static symbols already substituted.
    #     td_ordered : list
    #         Ordered time-dependent sympy symbols.
    #     func_name : str
    #         Name of the generated C function.
    #
    #     Returns
    #     -------
    #     str :
    #         C source code as a string.
    #     """
    #     args = ", ".join(f"double {s.name}" for s in td_ordered)
    #     lines = [
    #         "#include <stddef.h>",
    #         f"void {func_name}({args}, double *out, size_t n) {{",
    #     ]
    #     for i, expr in enumerate(reduced_exprs):
    #         lines.append(f"    out[{i}] = {ccode(expr)};")
    #     lines.append("}")
    #     return "\n".join(lines)
    #
    # def _compile_c_function(
    #         source: str,
    #         func_name: str,
    #         n_out: int,
    #         cache_path: Path,
    # ) -> Callable:
    #     """
    #     Compiles C source to a shared library and returns a callable via ctypes.
    #
    #     Parameters
    #     ----------
    #     source : str
    #         C source code string.
    #     func_name : str
    #         Name of the C function to load.
    #     n_out : int
    #         Number of output values (nnz).
    #     cache_path : Path
    #         Path to write the compiled .so / .dll.
    #
    #     Returns
    #     -------
    #     Callable :
    #         Python callable wrapping the compiled C function.
    #     """
    #     import ctypes
    #     import subprocess
    #     import tempfile
    #
    #     src_path = cache_path.with_suffix(".c")
    #     src_path.write_text(source)
    #
    #     result = subprocess.run(
    #         ["gcc", "-O3", "-shared", "-fPIC", "-o", str(cache_path), str(src_path)],
    #         capture_output=True,
    #         text=True,
    #     )
    #     if result.returncode != 0:
    #         raise RuntimeError(result.stderr)
    #
    #     lib = ctypes.CDLL(str(cache_path))
    #     fn = getattr(lib, func_name)
    #     fn.restype = None
    #
    #     out_type = ctypes.c_double * n_out
    #
    #     def c_callable(*td_vals: float) -> np.ndarray:
    #         out = out_type()
    #         fn(*[ctypes.c_double(v) for v in td_vals], out, ctypes.c_size_t(n_out))
    #         return np.frombuffer(out, dtype=np.float64).copy()
    #
    #     return c_callable

    # def _prepare_matrix_ingredients(
    #         self, key: str, parallel: bool
    # ) -> tuple[list, list, np.ndarray, np.ndarray, tuple, list]:
    #     """
    #     Extracts and reduces nonzero expressions, substituting all static symbols.
    #
    #     Parameters
    #     ----------
    #     key : str
    #         Either "symbol" or "input" to determine the matrix type.
    #     parallel : bool
    #         If True, parallelizes static substitution via ProcessPoolExecutor.
    #
    #     Returns
    #     -------
    #     tuple :
    #         td_ordered, reduced_exprs, rows, cols, shape, raw exprs (unreduced)
    #     """
    #     matrix_symbol = self._get_matrix_symbol(key)
    #     all_symbols = self.get_symbols()
    #     all_values = self.get_values()
    #     td_symbols = self.get_time_dependent_symbols()
    #     td_names = {s.name for s in td_symbols}
    #
    #     static_map = {
    #         s_mat: val
    #         for sym, val in zip(all_symbols, all_values)
    #         if sym.name not in td_names
    #         for s_mat in matrix_symbol.free_symbols
    #         if s_mat.name == sym.name
    #     }
    #
    #     td_ordered = [
    #         next(s for s in matrix_symbol.free_symbols if s.name == td.name)
    #         for td in td_symbols
    #         if any(s.name == td.name for s in matrix_symbol.free_symbols)
    #     ]
    #
    #     dok = matrix_symbol.todok()
    #     shape = matrix_symbol.shape
    #     keys, exprs = zip(*dok.items()) if dok else ([], [])
    #     rows = np.array([k[0] for k in keys], dtype=np.int32)
    #     cols = np.array([k[1] for k in keys], dtype=np.int32)
    #
    # TODO: do not do it like that, it is worse than the solution that already exists.
    #     if parallel:
    #         tasks = [(expr, static_map) for expr in exprs]
    #         with ProcessPoolExecutor() as executor:
    #             reduced_exprs = list(executor.map(_xreplace_element, tasks))
    #     else:
    #         reduced_exprs = [expr.xreplace(static_map) for expr in exprs]
    #
    #     return td_ordered, reduced_exprs, rows, cols, shape
    #
    # TODO: This is worse than the current solution, but the other version (numby/c...) should be implemented to speed
    #  things up. But attention: Currently, it is just vibe coded...
    # def _build_matrix_function_lambdify(
    #         self, key: str, parallel: bool = False
    # ) -> Callable:
    #     """
    #     Builds the matrix function using lambdify with numpy backend.
    #
    #     Parameters
    #     ----------
    #     key : str
    #         Either "symbol" or "input" to determine the matrix type.
    #     parallel : bool
    #         If True, parallelizes static symbol substitution.
    #
    #     Returns
    #     -------
    #     Callable :
    #         Function accepting td symbol values, returning a csr_matrix.
    #     """
    #     td_ordered, reduced_exprs, rows, cols, shape = (
    #         self._prepare_matrix_ingredients(key, parallel)
    #     )
    #
    #     if not len(rows):
    #         empty = csr_matrix(shape, dtype=float)
    #
    #         def assembled(*_) -> csr_matrix:
    #             return empty
    #
    #         return assembled
    #
    #     data_func = lambdify(td_ordered, reduced_exprs, "numpy")
    #     template = coo_matrix(
    #         (np.ones(len(rows), dtype=float), (rows, cols)), shape=shape
    #     ).tocsr()
    #
    #     def assembled(*td_vals: float) -> csr_matrix:
    #         template.data[:] = np.asarray(data_func(*td_vals), dtype=float)
    #         return template
    #
    #     return assembled
    #
    # def _build_matrix_function_numba(self, key: str, parallel: bool = False) -> Callable:
    #     """
    #     Builds the matrix function using a numba-JIT compiled callable, with
    #     caching to self.save_folder_path keyed by self.hash.
    #
    #     Parameters
    #     ----------
    #     key : str
    #         Either "symbol" or "input" to determine the matrix type.
    #     parallel : bool
    #         If True, parallelizes static symbol substitution.
    #
    #     Returns
    #     -------
    #     Callable :
    #         Function accepting td symbol values, returning a csr_matrix.
    #     """
    #     td_ordered, reduced_exprs, rows, cols, shape = (
    #         self._prepare_matrix_ingredients(key, parallel)
    #     )
    #
    #     if not len(rows):
    #         empty = csr_matrix(shape, dtype=float)
    #
    #         def assembled(*_) -> csr_matrix:
    #             return empty
    #
    #         return assembled
    #
    #     cache_path = Path(self.save_folder_path) / f"{self.hash}_{key}_numba.pkl"
    #
    #     if cache_path.exists():
    #         with open(cache_path, "rb") as f:
    #             data_func = pickle.load(f)
    #     else:
    #         data_func = lambdify(td_ordered, reduced_exprs, "numpy")
    #         data_func_nb = numba.njit(data_func, cache=True)
    #         with open(cache_path, "wb") as f:
    #             pickle.dump(data_func_nb, f)
    #         data_func = data_func_nb
    #
    #     template = coo_matrix(
    #         (np.ones(len(rows), dtype=float), (rows, cols)), shape=shape
    #     ).tocsr()
    #
    #     def assembled(*td_vals: float) -> csr_matrix:
    #         template.data[:] = np.asarray(data_func(*td_vals), dtype=float)
    #         return template
    #
    #     return assembled
    #
    # def _build_matrix_function_c(self, key: str, parallel: bool = False) -> Callable:
    #     """
    #     Builds the matrix function using a compiled C shared library via ctypes,
    #     falling back to numba if compilation fails.
    #
    #     Parameters
    #     ----------
    #     key : str
    #         Either "symbol" or "input" to determine the matrix type.
    #     parallel : bool
    #         If True, parallelizes static symbol substitution.
    #
    #     Returns
    #     -------
    #     Callable :
    #         Function accepting td symbol values, returning a csr_matrix.
    #     """
    #     td_ordered, reduced_exprs, rows, cols, shape = (
    #         self._prepare_matrix_ingredients(key, parallel)
    #     )
    #
    #     if not len(rows):
    #         empty = csr_matrix(shape, dtype=float)
    #
    #         def assembled(*_) -> csr_matrix:
    #             return empty
    #
    #         return assembled
    #
    #     func_name = f"matrix_func_{self.hash}_{key}"
    #     so_path = Path(self.save_folder_path) / f"{func_name}.so"
    #
    #     try:
    #         if so_path.exists():
    #             import ctypes
    #             lib = ctypes.CDLL(str(so_path))
    #             fn = getattr(lib, func_name)
    #             n_out = len(rows)
    #             out_type = ctypes.c_double * n_out
    #
    #             def data_func(*td_vals: float) -> np.ndarray:
    #                 out = out_type()
    #                 fn(
    #                     *[ctypes.c_double(v) for v in td_vals],
    #                     out,
    #                     ctypes.c_size_t(n_out),
    #                 )
    #                 return np.frombuffer(out, dtype=np.float64).copy()
    #         else:
    #             source = _build_c_source(reduced_exprs, td_ordered, func_name)
    #             data_func = _compile_c_function(
    #                 source, func_name, len(rows), so_path
    #             )
    #     except Exception as e:
    #         print(
    #             f"C compilation failed for '{key}' matrix ({e}), falling back to numba."
    #         )
    #         return self._build_matrix_function_numba(key, parallel=parallel)
    #
    #     template = coo_matrix(
    #         (np.ones(len(rows), dtype=float), (rows, cols)), shape=shape
    #     ).tocsr()
    #
    #     def assembled(*td_vals: float) -> csr_matrix:
    #         template.data[:] = np.asarray(data_func(*td_vals), dtype=float)
    #         return template
    #
    #     return assembled
    #
    # def _build_matrix_function(
    #         self, key: str, strategy: str | None = None
    # ) -> Callable:
    #     """
    #     Dispatcher selecting the matrix function build strategy.
    #
    #     Parameters
    #     ----------
    #     key : str
    #         Either "symbol" or "input" to determine the matrix type.
    #     strategy : str | None
    #         One of "lambdify", "parallel", "numba", "c". If None, falls back
    #         to self.strategy set at __init__.
    #
    #     Returns
    #     -------
    #     Callable :
    #         Function accepting td symbol values, returning a csr_matrix.
    #     """
    #     s = strategy if strategy is not None else self.strategy
    #     if s == "lambdify":
    #         return self._build_matrix_function_lambdify(key, parallel=False)
    #     if s == "parallel":
    #         return self._build_matrix_function_lambdify(key, parallel=True)
    #     if s == "numba":
    #         return self._build_matrix_function_numba(key, parallel=False)
    #     if s == "c":
    #         return self._build_matrix_function_c(key, parallel=False)
    #     raise ValueError(f"Unknown strategy '{s}'. Choose from: lambdify, parallel, numba, c.")
    #
    # def _build_matrix(
    #         self, key: str, strategy: str | None = None
    # ) -> csr_matrix:
    #     """
    #     Inputs all values into the desired matrix function.
    #
    #     Parameters
    #     ----------
    #     key : str
    #         Either "symbol" or "input" to determine the matrix type.
    #     strategy : str | None
    #         Overrides self.strategy if provided.
    #
    #     Returns
    #     -------
    #     csr_matrix :
    #         The desired matrix.
    #     """
    #     attr = f"_{key}_matrix"
    #     if getattr(self, attr) is None:
    #         if not self.get_time_dependent_symbols():
    #             result = self._build_matrix_direct(key)
    #         else:
    #             result = self._build_matrix_function(key, strategy=strategy)(
    #                 *self.get_values()
    #             )
    #         assert self.no_infinity(result), (
    #             f"Infinity detected in {key} matrix. System cannot be solved."
    #         )
    #         setattr(self, attr, result)
    #     return getattr(self, attr)

    def _build_matrix(self, key: str) -> SparseMatrix | ImmutableSparseMatrix | spmatrix | sparray:
        """
        Inputs all values (can be symbolic values) into the desired matrix function.

        Parameters
        ----------
        key : str
            Either "symbol" or "input" to determine the matrix type.

        Returns
        -------
        SparseMatrix | ImmutableSparseMatrix | spmatrix | sparray :
            The desired matrix. If no time dependent variables are used, it is a scipy sparse matrix, otherwise it's a
            sympy SparseMatrix.
        """
        attr = f"_{key}_matrix"
        if getattr(self, attr) is None:
            if self.get_time_dependent_symbols():
                result = self._build_matrix_function(key)(*self.get_values())
            else:
                result = self._build_matrix_direct(key)
            assert self.no_infinity(result), f"Infinity detected in {key} matrix. System cannot be solved."
            setattr(self, attr, result)
        return getattr(self, attr)

    @property
    def system_matrix_symbol(self) -> SparseMatrix | ImmutableSparseMatrix:
        return self._get_matrix_symbol("system")

    @property
    def input_matrix_symbol(self) -> SparseMatrix | ImmutableSparseMatrix:
        return self._get_matrix_symbol("input")

    @property
    def system_matrix_function(self) -> Callable:
        return self._build_matrix_function("system")

    @property
    def input_matrix_function(self) -> Callable:
        return self._build_matrix_function("input")

    @property
    def system_matrix(self) -> SparseMatrix | ImmutableSparseMatrix | spmatrix | sparray:
        return self._build_matrix("system")

    @property
    def input_matrix(self) -> SparseMatrix | ImmutableSparseMatrix | spmatrix | sparray:
        return self._build_matrix("input")

    @property
    def temperature_vector_symbol(self) -> list:
        if self._temperature_vector_symbol is None:
            result = [node.temperature_symbol for node in self.nodes]
            self._temperature_vector_symbol = result
        return self._temperature_vector_symbol

    @property
    def temperature_vector(self) -> np.ndarray:
        result = [node.temperature for node in self.nodes]
        return np.array(result).flatten()

    @property
    def input_vector(self) -> np.ndarray:
        result = [n for input_item in self.inputs for n in input_item.values]
        return np.array(result).flatten()

    @property
    def input_vector_symbol(self) -> np.ndarray:
        if self._input_vector_symbol is None:
            result = []
            if self.inputs is not None and self.inputs != []:
                result = [n for input_item in self.inputs for n in input_item.symbols]
            self._input_vector_symbol = np.array(result).flatten()
        return self._input_vector_symbol

    # @property
    # def seconds_of_day(self):
    #     """
    #     Returns the seconds that have already passed on the day of ``self.start_time``.
    #
    #     Returns
    #     -------
    #     float | int :
    #         The passed seconds of the day.
    #     """
    #     return (self.settings.start_date - self.settings.start_date.astype("datetime64[D]")) / np.timedelta64(1, "s")

    @property
    def save_folder_path(self):
        if self.settings.save_folder_path is None:
            return run_folder
        return self.settings.save_folder_path

    @property
    def pickle_path(self) -> str:
        filename = f"{self.hash}.pickle"
        return os.path.normpath(os.path.join(self.save_folder_path, filename))

    def pickle_path_result(self, t_span, name_add_on=None):
        name_add_on = add_leading_underscore(name_add_on)
        filename = f"{self.hash}{name_add_on}_{int(t_span[1])}_result.pickle"
        return os.path.normpath(os.path.join(self.save_folder_path, filename))

    @property
    def pickle_path_single_solution(self) -> str:
        filename = f"{self.hash}_single_solution.pickle"
        return os.path.normpath(os.path.join(self.save_folder_path, filename))

    def pickle_path_solution(self, t_span, name_add_on=None) -> str:
        name_add_on = add_leading_underscore(name_add_on)
        filename = f"{self.hash}{name_add_on}_{int(t_span[0])}_{int(t_span[1])}_solution.pickle"
        return os.path.normpath(os.path.join(self.save_folder_path, filename))

    def save_matrices(self):
        if self.save_to_pickle:
            file_path = self.pickle_path
            matrices = [
                self._system_matrix_symbol,
                self._input_matrix_symbol,
                self._input_vector_symbol,
                self._temperature_vector_symbol,
                self.forbidden_values,
            ]
            with open(file_path, "wb") as f:
                pickle.dump(matrices, f)

    def load_matrices(self):
        file_path = self.pickle_path
        if os.path.exists(file_path):
            with open(file_path, "rb") as f:
                matrices = pickle.load(f)
            self._system_matrix_symbol = matrices[0]
            self._input_matrix_symbol = matrices[1]
            self._input_vector_symbol = matrices[2]
            self._temperature_vector_symbol = matrices[3]
            self.forbidden_values = matrices[4]
            print("matrices loaded")
            return True
        else:
            print("No network found nor loaded.")
            return False

    def save_last_step_solution(self, pickle_path_single_solution: str = None):
        """
        Saves the last time step solution.
        """
        if pickle_path_single_solution is None:
            pickle_path_single_solution = self.pickle_path_single_solution
        file_path = pickle_path_single_solution
        self.rc_solution.save_last_step(file_path)

    def load_initial_values(self, return_bool: bool = False, pickle_path_single_solution: str = None) -> bool:
        """
        Loads the last time step solution (temperature vector) and sets it as initial values.
        """
        if pickle_path_single_solution is None:
            pickle_path_single_solution = self.pickle_path_single_solution
        file_path = pickle_path_single_solution
        if os.path.exists(file_path):
            with open(file_path, "rb") as f:
                solution_tuple = pickle.load(f)
            temp_vector = solution_tuple[0]
            input_vector = solution_tuple[1]
            for node, temp in zip(self.rc_objects.nodes, temp_vector):
                node.initial_temperature = temp
            for item, value in zip(self.inputs, input_vector):
                item.initial_value = value
            if return_bool:
                return True
        else:
            print("No temperature vector found nor loaded.")
            if return_bool:
                return False

    @property
    def inhomogeneous_system(self) -> bool:
        """
        Returns True if inputs are existing and the network is inhomogeneous. False otherwise.

        Returns
        -------
        bool :
        """
        if self.rc_objects.inputs is None or self.rc_objects.inputs == []:
            return False
        return True

    def solve_network(
        self,
        t_span: tuple | Any = None,
        print_progress=False,
        name_add_on: str = "",
        check_courant: bool = True,
        time_dependent_function: Callable = None,
        hook_function: Callable = None,
        expected_solution_size_mb=5000,
        **kwargs: dict[str : int | Any],
    ):
        """
        Solves the network at the given times.

        If time_vector is None, one second is calculated.

        Parameters
        ----------
        t_span : tuple | Any
            Interval of integration (t0, tf). The solver starts with t=t0 and integrates until it reaches t=tf.
            Both t0 and tf must be floats or values interpretable by the float conversion function.
        print_progress : bool, optional
            If True, some print outs are made during solving to get the time step that is currently simulated.
        name_add_on : str, optional
            Optional add-on to the name of in-between saves that is placed after the hash value (separated by "_").
            Example save name:
                42395d3d9f07f06ce9c9cb609b406aa54fc2dc5e8c4d9cc75987d9a02541ad2f_nameAddOn_zw_000001080_h.pickle
        check_courant : bool, optional
            If True, self.check_courant(0.4) is run before simulating.
        time_dependent_function : Callable
            A function returning the values for all time dependent symbols that are in the matrices in the same order as
            self.get_time_dependent_symbols().
            This function is required if time dependent symbols exist.
            It must return an iterable (e.g. list)
        hook_function : Callable, optional
            A function that is run before the network is solved using solve_ivp.
            Can be used to catch the time before the solving actually starts (e.g. used in `PerformanceTest`\).
        expected_solution_size_mb : int | float, optional
            The expected solution size in Megabytes. Is used for RAM-Management in ``SystemHandler.solve()``\.
            The solution size depends on the size of the RC network and number of saved time steps.
        kwargs : dict[str: int | Any], optional
            Passed to SystemHandler.

        Returns
        -------
        scipy.integrate._ivp.ivp.OdeResult :
            The solution of the network (time and temperatures of all nodes).
            See: https://docs.scipy.org/doc/scipy/reference/generated/scipy.integrate.solve_ivp.html#solve-ivp
        """
        if self.get_time_dependent_symbols():
            assert time_dependent_function

        continued_simulation = False
        if self.load_solution or self.continue_canceled:
            success = self.rc_solution.load_solution(
                self.pickle_path_solution(t_span, name_add_on), last_time_step=t_span[-1]
            )
            if not success:
                success = self.rc_solution.load_solution(
                    self.pickle_path_result(t_span, name_add_on), last_time_step=t_span[-1]
                )
            if success or (not isinstance(success, bool) and success == 0):  # ==0 because 0 could be the last time
                # step (will never be the case.... -.-)
                if not isinstance(success, bool):
                    if not self.continue_canceled:
                        self.rc_solution.delete_solution_except_first()
                        print(f"Partial solution detected but not used because continue_canceled is False.")
                    else:
                        print(
                            f"Simulation is started at loaded time step {success} on {success / t_span[-1] * 100:.2f} %."
                        )
                        t_span = (success, t_span[-1])
                        continued_simulation = True
                else:
                    print("Solution was loaded from file.")
                    return None

        max_step = 1
        if check_courant and (self.rc_objects.mass_flow_nodes is not None or self.rc_objects.mass_flow_nodes != []):
            loop_counter = 0
            while loop_counter < 1000:
                try:
                    self.check_courant(max_step)  # approximated maximum time step used during iterations.
                    # if no error
                    break
                except HighCourantNumberError:
                    loop_counter += 1
                    max_step *= 0.99

        temperature_vector = np.array(self.temperature_vector).flatten()
        system_matrix = self.system_matrix
        time_symbols = self.get_time_dependent_symbols()
        if time_symbols:
            system_matrix = SparseSymbolicEvaluator(system_matrix, time_symbols)

        system_handler_kwargs = {
            "system_matrix": system_matrix,
            "rc_solution": self.rc_solution,
            "settings": self.settings,
            "print_progress": print_progress,
            "print_points": np.linspace(t_span[0], t_span[-1], 20+1),
            "batch_end": t_span[-1],
            "time_dependent_function": time_dependent_function,
        }

        # create the time_steps to solve the results (every X seconds a value)
        t_eval = np.linspace(
            t_span[0], t_span[1], max(1, int((t_span[1] - t_span[0]) / self.settings.save_all_x_seconds) + 1)
        )

        if self.inhomogeneous_system:
            input_matrix = self.input_matrix
            if time_symbols:
                input_matrix = SparseSymbolicEvaluator(input_matrix, time_symbols)
            input_vector = self.input_vector

            # Each Input can be called as a function to calculate new boundary values during simulation:
            functions_list = self.rc_objects.inputs
            # Also each Input has some functions that can be called independently of the object that return values for
            # the calculation.
            kwargs_functions = {}
            for item in self.rc_objects.inputs:
                kwargs_functions.update(item.get_kwargs_functions())  # Values should be overwritten so that the same
                # values are calculated only once

            system_handler_kwargs.update(
                {
                    "input_matrix": input_matrix,
                    "input_vector": input_vector,
                    "functions_list": functions_list,
                    "kwargs_functions": kwargs_functions,
                    "t_eval": t_eval,
                    "first_time": t_span[0],
                }
            )

        # only update the keys that are in the predefined dictionary (it would also work if everything is passed anyway)
        system_handler_kwargs.update({k: kwargs[k] for k in system_handler_kwargs if k in kwargs})

        system_handler = self.system_handler_type(**system_handler_kwargs)
        save_prefix = f"{self.hash}"
        if name_add_on:
            save_prefix += f"_{name_add_on.removeprefix('_').removesuffix('_')}"
        solve_handler = SolveIVPHandler(
            system_handler=system_handler,
            save_prefix=save_prefix,
            solve_settings=self.settings.solve_settings,
        )
        if hook_function is not None:
            hook_function()
        solve_handler.solve(
            t_span=t_span,
            y0=temperature_vector,
            t_eval=t_eval,
            continued_simulation=continued_simulation,
            expected_solution_size_mb=expected_solution_size_mb,
        )

    @property
    def system_handler_type(self):
        """
        Returns the SystemHandler type depending on which system (in/homogeneous) is needed.

        Returns
        -------
        type :
            The system handler type.
        """
        if self.inhomogeneous_system:
            return InhomogeneousSystemHandler
        return HomogeneousSystemHandler

    @property
    def all_objects(self) -> list:
        return [*(self.rc_objects.resistors or []), *(self.rc_objects.nodes or []), *(self.rc_objects.inputs or [])]

    @property
    def objects_with_identical_symbols(self) -> list:
        """
        Get all objects with symbols that are relevant for the system matrix.

        You cannot just use every object, because some (e.g. Resistors) can be summarized in local groups with one
        symbol representing the whole group, like the equivalent resistance of multiple connected Resistors.

        No ``InternalHeatSource`` s are returned, because their symbol is already represented in the corresponding Node.

        Returns
        -------
        list :
            All network objects without the ones that are already taken into account by the symbols of another.
            The list has the same order every time it is created.
        """

        def filter_resistors(resistor_list):
            # Create set of all resistors for O(1) lookups
            all_resistors = {obj for obj in resistor_list if isinstance(obj, Resistor)}
            to_exclude = set()

            # Collect all resistors to exclude in order of appearance
            for obj in resistor_list:
                if isinstance(obj, Resistor) and obj not in to_exclude:
                    inbetween = set(obj.all_resistors_inbetween) - {obj}
                    to_exclude.update(inbetween & all_resistors)

            # Filter maintaining original order
            return [obj for obj in resistor_list if not obj in to_exclude]

        result = [rc_obj for rc_obj in self.all_objects if not isinstance(rc_obj, InternalHeatSource)]
        return filter_resistors(result)

    def get_symbols(self):
        """
        Returns a list with all symbols, except time dependent symbols.

        Returns
        -------
        list :
            All symbols, except time dependent symbols.
        """
        all_symbols = [symb for rc_object in self.objects_with_identical_symbols for symb in rc_object.symbols]
        return all_symbols

    def get_values(self):
        """
        Returns a list with all values, except of time dependent symbols.

        Returns
        -------
        list :
            All values, except of time dependent symbols.
        """
        all_values = [
            val if isinstance(val, Basic) else np.float64(val)
            for rc_object in self.objects_with_identical_symbols
            for val in rc_object.values
        ]
        return all_values

    def get_time_dependent_symbols(self) -> list:
        """
        A list with all time dependent symbols but each of it is only added once.

        Returns
        -------
        list :
            The time dependent symbols.
        """
        symbols = []
        seen = set()
        for rc_object in self.objects_with_identical_symbols:
            for symb in rc_object.time_dependent_symbols:
                if symb not in seen:
                    seen.add(symb)
                    symbols.append(symb)
        return symbols

    def get_symbols_and_values(self) -> tuple[list, list]:
        """
        Return two lists of first: all symbols and second: all associated values of all rc objects.

        Returns
        -------
        tuple[list, list] :

        """
        return self.get_symbols(), self.get_values()

    def make_system_matrices(self):
        """
        Creates the Jacobian matrices of the RC Network.

        If self.load_from_pickle the whole network will be loaded from pickle file if it exists to prevent heavy
        calculations.

        Returns
        -------
        sympy expression :
            The system matrix as sympy expression.
        """
        success = False
        if self.load_from_pickle:
            try:
                success = self.load_matrices()
            except Exception:
                pass
        if not success:
            # fill system matrix
            terms = []
            involved_symbols: list[set] = []
            temperature_symbols: list[set] = []
            variables = []
            for node in self.nodes:
                # works only for one term
                term, t_symbols, all_symbols = node.temperature_derivative_term()
                terms.append(term)
                involved_symbols.append(all_symbols)
                temperature_symbols.append(t_symbols)
                variables.append(node.temperature_symbol)

            self._system_matrix_symbol = build_jacobian(
                terms, variables, temperature_symbols, num_cores=self.num_cores_jacobian
            )
            print("system matrix created")

            self.save_matrices()

            input_variables = list(self.input_vector_symbol)
            self._input_matrix_symbol = build_jacobian(
                terms, input_variables, involved_symbols, num_cores=self.num_cores_jacobian
            )
            print("input matrix created")

            self.save_matrices()

    def check_courant(self, time_step: float):
        """
        Calculates the Courant number for the whole network and raises an error if its larger than 1.

        Parameters
        ----------
        time_step : float
            The maximum time step in seconds.

        Raises
        ------
        HighCourantNumberError :
            If the courant number is greater than 1 the network will calculate shit.

        """
        # TODO: Do not use the courant number but return a critical maximum time_step to easy raise an error during
        #  iterations. So: no iteration, but calculate the maximum time_step and return this so that it can be set.
        mass_flow_nodes = self.rc_objects.mass_flow_nodes
        mass_flow_node: MassFlowNode
        for mass_flow_node in mass_flow_nodes:
            if mass_flow_node.courant_number(time_step) > 1:
                raise HighCourantNumberError

    def matrix_to_latex_diag(self):
        matrix = self.system_matrix_symbol
        diag_elements = matrix.diagonal()
        matrix_no_diag = matrix - diag(*diag_elements)

        matrix_latex = latex(matrix_no_diag)
        diag_latex = latex(Matrix(diag_elements).reshape(len(diag_elements), 1))

        return f"{matrix_latex} + \\mathrm{{diag}}\\left({diag_latex}\\right)"
