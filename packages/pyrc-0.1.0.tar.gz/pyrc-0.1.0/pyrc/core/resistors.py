#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

from __future__ import annotations

import warnings
from typing import Any
from typing import TYPE_CHECKING

import numpy as np
from sympy import Basic

from pyrc.core.components.resistor import Resistor
from pyrc.core.components.capacitor import Capacitor
from pyrc.core.heat_transfer import alpha_forced_convection_in_pipe
from pyrc.core.components.templates import Solid, Fluid
from pyrc.tools.functions import is_set, check_type, return_type

if TYPE_CHECKING:
    from pyrc.core.nodes import MassFlowNode, Node, ChannelNode
    from pyrc.core.inputs import (
        BoundaryCondition,
        FluidBoundaryCondition,
        FlowBoundaryCondition,
        SolidBoundaryCondition,
    )

np.seterr(divide="ignore")


class MassTransport(Resistor):
    def __init__(self):
        """
        Represents the resistance caused by mass transfer between two `MassFlowNode` s.

        The resistance is calculated automatically.

        Be aware that this `Resistor` doesn't care about Courant number at all. This has to be checked in the Handler
        that starts the simulation.
        """
        super().__init__(resistance=np.nan)
        self.__source: MassFlowNode | Any = None
        self.__sink: MassFlowNode | Any = None
        self._volume_flow: float | Any = None

    @property
    def source(self) -> MassFlowNode:
        if self.__source is None:
            raise AttributeError("Source node has not been set yet.")
        return self.__source

    @source.setter
    def source(self, value: MassFlowNode):
        self.__source = value

    @property
    def sink(self) -> MassFlowNode:
        if self.__sink is None:
            raise AttributeError("Sink node has not been set yet.")
        return self.__sink

    @sink.setter
    def sink(self, value: MassFlowNode):
        self.__sink = value

    @property
    def guess_volume_flow(self):
        return self._volume_flow

    @property
    def volume_flow(self):
        from pyrc.core.nodes import MassFlowNode

        if self._volume_flow is None:
            # create volume flow using one connected MassFlowNode
            for node in self.neighbours:
                if isinstance(node, MassFlowNode):
                    node.propagate_flow()
                    break
        return self._volume_flow

    @property
    def resistance(self) -> float | int:
        from pyrc.core.nodes import FlowBoundaryCondition

        if not is_set(self._resistance):
            # Get volume flow using source and sink of neighbour nodes
            nodes: list = self.nodes
            assert len(nodes) == 2
            if isinstance(nodes[0], FlowBoundaryCondition):
                mfn = nodes[1]
            else:
                mfn = nodes[0]
            resistance = 1 / np.float64(self.volume_flow * mfn.material.density * mfn.material.heat_capacity)

            self._resistance = resistance
        return self._resistance

    # def make_velocity_direction(self):
    #     """
    #     Trigger the process in a `MassFlowNode` neighbour of ``self``.
    #     """
    #     from pyrc.core.nodes import MassFlowNode
    #     for neighbour in self.neighbours:
    #         if isinstance(neighbour, MassFlowNode):
    #             neighbour.make_velocity_direction()
    #             return None  # break out of the method
    #     # raise error otherwise
    #     raise ConnectionError(f"The {type(self)} isn't connected to any MassFlowNode. Damn!")


class CombinedResistor(Resistor):
    def __init__(
        self,
        resistance: float | int | np.number | Basic = np.nan,
        htc: float | int | np.number | Basic = np.nan,
        heat_conduction=True,
        heat_transfer=True,
    ):
        """
        Automated version of Resistor, calculating its resistance based on connected objects.

        The algorithms of this class rely on geometric representations and assume a thermal problem. For most of the
        algorithms the connected capacities and boundary conditions must inherit from `Cell` or at least `Geometric`\.
        Using the geometric information let the algorithm figure out which areas/lengths influence the heat transfer and
        thermal conduction. If you connect a `BoundaryCondition` (not inheriting from Cell/Geometric) you still can use
        this class but must define the direction to this BoundaryCondition manually using ``manual_directions`` and
        ``set_direction()`` of `TemperatureNode` (Capacitor/BoundaryCondition).

        Parameters
        ----------
        resistance : float | int | np.number | sympy.Basic, optional
            The resistance of self. If set, no algorithm is used (and it would be preferable to use Resistor class
            instead).
        htc : float | int | np.number | sympy.Basic, optional
            Heat transfer coefficient that is used, if no other HTC was found (in boundary conditions).
            If not set, an initial value of 5 is used (raising a warning).
        heat_conduction : bool, optional
            Switch on/off heat conductivity.
        heat_transfer : bool, optional
            Switch on/off heat transfer.
        """
        super().__init__(resistance)
        self.heat_conduction: bool = heat_conduction
        self.heat_transfer: bool = heat_transfer
        self.__htc = htc

    @property
    def htc(self):
        if not is_set(self.__htc):
            warnings.warn("Warning: Initial HTC value of 5 is used.")
            self.__htc = 5
        return self.__htc

    @property
    def heat_transfer_coefficient(self):
        return self.htc

    @property
    def resistance(self) -> float | int:
        """
        Determines the resistance accordingly to the nodes the resistor is connected to.

        To get this, look at the pictures of Joel Kimmich from 13.8.2025

        Returns
        -------

        """
        if is_set(self._resistance):
            return self._resistance
        resistance = np.float64(0)

        from pyrc.core.nodes import Node, ChannelNode
        from pyrc.core.inputs import BoundaryCondition, FluidBoundaryCondition, SolidBoundaryCondition

        if len(self.direct_connected_node_templates) == 2:
            if all(isinstance(neighbour, Node) for neighbour in self.neighbours):
                # no BoundaryCondition
                if (
                    all(isinstance(neighbour.material, Solid) for neighbour in self.neighbours)
                    or all(isinstance(neighbour.material, Fluid) for neighbour in self.neighbours)
                    and self.heat_conduction
                ):
                    # heat conduction in both nodes (also for two ChannelNodes)
                    node: Node
                    for i, node in enumerate(self.neighbours):
                        other_node = self.neighbours[(i + 1) % 2]
                        resistance += node.get_conduction_length(other_node) / (
                            node.material.thermal_conductivity * node.get_area(other_node)
                        )
                elif check_type(self.neighbours, ChannelNode, Node):
                    # ChannelNode to Solid: HeatTransfer AND HeatConduction
                    channel_node, node = return_type(self.neighbours, ChannelNode)
                    assert isinstance(node.material, Solid)
                    if self.heat_transfer:
                        # calculate heat transfer in pipe using Nusselt correlation(s)
                        resistance += resistance_channel_heat_transfer(channel_node, node)
                    if self.heat_conduction:
                        resistance += node.get_conduction_length(channel_node) / (
                            node.material.thermal_conductivity * node.get_area(channel_node)
                        )
                else:
                    # solid to fluid: heat transfer in fluid and conduction in solid
                    solid, fluid = return_type(self.neighbours, Solid, [n.material for n in self.neighbours])
                    if self.heat_transfer:
                        effective_area = min(solid.get_area(fluid), fluid.get_area(solid))
                        resistance += 1 / (self.htc * effective_area)
                    if self.heat_conduction:
                        resistance += solid.get_conduction_length(fluid) / (
                            solid.material.thermal_conductivity * solid.get_area(fluid)
                        )
            elif check_type(self.neighbours, BoundaryCondition, Node):
                # 1 BC and 1 Node
                if check_type(self.neighbours, FluidBoundaryCondition, Node):
                    # 1 FluidBC and 1 Node
                    bc, node = return_type(self.neighbours, FluidBoundaryCondition)
                    if isinstance(node.material, Solid):
                        if self.heat_transfer:
                            resistance += resistance_bc_heat_transfer(bc, node)
                    if self.heat_conduction:
                        # for both: (both Fluid) and (Fluid BC and Solid Node)
                        resistance += node.get_conduction_length(bc) / (
                            node.material.thermal_conductivity * node.get_area(bc)
                        )
                elif check_type(self.neighbours, SolidBoundaryCondition, Node):
                    # 1 SolidBC and 1 Node
                    node, bc = return_type(self.neighbours, Node)
                    effective_area = node.get_area(bc)
                    if isinstance(node.material, Fluid) and self.heat_transfer:
                        resistance += 1 / (self.htc * effective_area)
                        # no heat conduction if node is Fluid (is already included in heat transfer)
                    elif self.heat_conduction:
                        # like two solids, but only node is used (so conduction in BC is infinite)
                        resistance += node.get_conduction_length(bc) / (
                            node.material.thermal_conductivity * node.get_area(bc)
                        )
                else:
                    # BC is undefined -> resistance should be given
                    assert check_type(self.neighbours, BoundaryCondition, Node), (
                        "You must use FluidBoundaryCondition or SolidBoundaryCondition or set a resistance/htc value."
                    )
                    bc, node = return_type(self.neighbours, BoundaryCondition)
                    # TODO: Maybe a BC shouldn't get an HTC value because it depends on the cell / the cell AND the BC.
                    if not is_set(bc.htc):
                        htc = self.htc
                        warnings.info("Resistor.htc was used instead of BoundaryCondition.htc.")
                    else:
                        htc = bc.htc
                    warnings.warn("You might consider using FluidBoundaryCondition instead of BoundaryCondition.")
                    resistance += 1 / (htc * node.get_area(bc))
            elif all(isinstance(neighbour, BoundaryCondition) for neighbour in self.neighbours):
                raise ValueError("Two BoundaryConditions cannot be connected directly to each other.")
            else:
                raise ValueError(
                    f"This combination isn't implemented: {self.neighbours}\n{[type(n) for n in self.neighbours]}"
                )
        elif len(self.direct_connected_node_templates) == 0:
            # Only connected to other resistors:
            #  the resistance must be given. But this was already checked, so raise an Error
            raise ValueError("If a Resistor is between two others, its resistance must be given!")
        else:
            # one Node, one/multiple Resistor/s -> only the resistance of this Resistor is returned, no equivalent
            # resistance!
            node: Capacitor = self.direct_connected_node_templates[0]
            other_node: Capacitor = self.get_connected_node(node)
            if isinstance(node, BoundaryCondition):
                assert isinstance(other_node, Node)
                if isinstance(node, FluidBoundaryCondition):
                    if isinstance(other_node.material, Fluid):
                        # FluidBC to Fluid Node -> Own resistance is zero, because BC don't have mass/volume
                        resistance += np.float64(0)
                    elif self.heat_transfer:
                        # FluidBC to Solid Node -> HeatTransfer
                        resistance += resistance_bc_heat_transfer(node, other_node)
                elif isinstance(node, SolidBoundaryCondition):
                    if isinstance(other_node.material, Fluid) and self.heat_transfer:
                        # SolidBC to Fluid -> HeatTransfer
                        resistance += resistance_bc_heat_transfer(node, other_node)
            elif isinstance(node, ChannelNode) and self.heat_transfer:
                # ChannelNode should only be connected to a Solid Node over a HeatConduction Resistor
                assert isinstance(other_node, Node) and isinstance(other_node.material, Solid)
                # HeatTransfer in a round channel
                resistance += resistance_channel_heat_transfer(node, other_node)
            else:
                # one Node (no BC) and one/multiple resistors -> only heat mechanism of self is calculated
                node: Node
                if self.heat_conduction and (
                    isinstance(node.material, Solid)
                    or (
                        isinstance(node.material, Fluid)
                        and (
                            isinstance(other_node, FluidBoundaryCondition)
                            or (isinstance(other_node, Node) and isinstance(other_node.material, Fluid))
                        )
                    )
                ):
                    resistance = node.get_conduction_length(other_node) / (
                        node.material.thermal_conductivity * node.get_area(other_node)
                    )
                elif self.heat_transfer:
                    # self.material is Fluid and other_node is solid
                    # Heat transfer
                    if isinstance(other_node, SolidBoundaryCondition):
                        resistance += resistance_bc_heat_transfer(other_node, node)
                    else:
                        resistance += 1 / (self.htc * node.get_area(other_node))
        return resistance


class HeatConduction(CombinedResistor):
    def __init__(self, resistance=np.nan):
        """
        Represents the resistance caused by heat conduction.

        If the nodes, where the heat conduction takes place, differ in their material (Solid and Fluid) the heat
        conduction is set to 0 (the resistance is set to np.inf), because the heat conduction is included in
        HeatTransfer. So calculating it also in HeatConduction it would be taken into account twice.
        So: Do not forget to create a `HeatTransfer` `Resistor` between such nodes!

        Parameters
        ----------
        resistance : float, optional
            The resistance. If set, it will not be calculated.
        """
        super().__init__(resistance, heat_conduction=True, heat_transfer=False)

    @property
    def htc(self):
        return np.nan


class HeatTransfer(CombinedResistor):
    def __init__(self, resistance=np.nan, htc=np.nan):
        """
        Represents the resistance caused by heat transfer between a solid and a fluid.

        Parameters
        ----------
        resistance : float, optional
            The resistance. If set, it will not be calculated.
        """
        super().__init__(resistance, htc=htc, heat_transfer=True, heat_conduction=False)

    # def single_resistance(self, node: FluidBoundaryCondition | Node):
    #     """
    #     Returns the resistance using the passed node.
    #
    #     The passed node must have a Fluid as material or must be a FluidBoundaryCondition.
    #
    #     Returns
    #     -------
    #     np.float64 :
    #         The resistance.
    #     """
    #     if isinstance(node, Node):
    #         assert isinstance(node.material, Fluid)
    #
    #     else:
    #         assert isinstance(node, FluidBoundaryCondition)


def resistance_bc_heat_transfer(bc: BoundaryCondition, node: Node):
    """
    Returns the resistance of a heat transfer between FluidBC-Solid Node or SolidBC-Fluid Node.

    Parameters
    ----------
    bc : BoundaryCondition
    node : Node

    Returns
    -------
    np.float64
    """
    effective_area = node.get_area(bc)
    assert is_set(bc.heat_transfer_coefficient), "FluidBoundaryCondition has to get a heat transfer coefficient."
    return 1 / (bc.heat_transfer_coefficient * effective_area)


def resistance_channel_heat_transfer(channel_node: ChannelNode, node: Node):
    effective_area = channel_node.get_pipe_area(node)

    # calculate the alpha using Gnielinski
    alpha = alpha_forced_convection_in_pipe(channel_node.diameter, channel_node.velocity, channel_node.material)
    return 1 / (alpha * effective_area)
