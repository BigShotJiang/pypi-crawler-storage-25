#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

from rtree import index
from vpython import color

from pyrc.core.components.resistor import Resistor
from pyrc.core.resistors import CombinedResistor


def connect_cells_with_resistors(cells: list, tolerance: float = 1e-9) -> list[Resistor]:
    """
    Connect cells that share touching surfaces with resistor objects using AABB tree.

    Parameters
    ----------
    cells : list
        List of Cell objects to connect
    tolerance : float
        Floating point tolerance for boundary comparison

    Returns
    -------
    list :
        List of created Resistor objects
    """

    resistors = []
    connections = set()

    # Build R-tree spatial index with cell bounding boxes (3D)
    p = index.Property()
    p.dimension = 3
    idx = index.Index(properties=p)

    for i, cell in enumerate(cells):
        bounds = cell.boundaries  # [-x, x, -y, y, -z, z]
        # rtree expects (minx, miny, minz, maxx, maxy, maxz)
        bbox = (bounds[0], bounds[2], bounds[4], bounds[1], bounds[3], bounds[5])
        idx.insert(i, bbox)

    # Check each cell against candidates from spatial index
    for i, cell1 in enumerate(cells):
        bounds1 = cell1.boundaries

        # Expand bbox slightly for tolerance to catch touching surfaces
        bbox_query = (
            bounds1[0] - tolerance,
            bounds1[2] - tolerance,
            bounds1[4] - tolerance,
            bounds1[1] + tolerance,
            bounds1[3] + tolerance,
            bounds1[5] + tolerance,
        )

        # Query overlapping bounding boxes
        for j in idx.intersection(bbox_query):
            if j <= i:  # Avoid duplicate checks and self-comparison
                continue

            cell2 = cells[j]

            # Check if already connected
            connection_id = tuple(sorted([id(cell1), id(cell2)]))
            if connection_id in connections:
                continue

            # Check if cells have touching surfaces
            bounds2 = cell2.boundaries
            if check_contact_between_cells(bounds1, bounds2, tolerance):
                # Create resistor and connect cells
                resistor = CombinedResistor()
                resistor.double_connect(cell1, cell2)

                resistors.append(resistor)
                connections.add(connection_id)

    return resistors


# vibe coded algorithms to get the connected surfaces visualized.
# it is not updated for this project yet


def check_contact_between_cells(bounds1: list, bounds2: list, tolerance: float | int):
    """
    Check if two cells have touching surfaces.

    Parameters
    ----------
    bounds1 : list
        Boundaries of cell1 [-x, x, -y, y, -z, z]
    bounds2 : list
        Boundaries of cell2 [-x, x, -y, y, -z, z]
    tolerance : float
        Floating point tolerance

    Returns
    -------
    bool
        True if surfaces touch with overlapping area, False otherwise
    """

    # X-axis: check if faces are coplanar and overlap in y,z
    if abs(bounds1[1] - bounds2[0]) < tolerance or abs(bounds1[0] - bounds2[1]) < tolerance:
        y_overlap = min(bounds1[3], bounds2[3]) - max(bounds1[2], bounds2[2])
        z_overlap = min(bounds1[5], bounds2[5]) - max(bounds1[4], bounds2[4])
        if y_overlap > tolerance and z_overlap > tolerance:
            return True

    # Y-axis: check if faces are coplanar and overlap in x,z
    if abs(bounds1[3] - bounds2[2]) < tolerance or abs(bounds1[2] - bounds2[3]) < tolerance:
        x_overlap = min(bounds1[1], bounds2[1]) - max(bounds1[0], bounds2[0])
        z_overlap = min(bounds1[5], bounds2[5]) - max(bounds1[4], bounds2[4])
        if x_overlap > tolerance and z_overlap > tolerance:
            return True

    # Z-axis: check if faces are coplanar and overlap in x,y
    if abs(bounds1[5] - bounds2[4]) < tolerance or abs(bounds1[4] - bounds2[5]) < tolerance:
        x_overlap = min(bounds1[1], bounds2[1]) - max(bounds1[0], bounds2[0])
        y_overlap = min(bounds1[3], bounds2[3]) - max(bounds1[2], bounds2[2])
        if x_overlap > tolerance and y_overlap > tolerance:
            return True

    return False


def visualize_contact_area(bounds1: list, bounds2: list, tolerance: float, contact_color=color.red):
    """
    Create a thin box and cylinder representing the contact area between two cells.

    Parameters
    ----------
    bounds1 : list
        Boundaries of cell1 [-x, x, -y, y, -z, z]
    bounds2 : list
        Boundaries of cell2 [-x, x, -y, y, -z, z]
    tolerance : float
        Floating point tolerance
    contact_color : vpython.color
        Color for contact area visualization

    Returns
    -------
    tuple or None
        (box, cylinder) representing contact area, or None if no contact
    """
    from vpython import box, cylinder, vector

    thickness = tolerance * 10

    # Calculate overlap ranges once
    x_min, x_max = max(bounds1[0], bounds2[0]), min(bounds1[1], bounds2[1])
    y_min, y_max = max(bounds1[2], bounds2[2]), min(bounds1[3], bounds2[3])
    z_min, z_max = max(bounds1[4], bounds2[4]), min(bounds1[5], bounds2[5])

    x_overlap = x_max - x_min
    y_overlap = y_max - y_min
    z_overlap = z_max - z_min

    pos = None
    size = None
    cyl_axis = None

    # X-axis: cell1 +x face touches cell2 -x face
    if abs(bounds1[1] - bounds2[0]) < tolerance < y_overlap and z_overlap > tolerance:
        pos = vector(bounds1[1], (y_min + y_max) / 2, (z_min + z_max) / 2)
        size = vector(thickness, y_overlap, z_overlap)
        delta1_x = bounds1[1] - bounds1[0]
        delta2_x = bounds2[1] - bounds2[0]
        cyl_length = delta1_x / 4 + delta2_x / 4
        cyl_axis = vector(cyl_length, 0, 0)

    # X-axis: cell1 -x face touches cell2 +x face
    elif abs(bounds1[0] - bounds2[1]) < tolerance < y_overlap and z_overlap > tolerance:
        pos = vector(bounds1[0], (y_min + y_max) / 2, (z_min + z_max) / 2)
        size = vector(thickness, y_overlap, z_overlap)
        delta1_x = bounds1[1] - bounds1[0]
        delta2_x = bounds2[1] - bounds2[0]
        cyl_length = delta1_x / 4 + delta2_x / 4
        cyl_axis = vector(-cyl_length, 0, 0)

    # Y-axis: cell1 +y face touches cell2 -y face
    elif abs(bounds1[3] - bounds2[2]) < tolerance < x_overlap and z_overlap > tolerance:
        pos = vector((x_min + x_max) / 2, bounds1[3], (z_min + z_max) / 2)
        size = vector(x_overlap, thickness, z_overlap)
        delta1_y = bounds1[3] - bounds1[2]
        delta2_y = bounds2[3] - bounds2[2]
        cyl_length = delta1_y / 4 + delta2_y / 4
        cyl_axis = vector(0, cyl_length, 0)

    # Y-axis: cell1 -y face touches cell2 +y face
    elif abs(bounds1[2] - bounds2[3]) < tolerance < x_overlap and z_overlap > tolerance:
        pos = vector((x_min + x_max) / 2, bounds1[2], (z_min + z_max) / 2)
        size = vector(x_overlap, thickness, z_overlap)
        delta1_y = bounds1[3] - bounds1[2]
        delta2_y = bounds2[3] - bounds2[2]
        cyl_length = delta1_y / 4 + delta2_y / 4
        cyl_axis = vector(0, -cyl_length, 0)

    # Z-axis: cell1 +z face touches cell2 -z face
    elif abs(bounds1[5] - bounds2[4]) < tolerance < x_overlap and y_overlap > tolerance:
        pos = vector((x_min + x_max) / 2, (y_min + y_max) / 2, bounds1[5])
        size = vector(x_overlap, y_overlap, thickness)
        delta1_z = bounds1[5] - bounds1[4]
        delta2_z = bounds2[5] - bounds2[4]
        cyl_length = delta1_z / 4 + delta2_z / 4
        cyl_axis = vector(0, 0, cyl_length)

    # Z-axis: cell1 -z face touches cell2 +z face
    elif abs(bounds1[4] - bounds2[5]) < tolerance < x_overlap and y_overlap > tolerance:
        pos = vector((x_min + x_max) / 2, (y_min + y_max) / 2, bounds1[4])
        size = vector(x_overlap, y_overlap, thickness)
        delta1_z = bounds1[5] - bounds1[4]
        delta2_z = bounds2[5] - bounds2[4]
        cyl_length = delta1_z / 4 + delta2_z / 4
        cyl_axis = vector(0, 0, -cyl_length)

    if pos is not None and size is not None and cyl_axis is not None:
        contact_box = box(pos=pos, size=size, color=contact_color, opacity=0.7)

        # Calculate cylinder diameter as 1/8 of minimal box dimension (excluding thickness)
        box_dims = [abs(s) for s in [size.x, size.y, size.z] if abs(s) > thickness * 2]
        cyl_radius = min(box_dims) / 16 if box_dims else thickness

        contact_cylinder = cylinder(pos=pos, axis=cyl_axis, radius=cyl_radius, color=contact_color)

        return contact_box, contact_cylinder

    return None
