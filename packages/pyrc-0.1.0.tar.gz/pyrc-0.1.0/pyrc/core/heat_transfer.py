#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

import numpy as np

import sympy as sp

from pyrc.core.components.templates import Fluid

characteristic_length_pipe = 12  # used in alpha_gnielinski_forced_tube_flow_laminar for each ChannelNode


# noinspection PyPep8Naming
def alpha_gnielinski_forced_tube_flow_turbulent(diameter, velocity, fluid_material: Fluid) -> float:
    """
    Return the alpha.

    Parameters
    ----------
    diameter
    velocity
    fluid_material

    Returns
    -------

    """
    Nu = nusselt_gnielinski_forced_tube_flow_turbulent(diameter, velocity, fluid_material)

    return Nu * fluid_material.thermal_conductivity / diameter


# noinspection PyPep8Naming
def nusselt_gnielinski_forced_tube_flow_turbulent(diameter, velocity, fluid_material: Fluid) -> float:
    """
    Return the alpha.

    Parameters
    ----------
    diameter
    velocity
    fluid_material

    Returns
    -------

    """
    Re = diameter * velocity / fluid_material.kin_viscosity
    Pr = fluid_material.Pr

    zeta = (1.8 * np.log10(Re) - 1.5) ** -2

    return (zeta / 8 * Re * Pr) / (1 + 12.7 * (zeta / 8) ** 0.5 * (Pr ** (2 / 3) - 1))


# noinspection PyPep8Naming
def alpha_gnielinski_forced_tube_flow_laminar(diameter, velocity, fluid_material: Fluid) -> float:
    Nu = nusselt_gnielinski_forced_tube_flow_laminar(diameter, velocity, fluid_material)

    return Nu * fluid_material.thermal_conductivity / diameter


# noinspection PyPep8Naming
def nusselt_gnielinski_forced_tube_flow_laminar(diameter, velocity, fluid_material: Fluid) -> float:
    Re = diameter * velocity / fluid_material.kin_viscosity
    Pr = fluid_material.Pr

    L = characteristic_length_pipe

    Nu_d1 = 3.66
    Nu_d2 = 1.615 * (Re * Pr * diameter / L) ** (1 / 3)

    return (Nu_d1**3 + 0.7**3 + (Nu_d2 - 0.7) ** 3) ** (1 / 3)


# noinspection PyPep8Naming
def alpha_gnielinski_forced_tube_flow_transition(diameter, velocity, fluid_material: Fluid) -> float:
    Re = diameter * velocity / fluid_material.kin_viscosity
    gamma = (Re - 2300) / (10**4 - 2300)
    Nu_laminar = nusselt_gnielinski_forced_tube_flow_laminar(diameter, velocity, fluid_material)
    Nu_turbulent = nusselt_gnielinski_forced_tube_flow_turbulent(diameter, velocity, fluid_material)

    Nu = (1 - gamma) * Nu_laminar + gamma * Nu_turbulent

    return Nu * fluid_material.thermal_conductivity / diameter


# noinspection PyPep8Naming
def alpha_forced_convection_in_pipe(diameter, velocity, fluid_material: Fluid) -> float | sp.Basic:
    Re = diameter * velocity / fluid_material.kin_viscosity

    if isinstance(Re, sp.Basic):
        return sp.Piecewise(
            (alpha_gnielinski_forced_tube_flow_laminar(diameter, velocity, fluid_material), Re <= 2300),
            (alpha_gnielinski_forced_tube_flow_transition(diameter, velocity, fluid_material), Re < 10000),
            (alpha_gnielinski_forced_tube_flow_turbulent(diameter, velocity, fluid_material), Re < 10 ** 6),
            (sp.nan, True),
        )
    else:
        if Re <= 2300:
            return alpha_gnielinski_forced_tube_flow_laminar(diameter, velocity, fluid_material)
        elif Re >= 10000:
            if Re < 10**6:
                raise ValueError(f"Reynolds to high: {Re}\nOnly defined for < 10e6")
            return alpha_gnielinski_forced_tube_flow_turbulent(diameter, velocity, fluid_material)
        return alpha_gnielinski_forced_tube_flow_transition(diameter, velocity, fluid_material)


# noinspection PyPep8Naming
def alpha_free_convection_horizontal_wall(length, fluid_material: Fluid) -> float:
    Nu = 0.14 * (fluid_material.Gr * fluid_material.Pr) ** (1 / 3)  # always turbulent
    return Nu * fluid_material.thermal_conductivity / length
