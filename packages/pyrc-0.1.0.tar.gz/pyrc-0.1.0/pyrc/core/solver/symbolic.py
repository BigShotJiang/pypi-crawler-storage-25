#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

from sympy import SparseMatrix, lambdify, Symbol
import numpy as np
from scipy.sparse import csr_matrix, coo_matrix


class SparseSymbolicEvaluator:
    def __init__(self, semi_symbolic_matrix: SparseMatrix, time_symbols: list[Symbol]):
        """
        Parameters
        ----------
        semi_symbolic_matrix : SparseMatrix
            Sparse matrix with time-dependent symbols or numpy array
        time_symbols : list[Symbol]
            Ordered list of time-dependent symbols
        """
        self.time_symbols: list[Symbol] = time_symbols
        self.shape = semi_symbolic_matrix.shape

        symbolic_expressions = []
        symbolic_rows, symbolic_cols = [], []
        constant_data, constant_rows, constant_cols = [], [], []

        for (i, j), expr in semi_symbolic_matrix.todok().items():
            expr = semi_symbolic_matrix[i, j]

            if hasattr(expr, "free_symbols") and expr.free_symbols:
                symbolic_expressions.append(expr)
                symbolic_rows.append(i)
                symbolic_cols.append(j)
            else:
                constant_data.append(float(expr))
                constant_rows.append(i)
                constant_cols.append(j)

        self._n_symbolic = len(symbolic_expressions)
        n_constant = len(constant_data)

        if self._n_symbolic > 0:
            self._symbolic_func = lambdify(time_symbols, symbolic_expressions, "numpy")

        all_rows = np.array(constant_rows + symbolic_rows, dtype=np.int32)
        all_cols = np.array(constant_cols + symbolic_cols, dtype=np.int32)
        self._all_data = np.empty(n_constant + self._n_symbolic, dtype=np.float64)
        self._all_data[:n_constant] = constant_data
        self._symbolic_slice = slice(n_constant, n_constant + self._n_symbolic)

        # Build COO and convert to CSR to recover the permutation order
        coo = coo_matrix((self._all_data, (all_rows, all_cols)), shape=self.shape)

        self._perm = np.lexsort((all_cols, all_rows))
        self._matrix = csr_matrix(coo)
        self._csr_data = self._matrix.data

    def evaluate(self, time_values=None) -> csr_matrix:
        """
        Parameters
        ----------
        time_values : array-like
            Values for time-dependent symbols in same order as time_symbols

        Returns
        -------
        csr_matrix
            Evaluated sparse matrix
        """
        if self._n_symbolic > 0:
            self._all_data[self._symbolic_slice] = self._symbolic_func(*time_values)
            self._csr_data[:] = self._all_data[self._perm]
        return self._matrix
