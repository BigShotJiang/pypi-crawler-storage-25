#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

from __future__ import annotations

import os.path
import time
import warnings
from collections import deque
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
from datetime import datetime
from multiprocessing import cpu_count
from typing import Any, Callable

import numpy as np
from scipy.integrate import solve_ivp
from scipy.sparse import spmatrix, sparray

from pyrc.core.settings import initial_settings, Settings, SolveSettings
from pyrc.core.solver.symbolic import SparseSymbolicEvaluator
from pyrc.core.components.templates import RCSolution
from pyrc.tools.science import get_free_ram_gb


class HomogeneousSystemHandler:
    def __init__(
        self,
        system_matrix: SparseSymbolicEvaluator | spmatrix | sparray,
        rc_solution: RCSolution,
        settings: Settings,
        print_progress=True,
        print_points: list | np.ndarray = None,
        batch_end=None,
        time_dependent_function=None,
        _initialize_temperature_function=True,
        **kwargs,
    ):
        """
        System Handler that is called ("as function") by `solve_ivp`.

        Parameters
        ----------
        system_matrix : spmatrix | sparray | SparseSymbolicEvaluator
            The system matrix.
            If constant, the type must be a sparse scipy matrix.
            If time dependent symbols are contained, the system matrix must be given in a `SparseSymbolicEvaluator`
            object.
        rc_solution
        settings
        print_progress
        print_points
        batch_end
        time_dependent_function : Callable, optional
            A function that calculates all time dependent variables within the time step and returns them in the correct
            order as iterable (e.g. list).
            It gets parameters like this:\n
            ``time_dependent_function(time, temperature_vector)`` \n
            or\n
            ``time_dependent_function(time, temperature_vector, input_vector)``\.\n
            To not run into Errors just use ``*args``\, ``**kwargs`` at the end in case more values are passed then
            needed.
        _initialize_temperature_function : bool, optional
            If ``False``, the ``dtemperature_dt_function`` attribute is not set using the method `_init_temperature_equation()`
            Used in subclasses to prevent an early call of attributes that are created in the subclasses later on.
        kwargs : dict, optional
            Not used: Just to not raise an error if too much information is passed.
        """
        self.system_matrix: spmatrix | sparray | SparseSymbolicEvaluator = system_matrix
        self.rc_solution = rc_solution
        self.settings = settings

        self.time_dependent_function: Callable = time_dependent_function  # must return the value(s) as iterable
        self.time_dependent_active: bool = True
        if time_dependent_function is None:
            self.time_dependent_active = False
            self.time_dependent_function = lambda *args, **keyword_args: []

        if print_progress and batch_end is None:
            import warnings

            warnings.warn("Print progress might not work as expected because batch_end value is not given.")
            batch_end = np.inf
        self.batch_end = batch_end

        # print progress
        if print_points is None:
            print_points = [0]
        if isinstance(print_points, np.ndarray):
            print_points = print_points.tolist()
        self.print_points: deque = deque(print_points)
        self.next_printed_time_step = self.print_points.popleft()
        self.print_progress = print_progress

        # initialize the temperature equation using a lambda
        self.dtemperature_dt_function = lambda *args, **keyword_args: None
        if _initialize_temperature_function:
            # this can be switched off because it always have to run at the end of all subclasses inits
            self.dtemperature_dt_function = self._init_temperature_equation()

    def _init_temperature_equation(self) -> Callable:
        if isinstance(self.system_matrix, SparseSymbolicEvaluator):
            assert self.time_dependent_active
            system_matrix = lambda v: self.system_matrix.evaluate(v)
        else:
            if self.time_dependent_active:
                warnings.warn(
                    "Function to calculate time dependent values passed, but no time dependent system matrix detected.\n"
                    "The passed function has no effect."
                )
            return lambda temperature: self.system_matrix @ temperature
        return lambda temperature, v: system_matrix(v) @ temperature

    def __call__(self, t, temperature):
        """
        The function the solve_ivp is going to solve.

        Parameters
        ----------
        t
        temperature

        Notes
        -----
        The input vector that is saved during the iteration of the solver at the t_eval

        Returns
        -------
        np.ndarray :
            The resulting vector of the temperature derivative.
        """
        if self.print_progress:
            self._update_progress_print(t)
        temperature = temperature.reshape(-1, 1)

        if self.time_dependent_active:
            time_dependent_values = self.time_dependent_function(t, temperature)
            dtemperature_dt = self.dtemperature_dt_function(temperature, time_dependent_values)
        else:
            dtemperature_dt = self.dtemperature_dt_function(temperature)

        return dtemperature_dt.flatten()

    def set_new_t_eval(self, new_t_eval):
        """
        Change the current t_eval.

        Parameters
        ----------
        new_t_eval : array_like
            The new t_eval.
        """
        # Currently only used in the child class
        pass

    def _update_progress_print(self, t):
        if t >= self.next_printed_time_step:
            # prevent initialization print out (is not fail save, but okay)
            if t != self.batch_end or (self.print_points and t == self.print_points[0]):
                if len(self.print_points) > 0:
                    self.next_printed_time_step = self.print_points.popleft()
                    self.print_out_progress(t)
                else:
                    self.next_printed_time_step = np.inf
                    # deactivate printing for better performance
                    self.print_progress = False

    def print_out_progress(self, t):
        """
        Prints a formatted time stamp.

        Parameters
        ----------
        t : float | int
            The time to format/print.
        """
        print(f"Progress: t = {self.format_t(t)}")


    @staticmethod
    def format_t(t):
        days = int(t) // 86400
        hours = (int(t) % 86400) // 3600
        minutes = (int(t) % 3600) // 60
        seconds = int(t) % 60
        return (
            f"{days:>4} days, {hours:02}:{minutes:02}:{seconds:02} - current time: "
            f"{datetime.now().strftime('%d %H:%M:%S')}"
        )


class InhomogeneousSystemHandler(HomogeneousSystemHandler):
    def __init__(
        self,
        system_matrix,
        input_matrix,
        input_vector,
        rc_solution,
        functions_list,
        kwargs_functions: dict,
        t_eval=None,
        time_dependent_function=None,
        use_parallelization=False,
        core_count=cpu_count(),
        print_progress=True,
        print_points=3600,
        settings: Settings = initial_settings,
        first_time: float | int = 0,
        **kwargs,
    ):
        super().__init__(
            system_matrix,
            rc_solution,
            settings,
            time_dependent_function=time_dependent_function,
            print_progress=print_progress,
            print_points=print_points,
            batch_end=t_eval[-1],
            _initialize_temperature_function=False,
        )
        self.input_matrix = input_matrix
        self.input_vector = input_vector.reshape(-1, 1)
        self.functions_list = functions_list

        self.after_iteration = np.inf
        self.next_eval_time = 0
        self.t_eval_iter = iter(())
        self.set_new_t_eval(t_eval)

        self.last_t = first_time
        self.last_eval_time = 0
        self.current_eval_time = 0
        self.use_current_eval_time = False

        self.input_update_function = self._update_input_vector

        # if use_parallelization:  # not used because it is not working yet
        #     # decide what is the best using the length of the input matrix.
        #     # If len(input) <= 500 only use threads, otherwise multiprocessing
        #     number_inputs = self.input_vector.shape[0]
        #     if number_inputs <= np.inf:  # switched off because pickle doesn't work
        #         self.input_update_function = self._update_input_vector
        #     elif number_inputs <= 50:
        #         self.input_update_function = self._update_input_vector_threads
        #     else:
        #         self.input_update_function = self._update_input_vector_processes
        self.core_count = max(1, min(core_count, cpu_count()))
        self.kwargs_functions: dict = kwargs_functions

        # initialize the temperature equation using a lambda
        self.dtemperature_dt_function = self._init_temperature_equation()

    def _init_temperature_equation(self) -> Callable:
        if isinstance(self.system_matrix, SparseSymbolicEvaluator):
            system_matrix_fun = lambda v: self.system_matrix.evaluate(v)
        else:
            system_matrix_fun = lambda *args, **kwargs: self.system_matrix
        if isinstance(self.input_matrix, SparseSymbolicEvaluator):
            input_matrix_fun = lambda v: self.input_matrix.evaluate(v)
        else:
            input_matrix_fun = lambda *args, **kwargs: self.input_matrix
        return lambda temperature, input_v, v: system_matrix_fun(v) @ temperature + input_matrix_fun(v) @ input_v

    def set_new_t_eval(self, new_t_eval):
        """
        Change the current t_eval.

        Parameters
        ----------
        new_t_eval : array_like
            The new t_eval.
        """
        if new_t_eval is None:
            self.t_eval_iter = iter([-np.inf])
            self.after_iteration = -np.inf
        else:
            self.t_eval_iter = iter(new_t_eval)
            self.after_iteration = np.inf
        self.next_eval_time = next(self.t_eval_iter, self.after_iteration)
        self.use_current_eval_time = False

    def calculate_kwargs(self, tau, temp_vector, _input_vector, **kwargs):
        return {name: fun(tau, temp_vector, _input_vector, **kwargs) for name, fun in self.kwargs_functions.items()}

    def _update_input_vector_threads(self, t, temperature, **kwargs):
        with ThreadPoolExecutor() as executor:
            results = list(executor.map(lambda f: f(t, temperature, self.input_vector, **kwargs), self.functions_list))
        self.input_vector = np.array(results).reshape(-1, 1)

    @staticmethod
    def _worker_call(args):
        f, t, temperature, input_vector, kwargs = args
        return f(t, temperature, input_vector, **kwargs)

    def _update_input_vector_processes(self, t, temperature, **kwargs):
        args_iter = [(f, t, temperature, self.input_vector.copy(), kwargs) for f in self.functions_list]
        with ProcessPoolExecutor(max_workers=self.core_count) as executor:
            results = list(executor.map(self._worker_call, args_iter))
        self.input_vector = np.array(results).reshape(-1, 1)

    def _update_input_vector(self, t, temperature, **kwargs):
        # TODO: Speedup by creating one big lambda function returning a vector instead of looping over all
        self.input_vector = np.array(
            [f(t, temperature, self.input_vector, **kwargs) for f in self.functions_list]
        ).reshape(-1, 1)

    def __call__(self, t, temperature: np.ndarray):
        """
        The function the solve_ivp is going to solve.

        Parameters
        ----------
        t
        temperature

        Notes
        -----
        The input vector that is saved during the iteration of the solver at the t_eval

        Returns
        -------
        np.ndarray :
            The resulting vector of the temperature derivative.
        """
        if t < self.last_t:
            if t == self.batch_end or (self.last_t >= self.last_eval_time > t):
                # Delete the last result because the solver is in initialization or one time step was saved to early.
                # Revert the next_eval_time to the last value.
                self.next_eval_time = self.last_eval_time
                self.use_current_eval_time = True
                self.rc_solution.delete_last_input()
        if self.print_progress:
            self._update_progress_print(t)
        temperature = temperature.reshape(-1, 1)

        kwargs = self.calculate_kwargs(t, temperature, self.input_vector)

        self.input_update_function(t, temperature, **kwargs)

        time_dependent_values = self.time_dependent_function(t, temperature, self.input_vector)

        # Check if the input vector has to be saved.
        if t >= self.next_eval_time:
            # NOTE: This is not perfect, because the input vector of the next time step is saved for the result of
            #  the last time step. However, the solver will perform such small iteration steps that this will not
            #  become a problem.
            self.rc_solution.append_to_input(self.input_vector)
            self.last_eval_time = self.next_eval_time
            if self.use_current_eval_time:
                self.next_eval_time = self.current_eval_time
                self.use_current_eval_time = False
            else:
                self.next_eval_time = next(self.t_eval_iter, self.after_iteration)

        dtemperature_dt = self.dtemperature_dt_function(temperature, self.input_vector, time_dependent_values)

        self.last_t = t
        return dtemperature_dt.flatten()


class SolveIVPHandler:
    def __init__(
        self,
        system_handler: HomogeneousSystemHandler | InhomogeneousSystemHandler,
        max_saved_steps=None,
        method=None,
        max_step=None,
        rtol=None,
        atol=None,
        save_interval=None,
        save_path=None,
        save_prefix="",
        minimize_ram_usage=None,
        solve_settings=None,
        **kwargs,
    ):
        """
        Handler of the solving process with solve_ivp.

        Parameters
        ----------
        system_handler : HomogeneousSystemHandler | InhomogeneousSystemHandler
            The system handler that holds the function to solve in __call__().
        max_saved_steps : int, optional
            The maximum number of used seconds during one solve_ivp call.
            It defines the batch size in seconds.
            Using this prevents long solving time because the matrices become very big.
        method : str, optional
            The method to use to solve the system (see scipy.solve_ivp).
        max_step
        rtol
        atol
        save_interval
        save_path
        save_prefix : str, optional
            This is the beginning of the name of the pickle file that is saved during the solving.
        minimize_ram_usage : bool, optional
            If True, the solution is deleted if saved to minimize the RAM usage during runtime.
        kwargs
        """
        if solve_settings is None:
            solve_settings = SolveSettings()
        self.solve_settings = solve_settings
        max_saved_steps, method, max_step, rtol, atol, save_interval, minimize_ram_usage = self.set_initial_values(
            max_saved_steps=max_saved_steps,
            method=method,
            max_step=max_step,
            rtol=rtol,
            atol=atol,
            save_interval=save_interval,
            minimize_ram_usage=minimize_ram_usage,
        )
        self.system_handler: HomogeneousSystemHandler | InhomogeneousSystemHandler = system_handler
        self.max_saved_steps = int(max_saved_steps)
        self.method = method
        self.max_step = max_step
        self.rtol = rtol
        self.atol = atol

        self.save_interval = save_interval
        self.save_counter = 0
        if save_path is None:
            save_path = self.system_handler.settings.save_folder_path
        if save_path is None:
            self.save_path = None
        else:
            self.save_path = os.path.normpath(save_path)
        self.save_prefix = save_prefix

        if self.save_path is None and minimize_ram_usage:
            print("Minimize RAM usage deactivated because no save_path is declared in Settings.")
            print("This also deactivates every save during solving.")
            minimize_ram_usage = False
        self.minimize_ram_usage = minimize_ram_usage

        self.kwargs = kwargs

    def set_initial_values(self, **kwargs):
        result = []
        settings_dict: dict = self.solve_settings.dict
        for key, arg in zip(kwargs.keys(), kwargs.values()):
            if arg is None:
                result.append(settings_dict[key])
            else:
                result.append(arg)
                print(f"Solve setting {key} is overwritten by manual/coded value: {arg}")
        return result

    def get_batches(self, t_span):
        start, end = t_span
        splits = np.arange(start, end, self.max_saved_steps)
        if splits[-1] != end:
            splits = np.append(splits, end)
        return splits

    def solve(
        self,
        t_span,
        y0,
        t_eval=None,
        continued_simulation: bool = False,
        expected_solution_size_mb=5000,
    ):
        """
        Runs the solve_ivp in batches.

        Parameters
        ----------
        t_span : tuple[int | float, int| float] :
            The start and end of the simulation in seconds.
            Usually it starts at 0: (0, end_seconds)
            See also: scipy.integrate.solve_ivp()
        y0 : np.ndarray | Iterable | float | int
            The initial state of the system.
            See also: scipy.integrate.solve_ivp()
        t_eval : np.ndarray | Iterable | float | int, optional
            Times at which to store the computed solution, must be sorted and lie within `t_span`\.
            If None (default), use points selected by the solver.
            See also: scipy.integrate.solve_ivp()
        continued_simulation : bool, optional
            If True, the first value of the first batch is not kept, because the simulation is continued.
        expected_solution_size_mb : int | float, optional
            The expected solution size in Megabytes. Is used for RAM-Management: if not enough free memory is available,
            the method waits for 10 seconds and tries again for a total of 360 times before raising an error.
            The solution size depends on the size of the RC network and number of saved time steps.
        """
        batches = self.get_batches(t_span)

        list_t, list_y = [], []
        current_y0 = y0

        if self.save_path is not None:
            intermediate_save_prefix = os.path.join(self.save_path, self.save_prefix + f"_{int(t_span[-1])}_")
        else:
            intermediate_save_prefix = "dummy_path"

        for i in range(len(batches) - 1):
            batch_start, batch_end = float(batches[i]), float(batches[i + 1])
            if t_eval is not None:
                if i == 0 and not continued_simulation:
                    mask = (t_eval >= batch_start) & (t_eval <= batch_end)
                else:
                    # exclude the batch_start for every batch except the first one to prevent duplicates
                    mask = (t_eval > batch_start) & (t_eval <= batch_end)
                t_eval_batch = t_eval[mask]
            else:
                t_eval_batch = None

            self.system_handler.set_new_t_eval(t_eval_batch)

            last_step_not_in_solution = False
            if t_eval_batch.size == 0 or t_eval_batch[-1] != batch_end:
                # The last step must be returned by solve_ivp anyway to pass it as new y0 in the next batch
                t_eval_batch = np.append(t_eval_batch, batch_end)
                last_step_not_in_solution = True

            # update end of batch (used for correct print out and saves)
            self.system_handler.batch_end = batch_end

            sol: Any = solve_ivp(
                fun=self.system_handler,
                t_span=(batch_start, batch_end),
                y0=current_y0,
                method=self.method,
                t_eval=t_eval_batch,
                max_step=self.max_step,
                rtol=self.rtol,
                atol=self.atol,
                **self.kwargs,
            )
            current_y0 = sol.y[:, -1]

            if last_step_not_in_solution:
                # delete last solution if not requested in settings (but it was needed for y0)
                self.system_handler.rc_solution.delete_last_input()
                new_time_steps = sol.t[:-1]
                new_y_values = sol.y[:, :-1]
            else:
                new_time_steps = sol.t
                new_y_values = sol.y

            if new_time_steps.size != 0:
                list_t.append(new_time_steps)
                list_y.append(new_y_values)
                # increase counter only if new solution was added. Otherwise it saves the same solution / an empty one
                self.save_counter += 1

            if self.save_counter // self.save_interval > 0 or (
                batch_end == t_span[-1]
                and (self.system_handler.rc_solution.last_saved_timestep_index > 0 or self.minimize_ram_usage)
            ):
                save_path = f"{intermediate_save_prefix}{float(batch_end):09.0f}_s.pickle"
                if self.minimize_ram_usage:
                    # save the solution and delete it afterward
                    assert self.save_path is not None
                    self.system_handler.rc_solution.save_to_file_only(
                        t=np.concatenate(list_t),
                        y=np.concatenate(list_y, axis=1).T,
                        path_with_name_and_ending=save_path,
                    )
                else:
                    self.add_to_solution(list_t, list_y)
                    if self.save_path is not None:
                        self.system_handler.rc_solution.save_new_solution(save_path)

                list_y = []
                list_t = []
                self.save_counter = 0

        # Make print out for the last time step that else will be missed
        if self.system_handler.print_progress:
            if self.system_handler.next_printed_time_step <= t_span[-1]:
                self.system_handler.print_out_progress(t_span[-1])

        save_path = f"{intermediate_save_prefix}result.pickle"
        if self.minimize_ram_usage:
            # load solution in and save it as one big solution
            # it will load all intermediate saves because it will not find the requested path with "_result.pickle"
            # first check, if enough RAM is available
            assert self.save_path is not None
            loop_counter = 0
            max_loops = 360
            while get_free_ram_gb() < expected_solution_size_mb / 1000 and loop_counter < max_loops:
                loop_counter += 1
                time.sleep(10)  # waiting for more free RAM
            if not loop_counter >= max_loops:
                self.system_handler.rc_solution.load_solution(save_path)
                # Now save the accumulated result in one pickle with the "_result" ending
                self.system_handler.rc_solution.save_solution(save_path)
            else:
                print("Not enough RAM for over one hour. Incremental solutions are not combined.")
        else:
            self.add_to_solution(list_t, list_y)
            if self.save_path is not None:
                self.system_handler.rc_solution.save_solution(save_path)

    def add_to_solution(self, new_t: list, new_y: list):
        if self.system_handler.rc_solution.t is None:
            self.system_handler.rc_solution.t = np.concatenate(new_t)
        else:
            if new_t is not None:
                self.system_handler.rc_solution.t = np.concatenate([self.system_handler.rc_solution.t, *new_t])
        if self.system_handler.rc_solution.y is None:
            self.system_handler.rc_solution.y = np.concatenate(new_y, axis=1).T
        else:
            if new_y is not None:
                self.system_handler.rc_solution.y = np.concatenate([self.system_handler.rc_solution.y.T, *new_y],
                                                                   axis=1).T
