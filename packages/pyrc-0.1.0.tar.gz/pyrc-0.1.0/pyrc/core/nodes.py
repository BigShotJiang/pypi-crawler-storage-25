#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

from __future__ import annotations

import warnings

import numpy as np
from collections import deque
from typing import TYPE_CHECKING
from abc import ABC

from pyrc.core.components.capacitor import Capacitor
from pyrc.core.inputs import BoundaryCondition, FlowBoundaryCondition, InternalHeatSource
from pyrc.core.materials import Air
from pyrc.core.components.templates import (
    Material,
    ObjectWithPorts,
    Cell,
    Geometric,
    ConnectedFlowObject,
    calculate_balance_for_resistors,
    initial_rc_objects,
    RCObjects,
    RCSolution,
    solution_object,
    Fluid,
    Solid,
)

if TYPE_CHECKING:
    from pyrc.core.resistors import MassTransport
    from pyrc.core.settings import Settings
    from pyrc.core.components.resistor import Resistor


class ConnectedFlowCapacitorObject(Capacitor, ConnectedFlowObject, ABC):
    pass


class Node(Capacitor, Cell):
    def __init__(
        self,
        material: Material,
        temperature: float | int | np.number,
        position: np.ndarray | tuple,
        temperature_derivative: float | int | np.number = 0,
        internal_heat_source: bool | int | float | np.number = False,
        internal_heat_source_type=InternalHeatSource,
        delta: np.ndarray | tuple | list = None,
        rc_objects=initial_rc_objects,
        rc_solution: RCSolution = solution_object,
        **kwargs: float | int | np.ndarray | Settings,
    ):
        """

        Parameters
        ----------
        material : Material
            Container with all material properties stored in the node is made up from.
        temperature : float | int | np.number
            The temperature of the node.
            It is recommended to use the SI unit Kelvin instead of degrees Celsius.
        position : np.ndarray
            The position of the node in 2D/3D space.
            If 2D, a zero is added for the z coordinate.
        temperature_derivative : float | int | np.number, optional
            The temperature derivative of the node.
        internal_heat_source : bool | int | float | np.number, optional
            If True, an internal heat source term is added.
            It can be accessed using Node.internal_heat_source
            If a number, the number is used to set as volumetric heat source power in W/m**3.
        internal_heat_source_type : type, optional
            The internal heat source type.
            Can be each `InternalHeatSource` type.
        delta : np.ndarray | tuple, optional
            Delta vector [delta_x, delta_y, delta_z].
        kwargs : dict
            Parameters passed to `InternalHeatSource`/its type.

        Notes
        -----
        Be aware of the fact that the **Node's properties can change during network creation!**
        This means, that if you add connections to a Node it's volume/mass can change. So every object, that needs
        the Node's volume/mass should be initialized **after** the whole network was build up. This affects,
        among other things, `Input` s like `InternalHeatSource` s, especially `Radiation`.
        To avoid this, you must pass the whole object (node/BC) to the Input and program it in a way that the values
        are created earliest when values are requested (and therefore the network must be set up (hopefully)).
        """
        Capacitor.__init__(
            self,
            capacity=None,
            temperature=temperature,
            temperature_derivative=temperature_derivative,
            rc_objects=rc_objects,
            rc_solution=rc_solution,
        )
        Cell.__init__(self, position=position, delta=delta)
        self.material: Material | Fluid | Solid = material
        self._volume = None
        self._kwargs = kwargs  # saved for __copy__

        # This must be at the end of init. It uses some attributes of node already (like node.id)
        if internal_heat_source:
            if not isinstance(internal_heat_source, bool):
                internal_heat_source = internal_heat_source_type(
                    node=self, specific_power_in_w_per_cubic_meter=internal_heat_source, **kwargs
                )
            elif internal_heat_source_type is not None:
                internal_heat_source = internal_heat_source_type(node=self, **kwargs)
            else:
                internal_heat_source = InternalHeatSource(node=self, **kwargs)
            self.add_internal_heat_source(internal_heat_source)

    def __copy__(self):
        # TODO: This was not checked well. Have a closer look on it.
        cls = self.__class__
        internal_heat_source = False if self.internal_heat_source is None else True
        internal_heat_source_type = InternalHeatSource
        if internal_heat_source:
            internal_heat_source_type = type(self.internal_heat_source)
            if isinstance(self.internal_heat_source, InternalHeatSource):
                Warning(
                    "A Node with an InternalHeatSource is copied. The attribute\n"
                    "\tspecific_power_in_w_per_meter_squared\n"
                    "might be lost."
                )
            if hasattr(self.internal_heat_source, "volume_specific_power"):
                internal_heat_source = self.internal_heat_source.volume_specific_power
        return cls(
            material=self.material,
            temperature=self.temperature,
            position=self.position,
            temperature_derivative=self.temperature_derivative,
            internal_heat_source=internal_heat_source,
            internal_heat_source_type=internal_heat_source_type,
            delta=self.delta,
            rc_objects=self.rc_objects,
            rc_solution=self.solutions,
            **self._kwargs,
        )

    def __str__(self):
        return self.__repr__()

    def __repr__(self):
        return f"{self.__class__.__name__} {self.id}: {self.material.__class__.__name__}; ϑ={self.temperature}"

    @property
    def capacity(self) -> float | int:
        """
        Returns the capacity (not specific) of the node in J/K.

        Returns
        -------
        float | int :
            The capacity of the node in J/K.
        """
        if self._capacity is None:
            self.calculate_capacity()
        return self._capacity

    @property
    def volume(self) -> float | int:
        if self._volume is None:
            self.calculate_volume()
        return self._volume

    @property
    def mass(self) -> float | int | np.number:
        """
        Returns the mass flow of the node in kg.

        Returns
        -------
        float | int :
            The mass flow of the node in kg.
            If the density isn't defined np.nan is returned.
        """
        if self.material.density:
            return self.volume * self.material.density
        return np.nan

    def update_color(self, t_min: float = 263.15, t_max: float = 413.15, colormap="managua") -> None:
        """
        Update the color of the vbox for visualization.

        Parameters
        ----------
        t_min : float | int, optional
            The minimal temperature for the color code.
        t_max : float | int, optional
            The maximal temperature for the color code.
        colormap : str, optional
            The colormap to use. See pyrc.core.visualization.color.color.py or the txt files in there respectively.
        """
        Cell.update_color(self.temperature, t_min=t_min, t_max=t_max, colormap=colormap)

    def area(self, normal: np.ndarray) -> float:
        """
        Returns the area of the desired plane in m**2.

        Parameters
        ----------
        normal : np.ndarray
            The direction to the wanted plane.
            E.g.: if (1,0,0) the y-z-plane is wanted so the area of the yz-plane is returned.

        Returns
        -------
        float :
            The area in m^2.
        """
        direction_abs = np.abs(normal)

        multiplication_vector = np.array([1, 1, 1]) - direction_abs
        area = np.prod(self.delta, where=multiplication_vector.astype(bool))
        return float(area.item())

    def calculate_capacity(self):
        self._capacity = self.material.heat_capacity * self.mass  # J/K

    def calculate_volume(self):
        self._volume = self.delta_x * self.delta_y * self.delta_z  # m^3

        # add volume for each channel node
        channel_nodes = self.get_connected_nodes(ChannelNode)
        channel_node: ChannelNode
        for channel_node in channel_nodes:
            raw_volume = channel_node.delta_x * channel_node.delta_y * channel_node.delta_z
            solid_volume = raw_volume - channel_node.volume
            self._volume += solid_volume / 4

    @property
    def values(self) -> list:
        result = [*super().values_without_capacity, self.capacity]
        return result

    def get_area(self, asking_node: Node | Cell | BoundaryCondition | Capacitor) -> float | int | np.number:
        """
        Returns the area that the asking node sees. Through this area travels the heat between both nodes.

        Example: If the asking node has the same position in x and y direction but is shifted in z direction,
        the area of the cell face X-Y is returned.

        A non-Cell class is only valid if its direction to/from self was set manually in
        self.manual_directions[asking_node]. Otherwise, it will throw an error.

        Parameters
        ----------
        asking_node : Node | Cell | BoundaryCondition | Capacitor
            The Node that asks for the area of this Node. It is used to calculate the shift in position and to return
            the associated surface area accordingly.
            If it doesn't inherit from Cell, it is assumed that the direction is set manually in manual_directions dict
            using ``self`` as key.

        Returns
        -------
        float | int | np.number :
            The area of the surface of the cell that has the normal vector of the line you get connecting both `self`
            and `asking_node`.
        """
        # determine the shift in position between self and asking_node
        direction_to_asking_node = self.get_direction(asking_node=asking_node)

        return self.area(direction_to_asking_node)

    def get_conduction_length(self, asking_node: Node | ConnectedFlowObject | Geometric | Capacitor):
        """
        Returns the length to the asking node. It's half the delta value in direction to the asking node.

        Parameters
        ----------
        asking_node : Geometric
            The Node asking for the (half) length between itself and self.

        Returns
        -------
        float :
            The half-length of self. Or: Half the delta value of self pointing towards asking_node.
        """
        direction = self.get_direction(asking_node)  # returns the direction to (not from) the asking node.

        return np.linalg.norm(direction * self.delta) * 0.5

    def get_both_perpendicular_lengths(self, asking_node: Geometric | Node | BoundaryCondition) -> tuple[float, float]:
        """
        Returns both perpendicular lengths between the self and the asking node.

        Parameters
        ----------
        asking_node : Geometric | Node | BoundaryCondition
            The node asking.

        Returns
        -------
        tuple[float, float] :
            Both length in no particular order.
        """
        # get the direction to the asking node
        direction = self.get_direction(asking_node)

        # Define the mapping of axes
        axis_map = {
            (1, 0, 0): ["delta_y", "delta_z"],  # If direction is X, take Y and Z
            (0, 1, 0): ["delta_x", "delta_z"],  # If direction is Y, take X and Z
            (0, 0, 1): ["delta_x", "delta_y"],  # If direction is Z, take X and Y
        }

        # Convert direction to tuple
        direction_tuple = tuple(np.abs(direction).astype(int))

        if direction_tuple not in axis_map:
            return np.nan, np.nan  # Shouldn't happen if input is correct

        # Extract the two perpendicular delta values
        delta_1 = getattr(self, axis_map[direction_tuple][0])
        delta_2 = getattr(self, axis_map[direction_tuple][1])

        return delta_1, delta_2

    def get_smaller_edge(self, asking_node: Geometric | Node | BoundaryCondition | Capacitor):
        """
        Returns the smaller edge of the cell using the asking node to set the direction.

        Used to determine the diameter in `MassFlowNode` s.

        Parameters
        ----------
        asking_node : Geometric | Node | BoundaryCondition
            The node that asks for the diameter of this `Node`. It determines the direction to get the right dimension.

        Returns
        -------
        float | int | np.number :
            The diameter (smallest length of the cell side pointing towards `asking_node`).
        """
        deltas = self.get_both_perpendicular_lengths(asking_node=asking_node)

        # Return the smaller of the two
        return min(deltas)


class MassFlowNode(Node, ConnectedFlowObject):
    def __init__(
        self,
        material: Material,
        temperature,
        position,
        flow_area: float | int | str = None,
        flow_length: float | int | str = None,
        temperature_derivative=0,
        flow_velocity=None,
        mass_flow=None,
        volume_flow=None,
        rc_objects: RCObjects = initial_rc_objects,
        rc_solution: RCSolution = solution_object,
        **kwargs,
    ):
        """

        Parameters
        ----------
        temperature : float | int | np.number
            The (initial) temperature of the node.
        position : np.ndarray
            The position of the node in 2D/3D space.
            If 2D, a zero is added for the z coordinate.
        flow_area : float | int | str
            Defining the area that is used for flow calculations (determining the velocity and the Courant number).
            Can be a string:
            xy: xy-plane, xz: xz-plane, yz: yz-plane
            If not given the smallest flow area is used that points to a `ConnectedFlowObject`.
        flow_length : float | int | str
            Defining the length that the flow takes.
            Can be a string:
            x: delta_x, y: delta_y, z: delta_z
            If not given the matching one for the flow area is used.
        temperature_derivative : float | int | np.number
            The temperature derivative of the node.
        flow_velocity : float | int | np.number
            The flow velocity of the node.
            It doesn't matter which sign it has. Only the absolute value is used.
        """
        ConnectedFlowObject.__init__(self)
        Node.__init__(
            self,
            material=material,
            temperature=temperature,
            position=position,
            temperature_derivative=temperature_derivative,
            rc_objects=rc_objects,
            rc_solution=rc_solution,
            **kwargs,
        )
        # Compute area if it's given as a plane
        self._flow_length = None
        self._flow_area = None
        if isinstance(flow_length, str):
            self._flow_length = getattr(self, f"delta_{flow_length}")
        else:
            self._flow_length = flow_length
        if isinstance(flow_area, str):
            match flow_area.lower():
                case "xy" | "yx":
                    self._flow_area = self.delta_x * self.delta_y
                    self._flow_length = self.delta_z
                case "xz" | "zx":
                    self._flow_area = self.delta_x * self.delta_z
                    self._flow_length = self.delta_y
                case "yz" | "zy":
                    self._flow_area = self.delta_y * self.delta_z
                    self._flow_length = self.delta_x
                case _:
                    raise ValueError("Invalid plane. Use 'xy', 'xz', or 'yz'.")
        else:
            self._flow_area = flow_area  # Assume it's given as a direct value in m².
        # TODO: set flow_area and flow_direction depending on each other.

        self._flow_propagation = False

        if sum(val is not None for val in [flow_velocity, mass_flow, volume_flow]) != 1:
            self._flow_propagation = True

        self._passed_flow_velocity = flow_velocity

        if volume_flow is not None:
            self._volume_flow = volume_flow
        elif flow_velocity is not None:
            # calculate later because the area isn't known until all connections were made
            self._volume_flow = None
        elif mass_flow is not None:
            self._volume_flow = mass_flow / self.material.density

        # Initialize cache
        self._velocity = None
        self._mass_flow = None
        self._flow_direction = None

    def courant_number(self, time_step: float):
        """
        Calculates the courant number of the node.

        Parameters
        ----------
        time_step : float | int | np.number
            The (maximum) time step used for calculation.

        Returns
        -------
        float | np.number :
            The courant number.
        """
        return self.velocity * time_step / self.flow_length

    @property
    def flow_length(self) -> float:
        """
        The effective length of the channel. Use only if no asking_node is given!

        This assumes that each ChannelNode is connected to at least one solid node at its sides. This node is used to
        get the perpendicular direction and define which sides defining the length.

        Returns
        -------
        float :
            The length, but it can be wrong in few cases.
        """
        if self._flow_length is None:
            # request flow_area and calculate the value in it
            _ = self.flow_area
        return self._flow_length

    @property
    def flow_area(self):
        if self._flow_area is None or self._flow_length is None:
            # get the areas between self and ConnectedFlowObjects and take the smallest one.
            result = np.inf
            flow_length = 0
            flow_obj: MassFlowNode | BoundaryCondition
            for flow_obj in self.mass_flow_neighbours:
                area = self.get_area(flow_obj)
                if result > area:
                    result = area
                    flow_length = self.get_direction(flow_obj) * self.delta
            self._flow_area = result
            self._flow_length = np.linalg.norm(flow_length)
        return self._flow_area

    @property
    def volume_flow(self):
        """Returns the cached volume flow rate (m³/s)."""
        if self._flow_propagation and self._volume_flow is None:
            self.propagate_flow()
            # volume flow should be set now
            self._flow_propagation = False
        if self._volume_flow is None:
            if self._passed_flow_velocity:
                self._volume_flow = self._passed_flow_velocity * self.flow_area
            else:
                raise ValueError("This shouldn't have happened!")
        return self._volume_flow

    @property
    def velocity(self):
        """Returns the cached flow velocity (m/s) or calculates it if needed."""
        if self._velocity is None:
            self._velocity = self.volume_flow / self.flow_area
        return self._velocity

    @property
    def mass_flow(self):
        """Returns the cached mass flow rate (kg/s) or calculates it if needed."""
        if self._mass_flow is None:
            self._mass_flow = self.volume_flow * self.material.density
        return self._mass_flow

    def reset_properties(self):
        """Clears cached flow velocity and mass flow to force recalculation."""
        super().reset_properties()
        self._velocity = None
        self._mass_flow = None

    @property
    def sources(self) -> list[Capacitor | Node]:
        """
        Returns a list with all nodes where volume flow is flowing into the node.

        No check is performed which node type is put into the list, but it should only be `MassFlowNode` s and its
        descendants or `FlowBoundaryCondition` s.

        Returns
        -------
        list :
            All nodes serving as volume flow source.
        """
        result = []
        seen = set()
        resistor: MassTransport
        for resistor in self.connected_mass_transport_resistors():
            if resistor.sink == self:
                connected = resistor.get_connected_node(self)
                if connected not in seen:
                    seen.add(connected)
                    result.append(connected)
        return result

    @property
    def sinks(self) -> list[MassFlowNode | FlowBoundaryCondition]:
        """
        Returns a list of all `MassFlowNode` s into which the flow is flowing.

        No check is performed which node type is put into the list, but it should only be `MassFlowNode` s and its
        descendants or `FlowBoundaryCondition` s.

        Returns
        -------
        list :
            All nodes serving as volume flow sink.
        """
        result = []
        seen = set()
        resistor: MassTransport
        for resistor in self.connected_mass_transport_resistors():
            if resistor.source == self:
                connected = resistor.get_connected_node(self)
                if connected not in seen:
                    seen.add(connected)
                    result.append(connected)
        return result

    @property
    def diameter(self) -> float:
        """
        Returns the hydraulic diameter.

        Returns
        -------
        float :
            The hydraulic diameter of the node.
        """
        len1, len2 = self.get_minimal_perpendicular_lengths_to_flow()
        len1 = float(len1)
        len2 = float(len2)
        # return hydraulic diameter
        return 2 * len1 * len2 / (len1 + len2)

    def get_resistor_volume_flow(self, resistor: MassTransport):
        """
        Returns the volume flow for the given resistor using mass balance.

        Parameters
        ----------
        resistor : MassTransport
            The `Resistor` to determine the volume flow for.

        Returns
        -------
        float :
            The volume flow of the given `Resistor`.
        """
        result = 0
        other_node_on_resistor = resistor.get_connected_node(self)
        for sink in self.sinks:
            if sink != other_node_on_resistor:
                result -= sink.volume_flow
        source: ConnectedFlowObject
        for source in self.sources:
            if source != other_node_on_resistor:
                result += source.volume_flow

        # if other_node_on_resistor is in sinks, the volume flow is positive (if it flows from source to sink) and
        # vice versa: if in sources, the volume flow is negative
        if other_node_on_resistor in self.sources:
            result *= -1
        return result

    @property
    def start_nodes(self) -> list:
        """
        Returns all nodes that are defined as a start of the mass flow.

        Used for the algorithm to set the direction of the mass flow (make_velocity_direction).

        Returns
        -------
        list :
            A list with all mass flow start BoundaryConditions.
        """
        result = []
        element: ObjectWithPorts
        for element in self.rc_objects.all:
            if isinstance(element, BoundaryCondition):
                if element.is_mass_flow_start:
                    result.append(element)
        return result

    @property
    def mass_flow_neighbours(self):
        """
        Returns all neighbour `MassFlowNode` s.

        Returns
        -------
        list :
            The list with all neighbour `MassFlowNode` s
        """
        return [*self.sinks, *self.sources]

    @property
    def balance(self):
        return calculate_balance_for_resistors(self, self.connected_mass_transport_resistors())

    def check_balance(self) -> bool:
        """
        Returns True if every parent `ConnectedFlowObject` has a balanced volume flow.

        This implies that the algorithm to set the volume flow always walks from the flow start to its end and not
        the other way around.

        Returns
        -------
        bool :
            True if every parent `ConnectedFlowObject` has a balanced volume flow. False otherwise.
        """
        if self.volume_flow_is_balanced:
            return True
        # walk the flow upwards and check every source if they are balanced.
        source: ConnectedFlowObject
        for source in self.sources:
            if source.check_balance():
                continue
            else:
                return False
        # check if self is balanced
        balance = self.balance

        if np.isclose(balance, 0):
            self.volume_flow_is_balanced = True
            return True
        return False

    @property
    def flow_direction(self) -> list[np.ndarray]:
        result = []
        if self._flow_direction is None:
            flow_direction = np.array((0, 0, 0))
            for neighbour in self.mass_flow_neighbours:
                flow_direction += np.abs(neighbour.get_direction(self))
            for i, value in enumerate(flow_direction):
                if value > 0:
                    result.append(np.zeros(3))
                    result[-1][i] = 1
            self._flow_direction = flow_direction
        return self._flow_direction

    def get_minimal_perpendicular_lengths_to_flow(self) -> tuple:
        flow_direction: list = self.flow_direction

        if len(flow_direction) > 1:
            minima = np.partition(self.delta, 1)[0:2]
            return minima[0], minima[1]

        mask_vector = np.array([1, 1, 1]) - np.abs(flow_direction[0])

        masked_array = np.ma.array(self.delta, mask=mask_vector)
        # invert mask of masked array
        masked_array = np.ma.array(masked_array.data, mask=~masked_array.mask)
        return tuple(masked_array.compressed())

    def get_perpendicular_length_parallel_to_flow(self, asking_node: Node):
        """
        Returns the length that is perpendicular to the connection asking_node - self and is parallel to the flow.

        Used for the effective area between a Solid and a MassFlowNode as well as to get the length of ChannelNodes.

        Parameters
        ----------
        asking_node : Node

        Returns
        -------
        float :
            The length.
        """
        first_vector = self.mass_flow_neighbours[0].get_direction(self)

        second_vector = self.get_direction(asking_node)

        # make cross product to get the third vector
        third_vector = np.abs(np.cross(first_vector, second_vector))

        return float((third_vector.reshape(1, 3) @ self.delta.reshape(3, 1)).item())

    def connected_mass_transport_resistors(self) -> list[MassTransport]:
        """
        Returns all connected mass transport resistors.

        Returns
        -------
        list[MassTransport] :
            The list.
        """
        from pyrc.core.resistors import MassTransport

        result = []
        for neighbour in self.neighbours:
            if isinstance(neighbour, MassTransport):
                result.append(neighbour)
        return result

    @property
    def mass_transport_resistors(self) -> list:
        """
        Returns a list with all MassTransport resistors in the network.

        Returns
        -------
        list :
            The list with all MassTransport resistors in the network.
        """
        from pyrc.core.resistors import MassTransport

        return self.rc_objects.get_all_objects(MassTransport)

    @property
    def mass_flow_nodes(self) -> list:
        """
        Returns a list with all MassTransport resistors in the network.

        Returns
        -------
        list :
            The list with all MassTransport resistors in the network.
        """
        from pyrc.core.resistors import MassFlowNode

        return self.rc_objects.get_all_objects(MassFlowNode)

    # def make_velocity_direction(self):
    #     """
    #     Determines and sets the source and sink for each resistor in a network using iterative DFS.
    #     """
    #     from pyrc.core.resistors import MassTransport
    #     resistors: list[MassTransport] = self.mass_transport_resistors
    #     start_nodes = self.start_nodes
    #
    #     graph = {}
    #     resistor_map = {}  # Maps node pairs (unordered) to resistors
    #
    #     # Step 1: Build adjacency list and resistor mapping
    #     for resistor in resistors:
    #         u, v = resistor.neighbours  # Each resistor connects exactly two nodes
    #         key = frozenset((u, v))  # Store as an unordered key
    #
    #         graph[u].append(v)
    #         graph[v].append(u)
    #         resistor_map[key] = resistor  # Single entry instead of two
    #
    #     # Step 2: Start iterative DFS from each start node
    #     for start_node in start_nodes:
    #         stack = [(start_node, None)]
    #         visited = set()
    #
    #         while stack:
    #             node, parent = stack.pop()
    #             if node in visited:
    #                 continue
    #             visited.add(node)
    #
    #             for neighbor in graph[node]:
    #                 if neighbor == parent:
    #                     continue
    #                 key = frozenset((node, neighbor))
    #                 resistor = resistor_map[key]
    #                 resistor.source = node
    #                 resistor.sink = neighbor
    #                 stack.append((neighbor, node))
    #
    #     # Ensure all resistors have source and sink set
    #     for resistor in resistors:
    #         if resistor.source is None or resistor.sink is None:
    #             raise ValueError(
    #                 f"Resistor between {resistor.neighbours[0]} and {resistor.neighbours[1]} is not properly set.")

    def propagate_flow(self):
        """
        Propagates the volume flow through all connected `ConnectedFlowObject` s from start to end.

        It considers already set volume flows on its way to the end, but until now there is now backflow allowed. So
        if the set volume flow of an sink exceeds the balance it will be overwritten.

        Only works if the volume flow is set at the start `FlowBoundaryCondition`! It walks from the start to the end
        and not the other way round.
        """
        start_nodes = self.start_nodes
        queue = deque(start_nodes)
        considered = set(start_nodes)

        while queue:
            node: ConnectedFlowCapacitorObject = queue.popleft()

            if node.guess_volume_flow is None:
                warnings.warn("That shouldn't have happened.")
                continue  # Skip nodes without a defined volume flow
            node.volume_flow_is_balanced = True

            sink_nodes: list[ConnectedFlowObject] = [n for n in node.sinks if n not in considered]
            if not sink_nodes:
                # dead end.
                continue

            defined_sinks = [n for n in sink_nodes if n.volume_flow_is_balanced]
            undefined_sinks = [n for n in sink_nodes if not n.volume_flow_is_balanced]

            if len(defined_sinks) > 0:
                total_defined_flow = sum(n.guess_volume_flow for n in defined_sinks)
                remaining_flow = node.guess_volume_flow - total_defined_flow
                if np.isclose(remaining_flow, 0):
                    remaining_flow = 0
                if remaining_flow < 0:
                    # overwrite all incorrect sink volume flows with equal distribution
                    # TODO: Maybe allow negative volume flows (back-flows)?
                    print("Warning: Set volume flow is overwritten to create no backflow.")
                    undefined_sinks.extend(defined_sinks)
                    defined_sinks = []
                for sink in defined_sinks:
                    if sink not in considered:
                        # TODO: check if sources are all having a defined volume flow (this would save circle circuits)
                        add_sink_to_queue = True
                        for source in sink.sources:
                            if source.volume_flow_is_balanced:
                                continue
                            else:
                                add_sink_to_queue = False
                                break
                        if add_sink_to_queue:
                            queue.append(sink)
                            considered.add(sink)
            else:
                remaining_flow = node.guess_volume_flow

            if len(undefined_sinks) > 0:
                equal_flow = remaining_flow / len(undefined_sinks)
                for sink in undefined_sinks:
                    if sink not in considered:
                        if sink.guess_volume_flow is None:
                            sink._volume_flow = 0  # Initialize if undefined

                        sink._volume_flow += equal_flow
                        # set volume flow in resistor in between
                        resistor = node.get_mass_transport_to_node(sink)
                        resistor._volume_flow = equal_flow

                        if all(s.volume_flow_is_balanced for s in sink.sources):
                            queue.append(sink)
                            considered.add(sink)

        self.set_remaining_resistor_volume_flow()

    def set_remaining_resistor_volume_flow(self):
        """
        Sets all unset volume flows of all `MassTransport` `Resistors`.

        The most of them should have been set already in `self.propagate_flow()`.

        """
        resistors = [r for r in self.mass_transport_resistors if r.guess_volume_flow is None]
        max_attempts = len(resistors)
        queue = deque(resistors)
        attempts = {resistor: 0 for resistor in resistors}  # keep track how often the resistor is re-added to the queue

        resistor: MassTransport
        while queue:
            resistor = queue.popleft()

            node: ConnectedFlowCapacitorObject
            for node in resistor.neighbours:
                # First: check if node only has two resistors connected. If so, set volume_flow of node as own one.
                if len(node.sinks) == 1 and len(node.sources) == 1:
                    resistor._volume_flow = node.volume_flow
                    break  # go to next resistor
            else:  # Only executed if the first loop did not break
                node: ConnectedFlowCapacitorObject
                from pyrc.core.resistors import MassTransport

                for node in resistor.neighbours:
                    # Determine the volume_flow balance of the node using the resistor.guess_volume_flow
                    # At least 'resistor' has no volume_flow set. If it is the only one, it can be calculated.
                    # Otherwise, resistor is added back to queue.

                    defined_resistors = {"sink": [], "source": []}
                    undefined_resistors = {"sink": [], "source": []}

                    connected_resistors = [n for n in node.neighbours if isinstance(n, MassTransport)]
                    res: MassTransport
                    for res in connected_resistors:
                        if res.guess_volume_flow is None:
                            if res.sink == node:
                                # resistor is source for node
                                undefined_resistors["source"].append(res)
                            else:
                                # resistor is sink for node
                                undefined_resistors["sink"].append(res)
                        else:
                            if res.sink == node:
                                # resistor is source for node
                                defined_resistors["source"].append(res)
                            else:
                                # resistor is sink for node
                                defined_resistors["sink"].append(res)

                    def calculate_balance(def_resistors: dict):
                        result = 0
                        for def_res in def_resistors["sink"]:
                            result -= def_res.guess_volume_flow
                        for def_res in def_resistors["source"]:
                            result += def_res.guess_volume_flow
                        return result

                    number_undefined_res = len(undefined_resistors["sink"]) + len(undefined_resistors["source"])
                    if number_undefined_res > 1:
                        continue  # Volume flow cannot be determined --> check next node or go to 'else'
                    else:
                        if number_undefined_res == 1:
                            # Can only be resistor that isn't defined so its volume flow is set using the balance of
                            # the node.
                            resistor._volume_flow = calculate_balance(defined_resistors)
                            break
                        elif number_undefined_res == 0:
                            break
                else:
                    # add resistor back to queue (if for loop did break!)
                    if attempts[resistor] >= max_attempts:
                        raise RuntimeError(
                            f"Could not determine attribute for {resistor} after {max_attempts} attempts."
                        )
                    attempts[resistor] += 1
                    queue.append(resistor)


class ChannelNode(MassFlowNode):
    @property
    def flow_length(self) -> float:
        """
        The effective length of the channel. Use only if no asking_node is given!

        This assumes that each ChannelNode is connected to at least one solid node at its sides. This node is used to
        get the perpendicular direction and define which sides defining the length.

        Returns
        -------
        float :
            The length, but it can be wrong in few cases.
        """
        _ = super().flow_area
        return self._flow_length

    @property
    def flow_area(self):
        self._flow_area = self.diameter**2 / 4 * np.pi
        return self._flow_area

    @property
    def diameter(self) -> float:
        """
        Returns the diameter by using neighbour nodes that aren't ChannelNodes.

        This assumes that each ChannelNode is connected to at least one solid node at its sides. This node is used to
        get the perpendicular direction and define which sides defining the diameter.

        Returns
        -------
        float :
            The diameter.
        """
        from pyrc.core.resistors import MassTransport

        neighbour: Resistor
        for neighbour in self.neighbours:
            if not isinstance(neighbour, MassTransport):
                asking_node = neighbour.get_connected_node(self)
                if not isinstance(asking_node, MassFlowNode):
                    return self.get_smaller_edge(asking_node)

        return np.nan

    @property
    def volume(self) -> float | int:
        """
        Returns the volume of the circular air channel.

        Returns
        -------
        float | int | np.number :
            The volume of the air channel.
        """
        return self.flow_area * self.flow_length

    @property
    def circumference(self):
        return self.diameter * np.pi

    def get_pipe_area(self, asking_node: Node | BoundaryCondition) -> float | int | np.number:
        """
        Return the effective area of this ChannelNode.

        Parameters
        ----------
        asking_node : Node | BoundaryCondition
            The Node that asks for the area of this Node. It is used to calculate the shift in position and to return
            the associated surface area accordingly.

        Returns
        -------
        float | int | np.number :
            The area of the surface of the cell that has the normal vector of the line you get connecting both `self`
            and `asking_node`.
        """
        connected_mass_transport_resistors = self.mass_transport_resistors

        if isinstance(asking_node, ConnectedFlowObject):
            return self.flow_area

        if len(connected_mass_transport_resistors) < 3:
            return self.circumference * self.flow_length / 2
        else:
            return self.circumference * self.flow_length / len(connected_mass_transport_resistors)

    # def volume_flow(self, *args, **kwargs) -> float | int | np.number:
    #     """
    #     Returns the volume flow for the asking Resistor using a diameter that has the same value as the cell
    #     height/width/depth.
    #
    #     The length of which edge of the cell is used is determined by the asking resistor.
    #
    #     Returns
    #     -------
    #     float | int | np.number :
    #         The volume flow of the `MassFlowNode` in m^3/s.
    #     """
    #     return self.flow_area * self.velocity


class AirNode(MassFlowNode):

    def __init__(self,
                 temperature: float | int | np.number,
                 position: np.ndarray,
                 temperature_derivative: float | int | np.number = 0,
                 rc_objects: RCObjects = initial_rc_objects,
                 rc_solution: RCSolution = solution_object,
                 **kwargs):
        super().__init__(material=Air(),
                         temperature=temperature,
                         position=position,
                         temperature_derivative=temperature_derivative,
                         rc_objects=rc_objects,
                         rc_solution=rc_solution,
                         **kwargs)
