#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

import multiprocessing as mp
import os
import time
from copy import copy
from typing import Any, Callable

from pyrc.core.network import RCNetwork
from pyrc.core.settings import initial_settings as i_settings, Settings
from pyrc.core.components.templates import EquationItem, RCObjects, RCSolution

from pyrc.tools.functions import add_leading_underscore, subtract_seconds_from_string


class Simulation:
    """
    Handle one RC network simulation including pre-simulation.

    The pre-simulation determines correct initial values for the network by calculating a time range before the real
    simulation. The pre-simulation can be done with varying weather data or just static simulation of the initial
    boundary conditions of the network. But because of the time dependent values of all capacities it is recommended to
    use the option with varying (realistic) boundary data.

    The pre-simulation is saved as single initial values that can be loaded in. It is executed only once and then loaded
    in from file.

    """

    def __init__(
        self,
        network_class: type(RCNetwork) = None,
        network_keyword_arguments: dict[str, Any] = None,
        pre_calculation_seconds: int | float = 36000,
        t_span: tuple = None,
        name_add_on: str = None,
        settings: Settings = None,
        pre_calculation_settings: Settings = None,
        print_progress: bool = True,
        time_dependent_function: Callable | Any = None,
    ) -> None:
        self.network_class = network_class
        self.network_keyword_arguments = network_keyword_arguments
        self.pre_calculation_seconds: int | float = pre_calculation_seconds
        self.t_span: tuple = t_span
        self.name_add_on: str = name_add_on
        self.settings: Settings = settings
        self.pre_calculation_settings: Settings = pre_calculation_settings
        self.print_progress: bool = print_progress
        self.time_dependent_function: Callable = time_dependent_function

        self.network = None

    def run(
        self,
        network_class: type(RCNetwork) = None,
        network_keyword_arguments: dict[str, Any] = None,
        t_span: tuple = None,
        name_add_on: str = None,
        settings: Settings = None,
        pre_calculation_settings: Settings = None,
        print_progress: bool = None,
        time_dependent_function: Callable | Any = None,
    ):
        """
        Run the simulation including pre-simulation with the passed network type.

        Parameters
        ----------
        network_class : type(RCNetwork)
            The RCNetwork that is created for the simulation.
        network_keyword_arguments : dict[str, Any]
            The keyword arguments for the RCNetwork object that is created.
        t_span : tuple
            The t_span for the simulation: (start, end) in seconds.
            It should start at 0 (otherwise it can work but it's not tested).
        name_add_on : str, optional
            An add-on for the name to identify the name to the worker.
            If None, a random five digits integer is used (with leading zeros).
        settings : Settings, optional
            The settings for the network and simulation.
            If None, the initial settings dict from the network is used.
        pre_calculation_settings : Settings, optional
            The settings for the pre-calculation. Should only vary in the weather data start date.
            If None, the initial settings dict from the network is used, but with static calculation.
        print_progress : bool, optional
            Whether to print some progress information during the simulation.
        """
        self.network = self._worker(
            network_class=network_class or self.network_class,
            network_copy_dict=network_keyword_arguments or self.network_keyword_arguments or {},
            pre_calculation_seconds=self.pre_calculation_seconds,
            t_span_simulation=t_span or self.t_span,
            name_add_on=name_add_on or self.name_add_on,
            settings=settings or self.settings,
            pre_calculation_settings=pre_calculation_settings or self.pre_calculation_settings,
            print_progress=print_progress if print_progress is not None else self.print_progress,
            return_network=True,
            time_dependent_function=time_dependent_function or self.time_dependent_function,
        )

    @staticmethod
    def _worker(
        network_class: type(RCNetwork),
        network_copy_dict: dict,
        pre_calculation_seconds: int | float,
        t_span_simulation: tuple,
        name_add_on: str = None,
        settings: Settings = None,
        pre_calculation_settings: Settings = None,
        print_progress: bool = True,
        return_network: bool = False,
        time_dependent_function: Callable | Any = None,
    ) -> RCNetwork or None:
        """
        Runs a single simulation. Only pass a copy of network!

        Remember: The network shouldn't exist / built yet because it's not pickable. The network is created newly and if
        the matrices are already created they are loaded from file.
        Not only the unpickable state of the network forces the creation of the network within this method but also the
        network dependency on both rc_objects and rc_solution objects.

        Parameters
        ----------
        network_class : type(RCNetwork)
            The RCNetwork that is created for the simulation.
        network_copy_dict : dict
            A dictionary to give RCNetwork as keyword arguments for initializing.
            This bypasses to move the unpickable RCNetwork object to the worker and instead creates it inside the
            worker.
        pre_calculation_seconds : int | float
            See main class.
        t_span_simulation : tuple
            The t_span for the simulation: (start, end) in seconds.
            It should start at 0 (otherwise it can work but it's not tested).
        name_add_on : str, optional
            An add-on for the name to identify the name to the worker.
        settings : Settings, optional
            The settings for the network and simulation.
            If None, the initial settings dict from the network is used.
        pre_calculation_settings : Settings, optional
            The settings for the pre-calculation. Should only vary in the weather data start date.
            If None, the initial settings dict from the network is used, but with static calculation or a shifted
            weather start date, if use_weather_data.
        """
        # Just to be safe: Create new RCObjects and RCSolution instances that are not linked to other simulations.
        rc_objects = RCObjects()
        network_copy_dict.update(
            {
                "rc_objects": rc_objects,
                "rc_solution": RCSolution(rc_objects=rc_objects),
            }
        )
        network: RCNetwork = network_class(**network_copy_dict)
        if settings is not None:
            network.settings = copy(settings)
        else:
            settings = copy(network.settings)
        network.create_network()
        test = network.groups["inner"][13].resistors_in_direction((1, 0, 0))[0].resistance

        name_add_on = add_leading_underscore(name_add_on)

        name_prefix = os.path.join(network.settings.save_folder_path, f"{network.hash}{name_add_on}")
        single_solution_name = f"{name_prefix}_{pre_calculation_seconds}_single_solution.pickle"

        if not network.load_initial_values(return_bool=True, pickle_path_single_solution=single_solution_name):
            print(f"{network.hash}: starting pre-calculation")
            if pre_calculation_settings is not None:
                network.settings = pre_calculation_settings
            else:
                if network.settings.use_weather_data:
                    original_date = network.settings.start_date
                    network.settings.start_date = subtract_seconds_from_string(original_date, pre_calculation_seconds)
                    network.settings.calculate_static = False
                    print(f"Dynamic pre-calculation with weather start date: {network.settings.start_date}")
                else:
                    print("Static pre-calculation.")
                    network.settings.calculate_static = True
            t_span = (0, pre_calculation_seconds)
            network.solve_network(
                t_span,
                print_progress=print_progress,
                name_add_on=name_add_on + "_pre_calculation",
                time_dependent_function=time_dependent_function,
            )

            # save last solution to load it back in later
            network.rc_solution.save_last_step(single_solution_name)

            # delete all static solutions in the solutions object and free space for dynamic solution
            network.rc_solution.delete_solutions(confirm=True)
            network.reset_properties()

            assert network.load_initial_values(return_bool=True, pickle_path_single_solution=single_solution_name)
            network.settings = settings  # change back to original settings
            print(f"{network.hash}: pre-calculation done.")
        else:
            print(f"{network.hash}: pre-calculation was loaded from file.")

        t_span = t_span_simulation
        network.solve_network(
            t_span,
            print_progress=print_progress,
            name_add_on=name_add_on,
            time_dependent_function=time_dependent_function,
        )
        # result is saved in network.solve_network so it doesn't need to be saved in here.
        # file_path = f"{name_prefix}_result.pickle"
        # network.rc_solution.save_solution(file_path)

        if return_network:
            return network


class Parameterization(Simulation):
    """
    Class to handle `RCNetwork` calculations that are quite similar but differ in one settings parameter.

    All calculations are run in parallel.
    """

    def __init__(
        self,
        parameters_tuples: list[tuple],
        pre_calculation_seconds=36000,
        initial_settings_dict: dict = i_settings,
        max_core_number=0,
        t_span=None,
    ):
        """

        Parameters
        ----------
        parameters_tuples : list[tuple]
            Defining the parameters for each simulation:
            for parameters in parameters_tuples:
                network_type: type = parameters[0]
                settings_dict = parameters[1]
                network_parameters = parameters[2]
                t_span = parameters[3]
                name_add_on = parameters[4]
        pre_calculation_seconds : int | float, optional
            How long the static calculation before the dynamic calculation should be.
        initial_settings_dict : dict, optional
            The initial settings to use for the calculations. If not given, the initial ones from ``core.settings`` is
            used.
        max_core_number : int, optional
            An optional limit how many cores can be used for the calculations.
            0 for no limit.
        """
        super().__init__(pre_calculation_seconds=pre_calculation_seconds, settings=initial_settings_dict)
        self.parameters_tuples: list[tuple] = parameters_tuples

        if t_span is None:
            t_span = (0, 8760 * 3600)
        self.t_span = t_span

        if max_core_number <= 0:
            max_core_number = mp.cpu_count()
        self.max_core_number: int = min(max_core_number, mp.cpu_count())

    def get_parameters(self, parameters: tuple):
        """
        Returns the first few parameters for the worker method.

        Parameters
        ----------
        parameters : tuple
            The tuple out of self.parameters_tuples

        Returns
        -------
        tuple :
            The parameters as tuple.
        """
        network_type: type = parameters[0]
        settings_dict = parameters[1]
        network_parameters = parameters[2]
        t_span = parameters[3]
        name_add_on = parameters[4]

        settings = Settings(**settings_dict)
        network_parameters.update(
            {
                "settings": settings,
                "load_from_pickle": True,
                "save_to_pickle": True,
                "num_cores_jacobian": 1,
                "rc_objects": RCObjects(),
                "rc_solution": RCSolution(),
            }
        )

        pre_settings_dict = settings_dict.copy()
        try:
            original_date = settings_dict["start_date"]
        except KeyError:
            original_date = "2022-01-01T00:00:00"
        pre_settings_dict.update(
            {"start_date": subtract_seconds_from_string(original_date, self.pre_calculation_seconds)}
        )
        pre_settings = Settings(**pre_settings_dict)

        return (
            network_type,
            network_parameters,
            self.pre_calculation_seconds,
            t_span,
            name_add_on,
            settings,
            pre_settings,
            False,
        )

    def pre_create_jacobians(self):
        """
        Pre-creates the jacobian matrices of all RCNetworks if not already found in pickle file.

        This is useful to quickly generate all jacobian matrices outside the workers so that they only need to load
        the matrices and lambdify them.

        Returns
        -------

        """
        for parameters in self.parameters_tuples:
            # Reset class attribute from Equation item to get the same hash values for equal networks
            EquationItem.item_counter = 0
            params = self.get_parameters(parameters)
            network_type, network_parameters = params[:2]

            network_parameters = network_parameters.copy()
            network_parameters.update(
                {
                    "load_from_pickle": True,
                    "save_to_pickle": True,
                    "num_cores_jacobian": self.max_core_number,
                    "rc_objects": RCObjects(),
                    "rc_solution": RCSolution(),
                }
            )
            # {"load_from_pickle": True, "save_to_pickle": True, "num_cores_jacobian": 1})  # for debugging
            network: RCNetwork = network_type(**network_parameters)

            network.create_network()
            network.make_system_matrices()
            print(f"{params[5]}: Jacobi pre-calculation done for hash: {network.hash}")

    def run(self):
        # first create the jacobian matrices for all networks using all cores
        self.pre_create_jacobians()

        if self.max_core_number == 1:
            print("Using single core calculation.")
            for parameters in self.parameters_tuples:
                worker_parameters = self.get_parameters(parameters)
                # check name_add_on
                if worker_parameters[5] == "" or worker_parameters[5] is None:
                    worker_parameters = (*worker_parameters[:5], f"1", *worker_parameters[6:])
                self._worker(*worker_parameters)
                print(f"Starting process: {worker_parameters[5]}")
        else:
            # create single processes that run the parameter simulations
            active = []
            process_infos = []
            process_id = 0
            for parameters in self.parameters_tuples:
                # Wait until a slot is free
                while len(active) >= self.max_core_number:
                    skip_waiting = False
                    for idx, p in enumerate(active):
                        if not p.is_alive():
                            p.join()
                            proc_id, name_addon, p_name = process_infos[idx]
                            print(f"Process {proc_id} with name AddOn '{name_addon}' finished. Proc name {p_name}")
                            skip_waiting = True
                    if not skip_waiting:
                        time.sleep(0.1)  # small delay to avoid busy-waiting
                    mask = [p.is_alive() for p in active]
                    active = [p for p, alive in zip(active, mask) if alive]
                    process_infos = [info for info, alive in zip(process_infos, mask) if alive]

                worker_parameters = self.get_parameters(parameters)
                # check name_add_on
                if worker_parameters[5] == "" or worker_parameters[5] is None:
                    worker_parameters = (*worker_parameters[:5], f"{process_id}", *worker_parameters[6:])
                process = mp.Process(target=self._worker, args=worker_parameters)
                print(f"Starting process {process_id} - name AddOn: {worker_parameters[5]} -  Proc name {process.name}")
                process.start()
                active.append(process)
                process_infos.append((process_id, worker_parameters[5], process.name))
                process_id += 1

            while active:
                skip_waiting = False
                for idx, p in enumerate(active):
                    if not p.is_alive():
                        p.join()
                        proc_id, name_addon, p_name = process_infos[idx]
                        print(f"Process {proc_id} (name: {p_name}) with name AddOn '{name_addon}' finished.")
                        skip_waiting = True
                if not skip_waiting:
                    time.sleep(0.1)
                active_infos = [(p, info) for p, info in zip(active, process_infos) if p.is_alive()]
                active, process_infos = zip(*active_infos) if active_infos else ([], [])

        print("All processes finished.")
