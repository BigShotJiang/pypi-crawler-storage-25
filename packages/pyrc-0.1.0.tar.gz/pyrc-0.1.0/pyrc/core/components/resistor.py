#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

from __future__ import annotations

from _warnings import warn
from typing import Any, TYPE_CHECKING

import numpy as np
from sympy import symbols

from pyrc.core.components.templates import ObjectWithPorts, SymbolMixin
from pyrc.tools.functions import contains_symbol
from pyrc.tools.science import round_valid

if TYPE_CHECKING:
    from pyrc.core.nodes import Node
    from pyrc.core.components.node import TemperatureNode
    from pyrc.core.components.capacitor import Capacitor


class Resistor(ObjectWithPorts, SymbolMixin):
    resistor_counter = 0

    def __init__(self, resistance=np.nan):
        """
        (Thermal) resistor element of an RC network.

        This is the base class of all Resistors and heat and mass transfer/transport elements calculating the
        resistance by their own.

        Parameters
        ----------
        resistance : float | int | np.number
            The (thermal) resistance of the `Resistor` in K/W.
        """
        ObjectWithPorts.__init__(self)
        if not contains_symbol(resistance):
            resistance = np.float64(resistance)
        self._resistance = resistance
        Resistor.resistor_counter += 1
        self.id = Resistor.resistor_counter
        self.__direct_connected_node_templates = None

        # Create sympy symbols to put in the equation(s)
        # Has to be at the end of init (after self.id)
        self.resistance_symbol = symbols(f"R_{self.id}")
        self._equivalent_resistance_symbol = None

    @classmethod
    def reset_counter(cls):
        Resistor.resistor_counter = 0

    def __str__(self):
        return self.__repr__()

    def __repr__(self):
        return f"{self.__class__.__name__} {self.id}: 1/R={round_valid(1 / self._resistance, 3)}"

    @property
    def nodes(self):
        """
        Returns both connected nodes, no matter, if other resistors are between them.

        Returns
        -------
        list :
            The Nodes in a list.
        """
        result = []
        seen = {self}
        to_check = self.neighbours.copy()

        from pyrc.core.components.node import TemperatureNode

        while to_check and len(result) < 2:
            current = to_check.pop()
            if current in seen:
                continue
            seen.add(current)

            if isinstance(current, TemperatureNode):
                result.append(current)
            else:
                to_check.extend(n for n in current.neighbours if n not in seen)
        assert len(result) <= 2, (
            "Each Resistor should only be connected two a maximum of 2 TemperatureNodes.\nIf it is "
            "connected to more than 2 (also over other Resistors) you must insert a Node."
        )
        return sorted(result, key=lambda node: node.id)

    @property
    def direct_connected_node_templates(self):
        if self.__direct_connected_node_templates is None:
            from pyrc.core.components.node import TemperatureNode

            self.__direct_connected_node_templates = [
                neighbour for neighbour in self.neighbours if isinstance(neighbour, TemperatureNode)
            ]
        return self.__direct_connected_node_templates

    @property
    def symbols(self) -> list:
        # return [self.resistance_symbol, self.equivalent_resistance_symbol]
        return [self.equivalent_resistance_symbol]

    @property
    def values(self) -> list:
        # return [self.resistance, self.equivalent_resistance]
        return [self.equivalent_resistance]

    @property
    def all_resistors_inbetween(self) -> list[Resistor]:
        """
        Returns all resistors between both connected `TemperatureNode`\s including self.

        Returns
        -------
        list[Resistor] :
            All Resistors that form the equivalent resistor between both connected `TemperatureNode`\s.
        """
        seen = {self}
        to_check = self.neighbours.copy()
        while to_check:
            current = to_check.pop()
            if current not in seen and isinstance(current, Resistor):
                seen.add(current)
                to_check.extend([n for n in current.neighbours if n not in seen])
        return sorted(list(seen), key=lambda res: res.id)

    @property
    def equivalent_resistance(self) -> np.float64:
        """
        Returns the equivalent resistance from one node to the other.

        This considers both serial and parallel Resistors between the same Nodes.

        Returns
        -------
        np.float64 :
            The equivalent resistance from one node to the other.
        """
        nodes = self.direct_connected_node_templates
        assert len(nodes) > 0, (
            "This property is meant to be executed only for resistors that are connected to one TemperatureNode."
        )
        if len(nodes) == 2:
            return self.resistance

        def run_through_resistors(start_resistor: Resistor, start_node: Capacitor):
            _equivalent_serial = start_resistor.resistance
            _parallel_resistors = [
                neighbour for neighbour in start_resistor.neighbours if isinstance(neighbour, Resistor)
            ]
            _current = start_resistor
            while len(_parallel_resistors) == 1:
                _equivalent_serial += _parallel_resistors[0].resistance
                _parallel_resistors, _current = (
                    [
                        neighbour
                        for neighbour in _parallel_resistors[0].neighbours
                        if isinstance(neighbour, Resistor)
                        and neighbour is not _current
                        and neighbour.get_connected_node(_parallel_resistors[0]) is not start_node
                    ],
                    _parallel_resistors[0],
                )
            return _equivalent_serial, _parallel_resistors, _current

        # calculate the equivalent resistance
        equivalent_serial, parallel_resistors, current = run_through_resistors(self, nodes[0])
        if len(parallel_resistors) > 1:
            equivalent_parallel = parallel_equivalent_resistance(current)
        else:
            # Doing the same thing just the other way round.
            # parallel resistors list is empty because the Resistor "current" at the end (right before a Node)
            # now you need to check if there are parallel Resistors if walking in the other direction
            equivalent_serial, parallel_resistors, current = run_through_resistors(
                current, current.direct_connected_node_templates[0]
            )
            if len(parallel_resistors) > 1:
                equivalent_parallel = parallel_equivalent_resistance(current)
            else:
                # parallel_resistors is empty
                equivalent_parallel = 0

        # serial resistance between both equivalents
        return equivalent_parallel + equivalent_serial

    @property
    def equivalent_resistance_symbol(self):
        if self._equivalent_resistance_symbol is None:
            resistors = self.all_resistors_inbetween
            symbol = symbols("_".join([f"{r}" for r in ["R_eq", *[res.id for res in resistors]]]))

            # set this symbol to all other resistors (including self)
            for r in resistors:
                r._equivalent_resistance_symbol = symbol
        return self._equivalent_resistance_symbol

    # def get_equivalent_resistors(self) -> list:
    #     """
    #     Returns a list with all resistors between the two nodes self is connected with.
    #
    #     Returns
    #     -------
    #     list :
    #     """
    #     node1, node2 = self.nodes
    #     result = set()
    #
    #     neighbour: Resistor
    #     for neighbour in node1.neighbours:
    #         if neighbour.get_connected_node(node1) == node2:
    #             result.add(neighbour)
    #             connected_resistors
    #
    # def get_connected_resistors(self, include_self=False) -> list:
    #     """
    #     Returns a list with all resistors that are connected to this resistor or the connected ones.
    #
    #     Parameters
    #     ----------
    #     include_self : bool, optional
    #         If True, self is included in the result.
    #
    #     Returns
    #     -------
    #     list :
    #         All connected resistors.
    #     """
    #     result = []
    #     visited = set()
    #     to_check = [neighbour for neighbour in self.neighbours if isinstance(neighbour, Resistor)]
    #
    #     for resistor in to_check:
    #         visited.add(resistor)
    #
    #     while to_check:
    #         resistor = to_check.pop()
    #         result.append(resistor)
    #         for neighbour in resistor.neighbours:
    #             if isinstance(neighbour, Resistor) and neighbour not in visited:
    #                 visited.add(neighbour)
    #                 to_check.append(neighbour)
    #
    #     if include_self:
    #         result.append(self)
    #
    #     return result

    @property
    def resistance(self) -> float | int | np.nan:
        return self._resistance

    def heat_flux(self, asking_node: Capacitor) -> float:
        """
        Returns the accumulated heat flux of this node that is transferred into the ``asking_node``.

        Parameters
        ----------
        asking_node : Capacitor
            The Node asking for the heat flux.
            If the result is positive that heat flows into the asking_node.

        Returns
        -------
        float :
            The heat flux flowing into the asking_node in W.
        """
        if self.neighbours[0] == asking_node:
            other_node = self.neighbours[1]
        else:
            other_node = self.neighbours[0]
        other_node: Capacitor

        return 1 / self.resistance * (other_node.temperature - asking_node.temperature)

    def connect(self, neighbour, direction: tuple | list | np.ndarray | Any = None, node_direction_points_to=None):
        super().connect(neighbour, direction, node_direction_points_to)
        # check, if direction is set manually if BoundaryCondition and Cell are involved
        from pyrc.core.components.templates import Cell

        if len(self.nodes) == 2 and (isinstance(self, Cell) or isinstance(neighbour, Cell)):
            from pyrc.core.nodes import BoundaryCondition, Node

            for i, neighbour in enumerate(self.nodes):
                if isinstance(neighbour, BoundaryCondition):
                    # check, if manual_directions of other neighbour was set
                    if isinstance(self.nodes[(i + 1) % 2], Node):
                        if neighbour not in self.nodes[(i + 1) % 2].manual_directions:
                            raise ValueError("Direction must be set manually if BoundaryCondition is involved.")
                    else:
                        raise NotImplementedError(
                            "FAAIIILLL. What kind of object is connected here? Two "
                            "BoundaryConditions? Or two Resistors???"
                        )

    def get_connected(self, asking_node: Capacitor | Node | Resistor) -> list[TemperatureNode | Resistor]:
        """
        Returns the neighbour that isn't the asking one.

        Parameters
        ----------
        asking_node : Capacitor | Node
            The asking Node. The method will return the other neighbour of ``self``.

        Returns
        -------
        TemperatureNode :
            The other neighbour of ``self``.
        """
        assert asking_node in self.neighbours, "The asking_node is not connected to self."
        return [n for n in self.neighbours if n is not asking_node]

    def get_connected_node(self, asking_node: TemperatureNode | Resistor) -> TemperatureNode:
        """
        Returns the connected TemperatureNode that isn't the asking one. It is routed through all connected Resistors to
        the TemperatureNode.

        Parameters
        ----------
        asking_node : Capacitor | Resistor
            The asking Node. The method will return the other node connected (over other `Resistor`\s) to self.

        Returns
        -------
        TemperatureNode :
            The other node connected to ``self``.
        """
        assert asking_node in self.neighbours, "The asking_node is not connected to self."
        if isinstance(asking_node, Resistor) and len(self.neighbours) > 2:
            warn("It is not defined, which node is returned. The first one found is returned.")
        seen_nodes = {asking_node, self}
        to_check = [n for n in self.neighbours if n is not asking_node]

        from pyrc.core.components.node import TemperatureNode

        while to_check:
            current = to_check.pop()
            if current in seen_nodes:
                continue
            seen_nodes.add(current)

            if isinstance(current, TemperatureNode):
                return current

            to_check.extend(n for n in current.neighbours if n not in seen_nodes)
        raise ValueError(f"No connected TemperatureNode found: {self}")


def parallel_equivalent_resistance(start_resistor: Resistor, ignore_resistor: Resistor = None) -> np.float64:
    """
    Calculates the equivalent resistance of the connected Resistors.

    It also checks if the connected Resistors are connected to other Resistors in serial and consider this, too.

    This only works, if no other parallel resistors occur. But this should be okay, because this doesn't make any sense
    thermo-physically.

    Parameters
    ----------
    start_resistor : Resistor
        The start Resistor, where in one "direction" parallel resistors are connected to (can also be just one).
    ignore_resistor : Resistor, optional
        If given this Resistor is excluded from the neighbours list of start_resistor.
        This is needed to determine some kind of "direction" and only calculate the equivalent resistance for the
        Resistors that are actually parallel.

    Returns
    -------
    np.float64 :
        The equivalent resistance of the connected Resistors without the resistance of the start_resistor.
    """
    parallel_resistors = [neighbour for neighbour in start_resistor.neighbours if isinstance(neighbour, Resistor)]
    if ignore_resistor is not None:
        try:
            parallel_resistors.remove(ignore_resistor)
        except ValueError:
            # ignore_resistor not in neighbours of start_resistor
            pass
    parallel_resistance_list = []
    for resistor in parallel_resistors:
        parallel_resistance = resistor.resistance
        current = resistor
        connected: list = current.get_connected(start_resistor)
        assert len(connected) == 1, "Currently in parallel circuits no other nested parallel circuits are allowed."
        connected = connected[0]
        while isinstance(connected, Resistor):
            assert len(connected.neighbours) == 2, (
                "No series of parallel Resistors are allowed. Just one Resistor "
                "that is connected to multiple others in parallel\n"
                "which themselves can be serial connected to others, but not parallel!"
            )
            parallel_resistance += connected.resistance
            connected, current = connected.get_connected(current), connected
            assert len(connected) == 1, "Currently in parallel circuits no other nested parallel circuits are allowed."
            connected = connected[0]
        parallel_resistance_list.append(parallel_resistance)
    return 1 / np.float64(sum([1 / np.float64(r) for r in parallel_resistance_list]))
