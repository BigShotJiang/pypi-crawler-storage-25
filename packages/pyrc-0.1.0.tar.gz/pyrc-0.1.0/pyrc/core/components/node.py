#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------
from __future__ import annotations
from abc import abstractmethod
from typing import Any, TYPE_CHECKING

import numpy as np
import pandas as pd
from sympy import Basic, symbols

from pyrc.core.components.templates import (
    ObjectWithPorts,
    EquationItem,
    RCObjects,
    initial_rc_objects,
    RCSolution,
    solution_object,
)

if TYPE_CHECKING:
    from pyrc.core.components.resistor import Resistor


class TemperatureNode(ObjectWithPorts, EquationItem):
    def __init__(
        self,
        temperature,
        rc_objects: RCObjects = None,
        temperature_derivative=0,
        rc_solution: RCSolution = None,
    ):
        """
        Capacitor building part, currently designed as thermal capacitor.

        Parameters
        ----------
        temperature : float | int
            The temperature of the node.
        temperature_derivative : float | int
            The temperature derivative of the node.
        rc_objects : RCObjects, optional
            An `RCObjects` object to store all building parts (`Capacitor`\s, `Resistor`\s, ...)
            If None, an initial object will be used.
        rc_solution : RCSolution, optional
            An `RCSolution` object where the solution is stored.
            If None, an initial solution will be used.
        """
        if rc_objects is None:
            rc_objects = initial_rc_objects
        if rc_solution is None:
            rc_solution = solution_object
        ObjectWithPorts.__init__(self)
        EquationItem.__init__(self)
        self.rc_objects = rc_objects

        assert not (isinstance(temperature, Basic) and temperature.free_symbols)
        self.initial_temperature = temperature
        self.temperature_derivative = temperature_derivative

        self.temperature_symbol = symbols(f"theta_{self.id}")

        self.manual_directions = {}  # store manual set directions. Used for connected BoundaryConnections

        # make space for results
        self.solutions: RCSolution = rc_solution

        # Cashing
        self.__connected_mass_flow_nodes = None

        # make space for results
        self.solutions: RCSolution = rc_solution

    @property
    @abstractmethod
    def index(self) -> int:
        """
        Returns the position of self within the vector where the temperature is stored in.

        Is currently defined by its subclasses using the result object.

        Returns
        -------
        int :
            The index of the vector.
        """
        pass

    @property
    def temperature(self) -> float | np.number | int | Any:
        if self.solutions.exist:
            return self.solutions.temperature_vectors[-1, self.index]
        return self.initial_temperature

    @property
    def temperature_vector_pandas(self) -> pd.Series:
        """
        The result vector of one node as pandas Series.

        Returns
        -------
        pd.Series
        """
        return self.solutions.temperature_vectors_pandas.iloc[:, self.index]

    @property
    def temperature_vector(self) -> np.ndarray:
        if self.solutions.exist:
            return self.solutions.temperature_vectors[:, self.index]
        return np.array([self.initial_temperature])

    def temperature_at_time(self, time_step: list | float | int) -> np.float64 | list:
        if isinstance(time_step, list):
            result = []
            for step in time_step:
                result.append(np.interp(step, self.solutions.time_steps, self.temperature_vector))
            return result
        else:
            return np.interp(time_step, self.solutions.time_steps, self.temperature_vector)

    @property
    def symbols(self) -> list:
        """
        Returns a list of all sympy.symbols of the object, except time dependent symbols.

        Must be in the same order as self.values.

        Returns
        -------
        list :
            The list of sympy.symbols.
        """
        return [self.temperature_symbol]

    @property
    def values(self) -> list:
        """
        Returns a list of all values of all object symbols, except of time dependent symbols.

        Must be in the same order as self.symbols.

        Returns
        -------
        list :
            The list of sympy.symbols.
        """
        return [self.temperature]

    def get_resistors_between(self, node) -> list[Resistor]:
        """
        Returns all resistors between self and node.

        Parameters
        ----------
        node : TemperatureNode
            The TemperatureNode to which the resistors should go.

        Returns
        -------
        list[Resistor] :
            A list with all resistors between self and node.
        """
        resistor: Resistor
        for resistor in self.neighbours:
            if resistor.get_connected_node(self) == node:
                return resistor.all_resistors_inbetween
        raise ValueError("No resistors between two TemperatureNodes. This is not allowed.")

    def filter_resistors_equivalent(self, resistors=None):
        """
        Returns all neighbours without the ones that are connected to the same node.

        Used for equivalent resistances.

        Parameters
        ----------
        resistors : list[Resistor], optional
            The resistors to filter.

        Returns
        -------
        list[Resistor] :
            The filtered list.
        """
        if resistors is None:
            resistors = self.neighbours
        else:
            for r in resistors:
                assert r in self.neighbours
        result = []
        seen_nodes = set()
        for resistor in resistors:
            node = resistor.get_connected_node(self)
            if node not in seen_nodes:
                result.append(resistor)
                seen_nodes.add(node)
        return sorted(result, key=lambda obj: obj.id)

    def set_direction(self, node_direction_points_to: "TemperatureNode", direction: np.ndarray):
        """
        Adding a manual direction from self to the given node.

        The direction has to be a np.ndarray like:
            [1,0,0] or [0,1,0] or [0,0,1] or negative ones of this.

        Parameters
        ----------
        node_direction_points_to : TemperatureNode
            The node where the direction points to.
        direction : np.ndarray
            The direction to the ``node_direction_points_to``\. Has to be a np.ndarray.
        """
        direction = np.array(direction).ravel()
        if len(direction) == 1:
            np.append(direction, np.array([0, 0]))
        elif len(direction) == 2:
            np.append(direction, np.array([0]))
        elif len(direction) != 3:
            raise ValueError(f"direction must have 1,2, or 3 values, got {direction.shape}")
        valid = np.array([[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]])
        if not any(np.array_equal(direction, v) for v in valid):
            raise ValueError(f"direction must be one of ±[1,0,0], ±[0,1,0], ±[0,0,1], got {direction}")
        self.manual_directions[node_direction_points_to] = direction
