#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import numpy as np
from sympy import symbols

from pyrc.core.components.node import TemperatureNode
from pyrc.core.components.templates import (
    initial_rc_objects,
    solution_object,
    ConnectedFlowObject,
    Cell,
)

if TYPE_CHECKING:
    from pyrc.core.components.resistor import Resistor
    from pyrc.core.nodes import Node
    from pyrc.core.resistors import MassTransport
    from pyrc.core.inputs import InternalHeatSource
    from pyrc.core.nodes import MassFlowNode
    from pyrc.core.components.templates import RCObjects, RCSolution


class Capacitor(TemperatureNode):
    def __init__(
        self,
        capacity: float,
        temperature,
        rc_objects: RCObjects = initial_rc_objects,
        temperature_derivative=0,
        internal_heat_source: InternalHeatSource = None,
        rc_solution: RCSolution = solution_object,
    ):
        """
        Capacitor building part, currently designed as thermal capacitor.

        Parameters
        ----------
        capacity : float
            The capacity of the capacitor.
        temperature : float | int
            The temperature of the node.
        temperature_derivative : float | int
            The temperature derivative of the node.
        """
        super().__init__(
            temperature=temperature,
            rc_objects=rc_objects,
            temperature_derivative=temperature_derivative,
            rc_solution=rc_solution,
        )
        if type(self) is Capacitor and (capacity is None or capacity == np.nan or capacity == 0):
            # subclasses are allowed to set capacity to None (see Node)
            raise TypeError("Capacitor requires 'capacity'")
        self._capacity = capacity

        self.__internal_heat_source: InternalHeatSource | Any = internal_heat_source

        # Cashing
        self.__connected_mass_flow_nodes = None

        # Create sympy symbols to put in the equation(s)
        # Has to be at the end of init (after self.id)
        self.capacity_symbol = symbols(f"C_{self.id}")

    @property
    def index(self):
        if not self._index:
            self._index = self.rc_objects.nodes.index(self)
        return self._index

    @property
    def internal_heat_source(self) -> InternalHeatSource:
        return self.__internal_heat_source

    def make_internal_heat_source(self, heat_source_type, **kwargs):
        self.__internal_heat_source = heat_source_type(node=self, **kwargs)

    def add_internal_heat_source(self, heat_source: InternalHeatSource):
        assert heat_source.node == self
        self.__internal_heat_source = heat_source

    @property
    def resistors_without_parallel(self):
        """
        Returns every resistor on the node that isn't connected to the same as another.

        If multiple resistors are in self.neighbours and are connected to the same node the first one is taken (more
        or less random).

        Returns
        -------

        """
        resistors: Resistor = self.neighbours
        seen_nodes = set()
        result = []
        for resistor in resistors:
            connected_node = resistor.get_connected_node(self)
            if connected_node not in seen_nodes:
                seen_nodes.add(connected_node)
                result.append(resistor)
        return result

    @property
    def symbols(self) -> list:
        """
        Returns a list of all sympy.symbols of the object, except time dependent symbols.

        Must be in the same order as self.values.

        Returns
        -------
        list :
            The list of sympy.symbols.
        """
        result = [*super().symbols, self.capacity_symbol]
        if self.internal_heat_source:
            result.append(self.internal_heat_source.symbol)
        return result

    @property
    def values(self) -> list:
        """
        Returns a list of all values of all object symbols, except of time dependent symbols.

        Must be in the same order as self.symbols.

        Returns
        -------
        list :
            The list of sympy.symbols.
        """
        result = [*self.values_without_capacity, self._capacity]
        return result

    @property
    def values_without_capacity(self) -> list:
        """
        Returns a list of all values of all object symbols expect the capacity and the time dependent symbols.

        This is used in some subclasses that calculate their capacity on their own.

        Must be in the same order as self.symbols.

        Returns
        -------
        list :
            The list of sympy.symbols.
        """
        result = super().values
        if self.internal_heat_source:
            result.append(self.internal_heat_source.power)
        return result

    @property
    def mass_flow_connections(self) -> int:
        """
        Returns the number of `MassFlowNode` s connected to ``self``.

        Returns
        -------
        int :
            The number of connected `MassFlowNode` s.
        """
        return len(self.connected_mass_flow_nodes)

    @property
    def connected_mass_flow_nodes(self) -> list[MassFlowNode]:
        if self.__connected_mass_flow_nodes is None:
            self.__connected_mass_flow_nodes = self.get_connected_mass_flow_nodes()
        return self.__connected_mass_flow_nodes

    def temperature_derivative_term(self) -> tuple:
        """
        Create the `sympy` expression for the temperature derivative (right side of heat flux balance equation).

        The sign convention is:
            Heat flux pointing into the node is positive.

        Returns
        -------
        tuple[sympy expression, set] :
            The term and a set with all involved temperature symbols.
        """
        from pyrc.core.resistors import MassTransport

        result_equation = 0
        temperature_symbols = set()
        all_symbols = set()

        # loop over ports/connections
        resistor: Resistor
        for resistor in self.filter_resistors_equivalent():
            connected_node: TemperatureNode = resistor.get_connected_node(self)
            rc_term = 1 / (resistor.equivalent_resistance_symbol * self.capacity_symbol)
            if isinstance(resistor, MassTransport):
                if (resistor.source == self and resistor.volume_flow >= 0) or (
                    resistor.sink == self and resistor.volume_flow < 0
                ):
                    result_equation -= rc_term * self.temperature_symbol
                else:
                    # self is sink
                    result_equation += rc_term * connected_node.temperature_symbol
                    temperature_symbols.add(connected_node.temperature_symbol)
            else:
                # resistor is a resistor, so we have to get the other node connected to it.
                result_equation += rc_term * (connected_node.temperature_symbol - self.temperature_symbol)
                temperature_symbols.add(connected_node.temperature_symbol)
            temperature_symbols.add(self.temperature_symbol)

        # add internal heat source terms
        if self.internal_heat_source:
            result_equation += self.internal_heat_source.symbol / self.capacity_symbol
            all_symbols.add(self.internal_heat_source.symbol)

        all_symbols.update(temperature_symbols)
        return result_equation, temperature_symbols, all_symbols

    def get_mass_transport_to_node(self, target_node: ConnectedFlowObject):
        """
        Returns the `ConnectedFlowObject` `Resistor` lying inbetween self and target_node.

        Parameters
        ----------
        target_node : ConnectedFlowObject
            The `ConnectedFlowObject` to which the MassTransport Resistor is requested for.

        Returns
        -------
        MassTransport :
            The MassTransport Resistor inbetween self and target_node.
        """
        for resistor in self.get_connected_mass_transport_resistors():
            if resistor.get_connected_node(self) == target_node:
                return resistor

    def reset_properties(self):
        self.__connected_mass_flow_nodes = None

    def get_neighbours(self, variant: type = None) -> list:
        """
        Returns a list of connected objects with given variant.

        If variant is ``None``, all objects are returned.

        Parameters
        ----------
        variant : None | type
            The type (of `Resistors`) to return.
            Example: ``variant=MassTransport`` only returns all `MassTransport` resistors.

        Returns
        -------
        list :
            A list with all requested objects.
        """
        if variant is None:
            return self.neighbours
        else:
            result = []
            for resistor in self.neighbours:
                if isinstance(resistor, variant):
                    result.append(resistor)
            return result

    def get_connected_mass_transport_resistors(self, except_this: MassTransport | list = None) -> list:
        """
        Returns a list of connected `MassTransport` resistors except the given ones.

        Parameters
        ----------
        except_this : MassTransport | list
            The given `MassTransport` resistors to exclude from the result.

        Returns
        -------
        list :
            The list of connected `MassTransport` resistors without all given ones.
        """
        from pyrc.core.resistors import MassTransport

        result = self.get_neighbours(variant=MassTransport)
        if isinstance(except_this, MassTransport):
            except_this = [except_this]

        if except_this:
            for except_resistor in except_this:
                if except_resistor in result:
                    result.remove(except_resistor)

        return result

    @property
    def connected_mass_transport_resistors(self) -> list:
        return self.get_connected_mass_transport_resistors()

    def get_connected_nodes(self, variant: type = None) -> list:
        """
        Returns a list of by `Resistor` s connected `TemperatureNode` s.

        Duplicates of connected nodes (due to multiple resistors between two unique nodes) are not returned twice.

        Parameters
        ----------
        variant : None | type
            The type (of `TemperatureNode`) to return.
            If ``None``, all connected nodes are returned.

        Returns
        -------
        list :
            The list of connected `TemperatureNode` s.
        """
        result = []

        if variant is None:
            neighbour: Resistor
            for neighbour in self.neighbours:
                connected: list = neighbour.get_connected(self)
                for c in connected:
                    if c not in result:
                        result.append(c)
        else:
            neighbour: Resistor
            for neighbour in self.neighbours:
                connected: list = neighbour.get_connected(self)
                for c in connected:
                    if isinstance(c, variant) and c not in result:
                        result.append(c)
        return result

    def get_connected_mass_flow_nodes(self) -> list[MassFlowNode]:
        """
        Returns a list of connected `MassFlowNode` s.

        Returns
        -------
        list :
            The list of connected `MassFlowNode` s.
        """
        from pyrc.core.nodes import MassFlowNode

        return self.get_connected_nodes(MassFlowNode)

    def get_next_air_nodes(self, asking_node: Capacitor) -> list[MassFlowNode]:
        """
        Returns the next air nodes as a list.

        Parameters
        ----------
        asking_node : Capacitor
            The Node that asks for the connected `MassFlowNode` s.

        Returns
        -------
        list[MassFlowNode] :
            The connected `MassFlowNode` s of self but without ``asking_node``.
        """
        result = []

        for node in self.connected_mass_flow_nodes:
            if not node == asking_node:
                result.append(node)
        return result

    def resistors_in_direction(
        self, direction: np.ndarray | str, except_resistor_types: list[type] = None
    ) -> list[Resistor]:
        """
        Returns all `Resistor` s connected to nodes in the given direction.

        Parameters
        ----------
        direction : np.ndarray | str
            The direction to get the `Resistor` s from.
            If an array, it has to be parallel to the coordinate axes.
            If a string, it should be of the following:
            +x,+y,+z,-x,-y,-z,x,y,z
        except_resistor_types : list, optional
            If not None, these `Resistor` types will not be added to the result.

        Returns
        -------
        list[Resistor] :
            The `Resistor` s in the requested direction.
        """
        result = []
        if except_resistor_types is None:
            except_resistor_types = []
        if not isinstance(except_resistor_types, list):
            except_resistor_types = [except_resistor_types]

        if isinstance(direction, str):
            if len(direction) == 1 or direction[0] == "+":
                sign = 1
            else:
                sign = -1
            match direction[-1].lower():
                case "x":
                    direction = sign * np.ndarray((1, 0, 0))
                case "y":
                    direction = sign * np.ndarray((0, 1, 0))
                case "z":
                    direction = sign * np.ndarray((0, 0, 1))
                case _:
                    raise ValueError("Invalid direction string. This algorithm only works for rectangular meshes.")

        neighbour_resistors = [
            r for r in self.neighbours if not any(isinstance(r, r_type) for r_type in except_resistor_types)
        ]
        for resistor in neighbour_resistors:
            other_node: Capacitor = resistor.get_connected_node(self)
            neighbour_dir = self.get_direction(other_node)
            if np.allclose((neighbour_dir - direction), 0):
                result.append(resistor)
        return result

    def resistors_in_direction_filtered(
        self, direction: np.ndarray | str, except_resistor_types: list = None
    ) -> list[Resistor]:
        """
        Like resistors_in_direction but only one resistor is returned for parallel resistors.

        Parameters
        ----------
        direction : np.ndarray | str
            The direction to get the `Resistor` s from.
            If an array, it has to be parallel to the coordinate axes.
            If a string, it should be of the following:
            +x,+y,+z,-x,-y,-z,x,y,z
        except_resistor_types : list, optional
            If not None, these `Resistor` types will not be added to the result.

        Returns
        -------
        list[Resistor] :
            The `Resistor` s in the requested direction.
        """
        resistors = self.resistors_in_direction(direction, except_resistor_types)
        return self.filter_resistors_equivalent(resistors)

    def get_direction(self, asking_node: Cell | Capacitor) -> np.array:
        """
        Returns the direction (x,y,z direction) to the asking node. Is returned as normalized vector.

        Parameters
        ----------
        asking_node : Cell
            The Node asking for the direction to it.

        Returns
        -------
        np.ndarray :
            The direction from ``self`` to the asking node.
        """

        # compare the boundaries to get the matching one and determine its direction
        if asking_node in self.manual_directions:
            return np.array(self.manual_directions[asking_node])
        assert isinstance(asking_node, Cell), "Directions have to be set manually if the asking_node is no Cell."
        self: Node
        asking_boundaries = asking_node.boundaries
        self_boundaries = self.boundaries

        diff = []
        for i, element in enumerate(asking_boundaries):
            unit = -1 + 2 * ((i + 1) % 2)  # switch that is -1 if i is odd and +1 if i is even.
            diff.append(element - self_boundaries[i + unit])

        directions = np.array([
            [1, 0, 0], [-1, 0, 0],
            [0, 1, 0], [0, -1, 0],
            [0, 0, 1], [0, 0, -1]
        ])

        # Take the difference that is closest to 0 (without floating point error it will exactly has one 0 in it).
        return directions[np.argmin(np.abs(diff))]
