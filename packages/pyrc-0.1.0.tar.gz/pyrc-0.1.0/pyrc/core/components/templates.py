#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

from __future__ import annotations

import os
import pickle
import re
from abc import abstractmethod, ABC
from typing import Any, TYPE_CHECKING, Optional

import numpy as np
import pandas as pd
import sympy as sp

from vpython import box, vector

from pyrc.core.components.input import Input
from pyrc.core.visualization.color.color import value_to_rgb
from pyrc.tools.errors import FixedPositionError, FixedXYError, FixedZError
from pyrc.tools.functions import is_set
from pyrc.tools.science import is_numeric
from pyrc.visualization.vtk_parser import write_static_cells_vtu, write_temperature_vtu

if TYPE_CHECKING:
    from pyrc.core.inputs import InternalHeatSource
    from pyrc.core.resistors import MassTransport
    from pyrc.core.components.resistor import Resistor
    from pyrc.core.components.node import TemperatureNode


class RCObjects:
    def __init__(self, nodes: list = None, resistors: list = None, boundaries: list = None):
        self.__nodes = nodes
        self.__resistors: list[Resistor] = resistors
        self.__boundaries = boundaries
        self.__input_objs = None
        self.__internal_heat_sources = None

    @property
    def nodes(self) -> list:
        return self.__nodes

    @property
    def mass_flow_nodes(self):
        from pyrc.core.nodes import MassFlowNode
        return [n for n in self.nodes if isinstance(n, MassFlowNode)]

    @property
    def resistors(self) -> list[Resistor]:
        return self.__resistors

    @property
    def boundaries(self) -> list:
        return self.__boundaries

    @property
    def inputs(self) -> list[EquationItemInput]:
        if self.__input_objs is None and self.nodes is not None:
            result = []
            if self.boundaries is not None:
                result.extend(self.boundaries)
            if self.internal_heat_sources is not None:
                result.extend(self.internal_heat_sources)
            self.__input_objs = result
        return self.__input_objs

    @property
    def all(self) -> list[TemperatureNode | Resistor]:
        """
        Returns all `TemperatureNode`\s and `Resistor`\s (network objects, that are linked together).

        `InternalHeatSource` s are not returned!

        Returns
        -------
        list[TemperatureNode | Resistor] :
            Capacitors, BoundaryConditions and Resistors
        """
        result = []
        item: list | None
        for item in [self.__nodes, self.__resistors, self.__boundaries]:
            if item is not None and item != []:
                result.extend(item)
        return result

    @property
    def all_equation_objects(self) -> list[EquationItem]:
        return [*self.all, *self.other_equation_objects]

    @property
    def other_equation_objects(self) -> list[EquationItem]:
        """
        Like `RCObjects.all` but not the connected RC objects were returned but all other `EquationItem` s.

        This is mainly used for `InternalHeatSource` s and in the future for other input items.

        Returns
        -------
        list[InternalHeatSource] :
            All other `EquationItem` s.
            Until now, it's just all InternalHeatSource items.
        """
        return self.internal_heat_sources

    @property
    def internal_heat_sources(self) -> list[InternalHeatSource]:
        if self.__internal_heat_sources is None:
            self.__internal_heat_sources = [n.internal_heat_source for n in self.nodes if n.internal_heat_source]
        return self.__internal_heat_sources

    def set_lists(self,
                  capacitors: list = None,
                  resistors: list = None,
                  boundaries: list = None):
        if capacitors is not None:
            assert isinstance(capacitors, list)
            self.__nodes = capacitors
        if resistors is not None:
            assert isinstance(resistors, list)
            self.__resistors = resistors
        if boundaries is not None:
            assert isinstance(boundaries, list)
            self.__boundaries = boundaries

    @property
    def raw_data(self) -> tuple:
        return (
            self.__nodes,
            self.__resistors,
            self.__boundaries,
            self.__input_objs
        )

    def wipe_all(self):
        """
        Deletes every raw data.
        """
        self.__nodes = None
        self.__resistors = None
        self.__boundaries = None
        self.__input_objs = None
        self.__internal_heat_sources = None

    def get_all_objects(self, variant: type) -> list:
        """
        Returns a list with tuples with all objects in the network with requested variant/type.

        Parameters
        ----------
        variant : type
            The ``type`` of the objects that will be returned.
            Will be used for the ``isinstance()`` match.

        Returns
        -------
        list :
            The list with all objects in the network with requested variant.
        """
        result = []

        for element in self.all:
            if isinstance(element, variant):
                result.append(element)
        return result

    def set_loaded_data(self, loaded_objects: RCObjects):
        """
        Replaces all attributes with the ones of the loaded `RCObjects`.

        Parameters
        ----------
        loaded_objects : RCObjects
            The loaded `RCObjects` that should "replace" self / should be used to overwrite self.

        """
        raw_data = loaded_objects.raw_data
        self.__nodes = raw_data[0]
        self.__resistors = raw_data[1]
        self.__boundaries = raw_data[2]
        self.__input_objs = raw_data[3]


initial_rc_objects = RCObjects()


class SymbolMixin:

    @property
    @abstractmethod
    def symbols(self) -> list:
        """
        Returns a list of all sympy.symbols of the object, except time dependent symbols.

        Must be in the same order as self.values.

        Returns
        -------
        list :
            The list of sympy.symbols.
        """
        pass

    @property
    @abstractmethod
    def values(self) -> list:
        """
        Returns a list of all values of all object symbols, except of time dependent symbols.

        Must be in the same order as self.symbols.

        Returns
        -------
        list :
            The list of sympy.symbols.
        """
        pass

    @property
    def time_dependent_symbols(self) -> list:
        """
        Returns a list of all symbols that are needed to calculate self.value.

        The list is sorted by the name of the symbols for deterministic reasons.

        Returns
        -------
        list :
            All symbols that are needed to calculate self.value (symbols that are time dependent and will be calculated
            between time steps).
        """
        symbols = {sym for value in self.values if isinstance(value, sp.Expr) for sym in value.free_symbols}
        return sorted(symbols, key=lambda s: s.name)


class EquationItem(SymbolMixin, ABC):
    item_counter = 0

    def __init__(self):
        EquationItem.item_counter += 1
        self.id: int = EquationItem.item_counter
        self._index = None

    @classmethod
    def reset_counter(cls):
        EquationItem.item_counter = 0


class RCSolution:
    def __init__(self, rc_objects: RCObjects = initial_rc_objects):
        self.rc_objects = rc_objects
        self.__result_vectors: np.ndarray | Any = None
        self._input_vectors: list = []
        self.time_steps: np.ndarray | Any = None

        self._temperature_dataframe = None
        self._dataframe = None

        self.last_saved_timestep_index = 0

    @property
    def input_exists(self) -> bool:
        if self._input_vectors:
            return True
        return False

    @property
    def inputs(self):
        return self.rc_objects.inputs

    @property
    def nodes(self):
        return self.rc_objects.nodes

    @property
    def input_vectors(self) -> np.ndarray | Any:
        if self._input_vectors:
            return np.concatenate(self._input_vectors, axis=0)
        return None

    def last_value_input(self, index):
        return self._input_vectors[-1][-1, index]

    def append_to_input(self, new_input_vector: np.ndarray):
        self._input_vectors.append(new_input_vector.reshape(1, -1))

    def delete_last_input(self):
        if len(self._input_vectors) > 0:
            self._input_vectors.pop()

    def delete_solution_except_first(self):
        """
        Deletes every solution except for the time_step == 0.
        """
        self.__result_vectors = self.__result_vectors[0, :]
        first_input_vector = self._input_vectors[0]
        self._input_vectors = [first_input_vector]
        self.time_steps = np.array(self.time_steps[0])

        self._temperature_dataframe = None
        self._dataframe = None

        self.last_saved_timestep_index = 0

    def save_solution(self, path_with_name_and_ending: str):
        with open(path_with_name_and_ending, "wb") as f:
            pickle.dump(self.raw_data, f)
        if self.time_steps is not None:
            self.last_saved_timestep_index = len(self.time_steps) - 1

    def save_to_file_only(self, t: np.ndarray, y: np.ndarray, path_with_name_and_ending: str):
        """
        Only save the passed solution to file and delete the input vector except the last value.

        The t and y values are not saved into the solution object to prevent high RAM usage. The input vector is
        deleted for the same reason. Only the last value of the input vector is kept to use it for further solving.

        Parameters
        ----------
        t : np.ndarray
            The time step array of the solution.
        y : np.ndarray
            The result array/matrix of the solution.
        path_with_name_and_ending : str
            Where to save the solution.
        """
        if t is not None:
            data = [
                y,
                self._input_vectors[-len(t):],
                t,
                None,
                None
            ]
            with open(path_with_name_and_ending, "wb") as f:
                pickle.dump(data, f)
            # delete the input vector to make space for new one
            self._input_vectors = []

    def save_new_solution(self, path_with_name_and_ending: str):
        """
        Like save_solution, but it only saves the new solution data instead of everything.

        New data is defined as all data that is saved in a time step greater than self.last_saved_timestep.

        Parameters
        ----------
        path_with_name_and_ending : str
            Where to save the solution.

        Returns
        -------

        """
        if self.time_steps is None:
            self.save_solution(path_with_name_and_ending)
        else:
            # save everything from self.last_saved_timestep_index up to the last time step
            with open(path_with_name_and_ending, "wb") as f:
                pickle.dump(self.raw_data_last(self.last_saved_timestep_index + 1), f)

            if self.time_steps is not None:
                self.last_saved_timestep_index = len(self.time_steps) - 1

    def write_paraview_data(self,
                            folder: str,
                            increment: int = None,
                            number_of_saved_steps: int = None,
                            time_increment: int | float | Any = None,
                            use_degrees_celsius: bool = True):
        """
        Parsing the result data to vtu files that can be used to visualize the result in paraview.

        It is recommended to not generate more than several thousand resolution steps.
        If no increment is given, about 2000 result steps are created.

        Parameters
        ----------
        folder : str
            The folder to save the paraview data in.
        increment : int, optional
            If specified, only the incremental part of the result is parsed (to shorten the write time).
            If None, the increment is calculated so that a maximum of 2000 results are created.
        number_of_saved_steps : int, optional
            Works like increment but instead of walking a fixed step width it calculates the increment using the
            given number to get the number of steps.
            Or: Say, how many steps should be saved (+-1).
            Overwrites the increment parameter.
        time_increment : int | float | Any, optional
            The x'th time that should be saved in seconds.
            If given, the increment parameter is not used.
            Example usage: time_increment = 120
                The result files are created for results every 120 seconds.
        use_degrees_celsius : bool, optional
            If True, the temperatures are saved as degree Celsius. In Kelvin otherwise.

        Returns
        -------

        """
        static_points, static_cells = write_static_cells_vtu(self.nodes, folder)

        if increment is None:
            increment = self.time_steps_count // 2000
        if number_of_saved_steps is not None:
            increment = self.time_steps_count // number_of_saved_steps
        increment = max(1, int(increment))
        if time_increment is not None:
            assert isinstance(time_increment, float) or isinstance(time_increment, int)
        mask = None
        if time_increment is not None:
            mask = np.diff(np.floor((self.time_steps - self.time_steps[0]) / time_increment), prepend=-1).astype(
                bool)
        if mask is not None:
            print("Time increment is used.")
            result = self.result_vectors[mask, :]
            time_steps = self.time_steps[mask]
        else:
            print("Manual increment is used.")
            result = self.result_vectors[::increment, :]
            time_steps = self.time_steps[::increment]

        if use_degrees_celsius:
            result -= 273.15

        write_temperature_vtu(
            result,
            time_steps,
            static_points,
            static_cells,
            folder,
            step_interval=1  # reducing of the result was already done, so parse every step
        )

    @property
    def raw_data(self):
        return [
            self.result_vectors,
            self._input_vectors,
            self.time_steps,
            self._temperature_dataframe,
            self._dataframe
        ]

    def raw_data_last(self, starting_index):
        """
        Like raw_data but only returns the values starting from `starting_index`.

        Parameters
        ----------
        starting_index : int
            The index where to start getting the data from.

        Returns
        -------
        list :
            A list with all raw data starting from `starting_index`.
        """
        result_vectors = None
        if self.result_vectors is not None:
            result_vectors = self.result_vectors[starting_index:, :]
        input_vectors = []
        if self._input_vectors:
            input_vectors = self._input_vectors[starting_index:]
        time_steps = None
        if self.time_steps is not None:
            time_steps = self.time_steps[starting_index:]
        temperature_dataframe = None
        if self._temperature_dataframe is not None:
            temperature_dataframe = self._temperature_dataframe.iloc[starting_index:]
        dataframe = None
        if self._dataframe is not None:
            dataframe = self._dataframe.iloc[starting_index:]

        return [
            result_vectors,
            input_vectors,
            time_steps,
            temperature_dataframe,
            dataframe
        ]

    def delete_solutions(self, confirm=False):
        """
        Use with care! Deletes all data if it's confirm=True.
        """
        if confirm:
            self.__result_vectors = None
            self._input_vectors = []
            self.time_steps = None

            self._temperature_dataframe = None
            self._dataframe = None

            self.last_saved_timestep_index = 0
        else:
            print("You have to confirm to delete all data.")

    def load_solution(self,
                      path_with_name_and_ending: str,
                      save_combined_solution: bool = True,
                      last_time_step=None):
        """
        Loads a pickled solution. If the file is not found it searches for incremental solutions and loads them.

        This method forces the load. That the hash matches the current network is the responsibility of the user.

        The search for an incremental solution is done by using the hash as the start followed by a "_" and
        everything after the hash is used as add-on to the name, except "_result". So if the requested file is:
            fcd7d8e0f79c611c05db6e80457b8c3f0f2a696acb5e213cc0516bed468e9497_normal_static_result.pickle
        it searches for:
            fcd7d8e0f79c611c05db6e80457b8c3f0f2a696acb5e213cc0516bed468e9497_normal_static_0000100_*.pickle
        The number is the time step and after the time step everything can follow (".*").

        Parameters
        ----------
        path_with_name_and_ending : str
            The path where the solution is stored with name and ending.
        save_combined_solution : bool, optional
            If True, the solution is saved in a pickle file if it was concatenated from incremental solutions.
        last_time_step : int | float, optional
            The last time step which defines the complete solution.
            If given, it is checked if the whole solution was loaded or just a part out of it.
            Used, to continue canceled simulations.

        Returns
        -------

        """
        path_with_name_and_ending = os.path.normpath(path_with_name_and_ending)
        if os.path.exists(path_with_name_and_ending):
            with open(path_with_name_and_ending, "rb") as f:
                loaded_solution = pickle.load(f)
            raw_data = loaded_solution
            self._append_or_initialize(raw_data)
            return True
        else:
            # try to load incremental data
            folder, rc_hash, name_add_on = self._get_hash_and_folder_from_file_name(path_with_name_and_ending)
            if rc_hash is not None:
                success = self._load_all_solutions(folder, rc_hash, name_add_on)
                solution_is_complete = True
                if last_time_step is not None and success:
                    last_loaded_step = self.time_steps[-1]
                    if last_loaded_step < last_time_step:
                        print(f"Solution loaded {last_loaded_step}/{last_time_step}")
                        solution_is_complete = False
                        success = last_loaded_step
                if success and save_combined_solution and solution_is_complete:
                    self.save_solution(path_with_name_and_ending)
                return success
        return False

    def _append_or_initialize(self, raw_data):
        """
        Append new data from raw_data to existing attributes if they are not None,
        otherwise initialize them.

        Parameters
        ----------
        raw_data : tuple
            A tuple containing (result_vectors, input_vectors, time_steps,
            temperature_dataframe, dataframe).
        """
        if raw_data[0] is not None:
            if self.__result_vectors is None:
                self.__result_vectors: np.ndarray = raw_data[0]
            else:
                self.__result_vectors = np.concatenate((self.__result_vectors, raw_data[0]), axis=0)

        if raw_data[1] is not None:
            if self._input_vectors is None:
                self._input_vectors: list = raw_data[1]
            else:
                self._input_vectors.extend(raw_data[1])

        if raw_data[2] is not None:
            if self.time_steps is None:
                self.time_steps: np.ndarray = raw_data[2]
            else:
                self.time_steps = np.concatenate((self.time_steps, raw_data[2]), axis=0)

        if raw_data[3] is not None:
            if self._temperature_dataframe is None:
                self._temperature_dataframe = raw_data[3]
            else:
                self._temperature_dataframe = pd.concat([self._temperature_dataframe, raw_data[3]])

        if raw_data[4] is not None:
            if self._dataframe is None:
                self._dataframe = raw_data[4]
            else:
                self._dataframe = pd.concat([self._dataframe, raw_data[4]])

    def _load_all_solutions(self, save_dir: str, save_prefix: str, hash_add_on: str | Any = None):
        """
        Load all incrementally saved pickled solution files matching the pattern
        '{save_prefix}.*{float(batch_end):09.0f}.*.(pickle|pkl)' in ascending order of batch_end.

        The current solution is replaced if some exist!

        Parameters
        ----------
        save_dir : str
            Directory where the pickled files are stored.
        save_prefix : str
            Prefix of the saved files to identify relevant pickles.
        hash_add_on : str | Any, optional
            A string that is added to the hash with a "_" to serve as identifier.

        Returns
        -------
        list
            A list of loaded solutions sorted by batch_end.
        """
        if hash_add_on is not None:
            save_prefix += "_" + hash_add_on
        # pattern = re.compile(rf"{re.escape(save_prefix)}.*?(\d+(?:\.\d+)?)(?!.*\d).*\.(?:pickle|pkl)$")
        pattern = re.compile(
            rf"{re.escape(save_prefix)}_?(\d+(?:\.\d+)?)(?=_(?:s)?\.pickle$|(?:s)?\.pickle$|_(?:s)?\.pkl$|(?:s)?\.pkl$)")
        solutions = []

        for file_name in os.listdir(save_dir):
            match = pattern.match(file_name)
            if match:
                batch_end = float(match.group(1))
                solutions.append((batch_end, file_name))

        solutions.sort(key=lambda x: x[0])

        all_data = [[] for _ in range(5)]

        for _, file_name in solutions:
            with open(os.path.join(save_dir, file_name), "rb") as f:
                raw_data = pickle.load(f)
                for i, data in enumerate(raw_data):
                    if data is not None:
                        all_data[i].append(data)

        # Concatenate once for each data type
        if all_data[0]:
            self.__result_vectors = np.concatenate(all_data[0], axis=0)

        if all_data[1]:
            self._input_vectors = []
            for vectors in all_data[1]:
                self._input_vectors.extend(vectors)

        if all_data[2]:
            self.time_steps = np.concatenate(all_data[2], axis=0)

        if all_data[3]:
            self._temperature_dataframe = pd.concat(all_data[3], ignore_index=True)

        if all_data[4]:
            self._dataframe = pd.concat(all_data[4], ignore_index=True)
        #
        # for _, file_name in solutions:
        #     with open(os.path.join(save_dir, file_name), "rb") as f:
        #         raw_data = pickle.load(f)
        #         self._append_or_initialize(raw_data)

        if len(solutions) > 0:
            return True
        return False

    @staticmethod
    def _get_hash_and_folder_from_file_name(path: str):
        """
        Extract the hash and folder from the full path of a saved pickle file.

        The hash is defined as all characters in the filename before the first underscore.

        The name add-on is everything followed by the hash (without the underscore) but without the .pickle extension
        and without "_result". If no characters match this, None is returned.

        Parameters
        ----------
        path : str
            Full path to the saved pickle file including the file name (with or without ending)

        Returns
        -------
        tuple[str, str]
            A tuple (save_dir, save_prefix).
        """
        folder = os.path.dirname(path)
        filename = os.path.basename(path)
        # split at _
        split = filename.split("_", 1)
        rc_hash = None
        name_add_on = None
        if len(split) > 1:
            rc_hash = split[0]
            name_add_on = split[1]
        else:
            # split at .
            split = filename.split(".", 1)
            if len(split) > 1:
                if len(split[0]) == 64:
                    rc_hash = split[0]
                    name_add_on = ".".join(split[1:]) if len(split) > 1 else None
        if name_add_on is not None:
            name_add_on = name_add_on.removesuffix(".pickle")
            name_add_on = name_add_on.removesuffix(".pkl")
            name_add_on = name_add_on.removesuffix("_result")
        return folder, rc_hash, name_add_on

    @property
    def exist(self) -> bool:
        if self.result_vectors is not None:
            return True
        return False

    @property
    def result_vectors(self) -> np.ndarray | Any:
        return self.__result_vectors

    @result_vectors.setter
    def result_vectors(self, value):
        pass

    @property
    def time_steps_count(self):
        return len(self.time_steps.flatten())

    @property
    def temperature_vectors_pandas(self) -> pd.DataFrame:
        """
        Returns the solution with all node results in one column within a pd.DataFrame.

        The DataFrame is cached. To reset it, set ``self.result_vectors = None`` .

        Returns
        -------
        pd.DataFrame :
            The solution. Each column represents the solution of one node. Each row the time step.
            The index of the DataFrame are the time steps.
        """
        if self._temperature_dataframe is None:
            self._temperature_dataframe = pd.DataFrame(self.result_vectors)
            self._temperature_dataframe.index = self.time_steps
        return self._temperature_dataframe

    @property
    def dataframe(self):
        if self._dataframe is None:
            merge = np.concatenate((self.result_vectors, self.input_vectors), axis=1)
            self._dataframe = pd.DataFrame(merge, columns=[*[n.id for n in self.nodes], *[i.id for i in self.inputs]],
                                           index=self.time_steps)
        return self._dataframe

    @property
    def temperature_vectors(self) -> np.ndarray:
        """
        Like temperature_vectors_pandas, but returns a numpy array.

        This value is not cached.

        Returns
        -------
        np.ndarray :
            The solution. Each column represents the solution of one node. Each row the time step.
        """
        return self.result_vectors

    @property
    def t(self):
        return self.time_steps

    @t.setter
    def t(self, value):
        self.time_steps = value

    @property
    def y(self):
        return self.result_vectors

    @y.setter
    def y(self, value):
        assert isinstance(value, np.ndarray)
        self.__result_vectors = value

    # def set_loaded_data(self, loaded_solutions: RCSolution):
    #     """
    #     Replaces all attributes with the ones of the loaded `RCSolution`.
    #
    #     This is used when the object can hardly be replaced by a loaded one, e.g. when used in composition.
    #
    #     Parameters
    #     ----------
    #     loaded_solutions : RCSolution
    #         The loaded solution object that should "replace" self / should be used to overwrite self.
    #
    #     """
    #     self.time_steps = loaded_solutions.time_steps
    #     self.result_vectors = loaded_solutions.result_vectors
    #     self._input_vectors: np.ndarray | Any = loaded_solutions._input_vectors

    def save_last_step(self, file_path):
        """
        Saves a vector with the solution of the last time step.

        The saved data can be set as initial values using `RCNetwork.load_initial_values`

        Parameters
        ----------
        file_path : str | Any
            The file path with name and ending.
        """
        last_solution = self.temperature_vectors[-1, :]
        last_input = self.input_vectors[-1, :]
        with open(file_path, "wb") as f:
            pickle.dump((last_solution, last_input), f)


solution_object = RCSolution()


class ObjectWithPorts:

    def __init__(self):
        self.__neighbours = []

    @property
    def neighbours(self):
        return self.__neighbours

    @property
    def ports(self):
        """
        Alias for `self.neighbours`.
        """
        return self.__neighbours

    def __iter__(self):
        """
        Iterate over `self.neighbours`.

        Returns
        -------
        ObjectWithPorts :
            The neighbours.
        """
        for neighbour in self.neighbours:
            yield neighbour

    def connect(self, neighbour, direction: tuple | list | np.ndarray | Any = None, node_direction_points_to=None):
        """
        Add the given object/neighbour to the `self.neighbours` list.

        The neighbour itself will connect ``self`` to its neighbours list.
        E.g.: If node2 should be connected to node1, node2's neighbours list appends self.

        The direction is a possibility to set the direction between two connected nodes manually. It is used for
        connected `BoundaryCondition` s and `Node` s.
        The direction is set for the neighbour. The

        Parameters
        ----------
        neighbour : ObjectWithPorts
            The neighbour to connect to. It will connect ``self`` to itself.
            This is the Node the manual direction is set on!
        direction : tuple | list | np.ndarray, optional
            If not None, a direction is set manually to node_direction_points_at.
            Either none or both node_direction_points_at and direction must be passed.
        node_direction_points_to : TemperatureNode, optional
            If not None, this is the node to which the direction points at (looking from neighbour).
            Either none or both node_direction_points_at and direction must be passed.
            Must be a TemperatureNode.
        """
        self.__neighbours.append(neighbour)
        neighbour.__single_connect(self)
        if (direction is not None) ^ (node_direction_points_to is not None):
            raise ValueError("Either none or both node_direction_points_at and direction must be passed.")

        # set direction of neighbour using the node the direction points at
        if direction is not None:
            direction: tuple | np.ndarray | list
            from pyrc.core.nodes import Node
            from pyrc.core.components.node import TemperatureNode
            assert isinstance(node_direction_points_to, TemperatureNode)
            direction: np.ndarray = np.array(direction) / np.linalg.norm(np.array(direction))
            if not isinstance(neighbour, Node):
                assert isinstance(self, Node), "The direction can only set on Nodes, not TemperatureNodes/Resistors."
                # set direction at self to node_direction_points_to
                self.set_direction(node_direction_points_to, direction)
            else:
                node: TemperatureNode = node_direction_points_to
                neighbour.set_direction(node, direction)

    def double_connect(self, neighbour1, neighbour2):
        self.connect(neighbour1)
        self.connect(neighbour2)

    def __single_connect(self, neighbour):
        """
        Like `self.connect`, but it doesn't set the connection to the neighbour, too.

        Parameters
        ----------
        neighbour : ObjectWithPorts
            The neighbour to connect to.
        """
        self.__neighbours.append(neighbour)


class ConnectedFlowObject:

    def __init__(self):
        self._volume_flow = None
        # manual switch to determine if the volume flows are balanced: sum(inflows)-sum(outflows) = 0
        # This switch should be actuated from the algorithm that distributes the flows or a method that checks the
        # balance.
        self.volume_flow_is_balanced = False

    @property
    def guess_volume_flow(self):
        return self._volume_flow

    @property
    def volume_flow(self):
        return self._volume_flow

    @abstractmethod
    def check_balance(self) -> bool:
        pass

    @property
    def sources(self) -> list:
        return []

    @property
    def sinks(self) -> list:
        return []

    @property
    @abstractmethod
    def balance(self):
        pass


class Geometric:
    """
    Skeleton for a geometric object that only contains the position in 3D space.

    Defines getter and setter for X, Y and Z coordinates. If a 2D vector is given,
    the Z coordinate is set to 0.

    Parameters
    ----------
    position : np.ndarray
        Either 2D or 3D position of the object as array.
    fixed_position : bool
        If ``True``, the position cannot be changed. Overwrites both `fixed_z` and `fixed_xy` parameters.
    fixed_z : bool
        If ``True``, the z coordinate cannot be changed.
    fixed_xy : bool
        If ``True``, the x and y coordinates cannot be changed.
    """

    def __init__(self,
                 position: np.ndarray | tuple,
                 fixed_position: bool = False,
                 fixed_z: bool = False,
                 fixed_xy: bool = False):

        if fixed_position:
            fixed_z = fixed_xy = True
        self.fixed_z = fixed_z
        self.fixed_xy = fixed_xy

        self.position = np.array(position, dtype=np.float64)

    @property
    def position(self) -> np.ndarray:
        return self.__position

    @position.setter
    def position(self, value: np.ndarray):
        if self.fixed_z or self.fixed_xy:
            raise FixedPositionError()
        if not isinstance(value, np.ndarray):
            value = np.array(value, dtype=np.float64)
        assert 2 <= len(value) <= 3
        if len(value) == 2:
            value = np.array([*value, 0], dtype=np.float64)
        if np.isnan(value).any():
            raise ValueError
        self.__position = value.copy()

    @property
    def x(self):
        return self.__position[0]

    @x.setter
    def x(self, value):
        if self.fixed_xy:
            raise FixedXYError()
        assert is_numeric(value)
        self.__position = np.array([value, self.y, self.z])

    @property
    def y(self):
        return self.__position[1]

    @y.setter
    def y(self, value):
        if self.fixed_xy:
            raise FixedXYError()
        assert is_numeric(value)
        self.__position = np.array([self.x, value, self.z])

    @property
    def z(self):
        return self.__position[2]

    @z.setter
    def z(self, value):
        if self.fixed_z:
            raise FixedZError()
        assert is_numeric(value)
        self.__position = np.array([self.x, self.y, value])


class Cell(Geometric):

    def __init__(self,
                 position: np.ndarray | tuple,
                 delta: np.ndarray | tuple = None,
                 ):
        """
        Extends the `Geometric` class to a cell with length, height and depth.

        Parameters
        ----------
        position : np.ndarray
            The position of the node in 2D/3D space.
            If 2D, a zero is added for the z coordinate.
        delta : np.ndarray | tuple, optional
            Delta vector [delta_x, delta_y, delta_z].
        """
        # visualize the Cell using vpython
        self.__vbox: Optional[
            box] = None  # must be initialized before Geometric init is called because of position setter
        self.opacity = 1

        super().__init__(position=position)

        self.delta = delta

    @Geometric.position.setter
    def position(self, value):
        Geometric.position.fset(self, value)
        if self.__vbox is not None:
            self.update_vbox_geometry()

    @property
    def vbox(self):
        if self.__vbox is None:
            self.vbox = box(
                pos=vector(*self.position),
                size=vector(*self.delta),
                color=vector(0.6, 0.6, 0.6),
                opacity=self.opacity,
                shininess=0.0,
            )
        return self.__vbox

    @vbox.setter
    def vbox(self, value):
        assert isinstance(value, box)
        self.__vbox = value

    @property
    def delta(self):
        """
        Returns the delta vector.

        Returns
        -------
        np.ndarray :
            The delta vector.
        """
        return self.__delta

    @delta.setter
    def delta(self, value):
        value = np.asarray(value).ravel()
        if value.size == 1:
            self.__delta = np.append(value, [1.0, 1.0])
        elif value.size == 2:
            self.__delta = np.append(value, 1.0)
        elif value.size == 3:
            self.__delta = value
        else:
            raise ValueError(f"Expected 2 or 3 elements, got {value.size}.")

        if self.__vbox is not None:
            self.update_vbox_geometry()

    @property
    def delta_x(self):
        return self.delta[0]

    @property
    def delta_y(self):
        return self.delta[1]

    @property
    def delta_z(self):
        return self.delta[2]

    @property
    def length(self):
        return self.delta_x

    @property
    def height(self):
        return self.delta_y

    @property
    def depth(self):
        return self.delta_z

    @property
    def boundaries(self) -> list:
        """
        Returns the boundaries of the cell.

        The format looks like:
        [-x, x, -y, y, -z, z]

        Returns
        -------
        list :
            The boundaries.
        """
        negative = (self.position - self.delta / 2).tolist()
        positive = (self.position + self.delta / 2).tolist()
        return [item for pair in zip(negative, positive) for item in pair]

    def update_vbox_geometry(self) -> None:
        """
        Update position/size (geometry) of the vbox (visualization). Call only if geometry changes.
        """
        self.vbox.pos = vector(*self.position)
        self.vbox.size = vector(*self.delta)

    def update_color(self, temperature: float, t_min: float = 263.15, t_max: float = 413.15,
                     colormap="managua") -> None:
        """
        Update the color of the vbox for visualization.

        Parameters
        ----------
        temperature : float
            The temperature in Kelvin to set.
        t_min : float | int, optional
            The minimal temperature for the color code.
        t_max : float | int, optional
            The maximal temperature for the color code.
        colormap : str, optional
            The colormap to use. See pyrc.core.visualization.color.color.py or the txt files in there respectively.
        """
        assert t_max > t_min
        t_norm = (temperature - t_min) / (t_max - t_min)
        r, g, b = value_to_rgb(t_norm, colormap)
        self.vbox.color = vector(r, g, b)

    def _apply_alignment(self, alignment, reference_position, other_deltas):
        """
        Apply alignment string to calculate new position.

        Parameters
        ----------
        alignment : str
            Face alignment specification with optional pairing override.
            Format: Space-separated or consecutive axis specifications.
            Each specification: [self_dir][other_dir]axis
            where self_dir and other_dir are '+' or '-'.
            Default pairing: opposite faces ('+x' pairs with '-x' of other)
            Examples: 'x' (default opposite), 'xy' (both default opposite),
                      '+-x' (explicit opposite), '++x' (same face),
                      '-y' (self -y with other +y), '+-x -+y' (multiple axes with space)
        reference_position : np.ndarray
            Starting position to update
        other_deltas : np.ndarray
            Delta values of object being placed

        Returns
        -------
        np.ndarray
            Updated position after applying alignment

        Raises
        ------
        ValueError
            If alignment string is malformed
        """
        new_position = reference_position.copy()

        # Remove spaces and parse character by character
        alignment_no_space = alignment.replace(' ', '')

        i = 0
        while i < len(alignment_no_space):
            self_direction = 1
            other_direction = -1
            signs = []

            # Parse signs (0, 1, or 2)
            while i < len(alignment_no_space) and alignment_no_space[i] in ['-', '+']:
                signs.append(-1 if alignment_no_space[i] == '-' else 1)
                i += 1
                if len(signs) > 2:
                    raise ValueError(f"More than 2 signs found before axis at position {i}")

            # Parse axis
            if i < len(alignment_no_space) and alignment_no_space[i] in ['x', 'y', 'z']:
                axis = alignment_no_space[i]
                i += 1
            else:
                if signs:
                    raise ValueError(f"Found direction signs without following axis at position {i}")
                break

            # Apply signs
            if len(signs) == 1:
                self_direction = signs[0]
                other_direction = -signs[0]  # Opposite of self
            elif len(signs) == 2:
                self_direction = signs[0]
                other_direction = signs[1]
            # else: len(signs) == 0, use defaults (1, -1)

            axis_index = {'x': 0, 'y': 1, 'z': 2}[axis]
            new_position[axis_index] = (self.position[axis_index] +
                                        self_direction * self.delta[axis_index] / 2 -
                                        other_direction * other_deltas[axis_index] / 2)

        return new_position

    def place_adjacent(self, other_cell, alignment):
        """
        Place other_cell adjacent to self aligned at specified face(s).

        Parameters
        ----------
        other_cell : Cell
            Cell to be placed adjacent to self
        alignment : str
            Face alignment specification with optional pairing override.
            Format: Space-separated or consecutive axis specifications.
            Each specification: [self_dir][other_dir]axis
            where self_dir and other_dir are '+' or '-'.
            Default pairing: opposite faces ('+x' pairs with '-x' of other)
            Examples: 'x' (default opposite), 'xy' (both default opposite),
                      '+-x' (explicit opposite), '++x' (same face),
                      '-y' (self -y with other +y), '+-x -+y' (multiple axes with space)
        """
        other_cell.position = self._apply_alignment(
            alignment,
            other_cell.position,
            other_cell.delta
        )

        return other_cell

    def create_adjacent(self, alignment, **kwargs):
        """
        Create and place new cell of same type adjacent to self.

        Parameters
        ----------
        alignment : str
            Face alignment specification with optional pairing override.
            Format: Space-separated or consecutive axis specifications.
            Each specification: [self_dir][other_dir]axis
            where self_dir and other_dir are '+' or '-'.
            Default pairing: opposite faces ('+x' pairs with '-x' of other)
            Examples:\n
            ``x`` (default opposite), ``xy`` (both default opposite),\n
            ``+-x`` (explicit opposite), ``++x`` (same face),\n
            ``-y`` (self -y with other +y), ``+-x -+y`` (multiple axes with space)
        **kwargs
            Arguments passed to constructor (``delta`` etc.)

        Returns
        -------
        Cell or subclass :
            New `Cell` of same type as ``self`` placed adjacent to ``self``
        """
        if "position" not in kwargs:
            kwargs["position"] = self.position.copy()
        new_cell = type(self)(**kwargs)
        return self.place_adjacent(new_cell, alignment)

    @classmethod
    def create_grid(cls,
                    grid_size,
                    delta: np.ndarray | tuple = None,
                    center_position=None,
                    **kwargs) -> np.ndarray:
        """
        Create a 3D grid of cells.

        Parameters
        ----------
        grid_size : tuple of int
            Number of cells (nx, ny, nz).
        delta : np.ndarray | tuple
            Total dimensions in one vector.
            If single delta-values are given, too, the delta vector is used.
        delta : float
            Total length in x,y,z direction.
        center_position : np.ndarray, optional
            Center position of the grid. Defaults to origin.
        **kwargs
            Additional arguments passed to constructor.

        Returns
        -------
        np.ndarray
            3D array of shape (nx, ny, nz) containing Cell instances.
        """

        nx, ny, nz = grid_size
        cell_deltas = delta / np.array([nx, ny, nz])
        center = np.zeros(3) if center_position is None else center_position.copy()

        cells = np.empty((nx, ny, nz), dtype=object)
        for ix in range(nx):
            for iy in range(ny):
                for iz in range(nz):
                    offset = (np.array([ix, iy, iz]) - (np.array([nx, ny, nz]) - 1) / 2) * cell_deltas
                    cells[ix, iy, iz] = cls(
                        position=center + offset,
                        delta=cell_deltas,
                        **kwargs
                    )
        return cells

    def create_grid_aligned(self,
                            alignment,
                            grid_size,
                            total_delta,
                            position=None,
                            **kwargs) -> np.ndarray[Cell]:
        """
        Create a 3D grid of cells aligned to self.

        Parameters
        ----------
        alignment : str
            Face alignment specification. See _apply_alignment for format.
        grid_size : tuple of int
            Number of cells (nx, ny, nz).
        total_delta : float
            Total length in x,y,z direction.
        position : np.ndarray, optional
            Base position, updated by alignment. Defaults to origin.
        **kwargs
            Additional arguments passed to constructor.

        Returns
        -------
        np.ndarray
            3D array of shape (nx, ny, nz) containing Cell instances.
        """
        base = np.zeros(3) if position is None else position.copy()
        total_deltas = np.array(total_delta)
        center = self._apply_alignment(alignment, base, total_deltas)
        return type(self).create_grid(
            grid_size, total_delta,
            center_position=center, **kwargs
        )


class Material:

    def __init__(self,
                 name,
                 density: float | int | np.number = np.nan,
                 heat_capacity: float | int | np.number = np.nan,
                 thermal_conductivity: float | int | np.number = np.nan,
                 ):
        """
        Container to hold all material properties.

        Parameters
        ----------
        name : str
            The name/identifier of the material.
        density : float | int | np.number
            The density of the material in kg/m^3.
        heat_capacity : float | int | np.number
            The heat capacity of the material in J/kg/K.
        thermal_conductivity : float | int | np.number
            The thermal conductivity of the material in W/m/K.
        """
        self.__name = name
        self.__density = density
        self.__heat_capacity = heat_capacity
        self.__thermal_conductivity = thermal_conductivity

    def __new__(cls, *args, **kwargs):
        """
        This blocks the creation of instances from this class because it should only be used the children of self.

        Parameters
        ----------
        args
        kwargs
        """
        if cls is Material:
            children = [sub_cls.__name__ for sub_cls in Material.__subclasses__()]
            raise TypeError(f"Cannot instantiate {cls.__name__} directly. Use the children: {', '.join(children)}")
        return super().__new__(cls)

    @property
    def name(self):
        return self.__name

    @property
    def density(self):
        return self.__density

    @property
    def heat_capacity(self):
        return self.__heat_capacity

    @property
    def thermal_conductivity(self):
        return self.__thermal_conductivity


class Fluid(Material):

    def __init__(
        self,
        *args,
        kin_viscosity: float | int | np.number = np.nan,
        prandtl_number: float | int | np.number = np.nan,
        grashof_number: float | int | np.number = np.nan,
        **kwargs,
    ):
        """

        Parameters
        ----------
        args
        kin_viscosity : float | int | np.number
            The kinematic viscosity of the material in m^2/s.
        prandtl_number : float | int | np.number
            The Prandtl number of the material without unit.
        grashof_number : float | int | np.number
            The Grashof number of the material without unit.
        kwargs
        """
        super().__init__(*args, **kwargs)
        self.__kin_viscosity = kin_viscosity
        self.__prandtl_number = prandtl_number
        self.__grashof_number = grashof_number

    @property
    def kin_viscosity(self):
        return self.__kin_viscosity

    @property
    def prandtl_number(self):
        if self.__prandtl_number is None or not is_set(self.__prandtl_number):
            self.__prandtl_number = self.kin_viscosity * self.density * self.heat_capacity / self.thermal_conductivity
        return self.__prandtl_number

    @property
    def Pr(self):
        return self.prandtl_number

    @property
    def grashof_number(self):
        return self.__grashof_number

    @property
    def Gr(self):
        return self.__grashof_number

    @property
    def rayleigh_number(self):
        return self.grashof_number * self.prandtl_number


class Solid(Material):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)


class CompositeMaterialSolid(Solid):
    """
    Combine multiple materials using ratios.
    """

    def __init__(self, name, materials, ratios, **kwargs):
        total_ratio = sum(ratios)
        weights = [ratio / total_ratio for ratio in ratios]

        density = sum(mat.density * weight for mat, weight in zip(materials, weights))
        heat_capacity = sum(mat.heat_capacity * weight for mat, weight in zip(materials, weights))
        thermal_conductivity = sum(mat.thermal_conductivity * weight for mat, weight in zip(materials, weights))

        solid_kwargs = {
            "name": name,
            "density": density,
            "heat_capacity": heat_capacity,
            "thermal_conductivity": thermal_conductivity
        }
        solid_kwargs.update(kwargs)
        super().__init__(
            **solid_kwargs
        )


class CompositeMaterialFluid(Fluid):
    """
    Combine multiple fluid materials using ratios.
    """

    def __init__(self, name, materials, ratios, **kwargs):
        total_ratio = sum(ratios)
        weights = [ratio / total_ratio for ratio in ratios]

        density = sum(mat.density * weight for mat, weight in zip(materials, weights))
        heat_capacity = sum(mat.heat_capacity * weight for mat, weight in zip(materials, weights))
        thermal_conductivity = sum(mat.thermal_conductivity * weight for mat, weight in zip(materials, weights))
        kin_viscosity = sum(mat.kin_viscosity * weight for mat, weight in zip(materials, weights))

        fluid_kwargs = {
            "name": name,
            "density": density,
            "heat_capacity": heat_capacity,
            "thermal_conductivity": thermal_conductivity,
            "kin_viscosity": kin_viscosity
        }
        fluid_kwargs.update(kwargs)
        super().__init__(
            **fluid_kwargs
        )


def calculate_balance_for_resistors(node, resistors: list[MassTransport]):
    balance = 0
    for resistor in resistors:
        if resistor.sink == node:
            # resistor is source for node
            balance += resistor.volume_flow
        else:
            # resistor is sink for node
            balance -= resistor.volume_flow
    return balance


class EquationItemInput(Input, EquationItem, ABC): pass
