#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

from __future__ import annotations

from abc import abstractmethod

from pyrc.core.settings import Settings, initial_settings


class Input:
    """
    Each Input can be called as function to get its value during solving depending on the time step/ temperature
    or last input value.

    Attributes
    ----------
    self.static : bool, optional
        If True, a static value is assumed and no time-dependent calculations were done.
        NOTE: You may take a look on the ConstantInput class for such cases to remain performant.
        This also serves as a switch to first just use static values during network solving until a stationary
        state is reached and then activate the dynamic calculation.


    """

    def __init__(self, settings: Settings = initial_settings):
        """
        Super class for all inputs.

        Mainly used for calculation boundary conditions both time-independent and time-dependent.

        The simplest way of using this class would be to just return one static value, no matter which solving time,
        temperature or input_vector is given. Because the __call__method is run every solver iteration it should be
        as performant as possible. Therefor, for constant Inputs it's recommended to use the ConstantInput class.

        """
        self.settings = settings

    @property
    def static(self):
        return self.settings.calculate_static

    @property
    @abstractmethod
    def index(self) -> int:
        """
        Returns the index of self in the input vector/matrix.

        Returns
        -------
        int :
            The index of self in the input vector/matrix.
        """
        pass

    @property
    @abstractmethod
    def initial_value(self):
        pass

    @initial_value.setter
    @abstractmethod
    def initial_value(self, value):
        pass

    @abstractmethod
    def calculate_static(self, tau, temp_vector, _input_vector, *args, **kwargs):
        """
        Calculate static values.

        Each function in the dict must have the possibility to get along with *args and **kwargs.

        Parameters
        ----------
        tau
        temp_vector
        _input_vector
        kwargs

        Returns
        -------

        """
        pass

    def calculate_dynamic(self, tau, temp_vector, _input_vector, *args, **kwargs):
        """
        Should be overwritten for all time-dependent inputs.

        Is used, when self.static = False to calculate time-dependent inputs.

        Each function in the dict must have the possibility to get along with *args and **kwargs.

        Parameters
        ----------
        tau : float
            The current time of the solving process.
        temp_vector : np.ndarray
            The temperature vector of the last solution during iteration.
            In the first iteration it is the initial one.
        _input_vector :
            The input vector used for the last solution during iteration.
            In the first iteration it is the initial one.
        kwargs : dict, optional
            Further values that can be used for just some calculations.

        Returns
        -------
        float | int | np.number :
            A new input value for the input vector
        """
        return self.calculate_static(tau, temp_vector, _input_vector)

    def get_kwargs_functions(self) -> dict:
        """
        Used to calculate keyword arguments for calculate_static/dynamic that only need to be calculated once for all objects.

        The main reason for this method is speed up during calculation/iteration/solving, because some/most of the
        boundary conditions only need to be calculated once per time step. So these BCs should be calculated in here
        and passed to each Input object so that they can use the value for their calculation.

        Each function in the dict must have the possibility to get along with *args and **kwargs.

        Returns
        -------
        dict :
            The names of the values that must be passed to calculate_static/dynamic and the function to calculate
            this values.
            If for example the exterior temperature is needed for calculate_dynamic, the dict looks like this:
            {"exterior_temperature": lambda tau: my_fancy_algorithm_to_calculate/get_the_exterior_temperature(tau)}
            To use it, this dict must be passed to calculate_dynamic like this:
            my_obj.calculate_dynamic(tau, temp_vector, _input_vector, **the_get_kwargs_dict)
        """
        return {}

    def __call__(self, tau, temp_vector, _input_vector, *args, **kwargs):
        if self.static:
            return self.calculate_static(tau, temp_vector, _input_vector, *args, **kwargs)
        return self.calculate_dynamic(tau, temp_vector, _input_vector, *args, **kwargs)
