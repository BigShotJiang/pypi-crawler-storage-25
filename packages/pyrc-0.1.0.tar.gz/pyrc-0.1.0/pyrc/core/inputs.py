#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

from __future__ import annotations

import sys
from datetime import datetime

import numpy as np
from sympy import symbols
from typing import TYPE_CHECKING, Callable
from scipy.constants import Stefan_Boltzmann

from pyrc.core.components.node import TemperatureNode
from pyrc.core.settings import initial_settings, Settings
from pyrc.core.components.templates import (
    Geometric,
    ConnectedFlowObject,
    calculate_balance_for_resistors,
    EquationItem,
    RCObjects,
    initial_rc_objects,
    RCSolution,
    solution_object,
    Cell,
)
from pyrc.core.components.input import Input

if TYPE_CHECKING:
    from pyrc.core.nodes import Node, MassFlowNode
    from pyrc.core.components.resistor import Resistor

_bc_missing_counterparts: list[str] = []

# TODO: create a new class implementing the settings (and same for rcobjects) as class variable which can be set
#  initially for all subclasses to eliminate the need of passing the instances to each new class instances.


class BoundaryCondition(TemperatureNode, Input):
    def __init__(
        self,
        temperature,
        rc_objects: RCObjects = initial_rc_objects,
        rc_solution: RCSolution = solution_object,
        is_mass_flow_start: bool = False,
        heat_transfer_coefficient: float = np.nan,
        is_fluid: bool = False,
        settings: Settings = initial_settings,
        **kwargs,
    ):
        """
        Boundary condition of the RC network. Only sets a temperature without having a capacity.

        Parameters
        ----------
        temperature : float | int | np.number
            The temperature of the node.
            It is recommended to use the SI unit Kelvin instead of degrees Celsius.
        position : np.ndarray
            The position of the node in 2D/3D space.
            If 2D, a zero is added for the z coordinate.
        is_mass_flow_start : bool
            If True, the `BoundaryCondition` is a start of a mass flow.
                If so, it must be connected to a `MassTransport` resistor.
        heat_transfer_coefficient : float
            The heat transfer coefficient used to calculate free convection to the surrounding solid nodes.
        is_fluid : bool, optional
            If True, the BC is considered as fluid, otherwise as solid Material.
        settings : Settings, optional
            A `Settings` object with general settings, including `SolveSettings`
        kwargs : dict
            Optional arguments passed to `TemperatureNode`\.
        """
        TemperatureNode.__init__(
            self, temperature=temperature, rc_objects=rc_objects, rc_solution=rc_solution, **kwargs
        )
        Input.__init__(self, settings=settings)
        self._is_fluid = is_fluid
        # TODO: The following attributes should be moved to the correct subclasses
        self.is_mass_flow_start: bool = is_mass_flow_start
        self.htc: float | np.float64 = heat_transfer_coefficient  # in W/m/m/K

    def __init_subclass__(cls, **kwargs):
        """
        Warns if no subclass of this class was found in this module (py-file) that inherits from `Cell`\.

        Every BoundaryCondition class should have a counterpart that also is a `Cell` and one the is a `Geometric`\.
        This way, the boundary condition can be used in algorithms like Capacitors that also are cells (in meshes).
        The classes should be named like the non-Cell/Geometric-classes extended with "Cell"/"Geometric".

        This class is only useful during development, when new `BoundaryConditions` are added.

        Parameters
        ----------
        kwargs

        Returns
        -------

        """
        super().__init_subclass__(**kwargs)
        if cls.__name__.endswith("Geometric") or cls.__name__.endswith("Cell"):
            # The method is run in the Cell/Geometric subclass, so no check is needed :D
            return
        for geometric_version in ["Cell", "Geometric"]:
            _bc_missing_counterparts.append(cls.__name__ + geometric_version)

    @property
    def is_solid(self):
        return not self._is_fluid

    @property
    def is_fluid(self):
        return self._is_fluid

    def __str__(self):
        return self.__repr__()

    def __repr__(self):
        return f"{self.__class__.__name__}: ϑ={self.temperature}"

    @property
    def heat_transfer_coefficient(self):
        return self.htc

    @property
    def index(self) -> int:
        """
        The index of `self` within the input vector (row in input matrix).

        The value is cached to improve performance.

        Returns
        -------
        int
        """
        if not self._index:
            self._index = self.rc_objects.inputs.index(self)
        return self._index

    @property
    def initial_value(self):
        return self.initial_temperature

    @initial_value.setter
    def initial_value(self, value):
        self.initial_temperature = value

    @property
    def temperature(self) -> float | int | np.number:
        """
        The temperature of `self`\.

        If no solution is saved yet, the initial temperature is returned.

        Returns
        -------
        float | int | np.number
        """
        if not self.solutions.input_exists:
            return self.initial_temperature
        return self.solutions.last_value_input(self.index)

    @property
    def temperature_vector(self):
        """
        The vector with all temperature values of `self` of all (currently existing) time steps.

        If no solution is saved (yet), the initial temperature is returned as vector with `time_step` length.

        Returns
        -------
        np.ndarray | np.number
        """
        if not self.solutions.exist:
            result = np.array([self.temperature] * self.solutions.time_steps_count)
            return result
        return self.solutions.input_vectors[:, self.index]

    def calculate_static(self, tau, temp_vector, _input_vector, *args, **kwargs):
        """

        Parameters
        ----------
        tau
        temp_vector
        _input_vector
        args
        kwargs

        Returns
        -------

        """
        return self.temperature


class BoundaryConditionGeometric(BoundaryCondition, Geometric):
    def __init__(self, *args, position, **kwargs):
        Geometric.__init__(self, position=position)
        BoundaryCondition.__init__(self, *args, **kwargs)


class BoundaryConditionCell(BoundaryCondition, Cell):
    def __init__(self, *args, position, delta: np.ndarray | tuple = None, **kwargs):
        Cell.__init__(self, position=position, delta=delta)
        BoundaryCondition.__init__(self, *args, **kwargs)


class FluidBoundaryCondition(BoundaryCondition):
    def __init__(
        self,
        *args,
        rc_objects: RCObjects = initial_rc_objects,
        rc_solution: RCSolution = solution_object,
        **kwargs: Settings | float | int | np.ndarray,
    ):
        super().__init__(*args, rc_objects=rc_objects, rc_solution=rc_solution, is_fluid=True, **kwargs)


class FluidBoundaryConditionGeometric(FluidBoundaryCondition, Geometric):
    def __init__(self, *args, position, **kwargs):
        Geometric.__init__(self, position=position)
        FluidBoundaryCondition.__init__(self, *args, **kwargs)


class FluidBoundaryConditionCell(FluidBoundaryCondition, Cell):
    def __init__(self, *args, position, delta: np.ndarray | tuple = None, **kwargs):
        Cell.__init__(self, position=position, delta=delta)
        FluidBoundaryCondition.__init__(self, *args, **kwargs)


class InteriorBoundaryCondition(FluidBoundaryCondition):
    pass


class InteriorBoundaryConditionGeometric(InteriorBoundaryCondition, Geometric):
    def __init__(self, *args, position, **kwargs):
        Geometric.__init__(self, position=position)
        InteriorBoundaryCondition.__init__(self, *args, **kwargs)


class InteriorBoundaryConditionCell(InteriorBoundaryCondition, Cell):
    def __init__(self, *args, position, delta: np.ndarray | tuple = None, **kwargs):
        Cell.__init__(self, position=position, delta=delta)
        InteriorBoundaryCondition.__init__(self, *args, **kwargs)


class ExteriorTemperatureInputMixin:
    def __init__(
        self,
        temperature_delta=None,
        middle_temperature=None,
        settings: Settings = initial_settings,
    ):
        """
        Class to calculate the exterior temperature.

        The temperature can be returned:
        1. static
        2. dynamic: sinus curve using ``temperature_delta`` and ``middle_temperature``
        3. dynamic: weather data. The information is in the ``settings`` object.

        Parameters
        ----------
        temperature_delta : float | int, optional
            The amplitude of the sinus curve.
            Not used if ``self.settings.use_weather_data is True``
        middle_temperature : float | int, optional
            The middle temperature of the sinus curve.
            Not used if ``self.settings.use_weather_data is True``
        settings : Settings, optional
            A settings object with all important settings.
            If not given the initial Settings object is used.
        """
        self.settings = settings
        if not self.settings.use_weather_data:
            assert temperature_delta is not None and middle_temperature is not None
        self.temperature_delta = temperature_delta
        self.middle_temperature = middle_temperature

    def get_kwargs_functions(self) -> dict:
        """
        See Input.get_kwargs()

        Returns
        -------
        dict :
            The names of the values that must be passed to calculate_static/dynamic and the function to calculate
            this values.
            If for example the exterior temperature is needed for calculate_dynamic, the dict looks like this:
            {"exterior_temperature": lambda tau: my_fancy_algorithm_to_calculate/get_the_exterior_temperature(tau)}
            To use it, this dict must be passed to calculate_dynamic like this:
            my_obj.calculate_dynamic(tau, temp_vector, _input_vector, **the_get_kwargs_dict)
        """
        if self.settings.calculate_static:
            return {"exterior_temperature": self.calculate_static_fun()}
        return {"exterior_temperature": self.calculate_dynamic_fun()}

    def calculate_static_fun(self) -> Callable:
        dynamic_fun = self.calculate_dynamic_fun()
        value = dynamic_fun(0)
        return lambda *args, **_kwargs: value

    def calculate_dynamic_fun(self) -> Callable:
        if not self.settings.use_weather_data:
            return lambda tau, *args, **kwargs: (
                (self.temperature_delta * -np.cos(np.pi / 43200 * (tau + self.settings.start_shift - 14400))) / 2
                + self.middle_temperature
            )
        # use weather data
        return self.settings.weather_data.get_interpolator("exterior_temperature")

    def calculate_dynamic(self, *args, exterior_temperature=None, **kwargs):
        return exterior_temperature


class ExteriorBoundaryCondition(FluidBoundaryCondition, ExteriorTemperatureInputMixin):
    def __init__(
        self,
        *args,
        temperature_delta=None,
        middle_temperature=None,
        rc_objects: RCObjects = initial_rc_objects,
        rc_solution: RCSolution = solution_object,
        settings: Settings = initial_settings,
        **kwargs: bool | float | int,
    ):
        FluidBoundaryCondition.__init__(
            self, *args, rc_objects=rc_objects, rc_solution=rc_solution, settings=settings, **kwargs
        )
        ExteriorTemperatureInputMixin.__init__(self, temperature_delta, middle_temperature, settings=settings)

    def get_kwargs_functions(self) -> dict:
        return ExteriorTemperatureInputMixin.get_kwargs_functions(self)

    def calculate_static(self, *args, **kwargs):
        return self.calculate_dynamic(*args, **kwargs)

    def calculate_dynamic(self, tau, temp_vector, _input_vector, *args, **kwargs):
        # Logic is in ExteriorTemperatureInputMixin.calculate_dynamic_fun.
        # In **kwargs there must be a keyword "exterior_temperature" to work correctly
        return ExteriorTemperatureInputMixin.calculate_dynamic(self, **kwargs)


class ExteriorBoundaryConditionGeometric(ExteriorBoundaryCondition, Geometric):
    def __init__(self, *args, position, **kwargs):
        Geometric.__init__(self, position=position)
        ExteriorBoundaryCondition.__init__(self, *args, **kwargs)


class ExteriorBoundaryConditionCell(ExteriorBoundaryCondition, Cell):
    def __init__(self, *args, position, delta: np.ndarray | tuple = None, **kwargs):
        Cell.__init__(self, position=position, delta=delta)
        ExteriorBoundaryCondition.__init__(self, *args, **kwargs)


class SolidBoundaryCondition(BoundaryCondition):
    def __init__(
        self, *args, rc_objects: RCObjects = initial_rc_objects, rc_solution: RCSolution = solution_object, **kwargs
    ):
        super().__init__(*args, rc_objects=rc_objects, rc_solution=rc_solution, is_fluid=False, **kwargs)


class SolidBoundaryConditionGeometric(SolidBoundaryCondition, Geometric):
    def __init__(self, *args, position, **kwargs):
        Geometric.__init__(self, position=position)
        SolidBoundaryCondition.__init__(self, *args, **kwargs)


class SolidBoundaryConditionCell(SolidBoundaryCondition, Cell):
    def __init__(self, *args, position, delta: np.ndarray | tuple = None, **kwargs):
        Cell.__init__(self, position=position, delta=delta)
        SolidBoundaryCondition.__init__(self, *args, **kwargs)


class FlowBoundaryCondition(FluidBoundaryCondition, ConnectedFlowObject):
    def __init__(
        self,
        *args,
        volume_flow=None,
        rc_objects: RCObjects = initial_rc_objects,
        rc_solution: RCSolution = solution_object,
        **kwargs,
    ):
        FluidBoundaryCondition.__init__(self, *args, rc_objects=rc_objects, rc_solution=rc_solution, **kwargs)
        ConnectedFlowObject.__init__(self)

        self.volume_flow = volume_flow

        if self.is_mass_flow_start:
            self.volume_flow_is_balanced = True

    @property
    def balance(self):
        from pyrc.core.resistors import MassTransport

        return calculate_balance_for_resistors(self, [res for res in self.neighbours if isinstance(res, MassTransport)])

    @property
    def volume_flow(self):
        return super().volume_flow

    @volume_flow.setter
    def volume_flow(self, value):
        self._volume_flow = value

    @property
    def sinks(self) -> list[MassFlowNode]:
        """
        A list with all `MassFlowNode`\s that are sinks of mass flow for `self`\.

        Returns
        -------
        list[MassFlowNode]
        """
        from pyrc.core.resistors import MassTransport

        result = []
        if self.is_mass_flow_start:
            for neighbour in self.neighbours:
                if isinstance(neighbour, MassTransport):
                    result.append(neighbour.get_connected_node(self))
        return result

    @property
    def sources(self) -> list[MassFlowNode]:
        """
        A list with all `MassFlowNode`\s that are sources of mass flow for `self`\.

        Returns
        -------
        list[MassFlowNode]
        """
        from pyrc.core.resistors import MassTransport

        result = []
        if not self.is_mass_flow_start:
            for neighbour in self.neighbours:
                if isinstance(neighbour, MassTransport):
                    result.append(neighbour.get_connected_node(self))
        return result

    def check_balance(self) -> bool:
        """
        If the sum of all sinks and sources of `self` is 0 this method returns True, False otherwise.

        Returns
        -------
        bool
        """
        if self.volume_flow_is_balanced:
            return True
        # check if start or end
        if self.is_mass_flow_start:
            self.volume_flow_is_balanced = True
            return True
        # self is end. So check all connected ConnectedFlowObjects for check_balance
        flow_objects = []
        resistor: Resistor
        for node in [resistor.get_connected_node(self) for resistor in self.neighbours]:
            if isinstance(node, ConnectedFlowObject):
                if node in flow_objects:
                    continue
                flow_objects.append(node)
        for flow_object in flow_objects:
            if flow_object.check_balance():
                continue
            else:
                return False
        return True

    def connect(self, *args, **kwargs):
        from pyrc.core.resistors import MassTransport

        super().connect(*args, **kwargs)
        # Prevent the connection to every other Resistor than MassTransport.
        assert isinstance(self.neighbours[-1], MassTransport)


class FlowBoundaryConditionGeometric(FlowBoundaryCondition, Geometric):
    def __init__(self, *args, position, **kwargs):
        Geometric.__init__(self, position=position)
        FlowBoundaryCondition.__init__(self, *args, **kwargs)


class FlowBoundaryConditionCell(FlowBoundaryCondition, Cell):
    def __init__(self, *args, position, delta: np.ndarray | tuple = None, **kwargs):
        Cell.__init__(self, position=position, delta=delta)
        FlowBoundaryCondition.__init__(self, *args, **kwargs)


class ExteriorInletFlow(FlowBoundaryCondition, ExteriorTemperatureInputMixin):
    """
    A boundary condition with constant mass flow and the temperature of `ExteriorTemperatureInput`\.

    This is the start of a mass flow.
    """

    def __init__(
        self,
        *args,
        volume_flow=None,
        temperature_delta=None,
        middle_temperature=None,
        rc_objects: RCObjects = initial_rc_objects,
        rc_solution: RCSolution = solution_object,
        settings: Settings = initial_settings,
        **kwargs: np.ndarray | bool | float | int,
    ):
        FlowBoundaryCondition.__init__(
            self,
            *args,
            volume_flow=volume_flow,
            rc_objects=rc_objects,
            rc_solution=rc_solution,
            settings=settings,
            **kwargs,
        )
        ExteriorTemperatureInputMixin.__init__(self, temperature_delta, middle_temperature, settings=settings)
        self.is_mass_flow_start = True

    def get_kwargs_functions(self) -> dict:
        return ExteriorTemperatureInputMixin.get_kwargs_functions(self)

    def calculate_static(self, *args, **kwargs):
        return self.calculate_dynamic(*args, **kwargs)

    def calculate_dynamic(self, tau, temp_vector, _input_vector, *args, **kwargs):
        # Logic is in ExteriorTemperatureInputMixin.calculate_dynamic_fun.
        # In **kwargs there must be a keyword "exterior_temperature" to work correctly
        return ExteriorTemperatureInputMixin.calculate_dynamic(self, **kwargs)


class ExteriorInletFlowGeometric(ExteriorInletFlow, Geometric):
    def __init__(self, *args, position, **kwargs):
        Geometric.__init__(self, position=position)
        ExteriorInletFlow.__init__(self, *args, **kwargs)


class ExteriorInletFlowCell(ExteriorInletFlow, Cell):
    def __init__(self, *args, position, delta: np.ndarray | tuple = None, **kwargs):
        Cell.__init__(self, position=position, delta=delta)
        ExteriorInletFlow.__init__(self, *args, **kwargs)


class ExteriorOutletFlow(FlowBoundaryCondition, ExteriorTemperatureInputMixin):
    """
    A boundary condition serving as the end of a mass flow. The `volume_flow` value has no effect.

    The temperature is set as `ExteriorTemperatureInput` to easily calculate the heat flux between the connected
    `MassFlowNode` and the exterior Temperature. You could redefine this if you want to calculate another
    difference. It has no effect for solving the RC network because only `MassTransport` Resistors are allowed as
    neighbours and their are always just passing energy INTO this ExteriorOutletFlow boundary condition and never out
    of it.

    This is the end of a mass flow.
    """

    def __init__(
        self,
        *args,
        temperature_delta=None,
        middle_temperature=None,
        rc_objects: RCObjects = initial_rc_objects,
        rc_solution: RCSolution = solution_object,
        settings: Settings = initial_settings,
        **kwargs: np.ndarray | bool | float | int,
    ):
        FlowBoundaryCondition.__init__(
            self, *args, rc_objects=rc_objects, rc_solution=rc_solution, settings=settings, **kwargs
        )
        ExteriorTemperatureInputMixin.__init__(self, temperature_delta, middle_temperature, settings=settings)
        self.is_mass_flow_start = False

    def get_kwargs_functions(self) -> dict:
        return ExteriorTemperatureInputMixin.get_kwargs_functions(self)

    def calculate_static(self, *args, **kwargs):
        return self.calculate_dynamic(*args, **kwargs)

    def calculate_dynamic(self, tau, temp_vector, _input_vector, *args, **kwargs):
        # Logic is in ExteriorTemperatureInputMixin.calculate_dynamic_fun.
        # In **kwargs there must be a keyword "exterior_temperature" to work correctly
        return ExteriorTemperatureInputMixin.calculate_dynamic(self, **kwargs)


class ExteriorOutletFlowGeometric(ExteriorOutletFlow, Geometric):
    def __init__(self, *args, position, **kwargs):
        Geometric.__init__(self, position=position)
        ExteriorOutletFlow.__init__(self, *args, **kwargs)


class ExteriorOutletFlowCell(ExteriorOutletFlow, Cell):
    def __init__(self, *args, position, delta: np.ndarray | tuple = None, **kwargs):
        Cell.__init__(self, position=position, delta=delta)
        ExteriorOutletFlow.__init__(self, *args, **kwargs)


class InternalHeatSource(EquationItem, Input):
    def __init__(
        self,
        node: Node,
        specific_power_in_w_per_cubic_meter=None,
        specific_power_in_w_per_meter_squared=None,
        area_direction: np.ndarray = None,
        settings: Settings = initial_settings,
    ):
        EquationItem.__init__(self)
        Input.__init__(self, settings=settings)
        self.node: Node = node
        self.volume_specific_power = specific_power_in_w_per_cubic_meter  # in W/(m**3)
        self.__area_specific_power = specific_power_in_w_per_meter_squared  # in W/(m**3)
        self.symbol = symbols(f"Q_dot_{self.node.id}")
        self.area_direction: np.ndarray = area_direction  # should be like (1,0,0) in any order and sign

        # must be placed after initialization!
        if specific_power_in_w_per_cubic_meter is not None and specific_power_in_w_per_meter_squared is not None:
            raise ValueError("Do not set both power variables.")
        elif specific_power_in_w_per_cubic_meter is None and specific_power_in_w_per_meter_squared is not None:
            if area_direction is None:
                raise ValueError("If specific_power_in_w_per_meter_squared is set, the direction must be set, too.")

        # The calculation of the volume_specific_power is done later because during initialization the volume isn't
        # known (because it depends on the connected Nodes that are still created during initialization).

        # check, if self.volume_specific_power is None and replace it with 0 if so
        if self.volume_specific_power is None and self.__area_specific_power is None:
            self.volume_specific_power = np.float64(0)
        self._area = None

    @property
    def initial_value(self):
        return self.power

    @initial_value.setter
    def initial_value(self, value):
        self.volume_specific_power = value / self.node.volume

    @property
    def area(self):
        if self._area is None:
            self._area = self.node.area(self.area_direction)
        return self._area

    @property
    def index(self) -> int:
        if not self._index:
            self._index = self.node.rc_objects.inputs.index(self)
        return self._index

    @property
    def power(self):
        if self.volume_specific_power is None:
            self.set_area_specific_power(self.__area_specific_power)
        return self.volume_specific_power * self.node.volume

    @property
    def area_specific_power(self):
        if self.area_direction is None:
            return None
        return self.power / self.area

    def set_area_specific_power(self, area_specific_power_in_w_per_square_meter, direction: np.ndarray = None):
        """
        Sets the volume specific power by calculating it with the area specific power and a direction/normal of the
        effective surface.

        Parameters
        ----------
        area_specific_power_in_w_per_square_meter : float | int
            The area specific power in W/m**2.
        direction : np.ndarray, optional
            The normal of the surface where the power is applied to. Should be (1,0,0) with any order and sign.
            Is used to get the area of the node using ``self.node.area(direction)``\.

        """
        if direction is None:
            assert self.area_direction is not None
        if self.area_direction is None:
            assert isinstance(direction, np.ndarray) and len(direction) == 3, "Direction to face must be passed!"
            self.area_direction = direction
        else:
            if direction is not None:
                assert isinstance(direction, np.ndarray) and len(direction) == 3
                print("Warning: direction is overwritten.")
                self.area_direction = direction
        self.volume_specific_power = area_specific_power_in_w_per_square_meter * self.area / self.node.volume

    def calculate_static(self, tau, temp_vector, _input_vector, **kwargs):
        return self.power

    @property
    def symbols(self) -> list:
        return [self.symbol]

    @property
    def values(self) -> list:
        return [self.power]


class Radiation(InternalHeatSource):
    def __init__(self, *args, epsilon_short=0.7, epsilon_long=0.93, **kwargs):
        super().__init__(*args, **kwargs)
        self.epsilon_short = epsilon_short
        self.epsilon_long = epsilon_long
        self.epsilon_long_boltzmann = self.epsilon_long * Stefan_Boltzmann  # pre-calculation of calculate_dynamic
        self._bc_temp_input_index = None

    @property
    def bc_temp_input_index(self):
        if self._bc_temp_input_index is None:
            for fbc in self.node.get_connected_nodes(variant=FluidBoundaryCondition):
                # TODO: If multiple BoundaryConditions are connected, only the last one is used for temp. calculation
                #  If one capacitor has multiple BCs connected the calculation won't work as it is implemented currently
                #  with calculate_dynamic_functions if no weather data is used.
                fbc: FluidBoundaryCondition
                self._bc_temp_input_index = fbc.index
            assert self._bc_temp_input_index is not None
        return self._bc_temp_input_index

    def get_kwargs_functions(self) -> dict:
        if self.settings.calculate_static:
            return self.calculate_static_functions()
        return self.calculate_dynamic_functions()

    def calculate_static_functions(self) -> dict:
        dyn_functions: dict = self.calculate_dynamic_functions()
        result = {}
        for name, fun in dyn_functions.items():
            result[name] = (
                lambda f: lambda tau, temp_vec, input_vec, *args, **kwargs: f(0, temp_vec, input_vec, *args, **kwargs)
            )(fun)
        return result

    def calculate_dynamic_functions(self) -> dict:
        """
        This function is used to pre-calculate some values during solving that are node independent.

        This way calculation time can be decreased.

        Returns
        -------
        dict :
            A dictionary where the key stands for the parameter that is passed to the function calculating node
            dependent stuff and the value is its value (crazy, I know).
        """
        result = {}

        if self.settings.use_weather_data:
            result["incoming_area_specific_power_long"] = self.settings.area_specific_radiation_interpolator_long
            result["incoming_area_specific_power_short"] = self.settings.area_specific_radiation_interpolator_short
        else:
            dt = datetime.fromisoformat(self.settings.start_date)
            seconds_today = dt.hour * 3600 + dt.minute * 60 + dt.second + dt.microsecond / 1e6
            result["incoming_area_specific_power_short"] = lambda tau, *args, **kwargs: (
                sin_function(tau, seconds_today) * self.settings.maximum_area_specific_power
            )
            result["incoming_area_specific_power_long"] = lambda tau, *args, **kwargs: 0

            # the following only works if only one boundary condition is used for all Radiation objects (
            # e.g. the ExteriorTemperature and all Radiation objects are influenced by the same. If multiple
            # influences between Radiation objects and BCs would exists, the index is changing, depending on the
            # Radiation object. For that, calculate the value directly in each object (increases calculation overhead)
            # or create a unique kwarg for each of them (recommended with new classes))
            index = self.bc_temp_input_index
            result["sky_temp_4_diff"] = lambda tau, temp_vector, _input_vector, *args, _index=index, **kwargs: (
                sky_temp_according_to_swinbank(_input_vector.ravel()[_index]) ** 4
                - sky_temp_according_to_swinbank(_input_vector.ravel()[_index]) ** 4
            )
        return result

    def calculate_static(self, tau, temp_vector, _input_vector, **kwargs):
        return self.calculate_dynamic(0, temp_vector, _input_vector, **kwargs)

    def calculate_dynamic(
        self,
        tau,
        temp_vector,
        _input_vector,
        incoming_area_specific_power_short=np.nan,
        incoming_area_specific_power_long=np.nan,
        sky_temp_4_diff=np.nan,
        **kwargs,
    ):
        temp_vector_flat = temp_vector.ravel()

        node_temp_4 = temp_vector_flat[self.node.index] ** 4

        if self.settings.use_weather_data:
            outgoing_spec_power = self.epsilon_long_boltzmann * node_temp_4  # in W/m^2
        else:
            # here incoming_area_specific_power only contains the direct radiation. So the radiation towards sky and
            # ambient has to be calculated, too.
            # TODO: Use the sight factor of the wall for both sky and bc/ambient (but this information is not accessible
            #  here)
            outgoing_spec_power = 0.5 * self.epsilon_long_boltzmann * (2 * node_temp_4 - sky_temp_4_diff)
        power = (
            incoming_area_specific_power_long * self.epsilon_long
            + incoming_area_specific_power_short * self.epsilon_short
            - outgoing_spec_power
        ) * self.area
        self.volume_specific_power = power / self.node.volume
        return power


def sky_temp_according_to_swinbank(air_temperature: float):
    return 0.0552 * air_temperature ** 1.5


def sin_function(tau, shift_start_time):
    return np.maximum(0.0, -np.cos(np.pi / 43200 * (tau + shift_start_time)))


# must be at the end of this module
# This checks if for every BoundaryCondition also a similar class exists that inherits from Geometry / Cell (both separately)
_module = sys.modules[__name__]
for _counterpart in _bc_missing_counterparts:
    if not hasattr(_module, _counterpart):
        import warnings

        warnings.warn(f"Missing counterpart {_counterpart}", stacklevel=2)
