#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

import os
from collections.abc import Callable
from copy import copy
from typing import Any, Optional

import numpy as np

from pyrc.dataHandler.weather import WeatherData
from pyrc.core.wall import Wall


class SolveSettings:
    def __init__(
        self,
        max_saved_steps=5e4,
        method="RK45",
        max_step=0.4,
        rtol=1e-7,
        atol=1e-2,
        save_interval=1,
        minimize_ram_usage=True,
    ):
        """

        Parameters
        ----------
        max_saved_steps : int, optional
            The maximum number of seconds that are simulated in one solve_ivp call.
            Defines the batch size.
        method : str, optional
            The method of the solver. See solve_ivp
        max_step : int | float, optional
            The maximum number of seconds that the solver can use as one step.
        rtol, atol : float or array_like, optional
            Relative and absolute tolerances. The solver keeps the local error
            estimates less than ``atol + rtol * abs(y)``. Here `rtol` controls a
            relative accuracy (number of correct digits), while `atol` controls
            absolute accuracy (number of correct decimal places). To achieve the
            desired `rtol`, set `atol` to be smaller than the smallest value that
            can be expected from ``rtol * abs(y)`` so that `rtol` dominates the
            allowable error. If `atol` is larger than ``rtol * abs(y)`` the
            number of correct digits is not guaranteed. Conversely, to achieve the
            desired `atol` set `rtol` such that ``rtol * abs(y)`` is always smaller
            than `atol`. If components of y have different scales, it might be
            beneficial to set different `atol` values for different components by
            passing array_like with shape (n,) for `atol`. Default values are
            1e-3 for `rtol` and 1e-6 for `atol`. [Copied from scipy.solve_ivp doc]
        save_interval : int, optional
            In which interval the solution should be saved.
            One interval is as long as max_saved_steps.
        minimize_ram_usage : bool, optional
            If True and a save_path is given to the RCNetwork it occasionally deletes the solution after saving to
            disk to free RAM.
        """
        self.max_saved_steps: int = int(max_saved_steps)
        self.method = method
        self.max_step = max_step
        self.rtol = rtol
        self.atol = atol
        self.save_interval = save_interval
        self.minimize_ram_usage = minimize_ram_usage

    @property
    def keys(self):
        return [
            "max_saved_steps",
            "method",
            "max_step",
            "rtol",
            "atol",
            "save_interval",
            "minimize_ram_usage",
        ]

    @property
    def values(self):
        return [
            self.max_saved_steps,
            self.method,
            self.max_step,
            self.rtol,
            self.atol,
            self.save_interval,
            self.minimize_ram_usage,
        ]

    @property
    def dict(self):
        return {k: v for k, v in zip(self.keys, self.values)}

    def __copy__(self):
        return SolveSettings(**{k: copy(v) for k, v in zip(self.keys, self.values)})


class Settings:
    """
    Class for composition. Every object can get the same object of this class to determine global settings.

    In the future a settings yaml could be used and loaded in.
    """

    def __init__(
        self,
        calculate_static,
        use_weather_data,
        wall: Wall = Wall(),
        start_date="2022-01-01T00:00:00",  # if this initial value is changed you have to change the
        # Parameterization class values, too (it uses it hardcoded)
        weather_data_path=None,
        maximum_area_specific_power=400,
        save_folder_path=None,
        save_all_x_seconds=25,  # TODO: Maybe use not this value if not given but save 1000 steps for each simulation
        solve_settings: SolveSettings | Any = None,
    ):
        self.calculate_static = calculate_static
        self.wall = wall
        self.__start_date = start_date
        self.__use_weather_data: bool = use_weather_data
        self.__weather_data_path = os.path.normpath(weather_data_path) if weather_data_path is not None else None
        self.weather_data: Optional["WeatherData"] | Any = None
        self.__rebuild_weather_data()

        self._area_specific_radiation_interpolator_short = None
        self._area_specific_radiation_interpolator_long = None
        # only used if weather data is not used
        self.maximum_area_specific_power = maximum_area_specific_power

        self.__save_folder_path = None
        self.save_folder_path = save_folder_path

        self.save_all_x_seconds = save_all_x_seconds

        if solve_settings is None:
            solve_settings = SolveSettings()
        self.solve_settings: SolveSettings = solve_settings

    def __rebuild_weather_data(self) -> None:
        """(Re)create WeatherData if enabled and fully configured; otherwise set to None."""
        if not self.__use_weather_data:
            self.weather_data = None
            return

        if self.__weather_data_path is None:
            raise ValueError("use_weather_data=True requires weather_data_path to be set.")

        self.weather_data = WeatherData(
            self.__weather_data_path,
            start_time=self.__start_date,
        )

    def __copy__(self):
        obj = Settings(
            calculate_static=self.calculate_static,
            use_weather_data=False,
            wall=copy(self.wall),
            start_date=self.start_date,
            weather_data_path=self.weather_data_path,
            maximum_area_specific_power=self.maximum_area_specific_power,
            save_folder_path=self.save_folder_path,
            save_all_x_seconds=self.save_all_x_seconds,
            solve_settings=copy(self.solve_settings),
        )
        obj.use_weather_data = self.use_weather_data
        return obj

    def __deepcopy__(self):
        return self.__copy__()

    @property
    def save_folder_path(self):
        return self.__save_folder_path

    @save_folder_path.setter
    def save_folder_path(self, value):
        if value is not None:
            os.makedirs(os.path.normpath(value), exist_ok=True)
        self.__save_folder_path = value

    @property
    def start_date(self) -> str:
        return self.__start_date

    @start_date.setter
    def start_date(self, value: str) -> None:
        self.__start_date = value
        self.__rebuild_weather_data()

    @property
    def weather_data_path(self) -> Optional[str]:
        return self.__weather_data_path

    @weather_data_path.setter
    def weather_data_path(self, value: Optional[str]) -> None:
        self.__weather_data_path = os.path.normpath(value) if value is not None else None
        self.__rebuild_weather_data()

    @property
    def use_weather_data(self) -> bool:
        return self.__use_weather_data

    @use_weather_data.setter
    def use_weather_data(self, value: bool) -> None:
        self.__use_weather_data = value
        self.__rebuild_weather_data()

    @property
    def area_specific_radiation_interpolator_short(self) -> Callable | Any:
        if self._area_specific_radiation_interpolator_short is None:
            if self.weather_data is not None:
                self._area_specific_radiation_interpolator_short = self.weather_data.radiation_interpolator(
                    self.wall, wavelength_type="short"
                )
        return self._area_specific_radiation_interpolator_short

    @property
    def area_specific_radiation_interpolator_long(self) -> Callable | Any:
        if self._area_specific_radiation_interpolator_long is None:
            if self.weather_data is not None:
                self._area_specific_radiation_interpolator_long = self.weather_data.radiation_interpolator(
                    self.wall, wavelength_type="long"
                )
        return self._area_specific_radiation_interpolator_long

    @property
    def start_shift(self):
        return (
            np.datetime64(self.start_date) - np.datetime64(self.start_date).astype("datetime64[D]")
        ) / np.timedelta64(1, "s")


initial_wall = Wall()
initial_settings = Settings(
    calculate_static=False,
    use_weather_data=False,
    wall=initial_wall,
    # weather_data_path=r"C:\path\to\dwd_data\TRY2015_523748130791_Jahr.dat",
    # save_folder_path=r"C:\path\to\folder",
    start_date="2023-09-15T00:00:00",
)
settings_first_try = Settings(
    calculate_static=False,
    use_weather_data=True,
    wall=initial_wall,
    weather_data_path=r"/path/to/dwd_data/TRY2015_523748130791_Jahr.dat",
    # save_folder_path=r"/path/to/folder",
    start_date="2023-09-15T00:00:00",
)
# settings = Settings(
#     calculate_static=True,
#     use_weather_data=True,
#     wall=initial_wall,
#     weather_data_path=r"/path/to/dwd_data/TRY2015_523748130791_Jahr.dat",
#     save_folder_path=r"/path/to/folder",
#     start_date="2023-09-15T00:00:00",
# )
