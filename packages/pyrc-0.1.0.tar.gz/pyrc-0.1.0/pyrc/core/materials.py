#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

from pyrc.core.components.templates import Fluid, Solid, CompositeMaterialSolid


class Air(Fluid):
    def __init__(self):
        # values at 20 °C: https://stoffdaten-online.de/luft/
        super().__init__(
            name="air", density=1.189, heat_capacity=1.006e3, thermal_conductivity=25.87e-3, kin_viscosity=15.32e-6
        )


class Water(Fluid):
    def __init__(self):
        # values at 20 °C: https://de.scribd.com/document/705897719/Tabela-A-9
        super().__init__(
            name="water",
            density=998.0,
            heat_capacity=4182,
            thermal_conductivity=0.598,
            kin_viscosity=1.002e-3 / 998.0,
            prandtl_number=7.01,
        )


class Metal(Solid):
    def __init__(self):
        # generic metal - no real template
        super().__init__(
            name="Metal",
            density=3000,  # kg/m^3,
            heat_capacity=900e3,  # J/(kg*K)
            thermal_conductivity=40,  # W/(m*K)
        )


class EPS032(Solid):
    def __init__(self):
        # https://knauf.com/api/download-center/v1/assets/cf95bd43-57c8-4261-a11d-0e206a8927c2?download=true&country=de
        super().__init__(
            name="EPS_032",
            density=20,
            # kg/m^3, https://teamce.com.au/wp-content/themes/cecsgroup/_datasheets/concrete-formwork/styrene-insulation/Polystyrene.pdf
            heat_capacity=1.450e3,  # J/(kg*K)
            thermal_conductivity=0.032,  # W/(m*K)
        )


class SandLimeBrick(Solid):
    def __init__(self):
        # https://www.kalksandstein.de/produkte-daten-und-fakten/stoffwerte/
        super().__init__(
            name="Sand_Lime_Brick",
            density=2.0e3,  # kg/m^3
            heat_capacity=0.88e3,
            # J/(kg*K), https://www.schweizer-fn.de/stoff/wkapazitaet/wkapazitaet_baustoff_erde.php
            thermal_conductivity=1.1,  # W/(m*K)
        )


class Concrete(Solid):
    def __init__(self):
        # https://www.schweizer-fn.de/stoff/wkapazitaet/wkapazitaet_baustoff_erde.php
        # https://www.schweizer-fn.de/stoff/wleit_isolierung/wleit_isolierung.php
        super().__init__(
            name="Concrete",
            density=2.0e3,  # kg/m^3
            heat_capacity=1.0e3,  # J/(kg*K)
            thermal_conductivity=1.6,  # W/(m*K)
        )


class Plaster(Solid):
    def __init__(self):
        # https://www.schweizer-fn.de/stoff/wkapazitaet/wkapazitaet_baustoff_erde.php
        # "Verputz"
        # https://www.schweizer-fn.de/stoff/wleit_isolierung/wleit_isolierung.php
        # "Kalkzementputz Maschinenputz"
        super().__init__(
            name="Plaster",
            density=1.5e3,  # kg/m^3
            heat_capacity=0.8e3,  # J/(kg*K)
            thermal_conductivity=0.6,  # W/(m*K)
        )


class Clinker(Solid):
    def __init__(self):
        # https://materialarchiv.ch/de/ma:material_1263?type=all
        # https://www.schweizer-fn.de/stoff/wkapazitaet/wkapazitaet_baustoff_erde.php
        super().__init__(
            name="Clinker",
            density=2.2e3,  # kg/m^3
            heat_capacity=900,  # J/(kg*K)
            thermal_conductivity=1.2,  # W/(m*K)
        )


class Wood(Solid):
    def __init__(self):
        # https://de.wikipedia.org/wiki/Brettsperrholz
        super().__init__(name="Glass", density=500, heat_capacity=1610, thermal_conductivity=0.14)


class SodaLimeGlass(Solid):
    def __init__(self):
        # https://en.wikipedia.org/wiki/Soda%E2%80%93lime_glass
        super().__init__(name="Glass", density=2520, heat_capacity=720, thermal_conductivity=1)


class PolyvinylChloride(Solid):
    def __init__(self):
        # ISO 10077-2 appendix D table D.1
        # heat capacity: https://materials.fsri.org/materialdetail/polyvinyl-chloride-pvc
        super().__init__(name="PVC", density=1390, heat_capacity=1020, thermal_conductivity=0.17)


class WindowGlass(CompositeMaterialSolid):
    def __init__(self, part_air=0.077, part_glass=0.008):
        super().__init__(
            name="WindowGlass",
            materials=[Air(), SodaLimeGlass()],
            ratios=[part_air, part_glass],
            thermal_conductivity=0.34989,
        )


class WindowFrame(CompositeMaterialSolid):
    def __init__(self):
        super().__init__(
            name="WindowFrame",
            materials=[Air(), PolyvinylChloride()],
            ratios=[0.9, 0.1],
            thermal_conductivity=0.47176,  # with alpha_i = 7.3 and alpha_amb = 25 the U value is 2,8 like ISO 10077-2
        )


class WoodWall(CompositeMaterialSolid):
    def __init__(self):
        super().__init__(
            name="WoodWall",
            materials=[Air(), Wood()],
            ratios=[0.8, 0.2],
        )


class WindowHallway(CompositeMaterialSolid):
    def __init__(self):
        glas_ratio = 0.6 / 11.5
        super().__init__(
            name="WindowHallway",
            materials=[Air(), WindowGlass()],
            ratios=[1 - glas_ratio, glas_ratio],
        )


class WindowInBetween(CompositeMaterialSolid):
    def __init__(self):
        metal_ratio = 0.003 / 0.085
        super().__init__(
            name="WindowHallway",
            materials=[EPS032(), Metal()],
            ratios=[1 - metal_ratio, metal_ratio],
        )


class Cladding(CompositeMaterialSolid):
    def __init__(self):
        wood_ratio = 1.6 / 20
        super().__init__(
            name="WindowHallway",
            materials=[Air(), Wood()],
            ratios=[1 - wood_ratio, wood_ratio],
        )


class MetalWater(CompositeMaterialSolid):
    def __init__(self, metal_ratio=1.8 / 16):
        super().__init__(
            name=f"MetalWater_{metal_ratio:.5g}",
            materials=[Metal(), Water()],
            ratios=[metal_ratio, 1 - metal_ratio],
        )
