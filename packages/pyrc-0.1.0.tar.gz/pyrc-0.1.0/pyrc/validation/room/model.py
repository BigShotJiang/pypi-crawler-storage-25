#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

from pyrc.validation.network import NetworkTemplate


class RoomNetwork(NetworkTemplate):
    def __init__(self):
        super().__init__()
        self.settings.save_all_x_seconds = 5

    def _create_network(self):
        pass
