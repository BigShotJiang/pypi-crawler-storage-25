#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

# Script for validation
#
# Calculation of the solution of stationary heat conduction in different materials
#
# Analytic solution
#
import numpy as np

from pyrc.visualization.plot import LinePlot


def line_heat_conduction(
    range_x: list | np.ndarray | tuple,
    thickness: float | int,
    delta_temperature: float | int,
    lower_temperature: float | int = 0,
) -> np.ndarray:
    """

    Parameters
    ----------
    range_x : list | np.ndarray | tuple
        The x values to calculate the temperature for.
    thickness : float | int
        The thickness of the material in m.
    delta_temperature : float | int
        The temperature difference in K.
    lower_temperature : float | int, optional
        The lower temperature in K or °C.

    Returns
    -------
    np.ndarray :
        The temperature values for the given range_x through the material.
    """
    range_x = np.array(range_x)

    return lower_temperature + range_x / thickness * delta_temperature


def major_temperatures(
    walls: list,
    lower_temperature: float | int,
    upper_temperature: float | int,
):
    """

    Parameters
    ----------
    walls : list
        Tuples defining the walls in ascending temperature order.
        Each tuple consists of:
            1. thickness in m
            2. thermal conductivity coefficient in W/m/K
    lower_temperature : float | int
        The lower temperature in K
    upper_temperature : float | int
        The upper temperature in K

    Returns
    -------
    list :
        The temperatures between and at start/beginning of the walls.
    """

    if len(walls) == 1:
        return [lower_temperature, upper_temperature]

    # calculate heat transfer coefficient k
    k = get_k([t / tc for t, tc in walls])

    # specific heat flux
    spec_heat_flux = k * (upper_temperature - lower_temperature)

    result = [lower_temperature]
    for i, wall in enumerate(walls):
        s, conductivity = wall
        result.append(result[-1] + spec_heat_flux * s / conductivity)

    return result


def get_k(resistance_terms: list):
    """
    Calculates k.

    Parameters
    ----------
    resistance_terms : list
        The resistance terms. E.g.: thickness/thermal_conductivity or 1/alpha.

    Returns
    -------
    float :
        k in W/K/m/m
    """
    return 1 / sum(resistance_terms)


def make_temp_data(
    walls: list,
    lower_temperature: float | int,
    upper_temperature: float | int,
    number_points: int,
) -> tuple[np.ndarray, np.ndarray]:
    temps = major_temperatures(walls, lower_temperature, upper_temperature)

    thickness_list = [j[0] for j in walls]
    x_borders = np.cumsum([0, *thickness_list])
    x_values = x_borders
    y_values = np.array(temps)
    # number_points
    # total_thickness = sum(thickness_list)
    # increment = total_thickness / (number_points - 1)
    # x_values = np.array([n*increment for n in range(number_points)])
    #
    # y_values = np.zeros_like(x_values, dtype=float)
    #
    # current_temp = lower_temperature
    # for i in range(0, len(temps)-1):
    #     mask = (x_values<x_borders[i+1]) & (x_values >= x_borders[i])
    #     y_values[mask] = line_heat_conduction(
    #         x_values[mask] - x_borders[i],
    #         thickness_list[i],
    #         delta_temperature=temps[i],
    #         lower_temperature=current_temp
    #     )
    #     current_temp = y_values[mask][-1]

    return x_values, y_values


def run_conduction_analytic(plot_data=True):
    data = make_temp_data(
        [
            (0.1, 1),
            (0.2, 3),
            (0.5, 10),
            (0.1, 0.3),
            (0.1, 30),
        ],
        -11,
        20,
        number_points=300,
    )

    if plot_data:
        plot = LinePlot(x=data[0], ys=data[1], y_title="Temperature / °C")
        plot.plot()
        # plot.save("/home/kimmichjl/testplot.png")
        plot.save(r"C:\Simulations\PyRC\debug\conduction_analytic.png")
    else:
        return data[0], data[1]


if __name__ == "__main__":
    run_conduction_analytic(True)
