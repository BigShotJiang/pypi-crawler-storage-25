#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

from pyrc.validation.conduction.analytic import run_conduction_analytic
from pyrc.validation.conduction.model import run_conduction_model
import numpy as np
from pyrc.visualization.plot import LinePlot


def interpolate_extrapolate_vectors(first_x, second_x, second_y):
    """
    Interpolates and extrapolates y-values from the second dataset onto
    the x-values of the first dataset.

    For extrapolation, uses linear extension through the two nearest points.

    Parameters:
    -----------
    first_x : array-like
        X values of the first dataset (e.g., 1500 points)
    second_x : array-like
        X values of the second dataset (e.g., 7 points)
    second_y : array-like
        Y values of the second dataset (to be interpolated/extrapolated)

    Returns:
    --------
    new_x : numpy.ndarray
        Same as first_x
    new_y : numpy.ndarray
        Interpolated/extrapolated y-values at first_x positions
    """

    # Convert inputs to numpy arrays
    first_x = np.array(first_x)
    second_x = np.array(second_x)
    second_y = np.array(second_y)

    # Initialize result array
    new_y = np.zeros_like(first_x, dtype=float)

    # Get the x-range of the second dataset
    x_min = second_x[0]
    x_max = second_x[-1]

    for i, x_target in enumerate(first_x):
        if x_min <= x_target <= x_max:
            # Interpolation case: x_target is within the range
            new_y[i] = np.interp(x_target, second_x, second_y)
        elif x_target < x_min:
            # Left extrapolation: use the two leftmost points
            x1, x2 = second_x[0], second_x[1]
            y1, y2 = second_y[0], second_y[1]
            # Linear extrapolation: y = y1 + (y2-y1)/(x2-x1) * (x_target-x1)
            slope = (y2 - y1) / (x2 - x1)
            new_y[i] = y1 + slope * (x_target - x1)
        else:  # x_target > x_max
            # Right extrapolation: use the two rightmost points
            x1, x2 = second_x[-2], second_x[-1]
            y1, y2 = second_y[-2], second_y[-1]
            # Linear extrapolation: y = y2 + (y2-y1)/(x2-x1) * (x_target-x2)
            slope = (y2 - y1) / (x2 - x1)
            new_y[i] = y2 + slope * (x_target - x2)

    return new_y


if __name__ == "__main__":
    calculation_time = 1100
    x_model, y_model = run_conduction_model(False, calculation_time=calculation_time)
    x_analytic, y_analytic = run_conduction_analytic(False)

    # recalculate the values from analytic solution to x values of model solution to print in same plot
    y_analytic_polation = interpolate_extrapolate_vectors(x_model, x_analytic, y_analytic)

    plot = LinePlot(x=x_model, ys=y_model - y_analytic_polation, y_title="Temperature-Delta / K", x_title="Length / m")
    plot.plot()
    plot.ax.set_xlim(left=0, right=x_model[-1])
    # plot.fig.legend(loc="outside upper right", ncols=5)
    plot.save(
        r"C:\Simulations\PyRC\debug\conduction_comparison"
        f"_{calculation_time}.png"
    )
