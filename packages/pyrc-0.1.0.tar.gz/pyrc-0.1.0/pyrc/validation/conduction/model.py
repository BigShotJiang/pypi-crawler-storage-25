#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

# Script for validation
#
# Calculation of the solution of stationary heat conduction in different materials
#
# Model solution
#

import numpy as np

from pyrc.core.inputs import FluidBoundaryConditionGeometric
from pyrc.core.nodes import Node
from pyrc.core.resistors import HeatConduction, CombinedResistor
from pyrc.core.components.templates import Solid
from pyrc.visualization.plot import LinePlot
from pyrc.validation.network import NetworkTemplate


class Layer:
    def __init__(self, thickness, thermal_conductivity, number_increments=40):
        self.thickness = thickness
        self.thermal_conductivity = thermal_conductivity
        self.number_increments = number_increments


class ConductionNetwork(NetworkTemplate):
    def __init__(self, layers: list[Layer], set_increments_intelligent=False, increment_basic_number: int = 3):
        super().__init__()

        self.settings.solve_settings.atol = 1e-8

        self.save_to_pickle = True
        self.load_from_pickle = True
        self.load_solution = True

        self.layers = layers
        if set_increments_intelligent:
            increment_number = (
                np.ceil(1 / min([layer.thickness / layer.thermal_conductivity for layer in (self.layers)]))
                * increment_basic_number
            )
            for layer in self.layers:
                layer.number_increments = int(np.ceil(layer.thickness / layer.thermal_conductivity * increment_number))
        self.x_major_points = np.cumsum([0, *[l.thickness for l in layers]])

        self.initial_temperature = 0
        self.lower_temperature = -11
        self.upper_temperature = 20

    def _create_network(self, *args, **kwargs):
        # first, create the nodes
        layer_nodes = []
        layer: Layer
        for i, layer, x_start in zip(range(len(self.layers)), self.layers, self.x_major_points):
            material = Solid(
                f"material_{i}",
                thermal_conductivity=layer.thermal_conductivity,
                density=10,  # Speed up convergence by decreasing mass and heat capacity
                heat_capacity=100,
            )
            for increment in range(layer.number_increments):
                layer_nodes.append(
                    Node(
                        material=material,
                        temperature=self.initial_temperature,
                        position=np.array(
                            [x_start + (increment + 0.5) * layer.thickness / layer.number_increments, 0, 0]
                        ),
                        delta=(layer.thickness / layer.number_increments, 1, 1),
                        rc_objects=self.rc_objects,
                        rc_solution=self.rc_solution,
                    )
                )

        # add resistors between the nodes.
        all_resistors = []
        for i, node in enumerate(layer_nodes[:-1]):
            all_resistors.append(HeatConduction())
            all_resistors[-1].connect(layer_nodes[i])
            all_resistors[-1].connect(layer_nodes[i + 1])

        # add boundary conditions
        lower_temp_bc = FluidBoundaryConditionGeometric(
            temperature=self.lower_temperature,
            position=layer_nodes[0].position + np.array([-1, 0, 0]),
            rc_objects=self.rc_objects,
            rc_solution=self.rc_solution,
            settings=self.settings,
        )
        all_resistors.append(CombinedResistor(resistance=np.float64(0)))
        all_resistors.append(CombinedResistor())
        all_resistors[-1].connect(layer_nodes[0], direction=(-1, 0, 0), node_direction_points_to=lower_temp_bc)
        all_resistors[-1].connect(all_resistors[-2])
        all_resistors[-2].connect(lower_temp_bc)
        upper_temp_bc = FluidBoundaryConditionGeometric(
            temperature=self.upper_temperature,
            position=layer_nodes[-1].position + np.array([1, 0, 0]),
            rc_objects=self.rc_objects,
            rc_solution=self.rc_solution,
            settings=self.settings,
        )
        all_resistors.append(CombinedResistor(resistance=np.float64(0)))
        all_resistors.append(CombinedResistor())
        all_resistors[-1].connect(layer_nodes[-1], direction=(1, 0, 0), node_direction_points_to=upper_temp_bc)
        all_resistors[-1].connect(all_resistors[-2])
        all_resistors[-2].connect(upper_temp_bc)

        # add all nodes and resistors to rc_objects
        self.rc_objects.set_lists(
            capacitors=layer_nodes, resistors=all_resistors, boundaries=[lower_temp_bc, upper_temp_bc]
        )

        self.groups["layers"] = layer_nodes
        self.groups["boundaries"] = [lower_temp_bc, upper_temp_bc]


def run_conduction_model(plot_data=True, calculation_time=12000):
    network = ConductionNetwork(
        [
            Layer(0.1, 1, number_increments=6),
            Layer(0.2, 3, number_increments=5),
            Layer(0.5, 10, number_increments=10),
            Layer(0.1, 0.3, number_increments=40),
            Layer(0.1, 30, number_increments=3),
        ],
        set_increments_intelligent=True,
        increment_basic_number=2,
    )
    network.create_network()
    network.solve_network(
        # t_span=(0, 3600*24*1),
        t_span=(0, calculation_time),
        print_progress=True,
        check_courant=False,
    )

    if plot_data:
        plot = LinePlot(x=[n.position[0] for n in network.nodes], ys=network.rc_solution.temperature_vectors[-1, :])
        plot.plot()
        plot.ax.set_xlim(left=0, right=network.x_major_points[-1])
        plot.save(r"C:\Simulations\PyRC\debug\conduction_model.png")
    else:
        return [n.position[0] for n in network.nodes], network.rc_solution.temperature_vectors[-1, :]


if __name__ == '__main__':
    run_conduction_model(True)
