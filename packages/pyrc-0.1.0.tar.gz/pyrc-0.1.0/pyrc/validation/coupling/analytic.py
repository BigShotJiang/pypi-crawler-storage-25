#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

# Script for validation
#
# Calculation of the dynamic solution of two coupled volumes with different temperature
#
# Analytic solution
#
import numpy as np

from pyrc.visualization.plot import LinePlot
from pyrc.validation.coupling import setup
from pyrc.validation.network import Block, Model

thermal_conductivity = 10
density = 10
heat_capacity = 10
a = thermal_conductivity / (density * heat_capacity)


class ModelCoupling(Model):
    def __init__(self, blocks: list[Block]):
        """
        Initialize heat equation model with blocks.

        Parameters
        ----------
        blocks : list of Block
            List of Block objects defining initial conditions
        """
        super().__init__(blocks)

    def get_function(self, n_terms=60):
        """
        Returns function u(x,t) for 1D heat equation with adiabatic boundaries.

        Parameters
        ----------
        n_terms : int
            Number of Fourier series terms

        Returns
        -------
        callable
            Function u(x, t) that returns temperature for given positions x and times t.
            The function returns a value, vector or matrix.
            Same x values are in rows, same t values are in columns. (x, t)
        """
        L = self.length

        # Calculate A0
        A0 = sum(self.widths * np.array([b.initial_temperature for b in self.blocks])) / L

        # Calculate An coefficients
        def calculate_An(n):
            A_n = 0
            k_n = n * np.pi / L
            for j, block in enumerate(self.blocks):
                T_j = block.initial_temperature
                x1 = self.x_positions[j]
                x2 = self.x_positions[j + 1]
                A_n += T_j * (np.sin(k_n * x2) - np.sin(k_n * x1))

            return (2 / (L * k_n)) * A_n

        # Precompute coefficients
        coeffs = [calculate_An(n) for n in range(1, n_terms + 2)]

        def u(x, t):
            x = np.atleast_1d(x)
            t = np.atleast_1d(t)
            X, T = np.meshgrid(x, t, indexing="ij")

            result = np.full_like(X, A0)

            for n in range(1, n_terms + 2):
                result += coeffs[n - 1] * np.cos(n * np.pi * X / L) * np.exp(-self.alpha * (n * np.pi / L) ** 2 * T)

            # Override t=0 with exact initial conditions
            t_zero_indices = np.where(t == 0)[0]
            if len(t_zero_indices) > 0:
                for t_idx in t_zero_indices:
                    for i, block in enumerate(self.blocks):
                        if i == len(self.blocks) - 1:  # Last block includes right endpoint
                            mask = (x >= self.x_positions[i]) & (x <= self.x_positions[i + 1])
                        else:
                            mask = (x >= self.x_positions[i]) & (x < self.x_positions[i + 1])
                        result[mask, t_idx] = block.initial_temperature

            return result.squeeze()

        return u

    def get_function_new(self, n_terms=100):
        """
        Returns function u(x,t) for 1D heat equation with adiabatic boundaries.

        Parameters
        ----------
        n_terms : int
            Number of Fourier series terms

        Returns
        -------
        callable
            Function u(x, t) that returns temperature for given positions x and times t.
            The function returns a value, vector or matrix.
            Same x values are in rows, same t values are in columns. (x, t)
        """

        L = self.length

        def sum_constant(k):
            """
            Calculates constant values for each block for a given number of increment.

            Parameters
            ----------
            k : int
                The increment number.

            Returns
            -------
            list :
                A list with the constants for all blocks for the given icrement number k.
            """
            result = []

            for n, block in enumerate(self.blocks):
                T_n = block.initial_temperature
                x_n = self.x_positions[n]
                x_n_plus_one = self.x_positions[n + 1]

                result.append(
                    T_n * 2 / (np.pi * k) * (np.sin(k * np.pi * x_n_plus_one / L) - np.sin(k * np.pi * x_n / L))
                )
            return result

        def temperature_constants():
            # Counter of blocks with constant initial temperautres start at 0 here, not from 1 like in the derivation
            # from Juri Joussen
            result = []
            for n, block in enumerate(self.blocks):
                result.append(block.width / L * block.initial_temperature)
            return result

        temperature_const = temperature_constants()
        sum_constants = [sum_constant(n) for n in range(1, n_terms + 1)]

        def u(x, t):
            x = np.atleast_1d(x)
            t = np.atleast_1d(t)
            X, T = np.meshgrid(x, t, indexing="ij")

            result = np.full_like(X, np.array(temperature_const))

            for k in range(1, n_terms + 2):
                # The material properties are missing?!
                result += sum_constants[k - 1] * np.cos(k * np.pi * X / L) * np.exp(-((k * np.pi / L) ** 2) * T)

            # Override t=0 with exact initial conditions
            t_zero_indices = np.where(t == 0)[0]
            if len(t_zero_indices) > 0:
                for t_idx in t_zero_indices:
                    for i, block in enumerate(self.blocks):
                        if i == len(self.blocks) - 1:  # Last block includes right endpoint
                            mask = (x >= self.x_positions[i]) & (x <= self.x_positions[i + 1])
                        else:
                            mask = (x >= self.x_positions[i]) & (x < self.x_positions[i + 1])
                        result[mask, t_idx] = block.initial_temperature

            return result.squeeze()

        return u

    def error(self, n_terms, time):
        return np.exp(-self.alpha * (n_terms * np.pi / 15) ** 2 * time)

    def get_n_terms(self, time, maximum_error=1e-10):
        return int((-np.log(maximum_error) / (self.alpha * time)) ** 0.5 * self.length / np.pi + 1)


def run_coupling_analytic(plot_data: str = None, n_terms=None):
    blocks, _, times, name_add_on = setup()

    model = ModelCoupling(blocks)

    if n_terms is None:
        n_terms = model.get_n_terms(time=0.1, maximum_error=1e-12)
    else:
        n_terms = int(n_terms)
    function = model.get_function(n_terms=n_terms)

    result = function(x=model.x_values, t=np.array(times))

    if plot_data:
        plot = LinePlot(
            x=model.x_values,
            ys=result.T,
            labels=[f"{float(t):.1f} s" for t in times],
            y_title="Temperature / °C (analytic)",
            x_title="Length / m",
        )
        plot.plot()
        plot.ax.set_xlim(left=0, right=model.x_positions[-1])
        plot.fig.legend(loc="outside upper right", ncols=5)
        plot.save(plot_data)
    return model.x_values, result.T, times, name_add_on


if __name__ == "__main__":
    run_cooupling_analytic(True)
