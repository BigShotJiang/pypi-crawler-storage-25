#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

# Script for validation
#
# Calculation of the dynamic solution of two coupled volumes with different temperature
#
# Model solution
#
import numpy as np

from pyrc.core.nodes import Node
from pyrc.visualization.plot import LinePlot
from pyrc.validation.coupling import setup
from pyrc.validation.network import NetworkTemplate, Block
from pyrc.core.resistors import CombinedResistor


class CouplingNetwork(NetworkTemplate):
    def __init__(self, blocks: list[Block], save_and_load: bool = True, **kwargs):
        super().__init__(**kwargs)
        self.settings.save_all_x_seconds = 0.1
        self.settings.solve_settings.atol = 1e-8
        self.blocks = blocks

        if save_and_load:
            self.save_to_pickle = True
            self.load_from_pickle = True
            self.load_solution = True

        self.x_major_points = np.cumsum([0, *[b.width for b in self.blocks]])

    def _create_network(self):
        block_nodes = []
        block: Block
        for i, block in enumerate(self.blocks):
            x_start = sum([b.width for b in self.blocks[:i]])
            start_vector = np.array([x_start, 0, 0])
            for increment in range(block.increments):
                block_nodes.append(
                    Node(
                        material=block.material,
                        temperature=block.initial_temperature,
                        position=block.increment_positions[increment] + start_vector,
                        delta=(block.width / block.increments, 1, 1),
                        rc_objects=self.rc_objects,
                        rc_solution=self.rc_solution,
                    )
                )

        # add resistors between the nodes
        all_resistors = []
        for i, node in enumerate(block_nodes[:-1]):
            all_resistors.append(CombinedResistor())
            all_resistors[-1].double_connect(block_nodes[i], block_nodes[i + 1])

        # no BoundaryConditions must be added (adiabatic sides)
        self.rc_objects.set_lists(capacitors=block_nodes, resistors=all_resistors)


def run_coupling_model(plot_data: str = None, save_and_load=True):
    blocks, time_indexes, times, name_add_on = setup()
    network = CouplingNetwork(
        blocks,
        save_and_load,
        working_dir=r"C:\Simulations\PyRC\evaluation\coupling",
    )
    network.num_cores_jacobian = 4
    # network.settings.save_folder_path = r"C:\Simulations\PyRC\debug"
    network.create_network()
    network.solve_network(
        # t_span=(0, 3600*24*1),
        t_span=(0, 2000),
        print_progress=True,
        check_courant=False,
    )

    if plot_data:
        plot = LinePlot(
            x=[n.position[0] for n in network.nodes],
            ys=network.rc_solution.temperature_vectors[time_indexes],
            labels=[f"{float(t):.1f} s" for t in times],
            y_title="Temperature / °C (model)",
            x_title="Length / m",
        )
        plot.plot()
        plot.ax.set_xlim(left=0, right=network.x_major_points[-1])
        plot.fig.legend(loc="outside upper right", ncols=5)
        plot.save(plot_data)
    return (
        [n.position[0] for n in network.nodes],
        network.rc_solution.temperature_vectors[time_indexes],
        times,
        name_add_on,
        network,
    )


if __name__ == '__main__':
    run_coupling_model(True)
