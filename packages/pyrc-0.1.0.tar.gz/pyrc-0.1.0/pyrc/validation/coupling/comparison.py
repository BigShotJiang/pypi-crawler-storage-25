#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

# Script for validation
#
# Calculation of the dynamic solution of two coupled volumes with different temperature
#
# Comparison
#
import os

import numpy as np

from pyrc.visualization.plot import LinePlot
from pyrc.validation.coupling.analytic import run_coupling_analytic
from pyrc.validation.coupling.model import run_coupling_model

if __name__ == "__main__":
    save_folder = r"C:\Simulations\PyRC\evaluation\coupling"
    model_x, model_y, times, name_add_on, network = run_coupling_model(os.path.join(save_folder, "coupling_model.svg"))
    analytic_x, analytic_y, _, _ = run_coupling_analytic(
        os.path.join(save_folder, "coupling_analytic.svg"), n_terms=10000
    )

    plot = LinePlot(
        x=model_x,
        ys=model_y - analytic_y,
        labels=[f"{float(t):.1f} s" for t in times],
        y_title="Temperature-Delta / K",
        x_title="Length / m",
        width_mm=160,
        height_mm=90,
    )
    plot.plot()

    # Add tolerance of solver as line
    y_solver = np.max(
        network.settings.solve_settings.atol + network.settings.solve_settings.rtol * abs(model_y), axis=0
    )
    plot.plot(model_x, ys=[y_solver], labels=["min solver accuracy"])

    plot.ax.set_xlim(left=0, right=model_x[-1])
    plot.fig.legend(loc="outside upper right", ncols=5)
    plot.save(os.path.join(save_folder, f"coupling_comparison{name_add_on}_add.png"))
    plot.save(os.path.join(save_folder, f"coupling_comparison{name_add_on}_add.svg"))

    upper_limit = y_solver[int(len(y_solver) / 2)] * 1.5
    plot.ax.set_ylim(top=upper_limit, bottom=-1 * upper_limit)
    plot.fig.legend(loc="outside upper right", ncols=5)
    plot.save(os.path.join(save_folder, f"coupling_comparison{name_add_on}_add_2.png"))
    plot.save(os.path.join(save_folder, f"coupling_comparison{name_add_on}_add_2.svg"))
    # plot.ax.set_xlim(left=0, right=model_x[-1])
    # plot.ax.set_ylim(bottom=-0.05, top=0.05)
    # plot.fig.legend(loc="outside upper right", ncols=5)
    # plot.save(r"C:\Simulations\PyRC\debug\coupling_comparison2"
    #           f"{name_add_on}.png")
    # plot.ax.set_xlim(left=0, right=0.2)
    # plot.ax.set_ylim(bottom=-0.05, top=0.05)
    # plot.fig.legend(loc="outside upper right", ncols=5)
    # plot.save(r"C:\Simulations\PyRC\debug\coupling_comparison3"
    #           f"{name_add_on}.png")
    # plot.ax.set_xlim(left=0, right=0.1)
    # plot.ax.set_ylim(bottom=-0.05, top=0.05)
    # plot.fig.legend(loc="outside upper right", ncols=5)
    # plot.save(r"C:\Simulations\PyRC\debug\coupling_comparison4"
    #           f"{name_add_on}.png")
