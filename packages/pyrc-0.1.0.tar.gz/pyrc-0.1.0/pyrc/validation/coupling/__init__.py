#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

from pyrc.validation.network import Block

name_add_on = ""


def setup(save_step=0.1):
    increments_per_block = 1000
    increments_per_width = 1000 // 15
    blocks = [
        Block(8, 20, increments=increments_per_width * 8),
        Block(4, 60, increments=increments_per_width * 4),
        Block(2, -10, increments=increments_per_width * 2),
        Block(6, 0, increments=increments_per_width * 6),
    ]
    # blocks = [
    #     Block(8, 0, increments=increments_per_block),
    #     Block(4, 60, increments=increments_per_block),
    #     Block(8, 0, increments=increments_per_block),
    # ]
    kwargs = {
        # "thermal_conductivity": 10,
        # "density": 100,
        # "heat_capacity": 100,
    }
    # blocks = [
    #     Block(5, 0, increments=increments_per_block, **kwargs),
    #     Block(5, 60, increments=increments_per_block, **kwargs),
    #     Block(5, 0, increments=increments_per_block, **kwargs),
    # ]

    time_indexes = [x for x in [0] + [n * 10 ** i for i in [0, 1, 2, 3, 4] for n in [1, 2, 5]] if x <= 2000 / save_step]
    times = [t * save_step for t in time_indexes]

    return blocks, time_indexes, times, name_add_on
