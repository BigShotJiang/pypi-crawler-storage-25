#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

import numpy as np

from pyrc.core.network import RCNetwork
from pyrc.core.settings import SolveSettings, Settings
from pyrc.core.components.templates import RCObjects, RCSolution, Solid


class NetworkTemplate(RCNetwork):
    def __init__(self, working_dir=r"C:\Simulations\PyRC\debug"):
        solve_settings = SolveSettings(
            max_step=1000,
            save_interval=int(1e5),
            max_saved_steps=70,
            # rtol=0.1,
            atol=1e-8,
        )
        settings = Settings(
            calculate_static=False,
            use_weather_data=False,
            weather_data_path=None,
            save_folder_path=working_dir,
            save_all_x_seconds=300,
            solve_settings=solve_settings,
        )

        rc_objects = RCObjects()
        rc_solution = RCSolution(rc_objects=rc_objects)
        super().__init__(
            save_to_pickle=True,
            load_from_pickle=True,
            load_solution=True,
            settings=settings,
            rc_objects=rc_objects,
            rc_solution=rc_solution,
            num_cores_jacobian=None,
        )

    def _create_network(self, *args, **kwargs):
        pass


class Block:
    counter = 0

    def __init__(
        self,
        width,
        initial_temperature,
        increments=10,
        thermal_conductivity=10,
        density=10,
        heat_capacity=10,
    ):
        self.width = width
        self.initial_temperature = initial_temperature
        self.increments = increments

        self.material = Solid(
            f"material_{Block.counter}",
            thermal_conductivity=thermal_conductivity,
            density=density,
            heat_capacity=heat_capacity,
        )
        Block.counter += 1

        self.__increment_positions = None
        self.__x_values = None

    @property
    def x_values(self) -> np.ndarray:
        if self.__x_values is None:
            self.__x_values = (np.array(range(self.increments)) + 0.5) * self.width / self.increments
        return self.__x_values

    @property
    def increment_positions(self) -> np.ndarray:
        if self.__increment_positions is None:
            self.__increment_positions = np.column_stack(
                [self.x_values, np.zeros_like(self.x_values), np.zeros_like(self.x_values)]
            )
        return self.__increment_positions


class Model:
    def __init__(self, blocks: list[Block]):
        """
        Initialize heat equation model with blocks.

        Parameters
        ----------
        blocks : list of Block
            List of Block objects defining initial conditions
        """
        self.blocks: list[Block] = blocks
        self.widths = np.array([block.width for block in blocks])
        self.length = sum(self.widths)
        self.x_positions = np.concatenate([[0], np.cumsum(self.widths)])
        self.alpha = blocks[0].material.thermal_conductivity / (
            blocks[0].material.density * blocks[0].material.heat_capacity
        )
        self._x_values = None

    @property
    def x_values(self) -> list:
        if self._x_values is None:
            x_values = []
            for i, block in enumerate(self.blocks):
                start = sum([b.width for b in self.blocks[:i]])
                values = block.x_values + start
                x_values.extend(values.tolist())
            self._x_values = x_values
        return self._x_values
