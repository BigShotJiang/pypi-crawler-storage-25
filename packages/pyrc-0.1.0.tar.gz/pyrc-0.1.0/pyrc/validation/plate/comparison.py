#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

# Script for validation
#
# Calculation of the dynamic solution of a semi-infinite plate
#
# Comparison
#
from pyrc.visualization.plot import LinePlot
from pyrc.validation.plate.analytic import run_plate_analytic
from pyrc.validation.plate.model import run_plate_model

model_x, model_y, times, name_add_on = run_plate_model(False)
analytic_x, analytic_y, _, _ = run_plate_analytic(False)

plot = LinePlot(
    x=model_x,
    ys=model_y - analytic_y,
    labels=[f"{float(t):.1f} s" for t in times],
    y_title="Temperature-Delta / K",
    x_title="Length / m",
)
plot.plot()
plot.ax.set_xlim(left=0, right=model_x[-1])
plot.fig.legend(loc="outside upper right", ncols=5)
plot.save(
    r"C:\Simulations\PyRC\debug\plate_comparison"
    f"{name_add_on}.png"
)
plot.ax.set_xlim(left=0, right=model_x[-1])
plot.ax.set_ylim(bottom=-0.05, top=0.05)
plot.fig.legend(loc="outside upper right", ncols=5)
plot.save(
    r"C:\Simulations\PyRC\debug\plate_comparison2"
    f"{name_add_on}.png"
)
plot.ax.set_xlim(left=0, right=0.2)
plot.ax.set_ylim(bottom=-0.05, top=0.05)
plot.fig.legend(loc="outside upper right", ncols=5)
plot.save(
    r"C:\Simulations\PyRC\debug\plate_comparison3"
    f"{name_add_on}.png"
)
plot.ax.set_xlim(left=0, right=0.1)
plot.ax.set_ylim(bottom=-0.05, top=0.05)
plot.fig.legend(loc="outside upper right", ncols=5)
plot.save(
    r"C:\Simulations\PyRC\debug\plate_comparison4"
    f"{name_add_on}.png"
)
