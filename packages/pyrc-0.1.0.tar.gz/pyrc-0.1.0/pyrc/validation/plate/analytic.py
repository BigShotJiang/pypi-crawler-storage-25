#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

# Script for validation
#
# Calculation of the dynamic solution of a semi-infinite plate
#
# Analytic solution
#
import numpy as np
from scipy.special import erf

from pyrc.visualization.plot import LinePlot
from pyrc.validation.network import Model
from pyrc.validation.plate import setup

thermal_conductivity = 10
density = 10
heat_capacity = 10
a = thermal_conductivity / (density * heat_capacity)


def u(x, time, alpha, initial_temperature, new_temperature):
    x = np.atleast_1d(x)
    time = np.atleast_1d(time)
    X, T = np.meshgrid(x, time, indexing="ij")

    result = (1 - erf(X / (2 * (alpha * T) ** 0.5))) * (new_temperature - initial_temperature) + initial_temperature

    # Handle x=0 and time=0 case
    mask = (X == 0) & (T == 0)
    result[mask] = initial_temperature

    return result.squeeze()


class ModelPlate(Model):
    def __init__(self, blocks, new_temperature):
        super().__init__(blocks)
        self.initial_temperature = blocks[0].initial_temperature
        self.new_temperature = new_temperature

    def u(self, time):
        x = np.atleast_1d(self.x_values)
        time = np.atleast_1d(time)
        X, T = np.meshgrid(x, time, indexing="ij")

        result = (1 - erf(X / (2 * (self.alpha * T) ** 0.5))) * (
            self.new_temperature - self.initial_temperature
        ) + self.initial_temperature

        # Handle x=0 and time=0 case
        mask = (X == 0) & (T == 0)
        result[mask] = self.initial_temperature

        return result.squeeze()


def run_plate_analytic(plot_data=False):
    blocks, _, times, name_add_on = setup()

    model = ModelPlate(blocks, 20)

    result = model.u(times)  # x from top to bottom (axis=0) and time from left to right (axis=1)

    if plot_data:
        plot = LinePlot(
            x=model.x_values,
            ys=result.T,
            labels=[f"{float(t):.1f} s" for t in times],
            y_title="Temperature / °C (analytic)",
            x_title="Length / m",
        )
        plot.plot()
        plot.ax.set_xlim(left=0, right=model.x_positions[-1])
        plot.fig.legend(loc="outside upper right", ncols=5)
        plot.save(
            r"C:\Simulations\PyRC\debug\plate_analytic"
            f"{name_add_on}.png"
        )
    else:
        return model.x_values, result.T, times, name_add_on


if __name__ == '__main__':
    run_plate_analytic(True)
