#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

from pyrc.validation.network import Block

name_add_on = ""


def setup(save_step=0.1):
    increments_per_block = 1500
    # blocks = [
    #     Block(8, 20, increments=increments_per_block),
    #     Block(4, 60, increments=increments_per_block),
    #     Block(2, -10, increments=increments_per_block),
    #     Block(6, 0, increments=increments_per_block),
    # ]
    # blocks = [
    #     Block(8, 0, increments=increments_per_block),
    #     Block(4, 60, increments=increments_per_block),
    #     Block(8, 0, increments=increments_per_block),
    # ]
    blocks = [
        Block(1, 60, increments=increments_per_block,
              thermal_conductivity=20,
              density=1000,
              heat_capacity=1000,
              )
    ]

    time_indexes = [x for x in [0] + [n * 10 ** i for i in [0, 1, 2, 3, 4] for n in [1, 2, 5]] if x <= 2000 / save_step]
    times = [t * save_step for t in time_indexes]

    return blocks, time_indexes, times, name_add_on
