#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

# Script for validation
#
# Calculation of the dynamic solution of a semi-infinite plate
#
# Model solution
#
import numpy as np

from pyrc.core.inputs import FluidBoundaryConditionGeometric
from pyrc.core.nodes import Node
from pyrc.core.resistors import CombinedResistor
from pyrc.visualization.plot import LinePlot
from pyrc.validation.network import NetworkTemplate, Block
from pyrc.validation.plate import setup


class PlateNetwork(NetworkTemplate):
    def __init__(self, blocks: list[Block], new_temperature):
        super().__init__()
        self.settings.save_all_x_seconds = 0.1
        self.blocks = blocks
        self.new_temperature = new_temperature

        self.x_major_points = np.cumsum([0, *[b.width for b in self.blocks]])

    def _create_network(self):
        block_nodes = []
        block: Block
        for i, block in enumerate(self.blocks):
            x_start = sum([b.width for b in self.blocks[:i]])
            start_vector = np.array([x_start, 0, 0])
            for increment in range(block.increments):
                block_nodes.append(
                    Node(
                        material=block.material,
                        temperature=block.initial_temperature,
                        position=block.increment_positions[increment] + start_vector,
                        delta=(block.width / block.increments, 1, 1),
                        rc_objects=self.rc_objects,
                        rc_solution=self.rc_solution,
                    )
                )

        # add resistors between the nodes
        all_resistors = []
        for i, node in enumerate(block_nodes[:-1]):
            all_resistors.append(CombinedResistor())
            all_resistors[-1].double_connect(block_nodes[i], block_nodes[i + 1])

        # add Boundary to x=0 side
        bc = FluidBoundaryConditionGeometric(
            temperature=self.new_temperature,
            position=np.array([-1, 0, 0]),
            rc_objects=self.rc_objects,
            rc_solution=self.rc_solution,
            settings=self.settings,
        )
        conduction_resistor = CombinedResistor()
        convective_resistor = CombinedResistor(resistance=np.float64(0))
        conduction_resistor.connect(block_nodes[0], direction=(-1, 0, 0), node_direction_points_to=bc)
        convective_resistor.double_connect(conduction_resistor, bc)
        all_resistors.extend([conduction_resistor, convective_resistor])

        self.rc_objects.set_lists(capacitors=block_nodes, resistors=all_resistors, boundaries=[bc])


def run_plate_model(plot_data=False):
    blocks, time_indexes, times, name_add_on = setup()
    network = PlateNetwork(blocks, 20)
    network.save_to_pickle = True
    network.load_from_pickle = True
    network.num_cores_jacobian = 1
    # network.settings.save_folder_path = r"C:\Simulations\PyRC\debug"
    network.create_network()
    network.solve_network(
        # t_span=(0, 3600*24*1),
        t_span=(0, 2000),
        print_progress=True,
        check_courant=False,
    )
    if plot_data:
        plot = LinePlot(
            x=[n.position[0] for n in network.nodes],
            ys=network.rc_solution.temperature_vectors[time_indexes],
            labels=[f"{float(t):.1f} s" for t in times],
            y_title="Temperature / °C (model)",
            x_title="Length / m",
        )
        plot.plot()
        plot.ax.set_xlim(left=0, right=network.x_major_points[-1])
        plot.fig.legend(loc="outside upper right", ncols=5)
        plot.save(
            r"C:\Simulations\PyRC\debug\plate"
            f"{name_add_on}.png"
        )
    else:
        return (
            [n.position[0] for n in network.nodes],
            network.rc_solution.temperature_vectors[time_indexes],
            times,
            name_add_on,
        )


if __name__ == "__main__":
    run_plate_model(True)
