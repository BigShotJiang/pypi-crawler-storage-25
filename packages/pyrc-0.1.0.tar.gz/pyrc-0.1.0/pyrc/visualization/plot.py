#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------
from __future__ import annotations
from datetime import datetime, timedelta
from typing import TYPE_CHECKING

import numpy as np
from matplotlib import pyplot as plt
import matplotlib.dates as mdates
import matplotlib.ticker as ticker

from pyrc.tools.plotting import format_date_x_axis, custom_numeric_ticks_formatter
from pyrc.tools.science import cm_to_inch, is_numeric

if TYPE_CHECKING:
    pass
# plt.style.use('tableau-colorblind10')
# print(plt.style.available)
# load style sheet
# plt.style.use(os.path.normpath(os.path.join(package_dir, "visualization", "plotsettings.mplstyle")))
# plt.rcParams["axes.prop_cycle"] = plt.cycler("color", )


class PlotMixin(object):
    def __init__(self, x, ys, y_title="Heat Flux / W", marker_size=6, x_title=None, width_mm=160, height_mm=9):
        self.fig, self.ax = plt.subplots(layout="constrained")
        self.fig.set_size_inches(cm_to_inch(width_mm / 10), cm_to_inch(height_mm / 10))

        self.x = x
        self.ys = ys

        if isinstance(self.x[0], datetime):
            self.x_is_datetime = True
        else:
            self.x_is_datetime = False

        self.y_title = y_title
        self.x_title = x_title
        self.marker_size = marker_size

        self.lines = None
        self.labels = []

        self.next_color = self.color_iter()
        self.next_line_style = self.line_style_iter()
        self.next_marker = self.marker_iter()

    def __del__(self):
        if self.fig is not None:
            plt.close(self.fig)

    @property
    def markers(self) -> list[str]:
        return ["o", "s", "^", "v", "<", ">", "d", "p", "*", "h"]

    def marker_iter(self):
        markers = self.markers
        i = 0
        n = len(markers)
        while True:
            yield markers[i]
            i = (i + 1) % n

    @property
    def colors(self) -> list[tuple[float, float, float]]:
        return [
            (0.0051932, 0.098238, 0.34984),
            (0.98135, 0.80041, 0.98127),
            (0.51125, 0.5109, 0.1933),
            (0.1333, 0.37528, 0.3794),
            (0.94661, 0.61422, 0.41977),
            (0.066899, 0.26319, 0.37759),
            (0.9929, 0.70485, 0.70411),
            (0.30238, 0.45028, 0.30012),
            (0.75427, 0.56503, 0.21176),
            (0.40297, 0.48047, 0.24473),
        ]

    def line_style_iter(self):
        n = len(self.colors)
        styles = ["-", "--", ":", "-."]
        i = 0
        while True:
            yield styles[i // n]
            i += 1
            if i >= n * len(styles):
                i = 0

    def color_iter(self):
        colors = self.colors
        i = 0
        n = len(colors)
        while True:
            yield tuple(colors[i])
            i = (i + 1) % n

    def _add_line(self, line):
        if self.lines is None:
            self.lines = line
        else:
            self.lines = self.lines + line

    def _add_line_and_label(self, line, label=None):
        if self.lines is None:
            self.lines = line
        else:
            self.lines = self.lines + line
        self.labels.append(label)

    def format(self):
        if self.x_title is not None:
            self.ax.set_xlabel(self.x_title)
        if self.y_title is not None:
            self.ax.set_ylabel(self.y_title)
        self.ax.grid(True)
        self.ax.set_xlim(left=self.x[0], right=self.x[-1])
        if self.x_is_datetime:
            self.formate_x_datetime()

    def formate_x_datetime(self, start=None, end=None):
        if start is None:
            start = self.x[0]
        if end is None:
            end = self.x[-1]
        format_date_x_axis(start, end, self.ax, return_version=False)

    def format_numeric_ticks(self):
        formatter = ticker.FuncFormatter(custom_numeric_ticks_formatter)

        for ax in self.fig.get_axes():
            # Check if y-axis has numeric data
            try:
                current_formatter = ax.yaxis.get_major_formatter()
                if not isinstance(current_formatter, plt.matplotlib.dates.DateFormatter):
                    ax.yaxis.set_major_formatter(formatter)
            except:
                pass

            # Check x-axis
            if not self.x_is_datetime and not isinstance(self.x[0], str):
                try:
                    current_formatter = ax.xaxis.get_major_formatter()
                    if not isinstance(current_formatter, plt.matplotlib.dates.DateFormatter):
                        ax.xaxis.set_major_formatter(formatter)
                except:
                    pass

    def show_legend(self, **kwargs):
        initial_kwargs = {"loc": "outside upper right", "ncols": min(4, len(self.labels))}
        initial_kwargs.update(kwargs)
        self.fig.legend(handles=self.lines, labels=self.labels, **initial_kwargs)

    def show(self):
        self.format_numeric_ticks()
        plt.show()

    def save(self, path):
        self.format_numeric_ticks()
        self.fig.savefig(path, dpi=600)

    def close(self):
        if self.fig is not None:
            plt.close(self.fig)


class DoubleY(PlotMixin):
    def __init__(
        self,
        x,
        ys_left: list,
        ys_right: list,
        labels_left=None,
        labels_right=None,
        y_title_left="Heat Flux / W",
        y_title_right="Temperature / K",
        marker_size=6,
        **kwargs,
    ):
        if not isinstance(ys_left, list):
            ys_left = [ys_left]
        if not isinstance(ys_right, list):
            ys_right = [ys_right]
        ys_left = [np.array(y) for y in ys_left]
        ys_right = [np.array(y) for y in ys_right]

        super().__init__(x=np.array(x), ys=ys_left, y_title=y_title_left, marker_size=marker_size, **kwargs)

        self.ys_left = ys_left
        self.ys_right = ys_right
        self.y_title_right = y_title_right

        self.ax_right = self.ax.twinx()

        if labels_left is None:
            labels_left = [None] * len(ys_left)
        if labels_right is None:
            labels_right = [None] * len(ys_right)
        if not isinstance(labels_left, list):
            labels_left = [labels_left]
        if not isinstance(labels_right, list):
            labels_right = [labels_right]

        self.labels_left = labels_left
        self.labels_right = labels_right

    @property
    def ax_left(self):
        return self.ax

    def scale_right_axis(self):
        """
        Scales the right axis so that the major ticks matches the left one.
        """
        left_ticks = self.ax.get_yticks()
        num_ticks = len(left_ticks)

        # Get right axis data range
        right_data_min, right_data_max = self.ax_right.get_ylim()
        right_range = right_data_max - right_data_min

        # Generate nice spacings: [1,2,5] * 10^n
        nice_spacings = []
        for n in range(-10, 10):
            for base in [1, 2, 3, 4, 5, 6]:
                nice_spacings.append(base * 10**n)

        # Find the minimum spacing that can cover the data range with num_ticks-1 intervals
        target_spacing = right_range / (num_ticks - 1)
        right_tick_spacing = min([s for s in nice_spacings if s >= target_spacing])

        # Calculate new right axis limits based on nice spacing
        right_min = np.floor(right_data_min / right_tick_spacing) * right_tick_spacing
        right_max = right_min + (num_ticks - 1) * right_tick_spacing

        # Create right axis ticks
        right_ticks = np.linspace(right_min, right_max, num_ticks)

        self.ax_right.set_ylim(right_min, right_max)
        self.ax_right.set_yticks(right_ticks)

    def plot(self):

        for i, y in enumerate(self.ys_left):
            self._add_line_and_label(
                self.ax.plot(
                    self.x,
                    y,
                    label=self.labels_left[i],
                    color=next(self.next_color),
                    marker=next(self.next_marker),
                    markersize=self.marker_size,
                    linestyle="None",
                ),
                self.labels_left[i],
            )

        for i, y in enumerate(self.ys_right):
            self._add_line_and_label(
                self.ax_right.plot(
                    self.x,
                    y,
                    label=self.labels_right[i],
                    color=next(self.next_color),
                    marker=next(self.next_marker),
                    markersize=self.marker_size,
                    linestyle="None",
                ),
                self.labels_right[i],
            )

        self.format()

    def format(self):
        if self.x_title is not None:
            self.ax.set_xlabel(self.x_title)
        if self.y_title is not None:
            self.ax.set_ylabel(self.y_title)
        if self.y_title_right is not None:
            self.ax_right.set_ylabel(self.y_title_right)

        self.ax.grid(True)

        if not isinstance(self.x[0], str):
            dx = self.x[1] - self.x[0] if len(self.x) > 1 else 0
            self.ax.set_xlim(left=self.x[0] - dx / 2, right=self.x[-1] + dx / 2)

        if self.x_is_datetime:
            self.formate_x_datetime(self.x[0] - dx / 2, self.x[-1] + dx / 2)

        self.format_numeric_ticks()


class DoubleYSeparated(DoubleY):
    def __init__(
        self,
        x,
        ys_left: list,
        ys_right: list,
        labels=None,
        y_title_left="Heat Flux / W",
        y_title_right="Temperature / K",
        marker_size=6,
        same_marker=False,
    ):
        super().__init__(
            x, ys_left, ys_right, y_title_left=y_title_left, y_title_right=y_title_right, marker_size=marker_size
        )

        if labels is None:
            labels = [None] * len(ys_left)
        if not isinstance(labels, list):
            labels = [labels]
        self.labels = labels
        self.same_marker = same_marker

    def plot(self):

        for i, (y_left, y_right) in enumerate(zip(self.ys_left, self.ys_right)):
            marker = next(self.next_marker)

            self._add_line(
                self.ax.plot(
                    self.x,
                    y_left,
                    color="black",
                    marker=marker,
                    markersize=self.marker_size,
                    linestyle="None",
                )
            )

            if not self.same_marker:
                marker = next(self.next_marker)

            self._add_line(
                self.ax_right.plot(
                    self.x,
                    y_right,
                    color=self.colors[0],
                    marker=marker,
                    markersize=self.marker_size,
                    linestyle="None",
                )
            )

            if self.labels[i] is not None and not self.same_marker:
                self.ax.plot(
                    [],
                    [],
                    color="black",
                    marker=marker,
                    linestyle="None",
                    markersize=self.marker_size,
                    label=self.labels[i],
                )

        self.format()

    def format(self):
        super().format()
        self.ax.yaxis.label.set_color("black")
        self.ax.tick_params(axis="y", colors="black")
        self.ax_right.yaxis.label.set_color(self.colors[0])
        self.ax_right.tick_params(axis="y", colors=self.colors[0])


class LinePlot(PlotMixin):
    def __init__(
        self,
        x,
        ys: list | np.ndarray,
        labels=None,
        y_scale=1,
        y_title="Values",
        linewidth=1.8,
        x_title=None,
        width_mm=160,
        height_mm=90,
    ):
        if not isinstance(ys, list):
            if not (isinstance(ys, np.ndarray) and len(ys.shape) > 1 and ys.shape[0] > 1 and ys.shape[1] > 1):
                ys = [np.array(ys)]
        ys = [np.array(y) for y in ys]
        super().__init__(x=np.array(x), ys=ys, y_title=y_title, x_title=x_title, width_mm=width_mm, height_mm=height_mm)

        if labels is None:
            labels = [None] * len(ys)
        if not isinstance(labels, list):
            labels = [labels]
        self.labels = labels

        self.y_scale = y_scale
        self.line_width = linewidth

    def plot(self, x=None, ys=None, labels=None):
        if x is None:
            x = self.x
        if ys is None:
            ys = self.ys
        if labels is None:
            labels = self.labels
        if not isinstance(labels, list):
            labels = [labels]
        for i, y in enumerate(ys):
            self.ax.plot(
                x,
                np.array(y) * self.y_scale,
                label=labels[i],
                color=next(self.next_color),
                linewidth=self.line_width,
                linestyle=next(self.next_line_style),
            )
        self.format()

    def plot_marker(self):
        for i, y in enumerate(self.ys):
            self.ax.plot(
                self.x,
                np.array(y) * self.y_scale,
                label=self.labels[i],
                color=next(self.next_color),
                marker=next(self.next_marker),
            )
        self.format()

    def plot_stack(self):
        self.ax.stackplot(
            self.x,
            *[y * self.y_scale for y in self.ys],
            labels=self.labels,
            colors=self.colors,
        )
        self.format()

    def format(self):
        super().format()
        self.format_numeric_ticks()


class TimePlot(LinePlot):
    def format(self):
        super().format()
        self.formate_x_datetime()
        self.format_numeric_ticks()


class BarPlot(PlotMixin):
    def __init__(self, bar_values, bar_positions=None, y_title="Heat / kWh", **kwargs):
        assert len(bar_values) > 1
        if bar_positions is None:
            bar_positions = range(len(bar_values))
        super().__init__(x=bar_positions, ys=bar_values, y_title=y_title, **kwargs)

    @property
    def bar_width(self):
        if len(self.x) > 1:
            diff = np.diff(self.x)
            min_diff = np.min(diff)
            return min_diff * 0.8
        return 1

    def plot(self):
        self.ax.bar(self.x, self.ys, width=self.bar_width, color=next(self.next_color))
        self.format()

    def format(self):
        super().format()
        if is_numeric(self.x[0]):
            self.ax.set_xlim(left=self.x[0] - self.bar_width / 0.8 / 2, right=self.x[-1] + self.bar_width / 0.8 / 2)
        self.format_numeric_ticks()


class TimeBarPlot(BarPlot):
    def __init__(self, bar_values, bar_positions, y_title="Heat / kWh", **kwargs):
        super().__init__(bar_values, bar_positions, y_title=y_title, **kwargs)

    @property
    def bar_width(self) -> float:
        if len(self.x) > 1:
            date_nums = mdates.date2num(self.x)
            time_diffs = np.diff(date_nums)
            min_diff = time_diffs[0]
            return float(min_diff * 0.8)
        else:
            return 1 / 24

    def format(self):
        super().format()
        format_date_x_axis(self.x[0], self.x[-1], self.ax, return_version=False)
        self.ax.set_xlim(
            left=self.x[0] - timedelta(days=self.bar_width / 0.8 / 2),
            right=self.x[-1] + timedelta(days=self.bar_width / 0.8 / 2),
        )
        self.format_numeric_ticks()


def seconds_to_dates(seconds: list, start_date=datetime(2023, 1, 1), return_array=False) -> list | np.ndarray:
    result = [start_date + timedelta(seconds=int(s)) for s in seconds]
    if return_array:
        return np.array(result)
    return result


def format_x_axis_to_date(fig, ax):
    ax.xaxis.set_major_locator(mdates.DayLocator(bymonthday=(1, 7, 14, 21, 28)))
    ax.xaxis.set_minor_locator(mdates.DayLocator(interval=1))
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%d.%m."))
    ax.grid(True)
    # for label in ax.get_xticklabels(which="major"):
    #     label.set(rotation=30, horizontalalignment="right")
    ax.tick_params(axis="x", which="minor", bottom=True)
    fig.autofmt_xdate()
    return fig, ax
