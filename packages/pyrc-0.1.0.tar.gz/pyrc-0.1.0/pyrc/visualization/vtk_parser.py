#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

from __future__ import annotations
from typing import TYPE_CHECKING

import numpy as np
import meshio
import os
import multiprocessing

if TYPE_CHECKING:
    from pyrc.core.nodes import Node


def write_vtu_parallel(t_idx,
                       name: str,
                       time_steps: list,
                       matrix,
                       output_folder: str,
                       format_layout: str,
                       points: np.ndarray,
                       cells: np.array,
                       cell_type: str = "hexahedron"):
    """
    Writes a single .vtu file for a specific time step. Is used in multiprocessing pool.starmap

    Parameters
    ----------
    t_idx : int
        The index of the time step.
    name : str
        The name of the parameter.
    time_steps : list
        A list with all time steps.
    matrix : np.ndarray
        A numpy matrix with the values.
        Shape: time_steps, nodes
        For one time step one row is used (not one column)!
    output_folder : str
        The output folder.
    format_layout : str
        A format to style the index of the temperature. Should be: "0{len(time_steps)}d"


    Returns
    -------
    str :
        The line to add to the pvd file that links to the created temperature file.
    """
    vtu_filename = os.path.join(output_folder, f"{name}_{t_idx:{format_layout}}.vtu")

    mesh = meshio.Mesh(
        points=points,
        cells=[(cell_type, cells)],
        cell_data={name: [matrix[t_idx, :]]},  # Fast NumPy slicing
    )

    mesh.write(vtu_filename)
    return f'<DataSet timestep="{time_steps[t_idx]}" file="{name}_{t_idx:{format_layout}}.vtu" />'


# Function to write VTU files
def write_static_cells_vtu(nodes: list[Node],
                           output_folder="output") -> tuple[np.ndarray, np.ndarray]:
    os.makedirs(os.path.normpath(output_folder), exist_ok=True)

    # Define hexahedral cells (each node is a box-like cell)
    cells = []
    all_points = []
    for i, node in enumerate(nodes):
        # Compute the 8 corner points of the hexahedral cell
        min_corner = node.position - node.delta / 2
        max_corner = node.position + node.delta / 2
        cell_points = np.array([
            min_corner,
            [max_corner[0], min_corner[1], min_corner[2]],
            [max_corner[0], max_corner[1], min_corner[2]],
            [min_corner[0], max_corner[1], min_corner[2]],
            [min_corner[0], min_corner[1], max_corner[2]],
            [max_corner[0], min_corner[1], max_corner[2]],
            [max_corner[0], max_corner[1], max_corner[2]],
            [min_corner[0], max_corner[1], max_corner[2]],
        ])

        # Append points and define cell connectivity
        start_idx = len(all_points)
        all_points.extend(cell_points)
        cells.append(list(range(start_idx, start_idx + 8)))

    all_points = np.array(all_points)  # Convert to NumPy array

    # --- 2️⃣ Save the Base Geometry as `nodes.vtu` ---
    cells = np.array(cells)
    base_mesh = meshio.Mesh(
        all_points,
        [("hexahedron", cells)],
    )
    base_vtu_file = os.path.join(output_folder, "nodes.vtu")
    base_mesh.write(base_vtu_file)
    print(f"Base geometry saved: {base_vtu_file}")

    pvd_static = ['<DataSet timestep="0.0" file="nodes.vtu" />']
    write_pvd(pvd_static, output_folder=output_folder, name="nodes")

    return all_points, cells


# Function to write VTU files
def write_temperature_vtu(result_temperatures: np.ndarray,
                          time_steps: list,
                          points: np.ndarray,
                          cells: np.ndarray,
                          output_folder="output",
                          step_interval: int = 1, ):
    os.makedirs(os.path.normpath(output_folder), exist_ok=True)

    # --- 1️⃣ Generate Time-Step VTU Files ---
    temperatures = result_temperatures  # Shape: (num_time_steps, num_nodes)

    num_time_steps = temperatures.shape[0]

    format_number = len(str(num_time_steps))
    format_layout = f"0{format_number}d"
    if step_interval is None:
        step_interval = max(1, len(time_steps) // 2000)
    selected_indices = range(0, num_time_steps, step_interval)

    # --- 2️⃣ Parallel File Writing ---
    pool = multiprocessing.Pool(processes=multiprocessing.cpu_count())  # Use all CPU cores
    tasks = [(t_idx, "temperature", time_steps, temperatures, output_folder, format_layout, points, cells) for t_idx in
             selected_indices]

    pvd_entries = pool.starmap(write_vtu_parallel, tasks)
    pool.close()
    pool.join()

    # for t_idx in selected_indices:
    #     temperatures = np.array([node.temperature_vector.iloc[t_idx] for node in nodes])
    #
    #     timestep_mesh = meshio.Mesh(
    #         all_points,
    #         [("hexahedron", np.array(cells))],
    #         cell_data={"Temperature": [temperatures]},
    #     )
    #
    #     vtu_filename = os.path.join(output_folder, f"temperature_{t_idx:{format_layout}}.vtu")
    #     timestep_mesh.write(vtu_filename)
    #
    #     pvd_entries.append(f'<DataSet timestep="{time_steps[t_idx]}" file="temperature_{t_idx:{format_layout}}.vtu" />')

    write_pvd(pvd_entries, output_folder)


def write_pvd(pvd_entries: list, output_folder="output", name="00_simulation"):
    os.makedirs(output_folder, exist_ok=True)

    pvd_content = f"""<?xml version="1.0"?>
        <VTKFile type="Collection" version="0.1">
          <Collection>
            {"".join(pvd_entries)}
          </Collection>
        </VTKFile>"""

    pvd_file_path = os.path.join(output_folder, f'{name}.pvd')
    with open(pvd_file_path, "w") as f:
        f.write(pvd_content)

    print(f"PVD file saved: {pvd_file_path}")


def create_heat_flux_lines(resistors,
                           time_steps: list,
                           output_folder="output",
                           step_interval=None):
    os.makedirs(output_folder, exist_ok=True)
    n_time_steps = len(time_steps)

    if step_interval is None:
        step_interval = max(1, n_time_steps // 2000)
    format_number = len(str(n_time_steps))
    format_layout = f"0{format_number}d"

    selected_indices = range(0, n_time_steps, step_interval)

    line_points = []
    line_cells = []
    flux_vectors = []
    sources = []
    sinks = []

    point_idx = 0

    from pyrc.core.resistors import MassTransport
    for resistor in resistors:
        if isinstance(resistor, MassTransport):
            source, sink = resistor.source, resistor.sink
        else:
            source, sink = resistor.neighbours[0], resistor.neighbours[1]
        sources.append(source)
        sinks.append(sink)

        direction = sink.position - source.position
        direction /= np.linalg.norm(direction)  # Normalize vector
        flux_vectors.append(direction)  # Store unit vector for later scaling

        line_points.extend([source.position, sink.position])
        line_cells.append([point_idx, point_idx + 1])  # Positive direction
        line_cells.append([point_idx + 1, point_idx])  # Negative direction

        point_idx += 2

    line_points = np.array(line_points)
    line_cells = np.array(line_cells)
    flux_vectors = np.array(flux_vectors)

    line_mesh = meshio.Mesh(
        line_points,
        [("line", np.array(line_cells))],
    )
    line_vtu_file = os.path.join(output_folder, "line_cells.vtu")
    line_mesh.write(line_vtu_file)
    print(f"Line cell geometry saved: {line_vtu_file}")

    temperatures_source = np.array(
        [source.temperature_vector for source in sources])  # shape[resistors,timesteps]
    temperatures_sink = np.array([sink.temperature_vector for sink in sinks])  # shape[resistors, timesteps]
    resistances = np.array([resistor.resistance for resistor in resistors])[:, np.newaxis]  # shape[resistors, 1]
    temp_delta = temperatures_source - temperatures_sink  # shape[resistors, timesteps]
    fluxes = temp_delta[:, selected_indices] / resistances  # shape[resistors, timesteps]

    flux_positive = np.maximum(fluxes, 0)[..., np.newaxis] * flux_vectors[:, np.newaxis, :]
    flux_negative = -np.maximum(-fluxes, 0)[..., np.newaxis] * flux_vectors[:, np.newaxis, :]

    flux_vector_data = np.empty((len(selected_indices), len(resistors) * 2, 3))
    flux_vector_data[:, ::2, :] = np.transpose(flux_positive, (1, 0, 2))
    flux_vector_data[:, 1::2, :] = np.transpose(flux_negative, (1, 0, 2))

    pool = multiprocessing.Pool(processes=multiprocessing.cpu_count())  # Use all CPU cores
    tasks = [(t_idx,
              "HeatFluxVector",
              time_steps[selected_indices],
              flux_vector_data,
              output_folder,
              format_layout,
              line_points,
              line_cells,
              "line") for t_idx in range(len(selected_indices))]

    pvd_entries = pool.starmap(write_vtu_parallel, tasks)
    pool.close()
    pool.join()

    # for t_idx in selected_indices:
    #     fluxes = (temperatures_source[:, t_idx] - temperatures_sink[:, t_idx]) / resistances.flatten()
    #
    #     flux_vector_data = np.zeros((len(resistors) * 2, 3))  # 3D vector field
    #     flux_vector_data[::2] = flux_vectors * np.maximum(fluxes[:, np.newaxis], 0)  # Positive flux
    #     flux_vector_data[1::2] = -flux_vectors * np.maximum(-fluxes[:, np.newaxis], 0)  # Negative flux
    #
    #     mesh = meshio.Mesh(
    #         points=line_points,
    #         cells=[("line", np.array(line_cells))],
    #         cell_data={"HeatFluxVector": [flux_vector_data]}
    #     )
    #     vtu_filename = os.path.join(output_folder, f"heat_flux_{t_idx:{format_layout}}.vtu")
    #     mesh.write(vtu_filename)
    #
    #     pvd_entries.append(f'<DataSet timestep="{time_steps[t_idx]}" file="heat_flux_{t_idx:{format_layout}}.vtu" />')

    write_pvd(pvd_entries, output_folder, name="00_HeatFluxVector")
