#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

# Locale settings
import locale

from matplotlib import pyplot as plt


def set_german_number_format():
    # Set to German locale to get comma decimal separator
    locale.setlocale(locale.LC_NUMERIC, "de_DE.UTF-8")
    # if this throw an error you need to call the linux command: sudo locale-gen "de_DE.UTF-8"
    plt.rcParams["axes.formatter.use_locale"] = True


from pyrc.visualization.plot import (
    PlotMixin,
    DoubleY,
    DoubleYSeparated,
    LinePlot,
    TimePlot,
    BarPlot,
    TimeBarPlot,
    seconds_to_dates,
    format_x_axis_to_date,
)
from pyrc.visualization.vtk_parser import write_pvd, write_static_cells_vtu, write_temperature_vtu

__all__ = ["set_german_number_format"]

__all__.extend(
    [
        "PlotMixin",
        "DoubleY",
        "DoubleYSeparated",
        "LinePlot",
        "TimePlot",
        "BarPlot",
        "TimeBarPlot",
        "seconds_to_dates",
        "format_x_axis_to_date",
    ]
)
__all__.extend(["write_pvd", "write_static_cells_vtu", "write_temperature_vtu"])