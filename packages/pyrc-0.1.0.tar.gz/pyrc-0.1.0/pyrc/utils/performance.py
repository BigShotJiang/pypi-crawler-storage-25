#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

import numpy as np
from sympy import symbols

from pyrc.core.components.capacitor import Capacitor
from pyrc.core.components.resistor import Resistor
from pyrc.tools.science import celsius_to_kelvin
from pyrc.tools.timing import Timing
from pyrc.core.network import RCNetwork
from pyrc.core.inputs import BoundaryCondition


class PerformanceTest:

    def __init__(self):
        self.network = RCNetwork()
        # Initialize rng with seed to always get the same random numbers
        self.rng = np.random.default_rng(1)

    def get_random_temperature(self):
        return celsius_to_kelvin(self.rng.normal(loc=15, scale=25))

    def build_big_network(self, number_of_nodes=10000, resistors_between_nodes=1):
        """
        Creates a huge RC-Network and saves it in self.__network.

        """
        boundaries = [BoundaryCondition(celsius_to_kelvin(-10)),
                      BoundaryCondition(celsius_to_kelvin(40))]

        nodes = []
        for i in range(number_of_nodes):
            nodes.append(
                Capacitor(
                    capacity=abs(self.rng.normal(loc=10, scale=3)),
                    temperature=self.get_random_temperature(),
                )
            )

        resistors = []
        for i in range((number_of_nodes + 1) * resistors_between_nodes):
            if i == 1:
                resistance = symbols("my_variable")
            else:
                resistance = self.rng.normal(loc=10, scale=20)
            resistors.append(
                Resistor(resistance=resistance)
            )

        # Connect all parts to one network
        boundaries[0].connect(resistors[0])

        # resistor_index = 0
        last_part = resistors[0]
        for i in range(1, len(resistors)):
            if i % resistors_between_nodes == 0:
                # add node
                index = int(i / resistors_between_nodes - 1)
                if index < len(nodes):
                    last_part.connect(nodes[index])
                    last_part = nodes[index]
            last_part.connect(resistors[i])
            last_part = resistors[i]

        last_part.connect(boundaries[1])

        # Network created. Add all objects to rc_objects list.
        self.network.rc_objects.set_lists(capacitors=nodes, resistors=resistors, boundaries=boundaries)

    def test_performance(self, *args, **kwargs):
        time_dependent_function = lambda t, temp, **kwargs: np.sin(t) + 3

        time = Timing("Performance test")

        self.build_big_network(*args, **kwargs)
        time.catch_time("Network build up.")

        self.network.make_system_matrices()
        time.catch_time("Symbol matrices created.")

        def start_solve():
            time.catch_time("Start solving...")

        _ = self.network.solve_network((0, 10), hook_function=start_solve,
                                       time_dependent_function=time_dependent_function)
        time.catch_time("10 seconds simulated.")
        time.end_timing()


if __name__ == "__main__":
    network_test = PerformanceTest()
    network_test.test_performance()
