#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

import os.path
from collections.abc import Callable
from datetime import datetime

import numpy as np
import pandas as pd
from scipy.interpolate import PchipInterpolator

from pyrc.core.wall import Wall


class WeatherData:
    def __init__(
        self,
        path,
        start_time: str | datetime = "2015-01-01T01:00",
    ):
        self.path = os.path.normpath(path)
        if not isinstance(start_time, datetime):
            start_time = datetime.fromisoformat(start_time)
        self.start_time: datetime = start_time
        self.datetime_col_index = 0
        self.edge_points = 5
        self.columns = [
            "temp",  # 0
            "pressure",  # 1
            "wind direction",  # 2
            "wind speed",  # 3
            "cloudiness",  # 4
            "moisture",  # 5
            "relative_humidity",  # 6
            "direct solar radiation",  # 7
            "diffuse solar radiation",  # 8
            "atmospheric heat radiation",  # 9
            "terrestrial heat radiation",  # 10
        ]

        self.__period = None
        self.__interpolators = None

    def __copy__(self):
        return WeatherData(
            path=self.path,
            start_time=datetime.fromisoformat(self.start_time.isoformat()),
        )

    def __deepcopy__(self):
        return self.__copy__()

    @property
    def period(self):
        if self.__period is None:
            _, self.__period = self._make_interpolators()
        return self.__period

    @property
    def interpolators(self) -> list[PchipInterpolator]:
        if self.__interpolators is None:
            self.__interpolators, self.__period = self._make_interpolators()
        return self.__interpolators

    def get_raw_data(self) -> np.ndarray:
        df = pd.read_csv(
            self.path,
            skiprows=34,
            sep="\s+",
            header=None,
            names=["RW", "HW", "MM", "DD", "HH", "T", "P", "WR", "WG", "N", "x", "RF", "B", "D", "A", "E", "IL"],
        )

        df["datetime"] = pd.to_datetime(dict(year=2015, month=df["MM"], day=df["DD"], hour=df["HH"]))
        df.drop(columns=["RW", "HW", "IL", "MM", "DD", "HH"], inplace=True)

        df["T"] += 273.15  # °C to K
        df["P"] *= 100  # hPa to Pa
        df["N"] /= 8.0  # 1/8 to 0–1
        df["x"] /= 1000.0  # g/kg to kg/kg

        cols = ["datetime"] + [c for c in df.columns if c != "datetime"]
        df = df[cols]

        result = df.to_numpy()
        result[:, 0] = result[:, 0].astype("datetime64[s]")

        return result

    def get_interpolator_values(self) -> tuple:

        # rearrange matrix so that it starts at start_time
        seconds, data = self.reorder_matrix_by_time()
        columns = np.arange(1, data.shape[1])  # skip datetime column by default
        values = data[:, columns]

        # edge padding using correct slices
        period = seconds[-1] - seconds[0] + (seconds[1] - seconds[0])
        left = np.arange(-self.edge_points, 0)
        right = np.arange(0, self.edge_points)
        extended_seconds = np.concatenate([seconds[left] - period, seconds, seconds[right] + period])
        extended_values = np.concatenate([values[left], values, values[right]])
        return extended_seconds, extended_values, period

    def _make_interpolators(self):
        extended_seconds, extended_values, period = self.get_interpolator_values()

        interpolators = [
            PchipInterpolator(extended_seconds, extended_values[:, i], extrapolate=False)
            for i in range(extended_values.shape[1])
        ]
        return interpolators, period

    def _radiation_values_on_wall(self, wall: Wall):
        """
        Used to get some values you need for calculations with radiation.

        See `self.get_radiation_on_wall_interpolator`

        Parameters
        ----------
        wall : Wall
            The `Wall` to calculate the incoming specific power on.

        Returns
        -------
        stuff
        """
        seconds, values, period = self.get_interpolator_values()
        direct_rad: np.ndarray = values[:, 7]
        diffuse_rad: np.ndarray = values[:, 8]
        atmospheric_rad: np.ndarray = values[:, 9]
        terrestrial_rad: np.ndarray = -1 * values[:, 10]  # change to positive

        # parse the values on the wall (to recalculate all values for horizontal planes on the wall)
        dates = np.array(np.datetime64(self.start_time.isoformat())) + seconds * np.timedelta64(1, "s")
        direct_rad_values = wall.apply_direct_radiation(direct_rad, dates=dates)
        diffuse_rad_values = wall.apply_sky_radiation(diffuse_rad)
        atmospheric_rad_values = wall.apply_sky_radiation(atmospheric_rad)
        terrestrial_rad_values = wall.apply_ground_radiation(terrestrial_rad)

        return seconds, direct_rad_values, diffuse_rad_values, atmospheric_rad_values, terrestrial_rad_values

    def radiation_interpolator(self, wall: Wall, wavelength_type="short") -> Callable:
        """
        Returns an interpolator that calculates the incoming specific power of short/long wavelengths on a wall in
        W/m^2.

        Parameters
        ----------
        wall : Wall
            The wall to calculate the incoming specific power on.
        wavelength_type : str | int | bool, optional
            The type of wavelengths to use.
            If "short", 0 or False, the interpolator for short wavelengths are returned, long otherwise.

        Returns
        -------
        Callable :
            The interpolator in the form ``f(time, *args, **kwargs)`` where only the time variable is actually used.
        """
        seconds, direct_rad_values, diffuse_rad_values, atmospheric_rad_values, terrestrial_rad_values = (
            self._radiation_values_on_wall(wall)
        )

        if wavelength_type == "short" or wavelength_type == 0 or wavelength_type == False:
            result_values = np.sum([direct_rad_values, diffuse_rad_values], axis=0)
            interpolator = PchipInterpolator(seconds, result_values, extrapolate=False)
            return lambda time, *args, **kwargs: interpolator(time % self.period)
        result_values = np.sum([atmospheric_rad_values, terrestrial_rad_values], axis=0)
        interpolator = PchipInterpolator(seconds, result_values, extrapolate=False)
        return lambda time, *args, **kwargs: interpolator(time % self.period)

    def get_radiation_on_wall_interpolator(self, wall: Wall) -> Callable:
        """
        Returns an interpolator that calculates the incoming specific power on a wall in W/m^2.

        Parameters
        ----------
        wall : Wall
            The wall to calculate the incoming specific power on.

        Returns
        -------
        Callable :
            The interpolator in the form ``f(time, *args, **kwargs)`` where only the time variable is actually used.

        """
        seconds, direct_rad_values, diffuse_rad_values, atmospheric_rad_values, terrestrial_rad_values = (
            self._radiation_values_on_wall(wall)
        )

        # add all values up and create one Interpolator out of it
        result_values = np.sum(
            [direct_rad_values, diffuse_rad_values, atmospheric_rad_values, terrestrial_rad_values], axis=0
        )
        interpolator = PchipInterpolator(seconds, result_values, extrapolate=False)
        return lambda time, *args, **kwargs: interpolator(time % self.period)

    def get_interpolator(self, name) -> Callable:
        match name.lower():
            case "t" | "temperature" | "temp" | "exterior" | "exterior_temperature" | "exterior temperature":
                return lambda time, *args, **kwargs: self.interpolators[0](time % self.period)
            case "direct solar" | "direct radiation" | "direct solar radiation" | "direct":
                return lambda time, *args, **kwargs: self.interpolators[7](time % self.period)
            case "diffuse solar" | "diffuse radiation" | "diffuse solar radiation" | "diffuse":
                return lambda time, *args, **kwargs: self.interpolators[8](time % self.period)
            case "atmospheric" | "atmospheric radiation":
                return lambda time, *args, **kwargs: self.interpolators[9](time % self.period)
            case "terrestrial" | "terrestrial radiation" | "ground radiation" | "ambient radiation":
                return lambda time, *args, **kwargs: -1 * self.interpolators[10](time % self.period)
            case _:
                raise NotImplementedError  # implement more if needed

    def reorder_matrix_by_time(self):
        matrix = self.get_raw_data()
        times = matrix[:, self.datetime_col_index].astype(datetime)

        times_norm = np.array([dt.replace(year=1970) for dt in times])

        start_time_norm = self.start_time.replace(year=1970)

        # Find the closest index
        closest_idx = np.argmin(np.abs(times_norm - start_time_norm))

        # Reorder the matrix
        start_matrix = matrix[closest_idx:]
        end_matrix = matrix[:closest_idx]
        end_matrix[:, 0] = np.array([d.replace(year=d.year + 1) for d in end_matrix[:, 0]])
        matrix = np.concatenate((start_matrix, end_matrix), axis=0)
        time_seconds = np.array([(dt - matrix[0, 0]).total_seconds() for dt in matrix[:, 0]])
        return time_seconds, matrix


# weather_data = WeatherData(path=r"C:\path\to\dwd_data\TRY2015_523748130791_Jahr.dat",
#                            start_time="2015-01-01 00:00:00")

# if __name__ == "__main__":
#     path = os.path.normpath(r"C:\path\to\dwd_data\TRY2015_523748130791_Jahr.dat")
#     mat = load_data(path)
#     test_fun=prepare_interpolator(mat, columns=[1], start_time="2015-01-01T00:00")
#     labels = ["Temp"]
#
#     x = list(range(0,8760*3600*2, 100))
#     y = np.array([test_fun(s) for s in x])
#
#     for i in range(y.shape[1]):
#         plt.plot(np.array(x)/(3600*24),y[:,i], label=labels[i])
#     plt.show()
#
#     print("done")
