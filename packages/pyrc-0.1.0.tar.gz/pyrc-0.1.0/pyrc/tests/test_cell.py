#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

import unittest
import numpy as np
from pyrc.core.components.templates import Cell  # Replace with actual import


class TestCellPlacement(unittest.TestCase):

    def setUp(self):
        self.cell = Cell(position=np.array([0.0, 0.0, 0.0]),
                         delta=(2, 2, 2))

        # for testing of create_grid class_method
        self.grid_size = (3, 4, 5)
        self.delta = (1.5, 2.0, 2.5)
        self.grid = Cell.create_grid(self.grid_size, self.delta)

    def test_place_adjacent_x(self):
        other = Cell(position=np.array([0.0, 0.0, 0.0]),
                     delta=(2, 2, 2))
        self.cell.place_adjacent(other, "x")
        np.testing.assert_array_equal(other.position, np.array([2.0, 0.0, 0.0]))

    def test_place_adjacent_minus_x(self):
        other = Cell(position=np.array([0.0, 0.0, 0.0]),
                     delta=(2, 2, 2))
        self.cell.place_adjacent(other, "-x")
        np.testing.assert_array_equal(other.position, np.array([-2.0, 0.0, 0.0]))

    def test_place_adjacent_simple(self):
        other = Cell(position=np.array([0.0, 0.0, 0.0]),
                     delta=(2, 2, 2))
        self.cell.place_adjacent(other, "xy")
        np.testing.assert_array_equal(other.position, np.array([2.0, 2.0, 0.0]))
        other = Cell(position=np.array([0.0, 0.0, 0.0]),
                     delta=(2, 2, 2))
        self.cell.place_adjacent(other, "x-y")
        np.testing.assert_array_equal(other.position, np.array([2.0, -2.0, 0.0]))
        other = Cell(position=np.array([0.0, 0.0, 0.0]),
                     delta=(2, 2, 3))
        self.cell.place_adjacent(other, "x-yz")
        np.testing.assert_array_equal(other.position, np.array([2.0, -2.0, 2.5]))
        other = Cell(position=np.array([0.0, 0.0, 0.0]),
                     delta=(2, 2, 3))
        self.cell.place_adjacent(other, "x-y+z")
        np.testing.assert_array_equal(other.position, np.array([2.0, -2.0, 2.5]))

    def test_place_adjacent_at_vertex(self):
        other = Cell(position=np.array([0.0, 0.0, 0.0]),
                     delta=(2, 2, 2))
        self.cell.place_adjacent(other, "xyz")
        np.testing.assert_array_equal(other.position, np.array([2.0, 2.0, 2.0]))

    def test_place_adjacent_stack(self):
        other = Cell(position=np.array([0.0, 0.0, 0.0]),
                     delta=(2, 2, 2))
        self.cell.place_adjacent(other, "++x++y-z")
        np.testing.assert_array_equal(other.position, np.array([0, 0, -2.0]))
        self.cell.place_adjacent(other, "++x++yz")
        np.testing.assert_array_equal(other.position, np.array([0, 0, 2.0]))
        self.cell.place_adjacent(other, "++x++y-+z")
        np.testing.assert_array_equal(other.position, np.array([0, 0, -2.0]))

    def test_place_adjacent_with_space(self):
        other = Cell(position=np.array([0.0, 0.0, 0.0]),
                     delta=(2, 2, 2))
        self.cell.place_adjacent(other, "x -y")
        np.testing.assert_array_equal(other.position, np.array([2.0, -2.0, 0.0]))

    def test_place_adjacent_same_face(self):
        """
        This places the new cell within the other at the same position.
        """
        other = Cell(position=np.array([0.0, 0.0, 0.0]),
                     delta=(2, 2, 2))
        self.cell.place_adjacent(other, "++x")
        np.testing.assert_array_equal(other.position, np.array([0.0, 0.0, 0.0]))
        other = Cell(position=np.array([0.0, 0.0, 0.0]),
                     delta=(2, 2, 2))
        self.cell.place_adjacent(other, "--x")
        np.testing.assert_array_equal(other.position, np.array([0.0, 0.0, 0.0]))

    def test_place_adjacent_plus_minus_notation(self):
        other = Cell(position=np.array([0.0, 0.0, 0.0]),
                     delta=(2, 2, 2))
        self.cell.place_adjacent(other, "+-y")
        np.testing.assert_array_equal(other.position, np.array([0.0, 2.0, 0.0]))
        other = Cell(position=np.array([0.0, 0.0, 0.0]),
                     delta=(2, 2, 2))
        self.cell.place_adjacent(other, "-+y")
        np.testing.assert_array_equal(other.position, np.array([0.0, -2.0, 0.0]))

    def test_place_adjacent_different_sizes(self):
        other = Cell(position=np.array([0.0, 0.0, 0.0]),
                     delta=(4, 2, 2))
        self.cell.place_adjacent(other, "x")
        np.testing.assert_array_equal(other.position, np.array([3.0, 0.0, 0.0]))

    def test_place_adjacent_preserves_unaligned_coordinates(self):
        other = Cell(position=np.array([10.0, 20.0, 30.0]),
                     delta=(2, 2, 2))
        self.cell.place_adjacent(other, "x")
        np.testing.assert_array_equal(other.position, np.array([2.0, 20.0, 30.0]))

    def test_create_adjacent(self):
        new_cell = self.cell.create_adjacent("y", delta=(3.0, 3.0, 3.0))
        self.assertIsInstance(new_cell, Cell)
        np.testing.assert_array_equal(new_cell.position, np.array([0.0, 2.5, 0.0]))
        self.assertEqual(new_cell.delta_x, 3.0)

    def test_create_adjacent_with_position(self):
        new_cell = self.cell.create_adjacent("z", position=np.array([5.0, 5.0, 5.0]),
                                             delta=(2.0, 2.0, 2.0))
        np.testing.assert_array_equal(new_cell.position, np.array([5.0, 5.0, 2.0]))

    def test_create_grid_aligned(self):
        cells = self.cell.create_grid_aligned("x", (2, 2, 2), (4.0, 4.0, 4.0))
        cells = cells.flatten()
        self.assertEqual(len(cells), 8)
        self.assertIsInstance(cells[0], Cell)
        np.testing.assert_array_equal(cells[0].delta, np.array([2.0, 2.0, 2.0]))
        np.testing.assert_array_equal(cells[0].position, np.array([2.0, -1, -1]))
        np.testing.assert_array_equal(cells[1].position, np.array([2.0, -1, 1]))
        np.testing.assert_array_equal(cells[4].position, np.array([4.0, -1, -1]))

    def test_create_grid_aligned_positioning(self):
        cells: np.ndarray = self.cell.create_grid_aligned("x", (2, 1, 1), (4.0, 2.0, 2.0))
        cells = cells.flatten()
        self.assertEqual(len(cells), 2)
        np.testing.assert_array_almost_equal(cells[0].position, np.array([2.0, 0, 0.0]))
        np.testing.assert_array_almost_equal(cells[1].position, np.array([4.0, 0.0, 0.0]))

    def test_inherited_class(self):
        class SpecialCell(Cell):
            def __init__(self, position, delta, special=None):
                super().__init__(position, delta)
                self.special = special

        _special = SpecialCell(np.array([0.0, 0.0, 0.0]), (2.0, 2.0, 2.0), special=42)
        new_special = _special.create_adjacent("x", delta=(2.0, 2.0, 2.0), special=99)
        self.assertIsInstance(new_special, SpecialCell)
        self.assertEqual(new_special.special, 99)

    def test_create_grid_return_type_and_shape(self):
        """Grid has correct type and shape."""
        self.assertIsInstance(self.grid, np.ndarray)
        self.assertEqual(self.grid.shape, self.grid_size)

    def test_create_grid_all_cells_are_cell_instances(self):
        """All elements are Cell instances."""
        for cell in self.grid.flat:
            self.assertIsInstance(cell, Cell)

    def test_create_grid_cell_deltas(self):
        """Each cell has correct delta dimensions."""
        expected = np.array(self.delta) / np.array(self.grid_size)
        for cell in self.grid.flat:
            self.assertAlmostEqual(cell.delta_x, expected[0])
            self.assertAlmostEqual(cell.delta_y, expected[1])
            self.assertAlmostEqual(cell.delta_z, expected[2])

    def test_create_grid_center_position_default(self):
        """Grid center (mean of all positions) defaults to origin."""
        positions = np.array([cell.position for cell in self.grid.flat])
        np.testing.assert_allclose(positions.mean(axis=0), np.zeros(3), atol=1e-12)

    def test_create_grid_center_position_custom(self):
        """Grid center (mean of all positions) equals specified center."""
        center = np.array([1.0, 2.0, 3.0])
        grid = Cell.create_grid(self.grid_size, self.delta, center_position=center)
        positions = np.array([cell.position for cell in grid.flat])
        np.testing.assert_allclose(positions.mean(axis=0), center, atol=1e-12)

    def test_create_grid_positions_spacing(self):
        """Adjacent cells are spaced by cell deltas."""
        expected_deltas = np.array(self.delta) / np.array(self.grid_size)
        for ix in range(self.grid_size[0] - 1):
            diff = self.grid[ix + 1, 0, 0].position - self.grid[ix, 0, 0].position
            self.assertAlmostEqual(diff[0], expected_deltas[0])
        for iy in range(self.grid_size[1] - 1):
            diff = self.grid[0, iy + 1, 0].position - self.grid[0, iy, 0].position
            self.assertAlmostEqual(diff[1], expected_deltas[1])
        for iz in range(self.grid_size[2] - 1):
            diff = self.grid[0, 0, iz + 1].position - self.grid[0, 0, iz].position
            self.assertAlmostEqual(diff[2], expected_deltas[2])

    def test_create_grid_subclass_returns_subclass_instances(self):
        """Subclass call populates grid with subclass instances."""

        class SubCell(Cell):
            pass

        grid = SubCell.create_grid(self.grid_size, self.delta)
        for cell in grid.flat:
            self.assertIsInstance(cell, SubCell)


if __name__ == "__main__":
    unittest.main()
