#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

from unittest import TestCase

import numpy as np

from pyrc.core.components.resistor import Resistor
from pyrc.core.inputs import FluidBoundaryConditionGeometric
from pyrc.core.materials import Concrete
from pyrc.core.nodes import Node
from pyrc.model.facade import Facade
from pyrc.tools.science import celsius_to_kelvin


class TestNode(TestCase):
    """
    Testing basic parts.

    This test has to be changed in the future, when the solvers are up and running :P
    """

    def setUp(self):
        # setup simple case with two boundary conditions, one node in the middle and two resistors
        self.bc_outside = FluidBoundaryConditionGeometric(temperature=celsius_to_kelvin(5),
                                                          position=np.array([1, 0, 0]))
        self.bc_inside = FluidBoundaryConditionGeometric(temperature=celsius_to_kelvin(5),
                                                         position=np.array([-1, 0, 0]))

        self.node = Node(material=Concrete(),  # J/K; like 240x100x100 mm of concrete
                         temperature=celsius_to_kelvin(0),
                         position=np.array([0, 0, 0]))

        self.heat_transfer_outside = Resistor(resistance=0.45333)  # 1 W/m/K for 120 mm and alpha=3
        self.heat_transfer_inside = Resistor(resistance=0.62)  # 1 W/m/K for 120 mm and alpha=2

        # create connections
        self.bc_outside.connect(self.heat_transfer_outside)
        self.heat_transfer_outside.connect(self.node, direction=(1, 0, 0), node_direction_points_to=self.bc_outside)
        self.heat_transfer_inside.connect(self.node, direction=(-1, 0, 0), node_direction_points_to=self.bc_inside)
        self.heat_transfer_inside.connect(self.bc_inside)

    def test_connect_to_neighbour(self):
        self.assertIsInstance(self.node.neighbours[0], Resistor)
        self.assertAlmostEqual(self.node.neighbours[0].resistance, 0.45333, places=6)
        self.assertIsInstance(self.node.neighbours[1], Resistor)
        self.assertAlmostEqual(self.node.neighbours[1].resistance, 0.62, places=6)


class TestRCNetwork(TestCase):

    def setUp(self):
        self.base_case = Facade(num_cores_jacobian=1, load_from_pickle=False)
        self.base_case.settings.save_all_x_seconds = 0.5
        self.base_case.create_network()

        self.base_case_symbolic = Facade(num_cores_jacobian=1, load_from_pickle=False)
        self.base_case.settings.save_all_x_seconds = 0.5
        self.base_case.create_network()

    # def test_make_system_matrix(self):
    #     system_matrix_symbol = self.base_case.system_matrix_symbol
    #     system_matrix = self.base_case.system_matrix

    def test_solve_network(self):
        t_span = (0, 1)
        self.base_case.solve_network(t_span)
        np.testing.assert_allclose(self.base_case.rc_solution.t, np.array([0, 0.5, 1]))
        np.testing.assert_allclose(self.base_case.rc_solution.y[-1][-1], 284.15468370747436)
