#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

from unittest import TestCase

import numpy as np

from pyrc.core.inputs import FluidBoundaryConditionGeometric, InteriorBoundaryConditionGeometric
from pyrc.core.materials import Concrete, Air
from pyrc.core.nodes import Node
from pyrc.core.resistors import CombinedResistor
from pyrc.tools.science import celsius_to_kelvin


class TestCombinedResistor(TestCase):

    def setUp(self):
        # class TestNetwork(RCNetwork):
        #     def __init__(self,*args, **kwargs):
        #         super().__init__(*args, **kwargs)
        #         self.load_from_pickle = False
        #         self.save_to_pickle = False
        #         self.continue_canceled = False
        #         self.settings.save_all_x_seconds = 1
        #
        #     def _create_network(self):
        #         bc_outside = FluidBoundaryCondition(temperature=celsius_to_kelvin(5), position=np.array([1, 0, 0]),
        #                                                  heat_transfer_coefficient=4)
        #         bc_inside = InteriorBoundaryCondition(temperature=celsius_to_kelvin(5), position=np.array([0, 0, 0]),
        #                                                    heat_transfer_coefficient=3.5)
        #
        #         material = Concrete()
        #
        #         node1 = Node(material=material,  # J/K; like 240x100x100 mm of concrete
        #                           temperature=celsius_to_kelvin(0),
        #                           position=np.array([0, 0, 0]),
        #                            delta=(0.3, 0.5, 1))
        #         node2 = Node(material=material,  # J/K; like 240x100x100 mm of concrete
        #                           temperature=celsius_to_kelvin(0),
        #                           position=np.array([0.3, 0, 0]),
        #                           delta=(0.3, 0.5, 1))
        #         node3 = Node(material=material,  # J/K; like 240x100x100 mm of concrete
        #                           temperature=celsius_to_kelvin(0),
        #                           position=np.array([0.6, 0, 0]),
        #                           delta=(0.3, 0.5, 1))
        #         node4 = Node(material=Air(),  # J/K; like 240x100x100 mm of concrete
        #                           temperature=celsius_to_kelvin(0),
        #                           position=np.array([0.9, 0, 0]),
        #                           delta=(0.3, 0.5, 1))
        #         node5 = Node(material=material,  # J/K; like 240x100x100 mm of concrete
        #                           temperature=celsius_to_kelvin(0),
        #                           position=np.array([1.2, 0, 0]),
        #                           delta=(0.3, 0.5, 1))
        #
        #         heat_transfer_outside = CombinedResistor()  # 1 W/m/K for 120 mm and alpha=3
        #         heat_transfer_inside = CombinedResistor()  # 1 W/m/K for 120 mm and alpha=2
        #
        #         conduction1_2 = CombinedResistor()  # 3
        #         conduction2_3_1 = CombinedResistor()  # 4
        #         conduction2_3_2 = CombinedResistor()  # 5
        #         conduction3_4_1 = CombinedResistor()  # 6
        #         conduction3_4_2_1 = CombinedResistor()  # 7
        #         conduction3_4_2_2 = CombinedResistor(htc=13)  # 8
        #         conduction4_5_1 = CombinedResistor(htc=2)  # 9
        #         conduction4_5_2 = CombinedResistor()  # 10
        #
        #         # create connections to BCs
        #         bc_outside.connect(heat_transfer_outside)
        #         heat_transfer_outside.connect(node5, direction=(1, 0, 0), node_direction_points_to=bc_outside)
        #         node1.connect(heat_transfer_inside, direction=(-1, 0, 0), node_direction_points_to=bc_inside)
        #         heat_transfer_inside.connect(bc_inside)
        #
        #         # connect nodes
        #         conduction1_2.double_connect(node1, node2)
        #         conduction2_3_1.double_connect(node2, conduction2_3_2)
        #         conduction2_3_2.connect(node3)
        #         conduction3_4_1.double_connect(node3, conduction3_4_2_1)
        #         conduction3_4_1.connect(conduction3_4_2_2)
        #         conduction3_4_2_2.connect(node4)
        #         conduction3_4_2_1.connect(node4)
        #         conduction4_5_1.double_connect(node4, conduction4_5_2)
        #         conduction4_5_2.connect(node5)
        #
        #         self.rc_objects.set_lists(nodes=[node1, node2, node3, node4, node5],
        #                                   resistors=[
        #                                       conduction1_2,
        #                                       conduction2_3_1,
        #                                       conduction2_3_2,
        #                                       conduction3_4_1,
        #                                       conduction3_4_2_1,
        #                                       conduction3_4_2_2,
        #                                       conduction4_5_1,
        #                                       conduction4_5_2,
        #                                       heat_transfer_outside,
        #                                       heat_transfer_inside,
        #                                   ],
        #                                   boundaries=[bc_inside, bc_outside])
        #
        # self.network = TestNetwork()

        self.bc_outside = FluidBoundaryConditionGeometric(temperature=celsius_to_kelvin(5),
                                                          position=np.array([1, 0, 0]),
                                                 heat_transfer_coefficient=4)
        self.bc_inside = InteriorBoundaryConditionGeometric(temperature=celsius_to_kelvin(5),
                                                            position=np.array([0, 0, 0]),
                                                   heat_transfer_coefficient=3.5)

        material = Concrete()

        self.node1 = Node(material=material,  # J/K; like 240x100x100 mm of concrete
                          temperature=celsius_to_kelvin(0),
                          position=np.array([0, 0, 0]),
                          delta=(0.3, 0.5, 1))
        self.node2 = Node(material=material,  # J/K; like 240x100x100 mm of concrete
                          temperature=celsius_to_kelvin(0),
                          position=np.array([0.3, 0, 0]),
                          delta=(0.3, 0.5, 1))
        self.node3 = Node(material=material,  # J/K; like 240x100x100 mm of concrete
                          temperature=celsius_to_kelvin(0),
                          position=np.array([0.6, 0, 0]),
                          delta=(0.3, 0.5, 1))
        self.node4 = Node(material=Air(),  # J/K; like 240x100x100 mm of concrete
                          temperature=celsius_to_kelvin(0),
                          position=np.array([0.9, 0, 0]),
                          delta=(0.3, 0.5, 1))
        self.node5 = Node(material=material,  # J/K; like 240x100x100 mm of concrete
                          temperature=celsius_to_kelvin(0),
                          position=np.array([1.2, 0, 0]),
                          delta=(0.3, 0.5, 1))

        self.heat_transfer_outside = CombinedResistor()  # 1
        self.heat_transfer_inside = CombinedResistor()  # 1

        self.conduction1_2 = CombinedResistor()  # 3
        self.conduction2_3_1 = CombinedResistor()  # 4
        self.conduction2_3_2 = CombinedResistor()  # 5
        self.conduction3_4_1 = CombinedResistor()  # 6
        self.conduction3_4_2_1 = CombinedResistor(htc=5)  # 7
        self.conduction3_4_2_2 = CombinedResistor(htc=13)  # 8
        self.conduction4_5_1 = CombinedResistor(htc=2)  # 9
        self.conduction4_5_2 = CombinedResistor()  # 10

        # create connections to BCs
        self.bc_outside.connect(self.heat_transfer_outside)
        self.heat_transfer_outside.connect(self.node5, direction=(1, 0, 0), node_direction_points_to=self.bc_outside)
        self.node1.connect(self.heat_transfer_inside, direction=(-1, 0, 0), node_direction_points_to=self.bc_inside)
        self.heat_transfer_inside.connect(self.bc_inside)

        # connect nodes
        self.conduction1_2.double_connect(self.node1, self.node2)
        self.conduction2_3_1.double_connect(self.node2, self.conduction2_3_2)
        self.conduction2_3_2.connect(self.node3)
        self.conduction3_4_1.double_connect(self.node3, self.conduction3_4_2_1)
        self.conduction3_4_1.connect(self.conduction3_4_2_2)
        self.conduction3_4_2_2.connect(self.node4)
        self.conduction3_4_2_1.connect(self.node4)
        self.conduction4_5_1.double_connect(self.node4, self.conduction4_5_2)
        self.conduction4_5_2.connect(self.node5)

    def test_resistance(self):
        # self.network.create_network()
        # self.network.solve_network((0,10))
        self.assertAlmostEqual(self.heat_transfer_outside.resistance, 1 / (0.5 * 4) + (0.3 / 2) / (1.6 * 0.5))
        self.assertAlmostEqual(self.heat_transfer_inside.resistance, 1 / (0.5 * 3.5) + (0.3 / 2) / (1.6 * 0.5))

        conduction_resistance1_2 = (self.node1.delta_x / 2 / (
                self.node1.material.thermal_conductivity * self.node1.delta_y * self.node1.delta_z) +
                                    self.node2.delta_x / 2 / (
                                            self.node2.material.thermal_conductivity * self.node2.delta_y * self.node2.delta_z))
        self.assertAlmostEqual(self.conduction1_2.resistance, conduction_resistance1_2)
        self.assertAlmostEqual(self.conduction1_2.equivalent_resistance, conduction_resistance1_2)

        conduction_resistance2_3_1 = self.node2.delta_x / 2 / (
                self.node2.material.thermal_conductivity * self.node2.delta_y * self.node2.delta_z)
        self.assertAlmostEqual(self.conduction2_3_1.resistance, conduction_resistance2_3_1)
        conduction_resistance2_3_2 = self.node3.delta_x / 2 / (
                self.node3.material.thermal_conductivity * self.node3.delta_y *
                self.node3.delta_z)
        self.assertAlmostEqual(self.conduction2_3_2.resistance, conduction_resistance2_3_2)

        self.assertAlmostEqual(self.conduction2_3_1.equivalent_resistance,
                               conduction_resistance2_3_1 + conduction_resistance2_3_2)
        self.assertAlmostEqual(self.conduction2_3_2.equivalent_resistance,
                               conduction_resistance2_3_1 + conduction_resistance2_3_2)

        conduction_resistance3_4_1 = self.node3.delta_x / 2 / (
                self.node3.material.thermal_conductivity * self.node3.delta_y * self.node3.delta_z)
        conduction_resistance3_4_2_1 = 1 / (
                self.conduction3_4_2_1.htc * self.node4.delta_y * self.node4.delta_z)
        conduction_resistance3_4_2_2 = 1 / (
                self.conduction3_4_2_2.htc * self.node4.delta_y * self.node4.delta_z)
        conduction_resistance3_4_2 = 1 / (1 / conduction_resistance3_4_2_1 + 1 / conduction_resistance3_4_2_2)
        self.assertAlmostEqual(self.conduction3_4_1.equivalent_resistance,
                               conduction_resistance3_4_1 + conduction_resistance3_4_2)
        self.assertAlmostEqual(self.conduction3_4_2_1.equivalent_resistance,
                               conduction_resistance3_4_1 + conduction_resistance3_4_2)
        self.assertAlmostEqual(self.conduction3_4_2_2.equivalent_resistance,
                               conduction_resistance3_4_1 + conduction_resistance3_4_2)

        conduction_resistance4_5_1 = 1 / (
                self.conduction4_5_1.htc * self.node4.delta_y * self.node4.delta_z)
        conduction_resistance4_5_2 = self.node5.delta_x / 2 / (
                self.node5.material.thermal_conductivity * self.node5.delta_y * self.node5.delta_z)
        self.assertAlmostEqual(self.conduction4_5_1.equivalent_resistance,
                               conduction_resistance4_5_1 + conduction_resistance4_5_2)
