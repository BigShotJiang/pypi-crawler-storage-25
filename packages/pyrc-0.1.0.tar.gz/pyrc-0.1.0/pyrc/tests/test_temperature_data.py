#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

import numpy as np
from scipy.interpolate import CubicSpline, PchipInterpolator
from scipy.optimize import minimize
import matplotlib.pyplot as plt


def smooth_hourly_data(times, hourly_values, mean_measured_flags):
    times = np.asarray(times)
    hourly_values = np.asarray(hourly_values)

    mid_times = (times[:-1] + times[1:]) / 2
    init_guess = np.interp(mid_times, times, hourly_values)

    def objective(mid_vals):
        all_times = np.concatenate([times, mid_times])
        all_vals = np.concatenate([hourly_values, mid_vals])
        sort_idx = np.argsort(all_times)
        spline = CubicSpline(all_times[sort_idx], all_vals[sort_idx])

        integral_means = np.array([
            spline.integrate(times[i], times[i + 1]) / (times[i + 1] - times[i])
            for i in range(len(hourly_values) - 1)
        ])
        residual = integral_means - hourly_values[1:]
        residual[~mean_measured_flags] = 0
        return np.sum(residual ** 2)

    result = minimize(objective, init_guess, method="L-BFGS-B")
    optimized_mid_vals = result.x

    all_times_final = np.concatenate([times, mid_times])
    all_vals_final = np.concatenate([hourly_values, optimized_mid_vals])
    sort_idx_final = np.argsort(all_times_final)
    final_spline = CubicSpline(all_times_final[sort_idx_final], all_vals_final[sort_idx_final])

    return final_spline


# Example usage:
if __name__ == '__main__':
    _times = np.arange(0, 24)  # hourly from 0 to 24
    times_shifted = _times - 0.5
    _hourly_values = np.array([
        16.2,
        17.2,
        17.4,
        17.1,
        16.6,
        16.0,
        16.1,
        17.1,
        17.4,
        17.9,
        19.4,
        22.2,
        23.1,
        23.3,
        24.6,
        25.4,
        25.9,
        26.0,
        25.9,
        23.8,
        22.8,
        21.1,
        20.2,
        19.3,
    ])
    _mean_measured_flags = np.zeros(24, dtype=bool)  # True for hourly mean, False for snapshots

    # Compute spline
    my_splint = PchipInterpolator(times_shifted, _hourly_values)
    # interp_func = smooth_hourly_data(_times, _hourly_values, _mean_measured_flags)

    # Fine resolution for smooth plot
    fine_times = np.linspace(times_shifted[0], times_shifted[-1], 500)
    smooth_values = my_splint(fine_times)

    # Plot
    plt.figure(figsize=(10, 5))
    plt.plot(fine_times, smooth_values, label="Spline interpolation")
    plt.step(_times, _hourly_values, where="pre", label="Hourly mean values", color="r")
    # plt.scatter(_times, _hourly_values, color="r", zorder=5)
    plt.xlabel("Time (hours)")
    plt.ylabel("Value")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()
