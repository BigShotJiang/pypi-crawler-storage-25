#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

from unittest import TestCase

import numpy as np
from sympy import SparseMatrix, Symbol, sin, cos
from pyrc.core.solver.symbolic import SparseSymbolicEvaluator

t, w = Symbol("t"), Symbol("w")


class TestSparseSymbolicEvaluator(TestCase):

    def test_constant_matrix(self):
        """Matrix with only constant entries evaluates correctly."""
        M = SparseMatrix(3, 3, {(0, 0): 1.0, (1, 2): 3.0, (2, 1): -2.0})
        ev = SparseSymbolicEvaluator(M, [])
        result = ev.evaluate()
        expected = np.array([[1, 0, 0], [0, 0, 3], [0, -2, 0]], dtype=float)
        np.testing.assert_allclose(result.toarray(), expected)

    def test_symbolic_single_entry(self):
        """Single symbolic entry is evaluated and placed correctly alongside a constant."""
        M = SparseMatrix(2, 2, {(0, 0): t, (1, 1): 2.0})
        ev = SparseSymbolicEvaluator(M, [t])
        result = ev.evaluate(np.array([3.0]))
        expected = np.array([[3.0, 0], [0, 2.0]])
        np.testing.assert_allclose(result.toarray(), expected)

    def test_symbolic_multiple_symbols(self):
        """Multiple symbols in multiple entries are evaluated correctly."""
        M = SparseMatrix(2, 2, {(0, 0): t + w, (0, 1): w, (1, 0): t})
        ev = SparseSymbolicEvaluator(M, [t, w])
        result = ev.evaluate(np.array([1.0, 2.0]))
        expected = np.array([[3.0, 2.0], [1.0, 0.0]])
        np.testing.assert_allclose(result.toarray(), expected)

    def test_nonlinear_expression(self):
        """Nonlinear symbolic expressions (sin, cos) are evaluated correctly."""
        M = SparseMatrix(2, 2, {(0, 0): sin(t), (1, 1): cos(t)})
        ev = SparseSymbolicEvaluator(M, [t])
        val = np.pi / 4
        result = ev.evaluate(np.array([val]))
        expected = np.array([[np.sin(val), 0], [0, np.cos(val)]])
        np.testing.assert_allclose(result.toarray(), expected)

    def test_mixed_constant_and_symbolic(self):
        """Matrix with mixed constant and symbolic entries evaluates correctly."""
        M = SparseMatrix(2, 2, {(0, 0): t, (0, 1): 5.0, (1, 1): w})
        ev = SparseSymbolicEvaluator(M, [t, w])
        result = ev.evaluate(np.array([2.0, -1.0]))
        expected = np.array([[2.0, 5.0], [0.0, -1.0]])
        np.testing.assert_allclose(result.toarray(), expected)

    def test_working_matrix_not_modified_between_calls(self):
        """Consecutive calls with different values return correct results without state leakage."""
        M = SparseMatrix(2, 2, {(0, 0): t})
        ev = SparseSymbolicEvaluator(M, [t])
        ev.evaluate(np.array([10.0]))
        result = ev.evaluate(np.array([3.0]))
        expected = np.array([[3.0, 0], [0, 0.0]])
        np.testing.assert_allclose(result.toarray(), expected)

    def test_empty_matrix(self):
        """Matrix with no nonzero entries returns a zero matrix."""
        M = SparseMatrix(3, 3, {})
        ev = SparseSymbolicEvaluator(M, [t])
        result = ev.evaluate(np.array([1.0]))
        np.testing.assert_allclose(result.toarray(), np.zeros((3, 3)))

    def test_shape(self):
        """Evaluator and output matrix have the correct shape."""
        M = SparseMatrix(4, 6, {(0, 0): t, (3, 5): 1.0})
        ev = SparseSymbolicEvaluator(M, [t])
        self.assertEqual(ev.shape, (4, 6))
        self.assertEqual(ev.evaluate(np.array([1.0])).shape, (4, 6))

    def test_large_sparse_matrix(self):
        """Random 1000x1000 sparse matrix with ~20 entries per row, mixed constant and symbolic, evaluates correctly."""
        rng = np.random.default_rng(42)
        n = 1000
        entries_per_row = 20
        M_dict = {}
        expected = np.zeros((n, n))

        t_val, w_val = 2.5, -1.3

        for i in range(n):
            cols = rng.choice(n, size=entries_per_row, replace=False)
            for j in cols:
                if rng.random() < 0.5:
                    val = rng.uniform(-10, 10)
                    M_dict[(i, int(j))] = val
                    expected[i, int(j)] += val
                elif rng.random() < 0.5:
                    M_dict[(i, int(j))] = t
                    expected[i, int(j)] += t_val
                else:
                    M_dict[(i, int(j))] = w
                    expected[i, int(j)] += w_val

        M = SparseMatrix(n, n, M_dict)
        ev = SparseSymbolicEvaluator(M, [t, w])
        result = ev.evaluate(np.array([t_val, w_val]))
        np.testing.assert_allclose(result.toarray(), expected)
