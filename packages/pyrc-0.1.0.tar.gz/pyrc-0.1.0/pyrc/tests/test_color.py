#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

import unittest
import numpy as np
from pyrc.core.visualization.color.color import available, value_to_rgb, make_color_mapper, get_palette, cycle_palette, \
    CMAPS


class TestColormap(unittest.TestCase):

    def _first_of_kind(self, kind: str) -> str | None:
        """Return the first colormap name of the given kind, or None."""
        names = available(kind)
        return names[0] if names else None

    def test_colormaps_loaded(self):
        """At least one colormap is discovered and loaded at import time."""
        names = available()
        self.assertIsInstance(names, tuple)
        self.assertGreater(len(names), 0)

    def test_available_filter_uniform(self):
        """available('uniform') returns only uniform-kind entries."""
        names = available("uniform")
        self.assertTrue(all(CMAPS[n][0] == "uniform" for n in names))

    def test_available_filter_discrete(self):
        """available('discrete') returns only discrete-kind entries."""
        names = available("discrete")
        self.assertTrue(all(CMAPS[n][0] == "discrete" for n in names))

    def test_available_filter_explicit(self):
        """available('explicit') returns only explicit-kind entries."""
        names = available("explicit")
        self.assertTrue(all(CMAPS[n][0] == "explicit" for n in names))

    def test_value_to_rgb_shape_and_range_scalar(self):
        """Scalar input yields shape (3,) float32 in [0, 1]."""
        cmap = self._first_of_kind("uniform") or self._first_of_kind("explicit")
        if cmap is None:
            self.skipTest("No gradient colormap available")
        rgb = value_to_rgb(0.5, cmap=cmap)
        self.assertEqual(rgb.shape, (3,))
        self.assertEqual(rgb.dtype, np.float32)
        self.assertTrue(np.all(np.isfinite(rgb)))
        self.assertTrue(np.all((rgb >= 0.0) & (rgb <= 1.0)))

    def test_value_to_rgb_shape_vector(self):
        """Vector input of length N yields shape (N, 3) float32."""
        cmap = self._first_of_kind("uniform") or self._first_of_kind("explicit")
        if cmap is None:
            self.skipTest("No gradient colormap available")
        v = np.array([0.0, 0.25, 0.5, 0.75, 1.0], dtype=np.float32)
        rgb = value_to_rgb(v, cmap=cmap)
        self.assertEqual(rgb.shape, (5, 3))
        self.assertEqual(rgb.dtype, np.float32)
        self.assertTrue(np.all(np.isfinite(rgb)))

    def test_clipping(self):
        """Values outside [0, 1] are clipped to the boundary colours."""
        cmap = self._first_of_kind("uniform") or self._first_of_kind("explicit")
        if cmap is None:
            self.skipTest("No gradient colormap available")
        self.assertTrue(np.allclose(value_to_rgb(-123.0, cmap=cmap), value_to_rgb(0.0, cmap=cmap)))
        self.assertTrue(np.allclose(value_to_rgb(999.0, cmap=cmap), value_to_rgb(1.0, cmap=cmap)))

    def test_make_mapper(self):
        """make_color_mapper returns a callable producing correct output shape."""
        cmap = self._first_of_kind("uniform") or self._first_of_kind("explicit")
        if cmap is None:
            self.skipTest("No gradient colormap available")
        f = make_color_mapper(cmap)
        self.assertEqual(f(np.array([0.1, 0.2], dtype=np.float32)).shape, (2, 3))

    def test_deterministic(self):
        """Identical inputs always produce identical RGB outputs."""
        cmap = self._first_of_kind("uniform") or self._first_of_kind("explicit")
        if cmap is None:
            self.skipTest("No gradient colormap available")
        v = np.linspace(0, 1, 11, dtype=np.float32)
        self.assertTrue(np.array_equal(value_to_rgb(v, cmap=cmap), value_to_rgb(v, cmap=cmap)))

    def test_endpoints_uniform(self):
        """v=0 and v=1 map exactly to the first and last table rows."""
        cmap = self._first_of_kind("uniform")
        if cmap is None:
            self.skipTest("No uniform colormap available")
        rgb_table = CMAPS[cmap][1]
        self.assertTrue(np.allclose(value_to_rgb(0.0, cmap=cmap), rgb_table[0]))
        self.assertTrue(np.allclose(value_to_rgb(1.0, cmap=cmap), rgb_table[-1]))

    def test_unknown_cmap_raises(self):
        """Requesting an unknown colormap name raises KeyError."""
        with self.assertRaises(KeyError):
            value_to_rgb(0.5, cmap="__does_not_exist__")

    def test_get_palette_shape_and_range(self):
        """Discrete palette is a finite (N, 3) float32 array in [0, 1]."""
        cmap = self._first_of_kind("discrete")
        if cmap is None:
            self.skipTest("No discrete palette available")
        palette = get_palette(cmap)
        self.assertIsInstance(palette, np.ndarray)
        self.assertEqual(palette.ndim, 2)
        self.assertEqual(palette.shape[1], 3)
        self.assertEqual(palette.dtype, np.float32)
        self.assertTrue(np.all((palette >= 0.0) & (palette <= 1.0)))

    def test_get_palette_raises_for_gradient(self):
        """get_palette raises TypeError when called on a gradient colormap."""
        cmap = self._first_of_kind("uniform") or self._first_of_kind("explicit")
        if cmap is None:
            self.skipTest("No gradient colormap available")
        with self.assertRaises(TypeError):
            get_palette(cmap)

    def test_get_palette_raises_unknown(self):
        """get_palette raises KeyError for an unknown colormap name."""
        with self.assertRaises(KeyError):
            get_palette("__does_not_exist__")

    def test_cycle_palette_discrete_yields_correct_colors(self):
        """Generator yields palette swatches in file order."""
        cmap = self._first_of_kind("discrete")
        if cmap is None:
            self.skipTest("No discrete palette available")
        palette = get_palette(cmap)
        gen = cycle_palette(cmap)
        for expected in palette:
            self.assertTrue(np.array_equal(next(gen), expected))

    def test_cycle_palette_discrete_wraps(self):
        """After exhausting all swatches the generator restarts from the first."""
        cmap = self._first_of_kind("discrete")
        if cmap is None:
            self.skipTest("No discrete palette available")
        n = get_palette(cmap).shape[0]
        gen = cycle_palette(cmap)
        first = next(gen).copy()
        for _ in range(n - 1):
            next(gen)
        self.assertTrue(np.array_equal(next(gen), first))

    def test_cycle_palette_uniform_yields_correct_colors(self):
        """Generator yields uniform table rows in order."""
        cmap = self._first_of_kind("uniform")
        if cmap is None:
            self.skipTest("No uniform colormap available")
        rgb_table = CMAPS[cmap][1]
        gen = cycle_palette(cmap)
        for expected in rgb_table:
            self.assertTrue(np.array_equal(next(gen), expected))

    def test_cycle_palette_uniform_wraps(self):
        """After exhausting all table rows the generator restarts from the first."""
        cmap = self._first_of_kind("uniform")
        if cmap is None:
            self.skipTest("No uniform colormap available")
        n = CMAPS[cmap][1].shape[0]
        gen = cycle_palette(cmap)
        first = next(gen).copy()
        for _ in range(n - 1):
            next(gen)
        self.assertTrue(np.array_equal(next(gen), first))

    def test_cycle_palette_yields_float32(self):
        """Each value yielded by the generator has dtype float32."""
        cmap = self._first_of_kind("discrete") or self._first_of_kind("uniform")
        if cmap is None:
            self.skipTest("No colormap available")
        self.assertEqual(next(cycle_palette(cmap)).dtype, np.float32)

    def test_cycle_palette_unknown_raises(self):
        """cycle_palette raises KeyError for an unknown colormap name."""
        with self.assertRaises(KeyError):
            next(cycle_palette("__does_not_exist__"))


if __name__ == "__main__":
    unittest.main()
