#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

from typing import Any

import numpy as np

from pyrc.core.inputs import Radiation, ExteriorBoundaryConditionGeometric, InteriorBoundaryConditionGeometric
from pyrc.core.materials import Air, Plaster, SandLimeBrick, EPS032
from pyrc.core.network import RCNetwork
from pyrc.core.nodes import Node, MassFlowNode
from pyrc.core.resistors import HeatConduction, MassTransport, HeatTransfer
from pyrc.tools.science import celsius_to_kelvin


class Facade(RCNetwork):

    def __init__(self,
                 *args,
                 height=0.5,
                 length=11,
                 nodes_in_length=1,
                 nodes_in_height=1,
                 one_y_node_z_layer_indexes: list | Any = None,
                 ambient_htc: float | int = 7,
                 interior_htc: float | int = 10,
                 specific_power_in_w_per_meter_squared: float | int = 200,
                 **kwargs):
        """
        A Facade RC network to simulate different wall layers.

        #TODO: update, because a lot of new algorithms make the build up easier and faster since this model was created

        Parameters
        ----------
        args : list
            The arguments for `RCNetwork` .
        one_y_node_z_layer_indexes : list | Any, optional
            A list with z layer indexes where only one y node should be applied.
            The numbers must match the indexes of the z_list (layers list).
            This is used to minimize the number of nodes in the network where it is not necessary to resolve in this
            detail.
            Currently, it is only working when the region is at the end of the layer (and maybe at the beginning).
            So, using [n-2, n-1, n] is working, but not [n-3, n-2, n-1] because the last layer is not chosen.
            To implement it properly the connection between the layers must be modified.
        ambient_htc : float | int, optional
            The heat transfer coefficient on the outer wall surface.
        interior_htc : float | int, optional
            The heat transfer coefficient on the inner wall surface.
        specific_power_in_w_per_meter_squared : float | int, optional
            The specific power in W/m^2 squared of all Radiation objects.
            Only used when weather data is not used.
        kwargs
        """
        super().__init__(*args, **kwargs)
        self.air = Air()
        self.plaster = Plaster()
        self.eps = EPS032()
        sand_lime_brick = SandLimeBrick()

        # At these layers only one node is used for the y direction.
        # Used to minimize the number of nodes in the network and fasten calculation.
        if one_y_node_z_layer_indexes is None:
            one_y_node_z_layer_indexes = []
        self.one_y_node_z_layer_indexes = one_y_node_z_layer_indexes
        self.layers = [
            0.001,
            0.003,
            0.1,
            0.1,
            0.1,
            0.05,
            0.05,
            0.075,
            0.016
        ]
        self.materials = [
            self.plaster,
            self.plaster,
            self.eps,
            self.eps,
            self.eps,
            sand_lime_brick,
            sand_lime_brick,
            sand_lime_brick,
            self.plaster
        ]

        self.height = height
        self.length = length
        self.nodes_in_length = nodes_in_length
        self.nodes_in_height = nodes_in_height

        self.ambient_htc = ambient_htc  # W/m/m/K
        self.interior_htc = interior_htc  # W/m/m/K

        # initial values, only used if weather data is not used
        self.ambient_temperature = celsius_to_kelvin(-11)
        self.interior_temperature = celsius_to_kelvin(20)
        self.initial_solid_temperature = celsius_to_kelvin(11)
        self.initial_fluid_temperature = celsius_to_kelvin(-11)
        self.specific_power_in_w_per_meter_squared = specific_power_in_w_per_meter_squared

        self.epsilon_short = 0.7

    def _create_network(self):
        # define thicknesses
        layers = self.layers
        materials = self.materials

        ambient_temperature = self.ambient_temperature

        interior_temperature = self.interior_temperature

        initial_solid_temperature = self.initial_solid_temperature

        # make lengths lists for subgroup
        x_list = [self.length / self.nodes_in_length] * self.nodes_in_length
        y_list = [self.height / self.nodes_in_height] * self.nodes_in_height
        z_list = layers

        y_height = self.height

        # build up the network, starting with the upper right corner as 0,0,0
        # place cells
        subgroup_nodes: list = [[[None for _ in range(len(z_list))] for _ in range(len(y_list))] for _ in
                                range(len(x_list))]

        # first cell is positioned on 0, so the middle is shifted by the first height/2
        y_pos = y_height / 2 - y_list[0] / 2
        for zi, z in enumerate(z_list):
            if zi == 0:
                if 0 in self.one_y_node_z_layer_indexes:
                    # Radiation to every outer node
                    for xi, x in enumerate(x_list):
                        subgroup_nodes[xi][0][zi] = Node(
                            material=materials[zi],
                            temperature=initial_solid_temperature,
                            internal_heat_source=True,
                            internal_heat_source_type=Radiation,
                            position=np.array([
                                lengths_to_position(x_list, xi),
                                y_pos,
                                lengths_to_position(z_list, zi)
                            ]),
                            delta=(x, y_height, z),
                            specific_power_in_w_per_meter_squared=self.specific_power_in_w_per_meter_squared,
                            area_direction=np.array([0, 0, -1]),
                            settings=self.settings,
                            rc_objects=self.rc_objects,
                            rc_solution=self.rc_solution,
                            epsilon_short=self.epsilon_short
                        )
                else:
                    for yi, y in enumerate(y_list):
                        # Radiation to every outer node
                        for xi, x in enumerate(x_list):
                            subgroup_nodes[xi][yi][zi] = Node(
                                material=materials[zi],
                                temperature=initial_solid_temperature,
                                internal_heat_source=True,
                                internal_heat_source_type=Radiation,
                                position=np.array([
                                    lengths_to_position(x_list, xi),
                                    lengths_to_position(y_list, yi),
                                    lengths_to_position(z_list, zi)
                                ]),
                                delta=(x, y, z),
                                specific_power_in_w_per_meter_squared=self.specific_power_in_w_per_meter_squared,
                                area_direction=np.array([0, 0, -1]),
                                settings=self.settings,
                                rc_objects=self.rc_objects,
                                rc_solution=self.rc_solution,
                                epsilon_short=self.epsilon_short
                            )
            elif zi not in self.one_y_node_z_layer_indexes:
                for yi, y in enumerate(y_list):
                    for xi, x in enumerate(x_list):
                        subgroup_nodes[xi][yi][zi] = Node(
                            material=materials[zi],
                            temperature=initial_solid_temperature,
                            position=np.array([
                                lengths_to_position(x_list, xi),
                                lengths_to_position(y_list, yi),
                                lengths_to_position(z_list, zi)
                            ]),
                            delta=(x, y, z),
                            rc_objects=self.rc_objects,
                            rc_solution=self.rc_solution,
                        )
            else:  # only one node over y direction
                for xi, x in enumerate(x_list):
                    subgroup_nodes[xi][0][zi] = Node(
                        material=materials[zi],
                        temperature=initial_solid_temperature,
                        position=np.array([
                            lengths_to_position(x_list, xi),
                            y_pos,
                            lengths_to_position(z_list, zi)
                        ]),
                        delta=(x, y_height, z),
                        rc_objects=self.rc_objects,
                        rc_solution=self.rc_solution,
                    )

        nodes_list = [
            x
            for xss in subgroup_nodes
            for xs in xss
            for x in xs
            if x is not None
        ]
        boundaries_list: list = []

        distance_bc_to_wall = 0.3
        # add boundary conditions
        bc_outer_position = 0.5 * (
                subgroup_nodes[-1][0][0].position - get_last_y_node(subgroup_nodes, 0, -1, 0).position) + np.array(
            [0, 0, -distance_bc_to_wall]) + get_last_y_node(subgroup_nodes, 0, -1, 0).position
        bc_outer = ExteriorBoundaryConditionGeometric(
            temperature=ambient_temperature,
            position=bc_outer_position,
            is_mass_flow_start=False,
            heat_transfer_coefficient=self.ambient_htc,
            temperature_delta=10,
            middle_temperature=celsius_to_kelvin(-5),
            settings=self.settings,
            rc_objects=self.rc_objects,
            rc_solution=self.rc_solution,
        )
        boundaries_list.append(bc_outer)

        bc_inner_position = (
                0.5 * (subgroup_nodes[-1][0][-1].position - get_last_y_node(subgroup_nodes, 0, -1,
                                                                            -1).position) + np.array(
            [0, 0, distance_bc_to_wall]) + get_last_y_node(subgroup_nodes, 0, -1, -1).position)
        bc_inner = InteriorBoundaryConditionGeometric(
            temperature=interior_temperature,
            position=bc_inner_position,
            is_mass_flow_start=False,
            heat_transfer_coefficient=self.interior_htc,
            settings=self.settings,
            rc_objects=self.rc_objects,
            rc_solution=self.rc_solution,
        )
        boundaries_list.append(bc_inner)

        # region Create Resistors and connect them to the nodes.

        # initialize lists for resistors
        resistors = []
        # connect all nodes
        for x in range(len(x_list) - 1):
            for y in range(len(y_list)):
                for z in range(len(z_list)):
                    node1 = subgroup_nodes[x][y][z]
                    node2 = subgroup_nodes[x + 1][y][z]
                    if node1 is None or node2 is None:
                        continue
                    resistors.append(HeatConduction())

                    # connect it to the nodes
                    resistors[-1].connect(node1)
                    resistors[-1].connect(node2)

                    # check if also other resistors must be added.
                    if (isinstance(node2, MassFlowNode) and
                            isinstance(node1, MassFlowNode)):
                        resistors.append(MassTransport())

                        # connect it to the nodes
                        resistors[-1].connect(node1)
                        resistors[-1].connect(node2)
                        resistors[-1].source = node1
                        resistors[-1].sink = node2

        # walk over y-axis
        for y in range(len(y_list) - 1):
            for x in range(len(x_list)):
                for z in range(len(z_list)):
                    node1 = subgroup_nodes[x][y][z]
                    node2 = subgroup_nodes[x][y + 1][z]
                    if node1 is None or node2 is None:
                        continue
                    resistors.append(HeatConduction())

                    # connect it to the nodes
                    resistors[-1].connect(node1)
                    resistors[-1].connect(node2)

                    # check if also other resistors must be added.
                    if (isinstance(node2, MassFlowNode) or
                            isinstance(node1, MassFlowNode)):
                        resistors.append(HeatTransfer())

                        # connect it to the nodes
                        resistors[-1].connect(node1)
                        resistors[-1].connect(node2)

        # walk over z-axis
        for z in range(len(z_list) - 1):
            for x in range(len(x_list)):
                for y in range(len(y_list)):
                    node1 = subgroup_nodes[x][y][z]
                    node2 = subgroup_nodes[x][y][z + 1]
                    if node1 is None and node2 is None:
                        continue
                    elif node1 is None:
                        # only node1 is None
                        node1 = get_last_y_node(subgroup_nodes, x, y, z)
                    elif node2 is None:
                        node2 = get_last_y_node(subgroup_nodes, x, y, z + 1)
                    resistors.append(HeatConduction())

                    # connect it to the nodes
                    resistors[-1].connect(node1)
                    resistors[-1].connect(node2)

                    # check if also other resistors must be added.
                    if (isinstance(node2, MassFlowNode) or
                            isinstance(node1, MassFlowNode)):
                        resistors.append(HeatTransfer())

                        # connect it to the nodes
                        resistors[-1].connect(node1)
                        resistors[-1].connect(node2)

        # connect front/back nodes  (to bc outer/inner)
        for x, y in zip(*[range(len(x_list))] * 2):
            for z, bc, direction in [(0, bc_outer, (0, 0, -1)), (-1, bc_inner, (0, 0, 1))]:
                node: Node = subgroup_nodes[x][y][z]
                if node is None:
                    continue
                resistors.append(HeatTransfer())
                resistors[-1].connect(node, direction=direction, node_direction_points_to=bc)
                resistors[-1].connect(bc)

        # endregion

        self.rc_objects.set_lists(capacitors=nodes_list, resistors=resistors, boundaries=boundaries_list)

        # create some groups to use them later for postprocessing
        self.groups[f"layers"] = [
            [[item for b in subgroup_nodes[l] for item in b if item is not None] for l in range(len(x_list))],
            [[item for a in subgroup_nodes for item in a[l] if item is not None] for l in range(len(y_list))],
            [[item[l] for a in subgroup_nodes for item in a if (item is not None and item[l] is not None)] for l in
             range(
                 len(z_list))],
        ]
        self.groups["outer_layer"] = [z_list[0] for y_list in subgroup_nodes for z_list in y_list if
                                      z_list[0] is not None]
        self.groups["inner_layer"] = [z_list[-1] for y_list in subgroup_nodes for z_list in y_list if
                                      z_list[-1] is not None]
        self.groups["flux_bcs"] = [bc_outer, bc_inner]
        self.groups["internal_heat_sources"] = [ihc.internal_heat_source for ihc in nodes_list if
                                                ihc is not None and
                                                ihc.internal_heat_source is not None]

        print(f"Number nodes: {len(nodes_list)}")
        print(f"Number resistors: {len(resistors)}")


def get_last_y_object(nodes: list, x, z) -> Node:
    y = len(nodes) - 1
    last_element = nodes[x][y][z]
    while last_element is None and y > 0:
        y -= 1
        last_element = nodes[x][y][z]
    return last_element


def get_last_y_node(nodes: list, x, y, z) -> Node:
    """
    Returns the node that is the last of the y direction.

    E.g. if only one node is created in y direction but other x-z-layers have more y-nodes, the single node is stored in
    index 0. It is returned instead of the None value in the nodes list.

    Correcter way would be to check, which node is the neighbour by using position and delta values, but it is
    heavier to calculate.

    Parameters
    ----------
    nodes
    x
    y
    z

    Returns
    -------

    """
    y = y + len(nodes[x]) if y <= 0 else y
    node = nodes[x][y][z]
    y_counter = y
    while node is None and y_counter > 0:
        y_counter -= 1
        node = nodes[x][y_counter][z]
    while node is None and y < len(nodes) - 1:
        # if not working, search in positive direction for a node and take it.
        y += 1
        node = nodes[x][y][z]
    return node


def lengths_to_position(the_list: list, index: int):
    if index == 0:
        return 0

    length = the_list[index] / 2 + the_list[0] / 2

    # sum all lengths up that lay between 0 and index:
    for i in range(1, index):
        length += the_list[i]

    return length
