#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

from copy import copy

from pyrc.core.connecting import connect_cells_with_resistors
from pyrc.core.materials import *
from pyrc.core.network import RCNetwork
from pyrc.core.nodes import Node
from pyrc.core.visualization.viewer import Viewer
from pyrc.core.visualization.vpython import color_cells_by_attribute
from pyrc.tools.science import celsius_to_kelvin


def clamp(n, smallest, largest):
    return max(smallest, min(n, largest))


class Office(RCNetwork):

    def __init__(self,
                 *args,
                 **kwargs):
        """
        Parameters
        ----------
        args : list
            The arguments for `RCNetwork` .
        kwargs : dict
            Keyword arguments for `RCNetwork` .
        """
        super().__init__(*args, **kwargs)
        self.outer_alpha = 25  # ISO 10292 chapter 8
        self.inner_alpha = 7.3  # ISO 10292 chapter 8

        self.bricks = Clinker()

    def _create_network(self):
        nodes = []

        def get_node(**kwargs):
            my_kwargs = {
                "material": Air(),
                "temperature": celsius_to_kelvin(20),
                "position": (0, 0, 0),
                "delta": (1, 1, 1),
                "rc_objects": self.rc_objects,
                "rc_solution": self.rc_solution,
            }
            my_kwargs.update(kwargs)
            return Node(**my_kwargs)

        wall_west = Node(
            material=WoodWall(),
            temperature=celsius_to_kelvin(20),
            position=(5.520 / 2, 0.115 / 2, 2.750 / 2),
            delta=(5.520, 0.115, 2.750),
            rc_objects=self.rc_objects,
            rc_solution=self.rc_solution,
        )
        nodes.append(wall_west)

        wall_north = Node(
            material=self.bricks,
            temperature=celsius_to_kelvin(20),
            position=(0, 0, 0),
            delta=(0.115, 2.620, 2.060),
            rc_objects=self.rc_objects,
            rc_solution=self.rc_solution,
        )
        wall_west.place_adjacent(wall_north, "--xy--z")
        nodes.append(wall_north)

        door = Node(
            material=Wood(),
            temperature=celsius_to_kelvin(20),
            position=(0, 0, 0),
            delta=(0.040, 0.910, 2.035),
            rc_objects=self.rc_objects,
            rc_solution=self.rc_solution,
        )
        wall_north.place_adjacent(door, "++xy--z")
        nodes.append(door)

        over_door = Node(
            material=self.bricks,
            temperature=celsius_to_kelvin(20),
            position=(0, 0, 0),
            delta=(0.115, 0.910, 0.025),
            rc_objects=self.rc_objects,
            rc_solution=self.rc_solution,
        )
        door.place_adjacent(over_door, "++x--yz")
        nodes.append(over_door)

        wall_north_top = Node(
            material=self.bricks,
            temperature=celsius_to_kelvin(20),
            position=(0, 0, 0),
            delta=(0.115, 6.265, 0.190),
            rc_objects=self.rc_objects,
            rc_solution=self.rc_solution,
        )
        wall_west.place_adjacent(wall_north_top, "--xy++z")
        nodes.append(wall_north_top)

        air_door = get_node(delta=(0.075, 0.91, 2.035))
        door.place_adjacent(air_door, "-x--y--z")
        nodes.append(air_door)

        wall_north_east = get_node(delta=(0.115, 2.735, 2.06), material=WoodWall())
        air_door.place_adjacent(wall_north_east, "--xy--z")
        nodes.append(wall_north_east)

        window_hallway = get_node(delta=(0.115, 6.265, 0.5), material=WindowHallway())
        wall_north.place_adjacent(window_hallway, "--x--yz")
        nodes.append(window_hallway)

        wall_east = get_node(material=self.bricks, delta=(5.520, 0.325, 2.750))
        wall_north_east.place_adjacent(wall_east, "--xy--z")
        nodes.append(wall_east)

        air_node = get_node(delta=(4.88, 6.265, 2.75))
        wall_north.place_adjacent(air_node, "x--y--z")
        nodes.append(air_node)

        class Window:
            def __init__(self,
                         place_node,
                         alignment_string,
                         glass_width=1.99,
                         glass_height=1.58,
                         frame_width=0.16,
                         air_thickness: float | int = 0.44,
                         ):
                """
                Adds a Windows to the Office including the air in front of it.

                Parameters
                ----------
                place_node : Node
                    The Node on which the top of the frame is aligned to.
                alignment_string : str
                    The alignment string how the top of the window frame is aligned to the place_node.
                glass_width : float | int, optional
                    The glass width (without the frame!)
                glass_height : float | int, optional
                    The glass height (without the frame!)
                frame_width : float | int, optional
                    The frame width.
                air_thickness : float | int, optional
                    Thickness of the air that should be added in front of the Window (inside the room).
                """
                nonlocal nodes
                self.window_height = (glass_height + 2 * frame_width)
                self.window_width = (glass_width + 2 * frame_width)

                self.frame_top = get_node(delta=(0.085, self.window_width, frame_width), material=WindowFrame())
                place_node.place_adjacent(self.frame_top, alignment_string)
                nodes.append(self.frame_top)

                self.frame_west = get_node(delta=(0.085, frame_width, glass_height), material=WindowFrame())
                self.frame_top.place_adjacent(self.frame_west, "++x--y-z")
                nodes.append(self.frame_west)

                self.frame_bottom = copy(self.frame_top)
                self.frame_west.place_adjacent(self.frame_bottom, "++x--y-z")
                nodes.append(self.frame_bottom)

                self.frame_east = copy(self.frame_west)
                self.frame_top.place_adjacent(self.frame_east, "++x++y-z")
                nodes.append(self.frame_east)

                self.glass = get_node(delta=(0.085, glass_width, glass_height), material=WindowGlass())
                self.frame_west.place_adjacent(self.glass, "++xy++z")
                nodes.append(self.glass)

                self.air = get_node(delta=(air_thickness, self.window_width, self.window_height))
                self.frame_bottom.place_adjacent(self.air, "-x--y--z")
                nodes.append(self.air)

        window_west = Window(wall_west, "++xy++z")

        class Pillar:
            def __init__(self,
                         place_node,
                         alignment_string,
                         office_height=2.75,
                         wall_below_height=0.85,
                         ):
                nonlocal nodes
                window_height = office_height - wall_below_height
                self.outer = get_node(delta=(0.085, 0.2, window_height), material=WindowInBetween())
                place_node.place_adjacent(self.outer, alignment_string)
                nodes.append(self.outer)

                self.middle = get_node(delta=(0.24, 0.2, window_height), material=Cladding())
                self.outer.place_adjacent(self.middle, "-x--y++z")
                nodes.append(self.middle)

                self.pillar = get_node(delta=(0.2, 0.2, office_height), material=Concrete())
                self.middle.place_adjacent(self.pillar, "-x--y++z")
                nodes.append(self.pillar)

        pillar_west = Pillar(window_west.frame_top, "++xy++z")

        window_middle = Window(pillar_west.outer, "++xy++z", glass_width=0.72)
        pillar_middle = Pillar(window_middle.frame_top, "++xy++z")

        window_east = Window(pillar_middle.outer, "++xy++z", glass_width=1.995)
        pillar_east = Pillar(window_east.frame_top, "++xy++z")

        # wall below windows
        wall_below_windows = get_node(
            delta=(0.325, 6.265, 0.85), material=self.bricks
        )
        wall_west.place_adjacent(wall_below_windows, "++xy--z")
        nodes.append(wall_below_windows)

        class RadiatorPlate:
            def __init__(self,
                         place_node: Node,
                         alignment_string,
                         dimensions,
                         ):
                nonlocal nodes
                self.node = get_node(delta=dimensions, material=MetalWater(metal_ratio=1.8 / 16))
                place_node.place_adjacent(self.node, alignment_string)

                nodes.append(self.node)

        class Radiator:
            def __init__(self,
                         place_node,
                         alignment_string,
                         dimensions,
                         number_plates=2,
                         plate_thickness=0.016):
                nonlocal nodes
                self.plates: list[RadiatorPlate] = []
                self.air_gaps: list[Node] = []

                if number_plates > 1:
                    self.air_gap_thickness = (dimensions[0] - plate_thickness * number_plates) / (number_plates - 1)
                    assert self.air_gap_thickness > 0.0
                else:
                    self.air_gap_thickness = None

                for i in range(number_plates):
                    self.plates.append(
                        RadiatorPlate(
                            place_node=place_node,
                            alignment_string=alignment_string,
                            dimensions=(plate_thickness, *dimensions[1:]),
                        )
                    )
                    if i != number_plates - 1:
                        place_node: Node = self.plates[-1].node
                        alignment_string = "x--y--z"
                        self.air_gaps.append(get_node(delta=(self.air_gap_thickness, *dimensions[1:])))
                        place_node.place_adjacent(self.air_gaps[-1], alignment_string)
                        place_node = self.air_gaps[-1]

                self.nodes = [*self.air_gaps, *[n.node for n in self.plates]]
                nodes.extend(self.nodes)

        class RadiatorBundle:
            def __init__(self,
                         place_node,
                         alignment_string,
                         dimensions: tuple = None,
                         vertex_offset: tuple = None,
                         air_box: tuple = None,
                         ):
                """

                Parameters
                ----------
                place_node
                alignment_string
                dimensions : tuple, optional
                    The dimensions of the radiator.
                vertex_offset : tuple, optional
                    The offset of the vertex that is in the following coordinates: (-x, -y, -z).
                    This is the lower, inner, west vertex.
                air_box : tuple, optional
                    The dimensions of the whole air volume containing the radiator.
                """
                nonlocal nodes
                if dimensions is None:
                    dimensions = (0.081, 1.83, 0.42)
                if air_box is None:
                    air_box = (0.2, 2.31, 0.85)
                if vertex_offset is None:
                    vertex_offset = (0.65, 0.23, 0.21)
                self.air_below = get_node(delta=(air_box[0], air_box[1], vertex_offset[2]))
                place_node.place_adjacent(self.air_below, alignment_string)

                self.air_west = get_node(delta=(air_box[0], vertex_offset[1], dimensions[2]))
                self.air_below.place_adjacent(self.air_west, "--x--yz")

                self.air_inner = get_node(delta=(vertex_offset[0], vertex_offset[1], dimensions[2]))
                self.air_west.place_adjacent(self.air_inner, "--xy--z")

                self.air_outer = copy(self.air_inner)
                self.air_west.place_adjacent(self.air_outer, "--xy++z")

                self.air_top = get_node(delta=(air_box[0], air_box[1], air_box[2] - dimensions[2] - vertex_offset[2]))
                self.air_west.place_adjacent(self.air_top, "--yz")
                self.air_inner.place_adjacent(self.air_top, "--x")

                self.air_east = get_node(
                    delta=(air_box[0], air_box[1] - dimensions[1] - vertex_offset[1], dimensions[2]))
                self.air_below.place_adjacent(self.air_east, "--x++yz")

                nodes.extend(
                    [self.air_below, self.air_west, self.air_inner, self.air_outer, self.air_top, self.air_east])

                self.radiator = Radiator(
                    self.air_inner,
                    "x--y--z",
                    dimensions,
                    number_plates=2,
                    plate_thickness=0.016
                )

        radiator_bundle_west = RadiatorBundle(
            air_node,
            "x--y--z",
            dimensions=(0.081, 1.83, 0.42),
            vertex_offset=(0.065, 0.23, 0.21),
            air_box=(0.2, 2.31, 0.85),
        )

        radiator_bundle_middle = RadiatorBundle(
            pillar_west.pillar,
            "--xy--z",
            dimensions=(0.081, 0.705, 0.42),
            vertex_offset=(0.065, 0.23, 0.21),
            air_box=(0.2, 1.04, 0.85),
        )

        radiator_bundle_east = RadiatorBundle(
            pillar_middle.pillar,
            "--xy--z",
            dimensions=(0.081, 1.83, 0.42),
            vertex_offset=(0.065, 0.23, 0.21),
            air_box=(0.2, 2.315, 0.85),
        )

        # connect every node with resistors
        resistors = connect_cells_with_resistors(nodes)

        self.rc_objects.set_lists(capacitors=nodes, resistors=resistors)


if __name__ == '__main__':
    office = Office()
    office.create_network()

    office.solve_network((0, 8760 * 3600))

    nodes = office.rc_objects.nodes
    solid_nodes = [n for n in office.rc_objects.nodes if n.material.name.lower() != "air"]

    viewer = Viewer(
        wireframe=((5.520 / 2, 6.705 / 2, 2.750 / 2), (5.520, 6.705, 2.750))
    )
    viewer.add_new_from_list(solid_nodes)

    color_cells_by_attribute(solid_nodes, "material.name", opacity=0.4, cmap="managua25")

    print("DONE")
    # from vpython import color
    # air_node: Node
    # for node in nodes:
    #     if node.material.name == "air":
    #         node.vbox.opacity = 0.0
    #         node.vbox.color = color.blue
    #     else:
    #         node.vbox.opacity = 0.4
    #
    # for node in nodes:
    #     node.vbox.opacity = 0.5
