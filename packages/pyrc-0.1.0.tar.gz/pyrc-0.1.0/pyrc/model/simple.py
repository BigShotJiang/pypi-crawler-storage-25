#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

import numpy as np

from pyrc.core.components.resistor import Resistor
from pyrc.core.connecting import connect_cells_with_resistors
from pyrc.core.inputs import InteriorBoundaryCondition, ExteriorBoundaryCondition, Radiation
from pyrc.core.materials import SandLimeBrick
from pyrc.core.network import RCNetwork
from pyrc.core.nodes import Node
from pyrc.core.resistors import CombinedResistor
from pyrc.core.simulation import Simulation
from pyrc.postprocessing.parser import FastParser

from sympy import Symbol


class SimpleWall(RCNetwork):

    def __init__(self, *args, layers=None, make_smiley=True, **kwargs):
        super().__init__(*args, **kwargs)

        self.settings.save_folder_path = r"C:\Simulations\PyRC\demo"
        self.settings.weather_data_path = r"C:\Simulations\PyRC\TRY2015_523748130791_Jahr.dat"
        self.settings.start_date = "2022-06-01T00:00:00"
        self.settings.use_weather_data = True
        self.settings.save_all_x_seconds = 60
        self.settings.solve_settings.max_step = 2

        self.material = SandLimeBrick()
        if layers is None:
            layers = (5, 1, 1)
        if make_smiley:
            layers = (layers[0], 8, 7)
            self.dimensions = (0.3, 4, 3.5)
        else:
            self.dimensions = (0.3, 5, 2.75)
        self.make_smiley = make_smiley
        self.layers = layers
        self.initial_temperature = 273.15 + 15
        self.inner_temperature = 273.15 + 20
        self.outer_temperature = 273.15

        self.sim_objects = {
            "rc_objects": self.rc_objects,
            "rc_solution": self.rc_solution,
            "settings": self.settings,
        }

        self.inner_htc = 4
        self.outer_htc = 14

    def _create_network(self):
        # Create node grid
        nodes_matrix: np.ndarray[Node] = Node.create_grid(
            grid_size=self.layers,
            delta=self.dimensions,
            material=self.material,
            temperature=self.initial_temperature,
            **self.sim_objects
        )

        if self.make_smiley:
            for coord in [[1, 2], [2, 1], [3, 1], [4, 1], [5, 1], [6, 2], [2, 4], [2, 5], [5, 4], [5, 5]]:
                nodes_matrix[-1, *coord].add_internal_heat_source(Radiation,
                                                                  specific_power_in_w_per_meter_squared=400,
                                                                  area_direction=np.array((1, 0, 0)))

        nodes: list = nodes_matrix.flatten().tolist()

        # connect all nodes in the grid with CombinedResistor
        resistors: list[Resistor] = connect_cells_with_resistors(nodes)

        # add symbol to resistor(s)
        resistors_to_change = []
        for i in range(0, self.layers[0] - 1):
            resistors_to_change.extend(nodes_matrix[i, 0, 0].get_resistors_between(nodes_matrix[i + 1, 0, 0]))
        test_symbol = Symbol("test")
        for r in resistors_to_change:
            r._resistance = test_symbol
        # resistors_to_change[0].resistance

        # add Boundary condition on two sides of the wall

        bc_inner = InteriorBoundaryCondition(
            temperature=self.inner_temperature,
            position=np.array([-self.dimensions[0], 0, 0]),  # in negative x direction
            heat_transfer_coefficient=self.inner_htc,
            **self.sim_objects
        )
        # connect
        cell: Node
        for cell in nodes_matrix[0, :, :].flat:
            resistors.append(CombinedResistor(htc=self.inner_htc))
            resistors[-1].connect(cell, direction=(-1, 0, 0), node_direction_points_to=bc_inner)
            resistors[-1].connect(bc_inner)

        bc_outer = ExteriorBoundaryCondition(
            temperature=self.outer_temperature,
            position=np.array([self.dimensions[0], 0, 0]),  # in positive x direction
            heat_transfer_coefficient=self.outer_htc,
            **self.sim_objects
        )
        # connect
        cell: Node
        for cell in nodes_matrix[-1, :, :].flat:
            resistors.append(CombinedResistor(htc=self.outer_htc))
            resistors[-1].connect(cell, direction=(1, 0, 0), node_direction_points_to=bc_outer)
            resistors[-1].connect(bc_outer)

        self.rc_objects.set_lists(capacitors=nodes, resistors=resistors, boundaries=[bc_inner, bc_outer])
        self.groups["outer"] = nodes_matrix[-1, :, :].flatten().tolist()
        self.groups["inner"] = nodes_matrix[0, :, :].flatten().tolist()


if __name__ == "__main__":
    simulation = Simulation(
        network_class=SimpleWall,
        pre_calculation_seconds=3600 * 24,
        t_span=(0, 3600 * 24),
        network_keyword_arguments={"num_cores_jacobian": 1}
    )
    simulation.run(
        time_dependent_function=lambda t, *args, **kwargs: [0.218 * (1.5 + 0.5 * np.sin(2 * np.pi * t / (86400 / 4)))])

    parser = FastParser((simulation.network, simulation.network.pickle_path_result))
    index = parser.add_node_filter("outer", return_index=True)

    simulation.network.rc_solution.write_paraview_data(
        r"C:\Simulations\PyRC\demo\paraview",
        use_degrees_celsius=True,
        time_increment=5
    )

    print("Done")
