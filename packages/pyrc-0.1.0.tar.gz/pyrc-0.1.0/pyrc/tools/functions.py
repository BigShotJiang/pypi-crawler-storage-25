#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any

from sympy import latex, Basic, sympify, diag, Matrix
import numpy as np


def add_leading_underscore(string: str = "") -> str:
    """
    Adds a leading underscore if not already existing and string is not None or empty.

    Parameters
    ----------
    string : str
        The string to check.

    Returns
    -------
    str :
        Checked string.
    """
    if string is not None and string != "":
        if not string.startswith("_"):
            string = f"_{string}"
    else:
        string = ""
    return string


def sympy_matrix_to_latex(matrix):
    """
    Return a LaTeX representation of a sympy expression.

    Parameters
    ----------
    matrix : sympy.Matrix
        Expression or matrix to convert to LaTeX.

    Returns
    -------
    str
        LaTeX representation of expr.
    """

    diag_elements = matrix.diagonal()
    matrix_no_diag = matrix - diag(*diag_elements)

    matrix_latex = latex(matrix_no_diag)
    diag_latex = latex(Matrix(diag_elements).reshape(len(diag_elements), 1))

    return f"{matrix_latex} + \\mathrm{{diag}}\\left({diag_latex}\\right)"


def save_as_tex(filename, latex_str):
    if isinstance(latex_str, list):
        latex_str = "\n\n".join(latex_str)
    with open(filename, "w") as f:
        f.write(
            rf"""\documentclass[border=3mm]{{standalone}}
\usepackage{{amsmath}}
\begin{{document}}
$ {latex_str} $
\end{{document}}"""
        )

def sympy_to_tex(matrix, file):
    save_as_tex(file, sympy_matrix_to_latex(matrix))


def sympy_sparse_matrix_to_latex(M, filename, fontsize="20pt"):
    latex_str = sparse_matrix_to_nicematrix_latex(M)
    doc = rf"""\documentclass[border=3mm]{{standalone}}
\usepackage{{amsmath}}
\usepackage{{nicematrix}}
\usepackage{{lmodern}}
\usepackage{{anyfontsize}}

\NiceMatrixOptions{{cell-space-limits=2pt}}

\begin{{document}}
\fontsize{{{fontsize}}}{{{fontsize}}}\selectfont
\[
{latex_str}
\]
\end{{document}}
"""
    with open(filename, "w") as f:
        f.write(doc)


def is_set(value):
    """
    Returns True if the value is already set (by value or symbol) and False if it is np.nan.

    Parameters
    ----------
    value : any
        The value to check.

    Returns
    -------
    bool :
        True if the resistance value is already set and False if it is np.nan.
    """
    if isinstance(value, Basic):
        return True
    if value is None:
        return False
    if isinstance(value, np.ndarray):
        return value.size > 0
    if isinstance(value, (list, tuple)):
        return len(value) > 0
    if np.isnan(value):
        return False
    return True


def get_nested_attribute(obj, attribute_path: str):
    """
    Get nested attribute value from object using dot notation.

    Parameters
    ----------
    obj : object
        Object to get attribute from
    attribute_path : str
        Dot-separated attribute path (e.g., 'material.name')

    Returns
    -------
    Any
        Value of the attribute
    """
    attributes = attribute_path.split(".")
    value = obj
    for attr in attributes:
        value = getattr(value, attr)
    return value


def contains_symbol(expr: float | int | np.ndarray | np.number | Any) -> bool:
    """Check whether any sympy symbol appears in an expression, array, or scalar.

    Parameters
    ----------
    expr : float | int | np.ndarray | np.number | Any
        Expression, numpy array, list, scalar, or np.nan to check.

    Returns
    -------
    bool :
        True if any sympy symbol is found anywhere in expr.
    """
    if isinstance(expr, np.ndarray):
        return any(contains_symbol(e) for e in expr.flat)
    if isinstance(expr, (list, tuple)):
        return any(contains_symbol(e) for e in expr)
    try:
        return bool(sympify(expr).free_symbols)
    except Exception:
        return False


def check_type(nodes, type1, type2) -> bool:
    return (isinstance(nodes[0], type1) and isinstance(nodes[1], type2)) or (
        isinstance(nodes[1], type1) and isinstance(nodes[0], type2)
    )


def return_type(nodes: list, type1, check_value: list | Any = None):
    if check_value is None:
        check_value = nodes
    assert len(check_value) == len(nodes)
    if isinstance(check_value[0], type1):
        return tuple(nodes)
    else:
        return nodes[1], nodes[0]


def subtract_seconds_from_string(date_string: str, seconds: int | float) -> str:
    dt = datetime.fromisoformat(date_string)
    result_dt = dt - timedelta(seconds=seconds)
    return result_dt.isoformat()


def fill_none(list1, list2):
    return [b if a is None else a for a, b in zip(list1, list2)]
