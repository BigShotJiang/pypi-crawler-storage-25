#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------


class FixedPositionError(Exception):
    default_message = "Position is fixed and cannot be changed."

    def __init__(self, message=default_message):
        self.message = message
        super().__init__(self.message)


class FixedXYError(FixedPositionError):
    default_message = "Position in X-Y-Plane is fixed and cannot be changed."

    def __init__(self, message=default_message):
        self.message = message
        super().__init__(self.message)


class FixedZError(FixedPositionError):
    default_message = "Height is fixed and cannot be changed."

    def __init__(self, message=default_message):
        self.message = message
        super().__init__(self.message)


class HighCourantNumberError(Exception):
    def __init__(self):
        super().__init__(
            "The courant number is greater than 1. Decrease the simulated time step or enlarge the "
            "MassFlowNodes in flow direction."
        )
