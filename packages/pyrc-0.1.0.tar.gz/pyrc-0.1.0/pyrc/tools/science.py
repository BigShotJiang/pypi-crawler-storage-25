#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

import numpy as np
from sympy import diff, SparseMatrix
import multiprocessing
import os
from psutil import virtual_memory

os.environ["SYMPY_CACHE_SIZE"] = "10000000000"


def get_free_ram_gb():
    return get_free_ram() / (1024**3)


def get_free_ram():
    return virtual_memory().available


def kelvin_to_celsius(kelvin):
    return kelvin - 273.15


def celsius_to_kelvin(celsius):
    return celsius + 273.15


def build_jacobian(terms: list, variables: list, involved_symbols: list, num_cores: int = None) -> SparseMatrix:
    """
    creates the jacobian matrix using all terms and their involved symbols.

    Parameters
    ----------
    terms : list
        All terms in a list.
    variables : list
        All variables of all terms in a list.
    involved_symbols : list
        Lists with the symbols the derivative must be created for each term in a list.
        So for term[0] there are only the variables involved_symbols[0] relevant.
        It is used to make the calculation faster and set 0 to all other places in the jacobian matrix where the
        symbols are not involved.
    num_cores : int, optional
        The number of cores that should be used to calculate the jacobian matrix.
        If None, the maximum number of cores except one is used.
        If 1 or smaller, no parallel computing is used.

    Returns
    -------
    Any :
        The jacobian matrix with symbols.
    """

    # Define batch size for efficiency
    if num_cores is None:
        num_cores = multiprocessing.cpu_count() - 1

    if num_cores <= 1:
        jacobian_rows = compute_jacobian_batch(list(range(0, len(terms))), terms, involved_symbols, variables)
    else:
        batch_size = max(1, len(terms) // (num_cores * 3))  # Adjust batch size based on problem size
        batches = [list(range(i, min(i + batch_size, len(terms)))) for i in range(0, len(terms), batch_size)]

        # Prepare arguments for starmap
        batch_args = [(batch, terms, involved_symbols, variables) for batch in batches]

        # Parallel execution with batching using starmap
        with multiprocessing.Pool(processes=num_cores) as pool:
            jacobian_batches = pool.starmap(compute_jacobian_batch, batch_args)

        # Flatten the result and convert to SparseMatrix
        jacobian_rows = [row for batch in jacobian_batches for row in batch]
    jacobian = SparseMatrix(jacobian_rows)

    return jacobian


def is_numeric(value):
    """
    Checks if value is a numeric value.

    Parameters
    ----------
    value : Any
        Value to check.

    Returns
    -------
    bool
        True if value is numeric, False otherwise
    """
    list_of_numerics = [float, int, np.number]  # add numeric data types here if necessary
    for numeric in list_of_numerics:
        if isinstance(value, numeric):
            return True
    return False


def round_valid(number: float | int, valid_digits: int, return_str: bool = False):
    if np.isnan(number):
        if return_str:
            return "NaN"
        return np.nan
    if number == np.inf:
        if return_str:
            return "Infinity"
        return np.inf
    if number == -np.inf:
        if return_str:
            return "-Infinity"
        return -np.inf
    if int(number) == 0:
        # number < 1
        if number == 0:
            if return_str:
                return "0"
            return 0
        counter = 0
        while int(number) == 0:
            number = number * 10
            counter += 1
        if return_str:
            format_str = f"{{:{counter + 1 + valid_digits}.{valid_digits + counter - 1}f}}"
            return format_str.format(np.round(number, valid_digits) / 10**counter)
        return np.round(np.round(number, valid_digits) / 10**counter, counter + valid_digits - 1)
    else:
        ten_digits = int(np.log10(abs(number))) + 1
        if ten_digits >= valid_digits:
            number = int(number)
        if return_str:
            return f"{np.round(number, valid_digits - ten_digits)}"
        return np.round(number, valid_digits - ten_digits)


# Function to compute a batch of Jacobian rows
def compute_jacobian_batch(_batch, _terms, _dependent_variables, _all_variables):
    batch_result = []
    for i in _batch:
        row = [diff(_terms[i], v) if v in _dependent_variables[i] else 0 for v in _all_variables]
        batch_result.append(row)
    return batch_result


def cm_to_inch(value):
    return value / 2.54
