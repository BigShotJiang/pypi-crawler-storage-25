#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

import numpy as np
import time
import os

from pyrc.tools import round_valid


class Timing:
    def __init__(
        self,
        name: str = "",
        print_init: bool = True,
        print_results: bool = True,
        no_logging: bool = False,
        result_path: str = None,
    ):
        """
        Class for simple timing.

        This class was originally written by Joel Kimmich in his Fraqualex-project.

        Parameters
        ----------
        name : str, optional
            Possible prefix
        print_init : bool, optional
            If True the dialog 'Started Timing' will be printed out of init
        print_results : bool, optional
            If False no prints will be done
        no_logging : bool, optional
            If True no logging will be done, which speeds up the timing a bit.
        result_path : str, optional
            The path to save a result file with all events.
            If None the result will not be saved.

        Examples
        --------
        >>> time = Timing()
        >>> time.catch_time() # prints out the current time and the difference to the last catch_time call
        >>> time.end_timing() # ends the timing with a last print out (if print_results is True)
        >>> log: dict = time.log # in the log you can find all times deltas in a dict (if no_logging is False)
        """
        self.times = []
        self.no_logging = no_logging
        start_time_ns = time.perf_counter_ns()
        self.times.append(start_time_ns)
        self.name = name + ": "
        self.print_results = print_results
        self.result_path = result_path
        if self.result_path:
            os.makedirs(os.path.dirname(self.result_path), exist_ok=True)

        if print_init and print_results:
            print(f"{self.clock}: {self.name}Started Timing")

        # internal logging of all catch_time events
        self.logging = {0: self.name + "start"}
        self.logging_hr = {ns_to_hr_time(0): self.name + "start"}

    @property
    def clock(self):
        return time.strftime("%H:%M:%S")

    @property
    def time(self):
        diff = np.array(self.times)
        diff = diff - self.times[0]
        return diff.tolist()

    @property
    def log(self) -> dict:
        return self.logging

    @property
    def seconds(self):
        return [x / 1e9 for x in self.time]

    @property
    def log_hr(self):
        return self.logging_hr

    # def write_log_file(self, result_path: str = None):
    #     """
    #     Write the current log into a yaml file.
    #
    #     Parameters
    #     ----------
    #     result_path : str, optional
    #         The path to save a result file with all events.
    #         If None, self.result_path will be used. If this is also None, no log file is written.
    #
    #     """
    #     if result_path is None:
    #         if self.result_path:
    #             result_path = self.result_path
    #
    #     if result_path:
    #         write_dict_to_yaml(data=self.log, path=result_path)
    #     else:
    #         logging.warning("No logging file created because no file path is given.")

    # def plot_time_catches(self):
    #     """
    #     Plots the times over the calls with matplotlib.
    #
    #     Returns
    #     -------
    #     """
    #     seconds = self.seconds
    #     plot_over_time(seconds, list(range(0, len(seconds))))

    def catch_time(self, message=None):
        self.times.append(time.perf_counter_ns())
        if message is None:
            message = "no message"

        # log times with a message in dict
        delta = self.times[-1] - self.times[0]

        if not self.no_logging:
            self.logging[delta] = message
            self.logging_hr[ns_to_hr_time(delta)] = message

        if self.print_results:
            time_diff = self.times[-1] - self.times[-2]
            time_str = ns_to_hr_time(time_diff)
            if message is not None:
                print(f"{self.clock}: {self.name}Time-diff: {time_str} | {message}")
            else:
                print(f"{self.clock}: {self.name}Time-diff: {time_str}")

    def end_timing(self, return_times: bool = False):
        self.catch_time("Ending timing.")
        if self.print_results:
            valid = round_valid((self.times[-1] - self.times[0]) / 1e9, 4)
            print(f"{self.clock}: {self.name}Duration: {valid} seconds")
        if return_times:
            times_seconds = [x / 1e9 for x in self.times]
            return times_seconds
        # if self.result_path:
        #     self.write_log_file()


def ns_to_hr_time(nanoseconds: int):
    """
    Parses a value in nanoseconds to a human-readable time string.

    Use this function only for relative values because the absolute value isn't defined.

    Parameters
    ----------
    nanoseconds : int

    Returns
    -------
    str :
        The human-readable time string with hours:minutes:seconds. Seconds has four decimal digits.
    """
    seconds = nanoseconds / 1e9
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    seconds = (seconds % 3600) % 60
    return f"{'{:5.0f}'.format(hours)}:{'{:02.0f}'.format(minutes)}:{'{:07.4f}'.format(seconds)}"
