#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------
from pyrc.tools.errors import FixedPositionError, FixedXYError, FixedZError, HighCourantNumberError

__all__ = ["FixedPositionError", "FixedXYError", "FixedZError", "HighCourantNumberError"]

from pyrc.tools.functions import (
    add_leading_underscore,
    sympy_matrix_to_latex,
    save_as_tex,
    sympy_to_tex,
    sympy_sparse_matrix_to_latex,
    is_set,
    get_nested_attribute,
    contains_symbol,
    check_type,
    return_type,
    subtract_seconds_from_string,
    fill_none,
)

__all__.extend(
    [
        "add_leading_underscore",
        "sympy_matrix_to_latex",
        "save_as_tex",
        "sympy_to_tex",
        "sympy_sparse_matrix_to_latex",
        "is_set",
        "get_nested_attribute",
        "contains_symbol",
        "check_type",
        "return_type",
        "subtract_seconds_from_string",
        "fill_none",
    ]
)

from pyrc.tools.plotting import custom_numeric_ticks_formatter, format_date_x_axis

__all__.extend(["custom_numeric_ticks_formatter", "format_date_x_axis"])

from pyrc.tools.science import (
    get_free_ram,
    get_free_ram_gb,
    kelvin_to_celsius,
    celsius_to_kelvin,
    build_jacobian,
    is_numeric,
    round_valid,
    compute_jacobian_batch,
    cm_to_inch,
)

__all__.extend(
    [
        "get_free_ram",
        "get_free_ram_gb",
        "kelvin_to_celsius",
        "celsius_to_kelvin",
        "build_jacobian",
        "is_numeric",
        "round_valid",
        "compute_jacobian_batch",
        "cm_to_inch",
    ]
)

from pyrc.tools.timing import Timing, ns_to_hr_time
__all__.extend(["Timing","ns_to_hr_time"])