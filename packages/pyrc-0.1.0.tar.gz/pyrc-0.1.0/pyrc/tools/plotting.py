#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

from datetime import timedelta, datetime

import matplotlib.dates as mdates
from mpl_toolkits.mplot3d.proj3d import proj_transform
from mpl_toolkits.mplot3d.axes3d import Axes3D
import numpy as np
from matplotlib.patches import FancyArrowPatch


class Arrow3D(FancyArrowPatch):
    def __init__(self, start, end, *args, **kwargs):
        super().__init__((0, 0), (0, 0), *args, **kwargs)
        self._start = tuple(start)
        self._end = tuple(end)

    def make_arrow(self):
        x1, y1, z1 = self._start
        x2, y2, z2 = self._end

        xs, ys, zs = proj_transform((x1, x2), (y1, y2), (z1, z2), self.axes.M)
        self.set_positions((xs[0], ys[0]), (xs[1], ys[1]))
        return zs

    def draw(self, renderer):
        self.make_arrow()
        super().draw(renderer)

    def do_3d_projection(self, renderer=None):
        zs = self.make_arrow()
        return np.min(zs)


def custom_numeric_ticks_formatter(x, pos):
    """
    Format numbers/ticks to match ISO 80000.

    Parameters
    ----------
    x : float | int
        The number to format.
    pos

    Returns
    -------
    str :
        The formatted number with a short protected space as thousands separator and a "," as decimal.
    """
    if abs(x) >= 1000:
        s = f"{x:,.0f}".replace(",", "\u202f").replace(".", ",")
        return s
    else:
        return f"{x:g}".replace(".", ",")


def format_date_x_axis(start_date: datetime, end_date: datetime, ax, return_version: bool = True) -> str | None:
    """
    Formats the ticks of an axis as date.

    Depending on the date range it parses the time/date to days, weeks, months and years with matching minor ticks.

    Parameters
    ----------
    start_date : datetime
        The start date of the axis.
    end_date : datetime
        The end date of the axis.
    ax : matplotlib.axis.Axis
        The axis to format.
    return_version : bool
        Whether to return the version of the axis or not.

    Returns
    -------
    str | None :
        The formatted Axis if return_version is True, otherwise None.
    """
    time_delta = end_date - start_date
    if time_delta <= timedelta(days=3):
        version = "day"
        ax.xaxis.set_major_locator(mdates.HourLocator(byhour=(0, 6, 12, 18)))
        ax.xaxis.set_minor_locator(mdates.HourLocator())
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%d.%m. %-H Uhr"))
    elif time_delta <= timedelta(days=10):
        version = "week"
        ax.xaxis.set_major_locator(mdates.DayLocator())
        ax.xaxis.set_minor_locator(mdates.HourLocator(byhour=(0, 6, 12, 18)))
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%d.%m."))
    elif time_delta <= timedelta(days=80):
        version = "month"
        ax.xaxis.set_major_locator(mdates.DayLocator(bymonthday=(1, 7, 15, 23)))
        ax.xaxis.set_minor_locator(mdates.DayLocator())
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%d.%m."))
    else:
        version = "year"
        ax.xaxis.set_major_locator(mdates.MonthLocator())
        ax.xaxis.set_minor_locator(mdates.DayLocator(bymonthday=(1, 7, 14, 21, 28)))
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%-m."))
    ax.grid(True)
    ax.tick_params(axis="x", which="minor", bottom=True)
    ax.set_xlim(left=start_date)
    ax.set_xlim(right=end_date)
    if return_version:
        return version


def _arrow3D(ax, start, end, *args, **kwargs):
    """Add an 3d arrow to an `Axes3D` instance."""

    arrow = Arrow3D(start, end, *args, **kwargs)
    ax.add_artist(arrow)


setattr(Axes3D, "arrow3D", _arrow3D)

# example usage
# fig = plt.figure()
# ax = fig.add_subplot(111, projection='3d')
# ax.set_xlim(0,2)
# ax.arrow3D((0,0,0),
#            (1,1,1),
#            mutation_scale=10,
#            arrowstyle="-|>",
#            linestyle="-")
# ax.arrow3D((1,0,0),
#             (2,1,1),
#            mutation_scale=20,
#            ec ="green",
#            fc="red")
# ax.set_title('3D Arrows Demo')
# ax.set_xlabel('x')
# ax.set_ylabel('y')
# ax.set_zlabel('z')
# fig.tight_layout()
# plt.show()
