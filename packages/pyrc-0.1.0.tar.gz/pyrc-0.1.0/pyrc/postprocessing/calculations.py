#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

import warnings

import numpy as np

from pyrc.core.components.resistor import Resistor
from pyrc.core.components.capacitor import Capacitor
from pyrc.core.inputs import BoundaryCondition, InternalHeatSource
from pyrc.core.nodes import MassFlowNode
from pyrc.core.components.input import Input


# def heat_flux_z_direction(temp_matrix: np.ndarray, input_matrix: np.ndarray, nodes: list, )

class SimpleHeatFlux:
    def __init__(self,
                 time_filtered_temp_matrix: np.ndarray,
                 time_filtered_input_matrix: np.ndarray,
                 ):
        """
        Do not filter the columns! Otherwise, the algorithms won't work anymore.

        Parameters
        ----------
        time_filtered_temp_matrix
        time_filtered_input_matrix
        """
        self.temp_matrix = time_filtered_temp_matrix
        self.input_matrix = time_filtered_input_matrix

    def boundary(self, boundary: BoundaryCondition) -> np.ndarray:
        resistors: Resistor = boundary.neighbours

        bc_temp = self.input_matrix[:, boundary.index]
        heat_flux_sum = np.zeros_like(bc_temp)

        for resistor in resistors:
            other_node_index = resistor.get_connected_node(boundary).index
            node_temp = self.temp_matrix[:, other_node_index]
            heat_flux_sum += 1 / resistor.resistance * (bc_temp - node_temp)
        return heat_flux_sum

    def preheat(self, distributor: MassFlowNode, collector: MassFlowNode):
        """
        Returns the preheat in Kelvin.

        Returns
        -------
        np.ndarray
        """
        temp_dist: np.ndarray = self.temp_matrix[:, distributor.index]
        temp_col: np.ndarray = self.temp_matrix[:, collector.index]
        return temp_col - temp_dist

    def channel_heat_flux(self, distributor: MassFlowNode, collector: MassFlowNode):
        """
        Returns the heat flux between distributor and collector.

        Parameters
        ----------
        distributor : MassFlowNode
        collector : MassFlowNode

        Returns
        -------
        np.ndarray :
            The heat flux between distributor and collector.
        """
        temp_dist = self.temp_matrix[:, distributor.index]
        temp_col = self.temp_matrix[:, collector.index]
        mass_flow = distributor.mass_flow
        spec_capacity = distributor.material.heat_capacity
        return mass_flow * spec_capacity * (temp_col - temp_dist)

    def calculate_heat_flux(self, node, resistors: list | Resistor, raise_error_instead_of_warning=False) -> (
            np.ndarray | float):
        """
        Returns the heat flux going into the node by the passed resistors.

        Attention: It uses the equivalent resistance for both serial and parallel resistors. To prevent double
        calculation do only pass one Resistor to a Node

        Parameters
        ----------
        node : NoteTemplate
            The Node of which the heat flux is being calculated.
        resistors : list | Resistor
            The resistors used to calculate the heat flow. They should be connected to node.
        raise_error_instead_of_warning : bool, optional
            If True, an error is raised instead of a warning when a heat flux is calculated to a Node that was
            already considered.

        Returns
        -------
        float | np.ndarray :
            The heat fluxes for every time step.
        """
        if isinstance(resistors, Resistor):
            resistors = [resistors]

        result = 0
        node_temp = self.temp_matrix[:, node.index]
        seen_other_nodes = set()
        for resistor in resistors:
            other_node = resistor.get_connected_node(node)
            if other_node in seen_other_nodes:
                if raise_error_instead_of_warning:
                    raise ValueError("The heat flux to this Node was already calculated.\n"
                                     "You might consider using TemperatureNode.resistors_in_direction_filtered (with "
                                     "filtered!).")
                warnings.warn("The heat flux to this Node was already calculated; the heat flux is probably wrong!")
            if isinstance(other_node, Input):
                result += 1 / resistor.equivalent_resistance * (
                        self.input_matrix[:, other_node.index] - node_temp)
            else:
                result += 1 / resistor.equivalent_resistance * (
                        self.temp_matrix[:, other_node.index] - node_temp)
        return result

    def internal_heat_source(self, ihc: InternalHeatSource | list) -> np.ndarray:
        """
        Returns the values for the internal heat sources out of the input matrix.

        Parameters
        ----------
        ihc : list | InternalHeatSource
            The `InternalHeatSource` s to get the values from.

        Returns
        -------
        np.ndarray :
            The values.
            Vector if one IHS is passed, matrix otherwise (time steps x IHS).
        """
        if not isinstance(ihc, list):
            ihc = [ihc]
        ihc_index = [i.index for i in ihc]
        ihc_values = self.input_matrix[:, ihc_index]
        return ihc_values

    def heat_flux_directions(
            self,
            nodes: list[Capacitor],
            directions: list | np.ndarray = np.array([0, 0, -1]),
            except_resistor_types=None
    ) -> tuple | np.ndarray:
        """
        Returns the heat flux through the layer in the desired direction of all nodes in the given list.

        E.g. if the direction is (0,0,1) the heat flux in positive z direction is calculated. The heat flux is
        positive if going in the same direction as the desired one.

        Parameters
        ----------
        nodes : list[Capacitor]
            The Nodes of which the heat flux is being calculated.
        directions : list | np.ndarray, optional
            The direction(s) in which the heat flux is calculated.
            Can be a list then each direction is calculated and returned.
        except_resistor_types

        Returns
        -------
        np.ndarray | tuple :
            The result of one direction as np.ndarray or the result of all directions as tuple.
        """
        if except_resistor_types is None:
            except_resistor_types = []
        if isinstance(directions, np.ndarray):
            directions = [directions]
        results = []
        for direction in directions:
            nodes_and_resistors = [
                (node, node.resistors_in_direction_filtered(direction, except_resistor_types=except_resistor_types))
                for node in nodes if node is not None
            ]

            result = 0
            for node, resistors in nodes_and_resistors:
                result += self.calculate_heat_flux(node, resistors)
            results.append(result)

        if len(results) > 1:
            return tuple(results)
        return results[0]
