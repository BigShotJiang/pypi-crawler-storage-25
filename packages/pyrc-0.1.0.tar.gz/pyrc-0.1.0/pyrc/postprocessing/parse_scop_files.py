#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

import re

import numpy as np
import pandas as pd
from datetime import datetime


def parse_scop_file(filenames: dict) -> pd.DataFrame:
    """
    Parse SCOP data file and extract values for each VL and version/subversion.

    Parameters
    ----------
    filenames : dict[str, str]
        Names (keys) and paths (values) of the SCOP files.

    Returns
    -------
    pd.DataFrame :
        DataFrame with columns: period_type, date, subversion, VL, value, time_steps
    """

    result = []
    for name, path in filenames.items():
        with open(path, "r") as file:
            content = file.read()

        # Split by separator lines
        blocks = content.split("--------------------------------------")

        for block in blocks:
            block = block.strip()
            if not block:
                continue

            lines = block.split("\n")

            # Parse header line
            header_pattern = r"SCOP\$_\{neu\}\$/SCOP\$_\{alt\}\$ (\w+) (\d{4}-\d{2}-\d{2}) ([\w\s-]+) in %:"
            header_match = re.match(header_pattern, lines[0])

            if not header_match:
                continue

            period_type = header_match.group(1)
            date = datetime.strptime(header_match.group(2), "%Y-%m-%d")
            subversion = header_match.group(3)

            orientation = "Süd"
            volume_flow = 250
            if "vf" in subversion:
                volume_flow = int(subversion[2:].split()[0])
            else:
                orientation = subversion.split()[0]

            # Parse VL values
            vl_values = {}
            heat_amount = None
            for line in lines[1:-1]:  # Skip header and time steps line
                line = line.strip()

                # check for VL values
                vl_match = re.match(r"(\d+\.\d+) für VL = (\d+)", line)
                if vl_match:
                    value = float(vl_match.group(1))
                    vl = int(vl_match.group(2))
                    vl_values[vl] = value

                # Check for heat amount line
                heat_amount_match = re.match(r"Wärmemenge / kWh/12/a: (.+)", line)
                if heat_amount_match:
                    heat_amount_str = heat_amount_match.group(1)
                    heat_amount = np.array([float(x) for x in heat_amount_str.split()])

            # Parse time steps
            time_steps_match = re.search(r"for\s+(\d+)\s+time steps", lines[-1])
            time_steps = int(time_steps_match.group(1)) if time_steps_match else None

            # Add data for each VL
            for vl, value in vl_values.items():
                result.append(
                    {
                        "type": name,
                        "period_type": period_type,
                        "date": date,
                        "orientation": orientation,
                        "volume_flow": volume_flow,
                        "VL": vl,
                        "value": value,
                        "time_steps": time_steps,
                        "heat_amount": heat_amount,
                    }
                )

    return pd.DataFrame(result)


def get_data_subset(df, period_type=None, orientation=None, volume_flow=None, vl=None, scop_type=None):
    """
    Filter DataFrame based on criteria.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame from parse_scop_file
    period_type : str, optional
        Filter by period type (day, week, year)
    orientation : str, optional
        Filter by orientation (Ost, Süd, ...)
    volume_flow : int | list, optional
        Filter by volume flow.
    vl : int | list, optional
        Filter by VL value(s)
    scop_type : str | list, optional
        The type of the SCOP values (e.g. preheat, complete, ...)

    Returns
    -------
    pd.DataFrame
        Filtered DataFrame
    """

    result = df.copy()

    if period_type is not None:
        result = result[result["period_type"] == period_type]

    if orientation is not None:
        result = result[result["orientation"] == orientation]

    if volume_flow is not None:
        if isinstance(volume_flow, (list, tuple)):
            result = result[result["volume_flow"].isin(volume_flow)]
        else:
            result = result[result["volume_flow"] == volume_flow]

    if scop_type is not None:
        if isinstance(scop_type, (list, tuple)):
            result = result[result["type"].isin(scop_type)]
        else:
            result = result[result["type"] == scop_type]

    if vl is not None:
        if isinstance(vl, (list, tuple)):
            result = result[result["VL"].isin(vl)]
        else:
            result = result[result["VL"] == vl]

    return result


def add_heat_dates(df: pd.DataFrame):
    """
    For each array in column "heat_amount" it adds an array representing the time for each entry.

    It also cleans the heat_amount arrays from unnecessary values (from overhanging time ranges and stuff).

    Used before plotting the data.

    Parameters
    ----------
    df

    Returns
    -------
    pd.DataFrame :
        The same DataFrame but with new column "heat_amount_time" and a cleaned up version of the column "heat_amount"
    """
    # only month and year are implemented because they are the important ones at first
    df = df.copy()

    def process_row(row):
        if row["period_type"] == "month":
            return np.array(row["date"]), row["heat_amount"]
        elif row["period_type"] == "year":
            heat_amount = row["heat_amount"][:12] if row["heat_amount"] is not None else None
            year = row["date"].year
            heat_dates = np.array([pd.Timestamp(year, month, 1) for month in range(1, 13)])
            return heat_dates, heat_amount
        else:
            return row["date"], row["heat_amount"]

    df[["heat_dates", "heat_amount"]] = df.apply(
        lambda row: pd.Series(process_row(row)), axis=1
    )

    return df
