#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------
from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING

import numpy as np
from matplotlib import pyplot as plt

from pyrc.core.components.templates import solution_object
from pyrc.visualization import seconds_to_dates, TimePlot

if TYPE_CHECKING:
    from pyrc.core.nodes import Node, MassFlowNode, ChannelNode
    from pyrc.core.components.capacitor import Capacitor
    from pyrc.core.components.resistor import Resistor
    from pyrc.core.inputs import BoundaryCondition, InternalHeatSource
    from pyrc.core.components.templates import RCSolution


def get_accumulated_heat_flux(node: Capacitor):
    """
    Sums up the heat flux of all connected resistors.

    Used to get the heat flux that is brought in through `BoundaryCondition` s.

    Parameters
    ----------
    node : NoteTemplate
        The Node of which the heat flux is being calculated.
        For this, all connected resistors are summed up.

    Returns
    -------
    float :
        The heat flux of all connected resistors.
    """
    resistors: Resistor = node.neighbours
    seen_nodes = set()
    resistors_without_parallel = []
    for resistor in resistors:
        connected_node = resistor.get_connected_node(node)
        if connected_node not in seen_nodes:
            seen_nodes.add(connected_node)
            resistors_without_parallel.append(resistor)

    heat_flux = [r.heat_flux(node) for r in resistors_without_parallel]

    return sum(heat_flux)


class HeatFlux:
    def __init__(self, rc_solution: RCSolution = solution_object):
        self.rc_solution = rc_solution

    def parse_time_step_index(self, time_step_index):
        if time_step_index is None:
            time_step_index = list(range(len(self.rc_solution.time_steps)))
        elif (
            not isinstance(time_step_index, list)
            and not isinstance(time_step_index, slice)
            and not isinstance(time_step_index, np.ndarray)
        ):
            time_step_index = [time_step_index]
        return time_step_index

    def boundary(self, boundary: BoundaryCondition, time_step_index=None):
        resistors: Resistor = boundary.neighbours

        time_step_index = self.parse_time_step_index(time_step_index)

        bc_temp = self.rc_solution.input_vectors[time_step_index, boundary.index]
        heat_flux_sum = np.zeros_like(bc_temp)

        for resistor in resistors:
            other_node_index = resistor.get_connected_node(boundary).index
            node_temp = self.rc_solution.result_vectors[time_step_index, other_node_index]
            heat_flux_sum += 1 / resistor.resistance * (bc_temp - node_temp)
        return self.rc_solution.time_steps[time_step_index], heat_flux_sum

    def preheat(self, distributor: MassFlowNode, collector: MassFlowNode):
        """
        Returns the preheat in Kelvin.

        Returns
        -------
        np.ndarray
        """
        time_step_index = self.parse_time_step_index(None)
        temp_dist: np.ndarray = self.rc_solution.result_vectors[time_step_index, distributor.index]
        temp_col: np.ndarray = self.rc_solution.result_vectors[time_step_index, collector.index]
        return temp_col - temp_dist

    def calculate_heat_flux(self, node, resistors: list | Resistor, time_step_index=None) -> np.ndarray | float:
        """
        Returns the heat flux going into the node by the passed resistors.

        Parameters
        ----------
        node : NoteTemplate
            The Node of which the heat flux is being calculated.
        resistors : list | Resistor
            The resistors used to calculate the heat flow.
        time_step_index : int | slice | list, optional
            The time steps that should be calculated.
            If None, all are calculated.

        Returns
        -------
        float | np.ndarray :
            The heat fluxes for every time step.
        """
        from pyrc.core.components.resistor import Resistor

        if isinstance(resistors, Resistor):
            resistors = [resistors]
        time_step_index = self.parse_time_step_index(time_step_index)

        result = 0
        node_temp = self.rc_solution.result_vectors[time_step_index, node.index]

        from pyrc.core.components.input import Input

        for resistor in resistors:
            other_node = resistor.get_connected_node(node)
            if isinstance(other_node, Input):
                result += (
                    1
                    / resistor.equivalent_resistance
                    * (self.rc_solution.input_vectors[time_step_index, other_node.index] - node_temp)
                )
            else:
                result += (
                    1
                    / resistor.equivalent_resistance
                    * (self.rc_solution.result_vectors[time_step_index, other_node.index] - node_temp)
                )
        return result

    def internal_heat_source(self, ihc: InternalHeatSource | list, time_step_index=None):
        if not isinstance(ihc, list):
            ihc = [ihc]
        ihc_index = [i.index for i in ihc]
        time_step_index = self.parse_time_step_index(time_step_index)
        ihc_values = self.rc_solution.input_vectors[time_step_index, :][:, ihc_index]
        return self.rc_solution.time_steps[time_step_index], ihc_values

    def heat_flux_directions(
        self,
        nodes: list[Node],
        directions: list | np.ndarray = np.array([0, 0, -1]),
        except_resistor_types=None,
        time_step_index=None,
    ) -> tuple | np.ndarray:
        """
        Returns the heat flux through the layer in the desired direction of all nodes in the given list.

        E.g. if the direction is (0,0,1) the heat flux in positive z direction is calculated. The heat flux is
        positive if going in the same direction as the desired one.

        Parameters
        ----------
        nodes : list[Node]
            The Nodes of which the heat flux is being calculated.
        directions : list | np.ndarray, optional
            The direction(s) in which the heat flux is calculated.
            Can be a list then each direction is calculated and returned.
        except_resistor_types
        time_step_index

        Returns
        -------
        np.ndarray | tuple :
            The result of one direction as np.ndarray or the result of all directions as tuple.
        """
        if except_resistor_types is None:
            except_resistor_types = []
        if isinstance(directions, np.ndarray):
            directions = [directions]
        results = []
        for direction in directions:
            nodes_and_resistors = [
                (node, node.resistors_in_direction_filtered(direction, except_resistor_types=except_resistor_types))
                for node in nodes
                if node is not None
            ]

            result = 0
            for node, resistors in nodes_and_resistors:
                result += self.calculate_heat_flux(node, resistors, time_step_index)
            results.append(result)

        if len(results) > 1:
            return tuple(results)
        return results[0]


def fluxes_data(
    boundaries: list = None,
    boundaries_sum: list = None,
    time_step_index=None,
    balance: bool = False,
    rc_solution: RCSolution = None,
):
    if rc_solution is not None:
        heat_flux = HeatFlux(rc_solution=rc_solution)
    else:
        heat_flux = HeatFlux()

    results = []
    labels = []

    sum_vector = None
    time_steps = None

    def add_to_sum(result: np.ndarray, _sum_vector):
        if _sum_vector is None:
            _sum_vector = np.zeros_like(result)
        return _sum_vector + result

    if boundaries is not None:
        for bc in boundaries:
            time_steps, y = heat_flux.boundary(bc, time_step_index)
            results.append(y)
            labels.append(bc.__class__.__name__)
            sum_vector = add_to_sum(y, sum_vector)
    if boundaries_sum is not None:
        if not isinstance(boundaries_sum[0], list):
            boundaries_sum = [boundaries_sum]
        for i, bc_groups in enumerate(boundaries_sum):
            time_steps, bc_sum = heat_flux.internal_heat_source(bc_groups[0], time_step_index)
            for bc in bc_groups[1:]:
                _, bc_add_on = heat_flux.internal_heat_source(bc, time_step_index)
                bc_sum += bc_add_on
            results.append(bc_sum)
            labels.append(f"{bc_groups[0].__class__.__name__}s: {i}")
            sum_vector = add_to_sum(bc_sum.reshape(-1, 1), sum_vector.reshape(-1, 1))
    if balance and time_steps is not None and sum_vector is not None:
        results.append(sum_vector)
        labels.append("Balance")
    return time_steps, results, labels


def plot_channel_balance(
    channel_nodes: list[Node] | ChannelNode,
    distributor: MassFlowNode,
    collector: MassFlowNode,
    time_step_index=None,
    start_date=datetime(2023, 1, 1),
    y_scale=1,
):
    """
    Plots the balance of the given channel nodes.

    Parameters
    ----------
    channel_nodes : list[ChannelNode] | ChannelNode
        The channel nodes to plot the sum of.
    distributor : MassFlowNode
        The distributor before the channel nodes.
        Used to calculate the heat flux that goes into the mass flow within the channel nodes.
    collector : MassFlowNode
        The collector after the channel nodes.
        Used to calculate the heat flux that goes into the mass flow within the channel nodes.
    time_step_index : int | slice | list, optional
        The time steps that should be calculated.

    """
    from pyrc.core.nodes import ChannelNode

    if isinstance(channel_nodes, ChannelNode):
        channel_nodes = [channel_nodes]
    heat_flux = HeatFlux()
    time_step_index = heat_flux.parse_time_step_index(time_step_index)
    exterior_direction = np.array([0, 0, -1])
    interior_direction = np.array([0, 0, 1])
    upper_direction = np.array([0, -1, 0])
    lower_direction = np.array([0, 1, 0])
    ex, interior, up, lo = heat_flux.heat_flux_directions(
        channel_nodes,
        directions=[exterior_direction, interior_direction, upper_direction, lower_direction],
        time_step_index=time_step_index,
    )
    # side_heat_flux_dist = heat_flux.heat_flux_directions([distributor],
    #                                                      directions=[np.array([1, 0, 0])],
    #                                                      time_step_index=time_step_index,
    #                                                      except_resistor_types=[MassTransport]
    #                                                      )
    # side_heat_flux_col = heat_flux.heat_flux_directions([collector],
    #                                                     directions=[np.array([-1, 0, 0])],
    #                                                     time_step_index=time_step_index,
    #                                                     except_resistor_types=[MassTransport]
    #                                                     )
    temp_dist = heat_flux.rc_solution.result_vectors[time_step_index, distributor.index]
    temp_col = heat_flux.rc_solution.result_vectors[time_step_index, collector.index]
    mass_flow = distributor.mass_flow
    spec_capacity = distributor.material.heat_capacity
    channel_heat_flux = mass_flow * spec_capacity * (temp_col - temp_dist)

    x = heat_flux.rc_solution.time_steps[time_step_index]
    x = seconds_to_dates(x, start_date)

    time_plot = TimePlot(
        x=x,
        ys=[ex, interior, (up + lo)],
        labels=["exterior", "interior", "inbetween"],
        y_scale=y_scale,
        y_title="Heat Flux / W",
    )
    time_plot.plot_stack()
    time_plot.ax.plot(
        time_plot.x,
        channel_heat_flux * time_plot.y_scale,
        label=["channel"],
        color="black",
        linewidth=time_plot.line_width,
    )
    time_plot.format()
    time_plot.show()


def plot_fluxes_accumulated(
    boundaries: list = None, boundaries_sum: list = None, time_step_index=None, plot_balance: bool = False
):
    x, ys, labels = fluxes_data(boundaries, boundaries_sum, time_step_index, plot_balance)

    fig, (ax1, ax2) = plt.subplots(nrows=2, ncols=1, sharex=True)

    for i, y in enumerate(ys):
        if labels[i] == "Balance":
            pass
        ax1.plot(x, y, labels[i])

    fig.tight_layout()
    ax1.set_xlabel("Time")
    ax1.set_ylabel("Positive Heat flux / W")
    ax2.set_ylabel("Negative Heat flux / W")
    for ax in (ax1, ax2):
        ax.grid(True)
        ax.legend()

    plt.show()
