#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

import time
from abc import abstractmethod
from collections.abc import Callable
from copy import copy
from datetime import datetime, timedelta
from typing import Any

import numpy as np

import gc
import os

from pyrc.core.components.capacitor import Capacitor
from pyrc.core.network import RCNetwork
from pyrc.core.nodes import Node
from pyrc.core.settings import Settings
from pyrc.core.components.templates import RCSolution
from pyrc.dataHandler.weather import WeatherData
from pyrc.tools.science import get_free_ram
from pyrc.visualization.plot import seconds_to_dates


def parse_direction(direction: np.ndarray | str) -> np.ndarray:
    """
    Makes one direction vector out of the input.

    Parameters
    ----------
    direction

    Returns
    -------
    np.ndarray :
        The corresponding array for the string (or numpy array).
    """
    if isinstance(direction, str):
        sign = 1
        if len(direction) == 2:
            if direction[0] == "-":
                sign = -1
            direction = direction[1]
        assert len(direction) == 1
        match direction.lower():
            case "x":
                direction = np.array((1, 0, 0))
            case "y":
                direction = np.array((0, 1, 0))
            case "z":
                direction = np.array((0, 0, 1))
            case _:
                raise ValueError("Invalid direction input.")
        direction = sign * direction
    return direction


class Filter:
    @abstractmethod
    def apply_filter(self, matrix: np.ndarray, axis=None) -> np.ndarray:
        pass


class FilterMixin(Filter):

    def __init__(self,
                 values: list | np.ndarray,
                 settings: Settings):
        self.network_settings = settings
        if isinstance(values, list):
            values = np.array(values)
        self.values: np.ndarray = values.flatten()
        self.number = self.values.shape[0]
        self.mask = np.full(self.number, False, dtype=bool)

    @abstractmethod
    def __copy__(self):
        return FilterMixin(self.values, self.network_settings)

    def invert(self):
        """
        Inverts the mask of the given axis.
        """
        self.mask = np.invert(self.mask)

    def _add_mask(self, mask):
        """
        Adds the mask to the current mask. So True + False = True

        Parameters
        ----------
        mask : np.ndarray
            The mask to add.
            Where True the current mask is also set to True.
        """
        self._apply_mask(mask, add=True)

    def _subtract_mask(self, mask):
        """
        Subtract the mask from the current mask. So True + False = False

        Parameters
        ----------
        mask : np.ndarray
            The mask to add.
            Where False the current mask is also set to False.
        """
        self._apply_mask(mask, add=False)

    def _apply_mask(self, mask_vector: np.ndarray, add=True):
        """
        Applies the provided boolean mask array to self.mask_row or self.mask_col using logical and/or (&/|).

        Parameters
        ----------
        mask_vector : np.ndarray
            The mask to add.
        add : bool, optional
            Whether to add the boolean mask array or subtract it.
            Add: current | mask_vector
            Not add: current & mask_vector

        """
        mask_vector = mask_vector.reshape(-1, )
        assert mask_vector.shape[0] == self.number
        if add:
            self.mask = mask_vector | self.mask
        else:
            self.mask = mask_vector & self.mask

    def apply_filter(self, matrix: np.ndarray, axis=None) -> np.ndarray:
        """
        Returns the filtered matrix.

        This does not save any data to the class so the RAM usage is not affected.

        Parameters
        ----------
        matrix : np.ndarray
            The matrix to be filtered.
        axis : int, optional
            If 0 the mask is applied to the row mask, to the column mask either.
            If None, it is added to the mask of same length.

        Returns
        -------
        np.ndarray :
            The filtered matrix.
        """
        if axis is None:
            if matrix.shape[0] == self.number:
                axis = 0
            elif matrix.shape[1] == self.number:
                axis = 1
            else:
                raise ValueError("Length of mask_vector must match one of the dimensions of rows or columns.")
        if axis == 0:
            assert matrix.shape[0] == self.number
            return matrix[self.mask]
        else:
            assert matrix.shape[1] == self.number
            return matrix[:, self.mask]

    def __add__(self, other):
        import copy
        result = copy.copy(self)
        result._add_mask(other.mask)
        return result

    @property
    def filtered_values(self) -> np.ndarray:
        return self.values[self.mask]


class NodeFilter(FilterMixin):

    def __init__(self,
                 nodes: list[Capacitor] | np.ndarray,
                 settings: Settings):
        """
        Initially: filter out everything.

        Parameters
        ----------
        nodes : list[Capacitor] | np.ndarray
            The nodes which solutions are represented in the columns.
        settings: Settings
            The ``Settings`` object that matches the settings of the network.
            Is used to get the start_date and the weather_data_path
        """
        super().__init__(values=nodes, settings=settings)

    def __copy__(self):
        return NodeFilter(self.values, self.network_settings)

    def add_nodes(self, nodes: list[Node] | str):
        """
        Adds the nodes to the current node mask. If string is given, the corresponding group is added.

        Parameters
        ----------
        nodes : list[Node] | Node | np.ndarray
            The list with the node objects.
        """
        if isinstance(nodes, Node):
            nodes = [nodes]
        elif isinstance(nodes, np.ndarray):
            nodes = nodes.tolist()
        assert isinstance(nodes, list)
        indices = [node.index for node in nodes]
        self.mask[indices] = True

    def subtract_nodes(self, nodes: list[Node] | str):
        """
        Subtract the nodes to the current node mask. If string is given, the corresponding group is subtracted.

        Parameters
        ----------
        nodes : list[Capacitor] | Node | np.ndarray
            The list with the node objects.
        """
        if isinstance(nodes, Node):
            nodes = [nodes]
        elif isinstance(nodes, np.ndarray):
            nodes = nodes.tolist()
        indices = [node.index for node in nodes]
        self.mask[indices] = False

    def apply_filter(self, matrix: np.ndarray, axis=1) -> np.ndarray:
        return super().apply_filter(matrix, axis)


class WeatherFilter(FilterMixin):

    def __init__(self,
                 settings: Settings):
        # TODO: create datetime vector and pass it to super init
        super().__init__(values=[], settings=settings)
        self._weather = None

    def __copy__(self):
        result = WeatherFilter(self.network_settings)
        result._weather = self._weather
        return result

    @property
    def weather(self) -> WeatherData:
        if self._weather is None:
            self._weather = self.network_settings.weather_data
        return self._weather


class TimeFilter(FilterMixin):
    """
    A class that contains the filter for one RCSolution, especially nodes (columns) and dates (rows).
    """

    def __init__(self,
                 seconds: np.ndarray,
                 settings: Settings,
                 time_accuracy="ms",
                 initial_mask_value=False):
        """
        Initially: filter out everything.

        Parameters
        ----------
        seconds : np.ndarray
            The row index as increasing seconds.
        settings : Settings
            The ``Settings`` object that matches the settings of the network.
            Is used to get the start_date and the weather_data_path
        time_accuracy : str, optional
            The time accuracy used in numpy.datetime64 calculations. E.g.: "ms", "s", "m"
        """
        self.time_accuracy = time_accuracy
        time_mult = np.timedelta64(1, "s") / np.timedelta64(1, time_accuracy)
        values: np.ndarray = (np.datetime64(settings.start_date)
                              + np.timedelta64(1, time_accuracy) * np.array(seconds) * time_mult)
        super().__init__(values=values, settings=settings)
        if initial_mask_value:
            self.invert()

    def __copy__(self):
        result: TimeFilter = type(self).__new__(type(self))
        # Copy all attributes from parent class
        super(TimeFilter, result).__init__(self.values, self.network_settings)
        result.mask = self.mask.copy()
        # Copy specific attributes from this class
        result.time_accuracy = self.time_accuracy
        # Copy any other attributes you have
        return result

    @property
    def datetime(self):
        """
        Returns the date times from filtered values as vector with datetime.datetime objects (instead of np.datetime64).

        Returns
        -------
        np.ndarray(datetime.datetime) :
            Date times of filtered values.
        """
        filtered_values = self.values[self.mask]
        return np.array([dt.astype(datetime) for dt in filtered_values])

    def daterange(self, datetime1, datetime2=None):
        """
        Filters rows using a datetime range. The current row mask is overwritten.

        If datetime2 is None, the same day is used as end of the range.
        If datetime2 is not None, the exact datetime is used as end (included). So if you want the same result as
        with "None" then you have to use datetime1 + np.timedelta64(1, "D").

        Parameters
        ----------
        datetime1 : np.datetime64 | datetime.datetime | Any
            The start of the range. Is included in the range.
            Is converted to np.datetime64.
        datetime2 : np.datetime64 | datetime.datetime | Any, optional
            The end of the range. Is included in the range (but with time. So if you want the whole day you have to
            use the next day at 00:00:00).
            If None, the same day as datetime1 is used as end of the range.
            Is converted to np.datetime64.

        Examples
        --------
        To apply a range of three days:
            self.range(datetime(2022,4,1), "2022-04-03")
        which will result in the range 1.4.22 00:00:00 up to 4.4.22 00:00:00.
        """
        datetime1 = np.datetime64(datetime1)
        if datetime2 is None:
            datetime2 = datetime1.astype("datetime64[D]") + np.timedelta64(1, "D")
        else:
            datetime2 = np.datetime64(datetime2)
            # if datetime2 - datetime2.astype("datetime64[D]") == 0:
            #     # only day is given, no hours/minutes/seconds
            #     datetime2 = datetime2.astype("datetime64[D]") + np.timedelta64(1, "D")

        mask = ((self.values >= datetime1.astype(f"datetime64[{self.time_accuracy}]"))
                & (self.values <= datetime2.astype(f"datetime64[{self.time_accuracy}]")))

        self._add_mask(mask)

    def apply_filter(self, matrix: np.ndarray, axis=0) -> np.ndarray:
        return super().apply_filter(matrix, axis)


class NetworkFilter(Filter):
    """
    Combines a TimeFilter for the row and a NodeFilter for the columns to one filter.
    """

    def __init__(self,
                 seconds: np.ndarray,
                 nodes: list[Capacitor],
                 settings: Settings,
                 time_accuracy="ms"):
        """
        Initially: filter out everything.

        Parameters
        ----------
        seconds : np.ndarray
            The row index as increasing seconds.
        nodes : list[Capacitor]
            The nodes which solutions are represented in the columns.
        settings: Settings
            The ``Settings`` object that matches the settings of the network.
            Is used to get the start_date and the weather_data_path
        """
        self.number_rows = len(seconds.flatten())
        self.number_columns = len(nodes)
        self.network_settings: Settings = settings

        self.filter_row: TimeFilter = TimeFilter(seconds, self.network_settings, time_accuracy)
        self.filter_column: NodeFilter = NodeFilter(nodes, self.network_settings)
        self.filter_column.invert()  # activate all nodes initially

    def apply_filter(self, matrix, axis=None):
        if axis is None:
            # For maximum performance always filter columns first and then rows! NumPy arrays use row-major (C-style)
            # memory layout by default.
            column_filtered = self.apply_column_filter(matrix)
            return self.apply_row_filter(column_filtered)
        elif axis == 0:
            return self.apply_row_filter(matrix)
        else:
            return self.apply_column_filter(matrix)

    def apply_row_filter(self, matrix):
        return self.filter_row.apply_filter(matrix)

    def apply_column_filter(self, matrix):
        return self.filter_column.apply_filter(matrix)


class FilteredRCSolution:

    def __init__(self, rc_solution: RCSolution, filter_obj: Filter):
        self._rc_solution: RCSolution = rc_solution
        self.filter: Filter = filter_obj

    def __getattr__(self, item):
        """
        Returns the attribute from RCSolution. But for some attributes it returns the filtered version.
        """
        attr = getattr(self._rc_solution, item)

        if item in [
            "result_vectors",
            "temperature_vectors",
            "y"
        ]:
            attr = self.filter.apply_filter(attr)
        elif item in [
            "t",
            "time_steps",
            "input_vectors"
        ]:
            if isinstance(self.filter, TimeFilter):
                attr = self.filter.apply_filter(attr)
            elif isinstance(self.filter, NetworkFilter):
                attr = self.filter.apply_row_filter(attr)
        return attr


class FastParser:
    """
    Class to process the solutions of an RC-network.

    Here all calculations for a single RC-network are performed. Also, this class should make filtering easy and the
    processing fast without a lot of RAM usage. For this, the calculation should be done in a queue and after this
    the network solution is removed from the memory to free RAM and only the requested calculation/solution data is
    kept in memory.

    To compare several RCNetwork Solutions use the class `MultiParser` which processes multiple FastParser instances.
    """

    _total_reserved_memory = 0  # in bytes

    def __init__(self,
                 network_solution_path_tuple: tuple[RCNetwork, str],
                 solution_size=None):
        self.network = network_solution_path_tuple[0]
        self.solution_path = network_solution_path_tuple[1]  # the pickle file of the solution containing the RCSolution
        self._solution_size = solution_size

        self._blocked_ram = 0

        self._filters: list[NetworkFilter | TimeFilter | NodeFilter] = []
        self._filter_names: list[str] = []

    def __copy__(self):
        result: FastParser = type(self).__new__(type(self))
        result.network = self.network
        result.solution_path = self.solution_path
        result._solution_size = self._solution_size
        result._blocked_ram = self._blocked_ram

        result._filters = [copy(f) for f in self._filters]
        result._filter_names = self._filter_names
        return result

    def __parse_filter_index(self, entry):
        if isinstance(entry, str):
            entry = self._filter_names.index(entry)
        return entry

    @property
    def result_vectors(self):
        if not self.solution_exist:
            self.load_solution_safe()
        return self.network.rc_solution.result_vectors

    @property
    def time_vector(self):
        if not self.solution_exist:
            self.load_solution_safe()
        return np.array(seconds_to_dates(self.network.rc_solution.time_steps,
                                         self.network.settings.weather_data.start_time))

    @property
    def input_vectors(self):
        if not self.solution_exist:
            self.load_solution_safe()
        return self.network.rc_solution.input_vectors

    @property
    def filters(self) -> list[NetworkFilter | TimeFilter | NodeFilter]:
        return self._filters

    @property
    def time_filters(self) -> list[TimeFilter]:
        return [f for f in self.filters if isinstance(f, TimeFilter)]

    @property
    def network_filter(self) -> list[NetworkFilter]:
        return [f for f in self.filters if isinstance(f, NetworkFilter)]

    @property
    def node_filter(self) -> list[NodeFilter]:
        return [f for f in self.filters if isinstance(f, NodeFilter)]

    def filter(self, entry: int | Any | str = -1) -> NetworkFilter | TimeFilter | NodeFilter:
        """
        Returns a `Filter` object specified by entry. If entry is not given the last `Filter` is used.

        Parameters
        ----------
        entry : int | Any, optional
            If an int the index of the filter in the filter list self._filter.
            If a string the name of the filter in self._filter_names. Is parsed to an index.
            If None, the last `Filter` is used.
        """
        return self._filters[self.__parse_filter_index(entry)]

    def _add_filter(self, filter_class: type, name: str = None):
        """
        Adds a new `Filter` object. It initially filters out everything (empty matrix).

        The `Filter` objects are used to create different sets of data using the same data source. You can
        manipulate the filter/mask using the methods of the `Filter` class.

        Parameters
        ----------
        filter_class : type
            The Filter class to be added to self._filters
        name : str, optional
            The name of the filter to add.
            If None, the filter is only accessible by its index.

        Returns
        -------
        int :
            The index of the just added `Filter` object that can be used to get the filter using
            self.filter(index)
        """
        if not self.solution_exist:
            self.load_solution_safe()
        assert self.network.rc_solution.exist
        kwargs = {"settings": self.network.settings}
        if filter_class is TimeFilter or filter_class is NetworkFilter:
            kwargs["seconds"] = self.network.rc_solution.time_steps
        if filter_class is NodeFilter or filter_class is NetworkFilter:
            kwargs["nodes"] = self.network.nodes
        self._filters.append(filter_class(
            **kwargs
        ))
        self._filter_names.append(name)
        return len(self.filters) - 1

    def add_filter(self, name: str = None, return_index=False):
        """
        Adds a new ``NetworkFilter`` object. It initially filters out everything (empty matrix).

        The ``NetworkFilter`` objects are used to create different sets of data using the same data source. You can
        manipulate the filter/mask using the methods of the ``NetworkFilter`` class.

        Parameters
        ----------
        name : str, optional
            The name of the filter to add.
            If None, the filter is only accessible by its index.
        return_index : bool, optional
            If True the index of the added ``NetworkFilter`` is returned.

        Returns
        -------
        None | int :
            If return_index: the index of the just added ``NetworkFilter`` object that can be used to get the filter using
            self.filter(index)
        """
        result = self._add_filter(NetworkFilter, name)
        if return_index:
            return result

    def add_time_filter(self, name: str = None, return_index=False):
        """
        Adds a new `TimeFilter` object. It initially filters out everything (empty matrix).

        The `TimeFilter` objects are used to create different sets of data using the same data source. You can
        manipulate the filter/mask using the methods of the `TimeFilter` class.

        Parameters
        ----------
        name : str, optional
            The name of the filter to add.
            If None, the filter is only accessible by its index.
        return_index : bool, optional
            If True the index of the added ``TimeFilter`` is returned.

        Returns
        -------
        None | int :
            If return_index: the index of the just added `TimeFilter` object that can be used to get the filter using
            self.filter(index)
        """
        result = self._add_filter(TimeFilter, name)
        if return_index:
            return result

    def add_node_filter(self, name: str = None, return_index=False):
        """
        Adds a new `NodeFilter` object. It initially filters out everything (empty matrix).

        The `NodeFilter` objects are used to create different sets of data using the same data source. You can
        manipulate the filter/mask using the methods of the `NodeFilter` class.

        Parameters
        ----------
        name : str, optional
            The name of the filter to add.
            If None, the filter is only accessible by its index.
        return_index : bool, optional
            If True the index of the added ``NodeFilter`` is returned.

        Returns
        -------
        None | int :
            If return_index: the index of the just added `NodeFilter` object that can be used to get the filter using
            self.filter(index)
        """
        result = self._add_filter(NodeFilter, name)
        if return_index:
            return result

    def remove_filter(self, entry: int | Any = -1):
        """
        Removes the desired filter from the filters list.

        Remember: Previously passed filter indexes might change.

        Parameters
        ----------
        entry : int | Any, optional
            If an int the index of the filter in the filter list self._filter.
            If a string the name of the filter in self._filter_names. Is parsed to an index.
            If None, the last filter is used.
        """
        index = self.__parse_filter_index(entry)
        for l in [self._filters, self._filter_names]:
            l.pop(index)

    def add_time_filters(self,
                         days=None,
                         weeks=None,
                         months=None,
                         years=None,
                         filter_name_add_on="",
                         return_names=False):
        """
        Adds time filters for all passed days, weeks, months and years.

        The time filters are named like "day{index of this day in list}{filter_name_add_on}".
        The weeks, months and years are represented by their start day.

        If no value is passed no filter is created.

        Parameters
        ----------
        days : list[datetime] | datetime, optional
            The days that should be plotted.
        weeks : list[datetime] | datetime, optional
            The weeks that should be plotted.
            Each week is represented by its start date.
        months : list[datetime] | datetime, optional
            The months that should be plotted.
            Each month is represented by its start date.
        years : list[datetime] | datetime, optional
            The years that should be plotted.
            Each year is represented by its start date.
        filter_name_add_on : str, optional
            A name add-on for the time filter that is added.
        return_names : bool, optional
            If True the names of the time filters are returned as dictionary with the entries days, weeks,
            months and years and the corresponding list.

        Returns
        -------
        dict | None :
            If return_names, a dict with the layout:
            {"days": [], "weeks": [], "months": [], "years": []}
            with the names of the filters in the lists.
        """
        import calendar
        names = {
            "days": days or [],
            "weeks": weeks or [],
            "months": months or [],
            "years": years or [],
        }
        for i, day in enumerate(days):
            names["days"].append(f"day{i}{filter_name_add_on}")
            self.add_time_filter(names["days"][-1])
            time_filter: TimeFilter = self.filter(names["days"][-1])
            time_filter.daterange(datetime1=day)
        for i, week in enumerate(weeks):
            names["weeks"].append(f"week{i}{filter_name_add_on}")
            self.add_time_filter(names["weeks"][-1])
            time_filter: TimeFilter = self.filter(names["weeks"][-1])
            time_filter.daterange(datetime1=week, datetime2=week + timedelta(days=7))
        for i, dt in enumerate(months):
            names["months"].append(f"month{i}{filter_name_add_on}")
            self.add_time_filter(names["months"][-1])
            time_filter: TimeFilter = self.filter(names["months"][-1])
            if dt.month == 12:
                next_year = dt.year + 1
                next_month = 1
            else:
                next_year = dt.year
                next_month = dt.month + 1

            max_day = calendar.monthrange(next_year, next_month)[1]
            next_day = min(dt.day, max_day)

            datetime2 = dt.replace(year=next_year, month=next_month, day=next_day)
            time_filter.daterange(datetime1=dt, datetime2=datetime2)
        for i, dt in enumerate(years):
            names["years"].append(f"year{i}{filter_name_add_on}")
            self.add_time_filter(names["years"][-1])
            time_filter: TimeFilter = self.filter(names["years"][-1])
            # Handle leap year edge case for Feb 29
            if dt.month == 2 and dt.day == 29 and not calendar.isleap(dt.year + 1):
                new_dt = dt.replace(year=dt.year + 1, month=3, day=1)
            else:
                new_dt = dt.replace(year=dt.year + 1)
            time_filter.daterange(datetime1=dt, datetime2=new_dt)
        if return_names:
            return names

    def _block_memory(self):
        self._blocked_ram = self.solution_size * 1.01
        FastParser._total_reserved_memory += self.solution_size

    def _free_memory(self):
        FastParser._total_reserved_memory -= self._blocked_ram
        self._blocked_ram = 0

    @property
    def solution_exist(self) -> bool:
        return self.network.rc_solution.exist

    @property
    def solution_size(self):
        if self._solution_size is None:
            if os.path.isfile(self.solution_path):
                self._solution_size = os.path.getsize(self.solution_path)
            else:
                print(f"The solution size is estimated to be 10 GB ({self.solution_path})")
                self._solution_size = 10 * 1024 ** 3
        return self._solution_size

    def load_solution(self):
        """
        Loads solution, but only if enough RAM is available.

        Raises
        ------
        MemoryError :
            If not enough memory is available.
        """
        if (get_free_ram() - FastParser._total_reserved_memory) > self.solution_size:
            self._block_memory()
            assert self.network.rc_solution.load_solution(
                self.solution_path), f"Solution file {self.solution_path} not found"
            self._free_memory()
        else:
            raise MemoryError("Not enough free memory to load solution.")

    def load_solution_safe(self):
        """
        Like load_solution, but it waits for up to 1 hour for enough RAM.

        Raises
        ------
        MemoryError :
            If not enough memory is available within 1 hour.
        """
        counter = 0
        success = False
        while counter <= 3600:
            if (get_free_ram() - FastParser._total_reserved_memory) > self.solution_size:
                self.load_solution()
                success = True
                break
            time.sleep(1)
            counter += 1
        if not success:
            raise MemoryError("Not enough free memory to load solution.")

    def free_ram(self):
        """
        Deletes the network solution from memory without deleting any calculated/filtered/requested data.

        #TODO: Append this function with all variables that are existing in the state of this class containing the
          whole solution data. The garbage collection has to be able to free the RAM from the most data!
        """
        self.network.rc_solution.delete_solutions(True)

        # garbage collection
        gc.collect()

    def map(self, function: Callable, *args, **kwargs):
        """
        Maps the passed function to every filter and returns the result as a tuple.

        Parameters
        ----------
        function : Callable
            The function to map on every filter. The first argument is a FilteredRCSolution.

        Returns
        -------
        tuple :
            The results for each filter.
        """
        result = []
        for filter_obj in self.filters:
            filtered_solution = FilteredRCSolution(self.network.rc_solution, filter_obj)
            result.append(function(filtered_solution, *args, **kwargs))
        return tuple(result)


class MultiParser:
    """
    Class to process multiple solutions of an RC-network (FastParser instances).

    It behaves like FastParser, but it always executes all calls to every parser instance defined in the init.

    This should be used with brain!
    Only compare networks with same hashes or with comparable layout.
    """

    def __init__(self, objects: list):
        """
        Objects can be a list of FastParser instances or network solution-path tuples.

        Parameters
        ----------
        objects : list[FastParser] | list[tuple[RCNetwork, str]]
            These objects are compared to each other (same calculations are done for all of them).
        """
        assert isinstance(objects, list)
        self.parsers: list[FastParser] = []
        for obj in objects:
            if isinstance(obj, FastParser):
                self.parsers.append(obj)
            elif isinstance(obj, tuple):
                obj: tuple[RCNetwork, str]
                self.parsers.append(FastParser(obj))
            else:
                raise TypeError(f"Object {obj} is not a FastParser instance or a tuple to create it.")

    def __getattr__(self, name):
        def multi_method(*args, **kwargs):
            results = []
            for parser in self.parsers:
                attr = getattr(parser, name)
                if callable(attr):
                    results.append(attr(*args, **kwargs))
                else:
                    results.append(attr)
            return results

        first_attr = getattr(self.parsers[0], name)
        if callable(first_attr):
            return multi_method
        else:
            return [getattr(parser, name) for parser in self.parsers]
