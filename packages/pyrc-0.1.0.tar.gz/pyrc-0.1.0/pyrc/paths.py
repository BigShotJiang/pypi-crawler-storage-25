#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------
import os

# Create package directory and run folder inside it.
package_dir = os.path.dirname(os.path.abspath(__file__))
run_folder = os.path.join(package_dir, "run")
os.makedirs(run_folder, exist_ok=True)
