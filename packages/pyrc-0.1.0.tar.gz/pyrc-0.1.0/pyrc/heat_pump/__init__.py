#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

from pyrc.heat_pump.heat_pump import COP, carnot_heat_pump

__all__ = ["COP", "carnot_heat_pump"]