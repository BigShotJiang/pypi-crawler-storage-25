#  -------------------------------------------------------------------------------
#       Copyright (C) 2026  Joel Kimmich, Tim Jourdan
#  ------------------------------------------------------------------------------
#   License
#       This file is part of PyRC, distributed under GPL-3.0-or-later.
#  ------------------------------------------------------------------------------

import numpy as np


def carnot_heat_pump(source_temperature, supply_temperature):
    """
    Calculates the Carnot efficiency.

    Parameters
    ----------
    source_temperature : float | np.ndarray | list
        The temperature in Kelvin of the source.
    supply_temperature : float | np.ndarray | list
        The temperature in Kelvin of the supply water.

    Returns
    -------
    float | np.ndarray :
        The Carnot efficiency.
        If its an array with
    """
    source_temperature = np.asarray(source_temperature)
    supply_temperature = np.asarray(supply_temperature)

    source_temperature = source_temperature.reshape(-1, 1)
    supply_temperature = supply_temperature.reshape(1, -1)

    result = supply_temperature.reshape(1, -1) / np.abs(
        source_temperature.reshape(-1, 1) - supply_temperature.reshape(1, -1))
    return np.squeeze(result)


class COP:
    def __init__(self):
        self.exergetic_efficency = 0.45  # COP_real / COP_Carnot
        self.overtemperature_delta = 3  # Is added to the supply temperature because of loss in heat transfer

    def cop_change(self, new_temperature, old_temperature, supply_water_temperature):
        """
        Returns how much more Watt per Watt is created from a heat pump when the source temperature changes.

        Returns each supply_water_temperature in a row (supply_temp x time_steps).

        Parameters
        ----------
        new_temperature : float | int | np.ndarray | list
            The new source temperature in Kelvin.
        old_temperature : float | int | np.ndarray | list
            The temperature in Kelvin to compare the new temperature with.
        supply_water_temperature : float | int
            The supply water temperature in Kelvin.
            Used to calculate the carnot efficiency.

        Returns
        -------
        float | np.ndarray:
            The change of the COP with the new temeprature.
            > 1 if the COP increases
            < 1 if the COP decreases
            = 1 if no change at all.
            If it's an array with multiple dimensions each row is with a fixed supply water temperature.
        """
        supply = np.asarray(supply_water_temperature) + self.overtemperature_delta
        cop_old = self.exergetic_efficency * carnot_heat_pump(supply, old_temperature)
        cop_new = self.exergetic_efficency * carnot_heat_pump(supply, new_temperature)

        return np.where((cop_old >= 0.4) & (cop_new <= 35), cop_new / cop_old, np.nan)
