<h1 align="center">
<img src="https://codeberg.org/IGTE/pyrc/raw/commit/b356e77f85cf33decd9ebfa2fef8a93f49db6aad/docs/source/_static/logo_dark.svg" alt="PyRC Logo" height="65">
</h1><br>

[![PyPI - Version](https://img.shields.io/pypi/v/pyrc)](https://pypi.org/project/pyrc/)
[![PyPI - License](https://img.shields.io/pypi/l/pyrc)](https://pypi.org/project/pyrc/)
[![DOI](https://img.shields.io/badge/DOI-10.18419%2Fdarus--5765-blue)](https://dx.doi.org/10.18419/darus-5765)
[![Typing](https://img.shields.io/pypi/types/pyrc)](https://pypi.org/project/pyrc/)

PyRC is a package for modeling and solving dynamic thermal RC-network problems. It brings the simplicity of
Python to physics-based dynamic models that can be represented as ODEs and solved efficiently by numerical algorithms.
The automation of geometric thermal problems in PyRC makes it easy to combine existing Python scripts with accurate,
physics-based dynamic models.

PyRC started as research software, built from scientists for scientists, and later for everyone. It was initiated at
the [Institute for Building Energetics, Thermotechnology and Energy Storage (IGTE)](https://www.igte.uni-stuttgart.de)
at the University of Stuttgart by Joel Kimmich and Tim Jourdan.

## When to use PyRC

- Multidimensional dynamic thermal problems
- Systems where time scales span nanoseconds to decades
- Avoiding the complexity of CFD mesh generation
- Thermal networks with unstructured topology
- Extending or customizing solvers directly in Python
- Parameterizing large-scale RC-networks with up to thousands of elements
- Parameterizing small-scale RC-networks with only a few elements
- Time-dependent system matrices or boundary conditions
- Solving partial differential equations via lumped-parameter models
- Creating geometric networks with visual aid of VPython
- Obtaining the state-space representation of complex systems with hundreds or thousands of capacities and
  resistors — even without solving the ODE

## Installation

```bash
pip install pyrc
```

## Performance

- Network with weather data as boundary conditions and 280 radiation source terms; simulating one year with a
  maximum time step of 0.4 s on a single core at 3.2 GHz:
  - 3'302 capacities, 10'717 resistances
  - Pre-simulation to initialize: 2.5 hours (~7 simulated days)
  - Total simulation time: ~6.5 days
- Smaller systems (~400 nodes) run 1'000 times faster than simulated time.
- Largest simulated system: over 6'000 capacitors and 30'000 resistors.

## Fun Facts

- In principle, PyRC works not only for thermal problems but also for electrical ones. However, this has not yet been
  tested, and an `Induction` class modeling the behaviour of an electrical coil is still missing. Contributions
  are welcome!
- Even without solving the ODE, PyRC can be used to obtain the state-space representation of complex systems with
  hundreds or thousands of capacities and resistors.

## Publications

First publication:
> Kimmich, J. & Jourdan, T.: "Python Package for Generating Dynamic Systems and Simulating Resistance-Capacitance
> Networks (PyRC)", DaRUS, 2026. <https://dx.doi.org/10.18419/darus-5765>

Poster presented at the 1st Stuttgart Research Software Day, 2026:
> Kimmich, J. & Jourdan, T.: "PyRC", Zenodo, 2026. <https://doi.org/10.5281/zenodo.18832971>

Further publications are in progress.

## Notes

- PyRC was first applied to simulate a dynamic thermal system with constant mass flow under boundary conditions
  from weather data (solar radiation and ambient temperature) over a full year, including parameter studies.
- More extensive testing beyond the cases covered so far is necessary. Contributions in this regard are
  particularly welcome.

## Contributing

See [CONTRIBUTING.rst](https://codeberg.org/IGTE/pyrc/src/branch/main/CONTRIBUTING.rst) for how to contribute to PyRC.

## License

See [LICENSE.txt](https://codeberg.org/IGTE/pyrc/src/branch/main/LICENSE.txt) for the license.

## Funding

Funded by the Federal Ministry for Economic Affairs and Energy (Bundesministerium für Wirtschaft und Energie), Germany.