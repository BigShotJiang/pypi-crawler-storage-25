import yaml
from click.testing import CliRunner

from oppie.cli import cli

# Input sequences for init tests:
# Instance type (1=repo) + Provider (1=local) + LLM backend (1=local, accept defaults) + Test? (n) + Context? (n)
_LOCAL_LLM_INPUT = '1\n1\n1\nllama-3.2-8b\nhttp://localhost:8080/v1\nn\nn\n'


def test_init_local_minimal(tmp_path):
    home = tmp_path / '.oppie'
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ['--home', str(home), 'init'],
        input=_LOCAL_LLM_INPUT,
    )

    assert result.exit_code == 0, result.output
    assert (home / '.oppie-marker').exists()
    config = yaml.safe_load((home / 'config' / 'oppie.yaml').read_text())
    assert config['instance_type'] == 'repo'
    assert config['provider']['type'] == 'local'
    assert 'llm' in config
    assert config['llm']['backend'] == 'openai-compatible'
    assert 'oppie is ready' in result.output


def test_init_fails_if_instance_exists(tmp_path):
    home = tmp_path / '.oppie'
    home.mkdir()
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ['--home', str(home), 'init'],
    )

    assert result.exit_code != 0
    assert 'Instance already exists' in result.output


def test_init_portfolio_type(tmp_path):
    home = tmp_path / '.oppie'
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ['--home', str(home), 'init'],
        input='2\n1\n1\nllama-3.2-8b\nhttp://localhost:8080/v1\nn\nn\n',
    )

    assert result.exit_code == 0, result.output
    config = yaml.safe_load((home / 'config' / 'oppie.yaml').read_text())
    assert config['instance_type'] == 'portfolio'


def test_init_with_context_docs(tmp_path):
    home = tmp_path / '.oppie'
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ['--home', str(home), 'init'],
        input='1\n1\n1\nllama-3.2-8b\nhttp://localhost:8080/v1\nn\ny\n',
    )

    assert result.exit_code == 0, result.output
    context_dir = home / 'context'
    assert (context_dir / 'vision.md').exists()
    assert (context_dir / 'roadmap.md').exists()
    assert (context_dir / 'metrics.md').exists()
    assert (context_dir / 'prioritization.md').exists()


def test_init_shows_unified_prompt_examples(tmp_path):
    home = tmp_path / '.oppie'
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ['--home', str(home), 'init'],
        input=_LOCAL_LLM_INPUT,
    )

    assert result.exit_code == 0, result.output
    assert 'just type what you want' in result.output
    assert 'question' in result.output
    assert 'instruction' in result.output
    assert 'status report' in result.output


def test_init_linear_provider(tmp_path, monkeypatch):
    home = tmp_path / '.oppie'
    from unittest.mock import MagicMock, patch

    from oppie.providers.linear.config import LinearProviderConfig

    # Mock extras to report linear available
    monkeypatch.setattr(
        'oppie.cli.commands.init.extras_available',
        lambda: {'linear': True, 'openai': True, 'anthropic': True},
    )

    mock_config = LinearProviderConfig(
        type='linear',
        team_id='team-123',
        project_id='proj-456',
        api_key='lin_api_test',
    )
    mock_provider = MagicMock()
    mock_provider._config = mock_config

    with patch(
        'oppie.providers.linear.provider.LinearProvider.setup',
        return_value=mock_provider,
    ):
        runner = CliRunner()
        # Choose: repo, linear provider, no sync, LLM local (accept defaults), no test, no context
        result = runner.invoke(
            cli,
            ['--home', str(home), 'init'],
            input='1\n2\nn\n1\nllama-3.2-8b\nhttp://localhost:8080/v1\nn\nn\n',
        )

    assert result.exit_code == 0, result.output
    config = yaml.safe_load((home / 'config' / 'oppie.yaml').read_text())
    assert config['provider']['type'] == 'linear'
    assert config['provider']['team_id'] == 'team-123'
    mock_provider.close.assert_called_once()


def test_init_fails_without_openai_extra(tmp_path, monkeypatch):
    home = tmp_path / '.oppie'
    monkeypatch.setattr(
        'oppie.cli.commands.init.extras_available',
        lambda: {'linear': False, 'openai': False, 'anthropic': True},
    )
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ['--home', str(home), 'init'],
        input='1\n1\n1\n',
    )

    assert result.exit_code != 0
    assert "pip install 'oppie[openai]'" in result.output


def test_init_fails_without_anthropic_extra(tmp_path, monkeypatch):
    home = tmp_path / '.oppie'
    monkeypatch.setattr(
        'oppie.cli.commands.init.extras_available',
        lambda: {'linear': False, 'openai': True, 'anthropic': False},
    )
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ['--home', str(home), 'init'],
        input='1\n1\n2\n',
    )

    assert result.exit_code != 0
    assert "pip install 'oppie[anthropic]'" in result.output
