import pytest
from pydantic import ValidationError

from oppie.config import (
    InstanceType,
    LLMBackend,
    ProviderType,
    load_config,
    load_oppie_config,
    load_provider_credentials,
)
from tests.config.conftest import write_yaml

_LLM_DATA = {'backend': 'openai-compatible', 'model': 'test'}


def test_load_oppie_config_missing_llm_raises(tmp_path):
    write_yaml(
        tmp_path / 'oppie.yaml',
        {'instance_type': 'repo', 'provider': {'type': 'local'}},
    )

    with pytest.raises(ValidationError, match='llm'):
        load_oppie_config(tmp_path)


def test_load_oppie_config_minimal(tmp_path):
    write_yaml(
        tmp_path / 'oppie.yaml',
        {'instance_type': 'repo', 'provider': {'type': 'local'}, 'llm': _LLM_DATA},
    )
    config = load_oppie_config(tmp_path)

    assert config.instance_type == InstanceType.REPO
    assert config.provider.provider_type == ProviderType.LOCAL
    assert config.llm.backend == LLMBackend.OPENAI_COMPATIBLE


def test_load_oppie_config_full(tmp_path):
    write_yaml(
        tmp_path / 'oppie.yaml',
        {
            'instance_type': 'portfolio',
            'provider': {'type': 'linear', 'team_id': 'team-123'},
            'llm': {
                'backend': 'openai-compatible',
                'model': 'llama-3.2-8b',
                'endpoint': 'http://localhost:8080/v1',
                'max_tokens': 4000,
                'temperature': 0.5,
            },
        },
    )
    config = load_oppie_config(tmp_path)

    assert config.instance_type == InstanceType.PORTFOLIO
    assert config.provider.provider_type == ProviderType.LINEAR
    assert config.llm is not None
    assert config.llm.backend == LLMBackend.OPENAI_COMPATIBLE
    assert config.llm.model == 'llama-3.2-8b'
    assert config.llm.endpoint == 'http://localhost:8080/v1'
    assert config.llm.max_tokens == 4000
    assert config.llm.temperature == 0.5


def test_load_oppie_config_missing_file(tmp_path):
    with pytest.raises(FileNotFoundError, match='Config file not found'):
        load_oppie_config(tmp_path)


def test_load_oppie_config_empty_file(tmp_path):
    (tmp_path / 'oppie.yaml').write_text('')

    with pytest.raises(ValueError, match='Config file is empty'):
        load_oppie_config(tmp_path)


def test_load_oppie_config_invalid_instance_type(tmp_path):
    write_yaml(
        tmp_path / 'oppie.yaml',
        {'instance_type': 'banana', 'provider': {'type': 'local'}},
    )

    with pytest.raises(ValidationError, match='instance_type'):
        load_oppie_config(tmp_path)


def test_load_oppie_config_invalid_provider_type(tmp_path):
    write_yaml(
        tmp_path / 'oppie.yaml',
        {'instance_type': 'repo', 'provider': {'type': 'jira'}},
    )

    with pytest.raises(ValidationError, match='provider'):
        load_oppie_config(tmp_path)


def test_load_oppie_config_invalid_llm_backend(tmp_path):
    write_yaml(
        tmp_path / 'oppie.yaml',
        {
            'instance_type': 'repo',
            'provider': {'type': 'local'},
            'llm': {'backend': 'gpt', 'model': 'x'},
        },
    )

    with pytest.raises(ValidationError, match='backend'):
        load_oppie_config(tmp_path)


def test_load_oppie_config_ignores_unknown_keys(tmp_path):
    write_yaml(
        tmp_path / 'oppie.yaml',
        {
            'instance_type': 'repo',
            'provider': {'type': 'local'},
            'llm': _LLM_DATA,
            'future_feature': True,
        },
    )
    config = load_oppie_config(tmp_path)

    assert config.instance_type == InstanceType.REPO


def test_load_oppie_config_invalid_temperature(tmp_path):
    write_yaml(
        tmp_path / 'oppie.yaml',
        {
            'instance_type': 'repo',
            'provider': {'type': 'local'},
            'llm': {
                'backend': 'anthropic',
                'model': 'claude-3',
                'temperature': 5.0,
            },
        },
    )

    with pytest.raises(ValidationError, match='temperature'):
        load_oppie_config(tmp_path)


def test_load_provider_credentials_with_api_key(tmp_path):
    write_yaml(tmp_path / 'provider.yaml', {'api_key': 'sk-test'})
    creds = load_provider_credentials(tmp_path)

    assert creds == {'api_key': 'sk-test'}


def test_load_provider_credentials_missing_file(tmp_path):
    creds = load_provider_credentials(tmp_path)

    assert creds == {}


def test_load_provider_credentials_empty_file(tmp_path):
    (tmp_path / 'provider.yaml').write_text('')
    creds = load_provider_credentials(tmp_path)

    assert creds == {}


def test_load_config_merges_credentials(tmp_path):
    write_yaml(
        tmp_path / 'oppie.yaml',
        {
            'instance_type': 'repo',
            'provider': {'type': 'linear', 'team_id': 'team-123'},
            'llm': _LLM_DATA,
        },
    )
    write_yaml(tmp_path / 'provider.yaml', {'api_key': 'sk-merged'})
    config = load_config(tmp_path)

    assert config.provider.api_key == 'sk-merged'


def test_load_config_no_credentials(tmp_path):
    write_yaml(
        tmp_path / 'oppie.yaml',
        {'instance_type': 'repo', 'provider': {'type': 'local'}, 'llm': _LLM_DATA},
    )
    config = load_config(tmp_path)

    assert config.provider.api_key is None
