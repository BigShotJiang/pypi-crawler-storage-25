"""Shared services."""
