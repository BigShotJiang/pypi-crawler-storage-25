"""Ingest components."""
