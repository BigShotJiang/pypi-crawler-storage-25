"""Core pipeline helpers."""
