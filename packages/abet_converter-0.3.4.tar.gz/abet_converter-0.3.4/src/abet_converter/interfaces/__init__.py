"""Shared interfaces."""
