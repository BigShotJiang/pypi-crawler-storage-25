"""DocExtract Python SDK — Extract structured data from documents."""

from .client import DocExtract

__version__ = "1.0.0"
__all__ = ["DocExtract"]
