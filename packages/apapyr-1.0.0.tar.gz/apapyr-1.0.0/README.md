# aPapyr Python SDK

Extract structured data from invoices, receipts, and documents. Send a PDF or image, get clean JSON back.

## Install

```bash
pip install apapyr
```

## Quick Start

```python
from apapyr import aPapyr

client = aPapyr("sk_live_your_key")

# Extract data from an invoice
result = client.extract("invoice.pdf")

print(result.get_field("vendor_name"))   # "Acme Corp"
print(result.get_field("total"))          # 1250.00
print(result.get_field("due_date"))       # "2026-04-15"
print(result.confidence)                  # 0.97

# Get all fields as a flat dictionary
print(result.to_flat_dict())
# {"document_type": "invoice", "vendor_name": "Acme Corp", "total": 1250.00, ...}

# Check confidence for a specific field
print(result.get_field_confidence("total"))  # 0.98
```

## Document Types

| Type | Key Fields |
|------|-----------|
| `invoice` | vendor, total, tax, due_date, line_items |
| `receipt` | merchant, total, tax, tip, payment_method |
| `w2` | employer, wages, federal_tax, state_tax |
| `bank_statement` | bank, balances, transactions |
| `contract` | parties, dates, value, obligations |
| `auto` | automatically detects type (default) |

## AI Agent Support

aPapyr works natively with AI agents via MCP:

```bash
# Add to Claude Code
claude mcp add apapyr -- npx @apapyr/mcp-server
```

Then just ask: *"Extract the data from invoice.pdf"*

## Environment Variable

```bash
export APAPYR_API_KEY=sk_live_your_key
```

```python
client = aPapyr()  # reads from env
```

## Links

- [API Docs](https://apapyr.com/docs.html)
- [Dashboard](https://apapyr.com/dashboard.html)
- [Free Tool](https://apapyr.com/free-tool.html)
- [MCP Server](https://www.npmjs.com/package/@apapyr/mcp-server)
