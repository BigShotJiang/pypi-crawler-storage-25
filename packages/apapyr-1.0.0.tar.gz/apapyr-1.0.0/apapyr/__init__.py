"""aPapyr Python SDK — Extract structured data from documents."""

from .client import aPapyr, Extraction, aPapyrError

__version__ = "1.0.0"
__all__ = ["aPapyr", "Extraction", "aPapyrError"]
