"""aPapyr API client."""

import os
from pathlib import Path
from typing import Optional, Any, Union, BinaryIO

import requests


class aPapyrError(Exception):
    def __init__(self, message: str, status_code: int = None, response: dict = None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response


class Extraction:
    """Represents an extraction result."""

    def __init__(self, data: dict):
        self._data = data
        self.id = data.get("id")
        self.status = data.get("status")
        self.document_type = data.get("document_type")
        self.confidence = data.get("confidence")
        self.processing_time_ms = data.get("processing_time_ms")
        self.cached = data.get("cached", False)
        self.fields = data.get("data", {}).get("fields", {})
        self.line_items = data.get("data", {}).get("line_items", [])
        self.validation_warnings = data.get("validation_warnings", [])

    def get_field(self, name: str) -> Any:
        """Get a field value by name."""
        field = self.fields.get(name, {})
        if isinstance(field, dict):
            return field.get("value")
        return field

    def get_field_confidence(self, name: str) -> float:
        """Get a field's confidence score."""
        field = self.fields.get(name, {})
        if isinstance(field, dict):
            return field.get("confidence", 0.0)
        return 0.0

    def to_dict(self) -> dict:
        """Return the raw API response."""
        return self._data

    def to_flat_dict(self) -> dict:
        """Return a flat dictionary of field name -> value (no confidence scores)."""
        result = {"document_type": self.document_type}
        for key, val in self.fields.items():
            if isinstance(val, dict):
                result[key] = val.get("value")
            else:
                result[key] = val
        return result

    def __repr__(self):
        return f"Extraction(id='{self.id}', type='{self.document_type}', confidence={self.confidence})"


class aPapyr:
    """aPapyr API client.

    Usage:
        client = aPapyr("sk_live_your_key")
        result = client.extract("invoice.pdf")
        print(result.get_field("total"))  # 1250.00
    """

    def __init__(self, api_key: str = None, base_url: str = "https://api.apapyr.com"):
        self.api_key = api_key or os.environ.get("APAPYR_API_KEY")
        if not self.api_key:
            raise aPapyrError(
                "API key required. Pass it as aPapyr('sk_live_...') or set APAPYR_API_KEY env var."
            )
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()
        self.session.headers.update({"Authorization": f"Bearer {self.api_key}"})

    def extract(
        self,
        file: Union[str, Path, BinaryIO],
        document_type: str = "auto",
        webhook_url: str = None,
    ) -> Extraction:
        """Extract structured data from a document.

        Args:
            file: File path (str/Path) or file-like object
            document_type: One of: auto, invoice, receipt, w2, bank_statement, contract
            webhook_url: Optional URL to receive results via webhook

        Returns:
            Extraction object with parsed data
        """
        if isinstance(file, (str, Path)):
            file_path = Path(file)
            if not file_path.exists():
                raise aPapyrError(f"File not found: {file_path}")
            file_obj = open(file_path, "rb")
            file_name = file_path.name
        else:
            file_obj = file
            file_name = getattr(file, "name", "document")

        try:
            data = {"document_type": document_type}
            if webhook_url:
                data["webhook_url"] = webhook_url

            response = self.session.post(
                f"{self.base_url}/v1/extract",
                files={"file": (file_name, file_obj)},
                data=data,
                timeout=120,
            )
        finally:
            if isinstance(file, (str, Path)):
                file_obj.close()

        return self._handle_response(response)

    def get_extraction(self, extraction_id: str) -> Extraction:
        """Get a previous extraction result by ID."""
        response = self.session.get(f"{self.base_url}/v1/extract/{extraction_id}", timeout=30)
        return self._handle_response(response)

    def list_extractions(self, limit: int = 20, offset: int = 0) -> list:
        """List recent extractions."""
        response = self.session.get(
            f"{self.base_url}/v1/extractions",
            params={"limit": limit, "offset": offset},
            timeout=30,
        )
        if response.status_code != 200:
            self._raise_error(response)
        data = response.json()
        return data.get("extractions", [])

    def get_usage(self) -> dict:
        """Get current usage and billing info."""
        response = self.session.get(f"{self.base_url}/v1/usage", timeout=30)
        if response.status_code != 200:
            self._raise_error(response)
        return response.json()

    def list_schemas(self) -> dict:
        """List supported document types and fields."""
        response = self.session.get(f"{self.base_url}/v1/schemas", timeout=30)
        if response.status_code != 200:
            self._raise_error(response)
        return response.json()

    def _handle_response(self, response) -> Extraction:
        if response.status_code != 200:
            self._raise_error(response)
        data = response.json()
        if data.get("status") == "failed":
            raise aPapyrError(
                data.get("error", "Extraction failed"),
                status_code=response.status_code,
                response=data,
            )
        return Extraction(data)

    def _raise_error(self, response):
        try:
            data = response.json()
            message = data.get("detail", str(data))
        except Exception:
            message = response.text
        raise aPapyrError(message, status_code=response.status_code)
