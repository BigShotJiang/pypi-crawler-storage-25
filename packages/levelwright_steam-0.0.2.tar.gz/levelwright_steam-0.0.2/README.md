# levelwright-steam

Hermes-Agent plugin providing Steam library, playtime, achievements, and ProtonDB compatibility tools for [Levelwright](https://github.com/levelwright/levelwright).

**Status:** Placeholder release. Real implementation coming in v0.1.0.

## Scope (planned)

Tools exposed to the Hermes agent:

- `steam_get_library` — owned games (via Steam Web API)
- `steam_get_playtime` — hours played per game
- `steam_get_achievements` — achievement progress
- `steam_get_recent` — recently played
- `protondb_check_compat` — ProtonDB rating + Deck Verified status

Steam Web API calls use a user-provided API key, never a shipped key. See [ADR-0010](https://github.com/levelwright/levelwright/blob/main/docs/adr/ADR-0010-steam-web-api-key-user-provided.md).

## License

MIT.
