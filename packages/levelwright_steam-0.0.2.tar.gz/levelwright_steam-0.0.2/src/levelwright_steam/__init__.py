"""Levelwright steam plugin — Steam library, playtime, achievements, ProtonDB.

Placeholder release. Real implementation exposes Hermes-Agent tools that
call the Steam Web API (user-provided key) and ProtonDB for compatibility
ratings. See ADR-0002 and ADR-0010 at
https://github.com/levelwright/levelwright.
"""

__version__ = "0.0.2"
