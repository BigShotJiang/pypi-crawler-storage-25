# markstate

Track the status of any markdown documents through a defined workflow — phases, gate conditions, and transitions stored in a `flow.yml` beside your docs.

Works for any document-centric process: spec reviews, ADRs, runbooks, content pipelines. A particularly good fit is **spec-driven development**, where proposals, specs, and task lists move through stages like draft → approved → in-progress → done, and an AI agent or human needs to know exactly where everything stands before proceeding.

## Examples

Ready-made flows and agent skills are in [`examples/`](examples/) and [`skills/`](skills/):

| Example | Description |
|---|---|
| [`examples/sdd/`](examples/sdd/) | Spec-driven development: proposal → spec → tasks → done |
| [`examples/openspec/`](examples/openspec/) | [OpenSpec](https://github.com/Fission-AI/OpenSpec)-style: proposal + design agreed upfront, then tasks |

Each example includes a `flow.yml` to place at the root of your change collection (e.g. `specs/flow.yml`) and a matching skill in `skills/` to guide an AI agent through the workflow.

## Install

```bash
uv tool install markstate
```

## Quick start

```bash
# Install the CLI
uv tool install markstate

# Install the sdd skill into Claude Code
uvx skillset add vivainio/markstate -s sdd

# Bootstrap a hidden SDD workflow — nothing visible in the repo until you're ready
markstate init https://raw.githubusercontent.com/vivainio/markstate/main/examples/sdd/flow.yml --hidden
# → creates .markstate/flow.yml and adds .markstate/ to .gitignore

# Start the workflow
markstate new proposal.md
markstate next
markstate do accept proposal.md
markstate status
```

## Commands

### `init`

Create a `flow.yml` in the current directory:

```
markstate init                                    # write built-in template
markstate init examples/sdd/flow.yml              # copy from an existing flow.yml
markstate init examples/sdd/flow.yml --hidden     # copy into .markstate/ (see below)
markstate init --force                            # overwrite existing
```

### `new`

Create a document from its template defined in `flow.yml`. Available files are shown in the help when a `flow.yml` is present:

```
markstate new spec.md
markstate new spec.md tasks/task-1/     # create in a specific directory
markstate new specs/03-password-reset   # create a directory from a dir template
```

When inside a directory matching a dir template (e.g. `specs/*`), shows only the files missing from that directory.

### `set`

Set the status of one or more documents directly, without a defined move. Works without `flow.yml`:

```
markstate set draft spec.md
markstate set done docs/*.md
```

### `do`

Apply a named transition to a document. Validates the current status before applying:

```
$ markstate do approve spec.md
spec.md: draft → approved
→ entering phase: review
  advance when:
    - all files matching 'specs/*/tasks.md' must have status 'done'
```

When a transition causes a phase change, the new phase and its completion conditions are printed. Files marked `auto: true` in the new phase's `produces` are created automatically.

### `--set key=value`

`new`, `set`, `do`, and `check` all accept one or more `--set key=value` flags to write additional frontmatter fields alongside the main operation:

```
markstate do accept proposal.md --set reviewer=me --set reviewed_at=now
markstate set approved spec.md --set approved_by=me
markstate new proposal.md --set author=me --set created_at=now
```

Two magic values are expanded automatically:

| Value | Expands to |
|---|---|
| `me` | Git user name (`git config user.name`) |
| `now` | UTC timestamp in ISO 8601 format (`2026-03-28T12:00:00Z`) |

### `status`

Show file statuses and phase progress:

```
$ markstate status
current phase: drafting

  spec.md                         draft
  design.md                       draft

  drafting              in progress
  review                pending
  done                  pending
```

Takes an optional directory argument. Add `--json` for machine-readable output.

### `next`

Show what can be done next — applicable transitions on existing documents, and files that still need to be created:

```
$ markstate next
  spec.md                         draft           → approve (→ approved), start-review (→ in-review)
  design.md                       (not created)   → markstate new design.md
```

### `focus`

Set or show the current task directory. Once set, `status`, `next`, and `check-gate` use it as the default directory:

```
markstate focus tasks/PROJ-123.add-auth   # set focus
markstate focus                           # show current focus
markstate next                            # operates on the focused directory
```

Focus is stored in `.markstate-focus` at the project root. Add it to `.gitignore` as it is personal state.

### `transitions`

List all defined transitions:

```
$ markstate transitions
  approve               draft → approved
  start-review          draft → in-review
  mark-reviewed         in-review → reviewed
```

### `query`

Find documents by front matter fields. Predicates are ANDed:

```
markstate query status=draft
markstate query status=draft "created-at>2024-06-01"
markstate query title~=api status!=done
markstate query status=draft --json
markstate query status=draft --dir path/to/docs
```

Supported operators:

| Operator | Meaning |
|---|---|
| `=` | exact match |
| `!=` | not equal |
| `~=` | substring match (case-insensitive) |
| `>` `<` `>=` `<=` | ordered comparison (numeric or string; ISO dates compare correctly) |

Searches recursively from `docs_root` (or cwd if no `flow.yml`). Add `--json` for machine-readable output.

### `check-gate`

Check if gate conditions for a phase are met. Exits 0 if satisfied, 1 otherwise:

```
$ markstate check-gate review
gate not satisfied:
  - spec.md must have status 'approved'
```

## Trying it without visible marks

To experiment without touching the repo visibly, point `init` at an existing `flow.yml` (a sample, a colleague's, a cloned example) and pass `--hidden`:

```
markstate init path/to/flow.yml --hidden
echo '.markstate/' >> .gitignore
```

`init --hidden` copies the file to `.markstate/flow.yml`, creates the directory, and prints a reminder to update `.gitignore`. All documents and the focus file land under `.markstate/` — one gitignore entry covers everything.

If the experiment works and you want to share it, move `flow.yml` to the root and commit.

## Configuration reference

`flow.yml` is discovered by walking up from the current directory, checking `flow.yml` then `.markstate/flow.yml` at each level.

| Field | Description |
|---|---|
| `status_field` | Front matter key to track state (default: `status`) |
| `docs_root` | Directory where documents live, relative to `flow.yml` or absolute (default: same directory as `flow.yml`) |
| `phases` | Ordered list of phases |
| `transitions` | Named transitions between states |

`docs_root` allows `flow.yml` to live in a separate location — even a different repository — from the documents it manages:

```yaml
# flow.yml in a tooling repo, docs_root pointing to a sibling docs repo
docs_root: ../my-docs-repo
```

**Phase fields:**

| Field | Description |
|---|---|
| `name` | Phase name |
| `produces` | Documents this phase produces (files or directory templates) |
| `gates` | Conditions that must pass to enter this phase |
| `advance_when` | Conditions that must pass to leave this phase |

**Produces — file:**

```yaml
produces:
  - file: spec.md
    template: |
      ---
      status: draft
      ---

      # Spec
    auto: true   # create automatically when phase is entered
```

**Produces — directory template:**

```yaml
produces:
  - dir: specs/*
    files:
      - file: functional-spec.md
        template: |
          ---
          status: draft
          ---

          # Functional Spec
      - file: tasks.md
        template: |
          ---
          status: todo
          ---

          # Tasks
```

`markstate new specs/03-password-reset` creates the directory with all files. When inside a matching directory, `markstate new` shows only the missing files.

**Condition fields** (use one pair):

| Fields | Description |
|---|---|
| `file` + `status` | A specific file must have the given status |
| `glob` + `all_status` | All files matching the glob must have the given status |

**Transition fields:**

| Field | Description |
|---|---|
| `name` | Transition name (used with `markstate do`) |
| `from` | Required current status |
| `to` | New status after applying the transition |

## Minimal flow without config

`markstate` can be used without a `flow.yml` for lightweight, free-form status tracking. No phases, no moves, no gates — just statuses in front matter.

Add a status to any markdown file:

```markdown
---
status: todo
---

# My note
```

Then use `set` to update it:

```
$ markstate set done notes.md
notes.md: todo → done

$ markstate set in-progress docs/*.md
docs/api.md: todo → in-progress
docs/guide.md: todo → in-progress
```

And `status` to see everything in a directory:

```
$ markstate status
  notes.md                        done
  docs/api.md                     in-progress
  docs/guide.md                   in-progress
```

Status values are arbitrary strings — use whatever fits your workflow.

## License

MIT
