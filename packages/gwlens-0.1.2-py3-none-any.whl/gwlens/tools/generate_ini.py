def write_parameters_ini(output_file="parameters.ini"):
    content = """#author: Sreekanth Harikumar

#*****************************************#
[Source]
#*****************************************#

# Gravitational wave frequency of the source
frequency = 100
#Ds : Distance to lens in kpc
Ds = 16

#*****************************************#
[Lens]
#*****************************************#

#Model of the lens
lensmodel = point
# Mass of the lens in solar mass
lensmass = 1000 
#Dl :  Distance to lens in kpc
Dl = 8

#*****************************************#
[Microlens]
#*****************************************#

#v :  velocity of the lens (not relative velocity) in 1 km/s
v = 200
# The micorlensing closest impact parameter y0 in literature
closest_approach = 0.01
# Time at which the maximum peak is observed
Time_of_closest_approach = 0
#Period of observation
Tobs = 1000
#sampling_number. Set it low for speed but this will affect accuracy.
Number_of_samples = 1000

#*****************************************#
[Output]
#*****************************************#

#Name of the output folder in which the results are stored
outdir = outdir

#*****************************************#
[Plots]
#*****************************************#

generate_plots = True

#*****************************************#
[Interpolation]
#*****************************************#

filename = result_point
lensmodel = point
n-parallel = 4
precision = 50

dimensionless_frequency_lower_limit =  0.00001
dimensionless_frequency_upper_limit =  100
dimensionless_frequency_samples =  1000

impact_parameter_lower_limit = 0.01
impact_parameter_upper_limit  = 1
impact_parameter_samples = 1

scale_radius_lower_limit = 2.1
scale_radius_upper_limit = 3
scale_radius_samples = 2

powerlaw_coreradius = 0.1
powerlaw_amplitude = 1.0
powerlaw_exponent = 1.0
"""
    with open(output_file, "w") as f:
        f.write(content)
    print(f"✅ INI file written to: {output_file}")



def main():
    #Argument parser for CLI. Writes ini in the custom file name.
    import argparse
    parser = argparse.ArgumentParser(description="Generate default parameters.ini")

    parser.add_argument("--output", default="parameters.ini", help="Output INI file name")

    args = parser.parse_args()
    write_parameters_ini(output_file=args.output)