"""Built-in post_round_hook for gemini CLI: usage events + transient error classifier.

Validates the 0.1.23 multi-CLI architecture: this is the second built-in
plugin (after claude) emitting the generic transient_error_detected and
agent_usage_recorded event families without any agent-runner core changes.
"""

from __future__ import annotations

import json
import time
from collections import deque
from pathlib import Path
from typing import Any

from agent_runner.api import (
    emit_agent_usage_recorded,
    emit_transient_error_detected,
)
from agent_runner.builtin_plugins._constants import (
    _5XX_STATUSES,
    _BACK_OFF_DEFAULTS,
    _RAW_CAP,
    _TAIL_LINES,
)
from agent_runner.hooks import HookContext, register_post_round_hook


class GeminiErrorDetector:
    """Parse gemini round log tail; emit usage + transient_error_detected events."""

    name = "gemini_error_detector"

    def after_round(self, ctx: HookContext, result: Any) -> None:
        if ctx.agent_binary != "gemini":
            return
        log_path = ctx.agent_log_path
        if log_path is None or not log_path.exists():
            return
        parsed = _parse_gemini_log(log_path)
        if parsed.get("transient_error"):
            te = parsed["transient_error"]
            emit_transient_error_detected(ctx.log_dir, round_num=ctx.round_num, **te)
        if parsed.get("usage"):
            emit_agent_usage_recorded(
                ctx.log_dir,
                round_num=ctx.round_num,
                phase=ctx.phase or "",
                success=(result.exit_code == 0 and not result.timed_out),
                **parsed["usage"],
            )


def _parse_gemini_log(log_path: Path) -> dict[str, Any]:
    """Scan last _TAIL_LINES; extract usage from result.stats; classify any error.

    Returns dict with optional 'usage' and 'transient_error' keys.
    """
    with log_path.open("r", encoding="utf-8", errors="replace") as f:
        tail = deque(f, maxlen=_TAIL_LINES)
    result_event: dict | None = None
    for line in tail:
        line = line.strip()
        if not line:
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if event.get("type") == "result":
            result_event = event
    if result_event is None:
        return {}

    out: dict[str, Any] = {}

    # Usage extraction
    stats = result_event.get("stats") or {}
    if stats:
        out["usage"] = _extract_usage(stats)

    # Error classification (best-effort; gemini error schema less documented)
    if result_event.get("status") == "error" or result_event.get("error"):
        err = result_event.get("error") or {}
        code = err.get("code") if isinstance(err, dict) else None
        raw = str(
            (err.get("message") if isinstance(err, dict) else None)
            or result_event.get("status", "error")
        )[:_RAW_CAP]
        classification = _classify_gemini_error(code)
        if classification:
            duration = _BACK_OFF_DEFAULTS[classification]
            out["transient_error"] = {
                "classification": classification,
                "agent": "gemini",
                "reset_at_epoch": int(time.time() + duration),
                "raw": raw,
            }
    return out


def _extract_usage(stats: dict[str, Any]) -> dict[str, Any]:
    """Build agent_usage_recorded payload from gemini result.stats.

    Uses ``stats.input`` directly (gemini provides net non-cached input in
    that field; ``stats.input_tokens`` is gross including cached, so the
    subtraction in earlier code was unnecessary).
    """
    models = stats.get("models") or {}
    primary_model = (
        max(models, key=lambda m: models[m].get("total_tokens", 0)) if models else "unknown"
    )
    breakdown = (
        {
            name: {
                "total_tokens": int(m.get("total_tokens", 0)),
                "input_tokens": int(m.get("input_tokens", m.get("input", 0))),
                "output_tokens": int(m.get("output_tokens", 0)),
                "cached_tokens": int(m.get("cached", 0)),
            }
            for name, m in models.items()
        }
        if len(models) > 1
        else None
    )
    return {
        "agent": "gemini",
        "model": primary_model,
        "input_tokens": int(stats.get("input", 0)),
        "output_tokens": int(stats.get("output_tokens", 0)),
        "cached_tokens": int(stats.get("cached", 0)),
        "cache_creation_tokens": 0,  # gemini has no cache-creation concept
        "cost_usd": None,  # gemini doesn't expose USD
        "duration_ms": int(stats.get("duration_ms", 0)),
        "models_breakdown": breakdown,
        "tool_call_count": int(stats.get("tool_calls", 0)),
    }


def _classify_gemini_error(code: Any) -> str | None:
    """Map gemini error code to 0.1.23 classification. None means 'not transient'."""
    if code == 429:
        return "rate_limit_model"
    if code in _5XX_STATUSES:
        return "api_transient_5xx"
    if code == 408:
        return "api_timeout"
    return None


register_post_round_hook(GeminiErrorDetector())
