#!/usr/bin/env node
'use strict';

/**
 * Lyra Unily MCP Launcher
 *
 * Thin launcher that spawns the unily-mcp-server Python package locally.
 * Tries uvx first (uv tool runner), falls back to python / python3.
 *
 * Credentials are supplied via environment variables in Claude Desktop config:
 *
 *   {
 *     "mcpServers": {
 *       "lyra-unily": {
 *         "command": "npx",
 *         "args": ["lyra-unily-mcp"],
 *         "env": {
 *           "UNILY_CLIENT_ID": "your-client-id",
 *           "UNILY_CLIENT_SECRET": "your-client-secret"
 *         }
 *       }
 *     }
 *   }
 *
 * Alternatively, if you already have uv installed you can skip the npm bridge
 * entirely and use uvx directly:
 *
 *   "command": "uvx",
 *   "args": ["lyra-unily-mcp"]
 */

const { spawnSync, spawn } = require('child_process');

const IS_WIN = process.platform === 'win32';

/**
 * Check whether a command is available on PATH.
 * Uses spawnSync so the check is synchronous and quick.
 */
function available(cmd) {
  const result = spawnSync(cmd, ['--version'], {
    stdio: 'ignore',
    timeout: 3000,
    // On Windows, .cmd wrappers (uvx.cmd, python.cmd) need shell: true
    shell: IS_WIN,
  });
  return !result.error && result.status !== null;
}

function launch() {
  let cmd, args;

  if (available('uvx')) {
    // Preferred: uvx downloads and caches the package from PyPI automatically.
    // Users do not need to pre-install anything beyond uv itself.
    cmd = 'uvx';
    args = ['lyra-unily-mcp'];
  } else if (available('python')) {
    cmd = 'python';
    args = ['-m', 'unily_mcp_server'];
  } else if (available('python3')) {
    cmd = 'python3';
    args = ['-m', 'unily_mcp_server'];
  } else {
    process.stderr.write(
      'lyra-unily-mcp: neither uvx nor python found on PATH.\n' +
      'Install uv (https://docs.astral.sh/uv/) for automatic package management,\n' +
      'or install Python 3.11+ and run: pip install lyra-unily-mcp\n'
    );
    process.exit(1);
  }

  const child = spawn(cmd, args, {
    stdio: 'inherit',
    env: process.env,
    shell: IS_WIN,
  });

  child.on('error', (err) => {
    process.stderr.write(`lyra-unily-mcp: failed to start ${cmd}: ${err.message}\n`);
    process.exit(1);
  });

  child.on('exit', (code, signal) => {
    if (signal) {
      // Propagate signal so the parent sees a signal-terminated exit
      process.kill(process.pid, signal);
    } else {
      process.exit(code ?? 1);
    }
  });
}

launch();
