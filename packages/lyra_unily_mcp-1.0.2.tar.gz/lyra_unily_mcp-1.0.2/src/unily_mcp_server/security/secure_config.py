"""Secure configuration management with credential leak prevention.

Secrets are read directly from the process environment on every call —
intentionally no in-process cache so runtime secret rotation (e.g. Vault
agent rewriting env vars) is picked up without a process restart.
"""

import math
import os
import re
from typing import List, Pattern


class SecurityError(Exception):
    """Raised when a security violation is detected."""


class SecureConfig:
    """Environment-only configuration with credential leak detection."""

    FORBIDDEN_PATTERNS: List[Pattern] = [
        re.compile(
            r'[a-zA-Z0-9_-]*api[_-]?key["\']?\s*[:=]\s*["\']?[a-zA-Z0-9_\-]{20,}',
            re.IGNORECASE,
        ),
        re.compile(
            r'[a-zA-Z0-9_-]*token["\']?\s*[:=]\s*["\']?[a-zA-Z0-9_\-]{20,}',
            re.IGNORECASE,
        ),
        re.compile(
            r'[a-zA-Z0-9_-]*secret["\']?\s*[:=]\s*["\']?[a-zA-Z0-9_\-]{20,}',
            re.IGNORECASE,
        ),
        re.compile(
            r'password["\']?\s*[:=]\s*["\'][^\s"\']{8,}',
            re.IGNORECASE,
        ),
        re.compile(r'-----BEGIN (RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----', re.IGNORECASE),
        re.compile(r'AKIA[0-9A-Z]{16}'),
        re.compile(r'\b[a-zA-Z0-9_\-]{32,}\b'),
    ]

    @staticmethod
    def _shannon_entropy(s: str) -> float:
        freq: dict[str, float] = {}
        for c in s:
            freq[c] = freq.get(c, 0) + 1
        length = len(s)
        return -sum((f / length) * math.log2(f / length) for f in freq.values())

    @classmethod
    def get_secret(cls, name: str) -> str:
        """Return the environment variable *name* or raise SecurityError if unset."""
        value = os.environ.get(name)
        if not value:
            raise SecurityError(
                f"Required secret '{name}' is not set in the environment. "
                "Secrets must be provided via environment variables."
            )
        return value

    @classmethod
    def get_optional(cls, name: str, default: str = "") -> str:
        """Return the environment variable *name* or *default* if unset."""
        return os.environ.get(name, default)

    @classmethod
    def scan_for_credentials(cls, text: str) -> List[str]:
        """Return a list of detected credential-like patterns found in *text*.

        Used to prevent accidental credential leakage through user inputs.
        """
        findings: List[str] = []
        for pattern in cls.FORBIDDEN_PATTERNS:
            for match in pattern.finditer(text):
                matched = match.group(0)
                # Only flag high-entropy long strings; short matches are likely
                # false positives (e.g. base64 content, UUIDs).
                if len(matched) >= 32 and cls._shannon_entropy(matched) < 3.5:
                    continue
                findings.append(f"Potential credential detected: {matched[:20]}…")
        return findings
