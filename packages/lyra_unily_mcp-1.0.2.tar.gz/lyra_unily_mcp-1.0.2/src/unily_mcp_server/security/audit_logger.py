"""Structured audit logging for MCP tool calls."""

import structlog

logger = structlog.get_logger()


class AuditLogger:
    """Emits structured audit log entries for tool call outcomes."""

    @staticmethod
    def log_tool_call(
        tool_name: str,
        success: bool,
        duration_ms: float,
        error: str | None = None,
    ) -> None:
        if success:
            logger.info(
                "unily.tool.success",
                tool=tool_name,
                duration_ms=round(duration_ms, 1),
            )
        else:
            logger.warning(
                "unily.tool.failure",
                tool=tool_name,
                duration_ms=round(duration_ms, 1),
                error=error,
            )
