"""OAuth2 Client Credentials token manager for the Unily API.

Unily uses the client credentials grant (RFC 6749 §4.4).  There are no
per-user sessions — one service identity authenticates on behalf of all
requests.  This module keeps a single in-process token cache and refreshes
it proactively before expiry, serialising concurrent refresh attempts with
an asyncio.Lock so only one HTTP call is made when multiple tool calls race
at token-expiry time.

Environment variables consumed (via SecureConfig):
    UNILY_CLIENT_ID      — OAuth2 client ID
    UNILY_CLIENT_SECRET  — OAuth2 client secret
    UNILY_TOKEN_URL      — Token endpoint
                           (default: https://lyra-api.unily.com/connect/token)
    UNILY_API_SCOPES     — Space-separated scope list (optional override)
"""

import asyncio
import os
import time
from typing import Optional

import httpx
import structlog

logger = structlog.get_logger()

# All scopes granted to the Unily service integration.
DEFAULT_SCOPES = (
    "gateway.bots "
    "gateway.broadcasts:readWrite "
    "gateway.content.readaccess:readWrite "
    "gateway.contentmanagement "
    "gateway.contentmanagement.read "
    "gateway.contentmanagement:read "
    "gateway.contentmanagement:readWrite "
    "gateway.files.data:readWrite "
    "gateway.followedcontent "
    "gateway.followedusers "
    "gateway.formsubmission "
    "gateway.graphql "
    "gateway.media.data:readWrite "
    "gateway.notification "
    "gateway.personalisation:readWrite "
    "gateway.social:readWrite "
    "gateway.userprofile:readWrite "
    "gateway.videos"
)

# Refresh the token this many seconds before it actually expires to avoid
# race conditions between expiry and the next API call.
_EXPIRY_BUFFER_SECONDS = 60


class TokenManagerError(Exception):
    """Raised when a token cannot be obtained or refreshed."""


class TokenManager:
    """Thread-safe OAuth2 client credentials token manager.

    Usage::

        manager = TokenManager()
        token = await manager.get_token()   # always returns a valid bearer token

    The asyncio.Lock is created lazily on first use rather than at __init__
    time so that the singleton can be constructed before an event loop exists
    (e.g. at module import time) without raising "no running event loop".
    """

    def __init__(self) -> None:
        self._lock: Optional[asyncio.Lock] = None
        self._access_token: Optional[str] = None
        self._expires_at: float = 0.0  # monotonic deadline (time.monotonic())

    def _get_lock(self) -> asyncio.Lock:
        """Return the per-manager Lock, creating it inside the running loop."""
        if self._lock is None:
            self._lock = asyncio.Lock()
        return self._lock

    def _is_valid(self) -> bool:
        """Return True if the cached token has at least _EXPIRY_BUFFER_SECONDS left."""
        return (
            self._access_token is not None
            and time.monotonic() < self._expires_at - _EXPIRY_BUFFER_SECONDS
        )

    async def get_token(self) -> str:
        """Return a valid bearer token, refreshing proactively if needed."""
        if self._is_valid():
            return self._access_token  # type: ignore[return-value]

        async with self._get_lock():
            # Double-check after acquiring the lock — another coroutine may have
            # already refreshed.
            if self._is_valid():
                return self._access_token  # type: ignore[return-value]

            await self._fetch_token()
            return self._access_token  # type: ignore[return-value]

    async def _fetch_token(self) -> None:
        """Perform the client credentials grant and cache the result."""
        from unily_mcp_server.security.secure_config import SecureConfig

        client_id = SecureConfig.get_secret("UNILY_CLIENT_ID")
        client_secret = SecureConfig.get_secret("UNILY_CLIENT_SECRET")
        token_url = os.environ.get(
            "UNILY_TOKEN_URL", "https://lyra-api.unily.com/connect/token"
        )
        scopes = os.environ.get("UNILY_API_SCOPES", DEFAULT_SCOPES)

        payload = {
            "grant_type": "client_credentials",
            "client_id": client_id,
            "client_secret": client_secret,
            "scope": scopes,
        }

        logger.info("unily.token_manager.fetching", token_url=token_url)

        try:
            async with httpx.AsyncClient(timeout=15.0) as client:
                response = await client.post(
                    token_url,
                    data=payload,
                    headers={"Content-Type": "application/x-www-form-urlencoded"},
                )
                response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            raise TokenManagerError(
                f"Token endpoint returned {exc.response.status_code}: "
                f"{exc.response.text[:200]}"
            ) from exc
        except httpx.RequestError as exc:
            raise TokenManagerError(
                f"Network error contacting token endpoint: {exc}"
            ) from exc

        data = response.json()
        self._access_token = data["access_token"]
        # expires_in is in seconds; convert to a monotonic deadline
        expires_in = int(data.get("expires_in", 3600))
        self._expires_at = time.monotonic() + expires_in

        logger.info(
            "unily.token_manager.refreshed",
            expires_in=expires_in,
        )

    def invalidate(self) -> None:
        """Force the next get_token() call to re-fetch (e.g. after a 401 response)."""
        self._access_token = None
        self._expires_at = 0.0


# Module-level singleton shared across all tool calls within a process.
_token_manager: Optional[TokenManager] = None


def get_token_manager() -> TokenManager:
    """Return the process-level singleton TokenManager."""
    global _token_manager
    if _token_manager is None:
        _token_manager = TokenManager()
    return _token_manager
