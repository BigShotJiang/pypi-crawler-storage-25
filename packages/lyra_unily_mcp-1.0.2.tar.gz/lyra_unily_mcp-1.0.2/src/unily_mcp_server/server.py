"""Unily MCP Server — main server implementation.

Implements the Model Context Protocol for the Unily intranet platform.
Each user runs their own local instance; credentials are per-user.

Default transport: stdio (Claude Desktop).  SSE is available for advanced
deployments by setting UNILY_MCP_MODE=sse.

Environment variables:
    UNILY_CLIENT_ID       Unily OAuth2 client ID (required)
    UNILY_CLIENT_SECRET   Unily OAuth2 client secret (required)
    UNILY_API_BASE_URL    API base URL (default: https://lyra-api.unily.com)
    UNILY_TOKEN_URL       Token endpoint (default: https://lyra-api.unily.com/connect/token)
    UNILY_MCP_MODE        "stdio" (default) or "sse"
    UNILY_MCP_HOST        SSE bind host (default: 0.0.0.0)
    UNILY_MCP_PORT        SSE bind port (default: 8000)
"""

import os
import time
from typing import Any

import structlog
import structlog.stdlib
from fastmcp import FastMCP
from fastmcp.server.middleware import Middleware, MiddlewareContext

from unily_mcp_server.security import AuditLogger
from unily_mcp_server.tools.content import (
    unily_content_query as _content_query,
    unily_content_get as _content_get,
    unily_content_create as _content_create,
    unily_content_update as _content_update,
    unily_content_delete_draft as _content_delete_draft,
    unily_content_delete_confirm as _content_delete_confirm,
    unily_content_schedule_get as _content_schedule_get,
    unily_content_schedule_update as _content_schedule_update,
    unily_document_types_list as _document_types_list,
    unily_document_type_get as _document_type_get,
)
from unily_mcp_server.tools.media import (
    unily_media_create as _media_create,
    unily_media_replace as _media_replace,
    unily_media_get as _media_get,
    unily_media_folder_get as _media_folder_get,
    unily_media_update as _media_update,
    unily_media_delete as _media_delete,
    unily_media_folder_create as _media_folder_create,
)
from unily_mcp_server.tools.files import (
    unily_file_upload as _file_upload,
    unily_file_replace as _file_replace,
    unily_file_download as _file_download,
    unily_file_delete as _file_delete,
)
from unily_mcp_server.tools.social import (
    unily_social_comment_get as _social_comment_get,
    unily_social_comment_create as _social_comment_create,
    unily_social_comment_update as _social_comment_update,
    unily_social_comment_delete_draft as _social_comment_delete_draft,
    unily_social_comment_delete_confirm as _social_comment_delete_confirm,
    unily_social_reaction_types_list as _social_reaction_types_list,
    unily_content_reaction_set as _content_reaction_set,
    unily_content_reaction_delete as _content_reaction_delete,
)
from unily_mcp_server.tools.notifications import (
    unily_notifications_list as _notifications_list,
    unily_notifications_send as _notifications_send,
    unily_notification_delete as _notification_delete,
)
from unily_mcp_server.tools.users import (
    unily_followed_content_list as _followed_content_list,
    unily_followed_content_add as _followed_content_add,
    unily_followed_content_remove as _followed_content_remove,
    unily_followed_users_list as _followed_users_list,
    unily_followed_users_add as _followed_users_add,
    unily_followed_users_remove as _followed_users_remove,
    unily_personalisation_get as _personalisation_get,
    unily_personalisation_set_terms as _personalisation_set_terms,
)
from unily_mcp_server.tools.forms import (
    unily_forms_list as _forms_list,
    unily_form_submission_get as _form_submission_get,
    unily_form_submission_update_approval as _form_submission_update_approval,
)
from unily_mcp_server.tools.search import unily_search as _search

logger = structlog.get_logger()

mcp = FastMCP("unily-mcp-server")


# ------------------------------------------------------------------ #
# Middleware                                                            #
# ------------------------------------------------------------------ #

class ToolAuditMiddleware(Middleware):
    """Emits structured audit log entries for every tool call."""

    async def on_call_tool(
        self, context: MiddlewareContext, call_next: Any
    ) -> Any:
        # FastMCP middleware passes the raw message; extract tool name defensively.
        try:
            tool_name = context.message.params.get("name", "unknown")  # type: ignore[union-attr]
        except Exception:
            tool_name = "unknown"

        start = time.monotonic()
        try:
            result = await call_next(context)
            AuditLogger.log_tool_call(
                tool_name,
                success=True,
                duration_ms=(time.monotonic() - start) * 1000,
            )
            return result
        except Exception as exc:
            AuditLogger.log_tool_call(
                tool_name,
                success=False,
                duration_ms=(time.monotonic() - start) * 1000,
                error=str(exc),
            )
            raise


mcp.add_middleware(ToolAuditMiddleware())


# ------------------------------------------------------------------ #
# Content tools                                                         #
# ------------------------------------------------------------------ #

@mcp.tool(name="unily_content_query")
async def unily_content_query(query: dict) -> dict:
    """Search and filter Unily content using the structured query API.

    POST /api/v1/content/query — scope: gateway.contentmanagement:read

    Pass a Query object::

        {
          "documentTypes": ["newsArticle"],
          "keyword": "annual report",
          "skip": 0,
          "take": 20,
          "sort": "updatedAt",
          "sortOrder": "desc"
        }
    """
    return await _content_query(query)


@mcp.tool(name="unily_content_get")
async def unily_content_get(unique_id: str, include_descendants: bool = False) -> dict:
    """Retrieve a content item by UUID.

    GET /api/v1/content/{uniqueId} — scope: gateway.contentmanagement:read

    Args:
        unique_id: Content item UUID.
        include_descendants: Include child items in the response.
    """
    return await _content_get(unique_id, include_descendants)


@mcp.tool(name="unily_content_create")
async def unily_content_create(content: dict) -> dict:
    """Create a new content item.

    POST /api/v1/content — scope: gateway.contentmanagement:readWrite

    Typical body::

        {
          "name": "My Article",
          "documentTypeAlias": "newsArticle",
          "parentId": "<parent-uuid>",
          "properties": { "title": "...", "bodyText": "..." }
        }
    """
    return await _content_create(content)


@mcp.tool(name="unily_content_update")
async def unily_content_update(unique_id: str, patch: dict) -> dict:
    """Update specific fields of a content item (PATCH).

    PATCH /api/v1/content/{uniqueId} — scope: gateway.contentmanagement:readWrite

    Only fields present in *patch* are modified::

        { "properties": { "title": "Updated Title" } }
    """
    return await _content_update(unique_id, patch)


@mcp.tool(name="unily_content_delete_draft")
async def unily_content_delete_draft(unique_id: str) -> dict:
    """Stage a content item deletion (step 1 of 2).

    WARNING: Deleting content also deletes ALL descendant items.
    Call unily_content_delete_confirm with the returned draft_id to execute.
    """
    return await _content_delete_draft(unique_id)


@mcp.tool(name="unily_content_delete_confirm")
async def unily_content_delete_confirm(draft_id: str) -> dict:
    """Execute a staged content deletion (step 2 of 2).

    Call unily_content_delete_draft first to get a draft_id.

    DELETE /api/v1/content/{uniqueId} — scope: gateway.contentmanagement:readWrite
    """
    return await _content_delete_confirm(draft_id)


@mcp.tool(name="unily_content_schedule_get")
async def unily_content_schedule_get(unique_id: str) -> dict:
    """Get the publish/unpublish schedule for a content item.

    GET /api/v1/content-schedules/{uniqueId} — scope: gateway.contentmanagement:read
    """
    return await _content_schedule_get(unique_id)


@mcp.tool(name="unily_content_schedule_update")
async def unily_content_schedule_update(unique_id: str, schedule: dict) -> dict:
    """Update the publish/unpublish schedule for a content item.

    PUT /api/v1/content-schedules/{uniqueId} — scope: gateway.contentmanagement:readWrite

    Example::

        {
          "publishDate": "2025-06-01T09:00:00Z",
          "unpublishDate": "2025-12-31T23:59:59Z"
        }
    """
    return await _content_schedule_update(unique_id, schedule)


@mcp.tool(name="unily_document_types_list")
async def unily_document_types_list(iso_code: str = "") -> dict:
    """List all Unily document types (content schemas).

    GET /api/v1/document-types — scope: gateway.contentmanagement:read

    Args:
        iso_code: Optional language ISO code for localised labels.
    """
    return await _document_types_list(iso_code or None)


@mcp.tool(name="unily_document_type_get")
async def unily_document_type_get(alias: str, iso_code: str = "") -> dict:
    """Get a document type definition by alias.

    GET /api/v1/document-types/{alias} — scope: gateway.contentmanagement:read

    Args:
        alias: Document type alias (e.g. "newsArticle").
        iso_code: Optional language ISO code.
    """
    return await _document_type_get(alias, iso_code or None)


# ------------------------------------------------------------------ #
# Media tools                                                           #
# ------------------------------------------------------------------ #

@mcp.tool(name="unily_media_create")
async def unily_media_create(
    file_base64: str,
    file_name: str,
    media_type_alias: str,
    parent_id: str = "",
    name: str = "",
) -> dict:
    """Upload a new media item to Unily.

    POST /api/v1/media — scope: gateway.media.data:readWrite

    Pass the file as a base64-encoded string. Claude can encode any file
    you upload to this conversation before calling this tool.

    Args:
        file_base64: Base64-encoded file contents.
        file_name: Filename including extension (e.g. "hero.jpg").
        media_type_alias: Unily media type alias (e.g. "Image", "File", "Video").
        parent_id: UUID of the parent folder, or empty for root.
        name: Display name — defaults to file_name if empty.
    """
    return await _media_create(file_base64, file_name, media_type_alias, parent_id, name)


@mcp.tool(name="unily_media_replace")
async def unily_media_replace(
    unique_id: str,
    file_base64: str,
    file_name: str,
    extra_data: dict = {},
) -> dict:
    """Replace a media item's file in full (PUT).

    PUT /api/v1/media/{uniqueId} — scope: gateway.media.data:readWrite

    Swaps out the underlying file of an existing media item.
    For metadata-only changes use unily_media_update (PATCH) instead.

    Args:
        unique_id: UUID of the existing media item to replace.
        file_base64: Base64-encoded replacement file contents.
        file_name: Filename including extension.
        extra_data: Additional fields to include (e.g. {"name": "new-name"}).
    """
    return await _media_replace(unique_id, file_base64, file_name, extra_data)


@mcp.tool(name="unily_media_get")
async def unily_media_get(unique_id: str, include_descendants: bool = False) -> dict:
    """Retrieve a media item by UUID.

    GET /api/v1/media/{uniqueId} — scope: gateway.media.data:readWrite
    """
    return await _media_get(unique_id, include_descendants)


@mcp.tool(name="unily_media_folder_get")
async def unily_media_folder_get(unique_id: str) -> dict:
    """Retrieve a media folder by UUID.

    GET /api/v1/media/folders/{uniqueId} — scope: gateway.media.data:readWrite
    """
    return await _media_folder_get(unique_id)


@mcp.tool(name="unily_media_update")
async def unily_media_update(unique_id: str, data: dict) -> dict:
    """Update media item metadata (name, parent folder, etc.).

    PATCH /api/v1/media/{uniqueId} — scope: gateway.media.data:readWrite

    File binary replacement is not supported through this tool.
    Common fields: { "name": "new-name", "parentId": "<folder-uuid>" }
    """
    return await _media_update(unique_id, data)


@mcp.tool(name="unily_media_delete")
async def unily_media_delete(unique_id: str) -> dict:
    """Permanently delete a media item by UUID.

    DELETE /api/v1/media/{uniqueId} — scope: gateway.media.data:readWrite
    """
    return await _media_delete(unique_id)


@mcp.tool(name="unily_media_folder_create")
async def unily_media_folder_create(name: str, parent_id: str = "") -> dict:
    """Create a new media folder.

    POST /api/v1/media/folders — scope: gateway.media.data:readWrite

    Args:
        name: Display name for the folder.
        parent_id: Parent folder UUID, or empty string for root.
    """
    return await _media_folder_create(name, parent_id or None)


# ------------------------------------------------------------------ #
# Social tools                                                          #
# ------------------------------------------------------------------ #

@mcp.tool(name="unily_social_comment_get")
async def unily_social_comment_get(comment_id: int) -> dict:
    """Retrieve a social comment by ID.

    GET /api/v1/social-comments/{commentId} — scope: gateway.social:readWrite
    """
    return await _social_comment_get(comment_id)


@mcp.tool(name="unily_social_comment_create")
async def unily_social_comment_create(comment: dict) -> dict:
    """Create a new social comment.

    POST /api/v1/social-comments — scope: gateway.social:readWrite

    Required fields::

        {
          "contentId": 1234,
          "text": "Great article!",
          "userUniqueId": "<user-uuid>"
        }
    """
    return await _social_comment_create(comment)


@mcp.tool(name="unily_social_comment_update")
async def unily_social_comment_update(comment_id: int, comment: dict) -> dict:
    """Update a social comment.

    PUT /api/v1/social-comments/{commentId} — scope: gateway.social:readWrite
    """
    return await _social_comment_update(comment_id, comment)


@mcp.tool(name="unily_social_comment_delete_draft")
async def unily_social_comment_delete_draft(comment_id: int) -> dict:
    """Stage a comment deletion (step 1 of 2).

    Deletions are visible to other users and cannot be undone.
    Call unily_social_comment_delete_confirm with the returned draft_id.
    """
    return await _social_comment_delete_draft(comment_id)


@mcp.tool(name="unily_social_comment_delete_confirm")
async def unily_social_comment_delete_confirm(draft_id: str) -> dict:
    """Execute a staged comment deletion (step 2 of 2).

    DELETE /api/v1/social-comments/{commentId} — scope: gateway.social:readWrite
    """
    return await _social_comment_delete_confirm(draft_id)


@mcp.tool(name="unily_social_reaction_types_list")
async def unily_social_reaction_types_list(
    applicable_document_types: str = "",
    content_id: int = 0,
) -> dict:
    """List available social reaction types.

    GET /api/v1/social-reaction-types — scope: gateway.social:readWrite
    """
    return await _social_reaction_types_list(
        applicable_document_types or None,
        content_id,
    )


@mcp.tool(name="unily_content_reaction_set")
async def unily_content_reaction_set(
    content_unique_id: str,
    reaction: dict,
) -> dict:
    """Set or update a reaction on a content item.

    PUT /api/v1/content-reactions/{contentUniqueId} — scope: gateway.social:readWrite

    Example reaction::

        {"reactionName": "like", "userUniqueId": "<user-uuid>"}
    """
    return await _content_reaction_set(content_unique_id, reaction)


@mcp.tool(name="unily_content_reaction_delete")
async def unily_content_reaction_delete(
    content_unique_id: str,
    user_unique_id: str,
) -> dict:
    """Remove a user's reaction from a content item.

    DELETE /api/v1/content-reactions/{contentUniqueId} — scope: gateway.social:readWrite

    Args:
        content_unique_id: UUID of the content item.
        user_unique_id: UUID of the user whose reaction to remove.
    """
    return await _content_reaction_delete(content_unique_id, user_unique_id)


# ------------------------------------------------------------------ #
# Notification tools                                                    #
# ------------------------------------------------------------------ #

@mcp.tool(name="unily_notifications_list")
async def unily_notifications_list(
    user_id: int,
    skip: int = 0,
    take: int = 50,
    since: str = "",
) -> dict:
    """List notifications for a user.

    GET /api/v1/notifications/{userId} — scope: gateway.notification

    Args:
        user_id: Integer Unily user ID.
        skip: Pagination offset.
        take: Page size (max 50).
        since: ISO-8601 datetime — only return notifications after this time.
    """
    return await _notifications_list(user_id, skip, take, since or None)


@mcp.tool(name="unily_notifications_send")
async def unily_notifications_send(notification: dict) -> dict:
    """Send a notification to Unily users.

    POST /api/v1/notifications — scope: gateway.notification

    Key fields::

        {
          "title": "Important Update",
          "body": "Please review the new policy.",
          "url": "https://lyra.unily.com/...",
          "audienceAliases": ["all-users"]
        }
    """
    return await _notifications_send(notification)


@mcp.tool(name="unily_notification_delete")
async def unily_notification_delete(user_id: int, notification_id: int) -> dict:
    """Delete a specific notification for a user.

    DELETE /api/v1/notifications/{userId}/notification/{notificationId}
    scope: gateway.notification
    """
    return await _notification_delete(user_id, notification_id)


# ------------------------------------------------------------------ #
# User / Following tools                                               #
# ------------------------------------------------------------------ #

@mcp.tool(name="unily_followed_content_list")
async def unily_followed_content_list(
    user_id: int,
    search: str = "",
    skip: int = 0,
    take: int = 50,
    document_type_alias: str = "",
) -> dict:
    """List content items followed by a user.

    GET /api/v1/followed-content/{userId} — scope: gateway.followedcontent
    """
    return await _followed_content_list(
        user_id, search or None, skip, take, document_type_alias or None
    )


@mcp.tool(name="unily_followed_content_add")
async def unily_followed_content_add(user_id: int, content_id: int) -> dict:
    """Follow a content item on behalf of a user.

    POST /api/v1/followed-content/{userId} — scope: gateway.followedcontent
    """
    return await _followed_content_add(user_id, content_id)


@mcp.tool(name="unily_followed_content_remove")
async def unily_followed_content_remove(user_id: int, content_id: int) -> dict:
    """Unfollow a content item on behalf of a user.

    DELETE /api/v1/followed-content/{userId}/{contentId}
    scope: gateway.followedcontent
    """
    return await _followed_content_remove(user_id, content_id)


@mcp.tool(name="unily_followed_users_list")
async def unily_followed_users_list(
    user_id: int,
    search: str = "",
    skip: int = 0,
    take: int = 50,
) -> dict:
    """List users followed by a given user.

    GET /api/v1/followed-users/{userId} — scope: gateway.followedusers
    """
    return await _followed_users_list(user_id, search or None, skip, take)


@mcp.tool(name="unily_followed_users_add")
async def unily_followed_users_add(user_id: int, followed_user_id: int) -> dict:
    """Follow another user on behalf of a user.

    POST /api/v1/followed-users/{userId} — scope: gateway.followedusers

    Args:
        user_id: Integer Unily user ID (the follower).
        followed_user_id: Integer Unily user ID to follow.
    """
    return await _followed_users_add(user_id, followed_user_id)


@mcp.tool(name="unily_followed_users_remove")
async def unily_followed_users_remove(user_id: int, followed_user_id: int) -> dict:
    """Unfollow a user on behalf of a user.

    DELETE /api/v1/followed-users/{userId}/{followedUserId}
    scope: gateway.followedusers
    """
    return await _followed_users_remove(user_id, followed_user_id)


@mcp.tool(name="unily_personalisation_get")
async def unily_personalisation_get(user_id: str) -> dict:
    """Retrieve personalisation settings for a user.

    GET /api/v1/personalisation/{user-id} — scope: gateway.personalisation:readWrite

    Args:
        user_id: UUID of the Unily user.
    """
    return await _personalisation_get(user_id)


@mcp.tool(name="unily_personalisation_set_terms")
async def unily_personalisation_set_terms(
    user_id: str,
    property_alias: str,
    term_ids: list,
) -> dict:
    """Set personalisation terms for a user property (bulk replace).

    PUT /api/v1/personalisation/{user-id}/properties/{alias}/terms
    scope: gateway.personalisation:readWrite
    """
    return await _personalisation_set_terms(user_id, property_alias, term_ids)


# ------------------------------------------------------------------ #
# Form tools                                                            #
# ------------------------------------------------------------------ #

@mcp.tool(name="unily_forms_list")
async def unily_forms_list(
    scope: str,
    limit: int = 50,
    skip: int = 0,
    form_ids: str = "",
    approval_state: str = "",
    match: str = "",
) -> dict:
    """List form submissions.

    GET /api/v1/form-submissions — scope: gateway.formsubmission

    Args:
        scope: Required — submission scope (e.g. "all", "mine").
        limit: Maximum results to return.
        skip: Pagination offset.
        form_ids: Comma-separated form IDs (optional filter).
        approval_state: Filter by approval state (optional).
        match: Keyword search within submissions (optional).
    """
    return await _forms_list(
        scope, limit, skip,
        form_ids or None, approval_state or None, match or None
    )


@mcp.tool(name="unily_form_submission_get")
async def unily_form_submission_get(submission_id: str) -> dict:
    """Get a single form submission by ID.

    GET /api/v1/form-submissions/{id} — scope: gateway.formsubmission
    """
    return await _form_submission_get(submission_id)


@mcp.tool(name="unily_form_submission_update_approval")
async def unily_form_submission_update_approval(
    submission_id: str,
    approval_state: str,
    comment: str = "",
) -> dict:
    """Update the approval status of a form submission.

    PATCH /api/v1/form-submissions/{id}/approval-status
    scope: gateway.formsubmission
    """
    return await _form_submission_update_approval(
        submission_id, approval_state, comment or None
    )


# ------------------------------------------------------------------ #
# Search                                                                #
# ------------------------------------------------------------------ #

@mcp.tool(name="unily_search")
async def unily_search(
    query: str,
    variables: dict | None = None,
    operation_name: str = "",
) -> dict:
    """Search Unily content via GraphQL.

    POST /api/v1/search — scope: gateway.graphql

    Example::

        query = \"\"\"
        query SearchContent($q: String!) {
          search(query: $q, take: 10) {
            items { id name url }
            totalItems
          }
        }
        \"\"\"
        variables = {"q": "annual report"}
    """
    return await _search(query, variables, operation_name or None)


# ------------------------------------------------------------------ #
# File store tools                                                      #
# ------------------------------------------------------------------ #

@mcp.tool(name="unily_file_upload")
async def unily_file_upload(
    file_base64: str,
    file_name: str,
    folder_path: str = "",
) -> dict:
    """Upload a file to the Unily file store.

    POST /api/v1/files — scope: gateway.files.data:readWrite

    Pass the file as a base64-encoded string. Claude can encode any file
    you upload to this conversation before calling this tool.

    Args:
        file_base64: Base64-encoded file contents.
        file_name: Filename including extension (e.g. "report.pdf").
        folder_path: Destination folder path, or empty for root.
    """
    return await _file_upload(file_base64, file_name, folder_path)


@mcp.tool(name="unily_file_replace")
async def unily_file_replace(
    file_path: str,
    file_base64: str,
    file_name: str,
) -> dict:
    """Replace an existing file in the Unily file store.

    PUT /api/v1/files/{path} — scope: gateway.files.data:readWrite

    Args:
        file_path: Relative path of the file to replace.
        file_base64: Base64-encoded replacement file contents.
        file_name: Filename including extension.
    """
    return await _file_replace(file_path, file_base64, file_name)


@mcp.tool(name="unily_file_download")
async def unily_file_download(file_path: str) -> dict:
    """Get file info from the Unily file store.

    GET /api/v1/files/{path} — scope: gateway.files.data:readWrite

    Args:
        file_path: Relative path of the file.
    """
    return await _file_download(file_path)


@mcp.tool(name="unily_file_delete")
async def unily_file_delete(file_path: str) -> dict:
    """Delete a file from the Unily file store.

    DELETE /api/v1/files/{path} — scope: gateway.files.data:readWrite

    Args:
        file_path: Relative path of the file to delete.
    """
    return await _file_delete(file_path)


# ------------------------------------------------------------------ #
# Logging configuration                                                 #
# ------------------------------------------------------------------ #

def _configure_logging() -> None:
    """Configure structlog for JSON output (production) or console (dev)."""
    log_format = os.environ.get("GROVE_LOG_FORMAT", "console").lower()
    log_level = os.environ.get("GROVE_LOG_LEVEL", "INFO").upper()

    import logging
    logging.basicConfig(
        format="%(message)s",
        level=getattr(logging, log_level, logging.INFO),
    )

    if log_format == "json":
        structlog.configure(
            processors=[
                structlog.stdlib.add_log_level,
                structlog.stdlib.add_logger_name,
                structlog.processors.TimeStamper(fmt="iso"),
                structlog.processors.JSONRenderer(),
            ],
            wrapper_class=structlog.stdlib.BoundLogger,
            context_class=dict,
            logger_factory=structlog.stdlib.LoggerFactory(),
        )
    else:
        structlog.configure(
            processors=[
                structlog.stdlib.add_log_level,
                structlog.processors.TimeStamper(fmt="%H:%M:%S"),
                structlog.dev.ConsoleRenderer(),
            ],
            wrapper_class=structlog.stdlib.BoundLogger,
            context_class=dict,
            logger_factory=structlog.stdlib.LoggerFactory(),
        )


# ------------------------------------------------------------------ #
# Entry point                                                           #
# ------------------------------------------------------------------ #

def main() -> None:
    _configure_logging()

    mode = os.environ.get("UNILY_MCP_MODE", "stdio").lower()
    host = os.environ.get("UNILY_MCP_HOST", "0.0.0.0")
    port = int(os.environ.get("UNILY_MCP_PORT", "8000"))

    # Validate credentials are present before starting; fail fast.
    from unily_mcp_server.security.secure_config import SecureConfig
    try:
        SecureConfig.get_secret("UNILY_CLIENT_ID")
        SecureConfig.get_secret("UNILY_CLIENT_SECRET")
    except Exception as exc:
        import sys
        print(f"FATAL: {exc}", file=sys.stderr)
        sys.exit(1)

    logger.info(
        "unily.server.starting",
        mode=mode,
        host=host if mode == "sse" else "n/a",
        port=port if mode == "sse" else "n/a",
        tool_count=len(mcp._tool_manager._tools) if hasattr(mcp, "_tool_manager") else "?",
    )

    if mode == "sse":
        mcp.run(transport="sse", host=host, port=port)
    else:
        mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
