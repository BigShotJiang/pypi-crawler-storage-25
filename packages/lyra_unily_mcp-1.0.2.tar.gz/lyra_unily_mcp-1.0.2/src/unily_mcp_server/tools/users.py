"""User-centric tools for the Unily API.

Covers followed content, followed users, followed social channels,
and personalisation settings.
"""

from typing import Any, Dict, List, Optional

from unily_mcp_server.clients.unily import UnilyAPIError
from unily_mcp_server.tools._helpers import get_unily_client


# ------------------------------------------------------------------ #
# Followed Content                                                      #
# ------------------------------------------------------------------ #

async def unily_followed_content_list(
    user_id: int,
    search: Optional[str] = None,
    skip: int = 0,
    take: int = 50,
    document_type_alias: Optional[str] = None,
) -> Dict[str, Any]:
    """List content items followed by a user.

    Args:
        user_id: Integer Unily user ID.
        search: Optional keyword filter.
        skip: Pagination offset (default 0).
        take: Page size (default 50).
        document_type_alias: Filter by document type alias.
    """
    client = get_unily_client()
    try:
        return await client.followed_content_list(
            user_id, search, skip, take, document_type_alias
        )
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}


async def unily_followed_content_add(
    user_id: int,
    content_id: int,
) -> Dict[str, Any]:
    """Follow a content item on behalf of a user.

    Args:
        user_id: Integer Unily user ID.
        content_id: Integer content ID to follow.
    """
    client = get_unily_client()
    try:
        return await client.followed_content_add(user_id, content_id)
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}


async def unily_followed_content_remove(
    user_id: int,
    content_id: int,
) -> Dict[str, Any]:
    """Unfollow a content item on behalf of a user.

    Args:
        user_id: Integer Unily user ID.
        content_id: Integer content ID to unfollow.
    """
    client = get_unily_client()
    try:
        await client.followed_content_remove(user_id, content_id)
        return {"success": True}
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}


# ------------------------------------------------------------------ #
# Followed Users                                                        #
# ------------------------------------------------------------------ #

async def unily_followed_users_list(
    user_id: int,
    search: Optional[str] = None,
    skip: int = 0,
    take: int = 50,
) -> Dict[str, Any]:
    """List users followed by a given user.

    Args:
        user_id: Integer Unily user ID.
        search: Optional keyword filter on followed user names.
        skip: Pagination offset.
        take: Page size.
    """
    client = get_unily_client()
    try:
        return await client.followed_users_list(user_id, search, skip, take)
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}


async def unily_followed_users_add(
    user_id: int,
    followed_user_id: int,
) -> Dict[str, Any]:
    """Follow another user on behalf of a user.

    Args:
        user_id: Integer Unily user ID (the follower).
        followed_user_id: Integer Unily user ID to follow.
    """
    client = get_unily_client()
    try:
        return await client.followed_users_add(user_id, followed_user_id)
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}


async def unily_followed_users_remove(
    user_id: int,
    followed_user_id: int,
) -> Dict[str, Any]:
    """Unfollow a user on behalf of a user.

    Args:
        user_id: Integer Unily user ID (the follower).
        followed_user_id: Integer Unily user ID to unfollow.
    """
    client = get_unily_client()
    try:
        await client.followed_users_remove(user_id, followed_user_id)
        return {"success": True}
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}


# ------------------------------------------------------------------ #
# Personalisation                                                       #
# ------------------------------------------------------------------ #

async def unily_personalisation_get(user_id: str) -> Dict[str, Any]:
    """Retrieve personalisation settings for a user.

    Args:
        user_id: UUID of the Unily user.

    Returns the user's current personalisation property/term assignments.
    """
    client = get_unily_client()
    try:
        return await client.personalisation_get(user_id)
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}


async def unily_personalisation_set_terms(
    user_id: str,
    property_alias: str,
    term_ids: List[str],
) -> Dict[str, Any]:
    """Set personalisation terms for a user property (bulk replace).

    Replaces all existing terms for the given property alias with the
    provided list.

    Args:
        user_id: UUID of the Unily user.
        property_alias: Personalisation property alias (e.g. "location").
        term_ids: List of term UUIDs to assign.
    """
    client = get_unily_client()
    try:
        return await client.personalisation_set_terms(user_id, property_alias, term_ids)
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}
