"""Media management tools for the Unily API.

Covers media items, images, and folders including binary upload.
File contents are passed as base64-encoded strings so Claude can forward
uploaded files directly to the Unily media library.
"""

import base64
import json
from typing import Any, Dict, Optional

from unily_mcp_server.clients.unily import UnilyAPIError
from unily_mcp_server.tools._helpers import get_unily_client


async def unily_media_create(
    file_base64: str,
    file_name: str,
    media_type_alias: str,
    parent_id: str = "",
    name: str = "",
) -> Dict[str, Any]:
    """Upload a new media item to Unily (POST /api/v1/media).

    Pass the file as a base64-encoded string — Claude can encode any uploaded
    file this way before calling this tool.

    Args:
        file_base64: Base64-encoded file contents.
        file_name: Original filename including extension (e.g. "hero.jpg").
        media_type_alias: Unily media type alias (e.g. "Image", "File", "Video").
        parent_id: UUID of the parent folder, or empty string for root.
        name: Display name for the media item — defaults to file_name if empty.
    """
    client = get_unily_client()
    try:
        file_bytes = base64.b64decode(file_base64)
    except Exception as exc:
        return {"error": f"Invalid base64 data: {exc}"}

    data: Dict[str, Any] = {
        "contentTypeAlias": media_type_alias,
        "name": name or file_name,
    }
    if parent_id:
        data["parentId"] = parent_id

    try:
        return await client.media_create(json.dumps(data), file_bytes, file_name)
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}


async def unily_media_replace(
    unique_id: str,
    file_base64: str,
    file_name: str,
    extra_data: Dict[str, Any] = {},
) -> Dict[str, Any]:
    """Replace a media item's file and metadata in full (PUT /api/v1/media/{uniqueId}).

    Use this to swap out the underlying file of an existing media item.
    For metadata-only changes use unily_media_update (PATCH) instead.

    Args:
        unique_id: UUID of the existing media item to replace.
        file_base64: Base64-encoded replacement file contents.
        file_name: Filename including extension.
        extra_data: Additional UpdateMedia fields to include (e.g. {"name": "new-name"}).
    """
    client = get_unily_client()
    try:
        file_bytes = base64.b64decode(file_base64)
    except Exception as exc:
        return {"error": f"Invalid base64 data: {exc}"}

    data: Dict[str, Any] = dict(extra_data)
    if "name" not in data:
        data["name"] = file_name

    try:
        return await client.media_replace(unique_id, json.dumps(data), file_bytes, file_name)
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}


async def unily_media_get(
    unique_id: str,
    include_descendants: bool = False,
) -> Dict[str, Any]:
    """Retrieve a media item by its UUID.

    Works for any media type (images, documents, video, etc.).

    Args:
        unique_id: Media item UUID.
        include_descendants: When True, include child items (for folders).

    Returns the media item metadata.
    """
    client = get_unily_client()
    try:
        return await client.media_get(unique_id, include_descendants)
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}


async def unily_media_folder_get(unique_id: str) -> Dict[str, Any]:
    """Retrieve a media folder by its UUID.

    Args:
        unique_id: Media folder UUID.
    """
    client = get_unily_client()
    try:
        return await client.media_folder_get(unique_id)
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}


async def unily_media_update(
    unique_id: str,
    data: Dict[str, Any],
) -> Dict[str, Any]:
    """Update media item metadata (name, alt text, folder, etc.).

    File content cannot be replaced through this tool.  To replace the
    actual file binary use the Unily admin UI or the API directly.

    The *data* dict is serialised to JSON and sent as the ``data`` form field
    (UpdateMedia schema).  Common fields::

        {
          "name": "hero-banner-2025",
          "parentId": "<folder-uuid>"
        }

    Args:
        unique_id: Media item UUID.
        data: UpdateMedia fields (no file replacement).
    """
    import json

    client = get_unily_client()
    try:
        return await client.media_update(unique_id, json.dumps(data))
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}


async def unily_media_delete(unique_id: str) -> Dict[str, Any]:
    """Permanently delete a media item by UUID.

    Note: This is a direct delete (no draft/confirm) because media items do
    not have the same cascade-delete risk as content hierarchies.

    Args:
        unique_id: Media item UUID.
    """
    client = get_unily_client()
    try:
        await client.media_delete(unique_id)
        return {"success": True, "deleted_unique_id": unique_id}
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}


async def unily_media_folder_create(
    name: str,
    parent_id: Optional[str] = None,
) -> Dict[str, Any]:
    """Create a new media folder.

    Args:
        name: Display name for the folder.
        parent_id: UUID of the parent folder, or None for root level.
    """
    client = get_unily_client()
    folder: Dict[str, Any] = {"name": name}
    if parent_id:
        folder["parentId"] = parent_id
    try:
        return await client.media_folder_create(folder)
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}
