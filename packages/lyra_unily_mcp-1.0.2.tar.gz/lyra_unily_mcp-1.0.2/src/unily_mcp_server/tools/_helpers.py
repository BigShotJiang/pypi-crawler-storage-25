"""Shared helpers for tool implementations."""

from unily_mcp_server.clients.unily import UnilyClient

# Process-level singleton client; created once, reused across all tool calls.
_client: UnilyClient | None = None


def get_unily_client() -> UnilyClient:
    """Return the process-level UnilyClient singleton."""
    global _client
    if _client is None:
        _client = UnilyClient()
    return _client
