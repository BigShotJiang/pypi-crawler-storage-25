"""Social tools for the Unily API.

Covers social comments, content reactions, and reaction type listing.
Comment deletion uses the draft/confirm pattern because comments are
visible to other users and cannot be undone.
"""

from typing import Any, Dict, Optional

from unily_mcp_server.clients.unily import UnilyAPIError
from unily_mcp_server.tools._helpers import get_unily_client

# Draft store for comment delete confirmation.
_comment_delete_drafts: Dict[str, int] = {}
_DRAFT_COUNTER = [0]


def _new_draft_id() -> str:
    _DRAFT_COUNTER[0] += 1
    return f"cmt_del_{_DRAFT_COUNTER[0]}"


async def unily_social_comment_get(comment_id: int) -> Dict[str, Any]:
    """Retrieve a social comment by ID.

    Args:
        comment_id: Integer comment ID.
    """
    client = get_unily_client()
    try:
        return await client.social_comment_get(comment_id)
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}


async def unily_social_comment_create(comment: Dict[str, Any]) -> Dict[str, Any]:
    """Create a new social comment.

    The *comment* dict is a CreateCommentModel.  Required fields::

        {
          "contentId": 1234,
          "text": "Great article!",
          "userUniqueId": "<user-uuid>"
        }

    Returns the created comment.
    """
    client = get_unily_client()
    try:
        return await client.social_comment_create(comment)
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}


async def unily_social_comment_update(
    comment_id: int,
    comment: Dict[str, Any],
) -> Dict[str, Any]:
    """Update an existing social comment.

    Args:
        comment_id: Integer comment ID.
        comment: UpdateCommentModel fields (e.g. {"text": "Updated text"}).
    """
    client = get_unily_client()
    try:
        return await client.social_comment_update(comment_id, comment)
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}


async def unily_social_comment_delete_draft(comment_id: int) -> Dict[str, Any]:
    """Stage a social comment deletion for confirmation.

    Deleting a comment is visible to other users and cannot be undone.
    Call unily_social_comment_delete_confirm(draft_id) to proceed.

    Args:
        comment_id: Integer comment ID.
    """
    client = get_unily_client()
    try:
        item = await client.social_comment_get(comment_id)
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}

    draft_id = _new_draft_id()
    _comment_delete_drafts[draft_id] = comment_id

    text_preview = ""
    if isinstance(item, dict):
        text_preview = str(item.get("text", ""))[:100]

    return {
        "draft_id": draft_id,
        "action": "delete_comment",
        "comment_id": comment_id,
        "text_preview": text_preview,
        "warning": (
            "This will permanently delete the comment. "
            "Call unily_social_comment_delete_confirm with this draft_id to proceed."
        ),
    }


async def unily_social_comment_delete_confirm(draft_id: str) -> Dict[str, Any]:
    """Execute a staged comment deletion.

    Args:
        draft_id: The draft_id returned by unily_social_comment_delete_draft.
    """
    comment_id = _comment_delete_drafts.pop(draft_id, None)
    if comment_id is None:
        return {
            "error": f"No pending delete draft with id '{draft_id}'. "
            "Call unily_social_comment_delete_draft first."
        }

    client = get_unily_client()
    try:
        await client.social_comment_delete(comment_id)
        return {"success": True, "deleted_comment_id": comment_id}
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}


async def unily_social_reaction_types_list(
    applicable_document_types: Optional[str] = None,
    content_id: int = 0,
) -> Dict[str, Any]:
    """List available social reaction types.

    Args:
        applicable_document_types: Comma-separated document type aliases to filter.
        content_id: Content item ID to contextualise reactions (default 0).

    Returns a list of reaction type definitions.
    """
    client = get_unily_client()
    try:
        result = await client.social_reaction_types_list(
            applicable_document_types=applicable_document_types,
            content_id=content_id,
        )
        return {"reaction_types": result} if isinstance(result, list) else result
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}


async def unily_content_reaction_set(
    content_unique_id: str,
    reaction: Dict[str, Any],
) -> Dict[str, Any]:
    """Create or update a reaction on a content item.

    Args:
        content_unique_id: UUID of the content item.
        reaction: Reaction body, e.g. {"reactionName": "like", "userUniqueId": "<uuid>"}.
    """
    client = get_unily_client()
    try:
        return await client.content_reaction_put(content_unique_id, reaction)
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}


async def unily_content_reaction_delete(
    content_unique_id: str,
    user_unique_id: str,
) -> Dict[str, Any]:
    """Remove a user's reaction from a content item.

    Args:
        content_unique_id: UUID of the content item.
        user_unique_id: UUID of the user whose reaction to remove.
    """
    client = get_unily_client()
    try:
        await client.content_reaction_delete(content_unique_id, user_unique_id)
        return {"success": True}
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}
