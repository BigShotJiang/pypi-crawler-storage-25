"""Form submission tools for the Unily API."""

from typing import Any, Dict, Optional

from unily_mcp_server.clients.unily import UnilyAPIError
from unily_mcp_server.tools._helpers import get_unily_client


async def unily_forms_list(
    scope: str,
    limit: int = 50,
    skip: int = 0,
    form_ids: Optional[str] = None,
    approval_state: Optional[str] = None,
    match: Optional[str] = None,
    from_date: Optional[str] = None,
    to_date: Optional[str] = None,
    sort: Optional[str] = None,
    sort_order: Optional[str] = None,
) -> Dict[str, Any]:
    """List form submissions.

    Args:
        scope: Required — submission scope (e.g. "all", "mine").
        limit: Maximum number of results (required by API).
        skip: Pagination offset.
        form_ids: Comma-separated form IDs to filter.
        approval_state: Filter by approval state.
        match: Keyword search within submissions.
        from_date: ISO-8601 start date filter.
        to_date: ISO-8601 end date filter.
        sort: Sort field.
        sort_order: "asc" or "desc".
    """
    client = get_unily_client()
    params: Dict[str, Any] = {"scope": scope, "limit": limit, "skip": skip}
    if form_ids:
        params["formIds"] = form_ids
    if approval_state:
        params["approvalState"] = approval_state
    if match:
        params["match"] = match
    if from_date:
        params["from"] = from_date
    if to_date:
        params["to"] = to_date
    if sort:
        params["sort"] = sort
    if sort_order:
        params["sortOrder"] = sort_order

    try:
        return await client.form_submissions_list(params)
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}


async def unily_form_submission_get(submission_id: str) -> Dict[str, Any]:
    """Get a single form submission by ID.

    Args:
        submission_id: String submission ID.
    """
    client = get_unily_client()
    try:
        return await client.form_submission_get(submission_id)
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}


async def unily_form_submission_update_approval(
    submission_id: str,
    approval_state: str,
    comment: Optional[str] = None,
) -> Dict[str, Any]:
    """Update the approval status of a form submission.

    Args:
        submission_id: String submission ID.
        approval_state: New state (e.g. "approved", "rejected", "pending").
        comment: Optional reviewer comment.
    """
    client = get_unily_client()
    body: Dict[str, Any] = {"approvalState": approval_state}
    if comment is not None:
        body["comment"] = comment

    try:
        return await client.form_submission_update_approval(submission_id, body)
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}
