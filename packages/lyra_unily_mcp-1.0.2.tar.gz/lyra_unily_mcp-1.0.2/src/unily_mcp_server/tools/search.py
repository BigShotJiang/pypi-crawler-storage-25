"""GraphQL search tool for the Unily API.

The Unily search endpoint accepts a standard GraphQL query and returns
results via POST /api/v1/search (scope: gateway.graphql).
"""

from typing import Any, Dict, Optional

from unily_mcp_server.clients.unily import UnilyAPIError
from unily_mcp_server.tools._helpers import get_unily_client


async def unily_search(
    query: str,
    variables: Optional[Dict[str, Any]] = None,
    operation_name: Optional[str] = None,
) -> Dict[str, Any]:
    """Search Unily content using a GraphQL query.

    This sends a standard GraphQL request to the Unily search endpoint.
    The query string should be a valid GraphQL query document.

    Example::

        query = '''
        query SearchContent($q: String!) {
          search(query: $q, take: 10) {
            items {
              id
              name
              url
            }
            totalItems
          }
        }
        '''
        variables = {"q": "annual report"}

    Args:
        query: GraphQL query string.
        variables: Optional query variables dict.
        operation_name: Optional operation name (for multi-operation documents).

    Returns the GraphQL response object (``{"data": {...}}`` or
    ``{"errors": [...]})``).
    """
    client = get_unily_client()
    body: Dict[str, Any] = {"query": query}
    if variables is not None:
        body["variables"] = variables
    if operation_name is not None:
        body["operationName"] = operation_name

    try:
        return await client.search(body)
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}
