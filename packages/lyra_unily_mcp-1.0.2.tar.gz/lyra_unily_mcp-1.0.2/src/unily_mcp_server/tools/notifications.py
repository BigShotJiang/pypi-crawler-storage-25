"""Notification tools for the Unily API."""

from typing import Any, Dict, Optional

from unily_mcp_server.clients.unily import UnilyAPIError
from unily_mcp_server.tools._helpers import get_unily_client


async def unily_notifications_list(
    user_id: int,
    skip: int = 0,
    take: int = 50,
    since: Optional[str] = None,
    order_by: Optional[str] = None,
) -> Dict[str, Any]:
    """List notifications for a user.

    Args:
        user_id: Integer Unily user ID.
        skip: Offset for pagination (default 0).
        take: Page size (default 50).
        since: ISO-8601 datetime — only return notifications after this time.
        order_by: Sort field (e.g. "createdAt").

    Returns a paginated list of notification objects.
    """
    client = get_unily_client()
    try:
        return await client.notifications_list(user_id, since, skip, take, order_by)
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}


async def unily_notifications_send(notification: Dict[str, Any]) -> Dict[str, Any]:
    """Send a notification to one or more users via the notification hub.

    The *notification* body is a Notification object.  Key fields::

        {
          "title": "Important Update",
          "body": "Please review the new policy.",
          "url": "https://lyra.unily.com/content/...",
          "audienceAliases": ["all-users"]
        }

    audienceAliases: Dynamic audience aliases from the CMS, or static
    audience IDs prefixed with ``staticAudiences``.

    Returns the created notification or an error dict.
    """
    client = get_unily_client()
    try:
        return await client.notifications_send(notification)
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}


async def unily_notification_delete(
    user_id: int,
    notification_id: int,
) -> Dict[str, Any]:
    """Delete a specific notification for a user.

    Args:
        user_id: Integer Unily user ID.
        notification_id: Integer notification ID.
    """
    client = get_unily_client()
    try:
        await client.notification_delete(user_id, notification_id)
        return {"success": True, "deleted_notification_id": notification_id}
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}
