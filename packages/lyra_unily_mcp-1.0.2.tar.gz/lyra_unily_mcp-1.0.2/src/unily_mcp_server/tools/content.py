"""Content management tools for the Unily API.

Covers:
  - Content query (POST /api/v1/content/query)
  - Content get by UUID
  - Content create / update (patch)
  - Content delete with draft/confirm pattern (destructive — deletes all children)
  - Content schedule get / update
  - Document type listing
"""

from typing import Any, Dict, Optional

from unily_mcp_server.clients.unily import UnilyAPIError
from unily_mcp_server.tools._helpers import get_unily_client

# In-process draft store for the delete-confirm pattern.
# key: draft_id (str) → value: content_unique_id (str)
_delete_drafts: Dict[str, str] = {}
_DRAFT_COUNTER = [0]


def _new_draft_id() -> str:
    _DRAFT_COUNTER[0] += 1
    return f"del_{_DRAFT_COUNTER[0]}"


# ------------------------------------------------------------------ #
# Content Query                                                         #
# ------------------------------------------------------------------ #

async def unily_content_query(query: Dict[str, Any]) -> Dict[str, Any]:
    """Search and filter Unily content using the structured query API.

    The *query* parameter is passed directly to POST /api/v1/content/query.
    Common fields::

        {
          "documentTypes": ["newsArticle"],
          "keyword": "annual report",
          "skip": 0,
          "take": 20,
          "sort": "updatedAt",
          "sortOrder": "desc"
        }

    Returns a paginated list of content items.
    """
    client = get_unily_client()
    try:
        return await client.content_query(query)
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}


# ------------------------------------------------------------------ #
# Content Get                                                           #
# ------------------------------------------------------------------ #

async def unily_content_get(
    unique_id: str,
    include_descendants: bool = False,
) -> Dict[str, Any]:
    """Retrieve a single content item by its UUID.

    Args:
        unique_id: The content item's UUID (e.g. "3a4b5c6d-…").
        include_descendants: When True, include child content items.

    Returns the full content item object or an error dict.
    """
    client = get_unily_client()
    try:
        return await client.content_get_by_uuid(unique_id, include_descendants)
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}


# ------------------------------------------------------------------ #
# Content Create                                                        #
# ------------------------------------------------------------------ #

async def unily_content_create(content: Dict[str, Any]) -> Dict[str, Any]:
    """Create a new content item in Unily.

    The *content* body should be a CreateContent object.  Required fields
    vary by document type, but typically include::

        {
          "name": "My Article",
          "documentTypeAlias": "newsArticle",
          "parentId": "<parent-uuid>",
          "properties": { ... }
        }

    Returns the created content item.
    """
    client = get_unily_client()
    try:
        return await client.content_create(content)
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}


# ------------------------------------------------------------------ #
# Content Update (PATCH)                                                #
# ------------------------------------------------------------------ #

async def unily_content_update(
    unique_id: str,
    patch: Dict[str, Any],
) -> Dict[str, Any]:
    """Update specific fields of a content item (PATCH semantics).

    Only the fields present in *patch* are modified.  Example::

        {
          "properties": {
            "title": "Updated Title",
            "bodyText": "<p>New body.</p>"
          }
        }

    Args:
        unique_id: UUID of the content item to update.
        patch: Partial content update (PatchContent schema).

    Returns the updated content item.
    """
    client = get_unily_client()
    try:
        return await client.content_update(unique_id, patch)
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}


# ------------------------------------------------------------------ #
# Content Delete — draft/confirm pattern                               #
# ------------------------------------------------------------------ #

async def unily_content_delete_draft(unique_id: str) -> Dict[str, Any]:
    """Stage a content deletion for confirmation.

    WARNING: Deleting content in Unily also deletes ALL descendant items.
    Call unily_content_delete_confirm(draft_id) to proceed.

    Args:
        unique_id: UUID of the content item to delete.

    Returns a draft object with a draft_id to pass to confirm.
    """
    client = get_unily_client()
    # Verify the item exists before creating a draft.
    try:
        item = await client.content_get_by_uuid(unique_id)
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}

    draft_id = _new_draft_id()
    _delete_drafts[draft_id] = unique_id

    name = item.get("name", unique_id) if isinstance(item, dict) else unique_id
    return {
        "draft_id": draft_id,
        "action": "delete_content",
        "unique_id": unique_id,
        "content_name": name,
        "warning": (
            "This will permanently delete the content item and ALL its children. "
            "Call unily_content_delete_confirm with this draft_id to proceed."
        ),
    }


async def unily_content_delete_confirm(draft_id: str) -> Dict[str, Any]:
    """Execute a staged content deletion.

    Args:
        draft_id: The draft_id returned by unily_content_delete_draft.

    Returns a success/error dict.
    """
    unique_id = _delete_drafts.pop(draft_id, None)
    if unique_id is None:
        return {
            "error": f"No pending delete draft with id '{draft_id}'. "
            "Call unily_content_delete_draft first."
        }

    client = get_unily_client()
    try:
        await client.content_delete(unique_id)
        return {"success": True, "deleted_unique_id": unique_id}
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}


# ------------------------------------------------------------------ #
# Content Schedule                                                      #
# ------------------------------------------------------------------ #

async def unily_content_schedule_get(unique_id: str) -> Dict[str, Any]:
    """Get the publish/unpublish schedule for a content item.

    Args:
        unique_id: UUID of the content item.
    """
    client = get_unily_client()
    try:
        return await client.content_schedule_get(unique_id)
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}


async def unily_content_schedule_update(
    unique_id: str,
    schedule: Dict[str, Any],
) -> Dict[str, Any]:
    """Update the publish/unpublish schedule for a content item.

    The *schedule* body is an UpdateContentSchedule object, e.g.::

        {
          "publishDate": "2025-06-01T09:00:00Z",
          "unpublishDate": "2025-12-31T23:59:59Z"
        }

    Args:
        unique_id: UUID of the content item.
        schedule: Schedule update object.
    """
    client = get_unily_client()
    try:
        return await client.content_schedule_update(unique_id, schedule)
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}


# ------------------------------------------------------------------ #
# Document Types                                                        #
# ------------------------------------------------------------------ #

async def unily_document_types_list(
    iso_code: Optional[str] = None,
) -> Dict[str, Any]:
    """List all Unily document types (content schemas).

    Args:
        iso_code: Optional language ISO code to localise label values.

    Returns a list of document type definitions.
    """
    client = get_unily_client()
    try:
        result = await client.document_types_list(iso_code)
        return {"document_types": result} if isinstance(result, list) else result
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}


async def unily_document_type_get(
    alias: str,
    iso_code: Optional[str] = None,
) -> Dict[str, Any]:
    """Get a specific document type definition by alias.

    Args:
        alias: Document type alias (e.g. "newsArticle").
        iso_code: Optional language ISO code.
    """
    client = get_unily_client()
    try:
        return await client.document_type_get(alias, iso_code)
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}
