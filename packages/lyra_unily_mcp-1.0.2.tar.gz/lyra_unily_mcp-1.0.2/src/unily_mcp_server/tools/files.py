"""File management tools for the Unily API.

Covers raw file upload, replacement, download, and deletion via
/api/v1/files.  File contents are passed as base64-encoded strings
so Claude can forward uploaded files directly.
"""

import base64
from typing import Any, Dict

from unily_mcp_server.clients.unily import UnilyAPIError
from unily_mcp_server.tools._helpers import get_unily_client


async def unily_file_upload(
    file_base64: str,
    file_name: str,
    folder_path: str = "",
) -> Dict[str, Any]:
    """Upload a file to the Unily file store (POST /api/v1/files).

    Pass the file as a base64-encoded string — Claude can encode any uploaded
    file this way before calling this tool.

    Args:
        file_base64: Base64-encoded file contents.
        file_name: Filename including extension (e.g. "report.pdf").
        folder_path: Destination folder path within the file store, or empty
                     string to upload to the root.
    """
    client = get_unily_client()
    try:
        file_bytes = base64.b64decode(file_base64)
    except Exception as exc:
        return {"error": f"Invalid base64 data: {exc}"}

    try:
        return await client.file_upload(file_bytes, file_name, folder_path)
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}


async def unily_file_replace(
    file_path: str,
    file_base64: str,
    file_name: str,
) -> Dict[str, Any]:
    """Replace an existing file in the Unily file store (PUT /api/v1/files/{path}).

    Overwrites the file at *file_path* with new contents.  The path is the
    relative path returned when the file was originally uploaded.

    Args:
        file_path: Relative path of the file to replace (e.g. "documents/report.pdf").
        file_base64: Base64-encoded replacement file contents.
        file_name: Filename including extension.
    """
    client = get_unily_client()
    try:
        file_bytes = base64.b64decode(file_base64)
    except Exception as exc:
        return {"error": f"Invalid base64 data: {exc}"}

    try:
        return await client.file_replace(file_path, file_bytes, file_name)
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}


async def unily_file_download(file_path: str) -> Dict[str, Any]:
    """Download file metadata/info from the Unily file store (GET /api/v1/files/{path}).

    Args:
        file_path: Relative path of the file (e.g. "documents/report.pdf").
    """
    client = get_unily_client()
    try:
        return await client.file_download(file_path)
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}


async def unily_file_delete(file_path: str) -> Dict[str, Any]:
    """Delete a file from the Unily file store (DELETE /api/v1/files/{path}).

    Args:
        file_path: Relative path of the file to delete.
    """
    client = get_unily_client()
    try:
        await client.file_delete(file_path)
        return {"success": True, "deleted_path": file_path}
    except UnilyAPIError as exc:
        return {"error": str(exc), "status_code": exc.status_code}
