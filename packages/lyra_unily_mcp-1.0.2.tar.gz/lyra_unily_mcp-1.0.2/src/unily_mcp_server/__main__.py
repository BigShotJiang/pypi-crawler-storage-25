"""Entry point for `python -m unily_mcp_server`."""

from unily_mcp_server.server import main

main()
