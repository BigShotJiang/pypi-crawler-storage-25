"""Unily MCP Server — Model Context Protocol server for the Unily intranet platform."""

__version__ = "1.0.2"
