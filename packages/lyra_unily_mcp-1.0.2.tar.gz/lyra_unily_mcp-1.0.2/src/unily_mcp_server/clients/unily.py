"""Typed async HTTP client for the Unily API.

All requests are authenticated with a bearer token obtained via OAuth2
client credentials (see auth.token_manager).  On 401 the client
invalidates the cached token and retries once before raising.

Base URL: https://lyra-api.unily.com (overridable via UNILY_API_BASE_URL).
"""

import os
from typing import Any, Dict, List, Optional

import httpx
import structlog

from unily_mcp_server.auth.token_manager import get_token_manager, TokenManagerError

logger = structlog.get_logger()

_DEFAULT_BASE_URL = "https://lyra-api.unily.com"
_DEFAULT_TIMEOUT = 30.0


class UnilyAPIError(Exception):
    """Raised when the Unily API returns a non-2xx response."""

    def __init__(self, status_code: int, body: str, url: str) -> None:
        self.status_code = status_code
        self.body = body
        self.url = url
        super().__init__(f"Unily API {status_code} at {url}: {body[:200]}")


class UnilyClient:
    """Async Unily REST API client with automatic bearer-token refresh.

    Instantiate once and share across tool calls — the underlying
    httpx.AsyncClient is *not* kept open between calls; a new client is
    created per-request so the class is safe in any stateless environment
    without connection pool leakage.
    """

    def __init__(self) -> None:
        self._base_url = os.environ.get("UNILY_API_BASE_URL", _DEFAULT_BASE_URL).rstrip("/")
        self._timeout = float(os.environ.get("UNILY_API_TIMEOUT", str(_DEFAULT_TIMEOUT)))

    async def _get_headers(self) -> Dict[str, str]:
        manager = get_token_manager()
        token = await manager.get_token()
        return {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Any] = None,
        data: Optional[Any] = None,
        files: Optional[Any] = None,
        retry_on_401: bool = True,
    ) -> Any:
        """Execute an HTTP request and return the parsed JSON body.

        On 401, invalidates the cached token and retries once.
        """
        url = f"{self._base_url}{path}"
        headers = await self._get_headers()

        # When sending multipart/form-data, let httpx set the content-type.
        if files is not None:
            headers.pop("Content-Type", None)

        try:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                response = await client.request(
                    method,
                    url,
                    headers=headers,
                    params=params,
                    json=json,
                    data=data,
                    files=files,
                )
        except httpx.RequestError as exc:
            raise UnilyAPIError(0, str(exc), url) from exc

        if response.status_code == 401 and retry_on_401:
            # Token may have been revoked or expired mid-flight; invalidate and retry.
            get_token_manager().invalidate()
            return await self._request(
                method, path, params=params, json=json, data=data,
                files=files, retry_on_401=False,
            )

        if response.status_code == 429:
            raise UnilyAPIError(429, "Rate limit reached, try again later", url)

        if not response.is_success:
            raise UnilyAPIError(response.status_code, response.text, url)

        # 204 No Content → return empty dict
        if response.status_code == 204 or not response.content:
            return {}

        return response.json()

    # ------------------------------------------------------------------ #
    # Content                                                               #
    # ------------------------------------------------------------------ #

    async def content_query(self, query: Dict[str, Any]) -> Any:
        return await self._request("POST", "/api/v1/content/query", json=query)

    async def content_get_by_uuid(self, unique_id: str, include_descendants: bool = False) -> Any:
        return await self._request(
            "GET",
            f"/api/v1/content/{unique_id}",
            params={"includeDescendants": str(include_descendants).lower()},
        )

    async def content_create(self, content: Dict[str, Any]) -> Any:
        return await self._request("POST", "/api/v1/content", json=content)

    async def content_update(self, unique_id: str, patch: Dict[str, Any]) -> Any:
        return await self._request("PATCH", f"/api/v1/content/{unique_id}", json=patch)

    async def content_put(self, unique_id: str, content: Dict[str, Any]) -> Any:
        return await self._request("PUT", f"/api/v1/content/{unique_id}", json=content)

    async def content_delete(self, unique_id: str) -> Any:
        return await self._request("DELETE", f"/api/v1/content/{unique_id}")

    async def content_schedule_get(self, unique_id: str) -> Any:
        return await self._request("GET", f"/api/v1/content-schedules/{unique_id}")

    async def content_schedule_update(
        self, unique_id: str, schedule: Dict[str, Any]
    ) -> Any:
        return await self._request(
            "PUT", f"/api/v1/content-schedules/{unique_id}", json=schedule
        )

    # ------------------------------------------------------------------ #
    # Document Types                                                        #
    # ------------------------------------------------------------------ #

    async def document_types_list(self, iso_code: Optional[str] = None) -> Any:
        params: Dict[str, Any] = {}
        if iso_code:
            params["isoCode"] = iso_code
        return await self._request("GET", "/api/v1/document-types", params=params or None)

    async def document_type_get(
        self, alias: str, iso_code: Optional[str] = None
    ) -> Any:
        params: Dict[str, Any] = {}
        if iso_code:
            params["isoCode"] = iso_code
        return await self._request(
            "GET", f"/api/v1/document-types/{alias}", params=params or None
        )

    # ------------------------------------------------------------------ #
    # Media                                                                 #
    # ------------------------------------------------------------------ #

    async def media_get(self, unique_id: str, include_descendants: bool = False) -> Any:
        return await self._request(
            "GET",
            f"/api/v1/media/{unique_id}",
            params={"includeDescendants": str(include_descendants).lower()},
        )

    async def media_create(self, data_json: str, file_bytes: Optional[bytes] = None, file_name: str = "upload") -> Any:
        form_data: Dict[str, Any] = {"data": data_json}
        files = None
        if file_bytes is not None:
            files = {"umbracoFile": (file_name, file_bytes, "application/octet-stream")}
        return await self._request("POST", "/api/v1/media", data=form_data, files=files)

    async def media_update(
        self, unique_id: str, data_json: str, file_bytes: Optional[bytes] = None, file_name: str = "upload"
    ) -> Any:
        form_data: Dict[str, Any] = {"data": data_json}
        files = None
        if file_bytes is not None:
            files = {"umbracoFile": (file_name, file_bytes, "application/octet-stream")}
        return await self._request(
            "PATCH", f"/api/v1/media/{unique_id}", data=form_data, files=files
        )

    async def media_replace(
        self, unique_id: str, data_json: str, file_bytes: Optional[bytes] = None, file_name: str = "upload"
    ) -> Any:
        form_data: Dict[str, Any] = {"data": data_json}
        files = None
        if file_bytes is not None:
            files = {"umbracoFile": (file_name, file_bytes, "application/octet-stream")}
        return await self._request(
            "PUT", f"/api/v1/media/{unique_id}", data=form_data, files=files
        )

    async def media_delete(self, unique_id: str) -> Any:
        return await self._request("DELETE", f"/api/v1/media/{unique_id}")

    async def media_folder_get(self, unique_id: str) -> Any:
        return await self._request("GET", f"/api/v1/media/folders/{unique_id}")

    async def media_folder_create(self, folder: Dict[str, Any]) -> Any:
        return await self._request("POST", "/api/v1/media/folders", json=folder)

    # ------------------------------------------------------------------ #
    # Social                                                                #
    # ------------------------------------------------------------------ #

    async def social_comment_get(self, comment_id: int) -> Any:
        return await self._request("GET", f"/api/v1/social-comments/{comment_id}")

    async def social_comment_create(self, comment: Dict[str, Any]) -> Any:
        return await self._request("POST", "/api/v1/social-comments", json=comment)

    async def social_comment_update(self, comment_id: int, comment: Dict[str, Any]) -> Any:
        return await self._request(
            "PUT", f"/api/v1/social-comments/{comment_id}", json=comment
        )

    async def social_comment_delete(self, comment_id: int) -> Any:
        return await self._request("DELETE", f"/api/v1/social-comments/{comment_id}")

    async def social_reaction_types_list(
        self,
        applicable_document_types: Optional[str] = None,
        social_messages_enabled: Optional[bool] = None,
        content_id: int = 0,
    ) -> Any:
        params: Dict[str, Any] = {"contentId": content_id}
        if applicable_document_types:
            params["applicableDocumentTypes"] = applicable_document_types
        if social_messages_enabled is not None:
            params["socialMessagesEnabled"] = str(social_messages_enabled).lower()
        return await self._request("GET", "/api/v1/social-reaction-types", params=params)

    async def content_reaction_put(
        self, content_unique_id: str, reaction: Dict[str, Any]
    ) -> Any:
        return await self._request(
            "PUT", f"/api/v1/content-reactions/{content_unique_id}", json=reaction
        )

    async def content_reaction_delete(
        self, content_unique_id: str, user_unique_id: str
    ) -> Any:
        return await self._request(
            "DELETE",
            f"/api/v1/content-reactions/{content_unique_id}",
            params={"userUniqueId": user_unique_id},
        )

    # ------------------------------------------------------------------ #
    # Notifications                                                         #
    # ------------------------------------------------------------------ #

    async def notifications_list(
        self,
        user_id: int,
        since: Optional[str] = None,
        skip: int = 0,
        take: int = 50,
        order_by: Optional[str] = None,
    ) -> Any:
        params: Dict[str, Any] = {"skip": skip, "take": take}
        if since:
            params["since"] = since
        if order_by:
            params["orderBy"] = order_by
        return await self._request(
            "GET", f"/api/v1/notifications/{user_id}", params=params
        )

    async def notifications_send(self, notification: Dict[str, Any]) -> Any:
        return await self._request("POST", "/api/v1/notifications", json=notification)

    async def notifications_delete_all(self, user_id: int) -> Any:
        return await self._request("DELETE", f"/api/v1/notifications/{user_id}")

    async def notification_delete(self, user_id: int, notification_id: int) -> Any:
        return await self._request(
            "DELETE",
            f"/api/v1/notifications/{user_id}/notification/{notification_id}",
        )

    # ------------------------------------------------------------------ #
    # Users — Followed Content & Users                                     #
    # ------------------------------------------------------------------ #

    async def followed_content_list(
        self,
        user_id: int,
        search: Optional[str] = None,
        skip: int = 0,
        take: int = 50,
        document_type_alias: Optional[str] = None,
    ) -> Any:
        params: Dict[str, Any] = {"skip": skip, "take": take}
        if search:
            params["search"] = search
        if document_type_alias:
            params["documentTypeAlias"] = document_type_alias
        return await self._request(
            "GET", f"/api/v1/followed-content/{user_id}", params=params
        )

    async def followed_content_add(self, user_id: int, content_id: int) -> Any:
        return await self._request(
            "POST", f"/api/v1/followed-content/{user_id}", json=content_id
        )

    async def followed_content_remove(self, user_id: int, content_id: int) -> Any:
        return await self._request(
            "DELETE", f"/api/v1/followed-content/{user_id}/{content_id}"
        )

    async def followed_users_list(
        self,
        user_id: int,
        search: Optional[str] = None,
        skip: int = 0,
        take: int = 50,
    ) -> Any:
        params: Dict[str, Any] = {"skip": skip, "take": take}
        if search:
            params["search"] = search
        return await self._request(
            "GET", f"/api/v1/followed-users/{user_id}", params=params
        )

    async def followed_users_add(self, user_id: int, followed_user_id: int) -> Any:
        return await self._request(
            "POST", f"/api/v1/followed-users/{user_id}", json=followed_user_id
        )

    async def followed_users_remove(self, user_id: int, followed_user_id: int) -> Any:
        return await self._request(
            "DELETE", f"/api/v1/followed-users/{user_id}/{followed_user_id}"
        )

    # ------------------------------------------------------------------ #
    # Form Submissions                                                      #
    # ------------------------------------------------------------------ #

    async def form_submissions_list(self, params: Dict[str, Any]) -> Any:
        return await self._request("GET", "/api/v1/form-submissions", params=params)

    async def form_submission_get(self, submission_id: str) -> Any:
        return await self._request("GET", f"/api/v1/form-submissions/{submission_id}")

    async def form_submission_delete(self, submission_id: str) -> Any:
        return await self._request(
            "DELETE", f"/api/v1/form-submissions/{submission_id}"
        )

    async def form_submission_update_approval(
        self, submission_id: str, status: Dict[str, Any]
    ) -> Any:
        return await self._request(
            "PATCH",
            f"/api/v1/form-submissions/{submission_id}/approval-status",
            json=status,
        )

    # ------------------------------------------------------------------ #
    # Personalisation                                                       #
    # ------------------------------------------------------------------ #

    async def personalisation_get(self, user_id: str) -> Any:
        return await self._request("GET", f"/api/v1/personalisation/{user_id}")

    async def personalisation_set_terms(
        self, user_id: str, alias: str, term_ids: List[str]
    ) -> Any:
        return await self._request(
            "PUT",
            f"/api/v1/personalisation/{user_id}/properties/{alias}/terms",
            json=term_ids,
        )

    # ------------------------------------------------------------------ #
    # Search (GraphQL)                                                      #
    # ------------------------------------------------------------------ #

    async def search(self, graphql_query: Dict[str, Any]) -> Any:
        return await self._request("POST", "/api/v1/search", json=graphql_query)

    # ------------------------------------------------------------------ #
    # Files                                                                 #
    # ------------------------------------------------------------------ #

    async def file_download(self, file_path: str) -> Any:
        return await self._request("GET", f"/api/v1/files/{file_path}")

    async def file_upload(self, file_bytes: bytes, file_name: str, folder_path: str = "") -> Any:
        files = {"file": (file_name, file_bytes, "application/octet-stream")}
        data = {"folderPath": folder_path} if folder_path else {}
        return await self._request("POST", "/api/v1/files", data=data or None, files=files)

    async def file_replace(self, file_path: str, file_bytes: bytes, file_name: str) -> Any:
        files = {"file": (file_name, file_bytes, "application/octet-stream")}
        return await self._request("PUT", f"/api/v1/files/{file_path}", files=files)

    async def file_delete(self, file_path: str) -> Any:
        return await self._request("DELETE", f"/api/v1/files/{file_path}")
