# Unily MCP Server (lyra-unily)

Model Context Protocol server for the Unily intranet platform.

Provides Claude with tools to read and manage Unily content, media, social
interactions, notifications, and more via the Unily REST/GraphQL API.

Each user runs their own local instance with their own Unily OAuth2 client
credentials — there is no shared server.

## Installation

Requires Python 3.11+ and [uv](https://docs.astral.sh/uv/).

```bash
# uv handles the rest automatically via uvx
```

## Claude Desktop configuration

Add to `~/Library/Application Support/Claude/claude_desktop_config.json`
(macOS) or `%APPDATA%\Claude\claude_desktop_config.json` (Windows):

```json
{
  "mcpServers": {
    "lyra-unily": {
      "command": "uvx",
      "args": ["lyra-unily-mcp"],
      "env": {
        "UNILY_CLIENT_ID": "your-client-id",
        "UNILY_CLIENT_SECRET": "your-client-secret"
      }
    }
  }
}
```

Alternatively, if you prefer npx:

```json
{
  "mcpServers": {
    "lyra-unily": {
      "command": "npx",
      "args": ["lyra-unily-mcp"],
      "env": {
        "UNILY_CLIENT_ID": "your-client-id",
        "UNILY_CLIENT_SECRET": "your-client-secret"
      }
    }
  }
}
```

## Authentication

Uses OAuth2 Client Credentials (RFC 6749 §4.4).  Each user obtains their own
`client_id` and `client_secret` from the Unily admin portal and supplies them
via environment variables in their Claude Desktop config.

Required environment variables:
- `UNILY_CLIENT_ID` — your Unily OAuth2 client ID
- `UNILY_CLIENT_SECRET` — your Unily OAuth2 client secret

## Development

```bash
cd applications/unily-mcp-server
pip install -e ".[dev]"
UNILY_CLIENT_ID=... UNILY_CLIENT_SECRET=... python -m unily_mcp_server
```
