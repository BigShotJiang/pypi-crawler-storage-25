"""mcp-gateway: Security gateway for MCP server connections."""

__version__ = "0.1.0"
