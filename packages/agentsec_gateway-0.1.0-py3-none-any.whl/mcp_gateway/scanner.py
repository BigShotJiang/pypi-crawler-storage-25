"""MCP-specific security scanning.

Extends agentsec-core's pattern scanner with prompt injection,
path traversal, and command injection detection tailored to MCP tool calls.
"""

from __future__ import annotations

import re

from agentsec_core.scanner import Violation, scan_parameters as core_scan_parameters, scan_text

# ---------------------------------------------------------------------------
# MCP-specific threat patterns
# ---------------------------------------------------------------------------

PROMPT_INJECTION_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"ignore\s+(previous|all|above)\s+instructions", re.IGNORECASE),
    re.compile(r"you\s+are\s+now\s+in\s+(?:developer|admin|debug)\s+mode", re.IGNORECASE),
    re.compile(r"system\s*:\s*you\s+are", re.IGNORECASE),
    re.compile(r"<\s*(?:system|admin|root)\s*>", re.IGNORECASE),
]

PATH_TRAVERSAL_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"\.\./"),
    re.compile(r"/etc/(?:passwd|shadow|hosts)"),
    re.compile(r"~/.ssh/"),
    re.compile(r"/proc/self/"),
]

COMMAND_INJECTION_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r";\s*(?:rm|cat|curl|wget|nc|bash|sh|python)\s"),
    re.compile(r"\|\s*(?:sh|bash|python|perl|ruby)\b"),
    re.compile(r"\$\(.*\)"),
    re.compile(r"`.*`"),
]


def _check_patterns(
    text: str,
    patterns: list[re.Pattern[str]],
    rule_prefix: str,
    description: str,
    severity: str,
    source: str,
) -> list[Violation]:
    """Check text against a list of patterns, returning violations."""
    violations: list[Violation] = []
    for i, pattern in enumerate(patterns):
        match = pattern.search(text)
        if match:
            violations.append(Violation(
                source=source,
                line_number=0,
                severity=severity,
                rule_id=f"{rule_prefix}{i + 1:03d}",
                message=f"{description}: {match.group(0)[:80]}",
                match_text=match.group(0)[:120],
            ))
    return violations


def scan_tool_schema(schema: dict) -> list[str]:
    """Analyze an MCP tool schema for risky patterns.

    Returns list of warning strings describing potential risks.
    """
    warnings: list[str] = []
    name = schema.get("name", "")
    description = schema.get("description", "")

    dangerous_keywords = [
        "execute", "eval", "shell", "command", "sudo", "admin",
        "delete", "drop", "truncate", "rm -rf",
    ]
    for keyword in dangerous_keywords:
        if keyword in name.lower() or keyword in description.lower():
            warnings.append(f"Tool '{name}' contains dangerous keyword: {keyword}")

    input_schema = schema.get("inputSchema", {})
    properties = input_schema.get("properties", {})
    for prop_name, prop_def in properties.items():
        if prop_def.get("type") == "string" and not prop_def.get("maxLength"):
            warnings.append(f"Tool '{name}': param '{prop_name}' has no maxLength constraint")

    return warnings


def scan_tool_parameters(tool_name: str, params: dict) -> list[Violation]:
    """Scan tool parameters for secrets, PII, and injections.

    Combines core scanner (secrets/PII) with MCP-specific patterns
    (prompt injection, path traversal, command injection).
    """
    source = f"mcp:tool:{tool_name}"

    # Core secret/PII scanning
    violations = list(core_scan_parameters(params, source=source))

    # MCP-specific scanning on all string values
    text_values = _extract_strings(params)
    combined_text = "\n".join(text_values)

    violations.extend(_check_patterns(
        combined_text, PROMPT_INJECTION_PATTERNS,
        "INJ", "Prompt injection detected", "ERROR", source,
    ))
    violations.extend(_check_patterns(
        combined_text, PATH_TRAVERSAL_PATTERNS,
        "PTH", "Path traversal detected", "ERROR", source,
    ))
    violations.extend(_check_patterns(
        combined_text, COMMAND_INJECTION_PATTERNS,
        "CMD", "Command injection detected", "ERROR", source,
    ))

    return violations


def scan_response(response: dict) -> list[Violation]:
    """Scan MCP server response for data leakage.

    Checks response content fields for secrets and PII.
    """
    violations: list[Violation] = []
    result = response.get("result", {})
    if not isinstance(result, dict):
        return violations

    content = result.get("content", [])
    for item in content if isinstance(content, list) else []:
        if isinstance(item, dict):
            text = item.get("text", "")
            if text:
                violations.extend(scan_text(text, source="mcp:response"))

    return violations


def _extract_strings(data: dict | list | str, depth: int = 0) -> list[str]:
    """Recursively extract all string values from nested data."""
    if depth > 10:
        return []

    results: list[str] = []
    if isinstance(data, str):
        results.append(data)
    elif isinstance(data, dict):
        for value in data.values():
            results.extend(_extract_strings(value, depth + 1))
    elif isinstance(data, list):
        for item in data:
            results.extend(_extract_strings(item, depth + 1))
    return results
