"""Data flow monitoring for MCP connections.

Tracks per-server metrics: call counts, byte volumes, tool usage,
violation counts, and anomaly detection.
"""

from __future__ import annotations

import json
import logging
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass
class ServerMetrics:
    """Metrics for a single MCP server."""

    server_name: str
    total_calls: int = 0
    total_violations: int = 0
    bytes_inbound: int = 0
    bytes_outbound: int = 0
    tools_used: dict[str, int] = field(default_factory=dict)
    last_call: str | None = None  # ISO 8601 string for JSON serialization


class DataFlowMonitor:
    """Track data flow metrics per MCP server."""

    def __init__(self, metrics_path: str | Path = ".mcp-gateway/metrics.json") -> None:
        self._path = Path(metrics_path)
        self._servers: dict[str, ServerMetrics] = {}
        self.load()

    def record_call(
        self, server: str, tool: str, inbound_bytes: int, outbound_bytes: int
    ) -> None:
        """Record a tool call with byte counts."""
        metrics = self._get_or_create(server)
        metrics.total_calls += 1
        metrics.bytes_inbound += inbound_bytes
        metrics.bytes_outbound += outbound_bytes
        metrics.tools_used[tool] = metrics.tools_used.get(tool, 0) + 1
        metrics.last_call = datetime.now(timezone.utc).isoformat()

    def record_violation(self, server: str) -> None:
        """Record a security violation for a server."""
        metrics = self._get_or_create(server)
        metrics.total_violations += 1

    def get_stats(self, server: str | None = None) -> dict:
        """Get metrics as a dict, optionally filtered by server."""
        if server is not None:
            metrics = self._servers.get(server)
            if metrics is None:
                return {}
            return asdict(metrics)

        return {name: asdict(m) for name, m in self._servers.items()}

    def get_data_flow_report(self) -> str:
        """Human-readable data flow report."""
        if not self._servers:
            return "No data flow recorded."

        lines: list[str] = ["MCP Data Flow Report", "=" * 40]
        for name, metrics in sorted(self._servers.items()):
            lines.append(f"\n  Server: {name}")
            lines.append(f"    Total calls:      {metrics.total_calls}")
            lines.append(f"    Total violations: {metrics.total_violations}")
            lines.append(f"    Bytes inbound:    {metrics.bytes_inbound:,}")
            lines.append(f"    Bytes outbound:   {metrics.bytes_outbound:,}")
            lines.append(f"    Last call:        {metrics.last_call or 'never'}")
            if metrics.tools_used:
                lines.append("    Tools used:")
                for tool, count in sorted(
                    metrics.tools_used.items(), key=lambda x: x[1], reverse=True
                ):
                    lines.append(f"      {tool}: {count}")

        return "\n".join(lines)

    def detect_anomalies(self) -> list[str]:
        """Flag rate spikes or newly-seen tools."""
        anomalies: list[str] = []
        for name, metrics in self._servers.items():
            if metrics.total_violations > 0:
                violation_rate = metrics.total_violations / max(metrics.total_calls, 1)
                if violation_rate > 0.1:
                    anomalies.append(
                        f"{name}: high violation rate "
                        f"({metrics.total_violations}/{metrics.total_calls} = "
                        f"{violation_rate:.0%})"
                    )

            if metrics.bytes_outbound > 10_000_000:
                anomalies.append(
                    f"{name}: high outbound volume ({metrics.bytes_outbound:,} bytes)"
                )

        return anomalies

    def save(self) -> None:
        """Persist metrics to disk."""
        self._path.parent.mkdir(parents=True, exist_ok=True)
        data = {name: asdict(m) for name, m in self._servers.items()}
        self._path.write_text(
            json.dumps(data, indent=2), encoding="utf-8"
        )

    def load(self) -> None:
        """Load metrics from disk."""
        if not self._path.exists():
            return
        try:
            raw = json.loads(self._path.read_text(encoding="utf-8"))
            for name, data in raw.items():
                self._servers[name] = ServerMetrics(**data)
        except (json.JSONDecodeError, TypeError, KeyError) as exc:
            logger.warning("Failed to load metrics: %s", exc)

    def _get_or_create(self, server: str) -> ServerMetrics:
        """Get or create metrics for a server."""
        if server not in self._servers:
            self._servers[server] = ServerMetrics(server_name=server)
        return self._servers[server]
