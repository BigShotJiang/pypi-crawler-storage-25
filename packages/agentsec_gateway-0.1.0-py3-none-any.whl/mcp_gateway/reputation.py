"""MCP server reputation tracking.

Maintains a JSON-backed database of trust scores, violation history,
and anomaly counts per MCP server. Trust scores degrade on violations
and anomalies, providing a signal for policy decisions.
"""

from __future__ import annotations

import json
import logging
from dataclasses import asdict, dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ReputationEntry:
    """Reputation data for a single MCP server."""

    server_name: str
    source: str = "unknown"  # npm, github, local
    total_calls: int = 0
    total_violations: int = 0
    anomaly_count: int = 0
    trust_score: float = 100.0  # 0-100
    known_tools: list[str] = field(default_factory=list)
    flags: list[str] = field(default_factory=list)


class ReputationDB:
    """JSON-backed server reputation database."""

    def __init__(self, db_path: str | Path = ".mcp-gateway/reputation.json") -> None:
        self._path = Path(db_path)
        self._entries: dict[str, dict] = {}
        self.load()

    def get(self, server_name: str) -> ReputationEntry:
        """Get reputation for a server. Returns default entry if not found."""
        if server_name in self._entries:
            return ReputationEntry(**self._entries[server_name])
        return ReputationEntry(server_name=server_name)

    def update(self, server_name: str, **kwargs) -> ReputationEntry:
        """Update fields on a server's reputation entry.

        Recalculates trust_score after update.
        Returns the updated entry.
        """
        current = self._entries.get(
            server_name, asdict(ReputationEntry(server_name=server_name))
        )
        current.update(kwargs)
        current["server_name"] = server_name

        entry = ReputationEntry(**current)
        new_score = self.calculate_trust_score(entry)
        current["trust_score"] = new_score

        self._entries[server_name] = current
        return ReputationEntry(**current)

    def calculate_trust_score(self, entry: ReputationEntry) -> float:
        """Score = 100 - (violations * 10) - (anomalies * 5), clamped to [0, 100]."""
        score = 100.0 - (entry.total_violations * 10) - (entry.anomaly_count * 5)
        return max(0.0, min(100.0, score))

    def flag_suspicious(self, server_name: str, reason: str) -> None:
        """Flag a server with a reason string."""
        current = self._entries.get(
            server_name, asdict(ReputationEntry(server_name=server_name))
        )
        current["server_name"] = server_name
        flags = list(current.get("flags", []))
        if reason not in flags:
            flags.append(reason)
        current["flags"] = flags
        current["anomaly_count"] = current.get("anomaly_count", 0) + 1

        entry = ReputationEntry(**current)
        current["trust_score"] = self.calculate_trust_score(entry)
        self._entries[server_name] = current

    def get_report(self) -> str:
        """Human-readable reputation report."""
        if not self._entries:
            return "No server reputation data."

        lines: list[str] = ["MCP Server Reputation Report", "=" * 40]
        for name, data in sorted(self._entries.items()):
            entry = ReputationEntry(**data)
            status = "TRUSTED" if entry.trust_score >= 70 else "DEGRADED"
            if entry.trust_score < 30:
                status = "UNTRUSTED"

            lines.append(f"\n  {name} [{status}]")
            lines.append(f"    Trust score:  {entry.trust_score:.0f}/100")
            lines.append(f"    Source:       {entry.source}")
            lines.append(f"    Calls:        {entry.total_calls}")
            lines.append(f"    Violations:   {entry.total_violations}")
            lines.append(f"    Anomalies:    {entry.anomaly_count}")
            if entry.flags:
                lines.append(f"    Flags:        {', '.join(entry.flags)}")
            if entry.known_tools:
                lines.append(f"    Known tools:  {len(entry.known_tools)}")

        return "\n".join(lines)

    def save(self) -> None:
        """Persist reputation database to disk."""
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._path.write_text(
            json.dumps(self._entries, indent=2), encoding="utf-8"
        )

    def load(self) -> None:
        """Load reputation database from disk."""
        if not self._path.exists():
            return
        try:
            self._entries = json.loads(self._path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, TypeError) as exc:
            logger.warning("Failed to load reputation DB: %s", exc)
            self._entries = {}
