"""Auto-installer that patches .mcp.json to route through MCP gateway.

Wraps each server's command so all MCP traffic flows through the
security proxy. Creates a backup before modifying.
"""

from __future__ import annotations

import json
import logging
import shutil
from pathlib import Path

logger = logging.getLogger(__name__)

_GATEWAY_COMMAND = "mcp-gateway"
_MARKER_KEY = "_original_command"


def install(mcp_json_path: str | Path = ".mcp.json") -> dict[str, str]:
    """Patch .mcp.json to route all servers through the gateway.

    For each server, wraps the original command:
    Original: {"command": "npx", "args": ["-y", "@org/mcp-server"]}
    Patched:  {"command": "mcp-gateway",
               "args": ["proxy", "--server", "name", "--", "npx", "-y", "@org/mcp-server"],
               "_original_command": "npx",
               "_original_args": ["-y", "@org/mcp-server"]}

    Creates .mcp.json.bak backup before modifying.
    Returns dict of {server_name: "installed"} for each patched server.
    """
    path = Path(mcp_json_path)
    if not path.exists():
        raise FileNotFoundError(f"MCP config not found: {path}")

    config = json.loads(path.read_text(encoding="utf-8"))
    servers = config.get("mcpServers", {})

    if not servers:
        return {}

    # Create backup
    backup_path = Path(f"{path}.bak")
    shutil.copy2(path, backup_path)
    logger.info("Backup created: %s", backup_path)

    results: dict[str, str] = {}
    for name, server_cfg in servers.items():
        if _is_server_patched(server_cfg):
            results[name] = "already_installed"
            continue

        original_command = server_cfg.get("command", "")
        original_args = server_cfg.get("args", [])

        server_cfg[_MARKER_KEY] = original_command
        server_cfg["_original_args"] = list(original_args)

        gateway_args = ["proxy", "--server", name, "--"]
        if original_command:
            gateway_args.append(original_command)
        gateway_args.extend(original_args)

        server_cfg["command"] = _GATEWAY_COMMAND
        server_cfg["args"] = gateway_args

        results[name] = "installed"

    path.write_text(json.dumps(config, indent=2), encoding="utf-8")
    return results


def uninstall(mcp_json_path: str | Path = ".mcp.json") -> dict[str, str]:
    """Restore .mcp.json from _original_command fields or .bak file.

    Returns dict of {server_name: "restored"}.
    """
    path = Path(mcp_json_path)
    if not path.exists():
        raise FileNotFoundError(f"MCP config not found: {path}")

    config = json.loads(path.read_text(encoding="utf-8"))
    servers = config.get("mcpServers", {})

    results: dict[str, str] = {}
    restored_any = False

    for name, server_cfg in servers.items():
        if not _is_server_patched(server_cfg):
            results[name] = "not_patched"
            continue

        server_cfg["command"] = server_cfg.pop(_MARKER_KEY)
        server_cfg["args"] = server_cfg.pop("_original_args", [])

        results[name] = "restored"
        restored_any = True

    if restored_any:
        path.write_text(json.dumps(config, indent=2), encoding="utf-8")
    else:
        # Fall back to backup
        backup_path = Path(f"{path}.bak")
        if backup_path.exists():
            shutil.copy2(backup_path, path)
            results["_backup"] = "restored_from_backup"

    return results


def is_installed(mcp_json_path: str | Path = ".mcp.json") -> bool:
    """Check if gateway is already installed in any server."""
    path = Path(mcp_json_path)
    if not path.exists():
        return False

    try:
        config = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return False

    servers = config.get("mcpServers", {})
    return any(_is_server_patched(cfg) for cfg in servers.values())


def get_server_list(mcp_json_path: str | Path = ".mcp.json") -> list[dict[str, str]]:
    """List all servers with their install status.

    Returns list of dicts with keys: name, command, patched.
    """
    path = Path(mcp_json_path)
    if not path.exists():
        return []

    try:
        config = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return []

    servers = config.get("mcpServers", {})
    result: list[dict[str, str]] = []
    for name, cfg in servers.items():
        patched = _is_server_patched(cfg)
        original_cmd = cfg.get(_MARKER_KEY, cfg.get("command", "")) if patched else ""
        result.append({
            "name": name,
            "command": cfg.get(_MARKER_KEY, cfg.get("command", "")),
            "patched": "yes" if patched else "no",
        })

    return result


def _is_server_patched(server_cfg: dict) -> bool:
    """Check if a server config has been patched by the gateway."""
    return _MARKER_KEY in server_cfg
