"""MCP stdio proxy with security scanning.

Sits between Claude Code and an MCP server, intercepting JSON-RPC messages.
Scans tool calls against security policies and logs all traffic.
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
import sys
import threading
from pathlib import Path
from typing import IO

from agentsec_core.logger import AuditLogger
from agentsec_core.scanner import scan_parameters
from agentsec_core.schemas import AuditEvent, PolicyAction

logger = logging.getLogger(__name__)

_ALLOWED_EXECUTABLES = frozenset({
    "npx", "node", "python3", "python", "uvx", "deno", "bun", "docker",
})


def _validate_command(command: list[str]) -> None:
    """Validate server command executable against allowlist."""
    if not command:
        raise ValueError("Empty server command")
    exe = Path(command[0]).name
    if exe not in _ALLOWED_EXECUTABLES:
        raise ValueError(f"Disallowed executable in server command: {exe!r}")


class MCPProxy:
    """Transparent stdio proxy for MCP servers.

    Intercepts JSON-RPC messages flowing between Claude and the MCP server.
    Scans tool call parameters for secrets/PII.
    Logs all traffic to audit trail.

    Architecture:
        Claude stdout -> [proxy stdin] -> scan -> [server stdin]
        Claude stdin  <- [proxy stdout] <- scan <- [server stdout]
    """

    def __init__(
        self,
        server_command: list[str],
        server_env: dict[str, str] | None = None,
        policy_path: str | Path | None = None,
        log_path: str | Path = ".mcp-gateway/audit.jsonl",
        server_name: str = "unknown",
    ) -> None:
        _validate_command(server_command)
        self._server_command = server_command
        self._server_env = server_env
        self._log_path = Path(log_path)
        self._log_path.parent.mkdir(parents=True, exist_ok=True)
        self._audit = AuditLogger(self._log_path)
        self._server_name = server_name
        self._policy_path = policy_path
        self._lock = threading.Lock()
        self._stats = {"inbound": 0, "outbound": 0, "blocked": 0}

    def run(self) -> int:
        """Start the proxy. Blocks until the server process exits.

        Returns the server's exit code.
        """
        env = os.environ.copy()
        if self._server_env:
            env.update(self._server_env)

        proc = subprocess.Popen(
            self._server_command,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=env,
        )

        inbound_thread = threading.Thread(
            target=self._forward_inbound,
            args=(sys.stdin.buffer, proc.stdin),
            daemon=True,
        )

        outbound_thread = threading.Thread(
            target=self._forward_outbound,
            args=(proc.stdout, sys.stdout.buffer),
            daemon=True,
        )

        stderr_thread = threading.Thread(
            target=self._forward_stderr,
            args=(proc.stderr,),
            daemon=True,
        )

        inbound_thread.start()
        outbound_thread.start()
        stderr_thread.start()

        return proc.wait()

    def _forward_inbound(self, source: IO[bytes], dest: IO[bytes]) -> None:
        """Read from Claude, scan, forward to server. Drops blocked messages."""
        try:
            for line in source:
                with self._lock:
                    self._stats["inbound"] += 1
                decoded = line.decode("utf-8", errors="replace").strip()

                if decoded and self._scan_inbound(decoded):
                    continue  # Message blocked by policy — do not forward

                dest.write(line)
                dest.flush()
        except (BrokenPipeError, OSError):
            pass
        finally:
            try:
                dest.close()
            except OSError:
                pass

    def _forward_outbound(self, source: IO[bytes], dest: IO[bytes]) -> None:
        """Read from server, scan, forward to Claude."""
        try:
            for line in source:
                with self._lock:
                    self._stats["outbound"] += 1
                decoded = line.decode("utf-8", errors="replace").strip()

                if decoded:
                    self._scan_outbound(decoded)

                dest.write(line)
                dest.flush()
        except (BrokenPipeError, OSError):
            pass

    def _forward_stderr(self, source: IO[bytes]) -> None:
        """Forward server stderr to proxy stderr."""
        try:
            for line in source:
                sys.stderr.buffer.write(line)
                sys.stderr.buffer.flush()
        except (BrokenPipeError, OSError):
            pass

    def _scan_inbound(self, line: str) -> bool:
        """Scan an inbound JSON-RPC message for security issues.

        Returns True if the message should be blocked (not forwarded).
        """
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            return False

        method = msg.get("method", "")
        params = msg.get("params", {})

        if method not in ("tools/call", "tools/execute"):
            return False

        tool_name = params.get("name", "")
        tool_args = params.get("arguments", {})

        violations = scan_parameters(
            tool_args, source=f"mcp:{self._server_name}:{tool_name}"
        )

        action = PolicyAction.DENY if violations else PolicyAction.ALLOW
        event = AuditEvent(
            event_type="mcp_tool_call",
            tool_name=f"{self._server_name}/{tool_name}",
            action_taken=action,
            violations=[],
            parameters={"method": method, "tool": tool_name},
            metadata={
                "server": self._server_name,
                "direction": "inbound",
                "violation_count": len(violations),
            },
        )
        self._audit.log(event)

        if violations:
            with self._lock:
                self._stats["blocked"] += 1
            logger.warning(
                "BLOCKED %s/%s: %d violations detected",
                self._server_name, tool_name, len(violations),
            )
            return True

        return False

    def _scan_outbound(self, line: str) -> None:
        """Scan an outbound response for data leakage."""
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            return

        result = msg.get("result", {})
        if not isinstance(result, dict):
            return

        content = result.get("content", [])
        for item in content if isinstance(content, list) else []:
            text = item.get("text", "") if isinstance(item, dict) else ""
            if text:
                violations = scan_parameters(
                    {"text": text},
                    source=f"mcp:{self._server_name}:response",
                )
                if violations:
                    logger.warning(
                        "Data leakage in %s response: %d issues",
                        self._server_name,
                        len(violations),
                    )

    @property
    def stats(self) -> dict[str, int]:
        """Return current proxy statistics."""
        return dict(self._stats)
