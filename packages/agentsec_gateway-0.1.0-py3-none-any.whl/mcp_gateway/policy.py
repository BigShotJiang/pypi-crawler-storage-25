"""Per-server MCP security policies.

Defines per-server tool allow/block lists, rate limits, and data classification.
Loaded from a YAML configuration file.
"""

from __future__ import annotations

import fnmatch
import logging
from dataclasses import dataclass, field
from pathlib import Path

import yaml

logger = logging.getLogger(__name__)

_DEFAULT_CONFIG_TEMPLATE = """\
# MCP Gateway security policy
# Each server gets its own policy controlling which tools are allowed.
servers:
  # Example: restrict file system server
  # filesystem:
  #   allowed_tools: ["read_*", "list_*", "search_*"]
  #   blocked_tools: ["write_*", "delete_*"]
  #   max_calls_per_minute: 30
  #   data_classification: internal

  # Example: restrict Gmail
  # gmail:
  #   allowed_tools: ["gmail_search*", "gmail_read*", "gmail_list*"]
  #   blocked_tools: ["gmail_create_draft", "gmail_send*"]
  #   max_calls_per_minute: 10
  #   data_classification: confidential
"""


@dataclass(frozen=True)
class ServerPolicy:
    """Security policy for a single MCP server."""

    server_name: str
    allowed_tools: list[str] = field(default_factory=list)
    blocked_tools: list[str] = field(default_factory=list)
    max_calls_per_minute: int = 60
    data_classification: str = "internal"  # public, internal, confidential

    def is_tool_allowed(self, tool_name: str) -> bool:
        """Check if a tool is allowed by this policy.

        Logic:
        1. If blocked_tools match, deny.
        2. If allowed_tools is empty, allow all (not blocked).
        3. If allowed_tools is set, tool must match at least one pattern.
        """
        for pattern in self.blocked_tools:
            if fnmatch.fnmatch(tool_name, pattern):
                return False

        if not self.allowed_tools:
            return True

        return any(fnmatch.fnmatch(tool_name, p) for p in self.allowed_tools)


def load_gateway_config(path: str | Path) -> dict[str, ServerPolicy]:
    """Load per-server policies from YAML config.

    Returns a dict mapping server_name -> ServerPolicy.

    Raises:
        FileNotFoundError: If config file doesn't exist.
        ValueError: If YAML is malformed.
    """
    config_path = Path(path)
    if not config_path.exists():
        raise FileNotFoundError(f"Gateway config not found: {config_path}")

    raw = config_path.read_text(encoding="utf-8")
    try:
        data = yaml.safe_load(raw)
    except yaml.YAMLError as exc:
        raise ValueError(f"Invalid YAML in gateway config: {exc}") from exc

    if not isinstance(data, dict):
        raise ValueError("Gateway config must be a YAML mapping")

    servers_data = data.get("servers", {})
    if not isinstance(servers_data, dict):
        raise ValueError("'servers' must be a mapping")

    policies: dict[str, ServerPolicy] = {}
    for name, cfg in servers_data.items():
        if not isinstance(cfg, dict):
            logger.warning("Skipping non-dict server config: %s", name)
            continue
        policies[name] = ServerPolicy(
            server_name=name,
            allowed_tools=cfg.get("allowed_tools", []),
            blocked_tools=cfg.get("blocked_tools", []),
            max_calls_per_minute=cfg.get("max_calls_per_minute", 60),
            data_classification=cfg.get("data_classification", "internal"),
        )

    return policies


def create_default_config(path: str | Path) -> None:
    """Create a default gateway config file with commented examples."""
    config_path = Path(path)
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(_DEFAULT_CONFIG_TEMPLATE, encoding="utf-8")
    logger.info("Created default gateway config: %s", config_path)
