"""Allow running as `python -m mcp_gateway`."""

from .cli import main

main()
