"""Click-based CLI for MCP Security Gateway.

Commands:
    install   - Patch .mcp.json to route through gateway
    uninstall - Restore original .mcp.json
    proxy     - Run as stdio proxy (called by patched .mcp.json)
    scan      - Analyze configured MCP servers
    audit     - View audit log
    report    - Generate security report
    status    - Show install status and server list
"""

from __future__ import annotations

import json
import logging
import sys
from pathlib import Path

import click

from . import __version__

logger = logging.getLogger(__name__)


@click.group()
@click.version_option(version=__version__, prog_name="mcp-gateway")
@click.option("--verbose", "-v", is_flag=True, help="Enable debug logging.")
def main(verbose: bool) -> None:
    """MCP Security Gateway -- scan and audit MCP server connections."""
    level = logging.DEBUG if verbose else logging.WARNING
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        stream=sys.stderr,
    )


@main.command()
@click.option("--config", default=".mcp.json", help="Path to .mcp.json")
def install(config: str) -> None:
    """Patch .mcp.json to route all servers through the gateway."""
    from .installer import install as do_install

    try:
        results = do_install(config)
        for name, status in results.items():
            click.echo(f"  {name}: {status}")
        if results:
            click.echo("\nGateway installed. MCP traffic will now be scanned.")
        else:
            click.echo("No servers found in config.")
    except FileNotFoundError as exc:
        click.echo(f"Error: {exc}", err=True)
        raise SystemExit(1) from exc


@main.command()
@click.option("--config", default=".mcp.json", help="Path to .mcp.json")
def uninstall(config: str) -> None:
    """Restore .mcp.json to original (unpatched) state."""
    from .installer import uninstall as do_uninstall

    try:
        results = do_uninstall(config)
        for name, status in results.items():
            click.echo(f"  {name}: {status}")
        click.echo("\nGateway uninstalled.")
    except FileNotFoundError as exc:
        click.echo(f"Error: {exc}", err=True)
        raise SystemExit(1) from exc


@main.command()
@click.option("--server", required=True, help="Server name for logging.")
@click.option("--log-path", default=".mcp-gateway/audit.jsonl", help="Audit log path.")
@click.argument("command", nargs=-1, required=True)
def proxy(server: str, log_path: str, command: tuple[str, ...]) -> None:
    """Run as a stdio proxy for an MCP server.

    This is called automatically by the patched .mcp.json.
    Everything after '--' is the original server command.
    """
    from .proxy import MCPProxy

    mcp_proxy = MCPProxy(
        server_command=list(command),
        server_name=server,
        log_path=log_path,
    )
    exit_code = mcp_proxy.run()
    raise SystemExit(exit_code)


@main.command()
@click.option("--config", default=".mcp.json", help="Path to .mcp.json")
def scan(config: str) -> None:
    """Analyze all configured MCP servers and their tool schemas."""
    from .installer import get_server_list

    servers = get_server_list(config)
    if not servers:
        click.echo("No servers found in config.")
        return

    click.echo(f"Found {len(servers)} MCP server(s):\n")
    for srv in servers:
        status = "PROXIED" if srv["patched"] == "yes" else "DIRECT"
        click.echo(f"  [{status}] {srv['name']}")
        click.echo(f"           command: {srv['command']}")


@main.command()
@click.option("--tail", "-n", default=20, help="Number of recent events to show.")
@click.option("--server", default=None, help="Filter by server name.")
@click.option("--log-path", default=".mcp-gateway/audit.jsonl", help="Audit log path.")
def audit(tail: int, server: str | None, log_path: str) -> None:
    """View the audit log."""
    from agentsec_core.logger import AuditLogger

    audit_path = Path(log_path)
    if not audit_path.exists():
        click.echo("No audit log found. Run some MCP commands first.")
        return

    audit_logger = AuditLogger(audit_path)
    events = audit_logger.tail(tail)

    if server:
        events = [e for e in events if server in (e.tool_name or "")]

    if not events:
        click.echo("No matching events.")
        return

    for event in events:
        ts = event.timestamp.strftime("%Y-%m-%d %H:%M:%S") if event.timestamp else "?"
        action = event.action_taken.value
        violations = event.metadata.get("violation_count", 0)
        icon = "!!" if violations > 0 else "ok"
        click.echo(f"  [{ts}] [{icon}] {event.tool_name} -> {action}")


@main.command()
def report() -> None:
    """Generate a combined security report (reputation + data flow)."""
    from .monitor import DataFlowMonitor
    from .reputation import ReputationDB

    rep_db = ReputationDB()
    monitor = DataFlowMonitor()

    click.echo(rep_db.get_report())
    click.echo()
    click.echo(monitor.get_data_flow_report())

    anomalies = monitor.detect_anomalies()
    if anomalies:
        click.echo("\nAnomalies Detected:")
        for a in anomalies:
            click.echo(f"  !! {a}")


@main.command()
@click.option("--config", default=".mcp.json", help="Path to .mcp.json")
def status(config: str) -> None:
    """Show installed status and server list."""
    from .installer import get_server_list, is_installed

    installed = is_installed(config)
    click.echo(f"Gateway installed: {'yes' if installed else 'no'}")

    servers = get_server_list(config)
    if servers:
        click.echo(f"Servers ({len(servers)}):")
        for srv in servers:
            status_str = "PROXIED" if srv["patched"] == "yes" else "DIRECT"
            click.echo(f"  [{status_str}] {srv['name']} ({srv['command']})")
    else:
        click.echo("No servers configured.")
