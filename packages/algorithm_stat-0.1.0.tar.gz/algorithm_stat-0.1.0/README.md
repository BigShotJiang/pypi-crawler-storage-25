# algo-stat

> **Quant analysis in 3 lines.** A self-contained Python toolkit for
> market data, metrics, charts, Monte Carlo, backtesting, ML, macro,
> options, mortgage, and Alpaca paper trading.

```
algo-stat = library  +  CLI  +  REST API  +  Streamlit dashboard
```

---

## Install (local laptop)

```bash
cd algo-stat
python -m venv .venv && source .venv/bin/activate
pip install -e ".[all,test,dev]"        # all = trading + ml-deep
cp .env.example .env                    # add FRED_API_KEY (free, optional)
```

> **API keys?** `yfinance` needs **none**. FRED needs a free key (signup:
> https://fred.stlouisfed.org/docs/api/api_key.html). Alpaca only if you
> want paper trading.

## 3-line analyses (Jupyter / Python REPL)

```python
import algo_stat as a; a.use_dark()
a.report(a.fetch("NVDA", period="1y"), ticker="NVDA")
```

```python
import algo_stat as a
a.compare(["AAPL","MSFT","NVDA","GOOGL"], period="2y").show()
```

```python
import algo_stat as a
a.MonteCarlo("NVDA").simulate(n=1000, days=252).plot()
```

```python
import algo_stat as a
bt = a.Backtester("NVDA", period="2y").run(a.SMACrossover(20, 50))
print(bt.stats); bt.plot()
```

More examples in [notebooks/quickstart.py](notebooks/quickstart.py).

## CLI

```bash
algo-stat quote NVDA
algo-stat analyze NVDA --period 1y --chart
algo-stat compare AAPL,MSFT,NVDA,GOOGL --period 2y --chart
algo-stat montecarlo NVDA --n 1000 --days 252 --chart
algo-stat backtest NVDA --fast 20 --slow 50 --chart
algo-stat mortgage 300000 60000 0.055 --years 25
algo-stat macro cpi --years 10
algo-stat serve            # FastAPI on :8000
algo-stat dashboard        # Streamlit on :8501
```

## REST API

```bash
algo-stat serve
# → open http://127.0.0.1:8000/docs   (Swagger UI)
```

Endpoints:

| Method | Path                     | Purpose                   |
| ------ | ------------------------ | ------------------------- |
| GET    | `/health`                | health check              |
| GET    | `/quote/{ticker}`        | fundamental snapshot      |
| GET    | `/prices/{ticker}`       | OHLCV tail                |
| GET    | `/performance/{ticker}`  | CAGR / Sharpe / VaR / MDD |
| GET    | `/compare?tickers=...`   | normalized growth         |
| POST   | `/montecarlo`            | GBM simulation summary    |
| POST   | `/backtest/sma`          | SMA crossover stats       |
| POST   | `/mortgage`              | mortgage summary          |
| GET    | `/macro/{series}`        | FRED series               |
| POST   | `/options/black-scholes` | option pricing            |

## Streamlit dashboard

```bash
algo-stat dashboard
```

7 tabs: Performance · Compare · Monte Carlo · Backtest · Mortgage · Macro · Options.

## Package layout

```
algo_stat/
  data/         market.py · macro.py · universe.py
  metrics/      returns.py · performance.py · risk.py
  charts/       theme.py · price.py · compare.py · correlation.py · fundamentals.py
  derivatives/  montecarlo.py · options.py
  backtest/     engine.py · strategies.py
  ml/           pca.py · regression.py · classifier.py
  property/     mortgage.py
  trading/      alpaca_client.py
  cli.py        api.py        dashboard.py     report.py     config.py
```

## Tests

```bash
pytest -q
```

## Credits

© Hemant Thapa — MIT license.
