# © Squid Consultancy Group Ltd — All rights reserved.
# Unauthorised removal or modification of this notice is prohibited.
from __future__ import annotations
from typing import Sequence
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import numpy as np

from algo_stat.charts.theme import stamp_figure, _style_axes, BG, PANEL_BG, BORDER, GREEN, RED, GOLD


def balance_sheet_chart(years: Sequence, assets: Sequence[float],
                        liabilities: Sequence[float], title: str = "Balance Sheet"):
    """Dual-axis bar (assets/liabilities) + line (net equity)."""
    years = list(years); assets = list(assets); liabilities = list(liabilities)
    equity = [a - l for a, l in zip(assets, liabilities)]
    x = np.arange(len(years)); w = 0.35

    fig, ax1 = plt.subplots(figsize=(13, 7))
    fig.patch.set_facecolor(BG)
    _style_axes(ax1)

    # gradient-tinted bars
    bars_a = ax1.bar(x - w / 2, assets,      w, color="#4D96FF", alpha=0.88,
                     label="Assets", zorder=3)
    bars_l = ax1.bar(x + w / 2, liabilities, w, color=RED,       alpha=0.88,
                     label="Liabilities", zorder=3)

    # value labels on bars
    for bar in list(bars_a) + list(bars_l):
        h = bar.get_height()
        ax1.text(bar.get_x() + bar.get_width() / 2, h + max(assets) * 0.01,
                 f"{h:,.0f}", ha="center", va="bottom",
                 color="white", fontsize=8, fontweight="bold")

    ax1.set_xticks(x)
    ax1.set_xticklabels(years, color="#8B949E")
    ax1.set_ylabel("Amount", color="#8B949E", fontsize=11, labelpad=10)
    ax1.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v, _: f"{v:,.0f}"))

    # equity line on twin axis
    ax2 = ax1.twinx()
    ax2.set_facecolor(BG)
    ax2.tick_params(colors="#6E7681", labelsize=9, length=0)
    for spine in ax2.spines.values():
        spine.set_visible(False)

    # glow equity line
    for lw, al in [(10, 0.05), (4, 0.15), (2, 1.0)]:
        ax2.plot(x, equity, color=GOLD, linewidth=lw, alpha=al,
                 solid_capstyle="round", solid_joinstyle="round", zorder=4)
    ax2.scatter(x, equity, color=GOLD, s=60, zorder=5)
    ax2.set_ylabel("Equity", color=GOLD, fontsize=11, labelpad=10)
    ax2.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v, _: f"{v:,.0f}"))

    # combined legend
    h1, l1 = ax1.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    leg = ax1.legend(h1 + h2, l1 + l2 + ["Equity"],
                     loc="upper left", fontsize=10,
                     facecolor=PANEL_BG, edgecolor=BORDER, framealpha=0.9)
    for txt in leg.get_texts():
        txt.set_color("white")

    ax1.set_title(title, color="white", fontsize=16, fontweight="bold", pad=14)
    fig.tight_layout()
    stamp_figure(fig)
    plt.close(fig)
    return fig
