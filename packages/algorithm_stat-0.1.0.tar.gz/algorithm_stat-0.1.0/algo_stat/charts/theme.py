from __future__ import annotations
import matplotlib.pyplot as plt

_LICENSE = "© Squid Consultancy Group Ltd"

# ── shared vibrant palette (use across all chart modules) ─────────────────────
BG          = "#0D1117"       # canvas
GRID        = "#30363D"       # gridlines (very light)
GRID_ALPHA  = 0.25            # grid opacity — ≤0.3 everywhere
GRID_STYLE  = "--"            # dashed gridlines everywhere
CYAN        = "#00F5FF"       # primary line / highlight
GREEN       = "#39FF14"       # positive / profit
RED         = "#FF3864"       # negative / loss
GOLD        = "#FFD600"       # secondary accent
PURPLE      = "#BF5AF2"       # tertiary accent
ORANGE      = "#FF6B35"       # quaternary accent
BLUE        = "#4D96FF"       # quinary accent
TICK_FG     = "#6E7681"       # axis tick labels
LABEL_FG    = "#8B949E"       # axis labels
PANEL_BG    = "#161B22"       # inner panels / legend boxes
BORDER      = "#30363D"       # panel borders

NEON_SERIES = [CYAN, GREEN, GOLD, PURPLE, ORANGE, BLUE,
               "#FF3864", "#00FF88", "#FF9500", "#A8DAFF"]


def stamp_figure(fig) -> None:
    """Add the Squid Consultancy Group Ltd licence watermark to a figure."""
    fig.text(
        0.99, 0.01, _LICENSE,
        ha="right", va="bottom",
        fontsize=7, alpha=0.50,
        transform=fig.transFigure,
    )


def _style_axes(*axes) -> None:
    """Apply consistent dark styling to one or more Axes objects."""
    for ax in axes:
        ax.set_facecolor(BG)
        for spine in ax.spines.values():
            spine.set_visible(False)
        ax.tick_params(colors=TICK_FG, labelsize=9, length=0)
        ax.grid(True, color=GRID, linewidth=0.4, linestyle=GRID_STYLE, alpha=GRID_ALPHA)


def use_dark() -> None:
    """Apply the algo-stat dark theme."""
    plt.style.use("dark_background")
    plt.rcParams.update({
        "figure.figsize":    (14, 7),
        "figure.dpi":        110,
        "figure.facecolor":  BG,
        "axes.facecolor":    BG,
        "axes.grid":         True,
        "grid.color":        GRID,
        "grid.alpha":        GRID_ALPHA,
        "grid.linewidth":    0.4,
        "grid.linestyle":    GRID_STYLE,
        "axes.titlesize":    15,
        "axes.titlecolor":   "white",
        "axes.labelsize":    11,
        "axes.labelcolor":   LABEL_FG,
        "axes.edgecolor":    BORDER,
        "lines.linewidth":   1.8,
        "axes.spines.top":   False,
        "axes.spines.right": False,
        "xtick.color":       TICK_FG,
        "ytick.color":       TICK_FG,
        "legend.facecolor":  PANEL_BG,
        "legend.edgecolor":  BORDER,
        "legend.labelcolor": "white",
    })
