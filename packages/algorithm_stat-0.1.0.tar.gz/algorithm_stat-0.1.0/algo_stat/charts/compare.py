# © Squid Consultancy Group Ltd — All rights reserved.
# Unauthorised removal or modification of this notice is prohibited.
from __future__ import annotations
from typing import Iterable
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import matplotlib.ticker as mticker
import numpy as np
import pandas as pd

from algo_stat.data.market import fetch_many
from algo_stat.charts.theme import stamp_figure, _style_axes, NEON_SERIES, BG, PANEL_BG, BORDER


def normalized_growth(prices: pd.DataFrame) -> pd.DataFrame:
    """Rebase every column to 100 at first observation."""
    return prices.divide(prices.iloc[0]).multiply(100)


class _Comparison:
    def __init__(self, prices: pd.DataFrame, period: str):
        self.prices = prices
        self.period = period
        self.normalized = normalized_growth(prices)

    def show(self, title: str | None = None):
        norm = self.normalized
        tickers = list(norm.columns)
        n = len(tickers)

        fig = plt.figure(figsize=(15, 8), facecolor=BG)
        gs  = gridspec.GridSpec(2, 1, figure=fig, height_ratios=[3, 1],
                                hspace=0.06, left=0.07, right=0.97,
                                top=0.91, bottom=0.09)
        ax  = fig.add_subplot(gs[0])
        ax2 = fig.add_subplot(gs[1], sharex=ax)
        _style_axes(ax, ax2)

        for i, col in enumerate(tickers):
            color = NEON_SERIES[i % len(NEON_SERIES)]
            y = norm[col].values
            # glow passes
            for lw, al in [(10, 0.03), (4, 0.10), (1.8, 1.0)]:
                ax.plot(norm.index, y, color=color, linewidth=lw, alpha=al,
                        solid_capstyle="round")
            # fill under
            ax.fill_between(norm.index, y, 100,
                             where=(y >= 100), color=color, alpha=0.06, linewidth=0)
            # final value badge
            last = float(norm[col].iloc[-1])
            pct = last - 100
            badge = f"{col}  {pct:+.1f}%"
            ax.annotate(badge, xy=(norm.index[-1], last),
                        xytext=(6, 0), textcoords="offset points",
                        color=color, fontsize=9, fontweight="bold", va="center",
                        bbox=dict(boxstyle="round,pad=0.3", facecolor=PANEL_BG,
                                  edgecolor=color, linewidth=1, alpha=0.90))

        ax.axhline(100, color="#30363D", linewidth=1.2, linestyle="--", alpha=0.7)
        ax.set_ylabel("Indexed (base = 100)", color="#8B949E", fontsize=11, labelpad=10)
        plt.setp(ax.get_xticklabels(), visible=False)

        # drawdown panel
        for i, col in enumerate(tickers):
            color = NEON_SERIES[i % len(NEON_SERIES)]
            dd = (norm[col] / norm[col].cummax() - 1) * 100
            ax2.fill_between(norm.index, dd.values, 0, color=color, alpha=0.25, linewidth=0)
            ax2.plot(norm.index, dd.values, color=color, linewidth=0.9, alpha=0.8)

        ax2.set_ylabel("Drawdown %", color="#8B949E", fontsize=9, labelpad=8)
        ax2.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{x:+.0f}%"))
        ax2.set_xlabel("Date", color="#8B949E", fontsize=10, labelpad=8)

        fig.suptitle(
            title or f"Normalized Growth  ·  {self.period}  ·  {', '.join(tickers)}",
            color="white", fontsize=16, fontweight="bold", x=0.52, y=0.97,
        )
        fig.autofmt_xdate(rotation=30, ha="right")
        stamp_figure(fig)
        plt.close(fig)
        return fig

    def correlation(self):
        from algo_stat.charts.correlation import correlation_heatmap
        return correlation_heatmap(self.prices.pct_change().dropna())

    # ---- DataFrame accessors so Comparison plays nicely with `a.explore()` ----
    @property
    def data(self) -> pd.DataFrame:
        """Normalised (base=100) wide DataFrame — alias for ``self.normalized``."""
        return self.normalized

    @property
    def df(self) -> pd.DataFrame:
        """Raw price wide DataFrame — alias for ``self.prices``."""
        return self.prices

    def returns(self) -> pd.DataFrame:
        """Daily simple returns per ticker (NaNs dropped)."""
        return self.prices.pct_change().dropna()

    def __repr__(self) -> str:
        return f"<Comparison tickers={list(self.prices.columns)} period={self.period}>"


def compare(tickers: Iterable[str], period: str = "1y", field: str = "Close") -> _Comparison:
    """One-liner multi-ticker comparison.

    >>> compare(["AAPL","MSFT","NVDA"], period="2y").show()
    """
    prices = fetch_many(tickers, period=period, field=field)
    return _Comparison(prices, period)
