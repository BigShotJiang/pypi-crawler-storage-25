# © Squid Consultancy Group Ltd — All rights reserved.
# Unauthorised removal or modification of this notice is prohibited.
"""Animated charts (FuncAnimation) for backtests, Monte-Carlo sims, and prices.

Returns a tiny wrapper around `matplotlib.animation.FuncAnimation` that
auto-renders an interactive JS-HTML player (play/pause/scrubber) in
Jupyter — the same "openable" UX as the Studio / Explorer widgets.

    >>> ani = a.animate_backtest(bt)        # plays inline
    >>> ani.save_gif("backtest.gif")        # write to disk
    >>> ani.save("backtest.mp4")            # any matplotlib writer
"""
from __future__ import annotations
from typing import Optional
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.animation as manim

from algo_stat.charts.theme import (
    stamp_figure, _style_axes, BG, PANEL_BG, BORDER,
    CYAN, GREEN, RED, GOLD, NEON_SERIES,
)
from algo_stat.metrics.returns import _close


# ── wrapper so the cell auto-displays a JS player ────────────────────────────
class _Anim:
    """Thin wrapper around FuncAnimation with notebook auto-display + .save_gif()."""
    def __init__(self, ani: manim.FuncAnimation, fig):
        self._ani = ani
        self._fig = fig

    # Jupyter rich repr — interactive JS player (play/pause/scrub/loop)
    def _repr_html_(self) -> str:
        try:
            return self._ani.to_jshtml(default_mode="loop")
        except Exception as e:
            return f"<pre>animation render failed: {e}</pre>"

    def save_gif(self, path: str, fps: int = 25, dpi: int = 110) -> str:
        self._ani.save(path, writer=manim.PillowWriter(fps=fps), dpi=dpi)
        return path

    def save(self, path: str, **kwargs):
        return self._ani.save(path, **kwargs)

    @property
    def figure(self):
        return self._fig

    @property
    def animation(self) -> manim.FuncAnimation:
        return self._ani


# ── helpers ──────────────────────────────────────────────────────────────────
def _frame_indices(n: int, frames: Optional[int]) -> np.ndarray:
    """Down-sample n points into `frames` evenly-spaced indices (always include last)."""
    if frames is None or frames >= n:
        return np.arange(1, n + 1)
    return np.unique(np.linspace(1, n, frames).astype(int))


# ── 1) animated single-line price ────────────────────────────────────────────
def animate_price(data, *, title: Optional[str] = None, ticker: Optional[str] = None,
                  frames: Optional[int] = 120, interval: int = 40) -> _Anim:
    """Draw a price line progressively, frame-by-frame."""
    s = _close(data).dropna()
    x = np.arange(len(s))
    y = s.values
    idx_list = _frame_indices(len(s), frames)

    fig, ax = plt.subplots(figsize=(13, 6.5), facecolor=BG)
    _style_axes(ax)

    # glow layers (static, retinted later)
    glow1, = ax.plot([], [], color=CYAN, linewidth=12, alpha=0.04, solid_capstyle="round")
    glow2, = ax.plot([], [], color=CYAN, linewidth=5,  alpha=0.15, solid_capstyle="round")
    line,  = ax.plot([], [], color=CYAN, linewidth=2.0, solid_capstyle="round")
    head   = ax.scatter([], [], s=70, color=GOLD, zorder=5, edgecolor="white", linewidth=1)
    tag    = ax.text(0, 0, "", color="white", fontsize=10, fontweight="bold",
                     bbox=dict(boxstyle="round,pad=0.35", facecolor=PANEL_BG,
                               edgecolor=GOLD, linewidth=1, alpha=0.92),
                     ha="left", va="center")

    ax.set_xlim(0, len(s))
    pad = (y.max() - y.min()) * 0.08 or 1.0
    ax.set_ylim(y.min() - pad, y.max() + pad)
    ax.set_xticks([])
    ax.set_ylabel("Price", color="#8B949E")
    ax.set_title(title or (f"{ticker} — animated" if ticker else "Animated price"),
                 color="white", fontsize=15, fontweight="bold", pad=14)
    stamp_figure(fig)

    def update(k):
        xs, ys = x[:k], y[:k]
        for ln in (glow1, glow2, line):
            ln.set_data(xs, ys)
        if k > 0:
            head.set_offsets([[xs[-1], ys[-1]]])
            tag.set_position((xs[-1], ys[-1]))
            tag.set_text(f" {ys[-1]:,.2f} ")
        return glow1, glow2, line, head, tag

    ani = manim.FuncAnimation(fig, update, frames=idx_list,
                              interval=interval, blit=False, repeat=True)
    plt.close(fig)
    return _Anim(ani, fig)


# ── 2) animated backtest equity curve ────────────────────────────────────────
def animate_backtest(bt, *, frames: Optional[int] = 150, interval: int = 35,
                     title: str = "Backtest replay") -> _Anim:
    """Replay a Backtester result: equity curve grows, drawdown fills, signal bars stream."""
    eq = bt.equity
    sig = bt.signals.reindex(eq.index).fillna(0)
    dd = (eq / eq.cummax() - 1) * 100
    n = len(eq)
    x = np.arange(n)
    idx_list = _frame_indices(n, frames)

    fig = plt.figure(figsize=(14, 8), facecolor=BG)
    import matplotlib.gridspec as gridspec
    gs = gridspec.GridSpec(3, 1, figure=fig, height_ratios=[3, 1, 1],
                           hspace=0.08, left=0.08, right=0.97, top=0.92, bottom=0.08)
    ax1 = fig.add_subplot(gs[0])
    ax2 = fig.add_subplot(gs[1], sharex=ax1)
    ax3 = fig.add_subplot(gs[2], sharex=ax1)
    _style_axes(ax1, ax2, ax3)

    eq_glow, = ax1.plot([], [], color=CYAN, linewidth=10, alpha=0.05, solid_capstyle="round")
    eq_line, = ax1.plot([], [], color=CYAN, linewidth=2.0, solid_capstyle="round")
    eq_head  = ax1.scatter([], [], s=60, color=GOLD, edgecolor="white",
                           linewidth=1, zorder=5)
    ax1.axhline(1.0, color="#30363D", linewidth=1.0, linestyle="--", alpha=0.7)
    ax1.set_xlim(0, n); ax1.set_ylim(eq.min() * 0.98, eq.max() * 1.02)
    ax1.set_xticks([]); ax1.set_ylabel("Equity ($1)", color="#8B949E")

    badge = ax1.text(0.02, 0.97, "", transform=ax1.transAxes, va="top", ha="left",
                     fontsize=10, color="white", fontfamily="monospace",
                     bbox=dict(boxstyle="round,pad=0.5", facecolor=PANEL_BG,
                               edgecolor=CYAN, linewidth=1, alpha=0.92))

    dd_line, = ax2.plot([], [], color=RED, linewidth=1.2)
    dd_fill = [None]
    ax2.set_xlim(0, n); ax2.set_ylim(dd.min() * 1.05, 1)
    ax2.set_xticks([]); ax2.set_ylabel("Drawdown %", color="#8B949E", fontsize=9)
    ax2.axhline(0, color="#30363D", linewidth=0.8, linestyle="--", alpha=0.6)

    sig_bars = ax3.bar(x, np.zeros(n), width=1.5, color="#30363D", alpha=0.85)
    ax3.set_xlim(0, n); ax3.set_ylim(-1.2, 1.2)
    ax3.set_yticks([-1, 0, 1]); ax3.set_yticklabels(["Short", "Flat", "Long"], color="#8B949E")
    ax3.set_ylabel("Signal", color="#8B949E", fontsize=9)
    ax3.set_xlabel("Bars elapsed", color="#8B949E")

    fig.suptitle(f"{title}  ·  {bt.stats.get('strategy', 'Strategy')}",
                 color="white", fontsize=15, fontweight="bold")
    stamp_figure(fig)

    eq_arr  = eq.values
    dd_arr  = dd.values
    sig_arr = sig.values

    def update(k):
        xs = x[:k]
        eq_glow.set_data(xs, eq_arr[:k])
        eq_line.set_data(xs, eq_arr[:k])
        if k > 0:
            eq_head.set_offsets([[xs[-1], eq_arr[k-1]]])
            cur = eq_arr[k-1]
            run = (cur - 1)
            mdd = dd_arr[:k].min()
            badge.set_text(f"Bar:    {k}/{n}\n"
                           f"Equity: {cur:,.3f}\n"
                           f"P&L:    {run:+.1%}\n"
                           f"Max DD: {mdd:.1%}")
        # drawdown
        dd_line.set_data(xs, dd_arr[:k])
        if dd_fill[0] is not None:
            dd_fill[0].remove()
        if k > 1:
            dd_fill[0] = ax2.fill_between(xs, dd_arr[:k], 0,
                                          color=RED, alpha=0.30, linewidth=0)
        # signal bars — recolour up to k
        for i in range(min(k, n)):
            v = sig_arr[i]
            sig_bars[i].set_height(v)
            sig_bars[i].set_color(GREEN if v > 0 else (RED if v < 0 else "#30363D"))
        return (eq_glow, eq_line, eq_head, dd_line, badge)

    ani = manim.FuncAnimation(fig, update, frames=idx_list,
                              interval=interval, blit=False, repeat=True)
    plt.close(fig)
    return _Anim(ani, fig)


# ── 3) animated Monte-Carlo simulation ───────────────────────────────────────
def animate_montecarlo(mc, *, frames: Optional[int] = 120, interval: int = 35,
                       max_paths: int = 100, title: Optional[str] = None) -> _Anim:
    """Replay a MonteCarlo sim: many GBM paths reveal day-by-day with a fan."""
    if getattr(mc, "paths", None) is None:
        raise ValueError("Call mc.simulate(...) before animating.")
    paths = mc.paths
    horizon, n_paths = paths.shape
    n_draw = min(max_paths, n_paths)
    sample = paths[:, :n_draw]
    x = np.arange(horizon)
    idx_list = _frame_indices(horizon, frames)

    p05 = np.percentile(paths, 5,  axis=1)
    p50 = np.percentile(paths, 50, axis=1)
    p95 = np.percentile(paths, 95, axis=1)

    fig, ax = plt.subplots(figsize=(13, 7), facecolor=BG)
    _style_axes(ax)

    # one Line2D per drawn path (cycled colours, low alpha)
    palette = NEON_SERIES
    path_lines = []
    for j in range(n_draw):
        c = palette[j % len(palette)]
        ln, = ax.plot([], [], color=c, linewidth=0.8, alpha=0.35)
        path_lines.append(ln)

    fan = [None]   # holds the percentile fill artist
    median_line, = ax.plot([], [], color=GOLD, linewidth=2.2, alpha=0.95,
                           label="Median path")
    s0_line = ax.axhline(mc.s0, color="#30363D", linewidth=1.0,
                         linestyle="--", alpha=0.7)

    ax.set_xlim(0, horizon - 1)
    ymin = paths.min() * 0.95
    ymax = paths.max() * 1.05
    ax.set_ylim(ymin, ymax)
    ax.set_xlabel("Days", color="#8B949E")
    ax.set_ylabel("Price", color="#8B949E")
    ax.set_title(title or f"Monte-Carlo replay  ·  {n_paths:,} paths · {horizon-1}d horizon",
                 color="white", fontsize=15, fontweight="bold", pad=14)

    badge = ax.text(0.02, 0.97, "", transform=ax.transAxes, va="top", ha="left",
                    fontsize=10, color="white", fontfamily="monospace",
                    bbox=dict(boxstyle="round,pad=0.5", facecolor=PANEL_BG,
                              edgecolor=GOLD, linewidth=1, alpha=0.92))
    stamp_figure(fig)

    def update(k):
        xs = x[:k]
        for j, ln in enumerate(path_lines):
            ln.set_data(xs, sample[:k, j])
        median_line.set_data(xs, p50[:k])
        if fan[0] is not None:
            fan[0].remove()
        if k > 1:
            fan[0] = ax.fill_between(xs, p05[:k], p95[:k],
                                     color=CYAN, alpha=0.10, linewidth=0)
        if k > 0:
            cur = sample[k-1]
            badge.set_text(f"Day:     {k}/{horizon-1}\n"
                           f"Median:  {p50[k-1]:,.2f}\n"
                           f"P05:     {p05[k-1]:,.2f}\n"
                           f"P95:     {p95[k-1]:,.2f}")
        return (*path_lines, median_line, badge)

    ani = manim.FuncAnimation(fig, update, frames=idx_list,
                              interval=interval, blit=False, repeat=True)
    plt.close(fig)
    return _Anim(ani, fig)
