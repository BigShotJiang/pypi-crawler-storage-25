# © Squid Consultancy Group Ltd — All rights reserved.
# Unauthorised removal or modification of this notice is prohibited.
"""Pre-built chart functions — all return matplotlib Figure for further customization."""
