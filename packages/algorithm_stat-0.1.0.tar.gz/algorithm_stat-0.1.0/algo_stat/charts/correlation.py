# © Squid Consultancy Group Ltd — All rights reserved.
# Unauthorised removal or modification of this notice is prohibited.
from __future__ import annotations
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import seaborn as sns
import numpy as np
import pandas as pd

from algo_stat.charts.theme import stamp_figure, _style_axes, BG, PANEL_BG, BORDER, GRID_ALPHA


# custom neon diverging colormap: hot-pink → dark → electric-cyan
_NEON_CMAP = mcolors.LinearSegmentedColormap.from_list(
    "neon_corr",
    ["#FF3864", "#161B22", "#00F5FF"],
    N=256,
)


def correlation_heatmap(df: pd.DataFrame, title: str = "Correlation Matrix",
                        annot: bool = True):
    corr = df.corr()
    n = len(corr)
    size = max(7, n * 0.85)

    fig, ax = plt.subplots(figsize=(size, size * 0.9))
    fig.patch.set_facecolor(BG)
    ax.set_facecolor(BG)

    # heatmap with custom colormap
    mask = np.zeros_like(corr, dtype=bool)   # show full matrix
    sns.heatmap(
        corr, annot=annot, fmt=".2f", cmap=_NEON_CMAP,
        center=0, vmin=-1, vmax=1,
        square=True, linewidths=0, linecolor="none",
        ax=ax, annot_kws={"size": 10, "weight": "bold", "color": "white"},
        cbar_kws={"shrink": 0.75, "pad": 0.02},
    )

    # style colorbar
    cbar = ax.collections[0].colorbar
    cbar.ax.yaxis.set_tick_params(color="#6E7681", labelsize=9)
    plt.setp(cbar.ax.yaxis.get_ticklabels(), color="#6E7681")
    cbar.outline.set_edgecolor(BORDER)

    # style axes ticks
    ax.tick_params(colors="#8B949E", labelsize=10, length=0)
    for spine in ax.spines.values():
        spine.set_visible(False)

    # diagonal highlight boxes
    for i in range(n):
        ax.add_patch(plt.Rectangle((i, i), 1, 1,
                                    fill=True, facecolor="#BF5AF233",
                                    edgecolor="#BF5AF2", linewidth=1.5))

    ax.set_title(title, color="white", fontsize=16, fontweight="bold", pad=16)
    ax.set_xticklabels(ax.get_xticklabels(), rotation=40, ha="right", color="#8B949E")
    ax.set_yticklabels(ax.get_yticklabels(), rotation=0, color="#8B949E")

    fig.tight_layout()
    stamp_figure(fig)
    plt.close(fig)
    return fig
