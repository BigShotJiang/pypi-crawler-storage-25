# © Squid Consultancy Group Ltd — All rights reserved.
# Unauthorised removal or modification of this notice is prohibited.
from __future__ import annotations
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import matplotlib.ticker as mticker
import mplfinance as mpf
import numpy as np
import pandas as pd

from algo_stat.metrics.returns import _close
from algo_stat.charts.theme import stamp_figure

# ── vibrant palette ────────────────────────────────────────────────────────────
_BG        = "#0D1117"
_LINE      = "#00F5FF"   # electric cyan
_FILL      = "#00F5FF"
_POS       = "#39FF14"   # neon green  (YoY positive)
_NEG       = "#FF3864"   # hot pink    (YoY negative)
_ANNO_HI   = "#FF3864"   # high annotation
_ANNO_LO   = "#39FF14"   # low annotation
_MA_COLORS = ["#FFD600", "#FF6B6B", "#BF5AF2", "#4D96FF"]


def line(
    data,
    title:  str | None       = None,
    ma:     list[int] | None = None,
    ticker: str | None       = None,
    alpha:  float            = 0.3,
):
    """Premium line chart — neon glow, gradient fill, YoY change panel."""
    title = title or ticker
    s = _close(data).dropna()

    has_yoy = len(s) >= 13          # need at least 13 months for 1 YoY point

    # ── layout ────────────────────────────────────────────────────────────────
    fig = plt.figure(figsize=(15, 9 if has_yoy else 6), facecolor=_BG)
    if has_yoy:
        gs = gridspec.GridSpec(2, 1, figure=fig,
                               height_ratios=[3, 1], hspace=0.06,
                               left=0.07, right=0.97, top=0.91, bottom=0.08)
        ax  = fig.add_subplot(gs[0])
        ax2 = fig.add_subplot(gs[1], sharex=ax)
    else:
        gs = gridspec.GridSpec(1, 1, figure=fig,
                               left=0.07, right=0.97, top=0.91, bottom=0.08)
        ax  = fig.add_subplot(gs[0])
        ax2 = None

    for a_ in ([ax, ax2] if ax2 else [ax]):
        a_.set_facecolor(_BG)
        for spine in a_.spines.values():
            spine.set_visible(False)
        a_.tick_params(colors="#6E7681", labelsize=9, length=0)
        a_.grid(True, color="#30363D", linewidth=0.4, linestyle="--", alpha=0.25)

    # ── glow line (4 passes: outer halo → sharp core) ────────────────────────
    y = s.values.astype(float)
    for lw, al in [(14, 0.03), (8, 0.07), (3.5, 0.18), (1.6, 1.0)]:
        ax.plot(s.index, y, color=_LINE, linewidth=lw, alpha=al,
                solid_capstyle="round", solid_joinstyle="round")

    # ── gradient fill ─────────────────────────────────────────────────────────
    base = np.full_like(y, y.min() - (y.max() - y.min()) * 0.04)
    ax.fill_between(s.index, y, base, color=_FILL, alpha=alpha, linewidth=0,
                    zorder=0)

    # ── moving averages ───────────────────────────────────────────────────────
    if ma:
        for i, w in enumerate(ma):
            rolled = s.rolling(w).mean()
            ax.plot(s.index, rolled.values,
                    color=_MA_COLORS[i % len(_MA_COLORS)],
                    linewidth=1.5, linestyle="--", alpha=0.9,
                    label=f"MA {w}")
        leg = ax.legend(fontsize=9, loc="upper left",
                        facecolor="#161B22", edgecolor="#30363D",
                        framealpha=0.9)
        for txt in leg.get_texts():
            txt.set_color("white")

    # ── annotate all-time high & low ──────────────────────────────────────────
    idx_hi, idx_lo = s.idxmax(), s.idxmin()
    for idx, val, color, dy in [
        (idx_hi, s[idx_hi], _ANNO_HI, 22),
        (idx_lo, s[idx_lo], _ANNO_LO, -28),
    ]:
        ax.annotate(
            f"▲ {val:.2f}" if color == _ANNO_HI else f"▼ {val:.2f}",
            xy=(idx, val),
            xytext=(0, dy), textcoords="offset points",
            ha="center", va="center",
            color=color, fontsize=9, fontweight="bold",
            arrowprops=dict(arrowstyle="-|>", color=color,
                            lw=1.2, connectionstyle="arc3,rad=0.15"),
            bbox=dict(boxstyle="round,pad=0.3", facecolor="#161B22",
                      edgecolor=color, linewidth=1, alpha=0.9),
        )

    # ── current value badge ───────────────────────────────────────────────────
    last_val  = s.iloc[-1]
    first_val = s.iloc[0]
    pct_total = (last_val / first_val - 1) * 100
    badge_col = _POS if pct_total >= 0 else _NEG
    ax.annotate(
        f" {last_val:.2f}  {pct_total:+.1f}% ",
        xy=(s.index[-1], last_val),
        xytext=(8, 0), textcoords="offset points",
        va="center", ha="left",
        color=badge_col, fontsize=10, fontweight="bold",
        bbox=dict(boxstyle="round,pad=0.4", facecolor="#161B22",
                  edgecolor=badge_col, linewidth=1.4, alpha=0.95),
    )

    # ── axes styling ──────────────────────────────────────────────────────────
    ax.set_ylabel(title or "Value", color="#8B949E", fontsize=11, labelpad=10)
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(
        lambda x, _: f"{x:,.2f}"))
    if ax2 is None:
        ax.set_xlabel("Date", color="#8B949E", fontsize=10, labelpad=8)

    # ── title ─────────────────────────────────────────────────────────────────
    fig.suptitle(
        title or "Price",
        color="white", fontsize=17, fontweight="bold", x=0.52, y=0.97,
    )

    # ── YoY change panel ─────────────────────────────────────────────────────
    if ax2 is not None:
        yoy = s.pct_change(12).dropna() * 100
        pos = yoy[yoy >= 0]; neg = yoy[yoy < 0]
        bar_w = (s.index[-1] - s.index[0]).days / len(yoy) * 0.7
        ax2.bar(pos.index, pos.values, color=_POS, alpha=0.85,
                width=bar_w, align="center")
        ax2.bar(neg.index, neg.values, color=_NEG, alpha=0.85,
                width=bar_w, align="center")
        ax2.fill_between(yoy.index, yoy.values, 0,
                         where=yoy >= 0, color=_POS, alpha=0.12, linewidth=0)
        ax2.fill_between(yoy.index, yoy.values, 0,
                         where=yoy < 0,  color=_NEG, alpha=0.12, linewidth=0)
        ax2.axhline(0, color="#30363D", linewidth=1)
        ax2.set_ylabel("YoY %", color="#8B949E", fontsize=9, labelpad=8)
        ax2.yaxis.set_major_formatter(mticker.FuncFormatter(
            lambda x, _: f"{x:+.1f}%"))
        ax2.set_xlabel("Date", color="#8B949E", fontsize=10, labelpad=8)
        plt.setp(ax.get_xticklabels(), visible=False)

    fig.autofmt_xdate(rotation=30, ha="right")
    stamp_figure(fig)
    plt.close(fig)
    return fig


def candle(df: pd.DataFrame, title: str = "", style: str = "yahoo",
           volume: bool = True, ma: tuple[int, ...] = (20, 50)):
    """Candlestick chart via mplfinance. df must have OHLC(V)."""
    needed = {"Open", "High", "Low", "Close"}
    if not needed.issubset(df.columns):
        raise ValueError(f"Need OHLC columns; got {list(df.columns)}")
    fig, axes = mpf.plot(df, type="candle", style=style, mav=ma,
                      volume=volume and "Volume" in df.columns,
                      title=title, returnfig=True)
    # Force consistent light gridlines (alpha 0.25, dashed) across all panels
    for ax in (axes if isinstance(axes, (list, tuple)) else [axes]):
        ax.grid(True, color="#30363D", linewidth=0.4, linestyle="--", alpha=0.25)
    stamp_figure(fig)
    plt.close(fig)
    return fig


# ── multi-series line chart (for macro frames, normalised series, etc.) ──────

def lines(
    data: pd.DataFrame,
    *,
    title: str | None = None,
    ylabel: str | None = None,
    legend_loc: str = "best",
):
    """Multi-series line chart for wide DataFrames (one line per column).

    Use this for FRED / macro frames where each column is a separate series
    on potentially different scales (after :func:`algo_stat.fred_transform`).

    Examples
    --------
    >>> cpi = a.fred(["cpi","core_cpi"], years=10)
    >>> a.lines(a.fred_transform(cpi, "yoy"), title="CPI YoY %", ylabel="% YoY")
    """
    if isinstance(data, pd.Series):
        data = data.to_frame()
    if not isinstance(data, pd.DataFrame):
        raise TypeError(f"lines() expects a DataFrame; got {type(data).__name__}")

    df = data.dropna(how="all")
    cols = list(df.columns)

    fig = plt.figure(figsize=(15, 7), facecolor=_BG)
    ax  = fig.add_subplot(1, 1, 1)
    ax.set_facecolor(_BG)
    for sp in ax.spines.values():
        sp.set_visible(False)
    ax.tick_params(colors="#6E7681", labelsize=9, length=0)
    ax.grid(True, color="#30363D", linewidth=0.4, linestyle="--", alpha=0.25)

    palette = ["#00F5FF", "#FF3864", "#39FF14", "#FFD600",
               "#BF5AF2", "#4D96FF", "#FF8C42", "#F25CC1"]

    for i, c in enumerate(cols):
        color = palette[i % len(palette)]
        y = df[c].values.astype(float)
        for lw, al in [(8, 0.05), (3, 0.15), (1.6, 1.0)]:
            ax.plot(df.index, y, color=color, linewidth=lw, alpha=al,
                    solid_capstyle="round", label=c if lw == 1.6 else None)

    ax.axhline(0, color="#30363D", linewidth=0.8, linestyle="--", alpha=0.4)
    if ylabel:
        ax.set_ylabel(ylabel, color="#8B949E", fontsize=11, labelpad=10)
    if title:
        ax.set_title(title, color="white", fontsize=15, fontweight="bold",
                     loc="left", pad=14)

    leg = ax.legend(loc=legend_loc, fontsize=9,
                    facecolor="#161B22", edgecolor="#30363D", framealpha=0.9)
    for txt in leg.get_texts():
        txt.set_color("white")

    fig.autofmt_xdate(rotation=30, ha="right")
    fig.tight_layout()
    stamp_figure(fig)
    plt.close(fig)
    return fig


# ── twin-axis chart (two series on different scales) ─────────────────────────

def _to_series(x, name=None):
    """Coerce input → 1-D pd.Series indexed by datetime."""
    if isinstance(x, pd.Series):
        s = x
    elif isinstance(x, pd.DataFrame):
        if "Close" in x.columns:
            s = x["Close"]
        else:
            s = x.iloc[:, 0]
        name = name or (x.columns[0] if not x.empty else "series")
    else:
        raise TypeError(f"twin() needs Series/DataFrame; got {type(x).__name__}")
    s = s.dropna()
    if name:
        s = s.rename(name)
    return s


def twin(
    left,
    right,
    *,
    title: str | None = None,
    left_label: str | None = None,
    right_label: str | None = None,
    left_color: str = "#00F5FF",   # electric cyan
    right_color: str = "#FF3864",  # hot pink
):
    """Dual-axis line chart for two series on different scales.

    Mirrors the FinancialAnalysis2024 ``Twin_Plot`` pattern: left series on
    primary y-axis, right series on a ``twinx`` secondary y-axis, with
    end-of-line price tags for both. Use this when two series have very
    different units/scales and rebasing isn't appropriate (e.g., CPI vs S&P 500,
    M2 vs S&P 500, 10Y yield vs Gold).

    Examples
    --------
    >>> cpi = a.fred("cpi", years=20)
    >>> sp  = a.fetch("^GSPC", period="20y")
    >>> a.twin(cpi, sp, title="US CPI vs S&P 500",
    ...        left_label="CPI", right_label="S&P 500")
    """
    s1 = _to_series(left,  name=left_label)
    s2 = _to_series(right, name=right_label)
    left_label  = left_label  or s1.name or "left"
    right_label = right_label or s2.name or "right"

    # align on intersection of dates
    idx = s1.index.intersection(s2.index)
    if len(idx) == 0:
        # fall back to outer (e.g., monthly vs daily) — re-index right onto left
        s2 = s2.reindex(s1.index, method="ffill")
        idx = s1.index.dropna()
    s1, s2 = s1.loc[idx], s2.loc[idx]

    fig = plt.figure(figsize=(15, 7), facecolor=_BG)
    ax1 = fig.add_subplot(1, 1, 1)
    ax1.set_facecolor(_BG)

    # left series — glow + sharp
    for lw, al in [(8, 0.05), (3, 0.15), (1.6, 1.0)]:
        ax1.plot(s1.index, s1.values, color=left_color,
                 linewidth=lw, alpha=al, solid_capstyle="round")
    ax1.set_ylabel(left_label, color=left_color, fontsize=12, labelpad=10)
    ax1.tick_params(axis="y", colors=left_color, labelsize=9, length=0)
    ax1.tick_params(axis="x", colors="#6E7681", labelsize=9, length=0)
    for sp in ax1.spines.values():
        sp.set_visible(False)
    ax1.grid(True, color="#30363D", linewidth=0.4, linestyle="--", alpha=0.25)

    # right series on twin axis
    ax2 = ax1.twinx()
    ax2.set_facecolor(_BG)
    for lw, al in [(8, 0.05), (3, 0.15), (1.6, 1.0)]:
        ax2.plot(s2.index, s2.values, color=right_color,
                 linewidth=lw, alpha=al, solid_capstyle="round")
    ax2.set_ylabel(right_label, color=right_color, fontsize=12, labelpad=10)
    ax2.tick_params(axis="y", colors=right_color, labelsize=9, length=0)
    for sp in ax2.spines.values():
        sp.set_visible(False)
    ax2.grid(False)

    # end-of-line price tags
    def _tag(ax, x, y, color):
        ax.annotate(
            f" {y:,.2f} ",
            xy=(x, y), xycoords="data",
            xytext=(8, 0), textcoords="offset points",
            color="white", fontsize=9, fontweight="bold",
            va="center",
            bbox=dict(boxstyle="round,pad=0.35", fc=color, ec=color, alpha=0.95),
        )
    _tag(ax1, s1.index[-1], float(s1.iloc[-1]), left_color)
    _tag(ax2, s2.index[-1], float(s2.iloc[-1]), right_color)

    if title:
        ax1.set_title(title, color="white", fontsize=15, fontweight="bold",
                      loc="left", pad=14)

    fig.autofmt_xdate(rotation=30, ha="right")
    fig.tight_layout()
    stamp_figure(fig)
    plt.close(fig)
    return fig
