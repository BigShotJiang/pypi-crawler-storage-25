# © Squid Consultancy Group Ltd — All rights reserved.
# Unauthorised removal or modification of this notice is prohibited.
"""FastAPI REST API. Run with: `algo-stat serve` or `uvicorn algo_stat.api:app`."""
from __future__ import annotations
from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel

import algo_stat as a

app = FastAPI(
    title="algo-stat API",
    version=a.__version__,
    description="Quant finance toolkit — market data, metrics, charts, MC, backtests.",
)


@app.get("/health")
def health() -> dict:
    return {"status": "ok", "version": a.__version__}


@app.get("/quote/{ticker}")
def quote(ticker: str) -> dict:
    return a.ticker_info(ticker)


@app.get("/prices/{ticker}")
def prices(ticker: str, period: str = "1y", interval: str = "1d") -> dict:
    df = a.fetch(ticker, period=period, interval=interval)
    if df.empty:
        raise HTTPException(404, f"No data for {ticker}")
    return {"ticker": ticker, "rows": len(df),
            "columns": list(df.columns), "tail": df.tail(5).reset_index().to_dict(orient="records")}


@app.get("/performance/{ticker}")
def performance(ticker: str, period: str = "1y", market: str | None = None) -> dict:
    df = a.fetch(ticker, period=period)
    mkt = a.fetch(market, period=period) if market else None
    out = a.performance_metrics(df, market=mkt)
    out["var95"] = a.value_at_risk(df, 0.95)
    out.update(a.max_drawdown(df))
    return out


@app.get("/compare")
def compare(tickers: str = Query(..., description="comma-separated"),
            period: str = "1y") -> dict:
    items = [t.strip() for t in tickers.split(",")]
    cmp = a.compare(items, period=period)
    return {"tickers": items, "period": period,
            "normalized_tail": cmp.normalized.tail(5).reset_index().to_dict(orient="records")}


class MCRequest(BaseModel):
    ticker: str
    n: int = 1000
    days: int = 252
    seed: int | None = 42


@app.post("/montecarlo")
def montecarlo(req: MCRequest) -> dict:
    mc = a.MonteCarlo(req.ticker).simulate(n=req.n, days=req.days, seed=req.seed)
    return mc.summary()


class BTRequest(BaseModel):
    ticker: str
    fast: int = 20
    slow: int = 50
    period: str = "2y"
    fee_bps: float = 1.0


@app.post("/backtest/sma")
def backtest_sma(req: BTRequest) -> dict:
    bt = a.Backtester(req.ticker, period=req.period, fee_bps=req.fee_bps)
    return bt.run(a.SMACrossover(req.fast, req.slow)).stats


class MortgageRequest(BaseModel):
    price:   float
    deposit: float
    rate:    float
    years:   int = 25


@app.post("/mortgage")
def mortgage(req: MortgageRequest) -> dict:
    return a.MortgageCalculator(**req.model_dump()).summary()


@app.get("/macro/{series}")
def macro(series: str, years: int = 5) -> dict:
    df = a.fred(series, years=years)
    return {"series": series, "rows": len(df),
            "tail": df.tail(10).reset_index().to_dict(orient="records")}


class OptionRequest(BaseModel):
    S: float; K: float; T: float; r: float; sigma: float; q: float = 0.0


@app.post("/options/black-scholes")
def options_bs(req: OptionRequest) -> dict:
    res = a.black_scholes(**req.model_dump())
    return {"call": res.call, "put": res.put, "d1": res.d1, "d2": res.d2}
