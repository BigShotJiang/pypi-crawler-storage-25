# © Squid Consultancy Group Ltd — All rights reserved.
# Unauthorised removal or modification of this notice is prohibited.
"""Sharpe-based safety classifier.

Default: scikit-learn LogisticRegression (always available).
If TensorFlow is installed and `backend='tf'`, uses the original
3-layer Keras MLP architecture from the reference codebase
(Dense(10, relu) -> Dense(5, relu) -> Dense(1, sigmoid)).
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Sequence
import numpy as np
import pandas as pd

from algo_stat.data.market import fetch
from algo_stat.metrics.performance import sharpe, cagr


def _build_features(tickers: Sequence[str], period: str = "1y") -> pd.DataFrame:
    rows = []
    for t in tickers:
        try:
            df = fetch(t, period=period)
            rows.append({"ticker": t, "sharpe": sharpe(df), "cagr": cagr(df)})
        except Exception as e:                                   # noqa: BLE001
            rows.append({"ticker": t, "sharpe": np.nan, "cagr": np.nan, "error": str(e)})
    return pd.DataFrame(rows).dropna(subset=["sharpe", "cagr"])


@dataclass
class SafetyClassifier:
    """Predicts 'safe' (1) vs 'risky' (0) using Sharpe>threshold as ground truth.

    >>> clf = SafetyClassifier().fit(["AAPL","MSFT","NVDA","GME","AMC"])
    >>> clf.predict(["TSLA","KO"])
    """
    threshold: float = 0.5
    backend: str = "sklearn"        # or "tf"

    def fit(self, tickers: Sequence[str], period: str = "1y") -> "SafetyClassifier":
        feats = _build_features(tickers, period=period)
        X = feats[["sharpe", "cagr"]].values
        y = (feats["sharpe"] > self.threshold).astype(int).values
        self.features_ = feats

        if self.backend == "tf":
            import tensorflow as tf  # type: ignore
            model = tf.keras.Sequential([
                tf.keras.layers.Dense(10, activation="relu", input_shape=(2,)),
                tf.keras.layers.Dense(5,  activation="relu"),
                tf.keras.layers.Dense(1,  activation="sigmoid"),
            ])
            model.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy"])
            model.fit(X, y, epochs=50, verbose=0)
            self.model_ = model
        else:
            from sklearn.linear_model import LogisticRegression
            self.model_ = LogisticRegression(max_iter=500).fit(X, y)
        return self

    def predict(self, tickers: Sequence[str], period: str = "1y") -> pd.DataFrame:
        feats = _build_features(tickers, period=period)
        X = feats[["sharpe", "cagr"]].values
        if self.backend == "tf":
            proba = self.model_.predict(X, verbose=0).flatten()
        else:
            proba = self.model_.predict_proba(X)[:, 1]
        feats = feats.assign(prob_safe=proba, label=np.where(proba >= 0.5, "safe", "risky"))
        return feats
