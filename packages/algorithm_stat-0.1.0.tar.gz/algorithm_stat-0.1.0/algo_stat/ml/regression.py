# © Squid Consultancy Group Ltd — All rights reserved.
# Unauthorised removal or modification of this notice is prohibited.
from __future__ import annotations
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression


def linreg(x, y) -> dict:
    """OLS y = a + b*x. Returns slope, intercept, r2."""
    x = np.asarray(x).reshape(-1, 1); y = np.asarray(y)
    m = LinearRegression().fit(x, y)
    return {
        "slope":     float(m.coef_[0]),
        "intercept": float(m.intercept_),
        "r2":        float(m.score(x, y)),
        "predict":   lambda xs: m.predict(np.asarray(xs).reshape(-1, 1)),
    }


def polyfit(x, y, degree: int = 2) -> dict:
    coefs = np.polyfit(x, y, degree)
    poly  = np.poly1d(coefs)
    yhat  = poly(x)
    ss_res = float(np.sum((y - yhat) ** 2))
    ss_tot = float(np.sum((y - np.mean(y)) ** 2)) or 1.0
    return {"coefficients": coefs.tolist(), "r2": 1 - ss_res / ss_tot, "predict": poly}
