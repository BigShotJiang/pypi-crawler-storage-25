# © Squid Consultancy Group Ltd — All rights reserved.
# Unauthorised removal or modification of this notice is prohibited.
from __future__ import annotations
from typing import Sequence
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

from algo_stat.data.market import fetch_many
from algo_stat.charts.theme import stamp_figure


def stock_pca(tickers: Sequence[str], period: str = "1y",
              n_components: int = 2, plot: bool = True):
    """PCA on daily returns of multiple tickers.

    >>> stock_pca(["AAPL","MSFT","NVDA","TSLA"], plot=True)
    """
    prices = fetch_many(tickers, period=period).dropna()
    rets = prices.pct_change().dropna().T          # rows = tickers
    X = StandardScaler().fit_transform(rets.values)
    p = PCA(n_components=n_components).fit(X)
    coords = p.transform(X)

    df = pd.DataFrame(coords, index=rets.index,
                      columns=[f"PC{i+1}" for i in range(n_components)])

    fig = None
    if plot and n_components >= 2:
        from algo_stat.charts.theme import _style_axes, BG, PANEL_BG, BORDER, NEON_SERIES, CYAN
        import matplotlib.ticker as mticker

        ev = p.explained_variance_ratio_
        fig = plt.figure(figsize=(13, 8), facecolor=BG)
        gs  = fig.add_gridspec(1, 2, width_ratios=[2, 1], wspace=0.12,
                               left=0.08, right=0.97, top=0.91, bottom=0.10)
        ax_s  = fig.add_subplot(gs[0])   # scatter
        ax_ev = fig.add_subplot(gs[1])   # scree
        _style_axes(ax_s, ax_ev)

        # scatter with neon per-ticker colours
        for i, (name, row) in enumerate(df.iterrows()):
            color = NEON_SERIES[i % len(NEON_SERIES)]
            # glow dot
            ax_s.scatter(row["PC1"], row["PC2"], color=color, s=180, zorder=5, alpha=0.95)
            ax_s.scatter(row["PC1"], row["PC2"], color=color, s=600, zorder=4, alpha=0.12)
            ax_s.annotate(name,
                          (row["PC1"], row["PC2"]),
                          xytext=(0, 9), textcoords="offset points",
                          ha="center", va="bottom",
                          color=color, fontsize=10, fontweight="bold",
                          bbox=dict(boxstyle="round,pad=0.25", facecolor=PANEL_BG,
                                    edgecolor=color, linewidth=1, alpha=0.85))

        ax_s.axhline(0, color="#30363D", linewidth=1, linestyle="--", alpha=0.5)
        ax_s.axvline(0, color="#30363D", linewidth=1, linestyle="--", alpha=0.5)
        ax_s.set_xlabel(f"PC1  ({ev[0]:.1%} var.)",
                        color="#8B949E", fontsize=11, labelpad=10)
        ax_s.set_ylabel(f"PC2  ({ev[1]:.1%} var.)",
                        color="#8B949E", fontsize=11, labelpad=10)

        # scree / variance bar
        bar_colors = [NEON_SERIES[i % len(NEON_SERIES)] for i in range(n_components)]
        ax_ev.bar(range(1, n_components + 1), ev * 100,
                  color=bar_colors, alpha=0.88, zorder=3, width=0.5)
        cumev = np.cumsum(ev) * 100
        for lw, al in [(5, 0.12), (1.8, 1.0)]:
            ax_ev.plot(range(1, n_components + 1), cumev, color=CYAN,
                       linewidth=lw, alpha=al, marker="o", markersize=6)
        ax_ev.set_xlabel("Component", color="#8B949E", fontsize=10, labelpad=8)
        ax_ev.set_ylabel("Variance explained (%)", color="#8B949E", fontsize=10, labelpad=8)
        ax_ev.set_xticks(range(1, n_components + 1))
        ax_ev.set_title("Scree", color="white", fontsize=12, pad=8)
        ax_ev.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v, _: f"{v:.0f}%"))

        fig.suptitle(f"PCA  ·  {', '.join(str(t) for t in tickers)}  ·  {period}",
                     color="white", fontsize=16, fontweight="bold", x=0.52, y=0.97)
        stamp_figure(fig)
        plt.close(fig)
    return {"components": df, "explained": p.explained_variance_ratio_, "fig": fig}
