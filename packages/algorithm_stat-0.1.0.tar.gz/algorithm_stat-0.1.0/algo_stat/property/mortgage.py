# © Squid Consultancy Group Ltd — All rights reserved.
# Unauthorised removal or modification of this notice is prohibited.
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from algo_stat.charts.theme import stamp_figure


@dataclass
class MortgageCalculator:
    """Mortgage analytics & rate-shock simulator.

    >>> mc = MortgageCalculator(price=300_000, deposit=60_000, rate=0.055, years=25)
    >>> mc.summary()
    >>> mc.simulate_rate_shock([0.06, 0.07, 0.08]).plot()
    """
    price: float
    deposit: float
    rate: float            # annual decimal (e.g. 0.055)
    years: int = 25

    @property
    def loan(self) -> float:
        return self.price - self.deposit

    @property
    def monthly_payment(self) -> float:
        n = self.years * 12
        r = self.rate / 12
        if r == 0:
            return self.loan / n
        return self.loan * r / (1 - (1 + r) ** -n)

    def amortization(self) -> pd.DataFrame:
        n = self.years * 12
        r = self.rate / 12
        bal = self.loan
        rows = []
        pmt = self.monthly_payment
        for m in range(1, n + 1):
            interest = bal * r
            principal = pmt - interest
            bal -= principal
            rows.append({"month": m, "payment": pmt, "interest": interest,
                         "principal": principal, "balance": max(bal, 0)})
        return pd.DataFrame(rows)

    def summary(self) -> dict:
        am = self.amortization()
        return {
            "loan":            self.loan,
            "monthly_payment": float(self.monthly_payment),
            "total_paid":      float(am["payment"].sum()),
            "total_interest":  float(am["interest"].sum()),
            "ltv":             round(self.loan / self.price, 4),
        }

    def simulate_rate_shock(self, rates: list[float]) -> "_ShockResult":
        rows = []
        for r in rates:
            mc = MortgageCalculator(self.price, self.deposit, r, self.years)
            rows.append({"rate": r, "monthly_payment": mc.monthly_payment,
                         "total_interest": mc.amortization()["interest"].sum()})
        return _ShockResult(pd.DataFrame(rows), base=self)


@dataclass
class _ShockResult:
    df: pd.DataFrame
    base: MortgageCalculator

    def plot(self, title: str = "Rate-shock impact"):
        from algo_stat.charts.theme import _style_axes, BG, PANEL_BG, BORDER, GREEN, RED, GOLD, CYAN
        import matplotlib.colors as mcolors
        import matplotlib.ticker as mticker

        df  = self.df
        n   = len(df)
        pmt = df["monthly_payment"].values
        tot = df["total_interest"].values
        labels = [f"{r*100:.2f}%" for r in df["rate"]]

        # colour: green (low) → gold → red (high)
        cmap    = mcolors.LinearSegmentedColormap.from_list("shock", [GREEN, GOLD, RED], N=256)
        norm_v  = (pmt - pmt.min()) / (pmt.max() - pmt.min() + 1e-9)
        bar_colors = [cmap(v) for v in norm_v]

        fig = plt.figure(figsize=(14, 8), facecolor=BG)
        gs  = fig.add_gridspec(2, 1, hspace=0.08,
                               left=0.08, right=0.97, top=0.91, bottom=0.12)
        ax1 = fig.add_subplot(gs[0])
        ax2 = fig.add_subplot(gs[1])
        _style_axes(ax1, ax2)

        x = range(n)

        # ── monthly payment bars ──────────────────────────────────────
        bars = ax1.bar(x, pmt, color=bar_colors, width=0.6, alpha=0.88, zorder=3)
        ax1.axhline(self.base.monthly_payment, color=GOLD,
                    linewidth=2, linestyle="--", alpha=0.85, zorder=4,
                    label=f"Current: ${self.base.monthly_payment:,.0f}/mo")
        # value labels
        for bar, v in zip(bars, pmt):
            ax1.text(bar.get_x() + bar.get_width() / 2, v + pmt.max() * 0.01,
                     f"${v:,.0f}", ha="center", va="bottom",
                     color="white", fontsize=9, fontweight="bold")

        leg = ax1.legend(fontsize=10, facecolor=PANEL_BG, edgecolor=BORDER, framealpha=0.9)
        for txt in leg.get_texts():
            txt.set_color("white")
        ax1.set_ylabel("Monthly Payment ($)", color="#8B949E", fontsize=11, labelpad=10)
        ax1.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v, _: f"${v:,.0f}"))
        ax1.set_xticks(list(x)); ax1.set_xticklabels([])

        # ── total interest bars ───────────────────────────────────────
        bars2 = ax2.bar(x, tot / 1e3, color=bar_colors, width=0.6, alpha=0.88, zorder=3)
        for bar, v in zip(bars2, tot):
            ax2.text(bar.get_x() + bar.get_width() / 2, v / 1e3 + tot.max() / 1e3 * 0.01,
                     f"${v/1e3:,.0f}k", ha="center", va="bottom",
                     color="white", fontsize=9, fontweight="bold")

        ax2.set_ylabel("Total Interest ($k)", color="#8B949E", fontsize=11, labelpad=10)
        ax2.set_xticks(list(x)); ax2.set_xticklabels(labels, color="#8B949E", fontsize=10)
        ax2.set_xlabel("Interest Rate", color="#8B949E", fontsize=10, labelpad=8)
        ax2.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v, _: f"${v:,.0f}k"))

        fig.suptitle(title, color="white", fontsize=16, fontweight="bold",
                     x=0.52, y=0.97)
        stamp_figure(fig)
        plt.close(fig)
        return fig
