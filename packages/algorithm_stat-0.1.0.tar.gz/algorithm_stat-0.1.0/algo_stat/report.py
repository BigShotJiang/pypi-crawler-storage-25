# © Squid Consultancy Group Ltd — All rights reserved.
# Unauthorised removal or modification of this notice is prohibited.
from __future__ import annotations
from tabulate import tabulate

from algo_stat.metrics.performance import performance_metrics
from algo_stat.metrics.risk import value_at_risk, max_drawdown
from algo_stat.charts.price import line


def report(data, ticker: str = "Asset", show_chart: bool = True) -> dict:
    """One-call text + chart report.

    >>> a.report(a.fetch("NVDA"), ticker="NVDA")
    """
    perf = performance_metrics(data)
    perf["var95"]    = value_at_risk(data, 0.95)
    perf.update(max_drawdown(data))

    rows = [(k, v) for k, v in perf.items()]
    print(f"\n=== {ticker} ===")
    print(tabulate(rows, headers=["metric", "value"], tablefmt="github", floatfmt=".4f"))

    if show_chart:
        line(data, title=ticker, ma=[20, 50])
    return perf
