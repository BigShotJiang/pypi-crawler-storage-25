# © Squid Consultancy Group Ltd — All rights reserved.
# Unauthorised removal or modification of this notice is prohibited.
"""Index constituents — fetched live from Wikipedia, cached to data/."""
from __future__ import annotations
from io import StringIO
from pathlib import Path
import urllib.request
import pandas as pd

_CACHE = Path(__file__).resolve().parents[2] / "data"
_CACHE.mkdir(exist_ok=True)

_SP500_URL  = "https://en.wikipedia.org/wiki/List_of_S%26P_500_companies"
_FTSE_URL   = "https://en.wikipedia.org/wiki/FTSE_100_Index"

# Wikipedia rejects the default urllib user-agent with HTTP 403.
_UA = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0 Safari/537.36"
)


def _read_html(url: str) -> list[pd.DataFrame]:
    try:
        req = urllib.request.Request(url, headers={"User-Agent": _UA})
        with urllib.request.urlopen(req, timeout=30) as r:
            html = r.read().decode("utf-8", errors="replace")
        return pd.read_html(StringIO(html))
    except ImportError as e:
        raise ImportError(
            "pandas.read_html needs an HTML parser. Install with:\n"
            "  pip install lxml html5lib beautifulsoup4"
        ) from e


def sp500(refresh: bool = False) -> pd.DataFrame:
    """S&P 500 constituents (Symbol, Security, GICS Sector, ...).

    Cached to ``data/SNP500.csv`` after first call. Pass ``refresh=True``
    to force a re-download.
    """
    cache = _CACHE / "SNP500.csv"
    if cache.exists() and not refresh:
        return pd.read_csv(cache)
    df = _read_html(_SP500_URL)[0]
    df.to_csv(cache, index=False)
    return df


def ftse100(refresh: bool = False) -> pd.DataFrame:
    """FTSE 100 constituents (Ticker, Company, FTSE Industry Classification, ...).

    Cached to ``data/uk_100.csv`` after first call.
    """
    cache = _CACHE / "uk_100.csv"
    if cache.exists() and not refresh:
        return pd.read_csv(cache)
    tables = _read_html(_FTSE_URL)
    # The constituents table is the one with a 'Ticker' or 'EPIC' column.
    for t in tables:
        cols = {str(c).lower() for c in t.columns}
        if cols & {"ticker", "epic", "symbol"}:
            t.to_csv(cache, index=False)
            return t
    raise RuntimeError("Could not locate FTSE 100 constituents table on Wikipedia.")
