# © Squid Consultancy Group Ltd — All rights reserved.
# Unauthorised removal or modification of this notice is prohibited.
from __future__ import annotations
from typing import Iterable
import pandas as pd
import yfinance as yf


def fetch(
    ticker: str,
    period: str = "1y",
    interval: str = "1d",
    start: str | None = None,
    end: str | None = None,
    auto_adjust: bool = True,
) -> pd.DataFrame:
    """Fetch OHLCV for a single ticker. No API key required.

    >>> fetch("NVDA", period="6mo")
    """
    if start or end:
        df = yf.download(ticker, start=start, end=end, interval=interval,
                         auto_adjust=auto_adjust, progress=False)
    else:
        df = yf.download(ticker, period=period, interval=interval,
                         auto_adjust=auto_adjust, progress=False)
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)
    df.attrs["ticker"] = ticker
    return df


def fetch_many(
    tickers: Iterable[str],
    period: str = "1y",
    field: str = "Close",
    **kw,
) -> pd.DataFrame:
    """Fetch a single field across many tickers; returns wide DataFrame."""
    tickers = list(tickers)
    raw = yf.download(tickers, period=period, auto_adjust=True, progress=False, **kw)
    if isinstance(raw.columns, pd.MultiIndex):
        df = raw[field].copy()
    else:
        df = raw[[field]].rename(columns={field: tickers[0]})
    return df.dropna(how="all")


def ticker_info(ticker: str) -> dict:
    """Fundamental snapshot from yfinance .info."""
    info = yf.Ticker(ticker).info or {}
    keys = [
        "longName", "sector", "industry", "previousClose", "open",
        "dayLow", "dayHigh", "fiftyTwoWeekLow", "fiftyTwoWeekHigh",
        "marketCap", "volume", "averageVolume", "beta",
        "trailingPE", "forwardPE", "dividendYield", "currency", "exchange",
    ]
    return {k: info.get(k) for k in keys}
