# © Squid Consultancy Group Ltd — All rights reserved.
# Unauthorised removal or modification of this notice is prohibited.
"""FRED — Federal Reserve Economic Data client for algo_stat.

══════════════════════════════════════════════════════════════════════════════
  © Squid Consultancy Group Ltd  |  algo-stat  |  All rights reserved.
══════════════════════════════════════════════════════════════════════════════

Get your free FRED API key at:  https://fredaccount.stlouisfed.org/apikeys

Quick start
───────────
  >>> from algo_stat.data.fred import FredClient
  >>> import algo_stat as a; a.use_dark()

  # ── Create client ──────────────────────────────────────────────────────
  >>> client = FredClient(api_key="YOUR_KEY")
  >>> # or set FRED_API_KEY=YOUR_KEY in .env and call FredClient()

  # ── Fetch using shortcut names ─────────────────────────────────────────
  >>> cpi  = client.fetch("cpi",        years=5)    # → CPIAUCSL
  >>> gdp  = client.fetch("real_gdp",   years=20)   # → GDPC1
  >>> rate = client.fetch("fed_funds",  years=10)   # → FEDFUNDS

  # ── Fetch using raw FRED series IDs ────────────────────────────────────
  >>> sp500_pe = client.fetch("CAPE",    years=30)
  >>> yields   = client.fetch("DGS10",   start="2010-01-01", end="2024-12-31")

  # ── Multiple series → wide DataFrame ──────────────────────────────────
  >>> macro = client.fetch(["cpi", "fed_funds", "10y_treasury"])

  # ── Search for series ──────────────────────────────────────────────────
  >>> hits = client.search("inflation expectations", limit=5)
  >>> print(hits[["id", "title"]])

  # ── Plot (align to algo_stat standard first) ───────────────────────────
  >>> from algo_stat.data.adapter import align_series
  >>> df = align_series(cpi, label="CPI")
  >>> a.line(df.rename(columns={"CPI": "Close"}), ticker="CPI (CPIAUCSL)")

  # ── Pipeline (connect nodes) ───────────────────────────────────────────
  >>> (
  ...   client.fetch("cpi")
  ...   .pipe(align_series, label="CPI")
  ...   .rename(columns={"CPI": "Close"})
  ...   .pipe(a.line, ticker="Consumer Price Index")
  ... )

Output format (algo_stat standard Series)
──────────────────────────────────────────
  Type  : pd.DataFrame
  Index : DatetimeIndex (daily / monthly / quarterly — as published by FRED)
  Column: named after the FRED series ID (e.g. "CPIAUCSL"), float64
  Attrs : {"series": str, "source": "fred"}
  NaN   : used for unreported / missing observations

To use with any algo_stat chart, rename the column to "Close":

    df.rename(columns={"CPIAUCSL": "Close"})

or use the align_series helper which does this cleanly:

    from algo_stat.data.adapter import align_series
    aligned = align_series(raw, label="CPI")

Built-in series shortcuts
──────────────────────────
  Shortcut        FRED ID           Description
  ─────────────── ───────────────── ─────────────────────────────────────────
  cpi             CPIAUCSL          Consumer Price Index (all items)
  core_cpi        CPILFESL          CPI ex food & energy
  m2              M2SL              M2 money supply
  fed_funds       FEDFUNDS          Federal Funds Effective Rate
  unemployment    UNRATE            Unemployment rate
  gdp             GDP               Nominal GDP (current $, quarterly)
  real_gdp        GDPC1             Real GDP (chained 2017 $, quarterly)
  10y_treasury    DGS10             10-Year Treasury Constant Maturity Rate
  2y_treasury     DGS2              2-Year Treasury Constant Maturity Rate
  30y_mortgage    MORTGAGE30US      30-Year Fixed Mortgage Rate
  vix             VIXCLS            CBOE Volatility Index
  sahm_rule       SAHMREALTIME      Sahm Rule Recession Indicator
  debt_to_gdp     GFDEGDQ188S       Federal Debt as % of GDP
  yield_spread    T10Y2Y            10Y–2Y Treasury Spread (recession signal)
  breakeven_5y    T5YIE             5-Year Breakeven Inflation Rate
  pce             PCEPI             PCE Price Index (Fed's preferred inflation)
  core_pce        PCEPILFE          Core PCE Price Index
  retail_sales    RSXFS             Advance Retail Sales
  industrial_prod INDPRO            Industrial Production Index
  housing_starts  HOUST             Housing Starts (1000s of units)
  nfp             PAYEMS            Non-Farm Payrolls
  personal_income DSPIC96           Real Disposable Personal Income

Full FRED series catalogue:  https://fred.stlouisfed.org/
"""
from __future__ import annotations

from datetime import datetime, timedelta
from typing import Union
import pandas as pd

from algo_stat.config import settings

# ── Series shortcuts ──────────────────────────────────────────────────────────
SERIES: dict[str, str] = {
    "cpi":             "CPIAUCSL",
    "core_cpi":        "CPILFESL",
    "m2":              "M2SL",
    "fed_funds":       "FEDFUNDS",
    "unemployment":    "UNRATE",
    "gdp":             "GDP",
    "real_gdp":        "GDPC1",
    "10y_treasury":    "DGS10",
    "2y_treasury":     "DGS2",
    "30y_mortgage":    "MORTGAGE30US",
    "vix":             "VIXCLS",
    "sahm_rule":       "SAHMREALTIME",
    "debt_to_gdp":     "GFDEGDQ188S",
    "yield_spread":    "T10Y2Y",
    "breakeven_5y":    "T5YIE",
    "pce":             "PCEPI",
    "core_pce":        "PCEPILFE",
    "retail_sales":    "RSXFS",
    "industrial_prod": "INDPRO",
    "housing_starts":  "HOUST",
    "nfp":             "PAYEMS",
    "personal_income": "DSPIC96",
}

_BASE = "https://api.stlouisfed.org/fred"


class FredClient:
    """HTTP client for the FRED REST API — Python 3.13 safe (no pandas-datareader).

    Parameters
    ----------
    api_key : FRED API key from https://fredaccount.stlouisfed.org/apikeys
              Defaults to the ``FRED_API_KEY`` environment variable / .env file.

    Examples
    --------
    >>> from algo_stat.data.fred import FredClient
    >>> client = FredClient(api_key="YOUR_KEY")
    >>> cpi = client.fetch("cpi", years=10)
    >>> client.help()
    """

    source = "fred"

    def __init__(self, api_key: str | None = None) -> None:
        import os as _os
        self._key = api_key or settings.fred_api_key or _os.environ.get("FRED_API_KEY")
        if not self._key:
            raise ValueError(
                "FRED API key required. Pass api_key= or set FRED_API_KEY in .env\n"
                "Get a free key at: https://fredaccount.stlouisfed.org/apikeys"
            )

    # ── core fetch ────────────────────────────────────────────────────────

    def fetch(
        self,
        series: Union[str, list[str]],
        *,
        start: str | None = None,
        end:   str | None = None,
        years: int = 10,
        units: str = "lin",
    ) -> pd.DataFrame:
        """Fetch one or more FRED series.

        Parameters
        ----------
        series : shortcut name (e.g. ``"cpi"``) or raw FRED ID (``"CPIAUCSL"``)
                 or a list of either.
        start  : ISO date string ``"YYYY-MM-DD"``; overrides *years*
        end    : ISO date string ``"YYYY-MM-DD"``; defaults to today
        years  : lookback window when *start* not supplied (default 10)
        units  : FRED transformation code — ``"lin"`` (level), ``"pc1"``
                 (% change YoY), ``"pch"`` (% change), ``"log"`` etc.

        Returns
        -------
        pd.DataFrame
            DatetimeIndex + one column per series (float64, NaN for missing).
            Use ``align_series()`` to rename / normalise before charting.

        Examples
        --------
        >>> client.fetch("cpi")                         # single shortcut
        >>> client.fetch("CPIAUCSL", years=20)          # raw FRED ID
        >>> client.fetch(["cpi","fed_funds","vix"])     # multiple → wide
        >>> client.fetch("real_gdp", start="2000-01-01", end="2024-01-01")
        """
        end   = end   or datetime.today().strftime("%Y-%m-%d")
        start = start or (datetime.today() - timedelta(days=365 * years)).strftime("%Y-%m-%d")

        if isinstance(series, str):
            codes = [SERIES.get(series.lower(), series)]
        else:
            codes = [SERIES.get(s.lower(), s) for s in series]

        frames: list[pd.DataFrame] = []
        for code in codes:
            frames.append(self._fetch_one(code, start=start, end=end, units=units))

        if len(frames) == 1:
            return frames[0]

        # Merge multiple series on their date index
        merged = frames[0]
        for f in frames[1:]:
            merged = merged.join(f, how="outer")
        return merged

    # ── metadata / search ────────────────────────────────────────────────

    def series_info(self, series_id: str) -> dict:
        """Return FRED metadata for a series.

        >>> client.series_info("CPIAUCSL")
        """
        params = self._params({"series_id": SERIES.get(series_id.lower(), series_id)})
        return self._get(f"{_BASE}/series", params)["seriess"][0]

    def search(self, query: str, limit: int = 10) -> pd.DataFrame:
        """Search the FRED catalogue for series matching *query*.

        Returns a DataFrame with columns ``[id, title, frequency, units]``.

        >>> hits = client.search("inflation expectations", limit=5)
        >>> print(hits[["id", "title"]])
        """
        params = self._params({"search_text": query, "limit": limit})
        data   = self._get(f"{_BASE}/series/search", params)
        rows = [
            {
                "id":        s["id"],
                "title":     s["title"],
                "frequency": s.get("frequency_short", ""),
                "units":     s.get("units_short", ""),
                "updated":   s.get("last_updated", ""),
            }
            for s in data.get("seriess", [])
        ]
        return pd.DataFrame(rows)

    # ── convenience ───────────────────────────────────────────────────────

    @staticmethod
    def help() -> None:
        """Print the full FRED integration guide."""
        print(__doc__)

    @staticmethod
    def shortcuts() -> pd.DataFrame:
        """Return a DataFrame of all built-in series shortcuts.

        >>> FredClient.shortcuts()
        """
        return pd.DataFrame(
            [{"shortcut": k, "fred_id": v} for k, v in SERIES.items()]
        )

    # ── internals ─────────────────────────────────────────────────────────

    def _fetch_one(
        self,
        code:  str,
        start: str,
        end:   str,
        units: str,
    ) -> pd.DataFrame:
        params = self._params({
            "series_id":          code,
            "observation_start":  start,
            "observation_end":    end,
            "units":              units,
            "file_type":          "json",
        })
        data = self._get(f"{_BASE}/series/observations", params)
        obs  = data["observations"]

        records = [
            (row["date"], None if row["value"] == "." else float(row["value"]))
            for row in obs
        ]
        df           = pd.DataFrame(records, columns=["Date", code])
        df["Date"]   = pd.to_datetime(df["Date"])
        df           = df.set_index("Date").sort_index()
        df.attrs     = {"series": code, "source": "fred"}
        return df

    def _params(self, extra: dict) -> dict:
        return {"api_key": self._key, "file_type": "json", **extra}

    @staticmethod
    def _get(url: str, params: dict) -> dict:
        try:
            import requests
        except ImportError:
            raise ImportError("requests is required: pip install requests")
        # Retry on transient errors (5xx, connection issues). FRED occasionally
        # returns 500s under load — exponential backoff usually clears it.
        import time
        last_err: Exception | None = None
        for attempt in range(4):
            try:
                resp = requests.get(url, params=params, timeout=30)
                if resp.status_code >= 500:
                    last_err = requests.HTTPError(
                        f"{resp.status_code} {resp.reason}", response=resp
                    )
                    time.sleep(0.7 * (2 ** attempt))
                    continue
                resp.raise_for_status()
                return resp.json()
            except (requests.ConnectionError, requests.Timeout) as e:
                last_err = e
                time.sleep(0.7 * (2 ** attempt))
        # exhausted retries
        raise last_err if last_err else RuntimeError("FRED request failed")


# ── Module-level help callable (help(fred_module) works) ─────────────────────

def help() -> None:  # noqa: A001
    """Print the full FRED integration guide."""
    print(__doc__)


def fred(
    series: "str | list[str]",
    *,
    start: "str | None" = None,
    end: "str | None" = None,
    years: int = 10,
    api_key: "str | None" = None,
) -> "pd.DataFrame":
    """Convenience one-liner: create a FredClient and fetch in one call.

    Reads the API key from the ``FRED_API_KEY`` environment variable / .env file,
    or pass ``api_key=`` directly.

    >>> import algo_stat as a
    >>> a.fred("cpi", years=5)
    >>> a.fred(["cpi", "fed_funds", "10y_treasury"])
    >>> a.fred("cpi", api_key="YOUR_KEY")
    """
    return FredClient(api_key=api_key).fetch(series, start=start, end=end, years=years)


# ── DataFrame transforms (apply BEFORE plotting macro/FRED data) ─────────────

def transform(
    df: "pd.DataFrame",
    how: str = "yoy",
    *,
    window: int = 12,
    base: float = 100.0,
) -> "pd.DataFrame":
    """Standard transformations to apply to FRED / macro frames before plotting.

    Macro series live on very different scales (CPI in 100s, UNRATE in %, M2 in
    trillions). Always transform before charting two series together, otherwise
    one line will dwarf the other.

    Parameters
    ----------
    df     : wide DataFrame (one column per series), DatetimeIndex
    how    : transformation
             - ``"yoy"``       : year-over-year % change (uses *window* periods)
             - ``"mom"`` / ``"pct"`` : period-over-period % change
             - ``"log"``       : natural log of the level
             - ``"logdiff"``   : first difference of log (continuously-compounded return)
             - ``"diff"``      : first difference (level change)
             - ``"zscore"``    : (x - mean) / std, per column
             - ``"index"`` / ``"rebase"`` : rebase to *base* at first non-NaN obs
             - ``"roll"``      : rolling mean over *window* periods
             - ``"detrend"``   : subtract rolling mean over *window* periods
    window : lookback for ``yoy`` (default 12 = monthly YoY) or rolling ops
    base   : starting value for ``index`` / ``rebase`` (default 100)

    Returns
    -------
    pd.DataFrame  same shape / index as input, transformed.

    Examples
    --------
    >>> import algo_stat as a
    >>> cpi  = a.fred(["cpi","core_cpi"], years=10)
    >>> a.line(a.fred_transform(cpi, "yoy"), title="CPI YoY %")

    >>> # Compare M2 growth vs S&P 500 on the same chart
    >>> macro = a.fred(["m2","sp500"], years=20)
    >>> a.line(a.fred_transform(macro, "index"), title="M2 vs S&P 500 (rebased=100)")
    """
    import numpy as _np
    h = how.lower()
    if h == "yoy":
        return df.pct_change(window) * 100
    if h in ("mom", "pct"):
        return df.pct_change() * 100
    if h == "log":
        return _np.log(df)
    if h == "logdiff":
        return _np.log(df).diff()
    if h == "diff":
        return df.diff()
    if h == "zscore":
        return (df - df.mean()) / df.std(ddof=0)
    if h in ("index", "rebase", "normalize"):
        first = df.apply(lambda c: c.dropna().iloc[0] if c.dropna().size else _np.nan)
        return df.divide(first) * base
    if h == "roll":
        return df.rolling(window, min_periods=1).mean()
    if h == "detrend":
        return df - df.rolling(window, min_periods=1).mean()
    raise ValueError(
        f"Unknown transform {how!r}. "
        "Use one of: yoy, mom, pct, log, logdiff, diff, zscore, index, roll, detrend."
    )
