# © Squid Consultancy Group Ltd — All rights reserved.
# Unauthorised removal or modification of this notice is prohibited.
"""Alpha Vantage market data client for algo_stat.

══════════════════════════════════════════════════════════════════════════════
  © Squid Consultancy Group Ltd  |  algo-stat  |  All rights reserved.
══════════════════════════════════════════════════════════════════════════════

Get your free Alpha Vantage API key at:  https://www.alphavantage.co/support/#api-key

Quick start
───────────
  >>> from algo_stat.data.alphavantage import AlphaVantageClient
  >>> import algo_stat as a; a.use_dark()

  # ── Create client ──────────────────────────────────────────────────────
  >>> av = AlphaVantageClient(api_key="YOUR_KEY")
  >>> # or set ALPHA_VANTAGE_API_KEY=YOUR_KEY in .env and call AlphaVantageClient()

  # ── Equity — daily OHLCV ──────────────────────────────────────────────
  >>> ibm  = av.daily("IBM")                     # last 100 data points
  >>> nvda = av.daily("NVDA", full=True)          # full history
  >>> a.line(ibm, ticker="IBM")                   # works with all algo_stat charts
  >>> a.candle(nvda, ticker="NVDA")

  # ── Intraday (1min / 5min / 15min / 30min / 60min) ───────────────────
  >>> aapl5 = av.intraday("AAPL", interval="5min")
  >>> a.candle(aapl5, ticker="AAPL 5-min")

  # ── Foreign Exchange ──────────────────────────────────────────────────
  >>> eurusd = av.forex("EUR", "USD")
  >>> a.line(eurusd, ticker="EUR/USD")

  # ── Cryptocurrency ────────────────────────────────────────────────────
  >>> btc = av.crypto("BTC", market="USD")
  >>> a.candle(btc, ticker="BTC/USD")

  # ── Economic Indicator ────────────────────────────────────────────────
  >>> cpi   = av.economic("CPI")                  # monthly CPI
  >>> gdp   = av.economic("REAL_GDP")             # quarterly
  >>> unemp = av.economic("UNEMPLOYMENT")

  # ── Tech Indicators ───────────────────────────────────────────────────
  >>> rsi   = av.indicator("AAPL", "RSI",  interval="daily", period=14)
  >>> macd  = av.indicator("AAPL", "MACD", interval="daily")

  # ── Pipeline (connect nodes) ───────────────────────────────────────────
  >>> from algo_stat.data.adapter import align_series
  >>> (
  ...   av.economic("CPI")
  ...   .pipe(align_series, label="CPI")
  ...   .rename(columns={"CPI": "Close"})
  ...   .pipe(a.line, ticker="CPI (Alpha Vantage)")
  ... )

Output format (algo_stat standard)
────────────────────────────────────
  daily / intraday / forex / crypto
    → pd.DataFrame with DatetimeIndex + [Open, High, Low, Close, Volume]

  economic / indicator
    → pd.DataFrame with DatetimeIndex + one numeric column

  Use align_ohlcv() / align_series() from algo_stat.data.adapter if you
  have a custom Alpha Vantage response that needs normalisation.

Rate limits (free tier)
───────────────────────
  25 requests / day   |   5 requests / minute
  Premium plans: https://www.alphavantage.co/premium/

Available functions
───────────────────
  Method          AV function                  Description
  ─────────────── ──────────────────────────── ──────────────────────────────
  daily()         TIME_SERIES_DAILY_ADJUSTED   Equity OHLCV (split-adjusted)
  intraday()      TIME_SERIES_INTRADAY         Sub-daily OHLCV
  forex()         FX_DAILY                     FX OHLCV
  crypto()        DIGITAL_CURRENCY_DAILY       Crypto OHLCV
  economic()      Various                      GDP, CPI, Unemployment, etc.
  indicator()     Various                      RSI, MACD, BBANDS, EMA, etc.
  search()        SYMBOL_SEARCH                Find ticker symbols
"""
from __future__ import annotations

from typing import Literal
import pandas as pd

from algo_stat.config import settings

_BASE = "https://www.alphavantage.co/query"

# Economic indicator → AV function name
_ECONOMIC_MAP: dict[str, str] = {
    "real_gdp":        "REAL_GDP",
    "gdp":             "REAL_GDP",
    "cpi":             "CPI",
    "inflation":       "INFLATION",
    "unemployment":    "UNEMPLOYMENT",
    "nfp":             "NONFARM_PAYROLL",
    "fed_funds":       "FEDERAL_FUNDS_RATE",
    "30y_mortgage":    "REAL_GDP",       # not available separately
    "treasury_yield":  "TREASURY_YIELD",
    "retail_sales":    "RETAIL_SALES",
    "durables":        "DURABLES",
}


class AlphaVantageClient:
    """HTTP client for the Alpha Vantage REST API.

    Parameters
    ----------
    api_key : Alpha Vantage API key from https://www.alphavantage.co/support/#api-key
              Defaults to ``ALPHA_VANTAGE_API_KEY`` environment variable / .env file.

    Examples
    --------
    >>> from algo_stat.data.alphavantage import AlphaVantageClient
    >>> av = AlphaVantageClient(api_key="YOUR_KEY")
    >>> df = av.daily("IBM")
    >>> av.help()
    """

    source = "alpha_vantage"

    def __init__(self, api_key: str | None = None) -> None:
        self._key = api_key or settings.alpha_vantage_api_key
        if not self._key:
            raise ValueError(
                "Alpha Vantage API key required.\n"
                "Pass api_key= or set ALPHA_VANTAGE_API_KEY in .env\n"
                "Free key: https://www.alphavantage.co/support/#api-key"
            )

    # ── Equity ────────────────────────────────────────────────────────────

    def daily(self, symbol: str, *, full: bool = False) -> pd.DataFrame:
        """Daily adjusted OHLCV for an equity ticker.

        Parameters
        ----------
        symbol : e.g. ``"IBM"``, ``"NVDA"``, ``"TSLA"``
        full   : ``True`` → full 20-year history; ``False`` → latest 100 bars

        Returns
        -------
        pd.DataFrame with DatetimeIndex + [Open, High, Low, Close, Volume]

        Examples
        --------
        >>> av.daily("NVDA", full=True)
        """
        outputsize = "full" if full else "compact"
        data = self._get({
            "function":   "TIME_SERIES_DAILY_ADJUSTED",
            "symbol":     symbol,
            "outputsize": outputsize,
        })
        key = "Time Series (Daily)"
        return self._parse_ts(data, key, ticker=symbol)

    def intraday(
        self,
        symbol:   str,
        interval: Literal["1min", "5min", "15min", "30min", "60min"] = "5min",
        *,
        full:     bool = False,
    ) -> pd.DataFrame:
        """Intraday OHLCV for an equity ticker.

        Parameters
        ----------
        symbol   : ticker e.g. ``"AAPL"``
        interval : bar size — ``"1min" | "5min" | "15min" | "30min" | "60min"``
        full     : ``True`` → last 30 days of bars

        Examples
        --------
        >>> av.intraday("AAPL", interval="15min")
        """
        outputsize = "full" if full else "compact"
        data = self._get({
            "function":   "TIME_SERIES_INTRADAY",
            "symbol":     symbol,
            "interval":   interval,
            "outputsize": outputsize,
        })
        key = f"Time Series ({interval})"
        return self._parse_ts(data, key, ticker=symbol)

    # ── FX ────────────────────────────────────────────────────────────────

    def forex(self, from_ccy: str, to_ccy: str, *, full: bool = False) -> pd.DataFrame:
        """Daily FX OHLCV.

        Parameters
        ----------
        from_ccy : base currency  e.g. ``"EUR"``
        to_ccy   : quote currency e.g. ``"USD"``

        Examples
        --------
        >>> av.forex("GBP", "USD")
        """
        outputsize = "full" if full else "compact"
        data = self._get({
            "function":    "FX_DAILY",
            "from_symbol": from_ccy,
            "to_symbol":   to_ccy,
            "outputsize":  outputsize,
        })
        key    = "Time Series FX (Daily)"
        ticker = f"{from_ccy}/{to_ccy}"
        return self._parse_ts(data, key, ticker=ticker)

    # ── Crypto ────────────────────────────────────────────────────────────

    def crypto(self, symbol: str, market: str = "USD") -> pd.DataFrame:
        """Daily crypto OHLCV priced in *market* currency.

        Parameters
        ----------
        symbol : crypto ticker e.g. ``"BTC"``, ``"ETH"``
        market : quote currency e.g. ``"USD"``, ``"EUR"``

        Examples
        --------
        >>> av.crypto("ETH", market="USD")
        """
        data = self._get({
            "function": "DIGITAL_CURRENCY_DAILY",
            "symbol":   symbol,
            "market":   market,
        })
        key    = "Time Series (Digital Currency Daily)"
        ticker = f"{symbol}/{market}"
        raw    = data.get(key, {})

        mkt = market.lower()
        records: list[dict] = []
        for date_str, vals in raw.items():
            # AV uses "1a. open (USD)" style keys
            def _v(prefix: str) -> float | None:
                for k, v in vals.items():
                    if k.startswith(prefix):
                        try:
                            return float(v)
                        except (ValueError, TypeError):
                            return None
                return None

            records.append({
                "Date":   date_str,
                "Open":   _v("1a.") or _v("1."),
                "High":   _v("2a.") or _v("2."),
                "Low":    _v("3a.") or _v("3."),
                "Close":  _v("4a.") or _v("4."),
                "Volume": _v("5."),
            })

        df = pd.DataFrame(records)
        df["Date"] = pd.to_datetime(df["Date"])
        df = df.set_index("Date").sort_index()
        df = df.apply(pd.to_numeric, errors="coerce")
        df.attrs = {"ticker": ticker, "source": "alpha_vantage"}
        return df

    # ── Economic indicators ───────────────────────────────────────────────

    def economic(
        self,
        indicator: str,
        *,
        interval: str = "monthly",
        maturity: str = "10year",
    ) -> pd.DataFrame:
        """Fetch a US macroeconomic indicator.

        Parameters
        ----------
        indicator : ``"REAL_GDP"`` | ``"CPI"`` | ``"INFLATION"`` |
                    ``"UNEMPLOYMENT"`` | ``"NONFARM_PAYROLL"`` |
                    ``"FEDERAL_FUNDS_RATE"`` | ``"TREASURY_YIELD"`` |
                    ``"RETAIL_SALES"`` | ``"DURABLES"``
                    Or a shortcut: ``"gdp"``, ``"cpi"``, ``"fed_funds"``, etc.
        interval  : ``"annual" | "quarterly" | "monthly" | "daily"`` (varies by indicator)
        maturity  : for TREASURY_YIELD — ``"3month" | "2year" | "5year" | "10year" | "30year"``

        Examples
        --------
        >>> av.economic("CPI")
        >>> av.economic("REAL_GDP", interval="quarterly")
        >>> av.economic("TREASURY_YIELD", interval="daily", maturity="10year")
        """
        func = _ECONOMIC_MAP.get(indicator.lower(), indicator.upper())
        params: dict = {"function": func}
        if func == "TREASURY_YIELD":
            params["interval"] = interval
            params["maturity"] = maturity
        elif func in ("REAL_GDP",):
            params["interval"] = interval
        else:
            params["interval"] = interval

        data = self._get(params)
        rows = data.get("data", [])
        df   = pd.DataFrame(rows)
        if df.empty:
            return df
        df["date"]  = pd.to_datetime(df["date"])
        df["value"] = pd.to_numeric(df["value"], errors="coerce")
        df = df.set_index("date").rename(columns={"value": func}).sort_index()
        df.attrs = {"series": func, "source": "alpha_vantage"}
        return df

    # ── Technical indicators ──────────────────────────────────────────────

    def indicator(
        self,
        symbol:       str,
        function:     str,
        *,
        interval:     str = "daily",
        period:       int = 14,
        series_type:  str = "close",
    ) -> pd.DataFrame:
        """Fetch a technical indicator.

        Parameters
        ----------
        symbol      : equity ticker e.g. ``"AAPL"``
        function    : AV indicator name e.g. ``"RSI"``, ``"MACD"``, ``"EMA"``,
                      ``"SMA"``, ``"BBANDS"``, ``"STOCH"``
        interval    : ``"1min" | "5min" | ... | "daily" | "weekly" | "monthly"``
        period      : look-back window (used by RSI, SMA, EMA, etc.)
        series_type : ``"close" | "open" | "high" | "low"``

        Examples
        --------
        >>> av.indicator("AAPL", "RSI",   interval="daily", period=14)
        >>> av.indicator("AAPL", "MACD",  interval="daily")
        >>> av.indicator("AAPL", "BBANDS",interval="weekly", period=20)
        """
        params = {
            "function":    function.upper(),
            "symbol":      symbol,
            "interval":    interval,
            "time_period": period,
            "series_type": series_type,
        }
        data = self._get(params)
        key  = f"Technical Analysis: {function.upper()}"
        raw  = data.get(key, {})

        records = [{"Date": dt, **vals} for dt, vals in raw.items()]
        df = pd.DataFrame(records)
        if df.empty:
            return df
        df["Date"] = pd.to_datetime(df["Date"])
        df = df.set_index("Date").sort_index()
        df = df.apply(pd.to_numeric, errors="coerce")
        df.attrs = {"ticker": symbol, "indicator": function.upper(), "source": "alpha_vantage"}
        return df

    # ── Symbol search ─────────────────────────────────────────────────────

    def search(self, query: str) -> pd.DataFrame:
        """Search for ticker symbols matching *query*.

        >>> av.search("Tesla")
        """
        data = self._get({"function": "SYMBOL_SEARCH", "keywords": query})
        return pd.DataFrame(data.get("bestMatches", []))

    # ── Public help ───────────────────────────────────────────────────────

    @staticmethod
    def help() -> None:
        """Print the full Alpha Vantage integration guide."""
        print(__doc__)

    # ── Internals ─────────────────────────────────────────────────────────

    def _get(self, params: dict) -> dict:
        try:
            import requests
        except ImportError:
            raise ImportError("requests is required: pip install requests")
        full_params = {"apikey": self._key, **params}
        resp = requests.get(_BASE, params=full_params, timeout=30)
        resp.raise_for_status()
        data = resp.json()
        if "Error Message" in data:
            raise ValueError(f"Alpha Vantage error: {data['Error Message']}")
        if "Note" in data:
            raise RuntimeError(
                f"Alpha Vantage rate limit hit: {data['Note']}\n"
                "Free tier: 25 req/day, 5 req/min. See https://www.alphavantage.co/premium/"
            )
        if "Information" in data:
            raise RuntimeError(f"Alpha Vantage: {data['Information']}")
        return data

    @staticmethod
    def _parse_ts(data: dict, key: str, ticker: str) -> pd.DataFrame:
        """Parse a standard Alpha Vantage OHLCV time-series response."""
        raw = data.get(key, {})
        records: list[dict] = []
        for date_str, vals in raw.items():
            # Keys like "1. open", "2. high", ... or "1a. open (USD)"
            def _pick(prefix: str) -> float | None:
                for k, v in vals.items():
                    if k.lstrip("0123456789").lstrip(". ").lower().startswith(
                        prefix.lower()
                    ):
                        try:
                            return float(v)
                        except (ValueError, TypeError):
                            return None
                return None

            records.append({
                "Date":   date_str,
                "Open":   _pick("open"),
                "High":   _pick("high"),
                "Low":    _pick("low"),
                "Close":  _pick("adjusted close") or _pick("close"),
                "Volume": _pick("volume"),
            })

        df = pd.DataFrame(records)
        df["Date"] = pd.to_datetime(df["Date"])
        df = df.set_index("Date").sort_index()
        df = df.apply(pd.to_numeric, errors="coerce")
        df.attrs = {"ticker": ticker, "source": "alpha_vantage"}
        return df


# ── Module-level help callable ────────────────────────────────────────────────

def help() -> None:  # noqa: A001
    """Print the full Alpha Vantage integration guide."""
    print(__doc__)
