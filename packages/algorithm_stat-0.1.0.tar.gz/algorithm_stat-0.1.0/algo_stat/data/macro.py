# © Squid Consultancy Group Ltd — All rights reserved.
# Unauthorised removal or modification of this notice is prohibited.
from __future__ import annotations
from datetime import datetime, timedelta
import pandas as pd

from algo_stat.config import settings


def _pdr():
    """Lazy import — pandas-datareader breaks on Py3.12+ (distutils removed)
    unless the `setuptools` shim is available. Defer until the user calls fred()."""
    try:
        import pandas_datareader.data as pdr
    except ModuleNotFoundError as e:
        raise ImportError(
            "pandas-datareader is not importable in this environment "
            "(often a Python 3.12+ `distutils` issue). "
            "Try:  pip install setuptools pandas-datareader"
        ) from e
    return pdr

# Common FRED series shortcuts
SERIES = {
    "cpi":            "CPIAUCSL",
    "core_cpi":       "CPILFESL",
    "m2":             "M2SL",
    "fed_funds":      "FEDFUNDS",
    "unemployment":   "UNRATE",
    "gdp":            "GDP",
    "real_gdp":       "GDPC1",
    "10y_treasury":   "DGS10",
    "2y_treasury":    "DGS2",
    "30y_mortgage":   "MORTGAGE30US",
    "vix":            "VIXCLS",
    "sahm_rule":      "SAHMREALTIME",
    "debt_to_gdp":    "GFDEGDQ188S",
}


def fred(
    series: str | list[str],
    start: str | None = None,
    end: str | None = None,
    years: int = 10,
) -> pd.DataFrame:
    """Fetch FRED series. Accepts shortcut name(s) or raw FRED codes.

    >>> fred("cpi", years=5)
    >>> fred(["m2","fed_funds"])
    """
    if isinstance(series, str):
        codes = [SERIES.get(series.lower(), series)]
    else:
        codes = [SERIES.get(s.lower(), s) for s in series]

    end = end or datetime.today().strftime("%Y-%m-%d")
    start = start or (datetime.today() - timedelta(days=365 * years)).strftime("%Y-%m-%d")

    df = _pdr().DataReader(codes, "fred", start, end, api_key=settings.fred_api_key)
    return df
