# © Squid Consultancy Group Ltd — All rights reserved.
# Unauthorised removal or modification of this notice is prohibited.
"""Universal data adapter — normalise **any** third-party API response into the
algo_stat standard format so it plugs directly into every algo_stat function.

══════════════════════════════════════════════════════════════════════════════
  © Squid Consultancy Group Ltd  |  algo-stat  |  All rights reserved.
══════════════════════════════════════════════════════════════════════════════

Standard OHLCV format  (equity / crypto / FX)
─────────────────────────────────────────────
  Index   : DatetimeIndex, daily or finer, UTC-normalised
  Columns : Open, High, Low, Close, Volume  (float64; Volume optional)
  Attrs   : {"ticker": str, "source": str}

Standard Series format  (macro / economic)
───────────────────────────────────────────
  Index   : DatetimeIndex (any frequency)
  Column  : series label  (float64, NaN for missing / unreported periods)
  Attrs   : {"series": str, "source": str}

Quick start
───────────
  >>> from algo_stat.data.adapter import align_ohlcv, align_series
  >>> import algo_stat as a; a.use_dark()

  # ── 1. Align any OHLCV-like API response ───────────────────────────────
  >>> raw = my_broker_api.get_candles("ETH/USD")       # arbitrary DataFrame
  >>> df  = align_ohlcv(raw, close_col="close_price", date_col="ts")
  >>> a.line(df, ticker="ETH/USD")                     # works everywhere

  # ── 2. Align a single macro / series feed ──────────────────────────────
  >>> raw = pd.DataFrame({"date": [...], "value": [...]})
  >>> gdp = align_series(raw, value_col="value", date_col="date", label="GDP")
  >>> a.line(gdp.rename(columns={"GDP": "Close"}), ticker="GDP")

  # ── 3. Connect nodes (pipeline) ────────────────────────────────────────
  >>> from algo_stat.data.fred import FredClient
  >>> (
  ...   FredClient(api_key="YOUR_KEY").fetch("cpi")
  ...   .pipe(align_series, label="CPI")
  ...   .rename(columns={"CPI": "Close"})
  ...   .pipe(a.line, ticker="CPI")
  ... )

  # ── 4. Build your own adapter ───────────────────────────────────────────
  >>> class MyAPIAdapter:
  ...     source = "my_api"
  ...     def __init__(self, api_key): self.key = api_key
  ...     def fetch(self, identifier, **kw) -> pd.DataFrame:
  ...         raw = _my_api_call(identifier, self.key)
  ...         return align_ohlcv(raw, close_col="price")
  ...     def help(self): help_text()
"""
from __future__ import annotations

from typing import Protocol, runtime_checkable
import pandas as pd


# ── Protocol (structural typing — any class with .fetch() satisfies it) ──────

@runtime_checkable
class DataAdapter(Protocol):
    """Structural protocol every third-party source adapter must satisfy.

    Implement this to make any data source compatible with algo_stat:

        class MyAdapter:
            source = "my_source"

            def __init__(self, api_key: str): ...

            def fetch(self, identifier: str, **kwargs) -> pd.DataFrame:
                \"\"\"Return an algo_stat-compatible DataFrame.\"\"\"
                ...

            def help(self) -> None:
                \"\"\"Print usage instructions.\"\"\"
                ...
    """

    source: str

    def fetch(self, identifier: str, **kwargs) -> pd.DataFrame:  # noqa: D102
        """Return an algo_stat-compatible DataFrame."""
        ...

    def help(self) -> None:  # noqa: D102
        """Print usage instructions."""
        ...


# ── OHLCV normaliser ──────────────────────────────────────────────────────────

def align_ohlcv(
    df: pd.DataFrame,
    *,
    open_col:   str       = "open",
    high_col:   str       = "high",
    low_col:    str       = "low",
    close_col:  str       = "close",
    volume_col: str | None = "volume",
    date_col:   str | None = None,
    ticker:     str       = "unknown",
    source:     str       = "custom",
) -> pd.DataFrame:
    """Normalise any DataFrame into the algo_stat OHLCV standard.

    Parameters
    ----------
    df         : raw DataFrame from any API / broker / exchange
    open_col   : name of the open-price column in *df*
    high_col   : name of the high-price column in *df*
    low_col    : name of the low-price column in *df*
    close_col  : name of the close-price (or only price) column in *df*
    volume_col : name of the volume column; pass ``None`` if absent
    date_col   : column containing dates; ``None`` → use existing index
    ticker     : stored in ``df.attrs["ticker"]``
    source     : stored in ``df.attrs["source"]``

    Returns
    -------
    pd.DataFrame
        Columns ``[Open, High, Low, Close, Volume]`` with DatetimeIndex.
        Missing columns (e.g. no OHLC, only Close) are silently omitted.

    Examples
    --------
    >>> from algo_stat.data.adapter import align_ohlcv
    >>> import algo_stat as a
    >>> raw = some_api.get_prices("AAPL")
    >>> df  = align_ohlcv(raw, close_col="price", date_col="timestamp")
    >>> a.line(df, ticker="AAPL")
    >>> a.candle(df, ticker="AAPL")
    >>> a.backtest(df)
    """
    out = df.copy()

    # ── set DatetimeIndex ──────────────────────────────────────────────────
    if date_col and date_col in out.columns:
        out.index = pd.to_datetime(out[date_col], utc=False)
        out = out.drop(columns=[date_col])
    else:
        out.index = pd.to_datetime(out.index, utc=False)
    out.index.name = "Date"
    out = out.sort_index()

    # ── rename to canonical names ──────────────────────────────────────────
    rename: dict[str, str] = {}
    for src, dst in [
        (open_col,   "Open"),
        (high_col,   "High"),
        (low_col,    "Low"),
        (close_col,  "Close"),
    ]:
        if src in out.columns:
            rename[src] = dst
    if volume_col and volume_col in out.columns:
        rename[volume_col] = "Volume"
    out = out.rename(columns=rename)

    # ── keep only canonical columns, numeric ──────────────────────────────
    keep = [c for c in ["Open", "High", "Low", "Close", "Volume"] if c in out.columns]
    out  = out[keep].apply(pd.to_numeric, errors="coerce")

    out.attrs.update({"ticker": ticker, "source": source})
    return out


# ── Series normaliser (macro / single-value) ──────────────────────────────────

def align_series(
    df: pd.DataFrame,
    *,
    value_col: str       = "value",
    date_col:  str | None = None,
    label:     str | None = None,
    source:    str       = "custom",
) -> pd.DataFrame:
    """Normalise a single-series (macro / economic) DataFrame.

    Returns a DataFrame with DatetimeIndex and one numeric column named
    *label* (defaults to *value_col*).

    To use with algo_stat chart functions, rename the column to ``"Close"``:

        df.rename(columns={"GDP": "Close"})

    Parameters
    ----------
    df        : raw DataFrame with at least one numeric column
    value_col : name of the value column in *df*
    date_col  : date column name; ``None`` → use existing index
    label     : output column name (default: *value_col*)
    source    : stored in ``df.attrs["source"]``

    Examples
    --------
    >>> from algo_stat.data.adapter import align_series
    >>> import algo_stat as a
    >>> raw = pd.DataFrame({"date": ["2020-01-01", ...], "value": [21427, ...]})
    >>> gdp = align_series(raw, value_col="value", date_col="date", label="GDP")
    >>> a.line(gdp.rename(columns={"GDP": "Close"}), ticker="GDP")
    """
    out = df.copy()

    if date_col and date_col in out.columns:
        out.index = pd.to_datetime(out[date_col], utc=False)
        out = out.drop(columns=[date_col])
    else:
        out.index = pd.to_datetime(out.index, utc=False)
    out.index.name = "Date"
    out = out.sort_index()

    col_name = label or value_col
    if value_col in out.columns:
        out[col_name] = pd.to_numeric(out[value_col], errors="coerce")
        if col_name != value_col:
            out = out.drop(columns=[value_col])
    out = out[[col_name]]

    out.attrs.update({"series": col_name, "source": source})
    return out


# ── Public help ───────────────────────────────────────────────────────────────

def help_text() -> None:
    """Print full adapter usage guide."""
    print(__doc__)
