# © Squid Consultancy Group Ltd — All rights reserved.
# Unauthorised removal or modification of this notice is prohibited.
from __future__ import annotations
import math
from dataclasses import dataclass


def _norm_cdf(x: float) -> float:
    return 0.5 * (1 + math.erf(x / math.sqrt(2)))


@dataclass
class BSResult:
    call: float
    put:  float
    d1:   float
    d2:   float


def black_scholes(S: float, K: float, T: float, r: float, sigma: float,
                  q: float = 0.0) -> BSResult:
    """European option pricing via Black-Scholes-Merton.

    S sigma T in years, r/q annualized.
    """
    if T <= 0 or sigma <= 0:
        return BSResult(max(S - K, 0), max(K - S, 0), 0, 0)
    d1 = (math.log(S / K) + (r - q + 0.5 * sigma ** 2) * T) / (sigma * math.sqrt(T))
    d2 = d1 - sigma * math.sqrt(T)
    call = S * math.exp(-q * T) * _norm_cdf(d1) - K * math.exp(-r * T) * _norm_cdf(d2)
    put  = K * math.exp(-r * T) * _norm_cdf(-d2) - S * math.exp(-q * T) * _norm_cdf(-d1)
    return BSResult(call, put, d1, d2)
