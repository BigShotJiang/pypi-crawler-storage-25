# © Squid Consultancy Group Ltd — All rights reserved.
# Unauthorised removal or modification of this notice is prohibited.
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional
import numpy as np
import matplotlib.pyplot as plt

from algo_stat.data.market import fetch
from algo_stat.metrics.returns import log_returns, _close
from algo_stat.config import settings
from algo_stat.charts.theme import stamp_figure


@dataclass
class MonteCarlo:
    """Geometric Brownian Motion stock-path simulator.

    >>> mc = MonteCarlo("NVDA").simulate(n=1000, days=252)
    >>> mc.plot()
    >>> mc.summary()
    """
    ticker: str | None = None
    s0: float | None = None
    mu: float | None = None
    sigma: float | None = None
    period_lookup: str = "1y"
    paths: Optional[np.ndarray] = field(default=None, repr=False)

    def _calibrate(self) -> None:
        if self.s0 and self.mu is not None and self.sigma is not None:
            return
        if not self.ticker:
            raise ValueError("Provide either ticker or (s0, mu, sigma).")
        df = fetch(self.ticker, period=self.period_lookup)
        s = _close(df).dropna()
        lr = log_returns(df)
        self.s0    = float(s.iloc[-1])
        self.mu    = float(lr.mean() * settings.trading_days)
        self.sigma = float(lr.std() * np.sqrt(settings.trading_days))

    def simulate(self, n: int = 1000, days: int = 252, seed: int | None = 42) -> "MonteCarlo":
        self._calibrate()
        rng = np.random.default_rng(seed)
        dt = 1 / settings.trading_days
        shocks = rng.standard_normal((days, n))
        drift  = (self.mu - 0.5 * self.sigma ** 2) * dt
        diff   = self.sigma * np.sqrt(dt) * shocks
        log_paths = np.vstack([np.zeros((1, n)), np.cumsum(drift + diff, axis=0)])
        self.paths = self.s0 * np.exp(log_paths)
        return self

    def summary(self) -> dict:
        if self.paths is None:
            raise RuntimeError("Call .simulate() first.")
        end = self.paths[-1]
        return {
            "ticker":   self.ticker,
            "s0":       self.s0,
            "mu":       self.mu,
            "sigma":    self.sigma,
            "n_paths":  int(self.paths.shape[1]),
            "horizon":  int(self.paths.shape[0] - 1),
            "mean_end": float(end.mean()),
            "p05":      float(np.percentile(end, 5)),
            "p50":      float(np.percentile(end, 50)),
            "p95":      float(np.percentile(end, 95)),
            "prob_loss": float((end < self.s0).mean()),
        }

    def plot(self, max_paths: int = 200, title: str | None = None):
        from algo_stat.charts.theme import _style_axes, BG, CYAN, GREEN, RED, GOLD, PANEL_BG, BORDER, GRID_ALPHA
        import matplotlib.colors as mcolors
        import matplotlib.ticker as mticker

        if self.paths is None:
            self.simulate()

        fig = plt.figure(figsize=(16, 8), facecolor=BG)
        gs = fig.add_gridspec(1, 2, width_ratios=[3, 1], wspace=0.04,
                              left=0.07, right=0.97, top=0.90, bottom=0.10)
        ax_paths = fig.add_subplot(gs[0])
        ax_hist  = fig.add_subplot(gs[1])
        _style_axes(ax_paths, ax_hist)

        # ── path panel ────────────────────────────────────────────────
        n_draw = min(max_paths, self.paths.shape[1])
        sample = self.paths[:, :n_draw]
        days   = np.arange(sample.shape[0])

        # colour-fade by terminal value (low→red, high→green)
        ends     = sample[-1]
        lo, hi   = ends.min(), ends.max()
        norm_end = (ends - lo) / (hi - lo + 1e-9)
        cmap     = mcolors.LinearSegmentedColormap.from_list(
            "path_cmap", [RED, "#7B2FBE", CYAN, GREEN], N=256)

        for i in range(n_draw):
            c = cmap(norm_end[i])
            ax_paths.plot(days, sample[:, i], color=c, linewidth=0.5, alpha=0.25)

        # percentile bands
        p05 = np.percentile(self.paths, 5,  axis=1)
        p50 = np.percentile(self.paths, 50, axis=1)
        p95 = np.percentile(self.paths, 95, axis=1)

        ax_paths.fill_between(days, p05, p95, color=CYAN, alpha=0.08, linewidth=0)
        # glow on p50
        for lw, al in [(8, 0.05), (3, 0.20), (1.8, 1.0)]:
            ax_paths.plot(days, p50, color=GOLD, linewidth=lw, alpha=al)
        for lw, al in [(4, 0.12), (1.5, 1.0)]:
            ax_paths.plot(days, p05, color=RED,  linewidth=lw, alpha=al, linestyle="--")
            ax_paths.plot(days, p95, color=GREEN, linewidth=lw, alpha=al, linestyle="--")

        ax_paths.axhline(float(self.s0), color="#30363D", linewidth=1.2,
                          linestyle="--", alpha=0.7)
        ax_paths.set_xlabel("Trading day", color="#8B949E", fontsize=10, labelpad=8)
        ax_paths.set_ylabel("Price", color="#8B949E", fontsize=11, labelpad=10)
        ax_paths.legend(
            [plt.Line2D([0], [0], color=GOLD, lw=2),
             plt.Line2D([0], [0], color=GREEN, lw=1.4, linestyle="--"),
             plt.Line2D([0], [0], color=RED,   lw=1.4, linestyle="--")],
            ["P50 median", "P95 bull", "P05 bear"],
            loc="upper left", fontsize=9,
            facecolor=PANEL_BG, edgecolor=BORDER, framealpha=0.9,
            labelcolor="white",
        )

        # ── terminal histogram ─────────────────────────────────────────
        end_vals = self.paths[-1]
        counts, bin_edges = np.histogram(end_vals, bins=60)
        bin_centers = (bin_edges[:-1] + bin_edges[1:]) / 2
        bar_colors = [cmap((c - lo) / (hi - lo + 1e-9)) for c in bin_centers]

        ax_hist.barh(bin_centers, counts, height=(bin_edges[1] - bin_edges[0]) * 0.92,
                     color=bar_colors, alpha=0.88, zorder=3)
        ax_hist.axhline(float(self.s0), color="#30363D", linewidth=1.2,
                         linestyle="--", alpha=0.7)
        ax_hist.set_xlabel("Frequency", color="#8B949E", fontsize=9, labelpad=6)
        ax_hist.set_title("Terminal dist.", color="white", fontsize=11, pad=8)
        ax_hist.tick_params(labelleft=False)

        s = self.summary()
        badge = (f"n = {s['n_paths']:,}\n"
                 f"μ  = {s['mu']:.1%}\n"
                 f"σ  = {s['sigma']:.1%}\n"
                 f"P05 = {s['p05']:.2f}\n"
                 f"P50 = {s['p50']:.2f}\n"
                 f"P95 = {s['p95']:.2f}\n"
                 f"P(loss) = {s['prob_loss']:.1%}")
        ax_paths.text(0.99, 0.03, badge,
                      transform=ax_paths.transAxes, va="bottom", ha="right",
                      fontsize=9, color="white", fontfamily="monospace",
                      bbox=dict(boxstyle="round,pad=0.5", facecolor=PANEL_BG,
                                edgecolor=CYAN, linewidth=1, alpha=0.92))

        lbl = title or f"Monte Carlo  ·  {self.ticker or 'GBM'}  ·  {s['horizon']} days  ·  {s['n_paths']:,} paths"
        fig.suptitle(lbl, color="white", fontsize=16, fontweight="bold", x=0.52, y=0.97)
        stamp_figure(fig)
        plt.close(fig)
        return fig
