# © Squid Consultancy Group Ltd — All rights reserved.
# Unauthorised removal or modification of this notice is prohibited.
"""Derivatives: Monte Carlo simulations and option pricing."""
