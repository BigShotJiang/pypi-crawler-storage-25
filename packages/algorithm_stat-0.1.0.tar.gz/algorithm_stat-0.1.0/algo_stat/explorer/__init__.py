# © Squid Consultancy Group Ltd — All rights reserved.
# Unauthorised removal or modification of this notice is prohibited.
from algo_stat.explorer.explorer import DataExplorer, explore

__all__ = ["DataExplorer", "explore"]
