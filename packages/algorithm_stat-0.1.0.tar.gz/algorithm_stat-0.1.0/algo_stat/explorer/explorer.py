# (c) Squid Consultancy Group Ltd - All rights reserved.
"""
algo_stat.explorer.explorer
============================
Interactive DataFrame explorer for Jupyter notebooks (light theme).

Inspired by D-Tale (man-group/dtale, LGPL-2.1).
Re-built natively with ipywidgets, branded under Squid Consultancy Group Ltd.

Tabs
----
Grid . Describe . Summary . Column . Correlation . Charts .
Missing . Duplicates . Outliers . Time Series . Reshape . Query . Export
"""
from __future__ import annotations

import io, base64, math, html as _html_mod
import pandas as pd

try:
    import ipywidgets as W
    from IPython.display import display as _display, HTML as _HTML
    _OK = True
except ImportError:
    _OK = False

# --------------------------------------------------------------------------- #
# Light-theme palette                                                         #
# --------------------------------------------------------------------------- #
_BG    = "#FFFFFF"      # page background
_PNL   = "#F6F8FA"      # panels / toolbars
_PNL2  = "#EAEEF2"      # alt panel (table header etc.)
_BORD  = "#D0D7DE"      # borders
_BORD2 = "#E5E9EE"      # subtle borders
_TEXT  = "#1F2328"      # primary text
_DIM   = "#656D76"      # secondary text
_BLUE  = "#0969DA"      # primary accent
_GRN   = "#1A7F37"      # success
_RED   = "#CF222E"      # error
_GOLD  = "#9A6700"      # warning
_PURP  = "#8250DF"      # datetime
_ORNG  = "#BC4C00"      # other dtype
_HI    = "#FFF8C5"      # column highlight
_HIB   = "#E1F2FF"      # row hover

_NEON = [_BLUE, _GRN, _GOLD, _PURP, _ORNG, "#0550AE", "#CF222E",
         "#116329", "#953800", "#6639BA"]


def _dtype_color(dtype) -> str:
    s = str(dtype)
    if "int"       in s: return _BLUE
    if "float"     in s: return _GRN
    if "bool"      in s: return _GOLD
    if "datetime"  in s: return _PURP
    if "timedelta" in s: return _ORNG
    return _DIM


def _esc(v) -> str:
    return _html_mod.escape(str(v))


def _safe_isna(v) -> bool:
    try:
        return bool(pd.isna(v))
    except (TypeError, ValueError):
        return False


def _fmt_val(v, is_num: bool) -> tuple[str, str]:
    if _safe_isna(v):
        return "na", "NaN"
    s = str(v)
    if len(s) > 60:
        s = s[:57] + "..."
    return ("num", _esc(s)) if is_num else ("", _esc(s))


def _style_axes_light(ax):
    """Apply light-theme styling to a matplotlib axis."""
    ax.set_facecolor(_BG)
    for spine in ax.spines.values():
        spine.set_edgecolor(_BORD)
        spine.set_linewidth(0.8)
    ax.tick_params(colors=_DIM, labelsize=9)
    ax.grid(True, color=_BORD2, linestyle="--", linewidth=0.4, alpha=0.25)
    ax.set_axisbelow(True)


def _fig_to_png(fig) -> str:
    fig.patch.set_facecolor(_BG)
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=110, bbox_inches="tight",
                facecolor=_BG)
    buf.seek(0)
    return "data:image/png;base64," + base64.b64encode(buf.read()).decode()


def _grp(label: str, widget) -> W.VBox:
    return W.VBox(
        [W.HTML(f'<span style="color:{_DIM};font-size:10px;text-transform:uppercase;'
                f'letter-spacing:.08em;font-weight:600">{label}</span>'), widget],
        layout=W.Layout(gap="3px"),
    )


# --------------------------------------------------------------------------- #
# CSS - light theme                                                           #
# --------------------------------------------------------------------------- #
_CSS = """
<style>
.qs-dex {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Helvetica Neue", sans-serif;
    background: #FFFFFF;
    border: 1px solid #D0D7DE;
    border-radius: 10px;
    overflow: hidden;
    min-width: 760px;
    color: #1F2328;
}
.qs-dex-hdr {
    background: #F6F8FA;
    border-bottom: 1px solid #D0D7DE;
    padding: 10px 16px;
    display: flex; align-items: center; gap: 10px; flex-wrap: wrap;
}
.qs-dex-title {
    color: #1F2328; font-size: 13px; font-weight: 600; flex: 1;
    letter-spacing: .01em;
}
.qs-dex-badge {
    background: #FFFFFF; border: 1px solid #D0D7DE; border-radius: 12px;
    color: #656D76; font-size: 10px; padding: 2px 8px; font-weight: 500;
}
.qs-dex-badge.brand     { color: #0969DA; border-color: #B6E3FF; background: #DDF4FF; }
.qs-dex-badge.brand-dim { color: #8C959F; }

.qs-dex .p-TabBar              { background: #F6F8FA !important; border-bottom: 1px solid #D0D7DE !important; }
.qs-dex .p-TabBar-tab          { color: #656D76 !important; background: transparent !important; border: none !important; padding: 9px 14px !important; font-size: 12px !important; font-weight: 500 !important; }
.qs-dex .p-TabBar-tab:hover    { color: #1F2328 !important; background: #EAEEF2 !important; }
.qs-dex .p-TabBar-tab.p-mod-current { color: #0969DA !important; background: #FFFFFF !important; border-bottom: 2px solid #0969DA !important; }

.qs-tbl-wrap { overflow: auto; max-height: 440px; background: #FFFFFF; }
.qs-tbl { width: 100%; border-collapse: collapse; font-size: 12px; color: #1F2328; }
.qs-tbl thead tr { position: sticky; top: 0; z-index: 2; }
.qs-tbl thead th {
    background: #F6F8FA; font-weight: 600; padding: 7px 12px;
    border-bottom: 1px solid #D0D7DE; border-right: 1px solid #E5E9EE;
    white-space: nowrap; text-align: left; color: #1F2328;
}
.qs-tbl thead th .dt { display: block; font-size: 9px; font-weight: 400; margin-top: 2px; opacity: .85; }
.qs-tbl tbody tr:nth-child(even) { background: #FAFBFC; }
.qs-tbl tbody tr:nth-child(odd)  { background: #FFFFFF; }
.qs-tbl tbody tr:hover            { background: #DDF4FF; }
.qs-tbl td {
    padding: 4px 12px; border-right: 1px solid #EAEEF2; border-bottom: 1px solid #EAEEF2;
    max-width: 220px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.qs-tbl .idx { color: #8C959F; font-size: 10px; min-width: 40px; }
.qs-tbl .na  { color: #CF222E; font-style: italic; }
.qs-tbl .num { text-align: right; font-variant-numeric: tabular-nums; color: #0550AE; }
.qs-tbl .out { background: #FFEBE9; color: #CF222E; font-weight: 600; }
.qs-tbl .hi  { background: #FFF8C5; }
.qs-tbl .dup { background: #FFF1B8; }

.qs-pg-info { color: #656D76; font-size: 11px; }

.qs-dc-wrap { display: flex; flex-wrap: wrap; gap: 10px; padding: 12px; background: #FFFFFF; overflow-y: auto; max-height: 540px; }
.qs-dc {
    background: #F6F8FA; border: 1px solid #D0D7DE; border-radius: 8px;
    padding: 10px 12px; min-width: 200px; max-width: 240px; flex: 1;
    transition: border-color .12s, background .12s;
}
.qs-dc:hover { border-color: #0969DA; background: #FFFFFF; }
.qs-dc-name { color: #1F2328; font-weight: 600; font-size: 12px; margin-bottom: 6px; padding-bottom: 5px; border-bottom: 1px solid #D0D7DE; }
.qs-dc-row  { display: flex; justify-content: space-between; font-size: 11px; padding: 2px 0; }
.qs-dc-lbl  { color: #656D76; }
.qs-dc-val  { color: #1F2328; font-variant-numeric: tabular-nums; }

.qs-sum-grid { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px; padding: 14px; background: #FFFFFF; }
.qs-sum-card { background: #F6F8FA; border: 1px solid #D0D7DE; border-radius: 8px; padding: 12px 14px; }
.qs-sum-ttl  { color: #656D76; font-size: 10px; text-transform: uppercase; letter-spacing: .08em; margin-bottom: 4px; font-weight: 600; }
.qs-sum-val  { color: #0969DA; font-size: 22px; font-weight: 700; }
.qs-sum-sub  { color: #656D76; font-size: 11px; margin-top: 2px; }

.qs-mb-wrap { background: #FFFFFF; border: 1px solid #D0D7DE; border-radius: 8px; overflow: hidden; }
.qs-mb-row  { display: flex; align-items: center; gap: 8px; padding: 4px 12px; border-bottom: 1px solid #EAEEF2; font-size: 11px; }
.qs-mb-col  { color: #1F2328; min-width: 140px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-weight: 500; }
.qs-mb-bg   { flex: 1; background: #EAEEF2; border-radius: 3px; height: 6px; }
.qs-mb-bar  { height: 6px; border-radius: 3px; }
.qs-mb-pct  { color: #656D76; min-width: 48px; text-align: right; font-variant-numeric: tabular-nums; }

/* Buttons */
.qs-act button {
    background: #0969DA !important; border: 1px solid #0969DA !important; color: #FFFFFF !important;
    border-radius: 6px !important; font-size: 12px !important; font-weight: 500 !important;
    padding: 5px 14px !important; cursor: pointer !important; box-shadow: 0 1px 0 rgba(31,35,40,.04) !important;
}
.qs-act button:hover { background: #0860C7 !important; }
.qs-sm button {
    background: #F6F8FA !important; border: 1px solid #D0D7DE !important;
    color: #1F2328 !important; border-radius: 6px !important; font-size: 11px !important;
    padding: 3px 12px !important;
}
.qs-sm button:hover { background: #FFFFFF !important; border-color: #0969DA !important; color: #0969DA !important; }
.qs-warn button {
    background: #FFFFFF !important; border: 1px solid #D0D7DE !important;
    color: #CF222E !important; border-radius: 6px !important; font-size: 11px !important;
    padding: 3px 12px !important;
}
.qs-warn button:hover { background: #FFEBE9 !important; border-color: #CF222E !important; }

/* Inputs */
.qs-dex .widget-text input, .qs-dex .widget-dropdown select,
.qs-dex .widget-inttext input, .qs-dex .widget-floattext input,
.qs-dex .widget-textarea textarea, .qs-dex .widget-combobox input {
    background: #FFFFFF !important; border: 1px solid #D0D7DE !important;
    border-radius: 6px !important; color: #1F2328 !important;
    font-size: 12px !important; padding: 4px 8px !important;
    box-shadow: inset 0 1px 0 rgba(31,35,40,.04) !important;
}
.qs-dex .widget-text input:focus, .qs-dex .widget-dropdown select:focus,
.qs-dex .widget-textarea textarea:focus {
    border-color: #0969DA !important; outline: none !important;
    box-shadow: 0 0 0 3px rgba(9,105,218,.2) !important;
}
.qs-dex .jupyter-widgets-output-area { background: transparent !important; }
.qs-dex .widget-label { color: #656D76 !important; }

.qs-codeblk {
    background: #F6F8FA; border: 1px solid #D0D7DE; border-radius: 6px;
    padding: 12px; color: #1F2328; font-family: ui-monospace, SFMono-Regular, "SF Mono", monospace;
    font-size: 11px; white-space: pre; overflow-x: auto; line-height: 1.55;
}
.qs-codeblk .kw { color: #CF222E; }
.qs-codeblk .st { color: #0A3069; }
.qs-codeblk .nm { color: #0550AE; }
.qs-codeblk .cm { color: #6E7781; font-style: italic; }

.qs-section-ttl { color: #1F2328; font-size: 12px; font-weight: 600; margin: 10px 0 6px; }
</style>
"""


# --------------------------------------------------------------------------- #
# HTML generators                                                             #
# --------------------------------------------------------------------------- #

def _render_table(df: pd.DataFrame, page: int, ps: int,
                  sort_col: str | None = None, sort_asc: bool = True,
                  highlight: str = "none",
                  outlier_set: set | None = None,
                  hi_col: str | None = None,
                  dup_set: set | None = None) -> str:
    total = len(df)
    if total == 0:
        return ('<div class="qs-tbl-wrap" style="padding:30px;text-align:center;'
                f'color:{_DIM};font-size:12px">No rows match current view.</div>')

    start = page * ps
    end   = min(start + ps, total)
    chunk = df.iloc[start:end]
    num_set = set(df.select_dtypes(include="number").columns)

    th = '<th class="idx">#</th>'
    for col in chunk.columns:
        dc = _dtype_color(df[col].dtype)
        arrow = ""
        if sort_col == str(col):
            arrow = " &uarr;" if sort_asc else " &darr;"
        th += (
            f'<th title="{_esc(col)}">{_esc(str(col)[:24])}{arrow}'
            f'<span class="dt" style="color:{dc}">{df[col].dtype}</span></th>'
        )

    rows = []
    for idx_val, row in chunk.iterrows():
        row_extra = ""
        if dup_set is not None and idx_val in dup_set:
            row_extra = ' style="background:#FFF1B8"'
        cells = f'<td class="idx">{_esc(str(idx_val)[:18])}</td>'
        for col in chunk.columns:
            v = row[col]
            cls, disp = _fmt_val(v, col in num_set)
            extra = ""
            if highlight == "missing" and _safe_isna(v):
                extra = " na"
            elif highlight == "outliers" and outlier_set and (idx_val, col) in outlier_set:
                extra = " out"
            elif highlight == "column" and hi_col == str(col):
                extra = " hi"
            full = (cls + extra).strip()
            attr = f' class="{full}"' if full else ""
            cells += f"<td{attr}>{disp}</td>"
        rows.append(f"<tr{row_extra}>{cells}</tr>")

    return (
        '<div class="qs-tbl-wrap"><table class="qs-tbl">'
        f"<thead><tr>{th}</tr></thead>"
        f"<tbody>{''.join(rows)}</tbody>"
        "</table></div>"
    )


def _describe_html(df: pd.DataFrame) -> str:
    total = len(df)
    cards = []
    for col in df.columns:
        s   = df[col]
        dc  = _dtype_color(s.dtype)
        nc  = int(s.isna().sum())
        pct = nc / total * 100 if total else 0.0
        clr = _RED if pct > 5 else _GOLD if pct > 0 else _GRN
        rows: list[tuple[str, str]] = [
            ("Count", f"{total - nc:,}"),
            ("Null",  f'<span style="color:{clr}">{nc:,} ({pct:.1f}%)</span>'),
        ]
        if pd.api.types.is_numeric_dtype(s):
            d = s.dropna()
            if len(d):
                rows += [
                    ("Min",  f"{d.min():,.4g}"),
                    ("Max",  f"{d.max():,.4g}"),
                    ("Mean", f'<span style="color:{_BLUE}">{d.mean():,.4g}</span>'),
                    ("Std",  f"{d.std():,.4g}"),
                    ("25%",  f"{d.quantile(.25):,.4g}"),
                    ("50%",  f"{d.quantile(.50):,.4g}"),
                    ("75%",  f"{d.quantile(.75):,.4g}"),
                    ("Skew", f"{d.skew():,.3f}"),
                    ("Kurt", f"{d.kurt():,.3f}"),
                ]
        elif pd.api.types.is_datetime64_any_dtype(s):
            d = s.dropna()
            if len(d):
                rows += [
                    ("Min",    str(d.min())[:19]),
                    ("Max",    str(d.max())[:19]),
                    ("Unique", f"{d.nunique():,}"),
                ]
        else:
            d = s.dropna()
            rows.append(("Unique", f'<span style="color:{_BLUE}">{d.nunique():,}</span>'))
            for val, cnt in d.value_counts().head(3).items():
                rows.append((f'"{_esc(str(val)[:10])}"', f"{cnt:,}"))

        body = "".join(
            f'<div class="qs-dc-row"><span class="qs-dc-lbl">{_esc(str(l))}</span>'
            f'<span class="qs-dc-val">{v}</span></div>' for l, v in rows
        )
        cards.append(
            f'<div class="qs-dc"><div class="qs-dc-name">{_esc(str(col)[:24])}'
            f'<span style="float:right;font-size:9px;color:{dc};'
            f'background:#FFFFFF;border:1px solid {_BORD};border-radius:10px;'
            f'padding:1px 6px">{s.dtype}</span></div>{body}</div>'
        )
    return f'<div class="qs-dc-wrap">{"".join(cards)}</div>'


def _summary_html(df: pd.DataFrame) -> str:
    mem      = df.memory_usage(deep=True).sum()
    mem_str  = f"{mem/1024:.1f} KB" if mem < 1_048_576 else f"{mem/1_048_576:.2f} MB"
    dups     = int(df.duplicated().sum())
    nulls    = int(df.isna().sum().sum())
    total    = len(df) * len(df.columns)
    complete = f"{100 * (1 - nulls / total):.1f}%" if total else "N/A"

    n_num = len(df.select_dtypes(include="number").columns)
    n_obj = len(df.select_dtypes(include="object").columns)
    n_dt  = len(df.select_dtypes(include="datetime").columns)

    dtypes_html = " &nbsp;&middot;&nbsp; ".join(
        f'<span style="color:{_dtype_color(dt)}">{cnt} x {dt}</span>'
        for dt, cnt in df.dtypes.value_counts().items()
    )
    cols_preview = " &nbsp;".join(
        f'<span style="color:{_BLUE};font-size:11px">{_esc(str(c)[:18])}</span>'
        for c in df.columns[:24]
    ) + ("..." if len(df.columns) > 24 else "")

    return f"""<div class="qs-sum-grid">
    <div class="qs-sum-card"><div class="qs-sum-ttl">Rows</div>
        <div class="qs-sum-val">{len(df):,}</div></div>
    <div class="qs-sum-card"><div class="qs-sum-ttl">Columns</div>
        <div class="qs-sum-val">{len(df.columns):,}</div>
        <div class="qs-sum-sub">{n_num} numeric &middot; {n_obj} text &middot; {n_dt} datetime</div></div>
    <div class="qs-sum-card"><div class="qs-sum-ttl">Memory usage</div>
        <div class="qs-sum-val">{mem_str}</div></div>
    <div class="qs-sum-card"><div class="qs-sum-ttl">Duplicate rows</div>
        <div class="qs-sum-val" style="color:{_RED if dups else _GRN}">{dups:,}</div></div>
    <div class="qs-sum-card"><div class="qs-sum-ttl">Total NaN cells</div>
        <div class="qs-sum-val" style="color:{_RED if nulls else _GRN}">{nulls:,}</div></div>
    <div class="qs-sum-card"><div class="qs-sum-ttl">Data completeness</div>
        <div class="qs-sum-val">{complete}</div></div>
    <div class="qs-sum-card" style="grid-column:span 3">
        <div class="qs-sum-ttl">Column dtypes</div>
        <div style="padding-top:5px;font-size:12px;line-height:1.8">{dtypes_html}</div></div>
    <div class="qs-sum-card" style="grid-column:span 3">
        <div class="qs-sum-ttl">Columns ({len(df.columns)})</div>
        <div style="padding-top:5px;line-height:2;word-break:break-all">{cols_preview}</div></div>
</div>"""


def _missing_html(df: pd.DataFrame) -> str:
    total  = len(df)
    counts = df.isna().sum()
    rows = []
    for col in df.columns:
        nc  = int(counts[col])
        pct = nc / total * 100 if total else 0.0
        clr = _RED if pct > 10 else _GOLD if pct > 0 else _GRN
        bar = (f'<div class="qs-mb-bar" style="width:{pct:.2f}%;background:{clr}"></div>'
               if pct > 0 else "")
        rows.append(
            f'<div class="qs-mb-row">'
            f'<span class="qs-mb-col" title="{_esc(col)}">{_esc(str(col)[:22])}</span>'
            f'<div class="qs-mb-bg">{bar}</div>'
            f'<span class="qs-mb-pct">{pct:.1f}%</span></div>'
        )
    miss_cols = int((counts > 0).sum())
    return (
        f'<div style="color:{_DIM};font-size:11px;padding:10px 12px 8px">'
        f'{miss_cols} / {len(df.columns)} columns have missing values &middot; '
        f'{int(counts.sum()):,} total NaN cells</div>'
        f'<div class="qs-mb-wrap">{"".join(rows)}</div>'
    )


# --------------------------------------------------------------------------- #
# DataExplorer                                                                #
# --------------------------------------------------------------------------- #

class DataExplorer:
    """Interactive DataFrame explorer for Jupyter (light theme)."""

    def __init__(self, df: pd.DataFrame, name: str = "DataFrame"):
        if not _OK:
            raise ImportError("ipywidgets required:  pip install ipywidgets")
        if not isinstance(df, pd.DataFrame):
            raise TypeError(f"Expected pandas DataFrame, got {type(df).__name__}")

        self._df_orig  = df
        self._name     = name
        self._page     = 0
        self._ps       = 20
        self._sort_col: str | None = None
        self._sort_asc = True
        self._search   = ""
        self._filters: list[dict] = []
        self._hl_mode  = "none"
        self._hl_col: str | None = None
        self._df       = df

        self._grid_out   = W.Output(layout=W.Layout(overflow="auto"))
        self._info_lbl   = W.HTML("")
        self._filter_box = W.VBox([])

    # ---------- pipeline ---------- #
    def _outlier_index(self, df: pd.DataFrame) -> set:
        out = set()
        for col in df.select_dtypes(include="number").columns:
            s = df[col].dropna()
            if len(s) < 5:
                continue
            mu, sd = s.mean(), s.std()
            if sd == 0 or pd.isna(sd):
                continue
            lo, hi = mu - 3 * sd, mu + 3 * sd
            mask = (df[col] < lo) | (df[col] > hi)
            for i in df.index[mask.fillna(False)]:
                out.add((i, col))
        return out

    def _n_pages(self) -> int:
        return max(1, math.ceil(len(self._df) / self._ps))

    def _apply_filter(self, df: pd.DataFrame, f: dict) -> pd.DataFrame:
        col, op, val = f.get("col"), f.get("op"), f.get("val", "")
        if col not in df.columns:
            return df
        s = df[col]
        try:
            if op == "is null":  return df[s.isna()]
            if op == "not null": return df[s.notna()]
            if pd.api.types.is_numeric_dtype(s):
                v = float(val)
                if op == "==": return df[s == v]
                if op == "!=": return df[s != v]
                if op == ">":  return df[s > v]
                if op == ">=": return df[s >= v]
                if op == "<":  return df[s < v]
                if op == "<=": return df[s <= v]
            else:
                if op == "==":         return df[s.astype(str) == str(val)]
                if op == "!=":         return df[s.astype(str) != str(val)]
                if op == "contains":   return df[s.astype(str).str.contains(str(val), case=False, na=False, regex=False)]
                if op == "startswith": return df[s.astype(str).str.startswith(str(val), na=False)]
        except Exception:
            return df
        return df

    def _apply(self) -> None:
        df = self._df_orig
        for f in self._filters:
            df = self._apply_filter(df, f)
        q = self._search.strip()
        if q:
            mask = pd.Series(False, index=df.index)
            for col in df.columns:
                try:
                    mask |= df[col].astype(str).str.contains(q, case=False, na=False, regex=False)
                except Exception:
                    pass
            df = df[mask]
        if self._sort_col and self._sort_col in df.columns:
            try:
                df = df.sort_values(self._sort_col, ascending=self._sort_asc)
            except Exception:
                pass
        self._df = df
        self._page = 0
        self._refresh_grid()

    def _refresh_grid(self) -> None:
        n  = len(self._df)
        pg = self._n_pages()
        flt = f" (filtered from {len(self._df_orig):,})" if n != len(self._df_orig) else ""
        self._info_lbl.value = (
            f'<span class="qs-pg-info">{n:,} rows{flt} &middot; '
            f'Page {self._page + 1} / {pg}</span>'
        )
        out_set = self._outlier_index(self._df) if self._hl_mode == "outliers" else None
        with self._grid_out:
            self._grid_out.clear_output(wait=True)
            _display(_HTML(_render_table(
                self._df, self._page, self._ps, self._sort_col, self._sort_asc,
                highlight=self._hl_mode, outlier_set=out_set, hi_col=self._hl_col,
            )))

    # ---------- filters ---------- #
    def _render_filters(self) -> None:
        rows = []
        cols = [str(c) for c in self._df_orig.columns]
        for i, f in enumerate(self._filters):
            col_w = W.Dropdown(options=cols, value=f["col"], layout=W.Layout(width="150px"))
            if pd.api.types.is_numeric_dtype(self._df_orig[f["col"]]):
                op_opts = ["==", "!=", ">", ">=", "<", "<=", "is null", "not null"]
            else:
                op_opts = ["==", "!=", "contains", "startswith", "is null", "not null"]
            op_w  = W.Dropdown(options=op_opts,
                               value=f["op"] if f["op"] in op_opts else op_opts[0],
                               layout=W.Layout(width="120px"))
            val_w = W.Text(value=str(f.get("val", "")),
                           placeholder="value", layout=W.Layout(width="180px"),
                           continuous_update=False)
            rm    = W.Button(description="Remove", layout=W.Layout(width="80px", height="28px"))
            rm.add_class("qs-warn")

            def _mk(idx, key):
                def _h(ch):
                    self._filters[idx][key] = ch["new"]
                    if key == "col":
                        self._render_filters()
                    self._apply()
                return _h
            col_w.observe(_mk(i, "col"), "value")
            op_w.observe(_mk(i, "op"), "value")
            val_w.observe(_mk(i, "val"), "value")

            def _mk_remove(idx):
                def _r(_b):
                    self._filters.pop(idx)
                    self._render_filters(); self._apply()
                return _r
            rm.on_click(_mk_remove(i))
            rows.append(W.HBox([col_w, op_w, val_w, rm],
                               layout=W.Layout(gap="6px", padding="2px 12px")))
        self._filter_box.children = tuple(rows)

    def _add_filter(self, _b=None) -> None:
        if not self._df_orig.columns.size:
            return
        first = str(self._df_orig.columns[0])
        op = "==" if pd.api.types.is_numeric_dtype(self._df_orig[first]) else "contains"
        self._filters.append({"col": first, "op": op, "val": ""})
        self._render_filters(); self._apply()

    # ---------- tab: GRID ---------- #
    def _tab_grid(self) -> W.VBox:
        col_opts = ["-- none --"] + [str(c) for c in self._df_orig.columns]

        srch = W.Text(placeholder="Search all columns",
                      continuous_update=False, layout=W.Layout(width="200px"))
        scol = W.Dropdown(options=col_opts, value="-- none --", layout=W.Layout(width="150px"))
        sdir = W.ToggleButton(value=True, description="Asc",
                              layout=W.Layout(width="70px", height="30px"))
        ps_w = W.Dropdown(options=[10, 20, 50, 100, 200], value=20, layout=W.Layout(width="80px"))
        hl_w = W.Dropdown(options=[("None", "none"), ("Missing", "missing"),
                                   ("Outliers (3 sigma)", "outliers"), ("Column", "column")],
                          value="none", layout=W.Layout(width="150px"))
        hlc_w = W.Dropdown(options=col_opts, value="-- none --", layout=W.Layout(width="150px"))

        prev_b = W.Button(description="Prev", layout=W.Layout(width="60px", height="28px"))
        next_b = W.Button(description="Next", layout=W.Layout(width="60px", height="28px"))
        for b in (prev_b, next_b): b.add_class("qs-sm")

        add_filter = W.Button(description="Add filter",
                              layout=W.Layout(width="110px", height="30px"))
        add_filter.add_class("qs-act")
        add_filter.on_click(self._add_filter)

        def _on_search(ch): self._search = ch["new"]; self._apply()
        def _on_scol(ch):
            v = ch["new"]; self._sort_col = None if v == "-- none --" else v; self._apply()
        def _on_sdir(ch):
            self._sort_asc = ch["new"]
            sdir.description = "Asc" if ch["new"] else "Desc"
            self._apply()
        def _on_ps(ch):  self._ps = ch["new"]; self._page = 0; self._refresh_grid()
        def _on_hl(ch):  self._hl_mode = ch["new"]; self._refresh_grid()
        def _on_hlc(ch):
            v = ch["new"]; self._hl_col = None if v == "-- none --" else v; self._refresh_grid()
        def _prev(_):
            if self._page > 0: self._page -= 1; self._refresh_grid()
        def _next(_):
            if self._page < self._n_pages() - 1: self._page += 1; self._refresh_grid()

        srch.observe(_on_search, "value");  scol.observe(_on_scol, "value")
        sdir.observe(_on_sdir, "value");    ps_w.observe(_on_ps, "value")
        hl_w.observe(_on_hl, "value");      hlc_w.observe(_on_hlc, "value")
        prev_b.on_click(_prev);             next_b.on_click(_next)

        toolbar = W.HBox(
            [_grp("Search", srch), _grp("Sort col", scol), _grp("Dir", sdir),
             _grp("Rows/pg", ps_w), _grp("Highlight", hl_w), _grp("Column", hlc_w),
             _grp(" ", add_filter)],
            layout=W.Layout(padding="10px 12px", background_color=_PNL,
                            border_bottom=f"1px solid {_BORD}",
                            flex_wrap="wrap", gap="12px"),
        )
        filter_hdr = W.HTML(
            f'<div style="color:{_DIM};font-size:10px;text-transform:uppercase;'
            f'letter-spacing:.08em;font-weight:600;padding:8px 12px 0">Active filters</div>'
        )
        footer = W.HBox(
            [self._info_lbl, W.HTML(""), prev_b, next_b],
            layout=W.Layout(padding="6px 12px", background_color=_PNL,
                            border_top=f"1px solid {_BORD}",
                            justify_content="space-between", align_items="center"),
        )
        return W.VBox(
            [toolbar, filter_hdr, self._filter_box, self._grid_out, footer],
            layout=W.Layout(background_color=_BG),
        )

    # ---------- simple HTML tabs ---------- #
    def _tab_describe(self) -> W.Widget:
        return W.HTML(_describe_html(self._df_orig),
                      layout=W.Layout(overflow_y="auto", max_height="560px"))

    def _tab_summary(self) -> W.Widget:
        return W.HTML(_summary_html(self._df_orig),
                      layout=W.Layout(overflow_y="auto"))

    def _tab_missing(self) -> W.Widget:
        return W.HTML(
            f'<div style="padding:12px;background:{_BG}">' + _missing_html(self._df_orig) + "</div>",
            layout=W.Layout(overflow_y="auto", max_height="560px"),
        )

    # ---------- tab: COLUMN ANALYSIS ---------- #
    def _tab_col_analysis(self) -> W.VBox:
        cols   = [str(c) for c in self._df_orig.columns]
        col_w  = W.Dropdown(options=cols, value=cols[0] if cols else "",
                            layout=W.Layout(width="180px"))
        kind_w = W.Dropdown(options=["Histogram", "Value counts", "Box plot", "QQ plot", "KDE"],
                            value="Histogram", layout=W.Layout(width="150px"))
        bins_w = W.IntSlider(value=40, min=5, max=120, step=5,
                             continuous_update=False, layout=W.Layout(width="220px"),
                             description="")
        out    = W.Output()
        status = W.HTML("")
        btn    = W.Button(description="Render", layout=W.Layout(width="100px", height="32px"))
        btn.add_class("qs-act")

        def _render(_b=None):
            import matplotlib.pyplot as plt
            out.clear_output(wait=True)
            try:
                col, kind = col_w.value, kind_w.value
                s = self._df_orig[col]
                fig, ax = plt.subplots(figsize=(10, 4.2))
                _style_axes_light(ax)

                if kind == "Histogram":
                    if not pd.api.types.is_numeric_dtype(s):
                        raise ValueError("Histogram requires numeric column")
                    d = s.dropna()
                    ax.hist(d, bins=bins_w.value, color=_BLUE, alpha=0.85, linewidth=0)
                    ax.axvline(d.mean(),   color=_GOLD, linestyle="--", linewidth=1, label=f"mean={d.mean():.3g}")
                    ax.axvline(d.median(), color=_GRN,  linestyle="--", linewidth=1, label=f"median={d.median():.3g}")
                    ax.legend(facecolor=_PNL, edgecolor=_BORD, labelcolor=_TEXT, fontsize=9)
                    ax.set_xlabel(col, color=_DIM); ax.set_ylabel("Count", color=_DIM)
                elif kind == "Value counts":
                    vc = s.value_counts().head(20)
                    colors = [_NEON[i % len(_NEON)] for i in range(len(vc))]
                    ax.barh([str(x)[:18] for x in vc.index], vc.values, color=colors, alpha=0.9)
                    ax.invert_yaxis(); ax.set_xlabel("Count", color=_DIM)
                elif kind == "Box plot":
                    if not pd.api.types.is_numeric_dtype(s):
                        raise ValueError("Box plot requires numeric column")
                    ax.boxplot(s.dropna(), patch_artist=True, vert=False,
                               medianprops=dict(color=_GOLD, linewidth=2),
                               boxprops=dict(facecolor=_BLUE + "22", edgecolor=_BLUE),
                               whiskerprops=dict(color=_BLUE),
                               flierprops=dict(markerfacecolor=_RED, markeredgecolor=_RED,
                                               marker="o", markersize=4))
                    ax.set_xlabel(col, color=_DIM); ax.set_yticks([])
                elif kind == "KDE":
                    if not pd.api.types.is_numeric_dtype(s):
                        raise ValueError("KDE requires numeric column")
                    from scipy.stats import gaussian_kde
                    d = s.dropna().values
                    kde = gaussian_kde(d)
                    xs  = pd.np.linspace(d.min(), d.max(), 200) if hasattr(pd, "np") \
                          else __import__("numpy").linspace(d.min(), d.max(), 200)
                    ys = kde(xs)
                    ax.fill_between(xs, ys, color=_BLUE, alpha=0.25)
                    ax.plot(xs, ys, color=_BLUE, linewidth=1.5)
                    ax.set_xlabel(col, color=_DIM); ax.set_ylabel("Density", color=_DIM)
                else:  # QQ plot
                    if not pd.api.types.is_numeric_dtype(s):
                        raise ValueError("QQ plot requires numeric column")
                    from scipy import stats as _ss
                    d = s.dropna()
                    osm, osr = _ss.probplot(d, dist="norm", fit=False)
                    ax.scatter(osm, osr, color=_BLUE, alpha=0.6, s=14, linewidths=0)
                    lo, hi = float(min(osm)), float(max(osm))
                    ax.plot([lo, hi],
                            [lo * d.std() + d.mean(), hi * d.std() + d.mean()],
                            color=_GOLD, linewidth=1.4, linestyle="--", label="normal")
                    ax.legend(facecolor=_PNL, edgecolor=_BORD, labelcolor=_TEXT, fontsize=9)
                    ax.set_xlabel("Theoretical quantiles", color=_DIM)
                    ax.set_ylabel("Sample quantiles", color=_DIM)

                ax.set_title(f"{kind}: {col}", color=_TEXT, fontsize=12, pad=10)
                fig.tight_layout()
                with out:
                    _display(_HTML(
                        f'<img src="{_fig_to_png(fig)}"'
                        f' style="max-width:100%;border-radius:6px;border:1px solid {_BORD}"/>'
                    ))
                plt.close(fig)
                status.value = f'<span style="color:{_GRN};font-size:11px">Rendered</span>'
            except Exception as exc:
                status.value = f'<span style="color:{_RED};font-size:11px">{_esc(str(exc))}</span>'

        btn.on_click(_render)
        controls = W.HBox(
            [_grp("Column", col_w), _grp("Plot type", kind_w),
             _grp("Bins", bins_w),
             W.VBox([W.Label(""), btn], layout=W.Layout(justify_content="flex-end")),
             status],
            layout=W.Layout(background_color=_PNL, border=f"1px solid {_BORD}",
                            border_radius="8px", padding="12px",
                            flex_wrap="wrap", gap="10px", align_items="flex-end"),
        )
        return W.VBox([controls, out],
                      layout=W.Layout(background_color=_BG, padding="12px", gap="10px"))

    # ---------- tab: CORRELATION ---------- #
    def _tab_corr(self) -> W.VBox:
        num_cols = [str(c) for c in self._df_orig.select_dtypes(include="number").columns]
        out  = W.Output()
        note = W.HTML(
            f'<div style="color:{_DIM};font-size:11px;padding:10px 12px">'
            f'{len(num_cols)} numeric columns available</div>'
        )
        method_w = W.Dropdown(options=["pearson", "spearman", "kendall"],
                              value="pearson", layout=W.Layout(width="140px"))
        btn = W.Button(description="Render correlation matrix",
                       layout=W.Layout(width="220px", height="32px"))
        btn.add_class("qs-act")

        def _render(_b):
            out.clear_output(wait=True)
            with out:
                if len(num_cols) < 2:
                    _display(_HTML(f'<p style="color:{_RED};padding:12px">Need at least 2 numeric columns.</p>'))
                    return
                try:
                    import matplotlib.pyplot as plt
                    from matplotlib.colors import LinearSegmentedColormap
                    sub = self._df_orig[num_cols].dropna()
                    cor = sub.corr(method=method_w.value)
                    cmap = LinearSegmentedColormap.from_list(
                        "rwb", [_RED, "#FFFFFF", _BLUE])
                    fig, ax = plt.subplots(figsize=(min(12, 0.6*len(cor)+3),
                                                     min(10, 0.6*len(cor)+2.5)))
                    _style_axes_light(ax); ax.grid(False)
                    im = ax.imshow(cor, cmap=cmap, vmin=-1, vmax=1)
                    ax.set_xticks(range(len(cor))); ax.set_yticks(range(len(cor)))
                    ax.set_xticklabels(cor.columns, rotation=45, ha="right",
                                       color=_TEXT, fontsize=9)
                    ax.set_yticklabels(cor.columns, color=_TEXT, fontsize=9)
                    for i in range(len(cor)):
                        for j in range(len(cor)):
                            v = cor.iloc[i, j]
                            tc = "#FFFFFF" if abs(v) > 0.6 else _TEXT
                            ax.text(j, i, f"{v:.2f}", ha="center", va="center",
                                    color=tc, fontsize=8)
                    cb = plt.colorbar(im, ax=ax, fraction=0.04, pad=0.02)
                    cb.ax.tick_params(colors=_DIM, labelsize=8)
                    ax.set_title(f"{method_w.value.title()} correlation",
                                 color=_TEXT, fontsize=12, pad=10)
                    fig.tight_layout()
                    _display(_HTML(
                        f'<img src="{_fig_to_png(fig)}"'
                        f' style="max-width:100%;border-radius:6px;border:1px solid {_BORD}"/>'
                    ))
                    plt.close(fig)
                except Exception:
                    import traceback
                    _display(_HTML(
                        f'<pre style="color:{_RED};font-size:10px;white-space:pre-wrap">'
                        f'{_esc(traceback.format_exc())}</pre>'))

        btn.on_click(_render)
        return W.VBox(
            [note,
             W.HBox([_grp("Method", method_w), W.VBox([W.Label(""), btn])],
                    layout=W.Layout(padding="0 12px 8px 12px", gap="10px")),
             out],
            layout=W.Layout(background_color=_BG, padding="4px"),
        )

    # ---------- tab: CHARTS ---------- #
    def _tab_charts(self) -> W.VBox:
        num_cols = [str(c) for c in self._df_orig.select_dtypes(include="number").columns]
        all_cols = [str(c) for c in self._df_orig.columns]
        x_default = all_cols[0] if all_cols else ""
        y_default = num_cols[0] if num_cols else (all_cols[0] if all_cols else "")

        ct_w  = W.Dropdown(options=["Line", "Bar", "Scatter", "Histogram", "Box", "Area", "Pie"],
                           value="Line", layout=W.Layout(width="120px"))
        x_w   = W.Dropdown(options=all_cols, value=x_default, layout=W.Layout(width="150px"))
        y_w   = W.Dropdown(options=num_cols or all_cols, value=y_default,
                           layout=W.Layout(width="150px"))
        agg_w = W.Dropdown(options=["none", "mean", "sum", "count", "min", "max", "median"],
                           value="none", layout=W.Layout(width="100px"))
        out    = W.Output()
        status = W.HTML("")
        btn    = W.Button(description="Render", layout=W.Layout(width="110px", height="32px"))
        btn.add_class("qs-act")

        def _render(_b):
            import matplotlib.pyplot as plt
            out.clear_output(wait=True)
            status.value = f'<span style="color:{_DIM};font-size:11px">Rendering...</span>'
            try:
                ct, xc, yc, ag = ct_w.value, x_w.value, y_w.value, agg_w.value
                df = self._df_orig.copy()

                if ag != "none" and ct not in ("Histogram", "Pie"):
                    grp = df.groupby(xc)[yc]
                    df = {"mean": grp.mean, "sum": grp.sum, "count": grp.count,
                          "min": grp.min, "max": grp.max,
                          "median": grp.median}[ag]().reset_index()

                fig, ax = plt.subplots(figsize=(10, 4.5))
                _style_axes_light(ax)
                x_idx = range(len(df))

                if ct == "Histogram":
                    ax.hist(df[yc].dropna(), bins=40, color=_BLUE, alpha=0.85, linewidth=0)
                    ax.set_xlabel(yc, color=_DIM); ax.set_ylabel("Count", color=_DIM)
                elif ct == "Pie":
                    vc = df[yc].value_counts().head(10) if not pd.api.types.is_numeric_dtype(df[yc]) \
                         else df.groupby(xc)[yc].sum().head(10)
                    colors = [_NEON[i % len(_NEON)] for i in range(len(vc))]
                    ax.pie(vc.values, labels=[str(x)[:14] for x in vc.index],
                           colors=colors, autopct="%1.1f%%",
                           textprops={"color": _TEXT, "fontsize": 9})
                    ax.grid(False)
                elif ct in ("Line", "Area"):
                    if ct == "Line":
                        ax.plot(x_idx, df[yc], color=_BLUE, linewidth=1.6)
                        ax.fill_between(x_idx, df[yc], alpha=0.10, color=_BLUE)
                    else:
                        ax.fill_between(x_idx, df[yc], color=_BLUE, alpha=0.30)
                        ax.plot(x_idx, df[yc], color=_BLUE, linewidth=1.2)
                    step = max(1, len(df) // 10)
                    ax.set_xticks(list(range(0, len(df), step)))
                    ax.set_xticklabels([str(v)[:14] for v in df[xc].iloc[::step]],
                                       rotation=45, ha="right", fontsize=9)
                    ax.set_xlabel(xc, color=_DIM); ax.set_ylabel(yc, color=_DIM)
                elif ct == "Bar":
                    colors = [_NEON[i % len(_NEON)] for i in range(len(df))]
                    ax.bar(x_idx, df[yc], color=colors, alpha=0.9, width=0.7, linewidth=0)
                    step = max(1, len(df) // 20)
                    ax.set_xticks(list(range(0, len(df), step)))
                    ax.set_xticklabels([str(v)[:14] for v in df[xc].iloc[::step]],
                                       rotation=45, ha="right", fontsize=9)
                    ax.set_ylabel(yc, color=_DIM)
                elif ct == "Scatter":
                    ax.scatter(df[xc], df[yc], color=_BLUE, alpha=0.55, s=20, linewidths=0)
                    ax.set_xlabel(xc, color=_DIM); ax.set_ylabel(yc, color=_DIM)
                elif ct == "Box":
                    if xc in [str(c) for c in self._df_orig.select_dtypes(exclude="number").columns]:
                        groups = [g[yc].dropna().values for _, g in df.groupby(xc)]
                        lbls   = [str(k)[:12] for k in df[xc].unique()[:20]]
                        bp = ax.boxplot(groups[:20], patch_artist=True, labels=lbls,
                                        medianprops=dict(color=_BLUE, linewidth=2))
                        for patch, clr in zip(bp["boxes"], _NEON):
                            patch.set_facecolor(clr + "33"); patch.set_edgecolor(clr)
                        ax.tick_params(axis="x", rotation=45)
                    else:
                        ax.boxplot(df[yc].dropna(), patch_artist=True,
                                   medianprops=dict(color=_BLUE, linewidth=2),
                                   boxprops=dict(facecolor=_BLUE + "22", edgecolor=_BLUE))
                    ax.set_ylabel(yc, color=_DIM)

                title_extra = f" (grouped by {xc}, agg={ag})" if ag != "none" and ct not in ("Histogram", "Pie") else ""
                ax.set_title(f"{ct}: {yc}{title_extra}",
                             color=_TEXT, fontsize=12, pad=10)
                fig.tight_layout()
                with out:
                    _display(_HTML(
                        f'<img src="{_fig_to_png(fig)}"'
                        f' style="max-width:100%;border-radius:6px;border:1px solid {_BORD}"/>'
                    ))
                plt.close(fig)
                status.value = f'<span style="color:{_GRN};font-size:11px">Rendered</span>'
            except Exception as exc:
                status.value = f'<span style="color:{_RED};font-size:11px">{_esc(str(exc))}</span>'

        btn.on_click(_render)
        controls = W.HBox(
            [_grp("Chart type", ct_w), _grp("X axis", x_w),
             _grp("Y axis", y_w), _grp("Aggregation", agg_w),
             W.VBox([W.Label(""), btn], layout=W.Layout(justify_content="flex-end")),
             status],
            layout=W.Layout(background_color=_PNL, border=f"1px solid {_BORD}",
                            border_radius="8px", padding="12px",
                            flex_wrap="wrap", gap="10px", align_items="flex-end"),
        )
        return W.VBox([controls, out],
                      layout=W.Layout(background_color=_BG, padding="12px", gap="10px"))

    # ---------- tab: DUPLICATES ---------- #
    def _tab_duplicates(self) -> W.VBox:
        cols = [str(c) for c in self._df_orig.columns]
        subset_w = W.SelectMultiple(options=cols, value=tuple(),
                                    rows=6, layout=W.Layout(width="260px"))
        keep_w   = W.Dropdown(options=[("Mark all duplicates", False),
                                       ("Keep first only", "first"),
                                       ("Keep last only", "last")],
                              value=False, layout=W.Layout(width="220px"))
        out = W.Output()
        status = W.HTML("")
        btn = W.Button(description="Find duplicates",
                       layout=W.Layout(width="150px", height="32px"))
        btn.add_class("qs-act")

        def _render(_b):
            out.clear_output(wait=True)
            try:
                subset = list(subset_w.value) or None
                mask = self._df_orig.duplicated(subset=subset, keep=keep_w.value)
                dup = self._df_orig[mask]
                count = int(mask.sum())
                with out:
                    _display(_HTML(
                        f'<div style="color:{_DIM};font-size:11px;padding:8px 0">'
                        f'<b style="color:{_RED if count else _GRN}">{count:,}</b> '
                        f'duplicate rows found '
                        f'(subset: {", ".join(subset) if subset else "all columns"})</div>'
                    ))
                    if count:
                        _display(_HTML(_render_table(dup.head(200), 0, 200)))
                status.value = f'<span style="color:{_GRN};font-size:11px">Done</span>'
            except Exception as exc:
                status.value = f'<span style="color:{_RED};font-size:11px">{_esc(str(exc))}</span>'

        btn.on_click(_render)
        controls = W.HBox(
            [_grp("Subset (empty = all columns)", subset_w),
             _grp("Strategy", keep_w),
             W.VBox([W.Label(""), btn]), status],
            layout=W.Layout(background_color=_PNL, border=f"1px solid {_BORD}",
                            border_radius="8px", padding="12px",
                            flex_wrap="wrap", gap="12px", align_items="flex-end"),
        )
        return W.VBox([controls, out],
                      layout=W.Layout(background_color=_BG, padding="12px", gap="10px"))

    # ---------- tab: OUTLIERS ---------- #
    def _tab_outliers(self) -> W.VBox:
        num_cols = [str(c) for c in self._df_orig.select_dtypes(include="number").columns]
        col_w = W.Dropdown(options=num_cols or [""],
                           value=num_cols[0] if num_cols else "",
                           layout=W.Layout(width="180px"))
        method_w = W.Dropdown(options=[("Z-score (3 sigma)", "z"),
                                       ("IQR (1.5x)", "iqr"),
                                       ("Modified Z (MAD)", "mad")],
                              value="z", layout=W.Layout(width="180px"))
        out = W.Output(); status = W.HTML("")
        btn = W.Button(description="Detect outliers",
                       layout=W.Layout(width="150px", height="32px"))
        btn.add_class("qs-act")

        def _render(_b):
            out.clear_output(wait=True)
            try:
                c = col_w.value
                if not c:
                    raise ValueError("No numeric columns available")
                s = self._df_orig[c].dropna()
                if method_w.value == "z":
                    mu, sd = s.mean(), s.std()
                    mask = (s < mu - 3 * sd) | (s > mu + 3 * sd)
                    bounds = (mu - 3 * sd, mu + 3 * sd)
                    method_lbl = f"|z| > 3   (mean={mu:.4g}, std={sd:.4g})"
                elif method_w.value == "iqr":
                    q1, q3 = s.quantile(.25), s.quantile(.75)
                    iqr = q3 - q1
                    bounds = (q1 - 1.5 * iqr, q3 + 1.5 * iqr)
                    mask = (s < bounds[0]) | (s > bounds[1])
                    method_lbl = f"IQR x 1.5   (Q1={q1:.4g}, Q3={q3:.4g}, IQR={iqr:.4g})"
                else:  # mad
                    med = s.median()
                    mad = (s - med).abs().median()
                    if mad == 0: mad = 1e-9
                    mz = 0.6745 * (s - med) / mad
                    mask = mz.abs() > 3.5
                    bounds = (med - 3.5 * mad / 0.6745, med + 3.5 * mad / 0.6745)
                    method_lbl = f"|modified z| > 3.5   (median={med:.4g}, MAD={mad:.4g})"

                idx = s.index[mask]
                dfo = self._df_orig.loc[idx, [c]].copy()
                dfo.insert(0, "row_idx", idx)
                count = int(mask.sum())
                with out:
                    _display(_HTML(
                        f'<div style="color:{_DIM};font-size:11px;padding:8px 0">'
                        f'<b style="color:{_RED if count else _GRN}">{count:,}</b> outliers in '
                        f'<b>{_esc(c)}</b> &middot; method: {method_lbl} &middot; '
                        f'bounds: [{bounds[0]:.4g}, {bounds[1]:.4g}]</div>'
                    ))
                    if count:
                        _display(_HTML(_render_table(dfo.head(200), 0, 200)))
                status.value = f'<span style="color:{_GRN};font-size:11px">Done</span>'
            except Exception as exc:
                status.value = f'<span style="color:{_RED};font-size:11px">{_esc(str(exc))}</span>'

        btn.on_click(_render)
        controls = W.HBox(
            [_grp("Column", col_w), _grp("Method", method_w),
             W.VBox([W.Label(""), btn]), status],
            layout=W.Layout(background_color=_PNL, border=f"1px solid {_BORD}",
                            border_radius="8px", padding="12px",
                            flex_wrap="wrap", gap="12px", align_items="flex-end"),
        )
        return W.VBox([controls, out],
                      layout=W.Layout(background_color=_BG, padding="12px", gap="10px"))

    # ---------- tab: TIME SERIES ---------- #
    def _tab_timeseries(self) -> W.VBox:
        # eligible date columns: datetime dtype or the index if datetime
        dt_cols = [str(c) for c in self._df_orig.columns
                   if pd.api.types.is_datetime64_any_dtype(self._df_orig[c])]
        idx_is_dt = isinstance(self._df_orig.index, pd.DatetimeIndex)
        date_opts = (["<index>"] if idx_is_dt else []) + dt_cols
        if not date_opts:
            date_opts = ["<index>"]
        num_cols = [str(c) for c in self._df_orig.select_dtypes(include="number").columns]

        date_w = W.Dropdown(options=date_opts, value=date_opts[0],
                            layout=W.Layout(width="160px"))
        val_w  = W.Dropdown(options=num_cols or [""],
                            value=num_cols[0] if num_cols else "",
                            layout=W.Layout(width="160px"))
        freq_w = W.Dropdown(options=[("Day", "D"), ("Week", "W"), ("Month", "M"),
                                     ("Quarter", "Q"), ("Year", "Y")],
                            value="M", layout=W.Layout(width="100px"))
        agg_w  = W.Dropdown(options=["mean", "sum", "min", "max", "last"],
                            value="mean", layout=W.Layout(width="100px"))
        roll_w = W.IntSlider(value=20, min=2, max=200, step=1,
                             continuous_update=False,
                             layout=W.Layout(width="220px"), description="")
        out = W.Output(); status = W.HTML("")
        btn = W.Button(description="Render", layout=W.Layout(width="110px", height="32px"))
        btn.add_class("qs-act")

        def _render(_b):
            import matplotlib.pyplot as plt
            out.clear_output(wait=True)
            try:
                if not val_w.value:
                    raise ValueError("Select a numeric value column")
                df = self._df_orig.copy()
                if date_w.value == "<index>":
                    if not isinstance(df.index, pd.DatetimeIndex):
                        raise ValueError("Index is not datetime; pick a date column")
                    s = df[val_w.value]
                else:
                    df = df.set_index(pd.to_datetime(df[date_w.value]))
                    s  = df[val_w.value]
                s = s.sort_index()

                resampled = s.resample(freq_w.value).agg(agg_w.value)
                roll = resampled.rolling(roll_w.value, min_periods=1).mean()

                fig, ax = plt.subplots(figsize=(10, 4.5))
                _style_axes_light(ax)
                ax.plot(resampled.index, resampled.values, color=_BLUE,
                        linewidth=1.4, label=f"{agg_w.value} ({freq_w.value})")
                ax.plot(roll.index, roll.values, color=_ORNG, linewidth=1.6,
                        linestyle="--", label=f"rolling {roll_w.value}")
                ax.set_xlabel("Date", color=_DIM)
                ax.set_ylabel(val_w.value, color=_DIM)
                ax.set_title(f"{val_w.value} time series", color=_TEXT, fontsize=12, pad=10)
                ax.legend(facecolor=_PNL, edgecolor=_BORD, labelcolor=_TEXT, fontsize=9)
                fig.autofmt_xdate(); fig.tight_layout()
                with out:
                    _display(_HTML(
                        f'<img src="{_fig_to_png(fig)}"'
                        f' style="max-width:100%;border-radius:6px;border:1px solid {_BORD}"/>'
                    ))
                plt.close(fig)
                status.value = f'<span style="color:{_GRN};font-size:11px">Rendered</span>'
            except Exception as exc:
                status.value = f'<span style="color:{_RED};font-size:11px">{_esc(str(exc))}</span>'

        btn.on_click(_render)
        controls = W.HBox(
            [_grp("Date col", date_w), _grp("Value col", val_w),
             _grp("Resample", freq_w), _grp("Aggfunc", agg_w),
             _grp("Rolling window", roll_w),
             W.VBox([W.Label(""), btn]), status],
            layout=W.Layout(background_color=_PNL, border=f"1px solid {_BORD}",
                            border_radius="8px", padding="12px",
                            flex_wrap="wrap", gap="12px", align_items="flex-end"),
        )
        return W.VBox([controls, out],
                      layout=W.Layout(background_color=_BG, padding="12px", gap="10px"))

    # ---------- tab: RESHAPE ---------- #
    def _tab_reshape(self) -> W.VBox:
        cols = [str(c) for c in self._df_orig.columns]
        op_w  = W.Dropdown(options=["Pivot", "Melt", "Transpose", "Drop duplicates",
                                    "Drop NA rows", "Sort", "Group by"],
                           value="Pivot", layout=W.Layout(width="160px"))
        idx_w = W.Dropdown(options=cols, value=cols[0] if cols else "",
                           layout=W.Layout(width="150px"))
        col_w = W.Dropdown(options=cols, value=cols[0] if cols else "",
                           layout=W.Layout(width="150px"))
        val_w = W.Dropdown(options=cols, value=cols[0] if cols else "",
                           layout=W.Layout(width="150px"))
        agg_w = W.Dropdown(options=["mean", "sum", "count", "min", "max", "median"],
                           value="mean", layout=W.Layout(width="100px"))
        out = W.Output(); status = W.HTML("")
        btn = W.Button(description="Apply", layout=W.Layout(width="100px", height="32px"))
        btn.add_class("qs-act")

        def _render(_b):
            out.clear_output(wait=True)
            try:
                df = self._df_orig
                op = op_w.value
                if op == "Pivot":
                    res = df.pivot_table(index=idx_w.value, columns=col_w.value,
                                         values=val_w.value, aggfunc=agg_w.value)
                elif op == "Melt":
                    res = df.melt(id_vars=[idx_w.value])
                elif op == "Transpose":
                    res = df.T
                elif op == "Drop duplicates":
                    res = df.drop_duplicates()
                elif op == "Drop NA rows":
                    res = df.dropna()
                elif op == "Sort":
                    res = df.sort_values(idx_w.value)
                elif op == "Group by":
                    res = df.groupby(idx_w.value).agg(agg_w.value, numeric_only=True)
                else:
                    res = df
                with out:
                    _display(_HTML(
                        f'<div style="color:{_DIM};font-size:11px;padding:6px 0">'
                        f'Result shape: <b>{res.shape[0]:,} x {res.shape[1]:,}</b> '
                        f'(preview, first 100 rows)</div>'
                    ))
                    res2 = res.head(100).reset_index() if not isinstance(res.index, pd.RangeIndex) \
                           else res.head(100)
                    _display(_HTML(_render_table(res2, 0, 100)))
                status.value = f'<span style="color:{_GRN};font-size:11px">Applied</span>'
            except Exception as exc:
                status.value = f'<span style="color:{_RED};font-size:11px">{_esc(str(exc))}</span>'

        btn.on_click(_render)
        controls = W.HBox(
            [_grp("Operation", op_w), _grp("Index / sort key", idx_w),
             _grp("Columns", col_w), _grp("Values", val_w), _grp("Aggfunc", agg_w),
             W.VBox([W.Label(""), btn]), status],
            layout=W.Layout(background_color=_PNL, border=f"1px solid {_BORD}",
                            border_radius="8px", padding="12px",
                            flex_wrap="wrap", gap="10px", align_items="flex-end"),
        )
        return W.VBox([controls, out],
                      layout=W.Layout(background_color=_BG, padding="12px", gap="10px"))

    # ---------- tab: QUERY ---------- #
    def _tab_query(self) -> W.VBox:
        q_w = W.Textarea(
            value="",
            placeholder='e.g.  Close > 100 and Volume > 1_000_000',
            layout=W.Layout(width="100%", height="80px"),
        )
        hint = W.HTML(
            f'<div style="color:{_DIM};font-size:11px;padding:6px 0">'
            f'pandas <code>DataFrame.query()</code> syntax. Reference columns by name. '
            f'Use backticks for names with spaces, e.g. <code>`my col` &gt; 5</code>.</div>'
        )
        out = W.Output(); status = W.HTML("")
        btn = W.Button(description="Run query", layout=W.Layout(width="120px", height="32px"))
        btn.add_class("qs-act")

        def _render(_b):
            out.clear_output(wait=True)
            try:
                expr = q_w.value.strip()
                if not expr:
                    raise ValueError("Enter a query expression")
                res = self._df_orig.query(expr)
                with out:
                    _display(_HTML(
                        f'<div style="color:{_DIM};font-size:11px;padding:6px 0">'
                        f'Matched <b>{len(res):,}</b> / {len(self._df_orig):,} rows</div>'
                    ))
                    _display(_HTML(_render_table(res.head(200), 0, 200)))
                status.value = f'<span style="color:{_GRN};font-size:11px">OK</span>'
            except Exception as exc:
                status.value = f'<span style="color:{_RED};font-size:11px">{_esc(str(exc))}</span>'

        btn.on_click(_render)
        controls = W.VBox(
            [hint, q_w, W.HBox([btn, status], layout=W.Layout(gap="10px", align_items="center"))],
            layout=W.Layout(background_color=_PNL, border=f"1px solid {_BORD}",
                            border_radius="8px", padding="12px", gap="6px"),
        )
        return W.VBox([controls, out],
                      layout=W.Layout(background_color=_BG, padding="12px", gap="10px"))

    # ---------- tab: EXPORT ---------- #
    def _tab_export(self) -> W.VBox:
        path_w  = W.Text(value="export.csv", placeholder="output path",
                         layout=W.Layout(width="320px"))
        fmt_w   = W.Dropdown(options=["CSV", "TSV", "JSON", "Parquet", "Excel", "HTML"],
                             value="CSV", layout=W.Layout(width="120px"))
        scope_w = W.Dropdown(options=[("Filtered view", "view"), ("Original", "orig")],
                             value="view", layout=W.Layout(width="160px"))
        status = W.HTML("")
        save_b = W.Button(description="Save to disk",
                          layout=W.Layout(width="140px", height="32px"))
        save_b.add_class("qs-act")
        copy_b = W.Button(description="Show pandas code",
                          layout=W.Layout(width="170px", height="32px"))
        copy_b.add_class("qs-act")
        code_out = W.Output()

        def _do_save(_b):
            df   = self._df if scope_w.value == "view" else self._df_orig
            path = path_w.value or "export"
            try:
                if   fmt_w.value == "CSV":     df.to_csv(path, index=True)
                elif fmt_w.value == "TSV":     df.to_csv(path, sep="\t", index=True)
                elif fmt_w.value == "JSON":    df.to_json(path, orient="records", date_format="iso")
                elif fmt_w.value == "Parquet": df.to_parquet(path)
                elif fmt_w.value == "Excel":   df.to_excel(path, index=True)
                elif fmt_w.value == "HTML":    df.to_html(path, index=True)
                status.value = (f'<span style="color:{_GRN};font-size:11px">'
                                f'Saved {len(df):,} rows -> {_esc(path)}</span>')
            except Exception as exc:
                status.value = f'<span style="color:{_RED};font-size:11px">{_esc(str(exc))}</span>'

        def _do_code(_b):
            lines = [
                '<span class="cm"># algo-stat DataExplorer - equivalent pandas pipeline</span>',
                '<span class="kw">import</span> <span class="nm">pandas</span> <span class="kw">as</span> <span class="nm">pd</span>',
                f'df = pd.read_csv(<span class="st">"your_data.csv"</span>)',
                '',
            ]
            if self._filters:
                lines.append('<span class="cm"># filters</span>')
                for f in self._filters:
                    col, op, val = f["col"], f["op"], f["val"]
                    if op == "is null":
                        lines.append(f'df = df[df[<span class="st">"{_esc(col)}"</span>].isna()]')
                    elif op == "not null":
                        lines.append(f'df = df[df[<span class="st">"{_esc(col)}"</span>].notna()]')
                    elif op == "contains":
                        lines.append(f'df = df[df[<span class="st">"{_esc(col)}"</span>].astype(str).str.contains(<span class="st">"{_esc(val)}"</span>, case=False, na=False)]')
                    elif op == "startswith":
                        lines.append(f'df = df[df[<span class="st">"{_esc(col)}"</span>].astype(str).str.startswith(<span class="st">"{_esc(val)}"</span>)]')
                    else:
                        v_str = (repr(val) if not pd.api.types.is_numeric_dtype(self._df_orig[col]) else val)
                        lines.append(f'df = df[df[<span class="st">"{_esc(col)}"</span>] {op} {v_str}]')
            if self._search.strip():
                lines.append('<span class="cm"># global search</span>')
                lines.append(
                    f'mask = pd.concat([df[c].astype(str).str.contains('
                    f'<span class="st">"{_esc(self._search)}"</span>, case=False, na=False) '
                    f'for c in df.columns], axis=1).any(axis=1)'
                )
                lines.append('df = df[mask]')
            if self._sort_col:
                lines.append(
                    f'df = df.sort_values(<span class="st">"{_esc(self._sort_col)}"</span>, '
                    f'ascending={self._sort_asc})'
                )
            lines.append('')
            lines.append('<span class="cm"># export</span>')
            ext = fmt_w.value.lower()
            method = {"tsv": "csv", "html": "html"}.get(ext, ext)
            extra  = ', sep="\\t"' if ext == "tsv" else ""
            lines.append(f'df.to_{method}(<span class="st">"{_esc(path_w.value)}"</span>{extra})')
            code_out.clear_output(wait=True)
            with code_out:
                _display(_HTML(f'<div class="qs-codeblk">{chr(10).join(lines)}</div>'))

        save_b.on_click(_do_save); copy_b.on_click(_do_code)
        controls = W.HBox(
            [_grp("Format", fmt_w), _grp("Path", path_w),
             _grp("Source", scope_w),
             W.VBox([W.Label(""), save_b]),
             W.VBox([W.Label(""), copy_b]), status],
            layout=W.Layout(background_color=_PNL, border=f"1px solid {_BORD}",
                            border_radius="8px", padding="12px",
                            flex_wrap="wrap", gap="10px", align_items="flex-end"),
        )
        return W.VBox([controls, code_out],
                      layout=W.Layout(background_color=_BG, padding="12px", gap="10px"))

    # ---------- public ---------- #
    def show(self) -> None:
        """Render the DataExplorer widget in the current Jupyter cell."""
        _display(_HTML(_CSS))

        header = W.HTML(
            f'<div class="qs-dex-hdr">'
            f'<span class="qs-dex-title">{_esc(self._name)}</span>'
            f'<span class="qs-dex-badge">{len(self._df_orig):,} rows</span>'
            f'<span class="qs-dex-badge">{len(self._df_orig.columns)} cols</span>'
            f'<span class="qs-dex-badge brand">algo-stat</span>'
            f'<span class="qs-dex-badge brand-dim">(c) Squid Consultancy Group Ltd</span>'
            f'</div>'
        )

        tab_specs = [
            ("Grid",        self._tab_grid),
            ("Describe",    self._tab_describe),
            ("Summary",     self._tab_summary),
            ("Column",      self._tab_col_analysis),
            ("Correlation", self._tab_corr),
            ("Charts",      self._tab_charts),
            ("Missing",     self._tab_missing),
            ("Duplicates",  self._tab_duplicates),
            ("Outliers",    self._tab_outliers),
            ("Time Series", self._tab_timeseries),
            ("Reshape",     self._tab_reshape),
            ("Query",       self._tab_query),
            ("Export",      self._tab_export),
        ]
        tabs = W.Tab(children=[fn() for _, fn in tab_specs])
        for i, (title, _) in enumerate(tab_specs):
            tabs.set_title(i, title)

        root = W.VBox(
            [header, tabs],
            layout=W.Layout(border=f"1px solid {_BORD}", border_radius="10px",
                            overflow="hidden", background_color=_BG),
        )
        root.add_class("qs-dex")
        self._refresh_grid()
        _display(root)


# --------------------------------------------------------------------------- #
def explore(df: pd.DataFrame, name: str = "DataFrame") -> None:
    """Launch the interactive DataFrame explorer."""
    DataExplorer(df, name=name).show()
