# © Squid Consultancy Group Ltd — All rights reserved.
# Unauthorised removal or modification of this notice is prohibited.
from __future__ import annotations
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    fred_api_key:             str | None = None
    alpha_vantage_api_key:    str | None = None
    alpaca_api_key:           str | None = None
    alpaca_secret_key:        str | None = None
    alpaca_base_url:          str = "https://paper-api.alpaca.markets"

    risk_free_rate: float = 0.05      # annual
    trading_days: int = 252

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


settings = Settings()
