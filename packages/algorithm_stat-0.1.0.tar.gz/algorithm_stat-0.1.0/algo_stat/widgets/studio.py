# © Squid Consultancy Group Ltd — All rights reserved.
# Unauthorised removal or modification of this notice is prohibited.
"""
algo_stat.widgets.studio
========================
Interactive drag-and-drop chart studio for Jupyter notebooks.

Usage
-----
>>> import algo_stat as a
>>> a.Studio().show()
"""
from __future__ import annotations
import io, base64, traceback
from typing import Any

try:
    import ipywidgets as W
    from IPython.display import display as _display, HTML as _HTML
    _WIDGETS_OK = True
except ImportError:
    _WIDGETS_OK = False


# ── CSS injected once per show() call ─────────────────────────────────────────
_CSS = """
<style>
/* ─── Studio root (light theme) ────────────────────────────────────── */
.qs-studio {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Inter", "Helvetica Neue", Arial, sans-serif;
    background: #FFFFFF;
    border: 1px solid #E1E4E8;
    border-radius: 12px;
    overflow: hidden;
    min-height: 520px;
    color: #24292F;
}
/* ─── Toolbar ───────────────────────────────────────────────────────── */
.qs-toolbar {
    background: #F6F8FA;
    border-bottom: 1px solid #E1E4E8;
    padding: 10px 16px;
    display: flex;
    align-items: center;
    gap: 10px;
}
.qs-toolbar-title {
    color: #0969DA;
    font-size: 15px;
    font-weight: 700;
    letter-spacing: 0.04em;
    margin: 0;
    flex: 1;
}
.qs-toolbar-subtitle {
    color: #57606A;
    font-size: 11px;
}
/* ─── Main layout ───────────────────────────────────────────────────── */
.qs-body {
    display: flex;
    min-height: 480px;
}
/* ─── Left sidebar (chart blocks) ──────────────────────────────────── */
.qs-sidebar {
    width: 180px;
    min-width: 180px;
    background: #F6F8FA;
    border-right: 1px solid #E1E4E8;
    padding: 12px 10px;
    display: flex;
    flex-direction: column;
    gap: 6px;
}
.qs-sidebar-label {
    color: #57606A;
    font-size: 10px;
    text-transform: uppercase;
    letter-spacing: 0.10em;
    padding: 0 4px 4px 4px;
    border-bottom: 1px solid #E1E4E8;
    margin-bottom: 4px;
    font-weight: 600;
}
/* ─── Chart blocks (draggable) ──────────────────────────────────────── */
.qs-block {
    background: #FFFFFF;
    border: 1px solid #D0D7DE;
    border-radius: 8px;
    padding: 8px 10px;
    cursor: grab;
    display: flex;
    align-items: center;
    gap: 8px;
    transition: border-color 0.15s, box-shadow 0.15s, background 0.15s;
    user-select: none;
}
.qs-block:hover {
    border-color: #0969DA;
    background: #F6F8FA;
    box-shadow: 0 1px 3px rgba(9, 105, 218, 0.15);
}
.qs-block:active { cursor: grabbing; }
.qs-block-icon {
    font-size: 11px;
    font-weight: 700;
    color: #0969DA;
    background: #DDF4FF;
    border-radius: 4px;
    padding: 2px 6px;
    letter-spacing: 0.05em;
}
.qs-block-name { color: #24292F; font-size: 12px; font-weight: 500; }
/* ─── Drop zone / Canvas ────────────────────────────────────────────── */
.qs-canvas {
    flex: 1;
    padding: 16px;
    overflow-y: auto;
    background: #FFFFFF;
}
.qs-drop-hint {
    color: #8C959F;
    font-size: 13px;
    text-align: center;
    margin-top: 80px;
    pointer-events: none;
}
.qs-drop-hint span {
    font-size: 48px;
    display: block;
    margin-bottom: 10px;
    opacity: 0.4;
}
/* ─── Config card (per-added block) ────────────────────────────────── */
.qs-config-card {
    background: #FFFFFF;
    border: 1px solid #D0D7DE;
    border-radius: 10px;
    margin-bottom: 16px;
    overflow: hidden;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.04);
}
.qs-config-header {
    background: #F6F8FA;
    padding: 9px 14px;
    display: flex;
    align-items: center;
    gap: 8px;
    cursor: pointer;
    border-bottom: 1px solid #E1E4E8;
}
.qs-config-header:hover { background: #EAEEF2; }
.qs-config-icon {
    font-size: 11px;
    font-weight: 700;
    color: #0969DA;
    background: #DDF4FF;
    border-radius: 4px;
    padding: 2px 6px;
    letter-spacing: 0.05em;
}
.qs-config-name { color: #24292F; font-size: 13px; font-weight: 600; flex: 1; }
.qs-config-badge {
    background: #DDF4FF;
    border: 1px solid #B6E3FF;
    color: #0969DA;
    font-size: 10px;
    border-radius: 4px;
    padding: 1px 6px;
    font-weight: 600;
}
/* ─── Input rows ─────────────────────────────────────────────────────── */
.qs-input-row {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 8px 14px;
    border-bottom: 1px solid #EAEEF2;
}
.qs-input-label {
    color: #57606A;
    font-size: 11px;
    min-width: 90px;
    font-weight: 500;
}
/* Widget overrides — light */
.qs-studio .widget-text input,
.qs-studio .widget-dropdown select,
.qs-studio .widget-inttext input {
    background: #FFFFFF !important;
    border: 1px solid #D0D7DE !important;
    border-radius: 6px !important;
    color: #24292F !important;
    font-size: 12px !important;
    padding: 4px 8px !important;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif !important;
}
.qs-studio .widget-text input:focus,
.qs-studio .widget-dropdown select:focus {
    border-color: #0969DA !important;
    box-shadow: 0 0 0 2px rgba(9, 105, 218, 0.2) !important;
    outline: none !important;
}
.qs-studio .widget-label {
    color: #57606A !important;
    font-size: 11px !important;
}
/* Render button */
.qs-render-btn button {
    background: #0969DA !important;
    border: 1px solid #0969DA !important;
    color: #FFFFFF !important;
    border-radius: 6px !important;
    font-size: 12px !important;
    font-weight: 600 !important;
    padding: 5px 14px !important;
    cursor: pointer !important;
    transition: background 0.15s, box-shadow 0.15s !important;
}
.qs-render-btn button:hover {
    background: #0860C7 !important;
    box-shadow: 0 1px 4px rgba(9, 105, 218, 0.35) !important;
}
/* Delete button */
.qs-del-btn button {
    background: #FFFFFF !important;
    border: 1px solid #D0D7DE !important;
    color: #CF222E !important;
    border-radius: 6px !important;
    font-size: 11px !important;
    padding: 3px 10px !important;
}
.qs-del-btn button:hover {
    background: #FFEBE9 !important;
    border-color: #CF222E !important;
}
/* Output area */
.qs-output {
    padding: 10px 14px 12px 14px;
    background: #FFFFFF;
}
</style>
"""

# ── Chart-block definitions ────────────────────────────────────────────────────
_BLOCKS: list[tuple[str, str, str]] = [
    ("LN", "Line Chart",      "line"),
    ("CN", "Candlestick",     "candle"),
    ("CM", "Compare",         "compare"),
    ("CR", "Correlation",     "correlation"),
    ("MC", "Monte Carlo",     "montecarlo"),
    ("BT", "Backtest",        "backtest"),
    ("MR", "Mortgage Shock",  "mortgage"),
    ("PC", "PCA",             "pca"),
    ("FR", "FRED Macro",      "fred"),
]

# ── Dropdown choices ────────────────────────────────────────────────────────────
_PERIODS  = ["1mo", "3mo", "6mo", "1y", "2y", "3y", "5y", "10y"]
_MA_OPTS  = ["None", "20", "50", "50,200", "20,50,200"]

# ── Helpers ────────────────────────────────────────────────────────────────────

def _fig_to_png_data(fig) -> str:
    """Convert a Matplotlib figure to a base64-encoded PNG data-URI."""
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=110, bbox_inches="tight",
                facecolor=fig.get_facecolor())
    buf.seek(0)
    return "data:image/png;base64," + base64.b64encode(buf.read()).decode()


def _run_chart(chart_type: str, cfg: dict[str, Any]):
    """Execute a chart function and return a Matplotlib figure or None on error."""
    import algo_stat as a

    t = cfg.get("ticker", "AAPL").strip().upper() or "AAPL"
    p = cfg.get("period",  "1y")
    ma_raw  = cfg.get("ma", "None")
    ma_list = None if ma_raw in ("None", "") else [int(x) for x in ma_raw.split(",")]

    if chart_type == "line":
        df = a.fetch(t, period=p)
        return a.line(df, ticker=t, ma=ma_list)

    if chart_type == "candle":
        df = a.fetch(t, period=p)
        return a.candle(df, title=f"{t} — {p}")

    if chart_type == "compare":
        raw  = cfg.get("tickers_multi", "AAPL,MSFT,NVDA")
        tks  = [x.strip().upper() for x in raw.split(",") if x.strip()]
        return a.compare(tks, period=p).show()

    if chart_type == "correlation":
        raw  = cfg.get("tickers_multi", "AAPL,MSFT,NVDA,TSLA")
        tks  = [x.strip().upper() for x in raw.split(",") if x.strip()]
        prices = a.fetch_many(tks, period=p)
        return a.correlation_heatmap(prices.pct_change().dropna())

    if chart_type == "montecarlo":
        n_paths = int(cfg.get("n_paths", 500))
        days    = int(cfg.get("days",    252))
        return a.MonteCarlo(ticker=t, period_lookup=p).simulate(n=n_paths, days=days).plot()

    if chart_type == "backtest":
        from algo_stat.backtest.strategies import SMACrossover
        fast = int(cfg.get("sma_fast", 20))
        slow = int(cfg.get("sma_slow", 50))
        bt   = a.Backtester(t, period=p).run(SMACrossover(fast, slow))
        return bt.plot()

    if chart_type == "mortgage":
        price   = float(cfg.get("house_price",  300_000))
        deposit = float(cfg.get("deposit",       60_000))
        rate    = float(cfg.get("base_rate",      5.5)) / 100
        years   = int(cfg.get("years",           25))
        shocks_raw = cfg.get("rate_shocks", "5.5,6.0,6.5,7.0,7.5")
        shocks = [float(x) / 100 for x in shocks_raw.split(",") if x.strip()]
        mc = a.MortgageCalculator(price=price, deposit=deposit, rate=rate, years=years)
        return mc.simulate_rate_shock(shocks).plot()

    if chart_type == "pca":
        raw = cfg.get("tickers_multi", "AAPL,MSFT,NVDA,TSLA,GOOG,META")
        tks = [x.strip().upper() for x in raw.split(",") if x.strip()]
        res = a.stock_pca(tks, period=p, n_components=3, plot=True)
        return res["fig"]

    if chart_type == "fred":
        series = cfg.get("fred_series", "cpi").strip().lower()
        yr = int(cfg.get("years", 10))
        df = a.fred(series, years=yr)
        col = df.columns[0]
        return a.line(df.rename(columns={col: "Close"}), ticker=f"FRED: {col.upper()}")

    raise ValueError(f"Unknown chart type: {chart_type!r}")


# ── Studio class ───────────────────────────────────────────────────────────────

class Studio:
    """Interactive drag-and-drop chart studio for Jupyter.

    >>> import algo_stat as a
    >>> a.Studio().show()

    Drag any chart block from the sidebar onto the canvas,
    fill in the configuration inputs, and click **Render Chart**.
    """

    def __init__(self):
        if not _WIDGETS_OK:
            raise ImportError(
                "ipywidgets is required.  Install with:\n"
                "  pip install ipywidgets\n"
                "  jupyter labextension install @jupyter-widgets/jupyterlab-manager"
            )
        self._cards: list[dict] = []   # list of per-block UI state
        self._canvas = W.VBox(layout=W.Layout(width="100%"))
        self._drop_hint = W.HTML(
            '<div class="qs-drop-hint">'
            'Click a chart block on the left to add it to your canvas'
            '</div>'
        )
        self._canvas.children = (self._drop_hint,)
        self._root: W.Widget | None = None

    # ── sidebar ──────────────────────────────────────────────────────────────

    def _make_sidebar(self) -> W.VBox:
        header = W.HTML('<div class="qs-sidebar-label">Chart blocks</div>')
        btns   = [self._make_block_btn(icon, name, ctype)
                  for icon, name, ctype in _BLOCKS]
        return W.VBox(
            [header, *btns],
            layout=W.Layout(
                width="180px", min_width="180px",
                background_color="#F6F8FA",
                border_right="1px solid #E1E4E8",
                padding="12px 10px",
                overflow_y="auto",
            ),
        )

    def _make_block_btn(self, icon: str, name: str, ctype: str) -> W.Button:
        btn = W.Button(
            description=f"{icon}  {name}",
            layout=W.Layout(width="160px", height="36px", margin="2px 0"),
        )
        btn.style.button_color = "#FFFFFF"
        btn.add_class("qs-block")
        btn.on_click(lambda _b, ct=ctype, ic=icon, nm=name:
                     self._add_block(ct, ic, nm))
        return btn

    # ── config card ──────────────────────────────────────────────────────────

    def _add_block(self, ctype: str, icon: str, name: str) -> None:
        """Add a new config card to the canvas."""
        idx   = len(self._cards)
        cfg   = {}
        rows  = []

        def _row(label: str, widget: W.Widget) -> W.HBox:
            lbl = W.HTML(f'<div class="qs-input-label">{label}</div>',
                         layout=W.Layout(min_width="90px"))
            return W.HBox([lbl, widget], layout=W.Layout(
                padding="6px 14px", border_bottom="1px solid #EAEEF2"))

        # ── inputs per chart type ─────────────────────────────────────
        if ctype in ("line", "candle", "montecarlo", "backtest"):
            t_w = W.Text(value="AAPL", description="", continuous_update=False,
                         layout=W.Layout(width="130px"))
            t_w.observe(lambda ch, k="ticker": cfg.__setitem__(k, ch["new"]), "value")
            cfg["ticker"] = "AAPL"
            rows.append(_row("Ticker", t_w))

        if ctype in ("compare", "correlation", "pca"):
            t_w = W.Text(
                value=("AAPL,MSFT,NVDA"     if ctype == "compare" else
                       "AAPL,MSFT,NVDA,TSLA" if ctype == "correlation" else
                       "AAPL,MSFT,NVDA,TSLA,GOOG,META"),
                description="", continuous_update=False,
                layout=W.Layout(width="280px"),
            )
            t_w.observe(lambda ch, k="tickers_multi": cfg.__setitem__(k, ch["new"]), "value")
            cfg["tickers_multi"] = t_w.value
            rows.append(_row("Tickers (CSV)", t_w))

        if ctype not in ("mortgage",):
            p_w = W.Dropdown(options=_PERIODS, value="1y",
                             description="", layout=W.Layout(width="120px"))
            p_w.observe(lambda ch: cfg.__setitem__("period", ch["new"]), "value")
            cfg["period"] = "1y"
            rows.append(_row("Period", p_w))

        if ctype == "line":
            m_w = W.Dropdown(options=_MA_OPTS, value="None",
                             description="", layout=W.Layout(width="130px"))
            m_w.observe(lambda ch: cfg.__setitem__("ma", ch["new"]), "value")
            cfg["ma"] = "None"
            rows.append(_row("Moving avg", m_w))

        if ctype == "montecarlo":
            n_w = W.BoundedIntText(value=500,  min=100, max=5000, step=100,
                                   description="", layout=W.Layout(width="110px"))
            d_w = W.BoundedIntText(value=252,  min=21,  max=1260, step=21,
                                   description="", layout=W.Layout(width="110px"))
            n_w.observe(lambda ch: cfg.__setitem__("n_paths", ch["new"]), "value")
            d_w.observe(lambda ch: cfg.__setitem__("days",    ch["new"]), "value")
            cfg["n_paths"] = 500; cfg["days"] = 252
            rows.append(_row("Paths",       n_w))
            rows.append(_row("Days",        d_w))

        if ctype == "backtest":
            f_w = W.BoundedIntText(value=20, min=2, max=200,
                                   description="", layout=W.Layout(width="90px"))
            s_w = W.BoundedIntText(value=50, min=5, max=500,
                                   description="", layout=W.Layout(width="90px"))
            f_w.observe(lambda ch: cfg.__setitem__("sma_fast", ch["new"]), "value")
            s_w.observe(lambda ch: cfg.__setitem__("sma_slow", ch["new"]), "value")
            cfg["sma_fast"] = 20; cfg["sma_slow"] = 50
            rows.append(_row("SMA fast",  f_w))
            rows.append(_row("SMA slow",  s_w))

        if ctype == "mortgage":
            fields = [
                ("house_price",  "House price ($)",    300_000),
                ("deposit",      "Deposit ($)",         60_000),
                ("base_rate",    "Base rate (%)",           5.5),
                ("years",        "Term (years)",           25),
                ("rate_shocks",  "Shock rates (% CSV)", "5.5,6.0,6.5,7.0,7.5"),
            ]
            for key, label, default in fields:
                if key == "rate_shocks":
                    w = W.Text(value=str(default), description="",
                               continuous_update=False, layout=W.Layout(width="220px"))
                    w.observe(lambda ch, k=key: cfg.__setitem__(k, ch["new"]), "value")
                else:
                    w = W.FloatText(value=float(default), description="",
                                    layout=W.Layout(width="130px"))
                    w.observe(lambda ch, k=key: cfg.__setitem__(k, ch["new"]), "value")
                cfg[key] = default
                rows.append(_row(label, w))

        if ctype == "fred":
            s_w = W.Text(value="cpi", description="", continuous_update=False,
                         layout=W.Layout(width="150px"))
            y_w = W.BoundedIntText(value=10, min=1, max=50,
                                   description="", layout=W.Layout(width="90px"))
            s_w.observe(lambda ch: cfg.__setitem__("fred_series", ch["new"]), "value")
            y_w.observe(lambda ch: cfg.__setitem__("years",       ch["new"]), "value")
            cfg["fred_series"] = "cpi"; cfg["years"] = 10
            rows.append(_row("FRED series", s_w))
            rows.append(_row("Years",       y_w))

        # ── render + delete buttons ───────────────────────────────────
        out    = W.Output(layout=W.Layout(padding="0 14px 12px 14px"))
        status = W.HTML("", layout=W.Layout(padding="0 14px"))

        render_btn = W.Button(description="Render Chart",
                              layout=W.Layout(width="150px", height="32px",
                                              margin="8px 14px"))
        render_btn.add_class("qs-render-btn")

        del_btn = W.Button(description="Remove",
                           layout=W.Layout(width="90px", height="28px",
                                           margin="8px 4px"))
        del_btn.add_class("qs-del-btn")

        def _render(_b):
            out.clear_output(wait=True)
            status.value = '<span style="color:#57606A;font-size:11px">Rendering…</span>'
            try:
                fig = _run_chart(ctype, cfg)
                if fig is not None:
                    png = _fig_to_png_data(fig)
                    with out:
                        _display(_HTML(
                            f'<img src="{png}" style="max-width:100%;border-radius:6px;'
                            f'border:1px solid #D0D7DE;"/>'
                        ))
                    status.value = '<span style="color:#1A7F37;font-size:11px;font-weight:600">Ready</span>'
                else:
                    status.value = '<span style="color:#CF222E;font-size:11px">No figure returned</span>'
            except Exception as exc:
                tb = traceback.format_exc()
                status.value = (
                    f'<span style="color:#CF222E;font-size:11px">Error: {exc}</span>'
                )
                with out:
                    _display(_HTML(
                        f'<pre style="color:#CF222E;font-size:10px;'
                        f'white-space:pre-wrap;">{tb}</pre>'
                    ))

        render_btn.on_click(_render)

        def _remove(_b):
            # remove this card from canvas
            new_children = [c for c in self._canvas.children
                            if c is not card_box]
            if not new_children:
                new_children = [self._drop_hint]
            self._canvas.children = tuple(new_children)

        del_btn.on_click(_remove)

        btn_row = W.HBox([render_btn, del_btn, status],
                         layout=W.Layout(align_items="center"))

        header_html = W.HTML(
            f'<div class="qs-config-header">'
            f'<span class="qs-config-icon">{icon}</span>'
            f'<span class="qs-config-name">{name}</span>'
            f'<span class="qs-config-badge">drag-block</span>'
            f'</div>'
        )
        card_box = W.VBox(
            [header_html, *rows, btn_row, out],
            layout=W.Layout(
                border="1px solid #D0D7DE",
                border_radius="10px",
                margin="0 0 14px 0",
                overflow="hidden",
                background_color="#FFFFFF",
            ),
        )
        self._cards.append({"type": ctype, "cfg": cfg, "widget": card_box})

        # remove hint if present, append card
        current = [c for c in self._canvas.children if c is not self._drop_hint]
        self._canvas.children = tuple(current) + (card_box,)

    # ── toolbar ──────────────────────────────────────────────────────────────

    def _make_toolbar(self) -> W.HBox:
        title   = W.HTML(
            '<span class="qs-toolbar-title">algo-stat Studio</span>'
        )
        subtitle = W.HTML(
            '<span class="qs-toolbar-subtitle">Drag blocks to build your dashboard</span>'
        )
        clear_btn = W.Button(description="Clear all",
                             layout=W.Layout(width="90px", height="28px"))
        clear_btn.style.button_color = "#F6F8FA"
        clear_btn.on_click(self._clear_all)
        return W.HBox(
            [title, subtitle, W.Label(""), clear_btn],
            layout=W.Layout(
                padding="10px 16px",
                align_items="center",
                border_bottom="1px solid #E1E4E8",
                background_color="#F6F8FA",
            ),
        )

    def _clear_all(self, _b=None) -> None:
        self._cards.clear()
        self._canvas.children = (self._drop_hint,)

    # ── public show() ────────────────────────────────────────────────────────

    def show(self) -> None:
        """Render the Studio widget in the current Jupyter cell."""
        _display(_HTML(_CSS))

        toolbar  = self._make_toolbar()
        sidebar  = self._make_sidebar()

        body = W.HBox(
            [sidebar, self._canvas],
            layout=W.Layout(width="100%", min_height="480px"),
        )
        root = W.VBox(
            [toolbar, body],
            layout=W.Layout(
                width="100%",
                border="1px solid #E1E4E8",
                border_radius="12px",
                overflow="hidden",
                background_color="#FFFFFF",
            ),
        )
        root.add_class("qs-studio")
        self._root = root
        _display(root)
        # NOTE: do NOT return root — Jupyter would auto-display it again
        # (causing the widget to render twice). Use `_display` only.
        return None
