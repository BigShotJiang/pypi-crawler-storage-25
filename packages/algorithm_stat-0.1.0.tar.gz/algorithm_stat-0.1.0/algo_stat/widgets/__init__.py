# © Squid Consultancy Group Ltd — All rights reserved.
# Unauthorised removal or modification of this notice is prohibited.
from __future__ import annotations
from algo_stat.widgets.studio import Studio

__all__ = ["Studio"]
