# © Squid Consultancy Group Ltd — All rights reserved.
# Unauthorised removal or modification of this notice is prohibited.
"""algo-stat CLI — `algo-stat <command> ...`."""
from __future__ import annotations
import json
import typer
from rich import print
from rich.table import Table
from rich.console import Console

import algo_stat as a

app = typer.Typer(help="algo-stat — quant analysis from your terminal.", no_args_is_help=True)
console = Console()


@app.command()
def quote(ticker: str):
    """Show fundamental snapshot for a ticker."""
    info = a.ticker_info(ticker)
    table = Table(title=f"{ticker} snapshot", show_header=True)
    table.add_column("field"); table.add_column("value")
    for k, v in info.items():
        table.add_row(k, str(v))
    console.print(table)


@app.command()
def analyze(ticker: str, period: str = "1y", chart: bool = False):
    """Print performance metrics."""
    df = a.fetch(ticker, period=period)
    perf = a.report(df, ticker=ticker, show_chart=chart)
    if chart:
        import matplotlib.pyplot as plt
        plt.show()
    print(perf)


@app.command()
def compare(tickers: str, period: str = "1y", chart: bool = False):
    """Compare multiple tickers (comma-separated)."""
    items = [t.strip() for t in tickers.split(",")]
    cmp = a.compare(items, period=period)
    print(cmp.normalized.tail())
    if chart:
        cmp.show()
        import matplotlib.pyplot as plt
        plt.show()


@app.command()
def montecarlo(ticker: str, n: int = 1000, days: int = 252, chart: bool = False):
    """Run Monte Carlo simulation."""
    mc = a.MonteCarlo(ticker).simulate(n=n, days=days)
    print(json.dumps(mc.summary(), indent=2, default=str))
    if chart:
        mc.plot()
        import matplotlib.pyplot as plt
        plt.show()


@app.command()
def backtest(ticker: str, fast: int = 20, slow: int = 50,
             period: str = "2y", chart: bool = False):
    """Backtest an SMA crossover strategy."""
    bt = a.Backtester(ticker, period=period).run(a.SMACrossover(fast, slow))
    print(json.dumps(bt.stats, indent=2))
    if chart:
        bt.plot()
        import matplotlib.pyplot as plt
        plt.show()


@app.command()
def mortgage(price: float, deposit: float, rate: float, years: int = 25):
    """Mortgage summary."""
    mc = a.MortgageCalculator(price, deposit, rate, years)
    print(json.dumps(mc.summary(), indent=2))


@app.command()
def macro(series: str = "cpi", years: int = 5):
    """Fetch a FRED macro series."""
    df = a.fred(series, years=years)
    print(df.tail())


@app.command()
def serve(host: str = "127.0.0.1", port: int = 8000, reload: bool = False):
    """Run the FastAPI server."""
    import uvicorn
    uvicorn.run("algo_stat.api:app", host=host, port=port, reload=reload)


@app.command()
def dashboard(port: int = 8501):
    """Launch the Streamlit dashboard."""
    import subprocess, sys, pathlib
    p = pathlib.Path(__file__).with_name("dashboard.py")
    subprocess.run([sys.executable, "-m", "streamlit", "run", str(p),
                    "--server.port", str(port)])


if __name__ == "__main__":
    app()
