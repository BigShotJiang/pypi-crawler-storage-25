# © Squid Consultancy Group Ltd — All rights reserved.
# Unauthorised removal or modification of this notice is prohibited.
"""Alpaca paper-trading wrapper. Requires `pip install algo-stat[trading]`."""
from __future__ import annotations
from dataclasses import dataclass

from algo_stat.config import settings


@dataclass
class Alpaca:
    paper: bool = True

    def _client(self):
        try:
            from alpaca.trading.client import TradingClient  # type: ignore
        except ImportError as e:                              # noqa: BLE001
            raise ImportError("Install with: pip install algo-stat[trading]") from e
        if not settings.alpaca_api_key or not settings.alpaca_secret_key:
            raise RuntimeError("Set ALPACA_API_KEY / ALPACA_SECRET_KEY in .env")
        return TradingClient(settings.alpaca_api_key,
                             settings.alpaca_secret_key, paper=self.paper)

    def account(self) -> dict:
        a = self._client().get_account()
        return {
            "status":         a.status,
            "equity":         float(a.equity),
            "cash":           float(a.cash),
            "buying_power":   float(a.buying_power),
            "portfolio_value": float(a.portfolio_value),
        }

    def positions(self) -> list[dict]:
        return [{"symbol": p.symbol, "qty": float(p.qty),
                 "avg_entry": float(p.avg_entry_price),
                 "market_value": float(p.market_value),
                 "unrealized_pl": float(p.unrealized_pl)}
                for p in self._client().get_all_positions()]

    def buy(self, symbol: str, qty: float) -> dict:
        from alpaca.trading.requests import MarketOrderRequest  # type: ignore
        from alpaca.trading.enums    import OrderSide, TimeInForce  # type: ignore
        order = self._client().submit_order(MarketOrderRequest(
            symbol=symbol, qty=qty, side=OrderSide.BUY, time_in_force=TimeInForce.DAY))
        return {"id": str(order.id), "symbol": order.symbol, "qty": str(order.qty)}

    def sell(self, symbol: str, qty: float) -> dict:
        from alpaca.trading.requests import MarketOrderRequest  # type: ignore
        from alpaca.trading.enums    import OrderSide, TimeInForce  # type: ignore
        order = self._client().submit_order(MarketOrderRequest(
            symbol=symbol, qty=qty, side=OrderSide.SELL, time_in_force=TimeInForce.DAY))
        return {"id": str(order.id), "symbol": order.symbol, "qty": str(order.qty)}
