# © Squid Consultancy Group Ltd — All rights reserved.
# Unauthorised removal or modification of this notice is prohibited.
from __future__ import annotations
from dataclasses import dataclass
import pandas as pd


@dataclass
class SMACrossover:
    """Simple Moving Average crossover. Long when fast > slow, flat otherwise."""
    fast: int = 20
    slow: int = 50
    allow_short: bool = False
    name: str = "SMA crossover"

    def signals(self, prices: pd.Series) -> pd.Series:
        f = prices.rolling(self.fast).mean()
        s = prices.rolling(self.slow).mean()
        sig = (f > s).astype(int)
        if self.allow_short:
            sig = sig.where(f >= s, -1)
        return sig
