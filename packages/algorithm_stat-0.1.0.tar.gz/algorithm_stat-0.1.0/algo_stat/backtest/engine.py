# © Squid Consultancy Group Ltd — All rights reserved.
# Unauthorised removal or modification of this notice is prohibited.
from __future__ import annotations
from dataclasses import dataclass
from typing import Protocol
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from algo_stat.data.market import fetch
from algo_stat.metrics.returns import _close
from algo_stat.charts.theme import stamp_figure


class Strategy(Protocol):
    name: str
    def signals(self, prices: pd.Series) -> pd.Series: ...   # 1=long, 0=flat, -1=short


@dataclass
class BacktestResult:
    equity:  pd.Series
    returns: pd.Series
    signals: pd.Series
    stats:   dict

    def plot(self, title: str = "Backtest equity"):
        from algo_stat.charts.theme import _style_axes, BG, PANEL_BG, BORDER, CYAN, GREEN, RED, GOLD
        import matplotlib.gridspec as gridspec
        import matplotlib.ticker as mticker

        eq = self.equity
        drawdown = (eq / eq.cummax() - 1) * 100

        fig = plt.figure(figsize=(15, 9), facecolor=BG)
        gs  = gridspec.GridSpec(3, 1, figure=fig, height_ratios=[3, 1, 1],
                                hspace=0.06, left=0.08, right=0.97,
                                top=0.91, bottom=0.09)
        ax1 = fig.add_subplot(gs[0])
        ax2 = fig.add_subplot(gs[1], sharex=ax1)
        ax3 = fig.add_subplot(gs[2], sharex=ax1)
        _style_axes(ax1, ax2, ax3)

        # ── equity curve ──────────────────────────────────────────────
        for lw, al in [(12, 0.03), (5, 0.12), (2, 1.0)]:
            ax1.plot(eq.index, eq.values, color=CYAN, linewidth=lw, alpha=al,
                     solid_capstyle="round")
        ax1.fill_between(eq.index, eq.values, 1.0,
                          where=(eq.values >= 1.0), color=GREEN, alpha=0.08, linewidth=0)
        ax1.fill_between(eq.index, eq.values, 1.0,
                          where=(eq.values < 1.0),  color=RED,   alpha=0.10, linewidth=0)
        ax1.axhline(1.0, color="#30363D", linewidth=1.2, linestyle="--", alpha=0.7)

        # stats badge
        s = self.stats
        badge_lines = [
            f"Return:  {s['total_return']:+.1%}",
            f"CAGR:    {s['cagr']:+.1%}",
            f"Sharpe:  {s.get('sharpe', float('nan')):.2f}",
            f"Max DD:  {s['max_dd']:.1%}",
        ]
        ax1.text(0.02, 0.97, "\n".join(badge_lines),
                 transform=ax1.transAxes, va="top", ha="left", fontsize=9.5,
                 color="white", fontfamily="monospace",
                 bbox=dict(boxstyle="round,pad=0.5", facecolor=PANEL_BG,
                           edgecolor=CYAN, linewidth=1, alpha=0.92))
        ax1.set_ylabel("Equity  ($1 base)", color="#8B949E", fontsize=11, labelpad=10)
        plt.setp(ax1.get_xticklabels(), visible=False)

        # ── drawdown ──────────────────────────────────────────────────
        ax2.fill_between(eq.index, drawdown.values, 0,
                          color=RED, alpha=0.30, linewidth=0)
        ax2.plot(eq.index, drawdown.values, color=RED, linewidth=1.2, alpha=0.9)
        ax2.axhline(0, color="#30363D", linewidth=0.8, linestyle="--", alpha=0.6)
        ax2.set_ylabel("Drawdown %", color="#8B949E", fontsize=9, labelpad=8)
        ax2.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{x:.0f}%"))
        plt.setp(ax2.get_xticklabels(), visible=False)

        # ── signal bars ───────────────────────────────────────────────
        sig = self.signals.reindex(eq.index).fillna(0)
        colors_sig = [GREEN if v > 0 else (RED if v < 0 else "#30363D") for v in sig.values]
        ax3.bar(eq.index, sig.values, color=colors_sig, width=1.5, alpha=0.85, zorder=3)
        ax3.axhline(0, color="#30363D", linewidth=0.8)
        ax3.set_ylabel("Signal", color="#8B949E", fontsize=9, labelpad=8)
        ax3.set_yticks([-1, 0, 1])
        ax3.set_yticklabels(["Short", "Flat", "Long"], color="#8B949E", fontsize=8)
        ax3.set_xlabel("Date", color="#8B949E", fontsize=10, labelpad=8)

        strat_name = s.get("strategy", "Strategy")
        fig.suptitle(f"{title}  ·  {strat_name}",
                     color="white", fontsize=16, fontweight="bold", x=0.52, y=0.97)
        fig.autofmt_xdate(rotation=30, ha="right")
        stamp_figure(fig)
        plt.close(fig)
        return fig


class Backtester:
    """Vectorized long/flat/short backtester.

    >>> bt = Backtester("NVDA", period="2y").run(SMACrossover(20, 50))
    >>> bt.stats; bt.plot()
    """
    def __init__(self, ticker: str, period: str = "1y", fee_bps: float = 1.0):
        self.ticker = ticker
        self.period = period
        self.fee = fee_bps / 1e4
        self.prices = _close(fetch(ticker, period=period))

    def run(self, strategy: Strategy) -> BacktestResult:
        sig = strategy.signals(self.prices).reindex(self.prices.index).fillna(0)
        ret = self.prices.pct_change().fillna(0)
        # apply yesterday's signal to today's return
        position = sig.shift(1).fillna(0)
        turnover = position.diff().abs().fillna(0)
        net = position * ret - turnover * self.fee
        equity = (1 + net).cumprod()

        ann = 252
        stats = {
            "strategy":    getattr(strategy, "name", type(strategy).__name__),
            "total_return": float(equity.iloc[-1] - 1),
            "cagr":        float(equity.iloc[-1] ** (ann / max(len(equity), 1)) - 1),
            "sharpe":      float(net.mean() / net.std() * np.sqrt(ann)) if net.std() else float("nan"),
            "max_dd":      float(((equity / equity.cummax()) - 1).min()),
            "trades":      int((turnover > 0).sum()),
            "fees_paid":   float((turnover * self.fee).sum()),
        }
        return BacktestResult(equity, net, sig, stats)
