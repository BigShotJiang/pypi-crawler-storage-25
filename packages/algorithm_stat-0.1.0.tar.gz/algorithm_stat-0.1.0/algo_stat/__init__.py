# © Squid Consultancy Group Ltd — All rights reserved.
# Unauthorised removal or modification of this notice is prohibited.
"""algo-stat — unified quant-finance toolkit.
© Squid Consultancy Group Ltd — All rights reserved.

3-line analysis examples:

    >>> import algo_stat as a
    >>> df = a.fetch("NVDA", period="1y")
    >>> a.report(df, ticker="NVDA")          # full text + chart report

    >>> a.compare(["AAPL","MSFT","NVDA","GOOGL"], period="2y").show()

    >>> a.MonteCarlo("NVDA").simulate(n=1000).plot()

    # FRED macro data
    >>> client = a.FredClient(api_key="YOUR_FRED_KEY")   # fredaccount.stlouisfed.org/apikeys
    >>> cpi = client.fetch("cpi", years=10)
    >>> a.FredClient.help()                  # full usage guide

    # Alpha Vantage
    >>> av = a.AlphaVantageClient(api_key="YOUR_AV_KEY")
    >>> df = av.daily("IBM")
    >>> a.AlphaVantageClient.help()          # full usage guide

    # Align any third-party API to algo_stat format
    >>> from algo_stat.data.adapter import align_ohlcv, align_series
    >>> df = align_ohlcv(raw_df, close_col="price", date_col="ts")
"""
from __future__ import annotations

# data
from algo_stat.data.market import fetch, fetch_many, ticker_info
from algo_stat.data.fred import FredClient, fred, transform as fred_transform
from algo_stat.data.universe import sp500, ftse100
from algo_stat.data.alphavantage import AlphaVantageClient
from algo_stat.data.adapter import align_ohlcv, align_series, DataAdapter

# metrics
from algo_stat.metrics.performance import cagr, sharpe, beta, alpha, performance_metrics
from algo_stat.metrics.returns import daily_returns, log_returns
from algo_stat.metrics.risk import volatility, value_at_risk, max_drawdown

# charts
from algo_stat.charts.theme import use_dark
from algo_stat.charts.price import line, candle, lines, twin
from algo_stat.charts.compare import compare, normalized_growth
from algo_stat.charts.correlation import correlation_heatmap
from algo_stat.charts.fundamentals import balance_sheet_chart
from algo_stat.charts.animate import animate_price, animate_backtest, animate_montecarlo

# derivatives
from algo_stat.derivatives.montecarlo import MonteCarlo
from algo_stat.derivatives.options import black_scholes

# backtest
from algo_stat.backtest.engine import Backtester
from algo_stat.backtest.strategies import SMACrossover

# ml
from algo_stat.ml.pca import stock_pca
from algo_stat.ml.regression import linreg, polyfit
from algo_stat.ml.classifier import SafetyClassifier

# property
from algo_stat.property.mortgage import MortgageCalculator

# reporting
from algo_stat.report import report

# interactive studio (requires ipywidgets)
from algo_stat.widgets.studio import Studio

# interactive DataFrame explorer (requires ipywidgets)
from algo_stat.explorer.explorer import DataExplorer, explore

__version__ = "0.1.0"

__all__ = [
    # data — yfinance
    "fetch", "fetch_many", "ticker_info", "fred", "fred_transform", "sp500", "ftse100",
    # data — third-party adapters
    "FredClient", "AlphaVantageClient",
    "align_ohlcv", "align_series", "DataAdapter",
    # metrics
    "cagr", "sharpe", "beta", "alpha", "performance_metrics",
    "daily_returns", "log_returns",
    "volatility", "value_at_risk", "max_drawdown",
    # charts
    "use_dark", "line", "lines", "candle", "twin", "compare", "normalized_growth",
    "correlation_heatmap", "balance_sheet_chart",
    "animate_price", "animate_backtest", "animate_montecarlo",
    # derivatives / backtest
    "MonteCarlo", "black_scholes",
    "Backtester", "SMACrossover",
    # ml / property
    "stock_pca", "linreg", "polyfit", "SafetyClassifier",
    "MortgageCalculator",
    # reporting & studio
    "report", "Studio",
    # explorer
    "DataExplorer", "explore",
]
