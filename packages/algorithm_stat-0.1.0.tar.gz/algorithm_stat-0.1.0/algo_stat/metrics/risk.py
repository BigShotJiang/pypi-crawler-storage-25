# © Squid Consultancy Group Ltd — All rights reserved.
# Unauthorised removal or modification of this notice is prohibited.
from __future__ import annotations
import numpy as np
import pandas as pd

from algo_stat.config import settings
from algo_stat.metrics.returns import _close, daily_returns


def volatility(data, annualized: bool = True) -> float:
    r = daily_returns(data)
    return float(r.std() * (np.sqrt(settings.trading_days) if annualized else 1))


def value_at_risk(data, confidence: float = 0.95, method: str = "historical") -> float:
    """Negative number → expected loss at the given confidence."""
    r = daily_returns(data)
    if method == "historical":
        return float(np.percentile(r, (1 - confidence) * 100))
    if method == "parametric":
        from scipy.stats import norm  # type: ignore
        return float(norm.ppf(1 - confidence, loc=r.mean(), scale=r.std()))
    raise ValueError(f"Unknown method: {method}")


def max_drawdown(data) -> dict:
    s = _close(data).dropna()
    cum = (1 + s.pct_change().fillna(0)).cumprod()
    peak = cum.cummax()
    dd = (cum - peak) / peak
    trough = dd.idxmin()
    peak_date = cum[:trough].idxmax()
    return {
        "max_drawdown": float(dd.min()),
        "peak_date":   str(peak_date.date()),
        "trough_date": str(trough.date()),
    }
