# © Squid Consultancy Group Ltd — All rights reserved.
# Unauthorised removal or modification of this notice is prohibited.
from __future__ import annotations
import numpy as np
import pandas as pd

from algo_stat.config import settings
from algo_stat.metrics.returns import _close, daily_returns


def cagr(data) -> float:
    s = _close(data).dropna()
    years = (s.index[-1] - s.index[0]).days / 365.25
    if years <= 0 or s.iloc[0] == 0:
        return float("nan")
    return float((s.iloc[-1] / s.iloc[0]) ** (1 / years) - 1)


def sharpe(data, rf: float | None = None, periods: int | None = None) -> float:
    rf = settings.risk_free_rate if rf is None else rf
    periods = settings.trading_days if periods is None else periods
    r = daily_returns(data)
    excess = r.mean() * periods - rf
    vol = r.std() * np.sqrt(periods)
    return float(excess / vol) if vol else float("nan")


def beta(stock, market) -> float:
    a = daily_returns(stock).rename("a")
    b = daily_returns(market).rename("b")
    df = pd.concat([a, b], axis=1).dropna()
    cov = np.cov(df["a"], df["b"])[0, 1]
    var = np.var(df["b"])
    return float(cov / var) if var else float("nan")


def alpha(stock, market, rf: float | None = None) -> float:
    rf = settings.risk_free_rate if rf is None else rf
    rs = daily_returns(stock).mean() * settings.trading_days
    rm = daily_returns(market).mean() * settings.trading_days
    return float(rs - (rf + beta(stock, market) * (rm - rf)))


def performance_metrics(data, market=None) -> dict:
    """One-call summary of all key metrics."""
    out = {
        "cagr":       cagr(data),
        "sharpe":     sharpe(data),
        "volatility": float(daily_returns(data).std() * np.sqrt(settings.trading_days)),
    }
    if market is not None:
        out["beta"]  = beta(data, market)
        out["alpha"] = alpha(data, market)
    return out
