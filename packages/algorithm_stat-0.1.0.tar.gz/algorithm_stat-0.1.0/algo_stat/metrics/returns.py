# © Squid Consultancy Group Ltd — All rights reserved.
# Unauthorised removal or modification of this notice is prohibited.
from __future__ import annotations
import numpy as np
import pandas as pd


def _close(data) -> pd.Series:
    if isinstance(data, pd.DataFrame):
        for col in ("Adj Close", "Close"):
            if col in data.columns:
                return data[col]
        return data.iloc[:, 0]
    return data


def daily_returns(data) -> pd.Series:
    return _close(data).pct_change().dropna()


def log_returns(data) -> pd.Series:
    s = _close(data)
    return np.log(s / s.shift(1)).dropna()
