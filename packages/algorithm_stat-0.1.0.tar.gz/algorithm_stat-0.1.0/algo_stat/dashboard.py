# © Squid Consultancy Group Ltd — All rights reserved.
# Unauthorised removal or modification of this notice is prohibited.
"""Streamlit dashboard — `algo-stat dashboard` or `streamlit run algo_stat/dashboard.py`."""
from __future__ import annotations
import streamlit as st
import algo_stat as a

a.use_dark()

st.set_page_config(page_title="algo-stat", layout="wide")
st.title("algo-stat — quant dashboard")

tab_perf, tab_compare, tab_mc, tab_bt, tab_mort, tab_macro, tab_opt = st.tabs(
    ["Performance", "Compare", "Monte Carlo", "Backtest", "Mortgage", "Macro", "Options"]
)

# -------- Performance --------
with tab_perf:
    c1, c2 = st.columns([1, 3])
    with c1:
        ticker = st.text_input("Ticker", "NVDA", key="perf_t")
        period = st.selectbox("Period", ["3mo", "6mo", "1y", "2y", "5y", "max"], index=2)
        run = st.button("Analyze", key="perf_run")
    if run:
        df = a.fetch(ticker, period=period)
        with c2:
            st.subheader("Metrics")
            metrics = a.performance_metrics(df)
            metrics["var95"] = a.value_at_risk(df, 0.95)
            metrics.update(a.max_drawdown(df))
            st.json(metrics)
            st.subheader("Price")
            st.pyplot(a.line(df, title=ticker, ma=[20, 50]))

# -------- Compare --------
with tab_compare:
    tickers = st.text_input("Tickers (comma-separated)", "AAPL,MSFT,NVDA,GOOGL")
    period_c = st.selectbox("Period", ["6mo", "1y", "2y", "5y"], index=1, key="cmp_p")
    if st.button("Compare"):
        cmp = a.compare([t.strip() for t in tickers.split(",")], period=period_c)
        st.pyplot(cmp.show())
        st.pyplot(cmp.correlation())

# -------- Monte Carlo --------
with tab_mc:
    t_mc  = st.text_input("Ticker", "NVDA", key="mc_t")
    n_mc  = st.slider("Paths", 100, 5000, 1000, step=100)
    d_mc  = st.slider("Days",   30, 504,  252, step=10)
    if st.button("Simulate"):
        mc = a.MonteCarlo(t_mc).simulate(n=n_mc, days=d_mc)
        st.json(mc.summary())
        st.pyplot(mc.plot())

# -------- Backtest --------
with tab_bt:
    t_bt = st.text_input("Ticker", "NVDA", key="bt_t")
    fast = st.number_input("Fast SMA", 5, 200, 20)
    slow = st.number_input("Slow SMA", 10, 400, 50)
    p_bt = st.selectbox("Period", ["1y", "2y", "5y"], index=1, key="bt_p")
    if st.button("Run backtest"):
        bt = a.Backtester(t_bt, period=p_bt).run(a.SMACrossover(int(fast), int(slow)))
        st.json(bt.stats)
        st.pyplot(bt.plot(title=f"{t_bt}  SMA{fast}/{slow}"))

# -------- Mortgage --------
with tab_mort:
    price   = st.number_input("Property price",  10_000.0, 5_000_000.0, 300_000.0, step=1000.0)
    deposit = st.number_input("Deposit",              0.0, 5_000_000.0,  60_000.0, step=1000.0)
    rate    = st.number_input("Annual rate (decimal)", 0.0, 0.20, 0.055, step=0.001, format="%.4f")
    years   = st.number_input("Years", 1, 40, 25)
    if st.button("Calculate"):
        mc = a.MortgageCalculator(price, deposit, rate, int(years))
        st.json(mc.summary())
        shock = mc.simulate_rate_shock([rate, rate + 0.01, rate + 0.02, rate + 0.03])
        st.pyplot(shock.plot())

# -------- Macro --------
with tab_macro:
    series = st.selectbox("FRED series",
        ["cpi", "core_cpi", "m2", "fed_funds", "unemployment",
         "gdp", "real_gdp", "10y_treasury", "30y_mortgage", "vix"])
    years_m = st.slider("Years", 1, 30, 5)
    if st.button("Fetch macro"):
        df = a.fred(series, years=years_m)
        st.line_chart(df)

# -------- Options --------
with tab_opt:
    cols = st.columns(6)
    S    = cols[0].number_input("S",     1.0, 100000.0, 100.0)
    K    = cols[1].number_input("K",     1.0, 100000.0, 100.0)
    T    = cols[2].number_input("T (yr)", 0.01, 10.0, 0.5)
    r    = cols[3].number_input("r",   -0.05, 0.5, 0.05)
    sig  = cols[4].number_input("σ",    0.01, 5.0, 0.25)
    q    = cols[5].number_input("q",    0.0,  1.0, 0.0)
    if st.button("Price"):
        res = a.black_scholes(S, K, T, r, sig, q)
        st.json({"call": res.call, "put": res.put, "d1": res.d1, "d2": res.d2})
