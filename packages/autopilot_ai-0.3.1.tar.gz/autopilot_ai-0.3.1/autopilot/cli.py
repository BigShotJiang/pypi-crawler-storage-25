import click
from autopilot import __version__


@click.group()
@click.version_option(__version__)
def main() -> None:
    """Autopilot — AI coding automation engine."""


@main.command()
@click.option("--backend", type=click.Choice(["claude", "codex", "opencode"]), default="claude", show_default=True)
def init(backend: str) -> None:
    """Initialize autopilot in the current project."""
    from pathlib import Path
    from autopilot.init_project import init_project

    project_path = Path.cwd()
    init_project(project_path=project_path, backend=backend)
    click.echo(f"✓ Initialized .autopilot/ in {project_path}")
    click.echo(f"  Backend: {backend}")
    click.echo(f"  Next: add your requirements to .autopilot/requirements/ then run `ap run`")


@main.command()
@click.option("--backend", type=click.Choice(["claude", "codex", "opencode"]), default=None)
@click.option("--model", default=None, help="Model override (if backend supports it)")
@click.option("--log-level", type=click.Choice(["DEBUG", "INFO", "WARNING", "ERROR"], case_sensitive=False), default=None)
def run(backend: str | None, model: str | None, log_level: str | None) -> None:
    """Start the full pipeline."""
    from pathlib import Path
    import toml
    from autopilot.backends import get_backend
    from autopilot.pipeline.engine import PipelineEngine

    project_path = Path.cwd()
    autopilot_dir = project_path / ".autopilot"

    if not autopilot_dir.exists():
        click.echo("Error: .autopilot/ not found. Run `ap init` first.", err=True)
        raise SystemExit(1)

    from autopilot.pipeline.config import PipelineConfig

    config = toml.loads((autopilot_dir / "config.toml").read_text())
    ap_cfg = config.get("autopilot", {})
    chosen_backend = backend or ap_cfg["backend"]
    max_parallel = ap_cfg.get("max_parallel", 2)
    parallel_backends_names: list[str] = ap_cfg.get("parallel_backends", [])
    effective_log_level = log_level or ap_cfg.get("log_level", "INFO")
    pipeline_config = PipelineConfig.from_toml(ap_cfg, model_override=model or "")

    _dangerous = pipeline_config.allow_dangerous_permissions
    parallel_backends = [get_backend(n, model=pipeline_config.model, allow_dangerous=_dangerous) for n in parallel_backends_names] if parallel_backends_names else []

    click.echo(f"Backend: {chosen_backend}  parallel: {max(max_parallel, len(parallel_backends))}  log: {effective_log_level}")
    engine = PipelineEngine(
        project_path=project_path,
        backend=get_backend(chosen_backend, model=pipeline_config.model, allow_dangerous=_dangerous),
        max_parallel=max_parallel,
        parallel_backends=parallel_backends,
        log_level=effective_log_level,
        pipeline_config=pipeline_config,
    )
    engine.run()


def _try_extract_interview_decisions(autopilot_dir: "Path") -> None:
    """从 INTERVIEW.md 提取技术决策并合并到 answers.json（静默失败）。"""
    try:
        from autopilot.agents.interview_extractor import merge_into_answers_json
        count = merge_into_answers_json(autopilot_dir)
        if count:
            click.echo(f"✓ 已从 INTERVIEW.md 提取 {count} 条技术决策 → answers.json")
    except Exception:
        pass  # 提取失败不阻断主流程


@main.command()
def resume() -> None:
    """Resume from last checkpoint."""
    from pathlib import Path
    import toml
    from autopilot.backends import get_backend
    from autopilot.pipeline.context import PipelineState, Phase
    from autopilot.pipeline.engine import PipelineEngine

    project_path = Path.cwd()
    autopilot_dir = project_path / ".autopilot"

    if not autopilot_dir.exists():
        click.echo("Error: .autopilot/ not found. Run `ap init` first.", err=True)
        raise SystemExit(1)

    state = PipelineState.load(autopilot_dir / "state.json")

    if state.phase == Phase.HUMAN_PAUSE:
        if state.current_feature_id or state.active_feature_ids:
            next_phase = Phase.DEV_LOOP
        elif state.post_interview_phase is not None:
            # ap add --from-requirements 场景：INTERVIEW → PLANNING
            next_phase = state.post_interview_phase
            _try_extract_interview_decisions(autopilot_dir)
        elif state.pause_reason and "interview" in (state.pause_reason or "").lower():
            # 正常首跑场景：INTERVIEW → DOC_GEN
            next_phase = Phase.DOC_GEN
            _try_extract_interview_decisions(autopilot_dir)
        else:
            next_phase = Phase.DOC_GEN
        state.phase = next_phase
        state.phase_retries = 0
        state.pause_reason = None
        state.post_interview_phase = None
        state.save(autopilot_dir / "state.json")

    from autopilot.pipeline.config import PipelineConfig

    config = toml.loads((autopilot_dir / "config.toml").read_text())
    ap_cfg = config.get("autopilot", {})
    max_parallel = ap_cfg.get("max_parallel", 2)
    parallel_backends_names: list[str] = ap_cfg.get("parallel_backends", [])
    effective_log_level = ap_cfg.get("log_level", "INFO")
    pipeline_config = PipelineConfig.from_toml(ap_cfg)

    _dangerous = pipeline_config.allow_dangerous_permissions
    parallel_backends = [get_backend(n, model=pipeline_config.model, allow_dangerous=_dangerous) for n in parallel_backends_names] if parallel_backends_names else []
    engine = PipelineEngine(
        project_path=project_path,
        backend=get_backend(ap_cfg["backend"], model=pipeline_config.model, allow_dangerous=_dangerous),
        max_parallel=max_parallel,
        parallel_backends=parallel_backends,
        log_level=effective_log_level,
        pipeline_config=pipeline_config,
    )
    click.echo(f"Resuming from phase: {state.phase.value}")
    engine.run()


@main.command()
def status() -> None:
    """Show current pipeline status."""
    from pathlib import Path
    from autopilot.pipeline.context import PipelineState, FeatureList, RunResult

    autopilot_dir = Path.cwd() / ".autopilot"
    if not autopilot_dir.exists():
        click.echo("Not initialized. Run `ap init` first.")
        return

    run_result_path = autopilot_dir / "run_result.json"
    if run_result_path.exists():
        rr = RunResult.load(run_result_path)
        click.echo(f"状态: {rr.status}")
        click.echo(f"Phase: {rr.phase}")
        click.echo(f"耗时: {rr.elapsed_seconds}s")
        click.echo(f"Features: {rr.features_done}/{rr.features_total}")
        click.echo(f"知识条数: {rr.knowledge_count}")
        click.echo(f"时间: {rr.timestamp}")
        if rr.pause_reason:
            click.echo(f"暂停原因: {rr.pause_reason}")
        return

    state = PipelineState.load(autopilot_dir / "state.json")
    click.echo(f"Phase: {state.phase.value}")
    click.echo(f"Retries: {state.phase_retries}")
    if state.current_feature_id:
        click.echo(f"Feature: {state.current_feature_id}")
    if state.pause_reason:
        click.echo(f"Pause reason: {state.pause_reason}")

    fl_path = autopilot_dir / "feature_list.json"
    if fl_path.exists():
        fl = FeatureList.load(fl_path)
        done = sum(1 for f in fl.features if f.status == "completed")
        click.echo(f"Progress: {done}/{len(fl.features)} features")


@main.command()
def pause() -> None:
    """Pause the pipeline."""
    click.echo("Pausing...")


@main.command(name="add")
@click.argument("title_or_reqfile")
@click.option("--phase", default="backend", type=click.Choice(["backend", "frontend", "fullstack", "infra"]), show_default=True)
@click.option("--depends-on", "depends_on", default="", help="Comma-separated feature IDs this depends on")
@click.option("--test-file", "test_file", default="", help="Test file path")
@click.option("--from-requirements", "from_requirements", is_flag=True, default=False,
              help="Treat argument as a requirements file in .autopilot/requirements/ and re-run planning")
def add_feature(title_or_reqfile: str, phase: str, depends_on: str, test_file: str, from_requirements: bool) -> None:
    """Add new feature(s) to the backlog.

    \b
    Simple mode (quick, single feature):
      ap add "支付宝支付接口" --phase backend --depends-on feat-010

    \b
    Requirements mode (complex, re-runs AI planning for new req doc):
      1. Write new requirements to .autopilot/requirements/payment.md
      2. ap add payment.md --from-requirements
      → Triggers PLANNING phase to decompose new requirements into features
    """
    from pathlib import Path
    from autopilot.pipeline.context import FeatureList, Feature, PipelineState, Phase

    autopilot_dir = Path.cwd() / ".autopilot"
    state = PipelineState.load(autopilot_dir / "state.json")

    if from_requirements:
        # Requirements mode: run INTERVIEW first (to clarify new requirements),
        # then go to PLANNING (not DOC_GEN — existing docs stay, we just extend the plan)
        req_file = autopilot_dir / "requirements" / title_or_reqfile
        if not req_file.exists():
            click.echo(f"Error: requirements file not found: {req_file}", err=True)
            raise SystemExit(1)
        state.phase = Phase.INTERVIEW
        state.phase_retries = 0
        state.current_feature_id = None
        state.active_feature_ids = []
        state.post_interview_phase = Phase.PLANNING
        state.save(autopilot_dir / "state.json")
        click.echo(f"✓ Requirements file: {req_file.name}")
        click.echo("  Starting INTERVIEW → PLANNING flow.")
        click.echo("  Run `ap resume` — autopilot will clarify requirements, then decompose into features.")
        return

    # Simple mode: directly add a single feature
    fl_path = autopilot_dir / "feature_list.json"
    if not fl_path.exists():
        click.echo("Error: feature_list.json not found. Run `ap run` first.", err=True)
        raise SystemExit(1)

    fl = FeatureList.load(fl_path)
    existing_nums = []
    for f in fl.features:
        try:
            existing_nums.append(int(f.id.split("-")[1]))
        except (IndexError, ValueError):
            pass
    next_num = max(existing_nums, default=0) + 1
    new_id = f"feat-{next_num:03d}"

    dep_list = [d.strip() for d in depends_on.split(",") if d.strip()]
    if dep_list:
        existing_ids = {f.id for f in fl.features}
        missing = [d for d in dep_list if d not in existing_ids]
        if missing:
            click.echo(f"Error: unknown dependency IDs: {', '.join(missing)}", err=True)
            raise SystemExit(1)
        if new_id in dep_list:
            click.echo(f"Error: feature cannot depend on itself", err=True)
            raise SystemExit(1)

    new_feature = Feature(
        id=new_id,
        title=title_or_reqfile,
        phase=phase,
        depends_on=dep_list,
        status="pending",
        test_file=test_file or f"tests/test_{new_id.replace('-', '_')}.py",
    )
    fl.features.append(new_feature)
    fl.save(fl_path)

    if state.phase in (Phase.DONE, Phase.DELIVERY, Phase.KNOWLEDGE, Phase.DOC_UPDATE):
        state.phase = Phase.DEV_LOOP
        state.phase_retries = 0
        state.save(autopilot_dir / "state.json")
        click.echo(f"✓ Added {new_id}: {title_or_reqfile}")
        click.echo("  Pipeline reset to DEV_LOOP. Run `ap resume` to start development.")
    else:
        click.echo(f"✓ Added {new_id}: {title_or_reqfile}")
        click.echo("  Feature queued — will be picked up automatically in DEV_LOOP.")


@main.command(name="redo")
@click.argument("feature_id", required=False, default=None)
@click.option("--and-dependents", "and_dependents", is_flag=True, default=False,
              help="Also reset features that depend on this one")
@click.option("--failed", "failed", is_flag=True, default=False,
              help="Reset ALL failed features to pending")
def redo_feature(feature_id: str | None, and_dependents: bool, failed: bool) -> None:
    """Re-run a specific feature (reset to pending and resume).

    \b
    Examples:
      ap redo feat-005                     # redo a single feature
      ap redo feat-005 --and-dependents    # redo + all features that depend on it
      ap redo --failed                     # redo ALL failed features at once
    """
    from pathlib import Path
    from autopilot.pipeline.context import FeatureList, PipelineState, Phase

    if not failed and feature_id is None:
        click.echo("Error: provide a FEATURE_ID or use --failed to reset all failed features.", err=True)
        raise SystemExit(1)

    autopilot_dir = Path.cwd() / ".autopilot"
    fl_path = autopilot_dir / "feature_list.json"
    if not fl_path.exists():
        click.echo("Error: feature_list.json not found.", err=True)
        raise SystemExit(1)

    fl = FeatureList.load(fl_path)

    if failed:
        target_ids = {f.id for f in fl.features if f.status == "failed"}
        if not target_ids:
            click.echo("No failed features found.")
            return
    else:
        assert feature_id is not None
        target_ids = {feature_id}
        if and_dependents:
            changed = True
            while changed:
                changed = False
                for f in fl.features:
                    if f.id not in target_ids and any(d in target_ids for d in f.depends_on):
                        target_ids.add(f.id)
                        changed = True

    reset_count = 0
    for f in fl.features:
        if f.id in target_ids:
            f.status = "pending"
            f.fix_retries = 0
            reset_count += 1

    if reset_count == 0:
        click.echo(f"Error: feature '{feature_id}' not found.", err=True)
        raise SystemExit(1)

    fl.save(fl_path)

    # Reset pipeline state to DEV_LOOP
    state = PipelineState.load(autopilot_dir / "state.json")
    if state.phase in (Phase.DONE, Phase.DOC_UPDATE, Phase.KNOWLEDGE, Phase.DELIVERY):
        state.phase = Phase.DEV_LOOP
    state.phase_retries = 0
    state.current_feature_id = None
    state.active_feature_ids = []
    state.save(autopilot_dir / "state.json")

    for fid in sorted(target_ids):
        click.echo(f"  ↩ Reset: {fid}")
    click.echo(f"✓ {reset_count} feature(s) reset to pending. Run `ap resume` to re-develop.")




@main.command(name="check")
def check() -> None:
    """Pre-flight validation: verify autopilot is ready to run.

    Checks: config validity, backend CLIs installed, git repo, env vars.
    """
    import shutil
    import os
    from pathlib import Path
    import toml
    from autopilot.pipeline.config import PipelineConfig

    project_path = Path.cwd()
    autopilot_dir = project_path / ".autopilot"

    ok = True

    def _pass(msg: str) -> None:
        click.echo(f"  ✓  {msg}")

    def _fail(msg: str) -> None:
        nonlocal ok
        ok = False
        click.echo(f"  ✗  {msg}")

    def _warn(msg: str) -> None:
        click.echo(f"  ⚠  {msg}")

    click.echo("=== autopilot pre-flight check ===\n")

    # 1. .autopilot/ exists
    click.echo("[1/5] Project structure")
    if not autopilot_dir.exists():
        _fail(".autopilot/ not found — run `ap init` first")
        click.echo("\n✗ Pre-flight FAILED. Fix the issues above and re-run `ap check`.")
        raise SystemExit(1)
    _pass(".autopilot/ exists")

    config_path = autopilot_dir / "config.toml"
    if not config_path.exists():
        _fail("config.toml not found")
        ok = False
    else:
        _pass("config.toml exists")

    state_path = autopilot_dir / "state.json"
    _pass("state.json exists") if state_path.exists() else _warn("state.json not found (will be created on first run)")

    req_dir = autopilot_dir / "requirements"
    req_files = list(req_dir.glob("*.md")) + list(req_dir.glob("*.txt")) if req_dir.exists() else []
    non_readme = [f for f in req_files if f.name.lower() != "readme.md"]
    if non_readme:
        _pass(f"requirements/ has {len(non_readme)} file(s)")
    else:
        _warn("requirements/ has no requirement files — add one before running `ap run`")

    # 2. config.toml valid
    click.echo("\n[2/5] Configuration")
    ap_cfg: dict = {}
    if config_path.exists():
        try:
            raw = toml.loads(config_path.read_text(encoding="utf-8"))
            ap_cfg = raw.get("autopilot", {})
            PipelineConfig.from_toml(ap_cfg)
            _pass("config.toml parses OK")
        except Exception as exc:
            _fail(f"config.toml invalid: {exc}")

    backend_name: str = ap_cfg.get("backend", "claude")
    parallel_backends: list[str] = ap_cfg.get("parallel_backends", [])
    all_backend_names = list({backend_name} | set(parallel_backends))

    # 3. Backend CLIs
    click.echo("\n[3/5] Backend CLIs")
    CLI_MAP = {
        "claude":    ("claude",    "Claude Code CLI"),
        "codex":     ("codex",     "OpenAI Codex CLI"),
        "opencode":  ("opencode",  "OpenCode CLI"),
    }
    for bn in all_backend_names:
        cli_bin, cli_label = CLI_MAP.get(bn, (bn, bn))
        if shutil.which(cli_bin):
            _pass(f"{cli_label} (`{cli_bin}`) found in PATH")
        else:
            _fail(f"{cli_label} (`{cli_bin}`) not found — install it first")

    # 4. Environment variables
    click.echo("\n[4/5] Environment variables")
    telegram_enabled = bool(ap_cfg.get("notifications", {}).get("enabled", False))
    if telegram_enabled:
        for var in ("AUTOPILOT_TELEGRAM_TOKEN", "AUTOPILOT_TELEGRAM_CHAT_ID"):
            if os.environ.get(var):
                _pass(f"{var} set")
            else:
                _fail(f"{var} not set (required — Telegram notifications are enabled)")
    else:
        _pass("Telegram disabled — no env vars needed")

    # 5. Git repo
    click.echo("\n[5/5] Git repository")
    git_dir = project_path / ".git"
    if git_dir.exists():
        _pass(".git/ found — auto-commit will work")
    else:
        auto_commit = ap_cfg.get("auto_commit", True)
        if auto_commit:
            _warn(".git/ not found — auto_commit is enabled but this is not a git repo (will be skipped at runtime)")
        else:
            _pass("Not a git repo, but auto_commit = false — OK")

    click.echo("")
    if ok:
        click.echo("✓ Pre-flight passed. You're good to go — run `ap run`.")
    else:
        click.echo("✗ Pre-flight FAILED. Fix the issues above and re-run `ap check`.")
        raise SystemExit(1)


@main.group()
def sessions() -> None:
    """Inspect past pipeline sessions."""


@sessions.command(name="list")
def sessions_list() -> None:
    """List all recorded sessions."""
    from pathlib import Path
    from autopilot.sessions.reader import list_sessions, format_list

    sessions_dir = Path.cwd() / ".autopilot" / "sessions"
    click.echo(format_list(list_sessions(sessions_dir)))


@sessions.command(name="show")
@click.argument("session_id")
@click.option("--feature", "feature_id", default=None, help="Filter to a specific feature ID")
@click.option("--output", "show_output", is_flag=True, default=False, help="Show agent output tails")
def sessions_show(session_id: str, feature_id: str | None, show_output: bool) -> None:
    """Show detailed timeline for a session.

    Use 'latest' to show the most recent session.
    Prefix matching is supported (first 8 chars are enough).
    """
    from pathlib import Path
    from autopilot.sessions.reader import list_sessions, format_show

    sessions_dir = Path.cwd() / ".autopilot" / "sessions"

    if session_id == "latest":
        all_sessions = list_sessions(sessions_dir)
        if not all_sessions:
            click.echo("No sessions found.")
            return
        path = all_sessions[0]["path"]
    else:
        exact = sessions_dir / f"{session_id}.jsonl"
        if exact.exists():
            path = exact
        else:
            matches = list(sessions_dir.glob(f"{session_id}*.jsonl")) if sessions_dir.exists() else []
            if len(matches) == 1:
                path = matches[0]
            elif not matches:
                click.echo(f"Session not found: {session_id}", err=True)
                raise SystemExit(1)
            else:
                click.echo(f"Ambiguous session ID prefix '{session_id}', matches:", err=True)
                for m in matches:
                    click.echo(f"  {m.stem}", err=True)
                raise SystemExit(1)

    click.echo(format_show(path, feature_filter=feature_id, show_output=show_output))


@main.group()
def knowledge() -> None:
    """Manage knowledge base."""


@knowledge.command(name="list")
def knowledge_list() -> None:
    """List knowledge entries."""
    from pathlib import Path
    kb_dir = Path.cwd() / ".autopilot" / "knowledge"
    if not kb_dir.exists():
        click.echo("No knowledge base found.")
        return
    for md in sorted(kb_dir.rglob("*.md")):
        click.echo(f"  {md.relative_to(kb_dir)}")


@knowledge.command(name="search")
@click.argument("query")
def knowledge_search(query: str) -> None:
    """Search local knowledge base."""
    from pathlib import Path
    from autopilot.knowledge.local import LocalKnowledge

    kb = LocalKnowledge(Path.cwd() / ".autopilot" / "knowledge")
    local_content = kb.read_all()

    matches = [line for line in local_content.splitlines() if query.lower() in line.lower()]
    if matches:
        for m in matches[:10]:
            click.echo(f"  {m}")
    else:
        click.echo("No matches found.")
