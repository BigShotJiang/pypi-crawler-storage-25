# Examples

Ready-to-run drt configurations. Each directory is a self-contained project.

| Example | Source | Destination | Notes |
|---|---|---|---|
| [quickstart](./quickstart/) | DuckDB | httpbin.org/post | **Start here** — zero external credentials |
| [duckdb_to_slack](./duckdb_to_slack/) | DuckDB | Slack | Requires `SLACK_WEBHOOK_URL` |
| [notify_slack](./notify_slack/) | DuckDB | Slack | Alert-style notification pattern |
| [bigquery_to_hubspot](./bigquery_to_hubspot/) | BigQuery | HubSpot | Requires GCP + HubSpot credentials |
| [bigquery_to_github_actions](./bigquery_to_github_actions/) | BigQuery | GitHub Actions | Trigger workflows from query results |
| [duckdb_to_google_sheets](./duckdb_to_google_sheets/) | DuckDB | Google Sheets | Requires GCP service account |
| [sqlite_to_google_sheets](./sqlite_to_google_sheets/) | SQLite | Google Sheets | Requires GCP service account |
| [postgres_to_slack](./postgres_to_slack/) | PostgreSQL | Slack | Incremental sync, requires `SLACK_WEBHOOK_URL` |

Start with `quickstart/` if you are new to drt — it requires no cloud accounts and
runs end-to-end in about 5 minutes.
