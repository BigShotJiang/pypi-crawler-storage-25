from setuptools import setup, find_packages

setup(
    name="aboutpc",
    version="0.2.5",
    packages=find_packages(),
    entry_points={
        "console_scripts": [
            "aboutpc=aboutpc.main:main",
        ],
    },
)