__version__ = '0.2618.0'

banner = f'    * * * *    setux {__version__}    * * * *'
