# Phase 5 Sailbox Voyage Runbook

This runbook covers the Phase 5 demo path: a controller harness creates a
Sailbox, starts one Voyage, records Sailbox work with Voyage spans/events,
calls Sail inference, and inspects the result in the Phase 3 dashboard.

## Mental Model

One background task maps to one Voyage.

In Phase 5, the controller process owns telemetry:

- The controller creates or finds the Sail app.
- The controller creates and terminates the Sailbox.
- The controller calls `sail.voyage.init(..., sailbox_id=sb.sailbox_id)`.
- The controller records events around Sailbox work.
- The controller calls `sail.inference.*` so model calls include the Voyage
  header.

Do not put `SAIL_API_KEY` in `Sailbox.exec()` commands, image env, setup
scripts, stdout/stderr, Voyage payloads, or logs. Guest-process credential
injection is a Phase 6 design problem, not part of this smoke.

## Live Environment

The Sailbox smoke is live-only and guarded. Without `SAIL_PHASE5_LIVE=1`, the
example prints setup instructions and exits without creating a Sailbox or
calling inference.

Use staging and a dedicated internal org-bearing `sk_...` key for dashboard
validation:

```bash
cd sdk/python
export SAIL_PHASE5_LIVE=1
export SAIL_MODE=staging
export SAIL_API_KEY="sk_..." # dedicated internal key mapped to your Clerk org
unset SAIL_VOYAGE_ID        # this smoke must create a fresh Voyage
```

The example rejects missing keys, non-`sk_` keys, and ambient
`SAIL_VOYAGE_ID` before live calls. Do not use arbitrary customer keys for this
smoke.

Optional overrides:

```bash
export SAIL_PHASE5_MODEL="openai/gpt-oss-20b"
export SAIL_PHASE5_APP_NAME="phase5-sailbox-voyage-smoke"
export SAIL_PHASE5_STEPS=25        # denser timeline for pagination checks
export SAIL_PHASE5_FORCE_FAIL=1    # exercise failed terminal state
```

## Run The Smoke

```bash
uv run python examples/voyage_sailbox_agent_smoke.py
```

On success, the script prints JSON with:

- `run_id`
- `voyage_id`
- `dashboard_url`
- `sailbox_id`
- `responses_id`
- `exec_request_id`
- `steps`
- redacted/capped `stdout` and `stderr` tails

It also prints a dashboard checklist. The command run inside the Sailbox is
static and credential-free.

## Arcanist Demo Script

Use this exact sequence for the Phase 5 demo packet. It runs one successful
Sailbox-backed Voyage and one forced-failure Voyage.

```bash
cd sdk/python

export SAIL_PHASE5_LIVE=1
export SAIL_MODE=staging
export SAIL_API_KEY="sk_..." # dedicated internal key mapped to your Clerk org
unset SAIL_VOYAGE_ID

# Success: dense enough to inspect spans, events, model-call correlation, and
# timeline paging without adding more model or Sailbox calls.
export SAIL_PHASE5_STEPS=25
unset SAIL_PHASE5_FORCE_FAIL
uv run python examples/voyage_sailbox_agent_smoke.py

# Failure: validates terminal failed state and cleanup visibility.
export SAIL_PHASE5_FORCE_FAIL=1
uv run python - <<'PY'
import json
import sail

from examples.voyage_sailbox_agent_smoke import run_smoke

try:
    run_smoke()
except Exception as exc:
    print(json.dumps({
        "expected_failure": str(exc),
        "voyage_id": sail.voyage.id(),
        "dashboard_url": sail.voyage.dashboard_url(),
    }, indent=2, sort_keys=True))
    raise SystemExit(1)
else:
    raise SystemExit("expected forced failure")
PY
```

Record the printed `voyage_id` and `dashboard_url` for both runs. The forced
failure wrapper exits non-zero after printing that handoff JSON. Do not paste
API keys, stdout/stderr secrets, or customer data into the demo notes.

## Dashboard Checks

Open the printed `dashboard_url`, or build the preview URL manually:

```text
<preview-url>/staging/voyages/<voyage_id>
```

Verify:

- The Identity/Sailbox row shows the `sailbox_id`.
- Exactly one `voyage.started` event appears.
- Controller/model/Sailbox spans render.
- `controller.started` includes task payload fields.
- `controller.model_call.created` includes `response_id`.
- `sailbox.exec.completed` includes `exec_request_id`, return code, duration,
  and redacted stdout/stderr tails.
- `controller.step.completed` rows appear in ascending step order. With
  `SAIL_PHASE5_STEPS=25`, there should be 25 step events and matching progress
  spans.
- A model-call row is correlated through `X-Sail-Voyage-Id`.
- Terminal status is `completed`.
- No API key or bearer token appears in event payloads, stdout, stderr, or the
  terminal JSON.

## Negative Checks

These checks should not create live resources:

```bash
SAIL_PHASE5_LIVE=0 uv run python examples/voyage_sailbox_agent_smoke.py
```

Expected: setup instructions print and no Sailbox/inference requests are made.

```bash
SAIL_PHASE5_LIVE=1 SAIL_API_KEY=not-an-sk-key \
  uv run python examples/voyage_sailbox_agent_smoke.py
```

Expected: the script fails before Sail app lookup, Sailbox create, Voyage init,
or inference.

```bash
SAIL_PHASE5_LIVE=1 SAIL_API_KEY=sk_dummy SAIL_VOYAGE_ID=voy_00000000-0000-0000-0000-000000000001 \
  uv run python examples/voyage_sailbox_agent_smoke.py
```

Expected: the script rejects the ambient Voyage id before live calls. This
smoke is controller-owned and must create a fresh Voyage so the dashboard shows
exactly one `voyage.started` and the new Identity/Sailbox row value.

## Failure And Long-Run Modes

Use forced failure to verify terminal failed state and Sailbox cleanup:

```bash
SAIL_PHASE5_FORCE_FAIL=1 uv run python examples/voyage_sailbox_agent_smoke.py
```

Expected:

- The script exits non-zero.
- The Voyage is marked `failed`.
- The error section shows `RuntimeError` and `Forced Phase 5 smoke failure`.
- The Sailbox is still terminated in `finally`.
- No secret appears in payloads, stdout, stderr, or terminal output.

Use long-run density to validate timeline pagination without increasing model
or Sailbox cost:

```bash
SAIL_PHASE5_STEPS=25 uv run python examples/voyage_sailbox_agent_smoke.py
```

Expected:

- `controller.step.completed` events render in order from 1 through 25.
- Progress spans render around those step events.
- The model-call row remains correlated to the same Voyage.
- Terminal status is `completed` unless `SAIL_PHASE5_FORCE_FAIL=1` is also set.

## Demo Checklist

Successful run:

- Dashboard opens to the printed Voyage id.
- The Identity/Sailbox row shows the `sailbox_id`.
- Exactly one `voyage.started` event appears.
- Controller/model/Sailbox/progress spans render in sequence order.
- `sailbox.exec.completed` includes `exec_request_id`, return code, duration,
  and redacted stdout/stderr tails.
- A model-call row is correlated through `X-Sail-Voyage-Id`.
- Terminal status is `completed`.

Forced-failure run:

- Dashboard opens to the Voyage id printed by the forced-failure wrapper.
- The Error section shows `RuntimeError` and `Forced Phase 5 smoke failure`.
- `controller.force_fail.requested` appears before `voyage.failed`.
- The Sailbox was terminated; if termination failed, the CLI prints a cleanup
  warning and the Voyage is not marked completed.
- No API key or bearer token appears in payloads, stdout, stderr, or terminal
  output.

Do not check in screenshots. If screenshots are needed for a demo thread, keep
them outside the repository and use the checklist above as the source of truth.

## Local Verification

From the repo root:

```bash
just test-python-sdk
just python-sdk-build
just format
```

From `sdk/python`, the no-live guard is safe to run locally:

```bash
uv run python examples/voyage_sailbox_agent_smoke.py
```

Expected exit code: `2`. Expected side effect: none.

## Troubleshooting

If the Voyage exists but the dashboard does not show it, confirm the API key is
an internal org-bearing `sk_...` key mapped to the same Clerk org as your
dashboard session.

If the detail page renders the environment-unavailable card, the app deploy
does not have a read-only database pool configured for the requested `env`
segment.

If model-call rows are missing but events are present, confirm the inference
call went through `sail.inference.responses.create()` or a raw client using
`sail.voyage.headers()`.

If the Sailbox is left running after a failed local interruption, terminate it
through the normal Sailbox tooling before re-running the smoke.
