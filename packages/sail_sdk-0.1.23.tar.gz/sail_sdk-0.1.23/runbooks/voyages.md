# Python SDK Voyages Runbook

This runbook covers the Phase 4 Python SDK surface:

- `sail.voyage`
- `sail.inference.responses.create`
- `sail.inference.chat.completions.create`
- `sail.voyage.headers()` for raw clients

Use a dedicated internal org-bearing `sk_...` key for live smoke tests. Do not
run Voyage or inference smoke tests with arbitrary customer keys, and do not
use legacy `sr-` keys for dashboard validation because Voyage dashboard org
mapping depends on org-bearing keys.

## Local Verification

From the repo root:

```bash
just test-python-sdk
just python-sdk-build
just format
```

The Python SDK source stays Python 3.9 compatible and has no new runtime
dependencies beyond the existing package dependencies.

## Live Smoke Environment

Pick the deployed environment you intend to validate:

```bash
cd sdk/python
export SAIL_API_KEY=sk_...
export SAIL_MODE=staging
```

Use `SAIL_MODE=prod` for production. Use `SAIL_API_URL=https://...` only when
testing a specific REST API URL directly.

Optional defaults:

```bash
export SAILBOX_ID=sbx_...
export SAIL_AGENT_ID=agent_solver
export SAIL_AGENT_NAME=Solver
export SAIL_AGENT_ROLE=executor
export SAIL_VOYAGE_DEBUG=1
```

## Voyage Smoke

Run:

```bash
uv run python examples/voyage_smoke.py
```

Expected terminal output includes:

- Voyage ID
- Dashboard URL

Open the dashboard URL and verify:

- Voyage metadata renders.
- `voyage.started` appears.
- `planner.started` appears.
- `span.started` and `span.completed` appear.
- Agent metadata appears.
- A model-call row appears from `sail.inference.responses.create`.
- `complete()` marks the Voyage completed.

## Child Attach Smoke

Run:

```bash
uv run python examples/voyage_child_attach.py
```

The parent creates the Voyage, passes `SAIL_VOYAGE_ID` and `SAIL_API_KEY` to
the child, and the child attaches with `sail.voyage.init()`. Verify that the
dashboard shows parent and child events in the same Voyage and only one
`voyage.started`.

## Sailbox-Backed Smoke

Phase 5 adds a live Sailbox-backed Voyage smoke. It creates a Sailbox, starts a
Voyage with `sailbox_id`, calls Sail inference, records Sailbox exec telemetry,
and terminates the Sailbox.

Use it only with an internal org-bearing `sk_...` key and the explicit live
guard:

```bash
export SAIL_PHASE5_LIVE=1
uv run python examples/voyage_sailbox_agent_smoke.py
```

See [phase5-sailbox-voyage.md](phase5-sailbox-voyage.md) for the full setup,
dashboard checklist, and negative checks.

## Raw Headers Smoke

Use `sail.voyage.headers()` when testing custom HTTP clients or streaming
clients:

```python
import json
import os
import urllib.request

import sail

sail.voyage.init(name="raw-client-smoke")

api_urls = {
    "prod": "https://api.sailresearch.com",
    "dev": "https://dev.sailresearch.com",
    "staging": "https://staging.sailresearch.com",
    "local": "https://dev.sailresearch.com",
}
mode = os.environ.get("SAIL_MODE", "prod").strip().lower() or "prod"
api_url = os.environ.get("SAIL_API_URL", "").strip() or api_urls[mode]

headers = sail.voyage.headers({"Content-Type": "application/json"})
headers["Authorization"] = "Bearer " + os.environ["SAIL_API_KEY"]

req = urllib.request.Request(
    api_url.rstrip("/") + "/v1/responses",
    data=json.dumps({"model": "openai/gpt-oss-20b", "input": "hello"}).encode(),
    headers=headers,
    method="POST",
)
with urllib.request.urlopen(req) as resp:
    print(resp.status)

sail.voyage.complete()
```

## Delivery Semantics

- `event()` validates local input, enqueues quickly, and does not raise network
  errors.
- The background flusher sends buffered events periodically and in batches.
- `flush()`, `complete()`, and `fail()` block and raise delivery errors.
- Process exit performs a bounded best-effort flush only.
- Missing `SAIL_API_KEY` makes `sail.voyage` a no-op for local scripts, but
  `sail.inference` still requires an API key.

## Limitations

The v0 SDK does not include:

- streaming inference wrappers
- native async helpers
- an agent framework
- orchestration
- swarms
- memory graphs
- tool abstractions
- an OpenAI client factory
- Sailbox auto-binding
