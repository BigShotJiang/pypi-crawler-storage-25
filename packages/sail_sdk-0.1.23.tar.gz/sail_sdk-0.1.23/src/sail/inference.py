from __future__ import annotations

from typing import Any, Dict, Mapping, Optional

import sail.voyage as voyage_module
from sail._http_client import HTTPClient
from sail.errors import InferenceError, InferenceHTTPError

_STREAM_UNSUPPORTED_MESSAGE = (
    "stream=True is not supported by sail-sdk inference wrapper in v0; "
    "use a raw client with sail.voyage.headers()."
)


class _ResponsesResource:
    def create(
        self,
        *,
        voyage: Optional[Any] = None,
        headers: Optional[Mapping[str, str]] = None,
        timeout: Optional[float] = None,
        **payload: Any,
    ) -> Dict:
        return _post_inference(
            "/v1/responses",
            payload,
            voyage=voyage,
            headers=headers,
            timeout=timeout,
        )


class _ChatCompletionsResource:
    def create(
        self,
        *,
        voyage: Optional[Any] = None,
        headers: Optional[Mapping[str, str]] = None,
        timeout: Optional[float] = None,
        **payload: Any,
    ) -> Dict:
        return _post_inference(
            "/v1/chat/completions",
            payload,
            voyage=voyage,
            headers=headers,
            timeout=timeout,
        )


class _ChatResource:
    def __init__(self) -> None:
        self.completions = _ChatCompletionsResource()


responses = _ResponsesResource()
chat = _ChatResource()


def _post_inference(
    path: str,
    payload: Dict[str, Any],
    *,
    voyage: Optional[Any],
    headers: Optional[Mapping[str, str]],
    timeout: Optional[float],
) -> Dict:
    if payload.get("stream") is True:
        raise InferenceError(_STREAM_UNSUPPORTED_MESSAGE)

    request_headers = _merge_voyage_headers(voyage=voyage, headers=headers)
    try:
        client = HTTPClient()
    except ValueError as exc:
        raise InferenceError(str(exc)) from exc

    status, data = client.post(
        path,
        payload,
        headers=request_headers,
        timeout=timeout,
    )
    if status >= 400:
        _raise_inference_http_error(status, data)
    return data


def _merge_voyage_headers(
    *,
    voyage: Optional[Any],
    headers: Optional[Mapping[str, str]],
) -> Dict[str, str]:
    selected_voyage = voyage if voyage is not None else voyage_module._get_current()
    if selected_voyage is None:
        return dict(headers or {})
    return voyage_module._inference_headers(selected_voyage, headers)


def _raise_inference_http_error(status: int, data: Mapping[str, Any]) -> None:
    message = _error_message(data, "failed to create inference response")
    raise InferenceHTTPError(status, message, dict(data))


def _error_message(data: Mapping[str, Any], fallback: str) -> str:
    err = data.get("error")
    if isinstance(err, dict):
        message = err.get("message")
        if isinstance(message, str) and message:
            return message
    return fallback
