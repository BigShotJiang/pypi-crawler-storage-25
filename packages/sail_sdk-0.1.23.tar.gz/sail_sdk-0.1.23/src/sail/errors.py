from __future__ import annotations

from typing import Any, Dict, Optional


class SailError(Exception):
    """Base class for Sail SDK errors."""


class SailboxError(SailError):
    """Base class for sailbox-specific SDK errors."""


class SailboxCreationError(SailboxError):
    """Raised when sailbox creation fails."""


class ImageBuildError(SailboxError):
    """Raised when a custom image build fails."""


class SailboxExecutionError(SailboxError):
    """Base class for sailbox exec-related SDK errors."""


class SailboxTerminatedError(SailboxExecutionError):
    """Raised when a sailbox no longer exists on the worker."""


class SailboxExecAlreadyRunningError(SailboxExecutionError):
    """Raised when another exec request is already active for the sailbox."""


class SailboxExecRequestNotFoundError(SailboxExecutionError):
    """Raised when a wait references an unknown exec request."""


class SailboxWorkerLostError(SailboxExecutionError):
    """Raised when the assigned worker became unreachable and recovery is required."""


class SailboxFunctionError(SailboxExecutionError):
    """Raised when a Python function fails while running in a sailbox."""

    def __init__(
        self,
        message: str,
        *,
        error_type: str = "",
        traceback: str = "",
        stdout: str = "",
        stderr: str = "",
    ):
        super().__init__(message)
        self.error_type = error_type
        self.traceback = traceback
        self.stdout = stdout
        self.stderr = stderr


class SailboxFunctionSerializationError(SailboxExecutionError):
    """Raised when a Python function payload or result cannot be serialized."""


class VoyageError(SailError):
    """Base class for Voyage SDK errors."""


class VoyageHTTPError(VoyageError):
    """Raised when the Voyage API returns an HTTP error."""

    def __init__(
        self,
        status_code: int,
        message: str,
        response: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.response = response


class VoyageNotFoundError(VoyageHTTPError):
    """Raised when a Voyage cannot be found for the current API key."""


class InferenceError(SailError):
    """Base class for Sail inference wrapper errors."""


class InferenceHTTPError(InferenceError):
    """Raised when a Sail inference endpoint returns an HTTP error."""

    def __init__(
        self,
        status_code: int,
        message: str,
        response: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.response = response
