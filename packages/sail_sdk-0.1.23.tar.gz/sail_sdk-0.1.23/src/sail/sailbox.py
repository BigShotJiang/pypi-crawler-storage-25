from __future__ import annotations

import json
import shlex
import sys
import time
import uuid
from base64 import b64decode, b64encode
from dataclasses import dataclass, field
from typing import Any, Dict, List, Mapping, Optional, Tuple, Union
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

import grpc
from google.protobuf.json_format import MessageToDict

# Transport policy: sailbox monitoring reads (list, get) and lifecycle ops
# (create, terminate, pause, sleep, resume, checkpoint) go through the public
# HTTP API at /v1/sailboxes/*. Listeners, network requests, and `exec` dial
# the per-sailbox workerproxy directly over gRPC — `exec` is bidirectional
# streaming, and routing the others through the public API would add an
# unnecessary hop and concentrate per-sailbox traffic in the single
# scheduler/API instance. See backend/AGENTS.md
# "Transport: HTTP API vs Workerproxy gRPC".
from sail._client import Client, open_grpc_channel
from sail._http_client import HTTPClient
from sail.errors import (
    SailboxCreationError,
    SailboxExecAlreadyRunningError,
    SailboxExecutionError,
    SailboxFunctionError,
    SailboxFunctionSerializationError,
    SailboxExecRequestNotFoundError,
    SailboxTerminatedError,
    SailboxWorkerLostError,
)
from sail.function import SailFunction
from sail.image import ImageDefinition
from sail.pb.workerproxy.v1 import workerproxy_pb2, workerproxy_pb2_grpc

MIN_SAILBOX_MEMORY_MIB = 1024
MAX_SAILBOX_MEMORY_MIB = 64 * 1024
DEFAULT_SAILBOX_DISK_GIB = 8
MAX_SAILBOX_DISK_GIB = 64
# 22 = ssh; 10000 = guest agent
RESERVED_INGRESS_PORTS = {22, 10000}
EXEC_TRANSIENT_RETRY_TIMEOUT_SECONDS = 30.0
EXEC_TRANSIENT_RETRY_INITIAL_DELAY_SECONDS = 0.2
EXEC_TRANSIENT_RETRY_MAX_DELAY_SECONDS = 2.0
FUNCTION_RUNTIME_PACKAGE = "cloudpickle==3.1.2"
FUNCTION_RUNTIME_SETUP_TIMEOUT_SECONDS = 600
FUNCTION_RESULT_PREFIX = "__SAIL_FUNCTION_RESULT__:"
FUNCTION_RUNTIME_PREFIX = "__SAIL_FUNCTION_RUNTIME__:"
_REMOTE_FUNCTION_RUNTIME_READY: dict[tuple[str, str, str], str] = {}


@dataclass(frozen=True)
class SailboxExecResult:
    stdout: str
    stderr: str
    returncode: int


@dataclass(frozen=True)
class SailboxResponse:
    status_code: int
    headers: Dict[str, str]
    content: bytes

    @property
    def text(self) -> str:
        return self.content.decode("utf-8", errors="replace")

    def json(self) -> Any:
        return json.loads(self.text)


@dataclass(frozen=True)
class SailboxRequest:
    sailbox_id: str
    request_id: str
    exec_endpoint: str
    status: str
    response: Optional["SailboxResponse"] = None
    error_message: str = ""

    @property
    def id(self) -> str:
        return self.request_id

    def _apply_update(self, updated: SailboxRequest) -> SailboxRequest:
        object.__setattr__(self, "status", updated.status)
        object.__setattr__(self, "response", updated.response)
        object.__setattr__(self, "error_message", updated.error_message)
        return self

    def refresh(self) -> SailboxRequest:
        try:
            with open_grpc_channel(self.exec_endpoint) as channel:
                stub = workerproxy_pb2_grpc.WorkerProxyServiceStub(channel)
                resp = stub.GetNetworkRequest(
                    workerproxy_pb2.GetNetworkRequestRequest(
                        sailbox_id=self.sailbox_id,
                        request_id=self.request_id,
                    ),
                    metadata=Client.get().metadata(),
                )
        except grpc.RpcError as exc:
            raise SailboxExecutionError(exc.details() or exc.code().name) from exc
        return self._apply_update(
            _sailbox_request_from_proto(
                resp.request,
                exec_endpoint=self.exec_endpoint,
            )
        )

    def wait(self, timeout: Optional[float] = None) -> SailboxRequest:
        try:
            with open_grpc_channel(self.exec_endpoint) as channel:
                stub = workerproxy_pb2_grpc.WorkerProxyServiceStub(channel)
                resp = stub.WaitNetworkRequest(
                    workerproxy_pb2.WaitNetworkRequestRequest(
                        sailbox_id=self.sailbox_id,
                        request_id=self.request_id,
                    ),
                    metadata=Client.get().metadata(),
                    timeout=timeout,
                )
        except grpc.RpcError as exc:
            raise SailboxExecutionError(exc.details() or exc.code().name) from exc
        return self._apply_update(
            _sailbox_request_from_proto(
                resp.request,
                exec_endpoint=self.exec_endpoint,
            )
        )

    def cancel(self) -> SailboxRequest:
        try:
            with open_grpc_channel(self.exec_endpoint) as channel:
                stub = workerproxy_pb2_grpc.WorkerProxyServiceStub(channel)
                resp = stub.CancelNetworkRequest(
                    workerproxy_pb2.CancelNetworkRequestRequest(
                        sailbox_id=self.sailbox_id,
                        request_id=self.request_id,
                    ),
                    metadata=Client.get().metadata(),
                )
        except grpc.RpcError as exc:
            raise SailboxExecutionError(exc.details() or exc.code().name) from exc
        return self._apply_update(
            _sailbox_request_from_proto(
                resp.request,
                exec_endpoint=self.exec_endpoint,
            )
        )


@dataclass(frozen=True)
class SailboxListener:
    sailbox_id: str
    port: int
    url: str
    protocol: str
    route_status: str
    _exec_endpoint: str = field(default="", repr=False, compare=False)

    def status(self) -> "SailboxListener":
        if not self._exec_endpoint:
            raise SailboxExecutionError("listener status cannot be fetched")
        client = Client.get()
        try:
            with open_grpc_channel(self._exec_endpoint) as channel:
                stub = workerproxy_pb2_grpc.WorkerProxyServiceStub(channel)
                resp = stub.GetListener(
                    workerproxy_pb2.GetListenerRequest(
                        sailbox_id=self.sailbox_id,
                        guest_port=self.port,
                    ),
                    metadata=client.metadata(),
                )
        except grpc.RpcError as exc:
            raise _map_listener_rpc_error(self.sailbox_id, self.port, exc) from exc
        return _listener_from_proto(
            client,
            self.sailbox_id,
            self._exec_endpoint,
            resp.listener,
        )

    def wait(
        self,
        timeout: float = 60.0,
        poll_interval: float = 1.0,
    ) -> "SailboxListener":
        if timeout <= 0:
            raise ValueError("timeout must be positive")
        if poll_interval <= 0:
            raise ValueError("poll_interval must be positive")

        deadline = time.monotonic() + timeout
        listener = self
        last_error = ""
        while True:
            if listener.route_status == "LISTENER_ROUTE_STATUS_ACTIVE":
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise TimeoutError(
                        "listener "
                        f"{listener.sailbox_id}:{listener.port} did not become "
                        "reachable "
                        f"within {timeout} seconds; last status was "
                        f"{listener.route_status}"
                    )
                is_open, last_error = _listener_url_is_open(
                    listener.url,
                    timeout=remaining,
                )
                if is_open:
                    return listener
            else:
                last_error = listener.route_status

            remaining = deadline - time.monotonic()
            if remaining <= 0:
                detail = f"; last error was {last_error}" if last_error else ""
                raise TimeoutError(
                    "listener "
                    f"{listener.sailbox_id}:{listener.port} did not become "
                    "reachable "
                    f"within {timeout} seconds; last status was "
                    f"{listener.route_status}"
                    f"{detail}"
                )
            time.sleep(min(poll_interval, remaining))
            listener = listener.status()


@dataclass(frozen=True)
class SailboxExecRequest:
    sailbox_id: str
    exec_request_id: str
    exec_endpoint: str
    background: bool = False
    idempotency_key: str = ""

    def wait(
        self, *, retry_timeout: float = EXEC_TRANSIENT_RETRY_TIMEOUT_SECONDS
    ) -> SailboxExecResult:
        """Wait for the exec request to complete.

        For foreground execs this waits for the command itself to finish.
        For background execs this waits only for the detached launcher shell to
        succeed or fail; it does not wait for the long-lived background process.

        Retrying wait is safe because the request already has a durable
        exec_request_id. Retrying initial exec submission is only safe when the
        request has an idempotency key, which Sailbox.exec adds by default.
        """
        deadline: Optional[float] = None
        delay = EXEC_TRANSIENT_RETRY_INITIAL_DELAY_SECONDS
        while True:
            try:
                with open_grpc_channel(self.exec_endpoint) as channel:
                    stub = workerproxy_pb2_grpc.WorkerProxyServiceStub(channel)
                    resp = stub.WaitSailboxExec(
                        workerproxy_pb2.WaitSailboxExecRequest(
                            sailbox_id=self.sailbox_id,
                            exec_request_id=self.exec_request_id,
                        ),
                        metadata=Client.get().metadata(),
                    )
                break
            except grpc.RpcError as exc:
                if deadline is None:
                    deadline = _retry_deadline(retry_timeout)
                if not _should_retry_transient_exec_rpc(exc, deadline):
                    raise _map_exec_rpc_error(exc) from exc
                delay = _sleep_before_retry(delay, deadline)
        if resp.status == workerproxy_pb2.SAILBOX_EXEC_STATUS_WORKER_LOST:
            raise SailboxWorkerLostError(
                resp.stderr or "assigned worker was lost; call resume() and retry"
            )
        return SailboxExecResult(
            stdout=resp.stdout,
            stderr=resp.stderr,
            returncode=resp.return_code,
        )


from sail.app import App  # noqa: E402


@dataclass(frozen=True)
class SailboxInfo:
    """Read-only snapshot of a sailbox returned by ``Sailbox.list``.

    Distinct from ``Sailbox`` because the list endpoint deliberately omits
    ``worker_address`` and ``exec_endpoint`` — fields needed to call
    ``terminate``/``exec``/etc. Returning a partial ``Sailbox`` would expose
    methods that quietly fail.
    """

    sailbox_id: str
    app_id: str
    app_name: str
    name: str
    status: str
    memory_mib: int
    vcpu_count: int
    state_disk_size_gib: int
    architecture: str
    error_message: Optional[str]
    started_at: Optional[str]
    created_at: str
    updated_at: str


@dataclass(frozen=True)
class SailboxPage:
    """One page of ``Sailbox.list_page`` results plus the server's pagination envelope."""

    items: List[SailboxInfo]
    limit: int
    offset: int
    total: int
    has_more: bool


@dataclass(frozen=True)
class Sailbox:
    """A sandbox instance on the Sail platform.

    Identifiers on this type:

    - ``sailbox_id`` is the stable Sail control-plane identifier for the
      sandbox. This is the main external ID and the one used for follow-up
      operations like terminate/status lookup.
    - ``worker_address`` is the scheduler's internal address for the worker
      currently hosting the sailbox. It is operational metadata, not a
      client-facing endpoint.
    - ``exec_endpoint`` is the client-reachable worker-proxy endpoint for exec
      requests.

    In practice, callers should treat ``sailbox_id`` as the primary ID. The
    other fields are useful to surface for debugging, but they are not the
    durable external handle for the resource.
    """

    sailbox_id: str
    name: str
    status: str
    worker_address: str
    exec_endpoint: str

    @classmethod
    def create(
        cls,
        *,
        image: ImageDefinition,
        app: App,
        name: str,
        image_build_timeout: int = 1800,
        memory_mib: int = 1024,
        cpu: int = 1,
        ingress_ports: Optional[List[int]] = None,
        disk_gib: int = DEFAULT_SAILBOX_DISK_GIB,
    ) -> Sailbox:
        """Create a new sailbox.

        Custom image definitions are built first. Then this sends a synchronous
        POST /v1/sailboxes that returns once the VM is running or creation has
        failed.
        """
        if not isinstance(image, ImageDefinition):
            raise TypeError("image must be a sail.Image value")
        if image_build_timeout <= 0:
            raise ValueError("image_build_timeout must be greater than 0")
        _validate_create_args(
            cpu=cpu,
            memory_mib=memory_mib,
            disk_gib=disk_gib,
            ingress_ports=list(ingress_ports or []),
        )
        try:
            image = image._ensure_built(timeout=image_build_timeout)
        except grpc.RpcError as exc:
            raise SailboxCreationError(exc.details() or exc.code().name) from exc

        body = {
            "app_id": app.id,
            "name": name,
            "cpu": cpu,
            "memory_mib": memory_mib,
            "state_disk_size_gib": disk_gib,
            "ingress_ports": list(ingress_ports or []),
            "image": MessageToDict(
                image.to_proto(),
                preserving_proto_field_name=True,
            ),
        }
        status_code, data = HTTPClient.instance().post("/v1/sailboxes", body=body)
        _raise_for_status(status_code, data, SailboxCreationError)

        if data.get("status") == "failed":
            raise SailboxCreationError(
                f"Sailbox creation failed: {data.get('error_message', '')}"
            )
        _require_lifecycle_status(data, "running", "Sailbox creation")

        return cls(
            sailbox_id=data["sailbox_id"],
            name=name,
            status="running",
            worker_address=data.get("worker_address", ""),
            exec_endpoint=data.get("exec_proxy_endpoint", ""),
        )

    @classmethod
    def list(
        cls,
        *,
        app: Optional[str] = None,
        status: Optional[str] = None,
        search: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> List[SailboxInfo]:
        """List sailboxes for the current org via public HTTP.

        Filters are server-side. ``app`` matches against ``app_id`` (resolve
        an app name through ``App.find`` first if needed).

        Returns just the rows. Use ``list_page`` for the same call with the
        server's pagination envelope (``limit``/``offset``/``total``/``has_more``).
        """
        return cls.list_page(
            app=app,
            status=status,
            search=search,
            limit=limit,
            offset=offset,
        ).items

    @classmethod
    def list_page(
        cls,
        *,
        app: Optional[str] = None,
        status: Optional[str] = None,
        search: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> SailboxPage:
        """List sailboxes and return the server's pagination envelope alongside the rows."""
        query: Dict[str, Any] = {"limit": limit, "offset": offset}
        if app is not None:
            query["app"] = app
        if status is not None:
            query["status"] = status
        if search is not None:
            query["search"] = search

        status_code, data = HTTPClient.instance().get("/v1/sailboxes", query=query)
        if status_code == 400:
            # The backend returns 400 for caller-input bugs (out-of-range or
            # non-integer limit/offset). Raise ValueError so retry-on-
            # RuntimeError loops don't spin on a non-retriable input bug.
            msg = data.get("error", {}).get("message", "invalid argument")
            raise ValueError(f"Failed to list sailboxes: {msg}")
        _raise_for_status(status_code, data, RuntimeError)
        return SailboxPage(
            items=[_sailbox_info_from_json(row) for row in data["data"]],
            limit=int(data["limit"]),
            offset=int(data["offset"]),
            total=int(data["total"]),
            has_more=bool(data["has_more"]),
        )

    @classmethod
    def get(cls, sailbox_id: str) -> SailboxInfo:
        """Fetch a single sailbox owned by the current org via public HTTP.

        Returns the same trimmed shape as ``Sailbox.list`` — ``worker_address``
        and ``exec_endpoint`` are intentionally not exposed, so the result
        type is ``SailboxInfo`` rather than ``Sailbox``. Wrong-org ids and
        unknown ids both surface as ``LookupError`` (the server returns 404
        for both to avoid leaking ownership across orgs).
        """
        status_code, data = HTTPClient.instance().get(f"/v1/sailboxes/{sailbox_id}")
        if status_code == 404:
            msg = data.get("error", {}).get("message", "sailbox not found")
            raise LookupError(f"Sailbox {sailbox_id!r}: {msg}")
        if status_code in (401, 403):
            msg = data.get("error", {}).get("message", "unauthorized")
            raise PermissionError(f"Failed to fetch sailbox {sailbox_id!r}: {msg}")
        if status_code == 400:
            # The backend returns 400 specifically for malformed sailbox IDs
            # (the server-side `sailbox.ValidateID` check). That's a caller
            # input bug, not a transient backend failure, so raise ValueError
            # — retry-on-RuntimeError loops shouldn't retry a bad id forever.
            msg = data.get("error", {}).get("message", "invalid sailbox id")
            raise ValueError(f"Sailbox {sailbox_id!r}: {msg}")
        if status_code >= 400:
            msg = data.get("error", {}).get("message", "unknown error")
            raise RuntimeError(f"Failed to fetch sailbox {sailbox_id!r}: {msg}")
        return _sailbox_info_from_json(data)

    def terminate(self) -> None:
        """Permanently terminate this sailbox."""
        status_code, data = HTTPClient.instance().post(
            f"/v1/sailboxes/{self.sailbox_id}/terminate",
            body={},
        )
        # Scheduler returns 200 with status=terminated for both fresh and
        # already-terminated sailboxes, so repeated terminate calls are
        # naturally idempotent. A handler-emitted 404 (type=not_found_error)
        # means the row was never seen — same outcome. A route-level 404
        # (e.g. old backend without this endpoint) carries no type and must
        # surface as a real failure so mixed-version deploys don't silently
        # leave sailboxes running.
        if (
            status_code == 404
            and data.get("error", {}).get("type") == "not_found_error"
        ):
            return
        _raise_for_status(status_code, data, SailboxCreationError)

    def pause(self) -> None:
        """Checkpoint and pause this sailbox until it is explicitly resumed."""
        self._stop(action="pause", expected_status="paused")

    def sleep(self) -> None:
        """Checkpoint and sleep this sailbox until traffic or explicit resume wakes it."""
        self._stop(action="sleep", expected_status="sleeping")

    def _stop(self, *, action: str, expected_status: str) -> None:
        status_code, data = HTTPClient.instance().post(
            f"/v1/sailboxes/{self.sailbox_id}/{action}",
            body={},
        )
        _raise_for_status(status_code, data, SailboxCreationError)
        _require_lifecycle_status(data, expected_status, f"{action} sailbox")
        object.__setattr__(self, "status", expected_status)
        object.__setattr__(self, "worker_address", "")

    def checkpoint(self) -> None:
        """Durably checkpoint this running sailbox without stopping it."""
        status_code, data = HTTPClient.instance().post(
            f"/v1/sailboxes/{self.sailbox_id}/checkpoint",
            body={},
        )
        _raise_for_status(status_code, data, SailboxCreationError)
        _require_lifecycle_status(data, "running", "checkpoint sailbox")

    def resume(self) -> Sailbox:
        """Resume this sailbox through the public API."""
        status_code, data = HTTPClient.instance().post(
            f"/v1/sailboxes/{self.sailbox_id}/resume",
            body={},
        )
        _raise_for_status(status_code, data, SailboxCreationError)
        if data.get("resume_state") == "terminal_unavailable":
            raise SailboxCreationError(
                data.get("error_message") or "sailbox cannot be resumed"
            )
        _require_lifecycle_status(data, "running", "resume sailbox")
        # Frozen dataclass: bypass __setattr__.
        object.__setattr__(self, "status", "running")
        object.__setattr__(self, "worker_address", data.get("worker_address", ""))
        if refreshed := data.get("exec_proxy_endpoint"):
            object.__setattr__(self, "exec_endpoint", refreshed)
        return self

    def request(
        self,
        method: str,
        url: str,
        *,
        params: Optional[Dict[str, str]] = None,
        headers: Optional[Dict[str, str]] = None,
        data: Optional[Union[bytes, str]] = None,
        json: Optional[Any] = None,
        timeout: Optional[int] = None,
        durability: str = "tracked",
        idempotency_key: Optional[str] = None,
    ) -> SailboxRequest:
        # CR-someday nbaruah: consider deleting this tracked request API now
        # that sailboxes have transparent outbound egress through the egress proxy.
        if not method:
            raise ValueError("method must be non-empty")
        if not url:
            raise ValueError("url must be non-empty")
        if not idempotency_key or not idempotency_key.strip():
            raise ValueError("idempotency_key must be non-empty")
        if data is not None and json is not None:
            raise ValueError("data and json are mutually exclusive")

        body = b""
        request_headers = dict(headers or {})
        if json is not None:
            body = _json_dumps_bytes(json)
            request_headers.setdefault("Content-Type", "application/json")
        elif isinstance(data, str):
            body = data.encode("utf-8")
        elif data is not None:
            body = data

        client = Client.get()
        with open_grpc_channel(self.exec_endpoint) as channel:
            stub = workerproxy_pb2_grpc.WorkerProxyServiceStub(channel)
            resp = stub.CreateNetworkRequest(
                workerproxy_pb2.CreateNetworkRequestRequest(
                    sailbox_id=self.sailbox_id,
                    method=method,
                    url=url,
                    params=[
                        workerproxy_pb2.QueryParam(name=name, value=value)
                        for name, value in (params or {}).items()
                    ],
                    headers=[
                        workerproxy_pb2.HTTPHeader(name=name, value=value)
                        for name, value in request_headers.items()
                    ],
                    request_body=body,
                    timeout_seconds=timeout or 30,
                    durability_mode=durability,
                    idempotency_key=idempotency_key or "",
                ),
                metadata=client.metadata(),
            )
        return _sailbox_request_from_proto(
            resp.request,
            exec_endpoint=self.exec_endpoint,
        )

    def listener(self, port: int) -> SailboxListener:
        client = Client.get()
        try:
            with open_grpc_channel(self.exec_endpoint) as channel:
                stub = workerproxy_pb2_grpc.WorkerProxyServiceStub(channel)
                resp = stub.GetListener(
                    workerproxy_pb2.GetListenerRequest(
                        sailbox_id=self.sailbox_id,
                        guest_port=port,
                    ),
                    metadata=client.metadata(),
                )
        except grpc.RpcError as exc:
            raise _map_listener_rpc_error(self.sailbox_id, port, exc) from exc
        return _listener_from_proto(
            client,
            self.sailbox_id,
            self.exec_endpoint,
            resp.listener,
        )

    def listeners(self) -> list[SailboxListener]:
        client = Client.get()
        try:
            with open_grpc_channel(self.exec_endpoint) as channel:
                stub = workerproxy_pb2_grpc.WorkerProxyServiceStub(channel)
                resp = stub.ListListeners(
                    workerproxy_pb2.ListListenersRequest(sailbox_id=self.sailbox_id),
                    metadata=client.metadata(),
                )
        except grpc.RpcError as exc:
            raise SailboxExecutionError(exc.details() or exc.code().name) from exc
        return [
            _listener_from_proto(
                client,
                self.sailbox_id,
                self.exec_endpoint,
                listener,
            )
            for listener in resp.listeners
        ]

    def stream(self, *args, **kwargs):
        raise NotImplementedError(
            "stream support is reserved for a future resumable session API"
        )

    def webhook(self, *args, **kwargs):
        raise NotImplementedError(
            "webhook support is reserved for a future stable inbound delivery API"
        )

    def exec(
        self,
        command: Union[str, SailFunction],
        *function_args: Any,
        timeout: Optional[int] = None,
        background: bool = False,
        cwd: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        retry_timeout: float = EXEC_TRANSIENT_RETRY_TIMEOUT_SECONDS,
        args: Optional[Union[List[Any], Tuple[Any, ...]]] = None,
        kwargs: Optional[Mapping[str, Any]] = None,
    ) -> Union[SailboxExecRequest, Any]:
        """Run a shell command or decorated Python function in the sailbox."""
        if isinstance(command, SailFunction):
            return self._exec_function(
                command,
                function_args,
                timeout=timeout,
                background=background,
                cwd=cwd,
                idempotency_key=idempotency_key,
                retry_timeout=retry_timeout,
                args=args,
                kwargs=kwargs,
            )
        if not isinstance(command, str):
            if callable(command):
                raise TypeError(
                    "Python functions must be decorated with @sail.function before "
                    "passing them to Sailbox.exec"
                )
            raise TypeError("command must be a string or a sail.SailFunction")
        if function_args or args is not None or kwargs is not None:
            raise TypeError(
                "positional function args, args, and kwargs are only valid when "
                "executing a sail.SailFunction"
            )
        return self._exec_command(
            command,
            timeout=timeout,
            background=background,
            cwd=cwd,
            idempotency_key=idempotency_key,
            retry_timeout=retry_timeout,
        )

    def _exec_command(
        self,
        command: str,
        *,
        timeout: Optional[int] = None,
        background: bool = False,
        cwd: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        retry_timeout: float = EXEC_TRANSIENT_RETRY_TIMEOUT_SECONDS,
    ) -> SailboxExecRequest:
        """Run a shell command directly on the owning worker."""
        if not command:
            raise ValueError("command must be non-empty")
        if timeout is not None and timeout <= 0:
            raise ValueError("timeout must be greater than 0")
        if self.status == "paused":
            raise SailboxExecutionError("sailbox is paused. call resume() before exec")

        command = _command_with_cwd(command, cwd)
        if background:
            command = (
                f"nohup /bin/sh -lc {shlex.quote(command)} "
                "</dev/null >/dev/null 2>&1 &"
            )
        idempotency_key = _exec_idempotency_key(idempotency_key)

        # TODO: Consider renaming timeout to expected_runtime if we later need
        # a separate transport timeout distinct from the command runtime budget.
        deadline = _retry_deadline(retry_timeout)
        delay = EXEC_TRANSIENT_RETRY_INITIAL_DELAY_SECONDS
        while True:
            try:
                with open_grpc_channel(self.exec_endpoint) as channel:
                    stub = workerproxy_pb2_grpc.WorkerProxyServiceStub(channel)
                    resp = stub.ExecSailbox(
                        workerproxy_pb2.ExecSailboxRequest(
                            sailbox_id=self.sailbox_id,
                            argv=["/bin/sh", "-lc", command],
                            timeout_seconds=timeout or 0,
                            idempotency_key=idempotency_key,
                        ),
                        metadata=Client.get().metadata(),
                    )
                break
            except grpc.RpcError as exc:
                if not _should_retry_transient_exec_rpc(exc, deadline):
                    raise _map_exec_rpc_error(exc) from exc
                delay = _sleep_before_retry(delay, deadline)
        return SailboxExecRequest(
            sailbox_id=self.sailbox_id,
            exec_request_id=resp.exec_request_id,
            exec_endpoint=self.exec_endpoint,
            background=background,
            idempotency_key=idempotency_key,
        )

    def _exec_function(
        self,
        function: SailFunction,
        function_args: Tuple[Any, ...],
        *,
        timeout: Optional[int],
        background: bool,
        cwd: Optional[str],
        idempotency_key: Optional[str],
        retry_timeout: float,
        args: Optional[Union[List[Any], Tuple[Any, ...]]],
        kwargs: Optional[Mapping[str, Any]],
    ) -> Any:
        if background:
            raise ValueError("background=True is not supported for Python functions")
        if args is not None and function_args:
            raise ValueError("pass function arguments either positionally or via args")
        call_args = tuple(args) if args is not None else function_args
        call_kwargs = dict(kwargs or {})

        # Function execution rides on top of foreground exec after a
        # per-sailbox runtime bootstrap, so the backend only needs the single
        # ExecSailbox RPC and the SDK can still return the Python value directly.
        python_executable = self._ensure_function_runtime()
        command = _function_exec_command(
            function,
            call_args,
            call_kwargs,
            python_executable=python_executable,
        )
        result = self._exec_command(
            command,
            timeout=timeout,
            background=False,
            cwd=cwd,
            idempotency_key=idempotency_key,
            retry_timeout=retry_timeout,
        ).wait(retry_timeout=retry_timeout)
        return _decode_function_exec_result(result)

    def _ensure_function_runtime(self) -> str:
        resolved_version = _local_python_version()
        cache_key = (self.sailbox_id, self.exec_endpoint, resolved_version)
        if cache_key in _REMOTE_FUNCTION_RUNTIME_READY:
            return _REMOTE_FUNCTION_RUNTIME_READY[cache_key]
        # Only cache successful setup attempts. _exec_command will generate a
        # fresh idempotency key here, so a failed runtime check can be retried instead
        # of pinning the sailbox to a failed exec row.
        command = _function_runtime_setup_command(resolved_version)
        result = self._exec_command(
            command,
            timeout=FUNCTION_RUNTIME_SETUP_TIMEOUT_SECONDS,
        ).wait()
        if result.returncode != 0:
            raise SailboxFunctionSerializationError(
                "failed to prepare Python function runtime in sailbox: "
                f"returncode={result.returncode} stderr={result.stderr!r}"
            )
        python_executable, guest_version = _decode_function_runtime_result(result)
        # cloudpickle bytecode is sensitive to Python major.minor; patches are compatible.
        if _major_minor(guest_version) != _major_minor(resolved_version):
            guest_major, guest_minor = _major_minor(guest_version)
            raise SailboxFunctionSerializationError(
                f"Python version mismatch: local interpreter is {resolved_version} "
                f"but the sailbox's python3 is {guest_version}. cloudpickle "
                "requires matching major.minor versions. Either invoke "
                f"Sailbox.exec from a Python {guest_major}.{guest_minor}.x "
                "interpreter, or build a custom image whose python3 matches "
                "your local Python."
            )
        _REMOTE_FUNCTION_RUNTIME_READY[cache_key] = python_executable
        return python_executable


def _map_exec_rpc_error(exc: grpc.RpcError) -> SailboxExecutionError:
    details = exc.details() or "unknown sailbox exec error"
    code = exc.code()

    if code == grpc.StatusCode.FAILED_PRECONDITION and "already running" in details:
        return SailboxExecAlreadyRunningError(details)
    if code == grpc.StatusCode.NOT_FOUND:
        if "exec request" in details:
            return SailboxExecRequestNotFoundError(details)
        return SailboxTerminatedError(
            f"{details}; this is likely because this Sailbox is no longer running"
        )
    return SailboxExecutionError(f"{code.name}: {details}")


def _local_python_version() -> str:
    return f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"


def _major_minor(version: str) -> Tuple[int, int]:
    parts = version.split(".")
    return (int(parts[0]), int(parts[1]))


def _function_runtime_setup_command(python_version: str) -> str:
    # Function exec intentionally uses the image's python3. Imagebuilder is
    # responsible for making that interpreter match the SDK's local Python for
    # newly-built images, which keeps image-installed packages on sys.path.
    return (
        "python3 - <<'PY'\n"
        "import json\n"
        "import subprocess\n"
        "import sys\n"
        "\n"
        f"target = {python_version!r}\n"
        f"package = {FUNCTION_RUNTIME_PACKAGE!r}\n"
        f"cloudpickle_version = {FUNCTION_RUNTIME_PACKAGE.split('==', 1)[1]!r}\n"
        f"prefix = {FUNCTION_RUNTIME_PREFIX!r}\n"
        "python = sys.executable\n"
        "version = '.'.join(map(str, sys.version_info[:3]))\n"
        "\n"
        "def _ensure_pip():\n"
        "    if subprocess.run([python, '-m', 'pip', '--version'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0:\n"
        "        return\n"
        "    subprocess.check_call([python, '-m', 'ensurepip', '--upgrade'])\n"
        "\n"
        "def _ensure_cloudpickle():\n"
        '    check = f"import cloudpickle, sys; sys.exit(0 if cloudpickle.__version__ == {cloudpickle_version!r} else 1)"\n'
        "    if subprocess.run([python, '-c', check], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0:\n"
        "        return\n"
        "    _ensure_pip()\n"
        "    commands = [\n"
        "        [python, '-m', 'pip', 'install', '-q', '--break-system-packages', package],\n"
        "        [python, '-m', 'pip', 'install', '-q', package],\n"
        "    ]\n"
        "    last_error = None\n"
        "    for command in commands:\n"
        "        try:\n"
        "            subprocess.check_call(command)\n"
        "            return\n"
        "        except subprocess.CalledProcessError as exc:\n"
        "            last_error = exc\n"
        "    raise last_error\n"
        "\n"
        "_ensure_cloudpickle()\n"
        "print(prefix + json.dumps({'python': python, 'version': version, 'target': target}, separators=(',', ':')))\n"
        "PY"
    )


def _decode_function_runtime_result(result: SailboxExecResult) -> Tuple[str, str]:
    # Setup commands may emit pip output. Scan from the end so the last
    # sentinel wins and incidental stdout cannot become the protocol payload.
    envelope_line = ""
    for line in reversed(result.stdout.splitlines()):
        if line.startswith(FUNCTION_RUNTIME_PREFIX):
            envelope_line = line[len(FUNCTION_RUNTIME_PREFIX) :]
            break
    if not envelope_line:
        raise SailboxFunctionSerializationError(
            "Python function runtime setup did not return a valid result envelope: "
            f"returncode={result.returncode} stdout={result.stdout!r} "
            f"stderr={result.stderr!r}"
        )
    try:
        envelope = json.loads(envelope_line)
        python_executable = str(envelope["python"])
        guest_version = str(envelope["version"])
    except (KeyError, TypeError, json.JSONDecodeError) as exc:
        raise SailboxFunctionSerializationError(
            f"failed to decode Python function runtime setup result: {exc}"
        ) from exc
    if not python_executable:
        raise SailboxFunctionSerializationError(
            "Python function runtime setup returned an empty python executable"
        )
    return python_executable, guest_version


def _function_exec_command(
    function: SailFunction,
    args: Tuple[Any, ...],
    kwargs: Mapping[str, Any],
    *,
    python_executable: str,
) -> str:
    # CR-soon nbaruah: Move large function payloads/results to S3 or another
    # blob transport instead of embedding pickles in exec argv/stdout. The
    # current path is only suitable for small values because guest exec output
    # is captured with a fixed size cap.
    try:
        import cloudpickle

        # cloudpickle captures local Python functions and their reachable
        # picklable globals/closures. Imported packages are still referenced by
        # module name, so they must exist in the sailbox environment.
        payload = cloudpickle.dumps(
            {
                "function": function.func,
                "args": args,
                "kwargs": dict(kwargs),
            }
        )
    except Exception as exc:
        raise SailboxFunctionSerializationError(
            f"failed to serialize Python function call: {exc}"
        ) from exc

    payload_b64 = b64encode(payload).decode("ascii")
    return (
        f"{shlex.quote(python_executable)} - <<'PY'\n"
        "import base64\n"
        "import contextlib\n"
        "import io\n"
        "import json\n"
        "import traceback\n"
        "\n"
        "import cloudpickle\n"
        "\n"
        f"payload_b64 = {payload_b64!r}\n"
        f"prefix = {FUNCTION_RESULT_PREFIX!r}\n"
        "user_stdout = io.StringIO()\n"
        "user_stderr = io.StringIO()\n"
        "try:\n"
        "    # User stdout/stderr are captured into the envelope so the final\n"
        "    # sentinel line remains parseable by the SDK.\n"
        "    with contextlib.redirect_stdout(user_stdout), contextlib.redirect_stderr(user_stderr):\n"
        "        payload = cloudpickle.loads(base64.b64decode(payload_b64))\n"
        "        result = payload['function'](*payload['args'], **payload['kwargs'])\n"
        "    envelope = {\n"
        "        'ok': True,\n"
        "        'result': base64.b64encode(cloudpickle.dumps(result)).decode('ascii'),\n"
        "        'stdout': user_stdout.getvalue(),\n"
        "        'stderr': user_stderr.getvalue(),\n"
        "    }\n"
        "except BaseException as exc:\n"
        "    envelope = {\n"
        "        'ok': False,\n"
        "        'error_type': type(exc).__name__,\n"
        "        'error_message': str(exc),\n"
        "        'traceback': traceback.format_exc(),\n"
        "        'stdout': user_stdout.getvalue(),\n"
        "        'stderr': user_stderr.getvalue(),\n"
        "    }\n"
        "print(prefix + json.dumps(envelope, separators=(',', ':')))\n"
        "PY"
    )


def _decode_function_exec_result(result: SailboxExecResult) -> Any:
    # The command's stdout is both user output transport and control protocol.
    # Decode only the sentinel envelope and expose captured user output on
    # SailboxFunctionError for failures.
    envelope_line = ""
    for line in reversed(result.stdout.splitlines()):
        if line.startswith(FUNCTION_RESULT_PREFIX):
            envelope_line = line[len(FUNCTION_RESULT_PREFIX) :]
            break
    if not envelope_line:
        raise SailboxFunctionSerializationError(
            "Python function execution did not return a valid result envelope: "
            f"returncode={result.returncode} stdout={result.stdout!r} "
            f"stderr={result.stderr!r}"
        )
    try:
        envelope = json.loads(envelope_line)
    except json.JSONDecodeError as exc:
        raise SailboxFunctionSerializationError(
            f"failed to decode Python function result envelope: {exc}"
        ) from exc

    if not envelope.get("ok"):
        error_type = str(envelope.get("error_type") or "RemoteError")
        error_message = str(envelope.get("error_message") or "")
        traceback_text = str(envelope.get("traceback") or "")
        message = f"{error_type}: {error_message}" if error_message else error_type
        raise SailboxFunctionError(
            message,
            error_type=error_type,
            traceback=traceback_text,
            stdout=str(envelope.get("stdout") or ""),
            stderr=str(envelope.get("stderr") or ""),
        )

    try:
        import cloudpickle

        return cloudpickle.loads(b64decode(envelope["result"]))
    except Exception as exc:
        raise SailboxFunctionSerializationError(
            f"failed to deserialize Python function return value: {exc}"
        ) from exc


def _map_listener_rpc_error(
    sailbox_id: str, port: int, exc: grpc.RpcError
) -> SailboxExecutionError:
    if exc.code() == grpc.StatusCode.NOT_FOUND:
        return SailboxExecutionError(
            f"listener {sailbox_id}:{port} not found; pass ingress_ports=[{port}] "
            "when creating the Sailbox to expose this port"
        )
    return SailboxExecutionError(exc.details() or exc.code().name)


def _exec_idempotency_key(value: Optional[str]) -> str:
    if value is None:
        return f"exec_{uuid.uuid4()}"
    if not value.strip():
        raise ValueError("idempotency_key must be non-empty")
    return value.strip()


def _command_with_cwd(command: str, cwd: Optional[str]) -> str:
    if cwd is None:
        return command
    cwd = cwd.strip()
    if not cwd:
        raise ValueError("cwd must be non-empty")
    return f"cd {shlex.quote(cwd)} && exec /bin/sh -lc {shlex.quote(command)}"


def _retry_deadline(retry_timeout: Optional[float]) -> Optional[float]:
    if retry_timeout is None:
        return None
    if retry_timeout <= 0:
        return time.monotonic()
    return time.monotonic() + retry_timeout


def _should_retry_transient_exec_rpc(
    exc: grpc.RpcError, deadline: Optional[float]
) -> bool:
    if deadline is not None and time.monotonic() >= deadline:
        return False
    code = exc.code()
    if code in (grpc.StatusCode.UNAVAILABLE, grpc.StatusCode.DEADLINE_EXCEEDED):
        return True
    details = (exc.details() or "").lower()
    if code == grpc.StatusCode.UNKNOWN and any(
        fragment in details
        for fragment in (
            "endpoint closing",
            "connection reset",
            "socket closed",
            "transport is closing",
        )
    ):
        return True
    return False


def _sleep_before_retry(delay: float, deadline: Optional[float]) -> float:
    sleep_for = min(delay, EXEC_TRANSIENT_RETRY_MAX_DELAY_SECONDS)
    if deadline is not None:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return delay
        sleep_for = min(sleep_for, remaining)
    time.sleep(max(0.0, sleep_for))
    return min(delay * 2, EXEC_TRANSIENT_RETRY_MAX_DELAY_SECONDS)


def _json_dumps_bytes(value: Any) -> bytes:
    return json.dumps(value, separators=(",", ":"), sort_keys=True).encode("utf-8")


def _validate_create_args(
    *,
    cpu: int,
    memory_mib: int,
    disk_gib: int,
    ingress_ports: List[int],
) -> None:
    if cpu <= 0:
        raise ValueError("cpu must be greater than 0")
    if memory_mib < MIN_SAILBOX_MEMORY_MIB:
        raise ValueError(f"memory_mib must be at least {MIN_SAILBOX_MEMORY_MIB}")
    if memory_mib > MAX_SAILBOX_MEMORY_MIB:
        raise ValueError(f"memory_mib must be at most {MAX_SAILBOX_MEMORY_MIB}")
    if disk_gib <= 0:
        raise ValueError("disk_gib must be greater than 0")
    if disk_gib > MAX_SAILBOX_DISK_GIB:
        raise ValueError(f"disk_gib must be at most {MAX_SAILBOX_DISK_GIB}")
    seen: set[int] = set()
    for port in ingress_ports:
        if port <= 0 or port > 65535:
            raise ValueError("ingress_ports must be between 1 and 65535")
        if port in RESERVED_INGRESS_PORTS:
            raise ValueError(f"ingress_ports contains reserved port {port}")
        if port in seen:
            raise ValueError("ingress_ports must be unique")
        seen.add(port)


def _sailbox_info_from_json(row: Mapping[str, Any]) -> SailboxInfo:
    return SailboxInfo(
        sailbox_id=row["sailbox_id"],
        app_id=row["app_id"],
        app_name=row["app_name"],
        name=row["name"],
        status=row["status"],
        memory_mib=int(row["memory_mib"]),
        vcpu_count=int(row["vcpu_count"]),
        state_disk_size_gib=int(row["state_disk_size_gib"]),
        architecture=row["architecture"],
        error_message=row.get("error_message"),
        started_at=row.get("started_at"),
        created_at=row["created_at"],
        updated_at=row["updated_at"],
    )


def _sailbox_request_from_proto(
    request: workerproxy_pb2.NetworkRequest,
    *,
    exec_endpoint: str,
) -> SailboxRequest:
    response = None
    if request.status == workerproxy_pb2.NETWORK_REQUEST_STATUS_COMPLETED:
        response = SailboxResponse(
            status_code=request.response_status_code,
            headers={header.name: header.value for header in request.response_headers},
            content=request.response_body,
        )
    return SailboxRequest(
        sailbox_id=request.sailbox_id,
        request_id=request.request_id,
        exec_endpoint=exec_endpoint,
        status=workerproxy_pb2.NetworkRequestStatus.Name(request.status),
        response=response,
        error_message=request.error_message,
    )


def _listener_url(client: Client, sailbox_id: str, port: int, public_url: str) -> str:
    if public_url:
        return public_url
    ingress_url = client._config.sailbox_ingress_url.rstrip("/")
    if not ingress_url:
        return ""
    return f"{ingress_url}/_sailbox/{sailbox_id}/{port}"


def _listener_from_proto(
    client: Client,
    sailbox_id: str,
    exec_endpoint: str,
    listener,
) -> SailboxListener:
    return SailboxListener(
        sailbox_id=sailbox_id,
        port=listener.guest_port,
        url=_listener_url(client, sailbox_id, listener.guest_port, listener.public_url),
        protocol=listener.protocol,
        route_status=workerproxy_pb2.ListenerRouteStatus.Name(listener.route_status),
        _exec_endpoint=exec_endpoint,
    )


def _api_error_message(data: Mapping[str, Any]) -> str:
    err = data.get("error") if isinstance(data, Mapping) else None
    if isinstance(err, Mapping):
        message = err.get("message")
        if isinstance(message, str) and message:
            return message
    return "unknown error"


def _raise_for_status(
    status_code: int,
    data: Mapping[str, Any],
    default: type,
) -> None:
    """Raise an SDK exception for non-2xx HTTP responses.

    401/403 always become ``PermissionError`` so callers can distinguish auth
    failures from server-side errors. Everything else raises ``default`` with
    the API's ``error.message`` text.
    """
    if status_code < 400:
        return
    message = _api_error_message(data)
    if status_code in (401, 403):
        raise PermissionError(message)
    raise default(message)


def _require_lifecycle_status(
    data: Mapping[str, Any], expected: str, action: str
) -> None:
    """Raise ``SailboxCreationError`` when the API echoes an unexpected status."""
    got = data.get("status")
    if got != expected:
        raise SailboxCreationError(f"{action} returned unexpected status: {got}")


def _listener_url_is_open(url: str, *, timeout: float) -> tuple[bool, str]:
    if not url:
        return False, "listener URL is empty"
    req = Request(url, method="GET")
    try:
        with urlopen(req, timeout=timeout):
            return True, ""
    except HTTPError as exc:
        body = exc.read(512).decode("utf-8", errors="replace").strip()
        if exc.code in (502, 503) and body.lower() == "upstream unavailable":
            return False, f"HTTP {exc.code}: {body}"
        return True, ""
    except (TimeoutError, URLError, OSError) as exc:
        return False, f"{type(exc).__name__}: {exc}"
