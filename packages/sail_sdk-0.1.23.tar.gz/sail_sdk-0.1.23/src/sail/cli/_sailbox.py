"""`sail box` subcommands.

CLI commands here must drive sailbox operations through the public SDK
(`sail.sailbox.Sailbox` and friends), never via `HTTPClient`, the
scheduler stub, or workerproxy stubs directly. See `sdk/python/AGENTS.md`.
"""

from __future__ import annotations

import dataclasses
import pprint
import shlex
import sys
from dataclasses import replace
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

import click

from sail.app import App
from sail.cli._function_spec import (
    looks_like_function_spec,
    parse_function_args,
    resolve_function_spec,
)
from sail.cli._globals import apply_config_or_exit, output, with_global_flags
from sail.cli._output import Output
from sail.cli._state import (
    SailboxRecord,
    delete_sailbox_record,
    load_sailbox_record,
    save_sailbox_record,
)
from sail.errors import (
    SailboxExecutionError,
    SailboxFunctionError,
    SailboxFunctionSerializationError,
)
from sail.image import Image, ImageDefinition
from sail.sailbox import Sailbox, SailboxInfo, SailboxPage

_BASE_IMAGES = {
    "debian-arm64": Image.debian_arm64,
    "debian-amd64": Image.debian_amd64,
}


def register(cli: click.Group) -> None:
    cli.add_command(sailbox)


@click.group(
    name="box",
    help=(
        "Create, run commands on, inspect, and tear down sailboxes — the "
        "sandbox VMs that host your code. Each sailbox belongs to an app "
        "and has its own filesystem, CPU/memory budget, and optional "
        "ingress ports."
    ),
)
@with_global_flags
def sailbox(ctx: click.Context) -> None:
    pass


# Verbs intentionally not exposed yet:
#   shell/ssh — no PTY/SSH support on the worker proxy / guest agent.
#   cp/sync   — no first-class file-transfer RPC on the worker proxy.
# Add these subcommands once the corresponding backend support lands; we'd
# rather omit a verb than ship one that always fails.


@sailbox.command(name="create", help="create a new sailbox.")
@click.option("--app", "app_name", required=True, help="app name (created if missing).")
@click.option("--name", required=True, help="sailbox name within the app.")
@click.option(
    "--image",
    type=click.Choice(sorted(_BASE_IMAGES), case_sensitive=False),
    default="debian-arm64",
    show_default=True,
    help="base image.",
)
@click.option(
    "--cpu",
    type=click.IntRange(min=1),
    default=1,
    show_default=True,
    help="vCPU count (>= 1).",
)
@click.option(
    "--memory",
    default="1g",
    show_default=True,
    help="memory size with m/g suffix, or bare integer MiB (1024-65536 MiB).",
)
@click.option(
    "--disk",
    default="8g",
    show_default=True,
    help="state disk size with optional g suffix (1-64 GiB).",
)
@click.option(
    "--port",
    "ports",
    type=click.IntRange(1, 65535),
    multiple=True,
    help="ingress port to expose (repeatable: --port 8080 --port 9090).",
)
@with_global_flags
def _create(
    ctx: click.Context,
    app_name: str,
    name: str,
    image: str,
    cpu: int,
    memory: str,
    disk: str,
    ports: Tuple[int, ...],
) -> int:
    out = output(ctx)
    apply_config_or_exit(out)
    image_def: ImageDefinition = _BASE_IMAGES[image]
    try:
        memory_mib = _parse_memory(memory)
        disk_gib = _parse_disk(disk)
    except ValueError as exc:
        out.error(str(exc), code="invalid_argument")
        return 2

    found_app = App.find(name=app_name, mint_if_missing=True)
    try:
        sb = Sailbox.create(
            image=image_def,
            app=found_app,
            name=name,
            cpu=cpu,
            memory_mib=memory_mib,
            disk_gib=disk_gib,
            ingress_ports=list(ports) or None,
        )
    except ValueError as exc:
        # SDK-side input validation (size bounds, name shape, etc.) — surface
        # as invalid_argument so scripts get exit-2, matching the local checks
        # above.
        out.error(str(exc), code="invalid_argument")
        return 2
    # Cache write must be best-effort: the sailbox is already provisioned
    # server-side and counted against the user's quota, so a local write
    # failure (unwritable SAIL_HOME, disk full) must not surface as a
    # non-zero exit. Otherwise scripts retry and create duplicate VMs.
    try:
        save_sailbox_record(
            SailboxRecord(
                sailbox_id=sb.sailbox_id,
                name=sb.name,
                app_id=found_app.id,
                exec_endpoint=sb.exec_endpoint,
                worker_address=sb.worker_address,
            )
        )
    except OSError as exc:
        sys.stderr.write(
            f"sail: warning: created sailbox {sb.sailbox_id} but failed to "
            f"cache its exec endpoint locally ({exc}). `sail box exec` "
            f"and `listeners` will not work for this sailbox until "
            f"~/.sail/ is writable.\n"
        )
    payload = {
        "sailbox_id": sb.sailbox_id,
        "name": sb.name,
        "app": found_app.name,
        "app_id": found_app.id,
        "status": sb.status,
        "worker_address": sb.worker_address,
        "exec_endpoint": sb.exec_endpoint,
        "ingress_ports": list(ports),
    }
    # worker_address / exec_endpoint are internal infrastructure addresses —
    # the CLI uses them for the local exec cache, but they're not stable and
    # users shouldn't script against them. Keep them in --json for power users
    # / tooling, but elide from the default text output.
    text = (
        f"sailbox_id:    {sb.sailbox_id}\n"
        f"name:          {sb.name}\n"
        f"app:           {found_app.name} ({found_app.id})\n"
        f"status:        {sb.status}\n"
        f"ports:         {', '.join(map(str, ports)) or '(none)'}"
    )
    out.emit(payload, text=text)
    return 0


@sailbox.command(name="list", help="list sailboxes for the current org.")
@click.option("--app", "app_name", default=None, help="filter by app name.")
@click.option("--status", "status_filter", default=None, help="filter by status.")
@click.option("--search", default=None, help="filter by sailbox_id/name substring.")
@click.option(
    "--limit",
    type=click.IntRange(1, 100),
    default=50,
    show_default=True,
    help="max rows to return (1-100).",
)
@click.option(
    "--offset",
    type=click.IntRange(min=0),
    default=0,
    show_default=True,
    help="rows to skip for pagination.",
)
@with_global_flags
def _list(
    ctx: click.Context,
    app_name: Optional[str],
    status_filter: Optional[str],
    search: Optional[str],
    limit: int,
    offset: int,
) -> int:
    out = output(ctx)
    apply_config_or_exit(out)
    app_id: Optional[str] = None
    if app_name is not None:
        try:
            app = App.find(name=app_name)
        except LookupError:
            # An unknown app name has zero sailboxes by definition. Emit an
            # empty envelope so scripts get the same shape they would for a
            # known-but-empty app, instead of a 404 dressed up as exit-1.
            empty: dict[str, Any] = {
                "data": [],
                "limit": limit,
                "offset": offset,
                "total": 0,
                "has_more": False,
            }
            out.emit(empty, text="(no sailboxes)")
            return 0
        except PermissionError as exc:
            out.error(str(exc), code="permission_denied")
            return 1
        app_id = app.id

    try:
        page = Sailbox.list_page(
            app=app_id,
            status=status_filter,
            search=search,
            limit=limit,
            offset=offset,
        )
    except ValueError as exc:
        # Backend rejects out-of-range pagination with 400, which the SDK
        # surfaces as ValueError. Route through invalid_argument / exit 2 so
        # automation can distinguish caller mistakes from transient backend
        # failures, matching `sail box show` and the rest of the CLI's
        # input-error contract.
        out.error(str(exc), code="invalid_argument")
        return 2
    except PermissionError as exc:
        out.error(str(exc), code="permission_denied")
        return 1
    except RuntimeError as exc:
        out.error(str(exc), code="server_error")
        return 1

    payload = _page_to_envelope(page)
    now = datetime.now(timezone.utc)
    text = _render_sailbox_table(page.items, now=now)
    out.emit(payload, text=text)
    return 0


def _page_to_envelope(page: SailboxPage) -> dict[str, Any]:
    """Render a SailboxPage as the same envelope shape the backend returns.

    Scripts that page through `sail box list --json` rely on these field
    names verbatim; keep them in lockstep with the public HTTP response.
    """
    return {
        "data": [dataclasses.asdict(info) for info in page.items],
        "limit": page.limit,
        "offset": page.offset,
        "total": page.total,
        "has_more": page.has_more,
    }


def _render_sailbox_table(rows: List[SailboxInfo], *, now: datetime) -> str:
    if not rows:
        return "(no sailboxes)"
    columns = ("SAILBOX_ID", "NAME", "APP", "STATUS", "CPU", "MEM", "AGE")
    body: List[List[str]] = []
    for row in rows:
        body.append(
            [
                row.sailbox_id,
                row.name,
                row.app_name,
                row.status,
                str(row.vcpu_count),
                _format_memory_mib(row.memory_mib),
                _format_age(row.created_at, now=now),
            ]
        )
    widths = [
        max(len(columns[i]), *(len(r[i]) for r in body)) for i in range(len(columns))
    ]
    lines = ["  ".join(columns[i].ljust(widths[i]) for i in range(len(columns)))]
    for row in body:
        lines.append("  ".join(row[i].ljust(widths[i]) for i in range(len(columns))))
    return "\n".join(lines)


def _format_memory_mib(value: Any) -> str:
    try:
        mib = int(value)
    except (TypeError, ValueError):
        return ""
    if mib >= 1024 and mib % 1024 == 0:
        return f"{mib // 1024}g"
    return f"{mib}m"


def _format_age(created_at: Any, *, now: datetime) -> str:
    if not isinstance(created_at, str) or not created_at:
        return ""
    raw = created_at.replace("Z", "+00:00")
    try:
        created = datetime.fromisoformat(raw)
    except ValueError:
        return ""
    delta = now - created
    seconds = int(delta.total_seconds())
    if seconds < 0:
        # Clock skew between client and server can produce a negative delta.
        # Render as "0m ago" rather than a confusing negative.
        seconds = 0
    if seconds < 60:
        return f"{seconds}s ago"
    minutes = seconds // 60
    if minutes < 60:
        return f"{minutes}m ago"
    hours = minutes // 60
    if hours < 24:
        return f"{hours}h ago"
    days = hours // 24
    return f"{days}d ago"


@sailbox.command(
    name="exec",
    # ignore_unknown_options lets shell-form args that look like CLI flags
    # (e.g. `grep -r foo /opt`) pass through to the guest without forcing
    # the user to type a literal `--` separator.
    #
    # allow_interspersed_args=False stops Click from continuing to parse
    # *known* options past the first positional argument. Without it,
    # `sail box exec sb echo --timeout 30 hi` would silently strip
    # `--timeout 30` from the guest command and apply it to the CLI's own
    # --timeout — a footgun for any guest binary that uses the same flag
    # names (--timeout, --cwd, --background). Tradeoff: CLI options must
    # come before the sailbox_id (matches `python -m`, `modal run`, etc.).
    context_settings={
        "ignore_unknown_options": True,
        "allow_interspersed_args": False,
    },
    help=(
        "Run a shell command or @sail.function on a sailbox.\n\n"
        "Shell form — everything after the sailbox id is forwarded to the "
        "guest verbatim, so guest flags pass through without a `--` "
        "separator:\n\n"
        "  sail box exec [--timeout N] [--cwd DIR] [--background] "
        "<id> CMD [ARGS...]\n\n"
        "Function form — if the first token after <id> contains `::`, it's "
        "resolved as a @sail.function spec (MODULE::FN or PATH.py::FN) and "
        "the rest of the tokens are passed as its arguments:\n\n"
        "  sail box exec [--timeout N] [--cwd DIR] <id> MODULE::FN [ARGS...]\n\n"
        "Function arguments are ast.literal_eval'd if possible (so `42` is "
        "an int, `'hi'` is a str) and fall back to the raw string otherwise. "
        "A token of the form `key=value` whose key is a valid Python "
        "identifier becomes a kwarg.\n\n"
        "CLI options like --timeout must appear before the sailbox id; "
        "anything after the id (including option-like tokens such as "
        "`--color=auto`) is part of the guest command. A leading `--` after "
        "the id is consumed as the explicit end-of-options marker."
    ),
)
@click.argument("sailbox_id")
@click.option("--cwd", default=None, help="working directory inside the guest.")
@click.option(
    "--timeout",
    type=int,
    default=None,
    help="kill the command after this many seconds.",
)
@click.option(
    "--background",
    is_flag=True,
    default=False,
    help="detach the command and return once the guest accepts it.",
)
# nargs=-1 + type=click.UNPROCESSED preserves option-like tokens verbatim
# (e.g. `--color=red`) so they reach the guest unparsed. We deliberately do
# NOT mark it required: an empty command path emits our own structured error
# (code=invalid_argument) instead of Click's generic "Missing argument".
@click.argument("command", nargs=-1, type=click.UNPROCESSED)
@with_global_flags
def _exec(
    ctx: click.Context,
    sailbox_id: str,
    cwd: Optional[str],
    timeout: Optional[int],
    background: bool,
    command: Tuple[str, ...],
) -> int:
    out = output(ctx)
    # `ignore_unknown_options=True` lets guest flags pass through without a
    # `--` separator, but it also means a mistyped CLI option before the id
    # (`box exec --timeuot 30 sb echo`) is parsed as the <sailbox_id> rather
    # than rejected. A real sailbox id never starts with `-`, so catch that
    # here with a clear message instead of a confusing downstream error.
    # This is pure argv validation, so it runs before config is loaded.
    if sailbox_id.startswith("-"):
        out.error(
            f"expected a sailbox id but got {sailbox_id!r}, which looks like "
            f"an option. CLI options (--cwd, --timeout, --background) must "
            f"come before the sailbox id; everything after it is the guest "
            f"command.",
            code="invalid_argument",
        )
        return 2
    apply_config_or_exit(out)
    # With allow_interspersed_args=False, Click does not consume a `--`
    # separator after the sailbox id — it falls through into `command`.
    # Strip a leading `--` so the explicit end-of-options form
    # (`box exec --timeout N <id> -- cmd args`) resolves to `cmd args`
    # rather than trying to exec `--` as the guest program.
    if command and command[0] == "--":
        command = command[1:]
    if command and looks_like_function_spec(command[0]):
        return _exec_function_cmd(
            out=out,
            sailbox_id=sailbox_id,
            function_spec=command[0],
            argv=command[1:],
            timeout=timeout,
            background=background,
            cwd=cwd,
        )
    if not command:
        out.error(
            "missing command — use `sail box exec ID [FLAGS] CMD [ARGS...]` "
            "or `sail box exec ID MODULE::FN [ARGS...]`.",
            code="invalid_argument",
        )
        return 2
    sb = _hydrate_for_exec(sailbox_id, out)
    if sb is None:
        return 2

    cmd_str = _shell_join(list(command))
    try:
        request = sb.exec(
            cmd_str,
            timeout=timeout,
            background=background,
            cwd=cwd,
        )
    except ValueError as exc:
        out.error(str(exc), code="invalid_argument")
        return 2
    if background:
        payload = {
            "sailbox_id": sb.sailbox_id,
            "exec_request_id": request.exec_request_id,
            "background": True,
        }
        out.emit(
            payload,
            text=f"Launched background exec {request.exec_request_id}",
        )
        return 0

    result = request.wait()
    if out.json_mode:
        out.emit(
            {
                "sailbox_id": sb.sailbox_id,
                "exec_request_id": request.exec_request_id,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "returncode": result.returncode,
            }
        )
    else:
        if result.stdout:
            sys.stdout.write(result.stdout)
            if not result.stdout.endswith("\n"):
                sys.stdout.write("\n")
        if result.stderr:
            sys.stderr.write(result.stderr)
            if not result.stderr.endswith("\n"):
                sys.stderr.write("\n")
    return result.returncode


def _exec_function_cmd(
    *,
    out: Output,
    sailbox_id: str,
    function_spec: str,
    argv: Tuple[str, ...],
    timeout: Optional[int],
    background: bool,
    cwd: Optional[str],
) -> int:
    """Run the function form of ``sail box exec``."""
    if background:
        out.error(
            "--background is not supported for function execution — function "
            "results are returned synchronously.",
            code="invalid_argument",
        )
        return 2
    # Hydrate before resolving the spec — resolve_function_spec runs the
    # user's module top-level code, which we don't want to do if the remote
    # exec can never run anyway.
    sb = _hydrate_for_exec(sailbox_id, out)
    if sb is None:
        return 2

    # Parse argv before resolving the spec: resolve_function_spec runs the
    # user's module top-level code, and argv parsing is pure/local — no
    # reason to run user code only to reject the call on a duplicate kwarg.
    try:
        args, kwargs = parse_function_args(argv)
    except ValueError as exc:
        out.error(str(exc), code="invalid_argument")
        return 2

    try:
        sail_fn = resolve_function_spec(function_spec)
    except ValueError as exc:
        out.error(str(exc), code="invalid_argument")
        return 2

    try:
        result = sb.exec(
            sail_fn,
            *args,
            timeout=timeout,
            cwd=cwd,
            kwargs=kwargs,
        )
    except ValueError as exc:
        out.error(str(exc), code="invalid_argument")
        return 2
    except SailboxFunctionSerializationError as exc:
        out.error(str(exc) or exc.__class__.__name__, code="serialization_error")
        return 1
    except SailboxFunctionError as exc:
        # Print the remote traceback to stderr in text mode so users can
        # debug without re-running with logs.
        fields: Dict[str, Any] = {
            "error_type": exc.error_type,
            "traceback": exc.traceback,
            "stdout": exc.stdout,
            "stderr": exc.stderr,
        }
        out.error(str(exc), code="function_error", **fields)
        if not out.json_mode and exc.traceback:
            sys.stderr.write(exc.traceback)
            if not exc.traceback.endswith("\n"):
                sys.stderr.write("\n")
        return 1
    except SailboxExecutionError as exc:
        out.error(str(exc) or exc.__class__.__name__, code="execution_error")
        return 1

    if out.json_mode:
        out.emit({"sailbox_id": sb.sailbox_id, "result": result})
    else:
        sys.stdout.write(pprint.pformat(result))
        sys.stdout.write("\n")
    return 0


@sailbox.command(
    name="show",
    help="show sailbox metadata (app, size, status, timestamps).",
)
@click.argument("sailbox_id")
@with_global_flags
def _show(ctx: click.Context, sailbox_id: str) -> int:
    out = output(ctx)
    apply_config_or_exit(out)
    try:
        info = Sailbox.get(sailbox_id)
    except LookupError as exc:
        out.error(str(exc), code="not_found")
        return 1
    except PermissionError as exc:
        out.error(str(exc), code="permission_denied")
        return 1
    except ValueError as exc:
        # SDK raises ValueError for malformed sailbox IDs (the backend
        # returns 400). Route through invalid_argument / exit 2 so
        # automation can distinguish caller mistakes from transient backend
        # failures.
        out.error(str(exc), code="invalid_argument")
        return 2
    except RuntimeError as exc:
        out.error(str(exc), code="server_error")
        return 1

    payload = dataclasses.asdict(info)
    text = _render_sailbox_show(info)
    out.emit(payload, text=text)
    return 0


def _render_sailbox_show(row: SailboxInfo) -> str:
    lines = [
        f"sailbox_id:    {row.sailbox_id}",
        f"name:          {row.name}",
        f"app:           {row.app_name} ({row.app_id})",
        f"status:        {row.status}",
        f"cpu:           {row.vcpu_count}",
        f"memory:        {_format_memory_mib(row.memory_mib)}",
        f"disk:          {row.state_disk_size_gib}g",
        f"architecture:  {row.architecture}",
        f"created_at:    {row.created_at}",
        f"updated_at:    {row.updated_at}",
    ]
    if row.started_at:
        lines.append(f"started_at:    {row.started_at}")
    if row.error_message:
        lines.append(f"error:         {row.error_message}")
    return "\n".join(lines)


@sailbox.command(name="listeners", help="list ingress listeners.")
@click.argument("sailbox_id")
@with_global_flags
def _listeners(ctx: click.Context, sailbox_id: str) -> int:
    out = output(ctx)
    apply_config_or_exit(out)
    sb = _hydrate_for_exec(sailbox_id, out)
    if sb is None:
        return 2
    listeners = sb.listeners()
    rows = [
        {
            "port": ln.port,
            "url": ln.url,
            "protocol": ln.protocol,
            "route_status": ln.route_status,
        }
        for ln in listeners
    ]
    out.emit_table(rows, columns=("port", "protocol", "route_status", "url"))
    return 0


@sailbox.command(name="url", help="print the public URL for a guest port.")
@click.argument("sailbox_id")
@click.option("--port", required=True, type=click.IntRange(1, 65535))
@with_global_flags
def _url(ctx: click.Context, sailbox_id: str, port: int) -> int:
    out = output(ctx)
    apply_config_or_exit(out)
    sb = _hydrate_for_exec(sailbox_id, out)
    if sb is None:
        return 2
    listener = sb.listener(port)
    payload = {
        "sailbox_id": sailbox_id,
        "port": listener.port,
        "url": listener.url,
        "route_status": listener.route_status,
    }
    out.emit(payload, text=listener.url)
    return 0


@sailbox.command(name="terminate", help="terminate a sailbox.")
@click.argument("sailbox_id")
@with_global_flags
def _terminate(ctx: click.Context, sailbox_id: str) -> int:
    out = output(ctx)
    apply_config_or_exit(out)
    sb = _hydrate_for_lifecycle(sailbox_id)
    sb.terminate()
    out.emit(
        {"sailbox_id": sailbox_id, "status": "terminated"},
        text=f"Terminated {sailbox_id}",
    )
    # Backend terminate already succeeded — a local cache cleanup failure
    # (e.g. directory permission error on ~/.sail/sailboxes) must not surface
    # as a non-zero exit, or automation retries terminate on an already-dead
    # sailbox. delete_sailbox_record() already tolerates FileNotFoundError;
    # warn-and-continue on the rest.
    try:
        delete_sailbox_record(sailbox_id)
    except OSError as exc:
        sys.stderr.write(
            f"sail: warning: terminated sailbox {sailbox_id} but failed "
            f"to remove its local cache record ({exc}).\n"
        )
    return 0


@sailbox.command(name="sleep", help="sleep a sailbox.")
@click.argument("sailbox_id")
@with_global_flags
def _sleep(ctx: click.Context, sailbox_id: str) -> int:
    out = output(ctx)
    apply_config_or_exit(out)
    sb = _hydrate_for_lifecycle(sailbox_id)
    sb.sleep()
    out.emit(
        {"sailbox_id": sailbox_id, "status": sb.status},
        text=f"Sailbox {sailbox_id} is sleeping",
    )
    return 0


@sailbox.command(name="pause", help="pause a sailbox.")
@click.argument("sailbox_id")
@with_global_flags
def _pause(ctx: click.Context, sailbox_id: str) -> int:
    out = output(ctx)
    apply_config_or_exit(out)
    sb = _hydrate_for_lifecycle(sailbox_id)
    sb.pause()
    out.emit(
        {"sailbox_id": sailbox_id, "status": sb.status},
        text=f"Sailbox {sailbox_id} is paused",
    )
    return 0


@sailbox.command(name="resume", help="resume a sailbox.")
@click.argument("sailbox_id")
@with_global_flags
def _resume(ctx: click.Context, sailbox_id: str) -> int:
    out = output(ctx)
    apply_config_or_exit(out)
    record = load_sailbox_record(sailbox_id)
    sb = _hydrate_for_lifecycle(
        sailbox_id,
        exec_endpoint=record.exec_endpoint if record is not None else "",
    )
    sb.resume()
    if record is not None:
        # Best-effort write: backend resume already succeeded, so a local
        # cache write failure (read-only ~/.sail, disk full) must not bubble
        # up as a non-zero exit and trigger an automation retry on an
        # already-resumed sailbox. Same shape as the create path.
        try:
            save_sailbox_record(
                replace(
                    record,
                    worker_address=sb.worker_address,
                    exec_endpoint=sb.exec_endpoint,
                )
            )
        except OSError as exc:
            sys.stderr.write(
                f"sail: warning: resumed sailbox {sailbox_id} but failed "
                f"to update its local cache ({exc}). `sail box exec` will "
                f"not work for this sailbox until ~/.sail/ is writable.\n"
            )
    out.emit(
        {
            "sailbox_id": sailbox_id,
            "status": sb.status,
            "worker_address": sb.worker_address,
        },
        text=(
            f"Sailbox {sailbox_id} resumed (status={sb.status}, "
            f"worker={sb.worker_address})"
        ),
    )
    return 0


@sailbox.command(name="checkpoint", help="checkpoint a sailbox.")
@click.argument("sailbox_id")
@with_global_flags
def _checkpoint(ctx: click.Context, sailbox_id: str) -> int:
    out = output(ctx)
    apply_config_or_exit(out)
    sb = _hydrate_for_lifecycle(sailbox_id)
    sb.checkpoint()
    # Checkpoint is a snapshot, not a state transition — don't include a
    # `status` field, since we have no fresh state to report.
    out.emit(
        {"sailbox_id": sailbox_id},
        text=f"Checkpointed {sailbox_id}",
    )
    return 0


def _hydrate_for_lifecycle(sailbox_id: str, *, exec_endpoint: str = "") -> Sailbox:
    """Build a minimal Sailbox for scheduler-routed lifecycle calls.

    terminate/sleep/pause/resume/checkpoint dispatch through the scheduler by
    sailbox_id, so they don't need the cached worker endpoint. Resume callers
    may seed ``exec_endpoint`` from the local cache so that a response that
    omits ``exec_proxy_endpoint`` leaves the cached value intact rather than
    blanking it.
    """
    return Sailbox(
        sailbox_id=sailbox_id,
        name="",
        status="running",
        worker_address="",
        exec_endpoint=exec_endpoint,
    )


def _hydrate_for_exec(sailbox_id: str, out: Output) -> Optional[Sailbox]:
    """Hydrate a Sailbox with its cached exec endpoint, or emit a clear error.

    ``Sailbox.create`` returns ``exec_endpoint`` only at creation time — the
    status and resume endpoints don't expose it — so the CLI persists a
    per-sailbox record at ``~/.sail/sailboxes/<id>.json`` and rehydrates from
    there. Once the backend exposes the endpoint on those paths, refresh on
    cache-miss instead of erroring out.
    """
    record = load_sailbox_record(sailbox_id)
    if record is None or not record.exec_endpoint:
        out.error(
            f"no cached exec endpoint for {sailbox_id!r}. The CLI caches it at "
            f"creation time under ~/.sail/sailboxes/. This usually means the "
            f"sailbox was created in a different shell, or it was resumed and "
            f"may now live on a different worker — re-create the sailbox, or "
            f"run `sail box create` from the same shell that will run "
            f"`sail box exec`.",
            code="missing_state",
        )
        return None
    return Sailbox(
        sailbox_id=record.sailbox_id,
        name=record.name,
        status="running",
        worker_address=record.worker_address,
        exec_endpoint=record.exec_endpoint,
    )


def _parse_memory(value: str) -> int:
    """Convert a memory size to MiB (the SDK's unit). Accepts m/g suffixes; a
    bare integer is treated as MiB.

    Integer-only on purpose: ``int(float(...))`` would silently truncate
    ``1.9g`` to 1945 MiB (under-provisioning) and accept ``1e9999g`` as
    inf → OverflowError (bypassing the invalid_argument path).
    """
    raw = value.strip().lower()
    if not raw:
        raise ValueError("memory must be non-empty")
    try:
        if raw.endswith("g"):
            return int(raw[:-1]) * 1024
        if raw.endswith("m"):
            return int(raw[:-1])
        return int(raw)
    except ValueError:
        raise ValueError(
            f"invalid memory value {value!r}: "
            f"expected an integer with optional m/g suffix (e.g. 512m, 2g, 1024)"
        ) from None


def _parse_disk(value: str) -> int:
    """Convert a disk size to GiB (the SDK's unit). Accepts a g suffix; a bare
    integer is treated as GiB. Integer-only — see ``_parse_memory``."""
    raw = value.strip().lower()
    if not raw:
        raise ValueError("disk must be non-empty")
    try:
        if raw.endswith("g"):
            return int(raw[:-1])
        return int(raw)
    except ValueError:
        raise ValueError(
            f"invalid disk value {value!r}: "
            f"expected an integer with optional g suffix (e.g. 16g, 32)"
        ) from None


def _shell_join(parts: List[str]) -> str:
    """Quote argv parts into one shell string for SDK exec().

    SDK exec() runs the string under ``/bin/sh -lc``. Quoting here prevents
    spaces/globs from being re-expanded on the guest.
    """
    return " ".join(shlex.quote(p) for p in parts)
