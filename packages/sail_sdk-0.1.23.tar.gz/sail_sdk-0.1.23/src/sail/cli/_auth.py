"""`sail auth` subcommands."""

from __future__ import annotations

import os

import click

from sail import Config
from sail.cli._globals import (
    apply_config_best_effort,
    load_config_or_exit,
    output,
    with_global_flags,
)
from sail.cli._state import config_path, save_config_file


def register(cli: click.Group) -> None:
    cli.add_command(auth)


@click.group(
    name="auth",
    help=(
        "Show or clear the API key the CLI is using. The CLI reads "
        "SAIL_API_KEY first, then `api_key` from ~/.sail/config.toml. "
        "Create a key in the Sail dashboard, then either export it or "
        "persist it with `sail config set api_key=sk_...`."
    ),
)
@with_global_flags
def auth(ctx: click.Context) -> None:
    pass


@auth.command(name="whoami", help="show the active API key and target environment.")
@with_global_flags
def whoami(ctx: click.Context) -> int:
    out = output(ctx)
    # whoami reports the *resolved* key/url, so persisted config has to be
    # folded into the environment first; best-effort because a malformed file
    # must not stop the diagnostic from reporting env-derived state.
    apply_config_best_effort()
    # `sail auth whoami` is the diagnostic surface for SAIL_MODE/SAIL_API_KEY
    # misconfiguration, so we use from_env_optional_api_key() — it validates
    # SAIL_MODE and resolves api_url with overrides, without requiring an
    # API key.
    try:
        cfg = Config.from_env_optional_api_key()
    except ValueError as exc:
        out.error(str(exc), code="invalid_argument")
        return 2
    resolved_mode = os.environ.get("SAIL_MODE", "").strip().lower() or "prod"
    payload = {
        "mode": resolved_mode,
        "api_url": cfg.api_url,
        "api_key": _mask(cfg.api_key),
        "api_key_present": bool(cfg.api_key),
        "config_file": str(config_path()),
    }
    text = (
        f"mode:          {payload['mode']}\n"
        f"api_url:       {payload['api_url']}\n"
        f"api_key:       {payload['api_key'] or '(not set)'}\n"
        f"config_file:   {payload['config_file']}\n"
    )
    out.emit(payload, text=text.rstrip("\n"))
    return 0 if cfg.api_key else 1


@auth.command(
    name="logout", help="remove the api_key entry from the local config file."
)
@with_global_flags
def logout(ctx: click.Context) -> int:
    out = output(ctx)
    # logout edits the config file rather than the environment, so it loads
    # the raw dict (it needs to know what to remove). load_config_or_exit
    # emits the same `sail config reset` recovery hint as the other
    # config-reading commands.
    values = load_config_or_exit(out)
    if "api_key" not in values:
        out.emit(
            {"removed": False, "config_file": str(config_path())},
            text="No api_key entry in config file.",
        )
        return 0
    values.pop("api_key")
    save_config_file(values)
    out.emit(
        {"removed": True, "config_file": str(config_path())},
        text=f"Removed api_key from {config_path()}",
    )
    return 0


def _mask(api_key: str) -> str:
    if not api_key:
        return ""
    if len(api_key) <= 8:
        return "***"
    return f"{api_key[:4]}…{api_key[-4:]}"
