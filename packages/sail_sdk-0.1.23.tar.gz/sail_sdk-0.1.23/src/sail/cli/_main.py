"""Entry point for the ``sail`` CLI."""

from __future__ import annotations

import os
import sys
import traceback
from typing import List, Optional

import click

from sail.__about__ import __version__
from sail.cli import _app, _auth, _config, _run, _sailbox
from sail.cli._globals import output, with_global_flags
from sail.cli._output import Output


@click.group(
    invoke_without_command=True,
    context_settings={"help_option_names": ["-h", "--help"]},
    help="Manage sailboxes and apps from the command line.",
)
@click.version_option(__version__, "-v", "--version", message="%(version)s")
@with_global_flags
def cli(ctx: click.Context) -> None:
    # The root callback intentionally does no config loading: operational
    # commands fold ~/.sail/config.toml into the environment themselves via
    # `apply_config_or_exit`, at a point where Click has already parsed
    # `--json`/`--help` at every level. `version`/`config`/`auth` never load
    # it (or degrade gracefully), so a malformed file can't block `--help` or
    # the `config reset` recovery path.
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help(), err=True)
        ctx.exit(2)


@cli.command(name="version", help="print the CLI version.")
@with_global_flags
def _version_cmd(ctx: click.Context) -> None:
    """Equivalent to ``sail --version`` / ``sail -v``, but works from a
    script that wants structured output via ``sail --json version``."""
    output(ctx).emit({"version": __version__}, text=__version__)


# `_run` has no register() — it self-attaches to the box group on import
# (see _run.py). The modules below register their commands explicitly.
_auth.register(cli)
_config.register(cli)
_app.register(cli)
_sailbox.register(cli)


def main(argv: Optional[List[str]] = None) -> int:
    """CLI entry point.

    Always returns an int exit code. Parser-level exits (``--help``,
    ``--version``, unknown subcommand, bad option) come through Click as
    ``UsageError`` / ``Exit``; we surface their exit_code instead of letting
    SystemExit escape, so callers can treat the function as a uniform
    ``int main(argv)`` and the ``sail`` console_script entry point keeps
    working unchanged.
    """
    args = list(argv) if argv is not None else sys.argv[1:]
    try:
        result = cli.main(args=args, standalone_mode=False, prog_name="sail")
    except click.exceptions.UsageError as exc:
        exc.show()
        return exc.exit_code
    except click.exceptions.Exit as exc:
        return exc.exit_code
    except KeyboardInterrupt:
        sys.stderr.write("sail: interrupted\n")
        return 130
    except Exception as exc:  # noqa: BLE001 -- top-level CLI boundary
        # Last-resort handler: reached only if a leaf raises instead of
        # returning via ``output.error(...); return N``. Leaves emit their
        # expected errors with the correct ``--json`` mode already; for an
        # unexpected crash, a plain argv membership test is enough to still
        # shape the envelope for JSON consumers.
        out = Output(json_mode="--json" in args)
        out.error(str(exc) or exc.__class__.__name__, code=exc.__class__.__name__)
        if os.environ.get("SAIL_DEBUG"):
            traceback.print_exc()
        return 1
    return int(result or 0)
