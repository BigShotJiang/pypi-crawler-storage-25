"""Output helpers shared by all CLI subcommands.

Two output modes:
  - text: human-readable tables / single lines on stdout
  - json: a single JSON document on stdout

Errors always go to stderr. In JSON mode, errors are still emitted as
``{"error": {...}}`` on stdout so scripts can parse them uniformly, and a
short human-readable line is mirrored on stderr.
"""

from __future__ import annotations

import json
import sys
from typing import Any, List, Mapping, Optional, Sequence


class Output:
    def __init__(self, *, json_mode: bool) -> None:
        self.json_mode = json_mode

    def emit(self, payload: Any, *, text: Optional[str] = None) -> None:
        if self.json_mode:
            json.dump(payload, sys.stdout, indent=2, sort_keys=True, default=str)
            sys.stdout.write("\n")
        elif text is not None:
            sys.stdout.write(text)
            if not text.endswith("\n"):
                sys.stdout.write("\n")
        else:
            sys.stdout.write(_format_default(payload))

    def emit_table(
        self,
        rows: Sequence[Mapping[str, Any]],
        *,
        columns: Sequence[str],
    ) -> None:
        if self.json_mode:
            self.emit(list(rows))
            return
        if not rows:
            sys.stdout.write("(no rows)\n")
            return
        sys.stdout.write(_render_table(rows, columns))

    def error(self, message: str, *, code: str = "error", **fields: Any) -> None:
        payload = {"error": {"code": code, "message": message, **fields}}
        if self.json_mode:
            json.dump(payload, sys.stdout, indent=2, sort_keys=True, default=str)
            sys.stdout.write("\n")
        sys.stderr.write(f"sail: {message}\n")


def _format_default(payload: Any) -> str:
    if isinstance(payload, str):
        return payload + ("" if payload.endswith("\n") else "\n")
    if isinstance(payload, Mapping):
        return "".join(f"{k}: {v}\n" for k, v in payload.items())
    if isinstance(payload, (list, tuple)):
        return "\n".join(str(item) for item in payload) + "\n"
    return f"{payload}\n"


def _render_table(rows: Sequence[Mapping[str, Any]], columns: Sequence[str]) -> str:
    headers = [c.upper() for c in columns]
    body: List[List[str]] = []
    for row in rows:
        body.append([_str(row.get(c, "")) for c in columns])
    widths = [
        max(len(headers[i]), *(len(r[i]) for r in body)) for i in range(len(columns))
    ]
    lines: List[str] = []
    lines.append("  ".join(headers[i].ljust(widths[i]) for i in range(len(columns))))
    for row in body:
        lines.append("  ".join(row[i].ljust(widths[i]) for i in range(len(columns))))
    return "\n".join(lines) + "\n"


def _str(value: Any) -> str:
    if value is None:
        return ""
    return str(value)
