"""Shared MODULE::FN spec resolution and argument parsing for the CLI.

Used by both ``sail box exec ID MODULE::FN`` (runs an existing sailbox) and
``sail run MODULE::FN`` (creates an ephemeral sailbox). Both commands need to
load a Python function from the user's CWD and parse a tail of CLI tokens
into Python args/kwargs, so the logic lives here rather than being duplicated
across the two command modules.
"""

from __future__ import annotations

import ast
import os
import runpy
import sys
from typing import Any, Dict, List, Optional, Tuple

from sail.function import SailFunction


def looks_like_function_spec(token: str) -> bool:
    """``::`` in the first command token opts into the function form, mirroring
    Modal's ``modal run script.py::fn``. ``::`` (not ``:``) avoids clashing
    with Windows drive letters and PATH-like env values."""
    return "::" in token


def resolve_function_spec(spec: str) -> SailFunction:
    """Resolve a ``MODULE::FN`` or ``PATH.py::FN`` spec to a ``SailFunction``.

    The user's module is run via ``runpy`` with ``run_name="__main__"`` so
    the resulting function has ``__module__ == "__main__"``. That's the
    trigger for cloudpickle's by-value heuristic, which ships the function
    (and its closure) to a remote sailbox without sharing our sys.path —
    mirroring what already happens for ``python script.py`` callers.

    Targets ending in ``.py`` or containing a path separator are treated as
    filesystem paths; everything else is a dotted module name. Raises
    ``ValueError`` with a user-facing message on every failure.
    """
    target, _, attr = spec.rpartition("::")
    if not target or not attr:
        raise ValueError(
            f"function spec {spec!r} must be MODULE::FN or PATH.py::FN "
            f"(e.g. `pkg.mod::fn` or `./script.py::fn`)"
        )
    looks_like_path = target.endswith(".py") or "/" in target or "\\" in target
    saved_path = sys.path[:]
    evicted: Dict[str, Any] = {}
    top: Optional[str] = None
    try:
        if looks_like_path:
            # Precheck: user code can legitimately raise FileNotFoundError
            # at import time, so we can't disambiguate "script missing" from
            # that case by catching FNF around runpy.
            if not os.path.isfile(target):
                raise ValueError(f"file not found: {target!r}")
            # Match `python script.py` semantics — runpy.run_path doesn't add
            # the script's parent to sys.path for file inputs.
            sys.path.insert(0, os.path.dirname(os.path.abspath(target)))
            # No sys.modules eviction here, unlike the dotted branch below:
            # run_path resolves its target by literal filesystem path, never
            # via find_spec/sys.modules, so there is no cached-dependency
            # shadowing of the target to evict. The dotted-branch eviction is
            # specific to run_module's find_spec lookup of the target name.
            namespace = runpy.run_path(target, run_name="__main__")
        else:
            # Match `python -m pkg.mod` — sys.path[0] is the venv bin dir
            # when sail runs via its console-script, so user project modules
            # wouldn't resolve without this.
            sys.path.insert(0, os.getcwd())
            # Force CWD-first when the user's top-level name collides with a
            # preloaded module (sail imports click/grpc/httpx/…). runpy.run_module
            # goes through find_spec, which short-circuits on sys.modules and
            # would otherwise execute the cached dep instead of the CWD module.
            # isdir(top_path) covers both regular and PEP 420 namespace packages.
            top = target.split(".", 1)[0]
            top_path = os.path.join(os.getcwd(), top)
            if top in sys.modules and (
                os.path.isfile(top_path + ".py") or os.path.isdir(top_path)
            ):
                for name in list(sys.modules):
                    if name == top or name.startswith(top + "."):
                        evicted[name] = sys.modules.pop(name)
            namespace = runpy.run_module(target, run_name="__main__")
    except ImportError as exc:
        raise ValueError(f"could not import {target!r}: {exc}") from None
    except (Exception, SystemExit) as exc:  # noqa: BLE001 -- user-controlled module
        # SystemExit is folded in so user `sys.exit()` surfaces as
        # invalid_argument instead of killing the CLI. KeyboardInterrupt
        # propagates so Ctrl-C still works.
        raise ValueError(
            f"error executing {target!r}: {type(exc).__name__}: {exc}"
        ) from None
    finally:
        sys.path[:] = saved_path
        if evicted and top is not None:
            # User code may have loaded shadow top.* submodules during runpy;
            # drop any new entries so cloudpickle pickles them by value (the
            # remote has the preloaded dep at this name, not user code).
            for name in list(sys.modules):
                if (name == top or name.startswith(top + ".")) and name not in evicted:
                    sys.modules.pop(name, None)
        sys.modules.update(evicted)

    if attr not in namespace:
        raise ValueError(f"{target!r} has no attribute {attr!r}")
    obj = namespace[attr]
    if isinstance(obj, SailFunction):
        return obj
    if callable(obj):
        raise ValueError(
            f"{spec!r} resolves to a plain callable; decorate it with "
            f"`@sail.function` so the CLI can run it remotely"
        )
    raise ValueError(f"{spec!r} resolves to {type(obj).__name__}, not a callable")


def parse_function_args(tokens: Tuple[str, ...]) -> Tuple[List[Any], Dict[str, Any]]:
    """Split raw argv tokens into positional and keyword arguments.

    Each token is first checked for ``identifier=value`` shape; if so, value
    is parsed and the pair becomes a kwarg. Otherwise the token itself is
    parsed and appended positionally. Parsing tries ``ast.literal_eval`` and
    falls back to the raw string, so ``42`` → int, ``"hi"`` → str, ``[1,2]``
    → list, and ``some-host`` → ``"some-host"``.

    Positionals and keywords are independent groups, so CLI token order
    between them does not matter: ``fn x=1 2`` and ``fn 2 x=1`` both call
    ``fn(2, x=1)``. There is no "positional after keyword" restriction —
    that is a Python *source* syntax rule, and the parsed groups reach the
    function via ``*args`` / ``**kwargs``, where it does not apply.
    """
    args: List[Any] = []
    kwargs: Dict[str, Any] = {}
    for token in tokens:
        key, sep, raw = token.partition("=")
        if sep and key.isidentifier():
            if key in kwargs:
                raise ValueError(f"duplicate keyword argument {key!r}")
            kwargs[key] = _coerce_literal(raw)
        else:
            args.append(_coerce_literal(token))
    return args, kwargs


def _coerce_literal(raw: str) -> Any:
    """``ast.literal_eval`` with a string fallback for non-literal tokens."""
    try:
        return ast.literal_eval(raw)
    except (SyntaxError, ValueError):
        return raw
