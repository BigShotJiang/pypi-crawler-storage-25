"""Entry point for the ``sail`` CLI."""

from __future__ import annotations

from sail.cli._main import main

__all__ = ["main"]
