"""`sail app` subcommands."""

from __future__ import annotations

import click

from sail.app import App
from sail.cli._globals import apply_config_or_exit, output, with_global_flags
from sail.cli._output import Output


def register(cli: click.Group) -> None:
    cli.add_command(app)


@click.group(
    name="app",
    help=(
        "Apps group related sailboxes under a single name. "
        "`sail box create --app NAME ...` creates the app on demand, "
        "so you usually don't need these commands directly."
    ),
)
@with_global_flags
def app(ctx: click.Context) -> None:
    pass


@app.command(name="find", help="look up an app by name.")
@click.argument("name")
@with_global_flags
def _find(ctx: click.Context, name: str) -> int:
    out = output(ctx)
    apply_config_or_exit(out)
    found = App.find(name=name, mint_if_missing=False)
    return _emit_app(found, out)


@app.command(name="create", help="find or create an app by name.")
@click.argument("name")
@with_global_flags
def _create(ctx: click.Context, name: str) -> int:
    out = output(ctx)
    apply_config_or_exit(out)
    found = App.find(name=name, mint_if_missing=True)
    return _emit_app(found, out)


def _emit_app(app: App, out: Output) -> int:
    payload = {"id": app.id, "name": app.name, "created_at": app.created_at}
    text = f"id:         {app.id}\nname:       {app.name}\ncreated_at: {app.created_at}"
    out.emit(payload, text=text)
    return 0
