"""`sail box run MODULE::FN [ARGS...]` — one-shot ephemeral sailbox.

Sugar for the `box create` → `box exec MODULE::FN` → `box terminate`
sequence: spin up a fresh sailbox, run a `@sail.function`, tear it down in
`finally`. Intended for dev-loop iteration on a function before wiring it
into a longer agent — `sail box create` + `sail box exec` remains the
right path for any workflow that reuses the same sailbox.

Drives sailbox operations through the public SDK surface
(`Sailbox.create`, `sb.exec(SailFunction, ...)`, `sb.terminate`,
`App.find`) per the rule in ``sdk/python/AGENTS.md``.
"""

from __future__ import annotations

import pprint
import secrets
import sys
from typing import Any, Dict, Optional, Tuple

import click

from sail.app import App
from sail.cli._function_spec import (
    parse_function_args,
    resolve_function_spec,
)
from sail.cli._globals import apply_config_or_exit, output, with_global_flags
from sail.cli._sailbox import _BASE_IMAGES, _parse_disk, _parse_memory, sailbox
from sail.cli._state import (
    SailboxRecord,
    delete_sailbox_record,
    save_sailbox_record,
)
from sail.errors import (
    SailboxCreationError,
    SailboxExecutionError,
    SailboxFunctionError,
    SailboxFunctionSerializationError,
)
from sail.image import ImageDefinition
from sail.sailbox import Sailbox


def _generate_name() -> str:
    # Backend rejects duplicate (app_id, name); 32 bits of entropy is plenty.
    return f"run-{secrets.token_hex(4)}"


# Importing this module attaches `run` to the `box` command group as a side
# effect of the decorator below; `_main.py` imports `_run` purely for that
# effect, so there is no `register()` here (unlike `_app`/`_auth`/etc.).
@sailbox.command(
    name="run",
    # Mirror `box exec`: anything after the spec passes through to the
    # function unparsed, even option-like tokens. CLI options for `box run`
    # itself must come before the spec.
    context_settings={
        "ignore_unknown_options": True,
        "allow_interspersed_args": False,
    },
    help=(
        "Run a @sail.function once in a fresh sailbox, then terminate it.\n\n"
        "Shortcut for `box create` + `box exec` + `box terminate` for "
        "iterating on a function during development. For workflows that "
        "reuse the same sailbox, use `sail box create` + `sail box exec` "
        "directly.\n\n"
        "  sail box run [--app NAME] [--cpu N] [--memory SIZE] [--disk SIZE]\n"
        "               [--image NAME] [--port N]... [--name NAME]\n"
        "               [--timeout N] [--cwd DIR] [--keep] MODULE::FN [ARGS...]\n\n"
        "Arguments after MODULE::FN are forwarded to the function and parsed "
        "the same way as `sail box exec` (ast.literal_eval'd, with "
        "`identifier=value` tokens becoming kwargs)."
    ),
)
@click.option(
    "--app",
    "app_name",
    required=True,
    help="app name (created if missing).",
)
@click.option(
    "--image",
    type=click.Choice(sorted(_BASE_IMAGES), case_sensitive=False),
    default="debian-arm64",
    show_default=True,
    help="base image.",
)
@click.option(
    "--cpu",
    type=click.IntRange(min=1),
    default=1,
    show_default=True,
    help="vCPU count (>= 1).",
)
@click.option(
    "--memory",
    default="1g",
    show_default=True,
    help="memory size with m/g suffix, or bare integer MiB (1024-65536 MiB).",
)
@click.option(
    "--disk",
    default="8g",
    show_default=True,
    help="state disk size with optional g suffix (1-64 GiB).",
)
@click.option(
    "--port",
    "ports",
    type=click.IntRange(1, 65535),
    multiple=True,
    help="ingress port to expose (repeatable). Only useful with --keep.",
)
@click.option(
    "--name",
    "name",
    default=None,
    help="sailbox name within the app (default: run-<hex>).",
)
@click.option(
    "--timeout",
    type=int,
    default=None,
    help="kill the function after this many seconds.",
)
@click.option(
    "--cwd",
    default=None,
    help="working directory inside the guest.",
)
@click.option(
    "--keep",
    is_flag=True,
    default=False,
    help="leave the sailbox alive after exec instead of terminating it.",
)
# nargs=-1 + UNPROCESSED keeps option-like tokens verbatim. Deliberately not
# marked required: an empty positional tail emits our own structured error
# below, the same choice `box exec` makes for its command.
@click.argument("argv", nargs=-1, type=click.UNPROCESSED)
@with_global_flags
def _run(
    ctx: click.Context,
    app_name: str,
    image: str,
    cpu: int,
    memory: str,
    disk: str,
    ports: Tuple[int, ...],
    name: Optional[str],
    timeout: Optional[int],
    cwd: Optional[str],
    keep: bool,
    argv: Tuple[str, ...],
) -> int:
    out = output(ctx)
    apply_config_or_exit(out)

    # allow_interspersed_args=False leaves any `--` separator in `argv` rather
    # than letting Click consume it; strip a leading one so the explicit
    # end-of-options form (`box run -- MODULE::FN ARGS`) works. The head token
    # is then the spec and the rest its arguments — the same shape `box exec`
    # uses for its function form.
    tokens = argv[1:] if argv and argv[0] == "--" else argv
    if not tokens:
        out.error(
            "missing function spec — use "
            "`sail box run [FLAGS] MODULE::FN [ARGS...]`.",
            code="invalid_argument",
        )
        return 2
    function_spec, argv = tokens[0], tokens[1:]

    try:
        memory_mib = _parse_memory(memory)
        disk_gib = _parse_disk(disk)
    except ValueError as exc:
        out.error(str(exc), code="invalid_argument")
        return 2
    if timeout is not None and timeout <= 0:
        out.error("timeout must be greater than 0", code="invalid_argument")
        return 2
    if cwd is not None and not cwd.strip():
        out.error("cwd must be non-empty", code="invalid_argument")
        return 2

    # Parse argv and resolve the spec BEFORE creating the sailbox or minting
    # the app — caller errors shouldn't allocate compute or leave an orphaned
    # app behind on every typo. Parse first because resolve_function_spec runs
    # the user's module top-level code.
    try:
        args, kwargs = parse_function_args(argv)
        sail_fn = resolve_function_spec(function_spec)
    except ValueError as exc:
        out.error(str(exc), code="invalid_argument")
        return 2

    image_def: ImageDefinition = _BASE_IMAGES[image]
    found_app = App.find(name=app_name, mint_if_missing=True)
    sailbox_name = name or _generate_name()

    try:
        sb = Sailbox.create(
            image=image_def,
            app=found_app,
            name=sailbox_name,
            cpu=cpu,
            memory_mib=memory_mib,
            disk_gib=disk_gib,
            ingress_ports=list(ports) or None,
        )
    except SailboxCreationError as exc:
        out.error(str(exc) or exc.__class__.__name__, code="creation_error")
        return 1
    except ValueError as exc:
        # SDK-side input validation (size bounds, name shape, etc.).
        out.error(str(exc), code="invalid_argument")
        return 2

    # Persist the exec endpoint so a follow-up `sail box exec sb_xxx` can find
    # it — same lifecycle as `sail box create`. The record is the only way to
    # reach the box from a fresh CLI invocation; `--keep` (or a terminate
    # failure) is meaningless without it. Best-effort: a write failure leaves
    # the server-side sailbox in place, so don't error out — warn instead.
    try:
        save_sailbox_record(
            SailboxRecord(
                sailbox_id=sb.sailbox_id,
                name=sb.name,
                app_id=found_app.id,
                exec_endpoint=sb.exec_endpoint,
                worker_address=sb.worker_address,
            )
        )
    except OSError as exc:
        sys.stderr.write(
            f"sail: warning: created sailbox {sb.sailbox_id} but failed to "
            f"cache its exec endpoint locally ({exc}). `sail box exec` and "
            f"`listeners` will not work for this sailbox until ~/.sail/ is "
            f"writable.\n"
        )

    # Shown on stderr (text mode) whenever the box outlives the run.
    kept_notice = (
        f"sailbox kept: {sb.sailbox_id} (--keep). Use "
        f"`sail box terminate {sb.sailbox_id}` when done.\n"
    )

    exit_code = 0
    result: Any = None
    terminate_failed = False
    # Error emission is deferred until after the `finally` terminate runs:
    # the except handlers below execute *before* it, so terminate-failure
    # state isn't known yet. Handlers record the envelope; it's emitted once
    # the box's fate (alive or gone) is settled.
    error_code = "error"
    error_message = ""
    error_extra: Dict[str, Any] = {}
    try:
        try:
            result = sb.exec(
                sail_fn,
                *args,
                timeout=timeout,
                cwd=cwd,
                kwargs=kwargs,
            )
        except ValueError as exc:
            error_code = "invalid_argument"
            error_message = str(exc)
            exit_code = 2
        except SailboxFunctionSerializationError as exc:
            error_code = "serialization_error"
            error_message = str(exc) or exc.__class__.__name__
            exit_code = 1
        except SailboxFunctionError as exc:
            error_code = "function_error"
            error_message = str(exc)
            exit_code = 1
            error_extra = {
                "error_type": exc.error_type,
                "traceback": exc.traceback,
                "stdout": exc.stdout,
                "stderr": exc.stderr,
            }
            if not out.json_mode and exc.traceback:
                sys.stderr.write(exc.traceback)
                if not exc.traceback.endswith("\n"):
                    sys.stderr.write("\n")
        except SailboxExecutionError as exc:
            error_code = "execution_error"
            error_message = str(exc) or exc.__class__.__name__
            exit_code = 1
    finally:
        if not keep:
            try:
                sb.terminate()
            except Exception:  # noqa: BLE001 -- best-effort cleanup
                # Scheduler reaps on idle timeout; warn so the user knows to
                # check `sail box list` if they want to terminate sooner.
                terminate_failed = True
                sys.stderr.write(
                    f"sail: warning: failed to terminate {sb.sailbox_id} "
                    f"after run. Use `sail box terminate {sb.sailbox_id}` "
                    f"to clean up.\n"
                )
            else:
                # Mirror `sail box terminate`: the box is gone, so the cache
                # record can't point at anything useful. Best-effort —
                # tolerated by `delete_sailbox_record` if the file is missing.
                try:
                    delete_sailbox_record(sb.sailbox_id)
                except OSError:
                    pass

    # The box outlives the run with --keep, but also when terminate failed —
    # in both cases it is still consuming compute. Surface its identity in the
    # error envelope (not just the success payload) so --json automation that
    # reads only stdout can find and clean up the leaked box.
    kept = keep or terminate_failed
    if exit_code != 0:
        err_fields: Dict[str, Any] = dict(error_extra)
        if kept:
            err_fields.update(
                {
                    "sailbox_id": sb.sailbox_id,
                    "name": sb.name,
                    "app": found_app.name,
                    "app_id": found_app.id,
                    "kept": True,
                }
            )
        out.error(error_message, code=error_code, **err_fields)
        if keep and not out.json_mode:
            sys.stderr.write(kept_notice)
        return exit_code

    payload: Dict[str, Any] = {
        "sailbox_id": sb.sailbox_id,
        "name": sb.name,
        "app": found_app.name,
        "app_id": found_app.id,
        "result": result,
        "kept": kept,
    }
    if out.json_mode:
        out.emit(payload)
    else:
        sys.stdout.write(pprint.pformat(result))
        sys.stdout.write("\n")
        if keep:
            sys.stderr.write(kept_notice)
    return 0
