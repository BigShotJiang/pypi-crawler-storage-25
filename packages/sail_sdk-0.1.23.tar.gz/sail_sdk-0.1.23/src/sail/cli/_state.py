"""Local CLI state on disk under ``$SAIL_HOME`` (default ``~/.sail``).

Two files:

  - ``config.toml``: persistent user preferences (mode, default app, api key
    when written via `sail config set`). Environment variables always take
    precedence over this file.
  - ``sailboxes/<id>.json``: a small per-sailbox cache of the
    ``exec_endpoint`` returned at create time. The public HTTP API
    deliberately omits ``exec_endpoint`` from list/get responses (it's
    scheduler-internal infrastructure), so this cache lets follow-up
    commands like ``sail box exec ID -- echo hi`` from a fresh shell
    reach the worker proxy. Replace with a server lookup once the
    backend exposes it.
"""

from __future__ import annotations

import json
import os
import re
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Optional

if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib

CONFIG_KEYS = frozenset(
    {
        "mode",
        "api_key",
        "api_url",
        "imagebuilder_url",
    }
)

MODE_VALUES = ("prod", "dev", "staging", "local")


def home_dir() -> Path:
    override = os.environ.get("SAIL_HOME", "").strip()
    if override:
        return Path(override).expanduser()
    return Path.home() / ".sail"


def _ensure_home_dir(path: Path) -> None:
    """Create the directory tree under ~/.sail with 0o700 perms.

    The api_key file is chmod'd 0o600, but on default macOS/Linux umasks the
    parent directory ends up world-readable, so other local users can list
    config.toml's existence and stat its mtime. Tightening the parent to 0o700
    matches the convention used by ~/.ssh and ~/.aws.

    Only tighten directories the CLI itself created. Users can point
    ``SAIL_HOME`` at a pre-existing path (``/tmp`` in a container, a shared
    mount, etc.); chmod'ing those would strip sticky bits or break unrelated
    processes. Capture which ancestors existed before our mkdir and skip them.
    """
    home = home_dir()
    pre_existing: set[Path] = set()
    cur: Path = path
    while True:
        if cur.exists():
            pre_existing.add(cur)
        if cur == home or cur.parent == cur:
            break
        cur = cur.parent
    path.mkdir(parents=True, exist_ok=True)
    cur = path
    while True:
        if cur not in pre_existing:
            try:
                os.chmod(cur, 0o700)
            except OSError:
                pass
        if cur == home or cur.parent == cur:
            break
        cur = cur.parent


def _atomic_write_text(path: Path, content: str, *, mode: int) -> None:
    """Write `content` to `path` atomically: write to a tmp file, then rename.

    A truncate-then-write would leave the file empty if the process crashed
    mid-write, bricking every subsequent `sail` command on a malformed config.
    Rename on POSIX is atomic, so readers either see the old content or the
    new content — never a half-written file.
    """
    tmp = path.with_suffix(path.suffix + ".tmp")
    # Pin UTF-8: write_text() defaults to the platform locale, but tomllib
    # always reads as UTF-8. Without this, a Unicode value persisted on Windows
    # cp1252 would TOMLDecodeError on the next read.
    tmp.write_text(content, encoding="utf-8")
    try:
        os.chmod(tmp, mode)
    except OSError:
        pass
    try:
        os.replace(tmp, path)
    except OSError:
        # Don't leave a half-written .tmp behind on rename failure — the next
        # save would overwrite it anyway, but a stale .tmp is confusing to
        # anyone poking at the directory by hand.
        try:
            tmp.unlink()
        except OSError:
            pass
        raise


def config_path() -> Path:
    return home_dir() / "config.toml"


def sailboxes_dir() -> Path:
    return home_dir() / "sailboxes"


def load_config_file() -> dict[str, str]:
    """Return the persisted CLI config, or an empty dict if no file exists."""
    path = config_path()
    if not path.exists():
        return {}
    with path.open("rb") as f:
        data = tomllib.load(f)
    # `bool` is a subclass of `int` in Python, so without the explicit
    # exclusion `mode = true` would round-trip as the string `"True"` and
    # silently flow into `SAIL_MODE` — surfacing later as `invalid_mode` from
    # the SDK rather than as the typo it actually is.
    return {
        k: str(v)
        for k, v in data.items()
        if isinstance(v, (str, int, float)) and not isinstance(v, bool)
    }


_TOML_BASIC_ESCAPES = {
    0x08: "\\b",
    0x09: "\\t",
    0x0A: "\\n",
    0x0C: "\\f",
    0x0D: "\\r",
    0x22: '\\"',
    0x5C: "\\\\",
}


def _toml_basic_string_escape(value: str) -> str:
    """Escape `value` for inclusion in a TOML basic string.

    `sail config set` rejects control characters at input time, so
    user-supplied values are already safe. The interesting case is the
    round-trip: a hand-edited config containing valid TOML escape sequences
    (e.g. ``foo = "a\\nb"``) parses through ``tomllib`` as the literal
    string ``"a\nb"``. Rewriting that value via ``\\`` + ``"`` escaping
    alone would emit a raw newline inside the basic string and brick every
    subsequent ``sail`` command on the next read. Escape every control
    code-point (TOML disallows them unescaped) so ``load → save → load`` is
    always a no-op on the parsed value.
    """
    out: list[str] = []
    for ch in value:
        cp = ord(ch)
        if cp in _TOML_BASIC_ESCAPES:
            out.append(_TOML_BASIC_ESCAPES[cp])
        elif cp < 0x20 or cp == 0x7F:
            out.append(f"\\u{cp:04X}")
        else:
            out.append(ch)
    return "".join(out)


def save_config_file(values: dict[str, str]) -> Path:
    path = config_path()
    _ensure_home_dir(path.parent)
    lines = ["# Managed by `sail config`. Env vars override these values.\n"]
    for key in sorted(values):
        lines.append(f'{key} = "{_toml_basic_string_escape(values[key])}"\n')
    _atomic_write_text(path, "".join(lines), mode=0o600)
    return path


def apply_config_to_env(values: dict[str, str]) -> None:
    """Apply persisted config keys as environment defaults.

    Any env value already in ``os.environ`` wins, including the empty string
    — ``SAIL_API_KEY='' sail ...`` is a deliberate "ignore my persisted key"
    signal, not a fallthrough to the file.
    """
    mapping = {
        "mode": "SAIL_MODE",
        "api_key": "SAIL_API_KEY",
        "api_url": "SAIL_API_URL",
        "imagebuilder_url": "SAIL_IMAGEBUILDER_URL",
    }
    for cfg_key, env_key in mapping.items():
        if cfg_key in values and env_key not in os.environ:
            os.environ[env_key] = values[cfg_key]


@dataclass(frozen=True)
class SailboxRecord:
    sailbox_id: str
    name: str
    app_id: str
    exec_endpoint: str
    worker_address: str = ""


# Server-issued IDs match this pattern. Validated at the cache boundary so
# that a value like ``../evil/foo`` (whether from a typo or a hostile caller)
# can't escape ``sailboxes_dir()`` and read/write arbitrary files under
# ``~/.sail`` — `pathlib` doesn't normalize ``..`` segments, so the literal
# `f"{id}.json"` interpolation would otherwise resolve outside the cache dir.
_SAILBOX_ID_RE = re.compile(r"^[A-Za-z0-9_-]+$")


def _is_valid_sailbox_id(sailbox_id: str) -> bool:
    return bool(_SAILBOX_ID_RE.match(sailbox_id))


def save_sailbox_record(record: SailboxRecord) -> Path:
    if not _is_valid_sailbox_id(record.sailbox_id):
        raise ValueError(f"invalid sailbox_id {record.sailbox_id!r}")
    _ensure_home_dir(sailboxes_dir())
    path = sailboxes_dir() / f"{record.sailbox_id}.json"
    _atomic_write_text(
        path,
        json.dumps(asdict(record), indent=2, sort_keys=True),
        mode=0o600,
    )
    return path


def load_sailbox_record(sailbox_id: str) -> Optional[SailboxRecord]:
    if not _is_valid_sailbox_id(sailbox_id):
        return None
    path = sailboxes_dir() / f"{sailbox_id}.json"
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError, UnicodeDecodeError):
        # UnicodeDecodeError: a corrupted cache file with non-UTF8 bytes
        # would otherwise escape to the top-level CLI handler and turn a
        # recoverable cache problem into a hard ``exec``/``url``/``resume``
        # failure (with `resume` doing so *after* the backend already
        # succeeded). Match the JSONDecodeError branch — any unreadable
        # cache shape is just a miss.
        return None
    # Match the JSONDecodeError branch: any unusable cache shape is a miss.
    # Without this, a manually-edited file containing `null` or `[]` would
    # raise AttributeError on .get() and leak as a cryptic top-level error.
    if not isinstance(data, dict):
        return None
    # The cache file is keyed by the caller's sailbox_id (path is the source
    # of truth). Force the field to the requested ID instead of trusting the
    # on-disk value: a manually-edited file with a mismatched ``sailbox_id``
    # would otherwise route ``exec``/``url``/``listeners`` to the wrong sailbox.
    #
    # All other fields must be strings — without this, a hand-edited
    # ``exec_endpoint: 123`` would survive `_hydrate_for_exec`'s
    # ``not record.exec_endpoint`` truthiness check and explode later inside
    # ``open_grpc_channel`` on ``.strip()``. Treat any non-string field as a
    # cache miss, same as a malformed JSON shape.
    fields = ("name", "app_id", "exec_endpoint", "worker_address")
    if any(not isinstance(data.get(f, ""), str) for f in fields):
        return None
    return SailboxRecord(
        sailbox_id=sailbox_id,
        name=data.get("name", ""),
        app_id=data.get("app_id", ""),
        exec_endpoint=data.get("exec_endpoint", ""),
        worker_address=data.get("worker_address", ""),
    )


def delete_sailbox_record(sailbox_id: str) -> None:
    if not _is_valid_sailbox_id(sailbox_id):
        return
    path = sailboxes_dir() / f"{sailbox_id}.json"
    try:
        path.unlink()
    except FileNotFoundError:
        pass
