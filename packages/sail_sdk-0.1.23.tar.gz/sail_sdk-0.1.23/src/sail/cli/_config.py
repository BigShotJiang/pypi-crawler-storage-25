"""`sail config` subcommands — read/write ``~/.sail/config.toml``."""

from __future__ import annotations

from typing import Iterable, Optional, Tuple

import click

from sail.cli._globals import load_config_or_exit, output, with_global_flags
from sail.cli._output import Output
from sail.cli._state import (
    CONFIG_KEYS,
    MODE_VALUES,
    config_path,
    save_config_file,
)


def register(cli: click.Group) -> None:
    cli.add_command(config)


@click.group(
    name="config",
    help=(
        "Read and write ~/.sail/config.toml — persisted CLI defaults so "
        "you don't have to re-export SAIL_* in every new shell.\n\n"
        "Recognized keys: " + ", ".join(sorted(CONFIG_KEYS)) + ".\n\n"
        "Environment variables always take precedence over the file, so "
        "`SAIL_MODE=staging sail ...` overrides `mode` for that one "
        "invocation without touching the file."
    ),
)
@with_global_flags
def config(ctx: click.Context) -> None:
    pass


@config.command(
    name="get",
    help=(
        "Print the persisted config file (or one key). "
        "Without arguments: print the full file. With a KEY argument: "
        "print just that value (exits 1 if not set)."
    ),
)
@click.argument("key", required=False)
@with_global_flags
def _get(ctx: click.Context, key: Optional[str]) -> int:
    out = output(ctx)
    values = load_config_or_exit(out)
    if key:
        if key not in values:
            out.error(f"key {key!r} not set", code="not_found")
            return 1
        out.emit({key: values[key]}, text=values[key])
        return 0
    if not values:
        out.emit({"config_file": str(config_path()), "values": {}}, text="(empty)")
        return 0
    out.emit(
        {"config_file": str(config_path()), "values": values},
        text="\n".join(f"{k} = {v}" for k, v in sorted(values.items())),
    )
    return 0


@config.command(
    name="set",
    help=(
        "Set one or more key=value entries in the config file. Examples:\n"
        "  sail config set api_key=sk_...\n"
        "  sail config set mode=staging"
    ),
)
@click.argument("entries", nargs=-1, required=True, metavar="KEY=VALUE...")
@with_global_flags
def _set(ctx: click.Context, entries: Tuple[str, ...]) -> int:
    out = output(ctx)
    try:
        updates = _collect_kvs(entries)
    except ValueError as exc:
        out.error(str(exc), code="invalid_argument")
        return 2

    unknown = sorted(set(updates) - CONFIG_KEYS)
    if unknown:
        out.error(
            f"unknown config keys: {', '.join(unknown)}. "
            f"valid keys: {', '.join(sorted(CONFIG_KEYS))}",
            code="invalid_argument",
        )
        return 2

    # Validate constrained values up-front so a typo (e.g. `mode=prdo`) is
    # rejected at write time. Otherwise the bad value is persisted and every
    # subsequent SDK-backed command fails when Config.from_env() rejects the
    # unknown SAIL_MODE — turning a single typo into a stuck CLI state that
    # only `sail config unset mode` (or `reset`) can recover from.
    if "mode" in updates and updates["mode"] not in MODE_VALUES:
        out.error(
            f"invalid mode {updates['mode']!r}. "
            f"valid values: {', '.join(MODE_VALUES)}",
            code="invalid_argument",
        )
        return 2

    values = load_config_or_exit(out)
    values.update(updates)
    path = save_config_file(values)
    out.emit(
        {"config_file": str(path), "values": values, "updated": sorted(updates)},
        text=f"Saved {_n(len(updates), 'entry', 'entries')} to {path}",
    )
    return 0


@config.command(
    name="unset",
    help="remove one or more keys from the config file.",
)
@click.argument("keys", nargs=-1, required=True, metavar="KEY...")
@with_global_flags
def _unset(ctx: click.Context, keys: Tuple[str, ...]) -> int:
    out = output(ctx)
    values = load_config_or_exit(out)
    removed = []
    for key in keys:
        if values.pop(key, None) is not None:
            removed.append(key)
    # Only re-write the file if something actually changed. Without this, a
    # no-op `sail config unset KEY` against a missing file would still create
    # ``~/.sail/config.toml`` (and would fail outright in a read-only
    # ``SAIL_HOME``) — surprising for an unset that should be free to succeed
    # without touching disk.
    if removed:
        save_config_file(values)
    out.emit(
        {"removed": removed, "config_file": str(config_path())},
        text=f"Removed {_n(len(removed), 'entry', 'entries')}.",
    )
    return 0


@config.command(
    name="reset",
    help=(
        "Delete ~/.sail/config.toml entirely. Useful as a recovery path "
        "when the file is malformed and other config commands fail to "
        "parse it."
    ),
)
@with_global_flags
def _reset(ctx: click.Context) -> int:
    out = output(ctx)
    # Skip parsing the file: this is the recovery path when it's malformed and
    # every other config command fails on load.
    path = config_path()
    if not path.exists():
        out.emit(
            {"removed": False, "config_file": str(path)},
            text=f"{path} did not exist.",
        )
        return 0
    path.unlink()
    out.emit(
        {"removed": True, "config_file": str(path)},
        text=f"Removed {path}",
    )
    return 0


def _n(count: int, singular: str, plural: str) -> str:
    return f"{count} {singular if count == 1 else plural}"


def _collect_kvs(items: Iterable[str]) -> dict[str, str]:
    out: dict[str, str] = {}
    for item in items:
        key, sep, value = item.partition("=")
        if not sep:
            raise ValueError(f"expected key=value, got {item!r}")
        key = key.strip()
        # No legal sail config value contains control characters. Reject them
        # here so a shell-expanded oddity like `api_key=$'sk_test\n'` doesn't
        # write a raw newline into config.toml — TOML basic strings forbid
        # unescaped controls, and we'd brick every subsequent CLI run.
        if any(ord(c) < 32 or ord(c) == 127 for c in value):
            raise ValueError(
                f"value for {key!r} contains control characters; "
                f"only printable characters are supported"
            )
        # Strip then reject empty: `sail config set api_key=` looks like an
        # assignment but `save_config_file` skips empty entries, so the key
        # would silently *vanish* (clearing any existing value) under the
        # banner "Saved 1 entry". That's the worst kind of UX — accept-and-
        # discard. Send users to `sail config unset` for actual removal.
        value = value.strip()
        if not value:
            raise ValueError(
                f"empty value for {key!r}; "
                f"use `sail config unset {key}` to remove a key"
            )
        out[key] = value
    return out
