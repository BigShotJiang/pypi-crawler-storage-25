"""Click options and helpers shared across every command.

``--json`` and ``--mode`` are valid at every level — root, subgroup, and leaf —
so users can write ``sail --json box show ID`` or
``sail box show ID --json`` interchangeably (matching gh / docker /
kubectl). The ``@with_global_flags`` decorator attaches both options and the
``ctx.obj`` merge in one shot; apply it to every ``@click.group`` and
``@<group>.command``, and the nearest level's flags win.
"""

from __future__ import annotations

import functools
import os
from typing import Callable, Optional, TypeVar

import click

from sail.cli._output import Output
from sail.cli._state import (
    MODE_VALUES,
    apply_config_to_env,
    config_path,
    load_config_file,
)

F = TypeVar("F", bound=Callable[..., object])

_JSON_FLAG = click.option(
    "--json",
    "json_mode",
    is_flag=True,
    default=None,
    help="emit JSON output instead of human-readable text.",
)
_MODE_OPT = click.option(
    "--mode",
    type=click.Choice(MODE_VALUES, case_sensitive=False),
    default=None,
    help="override SAIL_MODE for this invocation.",
)


def with_global_flags(f: F) -> F:
    """Add ``--json`` / ``--mode`` to a Click command and merge them on entry.

    The wrapped callback receives ``ctx`` and its own arguments; ``--json``
    and ``--mode`` are folded into ``ctx.obj`` (and ``SAIL_MODE`` exported)
    before the callback runs, so leaves can call ``output(ctx)`` directly
    without restating the boilerplate. Apply as the innermost Click
    decorator on every group / leaf — outside ``@click.argument`` /
    ``@click.option`` declarations the callback owns, inside
    ``@click.group`` / ``@<group>.command``.
    """

    @functools.wraps(f)
    def wrapper(
        ctx: click.Context,
        json_mode: Optional[bool],
        mode: Optional[str],
        **kwargs: object,
    ) -> object:
        if ctx.obj is None:
            ctx.obj = {}
        if json_mode:
            ctx.obj["json_mode"] = True
        if mode:
            ctx.obj["mode"] = mode
            os.environ["SAIL_MODE"] = mode
        return f(ctx, **kwargs)

    return _JSON_FLAG(_MODE_OPT(click.pass_context(wrapper)))  # type: ignore[return-value]


def output(ctx: click.Context) -> Output:
    """Build an Output bound to the resolved json mode for this context."""
    obj = ctx.obj or {}
    return Output(json_mode=bool(obj.get("json_mode")))


def load_config_or_exit(out: Output) -> dict[str, str]:
    """Load ``~/.sail/config.toml``, or emit a structured error and exit 2.

    Raising ``click.exceptions.Exit`` lets ``main()`` translate the abort to
    its exit code without leaking a TOML parse traceback through the generic
    exception handler — ``sail config get/set/unset`` and ``sail auth logout``
    all need exactly this shape, which is why it lives here rather than
    duplicated per-command.
    """
    try:
        return load_config_file()
    except Exception as exc:  # noqa: BLE001 -- file shape is user-controlled
        out.error(
            f"could not parse {config_path()} ({exc.__class__.__name__}: {exc}). "
            f"Edit the file to fix it, or run `sail config reset` to delete it.",
            code="invalid_state",
        )
        raise click.exceptions.Exit(2) from None


def apply_config_or_exit(out: Output) -> None:
    """Fold ``~/.sail/config.toml`` into the environment, or exit 2.

    Operational commands (``sail box`` / ``sail app``) call this before
    constructing an SDK client, so a persisted ``api_key`` / ``api_url`` /
    ``mode`` becomes an env default. A malformed file is surfaced with the
    same structured error and ``sail config reset`` hint as
    ``load_config_or_exit``.
    """
    apply_config_to_env(load_config_or_exit(out))


def apply_config_best_effort() -> None:
    """Fold persisted config into the environment, tolerating a bad file.

    ``sail auth whoami`` is a diagnostic — it must still report env-derived
    state when ``~/.sail/config.toml`` is malformed, so a parse failure is
    swallowed here rather than surfaced the way operational commands do.
    """
    try:
        apply_config_to_env(load_config_file())
    except Exception:  # noqa: BLE001 -- file shape is user-controlled
        pass
