"""Generated protocol buffer code."""

from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder

_runtime_version.ValidateProtobufRuntimeVersion(
    _runtime_version.Domain.PUBLIC, 6, 31, 1, "", "imagebuilder/v1/imagebuilder.proto"
)
_sym_db = _symbol_database.Default()
from ...image.v1 import image_pb2 as image_dot_v1_dot_image__pb2

DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(
    b'\n"imagebuilder/v1/imagebuilder.proto\x12\x0fimagebuilder.v1\x1a\x14image/v1/image.proto"7\n\x11BuildImageRequest\x12"\n\x05image\x18\x01 \x01(\x0b2\x13.image.v1.ImageSpec"i\n\x12BuildImageResponse\x12\x10\n\x08image_id\x18\x01 \x01(\t\x12*\n\x06status\x18\x02 \x01(\x0e2\x1a.image.v1.ImageBuildStatus\x12\x15\n\rerror_message\x18\x03 \x01(\t".\n\x1aGetImageBuildStatusRequest\x12\x10\n\x08image_id\x18\x01 \x01(\t"r\n\x1bGetImageBuildStatusResponse\x12\x10\n\x08image_id\x18\x01 \x01(\t\x12*\n\x06status\x18\x02 \x01(\x0e2\x1a.image.v1.ImageBuildStatus\x12\x15\n\rerror_message\x18\x03 \x01(\t"O\n\x1dPrepareLocalFileUploadRequest\x12\x16\n\x0econtent_sha256\x18\x01 \x01(\t\x12\x16\n\x0econtent_length\x18\x02 \x01(\x04"\xac\x01\n\x1ePrepareLocalFileUploadResponse\x12A\n\x0ealready_exists\x18\x01 \x01(\x0b2\'.imagebuilder.v1.LocalFileAlreadyExistsH\x00\x12<\n\x0bsingle_part\x18\x02 \x01(\x0b2%.imagebuilder.v1.SinglePartUploadPlanH\x00B\t\n\x07outcome"\x18\n\x16LocalFileAlreadyExists"\xd1\x01\n\x14SinglePartUploadPlan\x12\x12\n\nupload_url\x18\x01 \x01(\t\x12T\n\x10required_headers\x18\x02 \x03(\x0b2:.imagebuilder.v1.SinglePartUploadPlan.RequiredHeadersEntry\x12\x17\n\x0fexpires_at_unix\x18\x03 \x01(\x03\x1a6\n\x14RequiredHeadersEntry\x12\x0b\n\x03key\x18\x01 \x01(\t\x12\r\n\x05value\x18\x02 \x01(\t:\x028\x012\xd9\x02\n\x13ImageBuilderService\x12U\n\nBuildImage\x12".imagebuilder.v1.BuildImageRequest\x1a#.imagebuilder.v1.BuildImageResponse\x12p\n\x13GetImageBuildStatus\x12+.imagebuilder.v1.GetImageBuildStatusRequest\x1a,.imagebuilder.v1.GetImageBuildStatusResponse\x12y\n\x16PrepareLocalFileUpload\x12..imagebuilder.v1.PrepareLocalFileUploadRequest\x1a/.imagebuilder.v1.PrepareLocalFileUploadResponseBLZJgithub.com/sailresearchco/sail/backend/internal/sailbox/imagebuilder/pb;pbb\x06proto3'
)
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(
    DESCRIPTOR, "imagebuilder.v1.imagebuilder_pb2", _globals
)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals["DESCRIPTOR"]._loaded_options = None
    _globals["DESCRIPTOR"]._serialized_options = (
        b"ZJgithub.com/sailresearchco/sail/backend/internal/sailbox/imagebuilder/pb;pb"
    )
    _globals["_SINGLEPARTUPLOADPLAN_REQUIREDHEADERSENTRY"]._loaded_options = None
    _globals["_SINGLEPARTUPLOADPLAN_REQUIREDHEADERSENTRY"]._serialized_options = (
        b"8\x01"
    )
    _globals["_BUILDIMAGEREQUEST"]._serialized_start = 77
    _globals["_BUILDIMAGEREQUEST"]._serialized_end = 132
    _globals["_BUILDIMAGERESPONSE"]._serialized_start = 134
    _globals["_BUILDIMAGERESPONSE"]._serialized_end = 239
    _globals["_GETIMAGEBUILDSTATUSREQUEST"]._serialized_start = 241
    _globals["_GETIMAGEBUILDSTATUSREQUEST"]._serialized_end = 287
    _globals["_GETIMAGEBUILDSTATUSRESPONSE"]._serialized_start = 289
    _globals["_GETIMAGEBUILDSTATUSRESPONSE"]._serialized_end = 403
    _globals["_PREPARELOCALFILEUPLOADREQUEST"]._serialized_start = 405
    _globals["_PREPARELOCALFILEUPLOADREQUEST"]._serialized_end = 484
    _globals["_PREPARELOCALFILEUPLOADRESPONSE"]._serialized_start = 487
    _globals["_PREPARELOCALFILEUPLOADRESPONSE"]._serialized_end = 659
    _globals["_LOCALFILEALREADYEXISTS"]._serialized_start = 661
    _globals["_LOCALFILEALREADYEXISTS"]._serialized_end = 685
    _globals["_SINGLEPARTUPLOADPLAN"]._serialized_start = 688
    _globals["_SINGLEPARTUPLOADPLAN"]._serialized_end = 897
    _globals["_SINGLEPARTUPLOADPLAN_REQUIREDHEADERSENTRY"]._serialized_start = 843
    _globals["_SINGLEPARTUPLOADPLAN_REQUIREDHEADERSENTRY"]._serialized_end = 897
    _globals["_IMAGEBUILDERSERVICE"]._serialized_start = 900
    _globals["_IMAGEBUILDERSERVICE"]._serialized_end = 1245
