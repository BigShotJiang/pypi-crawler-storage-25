"""Generated protocol buffer code."""

from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder

_runtime_version.ValidateProtobufRuntimeVersion(
    _runtime_version.Domain.PUBLIC, 6, 31, 1, "", "scheduler/v1/scheduler.proto"
)
_sym_db = _symbol_database.Default()
from ...image.v1 import image_pb2 as image_dot_v1_dot_image__pb2

DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(
    b'\n\x1cscheduler/v1/scheduler.proto\x12\x0cscheduler.v1\x1a\x14image/v1/image.proto"\xc6\x01\n\x14CreateSailboxRequest\x12\x0c\n\x04name\x18\x01 \x01(\t\x12\x0b\n\x03cpu\x18\x02 \x01(\r\x12\x12\n\nmemory_mib\x18\x03 \x01(\r\x12\x17\n\x0ftimeout_seconds\x18\x04 \x01(\r\x12\x0e\n\x06app_id\x18\x05 \x01(\t\x12"\n\x05image\x18\x06 \x01(\x0b2\x13.image.v1.ImageSpec\x12\x15\n\ringress_ports\x18\x07 \x03(\r\x12\x1b\n\x13state_disk_size_gib\x18\x08 \x01(\r"\xb3\x01\n\x15CreateSailboxResponse\x12\x12\n\nsailbox_id\x18\x01 \x01(\t\x12+\n\x06status\x18\x02 \x01(\x0e2\x1b.scheduler.v1.SailboxStatus\x12\x16\n\x0eworker_address\x18\x03 \x01(\t\x12\r\n\x05vm_id\x18\x04 \x01(\t\x12\x15\n\rerror_message\x18\x05 \x01(\t\x12\x1b\n\x13exec_proxy_endpoint\x18\x06 \x01(\t"-\n\x17GetSailboxStatusRequest\x12\x12\n\nsailbox_id\x18\x01 \x01(\t"\xb2\x01\n\x18GetSailboxStatusResponse\x12\x12\n\nsailbox_id\x18\x01 \x01(\t\x12+\n\x06status\x18\x02 \x01(\x0e2\x1b.scheduler.v1.SailboxStatus\x12\x16\n\x0eworker_address\x18\x03 \x01(\t\x12\r\n\x05vm_id\x18\x04 \x01(\t\x12\x15\n\rerror_message\x18\x05 \x01(\t\x12\x17\n\x0fcreated_at_unix\x18\x06 \x01(\x03"-\n\x17TerminateSailboxRequest\x12\x12\n\nsailbox_id\x18\x01 \x01(\t"G\n\x18TerminateSailboxResponse\x12+\n\x06status\x18\x01 \x01(\x0e2\x1b.scheduler.v1.SailboxStatus"A\n\x12StopSailboxRequest\x12\x12\n\nsailbox_id\x18\x01 \x01(\t\x12\x17\n\x0fwake_on_traffic\x18\x02 \x01(\x08"B\n\x13StopSailboxResponse\x12+\n\x06status\x18\x01 \x01(\x0e2\x1b.scheduler.v1.SailboxStatus".\n\x18CheckpointSailboxRequest\x12\x12\n\nsailbox_id\x18\x01 \x01(\t"g\n\x19CheckpointSailboxResponse\x12+\n\x06status\x18\x01 \x01(\x0e2\x1b.scheduler.v1.SailboxStatus\x12\x1d\n\x15checkpoint_generation\x18\x02 \x01(\x03"*\n\x14ResumeSailboxRequest\x12\x12\n\nsailbox_id\x18\x01 \x01(\t"\xf8\x01\n\x15ResumeSailboxResponse\x126\n\x0cresume_state\x18\x01 \x01(\x0e2 .scheduler.v1.SailboxResumeState\x12+\n\x06status\x18\x02 \x01(\x0e2\x1b.scheduler.v1.SailboxStatus\x12\x16\n\x0eworker_address\x18\x03 \x01(\t\x12\x1f\n\x17worker_internal_address\x18\x04 \x01(\t\x12\r\n\x05vm_id\x18\x05 \x01(\t\x12\x15\n\rerror_message\x18\x06 \x01(\t\x12\x1b\n\x13exec_proxy_endpoint\x18\x07 \x01(\t"\xec\x01\n\x15RegisterWorkerRequest\x12\x11\n\tworker_id\x18\x01 \x01(\t\x12\x1f\n\x17worker_internal_address\x18\x02 \x01(\t\x12\x16\n\x0eworker_address\x18\x03 \x01(\t\x12\x13\n\x0btotal_vcpus\x18\x04 \x01(\r\x12\x18\n\x10total_memory_mib\x18\x05 \x01(\r\x121\n\x0carchitecture\x18\x06 \x01(\x0e2\x1b.image.v1.ImageArchitecture\x12\x15\n\rinstance_type\x18\x07 \x01(\t\x12\x0e\n\x06region\x18\x08 \x01(\t"+\n\x16RegisterWorkerResponse\x12\x11\n\tworker_id\x18\x01 \x01(\t"+\n\x16HeartbeatWorkerRequest\x12\x11\n\tworker_id\x18\x01 \x01(\t"\x19\n\x17HeartbeatWorkerResponse",\n\x17DeregisterWorkerRequest\x12\x11\n\tworker_id\x18\x01 \x01(\t"\x1a\n\x18DeregisterWorkerResponse"\xce\x01\n\x1dReportWorkerPreemptionRequest\x12\x11\n\tworker_id\x18\x01 \x01(\t\x124\n\x06signal\x18\x02 \x01(\x0e2$.scheduler.v1.WorkerPreemptionSignal\x12\x0e\n\x06action\x18\x03 \x01(\t\x12\x18\n\x10notice_time_unix\x18\x04 \x01(\x03\x12\x13\n\x0binstance_id\x18\x05 \x01(\t\x12\x15\n\rinstance_type\x18\x06 \x01(\t\x12\x0e\n\x06region\x18\x07 \x01(\t"=\n\x1eReportWorkerPreemptionResponse\x12\x1b\n\x13sailboxes_scheduled\x18\x01 \x01(\r"\x13\n\x11GetVMStatsRequest"=\n\x12GetVMStatsResponse\x12\'\n\x08vm_stats\x18\x01 \x03(\x0b2\x15.scheduler.v1.VMStats"\xa0\x03\n\x07VMStats\x12\x12\n\nsailbox_id\x18\x01 \x01(\t\x12\r\n\x05vm_id\x18\x02 \x01(\t\x12\x16\n\x0eworker_address\x18\x03 \x01(\t\x12\x13\n\x0bcpu_time_ns\x18\x04 \x01(\x04\x12\x19\n\x11memory_used_bytes\x18\x05 \x01(\x04\x12\x1a\n\x12memory_total_bytes\x18\x06 \x01(\x04\x12\x17\n\x0frequested_vcpus\x18\x07 \x01(\r\x12\x1e\n\x16requested_memory_bytes\x18\x08 \x01(\x04\x12\x14\n\x0ctimestamp_ns\x18\t \x01(\x03\x12\x1d\n\x15state_disk_used_bytes\x18\n \x01(\x04\x12"\n\x1arequested_state_disk_bytes\x18\x0b \x01(\x04\x12(\n state_disk_filesystem_used_bytes\x18\x0c \x01(\x04\x12)\n!state_disk_filesystem_total_bytes\x18\r \x01(\x04\x12\'\n\x1fstate_disk_filesystem_available\x18\x0e \x01(\x08*\x8d\x03\n\rSailboxStatus\x12\x1e\n\x1aSAILBOX_STATUS_UNSPECIFIED\x10\x00\x12\x1a\n\x16SAILBOX_STATUS_PENDING\x10\x01\x12\x1b\n\x17SAILBOX_STATUS_STARTING\x10\x02\x12\x1a\n\x16SAILBOX_STATUS_RUNNING\x10\x03\x12\x1b\n\x17SAILBOX_STATUS_STOPPING\x10\x04\x12\x1a\n\x16SAILBOX_STATUS_STOPPED\x10\x05\x12\x19\n\x15SAILBOX_STATUS_FAILED\x10\x06\x12)\n%SAILBOX_STATUS_INTERRUPTED_RESTORABLE\x10\x07\x12\x1c\n\x18SAILBOX_STATUS_RESTORING\x10\x08\x12.\n*SAILBOX_STATUS_INTERRUPTED_UNSAFE_TO_RETRY\x10\t\x12\x1d\n\x19SAILBOX_STATUS_TERMINATED\x10\n\x12\x1b\n\x17SAILBOX_STATUS_SLEEPING\x10\x0b*\x81\x02\n\x12SailboxResumeState\x12$\n SAILBOX_RESUME_STATE_UNSPECIFIED\x10\x00\x12(\n$SAILBOX_RESUME_STATE_ALREADY_RUNNING\x10\x01\x12\'\n#SAILBOX_RESUME_STATE_RESUME_STARTED\x10\x02\x12!\n\x1dSAILBOX_RESUME_STATE_RESUMING\x10\x03\x12 \n\x1cSAILBOX_RESUME_STATE_RUNNING\x10\x04\x12-\n)SAILBOX_RESUME_STATE_TERMINAL_UNAVAILABLE\x10\x05*\xa9\x01\n\x16WorkerPreemptionSignal\x12(\n$WORKER_PREEMPTION_SIGNAL_UNSPECIFIED\x10\x00\x12.\n*WORKER_PREEMPTION_SIGNAL_SPOT_INTERRUPTION\x10\x01\x125\n1WORKER_PREEMPTION_SIGNAL_REBALANCE_RECOMMENDATION\x10\x022\xac\x08\n\x10SchedulerService\x12O\n\nGetVMStats\x12\x1f.scheduler.v1.GetVMStatsRequest\x1a .scheduler.v1.GetVMStatsResponse\x12X\n\rCreateSailbox\x12".scheduler.v1.CreateSailboxRequest\x1a#.scheduler.v1.CreateSailboxResponse\x12a\n\x10GetSailboxStatus\x12%.scheduler.v1.GetSailboxStatusRequest\x1a&.scheduler.v1.GetSailboxStatusResponse\x12a\n\x10TerminateSailbox\x12%.scheduler.v1.TerminateSailboxRequest\x1a&.scheduler.v1.TerminateSailboxResponse\x12R\n\x0bStopSailbox\x12 .scheduler.v1.StopSailboxRequest\x1a!.scheduler.v1.StopSailboxResponse\x12d\n\x11CheckpointSailbox\x12&.scheduler.v1.CheckpointSailboxRequest\x1a\'.scheduler.v1.CheckpointSailboxResponse\x12X\n\rResumeSailbox\x12".scheduler.v1.ResumeSailboxRequest\x1a#.scheduler.v1.ResumeSailboxResponse\x12[\n\x0eRegisterWorker\x12#.scheduler.v1.RegisterWorkerRequest\x1a$.scheduler.v1.RegisterWorkerResponse\x12^\n\x0fHeartbeatWorker\x12$.scheduler.v1.HeartbeatWorkerRequest\x1a%.scheduler.v1.HeartbeatWorkerResponse\x12a\n\x10DeregisterWorker\x12%.scheduler.v1.DeregisterWorkerRequest\x1a&.scheduler.v1.DeregisterWorkerResponse\x12s\n\x16ReportWorkerPreemption\x12+.scheduler.v1.ReportWorkerPreemptionRequest\x1a,.scheduler.v1.ReportWorkerPreemptionResponseBIZGgithub.com/sailresearchco/sail/backend/internal/sailbox/scheduler/pb;pbb\x06proto3'
)
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(
    DESCRIPTOR, "scheduler.v1.scheduler_pb2", _globals
)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals["DESCRIPTOR"]._loaded_options = None
    _globals["DESCRIPTOR"]._serialized_options = (
        b"ZGgithub.com/sailresearchco/sail/backend/internal/sailbox/scheduler/pb;pb"
    )
    _globals["_SAILBOXSTATUS"]._serialized_start = 2588
    _globals["_SAILBOXSTATUS"]._serialized_end = 2985
    _globals["_SAILBOXRESUMESTATE"]._serialized_start = 2988
    _globals["_SAILBOXRESUMESTATE"]._serialized_end = 3245
    _globals["_WORKERPREEMPTIONSIGNAL"]._serialized_start = 3248
    _globals["_WORKERPREEMPTIONSIGNAL"]._serialized_end = 3417
    _globals["_CREATESAILBOXREQUEST"]._serialized_start = 69
    _globals["_CREATESAILBOXREQUEST"]._serialized_end = 267
    _globals["_CREATESAILBOXRESPONSE"]._serialized_start = 270
    _globals["_CREATESAILBOXRESPONSE"]._serialized_end = 449
    _globals["_GETSAILBOXSTATUSREQUEST"]._serialized_start = 451
    _globals["_GETSAILBOXSTATUSREQUEST"]._serialized_end = 496
    _globals["_GETSAILBOXSTATUSRESPONSE"]._serialized_start = 499
    _globals["_GETSAILBOXSTATUSRESPONSE"]._serialized_end = 677
    _globals["_TERMINATESAILBOXREQUEST"]._serialized_start = 679
    _globals["_TERMINATESAILBOXREQUEST"]._serialized_end = 724
    _globals["_TERMINATESAILBOXRESPONSE"]._serialized_start = 726
    _globals["_TERMINATESAILBOXRESPONSE"]._serialized_end = 797
    _globals["_STOPSAILBOXREQUEST"]._serialized_start = 799
    _globals["_STOPSAILBOXREQUEST"]._serialized_end = 864
    _globals["_STOPSAILBOXRESPONSE"]._serialized_start = 866
    _globals["_STOPSAILBOXRESPONSE"]._serialized_end = 932
    _globals["_CHECKPOINTSAILBOXREQUEST"]._serialized_start = 934
    _globals["_CHECKPOINTSAILBOXREQUEST"]._serialized_end = 980
    _globals["_CHECKPOINTSAILBOXRESPONSE"]._serialized_start = 982
    _globals["_CHECKPOINTSAILBOXRESPONSE"]._serialized_end = 1085
    _globals["_RESUMESAILBOXREQUEST"]._serialized_start = 1087
    _globals["_RESUMESAILBOXREQUEST"]._serialized_end = 1129
    _globals["_RESUMESAILBOXRESPONSE"]._serialized_start = 1132
    _globals["_RESUMESAILBOXRESPONSE"]._serialized_end = 1380
    _globals["_REGISTERWORKERREQUEST"]._serialized_start = 1383
    _globals["_REGISTERWORKERREQUEST"]._serialized_end = 1619
    _globals["_REGISTERWORKERRESPONSE"]._serialized_start = 1621
    _globals["_REGISTERWORKERRESPONSE"]._serialized_end = 1664
    _globals["_HEARTBEATWORKERREQUEST"]._serialized_start = 1666
    _globals["_HEARTBEATWORKERREQUEST"]._serialized_end = 1709
    _globals["_HEARTBEATWORKERRESPONSE"]._serialized_start = 1711
    _globals["_HEARTBEATWORKERRESPONSE"]._serialized_end = 1736
    _globals["_DEREGISTERWORKERREQUEST"]._serialized_start = 1738
    _globals["_DEREGISTERWORKERREQUEST"]._serialized_end = 1782
    _globals["_DEREGISTERWORKERRESPONSE"]._serialized_start = 1784
    _globals["_DEREGISTERWORKERRESPONSE"]._serialized_end = 1810
    _globals["_REPORTWORKERPREEMPTIONREQUEST"]._serialized_start = 1813
    _globals["_REPORTWORKERPREEMPTIONREQUEST"]._serialized_end = 2019
    _globals["_REPORTWORKERPREEMPTIONRESPONSE"]._serialized_start = 2021
    _globals["_REPORTWORKERPREEMPTIONRESPONSE"]._serialized_end = 2082
    _globals["_GETVMSTATSREQUEST"]._serialized_start = 2084
    _globals["_GETVMSTATSREQUEST"]._serialized_end = 2103
    _globals["_GETVMSTATSRESPONSE"]._serialized_start = 2105
    _globals["_GETVMSTATSRESPONSE"]._serialized_end = 2166
    _globals["_VMSTATS"]._serialized_start = 2169
    _globals["_VMSTATS"]._serialized_end = 2585
    _globals["_SCHEDULERSERVICE"]._serialized_start = 3420
    _globals["_SCHEDULERSERVICE"]._serialized_end = 4488
