"""Generated protocol buffer code."""

from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder

_runtime_version.ValidateProtobufRuntimeVersion(
    _runtime_version.Domain.PUBLIC, 6, 31, 1, "", "image/v1/image.proto"
)
_sym_db = _symbol_database.Default()
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(
    b'\n\x14image/v1/image.proto\x12\x08image.v1"\x8b\x02\n\tImageSpec\x12#\n\x04base\x18\x01 \x01(\x0e2\x13.image.v1.BaseImageH\x00\x12-\n\x0bbuild_steps\x18\x02 \x03(\x0b2\x18.image.v1.ImageBuildStep\x12)\n\x03env\x18\x03 \x03(\x0b2\x1c.image.v1.ImageSpec.EnvEntry\x121\n\x0carchitecture\x18\x04 \x01(\x0e2\x1b.image.v1.ImageArchitecture\x12\x16\n\x0epython_version\x18\x05 \x01(\t\x1a*\n\x08EnvEntry\x12\x0b\n\x03key\x18\x01 \x01(\t\x12\r\n\x05value\x18\x02 \x01(\t:\x028\x01B\x08\n\x06source"\x89\x02\n\x0eImageBuildStep\x12/\n\x0bapt_install\x18\x01 \x01(\x0b2\x18.image.v1.PackageInstallH\x00\x12/\n\x0bpip_install\x18\x02 \x01(\x0b2\x18.image.v1.PackageInstallH\x00\x12+\n\x0brun_command\x18\x03 \x01(\x0b2\x14.image.v1.RunCommandH\x00\x120\n\x0eadd_local_file\x18\x04 \x01(\x0b2\x16.image.v1.AddLocalFileH\x00\x12.\n\radd_local_dir\x18\x05 \x01(\x0b2\x15.image.v1.AddLocalDirH\x00B\x06\n\x04step""\n\x0ePackageInstall\x12\x10\n\x08packages\x18\x01 \x03(\t"\x1d\n\nRunCommand\x12\x0f\n\x07command\x18\x01 \x01(\t"I\n\x0cAddLocalFile\x12\x16\n\x0econtent_sha256\x18\x01 \x01(\t\x12\x13\n\x0bremote_path\x18\x02 \x01(\t\x12\x0c\n\x04mode\x18\x03 \x01(\r"L\n\x0bAddLocalDir\x12\x13\n\x0bremote_path\x18\x01 \x01(\t\x12(\n\x05files\x18\x02 \x03(\x0b2\x19.image.v1.AddLocalDirFile"N\n\x0fAddLocalDirFile\x12\x15\n\rrelative_path\x18\x01 \x01(\t\x12\x16\n\x0econtent_sha256\x18\x02 \x01(\t\x12\x0c\n\x04mode\x18\x03 \x01(\r*s\n\x11ImageArchitecture\x12"\n\x1eIMAGE_ARCHITECTURE_UNSPECIFIED\x10\x00\x12\x1c\n\x18IMAGE_ARCHITECTURE_AMD64\x10\x01\x12\x1c\n\x18IMAGE_ARCHITECTURE_ARM64\x10\x02*>\n\tBaseImage\x12\x1a\n\x16BASE_IMAGE_UNSPECIFIED\x10\x00\x12\x15\n\x11BASE_IMAGE_DEBIAN\x10\x01*\xb3\x01\n\x10ImageBuildStatus\x12"\n\x1eIMAGE_BUILD_STATUS_UNSPECIFIED\x10\x00\x12\x1d\n\x19IMAGE_BUILD_STATUS_QUEUED\x10\x01\x12\x1f\n\x1bIMAGE_BUILD_STATUS_BUILDING\x10\x02\x12\x1c\n\x18IMAGE_BUILD_STATUS_READY\x10\x03\x12\x1d\n\x19IMAGE_BUILD_STATUS_FAILED\x10\x04BEZCgithub.com/sailresearchco/sail/backend/internal/sailbox/image/pb;pbb\x06proto3'
)
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, "image.v1.image_pb2", _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals["DESCRIPTOR"]._loaded_options = None
    _globals["DESCRIPTOR"]._serialized_options = (
        b"ZCgithub.com/sailresearchco/sail/backend/internal/sailbox/image/pb;pb"
    )
    _globals["_IMAGESPEC_ENVENTRY"]._loaded_options = None
    _globals["_IMAGESPEC_ENVENTRY"]._serialized_options = b"8\x01"
    _globals["_IMAGEARCHITECTURE"]._serialized_start = 872
    _globals["_IMAGEARCHITECTURE"]._serialized_end = 987
    _globals["_BASEIMAGE"]._serialized_start = 989
    _globals["_BASEIMAGE"]._serialized_end = 1051
    _globals["_IMAGEBUILDSTATUS"]._serialized_start = 1054
    _globals["_IMAGEBUILDSTATUS"]._serialized_end = 1233
    _globals["_IMAGESPEC"]._serialized_start = 35
    _globals["_IMAGESPEC"]._serialized_end = 302
    _globals["_IMAGESPEC_ENVENTRY"]._serialized_start = 250
    _globals["_IMAGESPEC_ENVENTRY"]._serialized_end = 292
    _globals["_IMAGEBUILDSTEP"]._serialized_start = 305
    _globals["_IMAGEBUILDSTEP"]._serialized_end = 570
    _globals["_PACKAGEINSTALL"]._serialized_start = 572
    _globals["_PACKAGEINSTALL"]._serialized_end = 606
    _globals["_RUNCOMMAND"]._serialized_start = 608
    _globals["_RUNCOMMAND"]._serialized_end = 637
    _globals["_ADDLOCALFILE"]._serialized_start = 639
    _globals["_ADDLOCALFILE"]._serialized_end = 712
    _globals["_ADDLOCALDIR"]._serialized_start = 714
    _globals["_ADDLOCALDIR"]._serialized_end = 790
    _globals["_ADDLOCALDIRFILE"]._serialized_start = 792
    _globals["_ADDLOCALDIRFILE"]._serialized_end = 870
