from __future__ import annotations

import functools
import inspect
from dataclasses import dataclass
from typing import Callable, Optional, TypeVar, overload

F = TypeVar("F", bound=Callable)


@dataclass
class SailFunction:
    """A Python function that can be executed inside a Sailbox."""

    func: Callable

    def __post_init__(self) -> None:
        # Keep this wrapper intentionally small: all remote execution behavior
        # lives on Sailbox so decorating a function does not change local calls.
        if not callable(self.func):
            raise TypeError("sail.function can only decorate callables")
        if inspect.iscoroutinefunction(self.func):
            raise TypeError("sail.function does not support async functions yet")
        if inspect.isasyncgenfunction(self.func):
            raise TypeError("sail.function does not support async generators yet")
        if inspect.isgeneratorfunction(self.func):
            raise TypeError("sail.function does not support generator functions yet")
        functools.update_wrapper(self, self.func)

    def __call__(self, *args, **kwargs):
        return self.func(*args, **kwargs)


@overload
def function(func: F) -> SailFunction: ...


@overload
def function(func: None = None) -> Callable[[F], SailFunction]: ...


def function(func: Optional[F] = None):
    """Decorate a Python function so it can run through ``Sailbox.exec``."""

    def decorate(value: F) -> SailFunction:
        return SailFunction(value)

    if func is None:
        return decorate
    return decorate(func)
