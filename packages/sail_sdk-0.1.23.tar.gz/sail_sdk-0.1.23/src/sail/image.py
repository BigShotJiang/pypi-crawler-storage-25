from __future__ import annotations

import concurrent.futures
import hashlib
import http.client
import os
import posixpath
import random
import stat
import sys
import time
import urllib.parse
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple, Union

import grpc
import pathspec
from sail._client import Client
from sail.errors import ImageBuildError
from sail.pb.image.v1 import image_pb2
from sail.pb.imagebuilder.v1 import imagebuilder_pb2

_IMAGEBUILDER_RETRY_DELAYS_SECONDS = (1.0, 2.0, 4.0)
_LOCAL_FILE_HASH_CHUNK = 64 * 1024
# 5 GiB — S3's single-PUT ceiling. The server enforces the same cap;
# the SDK-side check fails fast before the file is hashed.
_MAX_LOCAL_FILE_BYTES = 5 * 1024 * 1024 * 1024
# Mirrors MaxLocalDirFiles in backend/internal/sailbox/imagebuilder/manager.go.
# Rejecting client-side avoids hashing 100k files just to fail canonicalization.
_MAX_LOCAL_DIR_FILES = 50_000
# Mirrors MaxLocalDirRelativePathBytes in the same file.
_MAX_LOCAL_DIR_RELATIVE_PATH_BYTES = 1024
_LOCAL_DIR_UPLOAD_WORKERS = 16
# Per-socket-operation timeout for presigned PUT requests. Applies to
# the initial TCP/TLS connect AND each individual recv/send — not the
# full upload duration — so a stalled or half-open path raises instead
# of hanging forever, while a slow-but-progressing upload keeps going.
_PUT_REQUEST_SOCKET_TIMEOUT = 300.0


@dataclass(frozen=True)
class ImageDefinition:
    _spec: image_pb2.ImageSpec
    _image_id: Optional[str] = field(default=None)

    def to_proto(self) -> image_pb2.ImageSpec:
        return self._spec

    def apt_install(self, *packages: str) -> ImageDefinition:
        cleaned = _clean_packages(packages, "apt_install")
        step = image_pb2.ImageBuildStep(
            apt_install=image_pb2.PackageInstall(packages=cleaned)
        )
        return self._append_step(step)

    def pip_install(self, *packages: str) -> ImageDefinition:
        cleaned = _clean_packages(packages, "pip_install")
        step = image_pb2.ImageBuildStep(
            pip_install=image_pb2.PackageInstall(packages=cleaned)
        )
        return self._append_step(step)

    def run_commands(self, *cmd: str) -> ImageDefinition:
        if not cmd:
            raise ValueError("run_commands requires at least one command")
        steps = []
        for entry in cmd:
            cleaned = entry.strip()
            if not cleaned:
                raise ValueError("run_commands commands must be non-empty")
            steps.append(
                image_pb2.ImageBuildStep(
                    run_command=image_pb2.RunCommand(command=cleaned)
                )
            )
        image = self
        for step in steps:
            image = image._append_step(step)
        return image

    def add_local_file(
        self,
        local_path: Union[str, Path],
        remote_path: str,
        *,
        mode: Optional[int] = None,
    ) -> ImageDefinition:
        """Bake the contents of one local file into the image at remote_path.

        The local file is hashed (sha256) and uploaded to the imagebuilder's
        content-addressed asset store; only the hash, target path, and mode
        flow into the image spec. A one-byte change to the local file
        therefore changes the resulting image_id and forces a rebuild.

        ``remote_path`` must be an absolute POSIX path. If it ends with a
        slash, the basename of ``local_path`` is appended (matching Modal).
        ``mode`` is the POSIX permission bits (low 9 bits, max 0o777). When
        omitted (``None``) or 0 the worker applies the default 0o644 — proto3
        cannot distinguish absent from 0, so an explicit ``mode=0`` is
        treated the same as omitting the argument.
        """
        source = Path(local_path).expanduser()
        if not source.is_file():
            raise ValueError(
                f"add_local_file: {source} does not exist or is not a file"
            )
        # Validate cheap arguments before hashing or uploading; otherwise a
        # bad mode or remote_path argument would only surface after a
        # multi-GiB upload — the backend re-validates the same rules in
        # validateAbsoluteRemotePath.
        validated_mode = _validate_mode(mode)
        target = remote_path
        if target.endswith("/"):
            target = posixpath.join(target, source.name)
        _validate_remote_path(target)
        # Reject oversize files before hashing — a 10+ GiB file shouldn't
        # be fully streamed through sha256 just to surface a size error.
        stat_size = source.stat().st_size
        if stat_size > _MAX_LOCAL_FILE_BYTES:
            raise ValueError(
                f"add_local_file: {source} ({stat_size} bytes) exceeds the "
                f"{_MAX_LOCAL_FILE_BYTES}-byte local-file limit"
            )
        digest, size = _hash_file(source)
        if size > _MAX_LOCAL_FILE_BYTES:
            # Defense against the file growing between stat and read.
            raise ValueError(
                f"add_local_file: {source} ({size} bytes) exceeds the "
                f"{_MAX_LOCAL_FILE_BYTES}-byte local-file limit"
            )
        client = Client.get()
        _ensure_local_file_uploaded(client, source, digest, size)
        step = image_pb2.ImageBuildStep(
            add_local_file=image_pb2.AddLocalFile(
                content_sha256=digest,
                remote_path=target,
                mode=validated_mode,
            )
        )
        return self._append_step(step)

    def add_local_dir(
        self,
        local_path: Union[str, Path],
        remote_path: str,
        *,
        ignore: Optional[Union[Sequence[str], Path, str]] = None,
    ) -> ImageDefinition:
        """Bake a local directory into the image at remote_path.

        Each regular file under ``local_path`` is hashed and uploaded;
        per-file modes come from the local stat(). Symlinks are skipped.
        ``ignore`` accepts a sequence of gitignore patterns or a Path to a
        file containing them (e.g. ``.dockerignore``); pass a list to use
        patterns directly. ``remote_path`` must be an absolute POSIX path.
        """
        source = Path(local_path).expanduser()
        if not source.is_dir():
            raise ValueError(
                f"add_local_dir: {source} does not exist or is not a directory"
            )
        target = _validate_dir_remote_path(remote_path)
        spec = _load_ignore_spec(ignore)
        entries = _walk_local_dir_entries(source, spec)
        if not entries:
            if spec is not None:
                raise ValueError(
                    f"add_local_dir: {source} contains no files after applying ignore patterns"
                )
            raise ValueError(f"add_local_dir: {source} contains no files")
        if len(entries) > _MAX_LOCAL_DIR_FILES:
            raise ValueError(
                f"add_local_dir: {source} has {len(entries)} files after filtering, "
                f"max {_MAX_LOCAL_DIR_FILES}"
            )
        client = Client.get()
        files = _prepare_local_dir_files(client, entries)
        files.sort(key=lambda f: f.relative_path.encode("utf-8"))
        step = image_pb2.ImageBuildStep(
            add_local_dir=image_pb2.AddLocalDir(
                remote_path=target,
                files=[
                    image_pb2.AddLocalDirFile(
                        relative_path=f.relative_path,
                        content_sha256=f.digest,
                        mode=f.mode,
                    )
                    for f in files
                ],
            )
        )
        return self._append_step(step)

    def env(self, env: Dict[str, str]) -> ImageDefinition:
        if not env:
            raise ValueError("env requires at least one key")
        next_spec = image_pb2.ImageSpec()
        next_spec.CopyFrom(self._spec)
        _ensure_local_python_version(next_spec)
        for key, value in env.items():
            clean_key = key.strip()
            if not clean_key:
                raise ValueError("env keys must be non-empty")
            next_spec.env[clean_key] = value
        return ImageDefinition(next_spec)

    def build(self, *, timeout: int = 1800) -> ImageDefinition:
        if timeout <= 0:
            raise ValueError("timeout must be greater than 0")

        client = Client.get()
        spec = image_pb2.ImageSpec()
        spec.CopyFrom(self.to_proto())
        metadata = client.metadata()
        deadline = time.monotonic() + timeout
        resp = _build_image_with_socket_close_retries(
            client.imagebuilder_stub,
            spec,
            metadata,
            deadline,
        )
        image_id = resp.image_id

        while True:
            _raise_if_imagebuilder_deadline_exceeded(
                deadline, f"timed out waiting for image build {image_id}"
            )
            status = resp.status
            if status == image_pb2.IMAGE_BUILD_STATUS_READY:
                return ImageDefinition(spec, _image_id=image_id)
            if status == image_pb2.IMAGE_BUILD_STATUS_FAILED:
                raise ImageBuildError(resp.error_message or "image build failed")
            _sleep_until_imagebuilder_deadline(
                _next_build_poll_delay(),
                deadline,
                f"timed out waiting for image build {image_id}",
            )
            resp = _get_image_build_status_with_socket_close_retries(
                client.imagebuilder_stub,
                image_id,
                metadata,
                deadline,
            )

    def _ensure_built(self, *, timeout: int = 1800) -> ImageDefinition:
        if self._image_id is not None:
            return self
        return self.build(timeout=timeout)

    def _append_step(self, step: image_pb2.ImageBuildStep) -> ImageDefinition:
        next_spec = image_pb2.ImageSpec()
        next_spec.CopyFrom(self._spec)
        _ensure_local_python_version(next_spec)
        next_spec.build_steps.append(step)
        return ImageDefinition(next_spec)


def _clean_packages(packages: Tuple[str, ...], method: str) -> List[str]:
    if not packages:
        raise ValueError(f"{method} requires at least one package")
    cleaned: List[str] = []
    for package in packages:
        entry = package.strip()
        if not entry:
            raise ValueError(f"{method} packages must be non-empty")
        cleaned.append(entry)
    return cleaned


def _local_python_version() -> str:
    return f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"


def _ensure_local_python_version(spec: image_pb2.ImageSpec) -> None:
    if not spec.python_version:
        spec.python_version = _local_python_version()


def _next_build_poll_delay() -> float:
    return 1.0 + random.uniform(0.0, 0.25)


def _build_image_with_socket_close_retries(stub, spec, metadata, deadline):
    """Build an image, retrying only imagebuilder socket-close transport races."""
    timeout_message = "timed out waiting for image build to start"
    for delay in (*_IMAGEBUILDER_RETRY_DELAYS_SECONDS, None):
        _raise_if_imagebuilder_deadline_exceeded(deadline, timeout_message)
        try:
            return stub.BuildImage(
                imagebuilder_pb2.BuildImageRequest(image=spec),
                metadata=metadata,
            )
        except grpc.RpcError as exc:
            if delay is None or not _is_imagebuilder_socket_close(exc):
                raise
            _sleep_until_imagebuilder_deadline(delay, deadline, timeout_message)


def _get_image_build_status_with_socket_close_retries(
    stub, image_id, metadata, deadline
):
    """Fetch image build status, retrying only imagebuilder socket-close races."""
    timeout_message = f"timed out waiting for image build {image_id}"
    for delay in (*_IMAGEBUILDER_RETRY_DELAYS_SECONDS, None):
        _raise_if_imagebuilder_deadline_exceeded(deadline, timeout_message)
        try:
            return stub.GetImageBuildStatus(
                imagebuilder_pb2.GetImageBuildStatusRequest(image_id=image_id),
                metadata=metadata,
            )
        except grpc.RpcError as exc:
            if delay is None or not _is_imagebuilder_socket_close(exc):
                raise
            _sleep_until_imagebuilder_deadline(delay, deadline, timeout_message)


def _sleep_until_imagebuilder_deadline(
    delay: float, deadline: float, timeout_message: str
) -> None:
    """Sleep for at most the remaining imagebuilder timeout budget."""
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise TimeoutError(timeout_message)
    time.sleep(min(delay, remaining))
    _raise_if_imagebuilder_deadline_exceeded(deadline, timeout_message)


def _raise_if_imagebuilder_deadline_exceeded(
    deadline: float, timeout_message: str
) -> None:
    """Raise TimeoutError once imagebuilder build timeout budget is exhausted."""
    if time.monotonic() >= deadline:
        raise TimeoutError(timeout_message)


def _is_imagebuilder_socket_close(exc: grpc.RpcError) -> bool:
    """Return true for the transient imagebuilder socket-close errors we retry."""
    if exc.code() != grpc.StatusCode.UNAVAILABLE:
        return False
    details = (exc.details() or "").lower()
    return "socket closed" in details or "transport is closing" in details


def _validate_dir_remote_path(remote_path: str) -> str:
    if not remote_path.startswith("/"):
        raise ValueError(f"remote_path {remote_path!r} must be absolute")
    target = remote_path.rstrip("/")
    if not target:
        raise ValueError(f"add_local_dir: remote_path {remote_path!r} must not be '/'")
    _validate_remote_path(target)
    return target


def _load_ignore_spec(
    ignore: Optional[Union[Sequence[str], Path, str]],
) -> Optional[pathspec.PathSpec]:
    if ignore is None:
        return None
    if isinstance(ignore, (str, Path)):
        # Path-or-str is treated as a file path; wrap a single pattern in a list.
        ignore_path = Path(ignore).expanduser()
        if not ignore_path.is_file():
            raise ValueError(f"add_local_dir: ignore file {ignore_path} does not exist")
        with ignore_path.open("r", encoding="utf-8") as fh:
            return pathspec.GitIgnoreSpec.from_lines(fh)
    patterns = list(ignore)
    return pathspec.GitIgnoreSpec.from_lines(patterns)


@dataclass(frozen=True)
class _LocalDirEntry:
    abs_path: Path
    relative_path: str
    size: int
    mode: int


@dataclass(frozen=True)
class _LocalDirFile:
    relative_path: str
    digest: str
    mode: int


def _walk_local_dir_entries(
    source: Path, spec: Optional[pathspec.PathSpec]
) -> List[_LocalDirEntry]:
    # Negation patterns (e.g. ["*", "!keep/needed.txt"]) can re-include a
    # file under a directory whose name otherwise matches, so pruning is
    # only safe when no negation patterns exist.
    can_prune_dirs = spec is not None and not any(
        p.include is False for p in spec.patterns
    )
    entries: List[_LocalDirEntry] = []

    def _on_walk_error(err: OSError) -> None:
        raise err

    for dirpath, dirnames, filenames in os.walk(
        source, followlinks=False, onerror=_on_walk_error
    ):
        rel_dir = os.path.relpath(dirpath, source)
        rel_dir_posix = "" if rel_dir == "." else rel_dir.replace(os.sep, "/")
        dirnames.sort()
        if can_prune_dirs:
            kept_dirnames: List[str] = []
            for d in dirnames:
                rel = f"{rel_dir_posix}/{d}" if rel_dir_posix else d
                # Trailing slash so dir-only patterns like "node_modules/" match.
                if spec.match_file(rel + "/"):
                    continue
                kept_dirnames.append(d)
            dirnames[:] = kept_dirnames
        for name in sorted(filenames):
            rel = f"{rel_dir_posix}/{name}" if rel_dir_posix else name
            abs_path = Path(dirpath) / name
            if abs_path.is_symlink():
                continue
            try:
                st = abs_path.stat()
            except FileNotFoundError:
                continue
            if not stat.S_ISREG(st.st_mode):
                continue
            if spec is not None and spec.match_file(rel):
                continue
            if len(rel.encode("utf-8")) > _MAX_LOCAL_DIR_RELATIVE_PATH_BYTES:
                raise ValueError(
                    f"add_local_dir: relative_path {rel!r} exceeds "
                    f"{_MAX_LOCAL_DIR_RELATIVE_PATH_BYTES} bytes"
                )
            entries.append(
                _LocalDirEntry(
                    abs_path=abs_path,
                    relative_path=rel,
                    size=st.st_size,
                    mode=st.st_mode & 0o777,
                )
            )
    return entries


def _prepare_local_dir_files(
    client: Client, entries: Iterable[_LocalDirEntry]
) -> List[_LocalDirFile]:
    entries = list(entries)
    # Check sizes from stat before hashing so an oversize file in a large
    # tree doesn't burn sha256 cycles on the other entries.
    for entry in entries:
        if entry.size > _MAX_LOCAL_FILE_BYTES:
            raise ValueError(
                f"add_local_dir: {entry.abs_path} ({entry.size} bytes) exceeds "
                f"the {_MAX_LOCAL_FILE_BYTES}-byte per-file limit"
            )
    rows: List[_LocalDirFile] = []
    unique: Dict[str, Tuple[Path, int]] = {}
    for entry in entries:
        digest, size = _hash_file(entry.abs_path)
        # Recheck against growth between stat and read.
        if size > _MAX_LOCAL_FILE_BYTES:
            raise ValueError(
                f"add_local_dir: {entry.abs_path} ({size} bytes) exceeds "
                f"the {_MAX_LOCAL_FILE_BYTES}-byte per-file limit"
            )
        rows.append(
            _LocalDirFile(
                relative_path=entry.relative_path,
                digest=digest,
                mode=entry.mode,
            )
        )
        unique.setdefault(digest, (entry.abs_path, size))
    if unique:
        with concurrent.futures.ThreadPoolExecutor(
            max_workers=_LOCAL_DIR_UPLOAD_WORKERS
        ) as pool:
            futures = [
                pool.submit(_ensure_local_file_uploaded, client, path, digest, size)
                for digest, (path, size) in unique.items()
            ]
            for fut in concurrent.futures.as_completed(futures):
                fut.result()
    return rows


def _validate_mode(mode: Optional[int]) -> int:
    if mode is None or mode == 0:
        return 0
    if mode < 0 or mode > 0o777:
        raise ValueError(f"mode 0o{mode:o} must fit in low 9 bits")
    return mode


# Mirrors backend validateAbsoluteRemotePath in
# backend/internal/sailbox/imagebuilder/manager.go: rejecting these client-side
# avoids paying for a multi-GiB upload before the backend rejects the spec.
_REMOTE_PATH_FORBIDDEN_CHARS = frozenset('"\\$ ')


def _validate_remote_path(target: str) -> None:
    if not target.startswith("/"):
        raise ValueError(f"remote_path {target!r} must be absolute")
    if len(target) > 1 and target.endswith("/"):
        raise ValueError(f"remote_path {target!r} must not end with '/'")
    for ch in target:
        if ord(ch) < 0x20 or ord(ch) == 0x7F or ch in _REMOTE_PATH_FORBIDDEN_CHARS:
            raise ValueError(
                f"remote_path {target!r} contains an unsupported character"
            )
    for seg in target.split("/"):
        if seg == "..":
            raise ValueError(f"remote_path {target!r} must not contain '..'")


def _hash_file(path: Path) -> Tuple[str, int]:
    """Stream a file through sha256 without loading it all in memory."""
    digest = hashlib.sha256()
    size = 0
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(_LOCAL_FILE_HASH_CHUNK), b""):
            digest.update(chunk)
            size += len(chunk)
    return digest.hexdigest(), size


def _ensure_local_file_uploaded(
    client: Client, path: Path, digest: str, size: int
) -> None:
    """Probe + upload one local file, dispatching on the server's plan.

    The server replies with one of two outcomes:
      * already_exists: skip the upload entirely.
      * single_part: stream the bytes to one presigned PUT URL.
    """
    metadata = client.metadata()
    plan = client.imagebuilder_stub.PrepareLocalFileUpload(
        imagebuilder_pb2.PrepareLocalFileUploadRequest(
            content_sha256=digest,
            content_length=size,
        ),
        metadata=metadata,
    )
    outcome = plan.WhichOneof("outcome")
    if outcome == "already_exists":
        return
    if outcome == "single_part":
        single = plan.single_part
        _put_local_file_single(path, single.upload_url, dict(single.required_headers))
        return
    raise ImageBuildError(f"local file upload: unexpected server outcome {outcome!r}")


def _put_local_file_single(
    path: Path, upload_url: str, headers: Dict[str, str]
) -> None:
    """Stream the file body to the presigned PUT URL using only stdlib."""
    # PrepareLocalFileUpload guarantees required_headers includes
    # Content-Length and Content-Type.
    with path.open("rb") as body:
        _put_request(upload_url, headers, body)


def _put_request(url: str, headers: Dict[str, str], body) -> None:
    """PUT body to url; raise ImageBuildError on non-2xx."""
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme not in ("http", "https"):
        raise ValueError(f"unexpected local-file upload scheme {parsed.scheme!r}")
    # 300s applies to both connect and every individual socket recv/send,
    # not the full upload duration — a stalled TCP path surfaces an
    # exception instead of hanging forever, while a slow-but-progressing
    # upload keeps going as long as each chunk moves within 5 minutes.
    if parsed.scheme == "https":
        conn = http.client.HTTPSConnection(
            parsed.hostname, parsed.port or 443, timeout=_PUT_REQUEST_SOCKET_TIMEOUT
        )
    else:
        conn = http.client.HTTPConnection(
            parsed.hostname, parsed.port or 80, timeout=_PUT_REQUEST_SOCKET_TIMEOUT
        )
    selector = parsed.path or "/"
    if parsed.query:
        selector = f"{selector}?{parsed.query}"
    try:
        conn.request("PUT", selector, body=body, headers=headers)
        resp = conn.getresponse()
        data = resp.read()
        if resp.status < 200 or resp.status >= 300:
            raise ImageBuildError(
                f"local file upload failed: HTTP {resp.status} {resp.reason}: "
                f"{data.decode('utf-8', 'replace')[:512]}"
            )
    finally:
        conn.close()


class _ImageNamespace:
    # The arm64 factory pins python_version to the caller's interpreter so
    # the imagebuilder produces a per-Python-version base image (one for
    # 3.11, another for 3.12, etc.). That's what lets @sail.function exec
    # cloudpickle bytecode that matches the local interpreter. The amd64
    # factory leaves python_version empty so the spec stays a "builtin
    # base image" that EnsureBuild serves from the prebuilt rootfs; the
    # imagebuilder doesn't have an amd64 worker fleet that could build a
    # customized variant anyway.
    @property
    def debian_amd64(self) -> ImageDefinition:
        return ImageDefinition(
            image_pb2.ImageSpec(
                base=image_pb2.BASE_IMAGE_DEBIAN,
                architecture=image_pb2.IMAGE_ARCHITECTURE_AMD64,
            ),
        )

    @property
    def debian_amd(self) -> ImageDefinition:
        return self.debian_amd64

    @property
    def debian_arm64(self) -> ImageDefinition:
        return ImageDefinition(
            image_pb2.ImageSpec(
                base=image_pb2.BASE_IMAGE_DEBIAN,
                architecture=image_pb2.IMAGE_ARCHITECTURE_ARM64,
                python_version=_local_python_version(),
            ),
        )

    @property
    def debian_arm(self) -> ImageDefinition:
        return self.debian_arm64


Image = _ImageNamespace()
