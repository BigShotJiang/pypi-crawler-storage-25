from __future__ import annotations

import io
import json
import threading
import urllib.error

import pytest

import sail
import sail._http_client as http_client_module
import sail.voyage as voyage_module
from sail._config import Config
from sail._http_client import HTTPClient

VOYAGE_ID = "voy_00000000-0000-0000-0000-000000000001"
OTHER_VOYAGE_ID = "voy_00000000-0000-0000-0000-000000000002"


class FakeHTTPResponse:
    def __init__(self, *, status: int = 200, body: bytes = b'{"ok":true}') -> None:
        self.status = status
        self._body = body

    def read(self) -> bytes:
        return self._body

    def __enter__(self) -> "FakeHTTPResponse":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        return None


class RecordingURLOpener:
    def __init__(self, responses):
        self.responses = list(responses)
        self.calls = []

    def __call__(self, req, **kwargs):
        self.calls.append((req, kwargs))
        if not self.responses:
            raise AssertionError("unexpected HTTP request")
        response = self.responses.pop(0)
        if isinstance(response, BaseException):
            raise response
        status, body = response
        return FakeHTTPResponse(status=status, body=json.dumps(body).encode())


@pytest.fixture(autouse=True)
def reset_state() -> None:
    voyage_module._reset_for_tests()
    yield
    HTTPClient.reset()
    voyage_module._reset_for_tests()


def make_config(*, api_key: str = "test_key_123") -> Config:
    return Config(
        imagebuilder_url="imagebuilder.example.com:443",
        api_key=api_key,
        api_url="https://api.example.com",
        sailbox_ingress_url="https://api.example.com",
    )


def make_voyage(voyage_id: str = VOYAGE_ID) -> sail.Voyage:
    return sail.Voyage(
        id=voyage_id,
        client=HTTPClient(make_config()),
        _start_background=False,
    )


def set_inference_env(monkeypatch) -> None:
    monkeypatch.setenv("SAIL_API_KEY", "test_key_123")
    monkeypatch.setenv("SAIL_API_URL", "https://api.example.com")
    monkeypatch.delenv("SAIL_MODE", raising=False)


def install_recording_urlopen(monkeypatch, responses) -> RecordingURLOpener:
    opener = RecordingURLOpener(responses)
    monkeypatch.setattr(http_client_module.urllib.request, "urlopen", opener)
    return opener


def request_json(req):
    return json.loads(req.data.decode("utf-8"))


def request_headers(req):
    return {key.lower(): value for key, value in req.header_items()}


def test_inference_responses_create_posts_to_responses(monkeypatch):
    set_inference_env(monkeypatch)
    opener = install_recording_urlopen(
        monkeypatch,
        [(200, {"id": "resp_123", "output_text": "hello"})],
    )

    data = sail.inference.responses.create(
        model="openai/gpt-oss-20b",
        input="hello",
    )

    req, kwargs = opener.calls[0]
    assert req.get_method() == "POST"
    assert req.full_url == "https://api.example.com/v1/responses"
    assert kwargs == {}
    assert request_json(req) == {
        "model": "openai/gpt-oss-20b",
        "input": "hello",
    }
    assert data == {"id": "resp_123", "output_text": "hello"}


def test_inference_chat_completions_create_posts_to_chat_completions(monkeypatch):
    set_inference_env(monkeypatch)
    opener = install_recording_urlopen(
        monkeypatch,
        [(200, {"id": "chatcmpl_123", "choices": []})],
    )

    data = sail.inference.chat.completions.create(
        model="openai/gpt-oss-20b",
        messages=[{"role": "user", "content": "hello"}],
        timeout=4.5,
    )

    req, kwargs = opener.calls[0]
    assert req.get_method() == "POST"
    assert req.full_url == "https://api.example.com/v1/chat/completions"
    assert kwargs == {"timeout": 4.5}
    assert request_json(req) == {
        "model": "openai/gpt-oss-20b",
        "messages": [{"role": "user", "content": "hello"}],
    }
    assert data == {"id": "chatcmpl_123", "choices": []}


def test_inference_current_voyage_header_auto_injected(monkeypatch):
    set_inference_env(monkeypatch)
    opener = install_recording_urlopen(monkeypatch, [(200, {"id": "resp_123"})])
    voyage = make_voyage()
    voyage_module._set_current(voyage)

    sail.inference.responses.create(model="model", input="hello")

    headers = request_headers(opener.calls[0][0])
    assert headers["x-sail-voyage-id"] == VOYAGE_ID


def test_inference_current_voyage_context_headers_auto_injected(monkeypatch):
    set_inference_env(monkeypatch)
    opener = install_recording_urlopen(monkeypatch, [(200, {"id": "resp_123"})])
    voyage = make_voyage()
    voyage_module._set_current(voyage)

    with voyage.agent("agent_123"):
        with voyage.span("model call", span_id="span_123"):
            sail.inference.responses.create(model="model", input="hello")

    headers = request_headers(opener.calls[0][0])
    assert headers["x-sail-voyage-id"] == VOYAGE_ID
    assert headers["x-sail-voyage-span-id"] == "span_123"
    assert headers["x-sail-voyage-agent-id"] == "agent_123"


def test_inference_skips_non_header_safe_voyage_context(monkeypatch):
    set_inference_env(monkeypatch)
    opener = install_recording_urlopen(monkeypatch, [(200, {"id": "resp_123"})])
    voyage = make_voyage()
    voyage_module._set_current(voyage)

    with voyage.agent("agent_é"):
        with voyage.span("model call", span_id="span_\x1fbad"):
            sail.inference.responses.create(model="model", input="hello")

    headers = request_headers(opener.calls[0][0])
    assert headers["x-sail-voyage-id"] == VOYAGE_ID
    assert "x-sail-voyage-span-id" not in headers
    assert "x-sail-voyage-agent-id" not in headers


def test_inference_current_voyage_header_is_process_global_across_threads(monkeypatch):
    set_inference_env(monkeypatch)
    opener = install_recording_urlopen(monkeypatch, [(200, {"id": "resp_123"})])
    voyage = make_voyage()
    voyage_module._set_current(voyage)
    result = []

    def call_inference():
        result.append(sail.inference.responses.create(model="model", input="hello"))

    thread = threading.Thread(target=call_inference)
    thread.start()
    thread.join()

    assert result == [{"id": "resp_123"}]
    headers = request_headers(opener.calls[0][0])
    assert headers["x-sail-voyage-id"] == VOYAGE_ID


def test_inference_explicit_voyage_overrides_current_and_header_case(monkeypatch):
    set_inference_env(monkeypatch)
    opener = install_recording_urlopen(monkeypatch, [(200, {"id": "resp_123"})])
    voyage_module._set_current(make_voyage(VOYAGE_ID))
    explicit_voyage = make_voyage(OTHER_VOYAGE_ID)

    sail.inference.responses.create(
        voyage=explicit_voyage,
        headers={"x-sail-voyage-id": "old", "X-Trace": "trace_123"},
        model="model",
        input="hello",
    )

    headers = request_headers(opener.calls[0][0])
    assert headers["x-sail-voyage-id"] == OTHER_VOYAGE_ID
    assert headers["x-trace"] == "trace_123"


def test_inference_without_current_voyage_sends_no_voyage_header(monkeypatch):
    set_inference_env(monkeypatch)
    opener = install_recording_urlopen(monkeypatch, [(200, {"id": "resp_123"})])

    sail.inference.responses.create(model="model", input="hello")

    headers = request_headers(opener.calls[0][0])
    assert "x-sail-voyage-id" not in headers


def test_inference_preserves_caller_headers_and_uses_config_authorization(monkeypatch):
    set_inference_env(monkeypatch)
    opener = install_recording_urlopen(monkeypatch, [(200, {"id": "resp_123"})])

    sail.inference.responses.create(
        headers={"Authorization": "Bearer caller", "X-Trace": "trace_123"},
        model="model",
        input="hello",
    )

    headers = request_headers(opener.calls[0][0])
    assert headers["authorization"] == "Bearer test_key_123"
    assert headers["x-trace"] == "trace_123"


def test_inference_stream_true_raises_before_network(monkeypatch):
    set_inference_env(monkeypatch)
    opener = install_recording_urlopen(monkeypatch, [])

    with pytest.raises(sail.InferenceError, match="stream=True is not supported"):
        sail.inference.responses.create(model="model", input="hello", stream=True)

    assert opener.calls == []


def test_inference_forwards_raw_body_without_mutating_values(monkeypatch):
    set_inference_env(monkeypatch)
    opener = install_recording_urlopen(monkeypatch, [(200, {"id": "resp_123"})])
    metadata = {"nested": {"value": 1}}

    sail.inference.responses.create(
        model="model",
        input=[{"role": "user", "content": "hello"}],
        metadata=metadata,
        stream=False,
    )

    assert metadata == {"nested": {"value": 1}}
    assert request_json(opener.calls[0][0]) == {
        "model": "model",
        "input": [{"role": "user", "content": "hello"}],
        "metadata": {"nested": {"value": 1}},
        "stream": False,
    }


def test_inference_http_error_raises_inference_http_error(monkeypatch):
    set_inference_env(monkeypatch)

    def fake_urlopen(req, **kwargs):
        raise urllib.error.HTTPError(
            req.full_url,
            400,
            "bad request",
            {},
            io.BytesIO(b'{"error":{"message":"bad input"}}'),
        )

    monkeypatch.setattr(http_client_module.urllib.request, "urlopen", fake_urlopen)

    with pytest.raises(sail.InferenceHTTPError, match="bad input") as exc_info:
        sail.inference.responses.create(model="model", input="hello")

    assert exc_info.value.status_code == 400
    assert exc_info.value.response == {"error": {"message": "bad input"}}


def test_inference_missing_api_key_raises_inference_error_without_network(monkeypatch):
    monkeypatch.delenv("SAIL_API_KEY", raising=False)
    monkeypatch.setenv("SAIL_API_URL", "https://api.example.com")
    opener = install_recording_urlopen(monkeypatch, [])

    with pytest.raises(sail.InferenceError, match="SAIL_API_KEY must be set"):
        sail.inference.responses.create(model="model", input="hello")

    assert opener.calls == []
