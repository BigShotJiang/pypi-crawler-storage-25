"""Unit tests for the `sail` CLI.

These tests cover Click wiring, output formatting, config get/set
roundtrips, and unimplemented-command behavior. SDK calls (App.find,
Sailbox.*) are patched out — backend integration is exercised by the SDK
tests in test_sdk.py and the nightly suite.
"""

from __future__ import annotations

import io
import json
import os
import sys
import unittest
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional
from unittest import mock

from sail.cli import main
from sail.cli._config import _collect_kvs
from sail.cli._output import Output, _render_table
from sail.cli._state import (
    SailboxRecord,
    apply_config_to_env,
    config_path,
    home_dir,
    load_config_file,
    load_sailbox_record,
    save_config_file,
    save_sailbox_record,
)


@contextmanager
def captured_io():
    out = io.StringIO()
    err = io.StringIO()
    real_out, real_err = sys.stdout, sys.stderr
    sys.stdout, sys.stderr = out, err
    try:
        yield out, err
    finally:
        sys.stdout, sys.stderr = real_out, real_err


@contextmanager
def isolated_home(tmp_path: Path):
    saved = dict(os.environ)
    os.environ["SAIL_HOME"] = str(tmp_path)
    # Also clear envs that would leak from the host into the run.
    for key in (
        "SAIL_API_KEY",
        "SAIL_MODE",
        "SAIL_API_URL",
        "SAIL_IMAGEBUILDER_URL",
    ):
        os.environ.pop(key, None)
    try:
        yield
    finally:
        os.environ.clear()
        os.environ.update(saved)


@contextmanager
def _module_in_cwd(modname: str, body: str):
    """Write ``body`` to ``modname.py`` inside a tmp cwd, chdir into it, and
    pop ``modname`` out of ``sys.modules`` afterward. Shared by the
    `box exec MODULE::FN` and `box run` tests."""
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as td:
        with isolated_home(Path(td)):
            (Path(td) / f"{modname}.py").write_text(body)
            prev = os.getcwd()
            os.chdir(td)
            try:
                yield Path(td)
            finally:
                os.chdir(prev)
                sys.modules.pop(modname, None)


# --------------------------------------------------------------- Output utils


class TestOutputHelpers(unittest.TestCase):
    def test_emit_text_default(self):
        with captured_io() as (out, err):
            Output(json_mode=False).emit({"k": "v"}, text="hello")
        self.assertEqual(out.getvalue(), "hello\n")
        self.assertEqual(err.getvalue(), "")

    def test_emit_json_mode_ignores_text(self):
        with captured_io() as (out, err):
            Output(json_mode=True).emit({"k": "v"}, text="hello")
        self.assertEqual(json.loads(out.getvalue()), {"k": "v"})

    def test_table_render_handles_empty(self):
        with captured_io() as (out, err):
            Output(json_mode=False).emit_table([], columns=("a", "b"))
        self.assertEqual(out.getvalue(), "(no rows)\n")

    def test_table_render_aligns_columns(self):
        rendered = _render_table(
            [{"port": 80, "url": "http://x"}, {"port": 8080, "url": "http://yyyyy"}],
            columns=("port", "url"),
        )
        # Header row first, then aligned data.
        lines = rendered.splitlines()
        self.assertEqual(lines[0], "PORT  URL         ")
        self.assertEqual(lines[1], "80    http://x    ")
        self.assertEqual(lines[2], "8080  http://yyyyy")

    def test_error_writes_to_stderr_in_text_mode(self):
        with captured_io() as (out, err):
            Output(json_mode=False).error("bad", code="x")
        self.assertEqual(out.getvalue(), "")
        self.assertIn("sail: bad", err.getvalue())

    def test_error_writes_to_both_in_json_mode(self):
        with captured_io() as (out, err):
            Output(json_mode=True).error("bad", code="x")
        self.assertEqual(json.loads(out.getvalue())["error"]["code"], "x")
        self.assertIn("sail: bad", err.getvalue())

    def test_collect_kvs_parses_pairs(self):
        self.assertEqual(_collect_kvs(["a=1", "b=2"]), {"a": "1", "b": "2"})

    def test_collect_kvs_rejects_missing_equals(self):
        with self.assertRaises(ValueError):
            _collect_kvs(["a"])

    def test_collect_kvs_rejects_empty_value(self):
        # `sail config set api_key=` would otherwise be silently accepted and
        # then dropped at serialize time — clearing any prior value while the
        # success message claims "Saved 1 entry". Force users to `unset`.
        with self.assertRaises(ValueError) as cm:
            _collect_kvs(["api_key="])
        self.assertIn("sail config unset api_key", str(cm.exception))

    def test_collect_kvs_strips_value_whitespace(self):
        # Without value-side stripping, `sail config set "api_key= sk_test"`
        # writes a leading-space value to the file and produces a confusing
        # 401 from the API on every subsequent call.
        self.assertEqual(
            _collect_kvs(["api_key=  sk_test  "]),
            {"api_key": "sk_test"},
        )

    def test_collect_kvs_rejects_whitespace_only_value(self):
        with self.assertRaises(ValueError):
            _collect_kvs(["api_key=   "])


# ---------------------------------------------------------------------- main()


class TestTopLevel(unittest.TestCase):
    def test_help_exits_zero(self):
        with captured_io() as (out, _):
            rc = main(["--help"])
        self.assertEqual(rc, 0)
        self.assertTrue(out.getvalue().strip())

    def test_no_command_prints_help_and_exits_2(self):
        with captured_io() as (out, err):
            rc = main([])
        self.assertEqual(rc, 2)
        self.assertIn("sail", err.getvalue())

    def test_version_flag(self):
        with captured_io() as (out, err):
            rc = main(["--version"])
        self.assertEqual(rc, 0)
        self.assertTrue(out.getvalue().strip())

    def test_version_command_json(self):
        with captured_io() as (out, err):
            rc = main(["--json", "version"])
        self.assertEqual(rc, 0)
        self.assertIn("version", json.loads(out.getvalue()))

    def test_top_level_flags_reject_abbreviations(self):
        # Click does not auto-expand long-option prefixes, but a regression
        # to a custom parser could silently re-introduce that. Pin the
        # contract: `--mo` is rejected, the same invocation with the full
        # `--mode` spelling succeeds.
        with captured_io() as (_, err):
            rc = main(["--mo", "dev", "version"])
        self.assertEqual(rc, 2)
        self.assertTrue(err.getvalue().strip())
        with captured_io() as (out, _):
            rc = main(["--mode", "dev", "version"])
        self.assertEqual(rc, 0)
        self.assertTrue(out.getvalue().strip())

    def test_version_works_with_malformed_config(self):
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            config_path().parent.mkdir(parents=True, exist_ok=True)
            config_path().write_text("not = valid = toml\n")
            with captured_io() as (out, err):
                rc = main(["version"])
            self.assertEqual(rc, 0)
            self.assertTrue(out.getvalue().strip())


# ----------------------------------------------------------------------- auth


class TestAuth(unittest.TestCase):
    def test_whoami_without_api_key_returns_1(self):
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            with captured_io() as (out, err):
                rc = main(["auth", "whoami"])
        self.assertEqual(rc, 1)
        self.assertIn("(not set)", out.getvalue())

    def test_whoami_with_api_key_returns_0(self):
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            os.environ["SAIL_API_KEY"] = "sk-aaaaaaaaaaaa"
            with captured_io() as (out, err):
                rc = main(["auth", "whoami"])
        self.assertEqual(rc, 0)
        # Masked, never the full key.
        self.assertIn("sk-a…aaaa", out.getvalue())

    def test_whoami_works_with_malformed_config(self):
        # `sail auth whoami` is the diagnostic surface — when config.toml is
        # corrupt, it should still report (env-only) state instead of
        # forcing users to find `sail config reset` before they can see
        # what they're working with.
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            config_path().parent.mkdir(parents=True, exist_ok=True)
            config_path().write_text("not = valid = toml\n")
            os.environ["SAIL_API_KEY"] = "sk-bbbbbbbbbbbb"
            with captured_io() as (out, err):
                rc = main(["auth", "whoami"])
            self.assertEqual(rc, 0, err.getvalue())
            self.assertIn("sk-b…bbbb", out.getvalue())
        self.assertNotIn("sk-aaaaaaaaaaaa", out.getvalue())

    def test_logout_returns_structured_error_on_malformed_config(self):
        # `auth logout` has to load the file itself (it needs to know what
        # to remove). When the file is malformed, surface the same recovery
        # hint as `sail config get` instead of letting the TOML parse
        # exception escape to the generic top-level error handler.
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            config_path().parent.mkdir(parents=True, exist_ok=True)
            config_path().write_text("not = valid = toml\n")
            with captured_io() as (out, err):
                rc = main(["--json", "auth", "logout"])
        self.assertEqual(rc, 2, err.getvalue())
        payload = json.loads(out.getvalue())
        self.assertEqual(payload["error"]["code"], "invalid_state")
        self.assertIn("sail config reset", payload["error"]["message"])

    def test_login_is_not_registered(self):
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            with captured_io() as (out, err):
                rc = main(["auth", "login"])
        self.assertEqual(rc, 2)
        self.assertIn("No such command", err.getvalue())


# --------------------------------------------------------------------- config


class TestConfig(unittest.TestCase):
    def test_set_get_roundtrip(self):
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            with captured_io():
                rc = main(["config", "set", "mode=dev", "api_key=sk_test"])
            self.assertEqual(rc, 0)
            with captured_io() as (out, _):
                rc = main(["config", "get", "mode"])
            self.assertEqual(rc, 0)
            self.assertIn("dev", out.getvalue())

    def test_set_rejects_unknown_key(self):
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            with captured_io() as (out, err):
                rc = main(["config", "set", "totally_invented=x"])
        self.assertEqual(rc, 2)
        self.assertIn("unknown config keys", err.getvalue())

    def test_apply_config_to_env_does_not_clobber_existing(self):
        os.environ["SAIL_MODE"] = "prod"
        try:
            apply_config_to_env({"mode": "dev"})
            self.assertEqual(os.environ["SAIL_MODE"], "prod")
        finally:
            del os.environ["SAIL_MODE"]

    def test_apply_config_to_env_preserves_explicit_empty(self):
        # `SAIL_API_KEY='' sail ...` is an explicit "ignore my persisted key"
        # signal; it must not fall through to the config file.
        os.environ.pop("SAIL_API_KEY", None)
        os.environ["SAIL_API_KEY"] = ""
        try:
            apply_config_to_env({"api_key": "from-file"})
            self.assertEqual(os.environ["SAIL_API_KEY"], "")
        finally:
            del os.environ["SAIL_API_KEY"]

    def test_set_rejects_invalid_mode_value(self):
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            with captured_io() as (out, err):
                rc = main(["config", "set", "mode=prdo"])
        self.assertEqual(rc, 2)
        self.assertIn("invalid mode", err.getvalue())
        self.assertFalse(config_path().exists())

    def test_malformed_config_returns_structured_error(self):
        # Operational commands (box/app) fold persisted config into the
        # environment via apply_config_or_exit() inside the leaf body. A
        # malformed file exits 2 with a structured `invalid_state` error and
        # a `config reset` recovery hint, before the SDK call is reached.
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            config_path().parent.mkdir(parents=True, exist_ok=True)
            config_path().write_text("not = valid = toml\n[oops")
            with captured_io() as (out, err):
                rc = main(["app", "find", "demo"])
        self.assertEqual(rc, 2)
        self.assertIn("sail:", err.getvalue())
        self.assertIn("sail config reset", err.getvalue())

    def test_subcommand_help_works_with_malformed_config(self):
        # `--help` is an eager Click option: it renders before the leaf body
        # runs, so the apply_config_or_exit() call never fires. A malformed
        # config file must not turn `sail app --help` / `sail box --help`
        # into hard errors — that's exactly when users are looking for the
        # `config reset` recovery command.
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            config_path().parent.mkdir(parents=True, exist_ok=True)
            config_path().write_text("not = valid = toml\n[oops")
            for argv in (
                ["app", "--help"],
                ["box", "--help"],
                ["app", "find", "--help"],
                ["app", "-h"],
            ):
                with captured_io() as (out, err):
                    rc = main(argv)
                self.assertEqual(rc, 0, f"argv={argv} unexpectedly failed")
                # Help text goes to stdout; the leaf's usage banner is the
                # most stable substring across Click versions.
                self.assertIn("Usage:", out.getvalue())

    def test_malformed_config_emits_json_when_json_flag_at_any_level(self):
        # Click parses `--json` natively at every level, so the leaf's
        # apply_config_or_exit() emits a JSON error envelope whether the flag
        # is given at the root, the group, or the leaf.
        import json

        from tempfile import TemporaryDirectory

        for argv in (
            ["--json", "app", "find", "demo"],
            ["app", "--json", "find", "demo"],
            ["app", "find", "demo", "--json"],
        ):
            with TemporaryDirectory() as td, isolated_home(Path(td)):
                config_path().parent.mkdir(parents=True, exist_ok=True)
                config_path().write_text("not = valid = toml\n[oops")
                with captured_io() as (out, err):
                    rc = main(argv)
            self.assertEqual(rc, 2, f"argv={argv}")
            payload = json.loads(out.getvalue())
            self.assertEqual(payload["error"]["code"], "invalid_state")

    def test_config_set_unset_recovery_path_when_file_malformed(self):
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            config_path().parent.mkdir(parents=True, exist_ok=True)
            config_path().write_text("not = valid = toml\n[oops")
            # config set/unset should fail with a structured error pointing
            # at the recovery command, not blow up with a traceback.
            with captured_io() as (out, err):
                rc = main(["config", "set", "mode=dev"])
            self.assertEqual(rc, 2)
            self.assertIn("sail config reset", err.getvalue())
            with captured_io() as (out, err):
                rc = main(["config", "unset", "mode"])
            self.assertEqual(rc, 2)
            self.assertIn("sail config reset", err.getvalue())
            # `config reset` must succeed regardless of file shape.
            self.assertTrue(config_path().exists())
            with captured_io() as (out, err):
                rc = main(["config", "reset"])
            self.assertEqual(rc, 0)
            self.assertFalse(config_path().exists())
            # And after reset, normal operations work again.
            with captured_io():
                rc = main(["config", "set", "mode=dev"])
            self.assertEqual(rc, 0)

    def test_set_rejects_control_characters_in_value(self):
        # A raw newline in a config value would be written as an unescaped
        # control char into TOML and brick every subsequent CLI run. Reject
        # at write time and don't touch disk.
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            with captured_io() as (out, err):
                rc = main(["config", "set", "api_key=sk_test\nbad"])
        self.assertEqual(rc, 2)
        self.assertIn("control characters", err.getvalue())
        self.assertFalse(config_path().exists())

    def test_set_text_pluralization(self):
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            with captured_io() as (out, _):
                rc = main(["config", "set", "mode=dev"])
            self.assertEqual(rc, 0)
            self.assertIn("Saved 1 entry", out.getvalue())
            with captured_io() as (out, _):
                rc = main(["config", "set", "mode=staging", "api_key=sk_test"])
            self.assertEqual(rc, 0)
            self.assertIn("Saved 2 entries", out.getvalue())

    def test_unset_text_pluralization(self):
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            with captured_io():
                rc = main(["config", "set", "mode=dev", "api_key=sk_test"])
            self.assertEqual(rc, 0)
            with captured_io() as (out, _):
                rc = main(["config", "unset", "api_key"])
            self.assertEqual(rc, 0)
            self.assertIn("Removed 1 entry.", out.getvalue())

    def test_config_reset_on_missing_file_is_noop_zero(self):
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            with captured_io() as (out, err):
                rc = main(["config", "reset"])
        self.assertEqual(rc, 0)
        self.assertIn("did not exist", out.getvalue())

    def test_config_unset_does_not_create_file_when_nothing_removed(self):
        # A no-op `sail config unset KEY` against a missing config file should
        # not silently create the file as a side effect — both because it's
        # surprising and because it would fail under a read-only SAIL_HOME.
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            with captured_io() as (out, err):
                rc = main(["config", "unset", "api_key"])
            self.assertEqual(rc, 0, err.getvalue())
            self.assertIn("Removed 0 entries", out.getvalue())
            self.assertFalse(config_path().exists())


# ------------------------------------------------------------------------ app


class TestApp(unittest.TestCase):
    def test_find_calls_sdk(self):
        with mock.patch("sail.cli._app.App.find") as mocked:
            mocked.return_value = mock.Mock(
                id="app_1", name="demo", created_at=1700000000
            )
            with captured_io() as (out, err):
                rc = main(["--json", "app", "find", "demo"])
        self.assertEqual(rc, 0)
        mocked.assert_called_once_with(name="demo", mint_if_missing=False)
        self.assertEqual(json.loads(out.getvalue())["id"], "app_1")

    def test_create_calls_find_with_mint_if_missing(self):
        with mock.patch("sail.cli._app.App.find") as mocked:
            mocked.return_value = mock.Mock(
                id="app_1", name="demo", created_at=1700000000
            )
            with captured_io():
                rc = main(["app", "create", "demo"])
        self.assertEqual(rc, 0)
        mocked.assert_called_once_with(name="demo", mint_if_missing=True)

    def test_list_is_not_registered(self):
        with captured_io() as (out, err):
            rc = main(["app", "list"])
        self.assertEqual(rc, 2)
        self.assertIn("No such command", err.getvalue())


# -------------------------------------------------------------------- sailbox


@dataclass
class _StubExecRequest:
    sailbox_id: str
    exec_request_id: str
    background: bool
    command: str = ""
    timeout: Optional[int] = None
    cwd: Optional[str] = None

    def wait(self):
        return mock.Mock(stdout="hi\n", stderr="", returncode=0)


@dataclass
class _StubSailbox:
    sailbox_id: str = "sb_test"
    name: str = "test-box"
    status: str = "running"
    worker_address: str = "10.0.0.1:50051"
    exec_endpoint: str = "10.0.0.1:50052"
    last_exec: Optional["_StubExecRequest"] = None

    def exec(self, command, *, timeout=None, background=False, cwd=None):
        req = _StubExecRequest(
            sailbox_id=self.sailbox_id,
            exec_request_id="exec_123",
            background=background,
            command=command,
            timeout=timeout,
            cwd=cwd,
        )
        self.last_exec = req
        return req

    def listeners(self):
        return [
            mock.Mock(
                port=3000,
                url="https://api.sailresearch.com/_sailbox/sb_test/3000",
                protocol="http",
                route_status="LISTENER_ROUTE_STATUS_ACTIVE",
            )
        ]

    def listener(self, port):
        return mock.Mock(
            port=port,
            url=f"https://api.sailresearch.com/_sailbox/sb_test/{port}",
            route_status="LISTENER_ROUTE_STATUS_ACTIVE",
        )

    def terminate(self):
        return None

    def sleep(self):
        self.status = "sleeping"

    def pause(self):
        self.status = "paused"

    def resume(self):
        self.status = "running"
        return self

    def checkpoint(self):
        return None


@dataclass
class _StubFunctionSailbox:
    """Stub for the function form of `sail box exec`.

    The function-exec code calls ``sb.exec(SailFunction, *args, kwargs=...)``
    and unwraps a plain Python value (not a SailboxExecRequest), so this stub
    captures the call shape and either returns ``result`` or raises
    ``raise_exc``. Separate from ``_StubSailbox`` because the function path
    has a different return contract — mixing them in one stub would force
    every shell-exec test to also configure a result.
    """

    sailbox_id: str = "sb_test"
    name: str = "test-box"
    status: str = "running"
    worker_address: str = "10.0.0.1:50051"
    exec_endpoint: str = "10.0.0.1:50052"
    result: Any = None
    raise_exc: Optional[BaseException] = None
    last_function: Any = None
    last_args: tuple = ()
    last_kwargs: Optional[dict] = None
    last_timeout: Optional[int] = None
    last_cwd: Optional[str] = None

    def exec(
        self, command, *args, timeout=None, background=False, cwd=None, kwargs=None
    ):
        self.last_function = command
        self.last_args = args
        self.last_kwargs = dict(kwargs or {})
        self.last_timeout = timeout
        self.last_cwd = cwd
        if self.raise_exc is not None:
            raise self.raise_exc
        return self.result


class TestSailbox(unittest.TestCase):
    def test_create_persists_record_and_emits_metadata(self):
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            stub = _StubSailbox()
            with mock.patch(
                "sail.cli._sailbox.Sailbox.create", return_value=stub
            ) as create, mock.patch(
                "sail.cli._sailbox.App.find",
                return_value=mock.Mock(id="app_1", name="demo", created_at=0),
            ):
                with captured_io() as (out, err):
                    rc = main(
                        [
                            "--json",
                            "box",
                            "create",
                            "--app",
                            "demo",
                            "--name",
                            "test-box",
                            "--cpu",
                            "2",
                            "--memory",
                            "2g",
                            "--disk",
                            "16g",
                            "--port",
                            "3000",
                        ]
                    )
            self.assertEqual(rc, 0)
            kwargs = create.call_args.kwargs
            self.assertEqual(kwargs["cpu"], 2)
            self.assertEqual(kwargs["memory_mib"], 2048)
            self.assertEqual(kwargs["disk_gib"], 16)
            self.assertEqual(kwargs["ingress_ports"], [3000])
            payload = json.loads(out.getvalue())
            self.assertEqual(payload["sailbox_id"], "sb_test")
            record = load_sailbox_record("sb_test")
            self.assertIsNotNone(record)
            assert record is not None  # for type-checker
            self.assertEqual(record.exec_endpoint, "10.0.0.1:50052")

    def test_create_rejects_invalid_memory_with_exit_2(self):
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            with mock.patch(
                "sail.cli._sailbox.App.find",
                return_value=mock.Mock(id="app_1", name="demo", created_at=0),
            ), captured_io() as (out, err):
                rc = main(
                    [
                        "box",
                        "create",
                        "--app",
                        "demo",
                        "--name",
                        "x",
                        "--memory",
                        "oops",
                    ]
                )
        self.assertEqual(rc, 2)
        self.assertIn("invalid memory value", err.getvalue())
        self.assertIn("m/g suffix", err.getvalue())

    def test_create_rejects_out_of_range_port(self):
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            with mock.patch(
                "sail.cli._sailbox.App.find",
                return_value=mock.Mock(id="app_1", name="demo", created_at=0),
            ), captured_io() as (out, err):
                rc = main(
                    [
                        "box",
                        "create",
                        "--app",
                        "demo",
                        "--name",
                        "x",
                        "--port",
                        "0",
                    ]
                )
        self.assertEqual(rc, 2)
        # Click's IntRange validator surfaces a UsageError before we even
        # reach the leaf — message format is `... is not in the range ...`.
        self.assertIn("range", err.getvalue())

    def test_exec_uses_cached_endpoint(self):
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            save_sailbox_record(
                SailboxRecord(
                    sailbox_id="sb_test",
                    name="test-box",
                    app_id="app_1",
                    exec_endpoint="10.0.0.1:50052",
                    worker_address="10.0.0.1:50051",
                )
            )
            stub = _StubSailbox()
            # Patch the Sailbox constructor (not _hydrate_for_exec) so the
            # cache-lookup path actually runs: _hydrate_for_exec reads the
            # JSON record above, then constructs a Sailbox with the cached
            # endpoint — that constructor call is what we capture.
            with mock.patch("sail.cli._sailbox.Sailbox", return_value=stub) as ctor:
                with captured_io() as (out, err):
                    rc = main(["box", "exec", "sb_test", "--", "echo", "hi"])
            self.assertEqual(rc, 0)
            self.assertIn("hi", out.getvalue())
            ctor.assert_called_once()
            kwargs = ctor.call_args.kwargs
            self.assertEqual(kwargs["sailbox_id"], "sb_test")
            self.assertEqual(kwargs["exec_endpoint"], "10.0.0.1:50052")
            self.assertEqual(kwargs["worker_address"], "10.0.0.1:50051")

    def test_exec_without_cached_endpoint_errors(self):
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            with captured_io() as (out, err):
                rc = main(["box", "exec", "sb_unknown", "--", "echo", "hi"])
        self.assertEqual(rc, 2)
        self.assertIn("no cached exec endpoint", err.getvalue())

    def test_exec_requires_command(self):
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            save_sailbox_record(
                SailboxRecord(
                    sailbox_id="sb_test",
                    name="test-box",
                    app_id="app_1",
                    exec_endpoint="10.0.0.1:50052",
                )
            )
            with captured_io() as (out, err):
                rc = main(["box", "exec", "sb_test"])
        self.assertEqual(rc, 2)
        self.assertIn("missing command", err.getvalue())

    def test_exec_rejects_mistyped_option_as_sailbox_id(self):
        """A mistyped CLI option before the id (`--timeuot 30 sb ...`) is
        parsed as <sailbox_id> by `ignore_unknown_options`; catch the
        option-shaped id with a clear error instead of a confusing
        downstream failure."""
        with captured_io() as (out, err):
            rc = main(["box", "exec", "--timeuot", "30", "sb_test", "echo", "hi"])
        self.assertEqual(rc, 2)
        self.assertIn("--timeuot", err.getvalue())
        self.assertIn("looks like an option", err.getvalue())

    def test_exec_splits_with_sailbox_level_flags(self):
        """Regression: --json/--mode are valid at every parser level, so they
        must be accepted between `sailbox` and `exec`. Without that, the
        post-`--` tokens (the remote command) would land on the wrong parser
        and the exec call would never reach the SDK.
        """
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            stub = _StubSailbox()
            with mock.patch("sail.cli._sailbox._hydrate_for_exec", return_value=stub):
                with captured_io() as (out, err):
                    rc = main(
                        [
                            "box",
                            "--json",
                            "exec",
                            "sb_test",
                            "--",
                            "echo",
                            "hi",
                        ]
                    )
            self.assertEqual(rc, 0)
            self.assertIsNotNone(stub.last_exec)

    def test_subparser_rejects_flag_abbreviation(self):
        """Regression: a subgroup's `--mo` must be rejected as unknown, not
        silently expanded to `--mode`. Click does not auto-abbreviate, but a
        regression to a custom parser would re-introduce the failure mode."""
        with captured_io() as (_, err):
            rc = main(["box", "--mo", "dev", "list"])
        self.assertEqual(rc, 2)
        self.assertTrue(err.getvalue().strip())

    def test_exec_maps_sdk_value_errors_to_invalid_argument(self):
        """Regression: Sailbox.exec rejects timeout<=0 and empty --cwd with
        ValueError. Click's `type=int` accepts 0/-1, so the bad value reaches
        the SDK and would otherwise bubble through the generic exception
        handler (exit 1). The CLI should classify these as invalid_argument
        (exit 2).
        """
        from tempfile import TemporaryDirectory

        class _Rejecting:
            def exec(self, *args, **kwargs):
                raise ValueError("timeout must be greater than 0")

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            with mock.patch(
                "sail.cli._sailbox._hydrate_for_exec", return_value=_Rejecting()
            ):
                with captured_io() as (out, err):
                    rc = main(
                        [
                            "box",
                            "exec",
                            "--timeout",
                            "0",
                            "sb_test",
                            "echo",
                            "hi",
                        ]
                    )
            self.assertEqual(rc, 2)
            self.assertIn("timeout must be greater than 0", err.getvalue())

    def test_exec_background_flag_after_id(self):
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            stub = _StubSailbox()
            with mock.patch("sail.cli._sailbox._hydrate_for_exec", return_value=stub):
                with captured_io() as (out, err):
                    rc = main(
                        [
                            "box",
                            "exec",
                            "--background",
                            "sb_test",
                            "sleep",
                            "1",
                        ]
                    )
            self.assertEqual(rc, 0)
            assert stub.last_exec is not None
            self.assertTrue(stub.last_exec.background)
            self.assertEqual(stub.last_exec.command, "sleep 1")

    # ------------------------------------------- `sail box exec MODULE::FN`
    #
    # The user's module is run via runpy with run_name="__main__", so the
    # resolved function's __module__ is "__main__" and cloudpickle's by-value
    # heuristic ships it (closure included) to the remote sailbox without
    # sharing our sys.path. Tests use real .py files in a tmp cwd — runpy
    # walks the import system to find the module, so types.ModuleType stubs
    # in sys.modules wouldn't be picked up.

    def test_exec_function_via_module_path(self):
        """End-to-end: MODULE::FN resolves, args parse, the SDK gets a
        SailFunction, the result renders. Other MODULE::FN tests are narrow
        regressions on top of this."""
        body = (
            "import sail\n"
            "@sail.function\n"
            "def summarize(vals, label='default'):\n"
            "    return {'count': len(vals), 'sum': sum(vals), 'label': label}\n"
        )
        with _module_in_cwd("_sail_cli_test_module", body):
            stub = _StubFunctionSailbox(result={"count": 3, "sum": 6, "label": "demo"})
            with mock.patch("sail.cli._sailbox._hydrate_for_exec", return_value=stub):
                with captured_io() as (out, err):
                    rc = main(
                        [
                            "--json",
                            "box",
                            "exec",
                            "sb_test",
                            "_sail_cli_test_module::summarize",
                            "[1, 2, 3]",
                            "label=demo",
                        ]
                    )
            self.assertEqual(rc, 0, err.getvalue())
            from sail.function import SailFunction

            self.assertIsInstance(stub.last_function, SailFunction)
            self.assertEqual(stub.last_args, ([1, 2, 3],))
            self.assertEqual(stub.last_kwargs, {"label": "demo"})
            payload = json.loads(out.getvalue())
            self.assertEqual(payload["sailbox_id"], "sb_test")
            self.assertEqual(payload["result"], {"count": 3, "sum": 6, "label": "demo"})

    def test_exec_function_via_file_path(self):
        """File-path form resolves via runpy.run_path; any token with a
        path separator or ``.py`` suffix takes this branch."""
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            script = Path(td) / "fn_target.py"
            script.write_text(
                "import sail\n"
                "@sail.function\n"
                "def hello(name):\n"
                "    return f'hi, {name}'\n"
            )
            stub = _StubFunctionSailbox(result="hi, world")
            with mock.patch("sail.cli._sailbox._hydrate_for_exec", return_value=stub):
                with captured_io() as (out, err):
                    rc = main(["box", "exec", "sb_test", f"{script}::hello", "world"])
            self.assertEqual(rc, 0, err.getvalue())
            self.assertEqual(stub.last_args, ("world",))
            self.assertIn("hi, world", out.getvalue())

    def test_exec_function_file_path_resolves_sibling_imports(self):
        """runpy.run_path puts the script's parent dir on sys.path during the
        run, so ``import helper`` inside ``tools/fn.py`` resolves to
        ``tools/helper.py`` — same as ``python tools/fn.py``. The CLI restores
        sys.path afterward."""
        import sys as _sys
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            (Path(td) / "fn_helper.py").write_text("VALUE = 7\n")
            script = Path(td) / "fn_with_sibling.py"
            script.write_text(
                "import sail\n"
                "import fn_helper\n"
                "@sail.function\n"
                "def use_helper():\n"
                "    return fn_helper.VALUE\n"
            )
            saved_path = _sys.path[:]
            try:
                stub = _StubFunctionSailbox(result=7)
                with mock.patch(
                    "sail.cli._sailbox._hydrate_for_exec", return_value=stub
                ):
                    with captured_io() as (out, err):
                        rc = main(["box", "exec", "sb_test", f"{script}::use_helper"])
                self.assertEqual(rc, 0, err.getvalue())
                self.assertIn("7", out.getvalue())
                # CLI must restore sys.path to the exact pre-call slice.
                self.assertEqual(_sys.path, saved_path)
            finally:
                _sys.path[:] = saved_path
                _sys.modules.pop("fn_helper", None)

    def test_exec_function_module_resolves_from_cwd(self):
        """When sail runs via the console-script entry point, ``sys.path[0]``
        is the venv bin dir, not the user's cwd. The CLI prepends cwd so
        ``pkg.mod::fn`` works for an uninstalled project module, then
        restores sys.path."""
        import sys as _sys

        body = "import sail\n@sail.function\ndef fn():\n    return 'ok'\n"
        with _module_in_cwd("_sail_cli_cwd_module", body) as td:
            self.assertNotIn(str(td), _sys.path)
            stub = _StubFunctionSailbox(result="ok")
            with mock.patch("sail.cli._sailbox._hydrate_for_exec", return_value=stub):
                with captured_io() as (out, err):
                    rc = main(["box", "exec", "sb_test", "_sail_cli_cwd_module::fn"])
            self.assertEqual(rc, 0, err.getvalue())
            self.assertNotIn(str(td), _sys.path)

    def test_exec_function_module_cwd_shadows_preloaded(self):
        """Sail's CLI process has its own deps preloaded (click, grpc, …). A
        user whose CWD module happens to collide with one of those names must
        still get their CWD code, not the preloaded dep. The CLI evicts the
        cached entry for the run and restores it afterward so sail's later
        lazy imports still see the real dep."""
        import sys as _sys
        import types as _types

        # Preload a fake "shadowme" module to simulate a sail dep being imported
        # before the user invokes the CLI.
        preloaded = _types.ModuleType("shadowme")
        preloaded.MARKER = "preloaded"
        _sys.modules["shadowme"] = preloaded
        try:
            body = (
                "import sail\n"
                "MARKER = 'from-cwd'\n"
                "@sail.function\n"
                "def fn():\n"
                "    return MARKER\n"
            )
            with _module_in_cwd("shadowme", body):
                stub = _StubFunctionSailbox(result="from-cwd")
                with mock.patch(
                    "sail.cli._sailbox._hydrate_for_exec", return_value=stub
                ):
                    with captured_io() as (out, err):
                        rc = main(["box", "exec", "sb_test", "shadowme::fn"])
                self.assertEqual(rc, 0, err.getvalue())
                from sail.function import SailFunction

                self.assertIsInstance(stub.last_function, SailFunction)
                # Preloaded entry restored — sail's later lazy imports must see
                # the original dep, not the user's shadow. Assert here (inside
                # the cwd context) before the helper pops the user's module.
                self.assertIs(_sys.modules.get("shadowme"), preloaded)
        finally:
            _sys.modules.pop("shadowme", None)

    def test_exec_function_module_cwd_shadows_preloaded_namespace_package(self):
        """PEP 420 namespace packages (no __init__.py) must also win over a
        preloaded same-named module. The collision gate checks for a CWD
        directory with the top-level name regardless of __init__.py, so
        `shadowns/foo.py` alone is enough — even though Python imports the
        package without ever executing an __init__."""
        from tempfile import TemporaryDirectory
        import sys as _sys
        import types as _types

        preloaded = _types.ModuleType("shadowns")
        preloaded.MARKER = "preloaded"
        _sys.modules["shadowns"] = preloaded
        try:
            with TemporaryDirectory() as td:
                with isolated_home(Path(td)):
                    pkg_dir = Path(td) / "shadowns"
                    pkg_dir.mkdir()
                    # No __init__.py — this is a namespace package.
                    (pkg_dir / "foo.py").write_text(
                        "import sail\n"
                        "@sail.function\n"
                        "def fn():\n"
                        "    return 'from-namespace'\n"
                    )
                    prev = os.getcwd()
                    os.chdir(td)
                    try:
                        stub = _StubFunctionSailbox(result="from-namespace")
                        with mock.patch(
                            "sail.cli._sailbox._hydrate_for_exec", return_value=stub
                        ):
                            with captured_io() as (out, err):
                                rc = main(
                                    ["box", "exec", "sb_test", "shadowns.foo::fn"]
                                )
                        self.assertEqual(rc, 0, err.getvalue())
                        from sail.function import SailFunction

                        self.assertIsInstance(stub.last_function, SailFunction)
                        self.assertIs(_sys.modules.get("shadowns"), preloaded)
                    finally:
                        os.chdir(prev)
        finally:
            _sys.modules.pop("shadowns", None)
            _sys.modules.pop("shadowns.foo", None)

    def test_exec_function_module_purges_shadow_submodules(self):
        """User's shadow package may load submodules during execution
        (e.g. `from . import helper`). Those entries must be purged before
        we hand control back — otherwise cloudpickle would pickle objects
        from `shadowpkg.helper` by reference, and unpickling on the remote
        sailbox (which has the preloaded dep at `shadowpkg`, not user code)
        would fail with ModuleNotFoundError."""
        from tempfile import TemporaryDirectory
        import sys as _sys
        import types as _types

        preloaded = _types.ModuleType("shadowpkg")
        preloaded.MARKER = "preloaded"
        _sys.modules["shadowpkg"] = preloaded
        try:
            with TemporaryDirectory() as td:
                with isolated_home(Path(td)):
                    pkg_dir = Path(td) / "shadowpkg"
                    pkg_dir.mkdir()
                    (pkg_dir / "__init__.py").write_text("from . import helper\n")
                    (pkg_dir / "helper.py").write_text("X = 42\n")
                    (pkg_dir / "mod.py").write_text(
                        "import sail\n"
                        "from . import helper\n"
                        "@sail.function\n"
                        "def fn():\n"
                        "    return helper.X\n"
                    )
                    prev = os.getcwd()
                    os.chdir(td)
                    try:
                        stub = _StubFunctionSailbox(result=42)
                        with mock.patch(
                            "sail.cli._sailbox._hydrate_for_exec", return_value=stub
                        ):
                            with captured_io() as (out, err):
                                rc = main(
                                    ["box", "exec", "sb_test", "shadowpkg.mod::fn"]
                                )
                        self.assertEqual(rc, 0, err.getvalue())
                        # Preloaded restored — sail's later lazy imports see real dep.
                        self.assertIs(_sys.modules.get("shadowpkg"), preloaded)
                        # User-loaded submodules purged so cloudpickle pickles
                        # their references by value, not by name.
                        self.assertNotIn("shadowpkg.helper", _sys.modules)
                        self.assertNotIn("shadowpkg.mod", _sys.modules)
                    finally:
                        os.chdir(prev)
        finally:
            _sys.modules.pop("shadowpkg", None)
            _sys.modules.pop("shadowpkg.helper", None)
            _sys.modules.pop("shadowpkg.mod", None)

    def test_exec_function_resolved_function_has_main_module(self):
        """The whole simplification rests on this contract:
        ``_resolve_function_spec`` returns a SailFunction whose underlying
        callable has ``__module__ == "__main__"``. That's the trigger for
        cloudpickle's by-value heuristic, which lets the function (and its
        closure) ship to a remote sailbox without sharing our sys.path.
        Regress this and remote exec breaks with ModuleNotFoundError."""
        from sail.cli._function_spec import (
            resolve_function_spec as _resolve_function_spec,
        )

        body = "import sail\n@sail.function\ndef fn():\n    return 1\n"
        # MODULE::FN form.
        with _module_in_cwd("_sail_cli_main_module", body):
            sail_fn = _resolve_function_spec("_sail_cli_main_module::fn")
            self.assertEqual(sail_fn.func.__module__, "__main__")

        # PATH.py::FN form.
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            script = Path(td) / "fn_target.py"
            script.write_text(body)
            sail_fn = _resolve_function_spec(f"{script}::fn")
            self.assertEqual(sail_fn.func.__module__, "__main__")

    def test_exec_function_file_import_time_filenotfound_is_not_script_missing(self):
        """A script that raises FileNotFoundError at import time (e.g.
        ``open("data.csv")`` at module top level) must report ``error
        executing`` — not ``file not found``, which would incorrectly point
        at the script."""
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            script = Path(td) / "opens_missing_file.py"
            missing = Path(td) / "does_not_exist.csv"
            script.write_text(f"open({str(missing)!r}).read()\n")
            with mock.patch(
                "sail.cli._sailbox._hydrate_for_exec",
                return_value=_StubFunctionSailbox(),
            ):
                with captured_io() as (_out, err):
                    rc = main(["box", "exec", "sb_test", f"{script}::fn"])
            self.assertEqual(rc, 2)
            stderr = err.getvalue()
            self.assertIn("error executing", stderr)
            self.assertNotIn("file not found", stderr)

    def test_exec_function_file_missing_script_reports_file_not_found(self):
        """When the script path itself doesn't exist, the CLI says ``file not
        found`` so the user fixes the path instead of guessing at an import
        error."""
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            missing_script = Path(td) / "no_such_script.py"
            with mock.patch(
                "sail.cli._sailbox._hydrate_for_exec",
                return_value=_StubFunctionSailbox(),
            ):
                with captured_io() as (_out, err):
                    rc = main(["box", "exec", "sb_test", f"{missing_script}::fn"])
            self.assertEqual(rc, 2)
            self.assertIn("file not found", err.getvalue())

    def test_exec_function_bad_sailbox_id_skips_module_import(self):
        """The CLI hydrates the sailbox record before resolving the function
        spec, so a typoed sailbox_id fails fast without running the user's
        module top-level code (which may have side effects)."""
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td:
            with isolated_home(Path(td)):
                sentinel = Path(td) / "imported.marker"
                script = Path(td) / "side_effecting.py"
                script.write_text(
                    "import sail\n"
                    "from pathlib import Path as _P\n"
                    f"_P({str(sentinel)!r}).write_text('ran')\n"
                    "@sail.function\n"
                    "def fn():\n"
                    "    return 1\n"
                )
                with captured_io() as (_out, err):
                    rc = main(["box", "exec", "sb_never_created", f"{script}::fn"])
                self.assertEqual(rc, 2)
                self.assertIn("no cached exec endpoint", err.getvalue())
                self.assertFalse(
                    sentinel.exists(),
                    "user module top-level code ran despite missing sailbox record",
                )

    def test_exec_function_invalid_argv_skips_module_import(self):
        """A duplicate kwarg is caught by argv parsing before the user
        module runs; the spec resolver (which executes user top-level code)
        is only reached after argv is known good."""
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td:
            with isolated_home(Path(td)):
                # Seed a valid sailbox record so hydration succeeds and we
                # actually reach the argv-vs-spec ordering check.
                save_sailbox_record(
                    SailboxRecord(
                        sailbox_id="sb_ok",
                        name="ok",
                        app_id="app_1",
                        exec_endpoint="exec.invalid:443",
                        worker_address="worker.invalid:443",
                    )
                )
                sentinel = Path(td) / "imported.marker"
                script = Path(td) / "side_effecting.py"
                script.write_text(
                    "import sail\n"
                    "from pathlib import Path as _P\n"
                    f"_P({str(sentinel)!r}).write_text('ran')\n"
                    "@sail.function\n"
                    "def fn():\n"
                    "    return 1\n"
                )
                with captured_io() as (_out, err):
                    rc = main(
                        [
                            "box",
                            "exec",
                            "sb_ok",
                            f"{script}::fn",
                            "x=1",
                            "x=2",
                        ]
                    )
                self.assertEqual(rc, 2)
                self.assertIn("duplicate keyword argument", err.getvalue())
                self.assertFalse(
                    sentinel.exists(),
                    "user module top-level code ran despite invalid argv",
                )

    def test_exec_function_arg_parsing_falls_back_to_string(self):
        """ast.literal_eval rejects ``some-host``; the CLI keeps it as a
        string. Same goes for kwargs values."""
        from sail.cli._function_spec import parse_function_args as _parse_function_args

        args, kwargs = _parse_function_args(("42", "'hi'", "[1,2]", "some-host"))
        self.assertEqual(args, [42, "hi", [1, 2], "some-host"])
        self.assertEqual(kwargs, {})

        args, kwargs = _parse_function_args(("host=some-host", "count=3"))
        self.assertEqual(args, [])
        self.assertEqual(kwargs, {"host": "some-host", "count": 3})

    def test_exec_function_token_with_non_identifier_key_is_positional(self):
        """``1=2`` isn't a kwarg — ``1`` isn't a valid identifier — so we keep
        the whole token positional (and as a string, since ``1=2`` isn't a
        literal). Without this, users couldn't pass ``key=value`` strings
        whose LHS starts with a digit."""
        from sail.cli._function_spec import parse_function_args as _parse_function_args

        args, kwargs = _parse_function_args(("1=2",))
        self.assertEqual(args, ["1=2"])
        self.assertEqual(kwargs, {})

    def test_exec_function_rejects_malformed_spec(self):
        """``pkg::`` and ``::fn`` reach the function dispatcher because they
        contain ``::``, but neither half is valid. The user-facing error
        names the expected shape so the fix is obvious."""
        from tempfile import TemporaryDirectory

        for bad_spec in ("pkg.module::", "::fn"):
            with self.subTest(spec=bad_spec):
                with TemporaryDirectory() as td, isolated_home(Path(td)):
                    with mock.patch(
                        "sail.cli._sailbox._hydrate_for_exec",
                        return_value=_StubFunctionSailbox(),
                    ):
                        with captured_io() as (out, err):
                            rc = main(["box", "exec", "sb_test", bad_spec])
                    self.assertEqual(rc, 2)
                    self.assertIn("MODULE::FN", err.getvalue())

    def test_exec_function_rejects_missing_module(self):
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            with mock.patch(
                "sail.cli._sailbox._hydrate_for_exec",
                return_value=_StubFunctionSailbox(),
            ):
                with captured_io() as (out, err):
                    rc = main(
                        [
                            "box",
                            "exec",
                            "sb_test",
                            "_does_not_exist_module::fn",
                        ]
                    )
            self.assertEqual(rc, 2)
            self.assertIn("could not import", err.getvalue())

    def test_exec_function_module_import_time_error_is_invalid_argument(self):
        """Module top-level execution can raise non-ImportError exceptions
        (RuntimeError, NameError, SyntaxError, …). Those map to
        invalid_argument with the user's exception type and message
        preserved so the error is debuggable from the CLI output alone."""
        body = 'raise RuntimeError("boom at import time")\n'
        with _module_in_cwd("_sail_cli_import_time_error", body):
            with mock.patch(
                "sail.cli._sailbox._hydrate_for_exec",
                return_value=_StubFunctionSailbox(),
            ):
                with captured_io() as (out, err):
                    rc = main(
                        [
                            "box",
                            "exec",
                            "sb_test",
                            "_sail_cli_import_time_error::fn",
                        ]
                    )
            self.assertEqual(rc, 2)
            stderr = err.getvalue()
            self.assertIn("error executing", stderr)
            self.assertIn("RuntimeError", stderr)
            self.assertIn("boom at import time", stderr)

    def test_exec_function_module_sys_exit_is_invalid_argument(self):
        """Top-level ``sys.exit()`` raises SystemExit (a BaseException, not
        Exception). Our catch folds it in so the CLI returns invalid_argument
        instead of dying with the script's chosen exit code."""
        body = "import sys\nsys.exit(7)\n"
        with _module_in_cwd("_sail_cli_sysexit_module", body):
            with mock.patch(
                "sail.cli._sailbox._hydrate_for_exec",
                return_value=_StubFunctionSailbox(),
            ):
                with captured_io() as (out, err):
                    rc = main(
                        [
                            "box",
                            "exec",
                            "sb_test",
                            "_sail_cli_sysexit_module::fn",
                        ]
                    )
            self.assertEqual(rc, 2)
            stderr = err.getvalue()
            self.assertIn("error executing", stderr)
            self.assertIn("SystemExit", stderr)

    def test_exec_function_file_sys_exit_is_invalid_argument(self):
        """Counterpart for the file-path branch: a script that calls
        ``sys.exit()`` at top level must produce invalid_argument, not kill
        the CLI process with the script's exit code."""
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            script = Path(td) / "exits_at_import.py"
            script.write_text("import sys\nsys.exit(7)\n")
            with mock.patch(
                "sail.cli._sailbox._hydrate_for_exec",
                return_value=_StubFunctionSailbox(),
            ):
                with captured_io() as (out, err):
                    rc = main(["box", "exec", "sb_test", f"{script}::fn"])
            self.assertEqual(rc, 2)
            self.assertIn("error executing", err.getvalue())

    def test_exec_function_rejects_missing_attribute(self):
        body = "import sail\n"  # no `missing` attribute
        with _module_in_cwd("_sail_cli_attr_missing", body):
            with mock.patch(
                "sail.cli._sailbox._hydrate_for_exec",
                return_value=_StubFunctionSailbox(),
            ):
                with captured_io() as (out, err):
                    rc = main(
                        [
                            "box",
                            "exec",
                            "sb_test",
                            "_sail_cli_attr_missing::missing",
                        ]
                    )
            self.assertEqual(rc, 2)
            self.assertIn("has no attribute", err.getvalue())

    def test_exec_function_rejects_undecorated_callable(self):
        """A plain function is callable but not a SailFunction; the CLI
        rejects with a hint at the decorator so the user doesn't have to
        decode the SDK's own error."""
        body = "def plain(x):\n    return x\n"
        with _module_in_cwd("_sail_cli_undecorated", body):
            with mock.patch(
                "sail.cli._sailbox._hydrate_for_exec",
                return_value=_StubFunctionSailbox(),
            ):
                with captured_io() as (out, err):
                    rc = main(
                        [
                            "box",
                            "exec",
                            "sb_test",
                            "_sail_cli_undecorated::plain",
                        ]
                    )
            self.assertEqual(rc, 2)
            self.assertIn("@sail.function", err.getvalue())

    def test_exec_function_rejects_background(self):
        """The SDK rejects ``background``+SailFunction with ValueError; the
        CLI catches it earlier with a message specific to the ``::`` form
        so users supplying a function spec don't have to decode a generic
        error."""
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            with captured_io() as (out, err):
                rc = main(
                    [
                        "box",
                        "exec",
                        "--background",
                        "sb_test",
                        "ignored::fn",
                    ]
                )
            self.assertEqual(rc, 2)
            self.assertIn("--background", err.getvalue())

    def test_exec_function_surfaces_remote_traceback(self):
        """SailboxFunctionError carries the remote traceback; the CLI prints
        it to stderr in text mode so users can debug without re-running
        with logs."""
        from sail.errors import SailboxFunctionError

        body = (
            "import sail\n"
            "@sail.function\n"
            "def boom():\n"
            "    raise RuntimeError('from inside')\n"
        )
        with _module_in_cwd("_sail_cli_remote_raise", body):
            stub = _StubFunctionSailbox(
                raise_exc=SailboxFunctionError(
                    "RuntimeError: from inside",
                    error_type="RuntimeError",
                    traceback="Traceback (most recent call last):\n  File ...\n",
                )
            )
            with mock.patch("sail.cli._sailbox._hydrate_for_exec", return_value=stub):
                with captured_io() as (out, err):
                    rc = main(
                        [
                            "box",
                            "exec",
                            "sb_test",
                            "_sail_cli_remote_raise::boom",
                        ]
                    )
            self.assertEqual(rc, 1)
            self.assertIn("RuntimeError: from inside", err.getvalue())
            self.assertIn("Traceback", err.getvalue())

    def test_exec_function_traceback_in_json_mode(self):
        """JSON mode pins a richer error envelope — error_type, traceback,
        stdout, stderr — under ``error`` so scripting clients can read
        structured failure context without parsing stderr text. This is the
        public contract for non-zero JSON output."""
        from sail.errors import SailboxFunctionError

        body = "import sail\n@sail.function\ndef fn():\n    return None\n"
        with _module_in_cwd("_sail_cli_json_err", body):
            stub = _StubFunctionSailbox(
                raise_exc=SailboxFunctionError(
                    "ZeroDivisionError: division by zero",
                    error_type="ZeroDivisionError",
                    traceback="Traceback (most recent call last):\n  ZeroDivision\n",
                    stdout="before crash\n",
                    stderr="warning\n",
                )
            )
            with mock.patch("sail.cli._sailbox._hydrate_for_exec", return_value=stub):
                with captured_io() as (out, err):
                    rc = main(
                        [
                            "--json",
                            "box",
                            "exec",
                            "sb_test",
                            "_sail_cli_json_err::fn",
                        ]
                    )
            self.assertEqual(rc, 1)
            payload = json.loads(out.getvalue())
            self.assertEqual(payload["error"]["code"], "function_error")
            self.assertIn("ZeroDivisionError", payload["error"]["message"])
            self.assertEqual(payload["error"]["error_type"], "ZeroDivisionError")
            self.assertIn("Traceback", payload["error"]["traceback"])
            self.assertEqual(payload["error"]["stdout"], "before crash\n")
            self.assertEqual(payload["error"]["stderr"], "warning\n")

    def test_exec_function_serialization_error_distinct_code(self):
        """Serialization failures (cloudpickle of payload or result) are an
        input-side problem, distinct from a remote raise — they get their
        own error code so scripting clients can branch on it."""
        from sail.errors import SailboxFunctionSerializationError

        body = "import sail\n@sail.function\ndef fn():\n    return None\n"
        with _module_in_cwd("_sail_cli_serr", body):
            stub = _StubFunctionSailbox(
                raise_exc=SailboxFunctionSerializationError(
                    "could not pickle result: <unpicklable>"
                )
            )
            with mock.patch("sail.cli._sailbox._hydrate_for_exec", return_value=stub):
                with captured_io() as (out, err):
                    rc = main(
                        [
                            "--json",
                            "box",
                            "exec",
                            "sb_test",
                            "_sail_cli_serr::fn",
                        ]
                    )
            self.assertEqual(rc, 1)
            payload = json.loads(out.getvalue())
            self.assertEqual(payload["error"]["code"], "serialization_error")
            self.assertIn("pickle", payload["error"]["message"])

    def test_exec_function_duplicate_kwarg_is_invalid_argument(self):
        body = "import sail\n@sail.function\ndef f(**kw):\n    return kw\n"
        with _module_in_cwd("_sail_cli_dup_kw", body):
            with mock.patch(
                "sail.cli._sailbox._hydrate_for_exec",
                return_value=_StubFunctionSailbox(),
            ):
                with captured_io() as (out, err):
                    rc = main(
                        [
                            "box",
                            "exec",
                            "sb_test",
                            "_sail_cli_dup_kw::f",
                            "x=1",
                            "x=2",
                        ]
                    )
            self.assertEqual(rc, 2)
            self.assertIn("duplicate", err.getvalue())

    def test_exec_shell_form_without_dash_dash(self):
        """The `--` separator is optional when shell args have no leading-dash
        tokens. Pins the public ergonomics of the shell form."""
        sb = _StubSailbox()
        with mock.patch("sail.cli._sailbox._hydrate_for_exec", return_value=sb):
            with captured_io() as (out, err):
                rc = main(["box", "exec", "sb_test", "echo", "hi"])
        self.assertEqual(rc, 0)
        assert sb.last_exec is not None
        self.assertEqual(sb.last_exec.command, "echo hi")

    def test_exec_shell_form_forwards_unknown_options(self):
        """`ignore_unknown_options` lets `--color=red`-style guest flags pass
        through without a `--` separator, so common shell-form invocations
        like `ls --color=auto` work."""
        sb = _StubSailbox()
        with mock.patch("sail.cli._sailbox._hydrate_for_exec", return_value=sb):
            with captured_io() as (out, err):
                rc = main(["box", "exec", "sb_test", "ls", "--color=auto", "/opt"])
        self.assertEqual(rc, 0)
        assert sb.last_exec is not None
        self.assertEqual(sb.last_exec.command, "ls --color=auto /opt")

    def test_exec_guest_json_flag_after_id_does_not_flip_output_mode(self):
        """`allow_interspersed_args=False` stops Click from parsing a guest
        `--json` after <sailbox_id> as sail's own global flag, so
        `sail box exec sb jq --json` forwards `--json` to the guest and
        leaves sail in text-output mode."""
        sb = _StubSailbox()
        with mock.patch("sail.cli._sailbox._hydrate_for_exec", return_value=sb):
            with captured_io() as (out, err):
                rc = main(["box", "exec", "sb_test", "jq", "--json"])
        self.assertEqual(rc, 0)
        assert sb.last_exec is not None
        self.assertEqual(sb.last_exec.command, "jq --json")
        # Text mode: stdout is not a JSON envelope.
        self.assertFalse(out.getvalue().lstrip().startswith("{"))

    def test_exec_shell_form_still_accepts_dash_dash(self):
        """`--` remains a valid end-of-options marker after the sailbox id.
        Click does not consume it under allow_interspersed_args=False, so
        the command body strips a leading `--` itself — otherwise the SDK
        would try to exec `--` as the guest program."""
        sb = _StubSailbox()
        with mock.patch("sail.cli._sailbox._hydrate_for_exec", return_value=sb):
            with captured_io() as (out, err):
                rc = main(["box", "exec", "sb_test", "--", "echo", "hi"])
        self.assertEqual(rc, 0)
        assert sb.last_exec is not None
        self.assertEqual(sb.last_exec.command, "echo hi")

    def test_exec_shell_form_preserves_known_options_after_command(self):
        """`allow_interspersed_args=False` stops Click from consuming our
        own --timeout/--cwd/--background after the guest command token.
        Without it, `sail box exec sb echo --timeout 30 hi` would silently
        strip `--timeout 30` and apply it as the CLI's own transport
        timeout — a footgun for any guest binary that happens to share
        flag names with us."""
        sb = _StubSailbox()
        with mock.patch("sail.cli._sailbox._hydrate_for_exec", return_value=sb):
            with captured_io() as (out, err):
                rc = main(
                    [
                        "box",
                        "exec",
                        "sb_test",
                        "echo",
                        "--timeout",
                        "30",
                        "hi",
                    ]
                )
        self.assertEqual(rc, 0, err.getvalue())
        assert sb.last_exec is not None
        # Guest receives the full args verbatim; CLI's own --timeout stays
        # unset (default None).
        self.assertEqual(sb.last_exec.command, "echo --timeout 30 hi")
        self.assertIsNone(sb.last_exec.timeout)

    def test_exec_shell_form_cli_options_before_sailbox_id(self):
        """--timeout / --cwd must appear BEFORE the sailbox id.
        `allow_interspersed_args=False` stops Click from consuming options
        past the first positional, so the documented invocation shape
        mirrors `python -m`/modal. The `command == "echo hi"` assertion is
        also a regression guard: the flags must bind to the CLI, not pass
        through to the guest as part of the remote command."""
        sb = _StubSailbox()
        with mock.patch("sail.cli._sailbox._hydrate_for_exec", return_value=sb):
            with captured_io() as (out, err):
                rc = main(
                    [
                        "box",
                        "exec",
                        "--timeout",
                        "30",
                        "--cwd",
                        "/work",
                        "sb_test",
                        "echo",
                        "hi",
                    ]
                )
        self.assertEqual(rc, 0, err.getvalue())
        assert sb.last_exec is not None
        self.assertEqual(sb.last_exec.timeout, 30)
        self.assertEqual(sb.last_exec.cwd, "/work")
        self.assertEqual(sb.last_exec.command, "echo hi")

    def test_create_rejects_invalid_cpu(self):
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            with mock.patch("sail.cli._sailbox.App.find") as find:
                with captured_io() as (out, err):
                    rc = main(
                        [
                            "box",
                            "create",
                            "--app",
                            "demo",
                            "--name",
                            "x",
                            "--cpu",
                            "0",
                        ]
                    )
            self.assertEqual(rc, 2)
            # Click's IntRange surfaces a UsageError before the leaf runs;
            # message format is `... is not in the range x>=1`.
            self.assertIn("range", err.getvalue())
            # Pre-validation must run before App.find — no stranded apps for
            # bad arg input.
            find.assert_not_called()

    def test_create_maps_sdk_valueerror_to_invalid_argument(self):
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            with mock.patch(
                "sail.cli._sailbox.App.find",
                return_value=mock.Mock(id="app_1", name="demo", created_at=0),
            ), mock.patch(
                "sail.cli._sailbox.Sailbox.create",
                side_effect=ValueError("name must be lowercase"),
            ):
                with captured_io() as (out, err):
                    rc = main(
                        [
                            "box",
                            "create",
                            "--app",
                            "demo",
                            "--name",
                            "BAD-NAME",
                        ]
                    )
            self.assertEqual(rc, 2)
            self.assertIn("name must be lowercase", err.getvalue())

    def test_create_warns_on_cache_write_failure_but_returns_zero(self):
        # If the sailbox is provisioned server-side but the local cache write
        # fails (unwritable SAIL_HOME, disk full), the CLI must still report
        # success — otherwise scripts retry and create duplicate VMs.
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            with mock.patch(
                "sail.cli._sailbox.App.find",
                return_value=mock.Mock(id="app_1", name="demo", created_at=0),
            ), mock.patch(
                "sail.cli._sailbox.Sailbox.create",
                return_value=_StubSailbox(),
            ), mock.patch(
                "sail.cli._sailbox.save_sailbox_record",
                side_effect=OSError("disk full"),
            ):
                with captured_io() as (out, err):
                    rc = main(
                        [
                            "box",
                            "create",
                            "--app",
                            "demo",
                            "--name",
                            "x",
                        ]
                    )
            self.assertEqual(rc, 0)
            self.assertIn("warning", err.getvalue())
            self.assertIn("disk full", err.getvalue())
            self.assertIn("sb_test", out.getvalue())

    def test_resume_refreshes_cached_exec_endpoint(self):
        # Resume can land the sailbox on a different worker. The CLI must
        # write the post-resume exec_endpoint back so subsequent
        # `sail box exec` dials the new workerproxy, not the stale one.
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            save_sailbox_record(
                SailboxRecord(
                    sailbox_id="sb_test",
                    name="x",
                    app_id="app_1",
                    exec_endpoint="old-worker:50052",
                )
            )
            stub = _StubSailbox()
            stub.status = "running"
            stub.exec_endpoint = "new-worker:50052"
            with mock.patch(
                "sail.cli._sailbox._hydrate_for_lifecycle",
                return_value=stub,
            ):
                with captured_io():
                    rc = main(["box", "resume", "sb_test"])
            self.assertEqual(rc, 0)
            record = load_sailbox_record("sb_test")
            assert record is not None
            self.assertEqual(record.exec_endpoint, "new-worker:50052")

    def test_resume_warns_on_cache_write_failure_but_returns_zero(self):
        # Same class of issue as the create path: backend resume already
        # succeeded, so a local cache update failure must not surface a
        # non-zero exit (or automation will retry resume on a live sailbox).
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            save_sailbox_record(
                SailboxRecord(
                    sailbox_id="sb_test",
                    name="x",
                    app_id="app_1",
                    exec_endpoint="ep",
                )
            )
            stub = _StubSailbox()
            stub.status = "running"
            with mock.patch(
                "sail.cli._sailbox._hydrate_for_lifecycle",
                return_value=stub,
            ), mock.patch(
                "sail.cli._sailbox.save_sailbox_record",
                side_effect=OSError("disk full"),
            ):
                with captured_io() as (out, err):
                    rc = main(["box", "resume", "sb_test"])
            self.assertEqual(rc, 0)
            self.assertIn("warning", err.getvalue())
            self.assertIn("disk full", err.getvalue())

    def test_terminate_warns_on_cache_delete_failure_but_returns_zero(self):
        # Same class of issue: backend terminate succeeded, so a local cache
        # cleanup failure (directory permission error, etc.) must not bubble
        # up as a non-zero exit. delete_sailbox_record() already tolerates
        # FileNotFoundError; this covers the rest.
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            save_sailbox_record(
                SailboxRecord(
                    sailbox_id="sb_test",
                    name="x",
                    app_id="app_1",
                    exec_endpoint="ep",
                )
            )
            with mock.patch(
                "sail.cli._sailbox._hydrate_for_lifecycle",
                return_value=_StubSailbox(),
            ), mock.patch(
                "sail.cli._sailbox.delete_sailbox_record",
                side_effect=OSError("permission denied"),
            ):
                with captured_io() as (out, err):
                    rc = main(["box", "terminate", "sb_test"])
            self.assertEqual(rc, 0)
            self.assertIn("warning", err.getvalue())
            self.assertIn("permission denied", err.getvalue())

    def test_terminate_removes_record(self):
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            save_sailbox_record(
                SailboxRecord(
                    sailbox_id="sb_test",
                    name="x",
                    app_id="app_1",
                    exec_endpoint="ep",
                )
            )
            with mock.patch(
                "sail.cli._sailbox._hydrate_for_lifecycle",
                return_value=_StubSailbox(),
            ):
                with captured_io():
                    rc = main(["box", "terminate", "sb_test"])
            self.assertEqual(rc, 0)
            self.assertIsNone(load_sailbox_record("sb_test"))

    def test_unimplemented_subcommands_are_not_registered(self):
        for sub in ("shell", "ssh", "cp", "sync"):
            with captured_io() as (out, err):
                rc = main(["box", sub])
            self.assertEqual(rc, 2, f"`box {sub}` should be unknown")
            self.assertIn("No such command", err.getvalue())

    def test_old_sailbox_group_name_is_rejected(self):
        # Pin the hard-rename contract: `sail sailbox <verb>` must fail. If a
        # future change adds a `sailbox` alias for muscle memory, this test
        # should be the thing that forces the conversation about whether the
        # alias is intentional, not a silent regression.
        with captured_io() as (out, err):
            rc = main(["sailbox", "--help"])
        self.assertEqual(rc, 2)
        self.assertIn("No such command 'sailbox'", err.getvalue())

    def test_list_text_renders_table(self):
        from tempfile import TemporaryDirectory

        envelope = {
            "data": [
                {
                    "sailbox_id": "sb-aaa",
                    "app_id": "app_1",
                    "app_name": "demo",
                    "name": "alpha",
                    "status": "running",
                    "memory_mib": 2048,
                    "vcpu_count": 2,
                    "state_disk_size_gib": 8,
                    "architecture": "arm64",
                    "error_message": None,
                    "started_at": None,
                    "created_at": "2026-05-11T00:00:00Z",
                    "updated_at": "2026-05-11T00:00:00Z",
                }
            ],
            "limit": 50,
            "offset": 0,
            "total": 1,
            "has_more": False,
        }
        client = mock.Mock()
        client.get.return_value = (200, envelope)
        with TemporaryDirectory() as td, isolated_home(Path(td)):
            with mock.patch("sail.sailbox.HTTPClient.instance", return_value=client):
                with captured_io() as (out, err):
                    rc = main(["box", "list"])
        self.assertEqual(rc, 0)
        text = out.getvalue()
        self.assertIn("SAILBOX_ID", text)
        self.assertIn("sb-aaa", text)
        self.assertIn("alpha", text)
        self.assertIn("demo", text)
        self.assertIn("2g", text)
        # Query forwarded with defaults only.
        call = client.get.call_args
        self.assertEqual(call.args[0], "/v1/sailboxes")
        self.assertEqual(call.kwargs["query"], {"limit": 50, "offset": 0})

    def test_list_json_emits_full_envelope(self):
        from tempfile import TemporaryDirectory

        envelope = {
            "data": [],
            "limit": 25,
            "offset": 10,
            "total": 0,
            "has_more": False,
        }
        client = mock.Mock()
        client.get.return_value = (200, envelope)
        with TemporaryDirectory() as td, isolated_home(Path(td)):
            with mock.patch("sail.sailbox.HTTPClient.instance", return_value=client):
                with captured_io() as (out, err):
                    rc = main(
                        [
                            "--json",
                            "box",
                            "list",
                            "--limit",
                            "25",
                            "--offset",
                            "10",
                        ]
                    )
        self.assertEqual(rc, 0)
        payload = json.loads(out.getvalue())
        # JSON output mirrors the server envelope unchanged so scripts can
        # consume total/has_more for paging.
        self.assertEqual(payload, envelope)

    def test_list_resolves_app_name_via_app_find(self):
        from tempfile import TemporaryDirectory

        envelope = {
            "data": [],
            "limit": 50,
            "offset": 0,
            "total": 0,
            "has_more": False,
        }
        client = mock.Mock()
        client.get.return_value = (200, envelope)
        with TemporaryDirectory() as td, isolated_home(Path(td)):
            with mock.patch(
                "sail.cli._sailbox.App.find",
                return_value=mock.Mock(id="app_resolved", name="demo"),
            ), mock.patch("sail.sailbox.HTTPClient.instance", return_value=client):
                with captured_io():
                    rc = main(
                        [
                            "box",
                            "list",
                            "--app",
                            "demo",
                            "--status",
                            "running",
                        ]
                    )
        self.assertEqual(rc, 0)
        # CLI converts the friendly --app NAME into the server's app_id filter
        # so users never have to know the opaque app_xxx id.
        self.assertEqual(
            client.get.call_args.kwargs["query"],
            {"limit": 50, "offset": 0, "app": "app_resolved", "status": "running"},
        )

    def test_list_returns_empty_envelope_when_app_name_unknown(self):
        from tempfile import TemporaryDirectory

        client = mock.Mock()
        with TemporaryDirectory() as td, isolated_home(Path(td)):
            with mock.patch(
                "sail.cli._sailbox.App.find", side_effect=LookupError("missing")
            ), mock.patch("sail.sailbox.HTTPClient.instance", return_value=client):
                with captured_io() as (out, err):
                    rc = main(["--json", "box", "list", "--app", "ghost"])
        # Unknown app == zero sailboxes; the CLI emits an empty envelope so
        # scripts get a consistent shape instead of a 404 propagated as exit 1.
        self.assertEqual(rc, 0)
        client.get.assert_not_called()
        payload = json.loads(out.getvalue())
        self.assertEqual(payload["data"], [])
        self.assertEqual(payload["total"], 0)

    def test_list_forbidden_returns_exit_1(self):
        from tempfile import TemporaryDirectory

        client = mock.Mock()
        client.get.return_value = (
            403,
            {"error": {"message": "sailboxes require an organization-scoped API key"}},
        )
        with TemporaryDirectory() as td, isolated_home(Path(td)):
            with mock.patch("sail.sailbox.HTTPClient.instance", return_value=client):
                with captured_io() as (out, err):
                    rc = main(["box", "list"])
        self.assertEqual(rc, 1)
        self.assertIn("organization-scoped", err.getvalue())

    def test_list_unauthorized_returns_exit_1(self):
        # 401 (missing/invalid key, from PublicAuth) must hit the same
        # auth-error path as 403, not fall through to the generic 4xx
        # "server_error" bucket.
        from tempfile import TemporaryDirectory

        client = mock.Mock()
        client.get.return_value = (
            401,
            {"error": {"message": "Missing or invalid Authorization header"}},
        )
        with TemporaryDirectory() as td, isolated_home(Path(td)):
            with mock.patch("sail.sailbox.HTTPClient.instance", return_value=client):
                with captured_io() as (out, err):
                    rc = main(["box", "list"])
        self.assertEqual(rc, 1)
        self.assertIn("Authorization", err.getvalue())

    def test_list_app_lookup_auth_failure_returns_exit_1(self):
        # If --app NAME is given and App.find raises PermissionError (401/403
        # from /v1/apps/find), the CLI must surface it through the same
        # permission_denied path used for /v1/sailboxes — not let the
        # RuntimeError-shaped fallback leak through Click's top-level handler.
        from tempfile import TemporaryDirectory

        client = mock.Mock()
        with TemporaryDirectory() as td, isolated_home(Path(td)):
            with mock.patch(
                "sail.cli._sailbox.App.find",
                side_effect=PermissionError("Failed to find app: missing api key"),
            ), mock.patch("sail.sailbox.HTTPClient.instance", return_value=client):
                with captured_io() as (out, err):
                    rc = main(["--json", "box", "list", "--app", "demo"])
        self.assertEqual(rc, 1)
        client.get.assert_not_called()
        payload = json.loads(out.getvalue())
        self.assertEqual(payload["error"]["code"], "permission_denied")
        self.assertIn("missing api key", payload["error"]["message"])
        self.assertIn("missing api key", err.getvalue())

    def test_list_bad_request_returns_exit_2_invalid_argument(self):
        # The backend returns 400 for out-of-range pagination params (e.g.
        # --offset above 100000) since the CLI option only enforces min=0.
        # The CLI must surface that as invalid_argument / exit 2 to match
        # `sail box show` and the SDK, so automation doesn't retry a
        # non-retriable input bug as a transient backend failure.
        from tempfile import TemporaryDirectory

        client = mock.Mock()
        client.get.return_value = (
            400,
            {"error": {"message": "offset must be <= 100000"}},
        )
        with TemporaryDirectory() as td, isolated_home(Path(td)):
            with mock.patch("sail.sailbox.HTTPClient.instance", return_value=client):
                with captured_io() as (out, err):
                    rc = main(["--json", "box", "list", "--offset", "200000"])
        self.assertEqual(rc, 2)
        payload = json.loads(out.getvalue())
        self.assertEqual(payload["error"]["code"], "invalid_argument")
        self.assertIn("offset must be <= 100000", payload["error"]["message"])
        self.assertIn("offset must be <= 100000", err.getvalue())

    def test_show_text_renders_key_value_block(self):
        from tempfile import TemporaryDirectory

        item = {
            "sailbox_id": "sb-aaa",
            "app_id": "app_1",
            "app_name": "demo",
            "name": "alpha",
            "status": "running",
            "memory_mib": 2048,
            "vcpu_count": 2,
            "state_disk_size_gib": 16,
            "architecture": "arm64",
            "error_message": None,
            "started_at": "2026-05-11T00:00:00Z",
            "created_at": "2026-05-11T00:00:00Z",
            "updated_at": "2026-05-11T00:01:00Z",
        }
        client = mock.Mock()
        client.get.return_value = (200, item)
        with TemporaryDirectory() as td, isolated_home(Path(td)):
            with mock.patch("sail.sailbox.HTTPClient.instance", return_value=client):
                with captured_io() as (out, err):
                    rc = main(["box", "show", "sb-aaa"])
        self.assertEqual(rc, 0)
        text = out.getvalue()
        self.assertIn("sailbox_id:", text)
        self.assertIn("sb-aaa", text)
        self.assertIn("alpha", text)
        self.assertIn("demo (app_1)", text)
        self.assertIn("2g", text)
        self.assertEqual(client.get.call_args.args[0], "/v1/sailboxes/sb-aaa")

    def test_show_json_emits_bare_item(self):
        from tempfile import TemporaryDirectory

        item = {
            "sailbox_id": "sb-aaa",
            "app_id": "app_1",
            "app_name": "demo",
            "name": "alpha",
            "status": "running",
            "memory_mib": 1024,
            "vcpu_count": 1,
            "state_disk_size_gib": 8,
            "architecture": "arm64",
            "error_message": None,
            "started_at": None,
            "created_at": "2026-05-11T00:00:00Z",
            "updated_at": "2026-05-11T00:00:00Z",
        }
        client = mock.Mock()
        client.get.return_value = (200, item)
        with TemporaryDirectory() as td, isolated_home(Path(td)):
            with mock.patch("sail.sailbox.HTTPClient.instance", return_value=client):
                with captured_io() as (out, err):
                    rc = main(["--json", "box", "show", "sb-aaa"])
        self.assertEqual(rc, 0)
        payload = json.loads(out.getvalue())
        # JSON output mirrors the server's bare item (not a list envelope) so
        # scripts can `jq .sailbox_id` directly.
        self.assertEqual(payload, item)

    def test_show_not_found_returns_exit_1(self):
        from tempfile import TemporaryDirectory

        client = mock.Mock()
        client.get.return_value = (
            404,
            {"error": {"message": "sailbox not found"}},
        )
        with TemporaryDirectory() as td, isolated_home(Path(td)):
            with mock.patch("sail.sailbox.HTTPClient.instance", return_value=client):
                with captured_io() as (out, err):
                    rc = main(["box", "show", "sb-missing"])
        self.assertEqual(rc, 1)
        self.assertIn("sailbox not found", err.getvalue())

    def test_show_unauthorized_returns_exit_1(self):
        from tempfile import TemporaryDirectory

        client = mock.Mock()
        client.get.return_value = (
            401,
            {"error": {"message": "Missing or invalid Authorization header"}},
        )
        with TemporaryDirectory() as td, isolated_home(Path(td)):
            with mock.patch("sail.sailbox.HTTPClient.instance", return_value=client):
                with captured_io() as (out, err):
                    rc = main(["box", "show", "sb-anything"])
        self.assertEqual(rc, 1)
        self.assertIn("Authorization", err.getvalue())

    def test_show_malformed_id_returns_exit_2_invalid_argument(self):
        # Backend returns 400 for malformed sailbox IDs. The CLI must route
        # that through invalid_argument / exit 2 (matching the rest of
        # `sail box`'s input-error contract) instead of the generic
        # server_error / exit 1 bucket — otherwise automation retries a
        # non-retriable input bug as a transient backend failure.
        from tempfile import TemporaryDirectory

        client = mock.Mock()
        client.get.return_value = (
            400,
            {"error": {"message": "invalid sailbox id: missing sb_ prefix"}},
        )
        with TemporaryDirectory() as td, isolated_home(Path(td)):
            with mock.patch("sail.sailbox.HTTPClient.instance", return_value=client):
                with captured_io() as (out, err):
                    rc = main(["--json", "box", "show", "not-a-real-id"])
        self.assertEqual(rc, 2)
        payload = json.loads(out.getvalue())
        self.assertEqual(payload["error"]["code"], "invalid_argument")
        self.assertIn("missing sb_ prefix", payload["error"]["message"])
        self.assertIn("missing sb_ prefix", err.getvalue())


# ----------------------------------------------------------- `sail box run`


class TestRun(unittest.TestCase):
    """Tests for `sail box run MODULE::FN` — the ephemeral one-shot wrapper that
    creates a sailbox, execs a function, and terminates in ``finally``. Shape
    mirrors ``TestSailbox.test_exec_function_*`` but additionally asserts the
    create / terminate lifecycle. Patches target ``sail.cli._run.*`` rather
    than ``sail.cli._sailbox.*`` because ``_run`` imports the SDK directly."""

    @contextmanager
    def _patched_run(self, *, result=None, raise_exc=None):
        """Patch the SDK seams used by `sail box run` and yield (sb_stub, create,
        find, app). `sb_stub.terminate` is pre-stubbed as a Mock; tests that
        need it to fail set `sb_stub.terminate.side_effect`."""
        stub = _StubFunctionSailbox(result=result, raise_exc=raise_exc)
        stub.terminate = mock.Mock()
        # Mock(name=...) sets the mock's debug name, not the `.name`
        # attribute the leaf reads. Assign after construction.
        app = mock.Mock(id="app_1", created_at=0)
        app.name = "demo"
        with mock.patch(
            "sail.cli._run.Sailbox.create", return_value=stub
        ) as create, mock.patch("sail.cli._run.App.find", return_value=app) as find:
            yield stub, create, find, app

    def test_run_happy_path_creates_execs_and_terminates(self):
        body = (
            "import sail\n"
            "@sail.function\n"
            "def summarize(vals, label='default'):\n"
            "    return {'count': len(vals), 'label': label}\n"
        )
        with _module_in_cwd("_sail_run_happy", body):
            with self._patched_run(result={"count": 3, "label": "demo"}) as (
                stub,
                create,
                find,
                app,
            ):
                with captured_io() as (out, err):
                    rc = main(
                        [
                            "--json",
                            "box",
                            "run",
                            "--app",
                            "demo",
                            "_sail_run_happy::summarize",
                            "[1, 2, 3]",
                            "label=demo",
                        ]
                    )
            self.assertEqual(rc, 0, err.getvalue())
            from sail.function import SailFunction

            create.assert_called_once()
            self.assertIsInstance(stub.last_function, SailFunction)
            self.assertEqual(stub.last_args, ([1, 2, 3],))
            self.assertEqual(stub.last_kwargs, {"label": "demo"})
            stub.terminate.assert_called_once()
            payload = json.loads(out.getvalue())
            self.assertEqual(payload["sailbox_id"], "sb_test")
            self.assertEqual(payload["name"], "test-box")
            self.assertEqual(payload["app"], "demo")
            self.assertEqual(payload["app_id"], "app_1")
            self.assertEqual(payload["result"], {"count": 3, "label": "demo"})
            self.assertEqual(payload["kept"], False)

    def test_run_autogenerated_name_uses_run_prefix(self):
        body = "import sail\n@sail.function\ndef fn():\n    return 'ok'\n"
        with _module_in_cwd("_sail_run_autoname", body):
            with self._patched_run(result="ok") as (stub, create, find, app):
                with captured_io():
                    rc = main(["box", "run", "--app", "demo", "_sail_run_autoname::fn"])
            self.assertEqual(rc, 0)
            name = create.call_args.kwargs["name"]
            self.assertRegex(name, r"^run-[0-9a-f]{8}$")

    def test_run_name_override_is_passed_through(self):
        body = "import sail\n@sail.function\ndef fn():\n    return 'ok'\n"
        with _module_in_cwd("_sail_run_named", body):
            with self._patched_run(result="ok") as (stub, create, find, app):
                with captured_io():
                    rc = main(
                        [
                            "box",
                            "run",
                            "--app",
                            "demo",
                            "--name",
                            "my-explicit-name",
                            "_sail_run_named::fn",
                        ]
                    )
            self.assertEqual(rc, 0)
            self.assertEqual(create.call_args.kwargs["name"], "my-explicit-name")

    def test_run_app_find_mints_if_missing(self):
        body = "import sail\n@sail.function\ndef fn():\n    return 'ok'\n"
        with _module_in_cwd("_sail_run_mint", body):
            with self._patched_run(result="ok") as (stub, create, find, app):
                with captured_io():
                    rc = main(["box", "run", "--app", "demo", "_sail_run_mint::fn"])
            self.assertEqual(rc, 0)
            find.assert_called_once()
            kwargs = find.call_args.kwargs
            self.assertEqual(kwargs["name"], "demo")
            self.assertTrue(kwargs["mint_if_missing"])

    def test_run_keep_skips_terminate_and_warns(self):
        body = "import sail\n@sail.function\ndef fn():\n    return 'ok'\n"
        with _module_in_cwd("_sail_run_keep", body):
            with self._patched_run(result="ok") as (stub, create, find, app):
                with captured_io() as (out, err):
                    rc = main(
                        ["box", "run", "--app", "demo", "--keep", "_sail_run_keep::fn"]
                    )
            self.assertEqual(rc, 0)
            stub.terminate.assert_not_called()
            # text-mode keep notice goes to stderr.
            self.assertIn("kept", err.getvalue().lower())
            self.assertIn("sb_test", err.getvalue())

    def test_run_function_error_still_terminates(self):
        from sail.errors import SailboxFunctionError

        body = "import sail\n@sail.function\ndef fn():\n    raise ValueError('boom')\n"
        with _module_in_cwd("_sail_run_fnerr", body):
            exc = SailboxFunctionError(
                "boom",
                error_type="ValueError",
                traceback="Traceback (most recent call last):\n  ...\nValueError: boom\n",
                stdout="",
                stderr="",
            )
            with self._patched_run(raise_exc=exc) as (stub, create, find, app):
                with captured_io() as (out, err):
                    rc = main(
                        ["--json", "box", "run", "--app", "demo", "_sail_run_fnerr::fn"]
                    )
            self.assertEqual(rc, 1)
            stub.terminate.assert_called_once()
            payload = json.loads(out.getvalue())
            self.assertEqual(payload["error"]["code"], "function_error")
            self.assertEqual(payload["error"]["error_type"], "ValueError")

    def test_run_serialization_error_has_distinct_code(self):
        from sail.errors import SailboxFunctionSerializationError

        body = "import sail\n@sail.function\ndef fn():\n    return 'ok'\n"
        with _module_in_cwd("_sail_run_serr", body):
            with self._patched_run(
                raise_exc=SailboxFunctionSerializationError("cannot pickle")
            ) as (stub, create, find, app):
                with captured_io() as (out, err):
                    rc = main(
                        ["--json", "box", "run", "--app", "demo", "_sail_run_serr::fn"]
                    )
            self.assertEqual(rc, 1)
            stub.terminate.assert_called_once()
            payload = json.loads(out.getvalue())
            self.assertEqual(payload["error"]["code"], "serialization_error")

    def test_run_bad_spec_does_not_create_sailbox(self):
        with self._patched_run(result=None) as (stub, create, find, app):
            with captured_io() as (out, err):
                rc = main(
                    [
                        "--json",
                        "box",
                        "run",
                        "--app",
                        "demo",
                        "no_such_module_for_sail_run::fn",
                    ]
                )
        self.assertEqual(rc, 2)
        # Resolve runs before create; a bad spec must not allocate compute.
        create.assert_not_called()
        find.assert_not_called()
        payload = json.loads(out.getvalue())
        self.assertEqual(payload["error"]["code"], "invalid_argument")
        self.assertIn("no_such_module_for_sail_run", payload["error"]["message"])

    def test_run_bad_memory_does_not_resolve_or_create(self):
        with self._patched_run(result=None) as (stub, create, find, app):
            with captured_io() as (out, err):
                rc = main(
                    [
                        "box",
                        "run",
                        "--app",
                        "demo",
                        "--memory",
                        "oops",
                        "any.module::fn",
                    ]
                )
        self.assertEqual(rc, 2)
        create.assert_not_called()
        # Even App.find shouldn't have been called — we error before that.
        find.assert_not_called()
        self.assertIn("memory", err.getvalue().lower())

    def test_run_duplicate_kwargs_do_not_resolve_or_create(self):
        marker = "imported-marker"
        body = (
            "from pathlib import Path\n"
            f"Path({marker!r}).write_text('imported')\n"
            "import sail\n"
            "@sail.function\n"
            "def fn(*, x):\n"
            "    return x\n"
        )
        with _module_in_cwd("_sail_run_dup_kwargs_no_import", body) as td:
            with self._patched_run(result=None) as (stub, create, find, app):
                with captured_io() as (out, err):
                    rc = main(
                        [
                            "box",
                            "run",
                            "--app",
                            "demo",
                            "_sail_run_dup_kwargs_no_import::fn",
                            "x=1",
                            "x=2",
                        ]
                    )
            self.assertEqual(rc, 2)
            self.assertFalse((td / marker).exists())
            create.assert_not_called()
            find.assert_not_called()
            self.assertIn("duplicate keyword argument", err.getvalue())

    def test_run_bad_timeout_does_not_resolve_or_create(self):
        marker = "imported-marker"
        body = (
            "from pathlib import Path\n"
            f"Path({marker!r}).write_text('imported')\n"
            "import sail\n"
            "@sail.function\n"
            "def fn():\n"
            "    return 'ok'\n"
        )
        with _module_in_cwd("_sail_run_bad_timeout_no_import", body) as td:
            with self._patched_run(result=None) as (stub, create, find, app):
                with captured_io() as (out, err):
                    rc = main(
                        [
                            "box",
                            "run",
                            "--app",
                            "demo",
                            "--timeout",
                            "0",
                            "_sail_run_bad_timeout_no_import::fn",
                        ]
                    )
            self.assertEqual(rc, 2)
            self.assertFalse((td / marker).exists())
            create.assert_not_called()
            find.assert_not_called()
            self.assertIn("timeout must be greater than 0", err.getvalue())

    def test_run_empty_cwd_does_not_resolve_or_create(self):
        marker = "imported-marker"
        body = (
            "from pathlib import Path\n"
            f"Path({marker!r}).write_text('imported')\n"
            "import sail\n"
            "@sail.function\n"
            "def fn():\n"
            "    return 'ok'\n"
        )
        with _module_in_cwd("_sail_run_empty_cwd_no_import", body) as td:
            with self._patched_run(result=None) as (stub, create, find, app):
                with captured_io() as (out, err):
                    rc = main(
                        [
                            "box",
                            "run",
                            "--app",
                            "demo",
                            "--cwd",
                            "",
                            "_sail_run_empty_cwd_no_import::fn",
                        ]
                    )
            self.assertEqual(rc, 2)
            self.assertFalse((td / marker).exists())
            create.assert_not_called()
            find.assert_not_called()
            self.assertIn("cwd must be non-empty", err.getvalue())

    def test_run_malformed_config_returns_structured_error(self):
        # `box run` is an operational command: it folds persisted config into
        # the environment via apply_config_or_exit() before any SDK call. A
        # malformed config.toml exits 2 with a `config reset` hint, and the
        # box is never resolved or created.
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            config_path().parent.mkdir(parents=True, exist_ok=True)
            config_path().write_text("not = valid = toml\n[oops")
            with self._patched_run(result=None) as (stub, create, find, app):
                with captured_io() as (out, err):
                    rc = main(["box", "run", "--app", "demo", "any.module::fn"])
        self.assertEqual(rc, 2)
        self.assertIn("sail config reset", err.getvalue())
        find.assert_not_called()
        create.assert_not_called()

    def test_run_double_dash_before_spec_is_consumed(self):
        """`sail box run -- script.py::fn arg` is the explicit-end-of-options form.
        With ``allow_interspersed_args=False`` Click leaves the `--` separator in
        ``argv`` rather than consuming it; the leaf strips a leading `--` so the
        spec is still the first real token."""
        body = "import sail\n@sail.function\ndef fn(x):\n    return x * 2\n"
        with _module_in_cwd("_sail_run_dashdash", body):
            with self._patched_run(result=84) as (stub, create, find, app):
                with captured_io() as (out, err):
                    rc = main(
                        [
                            "box",
                            "run",
                            "--app",
                            "demo",
                            "--",
                            "_sail_run_dashdash::fn",
                            "42",
                        ]
                    )
            self.assertEqual(rc, 0, err.getvalue())
            self.assertEqual(stub.last_args, (42,))

    def test_run_missing_spec_returns_structured_error(self):
        # `box run --app demo` with no MODULE::FN tail: the leaf emits its own
        # invalid_argument / exit 2 rather than letting Click report a generic
        # usage error, so --json automation gets a structured envelope.
        with self._patched_run(result=None) as (stub, create, find, app):
            with captured_io() as (out, err):
                rc = main(["--json", "box", "run", "--app", "demo"])
        self.assertEqual(rc, 2)
        create.assert_not_called()
        find.assert_not_called()
        payload = json.loads(out.getvalue())
        self.assertEqual(payload["error"]["code"], "invalid_argument")
        self.assertIn("function spec", payload["error"]["message"])

    def test_run_text_mode_writes_result_to_stdout(self):
        body = "import sail\n@sail.function\ndef fn():\n    return {'a': 1, 'b': 2}\n"
        with _module_in_cwd("_sail_run_text", body):
            with self._patched_run(result={"a": 1, "b": 2}) as (
                stub,
                create,
                find,
                app,
            ):
                with captured_io() as (out, err):
                    rc = main(["box", "run", "--app", "demo", "_sail_run_text::fn"])
            self.assertEqual(rc, 0)
            # Text mode renders the result to stdout (not a JSON envelope);
            # both keys appear and stdout is not JSON.
            self.assertIn("'a': 1", out.getvalue())
            self.assertIn("'b': 2", out.getvalue())

    def test_run_terminate_failure_emits_stderr_warning(self):
        body = "import sail\n@sail.function\ndef fn():\n    return 'ok'\n"
        with _module_in_cwd("_sail_run_termfail", body):
            with self._patched_run(result="ok") as (stub, create, find, app):
                stub.terminate.side_effect = RuntimeError("nope")
                with captured_io() as (out, err):
                    rc = main(["box", "run", "--app", "demo", "_sail_run_termfail::fn"])
            # Exec succeeded so rc is still 0; terminate failure is a warning.
            self.assertEqual(rc, 0)
            self.assertIn("failed to terminate", err.getvalue())
            self.assertIn("sb_test", err.getvalue())
            # The result still has to print — a terminate failure must not
            # swallow what the user actually came here for.
            self.assertIn("'ok'", out.getvalue())

    def test_run_terminate_failure_marks_kept_true_in_json(self):
        """When terminate fails on the success path, the sailbox is alive
        even though the user didn't pass --keep. `kept` must reflect actual
        state so --json consumers don't assume cleanup happened."""
        body = "import sail\n@sail.function\ndef fn():\n    return 'ok'\n"
        with _module_in_cwd("_sail_run_termfail_json", body):
            with self._patched_run(result="ok") as (stub, create, find, app):
                stub.terminate.side_effect = RuntimeError("nope")
                with captured_io() as (out, err):
                    rc = main(
                        [
                            "--json",
                            "box",
                            "run",
                            "--app",
                            "demo",
                            "_sail_run_termfail_json::fn",
                        ]
                    )
            self.assertEqual(rc, 0)
            payload = json.loads(out.getvalue())
            self.assertEqual(payload["kept"], True)
            self.assertEqual(payload["result"], "ok")

    def test_run_exec_and_terminate_both_fail_surfaces_kept_sailbox(self):
        """When exec fails and terminate also fails (no --keep), the box is
        still alive. The JSON error envelope must carry `sailbox_id`/`kept` so
        automation reading only stdout can find and clean up the leaked box."""
        from sail.errors import SailboxExecutionError

        body = "import sail\n@sail.function\ndef fn():\n    return 'ok'\n"
        with _module_in_cwd("_sail_run_both_fail", body):
            with self._patched_run(raise_exc=SailboxExecutionError("worker gone")) as (
                stub,
                create,
                find,
                app,
            ):
                stub.terminate.side_effect = RuntimeError("nope")
                with captured_io() as (out, err):
                    rc = main(
                        [
                            "--json",
                            "box",
                            "run",
                            "--app",
                            "demo",
                            "_sail_run_both_fail::fn",
                        ]
                    )
            self.assertEqual(rc, 1)
            payload = json.loads(out.getvalue())
            self.assertEqual(payload["error"]["code"], "execution_error")
            self.assertEqual(payload["error"]["sailbox_id"], "sb_test")
            self.assertEqual(payload["error"]["kept"], True)

    def test_run_exec_fails_clean_terminate_omits_kept_metadata(self):
        """The flip side: exec fails but terminate succeeds, so the box is
        gone. The error envelope must NOT claim a still-running sailbox."""
        from sail.errors import SailboxExecutionError

        body = "import sail\n@sail.function\ndef fn():\n    return 'ok'\n"
        with _module_in_cwd("_sail_run_clean_term", body):
            with self._patched_run(raise_exc=SailboxExecutionError("worker gone")) as (
                stub,
                create,
                find,
                app,
            ):
                with captured_io() as (out, err):
                    rc = main(
                        [
                            "--json",
                            "box",
                            "run",
                            "--app",
                            "demo",
                            "_sail_run_clean_term::fn",
                        ]
                    )
            self.assertEqual(rc, 1)
            payload = json.loads(out.getvalue())
            self.assertEqual(payload["error"]["code"], "execution_error")
            self.assertNotIn("sailbox_id", payload["error"])
            self.assertNotIn("kept", payload["error"])

    def test_run_sailbox_creation_error_surfaces_creation_error_code(self):
        from sail.errors import SailboxCreationError

        body = "import sail\n@sail.function\ndef fn():\n    return 'ok'\n"
        with _module_in_cwd("_sail_run_create_err", body):
            app = mock.Mock(id="app_1", created_at=0)
            app.name = "demo"
            with mock.patch(
                "sail.cli._run.Sailbox.create",
                side_effect=SailboxCreationError("scheduler refused"),
            ) as create, mock.patch("sail.cli._run.App.find", return_value=app):
                with captured_io() as (out, err):
                    rc = main(
                        [
                            "--json",
                            "box",
                            "run",
                            "--app",
                            "demo",
                            "_sail_run_create_err::fn",
                        ]
                    )
            self.assertEqual(rc, 1)
            create.assert_called_once()
            payload = json.loads(out.getvalue())
            self.assertEqual(payload["error"]["code"], "creation_error")
            self.assertIn("scheduler refused", payload["error"]["message"])

    def test_run_keep_with_function_error_surfaces_kept_sailbox(self):
        """--keep means the sailbox outlives a function error on purpose. The
        error envelope and stderr have to identify it; otherwise the only path
        forward — attach a debugger, `sail box exec`, or terminate manually —
        becomes guesswork."""
        from sail.errors import SailboxFunctionError

        body = "import sail\n@sail.function\ndef fn():\n    raise ValueError('boom')\n"
        with _module_in_cwd("_sail_run_keep_err", body):
            exc = SailboxFunctionError(
                "boom",
                error_type="ValueError",
                traceback="Traceback ...\nValueError: boom\n",
                stdout="",
                stderr="",
            )
            with self._patched_run(raise_exc=exc) as (stub, create, find, app):
                with captured_io() as (out, err):
                    rc = main(
                        [
                            "--json",
                            "box",
                            "run",
                            "--app",
                            "demo",
                            "--keep",
                            "_sail_run_keep_err::fn",
                        ]
                    )
            self.assertEqual(rc, 1)
            stub.terminate.assert_not_called()
            payload = json.loads(out.getvalue())
            self.assertEqual(payload["error"]["code"], "function_error")
            self.assertEqual(payload["error"]["sailbox_id"], "sb_test")
            self.assertEqual(payload["error"]["kept"], True)
            self.assertEqual(payload["error"]["app"], "demo")

    def test_run_keep_persists_sailbox_record_for_followup_exec(self):
        """--keep is for follow-up debugging: `sail box exec sb_xxx` from a
        fresh shell. That command reads ~/.sail/sailboxes/<id>.json, so
        `sail box run` must write it just like `sail box create` does."""
        from sail.cli._state import load_sailbox_record

        body = "import sail\n@sail.function\ndef fn():\n    return 'ok'\n"
        with _module_in_cwd("_sail_run_keep_record", body):
            with self._patched_run(result="ok") as (stub, create, find, app):
                with captured_io():
                    rc = main(
                        [
                            "box",
                            "run",
                            "--app",
                            "demo",
                            "--keep",
                            "_sail_run_keep_record::fn",
                        ]
                    )
            self.assertEqual(rc, 0)
            stub.terminate.assert_not_called()
            record = load_sailbox_record("sb_test")
            self.assertIsNotNone(record)
            self.assertEqual(record.sailbox_id, "sb_test")
            self.assertEqual(record.exec_endpoint, "10.0.0.1:50052")
            self.assertEqual(record.worker_address, "10.0.0.1:50051")

    def test_run_default_path_deletes_local_record_after_terminate(self):
        """Without --keep the box is terminated, so the cache entry can't
        point at anything live. Mirror `sail box terminate` and remove it."""
        from sail.cli._state import load_sailbox_record

        body = "import sail\n@sail.function\ndef fn():\n    return 'ok'\n"
        with _module_in_cwd("_sail_run_default_record", body):
            with self._patched_run(result="ok") as (stub, create, find, app):
                with captured_io():
                    rc = main(
                        ["box", "run", "--app", "demo", "_sail_run_default_record::fn"]
                    )
            self.assertEqual(rc, 0)
            self.assertIsNone(load_sailbox_record("sb_test"))

    def test_run_terminate_failure_leaves_local_record_in_place(self):
        """If terminate failed, the box is still alive and the user is told to
        run `sail box terminate sb_xxx` — that command needs the cache record
        kept around until they actually clean up."""
        from sail.cli._state import load_sailbox_record

        body = "import sail\n@sail.function\ndef fn():\n    return 'ok'\n"
        with _module_in_cwd("_sail_run_termfail_record", body):
            with self._patched_run(result="ok") as (stub, create, find, app):
                stub.terminate.side_effect = RuntimeError("nope")
                with captured_io():
                    rc = main(
                        ["box", "run", "--app", "demo", "_sail_run_termfail_record::fn"]
                    )
            self.assertEqual(rc, 0)
            self.assertIsNotNone(load_sailbox_record("sb_test"))

    def test_run_keep_with_function_error_emits_kept_notice_on_stderr(self):
        from sail.errors import SailboxFunctionError

        body = "import sail\n@sail.function\ndef fn():\n    raise ValueError('boom')\n"
        with _module_in_cwd("_sail_run_keep_err_text", body):
            exc = SailboxFunctionError(
                "boom",
                error_type="ValueError",
                traceback="Traceback ...\nValueError: boom\n",
                stdout="",
                stderr="",
            )
            with self._patched_run(raise_exc=exc) as (stub, create, find, app):
                with captured_io() as (out, err):
                    rc = main(
                        [
                            "box",
                            "run",
                            "--app",
                            "demo",
                            "--keep",
                            "_sail_run_keep_err_text::fn",
                        ]
                    )
            self.assertEqual(rc, 1)
            # Text mode: error went to stderr via out.error(); kept notice
            # follows so the user can `sail box terminate sb_test`.
            self.assertIn("sb_test", err.getvalue())
            self.assertIn("kept", err.getvalue().lower())


# --------------------------------------------------------------- memory parser


class TestMemoryDiskParsing(unittest.TestCase):
    def test_memory_parsing(self):
        from sail.cli._sailbox import _parse_disk, _parse_memory

        self.assertEqual(_parse_memory("1g"), 1024)
        self.assertEqual(_parse_memory("2g"), 2048)
        self.assertEqual(_parse_memory("512m"), 512)
        self.assertEqual(_parse_memory("1024"), 1024)
        self.assertEqual(_parse_disk("16g"), 16)
        self.assertEqual(_parse_disk("32"), 32)

    def test_size_parsers_reject_non_integer_and_overflow(self):
        # Regression: int(float(...)) silently truncated 1.9g to 1945 MiB and
        # turned huge exponents into inf → OverflowError, both bypassing the
        # invalid_argument exit-2 path. Help text says "an integer with
        # optional ... suffix"; parser must match.
        from sail.cli._sailbox import _parse_disk, _parse_memory

        for bad in ("1.9g", "1.5m", "1.0", "1e9999g", "1e9999"):
            with self.assertRaises(ValueError, msg=f"memory {bad!r}"):
                _parse_memory(bad)
        for bad in ("8.9g", "8.5", "1e9999g", "1e9999"):
            with self.assertRaises(ValueError, msg=f"disk {bad!r}"):
                _parse_disk(bad)


class TestStateAtomicity(unittest.TestCase):
    def test_save_config_writes_via_rename(self):
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            save_config_file({"api_key": "sk_atomic"})
            self.assertEqual(load_config_file(), {"api_key": "sk_atomic"})
            # The tmp file used during atomic rename must not linger.
            tmp = config_path().with_suffix(config_path().suffix + ".tmp")
            self.assertFalse(tmp.exists())

    def test_save_config_does_not_truncate_on_failure(self):
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            save_config_file({"api_key": "sk_first"})
            # Force the rename to fail and verify the original file is intact
            # AND the half-written .tmp is cleaned up.
            with mock.patch("sail.cli._state.os.replace", side_effect=OSError("boom")):
                with self.assertRaises(OSError):
                    save_config_file({"api_key": "sk_second"})
            self.assertEqual(load_config_file(), {"api_key": "sk_first"})
            tmp = config_path().with_suffix(config_path().suffix + ".tmp")
            self.assertFalse(tmp.exists())

    def test_load_config_excludes_booleans(self):
        # bool is a subclass of int in Python; without an explicit exclusion
        # `mode = true` would round-trip as the string "True" and silently
        # flow into SAIL_MODE — surfacing later as `invalid_mode` from the
        # SDK rather than as the typo it actually is.
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            config_path().parent.mkdir(parents=True, exist_ok=True)
            config_path().write_text(
                'mode = true\napi_key = "sk_real"\n', encoding="utf-8"
            )
            self.assertEqual(load_config_file(), {"api_key": "sk_real"})

    def test_save_config_escapes_control_characters_in_round_trip(self):
        # `_collect_kvs` rejects control characters in user input, but a
        # hand-edited TOML file using valid escape sequences (e.g.
        # ``api_key = "first\\nsecond"``) parses through tomllib as a string
        # with a literal LF. Re-saving without escaping would emit a raw
        # newline inside the basic string and brick subsequent loads.
        from tempfile import TemporaryDirectory
        from textwrap import dedent
        from sail.cli._state import _toml_basic_string_escape

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            config_path().parent.mkdir(parents=True, exist_ok=True)
            config_path().write_text(
                dedent("""
                    api_key = "first\\nsecond\\ttab\\u0001ctrl"
                    """).strip() + "\n",
                encoding="utf-8",
            )
            values = load_config_file()
            self.assertEqual(values["api_key"], "first\nsecond\ttab\x01ctrl")
            # Round-trip: save the loaded values, re-load, value must match.
            save_config_file(values)
            self.assertEqual(load_config_file(), values)

        # Spot-check the escape function directly so we don't rely solely on
        # tomllib's tolerance to detect a regression.
        self.assertEqual(_toml_basic_string_escape("a\nb"), "a\\nb")
        self.assertEqual(_toml_basic_string_escape("a\x01b"), "a\\u0001b")
        self.assertEqual(_toml_basic_string_escape("a\x7fb"), "a\\u007Fb")
        self.assertEqual(_toml_basic_string_escape('a"b\\c'), 'a\\"b\\\\c')

    def test_save_config_persists_unicode_as_utf8(self):
        # Regression: Path.write_text() without encoding defaults to the
        # platform locale, so non-UTF-8 locales (Windows cp1252) would write
        # config in a locale encoding while tomllib reads as UTF-8 — round
        # trip would fail. Pin UTF-8 explicitly.
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            save_config_file({"api_key": "sk_café"})
            self.assertEqual(load_config_file(), {"api_key": "sk_café"})
            # Verify on-disk bytes are UTF-8 regardless of the platform locale.
            raw = config_path().read_bytes()
            self.assertIn("sk_café".encode("utf-8"), raw)

    def test_sailbox_id_traversal_is_rejected(self):
        # `pathlib` does not normalize `..` segments, so without validation
        # `load_sailbox_record('../evil/foo')` would resolve to `~/.sail/evil/
        # foo.json` and silently read whatever is there. Reject anything
        # outside the [A-Za-z0-9_-]+ pattern at the cache boundary.
        from tempfile import TemporaryDirectory

        from sail.cli._state import (
            delete_sailbox_record,
            sailboxes_dir,
        )

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            sailboxes_dir().mkdir(parents=True, exist_ok=True)
            evil = home_dir() / "evil"
            evil.mkdir(parents=True, exist_ok=True)
            (evil / "foo.json").write_text(
                '{"sailbox_id": "pwn", "name": "n", "app_id": "a", '
                '"exec_endpoint": "1.2.3.4:50052"}'
            )
            for bad in ("../evil/foo", "..", "a/b", "x.y", "sb_test\x00", ""):
                self.assertIsNone(load_sailbox_record(bad), f"load accepted {bad!r}")
                # Should not raise on delete; it's a no-op.
                delete_sailbox_record(bad)
            with self.assertRaises(ValueError):
                save_sailbox_record(
                    SailboxRecord(
                        sailbox_id="../evil/foo",
                        name="n",
                        app_id="a",
                        exec_endpoint="1.2.3.4:50052",
                    )
                )

    def test_load_sailbox_record_treats_non_object_json_as_miss(self):
        # `~/.sail/sailboxes/<id>.json` is only written by save_sailbox_record
        # (always a dict), but a manually-edited file containing `null` or
        # `[]` would otherwise raise AttributeError on .get(). Match the
        # JSONDecodeError branch and treat any unusable shape as a cache miss.
        from tempfile import TemporaryDirectory

        from sail.cli._state import sailboxes_dir

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            sailboxes_dir().mkdir(parents=True, exist_ok=True)
            for shape in ("null", "[]", '"sb_test"', "42"):
                (sailboxes_dir() / "sb_test.json").write_text(shape)
                self.assertIsNone(load_sailbox_record("sb_test"), f"shape={shape!r}")

    def test_load_sailbox_record_rejects_non_string_fields(self):
        # `_hydrate_for_exec`'s `not record.exec_endpoint` truthiness check
        # would happily forward a non-string truthy value (e.g. 123) into a
        # `Sailbox`, and `open_grpc_channel` later calls `.strip()` on it
        # — turning a recoverable cache problem into an AttributeError that
        # escapes to the top-level CLI handler.
        from tempfile import TemporaryDirectory

        from sail.cli._state import sailboxes_dir

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            sailboxes_dir().mkdir(parents=True, exist_ok=True)
            (sailboxes_dir() / "sb_test.json").write_text(
                '{"sailbox_id": "sb_test", "name": "n", "app_id": "a", '
                '"exec_endpoint": 123, "worker_address": "w"}'
            )
            self.assertIsNone(load_sailbox_record("sb_test"))
            (sailboxes_dir() / "sb_test.json").write_text(
                '{"sailbox_id": "sb_test", "name": null, "app_id": "a", '
                '"exec_endpoint": "1.2.3.4:50052", "worker_address": "w"}'
            )
            self.assertIsNone(load_sailbox_record("sb_test"))

    def test_load_sailbox_record_treats_non_utf8_bytes_as_miss(self):
        # A corrupted cache file with non-UTF8 bytes would otherwise raise
        # UnicodeDecodeError out of `path.read_text(encoding="utf-8")` and
        # escape to the top-level CLI error handler — turning a cache problem
        # into a hard `exec`/`url`/`resume` failure.
        from tempfile import TemporaryDirectory

        from sail.cli._state import sailboxes_dir

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            sailboxes_dir().mkdir(parents=True, exist_ok=True)
            (sailboxes_dir() / "sb_test.json").write_bytes(b"\xff\xfe\x00\x00not utf8")
            self.assertIsNone(load_sailbox_record("sb_test"))

    def test_home_dir_is_locked_down(self):
        from tempfile import TemporaryDirectory

        if sys.platform == "win32":
            self.skipTest("POSIX permissions only")
        with TemporaryDirectory() as td, isolated_home(Path(td)):
            save_config_file({"api_key": "sk_perms"})
            mode = home_dir().stat().st_mode & 0o777
            self.assertEqual(mode, 0o700)

    def test_save_does_not_chmod_preexisting_sail_home(self):
        # If the user points SAIL_HOME at an existing shared/system dir
        # (``/tmp`` in a container, a mount, etc.), tightening that dir to
        # 0o700 would strip sticky bits and break unrelated processes. Only
        # chmod directories the CLI itself creates.
        from tempfile import TemporaryDirectory

        if sys.platform == "win32":
            self.skipTest("POSIX permissions only")
        with TemporaryDirectory() as td, isolated_home(Path(td)):
            # SAIL_HOME (the temp dir) already exists; isolated_home set it.
            # Loosen its perms to a non-0o700 mode that mimics ``/tmp``.
            os.chmod(home_dir(), 0o755)
            save_config_file({"api_key": "sk_perms"})
            # Pre-existing SAIL_HOME left alone…
            self.assertEqual(home_dir().stat().st_mode & 0o777, 0o755)
            # …but a sub-directory we created is still tightened.
            from sail.cli._state import sailboxes_dir

            save_sailbox_record(
                SailboxRecord(
                    sailbox_id="sb_test",
                    name="n",
                    app_id="a",
                    exec_endpoint="1.2.3.4:50052",
                )
            )
            self.assertEqual(sailboxes_dir().stat().st_mode & 0o777, 0o700)

    def test_load_sailbox_record_forces_id_from_path(self):
        # The cache file's ``sailbox_id`` field is redundant with the path.
        # If a user manually edits the file to mutate that field, follow-up
        # commands like ``exec`` / ``url`` should still operate on the
        # caller's requested ID — never silently route to a different sailbox.
        from tempfile import TemporaryDirectory

        from sail.cli._state import sailboxes_dir

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            sailboxes_dir().mkdir(parents=True, exist_ok=True)
            (sailboxes_dir() / "sb_real.json").write_text(
                '{"sailbox_id": "sb_pwn", "name": "n", "app_id": "a", '
                '"exec_endpoint": "1.2.3.4:50052", "worker_address": "w"}'
            )
            record = load_sailbox_record("sb_real")
            self.assertIsNotNone(record)
            self.assertEqual(record.sailbox_id, "sb_real")


class TestSailboxCreateOutput(unittest.TestCase):
    def test_text_output_omits_internal_addresses(self):
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as td, isolated_home(Path(td)):
            with mock.patch(
                "sail.cli._sailbox.App.find",
                return_value=mock.Mock(id="app_1", name="demo", created_at=0),
            ), mock.patch(
                "sail.cli._sailbox.Sailbox.create",
                return_value=_StubSailbox(),
            ):
                with captured_io() as (out, err):
                    rc = main(
                        [
                            "box",
                            "create",
                            "--app",
                            "demo",
                            "--name",
                            "test-box",
                        ]
                    )
        self.assertEqual(rc, 0)
        text = out.getvalue()
        self.assertNotIn("worker:", text)
        self.assertNotIn("exec_endpoint:", text)
        self.assertNotIn("10.0.0.1", text)
        self.assertIn("sailbox_id:", text)


if __name__ == "__main__":
    unittest.main()
