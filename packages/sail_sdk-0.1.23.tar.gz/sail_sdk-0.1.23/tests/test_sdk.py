from __future__ import annotations

import json
import os
import re
import sys
import threading
from base64 import b64encode
from concurrent import futures
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlsplit

import cloudpickle
import grpc
import pytest
from google.protobuf import json_format

from sail._client import Client
from sail._config import Config
from sail._http_client import HTTPClient
from sail.app import App
from sail.errors import (
    ImageBuildError,
    SailboxCreationError,
    SailboxExecAlreadyRunningError,
    SailboxExecutionError,
    SailboxFunctionError,
    SailboxFunctionSerializationError,
    SailboxExecRequestNotFoundError,
    SailboxTerminatedError,
)
from sail.function import SailFunction, function
from sail.image import Image, ImageDefinition
from sail.pb.image.v1 import image_pb2
from sail.pb.imagebuilder.v1 import imagebuilder_pb2, imagebuilder_pb2_grpc
from sail.pb.scheduler.v1 import scheduler_pb2, scheduler_pb2_grpc
from sail.pb.workerproxy.v1 import workerproxy_pb2, workerproxy_pb2_grpc
from sail.sailbox import (
    FUNCTION_RESULT_PREFIX,
    FUNCTION_RUNTIME_PREFIX,
    Sailbox,
    SailboxExecRequest,
    SailboxInfo,
)
from sail.sailbox import _REMOTE_FUNCTION_RUNTIME_READY


class FakeScheduler(scheduler_pb2_grpc.SchedulerServiceServicer):
    """In-process gRPC server that simulates the scheduler."""

    def __init__(
        self,
        *,
        worker_address: str,
        create_status: int = scheduler_pb2.SAILBOX_STATUS_RUNNING,
        error_message: str = "",
        terminate_error: tuple[grpc.StatusCode, str] | None = None,
        terminate_status: int = scheduler_pb2.SAILBOX_STATUS_TERMINATED,
        start_error: tuple[grpc.StatusCode, str] | None = None,
        start_status: int = scheduler_pb2.SAILBOX_STATUS_RUNNING,
        resume_state: int = scheduler_pb2.SAILBOX_RESUME_STATE_RUNNING,
        resume_error_message: str = "",
    ):
        self.worker_address = worker_address
        self.create_status = create_status
        self.error_message = error_message
        self.terminate_error = terminate_error
        self.terminate_status = terminate_status
        self.start_error = start_error
        self.start_status = start_status
        self.resume_state = resume_state
        self.resume_error_message = resume_error_message
        self.last_metadata: dict[str, str] = {}
        self.last_create_request: scheduler_pb2.CreateSailboxRequest | None = None
        self.last_stop_request: scheduler_pb2.StopSailboxRequest | None = None
        self.last_checkpoint_request: scheduler_pb2.CheckpointSailboxRequest | None = (
            None
        )
        self.last_resume_request: scheduler_pb2.ResumeSailboxRequest | None = None

    def CreateSailbox(self, request, context):
        md = dict(context.invocation_metadata())
        self.last_metadata = md
        self.last_create_request = request
        return scheduler_pb2.CreateSailboxResponse(
            sailbox_id="sb-test-123",
            status=self.create_status,
            worker_address=(
                self.worker_address
                if self.create_status == scheduler_pb2.SAILBOX_STATUS_RUNNING
                else ""
            ),
            vm_id=(
                "vm-abc-123"
                if self.create_status == scheduler_pb2.SAILBOX_STATUS_RUNNING
                else ""
            ),
            exec_proxy_endpoint=self.worker_address,
            error_message=(
                self.error_message
                if self.create_status == scheduler_pb2.SAILBOX_STATUS_FAILED
                else ""
            ),
        )

    def GetSailboxStatus(self, request, context):
        md = dict(context.invocation_metadata())
        self.last_metadata = md
        return scheduler_pb2.GetSailboxStatusResponse(
            sailbox_id=request.sailbox_id,
            status=scheduler_pb2.SAILBOX_STATUS_RUNNING,
            worker_address="10.0.0.1:8732",
            vm_id="vm-abc-123",
        )

    def TerminateSailbox(self, request, context):
        if self.terminate_error is not None:
            context.abort(self.terminate_error[0], self.terminate_error[1])
        return scheduler_pb2.TerminateSailboxResponse(
            status=self.terminate_status,
        )

    def StopSailbox(self, request, context):
        self.last_stop_request = request
        status = scheduler_pb2.SAILBOX_STATUS_STOPPED
        if request.wake_on_traffic:
            status = scheduler_pb2.SAILBOX_STATUS_SLEEPING
        return scheduler_pb2.StopSailboxResponse(
            status=status,
        )

    def CheckpointSailbox(self, request, context):
        self.last_checkpoint_request = request
        return scheduler_pb2.CheckpointSailboxResponse(
            status=scheduler_pb2.SAILBOX_STATUS_RUNNING,
            checkpoint_generation=1,
        )

    def ResumeSailbox(self, request, context):
        self.last_resume_request = request
        if self.start_error is not None:
            context.abort(self.start_error[0], self.start_error[1])
        return scheduler_pb2.ResumeSailboxResponse(
            resume_state=self.resume_state,
            status=self.start_status,
            worker_address=self.worker_address,
            worker_internal_address=self.worker_address,
            vm_id="vm-restored-123",
            exec_proxy_endpoint=self.worker_address,
            error_message=self.resume_error_message,
        )

    def GetVMStats(self, request, context):
        return scheduler_pb2.GetVMStatsResponse(vm_stats=[])


class FakeImagebuilder(imagebuilder_pb2_grpc.ImageBuilderServiceServicer):
    """In-process gRPC server that simulates the imagebuilder."""

    def __init__(self) -> None:
        self.last_metadata: dict[str, str] = {}
        self.last_build_request: imagebuilder_pb2.BuildImageRequest | None = None
        self.build_call_count = 0
        self.status_call_count = 0
        self.build_errors: list[tuple[grpc.StatusCode, str]] = []
        self.status_errors: list[tuple[grpc.StatusCode, str]] = []
        self.build_status_sequence: list[int] = [
            image_pb2.IMAGE_BUILD_STATUS_READY,
        ]
        self.build_error_message = ""
        self.image_id = "sha256:test-image"
        # Build-asset surface — empty default means every probe is a miss.
        self.existing_local_files: set[str] = set()
        self.prepare_calls: list[imagebuilder_pb2.PrepareLocalFileUploadRequest] = []
        self.next_upload_url = "https://uploads.test/upload"
        self.upload_required_headers: dict[str, str] = {
            "Content-Type": "application/octet-stream"
        }

    def _next_status(self) -> int:
        status = self.build_status_sequence[0]
        if len(self.build_status_sequence) > 1:
            self.build_status_sequence = self.build_status_sequence[1:]
        return status

    def BuildImage(self, request, context):
        self.build_call_count += 1
        self.last_metadata = dict(context.invocation_metadata())
        self.last_build_request = request
        if self.build_errors:
            code, details = self.build_errors.pop(0)
            context.abort(code, details)
        return imagebuilder_pb2.BuildImageResponse(
            image_id=self.image_id,
            status=self._next_status(),
            error_message=self.build_error_message,
        )

    def GetImageBuildStatus(self, request, context):
        self.status_call_count += 1
        self.last_metadata = dict(context.invocation_metadata())
        if self.status_errors:
            code, details = self.status_errors.pop(0)
            context.abort(code, details)
        return imagebuilder_pb2.GetImageBuildStatusResponse(
            image_id=request.image_id,
            status=self._next_status(),
            error_message=self.build_error_message,
        )

    def PrepareLocalFileUpload(self, request, context):
        self.last_metadata = dict(context.invocation_metadata())
        self.prepare_calls.append(request)
        if request.content_sha256 in self.existing_local_files:
            return imagebuilder_pb2.PrepareLocalFileUploadResponse(
                already_exists=imagebuilder_pb2.LocalFileAlreadyExists(),
            )
        return imagebuilder_pb2.PrepareLocalFileUploadResponse(
            single_part=imagebuilder_pb2.SinglePartUploadPlan(
                upload_url=self.next_upload_url,
                required_headers=self.upload_required_headers,
                expires_at_unix=0,
            ),
        )


class FakeWorker(workerproxy_pb2_grpc.WorkerProxyServiceServicer):
    def __init__(
        self,
        *,
        exec_error=None,
        exec_errors=None,
        wait_error=None,
        wait_errors=None,
        wait_stdout="hi\n",
        wait_stdout_sequence=None,
        wait_stderr="",
        wait_stderr_sequence=None,
        wait_returncode=0,
        wait_returncode_sequence=None,
        listener_error=None,
        listener_statuses=None,
        listener_public_url: str | None = None,
    ):
        self.last_metadata: dict[str, str] = {}
        self.last_exec_request: workerproxy_pb2.ExecSailboxRequest | None = None
        self.exec_requests: list[workerproxy_pb2.ExecSailboxRequest] = []
        self.exec_error = exec_error
        self.exec_errors = list(exec_errors or [])
        self.wait_error = wait_error
        self.wait_errors = list(wait_errors or [])
        self.wait_call_count = 0
        self.wait_stdout = wait_stdout
        self.wait_stdout_sequence = list(wait_stdout_sequence or [])
        self.wait_stderr = wait_stderr
        self.wait_stderr_sequence = list(wait_stderr_sequence or [])
        self.wait_returncode = wait_returncode
        self.wait_returncode_sequence = list(wait_returncode_sequence or [])
        self.listener_error = listener_error
        self.network_requests: dict[str, workerproxy_pb2.NetworkRequest] = {}
        self.listener_statuses = list(
            listener_statuses or [workerproxy_pb2.LISTENER_ROUTE_STATUS_ACTIVE]
        )
        self.listener_public_url = listener_public_url
        self.listener_call_count = 0

    def ExecSailbox(self, request, context):
        self.last_metadata = dict(context.invocation_metadata())
        self.last_exec_request = request
        self.exec_requests.append(request)
        if self.exec_errors:
            code, details = self.exec_errors.pop(0)
            context.abort(code, details)
        if self.exec_error is not None:
            context.abort(self.exec_error[0], self.exec_error[1])
        return workerproxy_pb2.ExecSailboxResponse(exec_request_id="exec-123")

    def WaitSailboxExec(self, request, context):
        self.last_metadata = dict(context.invocation_metadata())
        self.wait_call_count += 1
        if self.wait_errors:
            code, details = self.wait_errors.pop(0)
            context.abort(code, details)
        if self.wait_error is not None:
            context.abort(self.wait_error[0], self.wait_error[1])
        stdout = (
            self.wait_stdout_sequence.pop(0)
            if self.wait_stdout_sequence
            else self.wait_stdout
        )
        stderr = (
            self.wait_stderr_sequence.pop(0)
            if self.wait_stderr_sequence
            else self.wait_stderr
        )
        returncode = (
            self.wait_returncode_sequence.pop(0)
            if self.wait_returncode_sequence
            else self.wait_returncode
        )
        return workerproxy_pb2.WaitSailboxExecResponse(
            exec_request_id=request.exec_request_id,
            status=workerproxy_pb2.SAILBOX_EXEC_STATUS_SUCCEEDED,
            stdout=stdout,
            stderr=stderr,
            return_code=returncode,
        )

    def CreateNetworkRequest(self, request, context):
        self.last_network_request = request
        req = workerproxy_pb2.NetworkRequest(
            request_id="nr-test-123",
            sailbox_id=request.sailbox_id,
            method=request.method,
            url=request.url,
            params=request.params,
            headers=request.headers,
            request_body=request.request_body,
            timeout_seconds=request.timeout_seconds,
            durability_mode=request.durability_mode,
            idempotency_key=request.idempotency_key,
            status=workerproxy_pb2.NETWORK_REQUEST_STATUS_COMPLETED,
            response_status_code=200,
            response_headers=[
                workerproxy_pb2.HTTPHeader(
                    name="Content-Type", value="application/json"
                )
            ],
            response_body=b'{"ok":true}',
        )
        self.network_requests[req.request_id] = req
        return workerproxy_pb2.CreateNetworkRequestResponse(request=req)

    def GetNetworkRequest(self, request, context):
        return workerproxy_pb2.GetNetworkRequestResponse(
            request=self.network_requests[request.request_id]
        )

    def WaitNetworkRequest(self, request, context):
        return workerproxy_pb2.WaitNetworkRequestResponse(
            request=self.network_requests[request.request_id]
        )

    def CancelNetworkRequest(self, request, context):
        canceled = workerproxy_pb2.NetworkRequest(
            request_id=request.request_id,
            sailbox_id=request.sailbox_id,
            status=workerproxy_pb2.NETWORK_REQUEST_STATUS_CANCELED,
        )
        self.network_requests[request.request_id] = canceled
        return workerproxy_pb2.CancelNetworkRequestResponse(request=canceled)

    def GetListener(self, request, context):
        if self.listener_error is not None:
            context.abort(self.listener_error[0], self.listener_error[1])
        status = self.listener_statuses[
            min(self.listener_call_count, len(self.listener_statuses) - 1)
        ]
        self.listener_call_count += 1
        return workerproxy_pb2.GetListenerResponse(
            listener=workerproxy_pb2.Listener(
                guest_port=request.guest_port,
                public_url=(
                    self.listener_public_url
                    if self.listener_public_url is not None
                    else f"https://{request.sailbox_id}-{request.guest_port}.sandbox.test"
                ),
                protocol="http",
                route_status=status,
            )
        )

    def ListListeners(self, request, context):
        return workerproxy_pb2.ListListenersResponse(
            listeners=[
                workerproxy_pb2.Listener(
                    guest_port=3000,
                    public_url=f"https://{request.sailbox_id}-3000.sandbox.test",
                    protocol="http",
                    route_status=workerproxy_pb2.LISTENER_ROUTE_STATUS_ACTIVE,
                )
            ]
        )


# --- FakeSailboxAPI ---
#
# Sailbox.list / get / create / terminate / pause / sleep / resume / checkpoint
# go through the public HTTP API at /v1/sailboxes/*. Exec, listeners, and
# network requests dial workerproxy directly over gRPC via the
# FakeScheduler/FakeWorker pair above, so each fixture in this file spins up
# both the gRPC servers AND the FakeSailboxAPI HTTP server.
#
# Request state is recorded on the FakeScheduler so assertions like
# `scheduler.last_create_request.app_id` read the same way whether the call
# took the HTTP or gRPC path: incoming JSON bodies are translated back into
# proto messages and written onto the FakeScheduler.

_SAILBOX_STATUS_TO_STR = {
    scheduler_pb2.SAILBOX_STATUS_RUNNING: "running",
    scheduler_pb2.SAILBOX_STATUS_STOPPED: "paused",
    scheduler_pb2.SAILBOX_STATUS_SLEEPING: "sleeping",
    scheduler_pb2.SAILBOX_STATUS_TERMINATED: "terminated",
    scheduler_pb2.SAILBOX_STATUS_FAILED: "failed",
}

_SAILBOX_RESUME_STATE_TO_STR = {
    scheduler_pb2.SAILBOX_RESUME_STATE_ALREADY_RUNNING: "already_running",
    scheduler_pb2.SAILBOX_RESUME_STATE_RESUME_STARTED: "resume_started",
    scheduler_pb2.SAILBOX_RESUME_STATE_RESUMING: "resuming",
    scheduler_pb2.SAILBOX_RESUME_STATE_RUNNING: "running",
    scheduler_pb2.SAILBOX_RESUME_STATE_TERMINAL_UNAVAILABLE: "terminal_unavailable",
}

# grpc.StatusCode → (http_status, error_type) for the two scheduler errors
# fake fixtures actually emit. The backend mapping has more codes
# (see schedulerErrorToHTTP); add entries here as tests start exercising them.
_GRPC_TO_HTTP = {
    grpc.StatusCode.NOT_FOUND: (404, "not_found_error"),
    grpc.StatusCode.FAILED_PRECONDITION: (409, "conflict_error"),
}


def _grpc_error_to_http(err):
    """Translate a (grpc.StatusCode, message) tuple to an (http_status, body)."""
    code, message = err
    status, err_type = _GRPC_TO_HTTP.get(code, (500, "server_error"))
    return status, {
        "error": {"message": message, "type": err_type, "param": None, "code": None}
    }


class FakeSailboxAPI(BaseHTTPRequestHandler):
    """HTTP handler that mimics the backend /v1/sailboxes/* endpoints.

    State is delegated to the FakeScheduler and FakeWorker instances attached
    to the server, so test assertions on those objects work uniformly whether
    the call took the HTTP or gRPC path.
    """

    # Route patterns (compiled once and reused across requests).
    _RE_SAILBOXES = re.compile(r"^/v1/sailboxes/?$")
    _RE_SAILBOX_ACTION = re.compile(
        r"^/v1/sailboxes/(?P<sid>[^/]+)/(?P<action>terminate|pause|sleep|resume|checkpoint)/?$"
    )

    def do_POST(self):
        self._record_request()
        body = self._read_body()
        scheduler = self.server.scheduler
        parsed = urlsplit(self.path)
        path = parsed.path

        if self._RE_SAILBOXES.match(path):
            self._handle_create(body, scheduler)
            return
        m = self._RE_SAILBOX_ACTION.match(path)
        if m:
            self._handle_action(m.group("sid"), m.group("action"), scheduler)
            return
        self._send_json(404, {"error": {"message": "not found"}})

    # --- Handlers ---

    def _handle_create(self, body, scheduler):
        if scheduler is None:
            self._send_json(503, {"error": {"message": "no scheduler configured"}})
            return
        ports = list(body.get("ingress_ports") or [])
        # Translate the JSON `image` blob back into the ImageSpec proto so the
        # FakeScheduler holds the same proto-shaped request whether the call
        # came in over HTTP or gRPC.
        image_spec = image_pb2.ImageSpec()
        raw_image = body.get("image")
        if raw_image:
            json_format.ParseDict(raw_image, image_spec, ignore_unknown_fields=True)
        req = scheduler_pb2.CreateSailboxRequest(
            name=body.get("name", ""),
            app_id=body.get("app_id", ""),
            cpu=int(body.get("cpu") or 0),
            memory_mib=int(body.get("memory_mib") or 0),
            state_disk_size_gib=int(body.get("state_disk_size_gib") or 0),
            timeout_seconds=int(body.get("timeout_seconds") or 0),
            ingress_ports=ports,
            image=image_spec,
        )
        scheduler.last_create_request = req
        status_enum = scheduler.create_status
        status_str = _SAILBOX_STATUS_TO_STR.get(status_enum, "running")
        running = status_enum == scheduler_pb2.SAILBOX_STATUS_RUNNING
        self._send_json(
            200,
            {
                "sailbox_id": "sb-test-123",
                "status": status_str,
                "worker_address": scheduler.worker_address if running else "",
                "vm_id": "vm-abc-123" if running else "",
                "exec_proxy_endpoint": scheduler.worker_address,
                "error_message": "" if running else scheduler.error_message,
            },
        )

    def _handle_action(self, sailbox_id, action, scheduler):
        if scheduler is None:
            self._send_json(503, {"error": {"message": "no scheduler configured"}})
            return
        if action == "terminate":
            if scheduler.terminate_error is not None:
                http_status, body = _grpc_error_to_http(scheduler.terminate_error)
                self._send_json(http_status, body)
                return
            # Real backend returns 200 with the current terminal status echoed
            # back even for already-terminated sailboxes (see scheduler/server.go
            # TerminateSailbox short-circuit), so mirror that here.
            self._send_json(
                200,
                {
                    "sailbox_id": sailbox_id,
                    "status": _SAILBOX_STATUS_TO_STR.get(
                        scheduler.terminate_status, "terminated"
                    ),
                },
            )
            return
        if action in ("pause", "sleep"):
            scheduler.last_stop_request = scheduler_pb2.StopSailboxRequest(
                sailbox_id=sailbox_id,
                wake_on_traffic=(action == "sleep"),
            )
            self._send_json(
                200,
                {
                    "sailbox_id": sailbox_id,
                    "status": "sleeping" if action == "sleep" else "paused",
                },
            )
            return
        if action == "resume":
            scheduler.last_resume_request = scheduler_pb2.ResumeSailboxRequest(
                sailbox_id=sailbox_id,
            )
            if scheduler.start_error is not None:
                http_status, body = _grpc_error_to_http(scheduler.start_error)
                self._send_json(http_status, body)
                return
            resume_state = _SAILBOX_RESUME_STATE_TO_STR.get(
                scheduler.resume_state, "running"
            )
            self._send_json(
                200,
                {
                    "sailbox_id": sailbox_id,
                    "status": _SAILBOX_STATUS_TO_STR.get(
                        scheduler.start_status, "running"
                    ),
                    "resume_state": resume_state,
                    "worker_address": scheduler.worker_address,
                    "vm_id": "vm-restored-123",
                    "exec_proxy_endpoint": scheduler.worker_address,
                    "error_message": scheduler.resume_error_message,
                },
            )
            return
        if action == "checkpoint":
            scheduler.last_checkpoint_request = scheduler_pb2.CheckpointSailboxRequest(
                sailbox_id=sailbox_id,
            )
            self._send_json(
                200,
                {
                    "sailbox_id": sailbox_id,
                    "status": "running",
                    "checkpoint_generation": 1,
                },
            )
            return
        self._send_json(404, {"error": {"message": f"unknown action {action}"}})

    # --- Helpers ---

    def _read_body(self):
        length = int(self.headers.get("Content-Length", 0))
        if not length:
            return {}
        raw = self.rfile.read(length)
        if not raw:
            return {}
        return json.loads(raw)

    def _record_request(self):
        self.server.last_path = self.path
        self.server.last_headers = dict(self.headers)
        # Mirror onto the scheduler's `last_metadata` (lowercase keys, matching
        # gRPC metadata convention) so bearer-token and metadata assertions
        # share one accessor across HTTP and gRPC fixtures.
        if self.server.scheduler is not None:
            self.server.scheduler.last_metadata = {
                k.lower(): v for k, v in self.headers.items()
            }

    def _send_json(self, status, body):
        raw = json.dumps(body).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def log_message(self, format, *args):
        pass


def _start_sailbox_api(scheduler, worker):
    """Start a FakeSailboxAPI HTTP server bound to the given scheduler/worker."""
    server = HTTPServer(("127.0.0.1", 0), FakeSailboxAPI)
    server.scheduler = scheduler
    server.worker = worker
    server.last_path = ""
    server.last_headers = {}
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    return server, server.server_address[1]


def _start_server(servicer):
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=2))
    scheduler_pb2_grpc.add_SchedulerServiceServicer_to_server(servicer, server)
    port = server.add_insecure_port("localhost:0")
    server.start()
    return server, port


def _start_imagebuilder(servicer):
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=2))
    imagebuilder_pb2_grpc.add_ImageBuilderServiceServicer_to_server(servicer, server)
    port = server.add_insecure_port("localhost:0")
    server.start()
    return server, port


def _start_worker(worker):
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=2))
    port = server.add_insecure_port("localhost:0")
    workerproxy_pb2_grpc.add_WorkerProxyServiceServicer_to_server(worker, server)
    server.start()
    return server, port


@pytest.fixture()
def _stub_imagebuilder_env(monkeypatch):
    # Every Sailbox.create now routes the image through BuildImage (the
    # client-side _skip_imagebuilder_build escape hatch is gone), so the
    # default scheduler fixtures need a reachable imagebuilder. The
    # default FakeImagebuilder.BuildImage returns READY immediately, which
    # matches the server's builtin-base-image shortcut.
    servicer = FakeImagebuilder()
    server, port = _start_imagebuilder(servicer)
    monkeypatch.setenv("SAIL_IMAGEBUILDER_URL", f"localhost:{port}")
    yield
    server.stop(grace=0)


@pytest.fixture()
def fake_imagebuilder(monkeypatch):
    """Start a fake imagebuilder and point the SDK at it."""
    servicer = FakeImagebuilder()
    server, port = _start_imagebuilder(servicer)
    monkeypatch.setenv("SAIL_IMAGEBUILDER_URL", f"localhost:{port}")
    monkeypatch.setenv("SAIL_API_KEY", "test_key_123")
    yield servicer
    server.stop(grace=0)


@pytest.fixture()
def fake_scheduler(monkeypatch, _stub_imagebuilder_env):
    """Start a fake scheduler that immediately returns RUNNING on first poll."""
    worker = FakeWorker()
    worker_server, worker_port = _start_worker(worker)

    servicer = FakeScheduler(worker_address=f"localhost:{worker_port}")
    server, port = _start_server(servicer)
    api_server, api_port = _start_sailbox_api(servicer, worker)
    monkeypatch.setenv("SAIL_API_URL", f"http://127.0.0.1:{api_port}")
    monkeypatch.setenv("SAIL_API_KEY", "test_key_123")
    yield servicer, worker
    api_server.shutdown()
    server.stop(grace=0)
    worker_server.stop(grace=0)


@pytest.fixture()
def fake_scheduler_and_imagebuilder(monkeypatch):
    """Start fake scheduler and imagebuilder endpoints for create-with-build tests."""
    worker = FakeWorker()
    worker_server, worker_port = _start_worker(worker)

    scheduler = FakeScheduler(worker_address=f"localhost:{worker_port}")
    scheduler_server, scheduler_port = _start_server(scheduler)

    imagebuilder = FakeImagebuilder()
    imagebuilder_server, imagebuilder_port = _start_imagebuilder(imagebuilder)

    api_server, api_port = _start_sailbox_api(scheduler, worker)

    monkeypatch.setenv("SAIL_IMAGEBUILDER_URL", f"localhost:{imagebuilder_port}")
    monkeypatch.setenv("SAIL_API_URL", f"http://127.0.0.1:{api_port}")
    monkeypatch.setenv("SAIL_API_KEY", "test_key_123")
    yield scheduler, imagebuilder
    api_server.shutdown()
    scheduler_server.stop(grace=0)
    imagebuilder_server.stop(grace=0)
    worker_server.stop(grace=0)


@pytest.fixture()
def worker_error_scheduler(monkeypatch, _stub_imagebuilder_env):
    worker = FakeWorker(
        exec_error=(
            grpc.StatusCode.FAILED_PRECONDITION,
            "another exec request is already running for this sailbox",
        ),
        wait_error=(grpc.StatusCode.NOT_FOUND, 'exec request "missing" not found'),
    )
    worker_server, worker_port = _start_worker(worker)

    servicer = FakeScheduler(worker_address=f"localhost:{worker_port}")
    server, port = _start_server(servicer)
    api_server, api_port = _start_sailbox_api(servicer, worker)
    monkeypatch.setenv("SAIL_API_URL", f"http://127.0.0.1:{api_port}")
    monkeypatch.setenv("SAIL_API_KEY", "test_key_123")
    yield servicer, worker
    api_server.shutdown()
    server.stop(grace=0)
    worker_server.stop(grace=0)


@pytest.fixture()
def missing_wait_scheduler(monkeypatch, _stub_imagebuilder_env):
    worker = FakeWorker(
        wait_error=(grpc.StatusCode.NOT_FOUND, 'exec request "missing" not found'),
    )
    worker_server, worker_port = _start_worker(worker)

    servicer = FakeScheduler(worker_address=f"localhost:{worker_port}")
    server, port = _start_server(servicer)
    api_server, api_port = _start_sailbox_api(servicer, worker)
    monkeypatch.setenv("SAIL_API_URL", f"http://127.0.0.1:{api_port}")
    monkeypatch.setenv("SAIL_API_KEY", "test_key_123")
    yield servicer, worker
    api_server.shutdown()
    server.stop(grace=0)
    worker_server.stop(grace=0)


@pytest.fixture()
def terminated_worker_scheduler(monkeypatch, _stub_imagebuilder_env):
    worker = FakeWorker(
        exec_error=(grpc.StatusCode.NOT_FOUND, "sailbox not found on this worker"),
    )
    worker_server, worker_port = _start_worker(worker)

    servicer = FakeScheduler(worker_address=f"localhost:{worker_port}")
    server, port = _start_server(servicer)
    api_server, api_port = _start_sailbox_api(servicer, worker)
    monkeypatch.setenv("SAIL_API_URL", f"http://127.0.0.1:{api_port}")
    monkeypatch.setenv("SAIL_API_KEY", "test_key_123")
    yield servicer, worker
    api_server.shutdown()
    server.stop(grace=0)
    worker_server.stop(grace=0)


@pytest.fixture()
def failing_scheduler(monkeypatch, _stub_imagebuilder_env):
    """Start a fake scheduler that returns FAILED."""
    servicer = FakeScheduler(
        worker_address="localhost:0",
        create_status=scheduler_pb2.SAILBOX_STATUS_FAILED,
        error_message="no capacity available",
    )
    server, port = _start_server(servicer)
    api_server, api_port = _start_sailbox_api(servicer, None)
    monkeypatch.setenv("SAIL_API_URL", f"http://127.0.0.1:{api_port}")
    monkeypatch.setenv("SAIL_API_KEY", "test_key_123")
    yield servicer
    api_server.shutdown()
    server.stop(grace=0)


@pytest.fixture()
def already_terminated_scheduler(monkeypatch, _stub_imagebuilder_env):
    # Real scheduler returns 200 with status=TERMINATED for already-terminated
    # sailboxes (see scheduler/server.go TerminateSailbox short-circuit), so
    # this fixture must not emit a precondition error.
    servicer = FakeScheduler(
        worker_address="localhost:0",
        terminate_status=scheduler_pb2.SAILBOX_STATUS_TERMINATED,
    )
    server, port = _start_server(servicer)
    api_server, api_port = _start_sailbox_api(servicer, None)
    monkeypatch.setenv("SAIL_API_URL", f"http://127.0.0.1:{api_port}")
    monkeypatch.setenv("SAIL_API_KEY", "test_key_123")
    yield servicer
    api_server.shutdown()
    server.stop(grace=0)


@pytest.fixture()
def terminated_resume_scheduler(monkeypatch, _stub_imagebuilder_env):
    # Real scheduler returns 200 with resume_state=TERMINAL_UNAVAILABLE for
    # resume of a terminated sailbox (see scheduler/server.go ResumeSailbox),
    # so model the contract here rather than emitting a precondition error.
    servicer = FakeScheduler(
        worker_address="localhost:0",
        resume_state=scheduler_pb2.SAILBOX_RESUME_STATE_TERMINAL_UNAVAILABLE,
        resume_error_message="sailbox sb-test-123 is SAILBOX_STATUS_TERMINATED and cannot be resumed",
    )
    server, port = _start_server(servicer)
    api_server, api_port = _start_sailbox_api(servicer, None)
    monkeypatch.setenv("SAIL_API_URL", f"http://127.0.0.1:{api_port}")
    monkeypatch.setenv("SAIL_API_KEY", "test_key_123")
    yield servicer
    api_server.shutdown()
    server.stop(grace=0)


@pytest.fixture()
def missing_terminate_scheduler(monkeypatch, _stub_imagebuilder_env):
    servicer = FakeScheduler(
        worker_address="localhost:0",
        terminate_error=(grpc.StatusCode.NOT_FOUND, "sailbox not found"),
    )
    server, port = _start_server(servicer)
    api_server, api_port = _start_sailbox_api(servicer, None)
    monkeypatch.setenv("SAIL_API_URL", f"http://127.0.0.1:{api_port}")
    monkeypatch.setenv("SAIL_API_KEY", "test_key_123")
    yield servicer
    api_server.shutdown()
    server.stop(grace=0)


@pytest.fixture(autouse=True)
def _reset_client():
    """Ensure the singleton client is reset between tests."""
    _REMOTE_FUNCTION_RUNTIME_READY.clear()
    yield
    Client.reset()
    HTTPClient.reset()
    _REMOTE_FUNCTION_RUNTIME_READY.clear()


# --- Sailbox.create ---


def test_create_returns_sailbox(fake_scheduler):
    fake_scheduler, _ = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    assert sb.sailbox_id == "sb-test-123"
    assert sb.name == "sandbox-1"
    assert sb.status == "running"
    assert sb.worker_address == fake_scheduler.worker_address
    assert sb.exec_endpoint == fake_scheduler.worker_address


def test_create_with_all_args(fake_scheduler):
    fake_scheduler, _ = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="my-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
        memory_mib=2048,
        cpu=2,
    )

    assert sb.sailbox_id == "sb-test-123"
    assert fake_scheduler.last_create_request.app_id == "app_test"
    assert fake_scheduler.last_create_request.cpu == 2
    assert fake_scheduler.last_create_request.memory_mib == 2048


def test_create_with_ingress_ports(fake_scheduler):
    fake_scheduler, _ = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="my-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
        ingress_ports=[3000, 8080],
    )

    assert sb.sailbox_id == "sb-test-123"
    assert list(fake_scheduler.last_create_request.ingress_ports) == [3000, 8080]


def test_create_with_disk_gib(fake_scheduler):
    fake_scheduler, _ = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="my-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
        disk_gib=8,
    )

    assert sb.sailbox_id == "sb-test-123"
    assert fake_scheduler.last_create_request.state_disk_size_gib == 8


def test_create_defaults_disk_gib_to_8(fake_scheduler):
    fake_scheduler, _ = fake_scheduler
    Sailbox.create(
        app=App(id="app_test", name="my-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    assert fake_scheduler.last_create_request.state_disk_size_gib == 8


def test_create_rejects_invalid_sizes(fake_scheduler):
    app = App(id="app_test", name="my-app", created_at=0)

    with pytest.raises(ValueError, match="cpu must be greater than 0"):
        Sailbox.create(app=app, image=Image.debian_amd64, name="sandbox-1", cpu=0)
    with pytest.raises(ValueError, match="memory_mib must be at least 1024"):
        Sailbox.create(
            app=app, image=Image.debian_amd64, name="sandbox-1", memory_mib=512
        )
    with pytest.raises(ValueError, match="memory_mib must be at most 65536"):
        Sailbox.create(
            app=app, image=Image.debian_amd64, name="sandbox-1", memory_mib=65537
        )
    with pytest.raises(ValueError, match="disk_gib must be greater than 0"):
        Sailbox.create(app=app, image=Image.debian_amd64, name="sandbox-1", disk_gib=0)
    with pytest.raises(ValueError, match="disk_gib must be at most 64"):
        Sailbox.create(app=app, image=Image.debian_amd64, name="sandbox-1", disk_gib=65)


def test_create_rejects_invalid_ingress_ports(fake_scheduler):
    app = App(id="app_test", name="my-app", created_at=0)

    with pytest.raises(ValueError, match="ingress_ports must be between 1 and 65535"):
        Sailbox.create(
            app=app,
            image=Image.debian_amd64,
            name="sandbox-1",
            ingress_ports=[0],
        )
    with pytest.raises(ValueError, match="reserved port 22"):
        Sailbox.create(
            app=app,
            image=Image.debian_amd64,
            name="sandbox-1",
            ingress_ports=[22],
        )
    with pytest.raises(ValueError, match="reserved port 10000"):
        Sailbox.create(
            app=app,
            image=Image.debian_amd64,
            name="sandbox-1",
            ingress_ports=[10000],
        )
    with pytest.raises(ValueError, match="ingress_ports must be unique"):
        Sailbox.create(
            app=app,
            image=Image.debian_amd64,
            name="sandbox-1",
            ingress_ports=[3000, 3000],
        )


def test_create_returns_running_without_polling(fake_scheduler):
    fake_scheduler, _ = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    assert sb.status == "running"


def test_create_failed_raises(failing_scheduler):
    with pytest.raises(SailboxCreationError, match="no capacity available"):
        Sailbox.create(
            app=App(id="app_test", name="test-app", created_at=0),
            image=Image.debian_amd64,
            name="sandbox-1",
        )


def test_create_serializes_debian_image(fake_scheduler):
    fake_scheduler, _ = fake_scheduler

    Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    assert fake_scheduler.last_create_request is not None
    assert fake_scheduler.last_create_request.image.base == image_pb2.BASE_IMAGE_DEBIAN


def test_create_requires_typed_image(fake_scheduler):
    with pytest.raises(TypeError, match="image must be a sail.Image value"):
        Sailbox.create(
            app=App(id="app_test", name="test-app", created_at=0),
            image="debian",  # type: ignore[arg-type]
            name="sandbox-1",
        )


def test_create_custom_image_builds_then_serializes_steps_and_env(
    fake_scheduler_and_imagebuilder, monkeypatch
):
    fake_scheduler, fake_imagebuilder = fake_scheduler_and_imagebuilder
    fake_imagebuilder.build_status_sequence = [
        image_pb2.IMAGE_BUILD_STATUS_QUEUED,
        image_pb2.IMAGE_BUILD_STATUS_BUILDING,
        image_pb2.IMAGE_BUILD_STATUS_READY,
    ]
    monkeypatch.setattr("sail.image.time.sleep", lambda _: None)
    monkeypatch.setattr("sail.image.random.uniform", lambda _a, _b: 0.0)

    image = (
        Image.debian_amd64.apt_install("git", "curl")
        .pip_install("numpy")
        .run_commands("echo ready", "touch /tmp/test")
        .env({"FOO": "bar", "HELLO": "world"})
    )
    Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=image,
        name="sandbox-1",
        image_build_timeout=5,
    )

    build_req = fake_imagebuilder.last_build_request
    assert build_req is not None
    assert len(build_req.image.build_steps) == 4
    assert (
        build_req.image.python_version
        == f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    )
    assert build_req.image.build_steps[0].apt_install.packages == ["git", "curl"]
    assert build_req.image.build_steps[1].pip_install.packages == ["numpy"]
    assert build_req.image.build_steps[2].run_command.command == "echo ready"
    assert build_req.image.build_steps[3].run_command.command == "touch /tmp/test"
    assert dict(build_req.image.env) == {"FOO": "bar", "HELLO": "world"}
    assert build_req.image.architecture == image_pb2.IMAGE_ARCHITECTURE_AMD64

    req = fake_scheduler.last_create_request
    assert req is not None
    assert len(req.image.build_steps) == 4
    assert (
        req.image.python_version
        == f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    )
    assert req.image.build_steps[0].apt_install.packages == ["git", "curl"]
    assert req.image.build_steps[1].pip_install.packages == ["numpy"]
    assert req.image.build_steps[2].run_command.command == "echo ready"
    assert req.image.build_steps[3].run_command.command == "touch /tmp/test"
    assert dict(req.image.env) == {"FOO": "bar", "HELLO": "world"}
    assert req.image.architecture == image_pb2.IMAGE_ARCHITECTURE_AMD64


def test_create_arm64_base_pins_local_python_version(fake_scheduler):
    fake_scheduler, _ = fake_scheduler

    Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_arm64,
        name="sandbox-1",
    )

    assert fake_scheduler.last_create_request is not None
    assert (
        fake_scheduler.last_create_request.image.architecture
        == image_pb2.IMAGE_ARCHITECTURE_ARM64
    )
    assert (
        fake_scheduler.last_create_request.image.python_version
        == f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    )


def test_create_amd64_base_leaves_python_version_empty(fake_scheduler):
    # amd64 base intentionally leaves python_version empty so the spec stays a
    # "builtin base image" that the imagebuilder serves from the prebuilt
    # rootfs without an arch-specific build.
    fake_scheduler, _ = fake_scheduler

    Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    assert fake_scheduler.last_create_request is not None
    assert (
        fake_scheduler.last_create_request.image.architecture
        == image_pb2.IMAGE_ARCHITECTURE_AMD64
    )
    assert fake_scheduler.last_create_request.image.python_version == ""


def test_create_custom_image_preserves_arm64_architecture(
    fake_scheduler_and_imagebuilder, monkeypatch
):
    fake_scheduler, fake_imagebuilder = fake_scheduler_and_imagebuilder
    fake_imagebuilder.build_status_sequence = [image_pb2.IMAGE_BUILD_STATUS_READY]
    monkeypatch.setattr("sail.image.time.sleep", lambda _: None)

    Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_arm64.pip_install("numpy"),
        name="sandbox-1",
        image_build_timeout=5,
    )

    assert fake_imagebuilder.last_build_request is not None
    assert (
        fake_imagebuilder.last_build_request.image.architecture
        == image_pb2.IMAGE_ARCHITECTURE_ARM64
    )
    assert fake_scheduler.last_create_request is not None
    assert (
        fake_scheduler.last_create_request.image.architecture
        == image_pb2.IMAGE_ARCHITECTURE_ARM64
    )


def test_create_custom_image_build_failure_raises(
    fake_scheduler_and_imagebuilder,
):
    fake_scheduler, fake_imagebuilder = fake_scheduler_and_imagebuilder
    fake_imagebuilder.build_status_sequence = [image_pb2.IMAGE_BUILD_STATUS_FAILED]
    fake_imagebuilder.build_error_message = "apt-get failed"

    with pytest.raises(ImageBuildError, match="apt-get failed"):
        Sailbox.create(
            app=App(id="app_test", name="test-app", created_at=0),
            image=Image.debian_amd64.apt_install("git"),
            name="sandbox-1",
        )

    assert fake_scheduler.last_create_request is None


def test_create_wraps_imagebuilder_transport_errors(fake_scheduler, monkeypatch):
    monkeypatch.setenv("SAIL_IMAGEBUILDER_URL", "localhost:0")

    with pytest.raises(SailboxCreationError, match="failed to connect"):
        Sailbox.create(
            app=App(id="app_test", name="test-app", created_at=0),
            image=Image.debian_amd64.pip_install("numpy"),
            name="sandbox-1",
        )


def test_create_custom_image_polls_until_ready(
    fake_scheduler_and_imagebuilder, monkeypatch
):
    fake_scheduler, fake_imagebuilder = fake_scheduler_and_imagebuilder
    fake_imagebuilder.build_status_sequence = [
        image_pb2.IMAGE_BUILD_STATUS_QUEUED,
        image_pb2.IMAGE_BUILD_STATUS_BUILDING,
        image_pb2.IMAGE_BUILD_STATUS_READY,
    ]
    monkeypatch.setattr("sail.image.time.sleep", lambda _: None)
    monkeypatch.setattr("sail.image.random.uniform", lambda _a, _b: 0.0)

    Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64.pip_install("numpy"),
        name="sandbox-1",
        image_build_timeout=5,
    )

    assert fake_imagebuilder.last_build_request is not None
    assert fake_imagebuilder.last_build_request.image.build_steps[
        0
    ].pip_install.packages == ["numpy"]
    assert (
        fake_imagebuilder.last_build_request.image.architecture
        == image_pb2.IMAGE_ARCHITECTURE_AMD64
    )
    assert fake_scheduler.last_create_request is not None


def test_arm64_base_image_build_uses_arm64_architecture(fake_imagebuilder, monkeypatch):
    fake_imagebuilder.build_status_sequence = [image_pb2.IMAGE_BUILD_STATUS_READY]
    monkeypatch.setattr("sail.image.time.sleep", lambda _: None)

    Image.debian_arm64.pip_install("numpy").build(timeout=5)

    assert fake_imagebuilder.last_build_request is not None
    assert (
        fake_imagebuilder.last_build_request.image.architecture
        == image_pb2.IMAGE_ARCHITECTURE_ARM64
    )


def test_image_build_failure_raises(fake_imagebuilder):
    fake_imagebuilder.build_status_sequence = [image_pb2.IMAGE_BUILD_STATUS_FAILED]
    fake_imagebuilder.build_error_message = "apt-get failed"

    with pytest.raises(ImageBuildError, match="apt-get failed"):
        Image.debian_amd64.apt_install("git").build(timeout=5)


def test_image_build_retries_transient_build_socket_close(
    fake_imagebuilder, monkeypatch
):
    fake_imagebuilder.build_errors = [
        (
            grpc.StatusCode.UNAVAILABLE,
            "failed to connect to all addresses; last error: UNAVAILABLE: "
            "ipv4:127.0.0.1:443: Socket closed",
        )
    ]
    monkeypatch.setattr("sail.image.time.sleep", lambda _: None)

    image = Image.debian_arm64.pip_install("numpy").build(timeout=5)

    assert image._image_id == "sha256:test-image"
    assert fake_imagebuilder.build_call_count == 2


def test_image_build_retries_transient_status_socket_close(
    fake_imagebuilder, monkeypatch
):
    fake_imagebuilder.build_status_sequence = [
        image_pb2.IMAGE_BUILD_STATUS_QUEUED,
        image_pb2.IMAGE_BUILD_STATUS_READY,
    ]
    fake_imagebuilder.status_errors = [
        (
            grpc.StatusCode.UNAVAILABLE,
            "failed to connect to all addresses; last error: UNAVAILABLE: "
            "ipv4:127.0.0.1:443: Socket closed",
        )
    ]
    monkeypatch.setattr("sail.image.time.sleep", lambda _: None)
    monkeypatch.setattr("sail.image.random.uniform", lambda _a, _b: 0.0)

    image = Image.debian_amd64.pip_install("numpy").build(timeout=5)

    assert image._image_id == "sha256:test-image"
    assert fake_imagebuilder.status_call_count == 2


def test_image_build_retry_sleep_is_capped_by_timeout(fake_imagebuilder, monkeypatch):
    fake_imagebuilder.build_status_sequence = [
        image_pb2.IMAGE_BUILD_STATUS_QUEUED,
        image_pb2.IMAGE_BUILD_STATUS_READY,
    ]
    fake_imagebuilder.status_errors = [
        (
            grpc.StatusCode.UNAVAILABLE,
            "failed to connect to all addresses; last error: UNAVAILABLE: "
            "ipv4:127.0.0.1:443: Socket closed",
        )
    ]
    now = 100.0
    sleeps: list[float] = []

    def fake_monotonic():
        return now

    def fake_sleep(seconds):
        nonlocal now
        sleeps.append(seconds)
        now += seconds

    monkeypatch.setattr("sail.image.time.monotonic", fake_monotonic)
    monkeypatch.setattr("sail.image.time.sleep", fake_sleep)
    monkeypatch.setattr("sail.image.random.uniform", lambda _a, _b: 0.0)

    with pytest.raises(TimeoutError, match="timed out waiting for image build"):
        Image.debian_amd64.pip_install("numpy").build(timeout=1.25)

    assert sleeps == pytest.approx([1.0, 0.25])
    assert fake_imagebuilder.status_call_count == 1


def test_image_build_remains_public_api(fake_imagebuilder, monkeypatch):
    fake_imagebuilder.build_status_sequence = [
        image_pb2.IMAGE_BUILD_STATUS_QUEUED,
        image_pb2.IMAGE_BUILD_STATUS_BUILDING,
        image_pb2.IMAGE_BUILD_STATUS_READY,
    ]
    monkeypatch.setattr("sail.image.time.sleep", lambda _: None)
    monkeypatch.setattr("sail.image.random.uniform", lambda _a, _b: 0.0)

    image = Image.debian_amd64.pip_install("numpy").build(timeout=5)

    assert image._image_id == "sha256:test-image"
    assert fake_imagebuilder.last_build_request is not None
    assert fake_imagebuilder.last_build_request.image.build_steps[
        0
    ].pip_install.packages == ["numpy"]


# --- add_local_file ---


def _sha256_hex(data: bytes) -> str:
    import hashlib

    return hashlib.sha256(data).hexdigest()


@pytest.fixture()
def _stub_put_request(monkeypatch):
    """Replace the real HTTP PUT helper with an in-memory recorder.

    Each recorded call captures url, headers, and the actual body bytes
    the SDK streamed.
    """
    state: dict = {"calls": []}

    def fake_put(url, headers, body):
        # Drain the body so tests can verify exactly what bytes the SDK
        # would have sent. Read in a fixed-size loop to mimic http.client.
        data = b""
        while True:
            chunk = body.read(8192)
            if not chunk:
                break
            data += chunk
        state["calls"].append({"url": url, "headers": dict(headers), "body": data})

    monkeypatch.setattr("sail.image._put_request", fake_put)
    return state


def test_add_local_file_uploads_then_appends_step(
    fake_imagebuilder, _stub_put_request, tmp_path
):
    payload = b"hello world\n"
    src = tmp_path / "config.json"
    src.write_bytes(payload)

    image = Image.debian_arm64.add_local_file(src, "/etc/myapp/config.json")

    assert len(fake_imagebuilder.prepare_calls) == 1
    prep = fake_imagebuilder.prepare_calls[0]
    assert prep.content_sha256 == _sha256_hex(payload)
    assert prep.content_length == len(payload)

    calls = _stub_put_request["calls"]
    assert len(calls) == 1
    assert calls[0]["body"] == payload
    assert calls[0]["url"] == "https://uploads.test/upload"

    spec = image.to_proto()
    assert len(spec.build_steps) == 1
    step = spec.build_steps[0].add_local_file
    assert step.content_sha256 == _sha256_hex(payload)
    assert step.remote_path == "/etc/myapp/config.json"
    assert step.mode == 0


def test_add_local_file_accepts_zero_byte_file(
    fake_imagebuilder, _stub_put_request, tmp_path
):
    src = tmp_path / "empty.txt"
    src.write_bytes(b"")

    image = Image.debian_arm64.add_local_file(src, "/etc/empty")

    assert len(fake_imagebuilder.prepare_calls) == 1
    prep = fake_imagebuilder.prepare_calls[0]
    assert prep.content_length == 0
    assert prep.content_sha256 == _sha256_hex(b"")
    calls = _stub_put_request["calls"]
    assert len(calls) == 1
    assert calls[0]["body"] == b""

    step = image.to_proto().build_steps[0].add_local_file
    assert step.content_sha256 == _sha256_hex(b"")
    assert step.remote_path == "/etc/empty"


def test_add_local_file_skips_upload_when_asset_exists(
    fake_imagebuilder, _stub_put_request, tmp_path
):
    payload = b"already-uploaded"
    src = tmp_path / "cached.bin"
    src.write_bytes(payload)
    fake_imagebuilder.existing_local_files = {_sha256_hex(payload)}

    Image.debian_arm64.add_local_file(src, "/opt/cached.bin")

    assert len(fake_imagebuilder.prepare_calls) == 1
    assert _stub_put_request["calls"] == []


def test_add_local_file_trailing_slash_appends_basename(
    fake_imagebuilder, _stub_put_request, tmp_path
):
    src = tmp_path / "weights.bin"
    src.write_bytes(b"x")

    image = Image.debian_arm64.add_local_file(src, "/models/")

    step = image.to_proto().build_steps[0].add_local_file
    assert step.remote_path == "/models/weights.bin"


def test_add_local_file_explicit_mode_preserved(
    fake_imagebuilder, _stub_put_request, tmp_path
):
    src = tmp_path / "run.sh"
    src.write_bytes(b"#!/bin/sh\n")

    image = Image.debian_arm64.add_local_file(src, "/usr/local/bin/run.sh", mode=0o755)

    step = image.to_proto().build_steps[0].add_local_file
    assert step.mode == 0o755


def test_add_local_file_rejects_relative_remote_path(
    fake_imagebuilder, _stub_put_request, tmp_path
):
    src = tmp_path / "f.txt"
    src.write_bytes(b"x")

    with pytest.raises(ValueError, match="must be absolute"):
        Image.debian_arm64.add_local_file(src, "relative/path")


def test_add_local_file_rejects_missing_local_file(
    fake_imagebuilder, _stub_put_request, tmp_path
):
    with pytest.raises(ValueError, match="does not exist"):
        Image.debian_arm64.add_local_file(tmp_path / "missing.txt", "/dst")


def test_add_local_file_rejects_invalid_mode(
    fake_imagebuilder, _stub_put_request, tmp_path
):
    src = tmp_path / "f.txt"
    src.write_bytes(b"x")
    with pytest.raises(ValueError, match="must fit in low 9 bits"):
        Image.debian_arm64.add_local_file(src, "/dst", mode=0o7777)


@pytest.mark.parametrize(
    "remote_path, match",
    [
        ("/tmp/$VAR/file", "unsupported character"),
        ('/tmp/"quoted"/file', "unsupported character"),
        ("/tmp/back\\slash/file", "unsupported character"),
        ("/tmp/with\nnewline", "unsupported character"),
        ("/tmp/with space/file", "unsupported character"),
        ("/tmp/../etc/passwd", "must not contain '..'"),
    ],
)
def test_add_local_file_rejects_invalid_remote_path(
    fake_imagebuilder, _stub_put_request, tmp_path, remote_path, match
):
    src = tmp_path / "f.txt"
    src.write_bytes(b"x")
    with pytest.raises(ValueError, match=match):
        Image.debian_arm64.add_local_file(src, remote_path)
    # Reject before any PrepareLocalFileUpload probe — saves a wasted upload.
    assert fake_imagebuilder.prepare_calls == []


def test_add_local_file_rejects_oversize_before_hashing(
    fake_imagebuilder, _stub_put_request, tmp_path, monkeypatch
):
    """An oversize file must fast-fail on stat without being hashed.

    Hashing a 10 GiB file just to reject it would be wasteful — drop the
    cap to a small value, write something larger than that, and assert
    `_hash_file` is never called.
    """
    import sail.image as image_mod

    monkeypatch.setattr(image_mod, "_MAX_LOCAL_FILE_BYTES", 8)
    src = tmp_path / "huge.bin"
    src.write_bytes(b"x" * 16)  # 16 > 8-byte test cap

    hash_calls = {"n": 0}
    real_hash = image_mod._hash_file

    def spy_hash(path):
        hash_calls["n"] += 1
        return real_hash(path)

    monkeypatch.setattr(image_mod, "_hash_file", spy_hash)

    with pytest.raises(ValueError, match="exceeds"):
        Image.debian_arm64.add_local_file(src, "/etc/huge")
    assert hash_calls["n"] == 0, "hashed an oversize file instead of fast-failing"
    assert fake_imagebuilder.prepare_calls == []


# --- add_local_dir ---


def _make_dir_tree(root, layout: dict):
    """Materialize {relative_posix_path: bytes_or_dict} on disk under root."""
    for name, value in layout.items():
        target = root / name
        if isinstance(value, dict):
            target.mkdir(parents=True, exist_ok=True)
            _make_dir_tree(target, value)
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(value)


def test_add_local_dir_uploads_and_sorts(
    fake_imagebuilder, _stub_put_request, tmp_path
):
    src = tmp_path / "tree"
    src.mkdir()
    _make_dir_tree(
        src,
        {
            "z.txt": b"zed",
            "a.txt": b"ay",
            "sub": {"nested.txt": b"deep"},
        },
    )

    image = Image.debian_arm64.add_local_dir(src, "/app")

    step = image.to_proto().build_steps[0].add_local_dir
    assert step.remote_path == "/app"
    rel_paths = [f.relative_path for f in step.files]
    # Server-side sort is authoritative, but SDK pre-sorting prevents
    # noise — assert the proto reaches the server already canonical.
    assert rel_paths == ["a.txt", "sub/nested.txt", "z.txt"]
    digests = {f.relative_path: f.content_sha256 for f in step.files}
    assert digests["a.txt"] == _sha256_hex(b"ay")
    assert digests["sub/nested.txt"] == _sha256_hex(b"deep")
    assert digests["z.txt"] == _sha256_hex(b"zed")
    # One unique sha per file → three uploads.
    assert len(_stub_put_request["calls"]) == 3
    assert len(fake_imagebuilder.prepare_calls) == 3


def test_add_local_dir_dedupes_uploads_by_sha(
    fake_imagebuilder, _stub_put_request, tmp_path
):
    src = tmp_path / "tree"
    src.mkdir()
    _make_dir_tree(
        src,
        {
            "a.txt": b"same",
            "b.txt": b"same",
            "c.txt": b"different",
        },
    )

    Image.debian_arm64.add_local_dir(src, "/app")

    # Two unique digests across three files → two probes and uploads.
    digests = {prep.content_sha256 for prep in fake_imagebuilder.prepare_calls}
    assert digests == {_sha256_hex(b"same"), _sha256_hex(b"different")}
    assert len(_stub_put_request["calls"]) == 2


def test_add_local_dir_skips_upload_when_asset_exists(
    fake_imagebuilder, _stub_put_request, tmp_path
):
    src = tmp_path / "tree"
    src.mkdir()
    (src / "cached.txt").write_bytes(b"cached")
    (src / "fresh.txt").write_bytes(b"fresh")
    fake_imagebuilder.existing_local_files = {_sha256_hex(b"cached")}

    Image.debian_arm64.add_local_dir(src, "/app")

    # Two probes but only one PUT — the cached blob short-circuits.
    assert len(fake_imagebuilder.prepare_calls) == 2
    assert len(_stub_put_request["calls"]) == 1
    assert _stub_put_request["calls"][0]["body"] == b"fresh"


def test_add_local_dir_applies_ignore_patterns(
    fake_imagebuilder, _stub_put_request, tmp_path
):
    src = tmp_path / "tree"
    src.mkdir()
    _make_dir_tree(
        src,
        {
            "main.py": b"main",
            "main.pyc": b"compiled",
            "__pycache__": {"main.cpython-311.pyc": b"cache"},
            "keep.pyc": b"keep this",
        },
    )

    image = Image.debian_arm64.add_local_dir(
        src,
        "/app",
        ignore=["*.pyc", "__pycache__/", "!keep.pyc"],
    )

    rel_paths = [
        f.relative_path for f in image.to_proto().build_steps[0].add_local_dir.files
    ]
    assert rel_paths == ["keep.pyc", "main.py"]


def test_add_local_dir_captures_file_mode(
    fake_imagebuilder, _stub_put_request, tmp_path
):
    src = tmp_path / "tree"
    src.mkdir()
    script = src / "run.sh"
    script.write_bytes(b"#!/bin/sh\n")
    os.chmod(script, 0o750)

    image = Image.debian_arm64.add_local_dir(src, "/app")

    step = image.to_proto().build_steps[0].add_local_dir
    by_path = {f.relative_path: f for f in step.files}
    assert by_path["run.sh"].mode == 0o750


def test_add_local_dir_loads_ignore_file(
    fake_imagebuilder, _stub_put_request, tmp_path
):
    src = tmp_path / "tree"
    src.mkdir()
    (src / "keep.txt").write_bytes(b"keep")
    (src / "drop.log").write_bytes(b"drop")

    ignore_file = tmp_path / ".sailignore"
    ignore_file.write_text("*.log\n")

    image = Image.debian_arm64.add_local_dir(src, "/app", ignore=ignore_file)

    rel_paths = [
        f.relative_path for f in image.to_proto().build_steps[0].add_local_dir.files
    ]
    assert rel_paths == ["keep.txt"]


def test_add_local_dir_strips_trailing_slash(
    fake_imagebuilder, _stub_put_request, tmp_path
):
    src = tmp_path / "tree"
    src.mkdir()
    (src / "f.txt").write_bytes(b"f")

    image = Image.debian_arm64.add_local_dir(src, "/app/")
    step = image.to_proto().build_steps[0].add_local_dir
    assert step.remote_path == "/app"


def test_add_local_dir_rejects_missing_dir(fake_imagebuilder, tmp_path):
    with pytest.raises(ValueError, match="does not exist"):
        Image.debian_arm64.add_local_dir(tmp_path / "missing", "/app")


def test_add_local_dir_rejects_relative_remote_path(
    fake_imagebuilder, _stub_put_request, tmp_path
):
    src = tmp_path / "tree"
    src.mkdir()
    (src / "f.txt").write_bytes(b"f")
    with pytest.raises(ValueError, match="must be absolute"):
        Image.debian_arm64.add_local_dir(src, "relative/dst")


def test_add_local_dir_rejects_empty_after_ignore(
    fake_imagebuilder, _stub_put_request, tmp_path
):
    src = tmp_path / "tree"
    src.mkdir()
    (src / "drop.log").write_bytes(b"drop")
    with pytest.raises(ValueError, match="after applying ignore patterns"):
        Image.debian_arm64.add_local_dir(src, "/app", ignore=["*.log"])


def test_add_local_dir_rejects_empty_dir_without_ignore(
    fake_imagebuilder, _stub_put_request, tmp_path
):
    """An empty dir with no ignore arg shouldn't blame patterns the user didn't pass."""
    src = tmp_path / "tree"
    src.mkdir()
    with pytest.raises(ValueError, match="no files"):
        Image.debian_arm64.add_local_dir(src, "/app")


def test_add_local_dir_rejects_root_remote_path(
    fake_imagebuilder, _stub_put_request, tmp_path
):
    """Mounting at '/' would clobber the rootfs — refuse the typo."""
    src = tmp_path / "tree"
    src.mkdir()
    (src / "f.txt").write_bytes(b"f")
    with pytest.raises(ValueError, match="must not be '/'"):
        Image.debian_arm64.add_local_dir(src, "/")


def test_add_local_dir_negation_reincludes_file_under_ignored_dir(
    fake_imagebuilder, _stub_put_request, tmp_path
):
    """When an ignore spec contains negations, dir-pruning would silently drop
    re-included files; the walker must descend into matched-ignored dirs so
    file-level negations can fire."""
    src = tmp_path / "tree"
    src.mkdir()
    (src / "keep").mkdir()
    (src / "keep" / "needed.txt").write_bytes(b"needed")
    (src / "keep" / "scratch.txt").write_bytes(b"scratch")
    (src / "other.txt").write_bytes(b"other")

    image = Image.debian_arm64.add_local_dir(
        src, "/app", ignore=["*", "!keep/needed.txt"]
    )
    rel_paths = sorted(
        f.relative_path for f in image.to_proto().build_steps[0].add_local_dir.files
    )
    assert rel_paths == ["keep/needed.txt"]


def test_add_local_dir_oversize_file_fails_before_hashing(
    fake_imagebuilder, _stub_put_request, tmp_path, monkeypatch
):
    """A 10 GiB file inside the tree should fast-fail on stat, not be hashed."""
    import sail.image as image_mod

    monkeypatch.setattr(image_mod, "_MAX_LOCAL_FILE_BYTES", 8)
    src = tmp_path / "tree"
    src.mkdir()
    (src / "ok.txt").write_bytes(b"ok")
    (src / "huge.bin").write_bytes(b"x" * 16)

    hash_calls = {"n": 0}
    real_hash = image_mod._hash_file

    def spy_hash(path):
        hash_calls["n"] += 1
        return real_hash(path)

    monkeypatch.setattr(image_mod, "_hash_file", spy_hash)
    with pytest.raises(ValueError, match="exceeds"):
        Image.debian_arm64.add_local_dir(src, "/app")
    assert hash_calls["n"] == 0, "hashed before stat-size check"
    assert fake_imagebuilder.prepare_calls == []


def test_add_local_dir_raises_on_unreadable_subdir(
    fake_imagebuilder, _stub_put_request, tmp_path
):
    """A permission-denied subtree must fail loudly, not silently skip files."""
    src = tmp_path / "tree"
    src.mkdir()
    (src / "ok.txt").write_bytes(b"ok")
    locked = src / "locked"
    locked.mkdir()
    (locked / "hidden.txt").write_bytes(b"hidden")
    locked.chmod(0o000)
    try:
        with pytest.raises(PermissionError):
            Image.debian_arm64.add_local_dir(src, "/app")
    finally:
        # Restore so the tmp_path cleanup can succeed.
        locked.chmod(0o700)


def test_add_local_dir_skips_symlinks(fake_imagebuilder, _stub_put_request, tmp_path):
    """Symlinks are skipped; following them could escape the source root."""
    src = tmp_path / "tree"
    src.mkdir()
    real = tmp_path / "outside.txt"
    real.write_bytes(b"outside")
    (src / "real.txt").write_bytes(b"inside")
    (src / "link.txt").symlink_to(real)

    image = Image.debian_arm64.add_local_dir(src, "/app")
    rel_paths = [
        f.relative_path for f in image.to_proto().build_steps[0].add_local_dir.files
    ]
    assert rel_paths == ["real.txt"]


# --- terminate ---


def test_terminate(fake_scheduler):
    _, _worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )
    # Should not raise.
    sb.terminate()


def test_terminate_already_terminated_is_noop(already_terminated_scheduler):
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    sb.terminate()


def test_terminate_missing_sailbox_is_noop(missing_terminate_scheduler):
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    sb.terminate()


def test_terminate_route_404_raises(fake_scheduler, monkeypatch):
    # A 404 without `type=not_found_error` (e.g. old backend missing the
    # endpoint, gateway misroute) must NOT be swallowed — otherwise mixed-
    # version deploys would silently leave sailboxes running.
    _, _worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    def fake_post(self, path, body, headers=None, timeout=None):
        return 404, {"error": {"message": "404 page not found"}}

    monkeypatch.setattr("sail._http_client.HTTPClient.post", fake_post, raising=True)

    with pytest.raises(SailboxCreationError):
        sb.terminate()


# --- pause/resume ---


def test_pause_calls_scheduler(fake_scheduler):
    scheduler, _worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    sb.pause()

    assert scheduler.last_stop_request is not None
    assert scheduler.last_stop_request.sailbox_id == "sb-test-123"
    assert not scheduler.last_stop_request.wake_on_traffic
    assert sb.status == "paused"


def test_sleep_calls_scheduler_with_wake_on_traffic(fake_scheduler):
    scheduler, _worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    sb.sleep()

    assert scheduler.last_stop_request is not None
    assert scheduler.last_stop_request.sailbox_id == "sb-test-123"
    assert scheduler.last_stop_request.wake_on_traffic
    assert sb.status == "sleeping"


def test_exec_rejects_paused_handle(fake_scheduler):
    _scheduler, _worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    sb.pause()

    with pytest.raises(SailboxExecutionError, match="call resume\\(\\) before exec"):
        sb.exec("echo hi")


def test_checkpoint_calls_scheduler(fake_scheduler):
    scheduler, _worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    sb.checkpoint()

    assert scheduler.last_checkpoint_request is not None
    assert scheduler.last_checkpoint_request.sailbox_id == "sb-test-123"


def test_resume_calls_scheduler(fake_scheduler):
    scheduler, _worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )
    assert sb.exec_endpoint != "", "fake create should populate exec_endpoint"

    started = sb.resume()

    assert scheduler.last_resume_request is not None
    assert scheduler.last_resume_request.sailbox_id == "sb-test-123"
    assert started is sb
    assert started.status == "running"
    assert sb.status == "running"
    # Resume refreshes exec_endpoint from the response so a sailbox that resumed
    # onto a different worker reaches the right workerproxy on the next call.
    assert sb.exec_endpoint == scheduler.worker_address


def test_resume_terminated_sailbox_raises(terminated_resume_scheduler):
    # Real backend returns 200 + resume_state=terminal_unavailable for
    # resume-of-terminated (not an error status code), so the SDK must
    # raise from the resume_state branch rather than from _raise_for_status.
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    with pytest.raises(SailboxCreationError, match="cannot be resumed"):
        sb.resume()


# --- auth ---


def _function_success_stdout(value, *, stdout: str = "", stderr: str = "") -> str:
    envelope = {
        "ok": True,
        "result": b64encode(cloudpickle.dumps(value)).decode("ascii"),
        "stdout": stdout,
        "stderr": stderr,
    }
    return FUNCTION_RESULT_PREFIX + json.dumps(envelope, separators=(",", ":")) + "\n"


def _function_runtime_stdout(
    python: str = "/usr/local/bin/python3",
    *,
    version: str = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
) -> str:
    envelope = {"python": python, "version": version}
    return FUNCTION_RUNTIME_PREFIX + json.dumps(envelope, separators=(",", ":")) + "\n"


def _function_error_stdout(
    *,
    error_type: str = "ValueError",
    error_message: str = "bad value",
    stdout: str = "",
    stderr: str = "",
) -> str:
    envelope = {
        "ok": False,
        "error_type": error_type,
        "error_message": error_message,
        "traceback": "Traceback (most recent call last):\nValueError: bad value\n",
        "stdout": stdout,
        "stderr": stderr,
    }
    return FUNCTION_RESULT_PREFIX + json.dumps(envelope, separators=(",", ":")) + "\n"


def _function_test_image():
    image = Image.debian_amd64.run_commands("true")
    return ImageDefinition(image.to_proto(), _image_id="sha256:test-function-image")


def test_bearer_token_sent(fake_scheduler):
    fake_scheduler, _ = fake_scheduler
    Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    assert fake_scheduler.last_metadata.get("authorization") == "Bearer test_key_123"


def test_exec_and_wait(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    req = sb.exec("echo hi", timeout=5)
    result = req.wait()

    assert req.exec_request_id == "exec-123"
    assert worker.last_exec_request.argv == ["/bin/sh", "-lc", "echo hi"]
    assert worker.last_metadata.get("authorization") == "Bearer test_key_123"
    assert result.stdout == "hi\n"
    assert result.stderr == ""
    assert result.returncode == 0


def test_exec_retries_transient_accept_error_with_idempotency_key(
    fake_scheduler, monkeypatch
):
    _scheduler, worker = fake_scheduler
    monkeypatch.setattr("sail.sailbox.time.sleep", lambda _seconds: None)
    worker.exec_errors = [(grpc.StatusCode.UNAVAILABLE, "Endpoint closing")]
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    req = sb.exec("cat /tmp/progress.json", idempotency_key="poll-1")

    assert req.exec_request_id == "exec-123"
    assert req.idempotency_key == "poll-1"
    assert len(worker.exec_requests) == 2
    assert [request.idempotency_key for request in worker.exec_requests] == [
        "poll-1",
        "poll-1",
    ]


def test_exec_generates_idempotency_key(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    req = sb.exec("echo hi")

    assert req.idempotency_key.startswith("exec_")
    assert worker.last_exec_request.idempotency_key == req.idempotency_key


def test_wait_retries_transient_error(fake_scheduler, monkeypatch):
    _scheduler, worker = fake_scheduler
    monkeypatch.setattr("sail.sailbox.time.sleep", lambda _seconds: None)
    worker.wait_errors = [(grpc.StatusCode.UNAVAILABLE, "Endpoint closing")]
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    result = sb.exec("echo hi").wait()

    assert result.stdout == "hi\n"
    assert worker.wait_call_count == 2


def test_exec_without_timeout_sends_zero(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    req = sb.exec("echo hi")

    assert req.background is False
    assert worker.last_exec_request.timeout_seconds == 0


def test_background_exec_wraps_command(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    req = sb.exec("python3 -m http.server 3000", background=True)

    assert req.background is True
    assert worker.last_exec_request.timeout_seconds == 0
    assert worker.last_exec_request.argv == [
        "/bin/sh",
        "-lc",
        "nohup /bin/sh -lc 'python3 -m http.server 3000' </dev/null >/dev/null 2>&1 &",
    ]


def test_exec_supports_cwd(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    sb.exec("python3 -m http.server 3000", cwd="/srv/app")

    assert worker.last_exec_request.argv == [
        "/bin/sh",
        "-lc",
        "cd /srv/app && exec /bin/sh -lc 'python3 -m http.server 3000'",
    ]


def test_background_exec_supports_cwd(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    sb.exec("python3 -m http.server 3000", background=True, cwd="/srv/app")

    assert worker.last_exec_request.argv == [
        "/bin/sh",
        "-lc",
        "nohup /bin/sh -lc 'cd /srv/app && exec /bin/sh -lc '\"'\"'python3 -m http.server 3000'\"'\"'' </dev/null >/dev/null 2>&1 &",
    ]


def test_function_decorator_forms():
    @function
    def plain():
        return "plain"

    @function()
    def called():
        return "called"

    assert isinstance(plain, SailFunction)
    assert isinstance(called, SailFunction)
    assert plain() == "plain"
    assert called() == "called"


def test_function_exec_returns_value(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=_function_test_image(),
        name="sandbox-1",
    )
    worker.wait_stdout_sequence = [
        _function_runtime_stdout(),
        _function_success_stdout({"sum": 5}),
    ]

    @function()
    def add(x, y):
        return {"sum": x + y}

    result = sb.exec(add, 2, 3, timeout=5, idempotency_key="fn-add")

    assert result == {"sum": 5}
    assert len(worker.exec_requests) == 2
    assert "cloudpickle==3.1.2" in worker.exec_requests[0].argv[2]
    assert (
        f"target = '{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}'"
        in worker.exec_requests[0].argv[2]
    )
    assert "uv python install" not in worker.exec_requests[0].argv[2]
    assert worker.exec_requests[1].timeout_seconds == 5
    assert worker.exec_requests[1].idempotency_key == "fn-add"
    assert worker.exec_requests[1].argv[2].startswith("/usr/local/bin/python3 - <<")
    assert "__SAIL_FUNCTION_RESULT__" in worker.exec_requests[1].argv[2]


def test_function_exec_works_on_base_image(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )
    worker.wait_stdout_sequence = [
        _function_runtime_stdout(),
        _function_success_stdout(7),
    ]

    @function()
    def value():
        return 7

    assert sb.exec(value) == 7
    assert len(worker.exec_requests) == 2


def test_function_exec_tolerates_patch_version_difference(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )
    guest_version = f"{sys.version_info.major}.{sys.version_info.minor}.999"
    worker.wait_stdout_sequence = [
        _function_runtime_stdout(version=guest_version),
        _function_success_stdout(1),
    ]

    @function()
    def value():
        return 1

    assert sb.exec(value) == 1


def test_function_exec_raises_on_python_version_mismatch(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )
    local = (
        f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    )
    mismatched_minor = sys.version_info.minor + 1
    guest_version = f"{sys.version_info.major}.{mismatched_minor}.0"
    worker.wait_stdout_sequence = [_function_runtime_stdout(version=guest_version)]

    @function()
    def value():
        return 1

    with pytest.raises(SailboxFunctionSerializationError) as exc:
        sb.exec(value)
    assert local in str(exc.value)
    assert guest_version in str(exc.value)


def test_function_exec_supports_args_and_kwargs(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=_function_test_image(),
        name="sandbox-1",
    )
    worker.wait_stdout_sequence = [
        _function_runtime_stdout(),
        _function_success_stdout("hello bob"),
    ]

    @function()
    def greet(name, *, prefix):
        return f"{prefix} {name}"

    assert sb.exec(greet, args=("bob",), kwargs={"prefix": "hello"}) == "hello bob"


def test_function_exec_caches_runtime_setup_per_sailbox(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=_function_test_image(),
        name="sandbox-1",
    )
    worker.wait_stdout_sequence = [
        _function_runtime_stdout(),
        _function_success_stdout(1),
        _function_success_stdout(2),
    ]

    @function()
    def value():
        return 1

    assert sb.exec(value) == 1
    assert sb.exec(value) == 2
    assert len(worker.exec_requests) == 3
    assert sum("cloudpickle==3.1.2" in req.argv[2] for req in worker.exec_requests) == 1


def test_function_exec_rejects_background(fake_scheduler):
    _scheduler, _worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=_function_test_image(),
        name="sandbox-1",
    )

    @function()
    def add():
        return 1

    with pytest.raises(ValueError, match="background=True"):
        sb.exec(add, background=True)


def test_function_exec_rejects_undecorated_callable(fake_scheduler):
    _scheduler, _worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    def add():
        return 1

    with pytest.raises(TypeError, match="@sail.function"):
        sb.exec(add)  # type: ignore[arg-type]


def test_function_exec_setup_failure_raises(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=_function_test_image(),
        name="sandbox-1",
    )
    worker.wait_returncode_sequence = [1]
    worker.wait_stderr_sequence = ["pip failed"]

    @function()
    def add():
        return 1

    with pytest.raises(SailboxFunctionSerializationError, match="pip failed"):
        sb.exec(add)


def test_function_exec_setup_failure_can_retry_with_fresh_idempotency_key(
    fake_scheduler,
):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=_function_test_image(),
        name="sandbox-1",
    )
    worker.wait_returncode_sequence = [1, 0, 0]
    worker.wait_stderr_sequence = ["pip failed", "", ""]
    worker.wait_stdout_sequence = [
        "",
        _function_runtime_stdout(),
        _function_success_stdout(1),
    ]

    @function()
    def add():
        return 1

    with pytest.raises(SailboxFunctionSerializationError, match="pip failed"):
        sb.exec(add)

    assert sb.exec(add) == 1
    setup_requests = [
        request
        for request in worker.exec_requests
        if "cloudpickle==3.1.2" in request.argv[2]
    ]
    assert len(setup_requests) == 2
    assert setup_requests[0].idempotency_key != setup_requests[1].idempotency_key
    assert all(
        request.idempotency_key.startswith("exec_") for request in setup_requests
    )


def test_function_exec_remote_exception_raises(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=_function_test_image(),
        name="sandbox-1",
    )
    worker.wait_stdout_sequence = [
        _function_runtime_stdout(),
        _function_error_stdout(stdout="before\n", stderr="warn\n"),
    ]

    @function()
    def bad():
        raise ValueError("bad value")

    with pytest.raises(SailboxFunctionError, match="ValueError: bad value") as exc:
        sb.exec(bad)

    assert exc.value.error_type == "ValueError"
    assert exc.value.stdout == "before\n"
    assert exc.value.stderr == "warn\n"
    assert "Traceback" in exc.value.traceback


def test_function_exec_invalid_envelope_raises(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=_function_test_image(),
        name="sandbox-1",
    )
    worker.wait_stdout_sequence = [_function_runtime_stdout(), "not an envelope\n"]
    worker.wait_stderr_sequence = ["", "ModuleNotFoundError: cloudpickle"]
    worker.wait_returncode_sequence = [0, 1]

    @function()
    def add():
        return 1

    with pytest.raises(
        SailboxFunctionSerializationError, match="valid result envelope"
    ):
        sb.exec(add)


def test_exec_already_running_raises(worker_error_scheduler):
    _scheduler, _worker = worker_error_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    with pytest.raises(SailboxExecAlreadyRunningError):
        sb.exec("echo hi", timeout=5)


def test_wait_missing_exec_request_raises(missing_wait_scheduler):
    _scheduler, _worker = missing_wait_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )
    req = sb.exec("echo hi", timeout=5)
    missing_req = SailboxExecRequest(
        sailbox_id=req.sailbox_id,
        exec_request_id="missing",
        exec_endpoint=req.exec_endpoint,
    )

    with pytest.raises(SailboxExecRequestNotFoundError):
        missing_req.wait()


def test_exec_on_terminated_sailbox_raises(terminated_worker_scheduler):
    _scheduler, _worker = terminated_worker_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    with pytest.raises(
        SailboxTerminatedError,
        match="this is likely because this Sailbox is no longer running",
    ):
        sb.exec("echo hi", timeout=5)


# --- config ---


def test_config_from_env(monkeypatch):
    monkeypatch.setenv("SAIL_IMAGEBUILDER_URL", "imagebuilder.example.com:9091")
    monkeypatch.setenv("SAIL_API_KEY", "key_abc")
    cfg = Config.from_env()
    assert cfg.imagebuilder_url == "imagebuilder.example.com:9091"
    assert cfg.api_key == "key_abc"


def test_config_rejects_unrecognized_mode(monkeypatch):
    monkeypatch.setenv("SAIL_MODE", "deev")
    monkeypatch.setenv("SAIL_API_KEY", "key_abc")
    with pytest.raises(ValueError, match="SAIL_MODE"):
        Config.from_env()


def test_config_accepts_imagebuilder_override(monkeypatch):
    monkeypatch.setenv("SAIL_IMAGEBUILDER_URL", "imagebuilder.example.com:9091")
    monkeypatch.delenv("SAIL_MODE", raising=False)
    monkeypatch.setenv("SAIL_API_KEY", "key_abc")
    cfg = Config.from_env()
    assert cfg.imagebuilder_url == "imagebuilder.example.com:9091"


def test_config_defaults_to_prod(monkeypatch):
    monkeypatch.delenv("SAIL_IMAGEBUILDER_URL", raising=False)
    monkeypatch.delenv("SAIL_API_URL", raising=False)
    monkeypatch.setenv("SAIL_API_KEY", "key_abc")
    monkeypatch.delenv("SAIL_MODE", raising=False)
    cfg = Config.from_env()
    assert (
        cfg.imagebuilder_url == "sailbox-imagebuilder-dispatcher.sailresearch.com:443"
    )
    assert cfg.api_url == "https://api.sailresearch.com"
    assert cfg.sailbox_ingress_url == "https://api.sailresearch.com"


def test_config_uses_prod_mode_defaults(monkeypatch):
    monkeypatch.delenv("SAIL_IMAGEBUILDER_URL", raising=False)
    monkeypatch.delenv("SAIL_API_URL", raising=False)
    monkeypatch.setenv("SAIL_MODE", "prod")
    monkeypatch.setenv("SAIL_API_KEY", "key_abc")
    cfg = Config.from_env()
    assert (
        cfg.imagebuilder_url == "sailbox-imagebuilder-dispatcher.sailresearch.com:443"
    )
    assert cfg.api_url == "https://api.sailresearch.com"
    assert cfg.sailbox_ingress_url == "https://api.sailresearch.com"


def test_config_uses_dev_mode_defaults(monkeypatch):
    monkeypatch.delenv("SAIL_IMAGEBUILDER_URL", raising=False)
    monkeypatch.delenv("SAIL_API_URL", raising=False)
    monkeypatch.setenv("SAIL_MODE", "dev")
    monkeypatch.setenv("SAIL_API_KEY", "key_abc")
    cfg = Config.from_env()
    assert (
        cfg.imagebuilder_url
        == "sailbox-imagebuilder-dispatcher.dev.sailresearch.com:443"
    )
    assert cfg.api_url == "https://dev.sailresearch.com"
    assert cfg.sailbox_ingress_url == "https://dev.sailresearch.com"


def test_config_uses_staging_mode_defaults(monkeypatch):
    monkeypatch.delenv("SAIL_IMAGEBUILDER_URL", raising=False)
    monkeypatch.delenv("SAIL_API_URL", raising=False)
    monkeypatch.setenv("SAIL_MODE", "staging")
    monkeypatch.setenv("SAIL_API_KEY", "key_abc")
    cfg = Config.from_env()
    assert (
        cfg.imagebuilder_url
        == "sailbox-imagebuilder-dispatcher.staging.sailresearch.com:443"
    )
    assert cfg.api_url == "https://staging.sailresearch.com"
    assert cfg.sailbox_ingress_url == "https://staging.sailresearch.com"


def test_config_api_url_override_drives_ingress_when_coupled(monkeypatch):
    """In prod/dev/staging the API and ingress share a host, so a single
    SAIL_API_URL points both at a self-hosted cluster."""
    monkeypatch.setenv("SAIL_API_URL", "https://self-hosted.example.com")
    monkeypatch.setenv("SAIL_MODE", "dev")
    monkeypatch.setenv("SAIL_API_KEY", "key_abc")
    cfg = Config.from_env()
    assert cfg.api_url == "https://self-hosted.example.com"
    assert cfg.sailbox_ingress_url == "https://self-hosted.example.com"


def test_config_uses_local_mode_defaults(monkeypatch):
    monkeypatch.delenv("SAIL_IMAGEBUILDER_URL", raising=False)
    monkeypatch.delenv("SAIL_API_URL", raising=False)
    monkeypatch.setenv("SAIL_MODE", "local")
    monkeypatch.setenv("SAIL_API_KEY", "key_abc")
    cfg = Config.from_env()
    assert cfg.imagebuilder_url == "localhost:50061"
    # api_url targets the local backend so HTTP lifecycle ops stay aligned
    # with the local sailbox ingress tunnel.
    assert cfg.api_url == "http://localhost:8080"
    assert cfg.sailbox_ingress_url == "http://localhost:18080"


def test_config_local_mode_api_url_override_keeps_local_ingress(monkeypatch):
    monkeypatch.delenv("SAIL_IMAGEBUILDER_URL", raising=False)
    monkeypatch.setenv("SAIL_MODE", "local")
    monkeypatch.setenv("SAIL_API_URL", "https://remote-api.example.com")
    monkeypatch.setenv("SAIL_API_KEY", "key_abc")
    cfg = Config.from_env()
    assert cfg.api_url == "https://remote-api.example.com"
    assert cfg.sailbox_ingress_url == "http://localhost:18080"


def test_config_missing_key_raises(monkeypatch):
    monkeypatch.setenv("SAIL_IMAGEBUILDER_URL", "host:5678")
    monkeypatch.delenv("SAIL_API_KEY", raising=False)
    with pytest.raises(ValueError, match="SAIL_API_KEY must be set"):
        Config.from_env()


# --- client singleton ---


def test_client_singleton(fake_scheduler):
    a = Client.get()
    b = Client.get()
    assert a is b

    Client.reset()
    assert Client._instance is None


class FakeAPIHandler(BaseHTTPRequestHandler):
    """HTTP handler that returns canned responses for the public API."""

    server: HTTPServer
    response_status: int
    response_body: dict
    last_headers: dict
    last_body: dict
    last_path: str

    def do_POST(self):
        content_length = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(content_length)) if content_length else {}
        self.server.last_headers = dict(self.headers)
        self.server.last_body = body
        self.server.last_path = self.path

        status = self.server.response_status
        resp = json.dumps(self.server.response_body).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(resp)

    def do_GET(self):
        self.server.last_headers = dict(self.headers)
        self.server.last_path = self.path

        status = self.server.response_status
        resp = json.dumps(self.server.response_body).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(resp)

    def log_message(self, format, *args):
        pass


@pytest.fixture()
def fake_api(monkeypatch, _stub_imagebuilder_env):
    """Start a local HTTP server and configure SAIL_API_URL to point at it."""
    server = HTTPServer(("127.0.0.1", 0), FakeAPIHandler)
    server.response_status = 200
    server.response_body = {}
    server.last_headers = {}
    server.last_body = {}
    server.last_path = ""

    t = threading.Thread(target=server.serve_forever)
    t.daemon = True
    t.start()

    port = server.server_address[1]
    monkeypatch.setenv("SAIL_API_KEY", "test_key_456")
    monkeypatch.setenv("SAIL_API_URL", f"http://127.0.0.1:{port}")
    yield server
    server.shutdown()


@pytest.fixture(autouse=True)
def _reset_http_client():
    """Ensure the HTTP singleton is reset between tests."""
    yield
    HTTPClient.reset()


def test_app_find_existing(fake_api):
    fake_api.response_status = 200
    fake_api.response_body = {
        "id": "app_abc",
        "name": "my-app",
        "created_at": 1712102400,
    }

    app = App.find(name="my-app")

    assert app.id == "app_abc"
    assert app.name == "my-app"
    assert app.created_at == 1712102400


def test_app_find_mint_if_missing(fake_api):
    fake_api.response_status = 201
    fake_api.response_body = {
        "id": "app_new",
        "name": "new-app",
        "created_at": 1712102500,
    }

    app = App.find(name="new-app", mint_if_missing=True)

    assert app.id == "app_new"
    assert app.name == "new-app"
    assert fake_api.last_body == {"name": "new-app", "mint_if_missing": True}


def test_app_find_not_found(fake_api):
    fake_api.response_status = 404
    fake_api.response_body = {"error": {"message": "app not found"}}

    with pytest.raises(LookupError, match="not found"):
        App.find(name="missing-app")


@pytest.mark.parametrize("status_code", [401, 403])
def test_app_find_auth_failure_raises_permission_error(fake_api, status_code):
    # Keep App.find's error taxonomy aligned with the rest of the SDK: 401/403
    # become PermissionError so callers (notably the CLI's `--app` lookup) can
    # route them through the auth-error path instead of a generic RuntimeError.
    fake_api.response_status = status_code
    fake_api.response_body = {"error": {"message": "missing api key"}}

    with pytest.raises(PermissionError, match="missing api key"):
        App.find(name="any")


def test_app_find_auth_header(fake_api):
    fake_api.response_status = 200
    fake_api.response_body = {"id": "app_x", "name": "x", "created_at": 0}

    App.find(name="x")

    assert fake_api.last_headers.get("Authorization") == "Bearer test_key_456"


def _list_envelope(rows, *, total=None, limit=50, offset=0):
    total = len(rows) if total is None else total
    return {
        "data": rows,
        "limit": limit,
        "offset": offset,
        "total": total,
        "has_more": offset + len(rows) < total,
    }


def _list_row(**overrides):
    row = {
        "sailbox_id": "sb-1",
        "app_id": "app_x",
        "app_name": "demo",
        "name": "sb-1",
        "status": "running",
        "memory_mib": 1024,
        "vcpu_count": 1,
        "state_disk_size_gib": 8,
        "architecture": "arm64",
        "error_message": None,
        "started_at": None,
        "created_at": "2026-05-11T00:00:00Z",
        "updated_at": "2026-05-11T00:00:00Z",
    }
    row.update(overrides)
    return row


def test_sailbox_list_returns_typed_rows(fake_api):
    fake_api.response_status = 200
    fake_api.response_body = _list_envelope(
        [
            _list_row(sailbox_id="sb-a", name="alpha"),
            _list_row(sailbox_id="sb-b", name="beta", status="terminated"),
        ]
    )

    rows = Sailbox.list()

    assert [type(r) for r in rows] == [SailboxInfo, SailboxInfo]
    assert [r.sailbox_id for r in rows] == ["sb-a", "sb-b"]
    assert rows[1].status == "terminated"


def test_sailbox_list_forwards_filters_as_query_string(fake_api):
    fake_api.response_status = 200
    fake_api.response_body = _list_envelope([])

    Sailbox.list(app="app_x", status="running", search="foo", limit=10, offset=20)

    assert fake_api.last_path.startswith("/v1/sailboxes?")
    query = fake_api.last_path.split("?", 1)[1]
    pairs = dict(item.split("=", 1) for item in query.split("&"))
    assert pairs == {
        "limit": "10",
        "offset": "20",
        "app": "app_x",
        "status": "running",
        "search": "foo",
    }


def test_sailbox_list_omits_unspecified_filters(fake_api):
    fake_api.response_status = 200
    fake_api.response_body = _list_envelope([])

    Sailbox.list()

    # Only the always-sent pagination params should appear; None filters must
    # not leak through as empty-string query values.
    query = fake_api.last_path.split("?", 1)[1]
    assert "app=" not in query
    assert "status=" not in query
    assert "search=" not in query


def test_sailbox_list_forbidden_raises_permission_error(fake_api):
    fake_api.response_status = 403
    fake_api.response_body = {
        "error": {"message": "sailboxes require an organization-scoped API key"}
    }

    with pytest.raises(PermissionError, match="organization-scoped"):
        Sailbox.list()


def test_sailbox_list_unauthorized_raises_permission_error(fake_api):
    # PublicAuth returns 401 for missing/invalid API keys. Callers using
    # `except PermissionError` should catch this alongside the 403 path,
    # not see it leak through as a RuntimeError.
    fake_api.response_status = 401
    fake_api.response_body = {
        "error": {"message": "Missing or invalid Authorization header"}
    }

    with pytest.raises(PermissionError, match="Authorization"):
        Sailbox.list()


def test_sailbox_list_server_error_raises_runtime_error(fake_api):
    fake_api.response_status = 500
    fake_api.response_body = {"error": {"message": "boom"}}

    with pytest.raises(RuntimeError, match="boom"):
        Sailbox.list()


def test_sailbox_list_bad_request_raises_value_error(fake_api):
    # Backend returns 400 for out-of-range/non-integer limit/offset. Surface
    # as ValueError so retry-on-RuntimeError loops don't spin on a
    # non-retriable input bug. (Only reachable from direct SDK callers; the
    # CLI clamps via click.IntRange before the request.)
    fake_api.response_status = 400
    fake_api.response_body = {"error": {"message": "limit must be <= 100"}}

    with pytest.raises(ValueError, match="limit must be <= 100"):
        Sailbox.list(limit=999)


def test_sailbox_get_returns_info(fake_api):
    fake_api.response_status = 200
    fake_api.response_body = _list_row(sailbox_id="sb-found", name="needle")

    info = Sailbox.get("sb-found")

    assert isinstance(info, SailboxInfo)
    assert info.sailbox_id == "sb-found"
    assert info.name == "needle"
    assert fake_api.last_path == "/v1/sailboxes/sb-found"


def test_sailbox_get_not_found_raises_lookup_error(fake_api):
    # Wrong-org and unknown id both surface as 404 server-side to avoid
    # leaking ownership. LookupError is the matching exception type so
    # callers can `except LookupError` for "not visible to me" without
    # caring whether the id is wrong or owned by someone else.
    fake_api.response_status = 404
    fake_api.response_body = {"error": {"message": "sailbox not found"}}

    with pytest.raises(LookupError, match="sb-missing"):
        Sailbox.get("sb-missing")


def test_sailbox_get_unauthorized_raises_permission_error(fake_api):
    fake_api.response_status = 401
    fake_api.response_body = {
        "error": {"message": "Missing or invalid Authorization header"}
    }

    with pytest.raises(PermissionError, match="Authorization"):
        Sailbox.get("sb-anything")


def test_sailbox_get_forbidden_raises_permission_error(fake_api):
    fake_api.response_status = 403
    fake_api.response_body = {
        "error": {"message": "sailboxes require an organization-scoped API key"}
    }

    with pytest.raises(PermissionError, match="organization-scoped"):
        Sailbox.get("sb-anything")


def test_sailbox_get_server_error_raises_runtime_error(fake_api):
    fake_api.response_status = 500
    fake_api.response_body = {"error": {"message": "boom"}}

    with pytest.raises(RuntimeError, match="boom"):
        Sailbox.get("sb-anything")


def test_sailbox_get_malformed_id_raises_value_error(fake_api):
    # Backend returns 400 for ids that fail server-side ValidateID. Surface
    # that as ValueError so retry-on-RuntimeError loops don't retry forever
    # against a non-retriable caller bug.
    fake_api.response_status = 400
    fake_api.response_body = {
        "error": {"message": "invalid sailbox id: missing sb_ prefix"}
    }

    with pytest.raises(ValueError, match="missing sb_ prefix"):
        Sailbox.get("not-a-real-id")


def test_config_api_url_optional(monkeypatch):
    """Config provides a default API URL when none is set."""
    monkeypatch.setenv("SAIL_IMAGEBUILDER_URL", "host:5678")
    monkeypatch.setenv("SAIL_API_KEY", "key_abc")
    monkeypatch.delenv("SAIL_MODE", raising=False)
    monkeypatch.delenv("SAIL_API_URL", raising=False)
    cfg = Config.from_env()
    assert cfg.api_url == "https://api.sailresearch.com"


def test_http_client_uses_default_api_url(monkeypatch):
    """HTTPClient falls back to the default API URL when none is set."""
    monkeypatch.setenv("SAIL_IMAGEBUILDER_URL", "host:5678")
    monkeypatch.setenv("SAIL_API_KEY", "key_abc")
    monkeypatch.delenv("SAIL_MODE", raising=False)
    monkeypatch.delenv("SAIL_API_URL", raising=False)
    client = HTTPClient()
    assert client._config.api_url == "https://api.sailresearch.com"


def test_http_client_normalizes_transport_failures(monkeypatch):
    """Transport-level errors (DNS/refused/timeout) surface as 503 envelopes
    so callers' status-based exception mapping turns them into SDK errors
    instead of leaking urllib/socket exceptions."""
    import urllib.error
    import urllib.request

    monkeypatch.setenv("SAIL_API_URL", "http://127.0.0.1:1")
    monkeypatch.setenv("SAIL_API_KEY", "key_abc")
    HTTPClient.reset()

    def boom(*_args, **_kwargs):
        raise urllib.error.URLError("connection refused")

    monkeypatch.setattr(urllib.request, "urlopen", boom)
    status, data = HTTPClient.instance().get("/v1/sailboxes")
    assert status == 503
    assert "connection refused" in data["error"]["message"]


def test_request_returns_response(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    op = sb.request(
        "POST",
        "https://example.com/api",
        json={"hello": "world"},
        idempotency_key="req-1",
    )
    assert op.id == "nr-test-123"
    assert op.status == "NETWORK_REQUEST_STATUS_COMPLETED"
    assert worker.last_network_request.idempotency_key == "req-1"

    refreshed = op.refresh()
    assert refreshed is op
    assert op.status == "NETWORK_REQUEST_STATUS_COMPLETED"
    assert op.response is not None
    assert op.response.json() == {"ok": True}
    assert refreshed.status == "NETWORK_REQUEST_STATUS_COMPLETED"
    assert refreshed.response is not None
    assert refreshed.response.json() == {"ok": True}

    completed = op.wait()
    assert completed is op
    assert op.status == "NETWORK_REQUEST_STATUS_COMPLETED"
    assert op.response is not None
    assert op.response.status_code == 200
    assert op.response.json() == {"ok": True}
    assert completed.status == "NETWORK_REQUEST_STATUS_COMPLETED"
    assert completed.response is not None
    assert completed.response.status_code == 200
    assert completed.response.json() == {"ok": True}


def test_request_cancel_returns_updated_handle(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    op = sb.request("POST", "https://example.com/api", idempotency_key="req-2")
    canceled = op.cancel()

    assert canceled is op
    assert canceled.id == op.id
    assert canceled.status == "NETWORK_REQUEST_STATUS_CANCELED"
    assert canceled.response is None
    assert (
        worker.network_requests[op.id].status
        == workerproxy_pb2.NETWORK_REQUEST_STATUS_CANCELED
    )


def test_request_requires_idempotency_key(fake_scheduler):
    _scheduler, _worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    with pytest.raises(ValueError, match="idempotency_key must be non-empty"):
        sb.request("POST", "https://example.com/api")


def test_listener_lookup(fake_scheduler):
    _scheduler, _worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
        ingress_ports=[3000],
    )

    listener = sb.listener(3000)

    assert listener.port == 3000
    assert listener.url == "https://sb-test-123-3000.sandbox.test"


def test_listener_lookup_uses_ingress_url_fallback(monkeypatch, fake_scheduler):
    _scheduler, worker = fake_scheduler
    worker.listener_public_url = ""
    monkeypatch.setenv("SAIL_MODE", "local")
    Client.reset()
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
        ingress_ports=[3000],
    )

    listener = sb.listener(3000)

    assert listener.url == "http://localhost:18080/_sailbox/sb-test-123/3000"


def test_listener_lookup_not_found_has_actionable_error(fake_scheduler):
    _scheduler, worker = fake_scheduler
    worker.listener_error = (grpc.StatusCode.NOT_FOUND, "listener not found")
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    with pytest.raises(SailboxExecutionError, match=r"pass ingress_ports=\[3000\]"):
        sb.listener(3000)


def test_listener_status_fetches_latest_listener(fake_scheduler):
    _scheduler, worker = fake_scheduler
    worker.listener_statuses = [
        workerproxy_pb2.LISTENER_ROUTE_STATUS_PENDING,
        workerproxy_pb2.LISTENER_ROUTE_STATUS_ACTIVE,
    ]
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
        ingress_ports=[3000],
    )

    listener = sb.listener(3000)
    latest = listener.status()

    assert listener.route_status == "LISTENER_ROUTE_STATUS_PENDING"
    assert latest.route_status == "LISTENER_ROUTE_STATUS_ACTIVE"
    assert worker.listener_call_count == 2


def test_listener_wait_returns_active_listener(monkeypatch, fake_scheduler):
    _scheduler, worker = fake_scheduler
    monkeypatch.setattr(
        "sail.sailbox._listener_url_is_open", lambda *_args, **_kwargs: (True, "")
    )
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
        ingress_ports=[3000],
    )

    listener = sb.listener(3000).wait(timeout=1, poll_interval=0.01)

    assert listener.route_status == "LISTENER_ROUTE_STATUS_ACTIVE"
    assert worker.listener_call_count == 1


def test_listener_wait_polls_until_active(monkeypatch, fake_scheduler):
    _scheduler, worker = fake_scheduler
    worker.listener_statuses = [
        workerproxy_pb2.LISTENER_ROUTE_STATUS_PENDING,
        workerproxy_pb2.LISTENER_ROUTE_STATUS_PENDING,
        workerproxy_pb2.LISTENER_ROUTE_STATUS_ACTIVE,
    ]
    monkeypatch.setattr(
        "sail.sailbox._listener_url_is_open", lambda *_args, **_kwargs: (True, "")
    )
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
        ingress_ports=[3000],
    )
    monkeypatch.setattr("sail.sailbox.time.sleep", lambda _seconds: None)

    listener = sb.listener(3000).wait(timeout=1, poll_interval=0.01)

    assert listener.route_status == "LISTENER_ROUTE_STATUS_ACTIVE"
    assert worker.listener_call_count == 3


def test_listener_wait_times_out(monkeypatch, fake_scheduler):
    _scheduler, worker = fake_scheduler
    worker.listener_statuses = [workerproxy_pb2.LISTENER_ROUTE_STATUS_PENDING]
    monkeypatch.setattr(
        "sail.sailbox._listener_url_is_open", lambda *_args, **_kwargs: (True, "")
    )
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
        ingress_ports=[3000],
    )
    monkeypatch.setattr("sail.sailbox.time.sleep", lambda _seconds: None)

    with pytest.raises(
        TimeoutError, match="last status was LISTENER_ROUTE_STATUS_PENDING"
    ):
        sb.listener(3000).wait(timeout=0.01, poll_interval=0.01)


def test_listener_wait_polls_until_url_is_reachable(monkeypatch, fake_scheduler):
    _scheduler, worker = fake_scheduler
    probe_results = [
        (False, "HTTP 502: upstream unavailable"),
        (True, ""),
    ]
    monkeypatch.setattr(
        "sail.sailbox._listener_url_is_open",
        lambda *_args, **_kwargs: probe_results.pop(0),
    )
    monkeypatch.setattr("sail.sailbox.time.sleep", lambda _seconds: None)
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
        ingress_ports=[3000],
    )

    listener = sb.listener(3000).wait(timeout=1, poll_interval=0.01)

    assert listener.route_status == "LISTENER_ROUTE_STATUS_ACTIVE"
    assert worker.listener_call_count == 2
    assert probe_results == []


def test_listener_wait_validates_arguments(fake_scheduler):
    _scheduler, _worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
        ingress_ports=[3000],
    )
    listener = sb.listener(3000)

    with pytest.raises(ValueError, match="timeout must be positive"):
        listener.wait(timeout=0)
    with pytest.raises(ValueError, match="poll_interval must be positive"):
        listener.wait(poll_interval=0)


def test_sailbox_create_accepts_app_object(fake_scheduler):
    app = App(id="app_test", name="test-app", created_at=0)
    sb = Sailbox.create(app=app, image=Image.debian_amd64, name="sandbox-1")
    assert sb.sailbox_id == "sb-test-123"
