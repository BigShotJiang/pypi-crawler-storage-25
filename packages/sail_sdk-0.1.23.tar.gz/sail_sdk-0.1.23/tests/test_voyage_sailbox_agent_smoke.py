from __future__ import annotations

import importlib.util
from pathlib import Path
from types import SimpleNamespace

import pytest

EXAMPLE_PATH = (
    Path(__file__).resolve().parents[1] / "examples" / "voyage_sailbox_agent_smoke.py"
)


def load_example():
    spec = importlib.util.spec_from_file_location(
        "voyage_sailbox_agent_smoke",
        EXAMPLE_PATH,
    )
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


class FakeVoyage:
    def __init__(self, *, sailbox_id, fail_error=None, operations=None):
        self.id = "voy_00000000-0000-0000-0000-000000000005"
        self.dashboard_url = "https://app.sailresearch.com/staging/voyages/" + self.id
        self.sailbox_id = sailbox_id
        self.fail_error = fail_error
        self.operations = operations if operations is not None else []
        self.events = []
        self.completed = None
        self.failed = None

    def headers(self, existing=None):
        result = dict(existing or {})
        result["X-Sail-Voyage-Id"] = self.id
        return result

    def event(self, kind, **kwargs):
        self.operations.append(f"voyage.event:{kind}")
        self.events.append((kind, kwargs))

    def span(self, *args, **kwargs):
        self.operations.append(f"voyage.span:{args[0] if args else ''}")
        self.events.append(("span", {"args": args, "kwargs": kwargs}))
        return _NoopContext()

    def agent(self, *args, **kwargs):
        self.operations.append(f"voyage.agent:{args[0] if args else ''}")
        self.events.append(("agent", {"args": args, "kwargs": kwargs}))
        return _NoopContext()

    def complete(self, **kwargs):
        self.operations.append("voyage.complete")
        self.completed = kwargs

    def fail(self, **kwargs):
        self.operations.append("voyage.fail")
        if self.fail_error is not None:
            raise self.fail_error
        self.failed = kwargs


class _NoopContext:
    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False


class FakeVoyageModule:
    def __init__(self, *, fail_error=None, operations=None):
        self.init_calls = []
        self.current = None
        self.fail_error = fail_error
        self.operations = operations if operations is not None else []

    def init(self, **kwargs):
        self.operations.append("voyage.init")
        self.init_calls.append(kwargs)
        self.current = FakeVoyage(
            sailbox_id=kwargs.get("sailbox_id"),
            fail_error=self.fail_error,
            operations=self.operations,
        )
        return self.current

    def headers(self, existing=None):
        if self.current is None:
            return dict(existing or {})
        return self.current.headers(existing)


class FakeExecRequest:
    exec_request_id = "exec_123"

    def __init__(self, result, operations):
        self._result = result
        self._operations = operations

    def wait(self):
        self._operations.append("exec.wait")
        return self._result


class FakeSailbox:
    sailbox_id = "sbx_phase5"

    def __init__(self, *, result, operations, terminate_error=None):
        self.result = result
        self.operations = operations
        self.terminate_error = terminate_error
        self.commands = []
        self.terminated = False

    def exec(self, command, **kwargs):
        self.operations.append("sailbox.exec")
        self.commands.append((command, kwargs))
        return FakeExecRequest(self.result, self.operations)

    def terminate(self):
        self.operations.append("sailbox.terminate")
        if self.terminate_error is not None:
            raise self.terminate_error
        self.terminated = True


class FakeSail:
    def __init__(
        self,
        *,
        exec_returncode=0,
        inference_error=None,
        voyage_fail_error=None,
        terminate_error=None,
    ):
        self.operations = []
        self.app_find_calls = []
        self.sailbox_create_calls = []
        self.voyage = FakeVoyageModule(
            fail_error=voyage_fail_error,
            operations=self.operations,
        )
        self.created_sailbox = None
        self.inference_error = inference_error
        self.terminate_error = terminate_error
        self.inference_calls = []
        self.Image = SimpleNamespace(debian_arm64="debian-arm64")
        result = SimpleNamespace(
            stdout=(
                "ok\n"
                "Bearer secret-token\n"
                "sk_1234567890abcdef\n"
                "sr-151fac87cde38a2c236ba87a6c20d07d\n"
            ),
            stderr="SAIL_API_KEY=sk_abcdef1234567890\n",
            returncode=exec_returncode,
        )
        self._exec_result = result

        fake = self

        class App:
            @staticmethod
            def find(**kwargs):
                fake.operations.append("app.find")
                fake.app_find_calls.append(kwargs)
                return SimpleNamespace(id="app_123", name=kwargs["name"])

        class Sailbox:
            @staticmethod
            def create(**kwargs):
                fake.operations.append("sailbox.create")
                fake.sailbox_create_calls.append(kwargs)
                fake.created_sailbox = FakeSailbox(
                    result=fake._exec_result,
                    operations=fake.operations,
                    terminate_error=fake.terminate_error,
                )
                return fake.created_sailbox

        class Responses:
            @staticmethod
            def create(**kwargs):
                fake.operations.append("inference.responses.create")
                fake.inference_calls.append(kwargs)
                if fake.inference_error is not None:
                    raise fake.inference_error
                headers = fake.voyage.headers({})
                assert headers["X-Sail-Voyage-Id"] == fake.voyage.current.id
                return {"id": "resp_123"}

        self.App = App
        self.Sailbox = Sailbox
        self.inference = SimpleNamespace(responses=Responses)


def test_main_without_live_guard_does_not_touch_sail(monkeypatch, capsys):
    module = load_example()
    fake_sail = FakeSail()
    monkeypatch.setattr(module, "sail", fake_sail)
    monkeypatch.delenv("SAIL_PHASE5_LIVE", raising=False)
    monkeypatch.setenv("SAIL_API_KEY", "sk_1234567890abcdef")

    assert module.main() == 2

    captured = capsys.readouterr()
    assert "SAIL_PHASE5_LIVE=1" in captured.out
    assert fake_sail.app_find_calls == []
    assert fake_sail.sailbox_create_calls == []


def test_run_smoke_requires_api_key_before_live_calls(monkeypatch):
    module = load_example()
    fake_sail = FakeSail()
    monkeypatch.setattr(module, "sail", fake_sail)

    with pytest.raises(RuntimeError, match="SAIL_API_KEY is required"):
        module.run_smoke({"SAIL_PHASE5_LIVE": "1"})

    assert fake_sail.app_find_calls == []
    assert fake_sail.sailbox_create_calls == []


def test_run_smoke_honors_explicit_empty_environ(monkeypatch):
    module = load_example()
    fake_sail = FakeSail()
    monkeypatch.setattr(module, "sail", fake_sail)
    monkeypatch.setenv("SAIL_PHASE5_LIVE", "1")
    monkeypatch.setenv("SAIL_API_KEY", "sk_1234567890abcdef")

    with pytest.raises(RuntimeError, match="SAIL_PHASE5_LIVE=1 is required"):
        module.run_smoke({})

    assert fake_sail.app_find_calls == []
    assert fake_sail.sailbox_create_calls == []


def test_run_smoke_success_records_voyage_sailbox_and_redacted_output(monkeypatch):
    module = load_example()
    fake_sail = FakeSail()
    monkeypatch.setattr(module, "sail", fake_sail)
    monkeypatch.setattr(module.time, "time", lambda: 1234567890)
    ticks = iter([10.0, 10.125])
    monkeypatch.setattr(module.time, "monotonic", lambda: next(ticks))

    result = module.run_smoke(
        {
            "SAIL_PHASE5_LIVE": "1",
            "SAIL_API_KEY": "sk_1234567890abcdef",
            "SAIL_PHASE5_MODEL": "model/test",
        }
    )

    assert fake_sail.app_find_calls == [
        {"name": "phase5-sailbox-voyage-smoke", "mint_if_missing": True}
    ]
    assert fake_sail.sailbox_create_calls[0]["image"] == "debian-arm64"
    assert fake_sail.sailbox_create_calls[0]["memory_mib"] == 1024
    assert fake_sail.voyage.init_calls[0]["sailbox_id"] == "sbx_phase5"
    assert fake_sail.voyage.init_calls[0]["metadata"]["phase"] == "5"
    assert fake_sail.inference_calls[0]["model"] == "model/test"
    assert fake_sail.created_sailbox.terminated is True
    assert fake_sail.operations.index("sailbox.terminate") < fake_sail.operations.index(
        "voyage.complete"
    )

    command, exec_kwargs = fake_sail.created_sailbox.commands[0]
    assert "SAIL_API_KEY" not in command
    assert "sk_" not in command
    assert exec_kwargs["timeout"] == 30

    voyage = fake_sail.voyage.current
    assert voyage.completed["payload"]["sailbox_id"] == "sbx_phase5"
    assert voyage.failed is None
    completed_events = [
        event for event in voyage.events if event[0] == "sailbox.exec.completed"
    ]
    assert len(completed_events) == 1
    payload = completed_events[0][1]["payload"]
    assert payload["exec_request_id"] == "exec_123"
    assert payload["returncode"] == 0
    assert payload["duration_ms"] == 125
    assert "secret-token" not in payload["stdout_tail"]["text"]
    assert "sk_1234567890abcdef" not in payload["stdout_tail"]["text"]
    assert "sr-151fac87cde38a2c236ba87a6c20d07d" not in payload["stdout_tail"]["text"]
    assert "sk_abcdef1234567890" not in payload["stderr_tail"]["text"]
    assert result["dashboard_url"] == voyage.dashboard_url
    assert result["sailbox_id"] == "sbx_phase5"


def test_run_smoke_rejects_non_sk_key_before_live_calls(monkeypatch):
    module = load_example()
    fake_sail = FakeSail()
    monkeypatch.setattr(module, "sail", fake_sail)

    with pytest.raises(RuntimeError, match="org-bearing sk_ key"):
        module.run_smoke(
            {
                "SAIL_PHASE5_LIVE": "1",
                "SAIL_API_KEY": "sr-151fac87cde38a2c236ba87a6c20d07d",
            }
        )

    assert fake_sail.app_find_calls == []
    assert fake_sail.sailbox_create_calls == []


def test_run_smoke_rejects_stale_voyage_id_before_live_calls(monkeypatch):
    module = load_example()
    fake_sail = FakeSail()
    monkeypatch.setattr(module, "sail", fake_sail)

    with pytest.raises(RuntimeError, match="SAIL_VOYAGE_ID must be unset"):
        module.run_smoke(
            {
                "SAIL_PHASE5_LIVE": "1",
                "SAIL_API_KEY": "sk_1234567890abcdef",
                "SAIL_VOYAGE_ID": "voy_00000000-0000-0000-0000-000000000099",
            }
        )

    assert fake_sail.app_find_calls == []
    assert fake_sail.sailbox_create_calls == []


def test_run_smoke_rejects_invalid_steps_before_live_calls(monkeypatch):
    module = load_example()
    fake_sail = FakeSail()
    monkeypatch.setattr(module, "sail", fake_sail)

    with pytest.raises(RuntimeError, match="SAIL_PHASE5_STEPS must be an integer"):
        module.run_smoke(
            {
                "SAIL_PHASE5_LIVE": "1",
                "SAIL_API_KEY": "sk_1234567890abcdef",
                "SAIL_PHASE5_STEPS": "many",
            }
        )

    assert fake_sail.app_find_calls == []
    assert fake_sail.sailbox_create_calls == []


def test_run_smoke_steps_emit_ordered_events(monkeypatch):
    module = load_example()
    fake_sail = FakeSail()
    monkeypatch.setattr(module, "sail", fake_sail)
    monkeypatch.setattr(module.time, "time", lambda: 1234567890)
    ticks = iter([10.0, 10.125])
    monkeypatch.setattr(module.time, "monotonic", lambda: next(ticks))

    result = module.run_smoke(
        {
            "SAIL_PHASE5_LIVE": "1",
            "SAIL_API_KEY": "sk_1234567890abcdef",
            "SAIL_PHASE5_STEPS": "3",
        }
    )

    voyage = fake_sail.voyage.current
    step_events = [
        event for event in voyage.events if event[0] == "controller.step.completed"
    ]

    assert result["steps"] == 3
    assert [event[1]["payload"]["step"] for event in step_events] == [1, 2, 3]
    assert [event[1]["message"] for event in step_events] == [
        "Step 1/3 complete",
        "Step 2/3 complete",
        "Step 3/3 complete",
    ]
    assert voyage.completed["payload"]["steps"] == 3


def test_run_smoke_forced_failure_marks_failed_and_terminates(monkeypatch):
    module = load_example()
    fake_sail = FakeSail()
    monkeypatch.setattr(module, "sail", fake_sail)
    monkeypatch.setattr(module.time, "time", lambda: 1234567890)
    ticks = iter([10.0, 10.125])
    monkeypatch.setattr(module.time, "monotonic", lambda: next(ticks))

    with pytest.raises(RuntimeError, match="Forced Phase 5 smoke failure"):
        module.run_smoke(
            {
                "SAIL_PHASE5_LIVE": "1",
                "SAIL_API_KEY": "sk_1234567890abcdef",
                "SAIL_PHASE5_FORCE_FAIL": "1",
                "SAIL_PHASE5_STEPS": "2",
            }
        )

    voyage = fake_sail.voyage.current
    force_events = [
        event
        for event in voyage.events
        if event[0] == "controller.force_fail.requested"
    ]

    assert len(force_events) == 1
    assert force_events[0][1]["level"] == "warn"
    assert voyage.completed is None
    assert voyage.failed["error_type"] == "RuntimeError"
    assert voyage.failed["message"] == "Forced Phase 5 smoke failure"
    assert fake_sail.created_sailbox.terminated is True
    assert fake_sail.operations.index("voyage.fail") < fake_sail.operations.index(
        "sailbox.terminate"
    )


def test_run_smoke_marks_failed_and_terminates_on_inference_error(monkeypatch):
    module = load_example()
    fake_sail = FakeSail(inference_error=RuntimeError("model unavailable"))
    monkeypatch.setattr(module, "sail", fake_sail)
    monkeypatch.setattr(module.time, "time", lambda: 1234567890)

    with pytest.raises(RuntimeError, match="model unavailable"):
        module.run_smoke(
            {
                "SAIL_PHASE5_LIVE": "1",
                "SAIL_API_KEY": "sk_1234567890abcdef",
            }
        )

    voyage = fake_sail.voyage.current
    assert voyage.completed is None
    assert voyage.failed["error_type"] == "RuntimeError"
    assert voyage.failed["message"] == "model unavailable"
    assert fake_sail.created_sailbox.terminated is True


def test_run_smoke_preserves_original_error_when_fail_reporting_fails(
    monkeypatch,
    capsys,
):
    module = load_example()
    fake_sail = FakeSail(
        inference_error=RuntimeError("model unavailable"),
        voyage_fail_error=RuntimeError("fail delivery"),
    )
    monkeypatch.setattr(module, "sail", fake_sail)
    monkeypatch.setattr(module.time, "time", lambda: 1234567890)

    with pytest.raises(RuntimeError, match="model unavailable"):
        module.run_smoke(
            {
                "SAIL_PHASE5_LIVE": "1",
                "SAIL_API_KEY": "sk_1234567890abcdef",
            }
        )

    captured = capsys.readouterr()
    assert "Warning: failed to mark Voyage failed: fail delivery" in captured.err
    assert fake_sail.created_sailbox.terminated is True


def test_run_smoke_preserves_original_error_when_terminate_fails(
    monkeypatch,
    capsys,
):
    module = load_example()
    fake_sail = FakeSail(
        inference_error=RuntimeError("model unavailable"),
        terminate_error=RuntimeError("terminate failed"),
    )
    monkeypatch.setattr(module, "sail", fake_sail)
    monkeypatch.setattr(module.time, "time", lambda: 1234567890)

    with pytest.raises(RuntimeError, match="model unavailable"):
        module.run_smoke(
            {
                "SAIL_PHASE5_LIVE": "1",
                "SAIL_API_KEY": "sk_1234567890abcdef",
            }
        )

    captured = capsys.readouterr()
    assert "Warning: failed to terminate Sailbox: terminate failed" in captured.err
    assert fake_sail.operations[-1] == "sailbox.terminate"
    assert fake_sail.voyage.current.failed["message"] == "model unavailable"


def test_run_smoke_marks_failed_when_successful_cleanup_fails(
    monkeypatch,
    capsys,
):
    module = load_example()
    fake_sail = FakeSail(terminate_error=RuntimeError("terminate failed"))
    monkeypatch.setattr(module, "sail", fake_sail)
    monkeypatch.setattr(module.time, "time", lambda: 1234567890)
    ticks = iter([10.0, 10.125])
    monkeypatch.setattr(module.time, "monotonic", lambda: next(ticks))

    with pytest.raises(RuntimeError, match="terminate failed"):
        module.run_smoke(
            {
                "SAIL_PHASE5_LIVE": "1",
                "SAIL_API_KEY": "sk_1234567890abcdef",
            }
        )

    voyage = fake_sail.voyage.current
    terminate_indices = [
        index
        for index, operation in enumerate(fake_sail.operations)
        if operation == "sailbox.terminate"
    ]

    captured = capsys.readouterr()
    assert "Warning: failed to terminate Sailbox: terminate failed" in captured.err
    assert len(terminate_indices) == 2
    assert terminate_indices[0] < fake_sail.operations.index("voyage.fail")
    assert voyage.completed is None
    assert voyage.failed["error_type"] == "RuntimeError"
    assert voyage.failed["message"] == "terminate failed"


def test_redaction_helper_covers_common_secret_shapes():
    module = load_example()

    text = module._redact_text(
        "Bearer abc.def sk_1234567890abcdef sr-151fac87cde38a2c236ba87a6c20d07d "
        "SAIL_API_KEY=sk_abcdef1234567890"
    )

    assert "abc.def" not in text
    assert "sk_1234567890abcdef" not in text
    assert "sr-151fac87cde38a2c236ba87a6c20d07d" not in text
    assert "sk_abcdef1234567890" not in text
    assert "Bearer [REDACTED]" in text
    assert "SAIL_API_KEY=[REDACTED]" in text
