## CLI must use only the public SDK

The `sail` CLI in `sdk/python/src/sail/cli/` is a thin wrapper around the
public SDK in `sdk/python/src/sail/`. CLI subcommands must drive sailbox,
app, and image operations through the public SDK surface (`Sailbox`, `App`,
`Image`, `Voyage`, `Config`) and never:

- import underscore-prefixed modules or symbols from the SDK — anything
  starting with `_` is private. This includes whole modules
  (`sail._http_client`, `sail._config`, `sail._client`) and individual
  attributes inside otherwise-public modules (`sail.sailbox._validate_*`,
  `sail._config._ENV_DEFAULTS`). If you need it, promote it to a public
  name first.
- import generated gRPC stubs (`sail.pb.*`) and dial scheduler / workerproxy
  endpoints directly,
- duplicate business logic that already exists in the SDK (input
  validation, status translation, pagination envelope shaping, error
  message wording, default values, mode resolution, etc.) — even a few
  lines of duplicated rules is a divergence risk. Always call the SDK.

If a CLI command needs a capability the SDK does not expose, add it to the
SDK first and then call it from the CLI. The reason: third-party SDK users
get the same surface CLI commands exercise — divergence between the two
means CLI flows hit code paths SDK users cannot, and vice versa.

For diagnostic commands that must work without an API key (`sail auth
whoami`, environment-debugging output), use `Config.from_env_optional_api_key()`
rather than reading `os.environ` directly or reaching into `_ENV_DEFAULTS`.

The single permitted CLI-only concern is local state (`~/.sail/config.toml`,
the per-sailbox `exec_endpoint` cache under `~/.sail/sailboxes/`), which the
CLI manages directly via `sail.cli._state`. That state never leaves the
client machine.

## Transport split

See `backend/AGENTS.md` "Transport: HTTP vs Scheduler gRPC" for the
HTTP-vs-gRPC routing policy. Briefly: sailbox lifecycle calls
(create/list/get/terminate/pause/sleep/resume/checkpoint) go through the
public HTTP API. Exec, listeners, and network requests stay on workerproxy
gRPC, dialed directly using the `exec_endpoint` returned at create time.
The SDK does not dial scheduler gRPC.

## Voyage inference context

Before changing `sail.voyage` or `sail.inference` header behavior, read
`../../VOYAGES_PHASE1_8_CONTEXT.md`. `sail.voyage.headers()` is the public
Voyage id helper; private inference context headers must stay optional and
header-safe so they never break an otherwise valid inference request.
