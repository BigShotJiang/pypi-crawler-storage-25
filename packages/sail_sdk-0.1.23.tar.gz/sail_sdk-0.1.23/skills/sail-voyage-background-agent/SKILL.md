---
name: sail-voyage-background-agent
description: Use when building or running a long-running background agent, eval harness, or Sailbox-backed task with the Python sail-sdk. Guides explicit Sail Voyage telemetry, spans, events, Sail inference correlation, Sailbox work attribution, terminal lifecycle, and secret-safe payload handling.
---

# Sail Voyage Background Agent

Use this pattern when a controller process owns a long-running task and you want
the Sail dashboard to show its trajectory. Sail provides the flight recorder; it
does not run the agent for you.

## Core Pattern

Start exactly one Voyage at task entry:

```python
import sail

voyage = sail.voyage.init(
    name="background task",
    metadata={"task": "eval"},
)
```

If the task controls a Sailbox, pass its id:

```python
voyage = sail.voyage.init(
    name="sailbox task",
    sailbox_id=sb.sailbox_id,
    metadata={"task": "repo repair"},
)
```

Use module-level `sail.voyage.*` helpers for the process-global current Voyage,
or keep the returned `voyage` object when multiple Voyage handles are present.

## Instrumentation

Wrap planner, model, tool, and Sailbox work in spans:

```python
with sail.voyage.agent("agent_planner", name="Planner", role="planner"):
    with sail.voyage.span("plan"):
        sail.voyage.event("planner.started", payload={"step": 1})
```

Use Sail inference wrappers when possible. They attach the current Voyage header
and make model-call rows appear in the dashboard:

```python
resp = sail.inference.responses.create(
    model="openai/gpt-oss-20b",
    input="Summarize the next action.",
)
```

For raw HTTP/OpenAI-compatible clients, merge Voyage headers explicitly:

```python
headers = sail.voyage.headers({"Content-Type": "application/json"})
```

## Sailbox Work

The v0 Sailbox pattern is controller-owned telemetry:

1. Controller creates or receives the Sailbox.
2. Controller initializes the Voyage with `sailbox_id=sb.sailbox_id`.
3. Controller records events around `sb.exec(...)`, `sb.request(...)`, and
   lifecycle operations.
4. Controller terminates or releases the Sailbox in `finally`.

Do not rely on Sailbox APIs to auto-create Voyages. Do not pass the API key into
Sailbox commands to make guest code attach by default.

Safe exec telemetry:

```python
# Implement redact() locally before recording tool output.
with sail.voyage.span("run command"):
    req = sb.exec("python3 task.py", timeout=60)
    result = req.wait()
    stdout_tail = redact(result.stdout)[-1000:]
    stderr_tail = redact(result.stderr)[-1000:]
    sail.voyage.event(
        "sailbox.exec.completed",
        payload={
            "exec_request_id": req.exec_request_id,
            "returncode": result.returncode,
            "stdout_tail": stdout_tail,
            "stderr_tail": stderr_tail,
        },
    )
```

## Child Processes

Use `SAIL_VOYAGE_ID` only when the child process already receives credentials
through a secure channel:

```python
# parent
import os
import subprocess
import sys

env = dict(os.environ)
env["SAIL_VOYAGE_ID"] = sail.voyage.id()
subprocess.run([sys.executable, "child.py"], env=env, check=True)

# child
import sail
sail.voyage.init()  # attaches to SAIL_VOYAGE_ID when SAIL_API_KEY is present
```

`SAIL_VOYAGE_ID` is only correlation. `SAIL_API_KEY` still authorizes event
delivery.

Do not use this pattern to smuggle credentials into Sailbox guest commands.

## Terminal Lifecycle

Always mark a terminal state. `complete()` and `fail()` flush synchronously and
may raise delivery errors.

```python
try:
    run_task()
    sail.voyage.complete(message="task complete")
except Exception as exc:
    sail.voyage.fail(
        error_type=exc.__class__.__name__,
        message=str(exc),
        payload={"phase": "run_task"},
    )
    raise
```

For long-running tasks, call `sail.voyage.flush()` at important checkpoints.

## Payload Hygiene

Keep payloads small, structured, and secret-free.

- Redact API keys, bearer tokens, credentials, cookies, and private URLs before
  recording stdout/stderr or tool outputs.
- Cap stdout/stderr snippets; prefer last 1-4 KiB over full logs.
- Do not put secrets in `message`, `payload`, `metadata`, stdout, stderr, or
  final printed JSON.
- Record identifiers such as `exec_request_id`, `response_id`, `sailbox_id`,
  return code, duration, and bounded/redacted tails.

## Hard Prohibitions

- Do not put `SAIL_API_KEY` or any secret into `Sailbox.exec()` shell strings.
- Do not bake API keys into image env, Dockerfiles, setup scripts, or payloads.
- Do not print API keys to stdout/stderr for Voyage collection.
- Do not add an agent framework, orchestration layer, memory graph, swarms, or
  Sailbox auto-binding when the task only needs Voyage telemetry.
- Do not use streaming inference wrappers; use a raw client with
  `sail.voyage.headers()` if streaming is required.

## Operator Handoff

At the end, print the Voyage id and dashboard URL:

```python
print(sail.voyage.id())
print(sail.voyage.dashboard_url())
```

The operator should verify:

- exactly one `voyage.started`
- planner/executor/Sailbox spans and events
- model-call rows for Sail inference
- `sailbox_id` in Voyage metadata when relevant
- terminal `completed` or `failed` status
