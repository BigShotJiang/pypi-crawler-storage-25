from __future__ import annotations

"""End-to-end Phase 4 Voyage smoke for a simple background-agent harness.

This example exercises the Phase 4 SDK surface:

- sail.voyage.init() create + automatic voyage.started
- process-global sail.voyage helpers
- agent and span context managers
- buffered events and explicit flush
- sail.inference.responses.create()
- sail.inference.chat.completions.create()
- sail.voyage.headers()
- child-process attach via SAIL_VOYAGE_ID
- terminal sail.voyage.complete()

Usage:
    cd sdk/python
    export SAIL_MODE=dev  # or staging/prod
    export SAIL_API_KEY=sk_...
    uv run python examples/voyage_background_agent_smoke.py
"""

import json
import os
import subprocess
import sys
import time
from typing import Any, Dict

import sail

DEFAULT_MODEL = "openai/gpt-oss-20b"
CHILD_SEQUENCE_START = 1_000


def _require_internal_sk_key() -> None:
    if not os.environ.get("SAIL_API_KEY", "").startswith("sk_"):
        raise RuntimeError("Set SAIL_API_KEY to a dedicated internal sk_ key.")


def _response_id(data: Dict[str, Any]) -> str:
    value = data.get("id")
    return value if isinstance(value, str) else ""


def run_child() -> int:
    voyage = sail.voyage.init()
    child_sequence = int(os.environ.get("SAIL_SMOKE_CHILD_SEQUENCE_START", "1000"))

    sail.voyage.event(
        "child.attached",
        message="child process attached to parent Voyage",
        payload={"pid": os.getpid(), "voyage_id": voyage.id},
        sequence_id=child_sequence,
    )
    with sail.voyage.agent("agent_child", name="Child worker", role="executor"):
        sail.voyage.event(
            "child.checkpoint",
            payload={"attached_voyage_id": sail.voyage.id()},
            sequence_id=child_sequence + 1,
        )

    sail.voyage.flush()
    print(
        json.dumps(
            {
                "child_voyage_id": voyage.id,
                "child_sequence_start": child_sequence,
                "status": "ok",
            },
            sort_keys=True,
        )
    )
    return 0


def run_parent() -> int:
    _require_internal_sk_key()

    model = os.environ.get("SAIL_SMOKE_MODEL", DEFAULT_MODEL)
    run_id = f"phase4-background-agent-smoke-{int(time.time())}"

    voyage = sail.voyage.init(
        name=run_id,
        metadata={
            "smoke": "phase4_background_agent",
            "model": model,
            "pid": os.getpid(),
        },
    )

    response_id = ""
    chat_id = ""
    child_result: Dict[str, Any] = {}

    try:
        merged_headers = sail.voyage.headers({"X-Smoke-Run": run_id})
        assert merged_headers["X-Sail-Voyage-Id"] == voyage.id

        sail.voyage.event(
            "background_agent.started",
            message="background agent smoke started",
            payload={"run_id": run_id, "model": model},
        )
        sail.voyage.event(
            "headers.checked",
            level="debug",
            payload={"has_voyage_header": "X-Sail-Voyage-Id" in merged_headers},
        )

        with sail.voyage.agent("agent_planner", name="Planner", role="planner"):
            with sail.voyage.span("plan task", span_id="span_plan_task"):
                response = sail.inference.responses.create(
                    model=model,
                    input=(
                        "Create a one-sentence plan for verifying a background "
                        "agent smoke test."
                    ),
                    background=True,
                    prompt_cache_key=f"{run_id}-responses-cache",
                    timeout=30,
                )
                response_id = _response_id(response)
                sail.voyage.event(
                    "planner.response.created",
                    payload={"response_id": response_id},
                )

        with sail.voyage.agent("agent_executor", name="Executor", role="executor"):
            with sail.voyage.span("execute task", span_id="span_execute_task"):
                chat = sail.inference.chat.completions.create(
                    model=model,
                    messages=[
                        {
                            "role": "user",
                            "content": (
                                "Reply with exactly five words confirming the "
                                "background agent smoke."
                            ),
                        }
                    ],
                    headers={"X-Sail-Async": "1", "X-Smoke-Run": run_id},
                    timeout=30,
                )
                chat_id = _response_id(chat)
                sail.voyage.event(
                    "executor.chat.created",
                    payload={"response_id": chat_id},
                )

        env = dict(os.environ)
        env["SAIL_VOYAGE_ID"] = voyage.id
        env["SAIL_SMOKE_CHILD_SEQUENCE_START"] = str(CHILD_SEQUENCE_START)
        with sail.voyage.agent("agent_parent", name="Parent", role="coordinator"):
            with sail.voyage.span("child process attach", span_id="span_child_attach"):
                completed = subprocess.run(
                    [sys.executable, __file__, "--child"],
                    env=env,
                    text=True,
                    capture_output=True,
                    check=True,
                )
                child_stdout = completed.stdout.strip().splitlines()
                child_result = json.loads(child_stdout[-1]) if child_stdout else {}
                sail.voyage.event(
                    "child.completed",
                    payload=child_result,
                    sequence_id=CHILD_SEQUENCE_START + 10,
                )

        sail.voyage.complete(
            message="phase4 background agent smoke complete",
            payload={
                "run_id": run_id,
                "responses_id": response_id,
                "chat_completion_id": chat_id,
                "child_voyage_id": child_result.get("child_voyage_id"),
            },
        )
    except Exception as exc:
        try:
            sail.voyage.fail(
                error_type=exc.__class__.__name__,
                message=str(exc),
                payload={"run_id": run_id},
            )
        finally:
            raise

    result = {
        "run_id": run_id,
        "voyage_id": voyage.id,
        "dashboard_url": voyage.dashboard_url,
        "responses_id": response_id,
        "chat_completion_id": chat_id,
        "child": child_result,
    }
    print(json.dumps(result, indent=2, sort_keys=True))
    print("\nDashboard checklist:")
    print("- status is completed")
    print("- exactly one voyage.started event")
    print("- background_agent.started and headers.checked events")
    print("- planner and executor agent labels on their span/event rows")
    print("- response and chat model-call rows linked to this Voyage")
    print("- child.attached / child.checkpoint / child.completed events")
    return 0


def main() -> int:
    if len(sys.argv) == 2 and sys.argv[1] == "--child":
        return run_child()
    return run_parent()


if __name__ == "__main__":
    raise SystemExit(main())
