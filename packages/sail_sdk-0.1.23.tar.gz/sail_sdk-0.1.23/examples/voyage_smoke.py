from __future__ import annotations

"""Create a Voyage, emit events/spans, correlate inference, and complete it.

Usage:
    cd sdk/python
    export SAIL_API_KEY=sk_...
    export SAIL_MODE=staging  # optional; prod is the default
    uv run python examples/voyage_smoke.py
"""

import os
import sys

import sail


def main() -> int:
    if not os.environ.get("SAIL_API_KEY", "").startswith("sk_"):
        print("Set SAIL_API_KEY to a dedicated internal sk_ key.", file=sys.stderr)
        return 2

    voyage = sail.voyage.init(name="python-sdk-voyage-smoke")
    try:
        sail.voyage.event("planner.started", message="planning")

        with sail.voyage.agent("agent_solver", name="Solver", role="executor"):
            with sail.voyage.span("call model"):
                resp = sail.inference.responses.create(
                    model="openai/gpt-oss-20b",
                    input="Say hello in one sentence.",
                )
                sail.voyage.event(
                    "model.response.received",
                    payload={"response_id": resp.get("id")},
                )

        sail.voyage.complete(message="done")
    except Exception as exc:
        sail.voyage.fail(
            error_type=exc.__class__.__name__,
            message=str(exc),
        )
        raise

    print("Voyage ID:", sail.voyage.id())
    print("Dashboard URL:", sail.voyage.dashboard_url())
    print("Object ID:", voyage.id)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
