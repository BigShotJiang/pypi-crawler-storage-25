from __future__ import annotations

"""Run a Python function inside a sailbox.

Usage:
    cd sdk/python
    export SAIL_MODE=prod  # optional; prod is also the default
    export SAIL_API_KEY=your_api_key_here
    uv run python examples/sailbox_function.py
"""

import os
import sys

import sail
from sail._config import Config


@sail.function()
def summarize(values: list[int]) -> dict[str, int]:
    total = sum(values)
    return {"count": len(values), "total": total}


def main() -> int:
    api_key = os.environ.get("SAIL_API_KEY", "")
    if not api_key:
        print("Set SAIL_API_KEY before running this script.", file=sys.stderr)
        return 2

    cfg = Config.from_env()

    print(f"Finding or minting app via API {cfg.api_url}...")
    app = sail.App.find(name="sailbox-function", mint_if_missing=True)

    print(f"Building image via imagebuilder {cfg.imagebuilder_url}...")
    image = sail.Image.debian_arm64.run_commands("python3 --version").build()

    print(f"Creating sailbox via API {cfg.api_url}...")
    sb = sail.Sailbox.create(
        app=app,
        image=image,
        name="function-demo",
        cpu=1,
        memory_mib=1024,
    )

    print("Running Python function...")
    result = sb.exec(summarize, [1, 2, 3, 4], timeout=30)
    print(result)

    print("Terminating sailbox...")
    sb.terminate()
    print("Terminated.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
