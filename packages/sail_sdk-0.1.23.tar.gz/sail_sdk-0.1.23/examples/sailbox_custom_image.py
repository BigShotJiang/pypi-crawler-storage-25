from __future__ import annotations

"""Build and run a sailbox with a custom Debian image.

Demonstrates the three ways to put content into a custom image:
  * apt_install / pip_install / run_commands — packages and shell steps
  * add_local_dir — bake a local source tree into the rootfs
  * add_local_file — bake a single local file into the rootfs

Usage:
    cd sdk/python
    export SAIL_MODE=prod  # optional; prod is also the default
    export SAIL_API_KEY=your_api_key_here
    uv run python examples/sailbox_custom_image.py
"""

import os
import sys
import tempfile
from pathlib import Path

import sail
from sail._config import Config


def _materialize_demo_sources(root: Path) -> tuple[Path, Path]:
    """Create a tiny local app tree + config file for the demo to upload."""
    app_dir = root / "app"
    app_dir.mkdir()
    (app_dir / "hello.py").write_text(
        "import os\nprint('hello from', os.environ.get('APP_ENV'))\n"
    )
    (app_dir / "requirements.txt").write_text("requests\n")
    # Files we expect ignore patterns to filter out.
    (app_dir / "ignored.pyc").write_text("compiled noise\n")
    (app_dir / "__pycache__").mkdir()
    (app_dir / "__pycache__" / "hello.cpython.pyc").write_text("more noise\n")

    config_path = root / "config.json"
    config_path.write_text('{"demo": true}\n')
    return app_dir, config_path


def main() -> int:
    api_key = os.environ.get("SAIL_API_KEY", "")
    if not api_key:
        print("Set SAIL_API_KEY before running this script.", file=sys.stderr)
        return 2

    cfg = Config.from_env()

    print(f"Finding or minting app via API {cfg.api_url}...")
    app = sail.App.find(name="sailbox-custom-image", mint_if_missing=True)

    with tempfile.TemporaryDirectory() as tmp:
        app_dir, config_path = _materialize_demo_sources(Path(tmp))

        print("Defining custom image...")
        image = (
            sail.Image.debian_arm64.apt_install("python3")
            .pip_install("requests")
            .add_local_dir(
                app_dir,
                "/opt/demo-app",
                ignore=["*.pyc", "__pycache__/"],
            )
            .add_local_file(config_path, "/etc/demo/config.json", mode=0o600)
            .run_commands("python3 -m pip show requests >/tmp/requests.txt")
            .env(
                {
                    "APP_ENV": "custom-image-demo",
                    "DEMO_MESSAGE": "hello-from-custom-image",
                }
            )
        )

        print(
            f"Creating sailbox from custom image via imagebuilder "
            f"{cfg.imagebuilder_url}..."
        )
        sb = sail.Sailbox.create(
            app=app,
            image=image,
            name="custom-image-demo",
            image_build_timeout=1800,
            cpu=1,
            memory_mib=1024,
        )

    print("Sailbox ready:")
    print(f"  sailbox_id: {sb.sailbox_id}")
    print(f"  worker:     {sb.worker_address}")

    print("Verifying installed packages, uploaded sources, and runtime env...")
    result = sb.exec(
        "python3 /opt/demo-app/hello.py\n"
        "ls /opt/demo-app\n"
        "stat -c '%a %n' /etc/demo/config.json\n"
        "cat /etc/demo/config.json\n"
        "cat /tmp/requests.txt | head -n 5\n",
        timeout=30,
    ).wait()
    print(result.stdout)
    if result.stderr:
        print(result.stderr, file=sys.stderr)
    print(f"return code: {result.returncode}")

    print("Terminating sailbox...")
    sb.terminate()
    print("Terminated.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
