# Sail SDK Examples

Run examples from `sdk/python` with `uv run python examples/<name>.py`.

Use a dedicated internal org-bearing `sk_...` key for live Voyage dashboard
smoke tests. Do not use arbitrary customer keys.

## Phase 4 Voyage Examples

Use these when validating the Python Voyage SDK and inference correlation:

| Example | Purpose |
| --- | --- |
| `voyage_smoke.py` | Minimal Voyage with events, a span, one Sail inference call, and `complete()`. |
| `voyage_child_attach.py` | Parent creates a Voyage; child attaches through `SAIL_VOYAGE_ID`. |
| `voyage_background_agent_smoke.py` | Rich controller-style run with responses + chat completions, spans, agents, child attach, and terminal state. |

Typical run:

```bash
export SAIL_MODE=staging
export SAIL_API_KEY="sk_..."
uv run python examples/voyage_background_agent_smoke.py
```

## Phase 5 Sailbox Voyage Example

Use this for the Arcanist/demo path where a controller harness creates a
Sailbox, starts one Voyage with `sailbox_id`, calls Sail inference, records
Sailbox exec telemetry, and terminates the Sailbox:

```bash
export SAIL_PHASE5_LIVE=1
export SAIL_MODE=staging
export SAIL_API_KEY="sk_..."
unset SAIL_VOYAGE_ID
uv run python examples/voyage_sailbox_agent_smoke.py
```

Useful modes:

```bash
SAIL_PHASE5_STEPS=25 uv run python examples/voyage_sailbox_agent_smoke.py
SAIL_PHASE5_FORCE_FAIL=1 uv run python examples/voyage_sailbox_agent_smoke.py
```

See `../runbooks/phase5-sailbox-voyage.md` for the full dashboard checklist
and safe-failure expectations.

## Sailbox Basics

Use these for Sailbox-only SDK behavior, without Voyage dashboard validation:

| Example | Purpose |
| --- | --- |
| `sailbox_smoke.py` | Basic Sailbox create/exec/terminate flow. |
| `sailbox_function.py` | Decorated Python function execution in a Sailbox. |
| `sailbox_custom_image.py` | Custom image usage. |
