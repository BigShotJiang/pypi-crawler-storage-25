from __future__ import annotations

"""Demonstrate child-process Voyage attach with SAIL_VOYAGE_ID.

Usage:
    cd sdk/python
    export SAIL_API_KEY=sk_...
    export SAIL_MODE=staging  # optional; prod is the default
    uv run python examples/voyage_child_attach.py
"""

import os
import subprocess
import sys

import sail


def run_child() -> int:
    voyage = sail.voyage.init()
    sail.voyage.event("child.started", message="child attached")
    with sail.voyage.span("child work", agent_id="child_worker", name="Child"):
        sail.voyage.event("child.step", payload={"pid": os.getpid()})
    sail.voyage.flush()
    print("Child Voyage ID:", voyage.id)
    return 0


def run_parent() -> int:
    if not os.environ.get("SAIL_API_KEY", "").startswith("sk_"):
        print("Set SAIL_API_KEY to a dedicated internal sk_ key.", file=sys.stderr)
        return 2

    voyage = sail.voyage.init(name="python-sdk-child-attach-smoke")
    env = dict(os.environ)
    env["SAIL_API_KEY"] = os.environ["SAIL_API_KEY"]
    env["SAIL_VOYAGE_ID"] = voyage.id

    try:
        sail.voyage.event("parent.launching_child")
        subprocess.run([sys.executable, __file__, "--child"], env=env, check=True)
        sail.voyage.complete(message="parent and child complete")
    except Exception as exc:
        sail.voyage.fail(error_type=exc.__class__.__name__, message=str(exc))
        raise

    print("Parent Voyage ID:", voyage.id)
    print("Dashboard URL:", voyage.dashboard_url)
    return 0


def main() -> int:
    if len(sys.argv) == 2 and sys.argv[1] == "--child":
        return run_child()
    return run_parent()


if __name__ == "__main__":
    raise SystemExit(main())
