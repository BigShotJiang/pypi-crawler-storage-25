from __future__ import annotations

"""Phase 5 Sailbox-backed Voyage smoke.

This example demonstrates the v0 Arcanist/controller pattern:

- the controller process owns one Voyage
- the controller creates and terminates the Sailbox
- the controller records Voyage events around Sailbox work
- model calls use sail.inference.* so the Voyage header is attached

It intentionally does not pass SAIL_API_KEY into Sailbox.exec() commands. The
command string can be stored/logged by the control plane, so guest-process
Voyage attach remains a later secure-credentials project.

Usage:
    cd sdk/python
    export SAIL_PHASE5_LIVE=1
    export SAIL_MODE=staging
    export SAIL_API_KEY=sk_...  # dedicated internal org-bearing key for smoke
    uv run python examples/voyage_sailbox_agent_smoke.py
"""

import json
import os
import re
import sys
import time
from typing import Any, Dict, Mapping, Optional

import sail

DEFAULT_MODEL = "openai/gpt-oss-20b"
DEFAULT_APP_NAME = "phase5-sailbox-voyage-smoke"
DEFAULT_STEPS = 1
MAX_STEPS = 500
OUTPUT_TAIL_CHARS = 1000

_SECRET_PATTERNS = (
    (re.compile(r"Bearer\s+[A-Za-z0-9._~+/=-]+", re.IGNORECASE), "Bearer [REDACTED]"),
    (re.compile(r"\bsk_[A-Za-z0-9._-]{8,}\b"), "sk_[REDACTED]"),
    (re.compile(r"\bsr-[A-Za-z0-9]{16,}\b"), "sr-[REDACTED]"),
    (re.compile(r"\b(SAIL_API_KEY=)[^\s]+"), r"\1[REDACTED]"),
)


def _truthy(value: Optional[str]) -> bool:
    return (value or "").strip().lower() in {"1", "true", "yes", "on"}


def _redact_text(value: str) -> str:
    redacted = value
    for pattern, replacement in _SECRET_PATTERNS:
        redacted = pattern.sub(replacement, redacted)
    return redacted


def _redacted_tail(value: str, max_chars: int = OUTPUT_TAIL_CHARS) -> Dict[str, Any]:
    redacted = _redact_text(value)
    truncated = len(redacted) > max_chars
    return {
        "text": redacted[-max_chars:] if truncated else redacted,
        "truncated": truncated,
    }


def _response_id(data: Mapping[str, Any]) -> str:
    value = data.get("id")
    return value if isinstance(value, str) else ""


def _parse_steps(value: Optional[str]) -> int:
    if value is None or not value.strip():
        return DEFAULT_STEPS
    try:
        steps = int(value)
    except ValueError:
        raise RuntimeError("SAIL_PHASE5_STEPS must be an integer") from None
    if steps < 0:
        raise RuntimeError("SAIL_PHASE5_STEPS must be >= 0")
    if steps > MAX_STEPS:
        raise RuntimeError(f"SAIL_PHASE5_STEPS must be <= {MAX_STEPS}")
    return steps


def _print_setup() -> None:
    print(
        "\n".join(
            [
                "Phase 5 Sailbox Voyage smoke is live-only.",
                "It creates a Sailbox and calls Sail inference, so it will not run unless SAIL_PHASE5_LIVE=1.",
                "",
                "Set:",
                "  export SAIL_PHASE5_LIVE=1",
                "  export SAIL_MODE=staging",
                "  export SAIL_API_KEY=sk_...  # dedicated internal org-bearing key for dashboard visibility",
                "  unset SAIL_VOYAGE_ID        # this smoke must create a fresh Voyage",
                "",
                "Then run:",
                "  uv run python examples/voyage_sailbox_agent_smoke.py",
                "",
                "No Sailbox or inference requests were made.",
            ]
        )
    )


def _live_env_error(environ: Mapping[str, str]) -> Optional[str]:
    api_key = environ.get("SAIL_API_KEY", "")
    if not api_key:
        return "SAIL_API_KEY is required for live Sailbox/inference smoke."
    if not api_key.startswith("sk_"):
        return "SAIL_API_KEY must be a dedicated internal org-bearing sk_ key."
    if environ.get("SAIL_VOYAGE_ID"):
        return (
            "SAIL_VOYAGE_ID must be unset for this controller-owned smoke so "
            "sail.voyage.init() creates a fresh Voyage."
        )
    return None


def _sailbox_command() -> str:
    # Keep this command static and credential-free. Sailbox.exec() argv can be
    # stored/logged by the control plane.
    return (
        "printf 'phase5 sailbox smoke\\n'; "
        "python3 - <<'PY'\n"
        "import json, os, platform\n"
        "print(json.dumps({\n"
        "    'cwd': os.getcwd(),\n"
        "    'python': platform.python_version(),\n"
        "    'platform': platform.system(),\n"
        "}, sort_keys=True))\n"
        "PY"
    )


def run_smoke(environ: Optional[Mapping[str, str]] = None) -> Dict[str, Any]:
    env = os.environ if environ is None else environ
    if not _truthy(env.get("SAIL_PHASE5_LIVE")):
        raise RuntimeError("SAIL_PHASE5_LIVE=1 is required for live smoke")

    env_error = _live_env_error(env)
    if env_error:
        raise RuntimeError(env_error)

    steps = _parse_steps(env.get("SAIL_PHASE5_STEPS"))
    force_fail = _truthy(env.get("SAIL_PHASE5_FORCE_FAIL"))
    model = env.get("SAIL_PHASE5_MODEL", DEFAULT_MODEL)
    app_name = env.get("SAIL_PHASE5_APP_NAME", DEFAULT_APP_NAME)
    run_id = f"phase5-sailbox-agent-smoke-{int(time.time())}"

    app = sail.App.find(name=app_name, mint_if_missing=True)
    sailbox = None
    voyage = None
    sailbox_id: Optional[str] = None
    response_id = ""
    exec_request_id = ""
    exec_payload: Dict[str, Any] = {}
    primary_error: Optional[Exception] = None

    try:
        sailbox = sail.Sailbox.create(
            app=app,
            image=sail.Image.debian_arm64,
            name="phase5-voyage-smoke",
            cpu=1,
            memory_mib=1024,
        )
        sailbox_id = sailbox.sailbox_id
        voyage = sail.voyage.init(
            name=run_id,
            sailbox_id=sailbox_id,
            metadata={
                "phase": "5",
                "smoke": "sailbox_agent",
                "app_name": app_name,
                "model": model,
                "pid": os.getpid(),
                "steps": steps,
                "force_fail": force_fail,
            },
        )

        with voyage.agent("controller", name="Controller", role="coordinator"):
            voyage.event(
                "controller.started",
                message="Sailbox-backed Voyage smoke started",
                payload={
                    "run_id": run_id,
                    "sailbox_id": sailbox_id,
                    "app_id": app.id,
                    "steps": steps,
                    "force_fail": force_fail,
                },
            )

            with voyage.span("call model", span_id="span_phase5_model"):
                response = sail.inference.responses.create(
                    model=model,
                    input=(
                        "Say one short sentence confirming the Phase 5 "
                        "Sailbox-backed Voyage smoke."
                    ),
                    background=True,
                    prompt_cache_key=f"{run_id}-responses-cache",
                    timeout=30,
                )
                response_id = _response_id(response)
                voyage.event(
                    "controller.model_call.created",
                    payload={"response_id": response_id},
                )

            with voyage.span("run sailbox command", span_id="span_phase5_exec"):
                command = _sailbox_command()
                started = time.monotonic()
                exec_request = sailbox.exec(command, timeout=30)
                exec_request_id = getattr(exec_request, "exec_request_id", "")
                result = exec_request.wait()
                duration_ms = int((time.monotonic() - started) * 1000)
                exec_payload = {
                    "exec_request_id": exec_request_id,
                    "returncode": result.returncode,
                    "duration_ms": duration_ms,
                    "stdout_tail": _redacted_tail(result.stdout),
                    "stderr_tail": _redacted_tail(result.stderr),
                }
                voyage.event(
                    "sailbox.exec.completed",
                    payload=exec_payload,
                )
                if result.returncode != 0:
                    raise RuntimeError(
                        f"Sailbox exec failed with return code {result.returncode}"
                    )

            for step in range(1, steps + 1):
                with voyage.span(
                    f"progress step {step}",
                    span_id=f"span_phase5_step_{step:04d}",
                ):
                    voyage.event(
                        "controller.step.completed",
                        message=f"Step {step}/{steps} complete",
                        payload={
                            "step": step,
                            "total_steps": steps,
                        },
                    )

            if force_fail:
                voyage.event(
                    "controller.force_fail.requested",
                    level="warn",
                    message="Forced Phase 5 smoke failure requested",
                    payload={"run_id": run_id},
                )
                raise RuntimeError("Forced Phase 5 smoke failure")

        sailbox.terminate()
        sailbox = None

        voyage.complete(
            message="Phase 5 Sailbox-backed Voyage smoke complete",
            payload={
                "run_id": run_id,
                "sailbox_id": sailbox_id,
                "responses_id": response_id,
                "exec_request_id": exec_request_id,
                "steps": steps,
            },
        )
    except Exception as exc:
        primary_error = exc
        if voyage is not None:
            try:
                voyage.fail(
                    error_type=exc.__class__.__name__,
                    message=str(exc),
                    payload={
                        "run_id": run_id,
                        "sailbox_id": sailbox_id,
                    },
                )
            except Exception as fail_exc:
                print(
                    f"Warning: failed to mark Voyage failed: {fail_exc}",
                    file=sys.stderr,
                )
        raise
    finally:
        if sailbox is not None:
            try:
                sailbox.terminate()
            except Exception as terminate_exc:
                if primary_error is not None:
                    print(
                        f"Warning: failed to terminate Sailbox: {terminate_exc}",
                        file=sys.stderr,
                    )
                else:
                    raise

    return {
        "run_id": run_id,
        "voyage_id": voyage.id if voyage is not None else None,
        "dashboard_url": voyage.dashboard_url if voyage is not None else None,
        "sailbox_id": sailbox_id,
        "responses_id": response_id,
        "exec_request_id": exec_request_id,
        "steps": steps,
        "force_fail": force_fail,
        "exec": exec_payload,
    }


def main() -> int:
    if not _truthy(os.environ.get("SAIL_PHASE5_LIVE")):
        _print_setup()
        return 2

    result = run_smoke()
    print(json.dumps(result, indent=2, sort_keys=True))
    print("\nDashboard checklist:")
    print("- Identity/Sailbox row shows sailbox_id")
    print("- exactly one voyage.started event")
    print("- controller/model/Sailbox spans render")
    print("- sailbox.exec.completed payload has redacted stdout/stderr tails")
    print("- controller.step.completed rows render when SAIL_PHASE5_STEPS is set")
    print("- model-call row is correlated to this Voyage")
    print("- terminal status is completed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
