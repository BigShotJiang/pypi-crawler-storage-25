"""Tests integration du serveur MCP hosted SSE + Streamable HTTP.

Validee :
  - GET /health bypass auth, retourne 200 + status JSON
  - POST /mcp sans Authorization Bearer => 401 missing_bearer_token
  - POST /mcp avec Bearer vide => 401 empty_bearer_token
  - GET /sse sans Bearer => 401
  - POST /mcp avec Bearer valide + initialize MCP => 200 + capabilities
  - POST /mcp avec Bearer valide + tools/list => 200 + 11 tools
  - POST /mcp avec Bearer valide + tools/call sur get_permit_details =>
    forward la cle au backend via use_api_key (mocke httpx pour ne pas
    appeler l'API prod)

Les tests reutilisent le pattern `httpx.MockTransport` du test_tools.py,
mais cote serveur MCP au lieu de cote tool.
"""
from __future__ import annotations

import json
import os
from contextlib import contextmanager
from unittest.mock import patch

import pytest
from starlette.testclient import TestClient


@contextmanager
def env(**kwargs):
    """Identique a test_tools.py : scope env vars sur la duree d'un test."""
    old: dict[str, str | None] = {k: os.environ.get(k) for k in kwargs}
    for k, v in kwargs.items():
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v
    try:
        yield
    finally:
        for k, v in old.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v


@pytest.fixture
def app():
    """Construit une instance fraiche de la Starlette app pour chaque test."""
    from permisapi_mcp.sse_server import create_app
    return create_app()


@pytest.fixture
def client(app):
    """Starlette TestClient autour de l'app SSE."""
    with TestClient(app) as c:
        yield c


# ---------------------------------------------------------------------------
# /health
# ---------------------------------------------------------------------------


def test_health_bypasses_auth_and_returns_status(client: TestClient):
    r = client.get("/health")
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "ok"
    assert body["service"] == "permisapi-mcp-sse"
    assert body["tools_count"] == 14


def test_health_no_auth_header_required(client: TestClient):
    """Pas de header => quand meme 200 (probe Railway)."""
    r = client.get("/health", headers={})
    assert r.status_code == 200


# ---------------------------------------------------------------------------
# Auth Bearer
# ---------------------------------------------------------------------------


def test_post_mcp_without_bearer_returns_401(client: TestClient):
    r = client.post("/mcp", json={"jsonrpc": "2.0", "id": 1})
    assert r.status_code == 401
    body = r.json()
    assert body["error"] == "missing_credentials"
    assert "permisapi.fr/#pricing" in body["detail"]


def test_post_mcp_with_empty_bearer_returns_401(client: TestClient):
    """Bearer header avec espace mais sans token = on tombe en `missing_credentials`
    (le middleware essaie le fallback `?key=` qui est aussi absent)."""
    r = client.post(
        "/mcp", json={"jsonrpc": "2.0", "id": 1},
        headers={"Authorization": "Bearer "},
    )
    assert r.status_code == 401
    body = r.json()
    assert body["error"] == "missing_credentials"


def test_post_mcp_with_non_bearer_scheme_returns_401(client: TestClient):
    """Basic / Digest / autre scheme : on rejette (Bearer uniquement,
    pas de fallback query param ?key= dans ce test)."""
    r = client.post(
        "/mcp", json={"jsonrpc": "2.0", "id": 1},
        headers={"Authorization": "Basic dGVzdDp0ZXN0"},
    )
    assert r.status_code == 401
    body = r.json()
    assert body["error"] == "missing_credentials"


def test_get_sse_without_bearer_returns_401(client: TestClient):
    r = client.get("/sse")
    assert r.status_code == 401
    assert r.json()["error"] == "missing_credentials"


def test_authorization_header_case_insensitive(client: TestClient):
    """Le header HTTP est case-insensitive, on doit accepter `authorization`
    en lowercase aussi bien que `Authorization` en CamelCase.
    """
    # Lowercase. Cle au format pk_test_* pour passer la validation
    # `load_access_token` (mode 2 cle directe).
    r1 = client.post(
        "/mcp", json={"jsonrpc": "2.0", "id": 1},
        headers={"authorization": "Bearer pk_test_lowercasekey"},
    )
    # Et non-bearer rejette en lowercase aussi
    r2 = client.post(
        "/mcp", json={"jsonrpc": "2.0", "id": 1},
        headers={"authorization": "Basic xyz"},
    )
    # r1 ne doit PAS retourner 401 missing_credentials, c'est r2 qui doit.
    assert r1.status_code != 401 or r1.json().get("error") != "missing_credentials"
    assert r2.status_code == 401
    assert r2.json()["error"] == "missing_credentials"


def test_query_param_key_accepted_as_fallback(client: TestClient):
    """Mode 2 d'auth : `?key=pk_...` en query param pour clients comme
    Claude.ai web hosted MCP BETA qui ne supporte pas Bearer custom."""
    from permisapi_mcp import tools as tools_mod

    captured: dict[str, str] = {}

    async def fake_call_tool(name, arguments, *, client=None):
        captured["key"] = tools_mod._api_key()
        return '{"echoed": true}'

    with env(PERMISAPI_KEY=None):
        with patch.object(tools_mod, "call_tool", side_effect=fake_call_tool):
            r = client.post(
                "/mcp/?key=pk_test_fromqueryparam",
                json={
                    "jsonrpc": "2.0",
                    "id": 1,
                    "method": "initialize",
                    "params": {
                        "protocolVersion": "2024-11-05",
                        "capabilities": {},
                        "clientInfo": {"name": "test", "version": "1.0"},
                    },
                },
                headers={"Accept": "application/json, text/event-stream"},
            )
            assert r.status_code == 200, r.text[:200]


def test_query_param_empty_falls_back_to_401(client: TestClient):
    """`?key=` vide (sans valeur) ne doit pas authentifier."""
    r = client.post("/mcp?key=", json={"jsonrpc": "2.0", "id": 1})
    assert r.status_code == 401
    assert r.json()["error"] == "missing_credentials"


def test_invalid_token_format_returns_401(client: TestClient):
    """Un token qui ne commence pas par pk_live_/pk_test_ et qui n'est pas
    un OAuth token genere par nous = `invalid_token` 401."""
    r = client.post(
        "/mcp", json={"jsonrpc": "2.0", "id": 1},
        headers={"Authorization": "Bearer not_a_permisapi_key"},
    )
    assert r.status_code == 401
    assert r.json()["error"] == "invalid_token"


def test_bearer_priority_over_query_param(client: TestClient):
    """Si Bearer ET query param sont presents, Bearer prend priorite."""
    from permisapi_mcp import tools as tools_mod

    captured_keys = []

    async def fake_call_tool(name, arguments, *, client=None):
        captured_keys.append(tools_mod._api_key())
        return '{"ok": true}'

    with env(PERMISAPI_KEY=None):
        with patch.object(tools_mod, "call_tool", side_effect=fake_call_tool):
            r = client.post(
                "/mcp/?key=pk_test_fromquery",
                json={
                    "jsonrpc": "2.0",
                    "id": 1,
                    "method": "initialize",
                    "params": {
                        "protocolVersion": "2024-11-05",
                        "capabilities": {},
                        "clientInfo": {"name": "test", "version": "1.0"},
                    },
                },
                headers={
                    "Authorization": "Bearer pk_test_frombearer",
                    "Accept": "application/json, text/event-stream",
                },
            )
            assert r.status_code == 200, r.text[:200]
    # Note : on ne tool/call pas reellement dans ce test (juste initialize),
    # donc captured_keys peut etre vide. L'important c'est que la requete
    # passe au lieu de retourner 401.


# ---------------------------------------------------------------------------
# Bearer scoping : la cle est injectee dans ContextVar pendant la requete
# ---------------------------------------------------------------------------


def test_bearer_token_injected_into_context_during_request(client: TestClient):
    """Quand une requete arrive avec Bearer X, `use_api_key()` rend X
    disponible a l'interieur du handler.

    On valide en patchant `tools.call_tool` pour qu'il lise la cle via
    `_api_key()` et la remonte dans le payload de reponse, ce qui montre
    que le middleware a bien injecte le ContextVar avant le dispatch MCP.
    """
    from permisapi_mcp import tools as tools_mod

    captured: dict[str, str] = {}

    async def fake_call_tool(name: str, arguments: dict, *, client=None) -> str:
        # On lit ce que _api_key() retourne pour confirmer l'injection.
        try:
            captured["key"] = tools_mod._api_key()
        except RuntimeError as e:
            captured["error"] = str(e)
        return json.dumps({"echoed_tool": name, "echoed_args": arguments})

    with env(PERMISAPI_KEY=None):  # pas d'env, isole le ContextVar
        with patch.object(tools_mod, "call_tool", side_effect=fake_call_tool):
            # Init MCP session
            init_resp = client.post(
                "/mcp",
                json={
                    "jsonrpc": "2.0",
                    "id": 1,
                    "method": "initialize",
                    "params": {
                        "protocolVersion": "2024-11-05",
                        "capabilities": {},
                        "clientInfo": {"name": "test", "version": "1.0"},
                    },
                },
                headers={
                    "Authorization": "Bearer pk_test_injectedbymiddleware",
                    "Accept": "application/json, text/event-stream",
                },
            )
            assert init_resp.status_code == 200

    # Pas force qu'on ait pu trigger un call_tool ici (le initialize ne le
    # fait pas en lui-meme), mais le test prouve au moins que le init MCP
    # round-trip avec Bearer non bloque == 200.


# ---------------------------------------------------------------------------
# MCP initialize round-trip
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# OAuth 2.0 flow
# ---------------------------------------------------------------------------


def test_oauth_metadata_endpoint_returns_json(client: TestClient):
    """Le SDK MCP doit avoir mounte /.well-known/oauth-authorization-server."""
    r = client.get("/.well-known/oauth-authorization-server")
    assert r.status_code == 200
    body = r.json()
    assert "issuer" in body
    assert "authorization_endpoint" in body
    assert "token_endpoint" in body
    assert "registration_endpoint" in body  # DCR enabled
    assert "revocation_endpoint" in body  # revoke enabled


def test_consent_get_without_id_returns_400(client: TestClient):
    r = client.get("/consent")
    assert r.status_code == 400
    assert "consent_id manquant" in r.text


def test_consent_get_with_invalid_id_returns_410(client: TestClient):
    r = client.get("/consent?consent_id=invalid_or_expired")
    assert r.status_code == 410
    assert "Lien expir" in r.text  # "Lien expiré" ou variante


def test_oauth_register_dcr_creates_client(client: TestClient):
    """DCR RFC 7591 : POST /register avec metadata client retourne un
    client_id + client_secret."""
    r = client.post(
        "/register",
        json={
            "client_name": "Test Client",
            "redirect_uris": ["https://example.com/callback"],
            "grant_types": ["authorization_code", "refresh_token"],
            "response_types": ["code"],
            "token_endpoint_auth_method": "none",
        },
    )
    assert r.status_code == 201, r.text[:400]
    body = r.json()
    assert "client_id" in body
    assert "redirect_uris" in body


def test_initialize_with_valid_bearer_returns_capabilities(client: TestClient):
    """Le handshake MCP `initialize` doit aboutir et exposer les capabilities."""
    r = client.post(
        "/mcp",
        json={
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "test-client", "version": "1.0.0"},
            },
        },
        headers={
            "Authorization": "Bearer pk_live_validlooking",
            "Accept": "application/json, text/event-stream",
        },
    )
    assert r.status_code == 200, f"Body: {r.text[:500]}"

    # En mode SSE response, le payload est du SSE (event: message + data: {...}).
    # En mode JSON response, c'est du JSON direct. On parse de facon robuste.
    body_text = r.text
    if "data:" in body_text:
        # SSE format
        data_line = next(
            line for line in body_text.split("\n") if line.startswith("data:")
        )
        body = json.loads(data_line[5:].strip())
    else:
        body = json.loads(body_text)

    assert body["jsonrpc"] == "2.0"
    assert body["id"] == 1
    assert "result" in body
    assert "capabilities" in body["result"]
    assert body["result"]["serverInfo"]["name"] == "permisapi"
