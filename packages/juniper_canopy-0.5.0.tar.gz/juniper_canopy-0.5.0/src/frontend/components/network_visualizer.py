#!/usr/bin/env python
#####################################################################################################################################################################################################
# Project:       Juniper
# Prototype:     Monitoring and Diagnostic Frontend for Cascade Correlation Neural Network
# File Name:     network_visualizer.py
# Author:        Paul Calnon
# Version:       1.7.0
#
# Date:          2025-10-11
# Last Modified: 2026-01-07
#
# License:       MIT License
# Copyright:     Copyright (c) 2024-2025 Paul Calnon
#
# Description:
#    This file contains the code to Visualize the current Cascade Correlation Neural Network prototype
#       including training, state, and architecture with the Juniper prototype Frontend for monitoring and diagnostics.
#
#####################################################################################################################################################################################################
# Notes:
#
# Network Visualizer Component
#
# Interactive visualization of the Cascade Correlation network topology,
# showing input, hidden, and output units with weighted connections.
# Color-coded by layer and connection strength.
#
#####################################################################################################################################################################################################
# References:
#
#####################################################################################################################################################################################################
# TODO :
#
#####################################################################################################################################################################################################
# COMPLETED:
#
#####################################################################################################################################################################################################
import hashlib
import json
import math
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

import networkx as nx
import plotly.graph_objects as go
from dash import dcc, html
from dash.dependencies import Input, Output, State
from plotly.subplots import make_subplots

from canopy_constants import DashboardConstants

from ..base_component import BaseComponent

# import numpy as np


class NetworkVisualizer(BaseComponent):
    """
    Network topology visualization component.

    Displays an interactive graph showing:
    - Input units
    - Hidden units (added dynamically during training)
    - Output units
    - Weighted connections between units
    - Color-coded by layer and connection strength
    """

    def __init__(self, config: Dict[str, Any], component_id: str = "network-visualizer"):
        """
        Initialize network visualizer component.

        Args:
            config: Component configuration dictionary
            component_id: Unique identifier for this component
        """
        super().__init__(config, component_id)

        # Configuration
        self.show_weights = config.get("show_weights", True)
        self.layout_type = config.get("layout", "hierarchical")  # hierarchical or spring

        # Current network state
        self.current_topology: Dict[str, Any] = {
            "input_units": 0,
            "hidden_units": 0,
            "output_units": 0,
            "connections": [],
        }

        self.logger.info(f"NetworkVisualizer initialized with layout={self.layout_type}")

    def get_layout(self) -> html.Div:
        """
        Get Dash layout for network visualizer.

        Returns:
            Dash Div containing the network visualization
        """
        is_dark = False
        return html.Div(
            [
                # Header with controls
                html.Div(
                    [
                        html.H3("Network Topology", style={"display": "inline-block"}),
                        html.Div(
                            [
                                html.Label("Layout:", style={"marginRight": "10px"}),
                                dcc.Dropdown(
                                    id=f"{self.component_id}-layout-selector",
                                    options=[
                                        {"label": "Hierarchical", "value": "hierarchical"},
                                        {"label": "Staggered", "value": "staggered"},
                                        {"label": "Spring", "value": "spring"},
                                        {"label": "Circular", "value": "circular"},
                                    ],
                                    value=self.layout_type,
                                    style={"width": "150px", "display": "inline-block"},
                                ),
                                html.Label("Show Weights:", style={"marginLeft": "20px", "marginRight": "10px"}),
                                dcc.Checklist(
                                    id=f"{self.component_id}-show-weights",
                                    options=[{"label": "", "value": "show"}],
                                    value=["show"] if self.show_weights else [],
                                    style={"display": "inline-block"},
                                ),
                                # OF-1: Display Mode Toggle (Node Graph / Weight Matrix)
                                html.Label("Display:", style={"marginLeft": "20px", "marginRight": "10px"}),
                                dcc.RadioItems(
                                    id=f"{self.component_id}-display-mode",
                                    options=[
                                        {"label": "Node Graph", "value": "node_graph"},
                                        {"label": "Weight Matrix", "value": "weight_matrix"},
                                    ],
                                    value="node_graph",
                                    inline=True,
                                    style={"display": "inline-block"},
                                    inputStyle={"marginRight": "5px"},
                                    labelStyle={"marginRight": "15px"},
                                ),
                                # P3-5: 2D/3D View Toggle
                                html.Label("View:", style={"marginLeft": "20px", "marginRight": "10px"}),
                                dcc.RadioItems(
                                    id=f"{self.component_id}-view-mode",
                                    options=[
                                        {"label": "2D", "value": "2d"},
                                        {"label": "3D", "value": "3d"},
                                    ],
                                    value="2d",
                                    inline=True,
                                    style={"display": "inline-block"},
                                    inputStyle={"marginRight": "5px"},
                                    labelStyle={"marginRight": "15px"},
                                ),
                            ],
                            style={"display": "inline-block", "float": "right"},
                        ),
                    ],
                    style={"marginBottom": "10px"},
                ),
                # CAN-020: Hierarchy-depth slider. Filters which cascade-correlation
                # hidden units (and their incoming/outgoing connections) are rendered.
                # In CasCor the cascade order *is* the hierarchy — unit 0 was added
                # first, unit N-1 most recently. Slider max auto-bumps clientside as
                # the topology grows; the user-picked value persists across grow
                # events so a "show only the first 3 units" focus is not reset on
                # every cascade_add. Hidden until at least one hidden unit exists.
                html.Div(
                    [
                        html.Label(
                            [
                                html.Span("Hidden depth: "),
                                html.Span(id=f"{self.component_id}-depth-label", children="all"),
                            ],
                            style={"marginRight": "10px", "minWidth": "120px", "display": "inline-block"},
                        ),
                        dcc.Slider(
                            id=f"{self.component_id}-depth-slider",
                            min=0,
                            max=0,  # bumped clientside as topology grows
                            step=1,
                            value=0,
                            marks=None,
                            tooltip={"placement": "bottom", "always_visible": False},
                            included=True,
                            updatemode="mouseup",
                        ),
                    ],
                    id=f"{self.component_id}-depth-slider-container",
                    style={"marginBottom": "10px", "padding": "0 10px", "display": "none"},
                ),
                # Network statistics
                html.Div(
                    id=f"{self.component_id}-stats-bar",
                    children=[
                        html.Div(
                            [
                                html.Strong("Input Units: "),
                                html.Span(id=f"{self.component_id}-input-count", children="0"),
                            ],
                            style={"display": "inline-block", "marginRight": "20px"},
                        ),
                        html.Div(
                            [
                                html.Strong("Hidden Units: "),
                                html.Span(id=f"{self.component_id}-hidden-count", children="0"),
                            ],
                            style={"display": "inline-block", "marginRight": "20px"},
                        ),
                        html.Div(
                            [
                                html.Strong("Output Units: "),
                                html.Span(id=f"{self.component_id}-output-count", children="0"),
                            ],
                            style={"display": "inline-block", "marginRight": "20px"},
                        ),
                        html.Div(
                            [
                                html.Strong("Total Connections: "),
                                html.Span(id=f"{self.component_id}-connection-count", children="0"),
                            ],
                            style={"display": "inline-block"},
                        ),
                    ],
                    style={
                        "marginBottom": "15px",
                        "padding": "10px",
                        "backgroundColor": "#2d2d2d" if is_dark else "#f8f9fa",
                        "borderRadius": "3px",
                    },
                ),
                # Selected node info panel
                html.Div(
                    id=f"{self.component_id}-selection-info",
                    children=[],
                    style={
                        "marginBottom": "10px",
                        "padding": "10px",
                        "backgroundColor": "var(--bs-info-bg-subtle, #e3f2fd)",
                        "borderRadius": "4px",
                        "display": "none",
                    },
                ),
                # Network graph
                dcc.Graph(
                    id=f"{self.component_id}-graph",
                    config={
                        "displayModeBar": True,
                        "displaylogo": False,
                        "modeBarButtonsToAdd": ["select2d", "lasso2d"],
                        "toImageButtonOptions": {
                            "format": "png",
                            "scale": 2,
                        },
                    },
                    style={"height": "600px"},
                ),
                # Topology data store
                dcc.Store(id=f"{self.component_id}-topology-store", data=self.current_topology),
                # View state store for preserving zoom, pan, and tool selection
                dcc.Store(
                    id=f"{self.component_id}-view-state",
                    data={
                        "xaxis_range": None,
                        "yaxis_range": None,
                        "dragmode": "pan",
                    },
                ),
                # Previous topology hash to detect changes
                dcc.Store(id=f"{self.component_id}-topology-hash", data=None),
                # Selected nodes store
                dcc.Store(id=f"{self.component_id}-selected-nodes", data=[]),
                # New node highlight state for P2-1: persistent highlighting with fade
                # Structure: {node_id, unit_index, state (active/fading), start_interval, fade_start_interval}
                dcc.Store(
                    id=f"{self.component_id}-new-node-highlight",
                    data=None,
                ),
            ],
            style={"padding": "20px"},
        )

    def register_callbacks(self, app):
        """
        Register Dash callbacks for network visualizer.

        Args:
            app: Dash application instance
        """

        @app.callback(
            Output(f"{self.component_id}-view-state", "data"),
            Input(f"{self.component_id}-graph", "relayoutData"),
            State(f"{self.component_id}-view-state", "data"),
            prevent_initial_call=True,
        )
        def capture_view_state(relayout_data, current_state):
            """Capture user's view state (zoom, pan, tool selection)."""
            if not relayout_data or not current_state:
                return current_state or {"xaxis_range": None, "yaxis_range": None, "dragmode": "pan"}

            new_state = current_state.copy()

            # Capture axis ranges (zoom/pan)
            if "xaxis.range[0]" in relayout_data:
                new_state["xaxis_range"] = [
                    relayout_data["xaxis.range[0]"],
                    relayout_data["xaxis.range[1]"],
                ]
            if "yaxis.range[0]" in relayout_data:
                new_state["yaxis_range"] = [
                    relayout_data["yaxis.range[0]"],
                    relayout_data["yaxis.range[1]"],
                ]

            # Capture tool selection
            if "dragmode" in relayout_data:
                new_state["dragmode"] = relayout_data["dragmode"]

            # Handle autorange/reset
            if relayout_data.get("xaxis.autorange"):
                new_state["xaxis_range"] = None
            if relayout_data.get("yaxis.autorange"):
                new_state["yaxis_range"] = None

            return new_state

        # PERF-CN-01: prevent_initial_call=False — must render initial empty
        # network graph (input/hidden/output counts at zero) on mount; theme-
        # and view-mode-aware so it also redraws when those change.
        @app.callback(
            [
                Output(f"{self.component_id}-graph", "figure"),
                Output(f"{self.component_id}-graph", "config"),
                Output(f"{self.component_id}-input-count", "children"),
                Output(f"{self.component_id}-hidden-count", "children"),
                Output(f"{self.component_id}-output-count", "children"),
                Output(f"{self.component_id}-connection-count", "children"),
                Output(f"{self.component_id}-topology-hash", "data"),
                Output(f"{self.component_id}-new-node-highlight", "data"),
            ],
            [
                Input(f"{self.component_id}-topology-store", "data"),
                Input(f"{self.component_id}-layout-selector", "value"),
                Input(f"{self.component_id}-show-weights", "value"),
                Input(f"{self.component_id}-view-mode", "value"),  # P3-5: 2D/3D toggle
                Input(f"{self.component_id}-display-mode", "value"),  # OF-1: Node Graph / Weight Matrix
                Input(f"{self.component_id}-raw-topology-store", "data"),  # OF-1: Raw topology for heatmap
                Input(f"{self.component_id}-depth-slider", "value"),  # CAN-020: hierarchy depth filter
                Input("metrics-panel-metrics-store", "data"),
                Input("theme-state", "data"),
                Input(f"{self.component_id}-selected-nodes", "data"),
                Input("fast-update-interval", "n_intervals"),
                Input("ws-cascade-add-buffer", "data"),  # D-06: WS cascade_add events trigger topo refresh
            ],
            [
                State(f"{self.component_id}-view-state", "data"),
                State(f"{self.component_id}-topology-hash", "data"),
                State(f"{self.component_id}-new-node-highlight", "data"),
            ],
            prevent_initial_call=False,
        )
        def update_network_graph(
            topology_data: Dict[str, Any],
            layout_type: str,
            show_weights: List[str],
            view_mode: str,  # P3-5: 2D/3D mode
            display_mode: str,  # OF-1: "node_graph" or "weight_matrix"
            raw_topology: Optional[Dict[str, Any]],  # OF-1: Raw topology for heatmap
            depth_filter: Optional[int],  # CAN-020: hierarchy depth filter (None = no filter)
            metrics_data: List[Dict[str, Any]],
            theme: str,
            selected_nodes: List[str],
            n_intervals: int,
            ws_cascade_add: Optional[Dict[str, Any]],  # D-06: WS cascade_add events
            view_state: Dict[str, Any],
            prev_hash: str,
            current_highlight: Optional[Dict[str, Any]],
        ):
            """
            Update network visualization based on topology data.

            Args:
                topology_data: Network topology dictionary
                layout_type: Layout algorithm to use
                show_weights: List containing 'show' if weights should be displayed
                view_mode: View mode ('2d' or '3d')
                display_mode: Display mode ('node_graph' or 'weight_matrix')
                raw_topology: Raw weight-oriented topology for heatmap view
                metrics_data: Historical metrics data for detecting new units
                theme: Current theme
                selected_nodes: List of selected node IDs
                n_intervals: Current interval count for animation timing
                view_state: Stored view state (zoom, pan, dragmode)
                prev_hash: Previous topology hash
                current_highlight: Current new-node highlight state

            Returns:
                Tuple of updated components including new highlight state
            """
            import dash

            # Short-circuit: if only the fast-update-interval fired and there's no
            # active highlight animation, skip the full graph rebuild.
            try:
                ctx = dash.callback_context
                if ctx.triggered and len(ctx.triggered) == 1:
                    trigger_id = ctx.triggered[0]["prop_id"]
                    if "fast-update-interval" in trigger_id and not current_highlight:
                        return (dash.no_update,) * 8
            except Exception:  # nosec B110 — callback_context unavailable outside Dash request
                pass

            def _dynamic_graph_config():
                """Build dcc.Graph config with a timestamped screenshot filename."""
                return {
                    "displayModeBar": True,
                    "displaylogo": False,
                    "modeBarButtonsToAdd": ["select2d", "lasso2d"],
                    "toImageButtonOptions": {
                        "format": "png",
                        "scale": 2,
                        "filename": f"canopy_network_{datetime.now():%Y%m%d_%H%M%S}",
                    },
                }

            def compute_hash(topo):
                key = {
                    "input": topo.get("input_units", 0),
                    "hidden": topo.get("hidden_units", 0),
                    "output": topo.get("output_units", 0),
                    "connections": len(topo.get("connections", [])),
                }
                return hashlib.md5(json.dumps(key, sort_keys=True).encode(), usedforsecurity=False).hexdigest()

            # OF-1: Weight Matrix display mode
            if display_mode == "weight_matrix":
                if raw_topology and raw_topology.get("input_size", 0) > 0:
                    fig = self._create_weight_heatmap(raw_topology, theme=theme)
                    input_count = str(raw_topology.get("input_size", 0))
                    hidden_count = str(len(raw_topology.get("hidden_units", [])))
                    output_count = str(raw_topology.get("output_size", 0))
                    connection_count = "—"
                    return fig, _dynamic_graph_config(), input_count, hidden_count, output_count, connection_count, prev_hash, current_highlight
                else:
                    empty_fig = self._create_empty_graph(theme)
                    return empty_fig, _dynamic_graph_config(), "0", "0", "0", "—", None, None

            if not topology_data or topology_data.get("input_units", 0) == 0:
                empty_fig = self._create_empty_graph(theme, view_mode=view_mode)
                return empty_fig, _dynamic_graph_config(), "0", "0", "0", "0", None, None

            # CAN-020: hierarchy filter — keep only the first ``depth_filter``
            # hidden units (cascade order). Run BEFORE compute_hash so the
            # cache invalidates when the filter changes; run AFTER the empty-
            # topology fast-path so we don't bother filtering an empty topo.
            n_hidden_total = topology_data.get("hidden_units", 0)
            topology_data, depth_label = self._apply_hierarchy_filter(topology_data, depth_filter, n_hidden_total)
            current_hash = compute_hash(topology_data)
            n_hidden = topology_data.get("hidden_units", 0)

            # Detect newly added hidden unit from metrics delta
            newly_added_unit = None
            if metrics_data and len(metrics_data) >= 2:
                prev_hidden = metrics_data[-2].get("network_topology", {}).get("hidden_units", 0)
                curr_hidden = metrics_data[-1].get("network_topology", {}).get("hidden_units", 0)
                if curr_hidden > prev_hidden:
                    newly_added_unit = curr_hidden - 1  # Index of new unit

            # P2-1: Manage new node highlight state
            new_highlight = self._update_highlight_state(
                current_highlight=current_highlight,
                newly_added_unit=newly_added_unit,
                n_hidden=n_hidden,
                selected_nodes=selected_nodes,
                n_intervals=n_intervals,
            )

            # Calculate highlight visual properties (pulse scale, opacity)
            highlight_props = self._calculate_highlight_properties(new_highlight, n_intervals)

            show_weight_labels = bool(show_weights) and ("show" in show_weights)

            # P3-5: Select 2D or 3D rendering
            if view_mode == "3d":
                fig = self._create_3d_network_graph(
                    topology_data,
                    layout_type,
                    show_weight_labels,
                    theme=theme,
                )
            else:
                # Create 2D network graph with enhanced highlight info
                fig = self._create_network_graph(
                    topology_data,
                    layout_type,
                    show_weight_labels,
                    newly_added_unit=None,  # Disable old highlighting, use new system
                    theme=theme,
                    selected_nodes=selected_nodes,
                    new_node_highlight=highlight_props,
                )

                # Apply stored view state (2D only)
                if view_state:
                    if view_state.get("xaxis_range"):
                        fig.update_layout(xaxis_range=view_state["xaxis_range"])
                    if view_state.get("yaxis_range"):
                        fig.update_layout(yaxis_range=view_state["yaxis_range"])
                    if view_state.get("dragmode"):
                        fig.update_layout(dragmode=view_state["dragmode"])

            # Extract counts
            input_count = str(topology_data.get("input_units", 0))
            # CAN-020: when filtering, surface "K of N" so the user can see
            # what's hidden vs. shown without losing the total in the stats bar.
            if n_hidden_total != n_hidden:
                hidden_count = f"{n_hidden} of {n_hidden_total}"
            else:
                hidden_count = str(n_hidden)
            output_count = str(topology_data.get("output_units", 0))
            connection_count = str(len(topology_data.get("connections", [])))

            return fig, _dynamic_graph_config(), input_count, hidden_count, output_count, connection_count, current_hash, new_highlight

        # PERF-CN-01: prevent_initial_call=False — theme-driven styling must be
        # applied on mount so the network stats bar matches the active theme.
        @app.callback(
            Output(f"{self.component_id}-stats-bar", "style"),
            Input("theme-state", "data"),
            prevent_initial_call=False,
        )
        def update_stats_bar_theme(theme):
            """Update stats bar background for dark mode."""
            is_dark = theme == "dark"
            return {
                "marginBottom": "15px",
                "padding": "10px",
                "backgroundColor": "#343a40" if is_dark else "#f8f9fa",
                "color": "#f8f9fa" if is_dark else "#212529",
                "borderRadius": "3px",
            }

        @app.callback(
            [
                Output(f"{self.component_id}-selected-nodes", "data"),
                Output(f"{self.component_id}-selection-info", "children"),
                Output(f"{self.component_id}-selection-info", "style"),
            ],
            [
                Input(f"{self.component_id}-graph", "clickData"),
                Input(f"{self.component_id}-graph", "selectedData"),
            ],
            [
                State(f"{self.component_id}-selected-nodes", "data"),
                State("theme-state", "data"),
            ],
            prevent_initial_call=True,
        )
        def handle_node_selection(click_data, selected_data, current_selection, theme):
            """Handle node selection via click or box/lasso select."""
            import dash

            ctx = dash.callback_context
            trigger = ctx.triggered[0]["prop_id"] if ctx.triggered else ""

            is_dark = theme == "dark" if theme else False
            base_style = {
                "marginBottom": "10px",
                "padding": "10px",
                "backgroundColor": "#1a3a5c" if is_dark else "#e3f2fd",
                "borderRadius": "4px",
                "border": "1px solid #2c5282" if is_dark else "1px solid #90caf9",
            }
            hidden_style = {**base_style, "display": "none"}
            visible_style = {**base_style, "display": "block"}
            secondary_color = "#adb5bd" if is_dark else "#666"
            hint_color = "#9ca3af" if is_dark else "#888"

            # Handle box/lasso selection
            if "selectedData" in trigger and selected_data:
                points = selected_data.get("points", [])
                if points:
                    selected_nodes = []
                    for point in points:
                        text = point.get("text", "")
                        if text:
                            node_id = text.lower().replace(" ", "_")
                            selected_nodes.append(node_id)

                    if selected_nodes:
                        info = html.Div(
                            [
                                html.Strong(f"Selected: {len(selected_nodes)} node(s)"),
                                html.Ul([html.Li(n.replace("_", " ").title()) for n in selected_nodes[:5]]),
                                html.Span(
                                    "(Click elsewhere to deselect)",
                                    style={"fontSize": "11px", "color": hint_color},
                                ),
                            ]
                        )
                        return selected_nodes, info, visible_style

            # Handle single click selection
            if "clickData" in trigger and click_data:
                points = click_data.get("points", [])
                if points:
                    point = points[0]
                    text = point.get("text", "")
                    if text:
                        node_id = text.lower().replace(" ", "_")

                        # Toggle selection: if already selected, deselect
                        if current_selection and node_id in current_selection:
                            return [], [], hidden_style

                        # Get node info
                        curve_number = point.get("curveNumber", 0)
                        layer_names = ["", "", "Input", "Hidden", "Output"]
                        layer = layer_names[min(curve_number, 4)] if curve_number >= 2 else "Unknown"

                        info = html.Div(
                            [
                                html.Strong(f"Selected: {text}"),
                                html.Br(),
                                html.Span(f"Layer: {layer}", style={"color": secondary_color}),
                                html.Br(),
                                html.Span(
                                    "(Click again or elsewhere to deselect)",
                                    style={"fontSize": "11px", "color": hint_color},
                                ),
                            ]
                        )
                        return [node_id], info, visible_style

            # No valid selection, clear
            return [], [], hidden_style

        @app.callback(
            Output(f"{self.component_id}-selection-info", "style", allow_duplicate=True),
            Input("theme-state", "data"),
            State(f"{self.component_id}-selection-info", "style"),
            prevent_initial_call=True,
        )
        def update_selection_info_theme(theme, current_style):
            """Update selection info panel colors when theme changes."""
            import dash

            if not current_style:
                return dash.no_update
            is_dark = theme == "dark" if theme else False
            return {
                **current_style,
                "backgroundColor": "#1a3a5c" if is_dark else "#e3f2fd",
                "border": "1px solid #2c5282" if is_dark else "1px solid #90caf9",
            }

        # CAN-020: clientside slider-bounds + label sync. The slider's ``max``
        # must track ``topology.hidden_units`` so the user can pick any cascade
        # depth, and the container should hide entirely when there are zero
        # hidden units (no useful filter to apply). The label below the slider
        # reads "all" when the value is at max (no filter active) and the
        # explicit count otherwise. Done clientside so we don't need to round-
        # trip the topology store through the server every time a unit is added.
        app.clientside_callback(
            """
            function(topology, currentValue) {
                if (!topology) {
                    return [0, 0, {marginBottom: "10px", padding: "0 10px", display: "none"}, "all"];
                }
                var nHidden = topology.hidden_units || 0;
                if (nHidden === 0) {
                    return [0, 0, {marginBottom: "10px", padding: "0 10px", display: "none"}, "all"];
                }
                // Bump max to current hidden-unit count.
                // Preserve the user-picked value across grow events as long as
                // it's still in range; otherwise snap to the new max (= show all).
                var v = currentValue;
                if (v === null || v === undefined || v > nHidden) {
                    v = nHidden;
                }
                var label = (v === nHidden) ? "all" : (v + " of " + nHidden);
                return [
                    nHidden,
                    v,
                    {marginBottom: "10px", padding: "0 10px", display: "block"},
                    label
                ];
            }
            """,
            [
                Output(f"{self.component_id}-depth-slider", "max"),
                Output(f"{self.component_id}-depth-slider", "value"),
                Output(f"{self.component_id}-depth-slider-container", "style"),
                Output(f"{self.component_id}-depth-label", "children"),
            ],
            Input(f"{self.component_id}-topology-store", "data"),
            State(f"{self.component_id}-depth-slider", "value"),
        )

        self.logger.debug(f"Callbacks registered for {self.component_id}")

    @staticmethod
    def _apply_hierarchy_filter(
        topology: Dict[str, Any],
        depth: Optional[int],
        n_hidden_total: int,
    ) -> tuple[Dict[str, Any], str]:
        """CAN-020: filter ``topology`` to the first ``depth`` hidden units.

        Returns ``(filtered_topology, depth_label)``. If ``depth`` is None,
        zero, or >= the total hidden count, the original topology is returned
        unchanged with label "all". Otherwise:
        - ``hidden_units`` is capped at ``depth``
        - ``connections`` drops any edge touching ``hidden_K`` for K >= depth

        The filter is a no-op for topologies with zero hidden units. We never
        mutate the input dict — the input is a Dash store payload that other
        callbacks may also read, and mutation would race.
        """
        if depth is None or depth <= 0 or depth >= n_hidden_total or n_hidden_total == 0:
            return topology, "all"

        filtered = dict(topology)
        filtered["hidden_units"] = depth

        connections = topology.get("connections", []) or []
        kept = []
        for conn in connections:
            from_node = str(conn.get("from", ""))
            to_node = str(conn.get("to", ""))
            if from_node.startswith("hidden_"):
                try:
                    if int(from_node.split("_", 1)[1]) >= depth:
                        continue
                except (ValueError, IndexError):
                    pass
            if to_node.startswith("hidden_"):
                try:
                    if int(to_node.split("_", 1)[1]) >= depth:
                        continue
                except (ValueError, IndexError):
                    pass
            kept.append(conn)
        filtered["connections"] = kept
        return filtered, f"{depth} of {n_hidden_total}"

    def _create_network_graph(
        self,
        topology: Dict[str, Any],
        layout_type: str,
        show_weights: bool,
        newly_added_unit: int = None,
        theme: str = "light",
        selected_nodes: List[str] = None,
        new_node_highlight: Optional[Dict[str, Any]] = None,
    ) -> go.Figure:
        """
        Create network graph visualization.

        Args:
            topology: Network topology dictionary
            layout_type: Layout algorithm ('hierarchical', 'spring', 'circular')
            show_weights: Whether to display weight values on edges
            newly_added_unit: Index of newly added hidden unit (for highlighting) - deprecated, use new_node_highlight
            theme: Current theme ("light" or "dark")
            selected_nodes: List of selected node IDs for highlighting
            new_node_highlight: P2-1 enhanced highlight props {node_id, size_scale, opacity}

        Returns:
            Plotly figure object
        """
        # Create NetworkX graph
        G = nx.DiGraph()

        # Add nodes
        n_input = topology.get("input_units", 0)
        n_hidden = topology.get("hidden_units", 0)
        n_output = topology.get("output_units", 0)

        # Add input nodes
        for i in range(n_input):
            G.add_node(f"input_{i}", layer="input", index=i)

        # Add hidden nodes
        for i in range(n_hidden):
            G.add_node(f"hidden_{i}", layer="hidden", index=i)

        # Add output nodes
        for i in range(n_output):
            G.add_node(f"output_{i}", layer="output", index=i)

        # Add edges with weights
        connections = topology.get("connections", [])
        for conn in connections:
            from_node = conn.get("from")
            to_node = conn.get("to")
            weight = conn.get("weight", 0.0)

            if from_node and to_node:
                G.add_edge(from_node, to_node, weight=weight)

        # Calculate layout positions
        pos = self._calculate_layout(G, layout_type, n_input, n_hidden, n_output)

        # Create edge traces
        edge_traces = self._create_edge_traces(G, pos, show_weights)

        # Create node traces
        node_traces = self._create_node_traces(G, pos)

        # Combine traces
        fig = go.Figure(data=edge_traces + node_traces)

        # P2-1: Add new node highlight with pulsing glow and edge highlights
        if new_node_highlight:
            new_node_traces = self._create_new_node_highlight_traces(G, pos, new_node_highlight)
            for trace in new_node_traces:
                fig.add_trace(trace)
        elif newly_added_unit is not None and newly_added_unit < n_hidden:
            # Fallback to old-style highlighting (for backwards compatibility)
            hidden_node = f"hidden_{newly_added_unit}"
            if hidden_node in pos:
                x, y = pos[hidden_node]
                fig.add_trace(
                    go.Scatter(
                        x=[x],
                        y=[y],
                        mode="markers",
                        marker={
                            "size": 28,
                            "color": "#17a2b8",
                            "line": {"width": 4, "color": "#fff"},
                            "opacity": 0.9,
                        },
                        name="New Unit",
                        showlegend=False,
                        hoverinfo="skip",
                    )
                )

        # Add selection highlights if any nodes are selected
        if selected_nodes:
            selection_traces = self._create_selection_highlight(pos, selected_nodes)
            for trace in selection_traces:
                fig.add_trace(trace)

        # Update layout
        is_dark = theme == "dark"

        # Theme-aware legend styling (P0-9: transparent background, bottom-left position)
        legend_bgcolor = "rgba(36, 36, 36, 0.7)" if is_dark else "rgba(248, 249, 250, 0.7)"
        legend_font_color = "#f8f9fa" if is_dark else "#212529"

        fig.update_layout(
            title="Cascade Correlation Network Architecture",
            showlegend=True,
            hovermode="closest",
            margin={"l": 20, "r": 20, "t": 40, "b": 20},
            xaxis={"showgrid": False, "zeroline": False, "showticklabels": False},
            yaxis={"showgrid": False, "zeroline": False, "showticklabels": False},
            template="plotly_dark" if is_dark else "plotly",
            plot_bgcolor="#242424" if is_dark else "#f8f9fa",
            paper_bgcolor="#242424" if is_dark else "#ffffff",
            font={"color": "#e9ecef" if is_dark else "#212529"},
            legend={
                "x": 0.02,
                "y": 0.02,
                "xanchor": "left",
                "yanchor": "bottom",
                "bgcolor": legend_bgcolor,
                "bordercolor": "rgba(0, 0, 0, 0)",
                "borderwidth": 0,
                "font": {"color": legend_font_color},
            },
            transition={"duration": 500, "easing": "cubic-in-out"},
            dragmode="pan",
        )

        return fig

    def _calculate_layout(
        self,
        G: nx.DiGraph,
        layout_type: str,
        n_input: int,
        n_hidden: int,
        n_output: int,
        scale: float = DashboardConstants.DEFAULT_SCALE,
    ) -> Dict[str, Tuple[float, float]]:
        """
        Calculate node positions based on layout algorithm.

        Args:
            G: NetworkX graph
            layout_type: Layout algorithm to use
            n_input: Number of input units
            n_hidden: Number of hidden units
            n_output: Number of output units

        Returns:
            Dictionary mapping node IDs to (x, y) positions
        """
        if layout_type == "circular":
            return dict(self._layout_type_circular(G=G, scale=scale))
        elif layout_type == "hierarchical":  # Hierarchical layout with layers
            return dict(self._layout_type_hierarchical(G=G, n_input=n_input, n_hidden=n_hidden, n_output=n_output))
        elif layout_type == "spring":  # Spring layout with constraints
            return dict(self._layout_type_sprint(G=G, k=2, iterations=50, seed=42))  # TODO: Convert these magic numbers into constants
        elif layout_type == "staggered":
            return dict(self._layout_type_staggered(G=G, n_input=n_input, n_hidden=n_hidden, n_output=n_output))
        else:  # Default to hierarchical
            return self._calculate_layout(G=G, layout_type="hierarchical", n_input=n_input, n_hidden=n_hidden, n_output=n_output)

    def _layout_type_circular(self, G: nx.DiGraph, scale: float = None):
        return nx.circular_layout(G, scale=scale)

    def _layout_type_hierarchical(self, G: nx.DiGraph, n_input: int, n_hidden: int, n_output: int):
        pos = {}
        # Input layer (left)
        for i in range(n_input):
            y = (i - n_input / 2) * 1.5
            pos[f"input_{i}"] = (0, y)
        # Hidden layer (middle) - staggered layout for better edge visibility
        if n_hidden > 0:
            self._calculate_hidden_node_position_offsets(n_hidden, pos)
        # Output layer (right)
        for i in range(n_output):
            y = (i - n_output / 2) * 1.5
            pos[f"output_{i}"] = (10, y)
        return pos

    def _layout_type_sprint(self, G: nx.DiGraph, k: float, iterations: int, seed: int):
        pos = nx.spring_layout(G, k=k, iterations=iterations, seed=seed)
        # Scale positions
        for node in pos:
            pos[node] = (pos[node][0] * 10, pos[node][1] * 10)
        return pos

    def _layout_type_staggered(self, G: nx.DiGraph, n_input: int, n_hidden: int, n_output: int):
        # Staggered hierarchical layout (same as hierarchical but more explicit)
        pos = {}
        # Input layer (left)
        for i in range(n_input):
            y = (i - n_input / 2) * 1.5
            pos[f"input_{i}"] = (0, y)
        # Hidden layer (middle) - staggered layout
        if n_hidden > 0:
            base_x = 5.0
            spread = min(3.0, max(1.5, n_hidden * 0.5))
            for i in range(n_hidden):
                y = (i - n_hidden / 2) * 1.5
                # Zigzag pattern
                if n_hidden == 1:
                    x = base_x
                else:
                    # Distribute across spread range
                    position_ratio = i / max(1, n_hidden - 1)
                    x = base_x - spread / 2 + position_ratio * spread
                    # Add small offset for zigzag effect
                    x += 0.3 if i % 2 == 0 else -0.3
                pos[f"hidden_{i}"] = (x, y)
        # Output layer (right)
        for i in range(n_output):
            y = (i - n_output / 2) * 1.5
            pos[f"output_{i}"] = (10, y)
        return pos

    def _calculate_hidden_node_position_offsets(self, n_hidden, pos):
        # Base x position (midpoint between input and output)
        base_x = 5.0
        # Stagger offset (horizontal spread)
        stagger_offset = 1.2

        # Calculate positions with alternating offsets
        hidden_x_positions = []
        for i in range(n_hidden):
            # Alternate left/right: even indices go right, odd go left
            offset = stagger_offset / 2 if i % 2 == 0 else -stagger_offset / 2
            hidden_x_positions.append(base_x + offset)

        # If more than 2 nodes, use a more spread-out stagger pattern
        if n_hidden > 2:
            # Distribute nodes across a wider horizontal range
            spread = min(3.0, n_hidden * 0.4)
            for i in range(n_hidden):
                # Create a wave pattern: first node at center, then alternating outward
                if i == 0:
                    hidden_x_positions[i] = base_x
                else:
                    # Alternate left and right with increasing offset
                    direction = 1 if i % 2 == 1 else -1
                    offset_level = (i + 1) // 2
                    hidden_x_positions[i] = base_x + direction * (offset_level * spread / max(1, (n_hidden // 2)))

        # Apply positions
        for i in range(n_hidden):
            y = (i - n_hidden / 2) * 1.5
            pos[f"hidden_{i}"] = (hidden_x_positions[i], y)

    def _create_edge_traces(self, G: nx.DiGraph, pos: Dict[str, Tuple[float, float]], show_weights: bool) -> List[go.Scatter]:
        """
        Create edge traces for the graph.

        Args:
            G: NetworkX graph
            pos: Node positions
            show_weights: Whether to show weight labels

        Returns:
            List of Scatter traces for edges
        """
        edge_traces = []

        # Group edges by weight magnitude for coloring
        for edge in G.edges(data=True):
            from_node, to_node, data = edge
            weight = data.get("weight", 0.0)

            x0, y0 = pos[from_node]
            x1, y1 = pos[to_node]

            # Color based on weight (red for negative, blue for positive)
            color = "#3498db" if weight >= 0 else "#e74c3c"

            # Line width based on weight magnitude
            width = min(5, max(0.5, abs(weight) * 3))

            edge_trace = go.Scatter(
                x=[x0, x1, None],
                y=[y0, y1, None],
                mode="lines",
                line={"width": width, "color": color},
                hoverinfo="text",
                hovertext=f"Weight: {weight:.3f}",
                showlegend=False,
            )
            edge_traces.append(edge_trace)

            # Add weight label if requested
            if show_weights:
                mid_x = (x0 + x1) / 2
                mid_y = (y0 + y1) / 2

                label_trace = go.Scatter(
                    x=[mid_x],
                    y=[mid_y],
                    mode="text",
                    text=[f"{weight:.2f}"],
                    textfont={"size": 8, "color": "#7f8c8d"},
                    hoverinfo="skip",
                    showlegend=False,
                )
                edge_traces.append(label_trace)

        return edge_traces

    def _create_node_traces(self, G: nx.DiGraph, pos: Dict[str, Tuple[float, float]]) -> List[go.Scatter]:
        """
        Create node traces for the graph.

        Args:
            G: NetworkX graph
            pos: Node positions

        Returns:
            List of Scatter traces for nodes
        """
        # Separate nodes by layer
        input_nodes = [n for n in G.nodes() if G.nodes[n].get("layer") == "input"]
        hidden_nodes = [n for n in G.nodes() if G.nodes[n].get("layer") == "hidden"]
        output_nodes = [n for n in G.nodes() if G.nodes[n].get("layer") == "output"]

        node_traces = []

        # Input nodes (green)
        if input_nodes:
            node_trace = self._create_node_trace(input_nodes, pos, "#2ecc71", "Input Units")
            node_traces.append(node_trace)

        # Hidden nodes (blue)
        if hidden_nodes:
            node_trace = self._create_node_trace(hidden_nodes, pos, "#3498db", "Hidden Units")
            node_traces.append(node_trace)

        # Output nodes (red)
        if output_nodes:
            node_trace = self._create_node_trace(output_nodes, pos, "#e74c3c", "Output Units")
            node_traces.append(node_trace)

        return node_traces

    def _create_node_trace(self, nodes: List[str], pos: Dict[str, Tuple[float, float]], color: str, name: str) -> go.Scatter:
        """
        Create a scatter trace for a group of nodes.

        Args:
            nodes: List of node IDs
            pos: Node positions
            color: Node color
            name: Trace name for legend

        Returns:
            Scatter trace object
        """
        x_coords = [pos[node][0] for node in nodes]
        y_coords = [pos[node][1] for node in nodes]
        labels = [node.replace("_", " ").title() for node in nodes]

        return go.Scatter(
            x=x_coords,
            y=y_coords,
            mode="markers+text",
            marker={"size": 20, "color": color, "line": {"width": 2, "color": "white"}},
            text=labels,
            textposition="middle center",
            textfont={"size": 10, "color": "white", "family": "Arial Black"},
            hoverinfo="text",
            hovertext=labels,
            name=name,
        )

    def _create_selection_highlight(self, pos: Dict[str, Tuple[float, float]], selected_nodes: List[str]) -> List[go.Scatter]:
        """
        Create highlight traces for selected nodes.

        Args:
            pos: Node positions
            selected_nodes: List of selected node IDs

        Returns:
            List of Scatter traces for selection highlights
        """
        if not selected_nodes:
            return []

        highlight_traces = []
        for node_id in selected_nodes:
            if node_id in pos:
                x, y = pos[node_id]
                highlight_traces.extend(
                    (
                        go.Scatter(
                            x=[x],
                            y=[y],
                            mode="markers",
                            marker={
                                "size": 35,
                                "color": "rgba(255, 193, 7, 0.5)",  # Yellow glow
                                "line": {"width": 3, "color": "#ffc107"},
                            },
                            name="Selected",
                            showlegend=False,
                            hoverinfo="skip",
                        ),
                        go.Scatter(
                            x=[x],
                            y=[y],
                            mode="markers",
                            marker={
                                "size": 28,
                                "color": "rgba(0, 0, 0, 0)",
                                "line": {"width": 3, "color": "#ff9800"},
                            },
                            name="Selected Ring",
                            showlegend=False,
                            hoverinfo="skip",
                        ),
                    )
                )
        return highlight_traces

    def _create_weight_heatmap(self, raw_topology: Dict[str, Any], theme: str = "light") -> go.Figure:
        """Create a weight matrix heatmap from raw CasCor topology (OF-1).

        Args:
            raw_topology: Raw weight-oriented topology dict from CasCor
            theme: Current theme ("light" or "dark")

        Returns:
            Plotly figure with weight heatmaps for hidden units and output layer
        """
        hidden_units = raw_topology.get("hidden_units", [])
        output_weights = raw_topology.get("output_weights", [])
        input_size = raw_topology.get("input_size", 0)
        output_size = raw_topology.get("output_size", 0)

        is_dark = theme == "dark"
        n_rows = len(hidden_units) + (1 if output_weights else 0)

        if n_rows == 0:
            return self._create_empty_graph(theme)

        subplot_titles = [f"Hidden Unit {i} Weights" for i in range(len(hidden_units))]
        if output_weights:
            subplot_titles.append("Output Weights")

        row_heights = [1] * len(hidden_units)
        if output_weights:
            row_heights.append(max(output_size, 1))

        fig = make_subplots(
            rows=n_rows,
            cols=1,
            subplot_titles=subplot_titles,
            vertical_spacing=0.08 if n_rows <= 5 else 0.04,
            row_heights=row_heights,
        )

        # Hidden unit weight vectors as single-row heatmaps
        for i, unit in enumerate(hidden_units):
            weights = unit.get("weights", [])
            labels = [f"in_{j}" for j in range(input_size)] + [f"h_{j}" for j in range(i)]
            bias = unit.get("bias", 0.0)
            activation = unit.get("activation", "?")
            fig.add_trace(
                go.Heatmap(
                    z=[weights],
                    x=labels,
                    y=[f"H{i}"],
                    colorscale="RdBu",
                    zmid=0,
                    showscale=(i == 0),
                    hovertemplate="From: %{x}<br>Weight: %{z:.4f}<extra>H" + str(i) + f" (bias={bias:.3f}, {activation})</extra>",
                ),
                row=i + 1,
                col=1,
            )

        # Output weight matrix as 2D heatmap
        if output_weights:
            row_labels = [f"in_{j}" for j in range(input_size)] + [f"h_{j}" for j in range(len(hidden_units))]
            # output_weights from CasCor: list of columns, each column has output_size values
            # Transpose to (num_outputs, num_input_sources) for display
            n_sources = len(output_weights)
            z_matrix = []
            for out_idx in range(output_size):
                row = [output_weights[src][out_idx] if out_idx < len(output_weights[src]) else 0.0 for src in range(n_sources)]
                z_matrix.append(row)
            out_labels = [f"out_{j}" for j in range(output_size)]

            output_bias = raw_topology.get("output_bias", [])
            bias_text = ", ".join(f"{b:.3f}" for b in output_bias) if output_bias else "N/A"
            fig.add_trace(
                go.Heatmap(
                    z=z_matrix,
                    x=row_labels,
                    y=out_labels,
                    colorscale="RdBu",
                    zmid=0,
                    showscale=True,
                    hovertemplate="From: %{x}<br>To: %{y}<br>Weight: %{z:.4f}<extra>Output (bias=" + bias_text + ")</extra>",
                ),
                row=n_rows,
                col=1,
            )

        # Calculate dynamic height based on content
        height = max(400, 100 * n_rows + 100)

        fig.update_layout(
            template="plotly_dark" if is_dark else "plotly",
            plot_bgcolor="#242424" if is_dark else "#f8f9fa",
            paper_bgcolor="#242424" if is_dark else "#ffffff",
            height=height,
            margin={"l": 60, "r": 20, "t": 40, "b": 20},
            title={
                "text": "Weight Matrix View",
                "font": {"size": 14, "color": "#adb5bd" if is_dark else "#495057"},
                "x": 0.5,
            },
        )

        return fig

    def _create_empty_graph(self, theme: str = "light", view_mode: str = "2d") -> go.Figure:
        """
        Create empty placeholder graph.

        Args:
            theme: Current theme ("light" or "dark")
            view_mode: View mode ("2d" or "3d")

        Returns:
            Empty Plotly figure
        """
        fig = go.Figure()

        is_dark = theme == "dark"
        text_color = "#adb5bd" if is_dark else "#6c757d"

        fig.add_annotation(
            text="No network topology available",
            xref="paper",
            yref="paper",
            x=0.5,
            y=0.5,
            showarrow=False,
            font={"size": 16, "color": text_color},
        )

        base_layout = {
            "template": "plotly_dark" if is_dark else "plotly",
            "plot_bgcolor": "#242424" if is_dark else "#f8f9fa",
            "paper_bgcolor": "#242424" if is_dark else "#ffffff",
            "margin": {"l": 20, "r": 20, "t": 20, "b": 20},
        }

        if view_mode == "3d":
            base_layout["scene"] = {
                "xaxis": {"showgrid": False, "showticklabels": False, "zeroline": False, "visible": False},
                "yaxis": {"showgrid": False, "showticklabels": False, "zeroline": False, "visible": False},
                "zaxis": {"showgrid": False, "showticklabels": False, "zeroline": False, "visible": False},
                "bgcolor": "#242424" if is_dark else "#f8f9fa",
            }
        else:
            base_layout["xaxis"] = {"showgrid": False, "showticklabels": False, "zeroline": False}
            base_layout["yaxis"] = {"showgrid": False, "showticklabels": False, "zeroline": False}

        fig.update_layout(**base_layout)

        return fig

    def _create_3d_network_graph(
        self,
        topology: Dict[str, Any],
        layout_type: str,
        show_weights: bool,
        theme: str = "light",
    ) -> go.Figure:
        """
        Create 3D network graph visualization (P3-5).

        Args:
            topology: Network topology dictionary
            layout_type: Layout algorithm ('hierarchical', etc.)
            show_weights: Whether to display weight values on edges
            theme: Current theme ("light" or "dark")

        Returns:
            Plotly figure object with 3D visualization
        """
        # Create NetworkX graph
        G = nx.DiGraph()

        n_input = topology.get("input_units", 0)
        n_hidden = topology.get("hidden_units", 0)
        n_output = topology.get("output_units", 0)

        # Add nodes
        for i in range(n_input):
            G.add_node(f"input_{i}", layer="input", index=i)
        for i in range(n_hidden):
            G.add_node(f"hidden_{i}", layer="hidden", index=i)
        for i in range(n_output):
            G.add_node(f"output_{i}", layer="output", index=i)

        # Add edges
        connections = topology.get("connections", [])
        for conn in connections:
            from_node = conn.get("from")
            to_node = conn.get("to")
            weight = conn.get("weight", 0.0)
            if from_node and to_node:
                G.add_edge(from_node, to_node, weight=weight)

        # Calculate 3D positions (layer as z-axis)
        pos_3d = self._calculate_3d_layout(n_input, n_hidden, n_output)

        # Create edge traces (3D lines)
        edge_traces = []
        for from_node, to_node, data in G.edges(data=True):
            if from_node in pos_3d and to_node in pos_3d:
                x0, y0, z0 = pos_3d[from_node]
                x1, y1, z1 = pos_3d[to_node]
                weight = data.get("weight", 0.0)

                # Color by weight (blue negative, gray zero, red positive)
                if weight > 0:
                    color = f"rgba(220, 53, 69, {min(1.0, abs(weight) * 0.8 + 0.2)})"
                elif weight < 0:
                    color = f"rgba(0, 123, 255, {min(1.0, abs(weight) * 0.8 + 0.2)})"
                else:
                    color = "rgba(150, 150, 150, 0.4)"

                edge_traces.append(
                    go.Scatter3d(
                        x=[x0, x1, None],
                        y=[y0, y1, None],
                        z=[z0, z1, None],
                        mode="lines",
                        line={"color": color, "width": max(1, min(5, abs(weight) * 3 + 1))},
                        hoverinfo="skip",
                        showlegend=False,
                    )
                )

        # Create node traces by layer
        layer_colors = {
            "input": "#28a745",  # Green
            "hidden": "#17a2b8",  # Teal
            "output": "#dc3545",  # Red
        }

        node_traces = []
        for layer, color in layer_colors.items():
            layer_nodes = [n for n, d in G.nodes(data=True) if d.get("layer") == layer]
            if not layer_nodes:
                continue

            x_vals = [pos_3d[n][0] for n in layer_nodes]
            y_vals = [pos_3d[n][1] for n in layer_nodes]
            z_vals = [pos_3d[n][2] for n in layer_nodes]
            labels = [n.replace("_", " ").title() for n in layer_nodes]

            node_traces.append(
                go.Scatter3d(
                    x=x_vals,
                    y=y_vals,
                    z=z_vals,
                    mode="markers+text",
                    marker={
                        "size": 12,
                        "color": color,
                        "line": {"width": 1, "color": "#ffffff"},
                        "opacity": 0.9,
                    },
                    text=labels,
                    textposition="top center",
                    textfont={"size": 10},
                    name=f"{layer.title()} Layer",
                    hoverinfo="text",
                )
            )

        # Combine traces
        fig = go.Figure(data=edge_traces + node_traces)

        # Update layout for 3D
        is_dark = theme == "dark"
        fig.update_layout(
            title="Cascade Correlation Network Architecture (3D)",
            showlegend=True,
            hovermode="closest",
            margin={"l": 0, "r": 0, "t": 40, "b": 0},
            template="plotly_dark" if is_dark else "plotly",
            paper_bgcolor="#242424" if is_dark else "#ffffff",
            scene={
                "xaxis": {
                    "showgrid": True,
                    "gridcolor": "#444" if is_dark else "#ddd",
                    "showticklabels": False,
                    "title": "",
                    "zeroline": False,
                    "backgroundcolor": "#242424" if is_dark else "#f8f9fa",
                },
                "yaxis": {
                    "showgrid": True,
                    "gridcolor": "#444" if is_dark else "#ddd",
                    "showticklabels": False,
                    "title": "",
                    "zeroline": False,
                    "backgroundcolor": "#242424" if is_dark else "#f8f9fa",
                },
                "zaxis": {
                    "showgrid": True,
                    "gridcolor": "#444" if is_dark else "#ddd",
                    "showticklabels": True,
                    "title": "Layer",
                    "ticktext": ["Input", "Hidden", "Output"],
                    "tickvals": [0, 1, 2],
                    "zeroline": False,
                    "backgroundcolor": "#242424" if is_dark else "#f8f9fa",
                },
                "camera": {
                    "eye": {"x": 1.5, "y": 1.5, "z": 0.8},
                    "up": {"x": 0, "y": 0, "z": 1},
                },
                "aspectmode": "manual",
                "aspectratio": {"x": 1, "y": 1, "z": 0.5},
            },
            legend={
                "x": 0.02,
                "y": 0.98,
                "xanchor": "left",
                "yanchor": "top",
                "bgcolor": "rgba(36, 36, 36, 0.7)" if is_dark else "rgba(248, 249, 250, 0.7)",
                "font": {"color": "#f8f9fa" if is_dark else "#212529"},
            },
        )

        return fig

    def _calculate_3d_layout(
        self,
        n_input: int,
        n_hidden: int,
        n_output: int,
    ) -> Dict[str, Tuple[float, float, float]]:
        """
        Calculate 3D node positions for network visualization (P3-5).

        Uses layers as z-axis, with input at z=0, hidden at z=1, output at z=2.
        Nodes are spread in x/y plane within each layer.

        Args:
            n_input: Number of input units
            n_hidden: Number of hidden units
            n_output: Number of output units

        Returns:
            Dictionary mapping node IDs to (x, y, z) positions
        """
        pos = {}

        # Input layer (z=0) - arranged in a line along y-axis
        for i in range(n_input):
            x = 0
            y = (i - n_input / 2) * 1.2
            pos[f"input_{i}"] = (x, y, 0)
        # Hidden layer (z=1) - arranged in a grid or circle
        if n_hidden > 0:
            for i in range(n_hidden):
                if n_hidden <= 4:
                    x = 0
                    y = (i - n_hidden / 2) * 1.2
                else:
                    angle = 2 * math.pi * i / n_hidden
                    radius = min(3, n_hidden * 0.4)
                    x = radius * math.cos(angle)
                    y = radius * math.sin(angle)
                pos[f"hidden_{i}"] = (x, y, 1)
        # Output layer (z=2) - arranged in a line along y-axis
        for i in range(n_output):
            x = 0
            y = (i - n_output / 2) * 1.2
            pos[f"output_{i}"] = (x, y, 2)
        return pos

    def _update_highlight_state(
        self,
        current_highlight: Optional[Dict[str, Any]],
        newly_added_unit: Optional[int],
        n_hidden: int,
        selected_nodes: List[str],
        n_intervals: int,
    ) -> Optional[Dict[str, Any]]:
        """
        Update the new node highlight state machine (P2-1).

        State transitions:
        - None -> active: When a new hidden unit is detected
        - active -> fading: When user selects a different node
        - fading -> None: After 2 seconds of fade-out
        - active/fading -> active: When a new hidden unit is added (reset to new node)

        Args:
            current_highlight: Current highlight state
            newly_added_unit: Index of newly added unit (if any)
            n_hidden: Total number of hidden units
            selected_nodes: Currently selected nodes
            n_intervals: Current interval count

        Returns:
            Updated highlight state or None
        """
        # If a new hidden unit was just added, create/reset highlight to that node
        if newly_added_unit is not None and newly_added_unit < n_hidden:
            node_id = f"hidden_{newly_added_unit}"
            return {
                "node_id": node_id,
                "unit_index": newly_added_unit,
                "state": "active",
                "start_interval": n_intervals,
                "fade_start_interval": None,
            }

        # No current highlight - nothing to do
        if not current_highlight:
            return None

        highlight_node = current_highlight.get("node_id")
        state = current_highlight.get("state", "active")

        # Check if user has selected a different node (trigger for fade)
        if state == "active" and selected_nodes and highlight_node not in selected_nodes:
            # User selected a different node, start fading
            return {
                **current_highlight,
                "state": "fading",
                "fade_start_interval": n_intervals,
            }

        # If fading, check if fade duration has elapsed
        if state == "fading":
            fade_start = current_highlight.get("fade_start_interval", n_intervals)
            elapsed_intervals = n_intervals - fade_start
            elapsed_ms = elapsed_intervals * DashboardConstants.FAST_UPDATE_INTERVAL_MS
            fade_duration_ms = 2000  # 2 seconds

            if elapsed_ms >= fade_duration_ms:
                # Fade complete, clear highlight
                return None

        return current_highlight

    def _calculate_highlight_properties(self, highlight: Optional[Dict[str, Any]], n_intervals: int) -> Optional[Dict[str, Any]]:
        """
        Calculate visual properties for the new node highlight (P2-1).

        Computes pulse scale (for breathing animation) and opacity (for fade-out).

        Args:
            highlight: Current highlight state
            n_intervals: Current interval count

        Returns:
            Dict with node_id, size_scale, opacity, or None if no highlight
        """
        if not highlight:
            return None

        node_id = highlight.get("node_id")
        state = highlight.get("state", "active")
        start_interval = highlight.get("start_interval", n_intervals)

        # Calculate pulse scale (breathing effect)
        # Use a 1-second period for the pulse
        period_ms = 1000
        elapsed_ms = (n_intervals - start_interval) * DashboardConstants.FAST_UPDATE_INTERVAL_MS
        phase = 2 * math.pi * ((elapsed_ms % period_ms) / period_ms)
        size_scale = 1.0 + 0.12 * math.sin(phase)  # Oscillate between 0.88 and 1.12

        # Calculate opacity
        if state == "active":
            opacity = 1.0
        else:  # fading
            fade_start = highlight.get("fade_start_interval", n_intervals)
            fade_elapsed_ms = (n_intervals - fade_start) * DashboardConstants.FAST_UPDATE_INTERVAL_MS
            fade_duration_ms = 2000
            t = min(1.0, max(0.0, fade_elapsed_ms / fade_duration_ms))
            opacity = 1.0 - t

        return {
            "node_id": node_id,
            "size_scale": size_scale,
            "opacity": opacity,
        }

    def _create_new_node_highlight_traces(
        self,
        G: "nx.DiGraph",
        pos: Dict[str, Tuple[float, float]],
        highlight_props: Dict[str, Any],
    ) -> List[go.Scatter]:
        """
        Create highlight traces for the newly added node (P2-1).

        Creates:
        - Pulsing glow effect on the node (cyan/teal color)
        - Highlighted edges connected to the node (more muted)

        Args:
            G: NetworkX graph with edges
            pos: Node positions
            highlight_props: Dict with node_id, size_scale, opacity

        Returns:
            List of Scatter traces for the highlight
        """
        traces = []
        node_id = highlight_props.get("node_id")
        size_scale = highlight_props.get("size_scale", 1.0)
        opacity = highlight_props.get("opacity", 1.0)

        if not node_id or node_id not in pos:
            return traces

        x, y = pos[node_id]

        # Edge highlights (draw first, behind node)
        edge_opacity = 0.5 * opacity  # More muted than node
        # CLN-CN-12: previously iterated ``G.edges(data=True)`` so that a
        # per-edge ``self.log_verbose(f"Edge Data: {data}")`` developer-trace
        # could log every edge dict. That call was an attribute error
        # (``log_verbose`` does not exist on this class; the correct API is
        # ``self.logger.verbose(...)``) and was commented out with a TODO
        # during the b47d55a refactor. Removed entirely because (a) the
        # commented form was dead code, (b) re-enabling per-edge per-frame
        # verbose logging from a visualizer hot path is the wrong
        # ergonomics, and (c) the edge ``data`` dict is not used here —
        # only the endpoint node IDs matter for hit-testing.
        for from_node, to_node in G.edges():
            if (from_node == node_id or to_node == node_id) and from_node in pos and to_node in pos:
                x0, y0 = pos[from_node]
                x1, y1 = pos[to_node]
                traces.append(
                    go.Scatter(
                        x=[x0, x1, None],
                        y=[y0, y1, None],
                        mode="lines",
                        line={
                            "width": 6,
                            "color": f"rgba(23, 162, 184, {edge_opacity})",
                        },
                        hoverinfo="skip",
                        showlegend=False,
                        name="New Unit Edges",
                    )
                )

        # Node glow effect (outer glow)
        base_glow_size = 38
        glow_size = base_glow_size * size_scale
        traces.append(
            go.Scatter(
                x=[x],
                y=[y],
                mode="markers",
                marker={
                    "size": glow_size,
                    "color": f"rgba(23, 162, 184, {0.3 * opacity})",  # Soft cyan glow
                    "line": {"width": 0},
                },
                hoverinfo="skip",
                showlegend=False,
                name="New Unit Glow",
            )
        )

        # Node highlight (inner ring)
        base_ring_size = 30
        ring_size = base_ring_size * size_scale
        traces.append(
            go.Scatter(
                x=[x],
                y=[y],
                mode="markers",
                marker={
                    "size": ring_size,
                    "color": f"rgba(23, 162, 184, {0.9 * opacity})",  # Cyan
                    "line": {"width": 4, "color": f"rgba(255, 255, 255, {opacity})"},
                },
                hoverinfo="skip",
                showlegend=False,
                name="New Unit Highlight",
            )
        )

        return traces

    def update_topology(self, topology: Dict[str, Any]):
        """
        Update the network topology.

        Args:
            topology: New topology dictionary
        """
        self.current_topology = topology
        self.logger.debug(f"Topology updated: {topology.get('hidden_units', 0)} hidden units")

    def get_topology(self) -> Dict[str, Any]:
        """
        Get current network topology.

        Returns:
            Topology dictionary
        """
        return self.current_topology.copy()
