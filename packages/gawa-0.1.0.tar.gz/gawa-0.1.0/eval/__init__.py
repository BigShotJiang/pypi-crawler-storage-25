"""Evaluation utilities for GAWA."""
