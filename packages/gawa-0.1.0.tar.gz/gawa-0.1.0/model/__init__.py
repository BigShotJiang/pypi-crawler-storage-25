"""Model package for GAWA."""
