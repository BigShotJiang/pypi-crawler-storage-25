"""Data utilities for GAWA."""
