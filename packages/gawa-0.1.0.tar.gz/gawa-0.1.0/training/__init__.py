"""Training package for GAWA."""
