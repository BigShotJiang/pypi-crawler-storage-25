"""Funky sub-agent client.

Mirrors the /sub-agents/* endpoints exposed by the Funky API. A
``SubAgent`` represents one workspace and a single session within it::

    from funky import Funky

    client = Funky()
    agent = client.create_subagent(model="claude-opus-4-7")
    try:
        messages = agent.send_message("hello")
        print(messages[-1].text)
    finally:
        agent.terminate()
"""

from __future__ import annotations

import asyncio
import os
import time
from collections.abc import Callable, Generator
from dataclasses import dataclass
from typing import Any
from urllib.parse import quote, urlencode

from ._http import (
    delete_and_parse_json,
    get_and_parse_json,
    post_and_parse_json,
    post_stream_sse,
)
from .constants import DEFAULT_BASE_URL, DEFAULT_STREAM_TIMEOUT_SECONDS, DEFAULT_TIMEOUT_SECONDS
from .errors import APIError

DEFAULT_POLL_INTERVAL_SECONDS = 2.0
DEFAULT_READY_TIMEOUT_SECONDS = 300.0
DEFAULT_OPERATION_RETRY_TIMEOUT_SECONDS = 20.0


@dataclass(frozen=True, slots=True)
class SessionSummary:
    id: str
    model: str
    created_at: int
    updated_at: int
    message_count: int
    first_message: str


@dataclass(frozen=True, slots=True)
class LastMessage:
    role: str
    text: str
    timestamp: int


@dataclass(frozen=True, slots=True)
class SessionAnalysis:
    id: str
    total_tokens: int
    total_cost: float
    last_message: LastMessage | None


@dataclass(frozen=True, slots=True)
class ModelAndSystemPrompt:
    model: str
    system_prompt: str | None
    updated_live_sessions: int | None = None


@dataclass(frozen=True, slots=True)
class SubAgentMessage:
    role: str
    text: str
    raw: dict[str, Any]


def _extract_message_text(message: dict[str, Any]) -> str:
    content = message.get("content")
    if isinstance(content, str):
        return content
    if not isinstance(content, list):
        return ""
    chunks: list[str] = []
    for item in content:
        if isinstance(item, str):
            chunks.append(item)
        elif isinstance(item, dict):
            text = item.get("text")
            if isinstance(text, str):
                chunks.append(text)
    return "".join(chunks)


def _parse_subagent_message(message: Any) -> SubAgentMessage | None:
    if not isinstance(message, dict):
        return None
    role = message.get("role")
    if not isinstance(role, str):
        return None
    return SubAgentMessage(role=role, text=_extract_message_text(message), raw=message)


def _stream_error_message(data: Any) -> str:
    if isinstance(data, dict):
        error = data.get("error")
        if isinstance(error, str):
            return error
    return "Sub-agent stream returned an error"


def _parse_model_and_system_prompt(response: Any) -> ModelAndSystemPrompt:
    if not isinstance(response, dict) or not isinstance(response.get("model"), str):
        raise APIError(
            status_code=200,
            message="Unexpected response format: expected object with model",
            details=response,
        )
    system_prompt = response.get("systemPrompt", response.get("system_prompt"))
    if system_prompt is not None and not isinstance(system_prompt, str):
        raise APIError(
            status_code=200,
            message="Unexpected response format: expected system prompt string",
            details=response,
        )
    updated_raw = response.get("updatedLiveSessions", response.get("updated_live_sessions"))
    updated_live_sessions = int(updated_raw) if updated_raw is not None else None
    return ModelAndSystemPrompt(
        model=response["model"],
        system_prompt=system_prompt,
        updated_live_sessions=updated_live_sessions,
    )


def _is_retryable_operation_error(exc: APIError) -> bool:
    message = str(exc).lower()
    transient_fragments = (
        "gateway",
        "sandbox",
        "timed out",
        "timeout",
        "network error",
        "connection",
        "temporarily unavailable",
    )
    return (
        exc.status_code == 0
        or exc.status_code >= 500
        or any(fragment in message for fragment in transient_fragments)
    )


def _retry_operation_until_deadline(
    operation: Callable[[], Any],
    *,
    retry_timeout: float,
    poll_interval: float,
) -> Any:
    deadline = time.monotonic() + retry_timeout
    while True:
        try:
            return operation()
        except APIError as exc:
            if not _is_retryable_operation_error(exc) or time.monotonic() >= deadline:
                raise
            time.sleep(poll_interval)


class SubAgent:
    """Client for one sub-agent: a workspace plus a single session within it."""

    def __init__(
        self,
        *,
        name: str,
        model: str,
        system_prompt: str,
        claim_name: str,
        namespace: str,
        pod_name: str,
        session_id: str = "",
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT_SECONDS,
        stream_timeout: float = DEFAULT_STREAM_TIMEOUT_SECONDS,
        api_key: str | None = None,
    ) -> None:
        self.name = name
        self.model = model
        self.system_prompt = system_prompt
        self.claim_name = claim_name
        self.namespace = namespace
        self.pod_name = pod_name
        self.session_id = session_id
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._stream_timeout = stream_timeout
        self._api_key = api_key

    # ── Lifecycle ───────────────────────────────────────────────────────

    @classmethod
    def create(
        cls,
        *,
        model: str,
        name: str = "subagent",
        system_prompt: str = "",
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT_SECONDS,
        stream_timeout: float = DEFAULT_STREAM_TIMEOUT_SECONDS,
        api_key: str | None = None,
        poll_interval: float = DEFAULT_POLL_INTERVAL_SECONDS,
        ready_timeout: float = DEFAULT_READY_TIMEOUT_SECONDS,
        operation_retry_timeout: float = DEFAULT_OPERATION_RETRY_TIMEOUT_SECONDS,
    ) -> "SubAgent":
        """Create a sub-agent workspace, configure it, and start one session."""
        normalized_url = base_url.rstrip("/")

        create_response = post_and_parse_json(
            url=f"{normalized_url}/sub-agents/workspaces",
            timeout=timeout,
            api_key=api_key,
        )
        if not isinstance(create_response, dict) or not isinstance(
            create_response.get("claim_name"), str
        ):
            raise APIError(
                status_code=200,
                message="Unexpected response format: expected object with claim_name",
                details=create_response,
            )
        claim_name: str = create_response["claim_name"]
        namespace: str = create_response.get("namespace", "")

        pod_name = cls._wait_until_running(
            base_url=normalized_url,
            claim_name=claim_name,
            namespace=namespace,
            timeout=timeout,
            poll_interval=poll_interval,
            ready_timeout=ready_timeout,
            api_key=api_key,
        )

        agent = cls(
            name=name,
            model=model,
            system_prompt=system_prompt,
            claim_name=claim_name,
            namespace=namespace,
            pod_name=pod_name,
            base_url=base_url,
            timeout=timeout,
            stream_timeout=stream_timeout,
            api_key=api_key,
        )

        # The API requires `systemPrompt` to be a non-empty string; send a
        # single space when the caller did not provide one of their own.
        prompt_to_send = system_prompt or " "
        _retry_operation_until_deadline(
            lambda: agent.set_model_and_system_prompt(model=model, system_prompt=prompt_to_send),
            retry_timeout=operation_retry_timeout,
            poll_interval=poll_interval,
        )

        session = _retry_operation_until_deadline(
            agent._create_session,
            retry_timeout=operation_retry_timeout,
            poll_interval=poll_interval,
        )
        agent.session_id = session["session_id"]
        if isinstance(session.get("model"), str):
            agent.model = session["model"]
        return agent

    @staticmethod
    def _wait_until_running(
        *,
        base_url: str,
        claim_name: str,
        namespace: str,
        timeout: float,
        poll_interval: float,
        ready_timeout: float,
        api_key: str | None,
    ) -> str:
        deadline = time.monotonic() + ready_timeout
        status_payload: Any = None
        while True:
            status_payload = get_and_parse_json(
                url=(
                    f"{base_url}/sub-agents/workspaces/{quote(claim_name, safe='')}/status"
                    f"?{urlencode({'namespace': namespace})}"
                ),
                timeout=timeout,
                api_key=api_key,
            )
            if isinstance(status_payload, dict):
                phase = status_payload.get("status")
                candidate_pod = status_payload.get("pod_name")
                if phase == "Running" and isinstance(candidate_pod, str) and candidate_pod:
                    return candidate_pod
                if phase == "Failed":
                    raise APIError(
                        status_code=500,
                        message="Sub-agent workspace failed to start",
                        details=status_payload,
                    )
            if time.monotonic() > deadline:
                raise APIError(
                    status_code=0,
                    message=(
                        f"Sub-agent workspace did not become ready within {ready_timeout:.1f}s"
                    ),
                    details=status_payload,
                )
            time.sleep(poll_interval)

    # ── URL helpers ─────────────────────────────────────────────────────

    def _workspace_url(self, suffix: str = "") -> str:
        path = f"{self._base_url}/sub-agents/workspaces/{quote(self.claim_name, safe='')}"
        return f"{path}{suffix}" if suffix else path

    def _qs(self) -> str:
        return urlencode({"namespace": self.namespace, "pod_name": self.pod_name})

    # ── Workspace endpoints ─────────────────────────────────────────────

    def get_status(self) -> dict:
        """Return current workspace Pod phase and pod_name."""
        return get_and_parse_json(
            url=f"{self._workspace_url('/status')}?{urlencode({'namespace': self.namespace})}",
            timeout=self._timeout,
            api_key=self._api_key,
        )

    def get_model_and_system_prompt(self) -> ModelAndSystemPrompt:
        """Return the workspace-global model and appended system prompt."""
        response = get_and_parse_json(
            url=f"{self._workspace_url('/model_and_system_prompt')}?{self._qs()}",
            timeout=self._timeout,
            api_key=self._api_key,
        )
        return _parse_model_and_system_prompt(response)

    def set_model_and_system_prompt(
        self,
        *,
        model: str,
        system_prompt: str,
    ) -> ModelAndSystemPrompt:
        """Set the workspace-global model and extra system prompt for new sessions."""
        response = post_and_parse_json(
            url=f"{self._workspace_url('/set_model_and_system_prompt')}?{self._qs()}",
            body={"model": model, "systemPrompt": system_prompt},
            timeout=self._timeout,
            api_key=self._api_key,
        )
        return _parse_model_and_system_prompt(response)

    # ── Sessions ────────────────────────────────────────────────────────

    def _create_session(self) -> dict[str, Any]:
        response = post_and_parse_json(
            url=f"{self._workspace_url('/sessions')}?{self._qs()}",
            timeout=self._timeout,
            api_key=self._api_key,
        )
        if not isinstance(response, dict) or not isinstance(response.get("sessionId"), str):
            raise APIError(
                status_code=200,
                message="Unexpected response format: expected object with sessionId",
                details=response,
            )
        return {"session_id": response["sessionId"], "model": response.get("model")}

    def list_sessions(self) -> list[SessionSummary]:
        """List all sessions in this workspace's pod."""
        response = get_and_parse_json(
            url=f"{self._workspace_url('/sessions')}?{self._qs()}",
            timeout=self._timeout,
            api_key=self._api_key,
        )
        if not isinstance(response, dict) or not isinstance(response.get("sessions"), list):
            raise APIError(
                status_code=200,
                message="Unexpected response format: expected object with sessions array",
                details=response,
            )
        return [
            SessionSummary(
                id=item["id"],
                model=item.get("model", "unknown"),
                created_at=int(item.get("createdAt", 0)),
                updated_at=int(item.get("updatedAt", 0)),
                message_count=int(item.get("messageCount", 0)),
                first_message=item.get("firstMessage", ""),
            )
            for item in response["sessions"]
            if isinstance(item, dict) and isinstance(item.get("id"), str)
        ]

    def get_session(self) -> dict[str, Any]:
        """Return the raw session payload from the API."""
        return get_and_parse_json(
            url=(
                f"{self._workspace_url('/sessions')}/{quote(self.session_id, safe='')}"
                f"?{self._qs()}"
            ),
            timeout=self._timeout,
            api_key=self._api_key,
        )

    def get_session_analysis(self) -> SessionAnalysis:
        """Return aggregated totals and the last message for this sub-agent session."""
        response = get_and_parse_json(
            url=(
                f"{self._workspace_url('/sessions')}/{quote(self.session_id, safe='')}/analysis"
                f"?{self._qs()}"
            ),
            timeout=self._timeout,
            api_key=self._api_key,
        )
        if not isinstance(response, dict) or not isinstance(response.get("id"), str):
            raise APIError(
                status_code=200,
                message="Unexpected response format: expected analysis object",
                details=response,
            )
        last_raw = response.get("lastMessage")
        last_message: LastMessage | None = None
        if isinstance(last_raw, dict):
            last_message = LastMessage(
                role=last_raw.get("role", "unknown"),
                text=last_raw.get("text", ""),
                timestamp=int(last_raw.get("timestamp", 0)),
            )
        return SessionAnalysis(
            id=response["id"],
            total_tokens=int(response.get("totalTokens", 0)),
            total_cost=float(response.get("totalCost", 0.0)),
            last_message=last_message,
        )

    # ── Messages ────────────────────────────────────────────────────────

    def stream_message(
        self,
        text: str,
        *,
        timeout: float | None = None,
        stream_timeout: float | None = None,
    ) -> Generator[tuple[str, Any], None, None]:
        """Send a user message and yield (event_type, data) tuples from the SSE stream.

        *timeout* bounds the connect / initial-response phase; *stream_timeout*
        bounds inter-event idle time once the stream is open. Both fall back
        to the values configured on the SubAgent if omitted.

        Event types include: agent_start, turn_start, message_start, message_update,
        message_end, tool_execution_start, tool_execution_update, tool_execution_end,
        turn_end, agent_end, error.
        """
        yield from post_stream_sse(
            url=(
                f"{self._workspace_url('/sessions')}/{quote(self.session_id, safe='')}/messages"
                f"?{self._qs()}"
            ),
            body={"text": text},
            timeout=timeout if timeout is not None else self._timeout,
            stream_timeout=(
                stream_timeout if stream_timeout is not None else self._stream_timeout
            ),
            api_key=self._api_key,
        )

    def send_message(
        self,
        text: str,
        *,
        timeout: float | None = None,
        stream_timeout: float | None = None,
    ) -> list[SubAgentMessage]:
        """Send a user message and return all completed assistant messages."""
        messages: list[SubAgentMessage] = []
        for event_type, data in self.stream_message(
            text, timeout=timeout, stream_timeout=stream_timeout
        ):
            if event_type == "error":
                raise APIError(
                    status_code=0,
                    message=_stream_error_message(data),
                    details=data,
                )
            if event_type == "message_end" and isinstance(data, dict):
                message = _parse_subagent_message(data.get("message"))
                if message is not None and message.role == "assistant":
                    messages.append(message)
            elif event_type == "agent_end" and not messages and isinstance(data, dict):
                raw_messages = data.get("messages")
                if isinstance(raw_messages, list):
                    for raw_message in raw_messages:
                        message = _parse_subagent_message(raw_message)
                        if message is not None and message.role == "assistant":
                            messages.append(message)
        return messages

    # ── Termination ─────────────────────────────────────────────────────

    def terminate(self) -> dict:
        """Synchronously delete this sub-agent's underlying workspace."""
        response = delete_and_parse_json(
            url=f"{self._workspace_url()}?{urlencode({'namespace': self.namespace})}",
            timeout=self._timeout,
            api_key=self._api_key,
        )
        if isinstance(response, dict) and response.get("deleted"):
            return response
        raise APIError(
            status_code=200,
            message='Unexpected response format: expected {"deleted": true}',
            details=response,
        )

    async def delete(self) -> dict:
        """Async wrapper for terminate()."""
        return await asyncio.to_thread(self.terminate)


class Funky:
    """Top-level Funky SDK client."""

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT_SECONDS,
        stream_timeout: float = DEFAULT_STREAM_TIMEOUT_SECONDS,
    ) -> None:
        self._api_key = api_key if api_key is not None else os.environ.get("FUNKY_API_KEY")
        self._base_url = base_url
        self._timeout = timeout
        self._stream_timeout = stream_timeout

    def create_subagent(
        self,
        *,
        model: str,
        system_prompt: str = "",
        name: str = "subagent",
        poll_interval: float = DEFAULT_POLL_INTERVAL_SECONDS,
        ready_timeout: float = DEFAULT_READY_TIMEOUT_SECONDS,
        operation_retry_timeout: float = DEFAULT_OPERATION_RETRY_TIMEOUT_SECONDS,
    ) -> SubAgent:
        """Provision a new sub-agent workspace and start a fresh session."""
        return SubAgent.create(
            name=name,
            model=model,
            system_prompt=system_prompt,
            base_url=self._base_url,
            timeout=self._timeout,
            stream_timeout=self._stream_timeout,
            api_key=self._api_key,
            poll_interval=poll_interval,
            ready_timeout=ready_timeout,
            operation_retry_timeout=operation_retry_timeout,
        )
