"""SDK constants."""

DEFAULT_BASE_URL = "https://api.funky.dev"
DEFAULT_TIMEOUT_SECONDS = 30.0

# Per-read socket timeout used for SSE streams. Long tool calls can pause
# the event flow; a short timeout would truncate the stream mid-turn.
DEFAULT_STREAM_TIMEOUT_SECONDS = 600.0
