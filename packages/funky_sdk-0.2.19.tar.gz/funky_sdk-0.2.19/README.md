# funky-sdk

Python SDK for spawning isolated Funky sub-agents.

## Install

```bash
pip install funky-sdk
```

## Getting started

```python
import os
from funky import Funky

client = Funky(
    api_key=os.environ.get("FUNKY_API_KEY"),  # This is the default and can be omitted
)

agent = client.create_subagent(model="gemini-3-flash-preview")
try:
    messages = agent.send_message("What is 2 * 2?")
    print(messages[-1].text)
finally:
    agent.terminate()
```

`create_subagent` also accepts an optional `system_prompt`:

```python
agent = client.create_subagent(
    model="gemini-3-flash-preview",
    system_prompt="You are a terse coding assistant.",
)
```

## Requirements

Python 3.10+
