from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

import pytest

import funky._http
import funky.sub_agent as sub_agent_module
from funky import APIError, Funky, SubAgent


@dataclass
class FakeResponse:
    body: bytes

    def read(self) -> bytes:
        return self.body

    def __enter__(self) -> FakeResponse:
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> bool:
        return False


@dataclass
class FakeSSEResponse:
    lines: list[bytes]

    def __iter__(self):
        return iter(self.lines)

    def close(self) -> None:
        pass


def make_sse_lines(events: list[tuple[str, dict[str, Any]]]) -> list[bytes]:
    lines: list[bytes] = []
    for event_type, data in events:
        lines.append(f"event: {event_type}\n".encode("utf-8"))
        lines.append(f"data: {json.dumps(data)}\n".encode("utf-8"))
        lines.append(b"\n")
    return lines


def message(role: str, text: str) -> dict[str, Any]:
    return {"role": role, "content": [{"type": "text", "text": text}], "timestamp": 1}


def fake_sub_agent_urlopen(captured: list[tuple[str, str, dict[str, Any] | None]]):
    def fake_urlopen(request, timeout: float, context=None):
        body = json.loads(request.data.decode("utf-8")) if request.data else None
        captured.append((request.get_method(), request.full_url, body))

        url = request.full_url
        if url.endswith("/sub-agents/workspaces") and request.get_method() == "POST":
            return FakeResponse(
                b'{"claim_name":"sa-claim-1","namespace":"sa-ns","status":"creating"}'
            )
        if "/sub-agents/workspaces/sa-claim-1/status" in url:
            return FakeResponse(b'{"status":"Running","pod_name":"sa-pod-1"}')
        if "/set_model_and_system_prompt" in url:
            return FakeResponse(
                b'{"model":"claude-opus-4-7","systemPrompt":"Be helpful","updatedLiveSessions":0}'
            )
        if url.endswith(
            "/sub-agents/workspaces/sa-claim-1/model_and_system_prompt"
            "?namespace=sa-ns&pod_name=sa-pod-1"
        ):
            return FakeResponse(b'{"model":"claude-opus-4-7","systemPrompt":"Be helpful"}')
        if "/sessions/session-1/messages" in url:
            return FakeSSEResponse(
                make_sse_lines(
                    [
                        ("message_end", {"type": "message_end", "message": message("user", "Hi")}),
                        (
                            "message_update",
                            {"type": "message_update", "message": message("assistant", "Hel")},
                        ),
                        (
                            "message_end",
                            {"type": "message_end", "message": message("assistant", "Hello")},
                        ),
                        (
                            "message_end",
                            {"type": "message_end", "message": message("assistant", "Done")},
                        ),
                        (
                            "agent_end",
                            {
                                "type": "agent_end",
                                "messages": [
                                    message("assistant", "Hello"),
                                    message("assistant", "Done"),
                                ],
                            },
                        ),
                    ]
                )
            )
        if url.endswith(
            "/sub-agents/workspaces/sa-claim-1/sessions?namespace=sa-ns&pod_name=sa-pod-1"
        ):
            return FakeResponse(b'{"sessionId":"session-1","model":"claude-opus-4-7"}')
        if "/sub-agents/workspaces/sa-claim-1/sessions/session-1?" in url:
            return FakeResponse(
                json.dumps(
                    {
                        "id": "session-1",
                        "model": "claude-opus-4-7",
                        "messages": [
                            message("user", "Hi"),
                            message("assistant", "Hello"),
                        ],
                        "isStreaming": False,
                    }
                ).encode("utf-8")
            )
        if "/sub-agents/workspaces/sa-claim-1?namespace=sa-ns" in url and request.get_method() == "DELETE":
            return FakeResponse(b'{"deleted":true}')
        return FakeResponse(b"{}")

    return fake_urlopen


def test_subagent_create_walks_the_new_endpoint_order(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured: list[tuple[str, str, dict[str, Any] | None]] = []
    monkeypatch.setattr(funky._http, "urlopen", fake_sub_agent_urlopen(captured))

    agent = SubAgent.create(
        name="Coding Assistant",
        model="claude-opus-4-7",
        system_prompt="Be helpful",
        poll_interval=0.0,
    )

    assert agent.name == "Coding Assistant"
    assert agent.model == "claude-opus-4-7"
    assert agent.system_prompt == "Be helpful"
    assert agent.session_id == "session-1"
    assert agent.claim_name == "sa-claim-1"
    assert agent.namespace == "sa-ns"
    assert agent.pod_name == "sa-pod-1"

    paths = [url.split("?", 1)[0] for _, url, _ in captured]
    assert paths == [
        "https://api.funky.dev/sub-agents/workspaces",
        "https://api.funky.dev/sub-agents/workspaces/sa-claim-1/status",
        "https://api.funky.dev/sub-agents/workspaces/sa-claim-1/set_model_and_system_prompt",
        "https://api.funky.dev/sub-agents/workspaces/sa-claim-1/sessions",
    ]
    set_request = next(item for item in captured if "/set_model_and_system_prompt" in item[1])
    assert set_request[2] == {"model": "claude-opus-4-7", "systemPrompt": "Be helpful"}


def test_subagent_create_substitutes_space_for_empty_system_prompt(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured: list[tuple[str, str, dict[str, Any] | None]] = []
    monkeypatch.setattr(funky._http, "urlopen", fake_sub_agent_urlopen(captured))

    agent = SubAgent.create(model="claude-opus-4-7", poll_interval=0.0)

    set_request = next(item for item in captured if "/set_model_and_system_prompt" in item[1])
    # API requires systemPrompt minLength 1; SDK sends a single space.
    assert set_request[2] == {"model": "claude-opus-4-7", "systemPrompt": " "}
    # User-visible attribute keeps the original empty string.
    assert agent.system_prompt == ""


def test_subagent_create_retries_transient_setup_errors(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    set_calls = {"count": 0}
    session_calls = {"count": 0}

    real_set = SubAgent.set_model_and_system_prompt
    real_create_session = SubAgent._create_session

    def flaky_set(self, *, model: str, system_prompt: str):
        set_calls["count"] += 1
        if set_calls["count"] == 1:
            raise APIError(
                status_code=500,
                message="Error communicating with pi-agent sandbox via gateway",
            )
        return real_set(self, model=model, system_prompt=system_prompt)

    def flaky_create_session(self):
        session_calls["count"] += 1
        if session_calls["count"] == 1:
            raise APIError(status_code=0, message="Network error: connection refused")
        return real_create_session(self)

    monkeypatch.setattr(SubAgent, "set_model_and_system_prompt", flaky_set)
    monkeypatch.setattr(SubAgent, "_create_session", flaky_create_session)

    captured: list[tuple[str, str, dict[str, Any] | None]] = []
    monkeypatch.setattr(funky._http, "urlopen", fake_sub_agent_urlopen(captured))

    agent = SubAgent.create(
        model="claude-opus-4-7",
        system_prompt="Be helpful",
        poll_interval=0.0,
    )

    assert set_calls["count"] == 2
    assert session_calls["count"] == 2
    assert agent.session_id == "session-1"


def test_subagent_create_does_not_retry_permanent_setup_errors(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    set_calls = {"count": 0}

    def always_unauthorized(self, *, model: str, system_prompt: str):
        set_calls["count"] += 1
        raise APIError(status_code=401, message="Unauthorized")

    monkeypatch.setattr(SubAgent, "set_model_and_system_prompt", always_unauthorized)

    captured: list[tuple[str, str, dict[str, Any] | None]] = []
    monkeypatch.setattr(funky._http, "urlopen", fake_sub_agent_urlopen(captured))

    with pytest.raises(APIError) as exc_info:
        SubAgent.create(
            model="claude-opus-4-7",
            system_prompt="Be helpful",
            poll_interval=0.0,
        )

    assert exc_info.value.status_code == 401
    assert set_calls["count"] == 1


def test_subagent_send_message_returns_completed_assistant_messages(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured: list[tuple[str, str, dict[str, Any] | None]] = []
    monkeypatch.setattr(funky._http, "urlopen", fake_sub_agent_urlopen(captured))

    agent = SubAgent.create(
        model="claude-opus-4-7",
        system_prompt="Be helpful",
        poll_interval=0.0,
    )
    messages = agent.send_message("Hi")

    assert [item.role for item in messages] == ["assistant", "assistant"]
    assert [item.text for item in messages] == ["Hello", "Done"]
    message_request = next(
        item for item in captured if "/sessions/session-1/messages" in item[1]
    )
    assert message_request[2] == {"text": "Hi"}


def test_subagent_stream_message_yields_raw_stream_events(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured: list[tuple[str, str, dict[str, Any] | None]] = []
    monkeypatch.setattr(funky._http, "urlopen", fake_sub_agent_urlopen(captured))

    agent = SubAgent.create(
        model="claude-opus-4-7",
        system_prompt="Be helpful",
        poll_interval=0.0,
    )
    events = list(agent.stream_message("Hi"))

    assert [event_type for event_type, _ in events] == [
        "message_end",
        "message_update",
        "message_end",
        "message_end",
        "agent_end",
    ]
    assert events[1][1]["message"]["content"][0]["text"] == "Hel"


def test_subagent_get_session_returns_raw_response(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured: list[tuple[str, str, dict[str, Any] | None]] = []
    monkeypatch.setattr(funky._http, "urlopen", fake_sub_agent_urlopen(captured))

    agent = SubAgent.create(
        model="claude-opus-4-7",
        system_prompt="Be helpful",
        poll_interval=0.0,
    )
    response = agent.get_session()

    assert response == {
        "id": "session-1",
        "model": "claude-opus-4-7",
        "messages": [
            message("user", "Hi"),
            message("assistant", "Hello"),
        ],
        "isStreaming": False,
    }
    get_request = next(
        item for item in captured if "/sessions/session-1?" in item[1] and item[0] == "GET"
    )
    assert "namespace=sa-ns" in get_request[1]
    assert "pod_name=sa-pod-1" in get_request[1]


def test_subagent_terminate_calls_delete_endpoint(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured: list[tuple[str, str, dict[str, Any] | None]] = []
    monkeypatch.setattr(funky._http, "urlopen", fake_sub_agent_urlopen(captured))

    agent = SubAgent.create(
        model="claude-opus-4-7",
        system_prompt="Be helpful",
        poll_interval=0.0,
    )
    result = agent.terminate()

    assert result == {"deleted": True}
    delete_requests = [item for item in captured if item[0] == "DELETE"]
    assert len(delete_requests) == 1
    assert "/sub-agents/workspaces/sa-claim-1?namespace=sa-ns" in delete_requests[0][1]


def test_funky_create_subagent_delegates_to_subagent_create(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured_kwargs: dict[str, Any] = {}

    def fake_create(**kwargs: Any) -> str:
        captured_kwargs.update(kwargs)
        return "the-agent"  # type: ignore[return-value]

    monkeypatch.setattr(SubAgent, "create", classmethod(lambda cls, **kw: fake_create(**kw)))

    client = Funky(api_key="key-123", base_url="https://example.test", timeout=42.0)
    result = client.create_subagent(model="claude-opus-4-7", system_prompt="hi", name="bot")

    assert result == "the-agent"
    assert captured_kwargs["model"] == "claude-opus-4-7"
    assert captured_kwargs["system_prompt"] == "hi"
    assert captured_kwargs["name"] == "bot"
    assert captured_kwargs["base_url"] == "https://example.test"
    assert captured_kwargs["timeout"] == 42.0
    assert captured_kwargs["api_key"] == "key-123"


def test_funky_reads_api_key_from_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("FUNKY_API_KEY", "from-env")
    client = Funky()
    assert client._api_key == "from-env"


def test_module_exports_match_public_api() -> None:
    # Sanity: nothing references the old pi_agent or workspace modules.
    assert not hasattr(sub_agent_module, "PiAgentWorkspace")
    assert not hasattr(sub_agent_module, "Subagent")


def test_iter_sse_raises_on_premature_stream_closure() -> None:
    # Stream ends with a half-delivered event (no trailing blank line). The
    # iterator should raise instead of silently returning, so callers can tell
    # the difference between a clean stream end and a truncated one.
    truncated = FakeSSEResponse(
        [
            b"event: message_end\n",
            b'data: {"type":"message_end","message":{"role":"assistant","content":[]}}\n',
            b"\n",
            b"event: agent_end\n",
            b'data: {"type":"agent_end"',  # truncated — no closing brace, no blank line
        ]
    )
    received: list[tuple[str, Any]] = []
    with pytest.raises(APIError) as exc_info:
        for event in funky._http._iter_sse(truncated):
            received.append(event)

    assert [event_type for event_type, _ in received] == ["message_end"]
    assert "premature" in str(exc_info.value).lower()


def test_iter_sse_clean_close_does_not_raise() -> None:
    clean = FakeSSEResponse(
        make_sse_lines(
            [("agent_end", {"type": "agent_end", "messages": []})]
        )
    )
    events = list(funky._http._iter_sse(clean))
    assert [event_type for event_type, _ in events] == ["agent_end"]
