import json
from pathlib import Path


def load_tree(path: str | Path, keep_extension: bool = False, default={}) -> dict:
    """
    지정된 경로 내의 디렉토리 구조와 JSON, JSON5, YAML 파일 데이터를 재귀적으로 읽어 반환합니다.

    :param path: 읽어올 최상위 디렉토리 경로
    :param keep_extension: True이면 키에 확장자를 포함(.json 등), False이면 확장자 제외 (기본값: False)
    """
    if not path:
        return default

    valid_exts = {".json", ".json5", ".yaml", ".yml"}

    def parse(item: Path):
        # 디렉토리인 경우 재귀 호출 시에도 keep_extension 설정을 넘겨줍니다.
        if item.is_dir():
            return load_tree(item, keep_extension)

        text = item.read_text(encoding="utf-8").strip()

        # 텍스트가 비어있는 경우 빈 딕셔너리를 반환합니다.
        if not text:
            return default

        match item.suffix.lower():
            case ".json":
                return json.loads(text)
            case ".json5":
                try:
                    import json5

                    return json5.loads(text)
                except ImportError:
                    raise ImportError(
                        f"'{item.name}' 읽기 실패: 'pip install json5' 필요"
                    )
            case ".yaml" | ".yml":
                try:
                    import yaml

                    return yaml.safe_load(text)
                except ImportError:
                    raise ImportError(
                        f"'{item.name}' 읽기 실패: 'pip install pyyaml' 필요"
                    )

    root = Path(path)

    return {
        # 디렉토리이거나 keep_extension이 True면 name, 아니면 stem(확장자 제외) 사용
        (item.name if item.is_dir() or keep_extension else item.stem): parse(item)
        for item in root.iterdir()
        if item.is_dir() or item.suffix.lower() in valid_exts
    }
