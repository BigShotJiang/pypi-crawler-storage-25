import inspect
import random
from typing import Any

__all__ = ["deep_get", "rand_key_chain", "get_attrs"]


def deep_get(data: Any, target_path: str, default: Any = None) -> list | Any:
    """
    중첩된 데이터 구조에서 경로와 일치하는 모든 값을 찾아 리스트로 반환합니다.

    데이터의 모든 깊이를 재귀적으로 탐색하여 'target_path'와 일치하는 구조를
    모두 수집합니다.

    Args:
        data: 검색할 딕셔너리 또는 리스트 구조.
        target_path: '/'로 구분된 검색 경로 (예: 'a/b').
        default: 검색 결과가 없을 경우 반환할 값. 기본값은 None.

    Returns:
        찾은 값들의 리스트 또는 검색 결과가 없을 경우 default 값.
    """
    path_keys = target_path.split("/")

    def _search(current):
        # 1. 현재 위치에서 경로 일치 여부 확인
        try:
            temp = current
            for key in path_keys:
                temp = temp[key]
            yield temp
        except (KeyError, TypeError, IndexError):
            pass

        # 2. 하위 요소(dict, list) 재귀 탐색
        if isinstance(current, dict):
            for value in current.values():
                yield from _search(value)
        elif isinstance(current, list):
            for item in current:
                yield from _search(item)

    results = list(_search(data))
    return results if results else default


def rand_key_chain(d: dict, depth: int = 0) -> list[Any]:
    """
    딕셔셔리에서 랜덤한 키 체인(경로)을 반환합니다

    Args:
        d: 탐색할 딕셔너리.
        depth: 탐색할 깊이. 0이면 최하위까지.

    Returns:
        랜덤하게 선택된 key들의 리스트.

    Raises:
        ValueError: 유효한 경로를 찾지 못했거나, 지정된 깊이에 도달할 수 없는 경우.
    """
    if depth < 0:
        raise ValueError("depth는 0 이상이어야 합니다.")

    chain = []
    current = d

    while True:
        # --- 루프 종료 조건 ---
        # 1. 지정된 깊이에 도달한 경우
        if depth and len(chain) == depth:
            break
        # 2. 더 이상 탐색할 수 없는 경우 (딕셔너리가 아니거나 비어있음)
        if not isinstance(current, dict) or not current:
            break

        # --- 핵심 로직: 키 선택 및 다음 단계로 이동 ---
        key = random.choice(list(current.keys()))
        chain.append(key)
        current = current[key]

    # --- 최종 결과 검증 ---
    # depth가 지정되었는데, 그 깊이에 도달하지 못하고 루프가 끝난 경우
    if depth and len(chain) < depth:
        raise ValueError(
            f"지정한 깊이({depth})까지 탐색할 수 없습니다. (실패 지점: 깊이 {len(chain) + 1})"
        )

    # 경로가 전혀 만들어지지 않은 경우 (예: 입력 딕셔너리가 비어있음)
    if not chain:
        raise ValueError(
            "유효한 경로를 찾을 수 없습니다 (입력 딕셔너리가 비어있을 수 있습니다)."
        )

    return chain


def get_attrs(obj: Any, instance_vars: bool = True) -> dict[str, Any]:
    """
    클래스 또는 인스턴스에서 '_'로 시작하지 않는 속성을 필터링하여 반환합니다.

    :param obj: 속성을 가져올 클래스 또는 인스턴스 객체.
    :param instance_vars: True일 경우 인스턴스 변수도 포함합니다. obj가 클래스일 경우 이 값은 무시됩니다.

    :returns: 필터링된 속성 딕셔너리.
    """
    # 1. 대상이 클래스인지 인스턴스인지 확인하여 기준 클래스를 정합니다.
    cls = obj if inspect.isclass(obj) else type(obj)

    # 2. 클래스의 public 속성을 가져옵니다.
    class_attributes = {k: v for k, v in vars(cls).items() if not k.startswith("_")}

    # 3. 인스턴스 변수를 포함해야 하는 경우, 인스턴스의 public 속성을 가져와 합칩니다.
    if instance_vars and not inspect.isclass(obj):
        instance_attributes = {
            k: v for k, v in vars(obj).items() if not k.startswith("_")
        }
        # 클래스 속성 위에 인스턴스 속성을 덮어씁니다 (Python의 기본 동작과 동일).
        return {**class_attributes, **instance_attributes}

    # 4. 클래스 변수만 반환하는 경우
    return class_attributes
