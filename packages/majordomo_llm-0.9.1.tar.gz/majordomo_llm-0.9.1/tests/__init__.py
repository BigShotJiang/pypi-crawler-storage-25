"""Tests for majordomo-llm."""
