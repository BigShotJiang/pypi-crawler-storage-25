# kelviq_sdk/models/__init__.py
"""
Pydantic Models for the Kelviq SDK.

This package contains Pydantic models used for data validation,
serialization, and deserialization for API requests and responses.
"""

# Import models from submodules to make them accessible
# directly from kelviq_sdk.models
# e.g., from kelviq_sdk.models import ReportUsagePayload

from .reporting import (
    BaseResponse,
    ReportUsagePayload,
    ReportUsageResponse,
    ReportEventPayload,
    ReportEventResponse,
)

from .entitlements import (
    EntitlementDetail,
    Entitlement,
    CheckEntitlementsResponse,
)

from .portal import (
    CreatePortalSessionPayload,
    CreatePortalSessionResponse,
)

__all__ = [
    "BaseResponse",
    "ReportUsagePayload",
    "ReportUsageResponse",
    "ReportEventPayload",
    "ReportEventResponse",
    "EntitlementDetail",
    "Entitlement",
    "CheckEntitlementsResponse",
    "CreatePortalSessionPayload",
    "CreatePortalSessionResponse",
]
