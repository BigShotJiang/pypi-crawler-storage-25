#
#       pyvistaqml
#       Unit tests for possible memory leaks in Fbo.
#
#       Copyright © 2026 Inria
#       Author(s): Manuel Petit <manuel.petit@inria.fr>
#
#       This file is part of pyvistaqml.
#
#       pyvistaqml is free software: you can redistribute it and/or modify
#       it under the terms of the GNU Lesser General Public License as published by
#       the Free Software Foundation, either version 3 of the License, or
#       (at your option) any later version.
#
#       pyvistaqml is distributed in the hope that it will be useful,
#       but WITHOUT ANY WARRANTY; without even the implied warranty of
#       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#       GNU Lesser General Public License for more details.
#
#       You should have received a copy of the GNU Lesser General Public License
#       along with pyvistaqml.  If not, see <https://www.gnu.org/licenses/>.
#
# -----------------------------------------------------------------------

import gc
import weakref
import os
import tempfile
import pytest
import shiboken6

from PySide6.QtQuick import QQuickView
from PySide6.QtQml import qmlRegisterType
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QUrl, QObject

from pyvistaqml.core.fbo import Fbo
from pyvistaqml.utils.funcs import setup_opengl_format

# Force OpenGL backend for testing
os.environ["QSG_RHI_BACKEND"] = "opengl"
setup_opengl_format()


class TestFboMemoryLeaks:
    @classmethod
    def setup_class(cls):
        """Ensure QApplication and QML types are registered."""
        if not QApplication.instance():
            cls._app = QApplication([])
        else:
            cls._app = QApplication.instance()

        try:
            qmlRegisterType(Fbo, "pyvistaqml.core", 1, 0, "Fbo")
        except Exception:
            pass

    def test_fbo_circular_reference_resolved(self, qtbot):
        """
        Tests if the Fbo properly releases its memory and cycle when the QML View is destroyed.
        """
        view = QQuickView()
        qml_content = """
        import QtQuick
        import pyvistaqml.core 1.0
        Item { width: 400; height: 400; Fbo { id: fbo; objectName: "fbo"; anchors.fill: parent } }
        """
        temp_qml = tempfile.NamedTemporaryFile(suffix=".qml", mode="w", delete=False)
        temp_qml.write(qml_content)
        temp_qml.close()

        view.setSource(QUrl.fromLocalFile(temp_qml.name))
        view.show()

        # Capture reference using weakref only
        fbo_weak = None

        def capture(v=view):
            nonlocal fbo_weak
            item = v.rootObject().findChild(QObject, "fbo")
            if item and getattr(item, "_fboRenderer", None):
                fbo_weak = weakref.ref(item)
                return True
            return False

        qtbot.waitUntil(capture, timeout=5000)
        view.setSource(QUrl())  # Unload the QML

        view.close()
        view.deleteLater()
        del view

        # Let Qt's Event Loop safely schedule the C++ deletions
        for _ in range(20):
            QApplication.instance().processEvents()

        # Clear Python's cycle collector
        for _ in range(3):
            gc.collect()

        leaked_fbo = fbo_weak()
        if leaked_fbo is not None:
            if shiboken6.isValid(leaked_fbo):
                pytest.fail("C++ Fbo object is still alive in memory!")

        assert True

        os.unlink(temp_qml.name)
