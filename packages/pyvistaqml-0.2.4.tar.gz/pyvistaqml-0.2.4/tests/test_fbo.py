#
#       pyvistaqml
#       Unit tests for Fbo.
#
#       Copyright © 2026 Inria
#       Author(s): Manuel Petit <manuel.petit@inria.fr>
#
#       This file is part of pyvistaqml.
#
#       pyvistaqml is free software: you can redistribute it and/or modify
#       it under the terms of the GNU Lesser General Public License as published by
#       the Free Software Foundation, either version 3 of the License, or
#       (at your option) any later version.
#
#       pyvistaqml is distributed in the hope that it will be useful,
#       but WITHOUT ANY WARRANTY; without even the implied warranty of
#       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#       GNU Lesser General Public License for more details.
#
#       You should have received a copy of the GNU Lesser General Public License
#       along with pyvistaqml.  If not, see <https://www.gnu.org/licenses/>.
#
# -----------------------------------------------------------------------

import unittest
import pytest
import os
import tempfile
import vtk

from PySide6.QtQuick import QQuickView
from PySide6.QtQml import qmlRegisterType
from PySide6.QtWidgets import QApplication
from PySide6.QtGui import (
    QMouseEvent,
    QWheelEvent,
    QHoverEvent,
    QKeyEvent,
)
from PySide6.QtCore import Qt, QPointF, QPoint, QEvent, QUrl

from pyvistaqml.core.fbo import Fbo
from pyvistaqml.utils.funcs import setup_opengl_format

# Force OpenGL backend for testing
os.environ["QSG_RHI_BACKEND"] = "opengl"

# Setup OpenGL Format
setup_opengl_format()


class TestFboStandalone(unittest.TestCase):
    view = None
    temp_qml = None
    fbo = None

    @pytest.fixture(autouse=True)
    def setup_qtbot(self, qtbot):
        self.qtbot = qtbot

    @classmethod
    def setUpClass(cls):
        """Register type once and start the App."""
        if not QApplication.instance():
            cls._app = QApplication([])
        else:
            cls._app = QApplication.instance()

        try:
            qmlRegisterType(Fbo, "pyvistaqml.core", 1, 0, "Fbo")
        except Exception:
            pass

    def setUp(self):
        """Load the FBO into a real QQuickView to trigger the Render Thread."""
        if TestFboStandalone.view is None:
            TestFboStandalone.view = QQuickView()

            qml_content = """
                import QtQuick
                import pyvistaqml.core 1.0
                Item {
                    width: 400; height: 400
                    Fbo {
                        objectName: "fbo"
                        anchors.fill: parent
                    }
                }
                """
            TestFboStandalone.temp_qml = tempfile.NamedTemporaryFile(
                suffix=".qml", mode="w", delete=False
            )
            TestFboStandalone.temp_qml.write(qml_content)
            TestFboStandalone.temp_qml.close()

            TestFboStandalone.view.setSource(
                QUrl.fromLocalFile(TestFboStandalone.temp_qml.name)
            )
            TestFboStandalone.view.show()

            root = TestFboStandalone.view.rootObject()
            TestFboStandalone.fbo = root.findChild(Fbo, "fbo")

        self.fbo = TestFboStandalone.fbo
        self.qtbot.waitUntil(lambda: self.fbo._fboRenderer is not None, timeout=5000)
        self.fbo_renderer = self.fbo._fboRenderer

    @classmethod
    def tearDownClass(cls):
        """Cleanly tears down the heavy Qt/VTK objects once."""
        if cls.view:
            cls.view.setSource(QUrl())
            cls.view.close()
            cls.view.deleteLater()
        cls.view = None

        if QApplication.instance():
            QApplication.instance().processEvents()

        if cls.temp_qml and os.path.exists(cls.temp_qml.name):
            os.unlink(cls.temp_qml.name)

    def test_fbo_initialization(self):
        """Covers Fbo.__init__ and default states."""
        self.assertIsNotNone(self.fbo_renderer)
        self.assertTrue(self.fbo._interaction_enabled)
        self.assertEqual(self.fbo.focusPolicy(), Qt.StrongFocus)

    def test_vtk_setup_proxies(self):
        """Covers addRenderer, setInteractorStyle, and initRWI natively."""
        ren = vtk.vtkRenderer()
        style = vtk.vtkInteractorStyleTrackballCamera()

        self.fbo.addRenderer(ren)
        self.fbo.setInteractorStyle(style)
        self.fbo.initRWI()

        self.assertIn(ren, self.fbo_renderer.rw.GetRenderers())
        self.assertEqual(self.fbo_renderer.rwi.GetInteractorStyle(), style)

    def test_command_queue(self):
        """Covers addCommand and its thread-safe execution in the render loop."""
        cmd_called = False

        def my_cmd():
            nonlocal cmd_called
            cmd_called = True

        self.fbo.addCommand(my_cmd)
        self.qtbot.waitUntil(lambda: cmd_called, timeout=2000)

        self.assertTrue(cmd_called)
        self.assertTrue(self.fbo.commandQueue.empty())

    def test_mouse_events(self):
        """Covers all mouse button types and double clicks."""
        buttons = [Qt.LeftButton, Qt.RightButton, Qt.MiddleButton]
        types = [
            QEvent.Type.MouseButtonPress,
            QEvent.Type.MouseButtonRelease,
            QEvent.Type.MouseButtonDblClick,
        ]

        for btn in buttons:
            for t in types:
                evt = QMouseEvent(
                    t, QPointF(10, 10), QPointF(10, 10), btn, btn, Qt.NoModifier
                )
                if (
                    t == QEvent.Type.MouseButtonPress
                    or t == QEvent.Type.MouseButtonDblClick
                ):
                    self.fbo.mousePressEvent(evt)
                elif t == QEvent.Type.MouseButtonRelease:
                    self.fbo.mouseReleaseEvent(evt)

        # Move mouse with modifiers
        move_evt = QMouseEvent(
            QEvent.Type.MouseMove,
            QPointF(20, 20),
            QPointF(20, 20),
            Qt.NoButton,
            Qt.LeftButton,
            Qt.ControlModifier | Qt.ShiftModifier,
        )
        self.fbo.mouseMoveEvent(move_evt)

        self.qtbot.waitUntil(lambda: len(self.fbo_renderer._eventsToProcess) == 0, timeout=2000)
        self.assertEqual(len(self.fbo_renderer._eventsToProcess), 0)

    def test_wheel_events(self):
        """Covers forward and backward wheel motion."""
        fwd = QWheelEvent(
            QPointF(10, 10),
            QPointF(10, 10),
            QPoint(0, 120),
            QPoint(0, 120),
            Qt.NoButton,
            Qt.NoModifier,
            Qt.ScrollPhase.NoScrollPhase,
            False,
        )
        self.fbo.wheelEvent(fwd)

        back = QWheelEvent(
            QPointF(10, 10),
            QPointF(10, 10),
            QPoint(0, -120),
            QPoint(0, -120),
            Qt.NoButton,
            Qt.NoModifier,
            Qt.ScrollPhase.NoScrollPhase,
            False,
        )
        self.fbo.wheelEvent(back)

        self.qtbot.waitUntil(lambda: len(self.fbo_renderer._eventsToProcess) == 0, timeout=2000)
        self.assertEqual(len(self.fbo_renderer._eventsToProcess), 0)
        self.qtbot.wait(100) # to make sure the events are processed

    def test_fbo_renderer_early_exits(self):
        """Covers early exits in synchronize and render when rw is missing."""
        old_rw = self.fbo_renderer.rw
        del self.fbo_renderer.rw
        try:
            self.fbo_renderer.synchronize(self.fbo)
            self.fbo_renderer.render()
        finally:
            self.fbo_renderer.rw = old_rw

        self.fbo_renderer._fbo_ref = None
        self.fbo_renderer.synchronize(self.fbo)
        self.fbo_renderer.render()

    def test_keyboard_events_and_mapping(self):
        """Covers key press/release and 100% of the vtk keysym mapping branches."""
        special_keys = [
            Qt.Key_Space,
            Qt.Key_Return,
            Qt.Key_Escape,
            Qt.Key_Up,
            Qt.Key_Down,
            Qt.Key_Left,
            Qt.Key_Right,
        ]

        for k in special_keys:
            press = QKeyEvent(QEvent.Type.KeyPress, k, Qt.NoModifier)
            self.fbo.keyPressEvent(press)

        char_press = QKeyEvent(QEvent.Type.KeyPress, Qt.Key_P, Qt.NoModifier, "p")
        self.fbo.keyPressEvent(char_press)

        release = QKeyEvent(QEvent.Type.KeyRelease, Qt.Key_P, Qt.NoModifier, "p")
        self.fbo.keyReleaseEvent(release)

        self.qtbot.waitUntil(lambda: len(self.fbo_renderer._eventsToProcess) == 0, timeout=2000)
        self.assertEqual(len(self.fbo_renderer._eventsToProcess), 0)

    def test_resize_and_pixel_ratio(self):
        """Covers synchronization resize logic and the SetViewport loop."""
        ren = vtk.vtkRenderer()
        ren.SetViewport(0, 0, 0.5, 0.5)
        self.fbo.addRenderer(ren)

        new_dim = 600
        root = self.view.rootObject()
        root.setProperty("width", new_dim)
        root.setProperty("height", new_dim)
        self.fbo.update()

        self.qtbot.wait(100)
        self.fbo.update()

        scale = self.fbo_renderer._getPixelRatio()
        expected_w = int(new_dim * scale)
        expected_h = int(new_dim * scale)

        self.qtbot.waitUntil(
            lambda: self.fbo_renderer.rw.GetSize() == (expected_w, expected_h),
            timeout=1000,
        )

        self.assertEqual(ren.GetViewport(), (0.0, 0.0, 1.0, 1.0))

    def test_interaction_disabled(self):
        """Covers the branch where interaction is disabled."""
        self.fbo._interaction_enabled = False
        evt = QMouseEvent(
            QEvent.Type.MouseMove,
            QPointF(10, 10),
            QPointF(10, 10),
            Qt.NoButton,
            Qt.NoButton,
            Qt.NoModifier,
        )
        self.fbo.mouseMoveEvent(evt)

        self.qtbot.wait(100)

        self.fbo._interaction_enabled = True
        self.assertEqual(len(self.fbo_renderer._eventsToProcess), 0)

    def test_hover_move(self):
        """Covers hover event conversion to mouse move."""
        evt = QHoverEvent(
            QEvent.Type.HoverMove,
            QPointF(30, 30),
            QPointF(30, 30),
            QPointF(20, 20),
            Qt.NoModifier,
        )
        self.fbo.hoverMoveEvent(evt)

        with self.fbo.pendingEventsLock:
            self.assertEqual(self.fbo.pendingEvents[-1]["type"], QEvent.Type.MouseMove)

        self.qtbot.wait(50)

    def test_opengl_init_and_fbo_creation(self):
        """Covers createFramebufferObject execution inside Qt."""
        self.assertIsNotNone(self.fbo_renderer._openGLFbo)

    def test_render_and_init_state(self):
        """Forces a re-initialization of the OpenGL state to hit the initialization branch."""
        self.fbo_renderer._isOpenGLStateInitialized = False

        self.fbo.update()
        self.qtbot.wait(100)

        self.assertTrue(self.fbo_renderer._isOpenGLStateInitialized)

    def test_fbo_render_proxy(self):
        """Covers fbo.render() manual call."""
        self.fbo.render()
        self.qtbot.wait(50)
        self.assertTrue(True)


if __name__ == "__main__":
    unittest.main()
