#
#       pyvistaqml
#       Unit tests for the proxies class.
#
#       Copyright © 2026 Inria
#       Author(s): Manuel Petit <manuel.petit@inria.fr>
#
#       This file is part of pyvistaqml.
#
#       pyvistaqml is free software: you can redistribute it and/or modify
#       it under the terms of the GNU Lesser General Public License as published by
#       the Free Software Foundation, either version 3 of the License, or
#       (at your option) any later version.
#
#       pyvistaqml is distributed in the hope that it will be useful,
#       but WITHOUT ANY WARRANTY; without even the implied warranty of
#       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#       GNU Lesser General Public License for more details.
#
#       You should have received a copy of the GNU Lesser General Public License
#       along with pyvistaqml.  If not, see <https://www.gnu.org/licenses/>.
#
# -----------------------------------------------------------------------

import unittest
from unittest.mock import MagicMock
import pyvista
import vtk

from pyvistaqml.core.proxies import (
    AsyncVtkProxy,
    AsyncDictProxy,
    AsyncListProxy,
    AsyncRendererProxy,
    AsyncRenderersProxy,
    wrap_result,
)


class TestProxies(unittest.TestCase):
    def setUp(self):
        """Setup a mock plotter to intercept FBO dispatch tasks."""
        self.mock_plotter = MagicMock()
        self.mock_plotter._dispatch_to_fbo = MagicMock(
            side_effect=lambda task, task_name: task()
        )

    def test_wrap_result_logic(self):
        """Tests the standalone wrap_result helper and its recursive branches."""
        # Base cases: None and existing proxies
        self.assertIsNone(wrap_result(self.mock_plotter, None))
        p = AsyncVtkProxy(self.mock_plotter, vtk.vtkActor())
        self.assertIs(wrap_result(self.mock_plotter, p), p)

        # Collection wrapping
        self.assertIsInstance(wrap_result(self.mock_plotter, []), AsyncListProxy)
        self.assertIsInstance(wrap_result(self.mock_plotter, {}), AsyncDictProxy)

        # VTK/PyVista object wrapping
        self.assertIsInstance(
            wrap_result(self.mock_plotter, vtk.vtkCamera()), AsyncVtkProxy
        )
        self.assertIsInstance(
            wrap_result(self.mock_plotter, pyvista.Sphere()), AsyncVtkProxy
        )

    def test_async_vtk_proxy_logic(self):
        """Simulates real VTK interactions (actors, properties, meshes)."""
        actor = vtk.vtkActor()
        proxy = AsyncVtkProxy(self.mock_plotter, actor)

        # Repr, Str, and Native access
        self.assertIn("Actor", str(proxy))
        self.assertIn("Actor", repr(proxy))
        self.assertEqual(proxy.native, actor)

        prop_proxy = proxy.GetProperty()
        self.assertIsInstance(prop_proxy, AsyncVtkProxy)
        self.assertTrue(self.mock_plotter._dispatch_to_fbo.called)

        proxy.PickableOff()
        self.mock_plotter._dispatch_to_fbo.assert_called()

        # Equality
        other_proxy = AsyncVtkProxy(self.mock_plotter, actor)
        self.assertEqual(proxy, other_proxy)
        self.assertEqual(proxy, actor)
        self.assertNotEqual(proxy, vtk.vtkProperty())

        # Iteration & Indexing
        list_proxy = AsyncVtkProxy(self.mock_plotter, [vtk.vtkProperty()])
        self.assertEqual(len(list_proxy), 1)
        self.assertIsInstance(list_proxy[0], AsyncVtkProxy)
        for item in list_proxy:
            self.assertIsInstance(item, AsyncVtkProxy)

    def test_async_dict_proxy_logic(self):
        """Simulates PyVista's actor and scalar bar dictionaries."""

        class ActorDict(dict):
            """Simulates a PyVista dictionary subclass with methods."""

            def clear_all(self):
                return True

            @property
            def active_actor(self):
                return vtk.vtkActor()

        real_dict = ActorDict({"sphere": vtk.vtkActor(), "metadata": [1, 2]})
        proxy = AsyncDictProxy(self.mock_plotter, real_dict)

        # Dict Protocol
        self.assertIsInstance(proxy["sphere"], AsyncVtkProxy)
        self.assertIsInstance(proxy.get("sphere"), AsyncVtkProxy)
        self.assertIn("sphere", proxy)
        self.assertEqual(len(proxy), 2)
        self.assertIsInstance(proxy.values()[0], AsyncVtkProxy)
        self.assertIsInstance(proxy.items()[0][1], AsyncVtkProxy)

        # Attribute Extension
        self.assertTrue(proxy.clear_all())
        self.assertIsInstance(proxy.active_actor, AsyncVtkProxy)

        # Attribute Setters
        proxy.custom_tag = "test"
        self.mock_plotter._dispatch_to_fbo.assert_called()

        # Test other methods
        self.assertEqual(proxy.native, real_dict)
        self.assertEqual(list(proxy.keys()), ["sphere", "metadata"])
        self.assertEqual(len(proxy.values()), 2)
        self.assertEqual(len(proxy.items()), 2)
        self.assertIn("sphere", proxy)
        for _ in proxy:
            pass
        self.assertEqual(str(proxy), str(real_dict))
        self.assertEqual(repr(proxy), repr(real_dict))

    def test_async_list_proxy_logic(self):
        """Simulates PyVista's specialized renderer list."""

        class RendererList(list):
            """Simulates pyvista.plotting.renderers.Renderers."""

            @property
            def active_renderer(self):
                return vtk.vtkCamera()

            def remove_all(self):
                pass

        real_list = RendererList([vtk.vtkActor()])
        proxy = AsyncListProxy(self.mock_plotter, real_list)

        # List Protocol
        self.assertIsInstance(proxy[0], AsyncVtkProxy)
        self.assertEqual(len(proxy), 1)
        for item in proxy:
            self.assertIsInstance(item, AsyncVtkProxy)

        # Property access
        self.assertIsInstance(proxy.active_renderer, AsyncVtkProxy)

        # Method and Setter dispatch
        proxy.remove_all()
        proxy.dirty_flag = True
        self.mock_plotter._dispatch_to_fbo.assert_called()

        # Test other methods
        self.assertEqual(proxy.native, real_list)
        self.assertEqual(str(proxy), str(real_list))
        self.assertEqual(repr(proxy), repr(real_list))

    def test_async_vtk_proxy_getattr_non_callable(self):
        """Specifically tests the non-callable branch of __getattr__."""

        # Use a dummy class with a module name starting with 'vtk' to trigger proxying
        class MockVtkParent:
            __module__ = "vtkmodules.test"

            def __init__(self):
                self.child_list = [1, 2, 3]

        real_obj = MockVtkParent()
        proxy = AsyncVtkProxy(self.mock_plotter, real_obj)

        l_proxy = proxy.child_list
        self.assertIsInstance(l_proxy, AsyncListProxy)

    def test_async_vtk_proxy_setattr_dispatch(self):
        """Specifically tests the __setattr__ dispatch logic and task naming."""
        actor = vtk.vtkActor()
        proxy = AsyncVtkProxy(self.mock_plotter, actor)

        # Setting an attribute triggers the FBO dispatch task
        proxy.visibility = False

        args, kwargs = self.mock_plotter._dispatch_to_fbo.call_args
        self.assertEqual(kwargs.get("task_name"), "set_visibility")

        self.assertFalse(actor.GetVisibility())

        # Test other methods
        self.assertTrue(bool(proxy))
        self.assertEqual(proxy, actor)
        self.assertFalse(proxy == "not_a_proxy")

    def test_specialized_renderer_proxies(self):
        """Test AsyncRendererProxy and AsyncRenderersProxy logic."""
        # Use a real PyVista Plotter (offscreen) to safely get native Renderer objects
        plotter = pyvista.Plotter(off_screen=True)
        real_renderers = plotter.renderers
        real_renderer = plotter.renderer

        # Test wrap_result intercepts
        renderers_proxy = wrap_result(self.mock_plotter, real_renderers)
        self.assertIsInstance(renderers_proxy, AsyncRenderersProxy)

        renderer_proxy = wrap_result(self.mock_plotter, real_renderer)
        self.assertIsInstance(renderer_proxy, AsyncRendererProxy)

        # Test AsyncRendererProxy explicit properties
        self.assertIsInstance(renderer_proxy.camera, AsyncVtkProxy)
        self.assertIsInstance(renderer_proxy.actors, AsyncDictProxy)
        self.assertIsInstance(renderer_proxy.lights, AsyncListProxy)

        # Test AsyncRendererProxy.clear() dispatch
        real_renderer.clear = MagicMock()
        renderer_proxy.clear()
        self.mock_plotter._dispatch_to_fbo.assert_called()
        real_renderer.clear.assert_called_once()

        # Test AsyncRenderersProxy explicit property
        active_ren_proxy = renderers_proxy.active_renderer
        self.assertIsInstance(active_ren_proxy, AsyncRendererProxy)

        # Test AsyncRenderersProxy.set_active_renderer dispatch
        real_renderers.set_active_renderer = MagicMock()
        renderers_proxy.set_active_renderer(0)
        self.mock_plotter._dispatch_to_fbo.assert_called()
        real_renderers.set_active_renderer.assert_called_once_with(0)

        plotter.close()


if __name__ == "__main__":
    unittest.main()
