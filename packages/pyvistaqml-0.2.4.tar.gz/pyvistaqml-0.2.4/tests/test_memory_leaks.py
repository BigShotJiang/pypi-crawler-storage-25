#
#       pyvistaqml
#       Unit test for possible memory leaks in qmlInteractor.
#
#       Copyright © 2026 Inria
#       Author(s): Manuel Petit <manuel.petit@inria.fr>
#
#       This file is part of pyvistaqml.
#
#       pyvistaqml is free software: you can redistribute it and/or modify
#       it under the terms of the GNU Lesser General Public License as published by
#       the Free Software Foundation, either version 3 of the License, or
#       (at your option) any later version.
#
#       pyvistaqml is distributed in the hope that it will be useful,
#       but WITHOUT ANY WARRANTY; without even the implied warranty of
#       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#       GNU Lesser General Public License for more details.
#
#       You should have received a copy of the GNU Lesser General Public License
#       along with pyvistaqml.  If not, see <https://www.gnu.org/licenses/>.
#
# -----------------------------------------------------------------------

import gc
import weakref
import os
import tempfile
import pyvista
import pytest
import types

from PySide6.QtQuick import QQuickView
from PySide6.QtQml import qmlRegisterType
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QUrl, QObject, QCoreApplication, QEvent

from pyvistaqml.core.qmlInteractor import QmlInteractor
from pyvistaqml.core.fbo import Fbo
from pyvistaqml.utils.funcs import setup_opengl_format

# Force OpenGL backend for testing
os.environ["QSG_RHI_BACKEND"] = "opengl"
if os.environ.get("CI") in ["1", "true", "True"]:
    pyvista.OFF_SCREEN = True

setup_opengl_format()


class TestMemoryLeakDiagnostics:
    @classmethod
    def setup_class(cls):
        if not QApplication.instance():
            cls._app = QApplication([])
        else:
            cls._app = QApplication.instance()

        try:
            qmlRegisterType(Fbo, "pyvistaqml.core", 1, 0, "Fbo")
        except Exception:
            pass

    # Parameterized test to isolate possible memory leak sources
    @pytest.mark.parametrize(
        "scenario",
        [
            "1_baseline_empty",
            "2_mesh_added",
            "3_track_mouse_position",
            "4_cell_picking",
            "5_box_widget",
            "6_affine_transform_widget",
            "7_custom_threadsafe_observer",
            "8_heavy_scalar_bar",
            "9_camera_linking",
        ],
    )
    def test_isolate_memory_leak(self, qtbot, scenario):
        """Diagnoses which specific feature is causing the memory leak."""
        view = QQuickView()
        qml_content = """
        import QtQuick
        import pyvistaqml.core 1.0
        Item { width: 400; height: 400; Fbo { id: fbo; objectName: "fbo"; anchors.fill: parent } }
        """
        temp_qml = tempfile.NamedTemporaryFile(suffix=".qml", mode="w", delete=False)
        temp_qml.write(qml_content)
        temp_qml.close()
        view.setSource(QUrl.fromLocalFile(temp_qml.name))
        view.show()

        fbo_item = view.rootObject().findChild(QObject, "fbo")
        qtbot.waitUntil(lambda item=fbo_item: getattr(item, "_fboRenderer", None) is not None, timeout=5000)

        interactor = QmlInteractor(fbo=fbo_item)
        interactor_ref = weakref.ref(interactor)

        # Apply the specific scenario
        if scenario == "2_mesh_added":
            interactor.add_mesh(pyvista.Sphere())
        elif scenario == "3_track_mouse_position":
            interactor.track_mouse_position(callback=lambda pos: None)
        elif scenario == "4_cell_picking":
            interactor.enable_cell_picking(callback=lambda cell: None)
        elif scenario == "5_box_widget":
            interactor.add_mesh(pyvista.Sphere())
            interactor.add_box_widget(callback=lambda bounds: None)
        elif scenario == "6_affine_transform_widget":
            interactor.add_mesh(pyvista.Sphere(), name="test_affine")
            interactor.add_affine_transform_widget("test_affine")
        elif scenario == "7_custom_threadsafe_observer":
            interactor.add_threadsafe_observer(
                "LeftButtonPressEvent", lambda caller, event: None
            )
        elif scenario == "8_heavy_scalar_bar":
            mesh = pyvista.Sphere()
            mesh["data"] = mesh.points[:, 2]
            interactor.add_mesh(mesh, scalars="data", show_scalar_bar=True)
        elif scenario == "9_camera_linking":
            fbo_item2 = view.rootObject().findChild(QObject, "fbo")
            interactor2 = QmlInteractor(fbo=fbo_item2)
            interactor.link_cameras([interactor, interactor2])
            interactor.unlink_cameras([interactor, interactor2])
            interactor2.close()
            del interactor2


        qtbot.wait(150)
        interactor.close()
        qtbot.wait(150)

        del interactor
        del fbo_item

        view.close()
        view.deleteLater()
        del view

        for _ in range(3):
            gc.collect()

        # GC Interrogator
        leaked_obj = interactor_ref()
        if leaked_obj is not None:
            diagnostic_msg = f"\n\n--- EXACT MEMORY LEAK TRACE FOR: {scenario} ---\n"

            # Ask the garbage collector what is holding our object
            refs = gc.get_referrers(leaked_obj)
            for ref in refs:
                # Ignore the current execution frame
                if isinstance(ref, types.FrameType):
                    continue

                diagnostic_msg += f"-> Held by type: {type(ref)}\n"

                # If it's trapped in a dictionary, find the key
                if isinstance(ref, dict):
                    keys = [k for k, v in ref.items() if v is leaked_obj]
                    diagnostic_msg += f"   Trapped under dict keys: {keys}\n"

                # If it's trapped in a method/function closure
                elif hasattr(ref, "__name__"):
                    diagnostic_msg += f"   Function/Method name: {ref.__name__}\n"

            diagnostic_msg += "--------------------------------------------------\n"
            pytest.fail(diagnostic_msg)

        assert leaked_obj is None
        os.unlink(temp_qml.name)

    def test_global_object_creep(self, qtbot):
        """
        Ensures that repeated creation and destruction of interactors
        does not leave behind orphaned PySide6 wrappers or VTK proxies.
        """


        def run_cycle():
            view = QQuickView()
            qml_content = """
            import QtQuick
            import pyvistaqml.core 1.0
            Item { width: 400; height: 400; Fbo { id: fbo; objectName: "fbo"; anchors.fill: parent } }
            """
            temp_qml = tempfile.NamedTemporaryFile(
                suffix=".qml", mode="w", delete=False
            )
            temp_qml.write(qml_content)
            temp_qml.close()

            view.setSource(QUrl.fromLocalFile(temp_qml.name))
            view.show()

            fbo_item = view.rootObject().findChild(QObject, "fbo")
            qtbot.waitUntil(
                lambda item=fbo_item: getattr(item, "_fboRenderer", None) is not None,
                timeout=5000,
            )

            interactor = QmlInteractor(fbo=fbo_item)
            interactor.add_mesh(pyvista.Sphere())
            interactor.render()
            qtbot.waitUntil(lambda: len(interactor.renderer.actors) > 0, timeout=2000)

            interactor.close()
            view.close()
            view.deleteLater()

            del interactor
            del fbo_item
            del view

            # Force Qt to empty its C++ "Trash Can"
            for _ in range(10):
                QApplication.instance().processEvents()
            QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)

            os.unlink(temp_qml.name)

        # Forces Qt and VTK to cache their global singletons
        run_cycle()

        # Establish absolute baseline AFTER the framework is warmed up
        for _ in range(3):
            gc.collect()
        baseline_objects = len(gc.get_objects())

        # Run the heavy creation/destruction cycles
        for _ in range(5):
            run_cycle()

        # Check final object count
        for _ in range(3):
            gc.collect()
        final_objects = len(gc.get_objects())

        delta = final_objects - baseline_objects

        print("\n" + "=" * 50)
        print("GLOBAL CREEP TEST PASSED")
        print(f"Objects leaked over 5 complete lifecycles: {delta}")
        print(f"Average overhead per plotter: {delta / 5:.1f} objects")
        print("=" * 50 + "\n")

        # We allow ~49 objects buffer per cycle (due to VTK cache footprint?)
        assert delta <= 300, (
            f"Global object creep detected! Leaked {delta} objects over 5 cycles."
        )

    def test_proxy_lifecycle_isolation(self, qtbot):
        """
        Ensures that creating AsyncVtkProxies does not trap the interactor in a memory leak.
        """
        view = QQuickView()
        qml_content = """
        import QtQuick
        import pyvistaqml.core 1.0
        Item { width: 400; height: 400; Fbo { id: fbo; objectName: "fbo"; anchors.fill: parent } }
        """
        temp_qml = tempfile.NamedTemporaryFile(suffix=".qml", mode="w", delete=False)
        temp_qml.write(qml_content)
        temp_qml.close()

        view.setSource(QUrl.fromLocalFile(temp_qml.name))
        view.show()

        fbo_item = view.rootObject().findChild(QObject, "fbo")
        qtbot.waitUntil(
            lambda item=fbo_item: getattr(item, "_fboRenderer", None) is not None, timeout=5000
        )

        interactor = QmlInteractor(fbo=fbo_item)
        interactor_ref = weakref.ref(interactor)

        def _simulate_user_generating_proxies(itr):
            itr.add_mesh(pyvista.Sphere())
            _1 = itr.camera
            _2 = itr.renderer.actors
            _3 = itr.renderers
            _4 = itr.iren

        _simulate_user_generating_proxies(interactor)

        interactor.close()
        view.close()
        view.deleteLater()

        del interactor
        del fbo_item
        del view

        for _ in range(10):
            QApplication.instance().processEvents()
        QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)

        for _ in range(3):
            gc.collect()

        leaked_obj = interactor_ref()
        if leaked_obj is not None:
            diagnostic = "\n\n" + "=" * 50 + "\n"
            diagnostic += "MEMORY LEAK DIAGNOSTIC\n"
            diagnostic += "=" * 50 + "\n"
            diagnostic += "The interactor is still alive! Held by:\n\n"

            for ref in gc.get_referrers(leaked_obj):
                if isinstance(ref, types.FrameType):
                    continue  # Ignore the test frame

                diagnostic += f"-> {type(ref)}\n"

                if isinstance(ref, dict):
                    keys = [k for k, v in ref.items() if v is leaked_obj]
                    diagnostic += f"   Dict Keys: {keys}\n"
                elif hasattr(ref, "__name__"):
                    diagnostic += f"   Function/Method: {ref.__name__}\n"

            pytest.fail(diagnostic)

        assert leaked_obj is None
        os.unlink(temp_qml.name)
