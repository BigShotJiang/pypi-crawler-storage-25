#
#       pyvistaqml
#       Unit tests for qmlInteractor.
#
#       Copyright © 2026 Inria
#       Author(s): Manuel Petit <manuel.petit@inria.fr>
#
#       This file is part of pyvistaqml.
#
#       pyvistaqml is free software: you can redistribute it and/or modify
#       it under the terms of the GNU Lesser General Public License as published by
#       the Free Software Foundation, either version 3 of the License, or
#       (at your option) any later version.
#
#       pyvistaqml is distributed in the hope that it will be useful,
#       but WITHOUT ANY WARRANTY; without even the implied warranty of
#       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#       GNU Lesser General Public License for more details.
#
#       You should have received a copy of the GNU Lesser General Public License
#       along with pyvistaqml.  If not, see <https://www.gnu.org/licenses/>.
#
# -----------------------------------------------------------------------

import unittest
import pytest
import os
import tempfile
import numpy as np
import pyvista
import logging

from PySide6.QtQuick import QQuickView
from PySide6.QtQml import qmlRegisterType
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QUrl, QObject

from pyvistaqml.core.qmlInteractor import QmlInteractor
from pyvistaqml.core.fbo import Fbo
from pyvistaqml.core.fboRenderer import FboRenderer
from pyvistaqml.utils.funcs import setup_opengl_format

os.environ["QSG_RHI_BACKEND"] = "opengl"
if os.environ.get("CI") in ["1", "true", "True"]:
    pyvista.OFF_SCREEN = True

# Setup OpenGL Format
setup_opengl_format()


class TestInteractor(unittest.TestCase):
    view = None
    interactor = None
    temp_qml = None

    @pytest.fixture(autouse=True)
    def setup_qtbot(self, qtbot):
        self.qtbot = qtbot

    @classmethod
    def setUpClass(cls):
        try:
            qmlRegisterType(Fbo, "pyvistaqml.core", 1, 0, "Fbo")
        except Exception:
            pass

    def setUp(self):
        if TestInteractor.view is None:
            if not QApplication.instance():
                self._app = QApplication([])
            else:
                self._app = QApplication.instance()

            TestInteractor.view = QQuickView()
            qml_content = """
            import QtQuick
            import pyvistaqml.core 1.0
            Item { width: 400; height: 400; Fbo { id: fbo; objectName: "fbo"; anchors.fill: parent } }
            """
            TestInteractor.temp_qml = tempfile.NamedTemporaryFile(
                suffix=".qml", mode="w", delete=False
            )
            TestInteractor.temp_qml.write(qml_content)
            TestInteractor.temp_qml.close()

            TestInteractor.view.setSource(
                QUrl.fromLocalFile(TestInteractor.temp_qml.name)
            )
            TestInteractor.view.show()

            fbo_item = TestInteractor.view.rootObject().findChild(QObject, "fbo")
            TestInteractor.interactor = QmlInteractor(fbo=fbo_item)

        self.view = TestInteractor.view
        self.interactor = TestInteractor.interactor
        self.interactor.clear()

    # Avoid propagating proxy errors to the test runner
    def tearDown(self):
        if self.interactor and self.interactor._fbo:
            self.qtbot.waitUntil(
                lambda: self.interactor._fbo.commandQueue.empty() and not self.interactor._in_fbo_task,
                timeout=5000
            )
        self.qtbot.wait(100)
        pyvista.global_theme.restore_defaults()

    @classmethod
    def tearDownClass(cls):
        import gc

        if cls.interactor:
            cls.interactor.close()
            cls.interactor = None

        pyvista.close_all()

        if QApplication.instance():
            QApplication.instance().processEvents()

        if cls.view:
            cls.view.setSource(QUrl())
            cls.view.close()
            cls.view.deleteLater()
        cls.view = None

        if QApplication.instance():
            QApplication.instance().processEvents()

        gc.collect()
        if cls.temp_qml and os.path.exists(cls.temp_qml.name):
            os.unlink(cls.temp_qml.name)

    def test_initialization(self):
        self.assertTrue(self.interactor._initialized)
        self.assertIsNotNone(self.interactor._fbo)
        self.assertIsNotNone(self.interactor.ren_win)

    def test_add_methods_batched(self):
        mesh = pyvista.Sphere()
        self.interactor.add_mesh(mesh)
        mesh["elevation"] = mesh.points[:, 2]
        self.interactor.add_mesh(mesh, scalars="elevation")

        self.interactor.add_arrows(
            np.array([[0.0, 0.0, 0.0], [1.0, 0.0, 0.0]]),
            np.array([[1.0, 1.0, 1.0], [0.0, 0.0, 1.0]]),
        )
        self.interactor.add_floor()
        self.interactor.add_light(pyvista.Light())
        self.interactor.add_lines(np.array([[0, 0, 0], [1, 1, 1]]))
        self.interactor.add_point_labels(np.array([[0.0, 0.0, 0.0]]), ["Origin"])
        self.interactor.add_ruler([0, 0, 0], [1, 1, 1])
        self.interactor.add_silhouette(mesh)
        self.interactor.add_scalar_bar(title="Z Elevation")
        self.interactor.add_text("Test Overlay", position="upper_right", font_size=14)

        grid = pyvista.ImageData(dimensions=(5, 5, 5))
        rng = np.random.default_rng()
        grid["values"] = rng.random(grid.n_cells)
        self.interactor.add_volume(grid)

        self.qtbot.waitUntil(lambda: len(self.interactor.renderer.actors) > 3, timeout=2000)
        self.assertGreater(len(self.interactor.renderer.actors), 3)

    def test_camera_and_view_methods(self):
        self.interactor.camera_position = [
            (5.0, 5.0, 5.0),
            (0.0, 0.0, 0.0),
            (0.0, 0.0, 1.0),
        ]
        self.qtbot.waitUntil(
            lambda: np.allclose(self.interactor.camera_position[0], (5.0, 5.0, 5.0)),
            timeout=2000
        )
        views = [
            "view_xy",
            "view_xz",
            "view_yx",
            "view_yz",
            "view_zx",
            "view_zy",
            "view_isometric",
            "view_vector",
            "isometric_view",
        ]
        for v in views:
            if v == "view_vector":
                getattr(self.interactor, v)([1, 1, 1])
            else:
                getattr(self.interactor, v)()

        self.interactor.reset_camera()
        self.interactor.fly_to([1, 1, 1])
        self.interactor.zoom_camera(1.5)
        self.interactor.add_mesh(pyvista.Sphere())
        self.interactor.get_default_cam_pos()
        self.qtbot.waitUntil(lambda: len(self.interactor.renderer.actors) > 0, timeout=2000)

    def test_shading_and_effects_batched(self):
        self.interactor.add_mesh(pyvista.Cube())
        effects = [
            ("enable_anti_aliasing", "disable_anti_aliasing"),
            ("enable_depth_of_field", "disable_depth_of_field"),
            ("enable_eye_dome_lighting", "disable_eye_dome_lighting"),
            ("enable_ssao", "disable_ssao"),
            ("add_blurring", "remove_blurring"),
        ]
        for en, _ in effects:
            getattr(self.interactor, en)()
        self.qtbot.wait(50)
        for _, dis in effects:
            getattr(self.interactor, dis)()

        self.interactor.disable_depth_peeling()
        self.interactor.remove_all_lights()
        self.interactor.enable_lightkit()
        self.qtbot.wait(100)
        self.assertTrue(True)

    def test_picking_methods(self):
        picking_modes = [
            "enable_point_picking",
            "enable_mesh_picking",
            "enable_cell_picking",
            "enable_block_picking",
            "enable_element_picking",
            "enable_surface_point_picking",
            "enable_geodesic_picking",
            "enable_horizon_picking",
            "enable_path_picking",
            "enable_rectangle_picking",
            "enable_rectangle_through_picking",
            "enable_rectangle_visible_picking",
        ]
        for m in picking_modes:
            getattr(self.interactor, m)()
        self.interactor.disable_picking()
        self.qtbot.wait(50)

    def test_export_import_methods(self):
        self.interactor.add_mesh(pyvista.Sphere())

        with tempfile.TemporaryDirectory() as tmpdir:
            obj, gltf, img = (
                os.path.join(tmpdir, "t.obj"),
                os.path.join(tmpdir, "t.gltf"),
                os.path.join(tmpdir, "t.png"),
            )
            self.interactor.export_obj(obj)
            self.interactor.export_gltf(gltf)
            self.interactor.screenshot(img)
            try:
                self.interactor.export_html(os.path.join(tmpdir, "t.html"))
            except Exception:
                pass
            self.qtbot.waitUntil(lambda: os.path.exists(obj) and os.path.exists(img), timeout=2000)

    def test_miscellaneous_methods(self):
        self.interactor.add_mesh(pyvista.Sphere())
        self.interactor.background_color = "red"
        self.interactor.set_background("blue")
        self.interactor.show_grid()
        self.interactor.show_bounds()
        self.interactor.where_is("sphere")

        self.interactor.disable()
        self.qtbot.waitUntil(lambda: not self.interactor._fbo._interaction_enabled, timeout=2000)

        self.interactor.enable()
        self.qtbot.waitUntil(lambda: self.interactor._fbo._interaction_enabled, timeout=2000)

        self.assertIsNone(self.interactor.show())

        bounds = self.interactor.bounds
        self.assertEqual(len(bounds), 6)

    def test_all_widgets_and_cleanup(self):
        self.interactor.add_mesh(pyvista.Sphere(), name="widget_mesh")
        self.interactor.add_box_widget(callback=lambda *args: None)
        self.interactor.add_plane_widget(callback=lambda *args: None)
        self.interactor.add_line_widget(callback=lambda *args: None)
        self.interactor.add_slider_widget(
            callback=lambda *args: None, value=0.5, rng=[0, 1]
        )
        self.interactor.add_checkbox_button_widget(callback=lambda *args: None)
        self.interactor.add_axes()
        self.interactor.add_affine_transform_widget("widget_mesh")

        self.qtbot.waitUntil(lambda: "widget_mesh" in self.interactor._affine_widgets, timeout=2000)

        self.interactor.clear()

        self.qtbot.waitUntil(lambda : len(self.interactor._affine_widgets) == 0, timeout=2000)
        self.qtbot.waitUntil(lambda : len(self.interactor.renderer.actors) == 0, timeout=2000)

    def test_warnings_and_label_replacements(self):
        """Covers internal fallbacks for points and labels styling."""
        rng = np.random.default_rng()
        pts = rng.random((5, 3))

        self.interactor.add_points(pts, style="points")
        self.interactor.add_point_labels(pts, ["A"] * 5, show_points=True, name="L1")
        self.interactor.add_point_labels(
            pts, ["B"] * 5, render_points_as_spheres=True, shape_opacity=1.0, name="L2"
        )

        poly = pyvista.PolyData(pts)
        poly["scalars"] = [1, 2, 3, 4, 5]
        self.interactor.add_point_scalar_labels(
            poly, "scalars", show_points=True, name="L3"
        )
        self.qtbot.wait(100)

    def test_transparent_screenshot(self):
        """Covers the transparency branch of the screenshot method."""
        self.interactor.screenshot("transp.png", transparent_background=True)
        self.qtbot.wait(50)
        if os.path.exists("transp.png"):
            os.remove("transp.png")

    def test_boot_state_and_sync_mode(self):
        """Covers empty setters, context managers, and uninitialized state checks."""
        self.interactor.ren_win = None
        self.interactor.iren = None
        self.interactor.disable_depth_peeling()

        with self.interactor.sync_mode():
            self.assertTrue(self.interactor._force_sync_mode)
            self.assertNotEqual(
                type(self.interactor.renderer).__name__, "AsyncVtkProxy"
            )

        # Simulate boot phase bypass
        self.interactor._initialized = False
        _ = self.interactor.ren_win
        self.interactor._initialized = True

        @self.interactor.in_render_thread(task_name="t")
        def t(x):
            return x

        t(1)

        # Init failure constraint
        with self.assertRaises(RuntimeError):
            QmlInteractor(fbo=None)

    def test_dynamic_setters(self):
        """Covers the dynamic patching of BasePlotter property setters."""
        self.interactor.opacity = 0.5
        self.interactor.scale = [2.0, 2.0, 2.0]
        self.interactor._set_base_attr("background_color", "green")
        self.qtbot.wait(50)

    def test_tracebacks_and_error_handling(self):
        """Ensures crashes in UI/FBO queues are safely swallowed and logged."""
        import unittest.mock

        def _crash():
            raise ValueError("Intentional FBO Crash")

        with self.assertLogs(
            "pyvistaqml.core.qmlInteractor", level=logging.ERROR
        ) as cm:
            self.interactor._dispatch_to_fbo(_crash, task_name="crash_test")
            self.interactor.remove_actor("ghost")
            self.interactor.clear_actors()

            # Attempt affine widget on non-existent actor
            self.interactor.add_affine_transform_widget("ghost_actor")

            # Crash the UI Queue processing
            def ui_crash():
                raise ValueError("Intentional UI Crash")

            self.interactor._ui_queue.append(ui_crash)
            self.interactor.sig_main_thread_call.emit()

            self.qtbot.waitUntil(
                lambda: any("CRASH IN FBO TASK" in log for log in cm.output),
                timeout=2000
            )
            self.assertTrue(any("Error executing UI task" in log for log in cm.output))

        # Release passes with no window
        with unittest.mock.patch.object(
            QmlInteractor,
            "render_window",
            new_callable=unittest.mock.PropertyMock(return_value=None),
        ):
            self.interactor._release_active_passes()

    def test_safe_observers_and_nested_vtk_events(self):
        """Simulates native VTK C++ events to verify Python thread-safe callbacks."""
        cb_run = False

        def _cb(*args):
            nonlocal cb_run
            cb_run = True

        # Setup interaction scene
        self.interactor.add_mesh(pyvista.Plane(i_size=10, j_size=10))
        self.interactor.reset_camera()

        self.interactor.add_threadsafe_observer("LeftButtonPressEvent", _cb)
        self.interactor.track_mouse_position(callback=_cb)

        self.interactor.enable_cell_picking(through=True)
        self.interactor.enable_cell_picking(callback=_cb, left_clicking=True)

        self.qtbot.wait(100)

        def _sim():
            if self.interactor.iren and hasattr(self.interactor.iren, "interactor"):
                self.interactor.iren.interactor.SetEventPosition(200, 200)
                self.interactor.iren.interactor.InvokeEvent("MouseMoveEvent")

                self.interactor.iren.interactor.SetKeyCode("a")
                self.interactor.iren.interactor.InvokeEvent("KeyPressEvent")

                self.interactor.iren.interactor.InvokeEvent("LeftButtonReleaseEvent")

        self.interactor._dispatch_to_fbo(_sim)

        self.qtbot.waitUntil(lambda: cb_run, timeout=2000)

        self.interactor.untrack_mouse_position()

    def test_double_close_cleanup(self):
        """Ensures multiple close() calls don't crash the teardown process."""
        dummy_fbo = Fbo()
        dummy_fbo._fboRenderer = FboRenderer()

        disposable_interactor = QmlInteractor(fbo=dummy_fbo)
        disposable_interactor.close()
        self.qtbot.wait(50)
        disposable_interactor.close()

    def test_camera_linking_and_unlinking(self):
        """Covers linking and unlinking cameras across multiple interactors."""
        fbo2 = Fbo()
        fbo2._fboRenderer = FboRenderer()
        interactor2 = QmlInteractor(fbo=fbo2)
        interactor2._force_sync_mode = (
            True  # Enable synchronous processing for headless testing
        )

        fbo3 = Fbo()
        fbo3._fboRenderer = FboRenderer()
        interactor3 = QmlInteractor(fbo=fbo3)
        interactor3._force_sync_mode = (
            True  # Enable synchronous processing for headless testing
        )

        group = [self.interactor, interactor2, interactor3]

        def get_cam(interactor):
            cam = interactor.renderer.camera
            return getattr(cam, "native", cam)

        self.interactor.camera.position = (50.0, 50.0, 50.0)

        self.qtbot.waitUntil(
            lambda: np.allclose(get_cam(self.interactor).position, (50.0, 50.0, 50.0)),
            timeout=2000
        )
        self.assertNotEqual(get_cam(self.interactor).position, get_cam(interactor2).position)

        # Test linking
        self.interactor.link_cameras(group)

        # Wait for the FBO queue to process the link
        self.qtbot.waitUntil(
            lambda: np.allclose(get_cam(self.interactor).position, get_cam(interactor2).position),
            timeout=2000
        )
        self.assertIsNotNone(self.interactor._camera_link_observer)

        # Test observer callback (Thread Safety)
        self.interactor.camera.position = (100.0, 100.0, 100.0)
        self.qtbot.waitUntil(
            lambda: np.allclose(get_cam(interactor2).position, (100.0, 100.0, 100.0)),
            timeout=2000
        )

        # Test unlinking
        self.interactor.unlink_cameras(group)
        self.qtbot.waitUntil(lambda: self.interactor._camera_link_observer is None, timeout=2000)

        self.interactor.camera.position = (200.0, 200.0, 200.0)
        self.qtbot.waitUntil(
            lambda: np.allclose(get_cam(self.interactor).position, (200.0, 200.0, 200.0)),
            timeout=2000
        )
        self.assertEqual(get_cam(interactor2).position, (100.0, 100.0, 100.0))

        interactor2.close()
        interactor3.close()
