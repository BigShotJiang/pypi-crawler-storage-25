#
#       pyvistaqml
#       The QML-compatible Framebuffer Object for VTK rendering.
#
#       Copyright (C) 2022 Dao Duc Tung
#       Copyright © 2026 Inria
#
#       Modified by: Manuel Petit <manuel.petit@inria.fr>
#       Original source: https://github.com/dao-duc-tung/qml-vtk-python
#
#       This file is part of pyvistaqml.
#
#       pyvistaqml is free software: you can redistribute it and/or modify
#       it under the terms of the GNU Lesser General Public License as published by
#       the Free Software Foundation, either version 3 of the License, or
#       (at your option) any later version.
#
#       pyvistaqml is distributed in the hope that it will be useful,
#       but WITHOUT ANY WARRANTY; without even the implied warranty of
#       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#       GNU Lesser General Public License for more details.
#
#       You should have received a copy of the GNU Lesser General Public License
#       along with pyvistaqml.  If not, see <https://www.gnu.org/licenses/>.
#
# -----------------------------------------------------------------------

import logging
from typing import Callable, Any
import vtk

from queue import Queue
from threading import Lock

from PySide6.QtCore import QEvent, Qt
from PySide6.QtGui import QMouseEvent, QWheelEvent, QHoverEvent, QKeyEvent
from PySide6.QtQuick import QQuickFramebufferObject

from pyvistaqml.core.fboRenderer import FboRenderer
from pyvistaqml.utils.funcs import extractMouseData, extractWheelData, extractKeyData

logger = logging.getLogger(__name__)


class Fbo(QQuickFramebufferObject):
    """The QML-compatible Framebuffer Object for VTK rendering.

    This class serves as the bridge between the QML UI and the VTK Render Thread.
    It manages the command queue for thread-safe operations and captures UI
    events (mouse, keyboard) to be processed by the renderer.

    Notes
    -----
    **Thread Management (The QML / VTK Divide)**
    In QML, the UI logic (Main Thread) and the OpenGL rendering (Render Thread)
    are strictly separated. Modifying a VTK/PyVista object from the Main Thread
    while OpenGL is drawing it causes an immediate Segmentation Fault.

    `Fbo` acts as the bridge. It captures events on the Main Thread and
    pushes them to a thread-safe queue (`commandQueue`). The `FboRenderer`
    later executes these tasks on the Render Thread.

    Examples
    --------
    >>> from pyvistaqml.core import Fbo
    >>> fbo = Fbo()
    >>> fbo.addCommand(lambda: print("Executed on Render Thread"))
    """

    def __init__(self) -> None:
        """Initializes the FBO component and its internal synchronization primitives."""
        super().__init__()
        self._fboRenderer: FboRenderer | None = None

        self.commandQueue: Queue[Callable[..., Any]] = Queue()
        self.commandQueueLock: Lock = Lock()
        self.in_render_loop: bool = False

        self.pendingEvents: list[dict[str, Any]] = []
        self.pendingEventsLock: Lock = Lock()

        self._interaction_enabled: bool = True

        self.setAcceptedMouseButtons(Qt.AllButtons)
        self.setAcceptHoverEvents(True)
        self.setMirrorVertically(True)
        self.setFocusPolicy(Qt.StrongFocus)

    def render(self) -> None:
        """Triggers a render call in the VTK render window.

        Returns
        -------
        None
        """
        if self._fboRenderer and self._fboRenderer.rwi:
            self._fboRenderer.rwi.Render()

    def addRenderer(self, renderer: vtk.vtkRenderer) -> None:
        """Adds a VTK renderer to the internal render window.

        Parameters
        ----------
        renderer : vtk.vtkRenderer
            The VTK renderer instance to add.

        Returns
        -------
        None
        """
        if self._fboRenderer and self._fboRenderer.rw:
            self._fboRenderer.rw.AddRenderer(renderer)

    def setInteractorStyle(self, interactorStyle: vtk.vtkInteractorStyle) -> None:
        """Sets the VTK interactor style.

        Parameters
        ----------
        interactorStyle : vtk.vtkInteractorStyle
            The VTK interactor style instance.

        Returns
        -------
        None
        """
        if self._fboRenderer and self._fboRenderer.rwi:
            self._fboRenderer.rwi.SetInteractorStyle(interactorStyle)

    def initRWI(self) -> None:
        """Initializes and starts the VTK Render Window Interactor.

        Returns
        -------
        None
        """
        if self._fboRenderer and self._fboRenderer.rwi:
            self._fboRenderer.rwi.Initialize()
            self._fboRenderer.rwi.Start()

    def createRenderer(self) -> QQuickFramebufferObject.Renderer:
        """Creates the `FboRenderer` called by the Qt Scene Graph.

        Returns
        -------
        QQuickFramebufferObject.Renderer
            The initialized renderer instance for the Render Thread.
        """
        logging.debug("Fbo: createRenderer() called by Qt Scene Graph")
        self._fboRenderer = FboRenderer()
        return self._fboRenderer

    def addCommand(self, command: Callable[..., Any]) -> None:
        """Adds a command to the queue for execution on the Render Thread.

        Parameters
        ----------
        command : Callable[..., Any]
            The function or lambda to be executed on the Render Thread.

        Returns
        -------
        None
        """
        with self.commandQueueLock:
            self.commandQueue.put(command)
        self.update()

    def mousePressEvent(self, event: QMouseEvent) -> None:
        """Handles mouse press events and queues them for VTK processing.

        Parameters
        ----------
        event : QMouseEvent
            The Qt mouse event.

        Returns
        -------
        None
        """
        logger.debug(f"[UI] Mouse PRESS détecté - Pos: {event.position()}")
        with self.pendingEventsLock:
            self.pendingEvents.append(extractMouseData(event))
        event.accept()
        self.update()

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:
        """Handles mouse release events and queues them for VTK processing.

        Parameters
        ----------
        event : QMouseEvent
            The Qt mouse event.

        Returns
        -------
        None
        """
        logger.debug(f"[UI] Mouse RELEASE détecté - Pos: {event.position()}")
        with self.pendingEventsLock:
            self.pendingEvents.append(extractMouseData(event))
        event.accept()
        self.update()

    def mouseMoveEvent(self, event: QMouseEvent) -> None:
        """Handles mouse move events and queues them for VTK processing.

        Parameters
        ----------
        event : QMouseEvent
            The Qt mouse event.

        Returns
        -------
        None
        """
        with self.pendingEventsLock:
            self.pendingEvents.append(extractMouseData(event))
        event.accept()
        self.update()

    def wheelEvent(self, event: QWheelEvent) -> None:
        """Handles mouse wheel events and queues them for VTK processing.

        Parameters
        ----------
        event : QWheelEvent
            The Qt wheel event.

        Returns
        -------
        None
        """
        with self.pendingEventsLock:
            self.pendingEvents.append(extractWheelData(event))
        event.accept()
        self.update()

    def hoverMoveEvent(self, event: QHoverEvent) -> None:
        """Handles hover move events and queues them as mouse moves for VTK.

        Parameters
        ----------
        event : QHoverEvent
            The Qt hover event.

        Returns
        -------
        None
        """
        with self.pendingEventsLock:
            self.pendingEvents.append(
                extractMouseData(event, forced_type=QEvent.Type.MouseMove)
            )
        event.accept()
        self.update()

    def keyPressEvent(self, event: QKeyEvent) -> None:
        """Handles key press events and queues them for VTK processing.

        Parameters
        ----------
        event : QKeyEvent
            The Qt key event.

        Returns
        -------
        None
        """
        logger.debug(
            f"[UI] Touche PRESS détectée : '{event.text()}' (Key: {event.key()})"
        )
        with self.pendingEventsLock:
            self.pendingEvents.append(extractKeyData(event, "KeyPress"))
        event.accept()
        self.update()

    def keyReleaseEvent(self, event: QKeyEvent) -> None:
        """Handles key release events and queues them for VTK processing.

        Parameters
        ----------
        event : QKeyEvent
            The Qt key event.

        Returns
        -------
        None
        """
        with self.pendingEventsLock:
            self.pendingEvents.append(extractKeyData(event, "KeyRelease"))
        event.accept()
        self.update()
