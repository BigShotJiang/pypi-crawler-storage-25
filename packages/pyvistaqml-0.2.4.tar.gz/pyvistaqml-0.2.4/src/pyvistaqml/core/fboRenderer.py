#
#       pyvistaqml
#       The specialized OpenGL renderer for VTK within a QML FBO.
#
#       Copyright (C) 2022 Dao Duc Tung
#       Copyright © 2026 Inria
#
#       Modified by: Manuel Petit <manuel.petit@inria.fr>
#       Original source: https://github.com/dao-duc-tung/qml-vtk-python
#
#       This file is part of pyvistaqml.
#
#       pyvistaqml is free software: you can redistribute it and/or modify
#       it under the terms of the GNU Lesser General Public License as published by
#       the Free Software Foundation, either version 3 of the License, or
#       (at your option) any later version.
#
#       pyvistaqml is distributed in the hope that it will be useful,
#       but WITHOUT ANY WARRANTY; without even the implied warranty of
#       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#       GNU Lesser General Public License for more details.
#
#       You should have received a copy of the GNU Lesser General Public License
#       along with pyvistaqml.  If not, see <https://www.gnu.org/licenses/>.
#
# -----------------------------------------------------------------------

import logging
from typing import Any
import vtk
import weakref

from PySide6.QtCore import QSize, Qt, QEvent, QPointF
from PySide6.QtGui import QOpenGLFunctions
from PySide6.QtOpenGL import QOpenGLFramebufferObject, QOpenGLFramebufferObjectFormat
from PySide6.QtQuick import QQuickFramebufferObject

from .. import core

logger = logging.getLogger(__name__)


class FboRenderer(QQuickFramebufferObject.Renderer):
    """The specialized OpenGL renderer for VTK within a QML FBO.

    This class operates on the Render Thread. It manages the VTK render window
    and interactor, processes queued UI events, and executes commands
    dispatched from the Main Thread.

    Notes
    -----
    **The Execution (FboRenderer)**
    The C++ Scene Graph wakes up the `FboRenderer` on the Render Thread.
    The renderer pops commands from the queue and executes them natively.
    It also synchronizes the VTK render window size with the QML element
    and translates Qt events into VTK events.

    **Thread Management (The QML / VTK Divide)**
    In QML, the UI logic (Main Thread) and the OpenGL rendering (Render Thread)
    are strictly separated. Modifying a VTK/PyVista object from the Main Thread
    while OpenGL is drawing it causes an immediate Segmentation Fault.
    Commands are safely executed on the Render Thread via `_dispatch_to_fbo`
    and `@fbo_task`.

    Examples
    --------
    >>> from pyvistaqml.core import FboRenderer
    >>> renderer = FboRenderer()
    >>> renderer.render()
    """

    def __init__(self) -> None:
        """Initializes the renderer and its internal VTK objects.

        Returns
        -------
        None
        """
        super().__init__()
        logger.debug(f"FboRenderer: __init__ created {self}")

        self.rw: vtk.vtkGenericOpenGLRenderWindow = vtk.vtkGenericOpenGLRenderWindow()
        self.rwi: vtk.vtkGenericRenderWindowInteractor = (
            vtk.vtkGenericRenderWindowInteractor()
        )

        self.rwi.SetRenderWindow(self.rw)

        self._glFunc: QOpenGLFunctions = QOpenGLFunctions()
        self._isOpenGLStateInitialized: bool = False

        self._openGLFbo: QOpenGLFramebufferObject | None = None
        self._fbo_ref: weakref.ReferenceType["core.Fbo"] | None = None

        self._eventsToProcess: list[dict[str, Any]] = []

    @property
    def _fbo(self) -> "core.Fbo | None":
        """Safely unpacks the weak reference to the Fbo.

        Returns
        -------
        core.Fbo | None
            The Fbo instance if it still exists, otherwise None.
        """
        return self._fbo_ref() if self._fbo_ref else None

    def createFramebufferObject(self, size: QSize) -> QOpenGLFramebufferObject:
        """Creates the OpenGL Framebuffer Object for the given size.

        Parameters
        ----------
        size : QSize
            The requested size of the framebuffer.

        Returns
        -------
        QOpenGLFramebufferObject
            The created OpenGL FBO.
        """
        glFormat = QOpenGLFramebufferObjectFormat()
        glFormat.setAttachment(QOpenGLFramebufferObject.CombinedDepthStencil)
        self._openGLFbo = QOpenGLFramebufferObject(size, glFormat)
        self.rw.OpenGLInitContext()
        return self._openGLFbo

    def synchronize(self, item: "core.Fbo") -> None:
        """Synchronizes the renderer state with the QML Fbo item.

        This is called on the Render Thread before rendering starts. It
        updates the render window size and collects pending events from the Fbo.

        Parameters
        ----------
        item : core.Fbo
            The QML Fbo item to synchronize with.

        Returns
        -------
        None
        """
        rw = getattr(self, "rw", None)
        if rw is None:
            return

        if not self._fbo_ref:
            self._fbo_ref = weakref.ref(item)

        fbo = self._fbo
        if not fbo:
            return

        scale = self._getPixelRatio()
        w = int(fbo.width() * scale)
        h = int(fbo.height() * scale)
        if self.rw.GetSize() != (w, h):
            self.rw.SetSize(w, h)
            # Notify VTK that the renderer's viewport might need updating
            for r in self.rw.GetRenderers():
                r.SetViewport(0, 0, 1, 1)

        with fbo.pendingEventsLock:
            if getattr(fbo, "_interaction_enabled", True):
                self._eventsToProcess.extend(fbo.pendingEvents)
            fbo.pendingEvents.clear()

    def render(self) -> None:
        """Executes the actual OpenGL rendering and processes the command queue.

        This method is called by the Qt Scene Graph on the Render Thread.
        It processes all queued UI events and then executes all commands
        in the `commandQueue`.

        Returns
        -------
        None
        """
        rw = getattr(self, "rw", None)
        if rw is None:
            return

        fbo = self._fbo
        if fbo is not None:
            fbo.in_render_loop = True

        try:
            self.rw.SetReadyForRendering(True)
            self.rw.SetIsCurrent(True)
            if not self._isOpenGLStateInitialized:
                self._openGLInitState()
                self._isOpenGLStateInitialized = True

            for event_dict in self._eventsToProcess:
                # 1. Keyboard Events
                if event_dict.get("is_key_event"):
                    if event_dict["type"] == "KeyPress":
                        self._process_key_press_event(event_dict)
                    elif event_dict["type"] == "KeyRelease":
                        self._process_key_release_event(event_dict)

                # 2. Mouse Events
                elif event_dict.get("is_mouse_event"):
                    if event_dict["type"] == QEvent.Type.MouseMove:
                        self._process_mouse_move_event(event_dict)
                    elif event_dict["type"] in (
                        QEvent.Type.MouseButtonPress,
                        QEvent.Type.MouseButtonRelease,
                        QEvent.Type.MouseButtonDblClick,
                    ):
                        self._process_mouse_button_event(event_dict)

                # 3. Wheel Events
                elif event_dict.get("is_wheel_event"):
                    self._process_wheel_event(event_dict)

            self._eventsToProcess.clear()

            if fbo is not None:
                with fbo.commandQueueLock:
                    while not fbo.commandQueue.empty():
                        cmd = fbo.commandQueue.get()
                        cmd()
        finally:
            if fbo is not None:
                fbo.in_render_loop = False

    def _openGLInitState(self) -> None:
        """Initializes the OpenGL state for VTK.

        Returns
        -------
        None
        """
        self.rw.OpenGLInitState()
        self.rw.MakeCurrent()
        self._glFunc.initializeOpenGLFunctions()
        self._glFunc.glUseProgram(0)

    # --- Modifier Helper ---
    def _get_ctrl_shift(self, event_dict: dict[str, Any]) -> tuple[bool, bool]:
        """Extracts modifiers (Ctrl/Shift) from the event dictionary.

        Parameters
        ----------
        event_dict : dict[str, Any]
            The event data dictionary.

        Returns
        -------
        tuple[bool, bool]
            A tuple of (ctrl, shift) booleans.
        """
        modifiers = event_dict.get("modifiers", Qt.KeyboardModifier.NoModifier)
        shift = bool(modifiers & Qt.ShiftModifier)
        ctrl = bool(modifiers & Qt.ControlModifier)
        return ctrl, shift

    # --- Mouse & Wheel Processors ---
    def _process_mouse_button_event(self, event_dict: dict[str, Any]) -> None:
        """Translates a Qt mouse button event to a VTK event.

        Parameters
        ----------
        event_dict : dict[str, Any]
            The event data dictionary.

        Returns
        -------
        None
        """
        ctrl, shift = self._get_ctrl_shift(event_dict)
        evt_type = event_dict["type"]
        btn = event_dict["button"]

        repeat = 1 if evt_type == QEvent.Type.MouseButtonDblClick else 0

        self._setEventInformation(
            event_dict["position"], ctrl, shift, chr(0), repeat, None
        )

        if evt_type in (QEvent.Type.MouseButtonPress, QEvent.Type.MouseButtonDblClick):
            if btn == Qt.LeftButton:
                self.rwi.LeftButtonPressEvent()
            elif btn == Qt.RightButton:
                self.rwi.RightButtonPressEvent()
            elif btn == Qt.MiddleButton:
                self.rwi.MiddleButtonPressEvent()
        elif evt_type == QEvent.Type.MouseButtonRelease:
            if btn == Qt.LeftButton:
                self.rwi.LeftButtonReleaseEvent()
            elif btn == Qt.RightButton:
                self.rwi.RightButtonReleaseEvent()
            elif btn == Qt.MiddleButton:
                self.rwi.MiddleButtonReleaseEvent()

    def _process_mouse_move_event(self, event_dict: dict[str, Any]) -> None:
        """Translates a Qt mouse move event to a VTK event.

        Parameters
        ----------
        event_dict : dict[str, Any]
            The event data dictionary.

        Returns
        -------
        None
        """
        ctrl, shift = self._get_ctrl_shift(event_dict)
        self._setEventInformation(event_dict["position"], ctrl, shift, chr(0), 0, None)
        self.rwi.MouseMoveEvent()

    def _process_wheel_event(self, event_dict: dict[str, Any]) -> None:
        """Translates a Qt wheel event to a VTK event.

        Parameters
        ----------
        event_dict : dict[str, Any]
            The event data dictionary.

        Returns
        -------
        None
        """
        ctrl, shift = self._get_ctrl_shift(event_dict)
        self._setEventInformation(event_dict["position"], ctrl, shift, chr(0), 0, None)

        delta = event_dict.get("delta", 0)
        if delta > 0:
            self.rwi.MouseWheelForwardEvent()
        elif delta < 0:
            self.rwi.MouseWheelBackwardEvent()

    # --- Key Processors ---
    def _process_key_press_event(self, event_dict: dict[str, Any]) -> None:
        """Translates a Qt key press event to a VTK event.

        Parameters
        ----------
        event_dict : dict[str, Any]
            The event data dictionary.

        Returns
        -------
        None
        """
        ctrl, shift = self._get_ctrl_shift(event_dict)
        key_char = event_dict["text"] if event_dict["text"] else chr(0)
        keysym = self._map_qt_to_vtk_keysym(event_dict["key"], key_char)

        self.rwi.SetKeyEventInformation(ctrl, shift, key_char, 0, keysym)
        self.rwi.KeyPressEvent()
        self.rwi.CharEvent()

    def _process_key_release_event(self, event_dict: dict[str, Any]) -> None:
        """Translates a Qt key release event to a VTK event.

        Parameters
        ----------
        event_dict : dict[str, Any]
            The event data dictionary.

        Returns
        -------
        None
        """
        ctrl, shift = self._get_ctrl_shift(event_dict)
        key_char = event_dict["text"] if event_dict["text"] else chr(0)
        keysym = self._map_qt_to_vtk_keysym(event_dict["key"], key_char)

        self.rwi.SetKeyEventInformation(ctrl, shift, key_char, 0, keysym)
        self.rwi.KeyReleaseEvent()

    def _map_qt_to_vtk_keysym(self, qt_key: int, key_char: str) -> str:
        """Maps Qt key codes to VTK keysym strings.

        Parameters
        ----------
        qt_key : int
            The Qt key code.
        key_char : str
            The character representation of the key.

        Returns
        -------
        str
            The VTK keysym string.
        """
        if qt_key == Qt.Key_Space:
            return "space"
        if qt_key in (Qt.Key_Return, Qt.Key_Enter):
            return "Return"
        if qt_key == Qt.Key_Escape:
            return "Escape"
        if qt_key == Qt.Key_Up:
            return "Up"
        if qt_key == Qt.Key_Down:
            return "Down"
        if qt_key == Qt.Key_Left:
            return "Left"
        if qt_key == Qt.Key_Right:
            return "Right"
        return key_char

    # --- Utilities ---
    def _setEventInformation(
        self,
        positionPoint: QPointF,
        ctrl: bool,
        shift: bool,
        key: str,
        repeat: int = 0,
        keysum: str | None = None,
    ) -> None:
        """Sets the event information in the VTK interactor.

        Parameters
        ----------
        positionPoint : QPointF
            The Qt position point.
        ctrl : bool
            True if the Control modifier is active.
        shift : bool
            True if the Shift modifier is active.
        key : str
            The key character.
        repeat : int, optional
            Repeat count (1 for double click).
        keysum : str | None, optional
            VTK keysym string.

        Returns
        -------
        None
        """
        scale = self._getPixelRatio()
        (w, h) = self.rw.GetSize()
        y = h - positionPoint.y() * scale
        x = positionPoint.x() * scale

        self.rwi.SetEventInformation(
            int(round(x)),
            int(round(y)),
            ctrl,
            shift,
            key,
            repeat,
            keysum,
        )

    def _getPixelRatio(self) -> float:
        """Returns the device pixel ratio for the current window.

        Returns
        -------
        float
            The pixel ratio.
        """
        fbo = self._fbo
        if fbo and fbo.window():
            return fbo.window().devicePixelRatio()
        return 1.0
