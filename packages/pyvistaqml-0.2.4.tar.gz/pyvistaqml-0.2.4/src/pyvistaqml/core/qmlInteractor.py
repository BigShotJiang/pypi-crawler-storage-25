#
#       pyvistaqml
#       PyVista QML Interactor Module.
#
#       Copyright © 2026 Inria
#       Author(s): Manuel Petit <manuel.petit@inria.fr>
#
#       This file is part of pyvistaqml.
#
#       pyvistaqml is free software: you can redistribute it and/or modify
#       it under the terms of the GNU Lesser General Public License as published by
#       the Free Software Foundation, either version 3 of the License, or
#       (at your option) any later version.
#
#       pyvistaqml is distributed in the hope that it will be useful,
#       but WITHOUT ANY WARRANTY; without even the implied warranty of
#       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#       GNU Lesser General Public License for more details.
#
#       You should have received a copy of the GNU Lesser General Public License
#       along with pyvistaqml.  If not, see <https://www.gnu.org/licenses/>.
#
# -----------------------------------------------------------------------

"""PyVista QML Interactor Module.

This module provides the `QmlInteractor` class, which acts as a bridge between
high-level Python/QML application logic and the VTK render thread. It is designed
to mimic the behavior of `pyvistaqt.QtInteractor`, but is specifically adapted
for the highly asynchronous Qt Quick / QML framework.

Transitioning from `pyvistaqt.QtInteractor`
-------------------------------------------
If you are coming from `pyvistaqt`, using `QmlInteractor` will feel familiar,
but there is a fundamental architectural difference: QML strictly separates the
Main UI thread from the OpenGL Render thread. `QmlInteractor` uses a Metaprogramming
Proxy Engine to hide this complexity from the developer.

**1. Standard Usage (The Synchronous Illusion)**
Most standard PyVista commands work exactly as they do in `pyvistaqt`. The interactor
uses proxies to silently catch your commands on the Main Thread and route them to the GPU.

    >>> interactor.add_mesh(my_mesh, color='red')  # Works seamlessly

**2. The Problem: Reading Native Data**
Because commands are routed asynchronously, if you ask for a property, you receive
an `AsyncVtkProxy` back, not the native C++ object. This prevents you from accidentally
crashing the app. However, it means you can't read raw data directly.

    >>> camera = interactor.camera
    >>> print(camera.position) # Returns a Proxy object, not the tuple of coordinates!

**3. Solution A: The `sync_mode()` Context Manager**
Use `sync_mode` when you are on the Main UI Thread but need to temporarily bypass
the proxy engine to read true, native VTK properties immediately.

    >>> with interactor.sync_mode():
    >>>     real_camera = interactor.camera
    >>>     print(real_camera.position) # Returns (1.0, 2.0, 3.0) - Real data!

**4. Solution B: The `@in_render_thread()` Decorator**
If you need to execute a complex, multi-step VTK operation, pushing it command-by-command
from the Main Thread is slow. Use this decorator to send your entire custom function
to the GPU thread at once. Inside this function, proxies are completely disabled.

    >>> @interactor.in_render_thread(task_name="complex_setup")
    >>> def setup_scene():
    >>>     # Returns real objects because we are executing on the GPU thread!
    >>>     actor, mapper = interactor.add_composite(multiblock)
    >>>     mapper.block_attr[0].color = 'blue'
    >>>
    >>> setup_scene() # Dispatches safely

Notes
-----
**Thread Management (The QML / VTK Divide)**

* **The Problem:** In QML, the UI logic (Main Thread) and the OpenGL rendering (Render Thread) are strictly separated. Modifying a VTK/PyVista object from the Main Thread while OpenGL is drawing it causes an immediate Segmentation Fault.
* **The Solution (`QmlInteractor` & `Fbo`):** `QmlInteractor` acts as the bridge. It intercepts user commands on the Main Thread and pushes them to a thread-safe queue (`commandQueue` in `Fbo`).
* **The Execution (`FboRenderer`):** The C++ Scene Graph wakes up the `FboRenderer` on the Render Thread. The renderer pops commands from the queue and executes them natively via `_dispatch_to_fbo` and `@fbo_task`.

**Memory Management (The C++ vs. Python Lifecycle)**

* **The Problem:** PyVista and VTK are C++ libraries wrapped in Python. Python's Garbage Collector cannot see C++ circular references (e.g., a VTK Interactor holding a reference to a Plotter, which holds the Renderers). If the QML View is destroyed, the Python objects will leak, keeping the GPU memory permanently allocated.
* **The Solution (Aggressive Teardown):** The `close()` method in `QmlInteractor` is highly aggressive. It manually breaks C++ Observer cycles (`RemoveAllObservers()`), sets internal PyVista references to `None` (`self.renderers._plotter = None`), and explicitly removes the Plotter from PyVista's global tracking dictionary (`_ALL_PLOTTERS`).
"""

import contextlib
import functools
import logging
from typing import Any, Callable, Generator
import weakref

from PySide6.QtCore import QObject, Signal, Slot

import vtk

from .fbo import Fbo
from .proxies import wrap_result

from pyvista import wrap as pyvista_wrap
from pyvista.plotting import BasePlotter
from pyvista.plotting.camera import Camera
from pyvista.plotting.render_window_interactor import RenderWindowInteractor

logger = logging.getLogger(__name__)


@contextlib.contextmanager
def _no_base_plotter_init() -> Generator[None, None, None]:
    """Context manager to temporarily disable the default __init__ of PyVista's BasePlotter.

    Because `QmlInteractor` inherits from both `QObject` and `BasePlotter`, we
    need precise control over when PyVista initializes its internal VTK objects
    to prevent premature window creation before the QML FBO component is ready.
    """
    init = BasePlotter.__init__
    BasePlotter.__init__ = lambda *args, **kwargs: None
    try:
        yield
    finally:
        BasePlotter.__init__ = init


def fbo_task(task_name: str | None = None) -> Callable[..., Any]:
    """Decorator to safely package and dispatch a method to the FBO thread.

    Parameters
    ----------
    task_name : str | None, optional
        An optional name for the task. If None, the function's `__name__` is used.

    Returns
    -------
    Callable[..., Any]
        the decorated function.

    Examples
    --------
    >>> @fbo_task("my_custom_task")
        def my_method(self):
            pass
    """

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        @functools.wraps(func)
        def wrapper(self: Any, *args: Any, **kwargs: Any) -> Any:
            # If no name is provided, automatically use the function's name
            name = task_name or func.__name__
            return self._dispatch_to_fbo(
                lambda: func(self, *args, **kwargs), task_name=name
            )

        return wrapper

    return decorator


class QmlInteractor(QObject, BasePlotter):
    """The main bridge between high-level Python/QML logic and the VTK render thread.

    Inherits from PyVista's `BasePlotter` to provide the full PyVista API, but
    overrides core mechanisms to dispatch operations safely to the OpenGL
    Render Thread.

    Parameters
    ----------
    fbo : Fbo
        The Framebuffer Object that this interactor is bound to.
    debounce_render : bool, default: True
        If True, rapid sequential calls to `render()` are deduplicated. Only one
        render command is queued for the next OpenGL frame, saving CPU/GPU cycles.
    **kwargs : Any
        Keyword arguments passed to the parent classes.

    Notes
    -----
    **Thread Management (The QML / VTK Divide)**
    `QmlInteractor` acts as the bridge. It intercepts user commands on the Main
    Thread and pushes them to a thread-safe queue. It uses asynchronous proxies
    (`AsyncVtkProxy`) to provide a synchronous developer experience.
    """

    sig_main_thread_call = Signal()

    def __init__(self, fbo: Fbo, debounce_render: bool = True, **kwargs: Any) -> None:
        """Initializes the interactor and binds it to a guaranteed QML Fbo component.

        Parameters
        ----------
        fbo : Fbo
            The Framebuffer Object that this interactor is bound to.
        debounce_render : bool, default: True
            If True, rapid sequential calls to `render()` are deduplicated. Only one
            render command is queued for the next OpenGL frame, saving CPU/GPU cycles.
        **kwargs : Any
            Keyword arguments passed to the BasePlotter class.

        Returns
        -------
        None

        Notes
        -----
        **Thread State Flags**
        The Interactor relies on three crucial state flags to manage thread safety
        and prevent deadlocks when interacting with C++ VTK objects:

        * `_force_sync_mode` (bool): When True (set by the `sync_mode` context manager),
            the asynchronous proxy engine is completely bypassed. Property accesses and
            method calls will immediately return native C++ VTK objects rather than Proxies.
        * `_in_fbo_task` (bool): A safety flag used by `_dispatch_to_fbo`. It is True
            only when the Render Thread is actively processing a queued Python task. It
            prevents "re-entrant deadlocks" (where the Render Thread tries to queue a
            task onto itself and waits indefinitely).
        * `fbo.in_render_loop` (bool): Maintained by the underlying FBO component.
            Indicates whether the OpenGL C++ Scene Graph is actively ticking. If True,
            it is inherently safe to bypass proxies because execution is already safely
            occurring within the GPU rendering lifecycle.
        """
        # =====================================================================
        # 1. State Flags Initialization
        # =====================================================================
        self._initialized: bool = False
        self._closed: bool = False
        self._ui_queue: list[Callable[..., Any]] = []
        self._fbo: Fbo | None = None

        # Thread & Dispatch Management Flags
        self._force_sync_mode: bool = False
        self._in_fbo_task: bool = False
        self._render_pending: bool = False
        self._debounce_render: bool = debounce_render

        if isinstance(fbo, Fbo):
            self._fbo = fbo
        else:
            raise RuntimeError("A valid Fbo component must be provided.")

        self._iren_wrapper = None
        self._renderer_wrapper = None

        # Observer & Widget Placeholders
        self._affine_widgets: dict[Any, Any] = {}
        self._cell_pick_observer = None
        self._mouse_move_observer = None
        self._camera_link_observer = None
        self._picking_text = None

        # =====================================================================
        # 2. Safely initialize Base classes
        # =====================================================================
        with _no_base_plotter_init():
            QObject.__init__(self)
        BasePlotter.__init__(self, **kwargs)

        self.interactor = self
        self.sig_main_thread_call.connect(self._process_ui_queue)

        # =====================================================================
        # 3. Mimic the QtInteractor setup flow
        # =====================================================================
        self._patch_baseplotter_methods()
        self._setup_interactor()
        self._setup_key_press()

        self._initialized = True

    @fbo_task(task_name="setup_interactor")
    def _setup_interactor(self):
        """Matches QtInteractor._setup_interactor"""
        fbo_renderer = getattr(self._fbo, "_fboRenderer", None)

        if not fbo_renderer:
            return

        # Bind PyVista renderers to the FBO
        for r in self.renderers:
            self._fbo.addRenderer(r)

        if fbo_renderer.rwi:
            self._iren_wrapper = RenderWindowInteractor(
                self, interactor=fbo_renderer.rwi
            )
            self._iren_wrapper.interactor.RemoveObservers("MouseMoveEvent")

            # Initialize
            self._fbo.initRWI()
            self._iren_wrapper.initialize()

            self.enable_trackball_style()

            # Define a callback for triggering Qt Scene Graph updates using thread-safe queue
            def _trigger_update(*args):
                if self._fbo:
                    self._ui_queue.append(self._fbo.update)
                    self.sig_main_thread_call.emit()

            self._render_event_observer = fbo_renderer.rwi.AddObserver(
                "RenderEvent", _trigger_update
            )

    @fbo_task(task_name="setup_key_press")
    def _setup_key_press(self):
        """Matches QtInteractor setup, but strictly bound to the Render Thread."""
        self._observers = {}

        if self.iren and hasattr(self.iren, "interactor"):
            self.iren.add_observer(
                "KeyPressEvent",
                lambda obj, event: BasePlotter.key_press_event(self, obj, event),
            )

        self.reset_key_events()

    # =========================================================================
    # CORE PROXIES (Window, Renderer, Interactor)
    # =========================================================================

    @property
    def ren_win(self):
        """Retrieves the VTK Render Window attached to the FBO."""
        if not self._fbo or not hasattr(self._fbo, "_fboRenderer"):
            return None
        fbo_renderer = getattr(self._fbo, "_fboRenderer")
        return fbo_renderer.rw if fbo_renderer else None

    @ren_win.setter
    def ren_win(self, value):
        pass

    @ren_win.deleter
    def ren_win(self):
        pass

    @property
    def render_window(self):
        return self.ren_win

    @property
    def iren(self):
        """Retrieves the VTK Render Window Interactor attached to the FBO."""
        if not self._fbo or not hasattr(self._fbo, "_fboRenderer"):
            return None
        fbo_renderer = getattr(self._fbo, "_fboRenderer")
        if not fbo_renderer:
            return None

        if (
            self._iren_wrapper is None
            or self._iren_wrapper.interactor != fbo_renderer.rwi
        ):
            self._iren_wrapper = RenderWindowInteractor(
                self, interactor=fbo_renderer.rwi
            )

        return self._iren_wrapper

    @iren.setter
    def iren(self, value):
        pass

    @iren.deleter
    def iren(self):
        pass

    # =========================================================================
    # STRICT OVERRIDES (Window & Render Control & Teardown)
    # =========================================================================

    def render(self) -> None:
        """Triggers a VTK render and queues a QML screen update.

        This method safely dispatches the native VTK render command to the
        background FBO thread. To prevent Qt threading violations and X11/Xvfb
        deadlocks, it ensures that the subsequent Qt ``update()`` request is
        always routed back to the Main UI Thread.

        Returns
        -------
        None
        """
        if self._debounce_render and self._render_pending:
            return

        self._render_pending = True

        def _task():
            self.render_window.Render()
            self._render_pending = False

        self._dispatch_to_fbo(_task, task_name="render")

        # Thread-safe Qt Scene Graph update
        if self._fbo:
            if self._is_safe_to_return_real_object():
                # Route the Qt update request safely back to the Main UI Thread
                self._ui_queue.append(self._fbo.update)
                self.sig_main_thread_call.emit()
            else:
                # Already on the UI thread, legally call it directly
                self._fbo.update()

    def show(self, *args: Any, **kwargs: Any) -> None:
        """Triggers a render in the QML FBO.

        In QML, the application engine handles the event loop, so this method
        simply requests an update from the FBO component.

        Parameters
        ----------
        *args : Any
            Positional arguments (ignored).
        **kwargs : Any
            Keyword arguments (ignored).

        Returns
        -------
        None
        """
        self.render()

    @fbo_task(task_name="clear_axes_widgets")
    def clear_axes_widgets(self) -> None:
        """Safely removes all orientation axes from the renderers.

        Returns
        -------
        None
        """
        for r in self.renderers:
            if r.axes_widget:
                r.axes_widget.Off()
                r.axes_widget.SetInteractor(None)
                r.axes_widget = None

    @fbo_task(task_name="clear_affine_widgets")
    def clear_affine_widgets(self) -> None:
        """Safely removes all custom affine transform widgets.

        Returns
        -------
        None
        """
        for widget in self._affine_widgets.values():
            widget.remove()
        self._affine_widgets.clear()

    @fbo_task(task_name="clear_widgets")
    def clear_widgets(self) -> None:
        """Safely removes all interactive VTK widgets from the scene.

        Returns
        -------
        None
        """
        # 1. Call our dedicated sub-cleaners safely
        self.clear_axes_widgets()
        self.clear_affine_widgets()

        # 2. Clear standard PyVista widgets
        widget_methods = [
            "clear_box_widgets",
            "clear_plane_widgets",
            "clear_line_widgets",
            "clear_slider_widgets",
            "clear_sphere_widgets",
            "clear_spline_widgets",
            "clear_button_widgets",
            "clear_camera_widgets",
            "clear_logo_widgets",
            "clear_measure_widgets",
            "clear_radio_button_widgets",
            "clear_camera3d_widgets",
        ]
        for method_name in widget_methods:
            getattr(BasePlotter, method_name)(self)

    @fbo_task(task_name="clear")
    def clear(self, *args: Any, **kwargs: Any) -> None:
        """Wipes the VTK scene completely without closing the window.

        Parameters
        ----------
        *args : Any
            Positional arguments passed to `BasePlotter.clear`.
        **kwargs : Any
            Keyword arguments passed to `BasePlotter.clear`.

        Returns
        -------
        None
        """
        # 0. Disable all interaction styles and observers
        logger.debug("QmlInteractor: Clearing all interaction styles and observers.")
        self.disable_picking()
        self.untrack_mouse_position()

        # 1. Force widget cleanup using our centralized method
        self.clear_widgets()

        # 2. Wipe the 3D props
        if self.renderer:
            self.renderer.RemoveAllViewProps()

        # 3. Let PyVista reset its internal lists
        BasePlotter.clear(self)

    def close(self, *args: Any, **kwargs: Any) -> None:
        """Tears down the application and prevents dangling pointer crashes.

        Safely closes the interactor, breaking Qt signals, clearing execution queues,
        and aggressively destroying C++ VTK cycles to prevent memory leaks when the
        QML view is destroyed.

        Parameters
        ----------
        *args : Any
            Positional arguments passed down to `BasePlotter.close`.
        **kwargs : Any
            Keyword arguments passed down to `BasePlotter.close`.

        Returns
        -------
        None

        Notes
        -----
        **Memory Management (The C++ vs. Python Lifecycle)**

        * **The Problem:** PyVista and VTK are C++ libraries wrapped in Python. Python's Garbage Collector cannot see C++ circular references (e.g., a VTK Interactor holding a reference to a Plotter, which holds the Renderers). If the QML View is destroyed, the Python objects will leak, keeping the GPU memory permanently allocated.
        * **The Solution (Aggressive Teardown):** The `close()` method in `QmlInteractor` is highly aggressive. It manually breaks C++ Observer cycles (`RemoveAllObservers()`), sets internal PyVista references to `None` (`self.renderers._plotter = None`), and explicitly removes the Plotter from PyVista's global tracking dictionary (`_ALL_PLOTTERS`).
        * **Signal Disconnection:** Qt Signals (`sig_main_thread_call`) are manually disconnected during teardown to sever the final links between the Python UI queue and the C++ Event Loop.
        """
        if self._closed:
            return

        self._closed = True

        # 1. Break Qt Signal references safely
        try:
            self.sig_main_thread_call.disconnect()
        except Exception:
            pass

        self._ui_queue.clear()

        if self._fbo:
            with self._fbo.commandQueueLock:
                while not self._fbo.commandQueue.empty():
                    self._fbo.commandQueue.get()

        # 3. Synchronous Teardown
        with self.sync_mode():
            if getattr(self, "iren", None):
                if hasattr(self.iren, "interactor"):
                    self.iren.interactor.RemoveAllObservers()
                if hasattr(self.iren, "_observers"):
                    self.iren._observers.clear()
                if hasattr(self.iren, "plotter"):
                    self.iren.plotter = None

            # 4. PyVista Renderer cycle breaker
            if hasattr(self, "renderers"):
                if hasattr(self.renderers, "_plotter"):
                    self.renderers._plotter = None

                for r in self.renderers:
                    if hasattr(r, "parent"):
                        r.parent = None
                    if hasattr(r, "figure"):
                        r.figure = None
                    if hasattr(r, "_plotter"):
                        r._plotter = None

            # Standard PyVista teardown
            BasePlotter.close(self)

            # Replace with an empty list so PyVista's __del__ doesn't crash later
            self.__dict__["renderers"] = []

        # 5. Evict from global PyVista dictionary using absolute memory identity
        from pyvista.plotting.plotter import _ALL_PLOTTERS

        to_pop = [k for k, v in _ALL_PLOTTERS.items() if v is self]
        for k in to_pop:
            _ALL_PLOTTERS.pop(k, None)

        # 6. Obliterate Python instance dictionaries to shatter ALL closures
        # explicitly preserve the attributes created in __init__ to support safe dot-notation
        safe_keys = {
            "_closed",
            "_initialized",
            "renderers",
            "_force_sync_mode",
            "_in_fbo_task",
            "_fbo",
            "_render_pending",
            "_debounce_render",
            "_ui_queue",
            "_iren_wrapper",
            "_renderer_wrapper",
            "_affine_widgets",
            "_cell_pick_observer",
            "_mouse_move_observer",
            "_camera_link_observer",
            "_picking_text",
        }
        for key in list(self.__dict__.keys()):
            if key not in safe_keys:
                self.__dict__.pop(key, None)

        self._fbo = None  # Safely release the Qt Reference

        # 7. Inform the Qt Event Loop that this Python wrapper can be safely deleted
        self.deleteLater()

    # =========================================================================
    # EXPLICIT DISPATCH OVERRIDES (Bug fixes and special cases)
    # =========================================================================

    def add_points(self, *args: Any, **kwargs: Any) -> Any:
        """Adds points to the scene with QML-specific stability fixes.

        In a QML/FBO environment, the standard 'points' style often causes
        rendering artifacts. This method unconditionally replaces it with
        'points_gaussian' for visual stability.

        Parameters
        ----------
        *args : Any
            Positional arguments passed to `add_points`.
        **kwargs : Any
            Keyword arguments passed to `add_points`.

        Returns
        -------
        Any
            The added actor proxy.
        """
        style = kwargs.get("style", "points")

        if style == "points":
            logger.warning(
                "QmlInteractor: Warning: 'style=\"points\"' is known to have issues in QML/FBO. "
                "Automatically switching to 'style=\"points_gaussian\"' for better stability."
            )
            kwargs["style"] = "points_gaussian"

        return self._dispatch_call("add_points", *args, **kwargs)

    def add_point_labels(self, points: Any, labels: Any, **kwargs: Any) -> Any:
        """Adds point labels with depth-sorting fixes for QML.

        Intelligently separates points from their text labels to prevent Z-Buffer
        (depth sorting) bugs specific to VTK and OpenGL transparency in QML.

        Parameters
        ----------
        points : Any
            The points to label.
        labels : Any
            The labels for the points.
        **kwargs : Any
            Keyword arguments passed to `add_point_labels`.

        Returns
        -------
        Any
            The added actor proxy.
        """
        show_points = kwargs.pop("show_points", True)
        render_spheres = kwargs.pop("render_points_as_spheres", False)
        p_color = kwargs.pop("point_color", kwargs.get("text_color", None))
        p_size = kwargs.pop("point_size", 5.0)

        if render_spheres:
            provided_opacity = kwargs.get("shape_opacity", 1.0)
            if provided_opacity is None or provided_opacity > 0.0:
                logger.warning(
                    "QmlInteractor: Warning: 'render_points_as_spheres=True' "
                    "causes depth bugs with label backgrounds. "
                    "Automatically forcing 'shape_opacity=0.0' to guarantee text visibility."
                )
            kwargs["shape_opacity"] = 0.0

        name = kwargs.get("name", "labels")

        if not show_points:
            # Trick to hide points without destroying the actor pipeline
            p_size = 0.0

        # We use a custom suffix to prevent PyVista's native hardcoded cleanup logic
        pts_name = f"{name}-qml_pts"
        self.add_points(
            points,
            color=p_color,
            point_size=p_size,
            name=pts_name,
            render_points_as_spheres=render_spheres,
        )

        kwargs["show_points"] = False
        return self._dispatch_call("add_point_labels", points, labels, **kwargs)

    def add_point_scalar_labels(self, points: Any, labels: Any, **kwargs: Any) -> Any:
        """Adds scalar labels, bypassing a native PyVista bug.

        Formats numbers directly in Python to ensure correct display.

        Parameters
        ----------
        points : Any
            The points to label.
        labels : Any
            The scalar labels or array name.
        **kwargs : Any
            Keyword arguments passed to `add_point_labels`.

        Returns
        -------
        Any
            The added actor proxy.
        """
        fmt = kwargs.pop("fmt", "%.2f")

        if isinstance(labels, str) and hasattr(points, "point_data"):
            scalar_array = points.point_data.get(labels)
            if scalar_array is not None:
                str_labels = [fmt % val for val in scalar_array]
                return self.add_point_labels(points, str_labels, **kwargs)

        return self.add_point_labels(points, labels, **kwargs)

    @fbo_task(task_name="add_affine_transform_widget")
    def add_affine_transform_widget(
        self, actor: str | vtk.vtkActor, *args: Any, **kwargs: Any
    ) -> Any:
        """Adds an affine transform widget to an actor.

        Includes fixes for macOS stability by swapping the hardware picker.

        Parameters
        ----------
        actor : str | vtk.vtkActor
            The actor or actor name to attach the widget to.
        *args : Any
            Positional arguments for the widget.
        **kwargs : Any
            Keyword arguments for the widget.

        Returns
        -------
        Any
            The created widget proxy.
        """
        actual_actor = self.actors.get(actor) if isinstance(actor, str) else actor
        if actual_actor is None:
            return None

        widget = BasePlotter.add_affine_transform_widget(
            self, actual_actor, *args, **kwargs
        )

        # Swap the GPU HardwarePicker for a stable CPU PropPicker (macOS fix)
        stable_picker = vtk.vtkPropPicker()
        if self.iren:
            self.iren.interactor.SetPicker(stable_picker)

        key = actor if isinstance(actor, str) else id(actual_actor)
        self._affine_widgets[key] = widget

        return widget

    def _release_active_passes(self) -> None:
        """Requests VTK (C++) to natively release memory of all active graphic passes.

        Returns
        -------
        None
        """
        if not self.render_window:
            return

        for renderer in self.renderers:
            current_pass = renderer.GetPass()
            if current_pass is not None:
                # Releasing the root pass propagates cleanup to all sub-shaders (Blur, SSAO, etc.)
                current_pass.ReleaseGraphicsResources(self.render_window)

    @fbo_task(task_name="remove_blurring")
    def remove_blurring(self) -> None:
        """
        Removes blurring from the scene, releasing graphics resources first.
        """
        self._release_active_passes()
        BasePlotter.remove_blurring(self)

    @fbo_task(task_name="disable_ssao")
    def disable_ssao(self) -> None:
        """
        Disables SSAO, releasing graphics resources first.
        """
        self._release_active_passes()
        BasePlotter.disable_ssao(self)

    @fbo_task(task_name="disable_depth_of_field")
    def disable_depth_of_field(self) -> None:
        """
        Disables depth of field, releasing graphics resources first.
        """
        self._release_active_passes()
        BasePlotter.disable_depth_of_field(self)

    @fbo_task(task_name="disable_eye_dome_lighting")
    def disable_eye_dome_lighting(self):
        self._release_active_passes()
        BasePlotter.disable_eye_dome_lighting(self)

    def enable_depth_peeling(self, **kwargs):
        """
        Depth Peeling destroys the QML Framebuffer on macOS/Metal, block it to prevent severe UI/GPU corruption.
        """
        logger.warning(
            "enable_depth_peeling() has been blocked. "
            "It destroys the shared QML Framebuffer context and causes GPU crashes. "
            "Use 'enable_anti_aliasing()' instead for better transparency rendering."
        )
        return False

    def disable_depth_peeling(self):
        """Silently pass, as depth peeling cannot be enabled anyway."""
        pass

    @fbo_task(task_name="enable_cell_picking")
    def enable_cell_picking(
        self,
        callback=None,
        show=True,
        show_message=False,
        color="pink",
        left_clicking=False,
        through=False,
        **kwargs,
    ):
        """ """
        self.disable_picking()

        if through:
            BasePlotter.enable_cell_picking(
                self,
                callback=callback,
                show=show,
                show_message=show_message,
                color=color,
                left_clicking=left_clicking,
                through=through,
                **kwargs,
            )
            return

        picker = vtk.vtkCellPicker()
        picker.SetTolerance(0.01)

        if self.iren and hasattr(self.iren, "interactor"):
            self.iren.interactor.SetPicker(picker)

        def _perform_pick(caller, event):
            click_x, click_y = caller.GetEventPosition()
            picker.Pick(click_x, click_y, 0, self.renderer)

            cell_id = picker.GetCellId()
            if cell_id != -1:
                actor = picker.GetActor()
                if actor and actor.GetMapper():
                    dataset = pyvista_wrap(actor.GetMapper().GetDataSetInput())
                    picked_cell = dataset.extract_cells(cell_id)

                    if callback:
                        safe_cb = self._wrap_threadsafe(callback)
                        safe_cb(picked_cell)

        if self.iren and hasattr(self.iren, "interactor"):
            if left_clicking:
                self._cell_pick_observer = self.iren.interactor.AddObserver(
                    "LeftButtonReleaseEvent", _perform_pick
                )
            else:

                def _on_key(caller, event):
                    if caller.GetKeyCode() == "p":
                        _perform_pick(caller, event)

                self._cell_pick_observer = self.iren.interactor.AddObserver(
                    "KeyPressEvent", _on_key
                )

    @fbo_task(task_name="disable_picking")
    def disable_picking(self):
        """Safely disables picking and resets the interaction style."""
        if self._cell_pick_observer and self.iren and hasattr(self.iren, "interactor"):
            self.iren.interactor.RemoveObserver(self._cell_pick_observer)
            self._cell_pick_observer = None

        self._picking_text = None

        BasePlotter.disable_picking(self)

    @fbo_task(task_name="track_mouse_position")
    def track_mouse_position(self, callback=None, **kwargs):
        """
        Custom QML override: Tracks mouse position, prevents observer leaks,
        and adds support for a thread-safe callback (which native PyVista lacks).
        """
        # 1. Clean up any existing observer to guarantee no memory leaks
        self.untrack_mouse_position()

        # 2. Define the native C++ callback
        def _on_mouse_move(caller, event):
            pos = caller.GetEventPosition()
            if pos and len(pos) >= 2:
                # Keep the native PyVista property updated
                self.mouse_position = pos

                # Safely bounce the coordinates to the Main UI Thread
                if callback:
                    safe_cb = self._wrap_threadsafe(callback)
                    safe_cb(pos)

        # 3. Attach directly to the raw C++ interactor
        if self.iren and hasattr(self.iren, "interactor"):
            self._mouse_move_observer = self.iren.interactor.AddObserver(
                "MouseMoveEvent", _on_mouse_move
            )

    @fbo_task(task_name="untrack_mouse_position")
    def untrack_mouse_position(self, **kwargs):
        """
        Custom QML override: Safely removes the mouse tracking observer.
        """
        if self._mouse_move_observer and self.iren and hasattr(self.iren, "interactor"):
            self.iren.interactor.RemoveObserver(self._mouse_move_observer)
            self._mouse_move_observer = None

    @fbo_task(task_name="disable")
    def disable(self):
        """Disables UI interaction (mouse/keyboard) with the 3D scene."""
        if self._fbo:
            self._fbo._interaction_enabled = False
        BasePlotter.disable(self)

    @fbo_task(task_name="enable")
    def enable(self):
        """Re-enables UI interaction (mouse/keyboard) with the 3D scene."""
        if self._fbo:
            self._fbo._interaction_enabled = True
        BasePlotter.enable(self)

    @fbo_task(task_name="screenshot")
    def screenshot(
            self,
            filename=None,
            transparent_background=False,
            **kwargs
    ):
        """
        Async Dispatch: Captures the screen via pure VTK on the Render Thread.
        Bypasses PyVista's windowing assumptions to prevent AttributeErrors in QML.

        Parameters
        ----------
        filename : str, optional
            The absolute path to save the screenshot to save the screenshot to a file.
        transparent_background : bool, optional
            Captures RGBA instead of RGB.
        """
        # 1. Handle deprecated arguments without crashing
        if "return_img" in kwargs or "window_size" in kwargs:
            logger.warning(
                "The 'return_img' and 'window_size' arguments are deprecated "
                "for async QML screenshots and are currently ignored."
            )

        if not filename:
            logger.warning("No filename provided to screenshot(). Aborting capture.")
            return None

        # 2. Force a fresh render so the buffer is up to date
        self.render_window.Render()

        # 3. Use raw VTK to scrape the pixels from our custom FBO Render Window
        w2i = vtk.vtkWindowToImageFilter()
        w2i.SetInput(self.render_window)
        w2i.SetScale(1)

        if transparent_background:
            w2i.SetInputBufferTypeToRGBA()
        else:
            w2i.SetInputBufferTypeToRGB()

        w2i.ReadFrontBufferOff()
        w2i.Update()

        # 4. Save directly to disk via pure C++ pipeline
        writer = vtk.vtkPNGWriter()
        writer.SetFileName(str(filename))
        writer.SetInputData(w2i.GetOutput())
        writer.Write()

        logger.debug(f"--- ASYNC SCREENSHOT SAVED TO: {filename} ---")

        return None

    @fbo_task(task_name="link_cameras")
    def link_cameras(self, group_interactors: list):
        """
        Links the cameras of the provided interactors to this one.
        Any movement in any interactor will automatically update all others.
        """
        # Guard against destroyed camera link targets
        if self._closed or getattr(self, "renderer", None) is None:
            return

        master_cam = self.renderer.camera
        # Unwrap the proxy to get the raw C++ vtkCamera
        native_cam = getattr(master_cam, "native", master_cam)

        # Assign the master camera pointer to the other renderers
        for interactor in group_interactors:
            if interactor._closed:
                continue
            if interactor != self and getattr(interactor, "renderer", None) is not None:
                interactor._dispatch_to_fbo(
                    lambda i=interactor, c=native_cam: setattr(
                        getattr(i.renderer, "native", i.renderer), "camera", c
                    ),
                    task_name="set_camera_link",
                )

        # Create a thread-safe callback that forces ALL FBOs to redraw
        def _sync_render(*args):
            for interactor in group_interactors:
                if interactor._closed:
                    continue
                if getattr(interactor, "renderer", None) is not None:
                    interactor._dispatch_to_fbo(
                        lambda o=interactor: o.render_window.Render(),
                        task_name="sync_render",
                    )
                    if getattr(interactor, "_fbo", None):
                        interactor._fbo.update()

        safe_cb = self._wrap_threadsafe(_sync_render)

        # Attach the observer directly to the native camera
        self._camera_link_observer = native_cam.AddObserver("ModifiedEvent", safe_cb)

    @fbo_task(task_name="unlink_cameras")
    def unlink_cameras(self, other_interactors: list):
        """
        Unlinks the cameras, giving each provided interactor its own independent camera
        cloned from the current view state.
        """
        # Guard against destroyed camera link targets
        if self._closed or getattr(self, "renderer", None) is None:
            return

        master_cam = self.renderer.camera
        native_cam = getattr(master_cam, "native", master_cam)

        # 1. Remove the observer if it exists
        if self._camera_link_observer:
            native_cam.RemoveObserver(self._camera_link_observer)
            self._camera_link_observer = None

        # 2. Give everyone else an independent copy of the current camera position
        for other in other_interactors:
            if other._closed:
                continue
            if other != self and getattr(other, "renderer", None) is not None:
                new_cam = Camera()
                new_cam.DeepCopy(native_cam)

                other._dispatch_to_fbo(
                    lambda o=other, c=new_cam: setattr(
                        getattr(o.renderer, "native", o.renderer), "camera", c
                    ),
                    task_name="set_camera_unlink",
                )

    # =========================================================================
    # DISPATCHERS & PATCHERS (The Core Engine)
    # =========================================================================
    def _is_safe_to_return_real_object(self) -> bool:
        """Determines if it is safe to return a raw C++ VTK object without a proxy.

        Returns
        -------
        bool
            True if executing safely inside the Render Thread, during bootup,
            or if synchronous mode is forced. False otherwise.
        """
        if self._force_sync_mode:
            return True
        if not self._initialized:
            return True

        return self._in_fbo_task or (self._fbo and self._fbo.in_render_loop)

    @contextlib.contextmanager
    def sync_mode(self) -> Generator[None, None, None]:
        """Temporarily disables asynchronous proxies for direct VTK access.

        This context manager allows direct, immediate, and synchronous access
        to native VTK/PyVista objects by temporarily bypassing the proxy routing engine.

        Yields
        ------
        None
        """
        original_state = self._force_sync_mode
        self._force_sync_mode = True
        try:
            yield
        finally:
            self._force_sync_mode = original_state

    def in_render_thread(self, task_name: str | None = None) -> Callable[..., Any]:
        """Decorator to dispatch an entire user function to the OpenGL Render Thread.

        This is a public utility for developers using the library, allowing them
        to safely execute complex, multi-step VTK modifications without triggering
        a segmentation fault from the Main UI Thread.

        Parameters
        ----------
        task_name : str | None, optional
            An optional explicit name for the task. Defaults to the function name.

        Returns
        -------
        Callable[..., Any]
            The decorated function, packaged for the FBO command queue.
        """

        def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
            @functools.wraps(func)
            def wrapper(*args: Any, **kwargs: Any) -> Any:
                name = task_name or func.__name__
                return self._dispatch_to_fbo(
                    lambda: func(*args, **kwargs), task_name=name
                )

            return wrapper

        return decorator

    @Slot()
    def _process_ui_queue(self) -> None:
        """Executes all pending UI tasks triggered by background VTK observers.

        Wakes up on the Main UI thread and sequentially pops and executes
        all lambda functions queued by `_wrap_threadsafe`.

        Returns
        -------
        None
        """
        while self._ui_queue:
            task = self._ui_queue.pop(0)
            try:
                task()
            except Exception as e:
                logger.error(f"Error executing UI task: {e}")

    def _patch_baseplotter_methods(self) -> None:
        """Dynamically generates proxy wrappers for all PyVista BasePlotter methods.

        Returns
        -------
        None

        Notes
        -----
        **The Metaprogramming Engine**
        To avoid manually rewriting every single method from PyVista's `BasePlotter`,
        this method iterates through the parent class at runtime. It intercepts
        methods and properties, replacing them with wrappers that automatically
        route arguments and return values through `_dispatch_call` and the proxy engine.

        To prevent massive closure-generation memory leaks, this patching is
        optimized to run exactly ONCE per application lifecycle on the class
        definition itself, rather than on individual instances.
        """
        # Prevent double-patching. If another interactor was already created
        # in this Python session, the class is already patched.
        if getattr(self.__class__, "_methods_patched", False):
            return

        for attr_name in dir(BasePlotter):
            # We skip private/protected methods (starting with '_') and any methods
            # we have explicitly overridden in QmlInteractor (like `close` or `clear`).
            if attr_name.startswith("_") or attr_name in self.__class__.__dict__:
                continue

            attr = getattr(BasePlotter, attr_name)

            # =================================================================
            # 1. FUNCTION / METHOD HANDLING
            # =================================================================
            if callable(attr):

                def make_wrapper(name: str) -> Callable[..., Any]:
                    # This is the interceptor. When the user calls `interactor.add_mesh()`,
                    # this function catches the call. Instead of running it instantly,
                    # it packages the method name and arguments and sends them to
                    # `_dispatch_call` to be routed to the Render Thread.
                    def wrapper(obj: Any, *args: Any, **kwargs: Any) -> Any:
                        return obj._dispatch_call(name, *args, **kwargs)

                    return wrapper

                # Attach the newly generated wrapper to the QmlInteractor class.
                setattr(self.__class__, attr_name, make_wrapper(attr_name))

            # =================================================================
            # 2. PROPERTY HANDLING
            # =================================================================
            elif isinstance(attr, property):

                def make_prop(name: str, orig_prop: property) -> property:

                    # --- The Getter Interceptor ---
                    def fget(obj: Any) -> Any:
                        # 1. Fetch the raw C++ object from PyVista
                        val = getattr(BasePlotter, name).__get__(obj)

                        # 2. If we are safely inside the GPU thread, return the raw object
                        if obj._is_safe_to_return_real_object():
                            return val

                        # 3. Otherwise, wrap the object in a Proxy to protect the Main Thread
                        return wrap_result(obj, val)

                    # --- The Setter Interceptor ---
                    fset = None
                    if hasattr(orig_prop, "fset") and orig_prop.fset:

                        def fset_wrapper(obj: Any, value: Any) -> None:
                            # BOOT AWARENESS: During `__init__`, PyVista sets initial properties.
                            # The OpenGL thread does not exist yet, so we must set them natively.
                            if not obj._initialized:
                                getattr(BasePlotter, name).__set__(obj, value)
                            # Normal operation: Route the setter to the Render Thread queue.
                            else:
                                obj._set_base_attr(name, value)

                        fset = fset_wrapper

                    # Reconstruct the property with our new intercepted getter and setter
                    return property(fget, fset)

                # Attach the newly generated property to the QmlInteractor class.
                setattr(self.__class__, attr_name, make_prop(attr_name, attr))

        # Flag the class as fully patched so future instances boot instantly
        setattr(self.__class__, "_methods_patched", True)

    def _wrap_threadsafe(self, func: Callable[..., Any]) -> Callable[..., Any]:
        """Wraps a Python callback to be safely executed on the Main UI Thread.

        This method is critical for VTK Observers. When VTK triggers an event
        (e.g., `ModifiedEvent`), it does so on the Render Thread. If the user's
        Python callback modifies the UI, it would crash. This wrapper intercepts
        the call, pushes it to a queue, and triggers a Qt signal to execute it
        on the Main Thread.

        Parameters
        ----------
        func : Callable[..., Any]
            The original Python function to be wrapped.

        Returns
        -------
        Callable[..., Any]
            A thread-safe wrapper function.

        Notes
        -----
        **Weak References**
        To prevent closures from trapping the `QmlInteractor` in memory during
        thread callbacks, this method uses `weakref.ref(self)`.

        **Signal Disconnection**
        Qt Signals are manually disconnected during teardown to sever the final
        links between the Python UI queue and the C++ Event Loop.
        """
        # Create a weak reference to 'self' so the closure doesn't trap it
        weak_self = weakref.ref(self)

        @functools.wraps(func)
        def _wrapper(*args: Any, **kwargs: Any) -> None:
            # Unpack the weak reference inside the callback execution
            interactor = weak_self()
            if not interactor:
                return  # If the interactor is destroyed, gracefully drop the event

            logger.debug(
                f"--- DEBUG: VTK triggered callback for {getattr(func, '__name__', str(func))} ---"
            )

            # 1. Append it to the Main Thread's execution queue with a delayed execution lambda
            interactor._ui_queue.append(lambda a=args, kw=kwargs: func(*a, **kw))

            # 2. Emit a Qt Signal. Qt Signals safely cross thread boundaries.
            # This wakes up the Main Thread and tells it to process the `_ui_queue`.
            interactor.sig_main_thread_call.emit()

        return _wrapper

    def _dispatch_to_fbo(
        self,
        task: Callable[..., Any],
        task_name: str | None = None,
        *args: Any,
        **kwargs: Any,
    ) -> Any:
        """Routes a task to be safely executed on the OpenGL Render Thread.

        This method acts as the core thread router, sending functions from the Main UI Thread
        to the FBO command queue for execution during the next OpenGL frame. It includes state
        awareness to prevent re-entrant deadlocks.

        Parameters
        ----------
        task : Callable[..., Any]
            The function or method to be executed on the Render Thread.
        task_name : str | None, optional
            An optional name for the task, used primarily for debugging and logging.
            If None, the `__name__` attribute of the task is used.
        *args : Any
            Positional arguments to pass to the `task`.
        **kwargs : Any
            Keyword arguments to pass to the `task`.

        Returns
        -------
        Any
            The result of the executed task if executed synchronously (e.g., already on the
            Render Thread or in sync mode), otherwise `None`.

        Notes
        -----
        **Thread Management (The QML / VTK Divide)**
        * **The Problem:** In QML, the UI logic (Main Thread) and the OpenGL rendering (Render Thread) are strictly separated. Modifying a VTK/PyVista object from the Main Thread while OpenGL is drawing it causes an immediate Segmentation Fault.
        * **The Solution (`QmlInteractor` & `Fbo`):** `QmlInteractor` acts as the bridge. It intercepts user commands on the Main Thread and pushes them to a thread-safe queue (`commandQueue` in `Fbo`).
        * **The Execution (`FboRenderer`):** The C++ Scene Graph wakes up the `FboRenderer` on the Render Thread. The renderer pops commands from the queue and executes them natively via `_dispatch_to_fbo` and `@fbo_task`.
        """
        import traceback

        name = task_name or (task.__name__ if hasattr(task, "__name__") else str(task))

        def _task(_unused_kwargs: Any = None) -> Any:
            logger.debug(f"QmlInteractor: task '{name}' execution starting")
            try:
                result = task(*args, **kwargs)
                logger.debug(f"QmlInteractor: task '{name}' execution finished")
                return result
            except Exception:
                # Catch and print internal VTK/PyVista errors so they don't silently kill the Render Thread!
                logger.error(
                    f"--- CRASH IN FBO TASK '{name}' ---\n{traceback.format_exc()}"
                )
                return None

        # Are we already executing inside the FBO rendering loop?
        is_in_fbo = self._in_fbo_task or (self._fbo and self._fbo.in_render_loop)

        # If we are already on the Render Thread, OR if the FBO doesn't exist (failed init),
        # execute instantly to prevent deadlocks and NoneType crashes.
        if is_in_fbo or not self._fbo or self._force_sync_mode:
            return _task()

        # If we are on the Main Thread, package it and send it to the FBO's command queue
        # to be processed on the very next OpenGL frame.
        else:

            def _task_wrapper(_unused_kwargs: Any = None) -> None:
                self._in_fbo_task = True
                try:
                    _task()
                finally:
                    self._in_fbo_task = False

            if self._fbo:
                self._fbo.addCommand(_task_wrapper)
            return None

    def _dispatch_call(self, method_name: str, *args: Any, **kwargs: Any) -> Any:
        """Generic async dispatcher for all PyVista BasePlotter methods.

        Intercepts arguments, protects callbacks, and routes the return values
        through the Proxy engine.

        Parameters
        ----------
        method_name : str
            The name of the `BasePlotter` method to call.
        *args : Any
            Positional arguments for the method.
        **kwargs : Any
            Keyword arguments for the method.

        Returns
        -------
        Any
            The result of the call, wrapped in a proxy if necessary.
        """

        def _is_callback(arg: Any) -> bool:
            """Safely detect true Python callbacks, ignoring VTK pipeline objects that happen to be callable."""
            if not callable(arg):
                return False
            mod_name = type(arg).__module__.split(".")[0]
            if mod_name in ["vtk", "vtkmodules", "pyvista"]:
                return False
            return True

        # 1. Scan arguments for user callbacks (e.g., `add_box_widget(callback=my_func)`)
        # If found, automatically wrap them so VTK doesn't crash the app when it triggers them.
        safe_args = tuple(
            self._wrap_threadsafe(arg) if _is_callback(arg) else arg for arg in args
        )
        safe_kwargs = {
            k: (self._wrap_threadsafe(v) if _is_callback(v) else v)
            for k, v in kwargs.items()
        }

        # 2. Create the task that actually calls the native PyVista method
        def _task() -> Any:
            method = getattr(BasePlotter, method_name)
            return method(self, *safe_args, **safe_kwargs)

        # 3. Dispatch to the OpenGL Render Thread
        result = self._dispatch_to_fbo(_task, task_name=method_name)

        # 4. If we are in a safe context (sync_mode or already on the Render Thread), return the raw C++ object
        if self._is_safe_to_return_real_object():
            return result

        # 5. Otherwise, automatically route the result through our Proxy engine!
        return wrap_result(self, result)

    @fbo_task(task_name="get_base_attr")
    def _get_base_attr(self, name: str) -> Any:
        """Thread-safe getter for BasePlotter attributes/properties.

        Parameters
        ----------
        name : str
            The attribute name.

        Returns
        -------
        Any
            The attribute value.
        """
        return getattr(BasePlotter, name).__get__(self)

    @fbo_task(task_name="set_base_attr")
    def _set_base_attr(self, name: str, value: Any) -> None:
        """Thread-safe setter for BasePlotter attributes/properties.

        Parameters
        ----------
        name : str
            The attribute name.
        value : Any
            The value to set.

        Returns
        -------
        None
        """
        getattr(BasePlotter, name).__set__(self, value)

    @fbo_task(task_name="add_threadsafe_observer")
    def add_threadsafe_observer(
        self, event: str, callback: Callable[..., Any], *args: Any, **kwargs: Any
    ) -> None:
        """Explicit wrapper to add a VTK observer that executes its callback safely on the UI thread.

        Parameters
        ----------
        event : str
            The VTK event name.
        callback : Callable[..., Any]
            The Python callback function.
        *args : Any
            Positional arguments for the observer.
        **kwargs : Any
            Keyword arguments for the observer.

        Returns
        -------
        None
        """
        # Wrapping the callback and adding the observer both happen safely on the Render Thread!
        safe_callback = self._wrap_threadsafe(callback)
        self.iren.add_observer(event, safe_callback, *args, **kwargs)
