#
#       pyvistaqml
#       Proxies for VTK and PyVista objects to ensure thread-safety.
#
#       Copyright © 2026 Inria
#       Author(s): Manuel Petit <manuel.petit@inria.fr>
#
#       This file is part of pyvistaqml.
#
#       pyvistaqml is free software: you can redistribute it and/or modify
#       it under the terms of the GNU Lesser General Public License as published by
#       the Free Software Foundation, either version 3 of the License, or
#       (at your option) any later version.
#
#       pyvistaqml is distributed in the hope that it will be useful,
#       but WITHOUT ANY WARRANTY; without even the implied warranty of
#       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#       GNU Lesser General Public License for more details.
#
#       You should have received a copy of the GNU Lesser General Public License
#       along with pyvistaqml.  If not, see <https://www.gnu.org/licenses/>.
#
# -----------------------------------------------------------------------

import weakref
from typing import Any, TYPE_CHECKING, Generator, Iterator
from pyvista.plotting.renderer import Renderer
from pyvista.plotting.renderers import Renderers

if TYPE_CHECKING:
    from .qmlInteractor import QmlInteractor


def _safe_weak_proxy(obj: Any) -> Any:
    """Ensures we don't try to weakref an object that is already a weakref proxy.

    Parameters
    ----------
    obj : Any
        The object to potentially wrap in a weakref proxy.

    Returns
    -------
    Any
        The object itself if already a proxy, otherwise a weakref proxy of the object.
    """
    if isinstance(obj, weakref.ProxyTypes):
        return obj
    return weakref.proxy(obj)


def wrap_result(plotter: "QmlInteractor", result: Any) -> Any:
    """Internal helper to wrap return values in the appropriate proxy.

    This function identifies the type of the `result` and wraps it in a
    thread-safe proxy if it's a VTK, PyVista, or collection object.

    Parameters
    ----------
    plotter : QmlInteractor
        The parent interactor responsible for dispatching tasks.
    result : Any
        The raw result from a VTK or PyVista operation.

    Returns
    -------
    Any
        The wrapped proxy object or the original result if no wrapping is needed.
    """
    if result is None or isinstance(
        result, (AsyncVtkProxy, AsyncDictProxy, AsyncListProxy)
    ):
        return result

    # 1. Intercept pyvista renderers and renderer
    if isinstance(result, Renderers):
        return AsyncRenderersProxy(plotter, result)
    if isinstance(result, Renderer):
        return AsyncRendererProxy(plotter, result)

    # 2. Standard Collections
    if isinstance(result, list):
        return AsyncListProxy(plotter, result)
    if isinstance(result, dict):
        return AsyncDictProxy(plotter, result)

    # 3. Generic VTK/PyVista objects
    mod_name = type(result).__module__.split(".")[0]
    if mod_name in ["vtk", "vtkmodules", "pyvista"]:
        return AsyncVtkProxy(plotter, result)

    return result


class AsyncVtkProxy:
    """A thread-safe proxy wrapper for native VTK and PyVista objects.

    This proxy intercepts attribute access and method calls to standard
    VTK/PyVista objects, packaging them into tasks that are safely dispatched
    to the OpenGL Render Thread.

    Parameters
    ----------
    plotter : QmlInteractor
        The parent interactor responsible for dispatching tasks to the FBO.
    real_obj : Any
        The underlying native C++ VTK or PyVista object being wrapped.

    Notes
    -----
    **The Proxy Pattern in QML**

    * **The Problem:** Because the Main UI Thread cannot safely modify VTK objects while the Render Thread is drawing them, the user rarely interacts with real VTK objects directly.
    * **The Solution:** Instead, they interact with `AsyncVtkProxy` objects. These proxies silently catch property changes (e.g., `actor.opacity = 0.5`) and method calls, packaging them into lambda functions. These functions are then routed through `_dispatch_to_fbo`, creating a seamless, synchronous developer experience on top of an asynchronous, multi-threaded architecture.
    * **Memory Management:** To prevent memory leaks, the proxy maintains a weak reference to the parent `plotter`.
    """

    def __init__(self, plotter: "QmlInteractor", real_obj: Any) -> None:
        object.__setattr__(self, "_plotter", _safe_weak_proxy(plotter))
        object.__setattr__(self, "_real_obj", real_obj)

    @property
    def native(self) -> Any:
        """Returns the underlying native C++ object.

        Returns
        -------
        Any
            The native VTK or PyVista object.
        """
        return self._real_obj

    def __getattr__(self, name: str) -> Any:
        attr = getattr(self._real_obj, name)

        if callable(attr):

            def wrapper(*args: Any, **kwargs: Any) -> Any:
                def _task() -> Any:
                    return attr(*args, **kwargs)

                res = self._plotter._dispatch_to_fbo(
                    _task, task_name=f"{type(self._real_obj).__name__}.{name}"
                )
                return wrap_result(self._plotter, res)

            return wrapper

        return wrap_result(self._plotter, attr)

    def __setattr__(self, name: str, value: Any) -> None:
        self._plotter._dispatch_to_fbo(
            lambda: setattr(self._real_obj, name, value), task_name=f"set_{name}"
        )

    def __repr__(self) -> str:
        return repr(self._real_obj)

    def __str__(self) -> str:
        return str(self._real_obj)

    def __len__(self) -> int:
        return len(self._real_obj)

    def __bool__(self) -> bool:
        return bool(self._real_obj)

    def __eq__(self, other: Any) -> bool:
        if isinstance(other, AsyncVtkProxy):
            return self._real_obj == other._real_obj
        return self._real_obj == other

    def __iter__(self) -> Generator[Any, None, None]:
        for item in self._real_obj:
            yield wrap_result(self._plotter, item)

    def __getitem__(self, key: Any) -> Any:
        return wrap_result(self._plotter, self._real_obj[key])


class AsyncDictProxy:
    """A thread-safe proxy wrapper for Python dictionaries containing VTK/PyVista objects.

    Parameters
    ----------
    plotter : QmlInteractor
        The parent interactor.
    real_dict : dict[Any, Any]
        The dictionary to wrap.
    """

    def __init__(self, plotter: "QmlInteractor", real_dict: dict[Any, Any]) -> None:
        object.__setattr__(self, "_plotter", _safe_weak_proxy(plotter))
        object.__setattr__(self, "_real_dict", real_dict)

    @property
    def native(self) -> dict[Any, Any]:
        """Returns the underlying native dictionary."""
        return self._real_dict

    def __getitem__(self, key: Any) -> Any:
        return wrap_result(self._plotter, self._real_dict[key])

    def get(self, key: Any, default: Any = None) -> Any:
        """Thread-safe get method for the dictionary."""
        return self[key] if key in self._real_dict else default

    def keys(self) -> Any:
        return self._real_dict.keys()

    def values(self) -> list[Any]:
        return [self[k] for k in self._real_dict.keys()]

    def items(self) -> list[tuple[Any, Any]]:
        return [(k, self[k]) for k in self._real_dict.keys()]

    def __contains__(self, key: Any) -> bool:
        return key in self._real_dict

    def __iter__(self) -> Iterator[Any]:
        return iter(self._real_dict)

    def __len__(self) -> int:
        return len(self._real_dict)

    def __getattr__(self, name: str) -> Any:
        attr = getattr(self._real_dict, name)
        if callable(attr):

            def wrapper(*args: Any, **kwargs: Any) -> Any:
                res = self._plotter._dispatch_to_fbo(
                    lambda: attr(*args, **kwargs), task_name=f"dict.{name}"
                )
                return wrap_result(self._plotter, res)

            return wrapper
        return wrap_result(self._plotter, attr)

    def __setattr__(self, name: str, value: Any) -> None:
        self._plotter._dispatch_to_fbo(
            lambda: setattr(self._real_dict, name, value), task_name=f"dict.set_{name}"
        )

    def __repr__(self) -> str:
        return repr(self._real_dict)

    def __str__(self) -> str:
        return str(self._real_dict)


class AsyncListProxy:
    """A thread-safe proxy wrapper for Python lists containing VTK/PyVista objects.

    Parameters
    ----------
    plotter : QmlInteractor
        The parent interactor.
    real_list : list[Any]
        The list to wrap.
    """

    def __init__(self, plotter: "QmlInteractor", real_list: list[Any]) -> None:
        object.__setattr__(self, "_plotter", _safe_weak_proxy(plotter))
        object.__setattr__(self, "_real_list", real_list)

    @property
    def native(self) -> list[Any]:
        """Returns the underlying native list."""
        return self._real_list

    def __getitem__(self, index: int | slice) -> Any:
        return wrap_result(self._plotter, self._real_list[index])

    def __iter__(self) -> Generator[Any, None, None]:
        for item in self._real_list:
            yield wrap_result(self._plotter, item)

    def __len__(self) -> int:
        return len(self._real_list)

    def __getattr__(self, name: str) -> Any:
        attr = getattr(self._real_list, name)
        if callable(attr):

            def wrapper(*args: Any, **kwargs: Any) -> Any:
                res = self._plotter._dispatch_to_fbo(
                    lambda: attr(*args, **kwargs), task_name=f"list.{name}"
                )
                return wrap_result(self._plotter, res)

            return wrapper
        return wrap_result(self._plotter, attr)

    def __setattr__(self, name: str, value: Any) -> None:
        self._plotter._dispatch_to_fbo(
            lambda: setattr(self._real_list, name, value), task_name=f"list.set_{name}"
        )

    def __repr__(self) -> str:
        return repr(self._real_list)

    def __str__(self) -> str:
        return str(self._real_list)


class AsyncRendererProxy(AsyncVtkProxy):
    """Specialized proxy for pyvista.Renderer."""

    @property
    def camera(self) -> Any:
        """Thread-safe access to the renderer's camera."""
        return wrap_result(self._plotter, self._real_obj.camera)

    @property
    def actors(self) -> Any:
        """Thread-safe access to the renderer's actors."""
        return wrap_result(self._plotter, self._real_obj.actors)

    @property
    def lights(self) -> Any:
        """Thread-safe access to the renderer's lights."""
        return wrap_result(self._plotter, self._real_obj.lights)

    def clear(self) -> Any:
        """Renderer-specific cleanup safely dispatched."""
        return self._plotter._dispatch_to_fbo(
            lambda: self._real_obj.clear(), task_name="renderer.clear"
        )


class AsyncRenderersProxy(AsyncListProxy):
    """Specialized proxy for pyvista.plotting.renderers.Renderers."""

    @property
    def active_renderer(self) -> Any:
        """Thread-safe access to the active renderer."""
        return wrap_result(self._plotter, self._real_list.active_renderer)

    def set_active_renderer(self, index: int) -> None:
        """Safely sets the active renderer by index."""
        self._plotter._dispatch_to_fbo(
            lambda: self._real_list.set_active_renderer(index),
            task_name="set_active_renderer",
        )
