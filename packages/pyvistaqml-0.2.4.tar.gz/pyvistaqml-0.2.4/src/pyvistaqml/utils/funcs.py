#
#       pyvistaqml
#       Global exception hook for unhandled exceptions.
#
#       Copyright © 2026 Inria
#       Author(s): Manuel Petit <manuel.petit@inria.fr>
#
#       This file is part of pyvistaqml.
#
#       pyvistaqml is free software: you can redistribute it and/or modify
#       it under the terms of the GNU Lesser General Public License as published by
#       the Free Software Foundation, either version 3 of the License, or
#       (at your option) any later version.
#
#       pyvistaqml is distributed in the hope that it will be useful,
#       but WITHOUT ANY WARRANTY; without even the implied warranty of
#       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#       GNU Lesser General Public License for more details.
#
#       You should have received a copy of the GNU Lesser General Public License
#       along with pyvistaqml.  If not, see <https://www.gnu.org/licenses/>.
#
# -----------------------------------------------------------------------

import sys
from typing import Any, Type

from PySide6.QtCore import QEvent, Qt
from PySide6.QtGui import QMouseEvent, QWheelEvent, QKeyEvent, QSurfaceFormat


def exceptHook(
    cls: Type[BaseException], exception: BaseException, traceback: Any
) -> None:
    """Global exception hook for unhandled exceptions.

    This method ensures that any uncaught exceptions are still passed to the
    default system excepthook, preventing them from being silently swallowed
    in certain Qt event loop configurations.

    Parameters
    ----------
    cls : Type[BaseException]
        The class of the exception.
    exception : BaseException
        The exception instance.
    traceback : Any
        The traceback object associated with the exception.

    Returns
    -------
    None
    """
    sys.__excepthook__(cls, exception, traceback)


def extractMouseData(
    event: QMouseEvent, forced_type: QEvent.Type | None = None
) -> dict[str, Any]:
    """Extracts Mouse or Hover events into a safe Python dictionary.

    This utility handles compatibility between different PySide6 versions to
    ensure mouse coordinates and button states are extracted consistently
    for transmission to the Render Thread.

    Parameters
    ----------
    event : QMouseEvent
        The Qt mouse event to extract data from.
    forced_type : QEvent.Type | None, optional
        An optional event type to override the one in the event object.
        Useful for mapping Hover events to MouseMove.

    Returns
    -------
    dict[str, Any]
        A dictionary containing 'is_mouse_event', 'type', 'position', 'button',
        and 'modifiers'.
    """
    # Compatibility check for coordinates
    pos = (
        event.position()
        if hasattr(event, "position")
        else (event.localPos() if hasattr(event, "localPos") else event.posF())
    )

    return {
        "is_mouse_event": True,
        "type": forced_type or event.type(),
        "position": pos,
        "button": event.button()
        if hasattr(event, "button")
        else Qt.MouseButton.NoButton,
        "modifiers": event.modifiers(),
    }


def extractWheelData(event: QWheelEvent) -> dict[str, Any]:
    """Extracts Wheel events into a safe Python dictionary.

    Parameters
    ----------
    event : QWheelEvent
        The Qt wheel event to extract data from.

    Returns
    -------
    dict[str, Any]
        A dictionary containing 'is_wheel_event', 'type', 'position', 'delta',
        and 'modifiers'.
    """
    pos = event.position() if hasattr(event, "position") else event.posF()

    return {
        "is_wheel_event": True,
        "type": event.type(),
        "position": pos,
        "delta": event.angleDelta().y() if hasattr(event, "angleDelta") else 0,
        "modifiers": event.modifiers(),
    }


def extractKeyData(event: QKeyEvent, event_type: str) -> dict[str, Any]:
    """Extracts Qt Key Event data into a thread-safe Python dictionary.

    Extracts key information for easy mapping to VTK keys in the Render Thread.

    Parameters
    ----------
    event : QKeyEvent
        The Qt key event to extract data from.
    event_type : str
        A string identifier for the event type (e.g., 'KeyPress', 'KeyRelease').

    Returns
    -------
    dict[str, Any]
        A dictionary containing 'is_key_event', 'type', 'key', 'text',
        and 'modifiers'.
    """
    return {
        "is_key_event": True,
        "type": event_type,
        "key": event.key(),
        "text": event.text(),
        "modifiers": event.modifiers(),
    }


def setup_opengl_format() -> None:
    """Forces Qt/QML to provision a modern OpenGL context for VTK/PyVista.

    Configures a modern OpenGL context tailored for VTK's advanced rendering
    pipelines. This MUST be called before creating the `QApplication`.

    Returns
    -------
    None

    Notes
    -----
    The configuration includes:
    1. Force OpenGL: PyVista requires pure OpenGL over Metal/Vulkan/DirectX.
    2. Version 4.1: Maximum supported version on macOS that supports modern VTK shaders.
    3. Core Profile: Disables legacy OpenGL features.
    4. Depth Buffer (24-bit): Prevents Z-fighting in 3D meshes.
    5. Stencil Buffer (8-bit): Used by VTK for 2D overlays and orientation axes.
    6. Alpha Buffer (8-bit): Enables transparency and volumetric rendering.
    """
    fmt = QSurfaceFormat()

    # 1. Force OpenGL: Newer versions of Qt try to use Metal (Mac) or Vulkan/DirectX (Windows)
    # by default. PyVista requires pure OpenGL.
    fmt.setRenderableType(QSurfaceFormat.OpenGL)

    # 2. Version 4.1: This is the "sweet spot". It supports all of VTK's modern shaders
    # (SSAO, physically based rendering), but 4.1 is also the absolute maximum version
    # of OpenGL that Apple macOS hardware supports.
    fmt.setVersion(4, 1)

    # 3. Core Profile: Tells the GPU to disable ancient, legacy OpenGL features
    # (like the fixed-function pipeline) and only use modern programmable shaders.
    fmt.setProfile(QSurfaceFormat.CoreProfile)

    # 4. Depth Buffer (24-bit): The Z-Buffer. This gives the GPU 16.7 million
    # "slices" of depth to figure out which objects are in front of each other.
    # Without this, 3D meshes will violently flicker through each other (Z-fighting).
    fmt.setDepthBufferSize(24)

    # 5. Stencil Buffer (8-bit): Used for masking. VTK heavily relies on this
    # to draw 2D overlays (like text, scalar bars, and orientation axes) cleanly
    # on top of the 3D scene without depth conflicts.
    fmt.setStencilBufferSize(8)

    # 6. Alpha Buffer (8-bit): Enables transparency. Required if you want the QML
    # UI to show through the background of your 3D viewport, and absolutely
    # required for Volumetric Rendering (Medical CT scans, smoke, etc.).
    fmt.setAlphaBufferSize(8)

    # Apply this format globally to all windows created by the application
    QSurfaceFormat.setDefaultFormat(fmt)
