#
#       pyvistaqml
#       Intercept unhandled exceptions.
#
#       Copyright © 2026 Inria
#       Author(s): Manuel Petit <manuel.petit@inria.fr>
#
#       This file is part of pyvistaqml.
#
#       pyvistaqml is free software: you can redistribute it and/or modify
#       it under the terms of the GNU Lesser General Public License as published by
#       the Free Software Foundation, either version 3 of the License, or
#       (at your option) any later version.
#
#       pyvistaqml is distributed in the hope that it will be useful,
#       but WITHOUT ANY WARRANTY; without even the implied warranty of
#       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#       GNU Lesser General Public License for more details.
#
#       You should have received a copy of the GNU Lesser General Public License
#       along with pyvistaqml.  If not, see <https://www.gnu.org/licenses/>.
#
# -----------------------------------------------------------------------

import logging


def exceptHook(errType, errMsg, errTraceback):
    """
    Intercepte les crashs (exceptions non gérées) et les redirige vers le système de log unifié.
    """
    # On récupère le logger racine de la librairie
    logger = logging.getLogger("pyvistaqml")

    # On enregistre une erreur critique en lui passant les infos de l'exception.
    # L'argument exc_info va automatiquement formater et extraire :
    # le type d'erreur, le message, le fichier, la ligne et le traceback complet !
    logger.critical(
        "Unhandled Exception detected!", exc_info=(errType, errMsg, errTraceback)
    )
