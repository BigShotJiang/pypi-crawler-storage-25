# contrecipe

> Procedural DNA curator for the Cont Hive.

`contrecipe` is the recipe **inspector, validator, compiler, and lifecycle keeper**
for the [Cont Hive](https://github.com/sertan/codent) air-gapped AI coding stack.
It does not chat with users and it does not solve tasks. It inspects, validates,
compiles, quarantines, and evolves recipes — the procedural memory of Cont.

## Identity

In the pDNA (Procedural DNA) philosophy, intelligence accumulates in **recipes**,
not in the model. A recipe is a small, atomic, deterministically verifiable
procedure. `contrecipe` is the gatekeeper for that procedural corpus:

```
Cont       → does the work (talks to user, calls tools)
Contmemo   → decides what enters memory (scribe + archivist)
Contrecipe → decides what enters the procedure corpus (master + compiler)
```

A recipe is **valid** only if:
- every step is atomic
- every tool exists in the live registry
- every input is bound
- every output is named
- every validation point returns a deterministic bool
- no LLM judgment is used as truth

## Install

```bash
pip install contrecipe
```

Standalone, zero cloud, zero server, zero internet.

## CLI

```bash
contrecipe --version
contrecipe inspect <path-to-recipes>     # corpus statistics + phantom-tool scan
contrecipe validate <recipe.yaml>        # canonical schema check
contrecipe compile  <recipe.yaml>        # source → executable plan (dry run)
contrecipe test     <recipe.yaml>        # golden test
contrecipe watch    <proposals-dir>      # background daemon (proposal inbox)
contrecipe quarantine list               # quarantine status
```

## Status

Pre-alpha. See `CHANGELOG.md` for sprint progress.

## License

MIT
