# v1 | 2026-05-03 | Sprint R4 — compiler tests
"""R4 compiler tests.

Coverage:
  - validator pre-pass gate (invalid/contaminated → CompileError)
  - desugar (defaults applied)
  - step ID assignment (s001, s002, …)
  - symbol table (output → step_id)
  - reference resolution (${name} → ${sNNN})
  - forward reference rejection
  - duplicate output rejection
  - source dict immutability (compiler must not mutate caller's input)
  - JSON round-trip
  - CLI integration
"""

from __future__ import annotations

import copy
import json
from pathlib import Path

import pytest

from contrecipe.cli import main as cli_main
from contrecipe.core import compiler
from contrecipe.core._registry import StaticRegistry
from contrecipe.core.compiler import (
    CompileError,
    EXIT_BAD_PATH,
    EXIT_COMPILE_ERROR,
    EXIT_OK,
    PLAN_SCHEMA_VERSION,
    compile_file,
    compile_recipe,
)

FIXTURE_ROOT = Path(__file__).parent / "fixtures" / "recipes_synthetic"

PROD_LIKE_REGISTRY = StaticRegistry.of({
    "run_shell", "list_dir", "read_file", "system_search", "duckdb_query",
})


def _minimal_valid() -> dict:
    return {
        "id": "ok",
        "version": 1,
        "triggers": ["t"],
        "steps": [
            {
                "worker": "run_shell",
                "params": {"command": "echo ok"},
                "verify": {"method": "exit_code", "expected": 0},
                "output": "r1",
            }
        ],
    }


# ---------------------------------------------------------------------------
# Validator pre-pass
# ---------------------------------------------------------------------------

def test_invalid_recipe_blocks_compile():
    raw = _minimal_valid()
    raw.pop("triggers")
    with pytest.raises(CompileError) as exc_info:
        compile_recipe(raw, registry=PROD_LIKE_REGISTRY)
    err = exc_info.value
    assert err.validation is not None
    assert err.validation.verdict == "invalid"


def test_contaminated_recipe_blocks_compile():
    raw = _minimal_valid()
    raw["steps"][0]["worker"] = "find_file"
    with pytest.raises(CompileError) as exc_info:
        compile_recipe(raw, registry=PROD_LIKE_REGISTRY)
    err = exc_info.value
    assert err.validation.verdict == "contaminated"


def test_skip_validation_compiles_minimal():
    """Tightly-scoped escape hatch; not for production."""
    raw = _minimal_valid()
    plan = compile_recipe(raw, skip_validation=True)
    assert plan.recipe_id == "ok"


# ---------------------------------------------------------------------------
# Plan shape
# ---------------------------------------------------------------------------

def test_compile_minimal_yields_well_formed_plan():
    plan = compile_recipe(_minimal_valid(), registry=PROD_LIKE_REGISTRY)
    assert plan.plan_schema_version == PLAN_SCHEMA_VERSION
    assert plan.recipe_id == "ok"
    assert plan.recipe_version == 1
    assert plan.triggers == ("t",)
    assert len(plan.steps) == 1
    assert plan.steps[0].id == "s001"


def test_step_ids_are_position_stable_and_padded():
    raw = _minimal_valid()
    raw["steps"] = [
        {
            "worker": "run_shell",
            "params": {"command": f"echo {i}"},
            "verify": {"method": "exit_code", "expected": 0},
            "output": f"r{i}",
        }
        for i in range(1, 4)
    ]
    plan = compile_recipe(raw, registry=PROD_LIKE_REGISTRY)
    assert [s.id for s in plan.steps] == ["s001", "s002", "s003"]


def test_symbol_table_maps_output_to_step_id():
    raw = _minimal_valid()
    raw["steps"] = [
        {"worker": "run_shell", "params": {"command": "a"},
         "verify": {"method": "exit_code", "expected": 0}, "output": "alpha"},
        {"worker": "run_shell", "params": {"command": "b"},
         "verify": {"method": "exit_code", "expected": 0}, "output": "beta"},
    ]
    plan = compile_recipe(raw, registry=PROD_LIKE_REGISTRY)
    assert plan.symbol_table == {"alpha": "s001", "beta": "s002"}


# ---------------------------------------------------------------------------
# Desugar — defaults filled at compile time
# ---------------------------------------------------------------------------

def test_desugar_fills_step_defaults():
    plan = compile_recipe(_minimal_valid(), registry=PROD_LIKE_REGISTRY)
    s = plan.steps[0]
    assert s.on_fail == "abort"     # default
    assert s.retries == 0           # default


def test_desugar_preserves_explicit_step_values():
    raw = _minimal_valid()
    raw["steps"][0]["on_fail"] = "retry"
    raw["steps"][0]["retries"] = 3
    plan = compile_recipe(raw, registry=PROD_LIKE_REGISTRY)
    assert plan.steps[0].on_fail == "retry"
    assert plan.steps[0].retries == 3


def test_desugar_fills_recipe_metadata_defaults():
    plan = compile_recipe(_minimal_valid(), registry=PROD_LIKE_REGISTRY)
    # author / lifecycle defaults captured in metadata
    assert plan.metadata.get("author") == "cont"
    assert plan.metadata.get("lifecycle") == "candidate"


# ---------------------------------------------------------------------------
# Reference resolution
# ---------------------------------------------------------------------------

def test_reference_rewritten_to_step_id():
    raw = {
        "id": "ref_chain",
        "version": 1,
        "triggers": ["x"],
        "steps": [
            {
                "worker": "system_search",
                "params": {"pattern": "config.toml"},
                "verify": {"method": "not_empty"},
                "output": "matches",
            },
            {
                "worker": "read_file",
                "params": {"path": "${matches}"},
                "verify": {"method": "not_empty"},
                "output": "contents",
            },
        ],
    }
    plan = compile_recipe(raw, registry=PROD_LIKE_REGISTRY)
    assert plan.steps[1].params["path"] == "${s001}"


def test_reference_resolution_walks_nested_structures():
    raw = _minimal_valid()
    raw["steps"][0]["output"] = "first"
    raw["steps"].append({
        "worker": "run_shell",
        "params": {
            "command": "process",
            "env": {"INPUT": "${first}", "OTHER": "literal"},
            "tags": ["${first}", "static"],
        },
        "verify": {"method": "exit_code", "expected": 0},
        "output": "second",
    })
    plan = compile_recipe(raw, registry=PROD_LIKE_REGISTRY)
    s2 = plan.steps[1]
    assert s2.params["env"]["INPUT"] == "${s001}"
    assert s2.params["env"]["OTHER"] == "literal"
    assert s2.params["tags"] == ["${s001}", "static"]


def test_unresolved_reference_is_compile_error():
    raw = _minimal_valid()
    raw["steps"][0]["params"]["command"] = "echo ${nonexistent}"
    with pytest.raises(CompileError) as exc_info:
        compile_recipe(raw, registry=PROD_LIKE_REGISTRY)
    assert "unresolved reference" in exc_info.value.message
    assert "nonexistent" in exc_info.value.message


def test_forward_reference_is_compile_error():
    raw = _minimal_valid()
    # First step references the SECOND step's output.
    raw["steps"][0]["params"]["command"] = "echo ${later}"
    raw["steps"].append({
        "worker": "run_shell",
        "params": {"command": "echo later"},
        "verify": {"method": "exit_code", "expected": 0},
        "output": "later",
    })
    with pytest.raises(CompileError) as exc_info:
        compile_recipe(raw, registry=PROD_LIKE_REGISTRY)
    assert "forward reference" in exc_info.value.message


def test_self_reference_is_forward_reference_error():
    raw = _minimal_valid()
    raw["steps"][0]["output"] = "self"
    raw["steps"][0]["params"]["command"] = "echo ${self}"
    with pytest.raises(CompileError) as exc_info:
        compile_recipe(raw, registry=PROD_LIKE_REGISTRY)
    # Step 1's output 'self' is not yet 'available' when params are resolved
    assert "forward reference" in exc_info.value.message


# ---------------------------------------------------------------------------
# Duplicate-output guard
# ---------------------------------------------------------------------------

def test_duplicate_output_is_compile_error():
    raw = _minimal_valid()
    raw["steps"].append({
        "worker": "run_shell",
        "params": {"command": "again"},
        "verify": {"method": "exit_code", "expected": 0},
        "output": "r1",  # duplicate of first step
    })
    with pytest.raises(CompileError) as exc_info:
        compile_recipe(raw, registry=PROD_LIKE_REGISTRY)
    assert "duplicate output" in exc_info.value.message


# ---------------------------------------------------------------------------
# Caller's input must not be mutated
# ---------------------------------------------------------------------------

def test_compiler_does_not_mutate_input_dict():
    raw = _minimal_valid()
    snapshot = copy.deepcopy(raw)
    compile_recipe(raw, registry=PROD_LIKE_REGISTRY)
    assert raw == snapshot, "compiler must not mutate caller's input"


def test_compiler_does_not_mutate_input_when_resolving_references():
    raw = _minimal_valid()
    raw["steps"][0]["output"] = "first"
    raw["steps"].append({
        "worker": "run_shell",
        "params": {"command": "echo ${first}"},
        "verify": {"method": "exit_code", "expected": 0},
        "output": "second",
    })
    snapshot = copy.deepcopy(raw)
    compile_recipe(raw, registry=PROD_LIKE_REGISTRY)
    assert raw == snapshot


# ---------------------------------------------------------------------------
# JSON serialisation
# ---------------------------------------------------------------------------

def test_to_json_round_trip_via_dict():
    plan = compile_recipe(_minimal_valid(), registry=PROD_LIKE_REGISTRY)
    payload = json.loads(plan.to_json())
    assert payload["plan_schema_version"] == PLAN_SCHEMA_VERSION
    assert payload["recipe_id"] == "ok"
    assert payload["steps"][0]["id"] == "s001"
    assert payload["symbol_table"]["r1"] == "s001"


def test_render_text_includes_steps_and_symbols():
    plan = compile_recipe(_minimal_valid(), registry=PROD_LIKE_REGISTRY)
    text = compiler.render_text(plan)
    assert "symbol table" in text
    assert "s001" in text
    assert "r1" in text


# ---------------------------------------------------------------------------
# File-level + fixture integration
# ---------------------------------------------------------------------------

def test_compile_canonical_valid_fixture():
    plan = compile_file(
        FIXTURE_ROOT / "canonical_valid.yaml",
        registry=PROD_LIKE_REGISTRY,
    )
    assert plan.recipe_id == "canonical_valid"
    assert len(plan.steps) == 1


def test_compile_with_references_fixture_resolves_correctly():
    plan = compile_file(
        FIXTURE_ROOT / "with_references.yaml",
        registry=PROD_LIKE_REGISTRY,
    )
    # First step's output 'matches' lives at s001; second step's path uses ${s001}
    assert plan.symbol_table == {"matches": "s001", "contents": "s002"}
    assert plan.steps[1].params["path"] == "${s001}"


def test_compile_invalid_fixture_raises():
    with pytest.raises(CompileError):
        compile_file(
            FIXTURE_ROOT / "invalid_no_id.yaml",
            registry=PROD_LIKE_REGISTRY,
        )


def test_compile_contaminated_fixture_raises():
    with pytest.raises(CompileError):
        compile_file(
            FIXTURE_ROOT / "contaminated_find_file.yaml",
            registry=PROD_LIKE_REGISTRY,
        )


def test_compile_file_bad_path():
    with pytest.raises(FileNotFoundError):
        compile_file(Path("/no/such/recipe.yaml"))


# ---------------------------------------------------------------------------
# CLI integration
# ---------------------------------------------------------------------------

def test_cli_compile_canonical_valid_returns_zero(capsys):
    rc = cli_main(["compile", str(FIXTURE_ROOT / "canonical_valid.yaml")])
    out = capsys.readouterr().out
    assert rc == EXIT_OK
    assert "s001" in out


def test_cli_compile_invalid_returns_one(capsys):
    rc = cli_main(["compile", str(FIXTURE_ROOT / "invalid_no_id.yaml")])
    err = capsys.readouterr().err
    assert rc == EXIT_COMPILE_ERROR
    assert "compile failed" in err


def test_cli_compile_contaminated_returns_one(capsys):
    rc = cli_main(["compile", str(FIXTURE_ROOT / "contaminated_find_file.yaml")])
    err = capsys.readouterr().err
    assert rc == EXIT_COMPILE_ERROR
    # Validator findings are surfaced under the compile error
    assert "R102" in err or "forbidden" in err


def test_cli_compile_bad_path_returns_three(capsys):
    rc = cli_main(["compile", "/no/such/recipe.yaml"])
    err = capsys.readouterr().err
    assert rc == EXIT_BAD_PATH
    assert "does not exist" in err


def test_cli_compile_json_flag(capsys):
    rc = cli_main([
        "compile",
        str(FIXTURE_ROOT / "canonical_valid.yaml"),
        "--json",
    ])
    out = capsys.readouterr().out
    assert rc == EXIT_OK
    payload = json.loads(out)
    assert payload["recipe_id"] == "canonical_valid"
    assert payload["plan_schema_version"] == PLAN_SCHEMA_VERSION


def test_cli_compile_with_registry_flag(tmp_path, capsys):
    reg = tmp_path / "reg.json"
    reg.write_text(json.dumps({"workers": ["run_shell"]}))
    rc = cli_main([
        "compile",
        str(FIXTURE_ROOT / "canonical_valid.yaml"),
        "--registry",
        str(reg),
    ])
    assert rc == EXIT_OK
