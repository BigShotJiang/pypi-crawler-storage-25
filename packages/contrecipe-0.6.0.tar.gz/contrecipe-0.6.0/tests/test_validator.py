# v1 | 2026-05-03 | Sprint R3 — validator tests
"""R3 validator tests.

Strategy:
  1. Per-rule unit tests on minimal raw mappings — fast feedback per code.
  2. File-level tests against real fixtures from R2's synthetic corpus
     and the R3-specific fixtures (canonical_valid, invalid_no_id, ...).
  3. Verdict ordering: contaminated > invalid > valid.
  4. Registry behaviour: introspective vs not.
  5. CLI end-to-end with --json and --registry.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from contrecipe.cli import main as cli_main
from contrecipe.core import validator
from contrecipe.core._registry import (
    EmptyRegistry,
    JsonFileRegistry,
    StaticRegistry,
)
from contrecipe.core.validator import (
    EXIT_BAD_PATH,
    EXIT_CONTAMINATED,
    EXIT_INVALID,
    EXIT_VALID,
    SEVERITY_ERROR,
    SEVERITY_INFO,
    VERDICT_CONTAMINATED,
    VERDICT_INVALID,
    VERDICT_VALID,
    Finding,
    validate_file,
    validate_recipe,
)

FIXTURE_ROOT = Path(__file__).parent / "fixtures" / "recipes_synthetic"

# A registry that knows the workers used in clean fixtures.
PROD_LIKE_REGISTRY = StaticRegistry.of({
    "run_shell", "list_dir", "read_file", "system_search", "duckdb_query",
})


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _minimal_valid() -> dict:
    """Minimal recipe dict that validates green under the prod-like registry."""
    return {
        "id": "ok",
        "version": 1,
        "triggers": ["t"],
        "steps": [
            {
                "worker": "run_shell",
                "params": {"command": "echo ok"},
                "verify": {"method": "exit_code", "expected": 0},
                "output": "r1",
            }
        ],
    }


def _codes(result) -> set[str]:
    return {f.code for f in result.findings}


# ---------------------------------------------------------------------------
# Verdict logic
# ---------------------------------------------------------------------------

def test_minimal_valid_under_prod_registry():
    res = validate_recipe(_minimal_valid(), registry=PROD_LIKE_REGISTRY)
    assert res.verdict == VERDICT_VALID
    assert res.errors == ()


def test_empty_registry_emits_info_but_still_valid():
    res = validate_recipe(_minimal_valid(), registry=EmptyRegistry())
    assert res.verdict == VERDICT_VALID
    info = [f for f in res.findings if f.severity == SEVERITY_INFO]
    assert any(f.code == "R900" for f in info)


def test_no_registry_arg_is_treated_as_empty():
    res = validate_recipe(_minimal_valid())
    assert res.verdict == VERDICT_VALID
    assert any(f.code == "R900" for f in res.findings)


def test_contamination_beats_invalid_verdict():
    """Even if other errors exist, presence of forbidden_worker → contaminated."""
    raw = _minimal_valid()
    raw["steps"][0]["worker"] = "find_file"   # forbidden
    raw.pop("triggers")                       # also broken
    res = validate_recipe(raw, registry=PROD_LIKE_REGISTRY)
    assert res.verdict == VERDICT_CONTAMINATED
    assert "R102" in _codes(res)


def test_invalid_when_only_schema_errors():
    raw = _minimal_valid()
    raw.pop("triggers")
    res = validate_recipe(raw, registry=PROD_LIKE_REGISTRY)
    assert res.verdict == VERDICT_INVALID


# ---------------------------------------------------------------------------
# Recipe-level rules (R001–R006)
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("missing", ["id", "version", "triggers", "steps"])
def test_R001_missing_required_recipe_field(missing):
    raw = _minimal_valid()
    raw.pop(missing)
    res = validate_recipe(raw, registry=PROD_LIKE_REGISTRY)
    assert "R001" in _codes(res)


def test_R002_id_must_be_nonempty_string():
    raw = _minimal_valid()
    raw["id"] = ""
    res = validate_recipe(raw, registry=PROD_LIKE_REGISTRY)
    assert "R002" in _codes(res)


def test_R003_version_must_be_positive_int():
    raw = _minimal_valid()
    raw["version"] = 0
    res = validate_recipe(raw, registry=PROD_LIKE_REGISTRY)
    assert "R003" in _codes(res)


def test_R003_version_bool_rejected():
    """Python bool is technically int; we explicitly reject it."""
    raw = _minimal_valid()
    raw["version"] = True
    res = validate_recipe(raw, registry=PROD_LIKE_REGISTRY)
    assert "R003" in _codes(res)


def test_R004_triggers_empty_list():
    raw = _minimal_valid()
    raw["triggers"] = []
    res = validate_recipe(raw, registry=PROD_LIKE_REGISTRY)
    assert "R004" in _codes(res)


def test_R004_triggers_with_non_string():
    raw = _minimal_valid()
    raw["triggers"] = ["valid", 42]
    res = validate_recipe(raw, registry=PROD_LIKE_REGISTRY)
    assert "R004" in _codes(res)


def test_R005_steps_not_a_list():
    raw = _minimal_valid()
    raw["steps"] = "not a list"
    res = validate_recipe(raw, registry=PROD_LIKE_REGISTRY)
    assert "R005" in _codes(res)


def test_R006_recipe_uses_field_rejected():
    raw = _minimal_valid()
    raw["uses"] = ["primitive_x"]
    res = validate_recipe(raw, registry=PROD_LIKE_REGISTRY)
    assert "R006" in _codes(res)


# ---------------------------------------------------------------------------
# Step-level rules (R100–R111)
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("missing", ["worker", "params", "verify", "output"])
def test_R100_missing_required_step_field(missing):
    raw = _minimal_valid()
    raw["steps"][0].pop(missing)
    res = validate_recipe(raw, registry=PROD_LIKE_REGISTRY)
    assert "R100" in _codes(res)


def test_R101_worker_not_a_string():
    raw = _minimal_valid()
    raw["steps"][0]["worker"] = 42
    res = validate_recipe(raw, registry=PROD_LIKE_REGISTRY)
    assert "R101" in _codes(res)


def test_R102_forbidden_worker_marks_contaminated():
    raw = _minimal_valid()
    raw["steps"][0]["worker"] = "report_failure"
    res = validate_recipe(raw, registry=PROD_LIKE_REGISTRY)
    assert "R102" in _codes(res)
    assert res.is_contaminated


def test_R103_unknown_worker_only_under_introspective_registry():
    raw = _minimal_valid()
    raw["steps"][0]["worker"] = "totally_made_up_tool"
    # Empty registry: no R103 error
    res_empty = validate_recipe(raw, registry=EmptyRegistry())
    assert "R103" not in _codes(res_empty)
    # Static registry that doesn't include it: R103 fires
    res_strict = validate_recipe(raw, registry=PROD_LIKE_REGISTRY)
    assert "R103" in _codes(res_strict)


def test_R104_params_not_a_mapping():
    raw = _minimal_valid()
    raw["steps"][0]["params"] = "string instead of mapping"
    res = validate_recipe(raw, registry=PROD_LIKE_REGISTRY)
    assert "R104" in _codes(res)


def test_R105_verify_not_a_mapping():
    raw = _minimal_valid()
    raw["steps"][0]["verify"] = "not a dict"
    res = validate_recipe(raw, registry=PROD_LIKE_REGISTRY)
    assert "R105" in _codes(res)


def test_R106_verify_method_missing():
    raw = _minimal_valid()
    raw["steps"][0]["verify"] = {"expected": 0}
    res = validate_recipe(raw, registry=PROD_LIKE_REGISTRY)
    assert "R106" in _codes(res)


def test_R107_verify_method_unknown():
    raw = _minimal_valid()
    raw["steps"][0]["verify"] = {"method": "output_eq", "expected": "x"}
    res = validate_recipe(raw, registry=PROD_LIKE_REGISTRY)
    assert "R107" in _codes(res)


def test_R108_output_empty_string():
    raw = _minimal_valid()
    raw["steps"][0]["output"] = ""
    res = validate_recipe(raw, registry=PROD_LIKE_REGISTRY)
    assert "R108" in _codes(res)


def test_R109_on_fail_invalid_value():
    raw = _minimal_valid()
    raw["steps"][0]["on_fail"] = "explode"
    res = validate_recipe(raw, registry=PROD_LIKE_REGISTRY)
    assert "R109" in _codes(res)


def test_R109_on_fail_valid_values_accepted():
    for ok in ("abort", "continue", "retry"):
        raw = _minimal_valid()
        raw["steps"][0]["on_fail"] = ok
        res = validate_recipe(raw, registry=PROD_LIKE_REGISTRY)
        assert "R109" not in _codes(res)


def test_R110_retries_negative():
    raw = _minimal_valid()
    raw["steps"][0]["retries"] = -1
    res = validate_recipe(raw, registry=PROD_LIKE_REGISTRY)
    assert "R110" in _codes(res)


def test_R111_step_uses_field_rejected():
    raw = _minimal_valid()
    raw["steps"][0]["uses"] = "primitive_x"
    res = validate_recipe(raw, registry=PROD_LIKE_REGISTRY)
    assert "R111" in _codes(res)


# ---------------------------------------------------------------------------
# Drift rules (R200–R201) — audit signal
# ---------------------------------------------------------------------------

def test_R200_legacy_action_field_detected():
    raw = _minimal_valid()
    step = raw["steps"][0]
    # Replace canonical names with legacy ones
    step.pop("worker")
    step.pop("params")
    step["action"] = "run_shell"
    step["args"] = {"command": "echo hi"}
    res = validate_recipe(raw, registry=PROD_LIKE_REGISTRY)
    assert "R200" in _codes(res)
    assert "R201" in _codes(res)


# ---------------------------------------------------------------------------
# File-level integration
# ---------------------------------------------------------------------------

def test_canonical_valid_fixture_passes(tmp_path):
    res = validate_file(
        FIXTURE_ROOT / "canonical_valid.yaml",
        registry=PROD_LIKE_REGISTRY,
    )
    assert res.is_valid


def test_invalid_no_id_fixture_fails():
    res = validate_file(
        FIXTURE_ROOT / "invalid_no_id.yaml",
        registry=PROD_LIKE_REGISTRY,
    )
    assert res.verdict == VERDICT_INVALID
    assert "R001" in _codes(res)


def test_invalid_bad_on_fail_fixture_fails():
    res = validate_file(
        FIXTURE_ROOT / "invalid_bad_on_fail.yaml",
        registry=PROD_LIKE_REGISTRY,
    )
    assert res.verdict == VERDICT_INVALID
    assert "R109" in _codes(res)


def test_contaminated_fixtures_marked_contaminated():
    for name in ("contaminated_find_file.yaml", "contaminated_report_failure.yaml"):
        res = validate_file(FIXTURE_ROOT / name, registry=PROD_LIKE_REGISTRY)
        assert res.is_contaminated, f"{name} should be contaminated"
        assert "R102" in _codes(res)


def test_drift_legacy_fixture_invalid():
    res = validate_file(
        FIXTURE_ROOT / "drift_legacy_action.yaml",
        registry=PROD_LIKE_REGISTRY,
    )
    assert res.verdict == VERDICT_INVALID
    assert "R200" in _codes(res)
    assert "R201" in _codes(res)


def test_validate_file_bad_path():
    with pytest.raises(FileNotFoundError):
        validate_file(Path("/no/such/file.yaml"))


def test_validate_file_directory_rejected(tmp_path):
    with pytest.raises(IsADirectoryError):
        validate_file(tmp_path)


def test_validate_file_yaml_parse_error_returns_invalid():
    res = validate_file(
        FIXTURE_ROOT / "broken_yaml.yaml",
        registry=PROD_LIKE_REGISTRY,
    )
    assert res.verdict == VERDICT_INVALID
    assert any(f.code == "R000" for f in res.findings)


# ---------------------------------------------------------------------------
# Renderers
# ---------------------------------------------------------------------------

def test_render_text_includes_verdict():
    res = validate_recipe(_minimal_valid(), registry=PROD_LIKE_REGISTRY)
    text = validator.render_text(res)
    assert "VALID" in text


def test_render_json_round_trip():
    raw = _minimal_valid()
    raw["steps"][0]["worker"] = "find_file"
    res = validate_recipe(raw, registry=PROD_LIKE_REGISTRY)
    payload = json.loads(validator.render_json(res))
    assert payload["verdict"] == "contaminated"
    codes = [f["code"] for f in payload["findings"]]
    assert "R102" in codes


# ---------------------------------------------------------------------------
# Registry: JsonFileRegistry
# ---------------------------------------------------------------------------

def test_json_file_registry_simple_list(tmp_path):
    p = tmp_path / "reg.json"
    p.write_text(json.dumps({"workers": ["run_shell", "list_dir"]}))
    reg = JsonFileRegistry(p)
    assert reg.is_known("run_shell")
    assert not reg.is_known("nope")
    assert reg.known_workers() == frozenset({"run_shell", "list_dir"})


def test_json_file_registry_rich_mapping(tmp_path):
    p = tmp_path / "reg.json"
    p.write_text(json.dumps({"workers": {
        "run_shell": {"params": ["command"]},
        "read_file": {"params": ["path"]},
    }}))
    reg = JsonFileRegistry(p)
    assert reg.is_known("read_file")
    assert reg.known_workers() == frozenset({"run_shell", "read_file"})


def test_json_file_registry_missing_file(tmp_path):
    reg = JsonFileRegistry(tmp_path / "absent.json")
    with pytest.raises(FileNotFoundError):
        reg.is_known("anything")


def test_json_file_registry_bad_shape(tmp_path):
    p = tmp_path / "reg.json"
    p.write_text(json.dumps({"not_workers": []}))
    reg = JsonFileRegistry(p)
    with pytest.raises(ValueError):
        reg.is_known("anything")


# ---------------------------------------------------------------------------
# CLI integration
# ---------------------------------------------------------------------------

def test_cli_validate_canonical_valid_returns_zero(capsys):
    rc = cli_main(["validate", str(FIXTURE_ROOT / "canonical_valid.yaml")])
    out = capsys.readouterr().out
    assert rc == EXIT_VALID
    assert "VALID" in out


def test_cli_validate_invalid_returns_one(capsys):
    rc = cli_main(["validate", str(FIXTURE_ROOT / "invalid_no_id.yaml")])
    out = capsys.readouterr().out
    assert rc == EXIT_INVALID
    assert "INVALID" in out


def test_cli_validate_contaminated_returns_two(capsys):
    rc = cli_main(["validate", str(FIXTURE_ROOT / "contaminated_find_file.yaml")])
    out = capsys.readouterr().out
    assert rc == EXIT_CONTAMINATED
    assert "CONTAMINATED" in out


def test_cli_validate_bad_path_returns_three(capsys):
    rc = cli_main(["validate", "/no/such/recipe.yaml"])
    err = capsys.readouterr().err
    assert rc == EXIT_BAD_PATH
    assert "does not exist" in err


def test_cli_validate_json_flag(capsys):
    rc = cli_main([
        "validate",
        str(FIXTURE_ROOT / "canonical_valid.yaml"),
        "--json",
    ])
    out = capsys.readouterr().out
    assert rc == EXIT_VALID
    payload = json.loads(out)
    assert payload["verdict"] == "valid"


def test_cli_validate_with_registry_flag(tmp_path, capsys):
    reg_path = tmp_path / "reg.json"
    reg_path.write_text(json.dumps({"workers": ["run_shell"]}))

    rc = cli_main([
        "validate",
        str(FIXTURE_ROOT / "canonical_valid.yaml"),
        "--registry",
        str(reg_path),
    ])
    out = capsys.readouterr().out
    assert rc == EXIT_VALID
    # With introspective registry, the R900 info should NOT appear
    assert "R900" not in out


def test_cli_validate_with_missing_registry_file(tmp_path, capsys):
    rc = cli_main([
        "validate",
        str(FIXTURE_ROOT / "canonical_valid.yaml"),
        "--registry",
        str(tmp_path / "no_such_registry.json"),
    ])
    err = capsys.readouterr().err
    assert rc == EXIT_BAD_PATH
    assert "no_such_registry.json" in err or "No such file" in err
