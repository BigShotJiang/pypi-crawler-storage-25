# v2 | 2026-05-03 | Sprint R3 — counts derived from PARSEABLE_FIXTURES (fixture-growth-resilient)
"""R2 inspector tests.

These exercise the inspector against a small synthetic corpus
(`tests/fixtures/recipes_synthetic`) covering: healthy, contaminated,
edge, drift, and parse-error cases. The inspector is read-only, so all
tests assert filesystem invariance as part of the contract.

Calibration against Sertan's real 182-recipe corpus happens at the end
of R3 (validator), where the same fixtures are reused.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from contrecipe.cli import main as cli_main
from contrecipe.core import inspector

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

FIXTURE_ROOT = Path(__file__).parent / "fixtures" / "recipes_synthetic"

# Files we expect to parse successfully.
# As fixtures are added in later sprints, append to this set.
PARSEABLE_FIXTURES = {
    "healthy_simple.yaml",
    "healthy_multistep.yaml",
    "contaminated_find_file.yaml",
    "contaminated_report_failure.yaml",
    "edge_no_verify.yaml",
    "edge_unknown_verify.yaml",
    "drift_legacy_action.yaml",
    # R3 additions (validator):
    "canonical_valid.yaml",
    "invalid_no_id.yaml",
    "invalid_bad_on_fail.yaml",
    # R4 additions (compiler):
    "with_references.yaml",
}

# Files we expect to land in parse_errors.
UNPARSEABLE_FIXTURES = {
    "broken_yaml.yaml",
    "wrong_shape.yaml",
}


@pytest.fixture()
def inv():
    return inspector.read_corpus(FIXTURE_ROOT)


@pytest.fixture()
def report(inv):
    return inspector.build_report(inv)


# ---------------------------------------------------------------------------
# Read-only contract
# ---------------------------------------------------------------------------

def test_read_corpus_does_not_mutate_filesystem():
    before = sorted(FIXTURE_ROOT.iterdir())
    before_sizes = {p.name: p.stat().st_size for p in before}
    inspector.read_corpus(FIXTURE_ROOT)
    after = sorted(FIXTURE_ROOT.iterdir())
    after_sizes = {p.name: p.stat().st_size for p in after}
    assert before == after
    assert before_sizes == after_sizes


def test_build_report_does_not_mutate_filesystem(inv):
    before = sorted(FIXTURE_ROOT.iterdir())
    inspector.build_report(inv)
    after = sorted(FIXTURE_ROOT.iterdir())
    assert before == after


# ---------------------------------------------------------------------------
# Inventory shape
# ---------------------------------------------------------------------------

def test_inventory_partitions_parseable_and_errors(inv):
    parsed_names = {r.path.name for r in inv.recipes}
    error_names = {e.path.name for e in inv.parse_errors}
    assert parsed_names == PARSEABLE_FIXTURES
    assert error_names == UNPARSEABLE_FIXTURES
    # No overlap, no leak
    assert parsed_names.isdisjoint(error_names)


def test_inventory_has_iso_scanned_at(inv):
    # Cheap sanity: looks like an ISO 8601 string with a Z or +00:00
    assert "T" in inv.scanned_at
    assert inv.scanned_at[-6:] in {"+00:00"} or inv.scanned_at.endswith("Z")


def test_inventory_root_is_resolved(inv):
    assert inv.root == FIXTURE_ROOT.resolve()


def test_total_counts(inv):
    # Counts derived from PARSEABLE_FIXTURES so the test stays correct
    # as fixtures are appended in later sprints.
    assert inv.total_recipes == len(PARSEABLE_FIXTURES)
    # Step count is sensitive to fixture content; use a lower bound that
    # captures what every healthy/contaminated fixture must contribute.
    # Each parseable fixture has at least one step.
    assert inv.total_steps >= len(PARSEABLE_FIXTURES)


def test_bad_root_raises():
    with pytest.raises(FileNotFoundError):
        inspector.read_corpus(Path("/no/such/place/abc/xyz/123"))


def test_bad_root_not_a_dir(tmp_path):
    f = tmp_path / "single.yaml"
    f.write_text("id: foo\n")
    with pytest.raises(NotADirectoryError):
        inspector.read_corpus(f)


# ---------------------------------------------------------------------------
# Phantom worker detection (canonical purpose of inspector)
# ---------------------------------------------------------------------------

def test_phantom_workers_flagged(report):
    # Both forbidden workers used in fixtures should appear.
    assert "find_file" in report.phantom_workers
    assert "report_failure" in report.phantom_workers


def test_phantom_workers_carry_recipe_paths(report):
    paths = report.phantom_workers["find_file"]
    assert any(p.name == "contaminated_find_file.yaml" for p in paths)


def test_clean_workers_not_flagged(report):
    # `run_shell`, `list_dir`, `read_file` are common, never forbidden.
    for w in ("run_shell", "list_dir", "read_file"):
        assert w not in report.phantom_workers


def test_has_issues_when_phantoms_or_parse_errors(report):
    # Our fixture set contains both → must be True.
    assert report.has_issues is True


# ---------------------------------------------------------------------------
# Verify method bucketing
# ---------------------------------------------------------------------------

def test_known_verify_methods_counted(report):
    # exit_code appears in: healthy_multistep ×2, drift_legacy ×1 → ≥3
    assert report.verify_methods.get("exit_code", 0) >= 3
    # not_empty in: healthy_simple, find_file, report_failure → ≥3
    assert report.verify_methods.get("not_empty", 0) >= 3


def test_unknown_verify_method_bucketed(report):
    # edge_unknown_verify uses `output_eq`, not in canonical set
    assert report.verify_methods.get("(unknown)", 0) >= 1


def test_absent_verify_bucketed(report):
    # edge_no_verify has a step with no verify field
    assert report.verify_methods.get("(absent)", 0) >= 1


# ---------------------------------------------------------------------------
# Drift signals
# ---------------------------------------------------------------------------

def test_drift_legacy_action_field_detected(report):
    # drift_legacy_action.yaml uses `action:` instead of `worker:`
    assert report.drift_signals.get("action_field_used_at_step_level", 0) >= 1
    assert report.drift_signals.get("args_field_used_at_step_level", 0) >= 1


# ---------------------------------------------------------------------------
# on_fail distribution surfacing the audit finding
# ---------------------------------------------------------------------------

def test_on_fail_distribution_includes_absent_and_present(report):
    # In our fixtures: some steps have on_fail, some don't.
    assert "(absent)" in report.on_fail_distribution
    assert "abort" in report.on_fail_distribution


# ---------------------------------------------------------------------------
# Lifecycle bucketing
# ---------------------------------------------------------------------------

def test_lifecycle_distribution(report):
    # Derive expected counts from the fixtures themselves so the test
    # stays correct as fixtures are appended in later sprints.
    import yaml as _yaml
    expected: dict[str, int] = {}
    for name in PARSEABLE_FIXTURES:
        data = _yaml.safe_load((FIXTURE_ROOT / name).read_text())
        lc = data.get("lifecycle") if isinstance(data, dict) else None
        if isinstance(lc, str):
            expected[lc] = expected.get(lc, 0) + 1
    for state, n in expected.items():
        assert report.lifecycle_distribution.get(state, 0) == n, (
            f"lifecycle '{state}' expected {n}, got "
            f"{report.lifecycle_distribution.get(state, 0)}"
        )


# ---------------------------------------------------------------------------
# Renderers
# ---------------------------------------------------------------------------

def test_render_text_contains_required_sections(report):
    text = inspector.render_text(report)
    for section in (
        "corpus root",
        "recipes",
        "steps",
        "recipe-level field presence",
        "step-level field presence",
        "verify methods",
        "workers",
        "on_fail distribution",
        "phantom / forbidden workers",
        "schema-drift signals",
    ):
        assert section in text, f"missing section: {section!r}"


def test_render_text_lists_phantom_paths(report):
    text = inspector.render_text(report)
    assert "find_file" in text
    assert "contaminated_find_file.yaml" in text


def test_render_json_is_parseable_and_complete(report):
    payload = json.loads(inspector.render_json(report))
    assert payload["schema_version"] == 1
    assert "totals" in payload
    assert payload["totals"]["recipes"] == len(PARSEABLE_FIXTURES)
    assert payload["totals"]["parse_errors"] == len(UNPARSEABLE_FIXTURES)
    assert "find_file" in payload["phantom_workers"]


# ---------------------------------------------------------------------------
# CLI integration (end-to-end through `contrecipe inspect`)
# ---------------------------------------------------------------------------

def test_cli_inspect_returns_nonzero_when_issues_present(capsys):
    rc = cli_main(["inspect", str(FIXTURE_ROOT)])
    out = capsys.readouterr().out
    # Has parse errors AND phantom workers → exit 1
    assert rc == inspector.EXIT_INSPECT_ISSUES_FOUND
    assert "phantom" in out.lower() or "forbidden" in out.lower()


def test_cli_inspect_json_flag_emits_json(capsys):
    rc = cli_main(["inspect", str(FIXTURE_ROOT), "--json"])
    out = capsys.readouterr().out
    assert rc == inspector.EXIT_INSPECT_ISSUES_FOUND
    payload = json.loads(out)
    assert payload["totals"]["recipes"] == len(PARSEABLE_FIXTURES)


def test_cli_inspect_clean_corpus_returns_zero(tmp_path, capsys):
    # Build a tiny clean corpus: just one healthy recipe, no phantoms.
    clean = tmp_path / "recipes"
    clean.mkdir()
    (clean / "healthy.yaml").write_text(
        "id: r\n"
        "version: 1\n"
        "triggers: ['x']\n"
        "steps:\n"
        "  - worker: run_shell\n"
        "    params: {command: 'echo hi'}\n"
        "    verify: {method: exit_code, expected: 0}\n"
        "    output: r1\n"
        "    on_fail: abort\n"
    )
    rc = cli_main(["inspect", str(clean)])
    assert rc == inspector.EXIT_OK


def test_cli_inspect_bad_path(capsys):
    rc = cli_main(["inspect", "/no/such/place/zzz"])
    assert rc == inspector.EXIT_INSPECT_BAD_PATH
    err = capsys.readouterr().err
    assert "does not exist" in err
