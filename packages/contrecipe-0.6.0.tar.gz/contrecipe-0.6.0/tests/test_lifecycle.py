# v1 | 2026-05-03 | Sprint R5 — lifecycle FSM tests
"""R5 lifecycle FSM tests.

The schema is the source of truth for legal states and transitions.
These tests verify that `lifecycle.py` reflects the schema accurately
and that its public API behaves predictably for every input shape.
"""

from __future__ import annotations

import pytest

from contrecipe.core import lifecycle as lc


# --------------------------------------------------------------------------
# Schema reflection
# --------------------------------------------------------------------------

def test_known_states_match_brief():
    expected = {
        "candidate", "validated", "active",
        "quarantine", "archived", "poisoned",
    }
    assert lc.known_states() == frozenset(expected)


def test_allowed_transitions_match_brief():
    """The brief commits to a small, decidable transition set."""
    expected = {
        ("candidate", "validated"),
        ("candidate", "poisoned"),
        ("validated", "active"),
        ("validated", "quarantine"),
        ("active", "quarantine"),
        ("quarantine", "active"),
        ("quarantine", "archived"),
        ("active", "archived"),
    }
    assert lc.allowed_transitions() == frozenset(expected)


# --------------------------------------------------------------------------
# is_known_state
# --------------------------------------------------------------------------

@pytest.mark.parametrize("s", [
    "candidate", "validated", "active", "quarantine", "archived", "poisoned",
])
def test_is_known_state_true_for_canonical(s):
    assert lc.is_known_state(s)


@pytest.mark.parametrize("s", ["", "draft", "ACTIVE", "deleted", "unknown"])
def test_is_known_state_false_for_others(s):
    assert not lc.is_known_state(s)


# --------------------------------------------------------------------------
# is_allowed
# --------------------------------------------------------------------------

def test_active_to_quarantine_allowed():
    assert lc.is_allowed("active", "quarantine")


def test_quarantine_to_active_allowed_for_restoration():
    assert lc.is_allowed("quarantine", "active")


def test_archived_is_terminal():
    """No transitions leave 'archived'."""
    assert lc.successors_of("archived") == frozenset()


def test_poisoned_is_terminal():
    """No transitions leave 'poisoned'."""
    assert lc.successors_of("poisoned") == frozenset()


def test_active_to_validated_not_allowed():
    """Going backwards from active to validated is not part of the FSM."""
    assert not lc.is_allowed("active", "validated")


def test_quarantine_to_validated_not_allowed():
    """Restoration goes back to active, not validated."""
    assert not lc.is_allowed("quarantine", "validated")


# --------------------------------------------------------------------------
# assert_transition
# --------------------------------------------------------------------------

def test_assert_transition_passes_for_legal():
    lc.assert_transition("active", "quarantine")  # no raise


def test_assert_transition_raises_illegal():
    with pytest.raises(lc.IllegalTransition):
        lc.assert_transition("active", "validated")


def test_assert_transition_raises_unknown_state():
    with pytest.raises(lc.UnknownState):
        lc.assert_transition("frozen", "active")


# --------------------------------------------------------------------------
# successors_of
# --------------------------------------------------------------------------

def test_successors_of_active():
    assert lc.successors_of("active") == frozenset({"quarantine", "archived"})


def test_successors_of_quarantine():
    assert lc.successors_of("quarantine") == frozenset({"active", "archived"})


def test_successors_of_unknown_raises():
    with pytest.raises(lc.UnknownState):
        lc.successors_of("not-a-state")
