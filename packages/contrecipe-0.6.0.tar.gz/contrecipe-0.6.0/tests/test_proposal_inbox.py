# v1 | 2026-05-03 | Sprint R6 — proposal inbox tests
"""R6 proposal inbox tests.

Coverage:
  - layout creation (idempotent)
  - drain_once: empty inbox is a no-op
  - drain_once: accepted path (valid + compilable)
  - drain_once: rejected path (validator says invalid)
  - drain_once: rejected path (validator says contaminated)
  - drain_once: rejected path (compile-only failure: duplicate output)
  - drain_once: malformed path (yaml parse error)
  - drain_once: malformed path (top-level not a mapping)
  - reclaim: leftover in processing/ from a prior crash is re-driven
  - back-pressure: max_proposals bounds work per cycle
  - idempotency: running drain_once twice is safe (no double-route)
  - registry passthrough: --registry rejects unknown workers
  - event log: per-proposal entries, journal integrity
  - CLI: --once mode (text and --json)
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from contrecipe.cli import main as cli_main
from contrecipe.core import event_log, proposal_inbox as pi
from contrecipe.core._registry import StaticRegistry
from contrecipe.core.proposal_inbox import (
    ALL_SUBDIRS,
    DIR_ACCEPTED,
    DIR_MALFORMED,
    DIR_NEW,
    DIR_PROCESSED,
    DIR_PROCESSING,
    DIR_REJECTED,
    EXIT_BAD_PATH,
    EXIT_OK,
    OP_ACCEPT,
    OP_MALFORMED,
    OP_RECLAIMED,
    OP_REJECT,
    InboxError,
    drain_once,
    ensure_layout,
)


PROD_LIKE_REGISTRY = StaticRegistry.of({
    "run_shell", "list_dir", "read_file", "system_search",
})


# ---------------------------------------------------------------------------
# Helpers — recipe text builders
# ---------------------------------------------------------------------------

def _valid_recipe(rid: str = "ok") -> str:
    return (
        f"id: {rid}\n"
        "version: 1\n"
        "triggers: ['x']\n"
        "steps:\n"
        "  - worker: run_shell\n"
        "    params: {command: 'echo ok'}\n"
        "    verify: {method: exit_code, expected: 0}\n"
        "    output: r1\n"
    )


def _invalid_recipe_no_id() -> str:
    return (
        "version: 1\n"
        "triggers: ['x']\n"
        "steps:\n"
        "  - worker: run_shell\n"
        "    params: {command: 'echo'}\n"
        "    verify: {method: exit_code, expected: 0}\n"
        "    output: r1\n"
    )


def _contaminated_recipe(rid: str) -> str:
    return (
        f"id: {rid}\n"
        "version: 1\n"
        "triggers: ['x']\n"
        "steps:\n"
        "  - worker: find_file\n"
        "    params: {pattern: '*'}\n"
        "    verify: {method: not_empty}\n"
        "    output: r1\n"
    )


def _duplicate_output_recipe(rid: str = "dup") -> str:
    """Validates clean but the compiler rejects (duplicate output names)."""
    return (
        f"id: {rid}\n"
        "version: 1\n"
        "triggers: ['x']\n"
        "steps:\n"
        "  - worker: run_shell\n"
        "    params: {command: 'echo a'}\n"
        "    verify: {method: exit_code, expected: 0}\n"
        "    output: r1\n"
        "  - worker: run_shell\n"
        "    params: {command: 'echo b'}\n"
        "    verify: {method: exit_code, expected: 0}\n"
        "    output: r1\n"
    )


def _drop(inbox: Path, name: str, body: str, *, sub: str = DIR_NEW) -> Path:
    p = inbox / sub / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(body, encoding="utf-8")
    return p


# ---------------------------------------------------------------------------
# Layout
# ---------------------------------------------------------------------------

def test_ensure_layout_creates_all_subdirs(tmp_path):
    inbox = tmp_path / "inbox"
    ensure_layout(inbox)
    for sub in ALL_SUBDIRS:
        assert (inbox / sub).is_dir()


def test_ensure_layout_is_idempotent(tmp_path):
    inbox = tmp_path / "inbox"
    ensure_layout(inbox)
    ensure_layout(inbox)
    for sub in ALL_SUBDIRS:
        assert (inbox / sub).is_dir()


def test_ensure_layout_refuses_when_root_is_a_file(tmp_path):
    f = tmp_path / "not_a_dir"
    f.write_text("hi")
    with pytest.raises(InboxError, match="not a directory"):
        ensure_layout(f)


# ---------------------------------------------------------------------------
# drain_once — empty inbox
# ---------------------------------------------------------------------------

def test_drain_once_empty(tmp_path):
    inbox = tmp_path / "inbox"
    ensure_layout(inbox)
    rep = drain_once(inbox, registry=PROD_LIKE_REGISTRY)
    assert rep.total == 0
    assert rep.reclaimed == ()


# ---------------------------------------------------------------------------
# drain_once — accept path
# ---------------------------------------------------------------------------

def test_drain_once_accepts_valid_recipe(tmp_path):
    inbox = tmp_path / "inbox"
    ensure_layout(inbox)
    _drop(inbox, "good.yaml", _valid_recipe("good"))

    rep = drain_once(inbox, registry=PROD_LIKE_REGISTRY)

    assert len(rep.accepted) == 1
    o = rep.accepted[0]
    assert o.proposal_name == "good.yaml"
    assert o.outcome == "accepted"
    # Routed correctly
    assert (inbox / DIR_ACCEPTED / "good.yaml").exists()
    # Durable copy
    assert (inbox / DIR_PROCESSED / "good.yaml").exists()
    # Cleared from new/ and processing/
    assert not (inbox / DIR_NEW / "good.yaml").exists()
    assert not (inbox / DIR_PROCESSING / "good.yaml").exists()


def test_drain_once_accepted_journal_entry(tmp_path):
    inbox = tmp_path / "inbox"
    ensure_layout(inbox)
    log = tmp_path / "events.jsonl"
    _drop(inbox, "good.yaml", _valid_recipe("good"))

    drain_once(inbox, registry=PROD_LIKE_REGISTRY, event_log_path=log)

    events = event_log.read_events(log)
    assert any(e["op"] == OP_ACCEPT and e["proposal"] == "good.yaml"
               for e in events)


# ---------------------------------------------------------------------------
# drain_once — reject paths
# ---------------------------------------------------------------------------

def test_drain_once_rejects_invalid_recipe(tmp_path):
    inbox = tmp_path / "inbox"
    ensure_layout(inbox)
    log = tmp_path / "events.jsonl"
    _drop(inbox, "bad.yaml", _invalid_recipe_no_id())

    rep = drain_once(inbox, registry=PROD_LIKE_REGISTRY, event_log_path=log)

    assert len(rep.rejected) == 1
    assert (inbox / DIR_REJECTED / "bad.yaml").exists()
    assert not (inbox / DIR_ACCEPTED / "bad.yaml").exists()
    events = event_log.read_events(log)
    rejects = [e for e in events if e["op"] == OP_REJECT]
    assert rejects
    assert rejects[0]["reason"] == "validator_invalid"
    assert "R001" in rejects[0]["detail"]


def test_drain_once_rejects_contaminated_recipe(tmp_path):
    inbox = tmp_path / "inbox"
    ensure_layout(inbox)
    log = tmp_path / "events.jsonl"
    _drop(inbox, "evil.yaml", _contaminated_recipe("evil"))

    rep = drain_once(inbox, registry=PROD_LIKE_REGISTRY, event_log_path=log)

    assert len(rep.rejected) == 1
    events = event_log.read_events(log)
    e = next(e for e in events if e["op"] == OP_REJECT)
    assert e["reason"] == "validator_contaminated"
    assert "R102" in e["detail"]


def test_drain_once_rejects_compile_only_failure(tmp_path):
    """Validates clean but compiler refuses (duplicate output)."""
    inbox = tmp_path / "inbox"
    ensure_layout(inbox)
    log = tmp_path / "events.jsonl"
    _drop(inbox, "dup.yaml", _duplicate_output_recipe("dup"))

    rep = drain_once(inbox, registry=PROD_LIKE_REGISTRY, event_log_path=log)

    assert len(rep.rejected) == 1
    events = event_log.read_events(log)
    rejects = [e for e in events if e["op"] == OP_REJECT]
    assert any(e["reason"] == "compiler_error" for e in rejects)


# ---------------------------------------------------------------------------
# drain_once — malformed paths
# ---------------------------------------------------------------------------

def test_drain_once_routes_malformed_yaml(tmp_path):
    inbox = tmp_path / "inbox"
    ensure_layout(inbox)
    log = tmp_path / "events.jsonl"
    _drop(inbox, "broken.yaml", "id: [unclosed\nsteps:\n  - worker\n")

    rep = drain_once(inbox, registry=PROD_LIKE_REGISTRY, event_log_path=log)

    assert len(rep.malformed) == 1
    assert (inbox / DIR_MALFORMED / "broken.yaml").exists()
    events = event_log.read_events(log)
    e = next(e for e in events if e["op"] == OP_MALFORMED)
    assert e["reason"] == "yaml_parse_error"


def test_drain_once_routes_non_mapping_top_level(tmp_path):
    inbox = tmp_path / "inbox"
    ensure_layout(inbox)
    _drop(inbox, "list.yaml", "- a\n- b\n")

    rep = drain_once(inbox, registry=PROD_LIKE_REGISTRY)
    assert len(rep.malformed) == 1


# ---------------------------------------------------------------------------
# Reclaim from a prior crash
# ---------------------------------------------------------------------------

def test_drain_once_reclaims_leftover_processing(tmp_path):
    inbox = tmp_path / "inbox"
    ensure_layout(inbox)
    log = tmp_path / "events.jsonl"
    # Simulate a crash: file already in processing/ at startup
    _drop(inbox, "leftover.yaml", _valid_recipe("leftover"), sub=DIR_PROCESSING)

    rep = drain_once(inbox, registry=PROD_LIKE_REGISTRY, event_log_path=log)

    assert "leftover.yaml" in rep.reclaimed
    assert len(rep.accepted) == 1
    # The processing/ entry was driven through and cleared
    assert not (inbox / DIR_PROCESSING / "leftover.yaml").exists()
    events = event_log.read_events(log)
    assert any(e["op"] == OP_RECLAIMED for e in events)
    assert any(e["op"] == OP_ACCEPT for e in events)


# ---------------------------------------------------------------------------
# Back-pressure
# ---------------------------------------------------------------------------

def test_max_proposals_caps_work_per_cycle(tmp_path):
    inbox = tmp_path / "inbox"
    ensure_layout(inbox)
    for i in range(5):
        _drop(inbox, f"r{i}.yaml", _valid_recipe(f"r{i}"))

    rep = drain_once(inbox, registry=PROD_LIKE_REGISTRY, max_proposals=3)
    assert len(rep.accepted) == 3
    # Two leftovers still in new/
    assert sorted(p.name for p in (inbox / DIR_NEW).iterdir()) == ["r3.yaml", "r4.yaml"]


# ---------------------------------------------------------------------------
# Idempotency
# ---------------------------------------------------------------------------

def test_two_consecutive_drains_clear_inbox(tmp_path):
    inbox = tmp_path / "inbox"
    ensure_layout(inbox)
    for i in range(3):
        _drop(inbox, f"r{i}.yaml", _valid_recipe(f"r{i}"))

    drain_once(inbox, registry=PROD_LIKE_REGISTRY)
    rep2 = drain_once(inbox, registry=PROD_LIKE_REGISTRY)

    assert rep2.total == 0
    assert sorted(p.name for p in (inbox / DIR_ACCEPTED).iterdir()) == [
        "r0.yaml", "r1.yaml", "r2.yaml",
    ]


def test_drain_does_not_mutate_already_routed_recipes(tmp_path):
    inbox = tmp_path / "inbox"
    ensure_layout(inbox)
    _drop(inbox, "good.yaml", _valid_recipe("good"))
    drain_once(inbox, registry=PROD_LIKE_REGISTRY)
    accepted = inbox / DIR_ACCEPTED / "good.yaml"
    sha_before = accepted.read_bytes()
    drain_once(inbox, registry=PROD_LIKE_REGISTRY)
    assert accepted.read_bytes() == sha_before


# ---------------------------------------------------------------------------
# Registry passthrough
# ---------------------------------------------------------------------------

def test_registry_passthrough_rejects_unknown_worker(tmp_path):
    """A recipe using a worker not in the registry should be rejected."""
    inbox = tmp_path / "inbox"
    ensure_layout(inbox)
    # `read_file` is in PROD_LIKE_REGISTRY; the strict registry below isn't.
    strict = StaticRegistry.of({"run_shell"})
    body = _valid_recipe("solo").replace("run_shell", "read_file")
    _drop(inbox, "solo.yaml", body)

    rep = drain_once(inbox, registry=strict)
    assert len(rep.rejected) == 1


# ---------------------------------------------------------------------------
# CLI integration
# ---------------------------------------------------------------------------

def test_cli_watch_once_text(tmp_path, capsys):
    inbox = tmp_path / "inbox"
    ensure_layout(inbox)
    _drop(inbox, "good.yaml", _valid_recipe("good"))
    _drop(inbox, "bad.yaml", _invalid_recipe_no_id())

    rc = cli_main(["watch", str(inbox), "--once"])
    out = capsys.readouterr().out
    assert rc == EXIT_OK
    assert "accepted  : 1" in out
    assert "rejected  : 1" in out


def test_cli_watch_once_json(tmp_path, capsys):
    inbox = tmp_path / "inbox"
    ensure_layout(inbox)
    _drop(inbox, "good.yaml", _valid_recipe("good"))

    rc = cli_main(["watch", str(inbox), "--once", "--json"])
    out = capsys.readouterr().out
    assert rc == EXIT_OK
    payload = json.loads(out)
    assert payload["totals"]["accepted"] == 1


def test_cli_watch_bad_path(tmp_path, capsys):
    rc = cli_main(["watch", str(tmp_path / "no_such_inbox"), "--once"])
    err = capsys.readouterr().err
    assert rc == EXIT_BAD_PATH
    assert "does not exist" in err


def test_cli_watch_with_event_log(tmp_path, capsys):
    inbox = tmp_path / "inbox"
    ensure_layout(inbox)
    log = tmp_path / "events.jsonl"
    _drop(inbox, "good.yaml", _valid_recipe("good"))

    rc = cli_main([
        "watch", str(inbox), "--once",
        "--event-log", str(log),
    ])
    assert rc == EXIT_OK
    events = event_log.read_events(log)
    assert any(e["op"] == OP_ACCEPT for e in events)


def test_cli_watch_with_registry(tmp_path, capsys):
    """End-to-end: --registry reaches the validator inside drain_once."""
    inbox = tmp_path / "inbox"
    ensure_layout(inbox)
    reg = tmp_path / "reg.json"
    reg.write_text(json.dumps({"workers": ["run_shell"]}))
    # Recipe uses 'system_search', not in the dump → reject
    _drop(inbox, "needs_search.yaml",
          _valid_recipe("needs_search").replace("run_shell", "system_search"))

    rc = cli_main([
        "watch", str(inbox), "--once",
        "--registry", str(reg),
    ])
    assert rc == EXIT_OK
    capsys.readouterr()
    # Verify routing
    assert (inbox / DIR_REJECTED / "needs_search.yaml").exists()


# ---------------------------------------------------------------------------
# watch() loop — bounded by max_cycles for tests
# ---------------------------------------------------------------------------

def test_watch_loop_drains_then_exits_on_max_cycles(tmp_path):
    inbox = tmp_path / "inbox"
    ensure_layout(inbox)
    _drop(inbox, "good.yaml", _valid_recipe("good"))

    # Tight interval, two cycles. First cycle drains, second finds nothing.
    rc = pi.watch(
        inbox,
        registry=PROD_LIKE_REGISTRY,
        poll_interval_seconds=0.01,
        max_proposals_per_cycle=4,
        max_cycles=2,
    )
    assert rc == EXIT_OK
    assert (inbox / DIR_ACCEPTED / "good.yaml").exists()
