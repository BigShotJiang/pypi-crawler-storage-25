# v1 | 2026-05-03 | Sprint R5 — quarantine + event_log tests
"""R5 quarantine, restore, archive, and event log tests.

Coverage:
  - quarantine: move + sidecar + journal entry
  - quarantine: collision rejection (idempotency boundary)
  - quarantine: cleanup on rename failure (no orphaned sidecar)
  - quarantine: bytes-preserving (sha256 of recipe unchanged)
  - quarantine: lifecycle gate (illegal prior_lifecycle blocks the move)
  - list_quarantine: empty area, populated area, JSON renderer
  - restore: back to origin, override target, missing-sidecar refusal
  - restore: blocked when target already exists
  - archive: from corpus, from quarantine (sidecar follows)
  - event_log: append, read, line-format integrity
  - CLI: list / add / restore / archive paths
"""

from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path

import pytest

from contrecipe.cli import main as cli_main
from contrecipe.core import event_log
from contrecipe.core import lifecycle as lc
from contrecipe.core import quarantine as q
from contrecipe.core.quarantine import (
    EXIT_BAD_PATH,
    EXIT_OK,
    EXIT_QUARANTINE_ERROR,
    OP_ARCHIVE,
    OP_QUARANTINE,
    OP_RESTORE,
    QuarantineError,
    QuarantineEntry,
    SIDECAR_SUFFIX,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

RECIPE_BODY = (
    "id: sample\n"
    "version: 1\n"
    "triggers: ['x']\n"
    "steps:\n"
    "  - worker: run_shell\n"
    "    params: {command: 'echo hi'}\n"
    "    verify: {method: exit_code, expected: 0}\n"
    "    output: r1\n"
)


def _sha256(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def _make_corpus(tmp_path: Path, name: str = "sample.yaml") -> Path:
    corpus = tmp_path / "recipes"
    corpus.mkdir(parents=True)
    recipe = corpus / name
    recipe.write_text(RECIPE_BODY)
    return recipe


# ---------------------------------------------------------------------------
# quarantine()
# ---------------------------------------------------------------------------

def test_quarantine_moves_recipe_and_writes_sidecar(tmp_path):
    recipe = _make_corpus(tmp_path)
    qdir = tmp_path / "quarantine"
    sha_before = _sha256(recipe)

    result = q.quarantine(
        recipe, quarantine_dir=qdir,
        reason="test_reason", fail_count=7, prior_lifecycle="active",
    )

    # Source gone, destination present
    assert not recipe.exists()
    assert result.dst_path.exists()
    assert result.dst_path == qdir / "sample.yaml"
    assert result.sidecar_path == qdir / "sample.quarantine.json"
    assert result.sidecar_path.exists()
    # Bytes preserved
    assert _sha256(result.dst_path) == sha_before


def test_quarantine_sidecar_payload_has_required_fields(tmp_path):
    recipe = _make_corpus(tmp_path)
    qdir = tmp_path / "quarantine"
    q.quarantine(
        recipe, quarantine_dir=qdir,
        reason="verify_fail_threshold_exceeded", fail_count=5,
        prior_lifecycle="active",
    )
    sidecar = qdir / "sample.quarantine.json"
    payload = json.loads(sidecar.read_text())
    assert payload["recipe_id"] == "sample"
    assert payload["reason"] == "verify_fail_threshold_exceeded"
    assert payload["fail_count"] == 5
    assert payload["prior_lifecycle"] == "active"
    assert payload["origin_path"].endswith("sample.yaml")
    assert "sha256" in payload
    assert payload["sidecar_schema_version"] == 1


def test_quarantine_collision_raises(tmp_path):
    recipe1 = _make_corpus(tmp_path)
    qdir = tmp_path / "quarantine"
    q.quarantine(recipe1, quarantine_dir=qdir, reason="first")

    # Recreate the source and try to quarantine again with same id
    recipe2 = _make_corpus(tmp_path / "second")  # different parent
    # But move it back to the original name to clash on file stem
    dst = tmp_path / "recipes2" / "sample.yaml"
    dst.parent.mkdir()
    shutil.move(str(recipe2), str(dst))

    with pytest.raises(QuarantineError, match="collision"):
        q.quarantine(dst, quarantine_dir=qdir, reason="second")


def test_quarantine_missing_source_raises(tmp_path):
    qdir = tmp_path / "quarantine"
    with pytest.raises(QuarantineError, match="not found"):
        q.quarantine(
            tmp_path / "no_such.yaml",
            quarantine_dir=qdir, reason="x",
        )


def test_quarantine_illegal_prior_lifecycle_blocks(tmp_path):
    recipe = _make_corpus(tmp_path)
    qdir = tmp_path / "quarantine"
    # 'archived' → 'quarantine' is not in the FSM
    with pytest.raises(lc.IllegalTransition):
        q.quarantine(
            recipe, quarantine_dir=qdir, reason="x",
            prior_lifecycle="archived",
        )
    # And nothing was moved
    assert recipe.exists()
    assert not qdir.exists() or not any(qdir.iterdir())


def test_quarantine_appends_event_when_log_provided(tmp_path):
    recipe = _make_corpus(tmp_path)
    qdir = tmp_path / "quarantine"
    log = tmp_path / "events.jsonl"
    q.quarantine(
        recipe, quarantine_dir=qdir, reason="r",
        fail_count=3, prior_lifecycle="active",
        event_log_path=log,
    )
    events = event_log.read_events(log)
    assert len(events) == 1
    e = events[0]
    assert e["op"] == OP_QUARANTINE
    assert e["recipe_id"] == "sample"
    assert e["from"] == "active"
    assert e["to"] == "quarantine"
    assert e["fail_count"] == 3
    assert "ts" in e


def test_quarantine_no_event_log_no_journal(tmp_path):
    recipe = _make_corpus(tmp_path)
    qdir = tmp_path / "quarantine"
    q.quarantine(recipe, quarantine_dir=qdir, reason="r")
    # Nothing else gets written
    sibs = sorted(p.name for p in qdir.iterdir())
    assert sibs == ["sample.quarantine.json", "sample.yaml"]


# ---------------------------------------------------------------------------
# list_quarantine()
# ---------------------------------------------------------------------------

def test_list_quarantine_empty_returns_empty_list(tmp_path):
    qdir = tmp_path / "quarantine"
    assert q.list_quarantine(qdir) == []


def test_list_quarantine_returns_entries_in_order(tmp_path):
    qdir = tmp_path / "quarantine"
    for i in range(3):
        recipe = _make_corpus(tmp_path / f"src_{i}", name=f"r{i}.yaml")
        q.quarantine(recipe, quarantine_dir=qdir, reason=f"reason_{i}")
    entries = q.list_quarantine(qdir)
    assert [e.recipe_id for e in entries] == ["r0", "r1", "r2"]


def test_list_quarantine_skips_orphaned_sidecar(tmp_path):
    qdir = tmp_path / "quarantine"
    qdir.mkdir()
    # Sidecar with no matching recipe file
    sidecar = qdir / f"orphan{SIDECAR_SUFFIX}"
    sidecar.write_text(json.dumps({"recipe_id": "orphan"}))
    assert q.list_quarantine(qdir) == []


def test_render_list_text_and_json(tmp_path):
    recipe = _make_corpus(tmp_path)
    qdir = tmp_path / "quarantine"
    q.quarantine(recipe, quarantine_dir=qdir,
                 reason="testing", fail_count=2, prior_lifecycle="active")
    entries = q.list_quarantine(qdir)
    text = q.render_list_text(entries)
    assert "sample" in text
    assert "testing" in text
    payload = json.loads(q.render_list_json(entries))
    assert payload["entries"][0]["recipe_id"] == "sample"


# ---------------------------------------------------------------------------
# restore()
# ---------------------------------------------------------------------------

def test_restore_returns_recipe_to_origin(tmp_path):
    recipe = _make_corpus(tmp_path)
    qdir = tmp_path / "quarantine"
    sha = _sha256(recipe)

    q.quarantine(recipe, quarantine_dir=qdir, reason="r", prior_lifecycle="active")
    assert not recipe.exists()

    result = q.restore("sample", quarantine_dir=qdir)

    assert result.dst_path == recipe
    assert recipe.exists()
    assert _sha256(recipe) == sha
    # Sidecar gone, recipe gone from quarantine
    assert not (qdir / "sample.yaml").exists()
    assert not (qdir / f"sample{SIDECAR_SUFFIX}").exists()


def test_restore_to_override_target(tmp_path):
    recipe = _make_corpus(tmp_path)
    qdir = tmp_path / "quarantine"
    q.quarantine(recipe, quarantine_dir=qdir, reason="r")

    new_target = tmp_path / "elsewhere" / "sample.yaml"
    q.restore("sample", quarantine_dir=qdir, target_path=new_target)
    assert new_target.exists()


def test_restore_refuses_overwrite_existing_target(tmp_path):
    recipe = _make_corpus(tmp_path)
    qdir = tmp_path / "quarantine"
    q.quarantine(recipe, quarantine_dir=qdir, reason="r")

    # Recreate something at the origin path so restore would clobber it
    recipe.write_text("squatter")
    with pytest.raises(QuarantineError, match="refusing to overwrite"):
        q.restore("sample", quarantine_dir=qdir)
    # And the quarantine state is untouched
    assert (qdir / "sample.yaml").exists()
    assert (qdir / f"sample{SIDECAR_SUFFIX}").exists()


def test_restore_missing_recipe_id_raises(tmp_path):
    qdir = tmp_path / "quarantine"
    qdir.mkdir()
    with pytest.raises(QuarantineError, match="no sidecar"):
        q.restore("ghost", quarantine_dir=qdir)


def test_restore_appends_event_when_log_provided(tmp_path):
    recipe = _make_corpus(tmp_path)
    qdir = tmp_path / "quarantine"
    log = tmp_path / "events.jsonl"
    q.quarantine(recipe, quarantine_dir=qdir, reason="r", prior_lifecycle="active",
                 event_log_path=log)
    q.restore("sample", quarantine_dir=qdir, event_log_path=log)
    events = event_log.read_events(log)
    ops = [e["op"] for e in events]
    assert ops == [OP_QUARANTINE, OP_RESTORE]


# ---------------------------------------------------------------------------
# archive()
# ---------------------------------------------------------------------------

def test_archive_from_corpus(tmp_path):
    recipe = _make_corpus(tmp_path)
    archive = tmp_path / "archive"
    log = tmp_path / "events.jsonl"
    q.archive(
        "sample",
        source_dir=recipe.parent,
        archive_dir=archive,
        prior_lifecycle="active",
        event_log_path=log,
    )
    assert not recipe.exists()
    assert (archive / "sample.yaml").exists()
    events = event_log.read_events(log)
    assert events[0]["op"] == OP_ARCHIVE


def test_archive_from_quarantine_takes_sidecar(tmp_path):
    recipe = _make_corpus(tmp_path)
    qdir = tmp_path / "quarantine"
    archive = tmp_path / "archive"
    q.quarantine(recipe, quarantine_dir=qdir, reason="r")

    q.archive("sample", source_dir=qdir, archive_dir=archive,
              prior_lifecycle="quarantine")

    assert (archive / "sample.yaml").exists()
    assert (archive / f"sample{SIDECAR_SUFFIX}").exists()


def test_archive_collision_raises(tmp_path):
    recipe = _make_corpus(tmp_path)
    archive = tmp_path / "archive"
    archive.mkdir()
    (archive / "sample.yaml").write_text("squatter")

    with pytest.raises(QuarantineError, match="collision"):
        q.archive("sample", source_dir=recipe.parent, archive_dir=archive)


def test_archive_missing_source_raises(tmp_path):
    archive = tmp_path / "archive"
    src = tmp_path / "recipes"
    src.mkdir()
    with pytest.raises(QuarantineError, match="not found"):
        q.archive("ghost", source_dir=src, archive_dir=archive)


# ---------------------------------------------------------------------------
# event_log
# ---------------------------------------------------------------------------

def test_event_log_append_and_read_round_trip(tmp_path):
    log = tmp_path / "events.jsonl"
    event_log.append(log, {"op": "quarantine", "recipe_id": "x"})
    event_log.append(log, {"op": "restore", "recipe_id": "x"})
    events = event_log.read_events(log)
    assert [e["op"] for e in events] == ["quarantine", "restore"]
    for e in events:
        assert "ts" in e


def test_event_log_one_object_per_line(tmp_path):
    log = tmp_path / "events.jsonl"
    event_log.append(log, {"op": "a"})
    event_log.append(log, {"op": "b"})
    lines = log.read_text().splitlines()
    assert len(lines) == 2
    for line in lines:
        json.loads(line)  # each line parses


def test_event_log_skips_corrupted_lines(tmp_path):
    log = tmp_path / "events.jsonl"
    log.write_text('{"ok": 1}\nNOT JSON\n{"ok": 2}\n')
    events = event_log.read_events(log)
    assert [e["ok"] for e in events] == [1, 2]


def test_event_log_read_missing_file_returns_empty(tmp_path):
    assert event_log.read_events(tmp_path / "absent.jsonl") == []


# ---------------------------------------------------------------------------
# CLI integration
# ---------------------------------------------------------------------------

def test_cli_quarantine_list_empty(tmp_path, capsys):
    qdir = tmp_path / "quarantine"
    qdir.mkdir()
    rc = cli_main(["quarantine", "list", "--dir", str(qdir)])
    out = capsys.readouterr().out
    assert rc == EXIT_OK
    assert "empty" in out.lower()


def test_cli_quarantine_add_then_list_then_restore(tmp_path, capsys):
    recipe = _make_corpus(tmp_path)
    qdir = tmp_path / "quarantine"
    log = tmp_path / "events.jsonl"

    rc = cli_main([
        "quarantine", "add", str(recipe),
        "--dir", str(qdir),
        "--reason", "verify_fails",
        "--fail-count", "5",
        "--prior-lifecycle", "active",
        "--event-log", str(log),
    ])
    assert rc == EXIT_OK
    assert (qdir / "sample.yaml").exists()

    capsys.readouterr()  # drop add's stdout
    rc = cli_main(["quarantine", "list", "--dir", str(qdir), "--json"])
    out = capsys.readouterr().out
    assert rc == EXIT_OK
    payload = json.loads(out)
    assert payload["entries"][0]["recipe_id"] == "sample"

    rc = cli_main([
        "quarantine", "restore", "sample",
        "--dir", str(qdir),
        "--event-log", str(log),
    ])
    assert rc == EXIT_OK
    assert recipe.exists()

    events = event_log.read_events(log)
    assert [e["op"] for e in events] == [OP_QUARANTINE, OP_RESTORE]


def test_cli_quarantine_add_collision_returns_one(tmp_path, capsys):
    recipe = _make_corpus(tmp_path)
    qdir = tmp_path / "quarantine"
    cli_main(["quarantine", "add", str(recipe),
              "--dir", str(qdir), "--reason", "first"])
    capsys.readouterr()

    # Make a fresh source with the same name → collision
    recipe2 = _make_corpus(tmp_path / "second")
    rc = cli_main(["quarantine", "add", str(recipe2),
                   "--dir", str(qdir), "--reason", "second"])
    err = capsys.readouterr().err
    assert rc == EXIT_QUARANTINE_ERROR
    assert "collision" in err


def test_cli_quarantine_archive_path(tmp_path, capsys):
    recipe = _make_corpus(tmp_path)
    archive = tmp_path / "archive"
    log = tmp_path / "events.jsonl"

    rc = cli_main([
        "quarantine", "archive", "sample",
        "--source", str(recipe.parent),
        "--archive-dir", str(archive),
        "--prior-lifecycle", "active",
        "--event-log", str(log),
    ])
    assert rc == EXIT_OK
    assert (archive / "sample.yaml").exists()


def test_cli_quarantine_list_bad_path(tmp_path, capsys):
    f = tmp_path / "single.yaml"
    f.write_text("hi")
    rc = cli_main(["quarantine", "list", "--dir", str(f)])
    err = capsys.readouterr().err
    assert rc == EXIT_BAD_PATH
    assert "not a directory" in err
