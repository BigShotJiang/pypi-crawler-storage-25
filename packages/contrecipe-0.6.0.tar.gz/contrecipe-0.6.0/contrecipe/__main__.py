# v1 | 2026-05-03 | Sprint R1 — entry for `python -m contrecipe`
"""Allows `python -m contrecipe ...` invocation, equivalent to the
`contrecipe` console script registered in pyproject.toml.
"""

from contrecipe.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
