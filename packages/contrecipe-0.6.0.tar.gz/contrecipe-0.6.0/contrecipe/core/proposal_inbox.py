# v1 | 2026-05-03 | Sprint R6 — proposal inbox (maildir-style, idempotent processor)
"""Proposal inbox processor.

Cont drops new recipe proposals into a directory; `contrecipe` polls it,
validates each one, compiles it to verify it can actually run, and routes
it to one of four outcomes:

    accepted/   — passed validation + compile; ready for corpus writer (R7)
    rejected/   — validator or compiler said no (the recipe is intact)
    malformed/  — yaml parse failed; cannot even be inspected
    processed/  — durable record; raw input copy, no-touch from this point

Pipeline per proposal:

    new/<id>.yaml
        │
        ▼   atomic os.rename → processing/<id>.yaml   (claim; crash-safe)
        │
        ▼   yaml.safe_load
        │     fail → malformed/  + journal entry
        │
        ▼   validator.validate_recipe
        │     verdict != valid → rejected/  + journal entry
        │
        ▼   compiler.compile_recipe
        │     CompileError → rejected/  + journal entry
        │
        ▼   accepted/<id>.yaml      + journal entry
        │
        ▼   processed/<id>.yaml     (durable copy of original input)

Outcomes are *moves*, not copies — except `processed/` which is a
**copy** of the original input, kept for audit. The split between
`accepted/` and `processed/` lets R7's corpus writer treat
`accepted/` as a queue (consume + delete) while still leaving an
immutable trail in `processed/`.

The processor is idempotent at restart: anything left in `processing/`
gets reclaimed and re-driven through the pipeline. Processing is also
side-effect-bounded: every move is `os.rename` within the inbox tree
(same filesystem) — atomic by POSIX guarantee.

Two run modes:

    drain_once(...)  — process up to N items, return outcome counts
    watch(...)       — drain_once() in a polling loop with sleep

`watch` exists for completeness; tests primarily exercise `drain_once`
because everything observable about the pipeline is captured there.
"""

from __future__ import annotations

import json
import shutil
import signal
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, Mapping

import yaml

from contrecipe.core import compiler, event_log
from contrecipe.core import validator as _validator
from contrecipe.core._registry import JsonFileRegistry, ToolRegistry
from contrecipe.core.compiler import CompileError

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

DIR_NEW = "new"
DIR_PROCESSING = "processing"
DIR_ACCEPTED = "accepted"
DIR_REJECTED = "rejected"
DIR_MALFORMED = "malformed"
DIR_PROCESSED = "processed"

ALL_SUBDIRS = (
    DIR_NEW, DIR_PROCESSING, DIR_ACCEPTED,
    DIR_REJECTED, DIR_MALFORMED, DIR_PROCESSED,
)

OP_ACCEPT = "proposal_accept"
OP_REJECT = "proposal_reject"
OP_MALFORMED = "proposal_malformed"
OP_RECLAIMED = "proposal_reclaimed"

DEFAULT_MAX_PER_CYCLE = 16
DEFAULT_POLL_INTERVAL_SECONDS = 1.0

EXIT_OK = 0
EXIT_INBOX_ERROR = 1
EXIT_BAD_PATH = 3


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------

class InboxError(Exception):
    """Inbox setup failed (missing root, etc.)."""


# ---------------------------------------------------------------------------
# Result data
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class ProposalOutcome:
    """One proposal's journey through the pipeline."""
    proposal_name: str
    outcome: str         # 'accepted' | 'rejected' | 'malformed'
    reason: str          # short tag; details in journal
    final_path: Path


@dataclass(frozen=True)
class DrainReport:
    """Aggregate of one drain_once() call."""
    inbox_root: Path
    accepted: tuple[ProposalOutcome, ...]
    rejected: tuple[ProposalOutcome, ...]
    malformed: tuple[ProposalOutcome, ...]
    reclaimed: tuple[str, ...]    # names of proposals re-driven from processing/

    @property
    def total(self) -> int:
        return len(self.accepted) + len(self.rejected) + len(self.malformed)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def ensure_layout(inbox_root: Path) -> None:
    """Create the maildir-style subdirectories. Idempotent."""
    inbox_root = inbox_root.expanduser().resolve()
    if inbox_root.exists() and not inbox_root.is_dir():
        raise InboxError(f"inbox root is not a directory: {inbox_root}")
    inbox_root.mkdir(parents=True, exist_ok=True)
    for sub in ALL_SUBDIRS:
        (inbox_root / sub).mkdir(exist_ok=True)


def drain_once(
    inbox_root: Path,
    *,
    registry: ToolRegistry | None = None,
    max_proposals: int = DEFAULT_MAX_PER_CYCLE,
    event_log_path: Path | None = None,
) -> DrainReport:
    """Process up to `max_proposals` items from `new/` (and any leftovers
    in `processing/` from a prior crash). Pure return value; side effects
    are confined to the inbox tree and the optional event log.
    """
    inbox_root = inbox_root.expanduser().resolve()
    if not inbox_root.is_dir():
        raise InboxError(f"inbox root does not exist: {inbox_root}")

    ensure_layout(inbox_root)

    new_dir = inbox_root / DIR_NEW
    proc_dir = inbox_root / DIR_PROCESSING

    accepted: list[ProposalOutcome] = []
    rejected: list[ProposalOutcome] = []
    malformed: list[ProposalOutcome] = []
    reclaimed: list[str] = []

    # 1) Reclaim anything left in processing/ from a prior crash.
    leftover = sorted(_iter_yaml_files(proc_dir))
    for path in leftover[:max_proposals]:
        reclaimed.append(path.name)
        if event_log_path is not None:
            event_log.append(event_log_path, {
                "op": OP_RECLAIMED,
                "proposal": path.name,
                "reason": "leftover_from_prior_run",
            })
        outcome = _drive_one(path, inbox_root, registry, event_log_path)
        _bucket(outcome, accepted, rejected, malformed)

    # 2) Claim new arrivals up to remaining quota.
    remaining = max_proposals - len(reclaimed)
    if remaining > 0:
        for src in sorted(_iter_yaml_files(new_dir))[:remaining]:
            claimed = _claim(src, proc_dir)
            if claimed is None:
                # Lost race / disappeared between scan and claim.
                continue
            outcome = _drive_one(claimed, inbox_root, registry, event_log_path)
            _bucket(outcome, accepted, rejected, malformed)

    return DrainReport(
        inbox_root=inbox_root,
        accepted=tuple(accepted),
        rejected=tuple(rejected),
        malformed=tuple(malformed),
        reclaimed=tuple(reclaimed),
    )


def watch(
    inbox_root: Path,
    *,
    registry: ToolRegistry | None = None,
    poll_interval_seconds: float = DEFAULT_POLL_INTERVAL_SECONDS,
    max_proposals_per_cycle: int = DEFAULT_MAX_PER_CYCLE,
    event_log_path: Path | None = None,
    max_cycles: int | None = None,
) -> int:
    """Run `drain_once` in a loop until interrupted.

    Sets handlers for SIGINT/SIGTERM so the daemon exits cleanly between
    cycles (never mid-pipeline). `max_cycles` is for tests; production
    callers pass None for indefinite operation.
    """
    inbox_root = inbox_root.expanduser().resolve()
    ensure_layout(inbox_root)

    stop = {"flag": False}

    def _handle_signal(signum, frame):  # noqa: ANN001
        stop["flag"] = True

    # Install handlers only when running on the main thread; drain_once is
    # safe to call from any thread, but signal install isn't.
    try:
        signal.signal(signal.SIGINT, _handle_signal)
        signal.signal(signal.SIGTERM, _handle_signal)
    except ValueError:
        # Not on main thread — skip signal install; caller controls stop.
        pass

    cycles = 0
    while not stop["flag"]:
        drain_once(
            inbox_root,
            registry=registry,
            max_proposals=max_proposals_per_cycle,
            event_log_path=event_log_path,
        )
        cycles += 1
        if max_cycles is not None and cycles >= max_cycles:
            break
        # Sleep in small chunks so SIGTERM is observed within ~50ms even
        # at long poll intervals.
        slept = 0.0
        while not stop["flag"] and slept < poll_interval_seconds:
            chunk = min(0.05, poll_interval_seconds - slept)
            time.sleep(chunk)
            slept += chunk

    return EXIT_OK


# ---------------------------------------------------------------------------
# CLI bridge
# ---------------------------------------------------------------------------

def cli_watch(
    inbox: str,
    *,
    interval: float = DEFAULT_POLL_INTERVAL_SECONDS,
    max_per_cycle: int = DEFAULT_MAX_PER_CYCLE,
    once: bool = False,
    registry_path: str | None = None,
    event_log_path: str | None = None,
    json_output: bool = False,
) -> int:
    """Entry for `contrecipe watch <inbox>`."""
    registry: ToolRegistry | None = None
    if registry_path:
        registry = JsonFileRegistry(Path(registry_path))

    log_path = Path(event_log_path) if event_log_path else None

    try:
        if once:
            report = drain_once(
                Path(inbox),
                registry=registry,
                max_proposals=max_per_cycle,
                event_log_path=log_path,
            )
            print(_render_report_json(report) if json_output
                  else _render_report_text(report))
            return EXIT_OK
        return watch(
            Path(inbox),
            registry=registry,
            poll_interval_seconds=interval,
            max_proposals_per_cycle=max_per_cycle,
            event_log_path=log_path,
        )
    except InboxError as exc:
        print(f"contrecipe: {exc}", file=sys.stderr)
        return EXIT_BAD_PATH
    except (OSError, ValueError) as exc:
        print(f"contrecipe: {exc}", file=sys.stderr)
        return EXIT_BAD_PATH


# ---------------------------------------------------------------------------
# Internal — single-proposal pipeline
# ---------------------------------------------------------------------------

def _drive_one(
    claimed: Path,
    inbox_root: Path,
    registry: ToolRegistry | None,
    event_log_path: Path | None,
) -> ProposalOutcome:
    """Run validate → compile → route, with full journal entries."""
    name = claimed.name

    # 1) Parse
    try:
        text = claimed.read_text(encoding="utf-8")
        raw = yaml.safe_load(text)
    except (OSError, yaml.YAMLError) as exc:
        return _route(
            claimed, inbox_root, DIR_MALFORMED,
            outcome="malformed", reason="yaml_parse_error",
            detail=str(exc),
            op=OP_MALFORMED, event_log_path=event_log_path,
        )
    if not isinstance(raw, dict):
        return _route(
            claimed, inbox_root, DIR_MALFORMED,
            outcome="malformed", reason="not_a_mapping",
            detail=f"top-level is {type(raw).__name__}",
            op=OP_MALFORMED, event_log_path=event_log_path,
        )

    # 2) Validate
    result = _validator.validate_recipe(raw, registry=registry)
    if not result.is_valid:
        codes = ",".join(sorted({f.code for f in result.errors}))
        return _route(
            claimed, inbox_root, DIR_REJECTED,
            outcome="rejected",
            reason=f"validator_{result.verdict}",
            detail=codes or "no_codes",
            op=OP_REJECT, event_log_path=event_log_path,
            extra={"verdict": result.verdict, "codes": codes},
        )

    # 3) Compile (defence in depth — a 'valid' recipe should compile,
    #    but compile-only failures like duplicate outputs land here.)
    try:
        compiler.compile_recipe(raw, registry=registry)
    except CompileError as exc:
        return _route(
            claimed, inbox_root, DIR_REJECTED,
            outcome="rejected", reason="compiler_error",
            detail=exc.message,
            op=OP_REJECT, event_log_path=event_log_path,
        )

    # 4) Accept — move to accepted/, copy to processed/
    return _route(
        claimed, inbox_root, DIR_ACCEPTED,
        outcome="accepted", reason="ok",
        detail="",
        op=OP_ACCEPT, event_log_path=event_log_path,
        also_archive_to=DIR_PROCESSED,
    )


def _route(
    claimed: Path,
    inbox_root: Path,
    target_subdir: str,
    *,
    outcome: str,
    reason: str,
    detail: str,
    op: str,
    event_log_path: Path | None,
    also_archive_to: str | None = None,
    extra: Mapping[str, object] | None = None,
) -> ProposalOutcome:
    """Move `claimed` from processing/ to target_subdir/, optionally also
    leaving a copy in `also_archive_to/` (used for accepted → processed).
    """
    target = inbox_root / target_subdir / claimed.name
    target.parent.mkdir(parents=True, exist_ok=True)

    if also_archive_to is not None:
        archive_dir = inbox_root / also_archive_to
        archive_dir.mkdir(parents=True, exist_ok=True)
        archive_path = archive_dir / claimed.name
        # Copy first (durable record), then move the original.
        if not archive_path.exists():
            shutil.copy2(claimed, archive_path)

    # Atomic move within the inbox tree.
    if target.exists():
        # Idempotency guard: if a previous run already routed this proposal,
        # leave the existing target alone, drop the duplicate from
        # processing/. The journal will show two entries which is correct.
        try:
            claimed.unlink()
        except FileNotFoundError:
            pass
    else:
        claimed.rename(target)

    if event_log_path is not None:
        payload: dict[str, object] = {
            "op": op,
            "proposal": claimed.name,
            "reason": reason,
            "detail": detail,
            "final_path": str(target),
        }
        if extra:
            payload.update(extra)
        event_log.append(event_log_path, payload)

    return ProposalOutcome(
        proposal_name=claimed.name,
        outcome=outcome,
        reason=reason,
        final_path=target,
    )


def _claim(src: Path, proc_dir: Path) -> Path | None:
    """Atomic move src → proc_dir/<name>. Returns None on race loss."""
    proc_dir.mkdir(parents=True, exist_ok=True)
    target = proc_dir / src.name
    try:
        src.rename(target)
    except FileNotFoundError:
        return None
    except OSError:
        return None
    return target


def _iter_yaml_files(directory: Path) -> Iterable[Path]:
    if not directory.is_dir():
        return ()
    return (
        p for p in directory.iterdir()
        if p.is_file() and p.suffix in (".yaml", ".yml")
    )


def _bucket(
    outcome: ProposalOutcome,
    accepted: list[ProposalOutcome],
    rejected: list[ProposalOutcome],
    malformed: list[ProposalOutcome],
) -> None:
    if outcome.outcome == "accepted":
        accepted.append(outcome)
    elif outcome.outcome == "rejected":
        rejected.append(outcome)
    else:
        malformed.append(outcome)


# ---------------------------------------------------------------------------
# Renderers
# ---------------------------------------------------------------------------

def _render_report_text(report: DrainReport) -> str:
    lines = [
        f"contrecipe watch — drain summary",
        f"inbox     : {report.inbox_root}",
        f"accepted  : {len(report.accepted)}",
        f"rejected  : {len(report.rejected)}",
        f"malformed : {len(report.malformed)}",
        f"reclaimed : {len(report.reclaimed)}",
    ]
    for label, group in (
        ("accepted",  report.accepted),
        ("rejected",  report.rejected),
        ("malformed", report.malformed),
    ):
        if not group:
            continue
        lines.append("")
        lines.append(f"--- {label} ---")
        for o in group:
            tail = f" — {o.reason}" if o.reason and o.reason != "ok" else ""
            lines.append(f"  {o.proposal_name}{tail}")
    return "\n".join(lines)


def _render_report_json(report: DrainReport) -> str:
    payload = {
        "schema_version": 1,
        "inbox_root": str(report.inbox_root),
        "totals": {
            "accepted": len(report.accepted),
            "rejected": len(report.rejected),
            "malformed": len(report.malformed),
            "reclaimed": len(report.reclaimed),
        },
        "accepted": [
            {"proposal": o.proposal_name, "final_path": str(o.final_path)}
            for o in report.accepted
        ],
        "rejected": [
            {"proposal": o.proposal_name, "reason": o.reason,
             "final_path": str(o.final_path)}
            for o in report.rejected
        ],
        "malformed": [
            {"proposal": o.proposal_name, "reason": o.reason,
             "final_path": str(o.final_path)}
            for o in report.malformed
        ],
        "reclaimed": list(report.reclaimed),
    }
    return json.dumps(payload, indent=2, sort_keys=True)
