# v1 | 2026-05-03 | Sprint R3 — recipe validator (verdict + findings)
"""Recipe validator.

Reads the canonical schema (`recipe_v1.schema.yaml`) and a parsed recipe,
emits structured findings, and assigns a verdict:

    valid         — no errors, no contamination
    invalid       — schema violations
    contaminated  — phantom / forbidden worker present (poisoned-memory risk)

A single recipe can have multiple findings; the verdict is a function of
the strongest finding present:

    contaminated  > invalid  > valid

The validator is **pure**: same input always yields the same findings.
Registry checks are skipped when the registry is non-introspective
(`EmptyRegistry`); a single info finding records that fact so operators
do not silently ship a half-validated corpus.

Finding codes
-------------
Recipe-level (R0xx)
  R001  missing required recipe field
  R002  recipe id not a non-empty string
  R003  recipe version not a positive integer
  R004  triggers not a non-empty list of strings
  R005  steps not a non-empty list of mappings
  R006  recipe-level uses field present (reserved for R4+)

Step-level (R1xx)
  R100  missing required step field
  R101  step worker not a string
  R102  worker is forbidden / phantom (CONTAMINATED)
  R103  worker not in tool registry
  R104  params not a mapping
  R105  verify not a mapping
  R106  verify.method missing
  R107  verify.method not in canonical allowed set
  R108  output not a non-empty string
  R109  on_fail not in {abort, continue, retry}
  R110  retries not a non-negative integer
  R111  step uses field present (reserved for R4+)

Drift (R2xx) — emitted as ERROR because runtime is broken either way
  R200  step uses legacy 'action' field instead of 'worker'
  R201  step uses legacy 'args' field instead of 'params'

Info (R9xx)
  R900  registry not introspective; worker-name validity not checked
"""

from __future__ import annotations

import json
import sys
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, Mapping, Sequence

import yaml

from contrecipe.core import inspector
from contrecipe.core._registry import EmptyRegistry, JsonFileRegistry, ToolRegistry
from contrecipe.core._schema import load_canonical_schema

# ----------------------------------------------------------------------------
# Constants
# ----------------------------------------------------------------------------

SEVERITY_ERROR = "error"
SEVERITY_WARNING = "warning"  # reserved for future use
SEVERITY_INFO = "info"

VERDICT_VALID = "valid"
VERDICT_INVALID = "invalid"
VERDICT_CONTAMINATED = "contaminated"

REQUIRED_RECIPE_FIELDS = ("id", "version", "triggers", "steps")
REQUIRED_STEP_FIELDS = ("worker", "params", "verify", "output")
ALLOWED_ON_FAIL = ("abort", "continue", "retry")

# Exit codes (CLI contract)
EXIT_VALID = 0
EXIT_INVALID = 1
EXIT_CONTAMINATED = 2
EXIT_BAD_PATH = 3


# ----------------------------------------------------------------------------
# Data model
# ----------------------------------------------------------------------------

@dataclass(frozen=True)
class Finding:
    """One rule violation or informational note about a recipe."""
    severity: str
    code: str
    message: str
    path: tuple[object, ...] = ()  # JSONPath-like tuple, e.g. ('steps', 0, 'verify')

    def render(self) -> str:
        loc = "." + ".".join(str(p) for p in self.path) if self.path else ""
        return f"  [{self.severity}] {self.code}{loc}: {self.message}"


@dataclass(frozen=True)
class ValidationResult:
    """Outcome of validating one recipe."""
    recipe_path: Path | None
    recipe_id: str | None
    verdict: str
    findings: tuple[Finding, ...]

    @property
    def errors(self) -> tuple[Finding, ...]:
        return tuple(f for f in self.findings if f.severity == SEVERITY_ERROR)

    @property
    def is_valid(self) -> bool:
        return self.verdict == VERDICT_VALID

    @property
    def is_contaminated(self) -> bool:
        return self.verdict == VERDICT_CONTAMINATED


# ----------------------------------------------------------------------------
# Public API
# ----------------------------------------------------------------------------

def validate_recipe(
    raw: Mapping[str, object],
    *,
    registry: ToolRegistry | None = None,
    recipe_path: Path | None = None,
) -> ValidationResult:
    """Validate a parsed recipe mapping. Pure; never raises on bad data."""
    findings: list[Finding] = []
    contaminated = False

    schema = load_canonical_schema()
    forbidden = frozenset(schema.get("forbidden_workers", []) or ())
    allowed_verify = frozenset(
        (schema.get("verify", {}) or {}).get("allowed_methods", {}) or {}
    )

    reg: ToolRegistry = registry if registry is not None else EmptyRegistry()
    if not reg.is_introspective:
        findings.append(
            Finding(
                severity=SEVERITY_INFO,
                code="R900",
                message=(
                    "registry not introspective; worker-name validity not "
                    "checked. Provide --registry to enable this rule."
                ),
            )
        )

    # ---- recipe-level checks --------------------------------------------
    for f in REQUIRED_RECIPE_FIELDS:
        if f not in raw:
            findings.append(
                Finding(SEVERITY_ERROR, "R001",
                        f"missing required recipe field: {f!r}", (f,))
            )

    rid = raw.get("id")
    if "id" in raw and not (isinstance(rid, str) and rid):
        findings.append(
            Finding(SEVERITY_ERROR, "R002",
                    f"recipe id must be a non-empty string, got {type(rid).__name__}",
                    ("id",))
        )

    version = raw.get("version")
    if "version" in raw and not (isinstance(version, int)
                                  and not isinstance(version, bool)
                                  and version >= 1):
        findings.append(
            Finding(SEVERITY_ERROR, "R003",
                    "recipe version must be a positive integer",
                    ("version",))
        )

    triggers = raw.get("triggers")
    if "triggers" in raw:
        if not isinstance(triggers, list) or not triggers:
            findings.append(
                Finding(SEVERITY_ERROR, "R004",
                        "triggers must be a non-empty list of strings",
                        ("triggers",))
            )
        elif not all(isinstance(t, str) and t for t in triggers):
            findings.append(
                Finding(SEVERITY_ERROR, "R004",
                        "every trigger must be a non-empty string",
                        ("triggers",))
            )

    if "uses" in raw:
        findings.append(
            Finding(SEVERITY_ERROR, "R006",
                    "recipe-level 'uses' is reserved for R4+; not supported",
                    ("uses",))
        )

    # ---- step-level checks ----------------------------------------------
    steps = raw.get("steps")
    if "steps" in raw:
        if not isinstance(steps, list) or not steps:
            findings.append(
                Finding(SEVERITY_ERROR, "R005",
                        "steps must be a non-empty list of mappings",
                        ("steps",))
            )
        else:
            for i, step in enumerate(steps):
                if not isinstance(step, dict):
                    findings.append(
                        Finding(SEVERITY_ERROR, "R005",
                                f"step {i} is {type(step).__name__}, expected mapping",
                                ("steps", i))
                    )
                    continue
                step_findings, step_contaminated = _validate_step(
                    step, i, forbidden, allowed_verify, reg,
                )
                findings.extend(step_findings)
                contaminated = contaminated or step_contaminated

    # ---- verdict --------------------------------------------------------
    has_error = any(f.severity == SEVERITY_ERROR for f in findings)
    if contaminated:
        verdict = VERDICT_CONTAMINATED
    elif has_error:
        verdict = VERDICT_INVALID
    else:
        verdict = VERDICT_VALID

    return ValidationResult(
        recipe_path=recipe_path,
        recipe_id=rid if isinstance(rid, str) else None,
        verdict=verdict,
        findings=tuple(findings),
    )


def validate_file(
    path: Path,
    *,
    registry: ToolRegistry | None = None,
) -> ValidationResult:
    """Validate a single recipe yaml file from disk."""
    path = path.expanduser().resolve()
    if not path.exists():
        raise FileNotFoundError(f"recipe file does not exist: {path}")
    if not path.is_file():
        raise IsADirectoryError(f"expected a file, got: {path}")
    try:
        text = path.read_text(encoding="utf-8")
        raw = yaml.safe_load(text)
    except yaml.YAMLError as exc:
        return ValidationResult(
            recipe_path=path,
            recipe_id=None,
            verdict=VERDICT_INVALID,
            findings=(
                Finding(SEVERITY_ERROR, "R000",
                        f"yaml parse error: {exc}", ()),
            ),
        )
    if not isinstance(raw, dict):
        return ValidationResult(
            recipe_path=path,
            recipe_id=None,
            verdict=VERDICT_INVALID,
            findings=(
                Finding(SEVERITY_ERROR, "R000",
                        f"top-level is {type(raw).__name__}, expected mapping", ()),
            ),
        )
    return validate_recipe(raw, registry=registry, recipe_path=path)


# ----------------------------------------------------------------------------
# Renderers
# ----------------------------------------------------------------------------

def render_text(result: ValidationResult) -> str:
    head = []
    head.append(f"contrecipe validate")
    if result.recipe_path:
        head.append(f"file    : {result.recipe_path}")
    if result.recipe_id:
        head.append(f"id      : {result.recipe_id}")
    head.append(f"verdict : {result.verdict.upper()}")

    counts = Counter(f.severity for f in result.findings)
    if counts:
        parts = [f"{counts[s]} {s}" for s in (SEVERITY_ERROR, SEVERITY_WARNING, SEVERITY_INFO) if counts[s]]
        head.append(f"findings: {', '.join(parts)}")
    head.append("")

    if not result.findings:
        head.append("  (no findings)")
        return "\n".join(head)

    for f in result.findings:
        head.append(f.render())
    return "\n".join(head)


def render_json(result: ValidationResult) -> str:
    payload = {
        "schema_version": 1,
        "recipe_path": str(result.recipe_path) if result.recipe_path else None,
        "recipe_id": result.recipe_id,
        "verdict": result.verdict,
        "findings": [
            {
                "severity": f.severity,
                "code": f.code,
                "message": f.message,
                "path": list(f.path),
            }
            for f in result.findings
        ],
    }
    return json.dumps(payload, indent=2, sort_keys=True)


# ----------------------------------------------------------------------------
# CLI bridge
# ----------------------------------------------------------------------------

def run_cli(
    recipe_path: str,
    *,
    json_output: bool = False,
    registry_path: str | None = None,
) -> int:
    """Entry point for `contrecipe validate <recipe>`."""
    registry: ToolRegistry | None = None
    if registry_path:
        registry = JsonFileRegistry(Path(registry_path))

    try:
        result = validate_file(Path(recipe_path), registry=registry)
    except (FileNotFoundError, IsADirectoryError) as exc:
        print(f"contrecipe: {exc}", file=sys.stderr)
        return EXIT_BAD_PATH
    except (OSError, ValueError) as exc:
        # registry load failure surfaces here
        print(f"contrecipe: {exc}", file=sys.stderr)
        return EXIT_BAD_PATH

    rendered = render_json(result) if json_output else render_text(result)
    print(rendered)

    if result.verdict == VERDICT_CONTAMINATED:
        return EXIT_CONTAMINATED
    if result.verdict == VERDICT_INVALID:
        return EXIT_INVALID
    return EXIT_VALID


# ----------------------------------------------------------------------------
# Internal helpers
# ----------------------------------------------------------------------------

def _validate_step(
    step: Mapping[str, object],
    idx: int,
    forbidden: frozenset[str],
    allowed_verify: frozenset[str],
    registry: ToolRegistry,
) -> tuple[list[Finding], bool]:
    findings: list[Finding] = []
    contaminated = False

    # Drift: legacy field names (audit signal). Treat as ERROR — the runtime
    # is broken whether the author meant well or not.
    if "action" in step:
        findings.append(
            Finding(SEVERITY_ERROR, "R200",
                    "step uses legacy 'action' field; rename to 'worker'",
                    ("steps", idx, "action"))
        )
    if "args" in step:
        findings.append(
            Finding(SEVERITY_ERROR, "R201",
                    "step uses legacy 'args' field; rename to 'params'",
                    ("steps", idx, "args"))
        )
    if "uses" in step:
        findings.append(
            Finding(SEVERITY_ERROR, "R111",
                    "step-level 'uses' is reserved for R4+; not supported",
                    ("steps", idx, "uses"))
        )

    # Required step fields
    for f in REQUIRED_STEP_FIELDS:
        if f not in step:
            findings.append(
                Finding(SEVERITY_ERROR, "R100",
                        f"missing required step field: {f!r}",
                        ("steps", idx, f))
            )

    # Worker
    worker = step.get("worker")
    if "worker" in step and not isinstance(worker, str):
        findings.append(
            Finding(SEVERITY_ERROR, "R101",
                    f"worker must be a string, got {type(worker).__name__}",
                    ("steps", idx, "worker"))
        )
    elif isinstance(worker, str):
        if worker in forbidden:
            findings.append(
                Finding(SEVERITY_ERROR, "R102",
                        f"worker {worker!r} is forbidden (contamination signature)",
                        ("steps", idx, "worker"))
            )
            contaminated = True
        elif registry.is_introspective and not registry.is_known(worker):
            findings.append(
                Finding(SEVERITY_ERROR, "R103",
                        f"worker {worker!r} not in tool registry",
                        ("steps", idx, "worker"))
            )

    # params
    params = step.get("params")
    if "params" in step and not isinstance(params, dict):
        findings.append(
            Finding(SEVERITY_ERROR, "R104",
                    f"params must be a mapping, got {type(params).__name__}",
                    ("steps", idx, "params"))
        )

    # verify
    verify = step.get("verify")
    if "verify" in step:
        if not isinstance(verify, dict):
            findings.append(
                Finding(SEVERITY_ERROR, "R105",
                        f"verify must be a mapping, got {type(verify).__name__}",
                        ("steps", idx, "verify"))
            )
        else:
            method = verify.get("method")
            if method is None:
                findings.append(
                    Finding(SEVERITY_ERROR, "R106",
                            "verify.method is required",
                            ("steps", idx, "verify", "method"))
                )
            elif not isinstance(method, str) or method not in allowed_verify:
                findings.append(
                    Finding(SEVERITY_ERROR, "R107",
                            f"verify.method {method!r} not in canonical set: "
                            f"{sorted(allowed_verify)}",
                            ("steps", idx, "verify", "method"))
                )

    # output
    output = step.get("output")
    if "output" in step and not (isinstance(output, str) and output):
        findings.append(
            Finding(SEVERITY_ERROR, "R108",
                    "output must be a non-empty string",
                    ("steps", idx, "output"))
        )

    # on_fail
    on_fail = step.get("on_fail")
    if "on_fail" in step and on_fail not in ALLOWED_ON_FAIL:
        findings.append(
            Finding(SEVERITY_ERROR, "R109",
                    f"on_fail must be one of {ALLOWED_ON_FAIL}, got {on_fail!r}",
                    ("steps", idx, "on_fail"))
        )

    # retries
    retries = step.get("retries")
    if "retries" in step and not (
        isinstance(retries, int)
        and not isinstance(retries, bool)
        and retries >= 0
    ):
        findings.append(
            Finding(SEVERITY_ERROR, "R110",
                    "retries must be a non-negative integer",
                    ("steps", idx, "retries"))
        )

    return findings, contaminated
