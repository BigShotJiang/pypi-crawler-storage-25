# v1 | 2026-05-03 | Sprint R5 — quarantine: move/restore/archive with sidecar metadata
"""Recipe quarantine, restore, and archive operations.

Quarantine never deletes. Recipes are *moved* (atomic rename when
possible; cross-device fallback) into a dedicated directory and gain a
small sidecar file (`<recipe>.quarantine.json`) recording why and when.
Restore reverses the move, taking the recipe back to its origin path
(or an explicit override). Archive is a one-way trip — same mechanics
but no restore.

Design constants (committed):

  - **Recipe content is never modified.** Lifecycle is recorded in a
    sidecar, not by editing the yaml. Quarantine and restore preserve
    bytes exactly; checksums match before and after.

  - **Atomic move.** `os.rename` within the same filesystem; falls back
    to `shutil.move` across devices. Two-phase: write sidecar first,
    then rename recipe; on rename failure, sidecar is removed so the
    quarantine area never holds an orphaned stub.

  - **Idempotent list.** `list_quarantine` and `list_archive` are pure
    reads. Safe to call from cron, dashboards, anywhere.

  - **Append-only journal.** Every state change writes one JSON line.
    Restore writes its own line; the original quarantine entry is
    preserved.

  - **Recipe identity is the file stem.** A quarantine area cannot
    hold two recipes with the same id — the second move raises rather
    than silently overwriting.
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import sys
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping

import yaml

from contrecipe.core import event_log, lifecycle

# ----------------------------------------------------------------------------
# Constants
# ----------------------------------------------------------------------------

SIDECAR_SUFFIX = ".quarantine.json"
SIDECAR_SCHEMA_VERSION = 1

OP_QUARANTINE = "quarantine"
OP_RESTORE = "restore"
OP_ARCHIVE = "archive"

# CLI exit codes
EXIT_OK = 0
EXIT_QUARANTINE_ERROR = 1
EXIT_BAD_PATH = 3


# ----------------------------------------------------------------------------
# Errors
# ----------------------------------------------------------------------------

class QuarantineError(Exception):
    """Operation could not complete (collision, missing source, etc.)."""


# ----------------------------------------------------------------------------
# Data model
# ----------------------------------------------------------------------------

@dataclass(frozen=True)
class QuarantineEntry:
    """One recipe currently sitting in a quarantine area."""
    recipe_id: str
    recipe_path: Path           # path inside quarantine dir
    sidecar_path: Path
    reason: str
    quarantined_at: str         # ISO 8601 UTC
    fail_count: int | None
    prior_lifecycle: str | None
    origin_path: str | None     # original location, used for restore


@dataclass(frozen=True)
class MoveResult:
    """Outcome of a quarantine/restore/archive operation."""
    op: str
    recipe_id: str
    src_path: Path
    dst_path: Path
    sidecar_path: Path | None


# ----------------------------------------------------------------------------
# Public API — operations
# ----------------------------------------------------------------------------

def quarantine(
    recipe_path: Path,
    *,
    quarantine_dir: Path,
    reason: str,
    fail_count: int | None = None,
    prior_lifecycle: str | None = None,
    event_log_path: Path | None = None,
) -> MoveResult:
    """Move a recipe into the quarantine area and write sidecar metadata.

    The recipe yaml file itself is moved unchanged. The sidecar captures
    *why*; this is the only place the reason ever lives, by design (the
    recipe file is preserved byte-for-byte for clean restore).

    Raises QuarantineError on:
      - missing source
      - collision in quarantine area (same recipe id already there)
    """
    recipe_path = recipe_path.expanduser().resolve()
    quarantine_dir = quarantine_dir.expanduser().resolve()

    if not recipe_path.exists():
        raise QuarantineError(f"recipe not found: {recipe_path}")
    if not recipe_path.is_file():
        raise QuarantineError(f"not a file: {recipe_path}")

    if prior_lifecycle is not None:
        # Sanity: the schema must agree this is a legal departure point.
        # Any of {candidate, validated, active} → quarantine is allowed.
        lifecycle.assert_transition(prior_lifecycle, lifecycle.STATE_QUARANTINE)

    quarantine_dir.mkdir(parents=True, exist_ok=True)

    recipe_id = recipe_path.stem
    dst_recipe = quarantine_dir / recipe_path.name
    sidecar = quarantine_dir / f"{recipe_id}{SIDECAR_SUFFIX}"

    if dst_recipe.exists() or sidecar.exists():
        raise QuarantineError(
            f"quarantine collision: {recipe_id!r} already present at "
            f"{quarantine_dir}"
        )

    sidecar_payload: dict[str, Any] = {
        "sidecar_schema_version": SIDECAR_SCHEMA_VERSION,
        "recipe_id": recipe_id,
        "reason": reason,
        "quarantined_at": _now_iso(),
        "fail_count": fail_count,
        "prior_lifecycle": prior_lifecycle,
        "origin_path": str(recipe_path),
        "sha256": _sha256(recipe_path),
    }

    # Two-phase: sidecar first, then recipe move. Cleanup sidecar if rename fails.
    _write_sidecar(sidecar, sidecar_payload)
    try:
        _atomic_move(recipe_path, dst_recipe)
    except OSError as exc:
        try:
            sidecar.unlink()
        except FileNotFoundError:
            pass
        raise QuarantineError(f"failed to move recipe: {exc}") from exc

    if event_log_path is not None:
        event_log.append(event_log_path, {
            "op": OP_QUARANTINE,
            "recipe_id": recipe_id,
            "from": prior_lifecycle,
            "to": lifecycle.STATE_QUARANTINE,
            "reason": reason,
            "fail_count": fail_count,
            "src_path": str(recipe_path),
            "dst_path": str(dst_recipe),
        })

    return MoveResult(
        op=OP_QUARANTINE,
        recipe_id=recipe_id,
        src_path=recipe_path,
        dst_path=dst_recipe,
        sidecar_path=sidecar,
    )


def restore(
    recipe_id: str,
    *,
    quarantine_dir: Path,
    target_path: Path | None = None,
    event_log_path: Path | None = None,
) -> MoveResult:
    """Take a recipe out of quarantine.

    By default the recipe goes back to its `origin_path` (recorded in the
    sidecar at quarantine time). Pass `target_path` to override.

    The sidecar is removed only after the recipe move succeeds.
    """
    quarantine_dir = quarantine_dir.expanduser().resolve()
    entry = _read_one_entry(recipe_id, quarantine_dir)

    dest = target_path.expanduser().resolve() if target_path else (
        Path(entry.origin_path).expanduser().resolve()
        if entry.origin_path else None
    )
    if dest is None:
        raise QuarantineError(
            f"no origin_path recorded for {recipe_id!r}; pass --to to override"
        )
    if dest.exists():
        raise QuarantineError(
            f"restore target already exists: {dest}; refusing to overwrite"
        )

    dest.parent.mkdir(parents=True, exist_ok=True)
    _atomic_move(entry.recipe_path, dest)

    # Sidecar removed last — keeps the journal honest if we crash mid-restore.
    try:
        entry.sidecar_path.unlink()
    except FileNotFoundError:
        pass

    if event_log_path is not None:
        event_log.append(event_log_path, {
            "op": OP_RESTORE,
            "recipe_id": recipe_id,
            "from": lifecycle.STATE_QUARANTINE,
            "to": entry.prior_lifecycle or "active",
            "src_path": str(entry.recipe_path),
            "dst_path": str(dest),
        })

    return MoveResult(
        op=OP_RESTORE,
        recipe_id=recipe_id,
        src_path=entry.recipe_path,
        dst_path=dest,
        sidecar_path=None,
    )


def archive(
    recipe_id: str,
    *,
    source_dir: Path,
    archive_dir: Path,
    reason: str = "archived",
    prior_lifecycle: str | None = None,
    event_log_path: Path | None = None,
) -> MoveResult:
    """One-way move from a source area (corpus or quarantine) to archive.

    Archive is terminal in the lifecycle FSM (no successor states leaving
    it back to active/validated). We do not write a sidecar in archive —
    the event log carries the audit trail; sidecar belongs to quarantine
    where restore needs origin info.
    """
    source_dir = source_dir.expanduser().resolve()
    archive_dir = archive_dir.expanduser().resolve()

    src_recipe = _find_recipe_in(source_dir, recipe_id)
    if src_recipe is None:
        raise QuarantineError(
            f"recipe {recipe_id!r} not found in {source_dir}"
        )

    if prior_lifecycle is not None:
        lifecycle.assert_transition(prior_lifecycle, lifecycle.STATE_ARCHIVED)

    archive_dir.mkdir(parents=True, exist_ok=True)
    dst = archive_dir / src_recipe.name
    if dst.exists():
        raise QuarantineError(
            f"archive collision: {recipe_id!r} already in {archive_dir}"
        )
    _atomic_move(src_recipe, dst)

    # If we are archiving from quarantine, take the sidecar along too.
    sidecar = source_dir / f"{recipe_id}{SIDECAR_SUFFIX}"
    if sidecar.exists():
        try:
            _atomic_move(sidecar, archive_dir / sidecar.name)
        except OSError:
            pass  # archived recipe is the important part

    if event_log_path is not None:
        event_log.append(event_log_path, {
            "op": OP_ARCHIVE,
            "recipe_id": recipe_id,
            "from": prior_lifecycle,
            "to": lifecycle.STATE_ARCHIVED,
            "reason": reason,
            "src_path": str(src_recipe),
            "dst_path": str(dst),
        })

    return MoveResult(
        op=OP_ARCHIVE,
        recipe_id=recipe_id,
        src_path=src_recipe,
        dst_path=dst,
        sidecar_path=None,
    )


# ----------------------------------------------------------------------------
# Public API — listings (read-only)
# ----------------------------------------------------------------------------

def list_quarantine(quarantine_dir: Path) -> list[QuarantineEntry]:
    """Enumerate quarantined recipes; pure read."""
    quarantine_dir = quarantine_dir.expanduser().resolve()
    if not quarantine_dir.exists():
        return []
    if not quarantine_dir.is_dir():
        raise NotADirectoryError(f"not a directory: {quarantine_dir}")

    entries: list[QuarantineEntry] = []
    for sidecar in sorted(quarantine_dir.glob(f"*{SIDECAR_SUFFIX}")):
        try:
            with sidecar.open("r", encoding="utf-8") as f:
                payload = json.load(f)
        except (OSError, json.JSONDecodeError):
            continue
        rid = payload.get("recipe_id")
        if not isinstance(rid, str):
            continue
        recipe = _find_recipe_in(quarantine_dir, rid)
        if recipe is None:
            # Orphaned sidecar; skip rather than crash.
            continue
        entries.append(QuarantineEntry(
            recipe_id=rid,
            recipe_path=recipe,
            sidecar_path=sidecar,
            reason=str(payload.get("reason", "")),
            quarantined_at=str(payload.get("quarantined_at", "")),
            fail_count=payload.get("fail_count"),
            prior_lifecycle=payload.get("prior_lifecycle"),
            origin_path=payload.get("origin_path"),
        ))
    return entries


# ----------------------------------------------------------------------------
# Renderers
# ----------------------------------------------------------------------------

def render_list_text(entries: Iterable[QuarantineEntry]) -> str:
    entries = list(entries)
    if not entries:
        return "(quarantine area is empty)"
    lines: list[str] = []
    lines.append(f"quarantined recipes: {len(entries)}")
    lines.append("")
    for e in entries:
        lines.append(f"  {e.recipe_id}")
        lines.append(f"      reason       : {e.reason}")
        lines.append(f"      quarantined  : {e.quarantined_at}")
        if e.fail_count is not None:
            lines.append(f"      fail_count   : {e.fail_count}")
        if e.prior_lifecycle:
            lines.append(f"      prior_state  : {e.prior_lifecycle}")
        if e.origin_path:
            lines.append(f"      origin       : {e.origin_path}")
        lines.append(f"      file         : {e.recipe_path}")
    return "\n".join(lines)


def render_list_json(entries: Iterable[QuarantineEntry]) -> str:
    payload = {
        "schema_version": 1,
        "entries": [
            {
                "recipe_id": e.recipe_id,
                "recipe_path": str(e.recipe_path),
                "sidecar_path": str(e.sidecar_path),
                "reason": e.reason,
                "quarantined_at": e.quarantined_at,
                "fail_count": e.fail_count,
                "prior_lifecycle": e.prior_lifecycle,
                "origin_path": e.origin_path,
            }
            for e in entries
        ],
    }
    return json.dumps(payload, indent=2, sort_keys=True)


# ----------------------------------------------------------------------------
# CLI bridge
# ----------------------------------------------------------------------------

def cli_list(quarantine_dir: str, *, json_output: bool = False) -> int:
    try:
        entries = list_quarantine(Path(quarantine_dir))
    except (FileNotFoundError, NotADirectoryError) as exc:
        print(f"contrecipe: {exc}", file=sys.stderr)
        return EXIT_BAD_PATH
    rendered = render_list_json(entries) if json_output else render_list_text(entries)
    print(rendered)
    return EXIT_OK


def cli_quarantine(
    recipe_path: str,
    *,
    quarantine_dir: str,
    reason: str,
    fail_count: int | None = None,
    prior_lifecycle: str | None = None,
    event_log_path: str | None = None,
) -> int:
    try:
        result = quarantine(
            Path(recipe_path),
            quarantine_dir=Path(quarantine_dir),
            reason=reason,
            fail_count=fail_count,
            prior_lifecycle=prior_lifecycle,
            event_log_path=Path(event_log_path) if event_log_path else None,
        )
    except QuarantineError as exc:
        print(f"contrecipe: {exc}", file=sys.stderr)
        return EXIT_QUARANTINE_ERROR
    except (lifecycle.IllegalTransition, lifecycle.UnknownState) as exc:
        print(f"contrecipe: lifecycle error — {exc}", file=sys.stderr)
        return EXIT_QUARANTINE_ERROR
    print(f"quarantined: {result.recipe_id} → {result.dst_path}")
    return EXIT_OK


def cli_restore(
    recipe_id: str,
    *,
    quarantine_dir: str,
    target_path: str | None = None,
    event_log_path: str | None = None,
) -> int:
    try:
        result = restore(
            recipe_id,
            quarantine_dir=Path(quarantine_dir),
            target_path=Path(target_path) if target_path else None,
            event_log_path=Path(event_log_path) if event_log_path else None,
        )
    except QuarantineError as exc:
        print(f"contrecipe: {exc}", file=sys.stderr)
        return EXIT_QUARANTINE_ERROR
    print(f"restored: {result.recipe_id} → {result.dst_path}")
    return EXIT_OK


def cli_archive(
    recipe_id: str,
    *,
    source_dir: str,
    archive_dir: str,
    reason: str = "archived",
    prior_lifecycle: str | None = None,
    event_log_path: str | None = None,
) -> int:
    try:
        result = archive(
            recipe_id,
            source_dir=Path(source_dir),
            archive_dir=Path(archive_dir),
            reason=reason,
            prior_lifecycle=prior_lifecycle,
            event_log_path=Path(event_log_path) if event_log_path else None,
        )
    except QuarantineError as exc:
        print(f"contrecipe: {exc}", file=sys.stderr)
        return EXIT_QUARANTINE_ERROR
    except (lifecycle.IllegalTransition, lifecycle.UnknownState) as exc:
        print(f"contrecipe: lifecycle error — {exc}", file=sys.stderr)
        return EXIT_QUARANTINE_ERROR
    print(f"archived: {result.recipe_id} → {result.dst_path}")
    return EXIT_OK


# ----------------------------------------------------------------------------
# Internal helpers
# ----------------------------------------------------------------------------

def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _atomic_move(src: Path, dst: Path) -> None:
    """Try same-FS rename; fall back to shutil.move across devices."""
    try:
        os.rename(src, dst)
    except OSError as exc:
        # EXDEV (cross-device) is the only legitimate fallback case.
        # Any other OSError propagates.
        if getattr(exc, "errno", None) is None:
            raise
        # Defensive: shutil handles a wider range cleanly.
        shutil.move(str(src), str(dst))


def _write_sidecar(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, sort_keys=True, ensure_ascii=False)
        f.write("\n")
    os.replace(tmp, path)


def _find_recipe_in(directory: Path, recipe_id: str) -> Path | None:
    for ext in (".yaml", ".yml"):
        candidate = directory / f"{recipe_id}{ext}"
        if candidate.is_file():
            return candidate
    return None


def _read_one_entry(recipe_id: str, quarantine_dir: Path) -> QuarantineEntry:
    sidecar = quarantine_dir / f"{recipe_id}{SIDECAR_SUFFIX}"
    if not sidecar.exists():
        raise QuarantineError(
            f"no sidecar for {recipe_id!r} in {quarantine_dir}"
        )
    with sidecar.open("r", encoding="utf-8") as f:
        payload = json.load(f)
    recipe = _find_recipe_in(quarantine_dir, recipe_id)
    if recipe is None:
        raise QuarantineError(
            f"sidecar present but recipe missing for {recipe_id!r}"
        )
    return QuarantineEntry(
        recipe_id=recipe_id,
        recipe_path=recipe,
        sidecar_path=sidecar,
        reason=str(payload.get("reason", "")),
        quarantined_at=str(payload.get("quarantined_at", "")),
        fail_count=payload.get("fail_count"),
        prior_lifecycle=payload.get("prior_lifecycle"),
        origin_path=payload.get("origin_path"),
    )
