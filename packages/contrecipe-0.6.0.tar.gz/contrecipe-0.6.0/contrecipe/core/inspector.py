# v1 | 2026-05-03 | Sprint R2 — read-only corpus reader, statistics, phantom scan
"""Recipe corpus inspector.

This module is **strictly read-only**: it parses every yaml file under a
recipes/ directory and computes counts. It does NOT validate against the
canonical schema (R3), compile (R4), or quarantine (R5). Its single
responsibility is to make the state of a corpus legible.

Output:
    1. A `RecipeInventory` (immutable parse result, with per-file errors)
    2. A `CorpusReport` (aggregate counters + phantom worker map)
    3. Renderers: `render_text` for terminal, `render_json` for tooling

Audit findings the inspector surfaces (without judging):
    - schema drift: steps using `action`/`args` instead of `worker`/`params`
    - dead-code reuse: recipes with `uses:` field
    - missing on_fail: count of steps with no on_fail (audit said 0/431)
    - phantom workers: recipes referencing forbidden_workers in the schema

R3 will turn these counts into accept/reject decisions; R2 only reports.
"""

from __future__ import annotations

import json
import sys
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable, Mapping, Sequence

import yaml

from contrecipe.core._schema import load_canonical_schema

# ----------------------------------------------------------------------------
# Constants
# ----------------------------------------------------------------------------

RECIPE_GLOBS = ("*.yaml", "*.yml")

# Top-level recipe fields the schema cares about. Used for presence counts.
RECIPE_FIELDS = (
    "id",
    "version",
    "triggers",
    "steps",
    "description",
    "tags",
    "author",
    "lifecycle",
    "replaces",
)

# Step fields the schema cares about. Used for presence counts.
STEP_FIELDS = (
    "worker",
    "params",
    "verify",
    "output",
    "on_fail",
    "retries",
    "uses",
)

# Schema-drift fields: legacy / runtime-mismatched names that should NOT
# appear in a clean corpus. We only count them; we do not reject in R2.
DRIFT_STEP_FIELDS = ("action", "args")

# Top-N workers shown in human-readable rendering.
TOP_WORKERS_RENDERED = 15

# Exit codes (mirrored in cli.py contract for `inspect` subcommand)
EXIT_OK = 0
EXIT_INSPECT_ISSUES_FOUND = 1   # parse errors or phantom workers present
EXIT_INSPECT_BAD_PATH = 3


# ----------------------------------------------------------------------------
# Data model — all immutable
# ----------------------------------------------------------------------------

@dataclass(frozen=True)
class ParseError:
    """A recipe file that did not parse to a usable mapping."""
    path: Path
    message: str


@dataclass(frozen=True)
class ParsedRecipe:
    """A successfully parsed recipe yaml.

    `raw` is the exact yaml-loaded mapping; the inspector does not normalise
    or coerce — that is R3's job. Fields may be missing, mistyped, or extra.
    """
    path: Path
    raw: Mapping[str, object]


@dataclass(frozen=True)
class RecipeInventory:
    """Immutable snapshot of a corpus on disk."""
    root: Path
    recipes: tuple[ParsedRecipe, ...]
    parse_errors: tuple[ParseError, ...]
    scanned_at: str  # ISO 8601 UTC

    @property
    def total_recipes(self) -> int:
        return len(self.recipes)

    @property
    def total_steps(self) -> int:
        return sum(_count_steps(r.raw) for r in self.recipes)


@dataclass(frozen=True)
class CorpusReport:
    """Aggregate, schema-aware counts over an inventory.

    Schema-aware in a *passive* sense: we use the schema to know which
    worker names are forbidden and which verify methods are recognised,
    but we do not call the validator and we do not produce verdicts.
    """
    inventory: RecipeInventory
    recipe_field_presence: Mapping[str, int]
    step_field_presence: Mapping[str, int]
    verify_methods: Mapping[str, int]    # includes "(unknown)" bucket
    workers: Mapping[str, int]
    on_fail_distribution: Mapping[str, int]
    lifecycle_distribution: Mapping[str, int]
    phantom_workers: Mapping[str, tuple[Path, ...]]   # forbidden → recipes
    drift_signals: Mapping[str, int]     # 'action_field_used', 'uses_field_used', etc.

    @property
    def total_recipes(self) -> int:
        return self.inventory.total_recipes

    @property
    def total_steps(self) -> int:
        return self.inventory.total_steps

    @property
    def has_issues(self) -> bool:
        return bool(self.inventory.parse_errors) or bool(self.phantom_workers)


# ----------------------------------------------------------------------------
# Public API — read + analyse + render
# ----------------------------------------------------------------------------

def read_corpus(root: Path) -> RecipeInventory:
    """Walk `root`, parse every recipe yaml, collect parse errors.

    The function never raises on a bad file; failures land in `parse_errors`.
    It does raise if `root` itself is missing or not a directory — that is a
    caller error, not a corpus condition.
    """
    root = root.expanduser().resolve()
    if not root.exists():
        raise FileNotFoundError(f"corpus root does not exist: {root}")
    if not root.is_dir():
        raise NotADirectoryError(f"corpus root is not a directory: {root}")

    recipes: list[ParsedRecipe] = []
    errors: list[ParseError] = []

    for path in _iter_recipe_paths(root):
        try:
            text = path.read_text(encoding="utf-8")
        except OSError as exc:
            errors.append(ParseError(path=path, message=f"read failed: {exc}"))
            continue
        try:
            data = yaml.safe_load(text)
        except yaml.YAMLError as exc:
            errors.append(ParseError(path=path, message=f"yaml parse: {exc}"))
            continue
        if not isinstance(data, dict):
            errors.append(
                ParseError(
                    path=path,
                    message=(
                        f"top-level is {type(data).__name__}, expected mapping"
                    ),
                )
            )
            continue
        recipes.append(ParsedRecipe(path=path, raw=data))

    scanned_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
    return RecipeInventory(
        root=root,
        recipes=tuple(recipes),
        parse_errors=tuple(errors),
        scanned_at=scanned_at,
    )


def build_report(inventory: RecipeInventory) -> CorpusReport:
    """Compute aggregate statistics over an inventory.

    Pure function: no I/O, no mutation of the inventory.
    """
    schema = load_canonical_schema()
    forbidden = set(schema.get("forbidden_workers", []) or ())
    allowed_verify = set(
        (schema.get("verify", {}) or {}).get("allowed_methods", {}) or {}
    )

    recipe_field_presence: Counter[str] = Counter()
    step_field_presence: Counter[str] = Counter()
    verify_methods: Counter[str] = Counter()
    workers: Counter[str] = Counter()
    on_fail_distribution: Counter[str] = Counter()
    lifecycle_distribution: Counter[str] = Counter()
    phantom: dict[str, list[Path]] = {}
    drift = Counter[str]()

    for parsed in inventory.recipes:
        for f in RECIPE_FIELDS:
            if f in parsed.raw:
                recipe_field_presence[f] += 1

        lifecycle = parsed.raw.get("lifecycle")
        if isinstance(lifecycle, str):
            lifecycle_distribution[lifecycle] += 1

        if parsed.raw.get("uses"):
            drift["uses_field_used_at_recipe_level"] += 1

        steps = parsed.raw.get("steps") or []
        if not isinstance(steps, list):
            # malformed steps; we only count it as drift, R3 will reject
            drift["steps_not_a_list"] += 1
            continue

        for step in steps:
            if not isinstance(step, dict):
                drift["step_not_a_mapping"] += 1
                continue

            for f in STEP_FIELDS:
                if f in step:
                    step_field_presence[f] += 1

            for f in DRIFT_STEP_FIELDS:
                if f in step:
                    drift[f"{f}_field_used_at_step_level"] += 1

            if step.get("uses"):
                drift["uses_field_used_at_step_level"] += 1

            worker = step.get("worker")
            if isinstance(worker, str):
                workers[worker] += 1
                if worker in forbidden:
                    phantom.setdefault(worker, []).append(parsed.path)

            verify = step.get("verify")
            if isinstance(verify, dict):
                method = verify.get("method")
                if isinstance(method, str):
                    bucket = method if method in allowed_verify else "(unknown)"
                    verify_methods[bucket] += 1
                else:
                    verify_methods["(missing-method)"] += 1
            elif "verify" in step:
                verify_methods["(malformed)"] += 1
            else:
                verify_methods["(absent)"] += 1

            on_fail = step.get("on_fail")
            on_fail_distribution[on_fail if isinstance(on_fail, str) else "(absent)"] += 1

    return CorpusReport(
        inventory=inventory,
        recipe_field_presence=dict(recipe_field_presence),
        step_field_presence=dict(step_field_presence),
        verify_methods=dict(verify_methods),
        workers=dict(workers),
        on_fail_distribution=dict(on_fail_distribution),
        lifecycle_distribution=dict(lifecycle_distribution),
        phantom_workers={
            w: tuple(paths) for w, paths in phantom.items()
        },
        drift_signals=dict(drift),
    )


def render_text(report: CorpusReport) -> str:
    """Human-readable rendering for terminal output."""
    inv = report.inventory
    lines: list[str] = []
    lines.append(f"contrecipe inspect — {inv.scanned_at}")
    lines.append(f"corpus root  : {inv.root}")
    lines.append(f"recipes      : {report.total_recipes}")
    lines.append(f"steps        : {report.total_steps}")
    if report.total_recipes:
        mean = report.total_steps / report.total_recipes
        lines.append(f"steps/recipe : {mean:.2f}")
    lines.append("")

    if inv.parse_errors:
        lines.append(f"parse errors ({len(inv.parse_errors)}):")
        for err in inv.parse_errors:
            lines.append(f"  - {err.path.name}: {err.message}")
        lines.append("")

    lines.append("recipe-level field presence")
    for f in RECIPE_FIELDS:
        n = report.recipe_field_presence.get(f, 0)
        lines.append(f"  {f:14s} : {n:>5d} / {report.total_recipes}")
    lines.append("")

    lines.append("step-level field presence")
    for f in STEP_FIELDS:
        n = report.step_field_presence.get(f, 0)
        lines.append(f"  {f:14s} : {n:>5d} / {report.total_steps}")
    lines.append("")

    lines.append("verify methods")
    for method, n in sorted(
        report.verify_methods.items(), key=lambda kv: (-kv[1], kv[0])
    ):
        lines.append(f"  {method:18s} : {n:>5d}")
    lines.append("")

    lines.append(f"workers (top {TOP_WORKERS_RENDERED})")
    top = sorted(report.workers.items(), key=lambda kv: (-kv[1], kv[0]))
    for worker, n in top[:TOP_WORKERS_RENDERED]:
        lines.append(f"  {worker:24s} : {n:>5d}")
    if len(top) > TOP_WORKERS_RENDERED:
        rest = sum(n for _, n in top[TOP_WORKERS_RENDERED:])
        lines.append(f"  {'(other)':24s} : {rest:>5d}  ({len(top) - TOP_WORKERS_RENDERED} more)")
    lines.append("")

    lines.append("on_fail distribution")
    for v, n in sorted(
        report.on_fail_distribution.items(), key=lambda kv: (-kv[1], kv[0])
    ):
        lines.append(f"  {v:14s} : {n:>5d}")
    lines.append("")

    if report.lifecycle_distribution:
        lines.append("lifecycle distribution")
        for v, n in sorted(
            report.lifecycle_distribution.items(), key=lambda kv: (-kv[1], kv[0])
        ):
            lines.append(f"  {v:14s} : {n:>5d}")
        lines.append("")

    lines.append("phantom / forbidden workers")
    if not report.phantom_workers:
        lines.append("  (none)")
    else:
        for worker, paths in sorted(report.phantom_workers.items()):
            lines.append(f"  {worker:24s} : {len(paths):>3d} recipe(s)")
            for p in paths:
                lines.append(f"      {p.name}")
    lines.append("")

    lines.append("schema-drift signals")
    if not report.drift_signals:
        lines.append("  (none)")
    else:
        for signal, n in sorted(
            report.drift_signals.items(), key=lambda kv: (-kv[1], kv[0])
        ):
            lines.append(f"  {signal:40s} : {n:>5d}")
    lines.append("")

    return "\n".join(lines)


def render_json(report: CorpusReport) -> str:
    """Machine-readable rendering for tooling and tests."""
    inv = report.inventory
    payload = {
        "schema_version": 1,
        "scanned_at": inv.scanned_at,
        "corpus_root": str(inv.root),
        "totals": {
            "recipes": report.total_recipes,
            "steps": report.total_steps,
            "parse_errors": len(inv.parse_errors),
        },
        "parse_errors": [
            {"path": str(e.path), "message": e.message} for e in inv.parse_errors
        ],
        "recipe_field_presence": dict(report.recipe_field_presence),
        "step_field_presence": dict(report.step_field_presence),
        "verify_methods": dict(report.verify_methods),
        "workers": dict(report.workers),
        "on_fail_distribution": dict(report.on_fail_distribution),
        "lifecycle_distribution": dict(report.lifecycle_distribution),
        "phantom_workers": {
            w: [str(p) for p in paths]
            for w, paths in report.phantom_workers.items()
        },
        "drift_signals": dict(report.drift_signals),
    }
    return json.dumps(payload, indent=2, sort_keys=True)


# ----------------------------------------------------------------------------
# CLI bridge
# ----------------------------------------------------------------------------

def run_cli(path_str: str, *, json_output: bool = False) -> int:
    """Entry point for the `contrecipe inspect <path>` subcommand.

    Returns:
        EXIT_OK if the corpus is clean (no parse errors, no phantom workers).
        EXIT_INSPECT_ISSUES_FOUND if there are issues (still printed in full).
        EXIT_INSPECT_BAD_PATH if the path does not exist or is not a dir.

    Drift signals do NOT fail the exit code: they are informational.
    """
    root = Path(path_str)
    try:
        inventory = read_corpus(root)
    except (FileNotFoundError, NotADirectoryError) as exc:
        print(f"contrecipe: {exc}", file=sys.stderr)
        return EXIT_INSPECT_BAD_PATH

    report = build_report(inventory)

    rendered = render_json(report) if json_output else render_text(report)
    print(rendered)

    return EXIT_INSPECT_ISSUES_FOUND if report.has_issues else EXIT_OK


# ----------------------------------------------------------------------------
# Internal helpers
# ----------------------------------------------------------------------------

def _iter_recipe_paths(root: Path) -> Iterable[Path]:
    seen: set[Path] = set()
    for pattern in RECIPE_GLOBS:
        for p in root.rglob(pattern):
            if p.is_file() and p not in seen:
                seen.add(p)
                yield p


def _count_steps(raw: Mapping[str, object]) -> int:
    steps = raw.get("steps")
    return len(steps) if isinstance(steps, list) else 0
