# v1 | 2026-05-03 | Sprint R1 — core namespace; modules ship per sprint
"""Core implementation modules.

Sprint R2 will add: inspector.py
Sprint R3 will add: validator.py, registry.py
Sprint R4 will add: compiler.py
Sprint R5 will add: quarantine.py, lifecycle.py
Sprint R6 will add: proposal_inbox.py
Sprint R7 will add: corpus_writer.py
Later: llm_client.py, reuse_analyzer.py, test_harness.py
"""
