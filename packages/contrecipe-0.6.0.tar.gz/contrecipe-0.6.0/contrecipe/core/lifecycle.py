# v1 | 2026-05-03 | Sprint R5 — recipe lifecycle FSM (schema-driven)
"""Recipe lifecycle state machine.

The canonical schema (`recipe_v1.schema.yaml`) lists the legal states and
transitions. This module is the *enforcer*: given a (from_state, to_state)
pair, it answers "is this transition allowed?" with a deterministic bool.
The schema is the source of truth; this module never reimplements it.

States (from schema):
    candidate    written, not yet validated
    validated    passed schema + registry checks; trial period
    active       in production
    quarantine   protective isolation (e.g. 5+ verify fails)
    archived     no longer used
    poisoned     contamination detected; permanently blocked

Transitions are loaded from `lifecycle_states` + `allowed_transitions`
in the schema. Anything else raises `IllegalTransition`.

Why a separate module: R5 introduces the first state-changing operations
in `contrecipe`. Centralising the FSM keeps state-change logic in exactly
one place — quarantine, restore, archive all delegate here before they
touch the filesystem.
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from typing import FrozenSet

from contrecipe.core._schema import load_canonical_schema

# ----------------------------------------------------------------------------
# State constants — convenience for callers
# ----------------------------------------------------------------------------

STATE_CANDIDATE = "candidate"
STATE_VALIDATED = "validated"
STATE_ACTIVE = "active"
STATE_QUARANTINE = "quarantine"
STATE_ARCHIVED = "archived"
STATE_POISONED = "poisoned"


# ----------------------------------------------------------------------------
# Errors
# ----------------------------------------------------------------------------

class IllegalTransition(Exception):
    """Raised when a (from_state, to_state) is not in the schema."""


class UnknownState(Exception):
    """Raised when a state name is not recognised."""


# ----------------------------------------------------------------------------
# Schema-driven facts (cached)
# ----------------------------------------------------------------------------

@lru_cache(maxsize=1)
def known_states() -> FrozenSet[str]:
    schema = load_canonical_schema()
    states = schema.get("lifecycle_states") or ()
    return frozenset(s for s in states if isinstance(s, str))


@lru_cache(maxsize=1)
def allowed_transitions() -> FrozenSet[tuple[str, str]]:
    schema = load_canonical_schema()
    raw = schema.get("allowed_transitions") or ()
    out: set[tuple[str, str]] = set()
    for entry in raw:
        if (
            isinstance(entry, (list, tuple))
            and len(entry) == 2
            and isinstance(entry[0], str)
            and isinstance(entry[1], str)
        ):
            out.add((entry[0], entry[1]))
    return frozenset(out)


# ----------------------------------------------------------------------------
# Public API
# ----------------------------------------------------------------------------

def is_known_state(state: str) -> bool:
    return state in known_states()


def is_allowed(from_state: str, to_state: str) -> bool:
    """Pure boolean check; never raises."""
    return (from_state, to_state) in allowed_transitions()


def assert_transition(from_state: str, to_state: str) -> None:
    """Raise IllegalTransition unless the move is allowed."""
    if not is_known_state(from_state):
        raise UnknownState(f"unknown lifecycle state: {from_state!r}")
    if not is_known_state(to_state):
        raise UnknownState(f"unknown lifecycle state: {to_state!r}")
    if not is_allowed(from_state, to_state):
        raise IllegalTransition(
            f"transition {from_state!r} → {to_state!r} is not allowed; "
            f"see canonical schema 'allowed_transitions'"
        )


def successors_of(state: str) -> FrozenSet[str]:
    """All states reachable in one step from `state`."""
    if not is_known_state(state):
        raise UnknownState(f"unknown lifecycle state: {state!r}")
    return frozenset(b for (a, b) in allowed_transitions() if a == state)
