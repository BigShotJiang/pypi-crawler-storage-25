# v1 | 2026-05-03 | Sprint R3 — tool registry abstraction (3 implementations)
"""Tool registry abstraction.

The validator needs to answer one question about each step's worker:
  "Is this name a real tool?"

The answer source varies:
  - In tests / standalone use:  no registry, or a small static set.
  - In production:              a JSON dump produced by Cont's tool
                                inventory command (banking environment;
                                offline; no Python import dependency).

Decoupling via this interface keeps `contrecipe` independent of `codent`'s
import path and lets us bench the validator against any registry source
later (e.g. a sqlite snapshot, a yaml manifest, a plug-in).

Conventions:
  - `is_known(worker)` returns False for unknown names.
  - `known_workers()` is best-effort (not all registries can enumerate;
    in that case it returns an empty set and `is_known` does the work).
  - `is_introspective` says whether absence-of-a-name is a reliable
    "worker does not exist" signal. EmptyRegistry is NOT introspective.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Protocol, runtime_checkable


@runtime_checkable
class ToolRegistry(Protocol):
    """Anything the validator can ask about worker names."""

    def is_known(self, worker: str) -> bool: ...
    def known_workers(self) -> frozenset[str]: ...

    @property
    def is_introspective(self) -> bool:
        """True iff missing-from-registry is a reliable rejection signal."""
        ...


@dataclass(frozen=True)
class EmptyRegistry:
    """Knows nothing. Validator will skip the 'unknown worker' check.

    Forbidden-workers logic still runs (it reads the canonical schema,
    not the registry), so contamination signatures are still caught.
    """

    is_introspective: bool = False

    def is_known(self, worker: str) -> bool:  # noqa: ARG002
        return False

    def known_workers(self) -> frozenset[str]:
        return frozenset()


@dataclass(frozen=True)
class StaticRegistry:
    """A fixed set of known worker names. Useful in tests."""

    _workers: frozenset[str]
    is_introspective: bool = True

    @classmethod
    def of(cls, workers: Iterable[str]) -> "StaticRegistry":
        return cls(_workers=frozenset(workers))

    def is_known(self, worker: str) -> bool:
        return worker in self._workers

    def known_workers(self) -> frozenset[str]:
        return self._workers


class JsonFileRegistry:
    """Loads a registry dump from a JSON file.

    Expected file shape (R10 will define the canonical Cont dump format;
    here we accept the simplest shape and a slightly richer one):

        {"workers": ["run_shell", "list_dir", ...]}                   # minimal
        {"workers": {"run_shell": {...schema...}, "list_dir": {...}}} # rich

    Either form yields the same `known_workers()` set in R3. The schema
    metadata (when present) is held in `_meta` for R4+ to consume.

    Lazy loading is intentional: instantiating a registry that points at
    a missing file should not crash; the call to `known_workers` does.
    """

    def __init__(self, path: Path) -> None:
        self._path = path
        self._cache_workers: frozenset[str] | None = None
        self._meta: dict[str, dict[str, object]] | None = None

    is_introspective: bool = True

    def _load(self) -> None:
        with self._path.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
        if not isinstance(data, dict) or "workers" not in data:
            raise ValueError(
                f"registry file {self._path} is not a mapping with 'workers'"
            )
        workers = data["workers"]
        if isinstance(workers, list):
            names = frozenset(str(w) for w in workers)
            self._meta = {}
        elif isinstance(workers, dict):
            names = frozenset(workers.keys())
            self._meta = {
                k: v for k, v in workers.items() if isinstance(v, dict)
            }
        else:
            raise ValueError(
                f"'workers' in {self._path} is {type(workers).__name__}, "
                "expected list or mapping"
            )
        self._cache_workers = names

    def is_known(self, worker: str) -> bool:
        if self._cache_workers is None:
            self._load()
        assert self._cache_workers is not None
        return worker in self._cache_workers

    def known_workers(self) -> frozenset[str]:
        if self._cache_workers is None:
            self._load()
        assert self._cache_workers is not None
        return self._cache_workers
