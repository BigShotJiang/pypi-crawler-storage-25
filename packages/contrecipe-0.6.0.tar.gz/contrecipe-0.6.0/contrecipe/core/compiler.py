# v1 | 2026-05-03 | Sprint R4 — recipe compiler (source → ExecutablePlan)
"""Recipe compiler.

Transforms a *source-form* recipe (what humans / Cont write) into an
*executable plan* — an immutable, position-stable, JSON-serialisable
descriptor that the Cont runtime can execute deterministically.

Pipeline (LLVM-style; Babel-style; same shape every compiler has):

    source_recipe              # raw yaml-loaded mapping
        │
        ▼  validate_recipe()   # R3 — must return verdict=valid; else fail-fast
        │
        ▼  desugar / fill defaults
        │     - on_fail: 'abort' if absent
        │     - retries: 0 if absent
        │     - lifecycle: 'candidate' if absent
        │     - author: 'cont' if absent
        │
        ▼  assign step ids     # 's001', 's002', ...; position-stable
        │
        ▼  build symbol table  # output_name → step_id (e.g. result_1 → s001)
        │
        ▼  resolve references  # ${result_1} in params → ${s001}
        │
        ▼  emit ExecutablePlan
        │
        ▼  validate plan       # invariants (unique IDs, all refs resolved)
        │
        ▼  done

The compiler **never executes**. The Cont runtime (R10) consumes
`ExecutablePlan.to_dict()` and dispatches.

Why these particular passes:
  - Defaults filled at compile-time means the runtime never has to
    interpret 'absent on_fail' — it sees a concrete, decided value.
  - Step IDs decouple references from authoring order. If a recipe is
    refactored (steps reordered), output names stay valid and refs
    re-resolve cleanly.
  - Reference resolution at compile-time turns a runtime question
    ("does this name exist?") into a compile-time bool — pDNA axiom.

Failure model:
  - `compile_recipe` raises `CompileError` with a structured cause when
    the input is not compilable. The validator runs first; if its verdict
    is not `valid`, the validator's findings are wrapped into the error
    so the caller sees exactly what blocked compilation.
  - Reference-resolution failures (`${unknown}`) are compile errors.
  - Duplicate output names are compile errors (would shadow at runtime).
"""

from __future__ import annotations

import json
import re
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import yaml

from contrecipe.core import validator as _validator
from contrecipe.core._registry import ToolRegistry
from contrecipe.core.validator import ValidationResult

# ----------------------------------------------------------------------------
# Constants
# ----------------------------------------------------------------------------

PLAN_SCHEMA_VERSION = 1
STEP_ID_FORMAT = "s{:03d}"          # s001, s002, ...; supports 999 steps/recipe
REF_PATTERN = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")

# CLI exit codes
EXIT_OK = 0
EXIT_COMPILE_ERROR = 1
EXIT_BAD_PATH = 3


# ----------------------------------------------------------------------------
# Errors
# ----------------------------------------------------------------------------

@dataclass(frozen=True)
class CompileError(Exception):
    """Raised when a recipe cannot be compiled.

    `validation` is the validator result when the failure was caused by
    upstream validation (verdict != valid). For pure compile-time
    failures (duplicate output names, unresolved refs) it is None.
    """
    message: str
    validation: ValidationResult | None = None
    detail: tuple[str, ...] = ()

    def __str__(self) -> str:  # for traceback readability
        return self.message


# ----------------------------------------------------------------------------
# Plan data model — immutable, JSON-friendly
# ----------------------------------------------------------------------------

@dataclass(frozen=True)
class CompiledStep:
    """One step of an executable plan.

    All fields are concrete (no defaults left for the runtime to fill in).
    """
    id: str                              # e.g. 's001'
    worker: str
    params: Mapping[str, Any]
    verify: Mapping[str, Any]
    output: str
    on_fail: str                         # always present after desugar
    retries: int                         # always present after desugar


@dataclass(frozen=True)
class ExecutablePlan:
    """Compiled, runtime-ready descriptor of a recipe.

    Serialise via `to_dict()` / `to_json()`; deserialise via `from_dict()`.
    """
    plan_schema_version: int
    recipe_id: str
    recipe_version: int
    triggers: tuple[str, ...]
    steps: tuple[CompiledStep, ...]
    symbol_table: Mapping[str, str]      # output_name → step_id
    metadata: Mapping[str, Any]          # description, tags, author, lifecycle

    def to_dict(self) -> dict[str, Any]:
        return {
            "plan_schema_version": self.plan_schema_version,
            "recipe_id": self.recipe_id,
            "recipe_version": self.recipe_version,
            "triggers": list(self.triggers),
            "steps": [
                {
                    "id": s.id,
                    "worker": s.worker,
                    "params": dict(s.params),
                    "verify": dict(s.verify),
                    "output": s.output,
                    "on_fail": s.on_fail,
                    "retries": s.retries,
                }
                for s in self.steps
            ],
            "symbol_table": dict(self.symbol_table),
            "metadata": dict(self.metadata),
        }

    def to_json(self, *, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, sort_keys=True)


# ----------------------------------------------------------------------------
# Public API
# ----------------------------------------------------------------------------

def compile_recipe(
    raw: Mapping[str, Any],
    *,
    registry: ToolRegistry | None = None,
    skip_validation: bool = False,
) -> ExecutablePlan:
    """Compile a parsed source recipe into an ExecutablePlan.

    By default the validator runs first; pass `skip_validation=True` only
    in very tightly-scoped tests that need to exercise a compile pass in
    isolation. Production callers should never set it.
    """
    if not skip_validation:
        result = _validator.validate_recipe(raw, registry=registry)
        if not result.is_valid:
            raise CompileError(
                message=(
                    f"recipe verdict is {result.verdict!r}; only 'valid' "
                    "recipes can be compiled"
                ),
                validation=result,
            )

    desugared = _desugar(raw)
    compiled_steps, symbol_table = _build_steps_and_symbols(desugared["steps"])
    compiled_steps = _resolve_references(compiled_steps, symbol_table)
    _check_invariants(compiled_steps, symbol_table)

    metadata = {
        k: desugared[k]
        for k in ("description", "tags", "author", "lifecycle")
        if k in desugared
    }

    return ExecutablePlan(
        plan_schema_version=PLAN_SCHEMA_VERSION,
        recipe_id=desugared["id"],
        recipe_version=desugared["version"],
        triggers=tuple(desugared["triggers"]),
        steps=tuple(compiled_steps),
        symbol_table=dict(symbol_table),
        metadata=metadata,
    )


def compile_file(
    path: Path,
    *,
    registry: ToolRegistry | None = None,
) -> ExecutablePlan:
    """Compile a recipe from a yaml file."""
    path = path.expanduser().resolve()
    if not path.exists():
        raise FileNotFoundError(f"recipe file does not exist: {path}")
    if not path.is_file():
        raise IsADirectoryError(f"expected a file, got: {path}")
    text = path.read_text(encoding="utf-8")
    raw = yaml.safe_load(text)
    if not isinstance(raw, dict):
        raise CompileError(
            message=(
                f"recipe top-level is {type(raw).__name__}, expected mapping"
            ),
        )
    return compile_recipe(raw, registry=registry)


# ----------------------------------------------------------------------------
# Renderers
# ----------------------------------------------------------------------------

def render_text(plan: ExecutablePlan) -> str:
    lines: list[str] = []
    lines.append(f"contrecipe compile — plan v{plan.plan_schema_version}")
    lines.append(f"recipe   : {plan.recipe_id} (v{plan.recipe_version})")
    lines.append(f"triggers : {len(plan.triggers)}")
    lines.append(f"steps    : {len(plan.steps)}")
    lines.append("")
    lines.append("symbol table")
    if not plan.symbol_table:
        lines.append("  (empty)")
    else:
        for name, sid in plan.symbol_table.items():
            lines.append(f"  {name:24s} → {sid}")
    lines.append("")
    lines.append("steps")
    for s in plan.steps:
        lines.append(f"  {s.id} {s.worker}")
        lines.append(f"      params  : {dict(s.params)}")
        lines.append(f"      verify  : {dict(s.verify)}")
        lines.append(f"      output  : {s.output}")
        lines.append(f"      on_fail : {s.on_fail} (retries={s.retries})")
    return "\n".join(lines)


def render_json(plan: ExecutablePlan) -> str:
    return plan.to_json()


# ----------------------------------------------------------------------------
# CLI bridge
# ----------------------------------------------------------------------------

def run_cli(
    recipe_path: str,
    *,
    json_output: bool = False,
    registry_path: str | None = None,
) -> int:
    """Entry for `contrecipe compile <recipe>`."""
    registry: ToolRegistry | None = None
    if registry_path:
        from contrecipe.core._registry import JsonFileRegistry
        registry = JsonFileRegistry(Path(registry_path))

    try:
        plan = compile_file(Path(recipe_path), registry=registry)
    except (FileNotFoundError, IsADirectoryError) as exc:
        print(f"contrecipe: {exc}", file=sys.stderr)
        return EXIT_BAD_PATH
    except CompileError as exc:
        print(f"contrecipe: compile failed — {exc.message}", file=sys.stderr)
        if exc.validation is not None:
            for f in exc.validation.findings:
                print(f.render(), file=sys.stderr)
        for d in exc.detail:
            print(f"  {d}", file=sys.stderr)
        return EXIT_COMPILE_ERROR
    except (OSError, ValueError) as exc:
        print(f"contrecipe: {exc}", file=sys.stderr)
        return EXIT_BAD_PATH

    print(render_json(plan) if json_output else render_text(plan))
    return EXIT_OK


# ----------------------------------------------------------------------------
# Internal passes
# ----------------------------------------------------------------------------

def _desugar(raw: Mapping[str, Any]) -> dict[str, Any]:
    """Apply schema defaults to a copy of `raw`. Pure; no mutation."""
    out: dict[str, Any] = dict(raw)

    out.setdefault("author", "cont")
    out.setdefault("lifecycle", "candidate")

    new_steps: list[dict[str, Any]] = []
    for step in out.get("steps", []) or []:
        step_copy: dict[str, Any] = dict(step)
        step_copy.setdefault("on_fail", "abort")
        step_copy.setdefault("retries", 0)
        # Defensive: copy nested params/verify so caller's dict is untouched
        if isinstance(step_copy.get("params"), dict):
            step_copy["params"] = dict(step_copy["params"])
        if isinstance(step_copy.get("verify"), dict):
            step_copy["verify"] = dict(step_copy["verify"])
        new_steps.append(step_copy)
    out["steps"] = new_steps
    return out


def _build_steps_and_symbols(
    steps: Sequence[Mapping[str, Any]],
) -> tuple[list[CompiledStep], dict[str, str]]:
    """Assign step IDs and build the output→step_id symbol table."""
    compiled: list[CompiledStep] = []
    symbols: dict[str, str] = {}

    for i, step in enumerate(steps, start=1):
        if i > 999:
            raise CompileError(
                message="recipe exceeds 999 steps; raise STEP_ID_FORMAT capacity",
            )
        sid = STEP_ID_FORMAT.format(i)
        output = step["output"]
        if output in symbols:
            raise CompileError(
                message=(
                    f"duplicate output name {output!r} (already bound to "
                    f"{symbols[output]}); each output must be unique"
                ),
                detail=(f"step {sid} re-declares output {output!r}",),
            )
        symbols[output] = sid

        compiled.append(
            CompiledStep(
                id=sid,
                worker=step["worker"],
                params=step["params"],
                verify=step["verify"],
                output=output,
                on_fail=step["on_fail"],
                retries=step["retries"],
            )
        )
    return compiled, symbols


def _resolve_references(
    steps: Sequence[CompiledStep],
    symbols: Mapping[str, str],
) -> list[CompiledStep]:
    """Rewrite ${output_name} occurrences in params to ${step_id}.

    A step may not reference its own output, nor any later step's output;
    forward references are unresolvable at runtime and we forbid them at
    compile-time so the corpus is decidable.
    """
    resolved: list[CompiledStep] = []
    available: dict[str, str] = {}        # outputs visible so far

    for step in steps:
        new_params = _walk_resolve(
            step.params, available, owner=step.id, symbols=symbols,
        )
        resolved.append(
            CompiledStep(
                id=step.id,
                worker=step.worker,
                params=new_params,
                verify=step.verify,
                output=step.output,
                on_fail=step.on_fail,
                retries=step.retries,
            )
        )
        # Make this step's output visible to subsequent steps.
        available[step.output] = step.id
    return resolved


def _walk_resolve(
    obj: Any,
    available: Mapping[str, str],
    *,
    owner: str,
    symbols: Mapping[str, str],
) -> Any:
    """Recursively rewrite ${name} tokens inside strings within obj."""
    if isinstance(obj, str):
        return _resolve_string(obj, available, owner=owner, symbols=symbols)
    if isinstance(obj, dict):
        return {k: _walk_resolve(v, available, owner=owner, symbols=symbols)
                for k, v in obj.items()}
    if isinstance(obj, list):
        return [_walk_resolve(v, available, owner=owner, symbols=symbols)
                for v in obj]
    return obj


def _resolve_string(
    s: str,
    available: Mapping[str, str],
    *,
    owner: str,
    symbols: Mapping[str, str],
) -> str:
    def repl(match: re.Match[str]) -> str:
        name = match.group(1)
        if name not in symbols:
            raise CompileError(
                message=f"unresolved reference ${{{name}}} in step {owner}",
                detail=(
                    f"output names visible at this step: {sorted(available)}",
                    f"all output names in recipe: {sorted(symbols)}",
                ),
            )
        if name not in available:
            raise CompileError(
                message=(
                    f"forward reference ${{{name}}} in step {owner}; "
                    f"output {name!r} is produced by a later step"
                ),
            )
        return f"${{{available[name]}}}"

    return REF_PATTERN.sub(repl, s)


def _check_invariants(
    steps: Sequence[CompiledStep],
    symbols: Mapping[str, str],
) -> None:
    """Cheap post-pipeline sanity checks."""
    seen_ids: set[str] = set()
    for s in steps:
        if s.id in seen_ids:
            raise CompileError(
                message=f"duplicate step id {s.id!r}; compiler bug",
            )
        seen_ids.add(s.id)
    if len(symbols) != len(steps):
        raise CompileError(
            message=(
                f"symbol table has {len(symbols)} entries but {len(steps)} "
                "steps; compiler bug"
            ),
        )
