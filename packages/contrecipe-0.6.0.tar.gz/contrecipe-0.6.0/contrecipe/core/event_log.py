# v1 | 2026-05-03 | Sprint R5 — append-only event log (JSONL with fcntl lock)
"""Append-only decision journal.

Every state-changing operation in `contrecipe` writes a single JSON line
to a configured log path. The log is the auditable trail of *what happened
and why* — quarantines, restores, archives. It is never rewritten.

Format: one JSON object per line, sorted keys, UTF-8.

    {"ts": "2026-05-03T10:11:12+00:00", "op": "quarantine",
     "recipe_id": "build_and_test", "from": "active", "to": "quarantine",
     "reason": "verify_fail_threshold_exceeded", "fail_count": 7,
     "src_path": "/.../build_and_test.yaml",
     "dst_path": "/.../quarantine/build_and_test.yaml"}

Concurrency: a tool-side `fcntl.flock(LOCK_EX)` covers the write. We are
designing for single-host single-process use (banking ops; no daemon
swarm). The lock is best-effort defence in depth; it does not pretend to
make append-only correct on a network filesystem.

Why JSONL not sqlite/log:
  - grep-friendly out of the box
  - banks like flat files: easy to ship, archive, retain
  - no schema migrations
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

# fcntl is POSIX-only; banking deployment is Ubuntu, so this is fine.
# Tests on non-POSIX platforms would skip the lock; we don't need that today.
import fcntl


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def append(path: Path, event: Mapping[str, Any]) -> None:
    """Append one event as a single JSON line. Creates parent dirs.

    Adds `ts` if absent. Sorts keys for diff-friendly output.
    """
    enriched: dict[str, Any] = {"ts": _now_iso(), **dict(event)}
    line = json.dumps(enriched, sort_keys=True, ensure_ascii=False)
    path = path.expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)

    # Open in append+binary so the lock applies cleanly. fcntl works on the fd.
    with path.open("ab") as f:
        try:
            fcntl.flock(f.fileno(), fcntl.LOCK_EX)
            f.write((line + "\n").encode("utf-8"))
            f.flush()
            os.fsync(f.fileno())
        finally:
            try:
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)
            except OSError:
                # If unlock fails the OS will release on close anyway.
                pass


def read_events(path: Path) -> list[dict[str, Any]]:
    """Read all events. Bad lines are silently skipped (log is forward-only).

    Convenience for diagnostics and tests; not intended for high-volume use.
    """
    if not path.exists():
        return []
    out: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return out
