# v1 | 2026-05-03 | Sprint R2 — internal canonical schema loader
"""Single point of access to the packaged canonical schema.

R2 (inspector) and later sprints (R3 validator, R4 compiler, R5 lifecycle)
all read the same schema. Centralising the load keeps them from drifting.

This is internal (`_schema.py`) — external callers should reach the schema
through high-level inspector / validator APIs, not by importing this directly.
"""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Mapping

import yaml

import contrecipe

_SCHEMA_FILENAME = "recipe_v1.schema.yaml"


@lru_cache(maxsize=1)
def load_canonical_schema() -> Mapping[str, object]:
    """Return the parsed canonical recipe schema.

    Cached for the process lifetime; the schema ships with the wheel and
    does not change at runtime.
    """
    pkg_root = Path(contrecipe.__file__).parent
    schema_path = pkg_root / "schemas" / _SCHEMA_FILENAME
    with schema_path.open("r", encoding="utf-8") as handle:
        data = yaml.safe_load(handle)
    if not isinstance(data, dict):
        raise RuntimeError(
            f"canonical schema at {schema_path} did not parse to a mapping"
        )
    return data


def schema_path() -> Path:
    """Filesystem location of the canonical schema (for diagnostics)."""
    return Path(contrecipe.__file__).parent / "schemas" / _SCHEMA_FILENAME
