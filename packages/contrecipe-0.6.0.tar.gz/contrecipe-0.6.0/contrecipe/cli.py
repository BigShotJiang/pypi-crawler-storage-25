# v6 | 2026-05-03 | Sprint R6 — `watch` wired to proposal_inbox; --once + drain modes
"""Command-line interface for contrecipe.

Sprint R1 provides only the argparse skeleton and `--version`.
Subsequent sprints fill in the subcommand bodies:

  R2  inspect      — corpus reader + statistics (read-only)
  R3  validate     — canonical schema + tool registry check
  R4  compile      — source → normalized → executable descriptor
  R5  quarantine   — list / restore / archive
  R6  watch        — proposal inbox daemon (polling)
  R7  (internal)   — atomic corpus writer used by inbox

Design notes:
  - argparse only; no typer/click. Banking installs prefer minimal deps.
  - Subcommands return integer exit codes; main() returns the exit code.
  - All subcommands print to stdout for tooling-friendly piping.
"""

from __future__ import annotations

import argparse
import sys
from typing import Sequence

from contrecipe import __version__

EXIT_OK = 0
EXIT_USAGE = 2
EXIT_NOT_IMPLEMENTED = 64  # EX_USAGE region; distinct from real errors


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="contrecipe",
        description=(
            "Procedural DNA curator for the Cont Hive. "
            "Inspects, validates, compiles, and quarantines recipes."
        ),
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"contrecipe {__version__}",
    )

    subparsers = parser.add_subparsers(dest="command", metavar="<command>")

    # R2 — inspect
    p_inspect = subparsers.add_parser(
        "inspect",
        help="Read corpus and emit statistics + phantom-tool scan (R2).",
    )
    p_inspect.add_argument("path", help="Path to a recipes/ directory.")
    p_inspect.add_argument(
        "--json",
        action="store_true",
        help="Emit machine-readable JSON instead of human-readable text.",
    )

    # R3 — validate
    p_validate = subparsers.add_parser(
        "validate",
        help="Validate one recipe against the canonical schema (R3).",
    )
    p_validate.add_argument("recipe", help="Path to a single recipe yaml file.")
    p_validate.add_argument(
        "--json",
        action="store_true",
        help="Emit machine-readable JSON instead of human-readable text.",
    )
    p_validate.add_argument(
        "--registry",
        default=None,
        help=(
            "Path to a tool registry JSON dump. When provided, unknown "
            "worker names are rejected. When absent, registry checks are "
            "skipped (forbidden-worker check still runs from the schema)."
        ),
    )

    # R4 — compile
    p_compile = subparsers.add_parser(
        "compile",
        help="Compile a recipe: source → normalized → executable plan (R4).",
    )
    p_compile.add_argument("recipe", help="Path to a single recipe yaml file.")
    p_compile.add_argument(
        "--json",
        action="store_true",
        help="Emit machine-readable JSON plan instead of human-readable text.",
    )
    p_compile.add_argument(
        "--registry",
        default=None,
        help=(
            "Path to a tool registry JSON dump (forwarded to the validator "
            "pre-pass)."
        ),
    )
    p_compile.add_argument(
        "--dry-run",
        action="store_true",
        default=True,
        help=(
            "MVP only emits a descriptor, never executes (default and only "
            "mode in R4)."
        ),
    )

    # R5 — quarantine
    p_quar = subparsers.add_parser(
        "quarantine",
        help="Manage the quarantine area (R5).",
    )
    quar_sub = p_quar.add_subparsers(dest="quarantine_action")

    p_quar_list = quar_sub.add_parser(
        "list",
        help="List quarantined recipes.",
    )
    p_quar_list.add_argument(
        "--dir",
        required=True,
        help="Quarantine directory.",
    )
    p_quar_list.add_argument(
        "--json",
        action="store_true",
        help="Emit machine-readable JSON.",
    )

    p_quar_add = quar_sub.add_parser(
        "add",
        help="Move a recipe into quarantine with a reason.",
    )
    p_quar_add.add_argument("recipe", help="Path to the recipe yaml file.")
    p_quar_add.add_argument("--dir", required=True, help="Quarantine directory.")
    p_quar_add.add_argument("--reason", required=True, help="Why this recipe is being quarantined.")
    p_quar_add.add_argument("--fail-count", type=int, default=None,
                            help="Verify-fail count that triggered this (optional).")
    p_quar_add.add_argument("--prior-lifecycle", default=None,
                            help="Lifecycle state the recipe is leaving (optional).")
    p_quar_add.add_argument("--event-log", default=None,
                            help="Append a JSONL entry to this log path (optional).")

    p_quar_restore = quar_sub.add_parser(
        "restore",
        help="Restore a quarantined recipe to its origin (or --to override).",
    )
    p_quar_restore.add_argument("recipe_id", help="Recipe id (file stem).")
    p_quar_restore.add_argument("--dir", required=True, help="Quarantine directory.")
    p_quar_restore.add_argument("--to", default=None,
                                help="Override target path (default: origin_path from sidecar).")
    p_quar_restore.add_argument("--event-log", default=None,
                                help="Append a JSONL entry to this log path (optional).")

    p_quar_archive = quar_sub.add_parser(
        "archive",
        help="One-way move from a source area to the archive directory.",
    )
    p_quar_archive.add_argument("recipe_id", help="Recipe id (file stem).")
    p_quar_archive.add_argument("--source", required=True,
                                help="Directory the recipe currently lives in (corpus or quarantine).")
    p_quar_archive.add_argument("--archive-dir", required=True, help="Archive destination.")
    p_quar_archive.add_argument("--reason", default="archived",
                                help="Reason recorded in the event log (default: 'archived').")
    p_quar_archive.add_argument("--prior-lifecycle", default=None,
                                help="Lifecycle state the recipe is leaving (optional).")
    p_quar_archive.add_argument("--event-log", default=None,
                                help="Append a JSONL entry to this log path (optional).")

    # R6 — watch
    p_watch = subparsers.add_parser(
        "watch",
        help="Poll a proposal inbox and process new recipes (R6).",
    )
    p_watch.add_argument("inbox", help="Path to the proposal inbox directory.")
    p_watch.add_argument(
        "--interval",
        type=float,
        default=1.0,
        help="Polling interval in seconds (default: 1.0).",
    )
    p_watch.add_argument(
        "--max-per-cycle",
        type=int,
        default=16,
        help="Soft cap on proposals processed per cycle (default: 16).",
    )
    p_watch.add_argument(
        "--once",
        action="store_true",
        help="Process the inbox once and exit (drain mode); do not loop.",
    )
    p_watch.add_argument(
        "--registry",
        default=None,
        help="Path to a tool registry JSON dump (forwarded to validator).",
    )
    p_watch.add_argument(
        "--event-log",
        default=None,
        help="Append per-proposal decisions to this JSONL file.",
    )
    p_watch.add_argument(
        "--json",
        action="store_true",
        help="In --once mode, emit machine-readable JSON summary.",
    )

    # R7 — test
    p_test = subparsers.add_parser(
        "test",
        help="Run golden tests against a recipe (R3+).",
    )
    p_test.add_argument("recipe", help="Path to a single recipe yaml file.")

    return parser


def _not_implemented(name: str, sprint: str) -> int:
    """Uniform stub response for subcommands not yet implemented."""
    print(
        f"[contrecipe] '{name}' is scheduled for sprint {sprint}; "
        f"current build is {__version__}. See CHANGELOG.md for status.",
        file=sys.stderr,
    )
    return EXIT_NOT_IMPLEMENTED


def main(argv: Sequence[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    if args.command is None:
        parser.print_help()
        return EXIT_USAGE

    # Each subcommand lands here. R1 only stubs them; later sprints
    # replace the body with real handlers (compiler.compile, etc.).
    if args.command == "inspect":
        from contrecipe.core import inspector
        return inspector.run_cli(args.path, json_output=args.json)
    if args.command == "validate":
        from contrecipe.core import validator
        return validator.run_cli(
            args.recipe,
            json_output=args.json,
            registry_path=args.registry,
        )
    if args.command == "compile":
        from contrecipe.core import compiler
        return compiler.run_cli(
            args.recipe,
            json_output=args.json,
            registry_path=args.registry,
        )
    if args.command == "quarantine":
        from contrecipe.core import quarantine as q
        action = args.quarantine_action
        if action == "list":
            return q.cli_list(args.dir, json_output=args.json)
        if action == "add":
            return q.cli_quarantine(
                args.recipe,
                quarantine_dir=args.dir,
                reason=args.reason,
                fail_count=args.fail_count,
                prior_lifecycle=args.prior_lifecycle,
                event_log_path=args.event_log,
            )
        if action == "restore":
            return q.cli_restore(
                args.recipe_id,
                quarantine_dir=args.dir,
                target_path=args.to,
                event_log_path=args.event_log,
            )
        if action == "archive":
            return q.cli_archive(
                args.recipe_id,
                source_dir=args.source,
                archive_dir=args.archive_dir,
                reason=args.reason,
                prior_lifecycle=args.prior_lifecycle,
                event_log_path=args.event_log,
            )
        # No action selected — show subhelp
        parser.parse_args(["quarantine", "--help"])
        return EXIT_USAGE
    if args.command == "watch":
        from contrecipe.core import proposal_inbox
        return proposal_inbox.cli_watch(
            args.inbox,
            interval=args.interval,
            max_per_cycle=args.max_per_cycle,
            once=args.once,
            registry_path=args.registry,
            event_log_path=args.event_log,
            json_output=args.json,
        )
    if args.command == "test":
        return _not_implemented("test", "R3")

    # Argparse will already have errored on unknown commands; defensive.
    parser.error(f"unhandled command: {args.command}")
    return EXIT_USAGE  # unreachable, but keeps mypy happy


if __name__ == "__main__":
    raise SystemExit(main())
