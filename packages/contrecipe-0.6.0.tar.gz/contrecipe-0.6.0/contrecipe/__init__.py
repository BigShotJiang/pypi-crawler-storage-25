# v6 | 2026-05-03 | Sprint R6 — version bump 0.6.0 (proposal inbox)
"""contrecipe — Procedural DNA curator for the Cont Hive.

This package does not chat. It inspects, validates, compiles, quarantines, and
evolves recipes. See README.md for the design rationale.
"""

__version__ = "0.6.0"
__all__ = ["__version__"]
