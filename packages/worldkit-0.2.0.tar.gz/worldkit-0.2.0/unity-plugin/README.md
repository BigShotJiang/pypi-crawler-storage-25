# WorldKit Unity Plugin

Load and run WorldKit world models in Unity. Encode observations, predict latent dynamics, and plan goal-directed actions using JEPA-based world models exported to ONNX.

## Prerequisites

- **Unity 2022.3+** (LTS recommended)
- **Barracuda** (Unity's neural network inference library) — included in Unity 2022+
- A WorldKit model exported to ONNX format

## Installation

### Via Unity Package Manager (local)

1. Clone or copy the `unity-plugin/` directory into your project
2. In Unity, go to **Window > Package Manager**
3. Click **+** > **Add package from disk...**
4. Select `unity-plugin/package.json`

### Via Unity Package Manager (git)

Add to your `Packages/manifest.json`:

```json
{
  "dependencies": {
    "com.worldkit.unity": "https://github.com/worldkit/worldkit.git?path=unity-plugin"
  }
}
```

## Exporting Models from Python

Before using WorldKit in Unity, export your trained model to ONNX:

```python
from worldkit import WorldModel

model = WorldModel.load("my_model.wk")
model.export_onnx("./export/")
# Creates: worldkit_encoder.onnx, worldkit_predictor.onnx
```

Then drag the `.onnx` files into your Unity project's `Assets/` folder. Unity will import them as `NNModel` assets via Barracuda.

## Quick Start

### 1. Add the component

Attach **WorldKitAgent** to any GameObject:

- Select your GameObject
- Click **Add Component > WorldKit > WorldKit Agent**

### 2. Assign models

In the Inspector:

- Drag your `worldkit_encoder.onnx` into the **Encoder** field
- Drag your `worldkit_predictor.onnx` into the **Predictor** field (optional, needed for planning)

### 3. Create a config

- Right-click in the Project panel: **Create > WorldKit > Model Config**
- Adjust settings to match your exported model (latent dim, action dim, etc.)
- Assign the config asset to the agent's **Config** field

### 4. Use in code

```csharp
using WorldKit;
using UnityEngine;

public class MyAgent : MonoBehaviour
{
    private WorldKitAgent _wk;

    void Start()
    {
        _wk = GetComponent<WorldKitAgent>();
    }

    void Update()
    {
        if (!_wk.IsReady) return;

        // Encode the current camera view
        float[] latent = _wk.EncodeCameraView();
        Debug.Log($"Latent dim: {latent.Length}");
    }
}
```

## API Reference

### WorldKitAgent (MonoBehaviour)

The main component. Attach to any GameObject.

| Property | Type | Description |
|----------|------|-------------|
| `IsReady` | `bool` | True when the encoder is loaded and ready |
| `Model` | `WorldKitModel` | Direct access to the underlying model |
| `Planner` | `WorldKitPlanner` | Direct access to the CEM planner |

| Method | Returns | Description |
|--------|---------|-------------|
| `LoadModel(encoder, predictor?)` | `void` | Load ONNX model assets at runtime |
| `Encode(Texture2D)` | `float[]` | Encode an image to a latent vector |
| `EncodeCameraView()` | `float[]` | Encode the current camera observation |
| `Predict(float[], float[])` | `float[]` | Predict next latent given current latent + action |
| `Plan(Texture2D, Texture2D)` | `PlanResult` | Plan actions from current to goal image |
| `PlanFromCamera(Texture2D)` | `PlanResult` | Plan from current camera view to goal |
| `Plausibility(Texture2D[], float[][]?)` | `float` | Score how physically plausible a frame sequence is (0-1) |

### WorldKitModel

Low-level ONNX inference wrapper.

| Method | Returns | Description |
|--------|---------|-------------|
| `LoadEncoder(NNModel)` | `void` | Load an ONNX encoder asset |
| `LoadPredictor(NNModel)` | `void` | Load an ONNX predictor asset |
| `RunEncoder(float[])` | `float[]` | Run encoder on CHW pixel array |
| `RunPredictor(float[], float[])` | `float[]` | Predict next latent from current latent + action |
| `Rollout(float[], float[][])` | `float[][]` | Multi-step latent rollout |

### WorldKitPlanner

Cross-Entropy Method planner operating in latent space.

| Method | Returns | Description |
|--------|---------|-------------|
| `Plan(float[], float[])` | `PlanResult` | Plan action sequence from current to goal latent |
| `SetActionBounds(float, float)` | `void` | Set symmetric action bounds (e.g., -1 to 1) |

### PlanResult

| Field | Type | Description |
|-------|------|-------------|
| `Actions` | `float[][]` | Planned action sequence `[horizon][actionDim]` |
| `LatentTrajectory` | `float[][]` | Predicted latent trajectory `[horizon+1][latentDim]` |
| `Cost` | `float` | L2 distance to goal in latent space |
| `Iterations` | `int` | Number of CEM iterations performed |

### WorldKitConfig (ScriptableObject)

Create via **Assets > Create > WorldKit > Model Config**.

| Field | Default | Description |
|-------|---------|-------------|
| `latentDim` | 192 | Latent space dimensionality |
| `imageSize` | 96 | Input image size (square) |
| `actionDim` | 2 | Number of action dimensions |
| `actionEmbedDim` | 192 | Action embedding dimensionality |
| `contextLength` | 3 | Predictor context length |
| `planningHorizon` | 50 | Max planning steps |
| `planningCandidates` | 200 | CEM candidate count |
| `planningElites` | 20 | CEM elite count |
| `planningIterations` | 5 | CEM iterations |
| `useGPU` | true | Use GPU for inference |

## .wk File Support

Dragging a `.wk` file into Unity will show model metadata and provide the Python command to export it to ONNX. The `.wk` format is a PyTorch bundle and cannot be run directly in Unity — export to ONNX first.

## Config Presets

Create configs programmatically to match Python presets:

```csharp
// Matches worldkit's "base" config
var baseConfig = WorldKitConfig.CreateBase();

// Matches worldkit's "nano" config (lightweight, for testing)
var nanoConfig = WorldKitConfig.CreateNano();
```

## Tensor Conventions

WorldKit ONNX models use these tensor formats:

| Tensor | Shape | Range | Layout |
|--------|-------|-------|--------|
| Encoder input (`pixels`) | `(B, 3, 96, 96)` | `[0, 1]` | NCHW |
| Encoder output (`latent`) | `(B, latent_dim)` | unbounded | — |
| Predictor input (`latent`) | `(B, latent_dim)` | unbounded | — |
| Predictor input (`action`) | `(B, action_dim)` | depends on env | — |
| Predictor output (`next_latent`) | `(B, latent_dim)` | unbounded | — |

Note: Barracuda uses NHWC internally. The plugin handles CHW-to-HWC conversion automatically.

## Troubleshooting

**"Encoder not loaded"**: Ensure the ONNX file is assigned in the Inspector or call `LoadModel()` before `Encode()`.

**Latent dimensions mismatch**: The `latentDim` in your WorldKitConfig must match the ONNX model. Check which Python config was used for training (`nano`=128, `base`=192, `large`=384, `xl`=512).

**Poor planning results**: Increase `planningCandidates` and `planningIterations`. Ensure action bounds match your environment.

**GPU inference issues**: If Barracuda compute shaders fail, set `useGPU = false` in the config to fall back to CPU (CSharpBurst).

## License

MIT — same as WorldKit.
