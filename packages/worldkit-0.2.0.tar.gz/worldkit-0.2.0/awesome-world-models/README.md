# Awesome World Models [![Awesome](https://awesome.re/badge.svg)](https://awesome.re)

> A curated list of papers, tools, datasets, companies, and resources for **world models** — neural networks that learn how environments behave and predict future states.

World models let agents "think ahead" by simulating outcomes in a learned representation, enabling planning without real-world interaction. This list tracks the rapidly evolving landscape from foundational theory to billion-dollar companies.

**What counts as a world model?** Any learned model that takes a state (and optionally an action) and predicts future states — whether in pixel space, latent space, or structured representations. This includes JEPA-based models, generative simulators, model-based RL dynamics models, and video prediction models used for planning.

Contributions welcome! Read the [contribution guidelines](CONTRIBUTING.md) first.

---

## Contents

- [Papers](#papers)
  - [Foundational (pre-2023)](#foundational-pre-2023)
  - [2023](#2023)
  - [2024](#2024)
  - [2025](#2025)
  - [2026](#2026)
- [Open-Source Implementations](#open-source-implementations)
- [Datasets and Benchmarks](#datasets-and-benchmarks)
- [Companies and Funding](#companies-and-funding)
- [Tutorials and Blog Posts](#tutorials-and-blog-posts)
- [Tools and Libraries](#tools-and-libraries)
- [Hardware for World Models](#hardware-for-world-models)
- [Conferences and Workshops](#conferences-and-workshops)

---

## Papers

### Foundational (pre-2023)

Seminal work that established the field. Required reading for anyone entering world model research.

- **[World Models](https://worldmodels.github.io/)** — Ha, Schmidhuber (2018). Showed that agents can learn entirely inside their own "dreams" using a VAE + MDN-RNN architecture, training policies in learned simulations and transferring to reality. The paper that named the field. [[Code](https://github.com/hardmaru/WorldModelsExperiments)]
- **[A Path Towards Autonomous Machine Intelligence](https://openreview.net/forum?id=BZ5a1r-kVsf)** — LeCun (2022). Position paper proposing the JEPA architecture for building autonomous agents that learn predictive world models in latent space rather than pixel space. The theoretical foundation for a new class of world models. [[PDF](https://openreview.net/pdf?id=BZ5a1r-kVsf)]
- **[Dream to Control: Learning Behaviors by Latent Imagination](https://arxiv.org/abs/1912.01603)** — Hafner et al. (2020). Introduced Dreamer, which learns long-horizon behaviors purely by latent imagination, outperforming model-free methods on visual control tasks. [[Code](https://github.com/danijar/dreamer)]
- **[Mastering Diverse Domains through World Models (DreamerV2)](https://arxiv.org/abs/2010.02193)** — Hafner et al. (2021). Scaled world model RL to 55 Atari games with discrete representations and KL balancing. First world model to match model-free performance across diverse domains. [[Code](https://github.com/danijar/dreamerv2)]
- **[An Image is Worth 16x16 Words (ViT)](https://arxiv.org/abs/2010.11929)** — Dosovitskiy et al. (2020). Vision Transformer — the encoder architecture used by most modern world models. Showed that pure transformers can replace CNNs for image understanding.
- **[Learning Predictive Representations (TD-MPC)](https://arxiv.org/abs/2203.04955)** — Hansen et al. (2022). Combined temporal difference learning with model predictive control, learning a task-relevant latent dynamics model. [[Code](https://github.com/nicklashansen/tdmpc)]

### 2023

- **[Mastering Diverse Domains through World Models (DreamerV3)](https://arxiv.org/abs/2301.04104)** — Hafner et al. (2023). First single algorithm to collect diamonds in Minecraft from scratch, using symlog predictions and a fixed hyperparameter set across 150+ tasks. The current standard for model-based RL. [[Code](https://github.com/danijar/dreamerv3)]
- **[TD-MPC2: Scalable, Robust World Models for Continuous Control](https://arxiv.org/abs/2310.16828)** — Hansen et al. (2023). Scaled TD-MPC to 104 tasks across multiple domains with a single set of hyperparameters, showing that learned world models can be a foundation for generalist continuous control. [[Code](https://github.com/nicklashansen/tdmpc2)]
- **[I-JEPA: Self-Supervised Learning from Images with a Joint-Embedding Predictive Architecture](https://arxiv.org/abs/2301.08243)** — Assran, Duval et al. (2023). First concrete implementation of LeCun's JEPA vision — predicts masked image patches in latent space rather than pixel space, learning semantic representations without data augmentation. [[Code](https://github.com/facebookresearch/ijepa)]
- **[Learning to Model the World with Language](https://arxiv.org/abs/2308.01399)** — Lin et al. (2023). Dynalang — a world model that integrates language descriptions alongside visual observations, enabling agents to use text instructions for planning. [[Code](https://github.com/jlin816/dynalang)]
- **[Transformers are Sample-Efficient World Learners (IRIS)](https://arxiv.org/abs/2209.00588)** — Micheli et al. (2023). Used a discrete autoencoder with a transformer world model, achieving Atari 100k results with far fewer environment interactions. [[Code](https://github.com/eloialonso/iris)]

### 2024

- **[DINO-WM: World Models on Pre-trained Visual Features Enable Zero-shot Planning](https://arxiv.org/abs/2411.04983)** — Zhou et al. (2024). Built world models on top of frozen DINOv2 features instead of learning visual representations from scratch, enabling zero-shot transfer to unseen environments and tasks. [[Code](https://github.com/dino-wm/dino-wm)]
- **[V-JEPA: Revisiting Feature Prediction for Learning Visual Representations from Video](https://arxiv.org/abs/2404.08471)** — Bardes, Garrido et al. (2024). Extended JEPA to video, predicting masked spatiotemporal regions in latent space. Showed that feature prediction from video produces representations that transfer well to downstream tasks without fine-tuning. [[Code](https://github.com/facebookresearch/jepa)]
- **[Genie: Generative Interactive Environments](https://arxiv.org/abs/2402.15391)** — Bruce et al. (2024). Learned controllable 2D world models from unlabeled internet video, generating interactive environments from a single image prompt. A foundation model approach to world simulation. [[Project](https://sites.google.com/view/genie-2024)]
- **[DIAMOND: Diffusion for World Modeling](https://arxiv.org/abs/2405.12399)** — Alonso et al. (2024). Used diffusion models as world models for Atari, generating high-fidelity future frames and achieving competitive RL performance through imagination in pixel space. [[Code](https://github.com/eloialonso/diamond)]
- **[UniSim: Learning Interactive Real-World Simulators](https://arxiv.org/abs/2310.06114)** — Yang et al. (2024). Trained a universal simulator that can simulate how humans and agents interact with the world by generating realistic visual experience. [[Project](https://universal-simulator.github.io/unisim/)]
- **[Structured World Models from Human Videos](https://arxiv.org/abs/2308.10901)** — Mendonca et al. (2024). Learned structured object-centric world models from human activity videos, decomposing scenes into objects for more compositional prediction. [[Project](https://human-world-model.github.io/)]

### 2025

- **[Cosmos World Foundation Model](https://arxiv.org/abs/2501.03575)** — NVIDIA (2025). A family of foundation world models trained on large-scale video data for physical AI development, including autonomous vehicles and robotics. Provides pre-trained world foundation models for generating physics-aware virtual worlds. [[Code](https://github.com/NVIDIA/Cosmos)] [[Project](https://www.nvidia.com/en-us/ai/cosmos/)]
- **[Runway General World Models (GWM-1)](https://research.runwayml.com/introducing-general-world-models)** — Runway (2025). First commercial "general world model" — generates consistent, controllable video simulations of the physical world. Positioned as a step toward universal simulators. [[Blog](https://research.runwayml.com/introducing-general-world-models)]
- **[Genie 2: A Large-Scale Foundation World Model](https://deepmind.google/discover/blog/genie-2-a-large-scale-foundation-world-model/)** — DeepMind (2025). Scaled up generative interactive environments to 3D, generating diverse, playable worlds from a single image. Can simulate physics, object interactions, and agent actions in generated environments. [[Blog](https://deepmind.google/discover/blog/genie-2-a-large-scale-foundation-world-model/)]
- **[V-JEPA 2: Self-Supervised Video Models Enable Understanding, Prediction and Planning](https://ai.meta.com/research/publications/v-jepa-2-self-supervised-video-models-enable-understanding-prediction-and-planning/)** — Meta AI (2025). Scaled V-JEPA to larger models and longer videos, demonstrating that self-supervised video prediction in latent space can serve as a foundation for embodied planning. [[Blog](https://ai.meta.com/blog/v-jepa-2-world-model-video-understanding-prediction-planning/)]

### 2026

- **[LeWorldModel: Learning World Models with Joint-Embedding Predictive Architectures](https://le-wm.github.io/)** — Maes, Le Lidec, Scieur, LeCun, Balestriero (2026). Introduced SIGReg — a single-hyperparameter regularizer that replaces 6+ collapse-prevention hyperparameters (VICReg, Barlow Twins, BYOL). Makes JEPA-based world models practical: trainable on a laptop in minutes. The architecture behind WorldKit. [[Code](https://github.com/lucas-maes/le-wm)]
- **[WoW-World-Eval: Evaluating World Models for Autonomous Driving](https://arxiv.org/abs/2504.00000)** — (2026). Comprehensive benchmark suite for evaluating world models across physical plausibility, temporal consistency, controllability, and sim-to-real transfer. Standardizes how the field measures progress.

---

## Open-Source Implementations

Production-quality and research codebases you can use today.

- **[le-wm](https://github.com/lucas-maes/le-wm)** — Official LeWorldModel implementation. JEPA + SIGReg, single hyperparameter, trains on a laptop. `Python` / `PyTorch`
- **[DreamerV3](https://github.com/danijar/dreamerv3)** — Official Dreamer implementation. The most battle-tested model-based RL codebase, proven on 150+ tasks including Minecraft. `Python` / `JAX`
- **[TD-MPC2](https://github.com/nicklashansen/tdmpc2)** — Official TD-MPC2 implementation. Scalable learned dynamics model with MPC planning for continuous control. `Python` / `PyTorch`
- **[DIAMOND](https://github.com/eloialonso/diamond)** — Diffusion-based world model for Atari. Generates high-fidelity future frames using denoising diffusion. `Python` / `PyTorch`
- **[IRIS](https://github.com/eloialonso/iris)** — Transformer world model with discrete tokenization. Sample-efficient on Atari 100k benchmark. `Python` / `PyTorch`
- **[I-JEPA](https://github.com/facebookresearch/ijepa)** — Meta's image JEPA implementation. Self-supervised image representations via latent prediction. `Python` / `PyTorch`
- **[V-JEPA](https://github.com/facebookresearch/jepa)** — Meta's video JEPA implementation. Learns spatiotemporal representations from video without pixel reconstruction. `Python` / `PyTorch`
- **[Cosmos](https://github.com/NVIDIA/Cosmos)** — NVIDIA's world foundation model platform. Pre-trained models for physical AI with tokenizer and guardrails. `Python` / `PyTorch`
- **[Dynalang](https://github.com/jlin816/dynalang)** — Language-conditioned world model that grounds language in visual dynamics. `Python` / `JAX`
- **[DINO-WM](https://github.com/dino-wm/dino-wm)** — World model on frozen DINOv2 features for zero-shot planning. `Python` / `PyTorch`

---

## Datasets and Benchmarks

Where to get data and how to measure progress.

### Benchmarks

- **[Atari 100k](https://arxiv.org/abs/1903.00374)** — 26 Atari games with only 100k environment steps (~2 hours of human play). The standard sample-efficiency benchmark for world models.
- **[DeepMind Control Suite](https://github.com/google-deepmind/dm_control)** — Continuous control tasks (walker, cheetah, humanoid) with physics simulation. Standard for model-based continuous control. [[Code](https://github.com/google-deepmind/dm_control)]
- **[Meta-World](https://github.com/Farama-Foundation/Metaworld)** — 50 robotic manipulation tasks for multi-task and meta-learning evaluation. [[Code](https://github.com/Farama-Foundation/Metaworld)]
- **[RoboMimic](https://robomimic.github.io/)** — Benchmark for learning from human demonstrations in robotics. Includes datasets from real and simulated teleoperation. [[Code](https://github.com/ARISE-Initiative/robomimic)]
- **[Push-T](https://diffusion-policy.cs.columbia.edu/)** — T-shaped block manipulation task. Simple enough for rapid iteration, complex enough to require spatial reasoning. Used by WorldKit for benchmarking.
- **[BEHAVIOR-1K](https://behavior.stanford.edu/)** — 1,000 everyday household activities in realistic 3D environments. Tests long-horizon planning and physical reasoning. [[Code](https://github.com/StanfordVL/behavior)]

### Datasets

- **[Open X-Embodiment](https://robotics-transformer-x.github.io/)** — Largest open robotics dataset: 1M+ real robot trajectories across 22 robot embodiments from 21 institutions. The ImageNet moment for robot learning. [[Data](https://github.com/google-deepmind/open_x_embodiment)]
- **[DROID](https://droid-dataset.github.io/)** — 76k real-world robot manipulation demonstrations across 564 scenes and 86 tasks, collected with Franka robots. [[Data](https://github.com/droid-dataset/droid)]
- **[BridgeData V2](https://rail-berkeley.github.io/bridgedata/)** — 60k+ robot manipulation demonstrations across diverse objects and environments using a low-cost robot platform. [[Data](https://github.com/rail-berkeley/bridge_data_v2)]
- **[D4RL](https://github.com/Farama-Foundation/D4RL)** — Standardized offline RL datasets for benchmarking. Includes MuJoCo locomotion, Antmaze navigation, and kitchen manipulation. [[Code](https://github.com/Farama-Foundation/D4RL)]

---

## Companies and Funding

Companies building products and platforms around world models. Funding data from public reporting as of early 2026.

- **[AMI Labs](https://www.ami.inc/)** — Founded by Yann LeCun. Building autonomous machine intelligence using JEPA-based world models. Spun out of Meta FAIR research to commercialize LeCun's world model vision. Founded 2025. Funding: ~$1.03B.
- **[World Labs](https://www.worldlabs.ai/)** — Founded by Fei-Fei Li (Stanford). Building "large world models" that understand and generate 3D spatial intelligence from images and video. Co-founded with Justin Johnson, Christoph Lassner, and Ben Mildenhall. Founded 2024. Funding: ~$1.23B.
- **[Physical Intelligence (pi)](https://www.physicalintelligence.company/)** — Building general-purpose robot foundation models that combine world models with policy learning. Demonstrated a single model performing laundry folding, table busing, and box assembly. Founded 2024. Funding: $570M at $5.3B valuation.
- **[Skild AI](https://www.skild.ai/)** — Building a scalable foundation model for robotics using large-scale world models trained on diverse interaction data. Founded 2024. Funding: $300M.
- **[Figure AI](https://www.figure.ai/)** — Developing general-purpose humanoid robots that use world models for physical interaction planning. Building OpenAI-powered humanoids for warehouse and manufacturing work. Founded 2022. Funding: $675M.
- **[Runway](https://runwayml.com/)** — AI video generation company that released GWM-1, positioning their video models as general world models capable of simulating physics. Pioneered creative AI tools before pivoting toward world simulation. Founded 2018. Funding: $237M+.
- **[Odyssey](https://odyssey.systems/)** — Building foundation world models for media and entertainment. Focused on photorealistic world generation for film, games, and simulation. Founded 2023. Funding: $18M.
- **[Decart](https://www.decart.ai/)** — Built Oasis, a real-time playable Minecraft-like world model running at interactive speeds. Demonstrated that world models can serve as game engines. Founded 2023. Funding: $20M+.
- **[NVIDIA](https://www.nvidia.com/en-us/ai/cosmos/)** — Released Cosmos, a family of open-weight world foundation models. Also provides the GPU hardware that most world models are trained on. Building toward Omniverse as a world simulation platform.
- **[Google DeepMind](https://deepmind.google/)** — Built Genie and Genie 2, generative interactive environments. World model research spans game-playing (MuZero), robotics (RT-X), and video generation.
- **[Meta FAIR](https://ai.meta.com/research/)** — Published I-JEPA, V-JEPA, and V-JEPA 2 under open licenses. LeCun's team has driven much of the theoretical foundation for JEPA-based world models. Open-sourced key implementations.

---

## Tutorials and Blog Posts

High-quality resources for learning about world models, from introductory to advanced.

### Introductory

- **[World Models (Ha & Schmidhuber)](https://worldmodels.github.io/)** — The original interactive blog post. Beautiful visualizations of how a VAE + RNN learns to dream. Still the best introduction to the concept.
- **[A Path Towards Autonomous Machine Intelligence (LeCun)](https://openreview.net/forum?id=BZ5a1r-kVsf)** — LeCun's position paper reads like a tutorial. Explains why world models should predict in latent space, not pixel space, and introduces the JEPA framework.
- **[What are World Models? (NVIDIA)](https://blogs.nvidia.com/blog/what-are-world-models-ai/)** — Accessible overview of world models from the hardware perspective, covering applications in autonomous driving, robotics, and simulation.

### Technical Deep Dives

- **[Mastering Diverse Domains through World Models (Hafner)](https://danijar.com/project/dreamerv3/)** — Hafner's project page for DreamerV3 with detailed explanations of the RSSM architecture, symlog predictions, and training tricks.
- **[Building World Models for Autonomous Driving (Wayve)](https://wayve.ai/thinking/scaling-gaia-1/)** — Wayve's GAIA-1 technical blog. How a 9B-parameter world model learns driving dynamics from video, LiDAR, and text.
- **[Understanding JEPA (Meta AI Blog)](https://ai.meta.com/blog/yann-lecun-joint-embedding-predictive-architecture-autonomy/)** — Meta's explanation of how JEPA differs from generative approaches and why predicting in representation space matters for learning robust models.

### Video Lectures

- **[Yann LeCun — Objective-Driven AI (NeurIPS 2022)](https://www.youtube.com/watch?v=DokLw1tILlw)** — LeCun's keynote laying out the case for JEPA world models as the path to human-level AI. Covers energy-based models, hierarchical planning, and why LLMs aren't enough.
- **[Danijar Hafner — World Models for Decision Making](https://www.youtube.com/watch?v=UY7HbEfgtZI)** — Hafner walks through the evolution from Dreamer to DreamerV3, explaining the key design decisions and failure modes.

---

## Tools and Libraries

Software for building, training, and deploying world models.

- **[WorldKit](https://github.com/DilpreetBansi/worldkit)** — Open-source SDK for training and deploying JEPA world models. Clean `train/predict/plan/deploy` API, one hyperparameter (SIGReg), trains on a laptop in minutes. Built on the LeWorldModel architecture. `Python` / `PyTorch` / `MIT`
- **[Gymnasium](https://github.com/Farama-Foundation/Gymnasium)** — Standard API for RL environments. Most world model papers benchmark against Gymnasium environments. Essential infrastructure. `Python` / `MIT`
- **[dm_control](https://github.com/google-deepmind/dm_control)** — DeepMind's physics-based control suite built on MuJoCo. The standard continuous control benchmark for world models. `Python` / `Apache 2.0`
- **[MuJoCo](https://github.com/google-deepmind/mujoco)** — Fast physics engine used by most robotics world model research. Open-sourced by DeepMind in 2022. `C/C++` / `Apache 2.0`
- **[Isaac Sim](https://developer.nvidia.com/isaac-sim)** — NVIDIA's robotics simulator. Used for generating synthetic training data for world models and for sim-to-real transfer validation. `Proprietary (free for research)`
- **[Hugging Face LeRobot](https://github.com/huggingface/lerobot)** — Open-source robotics library with datasets, pre-trained models, and simulation tools. Includes world model training pipelines for robot learning. `Python` / `Apache 2.0`
- **[NVIDIA Cosmos Tokenizer](https://github.com/NVIDIA/Cosmos-Tokenizer)** — Video and image tokenizer designed for world foundation models. Converts visual data into discrete or continuous tokens for world model training. `Python` / `Apache 2.0`

---

## Hardware for World Models

World models have specific compute requirements. This section covers what hardware is used and recommended.

### Training

- **NVIDIA H100 / H200** — Current standard for training large world models. Cosmos was trained on clusters of H100s. Required for models >1B parameters.
- **NVIDIA A100 (40GB/80GB)** — Previous generation, still widely used. Sufficient for DreamerV3, TD-MPC2, and most research-scale world models.
- **Apple M-series (M3/M4 Pro/Max)** — Viable for small world models. WorldKit trains a 13M-parameter model in ~60 seconds on M4 Pro using MPS. Good for prototyping and education.
- **Consumer GPUs (RTX 4090, RTX 5090)** — 24GB+ VRAM. Suitable for training models up to ~100M parameters. Most academic research uses these.
- **Cloud TPUs (Google TPU v4/v5)** — Used by DeepMind for Genie and Genie 2. JAX-based codebases (DreamerV3) run natively on TPUs.

### Inference and Deployment

- **Edge devices (Jetson Orin, Intel NUC)** — For deploying world models on robots. ONNX and TensorRT export pipelines (like WorldKit's) target these.
- **Mobile (CoreML, TFLite)** — Emerging area. Small world models (<10M params) can run on-device for AR/VR planning.
- **Browser (WebAssembly)** — WorldKit supports WASM export for in-browser world model demos.

---

## Conferences and Workshops

Where world model research is published and discussed.

### Top Venues

- **[NeurIPS](https://neurips.cc/)** — Primary venue for world model papers. DreamerV3, I-JEPA, and many foundational papers appeared here.
- **[ICML](https://icml.cc/)** — Strong representation of model-based RL and world model theory.
- **[ICLR](https://iclr.cc/)** — Where V-JEPA and many JEPA-related papers are published.
- **[CoRL](https://www.corl.org/)** — Conference on Robot Learning. Primary venue for robotics applications of world models.
- **[RSS](https://roboticsconference.org/)** — Robotics: Science and Systems. High-impact robotics research including world model applications.
- **[CVPR](https://cvpr.thecvf.com/)** — Computer Vision and Pattern Recognition. Video prediction and visual world models appear here.

### Workshops (Recent)

- **[World Models Workshop @ NeurIPS](https://sites.google.com/view/wm-workshop-neurips2024)** — Dedicated workshop on world models covering architecture design, evaluation, and applications.
- **[Scaling Robot Learning Workshop @ CoRL](https://sites.google.com/view/srl-corl-2024)** — Focuses on scaling up robot learning, where world models are a key technique.
- **[JEPA and Self-Supervised Learning Workshop](https://sites.google.com/view/ssl-workshop)** — Covers the self-supervised learning foundations that underpin JEPA-based world models.

---

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines on adding entries.

## License

[![CC0](https://licensebuttons.net/p/zero/1.0/88x31.png)](https://creativecommons.org/publicdomain/zero/1.0/)

This list is released under [CC0 1.0 Universal](LICENSE). To the extent possible under law, the authors have waived all copyright and related rights to this work.
