# WorldKit Playground

Interactive browser demo where anyone can train a tiny world model and watch it learn physics in real-time. Zero install, zero signup, zero Python.

## Quick Start

```bash
cd playground
npm install
npm run dev
```

Open [http://localhost:5173](http://localhost:5173)

## How It Works

1. **Pick an environment** — bouncing ball, pendulum, or spring-mass system
2. **Collect data** — watch the physics simulation run and record 500 training samples
3. **Train** — see the loss curve drop in real-time as the model learns physics
4. **Predict** — compare the model's predictions (gold) to actual physics (green)
5. **Plan** — click to set a goal, then watch the model imagine paths and pick the best one

## Technical Details

The playground implements a tiny world model (~10K parameters) entirely in JavaScript:

- **Architecture**: 2-hidden-layer MLP (96 units each) trained to predict next state given current state + action
- **Optimizer**: Adam with learning rate 0.002
- **Loss**: Mean Squared Error
- **Planner**: Cross-Entropy Method (CEM) — samples action sequences, rolls them out through the model, keeps the best
- **Latent visualization**: PCA projection of first hidden layer activations

No Python, no WebAssembly — pure JavaScript neural network with manual backpropagation.

## Environments

| Environment | State | Actions | Dynamics |
|-------------|-------|---------|----------|
| Bouncing Ball | x, y, vx, vy | force x/y | Gravity + elastic wall collisions |
| Pendulum | cos&theta;, sin&theta;, &omega; | torque | Gravity + damping |
| Spring | displacement, velocity | force | Hooke's law + damping |

## Deploy to GitHub Pages

```bash
npm run build
# The dist/ directory contains a static site ready to deploy
```

With GitHub Actions, add a workflow that runs `npm run build` and deploys `dist/` to Pages.

## Stack

- React 18
- Vite 5
- Tailwind CSS 3
- Recharts (loss curve)
- HTML5 Canvas (physics + latent space visualization)
