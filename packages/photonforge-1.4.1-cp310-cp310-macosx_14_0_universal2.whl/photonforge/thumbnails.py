from collections import defaultdict

try:
    from importlib.resources import as_file, files
except ImportError:
    from importlib_resources import as_file, files


_thumb_dir = files("photonforge").joinpath("thumbnails")

_default = _thumb_dir.joinpath("black_box.svg").read_text()

thumbnails = defaultdict(lambda: _default)

for item in _thumb_dir.iterdir():
    if not item.is_file():
        continue
    with as_file(item) as f:
        if f.suffix != ".svg":
            continue
        name = f.stem.encode("utf-8")
    thumbnails[name] = item.read_text()
