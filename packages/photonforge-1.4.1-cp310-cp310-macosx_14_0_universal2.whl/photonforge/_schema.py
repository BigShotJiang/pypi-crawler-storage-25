"""PhotonForge Store JSON schema.

Defines the Pydantic models that describe the JSON serialization format
for all PhotonForge objects.

Object graph
------------
Most objects are serialized **inline** as nested JSON.  Only two types
use UUID-based references that point into the Store ``data`` array:

- **Technology** -- referenced by ``TechnologyID`` (a UUID string).
- **Component** -- referenced by ``ComponentID`` (a UUID string).

Every other type (structures, ports, labels, models, etc.) is embedded
directly inside its parent object.

Cross-references inside a Component
------------------------------------
Within a single ``Component`` object there are two compact cross-
reference schemes that avoid duplicating data:

``Port.spec``
    When a Port's spec originates from the parent Component's
    Technology, the ``spec`` field is a **string** -- the key into
    ``Technology.ports``.  Otherwise it is a full inline ``PortSpec``.

``ReferencePort.reference``
    Virtual connections identify References by their **integer index**
    in the Component's ``references`` array (0-based).

Embedded PhotonForge objects in NativeData
------------------------------------------
Python-native containers (dicts, lists, ...) can embed PhotonForge
objects.  Two wrapper formats exist:

``NativePhotonForgeRef``
    ``{"type": "photonforge_ref", "id": "<uuid>"}`` -- for Technology
    and Component (UUID looked up in ``Store.data``).

``NativePhotonForgeInline``
    ``{"type": "photonforge", "data": {...}}`` -- for every other type
    (the ``data`` value is the full inline serialization).
"""

from typing import Annotated, Any, Literal, NewType

from pydantic import BaseModel, Discriminator, Field, Tag

# ---------------------------------------------------------------------------
# Scalar type aliases
# ---------------------------------------------------------------------------

type UInt8 = Annotated[int, Field(ge=0, le=2**8 - 1)]
type UInt32 = Annotated[int, Field(ge=0, le=2**32 - 1)]
type UInt64 = Annotated[int, Field(ge=0, le=2**64 - 1)]
type Int64 = Annotated[int, Field(ge=-(2**63), le=2**63 - 1)]

type Bool01 = Literal[0, 1]

# Coordinates are stored as integers and scaled by 1e-5 to get micrometers.
type Coordinate = Annotated[Int64, Field(json_schema_extra={"scale": 1e-5, "unit": "μm"})]
type Coordinate2D = tuple[Coordinate, Coordinate]
type Coordinate3D = tuple[Coordinate, Coordinate, Coordinate]
type Coordinate2DVector = list[Coordinate2D]

type PositiveCoordinate = Annotated[Coordinate, Field(gt=0)]
type NonNegativeCoordinate = Annotated[Coordinate, Field(ge=0)]

type Float2D = tuple[float, float]
type Float3D = tuple[float, float, float]

type Radius = Annotated[float, Field(gt=0, json_schema_extra={"scale": 1e-5, "unit": "μm"})]

type Fraction = Annotated[float, Field(ge=0, le=1)]
type Angle = Annotated[float, Field(json_schema_extra={"unit": "°"})]

type Complex = tuple[float, float]

# GDS-II style layer: (layer_number, datatype).
type Layer = tuple[UInt32, UInt32]

type Color = tuple[UInt8, UInt8, UInt8, UInt8]  # RGBA

# Boolean set operations: union, intersection, difference, symmetric difference.
type Operation = Literal["+", "*", "-", "^"]

type Polarization = Literal["", "TE", "TM"]

# ---------------------------------------------------------------------------
# Type discriminator constants -- every serialized object carries a ``type``
# integer that identifies its class.
# ---------------------------------------------------------------------------

StoreType = 1
PropertiesType = 2
RandomVariableType = 3
ExpressionType = 4
NativeType = 5  # Wrapped Python object
MediumType = 6  # Tidy3d medium, but also works for any tidy3d base model
LayerSpecType = 7
MaskSpecType = 8
ExtrusionSpecType = 9
PortSpecType = 10
TechnologyType = 11
RectangleType = 12
CircleType = 13
PolygonType = 14
PathType = 15
PolyhedronType = 16
ExtrudedType = 17
ConstructiveSolidType = 18
LabelType = 19
PortType = 20
FiberPortType = 21
GaussianPortType = 22
TerminalType = 23
ModelType = 24
ReferenceType = 25
ComponentType = 26
SMatrixType = 27
PoleResidueMatrixType = 28
TimeDomainModelType = 29
TimeSeriesType = 30
TimeStepperType = 31
InterpolatorType = 32
ZMatrixType = 33
YMatrixType = 34
MNAMatrixType = 35

PhotonForgeType = Literal[
    StoreType,
    PropertiesType,
    RandomVariableType,
    ExpressionType,
    NativeType,
    MediumType,
    LayerSpecType,
    MaskSpecType,
    ExtrusionSpecType,
    PortSpecType,
    TechnologyType,
    RectangleType,
    CircleType,
    PolygonType,
    PathType,
    PolyhedronType,
    ExtrudedType,
    ConstructiveSolidType,
    LabelType,
    PortType,
    FiberPortType,
    GaussianPortType,
    TerminalType,
    ModelType,
    ReferenceType,
    ComponentType,
    SMatrixType,
    PoleResidueMatrixType,
    TimeDomainModelType,
    TimeSeriesType,
    TimeStepperType,
    InterpolatorType,
    ZMatrixType,
    YMatrixType,
    MNAMatrixType,
]


def _get_type_discriminator(obj: object) -> int:
    if isinstance(obj, dict):
        return obj.get("type", 0)
    return getattr(obj, "type", 0)


# ---------------------------------------------------------------------------
# UUID reference types -- only Technology and Component are referenced by
# UUID strings in the Store ``data`` array.  All other types are inline.
# ---------------------------------------------------------------------------

TechnologyID = NewType("TechnologyID", str)
ComponentID = NewType("ComponentID", str)

# ---------------------------------------------------------------------------
# NativeData -- recursive type for serializing arbitrary Python values
# (used by ParametricData.kwargs and others).
# ---------------------------------------------------------------------------

type NativeData = (
    None
    | float
    | str
    | list[NativeData]  # python sequences, except tuple
    | NativeBoolean
    | NativeInteger
    | NativeComplex
    | NativeBytes
    | NativeDict
    | NativeTuple
    | NativeRegex
    | NativeTidy3D
    | NativePhotonForgeRef
    | NativePhotonForgeInline
)


class NativeInteger(BaseModel):
    type: Literal["integer"]
    value: Int64


class NativeBoolean(BaseModel):
    type: Literal["bool"]
    value: Bool01


class NativeComplex(BaseModel):
    type: Literal["complex"]
    real: float
    imag: float


class NativeBytes(BaseModel):
    type: Literal["b64encoded"]
    value: str  # Base64-encoded byte string


class NativeDict(BaseModel):
    type: Literal["dict"]
    values: list[tuple[NativeData, NativeData]]  # (key, value) array


class NativeTuple(BaseModel):
    type: Literal["tuple"]
    values: list[NativeData]


class NativeRegex(BaseModel):
    type: Literal["regex"]
    pattern: str
    flags: int  # flags used in the python re module


class NativeTidy3D(BaseModel):
    """Embedded Tidy3D model.

    Not all Tidy3D models support JSON; in those cases ``value`` is a
    Base64-encoded byte string with the HDF5 representation.
    """

    type: Literal["tidy3d"]
    value: Any | str


class NativePhotonForgeRef(BaseModel):
    """UUID reference to a Technology or Component in ``Store.data``."""

    type: Literal["photonforge_ref"]
    id: TechnologyID | ComponentID


class NativePhotonForgeInline(BaseModel):
    """Inline serialized PhotonForge object (any type except
    Technology/Component)."""

    type: Literal["photonforge"]
    data: dict[str, Any]


# ---------------------------------------------------------------------------
# Base type -- common fields shared by all PhotonForge objects.
# ---------------------------------------------------------------------------


class BaseType(BaseModel):
    """Common base for all serialized PhotonForge objects.

    Every object carries a ``type`` discriminator, a semantic version
    string, and optional ``properties``.
    """

    type: PhotonForgeType
    type_version: str
    properties: "Properties | None"


# ---------------------------------------------------------------------------
# Properties
# ---------------------------------------------------------------------------


class Native(BaseType):
    """Wrapper for an arbitrary Python object stored as NativeData."""

    type: Literal[NativeType]
    data: NativeData


class ScalarProperty(BaseModel):
    variant: Literal["int64", "double", "string"]
    value: Int64 | float | str


class Property(BaseModel):
    variant: Literal["int64", "double", "string", "array"]
    value: Int64 | float | str | list[ScalarProperty]


class NamedProperties(BaseModel):
    name: str
    values: list[Property]


class Properties(BaseModel):
    """Key-value property bag that can be attached to any object via
    ``BaseType.properties``."""

    type: Literal[PropertiesType]
    type_version: str
    data: list[NamedProperties]


class RandomVariable(BaseType):
    variant: Literal["Fixed", "Normal", "Uniform", "Discrete"]
    name: str
    value_spec: NativeData


# ---------------------------------------------------------------------------
# Expressions and interpolators
# ---------------------------------------------------------------------------


class SingleExpression(BaseModel):
    name: str
    variant: Literal["float64", "str"]
    value: float | str


class DirectExpression(BaseModel):
    """Lightweight expression used in-place (not a standalone object)."""

    parameters: list[str]
    expressions: list[SingleExpression]


class Expression(BaseType):
    """Standalone expression object (has its own id and properties)."""

    parameters: list[str]
    expressions: list[SingleExpression]


class Interpolator(BaseType):
    """Multi-dimensional interpolation table."""

    scalar_value: Bool01
    method: Literal["linear", "barycentric", "cubicspline", "pchip", "akima", "makima"]
    coords: Literal["real_imag", "mag_phase"]
    extrapolation: Literal["extrapolate", "constant"]
    parameter_names: list[str]
    x: list[list[float]]
    y: list[list[float] | list[Complex]]


# ---------------------------------------------------------------------------
# Technology building blocks
# ---------------------------------------------------------------------------


class LayerSpec(BaseType):
    """Display and metadata specification for a single GDS layer."""

    layer: Layer
    description: str
    color: Color
    pattern: Literal[
        "solid",
        "hollow",
        "\\",
        "\\\\",
        "/",
        "//",
        "|",
        "||",
        "-",
        "=",
        "x",
        "xx",
        "+",
        "++",
        ".",
        ":",
    ]


type MaskOperand = list[InnerMaskSpec]


class InnerMaskSpec(BaseModel):
    """Mask specification node used inside MaskSpec.operands (recursive)."""

    mask_type: Literal["boolean", "layer"]
    layer: Layer
    operation: Operation
    operands0: MaskOperand
    operands1: MaskOperand
    dilation: Coordinate
    translation: Coordinate2D


class MaskSpec(BaseType):
    """Top-level mask specification for extrusion."""

    mask_type: Literal["boolean", "layer"]
    layer: Layer
    operation: Operation
    operands0: MaskOperand
    operands1: MaskOperand
    dilation: Coordinate
    translation: Coordinate2D


class Medium(BaseType):
    """Wrapper around a Tidy3D base model."""

    # Using Any to avoid Pydantic v1/v2 incompatibility with Tidy3dBaseModel.
    medium: Any


class Media(BaseModel):
    """Pair of optical and electrical media (either may be absent)."""

    optical: Medium | None
    electrical: Medium | None


class ExtrusionSpec(BaseType):
    """Specifies how a 2D mask is extruded into a 3D structure."""

    media: Media
    limits: Coordinate2D
    sidewall_angle: Angle
    reference: Coordinate
    mask_spec: MaskSpec


class PathProfile(BaseModel):
    width: PositiveCoordinate
    offset: Coordinate
    layer: Layer


class NamedPathProfile(BaseModel):
    name: str
    width: PositiveCoordinate
    offset: Coordinate
    layer: Layer


class ElectricalSpec(BaseModel):
    """Electrical characteristics attached to a PortSpec."""

    voltage_path: Coordinate2DVector
    current_path: Coordinate2DVector
    impedance: Interpolator | None


class PortSpec(BaseType):
    """Cross-section specification shared by ports of the same type.

    Defined in ``Technology.ports`` and referenced by ``Port.spec``
    (either inline or by name string -- see ``Port``).
    """

    description: str
    width: PositiveCoordinate
    limits: Coordinate2D
    default_radius: Coordinate
    num_modes: UInt32
    added_solver_modes: UInt32
    polarization: Polarization
    target_neff: float
    path_profiles: list[PathProfile] | list[NamedPathProfile]
    electrical_spec: ElectricalSpec | None


class ParametricData(BaseModel):
    """Stores the parametric function and its arguments for parametric
    components, models, and technologies."""

    function: str | None
    kwargs: list[tuple[str, NativeData]]
    random_variables: list[RandomVariable]


# ---------------------------------------------------------------------------
# Technology
# ---------------------------------------------------------------------------


class Technology(BaseType):
    """Process technology definition.

    Referenced by UUID (``TechnologyID``) from ``Component.technology``
    and ``ConfigData.default_technology``.  All child objects (layers,
    extrusion specs, port specs, media) are serialized inline.
    """

    name: str
    version: str
    layers: list[tuple[str, LayerSpec]]  # name -> spec, name is unique
    extrusion_specs: list[ExtrusionSpec]
    ports: list[tuple[str, PortSpec]]  # name -> spec, name is unique
    connections: list[tuple[Layer, Layer]]
    background_media: Media
    parametric_data: ParametricData | None


# ---------------------------------------------------------------------------
# 2D geometry (structures)
# ---------------------------------------------------------------------------


class Rectangle(BaseType):
    center: Coordinate2D
    size: tuple[NonNegativeCoordinate, NonNegativeCoordinate]
    rotation: Angle


class Circle(BaseType):
    radius: tuple[PositiveCoordinate, PositiveCoordinate]
    inner_radius: tuple[NonNegativeCoordinate, NonNegativeCoordinate]
    center: Coordinate2D
    sector: tuple[Angle, Angle]
    rotation: Angle
    min_evals: UInt32


class Polygon(BaseType):
    vertices: Coordinate2DVector
    holes: list[Coordinate2DVector]


# --- Path interpolators (control width/offset along a Path) ---------------

type PathInterpolator = (
    ConstantInterpolator
    | LinearInterpolator
    | SmoothInterpolator
    | ParametricInterpolator
    | SliceInterpolator
)


class ConstantInterpolator(BaseModel):
    variant: Literal["constant"]
    value: float


class LinearInterpolator(BaseModel):
    variant: Literal["linear"]
    values: tuple[float, float]


class SmoothInterpolator(BaseModel):
    variant: Literal["smooth"]
    values: tuple[float, float]


class ParametricInterpolator(BaseModel):
    variant: Literal["parametric"]
    expression: DirectExpression
    scaling: float
    offset: float


class SliceInterpolator(BaseModel):
    variant: Literal["slice"]
    base: PathInterpolator
    limits: tuple[Fraction, Fraction]


# --- Path sections (segments that compose a Path) -------------------------

type PathSection = (
    SegmentPathSection
    | ArcPathSection
    | EulerPathSection
    | BezierPathSection
    | ParametricPathSection
)


class BasePathSection(BaseModel):
    variant: Literal["segment", "arc", "euler", "bezier", "parametric"]
    width: PathInterpolator
    offset: PathInterpolator
    min_evals: UInt32
    max_evals: UInt32


class SegmentPathSection(BasePathSection):
    vertices: Coordinate2DVector
    bevel_join_limit: float
    round_joins: Bool01


class ArcPathSection(BasePathSection):
    radius: tuple[Radius, Radius]
    center: Float2D
    endpoint_delta: Float2D
    initial_angle: Angle
    final_angle: Angle
    rotation: Angle


class EulerPathSection(BasePathSection):
    radius_eff: Radius
    origin: Float2D
    endpoint_delta: Float2D
    initial_angle: Angle
    final_angle: Angle
    euler_fraction: Fraction


class BezierPathSection(BasePathSection):
    controls: Coordinate2DVector


class ParametricPathSection(BasePathSection):
    expression: DirectExpression
    origin: Float2D
    rotation: Angle
    scaling: float
    x_reflection: Bool01


class Path(BaseType):
    scale_profile: Bool01
    round_caps: tuple[Bool01, Bool01]
    cap_extensions: tuple[float, float]
    end_position: Coordinate2D
    end_width: NonNegativeCoordinate
    end_offset: Coordinate
    path_sections: list[PathSection]


# Discriminated union of all 2D structure types (Rectangle, Circle,
# Polygon, Path).  Dispatched on the ``type`` field.
type AnyStructure = Annotated[
    Annotated[Rectangle, Tag(RectangleType)]
    | Annotated[Circle, Tag(CircleType)]
    | Annotated[Polygon, Tag(PolygonType)]
    | Annotated[Path, Tag(PathType)],
    Discriminator(_get_type_discriminator),
]


# ---------------------------------------------------------------------------
# 3D geometry
# ---------------------------------------------------------------------------


class Polyhedron(BaseType):
    """Arbitrary 3D solid defined by a triangle mesh."""

    vertices: list[Coordinate3D]
    triangles: list[tuple[UInt64, UInt64, UInt64]]
    medium: Medium


class Extruded(BaseType):
    """3D solid created by extruding a 2D structure along an axis."""

    face: AnyStructure
    limits: Coordinate2D
    dilations: Coordinate2D
    axis: Literal["x", "y", "z"]
    medium: Medium


# Discriminated union of all 3D structure types.
type AnyStructure3D = Annotated[
    Annotated[Polyhedron, Tag(PolyhedronType)]
    | Annotated[Extruded, Tag(ExtrudedType)]
    | Annotated[ConstructiveSolid, Tag(ConstructiveSolidType)],
    Discriminator(_get_type_discriminator),
]


class ConstructiveSolid(BaseType):
    """3D solid built from boolean operations on other 3D structures."""

    operands: tuple[list[AnyStructure3D], list[AnyStructure3D]]
    operation: Operation
    medium: Medium


# ---------------------------------------------------------------------------
# Labels
# ---------------------------------------------------------------------------


class Label(BaseType):
    text: str
    origin: Coordinate2D
    rotation: Angle
    scaling: float
    anchor: Literal["NW", "N", "NE", "W", "O", "E", "SW", "S", "SE"]
    x_reflection: Bool01


# ---------------------------------------------------------------------------
# Ports -- 2D (in-plane) and 3D (out-of-plane)
# ---------------------------------------------------------------------------


class Port(BaseType):
    """2D waveguide or electrical port.

    ``spec`` is either:

    - A **string** key into ``Technology.ports`` (preferred when the
      port spec comes from the Component's Technology -- preserves
      object identity on deserialization), or
    - A full inline **PortSpec** object (fallback for specs not found
      in the Technology).
    """

    center: Coordinate2D
    input_direction: float
    bend_radius: Coordinate
    spec: PortSpec | str
    extended: Bool01
    inverted: Bool01


class GaussianPort(BaseType):
    """Free-space port with a Gaussian beam profile."""

    center: Coordinate3D
    input_vector: Float3D
    waist_radius: float
    waist_position: float
    polarization_angle: float
    field_tolerance: float


class FiberPort(BaseType):
    """Fiber-coupled 3D port with an explicit cross-section geometry."""

    center: Coordinate3D
    input_vector: Float3D
    size: Coordinate2D
    extrusion_limits: Coordinate2D
    cross_section: list[tuple[AnyStructure, Medium]]
    target_neff: float
    num_modes: UInt32
    added_solver_modes: UInt32
    polarization: Polarization


# Discriminated union of all port types.
type AnyPort = Annotated[
    Annotated[Port, Tag(PortType)]
    | Annotated[FiberPort, Tag(FiberPortType)]
    | Annotated[GaussianPort, Tag(GaussianPortType)],
    Discriminator(_get_type_discriminator),
]


# ---------------------------------------------------------------------------
# Terminals and models
# ---------------------------------------------------------------------------


class Terminal(BaseType):
    """Electrical terminal associated with a routing layer."""

    routing_layer: Layer
    structure: AnyStructure | None


class TimeStepper(BaseType):
    """Time-domain simulation stepping configuration."""

    name: str
    parametric_data: ParametricData | None


class PortTerminalSpecSchema(BaseModel):
    signal_terminal: str
    reference_terminal: str | None
    impedance: Complex


class Model(BaseType):
    """Simulation model attached to a Component."""

    name: str
    time_stepper: TimeStepper | None
    parametric_data: ParametricData | None
    base_class: Literal["Model", "LumpedModel"] = "Model"
    port_map: dict[str, PortTerminalSpecSchema] | None = None


# ---------------------------------------------------------------------------
# References and virtual connections
# ---------------------------------------------------------------------------


class ReferencePort(BaseModel):
    """Identifies a port on a specific Reference within a Component.

    ``reference`` is a 0-based index into ``Component.references``.
    """

    reference: UInt64
    port_name: str
    repetition_index: UInt64


type VirtualConnection = tuple[ReferencePort, ReferencePort]


class UpdateKwargs(BaseModel):
    """Keyword overrides applied when a Reference re-evaluates its
    parametric component."""

    technology: NativeDict | None
    component: NativeDict | None
    model: NativeDict | None
    s_matrix: NativeDict | None


class Reference(BaseType):
    """Instance of another Component, optionally arrayed.

    ``component`` is a ``ComponentID`` (UUID string) pointing to an
    entry in ``Store.data``.
    """

    component: ComponentID
    origin: Coordinate2D
    rotation: Angle
    scaling: float
    x_reflection: Bool01
    columns: UInt32
    rows: UInt32
    spacing: Coordinate2D
    update_kwargs: UpdateKwargs | None


# ---------------------------------------------------------------------------
# Component
# ---------------------------------------------------------------------------


class Component(BaseType):
    """Top-level design unit.

    Referenced by UUID (``ComponentID``) from ``Reference.component``
    and ``Store.data``.

    - ``technology`` is a ``TechnologyID`` (UUID) pointing to a
      Technology in ``Store.data``.
    - ``references`` contains inline Reference objects; each Reference
      in turn points to another Component by UUID.
    - ``virtual_connections`` identifies References by their index in
      the ``references`` array (see ``ReferencePort``).
    - ``ports`` may contain Port objects whose ``spec`` is a string
      key into the Technology's ``ports`` map (see ``Port``).
    """

    name: str
    references: list[Reference]
    structures: list[tuple[Layer, list[AnyStructure]]]  # Layer is unique
    labels: list[tuple[Layer, list[Label]]]  # Layer is unique
    ports: list[tuple[str, AnyPort]]  # name is unique
    terminals: list[tuple[str, Terminal]]  # name is unique
    virtual_connections: list[VirtualConnection]
    models: list[tuple[str, Model]]  # name is unique
    active_optical_model_name: str
    active_electrical_model_name: str
    technology: TechnologyID
    parametric_data: ParametricData | None


# ---------------------------------------------------------------------------
# S-parameter and impedance matrices
# ---------------------------------------------------------------------------

type SMatrixKey = tuple[str, str]


class SMatrix(BaseType):
    """Frequency-domain scattering parameter matrix.

    ``ports`` entries may be None when a port name appears in
    ``elements`` keys but has no associated Port object.
    """

    frequencies: list[float]
    elements: list[tuple[SMatrixKey, list[Complex]]]
    ports: list[tuple[str, AnyPort | None]]


type ZMatrixKey = tuple[str, str]


class ZMatrix(BaseType):
    """Impedance matrix."""

    frequencies: list[float]
    elements: list[tuple[ZMatrixKey, list[Complex]]]
    terminals: list[tuple[str, Terminal | None]]


type YMatrixKey = tuple[str, str]


class YMatrix(BaseType):
    """Admittance matrix."""

    frequencies: list[float]
    elements: list[tuple[YMatrixKey, list[Complex]]]
    terminals: list[tuple[str, Terminal | None]]


type MNAMatrixKey = tuple[str, str]


class MNAMatrix(BaseType):
    """Modified Nodal Analysis matrix."""

    frequencies: list[float]
    elements: list[tuple[MNAMatrixKey, list[Complex]]]
    terminals: list[tuple[str, Terminal | None]]


class PoleResidueMatrix(BaseType):
    """Rational approximation of an S-matrix via poles and residues."""

    residues: list[tuple[SMatrixKey, list[Complex]]]
    poles: list[Complex]
    delays: list[tuple[SMatrixKey, float]]
    ports: list[tuple[str, AnyPort | None]]
    frequency_scaling: float


# ---------------------------------------------------------------------------
# Time-domain types
# ---------------------------------------------------------------------------


class TimeDomainModel(BaseType):
    """State-space model for time-domain simulation."""

    pole_residue_matrix: PoleResidueMatrix
    state: list[tuple[str, list[Complex]]]
    output: list[tuple[SMatrixKey, list[Complex]]]
    time_step: float


class TimeSeries(BaseType):
    """Recorded time-domain signal data."""

    shape: tuple[UInt64, UInt64, Literal[2]]
    values: list[float]  # column-major order in the first 2 indices
    keys: list[str]
    time_step: float
    time_index: Int64


# ---------------------------------------------------------------------------
# Store configuration and top-level container
# ---------------------------------------------------------------------------


class ConfigData(BaseModel):
    """Global configuration embedded in a Store."""

    grid: Coordinate
    tolerance: Coordinate
    mesh_refinement: float
    default_technology: TechnologyID | None
    default_time_steppers: NativeDict
    default_kwargs: NativeDict


# Union of every object type that can appear in ``Store.data``.
type AnyObject = Annotated[
    Annotated[Properties, Tag(PropertiesType)]
    | Annotated[RandomVariable, Tag(RandomVariableType)]
    | Annotated[Expression, Tag(ExpressionType)]
    | Annotated[Native, Tag(NativeType)]
    | Annotated[Medium, Tag(MediumType)]
    | Annotated[LayerSpec, Tag(LayerSpecType)]
    | Annotated[MaskSpec, Tag(MaskSpecType)]
    | Annotated[ExtrusionSpec, Tag(ExtrusionSpecType)]
    | Annotated[PortSpec, Tag(PortSpecType)]
    | Annotated[Technology, Tag(TechnologyType)]
    | Annotated[Rectangle, Tag(RectangleType)]
    | Annotated[Circle, Tag(CircleType)]
    | Annotated[Polygon, Tag(PolygonType)]
    | Annotated[Path, Tag(PathType)]
    | Annotated[Polyhedron, Tag(PolyhedronType)]
    | Annotated[Extruded, Tag(ExtrudedType)]
    | Annotated[ConstructiveSolid, Tag(ConstructiveSolidType)]
    | Annotated[Label, Tag(LabelType)]
    | Annotated[Port, Tag(PortType)]
    | Annotated[FiberPort, Tag(FiberPortType)]
    | Annotated[GaussianPort, Tag(GaussianPortType)]
    | Annotated[Terminal, Tag(TerminalType)]
    | Annotated[Model, Tag(ModelType)]
    | Annotated[Reference, Tag(ReferenceType)]
    | Annotated[Component, Tag(ComponentType)]
    | Annotated[SMatrix, Tag(SMatrixType)]
    | Annotated[PoleResidueMatrix, Tag(PoleResidueMatrixType)]
    | Annotated[TimeDomainModel, Tag(TimeDomainModelType)]
    | Annotated[TimeSeries, Tag(TimeSeriesType)]
    | Annotated[TimeStepper, Tag(TimeStepperType)]
    | Annotated[Interpolator, Tag(InterpolatorType)]
    | Annotated[ZMatrix, Tag(ZMatrixType)]
    | Annotated[YMatrix, Tag(YMatrixType)]
    | Annotated[MNAMatrix, Tag(MNAMatrixType)],
    Discriminator(_get_type_discriminator),
]


class Store(BaseModel):
    """Top-level container for serialized PhotonForge data.

    ``data`` is a dictionary mapping UUID strings to serialized
    objects.  Only Technology and Component objects appear here;
    all other types are embedded inline within their parent.

    ``top_content`` lists the UUIDs and types of the objects that were
    explicitly exported (the "entry points" into the data).
    """

    type: Literal[StoreType]
    type_version: str
    config: ConfigData
    top_content: list[tuple[str, PhotonForgeType]]
    data: dict[str, AnyObject]
    properties: Properties | None


if __name__ == "__main__":
    import json

    schema = Store.model_json_schema()
    print(json.dumps(schema, indent=2))
