from collections.abc import Sequence

import numpy
from numpy.random import SeedSequence, default_rng

from ..extension import (
    Component,
    TimeStepper,
    register_time_stepper_class,
)
from ..typing import (
    Frequency,
    Gain,
    NonNegativeInt,
    Power_dBm,
    TimeDelay,
    annotate,
)
from ..utils import K_B, H


class OpticalAmplifierTimeStepper(TimeStepper):
    r"""Time-stepper for a unidirectional optical amplifier.

    This model implements a simple optical amplifier with a constant gain
    and amplified spontaneous emission (ASE) noise. The ASE noise power is
    determined by the amplifier's gain and noise figure.

    Notes:
    ASE noise is modeled as a complex Gaussian random process. Its one-sided
    power spectral density (PSD) is:

    .. math::

       S_\text{ASE} &= n_{sp} (10^\frac{g}{10} - 1) h\nu

       n_\text{sp} &= \frac{10^\frac{\text{NF}}{10}}{2}

    in which :math:`g` is the power gain in dB, :math:`h\nu` is the photon
    energy, and :math:`n_\text{sp}` is the spontaneous emission factor,
    derived from the noise figure.

    The discrete-time simulation represents a spectral slice of width
    :math:`1/\Delta t` centered at the carrier frequency. To conserve the
    total physical noise energy in this slice, the noise variance per sample
    is:

    .. math:: \sigma^2 = \frac{S_\text{ASE}}{\Delta t}

    This corresponds to integrating the optical PSD over the full simulation
    bandwidth.

    Args:
        gain: The amplifier's power gain.
        noise_figure: The amplifier's noise figure (NF). If ``None``, noise
          is disabled.
        ports: Input and output port names. If not set, the *sorted* list of
          port names from the component is used.
        seed: Random number generator seed to ensure reproducibility.

    Reference:
        Agrawal, G. P. (2010). *Fiber-Optic Communication Systems*. Wiley.
    """

    def __init__(
        self,
        *,
        gain: Gain = 0,
        noise_figure: Gain | None = None,
        ports: annotate(Sequence[str], minItems=2, maxItems=2) | None = None,
        seed: NonNegativeInt | None = None,
    ) -> None:
        super().__init__(gain=gain, noise_figure=noise_figure, ports=ports, seed=seed)

    def setup_state(
        self,
        *,
        component: Component,
        time_step: TimeDelay,
        carrier_frequency: Frequency,
        **kwargs: object,
    ) -> None:
        """Initialize internal state.

        Args:
            component: Component representing amplifier.
            time_step: The interval between time steps (in seconds).
            carrier_frequency: The carrier frequency used to construct the time
              stepper. The carrier should be omitted from the input signals, as
              it is handled automatically by the time stepper.
            kwargs: Unused.
        """
        p = self.parametric_kwargs

        ports = p["ports"]
        component_ports = sorted(component.select_ports("optical"))
        if ports is None:
            ports = component_ports
            if len(ports) != 2:
                raise RuntimeError(
                    "OpticalAmplifierTimeStepper can only be used in components with 2 optical "
                    "ports."
                )
        elif len(ports) != 2:
            raise ValueError("'Argument 'ports' must be a sequence of 2 port names.")
        elif not all(name in component_ports for name in ports):
            raise RuntimeError(
                f"Not all port names defined in OpticalAmplifierTimeStepper ({ports!r}) match the "
                f"optical port names in component '{component.name}' ({component_ports!r})."
            )

        self.keys = tuple(p + "@0" for p in ports)

        g = 10.0 ** (p["gain"] / 10.0)
        nf = p["noise_figure"]
        n_sp = 0.0 if nf is None else (0.5 * 10.0 ** (nf / 10.0))
        s_ase = n_sp * (g - 1.0) * H * carrier_frequency

        self._gain = g**0.5
        self._stdev = (0.5 * s_ase / time_step) ** 0.5
        self._seed = SeedSequence() if p["seed"] is None else p["seed"]
        self.reset()

    def reset(self) -> None:
        """Reset internal state."""
        self._rng = default_rng(self._seed)
        self._sample_noise()

    def _sample_noise(self) -> None:
        self._ase = self._rng.normal(0, self._stdev) + 1j * self._rng.normal(0, self._stdev)

    def step_single(
        self,
        inputs: numpy.ndarray,
        outputs: numpy.ndarray,
        time_index: int,
        update_state: bool,
        shutdown: bool,
    ) -> None:
        """Take a single time step on the given inputs.

        Args:
            inputs: Input values at the current time step. Must be a 1D array of
              complex values ordered
              according to :attr:`keys`.
            outputs: Pre-allocated output array where results will be stored.
              Same size and type as ``inputs``.
            time_index: Time series index for the current input.
            update_state: Whether to update the internal stepper state.
            shutdown: Whether this is the last call to the single stepping
              function for the provided :class:`TimeSeries`.
        """
        outputs[1] = self._ase + self._gain * inputs[0]
        if update_state:
            self._sample_noise()


class ElectricalAmplifierTimeStepper(TimeStepper):
    r"""Time-stepper for a broadband amplifier or modulator dirver.

    This model implements an electrical amplifier with linear gain, noise,
    bandwidth limiting, port reflections, and common nonlinear effects: 1 dB
    compression, third-order intercept point (IP3), and saturation.

    Args:
        gain: The amplifier's power gain.
        f_3dB: -3 dB frequency cutoff for bandwidth limiting.
        saturation_power: Output saturation power.
        compression_power: 1 dB compression power.
        ip3: Third order intercept point.
        noise_figure: The amplifier's noise figure (NF). If ``None``,
          noise is disabled.
        r0: Reflection coefficient for the input port.
        r1: Reflection coefficient for the output port.
        ports: Input and output port names. If not set, the *sorted* list of
          port names from the component is used.
        seed: Random number generator seed to ensure reproducibility.

    Notes:
        The forward path signal is processed through the following stages at
        each time step:

        1.  Low-pass filter for bandwidth limiting:

            .. math::

               y_0\![n] &= \alpha y_0\![n-1] + (1-\alpha) G_a a_\text{in}

               \alpha &= e^{-2\pi f_\text{3dB} \Delta t}

               G_a &= 10^\frac{G_\text{dB}}{20}

        2.  Soft-knee compression:

            .. math::

               y_1 &= y_0 \left( 1 + \frac{c_s}{P_\text{1dB}} y_0^2
                 \right)^{-\frac{1}{2}}

               c_s &= 10^\frac{1}{10} - 1

        3.  Cubic IP3 nonlinearity:

            .. math::

                y_2 = y_1 \left(1 - \frac{1}{P_\text{IP3}} y_1^2\right)

        4.  Smooth saturation: A `tanh` function smoothly clamps the output
            amplitude to approach :math:`\sqrt{P_\text{sat}}`.

        5.  Additive noise: if enabled, white Gaussian noise is added to the
            output. The noise power spectral density is derived from the
            noise figure :math:`F` as :math:`S_P = k_B T_0 G_\text{dB} F`.
    """

    def __init__(
        self,
        *,
        gain: Gain = 0,
        f_3dB: annotate(Frequency | None, label="f 3dB") = None,
        saturation_power: Power_dBm | None = None,
        compression_power: Power_dBm | None = None,
        ip3: annotate(Power_dBm | None, label="IP3") = None,
        noise_figure: Gain | None = None,
        r0: annotate(float, minimum=-1, maximum=1) = 0,
        r1: annotate(float, minimum=-1, maximum=1) = 0,
        ports: annotate(Sequence[str], minItems=2, maxItems=2) | None = None,
        seed: NonNegativeInt | None = None,
    ) -> None:
        super().__init__(
            gain=gain,
            f_3dB=f_3dB,
            saturation_power=saturation_power,
            compression_power=compression_power,
            ip3=ip3,
            noise_figure=noise_figure,
            r0=r0,
            r1=r1,
            ports=ports,
            seed=seed,
        )

    def setup_state(
        self,
        *,
        component: Component,
        time_step: TimeDelay,
        **kwargs: object,
    ) -> None:
        """Initialize internal state.

        Args:
            component: Component representing the amplifier.
            time_step: The interval between time steps (in seconds).
            kwargs: Unused.
        """
        p = self.parametric_kwargs

        ports = p["ports"]
        component_ports = sorted(component.select_ports("electrical"))
        if ports is None:
            ports = component_ports
            if len(ports) != 2:
                raise RuntimeError(
                    "ElectricalAmplifierTimeStepper can only be used in components with 2 "
                    "electrical ports."
                )
        elif len(ports) != 2:
            raise ValueError("'Argument 'ports' must be a sequence of 2 port names.")
        elif not all(name in component_ports for name in ports):
            raise RuntimeError(
                f"Not all port names defined in ElectricalAmplifierTimeStepper ({ports!r}) match "
                f"the electrical port names in component '{component.name}' ({component_ports!r})."
            )

        self.keys = tuple(p + "@0" for p in ports)

        self._r0 = p["r0"]
        self._r1 = p["r1"]

        f_3dB = p["f_3dB"]
        self._alpha = 0.0 if f_3dB is None else numpy.exp(-2 * numpy.pi * f_3dB * time_step)

        g = 10.0 ** (p["gain"] / 10.0)
        self._gain = (1.0 - self._alpha) * g**0.5

        p1dB = p["compression_power"]
        self._c_1dB = 0.0 if p1dB is None else ((10.0**0.1 - 1.0) * 10.0 ** (p1dB / -10.0 + 3.0))

        ip3 = p["ip3"]
        self._c_ip3 = 0.0 if ip3 is None else (10.0 ** (ip3 / -10.0 + 3.0))

        p_sat = p["saturation_power"]
        self._sat = 0.0 if p_sat is None else (10.0 ** (p_sat / 20.0 - 1.5))

        T_0 = 290  # K
        nf = p["noise_figure"]
        self._stdev = (
            0.0 if nf is None else (0.5 * K_B * T_0 * g * 10 ** (nf / 10.0) / time_step) ** 0.5
        )
        self._seed = SeedSequence() if p["seed"] is None else p["seed"]

        self.reset()

    def reset(self) -> None:
        """Reset internal state."""
        self._y = 0.0
        self._rng = default_rng(self._seed)
        self._sample_noise()

    def _sample_noise(self) -> None:
        self._noise = self._rng.normal(0, self._stdev)

    def step_single(
        self,
        inputs: numpy.ndarray,
        outputs: numpy.ndarray,
        time_index: int,
        update_state: bool,
        shutdown: bool,
    ) -> None:
        """Take a single time step on the given inputs.

        Args:
            inputs: Input values at the current time step. Must be a 1D array of
              complex values ordered
              according to :attr:`keys`.
            outputs: Pre-allocated output array where results will be stored.
              Same size and type as ``inputs``.
            time_index: Time series index for the current input.
            update_state: Whether to update the internal stepper state.
            shutdown: Whether this is the last call to the single stepping
              function for the provided :class:`TimeSeries`.
        """
        x0 = inputs[0].real
        x1 = inputs[1].real

        y0 = self._alpha * self._y + self._gain * x0
        y = y0 / (1.0 + self._c_1dB * y0**2) ** 0.5
        y = y * max(0.0, (1.0 - self._c_ip3 * y**2))
        if self._sat > 0.0:
            y = self._sat * numpy.tanh(y / self._sat)

        outputs[0] = self._r0 * x0
        outputs[1] = self._r1 * x1 + self._noise + y

        if update_state:
            self._y = y0
            self._sample_noise()


register_time_stepper_class(OpticalAmplifierTimeStepper)
register_time_stepper_class(ElectricalAmplifierTimeStepper)
