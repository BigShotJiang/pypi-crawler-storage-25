from collections.abc import Sequence
from warnings import warn

import numpy

from ..extension import (
    Component,
    Interpolator,
    TimeStepper,
    register_time_stepper_class,
)
from ..typing import (
    Coordinate,
    Frequency,
    Impedance,
    Loss,
    PositiveFloat,
    PropagationLoss,
    Temperature,
    TimeDelay,
    annotate,
)
from ..utils import C_0, route_length
from .modulator import _get_impedance_runner

_zero = Interpolator([0], [0])


class _ArrayDelayBuffer:
    """Array-based delay buffer for high-performance array time stepping."""

    def __init__(
        self, keys: Sequence[str], delays: dict[str, float], default_delay: float, time_step: float
    ) -> None:
        self.keys = keys
        self.num_keys = len(keys)
        self.default_delay_steps = int(default_delay / time_step)

        # compute delay in time steps for each port
        self.delay_steps = numpy.array(
            [int(delays.get(name, default_delay) / time_step) for name in keys],
            dtype=numpy.intp,
        )

        # create buffer array: shape (num_keys, max_delay + 1)
        max_delay = max(self.delay_steps) if self.num_keys > 0 else self.default_delay_steps
        self.buffer_size = max_delay + 1
        self.buffers = numpy.zeros((self.num_keys, self.buffer_size), dtype=complex)
        self.initialized = False

    def reset(self) -> None:
        self.buffers.fill(0)
        # lazy initialization: get() returns fallback values until first put()
        self.initialized = False

    def put(self, buffer_index: int, values: Sequence[complex]) -> None:
        """Store values at the current buffer index."""
        for i in range(self.num_keys):
            idx = buffer_index % (self.delay_steps[i] + 1)
            self.buffers[i, idx] = values[i]
        self.initialized = True

    def get(self, buffer_index: int, fallback: numpy.ndarray, out: numpy.ndarray) -> numpy.ndarray:
        """Get delayed values from the buffer into pre-allocated output array.

        Args:
            buffer_index: Current buffer position.
            fallback: Array of fallback values for uninitialized or zero-delay ports.
            out: Pre-allocated output array to write results into.

        Returns:
            The same ``out`` array, now containing delayed values.
        """
        if not self.initialized:
            numpy.copyto(out, fallback)
            return out
        for i in range(self.num_keys):
            delay = self.delay_steps[i]
            if delay == 0:
                out[i] = fallback[i]
            else:
                idx = (buffer_index + 1) % (delay + 1)
                out[i] = self.buffers[i, idx]
        return out


class DelayedTimeStepper(TimeStepper):
    """Time stepper that adds time delays to other time steppers.

    Args:
        time_stepper: The time stepper to wrap with delays.
        input_delay: Default delay applied to the inputs.
        output_delay: Default delay applied to the outputs.
    """

    def __init__(
        self,
        time_stepper: TimeStepper,
        input_delay: TimeDelay = 0,
        output_delay: TimeDelay = 0,
    ) -> None:
        super().__init__(
            time_stepper=time_stepper, input_delay=input_delay, output_delay=output_delay
        )

    def setup_state(
        self,
        *,
        time_step: float,
        input_delays: dict[str, TimeDelay] = {},
        output_delays: dict[str, TimeDelay] = {},
        **kwargs: object,
    ) -> object:
        """Initialize internal buffers and set port-specific delays.

        Args:
            time_step: The interval between time steps (in seconds).
            input_delays: Mapping of port names to delays to override the
              default input delay.
            output_delays: Mapping of port names to delays to override the
              default output delay.
            kwargs: Unused.
        """
        self.buffer_index = 0
        self.time_stepper = self.parametric_kwargs["time_stepper"]
        self._time_step = time_step
        self._input_delays = input_delays
        self._output_delays = output_delays
        self._buffers_initialized = False

        # Simply return whatever the inner stepper returns
        return self.time_stepper.setup_state(time_step=time_step, **kwargs)

    def _initialize_buffers(self) -> None:
        """Initialize delay buffers once the wrapped stepper is ready."""
        if self._buffers_initialized:
            return

        keys = list(self.time_stepper.keys)
        num_keys = len(keys)
        self._input_buffer_array = _ArrayDelayBuffer(
            keys,
            self._input_delays,
            self.parametric_kwargs["input_delay"],
            self._time_step,
        )
        self._output_buffer_array = _ArrayDelayBuffer(
            keys,
            self._output_delays,
            self.parametric_kwargs["output_delay"],
            self._time_step,
        )

        # pre-allocate temporary buffers for step_single (avoids allocation in hot loop)
        self._temp_input_buffer = numpy.zeros(num_keys, dtype=complex)
        self._temp_output_buffer = numpy.zeros(num_keys, dtype=complex)
        self._buffers_initialized = True

    def reset(self) -> None:
        self.buffer_index = 0
        if self._buffers_initialized:
            self._input_buffer_array.reset()
            self._output_buffer_array.reset()
        self.time_stepper.reset()

    @property
    def keys(self) -> tuple[str, ...]:
        """Tuple of input/output keys."""
        return tuple(self.time_stepper.keys)

    def step_single(
        self,
        inputs: numpy.ndarray,
        outputs: numpy.ndarray,
        time_index: int,
        update_state: bool,
        shutdown: bool,
    ) -> None:
        """Take a single time step on the given inputs.

        Args:
            inputs: Input values at the current time step. Must be a 1D array of
              complex values ordered according to :attr:`keys`.
            outputs: Pre-allocated output array where results will be stored.
              Same size and type as ``inputs``.
            time_index: Time series index for the current input.
            update_state: Whether to update the internal stepper state.
            shutdown: Whether this is the last call to the single stepping
              function for the original :class:`TimeSeries`.
        """
        if not self._buffers_initialized:
            self._initialize_buffers()

        buffer_index = self.buffer_index
        if update_state:
            self.buffer_index += 1
            self._input_buffer_array.put(buffer_index, inputs)

        # use pre-allocated buffer for delayed inputs
        self._input_buffer_array.get(buffer_index, inputs, self._temp_input_buffer)

        # step the wrapped time stepper
        self.time_stepper.step_single(
            self._temp_input_buffer, outputs, time_index, update_state, shutdown
        )

        if update_state:
            self._output_buffer_array.put(buffer_index, outputs)

        # get delayed outputs directly into the outputs array
        self._output_buffer_array.get(buffer_index, outputs, self._temp_output_buffer)
        numpy.copyto(outputs, self._temp_output_buffer)

    def _step_single_unchecked(
        self,
        inputs: numpy.ndarray,
        outputs: numpy.ndarray,
        time_index: int,
        update_state: bool,
        shutdown: bool,
    ) -> None:
        """Fast-path step for internal use by CircuitTimeStepper.

        Skips argument validation but still ensures buffers are initialized.
        """
        if not self._buffers_initialized:
            self._initialize_buffers()

        buffer_index = self.buffer_index
        if update_state:
            self.buffer_index += 1
            self._input_buffer_array.put(buffer_index, inputs)

        # use pre-allocated buffer for delayed inputs
        self._input_buffer_array.get(buffer_index, inputs, self._temp_input_buffer)

        # step the wrapped time stepper using fast path if available
        unchecked = getattr(
            self.time_stepper, "_step_single_unchecked", self.time_stepper.step_single
        )
        unchecked(self._temp_input_buffer, outputs, time_index, update_state, shutdown)

        if update_state:
            self._output_buffer_array.put(buffer_index, outputs)

        # get delayed outputs directly into the outputs array
        self._output_buffer_array.get(buffer_index, outputs, self._temp_output_buffer)
        numpy.copyto(outputs, self._temp_output_buffer)


class AnalyticWaveguideTimeStepper(TimeStepper):
    r"""Analytic waveguide time-stepper with power-dependent effects.

    This model simulates a two-port optical waveguide where the effective
    refractive index is dynamically perturbed by power-dependent effects,
    specifically free-carrier dispersion and thermal changes. The total
    effective index at any time is the sum of the baseline index and the
    dynamic perturbations:

    .. math::

       &n(t) = n_\text{eff} + n_\text{fc}(t) + n_\text{th}(t)

       &\tau_\text{fc} \frac{{\rm d}n_\text{fc}}{{\rm d}t}
         + n_\text{fc}(t) = \Delta n_\text{fc}(P(t))

       &\tau_\text{th} \frac{{\rm d}n_\text{th}}{{\rm d}t}
         + n_\text{th}(t) = \Delta n_\text{th}(P(t))

    in which :math:`\Delta n_\text{fc}` and :math:`\Delta n_\text{th}` are
    the steady-state index changes corresponding to the instantaneous
    optical power :math:`P(t)` due to free-carrier and thermal effects,
    respectively.

    Args:
        n_eff: Effective refractive index (loss can be included here by
          using complex values).
        length: Length of the waveguide. If not provided, the length is
          measured by :func:`route_length` or ports distance.
        propagation_loss: Propagation loss.
        extra_loss: Legth-independent additional loss.
        n_group: Group index of the optical mode, used to calculate delay.
        tau_fc: Time constant for the free-carrier effects. If zero,
          free-carrier effects are disabled.
        dn_fc: Power-dependent, steady-state index variation due to
          free-carrier effects.
        tau_th: Time constant for the thermal effects. If zero, thermal
          effects are disabled.
        dn_th: Power-dependent, steady-state index variation due to thermal
          effects.

    Notes:
        The group delay :math:`n_g \ell / c_0` is implemented as a fixed
        multiple of the time step.

        This model uses a lumped element approximation by assuming a uniform
        effect along the waveguide length.
    """

    def __init__(
        self,
        *,
        n_eff: complex,
        length: Coordinate | None = None,
        propagation_loss: PropagationLoss = 0.0,
        extra_loss: Loss = 0.0,
        n_group: float = 0,
        tau_fc: TimeDelay = 0,
        dn_fc: Interpolator = _zero,
        tau_th: TimeDelay = 0,
        dn_th: Interpolator = _zero,
    ) -> None:
        super().__init__(
            n_eff=n_eff,
            length=length,
            propagation_loss=propagation_loss,
            extra_loss=extra_loss,
            n_group=n_group,
            tau_fc=tau_fc,
            dn_fc=dn_fc,
            tau_th=tau_th,
            dn_th=dn_th,
        )

    def setup_state(
        self,
        *,
        component: Component,
        time_step: TimeDelay,
        carrier_frequency: Frequency,
        **kwargs: object,
    ) -> None:
        """Initialize internal state.

        Args:
            component: Component representing the laser source.
            time_step: The interval between time steps (in seconds).
            carrier_frequency: The carrier frequency used to construct the time
              stepper. The carrier should be omitted from the input signals, as
              it is handled automatically by the time stepper.
            kwargs: Unused.
        """
        ports = sorted(component.select_ports("optical"))
        if len(ports) != 2:
            raise RuntimeError(
                "AnalyticWaveguideTimeStepper can only be used in components with 2 optical ports."
            )
        self.keys = (ports[0] + "@0", ports[1] + "@0")

        p = self.parametric_kwargs

        length = p["length"]
        if length is None:
            length = 0
            port0 = component.ports[ports[0]]
            port1 = component.ports[ports[1]]
            for _, _, layer in port0.spec.path_profiles_list():
                length = max(length, route_length(component, layer))
            if length <= 0:
                length = numpy.sqrt(numpy.sum((port0.center - port1.center) ** 2))

        self._alpha_fc = min(1.0, time_step / p["tau_fc"]) if p["tau_fc"] > 0 else 0.0
        self._alpha_th = min(1.0, time_step / p["tau_th"]) if p["tau_th"] > 0 else 0.0

        self._n_eff = p["n_eff"]
        self._dn_fc_interp = p["dn_fc"]
        self._dn_th_interp = p["dn_th"]

        self._phi0 = 2.0 * numpy.pi * carrier_frequency * length / C_0
        self._gain = 10.0 ** ((length * p["propagation_loss"] + p["extra_loss"]) / -20.0)

        self._delay = max(0, int(numpy.round(p["n_group"] * length / C_0 / time_step)))
        self._buffer = numpy.empty((self._delay, 2), dtype=complex)

        self.reset()

    def reset(self) -> None:
        """Reset internal state."""
        self._dn_fc = 0.0
        self._dn_th = 0.0
        self._buffer[:, :] = 0.0j
        self._index = 0

    def step_single(
        self,
        inputs: numpy.ndarray,
        outputs: numpy.ndarray,
        time_index: int,
        update_state: bool,
        shutdown: bool,
    ) -> None:
        """Take a single time step on the given inputs.

        Args:
            inputs: Input values at the current time step. Must be a 1D array of
              complex values ordered according to :attr:`keys`.
            outputs: Pre-allocated output array where results will be stored.
              Same size and type as ``inputs``.
            time_index: Time series index for the current input.
            update_state: Whether to update the internal stepper state.
            shutdown: Whether this is the last call to the single stepping
              function for the provided :class:`TimeSeries`.
        """
        if self._delay > 0:
            a0, a1 = self._buffer[self._index]
        else:
            a0 = inputs[0]
            a1 = inputs[1]

        factor = self._gain * numpy.exp(1j * self._phi0 * (self._n_eff + self._dn_fc + self._dn_th))
        outputs[0] = factor * a1
        outputs[1] = factor * a0

        if update_state:
            powers = numpy.abs(inputs) ** 2
            dn_fc0, dn_fc1 = self._dn_fc_interp(powers)
            dn_th0, dn_th1 = self._dn_th_interp(powers)
            self._dn_fc = (1.0 - self._alpha_fc) * self._dn_fc + self._alpha_fc * (dn_fc0 + dn_fc1)
            self._dn_th = (1.0 - self._alpha_th) * self._dn_th + self._alpha_th * (dn_th0 + dn_th1)

            if self._delay > 0:
                self._buffer[self._index] = inputs
                self._index = (self._index + 1) % self._delay


class RingTimeStepper(TimeStepper):
    r"""Analytic ring resonator time-stepper with single or double bus.

    This model implements a 2 or 4-port micro-ring or racetrack resonator.
    It simulates the time-domain behavior based on a co-located coupling
    section and a delay-line for the ring's round-trip propagation. The
    model includes both electro-optic and thermo-optic tuning of the ring's
    effective index and loss. An optional first-order low-pass filter can be
    applied to the electrical tuning input.

    Args:
        kappa1: Coupling coefficient for the first bus waveguide.
        kappa2: Coupling coefficient for the second bus waveguide.
        n_eff: Effective refractive index (loss can be included here by
          using complex values).
        length: Round-trip length of the ring.
        propagation_loss: Propagation loss.
        n_group: Group index of the optical mode, used to calculate delay.
          If ``None``, the real part of 'n_eff' is used.
        dn_dT: Temperature sensitivity for ``n_eff``.
        dL_dT: Temperature sensitivity for ``propagation_loss``.
        temperature: Operating temperature.
        reference_temperature: Reference temperature.
        dn_dv: Linear voltage-dependent effective index coefficient.
        dn_dv2: Quadratic voltage-dependent effective index coefficient.
        dloss_dv: Linear voltage-dependent propagation loss coefficient.
        dloss_dv2: Quadratic voltage-dependent propagation loss coefficient.
        z0: Characteristic impedance of the electrical port used to convert
          the input field amplitude to voltage. If ``None``, derived from
          port impedance, calculated by mode-solving, or set to 50 Ω.
        f_3dB: -3 dB frequency cutoff for bandwidth limiting. Only active
          for positive values.
        ports: List of port names. If not set, the *sorted* list of port
          names from the component is used.
        mesh_refinement: Minimal number of mesh elements per wavelength used
          for mode solving.
        verbose: Flag setting the verbosity of mode solver runs.

    Notes:
        The group delay :math:`n_g \ell / c_0` is implemented as a fixed
        multiple of the time step.

        The port order is the same as for the :class:`RingModel`, i.e.,
        input, through, drop, and isolated ports.
    """

    def __init__(
        self,
        *,
        kappa1: float,
        kappa2: float | None = None,
        n_eff: complex,
        length: Coordinate,
        propagation_loss: PropagationLoss = 0.0,
        n_group: float | None = None,
        dn_dT: annotate(complex, label="dn/dT", units="1/K") = 0.0,
        dL_dT: annotate(float, label="dL/dT", units="dB/μm/K") = 0.0,
        temperature: Temperature = 293.0,
        reference_temperature: Temperature = 293.0,
        dn_dv: annotate(complex, label="dn/dV", units="1/V") = 0.0,
        dn_dv2: annotate(complex, label="d²n/dV²", units="1/V²") = 0.0,
        dloss_dv: annotate(float, label="dL/dV", units="dB/μm/V") = 0.0,
        dloss_dv2: annotate(float, label="d²L/dV²", units="dB/μm/V²") = 0.0,
        z0: Impedance | Interpolator | None = None,
        f_3dB: annotate(Frequency, label="f 3dB") = 0,
        ports: annotate(Sequence[str], minItems=2, maxItems=2)
        | annotate(Sequence[str], minItems=4, maxItems=4)
        | None = None,
        mesh_refinement: PositiveFloat | None = None,
        verbose: bool = True,
    ) -> None:
        super().__init__(
            kappa1=kappa1,
            kappa2=kappa2,
            n_eff=n_eff,
            length=length,
            propagation_loss=propagation_loss,
            n_group=n_group,
            dn_dT=dn_dT,
            dL_dT=dL_dT,
            temperature=temperature,
            reference_temperature=reference_temperature,
            dn_dv=dn_dv,
            dn_dv2=dn_dv2,
            dloss_dv=dloss_dv,
            dloss_dv2=dloss_dv2,
            z0=z0,
            f_3dB=f_3dB,
            ports=ports,
            mesh_refinement=mesh_refinement,
            verbose=verbose,
        )

    def setup_state(
        self,
        *,
        component: Component,
        time_step: TimeDelay,
        carrier_frequency: Frequency,
        temperature: Temperature | None = None,
        verbose: bool | None = None,
        **kwargs: object,
    ) -> object:
        """Initialize internal state.

        Args:
            component: Component representing the laser source.
            time_step: The interval between time steps (in seconds).
            carrier_frequency: The carrier frequency used to construct the time
              stepper. The carrier should be omitted from the input signals, as
              it is handled automatically by the time stepper.
            temperature: If set, overrides the time stepper's temperature.
            verbose: If set, overrides the time stepper's `verbose` attribute.
            kwargs: Unused.
        """
        p = self.parametric_kwargs

        self._double_bus = p["kappa2"] is not None

        ports = p["ports"]
        component_ports = sorted(component.select_ports("optical"))
        if ports is None:
            ports = sorted(component_ports)
        elif not all(name in component_ports for name in ports):
            raise RuntimeError(
                f"Not all port names defined in RingTimeStepper match the optical "
                f"port names in component {component.name!r}."
            )

        e_ports = component.select_ports("electrical")
        if (
            (self._double_bus and len(ports) != 4)
            or (not self._double_bus and len(ports) != 2)
            or len(e_ports) > 1
        ):
            if self._double_bus:
                raise RuntimeError(
                    "RingTimeStepper with double bus can only be used in components with 4 optical "
                    "ports and 1 optional electrical port."
                )
            else:
                raise RuntimeError(
                    "RingTimeStepper with single bus can only be used in components with 2 optical "
                    "ports and 1 optional electrical port."
                )

        self.keys = tuple(p + "@0" for p in ports)

        length = p["length"]
        n_eff = p["n_eff"]
        n_group = p["n_group"]
        if n_group is None:
            n_group = numpy.real(n_eff)

        self._delay = max(0, int(numpy.round(n_group * length / C_0 / time_step)))
        self._buffer = numpy.empty((self._delay, 2), dtype=complex)

        if self._delay == 0:
            warn("RingTimeStepper round-trip is smaller than time step.", RuntimeWarning, 3)

        dl = (length / self._delay) if self._delay > 0 else length

        if temperature is None:
            temperature = p["temperature"]
        dT = temperature - p["reference_temperature"]

        q = 2 * numpy.pi * carrier_frequency * dl / C_0
        self._phi0 = q * (n_eff + p["dn_dT"] * dT)
        self._phi1 = q * p["dn_dv"]
        self._phi2 = q * p["dn_dv2"]

        self._g0 = (p["propagation_loss"] + p["dL_dT"] * dT) * dl / -20.0
        self._g1 = p["dloss_dv"] * dl / -20.0
        self._g2 = p["dloss_dv2"] * dl / -20.0

        self._k1 = p["kappa1"]
        self._k2 = p["kappa2"] if self._double_bus else 0.0
        sum_k = self._k1**2 + self._k2**2
        if sum_k > 1.0:
            raise ValueError(
                "Unitarity violation. RingTimeStepper requires 'kappa1**2 + kappa2**2 <= 1'."
            )
        self._t = (1.0 - sum_k) ** 0.5
        self._k1 *= 1j
        self._k2 *= 1j

        self._filter = numpy.exp(-2.0 * numpy.pi * p["f_3dB"] * time_step)
        if self._filter >= 1.0:
            self._filter = 0.0

        if len(e_ports) > 0:
            e_port = next(iter(e_ports))
            self.keys += (e_port + "@0",)
            self._factor = None
            if _get_impedance_runner(self, component, e_port, time_step, verbose) is not None:
                return self
        else:
            self._factor = min(1.0, 10.0**self._g0) * numpy.exp(1j * self._phi0)

        self.reset()

    @property
    def status(self) -> object:
        if not self._setup_thread.is_alive() and self._status["message"] == "running":
            self._status["message"] = "error"
        with self._lock:
            return self._status

    def reset(self) -> None:
        """Reset internal state."""
        if self._factor is None:
            self._sqrt_r_in = numpy.real(self._z0) ** 0.5
        self._v = 0.0
        self._buffer[:, :] = 0.0j
        self._index = 0

    def step_single(
        self,
        inputs: numpy.ndarray,
        outputs: numpy.ndarray,
        time_index: int,
        update_state: bool,
        shutdown: bool,
    ) -> None:
        """Take a single time step on the given inputs.

        Args:
            inputs: Input values at the current time step. Must be a 1D array of
              complex values ordered according to :attr:`keys`.
            outputs: Pre-allocated output array where results will be stored.
              Same size and type as ``inputs``.
            time_index: Time series index for the current input.
            update_state: Whether to update the internal stepper state.
            shutdown: Whether this is the last call to the single stepping
              function for the provided :class:`TimeSeries`.
        """
        if self._factor is None:
            v_in = self._sqrt_r_in * inputs[-1].real
            v = v_in * (1.0 - self._filter) + self._v * self._filter
            if update_state:
                self._v = v

            phi = self._phi0 + v * (self._phi1 + v * self._phi2)
            attenuation = min(1.0, 10.0 ** (self._g0 + v * (self._g1 + v * self._g2)))
            factor = attenuation * numpy.exp(1j * phi)
        else:
            factor = self._factor

        #  a₂→ ----------- ←a₃
        #      r₂→ ___ ←r₃
        #         /   \
        #         \___/
        #      r₀→     ←r₁
        #  a₀→ ----------- ←a₁

        a0, a1 = inputs[0:2]
        a2, a3 = inputs[2:4] if self._double_bus else (0, 0)

        r03, r12 = self._buffer[self._index] if self._delay > 0 else (0, 0)

        outputs[0] = self._t * a1 + self._k1 * r12
        outputs[1] = self._t * a0 + self._k1 * r03
        if self._double_bus:
            outputs[2] = self._t * a3 + self._k2 * r03
            outputs[3] = self._t * a2 + self._k2 * r12

        if update_state and self._delay > 0:
            r03 = self._t * r03 + self._k1 * a0 + self._k2 * a3
            r12 = self._t * r12 + self._k1 * a1 + self._k2 * a2
            self._buffer[self._index] = r03, r12
            self._buffer *= factor
            self._index = (self._index + 1) % self._delay


register_time_stepper_class(DelayedTimeStepper)
register_time_stepper_class(AnalyticWaveguideTimeStepper)
register_time_stepper_class(RingTimeStepper)
