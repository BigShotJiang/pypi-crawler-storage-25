from collections.abc import Sequence
from typing import Literal

import numpy

from ..extension import (
    Component,
    Expression,
    TimeStepper,
    register_time_stepper_class,
)
from ..typing import FieldAmplitude, annotate


class ExpressionTimeStepper(TimeStepper):
    r"""Expression time stepper for electrical signals.

    Args:
        expressions: Dictionary of expression strings for all output ports,
          indexed by name.

    Example:
        Example time stepper to be used on a component with 3 electrical
        ports: "E0", "E1", "E2". The first has a 0.1 reflection coefficient,
        the second has no output (zero, by default), and the third has a
        non-linear combination of all 3 inputs.

        >>> time_stepper = pf.ExpressionTimeStepper(
        ...     expressions={
        ...         "E0": "0.1 * E0",
        ...         "E2": "0.5 * E0 * E2 + abs(E1) * E1",
        ...     }
        ... )

    Note:
        Expressions can use all operators supported by :class:`Expression`.
    """

    def __init__(self, *, expressions: dict[str, str]) -> None:
        super().__init__(expressions=expressions)

    def setup_state(self, *, component: Component, **kwargs: object) -> None:
        """Initialize internal state.

        Args:
            component: Component representing the time stepper.
            kwargs: Unused.
        """
        expressions = self.parametric_kwargs["expressions"]
        component_ports = sorted(component.select_ports("electrical"))
        if any(port not in component_ports for port in expressions):
            raise RuntimeError(
                f"Not all ports required by ExpressionTimeStepper were found in component "
                f"{component.name!r}."
            )
        self.keys = tuple(port + "@0" for port in component_ports)
        self.expression = Expression(
            component_ports, [expressions.get(port, "0.0") for port in component_ports]
        )

    def step_single(
        self,
        inputs: numpy.ndarray,
        outputs: numpy.ndarray,
        time_index: int,
        update_state: bool,
        shutdown: bool,
    ) -> None:
        """Take a single time step on the given inputs.

        Args:
            inputs: Input values at the current time step. Must be a 1D array of
              complex values ordered
              according to :attr:`keys`.
            outputs: Pre-allocated output array where results will be stored.
              Same size and type as ``inputs``.
            time_index: Time series index for the current input.
            update_state: Whether to update the internal stepper state.
            shutdown: Whether this is the last call to the single stepping
              function for the provided :class:`TimeSeries`.
        """
        numpy.copyto(outputs, self.expression(*inputs.real))


class DifferentialTimeStepper(TimeStepper):
    r"""Time stepper for differentiating electrical signals in time.

    The "backwards" scheme, implements:

    .. math:: y_k = s \frac{x_k - x_{k-1}}{\Delta t}

    whereas the "central" scheme uses:

    .. math:: y_k = s \frac{x_k - x_{k-2}}{2 \Delta t}

    Args:
        scheme: Differentiation scheme.
        scale: Output scaling factor :math:`s`.
        output_port: Name of the port used as output. If ``None``, the last
          port is used (in the sorted list of ports).
    """

    def __init__(
        self,
        *,
        scheme: Literal["backwards", "central"] = "backwards",
        scale: annotate(float, units="s") = 1.0,
        output_port: str | None = None,
    ) -> None:
        super().__init__(scheme=scheme, scale=scale, output_port=output_port)

    def setup_state(self, *, time_step: float, component: Component, **kwargs: object) -> None:
        """Initialize internal state.

        Args:
            time_step: The interval between time steps (in seconds).
            component: Component representing the time stepper.
            kwargs: Unused.
        """
        p = self.parametric_kwargs
        component_ports = sorted(component.select_ports("electrical"))
        if len(component_ports) != 2:
            raise RuntimeError(
                f"DifferentialTimeStepper can only be used on components with 2 electrical "
                f"ports. Component {component.name!r} has {len(component_ports)}."
            )

        output_port = p["output_port"]
        if output_port == component_ports[0]:
            component_ports = (component_ports[1], component_ports[0])
        elif output_port is not None and output_port != component_ports[1]:
            raise RuntimeError(
                f"Port {output_port!r} required by DifferentialTimeStepper was not found in "
                f"component {component.name!r}."
            )
        self.keys = tuple(p + "@0" for p in component_ports)

        scheme = p["scheme"]
        if scheme not in ("backwards", "central"):
            raise ValueError("DifferentialTimeStepper 'scheme' must be 'backwards' or 'central'.")
        self._buffer = numpy.empty(1 if scheme == "backwards" else 2)
        self._scale = p["scale"] / (self._buffer.size * time_step)

        self.reset()

    def reset(self) -> None:
        self._buffer[:] = 0.0

    def step_single(
        self,
        inputs: numpy.ndarray,
        outputs: numpy.ndarray,
        time_index: int,
        update_state: bool,
        shutdown: bool,
    ) -> None:
        """Take a single time step on the given inputs.

        Args:
            inputs: Input values at the current time step. Must be a 1D array of
              complex values ordered
              according to :attr:`keys`.
            outputs: Pre-allocated output array where results will be stored.
              Same size and type as ``inputs``.
            time_index: Time series index for the current input.
            update_state: Whether to update the internal stepper state.
            shutdown: Whether this is the last call to the single stepping
              function for the provided :class:`TimeSeries`.
        """
        x = inputs[0].real
        outputs[1] = self._scale * (x - self._buffer[0])

        if update_state:
            if self._buffer.size == 1:
                self._buffer[0] = x
            else:
                self._buffer[0] = self._buffer[1]
                self._buffer[1] = x


class IntegralTimeStepper(TimeStepper):
    r"""Time stepper for integrating electrical signals in time.

    .. math:: y_k = y_{k - 1} + s x_k \Delta t

    Args:
        scale: Input scaling factor :math:`s`.
        start_value: Starting output value after reset.
        limits: Output value limits.
        output_port: Name of the port used as output. If ``None``, the last
          port is used (in the sorted list of ports).
        reset_port: Name of the port used as reset signal. If ``None``, the
          reset feature is disabled.
        reset_trigger: Type of edge used for triggering a reset.
        reset_tolerance: Value change tolerance for triggering a reset.
    """

    def __init__(
        self,
        *,
        scale: annotate(float, units="s⁻¹") = 1.0,
        start_value: FieldAmplitude = 0.0,
        limits: annotate(Sequence[FieldAmplitude | None], minItems=2, maxItems=2) = (
            None,
            None,
        ),
        output_port: str | None = None,
        reset_port: str | None = None,
        reset_trigger: Literal["fall", "rise", "both"] = "rise",
        reset_tolerance: float = 0.0,
    ) -> None:
        super().__init__(
            scale=scale,
            start_value=start_value,
            limits=limits,
            output_port=output_port,
            reset_port=reset_port,
            reset_trigger=reset_trigger,
            reset_tolerance=reset_tolerance,
        )

    def setup_state(self, *, time_step: float, component: Component, **kwargs: object) -> None:
        """Initialize internal state.

        Args:
            time_step: The interval between time steps (in seconds).
            component: Component representing the time stepper.
            kwargs: Unused.
        """
        p = self.parametric_kwargs
        reset_port = p["reset_port"]
        output_port = p["output_port"]

        required_ports = 2 if reset_port is None else 3
        component_ports = sorted(component.select_ports("electrical"))
        if len(component_ports) != required_ports:
            raise RuntimeError(
                f"IntegralTimeStepper can only be used on components with {required_ports} "
                f"electrical ports. Component {component.name!r} has {len(component_ports)}."
            )
        for required in (output_port, reset_port):
            if required is not None and required not in component_ports:
                raise RuntimeError(
                    f"Port {required!r} required by IntegralTimeStepper was not found in "
                    f"component {component.name!r}."
                )

        if reset_port is not None:
            component_ports.remove(reset_port)
            if reset_port == output_port:
                raise ValueError("'output_port' and 'reset_port' cannot be the same.")

        if output_port is None:
            input_port, output_port = component_ports
        else:
            component_ports.remove(output_port)
            input_port = component_ports[0]

        if reset_port is None:
            self.keys = (input_port + "@0", output_port + "@0")
        else:
            self.keys = (input_port + "@0", output_port + "@0", reset_port + "@0")

        self._reset_trigger = p["reset_trigger"]
        if self._reset_trigger not in ("fall", "rise", "both"):
            raise ValueError(
                "IntegralTimeStepper 'reset_trigger' must be 'fall', 'rise', or 'both'."
            )

        self._scale = p["scale"] * time_step
        self._y0 = p["start_value"]
        self._reset_tolerance = abs(p["reset_tolerance"])

        self._y_lo, self._y_hi = p["limits"]
        if self._y_lo is None:
            self._y_lo = -numpy.inf
        if self._y_hi is None:
            self._y_hi = numpy.inf

        self.reset()

    def reset(self) -> None:
        self._y = self._y0
        self._r = 0.0

    def step_single(
        self,
        inputs: numpy.ndarray,
        outputs: numpy.ndarray,
        time_index: int,
        update_state: bool,
        shutdown: bool,
    ) -> None:
        """Take a single time step on the given inputs.

        Args:
            inputs: Input values at the current time step. Must be a 1D array of
              complex values ordered
              according to :attr:`keys`.
            outputs: Pre-allocated output array where results will be stored.
              Same size and type as ``inputs``.
            time_index: Time series index for the current input.
            update_state: Whether to update the internal stepper state.
            shutdown: Whether this is the last call to the single stepping
              function for the provided :class:`TimeSeries`.
        """
        if len(self.keys) == 3:
            r = inputs[2].real
        else:
            r = 0.0

        edge = r - self._r
        if len(self.keys) == 3 and (
            (edge > self._reset_tolerance and self._reset_trigger != "fall")
            or (-edge > self._reset_tolerance and self._reset_trigger != "rise")
        ):
            y = self._y0
        else:
            y = self._y + self._scale * inputs[0].real

        y = min(self._y_hi, max(self._y_lo, y))
        outputs[1] = y

        if update_state:
            self._y = y
            self._r = r


register_time_stepper_class(ExpressionTimeStepper)
register_time_stepper_class(DifferentialTimeStepper)
register_time_stepper_class(IntegralTimeStepper)
