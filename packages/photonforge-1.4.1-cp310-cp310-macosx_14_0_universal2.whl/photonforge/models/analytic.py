import io
import struct
from collections.abc import Sequence
from typing import Literal

import numpy

from ..extension import (
    Circle,
    Component,
    Interpolator,
    Model,
    Path,
    Polygon,
    Port,
    PortSpec,
    Rectangle,
    Reference,
    SMatrix,
    Technology,
    boolean,
    config,
    frequency_classification,
    register_model_class,
    text,
)
from ..typing import (
    Coordinate,
    Dispersion,
    DispersionSlope,
    Frequency,
    Loss,
    PropagationLoss,
    Temperature,
    Voltage,
    annotate,
    array,
)
from ..utils import C_0, route_length

ComplexCoeff = array(complex, 0, 2)
ComplexCoeff1D = array(complex, 0, 1)
FloatCoeff = array(float, 0, 2)

_bb_layer = (0, 32767)


def _add_bb_text(component: Component, width: float) -> None:
    temp = Component(technology=component.technology)
    temp.add(_bb_layer, *text("BB", width, typeface=1))
    ref = Reference(temp)

    ref_size = ref.size()
    size = component.size()
    if ref_size[0] > 0.8 * size[0] or ref_size[1] > 0.8 * size[1]:
        ref.scale(0.8 * min(size[0] / ref_size[0], size[1] / ref_size[1]))
    elif ref_size[0] < 0.2 * size[0] and ref_size[1] < 0.2 * size[1]:
        ref.scale(0.2 * min(size[0] / ref_size[0], size[1] / ref_size[1]))

    ref.translate(0.5 * (sum(component.bounds()) - sum(ref.bounds())))
    component.add(_bb_layer, *ref.get_structures(_bb_layer))


def _ensure_correct_shape(x: object, ndims: int = 2) -> numpy.ndarray | Interpolator:
    if isinstance(x, Interpolator):
        if ndims == 1 and isinstance(x.y, list):
            x = Interpolator(x.x, x.y[0], x.method, x.coords, x.extrapolation, x.parameter_names)
        elif ndims == 2 and not isinstance(x.y, list):
            x = Interpolator(x.x, [x.y], x.method, x.coords, x.extrapolation, x.parameter_names)
        return x
    y = numpy.array(x)
    if y.ndim < ndims:
        shape = (-1,) + (1,) * (ndims - 1)
        y = y.reshape(shape)
    return y


def _sample(
    component_name: str,
    name: str,
    value: numpy.ndarray | Interpolator,
    frequencies: Sequence[float],
    num_modes: int,
) -> numpy.ndarray:
    value = _ensure_correct_shape(value)
    if isinstance(value, Interpolator):
        value = value(frequencies)
        if value.shape[0] == 1 and num_modes > 1:
            value = numpy.array(numpy.broadcast_to(value, (num_modes, len(frequencies))))
    else:
        shape = (max(num_modes, value.shape[0]), len(frequencies))
        value = numpy.array(numpy.broadcast_to(value, shape))

    if value.shape[0] < num_modes:
        raise RuntimeError(
            f"The first dimension of {name!r} in the model for {component_name!r} must be "
            f"{num_modes} to account for all modes in the component's ports."
        )

    return value[:num_modes]


class TerminationModel(Model):
    r"""Data model for a 1-port device.

    Args:
        r: Reflection coefficient for the first port. For multimode ports, a
          sequence of coefficients must be provided.

    Notes:
        For multimode ports, mixed-mode coefficients are 0. Dispersion can
        be included in the model by setting the coefficient to an
        :class:`Interpolator` (with multiple values for multimode ports), or
        a 2D array with shape (M, N), in which M is the number of modes, and
        N the length of the frequency sequence used in the S matrix
        computation.
    """

    def __init__(self, r: ComplexCoeff | Interpolator = 0) -> None:
        super().__init__(r=r)

    def black_box_component(
        self,
        port_spec: str | PortSpec | None = None,
        technology: Technology | None = None,
        name: str | None = None,
    ) -> Component:
        """Create a black-box component using this model for testing.

        Args:
            port_spec: Port specification used in the component. If ``None``,
              look for ``"port_spec"`` in :attr:`config.default_kwargs`.
            technology: Component technology. If ``None``, the default
              technology is used.
            name: Component name. If ``None`` a default is used.

        Returns:
            Component with ports and model.
        """
        model_name = self.__class__.__name__[:-5]
        component = Component(f"BB{model_name}" if name is None else name, technology=technology)
        component.properties.__thumbnail__ = "termination"

        if port_spec is None:
            port_spec = config.default_kwargs.get("port_spec")
            if port_spec is None:
                raise RuntimeError("Missing argument 'port_spec'.")
        if isinstance(port_spec, str):
            name = port_spec
            port_spec = component.technology.ports.get(port_spec)
            if port_spec is None:
                raise RuntimeError(f"Port spec '{name}' not found in component's technology.")

        width = port_spec.width
        length = width * 8

        profiles = port_spec.path_profiles_list()
        if len(profiles) == 0:
            profiles = [(width, 0, _bb_layer)]

        for w, g, layer in profiles:
            component.add(layer, Path((0, 0), w, g).segment((length, 0), 0))

        _add_bb_text(component, width)

        component.add_port(Port((0, 0), 0, port_spec))
        component.add_model(self, model_name)
        return component

    def start(
        self, component: Component, frequencies: Sequence[float], **kwargs: object
    ) -> SMatrix:
        """Start computing the S matrix response from a component.

        Args:
            component: Component from which to compute the S matrix.
            frequencies: Sequence of frequencies at which to perform the
              computation.
            **kwargs: Unused.

        Returns:
           Model result with attributes ``status`` and ``s_matrix``.
        """
        classification = frequency_classification(frequencies)
        component_ports = {
            name: port.copy(True) for name, port in component.select_ports(classification).items()
        }
        if len(component_ports) != 1:
            raise RuntimeError(
                f"TerminationModel can only be used on components with 1 port. "
                f"{component.name!r} has {len(component_ports)} {classification} ports."
            )

        name, port = next(iter(component_ports.items()))

        r = _sample(component.name, "r", self.parametric_kwargs["r"], frequencies, port.num_modes)

        elements = {(f"{name}@{mode}", f"{name}@{mode}"): r[mode] for mode in range(port.num_modes)}
        return SMatrix(frequencies, elements, {name: port})

    # Deprecated: kept for backwards compatibility with old phf files
    @classmethod
    def from_bytes(cls, byte_repr: bytes) -> "TerminationModel":
        """De-serialize this model."""
        size = struct.calcsize("<BQ")
        version, length = struct.unpack("<BQ", byte_repr[:size])
        if version != 0:
            raise RuntimeError("Unsuported TerminationModel version.")
        if len(byte_repr) != size + length:
            raise ValueError("Unexpected byte representation for TerminationModel")
        mem_io = io.BytesIO()
        mem_io.write(byte_repr[size:])
        mem_io.seek(0)
        coeff = numpy.load(mem_io)
        return cls(coeff)


class TwoPortModel(Model):
    r"""Data model for a 2-port component.

    .. math:: S = \begin{bmatrix}
                     r_0 e^{j \phi}  &   t e^{j \phi}  \\
                      t e^{j \phi}   &  r_1 e^{j \phi} \\
                  \end{bmatrix}

    with dispersion modeled by:

    .. math:: \phi = \frac{2 \pi l_p}{c_0}
         [n_\text{eff} f_0 + n_\text{group} (f - f_0)]

    Args:
        t: Transmission coefficient.
        r0: Reflection coefficient for the first port.
        r1: Reflection coefficient for the second port.
        ports: List of port names. If not set, the *sorted* list of port
          names from the component is used.
        propagation_length: Propagation length :math:`l_p` for dispersion
          modeling.
        n_eff: Effective refractive index for dispersion modeling.
        n_group: Group index. If ``None``, the value of ``n_eff`` is used.
        reference_frequency: Reference frequency :math:`f_0` for dispersion
          calculation. If ``None``, the central frequency is used.

    Notes:
        For multimode ports, a sequence of coefficients must be used, and
        mixed-mode coefficients are 0. Dispersion can be included in the
        model by setting the coefficients to an :class:`Interpolator` (with
        multiple values for multimode ports), or a 2D array with shape
        (M, N), in which M is the number of modes, and N the length of the
        frequency sequence used in the S matrix computation.
    """

    def __init__(
        self,
        t: ComplexCoeff | Interpolator = 1,
        r0: ComplexCoeff | Interpolator = 0,
        r1: ComplexCoeff | Interpolator = 0,
        ports: annotate(Sequence[str], minItems=2, maxItems=2) | None = None,
        *,
        propagation_length: annotate(float, units="μm") = 0.0,
        n_eff: ComplexCoeff | Interpolator = 0.0,
        n_group: FloatCoeff | Interpolator | None = None,
        reference_frequency: Frequency | None = None,
    ) -> None:
        super().__init__(
            t=t,
            r0=r0,
            r1=r1,
            ports=ports,
            propagation_length=propagation_length,
            n_eff=n_eff,
            n_group=n_group,
            reference_frequency=reference_frequency,
        )
        if ports is not None and len(ports) != 2:
            raise TypeError(
                f"TwoPortModel can only be used on components with 2 ports. "
                f"Argument 'ports' has length {len(ports)}."
            )

    def black_box_component(
        self,
        port_spec: str | PortSpec | None = None,
        technology: Technology | None = None,
        name: str | None = None,
    ) -> Component:
        """Create a black-box component using this model for testing.

        Args:
            port_spec: Port specification used in the component. If ``None``,
              look for ``"port_spec"`` in :attr:`config.default_kwargs`.
            technology: Component technology. If ``None``, the default
              technology is used.
            name: Component name. If ``None`` a default is used.

        Returns:
            Component with ports and model.
        """
        model_name = self.__class__.__name__[:-5]
        component = Component(f"BB{model_name}" if name is None else name, technology=technology)
        component.properties.__thumbnail__ = "wg"

        if port_spec is None:
            port_spec = config.default_kwargs.get("port_spec")
            if port_spec is None:
                raise RuntimeError("Missing argument 'port_spec'.")
        if isinstance(port_spec, str):
            name = port_spec
            port_spec = component.technology.ports.get(port_spec)
            if port_spec is None:
                raise RuntimeError(f"Port spec '{name}' not found in component's technology.")

        width = port_spec.width
        length = abs(self.parametric_kwargs["propagation_length"])
        if length == 0.0:
            length = width * 8

        profiles = port_spec.path_profiles_list()
        if len(profiles) == 0:
            profiles = [(width, 0, _bb_layer)]

        for w, g, layer in profiles:
            component.add(layer, Path((0, 0), w, g).segment((length, 0)))

        _add_bb_text(component, width)

        port_names = self.parametric_kwargs["ports"] or [None] * 2
        component.add_port(Port((0, 0), 0, port_spec), port_names[0])
        component.add_port(Port((length, 0), 180, port_spec.inverted()), port_names[1])

        component.add_model(self, model_name)
        return component

    def start(
        self, component: Component, frequencies: Sequence[float], **kwargs: object
    ) -> SMatrix:
        """Start computing the S matrix response from a component.

        Args:
            component: Component from which to compute the S matrix.
            frequencies: Sequence of frequencies at which to perform the
              computation.
            **kwargs: Unused.

        Returns:
           Model result with attributes ``status`` and ``s_matrix``.
        """
        classification = frequency_classification(frequencies)
        component_ports = {
            name: port.copy(True) for name, port in component.select_ports(classification).items()
        }
        if len(component_ports) != 2:
            raise RuntimeError(
                f"TwoPortModel can only be used on components with 2 ports. "
                f"{component.name!r} has {len(component_ports)} {classification} ports."
            )

        p = self.parametric_kwargs

        names = p["ports"]
        if names is None:
            names = sorted(component_ports)
        elif not all(name in component_ports for name in names):
            raise RuntimeError(
                f"Not all port names defined in TwoPortModel match the {classification} port "
                f"names in component {component.name!r}."
            )

        num_modes = component_ports[names[0]].num_modes
        if not all(port.num_modes == num_modes for port in component_ports.values()):
            raise RuntimeError(
                f"TwoPortModel requires that all component ports have the same number of "
                f"modes. Ports from {component.name!r} support different numbers of modes."
            )

        lp = _ensure_correct_shape(p["propagation_length"])

        f0 = p["reference_frequency"]
        if f0 is None:
            f0 = 0.5 * (frequencies.min() + frequencies.max())

        n_eff = _sample(component.name, "n_eff", p["n_eff"], frequencies, num_modes)
        n_group = p["n_group"]
        n_group = (
            n_eff
            if n_group is None
            else _sample(component.name, "n_group", n_group, frequencies, num_modes)
        )

        phase = numpy.exp(
            2j * numpy.pi * lp * ((n_eff - n_group) * f0 + n_group * frequencies) / C_0
        )

        t = _sample(component.name, "t", p["t"], frequencies, num_modes) * phase
        r0 = _sample(component.name, "r0", p["r0"], frequencies, num_modes) * phase
        r1 = _sample(component.name, "r1", p["r1"], frequencies, num_modes) * phase

        s = (
            (r0, t),
            (t, r1),
        )
        elements = {
            (f"{port_in}@{mode}", f"{port_out}@{mode}"): s[j][i][mode]
            for i, port_in in enumerate(names)
            for j, port_out in enumerate(names)
            for mode in range(component_ports[port_in].num_modes)
        }
        return SMatrix(frequencies, elements, component_ports)

    # Deprecated: kept for backwards compatibility with old phf files
    @classmethod
    def from_bytes(cls, byte_repr: bytes) -> "TwoPortModel":
        """De-serialize this model."""
        size = struct.calcsize("<B5Q")
        version, *lengths = struct.unpack("<B5Q", byte_repr[:size])
        if version != 0:
            raise RuntimeError("Unsuported TwoPortModel version.")
        coeffs = []
        for length in lengths[:3]:
            mem_io = io.BytesIO()
            mem_io.write(byte_repr[size : size + length])
            mem_io.seek(0)
            coeffs.append(numpy.load(mem_io))
            size += length
        if all(length == 0 for length in lengths[3:]):
            ports = None
        else:
            ports = []
            for length in lengths[3:]:
                ports.append(byte_repr[size : size + length].decode("utf8"))
                size += length
        return cls(*coeffs, ports)


class IsolatorModel(Model):
    r"""Data model for a 2-port isolator.

    .. math:: S = \begin{bmatrix}
                    r_0  &   i   \\
                     t   &  r_1  \\
                  \end{bmatrix}

    Args:
        t: Transmission coefficient.
        i: Isolation coefficient.
        r0: Reflection coefficient for the first port.
        r1: Reflection coefficient for the second port.
        ports: List of port names. If not set, the *sorted* list of port
          names from the component is used.

    Notes:
        For multimode ports, a sequence of coefficients must be used, and
        mixed-mode coefficients are 0. Dispersion can be included in the
        model by setting the coefficients to an :class:`Interpolator` (with
        multiple values for multimode ports), or a 2D array with shape
        (M, N), in which M is the number of modes, and N the length of the
        frequency sequence used in the S matrix computation.
    """

    def __init__(
        self,
        t: ComplexCoeff | Interpolator = 1,
        i: ComplexCoeff | Interpolator = 0,
        r0: ComplexCoeff | Interpolator = 0,
        r1: ComplexCoeff | Interpolator = 0,
        ports: annotate(Sequence[str], minItems=2, maxItems=2) | None = None,
    ) -> None:
        super().__init__(t=t, i=i, r0=r0, r1=r1, ports=ports)
        if ports is not None and len(ports) != 2:
            raise TypeError(
                f"IsolatorModel can only be used on components with 2 ports. "
                f"Argument 'ports' has length {len(ports)}."
            )

    def black_box_component(
        self,
        port_spec: str | PortSpec | None = None,
        technology: Technology | None = None,
        name: str | None = None,
    ) -> Component:
        """Create a black-box component using this model for testing.

        Args:
            port_spec: Port specification used in the component. If ``None``,
              look for ``"port_spec"`` in :attr:`config.default_kwargs`.
            technology: Component technology. If ``None``, the default
              technology is used.
            name: Component name. If ``None`` a default is used.

        Returns:
            Component with ports and model.
        """
        model_name = self.__class__.__name__[:-5]
        component = Component(f"BB{model_name}" if name is None else name, technology=technology)
        component.properties.__thumbnail__ = "isolator"

        if port_spec is None:
            port_spec = config.default_kwargs.get("port_spec")
            if port_spec is None:
                raise RuntimeError("Missing argument 'port_spec'.")
        if isinstance(port_spec, str):
            name = port_spec
            port_spec = component.technology.ports.get(port_spec)
            if port_spec is None:
                raise RuntimeError(f"Port spec '{name}' not found in component's technology.")

        width = port_spec.width

        profiles = port_spec.path_profiles_list()
        if len(profiles) == 0:
            profiles = [(width, 0, _bb_layer)]

        for w, g, layer in profiles:
            component.add(
                layer,
                Path((0, 0), w, g).segment((width * 6, 0)),
                Polygon([(width * 2, -width * 2), (width * 4, -width), (width * 2, -width)]),
                Polygon([(width * 4, width), (width * 2, width), (width * 2, width * 2)]),
            )

        _add_bb_text(component, width)

        port_names = self.parametric_kwargs["ports"] or [None] * 2
        component.add_port(Port((0, 0), 0, port_spec), port_names[0])
        component.add_port(Port((width * 6, 0), 180, port_spec.inverted()), port_names[1])

        component.add_model(self, model_name)
        return component

    def start(
        self, component: Component, frequencies: Sequence[float], **kwargs: object
    ) -> SMatrix:
        """Start computing the S matrix response from a component.

        Args:
            component: Component from which to compute the S matrix.
            frequencies: Sequence of frequencies at which to perform the
              computation.
            **kwargs: Unused.

        Returns:
           Model result with attributes ``status`` and ``s_matrix``.
        """
        classification = frequency_classification(frequencies)
        component_ports = {
            name: port.copy(True) for name, port in component.select_ports(classification).items()
        }
        if len(component_ports) != 2:
            raise RuntimeError(
                f"IsolatorModel can only be used on components with 2 ports. "
                f"{component.name!r} has {len(component_ports)} {classification} ports."
            )

        p = self.parametric_kwargs

        names = p["ports"]
        if names is None:
            names = sorted(component_ports)
        elif not all(name in component_ports for name in names):
            raise RuntimeError(
                f"Not all port names defined in IsolatorModel match the {classification} "
                f"port names in component {component.name!r}."
            )

        num_modes = component_ports[names[0]].num_modes
        if component_ports[names[1]].num_modes != num_modes:
            raise RuntimeError(
                f"IsolatorModel requires that both component ports have the same number of "
                f"modes. Ports from {component.name!r} support different numbers of modes."
            )

        t = _sample(component.name, "t", p["t"], frequencies, num_modes)
        i = _sample(component.name, "i", p["i"], frequencies, num_modes)
        r0 = _sample(component.name, "r0", p["r0"], frequencies, num_modes)
        r1 = _sample(component.name, "r1", p["r1"], frequencies, num_modes)

        s = (
            (r0, i),
            (t, r1),
        )
        elements = {
            (f"{port_in}@{mode}", f"{port_out}@{mode}"): s[j][i][mode]
            for i, port_in in enumerate(names)
            for j, port_out in enumerate(names)
            for mode in range(component_ports[port_in].num_modes)
        }
        return SMatrix(frequencies, elements, component_ports)


class PowerSplitterModel(Model):
    r"""Data model for a 3-port power splitter.

    .. math:: S = \begin{bmatrix}
                     r_0  &   t   &   t   \\
                      t   &  r_1  &   i   \\
                      t   &   i   &  r_1  \\
                  \end{bmatrix}

    Args:
        t: Transmission coefficient.
        i: Leakage (isolation) coefficient.
        r0: Reflection coefficient for the first port.
        r1: Reflection coefficient for the remaining ports.
        ports: List of port names. If not set, the *sorted* list of port
          names from the component is used.

    Notes:
        For multimode ports, a sequence of coefficients must be used, and
        mixed-mode coefficients are 0. Dispersion can be included in the
        model by setting the coefficients to an :class:`Interpolator` (with
        multiple values for multimode ports), or a 2D array with shape
        (M, N), in which M is the number of modes, and N the length of the
        frequency sequence used in the S matrix computation.
    """

    def __init__(
        self,
        t: ComplexCoeff | Interpolator = 2**-0.5,
        i: ComplexCoeff | Interpolator = 0,
        r0: ComplexCoeff | Interpolator = 0,
        r1: ComplexCoeff | Interpolator = 0,
        ports: annotate(Sequence[str], minItems=3, maxItems=3) | None = None,
    ) -> None:
        super().__init__(t=t, i=i, r0=r0, r1=r1, ports=ports)
        if ports is not None and len(ports) != 3:
            raise TypeError(
                f"PowerSplitterModel can only be used on components with 3 ports. "
                f"Argument 'ports' has length {len(ports)}."
            )

    def black_box_component(
        self,
        port_spec: str | PortSpec | None = None,
        technology: Technology | None = None,
        name: str | None = None,
    ) -> Component:
        """Create a black-box component using this model for testing.

        Args:
            port_spec: Port specification used in the component. If ``None``,
              look for ``"port_spec"`` in :attr:`config.default_kwargs`.
            technology: Component technology. If ``None``, the default
              technology is used.
            name: Component name. If ``None`` a default is used.

        Returns:
            Component with ports and model.
        """
        model_name = self.__class__.__name__[:-5]
        component = Component(f"BB{model_name}" if name is None else name, technology=technology)
        component.properties.__thumbnail__ = "y-splitter"

        if port_spec is None:
            port_spec = config.default_kwargs.get("port_spec")
            if port_spec is None:
                raise RuntimeError("Missing argument 'port_spec'.")
        if isinstance(port_spec, str):
            name = port_spec
            port_spec = component.technology.ports.get(port_spec)
            if port_spec is None:
                raise RuntimeError(f"Port spec '{name}' not found in component's technology.")

        width = port_spec.width
        length = width * 8

        p1 = [(0, 0), (0.25 * length, 0), (0.75 * length, 0.75 * width), (length, 0.75 * width)]
        p2 = [(x, -y) for x, y in p1]

        profiles = port_spec.path_profiles_list()
        if len(profiles) == 0:
            profiles = [(width, 0, _bb_layer)]

        for w, g, layer in profiles:
            polygons = boolean(
                Path(p1[0], w, g).segment(p1[1:]), Path(p2[0], w, g).segment(p2[1:]), "+"
            )
            component.add(layer, *polygons)

        _add_bb_text(component, width)

        port_names = self.parametric_kwargs["ports"] or [None] * 3
        component.add_port(Port(p1[0], 0, port_spec), port_names[0])
        component.add_port(Port(p2[-1], 180, port_spec.inverted()), port_names[1])
        component.add_port(Port(p1[-1], 180, port_spec.inverted()), port_names[2])

        component.add_model(self, model_name)
        return component

    def start(
        self, component: Component, frequencies: Sequence[float], **kwargs: object
    ) -> SMatrix:
        """Start computing the S matrix response from a component.

        Args:
            component: Component from which to compute the S matrix.
            frequencies: Sequence of frequencies at which to perform the
              computation.
            **kwargs: Unused.

        Returns:
           Model result with attributes ``status`` and ``s_matrix``.
        """
        classification = frequency_classification(frequencies)
        component_ports = {
            name: port.copy(True) for name, port in component.select_ports(classification).items()
        }
        if len(component_ports) != 3:
            raise RuntimeError(
                f"PowerSplitterModel can only be used on components with 3 ports. "
                f"{component.name!r} has {len(component_ports)} {classification} ports."
            )

        p = self.parametric_kwargs

        names = p["ports"]
        if names is None:
            names = sorted(component_ports)
        elif not all(name in component_ports for name in names):
            raise RuntimeError(
                f"Not all port names defined in PowerSplitterModel match the {classification} "
                f"port names in component {component.name!r}."
            )

        num_modes = component_ports[names[0]].num_modes
        if not all(port.num_modes == num_modes for port in component_ports.values()):
            raise RuntimeError(
                f"PowerSplitterModel requires that all component ports have the same number of "
                f"modes. Ports from {component.name!r} support different numbers of modes."
            )

        t = _sample(component.name, "t", p["t"], frequencies, num_modes)
        i = _sample(component.name, "i", p["i"], frequencies, num_modes)
        r0 = _sample(component.name, "r0", p["r0"], frequencies, num_modes)
        r1 = _sample(component.name, "r1", p["r1"], frequencies, num_modes)

        s = (
            (r0, t, t),
            (t, r1, i),
            (t, i, r1),
        )
        elements = {
            (f"{port_in}@{mode}", f"{port_out}@{mode}"): s[j][i][mode]
            for i, port_in in enumerate(names)
            for j, port_out in enumerate(names)
            for mode in range(component_ports[port_in].num_modes)
        }
        return SMatrix(frequencies, elements, component_ports)

    # Deprecated: kept for backwards compatibility with old phf files
    @classmethod
    def from_bytes(cls, byte_repr: bytes) -> "PowerSplitterModel":
        """De-serialize this model."""
        size = struct.calcsize("<B7Q")
        version, *lengths = struct.unpack("<B7Q", byte_repr[:size])
        if version != 0:
            raise RuntimeError("Unsuported PowerSplitterModel version.")
        coeffs = []
        for length in lengths[:4]:
            mem_io = io.BytesIO()
            mem_io.write(byte_repr[size : size + length])
            mem_io.seek(0)
            coeffs.append(numpy.load(mem_io))
            size += length
        if all(length == 0 for length in lengths[4:]):
            ports = None
        else:
            ports = []
            for length in lengths[4:]:
                ports.append(byte_repr[size : size + length].decode("utf8"))
                size += length
        return cls(*coeffs, ports)


class CirculatorModel(Model):
    r"""Data model for a 3-port circulator.

    .. math:: S = \begin{bmatrix}
                    r  &  i  &  t  \\
                    t  &  r  &  i  \\
                    i  &  t  &  r  \\
                  \end{bmatrix}

    Args:
        t: Transmission coefficient.
        i: Leakage (isolation) coefficient.
        r: Reflection coefficient.
        ports: List of port names. If not set, the *sorted* list of port
          names from the component is used.

    Notes:
        For multimode ports, a sequence of coefficients must be used, and
        mixed-mode coefficients are 0. Dispersion can be included in the
        model by setting the coefficients to an :class:`Interpolator` (with
        multiple values for multimode ports), or a 2D array with shape
        (M, N), in which M is the number of modes, and N the length of the
        frequency sequence used in the S matrix computation.
    """

    def __init__(
        self,
        t: ComplexCoeff | Interpolator = 1,
        i: ComplexCoeff | Interpolator = 0,
        r: ComplexCoeff | Interpolator = 0,
        ports: annotate(Sequence[str], minItems=3, maxItems=3) | None = None,
    ) -> None:
        super().__init__(t=t, i=i, r=r, ports=ports)
        if ports is not None and len(ports) != 3:
            raise TypeError(
                f"CirculatorModel can only be used on components with 3 ports. "
                f"Argument 'ports' has length {len(ports)}."
            )

    def black_box_component(
        self,
        port_spec: str | PortSpec | None = None,
        technology: Technology | None = None,
        name: str | None = None,
    ) -> Component:
        """Create a black-box component using this model for testing.

        Args:
            port_spec: Port specification used in the component. If ``None``,
              look for ``"port_spec"`` in :attr:`config.default_kwargs`.
            technology: Component technology. If ``None``, the default
              technology is used.
            name: Component name. If ``None`` a default is used.

        Returns:
            Component with ports and model.
        """
        model_name = self.__class__.__name__[:-5]
        component = Component(f"BB{model_name}" if name is None else name, technology=technology)
        component.properties.__thumbnail__ = "circulator"

        if port_spec is None:
            port_spec = config.default_kwargs.get("port_spec")
            if port_spec is None:
                raise RuntimeError("Missing argument 'port_spec'.")
        if isinstance(port_spec, str):
            name = port_spec
            port_spec = component.technology.ports.get(port_spec)
            if port_spec is None:
                raise RuntimeError(f"Port spec '{name}' not found in component's technology.")

        width = port_spec.width

        profiles = port_spec.path_profiles_list()
        if len(profiles) == 0:
            profiles = [(width, 0, _bb_layer)]

        for w, g, layer in profiles:
            component.add(
                layer,
                Rectangle(center=(width * 3, 0), size=(2 * width, 2 * width)),
                Path((0, 0), w, g).segment((width * 2, 0)),
                Path((width * 3, -width), w, g).segment((width * 3, -width * 3)),
                Path((width * 3, width), w, g).segment((width * 3, width * 3)),
            )

        _add_bb_text(component, width)

        port_names = self.parametric_kwargs["ports"] or [None] * 3
        component.add_port(Port((0, 0), 0, port_spec), port_names[0])
        component.add_port(Port((width * 3, -width * 3), 90, port_spec), port_names[1])
        component.add_port(Port((width * 3, width * 3), -90, port_spec), port_names[2])

        component.add_model(self, model_name)
        return component

    def start(
        self, component: Component, frequencies: Sequence[float], **kwargs: object
    ) -> SMatrix:
        """Start computing the S matrix response from a component.

        Args:
            component: Component from which to compute the S matrix.
            frequencies: Sequence of frequencies at which to perform the
              computation.
            **kwargs: Unused.

        Returns:
           Model result with attributes ``status`` and ``s_matrix``.
        """
        classification = frequency_classification(frequencies)
        component_ports = {
            name: port.copy(True) for name, port in component.select_ports(classification).items()
        }
        if len(component_ports) != 3:
            raise RuntimeError(
                f"CirculatorModel can only be used on components with 3 ports. "
                f"{component.name!r} has {len(component_ports)} {classification} ports."
            )

        p = self.parametric_kwargs

        names = p["ports"]
        if names is None:
            names = sorted(component_ports)
        elif not all(name in component_ports for name in names):
            raise RuntimeError(
                f"Not all port names defined in CirculatorModel match the {classification} "
                f"port names in component {component.name!r}."
            )

        num_modes = component_ports[names[0]].num_modes
        if not all(port.num_modes == num_modes for port in component_ports.values()):
            raise RuntimeError(
                f"CirculatorModel requires that all component ports have the same number of "
                f"modes. Ports from {component.name!r} support different numbers of modes."
            )

        t = _sample(component.name, "t", p["t"], frequencies, num_modes)
        i = _sample(component.name, "i", p["i"], frequencies, num_modes)
        r = _sample(component.name, "r", p["r"], frequencies, num_modes)

        s = (
            (r, i, t),
            (t, r, i),
            (i, t, r),
        )
        elements = {
            (f"{port_in}@{mode}", f"{port_out}@{mode}"): s[j][i][mode]
            for i, port_in in enumerate(names)
            for j, port_out in enumerate(names)
            for mode in range(component_ports[port_in].num_modes)
        }
        return SMatrix(frequencies, elements, component_ports)


class PolarizationBeamSplitterModel(Model):
    r"""Data model for a 3-port polarization beam splitter.

    The S matrix, considering no mode mixing, is represented by:

    .. math:: S = \begin{bmatrix}
                     r_0  &  t_1  &  t_2  \\
                     t_1  &  r_1  &   i   \\
                     t_2  &   i   &  r_2  \\
                  \end{bmatrix}

    The defaults assume that the 3 ports support up to 2 modes. More modes
    can be supported by extending the coefficients (see note below).

    Args:
        t1: Transmission coefficient to the first output port.
        t2: Transmission coefficient to the second output port.
        i: Leakage (isolation) coefficient between outputs.
        r0: Reflection coefficient for the input port.
        r1: Reflection coefficient for the first output port.
        r2: Reflection coefficient for the second output port.
        ports: List of port names. If not set, the *sorted* list of port
          names from the component is used.

    Notes:
        For multimode ports, a sequence of coefficients must be used, and
        mixed-mode coefficients are 0. Dispersion can be included in the
        model by setting the coefficients to an :class:`Interpolator` (with
        multiple values for multimode ports), or a 2D array with shape
        (M, N), in which M is the number of modes, and N the length of the
        frequency sequence used in the S matrix computation.
    """

    def __init__(
        self,
        *,
        t1: ComplexCoeff = (1, 0),
        t2: ComplexCoeff = (0, 1),
        i: ComplexCoeff = (0, 0),
        r0: ComplexCoeff = (0, 0),
        r1: ComplexCoeff = (0, 0),
        r2: ComplexCoeff = (0, 0),
        ports: annotate(Sequence[str], minItems=3, maxItems=3) | None = None,
    ) -> None:
        super().__init__(t1=t1, t2=t2, i=i, r0=r0, r1=r1, r2=r2, ports=ports)
        if ports is not None and len(ports) != 3:
            raise TypeError(
                f"PolarizationBeamSplitterModel can only be used on components with 3 ports. "
                f"Argument 'ports' has length {len(ports)}."
            )

    def black_box_component(
        self,
        port_spec: str | PortSpec | None = None,
        technology: Technology | None = None,
        name: str | None = None,
    ) -> Component:
        """Create a black-box component using this model for testing.

        Args:
            port_spec: Port specification used in the component. If ``None``,
              look for ``"port_spec"`` in :attr:`config.default_kwargs`.
            technology: Component technology. If ``None``, the default
              technology is used.
            name: Component name. If ``None`` a default is used.

        Returns:
            Component with ports and model.
        """
        model_name = self.__class__.__name__[:-5]
        component = Component(f"BB{model_name}" if name is None else name, technology=technology)
        component.properties.__thumbnail__ = "pbs"

        if port_spec is None:
            port_spec = config.default_kwargs.get("port_spec")
            if port_spec is None:
                raise RuntimeError("Missing argument 'port_spec'.")
        if isinstance(port_spec, str):
            name = port_spec
            port_spec = component.technology.ports.get(port_spec)
            if port_spec is None:
                raise RuntimeError(f"Port spec '{name}' not found in component's technology.")

        width = port_spec.width
        length = width * 8

        p1 = [(0, 0), (0.25 * length, 0), (0.75 * length, 1.5 * width), (length, 1.5 * width)]
        p2 = [(0, 0), (length, 0)]

        profiles = port_spec.path_profiles_list()
        if len(profiles) == 0:
            profiles = [(width, 0, _bb_layer)]

        for w, g, layer in profiles:
            polygons = boolean(
                Path(p1[0], w, g).segment(p1[1:]), Path(p2[0], w, g).segment(p2[1:]), "+"
            )
            component.add(layer, *polygons)

        _add_bb_text(component, width)

        port_names = self.parametric_kwargs["ports"] or [None] * 3
        component.add_port(Port(p1[0], 0, port_spec), port_names[0])
        component.add_port(Port(p2[-1], 180, port_spec.inverted()), port_names[1])
        component.add_port(Port(p1[-1], 180, port_spec.inverted()), port_names[2])

        component.add_model(self, model_name)
        return component

    def start(
        self, component: Component, frequencies: Sequence[float], **kwargs: object
    ) -> SMatrix:
        """Start computing the S matrix response from a component.

        Args:
            component: Component from which to compute the S matrix.
            frequencies: Sequence of frequencies at which to perform the
              computation.
            **kwargs: Unused.

        Returns:
           Model result with attributes ``status`` and ``s_matrix``.
        """
        classification = frequency_classification(frequencies)
        component_ports = {
            name: port.copy(True) for name, port in component.select_ports(classification).items()
        }
        if len(component_ports) != 3:
            raise RuntimeError(
                f"PolarizationBeamSplitterModel can only be used on components with 3 ports. "
                f"{component.name!r} has {len(component_ports)} {classification} ports."
            )

        p = self.parametric_kwargs

        names = p["ports"]
        if names is None:
            names = sorted(component_ports)
        elif not all(name in component_ports for name in names):
            raise RuntimeError(
                f"Not all port names defined in PolarizationBeamSplitterModel match the "
                f"{classification} port names in component {component.name!r}."
            )

        num_modes = component_ports[names[0]].num_modes
        if not all(port.num_modes == num_modes for port in component_ports.values()):
            raise RuntimeError(
                f"PolarizationBeamSplitterModel requires that all component ports have the same "
                f"number of modes. Ports from {component.name!r} support different numbers of "
                f"modes."
            )

        t1 = _sample(component.name, "t1", p["t1"], frequencies, num_modes)
        t2 = _sample(component.name, "t2", p["t2"], frequencies, num_modes)
        i = _sample(component.name, "i", p["i"], frequencies, num_modes)
        r0 = _sample(component.name, "r0", p["r0"], frequencies, num_modes)
        r1 = _sample(component.name, "r1", p["r1"], frequencies, num_modes)
        r2 = _sample(component.name, "r2", p["r2"], frequencies, num_modes)

        s = (
            (r0, t1, t2),
            (t1, r1, i),
            (t2, i, r2),
        )
        elements = {
            (f"{port_in}@{mode}", f"{port_out}@{mode}"): s[j][i][mode]
            for i, port_in in enumerate(names)
            for j, port_out in enumerate(names)
            for mode in range(component_ports[port_in].num_modes)
        }
        return SMatrix(frequencies, elements, component_ports)


class PolarizationSplitterRotatorModel(Model):
    r"""Data model for a polarization splitter rotator.

    Two types of PSR models are supported: a 4-port model that assumes a
    2-mode input port and 2 single-mode outputs; and a 6-port model that
    assumes all 3 ports support 2 modes.

    The full 6-port S matrix is represented by the usual coefficients:

    .. math:: S_{6p} = \begin{bmatrix}
                          s_{00} & s_{01} & \cdots & s_{05} \\
                          s_{01} & s_{11} & \cdots & s_{15} \\
                          \vdots & \vdots & \ddots & \vdots \\
                          s_{05} & s_{15} & \cdots & s_{55} \\
                       \end{bmatrix}

    The 4-port version drops the coefficients related to the unused mode in
    the output ports. Using ``output_mode = 0`` (default):

    .. math:: S_{4p} = \begin{bmatrix}
                          s_{00} & s_{01} & s_{02} & s_{04} \\
                          s_{01} & s_{11} & s_{12} & s_{14} \\
                          s_{02} & s_{12} & s_{22} & s_{24} \\
                          s_{04} & s_{14} & s_{24} & s_{44} \\
                       \end{bmatrix}

    and using ``output_mode = 1``:

    .. math:: S'_{4p} = \begin{bmatrix}
                          s_{00} & s_{01} & s_{03} & s_{05} \\
                          s_{01} & s_{11} & s_{13} & s_{15} \\
                          s_{03} & s_{13} & s_{33} & s_{35} \\
                          s_{05} & s_{15} & s_{35} & s_{55} \\
                       \end{bmatrix}

    Args:
        s00: Reflection for first mode on input port.
        s01: Inter-mode reflection for input port.
        s02: Transmission for first mode on input port to first mode on
          first output port.
        s03: Transmission for first mode on input port to second mode on
          first output port.
        s04: Transmission for first mode on input port to first mode on
          second output port.
        s05: Transmission for first mode on input port to second mode on
          second output port.
        s11: Reflection for second mode on input port.
        s12: Transmission for second mode on input port to first mode on
          first output port.
        s13: Transmission for second mode on input port to second mode on
          first output port.
        s14: Transmission for second mode on input port to first mode on
          second output port.
        s15: Transmission for second mode on input port to second mode on
          second output port.
        s22: Reflection for first mode on first output port.
        s23: Inter-mode reflection for the first output port.
        s24: Leakage (isolation) between the first mode on the first output
          port and the first mode on the second output port.
        s25: Leakage (isolation) between the first mode on the first output
          port and the second mode on the second output port.
        s33: Reflection for second mode on first output port.
        s34: Leakage (isolation) between the second mode on the first output
          port and the first mode on the second output port.
        s35: Leakage (isolation) between the second mode on the first output
          port and the second mode on the second output port.
        s44: Reflection for first mode on second output port.
        s45: Inter-mode reflection for the second output port.
        s55: Reflection for second mode on second output port.
        output_mode: Mode number used in output ports in the 4-port version.
        ports: List of port names. If not set, the *sorted* list of port
          names from the component is used.

    Notes:
        Dispersion can be included in the model by setting the coefficients
        to :class:`Interpolator` objects or to 1D arrays with the length of
        the frequencies vector to be used in the computation.
    """

    def __init__(
        self,
        *,
        s00: ComplexCoeff1D | Interpolator = 0,
        s01: ComplexCoeff1D | Interpolator = 0,
        s02: ComplexCoeff1D | Interpolator = 1,
        s03: ComplexCoeff1D | Interpolator = 0,
        s04: ComplexCoeff1D | Interpolator = 0,
        s05: ComplexCoeff1D | Interpolator = 0,
        s11: ComplexCoeff1D | Interpolator = 0,
        s12: ComplexCoeff1D | Interpolator = 0,
        s13: ComplexCoeff1D | Interpolator = 0,
        s14: ComplexCoeff1D | Interpolator = 1,
        s15: ComplexCoeff1D | Interpolator = 0,
        s22: ComplexCoeff1D | Interpolator = 0,
        s23: ComplexCoeff1D | Interpolator = 0,
        s24: ComplexCoeff1D | Interpolator = 0,
        s25: ComplexCoeff1D | Interpolator = 0,
        s33: ComplexCoeff1D | Interpolator = 0,
        s34: ComplexCoeff1D | Interpolator = 0,
        s35: ComplexCoeff1D | Interpolator = 0,
        s44: ComplexCoeff1D | Interpolator = 0,
        s45: ComplexCoeff1D | Interpolator = 0,
        s55: ComplexCoeff1D | Interpolator = 0,
        output_mode: Literal[0, 1] = 0,
        ports: annotate(Sequence[str], minItems=3, maxItems=3) | None = None,
    ) -> None:
        super().__init__(
            s00=s00,
            s01=s01,
            s02=s02,
            s03=s03,
            s04=s04,
            s05=s05,
            s11=s11,
            s12=s12,
            s13=s13,
            s14=s14,
            s15=s15,
            s22=s22,
            s23=s23,
            s24=s24,
            s25=s25,
            s33=s33,
            s34=s34,
            s35=s35,
            s44=s44,
            s45=s45,
            s55=s55,
            output_mode=output_mode,
            ports=ports,
        )
        if ports is not None and len(ports) != 3:
            raise TypeError(
                f"PolarizationSplitterRotatorModel can only be used on components with 3 ports. "
                f"Argument 'ports' has length {len(ports)}."
            )

    def black_box_component(
        self,
        port_spec: str | PortSpec | None = None,
        output_port_spec: str | PortSpec | None = None,
        technology: Technology | None = None,
        name: str | None = None,
    ) -> Component:
        """Create a black-box component using this model for testing.

        Args:
            port_spec: Port specification used in the component. If ``None``,
              look for ``"port_spec"`` in :attr:`config.default_kwargs`.
            output_port_spec: Port specification used for the output ports in
              the component. If ``None``, use the same as ``port_spec``.
            technology: Component technology. If ``None``, the default
              technology is used.
            name: Component name. If ``None`` a default is used.

        Returns:
            Component with ports and model.
        """
        model_name = self.__class__.__name__[:-5]
        component = Component(f"BB{model_name}" if name is None else name, technology=technology)
        # TODO: Add PSR icon
        component.properties.__thumbnail__ = "y-splitter"

        if port_spec is None:
            port_spec = config.default_kwargs.get("port_spec")
            if port_spec is None:
                raise RuntimeError("Missing argument 'port_spec'.")
        if isinstance(port_spec, str):
            name = port_spec
            port_spec = component.technology.ports.get(port_spec)
            if port_spec is None:
                raise RuntimeError(f"Port spec '{name}' not found in component's technology.")
        if isinstance(output_port_spec, str):
            name = output_port_spec
            output_port_spec = component.technology.ports.get(output_port_spec)
            if output_port_spec is None:
                raise RuntimeError(f"Port spec '{name}' not found in component's technology.")
        elif output_port_spec is None:
            output_port_spec = port_spec

        width = max(port_spec.width, output_port_spec.width)
        length = width * 8

        p0 = [(0, 0), (0.5 * length, 0)]
        p1 = [(0.5 * length, 0), (length, 0)]
        p2 = [(0.25 * length, 1.5 * width), (0.75 * length, 1.5 * width), (length, 1.5 * width)]

        profiles = port_spec.path_profiles_list()
        if len(profiles) == 0:
            profiles = [(width, 0, _bb_layer)]

        for w, g, layer in profiles:
            component.add(layer, Path(p0[0], w, g).segment(p0[1:]))

        profiles = output_port_spec.path_profiles_list()
        if len(profiles) == 0:
            profiles = [(width, 0, _bb_layer)]

        for w, g, layer in profiles:
            component.add(
                layer,
                Path(p1[0], w, g).segment(p1[1:]),
                Path(p2[0], 0, g - 0.5 * width).segment(p2[1], w, g).segment(p2[2]),
            )

        _add_bb_text(component, width)

        port_names = self.parametric_kwargs["ports"] or [None] * 3
        component.add_port(Port(p0[0], 0, port_spec), port_names[0])
        component.add_port(Port(p1[-1], 180, output_port_spec), port_names[1])
        component.add_port(Port(p2[-1], 180, output_port_spec), port_names[2])

        component.add_model(self, model_name)
        return component

    def start(
        self, component: Component, frequencies: Sequence[float], **kwargs: object
    ) -> SMatrix:
        """Start computing the S matrix response from a component.

        Args:
            component: Component from which to compute the S matrix.
            frequencies: Sequence of frequencies at which to perform the
              computation.
            **kwargs: Unused.

        Returns:
           Model result with attributes ``status`` and ``s_matrix``.
        """
        classification = frequency_classification(frequencies)
        component_ports = {
            name: port.copy(True) for name, port in component.select_ports(classification).items()
        }
        if len(component_ports) != 3:
            raise RuntimeError(
                f"PolarizationSplitterRotatorModel can only be used on components with 3 ports. "
                f"{component.name!r} has {len(component_ports)} {classification} ports."
            )

        p = self.parametric_kwargs

        names = p["ports"]
        output_mode = int(p["output_mode"])
        if names is None:
            names = sorted(component_ports)
        elif not all(name in component_ports for name in names):
            raise RuntimeError(
                f"Not all port names defined in PolarizationSplitterRotatorModel match the "
                f"{classification} port names in component {component.name!r}."
            )
        p0, p1, p2 = names

        input_modes = component_ports[p0].num_modes
        output_modes = component_ports[p1].num_modes
        if not (
            input_modes == 2
            and output_modes in (1, 2)
            and output_modes == component_ports[p2].num_modes
        ):
            raise RuntimeError(
                f"PolarizationSplitterRotatorModel requires 2 modes in the first port '{p0}', and "
                f"the same number of modes (1 or 2) for ports '{p1}' and '{p2}'."
            )

        shape = (len(frequencies),)
        s00 = _ensure_correct_shape(p["s00"], ndims=1)
        s00 = (
            s00(frequencies)
            if isinstance(s00, Interpolator)
            else numpy.array(numpy.broadcast_to(s00, shape))
        )
        s01 = _ensure_correct_shape(p["s01"], ndims=1)
        s01 = (
            s01(frequencies)
            if isinstance(s01, Interpolator)
            else numpy.array(numpy.broadcast_to(s01, shape))
        )
        s02 = _ensure_correct_shape(p["s02"], ndims=1)
        s02 = (
            s02(frequencies)
            if isinstance(s02, Interpolator)
            else numpy.array(numpy.broadcast_to(s02, shape))
        )
        s03 = _ensure_correct_shape(p["s03"], ndims=1)
        s03 = (
            s03(frequencies)
            if isinstance(s03, Interpolator)
            else numpy.array(numpy.broadcast_to(s03, shape))
        )
        s04 = _ensure_correct_shape(p["s04"], ndims=1)
        s04 = (
            s04(frequencies)
            if isinstance(s04, Interpolator)
            else numpy.array(numpy.broadcast_to(s04, shape))
        )
        s05 = _ensure_correct_shape(p["s05"], ndims=1)
        s05 = (
            s05(frequencies)
            if isinstance(s05, Interpolator)
            else numpy.array(numpy.broadcast_to(s05, shape))
        )
        s11 = _ensure_correct_shape(p["s11"], ndims=1)
        s11 = (
            s11(frequencies)
            if isinstance(s11, Interpolator)
            else numpy.array(numpy.broadcast_to(s11, shape))
        )
        s12 = _ensure_correct_shape(p["s12"], ndims=1)
        s12 = (
            s12(frequencies)
            if isinstance(s12, Interpolator)
            else numpy.array(numpy.broadcast_to(s12, shape))
        )
        s13 = _ensure_correct_shape(p["s13"], ndims=1)
        s13 = (
            s13(frequencies)
            if isinstance(s13, Interpolator)
            else numpy.array(numpy.broadcast_to(s13, shape))
        )
        s14 = _ensure_correct_shape(p["s14"], ndims=1)
        s14 = (
            s14(frequencies)
            if isinstance(s14, Interpolator)
            else numpy.array(numpy.broadcast_to(s14, shape))
        )
        s15 = _ensure_correct_shape(p["s15"], ndims=1)
        s15 = (
            s15(frequencies)
            if isinstance(s15, Interpolator)
            else numpy.array(numpy.broadcast_to(s15, shape))
        )
        s22 = _ensure_correct_shape(p["s22"], ndims=1)
        s22 = (
            s22(frequencies)
            if isinstance(s22, Interpolator)
            else numpy.array(numpy.broadcast_to(s22, shape))
        )
        s23 = _ensure_correct_shape(p["s23"], ndims=1)
        s23 = (
            s23(frequencies)
            if isinstance(s23, Interpolator)
            else numpy.array(numpy.broadcast_to(s23, shape))
        )
        s24 = _ensure_correct_shape(p["s24"], ndims=1)
        s24 = (
            s24(frequencies)
            if isinstance(s24, Interpolator)
            else numpy.array(numpy.broadcast_to(s24, shape))
        )
        s25 = _ensure_correct_shape(p["s25"], ndims=1)
        s25 = (
            s25(frequencies)
            if isinstance(s25, Interpolator)
            else numpy.array(numpy.broadcast_to(s25, shape))
        )
        s33 = _ensure_correct_shape(p["s33"], ndims=1)
        s33 = (
            s33(frequencies)
            if isinstance(s33, Interpolator)
            else numpy.array(numpy.broadcast_to(s33, shape))
        )
        s34 = _ensure_correct_shape(p["s34"], ndims=1)
        s34 = (
            s34(frequencies)
            if isinstance(s34, Interpolator)
            else numpy.array(numpy.broadcast_to(s34, shape))
        )
        s35 = _ensure_correct_shape(p["s35"], ndims=1)
        s35 = (
            s35(frequencies)
            if isinstance(s35, Interpolator)
            else numpy.array(numpy.broadcast_to(s35, shape))
        )
        s44 = _ensure_correct_shape(p["s44"], ndims=1)
        s44 = (
            s44(frequencies)
            if isinstance(s44, Interpolator)
            else numpy.array(numpy.broadcast_to(s44, shape))
        )
        s45 = _ensure_correct_shape(p["s45"], ndims=1)
        s45 = (
            s45(frequencies)
            if isinstance(s45, Interpolator)
            else numpy.array(numpy.broadcast_to(s45, shape))
        )
        s55 = _ensure_correct_shape(p["s55"], ndims=1)
        s55 = (
            s55(frequencies)
            if isinstance(s55, Interpolator)
            else numpy.array(numpy.broadcast_to(s55, shape))
        )

        if output_modes == 2:
            s = (
                (s00, s01, s02, s03, s04, s05),
                (s01, s11, s12, s13, s14, s15),
                (s02, s12, s22, s23, s24, s25),
                (s03, s13, s23, s33, s34, s35),
                (s04, s14, s24, s34, s44, s45),
                (s05, s15, s25, s35, s45, s55),
            )
            names = [f"{p0}@0", f"{p0}@1", f"{p1}@0", f"{p1}@1", f"{p2}@0", f"{p2}@1"]
        else:
            if output_mode == 0:
                s = (
                    (s00, s01, s02, s04),
                    (s01, s11, s12, s14),
                    (s02, s12, s22, s24),
                    (s04, s14, s24, s44),
                )
            else:
                s = (
                    (s00, s01, s03, s05),
                    (s01, s11, s13, s15),
                    (s03, s13, s33, s35),
                    (s05, s15, s35, s55),
                )
            names = [f"{p0}@0", f"{p0}@1", f"{p1}@{output_mode}", f"{p2}@{output_mode}"]
        elements = {
            (port_in, port_out): s[j][i]
            for i, port_in in enumerate(names)
            for j, port_out in enumerate(names)
        }
        return SMatrix(frequencies, elements, component_ports)


class DirectionalCouplerModel(Model):
    r"""Data model for a 4-port directional coupler.

    .. math:: S = \begin{bmatrix}
                     r   &  i   &  t'  &  c'  \\
                     i   &  r   &  c'  &  t'  \\
                     t'  &  c'  &  r   &  i   \\
                     c'  &  t'  &  i   &  r   \\
                  \end{bmatrix}


    with coefficients:

    .. math::

       t' &= t e^{j \phi}

       c' &= c e^{j \phi}

       \phi &= \frac{2 \pi l_p}{c_0}
         [n_\text{eff} f_0 + n_\text{group} (f - f_0)]

    Args:
        t: Transmission coefficient. If ``None``, it is calculated based on
          the magnitude of the other coefficients and the phase of ``c``
          plus 90°.
        c: Coupling coefficient.
        i: Leakage (isolation) coefficient.
        r: Reflection coefficient.
        ports: List of port names. If not set, the *sorted* list of port
          names from the component is used.
        propagation_length: Propagation length :math:`l_p` for dispersion
          modeling.
        n_eff: Effective refractive index for dispersion modeling.
        n_group: Group index. If ``None``, the value of ``n_eff`` is used.
        reference_frequency: Reference frequency :math:`f_0` for dispersion
          calculation. If ``None``, the central frequency is used.

    Notes:
        For multimode ports, a sequence of coefficients must be used, and
        mixed-mode coefficients are 0. Dispersion can be included in the
        model by setting the coefficients to an :class:`Interpolator` (with
        multiple values for multimode ports), or a 2D array with shape
        (M, N), in which M is the number of modes, and N the length of the
        frequency sequence used in the S matrix computation.
    """

    def __init__(
        self,
        t: ComplexCoeff | Interpolator | None = None,
        c: ComplexCoeff | Interpolator = -1j * 2**-0.5,
        i: ComplexCoeff | Interpolator = 0,
        r: ComplexCoeff | Interpolator = 0,
        ports: annotate(Sequence[str], minItems=4, maxItems=4) | None = None,
        *,
        propagation_length: annotate(float, units="μm") = 0.0,
        n_eff: ComplexCoeff | Interpolator = 0.0,
        n_group: FloatCoeff | Interpolator | None = None,
        reference_frequency: Frequency | None = None,
    ) -> None:
        super().__init__(
            t=t,
            c=c,
            i=i,
            r=r,
            ports=ports,
            propagation_length=propagation_length,
            n_eff=n_eff,
            n_group=n_group,
            reference_frequency=reference_frequency,
        )
        if ports is not None and len(ports) != 4:
            raise TypeError(
                f"DirectionalCouplerModel can only be used on components with 4 ports. "
                f"Argument 'ports' has length {len(ports)}."
            )

    def black_box_component(
        self,
        port_spec: str | PortSpec | None = None,
        technology: Technology | None = None,
        name: str | None = None,
    ) -> Component:
        """Create a black-box component using this model for testing.

        Args:
            port_spec: Port specification used in the component. If ``None``,
              look for ``"port_spec"`` in :attr:`config.default_kwargs`.
            technology: Component technology. If ``None``, the default
              technology is used.
            name: Component name. If ``None`` a default is used.

        Returns:
            Component with ports and model.
        """
        model_name = self.__class__.__name__[:-5]
        component = Component(f"BB{model_name}" if name is None else name, technology=technology)
        component.properties.__thumbnail__ = "dc"

        if port_spec is None:
            port_spec = config.default_kwargs.get("port_spec")
            if port_spec is None:
                raise RuntimeError("Missing argument 'port_spec'.")
        if isinstance(port_spec, str):
            name = port_spec
            port_spec = component.technology.ports.get(port_spec)
            if port_spec is None:
                raise RuntimeError(f"Port spec '{name}' not found in component's technology.")

        width = port_spec.width
        length = abs(self.parametric_kwargs["propagation_length"])
        if length == 0.0:
            length = width * 8

        p1 = [
            (0, -0.75 * width),
            (0.25 * length, -0.75 * width),
            (0.75 * length, 0.75 * width),
            (length, 0.75 * width),
        ]
        p2 = [(x, -y) for x, y in p1]

        profiles = port_spec.path_profiles_list()
        if len(profiles) == 0:
            profiles = [(width, 0, _bb_layer)]

        for w, g, layer in profiles:
            polygons = boolean(
                Path(p1[0], w, g).segment(p1[1:]), Path(p2[0], w, g).segment(p2[1:]), "+"
            )
            component.add(layer, *polygons)

        _add_bb_text(component, width)

        port_names = self.parametric_kwargs["ports"] or [None] * 4
        component.add_port(Port(p1[0], 0, port_spec), port_names[0])
        component.add_port(Port(p2[0], 0, port_spec.inverted()), port_names[1])
        component.add_port(Port(p2[-1], 180, port_spec.inverted()), port_names[2])
        component.add_port(Port(p1[-1], 180, port_spec), port_names[3])

        component.add_model(self, model_name)
        return component

    def start(
        self, component: Component, frequencies: Sequence[float], **kwargs: object
    ) -> SMatrix:
        """Start computing the S matrix response from a component.

        Args:
            component: Component from which to compute the S matrix.
            frequencies: Sequence of frequencies at which to perform the
              computation.
            **kwargs: Unused.

        Returns:
           Model result with attributes ``status`` and ``s_matrix``.
        """
        classification = frequency_classification(frequencies)
        component_ports = {
            name: port.copy(True) for name, port in component.select_ports(classification).items()
        }
        if len(component_ports) != 4:
            raise RuntimeError(
                f"DirectionalCouplerModel can only be used on components with 4 ports. "
                f"{component.name!r} has {len(component_ports)} {classification} ports."
            )

        p = self.parametric_kwargs

        names = p["ports"]
        if names is None:
            names = sorted(component_ports)
        elif not all(name in component_ports for name in names):
            raise RuntimeError(
                f"Not all port names defined in DirectionalCouplerModel match the "
                f"{classification} port names in component {component.name!r}."
            )

        num_modes = component_ports[names[0]].num_modes
        if not all(port.num_modes == num_modes for port in component_ports.values()):
            raise RuntimeError(
                f"DirectionalCouplerModel requires that all component ports have the same number "
                f"of modes. Ports from {component.name!r} support different numbers of modes."
            )

        lp = _ensure_correct_shape(p["propagation_length"])

        f0 = p["reference_frequency"]
        if f0 is None:
            f0 = 0.5 * (frequencies.min() + frequencies.max())

        n_eff = _sample(component.name, "n_eff", p["n_eff"], frequencies, num_modes)
        n_group = p["n_group"]
        n_group = (
            n_eff
            if n_group is None
            else _sample(component.name, "n_group", n_group, frequencies, num_modes)
        )

        n_f = (n_eff - n_group) * f0 + n_group * frequencies
        phase = numpy.exp(2j * numpy.pi * lp * n_f / C_0)

        c = _sample(component.name, "c", p["c"], frequencies, num_modes) * phase
        i = _sample(component.name, "i", p["i"], frequencies, num_modes)
        r = _sample(component.name, "r", p["r"], frequencies, num_modes)

        t = p["t"]
        if t is None:
            t_mag = numpy.sqrt(1 - numpy.abs(c) ** 2 - numpy.abs(i) ** 2 - numpy.abs(r) ** 2)
            t = -1j * numpy.exp(1j * numpy.angle(c)) * t_mag
        else:
            t = _sample(component.name, "t", t, frequencies, num_modes) * phase

        s = (
            (r, i, t, c),
            (i, r, c, t),
            (t, c, r, i),
            (c, t, i, r),
        )
        elements = {
            (f"{port_in}@{mode}", f"{port_out}@{mode}"): s[j][i][mode]
            for i, port_in in enumerate(names)
            for j, port_out in enumerate(names)
            for mode in range(component_ports[port_in].num_modes)
        }
        return SMatrix(frequencies, elements, component_ports)

    # Deprecated: kept for backwards compatibility with old phf files
    @classmethod
    def from_bytes(cls, byte_repr: bytes) -> "DirectionalCouplerModel":
        """De-serialize this model."""
        size = struct.calcsize("<B8Q")
        version, *lengths = struct.unpack("<B8Q", byte_repr[:size])
        if version != 0:
            raise RuntimeError("Unsuported DirectionalCouplerModel version.")
        coeffs = []
        for length in lengths[:4]:
            mem_io = io.BytesIO()
            mem_io.write(byte_repr[size : size + length])
            mem_io.seek(0)
            coeffs.append(numpy.load(mem_io))
            size += length
        if all(length == 0 for length in lengths[4:]):
            ports = None
        else:
            ports = []
            for length in lengths[4:]:
                ports.append(byte_repr[size : size + length].decode("utf8"))
                size += length
        return cls(*coeffs, ports)


class CrossingModel(Model):
    r"""Data model for a 4-port waveguide crossing.

    .. math:: S = \begin{bmatrix}
                     r  &  x  &  t  &  x  \\
                     x  &  r  &  x  &  t  \\
                     t  &  x  &  r  &  x  \\
                     x  &  t  &  x  &  r  \\
                  \end{bmatrix} e^{j \phi}


    with dispersion modeled by:

    .. math:: \phi = \frac{2 \pi l_p}{c_0}
         [n_\text{eff} f_0 + n_\text{group} (f - f_0)]

    Args:
        t: Transmission coefficient.
        x: Cross-coupling coefficient.
        r: Reflection coefficient.
        propagation_length: Propagation length :math:`l_p` for dispersion
          modeling.
        n_eff: Effective refractive index for dispersion modeling.
        n_group: Group index. If ``None``, the value of ``n_eff`` is used.
        reference_frequency: Reference frequency :math:`f_0` for dispersion
          calculation. If ``None``, the central frequency is used.
        ports: List of port names. If not set, the *sorted* list of port
          names from the component is used.

    Notes:
        For multimode ports, a sequence of coefficients must be used, and
        mixed-mode coefficients are 0. Dispersion can be included in the
        model by setting the coefficients to an :class:`Interpolator` (with
        multiple values for multimode ports), or a 2D array with shape
        (M, N), in which M is the number of modes, and N the length of the
        frequency sequence used in the S matrix computation.
    """

    def __init__(
        self,
        *,
        t: ComplexCoeff | Interpolator = 1.0,
        x: ComplexCoeff | Interpolator = 0.0,
        r: ComplexCoeff | Interpolator = 0.0,
        propagation_length: annotate(float, units="μm") = 0.0,
        n_eff: ComplexCoeff | Interpolator = 0.0,
        n_group: FloatCoeff | Interpolator | None = None,
        reference_frequency: Frequency | None = None,
        ports: annotate(Sequence[str], minItems=4, maxItems=4) | None = None,
    ) -> None:
        super().__init__(
            t=t,
            x=x,
            r=r,
            ports=ports,
            propagation_length=propagation_length,
            n_eff=n_eff,
            n_group=n_group,
            reference_frequency=reference_frequency,
        )
        if ports is not None and len(ports) != 4:
            raise TypeError(
                f"CrossingModel can only be used on components with 4 ports. "
                f"Argument 'ports' has length {len(ports)}."
            )

    def black_box_component(
        self,
        port_spec: str | PortSpec | None = None,
        technology: Technology | None = None,
        name: str | None = None,
    ) -> Component:
        """Create a black-box component using this model for testing.

        Args:
            port_spec: Port specification used in the component. If ``None``,
              look for ``"port_spec"`` in :attr:`config.default_kwargs`.
            technology: Component technology. If ``None``, the default
              technology is used.
            name: Component name. If ``None`` a default is used.

        Returns:
            Component with ports and model.
        """
        model_name = self.__class__.__name__[:-5]
        component = Component(f"BB{model_name}" if name is None else name, technology=technology)
        component.properties.__thumbnail__ = "crossing"

        if port_spec is None:
            port_spec = config.default_kwargs.get("port_spec")
            if port_spec is None:
                raise RuntimeError("Missing argument 'port_spec'.")
        if isinstance(port_spec, str):
            name = port_spec
            port_spec = component.technology.ports.get(port_spec)
            if port_spec is None:
                raise RuntimeError(f"Port spec '{name}' not found in component's technology.")

        width = port_spec.width
        length = abs(self.parametric_kwargs["propagation_length"])
        if length == 0.0:
            length = width * 8

        profiles = port_spec.path_profiles_list()
        if len(profiles) == 0:
            profiles = [(width, 0, _bb_layer)]

        for w, g, layer in profiles:
            polygons = boolean(
                Path((-length / 2, 0), w, g).segment((length / 2, 0)),
                Path((0, -length / 2), w, g).segment((0, length / 2)),
                "+",
            )
            component.add(layer, *polygons)

        _add_bb_text(component, width)

        port_names = self.parametric_kwargs["ports"] or [None] * 4
        component.add_port(Port((-length / 2, 0), 0, port_spec), port_names[0])
        component.add_port(Port((0, -length / 2), 90, port_spec), port_names[1])
        component.add_port(Port((length / 2, 0), 180, port_spec.inverted()), port_names[2])
        component.add_port(Port((0, length / 2), 270, port_spec.inverted()), port_names[3])

        component.add_model(self, model_name)
        return component

    def start(
        self, component: Component, frequencies: Sequence[float], **kwargs: object
    ) -> SMatrix:
        """Start computing the S matrix response from a component.

        Args:
            component: Component from which to compute the S matrix.
            frequencies: Sequence of frequencies at which to perform the
              computation.
            **kwargs: Unused.

        Returns:
           Model result with attributes ``status`` and ``s_matrix``.
        """
        classification = frequency_classification(frequencies)
        component_ports = {
            name: port.copy(True) for name, port in component.select_ports(classification).items()
        }
        if len(component_ports) != 4:
            raise RuntimeError(
                f"DirectionalCouplerModel can only be used on components with 4 ports. "
                f"{component.name!r} has {len(component_ports)} {classification} ports."
            )

        p = self.parametric_kwargs

        names = p["ports"]
        if names is None:
            names = sorted(component_ports)
        elif not all(name in component_ports for name in names):
            raise RuntimeError(
                f"Not all port names defined in DirectionalCouplerModel match the "
                f"{classification} port names in component {component.name!r}."
            )

        num_modes = component_ports[names[0]].num_modes
        if not all(port.num_modes == num_modes for port in component_ports.values()):
            raise RuntimeError(
                f"DirectionalCouplerModel requires that all component ports have the same number "
                f"of modes. Ports from {component.name!r} support different numbers of modes."
            )

        lp = _ensure_correct_shape(p["propagation_length"])

        f0 = p["reference_frequency"]
        if f0 is None:
            f0 = 0.5 * (frequencies.min() + frequencies.max())

        n_eff = _sample(component.name, "n_eff", p["n_eff"], frequencies, num_modes)
        n_group = p["n_group"]
        n_group = (
            n_eff
            if n_group is None
            else _sample(component.name, "n_group", n_group, frequencies, num_modes)
        )

        n_f = (n_eff - n_group) * f0 + n_group * frequencies
        phase = numpy.exp(2j * numpy.pi * lp * n_f / C_0)

        t = _sample(component.name, "t", p["t"], frequencies, num_modes) * phase
        x = _sample(component.name, "x", p["x"], frequencies, num_modes) * phase
        r = _sample(component.name, "r", p["r"], frequencies, num_modes) * phase

        s = (
            (r, x, t, x),
            (x, r, x, t),
            (t, x, r, x),
            (x, t, x, r),
        )
        elements = {
            (f"{port_in}@{mode}", f"{port_out}@{mode}"): s[j][i][mode]
            for i, port_in in enumerate(names)
            for j, port_out in enumerate(names)
            for mode in range(component_ports[port_in].num_modes)
        }
        return SMatrix(frequencies, elements, component_ports)


def _waveguide_transmission(
    frequencies: object,
    length: object,
    n_eff: object,
    n_group: object,
    dispersion: object,
    dispersion_slope: object,
    reference_frequency: object,
    propagation_loss: object,
    extra_loss: object,
    dn_dT: object,
    dL_dT: object,
    temperature: object,
    reference_temperature: object,
    voltage: object,
    v_piL: object,
    k2: object,
    k3: object,
    dn_dv: object,
    dn_dv2: object,
    dloss_dv: object,
    dloss_dv2: object,
) -> object:
    if reference_frequency is None:
        reference_frequency = 0.5 * (frequencies.min() + frequencies.max())

    dT = temperature - reference_temperature
    n_eff = n_eff + dn_dT * dT + voltage * (dn_dv + voltage * dn_dv2)
    propagation_loss = propagation_loss + dL_dT * dT
    total_loss = extra_loss + length * (
        propagation_loss + voltage * (dloss_dv + voltage * dloss_dv2)
    )

    w0 = 2 * numpy.pi * reference_frequency
    lda0 = C_0 / reference_frequency
    lda0_w0 = lda0 / w0

    beta0 = w0 * n_eff / C_0
    beta1 = n_group / C_0
    beta2 = -lda0_w0 * dispersion
    beta3 = lda0_w0**2 * (dispersion_slope + 2 * dispersion / lda0)
    dw = 2 * numpy.pi * (frequencies - reference_frequency)
    beta = beta0 + dw * (beta1 + dw * (beta2 / 2 + dw * beta3 / 6))

    if v_piL is None or v_piL == 0.0:
        beta_eo = 0.0
    else:
        beta_eo = numpy.pi / v_piL
    beta_eo = voltage * (beta_eo + voltage * (k2 + voltage * k3))
    t = 10.0 ** (total_loss / -20.0) * numpy.exp(1j * (beta + beta_eo) * length)
    return t


class AnalyticWaveguideModel(Model):
    r"""Analytic model for waveguides, bends, and EO phase-shifters.

    This model for 2-port components includes dispersion and temperature
    sensitivity for single- and multi-mode waveguides. For each mode, the
    transmission between ports at frequency :math:`f` is:

    .. math::

       S_{12} &= S_{21} = 10^{-\frac{L}{20}} e^{j (\beta \ell + \phi_{eo})}

       L &= L_0 + \ell \left(L_p + \frac{{\rm d}L_p}{{\rm d}V} V
         + \frac{{\rm d}^2L_p}{{\rm d}V^2} V^2 \right)

       \beta &= \beta_0 + \beta_1 \Delta\omega
         + \frac{\beta_2}{2} \Delta\omega^2
         + \frac{\beta_3}{6} \Delta\omega^3

       \beta_0 &= \frac{\omega_0}{c_0} n_\text{eff}

       \beta_1 &= \frac{n_\text{group}}{c_0}

       \beta_2 &= -\frac{\lambda_0}{\omega_0} D

       \beta_3 &= \left(\frac{\lambda_0}{\omega_0}\right)^2
         \left(S + \frac{2}{\lambda_0} D\right)

       \phi_{eo} &= \frac{\pi V \ell}{V_{\pi L}}
         + k_2 V^2 \ell + k_3 V^3 \ell

    in which :math:`\lambda_0 = c_0 f_0^{-1}`, :math:`\omega_0 = 2 \pi f_0`,
    :math:`\Delta\omega = 2 \pi (f - f_0)`, and the temperature dependence
    is taken into account through:

    .. math::

       n_\text{eff}(T) &= n_\text{eff}(T_0)
         + \frac{{\rm d}n_\text{eff}}{{\rm d}T} (T - T_0)

       L_p(T) &= L_p(T_0) + \frac{{\rm d}L_p}{{\rm d}T} (T - T_0)


    Args:
        n_eff: Effective refractive index (loss can be included here by
          using complex values).
        length: Length :math:`\ell` of the waveguide. If not provided, the
          length is measured by :func:`route_length` or ports distance.
        propagation_loss: Propagation loss :math:`L_p`.
        extra_loss: Length-independent loss :math:`L_0`. This can be used,
          for example, to model bending losses.
        n_group: Group index. If ``None``, the value of ``n_eff`` is used.
        dispersion: Chromatic dispersion coefficient :math:`D`.
        dispersion_slope: Chromatic dispersion slope :math:`S`.
        reference_frequency: Reference frequency :math:`f_0` for dispersion
          coefficients. If ``None``, the central frequency is used.
        dn_dT: Temperature sensitivity for ``n_eff``.
        dL_dT: Temperature sensitivity for ``propagation_loss``.
        temperature: Operating temperature :math:`T`.
        reference_temperature: Reference temperature :math:`T_0`.
        voltage: Operating voltage :math:`V`.
        v_piL: Electro-optic phase coefficient :math:`V_{\pi L}`.
        k2: Quadratic nonlinear phase coefficient.
        k3: Cubic nonlinear phase coefficient.
        dloss_dv: Linear voltage-dependent propagation loss coefficient.
        dloss_dv2: Quadratic voltage-dependent propagation loss coefficient.
    """

    def __init__(
        self,
        *,
        n_eff: complex | Sequence[complex] | Interpolator,
        length: Coordinate | None = None,
        propagation_loss: PropagationLoss | Sequence[PropagationLoss] = 0.0,
        extra_loss: Loss | Sequence[Loss] = 0.0,
        n_group: float | Sequence[float] | Interpolator | None = None,
        dispersion: Dispersion | Sequence[Dispersion] = 0.0,
        dispersion_slope: DispersionSlope | Sequence[DispersionSlope] = 0.0,
        reference_frequency: Frequency | None = None,
        dn_dT: annotate(complex | Sequence[complex], label="dn/dT", units="1/K") = 0.0,
        dL_dT: annotate(float | Sequence[float], label="dL/dT", units="dB/μm/K") = 0.0,
        temperature: Temperature = 293.0,
        reference_temperature: Temperature = 293.0,
        voltage: Voltage = 0.0,
        v_piL: annotate(float, label="VπL", units="V·μm") | None = None,
        k2: annotate(float, label="k₂", units="rad/μm/V²") = 0.0,
        k3: annotate(float, label="k₃", units="rad/μm/V³") = 0.0,
        dloss_dv: annotate(float, label="dL/dV", units="dB/μm/V") = 0.0,
        dloss_dv2: annotate(float, label="d²L/dV²", units="dB/μm/V²") = 0.0,
    ) -> None:
        super().__init__(
            length=length,
            n_eff=n_eff,
            propagation_loss=propagation_loss,
            extra_loss=extra_loss,
            n_group=n_group,
            dispersion=dispersion,
            dispersion_slope=dispersion_slope,
            reference_frequency=reference_frequency,
            dn_dT=dn_dT,
            dL_dT=dL_dT,
            temperature=float(temperature),
            reference_temperature=float(reference_temperature),
            voltage=float(voltage),
            v_piL=v_piL,
            k2=k2,
            k3=k3,
            dloss_dv=dloss_dv,
            dloss_dv2=dloss_dv2,
        )

    def black_box_component(
        self,
        port_spec: str | PortSpec | None = None,
        technology: Technology | None = None,
        name: str | None = None,
    ) -> Component:
        """Create a black-box component using this model for testing.

        Args:
            port_spec: Port specification used in the component. If ``None``,
              look for ``"port_spec"`` in :attr:`config.default_kwargs`.
            technology: Component technology. If ``None``, the default
              technology is used.
            name: Component name. If ``None`` a default is used.

        Returns:
            Component with ports and model.
        """
        p = self.parametric_kwargs

        model_name = self.__class__.__name__[:-5]
        component = Component(f"BB{model_name}" if name is None else name, technology=technology)
        component.properties.__thumbnail__ = "wg" if p["v_piL"] is None else "eo-ps"

        if port_spec is None:
            port_spec = config.default_kwargs.get("port_spec")
            if port_spec is None:
                raise RuntimeError("Missing argument 'port_spec'.")
        if isinstance(port_spec, str):
            name = port_spec
            port_spec = component.technology.ports.get(port_spec)
            if port_spec is None:
                raise RuntimeError(f"Port spec '{name}' not found in component's technology.")

        width = port_spec.width
        length = p["length"]
        if length is None or length <= 0:
            length = width * 8

        profiles = port_spec.path_profiles_list()
        if len(profiles) == 0:
            profiles = [(width, 0, _bb_layer)]

        for w, g, layer in profiles:
            component.add(layer, Path((0, 0), w, g).segment((length, 0)))

        _add_bb_text(component, width)

        component.add_port(
            (Port((0, 0), 0, port_spec), Port((length, 0), 180, port_spec.inverted()))
        )

        component.add_model(self, model_name)
        return component

    def start(
        self,
        component: Component,
        frequencies: Sequence[Frequency],
        temperature: Temperature | None = None,
        voltage: Voltage | None = None,
        **kwargs: object,
    ) -> SMatrix:
        """Start computing the S matrix response from a component.

        Args:
            component: Component from which to compute the S matrix.
            frequencies: Sequence of frequencies at which to perform the
              computation.
            temperature: Operating temperature override.
            voltage: Operating voltage override.
            **kwargs: Unused.

        Returns:
           Result object with attributes ``status`` and ``s_matrix``.
        """
        classification = frequency_classification(frequencies)
        component_ports = {
            name: port.copy(True) for name, port in component.select_ports(classification).items()
        }
        if len(component_ports) != 2:
            raise RuntimeError(
                f"AnalyticWaveguideModel can only be used on components with 2 ports. "
                f"{component.name!r} has {len(component_ports)} {classification} ports.",
            )

        port_names = sorted(component_ports)
        port0 = component_ports[port_names[0]]
        port1 = component_ports[port_names[1]]
        if port0.num_modes != port1.num_modes:
            raise RuntimeError(
                f"AnalyticWaveguideModel requires that all component ports have the same number of "
                f"modes. Ports from {component.name!r} support different numbers of modes."
            )

        frequencies = numpy.asarray(frequencies)

        p = self.parametric_kwargs

        length = p["length"]
        if length is None:
            length = 0
            for _, _, layer in port0.spec.path_profiles_list():
                length = max(length, route_length(component, layer))
            if length <= 0:
                length = numpy.sqrt(numpy.sum((port0.center - port1.center) ** 2))

        if temperature is None:
            temperature = p["temperature"]

        if voltage is None:
            voltage = p["voltage"]

        n_eff = _sample(component.name, "n_eff", p["n_eff"], frequencies, port0.num_modes)
        n_group = p["n_group"]
        n_group = (
            n_eff
            if n_group is None
            else _sample(component.name, "n_group", n_group, frequencies, port0.num_modes)
        )

        t = _waveguide_transmission(
            frequencies,
            length,
            n_eff,
            n_group,
            _ensure_correct_shape(p["dispersion"]),
            _ensure_correct_shape(p["dispersion_slope"]),
            p["reference_frequency"],
            _ensure_correct_shape(p["propagation_loss"]),
            _ensure_correct_shape(p["extra_loss"]),
            _ensure_correct_shape(p["dn_dT"]),
            _ensure_correct_shape(p["dL_dT"]),
            temperature,
            p["reference_temperature"],
            voltage,
            p["v_piL"],
            p["k2"],
            p["k3"],
            0.0,
            0.0,
            p["dloss_dv"],
            p["dloss_dv2"],
        )

        elements = {
            (f"{port_in}@{mode}", f"{port_out}@{mode}"): t[mode]
            for port_in, port_out in [port_names, (port_names[1], port_names[0])]
            for mode in range(component_ports[port_in].num_modes)
        }
        return SMatrix(frequencies, elements, component_ports)


class AnalyticDirectionalCouplerModel(Model):
    r"""Analytic model for a 4-port directional coupler.

    The S matrix for the directional coupler for each mode is given by:

    .. math:: S = \begin{bmatrix}
                     r  &  i  &  t  &  c  \\
                     i  &  r  &  c  &  t  \\
                     t  &  c  &  r  &  i  \\
                     c  &  t  &  i  &  r  \\
                  \end{bmatrix}

    with coefficients:

    .. math::

       t &= \sqrt{1 - c_r} A e^{j \phi}

       c &= \sqrt{c_r} A e^{j (\phi + \Delta\phi)}

       c_r &= \sin^2\left(\frac{\pi l_i}{2 l_c}\right)

       A &= 10^{-\frac{L_\text{dB}}{20}}

       \phi &= \frac{2 \pi l_p}{c_0}
         [n_\text{eff} f_0 + n_\text{group} (f - f_0)]

    Args:
        interaction_length: Interaction length :math:`l_i`.
        coupling_length: Beat length :math:`l_c`.
        propagation_length: Propagation length :math:`l_p`. If ``None``, the
          value of ``interaction_length`` is used.
        cross_phase: Cross-port phase shift :math:`\Delta\phi`.
        insertion_loss: Insertion loss :math:`L_\text{dB}`.
        isolation: Leakage (isolation) coefficient :math:`i`.
        reflection: Reflection coefficient :math:`r`.
        n_eff: Effective refractive index.
        n_group: Group index. If ``None``, the value of ``n_eff`` is used.
        reference_frequency: Reference frequency :math:`f_0` for dispersion
          calculation. If ``None``, the frequency average is used.
        ports: List of port names. If not set, the *sorted* list of port
          names from the component is used.

    Notes:
        For multimode ports, a sequence of coefficients must be used, and
        mixed-mode coefficients are 0. Dispersion can be included in the
        model by setting the coefficients to an :class:`Interpolator` (with
        multiple values for multimode ports), or a 2D array with shape
        (M, N), in which M is the number of modes, and N the length of the
        frequency sequence used in the S matrix computation.
    """

    def __init__(
        self,
        *,
        interaction_length: float,
        coupling_length: annotate(FloatCoeff, units="μm"),
        propagation_length: annotate(FloatCoeff, units="μm") | None = None,
        cross_phase: annotate(FloatCoeff, units="°") = 90,
        insertion_loss: annotate(ComplexCoeff, units="dB") = 0.0,
        isolation: ComplexCoeff | Interpolator = 0.0,
        reflection: ComplexCoeff | Interpolator = 0.0,
        n_eff: ComplexCoeff | Interpolator = 0.0,
        n_group: FloatCoeff | Interpolator | None = None,
        reference_frequency: Frequency | None = None,
        ports: annotate(Sequence[str], minItems=4, maxItems=4) | None = None,
    ) -> None:
        super().__init__(
            interaction_length=float(interaction_length),
            coupling_length=coupling_length,
            propagation_length=propagation_length,
            cross_phase=cross_phase,
            insertion_loss=insertion_loss,
            isolation=isolation,
            reflection=reflection,
            n_eff=n_eff,
            n_group=n_group,
            reference_frequency=reference_frequency,
            ports=ports,
        )
        if ports is not None and len(ports) != 4:
            raise TypeError(
                f"AnalyticDirectionalCouplerModel can only be used on components with 4 ports. "
                f"Argument 'ports' has length {len(ports)}."
            )

    def black_box_component(
        self,
        port_spec: str | PortSpec | None = None,
        technology: Technology | None = None,
        name: str | None = None,
    ) -> Component:
        """Create a black-box component using this model for testing.

        Args:
            port_spec: Port specification used in the component. If ``None``,
              look for ``"port_spec"`` in :attr:`config.default_kwargs`.
            technology: Component technology. If ``None``, the default
              technology is used.
            name: Component name. If ``None`` a default is used.

        Returns:
            Component with ports and model.
        """
        model_name = self.__class__.__name__[:-5]
        component = Component(f"BB{model_name}" if name is None else name, technology=technology)
        component.properties.__thumbnail__ = "dc"

        if port_spec is None:
            port_spec = config.default_kwargs.get("port_spec")
            if port_spec is None:
                raise RuntimeError("Missing argument 'port_spec'.")
        if isinstance(port_spec, str):
            name = port_spec
            port_spec = component.technology.ports.get(port_spec)
            if port_spec is None:
                raise RuntimeError(f"Port spec '{name}' not found in component's technology.")

        width = port_spec.width
        length = self.parametric_kwargs["interaction_length"]
        if length <= 0:
            length = width * 8

        p1 = [
            (0, -0.75 * width),
            (0.25 * length, -0.75 * width),
            (0.75 * length, 0.75 * width),
            (length, 0.75 * width),
        ]
        p2 = [(x, -y) for x, y in p1]

        profiles = port_spec.path_profiles_list()
        if len(profiles) == 0:
            profiles = [(width, 0, _bb_layer)]

        for w, g, layer in profiles:
            polygons = boolean(
                Path(p1[0], w, g).segment(p1[1:]), Path(p2[0], w, g).segment(p2[1:]), "+"
            )
            component.add(layer, *polygons)

        _add_bb_text(component, width)

        port_names = self.parametric_kwargs["ports"] or [None] * 4
        component.add_port(Port(p1[0], 0, port_spec), port_names[0])
        component.add_port(Port(p2[0], 0, port_spec.inverted()), port_names[1])
        component.add_port(Port(p2[-1], 180, port_spec.inverted()), port_names[2])
        component.add_port(Port(p1[-1], 180, port_spec), port_names[3])

        component.add_model(self, model_name)
        return component

    def start(
        self, component: Component, frequencies: Sequence[float], **kwargs: object
    ) -> SMatrix:
        """Start computing the S matrix response from a component.

        Args:
            component: Component from which to compute the S matrix.
            frequencies: Sequence of frequencies at which to perform the
              computation.
            **kwargs: Unused.

        Returns:
           Model result with attributes ``status`` and ``s_matrix``.
        """
        classification = frequency_classification(frequencies)
        component_ports = {
            name: port.copy(True) for name, port in component.select_ports(classification).items()
        }
        if len(component_ports) != 4:
            raise RuntimeError(
                f"AnalyticDirectionalCouplerModel can only be used on components with 4 ports. "
                f"{component.name!r} has {len(component_ports)} {classification} ports.",
            )

        p = self.parametric_kwargs

        names = p["ports"]
        if names is None:
            names = sorted(component_ports)
        elif not all(name in component_ports for name in names):
            raise RuntimeError(
                f"Not all port names defined in AnalyticDirectionalCouplerModel match the "
                f"{classification} port names in component {component.name!r}."
            )

        num_modes = component_ports[names[0]].num_modes
        if not all(port.num_modes == num_modes for port in component_ports.values()):
            raise RuntimeError(
                f"AnalyticDirectionalCouplerModel requires that all ports have the same number of "
                f"modes. Ports from {component.name!r} support different numbers of modes."
            )

        frequencies = numpy.asarray(frequencies)

        li = p["interaction_length"]
        lc = _ensure_correct_shape(p["coupling_length"])
        lp = p["propagation_length"]
        if lp is None:
            lp = li
        else:
            lp = _ensure_correct_shape(lp)

        f0 = p["reference_frequency"]
        if f0 is None:
            f0 = frequencies.mean()

        n_eff = _sample(component.name, "n_eff", p["n_eff"], frequencies, num_modes)
        n_group = p["n_group"]
        n_group = (
            n_eff
            if n_group is None
            else _sample(component.name, "n_group", n_group, frequencies, num_modes)
        )

        phi = 2 * numpy.pi * lp * ((n_eff - n_group) * f0 + n_group * frequencies) / C_0
        cr = numpy.sin((numpy.pi * li) / (2 * lc)) ** 2
        a = 10 ** (-_ensure_correct_shape(p["insertion_loss"]) / 20)

        t = a * numpy.sqrt(1 - cr) * numpy.exp(1j * phi)
        c = (
            a
            * numpy.sqrt(cr)
            * numpy.exp(1j * (phi + _ensure_correct_shape(p["cross_phase"]) / 180 * numpy.pi))
        )

        i = _sample(component.name, "isolation", p["isolation"], frequencies, num_modes)
        r = _sample(component.name, "reflection", p["reflection"], frequencies, num_modes)

        s = (
            (r, i, t, c),
            (i, r, c, t),
            (t, c, r, i),
            (c, t, i, r),
        )
        elements = {
            (f"{port_in}@{mode}", f"{port_out}@{mode}"): s[j][i][mode]
            for i, port_in in enumerate(names)
            for j, port_out in enumerate(names)
            for mode in range(component_ports[port_in].num_modes)
        }
        return SMatrix(frequencies, elements, component_ports)


class AnalyticMZIModel(Model):
    r"""Analytic model for a 4-port Mach-Zehnder interferometer.

    The S matrix for the MZI for each mode is given by:

    .. math::

       S_{31} &= \tau_1 t_1 \tau_2 + \kappa_1 t_2 \kappa_2

       S_{41} &= \tau_1 t_1 \kappa_2 + \kappa_1 t_2 \tau_2

       S_{32} &= \kappa_1 t_1 \tau_2 + \tau_1 t_2 \kappa_2

       S_{42} &= \kappa_1 t_1 \kappa_2 + \tau_1 t_2 \tau_2

    with remaining coefficients zero and transmissions $t_1$ and $t_2$
    calculated through an :class:`AnalyticWaveguideModel`.

    Args:
        n_eff1: Effective refractive index for the first arm (loss can be
          included here by using complex values).
        n_eff2: Effective refractive index for the second arm. If ``None``,
          defaults to ``n_eff1``.
        length1: Length of the first arm.
        length2: Length of the second arm. If ``None``, defaults to
          ``length1``.
        tau1: Transmission coefficient for the first coupler. If ``None``,
          it is calculated based on ``kappa1``.
        tau2: Transmission coefficient for the second coupler. If ``None``,
          it is calculated based on ``kappa2``.
        kappa1: Coupling coefficient for the first coupler.
        kappa2: Coupling coefficient for the second coupler.
        propagation_loss1: Propagation loss for the first arm.
        propagation_loss2: Propagation loss for the second arm.
        extra_loss1: Length-independent loss for the first arm.
        extra_loss2: Length-independent loss for the second arm.
        n_group1: Group index for the first arm. If ``None``, defaults to
          ``n_eff1``.
        n_group2: Group index for the second arm. If ``None``, defaults to
          ``n_group1``, ``n_eff2``, or ``n_eff1`` (first with valid value).
        dispersion1: Chromatic dispersion coefficient for the first arm.
        dispersion2: Chromatic dispersion coefficient for the second arm.
        dispersion_slope1: Chromatic dispersion slope for the first arm.
        dispersion_slope2: Chromatic dispersion slope for the second arm.
        reference_frequency: Reference frequency for the dispersion
          coefficients. If ``None``, the central frequency is used.
        dn1_dT: Temperature sensitivity for ``n_eff1``.
        dn2_dT: Temperature sensitivity for ``n_eff2``.
        dL1_dT: Temperature sensitivity for ``propagation_loss1``.
        dL2_dT: Temperature sensitivity for ``propagation_loss2``.
        temperature1: Operating temperature for the first arm.
        temperature2: Operating temperature for the second arm.
        reference_temperature: Reference temperature.
        voltage1: Operating voltage for the first arm.
        voltage2: Operating voltage for the second arm.
        v_piL1: Electro-optic phase coefficient for the first arm.
        v_piL2: Electro-optic phase coefficient for the second arm.
        k21: Quadratic nonlinear phase coefficient for the first arm.
        k22: Quadratic nonlinear phase coefficient for the second arm.
        k31: Cubic nonlinear phase coefficient for the first arm.
        k32: Cubic nonlinear phase coefficient for the second arm.
        dloss_dv_1: Linear voltage-dependent propagation loss coefficient
          for the first arm.
        dloss_dv_2: Linear voltage-dependent propagation loss coefficient
          for the second arm.
        dloss_dv2_1: Quadratic voltage-dependent propagation loss
          coefficient for the first arm.
        dloss_dv2_2: Quadratic voltage-dependent propagation loss
          coefficient for the second arm.
        ports: List of port names. If not set, the *sorted* list of port
          names from the component is used.

    Notes:
        For multimode ports, mixed-mode coefficients are 0. Parameters can
        be specified per mode by using sequences of values. Dispersion for
        ``tau1``, ``tau2``, ``kappa1``, and ``kappa2`` can also be manually
        included by setting the coefficients to an :class:`Interpolator`
        (with multiple values for multimode ports), or a 2D array with shape
        (M, N), in which M is the number of modes, and N the length of the
        frequency sequence used in the S matrix computation.
    """

    def __init__(
        self,
        *,
        n_eff1: ComplexCoeff | Interpolator,
        n_eff2: ComplexCoeff | Interpolator | None = None,
        length1: Coordinate,
        length2: Coordinate | None = None,
        tau1: ComplexCoeff | Interpolator | None = None,
        tau2: ComplexCoeff | Interpolator | None = None,
        kappa1: ComplexCoeff | Interpolator = -1j * 2**-0.5,
        kappa2: ComplexCoeff | Interpolator = -1j * 2**-0.5,
        propagation_loss1: PropagationLoss | Sequence[PropagationLoss] = 0.0,
        propagation_loss2: PropagationLoss | Sequence[PropagationLoss] = 0.0,
        extra_loss1: Loss | Sequence[Loss] = 0.0,
        extra_loss2: Loss | Sequence[Loss] = 0.0,
        n_group1: float | Sequence[float] | Interpolator | None = None,
        n_group2: float | Sequence[float] | Interpolator | None = None,
        dispersion1: Dispersion | Sequence[Dispersion] = 0.0,
        dispersion2: Dispersion | Sequence[Dispersion] = 0.0,
        dispersion_slope1: DispersionSlope | Sequence[DispersionSlope] = 0.0,
        dispersion_slope2: DispersionSlope | Sequence[DispersionSlope] = 0.0,
        reference_frequency: Frequency | None = None,
        dn1_dT: annotate(complex | Sequence[complex], label="dn/dT 1", units="1/K") = 0.0,
        dn2_dT: annotate(complex | Sequence[complex], label="dn/dT 2", units="1/K") = 0.0,
        dL1_dT: annotate(float | Sequence[float], label="dL/dT 1", units="dB/μm/K") = 0.0,
        dL2_dT: annotate(float | Sequence[float], label="dL/dT 2", units="dB/μm/K") = 0.0,
        temperature1: Temperature = 293.0,
        temperature2: Temperature = 293.0,
        reference_temperature: Temperature = 293.0,
        voltage1: Voltage = 0.0,
        voltage2: Voltage = 0.0,
        v_piL1: annotate(float, label="VπL 1", units="V·μm") | None = None,
        v_piL2: annotate(float, label="VπL 2", units="V·μm") | None = None,
        k21: annotate(float, label="k₂ 1", units="rad/μm/V²") = 0,
        k22: annotate(float, label="k₂ 2", units="rad/μm/V²") = 0,
        k31: annotate(float, label="k₃ 1", units="rad/μm/V³") = 0,
        k32: annotate(float, label="k₃ 2", units="rad/μm/V³") = 0,
        dloss_dv_1: annotate(float, label="dL/dV 1", units="dB/μm/V") = 0,
        dloss_dv_2: annotate(float, label="dL/dV 2", units="dB/μm/V") = 0,
        dloss_dv2_1: annotate(float, label="d²L/dV² 1", units="dB/μm/V²") = 0,
        dloss_dv2_2: annotate(float, label="d²L/dV² 2", units="dB/μm/V²") = 0,
        ports: Sequence[str] | None = None,
    ) -> None:
        super().__init__(
            n_eff1=n_eff1,
            n_eff2=n_eff2,
            length1=float(length1),
            length2=length2,
            tau1=tau1,
            tau2=tau2,
            kappa1=kappa1,
            kappa2=kappa2,
            propagation_loss1=propagation_loss1,
            propagation_loss2=propagation_loss2,
            extra_loss1=extra_loss1,
            extra_loss2=extra_loss2,
            n_group1=n_group1,
            n_group2=n_group2,
            dispersion1=dispersion1,
            dispersion2=dispersion2,
            dispersion_slope1=dispersion_slope1,
            dispersion_slope2=dispersion_slope2,
            reference_frequency=reference_frequency,
            dn1_dT=dn1_dT,
            dn2_dT=dn2_dT,
            dL1_dT=dL1_dT,
            dL2_dT=dL2_dT,
            temperature1=float(temperature1),
            temperature2=float(temperature2),
            reference_temperature=float(reference_temperature),
            voltage1=float(voltage1),
            voltage2=float(voltage2),
            v_piL1=v_piL1,
            v_piL2=v_piL2,
            k21=k21,
            k22=k22,
            k31=k31,
            k32=k32,
            dloss_dv_1=dloss_dv_1,
            dloss_dv_2=dloss_dv_2,
            dloss_dv2_1=dloss_dv2_1,
            dloss_dv2_2=dloss_dv2_2,
            ports=ports,
        )

    def black_box_component(
        self,
        port_spec: str | PortSpec | None = None,
        technology: Technology | None = None,
        name: str | None = None,
    ) -> Component:
        """Create a black-box component using this model for testing.

        Args:
            port_spec: Port specification used in the component. If ``None``,
              look for ``"port_spec"`` in :attr:`config.default_kwargs`.
            technology: Component technology. If ``None``, the default
              technology is used.
            name: Component name. If ``None`` a default is used.

        Returns:
            Component with ports and model.
        """
        p = self.parametric_kwargs

        model_name = self.__class__.__name__[:-5]
        component = Component(f"BB{model_name}" if name is None else name, technology=technology)
        component.properties.__thumbnail__ = "mzm"

        if port_spec is None:
            port_spec = config.default_kwargs.get("port_spec")
            if port_spec is None:
                raise RuntimeError("Missing argument 'port_spec'.")
        if isinstance(port_spec, str):
            name = port_spec
            port_spec = component.technology.ports.get(port_spec)
            if port_spec is None:
                raise RuntimeError(f"Port spec '{name}' not found in component's technology.")

        width = port_spec.width
        dc_length = width * 8
        length1 = p["length1"]
        if length1 <= 0:
            length1 = dc_length
        length2 = p["length2"] or length1
        if length2 <= 0:
            length2 = dc_length
        if max(length1, length2) > 3 * dc_length:
            length1 *= 3 * dc_length / max(length1, length2)
            length2 *= 3 * dc_length / max(length1, length2)

        p1 = [
            (0, -0.75 * width),
            (0.25 * dc_length, -0.75 * width),
            (0.75 * dc_length, 0.75 * width),
            (dc_length, 0.75 * width),
            (dc_length, 0.75 * width + 0.5 * length2),
            (2 * width + dc_length, 0.75 * width + 0.5 * length2),
            (2 * width + dc_length, 0.75 * width),
            (2 * width + 1.25 * dc_length, 0.75 * width),
            (2 * width + 1.75 * dc_length, -0.75 * width),
            (2 * width + 2 * dc_length, -0.75 * width),
        ]
        p2 = [
            (0, 0.75 * width),
            (0.25 * dc_length, 0.75 * width),
            (0.75 * dc_length, -0.75 * width),
            (dc_length, -0.75 * width),
            (dc_length, -0.75 * width - 0.5 * length1),
            (2 * width + dc_length, -0.75 * width - 0.5 * length1),
            (2 * width + dc_length, -0.75 * width),
            (2 * width + 1.25 * dc_length, -0.75 * width),
            (2 * width + 1.75 * dc_length, 0.75 * width),
            (2 * width + 2 * dc_length, 0.75 * width),
        ]

        profiles = port_spec.path_profiles_list()
        if len(profiles) == 0:
            profiles = [(width, 0, _bb_layer)]

        for w, g, layer in profiles:
            polygons = boolean(
                Path(p1[0], w, g).segment(p1[1:]), Path(p2[0], w, g).segment(p2[1:]), "+"
            )
            component.add(layer, *polygons)

        _add_bb_text(component, width)

        port_names = self.parametric_kwargs["ports"] or [None] * 4
        component.add_port(Port(p1[0], 0, port_spec), port_names[0])
        component.add_port(Port(p2[0], 0, port_spec.inverted()), port_names[1])
        component.add_port(Port(p2[-1], 180, port_spec.inverted()), port_names[2])
        component.add_port(Port(p1[-1], 180, port_spec), port_names[3])

        component.add_model(self, model_name)
        return component

    def start(
        self,
        component: Component,
        frequencies: Sequence[Frequency],
        temperature1: Temperature | None = None,
        temperature2: Temperature | None = None,
        voltage1: Voltage | None = None,
        voltage2: Voltage | None = None,
        **kwargs: object,
    ) -> SMatrix:
        """Start computing the S matrix response from a component.

        Args:
            component: Component from which to compute the S matrix.
            frequencies: Sequence of frequencies at which to perform the
              computation.
            temperature1: Operating temperature override for first arm.
            temperature2: Operating temperature override for second arm.
            voltage1: Operating voltage override for first arm.
            voltage2: Operating voltage override for second arm.
            **kwargs: Unused.

        Returns:
           Result object with attributes ``status`` and ``s_matrix``.
        """
        classification = frequency_classification(frequencies)
        component_ports = {
            name: port.copy(True) for name, port in component.select_ports(classification).items()
        }
        if len(component_ports) != 4:
            raise RuntimeError(
                f"AnalyticMZIModel can only be used on components with 4 ports. {component.name!r} "
                f"has {len(component_ports)} {classification} ports.",
            )

        p = self.parametric_kwargs

        names = p["ports"]
        if names is None:
            names = sorted(component_ports)
        elif not all(name in component_ports for name in names):
            raise RuntimeError(
                f"Not all port names defined in AnalyticMZIModel match the {classification} port "
                f"names in component {component.name!r}."
            )

        num_modes = component_ports[names[0]].num_modes
        if not all(port.num_modes == num_modes for port in component_ports.values()):
            raise RuntimeError(
                f"AnalyticMZIModel requires that all ports have the same number of modes. Ports "
                f"from {component.name!r} support different numbers of modes."
            )

        frequencies = numpy.asarray(frequencies)

        if temperature1 is None:
            temperature1 = p["temperature1"]

        if temperature2 is None:
            temperature2 = p["temperature2"]

        if voltage1 is None:
            voltage1 = p["voltage1"]

        if voltage2 is None:
            voltage2 = p["voltage2"]

        n_eff1 = _sample(component.name, "n_eff1", p["n_eff1"], frequencies, num_modes)
        n_eff2 = p["n_eff2"]
        n_eff2 = (
            n_eff1
            if n_eff2 is None
            else _sample(component.name, "n_eff2", n_eff2, frequencies, num_modes)
        )
        n_group1 = p["n_group1"]
        n_group1 = (
            n_eff1
            if n_group1 is None
            else _sample(component.name, "n_group1", n_group1, frequencies, num_modes)
        )
        n_group2 = p["n_group2"]
        n_group2 = (
            (n_group1 if p["n_group1"] is not None else n_eff2)
            if n_group2 is None
            else _sample(component.name, "n_group2", n_group2, frequencies, num_modes)
        )

        length1 = p["length1"]
        length2 = p["length2"]
        if length2 is None:
            length2 = length1

        t1 = _waveguide_transmission(
            frequencies,
            length1,
            n_eff1,
            n_group1,
            _ensure_correct_shape(p["dispersion1"]),
            _ensure_correct_shape(p["dispersion_slope1"]),
            p["reference_frequency"],
            _ensure_correct_shape(p["propagation_loss1"]),
            _ensure_correct_shape(p["extra_loss1"]),
            _ensure_correct_shape(p["dn1_dT"]),
            _ensure_correct_shape(p["dL1_dT"]),
            temperature1,
            p["reference_temperature"],
            voltage1,
            p["v_piL1"],
            p["k21"],
            p["k31"],
            0.0,
            0.0,
            p["dloss_dv_1"],
            p["dloss_dv2_1"],
        )

        t2 = _waveguide_transmission(
            frequencies,
            length2,
            n_eff2,
            n_group2,
            _ensure_correct_shape(p["dispersion2"]),
            _ensure_correct_shape(p["dispersion_slope2"]),
            p["reference_frequency"],
            _ensure_correct_shape(p["propagation_loss2"]),
            _ensure_correct_shape(p["extra_loss2"]),
            _ensure_correct_shape(p["dn2_dT"]),
            _ensure_correct_shape(p["dL2_dT"]),
            temperature2,
            p["reference_temperature"],
            voltage2,
            p["v_piL2"],
            p["k22"],
            p["k32"],
            0.0,
            0.0,
            p["dloss_dv_2"],
            p["dloss_dv2_2"],
        )

        kappa1 = _sample(component.name, "kappa1", p["kappa1"], frequencies, num_modes)
        kappa2 = _sample(component.name, "kappa2", p["kappa2"], frequencies, num_modes)

        tau1 = p["tau1"]
        if tau1 is None:
            tau1 = (
                -1j * numpy.exp(1j * numpy.angle(kappa1)) * numpy.sqrt(1 - numpy.abs(kappa1) ** 2)
            )
        else:
            tau1 = _sample(component.name, "tau1", tau1, frequencies, num_modes)

        tau2 = p["tau2"]
        if tau2 is None:
            tau2 = (
                -1j * numpy.exp(1j * numpy.angle(kappa2)) * numpy.sqrt(1 - numpy.abs(kappa2) ** 2)
            )
        else:
            tau2 = _sample(component.name, "tau2", tau2, frequencies, num_modes)

        s20 = tau1 * t1 * tau2 + kappa1 * t2 * kappa2
        s30 = tau1 * t1 * kappa2 + kappa1 * t2 * tau2
        s21 = kappa1 * t1 * tau2 + tau1 * t2 * kappa2
        s31 = kappa1 * t1 * kappa2 + tau1 * t2 * tau2

        s = (
            (None, None, s20, s30),
            (None, None, s21, s31),
            (s20, s21, None, None),
            (s30, s31, None, None),
        )
        elements = {
            (f"{port_in}@{mode}", f"{port_out}@{mode}"): s[j][i][mode]
            for i, port_in in enumerate(names)
            for j, port_out in enumerate(names)
            if s[j][i] is not None
            for mode in range(component_ports[port_in].num_modes)
        }
        return SMatrix(frequencies, elements, component_ports)


class RingModel(Model):
    r"""Analytic ring resonator/modulator model with single or double bus.

    The S matrix for each mode is given by:

    .. math:: S = \begin{bmatrix}
                     0   &  t_1  &   d   &   0   \\
                    t_1  &   0   &   0   &   d   \\
                     d   &   0   &   0   &  t_2  \\
                     0   &   d   &  t_2  &   0   \\
                  \end{bmatrix}

    in which :math:`t_1` and :math:`t_2` are the thru-port transmissions,
    and :math:`d` is the drop-port transmission. Temperature- and
    voltage-dependent effective index and ring loss are introduced
    analogously to the :class:`AnalyticWaveguideModel`.

    For single-bus models, :math:`\tau_2 = 1` and the S matrix becomes:

    .. math:: S = \begin{bmatrix}
                     0   &  t_1  \\
                    t_1  &   0   \\
                  \end{bmatrix}

    Args:
        kappa1: Coupling coefficient for the first bus waveguide.
        kappa2: Coupling coefficient for the second bus waveguide. If
          ``None``, models a single-bus ring.
        n_eff: Effective refractive index (loss can be included here by
          using complex values).
        length: Round-trip length of the ring.
        propagation_loss: Propagation loss.
        n_group: Group index. If ``None``, the value of ``n_eff`` is used.
        dispersion: Chromatic dispersion coefficient.
        dispersion_slope: Chromatic dispersion slope.
        reference_frequency: Reference frequency for dispersion
          coefficients. If ``None``, the central frequency is used.
        dn_dT: Temperature sensitivity for ``n_eff``.
        dL_dT: Temperature sensitivity for ``propagation_loss``.
        temperature: Operating temperature.
        reference_temperature: Reference temperature.
        voltage: Operating voltage.
        dn_dv: Linear voltage-dependent effective index coefficient.
        dn_dv2: Quadratic voltage-dependent effective index coefficient.
        dloss_dv: Linear voltage-dependent propagation loss coefficient.
        dloss_dv2: Quadratic voltage-dependent propagation loss coefficient.
        ports: List of port names. If not set, the *sorted* list of port
          names from the component is used.

    Notes:
        For multimode ports, mixed-mode coefficients are 0. Parameters can
        be specified per mode by using sequences of values. Dispersion for
        ``kappa1`` and ``kappa2`` can also be manually included by setting
        the coefficients to an :class:`Interpolator` (with multiple values
        for multimode ports), or a 2D array with shape (M, N), in which M is
        the number of modes, and N the length of the frequency sequence used
        in the S matrix computation.
    """

    def __init__(
        self,
        *,
        kappa1: ComplexCoeff | Interpolator,
        kappa2: ComplexCoeff | Interpolator | None = None,
        n_eff: complex | Sequence[complex] | Interpolator,
        length: Coordinate,
        propagation_loss: PropagationLoss | Sequence[PropagationLoss] = 0.0,
        n_group: float | Sequence[float] | Interpolator | None = None,
        dispersion: Dispersion | Sequence[Dispersion] = 0.0,
        dispersion_slope: DispersionSlope | Sequence[DispersionSlope] = 0.0,
        reference_frequency: Frequency | None = None,
        dn_dT: annotate(complex | Sequence[complex], label="dn/dT", units="1/K") = 0.0,
        dL_dT: annotate(float | Sequence[float], label="dL/dT", units="dB/μm/K") = 0.0,
        temperature: Temperature = 293.0,
        reference_temperature: Temperature = 293.0,
        voltage: Voltage = 0.0,
        dn_dv: annotate(complex, label="dn/dV", units="1/V") = 0.0,
        dn_dv2: annotate(complex, label="d²n/dV²", units="1/V²") = 0.0,
        dloss_dv: annotate(float, label="dL/dV", units="dB/μm/V") = 0.0,
        dloss_dv2: annotate(float, label="d²L/dV²", units="dB/μm/V²") = 0.0,
        ports: annotate(Sequence[str], minItems=2, maxItems=2)
        | annotate(Sequence[str], minItems=4, maxItems=4)
        | None = None,
    ) -> None:
        super().__init__(
            kappa1=kappa1,
            kappa2=kappa2,
            n_eff=n_eff,
            length=length,
            propagation_loss=propagation_loss,
            n_group=n_group,
            dispersion=dispersion,
            dispersion_slope=dispersion_slope,
            reference_frequency=reference_frequency,
            dn_dT=dn_dT,
            dL_dT=dL_dT,
            temperature=temperature,
            reference_temperature=reference_temperature,
            voltage=voltage,
            dn_dv=dn_dv,
            dn_dv2=dn_dv2,
            dloss_dv=dloss_dv,
            dloss_dv2=dloss_dv2,
            ports=ports,
        )
        self._double_bus = kappa2 is not None
        if ports is not None:
            if not self._double_bus and len(ports) != 2:
                raise TypeError(
                    f"RingModel with single bus can only be used on components with 2 ports. "
                    f"Argument 'ports' has length {len(ports)}."
                )
            elif self._double_bus and len(ports) != 4:
                raise TypeError(
                    f"RingModel with double bus can only be used on components with 4 ports. "
                    f"Argument 'ports' has length {len(ports)}."
                )

    def black_box_component(
        self,
        port_spec: str | PortSpec | None = None,
        technology: Technology | None = None,
        name: str | None = None,
    ) -> Component:
        """Create a black-box component using this model for testing.

        Args:
            port_spec: Port specification used in the component. If ``None``,
              look for ``"port_spec"`` in :attr:`config.default_kwargs`.
            technology: Component technology. If ``None``, the default
              technology is used.
            name: Component name. If ``None`` a default is used.

        Returns:
            Component with ports and model.
        """
        p = self.parametric_kwargs

        model_name = self.__class__.__name__[:-5]
        component = Component(f"BB{model_name}" if name is None else name, technology=technology)
        component.properties.__thumbnail__ = (
            "mrr"
            if (p["dn_dv"] == 0 and p["dn_dv2"] == 0 and p["dloss_dv"] == 0 and p["dloss_dv2"] == 0)
            else "mrm"
        )

        if port_spec is None:
            port_spec = config.default_kwargs.get("port_spec")
            if port_spec is None:
                raise RuntimeError("Missing argument 'port_spec'.")
        if isinstance(port_spec, str):
            name = port_spec
            port_spec = component.technology.ports.get(port_spec)
            if port_spec is None:
                raise RuntimeError(f"Port spec '{name}' not found in component's technology.")

        width = port_spec.width
        length = width * 4

        profiles = port_spec.path_profiles_list()
        if len(profiles) == 0:
            profiles = [(width, 0, _bb_layer)]

        for w, g, layer in profiles:
            component.add(
                layer,
                Circle(1.75 * width, inner_radius=0.75 * width),
                Path((-0.5 * length, -2.5 * width), w, g).segment((0.5 * length, -2.5 * width)),
            )
            if self._double_bus:
                component.add(
                    layer,
                    Path((-0.5 * length, 2.5 * width), w, g).segment((0.5 * length, 2.5 * width)),
                )

        _add_bb_text(component, width)

        port_names = self.parametric_kwargs["ports"] or [None] * 4
        component.add_port(Port((-0.5 * length, -2.5 * width), 0, port_spec), port_names[0])
        component.add_port(
            Port((0.5 * length, -2.5 * width), 180, port_spec.inverted()), port_names[1]
        )
        if self._double_bus:
            component.add_port(
                Port((-0.5 * length, 2.5 * width), 0, port_spec.inverted()), port_names[2]
            )
            component.add_port(Port((0.5 * length, 2.5 * width), 180, port_spec), port_names[3])

        component.add_model(self, model_name)
        return component

    def start(
        self,
        component: Component,
        frequencies: Sequence[Frequency],
        temperature: Temperature | None = None,
        voltage: Voltage | None = None,
        **kwargs: object,
    ) -> SMatrix:
        """Start computing the S matrix response from a component.

        Args:
            component: Component from which to compute the S matrix.
            frequencies: Sequence of frequencies at which to perform the
              computation.
            temperature: Operating temperature override.
            voltage: Operating voltage override.
            **kwargs: Unused.

        Returns:
           Result object with attributes ``status`` and ``s_matrix``.
        """
        classification = frequency_classification(frequencies)
        component_ports = {
            name: port.copy(True) for name, port in component.select_ports(classification).items()
        }
        if not self._double_bus and len(component_ports) != 2:
            raise TypeError(
                f"RingModel with single bus can only be used on components with 2 ports. "
                f"{component.name!r} has {len(component_ports)} {classification} ports."
            )
        elif self._double_bus and len(component_ports) != 4:
            raise TypeError(
                f"RingModel with double bus can only be used on components with 4 ports. "
                f"{component.name!r} has {len(component_ports)} {classification} ports."
            )

        p = self.parametric_kwargs

        names = p["ports"]
        if names is None:
            names = sorted(component_ports)
        elif not all(name in component_ports for name in names):
            raise RuntimeError(
                f"Not all port names defined in RingModel match the {classification} port names in "
                f"component {component.name!r}."
            )

        num_modes = component_ports[names[0]].num_modes
        if not all(port.num_modes == num_modes for port in component_ports.values()):
            raise RuntimeError(
                f"RingModel requires that all component ports have the same number of modes. Ports "
                f"from {component.name!r} support different numbers of modes."
            )

        if temperature is None:
            temperature = p["temperature"]

        if voltage is None:
            voltage = p["voltage"]

        n_eff = _sample(component.name, "n_eff", p["n_eff"], frequencies, num_modes)
        n_group = p["n_group"]
        n_group = (
            n_eff
            if n_group is None
            else _sample(component.name, "n_group", n_group, frequencies, num_modes)
        )

        ring_transmission = _waveguide_transmission(
            frequencies,
            p["length"],
            n_eff,
            n_group,
            _ensure_correct_shape(p["dispersion"]),
            _ensure_correct_shape(p["dispersion_slope"]),
            p["reference_frequency"],
            _ensure_correct_shape(p["propagation_loss"]),
            0.0,
            _ensure_correct_shape(p["dn_dT"]),
            _ensure_correct_shape(p["dL_dT"]),
            temperature,
            p["reference_temperature"],
            voltage,
            0.0,
            0.0,
            0.0,
            p["dn_dv"],
            p["dn_dv2"],
            p["dloss_dv"],
            p["dloss_dv2"],
        )

        kappa1 = _sample(component.name, "kappa1", p["kappa1"], frequencies, num_modes)
        kappa2 = (
            _sample(component.name, "kappa2", p["kappa2"], frequencies, num_modes)
            if self._double_bus
            else 0.0
        )

        tau1 = -1j * numpy.exp(1j * numpy.angle(kappa1)) * numpy.sqrt(1 - numpy.abs(kappa1) ** 2)
        tau2 = (
            (-1j * numpy.exp(1j * numpy.angle(kappa2)) * numpy.sqrt(1 - numpy.abs(kappa2) ** 2))
            if self._double_bus
            else 1.0
        )

        q = 1.0 - tau1 * tau2 * ring_transmission
        t1 = (tau1 - (tau1**2 - kappa1**2) * tau2 * ring_transmission) / q
        if self._double_bus:
            t2 = (tau2 - (tau2**2 - kappa2**2) * tau1 * ring_transmission) / q
            d = (kappa1 * kappa2 * ring_transmission**0.5) / q
            s = (
                (None, t1, d, None),
                (t1, None, None, d),
                (d, None, None, t2),
                (None, d, t2, None),
            )
        else:
            s = (
                (None, t1),
                (t1, None),
            )

        elements = {
            (f"{port_in}@{mode}", f"{port_out}@{mode}"): s[j][i][mode]
            for i, port_in in enumerate(names)
            for j, port_out in enumerate(names)
            if s[j][i] is not None
            for mode in range(component_ports[port_in].num_modes)
        }
        return SMatrix(frequencies, elements, component_ports)


class DualRingModel(Model):
    r"""Dual ring resonator/modulator model with single or double bus.

    The S matrix for each mode is given by:

    .. math:: S = \begin{bmatrix}
                     0   &  t_1  &   d   &   0   \\
                    t_1  &   0   &   0   &   d   \\
                     d   &   0   &   0   &  t_2  \\
                     0   &   d   &  t_2  &   0   \\
                  \end{bmatrix}

    in which :math:`t_1` and :math:`t_2` are the thru-port transmissions,
    and :math:`d` is the drop-port transmission. Temperature- and
    voltage-dependent effective index and ring loss are introduced
    analogously to the :class:`AnalyticWaveguideModel`.

    For single-bus models, :math:`\tau_3 = 1` and the S matrix becomes:

    .. math:: S = \begin{bmatrix}
                     0   &  t_1  \\
                    t_1  &   0   \\
                  \end{bmatrix}

    Args:
        kappa1: Coupling coefficient for the first bus waveguide.
        kappa2: Coupling coefficient between rings.
        kappa3: Coupling coefficient for the second bus. If ``None``,
          models a single-bus ring.
        n_eff1: Effective refractive index for the first ring (loss can
          be included here by using complex values).
        n_eff2: Effective refractive index for the second ring (loss can
          be included here by using complex values).
        length1: Round-trip length of the first ring.
        length2: Round-trip length of the second ring.
        propagation_loss1: Propagation loss for the first ring.
        propagation_loss2: Propagation loss for the second ring.
        n_group1: Group index for the first ring. If ``None``, the value
          of ``n_eff1`` is used.
        n_group2: Group index for the second ring. If ``None``, the
          value of ``n_eff2`` is used.
        dispersion1: Chromatic dispersion coefficient for the first ring.
        dispersion2: Chromatic dispersion coefficient for the second ring.
        dispersion_slope1: Chromatic dispersion slope for the first ring.
        dispersion_slope2: Chromatic dispersion slope for the second ring.
        reference_frequency: Reference frequency for dispersion
          coefficients. If ``None``, the central frequency is used.
        dn1_dT: Temperature sensitivity for ``n_eff1``.
        dn2_dT: Temperature sensitivity for ``n_eff2``.
        dL1_dT: Temperature sensitivity for ``propagation_loss1``.
        dL2_dT: Temperature sensitivity for ``propagation_loss2``.
        temperature1: Operating temperature for the first ring.
        temperature2: Operating temperature for the second ring.
        reference_temperature: Reference temperature.
        voltage1: Operating voltage for the first ring.
        voltage2: Operating voltage for the second ring.
        dn1_dv: Linear voltage-dependent effective index coefficient
          for the first ring.
        dn2_dv: Linear voltage-dependent effective index coefficient
          for the second ring.
        dn1_dv2: Quadratic voltage-dependent effective index coefficient
          for the first ring.
        dn2_dv2: Quadratic voltage-dependent effective index coefficient
          for the second ring.
        dloss_dv_1: Linear voltage-dependent propagation loss
          coefficient for the first ring.
        dloss_dv_2: Linear voltage-dependent propagation loss
          coefficient for the second ring.
        dloss_dv2_1: Quadratic voltage-dependent propagation loss
          coefficient for the first ring.
        dloss_dv2_2: Quadratic voltage-dependent propagation loss
          coefficient for the second ring.
        ports: List of port names. If not set, the *sorted* list of port
          names from the component is used.

    Notes:
        For multimode ports, mixed-mode coefficients are 0. Parameters can
        be specified per mode by using sequences of values. Dispersion for
        ``kappa1`` and ``kappa2`` can also be manually included by setting
        the coefficients to an :class:`Interpolator` (with multiple values
        for multimode ports), or a 2D array with shape (M, N), in which M is
        the number of modes, and N the length of the frequency sequence used
        in the S matrix computation.
    """

    def __init__(
        self,
        *,
        kappa1: ComplexCoeff | Interpolator,
        kappa2: ComplexCoeff | Interpolator,
        kappa3: ComplexCoeff | Interpolator | None = None,
        n_eff1: complex | Sequence[complex] | Interpolator,
        n_eff2: complex | Sequence[complex] | Interpolator,
        length1: Coordinate,
        length2: Coordinate,
        propagation_loss1: PropagationLoss | Sequence[PropagationLoss] = 0.0,
        propagation_loss2: PropagationLoss | Sequence[PropagationLoss] = 0.0,
        n_group1: float | Sequence[float] | Interpolator | None = None,
        n_group2: float | Sequence[float] | Interpolator | None = None,
        dispersion1: Dispersion | Sequence[Dispersion] = 0.0,
        dispersion2: Dispersion | Sequence[Dispersion] = 0.0,
        dispersion_slope1: DispersionSlope | Sequence[DispersionSlope] = 0.0,
        dispersion_slope2: DispersionSlope | Sequence[DispersionSlope] = 0.0,
        reference_frequency: Frequency | None = None,
        dn1_dT: annotate(complex | Sequence[complex], label="dn/dT", units="1/K") = 0.0,
        dn2_dT: annotate(complex | Sequence[complex], label="dn/dT", units="1/K") = 0.0,
        dL1_dT: annotate(float | Sequence[float], label="dL/dT", units="dB/μm/K") = 0.0,
        dL2_dT: annotate(float | Sequence[float], label="dL/dT", units="dB/μm/K") = 0.0,
        temperature1: Temperature = 293.0,
        temperature2: Temperature = 293.0,
        reference_temperature: Temperature = 293.0,
        voltage1: Voltage = 0.0,
        voltage2: Voltage = 0.0,
        dn1_dv: annotate(complex, label="dn/dV", units="1/V") = 0.0,
        dn2_dv: annotate(complex, label="dn/dV", units="1/V") = 0.0,
        dn1_dv2: annotate(complex, label="d²n/dV²", units="1/V²") = 0.0,
        dn2_dv2: annotate(complex, label="d²n/dV²", units="1/V²") = 0.0,
        dloss_dv_1: annotate(float, label="dL/dV", units="dB/μm/V") = 0.0,
        dloss_dv_2: annotate(float, label="dL/dV", units="dB/μm/V") = 0.0,
        dloss_dv2_1: annotate(float, label="d²L/dV²", units="dB/μm/V²") = 0.0,
        dloss_dv2_2: annotate(float, label="d²L/dV²", units="dB/μm/V²") = 0.0,
        ports: annotate(Sequence[str], minItems=2, maxItems=2)
        | annotate(Sequence[str], minItems=4, maxItems=4)
        | None = None,
    ) -> None:
        super().__init__(
            kappa1=kappa1,
            kappa2=kappa2,
            kappa3=kappa3,
            n_eff1=n_eff1,
            n_eff2=n_eff2,
            length1=length1,
            length2=length2,
            propagation_loss1=propagation_loss1,
            propagation_loss2=propagation_loss2,
            n_group1=n_group1,
            n_group2=n_group2,
            dispersion1=dispersion1,
            dispersion2=dispersion2,
            dispersion_slope1=dispersion_slope1,
            dispersion_slope2=dispersion_slope2,
            reference_frequency=reference_frequency,
            dn1_dT=dn1_dT,
            dn2_dT=dn2_dT,
            dL1_dT=dL1_dT,
            dL2_dT=dL2_dT,
            temperature1=temperature1,
            temperature2=temperature2,
            reference_temperature=reference_temperature,
            voltage1=voltage1,
            voltage2=voltage2,
            dn1_dv=dn1_dv,
            dn2_dv=dn2_dv,
            dn1_dv2=dn1_dv2,
            dn2_dv2=dn2_dv2,
            dloss_dv_1=dloss_dv_1,
            dloss_dv_2=dloss_dv_2,
            dloss_dv2_1=dloss_dv2_1,
            dloss_dv2_2=dloss_dv2_2,
            ports=ports,
        )
        self._double_bus = kappa3 is not None
        if ports is not None:
            if not self._double_bus and len(ports) != 2:
                raise TypeError(
                    f"DualRingModel with single bus can only be used on components with 2 ports. "
                    f"Argument 'ports' has length {len(ports)}."
                )
            elif self._double_bus and len(ports) != 4:
                raise TypeError(
                    f"DualRingModel with double bus can only be used on components with 4 ports. "
                    f"Argument 'ports' has length {len(ports)}."
                )

    def black_box_component(
        self,
        port_spec: str | PortSpec | None = None,
        technology: Technology | None = None,
        name: str | None = None,
    ) -> Component:
        """Create a black-box component using this model for testing.

        Args:
            port_spec: Port specification used in the component. If ``None``,
              look for ``"port_spec"`` in :attr:`config.default_kwargs`.
            technology: Component technology. If ``None``, the default
              technology is used.
            name: Component name. If ``None`` a default is used.

        Returns:
            Component with ports and model.
        """
        model_name = self.__class__.__name__[:-5]
        component = Component(f"BB{model_name}" if name is None else name, technology=technology)
        component.properties.__thumbnail__ = "dual_mrr"

        if port_spec is None:
            port_spec = config.default_kwargs.get("port_spec")
            if port_spec is None:
                raise RuntimeError("Missing argument 'port_spec'.")
        if isinstance(port_spec, str):
            name = port_spec
            port_spec = component.technology.ports.get(port_spec)
            if port_spec is None:
                raise RuntimeError(f"Port spec '{name}' not found in component's technology.")

        width = port_spec.width
        length = width * 4

        profiles = port_spec.path_profiles_list()
        if len(profiles) == 0:
            profiles = [(width, 0, _bb_layer)]

        for w, g, layer in profiles:
            component.add(
                layer,
                Circle(1.5 * width, inner_radius=0.5 * width, center=(0, -1.5 * width)),
                Circle(1.5 * width, inner_radius=0.5 * width, center=(0, 1.5 * width)),
                Path((-0.5 * length, -3.75 * width), w, g).segment((0.5 * length, -3.75 * width)),
            )
            if self._double_bus:
                component.add(
                    layer,
                    Path((-0.5 * length, 3.75 * width), w, g).segment((0.5 * length, 3.75 * width)),
                )

        _add_bb_text(component, width)

        port_names = self.parametric_kwargs["ports"] or [None] * 4
        component.add_port(Port((-0.5 * length, -3.75 * width), 0, port_spec), port_names[0])
        component.add_port(
            Port((0.5 * length, -3.75 * width), 180, port_spec.inverted()), port_names[1]
        )
        if self._double_bus:
            component.add_port(
                Port((-0.5 * length, 3.75 * width), 0, port_spec.inverted()), port_names[2]
            )
            component.add_port(Port((0.5 * length, 3.75 * width), 180, port_spec), port_names[3])

        component.add_model(self, model_name)
        return component

    def start(
        self,
        component: Component,
        frequencies: Sequence[Frequency],
        temperature1: Temperature | None = None,
        voltage1: Voltage | None = None,
        temperature2: Temperature | None = None,
        voltage2: Voltage | None = None,
        **kwargs: object,
    ) -> SMatrix:
        """Start computing the S matrix response from a component.

        Args:
            component: Component from which to compute the S matrix.
            frequencies: Sequence of frequencies at which to perform the
              computation.
            temperature1: Operating temperature override for first ring.
            temperature2: Operating temperature override for second ring.
            voltage1: Operating voltage override for first ring.
            voltage2: Operating voltage override for second ring.
            **kwargs: Unused.

        Returns:
           Result object with attributes ``status`` and ``s_matrix``.
        """
        classification = frequency_classification(frequencies)
        component_ports = {
            name: port.copy(True) for name, port in component.select_ports(classification).items()
        }
        if not self._double_bus and len(component_ports) != 2:
            raise TypeError(
                f"DualRingModel with single bus can only be used on components with 2 ports. "
                f"{component.name!r} has {len(component_ports)} {classification} ports."
            )
        elif self._double_bus and len(component_ports) != 4:
            raise TypeError(
                f"DualRingModel with double bus can only be used on components with 4 ports. "
                f"{component.name!r} has {len(component_ports)} {classification} ports."
            )

        p = self.parametric_kwargs

        names = p["ports"]
        if names is None:
            names = sorted(component_ports)
        elif not all(name in component_ports for name in names):
            raise RuntimeError(
                f"Not all port names defined in DualRingModel match the {classification} port "
                f"names in component {component.name!r}."
            )

        num_modes = component_ports[names[0]].num_modes
        if not all(port.num_modes == num_modes for port in component_ports.values()):
            raise RuntimeError(
                f"DualRingModel requires that all component ports have the same number of modes. "
                f"Ports from {component.name!r} support different numbers of modes."
            )

        if temperature1 is None:
            temperature1 = p["temperature1"]

        if temperature2 is None:
            temperature2 = p["temperature2"]

        if voltage1 is None:
            voltage1 = p["voltage1"]

        if voltage2 is None:
            voltage2 = p["voltage2"]

        n_eff1 = _sample(component.name, "n_eff1", p["n_eff1"], frequencies, num_modes)
        n_group1 = p["n_group1"]
        n_group1 = (
            n_eff1
            if n_group1 is None
            else _sample(component.name, "n_group1", n_group1, frequencies, num_modes)
        )

        ring1_transmission = _waveguide_transmission(
            frequencies,
            p["length1"],
            n_eff1,
            n_group1,
            _ensure_correct_shape(p["dispersion1"]),
            _ensure_correct_shape(p["dispersion_slope1"]),
            p["reference_frequency"],
            _ensure_correct_shape(p["propagation_loss1"]),
            0.0,
            _ensure_correct_shape(p["dn1_dT"]),
            _ensure_correct_shape(p["dL1_dT"]),
            temperature1,
            p["reference_temperature"],
            voltage1,
            0.0,
            0.0,
            0.0,
            p["dn1_dv"],
            p["dn1_dv2"],
            p["dloss_dv_1"],
            p["dloss_dv2_1"],
        )

        n_eff2 = _sample(component.name, "n_eff2", p["n_eff2"], frequencies, num_modes)
        n_group2 = p["n_group2"]
        n_group2 = (
            n_eff2
            if n_group2 is None
            else _sample(component.name, "n_group2", n_group2, frequencies, num_modes)
        )

        ring2_transmission = _waveguide_transmission(
            frequencies,
            p["length2"],
            n_eff2,
            n_group2,
            _ensure_correct_shape(p["dispersion2"]),
            _ensure_correct_shape(p["dispersion_slope2"]),
            p["reference_frequency"],
            _ensure_correct_shape(p["propagation_loss2"]),
            0.0,
            _ensure_correct_shape(p["dn2_dT"]),
            _ensure_correct_shape(p["dL2_dT"]),
            temperature2,
            p["reference_temperature"],
            voltage2,
            0.0,
            0.0,
            0.0,
            p["dn2_dv"],
            p["dn2_dv2"],
            p["dloss_dv_2"],
            p["dloss_dv2_2"],
        )

        kappa1 = _sample(component.name, "kappa1", p["kappa1"], frequencies, num_modes)
        kappa2 = _sample(component.name, "kappa2", p["kappa2"], frequencies, num_modes)
        kappa3 = (
            _sample(component.name, "kappa3", p["kappa3"], frequencies, num_modes)
            if self._double_bus
            else 0.0
        )

        tau1 = -1j * numpy.exp(1j * numpy.angle(kappa1)) * numpy.sqrt(1 - numpy.abs(kappa1) ** 2)
        tau2 = -1j * numpy.exp(1j * numpy.angle(kappa2)) * numpy.sqrt(1 - numpy.abs(kappa2) ** 2)
        tau3 = (
            (-1j * numpy.exp(1j * numpy.angle(kappa3)) * numpy.sqrt(1 - numpy.abs(kappa3) ** 2))
            if self._double_bus
            else 1.0
        )

        tau23 = (tau2 - (tau2**2 - kappa2**2) * tau3 * ring2_transmission) / (
            1.0 - tau2 * tau3 * ring2_transmission
        )
        t1 = (tau1 - (tau1**2 - kappa1**2) * tau23 * ring1_transmission) / (
            1.0 - tau1 * tau23 * ring1_transmission
        )
        if self._double_bus:
            tau21 = (tau2 - (tau2**2 - kappa2**2) * tau1 * ring1_transmission) / (
                1.0 - tau2 * tau1 * ring1_transmission
            )
            t2 = (tau3 - (tau3**2 - kappa3**2) * tau21 * ring2_transmission) / (
                1.0 - tau3 * tau21 * ring2_transmission
            )
            d = (kappa1 * kappa2 * kappa3 * (ring1_transmission * ring2_transmission) ** 0.5) / (
                1.0
                - tau1 * tau2 * ring1_transmission
                - tau2 * tau3 * ring2_transmission
                + tau1 * tau3 * (tau2**2 - kappa2**2) * ring1_transmission * ring2_transmission
            )
            s = (
                (None, t1, d, None),
                (t1, None, None, d),
                (d, None, None, t2),
                (None, d, t2, None),
            )
        else:
            s = (
                (None, t1),
                (t1, None),
            )

        elements = {
            (f"{port_in}@{mode}", f"{port_out}@{mode}"): s[j][i][mode]
            for i, port_in in enumerate(names)
            for j, port_out in enumerate(names)
            if s[j][i] is not None
            for mode in range(component_ports[port_in].num_modes)
        }
        return SMatrix(frequencies, elements, component_ports)


register_model_class(TerminationModel)
register_model_class(TwoPortModel)
register_model_class(IsolatorModel)
register_model_class(PowerSplitterModel)
register_model_class(CirculatorModel)
register_model_class(PolarizationBeamSplitterModel)
register_model_class(PolarizationSplitterRotatorModel)
register_model_class(DirectionalCouplerModel)
register_model_class(CrossingModel)
register_model_class(AnalyticWaveguideModel)
register_model_class(AnalyticDirectionalCouplerModel)
register_model_class(AnalyticMZIModel)
register_model_class(RingModel)
register_model_class(DualRingModel)
