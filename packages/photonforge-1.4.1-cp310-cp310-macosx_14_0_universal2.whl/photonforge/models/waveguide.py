import copy as libcopy
import io
import json
import struct
import zlib
from collections.abc import Sequence
from typing import Literal

import numpy

from ..cache import cache_s_matrix
from ..extension import (
    Component,
    Interpolator,
    Model,
    Path,
    Port,
    PortSpec,
    Reference,
    SMatrix,
    Technology,
    _from_bytes,
    config,
    frequency_classification,
    register_model_class,
)
from ..typing import (
    Coordinate,
    PositiveFloat,
)
from ..utils import C_0, _align_and_overlap, _angles_equal, _gather_status, route_length
from .analytic import ComplexCoeff, _add_bb_text, _bb_layer, _ensure_correct_shape, _sample
from .tidy3d import _ModeSolverRunner


def _port_with_x_section(port_name: str, component: Component) -> Port:
    port = component.ports[port_name].copy(True)
    direction = int((port.input_direction + 45) // 90) % 4
    angle = port.input_direction - 90 * direction
    axis = "x" if direction % 2 == 0 else "y"
    x_length = port.spec.width + 2 * config.tolerance
    x_center = port.center.copy()
    x_center[direction % 2] += config.grid * 2 * (1 - 2 * (direction // 2))
    inner = Component(technology=component.technology).add(Reference(component, -port.center))
    x_comp = Component(technology=component.technology).add(Reference(inner, port.center, -angle))
    port.spec.path_profiles = x_comp.slice_profile(axis, x_center, x_length)
    return port


class _WaveguideModelRunner:
    def __init__(
        self,
        runners: list[_ModeSolverRunner],
        free_space_phase: float,
        frequencies: Sequence[float],
        ports: dict[str, Port],
        overlap_mag_warning: bool,
    ) -> None:
        self.runners = runners
        self.free_space_phase = free_space_phase
        self.frequencies = frequencies
        self.ports = ports
        self.overlap_mag_warning = overlap_mag_warning
        self._s_matrix = None

    @property
    def status(self) -> dict[str, object]:
        return _gather_status(*self.runners)

    @property
    def s_matrix(self) -> SMatrix:
        if self._s_matrix is None:
            data = self.runners[0].data
            num_modes = next(iter(self.ports.values())).num_modes
            overlap = (
                _align_and_overlap(data, self.runners[1].data, self.overlap_mag_warning)[0]
                if len(self.runners) > 1
                else numpy.ones(num_modes)
            )
            n_complex = data.n_complex.values.T
            s = numpy.exp(1j * self.free_space_phase * n_complex)

            elements = {
                (f"{port_in}@{mode}", f"{port_out}@{mode}"): s[mode] * overlap[mode]
                for port_in in self.ports
                for port_out in self.ports
                for mode in range(num_modes)
                if port_in != port_out
            }

            self._s_matrix = SMatrix(self.frequencies, elements, self.ports)

        return self._s_matrix


class WaveguideModel(Model):
    r"""Data model for straight waveguides.

    The component is expected to have 2 ports with identical profiles. The S
    matrix is zero for all reflection or mixed-mode coefficients. Same-mode
    transmission coefficients are modeled by:

    .. math:: S_{jk} = \exp(i 2 \pi f n_c L / c₀)

    with :math:`n_c` the complex effective index for the port profile modes,
    and :math:`L` the waveguide length.

    Args:
        n_complex: Waveguide complex effective index. For multimode models,
          a sequence of indices must be provided, one for each mode. If set
          to ``None``, automatic computation is performed by mode-solving
          the first component port. If desired, the port specification of
          the component port can be overridden by setting ``n_complex`` to
          ``"cross-section"`` (uses :func:`Component.slice_profile`) or to
          a :class:`PortSpec` object.
        length: Physical length of the waveguide. If not provided, the
          length is measured by :func:`route_length` or ports distance.
        mesh_refinement: Minimal number of mesh elements per wavelength used
          for mode solving.
        verbose: Flag setting the verbosity of mode solver runs.

    Note:
        Dispersion can be included in the model by setting ``n_complex`` to
        an :class:`Interpolator` (with multiple values for multimode ports),
        or a 2D array with shape (M, N), in which M is the number of modes
        in the waveguide, and N the length of the frequency sequence used in
        the S matrix computation.

    See also:
        `Mach-Zehnder Interferometer
        <../examples/MZI.ipynb#Semi-Analytic-Design-Exploration>`__
    """

    def __init__(
        self,
        n_complex: ComplexCoeff | Interpolator | PortSpec | Literal["cross-section"] | None = None,
        length: Coordinate | None = None,
        mesh_refinement: PositiveFloat | None = None,
        verbose: bool = True,
    ) -> None:
        super().__init__(
            n_complex=n_complex,
            length=length,
            mesh_refinement=mesh_refinement,
            verbose=verbose,
        )
        self.n_complex = (
            _ensure_correct_shape(n_complex)
            if self._classify_n_complex(n_complex) in (numpy.ndarray, Interpolator)
            else n_complex
        )
        self.length = length
        self.mesh_refinement = mesh_refinement
        self.verbose = verbose

    @classmethod
    def _classify_n_complex(
        cls,
        n_complex: ComplexCoeff | Interpolator | PortSpec | Literal["cross-section"] | None,
    ) -> type[object] | None:
        if n_complex is None:
            return None
        elif isinstance(n_complex, str):
            if n_complex == "cross-section":
                return str
            raise ValueError(
                f"'n_complex' must be a scalar, array, PortSpec object, or the string "
                f"'cross-section'. The string {n_complex!r} is not valid."
            )
        elif isinstance(n_complex, PortSpec):
            return PortSpec
        elif isinstance(n_complex, Interpolator):
            return Interpolator
        else:
            return numpy.ndarray

    def black_box_component(
        self,
        port_spec: str | PortSpec | None = None,
        technology: Technology | None = None,
        name: str | None = None,
    ) -> Component:
        """Create a black-box component using this model for testing.

        Args:
            port_spec: Port specification used in the component. If ``None``,
              look for ``"port_spec"`` in :attr:`config.default_kwargs`.
            technology: Component technology. If ``None``, the default
              technology is used.
            name: Component name. If ``None`` a default is used.

        Returns:
            Component with ports and model.
        """
        model_name = self.__class__.__name__[:-5]
        component = Component(f"BB{model_name}" if name is None else name, technology=technology)
        component.properties.__thumbnail__ = "wg"

        if port_spec is None:
            port_spec = config.default_kwargs.get("port_spec")
            if port_spec is None:
                raise RuntimeError("Missing argument 'port_spec'.")
        if isinstance(port_spec, str):
            name = port_spec
            port_spec = component.technology.ports.get(port_spec)
            if port_spec is None:
                raise RuntimeError(f"Port spec '{name}' not found in component's technology.")

        width = port_spec.width
        length = self.length if self.length and self.length > 0 else width * 8

        profiles = port_spec.path_profiles_list()
        if len(profiles) == 0:
            profiles = [(width, 0, _bb_layer)]

        for w, g, layer in profiles:
            component.add(layer, Path((0, 0), w, g).segment((length, 0)))

        _add_bb_text(component, width)

        component.add_port((Port((0, 0), 0, port_spec), Port((length, 0), 180, port_spec)))
        component.add_model(self, model_name)
        return component

    @cache_s_matrix
    def start(
        self,
        component: Component,
        frequencies: Sequence[float],
        verbose: bool | None = None,
        cost_estimation: bool = False,
        **kwargs: object,
    ) -> SMatrix | _WaveguideModelRunner:
        """Start computing the S matrix response from a component.

        Args:
            component: Component from which to compute the S matrix.
            frequencies: Sequence of frequencies at which to perform the
              computation.
            verbose: If set, overrides the model's `verbose` attribute.
            cost_estimation: If set, simulations are uploaded, but not
              executed. S matrix may *not* be computed.
            **kwargs: Unused.

        Returns:
           Result object with attributes ``status`` and ``s_matrix``.
        """
        classification = frequency_classification(frequencies)
        component_ports = {
            name: port.copy(True) for name, port in component.select_ports(classification).items()
        }
        if len(component_ports) != 2:
            raise RuntimeError(
                f"WaveguideModel can only be used on components with 2 ports. "
                f"'{component.name}' has {len(component_ports)} {classification} ports.",
            )

        port_names = sorted(component_ports)
        port0 = component_ports[port_names[0]]
        port1 = component_ports[port_names[1]]

        if not isinstance(port0, Port) or not isinstance(port1, Port):
            raise RuntimeError(
                "WaveguideModel can only be used on components with planar ports (Port instances)."
            )

        if not port0.can_connect_to(port1):
            raise RuntimeError(
                "WaveguideModel can only be used on components with 2 ports with matching path "
                "profiles."
            )

        length = self.length
        if length is None:
            length = 0
            for _, _, layer in port0.spec.path_profiles_list():
                length = max(length, route_length(component, layer))
            if length <= 0:
                length = numpy.sqrt(numpy.sum((port0.center - port1.center) ** 2))

        frequencies = numpy.array(frequencies, dtype=float, ndmin=1)

        if verbose is None:
            verbose = self.verbose

        n_type = self._classify_n_complex(self.n_complex)
        if n_type in (numpy.ndarray, Interpolator):
            num_modes = port0.num_modes
            coeff = (2.0j * numpy.pi / C_0) * _sample(
                component.name, "n_complex", self.n_complex, frequencies, num_modes
            )

            t = numpy.exp(coeff * length * frequencies)
            elements = {
                (f"{port_in}@{mode}", f"{port_out}@{mode}"): t[mode]
                for port_in, port_out in [port_names, (port_names[1], port_names[0])]
                for mode in range(num_modes)
            }
            return SMatrix(frequencies, elements, component_ports)

        free_space_phase = 2.0 * numpy.pi / C_0 * length * frequencies
        for port in component_ports.values():
            if port.spec.polarization != "":
                port.spec = port.spec.copy()
                port.spec.polarization = ""
                port.spec.num_modes += port.spec.added_solver_modes
                port.spec.added_solver_modes = 0

        if n_type is str:
            ms_ports = (
                _port_with_x_section(port_names[0], component),
                _port_with_x_section(port_names[1], component),
            )
        else:
            ms_ports = (port0.copy(True), port1.copy(True))
            if n_type is PortSpec:
                ms_ports[0].spec = libcopy.deepcopy(self.n_complex)
                ms_ports[1].spec = libcopy.deepcopy(self.n_complex)

        rotation_fraction = (ms_ports[0].input_direction - ms_ports[1].input_direction) % 90
        is_multiple_of_90 = rotation_fraction < 1e-12 or (90 - rotation_fraction < 1e-12)

        ms_ports[1].input_direction += 180
        if _angles_equal(ms_ports[1].input_direction, ms_ports[0].input_direction):
            # No need for mode overlap calculation
            ms_ports = ms_ports[:1]

        runners = [
            _ModeSolverRunner(
                ms_port,
                frequencies,
                self.mesh_refinement,
                component.technology,
                cost_estimation=cost_estimation,
                verbose=verbose,
            )
            for ms_port in ms_ports
        ]
        return _WaveguideModelRunner(
            runners, free_space_phase, frequencies, component_ports, is_multiple_of_90
        )

    # Deprecated: kept for backwards compatibility with old phf files
    @classmethod
    def from_bytes(cls, byte_repr: bytes) -> "WaveguideModel":
        """De-serialize this model."""
        version = byte_repr[0]
        if version == 2:
            return cls(**dict(_from_bytes(byte_repr[1:])))
        elif version == 1:
            head_len = struct.calcsize("<BB2d")
            flags, length, mesh_refinement = struct.unpack("<B2d", byte_repr[1:head_len])
            verbose = (flags & 0x01) > 0
            lenght_is_none = (flags & 0x02) > 0
            n_type = {0x00: None, 0x04: str, 0x08: PortSpec, 0x0C: numpy.ndarray}.get(flags & 0x0C)
        elif version == 0:
            head_len = struct.calcsize("<B3?2d")
            n_complex_is_none, lenght_is_none, verbose, length, mesh_refinement = struct.unpack(
                "<3?2d", byte_repr[1:head_len]
            )
            n_type = None if n_complex_is_none else numpy.ndarray
        else:
            raise RuntimeError(
                "This WaveguideModel seems to have been created by a more recent version of "
                "PhotonForge and it is not supported by the this version."
            )

        if mesh_refinement <= 0:
            mesh_refinement = None

        if lenght_is_none:
            length = None

        n_complex = None
        if n_type is PortSpec:
            kwds = json.loads(zlib.decompress(byte_repr[head_len:]).decode("utf-8"))
            profiles = kwds["path_profiles"]
            if isinstance(profiles, dict):
                kwds["path_profiles"] = {
                    k: (v["width"], v["offset"], v["layer"]) for k, v in profiles.items()
                }
            else:
                kwds["path_profiles"] = [(v["width"], v["offset"], v["layer"]) for v in profiles]
            if "electrical_spec" in kwds:
                # The 1e-5 factor is to fix a bug that existed in the json conversion
                kwds.update(
                    {k: numpy.array(v) * 1e-5 for k, v in kwds.pop("electrical_spec").items()}
                )
            n_complex = PortSpec(**kwds)
        elif n_type is str:
            n_complex = "cross-section"
        elif n_type is numpy.ndarray:
            mem_io = io.BytesIO()
            mem_io.write(byte_repr[head_len:])
            mem_io.seek(0)
            n_complex = numpy.load(mem_io)
            if version == 0:
                # Version 0 stored the transformed coefficient
                n_complex *= -0.5j / numpy.pi * C_0

        return cls(n_complex, length, mesh_refinement, verbose)


register_model_class(WaveguideModel)
