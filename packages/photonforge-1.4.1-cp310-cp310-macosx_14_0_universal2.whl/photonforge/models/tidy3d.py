import collections
import io
import json
import os
import pathlib
import struct
import tempfile
import threading
import time
import warnings
import zlib
from collections.abc import Callable, Sequence
from typing import Any, Literal, get_args

import numpy
import tidy3d
from pydantic import TypeAdapter
from tidy3d.components.base import Tidy3dBaseModel
from tidy3d.components.data.data_array import DATA_ARRAY_MAP
from tidy3d.components.data.monitor_data import ElectromagneticFieldData
from tidy3d.plugins.mode import ModeSolver

from .._autograd.smatrix import AutogradSMatrix
from ..cache import _mode_solver_cache, _tidy3d_model_cache, cache_s_matrix
from ..extension import (
    Z_MAX,
    Component,
    FiberPort,
    GaussianPort,
    Model,
    Port,
    PortSpec,
    SMatrix,
    Technology,
    _auto_scale_from_refinement,
    _from_bytes,
    _layer_steps_from_refinement,
    _local_tidy3d_solver,
    _make_layer_refinement_spec,
    config,
    frequency_classification,
    register_model_class,
    snap_to_grid,
)
from ..parametric_utils import _filename_cleanup
from ..typing import Fraction, Medium, NonNegativeFloat, PositiveFloat, annotate, array
from ..utils import C_0, _angles_equal, _is_multiple_of_90

IsotropicUniformTypes = get_args(tidy3d.components.medium.IsotropicUniformMediumType)

PerElementMap = annotate(
    Sequence[Sequence[str, str], Sequence[str, str], complex | array(complex, 2)],
    brand="PhotonForgePortSymmetryPerElement",
)
ExplictMap = annotate(Sequence[str, str, dict[str, str]], brand="PhotonForgePortSymmetryExplicit")
ImplicitMap = annotate(Sequence[str | int], brand="PhotonForgePortSymmetryImplicit")

PortSymmetryType = Sequence[ExplictMap] | Sequence[ImplicitMap] | Sequence[PerElementMap]

SymmetryType = annotate(Sequence[int], brand="Tidy3dSymmetry")
SubpixelType = tidy3d.SubpixelSpec | bool
BoundsType = annotate(Sequence[Sequence[float | None]], brand="PhotonForgeOptionalBounds")
MonitorType = annotate(tidy3d.components.types.monitor.MonitorType, brand="Tidy3dMonitor")


# Polling interval for Tidy3D tasks
TIDY3D_POLLING_INTERVAL: float = 1.0

# Overlap threshold to discard modes in symmetry mapping
OVERLAP_THRESHOLD: float = 0.1

# Number of simulation structures to trigger grouping into geometry groups by medium
GROUPING_THRESHOLD: int = 1000

_solver_version = None

_pending_tasks_lock = threading.Lock()
_pending_tasks: set = set()


def abort_pending_tasks() -> list[str]:
    """Abort all known pending Tidy3D pending tasks.

    Returns:
        List of aborted task ids.
    """
    from tidy3d.web.api.webapi import abort
    from tidy3d.web.core.exceptions import WebError

    if _pending_tasks_lock is None:
        return []

    with _pending_tasks_lock:
        result = list(_pending_tasks)
        while len(_pending_tasks) > 0:
            task_id = _pending_tasks.pop()
            try:
                abort(task_id)
            except WebError:
                pass
    return result


def _tidy3d_to_str(obj: Tidy3dBaseModel) -> str:
    if (
        isinstance(obj, tidy3d.components.medium.MediumType.__args__)
        and obj.name is not None
        and len(obj.name) > 0
    ):
        return obj.name

    data = obj.model_dump(exclude_unset=True)
    return f"{obj.__class__.__name__}(" + ", ".join(f"{k}={v!r}" for k, v in data.items()) + ")"


_HDF5_HEADER = b"\x89\x48\x44\x46\x0d\x0a\x1a\x0a"
_JSON = b"\x00\x00"


def _tidy3d_to_bytes(obj: Tidy3dBaseModel) -> bytes:
    json_str = obj.model_dump_json(exclude_unset=False)
    if any((key in json_str for key, _ in DATA_ARRAY_MAP.items())):
        buffer = io.BytesIO()
        obj.to_hdf5(buffer)
        result = buffer.getvalue()
    else:
        result = _JSON + json_str.encode("utf-8")
    return result


def _tidy3d_from_bytes(obj_bytes: bytes) -> Tidy3dBaseModel:
    if obj_bytes.startswith(_JSON):
        obj = json.loads(obj_bytes[2:].decode("utf-8"))
    elif obj_bytes.startswith(_HDF5_HEADER):
        try:
            fd, path = tempfile.mkstemp(".hdf5")
            with open(fd, "wb") as fout:
                fout.write(obj_bytes)
            obj = Tidy3dBaseModel.dict_from_hdf5(path)
        finally:
            pathlib.Path(path).unlink(True)
    else:
        raise RuntimeError(
            "Byte sequence does not represent a recognized Tidy3D object in this version."
        )

    cls = getattr(tidy3d, obj["type"])
    return cls.model_validate(obj)


def _isotropic_uniform(
    technology: Technology, classification: Literal["optical", "electrical"]
) -> bool:
    if not isinstance(technology.get_background_medium(classification), IsotropicUniformTypes):
        return False
    return all(
        isinstance(e.get_medium(classification), IsotropicUniformTypes)
        for e in technology.extrusion_specs
    )


def _updated_tidy3d(obj: object, path: Sequence[str], value: object) -> Tidy3dBaseModel:
    if len(path) == 0:
        return value

    attr = path[0]
    path = path[1:]
    if attr.isdecimal():
        attr = int(attr)
        if not hasattr(obj, "__len__"):
            raise RuntimeError(
                f"Invalid 'simulation_updates' key: index found ({attr}) for non-sequence object: "
                f"{obj}"
            )
        obj = list(obj)
        obj[attr] = _updated_tidy3d(obj[attr], path, value)
        return obj

    return obj.copy(update={attr: _updated_tidy3d(getattr(obj, attr), path, value)})


_sim_types = tidy3d.Simulation | ModeSolver | tidy3d.EMESimulation
_data_types = tidy3d.SimulationData | tidy3d.ModeSolverData | tidy3d.EMESimulationData
_sim_type_names = {
    ModeSolver: "mode_solver",
    tidy3d.EMESimulation: "eme",
    tidy3d.Simulation: "tidy3d",
}


class _Tidy3DTaskRunner:
    def __init__(
        self,
        simulation: _sim_types,
        task_name: str,
        remote_path: str,
        verbose: bool,
        cost_estimation: bool,
    ) -> None:
        from tidy3d.web.api.webapi import load_simulation_if_cached

        self.simulation = simulation
        self.verbose = verbose
        self.cost_estimation = cost_estimation
        self.thread = None
        self.lock = threading.Lock()

        # Use cached data, if available
        self._data = load_simulation_if_cached(simulation, verbose=verbose)
        if self._data is not None:
            self._status = {"progress": 100, "message": "success"}
            return

        if _local_tidy3d_solver:
            from tidy3d_pipeline.run import run, run_mode_solver

            if isinstance(simulation, ModeSolver):
                self._data = run_mode_solver(simulation, "simulation_data.hdf5")
            else:
                self._data = run(simulation, "simulation_data.hdf5")
            self._status = {"progress": 100, "message": "success"}
        else:
            from tidy3d.web import Job
            from tidy3d.web.api.webapi import Folder

            # Make sure the folder is created before we use multithreaded uploads to avoid
            # duplication and name errors
            Folder.get(remote_path, create=True)

            self.job = Job(
                simulation=simulation,
                task_name=task_name,
                folder_name=remote_path,
                solver_version=_solver_version,
                verbose=False,
                simulation_type="photonforge:" + _sim_type_names.get(type(simulation), "tidy3d"),
            )

            self._task_info = {"task_name": self.job.task_name}
            self._status = {
                "progress": 0,
                "message": "running",
                "tasks": {"unknown": self._task_info},
            }

            self.thread = threading.Thread(daemon=True, target=self._run_and_monitor_task)
            self.thread.start()

    def _set_status(self, progress: object, message: object, task_info_update: object) -> object:
        with self.lock:
            self._status["progress"] = progress
            self._status["message"] = message
            self._task_info.update(task_info_update)

    def _run_and_monitor_task(self) -> object:
        from tidy3d.web.api import webapi
        from tidy3d.web.core.exceptions import WebError

        # Upload and get task ID
        if self.verbose:
            print(f"Uploading task '{self.job.task_name}…'")
        try:
            self.job.upload()
        except Exception as err:
            self._set_status(100, "error", {"error": str(err)})
            return

        with self.lock:
            self._status["tasks"] = {self.job.task_id: self._task_info}

        if self.cost_estimation:
            try:
                cost = self.job.estimate_cost(verbose=False)
            except WebError as err:
                self._set_status(100, "error", {"error": str(err)})
                return
            if self.verbose:
                print(f"Estimated cost for task '{self.job.task_name}: {cost}'")
            self._set_status(100, "success", {"estimated_cost": cost})
            return

        # Start task
        self._set_status(2, "running", {"status": "queued"})
        if self.verbose:
            url = webapi._get_url(self.job.task_id)
            print(f"Starting task '{self.job.task_name}': {url}")
        try:
            self.job.start()
        except WebError as err:
            self._set_status(100, "error", {"error": str(err)})
            return

        with _pending_tasks_lock:
            _pending_tasks.add(self.job.task_id)

        # Monitor progress
        goon = True
        while goon:
            time.sleep(TIDY3D_POLLING_INTERVAL)
            try:
                # Job.get_info does not expose the verbose flag
                info = webapi.get_info(self.job.task_id, verbose=False)
            except WebError as err:
                self._set_status(100, "error", {"error": str(err)})
                return

            if info.status in ("error", "diverged", "deleted", "abort", "aborted", "aborting"):
                warnings.warn(
                    f"Task with taskId={self.job.task_id} returned status '{info.status}'.",
                    stacklevel=2,
                )
                with _pending_tasks_lock:
                    _pending_tasks.discard(self.job.task_id)
                self._set_status(100, "error", {"status": info.status})
                return

            if info.status == "success":
                goon = False

                with _pending_tasks_lock:
                    _pending_tasks.discard(self.job.task_id)

                self._set_status(98, "running", {"status": "success"})
            else:
                try:
                    run_info = self.job.get_run_info()
                except WebError as err:
                    self._set_status(100, "error", {"error": str(err)})
                    return
                self._set_status(
                    2 + 0.96 * run_info[0],
                    "running",
                    {"status": info.status, "progress": run_info[0]},
                )

        # Download result
        if self.verbose:
            print(f"Downloading data from '{self.job.task_name}'…")

        fd, path = tempfile.mkstemp(".hdf5")
        os.close(fd)
        try:
            data = self.job.load(path)
        except Exception as err:
            with self.lock:
                self._set_status(100, "error", {"error": str(err)})
            return
        finally:
            pathlib.Path(path).unlink(True)

        with self.lock:
            self._data = data
            self._status["progress"] = 100
            self._status["message"] = "success"

    @property
    def status(self) -> dict[str, object]:
        with self.lock:
            return self._status

    @property
    def data(self) -> _data_types:
        with self.lock:
            if self._data is None and self._status["message"] != "success":
                raise RuntimeError(
                    f"Tidy3D task with taskId={self.job.task_id} did not complete successfully."
                )
            return self._data


# This function is used for 2 reasons: first, it checks if the local mode solver should be used.
# The check could be done in _Tidy3DTaskRunner, but that would increase its complexity. Second,
# web GUI can overwrite it to customize how simulations are executed.
def _simulation_runner(
    *,
    simulation: _sim_types,
    task_name: str,
    remote_path: str,
    verbose: bool,
    cost_estimation: bool,
) -> object:
    if (
        not _local_tidy3d_solver
        and config.use_local_mode_solver
        and simulation.type == "ModeSolver"
    ):
        old_level = tidy3d.config.logging.level
        tidy3d.config.logging.level = "ERROR"
        data = simulation.solve()
        tidy3d.config.logging.level = old_level
        RunnerResult = collections.namedtuple("RunnerResult", ("status", "data"))
        return RunnerResult(status={"progress": 100, "message": "success"}, data=data)
    return _Tidy3DTaskRunner(simulation, task_name, remote_path, verbose, cost_estimation)


class _ModeSolverRunner:
    def __init__(
        self,
        port: Port | FiberPort | PortSpec | ModeSolver,
        frequencies: Sequence[float],
        mesh_refinement: float | None,
        technology: Technology,
        *,
        task_name: str | None = None,
        remote_path: str = "Mode Solver",
        center_in_origin: bool = True,
        cost_estimation: bool = False,
        verbose: bool = True,
    ) -> None:
        if mesh_refinement is None:
            mesh_refinement = config.default_mesh_refinement

        frequencies = numpy.array(frequencies, dtype=float, ndmin=1)
        classification = frequency_classification(frequencies)

        if isinstance(port, Port):
            if center_in_origin:
                port = port.copy()
                port.center = (0, 0)
            mode_solver = port.to_tidy3d_mode_solver(
                frequencies,
                mesh_refinement,
                technology=technology,
                use_angle_rotation=_isotropic_uniform(technology, classification),
            )
            description = port.spec.description
        elif isinstance(port, FiberPort):
            if center_in_origin:
                port = port.copy()
                port.center = (0, 0, 0)
            mode_solver = port.to_tidy3d_mode_solver(
                frequencies,
                mesh_refinement,
                technology=technology,
                use_angle_rotation=_isotropic_uniform(technology, classification),
            )
            description = "FiberPort"
        elif isinstance(port, PortSpec):
            mode_solver = port.to_tidy3d(frequencies, mesh_refinement, technology=technology)
            description = port.description
        elif isinstance(port, ModeSolver):
            mode_solver = port
            description = "ModeSolver"
        else:
            raise TypeError("'port' must be a Port, FiberPort, PortSpec, or ModeSolver instance.")

        mode_solver_bytes = _tidy3d_to_bytes(mode_solver)
        key = (mode_solver_bytes, remote_path, cost_estimation)
        self.runner = _mode_solver_cache[key]
        if self.runner is None or self.runner.status["message"] == "error":
            if task_name is None:
                task_name = _filename_cleanup("Mode-" + description)
            self.runner = _simulation_runner(
                simulation=mode_solver,
                task_name=task_name,
                remote_path=remote_path,
                cost_estimation=cost_estimation,
                verbose=verbose,
            )
            _mode_solver_cache[key] = self.runner

    @property
    def status(self) -> dict[str, object]:
        return self.runner.status

    @property
    def data(self) -> tidy3d.SimulationData | tidy3d.ModeSolverData:
        return self.runner.data


def port_modes(
    port: str | Port | FiberPort | PortSpec | ModeSolver,
    frequencies: Sequence[float] = (),
    mesh_refinement: float | None = None,
    group_index: bool = False,
    impedance: bool = False,
    technology: Technology | None = None,
    task_name: str | None = None,
    remote_path: str = "Mode Solver",
    verbose: bool = True,
    show_progress: bool = True,
) -> ModeSolver:
    """Compute the port modes using Tidy3D's mode solver.

    Args:
        port: Port or port specification to solver for modes. A Tidy3D
          ``ModeSolver`` instance can also be used.
        frequencies: Sequence of frequency values for the mode solver.
          Not required if a ``ModeSolver`` instance is used as 'port'.
        mesh_refinement: Minimal number of mesh elements per wavelength used
          for mode solving.
        group_index: Flag indicating whether the mode solver should include
          group index computation.
        impedance: Flag indicating whether the mode impedances should also
          be computed and returned.
        technology: Technology specification for the port.
        task_name: Name for the Tidy3D task.
        remote_path: Remote folder for the task.
        verbose: Flag controlling solver verbosity.
        show_progress: Flag to control whether to show solver progress.

    Returns:
        Mode solver object with calculated `data`. If ``impedance == True``,
        the calculated impedance is also returned (``None`` for optical
        modes).

    Note:
        If a ``ModeSolver`` instance is used as 'port', arguments
        'frequency', 'mesh_refinement', 'group_index', and 'technology' have
        no effect.
    """
    if technology is None:
        technology = config.default_technology
    if isinstance(port, str):
        port = technology.ports[port]

    classification = None
    if isinstance(port, (Port, FiberPort)):
        classification = port.classification
        mode_solver = port.to_tidy3d_mode_solver(
            frequencies,
            mesh_refinement,
            group_index,
            technology,
            _isotropic_uniform(technology, classification),
        )
    elif isinstance(port, PortSpec):
        mode_solver = port.to_tidy3d(frequencies, mesh_refinement, group_index, technology)
        classification = port.classification
    elif isinstance(port, ModeSolver):
        mode_solver = port
    else:
        raise TypeError("'port' must be a Port, FiberPort, PortSpec, or ModeSolver instance.")

    if show_progress:
        print("Starting…", end="\r", flush=True)

    runner = _ModeSolverRunner(
        mode_solver,
        frequencies,
        mesh_refinement,
        technology,
        task_name=task_name,
        remote_path=remote_path,
        center_in_origin=False,
        verbose=verbose,
    )

    progress_chars = "-\\|/"
    i = 0
    while True:
        status = runner.status
        message = status["message"]
        if message == "success":
            if show_progress:
                print("Progress: 100% ", end="\n", flush=True)
            mode_solver._patch_data(runner.data)
            if not impedance:
                return mode_solver

            z0 = None
            if classification == "electrical":
                ic = port.to_tidy3d_impedance_calculator()
                z0 = ic.compute_impedance(mode_solver.data)
            return mode_solver, z0
        elif message == "running":
            if _local_tidy3d_solver:
                raise RuntimeError("Unexpected on-prem mode solver message.")
            if show_progress:
                p = max(0, min(100, int(status.get("progress", 0))))
                c = progress_chars[i]
                i = (i + 1) % len(progress_chars)
                print(f"Progress: {p}% {c}", end="\r", flush=True)
            time.sleep(0.3)
        elif message == "error":
            if show_progress:
                print("Progress: error", end="\n", flush=True)
            raise RuntimeError("Mode solver run resulted in error.")
        else:
            raise RuntimeError(f"Status message unknown: {message!r}.")


def _get_amps(
    data: ElectromagneticFieldData,
    port: Port | FiberPort | GaussianPort,
    epsilon_r: float,
    mode_index: int,
    reversed: bool,
) -> numpy.ndarray:
    args = (data.amps.coords["f"].values, epsilon_r) if isinstance(port, GaussianPort) else ()
    _, _, direction, *_ = port._axis_aligned_properties(*args)
    direction = "-" if (direction == "+") == reversed else "+"
    amps = data.amps.sel(direction=direction, mode_index=mode_index).values.flatten()
    return amps


def _nominal_mode_order(mode_spec: object) -> object:
    spec = mode_spec.sort_spec
    return (
        getattr(mode_spec, "filter_pol", None) is None
        and spec.filter_key is None
        and (
            spec.sort_key is None
            or (
                spec.sort_key == "n_eff"
                and spec.sort_reference is None
                and (spec.sort_order is None or spec.sort_order == "descending")
            )
        )
    )


def _mode_remap_from_symmetry(
    elements: dict[str, numpy.ndarray],
    ports: dict[str, Port | FiberPort | GaussianPort],
    data_sym: dict[str, tidy3d.ModeData | tidy3d.ModeSolverData],
    data_full: dict[str, tidy3d.ModeData | tidy3d.ModeSolverData],
) -> dict[tuple[str, str], numpy.ndarray]:
    num_freqs = next(iter(elements.values())).size
    mode_names = [
        f"{name}@{index}"
        for name, port in sorted(ports.items())
        for index in range(port.num_modes + port.added_solver_modes)
    ]

    # Port mode transformation matrix
    # M_ij = <e_i, e_j'> / <e_i, e_i>
    # S' = pinv(M) × S × M
    s = numpy.zeros((num_freqs, len(mode_names), len(mode_names)), dtype=complex)
    m = numpy.zeros((num_freqs, len(mode_names), len(mode_names)), dtype=complex)

    for j, mode_in in enumerate(mode_names):
        for i, mode_out in enumerate(mode_names):
            element = elements.get((mode_in, mode_out))
            if element is not None:
                s[:, i, j] = element

    total_modes = 0
    total_columns = 0
    invalid_sym_modes = []
    for name, port in sorted(ports.items()):
        num_modes = port.num_modes + port.added_solver_modes
        if isinstance(port, GaussianPort):
            m[
                :, total_modes : total_modes + num_modes, total_columns : total_columns + num_modes
            ] = numpy.eye(num_modes, dtype=complex)
            total_columns += num_modes
        else:
            sym_mode = data_sym[name]
            full_mode = data_full[name]
            projection = sym_mode.outer_dot(full_mode, conjugate=False)
            norm = sym_mode.dot(sym_mode, conjugate=False)
            m_block = (
                projection.transpose("mode_index_1", "mode_index_0", "f").values
                / norm.transpose("mode_index", "f").values
            ).T
            for sym_index in range(num_modes):
                m_line = m_block[:, sym_index, :num_modes]
                if (
                    numpy.sqrt((numpy.abs(m_line) ** 2).sum(axis=1)).sum()
                    < OVERLAP_THRESHOLD * num_freqs
                ):
                    invalid_sym_modes.append(total_modes + sym_index)
            for full_index in range(num_modes):
                m_column = m_block[:, :num_modes, full_index]
                if (
                    numpy.sqrt((numpy.abs(m_column) ** 2).sum(axis=1)).sum()
                    < OVERLAP_THRESHOLD * num_freqs
                ):
                    mode_names.pop(total_columns)
                else:
                    m[:, total_modes : total_modes + num_modes, total_columns] = m_column
                    total_columns += 1
        total_modes += num_modes

    m = m[:, :, :total_columns]
    if len(invalid_sym_modes) > 0:
        m = numpy.delete(m, invalid_sym_modes, 1)
        s = numpy.delete(s, invalid_sym_modes, 1)
        s = numpy.delete(s, invalid_sym_modes, 2)

    s = numpy.linalg.pinv(m) @ s @ m
    return {
        (mode_in, mode_out): s[:, i, j]
        for j, mode_in in enumerate(mode_names)
        for i, mode_out in enumerate(mode_names)
    }


class _Tidy3DModelRunner:
    def __init__(
        self,
        frequencies: Sequence[float],
        simulations: dict[str, tidy3d.Simulation],
        ports: dict[str, Port | FiberPort | GaussianPort],
        port_epsilon: dict[str, float],
        element_mappings: Sequence[PerElementMap],
        folder_name: str,
        cost_estimation: bool,
        verbose: bool,
    ) -> None:
        self.frequencies = frequencies
        self.runners = {}
        for name, sim in simulations.items():
            key = (_tidy3d_to_bytes(sim), folder_name, cost_estimation)
            runner = _tidy3d_model_cache[key]
            if runner is None or runner.status["message"] == "error":
                runner = _simulation_runner(
                    simulation=sim,
                    task_name=name,
                    remote_path=folder_name,
                    cost_estimation=cost_estimation,
                    verbose=verbose,
                )
                _tidy3d_model_cache[key] = runner
            self.runners[name] = runner

        self.ports = ports
        self.port_epsilon = port_epsilon
        self.element_mappings = element_mappings
        self.verbose = verbose
        self._s_matrix = None

        # If the model uses any symmetry or polarization filter, it will impact the mode numbering
        # of the ports. We need to remap port modes from the symmetry-applied to the full version.
        # The first simulation contains all mode fields with symmetry, so we only need to solve for
        # the modes in the full version.
        self.mode_data_key = sorted(simulations)[0]
        mode_sim = simulations[self.mode_data_key]
        self.mode_remap = mode_sim.symmetry != (0, 0, 0) or any(
            not _nominal_mode_order(m.mode_spec)
            for m in mode_sim.monitors
            if m.name in ports and isinstance(m, tidy3d.ModeMonitor)
        )
        if self.mode_remap:
            mode_sim = mode_sim.copy(update={"symmetry": (0, 0, 0)})
            for monitor in mode_sim.monitors:
                if not isinstance(monitor, tidy3d.ModeMonitor):
                    continue
                mode_solver = ModeSolver(
                    simulation=mode_sim,
                    plane=monitor.bounding_box,
                    mode_spec=monitor.mode_spec.copy(update={"sort_spec": tidy3d.ModeSortSpec()}),
                    freqs=monitor.freqs,
                    direction=monitor.store_fields_direction,
                )
                self.runners[monitor.name] = _simulation_runner(
                    simulation=mode_solver,
                    task_name=monitor.name,
                    remote_path=folder_name,
                    cost_estimation=cost_estimation,
                    verbose=verbose,
                )

    @property
    def status(self) -> dict[str, object]:
        """Monitor S matrix computation progress."""
        all_stat = [runner.status for runner in self.runners.values()]
        tasks = {}
        for s in all_stat:
            tasks.update(s.get("tasks", {}))

        if all(s["message"] == "success" for s in all_stat):
            message = "success"
            progress = 100
        elif any(s["message"] == "error" for s in all_stat):
            message = "error"
            progress = 100
        else:
            message = "running"
            progress = sum(
                100 if s["message"] == "success" else s["progress"] for s in all_stat
            ) / len(all_stat)
        return {"progress": progress, "message": message, "tasks": tasks}

    @property
    def s_matrix(self) -> SMatrix:
        """Get the model S matrix."""
        if self._s_matrix is None:
            elements = {}
            for src, src_port in self.ports.items():
                for src_mode in range(src_port.num_modes):
                    src_key = f"{src}@{src_mode}"
                    if src_key not in self.runners:
                        continue
                    data = self.runners[src_key].data
                    norm = _get_amps(
                        data[src], src_port, self.port_epsilon.get(src), src_mode, False
                    )
                    for dst, dst_port in self.ports.items():
                        for dst_mode in range(dst_port.num_modes):
                            dst_key = f"{dst}@{dst_mode}"
                            coeff = _get_amps(
                                data[dst], dst_port, self.port_epsilon.get(dst), dst_mode, True
                            )
                            elements[(src_key, dst_key)] = coeff / norm

            # S[src2@i, dst2@j] = factor[i, j] * S[src1@i, dst1@j]
            for (src1, dst1), (src2, dst2), factor in self.element_mappings:
                src_modes = self.ports[src1].num_modes
                dst_modes = self.ports[dst1].num_modes
                for src_index in range(src_modes):
                    for dst_index in range(dst_modes):
                        key1 = f"{src1}@{src_index}", f"{dst1}@{dst_index}"
                        key2 = f"{src2}@{src_index}", f"{dst2}@{dst_index}"
                        if key1 in elements and key2 not in elements:
                            elements[key2] = factor[src_index, dst_index] * elements[key1]

            # If symmetry or polarization filter was used, calculate and apply mode mapping
            if self.mode_remap:
                data_sym = self.runners[self.mode_data_key].data
                data_full = {
                    name: self.runners[name].data
                    for name, port in self.ports.items()
                    if not isinstance(port, GaussianPort)
                }
                elements = _mode_remap_from_symmetry(elements, self.ports, data_sym, data_full)

            self._s_matrix = SMatrix(self.frequencies, elements, self.ports)

        return self._s_matrix


def _get_epsilon(
    position: Sequence[float],
    structures: Sequence[tidy3d.Structure],
    background_medium: Medium,
    frequencies: Sequence[float],
) -> numpy.ndarray:
    for structure in structures[::-1]:
        bb_min, bb_max = structure.geometry.bounds
        if all(
            bb_min[i] <= position[i] <= bb_max[i] for i in range(3)
        ) and structure.geometry.inside(position[0:1], position[1:2], position[2:3]):
            return numpy.array([structure.medium.eps_comp(0, 0, f).real for f in frequencies])
    return numpy.array([background_medium.eps_comp(0, 0, f).real for f in frequencies])


def _source_shift(
    source: tidy3d.Source,
    simulation_grid: tidy3d.Grid,
    gap: float,
    port: Port | FiberPort | GaussianPort,
) -> tidy3d.Source:
    axis = source.size.index(0)
    center = list(source.center)
    if gap > 0:
        center[axis] += -gap if source.direction == "+" else gap
    else:
        grid_steps = -2 if source.direction == "+" else 2

        grid_boundaries = simulation_grid.boundaries.to_list[axis]
        grid_centers = simulation_grid.centers.to_list[axis]

        before = numpy.argwhere(grid_boundaries < center[axis])
        if len(before) == 0:
            raise RuntimeError(f"Position {center[axis]} is outside of simulation bounds.")

        shifted_index = before.flat[-1] + grid_steps
        if (grid_steps < 0 and shifted_index < 0) or (
            grid_steps > 0 and shifted_index >= len(grid_centers)
        ):
            raise RuntimeError(f"Position {center[axis]} is too close to {'xyz'[axis]} boundary.")

        center[axis] = float(grid_centers[shifted_index])

    if isinstance(source, tidy3d.GaussianBeam):
        input_vector = port.input_vector
        offset = (center[axis] - source.center[axis]) / abs(input_vector[axis])
        center = source.center - input_vector * abs(offset)
        update = {
            "center": center.tolist(),
            "waist_distance": float(source.waist_distance + offset),
        }
        if input_vector[axis] < 1.0:
            update["num_freqs"] = 1
    else:
        update = {"center": center}

    return source.copy(update=update)


def _geometry_key(geom: tidy3d.Geometry) -> tuple[float, float, float, float, str]:
    return (*(x for corner in geom.bounds for x in corner), geom.type)


def _inner_geometry_sort(geom: tidy3d.Geometry) -> tidy3d.Geometry:
    if isinstance(geom, tidy3d.GeometryGroup):
        return tidy3d.GeometryGroup(
            geometries=sorted([_inner_geometry_sort(g) for g in geom.geometries], key=_geometry_key)
        )
    elif isinstance(geom, tidy3d.ClipOperation):
        return tidy3d.ClipOperation(
            operation=geom.operation,
            geometry_a=_inner_geometry_sort(geom.geometry_a),
            geometry_b=_inner_geometry_sort(geom.geometry_b),
        )
    return geom


def _group_by_medium(structures: list[tidy3d.Structure]) -> list[tidy3d.Structure]:
    result = []
    size = len(structures)
    i = 0
    while i < size:
        current_medium = structures[i].medium
        j = i + 1
        while j < size and structures[j].medium == current_medium:
            j += 1
        if j > i + 1:
            geometries = [s.geometry for s in structures[i:j]]
            result.append(
                tidy3d.Structure(
                    geometry=tidy3d.GeometryGroup(geometries=geometries), medium=current_medium
                )
            )
        else:
            result.append(structures[i])
        i = j
    return result


def _transform_xy_bounds(
    bounds: BoundsType,
    translation: tuple[float, float],
    rotation: float,
    scaling: float,
    x_reflection: bool,
) -> BoundsType:
    (xmin, ymin, zmin), (xmax, ymax, zmax) = bounds
    if all(v is None for v in (xmin, ymin, xmax, ymax)):
        return bounds

    if not _is_multiple_of_90(rotation):
        warnings.warn(
            "Bounds are only transformed for rotations that are multiples of 90 degrees. "
            "Resetting bounds to default ((None, None, None), (None, None, None)).",
            RuntimeWarning,
            stacklevel=3,
        )
        return ((None, None, None), (None, None, None))

    y_scaling = (-scaling) if x_reflection else scaling
    if y_scaling < 0:
        ymin, ymax = (
            None if ymax is None else y_scaling * ymax,
            None if ymin is None else y_scaling * ymin,
        )
    elif y_scaling != 1:
        if ymin is not None:
            ymin *= y_scaling
        if ymax is not None:
            ymax *= y_scaling

    if scaling < 0:
        xmin, xmax = (
            None if xmax is None else scaling * xmax,
            None if xmin is None else scaling * xmin,
        )
    elif scaling != 1:
        if xmin is not None:
            xmin *= scaling
        if xmax is not None:
            xmax *= scaling

    match round(rotation / 90) % 4:
        case 1:
            xmin, xmax, ymin, ymax = (
                None if ymax is None else -ymax,
                None if ymin is None else -ymin,
                None if xmin is None else xmin,
                None if xmax is None else xmax,
            )
        case 2:
            xmin, xmax = (
                None if xmax is None else -xmax,
                None if xmin is None else -xmin,
            )
            ymin, ymax = (
                None if ymax is None else -ymax,
                None if ymin is None else -ymin,
            )
        case 3:
            xmin, xmax, ymin, ymax = (
                None if ymin is None else ymin,
                None if ymax is None else ymax,
                None if xmax is None else -xmax,
                None if xmin is None else -xmin,
            )

    if xmin is not None:
        xmin += translation[0]
    if xmax is not None:
        xmax += translation[0]
    if ymin is not None:
        ymin += translation[1]
    if ymax is not None:
        ymax += translation[1]

    return ((xmin, ymin, zmin), (xmax, ymax, zmax))


def _transform_tidy3d_structures(
    obj: tidy3d.Structure,
    translation: tuple[float, float],
    rotation: float,
    scaling: float,
    x_reflection: bool,
) -> Tidy3dBaseModel | None:
    result = obj.geometry
    result = result.scaled(scaling, scaling, 1.0)
    if x_reflection:
        result = result.reflected((0, 1, 0))
    if rotation != 0:
        result = result.rotated(rotation / 180 * numpy.pi, (0, 0, 1))
    if translation[0] != 0.0 or translation[1] != 0.0:
        result = result.translated(translation[0], translation[1], 0.0)
    return obj.copy(update={"geometry": result})


def _transform_tidy3d_monitors(
    obj: MonitorType,
    translation: tuple[float, float],
    rotation: float,
    scaling: float,
    x_reflection: bool,
) -> Tidy3dBaseModel | None:
    x, y, z = obj.center
    dx, dy, dz = obj.size
    x *= scaling
    y *= scaling
    dx *= abs(scaling)
    dy *= abs(scaling)
    if x_reflection:
        y = -y
    if _is_multiple_of_90(rotation):
        match round(rotation / 90) % 4:
            case 1:
                x, y = -y, x
                dx, dy = dy, dx
            case 2:
                x = -x
                y = -y
            case 3:
                x, y = y, -x
                dx, dy = dy, dx
    else:
        theta = rotation / 180 * numpy.pi
        cos_theta = numpy.cos(theta)
        sin_theta = numpy.sin(theta)
        x, y = (x * cos_theta - y * sin_theta, x * sin_theta + y * cos_theta)
        if dx != 0 and dy != 0:
            dx, dy = (
                abs(dx * cos_theta) + abs(dy * sin_theta),
                abs(dx * sin_theta) + abs(dy * cos_theta),
            )
        else:
            warnings.warn(
                f"Expanding planar monitor {obj.name!r} size to inf due to rotation.",
                RuntimeWarning,
                stacklevel=3,
            )
            if round((rotation % 180) / 90) % 2 == 1:
                dx, dy = dy, dx
            if dx != 0:
                dx = tidy3d.inf
            if dy != 0:
                dy = tidy3d.inf
    x += translation[0]
    y += translation[1]
    return obj.copy(update={"center": (x, y, z), "size": (dx, dy, dz)})


def _compose_affine_transform(
    matrix: tuple[tuple[float, float], tuple[float, float], tuple[float, float]],
    translation: tuple[float, float],
    rotation: float,
    scaling: float,
    x_reflection: bool,
) -> tuple[tuple[tuple[float, float], tuple[float, float]], tuple[float, float]]:
    theta = rotation / 180 * numpy.pi
    cos_theta = numpy.cos(theta)
    sin_theta = numpy.sin(theta)
    y_scaling = -scaling if x_reflection else scaling
    step_matrix = (
        (scaling * cos_theta, -y_scaling * sin_theta),
        (scaling * sin_theta, y_scaling * cos_theta),
    )
    matrix = (
        (
            step_matrix[0][0] * matrix[0][0] + step_matrix[0][1] * matrix[1][0],
            step_matrix[0][0] * matrix[0][1] + step_matrix[0][1] * matrix[1][1],
        ),
        (
            step_matrix[1][0] * matrix[0][0] + step_matrix[1][1] * matrix[1][0],
            step_matrix[1][0] * matrix[0][1] + step_matrix[1][1] * matrix[1][1],
        ),
        (
            step_matrix[0][0] * matrix[2][0] + step_matrix[0][1] * matrix[2][1] + translation[0],
            step_matrix[1][0] * matrix[2][0] + step_matrix[1][1] * matrix[2][1] + translation[1],
        ),
    )
    return matrix


def _eme_axis_affine_from_matrix(
    matrix: tuple[tuple[float, float], tuple[float, float], tuple[float, float]],
    old_axis: int,
    atol: float = 1e-9,
) -> tuple[int, float, float]:
    delta = (matrix[0][old_axis], matrix[1][old_axis])
    if abs(delta[0]) <= atol and abs(delta[1]) <= atol:
        raise RuntimeError("Invalid transformation for EME grid: zero scaling on propagation axis.")
    if abs(delta[0]) > atol and abs(delta[1]) > atol:
        raise RuntimeError(
            "Invalid transformation for EME grid: propagation axis is not aligned with x or y."
        )

    new_axis = 0 if abs(delta[0]) > atol else 1
    a = delta[new_axis]
    b = matrix[2][new_axis]
    return new_axis, a, b


def _transform_eme_grid_spec(
    eme_grid_spec: tidy3d.components.eme.grid.EMESubgridType,
    axis: int,
    matrix: tuple[tuple[float, float], tuple[float, float], tuple[float, float]],
) -> tidy3d.components.eme.grid.EMESubgridType:
    candidates = [
        (old_axis, *_eme_axis_affine_from_matrix(matrix, old_axis)) for old_axis in (0, 1)
    ]
    candidates = [(old_axis, a, b) for old_axis, new_axis, a, b in candidates if new_axis == axis]
    if len(candidates) != 1:
        raise RuntimeError(
            "Unable to infer original propagation axis while transforming 'eme_grid_spec'."
        )
    _, a, b = candidates[0]

    def _transform_spec(
        spec: tidy3d.components.eme.grid.EMESubgridType,
    ) -> tidy3d.components.eme.grid.EMESubgridType:
        if isinstance(spec, tidy3d.EMEUniformGrid):
            return spec

        if isinstance(spec, tidy3d.EMEExplicitGrid):
            boundaries = numpy.array(spec.boundaries, dtype=float)
            mode_specs = list(spec.mode_specs)
            boundaries = a * boundaries + b
            if a < 0:
                boundaries = boundaries[::-1]
                mode_specs = mode_specs[::-1]
            return spec.copy(update={"boundaries": boundaries, "mode_specs": mode_specs})

        if isinstance(spec, tidy3d.EMECompositeGrid):
            boundaries = numpy.array(spec.subgrid_boundaries, dtype=float)
            subgrids = [_transform_spec(subgrid) for subgrid in spec.subgrids]
            boundaries = a * boundaries + b
            if a < 0:
                boundaries = boundaries[::-1]
                subgrids = subgrids[::-1]
            return spec.copy(update={"subgrid_boundaries": boundaries, "subgrids": subgrids})

        raise RuntimeError(f"Unsupported EME grid specification type: {type(spec)!r}.")

    return _transform_spec(eme_grid_spec)


class Tidy3DModel(Model):
    """S matrix model based on Tidy3D FDTD calculation.

    Args:
        run_time: Maximal simulation run-time (in seconds) or an instance of
          ``tidy3d.RuntImeSpec``.
        medium: Background medium. If ``None``, the technology default is
          used.
        symmetry: Component symmetries.
        boundary_spec: Simulation boundary specifications (absorber by
          default).
        monitors: Extra field monitors added to the simulation.
        structures: Additional structures included in the simulations.
        grid_spec: Simulation grid specification. A single float can be used
          to specify the ``min_steps_per_wvl`` for an auto grid.
        shutoff: Field decay factor for simulation termination.
        subpixel: Flag controlling subpixel averaging in the simulation
          grid or an instance of ``tidy3d.SubpixelSpec``.
        courant: Courant stability factor.
        port_symmetries: Port symmetries to reduce the number of simulation
          runs. See note below.
        bounds: Bound overrides for the final simulation in the form
          ``((xmin, ymin, zmin), (xmax, ymax, zmax))``. Values set to
          ``None`` are ignored.
        source_gap: Separation between source and monitor representing a
          component port. Defaults to 2 grid cells for optical simulations
          and 1% of the maximum wavelength for electrical ones. The defaults
          are used when this is unset or set to 0.
        simulation_updates: Dictionary of updates applied to all simulations
          generated by this model. See example below.
        verbose: Control solver verbosity.

    If not set, the default grid specification for the component simulations
    is defined based on the wavelengths used in the ``s_matrix`` call.
    Defaults for ``run_time``, ``boundary_spec``, ``shutoff``, ``subpixel``,
    ``courant``, and ``source_gap`` can be defined in a ``"tidy3d"``
    dictionary in :attr:`config.default_kwargs`. Note that the values used
    are the ones available at the time of the ``s_matrix`` or ``start``
    call, not when model is initialized.

    The ``start`` method accepts an ``inputs`` argument as a sequence or set
    of port names to limit the computation to those inputs. Instead of port
    names, ``{port}@{mode}`` specifications are also accepted.

    Note:
        Each item in the ``port_symmetries`` sequence is a tuple of port
        names indicating the port replacements that do not affect the S
        matrix computation. Usually, that means each item is a permutation
        of the *sorted* list of component ports.

        For example, in a Y junction with input "P0" and outputs "P1" and
        "P2" operating in the fundamental TE mode, we can exchange ports
        "P1" and "P2" and the S matrix remains the same, because S₁₀ = S₂₀
        and S₁₁ = S₂₂. This symmetry is represented as the sequence
        ``("P0", "P2", "P1")``, which exchange "P1" anf "P2" with respect
        to the *sorted* port list "P0", "P1", "P2". We could also use
        indices instead of port names to the same effect: ``(0, 2, 1)``.

        It is also possible to represent S matrix symmetries for individual
        elements and with correction factors. This form requires a
        reference element, a mapped element, and a multiplication factor:
        ``((src, dst1), (src2, dst2), c)``, which translates into
        ``S[src2@i, dst2@j] = c[i,j] * S[src1@i, dst1@j]`` for all mode
        indices ``i`` and ``j`` supported by the source and destination
        ports, respectively. Note that the multiplicative factor is an array
        so that each mode can be phase-compensated according to its field
        symmetry (if ``c`` is an scalar, all modes use the same value).

    Example:
        Keys in ``simulation_updates`` specify a path to the value that
        will be updated using a ``'/'`` as separator, analogously to the
        ``path`` argument in the ``updated_copy`` method from ``tidy3d``
        objects. For indexing into a tuple or list, an integer value is
        used. The first part of the path can be an input in the form
        ``port@mode`` to specify that the update should be applied to
        a that simulation only.

        >>> simulation_updates = {
        ...     "P0@0/grid_spec/grid_x/max_scale": 1.3,
        ...     "boundary_spec/z/plus": td.PML(),
        ...     "center/2": 0.0,
        ... }
        >>> model = pf.Tidy3DModel(simulation_updates=simulation_updates)

    See also:
        - `Tidy3D Model guide <../guides/Tidy3D_Model.ipynb>`__
        - `Y splitter example <../examples/Y_Splitter.ipynb>`__
    """

    def __init__(
        self,
        run_time: tidy3d.RunTimeSpec | float | None = None,
        medium: Medium | None = None,
        symmetry: SymmetryType = (0, 0, 0),
        boundary_spec: tidy3d.BoundarySpec | None = None,
        monitors: Sequence[MonitorType] = (),
        structures: Sequence[tidy3d.Structure] = (),
        grid_spec: PositiveFloat | tidy3d.GridSpec | None = None,
        shutoff: PositiveFloat | None = None,
        subpixel: SubpixelType | None = None,
        courant: Fraction | None = None,
        port_symmetries: PortSymmetryType = (),
        bounds: BoundsType = ((None, None, None), (None, None, None)),
        source_gap: NonNegativeFloat | None = None,
        simulation_updates: dict[str, object] | None = None,
        verbose: bool = True,
    ) -> None:
        super().__init__(
            run_time=run_time,
            medium=medium,
            symmetry=symmetry,
            boundary_spec=boundary_spec,
            monitors=monitors,
            structures=structures,
            grid_spec=grid_spec,
            shutoff=shutoff,
            subpixel=subpixel,
            courant=courant,
            port_symmetries=port_symmetries,
            bounds=bounds,
            source_gap=source_gap,
            simulation_updates=simulation_updates,
            verbose=verbose,
        )
        self.run_time = run_time
        self.medium = medium
        self.symmetry = symmetry
        self.boundary_spec = boundary_spec
        self.monitors = monitors
        self.structures = structures
        self.grid_spec = grid_spec
        self.shutoff = shutoff
        self.subpixel = subpixel
        self.courant = courant
        self.port_symmetries = port_symmetries
        self.bounds = bounds
        self.source_gap = source_gap
        self.simulation_updates = {} if simulation_updates is None else simulation_updates
        self.verbose = verbose

    def transform(
        self,
        translation: Sequence[float] | complex = (0, 0),
        rotation: float = 0,
        scaling: float = 1,
        x_reflection: bool = False,
    ) -> "Tidy3DModel":
        if isinstance(translation, complex):
            translation = (translation.real, translation.imag)

        self.parametric_kwargs["bounds"] = self.bounds = _transform_xy_bounds(
            self.bounds, translation, rotation, scaling, x_reflection
        )
        self.parametric_kwargs["structures"] = self.structures = tuple(
            _transform_tidy3d_structures(s, translation, rotation, scaling, x_reflection)
            for s in self.structures
        )
        self.parametric_kwargs["monitors"] = self.monitors = tuple(
            _transform_tidy3d_monitors(m, translation, rotation, scaling, x_reflection)
            for m in self.monitors
        )

        if self.symmetry[0] != 0 or self.symmetry[1] != 0:
            if _is_multiple_of_90(rotation):
                if round(rotation // 90) % 2 == 1:
                    self.parametric_kwargs["symmetry"] = self.symmetry = (
                        self.symmetry[1],
                        self.symmetry[0],
                        self.symmetry[2],
                    )
            else:
                warnings.warn(
                    "Tidy3DModel 'symmetry' is not transformed for arbitrary rotations. "
                    "Resetting 'symmetry' in the xy plane.",
                    RuntimeWarning,
                    stacklevel=2,
                )
                self.parametric_kwargs["symmetry"] = self.symmetry = (0, 0, self.symmetry[2])

        if not _angles_equal(rotation, 0) or scaling != 1 or x_reflection:
            if isinstance(self.grid_spec, tidy3d.GridSpec):
                warnings.warn(
                    "Tidy3DModel 'grid_spec' is not transformed when it is a tidy3d.GridSpec. "
                    "Resetting 'grid_spec' to default None.",
                    RuntimeWarning,
                    stacklevel=2,
                )
                self.parametric_kwargs["grid_spec"] = self.grid_spec = None
            if self.boundary_spec is not None:
                warnings.warn(
                    "Tidy3DModel 'boundary_spec' is not transformed. "
                    "Resetting 'boundary_spec' to default None.",
                    RuntimeWarning,
                    stacklevel=2,
                )
                self.parametric_kwargs["boundary_spec"] = self.boundary_spec = None
            if len(self.simulation_updates) > 0:
                warnings.warn(
                    "Tidy3DModel 'simulation_updates' are not transformed. "
                    "Resetting 'simulation_updates' to default empty dictionary.",
                    RuntimeWarning,
                    stacklevel=2,
                )
                self.parametric_kwargs["simulation_updates"] = self.simulation_updates = {}

        return self

    def autograd_smatrix(
        self,
        *,
        component: Component,
        traced_params: numpy.ndarray,
        frequencies: Sequence[float],
        model_for_params: Callable[[numpy.ndarray], tuple[Component, Model]],
        show_progress: bool = True,
        model_kwargs: dict[str, Any] | None = None,
    ) -> AutogradSMatrix:
        """Compute autograd-compatible S-matrix (not yet implemented)."""

        raise NotImplementedError(
            "Tidy3DModel does not yet support autograd-based S-matrix computation."
        )

    def _process_port_symmetries(
        self, ports: dict[str, Port | FiberPort | GaussianPort], component_name: str
    ) -> tuple[set[str], list[PerElementMap]]:
        """Return the required simulation sources and mappings for a component."""
        port_names = sorted(ports.keys())
        element_mappings = []
        # required_sources = set(port_names)

        for port_symmetry in self.port_symmetries:
            # ImplicitMap
            if all(isinstance(x, (str, int)) for x in port_symmetry):
                equiv = [
                    port_names[x] if not isinstance(x, str) and x < len(port_names) else x
                    for x in port_symmetry
                ]
                pairs = []
                for src1, src2 in zip(port_names, equiv, strict=False):
                    src1_port = ports.get(src1)
                    src2_port = ports.get(src2)
                    if src1_port is None or src2_port is None:
                        missing_port = src1 if src1_port is None else src2
                        warnings.warn(
                            f"Port {missing_port} specified in 'port_symmetries' does not exist in "
                            f"component {component_name} or is defined for a different frequency "
                            f"range.",
                            stacklevel=3,
                        )
                        continue
                    if src1_port.num_modes != src2_port.num_modes:
                        warnings.warn(
                            f"Port pair {src1} and {src2} specified in 'port_symmetries' support "
                            f"different numbers of modes and will be ignored.",
                            stacklevel=3,
                        )
                        continue
                    pairs.append((src1, src2, src1_port.num_modes))
                element_mappings.extend(
                    (
                        ((src1, dst1), (src2, dst2), numpy.ones((src_modes, dst_modes)))
                        for src1, src2, src_modes in pairs
                        for dst1, dst2, dst_modes in pairs
                        if (src1, dst1) != (src2, dst2)
                    )
                )

            elif (
                len(port_symmetry) == 3
                and isinstance(port_symmetry[0], str)
                and isinstance(port_symmetry[1], str)
                and isinstance(port_symmetry[2], dict)
            ):
                # ExplictMap
                src1, src2, maps = port_symmetry
                if src1 == src2:
                    continue
                src1_port = ports.get(src1)
                src2_port = ports.get(src2)
                if src1_port is None or src2_port is None:
                    missing_port = src1 if src1_port is None else src2
                    warnings.warn(
                        f"Port {missing_port} specified in 'port_symmetries' does not exist in "
                        f"component {component_name} or is defined for a different frequency "
                        f"range.",
                        stacklevel=3,
                    )
                    continue
                src_modes = src1_port.num_modes
                if src_modes != src2_port.num_modes:
                    warnings.warn(
                        f"Port pair {src1} and {src2} specified in 'port_symmetries' support "
                        f"different numbers of modes and will be ignored.",
                        stacklevel=3,
                    )
                    continue
                element_mappings.append(
                    ((src1, src1), (src2, src2), numpy.ones((src_modes, src_modes)))
                )

                for dst1, dst1_port in ports.items():
                    dst2 = maps.get(dst1)
                    if dst2 is None:
                        continue
                    dst2_port = ports.get(dst2)
                    if dst2_port is None:
                        warnings.warn(
                            f"Port {dst2} specified in 'port_symmetries' does not exist in "
                            f"component {component_name} or is defined for a different frequency "
                            f"range.",
                            stacklevel=3,
                        )
                        continue
                    dst_modes = dst1_port.num_modes
                    if dst_modes != dst2_port.num_modes:
                        warnings.warn(
                            f"Port pair {dst1} and {dst2} specified in 'port_symmetries' support "
                            f"different numbers of modes and will be ignored.",
                            stacklevel=3,
                        )
                        continue
                    element_mappings.append(
                        ((src1, dst1), (src2, dst2), numpy.ones((src_modes, dst_modes)))
                    )

            elif (
                len(port_symmetry) == 3
                and isinstance(port_symmetry[0], (tuple, list))
                and len(port_symmetry[0]) == 2
                and isinstance(port_symmetry[1], (tuple, list))
                and len(port_symmetry[1]) == 2
                and all(isinstance(x, str) for p in port_symmetry[:2] for x in p)
            ):
                # PerElementMap
                (src1, dst1), (src2, dst2), factor = port_symmetry
                if (src1, dst1) == (src2, dst2):
                    continue

                src1_port = ports.get(src1)
                src2_port = ports.get(src2)
                dst1_port = ports.get(dst1)
                dst2_port = ports.get(dst2)
                if src1_port is None or src2_port is None or dst1_port is None or dst2_port is None:
                    missing_port = (
                        src1
                        if src1_port is None
                        else (src2 if src2_port is None else (dst1 if dst1_port is None else dst2))
                    )
                    warnings.warn(
                        f"Port {missing_port} specified in 'port_symmetries' does not exist in "
                        f"component {component_name} or is defined for a different frequency "
                        f"range.",
                        stacklevel=3,
                    )
                    continue
                if src1_port.num_modes != src2_port.num_modes:
                    warnings.warn(
                        f"Port pair {src1} and {src2} specified in 'port_symmetries' support "
                        f"different numbers of modes and will be ignored.",
                        stacklevel=3,
                    )
                    continue
                if dst1_port.num_modes != dst2_port.num_modes:
                    warnings.warn(
                        f"Port pair {dst1} and {dst2} specified in 'port_symmetries' support "
                        f"different numbers of modes and will be ignored.",
                        stacklevel=3,
                    )
                    continue
                shape = src1_port.num_modes, dst1_port.num_modes
                if numpy.ndim(factor) == 0:
                    factor = numpy.full(shape, factor)
                else:
                    factor = numpy.array(factor)
                    if factor.shape != shape:
                        warnings.warn(
                            f"Mapping ({src1}, {dst1}) to ({src2}, {dst2}) in 'port_symmetries' "
                            f"requires factor shape {shape}. Found {factor.shape}.",
                            stacklevel=3,
                        )
                        continue
                element_mappings.append(((src1, dst1), (src2, dst2), factor))

            else:
                warnings.warn(
                    f"Port symmetry specification {port_symmetry!r} does not match any of the "
                    f"required formats and will be ignored. Accepted formats are 'tuple[str]', "
                    f"'tuple[str, str, dict[str, str]]', and "
                    f"'tuple[tuple[str, str], tuple[str, str], complex | ndarray]'.",
                    stacklevel=3,
                )

        # Rank source ports by likelihood of being a source for most mappings and being less likely
        # to be a mapped source
        ranked = sorted(
            port_names,
            key=lambda p: (
                len([x for x in element_mappings if x[0][0] == p])
                - len([x for x in element_mappings if x[1][0] == p]),
                p,
            ),
        )

        retry = False
        required_sources = set(port_names)
        required_by_mapping = set()

        # Start looking for mapped sources from the most likely
        for src in reversed(ranked):
            if src in required_by_mapping:
                continue
            mapped = {}
            for (src1, _), (src2, dst2), _ in element_mappings:
                if src2 == src and src1 != src:
                    mapped[src1] = mapped.get(src1, set())
                    mapped[src1].add(dst2)

            # Look for a single source that can be used to map this src port using the rank
            src_options = [x for x in ranked if x in required_by_mapping]
            src_options.extend(x for x in ranked if x in mapped and x not in src_options)
            for required_src in src_options:
                if required_src in mapped and len(mapped[required_src]) == len(port_names):
                    required_sources.remove(src)
                    required_by_mapping.add(required_src)
                    break
            else:
                # We may be able to map this port using multiple sources, but let's
                # finish other options before using this wasteful alternative
                retry = retry or len(set().union(*mapped.values())) == len(port_names)

        if retry:
            for src in reversed(ranked):
                if src in required_by_mapping:
                    continue
                mapped = {}
                for (src1, _), (src2, dst2), _ in element_mappings:
                    if src2 == src and src1 != src:
                        mapped[src1] = mapped.get(src1, set())
                        mapped[src1].add(dst2)
                if len(set().union(*mapped.values())) == len(port_names):
                    required_sources.remove(src)
                    required_by_mapping.update(mapped.keys())

        return required_sources, element_mappings

    def get_simulations(
        self, component: Component, frequencies: Sequence[float], sources: Sequence[str] = ()
    ) -> dict[str, tidy3d.Simulation] | tidy3d.Simulation:
        """Return all simulations required by this component.

        Args:
            component: Instance of Component for calculation.
            frequencies: Sequence of frequencies for the simulation.
            sources: Port names to be used as sources (``{port}@{mode}``
              specifications are also accepted). If empty, use all required
              sources based on this model's port symmetries.

        Returns:
            Dictionary of ``tidy3d.Simulation`` indexed by source name or
            a single simulation if the component has no ports.
        """
        defaults = config.default_kwargs.get("tidy3d", {})

        frequencies = numpy.array(frequencies, dtype=float, ndmin=1)
        fmin = frequencies.min()
        fmax = frequencies.max()
        fmed = 0.5 * (fmin + fmax)
        max_wavelength = C_0 / fmin
        min_wavelength = C_0 / fmax

        classification = frequency_classification(frequencies)

        component_ports = component.select_ports(classification)

        technology = component.technology
        original_extrusions = technology.extrusion_specs

        # Make sure we reset technology to its original state
        try:
            zmin = None
            zmax = None
            if len(component_ports) > 0 and all(
                isinstance(p, Port) for p in component_ports.values()
            ):
                # zmin and zmax can be later expanded due to added PML gaps, so we keep extrusions
                # upt to some limit outside them. The largest port height is a safe default.
                port_height = max(
                    p.spec.limits[1] - p.spec.limits[0] for p in component_ports.values()
                )
                if self.bounds[0][2] is None:
                    zmin = min(p.spec.limits[0] for p in component_ports.values())
                    technology.extrusion_specs = [
                        e for e in technology.extrusion_specs if e.limits[1] >= zmin - port_height
                    ]
                if self.bounds[1][2] is None:
                    zmax = max(p.spec.limits[1] for p in component_ports.values())
                    technology.extrusion_specs = [
                        e for e in technology.extrusion_specs if e.limits[0] <= zmax + port_height
                    ]

            use_angle_rotation = _isotropic_uniform(technology, classification)

            medium = (
                technology.get_background_medium(classification)
                if self.medium is None
                else self.medium
            )
            if isinstance(medium, tidy3d.MultiPhysicsMedium):
                # TODO: Remove this once support for MultiPhysicsMedium is added for Scene
                medium = medium.optical

            layer_refinement = _layer_steps_from_refinement(config.default_mesh_refinement)
            if isinstance(self.grid_spec, tidy3d.GridSpec):
                grid_spec = self.grid_spec
                mesh_refinement = config.default_mesh_refinement
            else:
                mesh_refinement = (
                    config.default_mesh_refinement if self.grid_spec is None else self.grid_spec
                )
                layer_refinement = _layer_steps_from_refinement(mesh_refinement)
                grid_spec = tidy3d.GridSpec.auto(
                    wavelength=min_wavelength,
                    min_steps_per_wvl=mesh_refinement,
                    min_steps_per_sim_size=mesh_refinement,
                )

            extrusion_tolerance = 0
            if isinstance(grid_spec.grid_z, tidy3d.AutoGrid):
                extrusion_specs = technology.extrusion_specs
                if classification == "optical":
                    grid_lda = (
                        min_wavelength if grid_spec.wavelength is None else grid_spec.wavelength
                    )
                    temp_structures = [
                        tidy3d.Structure(
                            geometry=tidy3d.Box(size=(1, 1, 1)),
                            medium=spec.get_medium(classification),
                        )
                        for spec in extrusion_specs
                    ]
                    temp_scene = tidy3d.Scene(medium=medium, structures=temp_structures)
                    _, eps_max = temp_scene.eps_bounds(fmed)
                    extrusion_tolerance = grid_lda / (
                        grid_spec.grid_z.min_steps_per_wvl * eps_max**0.5
                    )
                elif len(extrusion_specs) > 0:
                    for spec in technology.extrusion_specs:
                        t = spec.limits[1] - spec.limits[0]
                        if t > 0 and (extrusion_tolerance == 0 or extrusion_tolerance > t):
                            extrusion_tolerance = t
                    extrusion_tolerance = max(
                        config.tolerance, extrusion_tolerance / layer_refinement
                    )
            elif isinstance(grid_spec.grid_z, tidy3d.components.grid.grid_spec.AbstractAutoGrid):
                extrusion_tolerance = grid_spec.grid_z._dl_min
            elif isinstance(grid_spec.grid_z, tidy3d.UniformGrid):
                extrusion_tolerance = grid_spec.grid_z.dl
            elif isinstance(grid_spec.grid_z, tidy3d.CustomGrid) and len(grid_spec.grid_z.dl) > 0:
                extrusion_tolerance = min(grid_spec.grid_z.dl)

            boundary_spec = (
                defaults.get(
                    "boundary_spec",
                    tidy3d.BoundarySpec.all_sides(boundary=tidy3d.Absorber(num_layers=70)),
                )
                if self.boundary_spec is None
                else self.boundary_spec
            )

            extrusion_layers = technology.extrusion_layers()
            (xmin, ymin), (xmax, ymax) = component.bounds(
                include_labels=False, layers=extrusion_layers
            )
            max_bounds = max(xmax - xmin, ymax - ymin)

            source_gap = (
                defaults.get("source_gap", 0) if self.source_gap is None else self.source_gap
            )
            if source_gap < 0:
                raise RuntimeError("'source_gap' cannot be negative.")

            if classification == "optical":
                pml_gap = (
                    (0.6 * max_wavelength)
                    if source_gap == 0
                    else (0.5 * max_wavelength + source_gap)
                )
                port_extension = 2 * pml_gap + max_bounds
            else:
                if source_gap == 0:
                    source_gap = max_wavelength / 100
                grid_scale = max_bounds / mesh_refinement
                pml_gap = max(max_wavelength / 100, 3 * grid_scale) + source_gap
                port_extension = pml_gap + 200 * grid_scale

                if any(
                    isinstance(p, Port) and p.bend_radius != 0 for p in component_ports.values()
                ):
                    warnings.warn(
                        "Electrical ports with non-zero bending radius can result in inaccurate "
                        "mode normalization, leading to invalid S matrices.",
                        stacklevel=2,
                    )

            for port in component_ports.values():
                _, size, *_ = (
                    port._axis_aligned_properties()
                    if isinstance(port, (Port, FiberPort))
                    else port._axis_aligned_properties(frequencies, 1.0)
                )
                port_extension = max(port_extension, size[0], size[1])

            # Bounds override
            delta = port_extension - 2 * pml_gap
            if self.bounds[0][0] is not None and self.bounds[0][0] < xmin - delta:
                port_extension = xmin - self.bounds[0][0] + 2 * pml_gap
            if self.bounds[0][1] is not None and self.bounds[0][1] < ymin - delta:
                port_extension = ymin - self.bounds[0][1] + 2 * pml_gap
            if self.bounds[1][0] is not None and self.bounds[1][0] > xmax + delta:
                port_extension = self.bounds[1][0] - xmax + 2 * pml_gap
            if self.bounds[1][1] is not None and self.bounds[1][1] > ymax + delta:
                port_extension = self.bounds[1][1] - ymax + 2 * pml_gap

            used_extrusions = []
            structures = [
                s.to_tidy3d()
                for s in component.extrude(
                    port_extension,
                    extrusion_tolerance=extrusion_tolerance,
                    classification=classification,
                    used_extrusions=used_extrusions,
                )
            ]

        finally:
            technology.extrusion_specs = original_extrusions

        # Sort to improve caching, but don't reorder different media
        i = 0
        while i < len(structures):
            current_medium = structures[i].medium
            j = i + 1
            while j < len(structures) and structures[j].medium == current_medium:
                j += 1
            # Even if j == i + 1 we want to sort internal geometries
            structures[i:j] = (
                tidy3d.Structure(geometry=geometry, medium=current_medium)
                for geometry in sorted(
                    [_inner_geometry_sort(s.geometry) for s in structures[i:j]], key=_geometry_key
                )
            )
            i = j

        port_structures = [
            structure
            for _, port in sorted(component_ports.items())
            if isinstance(port, FiberPort)
            for structure in port.to_tidy3d_structures()
        ]
        all_structures = structures + port_structures + list(self.structures)

        if len(sources) == 0:
            sources, _ = self._process_port_symmetries(component_ports, component.name)

        port_monitors = []
        port_sources = {}
        unused_sources = []
        grid_snapping_points = []
        for name, port in component_ports.items():
            if isinstance(port, (Port, FiberPort)):
                monitor = port.to_tidy3d_monitor(
                    frequencies, name=name, use_angle_rotation=use_angle_rotation
                )
                unused = True
                for mode_index in range(port.num_modes):
                    port_mode = f"{name}@{mode_index}"
                    if name in sources or port_mode in sources:
                        unused = False
                        port_sources[port_mode] = port.to_tidy3d_source(
                            frequencies,
                            name=name,
                            mode_index=mode_index,
                            use_angle_rotation=use_angle_rotation,
                        )
                if unused:
                    unused_sources.append(
                        port.to_tidy3d_source(
                            frequencies,
                            name=name,
                            mode_index=0,
                            use_angle_rotation=use_angle_rotation,
                        )
                    )

            else:
                epsilon_r = _get_epsilon(port.center, all_structures, medium, frequencies)
                monitor = port.to_tidy3d_monitor(frequencies, name=name, medium=epsilon_r)
                port_mode = f"{name}@0"
                if name in sources or port_mode in sources:
                    port_sources[port_mode] = port.to_tidy3d_source(
                        frequencies, name=name, medium=epsilon_r
                    )
                else:
                    unused_sources.append(
                        port.to_tidy3d_source(frequencies, name=name, medium=epsilon_r)
                    )

            port_monitors.append(monitor)

            i = monitor.size.index(0)
            p = [None, None, None]
            p[i] = monitor.center[i]
            grid_snapping_points.append(tuple(p))

        # Add layer refinements based on extruded layers and ports
        if classification == "electrical" and not isinstance(self.grid_spec, tidy3d.GridSpec):
            layer_refinement_specs = [
                _make_layer_refinement_spec(spec, layer_refinement, classification)
                for spec in sorted(
                    used_extrusions, key=lambda e: e.limits[1] - e.limits[0], reverse=True
                )
            ]
            grid_1d_update = {"max_scale": _auto_scale_from_refinement(mesh_refinement)}
            grid_spec = grid_spec.copy(
                update={
                    "snapping_points": grid_snapping_points,
                    "layer_refinement_specs": layer_refinement_specs,
                    "grid_x": grid_spec.grid_x.copy(update=grid_1d_update),
                    "grid_y": grid_spec.grid_y.copy(update=grid_1d_update),
                    "grid_z": grid_spec.grid_z.copy(update=grid_1d_update),
                }
            )

        # Simulation bounds
        # If zmin/zmax were pre-defined, do not set them based on geometry
        if zmin is None:
            zmin = Z_MAX
            for s in structures:
                for lim in s.geometry.bounds:
                    if -Z_MAX <= lim[2] <= Z_MAX:
                        zmin = min(zmin, lim[2])
        if zmax is None:
            zmax = -Z_MAX
            for s in structures:
                for lim in s.geometry.bounds:
                    if -Z_MAX <= lim[2] <= Z_MAX:
                        zmax = max(zmax, lim[2])
        for monitor in port_monitors:
            xmin = min(xmin, monitor.bounds[0][0])
            ymin = min(ymin, monitor.bounds[0][1])
            zmin = min(zmin, monitor.bounds[0][2])
            xmax = max(xmax, monitor.bounds[1][0])
            ymax = max(ymax, monitor.bounds[1][1])
            zmax = max(zmax, monitor.bounds[1][2])
        if zmin > zmax:
            raise RuntimeError(
                "Unable to determine z-limits for simulation. Please set Tidy3DModel bounds "
                "manually in the z axis."
            )

        if isinstance(boundary_spec.x.minus, (tidy3d.PML, tidy3d.StablePML)):
            xmin -= pml_gap
        if isinstance(boundary_spec.x.plus, (tidy3d.PML, tidy3d.StablePML)):
            xmax += pml_gap
        if isinstance(boundary_spec.y.minus, (tidy3d.PML, tidy3d.StablePML)):
            ymin -= pml_gap
        if isinstance(boundary_spec.y.plus, (tidy3d.PML, tidy3d.StablePML)):
            ymax += pml_gap
        if isinstance(boundary_spec.z.minus, (tidy3d.PML, tidy3d.StablePML)):
            zmin -= pml_gap
        if isinstance(boundary_spec.z.plus, (tidy3d.PML, tidy3d.StablePML)):
            zmax += pml_gap

        bounds = numpy.array(((xmin, ymin, zmin), (xmax, ymax, zmax)))

        center = tuple(snap_to_grid(v) / 2 for v in bounds[0] + bounds[1])

        # Include margin for port sources
        size = tuple(snap_to_grid(v + pml_gap) for v in bounds[1] - bounds[0])

        bounding_box = tidy3d.Box(center=center, size=size)

        all_structures = [s for s in all_structures if bounding_box.intersects(s.geometry)]
        if len(all_structures) >= GROUPING_THRESHOLD:
            all_structures = _group_by_medium(all_structures)

        shutoff = defaults.get("shutoff", 1.0e-5) if self.shutoff is None else self.shutoff
        subpixel = defaults.get("subpixel", True) if self.subpixel is None else self.subpixel
        courant = defaults.get("courant", 0.99) if self.courant is None else self.courant

        base_simulation = tidy3d.Simulation(
            center=center,
            size=size,
            run_time=1e-12 if self.run_time is None else self.run_time,
            medium=medium,
            symmetry=(0, 0, 0),
            structures=all_structures,
            boundary_spec=boundary_spec,
            monitors=list(self.monitors) + port_monitors,
            grid_spec=grid_spec,
            shutoff=shutoff,
            subpixel=subpixel,
            courant=courant,
        )

        # Update keywords from base simulation
        update = {"symmetry": self.symmetry}

        if len(port_sources) == 0:
            return base_simulation.copy(update=update)

        # RunTimeSpec can only be used when sources are defined
        if self.run_time is None:
            update["run_time"] = defaults.get(
                "run_time", tidy3d.RunTimeSpec(quality_factor=5.0, source_factor=3.0)
            )

        # Use base grid to shift sources and update base simulation
        grid = base_simulation.grid

        delta_factor = 3 if source_gap == 0 else 2

        for name in port_sources:
            unused_source = port_sources[name]
            source = _source_shift(
                unused_source, grid, source_gap, component_ports[unused_source.name]
            )
            port_sources[name] = source

            # Make sure we have at least 2 grid cells between monitor and source
            i = source.size.index(0)
            p = [None, None, None]
            p[i] = source.center[i]
            grid_snapping_points.append(tuple(p))
            p[i] = (p[i] + unused_source.center[i]) / 2
            grid_snapping_points.append(tuple(p))

            delta = delta_factor * (xmin - source.bounds[0][0])
            if delta > 0:
                xmin -= delta
            delta = delta_factor * (source.bounds[1][0] - xmax)
            if delta > 0:
                xmax += delta

            delta = delta_factor * (ymin - source.bounds[0][1])
            if delta > 0:
                ymin -= delta
            delta = delta_factor * (source.bounds[1][1] - ymax)
            if delta > 0:
                ymax += delta

            delta = delta_factor * (zmin - source.bounds[0][2])
            if delta > 0:
                zmin -= delta
            delta = delta_factor * (source.bounds[1][2] - zmax)
            if delta > 0:
                zmax += delta

        for unused_source in unused_sources:
            source = _source_shift(
                unused_source, grid, source_gap, component_ports[unused_source.name]
            )

            # Make sure we have at least 2 grid cells between monitor and source
            i = source.size.index(0)
            p = [None, None, None]
            p[i] = source.center[i]
            grid_snapping_points.append(tuple(p))
            p[i] = (p[i] + unused_source.center[i]) / 2
            grid_snapping_points.append(tuple(p))

            delta = delta_factor * (xmin - source.bounds[0][0])
            if delta > 0:
                xmin -= delta
            delta = delta_factor * (source.bounds[1][0] - xmax)
            if delta > 0:
                xmax += delta

            delta = delta_factor * (ymin - source.bounds[0][1])
            if delta > 0:
                ymin -= delta
            delta = delta_factor * (source.bounds[1][1] - ymax)
            if delta > 0:
                ymax += delta

            delta = delta_factor * (zmin - source.bounds[0][2])
            if delta > 0:
                zmin -= delta
            delta = delta_factor * (source.bounds[1][2] - zmax)
            if delta > 0:
                zmax += delta

        if classification == "electrical" and not isinstance(self.grid_spec, tidy3d.GridSpec):
            update["grid_spec"] = grid_spec.copy(update={"snapping_points": grid_snapping_points})

        for monitor in port_monitors:
            if xmin >= monitor.bounds[0][0]:
                xmin -= config.grid
            if ymin >= monitor.bounds[0][1]:
                ymin -= config.grid
            if zmin >= monitor.bounds[0][2]:
                zmin -= config.grid
            if xmax <= monitor.bounds[1][0]:
                xmax += config.grid
            if ymax <= monitor.bounds[1][1]:
                ymax += config.grid
            if zmax <= monitor.bounds[1][2]:
                zmax += config.grid

        bounds = numpy.array(((xmin, ymin, zmin), (xmax, ymax, zmax)))

        # Bounds override
        for i in range(3):
            if self.bounds[0][i] is not None:
                bounds[0, i] = self.bounds[0][i]
            if self.bounds[1][i] is not None:
                bounds[1, i] = self.bounds[1][i]

        update["center"] = tuple(snap_to_grid(v) / 2 for v in bounds[0] + bounds[1])
        update["size"] = tuple(snap_to_grid(v) for v in bounds[1] - bounds[0])

        bounding_box = tidy3d.Box(center=update["center"], size=update["size"])

        update["structures"] = [s for s in all_structures if bounding_box.intersects(s.geometry)]

        if self.boundary_spec is None and any(s == 0 for s in size):
            axis = "yxz"[size.index(0)]
            update["boundary_spec"] = boundary_spec.copy(
                update={axis: tidy3d.Boundary(minus=tidy3d.Periodic(), plus=tidy3d.Periodic())}
            )

        # Only the first simulation will store mode field data, if necessary due to mode remaping
        mode_remap = tuple(self.symmetry) != (0, 0, 0) or any(
            not _nominal_mode_order(m.mode_spec)
            for m in port_monitors
            if isinstance(m, tidy3d.ModeMonitor)
        )
        if not mode_remap:
            update["monitors"] = list(self.monitors) + [
                mon.copy(update={"store_fields_direction": None})
                if isinstance(mon, tidy3d.ModeMonitor)
                else mon
                for mon in port_monitors
            ]

        simulations = {}
        for name in sorted(port_sources):
            update["sources"] = [port_sources[name]]
            simulations[name] = base_simulation.copy(update=update)
            if mode_remap:
                # Mode fields required only in 1 simulation
                mode_remap = False
                update["monitors"] = list(self.monitors) + [
                    mon.copy(update={"store_fields_direction": None})
                    if isinstance(mon, tidy3d.ModeMonitor)
                    else mon
                    for mon in port_monitors
                ]

        for key, value in self.simulation_updates.items():
            path = key.split("/")
            if "@" in path[0]:
                sim = simulations.get(path[0])
                if sim is not None:
                    simulations[path[0]] = _updated_tidy3d(sim, path[1:], value)
            else:
                simulations = {
                    name: _updated_tidy3d(sim, path, value) for name, sim in simulations.items()
                }

        return simulations

    @cache_s_matrix
    def start(
        self,
        component: Component,
        frequencies: Sequence[float],
        *,
        inputs: Sequence[str] = (),
        verbose: bool | None = None,
        cost_estimation: bool = False,
        **kwargs: object,
    ) -> _Tidy3DModelRunner:
        """Start computing the S matrix response from a component.

        Args:
            component: Component from which to compute the S matrix.
            frequencies: Sequence of frequencies at which to perform the
              computation.
            inputs: Limit calculation to specific inputs. Each item must be
              a port name or a ``{port}@{mode}`` specification.
            verbose: If set, overrides the model's `verbose` attribute.
            cost_estimation: If set, simulations are uploaded, but not
              executed. S matrix will *not* be computed.
            **kwargs: Unused.

        Returns:
            Result object with attributes ``status`` and ``s_matrix``.

        Important:
            When using geometry symmetry, the mode numbering in ``inputs``
            is relative to the solver run *with the symmetry applied*, not
            the mode number presented in the final S matrix.
        """
        frequencies = numpy.array(frequencies, dtype=float, ndmin=1)
        classification = frequency_classification(frequencies)
        inputs = tuple(inputs)
        component_ports = {
            name: port.copy(True) for name, port in component.select_ports(classification).items()
        }
        if verbose is None:
            verbose = self.verbose

        required_sources, element_mappings = self._process_port_symmetries(
            component_ports, component.name
        )
        if len(inputs) > 0:
            required_sources = inputs

        simulations = self.get_simulations(component, frequencies, required_sources)
        if not isinstance(simulations, dict):
            raise RuntimeError(
                f"Tidy3DModel found no source ports for {classification} frequencies. Please make "
                f"sure that component '{component.name}' has {classification} ports."
            )

        sim = next(iter(simulations.values()))
        port_epsilon = {
            name: _get_epsilon(port.center, sim.structures, sim.medium, frequencies)
            for name, port in component_ports.items()
            if not isinstance(port, Port)
        }

        folder_name = _filename_cleanup(component.name)
        if len(folder_name) == 0:
            folder_name = "default"

        return _Tidy3DModelRunner(
            frequencies=frequencies,
            simulations=simulations,
            ports=component_ports,
            port_epsilon=port_epsilon,
            element_mappings=element_mappings,
            folder_name=folder_name,
            cost_estimation=cost_estimation,
            verbose=verbose,
        )

    def batch_data(
        self,
        component: Component,
        frequencies: Sequence[float],
        *,
        inputs: Sequence[str] = (),
        verbose: bool | None = None,
        show_progress: bool = True,
        **kwargs: object,
    ) -> object:
        """Return the Tidy3D BatchData for a given component.

        Uses the same arguments as :func:`Tidy3DModel.start`.
        """
        from tidy3d.web import BatchData
        from tidy3d.web.api.webapi import restore_simulation_if_cached

        if verbose is None:
            verbose = self.verbose

        if show_progress:
            print("Starting…", end="\r", flush=True)

        runner = self.start(component, frequencies, inputs=inputs, verbose=verbose, **kwargs)

        progress_chars = "-\\|/"
        i = 0
        while True:
            status = runner.status
            message = status["message"]
            if message == "success":
                if show_progress:
                    print("Progress: 100% ", end="\n", flush=True)
                task_ids = {}
                task_paths = {}
                for k, r in runner.runners.items():
                    path, task_id = restore_simulation_if_cached(r.simulation, verbose=verbose)
                    if path is not None and task_id is not None:
                        task_paths[k] = str(path)
                        task_ids[k] = task_id
                if len(task_ids) < len(runner.runners):
                    warnings.warn(
                        f"Missing cached data for {len(runner.runners) - len(task_ids)} tasks. "
                        "Please make sure tidy3d caching is enabled and working correctly.",
                        RuntimeWarning,
                        2,
                    )
                return BatchData(
                    task_ids=task_ids,
                    task_paths=task_paths,
                    verbose=verbose,
                    cached_tasks=dict.fromkeys(task_paths, True),
                )
            elif message == "running":
                if show_progress:
                    p = max(0, min(100, int(status.get("progress", 0))))
                    c = progress_chars[i]
                    i = (i + 1) % len(progress_chars)
                    print(f"Progress: {p}% {c}", end="\r", flush=True)
                time.sleep(0.3)
            elif message == "error":
                if show_progress:
                    print("Progress: error", end="\n", flush=True)
                raise RuntimeError("Batch run resulted in error.")
            else:
                raise RuntimeError(f"Status message unknown: {message!r}.")

    def test_port_symmetries(
        self,
        component: Component,
        frequencies: Sequence[float],
        plot_error: bool = True,
        atol: float = 0.02,
        **kwargs: object,
    ) -> bool:
        """
        Test this models port symmetries with a component.

        Effectively executes all simulations required without symmetries and
        compares with the symmetry setting.

        Args:
            component: Component to test.
            frequencies: Frequencies to use during the test.
            plot_error: Create a plot for elements with symmetry errors.
            atol: Absolute tolerance when comparing results.
            **kwargs: Arguments to replace in the model during the test.

        Returns:
            Boolean indicating whether the symmetries for all Tidy3D models in
            the component are correct.
        """
        success = True
        if len(self.port_symmetries) == 0:
            return True

        original_args = {k: getattr(self, k) for k in kwargs}
        for k, v in kwargs.items():
            setattr(self, k, v)

        port_symmetries = self.port_symmetries
        self.port_symmetries = []
        s1 = self.s_matrix(component, frequencies)
        self.port_symmetries = port_symmetries
        s0 = self.s_matrix(component, frequencies)

        for k, v in original_args.items():
            setattr(self, k, v)

        ax = None
        for k in s0.elements:
            if not numpy.allclose(s0[k], s1[k], atol=atol):
                success = False
                if plot_error and ax is None:
                    try:
                        from matplotlib import pyplot

                        _, ax = pyplot.subplots(2, 2, figsize=(10, 6), tight_layout=True)
                    except ImportError:
                        pass
                if ax is not None:
                    ax[0, 0].plot(frequencies, numpy.real(s0[k]), label=str(k) + " (sym)")
                    ax[0, 1].plot(frequencies, numpy.imag(s0[k]), label=str(k) + " (sym)")
                    ax[1, 0].plot(frequencies, numpy.real(s1[k]), label=str(k))
                    ax[1, 1].plot(frequencies, numpy.imag(s1[k]), label=str(k))
        if ax is not None:
            ax[0, 0].set(xlabel="Frequency (Hz)", ylabel="Real part")
            ax[0, 1].set(xlabel="Frequency (Hz)", ylabel="Imaginary part")
            ax[1, 0].set(xlabel="Frequency (Hz)", ylabel="Real part")
            ax[1, 1].set(xlabel="Frequency (Hz)", ylabel="Imaginary part")
            for a in ax.flat:
                a.legend()
        return success

    # Deprecated: kept for backwards compatibility with old phf files
    @classmethod
    def from_bytes(cls, byte_repr: bytes) -> "Tidy3DModel":
        """De-serialize this model."""
        version = byte_repr[0]
        if version == 1:
            obj = dict(_from_bytes(byte_repr[1:]))

        elif version == 0:
            n_size = struct.calcsize("<BL")
            n = struct.unpack("<L", byte_repr[1:n_size])[0]
            cursor = struct.calcsize("<BL" + n * "Q")
            lengths = struct.unpack("<" + n * "Q", byte_repr[n_size:cursor])

            obj = json.loads(byte_repr[cursor : cursor + lengths[0]].decode("utf-8"))
            cursor += lengths[0]

            models = [None] * (n - 1)
            for i, length in enumerate(lengths[1:]):
                models[i] = _tidy3d_from_bytes(byte_repr[cursor : cursor + length])
                cursor += length

            if cursor != len(byte_repr):
                raise RuntimeError("Invalid byte representation for Tidy3DModel.")

            indices = obj.pop("_tidy3d_indices_")
            for name, (i, j) in indices.items():
                if j < 0:
                    obj[name] = models[i]
                else:
                    obj[name] = [models[m] for m in range(i, j)]

        # zlib-compressed json used before versioning
        elif version == 0x78:
            obj = json.loads(zlib.decompress(byte_repr).decode("utf-8"))
            obj = _decode_arrays(obj)

            item = obj.get("medium")
            if isinstance(item, dict):
                obj["medium"] = TypeAdapter(tidy3d.components.medium.MediumType3D).validate_python(
                    obj["medium"]
                )

            item = obj.get("boundary_spec")
            if isinstance(item, dict):
                obj["boundary_spec"] = TypeAdapter(tidy3d.BoundarySpec).validate_python(item)

            item = obj.get("run_time")
            if isinstance(item, dict):
                obj["run_time"] = TypeAdapter(tidy3d.RunTimeSpec).validate_python(item)

            item = obj.get("grid_spec")
            if isinstance(item, dict):
                obj["grid_spec"] = TypeAdapter(tidy3d.GridSpec).validate_python(item)

            obj["monitors"] = [
                TypeAdapter(tidy3d.components.types.monitor.MonitorType).validate_python(mon)
                for mon in obj.get("monitors", ())
            ]

            obj["structures"] = [
                TypeAdapter(tidy3d.Structure).validate_python(s) for s in obj.get("structures", ())
            ]
        else:
            raise RuntimeError(
                f"Unsupported version found in Tidy3DModel byte representation: {version}."
            )

        return cls(**obj)


class _EMEModelRunner:
    def __init__(
        self,
        simulation: tidy3d.EMESimulation,
        ports: dict[str, Port | FiberPort],
        port_groups: tuple[tuple[str], tuple[str]],
        mesh_refinement: tidy3d.components.grid.grid_spec.GridSpec1d | float,
        technology: Technology,
        folder_name: str,
        cost_estimation: bool,
        verbose: bool,
        use_interface_matrix: bool,
    ) -> None:
        key = (_tidy3d_to_bytes(simulation), folder_name)
        runner = _tidy3d_model_cache[key]
        if runner is None or runner.status["message"] == "error":
            task_name = "EME" if "EME" not in ports else ("EME " + " ".join(ports))
            runner = _simulation_runner(
                simulation=simulation,
                task_name=task_name,
                remote_path=folder_name,
                cost_estimation=cost_estimation,
                verbose=verbose,
            )
            _tidy3d_model_cache[key] = runner
        self.runners = {0: runner}

        # Port modes for decomposition
        filter_polarization = False
        for name in port_groups[0] + port_groups[1]:
            self.runners[name] = _ModeSolverRunner(
                port=ports[name],
                frequencies=simulation.freqs,
                mesh_refinement=mesh_refinement,
                technology=technology,
                center_in_origin=False,
                verbose=verbose,
            )
            filter_polarization = filter_polarization or (ports[name].spec.polarization != "")

        self.ports = ports
        self.port_groups = port_groups
        self.use_interface_matrix = use_interface_matrix
        self._s_matrix = None

        # If the model uses any symmetry or polarization filter, it will impact the mode numbering
        # of the ports. We need to remap port modes from the symmetry-applied to the full version.
        self.mode_remap = simulation.symmetry != (0, 0, 0) or filter_polarization
        if self.mode_remap:
            classification = frequency_classification(simulation.freqs)
            use_angle_rotation = _isotropic_uniform(technology, classification)
            allowed = set(tidy3d.Simulation.model_fields).difference({"attrs", "type"})
            sim_kwargs = {k: v for k, v in simulation.model_dump().items() if k in allowed}
            full_sim = tidy3d.Simulation(run_time=1e-12, **sim_kwargs)
            for name in port_groups[0] + port_groups[1]:
                monitor = ports[name].to_tidy3d_monitor(
                    simulation.freqs, name="M", use_angle_rotation=use_angle_rotation
                )
                mode_solver = ModeSolver(
                    simulation=full_sim,
                    plane=monitor.bounding_box,
                    mode_spec=monitor.mode_spec.copy(update={"sort_spec": tidy3d.ModeSortSpec()}),
                    freqs=simulation.freqs,
                    direction=monitor.store_fields_direction,
                )
                self.runners[(name, "full")] = _simulation_runner(
                    simulation=mode_solver,
                    task_name=name + "-no_sym",
                    remote_path=folder_name,
                    cost_estimation=cost_estimation,
                    verbose=verbose,
                )

    @property
    def status(self) -> dict[str, object]:
        """Monitor S matrix computation progress."""
        all_stat = [runner.status for runner in self.runners.values()]
        if all(s["message"] == "success" for s in all_stat):
            message = "success"
            progress = 100
        elif any(s["message"] == "error" for s in all_stat):
            message = "error"
            progress = 100
        else:
            message = "running"
            progress = sum(
                100 if s["message"] == "success" else s["progress"] for s in all_stat
            ) / len(all_stat)
        return {"progress": progress, "message": message}

    @property
    def s_matrix(self) -> SMatrix:
        """Get the model S matrix."""
        if self._s_matrix is None:
            # Original S matrix in EME basis
            eme_data = self.runners[0].data
            eme_modes = eme_data.port_modes_tuple
            eme_modes = (eme_modes[0], eme_modes[1].time_reversed_copy)

            eme_s_matrix = eme_data.smatrix
            num_eme_modes = (
                eme_s_matrix.S11.coords["mode_index_in"].size,
                eme_s_matrix.S22.coords["mode_index_in"].size,
            )

            kwds = {"sweep_index": 0, "drop": True}
            if self.use_interface_matrix:
                eme_s_matrix = eme_data.coeffs.interface_smatrices
                kwds["eme_cell_index"] = 0

            num_freqs = len(eme_data.simulation.freqs)
            s = numpy.empty((num_freqs, sum(num_eme_modes), sum(num_eme_modes)), dtype=complex)
            s[:, : num_eme_modes[0], : num_eme_modes[0]] = (
                eme_s_matrix.S11.isel(**kwds)
                .transpose("f", "mode_index_out", "mode_index_in")
                .values[:, : num_eme_modes[0], : num_eme_modes[0]]
            )
            s[:, : num_eme_modes[0], num_eme_modes[0] :] = (
                eme_s_matrix.S12.isel(**kwds)
                .transpose("f", "mode_index_out", "mode_index_in")
                .values[:, : num_eme_modes[0], : num_eme_modes[1]]
            )
            s[:, num_eme_modes[0] :, : num_eme_modes[0]] = (
                eme_s_matrix.S21.isel(**kwds)
                .transpose("f", "mode_index_out", "mode_index_in")
                .values[:, : num_eme_modes[1], : num_eme_modes[0]]
            )
            s[:, num_eme_modes[0] :, num_eme_modes[0] :] = (
                eme_s_matrix.S22.isel(**kwds)
                .transpose("f", "mode_index_out", "mode_index_in")
                .values[:, : num_eme_modes[1], : num_eme_modes[1]]
            )

            # Port mode transformation matrix
            # M_ij = <e_i, e_j'> / <e_i, e_i>
            # S' = pinv(M) × S × M
            port_names = self.port_groups[0] + self.port_groups[1]
            port_num_modes = {
                name: self.ports[name].num_modes + self.ports[name].added_solver_modes
                for name in port_names
            }
            sum_modes = sum(port_num_modes.values())
            m = numpy.zeros((num_freqs, sum(num_eme_modes), sum_modes), dtype=complex)
            mode_index = 0
            for i in range(2):
                eme_mode = eme_modes[i].interpolated_copy
                norms = eme_mode.dot(eme_mode, conjugate=False)
                norms = norms.transpose("mode_index", "f").values[: num_eme_modes[i]]
                for name in self.port_groups[i]:
                    num_modes = port_num_modes[name]
                    port_data = self.runners[name].data
                    projection = (
                        eme_mode.outer_dot(port_data, conjugate=False)
                        .transpose("mode_index_1", "mode_index_0", "f")
                        .values[:, : num_eme_modes[i], :]
                    )
                    m_block = projection / norms
                    if i == 0:
                        m[:, : num_eme_modes[0], mode_index : mode_index + num_modes] = m_block.T
                    else:
                        m[:, num_eme_modes[0] :, mode_index : mode_index + num_modes] = m_block.T
                    mode_index += num_modes
            s = numpy.linalg.pinv(m) @ s @ m

            elements = {}
            j = 0
            for src in port_names:
                for src_mode in range(port_num_modes[src]):
                    i = 0
                    for dst in port_names:
                        for dst_mode in range(port_num_modes[dst]):
                            if (
                                src_mode < self.ports[src].num_modes
                                and dst_mode < self.ports[dst].num_modes
                            ):
                                elements[f"{src}@{src_mode}", f"{dst}@{dst_mode}"] = s[:, i, j]
                            i += 1
                    j += 1

            # If symmetry or polarization filter was used, calculate and apply mode mapping
            if self.mode_remap:
                data_sym = {
                    name: self.runners[name].data
                    for name, port in self.ports.items()
                    if not isinstance(port, GaussianPort)
                }
                data_full = {
                    name: self.runners[(name, "full")].data
                    for name, port in self.ports.items()
                    if not isinstance(port, GaussianPort)
                }
                elements = _mode_remap_from_symmetry(elements, self.ports, data_sym, data_full)

            self._s_matrix = SMatrix(eme_data.simulation.freqs, elements, self.ports)

        return self._s_matrix


class EMEModel(Model):
    """S matrix model based on Eigenmode Expansion calculation.

    Args:
        eme_grid_spec: 1D grid in the that specifies the EME cells where
          mode solving is performed along the propagation direction.
        medium: Background medium. If ``None``, the technology default is
          used.
        symmetry: Component symmetries.
        monitors: Extra field monitors added to the simulation.
        structures: Additional structures included in the simulations.
        grid_spec: Simulation grid specification. A single float can be used
          to specify the ``min_steps_per_wvl`` for an auto grid.
        subpixel: Flag controlling subpixel averaging in the simulation
          grid or an instance of ``tidy3d.SubpixelSpec``.
        bounds: Bound overrides for the final simulation.
        constraint: Constraint for EME propagation. Possible values are
          ``"passive"`` and ``"unitary"``.
        simulation_updates: Dictionary of updates applied to the simulation
          generated by this model. See example in :class:`Tidy3DModel`.
        verbose: Control solver verbosity.

    If not set, the default values for the component simulations are defined
    based on the wavelengths used in the ``s_matrix`` call.
    """

    def __init__(
        self,
        eme_grid_spec: annotate(
            tidy3d.components.eme.grid.EMESubgridType, brand="Tidy3dEMEGridSpec"
        ),
        medium: Medium | None = None,
        symmetry: SymmetryType = (0, 0, 0),
        monitors: Sequence[MonitorType] = (),
        structures: Sequence[tidy3d.Structure] = (),
        grid_spec: PositiveFloat | tidy3d.GridSpec | None = None,
        subpixel: SubpixelType = True,
        bounds: BoundsType = ((None, None, None), (None, None, None)),
        constraint: Literal["passive", "unitary"] | None = "passive",
        simulation_updates: dict[str, object] | None = None,
        verbose: bool = True,
        _use_interface_matrix=False,
        _grid_transform_matrix=((1.0, 0.0), (0.0, 1.0), (0.0, 0.0)),
    ) -> None:
        super().__init__(
            eme_grid_spec=eme_grid_spec,
            medium=medium,
            symmetry=symmetry,
            monitors=monitors,
            structures=structures,
            grid_spec=grid_spec,
            subpixel=subpixel,
            bounds=bounds,
            constraint=constraint,
            simulation_updates=simulation_updates,
            verbose=verbose,
            _use_interface_matrix=_use_interface_matrix,
            _grid_transform_matrix=_grid_transform_matrix,
        )
        self.eme_grid_spec = eme_grid_spec
        self.medium = medium
        self.symmetry = symmetry
        self.monitors = monitors
        self.structures = structures
        self.grid_spec = grid_spec
        self.subpixel = subpixel
        self.bounds = bounds
        self.constraint = constraint
        self.simulation_updates = {} if simulation_updates is None else simulation_updates
        self.verbose = verbose
        self._use_interface_matrix = _use_interface_matrix
        self._grid_transform_matrix = _grid_transform_matrix

    def transform(
        self,
        translation: Sequence[float] | complex = (0, 0),
        rotation: float = 0,
        scaling: float = 1,
        x_reflection: bool = False,
    ) -> "EMEModel":
        if isinstance(translation, complex):
            translation = (translation.real, translation.imag)

        self.parametric_kwargs["bounds"] = self.bounds = _transform_xy_bounds(
            self.bounds, translation, rotation, scaling, x_reflection
        )
        self.parametric_kwargs["structures"] = self.structures = tuple(
            _transform_tidy3d_structures(s, translation, rotation, scaling, x_reflection)
            for s in self.structures
        )
        self.parametric_kwargs["monitors"] = self.monitors = tuple(
            _transform_tidy3d_monitors(m, translation, rotation, scaling, x_reflection)
            for m in self.monitors
        )
        self.parametric_kwargs["_grid_transform_matrix"] = self._grid_transform_matrix = (
            _compose_affine_transform(
                self._grid_transform_matrix,
                translation,
                rotation,
                scaling,
                x_reflection,
            )
        )

        if self.symmetry[0] != 0 or self.symmetry[1] != 0:
            if _is_multiple_of_90(rotation):
                if round(rotation // 90) % 2 == 1:
                    self.parametric_kwargs["symmetry"] = self.symmetry = (
                        self.symmetry[1],
                        self.symmetry[0],
                        self.symmetry[2],
                    )
            else:
                warnings.warn(
                    "EMEModel 'symmetry' is not transformed for arbitrary rotations. "
                    "Resetting 'symmetry' in the xy plane.",
                    RuntimeWarning,
                    stacklevel=2,
                )
                self.parametric_kwargs["symmetry"] = self.symmetry = (0, 0, self.symmetry[2])

        if not _angles_equal(rotation, 0) or scaling != 1 or x_reflection:
            if isinstance(self.grid_spec, tidy3d.GridSpec):
                warnings.warn(
                    "EMEModel 'grid_spec' is not transformed when it is a tidy3d.GridSpec. "
                    "Resetting 'grid_spec' to default None.",
                    RuntimeWarning,
                    stacklevel=2,
                )
                self.parametric_kwargs["grid_spec"] = self.grid_spec = None
            if len(self.simulation_updates) > 0:
                warnings.warn(
                    "EMEModel 'simulation_updates' are not transformed. "
                    "Resetting 'simulation_updates' to default empty dictionary.",
                    RuntimeWarning,
                    stacklevel=2,
                )
                self.parametric_kwargs["simulation_updates"] = self.simulation_updates = {}

        return self

    @staticmethod
    def _group_ports(ports: dict[str, Port]) -> tuple[int, tuple[tuple[str], tuple[str]]]:
        port_groups = {}
        for name, port in ports.items():
            if isinstance(port, Port):
                fraction = port.input_direction % 90
                if fraction > 1e-12 and 90 - fraction > 1e-12:
                    raise RuntimeError(
                        f"Input direction of port '{name}' is not a multiple of 90°."
                    )
                direction = round(port.input_direction % 360) // 90
                coordinate = port.center[direction % 2]
                key = (coordinate, direction)
            elif isinstance(port, FiberPort):
                center, size, direction, *_ = port._axis_aligned_properties()
                axis = size.tolist().index(0)
                if axis > 1:
                    raise RuntimeError(f"Input direction of port '{name}' is not in the xy plane.")
                key = (center[axis], axis + (2 if direction == "-" else 0))
            else:
                warnings.warn(
                    f"EMEModel only works with Port and FiberPort instances. Port named '{name}' "
                    f"of type {type(port)} will be ignored.",
                    RuntimeWarning,
                    2,
                )
                continue
            port_groups[key] = (*port_groups.get(key, ()), name)

        if len(port_groups) == 1:
            key, group = next(iter(port_groups.items()))
            if key < 2:
                return (key[1], (group, ()))
            else:
                return (key[1] - 2, ((), group))

        if len(port_groups) == 2:
            key0, key1 = sorted(port_groups)
            if key1[1] - key0[1] == 2 and key0[0] < key1[0]:
                return (key0[1], (port_groups[key0], port_groups[key1]))

        raise RuntimeError(
            "Component ports need to be placed at 2 opposite sides, facing each other. Multiple "
            "ports on each side are allowed as long as they are aligned in the normal direction."
        )

    def get_simulation(
        self, component: Component, frequencies: Sequence[float]
    ) -> tuple[tidy3d.EMESimulation, tuple[tuple[str], tuple[str]]]:
        """Create an EME simulation for a component.

        Args:
            component: Instance of Component for calculation.
            frequencies: Sequence of frequencies for the simulation.

        Returns:
            EME simulation and 2 tuples with the names of the ports on each side of the domain.
        """
        frequencies = numpy.array(frequencies, dtype=float, ndmin=1)
        fmin = frequencies.min()
        fmax = frequencies.max()
        fmed = 0.5 * (fmin + fmax)
        max_wavelength = C_0 / fmin
        min_wavelength = C_0 / fmax

        classification = frequency_classification(frequencies)

        component_ports = component.select_ports(classification)

        technology = component.technology
        original_extrusions = technology.extrusion_specs

        # Make sure we reset technology to its original state
        try:
            zmin = None
            zmax = None
            if len(component_ports) > 0 and all(
                isinstance(p, Port) for p in component_ports.values()
            ):
                if self.bounds[0][2] is None:
                    zmin = min(p.spec.limits[0] for p in component_ports.values())
                    technology.extrusion_specs = [
                        e for e in technology.extrusion_specs if e.limits[1] >= zmin
                    ]
                if self.bounds[1][2] is None:
                    zmax = max(p.spec.limits[1] for p in component_ports.values())
                    technology.extrusion_specs = [
                        e for e in technology.extrusion_specs if e.limits[0] <= zmax
                    ]

            use_angle_rotation = _isotropic_uniform(technology, classification)

            medium = (
                technology.get_background_medium(classification)
                if self.medium is None
                else self.medium
            )
            if isinstance(medium, tidy3d.MultiPhysicsMedium):
                # TODO: Remove this once support for MultiPhysicsMedium is added for Scene
                medium = medium.optical

            layer_refinement = _layer_steps_from_refinement(config.default_mesh_refinement)
            if isinstance(self.grid_spec, tidy3d.GridSpec):
                grid_spec = self.grid_spec
                mesh_refinement = config.default_mesh_refinement
            else:
                mesh_refinement = (
                    config.default_mesh_refinement if self.grid_spec is None else self.grid_spec
                )
                layer_refinement = _layer_steps_from_refinement(mesh_refinement)
                grid_spec = tidy3d.GridSpec.auto(
                    wavelength=min_wavelength,
                    min_steps_per_wvl=mesh_refinement,
                    min_steps_per_sim_size=mesh_refinement,
                )

            extrusion_tolerance = 0
            if isinstance(grid_spec.grid_z, tidy3d.AutoGrid):
                extrusion_specs = technology.extrusion_specs
                if classification == "optical":
                    grid_lda = (
                        min_wavelength if grid_spec.wavelength is None else grid_spec.wavelength
                    )
                    temp_structures = [
                        tidy3d.Structure(
                            geometry=tidy3d.Box(size=(1, 1, 1)),
                            medium=spec.get_medium(classification),
                        )
                        for spec in extrusion_specs
                    ]
                    temp_scene = tidy3d.Scene(medium=medium, structures=temp_structures)
                    _, eps_max = temp_scene.eps_bounds(fmed)
                    extrusion_tolerance = grid_lda / (
                        grid_spec.grid_z.min_steps_per_wvl * eps_max**0.5
                    )
                elif len(extrusion_specs) > 0:
                    for spec in technology.extrusion_specs:
                        t = spec.limits[1] - spec.limits[0]
                        if t > 0 and (extrusion_tolerance == 0 or extrusion_tolerance > t):
                            extrusion_tolerance = t
                    extrusion_tolerance = max(
                        config.tolerance, extrusion_tolerance / layer_refinement
                    )
            elif isinstance(grid_spec.grid_z, tidy3d.components.grid.grid_spec.AbstractAutoGrid):
                extrusion_tolerance = grid_spec.grid_z._dl_min
            elif isinstance(grid_spec.grid_z, tidy3d.UniformGrid):
                extrusion_tolerance = grid_spec.grid_z.dl
            elif isinstance(grid_spec.grid_z, tidy3d.CustomGrid) and len(grid_spec.grid_z.dl) > 0:
                extrusion_tolerance = min(grid_spec.grid_z.dl)

            extrusion_layers = technology.extrusion_layers()
            (xmin, ymin), (xmax, ymax) = component.bounds(
                include_labels=False, layers=extrusion_layers
            )
            max_bounds = max(xmax - xmin, ymax - ymin)

            if classification == "optical":
                safe_margin = 0.3 * max_wavelength
                port_extension = 2 * safe_margin + max_bounds
            else:
                source_gap = max_wavelength / 100
                grid_scale = max_bounds / mesh_refinement
                safe_margin = max(max_wavelength / 100, 3 * grid_scale) + source_gap
                port_extension = safe_margin + 200 * grid_scale

                if any(
                    isinstance(p, Port) and p.bend_radius != 0 for p in component_ports.values()
                ):
                    warnings.warn(
                        "Electrical ports with non-zero bending radius can result in inaccurate "
                        "mode normalization, leading to invalid S matrices.",
                        stacklevel=2,
                    )

            for port in component_ports.values():
                _, size, *_ = (
                    port._axis_aligned_properties()
                    if isinstance(port, (Port, FiberPort))
                    else port._axis_aligned_properties(frequencies, 1.0)
                )
                port_extension = max(port_extension, size[0], size[1])

            # Bounds override
            delta = port_extension - 2 * safe_margin
            if self.bounds[0][0] is not None and self.bounds[0][0] < xmin - delta:
                port_extension = xmin - self.bounds[0][0] + 2 * safe_margin
            if self.bounds[0][1] is not None and self.bounds[0][1] < ymin - delta:
                port_extension = ymin - self.bounds[0][1] + 2 * safe_margin
            if self.bounds[1][0] is not None and self.bounds[1][0] > xmax + delta:
                port_extension = self.bounds[1][0] - xmax + 2 * safe_margin
            if self.bounds[1][1] is not None and self.bounds[1][1] > ymax + delta:
                port_extension = self.bounds[1][1] - ymax + 2 * safe_margin

            used_extrusions = []
            structures = [
                s.to_tidy3d()
                for s in component.extrude(
                    port_extension,
                    extrusion_tolerance=extrusion_tolerance,
                    classification=classification,
                    used_extrusions=used_extrusions,
                )
            ]

        finally:
            technology.extrusion_specs = original_extrusions

        # Sort to improve caching, but don't reorder different media
        i = 0
        while i < len(structures):
            current_medium = structures[i].medium
            j = i + 1
            while j < len(structures) and structures[j].medium == current_medium:
                j += 1
            # Even if j == i + 1 we want to sort internal geometries
            structures[i:j] = (
                tidy3d.Structure(geometry=geometry, medium=current_medium)
                for geometry in sorted(
                    [_inner_geometry_sort(s.geometry) for s in structures[i:j]], key=_geometry_key
                )
            )
            i = j

        port_structures = [
            structure
            for _, port in sorted(component_ports.items())
            if isinstance(port, FiberPort)
            for structure in port.to_tidy3d_structures()
        ]
        all_structures = structures + port_structures + list(self.structures)
        axis, port_groups = self._group_ports(component_ports)

        grid_snapping_points = []
        for name, port in component_ports.items():
            if isinstance(port, (Port, FiberPort)):
                monitor = port.to_tidy3d_monitor(
                    frequencies, name=name, use_angle_rotation=use_angle_rotation
                )
            else:
                epsilon_r = _get_epsilon(port.center, all_structures, medium, frequencies)
                monitor = port.to_tidy3d_monitor(frequencies, medium=epsilon_r, name=name)

            i = monitor.size.index(0)
            p = [None, None, None]
            p[i] = monitor.center[i]
            grid_snapping_points.append(tuple(p))

        # Add layer refinements based on extruded layers and ports
        if classification == "electrical" and not isinstance(self.grid_spec, tidy3d.GridSpec):
            layer_refinement_specs = [
                _make_layer_refinement_spec(spec, layer_refinement, classification)
                for spec in sorted(
                    used_extrusions, key=lambda e: e.limits[1] - e.limits[0], reverse=True
                )
            ]
            grid_1d_update = {"max_scale": _auto_scale_from_refinement(mesh_refinement)}
            grid_spec = grid_spec.copy(
                update={
                    "snapping_points": grid_snapping_points,
                    "layer_refinement_specs": layer_refinement_specs,
                    "grid_x": grid_spec.grid_x.copy(update=grid_1d_update),
                    "grid_y": grid_spec.grid_y.copy(update=grid_1d_update),
                    "grid_z": grid_spec.grid_z.copy(update=grid_1d_update),
                }
            )

        # Simulation bounds
        # If zmin/zmax were pre-defined, do not set them based on geometry
        if zmin is None:
            zmin = Z_MAX
            for s in structures:
                for lim in s.geometry.bounds:
                    if -Z_MAX <= lim[2] <= Z_MAX:
                        zmin = min(zmin, lim[2])
        if zmax is None:
            zmax = -Z_MAX
            for s in structures:
                for lim in s.geometry.bounds:
                    if -Z_MAX <= lim[2] <= Z_MAX:
                        zmax = max(zmax, lim[2])
        for name in port_groups[0] + port_groups[1]:
            monitor = component_ports[name].to_tidy3d_monitor(
                frequencies, name="M", use_angle_rotation=use_angle_rotation
            )
            xmin = min(xmin, monitor.bounds[0][0])
            ymin = min(ymin, monitor.bounds[0][1])
            zmin = min(zmin, monitor.bounds[0][2])
            xmax = max(xmax, monitor.bounds[1][0])
            ymax = max(ymax, monitor.bounds[1][1])
            zmax = max(zmax, monitor.bounds[1][2])
        if zmin > zmax:
            raise RuntimeError(
                "Unable to determine z-limits for simulation. Please set EMEModel bounds "
                "manually in the z axis."
            )

        bounds = numpy.array(((xmin, ymin, zmin), (xmax, ymax, zmax)))

        # Bounds override
        for i in range(3):
            if self.bounds[0][i] is not None:
                bounds[0, i] = self.bounds[0][i]
            if self.bounds[1][i] is not None:
                bounds[1, i] = self.bounds[1][i]

        port_offsets = []
        for i in range(2):
            sign = 2 * i - 1
            if len(port_groups[i]) > 0:
                port_offset = sign * (
                    bounds[i][axis] - component_ports[port_groups[i][0]].center[axis]
                )
                if port_offset < safe_margin:
                    port_offset = safe_margin
                    bounds[i][axis] = (
                        component_ports[port_groups[i][0]].center[axis] + sign * safe_margin
                    )
            else:
                port_offset = 0
            port_offsets.append(port_offset)

        center = tuple(snap_to_grid(v) / 2 for v in bounds[0] + bounds[1])
        size = tuple(snap_to_grid(v) for v in bounds[1] - bounds[0])
        bounding_box = tidy3d.Box(center=center, size=size)

        all_structures = [s for s in all_structures if bounding_box.intersects(s.geometry)]
        if len(all_structures) >= GROUPING_THRESHOLD:
            all_structures = _group_by_medium(all_structures)

        eme_grid_spec = self.eme_grid_spec
        if self._grid_transform_matrix != ((1.0, 0.0), (0.0, 1.0), (0.0, 0.0)):
            eme_grid_spec = _transform_eme_grid_spec(
                eme_grid_spec, axis, self._grid_transform_matrix
            )

        eme_simulation = tidy3d.EMESimulation(
            freqs=frequencies,
            center=center,
            size=size,
            medium=medium,
            symmetry=self.symmetry,
            structures=all_structures,
            monitors=list(self.monitors),
            grid_spec=grid_spec,
            eme_grid_spec=eme_grid_spec,
            subpixel=self.subpixel,
            axis=axis,
            port_offsets=port_offsets,
            constraint=self.constraint,
            store_coeffs=self._use_interface_matrix,
        )

        for path, value in self.simulation_updates.items():
            eme_simulation = _updated_tidy3d(eme_simulation, path.split("/"), value)

        return eme_simulation, port_groups

    @cache_s_matrix
    def start(
        self,
        component: Component,
        frequencies: Sequence[float],
        *,
        verbose: bool | None = None,
        cost_estimation: bool = False,
        **kwargs: object,
    ) -> _EMEModelRunner:
        """Start computing the S matrix response from a component.

        Args:
            component: Component from which to compute the S matrix.
            frequencies: Sequence of frequencies at which to perform the
              computation.
            verbose: If set, overrides the model's `verbose` attribute.
            cost_estimation: If set, simulations are uploaded, but not
              executed. S matrix will *not* be computed.
            **kwargs: Unused.

        Returns:
            Result object with attributes ``status`` and ``s_matrix``.

        Important:
            When using geometry symmetry, the mode numbering in ``inputs``
            is relative to the solver run *with the symmetry applied*, not
            the mode number presented in the final S matrix.
        """
        simulation, port_groups = self.get_simulation(component, frequencies)
        folder_name = _filename_cleanup(component.name)

        classification = frequency_classification(frequencies)
        component_ports = {
            name: port.copy(True) for name, port in component.select_ports(classification).items()
        }

        if verbose is None:
            verbose = self.verbose

        mesh_refinement = (
            config.default_mesh_refinement
            if self.grid_spec is None or isinstance(self.grid_spec, tidy3d.GridSpec)
            else self.grid_spec
        )

        if len(folder_name) == 0:
            folder_name = "default"
        result = _EMEModelRunner(
            simulation=simulation,
            ports=component_ports,
            port_groups=port_groups,
            mesh_refinement=mesh_refinement,
            technology=component.technology,
            folder_name=folder_name,
            cost_estimation=cost_estimation,
            verbose=verbose,
            use_interface_matrix=self._use_interface_matrix,
        )

        return result

    def simulation_data(
        self,
        component: Component,
        frequencies: Sequence[float],
        *,
        verbose: bool | None = None,
        show_progress: bool = True,
        **kwargs: object,
    ) -> tidy3d.EMESimulationData | None:
        """Return the EME simulation data for a given component.

        Uses the same arguments as :func:`EMEModel.start`.
        """
        if verbose is None:
            verbose = self.verbose

        if show_progress:
            print("Starting…", end="\r", flush=True)

        runner = self.start(component, frequencies, verbose=verbose, **kwargs).runners[0]

        progress_chars = "-\\|/"
        i = 0
        while True:
            status = runner.status
            message = status["message"]
            if message == "success":
                if show_progress:
                    print("Progress: 100% ", end="\n", flush=True)
                return runner.data
            elif message == "running":
                if show_progress:
                    p = max(0, min(100, int(status.get("progress", 0))))
                    c = progress_chars[i]
                    i = (i + 1) % len(progress_chars)
                    print(f"Progress: {p}% {c}", end="\r", flush=True)
                time.sleep(0.3)
            elif message == "error":
                if show_progress:
                    print("Progress: error", end="\n", flush=True)
                raise RuntimeError("Batch run resulted in error.")
            else:
                raise RuntimeError(f"Status message unknown: {message!r}.")

    # Deprecated: kept for backwards compatibility with old phf files
    @classmethod
    def from_bytes(cls, byte_repr: bytes) -> "EMEModel":
        """De-serialize this model."""
        version = byte_repr[0]
        if version == 1:
            obj = dict(_from_bytes(byte_repr[1:]))

        elif version == 0:
            n_size = struct.calcsize("<BL")
            n = struct.unpack("<L", byte_repr[1:n_size])[0]
            cursor = struct.calcsize("<BL" + n * "Q")
            lengths = struct.unpack("<" + n * "Q", byte_repr[n_size:cursor])

            obj = json.loads(byte_repr[cursor : cursor + lengths[0]].decode("utf-8"))
            cursor += lengths[0]

            models = [None] * (n - 1)
            for i, length in enumerate(lengths[1:]):
                models[i] = _tidy3d_from_bytes(byte_repr[cursor : cursor + length])
                cursor += length

            if cursor != len(byte_repr):
                raise RuntimeError("Invalid byte representation for Tidy3DModel.")

            indices = obj.pop("_tidy3d_indices_")
            for name, (i, j) in indices.items():
                if j < 0:
                    obj[name] = models[i]
                else:
                    obj[name] = [models[m] for m in range(i, j)]

        # zlib-compressed json used before versioning
        elif version == 0x78:
            obj = json.loads(zlib.decompress(byte_repr).decode("utf-8"))
            obj = _decode_arrays(obj)

            item = obj.get("eme_grid_spec")
            if isinstance(item, dict):
                obj["eme_grid_spec"] = TypeAdapter(
                    tidy3d.components.eme.grid.EMESubgridType
                ).validate_python(item)

            item = obj.get("medium")
            if isinstance(item, dict):
                obj["medium"] = TypeAdapter(tidy3d.components.medium.MediumType3D).validate_python(
                    item
                )

            item = obj.get("grid_spec")
            if isinstance(item, dict):
                obj["grid_spec"] = TypeAdapter(tidy3d.GridSpec).validate_python(item)

            obj["monitors"] = [
                TypeAdapter(tidy3d.components.types.monitor.MonitorType).validate_python(mon)
                for mon in obj.get("monitors", ())
            ]

            obj["structures"] = [
                TypeAdapter(tidy3d.Structure).validate_python(s) for s in obj.get("structures", ())
            ]

        return cls(**obj)


# Note: Kept for backwards compatibility. Do not use: horrible performance.
def _decode_arrays(obj: object) -> object:
    if isinstance(obj, dict):
        if len(obj) == 1:
            import xarray

            k, v = next(iter(obj.items()))
            if k == "PhotonForge xarray.Dataset":
                return xarray.Dataset.from_dict(v)
            if k == "PhotonForge xarray.DataArray":
                return xarray.DataArray.from_dict(v)
        return {k: _decode_arrays(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_decode_arrays(x) for x in obj]
    if isinstance(obj, tuple):
        return tuple(_decode_arrays(x) for x in obj)
    if isinstance(obj, set):
        return {_decode_arrays(x) for x in obj}
    return obj


register_model_class(Tidy3DModel)
register_model_class(EMEModel)
