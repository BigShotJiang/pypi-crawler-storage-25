from collections.abc import Sequence
from typing import Literal

from ..extension import (
    Component,
    Model,
    Path,
    Port,
    PortSpec,
    SMatrix,
    Technology,
    register_model_class,
)
from .analytic import _add_bb_text, _bb_layer


class ErrorModel(Model):
    def __init__(
        self, message: str, cls: Literal["RuntimeError", "NotImplementedError"] = "RuntimeError"
    ) -> None:
        # Error classes are not serializable in phf, so we use a string instead, since this model
        # is for internal use only.
        super().__init__(message=message, cls=cls)

    def black_box_component(
        self,
        num_ports: int | tuple[float, ...],
        port_spec: str | PortSpec | None = None,
        technology: Technology | None = None,
        name: str | None = None,
    ) -> Component:
        """Create a black-box component using this model for testing.

        Args:
            num_ports: Total number of ports (automatically distributed
              around the component) or a tuple of port directions (one for
              each desired port).
            port_spec: Port specification used in the component. If ``None``,
              look for ``"port_spec"`` in :attr:`config.default_kwargs`.
            technology: Component technology. If ``None``, the default
              technology is used.
            name: Component name. If ``None`` a default is used.

        Returns:
            Component with ports and model.
        """
        model_name = self.__class__.__name__[:-5]
        component = Component(f"BB{model_name}" if name is None else name, technology=technology)

        width = port_spec.width
        length = width * 8

        profiles = port_spec.path_profiles_list()
        if len(profiles) == 0:
            profiles = [(width, 0, _bb_layer)]

        for w, g, layer in profiles:
            component.add(layer, Path((0, 0), w, g).segment((length, 0)))

        _add_bb_text(component, width)

        if isinstance(num_ports, int):
            for i in range(num_ports):
                a = [0, 180, 90, -90][i % 4]
                x = [0, length, length / 2, length / 2][i % 4]
                y = [0, 0, -width / 2, width / 2][i % 4]
                component.add_port(Port((x, y), a, port_spec))
        else:
            totals = [0, 0, 0, 0]
            counters = [0, 0, 0, 0]
            for direction in num_ports:
                k = int((direction % 360) / 90 + 0.5) % 4
                totals[k] += 1
            for direction in num_ports:
                k = int((direction % 360) / 90 + 0.5) % 4
                n = totals[k]
                i = counters[k]
                counters[k] += 1
                if k == 0 or k == 2:
                    x = 0 if k == 0 else length
                    y = 0 if n == 1 else (-width / 4 + width / 2 * i / (n - 1))
                else:
                    x = (length / 2) if n == 1 else (length / 4 + length / 2 * i / (n - 1))
                    y = (-width / 2) if k == 1 else (width / 2)
                component.add_port(Port((x, y), direction, port_spec))

        component.add_model(self, model_name)
        return component

    def start(
        self, component: Component, frequencies: Sequence[float], **kwargs: object
    ) -> SMatrix:
        cls = (
            NotImplementedError
            if self.parametric_kwargs["cls"] == "NotImplementedError"
            else RuntimeError
        )
        raise cls(f"{self.parametric_kwargs['message']} (component {component.name!r})")


register_model_class(ErrorModel)
