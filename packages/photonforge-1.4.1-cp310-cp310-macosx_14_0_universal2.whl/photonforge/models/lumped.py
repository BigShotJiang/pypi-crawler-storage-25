"""Built-in lumped element models.

Each element implements ``start_mna`` returning an ``MNAMatrix`` with
nodal admittance stamps and/or MNA branch equations.  The base
``LumpedModel.s_matrix`` pipeline converts to S-parameters via
port-impedance-augmented solve (``mna_to_s``).
"""

import numpy as np

from .. import typing as pft
from ..extension import Component, LumpedModel, MNAMatrix, register_model_class
from ..utils import C_0

PortMapEntry = tuple[str, pft.Impedance] | tuple[str, str, pft.Impedance]
PortMap = dict[str, PortMapEntry]


class Resistor(LumpedModel):
    r"""Two-terminal resistor.

    MNA stamp: :math:`Y = \frac{1}{R}` admittance between terminals.

    Circuit diagram::

               R
       t1 ---/\/\/--- t2

    Args:
        resistance: Resistance.
        port_map: Port mappings from terminals (see :class:`LumpedModel`).

    Example:
        >>> resistor = pf.Resistor(resistance=50.0)
    """

    def __init__(self, *, resistance: pft.Resistance, port_map: PortMap | None = None) -> None:
        super().__init__(resistance=resistance, port_map=port_map)
        if resistance <= 0:
            raise ValueError(
                "Resistance must be positive. Use an inductor with L=0 for a short circuit."
            )

    def start_mna(
        self, component: Component | None, frequencies: list[float], **kwargs: object
    ) -> MNAMatrix:
        G = 1.0 / self.parametric_kwargs["resistance"]
        n = len(frequencies)
        elements = {
            ("t1", "t1"): np.full(n, G, dtype=complex),
            ("t1", "t2"): np.full(n, -G, dtype=complex),
            ("t2", "t1"): np.full(n, -G, dtype=complex),
            ("t2", "t2"): np.full(n, G, dtype=complex),
        }
        return MNAMatrix(frequencies, elements)


class Capacitor(LumpedModel):
    r"""Two-terminal capacitor.

    MNA stamp: :math:`Y = j\omega C` admittance between terminals.

    Circuit diagram::

              C
        t1 ---||--- t2

    Args:
        capacitance: Capacitance.
        port_map: Port mappings from terminals (see :class:`LumpedModel`).

    Example:
        >>> capacitor = pf.Capacitor(capacitance=1e-12)  # 1 pF
    """

    def __init__(self, *, capacitance: pft.Capacitance, port_map: PortMap | None = None) -> None:
        super().__init__(capacitance=capacitance, port_map=port_map)
        if capacitance <= 0:
            raise ValueError("Capacitance must be positive.")

    def start_mna(
        self, component: Component | None, frequencies: list[float], **kwargs: object
    ) -> MNAMatrix:
        Y_C = 1j * 2 * np.pi * np.array(frequencies) * self.parametric_kwargs["capacitance"]
        elements = {
            ("t1", "t1"): Y_C,
            ("t1", "t2"): -Y_C,
            ("t2", "t1"): -Y_C,
            ("t2", "t2"): Y_C,
        }
        return MNAMatrix(frequencies, elements)


class Inductor(LumpedModel):
    r"""Two-terminal inductor.

    MNA branch equation: auxiliary current :math:`I` with
    :math:`V(t_1) - V(t_2) = j\omega LI`.  Finite at all frequencies
    including DC.

    Circuit diagram::

                L
        t1 ---nnnnn--- t2

    Args:
        inductance: Inductance.
        port_map: Port mappings from terminals (see :class:`LumpedModel`).

    Example:
        >>> inductor = pf.Inductor(inductance=1e-9)  # 1 nH
    """

    def __init__(self, *, inductance: pft.Inductance, port_map: PortMap | None = None) -> None:
        super().__init__(inductance=inductance, port_map=port_map)
        if inductance < 0:
            raise ValueError("Inductance may not be negative.")

    def start_mna(
        self, component: Component | None, frequencies: list[float], **kwargs: object
    ) -> MNAMatrix:
        omega = 2 * np.pi * np.array(frequencies)
        inductance = self.parametric_kwargs["inductance"]
        elements: dict[tuple[str, str], np.ndarray] = {}
        _add_inductor_branch_stamp(elements, "t1", "t2", "_I", omega, inductance)
        return MNAMatrix(frequencies, elements)


class SeriesRLC(LumpedModel):
    r"""Series RLC circuit between two terminals.

    Series impedance :math:`Z = R + j\omega L + \frac{1}{j\omega C}`.
    Internal nodes and branch currents are used as needed. When
    ``resistance=0``, ``inductance=0``, or ``capacitance=None``, the
    corresponding stamps and internal nodes are omitted.

    Circuit diagram::

                R       L     C
        t1 ---/\/\/---nnnnn---||--- t2

    Args:
        resistance: Resistance. Only used if positive.
        inductance: Inductance. Only used if positive.
        capacitance: Capacitance. Only used if positive.
        port_map: Port mappings from terminals (see :class:`LumpedModel`).

    Example:
        >>> # Series LC tank at 1 GHz
        >>> lc = pf.SeriesRLC(inductance=2.5e-9, capacitance=10e-12)
    """

    def __init__(
        self,
        *,
        resistance: pft.Resistance | None = None,
        inductance: pft.Inductance | None = None,
        capacitance: pft.Capacitance | None = None,
        port_map: PortMap | None = None,
    ) -> None:
        super().__init__(
            resistance=resistance,
            inductance=inductance,
            capacitance=capacitance,
            port_map=port_map,
        )

    def start_mna(
        self, component: Component | None, frequencies: list[float], **kwargs: object
    ) -> MNAMatrix:
        resistance = self.parametric_kwargs["resistance"]
        inductance = self.parametric_kwargs["inductance"]
        capacitance = self.parametric_kwargs["capacitance"]

        # Chain: t1 --[R]-- _r --[L branch]-- _l --[C]-- t2
        # Determine which internal nodes exist.
        has_r = resistance is not None and resistance > 0
        has_l = inductance is not None and inductance > 0
        has_c = capacitance is not None and capacitance > 0

        if not (has_r or has_l or has_c):
            raise ValueError(
                "SeriesRLC with no valid elements is a zero-impedance wire. Use a direct "
                "connection instead."
            )

        omega = 2 * np.pi * np.array(frequencies)
        n = len(frequencies)
        elements: dict[tuple[str, str], np.ndarray] = {}

        # Node names at boundaries of each element
        left = "t1"
        if has_r:
            right_r = "_r" if (has_l or has_c) else "t2"
            G = 1.0 / resistance
            _add_admittance_stamp(elements, left, right_r, np.full(n, G, dtype=complex))
            left = right_r

        if has_l:
            right_l = "_l" if has_c else "t2"
            _add_inductor_branch_stamp(elements, left, right_l, "_I_L", omega, inductance)
            left = right_l

        if has_c:
            Y_C = 1j * omega * capacitance
            _add_admittance_stamp(elements, left, "t2", Y_C)
        elif left != "t2":
            # No C and left hasn't reached t2 yet -- direct wire.
            # This only happens when R=0, L=0, C=None which is caught above.
            pass

        return MNAMatrix(frequencies, elements)


class ParallelRLC(LumpedModel):
    r"""Parallel RLC circuit between two terminals.

    Admittance :math:`Y = \frac{1}{R} + \frac{1}{j\omega L} + j\omega C`.
    All stamps are between terminals directly.  The inductor adds an
    auxiliary branch current.

    Circuit diagram::

                    R
        t1 ---+---/\/\/---+--- t2
              |     L      |
              +---nnnnn----+
              |     C      |
              +-----||-----+

    Args:
        resistance: Resistance. Only used if positive.
        inductance: Inductance. Only used if positive.
        capacitance: Capacitance. Only used if positive.
        port_map: Port mappings from terminals (see :class:`LumpedModel`).

    Example:
        >>> # Parallel LC tank at 1 GHz
        >>> tank = pf.ParallelRLC(inductance=2.5e-9, capacitance=10e-12)
    """

    def __init__(
        self,
        *,
        resistance: pft.Resistance | None = None,
        inductance: pft.Inductance | None = None,
        capacitance: pft.Capacitance | None = None,
        port_map: PortMap | None = None,
    ) -> None:
        super().__init__(
            resistance=resistance,
            inductance=inductance,
            capacitance=capacitance,
            port_map=port_map,
        )

    def start_mna(
        self, component: Component | None, frequencies: list[float], **kwargs: object
    ) -> MNAMatrix:
        resistance = self.parametric_kwargs["resistance"]
        inductance = self.parametric_kwargs["inductance"]
        capacitance = self.parametric_kwargs["capacitance"]

        has_r = resistance is not None and resistance > 0
        has_l = inductance is not None and inductance > 0
        has_c = capacitance is not None and capacitance > 0

        if not (has_r or has_l or has_c):
            raise ValueError("ParallelRLC must have at least one valid element.")

        omega = 2 * np.pi * np.array(frequencies)
        n = len(frequencies)
        elements: dict[tuple[str, str], np.ndarray] = {}

        if has_r:
            G = 1.0 / resistance
            _add_admittance_stamp(elements, "t1", "t2", np.full(n, G, dtype=complex))

        if has_l:
            _add_inductor_branch_stamp(elements, "t1", "t2", "_I_L", omega, inductance)

        if has_c:
            Y_C = 1j * omega * capacitance
            _add_admittance_stamp(elements, "t1", "t2", Y_C)

        return MNAMatrix(frequencies, elements)


class IdealTransmissionLine(LumpedModel):
    r"""Lossless transmission line.

    Represented by the ABCD matrix:

    .. math:: S = \begin{bmatrix}
                          \cos(\beta\ell)       &  j Z_0 \sin(\beta\ell) \\
                    j Z_0^{-1} \sin(\beta\ell)  &     \cos(\beta\ell)
                  \end{bmatrix}

    Uses ABCD-to-MNA stamp with two branch currents and no singularities at
    any frequency.

    Circuit diagram::

        t1 =====[Z₀, βl]===== t2

    Args:
        z0: Characteristic impedance Z₀.
        length: Physical length.
        velocity: Phase velocity.
        port_map: Port mappings from terminals (see :class:`LumpedModel`).

    Example:
        >>> # Quarter-wave transformer at 10 GHz
        >>> wavelength = pf.C_0 / 10e9  # 3 cm
        >>> tline = pf.IdealTransmissionLine(
        ...     characteristic_impedance=70.7,
        ...     length=wavelength / 4,
        ... )
    """

    def __init__(
        self,
        *,
        z0: pft.Resistance,
        length: pft.Dimension,
        velocity: pft.Velocity = C_0,
        port_map: PortMap | None = None,
    ) -> None:
        super().__init__(
            z0=z0,
            length=length,
            velocity=velocity,
            port_map=port_map,
        )
        if z0 <= 0:
            raise ValueError("IdealTransmissionLine characteristic impedance must be positive.")
        if length < 0:
            raise ValueError("IdealTransmissionLine length may not be negative.")
        if velocity <= 0:
            raise ValueError("IdealTransmissionLine velocity must be positive.")

    def start_mna(
        self, component: Component | None, frequencies: list[float], **kwargs: object
    ) -> MNAMatrix:
        z0 = self.parametric_kwargs["z0"]
        length = self.parametric_kwargs["length"]
        velocity = self.parametric_kwargs["velocity"]
        omega = 2 * np.pi * np.array(frequencies)
        theta = omega * length / velocity
        a = np.cos(theta)
        b = 1j * z0 * np.sin(theta)
        c = 1j * np.sin(theta) / z0
        d = np.cos(theta)
        n = len(frequencies)
        ones = np.full(n, 1.0, dtype=complex)
        elements = {
            ("t1", "_I1"): ones,
            ("t2", "_I2"): ones,
            ("_I1", "t1"): ones,
            ("_I1", "t2"): -a,
            ("_I1", "_I2"): b,
            ("_I2", "_I1"): ones,
            ("_I2", "t2"): -c,
            ("_I2", "_I2"): d,
        }
        return MNAMatrix(frequencies, elements)


class IdealTransformer(LumpedModel):
    """Ideal transformer with turns ratio n:1.

    Constraint equations: :math:`V(p_1) - V(p_2) = n (V(s_1) - V(s_2))`,
    :math:`I_p = -n I_s`. Uses a pure constraint stamp with one auxiliary
    branch current. No impedance entries on the diagonal; no singularities
    at any frequency including DC.

    Circuit diagram (4-terminal, floating)::

                n:1
        p1 ---.° || °,--- s1
               ) || (
               ) || (
               ) || (
        p2 ---'  ||  '--- s2

    Args:
        turns_ratio: Turns ratio :math:`n` between primary and secondary.
        port_map: Port mappings from terminals (see :class:`LumpedModel`).

    Terminals:
    - ``p1``: Primary positive terminal
    - ``p2``: Primary negative terminal
    - ``s1``: Secondary positive terminal
    - ``s2``: Secondary negative terminal

    Note:
        Use differential port mapping to extract 2-port S-parameters:

        >>> port_map = {
        ...     "primary": ("p1", "p2", 50.0),
        ...     "secondary": ("s1", "s2", 50.0),
        ... }

    Example:
        >>> # 2:1 step-down transformer
        >>> xfmr = pf.IdealTransformer(turns_ratio=2.0)
    """

    def __init__(self, *, turns_ratio: pft.PositiveFloat, port_map: PortMap | None = None) -> None:
        super().__init__(turns_ratio=turns_ratio, port_map=port_map)
        if turns_ratio <= 0:
            raise ValueError("Turns ratio must be positive.")

    def start_mna(
        self, component: Component | None, frequencies: list[float], **kwargs: object
    ) -> MNAMatrix:
        n_freq = len(frequencies)
        ones = np.full(n_freq, 1.0, dtype=complex)
        n = self.parametric_kwargs["turns_ratio"]
        elements = {
            ("p1", "_Ip"): ones,
            ("p2", "_Ip"): -ones,
            ("s1", "_Ip"): -n * ones,
            ("s2", "_Ip"): n * ones,
            ("_Ip", "p1"): ones,
            ("_Ip", "p2"): -ones,
            ("_Ip", "s1"): -n * ones,
            ("_Ip", "s2"): n * ones,
        }
        return MNAMatrix(frequencies, elements)


def _add_to(
    elements: dict[tuple[str, str], np.ndarray],
    key: tuple[str, str],
    values: np.ndarray,
) -> None:
    if key in elements:
        elements[key] = elements[key] + values
    else:
        elements[key] = values


def _add_inductor_branch_stamp(
    elements: dict[tuple[str, str], np.ndarray],
    n1: str,
    n2: str,
    branch: str,
    omega: np.ndarray,
    L: float,
) -> None:
    ones = np.full(len(omega), 1.0, dtype=complex)
    _add_to(elements, (n1, branch), ones)
    _add_to(elements, (branch, n1), ones)
    _add_to(elements, (n2, branch), -ones)
    _add_to(elements, (branch, n2), -ones)
    elements[(branch, branch)] = -1j * omega * L


def _add_admittance_stamp(
    elements: dict[tuple[str, str], np.ndarray],
    n1: str,
    n2: str,
    Y: np.ndarray,
) -> None:
    _add_to(elements, (n1, n1), Y)
    _add_to(elements, (n1, n2), -Y)
    _add_to(elements, (n2, n1), -Y)
    _add_to(elements, (n2, n2), Y)


register_model_class(Resistor)
register_model_class(Capacitor)
register_model_class(Inductor)
register_model_class(SeriesRLC)
register_model_class(ParallelRLC)
register_model_class(IdealTransmissionLine)
register_model_class(IdealTransformer)
