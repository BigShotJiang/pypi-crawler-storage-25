from collections.abc import Sequence

import numpy

from ..extension import (
    Component,
    Interpolator,
    Model,
    Path,
    Port,
    PortSpec,
    Rectangle,
    SMatrix,
    Technology,
    config,
    frequency_classification,
    register_model_class,
)
from ..typing import (
    Frequency,
    Loss,
    PositiveDimension,
    PositiveFloat,
    Temperature,
    TimeDelay,
    annotate,
)
from ..utils import C_0
from .analytic import _add_bb_text, _bb_layer

Order = annotate(float, minimum=1)


class MuxDemuxModel(Model):
    """Single-mode, wavelength multiplexer demultiplexer (WDM).

    Args:
        frequencies: Central frequency for each channel. Use only one of
          ``frequencies`` or ``wavelengths``.
        wavelengths: Central wavelength for each channel. Use only one of
          ``frequencies`` or ``wavelengths``.
        bandwidth: 3dB frequency bandwidth for each channel when used with
          ``frequencies`` (in Hz). When ``wavelengths`` is used, this is the
          3dB wavelength bandwidth for each channel in (μm).
        order: Order of the super-Gaussian pulse.
        insertion_loss: Insertion loss per channel.
        group_delay: Constant group delay per channel.
        reflection: Reflection coefficient for incident fields. If a
          sequence of values is used, the first one is for the common port
          and the remaining are for the frequency-filtered ports.
        temperature_sensitivity: Temperature sensitivity for central
          frequencies (in Hz/K) or wavelengths (in μm/K).
        temperature: Operating temperature.
        reference_temperature: Reference temperature.
        ports: List of port names. If not set, the *sorted* list of port
          names from the component is used.

    Note:
        Sequences of values can be used to set different parameters per
        channel. All lenghts must match the number of channels (defined by
        ``frequencies`` or ``wavelengths``), except for ``reflection`` and
        ``ports``, which must include 1 additional entry for the common
        port (first item in each sequence).
    """

    def __init__(
        self,
        *,
        frequencies: Sequence[Frequency] = (),
        wavelengths: Sequence[PositiveDimension] = (),
        bandwidth: PositiveFloat | Sequence[PositiveFloat] = (),
        order: Order | Sequence[Order] = 4,
        insertion_loss: Loss | Sequence[Loss] = 0,
        group_delay: TimeDelay | Sequence[TimeDelay] = 0,
        reflection: complex | Interpolator | Sequence[complex | Interpolator] = 0,
        temperature_sensitivity: annotate(float | Sequence[float], units="*/K") = 0.0,
        temperature: Temperature = 293.0,
        reference_temperature: Temperature = 293.0,
        ports: Sequence[str] | None = None,
    ) -> None:
        super().__init__(
            frequencies=frequencies,
            wavelengths=wavelengths,
            bandwidth=bandwidth,
            order=order,
            insertion_loss=insertion_loss,
            group_delay=group_delay,
            reflection=reflection,
            temperature_sensitivity=temperature_sensitivity,
            temperature=temperature,
            reference_temperature=reference_temperature,
            ports=ports,
        )
        if (len(frequencies) == 0) == (len(wavelengths) == 0):
            if len(frequencies) == 0:
                raise RuntimeError("Either 'frequencies' or 'wavelengths' must be specified.")
            else:
                raise RuntimeError(
                    "Both 'frequencies' and 'wavelengths' specified. Please set one or the other."
                )

    def black_box_component(
        self,
        port_spec: str | PortSpec | None = None,
        technology: Technology | None = None,
        name: str | None = None,
    ) -> Component:
        """Create a black-box component using this model for testing.

        Args:
            port_spec: Port specification used in the component. If ``None``,
              look for ``"port_spec"`` in :attr:`config.default_kwargs`.
            technology: Component technology. If ``None``, the default
              technology is used.
            name: Component name. If ``None`` a default is used.

        Returns:
            Component with ports and model.
        """
        model_name = self.__class__.__name__[:-5]
        component = Component(f"BB{model_name}" if name is None else name, technology=technology)
        component.properties.__thumbnail__ = "wdm"

        if port_spec is None:
            port_spec = config.default_kwargs.get("port_spec")
            if port_spec is None:
                raise RuntimeError("Missing argument 'port_spec'.")
        if isinstance(port_spec, str):
            name = port_spec
            port_spec = component.technology.ports.get(port_spec)
            if port_spec is None:
                raise RuntimeError(f"Port spec '{name}' not found in component's technology.")

        p = self.parametric_kwargs
        n = max(len(p["frequencies"]), len(p["wavelengths"]))

        width = port_spec.width
        length = max(1, n) * 2 * width
        outs = [(i * 2 - n + 1) * width for i in range(n)]

        profiles = port_spec.path_profiles_list()
        if len(profiles) == 0:
            profiles = [(width, 0, _bb_layer)]

        for w, g, layer in profiles:
            component.add(
                layer,
                Rectangle(center=(3 * width, 0), size=(2 * width, length)),
                Path((0, 0), w, g).segment((2 * width, 0)),
                *(Path((4 * width, y), w, g).segment((6 * width, y)) for y in outs),
            )

        _add_bb_text(component, width)

        port_names = self.parametric_kwargs["ports"] or [None] * (n + 1)
        if len(port_names) < n + 1:
            port_names += [None] * (n + 1 - len(port_names))

        component.add_port(Port((0, 0), 0, port_spec), port_names[0])
        for port_name, y in zip(port_names[1:], outs, strict=True):
            component.add_port(Port((6 * width, y), 180, port_spec.inverted()), port_name)

        component.add_model(self, model_name)
        return component

    def start(
        self,
        component: Component,
        frequencies: Sequence[float],
        temperature: Temperature | None = None,
        **kwargs: object,
    ) -> SMatrix:
        """Start computing the S matrix response from a component.

        Args:
            component: Component from which to compute the S matrix.
            frequencies: Sequence of frequencies at which to perform the
              computation.
            temperature: Operating temperature override.
            **kwargs: Unused.

        Returns:
           Model result with attributes ``status`` and ``s_matrix``.
        """
        frequencies = numpy.array(frequencies)

        p = self.parametric_kwargs
        n = max(len(p["frequencies"]), len(p["wavelengths"]))

        classification = frequency_classification(frequencies)
        component_ports = {
            name: port.copy(True) for name, port in component.select_ports(classification).items()
        }
        if len(component_ports) != n + 1:
            raise RuntimeError(
                f"MuxDemuxModel specified with {n} channels requires a component with {n + 1} "
                "ports. '{component.name}' has {len(component_ports)} {classification} ports."
            )

        names = p["ports"]
        if names is None:
            names = sorted(component_ports)
        elif not all(name in component_ports for name in names):
            raise RuntimeError(
                f"Not all port names defined in MuxDemuxModel match the "
                f"{classification} port names in component '{component.name}'."
            )

        centers = numpy.array(p["frequencies"])
        if len(centers) == 0:
            centers = numpy.array(p["wavelengths"])
            reference_frequency = 0.5 * (C_0 / centers.max() + C_0 / centers.min())
            samples = C_0 / frequencies.reshape(-1, 1)
        else:
            reference_frequency = 0.5 * (centers.max() + centers.min())
            samples = frequencies.reshape(-1, 1)

        if temperature is None:
            temperature = p["temperature"]
        centers += numpy.array(p["temperature_sensitivity"], ndmin=1) * (
            temperature - p["reference_temperature"]
        )

        bandwidth = numpy.array(p["bandwidth"], ndmin=1)
        if bandwidth.size == 0:
            i = numpy.argsort(centers)
            j = numpy.argsort(i)  # inverse
            x = centers[i]
            bounds = numpy.hstack(([-numpy.inf], 0.5 * (x[:-1] + x[1:]), [numpy.inf]))
            bandwidth = 2 * numpy.minimum(x - bounds[:-1], bounds[1:] - x)[j]

        amp = 10.0 ** (numpy.array(p["insertion_loss"], ndmin=1) / -20.0)
        envelope = numpy.exp(
            -0.5 * numpy.log(2.0) * (2.0 * abs(samples - centers) / bandwidth) ** p["order"]
        )
        # Normalize overlapping channel envelopes so total power never exceeds
        # unity.  Applied before insertion loss so passivity holds regardless of
        # the loss value.  Using numpy.maximum avoids discontinuities in the
        # envelope shape.
        total_power = numpy.sum(envelope**2, axis=1, keepdims=True)
        envelope /= numpy.sqrt(numpy.maximum(total_power, 1.0))
        phase = numpy.exp(
            2.0j
            * numpy.pi
            * (frequencies.reshape(-1, 1) - reference_frequency)
            * numpy.array(p["group_delay"], ndmin=1)
        )
        s = amp * envelope * phase

        elements = {(f"{names[0]}@0", f"{name}@0"): s[:, i] for i, name in enumerate(names[1:])}

        reflection = numpy.array(self.parametric_kwargs["reflection"], ndmin=1)
        if reflection.size == 1:
            r = (
                reflection[0](frequencies)
                if isinstance(reflection[0], Interpolator)
                else numpy.broadcast_to(reflection[0], frequencies.shape)
            )
            elements.update({(f"{name}@0", f"{name}@0"): r for name in names})
        else:
            for name, r in zip(names, reflection, strict=True):
                elements[f"{name}@0", f"{name}@0"] = (
                    r(frequencies)
                    if isinstance(r, Interpolator)
                    else numpy.broadcast_to(r, frequencies.shape)
                )

        return SMatrix(frequencies, elements, component_ports).force_symmetric()


register_model_class(MuxDemuxModel)
