from __future__ import annotations

from collections.abc import Callable, Iterable, Iterator, Sequence
from typing import Literal

import tidy3d
from numpy import ndarray
from tidy3d.components.medium import MediumType
from tidy3d.plugins.mode import ModeSolver

Z_INF: float
Z_MAX: float
_component_registry: dict[str, object]
_local_tidy3d_solver: bool
_model_registry: dict[str, object]
_technology_registry: dict[str, object]
_time_stepper_registry: dict[str, object]
config: object

def _auto_scale_from_refinement(*args: object) -> object: ...
def _connect_s_matrices(*args: object) -> object: ...
def _content_repr(*args: object, include_config: object = True) -> object: ...
def _export(
    *args: object, filename: str | None = None, use_json: bool = False
) -> dict[str, object] | tuple[dict[str, object], bytes]: ...
def _from_bytes(obj: object) -> object: ...
def _import(
    filename: str | None = None,
    byte_repr: bytes | None = None,
    set_config: bool = False,
    use_json: bool = False,
) -> tuple[list[object], dict[str, object]]: ...
def _layer_steps_from_refinement(*args: object) -> object: ...
def _make_layer_refinement_spec(*args: object) -> object: ...
def _manhatan_path(*args: object) -> object: ...
def _pack_rectangles(*args: object) -> object: ...
def _prbs15(*args: object, **kwargs: object) -> object: ...
def _prbs31(*args: object, **kwargs: object) -> object: ...
def _prbs7(*args: object, **kwargs: object) -> object: ...
def _route(*args: object) -> object: ...
def _store_type(type_id: str | int) -> str | int: ...
def apodized_focused_grating(
    teeth_gaps: float | Sequence[float],
    teeth_widths: float | Sequence[float],
    n_eff: float | Sequence[float],
    n_sin: float,
    focal_length: float,
    width: float | None = None,
    angle: float | None = None,
    input_width: float | None = None,
) -> list[Circle | Polygon]: ...
def apodized_grating(
    teeth_gaps: float | Sequence[float],
    teeth_widths: float | Sequence[float],
    width: float,
    taper_length: float,
    taper_width: float,
) -> list[Rectangle | Polygon]: ...
def basic_technology(
    *,
    core_medium: MediumType | dict[Literal["optical", "electrical"], MediumType] | None = None,
    clad_medium: MediumType | dict[Literal["optical", "electrical"], MediumType] | None = None,
    trench_medium: MediumType | dict[Literal["optical", "electrical"], MediumType] | None = None,
    metal_medium: MediumType | dict[Literal["optical", "electrical"], MediumType] | None = None,
    top_medium: MediumType | dict[Literal["optical", "electrical"], MediumType] | None = None,
    substrate_medium: MediumType | dict[Literal["optical", "electrical"], MediumType] | None = None,
    core_thickness: float = 0.22,
    slab_thickness: float = 0.07,
    metal_thickness: float = 0.5,
    metal_separation: float = 1.5,
    clad_thickness: float = 1.5,
    box_thickness: float = 2.0,
    port_z_gap: float = 1.0,
    core_layer: tuple[int, int] = (2, 0),
    slab_layer: tuple[int, int] = (3, 0),
    clad_layer: tuple[int, int] = (1, 0),
    trench_layer: tuple[int, int] = (4, 0),
    metal_layer: tuple[int, int] = (5, 0),
    strip_width: float = 0.5,
    rib_width: float = 0.4,
    clad_width: float = 1.0,
    cpw_width: float = 3.6,
    cpw_gap: float = 1.0,
    mask_dilation: float = 0,
    sidewall_angle: float = 0,
    core_fill: bool = False,
    core_thickness_stdev: float = 0.002,
    slab_thickness_stdev: float = 0.005,
    clad_thickness_stdev: float = 0.05,
    box_thickness_stdev: float = 0.05,
    mask_dilation_stdev: float = 0.005,
    sidewall_angle_stdev: float = 2,
) -> Technology: ...
def boolean(
    operand1: Rectangle
    | Circle
    | Polygon
    | Path
    | Component
    | Reference
    | Iterable[Rectangle | Circle | Polygon | Path | Component | Reference],
    operand2: Rectangle
    | Circle
    | Polygon
    | Path
    | Component
    | Reference
    | Iterable[Rectangle | Circle | Polygon | Path | Component | Reference],
    operation: Literal["+", "*", "-", "^"],
) -> list[Polygon]: ...
def cross(arm_length: float, arm_width: float) -> Polygon: ...
def envelope(
    operand: Rectangle
    | Circle
    | Polygon
    | Path
    | Component
    | Reference
    | Iterable[Rectangle | Circle | Polygon | Path | Component | Reference],
    offset: float = 0,
    trim_x_min: bool = False,
    trim_x_max: bool = False,
    trim_y_min: bool = False,
    trim_y_max: bool = False,
    round_joins: bool = False,
    use_box: bool = False,
) -> Polygon: ...
def find_top_level(*components: Component) -> list[Component]: ...
def focused_grating(
    wavelength: float,
    period: float,
    n_sin: float,
    focal_length: float,
    length: float,
    width: float | None = None,
    angle: float | None = None,
    input_width: float | None = None,
    fill_factor: float | str | Expression = 0.5,
) -> list[Circle | Polygon]: ...
def frequency_classification(
    frequencies: float | Sequence[float],
) -> Literal["electrical", "optical"]: ...
def grating(
    period: float,
    num_periods: int,
    width: float,
    fill_factor: float | str | Expression = 0.5,
    taper_length: float = 0,
    taper_width: float = 0,
) -> list[Rectangle | Polygon]: ...
def grid_ceil(
    value: float | Sequence[float] | Sequence[Sequence[float]],
    grid: float | None = None,
    multiple: int = 1,
) -> float | ndarray: ...
def grid_floor(
    value: float | Sequence[float] | Sequence[Sequence[float]],
    grid: float | None = None,
    multiple: int = 1,
) -> float | ndarray: ...
def heal(
    operand: Rectangle
    | Circle
    | Polygon
    | Path
    | Component
    | Reference
    | Iterable[Rectangle | Circle | Polygon | Path | Component | Reference],
    feature_size: float,
) -> list[Polygon]: ...
def linear_taper(length: float, widths: Sequence[float] | float) -> Polygon: ...
def load_full_phf(filename: str, set_config: bool = True) -> tuple[object]: ...
def load_layout(
    filename: str,
    technology: Technology | None = None,
    layers: Iterable[tuple[int, int] | str] = [],
    cell_names: Iterable[str] = [],
    library_properties: bool = False,
    post_load_function: Callable[[Component], object] | None = None,
) -> dict[str, Component] | tuple[dict[str, Component], Properties]: ...
def load_phf(
    filename: str, only_explicit: bool = True, set_config: bool = True
) -> dict[Literal["components", "technologies"], list[Component] | list[Technology]]: ...
def load_snp(filename: str) -> tuple[ndarray, ndarray]: ...
def mmi(
    length: float,
    width: float,
    num_ports: int | Sequence[int],
    port_length: float | Sequence[float],
    port_width: float | Sequence[float],
    tapered_width: float | Sequence[float] | None = None,
    port_separation: float | Sequence[float] | None = None,
) -> list[Rectangle | Polygon]: ...
def offset(
    operand: Rectangle
    | Circle
    | Polygon
    | Path
    | Component
    | Reference
    | Iterable[Rectangle | Circle | Polygon | Path | Component | Reference],
    distance: float,
    round_joins: bool = False,
    trim_x_min: bool = False,
    trim_x_max: bool = False,
    trim_y_min: bool = False,
    trim_y_max: bool = False,
) -> list[Polygon]: ...
def pole_residue_fit(
    s_matrix: SMatrix,
    initial_poles: Sequence[complex] = (),
    min_poles: int = 0,
    max_poles: int = 30,
    loss_factor: float = 0.001,
    rms_error_tolerance: float = 0.0001,
    max_iterations: int = 100,
    max_stale_iterations: int = 3,
    real: bool = False,
    passive: bool = True,
    feedthrough: bool = False,
    delays: Literal["auto"] | dict[tuple[str, str], float] | float = 0,
    stable: bool = True,
    silence_warnings: bool = False,
) -> tuple[PoleResidueMatrix, float]: ...
def register_model_class(*model_classes: Model) -> None: ...
def register_time_stepper_class(*time_stepper_classes: TimeStepper) -> None: ...
def ruler(
    unit: float,
    minor_marker_length: float,
    marker_width: float,
    num_markers: int = 11,
    medium_marker_steps: int = 5,
    medium_marker_length: float = 0,
    major_marker_steps: int = 10,
    major_marker_length: float = 0,
    triangular_marker: bool = False,
) -> list[Rectangle | Polygon]: ...
def s_bend_length(offset: float, radius: float | None = None, meander: bool = True) -> float: ...
def s_matrix(
    component: Component | Callable[..., Component],
    frequencies: Sequence[float],
    *variables: RandomVariable | tuple[object, ...],
    show_progress: bool = True,
    random_samples: int = 0,
    corner_samples: int = 0,
    corner_coverage: float = 0.95,
    random_seed: int | None = None,
    parallel_jobs: int = 0,
    chain_technology_updates: bool = True,
    chain_component_updates: bool = True,
    component_args: tuple[object, ...] = (),
    component_kwargs: dict[str, object] = {},
    model_kwargs: dict[str, object] = {},
    callback_fn: Callable[[Component, tuple[object, ...]], object] | None = None,
) -> tuple[list[RandomVariable], list[SMatrix]]: ...
def s_to_y_matrix(
    s_matrix: SMatrix, impedances: complex | float | dict[str, complex | float] = 50.0
) -> YMatrix: ...
def s_to_z_matrix(
    s_matrix: SMatrix, impedances: complex | float | dict[str, complex | float] = 50.0
) -> ZMatrix: ...
def set_unique_names(*components: Component) -> list[Component]: ...
def snap_to_grid(
    value: float | Sequence[float] | Sequence[Sequence[float]],
    grid: float | None = None,
    multiple: int = 1,
) -> float | ndarray: ...
def text(
    text_string: str,
    size: float,
    origin: Sequence[float] | complex = (0, 0),
    rotation: float = 0,
    x_reflection: bool = False,
    typeface: Literal[0, 1] = 0,
) -> list[Polygon]: ...
def tidy3d_structures_from_layout(
    filename: str,
    technology: Technology | None = None,
    cell_name: str | None = None,
    classification: Literal["optical", "electrical"] = "optical",
) -> list[tidy3d.Structure]: ...
def vernier_scale(
    unit: float,
    marker_length: float,
    marker_width: float,
    divider: int = 10,
    gap: float = 0,
    triangular_marker: bool = False,
) -> tuple[list[Rectangle | Polygon], list[Rectangle | Polygon]]: ...
def write_layout(
    filename: str,
    *components: Component,
    paths_to_polygons: bool = True,
    compression_level: int = 9,
    fracture_limit: int = 0,
    library_name: str = "LIBRARY",
    library_properties: Properties | None = None,
    pre_export_function: Callable[[Component], object] | None = None,
) -> object: ...
def write_phf(filename: str, *args: object) -> object: ...
def y_to_s_matrix(
    y_matrix: YMatrix, impedances: complex | float | dict[str, complex | float] = 50.0
) -> SMatrix: ...
def y_to_z_matrix(y_matrix: YMatrix) -> ZMatrix: ...
def z_to_s_matrix(
    z_matrix: ZMatrix, impedances: complex | float | dict[str, complex | float] = 50.0
) -> SMatrix: ...
def z_to_y_matrix(z_matrix: ZMatrix) -> YMatrix: ...

class Circle:
    def __init__(
        self,
        radius: float | Sequence[float] | complex,
        center: Sequence[float] | complex = (0, 0),
        inner_radius: float | Sequence[float] | complex | None = None,
        sector: Sequence[float] | complex = (0, 0),
        rotation: float = 0,
        min_evals: int = 0,
    ) -> None: ...
    def __copy__(self, /) -> Circle: ...
    def __deepcopy__(self, *args: object, **kwargs: object) -> Circle: ...
    def __getstate__(self, /) -> object: ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def _repr_svg_(self) -> str: ...
    def add_gds_property(self, attribute: int, value: str) -> object: ...
    def area(self) -> float: ...
    def bounds(self) -> tuple[ndarray, ndarray]: ...
    def copy(self) -> Circle: ...
    def mirror(
        self,
        axis_endpoint: Sequence[float] | complex = (1, 0),
        axis_origin: Sequence[float] | complex = (0, 0),
    ) -> Circle: ...
    def perimeter(self) -> float: ...
    def rotate(
        self, rotation: float, center: Sequence[float, float] | complex = (0, 0)
    ) -> Circle: ...
    def scale(
        self, scaling: float, center: Sequence[float, float] | complex = (0, 0)
    ) -> Circle: ...
    def to_polygon(self) -> Polygon: ...
    def transform(
        self,
        translation: Sequence[float, float] | complex = (0, 0),
        rotation: float = 0,
        scaling: float = 1,
        x_reflection: bool = False,
    ) -> Circle: ...
    def translate(self, translation: Sequence[float, float] | complex) -> Circle: ...
    _id: object
    center: ndarray
    inner_radius: ndarray
    min_evals: int
    properties: Properties
    radius: ndarray
    rotation: float
    sector: ndarray
    x_max: float
    x_mid: float
    x_min: float
    y_max: float
    y_mid: float
    y_min: float

class Component:
    def __init__(self, name: str = "", technology: Technology | None = None) -> None: ...
    def __copy__(self, /) -> Component: ...
    def __deepcopy__(self, *args: object, **kwargs: object) -> Component: ...
    def __getitem__(self, key: object, /) -> object: ...
    def __getstate__(self, /) -> object: ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def _repr_svg_(self, partial: bool = False) -> str: ...
    def activate_model(
        self,
        model_name: str,
        classification: Literal["optical", "electrical"] | None = None,
    ) -> Model: ...
    def add(
        self,
        *args: str
        | tuple[int, int]
        | Polygon
        | Rectangle
        | Circle
        | Path
        | Label
        | Reference
        | Component,
    ) -> Component: ...
    def add_model(
        self,
        model: Model | Sequence[Model],
        model_name: str | None = None,
        set_active: bool | Literal["optical", "electrical"] = True,
    ) -> str | list[str]: ...
    def add_port(
        self,
        port: Port
        | FiberPort
        | GaussianPort
        | dict[str, Port | FiberPort | GaussianPort]
        | Sequence[Port | FiberPort | GaussianPort],
        port_name: str | None = None,
    ) -> str | list[str]: ...
    def add_reference(self, reference: Reference | Component) -> Reference: ...
    def add_reference_ports(
        self, include_dependencies: bool = False, add_model: Model | None = None
    ) -> list[str]: ...
    def add_terminal(
        self,
        terminal: Terminal | dict[str, Terminal] | Sequence[Terminal],
        terminal_name: str | None = None,
        add_structure: bool = False,
        structure_layer: str | tuple[int, int] | None = None,
    ) -> str | list[str]: ...
    def add_virtual_connection(
        self,
        reference0: Reference,
        port_name0: str,
        reference1: Reference,
        port_name1: str,
        repetition_index0: int = 0,
        repetition_index1: int = 0,
    ) -> Component: ...
    def add_virtual_connection_by_instance(
        self,
        instance_index0: int,
        port_name0: str,
        instance_index1: int,
        port_name1: str,
    ) -> Component: ...
    def bounds(
        self,
        include_ports: bool = True,
        include_labels: bool = True,
        layers: Iterable[str | tuple[int, int]] | None = None,
    ) -> tuple[ndarray, ndarray]: ...
    def build_mask(
        self, mask_spec: MaskSpec | str | tuple[int, int], heal: bool | float = False
    ) -> list[Polygon]: ...
    def center(self, include_ports: bool = True, include_labels: bool = True) -> ndarray: ...
    def convex_hull(
        self,
        include_labels: bool = True,
        layers: Iterable[str | tuple[int, int]] | None = None,
    ) -> ndarray: ...
    def copy(self, deep: bool = False, copy_technology: bool = False) -> Component: ...
    def dependencies(self) -> list[Component]: ...
    def detect_dependency_cycle(self) -> Component | None: ...
    def detect_ports(
        self,
        specs: Iterable[PortSpec] | None = None,
        bounds: tuple[tuple[float]] | ndarray | None = None,
        skip_internal_connections: bool = True,
        on_boundary: Literal["xy", "x", "+x", "-x", "y", "+y", "-y"] | None = None,
        boundary_margin: float = 0,
        minimal_turn_angle: float = 10,
    ) -> list[Port]: ...
    def disconnected_reference_ports(self) -> list[Port | FiberPort | GaussianPort]: ...
    def extrude(
        self,
        port_extension: float = 0,
        heal: bool | float = False,
        extrusion_tolerance: float = 0,
        classification: Literal["optical", "electrical"] = "optical",
        used_extrusions: list | None = None,
    ) -> list[Polyhedron | Extruded | ConstructiveSolid]: ...
    def filter_label_layers(
        self,
        layers: Iterable[str | tuple[int, int]],
        keep: bool,
        include_dependencies: bool = False,
    ) -> Component: ...
    def filter_layers(
        self,
        layers: Iterable[str | tuple[int, int]],
        keep: bool,
        include_dependencies: bool = False,
    ) -> Component: ...
    def flatten(self) -> Component: ...
    def get_instance_maps(
        self,
    ) -> tuple[dict[tuple[int, int], int], list[tuple[int, int]]]: ...
    def get_labels(
        self,
        layer: str | tuple[int, int] | None = None,
        depth: int = -1,
        skip_components: Iterable[str | Component] = (),
    ) -> list[Label] | dict[tuple[int, int], Label]: ...
    def get_netlist(
        self, include_virtual_connections: bool = True, *, suppress_warnings: bool = False
    ) -> dict[str, object]: ...
    def get_structures(
        self,
        layer: str | tuple[int, int] | None = None,
        depth: int = -1,
        skip_components: Iterable[str | Component] = (),
    ) -> (
        list[Rectangle | Circle | Polygon | Path]
        | dict[tuple[int, int], Rectangle | Circle | Polygon | Path]
    ): ...
    def invalid_virtual_connections(
        self,
    ) -> list[tuple[tuple[Reference, str, int], tuple[Reference, str, int]]]: ...
    def label_count(self) -> int: ...
    def layers(
        self,
        include_dependencies: bool = False,
        include_structures: bool = True,
        include_labels: bool = True,
    ) -> set[tuple[int, int]]: ...
    def query(
        self, *args: str | int | None
    ) -> (
        Port
        | FiberPort
        | GaussianPort
        | Terminal
        | list[Port | FiberPort | GaussianPort | Terminal]
    ): ...
    def remap_label_layers(
        self,
        layer_map: dict[str | tuple[int, int], str | tuple[int, int]],
        include_dependencies: bool = False,
    ) -> Component: ...
    def remap_layers(
        self,
        layer_map: dict[str | tuple[int, int], str | tuple[int, int]],
        include_dependencies: bool = False,
    ) -> Component: ...
    def remove(
        self,
        *args: Polygon | Rectangle | Circle | Path | Label | Reference,
        layer: str | tuple[int] | None = None,
    ) -> Component: ...
    def remove_model(self, model_name: str) -> Model | None: ...
    def remove_port(self, port_name: str) -> Port | FiberPort | GaussianPort | None: ...
    def remove_terminal(
        self, terminal_name: str, remove_structure: bool = True
    ) -> Terminal | None: ...
    def remove_virtual_connection(
        self, reference: Reference, port_name: str, repetition_index: int = 0
    ) -> bool: ...
    def remove_virtual_connection_by_instance(
        self, instance_index: int, port_name: str
    ) -> bool: ...
    def rename_model(self, old_model_name: str, new_model_name: str) -> Component: ...
    def rename_port(self, old_name: str, new_name: str) -> Component: ...
    def rename_terminal(self, old_name: str, new_name: str) -> Component: ...
    def replace_technology(
        self, new_technology: Technology, old_technology: Technology | None = None
    ) -> Component: ...
    def s_matrix(
        self,
        frequencies: Sequence[float],
        show_progress: bool = True,
        model_kwargs: dict[str, object] = {},
    ) -> SMatrix: ...
    def select_active_model(
        self, classification: Literal["optical", "electrical"]
    ) -> Model | None: ...
    def select_ports(
        self, classification: Literal["electrical", "optical"]
    ) -> dict[str, Port | FiberPort | GaussianPort]: ...
    def set_bounds(self, bounds: Sequence[Sequence[float]]) -> Component: ...
    def setup_time_stepper(
        self,
        time_step: float,
        carrier_frequency: float = 0,
        show_progress: bool = True,
        time_stepper_kwargs: dict[str, object] = {},
    ) -> TimeStepper: ...
    def size(self, include_ports: bool = True, include_labels: bool = True) -> ndarray: ...
    def slice_profile(
        self,
        axis: Literal["x", "y"],
        center: Sequence[float] | complex,
        length: float | None = None,
        depth: int = -1,
    ) -> list[tuple[float, float, tuple[int, int]]]: ...
    def structure_count(self) -> int: ...
    def tree_view(self, by_reference: bool = False, interactive: bool = False) -> object: ...
    def update(self, *args: object, **kwargs: object) -> Component: ...
    def write_gds(
        self,
        filename: str = "",
        paths_to_polygons: bool = True,
        fracture_limit: int = 0,
        pre_export_function: Callable | None = None,
    ) -> Component: ...
    def write_oas(
        self,
        filename: str = "",
        paths_to_polygons: bool = True,
        compression_level: int = 9,
        library_properties: Properties | None = None,
        pre_export_function: Callable | None = None,
    ) -> Component: ...
    _id: object
    active_model: dict[str, Model] | Model | None
    active_model_name: dict[str, str] | str | None
    labels: dict[tuple[int, int], Label]
    models: dict[str, Model]
    name: str
    parametric_function: str | None
    parametric_kwargs: dict[str, object]
    ports: dict[str, Port | FiberPort | GaussianPort]
    properties: Properties
    random_variables: list[RandomVariable]
    references: list[Reference]
    structures: dict[tuple[int, int], Rectangle | Circle | Polygon | Path]
    technology: Technology
    terminals: dict[str, Terminal]
    virtual_connections: list[
        tuple[tuple[Reference | None, str, int], tuple[Reference | None, str, int]]
    ]
    virtual_connections_by_instance: list[tuple[tuple[int, str], tuple[int, str]]]

class ConstructiveSolid:
    def __init__(
        self,
        operand1: Extruded
        | Polyhedron
        | ConstructiveSolid
        | Iterable[Extruded | Polyhedron | ConstructiveSolid],
        operand2: Extruded
        | Polyhedron
        | ConstructiveSolid
        | Iterable[Extruded | Polyhedron | ConstructiveSolid],
        operation: Literal["+", "*", "-", "^"],
        medium: MediumType = None,
    ) -> None: ...
    def __copy__(self, /) -> ConstructiveSolid: ...
    def __deepcopy__(self, *args: object, **kwargs: object) -> ConstructiveSolid: ...
    def __getstate__(self, /) -> object: ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def copy(self, deep: bool = False) -> ConstructiveSolid: ...
    def to_tidy3d(self) -> tidy3d.Structure: ...
    _id: object
    medium: MediumType
    operand1: list[Extruded | Polyhedron | ConstructiveSolid]
    operand2: list[Extruded | Polyhedron | ConstructiveSolid]
    operation: Literal["+", "*", "-", "^"]
    properties: Properties

class Expression:
    def __init__(
        self,
        parameter: str | Sequence[str],
        expression: str | tuple[str, str | float] | Sequence[str | tuple[str, str | float]],
    ) -> None: ...
    def __copy__(self, /) -> Expression: ...
    def __deepcopy__(self, *args: object, **kwargs: object) -> Expression: ...
    def __getstate__(self, /) -> object: ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def copy(self) -> Expression: ...
    _id: object
    expressions: list[tuple[str, str | float]]
    parameters: list[str]
    properties: Properties

class Extruded:
    def __init__(
        self,
        medium: MediumType,
        face: Rectangle | Circle | Polygon | Path,
        limits: Sequence[float],
        dilations: Sequence[float] = (0, 0),
        axis: Literal["x", "y", "z"] = "z",
    ) -> None: ...
    def __copy__(self, /) -> Extruded: ...
    def __deepcopy__(self, *args: object, **kwargs: object) -> Extruded: ...
    def __getstate__(self, /) -> object: ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def copy(self, deep: bool = False) -> Extruded: ...
    def to_tidy3d(self) -> tidy3d.Structure: ...
    _id: object
    axis: str
    dilations: ndarray
    face: Rectangle | Circle | Polygon | Path
    limits: ndarray
    medium: MediumType
    properties: Properties

class ExtrusionSpec:
    def __init__(
        self,
        mask_spec: MaskSpec,
        medium: MediumType | dict[Literal["optical", "electrical"], MediumType],
        limits: Sequence[float],
        sidewall_angle: float = 0,
        reference: Literal["top", "bottom", "middle"] | float = "top",
    ) -> None: ...
    def __copy__(self, /) -> ExtrusionSpec: ...
    def __deepcopy__(self, *args: object, **kwargs: object) -> ExtrusionSpec: ...
    def __getstate__(self, /) -> object: ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def copy(self, deep: bool = False) -> ExtrusionSpec: ...
    def extrude(
        self,
        *structures: Rectangle | Circle | Polygon | Path,
        extrusion_tolerance: float = 0,
        classification: Literal["optical", "electrical"] = "optical",
    ) -> list[Polyhedron | Extruded | ConstructiveSolid]: ...
    def get_medium(self, classification: Literal["optical", "electrical"]) -> MediumType: ...
    def mask_layers(self) -> set[tuple[int, int]]: ...
    _id: object
    limits: ndarray
    mask_spec: MaskSpec
    medium: MediumType | dict[Literal["optical", "electrical"], MediumType]
    properties: Properties
    reference: Literal["top", "bottom", "middle"] | float
    sidewall_angle: float

class FiberPort:
    def __init__(
        self,
        center: Sequence[float],
        input_vector: Sequence[float],
        size: Sequence[float] | complex,
        extrusion_limits: Sequence[float],
        cross_section: Sequence[tuple[Rectangle | Circle | Polygon | Path, MediumType]] = (),
        num_modes: int = 1,
        polarization: Literal["", "TE", "TM"] | None = None,
        target_neff: float = 1,
        added_solver_modes: int = 0,
    ) -> None: ...
    def __copy__(self, /) -> FiberPort: ...
    def __deepcopy__(self, *args: object, **kwargs: object) -> FiberPort: ...
    def __getstate__(self, /) -> object: ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def _axis_aligned_properties(
        self,
    ) -> tuple[ndarray, ndarray, Literal["+", "-"], float, float, float]: ...
    def copy(self, deep: bool = False) -> FiberPort: ...
    def is_connected_to(self, port: Port | FiberPort | GaussianPort) -> bool: ...
    def matches(self, port: Port | FiberPort | GaussianPort) -> bool: ...
    def reflected(self) -> FiberPort: ...
    def to_tidy3d_mode_solver(
        self,
        frequencies: Sequence[float],
        mesh_refinement: float | None = None,
        group_index: bool = False,
        technology: Technology | None = None,
        use_angle_rotation: bool = False,
    ) -> ModeSolver: ...
    def to_tidy3d_monitor(
        self, frequencies: Sequence[float], name: str, use_angle_rotation: bool = False
    ) -> tidy3d.ModeMonitor: ...
    def to_tidy3d_source(
        self,
        frequencies: Sequence[float],
        mode_index: int = 0,
        name: str | None = None,
        use_angle_rotation: bool = False,
    ) -> tidy3d.ModeSource: ...
    def to_tidy3d_structures(self) -> list[tidy3d.Structure]: ...
    _id: object
    added_solver_modes: int
    center: ndarray
    classification: Literal["optical", "electrical"]
    cross_section: list[tuple[Rectangle | Circle | Polygon | Path, MediumType]]
    extrusion_limits: ndarray
    input_vector: ndarray
    num_modes: int
    polarization: Literal["", "TE", "TM"]
    properties: Properties
    size: ndarray
    target_neff: float

class GaussianPort:
    def __init__(
        self,
        center: Sequence[float],
        input_vector: Sequence[float],
        waist_radius: float,
        waist_position: float = 0,
        polarization_angle: float = 0,
        field_tolerance: float = 0.001,
        *,
        waist_distance: float | None = None,
    ) -> None: ...
    def __copy__(self, /) -> GaussianPort: ...
    def __deepcopy__(self, *args: object, **kwargs: object) -> GaussianPort: ...
    def __getstate__(self, /) -> object: ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def _axis_aligned_properties(
        self,
        frequencies: Sequence[float],
        medium: MediumType | Sequence[float] | float = 1.0,
    ) -> tuple[ndarray, ndarray, Literal["+", "-"], float, float]: ...
    def copy(self, deep: bool = False) -> GaussianPort: ...
    def fields(
        self,
        x: float | Sequence[float],
        y: float | Sequence[float],
        z: float | Sequence[float],
        frequency: float | Sequence[float],
        medium: MediumType | Sequence[float] | float = 1.0,
    ) -> tuple[ndarray, ndarray, ndarray, ndarray, ndarray]: ...
    def is_connected_to(self, port: Port | FiberPort | GaussianPort) -> bool: ...
    def matches(self, port: Port | FiberPort | GaussianPort) -> bool: ...
    def reflected(self) -> GaussianPort: ...
    def to_tidy3d_monitor(
        self,
        frequencies: Sequence[float],
        name: str,
        medium: MediumType | Sequence[float] | float = 1.0,
    ) -> tidy3d.FieldMonitor: ...
    def to_tidy3d_source(
        self,
        frequencies: Sequence[float],
        name: str | None = None,
        medium: MediumType | Sequence[float] | float = 1.0,
    ) -> tidy3d.GaussianBeam: ...
    _id: object
    added_solver_modes: int
    center: ndarray
    classification: Literal["optical", "electrical"]
    field_tolerance: float
    input_vector: ndarray
    num_modes: int
    polarization_angle: float
    properties: Properties
    waist_distance: float
    waist_position: float
    waist_radius: float

class Interpolator:
    def __init__(
        self,
        x: Sequence[float] | Sequence[Sequence[float]],
        y: Sequence[float | complex] | Sequence[Sequence[float | complex]],
        method: str = "linear",
        coords: Literal["mag_phase", "real_imag"] = "real_imag",
        extrapolation: Literal["extrapolate", "constant"] = "extrapolate",
        parameter_names: Sequence[str] | None = None,
    ) -> None: ...
    def __copy__(self, /) -> Interpolator: ...
    def __deepcopy__(self, *args: object, **kwargs: object) -> Interpolator: ...
    def __getstate__(self, /) -> object: ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def copy(self) -> Interpolator: ...
    _id: object
    coords: str
    extrapolation: str
    method: str
    parameter_names: tuple[str, ...] | None
    properties: Properties
    x: ndarray
    y: ndarray | list[ndarray]

class Label:
    def __init__(
        self,
        text: str = "",
        origin: Sequence[float] | complex = (0, 0),
        anchor: Literal["NW", "N", "NE", "W", "O", "E", "SW", "S", "SE"] = "NW",
        rotation: float = 0,
        scaling: float = 1,
        x_reflection: bool = False,
    ) -> None: ...
    def __copy__(self, /) -> Label: ...
    def __deepcopy__(self, *args: object, **kwargs: object) -> Label: ...
    def __getstate__(self, /) -> object: ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def add_gds_property(self, attribute: int, value: str) -> object: ...
    def copy(self) -> Label: ...
    def mirror(
        self,
        axis_endpoint: Sequence[float] | complex = (1, 0),
        axis_origin: Sequence[float] | complex = (0, 0),
    ) -> Label: ...
    def rotate(self, rotation: float, center: Sequence[float] | complex = (0, 0)) -> Label: ...
    def scale(self, scaling: float, center: Sequence[float] | complex = (0, 0)) -> Label: ...
    def transform(
        self,
        translation: Sequence[float] | complex = (0, 0),
        rotation: float = 0,
        scaling: float = 1,
        x_reflection: bool = False,
    ) -> Label: ...
    def translate(self, translation: Sequence[float]) -> Label: ...
    _id: object
    anchor: Literal["NW", "N", "NE", "W", "O", "E", "SW", "S", "SE"]
    origin: ndarray
    properties: Properties
    rotation: float
    scaling: float
    text: str
    x_reflection: object

class LayerSpec:
    def __init__(
        self,
        layer: tuple[int, int],
        description: str,
        color: str | tuple[int, int, int] | tuple[int, int, int, int] | None = None,
        pattern: str = "",
    ) -> None: ...
    def __copy__(self, /) -> LayerSpec: ...
    def __deepcopy__(self, *args: object, **kwargs: object) -> LayerSpec: ...
    def __getstate__(self, /) -> object: ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def copy(self) -> LayerSpec: ...
    _id: object
    color: ndarray
    description: str
    layer: tuple[int, int]
    pattern: str
    properties: Properties

class LumpedModel:
    def __init__(
        self,
        *,
        port_map: dict[str, tuple[str, float] | tuple[str, str, float]] | None = None,
        **kwargs: object,
    ) -> None: ...
    def __copy__(self) -> LumpedModel: ...
    def __deepcopy__(self, memo: dict[int, object] | None = None) -> LumpedModel: ...
    def __getstate__(self, /) -> object: ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def estimate_cost(self, *args: object, **kwargs: object) -> float: ...
    def s_matrix(
        self,
        component: Component,
        frequencies: Sequence[float],
        show_progress: bool = True,
        model_kwargs: dict[str, object] = {},
    ) -> SMatrix: ...
    def setup_time_stepper(self, *args: object, **kwargs: object) -> object: ...
    def start(
        self, component: Component, frequencies: Sequence[float], **kwargs: object
    ) -> SMatrix | object: ...
    def start_mna(
        self, component: Component, frequencies: Sequence[float], **kwargs: object
    ) -> MNAMatrix | object: ...
    def update(self, *args: object, **kwargs: object) -> LumpedModel: ...
    _id: object
    parametric_function: str
    parametric_kwargs: dict[str, object]
    port_map: dict[str, tuple[str, complex] | tuple[str, str, complex]] | None
    properties: Properties
    random_variables: list[RandomVariable]
    time_stepper: None

class MNAMatrix:
    def __init__(
        self,
        frequencies: Sequence[float],
        elements: dict[tuple[str, str], Sequence[complex]],
        terminals: dict[str, Terminal | None] | None = None,
    ) -> None: ...
    def __copy__(self, /) -> MNAMatrix: ...
    def __deepcopy__(self, *args: object, **kwargs: object) -> MNAMatrix: ...
    def __getitem__(self, key: object, /) -> object: ...
    def __getstate__(self, /) -> object: ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def copy(self) -> MNAMatrix: ...
    def force_symmetric(self) -> MNAMatrix: ...
    _id: object
    elements: dict[tuple[str, str], ndarray]
    frequencies: ndarray
    properties: Properties
    terminals: dict[str, Terminal | None]
    wavelengths: ndarray

class MaskSpec:
    def __init__(
        self,
        operand1: str
        | tuple[int, int]
        | MaskSpec
        | Iterable[str | tuple[int, int] | MaskSpec] = None,
        operand2: str
        | tuple[int, int]
        | MaskSpec
        | Iterable[str | tuple[int, int] | MaskSpec] = None,
        operation: Literal["+", "*", "-", "^"] = "+",
        dilation: float = 0,
        translation: Sequence[float] | complex = (0, 0),
    ) -> None: ...
    def __copy__(self, /) -> MaskSpec: ...
    def __deepcopy__(self, *args: object, **kwargs: object) -> MaskSpec: ...
    def __getstate__(self, /) -> object: ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def copy(self) -> MaskSpec: ...
    def format(
        self,
        layer_names: dict[tuple[int, int], str] | None = None,
        technology: Technology | None = None,
    ) -> str: ...
    def get_layers(self) -> set[tuple[int, int]]: ...
    def parse(self, expression: str, technology: Technology | None = None) -> MaskSpec: ...
    def uses_translation(self, /) -> bool: ...
    _id: object
    dilation: float
    layer: tuple[int, int] | None
    operand1: list[MaskSpec]
    operand2: list[MaskSpec]
    operation: Literal["+", "*", "-", "^"]
    properties: Properties
    translation: ndarray

class Model:
    def __init__(self, **kwargs: object) -> None: ...
    def __copy__(self) -> Model: ...
    def __deepcopy__(self, memo: dict[int, object] | None = None) -> Model: ...
    def __getstate__(self, /) -> object: ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def transform(
        self,
        translation: Sequence[float, float] | complex = (0, 0),
        rotation: float = 0,
        scaling: float = 1,
        x_reflection: bool = False,
    ) -> Model: ...
    def estimate_cost(self, *args: object, **kwargs: object) -> float: ...
    def s_matrix(
        self,
        component: Component,
        frequencies: Sequence[float],
        show_progress: bool = True,
        model_kwargs: dict[str, object] = {},
    ) -> SMatrix: ...
    def setup_time_stepper(
        self,
        component: Component,
        time_step: float,
        carrier_frequency: float = 0,
        show_progress: bool = True,
        time_stepper_kwargs: dict[str, object] = {},
    ) -> TimeStepper: ...
    def start(
        self, component: Component, frequencies: Sequence[float], **kwargs: object
    ) -> SMatrix | object: ...
    def update(self, *args: object, **kwargs: object) -> Model: ...
    _id: object
    parametric_function: str
    parametric_kwargs: dict[str, object]
    properties: Properties
    random_variables: list[RandomVariable]
    time_stepper: TimeStepper | None

class Path:
    def __init__(
        self,
        origin: Sequence[float] | complex,
        width: float,
        offset: float = 0,
        caps: float
        | Literal["round"]
        | tuple[float | Literal["round"], float | Literal["round"]] = (0, 0),
        scale_profile: bool = True,
    ) -> None: ...
    def __copy__(self, /) -> Path: ...
    def __deepcopy__(self, *args: object, **kwargs: object) -> Path: ...
    def __getstate__(self, /) -> object: ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def _integration_points(
        self,
        width_rtol: float = 0,
        offset_rtol: float = 0,
        curvature_rtol: float = 0,
        include_offset: bool = True,
    ) -> tuple[ndarray, ndarray, ndarray, ndarray, ndarray, ndarray]: ...
    def _repr_svg_(self) -> str: ...
    def add_gds_property(self, attribute: int, value: str) -> object: ...
    def arc(
        self,
        initial_angle: float,
        final_angle: float,
        radius: float | Sequence[float] | None = None,
        rotation: float = 0,
        euler_fraction: float | None = None,
        endpoint: Sequence[float] | complex | None = None,
        width: float
        | tuple[float, Literal["constant", "linear", "smooth"]]
        | tuple[float, float, Literal["constant", "linear", "smooth"]]
        | tuple[str, str]
        | Expression = None,
        offset: float
        | tuple[float, Literal["constant", "linear", "smooth"]]
        | tuple[float, float, Literal["constant", "linear", "smooth"]]
        | tuple[str, str]
        | Expression = None,
        min_evals: int = 0,
        max_evals: int = 10000,
    ) -> Path: ...
    def area(self) -> float: ...
    def at(
        self,
        u: float,
        output: Literal["all", "position", "width", "offset", "gradient"] = "all",
    ) -> tuple[ndarray, float, float, ndarray] | ndarray | float: ...
    def bezier(
        self,
        controls: Sequence[Sequence[float] | complex],
        width: float
        | tuple[float, Literal["constant", "linear", "smooth"]]
        | tuple[float, float, Literal["constant", "linear", "smooth"]]
        | tuple[str, str]
        | Expression = None,
        offset: float
        | tuple[float, Literal["constant", "linear", "smooth"]]
        | tuple[float, float, Literal["constant", "linear", "smooth"]]
        | tuple[str, str]
        | Expression = None,
        relative: bool = False,
        min_evals: int = 0,
        max_evals: int = 10000,
    ) -> Path: ...
    def bounds(self) -> tuple[ndarray, ndarray]: ...
    def center(self) -> ndarray: ...
    def copy(self, /) -> Path: ...
    def interpolate(
        self,
        distances: Sequence[float] | float,
        include_offset: bool = True,
        output: Literal["all", "position", "width", "offset", "gradient"] = "all",
    ) -> tuple[ndarray, ndarray, ndarray, ndarray] | ndarray: ...
    def left_vertices(self) -> ndarray: ...
    def length(self, include_offset: bool = True) -> float: ...
    def mirror(
        self,
        axis_endpoint: Sequence[float] | complex = (1, 0),
        axis_origin: Sequence[float] | complex = (0, 0),
    ) -> Path: ...
    def parametric(
        self,
        position: tuple[str, str] | Expression,
        gradient: tuple[str, str] | None = None,
        width: float
        | tuple[float, Literal["constant", "linear", "smooth"]]
        | tuple[float, float, Literal["constant", "linear", "smooth"]]
        | tuple[str, str]
        | Expression = None,
        offset: float
        | tuple[float, Literal["constant", "linear", "smooth"]]
        | tuple[float, float, Literal["constant", "linear", "smooth"]]
        | tuple[str, str]
        | Expression = None,
        relative: bool = True,
        min_evals: int = 0,
        max_evals: int = 10000,
    ) -> Path: ...
    def perimeter(self) -> float: ...
    def right_vertices(self) -> ndarray: ...
    def rotate(
        self, rotation: float, center: Sequence[float, float] | complex = (0, 0)
    ) -> Path: ...
    def s_bend(
        self,
        endpoint: Sequence[float] | complex,
        euler_fraction: float | None = None,
        direction: Sequence[float] | complex | None = None,
        width: float
        | tuple[float, Literal["constant", "linear", "smooth"]]
        | tuple[float, float, Literal["constant", "linear", "smooth"]]
        | tuple[str, str]
        | Expression = None,
        offset: float
        | tuple[float, Literal["constant", "linear", "smooth"]]
        | tuple[float, float, Literal["constant", "linear", "smooth"]]
        | tuple[str, str]
        | Expression = None,
        relative: bool = False,
        min_evals: int = 0,
        max_evals: int = 10000,
    ) -> Path: ...
    def scale(self, scaling: float, center: Sequence[float, float] | complex = (0, 0)) -> Path: ...
    def segment(
        self,
        endpoint: Sequence[float] | complex | Sequence[Sequence[float] | complex],
        width: float
        | tuple[float, Literal["constant", "linear", "smooth"]]
        | tuple[float, float, Literal["constant", "linear", "smooth"]]
        | tuple[str, str]
        | Expression = None,
        offset: float
        | tuple[float, Literal["constant", "linear", "smooth"]]
        | tuple[float, float, Literal["constant", "linear", "smooth"]]
        | tuple[str, str]
        | Expression = None,
        join_limit: float | Literal["round"] = -1.0,
        relative: bool = False,
        min_evals: int = 0,
        max_evals: int = 10000,
    ) -> Path: ...
    def spine(self) -> ndarray: ...
    def to_polygon(self) -> Polygon: ...
    def transform(
        self,
        translation: Sequence[float, float] | complex = (0, 0),
        rotation: float = 0,
        scaling: float = 1,
        x_reflection: bool = False,
    ) -> Path: ...
    def translate(self, translation: Sequence[float, float] | complex) -> Path: ...
    def turn(
        self,
        angle: float,
        radius: float | None = None,
        euler_fraction: float | None = None,
        endpoint: Sequence[float] | complex | None = None,
        width: float
        | tuple[float, Literal["constant", "linear", "smooth"]]
        | tuple[float, float, Literal["constant", "linear", "smooth"]]
        | tuple[str, str]
        | Expression = None,
        offset: float
        | tuple[float, Literal["constant", "linear", "smooth"]]
        | tuple[float, float, Literal["constant", "linear", "smooth"]]
        | tuple[str, str]
        | Expression = None,
        min_evals: int = 0,
        max_evals: int = 10000,
    ) -> Path: ...
    def updated_copy(
        self,
        width: float,
        offset: float = 0,
        constant_width: bool = False,
        constant_offset: bool = False,
        relative: bool = False,
    ) -> Path: ...
    _id: object
    caps: tuple[float | Literal["round"], float | Literal["round"]]
    origin: ndarray
    properties: Properties
    scale_profile: bool
    size: int
    x_max: float
    x_mid: float
    x_min: float
    y_max: float
    y_mid: float
    y_min: float

class PhfStream:
    def __init__(
        self, filename: str, mode: Literal["r", "w"] = "r", set_config: bool = True
    ) -> None: ...
    def __getstate__(self, /) -> object: ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def close(self) -> object: ...
    def contents(self, only_explicit: bool = True) -> object: ...
    def data(self) -> list[object]: ...
    def load_component(
        self, name: str | None = None, only_explicit: bool = True
    ) -> list[Component]: ...
    def load_technology(
        self,
        name: str | None = None,
        version: str | None = None,
        only_explicit: bool = True,
    ) -> list[Technology]: ...
    def write(self, *args: object) -> PhfStream: ...
    _id: object
    config: dict[str, object] | None
    properties: Properties

class PoleResidueMatrix:
    def __init__(
        self,
        poles: Sequence[float],
        residues: dict[tuple[str, str] | Sequence[complex]],
        frequency_scaling: float = 6.283185,
        ports: dict[str, Port | FiberPort | GaussianPort | None] | None = None,
        delays: dict[tuple[str, str], float] | float | None = None,
    ) -> None: ...
    def __copy__(self, /) -> PoleResidueMatrix: ...
    def __deepcopy__(self, *args: object, **kwargs: object) -> PoleResidueMatrix: ...
    def __getstate__(self, /) -> object: ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def copy(self) -> PoleResidueMatrix: ...
    def enforce_passivity(
        self,
        frequencies: Sequence[float],
        max_iterations: int = 20,
        real: bool = False,
        feedthrough: bool = False,
    ) -> bool: ...
    def get_rms_error(self, s_matrix: SMatrix) -> float: ...
    def is_passive(self) -> bool: ...
    _id: object
    delays: dict[tuple[str, str], float]
    frequency_scaling: float
    poles: ndarray
    ports: dict[str, Port | FiberPort | GaussianPort | None]
    properties: Properties
    residues: dict[tuple[str, str], ndarray]

class Polygon:
    def __init__(
        self,
        vertices: Sequence[Sequence[float] | complex],
        holes: Sequence[Sequence[Sequence[float] | complex]] | None = None,
    ) -> None: ...
    def __copy__(self, /) -> Polygon: ...
    def __deepcopy__(self, *args: object, **kwargs: object) -> Polygon: ...
    def __getstate__(self, /) -> object: ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def _repr_svg_(self) -> str: ...
    def add_gds_property(self, attribute: int, value: str) -> object: ...
    def area(self) -> float: ...
    def bounds(self) -> tuple[ndarray, ndarray]: ...
    def copy(self) -> Polygon: ...
    def fillet(self, radius: float) -> Polygon: ...
    def mirror(
        self,
        axis_endpoint: Sequence[float] | complex = (1, 0),
        axis_origin: Sequence[float] | complex = (0, 0),
    ) -> Polygon: ...
    def perimeter(self) -> float: ...
    def remove_collinear(self) -> Polygon: ...
    def rotate(
        self, rotation: float, center: Sequence[float, float] | complex = (0, 0)
    ) -> Polygon: ...
    def scale(
        self, scaling: float, center: Sequence[float, float] | complex = (0, 0)
    ) -> Polygon: ...
    def to_polygon(self) -> Polygon: ...
    def transform(
        self,
        translation: Sequence[float, float] | complex = (0, 0),
        rotation: float = 0,
        scaling: float = 1,
        x_reflection: bool = False,
    ) -> Polygon: ...
    def translate(self, translation: Sequence[float, float] | complex) -> Polygon: ...
    _id: object
    holes: list[ndarray]
    properties: Properties
    vertices: ndarray
    x_max: float
    x_mid: float
    x_min: float
    y_max: float
    y_mid: float
    y_min: float

class Polyhedron:
    def __init__(
        self,
        medium: MediumType,
        vertices: Sequence[Sequence[float]],
        triangles: Sequence[Sequence[int]],
    ) -> None: ...
    def __copy__(self, /) -> Polyhedron: ...
    def __deepcopy__(self, *args: object, **kwargs: object) -> Polyhedron: ...
    def __getstate__(self, /) -> object: ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def copy(self) -> Polyhedron: ...
    def to_tidy3d(self) -> tidy3d.Structure: ...
    def write_ply(self, filename: str) -> Polyhedron: ...
    _id: object
    medium: MediumType
    properties: Properties
    triangles: ndarray
    vertices: ndarray

class Port:
    def __init__(
        self,
        center: Sequence[float] | complex,
        input_direction: float,
        spec: str | PortSpec,
        extended: bool = True,
        inverted: bool = False,
        bend_radius: float = 0,
    ) -> None: ...
    def __copy__(self, /) -> Port: ...
    def __deepcopy__(self, *args: object, **kwargs: object) -> Port: ...
    def __getstate__(self, /) -> object: ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def _axis_aligned_properties(self) -> tuple[ndarray, ndarray, str, float, float]: ...
    def can_connect_to(self, port: Port) -> bool: ...
    def copy(self, deep: bool = False) -> Port: ...
    def is_connected_to(self, port: Port) -> bool: ...
    def matches(self, port: Port) -> bool: ...
    def terminals(self, name: str | None = None) -> Terminal | dict[str, Terminal]: ...
    def to_tidy3d_impedance_calculator(
        self, extrapolate_to_endpoints: bool = True, snap_to_grid: bool = True
    ) -> tidy3d.ImpedanceCalculator: ...
    def to_tidy3d_mode_solver(
        self,
        frequencies: Sequence[float],
        mesh_refinement: float | None = None,
        group_index: bool = False,
        technology: Technology | None = None,
        use_angle_rotation: bool = False,
    ) -> ModeSolver: ...
    def to_tidy3d_monitor(
        self, frequencies: Sequence[float], name: str, use_angle_rotation: bool = False
    ) -> tidy3d.ModeMonitor: ...
    def to_tidy3d_source(
        self,
        frequencies: Sequence[float],
        mode_index: int = 0,
        name: str | None = None,
        use_angle_rotation: bool = False,
    ) -> tidy3d.ModeSource: ...
    _id: object
    added_solver_modes: int
    bend_radius: float
    center: ndarray
    classification: Literal["optical", "electrical"]
    extended: bool
    input_direction: float
    inverted: bool
    num_modes: int
    properties: Properties
    spec: PortSpec

class PortSpec:
    def __init__(
        self,
        description: str,
        width: float,
        limits: Sequence[float],
        num_modes: int = 1,
        polarization: Literal["TE", "TM", ""] | None = None,
        target_neff: float = 1,
        path_profiles: Iterable[tuple[float, float, str | tuple[int, int]]]
        | dict[str, tuple[float, float, str | tuple[int, int]]] = (),
        added_solver_modes: int = 0,
        voltage_path: Sequence[Sequence[float] | complex] | None = None,
        current_path: Sequence[Sequence[float] | complex]
        | Rectangle
        | Circle
        | Polygon
        | Path = None,
        default_radius: float = 0,
        impedance: complex | Interpolator | None = None,
    ) -> None: ...
    def __copy__(self, /) -> PortSpec: ...
    def __deepcopy__(self, *args: object, **kwargs: object) -> PortSpec: ...
    def __getstate__(self, /) -> object: ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def _is_1D(self) -> bool: ...
    def combined_with(self, port_spec: PortSpec, offset: float = 0) -> PortSpec: ...
    def copy(self) -> PortSpec: ...
    def get_paths(
        self, origin: Sequence[float] | complex, scale_width: bool = True
    ) -> list[tuple[tuple[int, int], Path]]: ...
    def inverted(self) -> PortSpec: ...
    def path_profile_for(
        self, layer: str | tuple[int, int], technology: Technology | None = None
    ) -> tuple[float, float] | tuple[list[float], list[float]]: ...
    def path_profiles_list(self) -> list[float, float, tuple[int, int]]: ...
    def profile_matches(self, port_spec: PortSpec) -> bool: ...
    def symmetric(self) -> bool: ...
    def to_tidy3d(
        self,
        frequencies: Sequence[float],
        mesh_refinement: float | None = None,
        group_index: bool = False,
        technology: Technology | None = None,
    ) -> ModeSolver: ...
    def to_tidy3d_impedance_calculator(
        self, extrapolate_to_endpoints: bool = True, snap_to_grid: bool = True
    ) -> tidy3d.ImpedanceCalculator: ...
    _id: object
    added_solver_modes: int
    classification: Literal["optical", "electrical"]
    current_path: ndarray | None
    default_radius: float
    description: str
    impedance: Interpolator | None
    limits: ndarray
    num_modes: int
    path_profiles: (
        Iterable[tuple[float, float, tuple[int, int]]]
        | dict[str, tuple[float, float, tuple[int, int]]]
    )
    polarization: Literal["TE", "TM", ""]
    properties: Properties
    target_neff: float
    voltage_path: ndarray | None
    width: float

class Properties:
    def __init__(
        self,
        **kwargs: int | float | str | bytes | Sequence[int | float | str | bytes],
    ) -> None: ...
    def __copy__(self, /) -> Properties: ...
    def __deepcopy__(self, *args: object, **kwargs: object) -> Properties: ...
    def __delitem__(self, key: object, /) -> object: ...
    def __getitem__(self, key: object, /) -> object: ...
    def __getstate__(self, /) -> object: ...
    def __iter__(self, /) -> Iterator[object]: ...
    def __len__(self, /) -> int: ...
    def __repr__(self, /) -> str: ...
    def __setitem__(self, key: object, value: object, /) -> object: ...
    def __str__(self, /) -> str: ...
    def add_gds_property(self, attribute: int, value: str | bytes) -> Properties: ...
    def copy(self) -> Properties: ...
    def get(self, key: str, default: object = None) -> object: ...
    def keys(self) -> object: ...

class RandomVariable:
    def __init__(
        self,
        name: str,
        parent: Component | Model | Technology | None = None,
        *,
        value: float | int | complex | None = None,
        stdev: float | int | None = None,
        values: Sequence[float | int | complex] | None = None,
        value_range: Sequence[float | int] | None = None,
    ) -> None: ...
    def __copy__(self, /) -> RandomVariable: ...
    def __deepcopy__(self, *args: object, **kwargs: object) -> RandomVariable: ...
    def __getstate__(self, /) -> object: ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def set_by_cdf(self, cdf: float) -> object: ...
    def size(self) -> object: ...
    _id: object
    name: str
    parent: Component | Model | Technology | None
    properties: Properties
    type: str
    value: object
    value_spec: dict[str, object]

class Rectangle:
    def __init__(
        self,
        corner1: Sequence[float] | complex | None = None,
        corner2: Sequence[float] | complex | None = None,
        center: Sequence[float] | complex | None = None,
        size: Sequence[float] | complex | None = None,
        rotation: float = 0,
    ) -> None: ...
    def __copy__(self, /) -> Rectangle: ...
    def __deepcopy__(self, *args: object, **kwargs: object) -> Rectangle: ...
    def __getstate__(self, /) -> object: ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def _repr_svg_(self) -> str: ...
    def add_gds_property(self, attribute: int, value: str) -> object: ...
    def area(self) -> float: ...
    def bounds(self) -> tuple[ndarray, ndarray]: ...
    def copy(self) -> Rectangle: ...
    def mirror(
        self,
        axis_endpoint: Sequence[float] | complex = (1, 0),
        axis_origin: Sequence[float] | complex = (0, 0),
    ) -> Rectangle: ...
    def perimeter(self) -> float: ...
    def rotate(self, rotation: float, center: Sequence[float] | complex = (0, 0)) -> Rectangle: ...
    def scale(self, scaling: float, center: Sequence[float] | complex = (0, 0)) -> Rectangle: ...
    def to_polygon(self) -> Polygon: ...
    def transform(
        self,
        translation: Sequence[float] | complex = (0, 0),
        rotation: float = 0,
        scaling: float = 1,
        x_reflection: bool = False,
    ) -> Rectangle: ...
    def translate(self, translation: Sequence[float] | complex) -> Rectangle: ...
    _id: object
    center: ndarray
    properties: Properties
    rotation: float
    size: ndarray
    x_max: float
    x_mid: float
    x_min: float
    y_max: float
    y_mid: float
    y_min: float

class Reference:
    def __init__(
        self,
        component: Component,
        origin: Sequence[float] | complex = (0, 0),
        rotation: float = 0,
        scaling: float = 1,
        x_reflection: bool = False,
        columns: int = 1,
        rows: int = 1,
        spacing: Sequence[float] | complex = (0, 0),
        technology_updates: dict[str, object] = {},
        component_updates: dict[str, object] = {},
        model_updates: dict[str, object] = {},
        s_matrix_kwargs: dict[str, object] = {},
    ) -> None: ...
    def __copy__(self, /) -> Reference: ...
    def __deepcopy__(self, *args: object, **kwargs: object) -> Reference: ...
    def __getitem__(self, key: object, /) -> object: ...
    def __getstate__(self, /) -> object: ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def _repr_svg_(self) -> str: ...
    def add_gds_property(self, attribute: int, value: str) -> object: ...
    def bounds(self, include_labels: bool = True) -> tuple[ndarray, ndarray]: ...
    def center(self, include_labels: bool = True) -> ndarray: ...
    def connect(self, port_name: str, to_port: Port, repetition_index: int = 0) -> Reference: ...
    def convex_hull(self, include_labels: bool = True) -> ndarray: ...
    def copy(self, deep: bool = False, copy_technology: bool = False) -> Reference: ...
    def get_labels(
        self, layer: str | tuple[int, int] | None = None, depth: int = -1
    ) -> list[Label]: ...
    def get_ports(
        self, port_name: str | None = None
    ) -> (
        list[Port | FiberPort | GaussianPort] | dict[str, list[Port | FiberPort | GaussianPort]]
    ): ...
    def get_repetition(self, repetition_index: int = -1) -> Reference | list[Reference]: ...
    def get_structures(
        self, layer: str | tuple[int, int] | None = None, depth: int = -1
    ) -> list[Rectangle | Circle | Polygon | Path]: ...
    def get_terminals(
        self, terminal_name: str | None = None
    ) -> list[Terminal] | dict[str, list[Terminal]]: ...
    def mirror(
        self,
        axis_endpoint: Sequence[float] | complex = (1, 0),
        axis_origin: Sequence[float] | complex = (0, 0),
    ) -> Reference: ...
    def query(
        self, *args: str | int | None
    ) -> (
        Port
        | FiberPort
        | GaussianPort
        | Terminal
        | list[Port | FiberPort | GaussianPort | Terminal]
    ): ...
    def rotate(self, rotation: float, center: Sequence[float] | complex = (0, 0)) -> Reference: ...
    def scale(self, scaling: float, center: Sequence[float] | complex = (0, 0)) -> Reference: ...
    def size(self, include_labels: bool = True) -> ndarray: ...
    def transform(
        self,
        translation: Sequence[float] | complex = (0, 0),
        rotation: float = 0,
        scaling: float = 1,
        x_reflection: bool = False,
    ) -> Reference: ...
    def transformed_component(self, name: str, repetition_index: int = 0) -> Component: ...
    def translate(self, translation: Sequence[float] | complex) -> Reference: ...
    def update(
        self,
        technology_updates: dict[str, object] = {},
        component_updates: dict[str, object] = {},
        model_updates: dict[str, object] = {},
        chain_technology_updates: bool = True,
        classification: Literal["electrical", "optical"] = "optical",
    ) -> list[tuple[Technology | Component | Model, dict[str, object]]]: ...
    _id: object
    columns: int
    component: Component
    component_name: str
    component_updates: dict[str, object]
    model_updates: dict[str, object]
    origin: ndarray
    properties: Properties
    rotation: float
    rows: int
    s_matrix_kwargs: dict[str, object]
    scaling: float
    spacing: ndarray
    technology_updates: dict[str, object]
    x_max: float
    x_mid: float
    x_min: float
    x_reflection: bool
    y_max: float
    y_mid: float
    y_min: float

class SMatrix:
    def __init__(
        self,
        frequencies: Sequence[float],
        elements: dict[tuple[str, str], Sequence[complex]],
        ports: dict[str, Port | FiberPort | GaussianPort | None] | None = None,
    ) -> None: ...
    def __copy__(self, /) -> SMatrix: ...
    def __deepcopy__(self, *args: object, **kwargs: object) -> SMatrix: ...
    def __getitem__(self, key: object, /) -> object: ...
    def __getstate__(self, /) -> object: ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def apply_time_delay(self, delay: float) -> SMatrix: ...
    def copy(self) -> SMatrix: ...
    def estimate_delays(self, lossless: bool = False) -> dict[tuple[str, str], float]: ...
    def estimate_phase(self) -> SMatrix: ...
    def force_symmetric(self) -> SMatrix: ...
    def load_snp(cls, filename: str, ports: Sequence[str | tuple[str, int]] = ()) -> SMatrix: ...
    def write_snp(self, filename: str) -> SMatrix: ...
    _id: object
    elements: dict[tuple[str, str], ndarray]
    frequencies: ndarray
    ports: dict[str, Port | FiberPort | GaussianPort | None]
    properties: Properties
    wavelengths: ndarray

class Technology:
    def __init__(
        self,
        name: str,
        version: str,
        layers: dict[str, LayerSpec],
        extrusion_specs: Iterable[ExtrusionSpec],
        ports: dict[str, PortSpec],
        background_medium: MediumType | dict[Literal["optical", "electrical"], MediumType],
        connections: Iterable[tuple[tuple[int, int], tuple[int, int]]] = (),
    ) -> None: ...
    def __copy__(self, /) -> Technology: ...
    def __deepcopy__(self, *args: object, **kwargs: object) -> Technology: ...
    def __getstate__(self, /) -> object: ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def _repr_html_(self, /) -> str: ...
    def add_connection(
        self, layer1: str | tuple[int, int], layer2: str | tuple[int, int]
    ) -> Technology: ...
    def add_layer(self, layer_name: str, layer_spec: LayerSpec) -> Technology: ...
    def add_port(self, port_name: str, port_spec: PortSpec) -> Technology: ...
    def copy(self, deep: bool = False) -> Technology: ...
    def extrusion_layers(self) -> set[tuple[int, int]]: ...
    def get_background_medium(
        self, classification: Literal["electrical", "optical"]
    ) -> MediumType: ...
    def insert_extrusion_spec(self, index: int, extrusion_spec: ExtrusionSpec) -> Technology: ...
    def pop_extrusion_spec(self, index: int = -1) -> ExtrusionSpec: ...
    def remove_connection(
        self, layer1: str | tuple[int, int], layer2: str | tuple[int, int]
    ) -> Technology: ...
    def remove_layer(self, layer_name: str) -> Technology: ...
    def remove_port(self, port_name: str) -> Technology: ...
    def update(self, *args: object, **kwargs: object) -> Technology: ...
    _id: object
    background_medium: MediumType | dict[Literal["optical", "electrical"], MediumType]
    connections: list[tuple[tuple[int, int], tuple[int, int]]]
    extrusion_specs: list[ExtrusionSpec]
    layers: dict[str, LayerSpec]
    name: str
    parametric_function: str
    parametric_kwargs: dict[str, object]
    ports: dict[str, PortSpec]
    properties: Properties
    random_variables: list[RandomVariable]
    version: str

class Terminal:
    def __init__(
        self,
        routing_layer: str | tuple[int, int],
        structure: Rectangle | Circle | Polygon | Path,
    ) -> None: ...
    def __copy__(self, /) -> Terminal: ...
    def __deepcopy__(self, *args: object, **kwargs: object) -> Terminal: ...
    def __getstate__(self, /) -> object: ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def _repr_svg_(self) -> str: ...
    def bounds(self) -> ndarray: ...
    def center(self) -> ndarray: ...
    def copy(self, deep: bool = False) -> Terminal: ...
    def mirror(
        self,
        axis_endpoint: Sequence[float] | complex = (1, 0),
        axis_origin: Sequence[float] | complex = (0, 0),
    ) -> Terminal: ...
    def rotate(self, rotation: float, center: Sequence[float] | complex = (0, 0)) -> Terminal: ...
    def scale(self, scaling: float, center: Sequence[float] | complex = (0, 0)) -> Terminal: ...
    def size(self) -> ndarray: ...
    def transform(
        self,
        translation: Sequence[float] | complex = (0, 0),
        rotation: float = 0,
        scaling: float = 1,
        x_reflection: bool = False,
    ) -> Terminal: ...
    def translate(self, translation: Sequence[float] | complex) -> Terminal: ...
    _id: object
    properties: Properties
    routing_layer: tuple[int, int]
    structure: Rectangle | Circle | Polygon | Path
    x_max: float
    x_mid: float
    x_min: float
    y_max: float
    y_mid: float
    y_min: float

class TimeDomainModel:
    def __init__(self, pole_residue_matrix: PoleResidueMatrix, time_step: float) -> None: ...
    def __copy__(self, /) -> TimeDomainModel: ...
    def __deepcopy__(self, *args: object, **kwargs: object) -> TimeDomainModel: ...
    def __getstate__(self, /) -> object: ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def _step_single_unchecked(
        self,
        inputs: ndarray,
        outputs: ndarray,
        time_index: int,
        update_state: bool,
        shutdown: bool,
    ) -> object: ...
    def copy(self) -> TimeDomainModel: ...
    def reset(self) -> TimeDomainModel: ...
    def step(
        self,
        inputs: TimeSeries | None = None,
        steps: int = 0,
        time_step: float = 0,
        show_progress: bool = True,
    ) -> TimeSeries: ...
    def step_single(
        self,
        inputs: ndarray,
        outputs: ndarray,
        time_index: int = 0,
        update_state: bool = True,
        shutdown: bool = False,
    ) -> object: ...
    _id: object
    keys: tuple[str]
    pole_residue_matrix: PoleResidueMatrix
    properties: Properties
    time_step: float

class TimeSeries:
    def __init__(
        self, values: dict[str, Sequence[complex]], time_step: float, time_index: int = 0
    ) -> None: ...
    def __copy__(self, /) -> TimeSeries: ...
    def __deepcopy__(self, *args: object, **kwargs: object) -> TimeSeries: ...
    def __getitem__(self, key: object, /) -> object: ...
    def __getstate__(self, /) -> object: ...
    def __len__(self, /) -> int: ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def copy(self) -> TimeSeries: ...
    _id: object
    properties: Properties
    time_index: int
    time_step: float
    times: ndarray
    values: dict[str, ndarray]

class TimeStepper:
    def __init__(self, **kwargs: object) -> None: ...
    def __copy__(self) -> TimeStepper: ...
    def __deepcopy__(self, memo: dict[int, object] | None = None) -> TimeStepper: ...
    def __getstate__(self, /) -> object: ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def reset(self) -> object: ...
    def setup(
        self,
        component: Component,
        time_step: float,
        *,
        carrier_frequency: float = 0,
        show_progress: bool = True,
        **kwargs: object,
    ) -> TimeStepper: ...
    def setup_state(
        self,
        *,
        component: Component,
        time_step: float,
        carrier_frequency: float,
        show_progress: bool,
        **kwargs: object,
    ) -> object: ...
    def step(
        self,
        inputs: TimeSeries = None,
        steps: int = 0,
        time_step: float = 0,
        show_progress: bool = True,
    ) -> TimeSeries: ...
    def step_single(
        self,
        inputs: ndarray,
        outputs: ndarray,
        time_index: int,
        update_state: bool,
        shutdown: bool,
    ) -> object: ...
    def update(self, *args: object, **kwargs: object) -> TimeStepper: ...
    _id: object
    parametric_function: str
    parametric_kwargs: dict[str, object]
    properties: Properties
    random_variables: list[RandomVariable]

class YMatrix:
    def __init__(
        self,
        frequencies: Sequence[float],
        elements: dict[tuple[str, str], Sequence[complex]],
        terminals: dict[str, Terminal | None] | None = None,
    ) -> None: ...
    def __copy__(self, /) -> YMatrix: ...
    def __deepcopy__(self, *args: object, **kwargs: object) -> YMatrix: ...
    def __getitem__(self, key: object, /) -> object: ...
    def __getstate__(self, /) -> object: ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def copy(self) -> YMatrix: ...
    def force_symmetric(self) -> YMatrix: ...
    def to_z_matrix(self) -> ZMatrix: ...
    _id: object
    elements: dict[tuple[str, str], ndarray]
    frequencies: ndarray
    properties: Properties
    terminals: dict[str, Terminal | None]
    wavelengths: ndarray

class ZMatrix:
    def __init__(
        self,
        frequencies: Sequence[float],
        elements: dict[tuple[str, str], Sequence[complex]],
        terminals: dict[str, Terminal | None] | None = None,
    ) -> None: ...
    def __copy__(self, /) -> ZMatrix: ...
    def __deepcopy__(self, *args: object, **kwargs: object) -> ZMatrix: ...
    def __getitem__(self, key: object, /) -> object: ...
    def __getstate__(self, /) -> object: ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def copy(self) -> ZMatrix: ...
    def force_symmetric(self) -> ZMatrix: ...
    def to_y_matrix(self) -> YMatrix: ...
    _id: object
    elements: dict[tuple[str, str], ndarray]
    frequencies: ndarray
    properties: Properties
    terminals: dict[str, Terminal | None]
    wavelengths: ndarray

class _Iterator:
    def __init__(self, *args: object, **kwargs: object) -> None: ...
    def __getstate__(self, /) -> object: ...
    def __iter__(self, /) -> Iterator[object]: ...
    def __next__(self, /) -> object: ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
