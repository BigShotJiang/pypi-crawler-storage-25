from typing import Annotated, Literal

from pydantic import BaseModel, Field, TypeAdapter

from photonforge.pda._types import DocumentId, ReadOnlyURL


class LogMessage(BaseModel):
    class _Data(BaseModel):
        level: Literal["debug", "info", "warning", "error"]
        message: str

    id: str | None
    userId: str | None = None
    type: Literal["log"]
    data: _Data


class ProjectAddLibrary(BaseModel):
    class _Data(BaseModel):
        projectId: DocumentId
        libraryId: str

    id: str
    userId: str | None = None
    type: Literal["project.library_add"]
    data: _Data


class ApplicationOpen(BaseModel):
    class _Data(BaseModel):
        projectId: DocumentId
        applicationId: DocumentId

    id: str
    userId: str | None = None
    type: Literal["application.open"]
    data: _Data


class ApplicationSave(BaseModel):
    class _Data(BaseModel):
        projectRef: ReadOnlyURL
        applicationRef: ReadOnlyURL
        componentRef: ReadOnlyURL

    id: str
    userId: str | None = None
    type: Literal["application.save"]
    data: _Data


class ParameterChange(BaseModel):
    class _Data(BaseModel):
        projectId: DocumentId
        componentRef: ReadOnlyURL

    id: str
    userId: str | None = None
    type: Literal["component.parameter_change"]
    data: _Data


class SimulationRequest(BaseModel):
    class _Data(BaseModel):
        projectRef: ReadOnlyURL
        applicationRef: ReadOnlyURL
        componentRef: ReadOnlyURL
        simulationId: str

    id: str
    userId: str | None = None
    type: Literal["simulation.request"]
    data: _Data


class SimulationAbort(BaseModel):
    class _Data(BaseModel):
        projectId: DocumentId  # No persistent project mutations
        simulationId: str

    id: str
    userId: str | None = None
    type: Literal["simulation.abort"]
    data: _Data


Event = Annotated[
    LogMessage
    | ProjectAddLibrary
    | ApplicationOpen
    | ApplicationSave
    | ParameterChange
    | SimulationRequest
    | SimulationAbort,
    Field(discriminator="type"),
]
event_adapter = TypeAdapter(Event)
