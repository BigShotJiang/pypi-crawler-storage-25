import asyncio
import logging
import logging.config
from argparse import ArgumentParser, BooleanOptionalAction
from contextlib import asynccontextmanager
from logging.handlers import QueueHandler
from multiprocessing import Process, Queue
from pathlib import Path

import uvicorn
from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import ValidationError
from tidy3d.config import get_manager

from photonforge._backend.types import event_adapter
from photonforge._backend.worker import start_worker
from photonforge.extension import __version__
from photonforge.pda._crdt.refs import AutomergeRef


async def log_handler(log_queue):
    logger = logging.getLogger("photonforge.server")
    while True:
        record = await asyncio.to_thread(log_queue.get)
        if record is None:
            logger.debug("Log handler received shutdown sentinel.")
            break
        logger.handle(record)


async def sender(response_queue: Queue, connections: list[WebSocket], user_id: str):
    logger = logging.getLogger("photonforge.server")
    while True:
        message = await asyncio.to_thread(response_queue.get)
        if message is None:
            logger.debug(
                "Response sender received shutdown sentinel; closing websocket connections."
            )
            for connection in tuple(connections):
                try:
                    await connection.close()
                except Exception:
                    pass
            break
        if isinstance(message, dict) and "userId" not in message:
            message["userId"] = user_id
        for connection in tuple(connections):
            try:
                await connection.send_json(message)
            except Exception as err:
                logger.debug(f"Failed to deliver websocket message to a client: {err}")


async def get_user_id() -> str:
    from httpx import AsyncClient
    from tidy3d.web.core import http_util

    from photonforge.pda._config import resolve_pda_endpoints

    api_endpoint, _ = resolve_pda_endpoints(None, None)
    async with AsyncClient(
        base_url=api_endpoint,
        headers={"simcloud-api-key": http_util.api_key()},
        timeout=10,
    ) as client:
        response = await client.get("/api/sync/me")
        response.raise_for_status()
        return response.json()["userId"]


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.log_queue = Queue()
    app.state.logger = logging.getLogger("photonforge.server.queue")
    app.state.logger.addHandler(QueueHandler(app.state.log_queue))

    log_handler_task = asyncio.create_task(log_handler(app.state.log_queue), name="Log handler")

    app.state.response_queue = Queue()
    app.state.workers: dict[str, tuple[Process, Queue]] = {}
    app.state.connections: list[WebSocket] = []
    app.state.user_id = await get_user_id()

    sender_task = asyncio.create_task(
        sender(app.state.response_queue, app.state.connections, app.state.user_id),
        name="Response sender",
    )

    app.state.logger.info(
        f"Backend server lifespan started with worker profile {app.state.worker_profile!r} "
        f"for user {app.state.user_id!r}."
    )

    yield

    app.state.logger.info("Shutting down backend workers.")

    for project_id, (worker, work_queue) in app.state.workers.items():
        app.state.logger.debug(f"Requesting shutdown for worker handling project {project_id}.")
        if worker.is_alive():
            work_queue.put(None)

    for project_id, (worker, _) in app.state.workers.items():
        app.state.logger.debug(f"Waiting for worker handling project {project_id} to exit.")
        worker.join()
        worker.close()

    app.state.logger.info("Shutting down websocket sender task.")
    app.state.response_queue.put(None)
    await sender_task

    app.state.logger.info("Shutting down log forwarding task.")
    app.state.log_queue.put(None)
    await log_handler_task
    app.state.logger.info("Backend server lifespan shutdown complete.")


app = FastAPI(
    title="PhotonForge Server",
    description="PhotonForge local server for GUI interaction.",
    version=__version__,
    lifespan=lifespan,
)
app.state.worker_profile = "default"

# Configure CORS for frontend development
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "https://photonforge.simulation.cloud",
        "https://photonforge.dev-simulation.cloud",
        "https://photonforge.uat-simulation.cloud",
        "https://local-photonforge.dev-simulation.cloud:5173",
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=[
        "Content-Type",
        "Authorization",
        "X-Requested-With",
        "X-Request-ID",
        "X-Correlation-ID",
    ],
    expose_headers=["Content-Length", "Content-Type"],
    max_age=1728000,  # 20 days, matching nginx config
)


@app.get("/")
async def root():
    return {"title": app.title, "description": app.description, "version": app.version}


@app.get("/verify/{userId}")
async def verify_user_id(userId: str, request: Request):
    return {"userId": userId, "verified": userId == app.state.user_id}


@app.get("/favicon.ico", include_in_schema=False)
async def favicon():
    root = Path(__file__).parent.parent
    return FileResponse(root / "static" / "icons" / "photonforge.svg")


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    app.state.connections.append(websocket)
    app.state.logger.debug(
        f"Accepted websocket connection; {len(app.state.connections)} client(s) connected."
    )
    while True:
        try:
            message = await websocket.receive_text()
        except WebSocketDisconnect:
            if websocket in app.state.connections:
                app.state.connections.remove(websocket)
            app.state.logger.debug(
                f"Websocket disconnected; {len(app.state.connections)} client(s) remain connected."
            )
            break

        try:
            event = event_adapter.validate_json(message)
        except ValidationError as err:
            app.state.logger.warning(f"Rejected invalid websocket event payload: {err}")
            app.state.response_queue.put(
                {"type": "log", "data": {"message": str(err), "level": "error"}}
            )
            continue

        if event.type == "log":
            app.state.logger.debug("Ignoring inbound frontend log event.")
            continue

        if event.userId != app.state.user_id:
            if event.userId is None:
                app.state.logger.warning(
                    f"Rejected websocket event {event.type} ({event.id}) without userId."
                )
                app.state.response_queue.put(
                    {
                        "id": event.id,
                        "type": "log",
                        "data": {"message": "Rejected event without userId.", "level": "warning"},
                    }
                )
            continue

        if event.type == "application.save" or event.type == "simulation.request":
            project_id = AutomergeRef.parse(event.data.projectRef).document_id
        else:
            project_id = event.data.projectId

        app.state.logger.debug(
            f"Received websocket event {event.type} ({event.id}) for project {project_id}."
        )
        worker, work_queue = app.state.workers.get(project_id, (None, None))

        if worker is None or not worker.is_alive():
            app.state.logger.info(
                f"Creating worker for project {project_id} to handle {event.type} events."
            )
            work_queue = Queue()
            worker = Process(
                target=start_worker,
                args=(
                    event.id,
                    work_queue,
                    app.state.response_queue,
                    app.state.log_queue,
                    app.state.worker_profile,
                ),
                name=f"W_{project_id}",
                daemon=True,
            )
            worker.start()
            app.state.workers[project_id] = (worker, work_queue)
            app.state.logger.debug(
                f"Started worker process {worker.name} for project {project_id}."
            )

        if worker.is_alive():
            app.state.logger.debug(
                f"Dispatching event {event.type} ({event.id}) to worker for project {project_id}."
            )
            work_queue.put(event)
        else:
            app.state.logger.error(
                f"Worker for project {project_id} is not alive while handling event {event.id}."
            )
            app.state.response_queue.put(
                {
                    "id": event.id,
                    "type": "log",
                    "data": {
                        "message": f"Worker for project {project_id} is not alive.",
                        "level": "error",
                    },
                }
            )


async def create_example():
    from uuid import uuid4

    import photonforge as pf
    import photonforge.pda._client
    from photonforge.pda._client import (
        _application_type,
        _create_document,
        _find_repo_document,
        _init,
        _results_type,
        _stop,
        _ui_component_type,
    )
    from photonforge.pda._common_schema import Matrix3x2AffineJson
    from photonforge.pda._component import CANVAS_SCALING_FACTOR, model_from_pf
    from photonforge.pda._project import _create_project, _load_project, _select_library

    photonforge.pda._client._warned = True
    await _init()
    try:
        lib_name = "Abstract Components"
        print(f"Loading library {lib_name!r} version {pf.__version__}…", flush=True)
        lib, lib_id = await _select_library(lib_name, pf.__version__, None, False)
        lib = await _load_project(project_id=lib.id)  # set default technology

        print("Creating 'Example' project…", flush=True)
        project = await _create_project(
            "Example", description="Example project", labels=("example",)
        )
        await project._add_library(library_id=lib_id)

        splitter = project.components(name="Y Splitter", origin=lib.name)
        splitter_doc = project._components[splitter._pda_id].ui_doc
        straight = project.components(name="WG", origin=lib.name)
        straight_doc = project._components[straight._pda_id].ui_doc

        splitter1_info = await _create_document(_ui_component_type, project.id)
        splitter1_doc = await _find_repo_document(splitter1_info["documentId"])
        splitter1_doc.change({"referencedComponent": splitter_doc.ref})

        splitter2_info = await _create_document(_ui_component_type, project.id)
        splitter2_doc = await _find_repo_document(splitter2_info["documentId"])
        splitter2_doc.change({"referencedComponent": splitter_doc.ref})

        straight1_info = await _create_document(_ui_component_type, project.id)
        straight1_doc = await _find_repo_document(straight1_info["documentId"])
        straight1_doc.change({"referencedComponent": straight_doc.ref})

        mzi_info = await _create_document(_ui_component_type, project.id)
        mzi_doc = await _find_repo_document(mzi_info["documentId"])

        # Create preview
        splitter1 = splitter.__deepcopy__()
        splitter1._pda_id = splitter1_doc.id
        splitter2 = splitter.__deepcopy__()
        splitter2._pda_id = splitter2_doc.id
        straight1 = straight.__deepcopy__()
        straight1._pda_id = straight1_doc.id
        mzi = pf.Component("MZI", splitter.technology)
        mzi._pda_id = mzi_doc.id
        r0 = mzi.add_reference(splitter1)
        r1 = mzi.add_reference(straight1)
        r2 = mzi.add_reference(splitter2).rotate(180)
        r1.x_min = r0.x_max + 10
        r2.x_min = r1.x_max + 10
        r1.y_min = r0["P2"].center[1]
        mzi.add_virtual_connection(r0, "P2", r1, "P0")
        mzi.add_virtual_connection(r1, "P1", r2, "P1")
        mzi.add_virtual_connection(r0, "P1", r2, "P2")
        mzi.add_reference_ports(add_model=pf.CircuitModel())
        preview = mzi._repr_svg_(partial=True)

        model = await model_from_pf(
            pf.CircuitModel(), project._data["modelSchemas"], project.id, True
        )
        project._doc.change({"modelSchemas": project._data["modelSchemas"]})

        ref_data = [
            (str(uuid4()), splitter1_doc.id, (r0.origin, 0, 1, False)),
            (str(uuid4()), straight1_doc.id, (r1.origin, 0, 1, False)),
            (str(uuid4()), splitter2_doc.id, (r2.origin, 180, 1, False)),
        ]

        def f(t, s=1):
            mat = Matrix3x2AffineJson.from_kwargs((t[0][0] * s, t[0][1] * s), *t[1:])
            return mat.model_dump(mode="json")

        mzi_doc.change(
            {
                "name": "MZI",
                "models": {"Circuit": model.model_dump(mode="json")},
                "activeModel": {"electrical": "Circuit", "optical": "Circuit"},
                "references": {
                    r_id: {
                        "id": r_id,
                        "component": c_id,
                        "transform": f(t),
                        "canvasProperties": {"transform": f(t, CANVAS_SCALING_FACTOR)},
                    }
                    for r_id, c_id, t in ref_data
                },
                "ports": [
                    {
                        "name": "P0",
                        "classificationType": "optical",
                        "baseType": "Port",
                        "numModes": 1,
                        "origin": {"kind": "port", "referenceId": ref_data[0][0], "name": "P0"},
                        "canvasProperties": {"side": "left", "offset": 0.0},
                    },
                    {
                        "name": "P1",
                        "classificationType": "optical",
                        "baseType": "Port",
                        "numModes": 1,
                        "origin": {"kind": "port", "referenceId": ref_data[2][0], "name": "P0"},
                        "canvasProperties": {"side": "left", "offset": 0.0},
                    },
                ],
                "virtualConnections": {
                    str(uuid4()): {
                        "from": {"kind": "port", "referenceId": ref_data[0][0], "name": "P1"},
                        "to": {"kind": "port", "referenceId": ref_data[2][0], "name": "P2"},
                    },
                    str(uuid4()): {
                        "from": {"kind": "port", "referenceId": ref_data[0][0], "name": "P2"},
                        "to": {"kind": "port", "referenceId": ref_data[1][0], "name": "P0"},
                    },
                    str(uuid4()): {
                        "from": {"kind": "port", "referenceId": ref_data[1][0], "name": "P1"},
                        "to": {"kind": "port", "referenceId": ref_data[2][0], "name": "P1"},
                    },
                },
                "thumbnail": pf.thumbnails[b"mzi"],
                "preview": preview,
            }
        )

        application = await _create_document(_application_type, project.id)

        results = await _create_document(_results_type, application["documentId"])
        doc = await _find_repo_document(results["documentId"])
        doc.change({"customNames": {}, "plots": {}, "simulations": {}})

        doc = await _find_repo_document(application["documentId"])
        doc.change(
            {
                "type": "schematic",
                "name": "Example Application",
                "description": "Simple interferometer example",
                "component": mzi_doc.id,
                "simulationSettings": {
                    "simulationMode": "frequency",
                    "frequencyDomain": {
                        "startWavelength": 1.45,
                        "stopWavelength": 1.65,
                        "points": 101,
                    },
                    "timeDomain": {
                        "carrierFrequency": 193.414e12,
                        "duration": 3e-10,
                        "frequencyBandwidth": 4e12,
                        "frequencyPoints": 100,
                        "monitors": [],
                        "timeStep": 1e-12,
                    },
                },
                "userConfigs": None,
                "results": results["documentId"],
            }
        )

        project._doc.change({"applications": [application["documentId"]]})
        await asyncio.sleep(0.2)
        await _stop()
        print("Done.", flush=True)
    finally:
        await _stop()


def run():
    parser = ArgumentParser(
        prog="photonforge-server", description=f"{app.description} Version {app.version}"
    )
    parser.add_argument("--host", default="0.0.0.0", help="server host address")
    parser.add_argument("--port", type=int, default=8001, help="server host port")
    parser.add_argument(
        "--log-level",
        default="INFO",
        type=lambda s: s.upper(),
        choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
        help="logging verbosity level",
    )
    parser.add_argument("--profile", default=None, help="tidy3d configuration profile")
    parser.add_argument("--example", action=BooleanOptionalAction, help="create an example project")
    args = parser.parse_args()

    profile = args.profile
    if profile is not None:
        get_manager().switch_profile(profile)
        app.state.worker_profile = profile

    if args.example:
        asyncio.run(create_example())
        return

    log_level = {
        "DEBUG": logging.DEBUG,
        "INFO": logging.INFO,
        "WARNING": logging.WARNING,
        "ERROR": logging.ERROR,
        "CRITICAL": logging.CRITICAL,
    }.get(args.log_level)
    uv_log_level = max(log_level, logging.INFO)

    LOG_CONFIG = {
        "version": 1,
        "disable_existing_loggers": True,
        "formatters": {
            "default": {
                "()": "uvicorn.logging.DefaultFormatter",
                "fmt": "%(levelprefix)s %(processName)s:%(threadName)s: %(message)s",
                "use_colors": True,
            },
            "uvicorn": {
                "()": "uvicorn.logging.DefaultFormatter",
                "fmt": "%(levelprefix)s %(processName)s:%(threadName)s: %(message)s",
                "use_colors": True,
            },
            "access": {
                "()": "uvicorn.logging.AccessFormatter",
                "fmt": '%(levelprefix)s %(client_addr)s: "%(request_line)s" %(status_code)s',
            },
        },
        "handlers": {
            "default": {
                "formatter": "default",
                "class": "logging.StreamHandler",
                "stream": "ext://sys.stdout",
            },
            "uvicorn": {
                "formatter": "uvicorn",
                "class": "logging.StreamHandler",
                "stream": "ext://sys.stderr",
            },
            "access": {
                "formatter": "access",
                "class": "logging.StreamHandler",
                "stream": "ext://sys.stderr",
            },
        },
        "loggers": {
            "photonforge.server": {"handlers": ["default"], "level": log_level, "propagate": False},
            "photonforge.server.queue": {"handlers": [], "level": log_level, "propagate": False},
            "photonforge.server.worker": {"handlers": [], "level": log_level, "propagate": False},
            "uvicorn": {"handlers": ["uvicorn"], "level": uv_log_level, "propagate": False},
            "uvicorn.error": {"level": uv_log_level},
            "uvicorn.access": {"handlers": ["access"], "level": uv_log_level, "propagate": False},
            "websockets": {"level": "WARNING", "propagate": False},
            "websockets.client": {"level": "WARNING", "propagate": False},
            "websockets.server": {"level": "WARNING", "propagate": False},
            "websockets.protocol": {"level": "WARNING", "propagate": False},
        },
    }
    logging.config.dictConfig(LOG_CONFIG)
    uvicorn.run(app=app, host=args.host, port=args.port, log_config=LOG_CONFIG)


if __name__ == "__main__":
    run()
