import logging
import queue
import time
from dataclasses import dataclass
from datetime import datetime
from multiprocessing import Queue, current_process
from threading import Event, Lock, Thread
from typing import Literal

import numpy as np

import photonforge as pf
import photonforge.pda._client
from photonforge.pda._crdt.document import Document
from photonforge.pda._types import (
    SchematicApplication,
    SMatrix,
)

_MONITOR_INITIAL_DELAY = 0.1


logger = logging.getLogger(f"photonforge.server.worker.{current_process().name}")

# Only available in pyhton 3.11 onwards
# log_level_values = {k.lower(): v for k, v in logging.getLevelNamesMapping().items()}
log_level_values = {
    "critical": logging.CRITICAL,
    "fatal": logging.FATAL,
    "error": logging.ERROR,
    "warn": logging.WARN,
    "warning": logging.WARNING,
    "info": logging.INFO,
    "debug": logging.DEBUG,
    "notset": logging.NOTSET,
}

message_queue = Queue()


def report(
    message: str,
    event_id: str | None,
    level: Literal["error", "warning", "info", "debug"] = "error",
    *,
    log: bool = True,
    send: bool = True,
):
    global logger, message_queue
    if send and logger.isEnabledFor(log_level_values[level]):
        event = {"type": "log", "data": {"message": message, "level": level}}
        if event_id is not None:
            event["id"] = event_id
        message_queue.put(event)
    if log:
        if event_id:
            message = f"{message} [{event_id}]"
        match level:
            case "debug":
                logger.debug(message)
            case "info":
                logger.info(message)
            case "warning":
                logger.warning(message)
            case _:
                logger.error(message)


@dataclass
class Job:
    results_doc: Document
    simulation_id: str
    sim_job: dict[str, object]
    tasks: dict[str, object]
    terminate: Event
    thread: Thread | None
    lock: Lock
    update_queue: queue.Queue[str]

    def update(self, **kwargs):
        with self.lock:
            self.sim_job.update(**kwargs)
        self.update_queue.put(self.simulation_id)


def monitor_status(runner: object, job: Job, progress_factor: float):
    last_status = None
    message = "running"
    delay = _MONITOR_INITIAL_DELAY
    while message == "running":
        time.sleep(delay)

        if job.terminate.is_set():
            job.update(
                state="failed",
                result={"level": "error", "message": "Job terminated", "id": job.simulation_id},
            )
            report(
                f"Simulation monitor for {job.simulation_id} terminated on request.",
                None,
                "info",
                send=False,
            )
            return "terminated"

        try:
            status = runner.status
            message = status["message"]
        except Exception as err:
            job.update(
                state="failed",
                result={"level": "error", "message": str(err), "id": job.simulation_id},
            )
            report(f"Simulation monitor error for {job.simulation_id}: {err}", None, send=False)
            return "failed"

        with job.lock:
            job.tasks.update(status.get("tasks", {}))

        if last_status is None:
            job.sim_job.update({"state": "running", "startedAt": datetime.now().isoformat()})

        if status != last_status:
            report(
                f"Simulation {job.simulation_id} status update: {status}",
                None,
                "info",
                send=False,
            )
            job.update(progress=min(100, max(0, int(progress_factor * status["progress"]))))
            last_status = status

    return message


def monitor_time_stepping(stepper: object, runner: object, time_step: float, steps: int, job: Job):
    message = monitor_status(runner, job, 0.5)
    if message != "success":
        job.sim_job["state"] = "failed"
        if job.sim_job.get("result") is None:
            job.update(
                result={
                    "level": "error",
                    "message": f"Time stepper setup failed: {message}",
                    "id": job.simulation_id,
                }
            )
            report(
                f"Time-domain simulation {job.simulation_id} failed before stepping: {message}",
                None,
                send=False,
            )
        return

    with job.lock:
        job.tasks.clear()

    try:
        outputs = np.zeros((steps, len(stepper.keys)), dtype=complex)
        zeros = np.zeros(len(stepper.keys), dtype=complex)
    except Exception as err:
        job.update(
            state="failed", result={"level": "error", "message": str(err), "id": job.simulation_id}
        )
        report(
            f"Failed to allocate time-series buffers for {job.simulation_id}: {err}",
            None,
            send=False,
        )
        return

    for step in range(steps):
        try:
            stepper.step_single(zeros, outputs[step], step, True, step == steps - 1)
        except Exception as err:
            job.update(
                state="failed",
                result={"level": "error", "message": str(err), "id": job.simulation_id},
            )
            report(
                f"Time stepping failed for simulation {job.simulation_id}: {err}",
                None,
                send=False,
            )
            return

        progress = 50 + int(50 * (step + 1) / steps)
        if progress > job.sim_job.get("progress", 0) + 5:
            job.update(progress=progress)
            report(
                f"Time-domain simulation {job.simulation_id} progress: {progress}%.",
                None,
                "info",
                send=False,
            )

    time_series = pf.TimeSeries(
        {k: outputs[:, i] for i, k in enumerate(stepper.keys)}, time_step, 0
    )
    result = {
        "timeStep": time_step,
        "timeIndex": 0,
        "numSteps": steps,
        "elements": [
            {"name": k, "values": [[z.real, z.imag] for z in v]}
            for k, v in time_series.values.items()
        ],
    }

    job.update(
        completedAt=datetime.now().isoformat(), state="succeeded", progress=100, result=result
    )
    report(
        f"Time-domain simulation {job.simulation_id} succeeded: {time_series}",
        None,
        "info",
        send=False,
    )


def monitor_s_matrix(runner: object, job: Job):
    if isinstance(runner, SMatrix):
        message = "success"
    else:
        message = monitor_status(runner, job, 1)
    job.sim_job["completedAt"] = datetime.now().isoformat()

    if message == "success":
        report(
            f"Frequency-domain simulation {job.simulation_id} completed runner phase.",
            None,
            "debug",
            send=False,
        )

        with job.lock:
            job.tasks.clear()

        try:
            s_matrix = runner if isinstance(runner, SMatrix) else runner.s_matrix
        except Exception as err:
            job.update(
                state="failed",
                result={"level": "error", "message": str(err), "id": job.simulation_id},
            )
            report(
                f"Failed to collect S-matrix for simulation {job.simulation_id}: {err}",
                None,
                send=False,
            )
            return

        if s_matrix is None:
            job.update(
                state="failed",
                result={
                    "level": "error",
                    "message": "S matrix unavailable",
                    "id": job.simulation_id,
                },
            )
            report(
                f"S-matrix result was unavailable for simulation {job.simulation_id}.",
                None,
                send=False,
            )
            return

        result = {
            "frequencies": s_matrix.frequencies.tolist(),
            "wavelengths": s_matrix.wavelengths.tolist(),
            "elements": [
                {"input": i, "output": j, "values": [[z.real, z.imag] for z in v.tolist()]}
                for (i, j), v in s_matrix.elements.items()
            ],
        }

        job.update(state="succeeded", result=result)
        report(
            f"Frequency-domain simulation {job.simulation_id} succeeded: {s_matrix}",
            None,
            "info",
            send=False,
        )
    else:
        if job.sim_job.get("result") is None:
            job.sim_job["result"] = {
                "level": "error",
                "message": f"S matrix computation failed: {message}",
                "id": job.simulation_id,
            }
            report(
                f"Frequency-domain simulation {job.simulation_id} failed: {message}",
                None,
                send=False,
            )
        job.update(state="failed")


def start_job(
    job: Job,
    component: pf.Component,
    application: SchematicApplication,
    event_id: str,
) -> bool:
    if application.simulationSettings.simulationMode == "time":
        settings = application.simulationSettings.timeDomain
        if settings is None:
            report(f"Missing time domain settings for simulation {job.simulation_id}", event_id)
            return False

        report(f"Simulation {job.simulation_id} settings: {settings}", event_id, "debug")

        time_step = settings.timeStep
        steps = int(settings.duration // time_step)
        carrier_frequency = settings.carrierFrequency

        if carrier_frequency == 0:
            start_freq = 0
            end_freq = settings.frequencyBandwidth * 2
        else:
            start_freq = max(0, carrier_frequency - settings.frequencyBandwidth)
            end_freq = carrier_frequency + settings.frequencyBandwidth
        frequencies = np.linspace(start_freq, end_freq, settings.frequencyPoints)

        monitors = {}
        for monitor in settings.monitors:
            for reference in component.references:
                if reference._id == monitor.referenceId:
                    ports = reference.get_ports(monitor.name)
                    if len(ports) == 1:
                        monitors[monitor.externalName] = ports[0]
                    break
            if monitor.externalName not in monitors:
                report(
                    f"Invalid monitor in component {component.name!r}: {monitor}",
                    event_id,
                    "warning",
                )

        if len(component.ports) == 0 and len(monitors) == 0:
            report(
                f"Component {component.name!r} has no ports or monitor. Time-domain simulation "
                f"would have no results.",
                event_id,
            )
            return False

        classification = pf.frequency_classification(frequencies)
        report(
            f"Resolved time-domain frequencies for {component.name!r} as {classification}.",
            event_id,
            "debug",
        )
        model = component.select_active_model(classification)
        if model is None:
            report(
                f"No model for {classification} frequencies in component {component.name!r}",
                event_id,
            )
            return False

        stepper = model.time_stepper
        if stepper is None:
            report(f"No time stepper for {model} in component {component.name!r}", event_id)
            return False

        try:
            runner = stepper.setup_state(
                component=component,
                time_step=time_step,
                carrier_frequency=carrier_frequency,
                frequencies=frequencies,
                monitors=monitors,
                show_progress=False,
            )
        except Exception as err:
            report(f"Time stepper setup error for component {component.name!r}: {err}", event_id)
            return False

        report(
            f"Time-domain simulation setup completed for component {component.name!r}.",
            event_id,
            "debug",
        )

        job.thread = Thread(
            target=monitor_time_stepping,
            args=(stepper, runner, time_step, steps, job),
            name=f"T_{job.simulation_id}",
            daemon=True,
        )
        job.thread.start()
        report(f"Started monitor thread for job {job.simulation_id}", event_id, "debug", send=False)

    else:  # application.simulationSettings.simulationMode == "frequency"
        if len(component.ports) == 0:
            report(
                f"Component {component.name!r} has no ports. Frequency-domain simulation cannot "
                f"run.",
                event_id,
            )
            return False

        settings = application.simulationSettings.frequencyDomain
        if settings is None:
            report(
                f"Missing frequency domain settings for simulation {job.simulation_id}", event_id
            )
            return False

        report(f"Simulation {job.simulation_id} settings: {settings}", event_id, "debug")

        try:
            frequencies = pf.C_0 / np.linspace(
                settings.startWavelength, settings.stopWavelength, settings.points
            )
            classification = pf.frequency_classification(frequencies)
        except Exception as err:
            report(f"Error in wavelength setting: {err}", event_id)
            return False

        report(
            f"Resolved frequency-domain sweep for {component.name!r} as {classification}.",
            event_id,
            "debug",
        )

        model = component.select_active_model(classification)
        if model is None:
            report(
                f"No model for {classification} frequencies in component {component.name!r}",
                event_id,
            )
            return False

        try:
            runner = model.start(component, frequencies, verbose=False)
        except Exception as err:
            report(f"Error starting simulation for component {component.name!r}: {err}", event_id)
            return False

        report(
            f"Frequency-domain simulation setup completed for component {component.name!r}.",
            event_id,
            "debug",
        )

        job.thread = Thread(
            target=monitor_s_matrix, args=(runner, job), name=f"T_{job.simulation_id}", daemon=True
        )
        job.thread.start()
        report(f"Started monitor thread for job {job.simulation_id}", event_id, "debug", send=False)

    return True
