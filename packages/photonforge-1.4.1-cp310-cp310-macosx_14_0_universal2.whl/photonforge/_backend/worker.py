import asyncio
import importlib
import queue
import time
from collections import namedtuple
from datetime import datetime
from json import loads as json_loads
from logging.handlers import QueueHandler
from multiprocessing import Queue, current_process
from threading import Event, Lock
from typing import Literal

from pydantic import ValidationError
from tidy3d.config import get_manager
from tidy3d.web.api.webapi import abort
from tidy3d.web.core.exceptions import WebError

import photonforge as pf
import photonforge.pda as pda
import photonforge.pda._client
from photonforge.extension import _export
from photonforge.pda._client import (
    _create_document,
    _find_repo_document,
    _technology_type,
    _ui_component_type,
)
from photonforge.pda._component import CANVAS_SCALING_FACTOR, component_from_pf
from photonforge.pda._crdt.document import Document
from photonforge.pda._crdt.refs import AutomergeRef
from photonforge.pda._parametric_schema import inspect_parameters, kwargs_from_schema
from photonforge.pda._project import _load_project, sort_exported_data
from photonforge.pda._sync_runtime import run as _run
from photonforge.pda._types import (
    DocumentId,
    ReadOnlyURL,
    SchematicApplication,
    UiComponent,
    UiReference,
)

from .monitor import Job, report, start_job

photonforge.pda._client._warned = True

CachedProject = namedtuple(
    "CachedProject", ["project", "components_by_name", "technologies_by_name", "available_objects"]
)


def cached(project: pda.Project) -> CachedProject:
    proj_id = project._doc.id
    components_by_name = {
        v.obj.name: v.obj for v in project._components.values() if v.parent_id == proj_id
    }
    technologies_by_name = {
        v.obj.name: v.obj for v in project._technologies.values() if v.parent_id == proj_id
    }
    available_objects = {k: v.obj for k, v in project._components.items()}
    available_objects.update({k: v.obj for k, v in project._technologies.items()})
    return CachedProject(project, components_by_name, technologies_by_name, available_objects)


async def resolve_ui_component_and_fields(
    id_or_ref: DocumentId | ReadOnlyURL | None,
    required_fields: set[str],
    cache: CachedProject,
    event_id: str,
) -> (
    tuple[
        pf.Component | None,
        Literal["current", "stale"] | None,
        ReadOnlyURL | None,
        dict[str, object],
    ]
    | None
):
    """Resolve an ID or reference URL to a project component."""
    report(f"Resolving component {id_or_ref}.", event_id, "debug")

    resolved_component = None
    referenced_component_ref = None
    resolved_state = None
    fields = {}
    visited = set()
    resolution_depth = 0
    while resolved_component is None or len(required_fields) > 0:
        if id_or_ref is None:
            break

        am_ref = AutomergeRef.parse(id_or_ref)
        ui_id = am_ref.document_id
        if ui_id in visited:
            report(f"Detected a referenced component cycle while resolving {ui_id}.", event_id)
            return None
        visited.add(ui_id)

        if not await wait_for_reference_snapshot(am_ref, event_id):
            return None

        ui_doc = await _find_repo_document(am_ref.ref)
        if ui_doc is None:
            report(f"UI component {ui_id} could not be found in PDA.", event_id)
            return None

        if resolved_component is None:
            component_data = cache.project._components.get(ui_id)
            if component_data is not None:
                report(f"Component {ui_id} is found in project.", event_id, "debug")
                resolved_component = component_data.obj
                if ui_doc.ref == am_ref.ref:
                    resolved_state = "current"
                else:
                    resolved_state = "stale"
                if resolution_depth > 0:
                    referenced_component_ref = am_ref.ref
            else:
                report(f"Component {ui_id} is outside the project.", event_id, "debug")

        try:
            ui_component_data = ui_doc.read()
            ui_component = UiComponent.model_validate(ui_component_data)
        except ValidationError as err:
            report(f"Invalid UI component payload for {ui_id}: {err}", event_id)
            return None
        except Exception as err:
            report(f"Error loading UI component {id_or_ref}: {err}", event_id)
            return None

        # name and pfRef only make sense locally: names must be unique and pfRef points to the
        # pf-native data document (no 2 UI components should point to the same data).
        if "name" in required_fields:
            fields["name"] = ui_component.name
            required_fields.remove("name")
        if "pfRef" in required_fields:
            fields["pfRef"] = ui_component.pfRef
            required_fields.remove("pfRef")
        for field in tuple(required_fields):
            value = getattr(ui_component, field)
            if value is not None:
                fields[field] = value
                required_fields.remove(field)

        resolution_depth += 1
        id_or_ref = ui_component.referencedComponent

    report(
        f"Resolved: {getattr(resolved_component, 'name', None)!r}; state: {resolved_state}; "
        f"referenced: {referenced_component_ref}; fields {fields}.",
        event_id,
        "debug",
    )
    return resolved_component, resolved_state, referenced_component_ref, fields


def new_parametric(
    component_or_fn: pf.Component | str,
    parameters: dict[str, object],
    cache: CachedProject,
    event_id: str,
) -> pf.Component | None:
    if isinstance(component_or_fn, pf.Component):
        component = component_or_fn
        fn_name = component.parametric_function
        report(
            f"Recomputing component {component_or_fn.name!r} from referenced parameters.",
            event_id,
            "debug",
        )
    elif component_or_fn:
        component = None
        fn_name = component_or_fn
        report(
            f"Recomputing factory function {fn_name!r} from referenced parameters.",
            event_id,
            "debug",
        )
    else:
        report("Missing referenced component or factory function to recompute", event_id)
        return None

    fn = pf._component_registry.get(fn_name)
    if fn is None and fn_name is not None and "." in fn_name:
        module_name, _, _ = fn_name.rpartition(".")
        try:
            importlib.import_module(module_name)
        except Exception as err:
            report(f"Error importing parametric module {module_name!r}: {err}", event_id)
            return None
        fn = pf._component_registry.get(fn_name)
    if fn is None:
        if fn_name is None:
            message = (
                f"Component {component.name!r} is not parametric and cannot be "
                "recomputed from UI parameters."
            )
        else:
            message = f"Parametric function {fn_name} not found: component cannot be updated."
        report(message, event_id)
        return None

    report(f"Deserializing parameters: {parameters}", event_id, "debug")
    try:
        _, _, classes = inspect_parameters(fn)
        kwargs = kwargs_from_schema(parameters, classes, cache.available_objects)
    except Exception as err:
        report(f"Error inspecting parameters from {fn_name!r}: {err}", event_id)
        return None

    report(f"Building component from {fn_name!r} with kwargs {kwargs}", event_id, "debug")
    try:
        new_component = fn(**kwargs, use_parametric_cache=False)
    except Exception as err:
        report(
            f"Error recomputing factory {fn_name!r} from UI parameters: {err}",
            event_id,
        )
        return None

    report(
        f"Recomputed parametric component from factory {fn_name!r} as {new_component.name!r}.",
        event_id,
        "debug",
    )

    # Preserve active models, if possible
    if component is not None:
        active_models = component.active_model_name
        if active_models is not None:
            if isinstance(active_models, str):
                active_models = {None: active_models}
            new_models = new_component.models
            for classification, name in active_models.items():
                if name in new_models:
                    new_component.activate_model(name, classification=classification)

    return new_component


def _copy_component_shell(component: pf.Component, name: str) -> pf.Component:
    new_component = pf.Component(name, component.technology)
    for model_name, model in component.models.items():
        new_component.add_model(model, model_name)

    active_models = component.active_model_name
    if isinstance(active_models, str):
        active_models = {None: active_models}
    for classification, model_name in active_models.items():
        if model_name in new_component.models:
            new_component.activate_model(model_name, classification=classification)

    return new_component


def _reference_kwargs_from_canvas_transform(
    ref_component: pf.Component, ui_ref: UiReference, ui_name: str, event_id: str
) -> dict[str, object]:
    kwargs = ui_ref.canvasProperties.transform.to_kwargs()
    kwargs["origin"] /= CANVAS_SCALING_FACTOR
    report(
        f"No layout transform for {ui_ref.id} ({ref_component.name!r}) in {ui_name!r}: "
        "reconstructed origin from schematic center.",
        event_id,
        "warning",
    )
    return kwargs


async def _component_from_ui(
    ui_id: DocumentId | ReadOnlyURL,
    cache: CachedProject,
    event_id: str,
    *,
    build_cache: dict[str, pf.Component],
    build_stack: set[str],
    mutate_existing: bool,
) -> pf.Component | None:
    am_ref = AutomergeRef.parse(ui_id)
    cache_key = am_ref.ref if len(am_ref.heads) > 0 else am_ref.document_id
    if cache_key in build_cache:
        return build_cache[cache_key]

    if cache_key in build_stack:
        report(f"Detected a schematic reference cycle while building {ui_id}.", event_id)
        return None
    build_stack.add(cache_key)

    try:
        resolved = await resolve_ui_component_and_fields(
            ui_id,
            {"name", "references", "ports", "terminals", "virtualConnections"},
            cache,
            event_id,
        )
        if resolved is None:
            return None
        resolved_component, resolved_state, referenced_component_ref, fields = resolved

        ui_name = fields.get("name", "")
        ui_references = fields.get("references", {})
        ui_ports = fields.get("ports", [])
        ui_terminals = fields.get("terminals", [])
        ui_connections = fields.get("virtualConnections", {})
        connected_port_origins = {
            (endpoint.referenceId, endpoint.name)
            for connection in ui_connections.values()
            for endpoint in (connection.frm, connection.to)
        }

        # Make sure references exist before changing the component
        references = {}
        for ui_ref in ui_references.values():
            report(
                f"Building reference {ui_ref.id} → {ui_ref.component} for {ui_name!r} ({ui_id}).",
                event_id,
                "debug",
            )
            resolved = await resolve_ui_component_and_fields(
                ui_ref.component,
                {"name", "pfRef", "references", "parameters", "parametersSchema"},
                cache,
                event_id,
            )
            if resolved is None:
                return None
            ref_component, ref_state, ref_ref, ref_fields = resolved

            is_static = ref_fields.get("parametersSchema") is None
            if is_static:
                should_rebuild = ref_component is None or (
                    len(ref_fields.get("references", {})) > 0 and ref_state == "stale"
                )
                if should_rebuild:
                    report(
                        f"Referenced component {ui_ref.component} is a live schematic: rebuilding.",
                        event_id,
                        "debug",
                    )
                    ref_component = await _component_from_ui(
                        ui_ref.component,
                        cache,
                        event_id,
                        build_cache=build_cache,
                        build_stack=build_stack,
                        mutate_existing=mutate_existing,
                    )
                    if ref_component is None:
                        return None
                else:
                    report(
                        f"Referenced component {ref_component.name!r} is static.",
                        event_id,
                        "debug",
                    )
            else:
                report(
                    f"Referenced component {ui_ref.component} is live parametric: updating from "
                    f"{ref_component or ref_fields.get('pfRef')}.",
                    event_id,
                    "debug",
                )
                # component_from_pf stores the parametric function name in pfRef. That is only
                # overwriten by an automerge doc when saving in the project.
                ref_component = new_parametric(
                    ref_component or ref_fields.get("pfRef"),
                    ref_fields.get("parameters", {}),
                    cache,
                    event_id,
                )
                if ref_component is None:
                    return None
                ref_name = ref_fields.get("name")
                if ref_name:
                    ref_component.name = ref_name
                ref_component._pda_id = AutomergeRef.parse_id(ui_ref.component)

            if ui_ref.transform is not None:
                kwargs = ui_ref.transform.to_kwargs()
            elif (
                ui_ref.canvasProperties is not None
                and ui_ref.canvasProperties.transform is not None
            ):
                kwargs = _reference_kwargs_from_canvas_transform(
                    ref_component, ui_ref, ui_name, event_id
                )
            else:
                report(
                    f"No layout or schematic transform for {ui_ref.id} ({ref_component.name!r}) in "
                    f"{ui_name!r}. Generated circuit might have overlapping components.",
                    event_id,
                    "warning",
                )
                kwargs = {}
            references[ui_ref.id] = pf.Reference(ref_component, **kwargs)
            references[ui_ref.id]._id = ui_ref.id

        if mutate_existing and resolved_state == "current" and referenced_component_ref is None:
            report(
                f"Updating in-project component {ui_name!r} ({ui_id}) from current UI state.",
                event_id,
                "debug",
            )
            component = resolved_component
            if ui_name:
                component.name = ui_name
        else:
            report(f"Building component {ui_name!r} ({ui_id}) from UI data.", event_id, "debug")
            if resolved_state == "current" and referenced_component_ref is None:
                component = _copy_component_shell(resolved_component, ui_name)
            else:
                technology = None
                if resolved_component is not None:
                    technology = resolved_component.technology
                elif len(references) > 0:
                    technology = sorted(references.items())[0][1].component.technology
                if len(ui_name) == 0:
                    ui_name = "Component"
                component = pf.Component(ui_name, technology)
                component.add_model(pf.CircuitModel(), "Circuit")
            component._pda_id = am_ref.document_id

        if mutate_existing:
            for args, _ in component.virtual_connections_by_instance:
                component.remove_virtual_connection_by_instance(*args)
            for name in component.ports:
                component.remove_port(name)
            for name in component.terminals:
                component.remove_terminal(name)
            component.remove(*component.references)

        component.add(*references.values())

        for ui_port in ui_ports:
            if ui_port.origin is None:
                report(
                    f"Skipping port {ui_port.name!r}: only reference ports can be added.",
                    event_id,
                    "warning",
                )
                continue
            if (ui_port.origin.referenceId, ui_port.origin.name) in connected_port_origins:
                report(
                    f"Skipping exposed port {ui_port.name!r}: origin "
                    f"{ui_port.origin.referenceId}.{ui_port.origin.name} is internally connected.",
                    event_id,
                    "debug",
                )
                continue
            reference = references.get(ui_port.origin.referenceId)
            if reference is None:
                report(
                    f"Invalid reference port {ui_port.name!r}: reference "
                    f"{ui_port.origin.referenceId} not found.",
                    event_id,
                    "warning",
                )
                continue
            ports = reference.get_ports(ui_port.origin.name)
            if len(ports) == 0:
                report(
                    f"Invalid reference port {ui_port.name!r}: port {ui_port.origin.name} "
                    f"not found in referenced component.",
                    event_id,
                    "warning",
                )
                continue
            component.add_port(ports[0], ui_port.name)

        for ui_terminal in ui_terminals:
            if ui_terminal.name is None:
                continue
            if ui_terminal.origin is None:
                report(
                    f"Skipping terminal {ui_terminal.name!r}: only reference terminals can "
                    f"be added.",
                    event_id,
                    "warning",
                )
                continue
            if ui_terminal.origin.referenceId is None:
                if ui_terminal.origin.portName is None:
                    report(
                        f"Invalid reference terminal {ui_terminal.name!r}: missing reference "
                        f"ID and "
                        f"port name.",
                        event_id,
                        "warning",
                    )
                    continue
                ports = component.get_ports(ui_terminal.origin.portName)
                if len(ports) == 0:
                    report(
                        f"Invalid reference terminal {ui_terminal.name!r}: port "
                        f"{ui_terminal.origin.portName} not found in component.",
                        event_id,
                        "warning",
                    )
                    continue
                terminal = ports[0].terminals().get(ui_terminal.origin.name)
                if terminal is None:
                    report(
                        f"Invalid reference terminal {ui_terminal.name!r}: terminal "
                        f"{ui_terminal.origin.name} not found in port.",
                        event_id,
                        "warning",
                    )
                    continue
                component.add_terminal(terminal, ui_terminal.name)
            else:
                reference = references.get(ui_terminal.origin.referenceId)
                if reference is None:
                    report(
                        f"Invalid reference terminal {ui_terminal.name!r}: reference "
                        f"{ui_terminal.origin.referenceId} not found.",
                        event_id,
                        "warning",
                    )
                    continue
                if ui_terminal.origin.portName is None:
                    terminals = reference.get_terminals(ui_terminal.origin.name)
                    if len(terminals) == 0:
                        report(
                            f"Invalid reference terminal {ui_terminal.name!r}: terminal "
                            f"{ui_terminal.origin.name} not found in referenced component.",
                            event_id,
                            "warning",
                        )
                        continue
                    component.add_terminal(terminals[0], ui_terminal.name)
                else:
                    ports = reference.get_ports(ui_terminal.origin.portName)
                    if len(ports) == 0:
                        report(
                            f"Invalid reference terminal {ui_terminal.name!r}: port "
                            f"{ui_terminal.origin.portName} not found in referenced component.",
                            event_id,
                            "warning",
                        )
                        continue
                    terminal = ports[0].terminals().get(ui_terminal.origin.name)
                    if terminal is None:
                        report(
                            f"Invalid reference terminal {ui_terminal.name!r}: terminal "
                            f"{ui_terminal.origin.name} not found in referenced port.",
                            event_id,
                            "warning",
                        )
                        continue
                    component.add_terminal(terminal, ui_terminal.name)

        for connection in ui_connections.values():
            r0 = references.get(connection.frm.referenceId)
            r1 = references.get(connection.to.referenceId)
            if r0 is None or r1 is None:
                invalid = connection.frm.referenceId if r0 is None else connection.to.referenceId
                report(
                    f"Invalid connection to reference {invalid}: reference not found.",
                    event_id,
                    "warning",
                )
                continue
            component.add_virtual_connection(r0, connection.frm.name, r1, connection.to.name)

        build_cache[cache_key] = component
        return component
    finally:
        build_stack.remove(cache_key)


_REF_SYNC_TIMEOUT = 10.0
_REF_SYNC_INITIAL_DELAY = 0.05
_REF_SYNC_MAX_DELAY = 0.5
_REF_SYNC_DELAY_FACTOR = 1.8


async def wait_for_reference_snapshot(am_ref: AutomergeRef, event_id: str) -> bool:
    """Wait until the worker can read a heads-pinned document snapshot."""
    if len(am_ref.heads) == 0:
        return True

    report(f"Waiting for referenced snapshot {am_ref.ref}.", event_id, "debug")

    loop = asyncio.get_running_loop()
    deadline = loop.time() + _REF_SYNC_TIMEOUT
    delay = _REF_SYNC_INITIAL_DELAY
    last_error: Exception | None = None
    latest_ref = ""

    while True:
        try:
            latest = await _find_repo_document(am_ref.document_id, check=False)
            if latest is not None:
                latest_ref = latest.ref
                if latest.ref == am_ref.ref:
                    snapshot = latest.read()
                else:
                    snapshot = latest.read_at(am_ref.heads)
                if snapshot:
                    return True
                last_error = RuntimeError("Snapshot payload is still empty.")
            else:
                latest_ref = ""
        except Exception as err:
            last_error = err

        remaining = deadline - loop.time()
        if remaining <= 0:
            detail = f": {last_error}" if last_error is not None else ""
            synced_ref = f" Latest local ref: {latest_ref}." if latest_ref else ""
            report(
                f"Requested ref {am_ref.ref} has not synchronized{detail}.{synced_ref}",
                event_id,
                "warning",
            )
            return False

        await asyncio.sleep(min(delay, remaining))
        delay = min(delay * _REF_SYNC_DELAY_FACTOR, _REF_SYNC_MAX_DELAY)


async def update_from_parameters(
    component_ref: ReadOnlyURL, cache: CachedProject, event_id: str
) -> pf.Component | None:
    """Update UI document from current parameters."""
    report(f"Updating component parameters for {component_ref}.", event_id, "debug")

    am_ref = AutomergeRef.parse(component_ref)
    if not await wait_for_reference_snapshot(am_ref, event_id):
        return None

    referenced_id = am_ref.document_id
    resolved = await resolve_ui_component_and_fields(
        component_ref, {"name", "pfRef", "parameters"}, cache, event_id
    )
    if resolved is None:
        return None

    resolved_component, _, referenced_ref, fields = resolved
    # component_from_pf stores the parametric function name in pfRef. That is only overwriten by an
    # automerge doc when saving in the project.
    new_component = new_parametric(
        resolved_component or fields.get("pfRef"),
        fields.get("parameters", {}),
        cache,
        event_id,
    )
    if new_component is None:
        return None
    old_name = fields.get("name")
    if old_name:
        new_component.name = old_name
    new_component._pda_id = referenced_id

    report(
        f"Serializing recalculated component {new_component.name!r} {referenced_id} into UI "
        f"documents.",
        event_id,
        "debug",
    )

    # Important: the new components and technologies generated internally are not available later
    # for deserialization because we don't gather them all in a project-like structure. That means
    # we can only reconstruct parametric components directly from the root node, and internal ones
    # may fail if they depend on objects not available in the project. A long-lived project-like
    # workspace can help, but it will be lost on shutdown. We can either try to store and restore it
    # (based on application id?), or live with this limitation.

    available_refs = {}
    project_id = cache.project._doc.id
    # Export to gather all required dependencies and create missing IDs
    try:
        objects, _ = _export(new_component)
    except Exception as err:
        report(f"Error in internal serialization of {new_component!r}: {err}", event_id)
        return None
    for _, obj in objects.items():
        if isinstance(obj, pf.Technology):
            project_technology = cache.technologies_by_name.get(obj.name)
            if obj is project_technology:
                # Does not need content change, so add early to available_refs
                ref_id = project_technology._pda_id
                available_refs[ref_id] = cache.project._technologies[ref_id].doc.ref
                report(
                    f"Technology {obj.name!r} found in project as {available_refs[ref_id]}.",
                    event_id,
                    "debug",
                )
            elif len(obj._pda_id) == 0:
                try:
                    doc_info = await _create_document(_technology_type, project_id)
                    obj._pda_id = doc_info["documentId"]
                except Exception as err:
                    report(
                        f"Error creating UI document for technology {obj.name!r}: {err}",
                        event_id,
                    )
                    return None
        elif isinstance(obj, pf.Component):
            project_component = cache.components_by_name.get(obj.name)
            if obj is project_component:
                # Does not need content change, so add early to available_refs
                ref_id = project_component._pda_id
                available_refs[ref_id] = cache.project._components[ref_id].ui_doc.ref
                report(
                    f"Component {obj.name!r} found in project as {available_refs[ref_id]}.",
                    event_id,
                    "debug",
                )
            elif len(obj._pda_id) == 0:
                try:
                    ui_doc_info = await _create_document(_ui_component_type, project_id)
                    obj._pda_id = ui_doc_info["documentId"]
                except Exception as err:
                    report(
                        f"Error creating UI document for component {obj.name!r}: {err}",
                        event_id,
                    )
                    return None
        else:
            report(f"Unsupported object in exported data: {obj!r}.", event_id)
            return None

    # Re-export to use all newly generated IDs
    try:
        objects, exported_data = _export(new_component, use_json=True)
        exported_data = json_loads(exported_data)
        sorted_data = sort_exported_data(objects, exported_data)
    except Exception as err:
        report(f"Error in internal serialization of {new_component!r}: {err}", event_id)
        return None
    for obj_id, obj_data, obj in sorted_data:
        if obj_id in available_refs:
            continue
        if isinstance(obj, pf.Technology):
            try:
                doc = await _find_repo_document(obj_id)
                doc.change(obj_data)
            except Exception as err:
                report(
                    f"Error exporting recalculated technology {obj.name!r}: {err}",
                    event_id,
                )
                return None
            available_refs[obj_id] = doc.ref
            report(f"Updated technology {obj.name!r} to {doc.ref}.", event_id, "debug")
        else:
            try:
                ui_doc = await _find_repo_document(obj._pda_id)
            except Exception as err:
                report(f"Error loading document for component {obj.name!r}: {err}", event_id)
                return None
            existing_ui = None
            try:
                existing_ui = UiComponent.model_validate(ui_doc.read())
            except Exception as err:
                report(
                    f"Error loading existing UI data for component {obj.name!r}: {err}",
                    event_id,
                    "warning",
                )
            try:
                ui_component = await component_from_pf(
                    obj,
                    model_schemas=cache.project._data["modelSchemas"],
                    component_schemas=cache.project._data["componentSchemas"],
                    available_refs=available_refs,
                    project_id=project_id,
                    existing_ui=existing_ui,
                    allow_project_changes=False,
                )
                # Keep original referenced component in case this live component is copy/pasted.
                # The original is required for us to find the parametric function, because this
                # newly generated component won't have a project-stored pfRef document yet.
                if obj_id == referenced_id:
                    ui_component.referencedComponent = referenced_ref
                # TODO: make the ui_doc sparse by using referencedComponent
                ui_doc.change(ui_component.model_dump(mode="json"))
            except Exception as err:
                report(
                    f"Error exporting recalculated component {obj.name!r} to UI data: {err}",
                    event_id,
                )
                return None
            available_refs[obj._pda_id] = ui_doc.ref
            report(f"Updated live component {obj.name!r} to {ui_doc.ref}.", event_id, "debug")

    report(
        f"Updated component UI document for {new_component.name!r} ({referenced_id}).",
        event_id,
        "info",
    )
    return new_component


def ensure_unique_name(
    component: pf.Component, project: pda.Project, all_names: set[str], event_id: str
):
    if component._pda_id in project._components:
        return
    if component.name in all_names:
        i = 1
        while f"{component.name}_{i}" in all_names:
            i += 1
        new_name = f"{component.name}_{i}"
        report(
            f"Renaming {component.name!r} to {new_name!r} to avoid duplicate names.",
            event_id,
            "info",
        )
        component.name = new_name
    all_names.add(component.name)


async def component_to_pf(
    ui_ref: ReadOnlyURL, add_or_update: bool, cache: CachedProject, event_id: str
) -> pf.Component | None:
    report(
        f"Converting UI component {ui_ref} to PhotonForge component; persist={add_or_update}.",
        event_id,
        "debug",
    )
    component = await _component_from_ui(
        ui_ref,
        cache,
        event_id,
        build_cache={},
        build_stack=set(),
        mutate_existing=add_or_update,
    )
    if component is None:
        return None

    if add_or_update:
        # Make sure all new components have unique names
        all_names = set(cache.components_by_name.keys())
        ensure_unique_name(component, cache.project, all_names, event_id)
        for dep in component.dependencies():
            ensure_unique_name(dep, cache.project, all_names, event_id)

        if component._pda_id in cache.project._components:
            report(
                f"Saved updated application component {component.name!r} {component._pda_id}.",
                event_id,
                "info",
            )
            try:
                await cache.project._add_or_update(
                    False, component, None, None, True, False, False, True
                )
            except Exception as err:
                report(
                    f"Error saving updated application component {component.name!r}: {err}",
                    event_id,
                )
                return None
        else:
            report(
                f"Saving new application component {component.name!r} {component._pda_id}.",
                event_id,
                "info",
            )
            try:
                await cache.project._add_or_update(
                    True, component, None, None, True, False, True, True
                )
            except Exception as err:
                report(
                    f"Error saving new application component {component.name!r}: {err}",
                    event_id,
                )
                return None
    else:
        report(
            f"Resolved simulation component {component.name!r} without making project changes.",
            event_id,
            "debug",
        )

    return component


async def _recover_pda_if_dead() -> bool:
    """Detect a dead `RepoManager` connect_task and rebuild from scratch.

    samod's `Repo.connect(transport)` task can end mid-session for several
    reasons — websockets keepalive timeout while the asyncio loop is
    starved during heavy simulation work, sync-server hiccup, etc. Once
    `connect_task` is `done()`, no further sync messages flow through the
    transport: cached `DocHandle`s silently return stale state, and
    `wait_for_reference_snapshot` polls in vain because there's no pipe
    for new ops to arrive on.

    A transport-level reconnect doesn't work — samod's protocol state
    machine doesn't know how to re-issue the `join` handshake, so swapping
    the inner WebSocket leaves it stuck. The only viable recovery is to
    rebuild the entire `RepoManager` (new peer-id, new WS, fresh
    subscriptions) and let `reload_project` re-populate caches on the
    next event. See `docs/sdj/2026-05-07-pda-worker-sync-reconnect.md`.

    Returns:
        ``True`` if the connect_task was dead and we re-initialized
        successfully — caller MUST clear `project` and `applications`
        caches so `reload_project` re-fetches against the fresh repo and
        refresh any active job document handles.
        ``False`` if the repo was healthy (no action taken) or the
        re-init itself failed (we're out of options).
    """
    mgr = photonforge.pda._client._repo_mgr
    if mgr is None:
        return False
    ct = getattr(mgr, "_connect_task", None)
    if ct is None or not ct.done():
        return False  # still alive — common path, no work

    # connect_task ended → samod has given up on this transport. Surface
    # *why* it ended at warning level for postmortem visibility.
    try:
        result = ct.result()
        report(
            f"PDA repo connect_task ended with {result!r}; re-initializing.",
            None,
            "warning",
            send=False,
        )
    except Exception as err:
        report(
            f"PDA repo connect_task failed with {err!r}; re-initializing.",
            None,
            "warning",
            send=False,
        )

    # Tear down the dead manager (closes transport, stops repo). Errors
    # during shutdown are non-fatal — we're going to recreate everything.
    try:
        await photonforge.pda._client._stop()
    except Exception as err:
        report(
            f"Error during PDA stop on recovery (continuing): {err!r}",
            None,
            "warning",
            send=False,
        )

    try:
        await photonforge.pda._client._init()
    except Exception as err:
        report(
            f"PDA re-init after connect_task death failed: {err!r}",
            None,
            "error",
            send=False,
        )
        return False  # we tried; caller will see a dead repo on the next call

    report(
        "PDA repo re-initialized; caches will be rebuilt on next reload.",
        None,
        "info",
        send=False,
    )
    return True


async def reload_project(
    project: pda.Project | None,
    project_id: DocumentId,
    required_ref: ReadOnlyURL | None,
    event_id: str,
) -> tuple[pda.Project, dict[DocumentId, tuple[Document, Document]]]:
    if required_ref is not None and not await wait_for_reference_snapshot(
        AutomergeRef.parse(required_ref), event_id
    ):
        return None, {}

    if project is None or project.id != project_id:
        try:
            report(f"Loading PDA project {project_id}", event_id, "info")
            project = await _load_project(project_id=project_id)
        except Exception as err:
            report(f"Error loading project {project_id}: {err}", event_id)
            return None, {}
    elif required_ref != project._doc_ref:
        try:
            report(f"Syncing PDA project {project_id}", event_id, "info")
            await project._reload(set_config=True, reload_module=True)
        except Exception as err:
            report(f"Error reloading project {project_id}: {err}", event_id)
            return None, {}

    report(f"Importing project {project_id} modules", event_id, "debug")
    try:
        # `import_module` is synchronous Python (importlib.import_module + class
        # registration) and can take many seconds with multiple libraries
        # attached (SiEPIC, Abstract Components, etc.). It runs inline on the
        # asyncio thread, which would normally cause the WS keepalive to
        # expire — *but* the WS is opened with `ping_interval=None` (see
        # `pda/_client.py`), so the connection survives the long block.
        # We deliberately do NOT offload to `asyncio.to_thread` here: the
        # imported library code may call `Component.get_netlist()` which has
        # known license-check issues in background-thread contexts
        # (`docs/sdj/2026-04-14-sync-runtime-limitations.md`).
        project.import_module(None)
    except Exception as err:
        report(f"Error importing project {project_id} modules: {err}", event_id)
        return None, {}

    try:
        applications = {}
        for app_id in project._data.get("applications", []):
            app_doc = await _find_repo_document(app_id)
            results = await _find_repo_document(app_doc.read()["results"])
            applications[app_id] = (app_doc, results)
    except ValidationError as err:
        report(f"Error validating application in project {project_id}: {err}", event_id)
        return None, {}
    except Exception as err:
        report(f"Error loading application in project {project_id}: {err}", event_id)
        return None, {}

    return project, applications


async def load_application(
    application_ref: ReadOnlyURL,
    applications: dict[DocumentId, tuple[Document, Document]],
    application_locks: dict[DocumentId, Lock],
    exact_match: bool,
    event_id: str,
) -> tuple[SchematicApplication, Document, Lock]:
    application_am_ref = AutomergeRef.parse(application_ref)
    application_id = application_am_ref.document_id
    app_doc, results_doc = applications.get(application_id, (None, None))
    if app_doc is None:
        report(f"Application {application_id} is not loaded.", event_id)
        return None, None, None
    lock = application_locks.setdefault(application_id, Lock())
    if (
        exact_match
        and app_doc.ref != application_ref
        and not await wait_for_reference_snapshot(application_am_ref, event_id)
    ):
        return None, None, None
    try:
        if exact_match and len(application_am_ref.heads) > 0:
            application_data = app_doc.read_at(application_am_ref.heads)
        else:
            application_data = app_doc.read()
        application = SchematicApplication.model_validate(application_data)
    except ValidationError as err:
        report(
            f"Application {application_id} has invalid schematic data: {err}",
            event_id,
        )
        return None, None, None
    except Exception as err:
        report(f"Error loading application {application_id}: {err}", event_id)
        return None, None, None
    return application, results_doc, lock


async def _flush_job_updates(jobs: dict[str, Job], update_queue: queue.Queue[str]) -> None:
    while True:
        try:
            simulation_id = update_queue.get_nowait()
        except queue.Empty:
            break
        job = jobs.get(simulation_id)
        if job is None:
            report(
                f"Dropping queued update for unknown simulation {simulation_id}.",
                None,
                "debug",
                send=False,
            )
            continue
        with job.lock:
            results = job.results_doc.read()
            results["simulations"][simulation_id] = dict(job.sim_job)
        job.results_doc.change(results)
    # This is important. It gives the automerge loop time to synchronize.
    await asyncio.sleep(0.05)


def create_job(
    jobs: dict[str, Job],
    results_doc: Document,
    lock: Lock,
    update_queue: queue.Queue[str],
    event: object,
) -> Job:
    job = Job(
        results_doc=results_doc,
        simulation_id=event.data.simulationId,
        sim_job={},
        tasks={},
        terminate=Event(),
        thread=None,
        lock=lock,
        update_queue=update_queue,
    )
    job.update(
        projectRef=event.data.projectRef,
        applicationRef=event.data.applicationRef,
        createdAt=datetime.now().isoformat(),
        startedAt=None,
        completedAt=None,
        state="queued",
        progress=0,
        result=None,
    )
    _run(_flush_job_updates({job.simulation_id: job, **jobs}, update_queue))
    return job


def refresh_job_documents(
    job: Job,
    applications: dict[DocumentId, tuple[Document, Document]],
    event_id: str,
) -> bool:
    simulation_id = job.simulation_id
    application_ref = job.sim_job.get("applicationRef")
    if not isinstance(application_ref, str):
        report(
            f"Simulation {simulation_id} is missing applicationRef after PDA recovery.",
            event_id,
        )
        job.terminate.set()
        return False
    application_id = AutomergeRef.parse(application_ref).document_id
    application_docs = applications.get(application_id)
    if application_docs is None:
        report(
            f"Application {application_id} for simulation {simulation_id} was not reloaded "
            "after PDA recovery.",
            event_id,
        )
        job.terminate.set()
        return False
    _, results_doc = application_docs
    with job.lock:
        job.results_doc = results_doc
    return True


def report_job_setup_failure(job: Job | None, jobs: dict[str, Job]) -> None:
    """Abort a job in the setup phase"""
    if job:
        job.update(
            state="failed",
            result={"level": "error", "message": "Job setup error", "id": job.simulation_id},
        )
        _run(_flush_job_updates({job.simulation_id: job, **jobs}, job.update_queue))


def start_worker(
    root_event_id: str,
    work_queue: Queue,
    response_queue: Queue,
    log_queue: Queue,
    profile: str,
):
    from . import monitor

    monitor.message_queue = response_queue
    monitor.logger.addHandler(QueueHandler(log_queue))

    report(f"Worker process {current_process().name} started.", root_event_id, "info", send=False)

    get_manager().switch_profile(profile)

    report("Opening PDA connections for worker startup.", root_event_id, "debug", send=False)
    for i in range(5):
        try:
            pda.init()
            break
        except Exception as err:
            if i == 4:
                report(f"Unable to open PDA connections after 5 attempts: {err}", root_event_id)
                return
            time.sleep(0.2 * (i + 1))

    project: pda.Project | None = None

    # Application ID: application doc, results doc
    applications: dict[DocumentId, tuple[Document, Document]] = {}
    # Locks are keyed by stable application ID and survive repo reconnects.
    application_locks: dict[DocumentId, Lock] = {}

    jobs: dict[str, Job] = {}
    update_queue: queue.Queue[str] = queue.Queue()
    idle_start = time.monotonic()

    while True:
        try:
            event = work_queue.get(True, 0.2)
        except queue.Empty:
            _run(_flush_job_updates(jobs, update_queue))
            if len(jobs) == 0:
                if time.monotonic() - idle_start >= 10 * 60:
                    report(
                        "Worker has been idle for 10 minutes with no active jobs; terminating.",
                        None,
                        "info",
                        send=False,
                    )
                    break
            continue

        idle_start = time.monotonic()
        _run(_flush_job_updates(jobs, update_queue))

        if event is None:
            report(
                "Worker termination requested by control queue sentinel.",
                None,
                "debug",
                send=False,
            )
            for job_id, job in jobs.items():
                report(
                    f"Requesting shutdown for active simulation {job_id}.",
                    None,
                    "info",
                    send=False,
                )
                job.terminate.set()

            for job_id, job in jobs.items():
                if job.thread is None:
                    continue
                report(
                    f"Waiting for simulation thread {job_id} to exit.",
                    None,
                    "debug",
                    send=False,
                )
                job.thread.join()
                for task_id in job.tasks:
                    report(
                        f"Aborting remote task {task_id} for simulation {job_id}.",
                        None,
                        "info",
                        send=False,
                    )
                    try:
                        abort(task_id)
                    except WebError:
                        pass
            break

        job = None
        if event.type == "application.save" or event.type == "simulation.request":
            project_id = AutomergeRef.parse(event.data.projectRef).document_id
            if event.type == "simulation.request":
                application, results_doc, lock = _run(
                    load_application(
                        event.data.applicationRef, applications, application_locks, False, event.id
                    )
                )
                if application is not None:
                    job = create_job(jobs, results_doc, lock, update_queue, event)
        else:
            project_id = event.data.projectId

        report(
            f"Received backend event {event.type} for project {project_id}.",
            event.id,
            "debug",
        )

        # Health-check the PDA repo BEFORE touching any cached doc state (except for early job
        # result). If samod's `Repo.connect()` task has died (websockets keepalive timeout during
        # simulation, sync-server restart, etc.), we rebuild the entire `RepoManager`, clear
        # per-project doc caches, and refresh active jobs against the fresh repo. See SDJ at
        # `docs/sdj/2026-05-07-pda-worker-sync-reconnect.md`.
        recovered = _run(_recover_pda_if_dead())
        if recovered:
            report(
                f"PDA recovered for event {event.type}; clearing project/application caches.",
                event.id,
                "debug",
            )
            project = None
            applications = {}

        if (
            event.type
            in ["project.library_add", "application.open", "application.save", "simulation.request"]
            or project is None
        ):
            project, applications = _run(
                reload_project(
                    project, project_id, getattr(event.data, "projectRef", None), event.id
                )
            )
            if project is None:
                report_job_setup_failure(job, jobs)
                continue

        if recovered:
            jobs = {
                k: v for k, v in jobs.items() if refresh_job_documents(v, applications, event.id)
            }
            if job is not None:
                if refresh_job_documents(job, applications, event.id):
                    _run(_flush_job_updates({job.simulation_id: job, **jobs}, update_queue))
                else:
                    job = None

        match event.type:
            case "project.library_add":
                report(
                    f"Adding library {event.data.libraryId} to project {project.name!r} and "
                    "refreshing imported modules.",
                    event.id,
                    "info",
                )
                try:
                    project.add_library(library_id=event.data.libraryId)
                except Exception as err:
                    report(
                        f"Failed to add library {event.data.libraryId} to project "
                        f"{project.name!r}: {err}",
                        event.id,
                    )
                    continue
                try:
                    project.import_module(globals())
                except Exception as err:
                    report(
                        f"Failed to refresh imported modules for project {project.name!r}: {err}",
                        event.id,
                    )
                    continue

            case "application.open":
                pass

            case "component.parameter_change":
                report(
                    f"Processing parameter change for component {event.data.componentRef}.",
                    event.id,
                    "info",
                )
                _run(update_from_parameters(event.data.componentRef, cached(project), event.id))

            case "application.save" | "simulation.request":
                if event.data.projectRef != project._doc_ref:
                    report(
                        "Backend has not synchronized to the requested project state: "
                        f"{event.data.projectRef} ≠ {project._doc_ref}",
                        event.id,
                    )
                    report_job_setup_failure(job, jobs)
                    continue
                application, results_doc, lock = _run(
                    load_application(
                        event.data.applicationRef,
                        applications,
                        application_locks,
                        True,
                        event.id,
                    )
                )
                if application is None:
                    report_job_setup_failure(job, jobs)
                    continue
                am_ref = AutomergeRef.parse(event.data.componentRef)
                if not _run(wait_for_reference_snapshot(am_ref, event.id)):
                    report_job_setup_failure(job, jobs)
                    continue

                if event.type == "application.save":
                    report(
                        f"Applying application {event.data.applicationRef} changes to project "
                        f"state.",
                        event.id,
                        "info",
                    )
                    _run(component_to_pf(event.data.componentRef, True, cached(project), event.id))

                else:
                    if job is None:
                        job = create_job(jobs, results_doc, lock, update_queue, event)
                    report(
                        f"Preparing component {application.component} for simulation "
                        f"{event.data.simulationId}.",
                        event.id,
                        "info",
                    )
                    component = _run(
                        component_to_pf(event.data.componentRef, False, cached(project), event.id)
                    )
                    if component is None:
                        report_job_setup_failure(job, jobs)
                        continue
                    if start_job(job, component, application, event.id):
                        jobs[event.data.simulationId] = job
                    else:
                        report_job_setup_failure(job, jobs)

            case "simulation.abort":
                simulation_id = event.data.simulationId
                job = jobs.get(simulation_id)
                if job is None:
                    report(
                        f"Simulation {simulation_id} was not found among active jobs.",
                        event.id,
                        "info",
                    )
                    continue

                report(f"Aborting active simulation {simulation_id}.", event.id, "info", send=False)
                job.terminate.set()
                job.thread.join()

                if job.sim_job["state"] in ("succeeded", "failed", "aborted"):
                    continue

                job.update(completedAt=datetime.now().isoformat(), state="aborted")

                remaining_tasks = set()
                for other_id, other_job in jobs.items():
                    if other_id != simulation_id:
                        with other_job.lock:
                            remaining_tasks.update(other_job.tasks.keys())
                for task_id in job.tasks:
                    if task_id in remaining_tasks:
                        report(
                            f"Skipping abort for shared remote task {task_id}; another "
                            "simulation still uses it.",
                            event.id,
                            "debug",
                        )
                        continue
                    report(
                        f"Aborting remote task {task_id} for simulation {simulation_id}.",
                        event.id,
                        "info",
                    )
                    try:
                        abort(task_id)
                    except WebError:
                        pass
                job.tasks = {}

            case _:
                report(f"Received unsupported backend event type {event.type!r}.", event.id)

        _run(_flush_job_updates(jobs, update_queue))

    report("Closing PDA connections for worker shutdown.", None, "debug", send=False)
    _run(_flush_job_updates(jobs, update_queue))
    pda.stop()

    report(f"Worker process {current_process().name} terminated.", None, "debug", send=False)
