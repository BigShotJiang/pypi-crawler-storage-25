"""PDA configuration plugin registration for tidy3d config."""

from __future__ import annotations

from pydantic import Field, model_validator
from tidy3d.config import get_manager
from tidy3d.config.registry import register_plugin
from tidy3d.config.sections import ConfigSection

_DEFAULT_PROFILES = {
    "default": ("https://photonforge.simulation.cloud", "wss://ws.photonforge.simulation.cloud"),
    "prod": ("https://photonforge.simulation.cloud", "wss://ws.photonforge.simulation.cloud"),
    "dev": (
        "https://photonforge.dev-simulation.cloud",
        "wss://ws.photonforge.dev-simulation.cloud",
    ),
    "uat": (
        "https://photonforge.uat-simulation.cloud",
        "wss://ws.photonforge.uat-simulation.cloud",
    ),
    "pre": (
        "https://photonforge.preprod-simulation.cloud",
        "wss://ws.photonforge.preprod-simulation.cloud",
    ),
    "nexus": ("http://127.0.0.1:3030", "ws://127.0.0.1:3030"),
    "test": ("http://localhost:3030", "ws://localhost:3030"),
}


@register_plugin("pda")
class PDAConfig(ConfigSection):
    """Profile-scoped PDA endpoint configuration."""

    api_endpoint: str | None = Field(None, json_schema_extra={"persist": True})
    ws_endpoint: str | None = Field(None, json_schema_extra={"persist": True})

    @model_validator(mode="after")
    def check_both_or_neither(self):
        if (self.api_endpoint is None) != (self.ws_endpoint is None):
            raise ValueError(
                "Configuration options 'pda.api_endpoint' and 'pda.ws_endpoint' must be both set "
                "or both left unset."
            )
        return self


def resolve_pda_endpoints(api_endpoint: str | None, ws_endpoint: str | None) -> tuple[str, str]:
    """Resolve PDA endpoints from explicit args, profile plugin, and defaults."""
    manager = get_manager()
    plugin = manager.plugins.pda
    plugin_api_endpoint = plugin.api_endpoint
    plugin_ws_endpoint = plugin.ws_endpoint

    profile_defaults = _DEFAULT_PROFILES.get(manager.profile, _DEFAULT_PROFILES["default"])

    resolved_endpoint = api_endpoint or plugin_api_endpoint or profile_defaults[0]
    resolved_socket_addr = ws_endpoint or plugin_ws_endpoint or profile_defaults[1]
    return resolved_endpoint, resolved_socket_addr
