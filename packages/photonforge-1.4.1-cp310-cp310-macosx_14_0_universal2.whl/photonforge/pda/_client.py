"""Low-level PDA HTTP and CRDT client operations."""

import re
from typing import Literal
from warnings import warn

import httpx
from automerge.transports.websocket import WebSocketClientTransport
from tidy3d.web.core import http_util
from websockets.client import connect as _websockets_connect

from ._config import resolve_pda_endpoints
from ._crdt.document import Document
from ._crdt.repo_manager import RepoManager
from ._sync_runtime import run as _run
from ._sync_runtime import stop as _stop_runtime
from ._types import DocumentId, ReadOnlyURL

_version = re.compile(
    r"""^\s*v?
    (?:
        (?:(?P<epoch>[0-9]+)!)?
        (?P<release>[0-9]+(?:\.[0-9]+)*)
        (?P<pre>
            [-_\.]?
            (?P<pre_l>(a|b|c|rc|alpha|beta|pre|preview))
            [-_\.]?
            (?P<pre_n>[0-9]+)?
        )?
        (?P<post>
            (?:-(?P<post_n1>[0-9]+))|
            (?:
                [-_\.]?
                (?P<post_l>post|rev|r)
                [-_\.]?
                (?P<post_n2>[0-9]+)?
            )
        )?
        (?P<dev>
            [-_\.]?
            (?P<dev_l>dev)
            [-_\.]?
            (?P<dev_n>[0-9]+)?
        )?
    )
    (?:\+(?P<local>[a-z0-9]+(?:[-_\.][a-z0-9]+)*))?
    \s*$""",
    re.VERBOSE | re.IGNORECASE,
)

_rest_client: httpx.AsyncClient | None = None
_repo_mgr: RepoManager | None = None

# document types
_project_type = "photonforge.project"
_application_type = "photonforge.application"
_results_type = "photonforge.application.results"
_technology_type = "photonforge.technology"
_component_type = "photonforge.component"
_ui_component_type = "photonforge.component.ui"
_component_schema_type = "photonforge.component-schema"
_model_schema_type = "photonforge.model-schema"


def init(api_endpoint: str | None = None, ws_endpoint: str | None = None) -> None:
    """Initialize global clients.

    Existing clients are stopped before opening new connections.

    Args:
        api_endpoint: Optional base URL for PDA REST endpoints.
        ws_endpoint: Optional websocket endpoint for CRDT synchronization.
    """
    _run(_init(api_endpoint, ws_endpoint))


_warned = False


async def _init(api_endpoint: str | None = None, ws_endpoint: str | None = None) -> None:
    global _rest_client, _repo_mgr, _warned

    if not _warned:
        warn(
            "The PDA interface is experimental and may suffer breaking changes in the 1.4.* "
            "version family for improved usability. Please check the changelog at "
            "https://docs.flexcompute.com/projects/photonforge/en/latest/changelog.html for more "
            "information after any updates.",
            RuntimeWarning,
            2,
        )
        _warned = True

    await _stop()

    api_endpoint, ws_endpoint = resolve_pda_endpoints(api_endpoint, ws_endpoint)
    _rest_client = httpx.AsyncClient(
        base_url=api_endpoint, headers={"simcloud-api-key": http_util.api_key()}, timeout=30
    )
    # Open the WS with `ping_interval=None` (client-side keepalive disabled) so the connection
    # survives multi-second blocked-loop windows during `project.import_module()` — see
    # `docs/sdj/2026-05-07-pda-worker-sync-reconnect.md` Bug A. Default `ping_interval=20s` +
    # `ping_timeout=20s` causes the server to abnormally close the connection if the client can't
    # pong within ~40s of cumulative loop-blocked time, which trivially happens with SiEPIC +
    # Abstract Components attached. Disabling the client ping is preferable to offloading
    # `import_module` to `asyncio.to_thread`, because the imported library code may call
    # `Component.get_netlist()` which has known license-check issues in background-thread contexts
    # (see `docs/sdj/2026-04-14-sync-runtime-limitations.md`).
    websocket = await _websockets_connect(
        ws_endpoint,
        extra_headers={"simcloud-api-key": http_util.api_key()},
        ping_interval=None,
    )
    transport = WebSocketClientTransport(websocket)
    _repo_mgr = await RepoManager.create(transport)


def stop() -> None:
    """Close and clear global clients.

    Args:
        None.

    Returns:
        ``None``.
    """
    try:
        _run(_stop())
    finally:
        _stop_runtime()


async def _stop() -> None:
    global _rest_client, _repo_mgr
    if _rest_client is not None:
        await _rest_client.aclose()
        _rest_client = None
    if _repo_mgr is not None:
        await _repo_mgr.stop()
        _repo_mgr = None


def user_info() -> tuple[str, str | None]:
    """Return current user ID and organization ID.

    Args:
        None.

    Returns:
        Tuple ``(user_id, organization_id)`` where ``organization_id``
        may be ``None`` for accounts without an organization.
    """
    return _run(_user_info())


async def _user_info() -> tuple[str, str | None]:
    if _rest_client is None:
        await _init()

    resp = await _rest_client.get("/api/sync/me")
    resp.raise_for_status()
    data = resp.json()
    return (data["userId"], data.get("tenantId"))


async def _create_document(
    doc_type: str, parent_id: DocumentId | None, data: dict[str, object] | None = None
) -> dict[str, object]:
    """Create a PDA document.

    Args:
        doc_type: Backend document type string.
        parent_id: Optional parent document ID.
        data: Optional initial document payload.

    Returns:
        Created document metadata from the backend.
    """
    if _rest_client is None:
        await _init()
    body = {"type": doc_type}
    if parent_id:
        body["parentId"] = parent_id
    if data:
        body["data"] = data
    resp = await _rest_client.post("/api/sync/documents", json=body)
    resp.raise_for_status()
    return resp.json()


async def _list_documents(
    types: list[str] | None = None, deleted: bool = False
) -> list[dict[str, object]]:
    """List PDA documents across all pages.

    Args:
        types: Optional list of backend document types to include.
        deleted: Whether to include retired documents.

    Returns:
        Flattened list of document metadata objects.
    """
    if _rest_client is None:
        await _init()
    params = {"page": 0, "deleted": deleted}
    if types:
        params["types"] = types
    result = []
    while True:
        resp = await _rest_client.get("/api/sync/documents", params=params)
        resp.raise_for_status()
        data = resp.json()
        result.extend(data["items"])
        if data["pagination"]["hasMore"]:
            params["page"] += 1
        else:
            break
    return result


async def _get_document(document_id: DocumentId) -> dict[str, object]:
    if _rest_client is None:
        await _init()
    resp = await _rest_client.get(f"/api/sync/documents/{document_id}")
    resp.raise_for_status()
    return resp.json()


async def _delete_document(document_id: DocumentId) -> bool:
    if _rest_client is None:
        await _init()
    resp = await _rest_client.delete(f"/api/sync/documents/{document_id}")
    resp.raise_for_status()
    return True


# async def _restore_document(document_id: DocumentId) -> bool:
#     if _rest_client is None:
#         await _init()
#     resp = await _rest_client.post(f"/api/sync/documents/{document_id}/restore")
#     resp.raise_for_status()
#     return True


async def _add_version(
    document_ref: ReadOnlyURL,
    version: str | None,
    bump_version: Literal["major", "minor", "patch"] | None,
) -> dict[str, object]:
    """Create a version for a document reference.

    Exactly one of ``version`` or ``bump_version`` can be set.

    Args:
        document_id: Target document ID.
        document_ref: Reference URL tied to the snapshot being versioned.
        version: Explicit semantic version string.
        bump_version: Version bump strategy when ``version`` is omitted.

    Returns:
        Created version metadata.
    """
    if _rest_client is None:
        await _init()
    body = {"ref": document_ref}
    if version is not None:
        if bump_version is not None:
            raise RuntimeError("Please specify only one of 'version' or 'bump_version'.")
        if _version.match(version) is None:
            raise ValueError(
                "Version format cannot be parsed. Expected format must match PEP 440 "
                "specification (https://peps.python.org/pep-0440/)."
            )
        body["version"] = version
    elif bump_version is not None:
        if bump_version not in ("major", "minor", "patch"):
            raise ValueError("'bump_version' must be one of 'major', 'minor', or 'patch'.")
        body["bump"] = bump_version
    resp = await _rest_client.post("/api/sync/versions", json=body)
    resp.raise_for_status()
    return resp.json()


async def _list_versions(document_ids: list[DocumentId]) -> list[dict[str, object]]:
    """List all versions for a document across paginated results."""
    if _rest_client is None:
        await _init()
    params = {"documentIds": document_ids, "page": 0}
    result = []
    while True:
        resp = await _rest_client.get("/api/sync/versions", params=params)
        resp.raise_for_status()
        data = resp.json()
        result.extend(data["items"])
        if data["pagination"]["hasMore"]:
            params["page"] += 1
        else:
            break
    return result


async def _list_latest_versions(document_ids: list[DocumentId]) -> list[dict[str, object]]:
    """List latest versions of all requested document IDs."""
    if _rest_client is None:
        await _init()
    params = {"documentIds": document_ids}
    resp = await _rest_client.get("/api/sync/versions/latest", params=params)
    resp.raise_for_status()
    data = resp.json()
    return data["items"]


async def _get_version(version_id: str) -> dict[str, object] | None:
    if _rest_client is None:
        await _init()
    resp = await _rest_client.get(f"/api/sync/versions/{version_id}")
    resp.raise_for_status()
    return resp.json()


async def _list_libraries(latest: bool, deleted: bool) -> list[dict[str, object]]:
    """List library entries joined with their version records."""
    if _rest_client is None:
        await _init()
    projects = {
        d["documentId"]: d for d in await _list_documents(types=[_project_type], deleted=deleted)
    }
    versions = (
        (await _list_latest_versions(list(projects.keys())))
        if latest
        else (await _list_versions(list(projects.keys())))
    )
    return [projects[version_info["documentId"]] | version_info for version_info in versions]


async def _add_tag(document_ref: ReadOnlyURL, tag: str) -> dict[str, object]:
    """Create a tag for a document reference.

    Args:
        document_id: Target document ID.
        document_ref: Reference URL tied to the snapshot being tagged.
        tag: Tag label to create.

    Returns:
        Created tag metadata.
    """
    if _version.match(tag) is not None:
        raise ValueError(
            "Tag matches a version string. Please use versioning instead of tagging in this case."
        )
    if _rest_client is None:
        await _init()
    resp = await _rest_client.post("/api/sync/tags", json={"ref": document_ref, "tag": tag})
    resp.raise_for_status()
    return resp.json()


async def _list_tags(
    document_type: str | None, document_id: DocumentId | None
) -> list[dict[str, object]]:
    """List tags filtered by document type and/or document ID.

    Args:
        document_type: Optional backend document type filter.
        document_id: Optional document ID filter.

    Returns:
        Flattened list of tag metadata objects.
    """
    if _rest_client is None:
        await _init()
    params = {"page": 0}
    if document_id is not None:
        params["documentId"] = document_id
    if document_type is not None:
        params["documentType"] = document_type
    result = []
    while True:
        resp = await _rest_client.get("/api/sync/tags", params=params)
        resp.raise_for_status()
        data = resp.json()
        result.extend(data["items"])
        if data["pagination"]["hasMore"]:
            params["page"] += 1
        else:
            break
    return result


async def _get_tag(tag_id: str) -> dict[str, object] | None:
    if _rest_client is None:
        await _init()
    resp = await _rest_client.get(f"/api/sync/tags/{tag_id}")
    resp.raise_for_status()
    return resp.json()


async def _delete_tag(tag_id: str) -> bool:
    if _rest_client is None:
        await _init()
    resp = await _rest_client.delete(f"/api/sync/tags/{tag_id}")
    resp.raise_for_status()
    return True


_grantee_type = {"private": "user", "organization": "tenant"}
_visibility = {v: k for k, v in _grantee_type.items()}


def _patch_visibility(permission: dict[str, object]):
    """Normalize backend grantee type into API visibility labels."""
    grantee_type = permission.pop("granteeType")
    permission["visibility"] = _visibility.get(grantee_type, grantee_type)
    return permission


async def _list_permissions(document_id: DocumentId) -> list[dict[str, object]]:
    """Return document permissions with normalized visibility labels."""
    if _rest_client is None:
        await _init()
    resp = await _rest_client.get(f"/api/sync/documents/{document_id}/permissions")
    resp.raise_for_status()
    return [_patch_visibility(p) for p in resp.json()]


async def _grant_permission(
    document_id: DocumentId,
    visibility: Literal["private", "organization", "public"],
    grantee_id: str | None,
    role: Literal["owner", "editor", "viewer"],
) -> dict[str, object]:
    """Grant a permission on a document.

    Args:
        document_id: Target document ID.
        visibility: Visibility scope for the grant.
        grantee_id: User or tenant ID when required.
        role: Access role to grant.

    Returns:
        Created permission metadata with normalized visibility.
    """
    if _rest_client is None:
        await _init()
    body = {"granteeType": _grantee_type.get(visibility, visibility), "role": role}
    if grantee_id is not None:
        body["granteeId"] = grantee_id
    resp = await _rest_client.post(f"/api/sync/documents/{document_id}/permissions", json=body)
    resp.raise_for_status()
    return _patch_visibility(resp.json())


async def _update_permission(
    document_id: DocumentId,
    permission_id: str,
    role: Literal["editor", "viewer"],
) -> dict[str, object]:
    """Update an existing permission role.

    Args:
        document_id: Target document ID.
        permission_id: Permission identifier to update.
        role: New role value.

    Returns:
        Updated permission metadata with normalized visibility.
    """
    if _rest_client is None:
        await _init()
    resp = await _rest_client.patch(
        f"/api/sync/documents/{document_id}/permissions/{permission_id}", json={"role": role}
    )
    resp.raise_for_status()
    return _patch_visibility(resp.json())


async def _revoke_permission(document_id: DocumentId, permission_id: str) -> bool:
    """Revoke a permission from a document.

    Args:
        document_id: Target document ID.
        permission_id: Permission identifier to remove.

    Returns:
        ``True`` when the backend accepts the revocation.
    """
    if _rest_client is None:
        await _init()
    resp = await _rest_client.delete(
        f"/api/sync/documents/{document_id}/permissions/{permission_id}"
    )
    resp.raise_for_status()
    return True


async def _transfer_ownership(document_id: DocumentId, new_owner: str) -> dict[str, object]:
    """Transfer document ownership to another user.

    Args:
        document_id: Target document ID.
        new_owner: Identifier of the new owner.

    Returns:
        Updated owner permission payload.
    """
    if _rest_client is None:
        await _init()
    resp = await _rest_client.post(
        f"/api/sync/documents/{document_id}/permissions/transfer-ownership",
        json={"newOwner": new_owner},
    )
    resp.raise_for_status()
    return _patch_visibility(resp.json())


async def _check_access(document_id: DocumentId) -> tuple[bool, dict[str, object]]:
    """Check whether the current user can access a document."""
    if _rest_client is None:
        await _init()
    resp = await _rest_client.get(f"/api/sync/documents/{document_id}/permissions/access")
    if resp.status_code == 401:
        return False, resp.json()
    resp.raise_for_status()
    return True, resp.json()


# NOTE: All documents must be created through _create_document to ensure initial permissions
# async def _create_repo_document(initial_data: dict[str, object] | None = None) -> Document:
#     if _repo_mgr is None:
#         await init()
#     return await _repo_mgr.create_document(initial_data)


async def _find_repo_document(ref: DocumentId | ReadOnlyURL, check: bool = True) -> Document | None:
    """Resolve a CRDT document by PDA ID or reference URL.

    Args:
        ref: Document identifier or reference URL.
        check: Whether to wait briefly for a synced document.

    Returns:
        Document handle wrapper, or ``None`` if not found and ``check``
        is ``False``.
    """
    if _repo_mgr is None:
        await _init()
    return await _repo_mgr.find_document(ref, check)
