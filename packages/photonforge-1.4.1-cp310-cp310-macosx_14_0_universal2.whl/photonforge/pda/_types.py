from datetime import datetime
from typing import Literal, NewType

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    NonNegativeFloat,
    PositiveFloat,
    PositiveInt,
)

from ._common_schema import Matrix3x2AffineJson

DocumentId = NewType("DocumentId", str)  # PDA document ID
ReadOnlyURL = NewType("ReadOnlyURL", str)  # PDA reference URL
ReferenceId = NewType("ReferenceId", str)  # UUID used in UiReference

ParametersSchema = dict[str, object]  # Type for the schema
ParameterValues = dict[str, object]  # Type for the value


class PortCanvasProperties(BaseModel):
    side: Literal["top", "right", "bottom", "left"]
    offset: float = Field(ge=-0.5, le=0.5)


class UiReferencePort(BaseModel):
    kind: Literal["port"] = "port"
    referenceId: ReferenceId
    name: str  # Name of the port in the referenced (parent) component


class UiPort(BaseModel):
    name: str
    classificationType: Literal["optical", "electrical"]
    baseType: Literal["Port", "FiberPort", "GaussianPort"]
    numModes: PositiveInt
    origin: UiReferencePort | None = None
    canvasProperties: PortCanvasProperties


class UiReferenceTerminal(BaseModel):
    kind: Literal["terminal"] = "terminal"
    name: str
    portName: str | None
    referenceId: ReferenceId | None


class UiTerminal(BaseModel):
    # name == None means this terminal is only available as a port-derived terminal, so it's origin
    # will have name and portName information
    name: str | None
    origin: UiReferenceTerminal | None = None
    canvasProperties: PortCanvasProperties


class UiConnection(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True, serialize_by_alias=True)

    frm: UiReferencePort = Field(..., alias="from")
    to: UiReferencePort
    properties: ParameterValues = {}


class UiModel(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    className: str  # Class name
    parameters: ParameterValues
    parametersSchema: ReadOnlyURL


class ReferenceCanvasProperties(BaseModel):
    width: float | None = None
    height: float | None = None
    transform: Matrix3x2AffineJson | None = None
    annotation: str | None = Field(default=None, max_length=50)


class UiReference(BaseModel):
    id: ReferenceId  # this instance's ID
    component: DocumentId | ReadOnlyURL
    transform: Matrix3x2AffineJson | None = None
    canvasProperties: ReferenceCanvasProperties | None = None


# Equivalent to a netlist: A netlist is a component where len(references) > 0, such that its
# references can be viewed in the schematic canvas with all their connections.
class UiComponent(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    # Document containing the full component data as exported from PF or the parametric
    # function used to generate the component if it is not yet persisted as a full document.
    pfRef: ReadOnlyURL | str | None = None

    name: str = ""  # instance's name (usually includes a hash, which is not nice to see in GUI)

    # Properties not defined in the current component can be looked up in this reference.
    referencedComponent: DocumentId | ReadOnlyURL | None = None

    # This defines 2 types of components:
    # 1. Parametric components (PCell): have a schema and can be updated with new parameters
    # 2. Static components: they are created declaratively and have parametersSchema == None
    parameters: ParameterValues | None = None
    parametersSchema: ReadOnlyURL | None = None

    models: dict[str, UiModel] | None = None
    activeModel: dict[Literal["optical", "electrical"], str | None] | None = None

    references: dict[ReferenceId, UiReference] | None = None
    referenceOrder: list[ReferenceId] | None = None

    ports: list[UiPort] | None = None
    terminals: list[UiTerminal] | None = None

    virtualConnections: dict[str, UiConnection] | None = None

    thumbnail: str | None = None
    preview: str | None = None


class UiReferenceMonitor(BaseModel):
    referenceId: ReferenceId
    name: str
    externalName: str | None = None


class TimeDomainSettings(BaseModel):
    timeStep: PositiveFloat
    duration: PositiveFloat
    carrierFrequency: NonNegativeFloat
    frequencyBandwidth: PositiveFloat
    frequencyPoints: PositiveInt
    monitors: list[UiReferenceMonitor]


class FrequencyDomainSettings(BaseModel):
    startWavelength: PositiveFloat
    stopWavelength: PositiveFloat
    points: PositiveInt


class SimulationSettings(BaseModel):
    simulationMode: Literal["frequency"] | Literal["time"]
    frequencyDomain: FrequencyDomainSettings | None = None
    timeDomain: TimeDomainSettings | None = None


class UserCanvasProperties(BaseModel):
    zoom: float
    panX: float
    panY: float


class UserConfig(BaseModel):
    canvasProperties: UserCanvasProperties | None = None


class SMatrixElement(BaseModel):
    input: str
    output: str
    values: list[tuple[float, float]]


class SMatrix(BaseModel):
    frequencies: list[float]
    wavelengths: list[float]
    elements: list[SMatrixElement]


class TimeSeriesElement(BaseModel):
    name: str
    values: list[tuple[float, float]]


class TimeSeries(BaseModel):
    timeStep: float
    timeIndex: int
    numSteps: int
    elements: list[TimeSeriesElement]


class Error(BaseModel):
    id: str | None
    level: Literal["error", "warning", "info", "debug"]
    message: str


class SimulationJob(BaseModel):
    projectRef: ReadOnlyURL
    applicationRef: ReadOnlyURL
    createdAt: datetime
    startedAt: datetime | None = None
    completedAt: datetime | None = None
    state: Literal["queued", "running", "succeeded", "failed", "aborted"]
    progress: int = Field(0, ge=0, le=100)
    result: SMatrix | TimeSeries | Error | None = None


class SimulationResults(BaseModel):
    simulations: dict[str, SimulationJob] = {}  # indexed by simulationId
    customNames: dict[str, str] = {}
    # plots: dict[str, PlotConfig] = {}


class SchematicApplication(BaseModel):
    type: Literal["schematic"]
    name: str
    description: str | None = None
    component: DocumentId
    simulationSettings: SimulationSettings | None = None
    userConfigs: dict[str, UserConfig] | None = None
    results: DocumentId  # SimulationResults


class ComponentInfo(BaseModel):
    ref: ReadOnlyURL  # UiComponent
    external: bool = False


class ProjectModel(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    name: str
    description: str | None = None
    labels: list[str] = []
    config: dict[str, object] = {}
    applications: list[DocumentId] = []  # SchematicApplication
    components: list[ComponentInfo] = []
    technologies: list[ReadOnlyURL] = []  # Technology
    libraries: list[ReadOnlyURL] = []  # ProjectModel
    componentSchemas: dict[str, DocumentId] = {}
    modelSchemas: dict[str, DocumentId] = {}
    pythonModule: bytes | None = None
