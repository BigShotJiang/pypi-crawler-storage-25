"""High-level project and library management for PhotonForge PDA.

This module provides the ``Project`` runtime object and async helpers to
create, list, load, retire, and restore PDA-backed projects.
"""

from __future__ import annotations

import importlib
import io
import keyword
import re
import string
import sys
import zipfile
from collections import defaultdict, namedtuple
from collections.abc import Iterable, Iterator, Mapping, Sequence
from filecmp import dircmp
from json import dumps as json_dumps
from json import loads as json_loads
from pathlib import Path
from types import ModuleType
from typing import Literal
from warnings import warn

from pydantic import ValidationError

from ..extension import Component, Technology, _export, _import
from ._client import (
    _add_tag,
    _add_version,
    _check_access,
    _component_type,
    _create_document,
    _delete_document,
    _delete_tag,
    _find_repo_document,
    _get_document,
    _get_version,
    _grant_permission,
    _list_documents,
    _list_libraries,
    _list_permissions,
    _list_tags,
    _list_versions,
    _project_type,
    # _restore_document,
    _revoke_permission,
    _technology_type,
    _transfer_ownership,
    _ui_component_type,
    _update_permission,
    _user_info,
    user_info,
)
from ._component import component_from_pf
from ._crdt.document import Document
from ._crdt.refs import AutomergeRef
from ._sync_runtime import run as _run
from ._types import DocumentId, ReadOnlyURL, UiComponent
from ._types import ProjectModel as _ProjectModel

_DEFAULT_MODULE_PATH = "./pflibs"

_table: defaultdict[int, int | None] = defaultdict(lambda: None)
for c in string.ascii_lowercase + string.digits:
    n = ord(c)
    _table[n] = n
for up, lo in zip(string.ascii_uppercase, string.ascii_lowercase, strict=True):
    _table[ord(up)] = ord(lo)
_o = ord("_")
_table[_o] = _o
_table[ord(" ")] = _o


def _purge_module(module_name: str) -> None:
    loaded = tuple(sys.modules)
    for key in loaded:
        if key == module_name or key.startswith(f"{module_name}."):
            del sys.modules[key]


def _check_unique_names(data: dict[DocumentId, Technology | Component], check_for: str) -> None:
    """Validate that object names are unique within one collection.

    Args:
        data: Objects keyed by document ID.
        check_for: Collection label used in error messages.

    Raises:
        RuntimeError: If duplicate names are detected.
    """
    if len({obj.name for obj in data.values()}) == len(data):
        return
    existing = set()
    for obj in data.values():
        if obj.name in existing:
            raise RuntimeError(
                f"{obj.name!r} will not be unique within project {check_for} after update."
            )
        existing.add(obj.name)
    raise RuntimeError(f"Update would result in duplicate name within project {check_for}.")


async def _add_version_and_tag_info(info: dict[str, object], doc: Document) -> dict[str, object]:
    """Add version and tag metadata for one document reference.

    Args:
        info: Base metadata payload to enrich.
        doc: Document whose current reference is used for filtering.

    Returns:
        Enriched metadata payload including matching tags and versions.

    The returned payload includes tags from matching references and either
    ``version`` (single match) or ``versions`` (multiple matches).
    """
    # TODO: endpoint to get version/tags by document reference
    versions = [
        version_info["version"]
        for version_info in await _list_versions(doc.id)
        if version_info["ref"] == doc.ref
    ]
    if len(versions) == 1:
        info["version"] = versions[0]
    elif len(versions) > 1:
        info["versions"] = versions
    info["tags"] = [
        tag_info["tag"] for tag_info in await _list_tags(None, doc.id) if tag_info["ref"] == doc.ref
    ]
    return info


_TechnologyData = namedtuple("_TechnologyData", ["doc", "obj", "parent_id"])
_ComponentData = namedtuple("_ComponentData", ["doc", "ui_doc", "obj", "parent_id", "external"])


class _ProjectObjectMap(Mapping[str, Component | Technology]):
    """Read-only live view of one project's named objects."""

    def __init__(
        self, project: Project, kind: Literal["components", "technologies"], parent_id: DocumentId
    ) -> None:
        self._project = project
        self._kind = kind
        self._parent_id = parent_id

    def _items(self) -> dict[str, Component | Technology]:
        if self._kind == "technologies":
            return {
                data.obj.name: data.obj
                for data in self._project._technologies.values()
                if data.parent_id == self._parent_id
            }
        return {
            data.obj.name: data.obj
            for data in self._project._components.values()
            if data.parent_id == self._parent_id and data.external
        }

    def __getitem__(self, key: str) -> Component | Technology:
        return self._items()[key]

    def __iter__(self) -> Iterator[str]:
        return iter(self._items())

    def __len__(self) -> int:
        return len(self._items())


class Project:
    """Live view of a PDA project or library document."""

    def __init__(self, document: Document) -> None:
        self._doc: Document = document
        self._technologies: dict[DocumentId, _TechnologyData] = {}
        self._components: dict[DocumentId, _ComponentData] = {}
        self._libraries: dict[DocumentId, Project] = {}

        self._module_path: Path | None = None

        self._refresh_state()

    def _refresh_state(self) -> None:
        self._data = self._doc.read()
        self._doc_ref = self._doc.ref

        _ProjectModel.model_validate(self._data)

        self._data.setdefault("description", None)
        self._data.setdefault("labels", [])
        self._data.setdefault("config", {})
        self._data.setdefault("applications", [])
        self._data.setdefault("components", [])
        self._data.setdefault("technologies", [])
        self._data.setdefault("libraries", [])
        self._data.setdefault("componentSchemas", {})
        self._data.setdefault("modelSchemas", {})
        self._data.setdefault("pythonModule", None)

        self._module_name: str = self._data["name"].translate(_table)
        if len(self._module_name) == 0:
            self._module_name = f"m_{self._doc.id}"
        else:
            if self._module_name[0].isdigit():
                self._module_name = "m_" + self._module_name
            while keyword.iskeyword(self._module_name) or keyword.issoftkeyword(self._module_name):
                self._module_name = self._module_name + "_"

    def __str__(self) -> str:
        return f"Project {self._data['name']!r}"

    def __repr__(self) -> str:
        return f"Project(name={self._data['name']!r}, project_id={self._doc.id!r})"

    def reload(
        self,
        *,
        module_path: str | Path | None = None,
        set_config: bool = True,
        reload_module: bool = True,
    ) -> Project:
        """Reload latest project data from PDA in place."""
        return _run(
            self._reload(
                module_path=module_path,
                set_config=set_config,
                reload_module=reload_module,
            )
        )

    async def _reload(
        self,
        *,
        module_path: str | Path | None = None,
        set_config: bool = True,
        reload_module: bool = True,
    ) -> Project:
        """Reload latest project data from PDA in place."""
        self._doc = self._doc.latest()
        self._refresh_state()
        await self._load_data(set_config)
        if reload_module:
            if module_path is None:
                module_path = self._module_path or _DEFAULT_MODULE_PATH
            self._load_module(module_path, True, False)
        return self

    @property
    def id(self) -> DocumentId:
        """Project ID."""
        return self._doc.id

    @property
    def name(self) -> str:
        """Project name."""
        return self._data["name"]

    @property
    def description(self) -> str | None:
        """Project description."""
        return self._data["description"]

    @property
    def labels(self) -> tuple[str]:
        """Project labels."""
        return tuple(self._data["labels"])

    @property
    def module_name(self) -> str:
        """Sanitized Python module name for this project."""
        return self._module_name

    @property
    def module_path(self) -> Path:
        """Filesystem path where the project Python module is loaded."""
        if self._module_path is None:
            raise RuntimeError(
                "Project module not loaded. Make sure the project was created using the functions "
                "'create_project' or 'load_project'."
            )
        return self._module_path

    def _find_target(
        self, target: Component | Technology | str | None
    ) -> tuple[Component | Technology | Project, Document]:
        self_id = self._doc.id
        if target is None:
            obj = self
            doc = self._doc
        elif isinstance(target, Technology):
            data = self._technologies.get(target._pda_id)
            if data is None:
                # Fallback to str case below
                target = target.name
            else:
                if data.parent_id != self_id:
                    raise RuntimeError(
                        "Only technologies from this project can be targeted, not from libraries."
                    )
                obj = data.obj
                doc = data.doc
        elif isinstance(target, Component):
            data = self._components.get(target._pda_id)
            if data is None:
                # Fallback to str case below
                target = target.name
            else:
                if data.parent_id != self_id:
                    raise RuntimeError(
                        "Only components from this project can be targeted, not from libraries."
                    )
                obj = data.obj
                doc = data.ui_doc

        if isinstance(target, str):
            for data in (*self._components.values(), *self._technologies.values()):
                if data.obj.name == target and data.parent_id == self_id:
                    obj = data.obj
                    doc = data.doc if isinstance(obj, Technology) else data.ui_doc
                    break
            else:
                raise RuntimeError(
                    f"{target!r} not found among project components or technologies."
                )
        return obj, doc

    def get_info(self, target: Component | Technology | str | None = None) -> dict[str, object]:
        """Return metadata for the project or one contained object.

        Args:
            target: Optional object or name to query instead of the
              project document.

        Returns:
            Metadata payload with document details, tags, and versions.

        The returned payload includes matching tags and versions for the
        current document reference.
        """
        return _run(self._get_info(target))

    async def _get_info(
        self, target: Component | Technology | str | None = None
    ) -> dict[str, object]:
        target, doc = self._find_target(target)
        info = await _get_document(doc.id)
        if target is self:
            info.update({"name": self.name, "labels": self._data["labels"]})
        else:
            info["name"] = target.name
            if isinstance(target, Component):
                info["external"] = self._components[doc.id].external
        return await _add_version_and_tag_info(info, doc)

    def get_library_info(
        self, name: str | None = None
    ) -> dict[str, object] | list[dict[str, object]]:
        """Return metadata for one library or all imported libraries.

        Args:
            name: Optional library name. If omitted, returns all libraries.

        Returns:
            Metadata payload for one library, or a list of payloads for all
            imported libraries.

        Raises:
            RuntimeError: If ``name`` is provided and no matching library is
                found.
        """
        return _run(self._get_library_info(name))

    async def _get_library_info(
        self, name: str | None = None
    ) -> dict[str, object] | list[dict[str, object]]:
        if name is None:
            return [await library._get_info() for library in self._libraries.values()]
        for library in self._libraries.values():
            if library.name == name:
                return await library._get_info()
        raise RuntimeError(f"Library {name!r} not found in project.")

    def set(
        self,
        *,
        name: str | None = None,
        description: str | None = None,
        labels: Sequence[str] | None = None,
    ) -> None:
        """Update editable project fields in-place.

        Args:
            name: Optional replacement project name.
            description: Optional replacement project description.
            labels: Optional replacement label collection.

        Raises:
            RuntimeError: If the project is read-only.
        """
        _run(self._set(name=name, description=description, labels=labels))

    async def _set(
        self,
        *,
        name: str | None = None,
        description: str | None = None,
        labels: Sequence[str] | None = None,
    ) -> None:
        if self._doc.is_read_only:
            raise RuntimeError(f"Read only project/library {self.name!r} cannot be modified.")
        changes = {}
        if isinstance(name, str):
            changes["name"] = name
        if isinstance(description, str):
            changes["description"] = description
        if labels is not None and all(isinstance(lbl, str) for lbl in labels):
            changes["labels"] = list(set(labels))
        if len(changes) > 0:
            self._doc.change(changes)

    async def _load_data(self, set_config: bool) -> object:
        """Load the project from PDA."""
        data = {}
        top_content = []
        self._technologies = {}
        self._components = {}
        for doc_ref in self._data["technologies"]:
            doc = await _find_repo_document(doc_ref)
            doc_id = AutomergeRef.parse(doc_ref).document_id
            data[doc_id] = doc.read()
            top_content.append((doc_id, 11))
            info = await _get_document(doc_id)
            self._technologies[doc_id] = _TechnologyData(doc, None, info["parentId"])
        for flagged_component in self._data["components"]:
            ui_ref = flagged_component["ref"]
            ui_doc = await _find_repo_document(ui_ref)
            doc_ref = ui_doc.read()["pfRef"]
            doc = await _find_repo_document(doc_ref)
            ui_id = AutomergeRef.parse(ui_ref).document_id
            data[ui_id] = doc.read()
            top_content.append((ui_id, 26))
            info = await _get_document(ui_id)
            self._components[ui_id] = _ComponentData(
                doc,
                ui_doc,
                None,
                info["parentId"],
                flagged_component.get("external", False),
            )

        json_data = {
            "type": 1,
            "type_version": "0.0",
            "config": self._data["config"],
            "top_content": top_content,
            "data": data,
            "properties": None,
        }
        byte_repr = json_dumps(json_data).encode("utf-8")
        objects, _ = _import(byte_repr=byte_repr, set_config=set_config, use_json=True)

        for (obj_id, _), obj in zip(top_content, objects, strict=True):
            obj._pda_id = obj_id
            if isinstance(obj, Technology):
                technology_data = self._technologies[obj_id]
                self._technologies[obj_id] = _TechnologyData(
                    technology_data.doc, obj, technology_data.parent_id
                )
            else:
                component_data = self._components[obj_id]
                self._components[obj_id] = _ComponentData(
                    component_data.doc,
                    component_data.ui_doc,
                    obj,
                    component_data.parent_id,
                    component_data.external,
                )

        self._libraries = {}
        for lib_ref in self._data["libraries"]:
            document = await _find_repo_document(lib_ref)
            try:
                lib = Project(document)
            except ValidationError:
                continue
            self._libraries[lib._doc.id] = lib

    def _load_module(self, module_path: str | Path, recursive: bool, create_template: bool) -> None:
        """Materialize and load the project Python module on disk.

        Args:
            module_path: Root directory where modules are unpacked.
            recursive: Whether dependency library modules are also loaded.
            create_template: Whether to create a starter module when no
              module archive exists.
        """
        self._module_path = Path(module_path).resolve()
        if str(self._module_path) not in sys.path:
            sys.path.insert(0, str(self._module_path))

        if recursive:
            for lib in self._libraries.values():
                lib._load_module(self._module_path, False, False)

        path = self._module_path / self._module_name

        previous = None
        if path.exists():
            i = 0
            while previous is None or previous.exists():
                i += 1
                previous = self._module_path / f"{self._module_name}.old{i}"
            path.replace(previous)

        path.mkdir(parents=True)

        python_module = self._data.get("pythonModule")
        if isinstance(python_module, (bytes, bytearray)):
            with zipfile.ZipFile(io.BytesIO(bytes(python_module)), "r") as zf:
                zf.extractall(self._module_path)
            if not path.is_dir():
                raise RuntimeError(f"Invalid python module data for project {self.name!r}.")
        elif create_template:
            (path / "README.md").write_text(f"""# {self.name} module

Files in this directory make up the project/library module. Add custom parametric technologies and
components here to make them available when the project is loaded.

See existing files as examples.""")

            (path / "__init__.py").write_text("from .component import example_component")

            (path / "component.py").write_text(
                '''import photonforge as pf
import photonforge.typing as pft


@pf.parametric_component(name_prefix="EXAMPLE")
def example_component(
    *,
    length: pft.PositiveDimension = 100,
) -> pf.Component:
    """Create an example parametric component.

    Args:
        length: Size of the square geometry.

    Returns:
        Component.
    """
    c = pf.Component()
    c.add(pf.Rectangle(size=(length, length)))
    return c'''
            )

        # If current sources match previous, delete previous.
        if previous is not None and previous.is_dir() and path.is_dir():
            cmp = dircmp(path, previous, ignore=["__pycache__"])
            if all(
                len(getattr(cmp, attr)) == 0
                for attr in ("left_only", "right_only", "common_funny", "diff_files", "funny_files")
            ):
                for root, dirs, files in previous.walk(top_down=False):
                    for name in files:
                        (root / name).unlink()
                    for name in dirs:
                        (root / name).rmdir()
                previous.rmdir()

    def save_module(self) -> None:
        """Pack the loaded module directory and store it in PDA.

        The module includes all files in the directory
        ``project.module_path / project.module_name``.
        """
        _run(self._save_module())

    async def _save_module(self) -> None:
        if self._doc.is_read_only:
            raise RuntimeError(f"Read only project/library {self.name!r} cannot be modified.")
        if self._module_path is None:
            raise RuntimeError(
                "Project module not loaded. Make sure the project was created using the functions "
                "'create_project' or 'load_project'."
            )
        module_dir = self._module_path / self._module_name
        if not module_dir.is_dir():
            raise RuntimeError(f"Module directory {module_dir!s} does not exist.")

        archive = io.BytesIO()
        with zipfile.ZipFile(archive, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
            for root, dirs, files in module_dir.walk(top_down=True):
                dirs[:] = sorted(d for d in dirs if d != "__pycache__")
                for filename in sorted(files):
                    if filename.endswith(".pyc"):
                        continue
                    file_path = root / filename
                    arcname = file_path.relative_to(self._module_path)
                    zf.write(file_path, arcname.as_posix())
        self._data["pythonModule"] = archive.getvalue()
        self._doc.change(self._data)

    def _bind_module_objects(self, module: ModuleType, parent_id: DocumentId) -> None:
        module.pda_components = _ProjectObjectMap(self, "components", parent_id)
        module.pda_technologies = _ProjectObjectMap(self, "technologies", parent_id)

    def import_module(self, namespace: dict | None, *, reload: bool = True) -> dict[str, object]:
        """Import the project and library Python modules.

        Args:
            namespace: Optional mapping to populate with imported modules.
            reload: Whether to hard-reload project/library modules from disk.

        Returns:
            Mapping from module name to imported module object.

        Each imported module gets two read-only live mappings:
        ``pda_components`` and ``pda_technologies``.

        Example:
            Import parametric components from the project and its libraries
            in the current namespace (equivalent to using
            ``import project_module`` for each dependency of the project):

            >>> project.import_module(globals())  # doctest: +SKIP
        """
        if reload:
            importlib.invalidate_caches()
            for lib in self._libraries.values():
                _purge_module(lib._module_name)
            _purge_module(self._module_name)

        modules = {}
        for lib in self._libraries.values():
            module = importlib.import_module(lib._module_name)
            self._bind_module_objects(module, lib._doc.id)
            modules[lib._module_name] = module

        module = importlib.import_module(self._module_name)
        self._bind_module_objects(module, self._doc.id)
        modules[self._module_name] = module

        if namespace is not None:
            namespace.update(modules)
        return modules

    def _resolve_origin(self, origin: str | DocumentId) -> Iterable[DocumentId]:
        if origin in ("self", self.name, self._module_name):
            return [self._doc.id]
        elif origin == "libraries":
            return self._libraries.keys()
        elif origin in self._libraries:
            return [origin]
        else:
            for lib_id, lib in self._libraries.items():
                if lib.name == origin or lib._module_name == origin:
                    return [lib_id]
        raise RuntimeError(f"Origin {origin!r} does not map to any library in the project.")

    def _filter_contents(
        self,
        values: Iterable[object],
        name: str | None,
        search: str | re.Pattern | None,
        origin: str | DocumentId | None,
    ) -> (
        dict[str, dict[str, Technology | Component]]
        | dict[str, Technology | Component]
        | Technology
        | Component
    ):
        """Apply name/search/origin filters to component or technology sets.

        Args:
            values: Iterable of internal object metadata records.
            name: Exact object name filter.
            search: Regex filter for object names.
            origin: Source scope selector.

        Returns:
            Filtered objects, grouped by origin when appropriate.
        """
        data = {}
        for item_data in values:
            d = data.get(item_data.parent_id, {})
            d[item_data.obj.name] = item_data.obj
            data[item_data.parent_id] = d

        single_origin = origin not in (None, "libraries")

        if origin is not None:
            data = {k: data[k] for k in self._resolve_origin(origin) if k in data}

        if name is not None:
            filtered = {}
            for origin, origin_results in data.items():
                if name in origin_results:
                    filtered[origin] = origin_results[name]
            data = filtered
        elif search is not None:
            if not isinstance(search, re.Pattern):
                search = re.compile(search)
            filtered = {}
            for origin, origin_results in data.items():
                matches = {k: v for k, v in origin_results.items() if search.search(k) is not None}
                if len(matches) > 0:
                    filtered[origin] = matches
            data = filtered

        if single_origin:
            if len(data) == 1:
                data = next(iter(data.values()))
        else:
            data = {
                self._libraries[k].name if k in self._libraries else self.name: v
                for k, v in data.items()
            }
        return data

    def technologies(
        self,
        *,
        name: str | None = None,
        search: str | re.Pattern | None = None,
        origin: str | DocumentId | None = None,
    ) -> dict[str, dict[str, Technology]] | dict[str, Technology] | Technology:
        """Query technologies by exact name, regex, and origin scope.

        Args:
            name: Exact technology name filter.
            search: Regex or pattern string filter for names.
            origin: Source scope ("self", "libraries", or library name).

        Returns:
            Filtered technology objects grouped by origin when needed.
        """
        return self._filter_contents(self._technologies.values(), name, search, origin)

    def components(
        self,
        *,
        name: str | None = None,
        search: str | re.Pattern | None = None,
        origin: str | DocumentId | None = None,
    ) -> dict[str, dict[str, Component]] | dict[str, Component] | Component:
        """Query components by exact name, regex, and origin scope.

        Args:
            name: Exact component name filter.
            search: Regex or pattern string filter for names.
            origin: Source scope ("self", "libraries", or library name).

        Returns:
            Filtered component objects grouped by origin when needed.
        """
        return self._filter_contents(self._components.values(), name, search, origin)

    def set_external(self, component: Component | str, external: bool = True) -> None:
        """Set/unset a component as external in the module mapping.

        Args:
            component: Component object or component name to set.
            external: Set/unset flag.
        """
        return _run(self._set_external(component, external))

    async def _set_external(self, component: Component | str, external: bool = True):
        """Set/unset a component as external in the module mapping.

        Args:
            component: Component object or component name to set.
            external: Set/unset flag.
        """
        component, ui_doc = self._find_target(component)
        if not isinstance(component, Component):
            raise TypeError("Only components can be set/unset external.")
        for flagged_component in self._data["components"]:
            if AutomergeRef.parse(flagged_component["ref"]).document_id == ui_doc.id:
                value = flagged_component.get("external", False)
                if external and not value:
                    self._components[ui_doc.id] = _ComponentData(
                        *self._components[ui_doc.id][:-1], True
                    )
                    flagged_component["external"] = True
                    self._doc.change(self._data)
                elif not external and value:
                    self._components[ui_doc.id] = _ComponentData(
                        *self._components[ui_doc.id][:-1], False
                    )
                    del flagged_component["external"]
                    self._doc.change(self._data)
                break

    def add(
        self,
        new_obj: Component | Technology,
        *,
        tag: str | None = None,
        bump_version: Literal["major", "minor", "patch"] | None = None,
        update_existing_dependencies: bool = True,
        update_config: bool = True,
        set_external: bool = True,
    ) -> dict[Literal["added", "updated"], list[Technology | Component]]:
        """Add an object and any missing dependencies to the project.

        Args:
            new_obj: Component or technology to add.
            tag: Optional tag applied to changed objects.
            bump_version: Optional semantic bump for changed objects.
            update_existing_dependencies: Whether existing dependencies may be
              updated.
            update_config: Whether to update project config from current
              settings.
            set_external: Whether to mark this component to be external in the
              module ``pda_components`` mapping. Dependencies are never marked.

        Returns:
            Mapping with ``added`` and ``updated`` object lists.
        """
        return _run(
            self._add_or_update(
                True,
                new_obj,
                tag,
                bump_version,
                update_existing_dependencies,
                update_config,
                set_external,
                False,
            )
        )

    def update(
        self,
        upd_obj: Component | Technology,
        *,
        tag: str | None = None,
        bump_version: Literal["major", "minor", "patch"] | None = None,
        update_existing_dependencies: bool = True,
        update_config: bool = True,
    ) -> dict[Literal["added", "updated"], list[Technology | Component]]:
        """Update an existing project object and optional dependencies.

        Args:
            upd_obj: Component or technology to update.
            tag: Optional tag applied to changed objects.
            bump_version: Optional semantic bump for changed objects.
            update_existing_dependencies: Whether existing dependencies may
              be updated.
            update_config: Whether to update project config from current
              setting.

        Returns:
            Mapping with ``added`` and ``updated`` object lists.
        """
        return _run(
            self._add_or_update(
                False,
                upd_obj,
                tag,
                bump_version,
                update_existing_dependencies,
                update_config,
                False,
                False,
            )
        )

    async def _add_or_update(
        self,
        add: bool,
        new_obj: Component | Technology,
        tag: str | None,
        bump_version: Literal["major", "minor", "patch"] | None,
        update_existing_dependencies: bool,
        update_config: bool,
        set_external: bool,
        keep_existing_ids: bool,
    ) -> dict[Literal["added", "updated"], list[Technology | Component]]:
        """Internal implementation for add/update synchronization.

        Args:
            add: ``True`` to add, ``False`` to update.
            new_obj: Primary component or technology to synchronize.
            tag: Optional tag applied to changed objects.
            bump_version: Optional semantic bump for changed objects.
            update_existing_dependencies: Whether existing dependencies may be
              updated.
            update_config: Whether to replace project config from export.
            set_external: Whether to mark this component to be external in the
              module ``pda_components`` mapping. Dependencies are never marked.
            keep_existing_ids: Used by the backend only.

        Returns:
            Mapping with ``added`` and ``updated`` object lists.
        """
        if self._doc.is_read_only:
            raise RuntimeError(f"Read only project/library {self.name!r} cannot be modified.")

        self_id = self._doc.id
        tech_by_name = {
            t.obj.name: t.obj for t in self._technologies.values() if t.parent_id == self_id
        }
        comp_by_name = {
            c.obj.name: c.obj for c in self._components.values() if c.parent_id == self_id
        }
        current_tech = {k: v for k, v in self._technologies.items() if v.parent_id == self_id}
        current_comp = {k: v for k, v in self._components.items() if v.parent_id == self_id}

        if isinstance(new_obj, Technology):
            if add:
                if not keep_existing_ids:
                    new_obj._pda_id = ""
            elif new_obj._pda_id not in current_tech:
                if new_obj.name in tech_by_name and not keep_existing_ids:
                    new_obj._pda_id = tech_by_name[new_obj.name]._pda_id
                else:
                    raise RuntimeError(f"{new_obj.name!r} not found in project. Use 'Project.add'.")
        elif isinstance(new_obj, Component):
            if add:
                if not keep_existing_ids:
                    new_obj._pda_id = ""
            elif new_obj._pda_id not in current_comp:
                if new_obj.name in comp_by_name and not keep_existing_ids:
                    new_obj._pda_id = comp_by_name[new_obj.name]._pda_id
                else:
                    raise RuntimeError(f"{new_obj.name!r} not found in project. Use 'Project.add'.")
        else:
            raise TypeError("Only Component and Technology can be added or updated.")

        primary_update_id = new_obj._pda_id

        future_technologies = {k: v.obj for k, v in current_tech.items()}
        future_components = {k: v.obj for k, v in current_comp.items()}

        module_names = {lib._module_name for lib in self._libraries.values()}
        module_names.update([self._module_name, "photonforge"])

        # Export to gather all required dependencies and create missing IDs
        objects, _ = _export(new_obj)
        for obj_id, obj in objects.items():
            if (
                obj.parametric_function is not None
                and obj.parametric_function.partition(".")[0] not in module_names
            ):
                warn(
                    f"The parametric function for {obj.name!r} ({obj.parametric_function}) does "
                    f"not come from a library within this project. Updating this component or "
                    f" technology will not be possible without the original source.",
                    RuntimeWarning,
                    2,
                )

            if isinstance(obj, Technology):
                if obj is new_obj:
                    # obj will be added or updated
                    future_technologies[obj_id] = obj
                    continue
                id_match = current_tech.get(obj._pda_id, None)
                name_match = tech_by_name.get(obj.name, None)
                if id_match is not None:
                    if update_existing_dependencies:
                        # obj will be updated
                        future_technologies[obj_id] = obj
                elif name_match is not None:
                    obj._pda_id = name_match._pda_id
                    if update_existing_dependencies:
                        # obj will be updated
                        future_technologies[obj._pda_id] = obj
                else:
                    # obj will be added
                    future_technologies[obj_id] = obj
            elif isinstance(obj, Component):
                if obj is new_obj:
                    # obj will be added
                    future_components[obj_id] = obj
                    continue
                id_match = current_comp.get(obj._pda_id, None)
                name_match = comp_by_name.get(obj.name, None)
                if id_match is not None:
                    if update_existing_dependencies:
                        # obj will be updated
                        future_components[obj_id] = obj
                elif name_match is not None and not keep_existing_ids:
                    obj._pda_id = name_match._pda_id
                    if update_existing_dependencies:
                        # obj will be updated
                        future_components[obj._pda_id] = obj
                else:
                    # obj will be added
                    future_components[obj_id] = obj
            else:
                raise TypeError(f"Unsupported object in exported data: {obj!r}.")

        _check_unique_names(future_technologies, "technologies")
        _check_unique_names(future_components, "components")

        # Create new documents for all new objects
        new_ids = set()
        for obj in objects.values():
            if isinstance(obj, Technology):
                if obj._pda_id not in current_tech:
                    if keep_existing_ids and len(obj._pda_id) > 0:
                        doc_id = obj._pda_id
                    else:
                        doc_info = await _create_document(_technology_type, self_id)
                        doc_id = doc_info["documentId"]
                        obj._pda_id = doc_id
                    doc = await _find_repo_document(doc_id)
                    self._technologies[doc_id] = _TechnologyData(doc, obj, self_id)
                    new_ids.add(doc_id)
            else:
                if obj._pda_id not in current_comp:
                    doc_info = await _create_document(_component_type, self_id)
                    doc_id = doc_info["documentId"]
                    if keep_existing_ids and len(obj._pda_id) > 0:
                        ui_doc_id = obj._pda_id
                    else:
                        ui_doc_info = await _create_document(_ui_component_type, self_id)
                        ui_doc_id = ui_doc_info["documentId"]
                        obj._pda_id = ui_doc_id
                    doc = await _find_repo_document(doc_id)
                    ui_doc = await _find_repo_document(ui_doc_id)
                    self._components[ui_doc_id] = _ComponentData(doc, ui_doc, obj, self_id, False)
                    new_ids.add(ui_doc_id)

        # Now re-export using existing doc ids for cross-referencing
        objects, data = _export(new_obj, use_json=True)
        data = json_loads(data)
        sorted_data = sort_exported_data(objects, data)

        component_refs = {
            AutomergeRef.parse_id(r): r
            for r in (*self._data["technologies"], *(x["ref"] for x in self._data["components"]))
        }

        # Add contents to new and updated docs
        added = []
        updated = []
        updated_component_ids = set()
        for obj_id, obj_data, obj in sorted_data:
            is_new = obj_id in new_ids
            is_primary_update = obj_id == primary_update_id
            if not is_new and not update_existing_dependencies and not is_primary_update:
                continue
            if isinstance(obj, Technology):
                doc, _, parent_id = self._technologies[obj_id]
                is_update = not is_new and not doc.read() == obj_data
                if is_new or is_update:
                    doc = doc.latest()
                    doc.change(obj_data)
                    self._technologies[obj_id] = _TechnologyData(doc.read_only(), obj, parent_id)
                if is_new:
                    self._data["technologies"].append(doc.ref)
                    added.append(obj)
                elif is_update:
                    i = self._data["technologies"].index(component_refs[obj_id])
                    self._data["technologies"][i] = doc.ref
                    updated.append(obj)
            else:
                doc, ui_doc, _, parent_id, external = self._components[obj_id]
                is_update = not is_new and (
                    doc.read() != obj_data
                    or any(
                        reference.component._pda_id in updated_component_ids
                        for reference in obj.references
                    )
                )
                if is_new or is_update:
                    previous_ui_ref = ui_doc.ref
                    ui_doc = ui_doc.latest()
                    existing_ui = None
                    if not is_new:
                        try:
                            existing_ui = UiComponent.model_validate(ui_doc.read())
                        except Exception as err:
                            warn(
                                f"Unable to get existing UI data for {obj.name!r}: {err}",
                                RuntimeWarning,
                                3,
                            )
                    component = await component_from_pf(
                        obj,
                        model_schemas=self._data["modelSchemas"],
                        component_schemas=self._data["componentSchemas"],
                        available_refs=component_refs,
                        project_id=self_id,
                        existing_ui=existing_ui,
                        allow_project_changes=True,
                    )
                    doc = doc.latest()
                    doc.change(obj_data)
                    component.pfRef = doc.ref
                    ui_doc.change(component.model_dump(mode="json"))
                    component_refs[obj_id] = ui_doc.ref
                    self._components[obj_id] = _ComponentData(
                        doc.read_only(), ui_doc.read_only(), obj, parent_id, external
                    )
                    updated_component_ids.add(obj_id)
                if is_new:
                    self._data["components"].append({"ref": ui_doc.ref})
                    added.append(obj)
                elif is_update:
                    for updated_component in self._data["components"]:
                        if updated_component["ref"] == previous_ui_ref:
                            updated_component["ref"] = ui_doc.ref
                            break
                    updated.append(obj)

        if update_config:
            self._data["config"] = data["config"]

        if self._doc.read() != self._data:
            self._doc.change(self._data)

        if set_external and isinstance(new_obj, Component):
            await self._set_external(new_obj, True)

        if tag is not None:
            for obj in (*added, *updated):
                doc = (
                    self._technologies[obj._pda_id].doc
                    if isinstance(obj, Technology)
                    else self._components[obj._pda_id].ui_doc
                )
                await _add_tag(doc.ref, tag)

        if bump_version is not None:
            for obj in (*added, *updated):
                doc = (
                    self._technologies[obj._pda_id].doc
                    if isinstance(obj, Technology)
                    else self._components[obj._pda_id].ui_doc
                )
                await _add_version(doc.ref, None, bump_version)

        return {"added": added, "updated": updated}

    def retire(self, targets: Sequence[Component | Technology | str]) -> None:
        """Retire technologies/components by object instance or name.

        Args:
            targets: Components/technologies (or names) to retire.

        Returns:
            ``None``.

        Objects still referenced by remaining project content are kept and
        reported through a runtime warning.
        """
        _run(self._retire(targets))

    async def _retire(self, targets: Sequence[Component | Technology | str]) -> None:
        if self._doc.is_read_only:
            raise RuntimeError(f"Read only project/library {self.name!r} cannot be modified.")

        self_id = self._doc.id
        tech_by_name = {
            v.obj.name: (k, v) for k, v in self._technologies.items() if v.parent_id == self_id
        }
        comp_by_name = {
            v.obj.name: (k, v) for k, v in self._components.items() if v.parent_id == self_id
        }

        retire_technologies = {}
        retire_components = {}
        for target in targets:
            if isinstance(target, Technology):
                data = self._technologies.get(target._pda_id)
                obj_id = None
                if data is None:
                    obj_id, data = tech_by_name.get(target.name, (None, None))
                if data is None or data.parent_id != self_id or target != data.obj:
                    raise RuntimeError(
                        f"Only technologies from this project can be retired. {target.name!r} not "
                        "found (must match exactly)."
                    )
                if obj_id is not None:
                    data.obj._pda_id = obj_id
                retire_technologies[data.obj._pda_id] = data
            elif isinstance(target, Component):
                data = self._components.get(target._pda_id)
                obj_id = None
                if data is None:
                    obj_id, data = comp_by_name.get(target.name, (None, None))
                if data is None or data.parent_id != self_id or target != data.obj:
                    raise RuntimeError(
                        f"Only components from this project can be retired. {target.name!r} not"
                        f"found (must match exactly)."
                    )
                if obj_id is not None:
                    data.obj._pda_id = obj_id
                retire_components[data.obj._pda_id] = data
            elif isinstance(target, str):
                obj_id, data = comp_by_name.get(target, (None, None))
                if data is None:
                    obj_id, data = tech_by_name.get(target, (None, None))
                    if data is None:
                        raise RuntimeError(
                            f"{target!r} not found among project components or technologies."
                        )
                    else:
                        data.obj._pda_id = obj_id
                        retire_technologies[obj_id] = data
                else:
                    data.obj._pda_id = obj_id
                    retire_components[obj_id] = data
            else:
                raise TypeError("Expected Component, Technology, or string name.")

        retire_ids = set(retire_components) | set(retire_technologies)
        keep_objects = [
            data.obj
            for obj_id, data in (*self._components.items(), *self._technologies.items())
            if data.parent_id == self_id and obj_id not in retire_ids
        ]

        exported, _ = _export(*keep_objects)
        exported_ids = {obj._pda_id for obj in exported.values() if len(obj._pda_id) > 0}

        used_component_ids = set(retire_components).intersection(exported_ids)
        used_technology_ids = set(retire_technologies).intersection(exported_ids)

        if len(used_component_ids) > 0 or len(used_technology_ids) > 0:
            used_names = sorted(
                retire_components[obj_id].obj.name for obj_id in used_component_ids
            ) + sorted(retire_technologies[obj_id].obj.name for obj_id in used_technology_ids)
            warn(
                "Objects in use cannot be retired: "
                + ", ".join(repr(name) for name in used_names)
                + ".",
                RuntimeWarning,
                2,
            )

        retired_component_ids = set(retire_components).difference(used_component_ids)
        retired_technology_ids = set(retire_technologies).difference(used_technology_ids)

        if len(retired_component_ids) == 0 and len(retired_technology_ids) == 0:
            return

        for obj_id in retired_component_ids:
            data = self._components.pop(obj_id)
            await _delete_document(data.ui_doc.id)
            await _delete_document(data.doc.id)

        for obj_id in retired_technology_ids:
            data = self._technologies.pop(obj_id)
            await _delete_document(data.doc.id)

        self._data["components"] = [
            x
            for x in self._data["components"]
            if AutomergeRef.parse(x["ref"]).document_id not in retired_component_ids
        ]
        self._data["technologies"] = [
            ref
            for ref in self._data["technologies"]
            if AutomergeRef.parse(ref).document_id not in retired_technology_ids
        ]

        self._doc.change(self._data)

    def add_tag(
        self, tag: str, *, target: Component | Technology | str | None = None
    ) -> Component | Technology | Project:
        """Attach a tag to the project or a specific contained object.

        Args:
            tag: Tag label to create.
            target: Optional target object or name. Defaults to project.

        Returns:
            Target object that received the tag.
        """
        obj, doc = self._find_target(target)
        _run(_add_tag(doc.ref, tag))
        return obj

    def remove_tag(
        self, tag: str | Sequence[str], *, target: Component | Technology | str | None = None
    ) -> Component | Technology | Project:
        """Remove one or more tags from the selected target.

        Args:
            tag: Tag label or labels to remove.
            target: Optional target object or name. Defaults to project.

        Returns:
            Target object from which tags were removed.
        """
        return _run(self._remove_tag(tag, target=target))

    async def _remove_tag(
        self, tag: str | Sequence[str], *, target: Component | Technology | str | None = None
    ) -> Component | Technology | Project:
        if isinstance(tag, str):
            tag = [tag]
        obj, doc = self._find_target(target)
        for tag_data in await _list_tags(None, doc.id):
            if tag_data["tag"] in tag:
                await _delete_tag(tag_data["id"])
        return obj

    def add_version(
        self,
        version: str | None = None,
        bump_version: Literal["major", "minor", "patch"] | None = None,
        *,
        target: Component | Technology | str | None = None,
    ) -> Component | Technology | Project:
        """Create a version for the selected target document reference.

        Args:
            version: Explicit semantic version string.
            bump_version: Semantic bump strategy when ``version`` is
              omitted.
            target: Optional target object or name. Defaults to project.

        Returns:
            Target object that received the version.
        """
        obj, doc = self._find_target(target)
        _run(_add_version(doc.ref, version, bump_version))
        return obj

    def list_permissions(self) -> list[dict[str, object]]:
        """List sharing permissions for the project document.

        Args:
            None.

        Returns:
            Permission metadata list.
        """
        return _run(_list_permissions(self.id))

    def grant_permission(
        self,
        *,
        visibility: Literal["private", "organization"],
        grantee_id: str | None = None,
        role: Literal["owner", "editor", "viewer"] = "viewer",
    ) -> dict[str, object]:
        """Grant access permissions for the project document.

        Args:
            visibility: Permission visibility scope.
            grantee_id: User or organization ID who will receive the permission.
            role: Access role to grant.

        Returns:
            Created permission payload.

        Notes:
            For organization visibility, ``grantee_id`` defaults to the current
            organization when available.

        Important:
            Setting public visibility is not allowed, as it shares the contents
            and all dependencies with **all** users in the platform. Please
            contact support if you want to share a public library.
        """
        if visibility == "public":
            if grantee_id is not None:
                raise ValueError("'grantee_id' must be None when visibility is 'public'.")
            if role != "viewer":
                raise ValueError("'role' must be 'viewer' when visibility is 'public'.")
        elif visibility == "organization":
            if not isinstance(grantee_id, str) or len(grantee_id.strip()) == 0:
                _, grantee_id = user_info()
                if not isinstance(grantee_id, str) or len(grantee_id.strip()) == 0:
                    raise RuntimeError(
                        "Current session has no organization. Cannot grant organization permission "
                        "without providing 'grantee_id'."
                    )
        elif not isinstance(grantee_id, str) or len(grantee_id.strip()) == 0:
            raise ValueError("'grantee_id' must be a non-empty string for private or organization.")

        return _run(_grant_permission(self.id, visibility, grantee_id, role))

    def update_permission(
        self, permission_id: str, *, role: Literal["editor", "viewer"]
    ) -> dict[str, object]:
        """Change the role associated with an existing permission.

        Args:
            permission_id: Permission identifier.
            role: New role value.

        Returns:
            Updated permission payload.
        """
        return _run(_update_permission(self.id, permission_id, role))

    def revoke_permission(self, permission_id: str) -> None:
        """Revoke one permission by its identifier.

        Args:
            permission_id: Permission identifier.

        Returns:
            ``None``.
        """
        _run(_revoke_permission(self.id, permission_id))

    def transfer_ownership(self, grantee_id: str) -> dict[str, object]:
        """Transfer project ownership to another user identifier.

        Args:
            grantee_id: Identifier of the new owner.

        Returns:
            Updated owner permission payload.
        """
        if not isinstance(grantee_id, str) or len(grantee_id) == 0:
            raise ValueError("'grantee_id' must be a non-empty string with the new owner's ID.")
        return _run(_transfer_ownership(self.id, grantee_id))

    def check_access(self) -> tuple[bool, dict[str, object]]:
        """Check if the current user can access this project.

        Args:
            None.

        Returns:
            Tuple ``(has_access, payload)`` from the access endpoint.
        """
        return _run(_check_access(self.id))

    async def _load_obj_ref(
        self, doc_id: DocumentId, doc_ref: ReadOnlyURL
    ) -> Component | Technology:
        """Load one object from a specific reference snapshot.

        Args:
            doc_id: Document ID of the selected object in this project.
            doc_ref: Reference URL for the selected snapshot.

        Returns:
            Loaded component or technology object.
        """
        data = {}
        top_content = []
        for obj_id, obj_data in self._technologies.items():
            if obj_id == doc_id:
                top_content.append((obj_id, 11))
                doc = await _find_repo_document(doc_ref)
            else:
                doc = obj_data.doc
            data[obj_id] = doc.read()
        for obj_id, obj_data in self._components.items():
            if obj_id == doc_id:
                top_content.append((obj_id, 26))
                ui_doc = await _find_repo_document(doc_ref)
                doc = await _find_repo_document(ui_doc.read()["pfRef"])
            else:
                doc = obj_data.doc
            data[obj_id] = doc.read()

        if len(top_content) == 0:
            raise RuntimeError("Target object not found in project.")

        json_data = {
            "type": 1,
            "type_version": "0.0",
            "config": self._data["config"],
            "top_content": top_content,
            "data": data,
            "properties": None,
        }
        byte_repr = json_dumps(json_data).encode("utf-8")
        objects, _ = _import(byte_repr=byte_repr, set_config=False, use_json=True)
        return objects[0]

    def load(
        self,
        target: Component | Technology | str,
        *,
        tag: str | None = None,
        version: str | None = None,
    ) -> Component | Technology | list[Component | Technology]:
        """Load a tagged/versioned snapshot of a project object.

        Args:
            target: Component/technology object or exact name.
            tag: Optional tag filter.
            version: Optional version filter.

        Returns:
            One object for a unique match, otherwise a list of matches.

        Returns one object when selection resolves to a single reference,
        otherwise returns all matching snapshots.
        """
        return _run(self._load(target, tag=tag, version=version))

    async def _load(
        self,
        target: Component | Technology | str,
        *,
        tag: str | None = None,
        version: str | None = None,
    ) -> Component | Technology | list[Component | Technology]:
        if target is None:
            raise ValueError(
                "Invalid target. If you want to load a specific version of this project, use "
                "'load_project' instead."
            )
        obj, doc = self._find_target(target)
        refs = set()
        if tag is not None:
            refs = {info["ref"] for info in await _list_tags(None, doc.id) if info["tag"] == tag}
        if version is not None:
            v_refs = {
                info["ref"] for info in await _list_versions(doc.id) if info["version"] == version
            }
            if tag is None:
                refs = v_refs
            else:
                refs = refs.intersection(v_refs)
        if len(refs) == 1:
            return await self._load_obj_ref(doc.id, next(iter(refs)))
        return [await self._load_obj_ref(doc.id, ref) for ref in refs]

    def add_library(
        self,
        name: str | None = None,
        *,
        version: str | None = None,
        library_id: str | None = None,
    ) -> object:
        """Attach a versioned library and its dependencies to the project.

        Args:
            name: Library project name when selecting by name/version.
            version: Library version when selecting by name/version.
            library_id: Specific library version record ID.

        Returns:
            ``None``.
        """
        return _run(self._add_library(name, version=version, library_id=library_id))

    async def _add_library(
        self,
        name: str | None = None,
        *,
        version: str | None = None,
        library_id: str | None = None,
    ) -> object:
        if self._doc.is_read_only:
            raise RuntimeError(f"Read only project/library {self.name!r} cannot be modified.")

        library, library_id = await _select_library(name, version, library_id, False)

        if library._doc.id in self._libraries:
            raise RuntimeError(
                f"{library.name!r} already in project. Library updates will be implemented in the "
                f"future."
            )

        module_names = {lib._module_name for lib in self._libraries.values()}
        module_names.add(self._module_name)
        if library._module_name in module_names:
            raise RuntimeError(
                f"Library module name {library._module_name!r} already in use in this project."
            )

        all_libraries = []
        for lib_ref in library._data["libraries"]:
            document = await _find_repo_document(lib_ref)
            try:
                lib = Project(document)
            except ValidationError:
                continue
            match = self._libraries.get(lib._doc.id)
            if match is None:
                if lib._module_name in module_names:
                    raise RuntimeError(
                        f"{lib.name!r} module name ({lib._module_name!r}) already in use in this "
                        f"project."
                    )
                all_libraries.append(lib)
            elif lib._doc.ref != match._doc.ref:
                raise RuntimeError(
                    f"{lib.name!r} cannot be added as a dependency because it is incompatible with "
                    f"{match.name!r} already in the project (different versions)."
                )

        # Make sure it loads last (depends on sub-libraries)
        all_libraries.append(library)

        for lib in all_libraries:
            await lib._load_data(False)
            lib._load_module(self._module_path, False, False)

        async def merge_schemas(field: str, schema_kind: str) -> None:
            for lib in all_libraries:
                for key, schema_doc_id in lib._data[field].items():
                    existing_doc_id = self._data[field].get(key)
                    if existing_doc_id is None:
                        self._data[field][key] = schema_doc_id
                        continue
                    if existing_doc_id == schema_doc_id:
                        continue

                    existing_doc = await _find_repo_document(existing_doc_id)
                    schema_doc = await _find_repo_document(schema_doc_id)
                    if existing_doc is None or schema_doc is None:
                        raise RuntimeError(
                            f"Unable to resolve {schema_kind} schema {key!r} while adding "
                            f"library {lib.name!r}."
                        )
                    if existing_doc.read() != schema_doc.read():
                        raise RuntimeError(
                            f"Library {lib.name!r} cannot be added because {schema_kind} schema "
                            f"{key!r} is incompatible with the version already in the project."
                        )

        await merge_schemas("componentSchemas", "component")
        await merge_schemas("modelSchemas", "model")

        self._data["libraries"].extend(lib._doc.ref for lib in all_libraries)
        self._libraries.update({lib._doc.id: lib for lib in all_libraries})

        existing = {x["ref"] for x in self._data["components"]}
        for x in library._data["components"]:
            if x["ref"] not in existing:
                info = {"ref": x["ref"]}
                if x.get("external", False):
                    info["external"] = True
                self._data["components"].append(info)
        self._components.update(
            {k: v for k, v in library._components.items() if k not in self._components}
        )

        existing = set(self._data["technologies"])
        self._data["technologies"].extend(
            ref for ref in library._data["technologies"] if ref not in existing
        )
        self._technologies.update(
            {k: v for k, v in library._technologies.items() if k not in self._technologies}
        )

        self._doc.change(self._data)


def _resolved_create_permission(
    visibility: Literal["private", "organization", "public"],
    role: Literal["editor", "viewer"] | None,
) -> tuple[Literal["organization", "public"] | None, Literal["editor", "viewer"] | None]:
    """Normalize create-time permission arguments into grant payload values.

    Args:
        visibility: Requested visibility at project creation.
        role: Optional role for non-private visibility.

    Returns:
        Tuple ``(visibility, role)`` for ``Project.grant_permission``.
    """
    if visibility == "private":
        if role is not None:
            raise ValueError("'role' cannot be used with visibility='private'.")
        return None, None

    if visibility == "public":
        if role is None:
            role = "viewer"
        if role != "viewer":
            raise ValueError("'public' permissions only support role='viewer'.")
        return visibility, role

    if role is None:
        role = "viewer"
    return visibility, role


def create_project(
    name: str,
    *,
    description: str | None = None,
    labels: Sequence[str] = (),
    visibility: Literal["private", "organization"] = "private",
    role: Literal["editor", "viewer"] | None = None,
    module_path: str = _DEFAULT_MODULE_PATH,
    create_template: bool = True,
) -> Project:
    """Create a new PDA project from current PhotonForge configuration.

    Args:
        name: Project name.
        description: Optional project description.
        labels: Project labels.
        visibility: Initial sharing visibility.
        role: Initial sharing role for non-private visibility.
        module_path: Root path where modules are unpacked.
        create_template: Whether to generate a starter module.

    Returns:
        Loaded project object.

    The initial project includes exported config dependencies and an
    optional template Python module directory.


    Important:
        Setting public visibility is not allowed, as it shares the contents
        and all dependencies with **all** users in the platform. Please
        contact support if you want to share a public library.
    """
    return _run(
        _create_project(
            name,
            description=description,
            labels=labels,
            visibility=visibility,
            role=role,
            module_path=module_path,
            create_template=create_template,
        )
    )


def sort_exported_data(
    objects: dict[str, Technology | Component], data: dict[str, object]
) -> list[tuple[str, dict[str, object], Technology | Component]]:
    sorted_data = []
    remaining = {}
    for obj_id, obj_data in data["data"].items():
        obj = objects[obj_id]
        if isinstance(objects[obj_id], Technology) or len(obj.references) == 0:
            sorted_data.append((obj_id, obj_data, obj))
        else:
            remaining[obj_id] = (obj_data, obj)
    progress = len(sorted_data)
    while len(remaining) > 0:
        for obj_id, (obj_data, obj) in remaining.items():
            if all(x.component._pda_id not in remaining for x in obj.references):
                sorted_data.append((obj_id, obj_data, obj))
        if len(sorted_data) == progress:
            raise RuntimeError("Dependency cycle found in exported data.")
        for obj_id, *_ in sorted_data[progress:]:
            remaining.pop(obj_id)
        progress = len(sorted_data)
    return sorted_data


async def _create_project(
    name: str,
    *,
    description: str | None = None,
    labels: Sequence[str] = (),
    visibility: Literal["private", "organization"] = "private",
    role: Literal["editor", "viewer"] | None = None,
    module_path: str = _DEFAULT_MODULE_PATH,
    create_template: bool = True,
) -> Project:
    # Create components and techologies used in config defaults.
    # If they come from another project (already have document IDs), we overwrite
    # them with new IDs because they can only belong to a single project.
    objects, _ = _export()
    if not all(isinstance(obj, (Component, Technology)) for obj in objects.values()):
        raise RuntimeError("Unexpected type in config data.")

    project_info = await _create_document(_project_type, None)
    project_id = project_info["documentId"]
    project_technologies = {}
    project_components = {}
    project_data = {
        "name": name,
        "description": description,
        "labels": list(labels),
        "applications": [],
        "libraries": [],
        "components": [],
        "technologies": [],
        "config": {},
        "componentSchemas": {},
        "modelSchemas": {},
    }

    # Create the documents ahead of time to define PDA IDs
    for obj in objects.values():
        if isinstance(obj, Technology):
            doc_info = await _create_document(_technology_type, project_id)
            doc_id = doc_info["documentId"]
            doc = await _find_repo_document(doc_id)
            obj._pda_id = doc_id
            project_technologies[doc_id] = doc
        else:
            doc_info = await _create_document(_component_type, project_id)
            ui_doc_info = await _create_document(_ui_component_type, project_id)
            doc_id = doc_info["documentId"]
            ui_doc_id = ui_doc_info["documentId"]
            doc = await _find_repo_document(doc_id)
            ui_doc = await _find_repo_document(ui_doc_id)
            obj._pda_id = ui_doc_id
            project_components[ui_doc_id] = (doc, ui_doc)

    # Now re-export using doc ids for cross-referencing from _pda_id
    objects, data = _export(use_json=True)
    data = json_loads(data)
    sorted_data = sort_exported_data(objects, data)

    component_refs = {}
    technologies = []
    for obj_id, obj_data, obj in sorted_data:
        if isinstance(obj, Technology):
            doc = project_technologies[obj_id]
            doc.change(obj_data)
            technologies.append(doc.ref)
            project_technologies[obj_id] = _TechnologyData(doc.read_only(), obj, project_id)
        else:
            component = await component_from_pf(
                obj,
                model_schemas=project_data["modelSchemas"],
                component_schemas=project_data["componentSchemas"],
                available_refs=component_refs,
                project_id=project_id,
                allow_project_changes=True,
            )
            doc, ui_doc = project_components[obj_id]
            doc.change(obj_data)
            component.pfRef = doc.ref
            ui_doc.change(component.model_dump(mode="json"))
            component_refs[obj_id] = ui_doc.ref
            project_components[obj_id] = _ComponentData(
                doc.read_only(), ui_doc.read_only(), obj, project_id, False
            )

    document = await _find_repo_document(project_id)
    project_data["components"] = [{"ref": ref} for ref in component_refs.values()]
    project_data["technologies"] = technologies
    project_data["config"] = data["config"]
    document.change(project_data)

    project = Project(document)
    project._technologies = project_technologies
    project._components = project_components

    visibility, role = _resolved_create_permission(visibility, role)
    if visibility is not None and role is not None:
        grant_id = None
        if visibility == "organization":
            _, tenant_id = await _user_info()
            if tenant_id is None:
                raise RuntimeError(
                    "Current session has no organization. Cannot grant organization permission."
                )
            grant_id = tenant_id
        await _grant_permission(project.id, visibility, grant_id, role)

    project._load_module(module_path, True, create_template)
    return project


def list_projects(
    name: str | None = None,
    *,
    labels: Sequence[str] = (),
    visibility: Literal["private", "organization", "public"] | None = None,
    role: Literal["owner", "editor", "viewer"] | None = None,
    retired: bool = False,
) -> list[dict[str, object]]:
    """List projects matching metadata, sharing, and retirement filters.

    Args:
        name: Exact project name filter.
        labels: Label filter; any overlap matches.
        visibility: Visibility filter.
        role: Permission role filter.
        retired: Whether to search retired projects.

    Returns:
        Project metadata list.
    """
    return _run(
        _list_projects(
            name,
            labels=labels,
            visibility=visibility,
            role=role,
            retired=retired,
        )
    )


async def _list_projects(
    name: str | None = None,
    *,
    labels: Sequence[str] = (),
    visibility: Literal["private", "organization", "public"] | None = None,
    role: Literal["owner", "editor", "viewer"] | None = None,
    retired: bool = False,
) -> list[dict[str, object]]:
    result = []
    labels = set(labels)
    for project_data in await _list_documents(types=[_project_type], deleted=retired):
        try:
            document = await _find_repo_document(project_data["documentId"])
        except RuntimeError as err:
            warn(
                f"Skipping unloadable project {project_data['documentId']}: {err}",
                RuntimeWarning,
                stacklevel=2,
            )
            continue
        try:
            project = Project(document)
        except ValidationError:
            continue
        if (
            (name is None or project._data.get("name") == name)
            and (len(labels) == 0 or len(labels.intersection(project._data.get("labels", ()))) > 0)
            and (role is None or project_data.get("role") == role)
            and (visibility is None or project_data.get("visibility") == visibility)
        ):
            project_data.update({"name": project.name, "labels": project.labels})
            result.append(project_data)
    return result


def list_libraries(
    name: str | None = None,
    *,
    labels: Sequence[str] = (),
    visibility: Literal["private", "organization", "public"] | None = None,
    role: Literal["owner", "editor", "viewer"] | None = None,
    latest: bool = True,
    retired: bool = False,
) -> list[dict[str, object]]:
    """List versioned project libraries with optional metadata filters.

    Args:
        name: Exact library name filter.
        labels: Label filter; any overlap matches.
        visibility: Visibility filter.
        role: Permission role filter.
        latests: If ``True``, only the latest version of each library is
          returned.
        retired: Whether to search retired libraries.

    Returns:
        Library metadata list.
    """
    return _run(
        _list_libraries2(
            name,
            labels=labels,
            visibility=visibility,
            role=role,
            latest=latest,
            retired=retired,
        )
    )


async def _list_libraries2(
    name: str | None = None,
    *,
    labels: Sequence[str] = (),
    visibility: Literal["private", "organization", "public"] | None = None,
    role: Literal["owner", "editor", "viewer"] | None = None,
    latest: bool = True,
    retired: bool = False,
) -> list[dict[str, object]]:
    result = []
    labels = set(labels)
    for library_data in await _list_libraries(latest=latest, deleted=retired):
        try:
            document = await _find_repo_document(library_data["documentId"])
        except RuntimeError as err:
            # Storage may contain a stub/empty snapshot for a half-created
            # project (DB row exists, content was never written). Skip rather
            # than aborting the whole listing so callers can still discover
            # healthy libraries.
            warn(
                f"Skipping unloadable library {library_data['documentId']}: {err}",
                RuntimeWarning,
                stacklevel=2,
            )
            continue
        try:
            library = Project(document)
        except ValidationError:
            continue
        if (
            (name is None or library._data.get("name") == name)
            and (len(labels) == 0 or len(labels.intersection(library._data.get("labels", ()))) > 0)
            and (role is None or library_data.get("role") == role)
            and (visibility is None or library_data.get("visibility") == visibility)
        ):
            library_data.update({"name": library.name, "labels": library.labels})
            result.append(library_data)
    return result


async def _select_project(
    name: str | None,
    version: str | None,
    tag: str | None,
    project_id: DocumentId | ReadOnlyURL | None,
    deleted: bool,
) -> Project:
    """Select one project by name/id and optional version/tag filters.

    Args:
        name: Project name used when ``project_id`` is not provided.
        version: Optional version filter.
        tag: Optional tag filter.
        project_id: Project document ID or reference URL.
        deleted: Whether to search retired projects.

    Returns:
        Matched project.
    """
    if project_id is None:
        if name is None:
            raise RuntimeError("Either 'name' or 'project_id' must be defined.")
        result = await _list_documents(types=[_project_type], deleted=deleted)
        matches = []
        for project_data in result:
            try:
                document = await _find_repo_document(project_data["documentId"])
            except RuntimeError as err:
                warn(
                    f"Skipping unloadable project {project_data['documentId']}: {err}",
                    RuntimeWarning,
                    stacklevel=2,
                )
                continue
            try:
                project = Project(document)
            except ValidationError:
                continue
            if project._data.get("name") == name:
                matches.append(project)
        if len(matches) == 0:
            raise RuntimeError(f"Project {name!r} not found.")
        if version is not None:
            matches = [
                project
                for project in matches
                if any(version == info["version"] for info in await _list_versions(project.id))
            ]
            if len(matches) == 0:
                raise RuntimeError(f"Version {version} of project {name!r} not found.")
        if tag is not None:
            matches = [
                project
                for project in matches
                if any(tag == info["tag"] for info in await _list_tags(None, project.id))
            ]
            if len(matches) == 0:
                raise RuntimeError(f"Tag {tag!r} not found in project {name!r}.")
        if len(matches) > 1:
            raise RuntimeError(f"{len(matches)} projects matching search parameters found.")
        project = matches[0]
    else:
        if name is not None:
            warn("Project name ignored. Using 'project_id' only.", RuntimeWarning, 3)
        document = await _find_repo_document(project_id)
        try:
            project = Project(document)
        except ValidationError as err:
            raise RuntimeError(f"Project {project_id!r} has invalid schema.") from err
        if version is not None and all(
            version != info["version"] for info in await _list_versions(project.id)
        ):
            raise RuntimeError(f"Version {version} of project {name!r} not found.")
        if tag is not None and all(
            tag != info["tag"] for info in await _list_tags(None, project.id)
        ):
            raise RuntimeError(f"Tag {tag!r} not found in project {name!r}.")
    return project


def load_project(
    name: str | None = None,
    *,
    project_id: DocumentId | ReadOnlyURL | None = None,
    version: str | None = None,
    tag: str | None = None,
    module_path: str = _DEFAULT_MODULE_PATH,
    set_config: bool = True,
    create_template: bool = False,
) -> Project:
    """Load one project by name or document reference.

    Args:
        name: Project name to load.
        project_id: Project document ID or reference URL.
        version: Optional version filter.
        tag: Optional tag filter.
        module_path: Root path where modules are unpacked.
        set_config: Whether to apply project config to PhotonForge.
        create_template: Whether to create a starter module if absent.

    Returns:
        Loaded project object.
    """
    return _run(
        _load_project(
            name,
            project_id=project_id,
            version=version,
            tag=tag,
            module_path=module_path,
            set_config=set_config,
            create_template=create_template,
        )
    )


async def _load_project(
    name: str | None = None,
    *,
    project_id: DocumentId | ReadOnlyURL | None = None,
    version: str | None = None,
    tag: str | None = None,
    module_path: str = _DEFAULT_MODULE_PATH,
    set_config: bool = True,
    create_template: bool = False,
) -> Project:
    project = await _select_project(name, version, tag, project_id, False)
    await project._load_data(set_config)
    project._load_module(module_path, True, create_template)
    return project


def retire_project(
    name: str | None = None, *, project_id: DocumentId | ReadOnlyURL | None = None
) -> object:
    """Retire a project document by name or identifier.

    Args:
        name: Project name.
        project_id: Project document ID or reference URL.

    Returns:
        ``None``.

    Important:
        Projects that are released (given a version) cannot be retired.
    """
    return _run(_retire_project(name, project_id=project_id))


async def _retire_project(
    name: str | None = None, *, project_id: DocumentId | ReadOnlyURL | None = None
) -> object:
    project = await _select_project(name, None, None, project_id, False)
    await _delete_document(project.id)


# def restore_project(
#     name: str | None = None, *, project_id: DocumentId | ReadOnlyURL | None = None
# ) -> object:
#     """Restore a previously retired project document.
#
#     Args:
#         name: Project name.
#         project_id: Project document ID or reference URL.
#
#     Returns:
#         ``None``.
#     """
#     return _run(_restore_project(name, project_id=project_id))
#
#
# async def _restore_project(
#     name: str | None = None, *, project_id: DocumentId | ReadOnlyURL | None = None
# ) -> object:
#     project = await _select_project(name, None, None, project_id, True)
#     await _restore_document(project.id)


async def _select_library(
    name: str | None, version: str | None, library_id: str | None, deleted: bool
) -> (Project, str):
    """Resolve a specific library version and version record ID.

    Args:
        name: Library project name.
        version: Library semantic version string.
        library_id: Explicit library version record ID.
        deleted: Whether to search retired projects.

    Returns:
        Tuple ``(library_project, library_version_id)``.
    """
    if library_id is None:
        if name is None or version is None:
            raise RuntimeError("Either 'name' and 'version', or 'library_id' must be defined.")
        project = await _select_project(name, None, None, None, deleted)
        matches = [
            library_info
            for library_info in await _list_versions(project._doc.id)
            if library_info["version"] == version
        ]
        if len(matches) == 0:
            raise RuntimeError(f"Library {name!r} version {version} not found.")
        if len(matches) > 1:
            raise RuntimeError(
                f"{len(matches)} libraries with name {name!r} and version {version} found."
            )
        library_id = matches[0]["id"]
        document = await _find_repo_document(matches[0]["documentId"])
        library = Project(document)
    else:
        if name is not None or version is not None:
            warn("Library name and version ignored. Using 'library_id' only.", RuntimeWarning, 3)
        library_data = await _get_version(library_id)
        document = await _find_repo_document(library_data["documentId"])
        library = Project(document)
    return library, library_id
