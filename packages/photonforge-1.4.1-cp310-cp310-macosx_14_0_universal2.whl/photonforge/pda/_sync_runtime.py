"""Sync bridge runtime for PDA async internals."""

from __future__ import annotations

import asyncio
import threading
from collections.abc import Coroutine
from typing import TypeVar

T = TypeVar("T")

_loop: asyncio.AbstractEventLoop | None = None
_loop_lock = threading.Lock()

_thread_loop: asyncio.AbstractEventLoop | None = None
_thread: threading.Thread | None = None
_thread_ready = threading.Event()
_thread_lock = threading.Lock()


def _ensure_loop() -> asyncio.AbstractEventLoop:
    global _loop
    if _loop is not None and not _loop.is_closed():
        return _loop
    with _loop_lock:
        if _loop is None or _loop.is_closed():
            _loop = asyncio.new_event_loop()
        return _loop


def _run_thread_loop(profile: str | None) -> None:
    global _thread_loop
    if profile is not None:
        from tidy3d.config import get_manager

        get_manager().switch_profile(profile)
    loop = asyncio.new_event_loop()
    _thread_loop = loop
    asyncio.set_event_loop(loop)
    _thread_ready.set()
    loop.run_forever()
    loop.run_until_complete(loop.shutdown_asyncgens())
    loop.close()


def _ensure_thread_loop() -> asyncio.AbstractEventLoop:
    global _thread
    if _thread_loop is not None and _thread is not None and _thread.is_alive():
        return _thread_loop
    with _thread_lock:
        if _thread_loop is not None and _thread is not None and _thread.is_alive():
            return _thread_loop
        from tidy3d.config import get_manager

        profile = get_manager().profile
        _thread_ready.clear()
        _thread = threading.Thread(
            target=_run_thread_loop,
            args=(profile,),
            name="photonforge-pda-sync",
            daemon=True,
        )
        _thread.start()
        _thread_ready.wait()
        if _thread_loop is None:
            raise RuntimeError("Failed to start PDA background event loop.")
        return _thread_loop


def run(coro: Coroutine[object, object, T]) -> T:
    """Run one coroutine synchronously.

    - If no event loop is running in the caller thread, run on a persistent
      local loop (script/test behavior).
    - If an event loop is already running (e.g. Jupyter), dispatch to a
      dedicated background loop thread and wait for the result.
    """
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        loop = _ensure_loop()
        asyncio.set_event_loop(loop)
        return loop.run_until_complete(coro)
    loop = _ensure_thread_loop()
    if _thread is not None and threading.current_thread() is _thread:
        raise RuntimeError("PDA sync API cannot be called from its own event loop thread.")
    return asyncio.run_coroutine_threadsafe(coro, loop).result()


def stop() -> None:
    """Close and clear all PDA sync runtime loops."""
    global _loop, _thread_loop, _thread

    if _loop is not None:
        loop = _loop
        if not loop.is_closed():
            asyncio.set_event_loop(loop)
            loop.run_until_complete(loop.shutdown_asyncgens())
            loop.close()
        _loop = None

    if _thread_loop is not None:
        loop = _thread_loop
        thread = _thread
        if loop.is_running():
            loop.call_soon_threadsafe(loop.stop)
        if thread is not None:
            thread.join()
        _thread_loop = None
        _thread = None
        _thread_ready.clear()
