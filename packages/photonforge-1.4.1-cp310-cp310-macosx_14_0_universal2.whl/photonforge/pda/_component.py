"""PhotonForge component to PDA UI-model conversion utilities."""

import logging
from collections.abc import Callable
from multiprocessing import current_process

import numpy as np

from .. import parametric
from ..extension import Component, Model, Port, Reference, Terminal, _component_registry
from ..thumbnails import thumbnails
from ._client import (
    _component_schema_type,
    _create_document,
    _find_repo_document,
    _model_schema_type,
)
from ._common_schema import Matrix3x2AffineJson
from ._crdt.refs import AutomergeRef
from ._parametric_schema import inspect_parameters
from ._types import (
    DocumentId,
    ReadOnlyURL,
    ReferenceCanvasProperties,
    UiComponent,
    UiModel,
    UiPort,
    UiReference,
    UiReferencePort,
    UiReferenceTerminal,
    UiTerminal,
)

logger = logging.getLogger(f"photonforge.server.worker.{current_process().name}.component")

CANVAS_SCALING_FACTOR = 20.0


def detect_route(
    component: Component, netlist: dict[str, object], route_index: int, reference: Reference
) -> dict[str, object] | None:
    """Try to map a route reference to a UI connection payload.

    Returns ``None`` when the reference cannot be represented as a
    PDA route connection.

    Args:
        component: Parent component containing the candidate route.
        netlist: Netlist structure derived from ``component``.
        route_index: Reference index for the candidate route.
        reference: Route reference to inspect.

    Returns:
        UI connection payload when route detection succeeds, otherwise
        ``None``.
    """
    fn_name = reference.component.parametric_function
    if fn_name not in ("photonforge.parametric.route", "photonforge.parametric.route_s_bend"):
        return None

    matches = [
        (connection_index, instance_index, port_name)
        for connection_index, connection in enumerate(netlist["connections"])
        for (instance_index, port_name, _), (other_index, _, _) in [
            connection,
            (connection[1], connection[0]),
        ]
        if other_index == route_index
    ]
    if len(matches) == 2:
        # Match connection ports to kwargs ports for ordering
        kwargs_ports = [
            reference.component.parametric_kwargs.get("port1"),
            reference.component.parametric_kwargs.get("port2"),
        ]
        for i in range(2):
            port = kwargs_ports[i]
            if not (port is None or isinstance(port, Port)):
                if len(port) > 1 and isinstance(port[0], Reference):
                    index = port[2] if len(port) > 2 else 0
                    port_list = port[0].get_ports(port[1])
                    kwargs_ports[i] = port_list[index]
                else:
                    kwargs_ports[i] = None

        route_ports = (
            component.references[matches[0][1]][matches[0][2]],
            component.references[matches[1][1]][matches[1][2]],
        )

        if route_ports[0] == kwargs_ports[1] or route_ports[1] == kwargs_ports[0]:
            matches = [matches[1], matches[0]]
        elif route_ports[0] != kwargs_ports[0] and route_ports[1] != kwargs_ports[1]:
            return None

        (connection_index0, instance0, port0), (connection_index1, instance1, port1) = matches

        kwargs = {
            # k: make_serializable(v)
            # for k, v in reference.component.parametric_kwargs.items()
            # if v is not None and k != "port1" and k != "port2"
        }

        fn = getattr(parametric, fn_name[fn_name.rfind(".") + 1 :])
        ref0 = component.references[instance0]
        ref1 = component.references[instance1]

        route = fn(port1=(ref0, port0), port2=(ref1, port1), **kwargs)
        route.name = reference.component.name
        if route != reference.component:
            return None

        netlist["connections"].pop(max(connection_index0, connection_index1))
        netlist["connections"].pop(min(connection_index0, connection_index1))

        # return {
        #     "port1": {"reference": instance0, "port": port0},
        #     "port2": {"reference": instance1, "port": port1},
        #     "function": fn_name,
        #     "kwargs": kwargs,
        # }

        return {
            "from": {"nodeId": ref0.component._id, "portId": ref0.component.ports[port0]._id},
            "to": {"nodeId": ref1.component._id, "portId": ref1.component.ports[port1]._id},
        }


def port_properties(
    port: Port, xmin: float, ymin: float, xmax: float, ymax: float
) -> tuple[str, float]:
    """Compute UI side/offset placement for a component port.

    Args:
        port: Port instance.
        xmin: Inner bounding-box minimum x.
        ymin: Inner bounding-box minimum y.
        xmax: Inner bounding-box maximum x.
        ymax: Inner bounding-box maximum y.

    Returns:
        Tuple ``(side, offset)`` for canvas placement.
    """
    c = port.center
    direction = (
        port.input_direction
        if isinstance(port, Port)
        else (np.arctan2(port.input_vector[1], port.input_vector[0]) / np.pi * 180)
    ) % 360
    _, _, side, coord = min(
        (min(0, c[0] - xmin), min(direction, 360 - direction), "left", -c[1].item()),
        (min(0, xmax - c[0]), abs(direction - 180), "right", -c[1].item()),
        (min(0, c[1] - ymin), abs(direction - 90), "bottom", c[0].item()),
        (min(0, ymax - c[1]), abs(direction - 270), "top", c[0].item()),
    )
    return side, coord


def terminal_properties(
    terminal: Terminal, xmin: float, ymin: float, xmax: float, ymax: float
) -> tuple[str, float]:
    """Compute UI side/offset placement for a terminal.

    Args:
        terminal: Terminal instance.
        xmin: Inner bounding-box minimum x.
        ymin: Inner bounding-box minimum y.
        xmax: Inner bounding-box maximum x.
        ymax: Inner bounding-box maximum y.

    Returns:
        Tuple ``(side, offset)`` for canvas placement.
    """
    c = terminal.center()
    _, _, side, coord = min(
        (min(0, c[0] - xmin), 2, "left", -c[1].item()),
        (min(0, xmax - c[0]), 3, "right", -c[1].item()),
        (min(0, c[1] - ymin), 0, "bottom", c[0].item()),
        (min(0, ymax - c[1]), 1, "top", c[0].item()),
    )
    return side, coord


def set_offsets(items: object) -> None:
    """Distribute side-local port/terminal offsets uniformly.

    Args:
        items: Mutable list of UI item dictionaries.

    Returns:
        ``None``.
    """
    n = len(items)
    if n <= 1:
        g = g0 = 0
    else:
        g = 1 / n
        g0 = -0.5 + g / 2
    items.sort(key=lambda item: (item["canvasProperties"]["offset"], item["name"] or ""))
    for i in range(n):
        items[i]["canvasProperties"]["offset"] = g0 + i * g


def get_ports_and_terminals(component: object) -> tuple[list[object], list[object]]:
    """Extract and place component ports/terminals for the schematic UI.

    Args:
        component: Component-like object exposing bounds, ports, and
          terminals.

    Returns:
        Tuple ``(ports, terminals)`` with UI model objects.
    """
    (xmin, ymin), (xmax, ymax) = component.bounds()
    d = min(ymax - ymin, xmax - xmin) / 4
    xmin += d
    ymin += d
    xmax -= d
    ymax -= d
    items_by_side = {"left": [], "right": [], "bottom": [], "top": []}
    for name, port in component.ports.items():
        side, coord = port_properties(port, xmin, ymin, xmax, ymax)
        items_by_side[side].append(
            {
                "name": name,
                "classificationType": port.classification,
                "baseType": port.__class__.__name__,
                "numModes": port.num_modes,
                "origin": None,
                "canvasProperties": {"side": side, "offset": coord},
            }
        )
        if port.classification == "electrical":
            for term_name, terminal in port.terminals().items():
                side, coord = terminal_properties(terminal, xmin, ymin, xmax, ymax)
                items_by_side[side].append(
                    {
                        "name": None,
                        "origin": UiReferenceTerminal(
                            name=term_name, portName=name, referenceId=None
                        ),
                        "canvasProperties": {"side": side, "offset": coord},
                    }
                )
    for name, terminal in component.terminals.items():
        side, coord = terminal_properties(terminal, xmin, ymin, xmax, ymax)
        items_by_side[side].append(
            {
                "name": name,
                "origin": None,
                "canvasProperties": {"side": side, "offset": coord},
            }
        )
    for items in items_by_side.values():
        set_offsets(items)
    ports = []
    terminals = []
    for items in items_by_side.values():
        for item in items:
            if "numModes" in item:
                ports.append(UiPort.model_validate(item))
            else:
                terminals.append(UiTerminal.model_validate(item))
    return ports, terminals


async def model_from_pf(
    model: Model,
    model_schemas: dict[str, DocumentId],
    project_id: DocumentId,
    allow_project_changes: bool,
) -> UiModel:
    """Build a UI model payload from a PhotonForge model instance.

    Args:
        model: PhotonForge model instance.

    Returns:
        UI model payload with parameter schema and values.
    """
    schema, values, _ = inspect_parameters(model.__class__, model.parametric_kwargs)
    model_key = model.__class__.__name__

    schema_doc_id = model_schemas.get(model_key)
    schema_doc = await _find_repo_document(schema_doc_id) if schema_doc_id else None

    if schema_doc is None:
        if not allow_project_changes:
            raise RuntimeError(
                f"Model schema for {model_key!r} is missing and updates are disabled."
            )
        schema_doc_info = await _create_document(_model_schema_type, project_id, schema)
        schema_doc_id = schema_doc_info["documentId"]
        model_schemas[model_key] = schema_doc_id
        schema_doc = await _find_repo_document(schema_doc_id)

    if schema_doc is None:
        raise RuntimeError(f"Could not resolve model schema document for {model_key!r}.")

    if schema_doc.read() != schema:
        if not allow_project_changes:
            raise RuntimeError(
                f"Existing schema for component {model_key!r} does not match the existing one "
                f"and updates are disabled."
            )
        schema_doc = schema_doc.latest()
        schema_doc.change(schema)

    return UiModel(
        className=model.__class__.__name__,
        parameters=values,
        parametersSchema=schema_doc.ref,
    )


async def component_schema_ref_from_pf(
    component: Component,
    component_schemas: dict[str, DocumentId],
    project_id: DocumentId,
    allow_project_changes: bool,
) -> tuple[str | None, dict[str, object]]:
    fn = _component_registry.get(component.parametric_function)
    if fn is None:
        return None, {}

    schema, values, _ = inspect_parameters(fn, component.parametric_kwargs)
    schema_key = component.parametric_function

    schema_doc_id = component_schemas.get(schema_key)
    schema_doc = await _find_repo_document(schema_doc_id) if schema_doc_id else None

    if schema_doc is None:
        if not allow_project_changes:
            raise RuntimeError(
                f"Component schema for {schema_key!r} is missing and updates are disabled."
            )
        schema_doc_info = await _create_document(_component_schema_type, project_id, schema)
        schema_doc_id = schema_doc_info["documentId"]
        component_schemas[schema_key] = schema_doc_id
        schema_doc = await _find_repo_document(schema_doc_id)

    if schema_doc is None:
        raise RuntimeError(f"Could not resolve component schema document for {schema_key!r}.")

    if schema_doc.read() != schema:
        if not allow_project_changes:
            raise RuntimeError(
                f"Existing schema for component {component.name!r} does not match the existing one "
                f"and updates are disabled."
            )
        schema_doc = schema_doc.latest()
        schema_doc.change(schema)

    return schema_doc.ref, values


def reference_from_pf(
    reference: Reference, available_refs: dict[DocumentId, DocumentId | ReadOnlyURL]
) -> UiReference:
    """Convert a PhotonForge reference into its UI representation.

    Args:
        reference: PhotonForge reference object.

    Returns:
        UI reference payload with affine transform.
    """
    # Both `transform` (layout) and `canvas_transform` (schematic) are written in
    # PhotonForge's native physics-Y-up convention. The frontend's CRDT adapter
    # (Approach C; flex#12086) flips Y at the model boundary so consumers see
    # canvas-Y-down, with no per-call-site conversion needed here.
    transform = Matrix3x2AffineJson.from_kwargs(
        reference.origin, reference.rotation, reference.scaling, reference.x_reflection
    )
    canvas_transform = Matrix3x2AffineJson.from_kwargs(
        reference.center() * CANVAS_SCALING_FACTOR, reference.rotation, 1.0, reference.x_reflection
    )
    component_ref = available_refs[reference.component._pda_id]
    return UiReference(
        id=reference._id,
        component=AutomergeRef.parse_id(component_ref),
        transform=transform,
        canvasProperties=ReferenceCanvasProperties(transform=canvas_transform),
    )


def endpoint_name(endpoint: dict[str, object]) -> str:
    if endpoint.get("kind") == "terminal":
        result = f"{endpoint['referenceId']}.T.{endpoint['name']}"
        if endpoint["portName"] is not None:
            result += f".P.{endpoint['portName']}"
        return result
    return f"{endpoint['referenceId']}.P.{endpoint['name']}"


def _port_key(port: UiPort) -> tuple[str, str | None, str | None]:
    if port.origin is None:
        return port.name, None, None
    return port.name, port.origin.referenceId, port.origin.name


def _terminal_key(
    terminal: UiTerminal,
) -> tuple[str | None, str | None, str | None, str | None]:
    if terminal.origin is None:
        return terminal.name, None, None, None
    return (
        terminal.name,
        terminal.origin.referenceId,
        terminal.origin.portName,
        terminal.origin.name,
    )


def _merge_ui_data(ui_component: UiComponent, existing_ui: UiComponent | None) -> UiComponent:
    if existing_ui is None:
        return ui_component

    if ui_component.references is not None and existing_ui.references is not None:
        for ref_id, reference in ui_component.references.items():
            existing_reference = existing_ui.references.get(ref_id)
            if existing_reference is not None and existing_reference.canvasProperties is not None:
                reference.canvasProperties = existing_reference.canvasProperties

    if (
        ui_component.referenceOrder is None
        and ui_component.references is not None
        and existing_ui.referenceOrder is not None
    ):
        ordered = [
            ref_id for ref_id in existing_ui.referenceOrder if ref_id in ui_component.references
        ]
        seen = set(ordered)
        ordered.extend(ref_id for ref_id in ui_component.references if ref_id not in seen)
        ui_component.referenceOrder = ordered

    if ui_component.ports is not None and existing_ui.ports is not None:
        existing_ports = {_port_key(port): port for port in existing_ui.ports}
        for port in ui_component.ports:
            existing_port = existing_ports.get(_port_key(port))
            if existing_port is not None:
                port.canvasProperties = existing_port.canvasProperties

    if ui_component.terminals is not None and existing_ui.terminals is not None:
        existing_terminals = {
            _terminal_key(terminal): terminal for terminal in existing_ui.terminals
        }
        for terminal in ui_component.terminals:
            existing_terminal = existing_terminals.get(_terminal_key(terminal))
            if existing_terminal is not None:
                terminal.canvasProperties = existing_terminal.canvasProperties

    if ui_component.virtualConnections is not None and existing_ui.virtualConnections is not None:
        for connection_key, connection in ui_component.virtualConnections.items():
            existing_connection = existing_ui.virtualConnections.get(connection_key)
            if existing_connection is not None:
                connection.properties = existing_connection.properties

    return ui_component


async def component_from_pf(
    component_or_fn: Component | Callable[[], Component],
    *,
    model_schemas: dict[str, DocumentId],
    component_schemas: dict[str, DocumentId],
    available_refs: dict[DocumentId, DocumentId | ReadOnlyURL],
    project_id: DocumentId,
    existing_ui: UiComponent | None = None,
    allow_project_changes: bool = True,
) -> UiComponent:
    """Convert a PhotonForge component into a PDA ``UiComponent``.

    Args:
        component_or_fn: Concrete component or zero-argument callable
          returning one.

    Returns:
        UI-facing component payload with parameters, models,
        references, terminals, and schematic connections.

    Raises:
        TypeError: If ``component_or_fn`` does not produce a component.
        RuntimeError: If unsupported array references are detected.
    """
    if isinstance(component_or_fn, Component):
        component = component_or_fn
    else:
        component = component_or_fn()
        if not isinstance(component, Component):
            raise TypeError("Expected 'Component' type.")

    schema_ref, values = await component_schema_ref_from_pf(
        component,
        component_schemas,
        project_id,
        allow_project_changes,
    )

    active_models = component.active_model_name
    if isinstance(active_models, str):
        active_models = {"electrical": active_models, "optical": active_models}

    models = {
        name: await model_from_pf(model, model_schemas, project_id, allow_project_changes)
        for name, model in component.models.items()
    }
    ports, terminals = get_ports_and_terminals(component)

    references = {}
    all_connections = []

    if len(component.references) > 0:
        netlist = component.get_netlist(suppress_warnings=True)
        if len(component.references) != len(netlist["instances"]):
            raise RuntimeError(
                f"Component '{component.name}' contains array references, which are not supported."
            )

        ref_ids = {}
        routes = []
        for index, reference in enumerate(component.references):
            route = None  # detect_route(component, netlist, index, reference)
            if route is None:
                ui_ref = reference_from_pf(reference, available_refs)
                ref_ids[index] = ui_ref.id
                references[ui_ref.id] = ui_ref
            else:
                routes.append(route)

        all_connections = [
            {
                "from": {"referenceId": ref_ids[i[0]], "name": i[1]},
                "to": {"referenceId": ref_ids[j[0]], "name": j[1]},
            }
            for i, j in netlist["connections"]
            + netlist["butt couplings"]
            + netlist["virtual connections"]
        ]

        net_ports = {v: k for k, v in netlist["ports"].items()}
        for ui_port in ports:
            index, name, _ = net_ports.get(ui_port.name, (None, None, None))
            if index is not None:
                ui_port.origin = UiReferencePort(referenceId=ref_ids[index], name=name)

        net_terminals = {v: k for k, v in netlist["terminals"].items()}
        for ui_terminal in terminals:
            index, name = net_terminals.get(ui_terminal.name, (None, None))
            if index is not None:
                if isinstance(name, str):
                    port_name = None
                else:
                    port_name, name = name
                ui_terminal.origin = UiReferenceTerminal(
                    referenceId=ref_ids[index], portName=port_name, name=name
                )

    virtualConnections = {
        f"{endpoint_name(vc['from'])}->{endpoint_name(vc['to'])}": vc for vc in all_connections
    }
    thumbnail = thumbnails[component.properties.get("__thumbnail__")]
    preview = component._repr_svg_(partial=True)

    return _merge_ui_data(
        UiComponent(
            pfRef=component.parametric_function,
            name=component.name,
            referencedComponent=None,
            parameters=values,
            parametersSchema=schema_ref,
            models=models,
            activeModel=active_models,
            references=references,
            ports=ports,
            terminals=terminals,
            virtualConnections=virtualConnections,
            thumbnail=thumbnail,
            preview=preview,
        ),
        existing_ui,
    )
