"""Heads capture and encoding via private automerge-py internals.

This module isolates all access to non-public automerge-py attributes
(_doc_actors, _actor_id, get_document) behind a small set of functions.
When upstream adds DocHandle.heads() and DocHandle.view(heads), only
this file needs to change.
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable, Sequence
from inspect import isawaitable
from typing import TYPE_CHECKING, Any

import automerge.core as _core
from automerge.document import MapReadProxy as _MapReadProxy
from automerge.repo import DocHandle, Repo
from base58 import b58decode_check, b58encode_check

from ._normalize import to_plain_mapping

if TYPE_CHECKING:
    from .document import Document


def _get_core_document(repo: Repo, handle: DocHandle) -> _core.Document:
    """Resolve a core document object from repo internals.

    Args:
        repo: Repository instance.
        handle: Document handle.

    Returns:
        Core automerge document.

    Raises:
        RuntimeError: If the actor is unavailable.
    """
    actor = repo._doc_actors.get(handle._actor_id)
    if actor is None:
        raise RuntimeError("Document actor not available.")
    return actor.get_document()


def encode_heads(raw: Sequence[bytes]) -> tuple[str, ...]:
    """Encode raw head bytes to bs58check strings.

    Args:
        raw: Raw head bytes from automerge core APIs.

    Returns:
        Encoded head strings.
    """
    return tuple(b58encode_check(h).decode("ascii") for h in raw)


def decode_heads(encoded: Sequence[str]) -> list[bytes]:
    """Decode bs58check head strings back to raw bytes.

    Args:
        encoded: Encoded head strings.

    Returns:
        Raw head byte arrays.
    """
    return [b58decode_check(h) for h in encoded]


def get_heads(repo: Repo, handle: DocHandle) -> tuple[str, ...]:
    """Return a document's current heads as encoded strings.

    Args:
        repo: Repository containing the document actor.
        handle: Document handle.

    Returns:
        Current encoded heads tuple.
    """
    return encode_heads(_get_core_document(repo, handle).get_heads())


def read_at_heads(repo: Repo, handle: DocHandle, heads: Sequence[str]) -> dict[str, Any]:
    """Read a plain-Python snapshot at specific heads.

    Args:
        repo: Repository containing the document actor.
        handle: Document handle.
        heads: Encoded heads identifying the snapshot.

    Returns:
        Plain mapping snapshot at the specified heads.
    """
    core_doc = _get_core_document(repo, handle)
    raw_heads = decode_heads(heads)
    proxy = _MapReadProxy(core_doc, _core.ROOT, raw_heads)
    return to_plain_mapping(proxy)


def watch_document_changes(
    document: Document,
    callback: Callable[[Document, tuple[str, ...], tuple[str, ...]], None | Awaitable[None]],
    interval: float = 0.1,
) -> asyncio.Task[None]:
    """Watch a document and invoke callback when heads change.

    This polls document heads and catches both local and remote updates,
    including changes synced from other processes.

    Args:
        document: Mutable latest document returned by ``RepoManager``.
        callback: Function called with updated heads on each change.
            Async callbacks are supported.
        interval: Polling interval in seconds.

    Returns:
        Background watcher task. Cancel it when done.

    Raises:
        RuntimeError: If ``document`` is a read-only snapshot.
        ValueError: If ``interval`` is not positive.
    """
    if interval <= 0:
        raise ValueError("interval must be positive.")
    if document._heads:
        raise RuntimeError("watch_document_changes requires a latest mutable document.")

    async def _watch() -> None:
        heads = get_heads(document._repo, document._handle)
        while True:
            await asyncio.sleep(interval)
            next_heads = get_heads(document._repo, document._handle)
            if next_heads == heads:
                continue
            prev_heads = heads
            heads = next_heads
            result = callback(document, prev_heads, heads)
            if isawaitable(result):
                await result

    return asyncio.create_task(_watch())
