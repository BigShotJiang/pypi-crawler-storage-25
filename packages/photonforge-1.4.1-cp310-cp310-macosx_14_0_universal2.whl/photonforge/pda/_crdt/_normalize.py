"""Automerge proxy to plain-Python normalization."""

from collections.abc import Mapping, Sequence
from typing import Any

from automerge.document import Text


def to_plain_mapping(document: Mapping[str, Any]) -> dict[str, Any]:
    """Convert nested automerge mapping proxies into plain Python values.

    Args:
        document: Mapping-like automerge document view.

    Returns:
        Plain-Python dictionary.
    """
    return {str(key): _to_plain_value(value) for key, value in document.items()}


def _to_plain_value(value: object) -> object:
    if isinstance(value, Text):
        return str(value)
    if isinstance(value, Mapping):
        return to_plain_mapping(value)
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        return [_to_plain_value(item) for item in value]
    return value
