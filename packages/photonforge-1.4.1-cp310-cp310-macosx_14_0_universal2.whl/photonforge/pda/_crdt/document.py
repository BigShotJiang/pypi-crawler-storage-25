from collections.abc import Mapping, Sequence

from automerge.repo import DocHandle, Repo

from ._normalize import to_plain_mapping
from .heads import get_heads, read_at_heads


class Document:
    """Per-document object returned by RepoManager.

    Wraps a DocHandle and exposes identity, heads, reading, snapshot
    reads, and mutation.  Schema-agnostic: stores whatever data the
    caller provides.
    """

    def __init__(self, repo: Repo, handle: DocHandle, heads: tuple[str, ...]) -> None:
        """Initialize a document wrapper.

        Args:
            repo: Owning repository instance.
            handle: Automerge document handle.
            heads: Optional read-only snapshot heads.
        """
        self._repo = repo
        self._handle = handle
        self._heads = heads

    @property
    def id(self) -> str:
        """Return the plain document identifier.

        Args:
            None.

        Returns:
            Document ID string.
        """
        return str(self._handle.document_id)

    @property
    def url(self) -> str:
        """Return the Automerge URL for this document.

        Args:
            None.

        Returns:
            Automerge URL string.
        """
        return str(self._handle.url)

    @property
    def heads(self) -> tuple[str, ...]:
        """Return encoded document heads.

        Args:
            None.

        Returns:
            Current heads, or fixed snapshot heads for read-only docs.
        """
        if self._heads:
            return self._heads
        return get_heads(self._repo, self._handle)

    @property
    def ref(self) -> str:
        """Return a reference URL including current heads.

        Args:
            None.

        Returns:
            Stringified document reference.
        """
        return self.url + "#" + ",".join(self.heads)

    @property
    def is_read_only(self) -> bool:
        """Return whether this wrapper is pinned to snapshot heads.

        Args:
            None.

        Returns:
            ``True`` for snapshot wrappers, ``False`` for mutable latest.
        """
        return len(self._heads) > 0

    def read(self) -> dict[str, object]:
        """Return a plain-Python copy of the document data.

        Args:
            None.

        Returns:
            Document mapping snapshot.
        """
        if self._heads:
            return read_at_heads(self._repo, self._handle, self._heads)
        raw = self._handle.doc()
        if isinstance(raw, Mapping):
            return to_plain_mapping(raw)
        raise TypeError("Expected a mapping from handle.doc().")

    def read_at(self, heads: Sequence[str]) -> dict[str, object]:
        """Return a plain-Python snapshot at the given heads.

        Args:
            heads: Encoded heads identifying the target snapshot.

        Returns:
            Document mapping snapshot.
        """
        return read_at_heads(self._repo, self._handle, heads)

    def change(self, updates: Mapping[str, object]) -> dict[str, object]:
        """Apply a top-level merge and return the updated data.

        Args:
            updates: Top-level key/value updates to merge.

        Returns:
            Updated document mapping snapshot.
        """
        if self._heads:
            raise RuntimeError("Read-only document does not support changes.")
        with self._handle.change() as doc:
            for key, value in updates.items():
                doc[key] = value
        return self.read()

    def read_only(self) -> "Document":
        """Return a snapshot wrapper pinned to current heads.

        Args:
            None.

        Returns:
            Read-only document wrapper.
        """
        return Document(self._repo, self._handle, self.heads)

    def latest(self) -> "Document":
        """Return a mutable wrapper tracking latest document state.

        Args:
            None.

        Returns:
            Mutable latest document wrapper.
        """
        return Document(self._repo, self._handle, ())
