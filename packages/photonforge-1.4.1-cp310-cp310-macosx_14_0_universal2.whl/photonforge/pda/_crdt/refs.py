from dataclasses import dataclass, field
from urllib.parse import quote, unquote

AUTOMERGE_URL_PREFIX = "automerge:"
AUTOMERGE_HEADS_PREFIX = "#"


@dataclass(frozen=True)
class AutomergeRef:
    """Parsed/constructed Automerge reference.

    Can be built from parts or parsed from a stringified ref.
    ``url`` and ``ref`` are derived automatically.
    """

    document_id: str
    heads: tuple[str, ...] = ()
    url: str = field(init=False)
    ref: str = field(init=False)

    def __post_init__(self) -> None:
        if not self.document_id:
            raise ValueError("document_id must not be empty.")
        if AUTOMERGE_HEADS_PREFIX in self.document_id:
            raise ValueError("document_id must not contain heads.")
        if any(not h for h in self.heads):
            raise ValueError("heads must not contain empty values.")

        object.__setattr__(self, "url", AUTOMERGE_URL_PREFIX + self.document_id)

        if self.heads:
            encoded = ",".join(quote(h, safe="") for h in self.heads)
            object.__setattr__(self, "ref", f"{self.url}{AUTOMERGE_HEADS_PREFIX}{encoded}")
        else:
            object.__setattr__(self, "ref", self.url)

    @classmethod
    def parse(cls, ref: str) -> "AutomergeRef":
        """Parse a stringified Automerge ref into an ``AutomergeRef``.

        Args:
            cls: Reference dataclass type.
            ref: Document ID, URL, or URL with heads.

        Returns:
            Parsed immutable reference object.
        """
        url_part, _, heads_text = ref.partition(AUTOMERGE_HEADS_PREFIX)
        document_id = url_part.removeprefix(AUTOMERGE_URL_PREFIX).removesuffix("/")
        heads = tuple(unquote(h) for h in heads_text.split(",") if h)
        return cls(document_id=document_id, heads=heads)

    @classmethod
    def parse_id(cls, ref: str) -> str:
        """Parse a stringified Automerge ref ad return the ID only.

        Args:
            cls: Reference dataclass type.
            ref: Document ID, URL, or URL with heads.

        Returns:
            Document ID.
        """
        return (
            ref.partition(AUTOMERGE_HEADS_PREFIX)[0]
            .removeprefix(AUTOMERGE_URL_PREFIX)
            .removesuffix("/")
        )
