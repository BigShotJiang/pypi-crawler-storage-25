from __future__ import annotations

import asyncio
from collections.abc import Mapping
from typing import Any, Protocol

from automerge.repo import InMemoryStorage, Repo, Storage

from .document import Document
from .refs import AutomergeRef


class Transport(Protocol):
    async def send(self, msg: bytes) -> None: ...
    async def recv(self) -> bytes: ...
    async def close(self) -> None: ...


class RepoManager:
    _FIND_TIMEOUT = 3.0
    _FIND_INITIAL_DELAY = 0.05
    _FIND_MAX_DELAY = 0.5
    _FIND_BACKOFF = 1.8
    _STOP_DRAIN_S = 1.0

    @classmethod
    async def create(cls, transport: Transport, storage: Storage | None = None) -> RepoManager:
        """Create, start, and connect a repository manager.

        Args:
            cls: Repo manager class.
            transport: Transport used for repo synchronization.
            storage: Optional automerge storage backend.

        Returns:
            Initialized repository manager instance.
        """
        if storage is None:
            storage = InMemoryStorage()
        repo = await Repo.load(storage)
        await repo.start()
        connect_task = asyncio.create_task(repo.connect(transport))
        return cls(repo, transport, connect_task)

    def __init__(self, repo: Repo, transport: Transport, connect_task: asyncio.Task) -> None:
        """Initialize a repo manager from existing runtime objects.

        Args:
            repo: Started automerge repository.
            transport: Active synchronization transport.
            connect_task: Background task driving repo connection.
        """
        self._repo = repo
        self._transport = transport
        self._connect_task = connect_task

    async def stop(self) -> None:
        """Stop transport, connection task, and repository.

        Args:
            None.

        Returns:
            ``None``.
        """
        # Outbound CRDT changes are queued inside the connect task's sync
        # loop. Cancelling immediately drops anything that hasn't been put
        # on the wire yet — fatal for script-style usage that calls
        # `change()` and then exits (e.g. tools/abstract_component_library).
        # Yield long enough for the sync loop to flush before tearing down.
        if self._connect_task is not None and not self._connect_task.done():
            await asyncio.sleep(self._STOP_DRAIN_S)

        if self._connect_task is not None:
            connect_task = self._connect_task
            self._connect_task = None
            connect_task.cancel()
            try:
                await connect_task
            except (asyncio.CancelledError, Exception):
                pass

        if self._transport is not None:
            await self._transport.close()
            self._transport = None

        if self._repo is not None:
            await self._repo.stop()
            self._repo = None

    async def create_document(self, initial: Mapping[str, Any] | None = None) -> Document:
        """Create a new document with the given initial data.

        Args:
            initial: Optional initial mapping written to the document.

        Returns:
            Mutable document wrapper.
        """
        if self._repo is None:
            raise RuntimeError("RepoManager already stopped.")

        handle = await self._repo.create()
        document = Document(self._repo, handle, ())
        if initial is not None:
            document.change(initial)
        return document

    async def find_document(self, ref: str, check: bool = True) -> Document | None:
        """Find a document by document ID, URL, or stringified ref.

        Args:
            ref: Document ID, Automerge URL, or full reference string.
            check: Whether to wait briefly for synchronization.

        Returns:
            Matching document wrapper, or ``None`` when ``check`` is
            ``False`` and no document is immediately available.
        """
        if self._repo is None:
            raise RuntimeError("RepoManager already stopped.")

        am_ref = AutomergeRef.parse(ref)
        loop = asyncio.get_running_loop()
        deadline = loop.time() + self._FIND_TIMEOUT
        delay = self._FIND_INITIAL_DELAY

        async def _find_within_deadline() -> object | None:
            # ``_repo.find`` blocks until the handle reaches a terminal state.
            # If a peer (e.g. sync-server) accepts our request but never
            # delivers data, the call hangs forever. Bound it to the remaining
            # deadline so callers fail with a clear timeout instead.
            remaining = deadline - loop.time()
            if remaining <= 0:
                return None
            try:
                return await asyncio.wait_for(self._repo.find(am_ref.url), timeout=remaining)
            except asyncio.TimeoutError:
                return None

        handle = await _find_within_deadline()
        if handle is not None:
            return Document(self._repo, handle, am_ref.heads)

        while check and handle is None:
            if self._connect_task.done():
                try:
                    reason = self._connect_task.result()
                except Exception as exc:
                    raise RuntimeError("Repository connection failed.") from exc
                raise RuntimeError(f"Repository connection closed before sync ({reason}).")

            handle = await _find_within_deadline()
            if handle is not None:
                return Document(self._repo, handle, am_ref.heads)

            remaining = deadline - loop.time()
            if remaining <= 0:
                raise RuntimeError(
                    f"Document not found in repository after waiting {self._FIND_TIMEOUT:.1f}s."
                )

            await asyncio.sleep(min(delay, remaining))
            delay = min(delay * self._FIND_BACKOFF, self._FIND_MAX_DELAY)

        return None
