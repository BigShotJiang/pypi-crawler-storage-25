# `photonforge._crdt.core`

Thin schema-agnostic CRDT runtime helpers for PhotonForge.

This layer wraps the small part of `automerge-py` that PhotonForge currently
needs on the backend:

- repo lifecycle
- document creation and lookup with arbitrary data
- normalized document reads and snapshot reads at specific heads
- top-level document updates
- polling-based document change watcher (local + remote sync)
- stringified Automerge refs
- heads capture and bs58check encoding

## Module Layout

| Module | Purpose |
|---|---|
| `refs.py` | `AutomergeRef` dataclass for Automerge URLs and stringified refs |
| `heads.py` | Heads capture, encoding, snapshot reads, and polling change watcher |
| `document.py` | `Document` wrapper returned by `RepoManager` |
| `repo_manager.py` | Repo lifecycle and document factory |
| `_normalize.py` | Automerge proxy to plain-Python normalization |

## Exports

`photonforge._crdt.core` exports:

- `AutomergeRef`
- `Document`
- `RepoManager`
- `encode_heads()`
- `decode_heads()`

## `Document`

`Document` is the primary per-document interface. `RepoManager.create()`
and `find()` return `Document` instances.

```python
doc = await manager.create({"name": "component", "owner": "user-1"})

doc.id      # plain string document ID
doc.url     # "automerge:<id>"
doc.heads   # tuple of bs58check strings (current heads)

doc.read()                # plain-Python dict of current data
doc.read_at(old_heads)    # snapshot at specific heads
doc.change({"status": "released"})  # mutate and return updated data
```

Documents are schema-agnostic. The core layer stores whatever data the
caller provides and does not enforce any specific fields.

### Heads

`doc.heads` returns the document's current heads as a tuple of bs58check-encoded
strings. This encoding matches the frontend's `DocHandle.heads()` format
(`UrlHeads`), so heads can be stored in JSON payloads and passed between
frontend and backend without conversion.

`doc.read_at(heads)` reads the document at a specific point in history. Use
this to reconstruct the exact state that was submitted for simulation.

Heads access uses private `automerge-py` internals (`repo._doc_actors`,
`handle._actor_id`, `actor.get_document()`). All private access is isolated
in `heads.py`. When upstream `automerge-py` adds `DocHandle.heads()` and
`DocHandle.view(heads)`, only `heads.py` needs to change.

### Standalone Encoding Helpers

`encode_heads()` and `decode_heads()` convert between raw `list[bytes]` (as
returned by `automerge.core.Document.get_heads()`) and `tuple[str, ...]` /
`list[bytes]` (bs58check strings). These are useful at API boundaries.

## `AutomergeRef`

`AutomergeRef` is a frozen dataclass that handles both construction and parsing
of Automerge URLs and stringified refs.

Formats:

- document URL: `automerge:<documentId>`
- document ref with heads: `automerge:<documentId>#head1,head2`

```python
from photonforge._crdt.core import AutomergeRef

r = AutomergeRef(document_id="kBV67dgr2ktyP3JnQuEb2ygDyT7", heads=("h1", "h2"))
r.url   # "automerge:kBV67dgr2ktyP3JnQuEb2ygDyT7"
r.ref   # "automerge:kBV67dgr2ktyP3JnQuEb2ygDyT7#h1,h2"

parsed = AutomergeRef.parse("automerge:kBV67dgr2ktyP3JnQuEb2ygDyT7#head-1,head%2F2")
parsed.document_id  # "kBV67dgr2ktyP3JnQuEb2ygDyT7"
parsed.heads        # ("head-1", "head/2")
```

Notes:

- `AutomergeRef.parse()` requires an `automerge:` prefix
- heads are percent-encoded when needed

## Change Watch Helper

`watch_document_changes()` in `heads.py` provides a polling watcher that detects
head changes for a mutable `Document`. This catches both local changes and
remote sync updates.

```python
from photonforge.pda.crdt.heads import watch_document_changes

def on_change(heads: tuple[str, ...]) -> None:
    print("heads changed:", heads)

task = watch_document_changes(doc, on_change, interval=0.1)
```

Notes:

- callback receives the updated heads tuple
- async callbacks are supported
- watcher requires a latest/mutable document (not a read-only heads snapshot)

## `RepoManager`

`RepoManager` manages a single Automerge repo instance. It is the factory for
`Document` instances.

### Lifecycle

```python
from automerge.repo import InMemoryStorage

from photonforge._crdt.core import RepoManager

manager = RepoManager(storage=InMemoryStorage())
await manager.start()

try:
    ...
finally:
    await manager.stop()
```

Behavior:

- `start()` loads a repo if needed and starts it
- `stop()` is safe to call more than once
- a manager created with `storage=...` owns the loaded repo instance
- a manager created with `repo=...` uses an external repo instance

### Create, Read, Change, Find

```python
from automerge.repo import InMemoryStorage

from photonforge._crdt.core import AutomergeRef, RepoManager

manager = RepoManager(storage=InMemoryStorage())
await manager.start()

doc = await manager.create({"name": "component", "kind": "waveguide"})

doc.id                  # plain string document ID
data = doc.read()       # plain-Python dict

updated = doc.change({"name": "updated", "status": "released"})

found = await manager.find(AutomergeRef(doc.id, ("ignored-head",)).ref)

assert found is not None
assert found.read() == updated

await manager.stop()
```

### API Notes

| Method | Purpose |
|---|---|
| `start()` | Load and start the underlying repo |
| `stop()` | Stop the underlying repo |
| `create(initial)` | Create a `Document` with arbitrary initial data |
| `find(ref)` | Resolve a document ID, Automerge URL, or stringified ref to a `Document` |

## Important Runtime Details

These details matter when building on top of the wrapper:

- `repo.create(initial)` does not seed initial data in the installed
  `automerge-py` build, so `create()` creates an empty doc and then
  writes the initial data in a change block
- `repo.find()` expects an Automerge URL, so `find()` normalizes
  document IDs and refs through `make_automerge_url()`
- `handle.doc()` returns Automerge proxy objects, not plain Python values
- Automerge text values are normalized back to plain Python strings on read
- `doc.change()` currently performs a top-level merge, not an arbitrary
  callback mutation API
