"""Shared schema primitives used by PDA parametric/schema tooling.

This module defines small root models and matrix helpers that map
between Python values and the JSON-schema shapes expected by PDA.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import ClassVar, Literal
from warnings import warn

import numpy as np
from pydantic import BaseModel, ConfigDict, Field, PositiveInt, RootModel


def fix_refs(j: dict[str, object] | list[object]) -> None:
    """Rewrite local ``$ref`` values to canonical hosted schema URLs.

    Args:
        j: JSON-like schema object to rewrite in-place.
    """
    if isinstance(j, list):
        for i in range(len(j)):
            fix_refs(j[i])

    if isinstance(j, dict):
        if "$ref" in j:
            s = j["$ref"]
            if "flexcompute" not in s:
                cls = globals()[s[s.rfind("/") + 1 :]]
                j["$ref"] = cls.ref_schema()
        for k in j:
            fix_refs(j[k])


def fix_fields(j: dict[str, object]) -> None:
    """Normalize generated Pydantic schema fields for PDA consumers.

    Args:
        j: JSON schema object to normalize in-place.
    """
    j.pop("title", None)

    j.pop("$defs", None)

    if "prefixItems" in j:
        j["items"] = j["prefixItems"]
        del j["prefixItems"]

    jp = j.get("properties")
    if jp:
        j["additionalProperties"] = False
        for k in jp:
            fix_fields(jp[k])


class AbstractBase(BaseModel):
    """Base class for schema wrappers with Python conversion helpers."""

    _version: ClassVar[str] = "1.0.0"

    @classmethod
    def ref_schema(cls) -> str:
        """Return the canonical hosted schema reference URL for the class.

        Args:
            cls: Schema wrapper class.

        Returns:
            Canonical schema URL.
        """
        return f"https://flexcompute.com/schemas/{cls._version}/{cls.__name__}.json"

    @classmethod
    def fixed_json_schema(cls, *args: object, **kwargs: object) -> dict[str, object]:
        """Return schema with PDA-compatible field and reference fixes.

        Args:
            *args: Positional arguments forwarded to Pydantic schema
              generation.
            **kwargs: Keyword arguments forwarded to Pydantic schema
              generation.

        Returns:
            Normalized JSON schema object.
        """
        j = cls.model_json_schema(*args, **kwargs)
        fix_fields(j)
        fix_refs(j)
        return j

    @classmethod
    def from_json(cls, obj: object) -> AbstractBase:
        """Validate and build the wrapper model from JSON-compatible data.

        Args:
            obj: JSON-compatible serialized value.

        Returns:
            Parsed wrapper instance.
        """
        return cls.model_validate(obj)

    @classmethod
    def from_python(cls, obj: object) -> AbstractBase:
        """Build the wrapper model from a Python value.

        Args:
            obj: Python value to wrap.

        Returns:
            Wrapper instance.
        """
        return cls(obj)

    @property
    def to_python(self) -> object:
        """Return the wrapped Python value.

        Args:
            None.

        Returns:
            Python representation for the schema wrapper.
        """
        return self.root


def remove_default(j: dict[str, object]) -> None:
    """Strip Pydantic-inserted defaults from generated schema fields.

    Args:
        j: Field schema object to mutate.
    """
    j.pop("default", None)


class Null(AbstractBase, RootModel):
    root: None = Field(None, json_schema_extra=remove_default)


class Integer(AbstractBase, RootModel):
    root: int


class NegativeInteger(AbstractBase, RootModel):
    root: int = Field(..., lt=0)


class PositiveInteger(AbstractBase, RootModel):
    root: int = Field(..., gt=0)


class NonPositiveInteger(AbstractBase, RootModel):
    root: int = Field(..., le=0)


class NonNegativeInteger(AbstractBase, RootModel):
    root: int = Field(..., ge=0)


class Float64(AbstractBase, RootModel):
    root: float


class NegativeFloat64(AbstractBase, RootModel):
    root: float = Field(..., lt=0)


class PositiveFloat64(AbstractBase, RootModel):
    root: float = Field(..., gt=0)


class NonPositiveFloat64(AbstractBase, RootModel):
    root: float = Field(..., le=0)


class NonNegativeFloat64(AbstractBase, RootModel):
    root: float = Field(..., ge=0)


class UnitIntervalFloat64(AbstractBase, RootModel):
    root: float = Field(..., ge=0, le=1)


class UnitBallIntervalFloat64(AbstractBase, RootModel):
    root: float = Field(..., ge=-1, le=1)


class CenteredUnitIntervalFloat64(AbstractBase, RootModel):
    root: float = Field(..., ge=-0.5, le=0.5)


class ComplexNumberJson(AbstractBase, RootModel):
    root: tuple[float, float]

    @classmethod
    def from_python(cls, obj: object) -> ComplexNumberJson:
        """Convert a Python complex-like value into a JSON tuple wrapper.

        Args:
            cls: Complex wrapper class.
            obj: Complex-coercible value.

        Returns:
            Wrapped ``(real, imag)`` tuple model.
        """
        z = complex(obj)
        return cls([z.real, z.imag])

    @property
    def to_python(self) -> complex:
        """Convert the wrapped tuple into a Python complex number.

        Args:
            None.

        Returns:
            Complex value.
        """
        return self.root[0] + 1j * self.root[1]


def fix_shape(j: dict[str, object]) -> None:
    """Normalize matrix shape schema entries for PDA compatibility.

    Args:
        j: Shape schema object to mutate.
    """
    j.pop("maxItems", None)
    j.pop("minItems", None)
    items = j["prefixItems"]
    for i in range(len(items)):
        if items[i].get("exclusiveMinimum") == 0:
            items[i]["minimum"] = 1
            del items[i]["exclusiveMinimum"]


MatrixScalar = (
    float
    | CenteredUnitIntervalFloat64
    | Float64
    | NegativeFloat64
    | NegativeInteger
    | NonNegativeFloat64
    | NonPositiveFloat64
    | PositiveFloat64
    | UnitBallIntervalFloat64
    | UnitIntervalFloat64
    | Integer
    | NonNegativeInteger
    | NonPositiveInteger
    | PositiveInteger
)


class AbstractMatrix(AbstractBase):
    """Flattened matrix payload with Fortran-order conversion helpers."""

    data: list[MatrixScalar] = Field(min_length=1)

    @classmethod
    def from_python(cls, obj: object) -> AbstractMatrix:
        """Convert array-like input into flattened matrix payload.

        Args:
            cls: Matrix wrapper class.
            obj: Array-like matrix input.

        Returns:
            Wrapper model with flattened data and shape.
        """
        array = np.array(obj)
        return cls(data=array.flatten(order="F").tolist(), shape=array.shape)

    @property
    def to_python(self) -> np.ndarray:
        """Convert flattened payload into a NumPy array.

        Args:
            None.

        Returns:
            Reconstructed matrix array.
        """
        return np.array(self.data).reshape(self.shape, order="F")


class BaseMatrix2D(AbstractMatrix):
    shape: tuple[PositiveInt, PositiveInt] = Field(json_schema_extra=fix_shape)


class BaseMatrix3D(AbstractMatrix):
    shape: tuple[PositiveInt, PositiveInt, PositiveInt] = Field(json_schema_extra=fix_shape)


class BaseMatrix4D(AbstractMatrix):
    shape: tuple[PositiveInt, PositiveInt, PositiveInt, PositiveInt] = Field(
        json_schema_extra=fix_shape
    )


class BaseMatrix5D(AbstractMatrix):
    shape: tuple[PositiveInt, PositiveInt, PositiveInt, PositiveInt, PositiveInt] = Field(
        json_schema_extra=fix_shape
    )


BaseMatrices = (BaseMatrix2D, BaseMatrix3D, BaseMatrix4D, BaseMatrix5D)


def complex_matrix_from_base(j: dict[str, object]) -> None:
    """Build complex-matrix schema from base matrix schema fragments.

    Args:
        j: Generated schema object to rewrite in-place.
    """
    shape = j["properties"]["shape"]
    shape["items"] = shape["prefixItems"]
    del shape["prefixItems"]
    del shape["title"]
    base = BaseMatrices[len(shape["items"]) - 2]
    j.clear()
    j["allOf"] = [
        {"$ref": base.ref_schema()},
        {
            "type": "object",
            "properties": {"shape": shape},
            "required": ["shape"],
            "additionalProperties": False,
        },
    ]


class AbstractComplexMatrix(AbstractBase):
    """Flattened complex matrix payload encoded as real/imag channels."""

    data: list[float] = Field(min_length=1)

    model_config = ConfigDict(json_schema_extra=complex_matrix_from_base)

    @classmethod
    def from_python(cls, obj: object) -> AbstractComplexMatrix:
        """Convert complex array-like input into real/imag payload format.

        Args:
            cls: Complex matrix wrapper class.
            obj: Complex array-like input.

        Returns:
            Wrapper model with channel-stacked flattened data.
        """
        array = np.array(obj, dtype=complex)
        array = np.stack((array.real, array.imag), axis=0)
        return cls(data=array.flatten(order="F").tolist(), shape=array.shape)

    @property
    def to_python(self) -> np.ndarray:
        """Convert channel-stacked payload into a complex NumPy array.

        Args:
            None.

        Returns:
            Reconstructed complex array.
        """
        array = np.array(self.data).reshape(self.shape, order="F")
        return array[0] + 1j * array[1]


class Matrix2DComplexNumber(AbstractComplexMatrix):
    shape: tuple[PositiveInt, PositiveInt, Literal[2.0]] = Field(json_schema_extra=fix_shape)


class Matrix3DComplexNumber(AbstractComplexMatrix):
    shape: tuple[PositiveInt, PositiveInt, PositiveInt, Literal[2.0]] = Field(
        json_schema_extra=fix_shape
    )


class Matrix4DComplexNumber(AbstractComplexMatrix):
    shape: tuple[PositiveInt, PositiveInt, PositiveInt, PositiveInt, Literal[2.0]] = Field(
        json_schema_extra=fix_shape
    )


ComplexMatrices = (Matrix2DComplexNumber, Matrix3DComplexNumber, Matrix4DComplexNumber)


class Matrix3Json(AbstractBase, RootModel):
    root: tuple[float, float, float, float, float, float, float, float, float]

    @classmethod
    def from_python(cls, obj: object) -> Matrix3Json:
        """Convert a 3x3 array-like value into flattened matrix wrapper.

        Args:
            cls: 3x3 matrix wrapper class.
            obj: Array-like 3x3 matrix input.

        Returns:
            Wrapped flattened 3x3 matrix.
        """
        array = np.array(obj, dtype=float)
        return cls(array.flatten(order="F").tolist())

    @property
    def to_python(self) -> np.ndarray:
        """Convert flattened 3x3 payload into a NumPy matrix.

        Args:
            None.

        Returns:
            Reconstructed 3x3 matrix.
        """
        return np.array(self.root).reshape((3, 3), order="F")


class Matrix3x2AffineJson(AbstractBase, RootModel):
    root: tuple[float, float, float, float, float, float]

    @classmethod
    def from_python(cls, obj: object) -> Matrix3x2AffineJson:
        """Convert a 2x3 array-like value into flattened matrix wrapper.

        Args:
            cls: 2x3 matrix wrapper class.
            obj: Array-like 2x3 matrix input.

        Returns:
            Wrapped flattened 2x3 matrix.
        """
        array = np.array(obj, dtype=float)
        return cls(array.flatten(order="F").tolist())

    @property
    def to_python(self) -> np.ndarray:
        """Convert flattened 3x3 payload into a NumPy matrix.

        Args:
            None.

        Returns:
            Reconstructed 3x3 matrix.
        """
        return np.array(self.root).reshape((2, 3), order="F")

    @classmethod
    def from_kwargs(cls, origin: np.ndarray, rotation: float, scaling: float, x_reflection: bool):
        """Construct a transform matrix from UI transform parameters.

        Args:
            origin: Translation vector in layout coordinates.
            rotation: Rotation angle in degrees.
            scaling: Uniform scale factor.
            x_reflection: Whether to reflect across the x axis.

        Returns:
            Affine transform wrapper.
        """
        angle = rotation * np.pi / 180.0
        sin = np.sin(angle)
        cos = np.cos(angle)
        scale_y = -scaling if x_reflection else scaling
        return cls.from_python(
            [
                [scaling * cos, -scale_y * sin, origin[0]],
                [scaling * sin, scale_y * cos, origin[1]],
            ]
        )

    def to_kwargs(self) -> dict[str, object]:
        """Decode matrix values into UI transform parameters.

        Args:
            None.

        Returns:
            Mapping with ``origin``, ``rotation``, ``scaling``, and
            ``x_reflection`` values.
        """
        t = self.to_python
        angle = np.arctan2(t[1, 0], t[0, 0])
        scaling = (t[0, 0] ** 2 + t[1, 0] ** 2) ** 0.5
        if abs(scaling - 1.0) < 1e-12:
            scaling = 1.0
        reflection = bool(t[0, 0] * t[1, 1] - t[0, 1] * t[1, 0] < 0)
        kwargs = {
            "origin": t[:, 2],
            "rotation": angle / np.pi * 180,
            "scaling": scaling,
            "x_reflection": reflection,
        }
        expected = Matrix3x2AffineJson.from_kwargs(**kwargs).to_python
        if np.abs(t - expected).max() > 1e-12:
            warn(
                f"Invalid affine transform. Found {t.tolist()}, expected {expected.tolist()}",
                RuntimeWarning,
                3,
            )
        return kwargs


schema_lib = {}
for cls in (
    Null,
    Integer,
    NegativeInteger,
    PositiveInteger,
    NonPositiveInteger,
    NonNegativeInteger,
    Float64,
    NegativeFloat64,
    PositiveFloat64,
    NonPositiveFloat64,
    NonNegativeFloat64,
    UnitIntervalFloat64,
    UnitBallIntervalFloat64,
    CenteredUnitIntervalFloat64,
    ComplexNumberJson,
    BaseMatrix2D,
    BaseMatrix3D,
    BaseMatrix4D,
    BaseMatrix5D,
    Matrix2DComplexNumber,
    Matrix3DComplexNumber,
    Matrix4DComplexNumber,
    Matrix3Json,
    Matrix3x2AffineJson,
):
    schema_lib[cls.__name__] = (cls, cls.fixed_json_schema(), cls.ref_schema())


if __name__ == "__main__":
    import sys

    def cleanup(j: dict[str, object] | list[object]) -> None:
        if isinstance(j, list):
            for i in range(len(j)):
                cleanup(j[i])

        if isinstance(j, dict):
            if j.get("minimum") == -9007199254740991:
                del j["minimum"]
            if j.get("maximum") == 9007199254740991:
                del j["maximum"]

            for k in j:
                cleanup(j[k])

    def print_diff(a: object, b: object, prefix: str = "-") -> None:
        if a == b:
            return
        if type(a) is not type(b):
            print(f"{prefix} type mismatch: {type(a)!r} != {type(b)!r}")
        elif isinstance(a, dict):
            for k in b:
                if k not in a:
                    print(f"{prefix} {k!r} missing in first dictionary")
            for k in a:
                if k not in b:
                    print(f"{prefix} {k!r} missing in second dictionary")
            for k in a:
                if k in b:
                    print_diff(a[k], b[k], f"{prefix}[{k!r}]")
        elif isinstance(a, (list, tuple)):
            if len(a) != len(b):
                print(f"{prefix} different lengths: {len(a)} != {len(b)}")
            for i in range(min(len(a), len(b))):
                print_diff(a[i], b[i], f"{prefix}[{i}]")
        else:
            print(f"{prefix} difference: {a!r} != {b!r}")

    schema_path = Path(sys.argv[1]).expanduser()

    # Not used in photonforge
    skipped = {
        "AlphaString",
        "AlphanumericString",
        "Base58UuidV4",
        "ISO8601DateTime",
        "LowercaseAlphaString",
        "Matrix2BasicTransform",
        "Matrix2DFloat64",
        "Matrix2DPositiveInteger",
        "Matrix2Json",
        "Matrix2RowMajorJson",
        "Matrix3DFloat64",
        "Matrix3DPositiveInteger",
        "Matrix3RowMajorJson",
        "Matrix4Json",
        "Matrix4RowMajorJson",
        "Matrix4x3AffineJson",
        "NonEmptyString",
        "NonNegativeVector3Json",
        "NonNullQuaternionJson",
        "NonNullVector2Json",
        "NonNullVector3Json",
        "NonNullVector4Json",
        "PositiveVector3Json",
        "PropertyCompositionSchema",
        "QuaternionJson",
        "RegExpPattern",
        "SemanticVersion",
        "SemanticVersionSpec",
        "Sha256",
        "TrimmedString",
        "UnitQuaternionJson",
        "UnitVector2Json",
        "UnitVector3Json",
        "UnitVector4Json",
        "UnitsDSL",
        "UnknownJsonArray",
        "UnknownJsonObject",
        "UnknownJsonValue",
        "UppercaseAlphaString",
        "UuidV4",
        "UuidV5",
        "Vector2Json",
        "Vector3Json",
        "Vector4Json",
    }

    frontend_lib = {}

    schema = json.loads((schema_path / "schemas-index.json").read_text())
    index = {v["$ref"]: k for k, v in schema["schemas"].items() if k not in skipped}

    for f in schema_path.glob("**/*.json"):
        schema = json.loads(f.read_text())

        if f.name in ("primitive-schemas-lookup.json", "ref-import-map.json", "schemas-index.json"):
            continue

        ref = schema.pop("$id")
        if not isinstance(ref, str) or ref not in index:
            continue

        brand = index[ref]

        # Unused for matching
        schema.pop("$schema")
        cleanup(schema)

        frontend_lib[brand] = schema

    print_diff(sorted(index.values()), sorted(frontend_lib))

    for key, schema in frontend_lib.items():
        if key not in schema_lib:
            print(f"Missing {key}")
            continue

        if schema_lib[key][1] != schema:
            print(f"Schema error in {key}:")
            print("- Zod:", json.dumps(schema, indent=2, ensure_ascii=False))
            print("- Lib:", json.dumps(schema_lib[key][1], indent=2, ensure_ascii=False))
            print_diff(schema, schema_lib[key][1])
