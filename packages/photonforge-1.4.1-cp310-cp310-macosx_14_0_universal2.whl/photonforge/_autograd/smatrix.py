from __future__ import annotations

from collections.abc import Sequence
from typing import TYPE_CHECKING

import autograd.numpy as np
from ..utils import C_0

if TYPE_CHECKING:
    from ..extension import FiberPort, GaussianPort, Port


class AutogradSMatrix(dict):
    """Dictionary-backed S-matrix container compatible with autograd values."""

    def __init__(
        self,
        frequencies: Sequence[float],
        ports: dict[str, Port | FiberPort | GaussianPort | None],
    ):
        super().__init__()
        self.frequencies = np.array(frequencies, dtype=float, copy=True)
        self.ports = dict(ports)

    @property
    def elements(self) -> "AutogradSMatrix":
        """Mirror the native `SMatrix.elements` accessor."""

        return self

    @property
    def wavelengths(self) -> np.ndarray:
        """Return wavelengths corresponding to stored frequencies."""

        return C_0 / self.frequencies

    def copy(self) -> "AutogradSMatrix":
        """Return a deep-ish copy preserving ndarray payloads."""

        copied = AutogradSMatrix(self.frequencies.copy(), self.ports.copy())
        copied.update({k: np.array(v, copy=True) for k, v in self.items()})
        return copied
