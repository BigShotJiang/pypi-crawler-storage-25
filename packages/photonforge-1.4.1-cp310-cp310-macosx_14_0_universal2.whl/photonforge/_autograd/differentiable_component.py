from __future__ import annotations

from collections.abc import Callable, Sequence
import functools
from typing import Any

import autograd.numpy as np
from autograd.tracer import getval, isbox

from tidy3d.components.autograd import hasbox

from ..extension import frequency_classification
from .param_codec import _build_flatten_metadata, _call_create_fn, _flatten_diff_params
from .smatrix import AutogradSMatrix
from .types import (
    CreateFn,
    ParamSpec,
    ComponentType,
    TracedParamList,
)


def _validate_no_nested_tracers(args: tuple[Any, ...], kwargs: dict[str, Any]) -> None:
    """Reject nested traced containers that the parameter codec does not support."""

    for arg_idx, arg in enumerate(args):
        if (not isbox(arg)) and hasbox(arg):
            raise TypeError(
                f"Unsupported nested traced container in positional argument {arg_idx}. "
                "Differentiable parameters must be directly traced scalars or arrays."
            )

    for key, value in kwargs.items():
        if (not isbox(value)) and hasbox(value):
            raise TypeError(
                f"Unsupported nested traced container in keyword argument '{key}'. "
                "Differentiable parameters must be directly traced scalars or arrays."
            )


def _model_name_from_identity(component: ComponentType, model: Any) -> str:
    """Resolve the model-name key for a model object by identity."""

    for model_name, candidate in component.models.items():
        if candidate is model:
            return model_name
    raise RuntimeError(
        "Active model selection returned a model that is not present in component.models."
    )


def _select_active_component_model(
    component: ComponentType, classification: str
) -> tuple[str, Any]:
    """Select the active model for a frequency classification."""

    model = component.select_active_model(classification)
    if model is None:
        raise TypeError(
            "Autograd requires an active model for the selected frequency classification. "
            f"Found no active '{classification}' model."
        )
    return _model_name_from_identity(component, model), model


class AutogradParametricComponent:
    """Thin wrapper that routes `s_matrix` through model-level autograd hooks."""

    def __init__(
        self,
        component: ComponentType,
        create_fn: CreateFn,
        param_spec: ParamSpec,
        diff_params: TracedParamList,
        diff_param_sizes: tuple[int, ...],
    ) -> None:
        self.component = component
        self._create_fn = create_fn
        self._param_spec = param_spec
        self._diff_params = diff_params
        self._diff_param_sizes = diff_param_sizes

    def s_matrix(
        self,
        frequencies: Sequence[float],
        show_progress: bool = True,
        model_kwargs: dict[str, Any] | None = None,
    ) -> AutogradSMatrix:
        """Evaluate an autograd-compatible S-matrix for the wrapped component."""

        if self._diff_params:
            traced_params = _flatten_diff_params(self._diff_params, self._diff_param_sizes)
        else:
            traced_params = np.array([])

        def recreate_component(params: np.ndarray) -> ComponentType:
            return _call_create_fn(self._create_fn, params, self._param_spec)

        classification = frequency_classification(frequencies)
        nominal_model_name, model = _select_active_component_model(self.component, classification)

        nominal_model_type = type(model)

        def model_for_params(params: np.ndarray) -> tuple[ComponentType, Any]:
            component = recreate_component(params)
            selected_model_name, selected_model = _select_active_component_model(
                component, classification
            )
            if selected_model_name != nominal_model_name:
                raise TypeError(
                    "Autograd model selection changed during parameter sweep. "
                    f"Expected active model '{nominal_model_name}', got '{selected_model_name}'. "
                    "Do not change active model assignment or model names as a function of "
                    "traced parameters."
                )
            if type(selected_model) is not nominal_model_type:
                raise TypeError(
                    "Autograd model type changed during parameter sweep. "
                    f"Expected {nominal_model_type.__name__}, got "
                    f"{type(selected_model).__name__}."
                )
            return component, selected_model

        return model.autograd_smatrix(
            component=self.component,
            traced_params=traced_params,
            frequencies=frequencies,
            show_progress=show_progress,
            model_kwargs=model_kwargs,
            model_for_params=model_for_params,
        )

    def __getattr__(self, name: str) -> Any:
        """Delegate unknown attributes to the wrapped component instance."""

        return getattr(self.component, name)


def differentiable_component(
    create_fn: CreateFn,
) -> Callable[..., AutogradParametricComponent]:
    """Wrap a component factory so it returns an `AutogradParametricComponent`."""

    @functools.wraps(create_fn)
    def wrapper(*args: Any, **kwargs: Any) -> AutogradParametricComponent:
        _validate_no_nested_tracers(args, kwargs)
        strip_args = [getval(arg) for arg in args]
        strip_kwargs = {key: getval(val) for key, val in kwargs.items()}

        sorted_kwarg_keys = sorted(kwargs.keys())
        sorted_kwarg_vals = [kwargs[key] for key in sorted_kwarg_keys]

        all_params = list(args) + list(sorted_kwarg_vals)

        param_assembly_key = [isbox(p) for p in all_params]
        diff_params = [p for p in all_params if isbox(p)]
        non_diff_params = [p for p in all_params if (not isbox(p))]

        diff_param_shapes, diff_param_sizes = _build_flatten_metadata(
            [getval(p) for p in diff_params]
        )

        param_spec = ParamSpec(
            arg_length=len(args),
            kwarg_keys=tuple(sorted_kwarg_keys),
            non_diff_params=tuple(non_diff_params),
            param_assembly_key=tuple(param_assembly_key),
            diff_param_shapes=diff_param_shapes,
            diff_param_sizes=diff_param_sizes,
        )
        component = create_fn(*strip_args, **strip_kwargs)

        return AutogradParametricComponent(
            component,
            create_fn,
            param_spec,
            diff_params,
            diff_param_sizes,
        )

    return wrapper
