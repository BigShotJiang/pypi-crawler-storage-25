from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from autograd.tracer import Box as TracedParam

from ..extension import Component as ComponentType

TracedParamList = list[TracedParam]
CreateFn = Callable[..., ComponentType]


@dataclass(frozen=True, slots=True)
class ParamSpec:
    """Reconstruction recipe for create-fn arguments after flattening."""

    arg_length: int
    kwarg_keys: tuple[str, ...]
    non_diff_params: tuple[Any, ...]
    param_assembly_key: tuple[bool, ...]
    diff_param_shapes: tuple[tuple[int, ...], ...]
    diff_param_sizes: tuple[int, ...]
