from __future__ import annotations

from collections.abc import Callable, Sequence
from typing import TYPE_CHECKING

import autograd.numpy as np
from autograd.tracer import getval

from .types import ParamSpec, TracedParam

if TYPE_CHECKING:
    from ..extension import Component


def _build_flatten_metadata(
    diff_params_stripped: Sequence[float | np.ndarray],
) -> tuple[tuple[tuple[int, ...], ...], tuple[int, ...]]:
    """Build flatten/unflatten metadata for differentiable parameters."""

    shapes = []
    sizes = []

    for param_val in diff_params_stripped:
        shape = np.shape(param_val)
        size = int(np.prod(shape)) if shape != () else 1
        shapes.append(shape)
        sizes.append(size)

    return tuple(shapes), tuple(sizes)


def _flatten_diff_params(
    diff_params: Sequence[TracedParam], diff_param_sizes: Sequence[int]
) -> np.ndarray:
    """Flatten traced parameters into one contiguous 1D array."""

    flat_chunks = []

    if len(diff_params) != len(diff_param_sizes):
        raise ValueError("Metadata length mismatch when flattening differentiable parameters")
    for param, size in zip(diff_params, diff_param_sizes):
        flat_chunks.append(np.reshape(np.array(param), (size,)))

    if flat_chunks:
        flat_params = np.concatenate(flat_chunks)
    else:
        flat_params = np.array([])

    return flat_params


def _unflatten_diff_params(
    flat_params: Sequence[float] | np.ndarray,
    diff_param_shapes: Sequence[tuple[int, ...]],
    diff_param_sizes: Sequence[int],
) -> list[float | np.ndarray]:
    """Reconstruct original per-parameter values from a flat parameter vector."""

    params = []
    idx = 0
    flat_params = np.asarray(flat_params)

    if len(diff_param_shapes) != len(diff_param_sizes):
        raise ValueError("Shape/size metadata length mismatch when unflattening parameters")

    for shape, size in zip(diff_param_shapes, diff_param_sizes):
        next_idx = idx + size
        slice_vals = flat_params[idx:next_idx]
        if shape == ():
            # Reconstructed scalar arguments are concrete values used to rebuild
            # components for setup/probing steps.
            param = float(slice_vals.reshape(-1)[0]) if slice_vals.size else 0.0
        else:
            param = np.reshape(slice_vals, shape)
        params.append(param)
        idx = next_idx

    return params


def _call_create_fn(
    create_fn: Callable[..., Component],
    user_params: np.ndarray | TracedParam,
    param_spec: ParamSpec,
) -> Component:
    """Rebuild and call the original factory using mixed diff/non-diff params."""

    # This callback rebuilds components from concrete values (no tracers), so
    # we can evaluate perturbed parameter points in a stable way.
    diff_params_flat = np.array(getval(user_params), dtype=float)
    diff_params_list = _unflatten_diff_params(
        diff_params_flat, param_spec.diff_param_shapes, param_spec.diff_param_sizes
    )
    non_diff_params_val = param_spec.non_diff_params

    iter_diff_params = iter(diff_params_list)
    iter_non_diff_params = iter(non_diff_params_val)

    assemble_params = [
        next(iter_diff_params) if select else next(iter_non_diff_params)
        for select in param_spec.param_assembly_key
    ]

    arg_vals = assemble_params[0 : param_spec.arg_length]
    kwarg_vals = assemble_params[param_spec.arg_length :]

    kwargs = {}
    for idx, key in enumerate(param_spec.kwarg_keys):
        kwargs[key] = kwarg_vals[idx]

    # Gradient flow keeps traced values through _flatten_diff_params; this path
    # exists to recreate components from concrete parameter values.
    return create_fn(*arg_vals, **kwargs)
