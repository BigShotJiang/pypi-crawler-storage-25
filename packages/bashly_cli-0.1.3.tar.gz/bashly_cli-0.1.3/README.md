# Bashly

AI-powered cross-environment terminal assistant. Type your request in plain English — Bashly generates the right command for your target environment, lets you approve or deny it, and optionally runs it.

## Supported environments

| Environment | Can run locally? |
|---|---|
| Windows (PowerShell) | Yes |
| Windows (CMD) | Yes |
| Linux (bash) | Yes |
| macOS (zsh) | Yes |
| Android (Termux) | Copy only |
| MicroPython (ESP32 / Pi Pico) | Copy only |
| Arduino CLI | Copy only |
| Raspberry Pi (bash + GPIO) | Copy only |

## Setup

### 1. Get an OpenRouter API key

Go to [openrouter.ai](https://openrouter.ai), sign in, and create an API key.

### 2. Clone or download this project

```
git clone https://github.com/yourusername/bashly
cd bashly
```

### 3. Add your API key

Open `.env` and replace the placeholder:

```
OPENROUTER_API_KEY=your_actual_key_here
```

### 4. Install dependencies with uv

```
uv init
uv add openai rich python-dotenv pyperclip
```

Or with pip:

```
pip install -r requirements.txt
```

### 5. Run Bashly

```
uv run bashly.py
```

Or with Python directly:

```
python bashly.py
```

## Usage

On startup, Bashly asks you to pick a target environment. After that, just type naturally:

```
Bashly (Linux) > find all log files older than 7 days
Bashly (MicroPy) > blink the onboard LED every 500ms
Bashly (Win/PS) > list all running processes sorted by memory
```

### Commands

| Type this | Does this |
|---|---|
| `history` | Show last 10 commands |
| `clear history` | Delete all saved history |
| `switch env` | Change target environment without restarting |
| `exit` | Quit Bashly |

### Approve / deny options

For executable environments (Windows, Linux, macOS):

- `y` — run the command
- `n` — skip it
- `c` — copy to clipboard without running
- `?` — explain what the command does, then decide

For copy-only environments (MicroPython, Arduino, Termux, RPi):

- `y` — copy to clipboard
- `n` — skip it
- `?` — explain, then decide

## Project structure

```
bashly/
├── bashly.py         Main loop and UI
├── llm.py            LLM API calls (OpenRouter)
├── executor.py       Danger check and subprocess execution
├── history.py        Save and load command history
├── environments.py   All supported environments and their prompts
├── .env              Your API key (never commit this)
└── requirements.txt  Dependencies
```

## Safety

Bashly checks every command for dangerous patterns before showing it to you:

- **Red / DANGEROUS** — contains destructive patterns like `rm -rf`, `format c:`, `dd if=`, fork bombs
- **Yellow / Caution** — contains elevated-privilege patterns like `sudo`, `chmod`, `kill`
- **Green / Safe** — no known dangerous patterns detected

You always have to explicitly approve before anything runs. Bashly never auto-executes.

## History

All approved, denied, and copied commands are saved to `~/.bashly_history.json`. This file persists across sessions and is stored in your home directory.

## Notes

- Danger detection is not a security guarantee — always read the command before approving
- For MicroPython and Arduino targets, Bashly generates code snippets, not terminal commands
- The `switch env` command lets you generate commands for multiple environments in one session