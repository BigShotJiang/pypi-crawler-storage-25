#!/usr/bin/env python3
# -*- coding: utf-8 -*-
""" Constants declarations """

# These get overwritten at build time. See build.sh
VERSION = '1.0.23'
BUILD = '2431300781'
NAME = 'ix-notifiers'
