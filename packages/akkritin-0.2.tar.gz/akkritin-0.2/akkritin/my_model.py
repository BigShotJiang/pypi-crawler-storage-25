def hello():
    print("1. 
import pandas as pd
import numpy as np
import math
import matplotlib.pyplot as plt
from scipy.stats import chi2_contingency, pearsonr

# READ CSV
df = pd.read_csv("data.csv")
print("Original Data:\n", df)

# ------------------ 1. MISSING VALUES ------------------

# a) Ignore tuple
print("\nIgnore Tuples:\n", df.dropna())

# b) Manual fill
df.loc[1,"Salary"] = 55000
print("\nManual Fill:\n", df)

# c) Global constant
print("\nGlobal Constant:\n", df.fillna(-1))

# d) Mean
df_mean = df.copy()
df_mean["Age"] = df_mean["Age"].fillna(df_mean["Age"].mean())
df_mean["Salary"] = df_mean["Salary"].fillna(df_mean["Salary"].mean())
print("\nMean Fill:\n", df_mean)

# e) Most probable (mode)
df_mode = df.copy()
df_mode["Age"] = df_mode["Age"].fillna(df_mode["Age"].mode()[0])
print("\nMode Fill:\n", df_mode)

# ------------------ 2. BINNING ------------------

df["bin_width"] = pd.cut(df["Age"], 3)
df["bin_freq"] = pd.qcut(df["Age"], 3)
print("\nBinning:\n", df)

# ------------------ 3. NORMALIZATION ------------------

# Min-Max
df["minmax"] = (df["Age"]-df["Age"].min())/(df["Age"].max()-df["Age"].min())

# Z-score
df["zscore"] = (df["Age"]-df["Age"].mean())/df["Age"].std()

# Decimal scaling
j = len(str(int(df["Age"].max())))
df["decimal"] = df["Age"]/(10**j)

print("\nNormalization:\n", df)

# ------------------ 4. DISTANCE ------------------

A = df.iloc[0][["Age","Salary"]]
B = df.iloc[1][["Age","Salary"]]

e = math.sqrt((A[0]-B[0])**2 + (A[1]-B[1])**2)
m = abs(A[0]-B[0]) + abs(A[1]-B[1])
p = 3
mk = (abs(A[0]-B[0])**p + abs(A[1]-B[1])**p)**(1/p)

print("\nDistances:")
print("Euclidean:", e)
print("Manhattan:", m)
print("Minkowski:", mk)

# ------------------ 5. VISUALIZATION ------------------

df["Age"].hist()
plt.title("Histogram")
plt.show()

df.boxplot()
plt.title("Boxplot")
plt.show()

plt.scatter(df["Age"], df["Salary"])
plt.title("Scatter Plot")
plt.show()

df["Age"].value_counts().plot.pie()
plt.title("Pie Chart")
plt.show()

# ------------------ 6. CORRELATION ------------------

# Pearson
print("\nPearson:\n", df.corr())

# Chi-square
table = pd.crosstab(df["Age"], df["Salary"])
chi2, p, dof, exp = chi2_contingency(table)
print("\nChi-square:", chi2)

# Product moment
x = df["Age"].values
y = df["Salary"].values
mx = np.mean(x)
my = np.mean(y)

num = np.sum((x-mx)*(y-my))
den = np.sqrt(np.sum((x-mx)**2)*np.sum((y-my)**2))

r = num/den
print("\nProduct Moment:", r)

2.
Knn
# KNN from scratch with CSV input (no predefined ML functions)

# read csv file
f = open("data.csv", "r")
data = []
for line in f:
    line = line.strip()
    if line != "":
        row = line.split(",")
        data.append(row)
f.close()

# separate features and labels
X = []
y = []

for i in range(len(data)):
    row = data[i]
    temp = []
    for j in range(len(row)-1):
        temp.append(float(row[j]))
    X.append(temp)
    y.append(row[-1])

# new point input
p = []
n = len(X[0])
for i in range(n):
    val = float(input())
    p.append(val)

k = int(input())

# distance calculation
dist = []
for i in range(len(X)):
    s = 0
    for j in range(len(p)):
        d = p[j] - X[i][j]
        s = s + d * d
    dist.append([s, y[i]])

# bubble sort
for i in range(len(dist)):
    for j in range(0, len(dist)-i-1):
        if dist[j][0] > dist[j+1][0]:
            temp = dist[j]
            dist[j] = dist[j+1]
            dist[j+1] = temp

# majority vote
count = {}
for i in range(k):
    c = dist[i][1]
    if c in count:
        count[c] = count[c] + 1
    else:
        count[c] = 1

# find result
m = 0
res = ""
for key in count:
    if count[key] > m:
        m = count[key]
        res = key

print(res)
3. naïve Bayesian algorithm
# Naive Bayes from scratch using CSV (categorical data)

# read csv
f = open("data.csv", "r")
data = []
for line in f:
    line = line.strip()
    if line != "":
        row = line.split(",")
        data.append(row)
f.close()

# separate features and class
X = []
y = []

for i in range(len(data)):
    row = data[i]
    temp = []
    for j in range(len(row)-1):
        temp.append(row[j])
    X.append(temp)
    y.append(row[-1])

# input unknown sample
p = []
n = len(X[0])
for i in range(n):
    val = input()
    p.append(val)

# find class counts
class_count = {}
for i in range(len(y)):
    c = y[i]
    if c in class_count:
        class_count[c] += 1
    else:
        class_count[c] = 1

# calculate probabilities
prob = {}

for c in class_count:
    prob[c] = class_count[c] / len(y)
    
    for j in range(n):
        num = 0
        den = class_count[c]
        
        for i in range(len(X)):
            if y[i] == c and X[i][j] == p[j]:
                num += 1
        
        # avoid zero probability
        prob[c] = prob[c] * ((num + 1) / (den + len(class_count)))

# find max probability class
res = ""
m = 0

for c in prob:
    if prob[c] > m:
        m = prob[c]
        res = c

print(res)
4. id3 
# ID3 Algorithm from scratch using CSV (categorical data)

# read csv
f = open("data.csv", "r")
data = []
for line in f:
    line = line.strip()
    if line != "":
        row = line.split(",")
        data.append(row)
f.close()

# split features and class
X = []
y = []

for i in range(len(data)):
    row = data[i]
    temp = []
    for j in range(len(row)-1):
        temp.append(row[j])
    X.append(temp)
    y.append(row[-1])

# entropy
def entropy(rows):
    count = {}
    for r in rows:
        c = r[-1]
        if c in count:
            count[c] += 1
        else:
            count[c] = 1
    
    e = 0
    total = len(rows)
    
    for c in count:
        p = count[c] / total
        e -= p * (p**0.0 if p == 0 else ( (p).__float__().__pow__(0) if False else (p and (__import__('math').log(p,2))) ))
    return e

# information gain
def gain(rows, col):
    total_entropy = entropy(rows)
    
    vals = {}
    for r in rows:
        v = r[col]
        if v in vals:
            vals[v].append(r)
        else:
            vals[v] = [r]
    
    w = 0
    total = len(rows)
    
    for v in vals:
        subset = vals[v]
        w += (len(subset)/total) * entropy(subset)
    
    return total_entropy - w

# build tree
def build(rows, cols):
    # check same class
    first = rows[0][-1]
    same = True
    for r in rows:
        if r[-1] != first:
            same = False
            break
    if same:
        return first
    
    if len(cols) == 0:
        return first
    
    # find best attribute
    best = cols[0]
    maxg = -1
    
    for c in cols:
        g = gain(rows, c)
        if g > maxg:
            maxg = g
            best = c
    
    tree = {best: {}}
    
    vals = {}
    for r in rows:
        v = r[best]
        if v in vals:
            vals[v].append(r)
        else:
            vals[v] = [r]
    
    new_cols = []
    for c in cols:
        if c != best:
            new_cols.append(c)
    
    for v in vals:
        tree[best][v] = build(vals[v], new_cols)
    
    return tree

# predict
def predict(tree, row):
    if type(tree) != dict:
        return tree
    
    for key in tree:
        val = row[key]
        if val in tree[key]:
            return predict(tree[key][val], row)
        else:
            return None

# prepare data with class at end
rows = []
for i in range(len(X)):
    rows.append(X[i] + [y[i]])

cols = list(range(len(X[0])))

tree = build(rows, cols)

# input test sample
p = []
for i in range(len(X[0])):
    p.append(input())

# convert to index-based row
test = p

print(predict(tree, test))

5. decision tree using cart
# CART Decision Tree from scratch using CSV (Gini Index)

# read csv
f = open("data.csv", "r")
data = []
for line in f:
    line = line.strip()
    if line != "":
        row = line.split(",")
        data.append(row)
f.close()

# separate features and class
X = []
y = []

for i in range(len(data)):
    row = data[i]
    temp = []
    for j in range(len(row)-1):
        temp.append(row[j])
    X.append(temp)
    y.append(row[-1])

# combine rows
rows = []
for i in range(len(X)):
    rows.append(X[i] + [y[i]])

# gini index
def gini(groups):
    total = 0
    for g in groups:
        total += len(g)
    
    gini_val = 0
    for g in groups:
        size = len(g)
        if size == 0:
            continue
        
        count = {}
        for r in g:
            c = r[-1]
            if c in count:
                count[c] += 1
            else:
                count[c] = 1
        
        score = 0
        for c in count:
            p = count[c] / size
            score += p * p
        
        gini_val += (1 - score) * (size / total)
    
    return gini_val

# split dataset
def split(index, value, rows):
    left = []
    right = []
    
    for r in rows:
        if r[index] == value:
            left.append(r)
        else:
            right.append(r)
    
    return left, right

# find best split
def best_split(rows):
    best_i = 0
    best_v = None
    best_s = 999
    
    for i in range(len(rows[0]) - 1):
        values = []
        for r in rows:
            if r[i] not in values:
                values.append(r[i])
        
        for v in values:
            left, right = split(i, v, rows)
            s = gini([left, right])
            
            if s < best_s:
                best_i = i
                best_v = v
                best_s = s
    
    return best_i, best_v

# create leaf
def leaf(rows):
    count = {}
    for r in rows:
        c = r[-1]
        if c in count:
            count[c] += 1
        else:
            count[c] = 1
    
    m = 0
    res = ""
    for c in count:
        if count[c] > m:
            m = count[c]
            res = c
    return res

# build tree
def build(rows, depth, max_depth):
    classes = []
    for r in rows:
        classes.append(r[-1])
    
    same = True
    for c in classes:
        if c != classes[0]:
            same = False
            break
    
    if same:
        return classes[0]
    
    if depth >= max_depth:
        return leaf(rows)
    
    i, v = best_split(rows)
    
    left, right = split(i, v, rows)
    
    if len(left) == 0 or len(right) == 0:
        return leaf(rows)
    
    node = {}
    node["index"] = i
    node["value"] = v
    node["left"] = build(left, depth+1, max_depth)
    node["right"] = build(right, depth+1, max_depth)
    
    return node

# predict
def predict(node, row):
    if type(node) != dict:
        return node
    
    if row[node["index"]] == node["value"]:
        return predict(node["left"], row)
    else:
        return predict(node["right"], row)

# build model
tree = build(rows, 0, 5)

# input test sample
p = []
for i in range(len(X[0])):
    p.append(input())

print(predict(tree, p))

6. Apriori Algorithm

# Apriori Algorithm from scratch using CSV

# read csv (each row = transaction: items separated by comma)
f = open("data.csv", "r")
data = []
for line in f:
    line = line.strip()
    if line != "":
        row = line.split(",")
        data.append(row)
f.close()

# min support and confidence
min_sup = 2
min_conf = 0.5

# get unique items
items = []
for t in data:
    for i in t:
        if i not in items:
            items.append(i)

# count support
def support_count(itemset):
    c = 0
    for t in data:
        found = True
        for i in itemset:
            if i not in t:
                found = False
                break
        if found:
            c += 1
    return c

# generate candidates
def join(L, k):
    C = []
    for i in range(len(L)):
        for j in range(i+1, len(L)):
            a = L[i]
            b = L[j]
            temp = list(set(a) | set(b))
            if len(temp) == k and temp not in C:
                C.append(temp)
    return C

# Apriori
L = []
L1 = []

for i in items:
    if support_count([i]) >= min_sup:
        L1.append([i])

L.append(L1)

k = 2
while True:
    Ck = join(L[k-2], k)
    Lk = []
    
    for c in Ck:
        if support_count(c) >= min_sup:
            Lk.append(c)
    
    if len(Lk) == 0:
        break
    
    L.append(Lk)
    k += 1

# display frequent itemsets
print("Frequent Itemsets:")
for i in range(len(L)):
    for itemset in L[i]:
        print(itemset, ":", support_count(itemset))

# generate rules
print("\nStrong Association Rules:")

for i in range(1, len(L)):
    for itemset in L[i]:
        for j in range(len(itemset)):
            left = [itemset[j]]
            right = []
            
            for x in itemset:
                if x != itemset[j]:
                    right.append(x)
            
            sup_xy = support_count(itemset)
            sup_x = support_count(left)
            
            conf = sup_xy / sup_x
            
            if conf >= min_conf:
                print(left, "->", right, "conf:", conf)

7. FP-growthAlgorithm
# FP-Growth from scratch using CSV

# read csv (each row = transaction)
f = open("data.csv", "r")
data = []
for line in f:
    line = line.strip()
    if line != "":
        row = line.split(",")
        data.append(row)
f.close()

min_sup = 2
min_conf = 0.5

# count item frequency
freq = {}
for t in data:
    for i in t:
        if i in freq:
            freq[i] += 1
        else:
            freq[i] = 1

# remove infrequent items
freq_items = []
for i in freq:
    if freq[i] >= min_sup:
        freq_items.append(i)

# sort items in transactions by frequency
transactions = []
for t in data:
    temp = []
    for i in t:
        if i in freq_items:
            temp.append(i)
    
    # sort manually
    for i in range(len(temp)):
        for j in range(0, len(temp)-i-1):
            if freq[temp[j]] < freq[temp[j+1]]:
                temp[j], temp[j+1] = temp[j+1], temp[j]
    
    if len(temp) > 0:
        transactions.append(temp)

# FP-tree node
class Node:
    def __init__(self, item):
        self.item = item
        self.count = 1
        self.child = {}
        self.link = None

# build tree
root = Node(None)
root.count = 0

header = {}

for t in transactions:
    cur = root
    for i in t:
        if i in cur.child:
            cur.child[i].count += 1
        else:
            new = Node(i)
            cur.child[i] = new
            
            if i in header:
                temp = header[i]
                while temp.link != None:
                    temp = temp.link
                temp.link = new
            else:
                header[i] = new
        
        cur = cur.child[i]

# get conditional pattern base
def cond_base(item):
    base = []
    node = header[item]
    
    while node != None:
        path = []
        parent = node
        
        # traverse up
        while parent.item != None:
            parent = find_parent(root, parent)
            if parent != None and parent.item != None:
                path.append(parent.item)
        
        for _ in range(node.count):
            if len(path) > 0:
                base.append(path)
        
        node = node.link
    
    return base

# find parent (manual search)
def find_parent(cur, target):
    for c in cur.child:
        if cur.child[c] == target:
            return cur
        res = find_parent(cur.child[c], target)
        if res != None:
            return res
    return None

# support count
def support(itemset):
    c = 0
    for t in data:
        found = True
        for i in itemset:
            if i not in t:
                found = False
                break
        if found:
            c += 1
    return c

# generate frequent itemsets (simple, not recursive mining)
freq_sets = []

for i in freq_items:
    freq_sets.append([i])
    
    base = cond_base(i)
    
    temp_items = []
    for b in base:
        for x in b:
            if x not in temp_items:
                temp_items.append(x)
    
    for x in temp_items:
        itemset = [i, x]
        if support(itemset) >= min_sup:
            freq_sets.append(itemset)

# display frequent itemsets
print("Frequent Itemsets:")
for s in freq_sets:
    print(s, ":", support(s))

# generate rules
print("\nStrong Association Rules:")

for s in freq_sets:
    if len(s) > 1:
        for i in range(len(s)):
            left = [s[i]]
            right = []
            
            for x in s:
                if x != s[i]:
                    right.append(x)
            
            conf = support(s) / support(left)
            
            if conf >= min_conf:
                print(left, "->", right, "conf:", conf)

8. Eclat (Equivalence Class Transformation) algorithm
# Eclat Algorithm (Vertical Data Format) from scratch using CSV

# read csv (each row = transaction)
f = open("data.csv", "r")
data = []
for line in f:
    line = line.strip()
    if line != "":
        row = line.split(",")
        data.append(row)
f.close()

min_sup = 2
min_conf = 0.5

# build vertical format (item -> transaction IDs)
V = {}
for tid in range(len(data)):
    for item in data[tid]:
        if item in V:
            V[item].append(tid)
        else:
            V[item] = [tid]

# keep only frequent 1-itemsets
items = []
for i in V:
    if len(V[i]) >= min_sup:
        items.append(i)

# Eclat recursive
freq_sets = []

def eclat(prefix, items):
    for i in range(len(items)):
        item = items[i]
        
        if prefix == []:
            new_set = [item]
            tids = V[item]
        else:
            new_set = prefix + [item]
            tids = intersect(prefix_tids[prefix_key(prefix)], V[item])
        
        if len(tids) >= min_sup:
            freq_sets.append((new_set, tids))
            
            new_items = items[i+1:]
            eclat_next(new_set, tids, new_items)

def eclat_next(prefix, tids, items):
    for i in range(len(items)):
        item = items[i]
        
        new_set = prefix + [item]
        new_tids = intersect(tids, V[item])
        
        if len(new_tids) >= min_sup:
            freq_sets.append((new_set, new_tids))
            eclat_next(new_set, new_tids, items[i+1:])

# intersection manually
def intersect(a, b):
    res = []
    for x in a:
        for y in b:
            if x == y:
                res.append(x)
    return res

# helper for prefix tids
prefix_tids = {}
def prefix_key(p):
    return tuple(p)

# run eclat
for i in items:
    prefix_tids[(i,)] = V[i]

eclat([], items)

# display frequent itemsets
print("Frequent Itemsets:")
for s, tids in freq_sets:
    print(s, ":", len(tids))

# support count
def support(itemset):
    c = 0
    for t in data:
        found = True
        for i in itemset:
            if i not in t:
                found = False
                break
        if found:
            c += 1
    return c

# generate strong rules
print("\nStrong Association Rules:")

for s, tids in freq_sets:
    if len(s) > 1:
        for i in range(len(s)):
            left = [s[i]]
            right = []
            
            for x in s:
                if x != s[i]:
                    right.append(x)
            
            conf = support(s) / support(left)
            
            if conf >= min_conf:
                print(left, "->", right, "conf:", conf)










Crypto

1.  
Diffie–Hellman Key Exchange

Code:
import java.util.*;

class Main {
    static long p, g, a, b;

    static long pow(long x, long y) {
        long r = 1;
        x = x % p;
        while (y > 0) {
            if (y % 2 == 1)
                r = (r * x) % p;
            y = y / 2;
            x = (x * x) % p;
        }
        return r;
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        System.out.print("Enter prime number (p): ");
        p = s.nextLong();

        System.out.print("Enter primitive root (g): ");
        g = s.nextLong();

        System.out.print("Enter Alice private key (a): ");
        a = s.nextLong();

        System.out.print("Enter Bob private key (b): ");
        b = s.nextLong();

        long A = pow(g, a);
        long B = pow(g, b);

        long k1 = pow(B, a);
        long k2 = pow(A, b);

        System.out.println("Alice Public Key: " + A);
        System.out.println("Bob Public Key: " + B);
        System.out.println("Shared Secret Key computed by Alice: " + k1);
        System.out.println("Shared Secret Key computed by Bob: " + k2);

        if (k1 == k2)
            System.out.println("Key Exchange Successful: Shared keys match.");
        else
            System.out.println("Key Exchange Failed.");
    }
}

Or
import java.util.*;

class Main {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        long p, g, a, b;

        System.out.print("Enter prime number (p): ");
        p = s.nextLong();

        System.out.print("Enter primitive root (g): ");
        g = s.nextLong();

        System.out.print("Enter Alice private key (a): ");
        a = s.nextLong();

        System.out.print("Enter Bob private key (b): ");
        b = s.nextLong();

        long A = (long)(Math.pow(g, a) % p);
        long B = (long)(Math.pow(g, b) % p);

        long k1 = (long)(Math.pow(B, a) % p);
        long k2 = (long)(Math.pow(A, b) % p);

        System.out.println("Alice Public Key: " + A);
        System.out.println("Bob Public Key: " + B);
        System.out.println("Shared Secret Key computed by Alice: " + k1);
        System.out.println("Shared Secret Key computed by Bob: " + k2);

        if (k1 == k2)
            System.out.println("Key Exchange Successful: Shared keys match.");
        else
            System.out.println("Key Exchange Failed.");
    }
}

2. rsa
import java.util.*;

class Main {
    static long p, q, n, phi, e, d;


    static long modInverse(long e, long phi) {
        for (long i = 1; i < phi; i++) {
            if ((e * i) % phi == 1)
                return i;
        }
        return -1;
    }

    static long pow(long x, long y, long mod) {
        long r = 1;
        x = x % mod;
        while (y > 0) {
            if (y % 2 == 1)
                r = (r * x) % mod;
            y = y / 2;
            x = (x * x) % mod;
        }
        return r;
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        System.out.print("Enter two prime numbers (p and q): ");
        p = s.nextLong();
        q = s.nextLong();

        n = p * q;
        phi = (p - 1) * (q - 1);

        System.out.print("Enter value of e: ");
        e = s.nextLong();

        d = modInverse(e, phi);

        System.out.println("Public Key: (e, n) = (" + e + ", " + n + ")");
        System.out.println("Private Key: (d, n) = (" + d + ", " + n + ")");

        System.out.print("Enter number of ASCII values: ");
        int m = s.nextInt();

        long[] msg = new long[m];
        System.out.println("Enter the ASCII values:");
        for (int i = 0; i < m; i++)
            msg[i] = s.nextLong();

        long[] enc = new long[m];
        for (int i = 0; i < m; i++)
            enc[i] = pow(msg[i], e, n);

        System.out.print("Encrypted Message: ");
        for (int i = 0; i < enc.length; i++)
            System.out.print(enc[i] + " ");
        System.out.println();

        long[] dec = new long[m];
        for (int i = 0; i < m; i++)
            dec[i] = pow(enc[i], d, n);

        System.out.print("Decrypted Message (ASCII values): ");
        for (int i = 0; i < dec.length; i++)
            System.out.print(dec[i] + " ");
        System.out.println();

        System.out.print("Decrypted Message: ");
        for (int i = 0; i < dec.length; i++)
            System.out.print((char) dec[i]);
    }
}

3. playfair cipher

import java.util.*;

class Main {
    static char m[][] = new char[5][5];

    static void create(String k) {
        boolean v[] = new boolean[26];
        k = k.toLowerCase().replace("j", "i");
        int x = 0;

        for (int i = 0; i < k.length(); i++) {
            char c = k.charAt(i);
            if (!v[c - 'a']) {
                m[x / 5][x % 5] = c;
                v[c - 'a'] = true;
                x++;
            }
        }

        for (char c = 'a'; c <= 'z'; c++) {
            if (c == 'j') continue;
            if (!v[c - 'a']) {
                m[x / 5][x % 5] = c;
                x++;
            }
        }
    }

    static void pos(char c, int p[]) {
        if (c == 'j') c = 'i';

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                if (m[i][j] == c) {
                    p[0] = i;
                    p[1] = j;
                    return;
                }
            }
        }
    }

    static String enc(String s) {
        s = s.toLowerCase().replace("j", "i").replaceAll(" ", "");
        if (s.length() % 2 != 0) s += "x";

        String r = "";

        for (int i = 0; i < s.length(); i += 2) {
            char a = s.charAt(i);
            char b = s.charAt(i + 1);

            int p1[] = new int[2];
            int p2[] = new int[2];

            pos(a, p1);
            pos(b, p2);

            if (p1[0] == p2[0]) {
                r += m[p1[0]][(p1[1] + 1) % 5];
                r += m[p2[0]][(p2[1] + 1) % 5];
            } else if (p1[1] == p2[1]) {
                r += m[(p1[0] + 1) % 5][p1[1]];
                r += m[(p2[0] + 1) % 5][p2[1]];
            } else {
                r += m[p1[0]][p2[1]];
                r += m[p2[0]][p1[1]];
            }
        }
        return r;
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        System.out.print("Enter key: ");
        String k = s.nextLine();

        System.out.print("Enter text: ");
        String t = s.nextLine();

        create(k);

        String c = enc(t);

        System.out.println("Encrypted Text: " + c);
    }
}

4. hill cipher

import java.util.*;

class Main {

    static int key[][] = {
        {17,17,5},
        {21,18,21},
        {2,2,19}
    };

    static void multiply(int[] p, int[] c) {
        for (int i = 0; i < 3; i++) {
            c[i] = 0;
            for (int j = 0; j < 3; j++) {
                c[i] += key[i][j] * p[j];
            }
            c[i] %= 26;
        }
    }

    static String encrypt(String text) {
        text = text.toLowerCase().replaceAll(" ", "");

        while (text.length() % 3 != 0)
            text += "x";

        String res = "";

        for (int i = 0; i < text.length(); i += 3) {
            int p[] = new int[3];
            int c[] = new int[3];

            for (int j = 0; j < 3; j++)
                p[j] = text.charAt(i + j) - 'a';

            multiply(p, c);

            for (int j = 0; j < 3; j++)
                res += (char)(c[j] + 'a');
        }

        return res;
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        System.out.print("Enter text: ");
        String t = s.nextLine();

        System.out.println("Encrypted Text: " + encrypt(t));
    }
}
4. hill cipher (encrypt)
import java.util.*;

class Main {

    static int key[][] = {
        {17,17,5},
        {21,18,21},
        {2,2,19}
    };

    static void multiply(int[] p, int[] c) {
        for (int i = 0; i < 3; i++) {
            c[i] = 0;
            for (int j = 0; j < 3; j++) {
                c[i] += key[i][j] * p[j];
            }
            c[i] %= 26;
        }
    }

    static String encrypt(String text) {
        text = text.toLowerCase().replaceAll(" ", "");

        while (text.length() % 3 != 0)
            text += "x";

        String res = "";

        for (int i = 0; i < text.length(); i += 3) {
            int p[] = new int[3];
            int c[] = new int[3];

            for (int j = 0; j < 3; j++)
                p[j] = text.charAt(i + j) - 'a';

            multiply(p, c);

            for (int j = 0; j < 3; j++)
                res += (char)(c[j] + 'a');
        }

        return res;
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        System.out.print("Enter text: ");
        String t = s.nextLine();

        System.out.println("Encrypted Text: " + encrypt(t));
    }
}
5. ceasar cipher encrypt

import java.util.*;

class Main {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        System.out.print("Enter text: ");
        String text = s.nextLine();

        System.out.print("Enter key: ");
        int k = s.nextInt();

        String res = "";

        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);

            if (c >= 'a' && c <= 'z') {
                res += (char)((c - 'a' + k) % 26 + 'a');
            }
            else if (c >= 'A' && c <= 'Z') {
                res += (char)((c - 'A' + k) % 26 + 'A');
            }
            else {
                res += c;
            }
        }

        System.out.println("Cipher Text: " + res);
    }
}
6. ceasar cipher (decrypt)
import java.util.*;

class Main {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        System.out.print("Enter cipher text: ");
        String text = s.nextLine();

        for (int k = 1; k < 26; k++) {
            String res = "";

            for (int i = 0; i < text.length(); i++) {
                char c = text.charAt(i);

                if (c >= 'a' && c <= 'z') {
                    res += (char)((c - 'a' - k + 26) % 26 + 'a');
                }
                else if (c >= 'A' && c <= 'Z') {
                    res += (char)((c - 'A' - k + 26) % 26 + 'A');
                }
                else {
                    res += c;
                }
            }

            System.out.println("Key " + k + ": " + res);
        }
    }
}
7.
Vignere cipher
import java.util.*;

class Main {

    static String encrypt(String text, String key) {
        text = text.toUpperCase();
        key = key.toUpperCase();

        String res = "";
        int j = 0;

        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);

            if (c >= 'A' && c <= 'Z') {
                int x = (c - 'A' + key.charAt(j) - 'A') % 26;
                res += (char)(x + 'A');
                j = (j + 1) % key.length();
            } else {
                res += c;
            }
        }
        return res;
    }

    static String decrypt(String text, String key) {
        text = text.toUpperCase();
        key = key.toUpperCase();

        String res = "";
        int j = 0;

        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);

            if (c >= 'A' && c <= 'Z') {
                int x = (c - key.charAt(j) + 26) % 26;
                res += (char)(x + 'A');
                j = (j + 1) % key.length();
            } else {
                res += c;
            }
        }
        return res;
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        System.out.print("Enter text: ");
        String text = s.nextLine();

        System.out.print("Enter key: ");
        String key = s.nextLine();

        String enc = encrypt(text, key);
        System.out.println("Encrypted Text: " + enc);

        String dec = decrypt(enc, key);
        System.out.println("Decrypted Text: " + dec);
    }
}
8. md5
import java.security.*;
import java.util.*;
class Main{
static String f(String m){
try{
byte[]b=MessageDigest.getInstance("MD5").digest(m.getBytes());
String s="";
for(byte x:b)s+=String.format("%02x",x);
return s;
}catch(Exception e){return null;}
}
public static void main(String[]a){
System.out.println(f(new Scanner(System.in).nextLine()));
}}
9. signature
import java.security.*;
import java.util.*;
class Main{
public static void main(String[]a)throws Exception{
Scanner s=new Scanner(System.in);
String m=s.nextLine();
KeyPairGenerator k=KeyPairGenerator.getInstance("DSA","SUN");
k.initialize(1024,new SecureRandom());
KeyPair p=k.generateKeyPair();
Signature g=Signature.getInstance("SHA1withDSA","SUN");
g.initSign(p.getPrivate());
g.update(m.getBytes());
byte[] d=g.sign();
g.initVerify(p.getPublic());
g.update(m.getBytes());
System.out.println(g.verify(d));
}}

10. des
import java.util.*;

class Main {

    static int[] PC1 = {
        57,49,41,33,25,17,9,
        1,58,50,42,34,26,18,
        10,2,59,51,43,35,27,
        19,11,3,60,52,44,36,
        63,55,47,39,31,23,15,
        7,62,54,46,38,30,22,
        14,6,61,53,45,37,29,
        21,13,5,28,20,12,4
    };

    static int[] PC2 = {
        14,17,11,24,1,5,
        3,28,15,6,21,10,
        23,19,12,4,26,8,
        16,7,27,20,13,2,
        41,52,31,37,47,55,
        30,40,51,45,33,48,
        44,49,39,56,34,53,
        46,42,50,36,29,32
    };

    static int[] SHIFT_TABLE = {
        1,1,2,2,2,2,2,2,
        1,2,2,2,2,2,2,1
    };

    static String hexToBin(String s) {
        StringBuilder b = new StringBuilder();
        for (char c : s.toCharArray()) {
            b.append(String.format("%4s", Integer.toBinaryString(Integer.parseInt("" + c, 16))).replace(' ', '0'));
        }
        return b.toString();
    }

    static String binToHex(String s) {
        StringBuilder h = new StringBuilder();
        for (int i = 0; i < s.length(); i += 4) {
            h.append(Integer.toHexString(Integer.parseInt(s.substring(i, i + 4), 2)).toUpperCase());
        }
        return h.toString();
    }

    static String permute(String k, int[] arr) {
        StringBuilder p = new StringBuilder();
        for (int i : arr) p.append(k.charAt(i - 1));
        return p.toString();
    }

    static String leftShift(String s, int n) {
        return s.substring(n) + s.substring(0, n);
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        String key = sc.nextLine();

        String binKey = hexToBin(key);
        String permKey = permute(binKey, PC1);

        String left = permKey.substring(0, 28);
        String right = permKey.substring(28);

        for (int i = 0; i < 16; i++) {
            left = leftShift(left, SHIFT_TABLE[i]);
            right = leftShift(right, SHIFT_TABLE[i]);

            String combined = left + right;
            String roundKey = permute(combined, PC2);

            System.out.println("Round " + (i + 1) + " Key: " + binToHex(roundKey));
        }
    }
}
11. aes

import java.util.*;

class Main {

    static int[] sbox = {
        0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,0x30,0x01,0x67,0x2b,0xfe,0xd7,0xab,0x76,
        0xca,0x82,0xc9,0x7d,0xfa,0x59,0x47,0xf0,0xad,0xd4,0xa2,0xaf,0x9c,0xa4,0x72,0xc0,
        0xb7,0xfd,0x93,0x26,0x36,0x3f,0xf7,0xcc,0x34,0xa5,0xe5,0xf1,0x71,0xd8,0x31,0x15,
        0x04,0xc7,0x23,0xc3,0x18,0x96,0x05,0x9a,0x07,0x12,0x80,0xe2,0xeb,0x27,0xb2,0x75,
        0x09,0x83,0x2c,0x1a,0x1b,0x6e,0x5a,0xa0,0x52,0x3b,0xd6,0xb3,0x29,0xe3,0x2f,0x84,
        0x53,0xd1,0x00,0xed,0x20,0xfc,0xb1,0x5b,0x6a,0xcb,0xbe,0x39,0x4a,0x4c,0x58,0xcf,
        0xd0,0xef,0xaa,0xfb,0x43,0x4d,0x33,0x85,0x45,0xf9,0x02,0x7f,0x50,0x3c,0x9f,0xa8,
        0x51,0xa3,0x40,0x8f,0x92,0x9d,0x38,0xf5,0xbc,0xb6,0xda,0x21,0x10,0xff,0xf3,0xd2,
        0xcd,0x0c,0x13,0xec,0x5f,0x97,0x44,0x17,0xc4,0xa7,0x7e,0x3d,0x64,0x5d,0x19,0x73,
        0x60,0x81,0x4f,0xdc,0x22,0x2a,0x90,0x88,0x46,0xee,0xb8,0x14,0xde,0x5e,0x0b,0xdb,
        0xe0,0x32,0x3a,0x0a,0x49,0x06,0x24,0x5c,0xc2,0xd3,0xac,0x62,0x91,0x95,0xe4,0x79,
        0xe7,0xc8,0x37,0x6d,0x8d,0xd5,0x4e,0xa9,0x6c,0x56,0xf4,0xea,0x65,0x7a,0xae,0x08,
        0xba,0x78,0x25,0x2e,0x1c,0xa6,0xb4,0xc6,0xe8,0xdd,0x74,0x1f,0x4b,0xbd,0x8b,0x8a,
        0x70,0x3e,0xb5,0x66,0x48,0x03,0xf6,0x0e,0x61,0x35,0x57,0xb9,0x86,0xc1,0x1d,0x9e,
        0xe1,0xf8,0x98,0x11,0x69,0xd9,0x8e,0x94,0x9b,0x1e,0x87,0xe9,0xce,0x55,0x28,0xdf,
        0x8c,0xa1,0x89,0x0d,0xbf,0xe6,0x42,0x68,0x41,0x99,0x2d,0x0f,0xb0,0x54,0xbb,0x16
    };

    static int[] rcon = {
        0x01,0x02,0x04,0x08,0x10,
        0x20,0x40,0x80,0x1B,0x36
    };

    static int[] rotWord(int[] w) {
        return new int[]{w[1], w[2], w[3], w[0]};
    }

    static int[] subWord(int[] w) {
        int[] res = new int[4];
        for (int i = 0; i < 4; i++) res[i] = sbox[w[i]];
        return res;
    }

    static int[] xor(int[] a, int[] b) {
        int[] res = new int[4];
        for (int i = 0; i < 4; i++) res[i] = a[i] ^ b[i];
        return res;
    }

    static String toHex(int[][] w, int start) {
        StringBuilder sb = new StringBuilder();
        for (int i = start; i < start + 4; i++) {
            for (int j = 0; j < 4; j++) {
                sb.append(String.format("%02x", w[i][j]));
            }
        }
        return sb.toString();
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);+
        String key = sc.nextLine();

        int[][] w = new int[44][4];

        for (int i = 0; i < 16; i++) {
            w[i / 4][i % 4] = Integer.parseInt(key.substring(2 * i, 2 * i + 2), 16);
        }

        for (int i = 4; i < 44; i++) {
            int[] temp = w[i - 1].clone();

            if (i % 4 == 0) {
                temp = subWord(rotWord(temp));
                temp[0] ^= rcon[(i / 4) - 1];
            }

            w[i] = xor(w[i - 4], temp);
        }

        for (int i = 0; i <= 10; i++) {
            System.out.println("Round " + i + " Key : " + toHex(w, i * 4));
        }
    }
}




")