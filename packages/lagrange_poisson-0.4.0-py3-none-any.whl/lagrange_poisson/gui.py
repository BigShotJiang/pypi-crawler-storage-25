"""
图形用户界面
Graphical User Interface using Tkinter
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import matplotlib

# 使用中文字体支持
matplotlib.rcParams["font.sans-serif"] = ["SimHei", "Microsoft YaHei", "Arial Unicode MS"]
matplotlib.rcParams["axes.unicode_minus"] = False

from .solver import LagrangePoissonSolver
from .numerical_methods import EulerMethod, ImprovedEulerMethod, RK4Method


class LagrangePoissonGUI:
    """拉格朗日-泊松问题求解器GUI"""

    def __init__(self, root):
        self.root = root
        self.root.title("拉格朗日-泊松问题求解器")
        self.root.geometry("1200x800")

        # 初始化变量
        self.method_var = tk.StringVar(value="RK4")
        self.display_mode = tk.StringVar(value="poisson")  # "poisson" 或 "euler"
        self.results_t = None
        self.results_y = None
        self.results_euler = None

        # 创建界面
        self.create_widgets()

    def create_widgets(self):
        """创建界面组件"""

        # 主容器
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        # 配置网格权重
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        main_frame.rowconfigure(0, weight=1)

        # 左侧参数面板
        params_frame = ttk.LabelFrame(main_frame, text="参数设置", padding="10")
        params_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), padx=(0, 10))

        # 转动惯量
        self.create_parameter_entry(params_frame, "主转动惯量 A:", "A", "1.0", 0)
        self.create_parameter_entry(params_frame, "主转动惯量 B:", "B", "2.0", 1)
        self.create_parameter_entry(params_frame, "主转动惯量 C:", "C", "3.0", 2)

        # 质心坐标
        ttk.Separator(params_frame, orient="horizontal").grid(
            row=3, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=10
        )
        self.create_parameter_entry(params_frame, "质心坐标 x0:", "x0", "0.1", 4)
        self.create_parameter_entry(params_frame, "质心坐标 y0:", "y0", "0.0", 5)
        self.create_parameter_entry(params_frame, "质心坐标 z0:", "z0", "0.0", 6)

        # 物理参数
        ttk.Separator(params_frame, orient="horizontal").grid(
            row=7, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=10
        )
        self.create_parameter_entry(params_frame, "质量 m (kg):", "m", "1.0", 8)
        self.create_parameter_entry(params_frame, "重力加速度 g (m/s²):", "g", "9.81", 9)

        # 初始条件
        ttk.Separator(params_frame, orient="horizontal").grid(
            row=10, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=10
        )
        ttk.Label(params_frame, text="初始条件:").grid(row=11, column=0, columnspan=2, sticky=tk.W)
        self.create_parameter_entry(params_frame, "角速度 p0:", "p0", "0.5", 12)
        self.create_parameter_entry(params_frame, "角速度 q0:", "q0", "0.1", 13)
        self.create_parameter_entry(params_frame, "角速度 r0:", "r0", "0.05", 14)
        self.create_parameter_entry(params_frame, "方向余弦 γ1:", "gamma1_0", "0.0", 15)
        self.create_parameter_entry(params_frame, "方向余弦 γ2:", "gamma2_0", "0.0", 16)
        self.create_parameter_entry(params_frame, "方向余弦 γ3:", "gamma3_0", "1.0", 17)

        # 求解参数
        ttk.Separator(params_frame, orient="horizontal").grid(
            row=18, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=10
        )
        self.create_parameter_entry(params_frame, "起始时间 t0:", "t0", "0.0", 19)
        self.create_parameter_entry(params_frame, "结束时间 t_end:", "t_end", "20.0", 20)
        self.create_parameter_entry(params_frame, "时间步长 dt:", "dt", "0.01", 21)

        # 数值方法选择
        ttk.Separator(params_frame, orient="horizontal").grid(
            row=22, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=10
        )
        ttk.Label(params_frame, text="数值方法:").grid(row=23, column=0, sticky=tk.W)
        method_combo = ttk.Combobox(
            params_frame,
            textvariable=self.method_var,
            values=["Euler", "ImprovedEuler", "RK4"],
            state="readonly",
            width=15,
        )
        method_combo.grid(row=23, column=1, sticky=(tk.W, tk.E), pady=5)
        method_combo.bind("<<ComboboxSelected>>", self.on_method_change)

        # 显示方法信息
        self.method_info_label = ttk.Label(params_frame, text="", foreground="blue")
        self.method_info_label.grid(row=24, column=0, columnspan=2, sticky=tk.W, pady=5)
        self.on_method_change(None)

        # 显示模式选择
        ttk.Separator(params_frame, orient="horizontal").grid(
            row=25, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=10
        )
        ttk.Label(params_frame, text="显示模式:").grid(row=26, column=0, sticky=tk.W)
        display_frame = ttk.Frame(params_frame)
        display_frame.grid(row=26, column=1, sticky=(tk.W, tk.E), pady=5)

        ttk.Radiobutton(
            display_frame,
            text="泊松变量 (γ)",
            variable=self.display_mode,
            value="poisson",
            command=self.on_display_mode_change
        ).pack(side=tk.LEFT, padx=5)

        ttk.Radiobutton(
            display_frame,
            text="欧拉角 (φ,θ,ψ)",
            variable=self.display_mode,
            value="euler",
            command=self.on_display_mode_change
        ).pack(side=tk.LEFT, padx=5)

        # 按钮
        button_frame = ttk.Frame(params_frame)
        button_frame.grid(row=27, column=0, columnspan=2, pady=20)

        self.solve_button = ttk.Button(button_frame, text="求解", command=self.solve)
        self.solve_button.pack(side=tk.LEFT, padx=5)

        ttk.Button(button_frame, text="清空", command=self.clear).pack(side=tk.LEFT, padx=5)

        ttk.Button(button_frame, text="导出数据", command=self.export_data).pack(
            side=tk.LEFT, padx=5
        )

        # 右侧绘图区域
        plot_frame = ttk.LabelFrame(main_frame, text="结果图形", padding="10")
        plot_frame.grid(row=0, column=1, sticky=(tk.W, tk.E, tk.N, tk.S))
        plot_frame.columnconfigure(0, weight=1)
        plot_frame.rowconfigure(0, weight=1)

        # 创建matplotlib图形
        self.figure = Figure(figsize=(10, 8), dpi=100)
        self.canvas = FigureCanvasTkAgg(self.figure, master=plot_frame)
        self.canvas.get_tk_widget().grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        # 初始化空图形
        self.init_plot()

        # 进度条
        self.progress = ttk.Progressbar(main_frame, mode="indeterminate")
        self.progress.grid(row=1, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(10, 0))

    def create_parameter_entry(self, parent, label_text, var_name, default_value, row):
        """创建参数输入框"""
        ttk.Label(parent, text=label_text).grid(row=row, column=0, sticky=tk.W, pady=2)

        var = tk.DoubleVar(value=float(default_value))
        setattr(self, f"{var_name}_var", var)

        entry = ttk.Entry(parent, textvariable=var, width=15)
        entry.grid(row=row, column=1, sticky=(tk.W, tk.E), pady=2)

    def on_method_change(self, event):
        """方法选择改变时的回调"""
        method = self.method_var.get()
        if method == "Euler":
            info = "显式欧拉法 - 一阶精度"
        elif method == "ImprovedEuler":
            info = "改进欧拉法 - 二阶精度"
        else:  # RK4
            info = "四阶Runge-Kutta法 - 四阶精度"
        self.method_info_label.config(text=info)

    def on_display_mode_change(self):
        """显示模式改变时的回调"""
        if self.results_t is not None and self.results_y is not None:
            if self.display_mode.get() == "euler" and self.results_euler is None:
                # 首次切换到欧拉角模式，计算欧拉角
                self.results_euler = LagrangePoissonSolver.poisson_to_euler_angles(
                    self.results_t, self.results_y
                )
            self.plot_results(self.results_t, self.results_y)

    def get_parameters(self):
        """获取所有参数"""
        return {
            "A": self.A_var.get(),
            "B": self.B_var.get(),
            "C": self.C_var.get(),
            "x0": self.x0_var.get(),
            "y0": self.y0_var.get(),
            "z0": self.z0_var.get(),
            "m": self.m_var.get(),
            "g": self.g_var.get(),
            "t0": self.t0_var.get(),
            "t_end": self.t_end_var.get(),
            "dt": self.dt_var.get(),
        }

    def get_initial_conditions(self):
        """获取初始条件"""
        return np.array(
            [
                self.p0_var.get(),
                self.q0_var.get(),
                self.r0_var.get(),
                self.gamma1_0_var.get(),
                self.gamma2_0_var.get(),
                self.gamma3_0_var.get(),
            ]
        )

    def solve(self):
        """执行求解"""
        try:
            # 获取参数
            params = self.get_parameters()
            initial_conditions = self.get_initial_conditions()

            # 验证参数
            if params["dt"] <= 0:
                raise ValueError("时间步长必须为正数")
            if params["t_end"] <= params["t0"]:
                raise ValueError("结束时间必须大于起始时间")

            # 创建求解器
            solver = LagrangePoissonSolver(
                A=params["A"],
                B=params["B"],
                C=params["C"],
                x0=params["x0"],
                y0=params["y0"],
                z0=params["z0"],
                m=params["m"],
                g=params["g"],
            )

            # 选择数值方法
            method = self.method_var.get()
            if method == "Euler":
                numerical_method = EulerMethod()
            elif method == "ImprovedEuler":
                numerical_method = ImprovedEulerMethod()
            else:  # RK4
                numerical_method = RK4Method()

            # 开始求解
            self.solve_button.config(state="disabled")
            self.progress.start()

            self.root.update()

            # 执行求解
            t, y = solver.solve(
                initial_conditions=initial_conditions,
                t_span=(params["t0"], params["t_end"]),
                dt=params["dt"],
                method=numerical_method,
            )

            self.results_t = t
            self.results_y = y

            # 计算欧拉角
            self.results_euler = LagrangePoissonSolver.poisson_to_euler_angles(t, y)

            # 绘制结果
            self.plot_results(t, y)

            self.progress.stop()
            self.solve_button.config(state="normal")

            messagebox.showinfo(
                "完成", f"求解完成！\n共计算 {len(t)} 个时间步\n使用方法: {numerical_method.get_name()}"
            )

        except Exception as e:
            self.progress.stop()
            self.solve_button.config(state="normal")
            messagebox.showerror("错误", f"求解失败: {str(e)}")

    def init_plot(self):
        """初始化空图形"""
        self.figure.clear()

        # 创建2x3子图
        for i, (title, ylabel) in enumerate(
            [
                ("角速度 p", "p (rad/s)"),
                ("角速度 q", "q (rad/s)"),
                ("角速度 r", "r (rad/s)"),
                ("方向余弦 γ₁", "γ₁"),
                ("方向余弦 γ₂", "γ₂"),
                ("方向余弦 γ₃", "γ₃"),
            ]
        ):
            ax = self.figure.add_subplot(2, 3, i + 1)
            ax.set_title(title)
            ax.set_xlabel("时间 (s)")
            ax.set_ylabel(ylabel)
            ax.grid(True, alpha=0.3)

        self.figure.tight_layout()
        self.canvas.draw()

    def plot_results(self, t, y):
        """绘制结果"""
        self.figure.clear()

        if self.display_mode.get() == "poisson":
            # 泊松变量模式
            labels = ["p (rad/s)", "q (rad/s)", "r (rad/s)", "γ₁", "γ₂", "γ₃"]
            titles = ["角速度 p", "角速度 q", "角速度 r", "方向余弦 γ₁", "方向余弦 γ₂", "方向余弦 γ₃"]

            for i in range(6):
                ax = self.figure.add_subplot(2, 3, i + 1)
                ax.plot(t, y[:, i], linewidth=1.5)
                ax.set_title(titles[i])
                ax.set_xlabel("时间 (s)")
                ax.set_ylabel(labels[i])
                ax.grid(True, alpha=0.3)

        elif self.display_mode.get() == "euler":
            # 欧拉角模式
            euler = self.results_euler
            labels = ["φ (rad)", "θ (rad)", "ψ (rad)", "φ (度)", "θ (度)", "ψ (度)"]
            titles = ["进动角 φ", "章动角 θ", "自转角 ψ", "进动角 φ", "章动角 θ", "自转角 ψ"]

            for i in range(3):
                # 弧度显示
                ax = self.figure.add_subplot(2, 3, i + 1)
                ax.plot(t, euler[:, i], linewidth=1.5, color=f'C{i}')
                ax.set_title(titles[i])
                ax.set_xlabel("时间 (s)")
                ax.set_ylabel(labels[i])
                ax.grid(True, alpha=0.3)

                # 角度显示
                ax = self.figure.add_subplot(2, 3, i + 4)
                ax.plot(t, np.degrees(euler[:, i]), linewidth=1.5, color=f'C{i}')
                ax.set_title(titles[i + 3])
                ax.set_xlabel("时间 (s)")
                ax.set_ylabel(labels[i + 3])
                ax.grid(True, alpha=0.3)

        self.figure.tight_layout()
        self.canvas.draw()

    def clear(self):
        """清空图形"""
        self.results_t = None
        self.results_y = None
        self.results_euler = None
        self.init_plot()

    def export_data(self):
        """导出数据到CSV文件"""
        if self.results_t is None or self.results_y is None:
            messagebox.showwarning("警告", "没有可导出的数据，请先执行求解！")
            return

        filename = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
            title="保存数据",
        )

        if filename:
            try:
                import csv

                with open(filename, "w", newline="", encoding="utf-8") as f:
                    writer = csv.writer(f)

                    # 根据显示模式决定导出内容
                    if self.display_mode.get() == "euler" and self.results_euler is not None:
                        # 导出欧拉角
                        writer.writerow([
                            "Time",
                            "phi_rad", "theta_rad", "psi_rad",
                            "phi_deg", "theta_deg", "psi_deg"
                        ])
                        for i in range(len(self.results_t)):
                            row = [
                                self.results_t[i],
                                self.results_euler[i, 0],
                                self.results_euler[i, 1],
                                self.results_euler[i, 2],
                                np.degrees(self.results_euler[i, 0]),
                                np.degrees(self.results_euler[i, 1]),
                                np.degrees(self.results_euler[i, 2])
                            ]
                            writer.writerow(row)
                    else:
                        # 导出泊松变量
                        writer.writerow(["Time", "p", "q", "r", "gamma1", "gamma2", "gamma3"])
                        for i in range(len(self.results_t)):
                            row = [self.results_t[i]] + list(self.results_y[i])
                            writer.writerow(row)

                messagebox.showinfo("成功", f"数据已保存到: {filename}")
            except Exception as e:
                messagebox.showerror("错误", f"导出失败: {str(e)}")


def main():
    """主函数"""
    root = tk.Tk()
    app = LagrangePoissonGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
