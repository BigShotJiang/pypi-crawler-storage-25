"""
拉格朗日-泊松问题求解器核心
Lagrange-Poisson Problem Solver Core
"""

import numpy as np
from typing import Callable, Tuple, List


class LagrangePoissonSolver:
    """
    拉格朗日-泊松问题求解器

    求解刚体绕定点在重力场中的运动
    """

    def __init__(
        self,
        A: float,
        B: float,
        C: float,
        x0: float,
        y0: float,
        z0: float,
        m: float = 1.0,
        g: float = 9.81,
    ):
        """
        初始化求解器

        Parameters:
        -----------
        A, B, C : float
            主转动惯量
        x0, y0, z0 : float
            质心在体坐标系中的坐标
        m : float
            质量
        g : float
            重力加速度
        """
        self.A = A
        self.B = B
        self.C = C
        self.x0 = x0
        self.y0 = y0
        self.z0 = z0
        self.m = m
        self.g = g

        # 预计算常数
        self.mg = m * g

    def _rhs(self, y: np.ndarray) -> np.ndarray:
        """
        计算右端函数 f(y)

        Parameters:
        -----------
        y : np.ndarray
            状态向量 [p, q, r, gamma1, gamma2, gamma3]

        Returns:
        --------
        np.ndarray
            导数 dy/dt
        """
        p, q, r, gamma1, gamma2, gamma3 = y

        # 欧拉动力学方程
        dp = (
            (self.B - self.C) / self.A * q * r
            + self.mg / self.A * (self.y0 * gamma3 - self.z0 * gamma2)
        )
        dq = (
            (self.C - self.A) / self.B * r * p
            + self.mg / self.B * (self.z0 * gamma1 - self.x0 * gamma3)
        )
        dr = (
            (self.A - self.B) / self.C * p * q
            + self.mg / self.C * (self.x0 * gamma2 - self.y0 * gamma1)
        )

        # 泊松方程（欧拉运动学方程）
        dgamma1 = r * gamma2 - q * gamma3
        dgamma2 = p * gamma3 - r * gamma1
        dgamma3 = q * gamma1 - p * gamma2

        return np.array([dp, dq, dr, dgamma1, dgamma2, dgamma3])

    def solve(
        self,
        initial_conditions: np.ndarray,
        t_span: Tuple[float, float],
        dt: float,
        method,
        callback: Callable = None,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        求解拉格朗日-泊松问题

        Parameters:
        -----------
        initial_conditions : np.ndarray
            初始状态 [p0, q0, r0, gamma1_0, gamma2_0, gamma3_0]
        t_span : tuple
            时间区间 (t_start, t_end)
        dt : float
            时间步长
        method : NumericalMethod
            数值方法对象
        callback : callable, optional
            回调函数，每次迭代后调用

        Returns:
        --------
        t : np.ndarray
            时间点数组
        y : np.ndarray
            状态数组，shape为 (n_steps, 6)
        """
        t_start, t_end = t_span
        n_steps = int((t_end - t_start) / dt) + 1

        t = np.linspace(t_start, t_end, n_steps)
        y = np.zeros((n_steps, 6))
        y[0] = initial_conditions

        # 定义右端函数（隐式传递当前参数）
        f = lambda state: self._rhs(state)

        for i in range(n_steps - 1):
            y[i + 1] = method.step(f, y[i], t[i], dt)

            # 可选：归一化方向余弦（保持单位向量）
            gamma = y[i + 1, 3:6]
            gamma_norm = np.linalg.norm(gamma)
            if gamma_norm > 0:
                y[i + 1, 3:6] = gamma / gamma_norm

            if callback:
                callback(i, t[i], y[i], dt)

        return t, y

    @staticmethod
    def normalize_gamma(y: np.ndarray) -> np.ndarray:
        """
        归一化方向余弦向量

        Parameters:
        -----------
        y : np.ndarray
            状态数组

        Returns:
        --------
        np.ndarray
            归一化后的状态数组
        """
        y_normalized = y.copy()
        for i in range(y.shape[0]):
            gamma = y[i, 3:6]
            gamma_norm = np.linalg.norm(gamma)
            if gamma_norm > 0:
                y_normalized[i, 3:6] = gamma / gamma_norm
        return y_normalized

    @staticmethod
    def poisson_to_euler_angles(
        t: np.ndarray,
        y: np.ndarray,
        phi0: float = 0.0,
        handle_singular: bool = True,
        singular_threshold: float = 1e-6
    ) -> np.ndarray:
        """
        将泊松变量转换为欧拉角

        根据刚体动力学中的欧拉角定义（3-1-3或类似约定）：
        - φ: 进动角
        - θ: 章动角
        - ψ: 自转角

        转换关系：
        γ₁ = sin(θ)·sin(ψ)
        γ₂ = sin(θ)·cos(ψ)
        γ₃ = cos(θ)

        Parameters:
        -----------
        t : np.ndarray
            时间点数组，shape (n_steps,)
        y : np.ndarray
            状态数组，shape (n_steps, 6)
            包含 [p, q, r, γ₁, γ₂, γ₃]
        phi0 : float
            初始进动角 φ (默认 0.0)
        handle_singular : bool
            是否处理奇异点（sinθ ≈ 0）
        singular_threshold : float
            判断奇异点的阈值

        Returns:
        --------
        euler_angles : np.ndarray
            欧拉角数组，shape (n_steps, 3)
            包含 [φ, θ, ψ] 单位：弧度
        """
        n_steps = len(t)
        euler_angles = np.zeros((n_steps, 3))

        # 提取变量
        p = y[:, 0]
        q = y[:, 1]
        gamma1 = y[:, 3]
        gamma2 = y[:, 4]
        gamma3 = y[:, 5]

        # 计算章动角 θ = arccos(γ₃)
        theta = np.arccos(np.clip(gamma3, -1.0, 1.0))

        # 计算自转角 ψ = atan2(γ₁, γ₂)
        psi = np.arctan2(gamma1, gamma2)

        # 计算进动角 φ 的导数并积分
        # φ̇ = (p·γ₁ + q·γ₂) / (γ₁² + γ₂²)
        phi = np.zeros(n_steps)
        phi[0] = phi0

        for i in range(n_steps - 1):
            dt = t[i + 1] - t[i]

            # 计算 sin²θ = γ₁² + γ₂²
            sin2_theta = gamma1[i]**2 + gamma2[i]**2

            if handle_singular and sin2_theta < singular_threshold**2:
                # 奇异点附近：保持 φ 不变或使用外推
                phi[i + 1] = phi[i]
            else:
                # 正常情况：φ̇ = (p·γ₁ + q·γ₂) / (γ₁² + γ₂²)
                phi_dot = (p[i] * gamma1[i] + q[i] * gamma2[i]) / sin2_theta
                phi[i + 1] = phi[i] + phi_dot * dt

        # 组合结果 [φ, θ, ψ]
        euler_angles[:, 0] = phi
        euler_angles[:, 1] = theta
        euler_angles[:, 2] = psi

        return euler_angles

    @staticmethod
    def poisson_to_euler_angles_simple(
        y: np.ndarray
    ) -> np.ndarray:
        """
        简化版：仅从泊松变量计算两个欧拉角 θ 和 ψ

        注意：此方法不计算 φ，因为它需要角速度信息

        Parameters:
        -----------
        y : np.ndarray
            状态数组，shape (n_steps, 6)

        Returns:
        --------
        euler_angles_partial : np.ndarray
            部分欧拉角数组，shape (n_steps, 2)
            包含 [θ, ψ] 单位：弧度
        """
        gamma1 = y[:, 3]
        gamma2 = y[:, 4]
        gamma3 = y[:, 5]

        # θ = arccos(γ₃)
        theta = np.arccos(np.clip(gamma3, -1.0, 1.0))

        # ψ = atan2(γ₁, γ₂)
        psi = np.arctan2(gamma1, gamma2)

        return np.column_stack([theta, psi])

    @staticmethod
    def compute_phi_dot(
        y: np.ndarray
    ) -> np.ndarray:
        """
        计算进动角 φ 的时间导数

        Parameters:
        -----------
        y : np.ndarray
            状态数组，shape (n_steps, 6)

        Returns:
        --------
        phi_dot : np.ndarray
            φ 的导数数组，shape (n_steps,)
        """
        p = y[:, 0]
        q = y[:, 1]
        gamma1 = y[:, 3]
        gamma2 = y[:, 4]

        # sin²θ = γ₁² + γ₂²
        sin2_theta = gamma1**2 + gamma2**2

        # φ̇ = (p·γ₁ + q·γ₂) / (γ₁² + γ₂²)
        phi_dot = np.zeros_like(sin2_theta)
        mask = sin2_theta > 1e-12  # 避免除零

        phi_dot[mask] = (p[mask] * gamma1[mask] + q[mask] * gamma2[mask]) / sin2_theta[mask]

        return phi_dot

    @staticmethod
    def euler_angles_to_poisson(
        phi: float,
        theta: float,
        psi: float
    ) -> np.ndarray:
        """
        将欧拉角转换为泊松变量（方向余弦）

        转换关系：
        γ₁ = sin(θ)·sin(ψ)
        γ₂ = sin(θ)·cos(ψ)
        γ₃ = cos(θ)

        注意：φ 不影响泊松变量，只影响角速度关系

        Parameters:
        -----------
        phi : float
            进动角 (rad) - 此参数保留用于一致性，但不影响γ
        theta : float
            章动角 (rad)
        psi : float
            自转角 (rad)

        Returns:
        --------
        gamma : np.ndarray
            泊松变量 [γ₁, γ₂, γ₃]
        """
        gamma1 = np.sin(theta) * np.sin(psi)
        gamma2 = np.sin(theta) * np.cos(psi)
        gamma3 = np.cos(theta)

        return np.array([gamma1, gamma2, gamma3])

    @staticmethod
    def euler_to_rotation_matrix(
        phi: float,
        theta: float,
        psi: float
    ) -> np.ndarray:
        """
        计算欧拉角对应的旋转矩阵（从空间坐标系到体坐标系）

        使用 z-x-z 约定（3-1-3欧拉角）

        Parameters:
        -----------
        phi : float
            进动角 (rad)
        theta : float
            章动角 (rad)
        psi : float
            自转角 (rad)

        Returns:
        --------
        R : np.ndarray
            3x3旋转矩阵
        """
        cphi, sphi = np.cos(phi), np.sin(phi)
        ctheta, stheta = np.cos(theta), np.sin(theta)
        cpsi, spsi = np.cos(psi), np.sin(psi)

        # z-x-z 欧拉角旋转矩阵
        R = np.array([
            [cphi*cpsi - sphi*ctheta*spsi,  -cphi*spsi - sphi*ctheta*cpsi,  sphi*stheta],
            [sphi*cpsi + cphi*ctheta*spsi,  -sphi*spsi + cphi*ctheta*cpsi, -cphi*stheta],
            [stheta*spsi,                    stheta*cpsi,                    ctheta]
        ])

        return R

    @staticmethod
    def get_body_axes(
        phi: float,
        theta: float,
        psi: float
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        获取体坐标系三个轴在空间坐标系中的表示

        Parameters:
        -----------
        phi, theta, psi : float
            欧拉角 (rad)

        Returns:
        --------
        x_body, y_body, z_body : tuple of np.ndarray
            体轴x, y, z在空间坐标系中的单位向量
        """
        R = LagrangePoissonSolver.euler_to_rotation_matrix(phi, theta, psi)

        # 体轴在空间坐标系中的表示（R的列向量）
        x_body = R[:, 0]  # 体x轴
        y_body = R[:, 1]  # 体y轴
        z_body = R[:, 2]  # 体z轴

        return x_body, y_body, z_body
