"""
数值方法实现
Numerical Methods Implementation
"""

import numpy as np
from abc import ABC, abstractmethod


class NumericalMethod(ABC):
    """数值方法抽象基类"""

    @abstractmethod
    def step(self, f, y, t, h):
        """
        执行单步递推

        Parameters:
        -----------
        f : callable
            右端函数 f(t, y)
        y : np.ndarray
            当前状态向量
        t : float
            当前时间
        h : float
            步长

        Returns:
        --------
        np.ndarray
            下一步状态向量
        """
        pass

    @abstractmethod
    def get_name(self):
        """获取方法名称"""
        pass

    @abstractmethod
    def get_order(self):
        """获取方法精度阶数"""
        pass


class EulerMethod(NumericalMethod):
    """显式欧拉法 (一阶精度)"""

    def step(self, f, y, t, h):
        return y + h * f(y)

    def get_name(self):
        return "显式欧拉法"

    def get_order(self):
        return 1


class ImprovedEulerMethod(NumericalMethod):
    """改进欧拉法 / Heun方法 (二阶精度)"""

    def step(self, f, y, t, h):
        k1 = f(y)
        y_predict = y + h * k1
        k2 = f(y_predict)
        return y + (h / 2) * (k1 + k2)

    def get_name(self):
        return "改进欧拉法"

    def get_order(self):
        return 2


class RK4Method(NumericalMethod):
    """四阶Runge-Kutta法 (四阶精度)"""

    def step(self, f, y, t, h):
        k1 = f(y)
        k2 = f(y + (h / 2) * k1)
        k3 = f(y + (h / 2) * k2)
        k4 = f(y + h * k3)
        return y + (h / 6) * (k1 + 2 * k2 + 2 * k3 + k4)

    def get_name(self):
        return "四阶 Runge-Kutta (RK4)"

    def get_order(self):
        return 4
