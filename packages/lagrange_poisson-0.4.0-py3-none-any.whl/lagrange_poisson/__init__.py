"""
拉格朗日-泊松问题求解器
Lagrange-Poisson Problem Solver

一个用于求解刚体绕定点运动的数值计算工具包
"""

__version__ = "0.4.0"
__author__ = "Your Name"

from .solver import LagrangePoissonSolver
from .numerical_methods import EulerMethod, ImprovedEulerMethod, RK4Method

__all__ = [
    "LagrangePoissonSolver",
    "EulerMethod",
    "ImprovedEulerMethod",
    "RK4Method",
]
