# -*- coding: utf-8 -*-
"""
增强版图形用户界面
Enhanced Graphical User Interface

功能：
- 欧拉角输入
- 3D动画显示
- 泊松变量/欧拉角切换显示
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import matplotlib.animation as animation
from mpl_toolkits.mplot3d import Axes3D
import matplotlib
from threading import Thread
import queue

# 使用中文字体支持
matplotlib.rcParams["font.sans-serif"] = ["SimHei", "Microsoft YaHei", "Arial Unicode MS"]
matplotlib.rcParams["axes.unicode_minus"] = False

from .solver import LagrangePoissonSolver
from .numerical_methods import EulerMethod, ImprovedEulerMethod, RK4Method


class EnhancedLagrangePoissonGUI:
    """拉格朗日-泊松问题求解器增强版GUI"""

    def __init__(self, root):
        self.root = root
        self.root.title("拉格朗日-泊松问题求解器 - 增强版")
        self.root.geometry("1400x900")

        # 初始化变量
        self.method_var = tk.StringVar(value="RK4")
        self.input_mode = tk.StringVar(value="euler")  # "euler" 或 "poisson"
        self.display_mode = tk.StringVar(value="euler")
        self.show_animation = tk.BooleanVar(value=True)

        self.results_t = None
        self.results_y = None
        self.results_euler = None
        self.animation = None
        self.anim_queue = queue.Queue()

        # 创建界面
        self.create_widgets()

    def create_widgets(self):
        """创建界面组件"""
        # 主容器
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        # 配置网格权重
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        main_frame.rowconfigure(0, weight=1)

        # === 左侧参数面板 ===
        params_frame = ttk.LabelFrame(main_frame, text="参数设置", padding="10")
        params_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), padx=(0, 10))

        row_idx = 0

        # 转动惯量
        self.create_parameter_entry(params_frame, "主转动惯量 A:", "A", "1.0", row_idx)
        row_idx += 1
        self.create_parameter_entry(params_frame, "主转动惯量 B:", "B", "2.0", row_idx)
        row_idx += 1
        self.create_parameter_entry(params_frame, "主转动惯量 C:", "C", "3.0", row_idx)
        row_idx += 1

        ttk.Separator(params_frame, orient="horizontal").grid(
            row=row_idx, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=10
        )
        row_idx += 1

        # 质心坐标
        self.create_parameter_entry(params_frame, "质心坐标 x0:", "x0", "0.1", row_idx)
        row_idx += 1
        self.create_parameter_entry(params_frame, "质心坐标 y0:", "y0", "0.0", row_idx)
        row_idx += 1
        self.create_parameter_entry(params_frame, "质心坐标 z0:", "z0", "0.0", row_idx)
        row_idx += 1

        ttk.Separator(params_frame, orient="horizontal").grid(
            row=row_idx, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=10
        )
        row_idx += 1

        # 物理参数
        self.create_parameter_entry(params_frame, "质量 m (kg):", "m", "1.0", row_idx)
        row_idx += 1
        self.create_parameter_entry(params_frame, "重力加速度 g (m/s²):", "g", "9.81", row_idx)
        row_idx += 1

        ttk.Separator(params_frame, orient="horizontal").grid(
            row=row_idx, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=10
        )
        row_idx += 1

        # === 输入模式选择 ===
        ttk.Label(params_frame, text="输入模式:").grid(row=row_idx, column=0, sticky=tk.W)
        row_idx += 1
        input_frame = ttk.Frame(params_frame)
        input_frame.grid(row=row_idx, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5)
        row_idx += 1

        ttk.Radiobutton(
            input_frame,
            text="欧拉角 (直观)",
            variable=self.input_mode,
            value="euler",
            command=self.on_input_mode_change
        ).pack(side=tk.LEFT, padx=5)

        ttk.Radiobutton(
            input_frame,
            text="泊松变量 (专业)",
            variable=self.input_mode,
            value="poisson",
            command=self.on_input_mode_change
        ).pack(side=tk.LEFT, padx=5)

        # === 初始条件容器 ===
        self.initial_conditions_frame = ttk.LabelFrame(params_frame, text="初始条件", padding="5")
        self.initial_conditions_frame.grid(row=row_idx, column=0, columnspan=2, sticky=(tk.W, tk.E))
        row_idx += 1

        # 动态创建初始条件输入框
        self.initial_entries = {}
        self.create_initial_condition_inputs("euler")

        ttk.Separator(params_frame, orient="horizontal").grid(
            row=row_idx, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=10
        )
        row_idx += 1

        # 求解参数
        self.create_parameter_entry(params_frame, "起始时间 t0:", "t0", "0.0", row_idx)
        row_idx += 1
        self.create_parameter_entry(params_frame, "结束时间 t_end:", "t_end", "20.0", row_idx)
        row_idx += 1
        self.create_parameter_entry(params_frame, "时间步长 dt:", "dt", "0.01", row_idx)
        row_idx += 1

        ttk.Separator(params_frame, orient="horizontal").grid(
            row=row_idx, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=10
        )
        row_idx += 1

        # 数值方法选择
        ttk.Label(params_frame, text="数值方法:").grid(row=row_idx, column=0, sticky=tk.W)
        row_idx += 1
        method_combo = ttk.Combobox(
            params_frame,
            textvariable=self.method_var,
            values=["Euler", "ImprovedEuler", "RK4"],
            state="readonly",
            width=15,
        )
        method_combo.grid(row=row_idx, column=1, sticky=(tk.W, tk.E), pady=5)
        row_idx += 1
        method_combo.bind("<<ComboboxSelected>>", self.on_method_change)

        self.method_info_label = ttk.Label(params_frame, text="", foreground="blue")
        self.method_info_label.grid(row=row_idx, column=0, columnspan=2, sticky=tk.W, pady=5)
        row_idx += 1
        self.on_method_change(None)

        # 显示选项
        ttk.Separator(params_frame, orient="horizontal").grid(
            row=row_idx, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=10
        )
        row_idx += 1

        ttk.Label(params_frame, text="显示选项:").grid(row=row_idx, column=0, sticky=tk.W)
        row_idx += 1

        ttk.Checkbutton(
            params_frame,
            text="显示3D动画",
            variable=self.show_animation
        ).grid(row=row_idx, column=0, columnspan=2, sticky=tk.W)
        row_idx += 1

        ttk.Label(params_frame, text="显示模式:").grid(row=row_idx, column=0, sticky=tk.W)
        row_idx += 1
        display_frame = ttk.Frame(params_frame)
        display_frame.grid(row=row_idx, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5)
        row_idx += 1

        ttk.Radiobutton(
            display_frame,
            text="欧拉角",
            variable=self.display_mode,
            value="euler",
            command=self.on_display_mode_change
        ).pack(side=tk.LEFT, padx=5)

        ttk.Radiobutton(
            display_frame,
            text="泊松变量",
            variable=self.display_mode,
            value="poisson",
            command=self.on_display_mode_change
        ).pack(side=tk.LEFT, padx=5)

        # 按钮
        ttk.Separator(params_frame, orient="horizontal").grid(
            row=row_idx, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=10
        )
        row_idx += 1

        button_frame = ttk.Frame(params_frame)
        button_frame.grid(row=row_idx, column=0, columnspan=2, pady=20)

        self.solve_button = ttk.Button(button_frame, text="求解", command=self.solve)
        self.solve_button.pack(side=tk.LEFT, padx=5)

        ttk.Button(button_frame, text="清空", command=self.clear).pack(side=tk.LEFT, padx=5)

        ttk.Button(button_frame, text="导出数据", command=self.export_data).pack(
            side=tk.LEFT, padx=5
        )

        ttk.Button(button_frame, text="播放动画", command=self.play_animation).pack(
            side=tk.LEFT, padx=5
        )

        # === 右侧绘图区域 ===
        plot_frame = ttk.LabelFrame(main_frame, text="结果图形", padding="10")
        plot_frame.grid(row=0, column=1, sticky=(tk.W, tk.E, tk.N, tk.S))
        plot_frame.columnconfigure(0, weight=1)
        plot_frame.rowconfigure(0, weight=1)

        # 创建matplotlib图形
        self.figure = Figure(figsize=(12, 8), dpi=100)
        self.canvas = FigureCanvasTkAgg(self.figure, master=plot_frame)
        self.canvas.get_tk_widget().grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        # 初始化空图形
        self.init_plot()

        # 进度条
        self.progress = ttk.Progressbar(main_frame, mode="indeterminate")
        self.progress.grid(row=1, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(10, 0))

    def create_parameter_entry(self, parent, label_text, var_name, default_value, row):
        """创建参数输入框"""
        ttk.Label(parent, text=label_text).grid(row=row, column=0, sticky=tk.W, pady=2)

        var = tk.DoubleVar(value=float(default_value))
        setattr(self, f"{var_name}_var", var)

        entry = ttk.Entry(parent, textvariable=var, width=15)
        entry.grid(row=row, column=1, sticky=(tk.W, tk.E), pady=2)

    def create_initial_condition_inputs(self, mode):
        """根据输入模式创建初始条件输入框"""
        # 清空现有输入框
        for widget in self.initial_conditions_frame.winfo_children():
            widget.destroy()
        self.initial_entries.clear()

        if mode == "euler":
            # 欧拉角输入
            labels = [
                ("角速度 p0 (rad/s):", "p0", "0.5"),
                ("角速度 q0 (rad/s):", "q0", "0.1"),
                ("角速度 r0 (rad/s):", "r0", "0.05"),
                ("进动角 φ0 (度):", "phi0", "0.0"),
                ("章动角 θ0 (度):", "theta0", "30.0"),
                ("自转角 ψ0 (度):", "psi0", "0.0"),
            ]
        else:
            # 泊松变量输入
            labels = [
                ("角速度 p0 (rad/s):", "p0", "0.5"),
                ("角速度 q0 (rad/s):", "q0", "0.1"),
                ("角速度 r0 (rad/s):", "r0", "0.05"),
                ("方向余弦 γ1:", "gamma1_0", "0.0"),
                ("方向余弦 γ2:", "gamma2_0", "0.0"),
                ("方向余弦 γ3:", "gamma3_0", "1.0"),
            ]

        for i, (label, var_name, default) in enumerate(labels):
            ttk.Label(self.initial_conditions_frame, text=label).grid(
                row=i//2, column=(i%2)*2, sticky=tk.W, padx=2, pady=2
            )
            var = tk.DoubleVar(value=float(default))
            self.initial_entries[var_name] = var
            ttk.Entry(self.initial_conditions_frame, textvariable=var, width=10).grid(
                row=i//2, column=(i%2)*2+1, sticky=tk.W, padx=2, pady=2
            )

    def on_input_mode_change(self):
        """输入模式改变时的回调"""
        self.create_initial_condition_inputs(self.input_mode.get())

    def on_method_change(self, event):
        """方法选择改变时的回调"""
        method = self.method_var.get()
        if method == "Euler":
            info = "显式欧拉法 - 一阶精度"
        elif method == "ImprovedEuler":
            info = "改进欧拉法 - 二阶精度"
        else:  # RK4
            info = "四阶Runge-Kutta法 - 四阶精度"
        self.method_info_label.config(text=info)

    def on_display_mode_change(self):
        """显示模式改变时的回调"""
        if self.results_t is not None and self.results_y is not None:
            if self.display_mode.get() == "euler" and self.results_euler is None:
                self.results_euler = LagrangePoissonSolver.poisson_to_euler_angles(
                    self.results_t, self.results_y
                )
            self.plot_results(self.results_t, self.results_y)

    def get_parameters(self):
        """获取所有参数"""
        return {
            "A": self.A_var.get(),
            "B": self.B_var.get(),
            "C": self.C_var.get(),
            "x0": self.x0_var.get(),
            "y0": self.y0_var.get(),
            "z0": self.z0_var.get(),
            "m": self.m_var.get(),
            "g": self.g_var.get(),
            "t0": self.t0_var.get(),
            "t_end": self.t_end_var.get(),
            "dt": self.dt_var.get(),
        }

    def get_initial_conditions(self):
        """获取初始条件"""
        p0 = self.initial_entries["p0"].get()
        q0 = self.initial_entries["q0"].get()
        r0 = self.initial_entries["r0"].get()

        if self.input_mode.get() == "euler":
            # 欧拉角模式：转换为泊松变量
            phi0 = np.radians(self.initial_entries["phi0"].get())
            theta0 = np.radians(self.initial_entries["theta0"].get())
            psi0 = np.radians(self.initial_entries["psi0"].get())

            gamma = LagrangePoissonSolver.euler_angles_to_poisson(phi0, theta0, psi0)
            gamma1_0, gamma2_0, gamma3_0 = gamma[0], gamma[1], gamma[2]

            # 保存初始欧拉角用于后续恢复φ
            self.initial_phi0 = phi0
        else:
            # 泊松变量模式
            gamma1_0 = self.initial_entries["gamma1_0"].get()
            gamma2_0 = self.initial_entries["gamma2_0"].get()
            gamma3_0 = self.initial_entries["gamma3_0"].get()

            # 从泊松变量计算初始欧拉角
            theta0 = np.arccos(np.clip(gamma3_0, -1.0, 1.0))
            psi0 = np.arctan2(gamma1_0, gamma2_0)
            self.initial_phi0 = 0.0  # 泊松变量无法确定初始φ

        return np.array([p0, q0, r0, gamma1_0, gamma2_0, gamma3_0])

    def solve(self):
        """执行求解"""
        try:
            # 获取参数
            params = self.get_parameters()
            initial_conditions = self.get_initial_conditions()

            # 验证参数
            if params["dt"] <= 0:
                raise ValueError("时间步长必须为正数")
            if params["t_end"] <= params["t0"]:
                raise ValueError("结束时间必须大于起始时间")

            # 创建求解器
            solver = LagrangePoissonSolver(
                A=params["A"],
                B=params["B"],
                C=params["C"],
                x0=params["x0"],
                y0=params["y0"],
                z0=params["z0"],
                m=params["m"],
                g=params["g"],
            )

            # 选择数值方法
            method = self.method_var.get()
            if method == "Euler":
                numerical_method = EulerMethod()
            elif method == "ImprovedEuler":
                numerical_method = ImprovedEulerMethod()
            else:  # RK4
                numerical_method = RK4Method()

            # 开始求解
            self.solve_button.config(state="disabled")
            self.progress.start()

            self.root.update()

            # 执行求解
            t, y = solver.solve(
                initial_conditions=initial_conditions,
                t_span=(params["t0"], params["t_end"]),
                dt=params["dt"],
                method=numerical_method,
            )

            self.results_t = t
            self.results_y = y

            # 计算欧拉角
            self.results_euler = solver.poisson_to_euler_angles(
                t, y, phi0=self.initial_phi0
            )

            # 绘制结果
            self.plot_results(t, y)

            self.progress.stop()
            self.solve_button.config(state="normal")

            messagebox.showinfo(
                "完成",
                f"求解完成！\n共计算 {len(t)} 个时间步\n使用方法: {numerical_method.get_name()}"
            )

        except Exception as e:
            self.progress.stop()
            self.solve_button.config(state="normal")
            messagebox.showerror("错误", f"求解失败: {str(e)}")

    def init_plot(self):
        """初始化空图形"""
        self.figure.clear()

        # 创建2x3子图
        for i, (title, ylabel) in enumerate(
            [
                ("角速度 p", "p (rad/s)"),
                ("角速度 q", "q (rad/s)"),
                ("角速度 r", "r (rad/s)"),
                ("进动角 φ", "φ (°)"),
                ("章动角 θ", "θ (°)"),
                ("自转角 ψ", "ψ (°)"),
            ]
        ):
            ax = self.figure.add_subplot(2, 3, i + 1)
            ax.set_title(title)
            ax.set_xlabel("时间 (s)")
            ax.set_ylabel(ylabel)
            ax.grid(True, alpha=0.3)

        self.figure.tight_layout()
        self.canvas.draw()

    def plot_results(self, t, y):
        """绘制结果"""
        self.figure.clear()

        if self.display_mode.get() == "poisson":
            # 泊松变量模式
            labels = ["p (rad/s)", "q (rad/s)", "r (rad/s)", "γ₁", "γ₂", "γ₃"]
            titles = ["角速度 p", "角速度 q", "角速度 r", "方向余弦 γ₁", "方向余弦 γ₂", "方向余弦 γ₃"]

            for i in range(6):
                ax = self.figure.add_subplot(2, 3, i + 1)
                ax.plot(t, y[:, i], linewidth=1.5)
                ax.set_title(titles[i])
                ax.set_xlabel("时间 (s)")
                ax.set_ylabel(labels[i])
                ax.grid(True, alpha=0.3)

        elif self.display_mode.get() == "euler":
            # 欧拉角模式
            euler = self.results_euler

            # 角速度
            for i in range(3):
                ax = self.figure.add_subplot(2, 3, i + 1)
                ax.plot(t, y[:, i], linewidth=1.5, color=f'C{i}')
                ax.set_title(['角速度 p', '角速度 q', '角速度 r'][i])
                ax.set_xlabel("时间 (s)")
                ax.set_ylabel(['p (rad/s)', 'q (rad/s)', 'r (rad/s)'][i])
                ax.grid(True, alpha=0.3)

            # 欧拉角（角度制）
            labels_euler = ["φ (°)", "θ (°)", "ψ (°)"]
            titles_euler = ["进动角 φ", "章动角 θ", "自转角 ψ"]

            for i in range(3):
                ax = self.figure.add_subplot(2, 3, i + 4)
                ax.plot(t, np.degrees(euler[:, i]), linewidth=1.5, color=f'C{i+3}')
                ax.set_title(titles_euler[i])
                ax.set_xlabel("时间 (s)")
                ax.set_ylabel(labels_euler[i])
                ax.grid(True, alpha=0.3)

        self.figure.tight_layout()
        self.canvas.draw()

    def clear(self):
        """清空图形"""
        self.results_t = None
        self.results_y = None
        self.results_euler = None
        if self.animation:
            self.animation.event_source.stop()
            self.animation = None
        self.init_plot()

    def export_data(self):
        """导出数据到CSV文件"""
        if self.results_t is None or self.results_y is None:
            messagebox.showwarning("警告", "没有可导出的数据，请先执行求解！")
            return

        filename = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
            title="保存数据",
        )

        if filename:
            try:
                import csv

                with open(filename, "w", newline="", encoding="utf-8") as f:
                    writer = csv.writer(f)

                    if self.display_mode.get() == "euler" and self.results_euler is not None:
                        # 导出欧拉角
                        writer.writerow([
                            "Time",
                            "p", "q", "r",
                            "phi_rad", "theta_rad", "psi_rad",
                            "phi_deg", "theta_deg", "psi_deg"
                        ])
                        for i in range(len(self.results_t)):
                            row = [
                                self.results_t[i],
                                self.results_y[i, 0], self.results_y[i, 1], self.results_y[i, 2],
                                self.results_euler[i, 0], self.results_euler[i, 1], self.results_euler[i, 2],
                                np.degrees(self.results_euler[i, 0]),
                                np.degrees(self.results_euler[i, 1]),
                                np.degrees(self.results_euler[i, 2])
                            ]
                            writer.writerow(row)
                    else:
                        # 导出泊松变量
                        writer.writerow(["Time", "p", "q", "r", "gamma1", "gamma2", "gamma3"])
                        for i in range(len(self.results_t)):
                            row = [self.results_t[i]] + list(self.results_y[i])
                            writer.writerow(row)

                messagebox.showinfo("成功", f"数据已保存到: {filename}")
            except Exception as e:
                messagebox.showerror("错误", f"导出失败: {str(e)}")

    def play_animation(self):
        """播放3D动画"""
        if self.results_euler is None:
            messagebox.showwarning("警告", "请先执行求解！")
            return

        # 创建动画窗口
        anim_window = tk.Toplevel(self.root)
        anim_window.title("3D陀螺运动动画")
        anim_window.geometry("800x600")

        # 创建matplotlib图形
        fig = Figure(figsize=(8, 6), dpi=100)
        canvas = FigureCanvasTkAgg(fig, master=anim_window)
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

        ax = fig.add_subplot(111, projection='3d')

        # 降采样以提高动画性能
        skip = max(1, len(self.results_t) // 200)
        t_anim = self.results_t[::skip]
        euler_anim = self.results_euler[::skip]

        # 绘制初始状态
        self._update_3d_gyro(ax, euler_anim[0])
        ax.set_title("陀螺运动 - 3D动画")
        ax.set_xlabel("X")
        ax.set_ylabel("Y")
        ax.set_zlabel("Z")

        # 设置等比例
        max_range = 1.5
        ax.set_xlim(-max_range, max_range)
        ax.set_ylim(-max_range, max_range)
        ax.set_zlim(-max_range, max_range)

        canvas.draw()

        def update(frame):
            ax.clear()
            self._update_3d_gyro(ax, euler_anim[frame])
            ax.set_title(f"陀螺运动 - t = {t_anim[frame]:.2f} s")
            ax.set_xlim(-max_range, max_range)
            ax.set_ylim(-max_range, max_range)
            ax.set_zlim(-max_range, max_range)
            ax.set_xlabel("X")
            ax.set_ylabel("Y")
            ax.set_zlabel("Z")
            canvas.draw()

        def play():
            for i in range(len(euler_anim)):
                update(i)
                anim_window.update()
                anim_window.after(20)  # 控制帧率

        # 在新线程中播放动画
        Thread(target=play, daemon=True).start()

    def _update_3d_gyro(self, ax, euler_angles):
        """更新3D陀螺图形"""
        phi, theta, psi = euler_angles

        # 获取体轴
        x_body, y_body, z_body = LagrangePoissonSolver.get_body_axes(phi, theta, psi)

        # 绘制体轴（箭头）
        axis_length = 1.0
        ax.quiver(0, 0, 0, x_body[0], x_body[1], x_body[2],
                 length=axis_length, color='r', label='X轴', arrow_length_ratio=0.1)
        ax.quiver(0, 0, 0, y_body[0], y_body[1], y_body[2],
                 length=axis_length, color='g', label='Y轴', arrow_length_ratio=0.1)
        ax.quiver(0, 0, 0, z_body[0], z_body[1], z_body[2],
                 length=axis_length, color='b', label='Z轴', arrow_length_ratio=0.1)

        # 绘制重力方向（固定向上）
        ax.quiver(0, 0, 0, 0, 0, 1,
                 length=1.2, color='k', linestyle='--', label='重力方向', arrow_length_ratio=0.1)

        # 绘制一个简单的刚体（椭球）轮廓
        u = np.linspace(0, 2 * np.pi, 20)
        v = np.linspace(0, np.pi, 10)
        x = 0.3 * np.outer(np.cos(u), np.sin(v))
        y = 0.2 * np.outer(np.sin(u), np.sin(v))
        z = 0.4 * np.outer(np.ones(np.size(u)), np.cos(v))

        # 旋转椭球
        R = LagrangePoissonSolver.euler_to_rotation_matrix(phi, theta, psi)
        for i in range(x.shape[0]):
            for j in range(x.shape[1]):
                point = np.array([x[i,j], y[i,j], z[i,j]])
                rotated = R @ point
                x[i,j], y[i,j], z[i,j] = rotated

        ax.plot_wireframe(x, y, z, color='c', alpha=0.3)

        # 添加轨迹提示
        time_text = f"φ={np.degrees(phi):.1f}° θ={np.degrees(theta):.1f}° ψ={np.degrees(psi):.1f}°"
        ax.text2D(0.05, 0.95, time_text, transform=ax.transAxes)


def main():
    """主函数"""
    root = tk.Tk()
    app = EnhancedLagrangePoissonGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
