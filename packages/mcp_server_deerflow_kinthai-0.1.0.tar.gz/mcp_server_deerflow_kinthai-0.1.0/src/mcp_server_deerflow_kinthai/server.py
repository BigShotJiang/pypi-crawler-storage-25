"""MCP Server that exposes DeerFlow deep capabilities via standard MCP protocol.

Uses the official ``mcp`` Python SDK with SSE transport so that any MCP
client (OpenClaw, Claude Desktop, Cursor, etc.) can discover and invoke
DeerFlow skills: deep-research, data-analysis, chart-visualization,
ppt-generation, image-generation, and consulting-analysis.

Usage:
    # Standalone (SSE on port 8808)
    python -m mcp_server_deerflow_kinthai

    # Or mount in an existing FastAPI/Starlette app
    from mcp_server_deerflow_kinthai.server import create_starlette_app
    app.mount("/mcp", create_starlette_app())

Author: freddy@kinthai.ai
Website: https://kinthai.ai
License: MIT
"""

import logging
import os
from typing import Any

from mcp import types
from mcp.server import Server

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# DeerFlow LangGraph client helpers
# ---------------------------------------------------------------------------

_langgraph_client = None


def _get_langgraph_url() -> str:
    return (
        os.getenv("DEERFLOW_LANGGRAPH_URL")
        or os.getenv("DEER_FLOW_CHANNELS_LANGGRAPH_URL")
        or os.getenv("DEER_FLOW_INTERNAL_LANGGRAPH_BASE_URL")
        or "http://localhost:2024"
    )


def _get_gateway_base_url() -> str:
    return (
        os.getenv("DEERFLOW_GATEWAY_URL")
        or os.getenv("DEER_FLOW_CHANNELS_GATEWAY_URL")
        or os.getenv("DEER_FLOW_INTERNAL_GATEWAY_BASE_URL")
        or "http://localhost:8001"
    )


async def _get_client():
    global _langgraph_client
    if _langgraph_client is None:
        from langgraph_sdk import get_client
        _langgraph_client = get_client(url=_get_langgraph_url())
    return _langgraph_client


# ---------------------------------------------------------------------------
# Response extraction (ported from DeerFlow ChannelManager)
# ---------------------------------------------------------------------------

def _extract_response_text(result: dict | list) -> str:
    if isinstance(result, list):
        messages = result
    elif isinstance(result, dict):
        messages = result.get("messages", [])
    else:
        return ""
    for msg in reversed(messages):
        if not isinstance(msg, dict):
            continue
        if msg.get("type") == "human":
            break
        if msg.get("type") == "tool" and msg.get("name") == "ask_clarification":
            content = msg.get("content", "")
            if isinstance(content, str) and content:
                return content
        if msg.get("type") == "ai":
            content = msg.get("content", "")
            if isinstance(content, str) and content:
                return content
            if isinstance(content, list):
                parts = []
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "text":
                        parts.append(block.get("text", ""))
                    elif isinstance(block, str):
                        parts.append(block)
                text = "".join(parts)
                if text:
                    return text
    return ""


def _extract_artifacts(result: dict | list) -> list[str]:
    if isinstance(result, list):
        messages = result
    elif isinstance(result, dict):
        messages = result.get("messages", [])
    else:
        return []
    artifacts: list[str] = []
    for msg in reversed(messages):
        if not isinstance(msg, dict):
            continue
        if msg.get("type") == "human":
            break
        if msg.get("type") == "ai":
            for tc in msg.get("tool_calls", []):
                if isinstance(tc, dict) and tc.get("name") == "present_files":
                    paths = tc.get("args", {}).get("filepaths", [])
                    if isinstance(paths, list):
                        artifacts.extend(p for p in paths if isinstance(p, str))
    return artifacts


def _guess_mime(filename: str) -> str:
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    return {
        "png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg",
        "svg": "image/svg+xml", "pdf": "application/pdf",
        "pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "csv": "text/csv", "html": "text/html", "md": "text/markdown",
        "json": "application/json",
    }.get(ext, "application/octet-stream")


# ---------------------------------------------------------------------------
# Tool definitions
# ---------------------------------------------------------------------------

TOOLS = [
    types.Tool(
        name="deep_research",
        description=(
            "Deep web research across multiple sources with cross-verification. "
            "Returns a structured analysis report. Use when the user needs thorough "
            "investigation of a topic, market, technology, or trend."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Research question or topic to investigate"},
                "agent_name": {"type": "string", "description": "DeerFlow agent identity for specialized analysis (e.g. 'ai-semiconductor-analyst')"},
            },
            "required": ["query"],
        },
    ),
    types.Tool(
        name="data_analysis",
        description=(
            "Analyze data using DuckDB. Generates statistical summaries, insights, "
            "and optional visualizations. Supports CSV and Excel files."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Analysis task description"},
                "agent_name": {"type": "string"},
            },
            "required": ["query"],
        },
    ),
    types.Tool(
        name="chart_visualization",
        description=(
            "Generate charts and visualizations (line, bar, pie, scatter, sankey, "
            "treemap, heatmap, and 20 more types). Returns image file."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Chart description including data and chart type"},
                "agent_name": {"type": "string"},
            },
            "required": ["query"],
        },
    ),
    types.Tool(
        name="ppt_generation",
        description="Generate a PowerPoint presentation with AI-designed slides. Returns a .pptx file.",
        inputSchema={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Presentation topic and requirements"},
                "agent_name": {"type": "string"},
            },
            "required": ["query"],
        },
    ),
    types.Tool(
        name="image_generation",
        description="Generate AI images based on a text description. Returns an image file.",
        inputSchema={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Image description / prompt"},
            },
            "required": ["query"],
        },
    ),
    types.Tool(
        name="consulting_analysis",
        description=(
            "Professional consulting analysis workflow. Generates structured "
            "business analysis using frameworks like SWOT, Porter's Five Forces, etc."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Consulting question or business scenario to analyze"},
                "agent_name": {"type": "string"},
            },
            "required": ["query"],
        },
    ),
]

_TOOL_NAMES = {t.name for t in TOOLS}

_SKILL_HINTS: dict[str, str] = {
    "deep_research": "Use the deep-research skill for this task.",
    "data_analysis": "Use the data-analysis skill for this task.",
    "chart_visualization": "Use the chart-visualization skill for this task.",
    "ppt_generation": "Use the ppt-generation skill for this task.",
    "image_generation": "Use the image-generation skill for this task.",
    "consulting_analysis": "Use the consulting-analysis skill for this task.",
}


# ---------------------------------------------------------------------------
# MCP Server
# ---------------------------------------------------------------------------

def create_server() -> Server:
    """Create and return a configured MCP Server instance."""
    server = Server("deerflow-kinthai")

    @server.list_tools()
    async def list_tools() -> list[types.Tool]:
        return TOOLS

    @server.call_tool()
    async def call_tool(name: str, arguments: dict[str, Any] | None = None) -> list[types.TextContent | types.ImageContent | types.EmbeddedResource]:
        arguments = arguments or {}

        if name not in _TOOL_NAMES:
            return [types.TextContent(
                type="text",
                text=f"Unknown tool: {name}. Available: {', '.join(sorted(_TOOL_NAMES))}",
            )]

        query = arguments.get("query", "")
        if not query:
            return [types.TextContent(type="text", text="Missing required argument: query")]

        agent_name = arguments.get("agent_name", "")
        skill_hint = _SKILL_HINTS.get(name, "")
        message = f"{skill_hint}\n\n{query}".strip() if skill_hint else query

        run_context: dict[str, Any] = {
            "thinking_enabled": True,
            "is_plan_mode": False,
            "subagent_enabled": False,
        }
        if agent_name:
            run_context["agent_name"] = agent_name

        try:
            client = await _get_client()
            thread = await client.threads.create()
            thread_id = thread["thread_id"]
            run_context["thread_id"] = thread_id

            logger.info("[deerflow-kinthai] call_tool: tool=%s, agent=%s, thread=%s", name, agent_name or "(default)", thread_id)

            result = await client.runs.wait(
                thread_id,
                "lead_agent",
                input={"messages": [{"role": "human", "content": message}]},
                config={"recursion_limit": 100},
                context=run_context,
            )

            response_text = _extract_response_text(result)
            artifacts = _extract_artifacts(result)

            if not response_text and not artifacts:
                return [types.TextContent(type="text", text="(No response from agent)")]

            content_blocks: list[types.TextContent | types.ImageContent | types.EmbeddedResource] = []

            if response_text:
                content_blocks.append(types.TextContent(type="text", text=response_text))

            gateway_base = _get_gateway_base_url()
            for artifact_path in artifacts:
                filename = artifact_path.rsplit("/", 1)[-1] if "/" in artifact_path else artifact_path
                uri = f"{gateway_base}/api/threads/{thread_id}/artifacts/{artifact_path}"
                mime = _guess_mime(filename)

                if mime.startswith("image/"):
                    content_blocks.append(types.ImageContent(
                        type="image",
                        data="",  # Client should fetch from URI
                        mimeType=mime,
                    ))
                else:
                    content_blocks.append(types.TextContent(
                        type="text",
                        text=f"[File: {filename}]({uri})",
                    ))

            logger.info("[deerflow-kinthai] call_tool complete: tool=%s, text_len=%d, artifacts=%d",
                        name, len(response_text), len(artifacts))
            return content_blocks

        except Exception:
            logger.exception("[deerflow-kinthai] call_tool failed: tool=%s", name)
            raise

    return server


# ---------------------------------------------------------------------------
# Starlette / FastAPI app factory
# ---------------------------------------------------------------------------

def create_starlette_app(server: Server | None = None):
    """Create a Starlette app that serves the MCP server over SSE transport.

    Can be mounted in an existing FastAPI app:
        app.mount("/mcp", create_starlette_app())
    """
    from starlette.applications import Starlette
    from starlette.routing import Mount, Route
    from mcp.server.sse import SseServerTransport

    if server is None:
        server = create_server()

    sse = SseServerTransport("/messages/")

    async def handle_sse(scope, receive, send):
        async with sse.connect_sse(scope, receive, send) as (read, write):
            await server.run(read, write, server.create_initialization_options())

    # Build a raw ASGI app that routes /sse and /messages
    async def app(scope, receive, send):
        path = scope.get("path", "")
        if path == "/sse" or path == "/sse/":
            await handle_sse(scope, receive, send)
        elif path.startswith("/messages"):
            await sse.handle_post_message(scope, receive, send)
        else:
            from starlette.responses import JSONResponse
            response = JSONResponse({"error": "Not found"}, status_code=404)
            await response(scope, receive, send)

    return app


# ---------------------------------------------------------------------------
# Standalone entry point
# ---------------------------------------------------------------------------

def main():
    """Run the MCP server standalone with SSE transport on port 8808."""
    import uvicorn

    logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    logger.info("Starting mcp-server-deerflow-kinthai on port 8808")
    logger.info("DeerFlow LangGraph URL: %s", _get_langgraph_url())
    logger.info("DeerFlow Gateway URL: %s", _get_gateway_base_url())

    app = create_starlette_app()
    uvicorn.run(app, host="0.0.0.0", port=8808)


if __name__ == "__main__":
    main()
