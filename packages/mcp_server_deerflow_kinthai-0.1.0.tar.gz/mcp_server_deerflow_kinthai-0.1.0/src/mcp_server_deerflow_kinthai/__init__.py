"""mcp-server-deerflow-kinthai — Standard MCP Server exposing DeerFlow deep capabilities.

Author: freddy@kinthai.ai
Website: https://kinthai.ai
License: MIT
"""
