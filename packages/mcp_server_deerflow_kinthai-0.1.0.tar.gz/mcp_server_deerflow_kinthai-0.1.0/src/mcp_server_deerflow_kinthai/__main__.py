"""Entry point for: python -m mcp_server_deerflow_kinthai"""

from mcp_server_deerflow_kinthai.server import main

main()
