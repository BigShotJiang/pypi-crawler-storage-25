# mcp-server-deerflow-kinthai

MCP Server that exposes [DeerFlow](https://github.com/bytedance/deer-flow) deep capabilities via standard [Model Context Protocol](https://modelcontextprotocol.io/).

Any MCP client (OpenClaw, Claude Desktop, Cursor, etc.) can discover and invoke DeerFlow skills through this server.

## Tools

| Tool | Description |
|------|-------------|
| `deep_research` | Multi-source web research with cross-verification |
| `data_analysis` | Data analysis with DuckDB (CSV/Excel) |
| `chart_visualization` | 26+ chart types (line, bar, pie, scatter, sankey, etc.) |
| `ppt_generation` | PowerPoint presentation generation |
| `image_generation` | AI image generation |
| `consulting_analysis` | Business analysis (SWOT, Porter's Five Forces, etc.) |

## Quick Start

```bash
# Install
pip install mcp-server-deerflow-kinthai

# Run (requires a running DeerFlow instance)
export DEERFLOW_LANGGRAPH_URL=http://localhost:2024
mcp-server-deerflow-kinthai
```

The server starts on port 8808 with SSE transport at `/sse`.

## Configuration

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `DEERFLOW_LANGGRAPH_URL` | `http://localhost:2024` | DeerFlow LangGraph server URL |
| `DEERFLOW_GATEWAY_URL` | `http://localhost:8001` | DeerFlow Gateway API URL (for artifact downloads) |

### OpenClaw

```json
{
  "mcp": {
    "servers": {
      "deerflow-kinthai": {
        "url": "http://localhost:8808/sse"
      }
    }
  }
}
```

### Claude Desktop

```json
{
  "mcpServers": {
    "deerflow-kinthai": {
      "command": "mcp-server-deerflow-kinthai"
    }
  }
}
```

## Mount in Existing App

```python
from fastapi import FastAPI
from mcp_server_deerflow_kinthai.server import create_starlette_app

app = FastAPI()
app.mount("/mcp", create_starlette_app())
```

## Development

```bash
git clone https://github.com/kinthaiofficial/mcp-server-deerflow-kinthai
cd mcp-server-deerflow-kinthai
pip install -e ".[dev]"
pytest
```

## License

MIT — [KinthAI](https://kinthai.ai)
