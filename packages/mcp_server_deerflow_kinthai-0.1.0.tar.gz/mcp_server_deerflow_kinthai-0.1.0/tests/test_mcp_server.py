"""Unit tests for the DeerFlow MCP Server endpoint."""

from __future__ import annotations

import os
import sys
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from fastapi.testclient import TestClient


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _clear_api_key(monkeypatch):
    """Ensure DEERFLOW_MCP_API_KEY is unset by default (dev mode)."""
    monkeypatch.delenv("DEERFLOW_MCP_API_KEY", raising=False)


@pytest.fixture
def client():
    """Create a FastAPI TestClient with just the mcp_server router.

    Import the module directly to avoid pulling in the full app.gateway
    package (which requires deerflow harness dependencies).
    """
    import importlib.util, sys
    spec = importlib.util.spec_from_file_location(
        "mcp_server",
        os.path.join(os.path.dirname(__file__), "..", "app", "gateway", "routers", "mcp_server.py"),
    )
    mod = importlib.util.module_from_spec(spec)
    sys.modules["app.gateway.routers.mcp_server"] = mod
    spec.loader.exec_module(mod)

    # Rebuild Pydantic models after dynamic import
    mod.ToolCallRequest.model_rebuild()
    mod.ToolCallResponse.model_rebuild()
    mod.ContentBlock.model_rebuild()

    from fastapi import FastAPI
    app = FastAPI()
    app.include_router(mod.router)
    return TestClient(app)


# ---------------------------------------------------------------------------
# tools/list
# ---------------------------------------------------------------------------

class TestToolsList:
    def test_returns_tools(self, client):
        resp = client.post("/api/mcp-server/tools/list")
        assert resp.status_code == 200
        data = resp.json()
        assert "tools" in data
        tools = data["tools"]
        assert len(tools) == 6
        names = {t["name"] for t in tools}
        assert "deep_research" in names
        assert "data_analysis" in names
        assert "chart_visualization" in names
        assert "ppt_generation" in names
        assert "image_generation" in names
        assert "consulting_analysis" in names

    def test_each_tool_has_schema(self, client):
        resp = client.post("/api/mcp-server/tools/list")
        for tool in resp.json()["tools"]:
            assert "name" in tool
            assert "description" in tool
            assert "inputSchema" in tool
            schema = tool["inputSchema"]
            assert schema["type"] == "object"
            assert "query" in schema["properties"]
            assert "query" in schema["required"]


# ---------------------------------------------------------------------------
# Authentication
# ---------------------------------------------------------------------------

class TestAuth:
    def test_no_key_configured_allows_access(self, client):
        resp = client.post("/api/mcp-server/tools/list")
        assert resp.status_code == 200

    def test_key_configured_rejects_without_header(self, client, monkeypatch):
        monkeypatch.setenv("DEERFLOW_MCP_API_KEY", "secret123")
        # Need to reload the module to pick up the new env var
        import sys
        mod = sys.modules["app.gateway.routers.mcp_server"]
        mod._API_KEY = "secret123"

        resp = client.post("/api/mcp-server/tools/list")
        assert resp.status_code == 401

        mod._API_KEY = ""

    def test_key_configured_accepts_correct_header(self, client):
        import sys
        mod = sys.modules["app.gateway.routers.mcp_server"]
        mod._API_KEY = "secret123"

        resp = client.post(
            "/api/mcp-server/tools/list",
            headers={"Authorization": "Bearer secret123"},
        )
        assert resp.status_code == 200

        mod._API_KEY = ""

    def test_key_configured_rejects_wrong_header(self, client):
        import sys
        mod = sys.modules["app.gateway.routers.mcp_server"]
        mod._API_KEY = "secret123"

        resp = client.post(
            "/api/mcp-server/tools/list",
            headers={"Authorization": "Bearer wrong"},
        )
        assert resp.status_code == 401

        mod._API_KEY = ""


# ---------------------------------------------------------------------------
# tools/call — validation
# ---------------------------------------------------------------------------

class TestToolCallValidation:
    def test_unknown_tool_returns_error(self, client):
        resp = client.post("/api/mcp-server/tools/call", json={
            "name": "nonexistent_tool",
            "arguments": {"query": "test"},
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["isError"] is True
        assert "Unknown tool" in data["content"][0]["text"]

    def test_missing_query_returns_error(self, client):
        resp = client.post("/api/mcp-server/tools/call", json={
            "name": "deep_research",
            "arguments": {},
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["isError"] is True
        assert "query" in data["content"][0]["text"]


# ---------------------------------------------------------------------------
# tools/call — execution
# ---------------------------------------------------------------------------

class TestToolCallExecution:
    @pytest.mark.asyncio
    async def test_successful_research(self, client):
        """Mock LangGraph client and verify the full tool call flow."""
        mock_thread = {"thread_id": "test-thread-123"}
        mock_result = {
            "messages": [
                {"type": "human", "content": "test query"},
                {"type": "ai", "content": "# Research Report\n\nFindings..."},
            ]
        }

        mock_client = AsyncMock()
        mock_client.threads.create = AsyncMock(return_value=mock_thread)
        mock_client.runs.wait = AsyncMock(return_value=mock_result)

        with patch.object(sys.modules["app.gateway.routers.mcp_server"], "_get_client", return_value=mock_client):
            resp = client.post("/api/mcp-server/tools/call", json={
                "name": "deep_research",
                "arguments": {"query": "AI market analysis"},
            })

        assert resp.status_code == 200
        data = resp.json()
        assert data["isError"] is False
        assert len(data["content"]) >= 1
        assert "Research Report" in data["content"][0]["text"]

    @pytest.mark.asyncio
    async def test_with_agent_name(self, client):
        mock_thread = {"thread_id": "test-thread-456"}
        mock_result = {
            "messages": [
                {"type": "human", "content": "query"},
                {"type": "ai", "content": "Analysis from specialist"},
            ]
        }

        mock_client = AsyncMock()
        mock_client.threads.create = AsyncMock(return_value=mock_thread)
        mock_client.runs.wait = AsyncMock(return_value=mock_result)

        with patch.object(sys.modules["app.gateway.routers.mcp_server"], "_get_client", return_value=mock_client):
            resp = client.post("/api/mcp-server/tools/call", json={
                "name": "consulting_analysis",
                "arguments": {
                    "query": "SWOT analysis of Tesla",
                    "agent_name": "venture-backed-startup-analyst",
                },
            })

        assert resp.status_code == 200
        # Verify agent_name was passed in the context
        call_kwargs = mock_client.runs.wait.call_args
        context = call_kwargs.kwargs.get("context") or call_kwargs[1].get("context", {})
        assert context.get("agent_name") == "venture-backed-startup-analyst"

    @pytest.mark.asyncio
    async def test_with_artifacts(self, client):
        mock_thread = {"thread_id": "test-thread-789"}
        mock_result = {
            "messages": [
                {"type": "human", "content": "make a chart"},
                {
                    "type": "ai",
                    "content": "Here is the chart.",
                    "tool_calls": [
                        {
                            "name": "present_files",
                            "args": {"filepaths": ["/mnt/user-data/outputs/chart.png"]},
                        }
                    ],
                },
            ]
        }

        mock_client = AsyncMock()
        mock_client.threads.create = AsyncMock(return_value=mock_thread)
        mock_client.runs.wait = AsyncMock(return_value=mock_result)

        with patch.object(sys.modules["app.gateway.routers.mcp_server"], "_get_client", return_value=mock_client):
            resp = client.post("/api/mcp-server/tools/call", json={
                "name": "chart_visualization",
                "arguments": {"query": "bar chart of sales data"},
            })

        assert resp.status_code == 200
        data = resp.json()
        assert data["isError"] is False
        # Should have text + resource blocks
        types = [c["type"] for c in data["content"]]
        assert "text" in types
        assert "resource" in types
        resource = next(c for c in data["content"] if c["type"] == "resource")
        assert "chart.png" in resource["resource"]["uri"]
        assert resource["resource"]["mimeType"] == "image/png"

    @pytest.mark.asyncio
    async def test_langgraph_error_returns_mcp_error(self, client):
        mock_client = AsyncMock()
        mock_client.threads.create = AsyncMock(side_effect=Exception("Connection refused"))

        with patch.object(sys.modules["app.gateway.routers.mcp_server"], "_get_client", return_value=mock_client):
            resp = client.post("/api/mcp-server/tools/call", json={
                "name": "deep_research",
                "arguments": {"query": "test"},
            })

        assert resp.status_code == 200
        data = resp.json()
        assert data["isError"] is True
        assert "failed" in data["content"][0]["text"].lower()

    @pytest.mark.asyncio
    async def test_empty_response(self, client):
        mock_thread = {"thread_id": "test-empty"}
        mock_result = {"messages": [{"type": "human", "content": "q"}]}

        mock_client = AsyncMock()
        mock_client.threads.create = AsyncMock(return_value=mock_thread)
        mock_client.runs.wait = AsyncMock(return_value=mock_result)

        with patch.object(sys.modules["app.gateway.routers.mcp_server"], "_get_client", return_value=mock_client):
            resp = client.post("/api/mcp-server/tools/call", json={
                "name": "deep_research",
                "arguments": {"query": "test"},
            })

        assert resp.status_code == 200
        data = resp.json()
        assert "No response" in data["content"][0]["text"]
