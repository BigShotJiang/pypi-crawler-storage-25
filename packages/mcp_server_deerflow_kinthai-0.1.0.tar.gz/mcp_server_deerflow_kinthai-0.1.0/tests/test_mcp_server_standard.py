"""Tests for mcp-server-deerflow-kinthai standard MCP server."""

import sys
import os

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import pytest
from mcp_server_deerflow_kinthai.server import (
    create_server,
    create_starlette_app,
    TOOLS,
    _extract_response_text,
    _extract_artifacts,
    _guess_mime,
)


class TestServerCreation:
    def test_create_server(self):
        server = create_server()
        assert server.name == "deerflow-kinthai"

    def test_create_starlette_app(self):
        app = create_starlette_app()
        assert callable(app)


class TestToolDefinitions:
    def test_six_tools_defined(self):
        assert len(TOOLS) == 6

    def test_tool_names(self):
        names = {t.name for t in TOOLS}
        assert names == {
            "deep_research", "data_analysis", "chart_visualization",
            "ppt_generation", "image_generation", "consulting_analysis",
        }

    def test_each_tool_has_schema(self):
        for tool in TOOLS:
            assert tool.name
            assert tool.description
            assert tool.inputSchema
            assert tool.inputSchema["type"] == "object"
            assert "query" in tool.inputSchema["properties"]
            assert "query" in tool.inputSchema["required"]


class TestExtractResponseText:
    def test_simple_ai_response(self):
        result = {"messages": [
            {"type": "human", "content": "hello"},
            {"type": "ai", "content": "world"},
        ]}
        assert _extract_response_text(result) == "world"

    def test_content_blocks(self):
        result = {"messages": [
            {"type": "human", "content": "q"},
            {"type": "ai", "content": [{"type": "text", "text": "answer"}]},
        ]}
        assert _extract_response_text(result) == "answer"

    def test_empty(self):
        assert _extract_response_text({"messages": []}) == ""
        assert _extract_response_text([]) == ""
        assert _extract_response_text({}) == ""

    def test_clarification(self):
        result = {"messages": [
            {"type": "human", "content": "q"},
            {"type": "tool", "name": "ask_clarification", "content": "What do you mean?"},
        ]}
        assert _extract_response_text(result) == "What do you mean?"


class TestExtractArtifacts:
    def test_present_files(self):
        result = {"messages": [
            {"type": "human", "content": "make chart"},
            {"type": "ai", "content": "done", "tool_calls": [
                {"name": "present_files", "args": {"filepaths": ["/mnt/user-data/outputs/chart.png"]}}
            ]},
        ]}
        artifacts = _extract_artifacts(result)
        assert artifacts == ["/mnt/user-data/outputs/chart.png"]

    def test_no_artifacts(self):
        result = {"messages": [
            {"type": "human", "content": "hello"},
            {"type": "ai", "content": "hi"},
        ]}
        assert _extract_artifacts(result) == []


class TestGuessMime:
    def test_common_types(self):
        assert _guess_mime("chart.png") == "image/png"
        assert _guess_mime("report.pdf") == "application/pdf"
        assert _guess_mime("data.csv") == "text/csv"
        assert _guess_mime("slides.pptx") == "application/vnd.openxmlformats-officedocument.presentationml.presentation"

    def test_unknown(self):
        assert _guess_mime("file.xyz") == "application/octet-stream"
