# CLAUDE.md — 公开仓边界声明

## ⚠️ 仓库性质

**这是 kinthaiofficial 的公开 GitHub 仓库。所有 commit 都会推送到 github.com。**

## 🚫 绝对禁止

- **禁止**引用任何 kinthai 私有基础设施：
  - 内网 IP（`10.8.x.x`、`127.0.0.1:3000`、`127.0.0.1:4000`）
  - 内部 URL（`kinthai.ai`、`kithkith.com`、`ops.kinthai.ai`）
  - 数据库容器名、密码、token
  - `/opt/kinthai/`、`/root/kinthai/`、`/root/kinthai-prod/` 等私有路径
- **禁止**提交 `.env`、凭据文件、任何含 `ghp_`/`ghs_`/`gho_` 前缀的 GitHub token
- **禁止**提交内部运维脚本（如 nightly 测试、部署流程、备份脚本）
- **禁止**引用 kinthai 项目的内部文档（CLAUDE.md 之外的项目文档）

## ✅ 允许

- 纯粹插件功能代码
- 公开文档（README、LICENSE、user-facing 安装指南）
- 对 kinthai 开放 API 的调用（通过 `https://kinthai.ai/api/v1/...` 公开端点）
- 单元测试（使用 mock 或 fixtures，不依赖内网资源）

## 🔐 Git 配置

- `user.email` = `freddy@kinthai.ai`
- Pre-commit hook 会拦截边界违规关键词（gitleaks + 自定义黑名单）

## 🧭 本地开发工作流

每次改动后：
```bash
git status
git diff
git add <files>
git commit   # pre-commit hook 会扫描
git push origin main
```

如果 pre-commit hook 拦截了你：**不要 --no-verify 绕过**，查实是不是真的有泄漏再决定。

## 🔗 相关项目

- kinthai 主项目（闭源 Gitea）: `/root/kinthai/`
- kinthai-prod 运维（闭源 Gitea）: `/root/kinthai-prod/`
- 其他公开仓: `/root/public/`
- 重构方案: `/root/.claude/plans/kinthai-repo-reorg.md`

如果要把内部代码搬过来，先问自己：
1. 这段代码是否引用任何 kinthai 私有资源？
2. 如果被世界上任何人看到，会造成安全问题吗？

**回答不确定 → 不搬。**
