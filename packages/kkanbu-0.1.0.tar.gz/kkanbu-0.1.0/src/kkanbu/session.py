"""Server-side session state for kkanbu multi-turn conversations.

Provides ephemeral in-memory session storage keyed by session_id.
Conversation history is ephemeral — only distilled learnings are persisted
to the knowledge graph.

Session lifecycle:
  - Created on first call (new session_id generated or provided)
  - Updated on each subsequent call (last_active timestamp refreshed)
  - Pruned automatically when inactive beyond SESSION_TIMEOUT_SECS

Session types:
  - "curious"      : kkanbu_curious multi-turn deep questioning
  - "teach"        : kkanbu_learn extraction session
  - "answer"       : kkanbu_answer context tracking
  - "conversation" : kkanbu_resolve_flag flag-seeded Socratic interview
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Literal

# ── Constants ─────────────────────────────────────────────────────────────────

SESSION_TIMEOUT_SECS: int = 1800  # 30 minutes of inactivity → prune

SessionType = Literal["curious", "teach", "answer", "conversation"]


# ── Data Structures ───────────────────────────────────────────────────────────


@dataclass
class MessageRecord:
    """A single message in a session's conversation history.

    Attributes:
        role:    "user" for human input, "assistant" for kkanbu responses.
        content: The message text (never persisted to graph; ephemeral only).
    """

    role: Literal["user", "assistant"]
    content: str

    def to_dict(self) -> dict[str, str]:
        """Serialize to the dict format expected by Anthropic messages API."""
        return {"role": self.role, "content": self.content}

    @classmethod
    def from_dict(cls, d: dict[str, str]) -> "MessageRecord":
        return cls(role=d["role"], content=d["content"])  # type: ignore[arg-type]


@dataclass
class SessionState:
    """Ephemeral per-session state for a multi-turn kkanbu conversation.

    All fields are in-memory only.  Only insights distilled from the
    conversation are written to the knowledge graph (via kkanbu_learn /
    kkanbu_curious response handlers).

    Common fields (all session types):
        session_id:    Unique identifier, echoed back to caller for continuity.
        session_type:  Which tool owns this session.
        created_at:    Epoch seconds when the session was created.
        last_active:   Epoch seconds of the most recent activity (used for expiry).
        history:       Ordered list of MessageRecord objects — ephemeral transcript.
        metadata:      Flexible dict for session-type-specific extra context.

    curious-specific (stored in metadata or top-level for fast access):
        thread_topic:      1–3 word label for the current conversational thread.
        topics_explored:   All thread topics seen in this session (anti-repetition).
        questions_asked:   Verbatim questions asked (passed to Opus to avoid repeats).

    teach-specific:
        insights_extracted: Running count of graph nodes created/updated this session.
        source_type:        "teach" (explicit) or "passive" (absorbed conversation).

    answer-specific:
        question_asked:     The interview question that started this session.

    conversation-specific:
        flag_id:            node_id of the flag that seeded this conversation (if any).
    """

    session_id: str
    session_type: SessionType
    created_at: float = field(default_factory=time.time)
    last_active: float = field(default_factory=time.time)

    # Ephemeral conversation transcript — never written to graph directly.
    history: list[MessageRecord] = field(default_factory=list)

    # --- curious-specific ------------------------------------------------
    thread_topic: str = ""
    topics_explored: list[str] = field(default_factory=list)
    questions_asked: list[str] = field(default_factory=list)

    # --- teach-specific --------------------------------------------------
    insights_extracted: int = 0
    source_type: str = "teach"  # "teach" | "passive"

    # --- answer-specific -------------------------------------------------
    question_asked: str = ""

    # --- conversation-specific -------------------------------------------
    flag_id: str = ""
    flag_groups: list[dict] = field(default_factory=list)
    current_group_index: int = 0

    # --- flexible overflow -----------------------------------------------
    metadata: dict[str, Any] = field(default_factory=dict)

    # ── Derived helpers ───────────────────────────────────────────────────

    @property
    def turn_count(self) -> int:
        """Number of assistant turns taken so far."""
        return sum(1 for m in self.history if m.role == "assistant")

    @property
    def is_fresh(self) -> bool:
        """True if no assistant message has been sent yet."""
        return self.turn_count == 0

    def touch(self) -> None:
        """Refresh last_active to now (call on every interaction)."""
        self.last_active = time.time()

    def append(self, role: Literal["user", "assistant"], content: str) -> None:
        """Append a message to the ephemeral history and touch last_active."""
        self.history.append(MessageRecord(role=role, content=content))
        self.touch()

    def history_as_dicts(self) -> list[dict[str, str]]:
        """Return history in the format expected by Anthropic messages API."""
        return [m.to_dict() for m in self.history]

    def age_secs(self) -> float:
        """Seconds since the session was last active."""
        return time.time() - self.last_active

    def to_summary(self) -> dict[str, Any]:
        """Lightweight summary dict for logging and debug output."""
        return {
            "session_id": self.session_id,
            "session_type": self.session_type,
            "turn_count": self.turn_count,
            "age_secs": round(self.age_secs(), 1),
            "thread_topic": self.thread_topic,
            "insights_extracted": self.insights_extracted,
        }


# ── Session Store ─────────────────────────────────────────────────────────────


class SessionStore:
    """In-memory session registry keyed by session_id.

    Thread-safety: Not needed — the MCP server is single-threaded (asyncio
    event loop), so plain dict operations are safe without locks.

    Usage::

        store = SessionStore()

        # Start a new session
        session = store.create("curious")

        # Resume an existing session (returns None if expired/not found)
        session = store.get(session_id)

        # Prune stale sessions (call at the start of each tool handler)
        pruned = store.prune_stale()
    """

    def __init__(self, timeout_secs: int = SESSION_TIMEOUT_SECS) -> None:
        self._sessions: dict[str, SessionState] = {}
        self.timeout_secs = timeout_secs

    # ── Factory ───────────────────────────────────────────────────────────

    def create(
        self,
        session_type: SessionType,
        session_id: str | None = None,
        **kwargs: Any,
    ) -> SessionState:
        """Create and register a new SessionState.

        Args:
            session_type: Which tool owns this session.
            session_id:   Optional caller-supplied ID.  A UUID4 is generated
                          if omitted.
            **kwargs:     Extra fields forwarded to SessionState (e.g.
                          ``thread_topic``, ``flag_id``).

        Returns:
            The newly created (and registered) SessionState.
        """
        sid = session_id or str(uuid.uuid4())
        now = time.time()
        session = SessionState(
            session_id=sid,
            session_type=session_type,
            created_at=now,
            last_active=now,
            **kwargs,
        )
        self._sessions[sid] = session
        return session

    # ── Retrieval ────────────────────────────────────────────────────────

    def get(self, session_id: str) -> SessionState | None:
        """Return the session if it exists and has not timed out, else None.

        Note: Does *not* touch last_active — the caller should call
        ``session.touch()`` after retrieving and deciding to continue.
        """
        session = self._sessions.get(session_id)
        if session is None:
            return None
        if session.age_secs() > self.timeout_secs:
            # Expired on access — remove and return None
            del self._sessions[session_id]
            return None
        return session

    def get_or_create(
        self,
        session_id: str | None,
        session_type: SessionType,
        **kwargs: Any,
    ) -> tuple[SessionState, bool]:
        """Retrieve an existing session or create a new one.

        Args:
            session_id:   Caller-supplied ID, or empty string / None to create.
            session_type: Used only when creating a new session.
            **kwargs:     Forwarded to ``create()`` if session is new.

        Returns:
            ``(session, is_new)`` where ``is_new`` is True when a session
            was created rather than retrieved.
        """
        if session_id:
            existing = self.get(session_id)
            if existing is not None:
                existing.touch()
                return existing, False
        # Create new (preserving caller-supplied ID if provided and expired)
        new_session = self.create(
            session_type,
            session_id=session_id or None,
            **kwargs,
        )
        return new_session, True

    # ── Lifecycle ────────────────────────────────────────────────────────

    def prune_stale(self) -> int:
        """Remove all sessions inactive beyond ``timeout_secs``.

        Returns:
            Number of sessions pruned.
        """
        now = time.time()
        stale = [
            sid
            for sid, s in self._sessions.items()
            if now - s.last_active > self.timeout_secs
        ]
        for sid in stale:
            del self._sessions[sid]
        return len(stale)

    def delete(self, session_id: str) -> bool:
        """Explicitly remove a session (e.g. after distillation to graph).

        Returns:
            True if the session existed and was removed, False otherwise.
        """
        if session_id in self._sessions:
            del self._sessions[session_id]
            return True
        return False

    # ── Introspection ────────────────────────────────────────────────────

    def __len__(self) -> int:
        return len(self._sessions)

    def __contains__(self, session_id: str) -> bool:
        return session_id in self._sessions

    def active_sessions(self) -> list[SessionState]:
        """Return all non-stale sessions (without pruning)."""
        now = time.time()
        return [
            s for s in self._sessions.values()
            if now - s.last_active <= self.timeout_secs
        ]

    def stats(self) -> dict[str, Any]:
        """Summary of current session store state for debug/monitoring."""
        sessions = self.active_sessions()
        by_type: dict[str, int] = {}
        for s in sessions:
            by_type[s.session_type] = by_type.get(s.session_type, 0) + 1
        return {
            "total_sessions": len(self._sessions),
            "active_sessions": len(sessions),
            "by_type": by_type,
            "timeout_secs": self.timeout_secs,
        }
