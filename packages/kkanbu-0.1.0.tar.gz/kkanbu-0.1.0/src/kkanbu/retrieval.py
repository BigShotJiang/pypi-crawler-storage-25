"""Selective retrieval layer for the kkanbu knowledge graph.

Provides keyword search across nodes and edges with BFS subgraph expansion,
returning a ranked context bundle suitable for LLM context injection.

Design goals:
  - Keyword matching across node content, why, metadata fields AND edge context
  - BFS expansion from seed nodes to configurable depth with score decay
  - Confidence-weighted ranking so high-confidence knowledge surfaces first
  - Deduplication + depth-aware scoring for clean context bundles
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Optional

from kkanbu.graph import KnowledgeGraph

# ---------------------------------------------------------------------------
# Stop-word list (shared with server.py logic — minimal, English)
# ---------------------------------------------------------------------------

_STOP_WORDS = frozenset({
    "the", "a", "an", "is", "are", "was", "were", "be", "been", "being",
    "have", "has", "had", "do", "does", "did", "will", "would", "could",
    "should", "may", "might", "shall", "can", "need", "dare", "ought",
    "used", "to", "of", "in", "for", "on", "with", "at", "by", "from",
    "as", "into", "through", "during", "before", "after", "above",
    "below", "between", "out", "off", "over", "under", "again",
    "further", "then", "once", "here", "there", "when", "where", "why",
    "how", "all", "both", "each", "few", "more", "most", "other",
    "some", "such", "no", "nor", "not", "only", "own", "same", "so",
    "than", "too", "very", "just", "because", "but", "and", "or",
    "if", "while", "about", "what", "which", "who", "whom", "this",
    "that", "these", "those", "i", "me", "my", "myself", "we", "our",
    "you", "your", "he", "him", "she", "her", "it", "its", "they",
    "them", "their",
})

# Scoring weights
_WEIGHT_CONTENT_MATCH = 2.0   # keyword found in node content
_WEIGHT_WHY_MATCH = 1.5       # keyword found in node why field
_WEIGHT_META_MATCH = 0.5      # keyword found in node metadata JSON
_WEIGHT_EDGE_CONTEXT = 1.0    # keyword found in edge context field
_WEIGHT_CONFIDENCE = 1.0      # multiplied by node.confidence
_BFS_DECAY = 0.6              # score multiplied per BFS hop away from seed


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class RankedNode:
    """A knowledge graph node with its relevance score and BFS depth."""
    node: dict
    score: float
    depth: int  # 0 = direct keyword match, 1+ = BFS neighbor

    @property
    def node_id(self) -> str:
        return self.node["node_id"]

    def as_text(self) -> str:
        """Single-line text representation for LLM context."""
        parts = [f"[{self.node['node_type']}] {self.node['content']}"]
        if self.node.get("why"):
            parts.append(f"  WHY: {self.node['why']}")
        parts.append(
            f"  (confidence={self.node['confidence']:.2f}, score={self.score:.2f}, depth={self.depth})"
        )
        return "\n".join(parts)


@dataclass
class RankedEdge:
    """A knowledge graph edge with its relevance score."""
    edge: dict
    from_node: dict
    to_node: dict
    score: float

    @property
    def edge_id(self) -> str:
        return self.edge["edge_id"]

    def as_text(self) -> str:
        """Single-line text representation for LLM context."""
        from_content = self.from_node.get("content", self.edge["from_node"])[:60]
        to_content = self.to_node.get("content", self.edge["to_node"])[:60]
        rel = self.edge["relation_type"]
        ctx = f" ({self.edge['context']})" if self.edge.get("context") else ""
        return f"  {from_content!r} --[{rel}]--> {to_content!r}{ctx}"


@dataclass
class ContextBundle:
    """A ranked, structured context bundle retrieved from the knowledge graph.

    Suitable for direct injection into LLM prompts as structured context.
    """
    query: str
    keywords: list[str]
    nodes: list[RankedNode] = field(default_factory=list)  # sorted by score desc
    edges: list[RankedEdge] = field(default_factory=list)  # sorted by score desc
    total_nodes_scanned: int = 0
    total_edges_scanned: int = 0
    bfs_depth_used: int = 0

    def top_nodes(self, n: int = 10) -> list[RankedNode]:
        """Return up to n highest-scoring nodes."""
        return self.nodes[:n]

    def top_edges(self, n: int = 20) -> list[RankedEdge]:
        """Return up to n highest-scoring edges."""
        return self.edges[:n]

    def as_text(self, max_nodes: int = 20, max_edges: int = 15) -> str:
        """Format the bundle as a text block for LLM consumption.

        Produces a compact but information-rich representation that gives
        the LLM the structured knowledge it needs to reason from the user's
        perspective.
        """
        if not self.nodes and not self.edges:
            return f"[No relevant knowledge found for: {self.query!r}]"

        lines: list[str] = [
            f"=== Knowledge Graph Context for: {self.query!r} ===",
            f"Keywords matched: {', '.join(self.keywords)}",
            f"Nodes retrieved: {len(self.nodes)} (scanned {self.total_nodes_scanned}), "
            f"Edges retrieved: {len(self.edges)} (scanned {self.total_edges_scanned})",
            "",
        ]

        if self.nodes:
            lines.append("--- Relevant Knowledge Nodes (ranked by relevance) ---")
            for rn in self.top_nodes(max_nodes):
                lines.append(rn.as_text())
                lines.append("")

        if self.edges:
            lines.append("--- Relevant Relationships ---")
            for re in self.top_edges(max_edges):
                lines.append(re.as_text())
            lines.append("")

        return "\n".join(lines)

    def is_empty(self) -> bool:
        return len(self.nodes) == 0

    def average_confidence(self) -> float:
        """Weighted average confidence of top nodes."""
        if not self.nodes:
            return 0.0
        top = self.top_nodes(10)
        return sum(rn.node["confidence"] for rn in top) / len(top)

    def to_prompt_payload(self, question: str = "") -> str:
        """Serialize this bundle into a structured LLM prompt payload.

        Produces a rich, semantically organized block that lets an LLM reason
        faithfully from the user's perspective. Uses the full relationship map
        and depth-aware node grouping — not just a flat list.

        See :func:`assemble_context_payload` for full details.
        """
        return assemble_context_payload(self, question=question)


# ---------------------------------------------------------------------------
# LLM context assembly
# ---------------------------------------------------------------------------

def assemble_context_payload(bundle: "ContextBundle", question: str = "") -> str:
    """Serialize a retrieved subgraph bundle into a structured LLM prompt payload.

    Converts the ranked nodes and edges of a ContextBundle into a rich, structured
    text block that an LLM can consume to reason authentically from the user's
    perspective.  This goes significantly beyond the diagnostic ``as_text()`` output:

    * Separates **direct keyword matches** (depth=0) from **BFS-inferred context**
      (depth≥1) so the LLM knows which knowledge is immediately relevant vs
      tangentially related.
    * Groups nodes by semantic type (value → preference → pattern → reasoning →
      observation) so the LLM can see the identity layer clearly.
    * Renders the **relationship map** with full edge context, weights, and node
      snippets so the LLM can trace *why* the user thinks a certain way.
    * Surfaces **low-confidence nodes** with explicit uncertainty markers so the
      LLM can calibrate hedging.
    * Appends a **voice framing** directive at the end — the instruction to speak
      as this specific person rather than giving a generic answer.

    Args:
        bundle: The ContextBundle produced by :func:`retrieve_context`.
        question: The original query / interview question (optional, used for header).

    Returns:
        A multi-section text block ready for inclusion in an LLM ``messages`` payload.
    """
    if bundle.is_empty():
        header = f" FOR: {question!r}" if question else ""
        return (
            f"=== KNOWLEDGE CONTEXT{header} ===\n"
            "No relevant knowledge found in graph.\n"
            "The user has not yet taught kkanbu anything relevant to this topic.\n"
            "=== END CONTEXT ==="
        )

    lines: list[str] = []

    # ── Header ────────────────────────────────────────────────────────────
    q_label = f": {question!r}" if question else ""
    direct_count = sum(1 for rn in bundle.nodes if rn.depth == 0)
    inferred_count = len(bundle.nodes) - direct_count
    avg_conf = bundle.average_confidence()

    conf_label = (
        "HIGH" if avg_conf >= 0.75
        else "MODERATE" if avg_conf >= 0.50
        else "LOW"
    )

    lines.append(f"=== KNOWLEDGE CONTEXT{q_label} ===")
    lines.append(
        f"Retrieved {len(bundle.nodes)} nodes "
        f"({direct_count} direct, {inferred_count} contextual) · "
        f"{len(bundle.edges)} relationships · "
        f"confidence: {conf_label} ({avg_conf:.2f})"
    )
    if bundle.keywords:
        lines.append(f"Query keywords: {', '.join(bundle.keywords)}")
    lines.append("")

    # ── Type display order — identity layers first ─────────────────────────
    _TYPE_ORDER = ["value", "pattern", "preference", "reasoning", "observation",
                   "correction", "flag", "debug_learning"]

    def _type_rank(t: str) -> int:
        return _TYPE_ORDER.index(t) if t in _TYPE_ORDER else len(_TYPE_ORDER)

    # ── Direct matches (depth=0) ───────────────────────────────────────────
    direct_nodes = sorted(
        [rn for rn in bundle.nodes if rn.depth == 0],
        key=lambda rn: (_type_rank(rn.node["node_type"]), -rn.score),
    )
    if direct_nodes:
        lines.append("━━━ DIRECT KNOWLEDGE (query-matched) ━━━")
        for rn in direct_nodes:
            lines.extend(_render_ranked_node(rn, show_depth=False))
        lines.append("")

    # ── Contextual / BFS-inferred nodes (depth≥1) ─────────────────────────
    inferred_nodes = sorted(
        [rn for rn in bundle.nodes if rn.depth > 0],
        key=lambda rn: (rn.depth, _type_rank(rn.node["node_type"]), -rn.score),
    )
    if inferred_nodes:
        lines.append("━━━ CONTEXTUAL KNOWLEDGE (graph-inferred) ━━━")
        for rn in inferred_nodes:
            lines.extend(_render_ranked_node(rn, show_depth=True))
        lines.append("")

    # ── Relationship map ───────────────────────────────────────────────────
    if bundle.edges:
        lines.append("━━━ KNOWLEDGE RELATIONSHIPS ━━━")
        # Sort edges: higher-weight, meaningful edges first
        sorted_edges = sorted(bundle.edges, key=lambda re: -re.score)
        for re in sorted_edges[:20]:  # cap at 20 for prompt size
            from_snippet = (re.from_node.get("content") or re.edge["from_node"])[:70]
            to_snippet = (re.to_node.get("content") or re.edge["to_node"])[:70]
            rel = re.edge["relation_type"]
            weight = re.edge.get("weight", 0.5)
            ctx = re.edge.get("context") or ""

            lines.append(f"  {from_snippet!r}")
            lines.append(f"    --[{rel}]--> {to_snippet!r}  (strength: {weight:.2f})")
            if ctx and ctx not in ("Auto-connected via shared keyword",):
                lines.append(f"    ↳ {ctx}")
        lines.append("")

    # ── Low-confidence caveats ─────────────────────────────────────────────
    low_conf_nodes = [
        rn for rn in bundle.nodes
        if rn.node.get("confidence", 1.0) < 0.5
    ]
    if low_conf_nodes:
        lines.append("━━━ UNCERTAIN KNOWLEDGE (low confidence — hedge appropriately) ━━━")
        for rn in low_conf_nodes[:5]:
            content = rn.node.get("content", "")[:80]
            conf = rn.node.get("confidence", 0.0)
            lines.append(f"  [{rn.node['node_type']}] {content}  (conf={conf:.2f})")
        lines.append("")

    # ── Voice framing directive ────────────────────────────────────────────
    lines.append("=== END CONTEXT ===")
    lines.append(
        "Speak authentically AS this person — use their actual values, reasoning, "
        "and language patterns reflected above. Confidence should match the graph: "
        "be definitive where confidence is HIGH, appropriately hedged where LOW. "
        "Do not add generic AI disclaimers; answer as the user would answer."
    )

    return "\n".join(lines)


def _render_ranked_node(rn: "RankedNode", show_depth: bool = False) -> list[str]:
    """Render a single RankedNode as a block of prompt lines."""
    node = rn.node
    node_type = node.get("node_type", "unknown")
    content = node.get("content", "")
    why = node.get("why") or ""
    conf = node.get("confidence", 0.5)
    src = node.get("source", "?")

    depth_note = f" [inferred via {rn.depth} hop{'s' if rn.depth != 1 else ''}]" if show_depth else ""

    lines: list[str] = []
    lines.append(f"[{node_type} | conf={conf:.2f} | src={src}]{depth_note}")
    lines.append(f"  {content}")
    if why:
        lines.append(f"  WHY: {why}")

    # Surface meaningful metadata (skip internal plumbing)
    meta_raw = node.get("metadata")
    if meta_raw:
        try:
            meta = json.loads(meta_raw) if isinstance(meta_raw, str) else meta_raw
            for mk in ("tag", "topic", "domain", "category", "label"):
                if mk in meta:
                    lines.append(f"  {mk.upper()}: {meta[mk]}")
        except (json.JSONDecodeError, TypeError):
            pass

    return lines


# ---------------------------------------------------------------------------
# Core retrieval logic
# ---------------------------------------------------------------------------

def extract_keywords(text: str) -> list[str]:
    """Tokenize text into meaningful search keywords.

    Lowercases, strips punctuation, removes stop words and very short tokens.
    Returns deduplicated list in original order.
    """
    words = text.lower().split()
    seen: set[str] = set()
    result: list[str] = []
    for w in words:
        w = w.strip(".,!?;:\"'()[]{}—-–/\\")
        if w and w not in _STOP_WORDS and len(w) > 2 and w not in seen:
            seen.add(w)
            result.append(w)
    return result


def _score_node(node: dict, keywords: list[str]) -> float:
    """Compute keyword-relevance score for a node (pre-BFS, at depth=0)."""
    score = 0.0
    content_lower = (node.get("content") or "").lower()
    why_lower = (node.get("why") or "").lower()

    # Parse metadata for keyword matching
    meta_str = ""
    if node.get("metadata"):
        try:
            meta_obj = json.loads(node["metadata"]) if isinstance(node["metadata"], str) else node["metadata"]
            meta_str = json.dumps(meta_obj).lower()
        except (json.JSONDecodeError, TypeError):
            meta_str = str(node["metadata"]).lower()

    for kw in keywords:
        if kw in content_lower:
            score += _WEIGHT_CONTENT_MATCH
        if kw in why_lower:
            score += _WEIGHT_WHY_MATCH
        if meta_str and kw in meta_str:
            score += _WEIGHT_META_MATCH

    # Confidence boost: confidence acts as a multiplier on the raw keyword score
    # but we preserve a floor so even 0-confidence nodes with strong matches surface
    if score > 0:
        confidence = node.get("confidence", 0.5)
        score = score * (0.5 + 0.5 * confidence)  # range: 50%–100% of raw score

    return score


def _score_edge(edge: dict, keywords: list[str]) -> float:
    """Compute keyword-relevance score for an edge."""
    ctx_lower = (edge.get("context") or "").lower()
    rel_lower = (edge.get("relation_type") or "").lower()
    score = 0.0
    for kw in keywords:
        if kw in ctx_lower:
            score += _WEIGHT_EDGE_CONTEXT
        if kw in rel_lower:
            score += _WEIGHT_EDGE_CONTEXT * 0.5
    weight = edge.get("weight", 0.5)
    if score > 0:
        score = score * (0.5 + 0.5 * weight)
    return score


def retrieve_context(
    graph: KnowledgeGraph,
    query: str,
    bfs_depth: int = 2,
    max_nodes: int = 30,
    min_confidence: float = 0.0,
    node_types: Optional[list[str]] = None,
    include_edge_seeds: bool = True,
) -> ContextBundle:
    """Retrieve a ranked context bundle from the knowledge graph.

    Algorithm:
    1. Extract keywords from query
    2. Seed search: keyword-match nodes and (optionally) edges directly
    3. BFS expansion: from seed nodes, traverse edges outward to bfs_depth,
       applying score decay per hop
    4. Collect all edges between included nodes for relationship context
    5. Rank nodes by score desc, edges by score desc
    6. Return ContextBundle

    Args:
        graph: The KnowledgeGraph instance to query.
        query: Free-text query (question, topic, or statement).
        bfs_depth: How many hops to expand from seed nodes (0 = seeds only).
        max_nodes: Maximum nodes to include in the bundle.
        min_confidence: Minimum node confidence to include.
        node_types: If set, restrict seed search to these node_type values.
        include_edge_seeds: Whether to also seed from edge context matches.

    Returns:
        ContextBundle with ranked nodes and edges.
    """
    keywords = extract_keywords(query)

    if not keywords:
        # Fallback: grab all high-confidence nodes if no keywords
        keywords = []

    bundle = ContextBundle(
        query=query,
        keywords=keywords,
        bfs_depth_used=bfs_depth,
    )

    # ── Step 1: Seed node search via keyword matching ─────────────────
    seed_scores: dict[str, float] = {}  # node_id -> score

    if keywords:
        for kw in keywords:
            rows = graph.search_nodes(
                kw,
                node_type=node_types[0] if (node_types and len(node_types) == 1) else None,
                min_confidence=min_confidence,
                limit=50,
            )
            bundle.total_nodes_scanned += len(rows)
            for node in rows:
                # Filter by node_types if multiple types requested
                if node_types and node["node_type"] not in node_types:
                    continue
                nid = node["node_id"]
                sc = _score_node(node, keywords)
                if sc > 0:
                    # Keep best score if node appears for multiple keywords
                    seed_scores[nid] = max(seed_scores.get(nid, 0.0), sc)

    else:
        # No keywords → pull all nodes ordered by confidence as seeds
        all_rows = graph.conn.execute(
            "SELECT * FROM nodes WHERE confidence >= ? ORDER BY confidence DESC LIMIT 50",
            (min_confidence,),
        ).fetchall()
        for row in all_rows:
            node = dict(row)
            bundle.total_nodes_scanned += 1
            seed_scores[node["node_id"]] = node["confidence"]

    # ── Shared node cache (populated lazily throughout) ───────────────
    node_cache: dict[str, dict] = {}

    # Pre-populate cache with already-fetched seed nodes
    for nid in seed_scores:
        if nid not in node_cache:
            n = graph.get_node(nid)
            if n:
                node_cache[nid] = n

    # ── Step 2: Seed from edge context matches ────────────────────────
    edge_seed_node_ids: set[str] = set()
    if include_edge_seeds and keywords:
        edge_rows = graph.conn.execute("SELECT * FROM edges").fetchall()
        bundle.total_edges_scanned += len(edge_rows)
        for row in edge_rows:
            edge = dict(row)
            sc = _score_edge(edge, keywords)
            if sc > 0:
                # Pull both endpoint nodes as seeds (with modest score),
                # but respect node_types filter if provided.
                for nid in (edge["from_node"], edge["to_node"]):
                    n = node_cache.get(nid) or graph.get_node(nid)
                    if not n:
                        continue
                    node_cache[nid] = n
                    if node_types and n["node_type"] not in node_types:
                        continue
                    edge_seed_node_ids.add(nid)
                    seed_scores[nid] = max(seed_scores.get(nid, 0.0), sc * 0.5)

    # ── Step 3: BFS expansion from seed nodes ────────────────────────
    # ranked_nodes accumulates: node_id -> (node, best_score, best_depth)
    ranked: dict[str, tuple[dict, float, int]] = {}

    # Initialize frontier with seeds at depth=0
    for nid, sc in seed_scores.items():
        if nid in node_cache:
            node = node_cache[nid]
            if node.get("confidence", 0.0) >= min_confidence:
                ranked[nid] = (node, sc, 0)

    frontier: list[str] = list(ranked.keys())

    for depth in range(1, bfs_depth + 1):
        if not frontier:
            break
        next_frontier: list[str] = []
        for nid in frontier:
            parent_score = ranked[nid][1]
            # Traverse both outgoing and incoming edges
            edges_out = graph.get_edges_from(nid)
            edges_in = graph.get_edges_to(nid)
            for edge in edges_out + edges_in:
                neighbor_id = edge["to_node"] if edge["from_node"] == nid else edge["from_node"]
                if neighbor_id in ranked:
                    continue  # already visited at a higher score
                n = node_cache.get(neighbor_id) or graph.get_node(neighbor_id)
                if not n:
                    continue
                node_cache[neighbor_id] = n
                if n.get("confidence", 0.0) < min_confidence:
                    continue
                if node_types and n["node_type"] not in node_types:
                    continue
                # Score decays with BFS distance
                neighbor_score = parent_score * (_BFS_DECAY ** depth)
                # Also add any direct keyword relevance at this node
                keyword_bonus = _score_node(n, keywords)
                final_score = max(neighbor_score, keyword_bonus * (_BFS_DECAY ** (depth - 1)))
                ranked[neighbor_id] = (n, final_score, depth)
                next_frontier.append(neighbor_id)
        frontier = next_frontier

    # ── Step 4: Collect edges between included nodes ──────────────────
    included_ids = set(ranked.keys())
    seen_edge_ids: set[str] = set()
    ranked_edges: list[RankedEdge] = []

    for nid in included_ids:
        edges_out = graph.get_edges_from(nid)
        for edge in edges_out:
            eid = edge["edge_id"]
            if eid in seen_edge_ids:
                continue
            if edge["to_node"] not in included_ids:
                continue
            seen_edge_ids.add(eid)
            from_n = node_cache.get(edge["from_node"]) or {}
            to_n = node_cache.get(edge["to_node"]) or {}
            sc = _score_edge(edge, keywords)
            # Edges between higher-scoring nodes get a boost
            from_score = ranked.get(edge["from_node"], (None, 0.0, 0))[1]
            to_score = ranked.get(edge["to_node"], (None, 0.0, 0))[1]
            sc += (from_score + to_score) * 0.1
            ranked_edges.append(RankedEdge(edge=edge, from_node=from_n, to_node=to_n, score=sc))

    # Track edge scan count (approximate — we only traversed included nodes)
    bundle.total_edges_scanned += len(seen_edge_ids)

    # ── Step 5: Rank and cap ──────────────────────────────────────────
    sorted_nodes = sorted(
        [RankedNode(node=n, score=sc, depth=d) for n, sc, d in ranked.values()],
        key=lambda rn: (-rn.score, rn.depth, -rn.node.get("confidence", 0.0)),
    )[:max_nodes]

    sorted_edges = sorted(ranked_edges, key=lambda re: -re.score)

    bundle.nodes = sorted_nodes
    bundle.edges = sorted_edges

    return bundle
