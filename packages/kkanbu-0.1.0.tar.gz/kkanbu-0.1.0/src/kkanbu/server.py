"""kkanbu MCP server — taste oracle for Ouroboros Socratic interviews.

Exposes tools for answering interview questions, teaching preferences,
ingesting repos, flagging uncertainty, and conversational learning.
"""

import json
import logging
import os
import re
import time
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import anthropic
from mcp.server.fastmcp import FastMCP

from kkanbu.graph import KnowledgeGraph
from kkanbu.retrieval import extract_keywords as _extract_keywords, retrieve_context
from kkanbu.session import SESSION_TIMEOUT_SECS, SessionState, SessionStore

logger = logging.getLogger("kkanbu")

# ── Server Setup ──────────────────────────────────────────────

mcp = FastMCP(
    "kkanbu",
    instructions=(
        "Taste oracle — proxies for the user in Ouroboros Socratic interviews "
        "using a knowledge graph of preferences, values, and reasoning patterns"
    ),
)

_anthropic_client: Optional[anthropic.Anthropic] = None

# ── LLM Model Constant ────────────────────────────────────────
_OPUS_MODEL = "claude-opus-4-6"

# ── Multi-User Profile System ────────────────────────────────
# Each user gets an isolated knowledge graph and session store.
# Storage layout:
#   ~/.kkanbu/
#     active_user              ← file containing current default username
#     profiles/
#       <username>/knowledge.db
#
_KKANBU_HOME = Path(os.environ.get("KKANBU_HOME", Path.home() / ".kkanbu"))
_PROFILES_DIR = _KKANBU_HOME / "profiles"
_ACTIVE_USER_FILE = _KKANBU_HOME / "active_user"

# Per-user caches: username → KnowledgeGraph / SessionStore
_user_graphs: dict[str, KnowledgeGraph] = {}
_user_session_stores: dict[str, SessionStore] = {}


def _get_active_user() -> str:
    """Read the currently logged-in user from disk. Returns '' if none."""
    if _ACTIVE_USER_FILE.exists():
        return _ACTIVE_USER_FILE.read_text().strip()
    return ""


def _set_active_user(username: str) -> None:
    """Write the active user to disk."""
    _KKANBU_HOME.mkdir(parents=True, exist_ok=True)
    _ACTIVE_USER_FILE.write_text(username)


def _clear_active_user() -> None:
    """Remove the active user file."""
    if _ACTIVE_USER_FILE.exists():
        _ACTIVE_USER_FILE.unlink()


_USERNAME_PATTERN = re.compile(r'^[a-zA-Z0-9_-]{1,64}$')

# Directories that must never be accessed during ingestion
_SENSITIVE_DIRS = frozenset({".ssh", ".gnupg", ".aws", ".config", ".kube", ".npmrc", ".env"})


def _validate_username(username: str) -> str:
    """Validate username is safe for filesystem use. Raises ValueError if invalid."""
    if not username or not _USERNAME_PATTERN.match(username):
        raise ValueError(
            f"Invalid username '{username}'. "
            "Use only letters, numbers, hyphens, and underscores (1-64 chars)."
        )
    return username


def _validate_ingest_path(path_str: str) -> Path:
    """Validate and resolve an ingestion path, preventing traversal attacks."""
    target = Path(path_str).resolve()
    # Block sensitive directories
    for part in target.parts:
        if part in _SENSITIVE_DIRS:
            raise ValueError(f"Access to '{part}' directories is not allowed for ingestion")
    return target


def _resolve_user(user: str = "") -> str:
    """Resolve which user to operate as.

    Args:
        user: Explicit username. If empty, falls back to the logged-in user.

    Returns:
        The resolved username.

    Raises:
        ValueError: If no user is specified and no one is logged in.
    """
    if user:
        return user
    active = _get_active_user()
    if active:
        return active
    raise ValueError(
        "No user specified and no one is logged in. "
        "Use kkanbu_of_who(action='login', username='...') first, "
        "or pass user='...' to any tool."
    )


def _user_db_path(username: str) -> Path:
    """Return the DB path for a given user profile."""
    return _PROFILES_DIR / username / "knowledge.db"


def _profile_exists(username: str) -> bool:
    """Check if a user profile exists."""
    return _user_db_path(username).parent.exists()


# ── Session State ─────────────────────────────────────────────
# Per-user in-memory session stores for multi-turn tools.
# Sessions expire after SESSION_TIMEOUT_SECS (1800 s = 30 min) of inactivity.

# Minimum acceptable depth for question quality gate (must be at or deeper than this level).
# Levels in ascending depth: surface < preference < value < identity < formative
_CURIOUS_MIN_DEPTH = {"value", "identity", "formative"}

# Surface-question regex patterns — if the generated question matches any of these it is
# flagged as too shallow and triggers a single retry with an explicit failure note.
_SURFACE_QUESTION_PATTERNS = [
    re.compile(r"\bdo you prefer\b", re.IGNORECASE),
    re.compile(r"\bwhich do you (like|prefer|enjoy)\b", re.IGNORECASE),
    re.compile(r"\bwhat('s| is) your (favorite|preferred)\b", re.IGNORECASE),
    re.compile(r"\bdo you (use|like|enjoy)\b", re.IGNORECASE),
    re.compile(r"\bhow (often|much) do you\b", re.IGNORECASE),
    re.compile(r"\bwhat (tools?|framework|language|library)\b", re.IGNORECASE),
]

# Minimum token-overlap fraction for a continuing-session question to be considered
# "on-thread".  Below this threshold the question is treated as scattering to an
# unrelated topic and triggers a single retry with an explicit coherence note.
#
# With threshold 0.25, a 2–4-word thread topic requires at least ONE meaningful
# keyword to appear in the question text or proposed new thread label — lenient
# enough to allow synonym-based follow-ups while catching total topic scatter.
_COHERENCE_THRESHOLD = 0.25

# Stop-words excluded from token overlap so common question words (what, your, the …)
# don't create false positives in coherence scoring.
_COHERENCE_STOP_WORDS: frozenset[str] = frozenset({
    "a", "an", "the", "and", "or", "but", "in", "on", "at", "to", "for",
    "of", "with", "is", "are", "was", "were", "be", "been", "being",
    "have", "has", "had", "do", "does", "did", "will", "would", "could",
    "should", "may", "might", "shall", "can", "not", "no", "nor",
    "so", "yet", "both", "either", "neither", "each", "that", "this",
    "it", "its", "i", "you", "he", "she", "we", "they", "your", "my",
    "what", "when", "how", "why", "where", "who", "which", "ever",
    "about", "than", "then", "now", "just", "only", "also", "very",
})


def get_graph(user: str = "") -> KnowledgeGraph:
    """Get the KnowledgeGraph for a user. Caches per-user instances.

    Args:
        user: Username. If empty, resolves from active user.
    """
    username = _resolve_user(user)

    if username not in _user_graphs:
        db_path_env = os.environ.get("KKANBU_DB_PATH")
        if db_path_env and username.startswith("_test_"):
            # Test-only override: use env var directly
            _user_graphs[username] = KnowledgeGraph(Path(db_path_env))
        else:
            db_path = _user_db_path(username)
            db_path.parent.mkdir(parents=True, exist_ok=True)
            _user_graphs[username] = KnowledgeGraph(db_path)

    return _user_graphs[username]


def _get_session_store(user: str = "") -> SessionStore:
    """Get the SessionStore for a user. Caches per-user instances."""
    username = _resolve_user(user)
    if username not in _user_session_stores:
        _user_session_stores[username] = SessionStore(timeout_secs=SESSION_TIMEOUT_SECS)
    return _user_session_stores[username]


def _get_anthropic_client() -> anthropic.Anthropic:
    """Lazy-initialize and return the Anthropic client."""
    global _anthropic_client
    if _anthropic_client is None:
        _anthropic_client = anthropic.Anthropic()
    return _anthropic_client


def _require_llm(tool_name: str) -> str | None:
    """Check if the Anthropic API key is configured. Returns error JSON string if not, None if OK."""
    api_key = os.environ.get("ANTHROPIC_API_KEY", "")
    if not api_key:
        return json.dumps({
            "error": f"{tool_name} requires an Anthropic API key. Set ANTHROPIC_API_KEY environment variable.",
        })
    return None


# ── Profile Management ───────────────────────────────────────

@mcp.tool()
def kkanbu_of_who(action: str, username: str = "") -> str:
    """Manage user profiles — create, delete, list, login, logout.

    Use this to switch between users or set up new profiles. Each user
    gets an isolated knowledge graph.

    Args:
        action: One of "create", "delete", "list", "login", "logout".
        username: Required for create, delete, login. Ignored for list/logout.

    Returns JSON:
        {"action": str, "username": str, "message": str}
        For "list": includes "profiles": [str], "active_user": str
    """
    action = action.lower().strip()

    # Validate username for actions that use it
    if action in ("create", "delete", "login") and username:
        try:
            _validate_username(username)
        except ValueError as e:
            return json.dumps({"error": str(e)})

    if action == "list":
        _PROFILES_DIR.mkdir(parents=True, exist_ok=True)
        profiles = sorted([
            d.name for d in _PROFILES_DIR.iterdir()
            if d.is_dir() and (d / "knowledge.db").exists()
        ])
        active = _get_active_user()

        if not profiles:
            return json.dumps({
                "action": "list",
                "profiles": [],
                "active_user": active,
                "message": "No profiles yet. Use action='create' to create one.",
            })

        return json.dumps({
            "action": "list",
            "profiles": profiles,
            "active_user": active,
            "message": f"{len(profiles)} profile(s). Active: {active or '(none)'}",
        })

    elif action == "create":
        if not username:
            return json.dumps({"error": "username is required for 'create'"})

        if _profile_exists(username):
            return json.dumps({
                "action": "create",
                "username": username,
                "message": f"Profile '{username}' already exists.",
            })

        # Creating the graph auto-creates the directory and DB
        db_path = _user_db_path(username)
        db_path.parent.mkdir(parents=True, exist_ok=True)
        KnowledgeGraph(db_path)

        return json.dumps({
            "action": "create",
            "username": username,
            "db_path": str(db_path),
            "message": f"Profile '{username}' created.",
        })

    elif action == "delete":
        if not username:
            return json.dumps({"error": "username is required for 'delete'"})

        if not _profile_exists(username):
            return json.dumps({
                "action": "delete",
                "username": username,
                "message": f"Profile '{username}' does not exist.",
            })

        # Remove from caches
        _user_graphs.pop(username, None)
        _user_session_stores.pop(username, None)

        # Clear active user if this was the logged-in user
        if _get_active_user() == username:
            _clear_active_user()

        # Delete the profile directory
        import shutil
        profile_dir = _PROFILES_DIR / username
        shutil.rmtree(profile_dir, ignore_errors=True)

        return json.dumps({
            "action": "delete",
            "username": username,
            "message": f"Profile '{username}' deleted.",
        })

    elif action == "login":
        if not username:
            return json.dumps({"error": "username is required for 'login'"})

        if not _profile_exists(username):
            # Auto-create profile on login
            db_path = _user_db_path(username)
            db_path.parent.mkdir(parents=True, exist_ok=True)
            KnowledgeGraph(db_path)

        _set_active_user(username)

        return json.dumps({
            "action": "login",
            "username": username,
            "message": f"Logged in as '{username}'.",
        })

    elif action == "logout":
        active = _get_active_user()
        _clear_active_user()

        return json.dumps({
            "action": "logout",
            "previous_user": active,
            "message": f"Logged out{f' from {active}' if active else ''}.",
        })

    else:
        return json.dumps({
            "error": f"Unknown action '{action}'. Use: create, delete, list, login, logout.",
        })


# ── AC7b: LLM Distillation Pipeline ──────────────────────────
# On session end (stale prune) or explicit trigger (kkanbu_distill), accumulated
# conversation history is sent to claude-opus-4-6 which extracts discrete typed
# learnings (preferences, values, patterns, observations, reasoning) and writes
# them to the knowledge graph.  This is the ephemeral-to-persistent distillation
# step described in the architecture spec.

_DISTILLATION_SYSTEM_PROMPT = """\
You are kkanbu's session distillation engine. Given a conversation transcript from a
completed or active session, extract discrete, persistent learnings about who the USER IS.

The conversation may be from any session type:
- "curious":      Multi-turn deep questioning — you asked probing questions, user responded
- "teach":        User explicitly taught you their preferences, values, and patterns
- "answer":       Interview Q&A — kkanbu answered questions on the user's behalf
- "conversation": Flag-resolution conversation resolving uncertain knowledge

YOUR TASK: Extract everything learnable from the FULL arc of this conversation.
Focus on what the USER said, revealed, or clearly implied — not the assistant's output.
For "curious" sessions, the user's RESPONSES are the gold mine — mine them deeply.
For "teach" sessions, extract from explicit statements AND implied identity patterns.
For "answer" sessions, extract from the domain of the question and any user corrections.

LEARNING TYPES — use the most precise type:
- preference:   What they choose, reach for, or favor in practice
- value:        What they deeply care about — principles, ethics, priorities
- pattern:      Recurring behaviors, habits, or ways of operating
- reasoning:    The WHY behind a preference or value
- observation:  A general truth about this person (skill, background, context)

DEPTH PRINCIPLE: Prefer identity-level learnings over surface ones.
  Surface: "Prefers dark mode"
  Identity: "Treats cognitive load as finite — optimizes environment to protect deep work"

UPSERT RULE: If an existing graph node captures the same knowledge less precisely,
include its node_id in "upsert_node_id" to update it rather than duplicate it.
Only upsert on genuine semantic overlap — create new nodes for distinct insights.

OUTPUT VALID JSON ONLY — no markdown fences, no commentary:
{
  "learnings": [
    {
      "content": "concise first-person statement of the learning",
      "node_type": "preference|value|pattern|reasoning|observation",
      "why": "reasoning context behind this learning, or null if not available",
      "confidence": 0.6-0.9,
      "depth": "surface|identity",
      "upsert_node_id": "existing_node_id_to_update or null"
    }
  ],
  "session_synthesis": "2-3 sentences: what this session revealed about who this person is",
  "distillation_notes": "1 sentence: anything unusual about this conversation or gaps noticed"
}

Extract 2-10 learnings per session. Quality over quantity — skip obvious or duplicative ones.
Only extract from what the USER actually said or clearly implied through their responses.
"""


def _format_transcript_for_distillation(session: "SessionState") -> str:
    """Format a session's conversation history as a readable transcript for LLM distillation."""
    lines = [
        f"Session type: {session.session_type}",
        f"Total turns: {session.turn_count}",
        "",
        "--- CONVERSATION TRANSCRIPT ---",
    ]
    for msg in session.history:
        label = "USER" if msg.role == "user" else "KKANBU"
        lines.append(f"\n{label}: {msg.content}")
    lines.append("\n--- END TRANSCRIPT ---")
    return "\n".join(lines)


def _distill_session_to_graph(session: "SessionState", user: str = "") -> dict:
    """Distill ephemeral session conversation history into persistent graph learnings.

    Sends the full conversation transcript to claude-opus-4-6, which extracts discrete
    typed learnings (preferences, values, patterns, observations, reasoning) and writes
    them to the knowledge graph via upsert_node().

    This is the core ephemeral-to-persistent distillation step.  It runs automatically
    when a session expires (via _distill_and_prune_stale_sessions) and can also be
    triggered explicitly via the kkanbu_distill tool.

    Args:
        session: The SessionState whose history should be distilled.

    Returns:
        Dict with:
          learnings_written: Number of nodes created or updated in the graph.
          learning_ids:      List of node_ids written during this distillation.
          session_synthesis: LLM's synthesis of what the session revealed.

    Notes:
        - Sessions without both user and assistant turns are skipped (nothing to distill).
        - All failures are non-fatal — returns an empty result dict on any error.
    """
    # Only distill sessions with meaningful two-sided conversation
    user_turns = [m for m in session.history if m.role == "user"]
    assistant_turns = [m for m in session.history if m.role == "assistant"]

    if not user_turns or not assistant_turns:
        # Single-sided or empty — nothing worth distilling
        return {"learnings_written": 0, "learning_ids": [], "session_synthesis": ""}

    graph = get_graph(user)
    graph_dump = graph.get_full_dump()
    existing_knowledge = _format_existing_knowledge(graph_dump)
    existing_node_ids = {n["node_id"] for n in graph_dump.get("nodes", [])}

    transcript = _format_transcript_for_distillation(session)

    user_msg = (
        f"{transcript}\n\n"
        f"{existing_knowledge}\n\n"
        "Distill this session into discrete persistent learnings about the user. "
        "Output JSON only."
    )

    try:
        client = _get_anthropic_client()
        response = client.messages.create(
            model=_OPUS_MODEL,
            max_tokens=2000,
            system=_DISTILLATION_SYSTEM_PROMPT,
            messages=[{"role": "user", "content": user_msg}],
        )
        raw = response.content[0].text.strip()

        # Strip markdown fences if present
        fence_match = re.search(r"```(?:json)?\s*([\s\S]*?)\s*```", raw)
        if fence_match:
            raw = fence_match.group(1).strip()

        extracted = json.loads(raw)

    except Exception as exc:
        logger.warning(
            "Session distillation failed for %s session %s: %s",
            session.session_type, session.session_id[:8], exc,
        )
        return {"learnings_written": 0, "learning_ids": [], "session_synthesis": ""}

    learnings = extracted.get("learnings", [])
    if not learnings:
        return {
            "learnings_written": 0,
            "learning_ids": [],
            "session_synthesis": extracted.get("session_synthesis", ""),
        }

    # Whitelist of valid node_types for distillation output
    _VALID_DISTILL_TYPES = {"preference", "value", "pattern", "reasoning", "observation"}

    # AC7c: UTC timestamp stamped on all nodes written in this distillation run.
    # Stored in metadata so the originating session and run time are always
    # recoverable from the node record alone.
    distill_timestamp = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

    learning_ids: list[str] = []
    # Track only brand-new (non-upserted) nodes for the edge-inference pass.
    # Upserted nodes already exist in the graph and likely have established edges;
    # running inference only for fresh nodes avoids redundant or duplicate edges.
    newly_created_ids: list[str] = []

    for learning in learnings:
        upsert_id = learning.get("upsert_node_id") or None
        # Validate upsert_id — must reference an actual existing node
        if upsert_id and upsert_id not in existing_node_ids:
            upsert_id = None

        node_type = learning.get("node_type", "observation")
        if node_type not in _VALID_DISTILL_TYPES:
            node_type = "observation"  # Safe fallback for unexpected types

        # AC7c: Source provenance metadata — records which session produced this
        # learning so audits can trace any graph node back to its originating
        # conversation without inspecting the ephemeral session store.
        provenance_meta: dict = {
            "distill_session_id": session.session_id,
            "distill_session_type": session.session_type,
            "distilled_at": distill_timestamp,
        }

        try:
            nid, was_updated = graph.upsert_node(
                node_type=node_type,
                content=learning["content"],
                source=f"distill:{session.session_type}",
                node_id=upsert_id,
                why=learning.get("why") or None,
                confidence=float(learning.get("confidence", 0.75)),
                metadata=provenance_meta,
            )
            learning_ids.append(nid)
            if not was_updated:
                newly_created_ids.append(nid)
        except Exception as exc:
            logger.warning("Failed to write distilled learning to graph: %s", exc)

    # AC7c: Edge inference — link newly distilled nodes to pre-existing graph entities.
    # After writing nodes, run a best-effort Opus pass that discovers typed semantic
    # edges between freshly created distilled nodes and pre-existing knowledge.
    # This mirrors the kkanbu_learn edge-inference second pass and is non-blocking:
    # failures are logged and silenced so a broken edge inference never blocks
    # the caller from receiving the distillation result.
    if newly_created_ids and existing_node_ids:
        _infer_edges_for_new_nodes(
            graph=graph,
            new_node_ids=newly_created_ids,
            pre_existing_ids=existing_node_ids,
        )

    return {
        "learnings_written": len(learning_ids),
        "learning_ids": learning_ids,
        "session_synthesis": extracted.get("session_synthesis", ""),
    }


def _distill_and_prune_stale_sessions(user: str = "") -> int:
    """Distill learnings from stale sessions before removing them from the store.

    Distillation is best-effort: individual session failures are logged and silenced
    so that a distillation error never blocks the pruning sweep.

    Args:
        user: Username whose session store to prune.

    Returns:
        Number of sessions pruned (same semantics as SessionStore.prune_stale()).
    """
    store = _get_session_store(user)
    now = time.time()
    stale_sessions = [
        s for s in store._sessions.values()
        if now - s.last_active > store.timeout_secs
    ]

    for session in stale_sessions:
        has_user = any(m.role == "user" for m in session.history)
        has_assistant = any(m.role == "assistant" for m in session.history)
        if has_user and has_assistant:
            try:
                result = _distill_session_to_graph(session, user=user)
                if result["learnings_written"] > 0:
                    logger.info(
                        "Auto-distilled %d learning(s) from stale %s session %s",
                        result["learnings_written"],
                        session.session_type,
                        session.session_id[:8],
                    )
            except Exception as exc:
                logger.warning(
                    "Auto-distillation failed for %s session %s (non-blocking): %s",
                    session.session_type, session.session_id[:8], exc,
                )

    return store.prune_stale()


# ── Sub-AC 9c: Eager curious distillation ─────────────────────────────────────
# When kkanbu_curious receives a user response that leads to a question of
# value/identity/formative depth, we distill the exchange into the graph
# immediately rather than waiting for session expiry.  This ensures that novel
# insights surfaced mid-conversation are not lost if the session is abandoned.


def _maybe_distill_curious_exchange(session: "SessionState", depth_level: str, user: str = "") -> dict:
    """Eagerly distill a curious session when the exchange surfaces novel insights.

    Called inside kkanbu_curious after each turn where the user provided a response
    and the generated question achieved value/identity/formative depth.  This
    implements the "during conversation" half of the ephemeral-to-graph distillation
    spec: learnings from high-quality exchanges are written to the graph immediately
    rather than waiting for session expiry.

    Idempotency: ``session.metadata["last_distilled_turn"]`` tracks which assistant
    turn was last distilled.  Distillation is skipped when the turn count has not
    advanced since the last successful run.

    Args:
        session:     The active curious session with current history.
        depth_level: The depth_level reported by Opus for the just-generated question.

    Returns:
        Dict with learnings_written (int), learning_ids (list[str]),
        and session_synthesis (str).  Returns an empty result dict on failure
        or when preconditions are not met (shallow depth, nothing new to distill).
    """
    _EMPTY = {"learnings_written": 0, "learning_ids": [], "session_synthesis": ""}

    # Only distill when the exchange reached identity-level depth
    if depth_level not in _CURIOUS_MIN_DEPTH:
        return _EMPTY

    # Idempotency guard: skip if already distilled this exact turn
    current_turn = session.turn_count
    last_distilled = session.metadata.get("last_distilled_turn", 0)
    if current_turn <= last_distilled:
        return _EMPTY

    # Need at least one user turn in history to have something to distill
    has_user = any(m.role == "user" for m in session.history)
    if not has_user:
        return _EMPTY

    try:
        result = _distill_session_to_graph(session, user=user)
        if result.get("learnings_written", 0) > 0:
            # Mark current turn as distilled so follow-up calls don't re-run
            session.metadata["last_distilled_turn"] = current_turn
            logger.info(
                "Eager curious distillation: wrote %d learning(s) from turn %d of session %s",
                result["learnings_written"],
                current_turn,
                session.session_id[:8],
            )
        return result
    except Exception as exc:
        logger.warning(
            "Eager curious distillation failed for session %s (non-blocking): %s",
            session.session_id[:8], exc,
        )
        return _EMPTY


# ── AC1: kkanbu_answer ────────────────────────────────────────

_ANSWER_SYSTEM_PROMPT = """\
You are kkanbu — a taste oracle that speaks AS a specific person in a Socratic interview.
You have been given a knowledge graph of their preferences, values, reasoning patterns,
and beliefs. Your job is to answer interview questions EXACTLY as that person would.

VOICE FIDELITY RULES:
1. Speak in first person as the user — "I prefer...", "For me, ...", "I always...", etc.
2. Match their tone: direct and opinionated where their confidence is high, honestly
   uncertain where the graph shows low confidence or no knowledge.
3. Ground every claim in their actual values and reasoning from the graph — don't invent.
4. Use the WHY fields to explain their reasoning in their own voice.
5. Be concise and natural — one or two focused paragraphs max.
   Avoid bullet lists unless the question naturally invites them.
6. NEVER add AI caveats, meta-commentary ("Based on my knowledge..."), or disclaimers.
   You ARE this person right now — answer as they would, not about them.
7. If the graph shows no relevant knowledge, say so honestly in first person:
   "Honestly, I haven't thought much about this yet."
8. Confidence calibration:
   - HIGH (>=0.75): State preferences firmly, no hedging.
   - MODERATE (0.50-0.74): "I tend to..." / "I generally prefer..."
   - LOW (<0.50): "I'm not entirely sure, but I think..." / "My instinct is..."

PHRASING PATTERNS (use sparingly, not as templates):
- "I reach for X because..."
- "For me it comes down to..."
- "I'm pretty opinionated about this — ..."
- "Honestly, I lean towards..."
- "It depends, but my default is..."

The knowledge context will be provided in the user message.

OUTPUT FORMAT — respond with valid JSON only, no markdown fences:
{
  "answer": "...",
  "llm_confidence": 0.0,
  "uncertainty_reasoning": null
}

SELF-ASSESSMENT INSTRUCTIONS:
- "answer": the voice-faithful response as described above.
- "llm_confidence": your honest estimate (0.0–1.0) of how well the graph represents this
  person's actual view on the topic being asked.
  - 0.85–1.0: graph has rich, directly relevant, high-confidence entries for this topic
  - 0.65–0.84: graph has relevant entries but some gaps; minor extrapolation needed
  - 0.40–0.64: graph is only tangentially relevant; moderate extrapolation required
  - 0.00–0.39: graph has little or no relevant knowledge; answer is largely inferred
- "uncertainty_reasoning": null when llm_confidence >= 0.65. When llm_confidence < 0.65,
  write 1–2 factual sentences explaining specifically what knowledge is absent or what
  you are extrapolating from. Example: "No entries about database preferences exist in the
  graph. I'm extrapolating from general engineering-simplicity values."
  Do NOT use hedging language or meta-commentary — state the gap plainly.
"""


# ── AnswerResult ───────────────────────────────────────────────

@dataclass
class AnswerResult:
    """Structured result from _llm_generate_answer, including the LLM's confidence self-assessment."""

    answer: str
    llm_confidence: float
    uncertainty_reasoning: Optional[str]


def _llm_generate_answer(question: str, context_payload: str) -> AnswerResult:
    """Call claude-opus-4-6 to generate a voice-faithful answer with confidence self-assessment.

    The LLM is instructed to return structured JSON containing the answer text, a
    self-assessed confidence score (llm_confidence), and—when confidence is low—an
    uncertainty_reasoning string that names the specific knowledge gaps driving the
    uncertainty.

    Args:
        question: The interview question to answer.
        context_payload: Assembled context from the knowledge graph.

    Returns:
        AnswerResult with answer, llm_confidence, and uncertainty_reasoning.

    Raises:
        Exception: If the Anthropic API call fails.
    """
    client = _get_anthropic_client()

    user_msg = (
        f"{context_payload}\n\n"
        f"Interview question: {question}"
    )

    response = client.messages.create(
        model=_OPUS_MODEL,
        max_tokens=1024,
        system=_ANSWER_SYSTEM_PROMPT,
        messages=[{"role": "user", "content": user_msg}],
    )

    raw_text = response.content[0].text.strip()

    # Parse structured JSON response from the LLM.
    # Fallback to treating the raw text as the answer with a moderate confidence score
    # when the LLM does not emit valid JSON (e.g. legacy mocks or unexpected format).
    try:
        parsed = json.loads(raw_text)
        answer_text = parsed["answer"]
        llm_confidence = float(parsed.get("llm_confidence", 0.7))
        # Clamp to [0.0, 1.0] to guard against out-of-range LLM output
        llm_confidence = max(0.0, min(1.0, llm_confidence))
        uncertainty_reasoning: Optional[str] = parsed.get("uncertainty_reasoning") or None
        # Normalise empty-string reasoning to None
        if uncertainty_reasoning is not None and not uncertainty_reasoning.strip():
            uncertainty_reasoning = None
        return AnswerResult(
            answer=answer_text,
            llm_confidence=llm_confidence,
            uncertainty_reasoning=uncertainty_reasoning,
        )
    except (json.JSONDecodeError, KeyError, TypeError):
        # Plain-text response (e.g. from a legacy mock or mis-formatted LLM output).
        # Treat as a moderate-confidence answer without structured reasoning.
        logger.debug("_llm_generate_answer: non-JSON response, treating as plain-text answer")
        return AnswerResult(
            answer=raw_text,
            llm_confidence=0.7,
            uncertainty_reasoning=None,
        )


@mcp.tool()
def kkanbu_answer(question: str, session_id: str = "", user: str = "") -> str:
    """Answer a Socratic interview question on behalf of the user.

    Retrieves relevant knowledge from the graph using selective retrieval,
    assembles it into a structured context payload, then uses claude-opus-4-6
    to generate a voice-faithful answer in the user's persona. If confidence
    is low, automatically flags the question for later review.

    Session lifecycle: on the first call (no session_id) a new "answer" session
    is created and its ID is returned so the caller can continue tracking the
    conversation. Subsequent calls with the same session_id retrieve the existing
    session and extend its history (enabling multi-turn context awareness).

    Args:
        question: The interview question to answer.
        session_id: Optional session identifier for multi-turn tracking. Leave
            empty to start a new session; a new session_id is returned.
        user: Username to operate as. If empty, uses the logged-in user.

    Returns:
        JSON string with keys:
          session_id, answer, confidence (graph-level), llm_confidence (LLM self-assessed),
          flagged (bool), uncertainty_reasoning (str|null), turn, is_new_session.
    """
    llm_err = _require_llm("kkanbu_answer")
    if llm_err:
        return llm_err
    _distill_and_prune_stale_sessions(user)
    graph = get_graph(user)

    # ── Session lifecycle ─────────────────────────────────────────────────────
    session, is_new = _get_session_store(user).get_or_create(
        session_id or None,
        session_type="answer",
        question_asked=question,
    )
    sid = session.session_id

    # Record the incoming question as a user turn in the ephemeral history
    session.append("user", question)

    # Retrieve ranked context bundle from the knowledge graph
    bundle = retrieve_context(
        graph,
        question,
        bfs_depth=2,
        max_nodes=25,
    )

    confidence = bundle.average_confidence() if not bundle.is_empty() else 0.1

    # Assemble structured context payload for LLM.
    # assemble_context_payload() handles the empty-bundle case gracefully —
    # it emits a "No relevant knowledge found" section so Opus can respond
    # naturally in the user's voice rather than being bypassed entirely.
    context_payload = bundle.to_prompt_payload(question=question)

    # Always call Opus — even with an empty graph — so the answer is always
    # voice-faithful.  The context payload already encodes any knowledge gaps.
    # _llm_generate_answer now returns an AnswerResult that includes the LLM's
    # own confidence self-assessment and (optionally) uncertainty reasoning.
    llm_confidence: float = 0.7
    uncertainty_reasoning: Optional[str] = None
    try:
        result = _llm_generate_answer(question, context_payload)
        answer = result.answer
        llm_confidence = result.llm_confidence
        uncertainty_reasoning = result.uncertainty_reasoning
    except Exception as exc:
        logger.error("LLM answer generation failed: %s", exc)
        return json.dumps({
            "session_id": sid,
            "error": f"LLM answer generation failed: {exc}",
            "turn": session.turn_count,
            "is_new_session": is_new,
        })

    # ── Uncertainty flagging ───────────────────────────────────────────────────
    # Flag when EITHER the graph confidence is low (<0.4) OR the LLM rates its
    # own confidence below 0.5 — meaning it had to extrapolate significantly.
    # When the LLM provides uncertainty_reasoning, it is appended to the answer
    # so the interviewer can see exactly why the oracle is uncertain.
    flagged = False
    effective_confidence = min(confidence, llm_confidence)

    if confidence < 0.4 or llm_confidence < 0.5:
        flagged = True
        _flag_question(question, answer, effective_confidence)
        if uncertainty_reasoning:
            answer += (
                f"\n\n⚑ Flagged for review (graph: {confidence:.2f}, "
                f"llm: {llm_confidence:.2f}): {uncertainty_reasoning}"
            )
        else:
            answer += (
                f"\n\n⚑ This answer has been flagged for review "
                f"(graph confidence: {confidence:.2f}, llm confidence: {llm_confidence:.2f})"
            )

    # Passive learning: record that this question was asked
    _passive_learn(f"Answered interview question: {question}", "observation")

    # Record the generated answer as an assistant turn in the ephemeral history
    session.append("assistant", answer)

    return json.dumps({
        "session_id": sid,
        "answer": answer,
        "confidence": round(confidence, 3),
        "llm_confidence": round(llm_confidence, 3),
        "flagged": flagged,
        "uncertainty_reasoning": uncertainty_reasoning,
        "turn": session.turn_count,
        "is_new_session": is_new,
    })


# ── AC2: kkanbu_learn (Opus-powered) ──────────────────────────

# ── Sub-AC 3c: Autonomous Edge-Writing Pipeline ───────────────
_EDGE_INFERENCE_SYSTEM_PROMPT = """\
You are the relationship inference engine for kkanbu's knowledge graph.

Given a set of NEWLY ADDED nodes and a selection of EXISTING nodes from the graph,
your task is to identify genuine semantic relationships between them and write typed edges.

RELATION TYPE VOCABULARY — choose the most precise type:
- supports:     New node provides evidence for or strengthens the existing node
- contradicts:  New node conflicts with or opposes the existing node
- derives_from: New node is a consequence or specific instance of the existing node
- generalizes:  New node is a broader abstraction; existing node is an example of it
- exemplifies:  New node is a concrete example of the existing node's principle
- refines:      New node is a more precise or nuanced version of the existing node
- challenges:   New node raises questions about or complicates the existing node

EDGE QUALITY RULES:
1. Only write edges with genuine semantic meaning — not just keyword overlap.
2. Each edge MUST have a context that explains the causal/logical reason for the relationship.
3. Weight reflects connection strength: 0.3=tenuous, 0.6=meaningful, 0.85=strong/direct.
4. Each new node should connect to 0-3 existing nodes maximum — quality over quantity.
5. Prefer identity-level connections: How does this new value relate to an existing belief?
6. DO NOT create edges between nodes with the same content (upserted nodes already merged).

OUTPUT valid JSON only — no markdown fences, no extra commentary:
{
  "edges": [
    {
      "from_new_node_id": "node_id_of_newly_created_or_updated_node",
      "to_existing_node_id": "node_id_of_existing_graph_node",
      "relation_type": "supports|contradicts|derives_from|generalizes|exemplifies|refines|challenges",
      "weight": 0.3-0.9,
      "context": "specific 1-sentence reasoning: WHY these nodes are semantically connected"
    }
  ],
  "inference_notes": "1-2 sentence summary of the cross-cutting themes identified"
}

If no meaningful edges exist, return {"edges": [], "inference_notes": "No strong connections identified."}
"""


def _format_nodes_for_edge_inference(nodes: list[dict], label: str) -> str:
    """Format node list as a compact numbered block for the edge inference prompt."""
    if not nodes:
        return f"{label}: none\n"
    lines = [f"{label} ({len(nodes)} nodes):"]
    for n in nodes:
        why_snippet = f" | why: {n['why'][:80]}" if n.get("why") else ""
        lines.append(
            f"  [{n['node_id']}] ({n['node_type']}, conf={n['confidence']:.1f}) "
            f"{n['content'][:120]}{why_snippet}"
        )
    return "\n".join(lines)


def _infer_edges_for_new_nodes(
    graph: "KnowledgeGraph",
    new_node_ids: list[str],
    pre_existing_ids: set[str],
) -> int:
    """Run a dedicated Opus pass to infer typed edges between new and existing nodes.

    This is a second-pass pipeline that fires after kkanbu_learn has created nodes.
    It examines each newly written node against the existing graph and autonomously
    writes semantic edges that encode the relationships the LLM identifies.

    Args:
        graph: The KnowledgeGraph instance.
        new_node_ids: IDs of nodes just created or updated in this teach call.
        pre_existing_ids: IDs of nodes that existed BEFORE this teach call.

    Returns:
        Number of edges written by the inference pass. Returns 0 on any failure
        (edge inference is a best-effort enhancement, never a blocker).
    """
    if not new_node_ids or not pre_existing_ids:
        return 0  # Nothing to connect

    # Fetch full content of newly created nodes
    new_nodes = []
    for nid in new_node_ids:
        node = graph.get_node(nid)
        if node:
            new_nodes.append(node)

    if not new_nodes:
        return 0

    # Build a semantically relevant selection of existing nodes.
    # Strategy: score each existing node by keyword overlap with the new nodes,
    # then take the top-50 by relevance (fallback: recency).
    new_content_blob = " ".join(
        f"{n['content']} {n.get('why', '') or ''}" for n in new_nodes
    ).lower()
    new_keywords = set(_extract_keywords(new_content_blob))

    existing_nodes_raw = [
        n for n in graph.get_full_dump()["nodes"]
        if n["node_id"] in pre_existing_ids
        and n["node_type"] not in ("flag", "debug_learning")
    ]

    def _relevance_score(node: dict) -> int:
        blob = f"{node['content']} {node.get('why', '') or ''}".lower()
        return sum(1 for kw in new_keywords if kw in blob)

    existing_nodes_sorted = sorted(existing_nodes_raw, key=_relevance_score, reverse=True)
    existing_nodes = existing_nodes_sorted[:50]  # Cap at 50 to keep prompt manageable

    if not existing_nodes:
        return 0  # No existing knowledge to connect to

    # Build the inference prompt
    new_block = _format_nodes_for_edge_inference(new_nodes, "NEWLY ADDED NODES")
    existing_block = _format_nodes_for_edge_inference(existing_nodes, "EXISTING GRAPH NODES")

    user_msg = (
        f"{new_block}\n\n"
        f"{existing_block}\n\n"
        "Identify semantic relationships between the NEWLY ADDED nodes and the EXISTING nodes. "
        "Focus on relationships that encode WHY these ideas are connected at an identity level — "
        "how do the new learnings reinforce, challenge, or derive from existing beliefs? "
        "Output JSON only."
    )

    # Call Opus for edge inference
    try:
        client = _get_anthropic_client()
        response = client.messages.create(
            model=_OPUS_MODEL,
            max_tokens=1024,
            system=_EDGE_INFERENCE_SYSTEM_PROMPT,
            messages=[{"role": "user", "content": user_msg}],
        )
        raw = response.content[0].text.strip()

        # Strip markdown fences if present
        fence_match = re.search(r"```(?:json)?\s*([\s\S]*?)\s*```", raw)
        if fence_match:
            raw = fence_match.group(1).strip()

        inference_result = json.loads(raw)
    except Exception as exc:
        logger.warning("Edge inference pass failed (non-blocking): %s", exc)
        return 0

    # Write inferred edges — LLM has full autonomy
    edges_written = 0
    new_node_id_set = set(new_node_ids)

    for edge_spec in inference_result.get("edges", []):
        from_id = edge_spec.get("from_new_node_id", "")
        to_id = edge_spec.get("to_existing_node_id", "")

        # Validate: from_id must be a new node, to_id must be a pre-existing node
        if from_id not in new_node_id_set:
            continue
        if to_id not in pre_existing_ids:
            continue
        if from_id == to_id:
            continue

        relation_type = edge_spec.get("relation_type", "supports")
        # Whitelist valid relation types
        valid_types = {
            "supports", "contradicts", "derives_from", "generalizes",
            "exemplifies", "refines", "challenges",
        }
        if relation_type not in valid_types:
            relation_type = "supports"

        weight = float(edge_spec.get("weight", 0.6))
        weight = max(0.1, min(1.0, weight))  # clamp to [0.1, 1.0]

        context = edge_spec.get("context") or "Inferred by edge pipeline"

        try:
            graph.add_edge(
                from_node=from_id,
                to_node=to_id,
                relation_type=relation_type,
                weight=weight,
                context=f"[edge-inference] {context}",
            )
            edges_written += 1
        except Exception:
            pass  # Individual edge failure should not stop the pipeline

    return edges_written


_TEACH_SYSTEM_PROMPT = """\
You are kkanbu's identity learning engine. Given content shared by or about a person,
extract deep, layered learnings about WHO THEY ARE — not just surface preferences.

The knowledge graph stores nodes with these types:
- preference: What they choose and how they work
- value: What they care about at a deeper level, their principles
- pattern: Recurring behaviors, habits, conventions
- reasoning: The WHY behind preferences and values
- observation: General truths about this person

DEPTH-OVER-SURFACE PRINCIPLE: Go beyond the surface.
Surface: "I prefer pytest"
Identity: "Values developer experience — tools should stay out of the way of thinking"

UPSERT RULE: If an existing node in the graph already captures the same knowledge but less
precisely or with lower confidence, provide its node_id in "upsert_node_id" to UPDATE that
node rather than creating a duplicate. Only upsert when the existing content genuinely
overlaps — create new nodes for truly distinct insights.

OUTPUT VALID JSON ONLY — no markdown, no explanation, just the JSON object:
{
  "learnings": [
    {
      "content": "concise, first-person phrasing of the learning",
      "node_type": "preference|value|pattern|reasoning|observation",
      "why": "deeper reasoning string or null",
      "confidence": 0.7-0.95,
      "depth": "surface|identity",
      "upsert_node_id": "existing_node_id_to_update_or_null"
    }
  ],
  "connections": [
    {
      "learning_index": 0,
      "to_node_id": "existing_node_id_from_graph_or_null",
      "to_learning_index": "index_of_another_new_learning_or_null",
      "relation_type": "supports|contradicts|derives_from|generalizes|exemplifies",
      "context": "why this connection exists"
    }
  ],
  "identity_summary": "1-2 sentence synthesis of WHO this person IS based on extracted learnings"
}

Extract 3-8 learnings per input. At least 50% should be identity-level (values, beliefs, deep patterns).
Ask yourself: What does this reveal about their worldview? What do they fundamentally believe?
YOU decide every node create/update and every edge — no automatic rules will be applied.
"""


def _format_existing_knowledge(graph_dump: dict) -> str:
    """Format top graph knowledge concisely for LLM context."""
    return _format_nodes_for_llm(graph_dump.get("nodes", []))


def _format_nodes_for_llm(nodes: list[dict]) -> str:
    """Format a list of graph nodes concisely for LLM context."""
    filtered = [n for n in nodes if n.get("node_type") not in ("flag", "debug_learning")]
    if not filtered:
        return "No existing knowledge in graph yet."
    lines = ["Existing knowledge (node_id | type | content | confidence):"]
    for n in filtered[:30]:
        lines.append(
            f"  {n['node_id']} | {n['node_type']} | {n['content'][:100]} | {n['confidence']:.1f}"
        )
    return "\n".join(lines)


def _parse_llm_json(raw: str) -> dict | list:
    """Strip markdown fences and parse JSON from LLM response."""
    raw = raw.strip()
    fence_match = re.search(r"```(?:json)?\s*([\s\S]*?)\s*```", raw)
    if fence_match:
        raw = fence_match.group(1).strip()
    return json.loads(raw)


def _retrieve_relevant_context(graph: "KnowledgeGraph", query: str) -> str:
    """Retrieve relevant existing nodes from the graph for LLM context."""
    from kkanbu.retrieval import retrieve_context

    bundle = retrieve_context(graph, query, max_nodes=30)
    relevant_nodes = [rn.node for rn in bundle.nodes]
    return _format_nodes_for_llm(relevant_nodes)


def _llm_extract_learnings(
    input_text: str, category: str, graph: "KnowledgeGraph",
    images: list[dict] | None = None,
) -> dict:
    """Extract and integrate learnings in a single LLM call.

    Uses retrieve_context to find relevant existing nodes, giving the LLM
    proper framing (who the graph is about) and accurate upsert/connection context.

    Returns a dict with 'learnings', 'connections', and 'identity_summary'.
    """
    client = _get_anthropic_client()

    existing_knowledge = _retrieve_relevant_context(graph, input_text[:2000])

    prompt_text = (
        f"User shared:\n{input_text}\n\n"
        f"Category hint: {category}\n\n"
        f"{existing_knowledge}\n\n"
        "Extract deep, structured identity learnings. Output JSON only."
    )

    if images:
        content_blocks: list[dict] = [{"type": "text", "text": prompt_text}]
        for img in images[:10]:
            content_blocks.append({
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": img["media_type"],
                    "data": img["data"],
                },
            })
        user_content: str | list = content_blocks
    else:
        user_content = prompt_text

    response = client.messages.create(
        model=_OPUS_MODEL,
        max_tokens=2000,
        system=_TEACH_SYSTEM_PROMPT,
        messages=[{"role": "user", "content": user_content}],
    )

    return _parse_llm_json(response.content[0].text)


@mcp.tool()
def kkanbu_learn(
    insight: str,
    why: str = "",
    category: str = "preference",
    conversation_text: str = "",
    session_id: str = "",
    user: str = "",
) -> str:
    """Teach kkanbu about the user — extracts deep identity-level insights via Opus.

    Use this when the user explicitly shares a preference, value, or pattern.
    Provide ``insight`` for direct teaching, or ``conversation_text`` for passive
    extraction from raw conversation. You can provide both.

    Args:
        insight: A preference, value, or pattern to learn (e.g., "I prefer pytest").
        why: The reasoning behind this insight.
        category: Hint for node type — preference, value, pattern, or reasoning.
        conversation_text: Raw conversation text for passive extraction.
        session_id: For multi-turn tracking. Leave empty to start a new session.
        user: Username. If empty, uses the logged-in user.

    Returns JSON:
        {"session_id": str, "result": str, "insights_extracted": int,
         "turn": int, "is_new_session": bool}
    """
    llm_err = _require_llm("kkanbu_learn")
    if llm_err:
        return llm_err
    _distill_and_prune_stale_sessions(user)
    graph = get_graph(user)

    # ── Session lifecycle ─────────────────────────────────────────────────────
    session, is_new = _get_session_store(user).get_or_create(
        session_id or None,
        session_type="teach",
    )
    sid = session.session_id

    # Build full input and determine source
    input_parts: list[str] = []
    source = "teach"

    if insight:
        input_parts.append(insight)
        if why:
            input_parts.append(f"Reasoning: {why}")

    if conversation_text:
        input_parts.append(f"From conversation:\n{conversation_text}")
        if not insight:
            source = "passive"

    if not input_parts:
        return json.dumps({
            "session_id": sid,
            "result": "Nothing to learn from — provide an insight or conversation_text.",
            "insights_extracted": session.insights_extracted,
            "turn": session.turn_count,
            "is_new_session": is_new,
        })

    full_input = "\n\n".join(input_parts)

    # Record the user's input in the ephemeral session history
    session.append("user", full_input[:500])

    # Call Opus for two-step extraction + integration
    try:
        extracted = _llm_extract_learnings(full_input, category, graph)
    except Exception as exc:
        logger.error("LLM extraction failed: %s", exc)
        return json.dumps({
            "error": f"LLM extraction failed: {exc}",
            "session_id": sid,
            "insights_extracted": session.insights_extracted,
            "turn": session.turn_count,
            "is_new_session": is_new,
        })

    learnings = extracted.get("learnings", [])
    if not learnings:
        return json.dumps({
            "error": "LLM returned no learnings",
            "session_id": sid,
            "insights_extracted": session.insights_extracted,
            "turn": session.turn_count,
            "is_new_session": is_new,
        })

    # ── Autonomous node-writing pipeline ──────────────────────────────────
    # The LLM has full autonomy: it decides which nodes to create vs update
    # (via upsert_node_id) and which edges to add (via connections).
    # No hardcoded rules are applied after this point.

    graph_dump = graph.get_full_dump()
    existing_node_ids = {n["node_id"] for n in graph_dump.get("nodes", [])}
    node_ids: list[str] = []      # parallel to learnings list, holds resolved IDs
    created_count = 0
    updated_count = 0

    base_confidence = 0.9 if source == "teach" else 0.65

    for learning in learnings:
        confidence = float(learning.get("confidence", base_confidence))
        upsert_id = learning.get("upsert_node_id") or None

        nid, was_updated = graph.upsert_node(
            node_type=learning.get("node_type", category),
            content=learning["content"],
            source=source,
            node_id=upsert_id,
            why=learning.get("why") or None,
            confidence=confidence,
        )
        node_ids.append(nid)
        if was_updated:
            updated_count += 1
        else:
            created_count += 1

    # ── Apply LLM-specified connections (LLM decides ALL edges) ───────────
    for conn in extracted.get("connections", []):
        from_idx = conn.get("learning_index", 0)
        if not (0 <= from_idx < len(node_ids)):
            continue
        from_id = node_ids[from_idx]

        # Connection may target an existing graph node OR another new learning
        to_id: str = ""
        raw_to_node = conn.get("to_node_id") or ""
        raw_to_learning = conn.get("to_learning_index")

        if raw_to_node and raw_to_node in existing_node_ids:
            to_id = raw_to_node
        elif raw_to_learning is not None:
            try:
                to_idx = int(raw_to_learning)
                if 0 <= to_idx < len(node_ids) and to_idx != from_idx:
                    to_id = node_ids[to_idx]
            except (TypeError, ValueError):
                pass

        if not to_id:
            continue

        try:
            graph.add_edge(
                from_id,
                to_id,
                conn.get("relation_type", "supports"),
                weight=0.7,
                context=conn.get("context", "LLM-identified connection"),
            )
        except Exception:
            pass  # Edge creation may fail if node was deleted mid-session

    # ── Sub-AC 3c: Autonomous edge-inference second pass ──────────────────
    # After creating nodes + applying explicit connections, run a dedicated Opus
    # pass that autonomously infers typed edges between the new nodes and the
    # broader existing graph.  This second pass discovers connections the initial
    # extraction prompt may have missed — particularly cross-domain semantic links.
    inferred_edge_count = _infer_edges_for_new_nodes(
        graph=graph,
        new_node_ids=node_ids,
        pre_existing_ids=existing_node_ids,
    )

    # Build human-readable result text
    identity_summary = extracted.get("identity_summary", "")
    total = created_count + updated_count
    result = f"✓ Learned: {total} deep insights extracted"
    if created_count and updated_count:
        result += f" ({created_count} new, {updated_count} updated)"
    result += "\n"
    if identity_summary:
        result += f"\n📍 Identity: {identity_summary}\n"
    result += "\nLearnings stored:\n"
    for learning in learnings:
        marker = "◆" if learning.get("depth") == "identity" else "·"
        upsert_tag = " [updated]" if learning.get("upsert_node_id") else ""
        result += f"  {marker} [{learning.get('node_type', 'preference')}] {learning['content']}{upsert_tag}\n"
    if inferred_edge_count:
        result += f"\n🔗 {inferred_edge_count} semantic edge(s) inferred and written to graph\n"

    # Update session state with this turn's learning count
    session.insights_extracted += total
    session.append("assistant", result)

    return json.dumps({
        "session_id": sid,
        "result": result,
        "insights_extracted": session.insights_extracted,
        "turn": session.turn_count,
        "is_new_session": is_new,
    })


# ── AC3: kkanbu_ingest ────────────────────────────────────────

# Supported document extensions for file-based ingest
_DOCUMENT_EXTENSIONS = {".pdf", ".md", ".txt", ".docx"}


def _extract_document(path: Path) -> dict:
    """Extract text and images from a document file.

    Uses pymupdf4llm for PDFs (outputs clean markdown with structure preserved)
    and python-docx for DOCX files.

    Returns:
        {"text": str, "images": [{"data": base64_str, "media_type": str}],
         "page_count": int, "source_name": str}
    """
    import base64

    ext = path.suffix.lower()
    result = {"text": "", "images": [], "page_count": 1, "source_name": path.name}

    if ext in (".md", ".txt"):
        result["text"] = path.read_text(errors="ignore")

    elif ext == ".pdf":
        import fitz  # pymupdf (installed via pymupdf4llm)
        import pymupdf4llm

        # pymupdf4llm extracts structured markdown with headers, tables, lists
        result["text"] = pymupdf4llm.to_markdown(str(path))

        # Count pages and extract figures as images for multimodal Opus
        doc = fitz.open(str(path))
        result["page_count"] = len(doc)

        for page_num, page in enumerate(doc):
            image_list = page.get_images(full=True)
            drawings = page.get_drawings()
            if image_list or drawings:
                pix = page.get_pixmap(dpi=150)
                img_bytes = pix.tobytes("png")
                result["images"].append({
                    "data": base64.b64encode(img_bytes).decode("ascii"),
                    "media_type": "image/png",
                    "page": page_num + 1,
                })

        doc.close()

    elif ext == ".docx":
        from docx import Document as DocxDocument

        doc = DocxDocument(str(path))
        text_parts = []

        for para in doc.paragraphs:
            if para.text.strip():
                text_parts.append(para.text)

        # Extract table content
        for table in doc.tables:
            rows = []
            for row in table.rows:
                cells = [cell.text.strip() for cell in row.cells]
                rows.append(" | ".join(cells))
            if rows:
                text_parts.append("\n".join(rows))

        result["text"] = "\n\n".join(text_parts)

        # Extract embedded images
        for rel in doc.part.rels.values():
            if "image" in rel.reltype:
                try:
                    img_data = rel.target_part.blob
                    content_type = rel.target_part.content_type
                    result["images"].append({
                        "data": base64.b64encode(img_data).decode("ascii"),
                        "media_type": content_type,
                    })
                except Exception:
                    pass  # Skip unreadable images

    return result


def _llm_extract_from_document(doc: dict, graph: "KnowledgeGraph") -> dict:
    """Extract learnings from a document with multimodal content (text + images).

    Single-step: retrieves relevant context, then sends text + images + context
    to Opus for extraction + integration in one call.
    """
    client = _get_anthropic_client()

    text = doc["text"]
    if len(text) > 50_000:
        text = text[:50_000] + "\n\n... [truncated]"

    existing_knowledge = _retrieve_relevant_context(graph, text[:2000])

    content_blocks: list[dict] = [{
        "type": "text",
        "text": (
            f"Document: {doc['source_name']} ({doc['page_count']} pages)\n\n"
            f"{text}\n\n"
            f"{existing_knowledge}\n\n"
            "Extract deep, structured identity learnings from this document. "
            "Focus on what this reveals about the user's values, preferences, "
            "thinking patterns, and beliefs. Output JSON only."
        ),
    }]

    for img in doc["images"][:10]:
        content_blocks.append({
            "type": "image",
            "source": {
                "type": "base64",
                "media_type": img["media_type"],
                "data": img["data"],
            },
        })

    response = client.messages.create(
        model=_OPUS_MODEL,
        max_tokens=3000,
        system=_TEACH_SYSTEM_PROMPT,
        messages=[{"role": "user", "content": content_blocks}],
    )

    return _parse_llm_json(response.content[0].text)


@mcp.tool()
def kkanbu_ingest(path: str, user: str = "") -> str:
    """Ingest a codebase, document, or webpage to extract identity-level insights via Opus.

    Use this to learn about the user from their existing work. Accepts:
    - A URL (http/https) → auto-crawls child pages (up to 10), with JS rendering
      fallback for SPAs/Squarespace/React sites (requires playwright optional dep)
    - A directory path → codebase analysis (structure, configs, code patterns)
    - A file path → document analysis (.pdf, .md, .txt, .docx) with text + figures

    All paths go through Opus for deep identity extraction.

    Args:
        path: URL, absolute directory path, or absolute file path.
        user: Username. If empty, uses the logged-in user.

    Returns JSON on success:
        Success message with extracted insights and graph stats.
    On error:
        {"error": str}
    """
    llm_err = _require_llm("kkanbu_ingest")
    if llm_err:
        return llm_err
    graph = get_graph(user)

    try:
        # ── Route: URL, directory, or file ────────────────────────
        if path.startswith("http://") or path.startswith("https://"):
            return _ingest_webpage(graph, path)

        try:
            target = _validate_ingest_path(path)
        except ValueError as e:
            return json.dumps({"error": str(e)})

        if not target.exists():
            return json.dumps({"error": f"Path does not exist: {path}"})

        if target.is_dir():
            return _ingest_codebase(graph, target)
        elif target.is_file() and target.suffix.lower() in _DOCUMENT_EXTENSIONS:
            return _ingest_document(graph, target)
        else:
            supported = ", ".join(sorted(_DOCUMENT_EXTENSIONS))
            return json.dumps({
                "error": f"Unsupported file type: {target.suffix}. Supported: {supported}, a directory, or a URL.",
            })

    except Exception as e:
        error_msg = f"Ingest error for {path}: {e}"
        _self_debug("kkanbu_ingest", error_msg, traceback.format_exc())
        return json.dumps({"error": error_msg})


def _ingest_codebase(graph: KnowledgeGraph, path: Path) -> str:
    """Ingest a codebase directory — deterministic scan then Opus extraction."""
    findings = []
    findings.extend(_analyze_project_structure(path))
    findings.extend(_analyze_config_files(path))
    findings.extend(_analyze_code_patterns(path))

    if not findings:
        return json.dumps({"error": f"No recognizable patterns found in {path}"})

    findings_text = f"Repository: {path.name}\n\nRaw findings from codebase scan:\n"
    for f in findings:
        findings_text += f"- [{f['type']}] {f['content']}"
        if f.get("why"):
            findings_text += f" (why: {f['why']})"
        findings_text += "\n"

    try:
        extracted = _llm_extract_learnings(findings_text, "ingest", graph)
        learnings = extracted.get("learnings", [])
    except Exception as exc:
        logger.error("Ingest LLM extraction failed: %s", exc)
        return json.dumps({"error": f"LLM extraction failed: {exc}", "raw_findings": len(findings)})

    if not learnings:
        return json.dumps({"error": "LLM returned no insights.", "raw_findings": len(findings)})

    graph_dump = graph.get_full_dump()
    node_ids = _store_extracted_learnings(graph, extracted, graph_dump, source_name=path.name)

    identity_summary = extracted.get("identity_summary", "")
    result = f"✓ Ingested {path.name}: {len(findings)} raw findings → {len(learnings)} deep insights\n\n"
    for learning in learnings:
        result += f"  • [{learning.get('node_type', '?')}] {learning['content']}\n"
    if identity_summary:
        result += f"\n  Identity: {identity_summary}\n"

    stats = graph.get_stats()
    result += f"\nKnowledge graph: {stats['nodes']} nodes, {stats['edges']} edges"
    return result


_MIN_EXTRACT_CHARS = 100  # below this, trafilatura likely missed JS content
_MAX_CRAWL_PAGES = 10
_TRAFILATURA_OPTS = dict(
    include_tables=True, include_links=True,
    include_comments=False, output_format="txt",
)


def _trafilatura_extract(html: str) -> str | None:
    """Run trafilatura extraction; return text if above threshold, else None."""
    import trafilatura

    text = trafilatura.extract(html, **_TRAFILATURA_OPTS)
    if text and len(text.strip()) >= _MIN_EXTRACT_CHARS:
        return text
    return None


def _fetch_page_content(url: str, browser=None) -> dict | None:
    """Fetch and extract text (and images when playwright is available) from a URL.

    Returns {"text": str, "images": list[dict]} or None.
    When a playwright browser is available, always renders to capture images
    even if trafilatura already got text.
    """
    import trafilatura

    # When playwright is available, prefer it for both text and images
    if browser is not None:
        result = _render_and_extract(url, browser)
        if result and (result["text"] or result["images"]):
            # If playwright got no text, try trafilatura on raw HTML as supplement
            if not result["text"]:
                downloaded = trafilatura.fetch_url(url)
                if downloaded:
                    result["text"] = _trafilatura_extract(downloaded) or ""
            return result if (result["text"] or result["images"]) else None

    # No playwright — text-only via trafilatura
    downloaded = trafilatura.fetch_url(url)
    if downloaded:
        text = _trafilatura_extract(downloaded)
        if text:
            return {"text": text, "images": []}

    # Last resort: try launching a one-off playwright instance
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        return None

    try:
        with sync_playwright() as p:
            br = p.chromium.launch(headless=True)
            try:
                return _render_and_extract(url, br)
            finally:
                br.close()
    except Exception as exc:
        logger.warning("Playwright fallback failed for %s: %s", url, exc)

    return None


_MAX_PAGE_IMAGES = 8
_MIN_IMG_DIMENSION = 80  # skip icons/spacers smaller than this
_MAX_IMG_BYTES = 1_500_000  # skip images larger than ~1.5MB (API limits)


def _download_image(url: str, page) -> dict | None:
    """Download an image by URL using the page's network context. Returns base64 dict."""
    import base64

    try:
        resp = page.request.get(url)
        if resp.status != 200:
            return None
        body = resp.body()
        if not body or len(body) > _MAX_IMG_BYTES:
            return None

        content_type = resp.headers.get("content-type", "")
        if "image/" not in content_type:
            return None

        media_type = content_type.split(";")[0].strip()
        return {
            "data": base64.b64encode(body).decode("ascii"),
            "media_type": media_type,
        }
    except Exception:
        return None


def _render_and_extract(url: str, browser) -> dict | None:
    """Render a page with playwright, extract text and download original images."""
    import base64
    from urllib.parse import urljoin

    try:
        page = browser.new_page()
        try:
            page.goto(url, wait_until="networkidle", timeout=15_000)
            html = page.content()

            images: list[dict] = []
            seen_srcs: set[str] = set()
            img_elements = page.query_selector_all("img")

            for img in img_elements[:_MAX_PAGE_IMAGES * 3]:
                try:
                    bbox = img.bounding_box()
                    if not bbox or bbox["width"] < _MIN_IMG_DIMENSION or bbox["height"] < _MIN_IMG_DIMENSION:
                        continue

                    # Prefer data-src (lazy-loaded original) over src (resized)
                    src = img.get_attribute("data-src") or img.get_attribute("src") or ""
                    if not src or src.startswith("data:"):
                        continue
                    abs_src = urljoin(url, src)
                    # Squarespace appends ?format=NNNw for resized thumbnails
                    if "squarespace" in abs_src and "?" in abs_src:
                        abs_src = abs_src.split("?")[0]
                    if abs_src in seen_srcs:
                        continue
                    seen_srcs.add(abs_src)

                    downloaded = _download_image(abs_src, page)
                    if downloaded:
                        images.append(downloaded)
                        if len(images) >= _MAX_PAGE_IMAGES:
                            break
                except Exception as exc:
                    logger.debug("Image extraction failed for element on %s: %s", url, exc)
                    continue

            # Fallback: full-page screenshot if few/no images downloaded
            if len(images) < 2:
                try:
                    screenshot = page.screenshot(type="jpeg", quality=60, full_page=True)
                    if len(screenshot) <= _MAX_IMG_BYTES:
                        images.insert(0, {
                            "data": base64.b64encode(screenshot).decode("ascii"),
                            "media_type": "image/jpeg",
                        })
                except Exception:
                    pass
        finally:
            page.close()

        text = _trafilatura_extract(html)
        if not text and not images:
            return None
        return {"text": text or "", "images": images}
    except Exception as exc:
        logger.warning("Playwright render failed for %s: %s", url, exc)
        return None


def _ingest_webpage(graph: KnowledgeGraph, url: str) -> str:
    """Ingest a webpage and its child pages — crawl, extract, then Opus extraction."""
    from urllib.parse import urlparse
    from trafilatura.spider import focused_crawler

    # ── Phase 1: discover child pages ────────────────────────────────
    try:
        child_urls, _ = focused_crawler(url, max_seen_urls=_MAX_CRAWL_PAGES, max_known_urls=50)
    except Exception as exc:
        logger.warning("Spider crawl failed for %s: %s", url, exc)
        child_urls = []

    pages = [url] + [c for c in child_urls if c != url][:_MAX_CRAWL_PAGES - 1]

    # ── Phase 2: fetch + extract each page through Opus ──────────────
    domain = urlparse(url).netloc
    all_learnings: list[dict] = []
    pages_ok = 0
    identity_summary = ""

    # Try to reuse a single playwright browser for all JS-rendered pages
    pw_browser = None
    try:
        from playwright.sync_api import sync_playwright
        pw_ctx = sync_playwright().start()
        pw_browser = pw_ctx.chromium.launch(headless=True)
    except Exception:
        pw_ctx = None

    try:
        for i, page_url in enumerate(pages):
            if i > 0:
                time.sleep(1)

            page_content = _fetch_page_content(page_url, browser=pw_browser)
            if not page_content or (not page_content["text"] and not page_content["images"]):
                logger.debug("No content from %s, skipping", page_url)
                continue

            input_text = f"Webpage: {page_url}\n\n{page_content['text']}"

            try:
                extracted = _llm_extract_learnings(
                    input_text, "ingest", graph, images=page_content.get("images"),
                )
                learnings = extracted.get("learnings", [])
            except Exception as exc:
                logger.error("LLM extraction failed for %s: %s", page_url, exc)
                continue

            if not learnings:
                continue

            graph_dump = graph.get_full_dump()
            _store_extracted_learnings(graph, extracted, graph_dump, source_name=domain)
            all_learnings.extend(learnings)
            pages_ok += 1

            identity_summary = identity_summary or extracted.get("identity_summary", "")
    finally:
        if pw_browser:
            pw_browser.close()
        if pw_ctx:
            pw_ctx.stop()

    # ── Phase 3: build result ────────────────────────────────────────
    if not all_learnings:
        return json.dumps({"error": f"No insights extracted from {url} ({len(pages)} pages crawled)"})

    result = f"✓ Ingested {url}: {pages_ok} page(s) crawled → {len(all_learnings)} deep insights\n\n"
    for learning in all_learnings:
        result += f"  • [{learning.get('node_type', '?')}] {learning['content']}\n"
    if identity_summary:
        result += f"\n  Identity: {identity_summary}\n"

    stats = graph.get_stats()
    result += f"\nKnowledge graph: {stats['nodes']} nodes, {stats['edges']} edges"
    return result


def _ingest_document(graph: KnowledgeGraph, path: Path) -> str:
    """Ingest a document file — extract text + figures, then Opus extraction."""
    doc = _extract_document(path)

    if not doc["text"].strip():
        return json.dumps({"error": f"No text content extracted from {path.name}"})

    try:
        extracted = _llm_extract_from_document(doc, graph)
        learnings = extracted.get("learnings", [])
    except Exception as exc:
        logger.error("Document LLM extraction failed: %s", exc)
        return json.dumps({"error": f"LLM extraction failed: {exc}", "source": path.name})

    if not learnings:
        return json.dumps({"error": "LLM returned no insights.", "source": path.name})

    graph_dump = graph.get_full_dump()
    node_ids = _store_extracted_learnings(graph, extracted, graph_dump, source_name=path.name)

    identity_summary = extracted.get("identity_summary", "")
    img_note = f", {len(doc['images'])} figures" if doc["images"] else ""
    result = (
        f"✓ Ingested {path.name}: {doc['page_count']} pages{img_note} "
        f"→ {len(learnings)} deep insights\n\n"
    )
    for learning in learnings:
        result += f"  • [{learning.get('node_type', '?')}] {learning['content']}\n"
    if identity_summary:
        result += f"\n  Identity: {identity_summary}\n"

    stats = graph.get_stats()
    result += f"\nKnowledge graph: {stats['nodes']} nodes, {stats['edges']} edges"
    return result


def _store_extracted_learnings(
    graph: KnowledgeGraph, extracted: dict, graph_dump: dict, source_name: str,
) -> list[str]:
    """Store LLM-extracted learnings and edges into the graph. Returns node IDs."""
    learnings = extracted.get("learnings", [])
    existing_node_ids = {n["node_id"] for n in graph_dump.get("nodes", [])}
    node_ids: list[str] = []

    for learning in learnings:
        upsert_id = learning.get("upsert_node_id")
        if upsert_id and upsert_id in existing_node_ids:
            graph.update_node(
                upsert_id,
                content=learning["content"],
                why=learning.get("why"),
                confidence=max(
                    learning.get("confidence", 0.7),
                    graph.get_node(upsert_id).get("confidence", 0) if graph.get_node(upsert_id) else 0,
                ),
            )
            node_ids.append(upsert_id)
        else:
            nid = graph.add_node(
                node_type=learning.get("node_type", "observation"),
                content=learning["content"],
                source="ingest",
                why=learning.get("why"),
                confidence=learning.get("confidence", 0.7),
                metadata={"source_file": source_name},
            )
            node_ids.append(nid)

    # Write edges from LLM connections
    for conn in extracted.get("connections", []):
        from_idx = conn.get("learning_index", 0)
        to_node_id = conn.get("to_node_id")
        to_idx = conn.get("to_learning_index")

        from_id = node_ids[from_idx] if from_idx < len(node_ids) else None
        to_id = None
        if to_node_id and to_node_id in existing_node_ids:
            to_id = to_node_id
        elif to_idx is not None and int(to_idx) < len(node_ids):
            to_id = node_ids[int(to_idx)]

        if from_id and to_id and from_id != to_id:
            graph.add_edge(
                from_id, to_id,
                conn.get("relation_type", "supports"),
                weight=0.6,
                context=conn.get("context", f"Ingest: {source_name}"),
            )

    return node_ids


# ── AC4: kkanbu_flag_question ─────────────────────────────────

def _flag_question(question: str, best_guess: str, confidence: float) -> str:
    """Flag an uncertain answer for post-run user review (internal).

    Called by kkanbu_answer when confidence is low. Records the question
    and best guess for the user to review later via kkanbu_get_flags.
    """
    graph = get_graph()

    graph.add_node(
        node_type="flag",
        content=question,
        source="flag",
        confidence=confidence,
        metadata={
            "flag_type": "answer_uncertainty",
            "best_guess": best_guess,
            "confidence_at_flag": confidence,
            "resolved": False,
        },
    )

    return (
        f"⚑ Flagged for review (confidence: {confidence:.2f})\n"
        f"  Question: {question}\n"
        f"  Best guess: {best_guess[:200]}..."
        if len(best_guess) > 200
        else f"⚑ Flagged for review (confidence: {confidence:.2f})\n"
        f"  Question: {question}\n"
        f"  Best guess: {best_guess}"
    )


# ── AC5: kkanbu_get_flags ────────────────────────────────────

@mcp.tool()
def kkanbu_get_flags(user: str = "") -> str:
    """Show all unresolved flagged items for review.

    Use this to see questions where kkanbu was uncertain (from kkanbu_answer)
    or contradictions/tensions found (from kkanbu_reflect). Does not require LLM.

    Args:
        user: Username. If empty, uses the logged-in user.

    Returns: Formatted text listing flags with best guesses and confidence scores.
    """
    graph = get_graph(user)
    flags = graph.get_unresolved_flags()

    if not flags:
        return "No flagged items — kkanbu was confident in all answers."

    result = f"⚑ {len(flags)} flagged items for review:\n\n"
    for i, flag in enumerate(flags, 1):
        meta = json.loads(flag["metadata"]) if flag.get("metadata") else {}
        result += f"{i}. **{flag['content']}**\n"
        result += f"   Best guess: {meta.get('best_guess', 'N/A')}\n"
        result += f"   Confidence: {flag['confidence']:.2f}\n"
        result += f"   Flagged: {flag['created_at']}\n\n"

    result += "Use kkanbu_resolve_flag() to review these with the user, or kkanbu_learn() to provide corrections."
    return result


# ── AC6: kkanbu_resolve_flag ─────────────────────────────────

_RESOLVE_FLAG_SYSTEM_PROMPT = """\
You are kkanbu — the user's deeply trusted partner. You're reviewing flagged \
questions where you were uncertain about your answers. Your job is to present \
these flags to the user in a natural, conversational way.

Given a set of flags, you will:
1. Group related flags by theme (e.g., "testing philosophy", "UX preferences", \
   "architecture decisions") — flags that share context should be discussed together.
2. Order groups so that earlier answers provide context for later ones.
3. For each group, write a single conversational question that covers the group's \
   flags naturally — weaving them together rather than listing them mechanically.

FLAGS HAVE TWO TYPES — adapt your question style:
- "answer_uncertainty": You guessed an answer but weren't confident. \
  Frame as: "I guessed X — is that right? What would you actually say?"
- "reflection": You noticed a contradiction, tension, or interesting pattern \
  in the knowledge graph. Frame as: "I noticed X and Y seem to pull in \
  different directions — how do you think about that?"
You can mix both types in a group if they're thematically related.

OUTPUT — respond with JSON only (no markdown fences):
{
  "groups": [
    {
      "theme": "short label for this group",
      "flag_node_ids": ["id1", "id2"],
      "question": "A natural, conversational question that covers these flags. \
Adapt tone based on flag_type. Mention what connects these flags.",
      "best_guesses_summary": "Brief summary of your guesses for context"
    }
  ]
}

Keep questions warm and conversational — you're a trusted friend checking in, \
not a survey bot. If a flag is standalone with no natural grouping, it gets its own group.
"""


def _plan_flag_groups(flags: list[dict]) -> list[dict]:
    """Use Opus to group related flags into conversational clusters.

    Falls back to one-flag-per-group if the LLM call fails.
    """
    if len(flags) <= 1:
        # Single flag — no grouping needed
        flag = flags[0]
        meta = json.loads(flag["metadata"]) if flag.get("metadata") else {}
        return [{
            "theme": "single flag",
            "flag_node_ids": [flag["node_id"]],
            "question": (
                f"I wasn't sure about something earlier and wanted to check with you. "
                f"I was asked: '{flag['content']}'\n\n"
                f"My best guess was: '{meta.get('best_guess', 'N/A')}' "
                f"(confidence: {flag['confidence']:.0%})\n\n"
                f"What would you actually say? And more importantly — why?"
            ),
            "best_guesses_summary": meta.get("best_guess", "N/A")[:200],
        }]

    # Build flag descriptions for the LLM
    flag_descriptions = []
    for f in flags:
        meta = json.loads(f["metadata"]) if f.get("metadata") else {}
        best_guess = meta.get("best_guess", "N/A")
        # Truncate very long guesses for the prompt
        if len(best_guess) > 500:
            best_guess = best_guess[:500] + "..."
        flag_descriptions.append({
            "node_id": f["node_id"],
            "flag_type": meta.get("flag_type", "answer_uncertainty"),
            "question": f["content"][:300],
            "best_guess": best_guess,
            "confidence": f["confidence"],
        })

    try:
        client = _get_anthropic_client()
        response = client.messages.create(
            model=_OPUS_MODEL,
            max_tokens=2000,
            system=_RESOLVE_FLAG_SYSTEM_PROMPT,
            messages=[{
                "role": "user",
                "content": (
                    f"Here are {len(flags)} flagged items to group:\n\n"
                    f"{json.dumps(flag_descriptions, indent=2)}\n\n"
                    "Group them by theme and write a natural question for each group."
                ),
            }],
        )

        raw = response.content[0].text.strip()
        fence_match = re.search(r"```(?:json)?\s*([\s\S]*?)\s*```", raw)
        if fence_match:
            raw = fence_match.group(1).strip()

        result = json.loads(raw)
        groups = result.get("groups", [])
        if groups:
            return groups
    except Exception as exc:
        logger.warning("Flag grouping LLM call failed, presenting flags individually (structural fallback): %s", exc)

    # Fallback: one flag per group
    groups = []
    for f in flags:
        meta = json.loads(f["metadata"]) if f.get("metadata") else {}
        groups.append({
            "theme": "ungrouped",
            "flag_node_ids": [f["node_id"]],
            "question": (
                f"I was asked: '{f['content'][:200]}'\n\n"
                f"My guess: '{meta.get('best_guess', 'N/A')[:200]}' "
                f"(confidence: {f['confidence']:.0%})\n\n"
                f"What would you say?"
            ),
            "best_guesses_summary": meta.get("best_guess", "N/A")[:200],
        })
    return groups


@mcp.tool()
def kkanbu_resolve_flag(user_response: str = "", session_id: str = "", user: str = "") -> str:
    """Review and resolve flagged items through grouped Socratic conversation.

    Use this AFTER kkanbu_get_flags shows unresolved items. On the first call,
    Opus groups related flags by theme and presents the first group. Subsequent
    calls move through remaining groups. Unlike kkanbu_curious, this is reactive
    — it resolves existing uncertainty rather than exploring new territory.

    Args:
        user_response: User's response (empty to start a new session).
        session_id: For multi-turn. Leave empty to start; reuse to continue.
        user: Username. If empty, uses the logged-in user.

    Returns JSON:
        {"session_id": str, "type": "question"|"follow_up"|"done",
         "message": str, "remaining_groups": int}
    """
    llm_err = _require_llm("kkanbu_resolve_flag")
    if llm_err:
        return llm_err
    _distill_and_prune_stale_sessions(user)
    graph = get_graph(user)

    # ── Session lifecycle ─────────────────────────────────────────────────────
    session, is_new = _get_session_store(user).get_or_create(
        session_id or None,
        session_type="conversation",
    )
    sid = session.session_id

    if not user_response:
        # Start new session — gather and group flags
        flags = graph.get_unresolved_flags()

        if not flags:
            return json.dumps({
                "session_id": sid,
                "type": "done",
                "message": "No flagged items right now — kkanbu was confident in all answers.",
                "remaining_flags": 0,
                "remaining_groups": 0,
                "is_new_session": is_new,
            })

        # Use Opus to group related flags
        groups = _plan_flag_groups(flags)

        # Store the group plan in the session for sequential access
        session.flag_groups = groups
        session.current_group_index = 0

        # Present first group
        group = groups[0]
        session.flag_id = group["flag_node_ids"][0]
        message = group["question"]
        session.append("assistant", message)

        return json.dumps({
            "session_id": sid,
            "type": "question",
            "message": message,
            "group_theme": group.get("theme", ""),
            "flag_node_ids": group["flag_node_ids"],
            "remaining_groups": len(groups) - 1,
            "total_flags": len(flags),
            "is_new_session": is_new,
        })

    else:
        # Record user's response in ephemeral session history
        session.append("user", user_response)

        # Resolve all flags in the current group
        current_idx = getattr(session, "current_group_index", 0)
        groups = getattr(session, "flag_groups", [])

        if current_idx < len(groups):
            current_group = groups[current_idx]
            for fid in current_group.get("flag_node_ids", []):
                _resolve_flags_from_conversation(graph, user_response, flag_id=fid)

        # Advance to next group
        next_idx = current_idx + 1
        session.current_group_index = next_idx

        if next_idx < len(groups):
            next_group = groups[next_idx]
            session.flag_id = next_group["flag_node_ids"][0]
            follow_up = (
                f"Got it, thanks! Moving on — {next_group.get('theme', 'next topic')}:\n\n"
                f"{next_group['question']}"
            )
        else:
            remaining = graph.get_unresolved_flags()
            if remaining:
                follow_up = (
                    f"Thanks! We've gone through all the grouped flags. "
                    f"There are still {len(remaining)} unresolved — "
                    f"call kkanbu_resolve_flag() again to start a new session."
                )
            else:
                follow_up = (
                    "Thanks! All flags resolved. "
                    "Learnings will be extracted when this session is distilled."
                )

        session.append("assistant", follow_up)

        remaining_groups = max(0, len(groups) - next_idx)
        return json.dumps({
            "session_id": sid,
            "type": "follow_up" if remaining_groups > 0 else "done",
            "message": follow_up,
            "remaining_groups": remaining_groups,
            "is_new_session": False,
        })


# ── AC9: Ouroboros Orchestration ──────────────────────────────



# ── AC11: Corrections ────────────────────────────────────────

@mcp.tool()
def kkanbu_correct(original: str, correction: str, why: str = "", user: str = "") -> str:
    """Correct a previous kkanbu answer or stored preference.

    Use this when kkanbu got something wrong. Lowers confidence of the original
    nodes and stores the correction. Does not require LLM.

    Args:
        original: The original answer or preference that was wrong.
        correction: What the correct answer should be.
        why: Why this correction matters.
        user: Username. If empty, uses the logged-in user.

    Returns: Confirmation text with correction details.
    """
    graph = get_graph(user)

    # Find the original node(s)
    original_nodes = graph.search_nodes(original, limit=5)

    # Create correction node
    correction_node_id = graph.add_node(
        node_type="correction",
        content=correction,
        source="correction",
        why=why or None,
        confidence=0.95,  # User corrections are very high confidence
    )

    corrected_count = 0
    for orig_node in original_nodes:
        # Lower confidence of original
        graph.update_node(orig_node["node_id"],
                         confidence=max(0.1, orig_node["confidence"] - 0.3))

        # Link correction to original
        graph.add_edge(
            correction_node_id, orig_node["node_id"], "corrects", weight=0.9,
            context=f"User correction: {why}" if why else "User correction",
        )
        corrected_count += 1

    # Also store as a preference if it seems like one
    pref_node_id = graph.add_node(
        node_type="preference",
        content=correction,
        source="correction",
        why=why or None,
        confidence=0.9,
    )
    graph.add_edge(correction_node_id, pref_node_id, "derives_from", weight=0.8)

    result = "✓ Correction recorded\n"
    result += f"  Original: '{original}'\n"
    result += f"  Corrected to: '{correction}'\n"
    if why:
        result += f"  Why: '{why}'\n"
    result += f"  Updated {corrected_count} existing nodes"
    return result


# ── Knowledge Graph Introspection ─────────────────────────────

@mcp.tool()
def kkanbu_status(user: str = "") -> str:
    """Show knowledge graph statistics — node/edge counts by type, database path.

    Use this for a quick health check of the knowledge graph. Does not require LLM.

    Args:
        user: Username. If empty, uses the logged-in user.

    Returns: Formatted text with node/edge counts and type breakdown.
    """
    graph = get_graph(user)
    stats = graph.get_stats()

    result = "📊 Kkanbu Knowledge Graph Status\n\n"
    result += f"**Total nodes:** {stats['nodes']}\n"
    result += f"**Total edges:** {stats['edges']}\n\n"

    if stats["by_type"]:
        result += "**By type:**\n"
        for ntype, count in sorted(stats["by_type"].items()):
            result += f"  • {ntype}: {count}\n"

    result += f"\n**Database:** {get_graph(user).db_path}"
    return result


@mcp.tool()
def kkanbu_visualize(port: int = 7742, user: str = "") -> str:
    """Launch an interactive D3.js graph visualization backed by a live HTTP API.

    Use this to visually explore the knowledge graph in a browser. Starts a
    local server (default port 7742) with live API endpoints. Click nodes to
    see details. Refresh to see latest data. Does not require LLM.

    API endpoints:
        GET /           — interactive force-directed graph UI
        GET /api/graph  — full graph JSON dump
        GET /api/node/<id> — single node with connections

    Args:
        port: HTTP port (default 7742).
        user: Username. If empty, uses the logged-in user.

    Returns JSON:
        {"status": "ok"|"already_running", "url": str, "nodes": int, "edges": int}
    """
    import socket
    import subprocess
    import threading
    from functools import partial
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from urllib.parse import urlparse

    # Check if server is already running on this port
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.5)
            s.connect(("127.0.0.1", port))
        # Port is already in use — just open browser
        try:
            subprocess.Popen(["open", f"http://localhost:{port}"])
        except FileNotFoundError:
            try:
                subprocess.Popen(["xdg-open", f"http://localhost:{port}"])
            except FileNotFoundError:
                pass
        return json.dumps({
            "status": "already_running",
            "url": f"http://localhost:{port}",
            "message": f"Visualization server already running at http://localhost:{port}",
        })
    except (ConnectionRefusedError, OSError):
        pass  # Port is free — start the server

    # Capture the DB path from the main-thread graph so the HTTP thread
    # can open its own SQLite connection (avoids check_same_thread errors).
    _vis_db_path = get_graph(user).db_path

    class VisHandler(BaseHTTPRequestHandler):
        def __init__(self, db_path, *args, **kwargs):
            self._db_path = db_path
            super().__init__(*args, **kwargs)

        def _open_graph(self):
            """Open a thread-local KnowledgeGraph for this request."""
            return KnowledgeGraph(db_path=self._db_path)

        def log_message(self, format, *args):
            logger.debug(f"kkanbu-vis: {format % args}")

        def _cors_headers(self):
            self.send_header("Access-Control-Allow-Origin", "http://127.0.0.1:7742")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("X-Frame-Options", "DENY")
            self.send_header("Cache-Control", "no-cache")

        def _json_response(self, data, status=200):
            body = json.dumps(data).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self._cors_headers()
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _html_response(self, html):
            body = html.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self._cors_headers()
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            parsed = urlparse(self.path)
            path = parsed.path.rstrip("/") or "/"

            if path == "/api/graph":
                graph = self._open_graph()
                self._json_response(graph.get_full_dump())

            elif path.startswith("/api/node/"):
                node_id = path[len("/api/node/"):]
                graph = self._open_graph()
                node = graph.get_node(node_id)
                if not node:
                    self._json_response({"error": "Node not found"}, 404)
                    return
                edges_out = graph.get_edges_from(node_id)
                edges_in = graph.get_edges_to(node_id)
                connections = []
                for e in edges_out:
                    target = graph.get_node(e["to_node"])
                    connections.append({
                        "direction": "out",
                        "relation": e["relation_type"],
                        "node": target,
                        "context": e.get("context"),
                    })
                for e in edges_in:
                    source = graph.get_node(e["from_node"])
                    connections.append({
                        "direction": "in",
                        "relation": e["relation_type"],
                        "node": source,
                        "context": e.get("context"),
                    })
                self._json_response({"node": node, "connections": connections})

            elif path == "/":
                self._html_response(_VIS_HTML)

            else:
                self.send_error(404)

    handler = partial(VisHandler, _vis_db_path)
    httpd = HTTPServer(("127.0.0.1", port), handler)
    httpd.daemon_threads = True

    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    logger.info(f"kkanbu visualization server started on http://localhost:{port}")

    # Open browser
    try:
        subprocess.Popen(["open", f"http://localhost:{port}"])
    except FileNotFoundError:
        try:
            subprocess.Popen(["xdg-open", f"http://localhost:{port}"])
        except FileNotFoundError:
            pass

    stats = get_graph(user).get_stats()
    return json.dumps({
        "status": "ok",
        "url": f"http://localhost:{port}",
        "nodes": stats["nodes"],
        "edges": stats["edges"],
        "message": f"Visualization server started at http://localhost:{port} — {stats['nodes']} nodes, {stats['edges']} edges. Refresh to see live updates.",
    })


# ── Visualization HTML (fetches from API) ────────────────────

_VIS_HTML = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Kkanbu Knowledge Graph</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { background: #0d1117; color: #c9d1d9; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Helvetica, Arial, sans-serif; overflow: hidden; }
  #graph { width: 100vw; height: 100vh; }
  svg { display: block; }
  #loading {
    position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);
    font-size: 16px; color: #8b949e;
  }
  #legend {
    position: fixed; top: 16px; left: 16px; background: #161b22; border: 1px solid #30363d;
    border-radius: 8px; padding: 12px 16px; font-size: 13px; z-index: 10;
  }
  #legend h3 { margin-bottom: 8px; color: #f0f6fc; font-size: 14px; }
  .legend-item { display: flex; align-items: center; gap: 8px; margin: 4px 0; }
  .legend-dot { width: 12px; height: 12px; border-radius: 50%; }
  #stats {
    position: fixed; top: 16px; right: 16px; background: #161b22; border: 1px solid #30363d;
    border-radius: 8px; padding: 12px 16px; font-size: 13px; z-index: 10;
  }
  #stats h3 { margin-bottom: 8px; color: #f0f6fc; font-size: 14px; }
  .refresh-btn {
    margin-top: 8px; padding: 4px 10px; background: #21262d; border: 1px solid #30363d;
    border-radius: 4px; color: #c9d1d9; cursor: pointer; font-size: 12px;
  }
  .refresh-btn:hover { background: #30363d; }
  #detail {
    position: fixed; bottom: 0; left: 0; right: 0; max-height: 40vh; overflow-y: auto;
    background: #161b22; border-top: 1px solid #30363d; padding: 20px 24px;
    transform: translateY(100%); transition: transform 0.25s ease; z-index: 20;
  }
  #detail.open { transform: translateY(0); }
  #detail h2 { font-size: 16px; color: #f0f6fc; margin-bottom: 8px; }
  #detail .meta { font-size: 13px; color: #8b949e; margin-bottom: 4px; }
  #detail .content { font-size: 14px; margin: 12px 0; line-height: 1.5; }
  #detail .why { font-size: 13px; color: #a5d6ff; font-style: italic; }
  #detail .connections { font-size: 13px; margin-top: 12px; }
  #detail .connections li { margin: 2px 0; }
  #detail .close-btn {
    position: absolute; top: 12px; right: 16px; background: none; border: none;
    color: #8b949e; font-size: 20px; cursor: pointer;
  }
  #detail .close-btn:hover { color: #f0f6fc; }
  .tooltip {
    position: absolute; background: #1c2128; border: 1px solid #30363d; border-radius: 6px;
    padding: 6px 10px; font-size: 12px; pointer-events: none; white-space: nowrap; z-index: 30;
  }
</style>
</head>
<body>
<div id="loading">Loading knowledge graph...</div>
<div id="graph"></div>

<div id="legend">
  <h3>Node Types</h3>
</div>

<div id="stats">
  <h3>Knowledge Graph</h3>
  <div id="stats-content"></div>
  <button class="refresh-btn" onclick="loadGraph()">Refresh</button>
</div>

<div id="detail">
  <button class="close-btn" onclick="document.getElementById('detail').classList.remove('open')">&times;</button>
  <div id="detail-content"></div>
</div>

<script src="https://d3js.org/d3.v7.min.js"></script>
<script>
const TYPE_COLORS = {
  preference: '#f97583',
  value: '#79c0ff',
  pattern: '#56d364',
  reasoning: '#d2a8ff',
  observation: '#e3b341',
  flag: '#f85149',
  correction: '#ffa657',
  debug_learning: '#8b949e',
};

let simulation, svg, g, tooltip;
let currentNodes = [], currentLinks = [];

function initSvg() {
  const width = window.innerWidth;
  const height = window.innerHeight;

  d3.select('#graph svg').remove();
  svg = d3.select('#graph')
    .append('svg')
    .attr('width', width)
    .attr('height', height);

  g = svg.append('g');
  svg.call(d3.zoom().scaleExtent([0.1, 8]).on('zoom', (e) => g.attr('transform', e.transform)));

  svg.append('defs').selectAll('marker')
    .data(['arrow'])
    .join('marker')
    .attr('id', 'arrow')
    .attr('viewBox', '0 -5 10 10')
    .attr('refX', 20).attr('refY', 0)
    .attr('markerWidth', 6).attr('markerHeight', 6)
    .attr('orient', 'auto')
    .append('path').attr('fill', '#30363d').attr('d', 'M0,-5L10,0L0,5');

  if (!tooltip) {
    tooltip = d3.select('body').append('div').attr('class', 'tooltip').style('display', 'none');
  }

  // Close detail on background click
  svg.on('click', (e) => {
    if (e.target.tagName === 'svg') document.getElementById('detail').classList.remove('open');
  });
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

function nodeRadius(d) { return 6 + d.confidence * 10; }

function renderGraph(rawNodes, rawEdges, stats) {
  document.getElementById('loading').style.display = 'none';
  const width = window.innerWidth;
  const height = window.innerHeight;

  // Stats
  document.getElementById('stats-content').innerHTML =
    `<div>Nodes: ${stats.nodes}</div><div>Edges: ${stats.edges}</div>`;

  // Legend
  const legend = document.getElementById('legend');
  legend.querySelectorAll('.legend-item').forEach(el => el.remove());
  Object.entries(TYPE_COLORS).forEach(([type, color]) => {
    const count = rawNodes.filter(n => n.node_type === type).length;
    if (count === 0) return;
    const item = document.createElement('div');
    item.className = 'legend-item';
    item.innerHTML = `<span class="legend-dot" style="background:${color}"></span>${type} (${count})`;
    legend.appendChild(item);
  });

  // Build data
  const nodeMap = new Map(rawNodes.map(n => [n.node_id, n]));
  const nodes = rawNodes.map(n => ({
    id: n.node_id,
    label: n.content.length > 50 ? n.content.slice(0, 47) + '...' : n.content,
    type: n.node_type,
    confidence: n.confidence,
    data: n,
  }));

  const links = rawEdges
    .filter(e => nodeMap.has(e.from_node) && nodeMap.has(e.to_node))
    .map(e => ({
      source: e.from_node, target: e.to_node,
      relation: e.relation_type, weight: e.weight, context: e.context,
    }));

  initSvg();

  if (simulation) simulation.stop();
  simulation = d3.forceSimulation(nodes)
    .force('link', d3.forceLink(links).id(d => d.id).distance(80))
    .force('charge', d3.forceManyBody().strength(-200))
    .force('center', d3.forceCenter(width / 2, height / 2))
    .force('collision', d3.forceCollide().radius(d => nodeRadius(d) + 4));

  const link = g.append('g').selectAll('line').data(links).join('line')
    .attr('stroke', '#30363d')
    .attr('stroke-width', d => 0.5 + d.weight * 2)
    .attr('marker-end', 'url(#arrow)')
    .on('mouseover', (e, d) => { tooltip.style('display', 'block').html(`${d.relation}${d.context ? ' — ' + d.context : ''}`); })
    .on('mousemove', (e) => { tooltip.style('left', (e.pageX + 10) + 'px').style('top', (e.pageY - 20) + 'px'); })
    .on('mouseout', () => tooltip.style('display', 'none'));

  const node = g.append('g').selectAll('circle').data(nodes).join('circle')
    .attr('r', nodeRadius)
    .attr('fill', d => TYPE_COLORS[d.type] || '#8b949e')
    .attr('stroke', '#0d1117').attr('stroke-width', 1.5)
    .style('cursor', 'pointer')
    .on('click', (e, d) => fetchNodeDetail(d.id))
    .on('mouseover', (e, d) => {
      tooltip.style('display', 'block').text(d.label);
      d3.select(e.target).attr('stroke', '#f0f6fc').attr('stroke-width', 2.5);
    })
    .on('mousemove', (e) => { tooltip.style('left', (e.pageX + 10) + 'px').style('top', (e.pageY - 20) + 'px'); })
    .on('mouseout', (e) => {
      tooltip.style('display', 'none');
      d3.select(e.target).attr('stroke', '#0d1117').attr('stroke-width', 1.5);
    })
    .call(d3.drag()
      .on('start', (e, d) => { if (!e.active) simulation.alphaTarget(0.3).restart(); d.fx = d.x; d.fy = d.y; })
      .on('drag', (e, d) => { d.fx = e.x; d.fy = e.y; })
      .on('end', (e, d) => { if (!e.active) simulation.alphaTarget(0); d.fx = null; d.fy = null; })
    );

  const labels = g.append('g').selectAll('text')
    .data(nodes.filter(d => d.confidence >= 0.7)).join('text')
    .text(d => d.label).attr('font-size', 10).attr('fill', '#8b949e')
    .attr('dx', d => nodeRadius(d) + 4).attr('dy', 3)
    .style('pointer-events', 'none');

  simulation.on('tick', () => {
    link.attr('x1', d => d.source.x).attr('y1', d => d.source.y)
        .attr('x2', d => d.target.x).attr('y2', d => d.target.y);
    node.attr('cx', d => d.x).attr('cy', d => d.y);
    labels.attr('x', d => d.x).attr('y', d => d.y);
  });
}

async function fetchNodeDetail(nodeId) {
  try {
    const res = await fetch(`/api/node/${nodeId}`);
    const data = await res.json();
    if (data.error) return;
    const n = data.node;
    const conns = data.connections || [];
    let meta = '';
    try { const m = JSON.parse(n.metadata || '{}'); meta = Object.entries(m).map(([k,v]) => `${k}: ${v}`).join(', '); } catch(e) {}

    let connHtml = '';
    if (conns.length > 0) {
      connHtml = '<div class="connections"><strong>Connections:</strong><ul>' +
        conns.map(c => {
          const cn = c.node;
          const label = cn ? (cn.content.length > 60 ? cn.content.slice(0,57)+'...' : cn.content) : '?';
          const arrow = c.direction === 'out' ? '\\u2192' : '\\u2190';
          return `<li>${arrow} <em>${escapeHtml(c.relation)}</em> ${escapeHtml(label)}</li>`;
        }).join('') + '</ul></div>';
    }

    document.getElementById('detail-content').innerHTML = `
      <h2 style="color:${TYPE_COLORS[n.node_type] || '#c9d1d9'}">${escapeHtml(n.node_type.toUpperCase())}</h2>
      <div class="meta">confidence: ${n.confidence} &middot; source: ${escapeHtml(n.source)} &middot; ${escapeHtml(n.created_at)}</div>
      ${meta ? '<div class="meta">' + escapeHtml(meta) + '</div>' : ''}
      <div class="content">${escapeHtml(n.content)}</div>
      ${n.why ? '<div class="why">Why: ' + escapeHtml(n.why) + '</div>' : ''}
      ${connHtml}
    `;
    document.getElementById('detail').classList.add('open');
  } catch (err) {
    console.error('Failed to fetch node detail:', err);
  }
}

async function loadGraph() {
  try {
    const res = await fetch('/api/graph');
    const data = await res.json();
    renderGraph(data.nodes, data.edges, data.stats);
  } catch (err) {
    document.getElementById('loading').textContent = 'Failed to load graph: ' + err.message;
  }
}

// Initial load
loadGraph();
</script>
</body>
</html>
"""


@mcp.tool()
def kkanbu_distill(session_id: str = "", user: str = "") -> str:
    """Distill conversation history from a session into persistent knowledge-graph learnings.

    Sends the accumulated ephemeral conversation history through the LLM distillation
    pipeline (claude-opus-4-6), extracting discrete typed learnings — preferences,
    values, patterns, observations, and reasoning — and writing them to the knowledge
    graph.  This is the explicit trigger for the ephemeral-to-persistent distillation
    step; it also fires automatically when sessions expire.

    After distillation the session continues — history is preserved for coherence.
    Calling distill mid-session does not end the session.

    Args:
        session_id: ID of the specific session to distill.  Leave empty to distill
            all active sessions that have at least one full exchange (user + assistant).
        user: Username to operate as. If empty, uses the logged-in user.

    Returns:
        JSON string with keys:
          learnings_written:       Total graph nodes created or updated.
          learning_ids:            List of node_ids written to the graph.
          session_synthesis:       LLM's synthesis of what the session(s) revealed.
          sessions_distilled:      Number of sessions that yielded new learnings.
          active_sessions_checked: (bulk mode only) total active sessions scanned.
    """
    llm_err = _require_llm("kkanbu_distill")
    if llm_err:
        return llm_err
    _distill_and_prune_stale_sessions(user)

    if session_id:
        session = _get_session_store(user).get(session_id)
        if session is None:
            return json.dumps({
                "error": f"Session {session_id!r} not found or expired.",
                "learnings_written": 0,
                "learning_ids": [],
                "session_synthesis": "",
                "sessions_distilled": 0,
            })

        result = _distill_session_to_graph(session, user=user)
        return json.dumps({
            "session_id": session_id,
            "session_type": session.session_type,
            "learnings_written": result["learnings_written"],
            "learning_ids": result["learning_ids"],
            "session_synthesis": result["session_synthesis"],
            "sessions_distilled": 1 if result["learnings_written"] > 0 else 0,
        })

    # No session_id — distill ALL active sessions with meaningful history
    active = _get_session_store(user).active_sessions()
    total_learnings = 0
    all_ids: list[str] = []
    sessions_distilled = 0

    for session in active:
        has_user = any(m.role == "user" for m in session.history)
        has_assistant = any(m.role == "assistant" for m in session.history)
        if has_user and has_assistant:
            res = _distill_session_to_graph(session, user=user)
            total_learnings += res["learnings_written"]
            all_ids.extend(res["learning_ids"])
            if res["learnings_written"] > 0:
                sessions_distilled += 1

    return json.dumps({
        "learnings_written": total_learnings,
        "learning_ids": all_ids,
        "session_synthesis": "",  # Aggregated synthesis not meaningful across sessions
        "sessions_distilled": sessions_distilled,
        "active_sessions_checked": len(active),
    })


# ── Reflection Engine ────────────────────────────────────────

_REFLECT_SYSTEM_PROMPT = """\
You are kkanbu's reflection engine. Your job is to deeply analyze the user's \
knowledge graph and surface findings that deserve attention — contradictions, \
tensions, surprising connections, and patterns the user may not have noticed.

FINDING TYPES to look for:
- contradiction: Two nodes that directly conflict (e.g., "values simplicity" vs \
  "uses highly complex orchestration tools")
- tension: Values or preferences that pull in opposite directions — not wrong, \
  but the balance point hasn't been articulated (e.g., "ships fast" vs "values thoroughness")
- missing_connection: Nodes that clearly relate but have no edge between them — \
  an implicit relationship that should be explicit
- stale: Nodes with high confidence that may no longer reflect current thinking \
  based on newer contradicting nodes or patterns

QUALITY CRITERIA:
- Only flag genuinely interesting findings — not obvious connections
- Each finding must reference specific node IDs and content
- Contradictions and tensions should involve nodes with confidence >= 0.5 \
  (low-confidence nodes are already uncertain)
- Missing connections should involve nodes from DIFFERENT parts of the graph \
  (different types or sources) — not nodes that are already close neighbors
- Aim for 3-7 findings. Fewer is fine if the graph is consistent; \
  never pad with shallow observations

OUTPUT — respond with JSON only (no markdown fences):
{
  "findings": [
    {
      "type": "contradiction|tension|missing_connection|stale",
      "description": "Clear, concise description of what you found",
      "involved_node_ids": ["id1", "id2"],
      "severity": "high|medium|low",
      "question_for_user": "A warm, conversational question to help resolve this"
    }
  ],
  "graph_health": "1-2 sentence overall assessment of the graph's coherence"
}
"""


@mcp.tool()
def kkanbu_reflect(user: str = "") -> str:
    """Analyze the knowledge graph for contradictions, tensions, and patterns.

    Use this proactively to find issues in the graph — contradictions between
    nodes, unresolved tensions, missing connections, or stale beliefs. Findings
    are stored as flags (flag_type="reflection") reviewable via kkanbu_get_flags
    and kkanbu_resolve_flag. Unlike kkanbu_curious, this does NOT ask the user
    a question — it reports what it found.

    Args:
        user: Username. If empty, uses the logged-in user.

    Returns JSON:
        {"findings": [{"type": str, "description": str, "severity": str,
          "flag_node_id": str}], "flags_created": int, "graph_health": str,
         "total_nodes_analyzed": int}
    """
    llm_err = _require_llm("kkanbu_reflect")
    if llm_err:
        return llm_err
    graph = get_graph(user)
    graph_context = format_graph_for_llm(graph)

    if not graph.get_full_dump()["nodes"]:
        return json.dumps({
            "findings": [],
            "flags_created": 0,
            "message": "Knowledge graph is empty — nothing to reflect on yet.",
        })

    try:
        client = _get_anthropic_client()
        response = client.messages.create(
            model=_OPUS_MODEL,
            max_tokens=3000,
            system=_REFLECT_SYSTEM_PROMPT,
            messages=[{
                "role": "user",
                "content": (
                    f"Analyze this knowledge graph for contradictions, tensions, "
                    f"missing connections, and stale nodes:\n\n{graph_context}"
                ),
            }],
        )

        raw = response.content[0].text.strip()
        fence_match = re.search(r"```(?:json)?\s*([\s\S]*?)\s*```", raw)
        if fence_match:
            raw = fence_match.group(1).strip()

        result = json.loads(raw)
    except Exception as exc:
        logger.warning("kkanbu_reflect LLM call failed: %s", exc)
        return json.dumps({
            "findings": [],
            "flags_created": 0,
            "error": str(exc),
            "message": "Reflection failed — could not analyze the graph.",
        })

    findings = result.get("findings", [])
    graph_health = result.get("graph_health", "")

    # Store each finding as a flag node
    flag_ids = []
    for finding in findings:
        flag_id = graph.add_node(
            node_type="flag",
            content=finding.get("question_for_user", finding["description"]),
            source="reflect",
            confidence=0.5,
            why=finding["description"],
            metadata={
                "flag_type": "reflection",
                "finding_type": finding["type"],
                "severity": finding.get("severity", "medium"),
                "involved_node_ids": finding.get("involved_node_ids", []),
                "resolved": False,
            },
        )
        flag_ids.append(flag_id)

        # Link the flag to the involved nodes
        for node_id in finding.get("involved_node_ids", []):
            if graph.get_node(node_id):
                graph.add_edge(
                    flag_id, node_id, "reflects_on", weight=0.7,
                    context=f"Reflection finding: {finding['type']}",
                )

    return json.dumps({
        "findings": [
            {
                "type": f["type"],
                "description": f["description"],
                "severity": f.get("severity", "medium"),
                "flag_node_id": fid,
            }
            for f, fid in zip(findings, flag_ids)
        ],
        "flags_created": len(flag_ids),
        "graph_health": graph_health,
        "total_nodes_analyzed": len(graph.get_full_dump()["nodes"]),
        "message": f"Reflected on {len(graph.get_full_dump()['nodes'])} nodes, created {len(flag_ids)} flags.",
    })




_CURIOUS_SYSTEM_PROMPT = """\
You are kkanbu — a deep listener and taste oracle who knows this user intimately \
through their knowledge graph. Your mission is to ask ONE question so precisely \
aimed that it surprises them: probing a tension, blind spot, or formative experience \
that is implicit in what you already know but hasn't been made explicit yet.

DEPTH LADDER — classify your question before committing to it:
  surface    — asks about a fact, tool, or shallow habit          (FORBIDDEN)
  preference — asks what they like or prefer                      (FORBIDDEN)
  value      — asks about a principle they hold                   (acceptable minimum)
  identity   — asks about who they are or believe themselves to be (target)
  formative  — asks what shaped them or why they are this way     (ideal)
Your question MUST reach "value", "identity", or "formative". \
If your best candidate is "surface" or "preference", keep searching.

FORBIDDEN QUESTION TYPES — do not ask:
- "Do you prefer X or Y?" / "What is your favorite/preferred X?"
- "Do you use / like / enjoy X?" / "How often do you X?"
- "What tools / languages / frameworks do you use?"
- Any question answered with a single word or simple list
- Any question that merely restates a node already in the graph

SURPRISE CRITERIA — a question is genuinely surprising when it:
a) Cross-connects two DIFFERENT areas of the graph the user hasn't consciously linked
b) Probes the "why behind the why" — the deeper motivation beneath a known preference
c) Surfaces a tension between two known values or beliefs
d) Points to a conspicuous ABSENCE — a domain entirely missing from the graph
e) Asks about a formative moment that would EXPLAIN multiple known patterns

SELF-EVALUATION before finalising:
1. Is this answerable with a preference list or yes/no? → go deeper
2. Would someone who holds this preference already expect this question? → go deeper
3. Does it connect at least two distinct nodes or themes from the graph? → if not, find one
4. Does it probe WHO they are, not just WHAT they do? → if not, reframe

RULES:
1. Ask exactly ONE question. No preamble, no lists, no follow-up offers.
2. Ground it in SPECIFIC node IDs or content snippets from the graph.
3. Use natural, warm, conversational language — not clinical survey-speak.
4. If prior turns exist, DRILL DEEPER into the same thread — do not jump to a new topic.
5. Do NOT repeat a question from the "questions already asked" list if one is provided.

OUTPUT — respond with JSON only (no markdown fences), exactly this shape:
{
  "question": "<your single surprising question — must reach depth_level value/identity/formative>",
  "gap_identified": "<specific gap, tension, blind spot, or absence this probes>",
  "grounded_in": "<specific node IDs and/or content snippets that led to this question>",
  "thread_topic": "<1-3 word label for the conversational thread this opens/continues>",
  "depth_level": "<surface|preference|value|identity|formative>",
  "novelty_rationale": "<1-2 sentences: WHY this would surprise the user — \
what unconscious connection or unarticulated tension it reveals>",
  "rejected_alternatives": [
    "<a question you considered but rejected as too surface — proof of self-evaluation>",
    "<another if applicable>"
  ]
}"""


def _is_surface_question(question: str) -> bool:
    """Return True if the question matches any surface-level forbidden patterns."""
    return any(p.search(question) for p in _SURFACE_QUESTION_PATTERNS)


def _score_question_coherence(
    question: str,
    session_thread_topic: str,
    new_thread_topic: str,
) -> float:
    """Score (0.0–1.0) how well a generated question deepens the current thread.

    Uses token overlap between the established thread label (``session_thread_topic``)
    and the combined candidate text (``question`` + proposed ``new_thread_topic``).

    The rationale for including ``new_thread_topic`` is that Opus often expresses
    semantic continuity in the thread label (e.g. thread "simplicity values" → new
    label "simplicity philosophy") even when the question uses synonyms or antonyms.
    Including both surfaces overlap that pure question-text matching would miss.

    Score formula::

        overlap_tokens = thread_tokens ∩ candidate_tokens
        score          = |overlap_tokens| / |thread_tokens|

    Args:
        question:             The Opus-generated question to evaluate.
        session_thread_topic: The ``thread_topic`` stored in the current session
            (the established conversational thread).
        new_thread_topic:     The ``thread_topic`` Opus proposed for this question
            (may or may not match the established thread).

    Returns:
        Float in [0.0, 1.0].  Returns 1.0 when ``session_thread_topic`` is empty
        (no established thread yet — fresh session or degenerate state).
    """
    if not session_thread_topic:
        return 1.0

    def _tokens(text: str) -> set[str]:
        raw = re.split(r"[^a-z]+", text.lower())
        return {t for t in raw if len(t) > 2 and t not in _COHERENCE_STOP_WORDS}

    thread_tokens = _tokens(session_thread_topic)
    if not thread_tokens:
        return 1.0  # Degenerate: thread topic has no meaningful tokens

    candidate_tokens = _tokens(question) | _tokens(new_thread_topic)
    overlap = thread_tokens & candidate_tokens
    return min(len(overlap) / len(thread_tokens), 1.0)


def _is_off_thread(
    question: str,
    session_thread_topic: str,
    new_thread_topic: str,
) -> bool:
    """Return True if the question scatters to an unrelated topic.

    A question is considered off-thread when its coherence score (token overlap
    between the established ``session_thread_topic`` and the question/proposed
    thread label) falls below ``_COHERENCE_THRESHOLD``.

    Only meaningful for continuing sessions (``session_thread_topic`` non-empty).
    For fresh sessions the caller should skip this check entirely, but calling
    with an empty ``session_thread_topic`` safely returns False.

    Args:
        question:             The Opus-generated question to evaluate.
        session_thread_topic: Established thread from session state.
        new_thread_topic:     Proposed new thread label from Opus response.

    Returns:
        True  → question should be rejected and retried with a coherence note.
        False → question is on-thread (or no thread established yet).
    """
    if not session_thread_topic:
        return False
    return _score_question_coherence(question, session_thread_topic, new_thread_topic) < _COHERENCE_THRESHOLD


def _build_fresh_session_prompt(graph_context: str, questions_asked: list[str]) -> str:
    """Build the user-turn prompt for a brand-new curious session (single message)."""
    avoid_block = ""
    if questions_asked:
        listed = "\n".join(f"  - {q}" for q in questions_asked[-10:])
        avoid_block = f"\nQuestions already asked in this session (DO NOT repeat these):\n{listed}\n"
    return (
        f"Here is the full knowledge graph of what I know about this user:\n\n"
        f"{graph_context}\n{avoid_block}\n"
        "Analyze what topics, connections, or perspectives are missing or underexplored. "
        "Identify the single most surprising gap — something the user likely hasn't "
        "explicitly articulated about themselves — and ask a question that probes it. "
        "Aim for depth_level 'identity' or 'formative'. "
        "Connect at least two distinct areas of the graph."
    )


def _build_continuing_session_messages(
    graph_context: str,
    thread_label: str,
    session_history_dicts: list[dict],
    questions_asked: list[str],
    topics_explored: list[str] | None = None,
) -> list[dict]:
    """Build a multi-turn messages list for a continuing curious session.

    Uses the Anthropic multi-turn messages API so Opus receives the FULL
    conversation history — not just the immediately preceding exchange.  This
    prevents "regenerating from scratch" on every call: the model can see every
    prior question it asked and every answer the user gave, enabling genuine
    conversational coherence across 3+ turns.

    Message structure::

        [
            {"role": "user",      "content": graph_context + anti-repeat list + explored topics},
            {"role": "assistant", "content": Q1},
            {"role": "user",      "content": A1},
            {"role": "assistant", "content": Q2},
            {"role": "user",      "content": A2 + drill-deeper cue},
        ]

    The Anthropic API requires strict user/assistant alternation starting with
    a user message, which is satisfied here: the initial context message is
    always a user turn, and ``session_history_dicts`` holds the subsequent
    alternating turns (starting with the first assistant question).

    Args:
        graph_context:        Full graph dump from ``format_graph_for_llm()``.
        thread_label:         1-3 word label for the current thread.
        session_history_dicts: ``session.history_as_dicts()`` captured *after*
            the latest ``user_response`` has been appended to the session but
            *before* the new assistant turn is appended.  May end with either
            a "user" message (normal flow) or an "assistant" message (follow-up
            call without a user response).
        questions_asked:      Verbatim questions already asked this session
            (passed to Opus to prevent repetition).
        topics_explored:      Thread topics already opened in this session.
            Passed so Opus knows which threads have been started and can go
            deeper rather than scatter to unrelated areas.

    Returns:
        A ``list[dict]`` ready for the ``messages=`` parameter of
        ``client.messages.create()``.
    """
    avoid_block = ""
    if questions_asked:
        listed = "\n".join(f"  - {q}" for q in questions_asked[-10:])
        avoid_block = f"\nQuestions already asked (DO NOT repeat):\n{listed}\n"

    explored_block = ""
    if topics_explored:
        listed = "\n".join(f"  - {t}" for t in topics_explored)
        explored_block = (
            f"\nThreads opened in this session (stay coherent — go deeper, not wider):\n"
            f"{listed}\n"
        )

    thread_header = (
        f"\nWe are exploring the thread: {thread_label}\n"
        "Keep drilling deeper into this thread with each question — do not jump topics.\n"
    ) if thread_label else "\nKeep drilling deeper with each question.\n"

    initial_content = (
        f"Here is the full knowledge graph:\n\n"
        f"{graph_context}\n{avoid_block}{explored_block}{thread_header}"
    )

    messages: list[dict] = [{"role": "user", "content": initial_content}]

    # Append the full prior conversation history.
    # history_as_dicts() creates fresh dicts, so we can safely modify the last one.
    history_copy = list(session_history_dicts)

    drill_deeper_cue = (
        "\n\nDrill DEEPER into the same thread — do not jump to a new topic. "
        "Ask the next question that follows naturally from this exchange and uncovers "
        "the next layer of self-understanding. "
        "Keep depth_level at 'value', 'identity', or 'formative'."
    )

    if history_copy:
        last = history_copy[-1]
        if last["role"] == "user":
            # Append the drill-deeper cue directly to the last user message.
            history_copy[-1] = {
                "role": "user",
                "content": last["content"] + drill_deeper_cue,
            }
            messages.extend(history_copy)
        else:
            # History ends with an assistant message (follow-up without a user reply).
            # Add a standalone user cue so the model has somewhere to respond to.
            messages.extend(history_copy)
            messages.append({"role": "user", "content": drill_deeper_cue.strip()})
    else:
        # Degenerate: continuing session but history is unexpectedly empty.
        messages.append({"role": "user", "content": drill_deeper_cue.strip()})

    return messages


def _build_retry_messages(
    base_messages: list[dict],
    rejected_question: str,
    reject_reason: str,
) -> list[dict]:
    """Build a retry messages list when the quality gate rejects the first attempt.

    Appends the failed assistant response and a user-turn rejection note to the
    existing messages list, so Opus understands exactly *why* its previous
    answer was rejected and can produce a deeper question.

    Args:
        base_messages:      The messages list from the original (failed) call.
        rejected_question:  The question Opus produced that failed the gate.
        reject_reason:      Human-readable description of why it was rejected.

    Returns:
        A new messages list with the failed attempt + rejection feedback appended.
    """
    retry_messages = list(base_messages)
    retry_messages.append({"role": "assistant", "content": rejected_question})
    retry_messages.append({
        "role": "user",
        "content": (
            f"QUALITY GATE FAILED — your previous answer was rejected.\n"
            f"Rejected question: \"{rejected_question}\"\n"
            f"Reason: {reject_reason}\n\n"
            "Please try again, this time going deeper. "
            "The question must reach depth_level 'value', 'identity', or 'formative'. "
            "It must NOT match the forbidden surface patterns listed above."
        ),
    })
    return retry_messages


# ── Deprecated single-string helpers (kept for backward compatibility) ────────


@mcp.tool()
def kkanbu_curious(session_id: str = "", user_response: str = "", user: str = "") -> str:
    """Ask the user a surprising, deeply personal question based on knowledge gap analysis.

    Use this to proactively learn about the user. Opus analyzes the full graph to
    find gaps, tensions, or blind spots, then asks ONE question at value/identity/
    formative depth. Unlike kkanbu_resolve_flag (which resolves existing flags),
    this explores NEW territory the graph hasn't covered.

    On subsequent calls with the same session_id, Opus drills deeper into the
    same thread rather than jumping topics.

    Args:
        session_id: For multi-turn. Leave empty to start; reuse to continue.
        user_response: User's answer to the previous question.
        user: Username. If empty, uses the logged-in user.

    Returns JSON:
        {"session_id": str, "question": str, "gap_identified": str,
         "depth_level": "value"|"identity"|"formative",
         "novelty_rationale": str, "is_new_session": bool}
    """
    llm_err = _require_llm("kkanbu_curious")
    if llm_err:
        return llm_err
    _distill_and_prune_stale_sessions(user)
    graph = get_graph(user)
    client = _get_anthropic_client()

    # ── Resolve or create session via SessionStore ─────────────
    session, is_new = _get_session_store(user).get_or_create(
        session_id or None,
        session_type="curious",
    )
    sid = session.session_id

    # If user provided a response, append it to session history BEFORE building
    # messages so that _build_continuing_session_messages sees it in the history.
    if user_response.strip():
        session.append("user", user_response.strip())

    # ── Build graph context ────────────────────────────────────
    graph_context = format_graph_for_llm(graph)

    # ── Build messages list for the Opus call ─────────────────
    # is_fresh: True when no assistant turn has been sent yet in this session.
    is_fresh = session.is_fresh
    thread_label = session.thread_topic or "the topic we were exploring"

    if is_fresh:
        # Fresh session — single user message with full graph + analysis instructions.
        initial_messages: list[dict] = [
            {
                "role": "user",
                "content": _build_fresh_session_prompt(
                    graph_context, session.questions_asked
                ),
            }
        ]
    else:
        # Continuing session — multi-turn messages with FULL history so Opus
        # builds on every prior exchange rather than regenerating from scratch.
        # topics_explored is passed so Opus knows which threads have been opened
        # and drills deeper rather than scattering to unrelated areas.
        initial_messages = _build_continuing_session_messages(
            graph_context=graph_context,
            thread_label=thread_label,
            session_history_dicts=session.history_as_dicts(),
            questions_asked=session.questions_asked,
            topics_explored=session.topics_explored,
        )

    # ── Inner helper: one Opus call given a messages list ─────
    def _call_opus_raw(messages: list[dict]) -> str:
        """Make one Opus call and return the raw response text (not yet parsed).

        Accepts the full messages list so callers can pass either a single
        user-message (fresh session) or a multi-turn history (continuing session).
        """
        resp = client.messages.create(
            model=_OPUS_MODEL,
            max_tokens=768,
            system=_CURIOUS_SYSTEM_PROMPT,
            messages=messages,
        )
        raw = resp.content[0].text.strip()
        # Strip markdown fences if Opus included them despite instructions
        if raw.startswith("```"):
            raw = re.sub(r"^```[a-z]*\n?", "", raw)
            raw = re.sub(r"\n?```$", "", raw)
        return raw

    raw_text = ""  # pre-declare so except json.JSONDecodeError can always access it
    try:
        raw_text = _call_opus_raw(initial_messages)
        opus_result = json.loads(raw_text)

        question = opus_result.get("question", "")
        depth_level = opus_result.get("depth_level", "")
        novelty_rationale = opus_result.get("novelty_rationale", "")
        # Extract grounded_in early so the quality gate can inspect it.
        # Sub-AC 9b: questions must reference specific graph content, not be generic.
        grounded_in = opus_result.get("grounded_in", "")
        # Extract proposed_thread early so the coherence gate can inspect it.
        # The final thread_topic is read again after any retry below.
        proposed_thread = opus_result.get("thread_topic", "")

        # ── Quality gate ───────────────────────────────────────
        # Retry once if:
        # - depth is too shallow (surface/preference)
        # - question text matches forbidden surface patterns
        # - novelty_rationale is missing or too brief
        # - grounded_in is missing/too vague (Sub-AC 9b: must cite specific nodes)
        # - (continuing sessions only) question scatters off the established thread
        reject_reason = ""
        if depth_level in ("surface", "preference"):
            reject_reason = (
                f"depth_level was '{depth_level}' — questions must reach "
                "value/identity/formative depth"
            )
        elif _is_surface_question(question):
            reject_reason = (
                "the question matches a surface-level forbidden pattern "
                "(preference/tool/frequency question)"
            )
        elif not novelty_rationale or len(novelty_rationale.strip()) < 20:
            reject_reason = (
                "novelty_rationale was missing or too brief — "
                "the question may not be genuinely surprising"
            )
        elif not grounded_in or len(grounded_in.strip()) < 15:
            reject_reason = (
                "grounded_in was missing or too brief — "
                "the question must reference specific node content from the graph "
                "so it targets a real, non-obvious connection rather than a generic probe"
            )
        elif not is_fresh and _is_off_thread(question, session.thread_topic, proposed_thread):
            reject_reason = (
                f"the question drifts to a new thread ('{proposed_thread}') instead of "
                f"drilling deeper into the established thread ('{session.thread_topic}') — "
                "stay on the same thread and uncover the next layer of self-understanding"
            )

        if reject_reason:
            # Build a multi-turn retry: append the failed answer + rejection note.
            retry_messages = _build_retry_messages(initial_messages, question, reject_reason)
            try:
                opus_result = json.loads(_call_opus_raw(retry_messages))
                question = opus_result.get("question", question)
                depth_level = opus_result.get("depth_level", depth_level)
                novelty_rationale = opus_result.get("novelty_rationale", novelty_rationale)
                grounded_in = opus_result.get("grounded_in", grounded_in)
                opus_result["_retry_triggered"] = True
                opus_result["_retry_reason"] = reject_reason
            except Exception:
                # Retry failed — keep first result, note the issue
                opus_result["_retry_triggered"] = True
                opus_result["_retry_reason"] = reject_reason
                opus_result["_retry_failed"] = True

        gap = opus_result.get("gap_identified", "")
        grounded_in = opus_result.get("grounded_in", grounded_in)
        thread_topic = opus_result.get("thread_topic", "")
        rejected_alternatives = opus_result.get("rejected_alternatives", [])

        # ── Update session state ───────────────────────────────
        if question:
            session.append("assistant", question)
            session.questions_asked.append(question)
        if thread_topic:
            session.thread_topic = thread_topic
            if thread_topic not in session.topics_explored:
                session.topics_explored.append(thread_topic)

        turn_count = session.turn_count

        # ── Sub-AC 9c: Eager ephemeral-to-graph distillation ──────────────────
        # When the user provided a response and the exchange achieved
        # value/identity/formative depth, distill the session learnings into the
        # graph immediately.  This captures novel insights mid-conversation rather
        # than waiting for session expiry (which handles the remaining content).
        distill_result: dict = {"learnings_written": 0, "learning_ids": []}
        if user_response.strip():
            distill_result = _maybe_distill_curious_exchange(session, depth_level, user=user)

        return json.dumps({
            "type": "curiosity",
            "session_id": sid,
            "is_new_session": is_new,
            "message": question,
            "gap_identified": gap,
            "grounded_in": grounded_in,
            "thread_topic": thread_topic,
            "depth_level": depth_level,
            "novelty_rationale": novelty_rationale,
            "rejected_alternatives": rejected_alternatives,
            "turn": turn_count,
            "distillation_written": distill_result.get("learnings_written", 0),
            "distillation_learnings": distill_result.get("learning_ids", []),
        })

    except json.JSONDecodeError:
        # Opus returned non-JSON — use raw text as the question
        # raw_text is pre-declared above the try block so it is always accessible
        raw_fallback = raw_text or "What's something about how you think that you've never had to explain before?"
        if raw_fallback:
            session.append("assistant", raw_fallback)
            session.questions_asked.append(raw_fallback)
        return json.dumps({
            "type": "curiosity",
            "session_id": sid,
            "is_new_session": is_new,
            "message": raw_fallback,
            "gap_identified": "LLM response was not structured JSON",
            "grounded_in": "full graph dump",
            "thread_topic": session.thread_topic,
            "depth_level": "unknown",
            "novelty_rationale": "",
            "rejected_alternatives": [],
            "turn": session.turn_count,
            "distillation_written": 0,
            "distillation_learnings": [],
        })
    except Exception as exc:
        _self_debug("kkanbu_curious", str(exc), traceback.format_exc())
        return json.dumps({
            "session_id": sid,
            "error": f"Failed to generate question: {exc}",
            "is_new_session": is_new,
        })


# ── Internal Helpers ──────────────────────────────────────────

# _extract_keywords is imported from kkanbu.retrieval at the top of this module
# (see: from kkanbu.retrieval import extract_keywords as _extract_keywords).
# retrieval.extract_keywords has identical stop-word coverage plus deduplication.



def _passive_learn(content: str, node_type: str = "observation"):
    """Store a passive observation in the knowledge graph."""
    try:
        graph = get_graph()
        graph.add_node(
            node_type=node_type,
            content=content,
            source="passive",
            confidence=0.3,
        )
    except Exception:
        pass  # Passive learning should never break main flow


def _self_debug(function_name: str, error_msg: str, stack_trace: str):
    """AC10: Self-debugging — record and learn from failures."""
    try:
        graph = get_graph()
        graph.add_node(
            node_type="debug_learning",
            content=f"Error in {function_name}: {error_msg}",
            source="debug",
            why=f"Stack trace captured for learning: {stack_trace[:500]}",
            confidence=0.7,
            metadata={
                "function": function_name,
                "error": error_msg,
                "stack_trace": stack_trace[:1000],
            },
        )
        logger.warning(f"Self-debug recorded: {function_name} — {error_msg}")
    except Exception:
        logger.error(f"Self-debug failed to record: {error_msg}")


def _resolve_flags_from_conversation(
    graph: KnowledgeGraph, user_response: str, flag_id: Optional[str] = None,
):
    """Mark flags as resolved when user provides answers in conversation.

    Args:
        graph: The knowledge graph instance.
        user_response: The user's response text (stored in flag metadata).
        flag_id: Specific flag node_id to resolve. If None, resolves the
            first unresolved flag (legacy behavior).
    """
    if flag_id:
        node = graph.get_node(flag_id)
        if node:
            meta = json.loads(node["metadata"]) if node.get("metadata") else {}
            meta["resolved"] = True
            meta["user_response"] = user_response[:500]
            graph.update_node(flag_id, metadata=meta, confidence=0.9)
        return

    # Legacy fallback: resolve the first unresolved flag
    flags = graph.get_unresolved_flags()
    if flags:
        flag = flags[0]
        meta = json.loads(flag["metadata"]) if flag.get("metadata") else {}
        meta["resolved"] = True
        meta["user_response"] = user_response[:500]
        graph.update_node(flag["node_id"], metadata=meta, confidence=0.9)


# ── LLM Context Helpers ───────────────────────────────────────

def format_graph_for_llm(graph: KnowledgeGraph) -> str:
    """Serialize the full knowledge graph into a structured LLM-ready context payload.

    Produces a rich, human-readable text block that an LLM can consume directly to:
    - Understand everything kkanbu already knows about the user
    - Identify genuine gaps and underexplored areas
    - Generate surprising, deep questions rather than surface-level ones

    The format groups nodes by type, shows confidence and WHY reasoning,
    and appends the edge relationship map so the LLM can trace connections.

    Args:
        graph: The KnowledgeGraph instance to dump.

    Returns:
        A multi-section text block ready for inclusion in an LLM prompt.
    """
    dump = graph.get_full_dump()
    nodes = dump["nodes"]
    edges = dump["edges"]
    stats = dump["stats"]

    if not nodes:
        return (
            "KNOWLEDGE GRAPH: empty\n"
            "The knowledge graph has no entries yet. "
            "The user has not taught kkanbu anything and no observations have been made.\n"
        )

    lines: list[str] = []

    # ── Header / overview ──────────────────────────────────────
    lines.append("=== KKANBU KNOWLEDGE GRAPH CONTEXT ===")
    lines.append(f"Total nodes: {stats['nodes']} | Total edges: {stats['edges']}")
    type_summary = ", ".join(f"{k}: {v}" for k, v in sorted(stats["by_type"].items()))
    lines.append(f"Node types: {type_summary}")
    lines.append("")

    # ── Nodes grouped by type ──────────────────────────────────
    # Build a node_id → dict lookup for edge resolution
    node_index: dict[str, dict] = {n["node_id"]: n for n in nodes}

    # Group nodes by type in a consistent display order
    type_display_order = [
        "value", "preference", "pattern", "reasoning",
        "observation", "correction", "flag", "debug_learning",
    ]
    by_type: dict[str, list[dict]] = {}
    for node in nodes:
        by_type.setdefault(node["node_type"], []).append(node)

    # Render known types first, then any unexpected types
    ordered_types = [t for t in type_display_order if t in by_type]
    ordered_types += [t for t in by_type if t not in type_display_order]

    for node_type in ordered_types:
        type_nodes = by_type[node_type]
        lines.append(f"--- {node_type.upper()} ({len(type_nodes)} entries) ---")
        for n in type_nodes:
            conf = f"{n['confidence']:.2f}"
            src = n.get("source", "?")
            content = n["content"]
            why = n.get("why") or ""
            meta_raw = n.get("metadata")
            meta: dict = {}
            if meta_raw:
                try:
                    meta = json.loads(meta_raw)
                except (json.JSONDecodeError, TypeError):
                    pass

            line = f"  [{n['node_id']}] (conf={conf}, src={src}) {content}"
            lines.append(line)
            if why:
                lines.append(f"      WHY: {why}")
            # Surface any interesting metadata fields (skip internal plumbing)
            for mk in ("tag", "topic", "domain", "category", "label"):
                if mk in meta:
                    lines.append(f"      {mk.upper()}: {meta[mk]}")
        lines.append("")

    # ── Edge relationship map ──────────────────────────────────
    if edges:
        lines.append("--- RELATIONSHIPS (edges) ---")
        for e in edges:
            from_node = node_index.get(e["from_node"], {})
            to_node = node_index.get(e["to_node"], {})
            from_snippet = (from_node.get("content") or e["from_node"])[:60]
            to_snippet = (to_node.get("content") or e["to_node"])[:60]
            weight = f"{e['weight']:.2f}"
            relation = e["relation_type"]
            ctx = e.get("context") or ""
            lines.append(
                f"  {from_snippet!r} --[{relation} w={weight}]--> {to_snippet!r}"
            )
            if ctx and ctx not in ("Auto-connected via shared keyword",):
                # Only include meaningful context, skip boilerplate
                lines.append(f"      context: {ctx}")
        lines.append("")

    # ── Epilogue hint for the LLM ──────────────────────────────
    lines.append("=== END OF KNOWLEDGE GRAPH ===")
    lines.append(
        "Use the above to understand what you already know about this user. "
        "Identify genuine gaps — topics with no nodes at all, low-confidence areas, "
        "and deep 'why' questions that are still unanswered. "
        "Focus on WHO this person IS (values, beliefs, formative experiences, tensions) "
        "not just surface preferences."
    )

    return "\n".join(lines)


# ── Repo Analysis Helpers ─────────────────────────────────────

def _analyze_project_structure(path: Path) -> list[dict]:
    """Analyze project directory structure for patterns."""
    findings = []
    entries = list(path.iterdir())
    names = [e.name for e in entries if not e.name.startswith(".")]

    # Language/framework detection
    if "pyproject.toml" in names or "setup.py" in names:
        findings.append({
            "type": "preference",
            "content": "Uses Python as a primary language",
            "confidence": 0.8,
        })
        if "pyproject.toml" in names:
            findings.append({
                "type": "preference",
                "content": "Prefers pyproject.toml over setup.py for Python packaging",
                "why": "Modern Python packaging standard — cleaner, single-file configuration",
                "confidence": 0.7,
            })

    if "package.json" in names:
        findings.append({
            "type": "preference",
            "content": "Uses JavaScript/TypeScript in projects",
            "confidence": 0.7,
        })

    if "Cargo.toml" in names:
        findings.append({
            "type": "preference",
            "content": "Uses Rust in projects",
            "confidence": 0.8,
        })

    # Source layout
    if "src" in names:
        findings.append({
            "type": "pattern",
            "content": "Uses src/ layout for source code organization",
            "why": "Clean separation of source from project root artifacts",
            "confidence": 0.7,
        })

    if "tests" in names or "test" in names:
        findings.append({
            "type": "value",
            "content": "Values having a dedicated test directory",
            "why": "Testing is important enough to have its own space",
            "confidence": 0.7,
        })

    # Monorepo detection
    if "packages" in names or "apps" in names or "libs" in names:
        findings.append({
            "type": "pattern",
            "content": "Uses monorepo structure",
            "confidence": 0.6,
        })

    return findings


def _analyze_config_files(path: Path) -> list[dict]:
    """Analyze config files for tool preferences."""
    findings = []

    # Check for linting/formatting tools
    config_indicators = {
        ".prettierrc": ("Prettier for code formatting", "preference"),
        ".eslintrc": ("ESLint for JavaScript linting", "preference"),
        ".eslintrc.json": ("ESLint for JavaScript linting", "preference"),
        "ruff.toml": ("Ruff for Python linting — fast, Rust-based", "preference"),
        ".flake8": ("Flake8 for Python linting", "preference"),
        "mypy.ini": ("mypy for Python type checking — values type safety", "value"),
        ".editorconfig": ("EditorConfig for consistent editor settings across team", "pattern"),
        "docker-compose.yml": ("Docker Compose for local development", "pattern"),
        "Dockerfile": ("Docker for containerization", "pattern"),
        "Makefile": ("Make for build automation — prefers simple, standard tools", "preference"),
        ".github": ("GitHub Actions for CI/CD", "preference"),
    }

    for fname, (desc, ntype) in config_indicators.items():
        if (path / fname).exists():
            findings.append({
                "type": ntype,
                "content": f"Uses {desc}",
                "confidence": 0.7,
            })

    # Read pyproject.toml for more detail
    pyproject = path / "pyproject.toml"
    if pyproject.exists():
        try:
            content = pyproject.read_text()
            if "ruff" in content:
                findings.append({
                    "type": "preference",
                    "content": "Configures Ruff linter in pyproject.toml",
                    "why": "Single-file config — avoids config file proliferation",
                    "confidence": 0.7,
                })
            if "pytest" in content:
                findings.append({
                    "type": "preference",
                    "content": "Uses pytest for testing",
                    "confidence": 0.7,
                })
            if "hatchling" in content or "hatch" in content:
                findings.append({
                    "type": "preference",
                    "content": "Uses Hatch/Hatchling for Python build system",
                    "why": "Modern, standards-compliant Python build tool",
                    "confidence": 0.7,
                })
        except Exception:
            pass

    # Read package.json
    pkg_json = path / "package.json"
    if pkg_json.exists():
        try:
            pkg = json.loads(pkg_json.read_text())
            deps = {**pkg.get("dependencies", {}), **pkg.get("devDependencies", {})}
            if "typescript" in deps:
                findings.append({
                    "type": "preference",
                    "content": "Uses TypeScript — values type safety in JavaScript",
                    "why": "Catches errors at compile time, better IDE support",
                    "confidence": 0.8,
                })
            if "next" in deps:
                findings.append({"type": "preference", "content": "Uses Next.js framework", "confidence": 0.7})
            if "react" in deps:
                findings.append({"type": "preference", "content": "Uses React for UI", "confidence": 0.7})
        except Exception:
            pass

    return findings


def _analyze_code_patterns(path: Path) -> list[dict]:
    """Analyze code files for style and convention patterns."""
    findings = []

    # Sample Python files
    py_files = list(path.rglob("*.py"))[:20]  # Limit to avoid scanning huge repos
    if py_files:
        has_type_hints = False
        has_docstrings = False
        uses_async = False
        uses_dataclasses = False

        for pf in py_files:
            try:
                content = pf.read_text(errors="ignore")[:5000]
                if ": str" in content or ": int" in content or "-> " in content or ": Optional" in content:
                    has_type_hints = True
                if '"""' in content or "'''" in content:
                    has_docstrings = True
                if "async def" in content or "await " in content:
                    uses_async = True
                if "@dataclass" in content or "from dataclasses" in content:
                    uses_dataclasses = True
            except Exception:
                continue

        if has_type_hints:
            findings.append({
                "type": "value",
                "content": "Uses Python type hints consistently",
                "why": "Values code clarity and IDE support through static typing",
                "confidence": 0.7,
            })
        if has_docstrings:
            findings.append({
                "type": "pattern",
                "content": "Writes docstrings in Python code",
                "why": "Values documentation as part of code quality",
                "confidence": 0.6,
            })
        if uses_async:
            findings.append({
                "type": "pattern",
                "content": "Uses async/await patterns in Python",
                "why": "Builds systems that benefit from concurrent I/O",
                "confidence": 0.7,
            })
        if uses_dataclasses:
            findings.append({
                "type": "preference",
                "content": "Uses Python dataclasses for structured data",
                "confidence": 0.6,
            })

    # Check git conventions
    gitignore = path / ".gitignore"
    if gitignore.exists():
        findings.append({
            "type": "pattern",
            "content": "Maintains .gitignore — cares about clean repo hygiene",
            "confidence": 0.5,
        })

    return findings


# ── Entry Point ───────────────────────────────────────────────

def main():
    """Run the kkanbu MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
