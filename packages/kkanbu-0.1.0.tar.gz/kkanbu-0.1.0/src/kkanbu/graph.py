"""SQLite knowledge graph with 2-table adjacency schema (nodes + edges).

Captures preferences, values, reasoning patterns, and — crucially — the WHY
behind them and the connections between them.
"""

import json
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

DEFAULT_DB_PATH = Path.home() / ".kkanbu" / "knowledge.db"

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS nodes (
    node_id TEXT PRIMARY KEY,
    node_type TEXT NOT NULL,  -- preference, value, pattern, reasoning, observation, flag, correction, debug_learning
    content TEXT NOT NULL,
    why TEXT,                 -- the reasoning behind this knowledge — why the user holds this view
    source TEXT NOT NULL,     -- teach, ingest, conversation, passive, correction, debug
    confidence REAL NOT NULL DEFAULT 0.5,
    metadata TEXT,            -- JSON blob for extra context
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS edges (
    edge_id TEXT PRIMARY KEY,
    from_node TEXT NOT NULL,
    to_node TEXT NOT NULL,
    relation_type TEXT NOT NULL,  -- supports, contradicts, derives_from, etc.
    weight REAL NOT NULL DEFAULT 0.5,
    context TEXT,             -- why this relationship exists
    created_at TEXT NOT NULL,
    FOREIGN KEY (from_node) REFERENCES nodes(node_id),
    FOREIGN KEY (to_node) REFERENCES nodes(node_id)
);

CREATE INDEX IF NOT EXISTS idx_nodes_type ON nodes(node_type);
CREATE INDEX IF NOT EXISTS idx_nodes_source ON nodes(source);
CREATE INDEX IF NOT EXISTS idx_nodes_confidence ON nodes(confidence);
CREATE INDEX IF NOT EXISTS idx_edges_from ON edges(from_node);
CREATE INDEX IF NOT EXISTS idx_edges_to ON edges(to_node);
CREATE INDEX IF NOT EXISTS idx_edges_relation ON edges(relation_type);
"""


class KnowledgeGraph:
    """SQLite-backed knowledge graph for user preferences and reasoning."""

    def __init__(self, db_path: Optional[Path] = None):
        self.db_path = db_path or DEFAULT_DB_PATH
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(self.db_path))
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA foreign_keys=ON")
        self._init_schema()

    def _init_schema(self):
        self.conn.executescript(SCHEMA_SQL)
        self.conn.commit()

    def _now(self) -> str:
        return datetime.now(timezone.utc).isoformat()

    def _gen_id(self) -> str:
        return uuid.uuid4().hex[:12]

    # ── Node CRUD ──────────────────────────────────────────────

    def add_node(
        self,
        node_type: str,
        content: str,
        source: str,
        why: Optional[str] = None,
        confidence: float = 0.5,
        metadata: Optional[dict] = None,
    ) -> str:
        """Create a knowledge node. Returns node_id."""
        node_id = self._gen_id()
        now = self._now()
        self.conn.execute(
            """INSERT INTO nodes
               (node_id, node_type, content, why, source, confidence, metadata, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (node_id, node_type, content, why, source, confidence,
             json.dumps(metadata) if metadata else None, now, now),
        )
        self.conn.commit()
        return node_id

    def update_node(self, node_id: str, **kwargs) -> bool:
        """Update node fields. Returns True if node existed."""
        allowed = {"content", "why", "confidence", "metadata", "node_type"}
        updates = {k: v for k, v in kwargs.items() if k in allowed}
        if not updates:
            return False
        if "metadata" in updates and isinstance(updates["metadata"], dict):
            updates["metadata"] = json.dumps(updates["metadata"])
        updates["updated_at"] = self._now()
        set_clause = ", ".join(f"{k} = ?" for k in updates)
        values = list(updates.values()) + [node_id]
        cursor = self.conn.execute(
            f"UPDATE nodes SET {set_clause} WHERE node_id = ?", values
        )
        self.conn.commit()
        return cursor.rowcount > 0

    def get_node(self, node_id: str) -> Optional[dict]:
        row = self.conn.execute("SELECT * FROM nodes WHERE node_id = ?", (node_id,)).fetchone()
        return dict(row) if row else None

    def delete_node(self, node_id: str) -> bool:
        self.conn.execute("DELETE FROM edges WHERE from_node = ? OR to_node = ?", (node_id, node_id))
        cursor = self.conn.execute("DELETE FROM nodes WHERE node_id = ?", (node_id,))
        self.conn.commit()
        return cursor.rowcount > 0

    # ── Edge CRUD ──────────────────────────────────────────────

    def add_edge(
        self,
        from_node: str,
        to_node: str,
        relation_type: str,
        weight: float = 0.5,
        context: Optional[str] = None,
    ) -> str:
        """Create a relationship edge. Returns edge_id."""
        edge_id = self._gen_id()
        self.conn.execute(
            """INSERT INTO edges (edge_id, from_node, to_node, relation_type, weight, context, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (edge_id, from_node, to_node, relation_type, weight, context, self._now()),
        )
        self.conn.commit()
        return edge_id

    def get_edges_from(self, node_id: str) -> list[dict]:
        rows = self.conn.execute(
            "SELECT * FROM edges WHERE from_node = ?", (node_id,)
        ).fetchall()
        return [dict(r) for r in rows]

    def get_edges_to(self, node_id: str) -> list[dict]:
        rows = self.conn.execute(
            "SELECT * FROM edges WHERE to_node = ?", (node_id,)
        ).fetchall()
        return [dict(r) for r in rows]

    # ── Graph Queries ──────────────────────────────────────────

    def search_nodes(
        self,
        query: str,
        node_type: Optional[str] = None,
        min_confidence: float = 0.0,
        limit: int = 20,
    ) -> list[dict]:
        """Full-text search across node content and why fields."""
        sql = """
            SELECT * FROM nodes
            WHERE (content LIKE ? OR why LIKE ?)
            AND confidence >= ?
        """
        params: list = [f"%{query}%", f"%{query}%", min_confidence]
        if node_type:
            sql += " AND node_type = ?"
            params.append(node_type)
        sql += " ORDER BY confidence DESC, updated_at DESC LIMIT ?"
        params.append(limit)
        rows = self.conn.execute(sql, params).fetchall()
        return [dict(r) for r in rows]

    def get_connected_context(self, node_id: str, depth: int = 2) -> list[dict]:
        """BFS traversal to gather connected knowledge for richer answers."""
        visited = set()
        frontier = [node_id]
        results = []
        for _ in range(depth):
            next_frontier = []
            for nid in frontier:
                if nid in visited:
                    continue
                visited.add(nid)
                node = self.get_node(nid)
                if node:
                    results.append(node)
                # Traverse both directions
                for edge in self.get_edges_from(nid) + self.get_edges_to(nid):
                    neighbor = edge["to_node"] if edge["from_node"] == nid else edge["from_node"]
                    if neighbor not in visited:
                        next_frontier.append(neighbor)
                        results.append({"_edge": edge})
            frontier = next_frontier
        return results

    def get_all_by_type(self, node_type: str, limit: int = 100) -> list[dict]:
        rows = self.conn.execute(
            "SELECT * FROM nodes WHERE node_type = ? ORDER BY updated_at DESC LIMIT ?",
            (node_type, limit),
        ).fetchall()
        return [dict(r) for r in rows]

    def get_unresolved_flags(self) -> list[dict]:
        """Get all flag nodes that haven't been resolved yet."""
        rows = self.conn.execute(
            """SELECT * FROM nodes WHERE node_type = 'flag'
               AND (json_extract(metadata, '$.resolved') IS NULL
                    OR json_extract(metadata, '$.resolved') = 0)
               ORDER BY created_at DESC"""
        ).fetchall()
        return [dict(r) for r in rows]

    def get_stats(self) -> dict:
        node_count = self.conn.execute("SELECT COUNT(*) FROM nodes").fetchone()[0]
        edge_count = self.conn.execute("SELECT COUNT(*) FROM edges").fetchone()[0]
        type_counts = {}
        for row in self.conn.execute("SELECT node_type, COUNT(*) as cnt FROM nodes GROUP BY node_type"):
            type_counts[row[0]] = row[1]
        return {"nodes": node_count, "edges": edge_count, "by_type": type_counts}

    def get_full_dump(self) -> dict:
        """Return all nodes and edges from the knowledge graph as a structured dict.

        Used to build a complete LLM-ready context payload for tools like kkanbu_curious
        that need holistic understanding of what is known and what is missing.

        Returns:
            {
                "nodes": [list of all node dicts, ordered by updated_at DESC],
                "edges": [list of all edge dicts, ordered by created_at DESC],
                "stats": {nodes: int, edges: int, by_type: dict},
            }
        """
        nodes = [
            dict(r)
            for r in self.conn.execute(
                "SELECT * FROM nodes ORDER BY confidence DESC, updated_at DESC"
            ).fetchall()
        ]
        edges = [
            dict(r)
            for r in self.conn.execute(
                "SELECT * FROM edges ORDER BY weight DESC, created_at DESC"
            ).fetchall()
        ]
        return {
            "nodes": nodes,
            "edges": edges,
            "stats": self.get_stats(),
        }

    # Whitelist of columns that may be updated via upsert_node / update_node.
    _ALLOWED_UPSERT_FIELDS = frozenset({
        "node_type", "content", "why", "confidence", "metadata", "updated_at",
    })

    def upsert_node(
        self,
        node_type: str,
        content: str,
        source: str,
        node_id: Optional[str] = None,
        why: Optional[str] = None,
        confidence: float = 0.5,
        metadata: Optional[dict] = None,
    ) -> tuple[str, bool]:
        """Create a new node or update an existing one.

        When node_id is provided and the node exists, update its fields (content,
        why, node_type, confidence, metadata) and bump updated_at.  Otherwise fall
        through to a normal insert.

        Returns:
            (node_id, was_updated) — was_updated=True when an existing node was
            patched; False when a new node was created.
        """
        if node_id:
            existing = self.get_node(node_id)
            if existing:
                # Patch the mutable fields the LLM supplied
                updates: dict = {}
                if node_type:
                    updates["node_type"] = node_type
                if content:
                    updates["content"] = content
                if why is not None:
                    updates["why"] = why
                if confidence is not None:
                    updates["confidence"] = confidence
                if metadata is not None:
                    updates["metadata"] = json.dumps(metadata)

                updates["updated_at"] = self._now()
                # Filter to whitelisted column names only
                updates = {k: v for k, v in updates.items() if k in self._ALLOWED_UPSERT_FIELDS}
                if not updates:
                    return node_id, True
                set_clause = ", ".join(f"{k} = ?" for k in updates)
                values = list(updates.values()) + [node_id]
                self.conn.execute(
                    f"UPDATE nodes SET {set_clause} WHERE node_id = ?", values
                )
                # Update source separately (not in allowed set of update_node)
                self.conn.execute(
                    "UPDATE nodes SET source = ? WHERE node_id = ?",
                    (source, node_id),
                )
                self.conn.commit()
                return node_id, True

        # No node_id supplied, or node_id not found — create a new node
        new_id = self.add_node(
            node_type=node_type,
            content=content,
            source=source,
            why=why,
            confidence=confidence,
            metadata=metadata,
        )
        return new_id, False

    def close(self):
        self.conn.close()
