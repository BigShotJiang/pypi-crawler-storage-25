"""kkanbu — taste oracle MCP server for Ouroboros Socratic interviews."""
__version__ = "0.1.0"
