"""Tests for the knowledge graph module."""


import pytest

from kkanbu.graph import KnowledgeGraph


@pytest.fixture
def graph(tmp_path):
    db_path = tmp_path / "test.db"
    g = KnowledgeGraph(db_path)
    yield g
    g.close()


class TestNodeCRUD:
    def test_add_and_get_node(self, graph):
        node_id = graph.add_node("preference", "Prefers Python", "teach", why="Loves the syntax")
        node = graph.get_node(node_id)
        assert node is not None
        assert node["content"] == "Prefers Python"
        assert node["why"] == "Loves the syntax"
        assert node["source"] == "teach"
        assert node["node_type"] == "preference"

    def test_update_node(self, graph):
        node_id = graph.add_node("preference", "Likes tabs", "teach", confidence=0.5)
        graph.update_node(node_id, content="Likes spaces", confidence=0.9)
        node = graph.get_node(node_id)
        assert node["content"] == "Likes spaces"
        assert node["confidence"] == 0.9

    def test_delete_node(self, graph):
        nid = graph.add_node("preference", "temp", "teach")
        assert graph.delete_node(nid)
        assert graph.get_node(nid) is None

    def test_delete_node_cascades_edges(self, graph):
        n1 = graph.add_node("preference", "A", "teach")
        n2 = graph.add_node("preference", "B", "teach")
        graph.add_edge(n1, n2, "supports")
        graph.delete_node(n1)
        assert graph.get_edges_from(n1) == []
        assert graph.get_edges_to(n2) == []


class TestEdges:
    def test_add_and_query_edges(self, graph):
        n1 = graph.add_node("value", "Simplicity", "teach")
        n2 = graph.add_node("preference", "Minimal deps", "teach")
        graph.add_edge(n1, n2, "supports", weight=0.8, context="Simple means fewer deps")

        edges_from = graph.get_edges_from(n1)
        assert len(edges_from) == 1
        assert edges_from[0]["to_node"] == n2
        assert edges_from[0]["relation_type"] == "supports"

        edges_to = graph.get_edges_to(n2)
        assert len(edges_to) == 1


class TestSearch:
    def test_search_by_content(self, graph):
        graph.add_node("preference", "Prefers Python for scripting", "teach", confidence=0.8)
        graph.add_node("preference", "Uses Rust for performance", "teach", confidence=0.9)
        results = graph.search_nodes("Python")
        assert len(results) == 1
        assert "Python" in results[0]["content"]

    def test_search_by_why(self, graph):
        graph.add_node("preference", "Uses SQLite", "teach", why="No server needed, embedded")
        results = graph.search_nodes("embedded")
        assert len(results) == 1

    def test_search_with_type_filter(self, graph):
        graph.add_node("preference", "Python preferred", "teach")
        graph.add_node("value", "Python community values", "teach")
        results = graph.search_nodes("Python", node_type="value")
        assert len(results) == 1
        assert results[0]["node_type"] == "value"

    def test_search_with_confidence_filter(self, graph):
        graph.add_node("preference", "Maybe likes Java", "ingest", confidence=0.3)
        graph.add_node("preference", "Definitely likes Python", "teach", confidence=0.9)
        results = graph.search_nodes("likes", min_confidence=0.5)
        assert len(results) == 1
        assert "Python" in results[0]["content"]


class TestGraphTraversal:
    def test_connected_context(self, graph):
        n1 = graph.add_node("value", "Simplicity", "teach")
        n2 = graph.add_node("preference", "Minimal config", "teach")
        n3 = graph.add_node("reasoning", "Less to maintain", "teach")
        graph.add_edge(n1, n2, "supports")
        graph.add_edge(n2, n3, "why_because")

        context = graph.get_connected_context(n1, depth=2)
        node_ids = [c["node_id"] for c in context if "node_id" in c]
        assert n1 in node_ids
        assert n2 in node_ids


class TestFlags:
    def test_unresolved_flags(self, graph):
        graph.add_node("flag", "What testing framework?", "flag", confidence=0.3,
                       metadata={"best_guess": "pytest", "resolved": False})
        graph.add_node("flag", "Resolved question", "flag", confidence=0.3,
                       metadata={"best_guess": "yes", "resolved": True})
        flags = graph.get_unresolved_flags()
        assert len(flags) == 1
        assert flags[0]["content"] == "What testing framework?"


class TestStats:
    def test_stats(self, graph):
        graph.add_node("preference", "A", "teach")
        graph.add_node("value", "B", "teach")
        n1 = graph.add_node("preference", "C", "teach")
        n2 = graph.add_node("value", "D", "teach")
        graph.add_edge(n1, n2, "supports")

        stats = graph.get_stats()
        assert stats["nodes"] == 4
        assert stats["edges"] == 1
        assert stats["by_type"]["preference"] == 2
        assert stats["by_type"]["value"] == 2
