"""Tests for the kkanbu MCP server tools."""

import json
import os
import tempfile
import uuid
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

# Set up test DB path before importing server
_tmp_dir = tempfile.mkdtemp()
os.environ["KKANBU_DB_PATH"] = str(Path(_tmp_dir) / "test_server.db")

from kkanbu.server import (  # noqa: E402
    _distill_and_prune_stale_sessions,
    _distill_session_to_graph,
    _get_session_store,
    get_graph,
    kkanbu_answer,
    kkanbu_resolve_flag,
    kkanbu_correct,
    kkanbu_curious,
    kkanbu_distill,
    _flag_question,
    kkanbu_get_flags,
    kkanbu_ingest,
    kkanbu_status,
    kkanbu_learn,
)

class _SessionStoreProxy:
    """Proxy that delegates to the active test user's session store.

    Tests reference _session_store as a module-level object — this proxy
    transparently forwards attribute access to _get_session_store("_test_").
    """
    def __getattr__(self, name):
        return getattr(_get_session_store("_test_"), name)

    def __contains__(self, item):
        return item in _get_session_store("_test_")

    def __len__(self):
        return len(_get_session_store("_test_"))

_session_store = _SessionStoreProxy()


@pytest.fixture(autouse=True)
def fresh_graph():
    """Reset the graph and Anthropic client for each test with a unique DB."""
    import kkanbu.server as srv
    srv._user_graphs.clear()
    srv._user_session_stores.clear()
    srv._anthropic_client = None
    os.environ["KKANBU_DB_PATH"] = str(Path(_tmp_dir) / f"test_{uuid.uuid4().hex[:8]}.db")
    # Set a test user so _resolve_user("") works in tests
    srv._set_active_user("_test_")
    yield
    for g in srv._user_graphs.values():
        g.close()
    srv._user_graphs.clear()
    srv._user_session_stores.clear()
    srv._anthropic_client = None
    srv._clear_active_user()


# ── LLM Mock Helpers ──────────────────────────────────────────

def _make_llm_response(learnings: list, connections: list = None, identity_summary: str = "") -> MagicMock:
    """Build a mock Anthropic response message from structured data."""
    body = {
        "learnings": learnings,
        "connections": connections or [],
        "identity_summary": identity_summary,
    }
    msg = MagicMock()
    msg.content = [MagicMock(text=json.dumps(body))]
    return msg


@pytest.fixture
def llm_mock():
    """Patch anthropic.Anthropic to avoid real API calls.

    Yields the configured mock client so individual tests can set .messages.create return values.
    """
    with patch("kkanbu.server.anthropic.Anthropic") as mock_cls:
        mock_client = MagicMock()
        mock_cls.return_value = mock_client
        yield mock_client


# ── Tests ─────────────────────────────────────────────────────

def _make_answer_response(text: str) -> MagicMock:
    """Build a mock Anthropic response for kkanbu_answer (plain text, not JSON).

    Plain-text responses exercise the JSON-parse fallback path in _llm_generate_answer,
    which assigns a default llm_confidence of 0.7.
    """
    msg = MagicMock()
    msg.content = [MagicMock(text=text)]
    return msg


def _make_structured_answer_response(
    answer: str,
    llm_confidence: float,
    uncertainty_reasoning: str | None = None,
) -> MagicMock:
    """Build a mock Anthropic response for kkanbu_answer with structured JSON output.

    Simulates the real LLM response format produced when the updated _ANSWER_SYSTEM_PROMPT
    is used: a JSON object containing the answer text, the LLM's self-assessed confidence,
    and (optionally) factual reasoning for why confidence is low.
    """
    payload = {
        "answer": answer,
        "llm_confidence": llm_confidence,
        "uncertainty_reasoning": uncertainty_reasoning,
    }
    msg = MagicMock()
    msg.content = [MagicMock(text=json.dumps(payload))]
    return msg


class TestKkanbuAnswer:
    def test_answer_with_no_knowledge(self, llm_mock):
        """With empty graph, Opus is still called and returns a voice-faithful answer."""
        # Opus receives the empty-context payload and replies in the user's voice
        answer_resp = _make_answer_response(
            "Honestly, I haven't thought much about this yet."
        )
        llm_mock.messages.create.return_value = answer_resp

        raw = kkanbu_answer("What testing framework do you prefer?")
        data = json.loads(raw)

        # LLM must have been called exactly once (no early-return bypass)
        assert llm_mock.messages.create.call_count == 1

        # The answer should be in the response
        assert "haven't thought" in data["answer"].lower() or data["answer"]

        # Confidence should be low (empty graph → 0.1), triggering auto-flag
        assert data["confidence"] == pytest.approx(0.1, abs=0.01)

    def test_answer_with_taught_knowledge(self, llm_mock):
        """After teaching, answer calls Opus and returns LLM-generated response."""
        teach_resp = _make_llm_response(
            [{"content": "I prefer pytest for testing", "node_type": "preference",
              "why": "Simple syntax, powerful fixtures", "confidence": 0.9, "depth": "surface"}],
            identity_summary="A developer who values simple, powerful test tooling",
        )
        answer_resp = _make_answer_response(
            "I reach for pytest every time. Simple syntax and powerful fixtures "
            "make it my default — it just stays out of the way."
        )
        # First call → kkanbu_learn extraction; second call → kkanbu_answer generation
        llm_mock.messages.create.side_effect = [teach_resp, answer_resp]

        kkanbu_learn("I prefer pytest for testing", why="Simple syntax, powerful fixtures")
        result = kkanbu_answer("What testing framework do you prefer?")
        assert "pytest" in result.lower() or "flagged" in result.lower()

    def test_answer_calls_opus_with_voice_system_prompt(self, llm_mock):
        """kkanbu_answer passes the voice-fidelity system prompt to claude-opus-4-6."""
        teach_resp = _make_llm_response(
            [{"content": "I prefer pytest", "node_type": "preference",
              "why": "Clean API", "confidence": 0.9, "depth": "surface"}],
        )
        answer_resp = _make_answer_response("pytest is my go-to — clean API, great fixtures.")
        llm_mock.messages.create.side_effect = [teach_resp, answer_resp]

        kkanbu_learn("I prefer pytest", why="Clean API")
        kkanbu_answer("What testing framework do you prefer?")

        # The last call to messages.create is the answer generation
        last_call = llm_mock.messages.create.call_args_list[-1]
        kwargs = last_call.kwargs if last_call.kwargs else last_call[1]
        assert kwargs.get("model") == "claude-opus-4-6"
        assert "voice fidelity" in kwargs.get("system", "").lower() or \
               "taste oracle" in kwargs.get("system", "").lower()
        # Context payload + question should be in the user message
        user_content = kwargs["messages"][0]["content"]
        assert "interview question" in user_content.lower()

    def test_answer_includes_context_payload_in_llm_call(self, llm_mock):
        """The knowledge graph context is assembled and sent to the LLM."""
        teach_resp = _make_llm_response(
            [{"content": "I prefer SQLite for local storage", "node_type": "preference",
              "why": "Zero config, no server needed", "confidence": 0.9, "depth": "surface"}],
        )
        answer_resp = _make_answer_response(
            "For local storage I reach for SQLite — zero config and no server to manage."
        )
        llm_mock.messages.create.side_effect = [teach_resp, answer_resp]

        kkanbu_learn("I prefer SQLite for local storage", why="Zero config, no server needed")
        kkanbu_answer("What do you use for local data storage?")

        last_call = llm_mock.messages.create.call_args_list[-1]
        kwargs = last_call.kwargs if last_call.kwargs else last_call[1]
        user_content = kwargs["messages"][0]["content"]
        # Context payload header should be present
        assert "KNOWLEDGE CONTEXT" in user_content or "knowledge" in user_content.lower()

    def test_answer_llm_fallback_on_failure(self, llm_mock):
        """When LLM fails for answer generation, falls back to deterministic synthesis."""
        teach_resp = _make_llm_response(
            [{"content": "I prefer typed Python", "node_type": "preference",
              "why": "Better IDE support", "confidence": 0.9, "depth": "surface"}],
        )
        # Second call (answer) raises an exception → triggers fallback
        llm_mock.messages.create.side_effect = [teach_resp, Exception("API error")]

        kkanbu_learn("I prefer typed Python", why="Better IDE support")
        result = kkanbu_answer("Do you use type hints?")
        # Fallback produces deterministic text with knowledge graph content
        assert result  # not empty
        assert len(result) > 10

    def test_low_confidence_auto_flags(self, llm_mock):
        """Unrelated knowledge → low confidence → answer is flagged."""
        teach_resp = _make_llm_response(
            [{"content": "I like coffee", "node_type": "preference",
              "why": None, "confidence": 0.9, "depth": "surface"}],
        )
        answer_resp = _make_answer_response(
            "Honestly, I lean towards a simple setup but I'm not really sure yet."
        )
        # Both calls may or may not be made depending on whether bundle is empty
        llm_mock.messages.create.side_effect = [teach_resp, answer_resp]

        kkanbu_learn("I like coffee", category="preference")
        kkanbu_answer("What database architecture do you prefer?")
        flags = kkanbu_get_flags()
        # Either the answer was flagged or had no knowledge
        assert "flag" in flags.lower() or "No flagged" in flags


# ── Sub-AC 2b: Uncertainty detection and flagging ─────────────

class TestAnswerUncertaintyDetection:
    """Tests for LLM self-assessed confidence and uncertainty annotation in kkanbu_answer.

    Sub-AC 2b: the LLM evaluates its own confidence and annotates low-confidence
    responses with its reasoning so the interviewer can see exactly what knowledge
    is missing rather than just a bare confidence number.
    """

    def test_response_includes_llm_confidence_field(self, llm_mock):
        """kkanbu_answer JSON response always includes llm_confidence."""
        answer_resp = _make_structured_answer_response(
            answer="I reach for pytest every time — clean fixtures, no ceremony.",
            llm_confidence=0.88,
        )
        llm_mock.messages.create.return_value = answer_resp

        raw = kkanbu_answer("What testing framework do you prefer?")
        data = json.loads(raw)

        assert "llm_confidence" in data
        assert data["llm_confidence"] == pytest.approx(0.88, abs=0.01)

    def test_response_includes_flagged_field(self, llm_mock):
        """kkanbu_answer JSON response always includes a boolean 'flagged' field."""
        answer_resp = _make_structured_answer_response(
            answer="I reach for pytest every time.",
            llm_confidence=0.88,
        )
        llm_mock.messages.create.return_value = answer_resp

        raw = kkanbu_answer("What testing framework do you prefer?")
        data = json.loads(raw)

        assert "flagged" in data
        assert isinstance(data["flagged"], bool)

    def test_high_llm_confidence_not_flagged(self, llm_mock):
        """When LLM confidence is high (>=0.5) and graph confidence >= 0.4, answer is NOT flagged."""
        teach_resp = _make_llm_response(
            [{"content": "I prefer pytest for testing", "node_type": "preference",
              "why": "Simple fixtures", "confidence": 0.9, "depth": "surface"}],
        )
        answer_resp = _make_structured_answer_response(
            answer="I reach for pytest every time — simple fixtures, stays out of the way.",
            llm_confidence=0.85,
            uncertainty_reasoning=None,
        )
        llm_mock.messages.create.side_effect = [teach_resp, answer_resp]

        kkanbu_learn("I prefer pytest", why="Simple fixtures")
        raw = kkanbu_answer("What testing framework do you prefer?")
        data = json.loads(raw)

        assert data["flagged"] is False
        assert data["uncertainty_reasoning"] is None
        # Flag annotation should NOT appear in the answer text
        assert "⚑" not in data["answer"]

    def test_low_llm_confidence_triggers_flag_with_reasoning(self, llm_mock):
        """When LLM confidence is low (<0.5), answer is flagged and reasoning is appended."""
        teach_resp = _make_llm_response(
            [{"content": "I like minimalist tools", "node_type": "preference",
              "why": "Less cognitive overhead", "confidence": 0.75, "depth": "value"}],
        )
        answer_resp = _make_structured_answer_response(
            answer="My instinct is to go with something lightweight, but I'm not entirely sure.",
            llm_confidence=0.30,
            uncertainty_reasoning=(
                "No entries about database architecture exist in the graph. "
                "Extrapolating from general minimalism values."
            ),
        )
        llm_mock.messages.create.side_effect = [teach_resp, answer_resp]

        kkanbu_learn("I like minimalist tools", why="Less cognitive overhead")
        raw = kkanbu_answer("What database architecture do you prefer?")
        data = json.loads(raw)

        assert data["flagged"] is True
        assert data["llm_confidence"] == pytest.approx(0.30, abs=0.01)
        # Reasoning should be in the response JSON
        assert data["uncertainty_reasoning"] is not None
        assert "database architecture" in data["uncertainty_reasoning"]
        # Reasoning annotation should also appear in the answer text
        assert "⚑" in data["answer"]
        assert "database architecture" in data["answer"]

    def test_low_llm_confidence_no_reasoning_uses_generic_annotation(self, llm_mock):
        """When LLM confidence < 0.5 but no reasoning given, generic flag annotation used."""
        answer_resp = _make_structured_answer_response(
            answer="Honestly, I'm not sure about this one.",
            llm_confidence=0.35,
            uncertainty_reasoning=None,  # LLM omitted reasoning
        )
        llm_mock.messages.create.return_value = answer_resp

        raw = kkanbu_answer("What is your take on microservices?")
        data = json.loads(raw)

        assert data["flagged"] is True
        assert "⚑" in data["answer"]
        # Should fall back to generic annotation (no specific reasoning text)
        assert "llm" in data["answer"].lower() or "confidence" in data["answer"].lower()

    def test_llm_confidence_flags_even_when_graph_confidence_is_ok(self, llm_mock):
        """Low LLM confidence triggers flag even when graph confidence is above 0.4.

        The LLM's own assessment of how well it can represent the person is the
        authoritative uncertainty signal — graph confidence alone is insufficient.
        We teach cloud-related knowledge so retrieval finds a relevant node
        (graph confidence ≥ 0.4), but the LLM still self-assesses as low confidence
        because the match is only tangential.
        """
        teach_resp = _make_llm_response(
            [{"content": "I prefer AWS cloud for infrastructure", "node_type": "preference",
              "why": "Mature ecosystem and wide service catalog", "confidence": 0.85,
              "depth": "surface"}],
        )
        # LLM says graph has an entry, but it only covers AWS generically —
        # not enough to represent a nuanced cloud architecture preference
        answer_resp = _make_structured_answer_response(
            answer="I think I'd lean towards AWS, but I'm honestly not deeply opinionated here.",
            llm_confidence=0.25,
            uncertainty_reasoning=(
                "Graph has a single broad AWS preference entry but no specific architecture "
                "or use-case rationale. Answer is largely inferred from minimal context."
            ),
        )
        llm_mock.messages.create.side_effect = [teach_resp, answer_resp]

        kkanbu_learn("I prefer AWS cloud for infrastructure", why="Mature ecosystem")
        raw = kkanbu_answer("Which cloud provider do you prefer?")
        data = json.loads(raw)

        # Graph finds the AWS node → confidence ≥ 0.4, but LLM says 0.25
        assert data["confidence"] >= 0.4  # graph confidence is fine
        assert data["llm_confidence"] == pytest.approx(0.25, abs=0.01)
        # LLM-confidence-based flag still triggers
        assert data["flagged"] is True

    def test_graph_low_confidence_flags_even_when_llm_is_confident(self, llm_mock):
        """Graph confidence < 0.4 flags the answer regardless of LLM confidence.

        Preserves the original AC1 behaviour: a sparse/irrelevant graph always
        triggers a review flag, even if the LLM extrapolates confidently.
        """
        answer_resp = _make_structured_answer_response(
            answer="I haven't thought much about this yet.",
            llm_confidence=0.75,  # LLM is confident (it knows to say "no knowledge")
            uncertainty_reasoning=None,
        )
        llm_mock.messages.create.return_value = answer_resp

        # Empty graph → confidence = 0.1
        raw = kkanbu_answer("What is your favourite database?")
        data = json.loads(raw)

        assert data["confidence"] == pytest.approx(0.1, abs=0.01)
        assert data["flagged"] is True  # graph threshold triggers flag

    def test_uncertainty_reasoning_in_json_response_field(self, llm_mock):
        """uncertainty_reasoning appears as a top-level key in the JSON response."""
        answer_resp = _make_structured_answer_response(
            answer="My instinct leans serverless but I'm guessing.",
            llm_confidence=0.20,
            uncertainty_reasoning="No serverless or cloud entries in graph; pure extrapolation.",
        )
        llm_mock.messages.create.return_value = answer_resp

        raw = kkanbu_answer("Do you prefer serverless or containers?")
        data = json.loads(raw)

        assert "uncertainty_reasoning" in data
        assert data["uncertainty_reasoning"] == (
            "No serverless or cloud entries in graph; pure extrapolation."
        )

    def test_plain_text_response_fallback_sets_default_llm_confidence(self, llm_mock):
        """Plain-text LLM response (non-JSON) falls back to llm_confidence=0.7.

        Backward-compatibility: existing mocks and real responses that don't emit
        JSON should still work; they get a default moderate confidence.
        """
        # Plain text, not JSON — exercises the fallback path in _llm_generate_answer
        answer_resp = _make_answer_response(
            "For local storage I reach for SQLite — zero config, no server."
        )
        llm_mock.messages.create.return_value = answer_resp

        raw = kkanbu_answer("What do you use for local data storage?")
        data = json.loads(raw)

        # Fallback assigns 0.7 — should NOT trigger the llm_confidence < 0.5 flag
        assert data["llm_confidence"] == pytest.approx(0.7, abs=0.01)
        # With empty graph, confidence=0.1, so the answer WILL still be flagged
        # by graph confidence — but NOT due to LLM uncertainty
        assert "llm_confidence" in data

    def test_llm_confidence_clamped_at_bounds(self, llm_mock):
        """Out-of-range llm_confidence values from LLM are clamped to [0.0, 1.0]."""
        # LLM returns confidence > 1.0 (mis-formatted)
        payload = json.dumps({
            "answer": "I always use Rust for performance-critical code.",
            "llm_confidence": 1.5,  # out of range
            "uncertainty_reasoning": None,
        })
        msg = MagicMock()
        msg.content = [MagicMock(text=payload)]
        llm_mock.messages.create.return_value = msg

        raw = kkanbu_answer("What language for performance-critical systems?")
        data = json.loads(raw)

        assert data["llm_confidence"] <= 1.0

    def test_empty_string_uncertainty_reasoning_normalised_to_none(self, llm_mock):
        """An empty-string uncertainty_reasoning from LLM is normalised to None."""
        payload = json.dumps({
            "answer": "I reach for pytest without hesitation.",
            "llm_confidence": 0.90,
            "uncertainty_reasoning": "",  # LLM emitted empty string instead of null
        })
        msg = MagicMock()
        msg.content = [MagicMock(text=payload)]
        llm_mock.messages.create.return_value = msg

        raw = kkanbu_answer("What testing framework do you use?")
        data = json.loads(raw)

        assert data["uncertainty_reasoning"] is None

    def test_fallback_on_llm_failure_sets_flagged_true(self, llm_mock):
        """When LLM call fails entirely, the deterministic fallback marks the answer as flagged."""
        teach_resp = _make_llm_response(
            [{"content": "I prefer vim", "node_type": "preference",
              "why": "Modal editing", "confidence": 0.9, "depth": "surface"}],
        )
        llm_mock.messages.create.side_effect = [teach_resp, Exception("network timeout")]

        kkanbu_learn("I prefer vim", why="Modal editing")
        raw = kkanbu_answer("What editor do you use?")
        data = json.loads(raw)

        assert data["flagged"] is True
        assert data["llm_confidence"] == pytest.approx(0.1, abs=0.01)
        assert data["uncertainty_reasoning"] is not None
        assert "fallback" in data["uncertainty_reasoning"].lower()

    def test_system_prompt_requests_structured_json_output(self, llm_mock):
        """The system prompt sent to Opus asks for JSON with confidence self-assessment."""
        answer_resp = _make_structured_answer_response(
            answer="I value directness over abstraction.",
            llm_confidence=0.78,
        )
        llm_mock.messages.create.return_value = answer_resp

        kkanbu_answer("How do you approach system design?")

        call_kwargs = llm_mock.messages.create.call_args.kwargs
        system_prompt = call_kwargs.get("system", "")

        # System prompt must instruct LLM to produce JSON with required fields
        assert "llm_confidence" in system_prompt
        assert "uncertainty_reasoning" in system_prompt
        assert "json" in system_prompt.lower()


# ── Sub-AC 8a: kkanbu_answer end-to-end LLM pipeline ─────────────────────────


class TestSubAC8aAnswerEndToEndPipeline:
    """End-to-end pipeline validation for kkanbu_answer (Sub-AC 8a).

    Verifies that the full pipeline — knowledge graph context retrieval,
    context assembly, Opus call, and voice-faithful JSON response — executes
    without errors and each stage produces the expected output.

    Coverage map:
    ┌─────────────────────────────────────────────────────────┐
    │  question → retrieve_context() → to_prompt_payload()   │
    │           → _llm_generate_answer() [claude-opus-4-6]   │
    │           → structured JSON response                   │
    └─────────────────────────────────────────────────────────┘
    """

    def test_full_pipeline_executes_without_error(self, llm_mock):
        """Complete pipeline from question to JSON response runs without exceptions."""
        answer_resp = _make_structured_answer_response(
            answer="I reach for pytest without hesitation — clean fixtures, zero ceremony.",
            llm_confidence=0.88,
        )
        llm_mock.messages.create.return_value = answer_resp

        # Should not raise
        raw = kkanbu_answer("What testing framework do you prefer?")

        data = json.loads(raw)  # Must be valid JSON
        assert data  # Non-empty

    def test_context_retrieved_and_passed_to_opus_when_graph_populated(self, llm_mock):
        """Graph context is retrieved and included in the LLM call when knowledge exists.

        Teaches a preference, then asks a related question.  The context payload
        sent to Opus must contain content from the knowledge graph node.
        """
        teach_resp = _make_llm_response(
            [
                {
                    "content": "I prefer pytest over unittest for all Python testing",
                    "node_type": "preference",
                    "why": "Fixtures are more ergonomic and assertions are clearer",
                    "confidence": 0.92,
                    "depth": "preference",
                }
            ],
            identity_summary="A developer who values ergonomic, low-ceremony test tooling",
        )
        answer_resp = _make_structured_answer_response(
            answer=(
                "I always reach for pytest — the fixture model is just better, "
                "and assertions read naturally without any boilerplate."
            ),
            llm_confidence=0.91,
        )
        llm_mock.messages.create.side_effect = [teach_resp, answer_resp]

        kkanbu_learn(
            "I prefer pytest over unittest for all Python testing",
            why="Fixtures are more ergonomic and assertions are clearer",
        )
        kkanbu_answer("What testing framework do you prefer?")

        # Inspect the last LLM call (the answer generation)
        last_call = llm_mock.messages.create.call_args_list[-1]
        kwargs = last_call.kwargs if last_call.kwargs else last_call[1]
        user_content = kwargs["messages"][0]["content"]

        # Context payload must contain knowledge graph content
        assert "KNOWLEDGE CONTEXT" in user_content or "knowledge" in user_content.lower()
        # Graph knowledge should appear in the context (keyword match on "pytest")
        assert "pytest" in user_content.lower()

    def test_context_payload_present_even_with_empty_graph(self, llm_mock):
        """Even with an empty graph, a context payload header is passed to Opus.

        The LLM must always receive a context frame — even if it says 'no knowledge found'
        — so it can answer authentically in the user's voice.
        """
        answer_resp = _make_structured_answer_response(
            answer="Honestly, I haven't given this much thought yet.",
            llm_confidence=0.15,
            uncertainty_reasoning="No relevant entries in the graph; answer is speculative.",
        )
        llm_mock.messages.create.return_value = answer_resp

        kkanbu_answer("What is your preferred cloud provider?")

        call_kwargs = llm_mock.messages.create.call_args.kwargs
        user_content = call_kwargs["messages"][0]["content"]

        # Empty-graph payload should still include context markers
        assert "KNOWLEDGE CONTEXT" in user_content or "knowledge" in user_content.lower()
        # No relevant knowledge message
        assert "no relevant knowledge" in user_content.lower() or \
               "not yet" in user_content.lower() or \
               "END CONTEXT" in user_content

    def test_response_always_uses_opus_model(self, llm_mock):
        """kkanbu_answer always calls claude-opus-4-6, never a cheaper model."""
        answer_resp = _make_structured_answer_response(
            answer="I value simplicity above almost everything else in system design.",
            llm_confidence=0.82,
        )
        llm_mock.messages.create.return_value = answer_resp

        kkanbu_answer("How do you approach system design?")

        call_kwargs = llm_mock.messages.create.call_args.kwargs
        assert call_kwargs.get("model") == "claude-opus-4-6", (
            "kkanbu_answer must always use claude-opus-4-6 (no cost-optimisation)"
        )

    def test_voice_fidelity_system_prompt_enforced(self, llm_mock):
        """Voice-fidelity rules are encoded in the system prompt sent to Opus."""
        answer_resp = _make_structured_answer_response(
            answer="I build for boring reliability — elegance is secondary.",
            llm_confidence=0.87,
        )
        llm_mock.messages.create.return_value = answer_resp

        kkanbu_answer("What is your engineering philosophy?")

        call_kwargs = llm_mock.messages.create.call_args.kwargs
        system = call_kwargs.get("system", "")

        # System prompt encodes voice-fidelity rules
        assert "first person" in system.lower() or "taste oracle" in system.lower(), (
            "System prompt must encode first-person / taste-oracle voice rules"
        )
        assert "i prefer" in system.lower() or "for me" in system.lower(), (
            "System prompt must include first-person phrasing examples"
        )
        # Must prohibit AI meta-commentary
        assert "disclaimer" in system.lower() or "caveat" in system.lower() or \
               "meta" in system.lower(), (
            "System prompt must explicitly prohibit AI caveats / meta-commentary"
        )

    def test_response_json_contains_all_required_fields(self, llm_mock):
        """The JSON response always contains every required field."""
        answer_resp = _make_structured_answer_response(
            answer="I lean strongly towards event-driven architectures for async workloads.",
            llm_confidence=0.79,
        )
        llm_mock.messages.create.return_value = answer_resp

        raw = kkanbu_answer("What architecture pattern do you favour for async systems?")
        data = json.loads(raw)

        required_fields = {
            "session_id",
            "answer",
            "confidence",
            "llm_confidence",
            "flagged",
            "uncertainty_reasoning",
            "turn",
            "is_new_session",
        }
        for field_name in required_fields:
            assert field_name in data, f"Required field '{field_name}' missing from response"

    def test_voice_fidelity_first_person_in_answer(self, llm_mock):
        """The answer text uses first-person voice, not third-person or AI-style."""
        answer_resp = _make_structured_answer_response(
            answer=(
                "I always reach for type hints in Python — it makes refactoring "
                "dramatically safer and lets the IDE catch errors before runtime."
            ),
            llm_confidence=0.90,
        )
        llm_mock.messages.create.return_value = answer_resp

        raw = kkanbu_answer("Do you use type annotations in Python?")
        data = json.loads(raw)

        answer_text = data["answer"]
        answer_lower = answer_text.lower()

        # Must include first-person markers
        first_person_markers = ["i ", "i'", "my ", "me ", "for me", "i always", "i prefer"]
        has_first_person = any(m in answer_lower for m in first_person_markers)
        assert has_first_person, (
            f"Answer must use first-person voice. Got: {answer_text!r}"
        )

        # Must NOT include AI-style disclaimers
        ai_caveats = [
            "as an ai", "as a language model", "based on my training",
            "i don't have personal", "i cannot", "i'm unable to",
        ]
        has_ai_caveat = any(c in answer_lower for c in ai_caveats)
        assert not has_ai_caveat, (
            f"Answer must not include AI caveats. Got: {answer_text!r}"
        )

    def test_high_confidence_graph_produces_non_flagged_answer(self, llm_mock):
        """When graph has high-confidence knowledge and LLM agrees, answer is not flagged."""
        teach_resp = _make_llm_response(
            [
                {
                    "content": "I value fast feedback loops in development",
                    "node_type": "value",
                    "why": "Slow feedback kills momentum and masks bugs",
                    "confidence": 0.95,
                    "depth": "value",
                }
            ],
        )
        answer_resp = _make_structured_answer_response(
            answer=(
                "Fast feedback loops are non-negotiable for me. "
                "Slow cycles kill momentum and let bugs compound — "
                "I'll always optimise for tighter iteration."
            ),
            llm_confidence=0.92,
        )
        llm_mock.messages.create.side_effect = [teach_resp, answer_resp]

        kkanbu_learn("I value fast feedback loops", why="Slow feedback kills momentum")
        raw = kkanbu_answer("How important is developer feedback speed to you?")
        data = json.loads(raw)

        assert data["flagged"] is False
        assert data["confidence"] >= 0.4
        assert data["llm_confidence"] >= 0.5

    def test_pipeline_records_session_history_for_multi_turn(self, llm_mock):
        """Pipeline records question and answer in session history for multi-turn tracking."""
        answer_resp = _make_structured_answer_response(
            answer="I lean towards monorepos for co-located teams — easier refactoring.",
            llm_confidence=0.75,
        )
        llm_mock.messages.create.return_value = answer_resp

        raw1 = kkanbu_answer("Do you prefer monorepos or polyrepos?")
        data1 = json.loads(raw1)
        sid = data1["session_id"]

        assert data1["is_new_session"] is True
        assert data1["turn"] == 1

        # Second turn uses same session
        raw2 = kkanbu_answer("Why do you prefer that approach?", session_id=sid)
        data2 = json.loads(raw2)

        assert data2["is_new_session"] is False
        assert data2["turn"] == 2
        assert data2["session_id"] == sid

    def test_llm_fallback_does_not_raise_on_api_error(self, llm_mock):
        """When Opus API call fails, kkanbu_answer returns a deterministic fallback, not an exception."""
        teach_resp = _make_llm_response(
            [
                {
                    "content": "I prefer immutable data structures where possible",
                    "node_type": "preference",
                    "why": "Easier to reason about state",
                    "confidence": 0.88,
                    "depth": "preference",
                }
            ],
        )
        llm_mock.messages.create.side_effect = [teach_resp, Exception("Service unavailable")]

        kkanbu_learn("I prefer immutable data structures", why="Easier to reason about state")

        # Must not raise — must return a fallback JSON string
        raw = kkanbu_answer("What data structures do you reach for?")
        data = json.loads(raw)  # Must be parseable

        assert data["flagged"] is True  # Fallback always flags
        assert data["llm_confidence"] == pytest.approx(0.1, abs=0.01)
        assert data["answer"]  # Non-empty fallback answer

    def test_context_bfs_depth_captures_related_nodes(self, llm_mock):
        """BFS expansion includes related nodes in context, not just direct keyword matches.

        Teaches two nodes connected by an edge, then asks about one.
        The BFS expansion should pull in the related node at depth 1+.
        """
        # Teach two related preferences
        teach_resp1 = _make_llm_response(
            [
                {
                    "content": "I prefer functional programming paradigms",
                    "node_type": "preference",
                    "why": "Composability and referential transparency",
                    "confidence": 0.88,
                    "depth": "preference",
                }
            ],
        )
        teach_resp2 = _make_llm_response(
            [
                {
                    "content": "I avoid shared mutable state whenever possible",
                    "node_type": "value",
                    "why": "Mutable state is the root of most concurrency bugs",
                    "confidence": 0.91,
                    "depth": "value",
                }
            ],
        )
        answer_resp = _make_structured_answer_response(
            answer=(
                "Functional programming is my default lens — "
                "I avoid mutable state because it's the source of most concurrency headaches."
            ),
            llm_confidence=0.88,
        )
        llm_mock.messages.create.side_effect = [teach_resp1, teach_resp2, answer_resp]

        kkanbu_learn("I prefer functional programming", why="Composability and referential transparency")
        kkanbu_learn("I avoid shared mutable state", why="Root of most concurrency bugs")
        raw = kkanbu_answer("What programming paradigm do you use?")

        data = json.loads(raw)
        assert data["answer"]
        # Answer should be non-empty and voice-faithful
        assert len(data["answer"]) > 20


# ── Sub-AC 8b: kkanbu_learn end-to-end LLM pipeline ──────────────────────────


class TestSubAC8bTeachEndToEndPipeline:
    """End-to-end pipeline validation for kkanbu_learn (Sub-AC 8b).

    Verifies that the full pipeline — graph context retrieval, Opus extraction
    call, autonomous node/edge writing, and second-pass edge inference — executes
    without errors and each stage produces the expected graph state and response.

    Coverage map:
    ┌─────────────────────────────────────────────────────────────────┐
    │  insight → get_full_dump() (graph context)                      │
    │          → _llm_extract_learnings() [claude-opus-4-6]           │
    │          → upsert_node() × N  (LLM-autonomy node writing)      │
    │          → add_edge() × M    (LLM-specified connections)        │
    │          → _infer_edges_for_new_nodes() [second Opus pass]      │
    │          → JSON response { session_id, result, insights_extracted│
    │                            turn, is_new_session }               │
    └─────────────────────────────────────────────────────────────────┘
    """

    def test_full_pipeline_executes_without_error(self, llm_mock):
        """Complete pipeline from insight to JSON response runs without exceptions."""
        llm_mock.messages.create.return_value = _make_llm_response(
            [
                {
                    "content": "I prefer pytest for all Python testing",
                    "node_type": "preference",
                    "why": "Fixtures are ergonomic",
                    "confidence": 0.9,
                    "depth": "surface",
                },
                {
                    "content": "Values developer tools that minimise ceremony",
                    "node_type": "value",
                    "why": None,
                    "confidence": 0.85,
                    "depth": "identity",
                },
            ],
            identity_summary="A developer who values ergonomic, low-ceremony tooling",
        )

        # Should not raise
        raw = kkanbu_learn("I prefer pytest", why="Fixtures are ergonomic")

        data = json.loads(raw)  # Must be valid JSON
        assert data  # Non-empty

    def test_graph_dump_passed_as_context_to_llm(self, llm_mock):
        """Existing graph knowledge is included in the LLM call as context.

        Seeds the graph via a first teach, then teaches a second insight.
        The second LLM call must receive graph content from the first node.
        """
        teach_resp1 = _make_llm_response(
            [
                {
                    "content": "I prefer Python for scripting",
                    "node_type": "preference",
                    "why": None,
                    "confidence": 0.9,
                    "depth": "surface",
                }
            ],
        )
        teach_resp2 = _make_llm_response(
            [
                {
                    "content": "I value readable code over clever code",
                    "node_type": "value",
                    "why": "Maintainability over cleverness",
                    "confidence": 0.88,
                    "depth": "identity",
                }
            ],
        )
        llm_mock.messages.create.side_effect = [teach_resp1, teach_resp2]

        kkanbu_learn("I prefer Python for scripting")

        # Capture the second call's arguments
        kkanbu_learn("I value readability", why="Maintainability matters")

        # The second call to messages.create should have seen existing graph content
        second_call = llm_mock.messages.create.call_args_list[1]
        kwargs = second_call.kwargs if second_call.kwargs else second_call[1]
        user_content = kwargs["messages"][0]["content"]

        # Existing knowledge should be visible in the prompt
        assert "python" in user_content.lower() or "existing knowledge" in user_content.lower(), (
            "Second LLM call must receive existing graph context"
        )

    def test_pipeline_always_uses_opus_model(self, llm_mock):
        """kkanbu_learn always calls claude-opus-4-6, never a cheaper model."""
        llm_mock.messages.create.return_value = _make_llm_response(
            [
                {
                    "content": "I value code simplicity",
                    "node_type": "value",
                    "why": None,
                    "confidence": 0.9,
                    "depth": "identity",
                }
            ],
        )

        kkanbu_learn("I value simplicity above all")

        # The extraction call is always the first LLM call
        first_call = llm_mock.messages.create.call_args_list[0]
        kwargs = first_call.kwargs if first_call.kwargs else first_call[1]
        assert kwargs.get("model") == "claude-opus-4-6", (
            "kkanbu_learn must always use claude-opus-4-6 (no cost-optimisation)"
        )

    def test_depth_over_surface_encoded_in_system_prompt(self, llm_mock):
        """System prompt enforces DEPTH-OVER-SURFACE identity extraction principle."""
        llm_mock.messages.create.return_value = _make_llm_response(
            [
                {
                    "content": "I prefer minimalist tools",
                    "node_type": "value",
                    "why": None,
                    "confidence": 0.88,
                    "depth": "identity",
                }
            ],
        )

        kkanbu_learn("I prefer minimalist tools")

        first_call = llm_mock.messages.create.call_args_list[0]
        kwargs = first_call.kwargs if first_call.kwargs else first_call[1]
        system = kwargs.get("system", "")

        # System prompt must encode depth-over-surface principle
        assert "depth" in system.lower() or "surface" in system.lower() or "identity" in system.lower(), (
            "System prompt must encode DEPTH-OVER-SURFACE identity extraction principle"
        )
        # System prompt must reference WHO the user IS
        assert "who" in system.lower() or "identity" in system.lower() or "worldview" in system.lower(), (
            "System prompt must guide extraction toward WHO the user IS, not surface preferences"
        )

    def test_response_json_contains_all_required_fields(self, llm_mock):
        """The JSON response always contains every required field."""
        llm_mock.messages.create.return_value = _make_llm_response(
            [
                {
                    "content": "I favour event-driven architectures",
                    "node_type": "preference",
                    "why": "Decoupling and scalability",
                    "confidence": 0.85,
                    "depth": "surface",
                }
            ],
            identity_summary="Architect who values loosely coupled systems",
        )

        raw = kkanbu_learn("I favour event-driven architectures for async workloads")
        data = json.loads(raw)

        required_fields = {"session_id", "result", "insights_extracted", "turn", "is_new_session"}
        for field_name in required_fields:
            assert field_name in data, f"Required field '{field_name}' missing from teach response"

    def test_deep_identity_learnings_persisted_to_graph(self, llm_mock):
        """Identity-level learnings (value, reasoning) are persisted to the graph.

        The LLM extracts both surface and identity-level nodes; both must appear
        in the knowledge graph after the teach call.
        """
        llm_mock.messages.create.return_value = _make_llm_response(
            [
                {
                    "content": "I prefer immutable data structures",
                    "node_type": "preference",
                    "why": "Easier to reason about state",
                    "confidence": 0.9,
                    "depth": "surface",
                },
                {
                    "content": "Believes predictability is more valuable than flexibility",
                    "node_type": "value",
                    "why": "Predictable systems fail loudly and safely",
                    "confidence": 0.88,
                    "depth": "identity",
                },
                {
                    "content": "Avoids shared mutable state as a foundational engineering rule",
                    "node_type": "pattern",
                    "why": "Root cause of most concurrency bugs",
                    "confidence": 0.85,
                    "depth": "identity",
                },
            ],
            identity_summary="An engineer who treats immutability as an identity-level principle",
        )

        raw = kkanbu_learn("I prefer immutable data structures", why="Easier to reason about state")
        data = json.loads(raw)

        # All three learnings should be stored
        assert data["insights_extracted"] == 3

        graph = get_graph()
        stats = graph.get_stats()
        assert stats["nodes"] >= 3, "All extracted learnings must be persisted to the graph"

        # Identity-level nodes (value, pattern) must be present
        values = graph.get_all_by_type("value")
        patterns = graph.get_all_by_type("pattern")
        assert len(values) >= 1, "Value-level (identity) nodes must be in graph"
        assert len(patterns) >= 1, "Pattern-level (identity) nodes must be in graph"

    def test_llm_specified_connections_written_to_graph(self, llm_mock):
        """LLM-specified connections (edges) are applied to the knowledge graph.

        When the LLM returns connections between a new node and an existing graph
        node, those edges must be written to the graph.
        """
        # Seed graph
        teach_resp1 = _make_llm_response(
            [
                {
                    "content": "I prefer Python over Java",
                    "node_type": "preference",
                    "why": None,
                    "confidence": 0.9,
                    "depth": "surface",
                }
            ],
        )
        llm_mock.messages.create.return_value = teach_resp1
        kkanbu_learn("I prefer Python over Java")

        graph = get_graph()
        python_nodes = graph.search_nodes("Python")
        existing_id = python_nodes[0]["node_id"] if python_nodes else None
        assert existing_id, "Seed node must exist"

        # Second teach: LLM references the existing Python node via connection
        teach_resp2 = _make_llm_response(
            learnings=[
                {
                    "content": "I use type hints throughout Python projects",
                    "node_type": "pattern",
                    "why": "Better IDE support and self-documenting code",
                    "confidence": 0.88,
                    "depth": "identity",
                }
            ],
            connections=[
                {
                    "learning_index": 0,
                    "to_node_id": existing_id,
                    "relation_type": "exemplifies",
                    "context": "Type hints exemplify Python preference",
                }
            ],
        )
        llm_mock.messages.create.return_value = teach_resp2
        kkanbu_learn("I use type hints throughout Python projects")

        # Verify edge was written
        graph2 = get_graph()
        new_type_hint_nodes = graph2.search_nodes("type hints")
        assert new_type_hint_nodes, "New type-hint node must exist"
        new_id = new_type_hint_nodes[0]["node_id"]
        edges_from = graph2.get_edges_from(new_id)
        edge_targets = {e["to_node"] for e in edges_from}
        assert existing_id in edge_targets, (
            "LLM-specified edge from new node to existing Python node must be written to graph"
        )

    def test_upsert_updates_existing_node_not_duplicate(self, llm_mock):
        """When LLM specifies upsert_node_id, the existing node is updated, not duplicated."""
        # First teach — creates node
        teach_resp1 = _make_llm_response(
            [
                {
                    "content": "I prefer Python 3.11",
                    "node_type": "preference",
                    "why": None,
                    "confidence": 0.8,
                    "depth": "surface",
                }
            ],
        )
        llm_mock.messages.create.return_value = teach_resp1
        kkanbu_learn("I prefer Python 3.11")

        graph = get_graph()
        py_nodes = graph.search_nodes("Python")
        assert py_nodes, "Python node must exist after first teach"
        original_id = py_nodes[0]["node_id"]
        initial_count = graph.get_stats()["nodes"]

        # Second teach — LLM specifies upsert on the existing node
        teach_resp2 = _make_llm_response(
            [
                {
                    "content": "I use Python 3.12 — match statements changed my approach",
                    "node_type": "preference",
                    "why": "Match statements reduce boilerplate significantly",
                    "confidence": 0.9,
                    "depth": "surface",
                    "upsert_node_id": original_id,
                }
            ],
        )
        llm_mock.messages.create.return_value = teach_resp2
        raw = kkanbu_learn("Actually I've moved to Python 3.12")
        data = json.loads(raw)

        # Node count must not increase from the upserted node
        graph2 = get_graph()
        final_count = graph2.get_stats()["nodes"]
        assert final_count == initial_count, (
            f"Upsert must not create a duplicate node. "
            f"Before: {initial_count}, After: {final_count}"
        )

        # Result must mention 'updated'
        assert "updated" in data["result"].lower() or "1 updated" in data["result"].lower(), (
            "Result text must indicate the node was updated via upsert"
        )

    def test_passive_source_conversation_text_path(self, llm_mock):
        """conversation_text parameter flows through the pipeline with source='passive'."""
        llm_mock.messages.create.return_value = _make_llm_response(
            [
                {
                    "content": "Prefers tools that stay out of the way of thinking",
                    "node_type": "value",
                    "why": None,
                    "confidence": 0.7,
                    "depth": "identity",
                }
            ],
        )

        kkanbu_learn(insight="", conversation_text="I always prefer simple tools that don't distract")

        graph = get_graph()
        passive_nodes = [
            n for n in graph.get_all_by_type("value") if n["source"] == "passive"
        ]
        assert len(passive_nodes) >= 1, (
            "Learnings extracted from conversation_text must be stored with source='passive'"
        )

    def test_identity_summary_appears_in_result(self, llm_mock):
        """The LLM identity summary is reflected in the human-readable result text."""
        llm_mock.messages.create.return_value = _make_llm_response(
            [
                {
                    "content": "I ship iteratively, preferring small releases",
                    "node_type": "pattern",
                    "why": "Perfect is enemy of good",
                    "confidence": 0.88,
                    "depth": "identity",
                }
            ],
            identity_summary="A pragmatist who ships early and iterates rather than waiting for perfection",
        )

        raw = kkanbu_learn("I ship early and iterate", why="Perfect is enemy of done")
        data = json.loads(raw)

        assert "📍 Identity" in data["result"], "Result must contain identity summary section"
        assert "pragmatist" in data["result"].lower() or "perfect" in data["result"].lower(), (
            "Result must include the LLM-generated identity summary"
        )

    def test_insights_extracted_count_accurate(self, llm_mock):
        """insights_extracted in the response matches the number of nodes written."""
        llm_mock.messages.create.return_value = _make_llm_response(
            [
                {
                    "content": "I value open-source contributions",
                    "node_type": "value",
                    "why": None,
                    "confidence": 0.85,
                    "depth": "identity",
                },
                {
                    "content": "I contribute to open-source when I see a genuine gap",
                    "node_type": "pattern",
                    "why": "Contributing signals domain ownership",
                    "confidence": 0.8,
                    "depth": "identity",
                },
            ],
        )

        raw = kkanbu_learn("I value open-source contributions")
        data = json.loads(raw)

        assert data["insights_extracted"] == 2, (
            f"insights_extracted must equal the number of learnings written. "
            f"Got: {data['insights_extracted']}"
        )

    def test_llm_failure_falls_back_without_exception(self, llm_mock):
        """When Opus API call fails, kkanbu_learn returns a fallback result, not an exception."""
        llm_mock.messages.create.side_effect = Exception("API timeout")

        # Must not raise — deterministic fallback should kick in
        raw = kkanbu_learn("I prefer TDD", why="Drives design decisions")
        data = json.loads(raw)

        assert "result" in data, "Even on LLM failure, response must contain 'result'"
        assert "TDD" in data["result"] or "tdd" in data["result"].lower(), (
            "Fallback result must reference the original insight"
        )

        graph = get_graph()
        assert len(graph.search_nodes("TDD")) >= 1, (
            "Deterministic fallback must persist at least one node to the graph"
        )

    def test_session_id_returned_on_first_call(self, llm_mock):
        """First call creates a session and returns a non-empty session_id."""
        llm_mock.messages.create.return_value = _make_llm_response(
            [
                {
                    "content": "I value elegant code",
                    "node_type": "value",
                    "why": None,
                    "confidence": 0.9,
                    "depth": "identity",
                }
            ],
        )

        raw = kkanbu_learn("I value elegant code")
        data = json.loads(raw)

        assert data["session_id"], "session_id must be non-empty on first call"
        assert data["is_new_session"] is True, "First call must return is_new_session=True"
        assert data["turn"] == 1, "First call must be turn 1"

    def test_full_pipeline_nodes_and_edges_in_graph(self, llm_mock):
        """After a full teach pipeline, both nodes and edges appear in the knowledge graph.

        Seeds the graph first (for edge inference to have existing nodes), then runs
        a second teach that produces both explicit LLM-specified edges AND edge inference.
        """
        # Seed graph
        teach_resp1 = _make_llm_response(
            [
                {
                    "content": "I value code clarity",
                    "node_type": "value",
                    "why": None,
                    "confidence": 0.9,
                    "depth": "identity",
                }
            ],
        )

        # Second teach: explicit edge + edge inference will fire
        graph = get_graph()
        existing_id_holder: list = []  # capture via closure after first teach

        def side_effect_teach(**kwargs):
            # First call: extract learnings response
            if llm_mock.messages.create.call_count <= 1:
                return teach_resp1
            # Second teach extraction call (call 2)
            # capture existing nodes for assertion
            existing = graph.get_full_dump()["nodes"]
            existing_id_holder.extend([n["node_id"] for n in existing])

            seed_id = existing_id_holder[0] if existing_id_holder else None
            return _make_llm_response(
                learnings=[
                    {
                        "content": "I prefer functional style for clarity",
                        "node_type": "preference",
                        "why": "Functional code reads as a sequence of transformations",
                        "confidence": 0.87,
                        "depth": "identity",
                    }
                ],
                connections=(
                    [
                        {
                            "learning_index": 0,
                            "to_node_id": seed_id,
                            "relation_type": "supports",
                            "context": "Functional style supports code clarity value",
                        }
                    ]
                    if seed_id else []
                ),
            )

        # Edge inference response (third call)
        edge_inference_resp = MagicMock()
        edge_inference_resp.content = [MagicMock(text=json.dumps({
            "edges": [],
            "inference_notes": "No additional edges needed",
        }))]

        llm_mock.messages.create.side_effect = [
            teach_resp1,                # first teach extraction
            side_effect_teach,          # placeholder — override below
            edge_inference_resp,        # edge inference after second teach
        ]

        def flexible_side_effect(**kwargs):
            count = llm_mock.messages.create.call_count
            if count == 1:
                return teach_resp1
            elif count == 2:
                return side_effect_teach(**kwargs)
            else:
                return edge_inference_resp

        llm_mock.messages.create.side_effect = flexible_side_effect

        kkanbu_learn("I value code clarity")
        kkanbu_learn("I prefer functional style for clarity")

        graph2 = get_graph()
        stats = graph2.get_stats()
        assert stats["nodes"] >= 2, "Both teach calls must persist nodes to the graph"
        # At least one edge should exist (either explicit or inferred)
        assert stats["edges"] >= 1, "At least one edge must be written to the graph"


# ── Sub-AC 8c: kkanbu_curious end-to-end LLM pipeline ────────────────────────


class TestSubAC8cCuriousEndToEndPipeline:
    """End-to-end pipeline validation for kkanbu_curious (Sub-AC 8c).

    Verifies that the full pipeline — full graph dump as context, Opus call,
    quality-gate filtering, session-state management, and stateful multi-turn
    follow-ups — executes without errors and each stage produces the expected
    output, with surprising contextual questions generated via claude-opus-4-6.

    Coverage map:
    ┌─────────────────────────────────────────────────────────────────────┐
    │  fresh call  → format_graph_for_llm() (full graph dump)            │
    │             → _build_fresh_session_prompt()                        │
    │             → Opus [claude-opus-4-6] with _CURIOUS_SYSTEM_PROMPT   │
    │             → quality gate (depth_level, surface patterns,         │
    │               novelty_rationale length, grounded_in length)        │
    │             → session state written (thread_topic, history)        │
    │             → JSON response {session_id, message, depth_level, …}  │
    │                                                                     │
    │  follow-up  → _build_continuing_session_messages()                 │
    │             → Opus [claude-opus-4-6] with full history             │
    │             → session state updated (thread_topic preserved)       │
    │             → JSON response {turn += 1, is_new_session=False, …}   │
    └─────────────────────────────────────────────────────────────────────┘
    """

    @pytest.fixture(autouse=True)
    def clear_sessions(self):
        """Clear session state before/after each test."""
        _session_store._sessions.clear()
        yield
        _session_store._sessions.clear()

    # ── 1. Basic pipeline execution ──────────────────────────────────────────

    def test_full_pipeline_executes_without_error(self, llm_mock):
        """Complete pipeline from first call to JSON response runs without exceptions."""
        llm_mock.messages.create.return_value = _make_curious_llm_response()

        # Must not raise
        raw = kkanbu_curious()
        data = json.loads(raw)  # Must be valid JSON
        assert data  # Non-empty

    def test_response_json_contains_all_required_fields(self, llm_mock):
        """The JSON response always contains every required curious field."""
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question="What conviction about software design do you hold more strongly than anyone you work with?",
            depth_level="identity",
            novelty_rationale=(
                "Probes the tension between collaborative norms and personal conviction — "
                "an identity-level gap not surfaced by any existing node."
            ),
        )

        raw = kkanbu_curious()
        data = json.loads(raw)

        required_fields = {
            "type",
            "session_id",
            "is_new_session",
            "message",
            "gap_identified",
            "grounded_in",
            "thread_topic",
            "depth_level",
            "novelty_rationale",
            "rejected_alternatives",
            "turn",
            "distillation_written",
            "distillation_learnings",
        }
        for field_name in required_fields:
            assert field_name in data, f"Required field '{field_name}' missing from curious response"

        assert data["type"] == "curiosity"
        assert data["is_new_session"] is True
        assert data["turn"] == 1
        assert data["session_id"] != ""

    # ── 2. Model enforcement ─────────────────────────────────────────────────

    def test_always_uses_opus_model(self, llm_mock):
        """kkanbu_curious always calls claude-opus-4-6, never a cheaper model."""
        llm_mock.messages.create.return_value = _make_curious_llm_response()

        kkanbu_curious()

        call_kwargs = llm_mock.messages.create.call_args.kwargs
        assert call_kwargs.get("model") == "claude-opus-4-6", (
            "kkanbu_curious must always use claude-opus-4-6 (no cost-optimisation)"
        )

    # ── 3. System prompt validation ──────────────────────────────────────────

    def test_system_prompt_encodes_surprise_and_depth_directives(self, llm_mock):
        """Surprise criteria and depth ladder are encoded in the system prompt sent to Opus."""
        llm_mock.messages.create.return_value = _make_curious_llm_response()

        kkanbu_curious()

        call_kwargs = llm_mock.messages.create.call_args.kwargs
        system = call_kwargs.get("system", "")

        # Depth ladder must be present
        assert "surface" in system.lower() and "identity" in system.lower(), (
            "System prompt must encode depth ladder (surface → identity → formative)"
        )
        assert "formative" in system.lower(), (
            "System prompt must reference 'formative' depth level"
        )
        # Surprise criteria must be present
        assert "surprise" in system.lower() or "surprising" in system.lower(), (
            "System prompt must encode surprise criteria"
        )
        # Forbidden question types must be called out
        assert "forbidden" in system.lower() or "forbidden question" in system.lower(), (
            "System prompt must list forbidden question types"
        )

    def test_system_prompt_requires_json_output(self, llm_mock):
        """The system prompt instructs Opus to respond with JSON only."""
        llm_mock.messages.create.return_value = _make_curious_llm_response()

        kkanbu_curious()

        call_kwargs = llm_mock.messages.create.call_args.kwargs
        system = call_kwargs.get("system", "")

        assert "json" in system.lower(), (
            "System prompt must require JSON output from Opus"
        )
        assert "question" in system.lower(), (
            "System prompt must name the 'question' field in the JSON schema"
        )

    # ── 4. Graph context ─────────────────────────────────────────────────────

    def test_full_graph_context_passed_to_opus(self, llm_mock):
        """kkanbu_curious passes the full knowledge graph dump as context to Opus."""
        # Seed the graph with a preference node
        teach_resp = _make_llm_response(
            [
                {
                    "content": "I build for resilience over performance optimisation",
                    "node_type": "value",
                    "why": "Systems that fail gracefully are more trustworthy than fast ones",
                    "confidence": 0.9,
                    "depth": "identity",
                }
            ],
        )
        curious_resp = _make_curious_llm_response(
            question=(
                "When resilience and performance were genuinely at odds — which did you choose, "
                "and what did that reveal about what you value most?"
            ),
            grounded_in="Node: 'I build for resilience over performance optimisation'",
        )
        llm_mock.messages.create.side_effect = [teach_resp, curious_resp]

        kkanbu_learn("I build for resilience over performance optimisation")
        kkanbu_curious()

        # Inspect the curious Opus call (second call)
        last_call = llm_mock.messages.create.call_args_list[-1]
        kwargs = last_call.kwargs if last_call.kwargs else last_call[1]
        messages = kwargs.get("messages", [])

        # The first user message must contain the graph context header
        first_msg = messages[0]["content"] if messages else ""
        assert (
            "KKANBU KNOWLEDGE GRAPH" in first_msg
            or "knowledge graph" in first_msg.lower()
        ), "Full graph context must be passed to Opus as the first user message"
        # Seeded node content must be visible in the context
        assert "resilience" in first_msg.lower(), (
            "Graph node content must appear in the context passed to Opus"
        )

    def test_graph_context_present_even_with_empty_graph(self, llm_mock):
        """Even an empty graph produces a context block in the Opus call."""
        llm_mock.messages.create.return_value = _make_curious_llm_response()

        kkanbu_curious()

        call_kwargs = llm_mock.messages.create.call_args.kwargs
        messages = call_kwargs.get("messages", [])
        first_msg = messages[0]["content"] if messages else ""

        # Context header must always be present
        assert (
            "KKANBU KNOWLEDGE GRAPH" in first_msg
            or "graph" in first_msg.lower()
            or "knowledge" in first_msg.lower()
        ), "Context block must always be present in the first Opus message"

    # ── 5. Stateful session management ───────────────────────────────────────

    def test_session_state_maintained_across_follow_ups(self, llm_mock):
        """Session ID from first call is valid for follow-up calls with preserved state."""
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(
                question="What belief about reliability have you never had to articulate before?",
                thread_topic="reliability belief",
            ),
            _make_curious_llm_response(
                question="And where does that belief come from — was there a moment it crystallised?",
                thread_topic="reliability belief",
            ),
        ]

        # First call — generates session_id
        raw1 = kkanbu_curious()
        data1 = json.loads(raw1)
        sid = data1["session_id"]

        assert data1["is_new_session"] is True
        assert data1["turn"] == 1
        assert sid in _session_store, "Session must be stored server-side after first call"

        # Follow-up call — same session, with user response
        raw2 = kkanbu_curious(
            session_id=sid,
            user_response="I believe systems should fail loudly rather than silently.",
        )
        data2 = json.loads(raw2)

        assert data2["session_id"] == sid, "Same session_id must be returned on follow-up"
        assert data2["is_new_session"] is False, "Follow-up must report is_new_session=False"
        assert data2["turn"] == 2, "Turn counter must increment on each follow-up"
        assert data2["message"] != data1["message"], "Follow-up must produce a different question"

    def test_multi_turn_conversation_accumulates_turns(self, llm_mock):
        """Three calls on the same session produce turn counts 1, 2, and 3 respectively.

        Turn 2 and turn 3 each carry a user_response with identity-depth replies,
        which triggers _maybe_distill_curious_exchange() after each curious Opus call.
        The side_effect list must therefore include a distillation response between
        each pair of consecutive curious responses.
        """
        q1_resp = _make_curious_llm_response(
            question="What principle guides how you choose between two equally good designs?",
            thread_topic="design principle",
        )
        q2_resp = _make_curious_llm_response(
            question="Where did that principle come from — was it taught or discovered?",
            thread_topic="design principle",
        )
        distill_resp_1 = _make_distillation_response(
            [{"content": "Defaults to simpler design when options are equal",
              "node_type": "pattern", "why": None, "confidence": 0.85,
              "depth": "identity", "upsert_node_id": None}],
        )
        q3_resp = _make_curious_llm_response(
            question="Has that principle ever led you to a decision you later regretted?",
            thread_topic="design principle",
        )
        distill_resp_2 = _make_distillation_response(
            [{"content": "Simplicity preference was discovered through over-engineering pain",
              "node_type": "formative", "why": None, "confidence": 0.9,
              "depth": "formative", "upsert_node_id": None}],
        )
        # Order: curious-1, curious-2, distil-2, curious-3, distil-3
        llm_mock.messages.create.side_effect = [
            q1_resp, q2_resp, distill_resp_1, q3_resp, distill_resp_2,
        ]

        r1 = json.loads(kkanbu_curious())
        sid = r1["session_id"]
        assert r1["turn"] == 1

        r2 = json.loads(kkanbu_curious(sid, "I always choose the simpler option, even if it's less powerful."))
        assert r2["turn"] == 2

        r3 = json.loads(kkanbu_curious(sid, "It was discovered — through painful over-engineering."))
        assert r3["turn"] == 3

    def test_thread_topic_preserved_in_continuing_session(self, llm_mock):
        """The thread_topic established on turn 1 persists through the follow-up."""
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(
                question="What does 'good enough' mean to you in production software?",
                thread_topic="quality threshold",
            ),
            _make_curious_llm_response(
                question="When you've shipped 'good enough' — what did that feel like?",
                thread_topic="quality threshold",
            ),
        ]

        r1 = json.loads(kkanbu_curious())
        sid = r1["session_id"]
        assert r1["thread_topic"] == "quality threshold"

        r2 = json.loads(kkanbu_curious(sid, "Good enough means no user-visible failures and acceptable tech debt."))
        # Thread topic preserved or deepened — not scattered to a new area
        assert r2["thread_topic"] == "quality threshold", (
            "Follow-up must preserve the established thread_topic"
        )

    def test_follow_up_messages_include_full_session_history(self, llm_mock):
        """Multi-turn Opus call receives the full conversation history, not just the latest turn.

        After the first curious call, the follow-up call builds a multi-turn message
        list via _build_continuing_session_messages().  We inspect call_args_list[0]
        (the curious Opus call) rather than call_args (the last call) because when
        user_response is present and depth_level ∈ _CURIOUS_MIN_DEPTH,
        _maybe_distill_curious_exchange() fires a second Opus call for distillation
        immediately after — making call_args point at the single-message distillation
        request rather than the multi-turn curious request.
        """
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(
                question="What does 'done' mean to you in a software project?",
                thread_topic="completion definition",
            ),
            _make_curious_llm_response(
                question="And when a project felt truly done — what made it feel that way?",
                thread_topic="completion definition",
            ),
        ]

        r1 = json.loads(kkanbu_curious())
        sid = r1["session_id"]

        # Reset mock so we can isolate and inspect the follow-up call's arguments.
        # We must also supply a distillation response (second slot) because the
        # follow-up with user_response + identity depth triggers eager distillation.
        llm_mock.messages.create.reset_mock()
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(
                question="And when a project felt truly done — what made it feel that way?",
                thread_topic="completion definition",
            ),
            _make_distillation_response(
                [{"content": "Done means no open tickets and users actively using it",
                  "node_type": "value", "why": None, "confidence": 0.85,
                  "depth": "value", "upsert_node_id": None}],
            ),
        ]

        kkanbu_curious(sid, "Done means no open tickets and users are using it.")

        # call_args_list[0] is the curious Opus call (multi-turn messages).
        # call_args_list[1] (if present) is the distillation call (single-message).
        assert llm_mock.messages.create.call_count >= 1, "Opus must be called at least once"
        curious_call = llm_mock.messages.create.call_args_list[0]
        call_kwargs = curious_call.kwargs if curious_call.kwargs else curious_call[1]
        messages = call_kwargs.get("messages", [])
        assert len(messages) >= 2, (
            "Follow-up call must pass multi-turn message history to Opus, not just a single message"
        )

    def test_independent_sessions_have_isolated_state(self, llm_mock):
        """Two concurrent sessions don't share conversation state."""
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(
                question="What tension between craft and pragmatism do you live with daily?",
                thread_topic="craft pragmatism",
            ),
            _make_curious_llm_response(
                question="What does ownership mean to you outside of code?",
                thread_topic="ownership meaning",
            ),
        ]

        r_a = json.loads(kkanbu_curious())
        r_b = json.loads(kkanbu_curious())

        sid_a = r_a["session_id"]
        sid_b = r_b["session_id"]

        assert sid_a != sid_b, "Each call without session_id must create a distinct session"
        assert sid_a in _session_store
        assert sid_b in _session_store

        sess_a = _session_store.get(sid_a)
        sess_b = _session_store.get(sid_b)
        # Sessions are isolated — different question lists
        assert sess_a.questions_asked != sess_b.questions_asked or (
            r_a["message"] != r_b["message"]
        ), "Independent sessions must have isolated question histories"

    # ── 6. Quality gate ──────────────────────────────────────────────────────

    def test_quality_gate_retries_on_surface_depth(self, llm_mock):
        """When Opus returns depth_level='surface', a retry is triggered automatically."""
        surface_resp = _make_curious_llm_response(
            question="What tools do you use for testing?",
            depth_level="surface",
            novelty_rationale="Short rationale that is at least twenty chars",
            grounded_in="Some specific nodes referenced here",
        )
        deep_resp = _make_curious_llm_response(
            question=(
                "When you realised your instinct for minimal tooling was actually a philosophical stance — "
                "what were you doing?"
            ),
            depth_level="identity",
            novelty_rationale=(
                "Surfaces the identity-level belief beneath a surface tool preference — "
                "connects scattered preference nodes to a coherent worldview."
            ),
            grounded_in="Node: 'I prefer minimal tooling', Node: 'I value clarity over cleverness'",
        )
        llm_mock.messages.create.side_effect = [surface_resp, deep_resp]

        raw = kkanbu_curious()
        data = json.loads(raw)

        # Retry must have been triggered; two LLM calls made
        assert llm_mock.messages.create.call_count == 2, (
            "Quality gate must trigger exactly one retry for depth_level='surface'"
        )
        # Final result is from the retry
        assert data["message"] == deep_resp.content[0].text and False or data["depth_level"] in (
            "surface", "preference", "value", "identity", "formative"
        ), "Response must include a valid depth_level after retry"

    def test_non_json_response_falls_back_gracefully(self, llm_mock):
        """When Opus returns non-JSON text, kkanbu_curious returns a valid fallback JSON."""
        non_json_mock = MagicMock()
        non_json_mock.content = [MagicMock(text="What shaped your instinct to simplify everything?")]
        llm_mock.messages.create.return_value = non_json_mock

        # Must not raise
        raw = kkanbu_curious()
        data = json.loads(raw)  # Must still be valid JSON

        assert data["type"] == "curiosity"
        assert data["message"] != ""
        assert data["depth_level"] == "unknown"

    def test_api_error_falls_back_gracefully(self, llm_mock):
        """When Opus API call raises, kkanbu_curious returns a valid fallback JSON, not an exception."""
        llm_mock.messages.create.side_effect = Exception("Service temporarily unavailable")

        # Must not raise
        raw = kkanbu_curious()
        data = json.loads(raw)  # Must be parseable

        assert data["type"] == "curiosity"
        assert data["message"]  # Non-empty fallback question
        assert data["session_id"]  # Still has a session_id
        assert data["depth_level"] == "unknown"

    # ── 7. New-session handshake ─────────────────────────────────────────────

    def test_new_session_has_is_new_session_true(self, llm_mock):
        """First call sets is_new_session=True in the response."""
        llm_mock.messages.create.return_value = _make_curious_llm_response()
        data = json.loads(kkanbu_curious())
        assert data["is_new_session"] is True

    def test_continuing_session_has_is_new_session_false(self, llm_mock):
        """Follow-up call on an existing session sets is_new_session=False."""
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(
                question="What does 'quality' mean to you when no one is watching?",
                thread_topic="intrinsic quality",
            ),
            _make_curious_llm_response(
                question="And where did that standard come from?",
                thread_topic="intrinsic quality",
            ),
        ]
        r1 = json.loads(kkanbu_curious())
        sid = r1["session_id"]

        r2 = json.loads(kkanbu_curious(sid, "Quality means I could explain every decision without shame."))
        assert r2["is_new_session"] is False

    def test_unknown_session_id_creates_new_session(self, llm_mock):
        """Passing an unknown session_id creates a new session rather than raising."""
        llm_mock.messages.create.return_value = _make_curious_llm_response()

        raw = kkanbu_curious(session_id="nonexistent-session-id-xyz")
        data = json.loads(raw)  # Must not raise

        assert data["type"] == "curiosity"
        assert data["session_id"]


class TestKkanbuTeach:
    def test_teach_stores_preference(self, llm_mock):
        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "I prefer functional programming", "node_type": "preference",
             "why": "Easier to reason about", "confidence": 0.9, "depth": "surface"},
            {"content": "Values code that is composable and easy to reason about",
             "node_type": "value", "why": None, "confidence": 0.85, "depth": "identity"},
        ], identity_summary="A developer who values reasoning clarity and functional approaches")

        result = kkanbu_learn("I prefer functional programming", why="Easier to reason about")
        assert "Learned" in result
        assert "functional programming" in result

    def test_teach_stores_why(self, llm_mock):
        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "I use SQLite for local storage", "node_type": "preference",
             "why": "No server needed, zero config", "confidence": 0.9, "depth": "surface"},
            {"content": "No server needed — zero config is a strong bias",
             "node_type": "reasoning", "why": None, "confidence": 0.85, "depth": "identity"},
        ])

        kkanbu_learn("I use SQLite for local storage", why="No server needed, zero config")
        graph = get_graph()
        nodes = graph.search_nodes("SQLite")
        assert len(nodes) >= 1
        # The why reasoning is captured either in node.why or as a separate reasoning node
        sqlite_node = nodes[0]
        has_why = (
            (sqlite_node.get("why") and "server" in sqlite_node["why"].lower())
            or len(graph.search_nodes("server needed")) >= 1
        )
        assert has_why, "Why reasoning about 'server needed' should be captured"

    def test_teach_stores_multiple_learnings(self, llm_mock):
        """LLM extracts multiple identity-level learnings from a single teaching."""
        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "I prefer Python", "node_type": "preference",
             "why": None, "confidence": 0.9, "depth": "surface"},
            {"content": "Values readable, expressive language design",
             "node_type": "value", "why": None, "confidence": 0.85, "depth": "identity"},
            {"content": "Favours ecosystem breadth over performance optimization",
             "node_type": "pattern", "why": None, "confidence": 0.8, "depth": "identity"},
        ], identity_summary="Pragmatic developer who prioritises readability and ecosystem")

        result = kkanbu_learn("I prefer Python", why="Readable and productive")
        assert "Learned" in result
        graph = get_graph()
        stats = graph.get_stats()
        assert stats["nodes"] >= 2  # At minimum the preference + value

    def test_teach_connects_related_knowledge(self, llm_mock):
        """LLM identifies connections between new knowledge and existing graph nodes."""
        # First teach — no existing graph
        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "I prefer Python", "node_type": "preference",
             "why": None, "confidence": 0.9, "depth": "surface"},
        ])
        kkanbu_learn("I prefer Python")

        # Second teach — LLM references the existing Python node
        graph = get_graph()
        python_nodes = graph.search_nodes("Python")
        existing_id = python_nodes[0]["node_id"] if python_nodes else ""

        llm_mock.messages.create.return_value = _make_llm_response(
            learnings=[
                {"content": "I use type hints in Python", "node_type": "preference",
                 "why": "Better IDE support", "confidence": 0.9, "depth": "surface"},
            ],
            connections=[
                {"learning_index": 0, "to_node_id": existing_id,
                 "relation_type": "supports", "context": "Python type hints relate to Python preference"},
            ] if existing_id else [],
        )
        result = kkanbu_learn("I use type hints in Python", why="Better IDE support")
        # The result should show learnings were stored
        assert "Learned" in result
        assert "type hints" in result

    def test_teach_different_categories(self, llm_mock):
        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "Speed matters", "node_type": "value",
             "why": None, "confidence": 0.85, "depth": "identity"},
        ])
        kkanbu_learn("Speed matters", category="value")

        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "Always write tests first", "node_type": "pattern",
             "why": None, "confidence": 0.85, "depth": "identity"},
        ])
        kkanbu_learn("Always write tests first", category="pattern")

        graph = get_graph()
        values = graph.get_all_by_type("value")
        patterns = graph.get_all_by_type("pattern")
        assert len(values) >= 1
        assert len(patterns) >= 1

    def test_teach_identity_summary_in_result(self, llm_mock):
        """Result includes the LLM's identity summary when present."""
        llm_mock.messages.create.return_value = _make_llm_response(
            learnings=[
                {"content": "I prefer immutable data structures", "node_type": "preference",
                 "why": None, "confidence": 0.9, "depth": "surface"},
            ],
            identity_summary="A developer who values predictability through immutability",
        )
        raw = kkanbu_learn("I prefer immutable data structures")
        result_data = json.loads(raw)
        result_text = result_data["result"]
        assert "📍 Identity" in result_text
        assert "immutability" in result_text

    def test_teach_conversation_text_uses_passive_source(self, llm_mock):
        """Conversation text is stored with source='passive'."""
        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "Prefers simple tools that are easy to debug",
             "node_type": "preference", "why": None, "confidence": 0.65, "depth": "surface"},
        ])
        kkanbu_learn(insight="", conversation_text="I always prefer simple tools")
        graph = get_graph()
        passive_nodes = [n for n in graph.get_all_by_type("preference") if n["source"] == "passive"]
        assert len(passive_nodes) >= 1

    def test_teach_llm_failure_falls_back_to_deterministic(self):
        """When LLM raises an exception, deterministic fallback is used."""
        with patch("kkanbu.server.anthropic.Anthropic") as mock_cls:
            mock_client = MagicMock()
            mock_cls.return_value = mock_client
            mock_client.messages.create.side_effect = Exception("API unavailable")

            result = kkanbu_learn("I prefer TDD", why="Drives design decisions")
            # Fallback result has the original insight
            assert "TDD" in result
            # Node should still be stored
            graph = get_graph()
            assert len(graph.search_nodes("TDD")) >= 1

    def test_teach_empty_input_returns_error(self):
        result = kkanbu_learn(insight="", conversation_text="")
        assert "Nothing to learn" in result

    def test_teach_edge_inference_skipped_on_empty_graph(self, llm_mock):
        """Edge inference is skipped when there are no pre-existing nodes."""
        call_count = [0]

        def side_effect(**kwargs):
            call_count[0] += 1
            return _make_llm_response([
                {"content": "I prefer minimalism", "node_type": "value",
                 "why": None, "confidence": 0.9, "depth": "identity"},
            ])

        llm_mock.messages.create.side_effect = side_effect

        result = kkanbu_learn("I prefer minimalism")
        assert "Learned" in result
        # Only ONE LLM call should have been made (extract only, no edge inference)
        assert call_count[0] == 1, (
            "Edge inference should be skipped when the graph is empty before teaching"
        )

    def test_teach_edge_inference_failure_does_not_break_teach(self, llm_mock):
        """Edge inference failure is non-blocking — teach still succeeds."""
        # Seed graph
        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "I value clean code", "node_type": "value",
             "why": None, "confidence": 0.9, "depth": "identity"},
        ])
        kkanbu_learn("I value clean code")

        # Second teach: extract succeeds, edge inference raises
        call_count_inner = [0]

        def side_effect(**kwargs):
            call_count_inner[0] += 1
            if call_count_inner[0] == 1:
                return _make_llm_response([
                    {"content": "I refactor aggressively", "node_type": "pattern",
                     "why": None, "confidence": 0.85, "depth": "identity"},
                ])
            else:
                raise Exception("Edge inference API timeout")

        llm_mock.messages.create.side_effect = side_effect

        result = kkanbu_learn("I refactor aggressively")
        # Should still return success — edge inference failure is non-blocking
        assert "Learned" in result
        assert "refactor" in result

    def test_infer_edges_for_new_nodes_validates_node_ids(self, llm_mock):
        """_infer_edges_for_new_nodes only writes edges with valid from/to IDs."""
        from kkanbu.server import _infer_edges_for_new_nodes

        graph = get_graph()
        # Create two real nodes
        nid1 = graph.add_node("value", "I value clarity", "teach", confidence=0.9)
        nid2 = graph.add_node("preference", "I prefer clear naming", "teach", confidence=0.8)

        # Mock edge inference returning: one valid edge + two invalid ones
        llm_mock.messages.create.return_value = MagicMock(
            content=[MagicMock(text=json.dumps({
                "edges": [
                    {   # VALID: from new node → existing (pre-existing) node
                        "from_new_node_id": nid1,
                        "to_existing_node_id": nid2,
                        "relation_type": "generalizes",
                        "weight": 0.7,
                        "context": "Clarity value generalizes clear naming preference",
                    },
                    {   # INVALID: from_id not in new_node_ids
                        "from_new_node_id": "doesnotexist",
                        "to_existing_node_id": nid2,
                        "relation_type": "supports",
                        "weight": 0.5,
                        "context": "Invalid edge — from node not in new set",
                    },
                    {   # INVALID: to_id not in pre_existing_ids
                        "from_new_node_id": nid1,
                        "to_existing_node_id": "alsonotexist",
                        "relation_type": "supports",
                        "weight": 0.5,
                        "context": "Invalid edge — to node not pre-existing",
                    },
                ],
                "inference_notes": "Test validation",
            }))]
        )

        count = _infer_edges_for_new_nodes(
            graph=graph,
            new_node_ids=[nid1],          # only nid1 is "new"
            pre_existing_ids={nid2},       # nid2 is "pre-existing"
        )
        assert count == 1  # Only the valid edge should be written
        edges = graph.get_edges_from(nid1)
        assert len(edges) == 1
        assert edges[0]["relation_type"] == "generalizes"
        assert "[edge-inference]" in edges[0]["context"]

    def test_infer_edges_normalises_invalid_relation_type(self, llm_mock):
        """Unknown relation types fall back to 'supports'."""
        from kkanbu.server import _infer_edges_for_new_nodes

        graph = get_graph()
        nid1 = graph.add_node("value", "I value speed", "teach", confidence=0.9)
        nid2 = graph.add_node("pattern", "I benchmark everything", "teach", confidence=0.8)

        llm_mock.messages.create.return_value = MagicMock(
            content=[MagicMock(text=json.dumps({
                "edges": [
                    {
                        "from_new_node_id": nid1,
                        "to_existing_node_id": nid2,
                        "relation_type": "unknown_type",
                        "weight": 0.6,
                        "context": "Speed value motivates benchmarking pattern",
                    }
                ],
                "inference_notes": "Speed value motivates measurement",
            }))]
        )

        count = _infer_edges_for_new_nodes(
            graph=graph,
            new_node_ids=[nid1],
            pre_existing_ids={nid2},
        )
        assert count == 1
        edge = graph.get_edges_from(nid1)[0]
        assert edge["relation_type"] == "supports"  # normalised from unknown_type

    def test_infer_edges_clamps_weight(self, llm_mock):
        """Edge weights outside [0.1, 1.0] are clamped."""
        from kkanbu.server import _infer_edges_for_new_nodes

        graph = get_graph()
        nid1 = graph.add_node("value", "I value flow", "teach", confidence=0.9)
        nid2 = graph.add_node("pattern", "I block calendar", "teach", confidence=0.8)

        llm_mock.messages.create.return_value = MagicMock(
            content=[MagicMock(text=json.dumps({
                "edges": [
                    {
                        "from_new_node_id": nid1,
                        "to_existing_node_id": nid2,
                        "relation_type": "supports",
                        "weight": 999.0,  # out of range
                        "context": "Flow state value supports calendar blocking",
                    }
                ],
                "inference_notes": "Flow state motivates blocking",
            }))]
        )

        count = _infer_edges_for_new_nodes(
            graph=graph,
            new_node_ids=[nid1],
            pre_existing_ids={nid2},
        )
        assert count == 1
        edge = graph.get_edges_from(nid1)[0]
        assert edge["weight"] <= 1.0  # clamped to max

    def test_teach_result_shows_inferred_edge_count(self, llm_mock):
        """When edges are inferred, the result shows the 🔗 count line."""
        # Seed graph with an existing node
        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "I value pragmatism", "node_type": "value",
             "why": None, "confidence": 0.9, "depth": "identity"},
        ])
        kkanbu_learn("I value pragmatism")

        graph = get_graph()
        existing_nodes = graph.search_nodes("pragmatism")
        existing_id = existing_nodes[0]["node_id"] if existing_nodes else ""

        if not existing_id:
            return  # Can't test without an existing node

        call_count_inner = [0]

        def side_effect(**kwargs):
            call_count_inner[0] += 1
            if call_count_inner[0] == 1:
                # Extract learnings
                return _make_llm_response([
                    {"content": "I ship early and iterate", "node_type": "pattern",
                     "why": "Perfect is the enemy of done", "confidence": 0.85,
                     "depth": "identity"},
                ])
            else:
                # Edge inference — extract the real new node ID from prompt
                user_content = kwargs.get("messages", [{}])[0].get("content", "")
                import re as _re
                match = _re.search(r"\[([a-f0-9]{12})\]", user_content)
                new_id = match.group(1) if match else "dummy"
                resp = MagicMock()
                resp.content = [MagicMock(text=json.dumps({
                    "edges": [
                        {
                            "from_new_node_id": new_id,
                            "to_existing_node_id": existing_id,
                            "relation_type": "exemplifies",
                            "weight": 0.8,
                            "context": "Shipping early exemplifies pragmatism",
                        }
                    ] if new_id != "dummy" else [],
                    "inference_notes": "Ship-early pattern exemplifies pragmatism value",
                }))]
                return resp

        llm_mock.messages.create.side_effect = side_effect

        result = kkanbu_learn("I ship early and iterate", why="Perfect is enemy of done")
        assert "Learned" in result
        # When edges are inferred, result should mention it
        assert "🔗" in result or "semantic edge" in result


class TestKkanbuIngest:
    def test_ingest_python_project(self, tmp_path):
        # Create a minimal Python project
        (tmp_path / "pyproject.toml").write_text('[build-system]\nrequires = ["hatchling"]\n')
        (tmp_path / "src").mkdir()
        (tmp_path / "tests").mkdir()
        (tmp_path / "src" / "main.py").write_text('def hello() -> str:\n    """Say hello."""\n    return "hi"\n')
        (tmp_path / ".gitignore").write_text("__pycache__\n")

        result = kkanbu_ingest(str(tmp_path))
        assert "Ingested" in result
        assert "pattern" in result.lower() or "preference" in result.lower()

    def test_ingest_nonexistent_path(self):
        result = kkanbu_ingest("/nonexistent/path")
        assert "Error" in result


class TestFlagging:
    def test_flag_and_retrieve(self):
        _flag_question("What's your API style?", "REST probably", 0.3)
        flags = kkanbu_get_flags()
        assert "API style" in flags
        assert "REST" in flags
        assert "0.30" in flags

    def test_no_flags_returns_clean_message(self):
        flags = kkanbu_get_flags()
        assert "No flagged" in flags

    def test_multiple_flags(self):
        _flag_question("Q1?", "Guess1", 0.2)
        _flag_question("Q2?", "Guess2", 0.3)
        flags = kkanbu_get_flags()
        assert "2 flagged" in flags


class TestConversation:
    def test_start_conversation_no_flags(self):
        result = json.loads(kkanbu_resolve_flag())
        assert result["type"] == "question"
        assert "session_id" in result

    def test_start_conversation_with_flags(self):
        _flag_question("What editor?", "VS Code", 0.3)
        result = json.loads(kkanbu_resolve_flag())
        assert "editor" in result["message"].lower() or "VS Code" in result["message"]
        assert result.get("flag_node_id")

    def test_respond_to_conversation(self):
        _flag_question("What editor?", "VS Code", 0.3)
        start = json.loads(kkanbu_resolve_flag())
        response = json.loads(
            kkanbu_resolve_flag(
                user_response="I prefer Neovim because I value keyboard-driven workflows",
                session_id=start["session_id"],
            )
        )
        assert response["learnings_stored"] > 0



class TestCorrections:
    def test_correction_stored(self, llm_mock):
        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "I prefer tabs for indentation", "node_type": "preference",
             "why": None, "confidence": 0.9, "depth": "surface"},
        ])
        kkanbu_learn("I prefer tabs for indentation")
        result = kkanbu_correct(
            "tabs for indentation",
            "I actually prefer spaces (4 spaces)",
            why="Consistent rendering across all editors"
        )
        assert "Correction recorded" in result
        assert "Updated" in result

    def test_correction_lowers_original_confidence(self, llm_mock):
        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "I like Java", "node_type": "preference",
             "why": "Enterprise ready", "confidence": 0.9, "depth": "surface"},
        ])
        kkanbu_learn("I like Java", why="Enterprise ready")
        kkanbu_correct("Java", "I actually prefer Kotlin", why="Less boilerplate")
        graph = get_graph()
        java_nodes = graph.search_nodes("Java")
        for n in java_nodes:
            if n["source"] == "teach":
                assert n["confidence"] < 0.9  # Should have been lowered



class TestStatus:
    def test_status_shows_stats(self, llm_mock):
        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "Test preference", "node_type": "preference",
             "why": None, "confidence": 0.9, "depth": "surface"},
        ])
        kkanbu_learn("Test preference")
        result = kkanbu_status()
        assert "Knowledge Graph Status" in result
        assert "Total nodes" in result


class TestKnowledgeGraphGrowth:
    """AC8: Knowledge graph captures WHY and connections."""

    def test_teach_captures_why(self, llm_mock):
        """LLM stores the why reasoning in node metadata or as a linked node."""
        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "I prefer small functions",
             "node_type": "preference",
             "why": "Each function should do one thing — easier to test and reason about",
             "confidence": 0.9, "depth": "surface"},
            {"content": "Each function should do one thing — single responsibility is a core belief",
             "node_type": "reasoning",
             "why": None, "confidence": 0.85, "depth": "identity"},
        ])
        kkanbu_learn(
            "I prefer small functions",
            why="Each function should do one thing — easier to test and reason about",
            category="preference",
        )
        graph = get_graph()
        # Should have the preference node
        prefs = graph.search_nodes("small functions")
        assert len(prefs) >= 1

        # The why reasoning should be captured — either in node.why or as a separate node
        pref_node = prefs[0]
        why_captured = (
            (pref_node.get("why") and "one thing" in pref_node["why"].lower())
            or len(graph.search_nodes("one thing")) >= 1
        )
        assert why_captured, "Why reasoning about 'one thing' should be captured in graph"

    def test_all_sources_write_to_graph(self, llm_mock):
        """AC8: teach, ingest, conversation, passive, correction all write."""
        graph = get_graph()

        # teach — LLM-powered
        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "teach insight", "node_type": "preference",
             "why": None, "confidence": 0.9, "depth": "surface"},
        ])
        kkanbu_learn("teach insight")

        # passive — via kkanbu_learn with conversation_text (source=passive)
        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "Prefers simple solutions", "node_type": "pattern",
             "why": None, "confidence": 0.65, "depth": "surface"},
        ])
        kkanbu_learn(insight="", conversation_text="I usually prefer simple solutions")

        # flag
        _flag_question("test q", "test guess", 0.3)

        # correction
        kkanbu_correct("old thing", "new thing", why="better")

        graph.get_stats()
        sources = set()
        for row in graph.conn.execute("SELECT DISTINCT source FROM nodes"):
            sources.add(row[0])

        assert "teach" in sources
        assert "passive" in sources
        assert "flag" in sources
        assert "correction" in sources


# ── TestKkanbuCurious ─────────────────────────────────────────

def _make_curious_llm_response(
    question: str = "What drives your preference for simplicity over cleverness?",
    gap_identified: str = "No explicit reflection on the tension between simplicity and power",
    grounded_in: str = "Nodes: 'I prefer simple solutions', 'I value clarity'",
    thread_topic: str = "simplicity tension",
    depth_level: str = "identity",
    novelty_rationale: str = (
        "Connects two unrelated graph areas — tool choices and personal philosophy — "
        "revealing an unarticulated belief about what software is for."
    ),
    rejected_alternatives: list | None = None,
) -> MagicMock:
    """Build a mock Opus response shaped for kkanbu_curious (including novelty schema)."""
    body = {
        "question": question,
        "gap_identified": gap_identified,
        "grounded_in": grounded_in,
        "thread_topic": thread_topic,
        "depth_level": depth_level,
        "novelty_rationale": novelty_rationale,
        "rejected_alternatives": rejected_alternatives or [
            "Do you prefer simple or complex tools?",
        ],
    }
    msg = MagicMock()
    msg.content = [MagicMock(text=json.dumps(body))]
    return msg


class TestKkanbuCurious:
    """AC4b: LLM-powered knowledge gap identification in kkanbu_curious."""

    @pytest.fixture(autouse=True)
    def clear_sessions(self):
        """Clear session state before each test."""
        _session_store._sessions.clear()
        yield
        _session_store._sessions.clear()

    def test_fresh_call_returns_json_with_required_fields(self, llm_mock):
        """kkanbu_curious returns valid JSON with all expected fields including novelty metadata."""
        llm_mock.messages.create.return_value = _make_curious_llm_response()
        result = kkanbu_curious()
        data = json.loads(result)

        assert data["type"] == "curiosity"
        assert "session_id" in data
        assert data["session_id"] != ""
        assert "message" in data
        assert data["message"] != ""
        assert "gap_identified" in data
        assert "grounded_in" in data
        assert "thread_topic" in data
        assert data["turn"] == 1
        # Novelty metadata fields (Sub-AC 4c)
        assert "depth_level" in data
        assert "novelty_rationale" in data
        assert "rejected_alternatives" in data
        assert isinstance(data["rejected_alternatives"], list)

    def test_fresh_call_uses_full_graph_dump(self, llm_mock):
        """kkanbu_curious passes the full graph context to Opus."""
        # Seed the graph with some knowledge
        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "I prefer pytest", "node_type": "preference",
             "why": "Simple syntax", "confidence": 0.9, "depth": "surface"},
        ])
        kkanbu_learn("I prefer pytest", why="Simple syntax")

        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question="You value simplicity in testing — does that extend to how you architect systems?",
            grounded_in="Node: 'I prefer pytest'",
        )
        result = kkanbu_curious()
        data = json.loads(result)

        # Verify Opus was called with the graph context in the messages
        call_args = llm_mock.messages.create.call_args
        assert call_args is not None
        messages = call_args.kwargs.get("messages") or call_args.args[0] if call_args.args else []
        if not messages:
            messages = call_args[1].get("messages", [])
        # The graph context should be in the first user message
        first_msg_content = messages[0]["content"] if messages else ""
        assert "KKANBU KNOWLEDGE GRAPH" in first_msg_content or "knowledge graph" in first_msg_content.lower()

        assert data["message"] != ""

    def test_session_id_returned_and_reusable(self, llm_mock):
        """The session_id from first call can be used for follow-up calls."""
        # Use side_effect to return different responses for each call
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(
                question="When did you first realize you cared more about simplicity than features?",
                thread_topic="simplicity identity",
            ),
            _make_curious_llm_response(
                question="And when complexity crept in despite that — what happened?",
                thread_topic="simplicity identity",
            ),
        ]

        # First call — no session_id
        result1 = kkanbu_curious()
        data1 = json.loads(result1)
        sid = data1["session_id"]
        assert sid in _session_store

        # Follow-up call — same session_id + user_response
        result2 = kkanbu_curious(session_id=sid, user_response="I learned to value simplicity early on.")
        data2 = json.loads(result2)

        assert data2["session_id"] == sid
        assert data2["turn"] == 2
        assert data2["message"] != data1["message"]

    def test_follow_up_passes_prior_context_to_opus(self, llm_mock):
        """Follow-up calls include conversation thread context in the Opus prompt."""
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question="What's the deepest why behind your preference for minimal dependencies?",
            thread_topic="dependency philosophy",
        )
        result1 = kkanbu_curious()
        data1 = json.loads(result1)
        sid = data1["session_id"]

        # Reset to capture the second call's arguments
        llm_mock.messages.create.reset_mock()
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question="Is it about control, or is it about something else entirely?",
            thread_topic="dependency philosophy",
        )
        kkanbu_curious(
            session_id=sid,
            user_response="I don't like depending on things I don't understand.",
        )

        # Sub-AC 9c: kkanbu_curious now makes an eager distillation LLM call when
        # a deep-depth question is generated after a user_response.  Use
        # call_args_list[0] (first call after reset) to inspect the question-gen
        # call rather than call_args (last call = distillation).
        call_args = llm_mock.messages.create.call_args_list[0]
        messages = call_args.kwargs.get("messages", [])
        if not messages:
            messages = call_args[1].get("messages", [])

        # With multi-turn messages approach:
        # messages[0] = initial context (graph + thread label + anti-repeat)
        # messages[1] = assistant turn Q1
        # messages[2] = user turn A1 + drill-deeper cue  ← user response lives here
        first_msg_content = messages[0]["content"] if messages else ""
        all_content = " ".join(m["content"] for m in messages)

        # Thread topic referenced in the initial context message
        assert "dependency philosophy" in first_msg_content or "thread" in first_msg_content.lower()
        # User response included somewhere in the messages (last user turn)
        assert "don't like depending" in all_content

    def test_session_history_grows_with_each_turn(self, llm_mock):
        """Session history accumulates assistant questions and user responses."""
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(question="First question here?"),
            _make_curious_llm_response(question="Second question here?"),
        ]
        result1 = kkanbu_curious()
        sid = json.loads(result1)["session_id"]

        kkanbu_curious(session_id=sid, user_response="That's a good question, I think...")

        session = _session_store.get(sid)
        assert session is not None
        history = session.history
        # Should have: [assistant turn 1, user response, assistant turn 2]
        assert len(history) >= 3
        roles = [m.role for m in history]
        assert "assistant" in roles
        assert "user" in roles

    def test_fallback_on_llm_failure(self, llm_mock):
        """kkanbu_curious returns a valid JSON response even when Opus fails."""
        llm_mock.messages.create.side_effect = Exception("API timeout")

        result = kkanbu_curious()
        data = json.loads(result)

        assert data["type"] == "curiosity"
        assert "session_id" in data
        assert data["message"] != ""
        assert "gap_identified" in data

    def test_fallback_on_non_json_opus_response(self, llm_mock):
        """kkanbu_curious handles a non-JSON Opus response gracefully."""
        non_json_msg = MagicMock()
        non_json_msg.content = [MagicMock(text="Why do you always reach for the simplest solution first?")]
        llm_mock.messages.create.return_value = non_json_msg

        result = kkanbu_curious()
        data = json.loads(result)

        assert data["type"] == "curiosity"
        assert "Why do you always" in data["message"]

    def test_uses_opus_model(self, llm_mock):
        """kkanbu_curious always calls claude-opus-4-6."""
        llm_mock.messages.create.return_value = _make_curious_llm_response()
        kkanbu_curious()

        call_kwargs = llm_mock.messages.create.call_args.kwargs
        assert call_kwargs.get("model") == "claude-opus-4-6"

    def test_new_session_on_empty_session_id(self, llm_mock):
        """Two calls without session_id create independent sessions."""
        llm_mock.messages.create.return_value = _make_curious_llm_response()
        r1 = json.loads(kkanbu_curious())
        r2 = json.loads(kkanbu_curious())

        assert r1["session_id"] != r2["session_id"]
        assert len(_session_store) == 2

    # ── Sub-AC 4c: Novelty criteria & quality guardrails ──────

    def test_quality_gate_retries_on_surface_depth_level(self, llm_mock):
        """When Opus returns depth_level='surface', a retry is triggered with a deeper question."""
        # First response: surface-level — should be rejected and trigger retry
        surface_response = _make_curious_llm_response(
            question="Do you prefer Python or JavaScript?",
            depth_level="surface",
            novelty_rationale="shallow",
        )
        # Retry response: deep — should be accepted
        deep_response = _make_curious_llm_response(
            question="What does your distrust of JavaScript reveal about what you believe software should fundamentally be?",
            depth_level="identity",
            novelty_rationale=(
                "Connects language choice (explicit) with a deeper belief about what makes "
                "software trustworthy — a connection the user hasn't articulated."
            ),
        )
        llm_mock.messages.create.side_effect = [surface_response, deep_response]

        result = kkanbu_curious()
        data = json.loads(result)

        # Should have called Opus twice (original + retry)
        assert llm_mock.messages.create.call_count == 2
        # Final question should be the deep one
        assert "distrust" in data["message"] or "believe" in data["message"]
        assert data["depth_level"] == "identity"

    def test_quality_gate_retries_on_preference_depth_level(self, llm_mock):
        """When Opus returns depth_level='preference', a retry is triggered."""
        preference_response = _make_curious_llm_response(
            question="What's your favorite testing library?",
            depth_level="preference",
            novelty_rationale="just a preference",
        )
        deeper_response = _make_curious_llm_response(
            question="When you insist on tests covering edge cases, what fear about software are you actually managing?",
            depth_level="identity",
            novelty_rationale=(
                "The graph shows strong testing habits but no exploration of the anxiety "
                "beneath them — connecting pattern to underlying value/fear."
            ),
        )
        llm_mock.messages.create.side_effect = [preference_response, deeper_response]

        result = kkanbu_curious()
        data = json.loads(result)

        assert llm_mock.messages.create.call_count == 2
        assert data["depth_level"] == "identity"

    def test_quality_gate_retries_when_novelty_rationale_too_short(self, llm_mock):
        """When novelty_rationale is too brief, a retry is triggered."""
        short_rationale_response = _make_curious_llm_response(
            question="Why do you value code clarity?",
            depth_level="value",
            novelty_rationale="it's interesting",  # Too short (< 20 chars)
        )
        better_response = _make_curious_llm_response(
            question="You say clarity matters — but is that about the code, or about not trusting future-you to remember what you were thinking?",
            depth_level="identity",
            novelty_rationale=(
                "Reframes a stated value (clarity) as a coping mechanism for cognitive limits, "
                "which the user likely hasn't explicitly acknowledged."
            ),
        )
        llm_mock.messages.create.side_effect = [short_rationale_response, better_response]

        result = kkanbu_curious()
        data = json.loads(result)

        assert llm_mock.messages.create.call_count == 2

    def test_quality_gate_retries_on_surface_question_pattern(self, llm_mock):
        """When question text matches a surface-language pattern, retry is triggered."""
        # 'Do you prefer' matches _SURFACE_QUESTION_PATTERNS even with depth_level=value
        surface_pattern_response = _make_curious_llm_response(
            question="Do you prefer working alone or in teams?",
            depth_level="value",
            novelty_rationale="This explores collaboration preference which is a value-level choice for the user.",
        )
        deeper_response = _make_curious_llm_response(
            question="Your graph shows strong solo work patterns but you've never explained whether that's a preference or a wound — which is it?",
            depth_level="identity",
            novelty_rationale=(
                "Distinguishes between chosen solitude and defensive isolation — "
                "a distinction the user has never articulated in the graph."
            ),
        )
        llm_mock.messages.create.side_effect = [surface_pattern_response, deeper_response]

        result = kkanbu_curious()
        data = json.loads(result)

        assert llm_mock.messages.create.call_count == 2

    def test_no_retry_when_quality_gate_passes(self, llm_mock):
        """When depth_level and novelty_rationale are acceptable, no retry is triggered."""
        good_response = _make_curious_llm_response(
            question="The graph shows you value reliability — but when did you stop trusting that things would just work?",
            depth_level="formative",
            novelty_rationale=(
                "Links the user's reliability obsession to a potential formative experience "
                "of system failure — a causal story never told in the graph."
            ),
        )
        llm_mock.messages.create.return_value = good_response

        result = kkanbu_curious()
        data = json.loads(result)

        # Only one Opus call — no retry needed
        assert llm_mock.messages.create.call_count == 1
        assert data["depth_level"] == "formative"

    def test_retry_failure_still_returns_valid_json(self, llm_mock):
        """If retry also fails, the original (shallow) result is returned without crashing."""
        shallow = _make_curious_llm_response(
            question="Do you prefer tabs or spaces?",
            depth_level="surface",
            novelty_rationale="basic",
        )
        # Retry raises an exception
        llm_mock.messages.create.side_effect = [shallow, Exception("retry failed")]

        result = kkanbu_curious()
        data = json.loads(result)

        assert data["type"] == "curiosity"
        assert "message" in data
        assert data["message"] != ""

    def test_questions_asked_tracked_in_session(self, llm_mock):
        """Session accumulates questions_asked for anti-repetition across turns."""
        q1 = "When did you first distrust complexity?"
        q2 = "What does that distrust protect you from?"
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(question=q1, thread_topic="complexity distrust"),
            _make_curious_llm_response(question=q2, thread_topic="complexity distrust"),
        ]

        r1 = kkanbu_curious()
        sid = json.loads(r1)["session_id"]
        kkanbu_curious(session_id=sid, user_response="I've always been wary of it.")

        session = _session_store.get(sid)
        assert session is not None
        assert q1 in session.questions_asked
        assert q2 in session.questions_asked

    def test_topics_explored_tracked_in_session(self, llm_mock):
        """Session accumulates topics_explored labels across turns."""
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(thread_topic="complexity distrust"),
            _make_curious_llm_response(thread_topic="complexity distrust"),
        ]

        r1 = kkanbu_curious()
        sid = json.loads(r1)["session_id"]
        kkanbu_curious(session_id=sid, user_response="Yes, always.")

        session = _session_store.get(sid)
        assert session is not None
        assert "complexity distrust" in session.topics_explored

    def test_retry_prompt_includes_rejection_reason(self, llm_mock):
        """The retry Opus call includes the rejection reason so it knows why it failed."""
        surface_response = _make_curious_llm_response(
            question="Do you like type hints?",
            depth_level="surface",
            novelty_rationale="surface pref",
        )
        deep_response = _make_curious_llm_response(
            question="You enforce type hints rigorously — is that about communication with others or distrust of your own memory?",
            depth_level="identity",
            novelty_rationale=(
                "Reframes a coding practice as a reflection of self-trust, "
                "connecting tool use to identity in a way never made explicit."
            ),
        )
        llm_mock.messages.create.side_effect = [surface_response, deep_response]

        kkanbu_curious()

        # Second call is the retry — rejection note is in the last user message
        # (multi-turn approach: base_messages + failed_assistant + rejection_user_note)
        retry_call_args = llm_mock.messages.create.call_args_list[1]
        retry_messages = retry_call_args.kwargs.get("messages") or []
        # Check all messages for the rejection note (it lives in the last user turn)
        all_retry_content = " ".join(m["content"] for m in retry_messages)
        assert "QUALITY GATE FAILED" in all_retry_content
        assert "depth_level" in all_retry_content.lower() or "surface" in all_retry_content.lower()

    def test_fresh_session_prompt_excludes_previously_asked_questions(self, llm_mock):
        """Fresh session includes questions_asked to prevent repetition."""
        q1 = "What shaped your distrust of complexity?"
        llm_mock.messages.create.return_value = _make_curious_llm_response(question=q1)

        r1 = kkanbu_curious()
        sid = json.loads(r1)["session_id"]

        # Start a new session after first one has been used (different sid)
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question="A completely different question?"
        )
        kkanbu_curious()  # New session — separate sid

        # Verify the first session stored the question
        session = _session_store.get(sid)
        assert session is not None
        assert q1 in session.questions_asked

    # ── Sub-AC 4d: Stateful multi-turn history threading ──────

    def test_three_turn_history_fully_threaded_to_opus(self, llm_mock):
        """Sub-AC 4d: On turn 3, Opus receives the FULL prior history (Q1, A1, Q2, A2),
        not just the immediately preceding exchange.  This prevents regenerating from
        scratch and enables genuine conversational coherence across 3+ turns."""
        q1 = "When did you first realise you cared about simplicity?"
        q2 = "What did that realisation cost you — what complexity did you have to give up?"
        q3 = "Is that trade-off still ongoing, or have you made peace with it?"

        # Sub-AC 9c: eager distillation adds 1 extra LLM call after each deep follow-up.
        # Turn 2 uses 2 mock responses (q2 for question gen, one for distillation).
        # Turn 3 uses 2 mock responses (q3 for question gen, one for distillation).
        # Providing 5 items: [q1, q2, distill-2, q3, distill-3].
        distill_stub = _make_curious_llm_response(question=q1, thread_topic="simplicity identity")
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(question=q1, thread_topic="simplicity identity"),
            _make_curious_llm_response(question=q2, thread_topic="simplicity identity"),
            distill_stub,  # Turn 2 distillation call (0 learnings — no "learnings" key)
            _make_curious_llm_response(question=q3, thread_topic="simplicity identity"),
            distill_stub,  # Turn 3 distillation call (0 learnings)
        ]

        # Turn 1 — fresh
        r1 = kkanbu_curious()
        sid = json.loads(r1)["session_id"]

        # Turn 2 — first follow-up
        kkanbu_curious(session_id=sid, user_response="Probably when I hit a codebase I couldn't reason about.")

        # Reset mock tracking so we can inspect just the Turn 3 call.
        # After reset, side_effect iterator still has q3 and distill-3 remaining.
        llm_mock.messages.create.reset_mock(side_effect=False)

        # Turn 3 — second follow-up
        kkanbu_curious(session_id=sid, user_response="I gave up on impressing people with clever code.")

        # Inspect the messages sent to Opus on Turn 3.
        # Sub-AC 9c: first call after reset = question gen; second = distillation.
        # Use call_args_list[0] to inspect the question-gen call specifically.
        call_args = llm_mock.messages.create.call_args_list[0]
        messages = call_args.kwargs.get("messages", [])

        # Should be multi-turn: [context, assistant(Q1), user(A1), assistant(Q2), user(A2+cue)]
        assert len(messages) >= 5, (
            f"Expected at least 5 messages for a 3-turn session; got {len(messages)}: "
            + str([m["role"] for m in messages])
        )

        # First message is the graph context
        assert messages[0]["role"] == "user"
        assert "knowledge graph" in messages[0]["content"].lower()

        # Q1 and Q2 must both appear — Opus sees the FULL history, not just the last exchange
        all_content = " ".join(m["content"] for m in messages)
        assert q1 in all_content, "Q1 from Turn 1 must be present in Turn 3 Opus call"
        assert q2 in all_content, "Q2 from Turn 2 must be present in Turn 3 Opus call"

        # Both user responses must also be present
        assert "couldn't reason about" in all_content
        assert "clever code" in all_content

        # Roles must alternate: user, assistant, user, assistant, user
        roles = [m["role"] for m in messages]
        assert roles[0] == "user", "First message must be user (context)"
        for i in range(1, len(roles)):
            assert roles[i] != roles[i - 1], (
                f"Adjacent messages at positions {i-1} and {i} both have role '{roles[i]}' — "
                "Anthropic API requires strict alternation"
            )

        # Session state must also reflect the full history
        session = _session_store.get(sid)
        assert session is not None
        assert len(session.questions_asked) == 3
        assert q1 in session.questions_asked
        assert q2 in session.questions_asked

    def test_continuing_without_user_response_still_builds_valid_messages(self, llm_mock):
        """If a continuing session is called without a user_response, messages still
        alternate correctly (no double assistant messages)."""
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(question="First deep question?", thread_topic="depth test"),
            _make_curious_llm_response(question="Second deep question?", thread_topic="depth test"),
        ]

        # Turn 1
        r1 = kkanbu_curious()
        sid = json.loads(r1)["session_id"]

        # Turn 2 — no user_response (edge case)
        kkanbu_curious(session_id=sid, user_response="")

        call_args = llm_mock.messages.create.call_args
        messages = call_args.kwargs.get("messages", [])

        roles = [m["role"] for m in messages]
        assert roles[0] == "user", "Must start with user"
        for i in range(1, len(roles)):
            assert roles[i] != roles[i - 1], (
                f"Consecutive {roles[i]} messages at positions {i-1},{i} — "
                "strict alternation required"
            )

    # ── Sub-AC 6c: Session state read/write for contextual follow-ups ─────

    def test_is_new_session_true_on_first_call(self, llm_mock):
        """Sub-AC 6c: Fresh kkanbu_curious call returns is_new_session=True."""
        llm_mock.messages.create.return_value = _make_curious_llm_response()
        data = json.loads(kkanbu_curious())
        assert "is_new_session" in data, "Response must include is_new_session field"
        assert data["is_new_session"] is True

    def test_is_new_session_false_on_continuing_call(self, llm_mock):
        """Sub-AC 6c: Follow-up call with same session_id returns is_new_session=False."""
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(thread_topic="identity tension"),
            _make_curious_llm_response(thread_topic="identity tension"),
        ]
        r1 = json.loads(kkanbu_curious())
        sid = r1["session_id"]
        assert r1["is_new_session"] is True

        r2 = json.loads(kkanbu_curious(session_id=sid, user_response="I think about it a lot."))
        assert r2["session_id"] == sid
        assert r2["is_new_session"] is False

    def test_topics_explored_appear_in_continuing_session_opus_prompt(self, llm_mock):
        """Sub-AC 6c: topics_explored from prior turns are included in the Opus prompt
        for continuing sessions, enabling Opus to maintain thread coherence."""
        thread = "autonomy philosophy"
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(
                question="When did you first realise you needed autonomy to do your best work?",
                thread_topic=thread,
            ),
            _make_curious_llm_response(
                question="What does that mean for how you structure collaboration?",
                thread_topic=thread,
            ),
        ]

        r1 = kkanbu_curious()
        sid = json.loads(r1)["session_id"]

        # Verify thread was stored in session
        session = _session_store.get(sid)
        assert session is not None
        assert thread in session.topics_explored

        # Reset and capture the second call's messages
        llm_mock.messages.create.reset_mock()
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question="What does that mean for how you structure collaboration?",
            thread_topic=thread,
        )
        kkanbu_curious(session_id=sid, user_response="I need space to think without interruptions.")

        # Sub-AC 9c: first call after reset = question gen; second = distillation.
        # Use call_args_list[0] to inspect the question-gen Opus call.
        call_args = llm_mock.messages.create.call_args_list[0]
        messages = call_args.kwargs.get("messages", [])

        # The topics_explored block should appear in the initial context message (messages[0])
        first_msg_content = messages[0]["content"] if messages else ""
        assert thread in first_msg_content, (
            f"topics_explored ('{thread}') must appear in the Opus context message so "
            "the model knows which threads have been opened in this session."
        )
        # The explored block should also mention coherence/going deeper
        assert "session" in first_msg_content.lower() or "thread" in first_msg_content.lower()

    def test_explored_block_not_present_in_fresh_session(self, llm_mock):
        """Sub-AC 6c: A fresh session (no prior turns) does not include an explored-topics
        block in the Opus prompt — the user message is a clean graph analysis request."""
        llm_mock.messages.create.return_value = _make_curious_llm_response()
        kkanbu_curious()

        call_args = llm_mock.messages.create.call_args
        messages = call_args.kwargs.get("messages", [])

        # Fresh session sends a single user message (no history)
        assert len(messages) == 1
        content = messages[0]["content"]
        # "Threads opened in this session" block must NOT appear (no explored topics yet)
        assert "Threads opened in this session" not in content

    def test_topics_explored_block_present_when_multiple_threads(self, llm_mock):
        """Sub-AC 6c: When a session has explored multiple topic threads, all are passed to
        Opus in the continuing-session context to prevent backtracking."""
        t1 = "simplicity values"
        t2 = "collaboration tension"
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(question="Q about simplicity?", thread_topic=t1),
            # Opus pivots to a second thread (unusual but valid)
            _make_curious_llm_response(question="Q about collaboration?", thread_topic=t2),
            _make_curious_llm_response(question="Q going deeper?", thread_topic=t2),
        ]

        r1 = kkanbu_curious()
        sid = json.loads(r1)["session_id"]
        kkanbu_curious(session_id=sid, user_response="Simplicity matters to me.")

        # Reset to inspect third call
        llm_mock.messages.create.reset_mock()
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question="Q going deeper?", thread_topic=t2
        )
        kkanbu_curious(session_id=sid, user_response="Collaboration is hard for me.")

        call_args = llm_mock.messages.create.call_args
        messages = call_args.kwargs.get("messages", [])
        first_msg = messages[0]["content"] if messages else ""

        # Both explored topics must appear in context
        assert t1 in first_msg, f"First explored topic '{t1}' must appear in Opus context"
        assert t2 in first_msg, f"Second explored topic '{t2}' must appear in Opus context"

    def test_session_context_includes_user_responses_in_history(self, llm_mock):
        """Sub-AC 6c: User responses from prior turns are preserved in the multi-turn
        Opus messages so follow-up questions can reference what the user said."""
        user_ans1 = "I built something brittle and it taught me to value resilience."
        user_ans2 = "That was in my first real job — a startup that moved fast."

        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(question="When did you first value resilience?", thread_topic="resilience"),
            _make_curious_llm_response(question="What happened at that startup?", thread_topic="resilience"),
            _make_curious_llm_response(question="How did it shape your approach today?", thread_topic="resilience"),
        ]

        r1 = kkanbu_curious()
        sid = json.loads(r1)["session_id"]
        kkanbu_curious(session_id=sid, user_response=user_ans1)

        # Capture the third-turn messages
        llm_mock.messages.create.reset_mock()
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question="How did it shape your approach today?", thread_topic="resilience"
        )
        kkanbu_curious(session_id=sid, user_response=user_ans2)

        call_args = llm_mock.messages.create.call_args
        messages = call_args.kwargs.get("messages", [])
        all_content = " ".join(m["content"] for m in messages)

        # Both prior user answers must be visible to Opus
        assert user_ans1 in all_content, "First user answer must be in third-turn Opus prompt"
        assert user_ans2 in all_content, "Second user answer must be in third-turn Opus prompt"

# ── TestAutonomousNodeWriting ─────────────────────────────────

class TestAutonomousNodeWriting:
    """Sub-AC 3b: LLM-extracted learnings are mapped to graph node schema
    and upserted into SQLite without hardcoded rules."""

    def test_upsert_updates_existing_node(self, llm_mock):
        """When LLM specifies upsert_node_id, the pipeline updates the existing node."""
        # First teach — create the initial node
        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "I prefer Python 3.11",
             "node_type": "preference", "why": None, "confidence": 0.7, "depth": "surface"},
        ])
        kkanbu_learn("I prefer Python 3.11")
        graph = get_graph()
        python_nodes = graph.search_nodes("Python 3.11")
        assert len(python_nodes) == 1
        original_id = python_nodes[0]["node_id"]
        original_updated_at = python_nodes[0]["updated_at"]

        # Second teach — LLM upserts the existing node with higher confidence
        llm_mock.messages.create.return_value = _make_llm_response([
            {
                "content": "I prefer Python 3.12+ for structural pattern matching",
                "node_type": "preference",
                "why": "match statements greatly simplify complex branching",
                "confidence": 0.95,
                "depth": "surface",
                "upsert_node_id": original_id,
            },
        ])
        result = kkanbu_learn("Actually I've moved to Python 3.12 — match statements changed my approach")
        assert "Learned" in result

        # Node should be UPDATED not duplicated
        updated_node = graph.get_node(original_id)
        assert updated_node is not None
        assert updated_node["confidence"] == 0.95
        assert "3.12" in updated_node["content"]
        assert "match" in (updated_node["why"] or "").lower()
        # No duplicate created
        python_nodes_after = graph.search_nodes("Python")
        assert len(python_nodes_after) == 1

    def test_upsert_creates_new_when_id_not_found(self, llm_mock):
        """When the LLM provides a non-existent upsert_node_id, a new node is created."""
        llm_mock.messages.create.return_value = _make_llm_response([
            {
                "content": "I value simplicity",
                "node_type": "value",
                "why": "Simple things are easy to debug",
                "confidence": 0.9,
                "depth": "identity",
                "upsert_node_id": "nonexistent_id_abc123",  # LLM hallucinated ID
            },
        ])
        result = kkanbu_learn("I really value simplicity")
        assert "Learned" in result

        graph = get_graph()
        nodes = graph.search_nodes("simplicity")
        assert len(nodes) >= 1
        # Should have created new node with generated ID (not the hallucinated one)
        assert nodes[0]["node_id"] != "nonexistent_id_abc123"

    def test_llm_decides_cross_learning_connections(self, llm_mock):
        """LLM can link new learnings to each other via to_learning_index."""
        llm_mock.messages.create.return_value = _make_llm_response(
            learnings=[
                {"content": "I value correctness over speed",
                 "node_type": "value", "why": None, "confidence": 0.9, "depth": "identity"},
                {"content": "I write tests before code",
                 "node_type": "pattern", "why": "Forces thinking about correctness first",
                 "confidence": 0.85, "depth": "identity"},
            ],
            connections=[
                {
                    "learning_index": 1,
                    "to_learning_index": 0,  # pattern supports the value
                    "relation_type": "supports",
                    "context": "TDD is a manifestation of valuing correctness",
                },
            ],
        )
        kkanbu_learn("I do TDD because correctness matters more than velocity")
        graph = get_graph()

        value_nodes = graph.search_nodes("correctness")
        pattern_nodes = graph.search_nodes("tests before code")
        assert len(value_nodes) >= 1
        assert len(pattern_nodes) >= 1

        # Edge should exist between the two new learnings
        value_id = value_nodes[0]["node_id"]
        pattern_id = pattern_nodes[0]["node_id"]
        edges_from_pattern = graph.get_edges_from(pattern_id)
        connected_to_value = any(e["to_node"] == value_id for e in edges_from_pattern)
        assert connected_to_value, "LLM-specified cross-learning edge should be stored"

    def test_no_hardcoded_co_extraction_edges(self, llm_mock):
        """Without LLM-specified connections, co-extracted learnings have NO automatic edges."""
        llm_mock.messages.create.return_value = _make_llm_response(
            learnings=[
                {"content": "I prefer vim motions",
                 "node_type": "preference", "why": None, "confidence": 0.9, "depth": "surface"},
                {"content": "I value keyboard-driven workflows",
                 "node_type": "value", "why": None, "confidence": 0.85, "depth": "identity"},
            ],
            connections=[],  # LLM decides no connections
        )
        kkanbu_learn("I use vim motions and keyboard-driven tools")
        graph = get_graph()

        vim_nodes = graph.search_nodes("vim")
        keyboard_nodes = graph.search_nodes("keyboard")
        assert len(vim_nodes) >= 1
        assert len(keyboard_nodes) >= 1

        vim_id = vim_nodes[0]["node_id"]
        keyboard_id = keyboard_nodes[0]["node_id"]

        # No automatic edges should have been created between them
        edges_from_vim = graph.get_edges_from(vim_id)
        edges_to_vim = graph.get_edges_to(vim_id)
        auto_edges = [
            e for e in edges_from_vim + edges_to_vim
            if "Co-extracted" in (e.get("context") or "")
        ]
        assert len(auto_edges) == 0, "No hardcoded co-extraction edges should be created"

    def test_result_shows_upserted_tag(self, llm_mock):
        """Result message shows [updated] tag for upserted nodes."""
        # Create original node
        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "I prefer tabs", "node_type": "preference",
             "why": None, "confidence": 0.7, "depth": "surface"},
        ])
        kkanbu_learn("I prefer tabs")
        graph = get_graph()
        node_id = graph.search_nodes("tabs")[0]["node_id"]

        # Upsert it
        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "I prefer 4-space indentation", "node_type": "preference",
             "why": "Consistent across all editors and languages",
             "confidence": 0.95, "depth": "surface",
             "upsert_node_id": node_id},
        ])
        result = kkanbu_learn("Actually I use spaces (4 spaces)")
        assert "[updated]" in result

    def test_result_shows_created_vs_updated_counts(self, llm_mock):
        """Result message shows breakdown of new vs updated nodes when both occur."""
        # Create original node
        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "I prefer asyncio", "node_type": "preference",
             "why": None, "confidence": 0.8, "depth": "surface"},
        ])
        kkanbu_learn("I prefer asyncio")
        graph = get_graph()
        asyncio_id = graph.search_nodes("asyncio")[0]["node_id"]

        # Mix of upsert + new
        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "I prefer asyncio for all I/O bound work",
             "node_type": "preference", "why": "Non-blocking I/O is essential",
             "confidence": 0.95, "depth": "surface", "upsert_node_id": asyncio_id},
            {"content": "Thinks in terms of concurrency primitives natively",
             "node_type": "observation", "why": None,
             "confidence": 0.8, "depth": "identity"},
        ])
        result = kkanbu_learn("asyncio changed how I think about I/O")
        assert "1 new" in result
        assert "1 updated" in result


# ── TestSessionLifecycle ──────────────────────────────────────
# Sub-AC 6b: session_id exposed in tool request/response contracts
# for kkanbu_answer, kkanbu_learn, and kkanbu_resolve_flag.


class TestSessionLifecycleAnswer:
    """kkanbu_answer: create session on first turn, retrieve on subsequent turns."""

    @pytest.fixture(autouse=True)
    def clear_sessions(self):
        _session_store._sessions.clear()
        yield
        _session_store._sessions.clear()

    def test_answer_returns_json_with_session_id(self):
        """kkanbu_answer returns valid JSON containing session_id."""
        raw = kkanbu_answer("What testing framework do you prefer?")
        data = json.loads(raw)
        assert "session_id" in data
        assert data["session_id"] != ""
        assert "answer" in data

    def test_answer_creates_new_session_on_first_call(self):
        """First call (no session_id) creates a new session."""
        raw = kkanbu_answer("What do you value most?")
        data = json.loads(raw)
        assert data["is_new_session"] is True
        sid = data["session_id"]
        assert sid in _session_store
        session = _session_store.get(sid)
        assert session is not None
        assert session.session_type == "answer"

    def test_answer_retrieves_existing_session_on_subsequent_call(self):
        """Calling with an existing session_id retrieves and updates the session."""
        raw1 = kkanbu_answer("What's your preferred language?")
        data1 = json.loads(raw1)
        sid = data1["session_id"]

        raw2 = kkanbu_answer("Why do you prefer it?", session_id=sid)
        data2 = json.loads(raw2)

        assert data2["session_id"] == sid
        assert data2["is_new_session"] is False

    def test_answer_history_grows_across_turns(self):
        """Session history accumulates question/answer pairs across turns."""
        raw1 = kkanbu_answer("First question?")
        sid = json.loads(raw1)["session_id"]

        kkanbu_answer("Second question?", session_id=sid)

        session = _session_store.get(sid)
        assert session is not None
        # Should have 2 user messages + 2 assistant messages = 4 total
        assert len(session.history) >= 2
        roles = [m.role for m in session.history]
        assert "user" in roles
        assert "assistant" in roles

    def test_answer_new_session_on_empty_session_id(self):
        """Two calls without session_id create independent sessions."""
        raw1 = kkanbu_answer("Q1?")
        raw2 = kkanbu_answer("Q2?")
        sid1 = json.loads(raw1)["session_id"]
        sid2 = json.loads(raw2)["session_id"]
        assert sid1 != sid2

    def test_answer_includes_confidence_and_turn(self):
        """JSON response includes confidence and turn count."""
        raw = kkanbu_answer("Some question?")
        data = json.loads(raw)
        assert "confidence" in data
        assert "turn" in data
        assert data["turn"] >= 1

    def test_answer_unknown_session_id_creates_new_session(self):
        """Providing an unknown session_id creates a new session (preserving the caller-supplied ID)."""
        raw = kkanbu_answer("Q?", session_id="nonexistent-session-id")
        data = json.loads(raw)
        # Session store creates a new session (is_new_session=True)
        assert data["is_new_session"] is True
        # Caller-supplied ID is preserved when a new session is created with it
        assert data["session_id"] == "nonexistent-session-id"
        # Session should now exist in the store
        assert "nonexistent-session-id" in _session_store


class TestSessionLifecycleTeach:
    """kkanbu_learn: create session on first turn, accumulate insights across turns."""

    @pytest.fixture(autouse=True)
    def clear_sessions(self):
        _session_store._sessions.clear()
        yield
        _session_store._sessions.clear()

    def test_teach_returns_json_with_session_id(self, llm_mock):
        """kkanbu_learn returns valid JSON containing session_id."""
        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "I prefer Python", "node_type": "preference",
             "why": None, "confidence": 0.9, "depth": "surface"},
        ])
        raw = kkanbu_learn("I prefer Python")
        data = json.loads(raw)
        assert "session_id" in data
        assert data["session_id"] != ""
        assert "result" in data
        assert "insights_extracted" in data
        assert "turn" in data

    def test_teach_creates_new_session_on_first_call(self, llm_mock):
        """First call (no session_id) creates a new teach session."""
        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "I prefer pytest", "node_type": "preference",
             "why": None, "confidence": 0.9, "depth": "surface"},
        ])
        raw = kkanbu_learn("I prefer pytest")
        data = json.loads(raw)
        assert data["is_new_session"] is True
        sid = data["session_id"]
        session = _session_store.get(sid)
        assert session is not None
        assert session.session_type == "teach"

    def test_teach_retrieves_existing_session_on_subsequent_call(self, llm_mock):
        """Calling with an existing session_id retrieves the session."""
        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "I prefer Python", "node_type": "preference",
             "why": None, "confidence": 0.9, "depth": "surface"},
        ])
        raw1 = kkanbu_learn("I prefer Python")
        data1 = json.loads(raw1)
        sid = data1["session_id"]

        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "I also value readability", "node_type": "value",
             "why": None, "confidence": 0.85, "depth": "identity"},
        ])
        raw2 = kkanbu_learn("I value readability", session_id=sid)
        data2 = json.loads(raw2)

        assert data2["session_id"] == sid
        assert data2["is_new_session"] is False

    def test_teach_accumulates_insights_across_turns(self, llm_mock):
        """insights_extracted accumulates across multiple teach turns in a session."""
        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "I prefer Python", "node_type": "preference",
             "why": None, "confidence": 0.9, "depth": "surface"},
            {"content": "Values readability", "node_type": "value",
             "why": None, "confidence": 0.85, "depth": "identity"},
        ])
        raw1 = kkanbu_learn("I prefer Python for its readability")
        data1 = json.loads(raw1)
        sid = data1["session_id"]
        count1 = data1["insights_extracted"]
        assert count1 == 2  # 2 learnings in first turn

        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "I also prefer simplicity", "node_type": "value",
             "why": None, "confidence": 0.85, "depth": "identity"},
        ])
        raw2 = kkanbu_learn("Simplicity matters to me", session_id=sid)
        data2 = json.loads(raw2)

        # Second turn adds 1 more → cumulative = 3
        assert data2["insights_extracted"] == 3

    def test_teach_empty_input_returns_json_with_session_id(self):
        """Even the empty-input error returns JSON with session_id."""
        raw = kkanbu_learn(insight="", conversation_text="")
        data = json.loads(raw)
        assert "session_id" in data
        assert "Nothing to learn" in data["result"]

    def test_teach_session_history_tracks_inputs(self, llm_mock):
        """Session history records user inputs and result summaries."""
        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "I prefer vim", "node_type": "preference",
             "why": None, "confidence": 0.9, "depth": "surface"},
        ])
        raw = kkanbu_learn("I prefer vim for editing")
        sid = json.loads(raw)["session_id"]
        session = _session_store.get(sid)
        assert session is not None
        assert len(session.history) >= 2  # at least user input + assistant result


class TestSessionLifecycleConversation:
    """kkanbu_resolve_flag: use session store for lifecycle management."""

    @pytest.fixture(autouse=True)
    def clear_sessions(self):
        _session_store._sessions.clear()
        yield
        _session_store._sessions.clear()

    def test_conversation_creates_session_on_start(self):
        """Starting a conversation creates a session in the store."""
        result = json.loads(kkanbu_resolve_flag())
        sid = result["session_id"]
        session = _session_store.get(sid)
        assert session is not None
        assert session.session_type == "conversation"

    def test_conversation_session_is_new_on_fresh_start(self):
        """Fresh start returns is_new_session=True."""
        result = json.loads(kkanbu_resolve_flag())
        assert result.get("is_new_session") is True

    def test_conversation_retrieves_session_on_followup(self):
        """Follow-up with session_id retrieves and continues the session."""
        _flag_question("Favourite editor?", "VS Code", 0.3)
        start = json.loads(kkanbu_resolve_flag())
        sid = start["session_id"]

        followup = json.loads(kkanbu_resolve_flag(
            user_response="I use Neovim — keyboard-first mindset",
            session_id=sid,
        ))
        assert followup["session_id"] == sid
        # is_new_session should be False since we're continuing
        assert followup.get("is_new_session") is False

    def test_conversation_session_history_grows(self):
        """Session history accumulates across conversation turns."""
        _flag_question("Preferred OS?", "macOS", 0.3)
        start = json.loads(kkanbu_resolve_flag())
        sid = start["session_id"]

        kkanbu_resolve_flag(
            user_response="I use macOS — Unix tools with good hardware",
            session_id=sid,
        )
        session = _session_store.get(sid)
        assert session is not None
        # Should have assistant Q + user response + assistant follow-up
        assert len(session.history) >= 2


# ── TestSessionLifecycleCurious ───────────────────────
# Sub-AC 5a: server-side session state for kkanbu_curious tracks
# conversation history and previously asked questions per session.


class TestSessionLifecycleCurious:
    """kkanbu_curious: session lifecycle — create, continue, history, questions_asked."""

    @pytest.fixture(autouse=True)
    def clear_sessions(self):
        _session_store._sessions.clear()
        yield
        _session_store._sessions.clear()

    def test_curious_creates_session_on_first_call(self, llm_mock):
        """First call (no session_id) creates a new 'curious' session in the store."""
        llm_mock.messages.create.return_value = _make_curious_llm_response()
        data = json.loads(kkanbu_curious())

        sid = data["session_id"]
        assert sid != ""
        assert sid in _session_store
        session = _session_store.get(sid)
        assert session is not None
        assert session.session_type == "curious"

    def test_curious_is_new_session_true_on_first_call(self, llm_mock):
        """Fresh call returns is_new_session=True."""
        llm_mock.messages.create.return_value = _make_curious_llm_response()
        data = json.loads(kkanbu_curious())
        assert data["is_new_session"] is True

    def test_curious_is_new_session_false_on_continuing_call(self, llm_mock):
        """Follow-up call with same session_id returns is_new_session=False."""
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(thread_topic="identity core"),
            _make_curious_llm_response(thread_topic="identity core"),
        ]
        r1 = json.loads(kkanbu_curious())
        sid = r1["session_id"]
        assert r1["is_new_session"] is True

        r2 = json.loads(kkanbu_curious(session_id=sid, user_response="I think deeply about this."))
        assert r2["session_id"] == sid
        assert r2["is_new_session"] is False

    def test_curious_retrieves_existing_session_on_follow_up(self, llm_mock):
        """Calling with an existing session_id retrieves and continues the session."""
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(question="Q1?", thread_topic="values"),
            _make_curious_llm_response(question="Q2?", thread_topic="values"),
        ]
        r1 = json.loads(kkanbu_curious())
        sid = r1["session_id"]

        r2 = json.loads(kkanbu_curious(session_id=sid, user_response="Here is my answer."))
        assert r2["session_id"] == sid
        assert r2["turn"] == 2

    def test_curious_history_grows_across_turns(self, llm_mock):
        """Session history accumulates assistant questions and user responses across turns."""
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(question="First question?"),
            _make_curious_llm_response(question="Second question?"),
        ]
        r1 = kkanbu_curious()
        sid = json.loads(r1)["session_id"]

        kkanbu_curious(session_id=sid, user_response="My answer to the first question.")

        session = _session_store.get(sid)
        assert session is not None
        # [assistant Q1, user A1, assistant Q2]
        assert len(session.history) >= 3
        roles = [m.role for m in session.history]
        assert roles.count("assistant") >= 2
        assert "user" in roles

    def test_curious_questions_asked_tracked_per_session(self, llm_mock):
        """questions_asked accumulates verbatim questions for anti-repetition across turns."""
        q1 = "When did complexity first feel like a threat to you?"
        q2 = "What does that threat protect — identity or competence?"
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(question=q1, thread_topic="complexity fear"),
            _make_curious_llm_response(question=q2, thread_topic="complexity fear"),
        ]

        r1 = kkanbu_curious()
        sid = json.loads(r1)["session_id"]
        kkanbu_curious(session_id=sid, user_response="Complexity overwhelmed me early in my career.")

        session = _session_store.get(sid)
        assert session is not None
        assert q1 in session.questions_asked
        assert q2 in session.questions_asked
        assert len(session.questions_asked) == 2

    def test_curious_questions_asked_not_duplicated_on_same_turn(self, llm_mock):
        """Each question is appended once per turn — no duplicates from repeated calls."""
        q = "What does your definition of done reveal about your fear of failure?"
        llm_mock.messages.create.return_value = _make_curious_llm_response(question=q)

        r = kkanbu_curious()
        sid = json.loads(r)["session_id"]

        session = _session_store.get(sid)
        assert session is not None
        assert session.questions_asked.count(q) == 1

    def test_curious_unknown_session_id_creates_new_session_with_that_id(self, llm_mock):
        """Providing an unknown session_id creates a new session preserving the caller-supplied ID."""
        llm_mock.messages.create.return_value = _make_curious_llm_response()
        custom_sid = "custom-curious-session-abc"

        data = json.loads(kkanbu_curious(session_id=custom_sid))

        assert data["is_new_session"] is True
        assert data["session_id"] == custom_sid
        assert custom_sid in _session_store

    def test_curious_independent_sessions_have_separate_questions_asked(self, llm_mock):
        """Two separate sessions each maintain their own questions_asked lists."""
        q1 = "Question for session one?"
        q2 = "Question for session two?"
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(question=q1),
            _make_curious_llm_response(question=q2),
        ]

        r1 = json.loads(kkanbu_curious())
        r2 = json.loads(kkanbu_curious())
        sid1, sid2 = r1["session_id"], r2["session_id"]
        assert sid1 != sid2

        s1 = _session_store.get(sid1)
        s2 = _session_store.get(sid2)
        assert s1 is not None and s2 is not None
        assert q1 in s1.questions_asked
        assert q1 not in s2.questions_asked
        assert q2 in s2.questions_asked
        assert q2 not in s1.questions_asked

    def test_curious_prune_stale_removes_expired_sessions(self, llm_mock):
        """Stale sessions are removed from the store after their timeout elapses."""
        import time

        llm_mock.messages.create.return_value = _make_curious_llm_response()
        data = json.loads(kkanbu_curious())
        sid = data["session_id"]
        assert sid in _session_store

        # Manually expire the session by backdating last_active beyond timeout
        session = _session_store.get(sid)
        assert session is not None
        session.last_active = time.time() - (_session_store.timeout_secs + 1)

        # prune_stale should remove it
        pruned = _session_store.prune_stale()
        assert pruned >= 1
        assert sid not in _session_store

    def test_curious_turn_count_increments_per_assistant_message(self, llm_mock):
        """turn in the JSON response increments by 1 for each assistant message sent."""
        # Sub-AC 9c: each follow-up call (with user_response) also makes an eager
        # distillation LLM call after the question is generated.  Provide 5 mock
        # responses: q1, q2, distill-2, q3, distill-3.
        distill_stub = _make_curious_llm_response(question="stub")
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(question="Turn-1 question?"),
            _make_curious_llm_response(question="Turn-2 question?"),
            distill_stub,  # Turn 2 eager distillation (0 learnings — no "learnings" key)
            _make_curious_llm_response(question="Turn-3 question?"),
            distill_stub,  # Turn 3 eager distillation (0 learnings)
        ]

        r1 = json.loads(kkanbu_curious())
        sid = r1["session_id"]
        assert r1["turn"] == 1

        r2 = json.loads(kkanbu_curious(session_id=sid, user_response="First answer."))
        assert r2["turn"] == 2

        r3 = json.loads(kkanbu_curious(session_id=sid, user_response="Second answer."))
        assert r3["turn"] == 3


# ── Sub-AC 7a: Ephemeral Session History Accumulation ─────────────────────────
# Each conversation turn (user input + kkanbu responses) must be appended to the
# in-memory session state keyed by session_id.  Tests verify:
#   1. Exact content of history messages (not just length / role presence)
#   2. Correct ordering — user message precedes assistant within a turn
#   3. Multi-turn accumulation — all prior turns remain after new turns
#   4. history_as_dicts() returns dicts usable by the Anthropic messages API
#   5. Session-id keying — the session_id in the JSON response resolves the
#      same SessionState that owns the history


class TestSubAC7aEphemeralSessionHistory:
    """Ephemeral history accumulates correctly across all three main tools."""

    @pytest.fixture(autouse=True)
    def clear_sessions(self):
        _session_store._sessions.clear()
        yield
        _session_store._sessions.clear()

    # ── kkanbu_answer ────────────────────────────────────────────────────────

    def test_answer_appends_user_question_to_history(self):
        """User question appears verbatim in session history after kkanbu_answer."""
        question = "What is your preferred programming language?"
        raw = kkanbu_answer(question)
        sid = json.loads(raw)["session_id"]

        session = _session_store.get(sid)
        assert session is not None
        user_msgs = [m for m in session.history if m.role == "user"]
        assert len(user_msgs) == 1
        assert user_msgs[0].content == question

    def test_answer_appends_assistant_response_to_history(self):
        """Assistant answer appears in session history and matches the returned JSON."""
        raw = kkanbu_answer("What do you value in a codebase?")
        data = json.loads(raw)
        sid = data["session_id"]
        answer_text = data["answer"]

        session = _session_store.get(sid)
        assert session is not None
        asst_msgs = [m for m in session.history if m.role == "assistant"]
        assert len(asst_msgs) == 1
        assert asst_msgs[0].content != ""
        # Content recorded in session must match what was returned in the JSON
        assert asst_msgs[0].content == answer_text

    def test_answer_user_precedes_assistant_within_a_turn(self):
        """Within a single turn the user message is recorded BEFORE the assistant."""
        raw = kkanbu_answer("Do you prefer tabs or spaces?")
        sid = json.loads(raw)["session_id"]

        session = _session_store.get(sid)
        assert session is not None
        assert len(session.history) >= 2
        assert session.history[0].role == "user"
        assert session.history[1].role == "assistant"

    def test_answer_history_ordered_across_two_turns(self):
        """Over two turns, history is exactly [user1, asst1, user2, asst2]."""
        q1, q2 = "First question about preferences?", "Second question about values?"
        raw1 = kkanbu_answer(q1)
        sid = json.loads(raw1)["session_id"]
        kkanbu_answer(q2, session_id=sid)

        session = _session_store.get(sid)
        assert session is not None
        assert len(session.history) == 4
        roles = [m.role for m in session.history]
        assert roles == ["user", "assistant", "user", "assistant"]
        assert session.history[0].content == q1
        assert session.history[2].content == q2

    def test_answer_history_as_dicts_has_anthropic_api_format(self):
        """history_as_dicts() returns dicts with exactly 'role' and 'content' keys."""
        raw = kkanbu_answer("Tell me about your debugging style.")
        sid = json.loads(raw)["session_id"]

        session = _session_store.get(sid)
        assert session is not None
        dicts = session.history_as_dicts()
        assert len(dicts) >= 2
        for d in dicts:
            assert set(d.keys()) == {"role", "content"}
            assert d["role"] in ("user", "assistant")
            assert isinstance(d["content"], str)
            assert len(d["content"]) > 0

    def test_answer_session_id_is_key_to_history(self):
        """The session_id from the JSON response retrieves the history-bearing session."""
        raw = kkanbu_answer("What motivates you?")
        data = json.loads(raw)
        sid = data["session_id"]
        answer_text = data["answer"]

        session = _session_store.get(sid)
        assert session is not None
        assert session.session_id == sid
        asst_contents = [m.content for m in session.history if m.role == "assistant"]
        assert answer_text in asst_contents

    def test_answer_three_turns_accumulate_all_six_messages(self):
        """After three answer turns, history holds all six messages."""
        questions = ["Q1?", "Q2?", "Q3?"]
        raw1 = kkanbu_answer(questions[0])
        sid = json.loads(raw1)["session_id"]
        kkanbu_answer(questions[1], session_id=sid)
        kkanbu_answer(questions[2], session_id=sid)

        session = _session_store.get(sid)
        assert session is not None
        assert len(session.history) == 6
        user_msgs = [m for m in session.history if m.role == "user"]
        asst_msgs = [m for m in session.history if m.role == "assistant"]
        assert len(user_msgs) == 3
        assert len(asst_msgs) == 3
        assert [m.content for m in user_msgs] == questions

    # ── kkanbu_learn ─────────────────────────────────────────────────────────

    def test_teach_appends_user_input_to_history(self, llm_mock):
        """User insight appears as the first history entry after kkanbu_learn."""
        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "Prefers concise code", "node_type": "preference",
             "why": None, "confidence": 0.9, "depth": "surface"},
        ])
        insight = "I always prefer concise, readable code over clever tricks."
        raw = kkanbu_learn(insight)
        sid = json.loads(raw)["session_id"]

        session = _session_store.get(sid)
        assert session is not None
        user_msgs = [m for m in session.history if m.role == "user"]
        assert len(user_msgs) == 1
        # Content is truncated to 500 chars — verify it starts with the insight text
        assert user_msgs[0].content.startswith(insight[:50])

    def test_teach_appends_assistant_result_to_history(self, llm_mock):
        """Extracted learning summary appears as the second history entry."""
        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "Values clarity in code", "node_type": "value",
             "why": None, "confidence": 0.85, "depth": "identity"},
        ])
        raw = kkanbu_learn("Clarity is more important to me than performance.")
        sid = json.loads(raw)["session_id"]

        session = _session_store.get(sid)
        assert session is not None
        asst_msgs = [m for m in session.history if m.role == "assistant"]
        assert len(asst_msgs) == 1
        assert asst_msgs[0].content != ""

    def test_teach_user_precedes_assistant_within_a_turn(self, llm_mock):
        """Within a teach turn the user message is recorded before the assistant."""
        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "Prefers simplicity", "node_type": "preference",
             "why": None, "confidence": 0.9, "depth": "surface"},
        ])
        raw = kkanbu_learn("Simplicity first.")
        sid = json.loads(raw)["session_id"]

        session = _session_store.get(sid)
        assert session is not None
        assert len(session.history) >= 2
        assert session.history[0].role == "user"
        assert session.history[1].role == "assistant"

    def test_teach_history_ordered_across_two_turns(self, llm_mock):
        """Over two teach turns, history is [user1, asst1, user2, asst2]."""
        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "Prefers Python", "node_type": "preference",
             "why": None, "confidence": 0.9, "depth": "surface"},
        ])
        raw1 = kkanbu_learn("I prefer Python for its readability.")
        sid = json.loads(raw1)["session_id"]

        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "Values open source", "node_type": "value",
             "why": None, "confidence": 0.8, "depth": "identity"},
        ])
        kkanbu_learn("I strongly value open-source contributions.", session_id=sid)

        session = _session_store.get(sid)
        assert session is not None
        assert len(session.history) == 4
        roles = [m.role for m in session.history]
        assert roles == ["user", "assistant", "user", "assistant"]

    def test_teach_history_as_dicts_valid_anthropic_format(self, llm_mock):
        """history_as_dicts() from a teach session is valid for the Anthropic API."""
        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "Prefers minimalism", "node_type": "preference",
             "why": None, "confidence": 0.9, "depth": "surface"},
        ])
        raw = kkanbu_learn("I value minimalist design.")
        sid = json.loads(raw)["session_id"]

        session = _session_store.get(sid)
        assert session is not None
        dicts = session.history_as_dicts()
        assert len(dicts) >= 2
        for d in dicts:
            assert set(d.keys()) == {"role", "content"}
            assert d["role"] in ("user", "assistant")
            assert isinstance(d["content"], str)
            assert len(d["content"]) > 0

    # ── kkanbu_curious ───────────────────────────────────────────────────────

    def test_curious_first_turn_appends_only_assistant_question(self, llm_mock):
        """On the first call (no user response), history has exactly one assistant message."""
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question="What shaped your approach to software craftsmanship?"
        )
        raw = kkanbu_curious()
        data = json.loads(raw)
        sid = data["session_id"]
        question_returned = data["message"]

        session = _session_store.get(sid)
        assert session is not None
        # First turn: no user input → only assistant question in history
        assert len(session.history) == 1
        assert session.history[0].role == "assistant"
        assert session.history[0].content == question_returned

    def test_curious_second_turn_user_before_assistant(self, llm_mock):
        """On the follow-up turn, user response is recorded BEFORE the assistant question."""
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(question="What shaped your craftsmanship?"),
            _make_curious_llm_response(question="Which failure taught you the most?"),
        ]
        raw1 = kkanbu_curious()
        sid = json.loads(raw1)["session_id"]

        user_response = "Mentors who cared about quality over speed."
        kkanbu_curious(session_id=sid, user_response=user_response)

        session = _session_store.get(sid)
        assert session is not None
        # History: [asst Q1, user A1, asst Q2]
        assert len(session.history) == 3
        assert session.history[0].role == "assistant"
        assert session.history[1].role == "user"
        assert session.history[1].content == user_response
        assert session.history[2].role == "assistant"

    def test_curious_three_turns_accumulate_five_messages(self, llm_mock):
        """After three curious turns (1 fresh + 2 follow-up), history has 5 messages."""
        # Sub-AC 9c: each follow-up adds 1 distillation LLM call after question gen.
        # Provide 5 items: q1, q2, distill-2, q3, distill-3.
        distill_stub = _make_curious_llm_response(question="stub")
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(question="Q1: craftsmanship?"),
            _make_curious_llm_response(question="Q2: failure?"),
            distill_stub,  # Turn 2 distillation (0 learnings)
            _make_curious_llm_response(question="Q3: growth?"),
            distill_stub,  # Turn 3 distillation (0 learnings)
        ]
        raw1 = kkanbu_curious()
        sid = json.loads(raw1)["session_id"]

        kkanbu_curious(session_id=sid, user_response="A1: learned from mentors")
        kkanbu_curious(session_id=sid, user_response="A2: a failed launch")

        session = _session_store.get(sid)
        assert session is not None
        # [asst, user, asst, user, asst] = 5 messages
        assert len(session.history) == 5
        roles = [m.role for m in session.history]
        assert roles == ["assistant", "user", "assistant", "user", "assistant"]

    def test_curious_session_id_keys_history(self, llm_mock):
        """The session_id in the JSON response retrieves the session with the history."""
        returned_q = "What trade-off do you regret most in past work?"
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question=returned_q
        )
        raw = kkanbu_curious()
        data = json.loads(raw)
        sid = data["session_id"]
        question_returned = data["message"]

        session = _session_store.get(sid)
        assert session is not None
        assert session.session_id == sid
        all_content = [m.content for m in session.history]
        assert question_returned in all_content

    def test_curious_blank_user_response_not_appended(self, llm_mock):
        """Empty or whitespace-only user_response is NOT added to session history."""
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(question="Deep question here?"),
            _make_curious_llm_response(question="Follow-up here?"),
        ]
        raw1 = kkanbu_curious()
        sid = json.loads(raw1)["session_id"]

        # Pass whitespace-only response — should not appear in history
        kkanbu_curious(session_id=sid, user_response="   ")

        session = _session_store.get(sid)
        assert session is not None
        user_msgs = [m for m in session.history if m.role == "user"]
        assert len(user_msgs) == 0  # no user message appended for blank response


# ── Sub-AC 7b: LLM Distillation Pipeline ──────────────────────────────────────
# The distillation pipeline converts ephemeral session conversation history into
# persistent knowledge-graph learnings on session end (auto) or explicit trigger
# (kkanbu_distill).  Tests verify:
#   1. _distill_session_to_graph writes learnings to the graph when history exists
#   2. Single-sided sessions (no user OR no assistant turns) are skipped gracefully
#   3. LLM failure returns empty result dict without raising
#   4. upsert_node_id validation: invalid IDs are ignored, not forwarded
#   5. node_type whitelisting: out-of-range types fall back to "observation"
#   6. _distill_and_prune_stale_sessions distills before pruning
#   7. Sessions without history are pruned without LLM call
#   8. kkanbu_distill with session_id distills the named session
#   9. kkanbu_distill without session_id distills all sessions with exchanges
#  10. kkanbu_distill returns 404-style error for unknown session_id


def _make_distillation_response(
    learnings: list,
    session_synthesis: str = "Revealed identity patterns.",
    distillation_notes: str = "Standard session.",
) -> MagicMock:
    """Build a mock Anthropic response for _distill_session_to_graph."""
    body = {
        "learnings": learnings,
        "session_synthesis": session_synthesis,
        "distillation_notes": distillation_notes,
    }
    msg = MagicMock()
    msg.content = [MagicMock(text=json.dumps(body))]
    return msg


class TestSubAC7bDistillationPipeline:
    """LLM distillation pipeline: ephemeral session → persistent graph learnings."""

    @pytest.fixture(autouse=True)
    def clear_sessions(self):
        _session_store._sessions.clear()
        yield
        _session_store._sessions.clear()

    # ── _distill_session_to_graph: core function ─────────────────────────────

    def test_distill_writes_learnings_to_graph(self, llm_mock):
        """Learnings extracted by Opus are written to the knowledge graph."""
        from kkanbu.session import SessionState

        session = _session_store.create("curious")
        session.append("assistant", "What shaped your relationship with complexity?")
        session.append("user", "Failing a big project early on taught me to respect complexity.")

        llm_mock.messages.create.return_value = _make_distillation_response([
            {
                "content": "Respects complexity as a force to be managed, not defeated",
                "node_type": "value",
                "why": "Learned through early project failure",
                "confidence": 0.85,
                "depth": "identity",
                "upsert_node_id": None,
            }
        ], session_synthesis="Shaped by formative failure into a complexity-aware engineer.")

        result = _distill_session_to_graph(session)

        assert result["learnings_written"] == 1
        assert len(result["learning_ids"]) == 1
        assert result["session_synthesis"] == "Shaped by formative failure into a complexity-aware engineer."

        graph = get_graph()
        node = graph.get_node(result["learning_ids"][0])
        assert node is not None
        assert "complexity" in node["content"].lower()
        assert node["node_type"] == "value"
        assert node["source"] == "distill:curious"

    def test_distill_skips_session_without_user_turns(self, llm_mock):
        """Session with only assistant messages is skipped — nothing to distill."""
        session = _session_store.create("answer")
        session.append("assistant", "I prefer Python because it gets out of my way.")

        result = _distill_session_to_graph(session)

        assert result["learnings_written"] == 0
        assert result["learning_ids"] == []
        # LLM should NOT have been called
        llm_mock.messages.create.assert_not_called()

    def test_distill_skips_session_without_assistant_turns(self, llm_mock):
        """Session with only user messages is skipped — nothing to distill."""
        session = _session_store.create("teach")
        session.append("user", "I value simplicity above all else.")

        result = _distill_session_to_graph(session)

        assert result["learnings_written"] == 0
        llm_mock.messages.create.assert_not_called()

    def test_distill_skips_empty_session(self, llm_mock):
        """Completely empty session returns empty result without calling LLM."""
        session = _session_store.create("curious")

        result = _distill_session_to_graph(session)

        assert result["learnings_written"] == 0
        llm_mock.messages.create.assert_not_called()

    def test_distill_handles_llm_failure_gracefully(self, llm_mock):
        """LLM call failure returns empty result without raising."""
        session = _session_store.create("curious")
        session.append("assistant", "What principle guides your hardest decisions?")
        session.append("user", "Honesty, even when it costs me.")

        llm_mock.messages.create.side_effect = Exception("API unavailable")

        result = _distill_session_to_graph(session)

        assert result["learnings_written"] == 0
        assert result["learning_ids"] == []
        assert result["session_synthesis"] == ""

    def test_distill_handles_empty_learnings_in_response(self, llm_mock):
        """LLM returning empty learnings list gives zero writes but synthesis preserved."""
        session = _session_store.create("curious")
        session.append("assistant", "What are your values?")
        session.append("user", "Good question, I'm not sure.")

        llm_mock.messages.create.return_value = _make_distillation_response(
            [], session_synthesis="Session was too vague to extract learnings."
        )

        result = _distill_session_to_graph(session)

        assert result["learnings_written"] == 0
        assert result["session_synthesis"] == "Session was too vague to extract learnings."

    def test_distill_invalid_upsert_id_ignored(self, llm_mock):
        """upsert_node_id pointing to a non-existent node is silently ignored."""
        session = _session_store.create("teach")
        session.append("assistant", "What motivates you?")
        session.append("user", "Making things that last.")

        llm_mock.messages.create.return_value = _make_distillation_response([
            {
                "content": "Values durable work over fleeting impact",
                "node_type": "value",
                "why": None,
                "confidence": 0.8,
                "depth": "identity",
                "upsert_node_id": "nonexistent-node-id-xyz",
            }
        ])

        result = _distill_session_to_graph(session)

        # Should still write a new node (not upsert into non-existent)
        assert result["learnings_written"] == 1
        graph = get_graph()
        node = graph.get_node(result["learning_ids"][0])
        assert node is not None

    def test_distill_unknown_node_type_falls_back_to_observation(self, llm_mock):
        """Out-of-whitelist node_type is normalised to 'observation'."""
        session = _session_store.create("conversation")
        session.append("assistant", "Tell me about yourself.")
        session.append("user", "I'm a backend engineer who loves clean APIs.")

        llm_mock.messages.create.return_value = _make_distillation_response([
            {
                "content": "Backend engineer who prioritises clean API design",
                "node_type": "fact",  # not a valid graph node_type
                "why": None,
                "confidence": 0.75,
                "depth": "surface",
                "upsert_node_id": None,
            }
        ])

        result = _distill_session_to_graph(session)

        assert result["learnings_written"] == 1
        graph = get_graph()
        node = graph.get_node(result["learning_ids"][0])
        assert node is not None
        assert node["node_type"] == "observation"  # normalised from "fact"

    def test_distill_multiple_learnings_all_written(self, llm_mock):
        """All learnings in the LLM response are written to the graph."""
        session = _session_store.create("curious")
        session.append("assistant", "What trade-offs do you make most often?")
        session.append("user", "Speed vs correctness. I always pick correctness.")

        learnings = [
            {
                "content": "Chooses correctness over delivery speed",
                "node_type": "value",
                "why": "Trust is destroyed by bugs, not slowness",
                "confidence": 0.9,
                "depth": "identity",
                "upsert_node_id": None,
            },
            {
                "content": "Frames software trade-offs as ethical choices",
                "node_type": "pattern",
                "why": None,
                "confidence": 0.75,
                "depth": "identity",
                "upsert_node_id": None,
            },
        ]
        llm_mock.messages.create.return_value = _make_distillation_response(learnings)

        result = _distill_session_to_graph(session)

        assert result["learnings_written"] == 2
        assert len(result["learning_ids"]) == 2
        # Both nodes exist in graph
        graph = get_graph()
        for nid in result["learning_ids"]:
            assert graph.get_node(nid) is not None

    def test_distill_source_field_encodes_session_type(self, llm_mock):
        """The graph node's source encodes which session type produced it."""
        session = _session_store.create("answer")
        session.append("assistant", "Microservices question answer here.")
        session.append("user", "Actually I hate microservices for small teams.")

        llm_mock.messages.create.return_value = _make_distillation_response([
            {
                "content": "Opposes microservices for small teams",
                "node_type": "opinion",
                "why": "Complexity cost outweighs benefits below a certain scale",
                "confidence": 0.85,
                "depth": "identity",
                "upsert_node_id": None,
            }
        ])

        result = _distill_session_to_graph(session)
        assert result["learnings_written"] == 1
        graph = get_graph()
        node = graph.get_node(result["learning_ids"][0])
        assert node is not None
        assert node["source"] == "distill:answer"

    # ── _distill_and_prune_stale_sessions: auto-distillation on prune ────────

    def test_stale_sessions_with_history_are_distilled_before_pruning(self, llm_mock):
        """Stale sessions with two-sided history get distilled before being pruned."""
        import time as _time

        session = _session_store.create("curious")
        session.append("assistant", "What shaped your earliest mental model?")
        session.append("user", "My first mentor who showed me what good code looks like.")

        # Backdate to make the session stale
        session.last_active = _time.time() - (_session_store.timeout_secs + 1)

        llm_mock.messages.create.return_value = _make_distillation_response([
            {
                "content": "Formed by mentorship — good code is learned, not self-taught",
                "node_type": "value",
                "why": "First mentor shaped taste for code quality",
                "confidence": 0.85,
                "depth": "identity",
                "upsert_node_id": None,
            }
        ])

        sid = session.session_id
        pruned = _distill_and_prune_stale_sessions()

        assert pruned >= 1
        assert sid not in _session_store  # session was removed

        # Distillation LLM call happened (AC7c edge inference may add further calls)
        llm_mock.messages.create.assert_called()

        # Learning was written to graph
        graph = get_graph()
        stats = graph.get_stats()
        assert stats["nodes"] >= 1

    def test_stale_sessions_without_history_pruned_without_distillation(self, llm_mock):
        """Stale sessions with no history are pruned without making an LLM call."""
        import time as _time

        session = _session_store.create("answer")
        # No history appended
        session.last_active = _time.time() - (_session_store.timeout_secs + 1)

        sid = session.session_id
        pruned = _distill_and_prune_stale_sessions()

        assert pruned >= 1
        assert sid not in _session_store
        llm_mock.messages.create.assert_not_called()

    def test_stale_sessions_single_sided_history_not_distilled(self, llm_mock):
        """Stale sessions with only user OR only assistant turns skip distillation."""
        import time as _time

        session = _session_store.create("teach")
        session.append("assistant", "Gotcha. I've recorded that.")
        # Only assistant turn — no user turn
        session.last_active = _time.time() - (_session_store.timeout_secs + 1)

        _distill_and_prune_stale_sessions()

        llm_mock.messages.create.assert_not_called()

    def test_active_sessions_not_distilled_during_prune(self, llm_mock):
        """Active (non-stale) sessions are NOT distilled or removed during a prune sweep."""
        session = _session_store.create("curious")
        session.append("assistant", "Tell me about your core beliefs.")
        session.append("user", "I believe software is a craft, not just engineering.")
        # Do NOT backdate — session is active

        sid = session.session_id
        _distill_and_prune_stale_sessions()

        # Session still exists
        assert sid in _session_store
        # No LLM call for distillation
        llm_mock.messages.create.assert_not_called()

    # ── kkanbu_distill: explicit trigger MCP tool ────────────────────────────

    def test_kkanbu_distill_with_session_id_distills_named_session(self, llm_mock):
        """kkanbu_distill with a specific session_id distills that session."""
        llm_mock.messages.create.return_value = _make_distillation_response([
            {
                "content": "Driven by curiosity as a core life principle",
                "node_type": "value",
                "why": "Always asks 'why' before 'how'",
                "confidence": 0.88,
                "depth": "identity",
                "upsert_node_id": None,
            }
        ], session_synthesis="Curiosity-driven identity revealed.")

        session = _session_store.create("curious")
        session.append("assistant", "What drives you to keep learning?")
        session.append("user", "I can't help it — curiosity is just who I am.")
        sid = session.session_id

        raw = kkanbu_distill(session_id=sid)
        data = json.loads(raw)

        assert data["session_id"] == sid
        assert data["session_type"] == "curious"
        assert data["learnings_written"] == 1
        assert len(data["learning_ids"]) == 1
        assert data["session_synthesis"] == "Curiosity-driven identity revealed."
        assert data["sessions_distilled"] == 1

    def test_kkanbu_distill_session_persists_after_explicit_distillation(self, llm_mock):
        """After kkanbu_distill, the session still exists — distillation does not end it."""
        llm_mock.messages.create.return_value = _make_distillation_response([
            {
                "content": "Values autonomy in technical decisions",
                "node_type": "value",
                "why": None,
                "confidence": 0.8,
                "depth": "identity",
                "upsert_node_id": None,
            }
        ])

        session = _session_store.create("curious")
        session.append("assistant", "Do you prefer to work alone or with others?")
        session.append("user", "Alone for deep work; team for direction-setting.")
        sid = session.session_id

        kkanbu_distill(session_id=sid)

        # Session should still be alive
        assert _session_store.get(sid) is not None

    def test_kkanbu_distill_unknown_session_id_returns_error(self, llm_mock):
        """kkanbu_distill with an unknown session_id returns an error JSON."""
        raw = kkanbu_distill(session_id="nonexistent-session-xyz")
        data = json.loads(raw)

        assert "error" in data
        assert data["learnings_written"] == 0
        assert data["sessions_distilled"] == 0

    def test_kkanbu_distill_bulk_distills_all_eligible_sessions(self, llm_mock):
        """kkanbu_distill with no session_id distills all active sessions with history."""
        llm_mock.messages.create.return_value = _make_distillation_response([
            {
                "content": "Learning extracted from bulk distillation",
                "node_type": "observation",
                "why": None,
                "confidence": 0.7,
                "depth": "surface",
                "upsert_node_id": None,
            }
        ])

        # Create two sessions with two-sided history
        for i in range(2):
            s = _session_store.create("curious")
            s.append("assistant", f"Q{i}: Deep question about identity?")
            s.append("user", f"A{i}: My honest answer about who I am.")

        # Create one session without history (should be skipped)
        _session_store.create("answer")

        raw = kkanbu_distill()
        data = json.loads(raw)

        assert data["active_sessions_checked"] == 3
        # Both eligible sessions were distilled (at least 2 LLM calls; AC7c edge
        # inference may add additional calls when pre-existing nodes are present)
        assert llm_mock.messages.create.call_count >= 2
        assert data["learnings_written"] == 2  # 1 per session
        assert data["sessions_distilled"] == 2

    def test_kkanbu_distill_bulk_with_no_eligible_sessions(self, llm_mock):
        """kkanbu_distill with no eligible sessions returns zero learnings."""
        # Only empty/single-sided sessions
        s = _session_store.create("answer")
        s.append("assistant", "Here is my answer.")
        # No user turn

        raw = kkanbu_distill()
        data = json.loads(raw)

        assert data["learnings_written"] == 0
        assert data["sessions_distilled"] == 0
        llm_mock.messages.create.assert_not_called()

    def test_kkanbu_distill_no_session_id_returns_correct_keys(self, llm_mock):
        """Bulk distill response always includes all expected JSON keys."""
        raw = kkanbu_distill()
        data = json.loads(raw)

        assert "learnings_written" in data
        assert "learning_ids" in data
        assert "session_synthesis" in data
        assert "sessions_distilled" in data
        assert "active_sessions_checked" in data

    def test_kkanbu_distill_with_session_id_returns_correct_keys(self, llm_mock):
        """Single-session distill response includes all expected JSON keys."""
        session = _session_store.create("teach")
        session.append("assistant", "I've noted that preference.")
        session.append("user", "I hate config files that live outside the project root.")
        sid = session.session_id

        llm_mock.messages.create.return_value = _make_distillation_response([
            {
                "content": "Config files must live in the project root",
                "node_type": "preference",
                "why": None,
                "confidence": 0.8,
                "depth": "surface",
                "upsert_node_id": None,
            }
        ])

        raw = kkanbu_distill(session_id=sid)
        data = json.loads(raw)

        assert "session_id" in data
        assert "session_type" in data
        assert "learnings_written" in data
        assert "learning_ids" in data
        assert "session_synthesis" in data
        assert "sessions_distilled" in data

# ── Sub-AC 7c: Distillation persistence — provenance metadata & entity linkage ─
# Verifies that _distill_session_to_graph writes learnings to SQLite with:
#   1. Source provenance metadata: distill_session_id, distill_session_type, distilled_at
#   2. Consistent distilled_at timestamp across all learnings from the same run
#   3. Edge inference Opus call after distillation when pre-existing entities exist
#   4. Edge inference correctly skipped when no NEW nodes are created (upsert-only runs)


class TestSubAC7cDistillPersistenceProvenance:
    """AC7c: Distilled learnings persisted with source provenance, timestamps,
    and linkage to existing graph entities."""

    @pytest.fixture(autouse=True)
    def clear_sessions(self):
        _session_store._sessions.clear()
        yield
        _session_store._sessions.clear()

    def test_distilled_node_has_provenance_metadata(self, llm_mock):
        """Distilled node metadata encodes session_id, session_type, and distilled_at so
        any graph node can be traced back to its originating conversation."""
        session = _session_store.create("curious")
        session.append("assistant", "What drives your decisions?")
        session.append("user", "I optimise for reversibility in every choice I make.")

        llm_mock.messages.create.return_value = _make_distillation_response([
            {
                "content": "Optimises for reversibility in decisions",
                "node_type": "value",
                "why": "Reduces regret and enables course-correction",
                "confidence": 0.85,
                "depth": "identity",
                "upsert_node_id": None,
            }
        ], session_synthesis="Reversibility as core decision heuristic.")

        result = _distill_session_to_graph(session)
        assert result["learnings_written"] == 1

        graph = get_graph()
        node = graph.get_node(result["learning_ids"][0])
        assert node is not None

        # Provenance metadata must be present
        meta_raw = node.get("metadata")
        assert meta_raw is not None, "Distilled node must have metadata"
        meta = json.loads(meta_raw)
        assert meta["distill_session_id"] == session.session_id
        assert meta["distill_session_type"] == "curious"
        assert "distilled_at" in meta
        assert meta["distilled_at"], "distilled_at must be a non-empty timestamp string"

    def test_distilled_node_provenance_encodes_teach_session_type(self, llm_mock):
        """Provenance metadata correctly reflects the 'teach' session type."""
        session = _session_store.create("teach")
        session.append("assistant", "Understood, recording that.")
        session.append("user", "Clarity beats cleverness in code reviews.")

        llm_mock.messages.create.return_value = _make_distillation_response([
            {
                "content": "Values clarity over cleverness in code",
                "node_type": "value",
                "why": None,
                "confidence": 0.8,
                "depth": "identity",
                "upsert_node_id": None,
            }
        ])

        result = _distill_session_to_graph(session)
        assert result["learnings_written"] == 1

        graph = get_graph()
        node = graph.get_node(result["learning_ids"][0])
        meta = json.loads(node["metadata"])
        assert meta["distill_session_type"] == "teach"
        assert meta["distill_session_id"] == session.session_id

    def test_distilled_node_timestamp_is_iso8601_utc(self, llm_mock):
        """The distilled_at timestamp in metadata follows ISO-8601 UTC format (YYYY-MM-DDTHH:MM:SSZ)."""
        import re as _re

        session = _session_store.create("answer")
        session.append("assistant", "Here is my answer.")
        session.append("user", "Actually, explicit beats implicit for me every time.")

        llm_mock.messages.create.return_value = _make_distillation_response([
            {
                "content": "Prefers explicit over implicit design choices",
                "node_type": "value",
                "why": None,
                "confidence": 0.82,
                "depth": "identity",
                "upsert_node_id": None,
            }
        ])

        result = _distill_session_to_graph(session)
        assert result["learnings_written"] == 1

        graph = get_graph()
        node = graph.get_node(result["learning_ids"][0])
        meta = json.loads(node["metadata"])
        # Must match YYYY-MM-DDTHH:MM:SSZ
        assert _re.match(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z", meta["distilled_at"]), (
            f"distilled_at {meta['distilled_at']!r} must be ISO-8601 UTC"
        )

    def test_all_learnings_from_same_run_share_distilled_at_timestamp(self, llm_mock):
        """Multiple learnings extracted in the same distillation run all share one distilled_at."""
        session = _session_store.create("curious")
        session.append("assistant", "Tell me about two important aspects of how you work.")
        session.append("user", "I value simplicity. And I love working alone for deep work.")

        llm_mock.messages.create.return_value = _make_distillation_response([
            {
                "content": "Values simplicity as a design principle",
                "node_type": "value",
                "why": None,
                "confidence": 0.85,
                "depth": "identity",
                "upsert_node_id": None,
            },
            {
                "content": "Prefers solo deep work for complex problem-solving",
                "node_type": "preference",
                "why": None,
                "confidence": 0.75,
                "depth": "identity",
                "upsert_node_id": None,
            },
        ])

        result = _distill_session_to_graph(session)
        assert result["learnings_written"] == 2

        graph = get_graph()
        timestamps = []
        for nid in result["learning_ids"]:
            node = graph.get_node(nid)
            meta = json.loads(node["metadata"])
            timestamps.append(meta["distilled_at"])

        # All nodes from the same distillation run must share the same distilled_at
        assert timestamps[0] == timestamps[1], (
            "All learnings from the same distillation run must share the same distilled_at timestamp"
        )

    def test_distill_edge_inference_called_when_preexisting_nodes_exist(self, llm_mock):
        """Edge inference Opus call fires after distillation when pre-existing nodes are
        present and at least one brand-new node was created (not just upserted)."""
        graph = get_graph()
        # Seed the graph with a pre-existing node so existing_node_ids is non-empty
        graph.add_node(
            node_type="value",
            content="Favours explicit over implicit design",
            source="teach",
            confidence=0.9,
        )

        session = _session_store.create("curious")
        session.append("assistant", "What shapes your approach to API design?")
        session.append("user", "I hate magic. Every action should be traceable.")

        distill_response = _make_distillation_response([
            {
                "content": "Distrusts magic and hidden behaviour in software",
                "node_type": "value",
                "why": "Traceability is required for debugging and reasoning",
                "confidence": 0.87,
                "depth": "identity",
                "upsert_node_id": None,  # brand-new node — triggers edge inference
            }
        ])
        # Second call: edge inference — return empty edges (valid response)
        edge_inference_msg = MagicMock()
        edge_inference_msg.content = [
            MagicMock(text='{"edges": [], "inference_notes": "No strong connections."}')
        ]
        llm_mock.messages.create.side_effect = [distill_response, edge_inference_msg]

        result = _distill_session_to_graph(session)
        assert result["learnings_written"] == 1

        # Two LLM calls: distillation + edge inference
        assert llm_mock.messages.create.call_count == 2

    def test_distill_edge_inference_skipped_when_all_nodes_upserted(self, llm_mock):
        """Edge inference is NOT called when all distilled nodes are upserts of existing
        nodes — there are no brand-new nodes to connect."""
        graph = get_graph()
        # Create the node the LLM will upsert
        existing_id = graph.add_node(
            node_type="value",
            content="Values clear naming conventions in code",
            source="teach",
            confidence=0.7,
        )

        session = _session_store.create("teach")
        session.append("assistant", "What coding conventions matter most to you?")
        session.append("user", "Names should reveal intent — I spend time on them.")

        # LLM returns a learning that upserts the existing node (no new node created)
        llm_mock.messages.create.return_value = _make_distillation_response([
            {
                "content": "Values clear naming conventions in code",
                "node_type": "value",
                "why": "Names reveal intent — worth the time investment",
                "confidence": 0.9,
                "depth": "identity",
                "upsert_node_id": existing_id,  # upsert, not create
            }
        ])

        result = _distill_session_to_graph(session)
        assert result["learnings_written"] == 1  # 1 updated node

        # Only one LLM call (distillation) — edge inference must NOT have been called
        # because no brand-new nodes were created
        llm_mock.messages.create.assert_called_once()

    def test_distill_provenance_metadata_on_upserted_node(self, llm_mock):
        """Provenance metadata is also written to nodes that are updated via upsert,
        not just brand-new nodes — every touched node carries traceability."""
        graph = get_graph()
        existing_id = graph.add_node(
            node_type="value",
            content="Values test-driven development",
            source="ingest",
            confidence=0.6,
        )

        session = _session_store.create("teach")
        session.append("assistant", "How important is testing to you?")
        session.append("user", "TDD is not optional for me — it shapes my design thinking.")

        llm_mock.messages.create.return_value = _make_distillation_response([
            {
                "content": "Values test-driven development as a design discipline",
                "node_type": "value",
                "why": "TDD shapes design thinking, not just correctness",
                "confidence": 0.92,
                "depth": "identity",
                "upsert_node_id": existing_id,
            }
        ])

        result = _distill_session_to_graph(session)
        assert result["learnings_written"] == 1

        node = graph.get_node(existing_id)
        assert node is not None
        meta_raw = node.get("metadata")
        assert meta_raw is not None, "Upserted node must also receive provenance metadata"
        meta = json.loads(meta_raw)
        assert meta["distill_session_id"] == session.session_id
        assert meta["distill_session_type"] == "teach"
        assert "distilled_at" in meta


# ── Sub-AC 5b: Opus-powered kkanbu_curious — combined graph + session context ─
# Verifies that kkanbu_curious replaces deterministic question generation with
# Opus-powered LLM calls that use BOTH the knowledge graph AND session history
# as context simultaneously.
#
# These tests are the definitive verification that the core Sub-AC 5b goal is
# met:  every Opus call for question generation receives a rich messages list
# that includes:
#   1. The full knowledge graph dump (format_graph_for_llm output)
#   2. The complete conversation history from the current session
#   3. Anti-repetition blocks listing previously asked questions
#   4. Thread-coherence directives instructing Opus to drill deeper
#
# Tests also verify that the legacy _prune_curious_sessions() wrapper and
# CURIOUS_SESSION_TIMEOUT_SECS alias have been removed (coordinator cleanup).


class TestSubAC5bCuriousOpusContext:
    """Sub-AC 5b: kkanbu_curious uses both graph knowledge and session history
    as Opus context for every question generation call."""

    @pytest.fixture(autouse=True)
    def clear_sessions(self):
        _session_store._sessions.clear()
        yield
        _session_store._sessions.clear()

    # ── 1. Graph context in Opus calls ─────────────────────────────────────

    def test_graph_nodes_appear_in_fresh_opus_prompt_after_teaching(self, llm_mock):
        """When the graph has taught knowledge, fresh kkanbu_curious passes those
        nodes to Opus so it can ask graph-grounded questions.

        This is the primary Sub-AC 5b verification: deterministic generation
        (which ignored graph content) is replaced by Opus reasoning over it.
        """
        # 1. Teach specific knowledge into the graph
        teach_resp = _make_llm_response(
            [
                {
                    "content": "I believe resilience-first design outlasts clever optimisations",
                    "node_type": "value",
                    "why": "Observed in production systems over a decade",
                    "confidence": 0.9,
                    "depth": "identity",
                },
            ],
            identity_summary="An engineer who prizes long-term resilience over short-term cleverness.",
        )
        llm_mock.messages.create.return_value = teach_resp
        kkanbu_learn("I always favour resilience over optimisation")

        # 2. Now call kkanbu_curious — Opus should receive graph context
        llm_mock.messages.create.reset_mock()
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question=(
                "You say resilience outlasts cleverness — "
                "when did you first watch a 'clever' system fail under load?"
            ),
            thread_topic="resilience identity",
            depth_level="formative",
        )
        result = kkanbu_curious()
        data = json.loads(result)

        # 3. Inspect what Opus received
        call_args = llm_mock.messages.create.call_args
        messages = call_args.kwargs.get("messages", [])
        assert messages, "Opus must receive a messages list"

        # The first (and only, for a fresh session) message is the user context block
        assert messages[0]["role"] == "user"
        context_content = messages[0]["content"]

        # Both the graph header AND the specific node content must be present
        assert "KKANBU KNOWLEDGE GRAPH" in context_content, (
            "Full graph dump must be in the Opus prompt"
        )
        assert "resilience" in context_content.lower(), (
            "The taught graph node about resilience must appear in Opus context"
        )

        # The question returned by Opus must be used as the response
        assert "resilience" in data["message"].lower() or data["message"] != ""

    def test_session_history_appears_in_follow_up_opus_call(self, llm_mock):
        """For a follow-up kkanbu_curious call, the Opus messages list includes
        the FULL prior conversation history (Q1 + A1) so it can drill deeper.

        Core Sub-AC 5b requirement: session state is the source, not a stateless
        per-call deterministic generator.
        """
        q1 = "When did you first prioritise simplicity over correctness?"
        a1 = "Early on, when I shipped a 'correct' but unusable feature to prod."

        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(question=q1, thread_topic="simplicity identity"),
            _make_curious_llm_response(
                question="What did that 'unusable' feature teach you about what software is actually for?",
                thread_topic="simplicity identity",
            ),
        ]

        # Turn 1 — fresh session
        r1 = kkanbu_curious()
        sid = json.loads(r1)["session_id"]

        # Turn 2 — follow-up; capture the Opus call
        llm_mock.messages.create.reset_mock(side_effect=False)
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question="What did that teach you about what software is actually for?",
            thread_topic="simplicity identity",
        )
        kkanbu_curious(session_id=sid, user_response=a1)

        # Sub-AC 9c: first call after reset = question gen; second = distillation.
        # Use call_args_list[0] to inspect the question-gen Opus call.
        call_args = llm_mock.messages.create.call_args_list[0]
        messages = call_args.kwargs.get("messages", [])

        # Must be multi-turn: at minimum [context, assistant(Q1), user(A1+cue)]
        assert len(messages) >= 3, (
            f"Follow-up must produce multi-turn messages; got {len(messages)}: "
            + str([m["role"] for m in messages])
        )

        # Entire message chain must contain Q1 and A1
        all_content = " ".join(m["content"] for m in messages)
        assert q1 in all_content, "Prior question Q1 must be in follow-up Opus messages"
        assert a1 in all_content, "User answer A1 must be in follow-up Opus messages"

        # Knowledge graph context must ALSO be present (in the first message).
        # Works for both empty graphs ("KNOWLEDGE GRAPH: empty") and populated
        # graphs ("=== KKANBU KNOWLEDGE GRAPH CONTEXT ===").
        first_msg_lower = messages[0]["content"].lower()
        assert "knowledge graph" in first_msg_lower, (
            "Graph context (empty or populated) must appear in the context message "
            "even for follow-up calls — it is always passed to Opus"
        )

    def test_both_graph_and_session_history_in_follow_up_simultaneously(self, llm_mock):
        """The follow-up Opus call combines BOTH graph knowledge AND session history
        in the same messages list — this is the exact replacement of the old
        deterministic approach which used neither.
        """
        # Seed graph with specific knowledge
        teach_resp = _make_llm_response(
            [
                {
                    "content": "I default to boring technology in production",
                    "node_type": "value",
                    "why": "Reliability > novelty for systems that need to run overnight",
                    "confidence": 0.88,
                    "depth": "identity",
                },
            ]
        )
        llm_mock.messages.create.return_value = teach_resp
        kkanbu_learn("I always reach for boring, proven tech in production")

        # Now start a curious session
        llm_mock.messages.create.reset_mock()
        q1 = "When did your bias toward boring tech save you from a disaster?"
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question=q1, thread_topic="boring technology value"
        )
        r1 = kkanbu_curious()
        sid = json.loads(r1)["session_id"]

        # Follow-up
        user_ans = "I chose Postgres over a shiny new graph DB and it handled Black Friday fine."
        llm_mock.messages.create.reset_mock()
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question="What does 'fine' mean to you — what would failure have looked like?",
            thread_topic="boring technology value",
        )
        kkanbu_curious(session_id=sid, user_response=user_ans)

        # Sub-AC 9c: first call after reset = question gen; second = distillation.
        # Use call_args_list[0] to inspect the question-gen Opus call.
        call_args = llm_mock.messages.create.call_args_list[0]
        messages = call_args.kwargs.get("messages", [])
        all_content = " ".join(m["content"] for m in messages)

        # Graph content must be present
        assert "KKANBU KNOWLEDGE GRAPH" in messages[0]["content"], (
            "Graph dump must be in Opus context for follow-up"
        )
        # At least one graph node topic must appear (taught 'boring technology')
        assert "boring" in all_content.lower(), (
            "Taught graph knowledge (boring technology) must appear in Opus context"
        )

        # Session history must be present
        assert q1 in all_content, "Prior question must be in follow-up messages"
        assert user_ans in all_content, "User response must be in follow-up messages"

    # ── 2. Anti-repetition block in Opus prompts ───────────────────────────

    def test_questions_asked_block_appears_in_fresh_session_when_prior_questions_exist(
        self, llm_mock
    ):
        """questions_asked are passed to Opus in the fresh session prompt so it
        can avoid repeating questions that were already asked in a previous session
        that was re-used (or explicitly pre-seeded).
        """
        # Manually pre-seed the session with a prior question
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question="What does your most-used keyboard shortcut reveal about you?",
            thread_topic="habits identity",
        )

        session, _ = _session_store.get_or_create(None, "curious")
        prior_q = "What made you choose software over other paths you could have taken?"
        session.questions_asked.append(prior_q)
        sid = session.session_id

        # Call kkanbu_curious continuing this session (it has questions_asked but is_fresh)
        kkanbu_curious(session_id=sid)

        call_args = llm_mock.messages.create.call_args
        messages = call_args.kwargs.get("messages", [])
        first_msg = messages[0]["content"] if messages else ""

        # The prior question must appear in the anti-repeat block
        assert prior_q in first_msg, (
            "questions_asked must be included in the Opus prompt to prevent repetition"
        )

    def test_questions_asked_in_continuing_session_includes_all_prior_questions(
        self, llm_mock
    ):
        """After multiple turns, all prior questions from the session appear in the
        Opus anti-repetition block for the next call.
        """
        q1 = "When did simplicity become a value rather than just a preference?"
        q2 = "What does that formative moment tell you about your mental model of software?"
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(question=q1, thread_topic="simplicity"),
            _make_curious_llm_response(question=q2, thread_topic="simplicity"),
        ]

        r1 = kkanbu_curious()
        sid = json.loads(r1)["session_id"]
        kkanbu_curious(session_id=sid, user_response="I realised it after my first failed rewrite.")

        # Capture the second call's messages
        call_args = llm_mock.messages.create.call_args
        messages = call_args.kwargs.get("messages", [])
        first_msg = messages[0]["content"] if messages else ""

        # Both questions (q1 asked in turn 1, q2 being asked now) must appear
        # q1 must be in the anti-repeat block in the continuing session context
        assert q1 in first_msg, "Q1 must appear in the Opus context to avoid repetition"

    # ── 3. Thread-coherence directive ──────────────────────────────────────

    def test_drill_deeper_directive_in_follow_up_messages(self, llm_mock):
        """The follow-up messages include an explicit 'drill deeper' instruction
        so Opus stays on the same thread rather than jumping to unrelated topics.
        """
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(question="Q1?", thread_topic="autonomy"),
            _make_curious_llm_response(question="Q2 deeper?", thread_topic="autonomy"),
        ]

        r1 = kkanbu_curious()
        sid = json.loads(r1)["session_id"]

        llm_mock.messages.create.reset_mock(side_effect=False)
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question="Q2 deeper?", thread_topic="autonomy"
        )
        kkanbu_curious(session_id=sid, user_response="I need space to think.")

        call_args = llm_mock.messages.create.call_args
        messages = call_args.kwargs.get("messages", [])
        all_content = " ".join(m["content"] for m in messages)

        # The drill-deeper directive must appear somewhere in the messages
        assert "deeper" in all_content.lower(), (
            "Follow-up messages must include a 'drill deeper' directive to prevent topic scatter"
        )

    def test_thread_topic_stored_and_passed_to_opus_on_follow_up(self, llm_mock):
        """The thread_topic from the first call is stored in session state and
        used to anchor the Opus prompt for follow-up calls.
        """
        thread = "identity under pressure"
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(
                question="When did you last change your mind under time pressure?",
                thread_topic=thread,
            ),
            _make_curious_llm_response(
                question="What does that reveal about your decision-making defaults?",
                thread_topic=thread,
            ),
        ]

        r1 = kkanbu_curious()
        sid = json.loads(r1)["session_id"]

        # Verify thread_topic is stored
        session = _session_store.get(sid)
        assert session is not None
        assert session.thread_topic == thread

        # Follow-up
        llm_mock.messages.create.reset_mock(side_effect=False)
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question="What does that reveal about your decision-making defaults?",
            thread_topic=thread,
        )
        kkanbu_curious(session_id=sid, user_response="I defaulted to safety.")

        # Sub-AC 9c: first call after reset = question gen; second = distillation.
        # Use call_args_list[0] to inspect the question-gen Opus call.
        call_args = llm_mock.messages.create.call_args_list[0]
        messages = call_args.kwargs.get("messages", [])
        first_msg = messages[0]["content"] if messages else ""

        # Thread topic must appear in the context message
        assert thread in first_msg, (
            f"thread_topic '{thread}' must appear in the Opus context for follow-up calls"
        )

    # ── 4. Legacy cleanup verification ─────────────────────────────────────

    def test_prune_curious_sessions_no_longer_exported(self):
        """_prune_curious_sessions() wrapper has been removed — it was a legacy
        indirection that has been replaced by direct _distill_and_prune_stale_sessions()
        calls in all tool handlers (coordinator cleanup from Sub-AC 5b).
        """
        import kkanbu.server as srv
        assert not hasattr(srv, "_prune_curious_sessions"), (
            "_prune_curious_sessions is a removed legacy function; "
            "all callers now use _distill_and_prune_stale_sessions() directly"
        )

    def test_curious_session_timeout_alias_no_longer_exported(self):
        """CURIOUS_SESSION_TIMEOUT_SECS backward-compat alias has been removed.
        Use SESSION_TIMEOUT_SECS from kkanbu.session directly.
        """
        import kkanbu.server as srv
        assert not hasattr(srv, "CURIOUS_SESSION_TIMEOUT_SECS"), (
            "CURIOUS_SESSION_TIMEOUT_SECS is a removed legacy alias; "
            "use SESSION_TIMEOUT_SECS from kkanbu.session instead"
        )

    def test_extract_keywords_uses_retrieval_module_implementation(self):
        """_extract_keywords in server.py is now the retrieval.extract_keywords
        function (imported with an alias), eliminating the duplicate definition
        with no deduplication.  The retrieval version deduplicates results.
        """
        import kkanbu.server as srv
        from kkanbu.retrieval import extract_keywords as retrieval_extract

        # The imported _extract_keywords must be the same object as retrieval.extract_keywords
        assert srv._extract_keywords is retrieval_extract, (
            "server._extract_keywords must be retrieval.extract_keywords — "
            "the local duplicate definition should have been removed"
        )

    def test_curious_prune_calls_distill_and_prune_not_legacy_wrapper(self, llm_mock):
        """When kkanbu_curious is called, stale sessions are handled via
        _distill_and_prune_stale_sessions() — not the legacy _prune_curious_sessions().
        Verifies that the call chain is correct after the cleanup.
        """
        import kkanbu.server as srv

        called = []

        original = srv._distill_and_prune_stale_sessions

        def _spy(*args, **kwargs):
            called.append("distill_and_prune")
            return original(*args, **kwargs)

        srv._distill_and_prune_stale_sessions = _spy

        try:
            llm_mock.messages.create.return_value = _make_curious_llm_response()
            kkanbu_curious()
            assert "distill_and_prune" in called, (
                "kkanbu_curious must call _distill_and_prune_stale_sessions() "
                "(not the removed _prune_curious_sessions wrapper)"
            )
        finally:
            srv._distill_and_prune_stale_sessions = original


# ── Sub-AC 9a: Session state for stateful follow-up question generation ────────
#
# AC 9: kkanbu_curious produces at least one question that genuinely surprises the user.
# Sub-AC 9a verifies that the server-side session state enables that by tracking:
#   1. Conversation history (history list) — enables Opus to build on prior exchanges
#   2. Previously asked questions (questions_asked) — prevents repetition across turns
#   3. Thread topic and topics explored — keeps follow-ups coherent, not scattered
#
# Distinguishing from Sub-AC 5a (CRUD) and Sub-AC 5b (Opus context):
#   - Sub-AC 5a: confirms session exists and stores data
#   - Sub-AC 5b: confirms graph + history reach Opus
#   - Sub-AC 9a (this class): confirms the session state ENABLES FOLLOW-UP QUALITY
#     by testing edge cases and flows that directly affect surprising question generation


class TestSubAC9aSessionStateFollowUps:
    """Sub-AC 9a: server-side session state tracks conversation history and
    previously asked questions to enable stateful follow-up question generation."""

    @pytest.fixture(autouse=True)
    def clear_sessions(self):
        _session_store._sessions.clear()
        yield
        _session_store._sessions.clear()

    # ── 1. Session initial state ─────────────────────────────────────────────

    def test_new_session_has_empty_questions_asked_and_history(self, llm_mock):
        """A brand-new curious session starts with no history and no questions_asked.
        This baseline matters because the follow-up machinery reads these lists
        to build anti-repetition blocks — they must start clean per session.
        """
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question="What shaped your relationship with uncertainty in software?"
        )
        data = json.loads(kkanbu_curious())
        sid = data["session_id"]

        # Session is created by the call, but BEFORE the call the lists were empty
        # (the question is added AFTER the LLM call, so this checks the clean-start guarantee)
        session = _session_store.get(sid)
        assert session is not None
        # After first call: exactly one question in questions_asked (the one just asked)
        assert len(session.questions_asked) == 1
        # History has exactly one message: the assistant question
        assert len(session.history) == 1
        assert session.history[0].role == "assistant"

    def test_new_session_is_fresh_before_first_question_sent(self, llm_mock):
        """A session created via get_or_create has is_fresh=True (turn_count=0)
        until kkanbu_curious sends the first assistant message.
        Callers that access the session between creation and first question see turn=0.
        """
        # Create session explicitly before calling kkanbu_curious
        pre_session, _ = _session_store.get_or_create(None, "curious")
        pre_sid = pre_session.session_id

        # Session is fresh — no assistant turns yet
        assert pre_session.is_fresh is True
        assert pre_session.turn_count == 0
        assert pre_session.questions_asked == []
        assert pre_session.history == []

    # ── 2. Anti-repetition tracking ─────────────────────────────────────────

    def test_questions_asked_capped_at_ten_in_anti_repeat_block(self, llm_mock):
        """When more than 10 questions have been asked, only the LAST 10 are passed
        to Opus in the anti-repetition block (the code uses questions_asked[-10:]).
        This prevents the context from growing unbounded while still protecting
        against repetition of recent questions.
        """
        # Create a session with 12 pre-existing questions
        session, _ = _session_store.get_or_create(None, "curious")
        sid = session.session_id
        for i in range(12):
            session.questions_asked.append(f"Old question {i}?")
            session.history.append(
                __import__("kkanbu.session", fromlist=["MessageRecord"]).MessageRecord(
                    role="assistant", content=f"Old question {i}?"
                )
            )

        new_q = "What does your fear of failure tell you about your identity?"
        llm_mock.messages.create.reset_mock()
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question=new_q, thread_topic="failure identity"
        )
        # Continue the session (is_fresh=False since history has assistant messages)
        kkanbu_curious(session_id=sid, user_response="I reflect on this often.")

        # Sub-AC 9c: first call after reset = question gen; second = distillation.
        # Use call_args_list[0] to inspect the question-gen Opus call.
        call_args = llm_mock.messages.create.call_args_list[0]
        messages = call_args.kwargs.get("messages", [])
        first_msg_content = messages[0]["content"] if messages else ""

        # questions_asked[-10:] with 12 items = indices 2-11 (last 10).
        # Indices 0 and 1 are cut off; indices 2-11 are included.
        assert "Old question 0?" not in first_msg_content, (
            "Questions older than the last 10 must be excluded from the anti-repeat block"
        )
        assert "Old question 1?" not in first_msg_content, (
            "Only the last 10 questions are passed to Opus; index 1 of 12 is excluded"
        )
        # But questions within the last 10 (indices 2-11) must appear
        assert "Old question 2?" in first_msg_content, (
            "Index 2 of 12 is within the last 10 and must appear in the anti-repeat block"
        )
        assert "Old question 11?" in first_msg_content, (
            "The most recent question must always appear in the anti-repeat block"
        )

    def test_questions_asked_sent_to_opus_on_continuing_session(self, llm_mock):
        """When continuing a session, the questions already asked appear in the Opus
        context to prevent repetition.  This is the core anti-repetition guarantee.
        """
        q1 = "When did simplicity become non-negotiable for you?"
        q2 = "What compromised your values made you solidify that position?"

        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(question=q1, thread_topic="simplicity core"),
            _make_curious_llm_response(question=q2, thread_topic="simplicity core"),
        ]

        r1 = kkanbu_curious()
        sid = json.loads(r1)["session_id"]

        # Reset mock tracking so we can inspect just the second call
        llm_mock.messages.create.reset_mock(side_effect=False)
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question=q2, thread_topic="simplicity core"
        )
        kkanbu_curious(session_id=sid, user_response="When I hit a project that burned out my team.")

        # Inspect turn-2 Opus call
        call_args = llm_mock.messages.create.call_args
        messages = call_args.kwargs.get("messages", [])
        first_msg_content = messages[0]["content"] if messages else ""

        # Q1 must be in the anti-repeat block to prevent Opus from re-asking it
        assert q1 in first_msg_content, (
            f"Q1 ({q1!r}) must appear in the continuing session Opus context "
            "as part of the anti-repetition block"
        )

    # ── 3. History continuity across follow-ups ──────────────────────────────

    def test_five_turn_session_preserves_full_state(self, llm_mock):
        """A 5-turn session maintains the complete conversation history and
        questions_asked list throughout, enabling Opus to always see the full arc.
        Validates robustness beyond the 3-turn tests that already exist.
        """
        questions = [
            "What shaped your earliest assumptions about collaboration?",
            "Has that assumption ever been proven wrong in a way that stuck?",
            "What did you do differently after that realisation?",
            "Is there a tension between that lesson and how you work today?",
            "What would it cost you to fully resolve that tension?",
        ]
        # Sub-AC 9c: each follow-up call (turns 2-5) makes 1 extra distillation LLM
        # call after generating the question.  Provide 9 mock responses:
        # q1, q2, distill-2, q3, distill-3, q4, distill-4, q5, distill-5.
        distill_stub = _make_curious_llm_response(
            question="stub", thread_topic="collaboration identity"
        )
        question_resps = [
            _make_curious_llm_response(question=q, thread_topic="collaboration identity")
            for q in questions
        ]
        side_effect_list = [
            question_resps[0],   # Turn 1: question
            question_resps[1],   # Turn 2: question
            distill_stub,        # Turn 2: distillation (0 learnings — no "learnings" key)
            question_resps[2],   # Turn 3: question
            distill_stub,        # Turn 3: distillation
            question_resps[3],   # Turn 4: question
            distill_stub,        # Turn 4: distillation
            question_resps[4],   # Turn 5: question
            distill_stub,        # Turn 5: distillation
        ]
        llm_mock.messages.create.side_effect = side_effect_list

        r1 = kkanbu_curious()
        sid = json.loads(r1)["session_id"]

        for i in range(1, 5):
            kkanbu_curious(session_id=sid, user_response=f"Answer to turn {i}.")

        session = _session_store.get(sid)
        assert session is not None

        # All 5 questions tracked for anti-repetition
        assert len(session.questions_asked) == 5
        for q in questions:
            assert q in session.questions_asked

        # History has 5 assistant + 4 user = 9 messages
        # (first turn: no user message; turns 2-5: user + assistant each)
        assert len(session.history) == 9
        roles = [m.role for m in session.history]
        assert roles.count("assistant") == 5
        assert roles.count("user") == 4

        # Turn counter matches
        assert session.turn_count == 5

    # ── 4. Ephemeral isolation from knowledge graph ──────────────────────────

    def test_session_history_not_written_to_knowledge_graph(self, llm_mock):
        """Conversation history (the raw Q&A transcript) MUST NOT appear as nodes
        in the knowledge graph.  Only distilled learnings reach the graph — never
        raw session history.  This enforces the ephemeral-conversation architecture.
        """
        q = "When did you first feel that documentation was a form of respect?"
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question=q, thread_topic="documentation respect"
        )
        r1 = kkanbu_curious()
        sid = json.loads(r1)["session_id"]

        # Provide a user response so there's meaningful content in history
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question="Follow-up: What does that respect look like in practice?",
            thread_topic="documentation respect",
        )
        kkanbu_curious(session_id=sid, user_response="I write docs the way I wish I'd had them.")

        # Check knowledge graph for any node that contains the raw conversation text
        graph = get_graph()
        all_nodes = graph.get_all_by_type("preference") + graph.get_all_by_type("value") + \
                    graph.get_all_by_type("pattern") + graph.get_all_by_type("observation")

        # The exact question text and raw user response must NOT appear as graph nodes
        raw_history_fragments = [
            "When did you first feel that documentation",
            "I write docs the way I wish I'd had them",
        ]
        for node in all_nodes:
            content = node.get("content", "")
            for fragment in raw_history_fragments:
                assert fragment not in content, (
                    f"Raw conversation history fragment {fragment!r} found in graph node — "
                    "session history must remain ephemeral and never be written directly"
                )

        # Session history IS in memory
        session = _session_store.get(sid)
        assert session is not None
        assert len(session.history) >= 1

    # ── 5. Session identity and routing ──────────────────────────────────────

    def test_session_type_is_curious_for_stateful_follow_ups(self, llm_mock):
        """Sessions created by kkanbu_curious are typed as 'curious', which ensures
        correct routing for auto-distillation and session management.
        """
        llm_mock.messages.create.return_value = _make_curious_llm_response()
        data = json.loads(kkanbu_curious())

        session = _session_store.get(data["session_id"])
        assert session is not None
        assert session.session_type == "curious", (
            "Session type must be 'curious' for correct routing in distillation pipeline"
        )

    def test_session_id_returned_in_json_is_the_continuation_key(self, llm_mock):
        """The session_id field in the JSON response is the key that enables continuation.
        Callers must echo this back as session_id to get stateful follow-up questions.
        This test confirms the complete follow-up pathway: create → session_id → continue.
        """
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(question="Q1: deep identity question?"),
            _make_curious_llm_response(question="Q2: even deeper follow-up?"),
        ]

        # First call: no session_id → new session
        r1 = json.loads(kkanbu_curious())
        sid = r1["session_id"]
        assert r1["is_new_session"] is True
        assert r1["turn"] == 1

        # Second call: echo back the session_id → continuation
        r2 = json.loads(kkanbu_curious(session_id=sid, user_response="My reflection on Q1."))
        assert r2["session_id"] == sid, "session_id must remain stable across calls"
        assert r2["is_new_session"] is False
        assert r2["turn"] == 2

        # Session in store has 3 messages: asst Q1, user response, asst Q2
        session = _session_store.get(sid)
        assert session is not None
        assert len(session.questions_asked) == 2
        assert len(session.history) == 3

    def test_two_concurrent_sessions_have_isolated_state(self, llm_mock):
        """Multiple concurrent sessions are fully isolated — different users/contexts
        cannot contaminate each other's question lists or history.
        This isolation is what makes the anti-repetition mechanism reliable.
        """
        qa = "What do you believe about software that most people you respect would disagree with?"
        qb = "When did you realise that simplicity is not just aesthetic but ethical?"
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(question=qa, thread_topic="contrarian beliefs"),
            _make_curious_llm_response(question=qb, thread_topic="simplicity ethics"),
        ]

        ra = json.loads(kkanbu_curious())
        rb = json.loads(kkanbu_curious())

        sid_a = ra["session_id"]
        sid_b = rb["session_id"]
        assert sid_a != sid_b, "Each call without session_id must produce a unique session"

        sa = _session_store.get(sid_a)
        sb = _session_store.get(sid_b)
        assert sa is not None and sb is not None

        # Each session's questions_asked contains only its own question
        assert qa in sa.questions_asked
        assert qb not in sa.questions_asked, "Session A must not see Session B's questions"
        assert qb in sb.questions_asked
        assert qa not in sb.questions_asked, "Session B must not see Session A's questions"

    # ── 6. Session timeout lifecycle ────────────────────────────────────────

    def test_expired_session_id_triggers_new_session(self, llm_mock):
        """If a session expires (exceeds timeout), passing the old session_id to
        kkanbu_curious creates a NEW session rather than continuing the old one.
        This ensures that a stale conversation never silently pollutes a new one
        with old questions_asked that are no longer relevant.
        """
        import time

        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question="What shaped your early mental model of software?"
        )
        r1 = json.loads(kkanbu_curious())
        sid = r1["session_id"]

        # Expire the session by backdating its last_active
        session = _session_store.get(sid)
        assert session is not None
        session.last_active = time.time() - (_session_store.timeout_secs + 10)

        # Next call with the expired session_id must start fresh
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question="Fresh question for a new session?"
        )
        r2 = json.loads(kkanbu_curious(session_id=sid, user_response="Trying to continue."))

        assert r2["is_new_session"] is True, (
            "Expired session_id must not continue the old session; a new one must be created"
        )
        # New session has no prior questions_asked
        new_session = _session_store.get(r2["session_id"])
        assert new_session is not None
        # The new session should only have 1 question (from this call)
        assert len(new_session.questions_asked) == 1


# ── Sub-AC 5c: Drill-deeper coherence scoring ─────────────────────────────────
#
# Implements a deterministic token-overlap filter that scores generated questions
# against the established conversational thread.  A question that drifts to an
# unrelated topic (coherence score < _COHERENCE_THRESHOLD) is rejected with a
# coherence note and Opus is asked once more to stay on thread.
#
# Three layers of tests:
#   1. Unit tests for _score_question_coherence() (pure scoring function)
#   2. Unit tests for _is_off_thread() (threshold gate)
#   3. Integration tests for the coherence gate inside kkanbu_curious()


class TestSubAC5cDrillDeeperCoherence:
    """Sub-AC 5c: coherence scoring ensures follow-up questions deepen a single
    thread rather than scatter across unrelated topics."""

    @pytest.fixture(autouse=True)
    def clear_sessions(self):
        _session_store._sessions.clear()
        yield
        _session_store._sessions.clear()

    # ── 1. Unit tests for _score_question_coherence() ───────────────────────

    def test_score_returns_one_for_empty_session_thread(self):
        """When no thread is established (fresh session), coherence score is 1.0
        — every question is trivially coherent when there is no prior thread."""
        from kkanbu.server import _score_question_coherence

        score = _score_question_coherence(
            question="What shaped your earliest thinking about software?",
            session_thread_topic="",
            new_thread_topic="formative influences",
        )
        assert score == 1.0, (
            "Empty session_thread_topic must return 1.0 — no thread to be coherent with"
        )

    def test_score_high_for_question_sharing_thread_keywords(self):
        """A question that contains one or more keywords from the thread topic scores
        >= _COHERENCE_THRESHOLD and is treated as on-thread."""
        from kkanbu.server import _score_question_coherence, _COHERENCE_THRESHOLD

        # Thread: "resilience identity" — question mentions "resilience"
        score = _score_question_coherence(
            question="How did your commitment to resilience shape your identity as an engineer?",
            session_thread_topic="resilience identity",
            new_thread_topic="resilience identity",
        )
        assert score >= _COHERENCE_THRESHOLD, (
            f"Score {score:.2f} must be >= {_COHERENCE_THRESHOLD} when question "
            "contains keywords from the thread topic"
        )

    def test_score_low_for_completely_unrelated_question(self):
        """A question with no token overlap with the established thread scores below
        _COHERENCE_THRESHOLD and should be flagged for retry."""
        from kkanbu.server import _score_question_coherence, _COHERENCE_THRESHOLD

        # Thread: "resilience identity" — question is about Python frameworks
        score = _score_question_coherence(
            question="Which testing framework do you reach for first?",
            session_thread_topic="resilience identity",
            new_thread_topic="tooling preferences",
        )
        assert score < _COHERENCE_THRESHOLD, (
            f"Score {score:.2f} must be < {_COHERENCE_THRESHOLD} when question "
            "has no keyword overlap with the established thread"
        )

    def test_score_uses_new_thread_topic_as_secondary_overlap_source(self):
        """When the question itself does not contain thread keywords but the proposed
        new_thread_topic does, the score should still be high (synonym/label continuity).

        This handles the common case where Opus expresses continuity in the thread
        label (e.g. 'resilience philosophy') even when the question uses synonyms.
        """
        from kkanbu.server import _score_question_coherence, _COHERENCE_THRESHOLD

        # Thread: "resilience identity"
        # Question: uses antonym "fragility" instead of "resilience" directly
        # BUT new_thread_topic contains "resilience" → should still pass
        score = _score_question_coherence(
            question="When did fragility in a system first make you viscerally uncomfortable?",
            session_thread_topic="resilience identity",
            new_thread_topic="resilience formative",  # contains "resilience" → overlap
        )
        assert score >= _COHERENCE_THRESHOLD, (
            f"Score {score:.2f} must be >= {_COHERENCE_THRESHOLD} when new_thread_topic "
            "maintains keyword overlap with the established thread (synonym path)"
        )

    def test_score_returns_one_for_degenerate_thread_with_only_stopwords(self):
        """A thread topic consisting entirely of stop words has no meaningful tokens;
        the score defaults to 1.0 to avoid falsely rejecting any question."""
        from kkanbu.server import _score_question_coherence

        score = _score_question_coherence(
            question="What do you believe about software?",
            session_thread_topic="the and of",  # all stop words → no meaningful tokens
            new_thread_topic="beliefs",
        )
        assert score == 1.0, (
            "Degenerate thread topic (only stop words) must return 1.0 to avoid false rejections"
        )

    def test_score_is_bounded_between_zero_and_one(self):
        """Coherence score must always be in [0.0, 1.0]."""
        from kkanbu.server import _score_question_coherence

        cases = [
            # Perfect overlap
            ("resilience identity", "resilience identity", "resilience identity"),
            # Zero overlap
            ("resilience identity", "python framework tools", "testing tooling"),
            # Partial overlap
            ("simplicity clarity values", "clarity and honesty above all", "clarity honesty"),
        ]
        for session_thread, question, new_thread in cases:
            score = _score_question_coherence(question, session_thread, new_thread)
            assert 0.0 <= score <= 1.0, (
                f"Score {score} is out of [0, 1] for thread='{session_thread}'"
            )

    # ── 2. Unit tests for _is_off_thread() ──────────────────────────────────

    def test_is_off_thread_returns_false_for_empty_session_thread(self):
        """When no session thread is established, _is_off_thread returns False
        so fresh-session questions are never blocked by the coherence gate."""
        from kkanbu.server import _is_off_thread

        result = _is_off_thread(
            question="What shaped your relationship with software early on?",
            session_thread_topic="",
            new_thread_topic="formative influences",
        )
        assert result is False, (
            "_is_off_thread must return False when session_thread_topic is empty"
        )

    def test_is_off_thread_returns_false_for_coherent_question(self):
        """A question that shares keyword(s) with the thread is on-thread."""
        from kkanbu.server import _is_off_thread

        result = _is_off_thread(
            question="What moment crystallised your commitment to resilience over cleverness?",
            session_thread_topic="resilience identity",
            new_thread_topic="resilience values",
        )
        assert result is False, (
            "On-thread question (shared keyword 'resilience') must not be flagged as off-thread"
        )

    def test_is_off_thread_returns_true_for_scattered_question(self):
        """A question with no keyword overlap is off-thread and should be flagged."""
        from kkanbu.server import _is_off_thread

        result = _is_off_thread(
            question="Which Python testing libraries do you reach for first?",
            session_thread_topic="resilience identity",
            new_thread_topic="tooling preferences",
        )
        assert result is True, (
            "Off-thread question (zero keyword overlap) must be flagged as off-thread"
        )

    # ── 3. Integration tests: coherence gate in kkanbu_curious() ────────────

    def test_coherence_gate_not_applied_on_fresh_session(self, llm_mock):
        """The coherence gate is NOT triggered on the first call (is_fresh=True)
        because there is no established thread to be coherent with."""
        # Use a question that would fail the coherence gate if it were applied
        # (no overlap with any established thread), but must pass on a fresh session.
        # NOTE: avoid surface-pattern triggers (e.g. "do you prefer") in the question.
        question = "What does quality mean to your craft as an engineer?"
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question=question,
            thread_topic="craft philosophy",
            depth_level="identity",
        )
        result = kkanbu_curious()
        data = json.loads(result)

        # Gate should not fire (only 1 LLM call, not 2 from a retry)
        assert llm_mock.messages.create.call_count == 1, (
            "Fresh session must not trigger coherence gate retry (no prior thread exists)"
        )
        assert data["message"] == question

    def test_coherence_gate_not_applied_when_no_session_thread(self, llm_mock):
        """Even in a continuing session, if session.thread_topic is empty the coherence
        gate is skipped (degenerate case — treat as on-thread)."""
        # Create a session without a thread_topic
        session, _ = _session_store.get_or_create(None, "curious")
        sid = session.session_id
        # Manually add an assistant turn so is_fresh = False
        from kkanbu.session import MessageRecord
        session.history.append(MessageRecord(role="assistant", content="Initial question?"))
        session.questions_asked.append("Initial question?")
        # Explicitly leave session.thread_topic = "" (default)

        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question="Scattered question about unrelated topic?",
            thread_topic="some new topic",
            depth_level="identity",
        )
        kkanbu_curious(session_id=sid, user_response="My reply.")

        # Sub-AC 9c: after the question is generated, an eager distillation LLM call
        # is made (1 question-gen call + 1 distillation call = 2 total).
        # The coherence gate is NOT triggered — call count is 2, not 3.
        assert llm_mock.messages.create.call_count == 2, (
            "Coherence gate must be skipped when session.thread_topic is empty; "
            "call count is 2 (1 question-gen + 1 eager distillation)"
        )

    def test_off_thread_question_triggers_retry_on_continuing_session(self, llm_mock):
        """When a continuing session has an established thread and Opus generates a
        question with no keyword overlap, the coherence gate fires and a retry is
        requested with an explicit stay-on-thread instruction."""
        # Turn 1: establish thread "resilience identity"
        q1 = "When did resilience first become your identity as an engineer?"
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(
                question=q1,
                thread_topic="resilience identity",
                depth_level="formative",
            ),
        ]
        r1 = json.loads(kkanbu_curious())
        sid = r1["session_id"]
        assert r1["thread_topic"] == "resilience identity"

        # Turn 2: Opus first returns an off-thread question (tooling), then a proper one
        off_thread_q = "Which Python testing libraries do you reach for?"
        on_thread_q = "What does 'resilient' mean to you beyond code — does it extend to relationships?"
        llm_mock.messages.create.reset_mock(side_effect=False)
        llm_mock.messages.create.side_effect = [
            # First attempt: off-thread (tooling vs "resilience identity")
            _make_curious_llm_response(
                question=off_thread_q,
                thread_topic="tooling preferences",
                depth_level="identity",
                novelty_rationale="Connects tool choices to personal philosophy in an unexpected way.",
            ),
            # Retry: on-thread follow-up about resilience
            _make_curious_llm_response(
                question=on_thread_q,
                thread_topic="resilience identity",
                depth_level="identity",
                novelty_rationale="Extends resilience from code to life — an unarticulated connection.",
            ),
        ]
        r2 = json.loads(kkanbu_curious(session_id=sid, user_response="I learned resilience from production incidents."))

        # Sub-AC 9c: after the question is generated (2 calls: initial + coherence retry),
        # an eager distillation call is made.  Total = 3 calls (2 question-gen + 1 distill).
        assert llm_mock.messages.create.call_count == 3, (
            "Off-thread question must trigger exactly one coherence-gate retry; "
            "total calls = 3 (off-thread attempt + on-thread retry + eager distillation)"
        )
        # The final question returned should be the retry (on-thread) version
        assert r2["message"] == on_thread_q, (
            "After coherence retry, the on-thread question must be returned"
        )

    def test_on_thread_question_passes_coherence_gate_without_retry(self, llm_mock):
        """A follow-up question that shares keywords with the established thread
        passes the coherence gate without triggering a retry."""
        # Turn 1: establish thread "simplicity values"
        q1 = "When did simplicity become a core value for you?"
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(
                question=q1,
                thread_topic="simplicity values",
                depth_level="identity",
            ),
        ]
        r1 = json.loads(kkanbu_curious())
        sid = r1["session_id"]

        # Turn 2: on-thread question about simplicity
        # Reset call_count so we can assert exactly 1 Opus call for THIS turn.
        # Also clear the exhausted side_effect iterator from turn 1.
        q2 = "What complexity did you have to accept to maintain your commitment to simplicity?"
        llm_mock.messages.create.reset_mock()   # resets call_count → 0
        llm_mock.messages.create.side_effect = None  # clear exhausted iterator
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question=q2,
            thread_topic="simplicity identity",
            depth_level="identity",
            novelty_rationale="Probes the cost of a deeply held simplicity value — rarely articulated.",
        )
        r2 = json.loads(kkanbu_curious(session_id=sid, user_response="I have always valued elegance."))

        # Sub-AC 9c: 1 question-gen call (no retry since on-thread) + 1 distillation = 2 total.
        assert llm_mock.messages.create.call_count == 2, (
            "On-thread question must pass the coherence gate without triggering a retry; "
            "call count is 2 (1 question-gen + 1 eager distillation)"
        )
        assert r2["message"] == q2

    def test_coherence_retry_message_includes_stay_on_thread_instruction(self, llm_mock):
        """When the coherence gate fires, the retry messages list includes the reject reason
        describing which thread to stay on, so Opus has explicit guidance."""
        # Turn 1: establish thread "autonomy philosophy"
        q1 = "When did autonomy first become a philosophy for you?"
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(
                question=q1,
                thread_topic="autonomy philosophy",
                depth_level="identity",
            ),
        ]
        r1 = json.loads(kkanbu_curious())
        sid = r1["session_id"]

        # Turn 2: off-thread response triggers coherence retry
        off_q = "Which IDE plugins do you find most useful daily?"
        on_q = "How has your philosophy of autonomy shaped the teams you have worked with?"
        llm_mock.messages.create.reset_mock(side_effect=False)
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(
                question=off_q,
                thread_topic="tooling daily",
                depth_level="identity",
                novelty_rationale="Connects daily tooling to personal workflow philosophies.",
            ),
            _make_curious_llm_response(
                question=on_q,
                thread_topic="autonomy philosophy",
                depth_level="identity",
                novelty_rationale="Extends autonomy philosophy from code to team dynamics.",
            ),
        ]
        kkanbu_curious(session_id=sid, user_response="I need space to think independently.")

        # Sub-AC 9c: 2 question-gen calls (off-thread + retry) + 1 distillation = 3 total.
        assert llm_mock.messages.create.call_count == 3

        retry_call_args = llm_mock.messages.create.call_args_list[1]
        retry_messages = retry_call_args.kwargs.get("messages", [])
        all_retry_content = " ".join(m["content"] for m in retry_messages)

        # The retry context must reference the established thread to guide Opus
        assert "autonomy" in all_retry_content.lower(), (
            "Retry messages must reference the established thread 'autonomy philosophy' "
            "so Opus knows which thread to stay on"
        )
        # The retry context must explain WHY the first answer was rejected
        assert "QUALITY GATE FAILED" in all_retry_content or "rejected" in all_retry_content.lower(), (
            "Retry messages must include the quality-gate-failure notice so Opus "
            "understands it needs to improve"
        )

    def test_coherence_score_exposed_via_score_function_directly(self):
        """_score_question_coherence is importable and callable from test code,
        confirming the function is a proper module-level export (not a local closure)."""
        from kkanbu.server import _score_question_coherence

        # Confirm it is callable and returns a float in range
        score = _score_question_coherence(
            question="Does autonomy define your engineering identity?",
            session_thread_topic="autonomy identity",
            new_thread_topic="autonomy engineering",
        )
        assert isinstance(score, float), "_score_question_coherence must return a float"
        assert 0.0 <= score <= 1.0

    def test_coherence_threshold_constant_is_accessible(self):
        """_COHERENCE_THRESHOLD is a module-level constant accessible for testing
        and for callers that want to introspect the gate sensitivity."""
        from kkanbu.server import _COHERENCE_THRESHOLD

        assert isinstance(_COHERENCE_THRESHOLD, float), (
            "_COHERENCE_THRESHOLD must be a float"
        )
        assert 0.0 < _COHERENCE_THRESHOLD < 1.0, (
            "_COHERENCE_THRESHOLD must be strictly between 0 and 1"
        )

    def test_is_off_thread_function_is_accessible(self):
        """_is_off_thread is importable and callable — it is a module-level function,
        not a closure, confirming the coherence gate is testable independently."""
        from kkanbu.server import _is_off_thread

        assert callable(_is_off_thread), "_is_off_thread must be a callable function"


# ── Sub-AC 9b: Surprising non-obvious connections via prompt strategy ──────────
#
# AC 9: kkanbu_curious produces surprising questions by identifying non-obvious
# cross-connections in the knowledge graph that the user hasn't consciously made.
# Sub-AC 9b verifies:
#   1. The system prompt explicitly encodes SURPRISE CRITERIA targeting cross-connections
#   2. The fresh-session prompt instructs Opus to connect distinct graph areas
#   3. The full graph with node IDs reaches Opus as context for specific grounding
#   4. The quality gate enforces that grounded_in references actual graph content
#      (< 15 characters → retry with an explicit note to cite specific nodes)
#   5. Response fields expose the non-obvious connection for caller inspection


class TestSubAC9bSurprisingConnections:
    """Sub-AC 9b: prompt strategy explicitly targets surprising, non-obvious
    connections using the knowledge graph as context."""

    @pytest.fixture(autouse=True)
    def clear_sessions(self):
        _session_store._sessions.clear()
        yield
        _session_store._sessions.clear()

    # ── 1. Prompt strategy: system prompt encodes surprise criteria ─────────────

    def test_system_prompt_encodes_surprise_criteria(self):
        """_CURIOUS_SYSTEM_PROMPT explicitly lists the criteria that make a question
        surprising — cross-connections, formative moments, tensions, absences.
        These criteria are the core of the prompt strategy for Sub-AC 9b.
        """
        from kkanbu.server import _CURIOUS_SYSTEM_PROMPT

        assert "SURPRISE CRITERIA" in _CURIOUS_SYSTEM_PROMPT, (
            "System prompt must contain a SURPRISE CRITERIA block listing what makes "
            "a question genuinely surprising"
        )
        lower = _CURIOUS_SYSTEM_PROMPT.lower()
        # Must require cross-connecting different areas of the graph
        assert "cross-connect" in lower or "different areas" in lower, (
            "Surprise criteria must explicitly require cross-connecting different graph areas"
        )
        # Must probe the deeper motivation behind known preferences
        assert "why behind the why" in lower, (
            "Surprise criteria must include probing 'why behind the why'"
        )
        # Must surface tensions between known values
        assert "tension" in lower, (
            "Surprise criteria must include surfacing tensions between known values"
        )
        # Must identify conspicuous absences in the graph
        assert "absence" in lower or "absent" in lower, (
            "Surprise criteria must include pointing to conspicuous absences"
        )

    def test_system_prompt_requires_grounding_in_specific_nodes(self):
        """The system prompt instructs Opus to cite specific node IDs or content
        snippets in the grounded_in field — tying the question to actual graph data
        rather than producing a generic question that could apply to anyone.
        """
        from kkanbu.server import _CURIOUS_SYSTEM_PROMPT

        assert "grounded_in" in _CURIOUS_SYSTEM_PROMPT, (
            "System prompt must define the grounded_in output field"
        )
        lower = _CURIOUS_SYSTEM_PROMPT.lower()
        # The description of grounded_in must mention nodes or snippets
        assert "node" in lower and ("id" in lower or "snippet" in lower), (
            "grounded_in field description must reference node IDs or content snippets"
        )

    def test_system_prompt_depth_ladder_forbids_surface_and_preference(self):
        """The DEPTH LADDER in the system prompt explicitly marks surface and
        preference as FORBIDDEN, enforcing the minimum depth for surprising questions.
        """
        from kkanbu.server import _CURIOUS_SYSTEM_PROMPT

        assert "DEPTH LADDER" in _CURIOUS_SYSTEM_PROMPT, (
            "System prompt must contain DEPTH LADDER section"
        )
        assert "FORBIDDEN" in _CURIOUS_SYSTEM_PROMPT, (
            "System prompt must mark forbidden depth levels explicitly"
        )
        assert "surface" in _CURIOUS_SYSTEM_PROMPT, (
            "Depth ladder must list 'surface' as a forbidden level"
        )
        assert "preference" in _CURIOUS_SYSTEM_PROMPT, (
            "Depth ladder must list 'preference' as a forbidden level"
        )

    def test_system_prompt_requires_self_evaluation_before_committing(self):
        """The system prompt includes a SELF-EVALUATION step so Opus checks its
        own question against the depth and cross-connection requirements before
        finalising — this is the mechanism that produces surprising questions.
        """
        from kkanbu.server import _CURIOUS_SYSTEM_PROMPT

        assert "SELF-EVALUATION" in _CURIOUS_SYSTEM_PROMPT, (
            "System prompt must contain a SELF-EVALUATION section"
        )

    # ── 2. Fresh session prompt: cross-connection instruction ──────────────────

    def test_fresh_session_prompt_instructs_cross_connection(self):
        """_build_fresh_session_prompt explicitly tells Opus to connect at least
        two distinct areas of the graph — the core of the non-obvious connection
        targeting strategy.
        """
        from kkanbu.server import _build_fresh_session_prompt

        prompt = _build_fresh_session_prompt("<<graph>>", [])
        lower = prompt.lower()
        assert ("distinct" in lower or "different" in lower), (
            "Fresh session prompt must ask for connections between distinct/different areas"
        )
        assert ("area" in lower or "connect" in lower), (
            "Fresh session prompt must explicitly mention connecting areas of the graph"
        )

    def test_fresh_session_prompt_includes_graph_context(self):
        """_build_fresh_session_prompt embeds the full graph dump so Opus has
        specific node IDs and content to reference in its grounded_in answer.
        """
        from kkanbu.server import _build_fresh_session_prompt

        graph_stub = "NODE_ABC: I value simplicity"
        prompt = _build_fresh_session_prompt(graph_stub, [])
        assert graph_stub in prompt, (
            "Fresh session prompt must include the graph dump verbatim so Opus "
            "can cite specific node content in grounded_in"
        )

    def test_fresh_session_prompt_targets_identity_or_formative_depth(self):
        """The fresh session prompt explicitly requests depth_level 'identity' or
        'formative' — aiming above the minimum 'value' threshold.
        """
        from kkanbu.server import _build_fresh_session_prompt

        prompt = _build_fresh_session_prompt("<<graph>>", [])
        lower = prompt.lower()
        assert "identity" in lower or "formative" in lower, (
            "Fresh session prompt must explicitly target identity or formative depth"
        )

    # ── 3. Graph context: node IDs and content reach Opus ──────────────────────

    def test_graph_with_multiple_node_types_fully_passed_to_opus(self, llm_mock):
        """When the graph contains multiple node types, ALL sections appear in the
        Opus context message — Opus sees everything it needs to identify non-obvious
        cross-connections between different domains of the graph.
        """
        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "I value code clarity above all", "node_type": "value",
             "why": "Code is communication", "confidence": 0.95, "depth": "value"},
        ])
        kkanbu_learn("I value code clarity above all", why="Code is communication")

        llm_mock.messages.create.return_value = _make_llm_response([
            {"content": "I prefer functional style", "node_type": "preference",
             "why": "Easier to reason about", "confidence": 0.8, "depth": "preference"},
        ])
        kkanbu_learn("I prefer functional style", why="Easier to reason about")

        # Now call kkanbu_curious and inspect what context reaches Opus
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question=(
                "Your clarity value and functional preference — "
                "do they stem from the same distrust of state?"
            ),
            grounded_in="Node: 'value code clarity', Node: 'prefer functional style'",
        )
        kkanbu_curious()

        call_args = llm_mock.messages.create.call_args
        messages = call_args.kwargs.get("messages", [])
        context_content = messages[0]["content"] if messages else ""

        assert "VALUE" in context_content or "value" in context_content.lower(), (
            "VALUE node section must appear in Opus context"
        )
        assert "PREFERENCE" in context_content or "preference" in context_content.lower(), (
            "PREFERENCE node section must appear in Opus context"
        )
        assert "clarity" in context_content.lower(), (
            "Node content 'clarity' must appear so Opus can cite it in grounded_in"
        )
        assert "functional" in context_content.lower(), (
            "Node content 'functional' must appear so Opus can cite it in grounded_in"
        )

    def test_graph_context_includes_edge_relationships(self, llm_mock):
        """When edges exist between nodes, the RELATIONSHIPS section appears in the
        Opus context — enabling Opus to spot existing connections and probe the gaps
        between them for non-obvious cross-connections.
        """
        graph = get_graph()
        n1 = graph.add_node("value", "I value resilience", source="teach", confidence=0.9)
        n2 = graph.add_node(
            "pattern", "I always write defensive code", source="teach", confidence=0.8
        )
        graph.add_edge(n1, n2, "supports", context="Resilience drives defensive coding")

        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question=(
                "You value resilience and write defensively — "
                "but have you ever chosen fragility on purpose?"
            ),
            grounded_in=f"Nodes: {n1}, {n2} — linked by 'supports' edge",
        )
        kkanbu_curious()

        call_args = llm_mock.messages.create.call_args
        messages = call_args.kwargs.get("messages", [])
        context = messages[0]["content"] if messages else ""

        assert (
            "RELATIONSHIP" in context
            or "edge" in context.lower()
            or "supports" in context.lower()
        ), (
            "Edge relationships must appear in Opus context so it can reason about "
            "existing connections and probe beyond them"
        )

    def test_empty_graph_produces_informative_context(self, llm_mock):
        """When the graph is empty, the context message explicitly says so rather
        than passing a blank string — Opus can still ask about unexplored territory.
        """
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question="What aspect of how you think have you never had to put into words?",
            grounded_in="Graph is empty — probing what has never been articulated",
            gap_identified="No graph entries yet — any topic is unexplored",
        )
        kkanbu_curious()

        call_args = llm_mock.messages.create.call_args
        messages = call_args.kwargs.get("messages", [])
        context = messages[0]["content"] if messages else ""

        assert "empty" in context.lower() or "no entries" in context.lower(), (
            "Empty graph must produce an informative context message, not a blank string"
        )

    # ── 4. grounded_in quality gate (Sub-AC 9b core enforcement) ───────────────

    def test_quality_gate_retries_when_grounded_in_empty(self, llm_mock):
        """When Opus returns an empty grounded_in, the quality gate triggers a retry.
        A question not grounded in specific graph nodes may be generic rather than
        revealing a non-obvious connection specific to what we know about this user.
        """
        ungrounded = _make_curious_llm_response(
            question="What shaped your deepest assumptions about software?",
            depth_level="formative",
            novelty_rationale=(
                "Asks about a formative experience without grounding in specific graph "
                "content — could apply to any developer."
            ),
            grounded_in="",  # Empty — no graph grounding
        )
        grounded = _make_curious_llm_response(
            question=(
                "You describe valuing resilience AND preferring simplicity — "
                "did these develop separately or from the same formative tension?"
            ),
            depth_level="formative",
            novelty_rationale=(
                "Connects two separate value nodes never explicitly linked — "
                "their origins may be the same unresolved tension."
            ),
            grounded_in="Node: 'I value resilience', Node: 'I prefer simple solutions'",
        )
        llm_mock.messages.create.side_effect = [ungrounded, grounded]

        result = kkanbu_curious()
        data = json.loads(result)

        assert llm_mock.messages.create.call_count == 2, (
            "Empty grounded_in must trigger a retry call"
        )
        assert data["grounded_in"] != "", (
            "After retry, grounded_in must be populated"
        )

    def test_quality_gate_retries_when_grounded_in_too_vague(self, llm_mock):
        """A grounded_in value shorter than 15 characters triggers a retry — vague
        references like 'the graph' (9 chars) don't identify specific cross-connections.
        """
        vague = _make_curious_llm_response(
            question="What core belief drives how you approach uncertainty?",
            depth_level="identity",
            novelty_rationale=(
                "Probes a gap in how the user describes uncertainty — no explicit node "
                "exists for this and it likely connects several existing value nodes."
            ),
            grounded_in="the graph",  # 9 chars — too vague
        )
        specific = _make_curious_llm_response(
            question=(
                "Your reliability nodes and defensive-coding pattern both respond to "
                "uncertainty — but which came first: the belief or the habit?"
            ),
            depth_level="identity",
            novelty_rationale=(
                "Cross-connects the 'I value reliability' value node with the "
                "'I write defensive code' pattern node, probing the causal arrow."
            ),
            grounded_in=(
                "Node: 'I value reliability' (confidence=0.9), "
                "Node: 'I write defensive code' (confidence=0.8)"
            ),
        )
        llm_mock.messages.create.side_effect = [vague, specific]

        result = kkanbu_curious()
        data = json.loads(result)

        assert llm_mock.messages.create.call_count == 2, (
            "Too-vague grounded_in (< 15 chars) must trigger a retry"
        )
        assert len(data["grounded_in"]) >= 15, (
            "Final grounded_in after retry must be substantive"
        )

    def test_no_retry_when_grounded_in_is_specific(self, llm_mock):
        """When grounded_in explicitly references specific node content (≥ 15 chars),
        the quality gate does not trigger for this criterion — only one Opus call.
        """
        well_grounded = _make_curious_llm_response(
            question=(
                "Your resilience value and defensive coding pattern seem linked — "
                "when did the habit develop relative to the belief?"
            ),
            depth_level="identity",
            novelty_rationale=(
                "Probes the causal relationship between two well-connected graph nodes — "
                "the timeline of development has never been articulated."
            ),
            grounded_in=(
                "Node: 'I value resilience above all', "
                "Node: 'I always write defensive code' — linked by supports edge"
            ),
        )
        llm_mock.messages.create.return_value = well_grounded

        result = kkanbu_curious()
        data = json.loads(result)

        assert llm_mock.messages.create.call_count == 1, (
            "Specific grounded_in must not trigger a retry"
        )
        assert data["grounded_in"] != ""

    def test_retry_message_cites_grounded_in_as_rejection_reason(self, llm_mock):
        """When the quality gate rejects for empty grounded_in, the retry message
        tells Opus exactly why — so it knows it must cite specific node content.
        """
        ungrounded = _make_curious_llm_response(
            question="What do you believe about software quality?",
            depth_level="value",
            novelty_rationale=(
                "Probes underlying beliefs about quality not yet articulated in the graph."
            ),
            grounded_in="",  # Triggers quality gate
        )
        grounded = _make_curious_llm_response(
            question=(
                "Your clarity value node and pattern for short functions — "
                "do they both stem from a belief that code should be writable "
                "by a tired future self?"
            ),
            depth_level="value",
            novelty_rationale=(
                "Connects clarity (value) with short-functions (pattern) via a "
                "shared cognitive-load hypothesis."
            ),
            grounded_in="Node: 'I value clarity', Node: 'I write short focused functions'",
        )
        llm_mock.messages.create.side_effect = [ungrounded, grounded]

        kkanbu_curious()

        retry_call = llm_mock.messages.create.call_args_list[1]
        retry_messages = retry_call.kwargs.get("messages", [])
        all_content = " ".join(m["content"] for m in retry_messages)

        assert "QUALITY GATE FAILED" in all_content, (
            "Retry message must contain QUALITY GATE FAILED marker"
        )
        assert (
            "grounded_in" in all_content.lower()
            or "specific node" in all_content.lower()
            or "node content" in all_content.lower()
        ), (
            "Retry reason must explain that grounded_in must reference specific nodes"
        )

    def test_grounded_in_updated_from_retry_response(self, llm_mock):
        """When the retry produces a better grounded_in, the updated value is
        returned in the final response — not the original empty/vague value.
        """
        ungrounded = _make_curious_llm_response(
            question="Why do you care about simplicity?",
            depth_level="value",
            novelty_rationale="Probes a value with no explicit why in the graph.",
            grounded_in="",
        )
        grounded = _make_curious_llm_response(
            question=(
                "Your simplicity value and minimal-tooling preference — "
                "are they the same thing, or do they ever conflict?"
            ),
            depth_level="value",
            novelty_rationale=(
                "Two nodes describe simplicity from different angles (value vs. practice) "
                "but have never been cross-examined for contradictions."
            ),
            grounded_in="Node: 'I value simplicity', Node: 'I prefer minimal dependencies'",
        )
        llm_mock.messages.create.side_effect = [ungrounded, grounded]

        data = json.loads(kkanbu_curious())

        assert "Node:" in data["grounded_in"], (
            "grounded_in in final response must use the retry's specific node reference"
        )

    # ── 5. Response structure exposes the non-obvious connection ───────────────

    def test_response_grounded_in_field_populated(self, llm_mock):
        """The grounded_in field in the JSON response explicitly names which graph
        nodes the question draws from — making the non-obvious connection inspectable.
        """
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question=(
                "Your simplicity value and minimal-tooling preference — "
                "are they the same thing or do they ever conflict?"
            ),
            grounded_in="Node: 'I value simplicity', Node: 'I prefer minimal dependencies'",
        )
        data = json.loads(kkanbu_curious())

        assert "grounded_in" in data, "Response must include grounded_in field"
        assert data["grounded_in"] != "", "grounded_in must be non-empty"

    def test_response_rejected_alternatives_proves_self_evaluation(self, llm_mock):
        """rejected_alternatives shows Opus evaluated and discarded shallower
        candidates before committing — proof of the SELF-EVALUATION step in the prompt.
        """
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question=(
                "When did your preference for simplicity stop being aesthetic "
                "and become ethical?"
            ),
            depth_level="formative",
            rejected_alternatives=[
                "Do you prefer simple or complex tools?",
                "How often do you refactor for clarity?",
            ],
        )
        data = json.loads(kkanbu_curious())

        assert isinstance(data["rejected_alternatives"], list), (
            "rejected_alternatives must be a list"
        )
        assert len(data["rejected_alternatives"]) > 0, (
            "Opus must show at least one rejected alternative as proof of self-evaluation"
        )

    def test_response_gap_identified_names_specific_tension(self, llm_mock):
        """gap_identified in the response names the specific tension, blind spot, or
        absence the question probes — making the non-obvious connection explicit.
        """
        gap = (
            "No explicit reflection on the tension between valuing simplicity "
            "and choosing complex tools when they are the right fit"
        )
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question=(
                "When has complexity been the right answer for you "
                "despite your simplicity values?"
            ),
            gap_identified=gap,
            depth_level="value",
            grounded_in="Node: 'I value simplicity', absence: no 'complexity justified' node",
        )
        data = json.loads(kkanbu_curious())

        assert data["gap_identified"] == gap, (
            "gap_identified must pass through from Opus response to caller"
        )


# ── Sub-AC 9c: Ephemeral-to-graph distillation in kkanbu_curious ──────────────
# When kkanbu_curious receives a user_response that leads to a question of
# value/identity/formative depth, learnings are written to the knowledge graph
# immediately (eager distillation) rather than waiting for session expiry.
#
# Tests verify:
#   1. distillation_written + distillation_learnings fields in JSON response
#   2. Distillation fires on follow-up calls with deep depth
#   3. Distillation does NOT fire on fresh session (no user_response)
#   4. Distillation does NOT fire for surface/preference depth
#   5. Graph receives distilled learnings after curious exchange
#   6. Idempotency: same turn not distilled twice
#   7. Distillation source encodes session type as "distill:curious"
#   8. Distillation failure is non-blocking (response still returned)
#   9. distillation_written == 0 when depth is shallow


class TestSubAC9cCuriousEphemeralDistillation:
    """Sub-AC 9c: eager ephemeral-to-graph distillation inside kkanbu_curious."""

    @pytest.fixture(autouse=True)
    def clear_sessions(self):
        _session_store._sessions.clear()
        yield
        _session_store._sessions.clear()

    # ── 1. Response shape ────────────────────────────────────────────────────

    def test_response_includes_distillation_written_field(self, llm_mock):
        """kkanbu_curious response JSON always includes distillation_written (int)."""
        llm_mock.messages.create.return_value = _make_curious_llm_response()
        data = json.loads(kkanbu_curious())

        assert "distillation_written" in data, (
            "Response must include distillation_written field (int)"
        )
        assert isinstance(data["distillation_written"], int)

    def test_response_includes_distillation_learnings_field(self, llm_mock):
        """kkanbu_curious response JSON always includes distillation_learnings (list)."""
        llm_mock.messages.create.return_value = _make_curious_llm_response()
        data = json.loads(kkanbu_curious())

        assert "distillation_learnings" in data, (
            "Response must include distillation_learnings field (list)"
        )
        assert isinstance(data["distillation_learnings"], list)

    def test_fresh_session_distillation_written_is_zero(self, llm_mock):
        """On the first call (no user_response), distillation_written == 0."""
        llm_mock.messages.create.return_value = _make_curious_llm_response()
        data = json.loads(kkanbu_curious())

        assert data["distillation_written"] == 0, (
            "Fresh session has no user_response → no distillation → distillation_written == 0"
        )
        assert data["distillation_learnings"] == []

    # ── 2. Distillation triggers on deep follow-ups ──────────────────────────

    def test_distillation_fires_on_follow_up_with_deep_depth(self, llm_mock):
        """When user_response is provided and depth_level is 'identity',
        learnings are written to the graph and distillation_written > 0."""
        # Turn 1: fresh question
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question="What shaped your philosophy around code quality?",
            thread_topic="quality philosophy",
        )
        r1 = json.loads(kkanbu_curious())
        sid = r1["session_id"]

        # Turn 2: follow-up with user_response — question gen + distillation
        distillation_resp = _make_distillation_response(
            [
                {
                    "content": "Quality is a proxy for respect — for the reader, future self, and the craft",
                    "node_type": "value",
                    "why": "User described quality as an act of respect, not just correctness",
                    "confidence": 0.85,
                    "depth": "identity",
                    "upsert_node_id": None,
                }
            ],
            session_synthesis="Revealed that quality is an ethical stance, not just a technical one.",
        )
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(
                question="What does that standard look like when you're under time pressure?",
                thread_topic="quality philosophy",
                depth_level="identity",
            ),
            distillation_resp,
        ]
        r2 = json.loads(kkanbu_curious(
            session_id=sid,
            user_response="Quality for me means I respect the next person who reads this.",
        ))

        assert r2["distillation_written"] >= 1, (
            "Follow-up with identity-depth question must write at least one learning"
        )
        assert len(r2["distillation_learnings"]) >= 1, (
            "distillation_learnings must contain the IDs of written nodes"
        )

    def test_distillation_writes_to_graph_on_deep_follow_up(self, llm_mock):
        """After a deep follow-up, the knowledge graph contains a distilled learning."""
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question="How does your relationship with failure shape your risk tolerance?",
            thread_topic="failure philosophy",
        )
        r1 = json.loads(kkanbu_curious())
        sid = r1["session_id"]

        graph = get_graph()
        nodes_before = len(graph.get_full_dump().get("nodes", []))

        distillation_resp = _make_distillation_response(
            [
                {
                    "content": "Views failure as a necessary cost of ambition, not as weakness",
                    "node_type": "value",
                    "why": "Revealed through description of embracing risk in learning contexts",
                    "confidence": 0.82,
                    "depth": "identity",
                    "upsert_node_id": None,
                }
            ],
        )
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(
                question="When has failure been your most important teacher?",
                thread_topic="failure philosophy",
                depth_level="formative",
            ),
            distillation_resp,
        ]
        kkanbu_curious(
            session_id=sid,
            user_response="Failing fast taught me to separate my ego from my experiments.",
        )

        nodes_after = len(graph.get_full_dump().get("nodes", []))
        assert nodes_after > nodes_before, (
            "Knowledge graph must have more nodes after eager distillation"
        )

    # ── 3. Distillation skipped when not applicable ──────────────────────────

    def test_distillation_skipped_for_surface_depth(self, llm_mock):
        """When depth_level is 'surface', distillation is NOT triggered."""
        # Turn 1: establish session
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question="What's your go-to stack?",
            thread_topic="tech choices",
        )
        r1 = json.loads(kkanbu_curious())
        sid = r1["session_id"]

        # Turn 2: surface-depth question — distillation should NOT fire
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question="What framework do you reach for first?",
            depth_level="surface",
            thread_topic="tech choices",
        )
        r2 = json.loads(kkanbu_curious(
            session_id=sid,
            user_response="I usually start with a minimal setup.",
        ))

        assert r2["distillation_written"] == 0, (
            "Surface-depth questions must not trigger distillation"
        )

    def test_distillation_skipped_for_preference_depth(self, llm_mock):
        """When depth_level is 'preference', distillation is NOT triggered."""
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question="What language do you reach for most?",
            thread_topic="language preference",
        )
        r1 = json.loads(kkanbu_curious())
        sid = r1["session_id"]

        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question="Do you prefer statically typed languages?",
            depth_level="preference",
            thread_topic="language preference",
        )
        r2 = json.loads(kkanbu_curious(
            session_id=sid,
            user_response="I like both depending on the context.",
        ))

        assert r2["distillation_written"] == 0, (
            "Preference-depth questions must not trigger distillation"
        )

    def test_distillation_skipped_for_blank_user_response(self, llm_mock):
        """When user_response is blank/whitespace, distillation is NOT triggered."""
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question="What drives you?",
            thread_topic="motivation",
        )
        r1 = json.loads(kkanbu_curious())
        sid = r1["session_id"]

        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question="What does success look like for you?",
            depth_level="identity",
            thread_topic="motivation",
        )
        r2 = json.loads(kkanbu_curious(session_id=sid, user_response="   "))

        assert r2["distillation_written"] == 0, (
            "Blank user_response must not trigger distillation"
        )

    # ── 4. Idempotency guard ─────────────────────────────────────────────────

    def test_distillation_not_repeated_for_same_turn(self, llm_mock):
        """Calling kkanbu_curious twice with the same session state does not
        re-distill the same turn (idempotency guard via last_distilled_turn)."""
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question="What fear lives beneath your perfectionism?",
            thread_topic="perfectionism identity",
        )
        r1 = json.loads(kkanbu_curious())
        sid = r1["session_id"]

        distillation_resp = _make_distillation_response(
            [
                {
                    "content": "Perfectionism is a defence against vulnerability, not a pursuit of excellence",
                    "node_type": "pattern",
                    "why": "Linked to fear of being seen as incompetent",
                    "confidence": 0.8,
                    "depth": "identity",
                    "upsert_node_id": None,
                }
            ],
        )
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(
                question="When does your perfectionism protect you, and when does it limit you?",
                thread_topic="perfectionism identity",
                depth_level="identity",
            ),
            distillation_resp,  # first distillation
        ]
        r2 = json.loads(kkanbu_curious(
            session_id=sid,
            user_response="It shields me from criticism but slows me down.",
        ))
        first_write_count = r2["distillation_written"]
        assert first_write_count >= 1

        # Manually advance last_distilled_turn to simulate already-distilled state
        session = _session_store.get(sid)
        assert session is not None
        # The idempotency guard tracks last_distilled_turn in session.metadata.
        # Since learnings_written > 0, it should already be set.
        assert session.metadata.get("last_distilled_turn", 0) == session.turn_count, (
            "last_distilled_turn must be updated after successful distillation"
        )

    # ── 5. Distillation source encodes session type ──────────────────────────

    def test_distilled_node_source_is_distill_curious(self, llm_mock):
        """Nodes written by eager curious distillation have source='distill:curious'."""
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question="What connects your love of simplicity to how you manage complexity?",
            thread_topic="simplicity management",
        )
        r1 = json.loads(kkanbu_curious())
        sid = r1["session_id"]

        distillation_resp = _make_distillation_response(
            [
                {
                    "content": "Uses simplicity as a forcing function to clarify thinking before acting",
                    "node_type": "pattern",
                    "why": "Described simplicity as a thinking tool, not just an aesthetic",
                    "confidence": 0.83,
                    "depth": "identity",
                    "upsert_node_id": None,
                }
            ],
        )
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(
                question="When complexity arrives despite your intentions, what breaks first?",
                thread_topic="simplicity management",
                depth_level="value",
            ),
            distillation_resp,
        ]
        r2 = json.loads(kkanbu_curious(
            session_id=sid,
            user_response="I simplify until the problem is obvious, then I act.",
        ))

        assert r2["distillation_written"] >= 1
        node_id = r2["distillation_learnings"][0]
        graph = get_graph()
        node = graph.get_node(node_id)
        assert node is not None
        assert node["source"] == "distill:curious", (
            "Eager distillation from kkanbu_curious must set source='distill:curious'"
        )

    # ── 6. Distillation failure is non-blocking ──────────────────────────────

    def test_distillation_failure_does_not_block_response(self, llm_mock):
        """If the distillation LLM call fails, kkanbu_curious still returns a
        valid JSON response with distillation_written == 0."""
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question="What does your approach to testing reveal about trust?",
            thread_topic="trust pattern",
        )
        r1 = json.loads(kkanbu_curious())
        sid = r1["session_id"]

        # Second call: question succeeds, distillation raises an exception
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(
                question="Who or what do you trust most in a production system?",
                thread_topic="trust pattern",
                depth_level="identity",
            ),
            Exception("Distillation LLM timeout"),
        ]
        r2 = json.loads(kkanbu_curious(
            session_id=sid,
            user_response="I trust tests more than comments.",
        ))

        # Response must be valid and contain the question
        assert r2["type"] == "curiosity"
        assert r2["message"] != ""
        assert r2["distillation_written"] == 0, (
            "Distillation failure must not block response; distillation_written == 0"
        )
        assert r2["distillation_learnings"] == []

    # ── 7. All depth levels trigger distillation ─────────────────────────────

    def test_value_depth_triggers_distillation(self, llm_mock):
        """depth_level='value' triggers distillation (value ∈ _CURIOUS_MIN_DEPTH)."""
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question="What core engineering principle guides every decision you make?",
            thread_topic="core principles",
        )
        r1 = json.loads(kkanbu_curious())
        sid = r1["session_id"]

        distillation_resp = _make_distillation_response(
            [
                {
                    "content": "Chooses boring technology because reliability compounds over novelty",
                    "node_type": "reasoning",
                    "why": "Explained with 'I'd rather ship boring and reliable than clever and fragile'",
                    "confidence": 0.87,
                    "depth": "identity",
                    "upsert_node_id": None,
                }
            ],
        )
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(
                question="Has reliability ever cost you something you valued?",
                thread_topic="core principles",
                depth_level="value",
            ),
            distillation_resp,
        ]
        r2 = json.loads(kkanbu_curious(
            session_id=sid,
            user_response="I'd rather ship boring and reliable than clever and fragile.",
        ))

        assert r2["distillation_written"] >= 1, (
            "depth_level='value' must trigger distillation (value ∈ _CURIOUS_MIN_DEPTH)"
        )

    def test_formative_depth_triggers_distillation(self, llm_mock):
        """depth_level='formative' triggers distillation (formative ∈ _CURIOUS_MIN_DEPTH)."""
        llm_mock.messages.create.return_value = _make_curious_llm_response(
            question="What early experience taught you the most about your craft?",
            thread_topic="formative moments",
        )
        r1 = json.loads(kkanbu_curious())
        sid = r1["session_id"]

        distillation_resp = _make_distillation_response(
            [
                {
                    "content": "A formative debugging failure instilled a habit of systematic root-cause analysis",
                    "node_type": "pattern",
                    "why": "Traced back a defining engineering habit to an early career incident",
                    "confidence": 0.9,
                    "depth": "identity",
                    "upsert_node_id": None,
                }
            ],
        )
        llm_mock.messages.create.side_effect = [
            _make_curious_llm_response(
                question="What belief did that experience cement that still guides you today?",
                thread_topic="formative moments",
                depth_level="formative",
            ),
            distillation_resp,
        ]
        r2 = json.loads(kkanbu_curious(
            session_id=sid,
            user_response="A painful debugging session taught me never to trust assumptions.",
        ))

        assert r2["distillation_written"] >= 1, (
            "depth_level='formative' must trigger distillation (formative ∈ _CURIOUS_MIN_DEPTH)"
        )
