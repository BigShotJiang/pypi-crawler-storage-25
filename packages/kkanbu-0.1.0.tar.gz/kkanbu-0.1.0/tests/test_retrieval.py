"""Tests for the selective retrieval layer (retrieval.py)."""

import pytest

from kkanbu.graph import KnowledgeGraph
from kkanbu.retrieval import (
    ContextBundle,
    RankedEdge,
    RankedNode,
    assemble_context_payload,
    extract_keywords,
    retrieve_context,
)


@pytest.fixture
def graph(tmp_path):
    db_path = tmp_path / "test_retrieval.db"
    g = KnowledgeGraph(db_path)
    yield g
    g.close()


@pytest.fixture
def populated_graph(graph):
    """Graph with a realistic set of user preferences for testing retrieval."""
    # Core value
    v1 = graph.add_node(
        "value", "Simplicity over cleverness", "teach",
        why="Complex code has hidden maintenance costs",
        confidence=0.95,
    )
    # Preference connected to value
    p1 = graph.add_node(
        "preference", "Prefers Python for backend services", "teach",
        why="Python's readability aligns with simplicity values",
        confidence=0.90,
    )
    # Another preference
    p2 = graph.add_node(
        "preference", "Uses SQLite for small projects", "teach",
        why="No server needed, embedded, zero config",
        confidence=0.85,
    )
    # Reasoning node
    r1 = graph.add_node(
        "reasoning", "Dependencies should be minimal because each dep is a liability",
        "teach", confidence=0.88,
    )
    # Pattern
    pat1 = graph.add_node(
        "pattern", "Writes tests before implementation when possible", "teach",
        why="Forces clearer API design upfront",
        confidence=0.80,
    )
    # Low-confidence ingest node
    low1 = graph.add_node(
        "observation", "Possibly uses React for frontend", "ingest",
        confidence=0.30,
    )
    # Unrelated node
    unrelated = graph.add_node(
        "observation", "Office temperature preference: cool", "teach",
        confidence=0.70,
    )

    # Edges
    graph.add_edge(v1, p1, "supports", weight=0.9,
                   context="Simplicity value supports Python preference")
    graph.add_edge(p1, p2, "relates_to", weight=0.6,
                   context="Both are backend technology choices")
    graph.add_edge(r1, p2, "supports", weight=0.8,
                   context="Minimal deps reasoning supports SQLite choice")
    graph.add_edge(pat1, r1, "derives_from", weight=0.7,
                   context="Testing pattern derives from minimal-dep reasoning")

    return graph, {
        "v1": v1, "p1": p1, "p2": p2, "r1": r1,
        "pat1": pat1, "low1": low1, "unrelated": unrelated,
    }


# ── extract_keywords ──────────────────────────────────────────────────────


class TestExtractKeywords:
    def test_basic_tokenization(self):
        kws = extract_keywords("Python backend services")
        assert "python" in kws
        assert "backend" in kws
        assert "services" in kws

    def test_removes_stop_words(self):
        kws = extract_keywords("How do you prefer to use Python?")
        assert "python" in kws
        assert "how" not in kws
        assert "do" not in kws
        assert "you" not in kws
        assert "to" not in kws

    def test_strips_punctuation(self):
        kws = extract_keywords("Python, Go, and Rust!")
        assert "python" in kws
        assert "rust" in kws
        # "and" is a stop word
        assert "and" not in kws

    def test_deduplicates(self):
        kws = extract_keywords("Python Python python")
        assert kws.count("python") == 1

    def test_filters_short_tokens(self):
        kws = extract_keywords("A to go Python is it")
        # 'go' is 2 chars → filtered; 'python' stays
        assert "go" not in kws
        assert "python" in kws

    def test_empty_string(self):
        assert extract_keywords("") == []

    def test_all_stop_words(self):
        assert extract_keywords("the a an is are") == []


# ── retrieve_context — basic ──────────────────────────────────────────────


class TestRetrieveContextBasic:
    def test_returns_context_bundle(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(graph, "Python backend")
        assert isinstance(bundle, ContextBundle)

    def test_finds_direct_keyword_match(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(graph, "Python")
        node_ids = {rn.node_id for rn in bundle.nodes}
        # p1 is about Python — must be in results
        assert ids["p1"] in node_ids

    def test_depth_zero_returns_seeds_only(self, populated_graph):
        graph, ids = populated_graph
        # Use include_edge_seeds=False so edge-context matches don't pull in extra nodes
        bundle = retrieve_context(graph, "Python", bfs_depth=0, include_edge_seeds=False)
        node_ids = {rn.node_id for rn in bundle.nodes}
        # Direct match: p1 (Python preference)
        assert ids["p1"] in node_ids
        # v1 (Simplicity value) has no "python" in content/why so should NOT appear
        assert ids["v1"] not in node_ids

    def test_bfs_expansion_brings_in_neighbors(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(graph, "Python", bfs_depth=2)
        node_ids = {rn.node_id for rn in bundle.nodes}
        # v1 is connected to p1 (Python preference) via "supports" edge — should appear at depth=1
        assert ids["v1"] in node_ids

    def test_seed_node_has_depth_zero(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(graph, "Python", bfs_depth=2)
        p1_ranked = next((rn for rn in bundle.nodes if rn.node_id == ids["p1"]), None)
        assert p1_ranked is not None
        assert p1_ranked.depth == 0

    def test_bfs_neighbor_has_nonzero_depth(self, populated_graph):
        graph, ids = populated_graph
        # Disable edge seeds so v1 is only reachable via BFS from p1, not as a seed
        bundle = retrieve_context(graph, "Python", bfs_depth=2, include_edge_seeds=False)
        v1_ranked = next((rn for rn in bundle.nodes if rn.node_id == ids["v1"]), None)
        assert v1_ranked is not None
        assert v1_ranked.depth >= 1

    def test_unrelated_node_not_retrieved(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(graph, "Python backend database", bfs_depth=1)
        node_ids = {rn.node_id for rn in bundle.nodes}
        # "office temperature" is unrelated — should not appear unless connected
        assert ids["unrelated"] not in node_ids

    def test_empty_graph_returns_empty_bundle(self, graph):
        bundle = retrieve_context(graph, "Python")
        assert bundle.is_empty()
        assert bundle.as_text() != ""  # Should still render cleanly


# ── retrieve_context — ranking ────────────────────────────────────────────


class TestRetrieveContextRanking:
    def test_nodes_sorted_by_score_descending(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(graph, "Python simplicity dependencies")
        scores = [rn.score for rn in bundle.nodes]
        assert scores == sorted(scores, reverse=True)

    def test_direct_matches_score_higher_than_bfs_neighbors(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(graph, "Python", bfs_depth=2)
        p1_ranked = next(rn for rn in bundle.nodes if rn.node_id == ids["p1"])
        v1_ranked = next((rn for rn in bundle.nodes if rn.node_id == ids["v1"]), None)
        if v1_ranked:
            assert p1_ranked.score >= v1_ranked.score

    def test_high_confidence_nodes_rank_higher_for_same_keywords(self, populated_graph):
        graph, ids = populated_graph
        # low1 has confidence=0.30, p1 has confidence=0.90; both can match "python"
        # But low1 says "Possibly uses React" — not Python — so it's harder to compare directly.
        # Instead just verify the bundle's average_confidence is reasonable
        bundle = retrieve_context(graph, "Python backend")
        assert bundle.average_confidence() > 0.5

    def test_min_confidence_filter_excludes_low_confidence(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(graph, "React frontend", min_confidence=0.5)
        node_ids = {rn.node_id for rn in bundle.nodes}
        # low1 has confidence=0.30 and contains "React" — should be excluded
        assert ids["low1"] not in node_ids

    def test_min_confidence_zero_includes_all(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(graph, "React", min_confidence=0.0)
        node_ids = {rn.node_id for rn in bundle.nodes}
        assert ids["low1"] in node_ids


# ── retrieve_context — edge handling ─────────────────────────────────────


class TestRetrieveContextEdges:
    def test_edges_between_included_nodes_are_collected(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(graph, "Python simplicity", bfs_depth=2)
        edge_from_ids = {re.edge["from_node"] for re in bundle.edges}
        edge_to_ids = {re.edge["to_node"] for re in bundle.edges}
        all_edge_nodes = edge_from_ids | edge_to_ids
        # At least some edges should touch the Python and simplicity nodes
        assert len(bundle.edges) > 0
        assert ids["p1"] in all_edge_nodes or ids["v1"] in all_edge_nodes

    def test_edge_keyword_match_brings_in_nodes(self, populated_graph):
        graph, ids = populated_graph
        # Edge context: "Simplicity value supports Python preference"
        # Searching "simplicity supports" should surface v1 or p1 via edge-context seed
        bundle = retrieve_context(
            graph, "simplicity supports", bfs_depth=0, include_edge_seeds=True
        )
        node_ids = {rn.node_id for rn in bundle.nodes}
        # The edge connects v1->p1 with context containing "simplicity" and "supports"
        assert ids["v1"] in node_ids or ids["p1"] in node_ids

    def test_edge_seeds_can_be_disabled(self, populated_graph):
        graph, ids = populated_graph
        bundle_with = retrieve_context(
            graph, "simplicity supports", bfs_depth=0, include_edge_seeds=True
        )
        bundle_without = retrieve_context(
            graph, "simplicity supports", bfs_depth=0, include_edge_seeds=False
        )
        # Without edge seeds at depth=0, fewer (or no) nodes via edge-context path
        # (exact counts depend on which keywords hit node content directly)
        assert len(bundle_with.nodes) >= len(bundle_without.nodes)

    def test_edges_sorted_by_score(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(graph, "Python simplicity", bfs_depth=2)
        if len(bundle.edges) > 1:
            scores = [re.score for re in bundle.edges]
            assert scores == sorted(scores, reverse=True)


# ── retrieve_context — node_types filter ─────────────────────────────────


class TestRetrieveContextNodeTypes:
    def test_node_type_filter_restricts_results(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(
            graph, "Python simplicity dependencies",
            node_types=["value"],
            bfs_depth=0,
        )
        for rn in bundle.nodes:
            assert rn.node["node_type"] == "value"

    def test_node_type_filter_multiple(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(
            graph, "Python backend",
            node_types=["preference", "value"],
            bfs_depth=0,
        )
        for rn in bundle.nodes:
            assert rn.node["node_type"] in ("preference", "value")


# ── retrieve_context — max_nodes ─────────────────────────────────────────


class TestRetrieveContextMaxNodes:
    def test_max_nodes_caps_results(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(graph, "Python simplicity", bfs_depth=3, max_nodes=2)
        assert len(bundle.nodes) <= 2

    def test_max_nodes_keeps_highest_scoring(self, populated_graph):
        graph, ids = populated_graph
        bundle_full = retrieve_context(graph, "Python simplicity", bfs_depth=2, max_nodes=100)
        bundle_capped = retrieve_context(graph, "Python simplicity", bfs_depth=2, max_nodes=2)
        # Capped bundle's nodes should be subset of full bundle's top nodes
        full_top2_ids = {rn.node_id for rn in bundle_full.nodes[:2]}
        capped_ids = {rn.node_id for rn in bundle_capped.nodes}
        assert capped_ids == full_top2_ids


# ── ContextBundle helpers ─────────────────────────────────────────────────


class TestContextBundle:
    def test_as_text_includes_query(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(graph, "Python backend testing")
        text = bundle.as_text()
        assert "Python backend testing" in text

    def test_as_text_includes_node_content(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(graph, "Python")
        text = bundle.as_text()
        assert "Python" in text

    def test_as_text_empty_bundle(self, graph):
        bundle = retrieve_context(graph, "nonexistent query xyz")
        text = bundle.as_text()
        assert "No relevant knowledge" in text

    def test_is_empty_false_when_nodes_present(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(graph, "Python")
        assert not bundle.is_empty()

    def test_is_empty_true_for_empty_graph(self, graph):
        bundle = retrieve_context(graph, "Python")
        assert bundle.is_empty()

    def test_average_confidence_range(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(graph, "Python simplicity")
        avg = bundle.average_confidence()
        assert 0.0 <= avg <= 1.0

    def test_top_nodes_respects_limit(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(graph, "Python simplicity dependencies", bfs_depth=2)
        top3 = bundle.top_nodes(3)
        assert len(top3) <= 3

    def test_keywords_populated(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(graph, "Python backend testing")
        assert "python" in bundle.keywords
        assert "backend" in bundle.keywords
        assert "testing" in bundle.keywords


# ── RankedNode / RankedEdge helpers ───────────────────────────────────────


class TestRankedNodeText:
    def test_as_text_includes_content(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(graph, "Python")
        p1_rn = next(rn for rn in bundle.nodes if rn.node_id == ids["p1"])
        text = p1_rn.as_text()
        assert "Python" in text
        assert "preference" in text  # node_type

    def test_as_text_includes_why_when_present(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(graph, "Python")
        p1_rn = next(rn for rn in bundle.nodes if rn.node_id == ids["p1"])
        text = p1_rn.as_text()
        assert "WHY" in text


class TestRankedEdgeText:
    def test_as_text_shows_relation(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(graph, "Python simplicity", bfs_depth=2)
        if bundle.edges:
            text = bundle.edges[0].as_text()
            # Should contain relation_type in the format --[relation_type]-->
            assert "--[" in text and "]-->" in text


# ── Multi-keyword scoring ─────────────────────────────────────────────────


class TestMultiKeywordScoring:
    def test_node_matching_more_keywords_scores_higher(self, populated_graph):
        graph, ids = populated_graph
        # p1 matches "python" (content) and "readability" (why); r1 matches "dependencies"
        bundle = retrieve_context(graph, "python readability")
        p1_rn = next((rn for rn in bundle.nodes if rn.node_id == ids["p1"]), None)
        r1_rn = next((rn for rn in bundle.nodes if rn.node_id == ids["r1"]), None)
        if p1_rn and r1_rn:
            # p1 matches more query keywords → higher score
            assert p1_rn.score >= r1_rn.score

    def test_bfs_depth_two_reaches_two_hops(self, populated_graph):
        graph, ids = populated_graph
        # pat1 -> r1 -> p2  (depth-2 from p2 seed via SQLite search)
        # If we query "sqlite embedded", p2 is a seed (depth=0)
        # r1 is 1 hop from p2 via "supports" edge
        # pat1 is 1 hop from r1 via "derives_from" edge → 2 hops total from p2
        bundle = retrieve_context(graph, "sqlite embedded", bfs_depth=2)
        node_ids = {rn.node_id for rn in bundle.nodes}
        assert ids["p2"] in node_ids  # direct match
        assert ids["r1"] in node_ids  # 1 hop
        # pat1 should be reachable at depth 2
        assert ids["pat1"] in node_ids


# ── assemble_context_payload ──────────────────────────────────────────────


class TestAssembleContextPayload:
    """Tests for the LLM context assembly function."""

    def test_returns_string(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(graph, "Python backend")
        payload = assemble_context_payload(bundle)
        assert isinstance(payload, str)
        assert len(payload) > 0

    def test_has_header_section(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(graph, "Python backend")
        payload = assemble_context_payload(bundle, question="What language do you prefer?")
        assert "=== KNOWLEDGE CONTEXT" in payload
        assert "What language do you prefer?" in payload

    def test_has_end_marker_and_voice_framing(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(graph, "Python backend")
        payload = assemble_context_payload(bundle)
        assert "=== END CONTEXT ===" in payload
        # Voice framing directive must be present
        assert "Speak authentically" in payload

    def test_shows_direct_knowledge_section(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(graph, "Python", bfs_depth=0, include_edge_seeds=False)
        payload = assemble_context_payload(bundle)
        assert "DIRECT KNOWLEDGE" in payload

    def test_shows_contextual_section_for_bfs_nodes(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(graph, "Python", bfs_depth=2, include_edge_seeds=False)
        payload = assemble_context_payload(bundle)
        # BFS-inferred nodes should produce the contextual section
        has_contextual = "CONTEXTUAL KNOWLEDGE" in payload
        # At least one of the two sections must be present
        assert "DIRECT KNOWLEDGE" in payload or has_contextual

    def test_shows_relationships_section_when_edges_present(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(graph, "Python simplicity", bfs_depth=2)
        payload = assemble_context_payload(bundle)
        if bundle.edges:
            assert "KNOWLEDGE RELATIONSHIPS" in payload
            # Should show relation type arrow
            assert "--[" in payload and "]-->" in payload

    def test_shows_confidence_label(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(graph, "Python")
        payload = assemble_context_payload(bundle)
        # Should include one of the confidence labels
        assert any(label in payload for label in ("HIGH", "MODERATE", "LOW"))

    def test_includes_why_reasoning(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(graph, "Python")
        payload = assemble_context_payload(bundle)
        # p1 has why="Python's readability aligns with simplicity values"
        assert "WHY" in payload

    def test_empty_bundle_returns_no_knowledge_message(self, graph):
        bundle = retrieve_context(graph, "completely unrelated query xyz abc")
        payload = assemble_context_payload(bundle)
        assert "No relevant knowledge" in payload
        assert "=== END CONTEXT ===" in payload

    def test_empty_bundle_with_question_includes_question_in_header(self, graph):
        bundle = retrieve_context(graph, "xyz totally unknown")
        payload = assemble_context_payload(bundle, question="What is your favorite color?")
        assert "What is your favorite color?" in payload

    def test_low_confidence_nodes_shown_with_hedge_marker(self, populated_graph):
        graph, ids = populated_graph
        # low1 has confidence=0.30
        bundle = retrieve_context(graph, "react frontend")
        if any(rn.node_id == ids["low1"] for rn in bundle.nodes):
            payload = assemble_context_payload(bundle)
            assert "UNCERTAIN KNOWLEDGE" in payload

    def test_keywords_shown_in_header(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(graph, "Python backend")
        payload = assemble_context_payload(bundle)
        assert "Query keywords:" in payload

    def test_hop_count_shown_for_inferred_nodes(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(graph, "Python", bfs_depth=2, include_edge_seeds=False)
        inferred = [rn for rn in bundle.nodes if rn.depth > 0]
        if inferred:
            payload = assemble_context_payload(bundle)
            assert "hop" in payload  # "1 hop" or "2 hops"

    def test_node_type_shown_in_payload(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(graph, "Python")
        payload = assemble_context_payload(bundle)
        # Node type headers like [preference | ...] or [value | ...] should appear
        assert "[preference" in payload or "[value" in payload or "[pattern" in payload


class TestContextBundleToPromptPayload:
    """Tests for ContextBundle.to_prompt_payload() convenience method."""

    def test_to_prompt_payload_delegates_to_assemble(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(graph, "Python backend")
        q = "What language do you use for backend?"
        via_method = bundle.to_prompt_payload(question=q)
        via_function = assemble_context_payload(bundle, question=q)
        assert via_method == via_function

    def test_to_prompt_payload_no_args(self, populated_graph):
        graph, ids = populated_graph
        bundle = retrieve_context(graph, "Python")
        payload = bundle.to_prompt_payload()
        assert "=== KNOWLEDGE CONTEXT ===" in payload

    def test_to_prompt_payload_empty_bundle(self, graph):
        bundle = retrieve_context(graph, "nothing here ever")
        payload = bundle.to_prompt_payload()
        assert "No relevant knowledge" in payload
