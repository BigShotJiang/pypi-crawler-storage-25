"""Platform-specific paths for license-sdk config files."""
from __future__ import annotations
import os
from pathlib import Path


def user_config_path() -> Path:
    """Return the user-level config.toml path. Respects LICENSE_SDK_USER_CONFIG env override (test-only)."""
    override = os.environ.get("LICENSE_SDK_USER_CONFIG")
    if override:
        return Path(override)
    # XDG-compliant on Linux/Mac; best-effort fallback on Windows
    xdg_home = os.environ.get("XDG_CONFIG_HOME")
    if xdg_home:
        return Path(xdg_home) / "license-sdk" / "config.toml"
    return Path.home() / ".config" / "license-sdk" / "config.toml"


def system_config_path() -> Path:
    """Return the system-level config.toml path. Respects LICENSE_SDK_SYSTEM_CONFIG env override (test-only)."""
    override = os.environ.get("LICENSE_SDK_SYSTEM_CONFIG")
    if override:
        return Path(override)
    return Path("/etc/license-sdk/config.toml")


def cache_dir() -> Path:
    """Return the cache directory for key and JWT state."""
    xdg_cache = os.environ.get("XDG_CACHE_HOME")
    if xdg_cache:
        return Path(xdg_cache) / "license-sdk"
    return Path.home() / ".cache" / "license-sdk"
