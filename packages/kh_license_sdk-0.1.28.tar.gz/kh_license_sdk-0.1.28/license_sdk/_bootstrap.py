"""Auto-register the LicenceImportHook at Python startup via .pth file.

The .pth file `_license_sdk.pth` contains:
    import license_sdk._bootstrap; license_sdk._bootstrap.install()

install() silent-fails in every possible way to guarantee Python can always start.
"""
from __future__ import annotations
import sys


def install() -> None:
    """Read config, instantiate hook, register in sys.meta_path. Silent fail on any error."""
    try:
        _install_impl()
    except Exception:
        # Absolutely never crash Python startup
        pass


def _install_impl() -> None:
    from license_sdk._config import load_runtime_config
    cfg = load_runtime_config()

    token = cfg.get("auth", {}).get("token")
    server_url = cfg.get("server", {}).get("url")
    client_id = cfg.get("server", {}).get("client_id")
    if not (token and server_url and client_id):
        return  # no valid config — silent no-op

    # Try to import the compiled agent (may be absent on dev machines)
    try:
        from license_agent.hook import LicenceImportHook
        from license_agent.refresh import KeyRefreshClient
        from license_agent.audit import AuditBuffer
    except ImportError:
        return
    # Guard against pytest monkeypatching modules to None
    if LicenceImportHook is None or KeyRefreshClient is None or AuditBuffer is None:
        return

    from license_sdk._config_paths import cache_dir as _cache_dir
    cache = str(cfg.get("cache", {}).get("dir", _cache_dir()))

    root_pem = cfg.get("security", {}).get("root_public_key") or ""

    refresh_client = KeyRefreshClient(
        server_url=server_url,
        client_id=client_id,
        api_token=token,
        cache_dir=cache,
        pinned_root_public_key_pem=root_pem,
    )
    audit = AuditBuffer(cache_dir=cache)
    hook = LicenceImportHook(
        protected_packages=frozenset(),  # auto-discovery would live here; current API accepts frozenset
        cache_dir=cache,
        pinned_root_public_key_pem=root_pem,
        refresh_client=refresh_client,
        audit_buffer=audit,
    )
    sys.meta_path.insert(0, hook)
