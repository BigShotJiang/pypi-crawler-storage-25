"""Multi-source runtime configuration for license-sdk.

Resolution order (first match wins):
  1. Environment variable LICENSE_SDK_TOKEN (and related)
  2. User config file (~/.config/license-sdk/config.toml)
  3. System config file (/etc/license-sdk/config.toml)
"""
from __future__ import annotations
import os
from pathlib import Path

try:
    import tomllib  # Python 3.11+
except ModuleNotFoundError:  # pragma: no cover - Py3.10 fallback
    import tomli as tomllib  # type: ignore[no-redef]

from license_sdk._config_paths import user_config_path, system_config_path, cache_dir


# Backward-compat legacy constants — callers that still use these fall back to
# environment variables that were the historical interface.
CACHE_DIR = os.environ.get("MYCOMPANY_CACHE_DIR", str(cache_dir()))
PROXY_URL = os.environ.get("MYCOMPANY_PROXY_URL", "")
PINNED_ROOT_PUBLIC_KEY_PEM = os.environ.get("MYCOMPANY_ROOT_PUBLIC_KEY", "")


def _read_toml(path: Path) -> dict:
    """Read a TOML file, return {} on any error (silent fail)."""
    try:
        with open(path, "rb") as f:
            return tomllib.load(f)
    except (FileNotFoundError, tomllib.TOMLDecodeError, PermissionError, OSError):
        return {}


def load_runtime_config() -> dict:
    """Load and merge config from all three sources.

    Returns a dict with keys: auth.token, server.url, server.client_id,
    cache.dir (resolved path), refresh.key_rotation_days, refresh.grace_period_days.

    Missing fields are simply absent. Callers must handle that.
    """
    # Start from system config (lowest priority)
    merged: dict = {}
    sys_cfg = _read_toml(system_config_path())
    _deep_merge(merged, sys_cfg)
    user_cfg = _read_toml(user_config_path())
    _deep_merge(merged, user_cfg)

    # Env var override for token (highest priority)
    token = os.environ.get("LICENSE_SDK_TOKEN")
    if token:
        merged.setdefault("auth", {})["token"] = token
    return merged


def _deep_merge(base: dict, override: dict) -> None:
    """Recursively merge override into base."""
    for k, v in override.items():
        if isinstance(v, dict) and isinstance(base.get(k), dict):
            _deep_merge(base[k], v)
        else:
            base[k] = v
