"""`kh-license` CLI for configuring the SDK.

Commands:
  login      — interactive or --token/--server; writes config + pip.conf
  status     — shows detected token source + active licences
  logout     — removes config + restores pip.conf
  bootstrap  — non-interactive; uses LICENSE_SDK_TOKEN env var; for CI/CD
"""
from __future__ import annotations
import argparse
import getpass
import os
import sys
from pathlib import Path

import httpx

from license_sdk._config import load_runtime_config
from license_sdk._config_paths import user_config_path
from license_sdk._pipconfig import detect_pip_config_path, write_pip_config, PipConfigUnchanged


def _write_config(path: Path, token: str, server_url: str, client_id: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    content = (
        f'[server]\nurl = "{server_url}"\nclient_id = "{client_id}"\n\n'
        f'[auth]\ntoken = "{token}"\n'
    )
    path.write_text(content)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def _validate_token_with_server(token: str, server_url: str) -> tuple[bool, str | None, str | None]:
    """POST or GET to the server to validate token. Returns (ok, client_id, error_msg)."""
    try:
        resp = httpx.get(
            f"{server_url.rstrip('/')}/api/v1/keys/current",
            auth=(token, ""),  # token passed as Basic-Auth username
            timeout=5.0,
        )
    except Exception as exc:
        return False, None, f"Network error: {exc}"
    if resp.status_code == 200:
        # We don't actually get client_id from /keys; in a richer flow we'd have
        # a dedicated /api/v1/whoami endpoint. For now derive a placeholder.
        body = resp.json() if callable(getattr(resp, "json", None)) else {}
        client_id = body.get("client_id", "unknown")
        return True, client_id, None
    return False, None, f"Server rejected token (HTTP {resp.status_code})"


def _cmd_login(args) -> int:
    token = args.token or os.environ.get("LICENSE_SDK_TOKEN")
    if not token and sys.stdin.isatty():
        token = getpass.getpass("Token: ")
    if not token:
        print("ERROR: token required (--token, stdin, or LICENSE_SDK_TOKEN)", file=sys.stderr)
        return 2

    server = args.server or os.environ.get("LICENSE_SDK_SERVER_URL")
    if not server:
        print("ERROR: --server is required on first login", file=sys.stderr)
        return 2

    ok, client_id, err = _validate_token_with_server(token, server)
    if not ok:
        print(f"ERROR: {err}", file=sys.stderr)
        return 1

    cfg_path = user_config_path()
    _write_config(cfg_path, token, server, client_id or "unknown")
    print(f"Wrote {cfg_path}")

    if not args.skip_pip_config:
        pip_path = detect_pip_config_path()
        index_url = f"https://__token__:{token}@{server.rstrip('/').split('://')[-1]}/pypi/simple"
        try:
            write_pip_config(
                pip_path, index_url=index_url,
                confirm_overwrite=lambda old: _ask_yes_no(f"Overwrite existing index-url ({old})?"),
            )
            print(f"Wrote {pip_path}")
        except PipConfigUnchanged:
            print(f"Skipped {pip_path} (kept existing index-url)")
    return 0


def _cmd_bootstrap(args) -> int:
    token = os.environ.get("LICENSE_SDK_TOKEN")
    if not token:
        print("ERROR: LICENSE_SDK_TOKEN not set", file=sys.stderr)
        return 2
    server = os.environ.get("LICENSE_SDK_SERVER_URL")
    if not server:
        print("ERROR: LICENSE_SDK_SERVER_URL not set", file=sys.stderr)
        return 2
    ok, client_id, err = _validate_token_with_server(token, server)
    if not ok:
        print(f"ERROR: {err}", file=sys.stderr)
        return 1
    cfg_path = user_config_path()
    _write_config(cfg_path, token, server, client_id or "unknown")
    pip_path = detect_pip_config_path()
    index_url = f"https://__token__:{token}@{server.rstrip('/').split('://')[-1]}/pypi/simple"
    try:
        write_pip_config(
            pip_path, index_url=index_url,
            confirm_overwrite=lambda old: True,  # non-interactive
        )
    except PipConfigUnchanged:
        pass
    print("bootstrap OK")
    return 0


def _cmd_logout(args) -> int:
    cfg_path = user_config_path()
    if not cfg_path.exists():
        print("Nothing to do (config not present).")
        return 0
    if not args.yes and sys.stdin.isatty():
        if not _ask_yes_no(f"Remove {cfg_path}?"):
            return 1
    cfg_path.unlink()
    print(f"Removed {cfg_path}")
    return 0


def _cmd_status(args) -> int:
    token_source = _detect_token_source()
    if token_source == "none":
        print("Not configured. Run `kh-license login` to get started.")
        return 1
    print(f"Token source: {token_source}")
    cfg = load_runtime_config()
    server = cfg.get("server", {}).get("url")
    client_id = cfg.get("server", {}).get("client_id")
    print(f"Server: {server}")
    print(f"Client ID: {client_id}")
    # Querying live licences is nice-to-have; stub for now.
    return 0


def _detect_token_source() -> str:
    if os.environ.get("LICENSE_SDK_TOKEN"):
        return "env (LICENSE_SDK_TOKEN)"
    from license_sdk._config_paths import user_config_path as ucp, system_config_path as scp
    if ucp().exists():
        return f"user ({ucp()})"
    if scp().exists():
        return f"system ({scp()})"
    return "none"


def _ask_yes_no(prompt: str) -> bool:
    try:
        answer = input(f"{prompt} [y/N] ").strip().lower()
    except EOFError:
        return False
    return answer in ("y", "yes")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="kh-license", description="License SDK CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    p_login = sub.add_parser("login", help="Configure token + pip.conf")
    p_login.add_argument("--token")
    p_login.add_argument("--server")
    p_login.add_argument("--skip-pip-config", action="store_true")
    p_login.set_defaults(func=_cmd_login)

    p_boot = sub.add_parser("bootstrap", help="Non-interactive login for CI")
    p_boot.set_defaults(func=_cmd_bootstrap)

    p_logout = sub.add_parser("logout", help="Remove local config")
    p_logout.add_argument("--yes", action="store_true")
    p_logout.set_defaults(func=_cmd_logout)

    p_stat = sub.add_parser("status", help="Show configuration + active licences")
    p_stat.set_defaults(func=_cmd_status)

    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
