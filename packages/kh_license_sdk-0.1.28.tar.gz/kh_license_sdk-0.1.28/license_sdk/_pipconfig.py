"""Read / merge / write pip.conf to configure the proxy index-url."""
from __future__ import annotations
import os
from pathlib import Path
from configparser import ConfigParser
from typing import Callable


PUBLIC_PYPI = "https://pypi.org/simple"


class PipConfigUnchanged(Exception):
    """Raised when the user refused to overwrite an existing index-url."""


def detect_pip_config_path() -> Path:
    """Return the most likely pip.conf path for the current OS.

    Precedence:
      1. PIP_CONFIG_FILE env var
      2. ~/.config/pip/pip.conf (Linux/Mac, XDG)
      3. ~/.pip/pip.conf (older)
      4. %APPDATA%\\pip\\pip.ini (Windows, best-effort)
    """
    override = os.environ.get("PIP_CONFIG_FILE")
    if override:
        return Path(override)
    xdg_home = os.environ.get("XDG_CONFIG_HOME")
    if xdg_home:
        return Path(xdg_home) / "pip" / "pip.conf"
    candidate = Path.home() / ".config" / "pip" / "pip.conf"
    if candidate.exists() or os.name != "nt":
        return candidate
    # Windows fallback
    appdata = os.environ.get("APPDATA")
    if appdata:
        return Path(appdata) / "pip" / "pip.ini"
    return Path.home() / "pip" / "pip.ini"


def write_pip_config(
    target: Path,
    index_url: str,
    confirm_overwrite: Callable[[str], bool] = None,
) -> None:
    """Merge-write pip config. Adds index-url and ensures PyPI fallback in extra-index-url.

    Args:
        target: path to pip.conf
        index_url: the new index-url to set
        confirm_overwrite: called with the existing index_url if different, must return True to proceed
    """
    target.parent.mkdir(parents=True, exist_ok=True)
    parser = ConfigParser()
    if target.exists():
        parser.read(target)
    if not parser.has_section("global"):
        parser.add_section("global")

    existing = parser["global"].get("index-url")
    if existing and existing != index_url:
        if confirm_overwrite is None or not confirm_overwrite(existing):
            raise PipConfigUnchanged()

    parser["global"]["index-url"] = index_url

    # Ensure PyPI fallback in extra-index-url
    extras_raw = parser["global"].get("extra-index-url", "")
    extras = [e.strip() for e in extras_raw.replace("\n", " ").split() if e.strip()]
    if PUBLIC_PYPI not in extras:
        extras.append(PUBLIC_PYPI)
    parser["global"]["extra-index-url"] = "\n    ".join(extras)

    with open(target, "w") as f:
        parser.write(f)
    try:
        os.chmod(target, 0o600)
    except OSError:
        pass  # Windows may reject; best effort
