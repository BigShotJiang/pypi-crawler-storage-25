"""Minimal shim for packaging the .pth file, which modern pyproject.toml does not handle directly.

The `.pth` must land in site-packages so Python's site.py runs it at interpreter
startup. Plain `data_files=[("", [...])]` places files under the `data` scheme
(sys.prefix), which is NOT scanned for .pth files.

Workaround: we override `install_lib` to also copy the .pth into the purelib
destination at wheel-install time, which is what actually lands in site-packages.
"""
from setuptools import setup
from setuptools.command.install_lib import install_lib as _install_lib
import os
import shutil


PTH_FILENAME = "_license_sdk.pth"


class _InstallLibWithPth(_install_lib):
    def run(self):
        super().run()
        here = os.path.dirname(os.path.abspath(__file__))
        src = os.path.join(here, PTH_FILENAME)
        if os.path.exists(src) and self.install_dir:
            try:
                os.makedirs(self.install_dir, exist_ok=True)
                shutil.copy2(src, os.path.join(self.install_dir, PTH_FILENAME))
            except OSError:
                pass  # best-effort


setup(
    data_files=[("", [PTH_FILENAME])],
    cmdclass={
        "install_lib": _InstallLibWithPth,
    },
)
