"""Tests for AVC MCP Client."""

import pytest

from avc_mcp_client import AVCMCPClient, AsyncAVCMCPClient, Resolution, TaskStatus
from avc_mcp_client.exceptions import MCPParseError, MCPToolError


class TestResolution:
    """Tests for Resolution enum."""

    def test_resolution_values(self):
        """Test that all resolution values are correct."""
        assert Resolution.P480.value == "480p"
        assert Resolution.P540.value == "540p"
        assert Resolution.P720.value == "720p"
        assert Resolution.P1080.value == "1080p"
        assert Resolution.P2K.value == "2k"

    def test_resolution_from_string(self):
        """Test creating Resolution from string."""
        assert Resolution("720p") == Resolution.P720
        assert Resolution("1080p") == Resolution.P1080


class TestTaskStatus:
    """Tests for TaskStatus enum."""

    def test_status_values(self):
        """Test that all status values are correct."""
        assert TaskStatus.WAIT.value == "wait"
        assert TaskStatus.START.value == "start"
        assert TaskStatus.PROCESSING.value == "processing"
        assert TaskStatus.COMPLETED.value == "completed"
        assert TaskStatus.FAILED.value == "failed"


class TestAVCMCPClient:
    """Tests for AVCMCPClient."""

    def test_init_default_values(self):
        """Test client initialization with default values."""
        client = AVCMCPClient()
        assert client.base_url == "http://192.168.0.7:8001"
        assert client.api_key is None
        assert client.timeout == 600.0
        assert client.poll_interval == 5.0

    def test_init_custom_values(self):
        """Test client initialization with custom values."""
        client = AVCMCPClient(
            base_url="http://custom:9000",
            api_key="test-key",
            timeout=300.0,
            poll_interval=10.0,
        )
        assert client.base_url == "http://custom:9000"
        assert client.api_key == "test-key"
        assert client.timeout == 300.0
        assert client.poll_interval == 10.0

    def test_base_url_trailing_slash(self):
        """Test that trailing slash is removed from base_url."""
        client = AVCMCPClient(base_url="http://192.168.0.7:8001/")
        assert client.base_url == "http://192.168.0.7:8001"

    def test_get_headers_with_api_key(self):
        """Test that headers include API key when set."""
        client = AVCMCPClient(api_key="test-key")
        headers = client._get_headers()
        assert headers["X-API-Key"] == "test-key"
        assert headers["Content-Type"] == "application/json"

    def test_get_headers_without_api_key(self):
        """Test that headers don't include API key when not set."""
        client = AVCMCPClient()
        headers = client._get_headers()
        assert "X-API-Key" not in headers

    def test_build_request(self):
        """Test building JSON-RPC request."""
        client = AVCMCPClient()
        request = client._build_request("test_tool", {"arg1": "value1"})

        assert request["jsonrpc"] == "2.0"
        assert request["method"] == "tools/call"
        assert request["params"]["name"] == "test_tool"
        assert request["params"]["arguments"] == {"arg1": "value1"}

    def test_request_id_increments(self):
        """Test that request ID increments."""
        client = AVCMCPClient()
        id1 = client._get_request_id()
        id2 = client._get_request_id()
        assert id2 == id1 + 1


class TestAsyncAVCMCPClient:
    """Tests for AsyncAVCMCPClient."""

    def test_init_default_values(self):
        """Test async client initialization with default values."""
        client = AsyncAVCMCPClient()
        assert client.base_url == "http://192.168.0.7:8001"
        assert client.api_key is None
        assert client.timeout == 600.0
        assert client.poll_interval == 5.0


# Integration tests (require running MCP server)
# Mark with pytest.mark.integration to skip by default


@pytest.mark.integration
class TestIntegration:
    """Integration tests requiring a running MCP server."""

    @pytest.fixture
    def client(self):
        """Create client for integration tests."""
        return AVCMCPClient(
            base_url="http://192.168.0.7:8001",
            api_key="test-api-key",  # Replace with valid key
        )

    def test_enhance_video_async(self, client):
        """Test async video enhancement."""
        # This test requires a valid video URL and API key
        result = client.enhance_video_async(
            video_url="https://example.com/test.mp4",  # Replace with valid URL
            resolution="720p",
        )
        assert result.success
        assert result.task_id
