# PyPI 发布完整指南

本文档详细说明如何将 `avc-mcp-client` 包发布到 PyPI（Python Package Index）。

---

## 目录

1. [发布前准备](#1-发布前准备)
2. [安装构建工具](#2-安装构建工具)
3. [更新版本号](#3-更新版本号)
4. [构建分发包](#4-构建分发包)
5. [检查包质量](#5-检查包质量)
6. [注册 PyPI 账号](#6-注册-pypi-账号)
7. [创建 API Token](#7-创建-api-token)
8. [配置认证信息](#8-配置认证信息)
9. [上传到 PyPI](#9-上传到-pypi)
10. [验证发布](#10-验证发布)
11. [完整命令清单](#11-完整命令清单)
12. [常见问题](#12-常见问题)

---

## 1. 发布前准备

### 1.1 检查项目结构

确保项目包含以下文件：

```
avc_mcp/
├── pyproject.toml          # 包配置（必需）
├── README.md               # 项目说明（必需）
├── LICENSE                 # 许可证文件（推荐）
├── src/
│   └── avc_mcp_client/
│       ├── __init__.py     # 包入口（必需）
│       ├── client.py
│       ├── types.py
│       └── exceptions.py
└── tests/                  # 测试目录
```

### 1.2 检查 pyproject.toml

确认以下字段已正确填写：

```toml
[project]
name = "avc-mcp-client"           # PyPI 上的包名（唯一）
version = "0.1.0"                 # 版本号
description = "..."               # 简短描述
readme = "README.md"              # README 文件路径
license = "MIT"                   # 许可证
requires-python = ">=3.10"       # Python 版本要求
authors = [{ name = "..." }]      # 作者信息
```

---

## 2. 安装构建工具

### 2.1 使用 uv（推荐，本项目已使用 uv）

```bash
uv pip install build twine
```

**注意**：本项目使用 `uv` 作为包管理器，与项目根目录的 `uv.lock` 文件对应。

### 2.2 使用 pip（备选）

```bash
pip install build twine
```

### 工具说明

| 工具 | 用途 |
|-----|------|
| `build` | 将源码打包成 wheel 和 sdist 格式 |
| `twine` | 安全地将包上传到 PyPI |

---

## 3. 更新版本号

**重要：每次发布必须使用新的版本号！**

### 3.1 语义化版本（Semantic Versioning）

版本格式：`主版本.次版本.修订号`（如 `1.2.3`）

| 版本类型 | 含义 | 示例 |
|---------|------|------|
| 主版本 (Major) | 不兼容的 API 修改 | `1.0.0` → `2.0.0` |
| 次版本 (Minor) | 向下兼容的功能新增 | `1.0.0` → `1.1.0` |
| 修订号 (Patch) | 向下兼容的问题修复 | `1.0.0` → `1.0.1` |

### 3.2 修改版本号

编辑 `pyproject.toml` 文件：

```toml
[project]
version = "0.1.1"  # ← 修改这里
```

### 3.3 版本号规则

- 首次发布建议用 `0.1.0`
- 修复 bug 用 `0.1.1`
- 新增功能用 `0.2.0`
- 重大更新用 `1.0.0`

---

## 4. 构建分发包

### 4.1 清理旧构建（重要）

```bash
# Windows
rmdir /s /q dist build
rmdir /s /q src\avc_mcp_client.egg-info

# Linux/Mac
rm -rf dist build *.egg-info
```

### 4.2 执行构建

使用 `uv run` 确保使用项目虚拟环境中的 Python：

```bash
uv run python -m build
```

**注意**：不要直接用 `python -m build`，因为系统可能使用 Anaconda 或其他 Python，导致找不到已安装的包。

如果用普通 pip，则先激活虚拟环境：
```bash
# Windows
.venv\Scripts\activate

# Linux/Mac
source .venv/bin/activate

# 然后再构建
python -m build
```

### 4.3 构建输出

执行成功后生成 `dist/` 目录：

```
dist/
├── avc_mcp_client-0.1.0-py3-none-any.whl   # Wheel 格式（二进制）
└── avc_mcp_client-0.1.0.tar.gz             # Source 格式（源码）
```

### 两种格式说明

| 格式 | 扩展名 | 用途 |
|-----|--------|------|
| Wheel | `.whl` | 预编译格式，安装速度快 |
| SDist | `.tar.gz` | 源码格式，可重新构建 |

---

## 5. 检查包质量

### 5.1 使用 twine 检查

```bash
uv run twine check dist/*
```

或用普通 pip（需先激活虚拟环境）：
```bash
twine check dist/*
```

### 5.2 预期输出

```
Checking dist/avc_mcp_client-0.1.0-py3-none-any.whl: PASSED
Checking dist/avc_mcp_client-0.1.0.tar.gz: PASSED
```

### 5.3 本地测试安装

```bash
# 创建测试虚拟环境
python -m venv test_env

# Windows 激活
test_env\Scripts\activate

# Linux/Mac 激活
source test_env/bin/activate

# 本地安装测试
pip install dist\avc_mcp_client-0.1.0-py3-none-any.whl

# 验证安装
python -c "from avc_mcp_client import AVCMCPClient; print('安装成功')"
```

---

## 6. 注册 PyPI 账号

### 6.1 访问官网

打开 https://pypi.org/account/register/

### 6.2 填写注册信息

- **Username**: 用户名（唯一，会显示在 URL 中）
- **Email**: 邮箱地址（需要验证）
- **Password**: 密码（至少 8 位，包含大小写和数字）

### 6.3 验证邮箱

1. 登录注册邮箱
2. 查找来自 PyPI 的验证邮件
3. 点击验证链接完成验证

**注意：必须验证邮箱才能上传包！**

---

## 7. 创建 API Token

### 7.1 为什么用 Token？

- ✅ 比密码更安全
- ✅ 可限制权限范围
- ✅ 可随时撤销

### 7.2 创建步骤

1. 登录 https://pypi.org/manage/account/
2. 左侧菜单点击 **API tokens**
3. 点击 **Add API token** 按钮
4. 填写信息：
   - **Token name**: `avc-mcp-client-upload`（任意名称）
   - **Scope**: 
     - 首次发布选 **Entire account**（整个账户）
     - 后续可选具体项目 **Project: avc-mcp-client**
5. 点击 **Add token**
6. **立即复制 Token**（格式如 `pypi-AgEIcHlwaS5vcmcCJ...`）

**⚠️ 警告：Token 只显示一次，务必保存好！**

---

## 8. 配置认证信息

### 方式 A：环境变量（推荐）

**Windows PowerShell:**
```powershell
$env:TWINE_USERNAME = "__token__"
$env:TWINE_PASSWORD = "pypi-AgEIcHlwaS5vcmcCJ..."  # 你的 Token
```

**Windows CMD:**
```cmd
set TWINE_USERNAME=__token__
set TWINE_PASSWORD=pypi-AgEIcHlwaS5vcmcCJ...
```

**Linux/Mac:**
```bash
export TWINE_USERNAME=__token__
export TWINE_PASSWORD=pypi-AgEIcHlwaS5vcmcCJ...
```

### 方式 B：配置文件 .pypirc

创建文件（Windows 路径）：
```
C:\Users\你的用户名\.pypirc
```

或（Linux/Mac 路径）：
```
~/.pypirc
```

文件内容：
```ini
[pypi]
username = __token__
password = pypi-AgEIcHlwaS5vcmcCJ...
```

### 方式对比

| 方式 | 优点 | 缺点 |
|-----|------|------|
| 环境变量 | 安全，不写入文件 | 每次新终端需重新设置 |
| .pypirc | 一次设置，永久使用 | Token 明文存储在文件中 |

---

## 9. 上传到 PyPI

### 9.1 正式上传

```bash
uv run twine upload dist/*
```

或用普通 pip（需先激活虚拟环境）：
```bash
twine upload dist/*
```

### 9.2 上传过程输出

```
Uploading distributions to https://upload.pypi.org/legacy/
Uploading avc_mcp_client-0.1.0-py3-none-any.whl
100%|████████████████| 12.3k/12.3k [00:01<00:00, 10.2kB/s]
Uploading avc_mcp_client-0.1.0.tar.gz
100%|████████████████| 10.1k/10.1k [00:01<00:00, 9.8kB/s]

View at:
https://pypi.org/project/avc-mcp-client/0.1.0/
```

### 9.3 上传到 TestPyPI（可选测试）

```bash
# 上传到测试环境（不影响正式包）
twine upload --repository testpypi dist/*
```

TestPyPI 地址：https://test.pypi.org/

---

## 10. 验证发布

### 10.1 网页验证

访问包页面：
```
https://pypi.org/project/avc-mcp-client/
```

检查内容：
- [ ] 版本号正确
- [ ] README 显示正常
- [ ] 项目链接可点击
- [ ] 作者信息正确
- [ ] 许可证显示正确

### 10.2 安装验证

```bash
# 从 PyPI 安装
pip install avc-mcp-client

# 验证版本
pip show avc-mcp-client

# 导入测试
python -c "from avc_mcp_client import AVCMCPClient; print('成功导入')"
```

### 10.3 卸载本地测试包

```bash
pip uninstall avc-mcp-client
```

---

## 11. 完整命令清单

### 一键发布脚本（Windows PowerShell，使用 uv）

```powershell
# 1. 安装工具
uv pip install build twine

# 2. 清理旧构建
Remove-Item -Recurse -Force dist, build -ErrorAction SilentlyContinue
Remove-Item -Recurse -Force src\avc_mcp_client.egg-info -ErrorAction SilentlyContinue

# 3. 构建（使用 uv run）
uv run python -m build

# 4. 检查
uv run twine check dist/*

# 5. 设置认证（替换为你的 Token）
$env:TWINE_USERNAME = "__token__"
$env:TWINE_PASSWORD = "pypi-你的Token"

# 6. 上传
uv run twine upload dist/*

# 7. 验证安装
pip install avc-mcp-client
python -c "from avc_mcp_client import AVCMCPClient; print('发布成功')"
```

### 一键发布脚本（Linux/Mac，使用 uv）

```bash
#!/bin/bash

# 1. 安装工具
uv pip install build twine

# 2. 清理旧构建
rm -rf dist build *.egg-info

# 3. 构建（使用 uv run）
uv run python -m build

# 4. 检查
uv run twine check dist/*

# 5. 设置认证（替换为你的 Token）
export TWINE_USERNAME="__token__"
export TWINE_PASSWORD="pypi-你的Token"

# 6. 上传
uv run twine upload dist/*

# 7. 验证
pip install avc-mcp-client
python -c "from avc_mcp_client import AVCMCPClient; print('发布成功')"
```

---

## 12. 常见问题

### Q1: 版本号冲突

**错误信息：**
```
HTTPError: 400 Bad Request from https://upload.pypi.org/legacy/
File already exists. See https://pypi.org/help/#file-name-reuse
```

**原因：** 该版本号已存在，不能重复上传。

**解决：** 修改 `pyproject.toml` 中的 `version`，使用新版本号。

---

### Q2: 认证失败

**错误信息：**
```
HTTPError: 403 Forbidden from https://upload.pypi.org/legacy/
Invalid or non-existent authentication information.
```

**原因：** Token 错误或过期。

**解决：**
1. 检查 Token 是否完整复制
2. 确认 Token 未过期
3. 重新生成 Token

---

### Q3: 包名已被占用

**错误信息：**
```
HTTPError: 403 Forbidden from https://upload.pypi.org/legacy/
The name 'xxx' isn't allowed.
```

**原因：** 包名已被他人使用或 PyPI 保留。

**解决：** 修改 `pyproject.toml` 中的 `name` 字段，使用新包名。

---

### Q4: README 未显示

**原因：** README 格式问题或文件路径错误。

**解决：**
1. 确认 `pyproject.toml` 中有 `readme = "README.md"`
2. 检查 README.md 文件存在
3. 重新构建并上传

---

### Q5: 依赖未安装

**原因：** 依赖未正确声明。

**解决：** 确认 `pyproject.toml` 中：

```toml
[project]
dependencies = [
    "httpx>=0.27.0",
    "pydantic>=2.0.0",
]
```

---

### Q6: `No module named build` 错误

**错误信息：**
```
python.exe: No module named build
```

**原因：** 
- 使用 `uv pip install` 把包装到了项目虚拟环境（`.venv`）
- 但直接运行 `python` 调用的是系统 Python（如 Anaconda）
- 系统 Python 没有安装 `build` 包

**解决：** 使用 `uv run` 前缀，让 uv 自动使用项目虚拟环境：

```bash
# ❌ 错误：可能调用系统 Python
python -m build

# ✅ 正确：使用 uv 项目环境
uv run python -m build
uv run twine check dist/*
uv run twine upload dist/*
```

---

## 附录

### 相关链接

- PyPI 官网：https://pypi.org/
- TestPyPI 测试站：https://test.pypi.org/
- Python 打包指南：https://packaging.python.org/
- 语义化版本规范：https://semver.org/lang/zh-CN/

### 包信息

| 属性 | 值 |
|-----|-----|
| 包名 | avc-mcp-client |
| 当前版本 | 0.1.0 |
| Python 要求 | >=3.10 |
| 构建工具 | hatchling |
| 许可证 | MIT |

---

**文档版本：1.0**  
**最后更新：2026-04-02**
