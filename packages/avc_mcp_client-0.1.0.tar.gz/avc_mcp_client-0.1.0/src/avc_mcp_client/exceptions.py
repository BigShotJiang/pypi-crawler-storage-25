"""Exceptions for AVC MCP Client."""


class MCPClientError(Exception):
    """Base exception for MCP client errors."""

    pass


class MCPConnectionError(MCPClientError):
    """Raised when connection to MCP server fails."""

    pass


class MCPParseError(MCPClientError):
    """Raised when response parsing fails."""

    pass


class MCPToolError(MCPClientError):
    """Raised when tool execution fails."""

    def __init__(self, message: str, code: int | None = None):
        super().__init__(message)
        self.code = code


class MPCTimeoutError(MCPClientError):
    """Raised when operation times out."""

    pass


class MCPAuthenticationError(MCPClientError):
    """Raised when authentication fails."""

    pass


class FileSizeExceededError(MCPClientError):
    """Raised when local file size exceeds 100MB limit."""

    def __init__(self, size_mb: float, max_mb: float = 100.0):
        message = f"文件大小 {size_mb:.1f}MB 超过限制 {max_mb:.0f}MB"
        super().__init__(message)
        self.size_mb = size_mb
        self.max_mb = max_mb


class FileNotFoundError(MCPClientError):
    """Raised when local file does not exist."""

    pass
