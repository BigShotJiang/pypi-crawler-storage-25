"""MCP Client for AVC video enhancement service."""

import base64
import json
import os
import time
from typing import Any

import httpx

from .exceptions import (
    MCPAuthenticationError,
    MCPClientError,
    MCPConnectionError,
    MCPParseError,
    MPCTimeoutError,
    MCPToolError,
    FileSizeExceededError,
    FileNotFoundError,
)
from .types import AsyncTaskResult, EnhanceResult, Resolution, TaskStatusResult, VideoType


# 最大文件大小：100MB
MAX_FILE_SIZE = 100 * 1024 * 1024


class AVCMCPClient:
    """
    Client for AVC video enhancement MCP service.

    Example:
        ```python
        from avc_mcp_client import AVCMCPClient

        client = AVCMCPClient(
            base_url="http://192.168.0.7:8001",
            api_key="your-api-key"
        )

        # URL 视频
        result = client.enhance_video_sync(
            video_url="https://example.com/video.mp4",
            type="url"
        )
        print(result.video_url)

        # 本地文件
        result = client.enhance_video_sync(
            video_url="/path/to/video.mp4",
            type="local"
        )
        print(result.video_url)
        ```
    """

    def __init__(
        self,
        base_url: str = "http://192.168.0.7:8001",
        api_key: str | None = None,
        timeout: float = 600.0,
        poll_interval: float = 5.0,
    ):
        """
        Initialize the MCP client.

        Args:
            base_url: Base URL of the MCP server
            api_key: API key for authentication
            timeout: Default timeout for requests (seconds)
            poll_interval: Interval for polling task status (seconds)
        """
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout
        self.poll_interval = poll_interval
        self._request_id = 0

    def _get_request_id(self) -> int:
        """Generate a unique request ID."""
        self._request_id += 1
        return self._request_id

    def _get_headers(self) -> dict[str, str]:
        """Get request headers including authentication."""
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream",
        }
        if self.api_key:
            headers["X-API-Key"] = self.api_key
        return headers

    def _build_request(self, tool_name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        """Build a JSON-RPC 2.0 request for MCP tool call."""
        return {
            "jsonrpc": "2.0",
            "id": self._get_request_id(),
            "method": "tools/call",
            "params": {
                "name": tool_name,
                "arguments": arguments,
            },
        }

    def _parse_response(self, response: httpx.Response) -> dict[str, Any]:
        """Parse MCP response and extract tool result.

        Handles SSE (Server-Sent Events) format:
        event: message
        data: {"jsonrpc":"2.0",...}
        """
        text = response.text

        # Parse SSE format
        data_line = None
        for line in text.strip().split("\n"):
            if line.startswith("data: "):
                data_line = line[6:]  # Remove "data: " prefix
                break

        if not data_line:
            raise MCPParseError(f"No data line in SSE response: {text[:200]}")

        try:
            data = json.loads(data_line)
        except json.JSONDecodeError as e:
            raise MCPParseError(f"Failed to parse response JSON: {e}") from e

        # Check for JSON-RPC error
        if "error" in data:
            error = data["error"]
            code = error.get("code")
            message = error.get("message", "Unknown error")

            if code == -32600 or "auth" in message.lower():
                raise MCPAuthenticationError(message)
            raise MCPToolError(message, code=code)

        # Extract tool result from MCP response
        if "result" not in data:
            raise MCPParseError("No result in MCP response")

        result = data["result"]
        content = result.get("content", [])

        if not content:
            raise MCPParseError("Empty content in MCP response")

        # Parse the text content
        text_content = content[0].get("text", "{}")
        try:
            return json.loads(text_content)
        except json.JSONDecodeError as e:
            raise MCPParseError(f"Failed to parse tool result: {e}") from e

    def _call_tool(self, tool_name: str, arguments: dict[str, Any], timeout: float | None = None) -> dict[str, Any]:
        """
        Call an MCP tool.

        Args:
            tool_name: Name of the tool to call
            arguments: Tool arguments
            timeout: Request timeout (uses default if None)

        Returns:
            Parsed tool result
        """
        request = self._build_request(tool_name, arguments)
        timeout_val = timeout or self.timeout

        try:
            with httpx.Client(timeout=timeout_val) as client:
                response = client.post(
                    f"{self.base_url}/mcp/",
                    json=request,
                    headers=self._get_headers(),
                )
                response.raise_for_status()
        except httpx.TimeoutException as e:
            raise MPCTimeoutError(f"Request timed out after {timeout_val}s") from e
        except httpx.ConnectError as e:
            raise MCPConnectionError(f"Failed to connect to MCP server: {e}") from e
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 401:
                raise MCPAuthenticationError("Authentication failed")
            raise MCPClientError(f"HTTP error: {e}") from e

        return self._parse_response(response)

    def _read_local_file(self, video_url: str) -> tuple[str, str]:
        """
        Read local file and return (filename, base64_data).

        Args:
            video_url: Local file path

        Returns:
            Tuple of (filename, base64_data)

        Raises:
            FileNotFoundError: If file does not exist
            FileSizeExceededError: If file size exceeds 100MB
        """
        # Check file exists
        if not os.path.exists(video_url):
            raise FileNotFoundError(f"文件不存在: {video_url}")

        # Check file size
        size = os.path.getsize(video_url)
        if size > MAX_FILE_SIZE:
            size_mb = size / (1024 * 1024)
            raise FileSizeExceededError(size_mb, 100.0)

        # Read and encode
        filename = os.path.basename(video_url)
        with open(video_url, 'rb') as f:
            file_data = base64.b64encode(f.read()).decode('utf-8')

        return filename, file_data

    def enhance_video_sync(
        self,
        video_url: str,
        resolution: Resolution | str = Resolution.P720,
        type: VideoType | str = VideoType.URL,
        timeout: float | None = None,
    ) -> EnhanceResult:
        """
        Enhance a video synchronously (blocks until complete).

        Args:
            video_url: Video URL or local file path
            resolution: Target resolution (default: 720p)
            type: Video source type - "url" or "local" (default: "url")
            timeout: Timeout in seconds (default: 600s)

        Returns:
            EnhanceResult with enhanced video URL

        Raises:
            MCPToolError: If enhancement fails
            MPCTimeoutError: If operation times out
            FileNotFoundError: If local file does not exist
            FileSizeExceededError: If local file exceeds 100MB
        """
        if isinstance(resolution, str):
            resolution = Resolution(resolution)
        if isinstance(type, str):
            type = VideoType(type)

        arguments = {
            "video_url": video_url,
            "resolution": resolution.value,
            "type": type.value,
        }

        # Handle local file
        if type == VideoType.LOCAL:
            filename, file_data = self._read_local_file(video_url)
            arguments["video_url"] = filename
            arguments["file_data"] = file_data

        result = self._call_tool("enhance_video_sync", arguments, timeout)
        return EnhanceResult.model_validate(result)

    def enhance_video_async(
        self,
        video_url: str,
        resolution: Resolution | str = Resolution.P720,
        type: VideoType | str = VideoType.URL,
    ) -> AsyncTaskResult:
        """
        Start video enhancement asynchronously.

        Args:
            video_url: Video URL or local file path
            resolution: Target resolution (default: 720p)
            type: Video source type - "url" or "local" (default: "url")

        Returns:
            AsyncTaskResult with task ID

        Raises:
            MCPToolError: If task creation fails
            FileNotFoundError: If local file does not exist
            FileSizeExceededError: If local file exceeds 100MB
        """
        if isinstance(resolution, str):
            resolution = Resolution(resolution)
        if isinstance(type, str):
            type = VideoType(type)

        arguments = {
            "video_url": video_url,
            "resolution": resolution.value,
            "type": type.value,
        }

        # Handle local file
        if type == VideoType.LOCAL:
            filename, file_data = self._read_local_file(video_url)
            arguments["video_url"] = filename
            arguments["file_data"] = file_data

        result = self._call_tool("enhance_video_async", arguments)
        return AsyncTaskResult.model_validate(result)

    def get_task_status(self, task_id: str) -> TaskStatusResult:
        """
        Get the status of a video enhancement task.

        Args:
            task_id: ID of the task to query

        Returns:
            TaskStatusResult with current status and video URL (if complete)

        Raises:
            MCPToolError: If query fails
        """
        arguments = {"task_id": task_id}
        result = self._call_tool("get_task_status", arguments)
        return TaskStatusResult.model_validate(result)

    def wait_for_task(
        self,
        task_id: str,
        timeout: float = 600.0,
        poll_interval: float | None = None,
    ) -> TaskStatusResult:
        """
        Wait for a task to complete.

        Args:
            task_id: ID of the task to wait for
            timeout: Maximum time to wait (seconds)
            poll_interval: Interval between status checks (uses client default if None)

        Returns:
            TaskStatusResult with final status

        Raises:
            MPCTimeoutError: If timeout is reached
            MCPToolError: If task fails
        """
        interval = poll_interval or self.poll_interval
        start_time = time.time()

        while True:
            result = self.get_task_status(task_id)

            if result.status in ("completed", "failed"):
                return result

            elapsed = time.time() - start_time
            if elapsed >= timeout:
                raise MPCTimeoutError(f"Task {task_id} did not complete within {timeout}s")

            time.sleep(interval)


class AsyncAVCMCPClient:
    """
    Async client for AVC video enhancement MCP service.

    Example:
        ```python
        from avc_mcp_client import AsyncAVCMCPClient

        async def main():
            client = AsyncAVCMCPClient(
                base_url="http://192.168.0.7:8001",
                api_key="your-api-key"
            )

            # 本地文件
            result = await client.enhance_video_sync(
                video_url="/path/to/video.mp4",
                type="local"
            )
            print(result.video_url)
        ```
    """

    def __init__(
        self,
        base_url: str = "http://192.168.0.7:8001",
        api_key: str | None = None,
        timeout: float = 600.0,
        poll_interval: float = 5.0,
    ):
        """
        Initialize the async MCP client.

        Args:
            base_url: Base URL of the MCP server
            api_key: API key for authentication
            timeout: Default timeout for requests (seconds)
            poll_interval: Interval for polling task status (seconds)
        """
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout
        self.poll_interval = poll_interval
        self._request_id = 0

    def _get_request_id(self) -> int:
        """Generate a unique request ID."""
        self._request_id += 1
        return self._request_id

    def _get_headers(self) -> dict[str, str]:
        """Get request headers including authentication."""
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream",
        }
        if self.api_key:
            headers["X-API-Key"] = self.api_key
        return headers

    def _build_request(self, tool_name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        """Build a JSON-RPC 2.0 request for MCP tool call."""
        return {
            "jsonrpc": "2.0",
            "id": self._get_request_id(),
            "method": "tools/call",
            "params": {
                "name": tool_name,
                "arguments": arguments,
            },
        }

    async def _parse_response(self, response: httpx.Response) -> dict[str, Any]:
        """Parse MCP response and extract tool result.

        Handles SSE (Server-Sent Events) format:
        event: message
        data: {"jsonrpc":"2.0",...}
        """
        text = response.text

        # Parse SSE format
        data_line = None
        for line in text.strip().split("\n"):
            if line.startswith("data: "):
                data_line = line[6:]  # Remove "data: " prefix
                break

        if not data_line:
            raise MCPParseError(f"No data line in SSE response: {text[:200]}")

        try:
            data = json.loads(data_line)
        except json.JSONDecodeError as e:
            raise MCPParseError(f"Failed to parse response JSON: {e}") from e

        if "error" in data:
            error = data["error"]
            code = error.get("code")
            message = error.get("message", "Unknown error")

            if code == -32600 or "auth" in message.lower():
                raise MCPAuthenticationError(message)
            raise MCPToolError(message, code=code)

        if "result" not in data:
            raise MCPParseError("No result in MCP response")

        result = data["result"]
        content = result.get("content", [])

        if not content:
            raise MCPParseError("Empty content in MCP response")

        text_content = content[0].get("text", "{}")
        try:
            return json.loads(text_content)
        except json.JSONDecodeError as e:
            raise MCPParseError(f"Failed to parse tool result: {e}") from e

    async def _call_tool(self, tool_name: str, arguments: dict[str, Any], timeout: float | None = None) -> dict[str, Any]:
        """Call an MCP tool asynchronously."""
        request = self._build_request(tool_name, arguments)
        timeout_val = timeout or self.timeout

        async with httpx.AsyncClient(timeout=timeout_val) as client:
            try:
                response = await client.post(
                    f"{self.base_url}/mcp/",
                    json=request,
                    headers=self._get_headers(),
                )
                response.raise_for_status()
            except httpx.TimeoutException as e:
                raise MPCTimeoutError(f"Request timed out after {timeout_val}s") from e
            except httpx.ConnectError as e:
                raise MCPConnectionError(f"Failed to connect to MCP server: {e}") from e
            except httpx.HTTPStatusError as e:
                if e.response.status_code == 401:
                    raise MCPAuthenticationError("Authentication failed")
                raise MCPClientError(f"HTTP error: {e}") from e

        return await self._parse_response(response)

    def _read_local_file(self, video_url: str) -> tuple[str, str]:
        """Read local file and return (filename, base64_data)."""
        if not os.path.exists(video_url):
            raise FileNotFoundError(f"文件不存在: {video_url}")

        size = os.path.getsize(video_url)
        if size > MAX_FILE_SIZE:
            size_mb = size / (1024 * 1024)
            raise FileSizeExceededError(size_mb, 100.0)

        filename = os.path.basename(video_url)
        with open(video_url, 'rb') as f:
            file_data = base64.b64encode(f.read()).decode('utf-8')

        return filename, file_data

    async def enhance_video_sync(
        self,
        video_url: str,
        resolution: Resolution | str = Resolution.P720,
        type: VideoType | str = VideoType.URL,
        timeout: float | None = None,
    ) -> EnhanceResult:
        """Enhance a video synchronously (blocks until complete)."""
        if isinstance(resolution, str):
            resolution = Resolution(resolution)
        if isinstance(type, str):
            type = VideoType(type)

        arguments = {
            "video_url": video_url,
            "resolution": resolution.value,
            "type": type.value,
        }

        if type == VideoType.LOCAL:
            filename, file_data = self._read_local_file(video_url)
            arguments["video_url"] = filename
            arguments["file_data"] = file_data

        result = await self._call_tool("enhance_video_sync", arguments, timeout)
        return EnhanceResult.model_validate(result)

    async def enhance_video_async(
        self,
        video_url: str,
        resolution: Resolution | str = Resolution.P720,
        type: VideoType | str = VideoType.URL,
    ) -> AsyncTaskResult:
        """Start video enhancement asynchronously."""
        if isinstance(resolution, str):
            resolution = Resolution(resolution)
        if isinstance(type, str):
            type = VideoType(type)

        arguments = {
            "video_url": video_url,
            "resolution": resolution.value,
            "type": type.value,
        }

        if type == VideoType.LOCAL:
            filename, file_data = self._read_local_file(video_url)
            arguments["video_url"] = filename
            arguments["file_data"] = file_data

        result = await self._call_tool("enhance_video_async", arguments)
        return AsyncTaskResult.model_validate(result)

    async def get_task_status(self, task_id: str) -> TaskStatusResult:
        """Get the status of a video enhancement task."""
        arguments = {"task_id": task_id}
        result = await self._call_tool("get_task_status", arguments)
        return TaskStatusResult.model_validate(result)

    async def wait_for_task(
        self,
        task_id: str,
        timeout: float = 600.0,
        poll_interval: float | None = None,
    ) -> TaskStatusResult:
        """Wait for a task to complete."""
        import asyncio

        interval = poll_interval or self.poll_interval
        start_time = time.time()

        while True:
            result = await self.get_task_status(task_id)

            if result.status in ("completed", "failed"):
                return result

            elapsed = time.time() - start_time
            if elapsed >= timeout:
                raise MPCTimeoutError(f"Task {task_id} did not complete within {timeout}s")

            await asyncio.sleep(interval)
