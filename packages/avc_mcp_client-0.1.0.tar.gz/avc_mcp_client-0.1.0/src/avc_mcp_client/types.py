"""Type definitions for AVC MCP Client."""

from enum import Enum

from pydantic import BaseModel, Field


class Resolution(str, Enum):
    """Video resolution options."""

    P480 = "480p"
    P540 = "540p"
    P720 = "720p"
    P1080 = "1080p"
    P2K = "2k"


class VideoType(str, Enum):
    """Video source type."""

    URL = "url"
    LOCAL = "local"


class TaskStatus(str, Enum):
    """Task status values."""

    WAIT = "wait"
    START = "start"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    TIMEOUT = "timeout"


class EnhanceResult(BaseModel):
    """Result of video enhancement operation."""

    success: bool
    task_id: str | None = Field(default=None, alias="task_id")
    status: TaskStatus | None = None
    video_url: str | None = Field(default=None, alias="video_url")
    message: str | None = None
    error: str | None = None

    class Config:
        populate_by_name = True


class AsyncTaskResult(BaseModel):
    """Result of async task creation."""

    success: bool
    task_id: str | None = Field(default=None, alias="task_id")
    status: TaskStatus | None = None
    message: str | None = None

    class Config:
        populate_by_name = True


class TaskStatusResult(BaseModel):
    """Result of task status query."""

    success: bool
    task_id: str | None = Field(default=None, alias="task_id")
    status: TaskStatus | None = None
    video_url: str | None = Field(default=None, alias="video_url")
    message: str | None = None
    error: str | None = None

    class Config:
        populate_by_name = True
