"""AVC MCP Client - Client for AVC video enhancement MCP service."""

from .client import AVCMCPClient, AsyncAVCMCPClient
from .exceptions import (
    MCPAuthenticationError,
    MCPClientError,
    MCPConnectionError,
    MCPParseError,
    MPCTimeoutError,
    MCPToolError,
    FileSizeExceededError,
    FileNotFoundError,
)
from .types import AsyncTaskResult, EnhanceResult, Resolution, TaskStatus, TaskStatusResult, VideoType

__version__ = "0.1.0"

__all__ = [
    # Client
    "AVCMCPClient",
    "AsyncAVCMCPClient",
    # Types
    "Resolution",
    "VideoType",
    "TaskStatus",
    "EnhanceResult",
    "AsyncTaskResult",
    "TaskStatusResult",
    # Exceptions
    "MCPClientError",
    "MCPConnectionError",
    "MCPParseError",
    "MCPToolError",
    "MPCTimeoutError",
    "MCPAuthenticationError",
    "FileSizeExceededError",
    "FileNotFoundError",
]
