"""Video / image standardization helpers for the IMX gen pipeline.

Phase 2.0f standardized the consolidated runtime on a single output
resolution contract: 1280x720 (landscape) or 720x1280 (portrait). This
module owns the source-video → target-resolution transform used by the
IMX packer (`bithuman convert`).

The transform is **aspect-preserving fit + letterbox/pillarbox to black**
so a source frame at any resolution ends up exactly at the target with
the original content centred and the unused pixels zero-filled. The same
math is used at three layers:

  * ``fit_to_target(frame, tw, th)``        — single-frame numpy op (BGR/RGB).
  * ``compute_fit_transform(sw, sh, tw, th)``— returns (scale, x_off, y_off,
    fit_w, fit_h). Used to scale crop_bbox / face_coords without touching
    pixels.
  * ``standardize_video(in_mp4, out_mp4, target)`` — full ffmpeg-driven
    re-encode at target resolution with pad filter.

The "portrait-detected" rule is explicit and centralized in
``select_target_resolution(src_w, src_h)`` so every callsite agrees.
"""
from __future__ import annotations

import os
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Tuple

import numpy as np


# Default landscape and portrait targets. The runtime's hard contract is
# 1280x720 / 720x1280; nothing in this module assumes those numbers though
# — callers can pick any target.
DEFAULT_LANDSCAPE: Tuple[int, int] = (1280, 720)
DEFAULT_PORTRAIT: Tuple[int, int] = (720, 1280)


def select_target_resolution(
    src_w: int,
    src_h: int,
    landscape: Tuple[int, int] = DEFAULT_LANDSCAPE,
    portrait: Tuple[int, int] = DEFAULT_PORTRAIT,
) -> Tuple[int, int]:
    """Pick landscape or portrait target based on source aspect.

    Strictly taller-than-wide (``src_h > src_w``) → portrait. Square or
    wider → landscape. Square is rare for avatars and the landscape canvas
    handles it via pillarbox.
    """
    if src_w <= 0 or src_h <= 0:
        raise ValueError(f"invalid source dims: {src_w}x{src_h}")
    return portrait if src_h > src_w else landscape


@dataclass(frozen=True)
class FitTransform:
    """Maps source coordinates → target-canvas coordinates.

    Apply to a pixel coord ``(x, y)`` in source space:

        x' = round(x * scale) + x_off
        y' = round(y * scale) + y_off

    The fit region on the canvas is::

        [x_off, x_off + fit_w) × [y_off, y_off + fit_h)

    and the rest of the canvas is zero-filled (letterbox / pillarbox).
    """

    src_w: int
    src_h: int
    target_w: int
    target_h: int
    scale: float
    fit_w: int
    fit_h: int
    x_off: int
    y_off: int

    def map_bbox(self, bbox: Tuple[int, int, int, int]) -> Tuple[int, int, int, int]:
        """Map an (x1, y1, x2, y2) bbox from source to target coords.

        The result is clamped to the target canvas and guaranteed to have
        ``x2 > x1`` and ``y2 > y1`` (degenerate bboxes raise).
        """
        x1, y1, x2, y2 = bbox
        if x2 <= x1 or y2 <= y1:
            raise ValueError(f"degenerate bbox: {bbox}")
        nx1 = int(round(x1 * self.scale)) + self.x_off
        ny1 = int(round(y1 * self.scale)) + self.y_off
        nx2 = int(round(x2 * self.scale)) + self.x_off
        ny2 = int(round(y2 * self.scale)) + self.y_off
        nx1 = max(0, min(self.target_w, nx1))
        nx2 = max(0, min(self.target_w, nx2))
        ny1 = max(0, min(self.target_h, ny1))
        ny2 = max(0, min(self.target_h, ny2))
        if nx2 <= nx1 or ny2 <= ny1:
            raise ValueError(
                f"bbox collapsed under transform {self}: {bbox} -> "
                f"({nx1}, {ny1}, {nx2}, {ny2})"
            )
        return (nx1, ny1, nx2, ny2)


def compute_fit_transform(
    src_w: int, src_h: int, target_w: int, target_h: int,
) -> FitTransform:
    """Compute the aspect-preserving fit + centered-pad transform.

    The source is scaled by ``min(target_w/src_w, target_h/src_h)`` and the
    scaled rectangle is centred on the target canvas. ``fit_w`` and
    ``fit_h`` are rounded to integers; offsets are floor-of-half so the
    pad is split as evenly as possible (with the +1 pixel on the right /
    bottom side when the gap is odd, matching ffmpeg's ``pad`` default).
    """
    if src_w <= 0 or src_h <= 0 or target_w <= 0 or target_h <= 0:
        raise ValueError(
            f"invalid dims: src={src_w}x{src_h} target={target_w}x{target_h}"
        )
    scale = min(target_w / src_w, target_h / src_h)
    fit_w = int(round(src_w * scale))
    fit_h = int(round(src_h * scale))
    fit_w = max(1, min(target_w, fit_w))
    fit_h = max(1, min(target_h, fit_h))
    x_off = (target_w - fit_w) // 2
    y_off = (target_h - fit_h) // 2
    return FitTransform(
        src_w=src_w, src_h=src_h,
        target_w=target_w, target_h=target_h,
        scale=scale, fit_w=fit_w, fit_h=fit_h,
        x_off=x_off, y_off=y_off,
    )


def fit_to_target(
    frame: np.ndarray, target_w: int, target_h: int,
    interpolation: Optional[int] = None,
) -> np.ndarray:
    """Aspect-preserving resize + letterbox/pillarbox pad of one frame.

    ``frame`` may be HxW (single channel) or HxWxC. Output dtype matches
    input. Unused canvas pixels are zero.
    """
    import cv2

    h, w = frame.shape[:2]
    tf = compute_fit_transform(w, h, target_w, target_h)

    interp = interpolation
    if interp is None:
        interp = cv2.INTER_AREA if tf.scale < 1.0 else cv2.INTER_LINEAR

    if tf.fit_w == w and tf.fit_h == h:
        resized = frame
    else:
        resized = cv2.resize(frame, (tf.fit_w, tf.fit_h), interpolation=interp)

    if tf.fit_w == target_w and tf.fit_h == target_h:
        return resized.copy() if resized is frame else resized

    if frame.ndim == 2:
        canvas = np.zeros((target_h, target_w), dtype=frame.dtype)
    else:
        canvas = np.zeros((target_h, target_w, frame.shape[2]), dtype=frame.dtype)
    canvas[tf.y_off:tf.y_off + tf.fit_h, tf.x_off:tf.x_off + tf.fit_w] = resized
    return canvas


def probe_video_dims(mp4_path: str) -> Tuple[int, int]:
    """Return ``(width, height)`` of the first video stream via PyAV."""
    import av  # type: ignore

    container = av.open(mp4_path)
    try:
        stream = container.streams.video[0]
        return int(stream.codec_context.width), int(stream.codec_context.height)
    finally:
        container.close()


def standardize_video(
    mp4_path: str,
    target_resolution: Tuple[int, int],
    crf: int = 18,
    preset: str = "medium",
) -> Tuple[bool, FitTransform]:
    """Re-encode ``mp4_path`` in place at ``target_resolution``.

    Uses ffmpeg's ``scale=W:H:force_original_aspect_ratio=decrease`` followed
    by ``pad=W:H:(ow-iw)/2:(oh-ih)/2`` so the output is exactly the target
    dims with letterbox / pillarbox black bars. H.264 CRF 18 (visually
    lossless) to preserve quality. Returns ``(was_transcoded, transform)``;
    when the source already matches the target dims we skip the transcode
    but still return the (identity) transform so callers can scale
    coordinates uniformly.

    Falls back to a PyAV re-encode if ffmpeg is not on PATH.
    """
    target_w, target_h = target_resolution
    if target_w <= 0 or target_h <= 0:
        raise ValueError(f"target_resolution invalid: {target_resolution}")
    # H.264 needs even dims; the standard 720p / portrait targets are
    # already even but guard anyway in case callers pass odd custom targets.
    if target_w % 2 or target_h % 2:
        raise ValueError(
            f"target_resolution must be even for H.264 encoding: {target_resolution}"
        )

    src_w, src_h = probe_video_dims(mp4_path)
    tf = compute_fit_transform(src_w, src_h, target_w, target_h)

    if src_w == target_w and src_h == target_h:
        return False, tf

    tmp_path = str(Path(mp4_path).parent / f"_standardize_{os.getpid()}.mp4")

    # ffmpeg path: combined scale+pad filter in one pass.
    if shutil.which("ffmpeg"):
        vf = (
            f"scale={target_w}:{target_h}:force_original_aspect_ratio=decrease,"
            f"pad={target_w}:{target_h}:(ow-iw)/2:(oh-ih)/2:black,setsar=1"
        )
        result = subprocess.run(
            ["ffmpeg", "-y", "-i", mp4_path,
             "-vf", vf,
             "-c:v", "libx264", "-crf", str(crf), "-preset", preset,
             "-pix_fmt", "yuv420p", "-an", tmp_path],
            capture_output=True, text=True,
        )
        if result.returncode != 0:
            if os.path.exists(tmp_path):
                os.unlink(tmp_path)
            raise RuntimeError(
                f"ffmpeg standardize failed: {result.stderr[-400:]}"
            )
    else:
        # PyAV fallback — slower path, but keeps the tool usable on
        # systems without ffmpeg CLI (e.g. tests in sandboxed CI).
        import av  # type: ignore

        input_container = av.open(mp4_path)
        output_container = av.open(tmp_path, "w", format="mp4")
        in_stream = input_container.streams.video[0]
        in_stream.thread_type = "AUTO"
        in_stream.thread_count = int(os.environ.get("CONVERT_THREADS") or 0)
        fps = in_stream.average_rate
        out_stream = output_container.add_stream("libx264", rate=fps)
        out_stream.width = target_w
        out_stream.height = target_h
        out_stream.pix_fmt = "yuv420p"
        out_stream.options = {"crf": str(crf), "preset": preset}
        for frame in input_container.decode(video=0):
            img = frame.to_ndarray(format="bgr24")
            fitted = fit_to_target(img, target_w, target_h)
            new_frame = av.VideoFrame.from_ndarray(fitted, format="bgr24")
            new_frame.pts = frame.pts
            new_frame.time_base = frame.time_base
            for packet in out_stream.encode(new_frame):
                output_container.mux(packet)
        for packet in out_stream.encode():
            output_container.mux(packet)
        output_container.close()
        input_container.close()

    os.replace(tmp_path, mp4_path)
    return True, tf


def parse_target_resolution(spec: str) -> Optional[Tuple[int, int]]:
    """Parse a CLI ``--target-resolution`` string.

    Accepted forms:

      * ``"WIDTHxHEIGHT"`` — e.g. ``"1280x720"`` or ``"720x1280"``. Both
        ``x`` and ``X`` separators are accepted.
      * ``"native"`` — return ``None`` to signal "preserve source
        resolution" (the legacy max-resolution-cap behaviour).
      * ``"auto"`` — return the sentinel ``("auto",)`` cast tuple; callers
        should resolve to landscape/portrait via
        :func:`select_target_resolution` once they know the source dims.
        Implemented as the tuple ``(0, 0)`` to keep the return type
        homogeneous.

    Raises :class:`ValueError` for malformed input.
    """
    s = spec.strip().lower()
    if s in ("native", "source", "passthrough"):
        return None
    if s == "auto":
        return (0, 0)
    for sep in ("x", "X", "*", " "):
        if sep in s:
            parts = s.split(sep)
            if len(parts) == 2:
                try:
                    w = int(parts[0])
                    h = int(parts[1])
                except ValueError as e:
                    raise ValueError(
                        f"--target-resolution: expected 'WxH' or 'native', got {spec!r}"
                    ) from e
                if w <= 0 or h <= 0:
                    raise ValueError(
                        f"--target-resolution dims must be positive, got {w}x{h}"
                    )
                return (w, h)
    raise ValueError(
        f"--target-resolution: expected 'WxH', 'auto', or 'native', got {spec!r}"
    )
