import httpx
from typing import Optional, List, Dict, Any, Union
from .models import (
    CimeResponse, 
    UserChannelInfo, 
    BulkChannelResponse, 
    LiveListResponse, 
    LiveSetting, 
    ChatSettings, 
    MessageResponse, 
    CategorySearchResponse, 
    SessionResponse,
    StreamKeyResponse
)

class CimeClient:
    def __init__(
        self, 
        client_id: Optional[str] = None, 
        client_secret: Optional[str] = None, 
        bearer_token: Optional[str] = None, 
        base_url: str = 'https://ci.me/api/openapi/'
    ):
        self.client_id = client_id
        self.client_secret = client_secret
        self.bearer_token = bearer_token
        self.base_url = base_url
        self.client = httpx.AsyncClient(base_url=base_url)

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.client.aclose()

    def _get_headers(self) -> Dict[str, str]:
        headers = {}
        if self.bearer_token:
            headers['Authorization'] = f'Bearer {self.bearer_token}'
        elif self.client_id and self.client_secret:
            headers['Client-Id'] = self.client_id
            headers['Client-Secret'] = self.client_secret
        return headers

    async def get_token(self, code: str) -> CimeResponse[Any]:
        data = {
            "grantType": "authorization_code",
            "clientId": self.client_id,
            "clientSecret": self.client_secret,
            "code": code
        }
        resp = await self.client.post('auth/v1/token', json=data)
        return CimeResponse[Any](**resp.json())

    async def refresh_token(self, refresh_token: str) -> CimeResponse[Any]:
        data = {
            "grantType": "refresh_token",
            "clientId": self.client_id,
            "clientSecret": self.client_secret,
            "refreshToken": refresh_token
        }
        resp = await self.client.post('auth/v1/token', json=data)
        return CimeResponse[Any](**resp.json())

    async def get_me(self) -> CimeResponse[UserChannelInfo]:
        resp = await self.client.get('open/v1/users/me', headers=self._get_headers())
        return CimeResponse[UserChannelInfo](**resp.json())

    async def get_channels(self, channel_ids: List[str]) -> CimeResponse[BulkChannelResponse]:
        params = {'channelIds': ','.join(channel_ids)}
        resp = await self.client.get('open/v1/channels', params=params, headers=self._get_headers())
        return CimeResponse[BulkChannelResponse](**resp.json())

    async def get_followers(self) -> CimeResponse[Any]:
        resp = await self.client.get('open/v1/channels/followers', headers=self._get_headers())
        return CimeResponse[Any](**resp.json())

    async def get_subscribers(self) -> CimeResponse[Any]:
        resp = await self.client.get('open/v1/channels/subscribers', headers=self._get_headers())
        return CimeResponse[Any](**resp.json())

    async def get_streaming_roles(self) -> CimeResponse[Any]:
        resp = await self.client.get('open/v1/channels/streaming-roles', headers=self._get_headers())
        return CimeResponse[Any](**resp.json())

    async def get_lives(
        self, 
        channel_ids: Optional[List[str]] = None, 
        page: Optional[int] = None, 
        size: Optional[int] = None
    ) -> CimeResponse[LiveListResponse]:
        params = {}
        if channel_ids: params['channelIds'] = ','.join(channel_ids)
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        
        resp = await self.client.get('open/v1/lives', params=params, headers=self._get_headers())
        # Use pydantic's parse_obj or similar via **json
        return CimeResponse[LiveListResponse](**resp.json())

    async def get_live_setting(self) -> CimeResponse[LiveSetting]:
        resp = await self.client.get('open/v1/lives/setting', headers=self._get_headers())
        return CimeResponse[LiveSetting](**resp.json())

    async def update_live_setting(self, settings: Dict[str, Any]) -> CimeResponse[LiveSetting]:
        resp = await self.client.patch('open/v1/lives/setting', json=settings, headers=self._get_headers())
        return CimeResponse[LiveSetting](**resp.json())

    async def get_stream_key(self) -> CimeResponse[StreamKeyResponse]:
        resp = await self.client.get('open/v1/streams/key', headers=self._get_headers())
        return CimeResponse[StreamKeyResponse](**resp.json())

    async def get_chat_settings(self) -> CimeResponse[ChatSettings]:
        resp = await self.client.get('open/v1/chats/settings', headers=self._get_headers())
        return CimeResponse[ChatSettings](**resp.json())

    async def update_chat_settings(self, settings: Dict[str, Any]) -> CimeResponse[ChatSettings]:
        resp = await self.client.put('open/v1/chats/settings', json=settings, headers=self._get_headers())
        return CimeResponse[ChatSettings](**resp.json())

    async def send_chat(self, message: str) -> CimeResponse[MessageResponse]:
        resp = await self.client.post('open/v1/chats/send', json={'message': message}, headers=self._get_headers())
        return CimeResponse[MessageResponse](**resp.json())

    async def update_notice(self, message: str) -> CimeResponse[Any]:
        resp = await self.client.post('open/v1/chats/notice', json={'message': message}, headers=self._get_headers())
        return CimeResponse[Any](**resp.json())

    async def search_categories(self, keyword: str, size: Optional[int] = None) -> CimeResponse[CategorySearchResponse]:
        params = {'keyword': keyword}
        if size is not None: params['size'] = size
        resp = await self.client.get('open/v1/categories/search', params=params, headers=self._get_headers())
        return CimeResponse[CategorySearchResponse](**resp.json())

    async def get_restrict_channels(self) -> CimeResponse[Any]:
        resp = await self.client.get('open/v1/restrict-channels', headers=self._get_headers())
        return CimeResponse[Any](**resp.json())

    async def restrict_channel(self, channel_id: str) -> CimeResponse[Any]:
        resp = await self.client.post('open/v1/restrict-channels', json={'channelId': channel_id}, headers=self._get_headers())
        return CimeResponse[Any](**resp.json())

    async def unrestrict_channel(self, channel_id: str) -> CimeResponse[Any]:
        resp = await self.client.request("DELETE", 'open/v1/restrict-channels', json={'channelId': channel_id}, headers=self._get_headers())
        return CimeResponse[Any](**resp.json())

    async def create_session(self, use_client_auth: bool = False) -> CimeResponse[SessionResponse]:
        endpoint = 'open/v1/sessions/auth/client' if use_client_auth else 'open/v1/sessions/auth'
        resp = await self.client.get(endpoint, headers=self._get_headers())
        return CimeResponse[SessionResponse](**resp.json())

    async def subscribe_event(self, session_key: str, event: str) -> CimeResponse[Any]:
        # event should be 'chat', 'donation', or 'subscription'
        params = {'sessionKey': session_key}
        resp = await self.client.post(f'open/v1/sessions/events/subscribe/{event}', params=params, headers=self._get_headers())
        return CimeResponse[Any](**resp.json())

    async def unsubscribe_event(self, session_key: str, event: str) -> CimeResponse[Any]:
        params = {'sessionKey': session_key}
        resp = await self.client.post(f'open/v1/sessions/events/unsubscribe/{event}', params=params, headers=self._get_headers())
        return CimeResponse[Any](**resp.json())
