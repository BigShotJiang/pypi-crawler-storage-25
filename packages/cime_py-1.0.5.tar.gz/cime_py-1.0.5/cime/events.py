import asyncio
import json
import websockets
from typing import Callable, Coroutine, Any, Dict, Set

class CimeEvents:
    def __init__(self, url: str):
        self.url = url
        self.ws = None
        self.handlers: Dict[str, Set[Callable[[Any], Coroutine]]] = {}
        self._running = False
        
        # 🔑 Extract sessionKey from URL for official HTTP subscription
        from urllib.parse import urlparse, parse_qs
        parsed = urlparse(url)
        self.session_key = parse_qs(parsed.query).get('sessionKey', [None])[0]

    def on(self, event_type: str, handler: Callable[[Any], Coroutine]):
        if event_type not in self.handlers:
            self.handlers[event_type] = set()
        self.handlers[event_type].add(handler)

    async def connect(self):
        """Connects to the event server. Note: Subscription is now done via HTTP API."""
        async with websockets.connect(self.url) as self.ws:
            self._running = True
            while self._running:
                try:
                    message_raw = await self.ws.recv()
                    message = json.loads(message_raw)
                    event_type = message.get("type") or message.get("event")
                    data = message.get("data")
                    
                    if event_type and event_type in self.handlers:
                        for handler in self.handlers[event_type]:
                            asyncio.create_task(handler(data))
                except websockets.exceptions.ConnectionClosed:
                    break
        self._running = False

    def disconnect(self):
        self._running = False
