# cime.py

CI.ME 공식 API를 활용한 비공식 Python SDK입니다.
(Unofficial Python SDK using Official CI.ME OpenAPI)

## Installation

```bash
pip install cime.py
```

## Quick Start

### Async Client Initialization

```python
import asyncio
from cime import CimeClient

async def main():
    async with CimeClient(
        client_id='YOUR_CLIENT_ID',
        client_secret='YOUR_CLIENT_SECRET'
    ) as client:
        # Use bearer token for user-specific actions
        # client.bearer_token = 'YOUR_BEARER_TOKEN'
        
        me = await client.get_me()
        print(f"My Channel: {me.content.channelName}")

asyncio.run(main())
```

### WebSocket Events

```python
import asyncio
from cime import CimeEvents, CimeClient

async def on_chat(data):
    print(f"New Chat: {data['message']}")

async def main():
    async with CimeClient(client_id='...', client_secret='...') as client:
        session = await client.create_session()
        events = CimeEvents(session.content.url)
        
        events.on("CHAT", on_chat)
        await events.subscribe("CHAT")
        
        await events.connect()

asyncio.run(main())
```

## Features

- CI.ME REST API (User, Channel, Live, Chat, etc.) 완벽 지원
- `httpx` 및 `websockets` 기반의 고성능 비동기 설계
- Pydantic 모델을 통한 강력한 데이터 검증 및 타입 힌트 제공

## License

MIT
