"""Fine-tune SDK and bundle helper services."""

from __future__ import annotations

import importlib
import shutil
import sys
import tempfile
import contextlib
from pathlib import Path
from typing import Any

from aimp_cli.core.errors import usage_error
from aimp_cli.domain.constants import FINE_TUNE_AGENT_ENTRYPOINT_RELATIVE_PATH
from aimp_cli.domain.project_config import load_project_config


def load_sdk_symbol(name: str) -> Any:
    """Load one symbol from ``aimp_sdk`` with a repo-local fallback."""
    repo_root = Path(__file__).resolve().parents[4]
    repo_runtime_roots = [
        root
        for root in (
            repo_root / "sdk",
            repo_root / "framework",
        )
        if root.exists()
    ]
    if repo_runtime_roots:
        for module_name in list(sys.modules):
            if (
                module_name == "aimp_sdk"
                or module_name.startswith("aimp_sdk.")
                or module_name == "aimp_framework"
                or module_name.startswith("aimp_framework.")
            ):
                sys.modules.pop(module_name, None)
        for runtime_root in reversed(repo_runtime_roots):
            sys.path.insert(0, str(runtime_root))
        try:
            module = importlib.import_module("aimp_sdk")
            if hasattr(module, name):
                return getattr(module, name)
        finally:
            for runtime_root in repo_runtime_roots:
                with contextlib.suppress(ValueError):
                    sys.path.remove(str(runtime_root))

    try:
        module = importlib.import_module("aimp_sdk")
        if hasattr(module, name):
            return getattr(module, name)
    except ImportError:
        pass

    raise ImportError(f"cannot import name '{name}' from 'aimp_sdk'")


def load_local_tuning_contract(
    project_dir: Path,
    *,
    tuning_model: str | None = None,
) -> dict[str, Any]:
    """Load the model-scoped fine-tune contract from agent + model selector."""
    load_model_tuning_contract = load_sdk_symbol("load_model_tuning_contract")
    project_config = load_project_config(project_dir)
    if project_config.tuning is None:
        raise usage_error(
            "This project does not enable fine-tune. Run: ai project configure --fine-tune",
            code="fine_tune_not_enabled",
        )
    model_key = str(tuning_model or project_config.tuning.model_key or "").strip()
    if not model_key:
        raise usage_error(
            "Fine-tune config is missing tuning.model_key",
            code="fine_tune_model_key_missing",
        )
    agent_module = project_dir / FINE_TUNE_AGENT_ENTRYPOINT_RELATIVE_PATH
    if not agent_module.exists():
        raise usage_error(
            f"Agent module not found: {FINE_TUNE_AGENT_ENTRYPOINT_RELATIVE_PATH}",
            code="fine_tune_agent_module_missing",
        )
    return load_model_tuning_contract(str(agent_module), model_key=model_key)


def create_tuning_bundle_archive(
    *,
    schema_contract: dict[str, Any],
    bundle_path: Path,
) -> tuple[tempfile.NamedTemporaryFile, str]:
    """Build one uploadable fine-tune dataset bundle archive."""
    build_tuning_dataset_bundle = load_sdk_symbol("build_tuning_dataset_bundle")
    payload = build_tuning_dataset_bundle(
        schema_contract=schema_contract,
        bundle_path=bundle_path,
    )
    temp_file = tempfile.NamedTemporaryFile(suffix=".zip", delete=False)
    try:
        payload.stream.seek(0)
        with Path(temp_file.name).open("wb") as handle:
            shutil.copyfileobj(payload.stream, handle)
    finally:
        temp_file.close()
        payload.stream.close()
    return temp_file, payload.content_type


def default_fine_tune_scaffold_output_dir(model_slug: str) -> Path:
    """Return the default local output directory for a consumer scaffold."""
    safe_slug = model_slug.strip().replace("/", "-").replace(" ", "-")
    return Path.cwd() / f"{safe_slug}-fine-tune"


def resolve_fine_tune_bundle_path(*, bundle: Path | None) -> Path:
    """Resolve one explicit local bundle path."""
    if bundle is None:
        raise usage_error(
            "Provide --bundle or use --output-dir to generate a workspace first",
            code="dataset_source_required",
        )
    bundle_path = bundle.expanduser().resolve()
    if not bundle_path.exists() or not bundle_path.is_file():
        raise usage_error(
            f"Fine-tune bundle file not found: {bundle}",
            code="dataset_not_found",
        )
    return bundle_path


def resolve_fine_tune_output_dir(
    *,
    model_slug: str,
    workspace: Path | None,
    output_dir: Path | None,
) -> Path:
    """Resolve the local workspace directory used for customer fine-tune scaffolds."""
    if workspace is not None and output_dir is not None:
        raise usage_error(
            "Use exactly one of --workspace or --output-dir",
            code="dataset_source_required",
        )
    target = workspace or output_dir or default_fine_tune_scaffold_output_dir(model_slug)
    return target.expanduser().resolve()
