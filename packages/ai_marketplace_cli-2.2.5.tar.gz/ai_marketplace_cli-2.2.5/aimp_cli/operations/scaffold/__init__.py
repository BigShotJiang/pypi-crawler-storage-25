"""Project scaffold rendering and synchronization."""
