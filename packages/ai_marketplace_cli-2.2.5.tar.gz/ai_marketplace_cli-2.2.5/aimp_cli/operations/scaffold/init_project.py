"""Agent project scaffolding helpers.

This module intentionally performs only filesystem templating operations.
Project structure and architecture are defined by framework-owned template files.
"""

from __future__ import annotations

import shutil
from importlib import resources
from pathlib import Path

from aimp_cli.domain.constants import PROJECT_ENV_RELATIVE_PATH
from aimp_cli.domain.runtime_packages import ordered_runtime_dependency_specs


def _to_pascal_case(value: str) -> str:
    """Convert string to PascalCase."""
    cleaned = "".join(character if character.isalnum() else " " for character in value)
    return "".join(part.capitalize() for part in cleaned.split()) or "Agent"


def _to_snake_case(value: str) -> str:
    """Convert string to snake_case."""
    cleaned = "".join(character if character.isalnum() else " " for character in value)
    return "_".join(part.lower() for part in cleaned.split()) or "agent"


def _framework_template_root() -> Path:
    """Return the framework-owned template root directory."""
    source_root = (
        Path(__file__).resolve().parents[4] / "framework" / "aimp_framework" / "project_template"
    )
    if source_root.exists():
        return source_root
    try:
        return Path(str(resources.files("aimp_framework").joinpath("project_template")))
    except ModuleNotFoundError as exc:
        raise RuntimeError(
            "Framework project template not found. Ensure ai-marketplace-framework is available."
        ) from exc


def _cli_template_root() -> Path:
    """Return the CLI-owned scaffold guidance template root directory."""
    source_root = Path(__file__).resolve().parent / "templates"
    if source_root.exists():
        return source_root
    try:
        return Path(str(resources.files("aimp_cli.operations.scaffold").joinpath("templates")))
    except ModuleNotFoundError as exc:
        raise RuntimeError(
            "CLI scaffold templates not found. Ensure ai-marketplace-cli is available."
        ) from exc


def _apply_placeholders(content: str, values: dict[str, str]) -> str:
    """Replace placeholders in template content."""
    result = content
    for key, value in values.items():
        result = result.replace(f"{{{{{key}}}}}", value)
    return result


def _copy_template_tree(
    source: Path,
    destination: Path,
    *,
    values: dict[str, str],
) -> None:
    """Copy one template tree and materialize placeholders."""
    for path in source.rglob("*"):
        if path.name == "__pycache__" or path.suffix in {".pyc", ".pyo"}:
            continue
        relative = path.relative_to(source)
        target = destination / relative
        if path.is_dir():
            target.mkdir(parents=True, exist_ok=True)
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        if path.suffix in {".py", ".md", ".mdx", ".toml", ".txt", ""}:
            content = path.read_text(encoding="utf-8")
            target.write_text(_apply_placeholders(content, values), encoding="utf-8")
        else:
            shutil.copy2(path, target)


def _create_agent_root(project_dir: Path, values: dict[str, str]) -> None:
    """Create root agent files from framework-owned templates."""
    template_root = _framework_template_root()
    root_template = template_root / "agent_root"
    _copy_template_tree(root_template, project_dir, values=values)


def _create_model(model_dir: Path, values: dict[str, str]) -> None:
    """Create the default model from framework-owned templates."""
    template_root = _framework_template_root()
    model_template = template_root / "model"
    _copy_template_tree(model_template, model_dir, values=values)


def _write_template_file(source: Path, target: Path, *, values: dict[str, str]) -> None:
    """Render one text template file with placeholder substitution."""
    target.parent.mkdir(parents=True, exist_ok=True)
    content = source.read_text(encoding="utf-8")
    target.write_text(_apply_placeholders(content, values), encoding="utf-8")


def _create_project_guidance(project_dir: Path, values: dict[str, str]) -> None:
    """Create project-local AGENTS routing and skill files."""
    template_root = _cli_template_root()
    _write_template_file(template_root / "AGENTS.md.tpl", project_dir / "AGENTS.md", values=values)

    skills_template_root = template_root / "skills"
    skills_root = project_dir / ".agents" / "skills"
    _write_template_file(
        skills_template_root / "SKILL_INDEX.md.tpl",
        skills_root / "SKILL_INDEX.md",
        values=values,
    )

    for path in sorted(skills_template_root.glob("*.md.tpl")):
        if path.name == "SKILL_INDEX.md.tpl":
            continue
        skill_name = path.name.removesuffix(".md.tpl")
        _write_template_file(path, skills_root / skill_name / "SKILL.md", values=values)


def _validate_scaffold(project_dir: Path) -> None:
    required_paths = (
        "contract.toml",
        "pyproject.toml",
        ".aimp/project.toml",
        ".aimp/publish.toml",
        "AGENTS.md",
        ".agents/skills/SKILL_INDEX.md",
        ".agents/skills/publish-readiness/SKILL.md",
        "agent.py",
        "schemas.py",
        "playground.py",
        "runtime/Dockerfile",
        "runtime/pyproject.toml",
        "runtime/contract.toml",
        "models/__init__.py",
        ".env",
    )
    missing = [path for path in required_paths if not (project_dir / path).exists()]
    if missing:
        joined = ", ".join(missing)
        raise RuntimeError(f"Scaffold template is incomplete; missing required files: {joined}")


def create_project_scaffold(name: str) -> Path:
    """Create an agent project scaffold.

    Creates:
    - root agent at ./<name>/
    - default model at ./<name>/models/<name>/
    """
    requested_name = name.strip()
    if not requested_name:
        raise ValueError("Project name cannot be empty")

    project_dir = Path(requested_name).resolve()
    if project_dir.exists():
        raise RuntimeError(f'Directory "{requested_name}" already exists')

    project_name = project_dir.name.strip()
    if not project_name:
        raise ValueError("Project name cannot be empty")

    agent_class_name = _to_pascal_case(project_name)
    if not agent_class_name.endswith("Agent"):
        agent_class_name = f"{agent_class_name}Agent"

    model_key = _to_snake_case(project_name)
    model_class_name = _to_pascal_case(model_key)
    if not model_class_name.endswith("Model"):
        model_class_name = f"{model_class_name}Model"

    runtime_dependencies = ordered_runtime_dependency_specs()

    values = {
        "PROJECT_NAME": project_name,
        "PROJECT_NAME_PASCAL": agent_class_name,
        "MODEL_KEY": model_key,
        "MODEL_CLASS_NAME": model_class_name,
        "FRAMEWORK_DEP": runtime_dependencies[0],
        "SDK_DEP": runtime_dependencies[1],
    }

    _create_agent_root(project_dir, values)
    model_dir = project_dir / "models" / model_key
    _create_model(model_dir, values)
    _create_project_guidance(project_dir, values)
    (project_dir / PROJECT_ENV_RELATIVE_PATH).write_text("", encoding="utf-8")
    _validate_scaffold(project_dir)

    return project_dir
