"""Template file helpers for CLI scaffold-adjacent utilities."""

from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Any

from aimp_cli.clients.studio_article import default_studio_article_mdx
from aimp_cli.domain.constants import (
    TUNING_ASSETS_RELATIVE_PATH,
    TUNING_BUNDLE_FILE_NAME,
    TUNING_HIDDEN_DIR_PATH,
    TUNING_HIDDEN_HELPERS_FILE,
    TUNING_HIDDEN_INIT_FILE,
    TUNING_HIDDEN_SCHEMA_FILE_NAME,
    TUNING_HIDDEN_SCHEMA_TYPES_FILE,
    TUNING_PREPARE_SCRIPT_FILE_NAME,
    TUNING_README_FILE_NAME,
)
from aimp_cli.domain.models import TuningSchemaConfig, TuningSchemaFieldConfig


def _template_root() -> Path:
    return Path(__file__).resolve().parent / "templates"


def _load_template(template_name: str, values: dict[str, str] | None = None) -> str:
    content = (_template_root() / template_name).read_text(encoding="utf-8")
    rendered = content
    for key, value in (values or {}).items():
        rendered = rendered.replace(f"{{{{{key}}}}}", value)
    return rendered


def studio_article_mdx_template() -> str:
    return _load_template(
        "studio/article/article.mdx.tpl",
        {"article_source": default_studio_article_mdx()},
    )


def write_default_studio_cover(cover_path: Path) -> None:
    cover_path.parent.mkdir(parents=True, exist_ok=True)
    source = Path(__file__).resolve().parents[2] / "assets" / "default-cover.jpg"
    shutil.copyfile(source, cover_path)


def _consumer_tuning_placeholder(field: TuningSchemaFieldConfig) -> Any:
    if field.type == "text":
        value: Any = f"replace-with-{field.key.replace('_', '-')}"
    elif field.type == "json":
        value = {"example": field.key}
    elif field.type == "image":
        value = f"assets/{field.key}-example.png"
    elif field.type == "audio":
        value = f"assets/{field.key}-example.wav"
    elif field.type == "video":
        value = f"assets/{field.key}-example.mp4"
    else:
        value = f"assets/{field.key}-example.bin"
    return [value] if field.multiple else value


def _build_field_definitions(schema: TuningSchemaConfig) -> str:
    lines: list[str] = []
    for field in schema.fields:
        python_type = "list[Any]" if field.multiple else "Any"
        default = "[]" if field.multiple else "None"
        field_line = f"    {field.key}: {python_type}"
        if not field.required:
            field_line += f" = {default}"
        if field.description:
            lines.append(f'    """{field.description}"""')
        lines.append(f"{field_line}\n")
    return "\n".join(lines)


def _schema_types_content(schema_contract: dict[str, Any], model_slug: str) -> str:
    schema = TuningSchemaConfig.model_validate(schema_contract)
    return _load_template(
        ".tuning/schema_types.py.tpl",
        {
            "model_slug": model_slug,
            "field_definitions": _build_field_definitions(schema),
            "schema_file_name": TUNING_HIDDEN_SCHEMA_FILE_NAME,
            "bundle_file_name": TUNING_BUNDLE_FILE_NAME,
        },
    )


def create_consumer_tuning_scaffold(
    output_dir: Path,
    *,
    model_slug: str,
    schema_contract: dict[str, Any],
) -> list[str]:
    schema = TuningSchemaConfig.model_validate(schema_contract)
    output_dir.mkdir(parents=True, exist_ok=True)
    assets_dir = output_dir / TUNING_ASSETS_RELATIVE_PATH
    assets_dir.mkdir(parents=True, exist_ok=True)
    tuning_dir = output_dir / TUNING_HIDDEN_DIR_PATH
    tuning_dir.mkdir(parents=True, exist_ok=True)

    schema_fields = "\n".join(
        (
            f"    - `{field.key}`: {field.type} "
            f"({'required' if field.required else 'optional'})"
            + (" [multiple]" if field.multiple else "")
        )
        for field in schema.fields
    )

    managed_files: dict[Path, str] = {
        output_dir / TUNING_PREPARE_SCRIPT_FILE_NAME: _load_template(
            "prepare_bundle.py.tpl",
            {
                "model_slug": model_slug,
                "schema_fields": schema_fields,
                "bundle_file_name": TUNING_BUNDLE_FILE_NAME,
            },
        ),
        output_dir / TUNING_README_FILE_NAME: _load_template(
            "fine_tune_readme.md.tpl",
            {
                "model_slug": model_slug,
                "schema_fields": schema_fields,
                "bundle_file_name": TUNING_BUNDLE_FILE_NAME,
            },
        ),
        assets_dir / "README.md": _load_template("assets_README.md.tpl"),
        tuning_dir / TUNING_HIDDEN_SCHEMA_FILE_NAME: json.dumps(schema.model_dump(), indent=2)
        + "\n",
        tuning_dir / TUNING_HIDDEN_SCHEMA_TYPES_FILE.name: _schema_types_content(
            schema_contract, model_slug
        ),
        tuning_dir / TUNING_HIDDEN_HELPERS_FILE.name: _load_template(".tuning/helpers.py.tpl"),
        tuning_dir / TUNING_HIDDEN_INIT_FILE.name: _load_template(".tuning/__init__.py.tpl"),
    }

    for file_path, contents in managed_files.items():
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(contents, encoding="utf-8")

    return [str(file_path.relative_to(output_dir)) for file_path in managed_files]


def regenerate_tuning_scaffold(
    output_dir: Path,
    *,
    model_slug: str,
    schema_contract: dict[str, Any],
) -> list[str]:
    schema = TuningSchemaConfig.model_validate(schema_contract)
    tuning_dir = output_dir / TUNING_HIDDEN_DIR_PATH
    tuning_dir.mkdir(parents=True, exist_ok=True)

    managed_files: dict[Path, str] = {
        tuning_dir / TUNING_HIDDEN_SCHEMA_FILE_NAME: json.dumps(schema.model_dump(), indent=2)
        + "\n",
        tuning_dir / TUNING_HIDDEN_SCHEMA_TYPES_FILE.name: _schema_types_content(
            schema_contract, model_slug
        ),
        tuning_dir / TUNING_HIDDEN_HELPERS_FILE.name: _load_template(".tuning/helpers.py.tpl"),
        tuning_dir / TUNING_HIDDEN_INIT_FILE.name: _load_template(".tuning/__init__.py.tpl"),
    }

    for file_path, contents in managed_files.items():
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(contents, encoding="utf-8")

    return [str(file_path.relative_to(output_dir)) for file_path in managed_files]
