"""Shared helpers for adding v2 scaffold stubs."""

from __future__ import annotations

from pathlib import Path
from typing import Callable


def write_scaffold_stub(
    *,
    project_dir: Path,
    relative_path: Path,
    render_fn: Callable[[str], str],
    name: str,
) -> Path:
    """Create one new scaffold stub without touching unrelated files."""
    absolute_path = project_dir / relative_path
    if absolute_path.exists():
        raise RuntimeError(f"Scaffold file already exists: {relative_path}")
    absolute_path.parent.mkdir(parents=True, exist_ok=True)
    absolute_path.write_text(render_fn(name), encoding="utf-8")
    return absolute_path
