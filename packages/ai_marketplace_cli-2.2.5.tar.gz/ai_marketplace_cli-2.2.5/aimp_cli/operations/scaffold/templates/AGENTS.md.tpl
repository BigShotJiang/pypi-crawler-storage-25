# AGENTS.md

This file routes local work. Open the matching local skill before editing.

## Read First

- `agent.py`
- `schemas.py`
- `playground.py`
- `runtime/contract.toml`
- `.aimp/project.toml`
- `.aimp/publish.toml`

## Use These Skills

- `studio-article-media`: edit `studio/article.mdx` or `studio/cover.jpg`
- `publish-readiness`: edit `runtime/contract.toml` or `.aimp/publish.toml`, or prepare a release
- `tuning-development`: edit `models/<name>/tuning/` when fine-tune is explicitly enabled
- `ci-quality-gates`: run the canonical local verification sequence

## Current Scaffold

- `agent.py` owns the public `@mode` entrypoints only.
- `schemas.py` defines the public inputs, outputs, and params used by those modes.
- `playground.py` maps each public mode to a Playground preset.
- `models/{{MODEL_KEY}}/model.py` owns the internal behavior used by the public modes.
- `models/{{MODEL_KEY}}/engine.py` owns runtime loading and execution helpers.
- `models/{{MODEL_KEY}}/vectors.py` owns declared vector bindings only.
- `models/{{MODEL_KEY}}/tuning/` exists only when tuning is intentionally enabled.
- `runtime/Dockerfile` is the root-agent container and must use `python -m aimp_sdk.agent_runner --module /app/agent.py`.
- `models/{{MODEL_KEY}}/runtime/Dockerfile` is the model runtime container and must use `python -m aimp_sdk.entrypoint --module /app/model.py`.
- `.aimp/project.toml` is the hidden scaffold contract for enabled modes, resources, and capabilities.
- `.aimp/publish.toml` stores publish intent only.

## Global Rules

- Keep `agent.py` thin and explicit. Do not invent `modes.py` or `workflows/` unless the scaffold actually adds them.
- Do not define public mode schemas or parameters in runtime contracts.
- Keep dependency and packaging metadata inside the owning `pyproject.toml`.
- If a mode reads or writes vectors, keep `models/{{MODEL_KEY}}/vectors.py`, `.aimp/project.toml`, and the implemented public modes aligned.
- Vector-enabled modes require client `scope` at execution time.
- Playground image previews depend on `image_id` and the local Playground cache. Public APIs should return IDs and metadata, not synthetic preview URLs.
- Heavy runtime assets must be preloaded during Docker build with a dedicated `runtime_preload.py`, then loaded from fixed local paths only.
- Do not hide downloads in `Engine.load()`, `Engine.build()`, or request-path code.
- Prefer non-interactive CLI usage with explicit flags
- Prefer `--json` whenever supported
