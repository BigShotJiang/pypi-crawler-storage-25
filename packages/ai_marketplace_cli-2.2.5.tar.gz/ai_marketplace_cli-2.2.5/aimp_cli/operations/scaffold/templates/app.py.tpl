{{imports}}

{{schema_blocks}}


class {{class_name}}(Model):
    """{{class_name}} — add your model logic below."""

{{method_blocks}}
