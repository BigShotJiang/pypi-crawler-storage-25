# Project Skills

Open these local skills based on the task:

- `studio-article-media`: use before editing `studio/article.mdx`, `studio/cover.jpg`, or Studio-facing copy
- `publish-readiness`: use before changing `runtime/contract.toml`, `.aimp/publish.toml`, hardware, pricing, or release flow
- `tuning-development`: use before editing `models/<name>/tuning/` for fine-tune-enabled projects
- `ci-quality-gates`: use before final verification or when a task changes public behavior

Baseline scaffold facts:

- public modes live in `agent.py`, with public schemas in `schemas.py` and Playground presets in `playground.py`
- root-agent runtimes use `python -m aimp_sdk.agent_runner --module /app/agent.py`
- vector-enabled modes require execution `scope`
- Playground image previews use `image_id` and local cache flow, not public API image URLs
- heavyweight runtime assets should be preloaded at Docker build time via `runtime_preload.py`, not downloaded at runtime
