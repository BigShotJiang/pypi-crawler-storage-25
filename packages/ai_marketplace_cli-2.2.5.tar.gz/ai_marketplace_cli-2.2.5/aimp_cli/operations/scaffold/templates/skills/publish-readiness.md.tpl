---
name: publish-readiness
description: Use when preparing a project for `ai push` or checking publish inputs.
---

# Publish Readiness

## Inspect First

- `AGENTS.md`
- `runtime/contract.toml`
- `.aimp/project.toml`
- `.aimp/publish.toml`
- `agent.py`
- `schemas.py`
- `playground.py`
- `models/`
- `studio/article.mdx`
- `studio/cover.jpg`

## Common Checks

- `runtime/contract.toml` contains public agent metadata only
- `runtime/Dockerfile` uses `python -m aimp_sdk.agent_runner --module /app/agent.py`
- `models/<name>/runtime/Dockerfile` uses `python -m aimp_sdk.entrypoint --module /app/model.py`
- `.aimp/project.toml` matches implemented public modes and declared vector aliases
- vector-enabled modes declare matching `resources.vector_db.collections` and `modes.<name>.resources.vector_aliases`
- vector-enabled modes are documented and tested with execution `scope`
- Playground image flows return `image_id` and metadata only; previews come from local cache, not public API URLs
- `.aimp/publish.toml` points to the correct Studio files and hardware intent
- `agent.py` stays thin and delegates behavior to the owning model package
- public modes in the hidden contract are actually implemented
- heavyweight runtime assets are prepared at Docker build time via `runtime_preload.py`, not startup hooks
- runtime loads are local-only and explicit; request-path code never downloads model assets
- CPU runtimes install accelerator-specific packages such as `torch` from an explicit CPU wheel source, not the generic PyPI package

## Commands

```bash
ai contract sync --json
ai contract show --json
ai contract validate --json
ai push --configure --json
ai push
```
