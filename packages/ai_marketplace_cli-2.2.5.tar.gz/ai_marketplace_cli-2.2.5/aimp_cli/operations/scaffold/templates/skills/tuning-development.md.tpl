---
name: tuning-development
description: Use when enabling fine-tune, editing tuning schema/runtime, or building tuning bundles.
---

# Tuning Development

## Agent Workflow

- Read the local schema and contract before changing tuning files.

## Local Facts

- Fine-tune configuration must be declared in `.aimp/project.toml` via `ai init --with-tuning` or `ai contract edit --fine-tune`.
- Fine-tune logic must be implemented in `models/<name>/tuning/runner.py` on the model tuning runner.
- The matching tuning dataset and hyperparameters live in `models/<name>/tuning/dataset.py` and `models/<name>/tuning/hyperparams.py`, then are attached from `models/<name>/model.py` via `tuning = ...`.
- The platform handles remote job isolation. Local debugging runs fine-tuning in a single trial loop.

## Author Flow

1. Enable fine-tune support with `ai contract edit --fine-tune --json`.
2. Edit `models/<name>/tuning/dataset.py` and `models/<name>/tuning/hyperparams.py`.
3. Implement `run(self, tuning)` in `models/<name>/tuning/runner.py`.
4. Bind the tuning runner from `models/<name>/model.py` with `tuning = ...`.
5. The platform passes generic tuning payload through `TuningContext`.
6. Publish the enabled model with `ai push`.

Example:
```python
# models/generator/tuning/runner.py
from aimp_sdk import TuneResult
from aimp_sdk.tuning import TuningContext


class GeneratorTuning:
    async def run(self, tuning: TuningContext) -> TuneResult:
        _ = tuning
        return TuneResult(metrics={"validation_loss": 0.0})
```

## Consumer Flow

1. Inspect schema with `ai fine-tune schema --model <model-slug> --json`.
2. Generate a workspace with `ai fine-tune scaffold --model <model-slug> --json`.
3. Fill `bundle.json` and local `assets/`, or edit `prepare_bundle.py`.
4. Create a job with `ai fine-tune create --model <model-slug> --output-dir . --json`.
5. Track jobs with `ai fine-tune list --json` and `ai fine-tune get --job <job-id> --json`.

## Commands

```bash
ai contract edit --fine-tune --json
ai fine-tune schema --json
ai fine-tune schema --model <model-slug> --json
ai fine-tune scaffold --model <model-slug> --json
ai fine-tune create --model <model-slug> --output-dir . --json
```
