---
name: ci-quality-gates
description: Use when running the canonical local verification sequence before publish.
---

# CI Quality Gates

## Verification Order

1. Run `py_compile` on touched Python files when the change is structural.
2. Run targeted tests for the changed area.
3. Run `ai contract sync --json` when public modes or vector resources changed.
4. Run `ai contract validate --json` when public surface or scaffold config changed.
5. Run publish-facing checks only after contract and tests are green.

## Commands

```bash
python3 -m py_compile <touched files>
ai contract sync --json
ai contract validate --json
uv run pytest
ai push --configure --json
```
