"""Fine-tune schema definitions."""

from __future__ import annotations

{{imports}}


class ModelFineTuneSchema(FineTuneSchema):
    """Explicit training input contract for this model."""
{{field_lines}}
