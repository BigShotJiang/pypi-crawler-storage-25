"""Build bundle.json for {{model_slug}} fine-tune.

This is your entry point for preparing training data.

USAGE:
    1. Edit the source_training_data() function below to load your data
    2. Run: python prepare_bundle.py
    3. Validate: Check for any errors in output
    4. Submit: ai fine-tune create --model {{model_slug}} --output-dir .

SCHEMA FIELDS:
{{schema_fields}}

Your data must have keys matching the schema fields above.
"""

from __future__ import annotations

from typing import Any, Iterator

# -----------------------------------------------------------------
# USER: Implement your data sourcing below
# 
# Use any Python library:
#   - Local files: Path("data/").glob("*.jpg")
#   - HuggingFace: from datasets import load_dataset
#   - Database: import sqlalchemy
#   - APIs: requests, httpx
#   - Cloud storage: boto3, google-cloud-storage
#
# Return an iterator of dictionaries matching the schema fields.
# -----------------------------------------------------------------


def source_training_data() -> Iterator[dict[str, Any]]:
    """Yield training records matching the schema fields.
    
    IMPLEMENT THIS FUNCTION with your data sourcing logic.
    
    Yields:
        dict: Training record with keys matching schema fields.
    
    Example:
        # From local files
        from pathlib import Path
        for img_path in Path("images/").glob("*.jpg"):
            label = img_path.stem.split("_")[0]
            yield {
                "training_images": [str(img_path)],
                "labels": [label],
            }
    """
    # TODO: Replace this placeholder with your data sourcing
    raise NotImplementedError(
        "Implement source_training_data() to yield your training records.\n"
        "Each record must have keys matching the schema fields above."
    )


# -----------------------------------------------------------------
# DO NOT EDIT BELOW - Auto-generated, uses .tuning/ helpers
# -----------------------------------------------------------------

def main() -> None:
    """Validate records and write bundle.json."""
    import sys
    from pathlib import Path
    
    # Import helpers from hidden .tuning/ folder
    tuning_dir = Path(__file__).parent / ".tuning"
    if not tuning_dir.exists():
        print("ERROR: .tuning/ folder not found. Run: ai fine-tune scaffold --model {{model_slug}}")
        sys.exit(1)
    
    sys.path.insert(0, str(tuning_dir.parent))
    try:
        from .tuning.helpers import build_bundle, load_schema
    except ImportError:
        print("ERROR: .tuning/helpers.py not found. Run: ai fine-tune scaffold --model {{model_slug}}")
        sys.exit(1)
    
    # Collect records
    try:
        records = list(source_training_data())
    except NotImplementedError as e:
        print(f"ERROR: {e}")
        sys.exit(1)
    
    if not records:
        print("ERROR: No training records returned from source_training_data()")
        sys.exit(1)
    
    # Validate and write
    schema = load_schema()
    fields = schema.get("fields", [])
    
    print(f"Schema: {len(fields)} fields")
    print(f"Records: {len(records)}")
    
    errors = build_bundle(records, "{{bundle_file_name}}")
    
    if errors:
        print("\nValidation errors:")
        for err in errors:
            print(f"  ✗ {err}")
        sys.exit(1)
    
    print(f"✓ Wrote {len(records)} validated records to {{bundle_file_name}}")
    print(f"\nNext: ai fine-tune create --model {{model_slug}} --output-dir .")


if __name__ == "__main__":
    main()