"""Internal helpers for fine-tune scaffold.

DO NOT EDIT - This file is auto-generated.
To update, run: ai fine-tune scaffold --model <slug> --regenerate
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


SCHEMA_PATH = Path(__file__).parent / "schema.json"


def load_schema() -> dict[str, Any]:
    """Load the tuning schema from schema.json.
    
    Returns:
        Schema dictionary with fields definition.
    
    Raises:
        FileNotFoundError: If schema.json doesn't exist.
        json.JSONDecodeError: If schema.json is not valid JSON.
    """
    return json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))


def get_required_fields(schema: dict[str, Any] | None = None) -> set[str]:
    """Get the set of required field names from schema.
    
    Args:
        schema: Schema dict, or None to load from file.
    
    Returns:
        Set of required field keys.
    """
    if schema is None:
        schema = load_schema()
    return {
        field["key"]
        for field in schema.get("fields", [])
        if field.get("required", True)
    }


def get_field_types(schema: dict[str, Any] | None = None) -> dict[str, str]:
    """Get a mapping of field names to their types.
    
    Args:
        schema: Schema dict, or None to load from file.
    
    Returns:
        Dict mapping field keys to their type strings.
    """
    if schema is None:
        schema = load_schema()
    return {
        field["key"]: field.get("type", "json")
        for field in schema.get("fields", [])
    }


def validate_record(record: dict[str, Any], schema: dict[str, Any] | None = None) -> list[str]:
    """Validate a single record against the schema.
    
    Args:
        record: Record dictionary to validate.
        schema: Schema dict, or None to load from file.
    
    Returns:
        List of error messages, empty if valid.
    """
    if schema is None:
        schema = load_schema()
    
    errors: list[str] = []
    required = get_required_fields(schema)
    
    missing = required - set(record.keys())
    if missing:
        errors.append(f"missing required fields: {', '.join(sorted(missing))}")
    
    fields = schema.get("fields", [])
    for field_def in fields:
        key = field_def.get("key")
        if key not in record:
            continue
        
        value = record[key]
        is_multiple = field_def.get("multiple", False)
        
        if is_multiple and not isinstance(value, list):
            errors.append(f"'{key}' must be a list (multiple=True)")
    
    return errors


def validate_records(records: list[dict[str, Any]], schema: dict[str, Any] | None = None) -> list[str]:
    """Validate multiple records against the schema.
    
    Args:
        records: List of record dictionaries to validate.
        schema: Schema dict, or None to load from file.
    
    Returns:
        List of error messages with record indices, empty if all valid.
    """
    if schema is None:
        schema = load_schema()
    
    errors: list[str] = []
    
    for i, record in enumerate(records):
        record_errors = validate_record(record, schema)
        for err in record_errors:
            errors.append(f"Record {i}: {err}")
    
    return errors


def write_bundle(records: list[dict[str, Any]], path: str | Path = "bundle.json") -> int:
    """Write records to a bundle JSON file.
    
    Args:
        records: List of record dictionaries to write.
        path: Output file path.
    
    Returns:
        Number of records written.
    """
    output_path = Path(path)
    data = {"records": records}
    output_path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    return len(records)


def build_bundle(records: list[dict[str, Any]], output_path: str | Path = "bundle.json") -> list[str]:
    """Validate and write bundle in one step.
    
    Args:
        records: List of record dictionaries.
        output_path: Output file path.
    
    Returns:
        List of validation errors, empty if successful.
    
    Raises:
        SystemExit: If validation fails.
    """
    errors = validate_records(records)
    if errors:
        return errors
    
    write_bundle(records, output_path)
    return []