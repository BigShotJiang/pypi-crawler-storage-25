"""Auto-generated tuning schema types for {{model_slug}}.

DO NOT EDIT - This file is auto-generated from schema.json.
To update, run: ai fine-tune scaffold --model {{model_slug}} --regenerate
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class TrainingRecord:
    """Single training record for {{model_slug}} model.
    
    Generated from schema.json - regenerate if schema changes.
    """
{{field_definitions}}


def validate_records(records: list[dict[str, Any]], schema_path: str = "{{schema_file_name}}") -> list[str]:
    """Validate records against schema.
    
    Args:
        records: List of record dictionaries to validate.
        schema_path: Path to schema.json file.
    
    Returns:
        List of error messages, empty if all records are valid.
    """
    import json
    from pathlib import Path
    
    errors: list[str] = []
    
    try:
        schema = json.loads(Path(schema_path).read_text(encoding="utf-8"))
    except FileNotFoundError:
        errors.append(f"Schema file not found: {schema_path}")
        return errors
    except json.JSONDecodeError as e:
        errors.append(f"Invalid schema JSON: {e}")
        return errors
    
    fields = schema.get("fields", [])
    required_fields = {f["key"] for f in fields if f.get("required", True)}
    
    for i, record in enumerate(records):
        missing = required_fields - set(record.keys())
        if missing:
            errors.append(f"Record {i}: missing required fields: {', '.join(sorted(missing))}")
        
        for field_def in fields:
            key = field_def.get("key")
            if key not in record:
                continue
            
            value = record[key]
            is_multiple = field_def.get("multiple", False)
            
            if is_multiple and not isinstance(value, list):
                errors.append(f"Record {i}: field '{key}' must be a list (multiple=True)")
            elif not is_multiple and isinstance(value, list):
                pass
    
    return errors


def write_bundle(records: list[dict[str, Any]], path: str = "{{bundle_file_name}}") -> int:
    """Write records to bundle JSON file.
    
    Args:
        records: List of record dictionaries to write.
        path: Output file path.
    
    Returns:
        Number of records written.
    """
    import json
    from pathlib import Path
    
    data = {"records": records}
    Path(path).write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    return len(records)