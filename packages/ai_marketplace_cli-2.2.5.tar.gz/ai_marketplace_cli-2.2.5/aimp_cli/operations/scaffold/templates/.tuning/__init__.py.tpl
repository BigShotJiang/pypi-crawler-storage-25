"""Auto-generated tuning scaffold helpers.

DO NOT EDIT - This package is auto-generated.
To update, run: ai fine-tune scaffold --model <slug> --regenerate
"""