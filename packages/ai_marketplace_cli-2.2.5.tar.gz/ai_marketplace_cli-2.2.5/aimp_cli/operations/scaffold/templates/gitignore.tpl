.env
.venv/
__pycache__/
.pytest_cache/
.ruff_cache/
.mypy_cache/
