"""Guided publish configuration helpers."""

from __future__ import annotations

from decimal import Decimal, InvalidOperation
from pathlib import Path

from rich.console import Console, Group, RenderableType
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from aimp_cli.core.errors import remote_state_error, usage_error
from aimp_cli.core.launcher import (
    LauncherOption,
    LauncherSection,
    confirm_action,
    prompt_text,
    select_menu,
    select_menu_fallback,
)
from aimp_cli.domain.constants import (
    DEFAULT_PUBLISH_SCHEMA_VERSION,
    DEFAULT_STUDIO_ARTICLE_MDX_FILE,
    DEFAULT_STUDIO_COVER_FILE,
    LEGACY_PUBLISH_CONFIG_FILE_NAME,
    PUBLISH_CONFIG_FILE_NAME,
    PUBLISH_CONFIG_RELATIVE_PATH,
)
from aimp_cli.domain.models import PublishHardwareTier
from aimp_cli.domain.publish_config import (
    PublishMetadataConfig,
    PublishStudioConfig,
    load_publish_config,
)
from aimp_cli.domain.protocols import PublishMetadataGatewayProtocol
from aimp_cli.domain.serialization import serialize_publish_config_toml
from aimp_cli.operations.scaffold.files import (
    studio_article_mdx_template,
    write_default_studio_cover,
)


def normalize_margin_value(value: Decimal) -> int | float:
    """Normalize decimal margin values to JSON-friendly numeric types."""
    if value == value.to_integral_value():
        return int(value)
    return float(value)


def parse_tags_input(raw_value: str) -> list[str]:
    """Parse and deduplicate comma-separated tags."""
    tags: list[str] = []
    for item in raw_value.split(","):
        tag = item.strip()
        if tag and tag not in tags:
            tags.append(tag)
    return tags


def format_hourly_usd(value: Decimal) -> str:
    """Format a price in USD/hour."""
    return f"${value.quantize(Decimal('0.01'))}/hr"


def compute_customer_hourly_price(
    *,
    base_cost_hourly: Decimal,
    developer_margin: Decimal,
    platform_fee_pct: Decimal,
) -> Decimal:
    """Compute customer hourly price from infra cost and developer margin."""
    denominator = Decimal("1") - platform_fee_pct
    if denominator <= 0:
        raise ValueError("platform_fee_pct must be below 1")
    return (base_cost_hourly + developer_margin) / denominator


def write_publish_config(project_dir: Path, config: PublishMetadataConfig) -> Path:
    """Write the hidden publish config and ensure article directories exist."""
    config_path = project_dir / PUBLISH_CONFIG_RELATIVE_PATH
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(
        serialize_publish_config_toml(config),
        encoding="utf-8",
    )
    article_path = project_dir / config.studio.article_mdx_file
    article_path.parent.mkdir(parents=True, exist_ok=True)
    if not article_path.exists():
        article_path.write_text(studio_article_mdx_template(), encoding="utf-8")
    if config.studio.cover_file == DEFAULT_STUDIO_COVER_FILE:
        cover_path = project_dir / config.studio.cover_file
        if not cover_path.exists():
            write_default_studio_cover(cover_path)
    return config_path


def render_publish_hardware_table(
    *,
    hardware_tiers: list[PublishHardwareTier],
    platform_fee_pct: Decimal,
    developer_margin: Decimal | None = None,
) -> Table:
    """Build the hardware table used in publish screens."""
    table = Table(title="Available Hardware", title_style="label", show_lines=False)
    table.add_column("#", style="muted", justify="right")
    table.add_column("Tier", style="primary", no_wrap=True)
    table.add_column("Label", style="label", no_wrap=True)
    table.add_column("Infra Cost", style="primary", no_wrap=True)
    table.add_column("Description", style="muted")
    if developer_margin is not None:
        table.add_column("Customer Price", style="success", no_wrap=True)

    for index, tier in enumerate(hardware_tiers, start=1):
        base_cost = Decimal(str(tier.base_cost_hourly))
        row = [
            str(index),
            tier.id,
            tier.label,
            format_hourly_usd(base_cost),
            tier.description,
        ]
        if developer_margin is not None:
            row.append(
                format_hourly_usd(
                    compute_customer_hourly_price(
                        base_cost_hourly=base_cost,
                        developer_margin=developer_margin,
                        platform_fee_pct=platform_fee_pct,
                    )
                )
            )
        table.add_row(*row)
    return table


def ensure_publish_config(
    *,
    project_dir: Path,
    gateway: PublishMetadataGatewayProtocol,
    configure_only: bool,
    console: Console,
    interactive_terminal: bool,
) -> PublishMetadataConfig:
    """Load or guide creation of the local publish config."""
    legacy_path = project_dir / LEGACY_PUBLISH_CONFIG_FILE_NAME
    if legacy_path.exists():
        raise usage_error(
            "Root publish config is no longer supported: aimp.publish.toml. "
            "Remove it and run: ai push --configure",
            code="legacy_publish_config_unsupported",
        )

    existing_config: PublishMetadataConfig | None = None
    load_error: RuntimeError | None = None
    try:
        existing_config = load_publish_config(project_dir)
    except RuntimeError as error:
        load_error = error

    if configure_only or load_error is not None:
        if load_error is not None and not interactive_terminal:
            detail = str(load_error)
            guidance = (
                f"Run `ai push --configure` from an interactive terminal or commit a valid "
                f"{PUBLISH_CONFIG_FILE_NAME}."
            )
            if "Run: ai push --configure" in detail:
                detail = detail.replace(" Run: ai push --configure", "")
                guidance = (
                    f"Use an interactive terminal to create {PUBLISH_CONFIG_FILE_NAME}, "
                    "or commit a valid file."
                )
            raise usage_error(
                f"{detail} {guidance}",
                code="publish_config_required",
            ) from load_error
        configured = run_publish_configuration_wizard(
            project_dir=project_dir,
            gateway=gateway,
            existing_config=existing_config,
            console=console,
            interactive_terminal=interactive_terminal,
        )
        write_publish_config(project_dir, configured)
        return configured

    if existing_config is None:
        raise usage_error(
            f"Publish config not found: {PUBLISH_CONFIG_FILE_NAME}. Run: ai push --configure",
            code="publish_config_required",
        )
    return existing_config


def run_publish_configuration_wizard(
    *,
    project_dir: Path,
    gateway: PublishMetadataGatewayProtocol,
    existing_config: PublishMetadataConfig | None,
    console: Console,
    interactive_terminal: bool,
) -> PublishMetadataConfig:
    """Collect guided publish metadata from the user."""
    metadata = gateway.get_publish_metadata()
    if not metadata.hardware_tiers:
        raise remote_state_error(
            "No hardware tiers are currently available for publish.",
            code="publish_hardware_catalog_empty",
        )

    existing_margin = Decimal(
        str(
            existing_config.pricing.get("developer_margin", 0) if existing_config is not None else 0
        )
    )
    platform_fee_pct = Decimal(str(metadata.platform_fee_pct))
    platform_fee_label = (platform_fee_pct * Decimal("100")).quantize(Decimal("0.01"))

    agent_name = prompt_text(
        "Agent name",
        console=console,
        default=(existing_config.studio.name if existing_config is not None else None),
        show_header=False,
        title="Agent Name",
        subtitle="Choose the display name for your Agent in the marketplace.",
    )
    if agent_name is None:
        raise usage_error("Publish configuration cancelled", code="publish_configuration_cancelled")
    studio_name = agent_name.strip()
    if not studio_name:
        raise usage_error(
            "Agent name is required. Set the customer-visible agent name explicitly.",
            code="invalid_studio_name",
        )

    tags_input = prompt_text(
        "Tags (comma-separated)",
        console=console,
        default=", ".join(existing_config.studio.tags) if existing_config is not None else "",
        show_header=False,
        title="Tags",
        subtitle="Add optional discovery tags as a comma-separated list.",
    )
    if tags_input is None:
        raise usage_error("Publish configuration cancelled", code="publish_configuration_cancelled")

    visibility = _select_visibility(
        default_visibility=(
            existing_config.studio.visibility if existing_config is not None else "private"
        ),
        console=console,
        interactive_terminal=interactive_terminal,
    )

    article_default = DEFAULT_STUDIO_ARTICLE_MDX_FILE
    if existing_config is not None:
        article_default = existing_config.studio.article_mdx_file or DEFAULT_STUDIO_ARTICLE_MDX_FILE
    article_path_value = prompt_text(
        "Article path",
        console=console,
        default=article_default,
        show_header=False,
        title="Article Path",
        subtitle="Point to the constrained MDX article file rendered in Studio.",
    )
    if article_path_value is None:
        raise usage_error("Publish configuration cancelled", code="publish_configuration_cancelled")
    article_path = article_path_value.strip() or article_default
    if not article_path.endswith(".mdx"):
        raise usage_error(
            "Studio article path must end with .mdx",
            code="invalid_article_path",
        )

    developer_margin = _prompt_developer_margin(
        console=console,
        hardware_tiers=metadata.hardware_tiers,
        platform_fee_pct=platform_fee_pct,
        platform_fee_label=str(platform_fee_label),
        default_margin=existing_margin,
    )

    parsed_tags_for_review = parse_tags_input(tags_input)
    review_lines = [
        f"Agent name:  {studio_name.strip()}",
        f"Tags:        {', '.join(parsed_tags_for_review) if parsed_tags_for_review else 'none'}",
        f"Visibility:  {visibility}",
        f"Article:     {article_path}",
        f"Platform fee:{platform_fee_label}%",
    ]
    review_details = Text("\n".join(review_lines), style="primary")
    if not confirm_action(
        "Save publish configuration?",
        console=console,
        default=True,
        confirm_label="Save Configuration",
        cancel_label="Cancel",
        confirm_description="Write this publish configuration to the project.",
        cancel_description="Return without saving publish settings.",
        show_header=False,
        title="Review",
        subtitle="Review publish metadata and derived customer pricing before saving.",
        details=review_details,
    ):
        raise usage_error("Publish configuration cancelled", code="publish_configuration_cancelled")

    studio_name_value = studio_name.strip()
    parsed_tags = parse_tags_input(tags_input)
    studio_config = PublishStudioConfig(
        name=studio_name_value,
        tags=parsed_tags,
        visibility=visibility,
        cover_file=(
            existing_config.studio.cover_file
            if existing_config is not None
            else DEFAULT_STUDIO_COVER_FILE
        ),
        cover_url=existing_config.studio.cover_url if existing_config is not None else None,
        article_mdx_file=article_path,
    )

    return PublishMetadataConfig(
        schema_version=DEFAULT_PUBLISH_SCHEMA_VERSION,
        studio=studio_config,
        pricing={"developer_margin": normalize_margin_value(developer_margin)},
        python_packages=existing_config.python_packages if existing_config is not None else None,
    )


def _select_visibility(
    *,
    default_visibility: str,
    console: Console,
    interactive_terminal: bool,
) -> str:
    options = [
        LauncherOption(
            key="private",
            label="private",
            description="Only you and your workspace can access the model.",
            handler=lambda: None,
        ),
        LauncherOption(
            key="public",
            label="public",
            description="Visible to marketplace users after readiness checks.",
            handler=lambda: None,
        ),
    ]
    if default_visibility in {"private", "public"}:
        options.sort(key=lambda option: option.key != default_visibility)
    sections = [LauncherSection(title="Visibility", options=options)]
    if interactive_terminal:
        try:
            selected = select_menu(
                sections,
                show_header=False,
                title="Visibility",
                subtitle="Choose whether the model stays workspace-private or becomes public.",
            )
        except Exception:
            console.print(
                "[yellow]Interactive selector unavailable. Falling back to plain menu.[/yellow]"
            )
            selected = select_menu_fallback(
                sections,
                console=console,
                show_header=False,
                title="Visibility",
                subtitle="Choose whether the model stays workspace-private or becomes public.",
            )
    else:
        selected = select_menu_fallback(
            sections,
            console=console,
            show_header=False,
            title="Visibility",
            subtitle="Choose whether the model stays workspace-private or becomes public.",
        )
    if selected is None:
        raise usage_error("Publish configuration cancelled", code="publish_configuration_cancelled")
    return selected.key


def _prompt_developer_margin(
    *,
    console: Console,
    hardware_tiers: list[PublishHardwareTier],
    platform_fee_pct: Decimal,
    platform_fee_label: str,
    default_margin: Decimal,
) -> Decimal:
    margin_error: str | None = None
    while True:
        tier_lines = [
            f"{tier.id}  {format_hourly_usd(Decimal(str(tier.base_cost_hourly)))} infra"
            for tier in hardware_tiers
        ]
        details_parts: list[RenderableType] = [
            Text("\n".join(tier_lines), style="muted"),
            Text(f"Platform fee: {platform_fee_label}%", style="muted"),
        ]
        if margin_error:
            details_parts.append(Text(margin_error, style="warning"))
        margin_input = prompt_text(
            "Developer margin (USD/hour)",
            console=console,
            default=str(normalize_margin_value(default_margin)),
            show_header=False,
            title="Developer Margin",
            subtitle=("Set your hourly margin on top of the platform-owned infrastructure cost."),
            details=Group(*details_parts),
        )
        if margin_input is None:
            raise usage_error(
                "Publish configuration cancelled",
                code="publish_configuration_cancelled",
            )
        try:
            developer_margin = Decimal(margin_input.strip())
        except InvalidOperation:
            margin_error = "Developer margin must be numeric."
            continue
        invalid_tiers = [
            tier.id
            for tier in hardware_tiers
            if Decimal(str(tier.base_cost_hourly)) + developer_margin <= 0
        ]
        if invalid_tiers:
            margin_error = "Developer margin makes the execute rate non-positive for: " + ", ".join(
                invalid_tiers
            )
            continue
        return developer_margin
