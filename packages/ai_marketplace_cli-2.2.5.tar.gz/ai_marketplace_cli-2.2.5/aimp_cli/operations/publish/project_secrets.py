"""Project secret synchronization for publish."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re

from aimp_cli.core.errors import usage_error
from aimp_cli.domain.constants import PROJECT_ENV_RELATIVE_PATH
from aimp_cli.domain.protocols import PublishGatewayProtocol

_SECRET_NAME_PATTERN = re.compile(r"^[A-Z][A-Z0-9_]{0,127}$")


@dataclass(slots=True)
class ManagedProjectSecrets:
    """Resolved project-local ``.env`` secret specification."""

    path: Path
    values: dict[str, str]

    @property
    def names(self) -> list[str]:
        return list(self.values.keys())


def _validate_secret_name(name: str, *, line_number: int) -> str:
    if not name:
        raise usage_error(
            f".env line {line_number}: secret name must be non-empty",
            code="project_secret_file_invalid",
        )
    if not _SECRET_NAME_PATTERN.fullmatch(name):
        raise usage_error(
            (
                f".env line {line_number}: secret '{name}' must start with an uppercase "
                "letter and contain only uppercase letters, numbers, and underscore (max 128 chars)"
            ),
            code="project_secret_file_invalid",
        )
    return name


def load_managed_project_secrets(project_dir: Path) -> ManagedProjectSecrets:
    """Load required project-local ``.env`` as the publish secret source of truth."""
    env_path = project_dir / PROJECT_ENV_RELATIVE_PATH
    if not env_path.exists():
        raise usage_error(
            (
                "Missing required project secret file: .env. "
                "Create it in the project root (empty file allowed for zero secrets)."
            ),
            code="project_secret_file_missing",
        )
    if not env_path.is_file():
        raise usage_error(
            "Project secret path must be a file: .env",
            code="project_secret_file_invalid",
        )

    values: dict[str, str] = {}
    for line_number, raw_line in enumerate(
        env_path.read_text(encoding="utf-8").splitlines(),
        start=1,
    ):
        if not raw_line:
            continue
        if raw_line.startswith("#"):
            continue
        if "=" not in raw_line:
            raise usage_error(
                f".env line {line_number}: expected NAME=VALUE",
                code="project_secret_file_invalid",
            )
        raw_name, raw_value = raw_line.split("=", 1)
        name = _validate_secret_name(raw_name, line_number=line_number)
        if name in values:
            raise usage_error(
                f".env line {line_number}: duplicate secret '{name}'",
                code="project_secret_file_invalid",
            )
        values[name] = raw_value

    return ManagedProjectSecrets(path=env_path, values=values)


def sync_managed_project_secrets(
    *,
    gateway: PublishGatewayProtocol,
    model_slug: str,
    managed_secrets: ManagedProjectSecrets,
) -> None:
    """Reconcile remote model secrets to exactly match project-local ``.env``."""
    remote = gateway.list_model_secrets(model_slug=model_slug)
    remote_names = {item.name for item in remote.secrets}
    local_names = set(managed_secrets.values.keys())

    # Upsert local desired state first; if this fails, do not delete any remote secret.
    for name in sorted(local_names):
        gateway.set_model_secret(
            model_slug=model_slug,
            name=name,
            value=managed_secrets.values[name],
        )

    # Delete extras only after all upserts have succeeded.
    for name in sorted(remote_names - local_names):
        gateway.delete_model_secret(model_slug=model_slug, name=name)
