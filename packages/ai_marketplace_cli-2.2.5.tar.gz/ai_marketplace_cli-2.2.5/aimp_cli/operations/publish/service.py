"""Publish-specific service helpers."""

from __future__ import annotations

from aimp_cli.domain.models import CliPublishResult


def build_publish_success_message(result: CliPublishResult) -> str:
    """Build the human-readable publish success summary."""
    if result.detached:
        lines = [
            "Remote build started.",
            f"Slug: {result.slug}",
            f"Version: {result.version or 'unknown'}",
            f"Build group: {result.publish_build_group_id}",
        ]
        phase = str(result.phase or "").strip()
        current_step = str(result.current_step_message or "").strip()
        if phase:
            lines.append(f"Phase: {phase}")
        if current_step:
            lines.append(f"Current step: {current_step}")
        lines.append(f"Watch: ai jobs watch --type build --job {result.publish_build_group_id}")
        lines.append("Registration and finalization continue on the same remote build group.")
        return "\n".join(lines)

    is_ready = result.readiness.is_ready
    reasons = result.readiness.blocking_reasons

    lines = [
        "Deployment successful.",
        f"Slug: {result.slug}",
        f"Visibility: {result.visibility or 'unknown'}",
        f"Ready: {'yes' if is_ready else 'no'}",
        f"URL: {result.url or 'unknown'}",
    ]
    if not is_ready and reasons:
        lines.append("Blocking reasons:")
        lines.extend(f"- {reason}" for reason in reasons)
    return "\n".join(lines)
