"""Publish workflow implementation."""

from __future__ import annotations

import json
import io
import os
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time
import tomllib
from collections.abc import Iterator
from contextlib import contextmanager
from fnmatch import fnmatch
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlparse, urlunparse
from urllib.request import urlopen

from rich.errors import LiveError
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
)

from aimp_cli.clients.gateway import UploadClient
from aimp_cli.clients.studio_article import (
    collect_local_media_references,
    parse_constrained_mdx,
    replace_media_sources,
)
from aimp_cli.core.config import CommandContext, can_prompt_for_input, console
from aimp_cli.core.errors import (
    CliError,
    coerce_cli_error,
    environment_error,
    usage_error,
)
from aimp_cli.core.launcher import confirm_action, prompt_text
from aimp_cli.domain.constants import (
    AGENT_ENTRYPOINT_RELATIVE_PATH,
    PROJECT_CONFIG_FILE_NAME,
    PUBLISH_CONFIG_FILE_NAME,
)
from aimp_cli.domain.models import (
    CliPublishResult,
    MEDIA_TYPE_ORDER,
    ModeReadinessPayload,
    OUTPUT_TYPE_ORDER,
    PublishBuildGroup,
    PublishBuildGroupCreateRequest,
    PublishRegistrationIntent,
    PublishRequest,
    ResourceConfig,
    SdkContract,
    StudioCoverPayload,
    StudioPublishPayload,
)
from aimp_cli.domain.project_config import (
    AgentContractMetadata,
    ProjectConfig,
    load_agent_contract,
    load_project_config,
    load_project_config_payload,
    load_project_config_with_resource_override,
    write_agent_contract,
    write_project_config,
)
from aimp_cli.domain.protocols import (
    DockerBackendProtocol,
    PublishGatewayProtocol,
    UploadClientFactoryProtocol,
    UploadClientProtocol,
)
from aimp_cli.domain.publish_config import (
    PublishPythonPackagesConfig,
    load_publish_config,
    load_studio_article_source,
    resolve_studio_file_paths,
)
from aimp_cli.domain.serialization import serialize_project_config_toml
from aimp_cli.domain.runtime_packages import (
    OFFICIAL_RUNTIME_DEPENDENCY_SPECS,
    RUNTIME_DEPENDENCY_NAMES,
)
from aimp_cli.operations.publish.mappers import (
    map_detached_publish_build_group,
    map_publish_response,
    map_registration_result,
)
from aimp_cli.operations.publish.project_secrets import (
    load_managed_project_secrets,
    sync_managed_project_secrets,
)
from aimp_cli.utils.docker_build import resolve_docker_build_spec
from aimp_cli.utils.execution_stream import ExecutionStreamCallbacks, watch_execution_stream
from aimp_cli.utils.publish_watch import PublishWatchRenderer

_ACTIVE_JOB_STATUSES = {"queued", "running"}
_LIVE_DISPLAY_DEPTH = 0
_DEFAULT_PYPI_SIMPLE_INDEX_URL = "https://pypi.org/simple/"
_RUNTIME_PACKAGE_INDEX_PROPAGATION_ATTEMPTS = 6
_RUNTIME_PACKAGE_INDEX_PROPAGATION_INTERVAL_SECONDS = 10.0
_RUNTIME_PACKAGE_INDEX_TIMEOUT_SECONDS = 5.0
_SEMVER_PATCH_PATTERN = re.compile(r"^(?P<major>\d+)\.(?P<minor>\d+)\.(?P<patch>\d+)$")
_DEFAULT_SOURCE_BUNDLE_EXCLUDE_PATTERNS = (
    ".git/",
    ".venv/",
    "venv/",
    "__pycache__/",
    "*.pyc",
)


def _project_config_is_missing_publish_section(project_dir: Path) -> bool:
    """Return whether the on-disk hidden project config lacks `[publish]`."""
    config_path = project_dir / PROJECT_CONFIG_FILE_NAME
    if not config_path.exists():
        return False
    raw = tomllib.loads(config_path.read_text(encoding="utf-8"))
    return not isinstance(raw.get("publish"), dict)


def _runtime_pythonpaths() -> list[str]:
    repo_python_root = Path(__file__).resolve().parents[4]
    source_paths: list[str] = []
    for candidate in (
        repo_python_root / "sdk",
        repo_python_root / "framework",
    ):
        if candidate.exists():
            source_paths.append(str(candidate))
    if source_paths:
        return source_paths

    paths: list[str] = []
    for module_name in ("aimp_sdk", "aimp_framework"):
        try:
            module = __import__(module_name)
        except ModuleNotFoundError:
            continue
        module_path = Path(module.__file__).resolve().parent.parent
        candidate = str(module_path)
        if candidate not in paths:
            paths.append(candidate)
    return paths


def _build_contract_pythonpath(
    *,
    project_dir: Path,
    env: dict[str, str],
) -> str:
    paths = [*_runtime_pythonpaths(), str(project_dir.resolve())]
    existing = env.get("PYTHONPATH")
    if existing:
        paths.append(existing)
    return os.pathsep.join(paths)


def _build_python_extraction_env(
    *,
    project_dir: Path,
    publish_config: Any | None,
) -> dict[str, str]:
    """Build the environment used by local Python extraction subprocesses."""
    _ = publish_config
    env = os.environ.copy()
    env["PYTHONPATH"] = _build_contract_pythonpath(
        project_dir=project_dir,
        env=env,
    )
    return env


def _raise_legacy_vector_contract_shape(
    *,
    project_dir: Path,
    raw_resources: Any,
) -> None:
    """Reject legacy vector contract payloads emitted by stale authoring runtimes."""
    if not isinstance(raw_resources, dict):
        return
    vector_db = raw_resources.get("vector_db", False)
    legacy_shape: str | None = None
    if vector_db is True:
        legacy_shape = "resources.vector_db=true"
    elif isinstance(vector_db, dict) and "aliases" in vector_db:
        legacy_shape = "resources.vector_db.aliases"
    if legacy_shape is None:
        return
    raise usage_error(
        (
            f"Python authoring for '{project_dir.name}' emitted legacy vector resources "
            f"({legacy_shape}). This CLI only accepts "
            "resources.vector_db.collections for vector-enabled models."
        ),
        code="legacy_python_contract_shape",
        hint=(
            "Use the repo-aligned CLI/runtime packages. For local development run "
            "`uv run --project packages/python/cli ai ...`, or reinstall the tool with "
            "`uv tool install ./packages/python/cli --force`."
        ),
        extra={"project_dir": str(project_dir), "legacy_shape": legacy_shape},
    )


def _load_project_pyproject(project_dir: Path) -> dict[str, Any]:
    """Load and validate the project's ``pyproject.toml``."""
    pyproject_path = project_dir / "pyproject.toml"
    return _load_pyproject_payload(pyproject_path, code_prefix="pyproject")


def _load_pyproject_payload(path: Path, *, code_prefix: str) -> dict[str, Any]:
    """Load and validate one concrete ``pyproject.toml`` payload."""
    display_path = str(path)
    if not path.exists():
        raise usage_error(
            f"{display_path} is required for publish",
            code=f"{code_prefix}_missing",
        )
    try:
        payload = tomllib.loads(path.read_text(encoding="utf-8"))
    except tomllib.TOMLDecodeError as exc:
        raise usage_error(
            f"{display_path} is invalid: {exc}",
            code=f"{code_prefix}_invalid",
        ) from exc
    if not isinstance(payload, dict):
        raise usage_error(
            f"{display_path} must parse to a table payload",
            code=f"{code_prefix}_invalid",
        )
    return payload


def _load_agent_contract_metadata(project_dir: Path) -> AgentContractMetadata:
    """Load publish-facing public metadata from ``contract.toml``."""
    try:
        return load_agent_contract(project_dir)
    except RuntimeError as exc:
        raise usage_error(str(exc), code="contract_invalid") from exc


def _replace_project_version_in_pyproject_text(text: str, *, version: str) -> str:
    """Replace ``[project].version`` while preserving the rest of the file."""
    lines = text.splitlines()
    inside_project = False
    replaced = False
    version_pattern = re.compile(r"^(\s*version\s*=\s*)(['\"])(.*)(\2\s*)$")

    for index, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith("[") and stripped.endswith("]"):
            inside_project = stripped == "[project]"
            continue
        if not inside_project:
            continue
        match = version_pattern.match(line)
        if match is None:
            continue
        prefix, quote_char, _, suffix = match.groups()
        lines[index] = f"{prefix}{quote_char}{version}{suffix}"
        replaced = True
        break

    if not replaced:
        raise usage_error(
            "pyproject.toml must define [project].version",
            code="pyproject_missing_version",
        )
    return "\n".join(lines) + ("\n" if text.endswith("\n") else "")


def _derive_build_pyproject(project_dir: Path, *, version: str) -> str:
    """Return build-time ``pyproject.toml`` text with the publish version injected."""
    pyproject_path = project_dir / "pyproject.toml"
    if not pyproject_path.exists():
        raise usage_error("pyproject.toml is required for publish", code="pyproject_missing")
    current_text = pyproject_path.read_text(encoding="utf-8")
    return _replace_project_version_in_pyproject_text(current_text, version=version)


def _suggest_next_version(version: str) -> str:
    """Return the next patch release for a semantic version."""
    match = _SEMVER_PATCH_PATTERN.fullmatch(version.strip())
    if match is None:
        raise usage_error(
            f"Version {version!r} must use semantic version format X.Y.Z to auto-suggest the next release.",
            code="version_bump_unsupported",
            hint="Update contract.toml manually to the next version, then retry.",
        )
    major = int(match.group("major"))
    minor = int(match.group("minor"))
    patch = int(match.group("patch")) + 1
    return f"{major}.{minor}.{patch}"


def _sync_project_versions(project_dir: Path, *, version: str) -> None:
    """Persist one agreed publish version to ``contract.toml`` only."""
    metadata = _load_agent_contract_metadata(project_dir)
    write_agent_contract(project_dir, metadata.model_copy(update={"version": version}))


def _resolve_publish_version(
    *,
    project_dir: Path,
    gateway: PublishGatewayProtocol,
    slug: str,
    context: CommandContext,
) -> AgentContractMetadata:
    """Resolve the local publish version, validate format, and fail before build on duplicates."""
    metadata = _load_agent_contract_metadata(project_dir)

    if _SEMVER_PATCH_PATTERN.fullmatch(metadata.version.strip()) is None:
        raise usage_error(
            f"Version '{metadata.version}' in contract.toml must use semantic version format X.Y.Z (e.g., 1.0.0).",
            code="invalid_semantic_version",
            hint="Update the version in contract.toml to standard format like 1.0.0 and retry ai push.",
        )

    while True:
        existing_release = gateway.get_model_version(slug, metadata.version)
        if existing_release is None:
            return metadata

        if context.json_output or not can_prompt_for_input():
            raise usage_error(
                f"Model '{slug}' version '{metadata.version}' already exists.",
                code="local_version_conflict",
                request_id=context.request_id,
                hint="Update contract.toml to a new version, then retry ai push.",
                extra={"slug": slug, "version": metadata.version},
            )

        suggested_version = _suggest_next_version(metadata.version)
        next_version = prompt_text(
            "Press Enter to accept the suggested next version, or type a new one:",
            console=console,
            default=suggested_version,
            show_header=False,
            title="Version Conflict",
            subtitle=(f"{slug}@{metadata.version} already exists remotely. No build has started."),
            details={
                "existing_version": metadata.version,
                "suggested_version": suggested_version,
            },
        )
        if next_version is None:
            raise usage_error(
                "Publish canceled before build started.",
                code="publish_canceled_by_user",
                request_id=context.request_id,
            )
        normalized_version = next_version.strip()
        if not normalized_version:
            console.print("[yellow]Version must be non-empty.[/yellow]")
            continue
        if _SEMVER_PATCH_PATTERN.fullmatch(normalized_version) is None:
            console.print(
                f"[yellow]Version '{normalized_version}' must use semantic version format X.Y.Z (e.g., 0.2.0).[/yellow]"
            )
            continue
        if normalized_version == metadata.version:
            console.print("[yellow]Choose a different version than the existing release.[/yellow]")
            continue
        _sync_project_versions(project_dir, version=normalized_version)
        metadata = _load_agent_contract_metadata(project_dir)


def _load_runtime_dependency_specs(project_dir: Path) -> dict[str, str]:
    """Load and validate runtime package dependency specs from runtime manifests."""
    manifest_paths = _runtime_manifest_paths(project_dir)
    if not manifest_paths:
        raise usage_error(
            (
                "Remote publish requires runtime manifests. Expected runtime/pyproject.toml "
                "and any models/*/runtime/pyproject.toml files used by published images."
            ),
            code="runtime_manifest_missing",
            extra={"project_dir": str(project_dir)},
        )

    for manifest_path in manifest_paths:
        payload = _load_pyproject_payload(
            manifest_path,
            code_prefix="runtime_manifest",
        )
        project = payload.get("project")
        if not isinstance(project, dict):
            raise usage_error(
                f"{manifest_path} must define a [project] table",
                code="runtime_manifest_missing_project",
                extra={"path": str(manifest_path)},
            )
        dependencies = project.get("dependencies")
        if not isinstance(dependencies, list):
            raise usage_error(
                f"{manifest_path} must define [project].dependencies as an array",
                code="runtime_manifest_missing_dependencies",
                extra={"path": str(manifest_path)},
            )
        resolved: dict[str, str] = {}
        for raw in dependencies:
            if not isinstance(raw, str):
                continue
            stripped = raw.strip()
            for name in RUNTIME_DEPENDENCY_NAMES:
                if _matches_runtime_dependency_name(stripped, name):
                    resolved[name] = stripped

        missing = [name for name in RUNTIME_DEPENDENCY_NAMES if name not in resolved]
        if missing:
            missing_display = ", ".join(missing)
            raise usage_error(
                (
                    f"{manifest_path} must declare runtime package dependencies: "
                    f"{missing_display}. Published runtime images are built from runtime manifests, "
                    "not the root pyproject.toml."
                ),
                code="runtime_dependencies_missing",
                extra={"path": str(manifest_path), "missing": missing},
            )
        for package_name in RUNTIME_DEPENDENCY_NAMES:
            actual_spec = resolved[package_name]
            expected_spec = OFFICIAL_RUNTIME_DEPENDENCY_SPECS[package_name]
            if actual_spec != expected_spec:
                raise usage_error(
                    (
                        f"{manifest_path} must pin official runtime packages exactly for "
                        "remote publish. "
                        f"Expected {expected_spec!r} but found {actual_spec!r}. "
                        "Published runtime images are built from runtime manifests, "
                        "not the root pyproject.toml."
                    ),
                    code="runtime_dependencies_must_be_exact",
                    extra={"path": str(manifest_path), "package_name": package_name},
                )

    return {
        name: OFFICIAL_RUNTIME_DEPENDENCY_SPECS[name]
        for name in RUNTIME_DEPENDENCY_NAMES
    }


def _runtime_manifest_paths(project_dir: Path) -> list[Path]:
    """Return the concrete runtime manifests that define published image dependencies."""
    manifest_paths: list[Path] = []
    root_runtime = project_dir / "runtime" / "pyproject.toml"
    if root_runtime.exists():
        manifest_paths.append(root_runtime)
    models_dir = project_dir / "models"
    if models_dir.exists():
        manifest_paths.extend(sorted(models_dir.glob("*/runtime/pyproject.toml")))
    return manifest_paths


def _legacy_runtime_path_sources(payload: dict[str, Any]) -> dict[str, str]:
    """Return runtime path sources declared via ``[tool.uv.sources]``."""
    tool = payload.get("tool")
    if not isinstance(tool, dict):
        return {}
    uv = tool.get("uv")
    if not isinstance(uv, dict):
        return {}
    sources = uv.get("sources")
    if not isinstance(sources, dict):
        return {}

    legacy_sources: dict[str, str] = {}
    for package_name in RUNTIME_DEPENDENCY_NAMES:
        source = sources.get(package_name)
        if not isinstance(source, dict):
            continue
        path_value = source.get("path")
        if isinstance(path_value, str) and path_value.strip():
            legacy_sources[package_name] = path_value.strip()
    return legacy_sources


def _reject_legacy_runtime_path_sources(project_dir: Path) -> None:
    """Reject local runtime path sources for remote publish."""
    candidate_paths = [project_dir / "pyproject.toml", *_runtime_manifest_paths(project_dir)]
    for path in candidate_paths:
        if not path.exists():
            continue
        payload = _load_pyproject_payload(path, code_prefix="pyproject")
        legacy_sources = _legacy_runtime_path_sources(payload)
        if not legacy_sources:
            continue
        package_names = ", ".join(sorted(legacy_sources))
        raise usage_error(
            (
                f"{path} uses local runtime path sources for {package_names}. "
                "Remote publish supports published PyPI packages only. "
                "Remove [tool.uv.sources] from runtime manifests and retry."
            ),
            code="runtime_path_sources_unsupported",
            extra={"path": str(path), "packages": sorted(legacy_sources)},
        )


def _matches_runtime_dependency_name(spec: str, package_name: str) -> bool:
    pattern = rf"^\s*{re.escape(package_name)}(?:\[[^]]+\])?(?:$|[\s<>=!~@(;])"
    return re.match(pattern, spec) is not None


def _extra_package_index_from_env() -> dict[str, str] | None:
    extra_index_url = os.getenv("AIMP_PYTHON_PACKAGE_EXTRA_INDEX_URL", "").strip()
    username = os.getenv("AIMP_PYTHON_PACKAGE_INDEX_USERNAME", "").strip()
    password = os.getenv("AIMP_PYTHON_PACKAGE_INDEX_PASSWORD", "")

    if not any((extra_index_url, username, password)):
        return None

    missing: list[str] = []
    if not extra_index_url:
        missing.append("AIMP_PYTHON_PACKAGE_EXTRA_INDEX_URL")
    if bool(username) != bool(password):
        if not username:
            missing.append("AIMP_PYTHON_PACKAGE_INDEX_USERNAME")
        if not password:
            missing.append("AIMP_PYTHON_PACKAGE_INDEX_PASSWORD")
    if missing:
        raise environment_error(
            "Python package extra index config is incomplete: " + ", ".join(missing),
            code="python_package_index_config_incomplete",
        )

    parsed = urlparse(extra_index_url)
    if parsed.scheme not in {"http", "https"}:
        raise environment_error(
            "AIMP_PYTHON_PACKAGE_EXTRA_INDEX_URL must use http or https.",
            code="python_package_index_config_invalid",
        )
    if not parsed.netloc:
        raise environment_error(
            "AIMP_PYTHON_PACKAGE_EXTRA_INDEX_URL must include a hostname.",
            code="python_package_index_config_invalid",
        )

    if not username and not password:
        return {"extra_index_url": extra_index_url}

    netloc = f"{quote(username, safe='')}:{quote(password, safe='')}@{parsed.netloc}"
    return {
        "extra_index_url": extra_index_url,
        "username": username,
        "password": password,
        "authenticated_extra_index_url": urlunparse(parsed._replace(netloc=netloc)),
    }


def _python_package_index_from_publish_config(
    publish_config: PublishPythonPackagesConfig | None,
) -> dict[str, str] | None:
    if publish_config is None:
        return None
    payload = {"extra_index_url": publish_config.extra_index_url}
    if publish_config.username is not None and publish_config.password is not None:
        payload["username"] = publish_config.username
        payload["password"] = publish_config.password
        parsed = urlparse(publish_config.extra_index_url)
        netloc = (
            f"{quote(publish_config.username, safe='')}:{quote(publish_config.password, safe='')}"
            f"@{parsed.netloc}"
        )
        payload["authenticated_extra_index_url"] = urlunparse(parsed._replace(netloc=netloc))
    return payload


def _resolve_python_package_index(
    publish_config: PublishPythonPackagesConfig | None,
) -> dict[str, str] | None:
    env_override = _extra_package_index_from_env()
    if env_override is not None:
        return env_override
    return _python_package_index_from_publish_config(publish_config)


def _normalize_simple_index_url(index_url: str) -> str:
    normalized = index_url.strip()
    if not normalized:
        return _DEFAULT_PYPI_SIMPLE_INDEX_URL
    return normalized.rstrip("/") + "/"


def _redact_package_index_url(index_url: str) -> str:
    parsed = urlparse(index_url)
    if not parsed.netloc or "@" not in parsed.netloc:
        return _normalize_simple_index_url(index_url)
    _, _, host = parsed.netloc.rpartition("@")
    return _normalize_simple_index_url(urlunparse(parsed._replace(netloc=host)))


def _runtime_package_index_urls(
    python_package_index: dict[str, str] | None,
) -> tuple[str, ...]:
    urls = [_DEFAULT_PYPI_SIMPLE_INDEX_URL]
    if python_package_index is not None:
        extra_index_url = str(python_package_index.get("extra_index_url", "")).strip()
        if extra_index_url:
            urls.append(extra_index_url)

    normalized_urls: list[str] = []
    seen: set[str] = set()
    for url in urls:
        normalized = _normalize_simple_index_url(url)
        if normalized in seen:
            continue
        normalized_urls.append(normalized)
        seen.add(normalized)
    return tuple(normalized_urls)


def _format_runtime_package_index_targets(
    python_package_index: dict[str, str] | None,
) -> str:
    return ", ".join(
        _redact_package_index_url(url) for url in _runtime_package_index_urls(python_package_index)
    )


def _minimum_runtime_package_version(spec: str, package_name: str) -> str | None:
    suffix = re.sub(
        rf"^\s*{re.escape(package_name)}(?:\[[^]]+\])?\s*",
        "",
        spec.strip(),
        count=1,
    )
    if not suffix:
        return None
    requirement_part = suffix.split(";", 1)[0].strip()
    if requirement_part.startswith("@"):
        return None
    minimum_version: str | None = None
    for clause in requirement_part.split(","):
        stripped = clause.strip()
        if not stripped:
            continue
        match = re.match(r"^(==|>=|~=)\s*([A-Za-z0-9_.!+-]+)$", stripped)
        if match is None:
            continue
        operator, version = match.groups()
        if operator == "==":
            return version
        if minimum_version is None:
            minimum_version = version
    return minimum_version


def _runtime_package_simple_index_url(index_url: str, package_name: str) -> str:
    normalized_name = re.sub(r"[-_.]+", "-", package_name).lower()
    return _normalize_simple_index_url(index_url) + f"{normalized_name}/"


def _fetch_runtime_package_simple_index(index_url: str, package_name: str) -> str:
    project_url = _runtime_package_simple_index_url(index_url, package_name)
    with urlopen(project_url, timeout=_RUNTIME_PACKAGE_INDEX_TIMEOUT_SECONDS) as response:
        return response.read().decode("utf-8", errors="replace")


def _simple_index_contains_package_version(
    package_name: str,
    version: str,
    page_content: str,
) -> bool:
    normalized_name_pattern = re.escape(package_name).replace(r"\-", "[-_]+")
    version_pattern = re.compile(
        rf"{normalized_name_pattern}[-_]+{re.escape(version)}(?:[-_.]|%2B)",
        re.IGNORECASE,
    )
    return version_pattern.search(page_content) is not None


def _missing_runtime_packages_from_indexes(
    *,
    dependency_specs: dict[str, str],
    python_package_index: dict[str, str] | None,
) -> dict[str, str] | None:
    index_urls = _runtime_package_index_urls(python_package_index)
    missing: dict[str, str] = {}
    for package_name in RUNTIME_DEPENDENCY_NAMES:
        required_version = _minimum_runtime_package_version(
            dependency_specs[package_name],
            package_name,
        )
        if required_version is None:
            continue

        found = False
        had_fetch_error = False
        for index_url in index_urls:
            try:
                page_content = _fetch_runtime_package_simple_index(index_url, package_name)
            except (HTTPError, URLError, OSError):
                had_fetch_error = True
                continue
            if _simple_index_contains_package_version(
                package_name,
                required_version,
                page_content,
            ):
                found = True
                break
        if found:
            continue
        if had_fetch_error:
            return None
        missing[package_name] = required_version
    return missing


def _wait_for_runtime_package_index_visibility(
    *,
    dependency_specs: dict[str, str],
    python_package_index: dict[str, str] | None,
) -> None:
    missing = _missing_runtime_packages_from_indexes(
        dependency_specs=dependency_specs,
        python_package_index=python_package_index,
    )
    if missing is None or not missing:
        return

    checked_indexes = _format_runtime_package_index_targets(python_package_index)
    missing_display = ", ".join(
        f"{package_name}=={version}" for package_name, version in missing.items()
    )
    propagation_window_seconds = int(
        _RUNTIME_PACKAGE_INDEX_PROPAGATION_ATTEMPTS
        * _RUNTIME_PACKAGE_INDEX_PROPAGATION_INTERVAL_SECONDS
    )
    console.print(
        "Runtime package release not yet visible on package index; "
        f"waiting up to {propagation_window_seconds}s "
        f"for propagation. Checked: {checked_indexes}. Missing: {missing_display}."
    )

    for _ in range(1, _RUNTIME_PACKAGE_INDEX_PROPAGATION_ATTEMPTS):
        time.sleep(_RUNTIME_PACKAGE_INDEX_PROPAGATION_INTERVAL_SECONDS)
        missing = _missing_runtime_packages_from_indexes(
            dependency_specs=dependency_specs,
            python_package_index=python_package_index,
        )
        if missing is None or not missing:
            return

    missing_display = ", ".join(
        f"{package_name}=={version}" for package_name, version in missing.items()
    )
    raise usage_error(
        (
            "Published runtime packages are not yet visible on the package index. "
            f"Checked: {checked_indexes}. Missing: {missing_display}."
        ),
        code="runtime_packages_unavailable",
    )


def _verify_runtime_packages_downloadable(
    *,
    dependency_specs: dict[str, str],
    python_bin: str | None,
    python_package_index: dict[str, str] | None,
) -> None:
    """Fail early when runtime packages cannot be resolved from a publishable index."""
    effective_python_package_index = python_package_index
    if effective_python_package_index is None:
        effective_python_package_index = _extra_package_index_from_env()

    _wait_for_runtime_package_index_visibility(
        dependency_specs=dependency_specs,
        python_package_index=effective_python_package_index,
    )

    uv_bin = shutil.which("uv")
    if not uv_bin:
        raise environment_error(
            "uv is required to verify publishable runtime packages.",
            code="uv_missing_for_publish_validation",
        )

    interpreter = python_bin or sys.executable
    env = os.environ.copy()
    cmd = [
        uv_bin,
        "pip",
        "install",
        "--dry-run",
        "--no-deps",
        "--python",
        interpreter,
        "--index-url",
        _DEFAULT_PYPI_SIMPLE_INDEX_URL,
    ]
    if effective_python_package_index is not None:
        cmd.extend(
            [
                "--extra-index-url",
                effective_python_package_index.get("authenticated_extra_index_url")
                or effective_python_package_index["extra_index_url"],
            ]
        )
    cmd.extend([dependency_specs[name] for name in RUNTIME_DEPENDENCY_NAMES])
    try:
        subprocess.run(
            cmd,
            check=True,
            capture_output=True,
            text=True,
            env=env,
        )
    except subprocess.CalledProcessError as exc:
        detail = (exc.stderr or exc.stdout or "").strip()
        raise usage_error(
            (
                "Published runtime packages are not downloadable from the configured "
                f"package index. Checked: "
                f"{_format_runtime_package_index_targets(effective_python_package_index)}. "
                "Release `ai-marketplace-framework` and "
                "`ai-marketplace-sdk` before remote publish."
            )
            + (f" Details: {detail}" if detail else ""),
            code="runtime_packages_unavailable",
        ) from exc


class _SyncResult:
    """Result of syncing SDK modes to TOML config."""

    def __init__(
        self,
        *,
        added_modes: list[str],
        updated_modes: list[str],
        removed_modes: list[str],
        updated_resources: bool,
    ) -> None:
        self.added_modes = added_modes
        self.updated_modes = updated_modes
        self.removed_modes = removed_modes
        self.updated_resources = updated_resources

    @property
    def has_changes(self) -> bool:
        return bool(
            self.added_modes or self.updated_modes or self.removed_modes or self.updated_resources
        )


def _sync_sdk_modes_to_config(
    *,
    sdk_contract: SdkContract,
    project_config: ProjectConfig,
) -> _SyncResult:
    """Sync SDK-declared modes to project config.

    Rebuilds hidden managed mode definitions from SDK authoring.
    Syncs resources from Python authoring declarations.

    Args:
        sdk_contract: Contract extracted from SDK @mode decorators.
        project_config: Current project config from contract.toml.

    Returns:
        _SyncResult with added/updated/removed modes and whether resources were updated.
    """
    from aimp_cli.domain.models import (
        InputDefinition,
        ModeContract,
        ModesConfig,
        OutputDefinition,
        ResourceConfig,
        SdkModeContract,
        normalize_public_output_kind,
    )

    normalized_sdk_modes: dict[str, SdkModeContract] = {}
    for mode_name, raw_mode in dict(sdk_contract.modes).items():
        if isinstance(raw_mode, SdkModeContract):
            normalized_sdk_modes[mode_name] = raw_mode
        else:
            payload = dict(raw_mode or {})
            raw_inputs = payload.get("inputs")
            raw_outputs = payload.get("outputs")
            if isinstance(raw_inputs, list):
                normalized_inputs: list[dict[str, Any]] = []
                for item in raw_inputs:
                    if isinstance(item, str):
                        normalized_inputs.append({"name": item, "kind": item, "required": True})
                    else:
                        normalized_inputs.append(item)
                payload["inputs"] = normalized_inputs
            if isinstance(raw_outputs, list):
                normalized_outputs: list[dict[str, Any]] = []
                for item in raw_outputs:
                    if isinstance(item, str):
                        normalized_outputs.append({"name": item, "kind": item, "required": True})
                    else:
                        normalized_outputs.append(item)
                payload["outputs"] = normalized_outputs
            normalized_sdk_modes[mode_name] = SdkModeContract.model_validate(payload)

    sdk_mode_names = set(normalized_sdk_modes.keys())
    toml_mode_names = set(project_config.modes.names())

    added_modes: list[str] = []
    updated_modes: list[str] = []
    removed_modes = sorted(toml_mode_names - sdk_mode_names)
    updated_resources = False
    existing_modes: dict[str, ModeContract] = dict(project_config.modes.root)
    new_modes: dict[str, ModeContract] = {}

    for mode_name in sorted(sdk_mode_names):
        sdk_mode = normalized_sdk_modes[mode_name]
        existing_mode = existing_modes.get(mode_name)
        input_defs: list[InputDefinition] = []
        if sdk_mode.inputs:
            for inp in sdk_mode.inputs:
                if inp.kind not in MEDIA_TYPE_ORDER:
                    raise ValueError(
                        f"SDK mode '{mode_name}' declares unsupported local input kind: {inp.kind}"
                    )
                input_defs.append(
                    InputDefinition(
                        name=inp.name,
                        kind=inp.kind,
                        required=inp.required,
                        description=inp.description or "",
                        multiple=inp.multiple,
                        label=inp.label,
                        default=inp.default,
                    )
                )
        elif existing_mode is not None:
            input_defs = list(existing_mode.inputs)
        if not input_defs:
            input_defs = [InputDefinition(name="text", kind="text", required=True)]

        output_defs: list[OutputDefinition] = []
        if sdk_mode.outputs:
            for output in sdk_mode.outputs:
                try:
                    published_kind = normalize_public_output_kind(output.kind)
                except ValueError:
                    raise ValueError(
                        f"SDK mode '{mode_name}' declares unsupported local output kind: {output.kind}"
                    )
                output_defs.append(
                    OutputDefinition(
                        name=output.name,
                        kind=published_kind,
                        required=output.required,
                        description=output.description or "",
                        multiple=output.multiple,
                        label=output.label,
                        default=output.default,
                    )
                )
        elif existing_mode is not None:
            output_defs = list(existing_mode.outputs)
        if not output_defs:
            output_defs = [OutputDefinition(name="result", kind="text", required=True)]

        next_mode = ModeContract(
            inputs=input_defs,
            outputs=output_defs,
            description=sdk_mode.description
            or (existing_mode.description if existing_mode else ""),
            resources=(
                sdk_mode.resources.model_copy(deep=True)
                if sdk_mode.resources
                else (
                    existing_mode.resources.model_copy(deep=True)
                    if existing_mode and existing_mode.resources
                    else None
                )
            ),
        )
        new_modes[mode_name] = next_mode
        if existing_mode is None:
            added_modes.append(mode_name)
        elif existing_mode.model_dump(exclude_none=True) != next_mode.model_dump(exclude_none=True):
            updated_modes.append(mode_name)

    sdk_resources = ResourceConfig.model_validate(getattr(sdk_contract, "resources", {}) or {})
    alias_names = {
        alias
        for sdk_mode in normalized_sdk_modes.values()
        if sdk_mode.resources is not None
        for alias in sdk_mode.resources.vector_aliases
    }
    if alias_names:
        declared_aliases = {alias.lower() for alias in sdk_resources.vector_aliases}
        if not declared_aliases:
            raise ValueError(
                "resources.vector_db.collections must declare all mode-scoped vector aliases"
            )
        missing_aliases = [
            alias for alias in sorted(alias_names) if alias.lower() not in declared_aliases
        ]
        if missing_aliases:
            raise ValueError(
                "modes.*.resources.vector_aliases contains undeclared aliases: "
                + ", ".join(missing_aliases)
            )
    sdk_resources_changed = project_config.resources.model_dump(
        exclude_none=True
    ) != sdk_resources.model_dump(exclude_none=True)
    if sdk_resources_changed:
        project_config.resources = sdk_resources.model_copy(deep=True)
        project_config.capabilities.vector = project_config.resources.vector_db_enabled
        updated_resources = True

    if added_modes or updated_modes or removed_modes:
        project_config.modes = ModesConfig(new_modes)

    return _SyncResult(
        added_modes=added_modes,
        updated_modes=updated_modes,
        removed_modes=removed_modes,
        updated_resources=updated_resources,
    )


class _NoopStatus:
    """No-op status handle used when a live display is already active."""

    def __init__(self, message: str) -> None:
        self.message = message

    def update(self, message: str) -> None:
        """Accept status updates without owning the console live display."""
        self.message = message


class _NoopProgress:
    """No-op progress handle used when a live display is already active."""

    def __init__(self) -> None:
        self._next_task_id = 0

    def add_task(self, *_args: Any, **_kwargs: Any) -> int:
        """Return a stable task identifier without rendering progress."""
        self._next_task_id += 1
        return self._next_task_id

    def update(self, *_args: Any, **_kwargs: Any) -> None:
        """Accept progress updates without rendering output."""

    def stop(self) -> None:
        """Mirror the Rich Progress stop API for callers."""


@contextmanager
def _managed_status(message: str, *, spinner: str = "line") -> Iterator[Any]:
    """Render a status spinner only when no other live display owns the console."""
    global _LIVE_DISPLAY_DEPTH

    if _LIVE_DISPLAY_DEPTH > 0:
        yield _NoopStatus(message)
        return

    status_manager = console.status(message, spinner=spinner)
    _LIVE_DISPLAY_DEPTH += 1
    try:
        try:
            status = status_manager.__enter__()
        except LiveError:
            yield _NoopStatus(message)
            return
        try:
            yield status
        finally:
            status_manager.__exit__(None, None, None)
    finally:
        _LIVE_DISPLAY_DEPTH -= 1


@contextmanager
def _managed_progress(*columns: Any, transient: bool) -> Iterator[Progress | _NoopProgress]:
    """Render progress only when no other live display owns the console."""
    global _LIVE_DISPLAY_DEPTH

    if _LIVE_DISPLAY_DEPTH > 0:
        yield _NoopProgress()
        return

    progress_manager = Progress(*columns, console=console, transient=transient)
    _LIVE_DISPLAY_DEPTH += 1
    try:
        try:
            progress = progress_manager.__enter__()
        except LiveError:
            yield _NoopProgress()
            return
        try:
            yield progress
        finally:
            progress_manager.__exit__(None, None, None)
    finally:
        _LIVE_DISPLAY_DEPTH -= 1


def _build_contract_python_candidates(
    python_bin: str | None,
    *,
    project_dir: Path,
) -> list[str]:
    """Return ordered Python interpreter candidates for contract extraction."""
    candidates: list[str] = []
    seen: set[str] = set()

    def add(candidate: str | None) -> None:
        if not candidate:
            return
        normalized = candidate.strip()
        if not normalized or normalized in seen:
            return
        seen.add(normalized)
        candidates.append(normalized)

    add(python_bin)
    add(str(project_dir / ".venv" / "bin" / "python"))
    add(str(project_dir / ".venv" / "Scripts" / "python.exe"))
    add(str(project_dir / ".venv" / "Scripts" / "python"))
    venv = os.getenv("VIRTUAL_ENV")
    if venv:
        add(str(Path(venv) / "bin" / "python"))
        add(str(Path(venv) / "Scripts" / "python.exe"))
        add(str(Path(venv) / "Scripts" / "python"))
    add(sys.executable)
    return candidates


def extract_contract_from_python(
    *,
    project_dir: Path,
    python_bin: str | None,
    publish_config: Any | None = None,
) -> SdkContract:
    """Extract operations contract from ``agent.py`` using the project interpreter."""
    module_path = project_dir / AGENT_ENTRYPOINT_RELATIVE_PATH
    if not module_path.exists():
        raise environment_error(
            f"{AGENT_ENTRYPOINT_RELATIVE_PATH} not found. Run: ai init",
            code="missing_project_file",
        )
    resolved_candidates = _build_contract_python_candidates(
        python_bin,
        project_dir=project_dir,
    )
    last_error = ""
    for candidate in resolved_candidates:
        env = _build_python_extraction_env(
            project_dir=project_dir,
            publish_config=publish_config,
        )
        try:
            completed = subprocess.run(
                [candidate, "-m", "aimp_sdk.contract", "--module", str(module_path)],
                check=False,
                capture_output=True,
                text=True,
                env=env,
            )
        except OSError as error:
            last_error = str(error)
            continue
        output = (completed.stdout or completed.stderr or "").strip()
        if completed.returncode != 0:
            last_error = output or f"Contract extraction failed with exit {completed.returncode}"
            continue
        if not output:
            raise usage_error("No contract output from Python", code="contract_extraction_failed")
        try:
            payload = json.loads(output)
            if not isinstance(payload, dict):
                raise ValueError("Contract extraction must return a JSON object")
            _raise_legacy_vector_contract_shape(
                project_dir=project_dir,
                raw_resources=payload.get("resources"),
            )
            normalized_modes: dict[str, Any] = {}
            raw_modes = payload.get("modes") or {}
            if isinstance(raw_modes, dict):
                for mode_name, raw_mode in raw_modes.items():
                    if not isinstance(raw_mode, dict):
                        continue
                    normalized_modes[str(mode_name)] = {
                        "inputs": raw_mode.get("inputs") or [],
                        "outputs": raw_mode.get("outputs") or [],
                        "parameters": raw_mode.get("parameters") or {},
                        "description": raw_mode.get("description"),
                        "spaces": raw_mode.get("spaces"),
                        "resources": raw_mode.get("resources"),
                    }
            normalized_payload = {
                "schema_version": payload.get("schema_version"),
                "capabilities": payload.get("capabilities") or {},
                "resources": payload.get("resources") or {},
                "modes": normalized_modes,
                "parameters": payload.get("parameters") or {},
                "tuning": payload.get("tuning"),
            }
            return SdkContract.model_validate(normalized_payload)
        except (ValueError, TypeError) as error:
            raise usage_error(
                f"Contract extraction returned invalid JSON: {error}",
                code="contract_extraction_failed",
            ) from error
    if last_error:
        tried = ", ".join(resolved_candidates)
        raise usage_error(
            f"{last_error} (python candidates tried: {tried})",
            code="contract_extraction_failed",
        )
    raise environment_error(
        "Python contract extraction failed",
        code="python_not_found",
        hint="Provide --python or activate the project virtual environment.",
    )


def extract_tuning_contract_from_python(
    *,
    project_dir: Path,
    python_bin: str | None,
    model_key: str,
    publish_config: Any | None = None,
) -> dict[str, Any] | None:
    """Extract model-scoped fine-tune contract from agent module."""
    module_path = project_dir / AGENT_ENTRYPOINT_RELATIVE_PATH
    if not module_path.exists():
        return None

    resolved_candidates = _build_contract_python_candidates(
        python_bin,
        project_dir=project_dir,
    )
    last_error = ""
    for candidate in resolved_candidates:
        env = _build_python_extraction_env(
            project_dir=project_dir,
            publish_config=publish_config,
        )
        try:
            completed = subprocess.run(
                [
                    candidate,
                    "-m",
                    "aimp_sdk.tuning_contract",
                    "--module",
                    str(module_path),
                    "--model-key",
                    model_key,
                ],
                check=False,
                capture_output=True,
                text=True,
                env=env,
            )
        except OSError as error:
            last_error = str(error)
            continue
        output = (completed.stdout or completed.stderr or "").strip()
        if completed.returncode != 0:
            last_error = (
                output or f"Tuning contract extraction failed with exit {completed.returncode}"
            )
            continue
        if not output:
            raise usage_error(
                "No tuning contract output from Python", code="tuning_contract_failed"
            )
        try:
            return json.loads(output)
        except (ValueError, TypeError) as error:
            raise usage_error(
                f"Tuning contract extraction returned invalid JSON: {error}",
                code="tuning_contract_failed",
            ) from error
    if last_error:
        tried = ", ".join(resolved_candidates)
        raise usage_error(
            f"{last_error} (python candidates tried: {tried})",
            code="tuning_contract_failed",
        )
    return None


def extract_mode_readiness_from_python(
    *,
    project_dir: Path,
    python_bin: str | None,
    mode_names: list[str] | None = None,
    publish_config: Any | None = None,
) -> ModeReadinessPayload:
    """Extract SDK-level public mode implementation verification from ``agent.py``."""
    module_path = project_dir / AGENT_ENTRYPOINT_RELATIVE_PATH
    if not module_path.exists():
        raise environment_error(
            f"{AGENT_ENTRYPOINT_RELATIVE_PATH} not found. Run: ai init",
            code="missing_project_file",
        )

    resolved_candidates = _build_contract_python_candidates(
        python_bin,
        project_dir=project_dir,
    )
    last_error = ""
    for candidate in resolved_candidates:
        env = _build_python_extraction_env(
            project_dir=project_dir,
            publish_config=publish_config,
        )
        try:
            completed = subprocess.run(
                [candidate, "-m", "aimp_sdk.mode_readiness", "--module", str(module_path)],
                check=False,
                capture_output=True,
                text=True,
                env=env,
            )
        except OSError as error:
            last_error = str(error)
            continue
        output = (completed.stdout or completed.stderr or "").strip()
        if completed.returncode != 0:
            last_error = (
                output or f"Mode readiness extraction failed with exit {completed.returncode}"
            )
            continue
        if not output:
            raise usage_error(
                "No mode readiness output from Python",
                code="mode_readiness_failed",
            )
        try:
            payload = json.loads(output)
        except (ValueError, TypeError) as error:
            raise usage_error(
                f"Mode readiness extraction returned invalid JSON: {error}",
                code="mode_readiness_failed",
            ) from error

        modes = mode_names or list(payload.keys())
        normalized_payload: dict[str, dict[str, Any]] = {}
        for mode in modes:
            entry = payload.get(mode) or {}
            implemented = bool(entry.get("implemented"))
            reason = entry.get("reason")
            if not implemented and not reason:
                reason = f"{mode}() is not implemented by this model"
            normalized_payload[mode] = {
                "declared": True,
                "implemented": implemented,
                "reason": reason,
            }
        return ModeReadinessPayload.model_validate(normalized_payload)

    if last_error:
        tried = ", ".join(resolved_candidates)
        raise usage_error(
            f"{last_error} (python candidates tried: {tried})",
            code="mode_readiness_failed",
        )
    raise environment_error(
        "Python mode readiness extraction failed",
        code="python_not_found",
        hint="Provide --python or activate the project virtual environment.",
    )


def build_mode_readiness_payload(
    *,
    modes: Any,
    implementation_status: ModeReadinessPayload,
) -> ModeReadinessPayload:
    """Combine contract-declared modes with SDK method overrides."""
    payload: dict[str, dict[str, Any]] = {}
    for mode_name in modes.names():
        readiness = implementation_status.get(mode_name)
        implemented = bool(readiness.implemented) if readiness is not None else False
        reason = readiness.reason if readiness is not None else None
        if not implemented and not reason:
            reason = f"{mode_name}() is not implemented by this model"
        payload[mode_name] = {
            "declared": True,
            "implemented": implemented,
            "reason": None if implemented else reason,
        }

    return ModeReadinessPayload.model_validate(payload)


def build_publish_payload(
    *,
    slug: str,
    version: str,
    publish_build_group_id: str,
    selected_hardware_tier: str,
    project_config: ProjectConfig,
    sdk_contract: SdkContract,
    required_secrets: list[str],
    mode_readiness: ModeReadinessPayload,
    parameters: dict[str, Any],
    tuning_contract: dict[str, Any] | None,
    publish_config: Any,
    studio: StudioPublishPayload,
) -> PublishRequest:
    """Build the publish request."""
    registration_intent = build_publish_registration_intent(
        project_config=project_config,
        selected_hardware_tier=selected_hardware_tier,
        sdk_contract=sdk_contract,
        required_secrets=required_secrets,
        mode_readiness=mode_readiness,
        parameters=parameters,
        tuning_contract=tuning_contract,
        publish_config=publish_config,
        studio=studio,
    )
    return PublishRequest(
        slug=slug,
        version=version,
        publish_build_group_id=publish_build_group_id,
        resources=registration_intent.resources,
        modes=registration_intent.modes,
        mode_readiness=registration_intent.mode_readiness,
        required_secrets=registration_intent.required_secrets,
        parameters=registration_intent.parameters,
        tuning=registration_intent.tuning,
        pricing=registration_intent.pricing,
        selected_hardware_tier=registration_intent.selected_hardware_tier,
        studio=registration_intent.studio,
    )


def build_publish_registration_intent(
    *,
    project_config: ProjectConfig,
    selected_hardware_tier: str,
    sdk_contract: SdkContract,
    required_secrets: list[str],
    mode_readiness: ModeReadinessPayload,
    parameters: dict[str, Any],
    tuning_contract: dict[str, Any] | None,
    publish_config: Any,
    studio: StudioPublishPayload,
) -> PublishRegistrationIntent:
    """Build one canonical publish registration intent for control-plane orchestration."""
    _ = sdk_contract
    normalized_selected_hardware_tier = str(selected_hardware_tier or "").strip().lower()
    if not normalized_selected_hardware_tier:
        raise usage_error(
            "Deployment hardware selection is required. Run `ai push --hardware <sku>`.",
            code="selected_hardware_tier_missing",
        )
    return PublishRegistrationIntent(
        resources=project_config.resources,
        modes=project_config.modes,
        mode_readiness=mode_readiness,
        required_secrets=list(required_secrets),
        parameters=parameters,
        tuning=tuning_contract,
        pricing=publish_config.pricing,
        selected_hardware_tier=normalized_selected_hardware_tier,
        studio=studio,
    )


def _default_upload_client_factory(gateway: PublishGatewayProtocol) -> UploadClientProtocol:
    """Build the default upload client for publish operations."""
    return UploadClient(gateway)


def _build_studio_publish_payload(
    *,
    project_dir: Path,
    publish_config: Any,
    gateway: PublishGatewayProtocol,
) -> StudioPublishPayload:
    """Build the Studio metadata payload for publish."""
    article_path, cover_path = resolve_studio_file_paths(project_dir, publish_config)
    article_source = load_studio_article_source(project_dir, publish_config)
    article_payload = parse_constrained_mdx(article_source)

    replacements: dict[str, str] = {}
    for reference in collect_local_media_references(article_payload, article_path=article_path):
        if not reference.resolved_path.exists() or not reference.resolved_path.is_file():
            raise usage_error(
                f"Studio media file not found: {reference.source}",
                code="studio_media_not_found",
            )
        upload_result = gateway.upload_studio_media(
            file_path=reference.resolved_path,
            media_type=reference.media_type,
        )
        public_url = str(upload_result.get("public_url") or "").strip()
        if not public_url:
            raise usage_error(
                f"Studio media upload missing public_url for {reference.source}",
                code="studio_media_public_url_missing",
            )
        replacements[reference.source] = public_url

    article_payload = replace_media_sources(article_payload, replacements)

    cover_payload: StudioCoverPayload | None = None
    if cover_path is not None:
        upload_result = gateway.upload_studio_media(file_path=cover_path, media_type="image")
        cover_payload = StudioCoverPayload(
            media_ref=str(upload_result.get("media_ref") or "").strip() or None,
            storage_uri=str(upload_result.get("storage_uri") or "").strip() or None,
            public_url=str(upload_result.get("public_url") or "").strip() or None,
        )
    elif getattr(publish_config.studio, "cover_url", None):
        cover_payload = StudioCoverPayload(public_url=publish_config.studio.cover_url)

    return StudioPublishPayload(
        name=publish_config.studio.name,
        tags=list(publish_config.studio.tags),
        visibility=publish_config.studio.visibility,
        article=article_payload,
        cover=cover_payload,
    )


def _load_dockerignore_patterns(build_context: Path) -> list[str]:
    """Load ordered ``.dockerignore`` patterns for the build context."""
    patterns: list[str] = list(_DEFAULT_SOURCE_BUNDLE_EXCLUDE_PATTERNS)
    dockerignore_path = build_context / ".dockerignore"
    if not dockerignore_path.exists():
        return patterns

    for raw_line in dockerignore_path.read_text(encoding="utf-8").splitlines():
        candidate = raw_line.strip()
        if not candidate or candidate.startswith("#"):
            continue
        patterns.append(candidate)
    return patterns


def _dockerignore_matches(relative_path: Path, *, pattern: str, is_dir: bool) -> bool:
    """Return whether one relative path matches a simplified Docker ignore pattern."""
    normalized_path = relative_path.as_posix()
    normalized_pattern = pattern.lstrip("/")
    dir_only = normalized_pattern.endswith("/")
    normalized_pattern = normalized_pattern.rstrip("/")
    if not normalized_pattern:
        return False

    if dir_only:
        path_parts = [part for part in relative_path.parts if part not in {"."}]
        if "/" not in normalized_pattern:
            return any(fnmatch(part, normalized_pattern) for part in path_parts)

        ancestor_paths = ["/".join(path_parts[:index]) for index in range(1, len(path_parts) + 1)]
        if not is_dir and ancestor_paths:
            ancestor_paths = ancestor_paths[:-1]
        if pattern.startswith("/"):
            return any(fnmatch(candidate, normalized_pattern) for candidate in ancestor_paths)
        suffix_candidates: list[str] = []
        for candidate in ancestor_paths:
            parts = candidate.split("/")
            suffix_candidates.extend("/".join(parts[index:]) for index in range(len(parts)))
        return any(fnmatch(candidate, normalized_pattern) for candidate in suffix_candidates)

    if "/" not in normalized_pattern:
        path_parts = [part for part in relative_path.parts if part not in {"."}]
        return any(fnmatch(part, normalized_pattern) for part in path_parts)

    candidates = [normalized_path]
    if not pattern.startswith("/"):
        path_parts = normalized_path.split("/")
        candidates.extend("/".join(path_parts[index:]) for index in range(1, len(path_parts)))
    return any(fnmatch(candidate, normalized_pattern) for candidate in candidates)


def _should_include_in_bundle(
    relative_path: Path,
    *,
    is_dir: bool,
    patterns: list[str],
    forced_includes: set[str],
) -> bool:
    """Apply ordered Docker ignore rules to a context-relative path."""
    normalized_path = relative_path.as_posix()
    for forced_include in forced_includes:
        normalized_forced = forced_include.rstrip("/")
        if normalized_path == normalized_forced:
            return True
        if normalized_forced and normalized_path.startswith(f"{normalized_forced}/"):
            return True

    include = True
    for pattern in patterns:
        negated = pattern.startswith("!")
        candidate = pattern[1:] if negated else pattern
        if _dockerignore_matches(relative_path, pattern=candidate, is_dir=is_dir):
            include = negated
    return include


def create_source_bundle_archive(
    *,
    build_context: Path,
    dockerfile: str | None,
    derived_pyproject_text: str | None = None,
) -> Path:
    """Create a compressed source bundle for remote publish builds."""
    patterns = _load_dockerignore_patterns(build_context)
    forced_includes = {
        ".dockerignore",
        dockerfile or "Dockerfile",
        "pyproject.toml",
        PROJECT_CONFIG_FILE_NAME,
        PUBLISH_CONFIG_FILE_NAME,
    }
    bundle_fd, bundle_name = tempfile.mkstemp(prefix="aimp-source-bundle-", suffix=".tar.gz")
    os.close(bundle_fd)
    bundle_path = Path(bundle_name)
    with tarfile.open(bundle_path, mode="w:gz") as archive:
        for path in build_context.rglob("*"):
            relative_path = path.relative_to(build_context)
            if not _should_include_in_bundle(
                relative_path,
                is_dir=path.is_dir(),
                patterns=patterns,
                forced_includes=forced_includes,
            ):
                continue
            if path.is_symlink():
                raise usage_error(
                    (
                        "Publish source bundle cannot include symbolic links: "
                        f"{relative_path.as_posix()}"
                    ),
                    code="publish_source_bundle_symlink_unsupported",
                )
            if (
                derived_pyproject_text is not None
                and relative_path.as_posix() == "pyproject.toml"
                and path.is_file()
            ):
                payload = derived_pyproject_text.encode("utf-8")
                info = tarfile.TarInfo(name="pyproject.toml")
                info.size = len(payload)
                info.mtime = int(path.stat().st_mtime)
                archive.addfile(info, io.BytesIO(payload))
                continue
            archive.add(path, arcname=str(relative_path), recursive=False)
    return bundle_path


def _is_terminal_build_status(status_value: str) -> bool:
    """Return whether one publish build status is terminal."""
    return status_value in {"succeeded", "failed", "canceled"}


def _build_publish_terminal_failure_message(build_group: PublishBuildGroup) -> str:
    """Return one phase-aware terminal publish failure message for CLI output."""
    current_step = str(build_group.current_step_message or "").strip()
    error_message = str(build_group.error_message or "").strip()
    if current_step and error_message and current_step.lower() != error_message.lower():
        return f"{current_step}: {error_message}"
    if current_step:
        return current_step
    if error_message:
        return error_message
    return "Remote publish build failed"


def wait_for_publish_build_group(
    *,
    gateway: PublishGatewayProtocol,
    job_id: str,
    context: CommandContext,
) -> PublishBuildGroup:
    """Watch one remote publish build group until it reaches a terminal state."""
    renderer = PublishWatchRenderer(console, job_id)
    with _managed_status("Attaching to remote build", spinner="line") as status:
        watch_execution_stream(
            gateway=gateway,
            job_id=job_id,
            context=context,
            callbacks=ExecutionStreamCallbacks(
                on_snapshot=lambda execution: renderer.apply_snapshot(execution, status),
                on_status=lambda payload: renderer.apply_status(payload, status),
                on_timeline=lambda items, _payload: renderer.render_timeline(items),
                on_logs=lambda items, _payload: renderer.render_logs(items),
                on_terminal=lambda execution: renderer.apply_terminal(execution, status),
            ),
        )
    return gateway.get_publish_build_group(job_id)


def _confirm_remote_build_cancel(job_id: str) -> bool:
    """Prompt for remote build cancellation using the interactive TUI."""
    if not sys.stdin.isatty():
        return False
    return confirm_action(
        f"Cancel remote build {job_id[:8]}?",
        console=console,
        show_header=False,
        confirm_label="Cancel Build",
        cancel_label="Keep Running",
        confirm_description="Cancel the remote build job and remove it from history.",
        cancel_description="Stop watching locally; the build continues running remotely.",
        title="Stop Watching",
        subtitle=f"Build job {job_id[:8]} is still running remotely.",
    )


def cancel_publish_build_group(
    *,
    gateway: PublishGatewayProtocol,
    job_id: str,
    poll_interval_seconds: float,
) -> None:
    """Cancel one remote build group and remove it from history."""
    payload = gateway.cancel_publish_build_group(job_id)
    if payload.cancel_state == "canceling":
        with _managed_status("Canceling remote build...", spinner="line") as status:
            while True:
                try:
                    job = gateway.get_publish_build_group(job_id)
                except CliError as error:
                    if error.http_status == 404:
                        return
                    raise
                status.update(f"Canceling remote build: {job.status} · job {job.job_id[:8]}")
                if job.status == "canceled":
                    gateway.delete_publish_build_group(job_id)
                    return
                time.sleep(poll_interval_seconds)
    gateway.delete_publish_build_group(job_id)


def resolve_publish_build_group_result(
    *,
    gateway: PublishGatewayProtocol,
    build_group: PublishBuildGroup,
    context: CommandContext,
) -> CliPublishResult:
    """Resolve one submitted or reused publish build group into a final publish result."""
    resolved_group = build_group
    if resolved_group.status in _ACTIVE_JOB_STATUSES:
        try:
            resolved_group = wait_for_publish_build_group(
                gateway=gateway,
                job_id=resolved_group.job_id,
                context=context,
            )
        except KeyboardInterrupt as error:
            if _confirm_remote_build_cancel(resolved_group.job_id):
                cancel_publish_build_group(
                    gateway=gateway,
                    job_id=resolved_group.job_id,
                    poll_interval_seconds=1.0,
                )
                raise usage_error(
                    "Remote publish build canceled and removed",
                    code="publish_build_canceled",
                    extra={"job_id": resolved_group.job_id},
                ) from error
            console.print(
                f"\nStopped watching remote publish build. "
                f"Job {resolved_group.job_id[:8]} is still running remotely."
            )
            raise
    elif resolved_group.status not in {"succeeded", "failed", "canceled"}:
        resolved_group = gateway.get_publish_build_group(resolved_group.job_id)

    if resolved_group.status != "succeeded":
        raise environment_error(
            _build_publish_terminal_failure_message(resolved_group),
            code=resolved_group.error_code or "publish_build_failed",
            extra={
                "job_id": resolved_group.job_id,
                "phase": resolved_group.phase,
                "stage": resolved_group.stage,
                "current_step_message": resolved_group.current_step_message,
            },
        )

    return map_registration_result(
        registration_result=resolved_group.registration_result,
        slug=resolved_group.slug,
        version=resolved_group.version,
        job_id=resolved_group.job_id,
        request_id=context.request_id,
    )


def run_publish(
    *,
    project_dir: Path,
    gateway: PublishGatewayProtocol,
    docker: DockerBackendProtocol | None = None,
    context: CommandContext,
    selected_hardware_tier: str,
    python_bin: str | None,
    parallel: int,
    verbose: bool,
    force: bool = False,
    detach: bool = False,
    upload_client_factory: UploadClientFactoryProtocol = _default_upload_client_factory,
) -> CliPublishResult:
    """Run the full publish flow."""
    slug = project_dir.name.replace(" ", "-").lower()
    bundle_path: Path | None = None
    try:
        # ── Phase 1: Extract local contract and configuration ──────────────────
        model_info = _resolve_publish_version(
            project_dir=project_dir,
            gateway=gateway,
            slug=slug,
            context=context,
        )
        publish_config = load_publish_config(project_dir)
        with _managed_status("Extracting contract…", spinner="line"):
            sdk_contract = extract_contract_from_python(
                project_dir=project_dir,
                python_bin=python_bin,
                publish_config=publish_config,
            )
            sdk_resources = ResourceConfig.model_validate(
                getattr(sdk_contract, "resources", {}) or {}
            )
            if (project_dir / PROJECT_CONFIG_FILE_NAME).exists():
                raw_project_config = load_project_config_payload(project_dir)
                try:
                    current_resources = ResourceConfig.model_validate(
                        raw_project_config.get("resources") or {}
                    )
                    resources_need_normalization = current_resources.model_dump(
                        exclude_none=True
                    ) != sdk_resources.model_dump(exclude_none=True)
                except Exception:
                    resources_need_normalization = True
                project_config = load_project_config_with_resource_override(
                    project_dir,
                    resource_override=sdk_resources,
                )
            else:
                resources_need_normalization = False
                project_config = load_project_config(project_dir)
            managed_project_secrets = load_managed_project_secrets(project_dir)
            _reject_legacy_runtime_path_sources(project_dir)
            runtime_dependency_specs = _load_runtime_dependency_specs(project_dir)

        sync_result = _sync_sdk_modes_to_config(
            sdk_contract=sdk_contract,
            project_config=project_config,
        )
        if resources_need_normalization:
            project_config.resources = sdk_resources.model_copy(deep=True)
            project_config.capabilities.vector = project_config.resources.vector_db_enabled
        if sync_result.has_changes or resources_need_normalization:
            write_project_config(project_dir, project_config)
            project_config = load_project_config(project_dir)
            if sync_result.added_modes:
                console.print(
                    f"[green]Auto-synced modes to contract.toml:[/green] "
                    f"{', '.join(sync_result.added_modes)}"
                )
            if sync_result.updated_modes:
                console.print(
                    f"[green]Auto-updated managed mode definitions:[/green] "
                    f"{', '.join(sync_result.updated_modes)}"
                )
            if sync_result.removed_modes:
                console.print(
                    f"[green]Auto-removed unmanaged mode definitions:[/green] "
                    f"{', '.join(sync_result.removed_modes)}"
                )
            if sync_result.updated_resources or resources_need_normalization:
                console.print("[green]Auto-synced runtime resources from Python authoring[/green]")

        if _project_config_is_missing_publish_section(project_dir):
            normalized_text = serialize_project_config_toml(project_config)
            project_config_path = project_dir / PROJECT_CONFIG_FILE_NAME
            project_config_path.write_text(normalized_text, encoding="utf-8")
            project_config = load_project_config(project_dir)
            console.print(
                "[green]Auto-synced publish packaging config from managed defaults[/green]"
            )

        with _managed_status("Extracting mode readiness…", spinner="line"):
            sdk_mode_readiness = extract_mode_readiness_from_python(
                project_dir=project_dir,
                python_bin=python_bin,
                mode_names=project_config.modes.names(),
                publish_config=publish_config,
            )
            mode_readiness = build_mode_readiness_payload(
                modes=project_config.modes,
                implementation_status=sdk_mode_readiness,
            )
            python_package_index = _resolve_python_package_index(
                getattr(publish_config, "python_packages", None)
            )
            tuning_contract: dict[str, Any] | None = None
            if project_config.tuning is not None:
                tuning_contract = extract_tuning_contract_from_python(
                    project_dir=project_dir,
                    python_bin=python_bin,
                    model_key=project_config.tuning.model_key,
                    publish_config=publish_config,
                )
                if tuning_contract is None:
                    raise usage_error(
                        "Unable to extract model-scoped tuning contract from agent module",
                        code="tuning_contract_failed",
                    )
            sdk_parameters: dict[str, Any] = sdk_contract.parameters or {}

        with _managed_status("Preparing Studio metadata", spinner="line"):
            studio_payload = _build_studio_publish_payload(
                project_dir=project_dir,
                publish_config=publish_config,
                gateway=gateway,
            )
            registration_intent = build_publish_registration_intent(
                project_config=project_config,
                selected_hardware_tier=selected_hardware_tier,
                sdk_contract=sdk_contract,
                required_secrets=managed_project_secrets.names,
                mode_readiness=mode_readiness,
                parameters=sdk_parameters,
                tuning_contract=tuning_contract,
                publish_config=publish_config,
                studio=studio_payload,
            )

        with _managed_status("Syncing project secrets", spinner="line"):
            sync_managed_project_secrets(
                gateway=gateway,
                model_slug=slug,
                managed_secrets=managed_project_secrets,
            )

        # ── Phase 2: Package/upload and submit publish intent ──────────────────
        with _managed_progress(
            SpinnerColumn(spinner_name="line", style="info"),
            TextColumn("[progress.description]{task.description}", style="primary"),
            BarColumn(bar_width=None, style="border", complete_style="info"),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%", style="muted"),
            TimeElapsedColumn(),
            transient=not verbose,
        ) as progress:
            task_id = progress.add_task("Initializing…", total=100)

            progress.update(task_id, description="Verifying published runtime packages")
            _verify_runtime_packages_downloadable(
                dependency_specs=runtime_dependency_specs,
                python_bin=python_bin,
                python_package_index=python_package_index,
            )
            progress.update(task_id, completed=15)

            progress.update(task_id, description="Resolving build context")
            build_context, dockerfile = resolve_docker_build_spec(project_dir)
            derived_pyproject_text = _derive_build_pyproject(
                project_dir=project_dir,
                version=model_info.version,
            )
            progress.update(task_id, completed=25)

            progress.update(task_id, description="Packaging source bundle")
            bundle_path = create_source_bundle_archive(
                build_context=build_context,
                dockerfile=dockerfile,
                derived_pyproject_text=derived_pyproject_text,
            )
            progress.update(task_id, completed=45)

            progress.update(task_id, completed=50, description="Uploading source bundle")
            upload_client = upload_client_factory(gateway)
            upload_result = upload_client.upload_file(
                file_path=bundle_path,
                slug=slug,
                version=model_info.version,
                artifact_type="source_bundle",
                content_type="application/gzip",
                metadata={
                    "original_name": model_info.name,
                    "bundle_type": "publish_source",
                },
                concurrency=parallel,
                on_progress=None,
            )

            progress.update(task_id, completed=75, description="Submitting publish intent")
            submitted_build_group = gateway.create_publish_build_group(
                PublishBuildGroupCreateRequest(
                    slug=slug,
                    version=model_info.version,
                    source_artifact_uri=upload_result.storage_uri,
                    source_artifact_id=upload_result.artifact_id,
                    dockerfile_path=dockerfile or "Dockerfile",
                    build_context_path=".",
                    selected_hardware_tier=registration_intent.selected_hardware_tier,
                    registration_intent=registration_intent,
                    python_package_index=python_package_index,
                    force=force,
                )
            )
            progress.update(task_id, completed=100, description="Publish intent submitted")
            if detach:
                return map_detached_publish_build_group(
                    build_group=submitted_build_group,
                    request_id=context.request_id,
                )

        return resolve_publish_build_group_result(
            gateway=gateway,
            build_group=submitted_build_group,
            context=context,
        )
    except LiveError as error:
        raise environment_error(
            "Publish output renderer encountered a live display conflict",
            code="publish_live_display_conflict",
            request_id=context.request_id,
            hint="Retry the publish command or use `--json` for non-interactive automation.",
        ) from error
    except CliError:
        raise
    except RuntimeError as error:
        raise coerce_cli_error(error, request_id=context.request_id) from error
    finally:
        if bundle_path is not None:
            bundle_path.unlink(missing_ok=True)


def publish_model_by_slug(*, gateway: PublishGatewayProtocol, slug: str) -> CliPublishResult:
    """Publish one existing remote model without rebuilding local artifacts."""
    publish_response = gateway.publish_model_by_slug(slug)
    return map_publish_response(publish_response)
