"""Transport-to-domain mapping for publish flows."""

from __future__ import annotations

from typing import Any

from aimp_cli.core.errors import environment_error
from aimp_cli.domain.models import (
    CliPublishReadinessView,
    CliPublishResult,
    PublishBuildGroup,
    PublishResponse,
)


def _map_readiness(raw_readiness: Any) -> CliPublishReadinessView:
    """Normalize transport readiness into the CLI-owned readiness model."""
    readiness_payload = (
        raw_readiness
        if isinstance(raw_readiness, dict)
        else {"is_ready": False, "blocking_reasons": []}
    )
    return CliPublishReadinessView.model_validate(readiness_payload)


def map_publish_response(response: PublishResponse) -> CliPublishResult:
    """Map Gateway transport publish response into one CLI-native domain result."""
    readiness_payload = (
        response.readiness.model_dump(exclude_none=True)
        if response.readiness is not None
        else None
    )
    return CliPublishResult(
        id=response.id,
        slug=response.slug,
        visibility=response.visibility,
        url=response.url,
        readiness=_map_readiness(readiness_payload),
    )


def map_detached_publish_build_group(
    *,
    build_group: PublishBuildGroup,
    request_id: str,
) -> CliPublishResult:
    """Map one detached publish build-group payload into CLI domain shape."""
    return CliPublishResult(
        detached=True,
        slug=build_group.slug,
        version=build_group.version,
        status=build_group.status,
        phase=build_group.phase,
        current_step_message=build_group.current_step_message,
        active_runtime_profile=build_group.active_runtime_profile,
        publish_build_group_id=build_group.job_id,
        request_id=request_id,
    )


def map_registration_result(
    *,
    registration_result: dict[str, Any],
    slug: str,
    version: str,
    job_id: str,
    request_id: str,
) -> CliPublishResult:
    """Map terminal build-group registration payload into one CLI domain result."""
    published_asset_id = str(registration_result.get("id") or "").strip()
    published_url = str(registration_result.get("url") or "").strip()
    if not published_asset_id or not published_url:
        raise environment_error(
            "Publish build group completed without terminal registration result.",
            code="publish_registration_result_missing",
            request_id=request_id,
            extra={"job_id": job_id},
        )

    return CliPublishResult(
        id=published_asset_id,
        slug=str(registration_result.get("slug") or slug).strip() or slug,
        version=str(registration_result.get("version") or version).strip() or version,
        visibility=str(registration_result.get("visibility") or "private").strip() or "private",
        readiness=_map_readiness(registration_result.get("readiness")),
        url=published_url,
        publish_build_group_id=job_id,
        request_id=request_id,
    )
