"""Resolve publishable workers from root ``Agent.workers`` declarations."""

from __future__ import annotations

import json
import os
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from aimp_cli.core.errors import environment_error, usage_error
from aimp_cli.domain.constants import AGENT_ENTRYPOINT_RELATIVE_PATH


# Helper services that should be ignored during compose validation
HELPER_SERVICES = frozenset(
    {
        "redis",
        "postgres",
        "db",
        "database",
        "minio",
        "qdrant",
        "vector-db",
        "vectordb",
        "nginx",
        "proxy",
        "gateway",
        "api",
        "worker",
        "scheduler",
        "celery",
        "rabbitmq",
        "kafka",
        "zookeeper",
        "elasticsearch",
        "mongo",
        "mongodb",
        "mysql",
        "mariadb",
        "memcached",
        "prometheus",
        "grafana",
        "jaeger",
        "zipkin",
    }
)


@dataclass(frozen=True)
class PublishWorker:
    """One deployable worker declared by the root agent."""

    key: str
    path: Path
    class_name: str
    module: str
    module_origin: Path


def is_publishable_worker(path: Path) -> bool:
    """Return true when a directory has the explicit publishable worker markers."""
    return (
        path.is_dir()
        and (path / "Dockerfile").is_file()
        and (path / "pyproject.toml").is_file()
        and (path / "runtime").is_dir()
    )


def validate_publishable_worker(*, key: str, path: Path) -> None:
    """Validate one declared worker deployment path."""
    missing: list[str] = []
    if not (path / "Dockerfile").is_file():
        missing.append("Dockerfile")
    if not (path / "pyproject.toml").is_file():
        missing.append("pyproject.toml")
    if not (path / "runtime").is_dir():
        missing.append("runtime/")
    if missing:
        raise usage_error(
            (
                f"Declared worker '{key}' resolves to '{path}' but is missing "
                f"deployment markers: {', '.join(missing)}."
            ),
            code="worker_deployment_markers_missing",
            extra={"worker_key": key, "path": str(path), "missing": missing},
        )


def is_helper_service(service_name: str) -> bool:
    """Return True if the service name is a known helper service (not a worker)."""
    normalized = service_name.lower().replace("-", "").replace("_", "")
    # Check exact match
    if service_name.lower() in HELPER_SERVICES:
        return True
    # Check normalized match (e.g., "my-postgres" -> "mypostgres" won't match, but we
    # want to be conservative and only flag obvious helper services)
    return normalized in {h.replace("-", "").replace("_", "") for h in HELPER_SERVICES}


def _runtime_pythonpaths() -> list[str]:
    repo_python_root = Path(__file__).resolve().parents[4]
    source_paths: list[str] = []
    for candidate in (repo_python_root / "sdk", repo_python_root / "framework"):
        if candidate.exists():
            source_paths.append(str(candidate))
    if source_paths:
        return source_paths

    paths: list[str] = []
    for module_name in ("aimp_sdk", "aimp_framework"):
        try:
            module = __import__(module_name)
        except ModuleNotFoundError:
            continue
        module_file = getattr(module, "__file__", None)
        if not isinstance(module_file, str) or not module_file:
            continue
        module_path = Path(module_file).resolve().parent.parent
        candidate = str(module_path)
        if candidate not in paths:
            paths.append(candidate)
    return paths


def _build_workers_pythonpath(*, project_dir: Path, env: dict[str, str]) -> str:
    paths = [*_runtime_pythonpaths(), str(project_dir.resolve())]
    existing = env.get("PYTHONPATH")
    if existing:
        paths.append(existing)
    return os.pathsep.join(paths)


def _build_python_candidates(python_bin: str | None) -> list[str]:
    candidates: list[str] = []
    if python_bin:
        candidates.append(python_bin)
    candidates.append(sys.executable)
    deduped: list[str] = []
    for candidate in candidates:
        if candidate and candidate not in deduped:
            deduped.append(candidate)
    return deduped


def _load_declared_workers_payload(
    *,
    project_dir: Path,
    python_bin: str | None,
) -> dict[str, Any]:
    module_path = project_dir / AGENT_ENTRYPOINT_RELATIVE_PATH
    if not module_path.exists():
        raise usage_error(
            f"{AGENT_ENTRYPOINT_RELATIVE_PATH} not found. Run: ai init",
            code="agent_entrypoint_missing",
            extra={"project_dir": str(project_dir)},
        )

    env = os.environ.copy()
    env["PYTHONPATH"] = _build_workers_pythonpath(project_dir=project_dir, env=env)
    resolved_candidates = _build_python_candidates(python_bin)
    last_error: str | None = None
    for candidate in resolved_candidates:
        try:
            result = subprocess.run(
                [candidate, "-m", "aimp_sdk.workers", "--module", str(module_path)],
                cwd=project_dir,
                env=env,
                text=True,
                capture_output=True,
                timeout=30,
                check=False,
            )
        except FileNotFoundError:
            last_error = f"Python interpreter not found: {candidate}"
            continue
        except subprocess.TimeoutExpired as exc:
            raise environment_error(
                "Agent workers extraction timed out",
                code="workers_extraction_timeout",
                extra={"project_dir": str(project_dir)},
            ) from exc

        output = result.stdout.strip()
        if result.returncode != 0:
            try:
                payload = json.loads(output) if output else {}
            except json.JSONDecodeError:
                payload = {}
            error = str(payload.get("error") or result.stderr or output or "unknown error")
            last_error = error.strip()
            continue
        if not output:
            raise usage_error(
                "No workers output from Python",
                code="workers_extraction_failed",
            )
        try:
            payload = json.loads(output)
        except json.JSONDecodeError as exc:
            raise usage_error(
                f"Workers extraction returned invalid JSON: {exc}",
                code="workers_extraction_failed",
            ) from exc
        if not isinstance(payload, dict):
            raise usage_error(
                "Workers extraction returned a non-object payload",
                code="workers_extraction_failed",
            )
        return payload

    tried = ", ".join(resolved_candidates)
    if last_error:
        raise usage_error(
            f"{last_error} (python candidates tried: {tried})",
            code="workers_extraction_failed",
        )
    raise environment_error(
        "Python workers extraction failed",
        code="python_not_found",
        hint="Provide --python or activate the project virtual environment.",
    )


def load_agent_declared_workers(
    *,
    project_dir: Path,
    python_bin: str | None = None,
) -> list[PublishWorker]:
    """Load and validate workers declared by root ``agent.py``."""
    payload = _load_declared_workers_payload(project_dir=project_dir, python_bin=python_bin)
    raw_workers = payload.get("workers")
    if not isinstance(raw_workers, list) or not raw_workers:
        raise usage_error(
            "Root agent.py must declare at least one worker class in Agent.workers.",
            code="agent_workers_empty",
            extra={"project_dir": str(project_dir)},
        )

    workers: list[PublishWorker] = []
    seen_keys: set[str] = set()
    for raw_worker in raw_workers:
        if not isinstance(raw_worker, dict):
            raise usage_error(
                "Workers extraction returned an invalid worker entry.",
                code="workers_extraction_failed",
            )
        key = str(raw_worker.get("key") or "").strip()
        class_name = str(raw_worker.get("class_name") or "").strip()
        module = str(raw_worker.get("module") or "").strip()
        module_origin_raw = str(raw_worker.get("module_origin") or "").strip()
        project_path_raw = str(raw_worker.get("project_path") or "").strip()
        if not key:
            raise usage_error(
                "Declared worker is missing a resolved key.",
                code="worker_key_missing",
                extra={"class_name": class_name, "module": module},
            )
        if key in seen_keys:
            raise usage_error(
                f"Duplicate worker key '{key}' in Agent.workers.",
                code="duplicate_worker_key",
                extra={"worker_key": key},
            )
        seen_keys.add(key)
        if not module_origin_raw:
            raise usage_error(
                f"Declared worker '{key}' cannot be resolved to a local module origin.",
                code="worker_origin_missing",
                extra={"worker_key": key, "class_name": class_name, "module": module},
            )
        if not project_path_raw:
            raise usage_error(
                (
                    f"Declared worker '{key}' from '{module_origin_raw}' cannot be "
                    "resolved to a local project path containing Dockerfile, "
                    "pyproject.toml, and runtime/."
                ),
                code="worker_project_path_unresolved",
                extra={
                    "worker_key": key,
                    "class_name": class_name,
                    "module": module,
                    "module_origin": module_origin_raw,
                },
            )
        worker = PublishWorker(
            key=key,
            path=Path(project_path_raw).resolve(),
            class_name=class_name,
            module=module,
            module_origin=Path(module_origin_raw).resolve(),
        )
        validate_publishable_worker(key=worker.key, path=worker.path)
        workers.append(worker)
    return workers


def load_agent_workers(
    *,
    project_dir: Path,
    python_bin: str | None = None,
) -> list[dict[str, Any]]:
    """Load workers from root ``agent.py`` using SDK loader.

    Returns a list of worker dictionaries with keys:
    - key: worker key
    - class_name: worker class name
    - module: module path
    - module_origin: file path to module
    - project_path: resolved path to worker directory
    """
    payload = _load_declared_workers_payload(project_dir=project_dir, python_bin=python_bin)
    raw_workers = payload.get("workers")
    if not isinstance(raw_workers, list) or not raw_workers:
        return []

    workers: list[dict[str, Any]] = []
    seen_keys: set[str] = set()
    for raw_worker in raw_workers:
        if not isinstance(raw_worker, dict):
            continue
        key = str(raw_worker.get("key") or "").strip()
        if not key:
            continue
        if key in seen_keys:
            continue
        seen_keys.add(key)
        workers.append(raw_worker)
    return workers


def describe_agent_topology(
    project_dir: Path,
    *,
    python_bin: str | None = None,
) -> tuple[str, list[PublishWorker]]:
    """Return the publish topology and declared workers for a project.

    Note: This returns "agent" for the new Agent.workers architecture.
    """
    workers = load_agent_declared_workers(project_dir=project_dir, python_bin=python_bin)
    return "agent", workers


def validate_agent_compose(
    *,
    project_dir: Path,
    workers: list[PublishWorker] | None = None,
) -> None:
    """Validate optional local ``docker-compose.yml`` against declared workers.

    Validates that:
    - Root agent has a corresponding service in docker-compose.yml
    - All declared workers have corresponding services in docker-compose.yml
    - Helper services (redis, postgres, etc.) are ignored
    """
    compose_path = project_dir / "docker-compose.yml"
    if not compose_path.exists():
        return

    # Load workers if not provided
    if workers is None:
        workers = load_agent_declared_workers(project_dir=project_dir)

    try:
        payload = yaml.safe_load(compose_path.read_text(encoding="utf-8"))
    except yaml.YAMLError as exc:
        raise usage_error(
            f"docker-compose.yml is invalid YAML: {exc}",
            code="compose_invalid",
            extra={"compose_path": str(compose_path)},
        ) from exc
    if not isinstance(payload, dict):
        raise usage_error(
            "docker-compose.yml must define a mapping payload.",
            code="compose_invalid",
            extra={"compose_path": str(compose_path)},
        )
    services = payload.get("services")
    if not isinstance(services, dict):
        raise usage_error(
            "docker-compose.yml must define services.",
            code="compose_invalid",
            extra={"compose_path": str(compose_path)},
        )

    declared_keys = [worker.key for worker in workers]

    # Filter out helper services from the services dict
    worker_services = {
        name: config for name, config in services.items() if not is_helper_service(name)
    }

    # Check that root agent service exists (root is a deployable runtime)
    if "agent" not in worker_services:
        raise usage_error(
            "docker-compose.yml is missing root agent service. "
            "Add a service named 'agent' for the root agent runtime.",
            code="compose_root_agent_missing",
            extra={
                "compose_path": str(compose_path),
                "expected_service": "agent",
            },
        )

    # Check that all declared workers have services
    missing = [key for key in declared_keys if key not in worker_services]
    if missing:
        raise usage_error(
            ("docker-compose.yml is missing services for declared workers: " + ", ".join(missing)),
            code="compose_declared_workers_missing",
            extra={
                "compose_path": str(compose_path),
                "missing_worker_services": missing,
                "declared_worker_keys": declared_keys,
            },
        )


def validate_compose(
    *,
    project_dir: Path,
    python_bin: str | None = None,
) -> dict[str, Any]:
    """Validate docker-compose.yml against declared workers.

    Returns a validation result with keys:
    - valid: bool
    - declared_workers: list of worker keys declared in Agent.workers
    - compose_services: list of service names in docker-compose.yml
    - worker_services: list of service names that are workers (not helpers)
    - helper_services: list of detected helper service names
    - missing: list of declared workers without corresponding services
    """
    compose_path = project_dir / "docker-compose.yml"

    # Load workers from Agent.workers
    workers = load_agent_workers(project_dir=project_dir, python_bin=python_bin)
    declared_keys = [str(worker.get("key", "")) for worker in workers if worker.get("key")]

    if not compose_path.exists():
        return {
            "valid": len(declared_keys) == 0,
            "declared_workers": declared_keys,
            "compose_services": [],
            "worker_services": [],
            "helper_services": [],
            "missing": declared_keys,
            "error": "docker-compose.yml not found",
        }

    try:
        payload = yaml.safe_load(compose_path.read_text(encoding="utf-8"))
    except yaml.YAMLError as exc:
        return {
            "valid": False,
            "declared_workers": declared_keys,
            "compose_services": [],
            "worker_services": [],
            "helper_services": [],
            "missing": declared_keys,
            "error": f"Invalid YAML: {exc}",
        }

    if not isinstance(payload, dict):
        return {
            "valid": False,
            "declared_workers": declared_keys,
            "compose_services": [],
            "worker_services": [],
            "helper_services": [],
            "missing": declared_keys,
            "error": "docker-compose.yml must define a mapping payload",
        }

    services = payload.get("services")
    if not isinstance(services, dict):
        return {
            "valid": False,
            "declared_workers": declared_keys,
            "compose_services": [],
            "worker_services": [],
            "helper_services": [],
            "missing": declared_keys,
            "error": "docker-compose.yml must define services",
        }

    all_service_names = list(services.keys())
    helper_names = [name for name in all_service_names if is_helper_service(name)]
    worker_service_names = [name for name in all_service_names if not is_helper_service(name)]
    missing = [key for key in declared_keys if key not in worker_service_names]

    return {
        "valid": len(missing) == 0,
        "declared_workers": declared_keys,
        "compose_services": all_service_names,
        "worker_services": worker_service_names,
        "helper_services": helper_names,
        "missing": missing,
    }


def generate_compose(
    *,
    project_dir: Path,
    python_bin: str | None = None,
    version: str = "3.8",
) -> dict[str, Any]:
    """Generate docker-compose.yml content from Agent.workers declarations.

    Creates service entries for:
    - Root agent (build context: .)
    - Each worker (build context: workers/<key>/)
    """
    workers = load_agent_workers(project_dir=project_dir, python_bin=python_bin)

    services: dict[str, Any] = {
        # Root agent is a deployable runtime
        "agent": {
            "build": {
                "context": ".",
                "dockerfile": "Dockerfile",
            }
        }
    }

    for worker in workers:
        key = str(worker.get("key", ""))
        if not key:
            continue
        services[key] = {
            "build": {
                "context": f"workers/{key}",
                "dockerfile": "Dockerfile",
            }
        }

    return {
        "version": version,
        "services": services,
    }
