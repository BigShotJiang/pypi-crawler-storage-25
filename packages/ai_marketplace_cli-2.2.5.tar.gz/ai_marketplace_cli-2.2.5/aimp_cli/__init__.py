"""Python CLI for the AI Marketplace Platform."""

__all__ = ["__version__"]

__version__ = "2.2.5"
