"""Constrained MDX helpers for CLI Studio article authoring."""

from __future__ import annotations

import copy
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

ALLOWED_HEADING_LEVELS = {1, 2, 3, 4}
ALLOWED_MEDIA_WIDTH_VALUES = {"sm", "md", "full"}
ALLOWED_MEDIA_ALIGN_VALUES = {"left", "center", "right"}
VIDEO_EXTENSIONS = {".mp4", ".webm", ".mov", ".m4v", ".mkv"}

_IMAGE_LINE_RE = re.compile(r"^!\[(?P<alt>[^\]]*)\]\((?P<src>[^)]+)\)$")
_UNORDERED_ITEM_RE = re.compile(r"^[-*+]\s+(?P<text>.+)$")
_ORDERED_ITEM_RE = re.compile(r"^\d+\.\s+(?P<text>.+)$")
_LINK_RE = re.compile(r"\[(?P<label>[^\]]+)\]\((?P<href>[^)]+)\)")
_MEDIA_TAG_RE = re.compile(r"^<(?P<tag>Image|Video|YouTube)(?P<attrs>\s+.+?)?\s*/>$")
_ATTR_RE = re.compile(r'(?P<key>[A-Za-z_][A-Za-z0-9_-]*)="(?P<value>[^"]*)"')


@dataclass(frozen=True, slots=True)
class LocalStudioMediaReference:
    """A local media path referenced from constrained MDX."""

    source: str
    resolved_path: Path
    media_type: str


def default_studio_article_mdx() -> str:
    """Return the default constrained MDX article template."""
    return (
        "## Model Overview\n\n"
        "Describe what your model does in plain language.\n\n"
        "## Inputs\n\n"
        "- Supported inputs: text\n\n"
        "## Outputs\n\n"
        "- Supported outputs: text\n\n"
        "Explain the response shape and any important fields.\n\n"
        "## Notes\n\n"
        "- Keep examples short and practical.\n"
        "- Use HTTPS links for external references.\n"
        "- Use `<Image />`, `<Video />`, and `<YouTube />` tags for rich media.\n"
    )


def parse_constrained_mdx(source: str) -> dict[str, Any]:
    """Parse constrained MDX into canonical Studio Tiptap JSON."""
    if not isinstance(source, str) or not source.strip():
        raise RuntimeError("studio.article_mdx_file must contain non-empty MDX")

    warnings: list[str] = []
    nodes: list[dict[str, Any]] = []
    lines = source.splitlines()
    index = 0
    in_code_block = False
    code_lines: list[str] = []

    while index < len(lines):
        raw_line = lines[index]
        line = raw_line.rstrip("\n")
        stripped = line.strip()

        if in_code_block:
            if stripped.startswith("```"):
                nodes.append(
                    {
                        "type": "codeBlock",
                        "content": [{"type": "text", "text": "\n".join(code_lines)}],
                    }
                )
                in_code_block = False
                code_lines = []
            else:
                code_lines.append(line)
            index += 1
            continue

        if stripped.startswith("```"):
            in_code_block = True
            code_lines = []
            index += 1
            continue

        if stripped.startswith("import ") or stripped.startswith("export "):
            raise RuntimeError("Constrained MDX does not allow import/export statements")
        if "{" in stripped or "}" in stripped:
            raise RuntimeError("Constrained MDX does not allow JSX expressions")

        if not stripped:
            index += 1
            continue

        media_node = _parse_media_tag_line(stripped)
        if media_node is not None:
            nodes.append(media_node)
            index += 1
            continue
        if stripped.startswith("<"):
            raise RuntimeError(f"Unsupported MDX tag: {stripped}")

        if "|" in stripped and index + 1 < len(lines) and "---" in lines[index + 1]:
            warnings.append("Markdown table is not supported; converted to paragraph text.")
            nodes.append(_paragraph_from_lines([line]))
            index += 1
            continue

        if _is_horizontal_rule(stripped):
            nodes.append({"type": "horizontalRule"})
            index += 1
            continue

        image_match = _IMAGE_LINE_RE.match(stripped)
        if image_match:
            nodes.append(
                {
                    "type": "image",
                    "attrs": {
                        "src": image_match.group("src").strip(),
                        "alt": image_match.group("alt").strip(),
                    },
                }
            )
            index += 1
            continue

        if stripped.startswith(("http://", "https://")):
            if _is_youtube_url(stripped):
                nodes.append({"type": "youtube", "attrs": {"src": stripped}})
            elif _is_video_url(stripped):
                nodes.append({"type": "video", "attrs": {"src": stripped}})
            else:
                nodes.append(
                    {
                        "type": "paragraph",
                        "content": [
                            {
                                "type": "text",
                                "text": stripped,
                                "marks": [{"type": "link", "attrs": {"href": stripped}}],
                            }
                        ],
                    }
                )
            index += 1
            continue

        if stripped.startswith(">"):
            quote_lines: list[str] = []
            while index < len(lines):
                maybe_quote = lines[index].strip()
                if not maybe_quote.startswith(">"):
                    break
                quote_lines.append(maybe_quote[1:].lstrip())
                index += 1
            nodes.append({"type": "blockquote", "content": [_paragraph_from_lines(quote_lines)]})
            continue

        unordered_items: list[str] = []
        while index < len(lines):
            maybe_item = _UNORDERED_ITEM_RE.match(lines[index].strip())
            if not maybe_item:
                break
            unordered_items.append(maybe_item.group("text"))
            index += 1
        if unordered_items:
            nodes.append(
                {
                    "type": "bulletList",
                    "content": [
                        {"type": "listItem", "content": [_paragraph_from_lines([item])]}
                        for item in unordered_items
                    ],
                }
            )
            continue

        ordered_items: list[str] = []
        while index < len(lines):
            maybe_item = _ORDERED_ITEM_RE.match(lines[index].strip())
            if not maybe_item:
                break
            ordered_items.append(maybe_item.group("text"))
            index += 1
        if ordered_items:
            nodes.append(
                {
                    "type": "orderedList",
                    "content": [
                        {"type": "listItem", "content": [_paragraph_from_lines([item])]}
                        for item in ordered_items
                    ],
                }
            )
            continue

        heading_level = 0
        while heading_level < len(stripped) and stripped[heading_level] == "#":
            heading_level += 1
        if heading_level > 0 and heading_level < len(stripped) and stripped[heading_level] == " ":
            heading_text = stripped[heading_level + 1 :].strip()
            if heading_level not in ALLOWED_HEADING_LEVELS:
                raise RuntimeError("Constrained MDX headings must use #, ##, ###, or #### only")
            nodes.append(
                {
                    "type": "heading",
                    "attrs": {"level": heading_level},
                    "content": _parse_inline_text(heading_text),
                }
            )
            index += 1
            continue

        paragraph_lines = [line]
        index += 1
        while index < len(lines):
            nxt = lines[index].strip()
            if not nxt:
                break
            if nxt.startswith(("```", ">", "<")):
                break
            if _UNORDERED_ITEM_RE.match(nxt) or _ORDERED_ITEM_RE.match(nxt):
                break
            if nxt.startswith(("http://", "https://")):
                break
            if _is_horizontal_rule(nxt) or _IMAGE_LINE_RE.match(nxt):
                break
            heading_probe = 0
            while heading_probe < len(nxt) and nxt[heading_probe] == "#":
                heading_probe += 1
            if heading_probe > 0 and heading_probe < len(nxt) and nxt[heading_probe] == " ":
                break
            paragraph_lines.append(lines[index])
            index += 1

        nodes.append(_paragraph_from_lines(paragraph_lines))

    if in_code_block:
        nodes.append(
            {
                "type": "codeBlock",
                "content": [{"type": "text", "text": "\n".join(code_lines)}],
            }
        )

    return {
        "format": "tiptap-json",
        "schema_version": 1,
        "content": {"type": "doc", "content": nodes},
        "import_warnings": warnings,
    }


def collect_local_media_references(
    article_payload: dict[str, Any],
    *,
    article_path: Path,
) -> list[LocalStudioMediaReference]:
    """Collect local media references from article JSON."""
    content = article_payload.get("content")
    if not isinstance(content, dict):
        return []
    references: dict[tuple[str, str], LocalStudioMediaReference] = {}

    def visit(node: Any) -> None:
        if isinstance(node, list):
            for item in node:
                visit(item)
            return
        if not isinstance(node, dict):
            return
        node_type = str(node.get("type") or "")
        attrs = node.get("attrs")
        if node_type in {"image", "video"} and isinstance(attrs, dict):
            src = attrs.get("src")
            if isinstance(src, str) and src and not _is_remote_url(src):
                resolved = (article_path.parent / src).expanduser().resolve()
                media_type = "image" if node_type == "image" else "video"
                references[(src, node_type)] = LocalStudioMediaReference(
                    source=src,
                    resolved_path=resolved,
                    media_type=media_type,
                )
        for value in node.values():
            visit(value)

    visit(content)
    return list(references.values())


def replace_media_sources(
    article_payload: dict[str, Any],
    replacements: dict[str, str],
) -> dict[str, Any]:
    """Replace local media sources with uploaded public URLs."""
    article_clone = copy.deepcopy(article_payload)

    def visit(node: Any) -> None:
        if isinstance(node, list):
            for item in node:
                visit(item)
            return
        if not isinstance(node, dict):
            return
        attrs = node.get("attrs")
        if isinstance(attrs, dict):
            src = attrs.get("src")
            if isinstance(src, str) and src in replacements:
                attrs["src"] = replacements[src]
        for value in node.values():
            visit(value)

    visit(article_clone.get("content"))
    return article_clone


def tiptap_to_constrained_mdx(article_payload: dict[str, Any]) -> str:
    """Serialize canonical Studio article JSON into constrained MDX."""
    if not isinstance(article_payload, dict):
        return default_studio_article_mdx()
    content = article_payload.get("content")
    if not isinstance(content, dict):
        return default_studio_article_mdx()
    nodes = content.get("content")
    if not isinstance(nodes, list):
        return default_studio_article_mdx()

    rendered: list[str] = []
    for node in nodes:
        block = _render_block(node)
        if block:
            rendered.append(block)
    return "\n\n".join(rendered).strip() + "\n"


def _parse_media_tag_line(line: str) -> dict[str, Any] | None:
    match = _MEDIA_TAG_RE.match(line)
    if not match:
        return None
    tag = match.group("tag")
    attrs_text = match.group("attrs") or ""
    attrs: dict[str, str] = {}
    for attr_match in _ATTR_RE.finditer(attrs_text):
        attrs[attr_match.group("key")] = attr_match.group("value")
    if "src" not in attrs or not attrs["src"].strip():
        raise RuntimeError(f"{tag} tag requires a non-empty src attribute")
    src = attrs["src"].strip()
    if tag == "YouTube":
        return {"type": "youtube", "attrs": {"src": src}}
    node_type = "image" if tag == "Image" else "video"
    node_attrs: dict[str, Any] = {"src": src}
    if tag == "Image" and attrs.get("alt"):
        node_attrs["alt"] = attrs["alt"].strip()
    if attrs.get("caption"):
        node_attrs["caption"] = attrs["caption"].strip()
    if attrs.get("width"):
        width = attrs["width"].strip()
        if width not in ALLOWED_MEDIA_WIDTH_VALUES:
            raise RuntimeError(f"{tag} width must be one of: sm, md, full")
        node_attrs["width"] = width
    if attrs.get("align"):
        align = attrs["align"].strip()
        if align not in ALLOWED_MEDIA_ALIGN_VALUES:
            raise RuntimeError(f"{tag} align must be one of: left, center, right")
        node_attrs["align"] = align
    return {"type": node_type, "attrs": node_attrs}


def _make_text_node(text: str) -> dict[str, Any]:
    return {"type": "text", "text": text}


def _parse_inline_text(line: str) -> list[dict[str, Any]]:
    if not line:
        return []
    nodes: list[dict[str, Any]] = []
    last = 0
    for match in _LINK_RE.finditer(line):
        start, end = match.span()
        if start > last:
            nodes.append(_make_text_node(line[last:start]))
        nodes.append(
            {
                "type": "text",
                "text": match.group("label"),
                "marks": [{"type": "link", "attrs": {"href": match.group("href").strip()}}],
            }
        )
        last = end
    if last < len(line):
        nodes.append(_make_text_node(line[last:]))
    return nodes or [_make_text_node(line)]


def _paragraph_from_lines(lines: list[str]) -> dict[str, Any]:
    content: list[dict[str, Any]] = []
    for index, line in enumerate(lines):
        content.extend(_parse_inline_text(line))
        if index < len(lines) - 1:
            content.append({"type": "hardBreak"})
    return {"type": "paragraph", "content": content}


def _is_horizontal_rule(line: str) -> bool:
    stripped = line.strip().replace(" ", "")
    return stripped in {"---", "***", "___"}


def _is_youtube_url(url: str) -> bool:
    host = (urlparse(url).hostname or "").lower()
    return host in {"youtube.com", "www.youtube.com", "youtu.be", "m.youtube.com"}


def _is_video_url(url: str) -> bool:
    path = (urlparse(url).path or "").lower()
    return any(path.endswith(ext) for ext in VIDEO_EXTENSIONS)


def _is_remote_url(value: str) -> bool:
    parsed = urlparse(value)
    return parsed.scheme in {"http", "https"}


def _render_block(node: Any) -> str:
    if not isinstance(node, dict):
        return ""
    node_type = node.get("type")
    if node_type == "heading":
        level = int((node.get("attrs") or {}).get("level", 2))
        level = level if level in ALLOWED_HEADING_LEVELS else 2
        return f"{'#' * level} {_render_inline_nodes(node.get('content'))}".strip()
    if node_type == "paragraph":
        return _render_inline_nodes(node.get("content"))
    if node_type == "blockquote":
        parts = []
        for child in node.get("content") or []:
            rendered = _render_block(child)
            if rendered:
                for line in rendered.splitlines():
                    parts.append(f"> {line}")
        return "\n".join(parts)
    if node_type == "bulletList":
        return "\n".join(_render_list_items(node.get("content"), ordered=False))
    if node_type == "orderedList":
        return "\n".join(_render_list_items(node.get("content"), ordered=True))
    if node_type == "codeBlock":
        return f"```\n{_extract_code_text(node)}\n```"
    if node_type == "horizontalRule":
        return "---"
    if node_type == "image":
        return _render_media_tag("Image", node)
    if node_type == "video":
        return _render_media_tag("Video", node)
    if node_type == "youtube":
        src = str((node.get("attrs") or {}).get("src") or "").strip()
        if not src:
            return ""
        return f'<YouTube src="{_escape_attr(src)}" />'
    return ""


def _render_list_items(items: Any, *, ordered: bool) -> list[str]:
    if not isinstance(items, list):
        return []
    rendered: list[str] = []
    for index, item in enumerate(items, start=1):
        if not isinstance(item, dict):
            continue
        content = item.get("content") or []
        text = ""
        if isinstance(content, list) and content:
            text = _render_block(content[0]).strip()
        prefix = f"{index}. " if ordered else "- "
        if text:
            rendered.append(prefix + text)
    return rendered


def _render_inline_nodes(nodes: Any) -> str:
    if not isinstance(nodes, list):
        return ""
    parts: list[str] = []
    for node in nodes:
        if not isinstance(node, dict):
            continue
        if node.get("type") == "hardBreak":
            parts.append("  \n")
            continue
        if node.get("type") != "text":
            continue
        text = str(node.get("text") or "")
        for mark in node.get("marks") or []:
            if not isinstance(mark, dict):
                continue
            mark_type = mark.get("type")
            if mark_type == "link":
                href = str((mark.get("attrs") or {}).get("href") or "").strip()
                if href:
                    text = f"[{text}]({href})"
            elif mark_type == "bold":
                text = f"**{text}**"
            elif mark_type == "italic":
                text = f"*{text}*"
            elif mark_type == "strike":
                text = f"~~{text}~~"
            elif mark_type == "code":
                text = f"`{text}`"
        parts.append(text)
    return "".join(parts).strip()


def _extract_code_text(node: dict[str, Any]) -> str:
    content = node.get("content")
    if not isinstance(content, list):
        return ""
    parts: list[str] = []
    for child in content:
        if isinstance(child, dict) and child.get("type") == "text":
            parts.append(str(child.get("text") or ""))
    return "".join(parts)


def _render_media_tag(tag: str, node: dict[str, Any]) -> str:
    attrs = node.get("attrs") or {}
    src = str(attrs.get("src") or "").strip()
    if not src:
        return ""
    parts = [f'src="{_escape_attr(src)}"']
    if tag == "Image" and attrs.get("alt"):
        parts.append(f'alt="{_escape_attr(str(attrs["alt"]))}"')
    if attrs.get("caption"):
        parts.append(f'caption="{_escape_attr(str(attrs["caption"]))}"')
    if attrs.get("width") in ALLOWED_MEDIA_WIDTH_VALUES:
        parts.append(f'width="{attrs["width"]}"')
    if attrs.get("align") in ALLOWED_MEDIA_ALIGN_VALUES:
        parts.append(f'align="{attrs["align"]}"')
    return f"<{tag} {' '.join(parts)} />"


def _escape_attr(value: str) -> str:
    return value.replace("&", "&amp;").replace('"', "&quot;")
