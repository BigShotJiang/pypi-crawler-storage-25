"""Gateway API and upload clients for the Python CLI."""

from __future__ import annotations

import concurrent.futures
import hashlib
import os
import threading
import time
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import Any, cast
from urllib.parse import quote, urlparse

import httpx
from pydantic import BaseModel

from aimp_cli.core.config import CommandContext
from aimp_cli.core.errors import (
    CliError,
    cli_error_from_http_status,
    environment_error,
    internal_error,
    network_error,
    usage_error,
)
from aimp_cli.domain.models import (
    AgentPublishRequest,
    AgentPublishResult,
    ArtifactType,
    AuthContext,
    AuthResponse,
    FineTuneJobListResponse,
    FineTuneJobResponse,
    JobCancelResponse,
    ModelLookupResponse,
    ModelSecretListResponse,
    ModelSecretMetadata,
    PartCompletionInfo,
    PublishBuildGroup,
    PublishBuildGroupCreateRequest,
    PublishBuildGroupListResponse,
    PublishMetadataResponse,
    PublishRequest,
    PublishResponse,
    StudioModelDetailResponse,
    UploadAbortRequest,
    UploadCompleteRequest,
    UploadCompleteResponse,
    UploadInitRequest,
    UploadInitResponse,
)
from aimp_cli.generated.gateway_contracts import PublishRequest as GatewayPublishRequest

READ_ONLY_RETRY_ATTEMPTS = 3
READ_ONLY_RETRY_DELAY_MS = 0.5
RETRYABLE_HTTP_STATUS_CODES = {502, 503, 504}
RETRYABLE_ERROR_CODES = {"ECONNABORTED", "ECONNREFUSED", "ECONNRESET", "ETIMEDOUT"}

_STUDIO_MEDIA_GATEWAY_TIMEOUT_ENV = "AIMP_STUDIO_MEDIA_UPLOAD_GATEWAY_TIMEOUT_SECONDS"
_DEFAULT_STUDIO_MEDIA_GATEWAY_TIMEOUT_SECONDS = 60.0
_PUBLISH_REGISTRATION_FAILED_CODE = "publish_registration_failed"
_PUBLISH_REGISTRATION_STEP_MESSAGE = "Final publish registration failed"


def _studio_media_upload_gateway_timeout_seconds() -> float:
    """Return HTTP timeout for Studio media upload init/complete Gateway calls."""
    raw = os.environ.get(_STUDIO_MEDIA_GATEWAY_TIMEOUT_ENV, "").strip()
    if raw:
        try:
            parsed = float(raw)
            if parsed >= 1.0:
                return parsed
        except ValueError:
            pass
    return _DEFAULT_STUDIO_MEDIA_GATEWAY_TIMEOUT_SECONDS


def _looks_like_html_error_response(*, text: str, content_type: str) -> bool:
    """Return whether one error response appears to be HTML markup."""
    normalized_type = content_type.lower()
    if "text/html" in normalized_type:
        return True
    normalized_text = text.lstrip().lower()
    return normalized_text.startswith("<!doctype html") or normalized_text.startswith("<html")


def _publish_registration_upload_failure_extra(
    *,
    upload_phase: str,
    upstream_code: str | None = None,
    extra: Any = None,
) -> dict[str, Any]:
    """Build canonical publish-registration details for Studio upload failures."""
    merged: dict[str, Any] = {}
    if isinstance(extra, dict):
        merged.update(extra)
    merged["reason"] = "studio_media_upload"
    merged["stage"] = "registration"
    merged["upload_phase"] = upload_phase
    merged["current_step_message"] = _PUBLISH_REGISTRATION_STEP_MESSAGE
    normalized_upstream = str(upstream_code or "").strip()
    if normalized_upstream and normalized_upstream != _PUBLISH_REGISTRATION_FAILED_CODE:
        merged["upstream_code"] = normalized_upstream
    return merged


class UploadProgress(BaseModel):
    """Upload progress payload."""

    part_number: int
    total_parts: int
    bytes_uploaded: int
    total_bytes: int
    percent_complete: int
    active_uploads: int


class UploadResult(BaseModel):
    """Upload result payload."""

    storage_uri: str
    artifact_id: str
    size_bytes: int


class GatewayClient:
    """HTTP client for Gateway and studio-facing endpoints."""

    def __init__(
        self,
        auth: AuthContext,
        context: CommandContext,
        *,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        self.auth = auth
        self.context = context
        headers = {
            "Content-Type": "application/json",
            "X-Request-ID": context.request_id,
        }
        if auth.api_key:
            headers["X-API-Key"] = auth.api_key
        self.client = httpx.Client(
            base_url=auth.gateway_url,
            timeout=30.0,
            headers=headers,
            transport=transport,
        )

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self.client.close()

    def _sleep(self, seconds: float) -> None:
        time.sleep(seconds)

    def _is_local_gateway(self) -> bool:
        parsed = urlparse(str(self.client.base_url))
        return parsed.hostname in {"localhost", "127.0.0.1", "::1"}

    def _is_retryable_error(self, error: httpx.HTTPError) -> bool:
        if isinstance(error, httpx.HTTPStatusError):
            return error.response.status_code in RETRYABLE_HTTP_STATUS_CODES
        request_error = getattr(error, "request", None)
        _ = request_error
        return isinstance(
            error,
            (
                httpx.ConnectError,
                httpx.ConnectTimeout,
                httpx.ReadTimeout,
                httpx.RemoteProtocolError,
            ),
        )

    def _extract_gateway_detail(self, response: httpx.Response) -> dict[str, Any]:
        if not response.is_stream_consumed:
            response.read()
        content_type = response.headers.get("content-type", "")
        try:
            payload = response.json()
        except ValueError:
            text = response.text.strip()
            if _looks_like_html_error_response(text=text, content_type=content_type):
                return {
                    "code": "invalid_gateway_error_response",
                    "message": "Gateway returned a non-JSON error response",
                    "extra": {"content_type": content_type or None},
                }
            return {"message": text or None}
        if isinstance(payload, dict):
            detail = payload.get("detail")
            if isinstance(detail, dict):
                message = detail.get("message")
                extra: dict[str, Any] = {}
                nested_details = detail.get("details")
                if isinstance(nested_details, dict):
                    extra.update(nested_details)
                extra.update(
                    {
                        key: value
                        for key, value in detail.items()
                        if key
                        not in {
                            "code",
                            "message",
                            "hint",
                            "retryable",
                            "details",
                        }
                    }
                )
                return {
                    "code": detail.get("code"),
                    "message": message if isinstance(message, str) and message.strip() else None,
                    "hint": detail.get("hint") if isinstance(detail.get("hint"), str) else None,
                    "retryable": _bool_or_none(detail.get("retryable")),
                    "extra": extra,
                }
            if isinstance(detail, str) and detail.strip():
                return {"message": detail}
            error_payload = payload.get("error")
            if isinstance(error_payload, dict):
                message = error_payload.get("message")
                details = error_payload.get("details")
                extra: dict[str, Any] = dict(details) if isinstance(details, dict) else {}
                gateway_rid = error_payload.get("request_id")
                if isinstance(gateway_rid, str) and gateway_rid.strip():
                    extra.setdefault("gateway_request_id", gateway_rid.strip())
                return {
                    "code": (
                        error_payload.get("code")
                        if isinstance(error_payload.get("code"), str)
                        else None
                    ),
                    "message": message if isinstance(message, str) and message.strip() else None,
                    "extra": extra,
                }
            error_message = payload.get("error")
            message = payload.get("message")
            if isinstance(message, str) and message.strip():
                return {
                    "message": message,
                    "code": error_message if isinstance(error_message, str) else None,
                }
            if isinstance(error_message, str) and error_message.strip():
                return {"message": error_message, "code": error_message}
        return {}

    def _build_read_only_gateway_error(
        self,
        operation: str,
        error: httpx.HTTPError,
    ) -> CliError:
        prefix = f"{operation} failed"
        if isinstance(error, httpx.HTTPStatusError):
            detail = self._extract_gateway_detail(error.response)
            message = detail.get("message") or (
                f"{prefix}: gateway returned {error.response.status_code} "
                f"at {self.auth.gateway_url}"
            )
            return cli_error_from_http_status(
                status_code=error.response.status_code,
                message=str(message),
                request_id=self.context.request_id,
                code=detail.get("code"),
                hint=detail.get("hint"),
                retryable=detail.get("retryable"),
                extra=detail.get("extra"),
            )
        if self._is_local_gateway():
            return network_error(
                (
                    f"{prefix}: local gateway/tunnel connectivity problem at "
                    f"{self.auth.gateway_url}. Original error: {error}"
                ),
                code="gateway_unreachable",
                request_id=self.context.request_id,
                hint="Check the local gateway URL or SSH tunnel and retry.",
            )
        return network_error(
            f"{prefix}: gateway unreachable at {self.auth.gateway_url}. Original error: {error}",
            code="gateway_unreachable",
            request_id=self.context.request_id,
            hint="Check network connectivity to the Gateway and retry.",
        )

    def _execute_read_only(
        self,
        operation: str,
        request_fn: Callable[[], httpx.Response],
    ) -> httpx.Response:
        attempt = 0
        while True:
            attempt += 1
            try:
                response = request_fn()
                response.raise_for_status()
                return response
            except httpx.HTTPError as error:
                if not self._is_retryable_error(error) or attempt >= READ_ONLY_RETRY_ATTEMPTS:
                    raise self._build_read_only_gateway_error(operation, error) from error
                self._sleep(READ_ONLY_RETRY_DELAY_MS)
        raise network_error(
            f"{operation} failed unexpectedly",
            code="service_unavailable",
            request_id=self.context.request_id,
        )

    def _raise_invalid_execution_payload(
        self,
        *,
        expected: str,
        payload: dict[str, Any],
        reason: str,
    ) -> None:
        raise internal_error(
            "Gateway returned an invalid execution payload.",
            code="gateway_execution_payload_invalid",
            request_id=self.context.request_id,
            extra={
                "expected": expected,
                "reason": reason,
                "keys": sorted(payload.keys()),
            },
        )

    def _coerce_timeline(self, value: Any) -> list[dict[str, Any]]:
        if not isinstance(value, list):
            return []
        return [item for item in value if isinstance(item, dict)]

    def _coerce_string_or_none(self, value: Any) -> str | None:
        if not isinstance(value, str):
            return None
        normalized = value.strip()
        return normalized or None

    def _coerce_logs(self, value: Any) -> list[dict[str, Any]]:
        if not isinstance(value, list):
            return []
        return [log for log in value if isinstance(log, dict)]

    def _normalize_publish_build_execution(
        self,
        execution: dict[str, Any],
    ) -> dict[str, Any]:
        execution_type = self._coerce_string_or_none(execution.get("type"))
        if execution_type and execution_type != "publish-build":
            self._raise_invalid_execution_payload(
                expected="publish-build",
                payload=execution,
                reason="unexpected_type",
            )

        details = execution.get("details")
        details_payload = details if isinstance(details, dict) else {}

        job_id = self._coerce_string_or_none(
            execution.get("job_id")
        ) or self._coerce_string_or_none(execution.get("id"))
        slug = self._coerce_string_or_none(execution.get("slug")) or self._coerce_string_or_none(
            execution.get("model_slug")
        )
        version = self._coerce_string_or_none(
            execution.get("version")
        ) or self._coerce_string_or_none(details_payload.get("version"))
        status = self._coerce_string_or_none(execution.get("status"))

        if not job_id or not slug or not version or not status:
            self._raise_invalid_execution_payload(
                expected="publish-build",
                payload=execution,
                reason="missing_required_fields",
            )
        normalized_child_jobs = self._normalize_publish_build_child_jobs(
            execution=execution,
            details_payload=details_payload,
        )
        release_artifact_descriptor = (
            execution.get("result_artifact_descriptor")
            if isinstance(execution.get("result_artifact_descriptor"), dict)
            else (
                details_payload.get("release_artifact")
                if isinstance(details_payload.get("release_artifact"), dict)
                else {}
            )
        )
        release_artifact_uri = self._coerce_string_or_none(
            execution.get("result_artifact_uri")
        ) or self._coerce_string_or_none(release_artifact_descriptor.get("uri"))

        return {
            "job_id": job_id,
            "job_type": self._coerce_string_or_none(execution.get("job_type")) or "build",
            "slug": slug,
            "version": version,
            "stage": self._coerce_string_or_none(execution.get("stage")),
            "phase": self._coerce_string_or_none(execution.get("phase")),
            "status": status,
            "timeline": self._coerce_timeline(execution.get("timeline")),
            "logs": self._coerce_logs(execution.get("logs")),
            "error_code": self._coerce_string_or_none(execution.get("error_code")),
            "error_message": self._coerce_string_or_none(execution.get("error_message")),
            "current_step_message": self._coerce_string_or_none(
                execution.get("current_step_message")
            ),
            "active_runtime_profile": self._coerce_string_or_none(
                execution.get("active_runtime_profile")
            )
            or self._coerce_string_or_none(details_payload.get("active_runtime_profile")),
            "requested_profiles": execution.get("requested_profiles")
            if isinstance(execution.get("requested_profiles"), list)
            else (
                details_payload.get("requested_profiles")
                if isinstance(details_payload.get("requested_profiles"), list)
                else []
            ),
            "successful_runtime_profiles": execution.get("successful_runtime_profiles")
            if isinstance(execution.get("successful_runtime_profiles"), list)
            else (
                details_payload.get("successful_runtime_profiles")
                if isinstance(details_payload.get("successful_runtime_profiles"), list)
                else []
            ),
            "result_artifact_uri": release_artifact_uri,
            "result_artifact_descriptor": release_artifact_descriptor,
            "registration_result": execution.get("registration_result")
            if isinstance(execution.get("registration_result"), dict)
            else (
                details_payload.get("publish_result")
                if isinstance(details_payload.get("publish_result"), dict)
                else {}
            ),
            "child_jobs": normalized_child_jobs,
            "created_at": self._coerce_string_or_none(execution.get("created_at")),
            "started_at": self._coerce_string_or_none(execution.get("started_at")),
            "finished_at": self._coerce_string_or_none(execution.get("finished_at")),
        }

    def _normalize_publish_build_child_jobs(
        self,
        *,
        execution: dict[str, Any],
        details_payload: dict[str, Any],
    ) -> list[dict[str, Any]]:
        if isinstance(details_payload.get("child_jobs"), list):
            raw_child_jobs = details_payload["child_jobs"]
        elif isinstance(execution.get("child_jobs"), list):
            raw_child_jobs = execution["child_jobs"]
        else:
            return []

        normalized_child_jobs: list[dict[str, Any]] = []
        for index, child_payload in enumerate(raw_child_jobs):
            if not isinstance(child_payload, dict):
                self._raise_invalid_execution_payload(
                    expected="publish-build-child",
                    payload=execution,
                    reason=f"child_jobs[{index}]_must_be_object",
                )
            normalized_child_jobs.append(
                self._normalize_publish_build_child_job(child_payload, index=index)
            )
        return normalized_child_jobs

    def _normalize_publish_build_child_job(
        self,
        payload: dict[str, Any],
        *,
        index: int,
    ) -> dict[str, Any]:
        details = payload.get("details")
        details_payload = details if isinstance(details, dict) else {}

        job_id = self._coerce_string_or_none(payload.get("job_id")) or self._coerce_string_or_none(
            payload.get("id")
        )
        slug = self._coerce_string_or_none(payload.get("slug")) or self._coerce_string_or_none(
            payload.get("model_slug")
        )
        version = self._coerce_string_or_none(
            payload.get("version")
        ) or self._coerce_string_or_none(details_payload.get("version"))
        status = self._coerce_string_or_none(payload.get("status"))
        if not job_id or not slug or not version or not status:
            self._raise_invalid_execution_payload(
                expected="publish-build-child",
                payload=payload,
                reason=f"child_jobs[{index}]_missing_required_fields",
            )

        return {
            "job_id": job_id,
            "job_type": self._coerce_string_or_none(payload.get("job_type")),
            "slug": slug,
            "version": version,
            "runtime_profile": self._coerce_string_or_none(payload.get("runtime_profile"))
            or self._coerce_string_or_none(details_payload.get("runtime_profile")),
            "stage": self._coerce_string_or_none(payload.get("stage")),
            "phase": self._coerce_string_or_none(payload.get("phase")),
            "status": status,
            "timeline": self._coerce_timeline(payload.get("timeline")),
            "error_code": self._coerce_string_or_none(payload.get("error_code")),
            "error_message": self._coerce_string_or_none(payload.get("error_message")),
            "logs": self._coerce_logs(payload.get("logs")),
            "current_step_message": self._coerce_string_or_none(
                payload.get("current_step_message")
            ),
            "lease_expires_at": self._coerce_string_or_none(payload.get("lease_expires_at")),
            "last_heartbeat_at": self._coerce_string_or_none(payload.get("last_heartbeat_at")),
            "last_progress_at": self._coerce_string_or_none(payload.get("last_progress_at")),
            "created_at": self._coerce_string_or_none(payload.get("created_at")),
            "started_at": self._coerce_string_or_none(payload.get("started_at")),
            "finished_at": self._coerce_string_or_none(payload.get("finished_at")),
            "cache_ref": self._coerce_string_or_none(payload.get("cache_ref")),
            "cache_imported": _bool_or_none(payload.get("cache_imported")),
            "cache_exported": _bool_or_none(payload.get("cache_exported")),
        }

    def _extract_publish_build_group_create_job(self, payload: dict[str, Any]) -> dict[str, Any]:
        job_payload = payload.get("job")
        if not isinstance(job_payload, dict):
            self._raise_invalid_execution_payload(
                expected="publish-build-create",
                payload=payload,
                reason="job_must_be_object",
            )
        return job_payload

    def _normalize_fine_tune_execution(self, execution: dict[str, Any]) -> dict[str, Any]:
        execution_type = self._coerce_string_or_none(execution.get("type"))
        if execution_type and execution_type != "fine-tune":
            self._raise_invalid_execution_payload(
                expected="fine-tune",
                payload=execution,
                reason="unexpected_type",
            )

        details = execution.get("details")
        details_payload = details if isinstance(details, dict) else {}

        job_id = self._coerce_string_or_none(
            execution.get("job_id")
        ) or self._coerce_string_or_none(execution.get("id"))
        model_slug = self._coerce_string_or_none(
            execution.get("model_slug")
        ) or self._coerce_string_or_none(execution.get("slug"))
        status = self._coerce_string_or_none(execution.get("status"))

        if not job_id or not model_slug or not status:
            self._raise_invalid_execution_payload(
                expected="fine-tune",
                payload=execution,
                reason="missing_required_fields",
            )

        return {
            "job_id": job_id,
            "model_slug": model_slug,
            "status": status,
            "created_at": self._coerce_string_or_none(execution.get("created_at")),
            "started_at": self._coerce_string_or_none(execution.get("started_at")),
            "finished_at": self._coerce_string_or_none(execution.get("finished_at")),
            "output_asset_id": self._coerce_string_or_none(execution.get("output_asset_id"))
            or self._coerce_string_or_none(details_payload.get("output_asset_id")),
            "output_asset_slug": self._coerce_string_or_none(execution.get("output_asset_slug"))
            or self._coerce_string_or_none(details_payload.get("output_asset_slug")),
            "output_kind": self._coerce_string_or_none(execution.get("output_kind"))
            or self._coerce_string_or_none(details_payload.get("output_kind")),
            "adapter_format": self._coerce_string_or_none(execution.get("adapter_format"))
            or self._coerce_string_or_none(details_payload.get("adapter_format"))
            or "lora",
            "timeline": self._coerce_timeline(execution.get("timeline")),
            "error_code": self._coerce_string_or_none(execution.get("error_code")),
            "error_message": self._coerce_string_or_none(execution.get("error_message")),
        }

    def _normalize_execution_cancel_response(self, payload: dict[str, Any]) -> dict[str, Any]:
        job_type = self._coerce_string_or_none(payload.get("job_type"))
        cancel_state = self._coerce_string_or_none(payload.get("cancel_state"))
        job_payload = payload.get("job")
        if (
            job_type not in {"build", "fine-tune"}
            or cancel_state not in {"canceling", "canceled"}
            or not isinstance(job_payload, dict)
        ):
            self._raise_invalid_execution_payload(
                expected="execution-cancel",
                payload=payload,
                reason="missing_required_fields",
            )

        return {
            "job_type": job_type,
            "cancel_state": cancel_state,
            "job": job_payload,
        }

    def authenticate(self, api_key: str) -> AuthResponse:
        """Validate API key and return auth payload."""
        response = self._execute_read_only(
            "Authentication",
            lambda: self.client.post("/v1/cli/auth", headers={"X-API-Key": api_key}),
        )
        return AuthResponse.model_validate(cast(dict[str, Any], response.json()))

    def get_current_user(self) -> AuthResponse | None:
        """Return current auth status using stored credentials."""
        if not self.auth.api_key:
            return None
        try:
            response = self._execute_read_only(
                "Authentication",
                lambda: self.client.post("/v1/cli/auth"),
            )
        except CliError as error:
            if error.http_status == 401:
                return None
            raise
        return AuthResponse.model_validate(cast(dict[str, Any], response.json()))

    def get_model(self, slug: str) -> ModelLookupResponse | None:
        """Look up a model by slug."""
        try:
            response = self._execute_read_only(
                "Model lookup",
                lambda: self.client.get(f"/v1/cli/models/{slug}"),
            )
        except CliError as error:
            if error.http_status == 404:
                return None
            raise
        return ModelLookupResponse.model_validate(cast(dict[str, Any], response.json()))

    def get_model_version(self, slug: str, version: str) -> ModelLookupResponse | None:
        """Look up one model release by slug and version."""
        try:
            response = self._execute_read_only(
                "Model version lookup",
                lambda: self.client.get(f"/v1/cli/models/{slug}/versions/{version}"),
            )
        except CliError as error:
            if error.http_status == 404:
                return None
            raise
        return ModelLookupResponse.model_validate(cast(dict[str, Any], response.json()))

    def create_publish_build_group(
        self,
        request: PublishBuildGroupCreateRequest,
    ) -> PublishBuildGroup:
        """Create a remote publish build group via the jobs endpoint."""
        payload: dict[str, Any] = {
            "model": request.slug,
            "mode": "publish-build",
            "input": {
                "version": request.version,
                "source_artifact_uri": request.source_artifact_uri,
                "dockerfile_path": request.dockerfile_path,
                "build_context_path": request.build_context_path,
                "selected_hardware_tier": request.selected_hardware_tier,
                "registration_intent": request.registration_intent.model_dump(exclude_none=True),
            },
        }
        if request.source_artifact_id is not None:
            input_payload = cast(dict[str, Any], payload["input"])
            input_payload["source_artifact_id"] = request.source_artifact_id
        if request.python_package_index is not None:
            input_payload = cast(dict[str, Any], payload["input"])
            input_payload["python_package_index"] = request.python_package_index
        if request.force:
            input_payload = cast(dict[str, Any], payload["input"])
            input_payload["force"] = True
        try:
            response = self.client.post(
                "/api/jobs/publish-build/",
                json=payload,
            )
            response.raise_for_status()
        except httpx.HTTPStatusError as error:
            detail = self._extract_gateway_detail(error.response)
            raise cli_error_from_http_status(
                status_code=error.response.status_code,
                message=str(detail.get("message") or f"Publish build job create failed: {error}"),
                request_id=self.context.request_id,
                code=detail.get("code"),
                hint=detail.get("hint"),
                retryable=detail.get("retryable"),
                extra=detail.get("extra"),
            ) from error
        except httpx.HTTPError as error:
            raise network_error(
                f"Publish build job create failed: {error}",
                code="gateway_unreachable",
                request_id=self.context.request_id,
            ) from error
        raw = cast(dict[str, Any], response.json())
        job_payload = self._extract_publish_build_group_create_job(raw)
        normalized_job = self._normalize_publish_build_execution(job_payload)
        return PublishBuildGroup.model_validate(normalized_job)

    def get_publish_build_group(self, job_id: str) -> PublishBuildGroup:
        """Resolve one publish build group via the jobs endpoint."""
        raw = self.get_job(job_id=job_id)
        return PublishBuildGroup.model_validate(self._normalize_publish_build_execution(raw))

    def list_publish_build_groups(
        self,
        *,
        model_slug: str | None = None,
        status: str | None = None,
        page: int = 1,
        page_size: int = 20,
    ) -> PublishBuildGroupListResponse:
        """List publish build groups via the jobs endpoint."""
        raw = self.list_jobs(
            job_type="build",
            status=status,
            model_slug=model_slug,
            page=page,
            page_size=page_size,
        )
        results = raw.get("results")
        if not isinstance(results, list):
            self._raise_invalid_execution_payload(
                expected="publish-build-list",
                payload=raw,
                reason="results_must_be_list",
            )
        normalized_results: list[dict[str, Any]] = []
        for index, item in enumerate(results):
            if not isinstance(item, dict):
                self._raise_invalid_execution_payload(
                    expected="publish-build-list-item",
                    payload=raw,
                    reason=f"results[{index}]_must_be_object",
                )
            normalized_results.append(self._normalize_publish_build_execution(item))

        pagination = raw.get("pagination")
        pagination_payload = pagination if isinstance(pagination, dict) else {}
        list_model_slug = self._coerce_string_or_none(raw.get("model_slug")) or model_slug
        return PublishBuildGroupListResponse.model_validate(
            {
                "results": normalized_results,
                "pagination": pagination_payload,
                "model_slug": list_model_slug,
            }
        )

    def cancel_publish_build_group(self, job_id: str) -> JobCancelResponse:
        """Cancel one publish build group via the jobs endpoint."""
        raw = self.cancel_job(job_id=job_id)
        return JobCancelResponse.model_validate(self._normalize_execution_cancel_response(raw))

    def delete_publish_build_group(self, job_id: str) -> None:
        """Delete one terminal publish build group via the jobs endpoint."""
        self.delete_job(job_id=job_id)

    def get_marketplace_model_detail(self, slug: str) -> dict[str, Any]:
        """Return marketplace model detail payload for a published model."""
        try:
            response = self.client.get(f"/api/marketplace/models/{slug}")
            response.raise_for_status()
        except httpx.HTTPStatusError as error:
            detail = self._extract_gateway_detail(error.response)
            raise cli_error_from_http_status(
                status_code=error.response.status_code,
                message=str(detail.get("message") or f"Model detail lookup failed: {error}"),
                request_id=self.context.request_id,
                code=detail.get("code"),
                hint=detail.get("hint"),
                retryable=detail.get("retryable"),
                extra=detail.get("extra"),
            ) from error
        except httpx.HTTPError as error:
            raise network_error(
                f"Model detail lookup failed: {error}",
                code="gateway_unreachable",
                request_id=self.context.request_id,
            ) from error
        return cast(dict[str, Any], response.json())

    # ================================================================
    # Job Methods
    # ================================================================

    def list_jobs(
        self,
        *,
        job_type: str | None = None,
        status: str | None = None,
        model_slug: str | None = None,
        page: int = 1,
        page_size: int = 20,
    ) -> dict[str, Any]:
        """List all long-running jobs."""
        params: dict[str, Any] = {"page": page, "page_size": page_size}
        if job_type:
            params["type"] = job_type
        if status:
            params["status"] = status
        if model_slug:
            params["model_slug"] = model_slug
        try:
            response = self._execute_read_only(
                "Jobs list",
                lambda: self.client.get("/api/jobs/", params=params),
            )
        except CliError:
            raise
        return cast(dict[str, Any], response.json())

    def get_job(self, *, job_id: str) -> dict[str, Any]:
        """Get a single job by ID."""
        try:
            response = self._execute_read_only(
                "Job detail",
                lambda: self.client.get(f"/api/jobs/{job_id}/"),
            )
        except CliError:
            raise
        return cast(dict[str, Any], response.json())

    @contextmanager
    def stream_job(self, job_id: str) -> Iterator[Iterator[str]]:
        """Open one live SSE stream for a single job."""
        try:
            with self.client.stream("GET", f"/api/jobs/{job_id}/stream/") as response:
                try:
                    response.raise_for_status()
                except httpx.HTTPStatusError as error:
                    detail = self._extract_gateway_detail(error.response)
                    raise cli_error_from_http_status(
                        status_code=error.response.status_code,
                        message=str(detail.get("message") or f"Job stream failed: {error}"),
                        request_id=self.context.request_id,
                        code=detail.get("code"),
                        hint=detail.get("hint"),
                        retryable=detail.get("retryable"),
                        extra=detail.get("extra"),
                    ) from error
                yield self._iter_job_stream_lines(response)
        except httpx.HTTPError as error:
            raise network_error(
                f"Job stream failed: {error}",
                code="job_stream_unavailable",
                request_id=self.context.request_id,
                hint=("Live job stream unavailable. Verify Gateway SSE connectivity and retry."),
                extra={"job_id": job_id},
            ) from error

    def _iter_job_stream_lines(self, response: httpx.Response) -> Iterator[str]:
        """Yield decoded SSE lines while normalizing transport failures."""
        try:
            yield from response.iter_lines()
        except httpx.HTTPError as error:
            raise network_error(
                f"Job stream failed: {error}",
                code="job_stream_unavailable",
                request_id=self.context.request_id,
                hint=("Live job stream unavailable. Verify Gateway SSE connectivity and retry."),
            ) from error

    def cancel_job(self, *, job_id: str) -> dict[str, Any]:
        """Cancel a queued job."""
        try:
            response = self.client.post(f"/api/jobs/{job_id}/cancel/")
            response.raise_for_status()
        except httpx.HTTPStatusError as error:
            detail = self._extract_gateway_detail(error.response)
            raise cli_error_from_http_status(
                status_code=error.response.status_code,
                message=str(detail.get("message") or f"Job cancel failed: {error}"),
                request_id=self.context.request_id,
                code=detail.get("code"),
                hint=detail.get("hint"),
                retryable=detail.get("retryable"),
                extra=detail.get("extra"),
            ) from error
        except httpx.HTTPError as error:
            raise network_error(
                f"Job cancel failed: {error}",
                code="gateway_unreachable",
                request_id=self.context.request_id,
            ) from error
        return cast(dict[str, Any], response.json())

    def delete_job(self, *, job_id: str) -> None:
        """Delete a terminal job."""
        try:
            response = self.client.delete(f"/api/jobs/{job_id}/")
            response.raise_for_status()
        except httpx.HTTPStatusError as error:
            detail = self._extract_gateway_detail(error.response)
            raise cli_error_from_http_status(
                status_code=error.response.status_code,
                message=str(detail.get("message") or f"Job delete failed: {error}"),
                request_id=self.context.request_id,
                code=detail.get("code"),
                hint=detail.get("hint"),
                retryable=detail.get("retryable"),
                extra=detail.get("extra"),
            ) from error
        except httpx.HTTPError as error:
            raise network_error(
                f"Job delete failed: {error}",
                code="gateway_unreachable",
                request_id=self.context.request_id,
            ) from error

    # ================================================================
    # Legacy Methods (delegate to V2 where possible)
    # ================================================================

    def create_fine_tune_job(
        self,
        *,
        model_slug: str,
        dataset_ref: str,
        budget: dict[str, Any] | None = None,
        labels: dict[str, Any] | None = None,
    ) -> FineTuneJobResponse:
        """Create a fine-tune job via the jobs endpoint."""
        input_data: dict[str, Any] = {"dataset_ref": dataset_ref}
        if budget is not None:
            input_data["budget"] = budget
        if labels is not None:
            input_data["labels"] = labels
        payload: dict[str, Any] = {
            "model": model_slug,
            "input": input_data,
        }
        try:
            response = self.client.post(
                "/api/jobs/fine-tune/",
                json=payload,
            )
            response.raise_for_status()
        except httpx.HTTPStatusError as error:
            detail = self._extract_gateway_detail(error.response)
            raise cli_error_from_http_status(
                status_code=error.response.status_code,
                message=str(detail.get("message") or f"Fine-tune create failed: {error}"),
                request_id=self.context.request_id,
                code=detail.get("code"),
                hint=detail.get("hint"),
                retryable=detail.get("retryable"),
                extra=detail.get("extra"),
            ) from error
        except httpx.HTTPError as error:
            raise network_error(
                f"Fine-tune create failed: {error}",
                code="gateway_unreachable",
                request_id=self.context.request_id,
            ) from error
        result = cast(dict[str, Any], response.json())
        job = result.get("job")
        if isinstance(job, dict):
            return FineTuneJobResponse.model_validate(job)
        return FineTuneJobResponse.model_validate(result)

    def list_fine_tune_jobs(
        self,
        *,
        model_slug: str | None = None,
        status: str | None = None,
        page: int = 1,
        page_size: int = 20,
    ) -> FineTuneJobListResponse:
        """List fine-tune jobs via the jobs endpoint."""
        raw = self.list_jobs(
            job_type="fine-tune",
            status=status,
            model_slug=model_slug,
            page=page,
            page_size=page_size,
        )
        results = raw.get("results")
        if not isinstance(results, list):
            self._raise_invalid_execution_payload(
                expected="fine-tune-list",
                payload=raw,
                reason="results_must_be_list",
            )
        normalized_results: list[dict[str, Any]] = []
        for index, item in enumerate(results):
            if not isinstance(item, dict):
                self._raise_invalid_execution_payload(
                    expected="fine-tune-list-item",
                    payload=raw,
                    reason=f"results[{index}]_must_be_object",
                )
            normalized_results.append(self._normalize_fine_tune_execution(item))

        pagination = raw.get("pagination")
        pagination_payload = pagination if isinstance(pagination, dict) else {}
        return FineTuneJobListResponse.model_validate(
            {
                "results": normalized_results,
                "pagination": pagination_payload,
            }
        )

    def get_fine_tune_job(self, *, job_id: str) -> FineTuneJobResponse:
        """Get a single fine-tune job via the jobs endpoint."""
        raw = self.get_job(job_id=job_id)
        return FineTuneJobResponse.model_validate(self._normalize_fine_tune_execution(raw))

    def cancel_fine_tune_job(self, *, job_id: str) -> JobCancelResponse:
        """Cancel one fine-tune job via the jobs endpoint."""
        raw = self.cancel_job(job_id=job_id)
        return JobCancelResponse.model_validate(self._normalize_execution_cancel_response(raw))

    def delete_fine_tune_job(self, *, job_id: str) -> None:
        """Delete one terminal fine-tune job via the jobs endpoint."""
        self.delete_job(job_id=job_id)

    def get_publish_metadata(self) -> PublishMetadataResponse:
        """Return platform-owned publish metadata for guided configuration."""
        try:
            response = self._execute_read_only(
                "Publish metadata lookup",
                lambda: self.client.get("/v1/cli/publish/metadata"),
            )
        except CliError as error:
            if error.http_status == 404:
                raise environment_error(
                    "Local Gateway does not support CLI publish metadata yet.",
                    code="gateway_publish_metadata_unsupported",
                    request_id=self.context.request_id,
                    hint=(
                        "Run `docker compose -f docker-compose.local.yml up -d gateway`. "
                        "If the route is still missing, run `make dev-up`."
                    ),
                    extra={"route": "/v1/cli/publish/metadata"},
                ) from error
            raise
        return PublishMetadataResponse.model_validate(cast(dict[str, Any], response.json()))

    def publish(self, request: PublishRequest | dict[str, Any]) -> PublishResponse:
        """Publish a model executable."""
        payload = (
            request
            if isinstance(request, PublishRequest)
            else PublishRequest.model_validate(request)
        )
        request_body = payload.model_dump(exclude_none=True)
        request_body = GatewayPublishRequest.model_validate(request_body).model_dump(
            exclude_none=True,
            exclude_unset=True,
            by_alias=True,
        )
        try:
            response = self.client.post(
                "/v1/cli/publish",
                json=request_body,
            )
            response.raise_for_status()
        except httpx.HTTPStatusError as error:
            detail = self._extract_gateway_detail(error.response)
            raise cli_error_from_http_status(
                status_code=error.response.status_code,
                message=str(detail.get("message") or f"Publish failed: {error}"),
                request_id=self.context.request_id,
                code=detail.get("code"),
                hint=detail.get("hint"),
                retryable=detail.get("retryable"),
                extra=detail.get("extra"),
            ) from error
        except httpx.HTTPError as error:
            raise network_error(
                f"Publish failed: {error}",
                code="gateway_unreachable",
                request_id=self.context.request_id,
                hint="Check Gateway connectivity and retry publish.",
            ) from error
        return PublishResponse.model_validate(cast(dict[str, Any], response.json()))

    def publish_agent(
        self,
        request: AgentPublishRequest | dict[str, Any],
    ) -> AgentPublishResult:
        """Persist one agent topology for already-published root + worker units.

        Root agent is the real deployable public entrypoint.
        Workers are deployable child runtimes under workers/<key>/.
        Public execution always enters through the root agent.
        """
        payload = (
            request
            if isinstance(request, AgentPublishRequest)
            else AgentPublishRequest.model_validate(request)
        )
        request_body = payload.model_dump(exclude_none=True)
        try:
            response = self.client.post(
                "/v1/cli/publish/agent",
                json=request_body,
            )
            response.raise_for_status()
        except httpx.HTTPStatusError as error:
            detail = self._extract_gateway_detail(error.response)
            raise cli_error_from_http_status(
                status_code=error.response.status_code,
                message=str(detail.get("message") or f"Agent publish failed: {error}"),
                request_id=self.context.request_id,
                code=detail.get("code"),
                hint=detail.get("hint"),
                retryable=detail.get("retryable"),
                extra=detail.get("extra"),
            ) from error
        except httpx.HTTPError as error:
            raise network_error(
                f"Agent publish failed: {error}",
                code="gateway_unreachable",
                request_id=self.context.request_id,
                hint="Check Gateway connectivity and retry publish.",
            ) from error
        return AgentPublishResult.model_validate(cast(dict[str, Any], response.json()))

    def publish_model_by_slug(self, slug: str) -> PublishResponse:
        """Publish one existing remote model without a local build flow."""
        try:
            path = f"/v1/cli/models/{quote(slug.strip(), safe='')}/publish/"
            response = self.client.post(path)
            response.raise_for_status()
        except httpx.HTTPStatusError as error:
            detail = self._extract_gateway_detail(error.response)
            raise cli_error_from_http_status(
                status_code=error.response.status_code,
                message=str(detail.get("message") or f"Model publish failed: {error}"),
                request_id=self.context.request_id,
                code=detail.get("code"),
                hint=detail.get("hint"),
                retryable=detail.get("retryable"),
                extra=detail.get("extra"),
            ) from error
        except httpx.HTTPError as error:
            raise network_error(
                f"Model publish failed: {error}",
                code="gateway_unreachable",
                request_id=self.context.request_id,
                hint="Check Gateway connectivity and retry publish.",
            ) from error
        return PublishResponse.model_validate(cast(dict[str, Any], response.json()))

    def set_model_secret(self, *, model_slug: str, name: str, value: str) -> ModelSecretMetadata:
        """Upsert one model-scoped runtime secret."""
        path = (
            f"/v1/cli/models/{quote(model_slug.strip(), safe='')}"
            f"/secrets/{quote(name.strip(), safe='')}"
        )
        try:
            response = self.client.put(path, json={"value": value})
            response.raise_for_status()
        except httpx.HTTPStatusError as error:
            detail = self._extract_gateway_detail(error.response)
            raise cli_error_from_http_status(
                status_code=error.response.status_code,
                message=str(detail.get("message") or f"Secret set failed: {error}"),
                request_id=self.context.request_id,
                code=detail.get("code"),
                hint=detail.get("hint"),
                retryable=detail.get("retryable"),
                extra=detail.get("extra"),
            ) from error
        except httpx.HTTPError as error:
            raise network_error(
                f"Secret set failed: {error}",
                code="gateway_unreachable",
                request_id=self.context.request_id,
                hint="Check Gateway connectivity and retry.",
            ) from error
        return ModelSecretMetadata.model_validate(cast(dict[str, Any], response.json()))

    def list_model_secrets(self, *, model_slug: str) -> ModelSecretListResponse:
        """List configured model-scoped runtime secrets."""
        path = f"/v1/cli/models/{quote(model_slug.strip(), safe='')}/secrets"
        response = self._execute_read_only(
            "Model secret lookup",
            lambda: self.client.get(path),
        )
        return ModelSecretListResponse.model_validate(cast(dict[str, Any], response.json()))

    def delete_model_secret(self, *, model_slug: str, name: str) -> None:
        """Delete one model-scoped runtime secret."""
        path = (
            f"/v1/cli/models/{quote(model_slug.strip(), safe='')}"
            f"/secrets/{quote(name.strip(), safe='')}"
        )
        try:
            response = self.client.delete(path)
            response.raise_for_status()
        except httpx.HTTPStatusError as error:
            detail = self._extract_gateway_detail(error.response)
            raise cli_error_from_http_status(
                status_code=error.response.status_code,
                message=str(detail.get("message") or f"Secret delete failed: {error}"),
                request_id=self.context.request_id,
                code=detail.get("code"),
                hint=detail.get("hint"),
                retryable=detail.get("retryable"),
                extra=detail.get("extra"),
            ) from error
        except httpx.HTTPError as error:
            raise network_error(
                f"Secret delete failed: {error}",
                code="gateway_unreachable",
                request_id=self.context.request_id,
                hint="Check Gateway connectivity and retry.",
            ) from error

    def upload_studio_media(
        self,
        *,
        file_path: Path,
        media_type: str,
    ) -> dict[str, Any]:
        """Upload Studio media through the public Studio media endpoint."""
        content_type = _guess_content_type(file_path)
        studio_timeout = _studio_media_upload_gateway_timeout_seconds()
        try:
            response = self.client.post(
                "/api/studio/media/upload/init",
                json={
                    "filename": file_path.name,
                    "content_type": content_type,
                    "media_type": media_type,
                    "size_bytes": file_path.stat().st_size,
                },
                timeout=studio_timeout,
            )
            response.raise_for_status()
        except httpx.HTTPStatusError as error:
            detail = self._extract_gateway_detail(error.response)
            raise cli_error_from_http_status(
                status_code=error.response.status_code,
                message=str(detail.get("message") or f"Studio media upload init failed: {error}"),
                request_id=self.context.request_id,
                code=_PUBLISH_REGISTRATION_FAILED_CODE,
                hint=detail.get("hint"),
                retryable=detail.get("retryable"),
                extra=_publish_registration_upload_failure_extra(
                    upload_phase="init",
                    upstream_code=str(detail.get("code") or ""),
                    extra=detail.get("extra"),
                ),
            ) from error
        except httpx.HTTPError as error:
            timeout_hint = None
            if isinstance(error, httpx.TimeoutException):
                timeout_hint = (
                    "If the control plane is slow, increase "
                    "STUDIO_MEDIA_UPLOAD_PROXY_TIMEOUT (Gateway) and "
                    f"{_STUDIO_MEDIA_GATEWAY_TIMEOUT_ENV} (CLI)."
                )
            raise network_error(
                f"Studio media upload init failed: {error}",
                code=_PUBLISH_REGISTRATION_FAILED_CODE,
                request_id=self.context.request_id,
                hint=timeout_hint,
                extra=_publish_registration_upload_failure_extra(
                    upload_phase="init",
                    upstream_code="gateway_unreachable",
                ),
            ) from error

        payload = cast(dict[str, Any], response.json())
        upload_id = str(payload.get("upload_id") or "")
        upload_strategy = str(payload.get("upload_strategy") or "single")

        if upload_strategy == "single":
            upload_url = str(payload.get("upload_url") or "").strip()
            if not upload_url:
                raise internal_error(
                    "Studio media upload URL missing from Gateway response",
                    code=_PUBLISH_REGISTRATION_FAILED_CODE,
                    request_id=self.context.request_id,
                    extra=_publish_registration_upload_failure_extra(
                        upload_phase="init",
                        upstream_code="studio_media_upload_invalid",
                    ),
                )
            headers = {
                str(key): str(value)
                for key, value in cast(
                    dict[str, Any], payload.get("required_headers") or {}
                ).items()
            }
            with file_path.open("rb") as handle:
                upload_response = httpx.put(
                    upload_url,
                    content=handle,
                    headers=headers,
                    timeout=60.0,
                )
            try:
                upload_response.raise_for_status()
            except httpx.HTTPError as error:
                raise network_error(
                    f"Studio media upload failed: {error}",
                    code=_PUBLISH_REGISTRATION_FAILED_CODE,
                    request_id=self.context.request_id,
                    extra=_publish_registration_upload_failure_extra(
                        upload_phase="single_part_upload",
                        upstream_code="studio_media_upload_failed",
                    ),
                ) from error
            complete_data = {"upload_id": upload_id}
        else:
            parts = cast(list[dict[str, Any]], payload.get("parts") or [])
            completed_parts: list[dict[str, Any]] = []
            chunk_size = int(payload.get("chunk_size", 5 * 1024 * 1024))  # default 5MB
            with file_path.open("rb") as handle:
                for part in parts:
                    part_number = int(part["part_number"])
                    upload_url = str(part["upload_url"])
                    chunk = handle.read(chunk_size)
                    upload_response = httpx.put(
                        upload_url,
                        content=chunk,
                        timeout=60.0,
                    )
                    try:
                        upload_response.raise_for_status()
                    except httpx.HTTPError as error:
                        raise network_error(
                            f"Studio media upload failed: {error}",
                            code=_PUBLISH_REGISTRATION_FAILED_CODE,
                            request_id=self.context.request_id,
                            extra=_publish_registration_upload_failure_extra(
                                upload_phase="multipart_upload",
                                upstream_code="studio_media_upload_failed",
                            ),
                        ) from error
                    etag = (
                        upload_response.headers.get("etag")
                        or upload_response.headers.get("ETag")
                        or ""
                    )
                    completed_parts.append(
                        {
                            "part_number": part_number,
                            "etag": etag,
                            "size_bytes": len(chunk),
                        }
                    )
            complete_data = {
                "upload_id": upload_id,
                "parts": completed_parts,
                "checksum": {"algorithm": "sha256", "value": calculate_file_hash(file_path)},
            }

        try:
            complete_response = self.client.post(
                "/api/studio/media/upload/complete",
                json=complete_data,
                timeout=studio_timeout,
            )
            complete_response.raise_for_status()
        except httpx.HTTPStatusError as error:
            detail = self._extract_gateway_detail(error.response)
            raise cli_error_from_http_status(
                status_code=error.response.status_code,
                message=str(
                    detail.get("message") or f"Studio media upload complete failed: {error}"
                ),
                request_id=self.context.request_id,
                code=_PUBLISH_REGISTRATION_FAILED_CODE,
                hint=detail.get("hint"),
                retryable=detail.get("retryable"),
                extra=_publish_registration_upload_failure_extra(
                    upload_phase="complete",
                    upstream_code=str(detail.get("code") or ""),
                    extra=detail.get("extra"),
                ),
            ) from error
        except httpx.HTTPError as error:
            timeout_hint = None
            if isinstance(error, httpx.TimeoutException):
                timeout_hint = (
                    "If the control plane is slow, increase "
                    "STUDIO_MEDIA_UPLOAD_PROXY_TIMEOUT (Gateway) and "
                    f"{_STUDIO_MEDIA_GATEWAY_TIMEOUT_ENV} (CLI)."
                )
            raise network_error(
                f"Studio media upload complete failed: {error}",
                code=_PUBLISH_REGISTRATION_FAILED_CODE,
                request_id=self.context.request_id,
                hint=timeout_hint,
                extra=_publish_registration_upload_failure_extra(
                    upload_phase="complete",
                    upstream_code="gateway_unreachable",
                ),
            ) from error

        return cast(dict[str, Any], complete_response.json())

    def get_studio_model(self, model_id: str) -> StudioModelDetailResponse:
        """Fetch studio model details."""
        try:
            response = self.client.get(f"/api/studio/models/{model_id}")
            response.raise_for_status()
        except httpx.HTTPStatusError as error:
            detail = self._extract_gateway_detail(error.response)
            raise cli_error_from_http_status(
                status_code=error.response.status_code,
                message=str(detail.get("message") or f"Model lookup failed: {error}"),
                request_id=self.context.request_id,
                code=detail.get("code"),
                hint=detail.get("hint"),
                retryable=detail.get("retryable"),
                extra=detail.get("extra"),
            ) from error
        except httpx.HTTPError as error:
            raise network_error(
                f"Model lookup failed: {error}",
                code="gateway_unreachable",
                request_id=self.context.request_id,
            ) from error
        return StudioModelDetailResponse.model_validate(cast(dict[str, Any], response.json()))

    def get_studio_model_analytics(self, model_id: str) -> dict[str, Any]:
        """Fetch model analytics."""
        try:
            response = self.client.get(f"/api/studio/models/{model_id}/analytics")
            response.raise_for_status()
        except httpx.HTTPStatusError as error:
            detail = self._extract_gateway_detail(error.response)
            raise cli_error_from_http_status(
                status_code=error.response.status_code,
                message=str(detail.get("message") or f"Analytics lookup failed: {error}"),
                request_id=self.context.request_id,
                code=detail.get("code"),
                hint=detail.get("hint"),
                retryable=detail.get("retryable"),
                extra=detail.get("extra"),
            ) from error
        except httpx.HTTPError as error:
            raise network_error(
                f"Analytics lookup failed: {error}",
                code="gateway_unreachable",
                request_id=self.context.request_id,
            ) from error
        return cast(dict[str, Any], response.json())

    def get_model_rates(self, model_id: str, actions: list[str]) -> dict[str, Any]:
        """Fetch marketplace rates."""
        try:
            response = self.client.get(
                f"/api/billing/marketplace/models/{model_id}/rates",
                params={"actions": actions},
            )
            response.raise_for_status()
        except httpx.HTTPStatusError as error:
            detail = self._extract_gateway_detail(error.response)
            raise cli_error_from_http_status(
                status_code=error.response.status_code,
                message=str(detail.get("message") or f"Rate lookup failed: {error}"),
                request_id=self.context.request_id,
                code=detail.get("code"),
                hint=detail.get("hint"),
                retryable=detail.get("retryable"),
                extra=detail.get("extra"),
            ) from error
        except httpx.HTTPError as error:
            raise network_error(
                f"Rate lookup failed: {error}",
                code="gateway_unreachable",
                request_id=self.context.request_id,
            ) from error
        return cast(dict[str, Any], response.json())

    def upload_init(self, request: UploadInitRequest) -> UploadInitResponse:
        """Initialize a multipart upload."""
        try:
            response = self.client.post(
                "/v1/cli/upload/init",
                content=request.model_dump_json(exclude_none=True),
            )
            response.raise_for_status()
        except httpx.HTTPStatusError as error:
            detail = self._extract_gateway_detail(error.response)
            raise cli_error_from_http_status(
                status_code=error.response.status_code,
                message=str(detail.get("message") or f"Upload init failed: {error}"),
                request_id=self.context.request_id,
                code=detail.get("code"),
                hint=detail.get("hint"),
                retryable=detail.get("retryable"),
                extra=detail.get("extra"),
            ) from error
        except httpx.HTTPError as error:
            raise network_error(
                f"Upload init failed: {error}",
                code="gateway_unreachable",
                request_id=self.context.request_id,
            ) from error
        return UploadInitResponse.model_validate(cast(dict[str, Any], response.json()))

    def upload_complete(self, request: UploadCompleteRequest) -> UploadCompleteResponse:
        """Complete a multipart upload."""
        try:
            response = self.client.post(
                "/v1/cli/upload/complete",
                content=request.model_dump_json(exclude_none=True),
            )
            response.raise_for_status()
        except httpx.HTTPStatusError as error:
            detail = self._extract_gateway_detail(error.response)
            raise cli_error_from_http_status(
                status_code=error.response.status_code,
                message=str(detail.get("message") or f"Upload complete failed: {error}"),
                request_id=self.context.request_id,
                code=detail.get("code"),
                hint=detail.get("hint"),
                retryable=detail.get("retryable"),
                extra=detail.get("extra"),
            ) from error
        except httpx.HTTPError as error:
            raise network_error(
                f"Upload complete failed: {error}",
                code="gateway_unreachable",
                request_id=self.context.request_id,
            ) from error
        return UploadCompleteResponse.model_validate(cast(dict[str, Any], response.json()))

    def upload_abort(self, request: UploadAbortRequest) -> None:
        """Abort a multipart upload."""
        try:
            response = self.client.post(
                "/v1/cli/upload/abort",
                content=request.model_dump_json(),
            )
            response.raise_for_status()
        except httpx.HTTPStatusError as error:
            detail = self._extract_gateway_detail(error.response)
            raise cli_error_from_http_status(
                status_code=error.response.status_code,
                message=str(detail.get("message") or f"Upload abort failed: {error}"),
                request_id=self.context.request_id,
                code=detail.get("code"),
                hint=detail.get("hint"),
                retryable=detail.get("retryable"),
                extra=detail.get("extra"),
            ) from error
        except httpx.HTTPError as error:
            raise network_error(
                f"Upload abort failed: {error}",
                code="gateway_unreachable",
                request_id=self.context.request_id,
            ) from error


def calculate_file_hash(file_path: Path) -> str:
    """Calculate SHA256 hash of a file."""
    digest = hashlib.sha256()
    with file_path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def get_file_size(file_path: Path) -> int:
    """Return file size in bytes."""
    return file_path.stat().st_size


def _bool_or_none(value: Any) -> bool | None:
    """Return a bool when the input is already boolean."""
    return value if isinstance(value, bool) else None


class UploadClient:
    """Multipart upload orchestration."""

    def __init__(self, gateway: Any, *, max_retries: int = 3) -> None:
        self.gateway = gateway
        self.max_retries = max_retries

    def upload_file(
        self,
        *,
        file_path: Path,
        slug: str,
        version: str,
        artifact_type: ArtifactType,
        content_type: str,
        metadata: dict[str, Any] | None,
        concurrency: int,
        on_progress: Any | None,
    ) -> UploadResult:
        """Upload a file using Gateway multipart URLs."""
        if concurrency < 1 or concurrency > 8:
            raise usage_error("Upload concurrency must be an integer between 1 and 8")
        file_hash = calculate_file_hash(file_path)
        init_response = self.gateway.upload_init(
            UploadInitRequest(
                slug=slug,
                version=version,
                artifact_type=artifact_type,
                file_size_bytes=get_file_size(file_path),
                file_hash_sha256=file_hash,
                content_type=content_type,
                metadata=metadata,
            )
        )
        offsets: list[int] = []
        current_offset = 0
        for part in init_response.parts:
            offsets.append(current_offset)
            current_offset += part.size_bytes
        total_bytes = current_offset
        bytes_uploaded_per_part = [0] * len(init_response.parts)
        progress_lock = threading.Lock()

        def upload_part(index: int) -> tuple[int, str, int]:
            part = init_response.parts[index]
            offset = offsets[index]
            etag = self._upload_part_with_retry(
                file_path=file_path,
                offset=offset,
                length=part.size_bytes,
                url=part.url,
                required_headers=part.headers,
            )
            with progress_lock:
                bytes_uploaded_per_part[index] = part.size_bytes
                bytes_uploaded = sum(bytes_uploaded_per_part)
            percent_complete = round((bytes_uploaded / total_bytes) * 100) if total_bytes else 100
            if on_progress is not None:
                on_progress(
                    UploadProgress(
                        part_number=part.part_number,
                        total_parts=len(init_response.parts),
                        bytes_uploaded=bytes_uploaded,
                        total_bytes=total_bytes,
                        percent_complete=percent_complete,
                        active_uploads=min(concurrency, len(init_response.parts)),
                    )
                )
            return part.part_number, etag, part.size_bytes

        try:
            with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as executor:
                completed = list(executor.map(upload_part, range(len(init_response.parts))))
            complete_response = self.gateway.upload_complete(
                UploadCompleteRequest(
                    upload_id=init_response.upload_id,
                    parts=[
                        PartCompletionInfo(
                            part_number=part_number,
                            etag=etag,
                            size_bytes=size_bytes,
                        )
                        for part_number, etag, size_bytes in completed
                    ],
                    checksum={"algorithm": "sha256", "value": file_hash},
                )
            )
        except Exception as error:
            try:
                self.gateway.upload_abort(
                    UploadAbortRequest(upload_id=init_response.upload_id, reason="error")
                )
            except Exception as abort_error:
                if isinstance(error, CliError):
                    raise CliError(
                        error.message,
                        code=error.code,
                        category=error.category,
                        exit_code=error.exit_code,
                        request_id=error.request_id,
                        hint=error.hint,
                        retryable=error.retryable,
                        http_status=error.http_status,
                        extra={**error.extra, "abort_error": str(abort_error)},
                    ) from error
                raise internal_error(
                    f"{error}. Cleanup failed: {abort_error}",
                    request_id=self._request_id(),
                ) from error
            raise
        return UploadResult(
            storage_uri=complete_response.storage_uri,
            artifact_id=complete_response.artifact_id,
            size_bytes=complete_response.size_bytes,
        )

    def _upload_part_with_retry(
        self,
        *,
        file_path: Path,
        offset: int,
        length: int,
        url: str,
        required_headers: dict[str, str],
    ) -> str:
        for attempt in range(1, self.max_retries + 1):
            try:
                with _FileSliceStream(file_path=file_path, offset=offset, length=length) as stream:
                    with httpx.Client(timeout=60.0) as client:
                        response = client.put(
                            url,
                            content=stream.iter_bytes(),
                            headers={
                                **required_headers,
                                "Content-Length": str(length),
                            },
                        )
                response.raise_for_status()
                etag = response.headers.get("etag") or response.headers.get("ETag")
                return etag or ""
            except httpx.HTTPError as error:
                if attempt >= self.max_retries:
                    raise network_error(
                        f"Upload failed: {error}",
                        code="upload_failed",
                        request_id=self._request_id(),
                    ) from error
                time.sleep(0.25)
        raise network_error(
            "Upload failed unexpectedly",
            code="upload_failed",
            request_id=self._request_id(),
        )

    def _request_id(self) -> str | None:
        """Return the current request id when the Gateway client exposes one."""
        context = getattr(self.gateway, "context", None)
        request_id = getattr(context, "request_id", None)
        return request_id if isinstance(request_id, str) else None


class _FileSliceStream:
    """Stream a fixed byte range from disk without buffering the full part."""

    def __init__(self, *, file_path: Path, offset: int, length: int) -> None:
        self._file_path = file_path
        self._offset = offset
        self._remaining = length
        self._handle = None

    def __enter__(self) -> _FileSliceStream:
        self._handle = self._file_path.open("rb")
        self._handle.seek(self._offset)
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        self.close()

    def read(self, size: int = -1) -> bytes:
        if self._handle is None:
            raise RuntimeError("File slice stream must be opened before reading")
        if self._remaining <= 0:
            return b""
        if size is None or size < 0 or size > self._remaining:
            size = self._remaining
        chunk = self._handle.read(size)
        self._remaining -= len(chunk)
        return chunk

    def close(self) -> None:
        if self._handle is not None:
            self._handle.close()
            self._handle = None

    def iter_bytes(self, chunk_size: int = 64 * 1024) -> Iterator[bytes]:
        """Yield the configured byte slice in httpx-compatible chunks."""
        while True:
            chunk = self.read(chunk_size)
            if not chunk:
                break
            yield chunk


def _guess_content_type(file_path: Path) -> str:
    """Infer a content type for Studio media uploads."""
    suffix = file_path.suffix.lower()
    if suffix == ".png":
        return "image/png"
    if suffix in {".jpg", ".jpeg"}:
        return "image/jpeg"
    if suffix == ".webp":
        return "image/webp"
    if suffix == ".gif":
        return "image/gif"
    if suffix == ".mp4":
        return "video/mp4"
    if suffix == ".webm":
        return "video/webm"
    if suffix == ".mov":
        return "video/quicktime"
    if suffix == ".mkv":
        return "video/x-matroska"
    return "application/octet-stream"
