"""Gateway-owned CLI transport models.

This module is generated from Gateway OpenAPI.
Do not edit manually.
"""

from .models import (
    CliModelLookupResponse,
    CliModelSecretListResponse,
    CliModelSecretMetadata,
    CliModelSecretSetRequest,
    CliPublishHardwareTier,
    CliPublishMetadataResponse,
    CliPublishReadiness,
    CliPublishResponse,
    CliReleaseRuntimeState,
    PartCompletionInfo,
    PublishRequest,
    UploadAbortRequest,
    UploadAbortResponse,
    UploadCompleteRequest,
    UploadCompleteResponse,
    UploadInitRequest,
    UploadInitResponse,
    UploadPartResponse,
)

ModelLookupResponse = CliModelLookupResponse
ModelSecretListResponse = CliModelSecretListResponse
ModelSecretMetadata = CliModelSecretMetadata
ModelSecretSetRequest = CliModelSecretSetRequest
PublishHardwareTier = CliPublishHardwareTier
PublishMetadataResponse = CliPublishMetadataResponse
PublishReadiness = CliPublishReadiness
PublishResponse = CliPublishResponse
ReleaseRuntimeState = CliReleaseRuntimeState
UploadPart = UploadPartResponse

__all__ = [
    "CliModelLookupResponse",
    "CliModelSecretListResponse",
    "CliModelSecretMetadata",
    "CliModelSecretSetRequest",
    "CliPublishHardwareTier",
    "CliPublishMetadataResponse",
    "CliPublishReadiness",
    "CliPublishResponse",
    "CliReleaseRuntimeState",
    "ModelLookupResponse",
    "ModelSecretListResponse",
    "ModelSecretMetadata",
    "ModelSecretSetRequest",
    "PartCompletionInfo",
    "PublishHardwareTier",
    "PublishMetadataResponse",
    "PublishReadiness",
    "PublishRequest",
    "PublishResponse",
    "ReleaseRuntimeState",
    "UploadAbortRequest",
    "UploadAbortResponse",
    "UploadCompleteRequest",
    "UploadCompleteResponse",
    "UploadInitRequest",
    "UploadInitResponse",
    "UploadPart",
    "UploadPartResponse",
]
