"""Generated transport contracts consumed by the CLI."""
