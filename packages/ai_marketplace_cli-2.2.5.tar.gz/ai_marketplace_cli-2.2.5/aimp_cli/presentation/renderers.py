"""Rich presentation helpers for CLI commands."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from rich.console import Console, Group
from rich.panel import Panel
from rich.pretty import Pretty
from rich.table import Table


def render_init_success(
    console: Console,
    *,
    project_dir: Path,
    next_steps: list[str],
) -> None:
    """Render the project init success screen with structured panels."""
    summary = Table.grid(padding=(0, 2))
    summary.add_column(style="label")
    summary.add_column(style="primary")
    summary.add_row("Project", project_dir.name)
    summary.add_row("Path", str(project_dir))

    steps_table = Table.grid(padding=(0, 2))
    steps_table.add_column(style="label", justify="right")
    steps_table.add_column(style="primary")
    for index, step in enumerate(next_steps, start=1):
        steps_table.add_row(str(index), step)

    console.print(
        Group(
            Panel(
                summary,
                title=" ✔ PROJECT CREATED ",
                title_align="left",
                border_style="success",
            ),
            Panel(
                steps_table,
                title=" NEXT STEPS ",
                title_align="left",
                border_style="border",
            ),
        )
    )


def render_auth_panel(
    *,
    console: Console,
    gateway_url: str,
    username: str | None = None,
    workspace: str | None = None,
    scopes: list[str] | None = None,
    authenticated: bool,
    reason: str | None = None,
) -> None:
    """Render the current authentication state."""
    table = Table.grid(padding=(0, 2))
    table.add_column(style="label")
    table.add_column(style="primary")
    table.add_row("Authenticated", "yes" if authenticated else "no")
    if username:
        table.add_row("Username", username)
    if workspace:
        table.add_row("Workspace", workspace)
    if scopes is not None:
        table.add_row("Scopes", ", ".join(scopes) if scopes else "None")
    table.add_row("Gateway", gateway_url)
    if reason:
        table.add_row("Reason", reason)
    console.print(Panel(table, title=" AUTH STATUS ", title_align="left", border_style="success"))


def render_model_inspect(console: Console, output: dict[str, Any]) -> None:
    """Render model inspect output."""
    model = output["model"]
    summary = Table.grid(padding=(0, 2))
    summary.add_column(style="label")
    summary.add_column(style="primary")
    summary.add_row("Name", str(model["name"]))
    summary.add_row("Slug", str(model["slug"]))
    summary.add_row("Status", str(model["status"]))
    summary.add_row("Version", str(model["version"]))
    summary.add_row("Selected operations", ", ".join(model["selected_operations"]))
    summary.add_row(
        "Supported tiers",
        (
            ", ".join(model["supported_hardware_tiers"])
            if model["supported_hardware_tiers"]
            else "None"
        ),
    )
    summary.add_row("Selected tier", str(model["selected_hardware_tier"] or "N/A"))

    sections: list[Any] = [
        Panel(summary, title=" MODEL ", title_align="left", border_style="success"),
        Panel(
            Pretty(model["pricing"] or {}, expand_all=False),
            title=" PRICING ",
            title_align="left",
            border_style="border",
        ),
        Panel(
            Pretty(output["rates"] or {}, expand_all=False),
            title=" RATES ",
            title_align="left",
            border_style="border",
        ),
        Panel(
            Pretty(output["storage"] | {"layer_pool": output["layer_pool"]}, expand_all=False),
            title=" STORAGE ",
            title_align="left",
            border_style="border",
        ),
    ]
    partial_errors = {
        key: value for key, value in output["partial_errors"].items() if value is not None
    }
    if partial_errors:
        sections.append(
            Panel(
                Pretty(partial_errors, expand_all=False),
                title=" PARTIAL ERRORS ",
                title_align="left",
                border_style="warning",
            )
        )
    console.print(Group(*sections))


def render_fine_tune_job(console: Console, job: dict[str, Any]) -> None:
    """Render a single fine-tune job payload."""
    derived_model_slug = str(job.get("output_asset_slug") or "").strip()
    summary = Table.grid(padding=(0, 2))
    summary.add_column(style="label")
    summary.add_column(style="primary")
    summary.add_row("Job", str(job.get("job_id", "")))
    summary.add_row("Model", str(job.get("model_slug", "")))
    summary.add_row("Status", str(job.get("status", "")))
    summary.add_row("Created", str(job.get("created_at") or ""))
    summary.add_row("Started", str(job.get("started_at") or ""))
    summary.add_row("Finished", str(job.get("finished_at") or ""))
    summary.add_row("Adapter", str(job.get("adapter_format") or ""))
    summary.add_row("Output Kind", str(job.get("output_kind") or ""))
    if derived_model_slug:
        summary.add_row("Derived Model", derived_model_slug)
    summary.add_row(
        "Output Asset",
        str(job.get("output_asset_slug") or job.get("output_asset_id") or ""),
    )
    panels = [Panel(summary, title=" FINE-TUNE JOB ", title_align="left", border_style="success")]
    error_message = str(job.get("error_message") or "").strip()
    if error_message:
        panels.append(
            Panel(error_message, title=" LAST ERROR ", title_align="left", border_style="error")
        )
    timeline = job.get("timeline")
    if isinstance(timeline, list) and timeline:
        timeline_table = Table(show_header=True, header_style="label")
        timeline_table.add_column("Event", style="primary")
        timeline_table.add_column("Status", style="primary")
        timeline_table.add_column("At", style="primary")
        for entry in timeline[-5:]:
            if not isinstance(entry, dict):
                continue
            timeline_table.add_row(
                str(entry.get("event") or ""),
                str(entry.get("status") or ""),
                str(entry.get("at") or ""),
            )
        panels.append(
            Panel(timeline_table, title=" TIMELINE ", title_align="left", border_style="border")
        )
    if str(job.get("status") or "").strip().lower() == "succeeded" and derived_model_slug:
        next_steps = Table.grid(padding=(0, 2))
        next_steps.add_column(style="label")
        next_steps.add_column(style="primary")
        next_steps.add_row("Derived model slug", derived_model_slug)
        output_asset_id = str(job.get("output_asset_id") or "").strip()
        if output_asset_id:
            next_steps.add_row("Derived model id", output_asset_id)
        next_steps.add_row("Usage", "Use this derived model directly in execution flows.")
        next_steps.add_row("CLI inspect", f"ai model inspect --slug {derived_model_slug}")
        next_steps.add_row(
            "SDK execute",
            (
                "client.models.execute("
                f'model="{derived_model_slug}", mode="generate", input={{"prompt": "hello"}}'
                ")"
            ),
        )
        panels.append(
            Panel(next_steps, title=" NEXT STEPS ", title_align="left", border_style="border")
        )
    console.print(Group(*panels))


def render_publish_build_job(console: Console, job: dict[str, Any]) -> None:
    """Render a single publish build job payload."""
    summary = Table.grid(padding=(0, 2))
    summary.add_column(style="label")
    summary.add_column(style="primary")
    summary.add_row("Job", str(job.get("job_id", "")))
    summary.add_row("Model", str(job.get("slug", "")))
    summary.add_row("Version", str(job.get("version", "")))
    summary.add_row("Status", str(job.get("status", "")))
    summary.add_row("Phase", str(job.get("phase") or ""))
    summary.add_row("Current Step", str(job.get("current_step_message") or ""))
    summary.add_row("Created", str(job.get("created_at") or ""))
    summary.add_row("Started", str(job.get("started_at") or ""))
    summary.add_row("Finished", str(job.get("finished_at") or ""))
    summary.add_row("Last Heartbeat", str(job.get("last_heartbeat_at") or ""))
    summary.add_row("Last Progress", str(job.get("last_progress_at") or ""))
    cache_ref = str(job.get("cache_ref") or "").strip()
    cache_imported = job.get("cache_imported")
    cache_exported = job.get("cache_exported")
    if cache_ref:
        summary.add_row("Cache Ref", cache_ref)
    if cache_imported is not None:
        summary.add_row("Cache Imported", "yes" if cache_imported else "no")
    if cache_exported is not None:
        summary.add_row("Cache Exported", "yes" if cache_exported else "no")
    panels = [Panel(summary, title=" BUILD JOB ", title_align="left", border_style="success")]
    error_message = str(job.get("error_message") or "").strip()
    if error_message:
        panels.append(
            Panel(error_message, title=" LAST ERROR ", title_align="left", border_style="warning")
        )
    timeline = job.get("timeline")
    if isinstance(timeline, list) and timeline:
        timeline_table = Table(show_header=True, header_style="label")
        timeline_table.add_column("Event", style="primary")
        timeline_table.add_column("Status", style="primary")
        timeline_table.add_column("At", style="primary")
        for entry in timeline[-5:]:
            if not isinstance(entry, dict):
                continue
            timeline_table.add_row(
                str(entry.get("event") or ""),
                str(entry.get("status") or ""),
                str(entry.get("at") or ""),
            )
        panels.append(
            Panel(timeline_table, title=" TIMELINE ", title_align="left", border_style="border")
        )
    console.print(Group(*panels))


def render_jobs_list(console: Console, payload: dict[str, Any]) -> None:
    """Render the unified ``ai jobs list`` output."""
    summary = Table.grid(padding=(0, 2))
    summary.add_column(style="label")
    summary.add_column(style="primary")
    summary.add_row("Type", str(payload.get("type", "all")))

    filters = payload.get("filters") or {}
    if isinstance(filters, dict):
        summary.add_row("Model", str(filters.get("model") or "all"))
        summary.add_row("Status", str(filters.get("status") or "all"))

    pagination = payload.get("pagination") or {}
    if isinstance(pagination, dict):
        summary.add_row(
            "Page",
            f"{pagination.get('page', 1)}/{pagination.get('total_pages', 0)}",
        )
        summary.add_row("Total Jobs", str(pagination.get("total_items", 0)))

    rows = payload.get("results") or []
    if not isinstance(rows, list) or not rows:
        console.print(
            Group(
                Panel(summary, title=" JOBS ", title_align="left", border_style="success"),
                Panel(
                    "No jobs found.",
                    title=" RESULTS ",
                    title_align="left",
                    border_style="border",
                ),
            )
        )
        return

    table = Table(show_header=True, header_style="label")
    table.add_column("Type", style="primary")
    table.add_column("Job", style="primary")
    table.add_column("Model", style="primary")
    table.add_column("Status", style="primary")
    table.add_column("Created", style="primary")

    for item in rows:
        if not isinstance(item, dict):
            continue
        table.add_row(
            str(item.get("job_type", "")),
            str(item.get("job_id", "")),
            str(item.get("model_slug", "")),
            str(item.get("status", "")),
            str(item.get("created_at") or ""),
        )

    console.print(
        Group(
            Panel(summary, title=" JOBS ", title_align="left", border_style="success"),
            Panel(table, title=" RESULTS ", title_align="left", border_style="border"),
        )
    )


def render_job_detail(console: Console, payload: dict[str, Any]) -> None:
    """Render the unified ``ai jobs get`` output."""
    job_type = str(payload.get("job_type", "")).strip().lower()
    job = payload.get("job") or {}
    if not isinstance(job, dict):
        job = {}

    if job_type == "build":
        render_publish_build_job(console, job)
        return

    render_fine_tune_job(console, job)


def render_fine_tune_list(console: Console, payload: dict[str, Any]) -> None:
    """Render the ``ai fine-tune list`` output as a structured table."""
    summary = Table.grid(padding=(0, 2))
    summary.add_column(style="label")
    summary.add_column(style="primary")

    pagination = payload.get("pagination") or {}
    if isinstance(pagination, dict):
        summary.add_row(
            "Page",
            f"{pagination.get('page', 1)}/{pagination.get('total_pages', 0)}",
        )
        summary.add_row("Total Jobs", str(pagination.get("total_items", 0)))

    rows = payload.get("results") or []
    if not isinstance(rows, list) or not rows:
        console.print(
            Group(
                Panel(
                    summary, title=" FINE-TUNE JOBS ", title_align="left", border_style="success"
                ),
                Panel(
                    "No jobs found.",
                    title=" RESULTS ",
                    title_align="left",
                    border_style="border",
                ),
            )
        )
        return

    table = Table(show_header=True, header_style="label")
    table.add_column("Job", style="primary")
    table.add_column("Model", style="primary")
    table.add_column("Status", style="primary")
    table.add_column("Created", style="primary")
    table.add_column("Error", style="primary")

    for item in rows:
        if not isinstance(item, dict):
            continue
        job_id = str(item.get("job_id", ""))
        if len(job_id) > 8:
            job_id = job_id[:8]
        error_message = str(item.get("error_message") or "").strip()
        table.add_row(
            job_id,
            str(item.get("model_slug", "")),
            str(item.get("status", "")),
            str(item.get("created_at") or ""),
            error_message,
        )

    console.print(
        Group(
            Panel(summary, title=" FINE-TUNE JOBS ", title_align="left", border_style="success"),
            Panel(table, title=" RESULTS ", title_align="left", border_style="border"),
        )
    )


def render_job_action(console: Console, payload: dict[str, Any]) -> None:
    """Render a simple job mutation result."""
    summary = Table.grid(padding=(0, 2))
    summary.add_column(style="label")
    summary.add_column(style="primary")
    summary.add_row("Action", str(payload.get("action") or ""))
    summary.add_row("Type", str(payload.get("job_type") or ""))
    summary.add_row("Job", str(payload.get("job_id") or ""))
    console.print(Panel(summary, title=" JOB ACTION ", title_align="left", border_style="success"))
