"""Human-facing Rich renderers."""
