"""Config resolution, persistence, and command context helpers."""

from __future__ import annotations

import json
import os
import sys
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from rich.console import Console

from rich.text import Text
from rich.theme import Theme

from aimp_cli.core.errors import CliError
from aimp_cli.domain.models import DEFAULT_GATEWAY_URL, LOCAL_GATEWAY_URL, AuthContext, ConfigData

CONFIG_DIR = Path.home() / ".aimp"
CONFIG_FILE = CONFIG_DIR / "config.json"

# Zinc Design System Tokens
ZINC_THEME = Theme(
    {
        "info": "cyan",
        "warning": "yellow",
        "error": "red",
        "success": "green",
        "primary": "bright_white",
        "muted": "grey50",
        "label": "grey70",
        "border": "grey30",
        "header": "bold bright_white",
    }
)

console = Console(theme=ZINC_THEME)


@dataclass(slots=True)
class CommandContext:
    """Execution context shared across services."""

    request_id: str
    command_name: str
    debug: bool = False
    json_output: bool = False
    started_at: float = time.time()

    def log(self, **payload: Any) -> None:
        """Emit debug logs as one-line JSON to stderr."""
        if not self.debug:
            return
        entry = {"request_id": self.request_id, "operation": self.command_name, **payload}
        print(json.dumps(entry, sort_keys=True), file=sys.stderr)

    def finish(self) -> float:
        """Return elapsed seconds for the command."""
        return max(time.time() - self.started_at, 0.0)


class ConfigStore:
    """Persist CLI credentials in ``~/.aimp/config.json``."""

    def __init__(self, path: Path = CONFIG_FILE) -> None:
        self._path = path
        self._config: ConfigData | None = None

    def ensure_dir(self) -> None:
        """Ensure the config directory exists with secure permissions."""
        self._path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        _apply_secure_permissions(self._path.parent, 0o700)

    def load(self) -> ConfigData | None:
        """Load config from disk."""
        if self._config is not None:
            return self._config
        if not self._path.exists():
            return None
        raw = self._path.read_text(encoding="utf-8")
        try:
            self._config = ConfigData.model_validate_json(raw)
        except Exception:
            return None
        return self._config

    def save(self, config: ConfigData) -> None:
        """Save config with ``0600`` permissions."""
        self.ensure_dir()
        self._path.write_text(
            config.model_dump_json(by_alias=True, exclude_none=True, indent=2) + "\n",
            encoding="utf-8",
        )
        _apply_secure_permissions(self._path, 0o600)
        self._config = config

    def clear(self) -> None:
        """Remove persisted config."""
        if self._path.exists():
            self._path.unlink()
        self._config = None

    def is_authenticated(self) -> bool:
        """Return whether credentials are stored."""
        config = self.load()
        return bool(config and config.api_key and config.gateway_url)

    def get_gateway_url(self) -> str:
        """Return configured gateway URL or local default."""
        config = self.load()
        if config:
            return config.gateway_url
        return LOCAL_GATEWAY_URL

    def get_api_key(self) -> str | None:
        """Return configured API key."""
        config = self.load()
        return config.api_key if config else None


config_store = ConfigStore()


def _apply_secure_permissions(path: Path, mode: int) -> None:
    """Apply POSIX permissions when supported by the platform."""
    if os.name == "nt":
        return
    try:
        os.chmod(path, mode)
    except OSError:
        return


def _stdin_is_tty() -> bool:
    """Return whether stdin supports interactive input."""
    stdin = getattr(sys.stdin, "isatty", None)
    return bool(stdin()) if callable(stdin) else False


def _stdout_is_tty() -> bool:
    """Return whether stdout supports full terminal rendering."""
    stdout = getattr(sys.stdout, "isatty", None)
    return bool(stdout()) if callable(stdout) else False


def has_interactive_terminal() -> bool:
    """Return whether stdin and stdout are both interactive terminals."""
    return _stdin_is_tty() and _stdout_is_tty()


def can_prompt_for_input() -> bool:
    """Return whether the CLI can prompt the user for a single text value."""
    return _stdin_is_tty()


def build_command_context(command_name: str, *, debug: bool, json_output: bool) -> CommandContext:
    """Create a new command context."""
    return CommandContext(
        request_id=f"cli-{uuid.uuid4()}",
        command_name=command_name,
        debug=debug,
        json_output=json_output,
        started_at=time.time(),
    )


def resolve_auth_context(
    *,
    gateway: str | None,
    api_key: str | None,
    persist: bool = False,
) -> AuthContext:
    """Resolve auth values using flag > env > config precedence."""
    config = config_store.load()
    resolved_gateway = (
        (gateway.strip() if gateway else "")
        or os.getenv("AIMP_GATEWAY_URL", "").strip()
        or (config.gateway_url if config else "")
        or DEFAULT_GATEWAY_URL
    )
    resolved_api_key = (
        (api_key.strip() if api_key else "")
        or os.getenv("AIMP_API_KEY", "").strip()
        or (config.api_key if config else "")
        or None
    )
    return AuthContext(
        gateway_url=resolved_gateway,
        api_key=resolved_api_key,
        persist=persist,
    )


def require_tty() -> None:
    """Fail when a command needs a TTY."""
    if not has_interactive_terminal():
        raise RuntimeError("Interactive input requires an interactive terminal")


def emit_result(
    payload: dict[str, Any],
    *,
    json_output: bool,
    success_message: str | None = None,
    title: str | None = None,
) -> None:
    """Print either JSON or a short human-readable success message."""
    request_id = payload.get("request_id")
    if json_output:
        data = dict(payload)
        data.pop("request_id", None)
        envelope: dict[str, Any] = {"ok": True, "data": data}
        if request_id:
            envelope["request_id"] = request_id
        console.print_json(json.dumps(envelope))
        return

    if success_message:
        section_label = f" {title} " if title else " SUCCESS "
        status_style = "success"
        rule_width = console.width - 2
        console.print(Text(section_label, style=f"bold {status_style}"))
        console.print(Text("─" * rule_width, style=status_style))
        console.print("")
        console.print(Text(success_message, style="primary"))
        console.print("")
        return

    for key, value in payload.items():
        console.print(f"[label]{key}:[/label] [primary]{value}[/primary]")


def emit_error(error: CliError, *, json_output: bool) -> None:
    """Print a structured CLI error."""
    if json_output:
        payload: dict[str, Any] = {
            "ok": False,
            "error": error.to_payload(),
        }
        if error.request_id:
            payload["request_id"] = error.request_id
        console.print_json(json.dumps(payload))
        return

    lines = [error.message]
    if error.hint:
        lines.append(f"Hint: {error.hint}")
    if error.http_status is not None:
        lines.append(f"HTTP status: {error.http_status}")
    if error.extra:
        for key in sorted(error.extra.keys()):
            value = error.extra[key]
            if isinstance(value, (str, int, float, bool)) or value is None:
                lines.append(f"{key}: {value}")
            else:
                lines.append(f"{key}: {json.dumps(value, default=str)}")
    if error.request_id:
        lines.append(f"Request ID: {error.request_id}")
    rule_width = console.width - 2
    console.print(Text(" ERROR ", style="bold error"))
    console.print(Text("─" * rule_width, style="error"))
    console.print("")
    console.print(Text("\n".join(lines), style="error"))
    console.print("")
