"""Typer application entrypoint for the Python CLI."""

from __future__ import annotations

import sys
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import Any

import click
import typer
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from typer.main import get_command

from aimp_cli.clients.docker import DockerClient
from aimp_cli.clients.gateway import GatewayClient, UploadClient
from aimp_cli.commands import auth as auth_commands
from aimp_cli.commands import compose as compose_commands
from aimp_cli.commands import contract as contract_commands
from aimp_cli.commands import fine_tune as fine_tune_commands
from aimp_cli.commands import jobs as jobs_commands
from aimp_cli.commands import model as model_commands
from aimp_cli.commands import publish as publish_commands
from aimp_cli.commands import secret as secret_commands
from aimp_cli.commands import skills as skills_commands
from aimp_cli.commands.common import CommandRuntime
from aimp_cli.core.cli.bootstrap import create_cli_apps
from aimp_cli.core.config import (
    ZINC_THEME,
    build_command_context,
    can_prompt_for_input,
    config_store,
    emit_result,
    has_interactive_terminal,
    require_tty,
    resolve_auth_context,
)
from aimp_cli.core.errors import ExitCode
from aimp_cli.core.launcher import LauncherActionResult, confirm_action, prompt_secret, prompt_text
from aimp_cli.domain.models import CliPublishResult, ModeContract
from aimp_cli.domain.project_config import ProjectConfig
from aimp_cli.operations.fine_tune.tuning import (
    create_tuning_bundle_archive,
    default_fine_tune_scaffold_output_dir,
    load_local_tuning_contract,
    load_sdk_symbol,
    resolve_fine_tune_bundle_path,
    resolve_fine_tune_output_dir,
)
from aimp_cli.operations.publish.core import run_publish
from aimp_cli.operations.publish.service import build_publish_success_message
from aimp_cli.presentation.renderers import (
    render_auth_panel,
    render_fine_tune_job,
    render_fine_tune_list,
    render_job_action,
    render_job_detail,
    render_jobs_list,
    render_model_inspect,
)
from aimp_cli.utils.interactive import interactive_launcher as run_interactive_launcher_flow
from aimp_cli.utils.service_interactive import (
    interactive_console_capture,
    launch_interactive_launcher,
    run_interactive_action,
)

console = Console(theme=ZINC_THEME)
_cli_apps = create_cli_apps()
app = _cli_apps.app
jobs_app = _cli_apps.jobs_app
model_app = _cli_apps.model_app
contract_app = _cli_apps.contract_app
fine_tune_app = _cli_apps.fine_tune_app
skills_app = _cli_apps.skills_app
secret_app = _cli_apps.secret_app
compose_app = _cli_apps.compose_app

__all__ = [
    "ModeContract",
    "ProjectConfig",
    "app",
    "auth",
    "compose_app",
    "compose_generate",
    "compose_validate",
    "console",
    "contract_app",
    "contract_edit",
    "contract_show",
    "contract_validate",
    "fine_tune_app",
    "fine_tune_create",
    "fine_tune_get",
    "fine_tune_list",
    "fine_tune_scaffold",
    "fine_tune_schema",
    "init",
    "interactive_launcher",
    "jobs_app",
    "jobs_get",
    "jobs_list",
    "jobs_watch",
    "login",
    "logout",
    "main",
    "model_app",
    "model_inspect",
    "model_pull",
    "push",
    "secret_app",
    "secret_delete",
    "secret_list",
    "secret_set",
    "run_interactive_launcher_flow",
    "skills_app",
    "skills_list",
]


def _runtime() -> CommandRuntime:
    """Build the current command runtime using app-module globals."""
    return CommandRuntime(
        console=console,
        build_command_context=build_command_context,
        emit_result=emit_result,
        config_store=config_store,
        has_interactive_terminal=has_interactive_terminal,
        can_prompt_for_input=can_prompt_for_input,
        require_tty=require_tty,
        resolve_auth_context=resolve_auth_context,
        prompt_text=prompt_text,
        prompt_secret=prompt_secret,
        confirm_action=confirm_action,
        gateway_client_cls=GatewayClient,
        upload_client_cls=UploadClient,
        docker_client_cls=DockerClient,
        run_publish=run_publish,
    )


@contextmanager
def _interactive_console_capture() -> Iterator[Console]:
    """Temporarily route command output into a recording console for the launcher."""
    global console
    original_console = console
    with interactive_console_capture(console) as recording_console:
        console = recording_console
        try:
            yield recording_console
        finally:
            console = original_console


def _run_interactive_action(
    *,
    title: str,
    subtitle: str | None,
    status: str,
    fallback_success_message: str,
    callback: Any,
) -> Any:
    """Execute one existing CLI command and capture its output for the launcher."""
    return run_interactive_action(
        capture_console=_interactive_console_capture,
        title=title,
        subtitle=subtitle,
        status=status,
        fallback_success_message=fallback_success_message,
        callback=callback,
    )


def _prompt_multi_select_values(
    *,
    title: str,
    subtitle: str,
    values: list[str],
    descriptions: dict[str, str],
    preselected: list[str],
) -> list[str]:
    """Prompt for one canonical multi-select list."""
    return contract_commands.prompt_multi_select_values(
        runtime=_runtime(),
        title=title,
        subtitle=subtitle,
        values=values,
        descriptions=descriptions,
        preselected=preselected,
    )


def _prompt_public_modes(*, default: list[str]) -> list[str]:
    """Prompt for one set of public modes."""
    return contract_commands.prompt_public_modes(runtime=_runtime(), default=default)


def _prompt_vector_db_support(*, default: bool) -> bool:
    """Prompt for Vector DB support."""
    return contract_commands.prompt_vector_db_support(runtime=_runtime(), default=default)


def _prompt_fine_tune_support(*, default: bool) -> bool:
    """Prompt for fine-tune support."""
    return contract_commands.prompt_fine_tune_support(runtime=_runtime(), default=default)


def _prompt_contract_config(existing: ProjectConfig | None = None) -> ProjectConfig:
    """Interactively prompt for local hidden contract settings."""
    return contract_commands.prompt_contract_config(
        existing=existing,
        prompt_public_modes_fn=_prompt_public_modes,
        prompt_multi_select_values_fn=_prompt_multi_select_values,
        prompt_vector_db_support_fn=_prompt_vector_db_support,
        prompt_fine_tune_support_fn=_prompt_fine_tune_support,
    )


def _launcher_list_active_build(*, slug: str) -> dict[str, Any] | None:
    """Return one active publish build job payload for the launcher."""
    try:
        context = _runtime().build_command_context("push", debug=False, json_output=False)
        auth_context = _runtime().resolve_auth_context(gateway=None, api_key=None)
        if not auth_context.api_key:
            return None
        client = _runtime().gateway_client_cls(auth_context, context)
        try:
            payload = client.list_publish_build_groups(model_slug=None, page_size=100)
            for job in payload.results:
                if job.status in {"queued", "running"}:
                    return job.model_dump()
            return None
        finally:
            client.close()
    except Exception:
        return None


def _launcher_cancel_build(*, job_id: str) -> LauncherActionResult | None:
    """Cancel a publish build job from the launcher."""
    from aimp_cli.core.errors import CliError

    try:
        context = _runtime().build_command_context("push", debug=False, json_output=False)
        auth_context = _runtime().resolve_auth_context(gateway=None, api_key=None)
        if not auth_context.api_key:
            return LauncherActionResult(
                title="Cancel Build",
                content="Not authenticated. Run: ai login",
                status="error",
            )
        client = _runtime().gateway_client_cls(auth_context, context)
        try:
            payload = client.cancel_publish_build_group(job_id)
            status_word = "canceling" if payload.cancel_state == "canceling" else "canceled"
            return LauncherActionResult(
                title="Cancel Build",
                content=f"Build {job_id[:8]} {status_word}.",
                status="success",
            )
        except CliError as error:
            return LauncherActionResult(
                title="Cancel Build",
                content=str(error.message),
                status="error",
            )
        finally:
            client.close()
    except Exception as error:
        return LauncherActionResult(
            title="Cancel Build",
            content=str(error),
            status="error",
        )


def _build_publish_success_message(result: CliPublishResult) -> str:
    """Build the human-readable publish success summary."""
    return build_publish_success_message(result)


def _prompt_project_name() -> str:
    """Prompt for a new project name."""
    from aimp_cli.commands import project as project_commands

    return project_commands.prompt_project_name(runtime=_runtime())


def _load_sdk_symbol(name: str) -> Any:
    """Load one SDK symbol from the installed package or repo-local fallback."""
    return load_sdk_symbol(name)


def _load_local_tuning_contract(
    project_dir: Path,
    *,
    tuning_model: str | None = None,
) -> dict[str, Any]:
    """Load the local fine-tune contract and schema payload."""
    return load_local_tuning_contract(project_dir, tuning_model=tuning_model)


def _create_tuning_bundle_archive(
    *,
    schema_contract: dict[str, Any],
    bundle_path: Path,
) -> tuple[Any, str]:
    """Build one uploadable fine-tune bundle archive."""
    return create_tuning_bundle_archive(schema_contract=schema_contract, bundle_path=bundle_path)


def _default_fine_tune_scaffold_output_dir(model_slug: str) -> Path:
    """Return the default local output directory for a consumer scaffold."""
    return default_fine_tune_scaffold_output_dir(model_slug)


def _resolve_fine_tune_bundle_path(*, bundle: Path | None) -> Path:
    """Resolve one explicit fine-tune bundle file path."""
    return resolve_fine_tune_bundle_path(bundle=bundle)


def _resolve_fine_tune_output_dir(
    *,
    model_slug: str,
    workspace: Path | None,
    output_dir: Path | None,
) -> Path:
    """Resolve the local fine-tune scaffold workspace directory."""
    return resolve_fine_tune_output_dir(
        model_slug=model_slug,
        workspace=workspace,
        output_dir=output_dir,
    )


@app.command()
def init(
    name: str | None = typer.Argument(None),
    yes: bool = typer.Option(False, "--yes", "-y", help="Create without confirmation"),
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable output"),
    debug: bool = typer.Option(False, "--debug", help="Emit debug logs to stderr"),
) -> None:
    """Initialize a new framework project."""
    from aimp_cli.commands import project as project_commands

    project_commands.init_command(
        runtime=_runtime(),
        name=name,
        yes=yes,
        json_output=json_output,
        debug=debug,
        prompt_project_name_fn=_prompt_project_name,
    )


@skills_app.command("list")
def skills_list(
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable output"),
    debug: bool = typer.Option(False, "--debug", help="Emit debug logs to stderr"),
) -> None:
    """List project-local skills for the current project."""
    skills_commands.skills_list_command(
        runtime=_runtime(),
        json_output=json_output,
        debug=debug,
    )


@compose_app.command("validate")
def compose_validate(
    python_bin: str | None = typer.Option(None, "--python", help="Python interpreter override"),
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable output"),
    debug: bool = typer.Option(False, "--debug", help="Emit debug logs to stderr"),
) -> None:
    """Validate docker-compose.yml against declared workers."""
    compose_commands.validate_compose_command(
        runtime=_runtime(),
        python_bin=python_bin,
        json_output=json_output,
        debug=debug,
    )


@compose_app.command("generate")
def compose_generate(
    output: Path | None = typer.Option(
        None, "--output", "-o", help="Output file path (default: docker-compose.yml)"
    ),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show output without writing file"),
    python_bin: str | None = typer.Option(None, "--python", help="Python interpreter override"),
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable output"),
    debug: bool = typer.Option(False, "--debug", help="Emit debug logs to stderr"),
) -> None:
    """Generate docker-compose.yml from Agent.workers declarations."""
    compose_commands.generate_compose_command(
        runtime=_runtime(),
        output=output,
        python_bin=python_bin,
        dry_run=dry_run,
        json_output=json_output,
        debug=debug,
    )


@app.command()
def login(
    gateway: str | None = typer.Option(None, "--gateway", help="Gateway URL"),
    api_key: str | None = typer.Option(None, "--api-key", help="API key"),
    stdin: bool = typer.Option(False, "--stdin", help="Read the API key from stdin"),
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable output"),
    debug: bool = typer.Option(False, "--debug", help="Emit debug logs to stderr"),
) -> None:
    """Authenticate and store credentials."""
    auth_commands.login_command(
        runtime=_runtime(),
        gateway=gateway,
        api_key=api_key,
        stdin=stdin,
        json_output=json_output,
        debug=debug,
    )


@app.command()
def logout(
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable output"),
    debug: bool = typer.Option(False, "--debug", help="Emit debug logs to stderr"),
) -> None:
    """Remove stored credentials."""
    auth_commands.logout_command(runtime=_runtime(), json_output=json_output, debug=debug)


@app.command()
def auth(
    gateway: str | None = typer.Option(None, "--gateway", help="Gateway URL override"),
    api_key: str | None = typer.Option(None, "--api-key", help="API key override"),
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable output"),
    debug: bool = typer.Option(False, "--debug", help="Emit debug logs to stderr"),
) -> None:
    """Show current authentication status."""
    auth_commands.auth_command(
        runtime=_runtime(),
        gateway=gateway,
        api_key=api_key,
        json_output=json_output,
        debug=debug,
        render_auth_panel=lambda **kwargs: render_auth_panel(console=console, **kwargs),
    )


@contract_app.command("edit")
def contract_edit(
    modes: str | None = typer.Option(
        None,
        "--modes",
        help="Comma-separated public mode names. At least one is required.",
    ),
    mode_inputs: list[str] | None = typer.Option(
        None,
        "--mode-inputs",
        help="Repeatable <mode>=<csv> input modalities, for example search=image,text.",
    ),
    mode_outputs: list[str] | None = typer.Option(
        None,
        "--mode-outputs",
        help="Repeatable <mode>=<name>:<kind>[,...] output fields, for example execute=summary:text,report:json.",
    ),
    vector_db: bool | None = typer.Option(
        None,
        "--vector-db/--no-vector-db",
        help="Enable or disable vector resource capability for this model.",
    ),
    fine_tune: bool | None = typer.Option(
        None,
        "--fine-tune/--no-fine-tune",
        help="Enable or disable fine-tune support for this project.",
    ),
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable output"),
    debug: bool = typer.Option(False, "--debug", help="Emit debug logs to stderr"),
) -> None:
    """Edit the hidden local contract."""
    contract_commands.contract_edit_command(
        runtime=_runtime(),
        modes=modes,
        mode_inputs=mode_inputs,
        mode_outputs=mode_outputs,
        vector_db=vector_db,
        fine_tune=fine_tune,
        json_output=json_output,
        debug=debug,
        prompt_contract_config_fn=_prompt_contract_config,
    )


@contract_app.command("validate")
def contract_validate(
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable output"),
    debug: bool = typer.Option(False, "--debug", help="Emit debug logs to stderr"),
) -> None:
    """Validate the hidden local contract."""
    contract_commands.contract_validate_command(
        runtime=_runtime(),
        json_output=json_output,
        debug=debug,
    )


@contract_app.command("show")
def contract_show(
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable output"),
    debug: bool = typer.Option(False, "--debug", help="Emit debug logs to stderr"),
) -> None:
    """Show the hidden local contract."""
    contract_commands.contract_show_command(
        runtime=_runtime(),
        json_output=json_output,
        debug=debug,
    )


@contract_app.command("diff")
def contract_diff(
    python_bin: str | None = typer.Option(None, "--python", help="Python interpreter override"),
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable output"),
    debug: bool = typer.Option(False, "--debug", help="Emit debug logs to stderr"),
) -> None:
    """Compare .aimp/project.toml modes with SDK-declared modes.

    Shows differences between modes declared in .aimp/project.toml vs SDK.
    """
    contract_commands.contract_diff_command(
        runtime=_runtime(),
        python_bin=python_bin,
        json_output=json_output,
        debug=debug,
    )


@contract_app.command("sync")
def contract_sync(
    python_bin: str | None = typer.Option(None, "--python", help="Python interpreter override"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show changes without writing"),
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable output"),
    debug: bool = typer.Option(False, "--debug", help="Emit debug logs to stderr"),
) -> None:
    """Synchronize .aimp/project.toml modes with SDK-declared modes.

    Updates .aimp/project.toml to match modes declared in SDK.
    """
    contract_commands.contract_sync_command(
        runtime=_runtime(),
        python_bin=python_bin,
        dry_run=dry_run,
        json_output=json_output,
        debug=debug,
    )


@secret_app.command("set")
def secret_set(
    name: str = typer.Argument(..., help="Secret env var name, for example ZAI_API_KEY"),
    model: str | None = typer.Option(None, "--model", help="Target model slug override"),
    stdin: bool = typer.Option(False, "--stdin", help="Read the secret value from stdin"),
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable output"),
    debug: bool = typer.Option(False, "--debug", help="Emit debug logs to stderr"),
) -> None:
    """Set or rotate one model-scoped runtime secret."""
    secret_commands.secret_set_command(
        runtime=_runtime(),
        name=name,
        model=model,
        stdin=stdin,
        json_output=json_output,
        debug=debug,
    )


@secret_app.command("list")
def secret_list(
    model: str | None = typer.Option(None, "--model", help="Target model slug override"),
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable output"),
    debug: bool = typer.Option(False, "--debug", help="Emit debug logs to stderr"),
) -> None:
    """List configured model-scoped runtime secrets."""
    secret_commands.secret_list_command(
        runtime=_runtime(),
        model=model,
        json_output=json_output,
        debug=debug,
    )


@secret_app.command("delete")
def secret_delete(
    name: str = typer.Argument(..., help="Secret env var name to delete"),
    model: str | None = typer.Option(None, "--model", help="Target model slug override"),
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable output"),
    debug: bool = typer.Option(False, "--debug", help="Emit debug logs to stderr"),
) -> None:
    """Delete one model-scoped runtime secret."""
    secret_commands.secret_delete_command(
        runtime=_runtime(),
        name=name,
        model=model,
        json_output=json_output,
        debug=debug,
    )


@app.command()
def push(
    gateway: str | None = typer.Option(None, "--gateway", help="Gateway URL override"),
    api_key: str | None = typer.Option(None, "--api-key", help="API key override"),
    slug: str | None = typer.Option(
        None, "--slug", help="Publish an existing remote model by slug"
    ),
    hardware: str | None = typer.Option(
        None,
        "--hardware",
        help="Deployment hardware SKU (for example: cpu-basic)",
    ),
    parallel: int = typer.Option(3, "--parallel", min=1, max=8, help="Upload concurrency (1-8)"),
    configure: bool = typer.Option(
        False,
        "--configure",
        help="Open the guided publish configuration flow without publishing",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Cancel any active build for this model and start a new one",
    ),
    detach: bool = typer.Option(
        False,
        "--detach",
        help="Start or reuse the remote build and return immediately without waiting",
    ),
    verbose: bool = typer.Option(False, "--verbose", help="Show live Docker logs"),
    python_bin: str | None = typer.Option(None, "--python", help="Python interpreter override"),
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable output"),
    debug: bool = typer.Option(False, "--debug", help="Emit debug logs to stderr"),
) -> None:
    """Publish project to the platform.

    Use --hardware <sku> to request a specific deployment tier.
    """
    publish_commands.run_publish_command(
        runtime=_runtime(),
        gateway=gateway,
        api_key=api_key,
        slug=slug,
        parallel=parallel,
        hardware=hardware,
        verbose=verbose,
        json_output=json_output,
        debug=debug,
        python_bin=python_bin,
        configure_only=configure,
        force=force,
        detach=detach,
        build_publish_success_message=_build_publish_success_message,
    )


@jobs_app.command("list")
def jobs_list(
    type: str = typer.Option(
        "all",
        "--type",
        help="Job type filter: all, build, or fine-tune",
    ),
    model: str | None = typer.Option(None, "--model", help="Filter by published model slug"),
    status: str | None = typer.Option(None, "--status", help="Filter by job status"),
    page: int = typer.Option(1, "--page", min=1, help="Page number"),
    page_size: int = typer.Option(20, "--page-size", min=1, max=100, help="Page size"),
    gateway: str | None = typer.Option(None, "--gateway", help="Gateway URL override"),
    api_key: str | None = typer.Option(None, "--api-key", help="API key override"),
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable output"),
    debug: bool = typer.Option(False, "--debug", help="Emit debug logs to stderr"),
) -> None:
    """List workspace jobs."""
    jobs_commands.jobs_list_command(
        runtime=_runtime(),
        job_type=type,
        model=model,
        status=status,
        page=page,
        page_size=page_size,
        gateway=gateway,
        api_key=api_key,
        json_output=json_output,
        debug=debug,
        render_jobs_list=lambda payload: render_jobs_list(console, payload),
    )


@jobs_app.command("get")
def jobs_get(
    type: str = typer.Option(..., "--type", help="Job type: build or fine-tune"),
    job: str = typer.Option(..., "--job", help="Job ID"),
    gateway: str | None = typer.Option(None, "--gateway", help="Gateway URL override"),
    api_key: str | None = typer.Option(None, "--api-key", help="API key override"),
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable output"),
    debug: bool = typer.Option(False, "--debug", help="Emit debug logs to stderr"),
) -> None:
    """Get a single workspace job."""
    jobs_commands.jobs_get_command(
        runtime=_runtime(),
        job_type=type,
        job=job,
        gateway=gateway,
        api_key=api_key,
        json_output=json_output,
        debug=debug,
        render_job_detail=lambda payload: render_job_detail(console, payload),
    )


@jobs_app.command("watch")
def jobs_watch(
    job: str = typer.Option(..., "--job", help="Job ID"),
    type: str = typer.Option(..., "--type", help="Job type: build or fine-tune"),
    gateway: str | None = typer.Option(None, "--gateway", help="Gateway URL override"),
    api_key: str | None = typer.Option(None, "--api-key", help="API key override"),
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable output"),
    debug: bool = typer.Option(False, "--debug", help="Emit debug logs to stderr"),
) -> None:
    """Watch one workspace job live."""
    jobs_commands.jobs_watch_command(
        runtime=_runtime(),
        job_type=type,
        job=job,
        gateway=gateway,
        api_key=api_key,
        json_output=json_output,
        debug=debug,
    )


@jobs_app.command("cancel")
def jobs_cancel(
    type: str = typer.Option(..., "--type", help="Job type: build or fine-tune"),
    job: str = typer.Option(..., "--job", help="Job ID"),
    gateway: str | None = typer.Option(None, "--gateway", help="Gateway URL override"),
    api_key: str | None = typer.Option(None, "--api-key", help="API key override"),
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable output"),
    debug: bool = typer.Option(False, "--debug", help="Emit debug logs to stderr"),
) -> None:
    """Cancel one job."""
    jobs_commands.jobs_cancel_command(
        runtime=_runtime(),
        job_type=type,
        job=job,
        gateway=gateway,
        api_key=api_key,
        json_output=json_output,
        debug=debug,
        render_job_action=lambda payload: render_job_action(console, payload),
    )


@jobs_app.command("delete")
def jobs_delete(
    type: str = typer.Option(..., "--type", help="Job type: build or fine-tune"),
    job: str = typer.Option(..., "--job", help="Job ID"),
    gateway: str | None = typer.Option(None, "--gateway", help="Gateway URL override"),
    api_key: str | None = typer.Option(None, "--api-key", help="API key override"),
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable output"),
    debug: bool = typer.Option(False, "--debug", help="Emit debug logs to stderr"),
) -> None:
    """Delete one terminal job from history."""
    jobs_commands.jobs_delete_command(
        runtime=_runtime(),
        job_type=type,
        job=job,
        gateway=gateway,
        api_key=api_key,
        json_output=json_output,
        debug=debug,
        render_job_action=lambda payload: render_job_action(console, payload),
    )


@fine_tune_app.command("schema")
def fine_tune_schema(
    model: str | None = typer.Option(None, "--model", help="Published model slug"),
    tuning_model: str | None = typer.Option(
        None,
        "--tuning-model",
        help="Local model key override for tuning discovery",
    ),
    gateway: str | None = typer.Option(None, "--gateway", help="Gateway URL override"),
    api_key: str | None = typer.Option(None, "--api-key", help="API key override"),
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable output"),
    debug: bool = typer.Option(False, "--debug", help="Emit debug logs to stderr"),
) -> None:
    """Show the fine-tune schema for a local or published model."""
    fine_tune_commands.fine_tune_schema_command(
        runtime=_runtime(),
        model=model,
        tuning_model=tuning_model,
        gateway=gateway,
        api_key=api_key,
        json_output=json_output,
        debug=debug,
        load_local_tuning_contract=_load_local_tuning_contract,
    )


@fine_tune_app.command("scaffold")
def fine_tune_scaffold(
    model: str = typer.Option(..., "--model", help="Published model slug"),
    output: Path | None = typer.Option(  # noqa: B008
        None,
        "--output",
        help="Local output directory for generated scaffold files",
    ),
    regenerate: bool = typer.Option(
        False,
        "--regenerate",
        help="Only update .tuning/ folder, preserve user edits",
    ),
    gateway: str | None = typer.Option(None, "--gateway", help="Gateway URL override"),
    api_key: str | None = typer.Option(None, "--api-key", help="API key override"),
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable output"),
    debug: bool = typer.Option(False, "--debug", help="Emit debug logs to stderr"),
) -> None:
    """Generate a consumer-facing fine-tune scaffold from a published schema."""
    fine_tune_commands.fine_tune_scaffold_command(
        runtime=_runtime(),
        model=model,
        output=output,
        regenerate=regenerate,
        gateway=gateway,
        api_key=api_key,
        json_output=json_output,
        debug=debug,
        default_fine_tune_scaffold_output_dir=_default_fine_tune_scaffold_output_dir,
    )


@fine_tune_app.command("create")
def fine_tune_create(
    model: str = typer.Option(..., "--model", help="Published model slug"),
    bundle: Path | None = typer.Option(  # noqa: B008
        None,
        "--bundle",
        help="Local fine-tune bundle JSON path",
    ),
    workspace: Path | None = typer.Option(  # noqa: B008
        None,
        "--workspace",
        help="Directory containing bundle.json",
    ),
    output_dir: Path | None = typer.Option(  # noqa: B008
        None,
        "--output-dir",
        help="Directory used for generated fine-tune scaffold files",
    ),
    max_trials: int = typer.Option(5, "--max-trials", min=1, help="Auto-tune trial budget"),
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Cancel any active fine-tune for this model and start a new one",
    ),
    gateway: str | None = typer.Option(None, "--gateway", help="Gateway URL override"),
    api_key: str | None = typer.Option(None, "--api-key", help="API key override"),
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable output"),
    debug: bool = typer.Option(False, "--debug", help="Emit debug logs to stderr"),
) -> None:
    """Create a new fine-tune job for a published model."""
    fine_tune_commands.fine_tune_create_command(
        runtime=_runtime(),
        model=model,
        bundle=bundle,
        workspace=workspace,
        output_dir=output_dir,
        max_trials=max_trials,
        force=force,
        gateway=gateway,
        api_key=api_key,
        json_output=json_output,
        debug=debug,
        resolve_fine_tune_output_dir=_resolve_fine_tune_output_dir,
        resolve_fine_tune_bundle_path=_resolve_fine_tune_bundle_path,
        create_tuning_bundle_archive=_create_tuning_bundle_archive,
        render_fine_tune_job=lambda payload: render_fine_tune_job(console, payload),
    )


@fine_tune_app.command("list")
def fine_tune_list(
    model: str | None = typer.Option(None, "--model", help="Filter by published model slug"),
    status: str | None = typer.Option(None, "--status", help="Filter by job status"),
    page: int = typer.Option(1, "--page", min=1, help="Page number"),
    page_size: int = typer.Option(20, "--page-size", min=1, max=100, help="Page size"),
    gateway: str | None = typer.Option(None, "--gateway", help="Gateway URL override"),
    api_key: str | None = typer.Option(None, "--api-key", help="API key override"),
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable output"),
    debug: bool = typer.Option(False, "--debug", help="Emit debug logs to stderr"),
) -> None:
    """List workspace-scoped fine-tune jobs."""
    fine_tune_commands.fine_tune_list_command(
        runtime=_runtime(),
        model=model,
        status=status,
        page=page,
        page_size=page_size,
        gateway=gateway,
        api_key=api_key,
        json_output=json_output,
        debug=debug,
        render_fine_tune_list=lambda payload: render_fine_tune_list(console, payload),
    )


@fine_tune_app.command("get")
def fine_tune_get(
    job: str = typer.Option(..., "--job", help="Fine-tune job ID"),
    gateway: str | None = typer.Option(None, "--gateway", help="Gateway URL override"),
    api_key: str | None = typer.Option(None, "--api-key", help="API key override"),
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable output"),
    debug: bool = typer.Option(False, "--debug", help="Emit debug logs to stderr"),
) -> None:
    """Get a single fine-tune job."""
    fine_tune_commands.fine_tune_get_command(
        runtime=_runtime(),
        job=job,
        gateway=gateway,
        api_key=api_key,
        json_output=json_output,
        debug=debug,
        render_fine_tune_job=lambda payload: render_fine_tune_job(console, payload),
    )


@model_app.command("inspect")
def model_inspect(
    slug: str | None = typer.Option(None, "--slug", help="Model slug"),
    asset_id: str | None = typer.Option(None, "--id", help="Model asset UUID"),
    modes: str | None = typer.Option(
        None, "--modes", help="Comma-separated public modes to filter"
    ),
    gateway: str | None = typer.Option(None, "--gateway", help="Gateway URL override"),
    api_key: str | None = typer.Option(None, "--api-key", help="API key override"),
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable output"),
    debug: bool = typer.Option(False, "--debug", help="Emit debug logs to stderr"),
) -> None:
    """Inspect model metadata and pricing."""
    model_commands.model_inspect_command(
        runtime=_runtime(),
        slug=slug,
        asset_id=asset_id,
        modes=modes,
        gateway=gateway,
        api_key=api_key,
        json_output=json_output,
        debug=debug,
        render_model_inspect=lambda payload: render_model_inspect(console, payload),
    )


@model_app.command("pull")
def model_pull(
    slug: str | None = typer.Option(None, "--slug", help="Model slug"),
    asset_id: str | None = typer.Option(None, "--id", help="Model asset UUID"),
    gateway: str | None = typer.Option(None, "--gateway", help="Gateway URL override"),
    api_key: str | None = typer.Option(None, "--api-key", help="API key override"),
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable output"),
    debug: bool = typer.Option(False, "--debug", help="Emit debug logs to stderr"),
) -> None:
    """Pull remote metadata into local project files."""
    model_commands.model_pull_command(
        runtime=_runtime(),
        slug=slug,
        asset_id=asset_id,
        gateway=gateway,
        api_key=api_key,
        json_output=json_output,
        debug=debug,
    )


def _build_launcher_callbacks() -> "LauncherCallbacks":
    """Construct raw (unwrapped) launcher callbacks for the interactive launcher."""
    from aimp_cli.utils.interactive import LauncherCallbacks

    return LauncherCallbacks(
        init_project=lambda name: init(
            name=name,
            yes=True,
            json_output=False,
            debug=False,
        ),
        configure_project=lambda: contract_edit(
            modes=None,
            mode_inputs=None,
            mode_outputs=None,
            vector_db=None,
            fine_tune=None,
            json_output=False,
            debug=False,
        ),
        validate_contract=lambda: contract_validate(json_output=False, debug=False),
        show_contract=lambda: contract_show(json_output=False, debug=False),
        configure_publish=lambda: push(
            gateway=None,
            api_key=None,
            slug=None,
            hardware=None,
            parallel=3,
            configure=True,
            force=False,
            detach=False,
            verbose=False,
            python_bin=None,
            json_output=False,
            debug=False,
        ),
        publish_project=lambda hardware: push(
            gateway=None,
            api_key=None,
            slug=None,
            hardware=hardware,
            parallel=3,
            configure=False,
            force=False,
            detach=False,
            verbose=False,
            python_bin=None,
            json_output=False,
            debug=False,
        ),
        create_fine_tune_job=lambda model_slug, dataset_path: fine_tune_create(
            model=model_slug,
            bundle=None if Path(dataset_path).expanduser().is_dir() else Path(dataset_path),
            workspace=Path(dataset_path) if Path(dataset_path).expanduser().is_dir() else None,
            output_dir=None,
            max_trials=5,
            gateway=None,
            api_key=None,
            json_output=False,
            debug=False,
        ),
        list_jobs=lambda job_type: jobs_list(
            type=job_type,
            model=None,
            status=None,
            page=1,
            page_size=20,
            gateway=None,
            api_key=None,
            json_output=True,
            debug=False,
        ),
        get_job_detail=lambda job_type, job_id: jobs_get(
            type=job_type,
            job=job_id,
            gateway=None,
            api_key=None,
            json_output=False,
            debug=False,
        ),
        cancel_job=lambda job_type, job_id: jobs_cancel(
            type=job_type,
            job=job_id,
            gateway=None,
            api_key=None,
            json_output=False,
            debug=False,
        ),
        delete_job=lambda job_type, job_id: jobs_delete(
            type=job_type,
            job=job_id,
            gateway=None,
            api_key=None,
            json_output=False,
            debug=False,
        ),
        login=lambda gateway, api_key: login(
            gateway=gateway,
            api_key=api_key,
            stdin=False,
            json_output=False,
            debug=False,
        ),
        auth=lambda: auth(
            gateway=None,
            api_key=None,
            json_output=False,
            debug=False,
        ),
        logout=lambda: logout(json_output=False, debug=False),
        inspect_model=lambda slug: model_inspect(
            slug=slug,
            asset_id=None,
            modes=None,
            gateway=None,
            api_key=None,
            json_output=False,
            debug=False,
        ),
        pull_model=lambda slug: model_pull(
            slug=slug,
            asset_id=None,
            gateway=None,
            api_key=None,
            json_output=False,
            debug=False,
        ),
        list_active_build=lambda slug: _launcher_list_active_build(slug=slug),
        cancel_build=lambda job_id: _launcher_cancel_build(job_id=job_id),
    )


def interactive_launcher() -> None:
    """Prompt-driven launcher for human TTY usage."""
    launch_interactive_launcher(
        console=console,
        config_store=config_store,
        run_interactive_launcher_flow=run_interactive_launcher_flow,
        capture_console=_interactive_console_capture,
        run_interactive_action=_run_interactive_action,
        callbacks=_build_launcher_callbacks(),
    )


def main() -> None:
    """Entry point for the CLI."""

    try:
        if len(sys.argv) == 1:
            if has_interactive_terminal():
                console.print("[dim]Starting interactive mode...[/dim]")
                interactive_launcher()
                return
            get_command(app).main(args=["--help"], prog_name="ai", standalone_mode=False)
            return
        app()
    except typer.Exit as exit_error:
        sys.exit(exit_error.exit_code)
    except KeyboardInterrupt:
        sys.exit(int(ExitCode.INTERRUPTED))
    except click.ClickException as error:
        console.print(
            Panel(
                Text(error.format_message(), style="error"),
                title=" ERROR ",
                title_align="left",
                border_style="error",
            )
        )
        sys.exit(error.exit_code)
    except Exception as error:
        console.print(
            Panel(
                Text(str(error), style="error"),
                title=" ERROR ",
                title_align="left",
                border_style="error",
            )
        )
        sys.exit(1)
