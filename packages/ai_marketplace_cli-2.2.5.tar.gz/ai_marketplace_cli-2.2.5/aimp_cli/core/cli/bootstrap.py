"""Typer application bootstrap wiring."""

from __future__ import annotations

from dataclasses import dataclass

import typer


@dataclass(frozen=True)
class CliApps:
    """Collection of Typer applications used by the CLI."""

    app: typer.Typer
    jobs_app: typer.Typer
    model_app: typer.Typer
    contract_app: typer.Typer
    secret_app: typer.Typer
    fine_tune_app: typer.Typer
    skills_app: typer.Typer
    compose_app: typer.Typer


def create_cli_apps() -> CliApps:
    """Create the top-level and subcommand Typer applications."""
    app = typer.Typer(help="AI Marketplace Platform CLI")
    jobs_app = typer.Typer(help="List, inspect, cancel, or delete platform jobs")
    model_app = typer.Typer(help="Inspect model metadata, pricing, and pull model data")
    contract_app = typer.Typer(help="Edit, validate, and inspect model contracts")
    secret_app = typer.Typer(help="Manage model-scoped runtime secrets")
    fine_tune_app = typer.Typer(help="Create, monitor, and manage fine-tuning jobs")
    skills_app = typer.Typer(help="List and explore project-local skills")
    compose_app = typer.Typer(help="Validate and generate docker-compose.yml")
    app.add_typer(jobs_app, name="jobs")
    app.add_typer(model_app, name="model")
    app.add_typer(contract_app, name="contract")
    app.add_typer(secret_app, name="secret")
    app.add_typer(fine_tune_app, name="fine-tune")
    app.add_typer(skills_app, name="skills")
    app.add_typer(compose_app, name="compose")
    return CliApps(
        app=app,
        jobs_app=jobs_app,
        model_app=model_app,
        contract_app=contract_app,
        secret_app=secret_app,
        fine_tune_app=fine_tune_app,
        skills_app=skills_app,
        compose_app=compose_app,
    )
