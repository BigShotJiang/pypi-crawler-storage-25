"""CLI bootstrap package."""
