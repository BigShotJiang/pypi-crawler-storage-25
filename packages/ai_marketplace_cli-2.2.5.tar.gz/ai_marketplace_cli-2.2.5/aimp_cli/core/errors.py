"""CLI error types and exit-code helpers."""

from __future__ import annotations

from enum import IntEnum, StrEnum
from typing import Any


class ExitCode(IntEnum):
    """Stable process exit codes for the CLI."""

    SUCCESS = 0
    INTERNAL = 1
    USAGE = 2
    AUTH = 3
    ENVIRONMENT = 4
    NETWORK = 5
    REMOTE_STATE = 6
    INTERRUPTED = 130


class ErrorCategory(StrEnum):
    """High-level CLI error categories."""

    USAGE = "usage"
    AUTH = "auth"
    ENVIRONMENT = "environment"
    NETWORK = "network"
    REMOTE_STATE = "remote_state"
    INTERNAL = "internal"


class CliError(Exception):
    """Structured CLI error with a stable exit code."""

    def __init__(
        self,
        message: str,
        *,
        code: str,
        category: ErrorCategory,
        exit_code: ExitCode,
        request_id: str | None = None,
        hint: str | None = None,
        retryable: bool = False,
        http_status: int | None = None,
        extra: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.code = code
        self.category = category
        self.exit_code = exit_code
        self.request_id = request_id
        self.hint = hint
        self.retryable = retryable
        self.http_status = http_status
        self.extra = extra or {}

    def with_request_id(self, request_id: str) -> CliError:
        """Return a copy with a request identifier attached."""
        return CliError(
            self.message,
            code=self.code,
            category=self.category,
            exit_code=self.exit_code,
            request_id=request_id,
            hint=self.hint,
            retryable=self.retryable,
            http_status=self.http_status,
            extra=self.extra,
        )

    def to_payload(self) -> dict[str, Any]:
        """Return the machine-readable error payload."""
        payload: dict[str, Any] = {
            "code": self.code,
            "category": self.category.value,
            "message": self.message,
            "retryable": self.retryable,
            "exit_code": int(self.exit_code),
        }
        if self.hint:
            payload["hint"] = self.hint
        if self.http_status is not None:
            payload["http_status"] = self.http_status
        if self.extra:
            payload["details"] = self.extra
        return payload


def usage_error(
    message: str,
    *,
    code: str = "usage_error",
    request_id: str | None = None,
    hint: str | None = None,
    extra: dict[str, Any] | None = None,
) -> CliError:
    """Build a usage/configuration CLI error."""
    return CliError(
        message,
        code=code,
        category=ErrorCategory.USAGE,
        exit_code=ExitCode.USAGE,
        request_id=request_id,
        hint=hint,
        extra=extra,
    )


def auth_error(
    message: str,
    *,
    code: str = "authentication_failed",
    request_id: str | None = None,
    hint: str | None = None,
    http_status: int | None = None,
    extra: dict[str, Any] | None = None,
) -> CliError:
    """Build an authentication or authorization CLI error."""
    return CliError(
        message,
        code=code,
        category=ErrorCategory.AUTH,
        exit_code=ExitCode.AUTH,
        request_id=request_id,
        hint=hint,
        http_status=http_status,
        extra=extra,
    )


def environment_error(
    message: str,
    *,
    code: str = "environment_error",
    request_id: str | None = None,
    hint: str | None = None,
    extra: dict[str, Any] | None = None,
) -> CliError:
    """Build a local environment or dependency CLI error."""
    return CliError(
        message,
        code=code,
        category=ErrorCategory.ENVIRONMENT,
        exit_code=ExitCode.ENVIRONMENT,
        request_id=request_id,
        hint=hint,
        extra=extra,
    )


def network_error(
    message: str,
    *,
    code: str = "service_unavailable",
    request_id: str | None = None,
    hint: str | None = None,
    http_status: int | None = None,
    extra: dict[str, Any] | None = None,
) -> CliError:
    """Build a network or downstream availability CLI error."""
    return CliError(
        message,
        code=code,
        category=ErrorCategory.NETWORK,
        exit_code=ExitCode.NETWORK,
        request_id=request_id,
        hint=hint,
        retryable=True,
        http_status=http_status,
        extra=extra,
    )


def remote_state_error(
    message: str,
    *,
    code: str = "remote_state_error",
    request_id: str | None = None,
    hint: str | None = None,
    http_status: int | None = None,
    retryable: bool = False,
    extra: dict[str, Any] | None = None,
) -> CliError:
    """Build a remote resource or conflict CLI error."""
    return CliError(
        message,
        code=code,
        category=ErrorCategory.REMOTE_STATE,
        exit_code=ExitCode.REMOTE_STATE,
        request_id=request_id,
        hint=hint,
        retryable=retryable,
        http_status=http_status,
        extra=extra,
    )


def internal_error(
    message: str,
    *,
    code: str = "internal_error",
    request_id: str | None = None,
    hint: str | None = None,
    extra: dict[str, Any] | None = None,
) -> CliError:
    """Build an unexpected internal CLI error."""
    return CliError(
        message,
        code=code,
        category=ErrorCategory.INTERNAL,
        exit_code=ExitCode.INTERNAL,
        request_id=request_id,
        hint=hint,
        extra=extra,
    )


def cli_error_from_http_status(
    *,
    status_code: int,
    message: str,
    request_id: str | None = None,
    code: str | None = None,
    hint: str | None = None,
    retryable: bool | None = None,
    extra: dict[str, Any] | None = None,
) -> CliError:
    """Map an HTTP status to the CLI error contract."""
    resolved_hint = hint
    if code == "UPSTREAM_INVALID_ERROR_RESPONSE" and not resolved_hint:
        resolved_hint = (
            "The control plane returned a non-JSON error body (often HTML). "
            "Check Django or backend logs for this request_id."
        )
    if status_code in {401, 403}:
        return auth_error(
            message,
            code=code or "authentication_failed",
            request_id=request_id,
            hint=resolved_hint,
            http_status=status_code,
            extra=extra,
        )
    if status_code in {400, 422}:
        return usage_error(
            message,
            code=code or "validation_error",
            request_id=request_id,
            hint=resolved_hint,
            extra=extra,
        )
    if status_code in {402, 404, 409}:
        return remote_state_error(
            message,
            code=code or _default_remote_code(status_code),
            request_id=request_id,
            hint=resolved_hint,
            http_status=status_code,
            retryable=retryable or False,
            extra=extra,
        )
    if status_code >= 500:
        return network_error(
            message,
            code=code or "service_unavailable",
            request_id=request_id,
            hint=resolved_hint,
            http_status=status_code,
            extra=extra,
        )
    return internal_error(
        message,
        code=code or "http_error",
        request_id=request_id,
        hint=resolved_hint,
        extra=extra,
    )


def coerce_cli_error(error: Exception, *, request_id: str) -> CliError:
    """Coerce an unexpected exception into the CLI error contract."""
    if isinstance(error, CliError):
        if error.request_id:
            return error
        return error.with_request_id(request_id)

    message = str(error).strip() or error.__class__.__name__
    if isinstance(error, KeyboardInterrupt):
        return CliError(
            "Interrupted",
            code="interrupted",
            category=ErrorCategory.INTERNAL,
            exit_code=ExitCode.INTERRUPTED,
            request_id=request_id,
        )
    if _looks_like_usage_error(message):
        return usage_error(message, code="validation_error", request_id=request_id)
    if _looks_like_network_error(message):
        return network_error(message, request_id=request_id, code="service_unavailable")
    if _looks_like_environment_error(message):
        return environment_error(message, request_id=request_id)
    return internal_error(message, request_id=request_id)


def _default_remote_code(status_code: int) -> str:
    """Return the default remote-state code for an HTTP status."""
    mapping = {
        402: "quota_exceeded",
        404: "resource_not_found",
        409: "conflict",
    }
    return mapping.get(status_code, "remote_state_error")


def _looks_like_usage_error(message: str) -> bool:
    """Return whether a raw message looks like a usage/config issue."""
    patterns = (
        "Provide --",
        "Config file not found",
        "Publish config not found",
        "Legacy contract file found",
        "parameters are not allowed",
        "operations.execute",
        "operations.search",
        "operations.index",
        "resources.vector_db",
        "execution.operations",
        "schema_version = 4 is required",
        "schema_version = 2 is required",
        "Root publish config is no longer supported",
        "pricing.base_cost is platform-owned",
        "studio ",
        "studio.",
        "hardware ",
        "hardware.",
        "pricing ",
        "pricing.",
        "unsupported legacy modality",
        "Invalid JSON in",
        "must contain",
        "must be",
        "not found: ",
        'Directory "',
        "Contract extraction failed",
        "No contract output",
    )
    return any(pattern in message for pattern in patterns)


def _looks_like_environment_error(message: str) -> bool:
    """Return whether a raw message looks like a local environment failure."""
    patterns = (
        "Docker ",
        "docker ",
        "Python ",
        "TTY",
        "Interactive input requires a TTY",
        "agent.py not found. Run: ai init",
    )
    return any(pattern in message for pattern in patterns)


def _looks_like_network_error(message: str) -> bool:
    """Return whether a raw message looks like a connectivity failure."""
    patterns = (
        "gateway unreachable",
        "connectivity problem",
        "Registry endpoint",
        "cannot be resolved (DNS)",
        "timed out",
        "socket hang up",
        "service unavailable",
    )
    return any(pattern in message for pattern in patterns)
