"""Module entrypoint for ``python -m aimp_cli``."""

from aimp_cli.core.app import main

if __name__ == "__main__":
    main()
