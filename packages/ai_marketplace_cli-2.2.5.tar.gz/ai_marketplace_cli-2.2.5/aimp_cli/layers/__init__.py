"""Layer hashing and Docker build-context helpers."""
