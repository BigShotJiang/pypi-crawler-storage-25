"""Service helpers used by the CLI command layer."""
