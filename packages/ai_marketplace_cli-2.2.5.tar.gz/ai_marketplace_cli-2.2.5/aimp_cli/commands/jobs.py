"""Unified workspace job read commands."""

from __future__ import annotations

from typing import Any

from aimp_cli.core.errors import auth_error, internal_error, usage_error
from aimp_cli.domain.models import (
    JobDetailResponse,
    JobListEntry,
    JobsListResponse,
)
from aimp_cli.utils.execution_stream import ExecutionStreamCallbacks, watch_execution_stream
from aimp_cli.utils.publish_watch import PublishWatchRenderer

from .common import CommandRuntime, exit_with_error

VALID_LIST_TYPES = {"all", "build", "fine-tune"}
VALID_DETAIL_TYPES = {"build", "fine-tune"}
VALID_MUTATION_TYPES = {"build", "fine-tune"}
TERMINAL_JOB_STATUSES = {"succeeded", "failed", "canceled"}


def _render_watch_logs(*, runtime: CommandRuntime, items: list[dict[str, Any]]) -> None:
    """Render structured execution log items for live watch flows."""
    for item in items:
        level = str(item.get("level") or "info").strip().lower()
        message = str(item.get("message") or "")
        if level == "error":
            runtime.console.print(f"[red]✗ {message}[/red]", soft_wrap=True)
        elif level == "warning":
            runtime.console.print(f"[yellow]⚠ {message}[/yellow]", soft_wrap=True)
        else:
            runtime.console.print(f"[dim]  {message}[/dim]", soft_wrap=True)


def _coerce_job_type(value: Any, *, request_id: str) -> str:
    normalized = str(value or "").strip().lower()
    if normalized in {"build", "fine-tune"}:
        return normalized
    raise internal_error(
        "Gateway returned a job payload without a valid job_type.",
        code="gateway_job_payload_invalid",
        request_id=request_id,
        extra={"job_type": value},
    )


def _coerce_job_entry(
    raw: Any,
    *,
    request_id: str,
    index: int,
) -> JobListEntry:
    if not isinstance(raw, dict):
        raise internal_error(
            "Gateway returned an invalid jobs list item.",
            code="gateway_jobs_list_invalid",
            request_id=request_id,
            extra={"index": index, "item_type": type(raw).__name__},
        )
    job_type = _coerce_job_type(raw.get("job_type"), request_id=request_id)
    job_id = str(raw.get("job_id") or "").strip()
    model_slug = str(raw.get("model_slug") or "").strip()
    status = str(raw.get("status") or "").strip()
    if not job_id or not model_slug or not status:
        raise internal_error(
            "Gateway returned a jobs list item missing required fields.",
            code="gateway_jobs_list_invalid",
            request_id=request_id,
            extra={"index": index},
        )
    job_payload = raw.get("job")
    return JobListEntry(
        job_type=job_type,
        job_id=job_id,
        model_slug=model_slug,
        status=status,
        created_at=str(raw.get("created_at")) if raw.get("created_at") else None,
        started_at=str(raw.get("started_at")) if raw.get("started_at") else None,
        finished_at=str(raw.get("finished_at")) if raw.get("finished_at") else None,
        job=job_payload if isinstance(job_payload, dict) else dict(raw),
    )


def _coerce_jobs_list_response(
    raw: dict[str, Any],
    *,
    requested_type: str,
    model: str | None,
    status: str | None,
    request_id: str,
) -> JobsListResponse:
    rows = raw.get("results")
    if not isinstance(rows, list):
        raise internal_error(
            "Gateway returned an invalid jobs list payload.",
            code="gateway_jobs_list_invalid",
            request_id=request_id,
            extra={"reason": "results_not_list"},
        )
    results = [
        _coerce_job_entry(item, request_id=request_id, index=index)
        for index, item in enumerate(rows)
    ]
    pagination = raw.get("pagination")
    return JobsListResponse(
        type=requested_type if requested_type in VALID_LIST_TYPES else "all",
        filters={"model": model, "status": status},
        results=results,
        pagination=pagination if isinstance(pagination, dict) else {},
        sources={},
    )


def _coerce_job_detail_response(
    raw: dict[str, Any],
    *,
    request_id: str,
) -> JobDetailResponse:
    job_type = _coerce_job_type(raw.get("job_type"), request_id=request_id)
    job = raw.get("job")
    if isinstance(job, dict):
        return JobDetailResponse(job_type=job_type, job=job)
    if isinstance(raw.get("job_id"), str):
        return JobDetailResponse(job_type=job_type, job=raw)
    raise internal_error(
        "Gateway returned an invalid job detail payload.",
        code="gateway_job_detail_invalid",
        request_id=request_id,
    )


def _coerce_job_cancel_payload(
    raw: dict[str, Any],
    *,
    request_id: str,
) -> dict[str, Any]:
    job_type = _coerce_job_type(raw.get("job_type"), request_id=request_id)
    cancel_state = str(raw.get("cancel_state") or "").strip().lower()
    if cancel_state not in {"canceling", "canceled"}:
        raise internal_error(
            "Gateway returned an invalid job cancel payload.",
            code="gateway_job_cancel_invalid",
            request_id=request_id,
            extra={"cancel_state": raw.get("cancel_state")},
        )
    job = raw.get("job")
    if not isinstance(job, dict):
        raise internal_error(
            "Gateway returned a cancel payload without job details.",
            code="gateway_job_cancel_invalid",
            request_id=request_id,
        )
    return {
        "job_type": job_type,
        "job_id": str(job.get("job_id") or ""),
        "cancel_state": cancel_state,
        "action": "canceled",
        "job": job,
    }


def jobs_list_command(
    *,
    runtime: CommandRuntime,
    job_type: str,
    model: str | None,
    status: str | None,
    page: int,
    page_size: int,
    gateway: str | None,
    api_key: str | None,
    json_output: bool,
    debug: bool,
    render_jobs_list: Any,
) -> None:
    """List unified workspace jobs from the CLI."""
    context = runtime.build_command_context("jobs.list", debug=debug, json_output=json_output)
    try:
        normalized_type = job_type.strip().lower()
        if normalized_type not in VALID_LIST_TYPES:
            raise usage_error(
                "--type must be one of: all,build,fine-tune",
                code="invalid_job_type",
                request_id=context.request_id,
            )
        auth_context = runtime.resolve_auth_context(gateway=gateway, api_key=api_key)
        if not auth_context.api_key:
            raise auth_error(
                "Not authenticated. Run: ai login",
                code="not_authenticated",
                request_id=context.request_id,
            )

        client = runtime.gateway_client_cls(auth_context, context)
        try:
            raw = client.list_jobs(
                job_type=None if normalized_type == "all" else normalized_type,
                status=status,
                model_slug=model,
                page=page,
                page_size=page_size,
            )
            payload = _coerce_jobs_list_response(
                raw,
                requested_type=normalized_type,
                model=model,
                status=status,
                request_id=context.request_id,
            )
        finally:
            client.close()

        result = payload.model_dump()
        if json_output:
            runtime.emit_result(result, json_output=True)
        else:
            render_jobs_list(result)
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )


def jobs_get_command(
    *,
    runtime: CommandRuntime,
    job_type: str,
    job: str,
    gateway: str | None,
    api_key: str | None,
    json_output: bool,
    debug: bool,
    render_job_detail: Any,
) -> None:
    """Get one job from the selected job type."""
    context = runtime.build_command_context("jobs.get", debug=debug, json_output=json_output)
    try:
        normalized_type = job_type.strip().lower()
        if normalized_type not in VALID_DETAIL_TYPES:
            raise usage_error(
                "--type must be one of: build,fine-tune",
                code="invalid_job_type",
                request_id=context.request_id,
            )
        auth_context = runtime.resolve_auth_context(gateway=gateway, api_key=api_key)
        if not auth_context.api_key:
            raise auth_error(
                "Not authenticated. Run: ai login",
                code="not_authenticated",
                request_id=context.request_id,
            )

        client = runtime.gateway_client_cls(auth_context, context)
        try:
            payload = _coerce_job_detail_response(
                client.get_job(job_id=job),
                request_id=context.request_id,
            )
            if payload.job_type != normalized_type:
                raise usage_error(
                    (
                        f"Job '{job}' is type '{payload.job_type}', but "
                        f"'--type {normalized_type}' was requested."
                    ),
                    code="job_type_mismatch",
                    request_id=context.request_id,
                )
        finally:
            client.close()

        result = payload.model_dump()
        if json_output:
            runtime.emit_result(result, json_output=True)
        else:
            render_job_detail(result)
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )


def jobs_watch_command(
    *,
    runtime: CommandRuntime,
    job_type: str,
    job: str,
    gateway: str | None,
    api_key: str | None,
    json_output: bool,
    debug: bool,
) -> None:
    """Watch one execution job live over SSE."""
    context = runtime.build_command_context("jobs.watch", debug=debug, json_output=json_output)
    try:
        normalized_type = job_type.strip().lower()
        if normalized_type not in VALID_DETAIL_TYPES:
            raise usage_error(
                "--type must be one of: build,fine-tune",
                code="invalid_job_type",
                request_id=context.request_id,
            )
        auth_context = runtime.resolve_auth_context(gateway=gateway, api_key=api_key)
        if not auth_context.api_key:
            raise auth_error(
                "Not authenticated. Run: ai login",
                code="not_authenticated",
                request_id=context.request_id,
            )

        client = runtime.gateway_client_cls(auth_context, context)
        try:
            latest_execution: dict[str, Any] = {}
            initial_payload = _coerce_job_detail_response(
                client.get_job(job_id=job),
                request_id=context.request_id,
            )
            if initial_payload.job_type != normalized_type:
                raise usage_error(
                    (
                        f"Job '{job}' is type '{initial_payload.job_type}', but "
                        f"'--type {normalized_type}' was requested."
                    ),
                    code="job_type_mismatch",
                    request_id=context.request_id,
                )

            if json_output:
                result = watch_execution_stream(
                    gateway=client,
                    job_id=job,
                    context=context,
                )
                runtime.emit_result(result, json_output=True)
                return

            if normalized_type == "build":
                initial = initial_payload.job
                renderer = PublishWatchRenderer(runtime.console, job)
                with runtime.console.status(
                    renderer.status_message(initial),
                    spinner="line",
                ) as status:
                    watch_execution_stream(
                        gateway=client,
                        job_id=job,
                        context=context,
                        callbacks=ExecutionStreamCallbacks(
                            on_snapshot=lambda execution: renderer.apply_snapshot(
                                execution,
                                status,
                            ),
                            on_status=lambda payload: renderer.apply_status(payload, status),
                            on_timeline=lambda items, _payload: renderer.render_timeline(items),
                            on_logs=lambda items, _payload: renderer.render_logs(items),
                            on_terminal=lambda execution: renderer.apply_terminal(
                                execution,
                                status,
                            ),
                        ),
                    )
            else:
                current_job = initial_payload.job
                with runtime.console.status(
                    f"{current_job.get('status', 'unknown')} · fine-tune · job {job[:8]}",
                    spinner="line",
                ) as status:
                    watch_execution_stream(
                        gateway=client,
                        job_id=job,
                        context=context,
                        callbacks=ExecutionStreamCallbacks(
                            on_snapshot=lambda execution: (
                                latest_execution.clear(),
                                latest_execution.update(execution),
                                status.update(
                                    (
                                        f"{execution.get('status', 'unknown')} "
                                        f"· fine-tune · job {job[:8]}"
                                    )
                                ),
                            ),
                            on_status=lambda payload: status.update(
                                (
                                    f"{payload.get('status', latest_execution.get('status', 'unknown'))} "
                                    f"· fine-tune · job {job[:8]}"
                                )
                            ),
                            on_logs=lambda items, _payload: _render_watch_logs(
                                runtime=runtime,
                                items=items,
                            ),
                            on_terminal=lambda execution: (
                                latest_execution.clear(),
                                latest_execution.update(execution),
                                status.update(
                                    (
                                        f"{execution.get('status', 'unknown')} "
                                        f"· fine-tune · job {job[:8]}"
                                    )
                                ),
                            ),
                        ),
                    )
        finally:
            client.close()
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )


def jobs_cancel_command(
    *,
    runtime: CommandRuntime,
    job_type: str,
    job: str,
    gateway: str | None,
    api_key: str | None,
    json_output: bool,
    debug: bool,
    render_job_action: Any,
) -> None:
    """Cancel one job."""
    context = runtime.build_command_context("jobs.cancel", debug=debug, json_output=json_output)
    try:
        normalized_type = job_type.strip().lower()
        if normalized_type not in VALID_MUTATION_TYPES:
            raise usage_error(
                "--type must be one of: build,fine-tune",
                code="invalid_job_type",
                request_id=context.request_id,
            )
        auth_context = runtime.resolve_auth_context(gateway=gateway, api_key=api_key)
        if not auth_context.api_key:
            raise auth_error(
                "Not authenticated. Run: ai login",
                code="not_authenticated",
                request_id=context.request_id,
            )

        client = runtime.gateway_client_cls(auth_context, context)
        try:
            result = _coerce_job_cancel_payload(
                client.cancel_job(job_id=job),
                request_id=context.request_id,
            )
            if result["job_type"] != normalized_type:
                raise usage_error(
                    (
                        f"Job '{job}' is type '{result['job_type']}', but "
                        f"'--type {normalized_type}' was requested."
                    ),
                    code="job_type_mismatch",
                    request_id=context.request_id,
                )
        finally:
            client.close()

        if json_output:
            runtime.emit_result(result, json_output=True)
        else:
            render_job_action(result)
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )


def jobs_delete_command(
    *,
    runtime: CommandRuntime,
    job_type: str,
    job: str,
    gateway: str | None,
    api_key: str | None,
    json_output: bool,
    debug: bool,
    render_job_action: Any,
) -> None:
    """Delete one terminal job from history."""
    context = runtime.build_command_context("jobs.delete", debug=debug, json_output=json_output)
    try:
        normalized_type = job_type.strip().lower()
        if normalized_type not in VALID_MUTATION_TYPES:
            raise usage_error(
                "--type must be one of: build,fine-tune",
                code="invalid_job_type",
                request_id=context.request_id,
            )
        auth_context = runtime.resolve_auth_context(gateway=gateway, api_key=api_key)
        if not auth_context.api_key:
            raise auth_error(
                "Not authenticated. Run: ai login",
                code="not_authenticated",
                request_id=context.request_id,
            )

        client = runtime.gateway_client_cls(auth_context, context)
        try:
            payload = _coerce_job_detail_response(
                client.get_job(job_id=job),
                request_id=context.request_id,
            )
            if payload.job_type != normalized_type:
                raise usage_error(
                    (
                        f"Job '{job}' is type '{payload.job_type}', but "
                        f"'--type {normalized_type}' was requested."
                    ),
                    code="job_type_mismatch",
                    request_id=context.request_id,
                )
            job_status = str(payload.job.get("status") or "").strip().lower()
            if job_status not in TERMINAL_JOB_STATUSES:
                raise usage_error(
                    "Delete requires a terminal job. Use `ai jobs cancel` first.",
                    code="job_not_terminal",
                    request_id=context.request_id,
                )
            client.delete_job(job_id=job)
        finally:
            client.close()

        result = {
            "job_type": normalized_type,
            "job_id": job,
            "action": "deleted",
        }
        if json_output:
            runtime.emit_result(result, json_output=True)
        else:
            render_job_action(result)
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )
