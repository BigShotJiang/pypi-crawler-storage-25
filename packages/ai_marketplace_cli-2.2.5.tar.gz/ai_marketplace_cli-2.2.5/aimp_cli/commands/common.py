"""Shared command runtime helpers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import typer
from rich.console import Console

from aimp_cli.core.config import emit_error
from aimp_cli.core.errors import coerce_cli_error


@dataclass(frozen=True)
class CommandRuntime:
    """Shared dependencies used by command handlers."""

    console: Console
    build_command_context: Any
    emit_result: Any
    config_store: Any
    has_interactive_terminal: Any
    can_prompt_for_input: Any
    require_tty: Any
    resolve_auth_context: Any
    prompt_text: Any
    prompt_secret: Any
    confirm_action: Any
    gateway_client_cls: Any
    upload_client_cls: Any
    docker_client_cls: Any
    run_publish: Any


def exit_with_error(
    error: Exception,
    *,
    json_output: bool,
    request_id: str,
    context: Any | None = None,
) -> None:
    """Render one CLI error and exit with the mapped exit code."""
    cli_error = coerce_cli_error(error, request_id=request_id)
    if context is not None:
        context.log(
            event="command_failed",
            error_code=cli_error.code,
            exit_code=int(cli_error.exit_code),
            category=cli_error.category.value,
        )
    emit_error(cli_error, json_output=json_output)
    raise typer.Exit(code=int(cli_error.exit_code))
