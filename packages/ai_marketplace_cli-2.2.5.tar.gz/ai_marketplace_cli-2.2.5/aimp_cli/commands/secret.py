"""Model secret command handlers."""

from __future__ import annotations

import sys
from pathlib import Path

from aimp_cli.core.errors import auth_error, usage_error
from aimp_cli.domain.discovery import find_project_root

from .common import CommandRuntime, exit_with_error


def _resolve_target_model(*, model: str | None) -> str:
    """Resolve the target model slug from CLI flags or the local project."""
    if model is not None:
        normalized = model.strip().lower()
        if not normalized:
            raise ValueError("--model must be non-empty")
        return normalized
    project_dir = find_project_root(Path.cwd())
    return project_dir.name.replace(" ", "-").lower()


def secret_set_command(
    *,
    runtime: CommandRuntime,
    name: str,
    model: str | None,
    stdin: bool,
    json_output: bool,
    debug: bool,
) -> None:
    """Set or rotate one model-scoped runtime secret."""
    context = runtime.build_command_context("secret.set", debug=debug, json_output=json_output)
    try:
        auth_context = runtime.resolve_auth_context(gateway=None, api_key=None)
        if not auth_context.api_key:
            raise auth_error(
                "Not authenticated. Run: ai login",
                code="not_authenticated",
                request_id=context.request_id,
            )
        target_model = _resolve_target_model(model=model)
        if stdin:
            secret_value = sys.stdin.read().strip()
        else:
            runtime.require_tty()
            secret_value = runtime.prompt_secret(
                f"Value for {name}",
                console=runtime.console,
                show_header=False,
                title="Model Secret",
                subtitle=f"Target model: {target_model}",
            )
        if secret_value is None:
            raise usage_error(
                "Secret set canceled.",
                code="secret_set_canceled",
                request_id=context.request_id,
            )
        if not secret_value:
            raise usage_error(
                "Secret value must be non-empty",
                code="invalid_secret_value",
                request_id=context.request_id,
            )
        client = runtime.gateway_client_cls(auth_context, context)
        try:
            result = client.set_model_secret(model_slug=target_model, name=name, value=secret_value)
        finally:
            client.close()
        runtime.emit_result(
            {
                "model": target_model,
                "secret": result.model_dump(exclude_none=True),
                "request_id": context.request_id,
            },
            json_output=json_output,
            success_message=f"Configured secret '{result.name}' for model '{target_model}'.",
            title="SECRET",
        )
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )


def secret_list_command(
    *,
    runtime: CommandRuntime,
    model: str | None,
    json_output: bool,
    debug: bool,
) -> None:
    """List configured model-scoped runtime secrets."""
    context = runtime.build_command_context("secret.list", debug=debug, json_output=json_output)
    try:
        auth_context = runtime.resolve_auth_context(gateway=None, api_key=None)
        if not auth_context.api_key:
            raise auth_error(
                "Not authenticated. Run: ai login",
                code="not_authenticated",
                request_id=context.request_id,
            )
        target_model = _resolve_target_model(model=model)
        client = runtime.gateway_client_cls(auth_context, context)
        try:
            result = client.list_model_secrets(model_slug=target_model)
        finally:
            client.close()
        runtime.emit_result(
            {
                "model": result.model,
                "secrets": [item.model_dump(exclude_none=True) for item in result.secrets],
                "request_id": context.request_id,
            },
            json_output=json_output,
            success_message=(
                f"Configured secrets for '{result.model}': "
                + (", ".join(item.name for item in result.secrets) if result.secrets else "none")
            ),
            title="SECRET",
        )
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )


def secret_delete_command(
    *,
    runtime: CommandRuntime,
    name: str,
    model: str | None,
    json_output: bool,
    debug: bool,
) -> None:
    """Delete one model-scoped runtime secret."""
    context = runtime.build_command_context("secret.delete", debug=debug, json_output=json_output)
    try:
        auth_context = runtime.resolve_auth_context(gateway=None, api_key=None)
        if not auth_context.api_key:
            raise auth_error(
                "Not authenticated. Run: ai login",
                code="not_authenticated",
                request_id=context.request_id,
            )
        target_model = _resolve_target_model(model=model)
        client = runtime.gateway_client_cls(auth_context, context)
        try:
            client.delete_model_secret(model_slug=target_model, name=name)
        finally:
            client.close()
        runtime.emit_result(
            {
                "model": target_model,
                "deleted": name,
                "request_id": context.request_id,
            },
            json_output=json_output,
            success_message=f"Deleted secret '{name}' from model '{target_model}'.",
            title="SECRET",
        )
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )
