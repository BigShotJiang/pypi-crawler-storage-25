"""Shared data models for the Python CLI."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, RootModel, model_serializer, model_validator

from aimp_cli.generated import gateway_contracts as generated_gateway_contracts

ModelLookupResponse = generated_gateway_contracts.ModelLookupResponse
ModelSecretListResponse = generated_gateway_contracts.ModelSecretListResponse
ModelSecretMetadata = generated_gateway_contracts.ModelSecretMetadata
PartCompletionInfo = generated_gateway_contracts.PartCompletionInfo
PublishHardwareTier = generated_gateway_contracts.PublishHardwareTier
PublishMetadataResponse = generated_gateway_contracts.PublishMetadataResponse
PublishResponse = generated_gateway_contracts.PublishResponse
ReleaseRuntimeState = generated_gateway_contracts.ReleaseRuntimeState
UploadAbortRequest = generated_gateway_contracts.UploadAbortRequest
UploadCompleteRequest = generated_gateway_contracts.UploadCompleteRequest
UploadCompleteResponse = generated_gateway_contracts.UploadCompleteResponse
UploadInitRequest = generated_gateway_contracts.UploadInitRequest
UploadInitResponse = generated_gateway_contracts.UploadInitResponse
UploadPart = generated_gateway_contracts.UploadPart

DEFAULT_GATEWAY_URL = "https://api.marketplace.example.com"
LOCAL_GATEWAY_URL = "http://localhost:8080"
DEFAULT_MODEL_VERSION = "0.1.0"
ArtifactType = Literal[
    "docker_image",
    "python_package",
    "javascript_package",
    "static_binary",
    "fine_tune_dataset",
    "source_bundle",
]
MediaType = Literal["text", "image", "audio", "video", "file", "json"]
OutputType = Literal[
    "text",
    "image",
    "audio",
    "video",
    "file",
    "json",
    "integer",
    "number",
    "boolean",
]

MEDIA_TYPE_ORDER: tuple[MediaType, ...] = (
    "text",
    "image",
    "audio",
    "video",
    "file",
    "json",
)
OUTPUT_TYPE_ORDER: tuple[OutputType, ...] = (
    "text",
    "image",
    "audio",
    "video",
    "file",
    "json",
    "integer",
    "number",
    "boolean",
)
FORBIDDEN_PLATFORM_MODES: tuple[str, ...] = ("delete", "purge")
VECTOR_ALIAS_PATTERN = r"^[A-Za-z][A-Za-z0-9_-]{0,63}$"
SECRET_NAME_PATTERN = r"^[A-Z][A-Z0-9_]{0,127}$"


def normalize_public_output_kind(kind: str) -> OutputType:
    """Validate one publishable public output kind."""
    normalized = str(kind or "").strip().lower()
    if normalized not in OUTPUT_TYPE_ORDER:
        raise ValueError(f"Unsupported public output kind: {kind}")
    return normalized  # type: ignore[return-value]


def _normalize_vector_alias_list(raw_aliases: list[str], *, field_name: str) -> list[str]:
    """Normalize one alias list using the canonical vector alias rules."""
    import re

    normalized: list[str] = []
    seen: set[str] = set()
    for raw_alias in raw_aliases:
        alias = str(raw_alias or "").strip()
        if not alias:
            raise ValueError(f"{field_name} must contain non-empty strings")
        if not re.fullmatch(VECTOR_ALIAS_PATTERN, alias):
            raise ValueError(
                f"{field_name} alias '{alias}' must start with a letter and contain only "
                "letters, numbers, underscore, and hyphen (max 64 chars)"
            )
        lowered = alias.lower()
        if lowered in seen:
            raise ValueError(f"Duplicate vector alias: {alias}")
        seen.add(lowered)
        normalized.append(alias)
    return normalized


class ConfigData(BaseModel):
    """Persisted CLI configuration."""

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    gateway_url: str = Field(alias="gatewayUrl")
    api_key: str = Field(alias="apiKey")
    username: str | None = None
    default_workspace: str | None = Field(default=None, alias="defaultWorkspace")


class AuthContext(BaseModel):
    """Resolved authentication context for a command execution."""

    gateway_url: str
    api_key: str | None = None
    persist: bool = False


class AuthResponse(BaseModel):
    """CLI auth response from Gateway."""

    valid: bool
    user_id: int
    username: str
    workspace: str | None = None
    workspace_name: str | None = None
    workspace_id: str | None = None
    workspace_type: str | None = None
    scopes: list[str] = Field(default_factory=list)


class InterfaceConfig(BaseModel):
    """Canonical interface definition."""

    model_config = ConfigDict(extra="forbid")

    inputs: list[MediaType]
    outputs: list[MediaType]

    @model_validator(mode="after")
    def validate_modalities(self) -> InterfaceConfig:
        """Require non-empty, canonical modality arrays."""
        self.inputs = _normalize_modalities(self.inputs, field_name="interface.inputs")
        self.outputs = _normalize_modalities(self.outputs, field_name="interface.outputs")
        return self


class VectorCollectionConfig(BaseModel):
    """Customer-facing vector collection metadata exposed by the model contract."""

    model_config = ConfigDict(extra="forbid")

    alias: str
    name: str
    description: str
    dimension: int
    metric: str

    @model_validator(mode="after")
    def validate_collection(self) -> "VectorCollectionConfig":
        import re

        self.alias = str(self.alias or "").strip()
        self.name = str(self.name or "").strip()
        self.description = str(self.description or "").strip()
        self.metric = str(self.metric or "").strip().lower()
        if not self.alias:
            raise ValueError("resources.vector_db.collections.alias must be non-empty")
        if not re.fullmatch(VECTOR_ALIAS_PATTERN, self.alias):
            raise ValueError(
                f"resources.vector_db.collections alias '{self.alias}' must start with a letter "
                "and contain only letters, numbers, underscore, and hyphen (max 64 chars)"
            )
        if not self.name:
            raise ValueError("resources.vector_db.collections.name must be non-empty")
        if not self.description:
            raise ValueError("resources.vector_db.collections.description must be non-empty")
        if isinstance(self.dimension, bool) or self.dimension <= 0:
            raise ValueError("resources.vector_db.collections.dimension must be a positive integer")
        if self.metric not in {"cosine", "dot", "euclidean"}:
            raise ValueError(
                "resources.vector_db.collections.metric must be one of: cosine, dot, euclidean"
            )
        return self


class VectorResourceCollectionsConfig(BaseModel):
    """Published vector collection catalog for customer-facing knowledge bases."""

    model_config = ConfigDict(extra="forbid")

    collections: list[VectorCollectionConfig]

    @model_validator(mode="after")
    def validate_collections(self) -> "VectorResourceCollectionsConfig":
        if not self.collections:
            raise ValueError("resources.vector_db.collections must be non-empty")
        normalized: list[VectorCollectionConfig] = []
        seen: set[str] = set()
        for collection in self.collections:
            lowered = collection.alias.lower()
            if lowered in seen:
                raise ValueError(f"Duplicate vector alias: {collection.alias}")
            seen.add(lowered)
            normalized.append(collection)
        self.collections = normalized
        return self


class ResourceConfig(BaseModel):
    """Internal runtime resources available to model code."""

    model_config = ConfigDict(extra="forbid")

    vector_db: bool | VectorResourceCollectionsConfig = False
    timeout: str | None = Field(
        default=None,
        description=(
            "Optional execution wall-clock limit for model containers (e.g. 30s, 5m, 1h). "
            "Forwarded to control plane runtime_config when no runtime.resources.timeout is set."
        ),
    )

    @property
    def vector_db_enabled(self) -> bool:
        """Return whether vector access is enabled."""
        if isinstance(self.vector_db, VectorResourceCollectionsConfig):
            return True
        return bool(self.vector_db)

    @property
    def vector_aliases(self) -> list[str]:
        """Return declared logical vector aliases."""
        if isinstance(self.vector_db, VectorResourceCollectionsConfig):
            return [collection.alias for collection in self.vector_db.collections]
        return []

    @property
    def vector_collections(self) -> list[VectorCollectionConfig]:
        """Return declared vector collections."""
        if isinstance(self.vector_db, VectorResourceCollectionsConfig):
            return list(self.vector_db.collections)
        return []


class CapabilitiesConfig(BaseModel):
    """Public app capabilities exposed by ``contract.toml``."""

    model_config = ConfigDict(extra="forbid")

    vector: bool = False
    tuning: bool = False


class ModeResourcesConfig(BaseModel):
    """Mode-scoped logical resource requirements."""

    model_config = ConfigDict(extra="forbid")

    vector_aliases: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_mode_resources(self) -> "ModeResourcesConfig":
        self.vector_aliases = _normalize_vector_alias_list(
            self.vector_aliases,
            field_name="modes.<name>.resources.vector_aliases",
        )
        return self


class TuningDatasetRequirementsConfig(BaseModel):
    """Public fine-tune dataset requirements."""

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    format: str


class TuningObjectiveConfig(BaseModel):
    """Internal tuning optimization objective."""

    model_config = ConfigDict(extra="forbid")

    name: str
    direction: Literal["minimize", "maximize"]


class TuningSplitPolicyConfig(BaseModel):
    """Internal tuning split policy."""

    model_config = ConfigDict(extra="forbid")

    strategy: str
    validation_ratio: float


class TuningDatasetSpecConfig(BaseModel):
    """Internal tuning dataset specification."""

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    format: str


class TuningSchemaFieldConfig(BaseModel):
    """Explicit fine-tune input field definition."""

    model_config = ConfigDict(extra="forbid")

    key: str
    type: Literal["image", "audio", "video", "text", "file", "json"]
    required: bool = True
    description: str | None = None
    multiple: bool = False


class TuningSchemaConfig(BaseModel):
    """Explicit fine-tune schema exposed to developers and customers."""

    model_config = ConfigDict(extra="forbid")

    fields: list[TuningSchemaFieldConfig]

    @model_validator(mode="after")
    def validate_fields(self) -> TuningSchemaConfig:
        if not self.fields:
            raise ValueError("tuning.schema.fields must be a non-empty array")

        seen: set[str] = set()
        for field in self.fields:
            key = field.key.strip()
            if not key:
                raise ValueError("tuning.schema.fields[].key must be non-empty")
            if key in seen:
                raise ValueError(f"Duplicate tuning schema field: {key}")
            seen.add(key)
            field.key = key
        return self


class TuningParameterDefinition(BaseModel):
    """Internal fine-tune hyperparameter definition."""

    model_config = ConfigDict(extra="forbid")

    kind: Literal["integer", "float", "boolean", "select"]
    default: Any
    required: bool = True
    min: int | float | None = None
    max: int | float | None = None
    step: int | float | None = None
    log: bool = False
    options: list[Any] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_definition(self) -> "TuningParameterDefinition":
        if self.kind == "boolean":
            if not isinstance(self.default, bool):
                raise ValueError("tuning.parameters boolean default must be a boolean")
            if self.min is not None or self.max is not None or self.step is not None:
                raise ValueError("tuning.parameters boolean does not support min/max/step")
            if self.log:
                raise ValueError("tuning.parameters boolean does not support log")
            if self.options:
                raise ValueError("tuning.parameters boolean does not support options")
            return self

        if self.kind == "select":
            if not self.options:
                raise ValueError("tuning.parameters select must define options")
            if self.default not in self.options:
                raise ValueError("tuning.parameters select default must be in options")
            if self.min is not None or self.max is not None or self.step is not None:
                raise ValueError("tuning.parameters select does not support min/max/step")
            if self.log:
                raise ValueError("tuning.parameters select does not support log")
            return self

        if self.options:
            raise ValueError("tuning.parameters numeric kinds do not support options")
        if self.min is None or self.max is None:
            raise ValueError("tuning.parameters numeric kinds require min and max")
        if self.max < self.min:
            raise ValueError("tuning.parameters max must be >= min")

        if self.kind == "integer":
            integer_fields = (self.default, self.min, self.max, self.step)
            for value in integer_fields:
                if value is None:
                    continue
                if isinstance(value, bool) or not isinstance(value, int):
                    raise ValueError("tuning.parameters integer values must be integers")
            if self.log:
                raise ValueError("tuning.parameters integer does not support log")
        else:
            numeric_fields = (self.default, self.min, self.max, self.step)
            for value in numeric_fields:
                if value is None:
                    continue
                if isinstance(value, bool) or not isinstance(value, (int, float)):
                    raise ValueError("tuning.parameters float values must be numeric")

        if self.default < self.min or self.default > self.max:
            raise ValueError("tuning.parameters default must be within min/max")
        return self


class TuningConfig(BaseModel):
    """Fine-tune capability contract managed by the CLI."""

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    supported: bool = True
    model_key: str
    strategy: Literal["lora", "full_tune"]
    training_runtime_profile: Literal["cpu", "gpu"]
    dataset_requirements: TuningDatasetRequirementsConfig
    objective: TuningObjectiveConfig
    split_policy: TuningSplitPolicyConfig
    dataset_spec: TuningDatasetSpecConfig
    input_schema: TuningSchemaConfig = Field(alias="schema")
    parameters: dict[str, TuningParameterDefinition] = Field(default_factory=dict)

    @model_validator(mode="after")
    def validate_tuning_selector(self) -> "TuningConfig":
        self.model_key = str(self.model_key or "").strip().lower()
        if not self.model_key:
            raise ValueError("tuning.model_key is required")
        return self


class ExecutionConfig(BaseModel):
    """Model-owned execution modes."""

    model_config = ConfigDict(extra="forbid")

    modes: list[str]

    @model_validator(mode="after")
    def validate_modes(self) -> ExecutionConfig:
        """Require non-empty, non-forbidden mode names."""
        if not self.modes:
            raise ValueError("execution.modes must be a non-empty array")

        normalized: list[str] = []
        for mode in self.modes:
            if not isinstance(mode, str) or not mode.strip():
                raise ValueError("execution.modes must contain non-empty strings")
            item = mode.strip().lower()
            if item in FORBIDDEN_PLATFORM_MODES:
                raise ValueError("execution.modes must not include platform lifecycle modes")
            if item not in normalized:
                normalized.append(item)

        self.modes = normalized
        return self


class InputDefinition(BaseModel):
    """Input parameter definition with name and modality."""

    model_config = ConfigDict(extra="forbid")

    name: str
    kind: MediaType
    required: bool = True
    description: str = ""
    multiple: bool = False
    label: str | None = None
    default: Any = None


class OutputDefinition(BaseModel):
    """Output parameter definition with name and modality."""

    model_config = ConfigDict(extra="forbid")

    name: str
    kind: OutputType
    required: bool = True
    description: str = ""
    multiple: bool = False
    label: str | None = None
    default: Any = None


class ModeContract(BaseModel):
    """Single mode contract entry."""

    model_config = ConfigDict(extra="forbid")

    inputs: list[InputDefinition] = Field(default_factory=list)
    enabled: bool = True
    outputs: list[OutputDefinition] = Field(default_factory=list)
    description: str = ""
    resources: ModeResourcesConfig | None = None

    @model_validator(mode="after")
    def validate_inputs(self) -> ModeContract:
        if self.inputs:
            seen_names: set[str] = set()
            for inp in self.inputs:
                if inp.name in seen_names:
                    raise ValueError(f"Duplicate input name: {inp.name}")
                seen_names.add(inp.name)
                if inp.kind not in MEDIA_TYPE_ORDER:
                    raise ValueError(f"Invalid modality kind: {inp.kind}")
        if self.outputs:
            seen_output_names: set[str] = set()
            for output in self.outputs:
                if output.name in seen_output_names:
                    raise ValueError(f"Duplicate output name: {output.name}")
                seen_output_names.add(output.name)
                if output.kind not in OUTPUT_TYPE_ORDER:
                    raise ValueError(f"Invalid modality kind: {output.kind}")
        return self


class ModesConfig(RootModel[dict[str, ModeContract]]):
    """Mode-scoped public contract (dynamic dict-based)."""

    def __iter__(self):  # type: ignore[override]
        return iter(self.root)

    def __getitem__(self, key: str) -> ModeContract:
        return self.root[key]

    def __contains__(self, key: str) -> bool:
        return key in self.root

    def __len__(self) -> int:
        return len(self.root)

    def keys(self) -> Any:
        return self.root.keys()

    def values(self) -> Any:
        return self.root.values()

    def items(self) -> Any:
        return self.root.items()

    def get(self, key: str, default: Any = None) -> Any:
        return self.root.get(key, default)

    def names(self) -> list[str]:
        """Return mode names."""
        return list(self.root.keys())


def _normalize_modalities(values: list[MediaType], *, field_name: str) -> list[MediaType]:
    """Normalize modality arrays to canonical order without duplicates."""
    if not values:
        raise ValueError(f"{field_name} must be a non-empty array")

    normalized: list[MediaType] = []
    for value in values:
        if value not in MEDIA_TYPE_ORDER:
            raise ValueError(f"{field_name} contains unsupported modality: {value}")
        if value not in normalized:
            normalized.append(value)
    return [item for item in MEDIA_TYPE_ORDER if item in normalized]


class SdkModeInput(BaseModel):
    """Input parameter from SDK contract."""

    model_config = ConfigDict(extra="forbid")

    name: str
    kind: str
    description: str = ""
    required: bool = True
    multiple: bool = False
    label: str | None = None
    default: Any = None


class SdkModeOutput(BaseModel):
    """Execution output field from SDK contract."""

    model_config = ConfigDict(extra="forbid")

    name: str
    kind: str
    description: str = ""
    required: bool = True
    multiple: bool = False
    label: str | None = None
    default: Any = None


class SdkModeParameterOption(BaseModel):
    """Option for select parameter."""

    model_config = ConfigDict(extra="forbid")

    value: str | int | float | bool
    label: str | None = None


class SdkModeParameter(BaseModel):
    """Config parameter from SDK contract."""

    model_config = ConfigDict(extra="forbid")

    kind: str
    description: str = ""
    default: Any = None
    label: str | None = None
    min: float | None = None
    max: float | None = None
    step: float | None = None
    options: list[SdkModeParameterOption] | None = None


class SdkModeContract(BaseModel):
    """Single mode contract from SDK."""

    model_config = ConfigDict(extra="forbid")

    inputs: list[SdkModeInput] = []
    outputs: list[SdkModeOutput] = []
    parameters: dict[str, SdkModeParameter] = {}
    description: str | None = None
    spaces: list[str] | None = None
    resources: ModeResourcesConfig | None = None


class SdkContract(BaseModel):
    """Contract returned from SDK loader with modes from decorators."""

    model_config = ConfigDict(extra="forbid")

    schema_version: int = Field(ge=1)
    capabilities: CapabilitiesConfig = Field(default_factory=CapabilitiesConfig)
    resources: ResourceConfig = Field(default_factory=ResourceConfig)
    modes: dict[str, SdkModeContract]
    parameters: dict[str, Any] = Field(default_factory=dict)
    tuning: dict[str, Any] | None = None


class ImageManifestLayer(BaseModel):
    """Manifest layer metadata."""

    model_config = ConfigDict(extra="forbid")

    digest: str
    size: int
    media_type: str | None = None


class ImageManifest(BaseModel):
    """Image manifest payload sent to Gateway."""

    model_config = ConfigDict(extra="forbid")

    digest: str
    total_size: int
    raw_manifest: dict[str, Any]
    layers: list[ImageManifestLayer]
    media_type: str | None = None


class StudioCoverPayload(BaseModel):
    """Studio cover metadata published from the CLI."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["image"] = "image"
    storage_uri: str | None = None
    public_url: str | None = None
    media_ref: str | None = None

    @model_validator(mode="after")
    def validate_location(self) -> StudioCoverPayload:
        if not self.media_ref and not self.storage_uri and not self.public_url:
            raise ValueError("studio.cover requires media_ref, storage_uri, or public_url")
        return self


class StudioPublishPayload(BaseModel):
    """Studio metadata payload published alongside the model contract."""

    model_config = ConfigDict(extra="forbid")

    name: str
    tags: list[str]
    visibility: Literal["public", "private"]
    article: dict[str, Any]
    cover: StudioCoverPayload | None = None


class ModeReadinessEntry(BaseModel):
    """Publish-time mode verification metadata."""

    model_config = ConfigDict(extra="forbid")

    declared: bool
    implemented: bool
    reason: str | None = None


class ModeReadinessPayload(RootModel[dict[str, ModeReadinessEntry]]):
    """Per-mode readiness metadata persisted with the contract."""

    @model_validator(mode="after")
    def validate_entries(self) -> ModeReadinessPayload:
        """Normalize readiness keys to lowercase non-empty mode names."""
        normalized: dict[str, ModeReadinessEntry] = {}
        for raw_name, entry in self.root.items():
            mode_name = str(raw_name).strip().lower()
            if not mode_name:
                raise ValueError("mode_readiness must use non-empty mode names")
            normalized[mode_name] = entry
        self.root = normalized
        return self

    def __iter__(self):  # type: ignore[override]
        return iter(self.root)

    def __getitem__(self, key: str) -> ModeReadinessEntry:
        return self.root[key]

    def __contains__(self, key: str) -> bool:
        return key in self.root

    def __len__(self) -> int:
        return len(self.root)

    def keys(self) -> Any:
        return self.root.keys()

    def values(self) -> Any:
        return self.root.values()

    def items(self) -> Any:
        return self.root.items()

    def get(self, key: str, default: Any = None) -> Any:
        return self.root.get(key, default)

    def names(self) -> list[str]:
        """Return readiness entry mode names."""
        return list(self.root.keys())


class PublishRequest(BaseModel):
    """Publish request payload."""

    model_config = ConfigDict(extra="forbid")

    slug: str
    version: str = DEFAULT_MODEL_VERSION
    publish_build_group_id: str
    resources: ResourceConfig
    modes: ModesConfig
    mode_readiness: ModeReadinessPayload
    required_secrets: list[str] = Field(default_factory=list)
    parameters: dict[str, Any] = Field(default_factory=dict)
    tuning: TuningConfig | None = None
    pricing: dict[str, Any]
    selected_hardware_tier: str
    studio: StudioPublishPayload

    @model_validator(mode="after")
    def validate_publish_source(self) -> PublishRequest:
        """Require one trusted remote build job reference."""
        declared_modes = set(self.modes.names())
        readiness_modes = set(self.mode_readiness.names())
        missing_readiness = sorted(declared_modes - readiness_modes)
        extra_readiness = sorted(readiness_modes - declared_modes)
        if missing_readiness:
            raise ValueError(
                "mode_readiness missing declared modes: " + ", ".join(missing_readiness)
            )
        if extra_readiness:
            raise ValueError(
                "mode_readiness contains undeclared modes: " + ", ".join(extra_readiness)
            )
        if not self.publish_build_group_id.strip():
            raise ValueError("publish_build_group_id is required")
        selected_hardware_tier = str(self.selected_hardware_tier or "").strip().lower()
        if not selected_hardware_tier:
            raise ValueError("selected_hardware_tier is required")
        self.selected_hardware_tier = selected_hardware_tier
        self.required_secrets = _normalize_secret_name_list(
            self.required_secrets,
            field_name="required_secrets",
        )
        return self

    @model_serializer(mode="wrap")
    def serialize_publish_request(self, serializer: Any) -> dict[str, Any]:
        """Serialize publish payload without internal mode fields."""
        payload = serializer(self)
        enabled_mode_names = [name for name, mode in self.modes.items() if bool(mode.enabled)]
        payload["modes"] = {
            name: self.modes[name].model_dump(exclude={"enabled"}, exclude_none=True)
            for name in enabled_mode_names
        }
        payload["mode_readiness"] = {
            name: self.mode_readiness[name].model_dump(exclude_none=True)
            for name in enabled_mode_names
            if name in self.mode_readiness
        }
        return payload


# ============================================================================
# Agent + Worker Topology Models
# ============================================================================


class PublishWorker(BaseModel):
    """One discovered worker under workers/<key>/."""

    model_config = ConfigDict(extra="forbid")

    key: str
    path: Path
    class_name: str
    module: str
    module_origin: Path


class AgentPublishWorker(BaseModel):
    """One published worker linked back to a root agent project."""

    model_config = ConfigDict(extra="forbid")

    key: str
    slug: str
    version: str = DEFAULT_MODEL_VERSION
    publish_build_group_id: str
    selected_hardware_tier: str

    @model_validator(mode="after")
    def validate_worker(self) -> "AgentPublishWorker":
        self.key = str(self.key or "").strip().lower()
        if not self.key:
            raise ValueError("workers[].key is required")
        self.slug = str(self.slug or "").strip()
        if not self.slug:
            raise ValueError("workers[].slug is required")
        self.version = str(self.version or "").strip()
        if not self.version:
            raise ValueError("workers[].version is required")
        self.publish_build_group_id = str(self.publish_build_group_id or "").strip()
        if not self.publish_build_group_id:
            raise ValueError("workers[].publish_build_group_id is required")
        self.selected_hardware_tier = str(self.selected_hardware_tier or "").strip().lower()
        if not self.selected_hardware_tier:
            raise ValueError("workers[].selected_hardware_tier is required")
        return self


class AgentPublishRoot(BaseModel):
    """Published root agent metadata."""

    model_config = ConfigDict(extra="forbid")

    slug: str
    version: str = DEFAULT_MODEL_VERSION
    publish_build_group_id: str

    @model_validator(mode="after")
    def validate_root(self) -> "AgentPublishRoot":
        self.slug = str(self.slug or "").strip()
        if not self.slug:
            raise ValueError("root.slug is required")
        self.version = str(self.version or "").strip()
        if not self.version:
            raise ValueError("root.version is required")
        self.publish_build_group_id = str(self.publish_build_group_id or "").strip()
        if not self.publish_build_group_id:
            raise ValueError("root.publish_build_group_id is required")
        return self


class AgentPublishRequest(BaseModel):
    """Aggregate publish payload for agent + worker projects."""

    model_config = ConfigDict(extra="forbid")

    project: str
    root: AgentPublishRoot
    workers: list[AgentPublishWorker]

    @model_validator(mode="after")
    def validate_request(self) -> "AgentPublishRequest":
        self.project = str(self.project or "").strip()
        if not self.project:
            raise ValueError("project is required")
        if not self.workers:
            raise ValueError("workers must contain at least one worker")
        seen_keys: set[str] = set()
        for worker in self.workers:
            if worker.key in seen_keys:
                raise ValueError(f"Duplicate worker key: {worker.key}")
            seen_keys.add(worker.key)
        return self


class AgentPublishWorkerResult(BaseModel):
    """Published worker result returned by agent publish flows."""

    model_config = ConfigDict(extra="forbid")

    key: str
    slug: str
    version: str
    id: str
    visibility: str
    url: str
    readiness: "CliPublishReadinessView" = Field(default_factory=lambda: CliPublishReadinessView())
    selected_hardware_tier: str


class AgentPublishRootResult(BaseModel):
    """Published root agent result returned by agent publish flows."""

    model_config = ConfigDict(extra="forbid")

    slug: str
    version: str
    id: str
    visibility: str
    url: str
    readiness: "CliPublishReadinessView" = Field(default_factory=lambda: CliPublishReadinessView())


class AgentPublishResult(BaseModel):
    """Aggregate result returned after agent topology registration."""

    model_config = ConfigDict(extra="forbid")

    project: str
    root: AgentPublishRootResult | None = None
    workers: list[AgentPublishWorkerResult] = Field(default_factory=list)


class CliPublishReadinessView(BaseModel):
    """CLI-owned readiness view used by publish application flows."""

    model_config = ConfigDict(extra="forbid")

    is_ready: bool = False
    blocking_reasons: list[str] = Field(default_factory=list)


class CliPublishResult(BaseModel):
    """CLI-owned publish result view after transport mapping."""

    model_config = ConfigDict(extra="forbid")

    slug: str
    id: str | None = None
    visibility: str | None = None
    url: str | None = None
    readiness: CliPublishReadinessView = Field(default_factory=CliPublishReadinessView)
    detached: bool | None = None
    version: str | None = None
    status: str | None = None
    phase: str | None = None
    current_step_message: str | None = None
    active_runtime_profile: str | None = None
    publish_build_group_id: str | None = None
    request_id: str | None = None

    @model_validator(mode="after")
    def validate_publish_result_shape(self) -> "CliPublishResult":
        """Enforce one explicit result shape for detached vs completed publish."""
        if bool(self.detached):
            if not self.publish_build_group_id:
                raise ValueError("detached publish result must include publish_build_group_id")
            return self
        if not self.id:
            raise ValueError("completed publish result must include id")
        if not self.visibility:
            raise ValueError("completed publish result must include visibility")
        if not self.url:
            raise ValueError("completed publish result must include url")
        return self


def _normalize_secret_name_list(raw_names: list[str], *, field_name: str) -> list[str]:
    """Normalize one secret-name list using env-var naming rules."""
    import re

    normalized: list[str] = []
    seen: set[str] = set()
    for raw_name in raw_names:
        name = str(raw_name or "").strip()
        if not name:
            raise ValueError(f"{field_name} must contain non-empty strings")
        if not re.fullmatch(SECRET_NAME_PATTERN, name):
            raise ValueError(
                f"{field_name} secret '{name}' must start with an uppercase letter and contain "
                "only uppercase letters, numbers, and underscore (max 128 chars)"
            )
        if name in seen:
            raise ValueError(f"Duplicate secret name: {name}")
        seen.add(name)
        normalized.append(name)
    return normalized


ResourceConfig.model_rebuild()
AgentPublishWorkerResult.model_rebuild()
AgentPublishResult.model_rebuild()


class PublishBuildJob(BaseModel):
    """Safe publish build job payload."""

    model_config = ConfigDict(extra="forbid")

    job_id: str
    job_type: str | None = None
    slug: str
    version: str
    runtime_profile: RuntimeProfile | None = None
    stage: str | None = None
    phase: str | None = None
    status: str
    timeline: list[dict[str, Any]] = Field(default_factory=list)
    error_code: str | None = None
    error_message: str | None = None
    logs: list[dict[str, Any]] = Field(default_factory=list)
    current_step_message: str | None = None
    lease_expires_at: str | None = None
    last_heartbeat_at: str | None = None
    last_progress_at: str | None = None
    created_at: str | None = None
    started_at: str | None = None
    finished_at: str | None = None
    cache_ref: str | None = None
    cache_imported: bool | None = None
    cache_exported: bool | None = None


class PublishBuildProfile(BaseModel):
    """Requested runtime profile entry for publish build groups and final publish."""

    model_config = ConfigDict(extra="forbid")

    runtime_profile: RuntimeProfile
    supported_hardware_tiers: list[str]
    target_image_ref: str | None = None

    @model_validator(mode="after")
    def validate_profile(self) -> "PublishBuildProfile":
        if not self.supported_hardware_tiers:
            raise ValueError("supported_hardware_tiers must not be empty")
        has_gpu = any(
            str(tier).strip().startswith("gpu-") for tier in self.supported_hardware_tiers
        )
        has_cpu = any(
            not str(tier).strip().startswith("gpu-") for tier in self.supported_hardware_tiers
        )
        if has_gpu and has_cpu:
            raise ValueError("supported_hardware_tiers cannot mix CPU and GPU tiers")
        if self.runtime_profile == "gpu" and not has_gpu:
            raise ValueError("gpu runtime_profile requires only GPU hardware tiers")
        if self.runtime_profile == "cpu" and has_gpu:
            raise ValueError("cpu runtime_profile requires only CPU hardware tiers")
        return self


class PublishBuildGroup(BaseModel):
    """Safe publish build group payload."""

    model_config = ConfigDict(extra="forbid")

    job_id: str
    job_type: str | None = None
    slug: str
    version: str
    stage: str | None = None
    phase: str | None = None
    status: str
    timeline: list[dict[str, Any]] = Field(default_factory=list)
    error_code: str | None = None
    error_message: str | None = None
    logs: list[dict[str, Any]] = Field(default_factory=list)
    current_step_message: str | None = None
    active_runtime_profile: RuntimeProfile | None = None
    requested_profiles: list[PublishBuildProfile] = Field(default_factory=list)
    successful_runtime_profiles: list[RuntimeProfile] = Field(default_factory=list)
    result_artifact_uri: str | None = None
    result_artifact_descriptor: dict[str, Any] = Field(default_factory=dict)
    registration_result: dict[str, Any] = Field(default_factory=dict)
    child_jobs: list[PublishBuildJob] = Field(default_factory=list)
    created_at: str | None = None
    started_at: str | None = None
    finished_at: str | None = None


class PublishRegistrationIntent(BaseModel):
    """Canonical publish registration intent persisted on one build group."""

    model_config = ConfigDict(extra="forbid")

    resources: ResourceConfig
    modes: ModesConfig
    mode_readiness: ModeReadinessPayload
    required_secrets: list[str] = Field(default_factory=list)
    parameters: dict[str, Any] = Field(default_factory=dict)
    tuning: TuningConfig | None = None
    pricing: dict[str, Any]
    selected_hardware_tier: str
    studio: StudioPublishPayload

    @model_validator(mode="after")
    def validate_registration_intent(self) -> "PublishRegistrationIntent":
        """Require one complete registration payload at submit time."""
        declared_modes = set(self.modes.names())
        readiness_modes = set(self.mode_readiness.names())
        missing_readiness = sorted(declared_modes - readiness_modes)
        extra_readiness = sorted(readiness_modes - declared_modes)
        if missing_readiness:
            raise ValueError(
                "mode_readiness missing declared modes: " + ", ".join(missing_readiness)
            )
        if extra_readiness:
            raise ValueError(
                "mode_readiness contains undeclared modes: " + ", ".join(extra_readiness)
            )
        selected_hardware_tier = str(self.selected_hardware_tier or "").strip().lower()
        if not selected_hardware_tier:
            raise ValueError("selected_hardware_tier is required")
        self.selected_hardware_tier = selected_hardware_tier
        self.required_secrets = _normalize_secret_name_list(
            self.required_secrets,
            field_name="required_secrets",
        )
        return self


class PublishBuildGroupCreateRequest(BaseModel):
    """Create request for one remote publish build group."""

    model_config = ConfigDict(extra="forbid")

    slug: str
    version: str = DEFAULT_MODEL_VERSION
    source_artifact_uri: str
    source_artifact_id: str | None = None
    dockerfile_path: str = "Dockerfile"
    build_context_path: str = "."
    selected_hardware_tier: str
    registration_intent: PublishRegistrationIntent
    python_package_index: dict[str, str] | None = None
    force: bool = False

    @model_validator(mode="after")
    def validate_paths(self) -> "PublishBuildGroupCreateRequest":
        """Validate bundle-relative build paths."""
        if not self.dockerfile_path.strip():
            raise ValueError("dockerfile_path must not be empty")
        if not self.build_context_path.strip():
            raise ValueError("build_context_path must not be empty")
        selected_hardware_tier = str(self.selected_hardware_tier or "").strip().lower()
        if not selected_hardware_tier:
            raise ValueError("selected_hardware_tier is required")
        self.selected_hardware_tier = selected_hardware_tier
        if self.python_package_index is not None:
            extra_index_url = str(self.python_package_index.get("extra_index_url", "")).strip()
            username = str(self.python_package_index.get("username", "")).strip()
            password = str(self.python_package_index.get("password", ""))
            if not extra_index_url:
                raise ValueError("python_package_index.extra_index_url must not be empty")
            if bool(username) != bool(password):
                raise ValueError(
                    "python_package_index.username and python_package_index.password must be set together"
                )
        return self


class PublishBuildGroupListResponse(BaseModel):
    """Paginated publish build group list payload."""

    model_config = ConfigDict(extra="forbid")

    results: list[PublishBuildGroup]
    pagination: dict[str, Any] = Field(default_factory=dict)
    model_slug: str | None = None


class StudioModelDetailResponse(BaseModel):
    """Studio model detail payload."""

    model_config = ConfigDict(extra="forbid")

    id: str
    slug: str
    name: str
    status: str
    version: str
    studio: dict[str, Any] | None = None
    interface: dict[str, Any] = Field(default_factory=dict)
    resources: dict[str, Any] = Field(default_factory=dict)
    operations: dict[str, Any] = Field(default_factory=dict)
    execution: dict[str, Any] = Field(default_factory=dict)
    capabilities: dict[str, Any] = Field(default_factory=dict)
    parameters: dict[str, Any]
    supported_hardware_tiers: list[str]
    selected_hardware_tier: str | None = None
    pricing: dict[str, Any]

    @model_validator(mode="after")
    def validate_hardware_tiers(self) -> "StudioModelDetailResponse":
        normalized_tiers = [
            str(tier).strip().lower() for tier in self.supported_hardware_tiers if str(tier).strip()
        ]
        if not normalized_tiers:
            raise ValueError("supported_hardware_tiers must not be empty")
        self.supported_hardware_tiers = normalized_tiers

        selected = str(self.selected_hardware_tier or "").strip().lower()
        if not selected or selected not in normalized_tiers:
            selected = normalized_tiers[0]
        self.selected_hardware_tier = selected
        return self


class FineTuneJobResponse(BaseModel):
    """Fine-tune job payload returned by Gateway."""

    job_id: str
    model_slug: str
    status: str
    created_at: str | None = None
    started_at: str | None = None
    finished_at: str | None = None
    output_asset_id: str | None = None
    output_asset_slug: str | None = None
    output_kind: str | None = None
    adapter_format: str
    timeline: list[dict[str, Any]] = Field(default_factory=list)
    error_code: str | None = None
    error_message: str | None = None


JobType = Literal["build", "fine-tune"]
JobListType = Literal["all", "build", "fine-tune"]
RuntimeProfile = Literal["cpu", "gpu"]


class JobCancelResponse(BaseModel):
    """Unified cancellation response returned by job cancel endpoints."""

    model_config = ConfigDict(extra="forbid")

    job_type: JobType
    cancel_state: Literal["canceling", "canceled"]
    job: dict[str, Any] = Field(default_factory=dict)


class FineTuneJobListResponse(BaseModel):
    """Paginated fine-tune job list payload."""

    model_config = ConfigDict(extra="forbid")

    results: list[FineTuneJobResponse]
    pagination: dict[str, Any] = Field(default_factory=dict)


class JobListEntry(BaseModel):
    """Normalized workspace job item used by unified CLI output."""

    model_config = ConfigDict(extra="forbid")

    job_type: JobType
    job_id: str
    model_slug: str
    status: str
    created_at: str | None = None
    started_at: str | None = None
    finished_at: str | None = None
    job: dict[str, Any] = Field(default_factory=dict)


class JobsListResponse(BaseModel):
    """Unified paginated job list returned by ``ai jobs list``."""

    model_config = ConfigDict(extra="forbid")

    type: JobListType
    filters: dict[str, Any] = Field(default_factory=dict)
    results: list[JobListEntry]
    pagination: dict[str, Any] = Field(default_factory=dict)
    sources: dict[str, Any] = Field(default_factory=dict)


class JobDetailResponse(BaseModel):
    """Normalized single job response returned by ``ai jobs get``."""

    model_config = ConfigDict(extra="forbid")

    job_type: JobType
    job: dict[str, Any] = Field(default_factory=dict)
