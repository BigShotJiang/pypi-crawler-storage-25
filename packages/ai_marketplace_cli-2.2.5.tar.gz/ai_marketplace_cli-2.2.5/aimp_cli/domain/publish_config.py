"""Publish config models and loading helpers."""

from __future__ import annotations

import tomllib
from pathlib import Path
from typing import Literal

from pydantic import BaseModel

from .constants import (
    DEFAULT_PUBLISH_SCHEMA_VERSION,
    LEGACY_PUBLISH_CONFIG_FILE_NAME,
    PUBLISH_CONFIG_FILE_NAME,
    PUBLISH_CONFIG_RELATIVE_PATH,
    VALID_VISIBILITY,
)


class PublishStudioConfig(BaseModel):
    """Publish config studio section."""

    name: str
    tags: list[str]
    visibility: str
    cover_file: str | None = None
    cover_url: str | None = None
    article_mdx_file: str


class PublishPythonPackagesConfig(BaseModel):
    """Optional Python package index overrides owned by publish config."""

    extra_index_url: str
    username: str | None = None
    password: str | None = None


class PublishMetadataConfig(BaseModel):
    """Validated publish metadata config."""

    schema_version: int
    studio: PublishStudioConfig
    pricing: dict[str, float]
    python_packages: PublishPythonPackagesConfig | None = None


def _validate_studio_section(studio: dict[str, object]) -> PublishStudioConfig:
    legacy_keys = [
        key for key in ("article_file", "article_markdown_file", "assets") if key in studio
    ]
    if legacy_keys:
        raise RuntimeError(
            "Unsupported studio keys in .aimp/publish.toml: "
            f"{', '.join(sorted(legacy_keys))}. Use studio.article_mdx_file only."
        )
    name = str(studio.get("name", "")).strip()
    if not name:
        raise RuntimeError("studio.name is required")
    tags_raw = studio.get("tags")
    if not isinstance(tags_raw, list):
        raise RuntimeError("studio.tags must be an array")
    tags = [str(tag).strip() for tag in tags_raw]
    if any(not tag for tag in tags):
        raise RuntimeError("studio.tags must contain non-empty strings")
    visibility = str(studio.get("visibility", "")).strip()
    if visibility not in VALID_VISIBILITY:
        raise RuntimeError("studio.visibility must be one of: public, private")
    article_mdx_file = str(studio.get("article_mdx_file", "")).strip()
    if not article_mdx_file:
        raise RuntimeError("studio.article_mdx_file is required")
    cover_file = str(studio.get("cover_file", "")).strip() or None
    cover_url = str(studio.get("cover_url", "")).strip() or None
    return PublishStudioConfig(
        name=name,
        tags=tags,
        visibility=visibility,
        cover_file=cover_file,
        cover_url=cover_url,
        article_mdx_file=article_mdx_file,
    )


def load_publish_config(project_dir: Path) -> PublishMetadataConfig:
    """Load and validate hidden publish config."""
    legacy_config_path = project_dir / LEGACY_PUBLISH_CONFIG_FILE_NAME
    if legacy_config_path.exists():
        raise RuntimeError(
            "Root publish config is no longer supported: aimp.publish.toml. "
            "Remove it and run: ai push --configure"
        )

    config_path = project_dir / PUBLISH_CONFIG_RELATIVE_PATH
    if not config_path.exists():
        raise RuntimeError(
            f"Publish config not found: {PUBLISH_CONFIG_FILE_NAME}. Run: ai push --configure"
        )
    raw = tomllib.loads(config_path.read_text(encoding="utf-8"))
    try:
        schema_version = int(raw.get("schema_version", 0))
    except (TypeError, ValueError) as exc:
        raise RuntimeError(
            f"schema_version = {DEFAULT_PUBLISH_SCHEMA_VERSION} is required"
        ) from exc
    if schema_version != DEFAULT_PUBLISH_SCHEMA_VERSION:
        raise RuntimeError(
            f"schema_version = {DEFAULT_PUBLISH_SCHEMA_VERSION} is required. "
            "Run: ai push --configure"
        )
    studio = raw.get("studio")
    if not isinstance(studio, dict):
        raise RuntimeError("studio section is required")
    if "hardware" in raw:
        raise RuntimeError(
            "hardware authoring is no longer supported in .aimp/publish.toml. "
            "Select deployment hardware during publish with `ai push --hardware <sku>` "
            "and remove [hardware]."
        )
    pricing = raw.get("pricing")
    if not isinstance(pricing, dict):
        raise RuntimeError("pricing section is required")
    python_packages_raw = raw.get("python_packages")
    if python_packages_raw is not None and not isinstance(python_packages_raw, dict):
        raise RuntimeError("python_packages section must be a table")
    if "base_cost" in pricing:
        raise RuntimeError("pricing.base_cost is platform-owned. Run: ai push --configure")
    unsupported_pricing_keys = [
        str(key) for key in pricing.keys() if str(key) not in {"developer_margin"}
    ]
    if unsupported_pricing_keys:
        raise RuntimeError(
            "Unsupported pricing keys in .aimp/publish.toml: "
            f"{', '.join(sorted(unsupported_pricing_keys))}"
        )
    if "developer_margin" not in pricing:
        raise RuntimeError("pricing.developer_margin is required")
    try:
        developer_margin = float(str(pricing.get("developer_margin")))
    except (TypeError, ValueError) as exc:
        raise RuntimeError("pricing.developer_margin must be numeric") from exc

    python_packages: PublishPythonPackagesConfig | None = None
    if python_packages_raw is not None:
        extra_index_url = str(python_packages_raw.get("extra_index_url", "")).strip()
        username = str(python_packages_raw.get("username", "")).strip() or None
        password_value = python_packages_raw.get("password")
        password = str(password_value) if password_value not in (None, "") else None
        if not extra_index_url:
            raise RuntimeError("python_packages.extra_index_url is required")
        unsupported_python_package_keys = [
            str(key)
            for key in python_packages_raw.keys()
            if str(key) not in {"extra_index_url", "username", "password"}
        ]
        if unsupported_python_package_keys:
            raise RuntimeError(
                "Unsupported python_packages keys in .aimp/publish.toml: "
                f"{', '.join(sorted(unsupported_python_package_keys))}"
            )
        if bool(username) != bool(password):
            raise RuntimeError(
                "python_packages.username and python_packages.password must be set together"
            )
        python_packages = PublishPythonPackagesConfig(
            extra_index_url=extra_index_url,
            username=username,
            password=password,
        )

    return PublishMetadataConfig(
        schema_version=DEFAULT_PUBLISH_SCHEMA_VERSION,
        studio=_validate_studio_section(studio),
        pricing={"developer_margin": developer_margin},
        python_packages=python_packages,
    )


def load_studio_article_source(project_dir: Path, publish_config: PublishMetadataConfig) -> str:
    """Load constrained MDX article source."""
    article_path = project_dir / publish_config.studio.article_mdx_file
    if not article_path.exists():
        raise RuntimeError(
            f"studio.article_mdx_file not found: {publish_config.studio.article_mdx_file}"
        )
    content = article_path.read_text(encoding="utf-8")
    if not content.strip():
        raise RuntimeError("studio.article_mdx_file must contain non-empty MDX")
    return content


def resolve_studio_file_paths(
    project_dir: Path,
    publish_config: PublishMetadataConfig,
) -> tuple[Path, Path | None]:
    """Resolve required Studio content file paths."""
    article_path = project_dir / publish_config.studio.article_mdx_file
    if not article_path.exists():
        raise RuntimeError(
            f"studio.article_mdx_file not found: {publish_config.studio.article_mdx_file}"
        )
    cover_path = (
        project_dir / publish_config.studio.cover_file if publish_config.studio.cover_file else None
    )
    if cover_path and not cover_path.exists():
        raise RuntimeError(f"studio.cover_file not found: {publish_config.studio.cover_file}")
    return article_path, cover_path
