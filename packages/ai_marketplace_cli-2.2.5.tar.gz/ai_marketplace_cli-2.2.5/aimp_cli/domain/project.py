"""Current project-domain facade for scaffold, config, and publish helpers."""

from __future__ import annotations

from aimp_cli.domain.constants import (
    AGENT_CONTRACT_FILE_NAME,
    AGENT_CONTRACT_RELATIVE_PATH,
    AGENT_ENTRYPOINT_RELATIVE_PATH,
    APP_PACKAGE_RELATIVE_PATH,
    DEFAULT_AGENT_NAME,
    DEFAULT_CONTRACT_SCHEMA_VERSION,
    DEFAULT_PUBLISH_SCHEMA_VERSION,
    DEFAULT_STUDIO_ARTICLE_MDX_FILE,
    DEFAULT_STUDIO_COVER_FILE,
    EMBEDDER_PACKAGE_NAME,
    FINE_TUNE_AGENT_ENTRYPOINT_RELATIVE_PATH,
    GENERATOR_PACKAGE_NAME,
    LEGACY_PUBLISH_CONFIG_FILE_NAME,
    PROJECT_CONFIG_FILE_NAME,
    PROJECT_CONFIG_RELATIVE_PATH,
    PUBLISH_CONFIG_FILE_NAME,
    PUBLISH_CONFIG_RELATIVE_PATH,
    SKILLS_RELATIVE_PATH,
    TUNING_ASSETS_RELATIVE_PATH,
    TUNING_BUNDLE_FILE_NAME,
    TUNING_HIDDEN_DIR_PATH,
    TUNING_HIDDEN_HELPERS_FILE,
    TUNING_HIDDEN_INIT_FILE,
    TUNING_HIDDEN_SCHEMA_FILE,
    TUNING_HIDDEN_SCHEMA_FILE_NAME,
    TUNING_HIDDEN_SCHEMA_TYPES_FILE,
    TUNING_PREPARE_SCRIPT_FILE_NAME,
    TUNING_README_FILE_NAME,
)
from aimp_cli.domain.discovery import ProjectSkillEntry, find_project_root, list_project_skills
from aimp_cli.domain.project_config import (
    AgentContractMetadata,
    ProjectConfig,
    ProjectPublishConfig,
    default_agent_contract_metadata,
    default_project_config,
    load_agent_contract,
    load_project_config,
    resolve_project_mode_names,
    write_agent_contract,
    write_project_config,
)
from aimp_cli.domain.publish_config import (
    PublishMetadataConfig,
    PublishStudioConfig,
    load_publish_config,
    load_studio_article_source,
    resolve_studio_file_paths,
)
from aimp_cli.domain.serialization import (
    agent_contract_toml_template,
    project_config_toml_template,
    publish_config_toml_template,
    serialize_agent_contract_toml,
    serialize_project_config_toml,
    serialize_publish_config_toml,
)
from aimp_cli.operations.publish.local_metadata import (
    RemoteModelPublishSnapshot,
    build_local_publish_metadata,
)
from aimp_cli.operations.scaffold.files import (
    create_consumer_tuning_scaffold,
    regenerate_tuning_scaffold,
    studio_article_mdx_template,
    write_default_studio_cover,
)
from aimp_cli.operations.scaffold.init_project import create_project_scaffold
from aimp_cli.operations.scaffold.tuning import default_tuning_workspace_config
from aimp_cli.utils.docker_build import (
    extract_docker_context_sources,
    resolve_docker_build_spec,
)

__all__ = [
    "AGENT_CONTRACT_FILE_NAME",
    "AGENT_CONTRACT_RELATIVE_PATH",
    "AGENT_ENTRYPOINT_RELATIVE_PATH",
    "APP_PACKAGE_RELATIVE_PATH",
    "AgentContractMetadata",
    "DEFAULT_AGENT_NAME",
    "DEFAULT_CONTRACT_SCHEMA_VERSION",
    "DEFAULT_PUBLISH_SCHEMA_VERSION",
    "DEFAULT_STUDIO_ARTICLE_MDX_FILE",
    "DEFAULT_STUDIO_COVER_FILE",
    "EMBEDDER_PACKAGE_NAME",
    "FINE_TUNE_AGENT_ENTRYPOINT_RELATIVE_PATH",
    "GENERATOR_PACKAGE_NAME",
    "LEGACY_PUBLISH_CONFIG_FILE_NAME",
    "load_agent_contract",
    "PROJECT_CONFIG_FILE_NAME",
    "PROJECT_CONFIG_RELATIVE_PATH",
    "PUBLISH_CONFIG_FILE_NAME",
    "PUBLISH_CONFIG_RELATIVE_PATH",
    "ProjectConfig",
    "ProjectPublishConfig",
    "ProjectSkillEntry",
    "PublishMetadataConfig",
    "PublishStudioConfig",
    "RemoteModelPublishSnapshot",
    "SKILLS_RELATIVE_PATH",
    "TUNING_ASSETS_RELATIVE_PATH",
    "TUNING_BUNDLE_FILE_NAME",
    "TUNING_HIDDEN_DIR_PATH",
    "TUNING_HIDDEN_HELPERS_FILE",
    "TUNING_HIDDEN_INIT_FILE",
    "TUNING_HIDDEN_SCHEMA_FILE",
    "TUNING_HIDDEN_SCHEMA_FILE_NAME",
    "TUNING_HIDDEN_SCHEMA_TYPES_FILE",
    "TUNING_PREPARE_SCRIPT_FILE_NAME",
    "TUNING_README_FILE_NAME",
    "agent_contract_toml_template",
    "build_local_publish_metadata",
    "create_consumer_tuning_scaffold",
    "create_project_files",
    "default_agent_contract_metadata",
    "default_project_config",
    "list_project_skills",
    "load_project_config",
    "load_publish_config",
    "load_studio_article_source",
    "project_config_toml_template",
    "publish_config_toml_template",
    "regenerate_tuning_scaffold",
    "resolve_docker_build_spec",
    "resolve_project_mode_names",
    "resolve_studio_file_paths",
    "serialize_agent_contract_toml",
    "serialize_project_config_toml",
    "serialize_publish_config_toml",
    "studio_article_mdx_template",
    "write_agent_contract",
    "write_default_studio_cover",
    "write_project_config",
]


def create_project_files(name: str):
    """Create a project scaffold from framework-owned templates."""
    return create_project_scaffold(name)
