"""Contract and discovery helpers for the CLI."""
