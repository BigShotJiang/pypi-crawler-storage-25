"""Project metadata and hidden scaffold configuration persistence."""

from __future__ import annotations

import tomllib
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

from aimp_cli.domain.models import (
    CapabilitiesConfig,
    ModeContract,
    ModesConfig,
    ResourceConfig,
    TuningConfig,
)

from .constants import (
    AGENT_CONTRACT_RELATIVE_PATH,
    DEFAULT_CONTRACT_SCHEMA_VERSION,
    PROJECT_CONFIG_FILE_NAME,
    PROJECT_CONFIG_RELATIVE_PATH,
)


class AgentContractMetadata(BaseModel):
    """Public agent metadata written to ``contract.toml``."""

    model_config = ConfigDict(extra="forbid")

    name: str
    version: str = "0.1.0"
    author: str = "username"
    description: str = "Generated with ai init"


class ProjectPublishConfig(BaseModel):
    """Hidden packaging config stored in ``.aimp/project.toml``."""

    model_config = ConfigDict(extra="forbid")

    artifact_path: str = "."
    artifact_format: Literal["tar.zst"] = "tar.zst"
    selected_hardware_tier: str | None = None

    @field_validator("artifact_path")
    @classmethod
    def validate_artifact_path(cls, value: str) -> str:
        normalized = str(value or "").strip()
        if not normalized:
            raise ValueError("publish.artifact_path must be non-empty")
        return normalized

    @field_validator("artifact_format", mode="before")
    @classmethod
    def normalize_artifact_format(cls, value: object) -> str:
        return str(value or "").strip().lower()

    @field_validator("selected_hardware_tier", mode="before")
    @classmethod
    def normalize_selected_hardware_tier(cls, value: object) -> str | None:
        normalized = str(value or "").strip().lower()
        return normalized or None


class ProjectConfig(BaseModel):
    """Hidden scaffold configuration loaded from ``.aimp/project.toml``."""

    model_config = ConfigDict(extra="forbid")

    schema_version: int = DEFAULT_CONTRACT_SCHEMA_VERSION
    capabilities: CapabilitiesConfig = Field(default_factory=CapabilitiesConfig)
    publish: ProjectPublishConfig = Field(default_factory=ProjectPublishConfig)
    resources: ResourceConfig = Field(default_factory=ResourceConfig, exclude=True)
    modes: ModesConfig
    tuning: TuningConfig | None = None


def default_project_config() -> ProjectConfig:
    """Return the default hidden project configuration."""
    from aimp_cli.domain.models import InputDefinition, OutputDefinition
    from aimp_cli.operations.scaffold.tuning import default_tuning_workspace_config

    config = ProjectConfig(
        schema_version=DEFAULT_CONTRACT_SCHEMA_VERSION,
        capabilities=CapabilitiesConfig(vector=False, tuning=True),
        resources=ResourceConfig(vector_db=False),
        modes=ModesConfig(
            {
                "generate": ModeContract(
                    inputs=[InputDefinition(name="prompt", kind="text", required=True)],
                    enabled=True,
                    outputs=[OutputDefinition(name="result", kind="text", required=True)],
                ),
            }
        ),
    )
    config.tuning = default_tuning_workspace_config(config)
    return config


def default_agent_contract_metadata(project_name: str) -> AgentContractMetadata:
    """Return default public metadata for a new scaffolded agent."""
    normalized_name = project_name.strip() or "agent"
    return AgentContractMetadata(
        name=normalized_name,
        version="0.1.0",
        author="username",
        description=f"{normalized_name} agent",
    )


def load_agent_contract(project_dir: Path) -> AgentContractMetadata:
    """Load and validate ``contract.toml`` public metadata."""
    contract_path = project_dir / AGENT_CONTRACT_RELATIVE_PATH
    if not contract_path.exists():
        raise RuntimeError(f"Contract file not found: {AGENT_CONTRACT_RELATIVE_PATH}. Run: ai init")
    raw = tomllib.loads(contract_path.read_text(encoding="utf-8"))
    agent_payload = raw.get("agent")
    if not isinstance(agent_payload, dict):
        raise RuntimeError("contract.toml must define an [agent] table")
    try:
        return AgentContractMetadata.model_validate(agent_payload)
    except Exception as exc:  # pragma: no cover - pydantic shapes are unit tested elsewhere
        raise RuntimeError(f"contract.toml is invalid: {exc}") from exc


def load_project_config(project_dir: Path) -> ProjectConfig:
    """Load and validate ``.aimp/project.toml``."""
    raw = load_project_config_payload(project_dir)
    return build_project_config(raw)


def load_project_config_payload(project_dir: Path) -> dict[str, Any]:
    """Load raw ``.aimp/project.toml`` after file-level prechecks."""
    config_path = project_dir / PROJECT_CONFIG_RELATIVE_PATH
    if not config_path.exists():
        legacy_path = project_dir / "aimp.config.toml"
        if legacy_path.exists():
            raise RuntimeError(
                "Root contract file is no longer supported: aimp.config.toml. "
                f"Use {PROJECT_CONFIG_FILE_NAME} instead."
            )
        if (project_dir / AGENT_CONTRACT_RELATIVE_PATH).exists():
            raise RuntimeError(
                f"Project config file not found: {PROJECT_CONFIG_FILE_NAME}. Run: ai init"
            )
        raise RuntimeError(f"Config file not found: {PROJECT_CONFIG_FILE_NAME}. Run: ai init")
    raw = tomllib.loads(config_path.read_text(encoding="utf-8"))
    if "parameters" in raw:
        raise RuntimeError(f"parameters are not allowed in {PROJECT_CONFIG_FILE_NAME}")
    if "required_secrets" in raw:
        raise RuntimeError(
            (
                f"{PROJECT_CONFIG_FILE_NAME} contains deprecated `required_secrets`, which must be "
                "removed. Move project runtime secrets to a project-local `.env` file "
                "(for example: `ZAI_API_KEY=...`)."
            )
        )
    return raw


def build_project_config(
    raw: dict[str, Any],
    *,
    resource_override: ResourceConfig | dict[str, Any] | None = None,
) -> ProjectConfig:
    """Validate raw project config payload into a canonical config object."""
    try:
        schema_version = int(raw.get("schema_version", 0))
    except (TypeError, ValueError) as exc:
        raise RuntimeError(
            f"schema_version = {DEFAULT_CONTRACT_SCHEMA_VERSION} is required"
        ) from exc
    if schema_version != DEFAULT_CONTRACT_SCHEMA_VERSION:
        raise RuntimeError(
            f"schema_version = {DEFAULT_CONTRACT_SCHEMA_VERSION} is required in "
            f"{PROJECT_CONFIG_FILE_NAME}. "
            "Update schema_version or re-initialize the project."
        )
    raw_publish = raw.get("publish")
    if raw_publish is None:
        publish = ProjectPublishConfig()
    else:
        if not isinstance(raw_publish, dict):
            raise RuntimeError(f"publish must be a table in {PROJECT_CONFIG_FILE_NAME}")
        if "artifact_path" not in raw_publish:
            raise RuntimeError(f"publish.artifact_path is required in {PROJECT_CONFIG_FILE_NAME}")
        if "artifact_format" not in raw_publish:
            raise RuntimeError(f"publish.artifact_format is required in {PROJECT_CONFIG_FILE_NAME}")
        try:
            publish = ProjectPublishConfig.model_validate(raw_publish)
        except Exception as exc:  # pragma: no cover - pydantic shapes are unit tested elsewhere
            raise RuntimeError(f"publish config is invalid: {exc}") from exc
    raw_modes = raw.get("modes") or raw.get("operations") or {}
    if isinstance(raw_modes, dict):
        for mode_name, mode_payload in raw_modes.items():
            if not isinstance(mode_payload, dict):
                continue
            raw_outputs = mode_payload.get("outputs")
            if (
                isinstance(raw_outputs, list)
                and raw_outputs
                and any(isinstance(item, str) for item in raw_outputs)
            ):
                raise RuntimeError(
                    f"modes.{mode_name}.outputs must use structured output objects. "
                    f"Replace outputs = [...] with [[modes.{mode_name}.outputs]] entries."
                )
    if isinstance(resource_override, ResourceConfig):
        resources = resource_override
    elif isinstance(resource_override, dict):
        resources = ResourceConfig.model_validate(resource_override)
    else:
        resources = ResourceConfig.model_validate(raw.get("resources") or {})
    return ProjectConfig(
        schema_version=DEFAULT_CONTRACT_SCHEMA_VERSION,
        capabilities=CapabilitiesConfig.model_validate(raw.get("capabilities") or {}),
        publish=publish,
        resources=resources,
        modes=ModesConfig.model_validate(raw_modes),
        tuning=(
            TuningConfig.model_validate(raw["tuning"])
            if isinstance(raw.get("tuning"), dict)
            else None
        ),
    )


def load_project_config_with_resource_override(
    project_dir: Path,
    *,
    resource_override: ResourceConfig | dict[str, Any],
) -> ProjectConfig:
    """Load ``.aimp/project.toml`` while replacing managed resources before validation."""
    raw = load_project_config_payload(project_dir)
    return build_project_config(raw, resource_override=resource_override)


def resolve_project_mode_names(config: ProjectConfig) -> list[str]:
    """Return enabled public mode names in canonical order."""
    return [name for name, mode in config.modes.items() if mode.enabled]



def write_project_config(project_dir: Path, config: ProjectConfig) -> Path:
    """Write the hidden scaffold configuration file."""
    from .serialization import serialize_project_config_toml

    config_path = project_dir / PROJECT_CONFIG_RELATIVE_PATH
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(serialize_project_config_toml(config), encoding="utf-8")
    return config_path


def write_agent_contract(project_dir: Path, metadata: AgentContractMetadata) -> Path:
    """Write the public metadata-only agent contract."""
    from .serialization import serialize_agent_contract_toml

    contract_path = project_dir / AGENT_CONTRACT_RELATIVE_PATH
    contract_path.parent.mkdir(parents=True, exist_ok=True)
    contract_path.write_text(serialize_agent_contract_toml(metadata), encoding="utf-8")
    return contract_path
