"""Shared publish-build watch rendering helpers."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from rich.console import Console


def _parse_timestamp(value: str | None) -> datetime | None:
    """Parse one optional ISO timestamp."""
    if not value:
        return None
    normalized = value.strip()
    if not normalized:
        return None
    try:
        parsed = datetime.fromisoformat(normalized.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def seconds_since_timestamp(value: str | None) -> int | None:
    """Return elapsed whole seconds since one timestamp."""
    parsed = _parse_timestamp(value)
    if parsed is None:
        return None
    return max(0, int((datetime.now(UTC) - parsed).total_seconds()))


def build_publish_watch_status_message(payload: dict[str, Any], *, job_id: str) -> str:
    """Build the compact live publish-build status line."""
    model_slug = str(payload.get("model_slug") or payload.get("slug") or "").strip()
    details = payload.get("details")
    details_payload = details if isinstance(details, dict) else {}
    version = str(payload.get("version") or details_payload.get("version") or "").strip()
    status_value = str(payload.get("status") or "unknown").strip() or "unknown"
    stage = str(payload.get("stage") or "").strip()
    last_progress_seconds = seconds_since_timestamp(
        str(payload.get("last_progress_at") or "").strip() or None
    )

    parts = [status_value]
    if stage:
        parts.append(stage)
    if last_progress_seconds is not None:
        parts.append(f"last progress {last_progress_seconds}s ago")
    if model_slug:
        parts.append(model_slug if not version else f"{model_slug}:{version}")
    parts.append(f"job {job_id[:8]}")
    return " · ".join(parts)


def render_publish_watch_logs(console: Console, items: list[dict[str, Any]]) -> None:
    """Render structured execution log items for publish-build watch flows."""
    for item in items:
        level = str(item.get("level") or "info").strip().lower()
        message = str(item.get("message") or "")
        if level == "error":
            console.print(f"[red]✗ {message}[/red]", soft_wrap=True)
        elif level == "warning":
            console.print(f"[yellow]⚠ {message}[/yellow]", soft_wrap=True)
        else:
            console.print(f"[dim]  {message}[/dim]", soft_wrap=True)


@dataclass(slots=True)
class PublishWatchRenderer:
    """Render one publish-build execution stream without duplicating steps."""

    console: Console
    job_id: str
    status_prefix: str = "Remote build"
    _last_stage: str | None = None
    _last_step: str | None = None
    _last_event_key: str | None = None
    _latest_execution: dict[str, Any] = field(default_factory=dict)

    def status_message(self, payload: dict[str, Any]) -> str:
        """Return the compact status line for one payload."""
        return f"{self.status_prefix}: " + build_publish_watch_status_message(
            payload,
            job_id=self.job_id,
        )

    def apply_snapshot(self, execution: dict[str, Any], status_handle: Any) -> None:
        """Render one snapshot payload."""
        self._latest_execution.clear()
        self._latest_execution.update(execution)
        self._render_state(execution)
        status_handle.update(self.status_message(execution))

    def apply_status(self, payload: dict[str, Any], status_handle: Any) -> None:
        """Render one incremental status payload."""
        merged = {**self._latest_execution, **payload}
        self._latest_execution.clear()
        self._latest_execution.update(merged)
        self._render_state(merged)
        status_handle.update(self.status_message(merged))

    def apply_terminal(self, execution: dict[str, Any], status_handle: Any) -> None:
        """Render one terminal payload."""
        self._latest_execution.clear()
        self._latest_execution.update(execution)
        self._render_state(execution)
        status_handle.update(self.status_message(execution))

    def render_timeline(self, items: list[dict[str, Any]]) -> None:
        """Render distinct timeline detail items."""
        for item in items:
            if not isinstance(item, dict):
                continue
            event = str(item.get("event") or "").strip()
            detail = str(item.get("detail") or "").strip()
            phase = str(item.get("phase") or "").strip()
            if not detail:
                continue
            event_key = "|".join((event, phase, detail))
            if event_key == self._last_event_key:
                continue
            self._last_event_key = event_key
            self.console.print(f"[cyan]Event:[/cyan] {event}: {detail}", soft_wrap=True)

    def render_logs(self, items: list[dict[str, Any]]) -> None:
        """Render raw structured log entries."""
        render_publish_watch_logs(self.console, items)

    def _render_state(self, payload: dict[str, Any]) -> None:
        """Render Stage/Step transitions once."""
        stage = str(payload.get("stage") or "").strip()
        if stage and stage != self._last_stage:
            self._last_stage = stage
            self.console.print(f"[cyan]Stage:[/cyan] {stage}", soft_wrap=True)

        step = str(payload.get("current_step_message") or "").strip()
        if step and step != self._last_step:
            self._last_step = step
            self.console.print(f"[bold]Step:[/bold] {step}", soft_wrap=True)
