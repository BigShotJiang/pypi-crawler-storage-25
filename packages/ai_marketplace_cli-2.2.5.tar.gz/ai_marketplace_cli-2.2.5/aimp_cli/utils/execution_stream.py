"""Shared SSE job stream parsing and watch helpers for the CLI."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from aimp_cli.core.config import CommandContext
from aimp_cli.core.errors import CliError, ErrorCategory, internal_error, network_error
from aimp_cli.domain.protocols import JobStreamGatewayProtocol


@dataclass(frozen=True)
class ExecutionStreamEvent:
    """One parsed SSE job event."""

    event: str
    payload: dict[str, Any]


@dataclass
class ExecutionStreamCallbacks:
    """Callback hooks invoked while consuming one job stream."""

    on_snapshot: Any | None = None
    on_status: Any | None = None
    on_timeline: Any | None = None
    on_logs: Any | None = None
    on_terminal: Any | None = None


@dataclass
class ExecutionStreamState:
    """Deduplication state persisted across reconnect attempts."""

    timeline_count_seen: int = 0
    log_count_seen: int = 0


def watch_execution_stream(
    *,
    gateway: JobStreamGatewayProtocol,
    job_id: str,
    context: CommandContext,
    callbacks: ExecutionStreamCallbacks | None = None,
) -> dict[str, Any]:
    """Watch one job SSE stream until a terminal payload is received."""
    callback_state = callbacks or ExecutionStreamCallbacks()
    stream_state = ExecutionStreamState()
    last_terminal_job: dict[str, Any] | None = None

    for attempt in range(2):
        try:
            with gateway.stream_job(job_id) as lines:
                for event in parse_execution_stream_events(lines, context=context):
                    if event.event == "snapshot":
                        _handle_snapshot_event(
                            event.payload,
                            stream_state=stream_state,
                            callbacks=callback_state,
                            context=context,
                        )
                        continue

                    if event.event == "status":
                        _handle_status_event(
                            event.payload, callbacks=callback_state, context=context
                        )
                        continue

                    if event.event == "timeline":
                        _handle_timeline_event(
                            event.payload,
                            stream_state=stream_state,
                            callbacks=callback_state,
                            context=context,
                        )
                        continue

                    if event.event == "logs":
                        _handle_logs_event(
                            event.payload,
                            stream_state=stream_state,
                            callbacks=callback_state,
                            context=context,
                        )
                        continue

                    if event.event == "terminal":
                        job = _handle_terminal_event(
                            event.payload,
                            stream_state=stream_state,
                            callbacks=callback_state,
                            context=context,
                        )
                        last_terminal_job = job
                        return job

                raise _job_stream_unavailable_error(
                    context=context,
                    job_id=job_id,
                    message="Job stream closed before a terminal event was received.",
                )
        except CliError as error:
            if _should_retry_stream_error(error, attempt):
                continue
            if error.http_status not in {401, 403, 404} and (
                error.code == "job_stream_unavailable"
                or error.category == ErrorCategory.NETWORK
            ):
                raise _job_stream_unavailable_error(
                    context=context,
                    job_id=job_id,
                    message=f"Job stream failed: {error}",
                ) from error
            raise
        except Exception as error:
            stream_error = _job_stream_unavailable_error(
                context=context,
                job_id=job_id,
                message=f"Job stream failed unexpectedly: {error}",
            )
            if attempt == 0:
                continue
            raise stream_error from error

    if last_terminal_job is not None:
        return last_terminal_job

    raise _job_stream_unavailable_error(
        context=context,
        job_id=job_id,
        message="Job stream unavailable after one reconnect attempt.",
    )


def parse_execution_stream_events(
    lines: Any,
    *,
    context: CommandContext,
) -> Any:
    """Parse SSE lines into structured execution events."""
    current_event: str | None = None
    data_lines: list[str] = []

    for raw_line in lines:
        line = raw_line if isinstance(raw_line, str) else str(raw_line)
        if line == "":
            parsed = _flush_sse_event(
                current_event=current_event,
                data_lines=data_lines,
                context=context,
            )
            if parsed is not None:
                yield parsed
            current_event = None
            data_lines = []
            continue

        if line.startswith(":"):
            continue
        if line.startswith("event:"):
            current_event = line.partition(":")[2].lstrip()
            continue
        if line.startswith("data:"):
            data_lines.append(line.partition(":")[2].lstrip())
            continue

    parsed = _flush_sse_event(
        current_event=current_event,
        data_lines=data_lines,
        context=context,
    )
    if parsed is not None:
        yield parsed


def _flush_sse_event(
    *,
    current_event: str | None,
    data_lines: list[str],
    context: CommandContext,
) -> ExecutionStreamEvent | None:
    """Flush the currently buffered SSE event when a frame boundary is reached."""
    if not data_lines:
        return None

    payload_text = "\n".join(data_lines).strip()
    try:
        payload = json.loads(payload_text)
    except json.JSONDecodeError as exc:
        raise _job_stream_unavailable_error(
            context=context,
            job_id="unknown",
            message="Gateway returned an invalid job stream payload.",
        ) from exc

    if not isinstance(payload, dict):
        raise internal_error(
            "Gateway returned an invalid job stream payload.",
            code="gateway_job_stream_payload_invalid",
            request_id=context.request_id,
            extra={"payload_type": type(payload).__name__},
        )

    event_name = (current_event or "message").strip()
    if not event_name:
        raise internal_error(
            "Gateway returned a job stream event without a name.",
            code="gateway_job_stream_event_invalid",
            request_id=context.request_id,
        )
    return ExecutionStreamEvent(event=event_name, payload=payload)


def _handle_snapshot_event(
    payload: dict[str, Any],
    *,
    stream_state: ExecutionStreamState,
    callbacks: ExecutionStreamCallbacks,
    context: CommandContext,
) -> None:
    """Apply a snapshot payload, including backfilling any unseen deltas."""
    job = _require_job_payload(payload, context=context)
    if callbacks.on_snapshot is not None:
        callbacks.on_snapshot(job)

    timeline = job.get("timeline")
    if isinstance(timeline, list):
        new_timeline = _slice_snapshot_items(
            items=timeline,
            seen_count=stream_state.timeline_count_seen,
        )
        if new_timeline and callbacks.on_timeline is not None:
            callbacks.on_timeline(new_timeline, payload)
        stream_state.timeline_count_seen = max(
            stream_state.timeline_count_seen,
            _coerce_count(payload.get("timeline_count"), fallback=len(timeline)),
        )

    logs = job.get("logs")
    if isinstance(logs, list):
        new_logs = _slice_snapshot_items(
            items=logs,
            seen_count=stream_state.log_count_seen,
        )
        if new_logs and callbacks.on_logs is not None:
            callbacks.on_logs(new_logs, payload)
        stream_state.log_count_seen = max(
            stream_state.log_count_seen,
            _coerce_count(payload.get("log_count"), fallback=len(logs)),
        )


def _handle_status_event(
    payload: dict[str, Any],
    *,
    callbacks: ExecutionStreamCallbacks,
    context: CommandContext,
) -> None:
    """Invoke the status callback for one status event."""
    if not isinstance(payload.get("status"), str):
        raise internal_error(
            "Gateway returned an execution status event without a status value.",
            code="gateway_execution_stream_event_invalid",
            request_id=context.request_id,
            extra={"event": "status"},
        )
    if callbacks.on_status is not None:
        callbacks.on_status(payload)


def _handle_timeline_event(
    payload: dict[str, Any],
    *,
    stream_state: ExecutionStreamState,
    callbacks: ExecutionStreamCallbacks,
    context: CommandContext,
) -> None:
    """Apply one timeline delta event with deduplication."""
    offset = _coerce_offset(payload.get("offset"), context=context, event_name="timeline")
    items = _coerce_items(payload.get("items"), context=context, event_name="timeline")
    new_items = _slice_delta_items(
        items=items,
        offset=offset,
        seen_count=stream_state.timeline_count_seen,
    )
    if new_items and callbacks.on_timeline is not None:
        callbacks.on_timeline(new_items, payload)
    stream_state.timeline_count_seen = max(stream_state.timeline_count_seen, offset + len(items))


def _handle_logs_event(
    payload: dict[str, Any],
    *,
    stream_state: ExecutionStreamState,
    callbacks: ExecutionStreamCallbacks,
    context: CommandContext,
) -> None:
    """Apply one logs delta event with deduplication."""
    offset = _coerce_offset(payload.get("offset"), context=context, event_name="logs")
    items = _coerce_items(payload.get("items"), context=context, event_name="logs")
    new_items = _slice_delta_items(
        items=items,
        offset=offset,
        seen_count=stream_state.log_count_seen,
    )
    if new_items and callbacks.on_logs is not None:
        callbacks.on_logs(new_items, payload)
    stream_state.log_count_seen = max(stream_state.log_count_seen, offset + len(items))


def _handle_terminal_event(
    payload: dict[str, Any],
    *,
    stream_state: ExecutionStreamState,
    callbacks: ExecutionStreamCallbacks,
    context: CommandContext,
) -> dict[str, Any]:
    """Apply one terminal event and return its final job payload."""
    job = _require_job_payload(payload, context=context)
    _handle_snapshot_event(
        payload,
        stream_state=stream_state,
        callbacks=ExecutionStreamCallbacks(
            on_snapshot=None,
            on_status=None,
            on_timeline=callbacks.on_timeline,
            on_logs=callbacks.on_logs,
            on_terminal=None,
        ),
        context=context,
    )
    if callbacks.on_terminal is not None:
        callbacks.on_terminal(job)
    return job


def _should_retry_stream_error(error: CliError, attempt: int) -> bool:
    """Return whether one stream failure should trigger the single reconnect."""
    if attempt >= 1:
        return False
    if error.http_status in {401, 403, 404}:
        return False
    if error.code == "job_stream_unavailable":
        return True
    return error.category == ErrorCategory.NETWORK


def _job_stream_unavailable_error(
    *,
    context: CommandContext,
    job_id: str,
    message: str,
) -> CliError:
    """Build the canonical CLI error for live job stream failures."""
    return network_error(
        message,
        code="job_stream_unavailable",
        request_id=context.request_id,
        hint=("Live job stream unavailable. Verify Gateway SSE connectivity and retry."),
        extra={"job_id": job_id},
    )


def _require_job_payload(
    payload: dict[str, Any], *, context: CommandContext
) -> dict[str, Any]:
    """Extract one job payload from a snapshot or terminal event."""
    job = payload.get("job")
    if isinstance(job, dict):
        return job
    raise internal_error(
        "Gateway returned a job stream event without a job payload.",
        code="gateway_job_stream_event_invalid",
        request_id=context.request_id,
    )


def _coerce_count(value: Any, *, fallback: int) -> int:
    """Return a non-negative count from a stream payload."""
    if isinstance(value, int) and value >= 0:
        return value
    return fallback


def _coerce_offset(
    value: Any,
    *,
    context: CommandContext,
    event_name: str,
) -> int:
    """Return a valid non-negative offset for delta payloads."""
    if isinstance(value, int) and value >= 0:
        return value
        raise internal_error(
            "Gateway returned a job stream event with an invalid offset.",
            code="gateway_job_stream_event_invalid",
            request_id=context.request_id,
            extra={"event": event_name, "offset": value},
        )


def _coerce_items(
    value: Any,
    *,
    context: CommandContext,
    event_name: str,
) -> list[dict[str, Any]]:
    """Return one validated list of item payloads."""
    if not isinstance(value, list):
        raise internal_error(
            "Gateway returned a job stream event with invalid items.",
            code="gateway_job_stream_event_invalid",
            request_id=context.request_id,
            extra={"event": event_name, "items_type": type(value).__name__},
        )
    return [item for item in value if isinstance(item, dict)]


def _slice_snapshot_items(*, items: list[Any], seen_count: int) -> list[dict[str, Any]]:
    """Return unseen items from a full snapshot payload."""
    if seen_count <= 0:
        return [item for item in items if isinstance(item, dict)]
    tail = items[seen_count:]
    return [item for item in tail if isinstance(item, dict)]


def _slice_delta_items(
    *,
    items: list[dict[str, Any]],
    offset: int,
    seen_count: int,
) -> list[dict[str, Any]]:
    """Return only unseen items from one offset-based delta payload."""
    if offset >= seen_count:
        return items
    skip = seen_count - offset
    if skip >= len(items):
        return []
    return items[skip:]
