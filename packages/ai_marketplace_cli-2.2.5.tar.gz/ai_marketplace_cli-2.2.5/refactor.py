#!/usr/bin/env python3
import os
import shutil
import re
from pathlib import Path

BASE_DIR = Path("/home/cc/AI-Marketplace-Platform/cli/aimp_cli")

def move_path(src, dst):
    src_path = BASE_DIR / src
    dst_path = BASE_DIR / dst
    if not src_path.exists():
        print(f"Skipping missing: {src}")
        return
    dst_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(src_path), str(dst_path))
    print(f"Moved {src} -> {dst}")

# 1. Create Directories and Move Files
moves = [
    # Core
    ("agent.py", "core/agent.py"),
    ("config.py", "core/config.py"),
    ("errors.py", "core/errors.py"),
    ("launcher.py", "core/launcher.py"),
    ("cli", "core/cli"),
    # Domain (Contracts + Models)
    ("contracts", "domain"),
    ("models.py", "domain/models.py"),
    ("protocols.py", "domain/protocols.py"),
    ("project.py", "domain/project.py"),
    # Clients
    ("gateway.py", "clients/gateway.py"),
    ("docker.py", "clients/docker.py"),
    ("studio_article.py", "clients/studio_article.py"),
    # Operations
    ("publish.py", "operations/publish/core.py"),
    ("publish_config.py", "operations/publish/config.py"),
    ("publish_local_metadata.py", "operations/publish/local_metadata.py"),
    ("services/publish.py", "operations/publish/service.py"),
    ("services/tuning.py", "operations/fine_tune/tuning.py"),
    ("services/agent.py", "operations/agent.py"),
    ("scaffold", "operations/scaffold"),
    # Utils
    ("interactive.py", "utils/interactive.py"),
    ("services/interactive.py", "utils/service_interactive.py"),
    ("execution_stream.py", "utils/execution_stream.py"),
    ("layers/core.py", "utils/layers.py"),
]

# We must map directories as well
# Wait, if we move `contracts` to `domain`, all files inside are moved. That's correct.
print("--- Moving Files ---")
for src, dst in moves:
    move_path(src, dst)

# Cleanup emptied dirs
for d in ["services", "layers"]:
    d_path = BASE_DIR / d
    if d_path.exists() and not os.listdir(d_path):
        d_path.rmdir()
        print(f"Removed empty dir {d}")
# Wait, aimp_cli/publish is an empty dir, let's remove it
if (BASE_DIR / "publish").exists() and not os.listdir(BASE_DIR / "publish"):
    (BASE_DIR / "publish").rmdir()

# Add __init__.py wherever missing
for root, dirs, files in os.walk(BASE_DIR):
    if "__init__.py" not in files and "__pycache__" not in root:
        (Path(root) / "__init__.py").touch()

print("--- Refactoring Imports ---")

replacements = [
    # Relative root imports (e.g. from .config, from ..config)
    (r'from \.+config import', r'from aimp_cli.core.config import'),
    (r'from \.+errors import', r'from aimp_cli.core.errors import'),
    (r'from \.+launcher import', r'from aimp_cli.core.launcher import'),
    (r'from \.+app import', r'from aimp_cli.core.app import'),
    (r'from \.+cli\.', r'from aimp_cli.core.cli.'),
    
    (r'from \.+models import', r'from aimp_cli.domain.models import'),
    (r'from \.+protocols import', r'from aimp_cli.domain.protocols import'),
    (r'from \.+project import', r'from aimp_cli.domain.project import'),
    (r'from \.+contracts\.', r'from aimp_cli.domain.'),
    (r'from \.+contracts import', r'from aimp_cli.domain import'),
    
    (r'from \.+gateway import', r'from aimp_cli.clients.gateway import'),
    (r'from \.+docker import', r'from aimp_cli.clients.docker import'),
    (r'from \.+studio_article import', r'from aimp_cli.clients.studio_article import'),
    
    # Specific file renames first before wildcards
    (r'from \.+services\.publish import', r'from aimp_cli.operations.publish.service import'),
    (r'from \.+publish_config import', r'from aimp_cli.operations.publish.config import'),
    (r'from \.+publish_local_metadata import', r'from aimp_cli.operations.publish.local_metadata import'),
    (r'from \.+publish import', r'from aimp_cli.operations.publish.core import'),
    
    (r'from \.+services\.tuning import', r'from aimp_cli.operations.fine_tune.tuning import'),
    (r'from \.+services\.agent import', r'from aimp_cli.operations.agent import'),
    (r'from \.+scaffold\.', r'from aimp_cli.operations.scaffold.'),
    (r'from \.+scaffold import', r'from aimp_cli.operations.scaffold import'),
    
    (r'from \.+services\.interactive import', r'from aimp_cli.utils.service_interactive import'),
    (r'from \.+interactive import', r'from aimp_cli.utils.interactive import'),
    (r'from \.+execution_stream import', r'from aimp_cli.utils.execution_stream import'),
    (r'from \.+layers\.core import', r'from aimp_cli.utils.docker_build import'),
    
    # Base module paths that shouldn't change namespace but maybe to absolute
    (r'from \.+commands\.', r'from aimp_cli.commands.'),
    (r'from \.+commands import', r'from aimp_cli.commands import'),
    (r'from \.+presentation\.', r'from aimp_cli.presentation.'),
    (r'from \.+presentation import', r'from aimp_cli.presentation import'),
    
    # Absolute module paths that were moved
    (r'aimp_cli\.config\b', r'aimp_cli.core.config'),
    (r'aimp_cli\.errors\b', r'aimp_cli.core.errors'),
    (r'aimp_cli\.launcher\b', r'aimp_cli.core.launcher'),
    (r'aimp_cli\.cli\.', r'aimp_cli.core.cli.'),
    
    (r'aimp_cli\.models\b', r'aimp_cli.domain.models'),
    (r'aimp_cli\.protocols\b', r'aimp_cli.domain.protocols'),
    (r'aimp_cli\.project\b', r'aimp_cli.domain.project'),
    (r'aimp_cli\.contracts\.', r'aimp_cli.domain.'),
    (r'aimp_cli\.contracts\b', r'aimp_cli.domain'),
    
    (r'aimp_cli\.gateway\b', r'aimp_cli.clients.gateway'),
    (r'aimp_cli\.docker\b', r'aimp_cli.clients.docker'),
    (r'aimp_cli\.studio_article\b', r'aimp_cli.clients.studio_article'),
    
    (r'aimp_cli\.publish\b', r'aimp_cli.operations.publish.core'),
    (r'aimp_cli\.publish_config\b', r'aimp_cli.operations.publish.config'),
    (r'aimp_cli\.publish_local_metadata\b', r'aimp_cli.operations.publish.local_metadata'),
    (r'aimp_cli\.services\.publish\b', r'aimp_cli.operations.publish.service'),
    (r'aimp_cli\.services\.tuning\b', r'aimp_cli.operations.fine_tune.tuning'),
    (r'aimp_cli\.services\.agent\b', r'aimp_cli.operations.agent'),
    (r'aimp_cli\.scaffold\b', r'aimp_cli.operations.scaffold'),
    
    (r'aimp_cli\.interactive\b', r'aimp_cli.utils.interactive'),
    (r'aimp_cli\.services\.interactive\b', r'aimp_cli.utils.service_interactive'),
    (r'aimp_cli\.execution_stream\b', r'aimp_cli.utils.execution_stream'),
    (r'aimp_cli\.layers\.core\b', r'aimp_cli.utils.docker_build'),
]

for directory in [BASE_DIR, Path("/home/cc/AI-Marketplace-Platform/cli/tests")]:
    for py_file in directory.rglob("*.py"):
        content = py_file.read_text()
        original = content
        
        for pattern, repl in replacements:
            content = re.sub(pattern, repl, content)
            
        if content != original:
            py_file.write_text(content)
            print(f"Updated imports in {py_file}")

print("Done refactoring.")
