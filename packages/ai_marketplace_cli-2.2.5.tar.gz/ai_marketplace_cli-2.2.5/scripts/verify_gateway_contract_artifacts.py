#!/usr/bin/env python3
"""Verify Gateway->CLI contract artifacts are present, tracked, and clean."""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
REQUIRED_ARTIFACTS: tuple[str, ...] = (
    "gateway/openapi/cli_contract_openapi.json",
    "cli/aimp_cli/generated/gateway_contracts/models.py",
    "cli/aimp_cli/generated/gateway_contracts/__init__.py",
    "cli/aimp_cli/generated/__init__.py",
)


def _run_git(*, repo_root: Path, args: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["git", *args],
        cwd=repo_root,
        check=False,
        text=True,
        capture_output=True,
    )


def _tracked_paths(*, repo_root: Path, paths: tuple[str, ...]) -> list[str]:
    untracked: list[str] = []
    for path in paths:
        result = _run_git(repo_root=repo_root, args=["ls-files", "--error-unmatch", "--", path])
        if result.returncode != 0:
            untracked.append(path)
    return untracked


def _changed_paths(*, repo_root: Path, staged: bool, paths: tuple[str, ...]) -> list[str]:
    args = ["diff", "--name-only", "--", *paths]
    if staged:
        args = ["diff", "--cached", "--name-only", "--", *paths]
    result = _run_git(repo_root=repo_root, args=args)
    if result.returncode not in {0, 1}:
        stderr = result.stderr.strip() or "unknown git diff failure"
        raise RuntimeError(f"git diff failed: {stderr}")
    return [line.strip() for line in result.stdout.splitlines() if line.strip()]


def verify_gateway_contract_artifacts(*, repo_root: Path) -> None:
    repo_result = _run_git(repo_root=repo_root, args=["rev-parse", "--is-inside-work-tree"])
    if repo_result.returncode != 0:
        raise RuntimeError(f"Not a git repository: {repo_root}")

    missing = [path for path in REQUIRED_ARTIFACTS if not (repo_root / path).is_file()]
    if missing:
        joined = "\n".join(f"- {path}" for path in missing)
        raise RuntimeError(f"Missing required generated artifacts:\n{joined}")

    untracked = _tracked_paths(repo_root=repo_root, paths=REQUIRED_ARTIFACTS)
    if untracked:
        joined = "\n".join(f"- {path}" for path in untracked)
        raise RuntimeError(f"Required artifacts are untracked:\n{joined}")

    unstaged_changes = _changed_paths(repo_root=repo_root, staged=False, paths=REQUIRED_ARTIFACTS)
    if unstaged_changes:
        joined = "\n".join(f"- {path}" for path in unstaged_changes)
        raise RuntimeError(f"Unstaged contract artifact drift detected:\n{joined}")

    staged_changes = _changed_paths(repo_root=repo_root, staged=True, paths=REQUIRED_ARTIFACTS)
    if staged_changes:
        joined = "\n".join(f"- {path}" for path in staged_changes)
        raise RuntimeError(f"Staged contract artifact drift detected:\n{joined}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--repo-root",
        type=Path,
        default=REPO_ROOT,
        help=f"Repository root containing tracked artifacts (default: {REPO_ROOT})",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    verify_gateway_contract_artifacts(repo_root=args.repo_root.resolve())
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except RuntimeError as error:
        print(str(error), file=sys.stderr)
        raise SystemExit(1) from error
