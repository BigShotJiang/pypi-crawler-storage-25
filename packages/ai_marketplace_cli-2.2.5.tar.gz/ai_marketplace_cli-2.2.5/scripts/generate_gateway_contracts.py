#!/usr/bin/env python3
"""Generate CLI transport models from the Gateway CLI OpenAPI contract snapshot.

Toolchain invariants (kept explicit for reproducibility):
- datamodel-code-generator package version is pinned exactly.
- installed CLI runtime pydantic version is pinned exactly.
- datamodel-code-generator targets pydantic major versions only; we target v2.
"""

from __future__ import annotations

import argparse
import importlib.metadata
import shutil
import subprocess
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_SCHEMA = REPO_ROOT / "gateway" / "openapi" / "cli_contract_openapi.json"
DEFAULT_OUTPUT_DIR = REPO_ROOT / "cli" / "aimp_cli" / "generated" / "gateway_contracts"
EXPECTED_DATAMODEL_CODEGEN_VERSION = "0.56.0"
EXPECTED_CLI_PYDANTIC_VERSION = "2.10.6"
TARGET_PYDANTIC_VERSION = "2"
GENERATED_PACKAGE_ROOT = REPO_ROOT / "cli" / "aimp_cli" / "generated"

INIT_FILE_CONTENT = '''"""Gateway-owned CLI transport models.

This module is generated from Gateway OpenAPI.
Do not edit manually.
"""

from .models import (
    CliModelLookupResponse,
    CliModelSecretListResponse,
    CliModelSecretMetadata,
    CliModelSecretSetRequest,
    CliPublishHardwareTier,
    CliPublishMetadataResponse,
    CliPublishReadiness,
    CliPublishResponse,
    CliReleaseRuntimeState,
    PartCompletionInfo,
    PublishRequest,
    UploadAbortRequest,
    UploadAbortResponse,
    UploadCompleteRequest,
    UploadCompleteResponse,
    UploadInitRequest,
    UploadInitResponse,
    UploadPartResponse,
)

ModelLookupResponse = CliModelLookupResponse
ModelSecretListResponse = CliModelSecretListResponse
ModelSecretMetadata = CliModelSecretMetadata
ModelSecretSetRequest = CliModelSecretSetRequest
PublishHardwareTier = CliPublishHardwareTier
PublishMetadataResponse = CliPublishMetadataResponse
PublishReadiness = CliPublishReadiness
PublishResponse = CliPublishResponse
ReleaseRuntimeState = CliReleaseRuntimeState
UploadPart = UploadPartResponse

__all__ = [
    "CliModelLookupResponse",
    "CliModelSecretListResponse",
    "CliModelSecretMetadata",
    "CliModelSecretSetRequest",
    "CliPublishHardwareTier",
    "CliPublishMetadataResponse",
    "CliPublishReadiness",
    "CliPublishResponse",
    "CliReleaseRuntimeState",
    "ModelLookupResponse",
    "ModelSecretListResponse",
    "ModelSecretMetadata",
    "ModelSecretSetRequest",
    "PartCompletionInfo",
    "PublishHardwareTier",
    "PublishMetadataResponse",
    "PublishReadiness",
    "PublishRequest",
    "PublishResponse",
    "ReleaseRuntimeState",
    "UploadAbortRequest",
    "UploadAbortResponse",
    "UploadCompleteRequest",
    "UploadCompleteResponse",
    "UploadInitRequest",
    "UploadInitResponse",
    "UploadPart",
    "UploadPartResponse",
]
'''

GENERATED_ROOT_INIT_CONTENT = '"""Generated transport contracts consumed by the CLI."""\n'


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--schema",
        type=Path,
        default=DEFAULT_SCHEMA,
        help=f"Gateway CLI OpenAPI schema snapshot (default: {DEFAULT_SCHEMA})",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=DEFAULT_OUTPUT_DIR,
        help=f"Output package directory (default: {DEFAULT_OUTPUT_DIR})",
    )
    return parser.parse_args()


def _assert_tooling_available() -> None:
    if shutil.which("datamodel-codegen") is None:
        raise RuntimeError(
            "datamodel-codegen is not installed in the active environment. "
            "Run this script via: uv run --project cli "
            "--with-requirements cli/scripts/requirements-contract-generation.txt "
            "python cli/scripts/generate_gateway_contracts.py"
        )
    datamodel_version = importlib.metadata.version("datamodel-code-generator")
    if datamodel_version != EXPECTED_DATAMODEL_CODEGEN_VERSION:
        raise RuntimeError(
            "datamodel-code-generator version mismatch: "
            f"expected {EXPECTED_DATAMODEL_CODEGEN_VERSION}, got {datamodel_version}. "
            "Use cli/scripts/requirements-contract-generation.txt."
        )
    pydantic_version = importlib.metadata.version("pydantic")
    if pydantic_version != EXPECTED_CLI_PYDANTIC_VERSION:
        raise RuntimeError(
            "installed CLI runtime pydantic version mismatch for contract generation: "
            f"expected {EXPECTED_CLI_PYDANTIC_VERSION}, got {pydantic_version}. "
            "Align cli/pyproject.toml and this script together."
        )


def generate_models(*, schema: Path, output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    models_path = output_dir / "models.py"
    cmd = [
        "datamodel-codegen",
        "--input",
        str(schema),
        "--input-file-type",
        "openapi",
        "--output",
        str(models_path),
        "--output-model-type",
        "pydantic_v2.BaseModel",
        "--target-python-version",
        "3.13",
        "--target-pydantic-version",
        TARGET_PYDANTIC_VERSION,
        "--disable-timestamp",
        "--extra-fields",
        "forbid",
        "--field-constraints",
        "--use-standard-collections",
        "--use-union-operator",
        "--formatters",
        "ruff-format",
        "ruff-check",
    ]
    subprocess.run(cmd, check=True)
    (output_dir / "__init__.py").write_text(INIT_FILE_CONTENT, encoding="utf-8")
    generated_root = output_dir.parent
    if generated_root == GENERATED_PACKAGE_ROOT:
        (generated_root / "__init__.py").write_text(
            GENERATED_ROOT_INIT_CONTENT,
            encoding="utf-8",
        )


def main() -> int:
    args = parse_args()
    if not args.schema.exists():
        raise FileNotFoundError(
            f"Schema snapshot not found: {args.schema}. "
            "Export first via gateway/scripts/export_openapi.py."
        )
    _assert_tooling_available()
    generate_models(schema=args.schema, output_dir=args.output_dir)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
