"""Tests for multipart upload behavior."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest
import httpx

from aimp_cli.core.errors import CliError, network_error
from aimp_cli.clients.gateway import UploadClient
from aimp_cli.clients.gateway import _FileSliceStream


class FakeGateway:
    """Small fake used by upload tests."""

    def upload_init(self, request: Any) -> Any:
        return type(
            "InitResponse",
            (),
            {
                "upload_id": "upload-1",
                "artifact_id": "artifact-1",
                "expires_at": "2026-01-01T00:00:00Z",
                "parts": [],
                "complete_url": "",
                "abort_url": "",
                "storage_backend": "s3",
                "upload_strategy": "single",
            },
        )()

    def upload_complete(self, request: Any) -> Any:
        return type(
            "CompleteResponse",
            (),
            {
                "storage_uri": "s3://bucket/demo",
                "artifact_id": "artifact-1",
                "size_bytes": 0,
            },
        )()

    def upload_abort(self, request: Any) -> None:
        self.aborted = request.upload_id


def test_upload_rejects_invalid_concurrency(tmp_path: Path) -> None:
    upload_client = UploadClient(FakeGateway())
    test_file = tmp_path / "payload.bin"
    test_file.write_bytes(b"demo")
    with pytest.raises(CliError, match="Upload concurrency must be an integer between 1 and 8"):
        upload_client.upload_file(
            file_path=test_file,
            slug="demo",
            version="0.1.0",
            artifact_type="docker_image",
            content_type="application/x-tar",
            metadata=None,
            concurrency=0,
            on_progress=None,
        )


def test_upload_preserves_primary_error_when_abort_cleanup_fails(tmp_path: Path) -> None:
    class FailingGateway(FakeGateway):
        def upload_init(self, request: Any) -> Any:
            return type(
                "InitResponse",
                (),
                {
                    "upload_id": "upload-1",
                    "artifact_id": "artifact-1",
                    "expires_at": "2026-01-01T00:00:00Z",
                    "parts": [
                        type(
                            "UploadPart",
                            (),
                            {
                                "part_number": 1,
                                "url": "http://example.com/part-1",
                                "size_bytes": 4,
                                "headers": {},
                            },
                        )()
                    ],
                    "complete_url": "",
                    "abort_url": "",
                    "storage_backend": "s3",
                    "upload_strategy": "single",
                },
            )()

        def upload_abort(self, request: Any) -> None:
            raise RuntimeError("abort failed")

    upload_client = UploadClient(FailingGateway())
    test_file = tmp_path / "payload.bin"
    test_file.write_bytes(b"demo")

    def fail_part(*args: Any, **kwargs: Any) -> str:
        raise network_error("Upload failed: part timeout", code="upload_failed")

    upload_client._upload_part_with_retry = fail_part  # type: ignore[method-assign]

    with pytest.raises(CliError) as exc_info:
        upload_client.upload_file(
            file_path=test_file,
            slug="demo",
            version="0.1.0",
            artifact_type="docker_image",
            content_type="application/x-tar",
            metadata=None,
            concurrency=1,
            on_progress=None,
        )

    assert exc_info.value.code == "upload_failed"
    assert exc_info.value.extra["abort_error"] == "abort failed"


def test_file_slice_stream_reads_only_requested_range(tmp_path: Path) -> None:
    file_path = tmp_path / "payload.bin"
    file_path.write_bytes(b"0123456789")

    with _FileSliceStream(file_path=file_path, offset=2, length=4) as stream:
        assert stream.read(2) == b"23"
        assert stream.read() == b"45"
        assert stream.read() == b""


def test_upload_part_uses_httpx_compatible_byte_iterator(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Part upload must pass an iterable of bytes, not a custom stream object, to httpx."""
    upload_client = UploadClient(FakeGateway())
    file_path = tmp_path / "payload.bin"
    file_path.write_bytes(b"abcdefgh")
    captured: dict[str, Any] = {}

    class _Response:
        headers = {"etag": "etag-1"}

        def raise_for_status(self) -> None:
            return None

    class _HttpxClientStub:
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            _ = args, kwargs

        def __enter__(self) -> "_HttpxClientStub":
            return self

        def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
            _ = exc_type, exc, tb

        def put(self, url: str, *, content: Any = None, headers: dict[str, str] | None = None) -> _Response:
            captured["url"] = url
            captured["headers"] = headers
            captured["content_type"] = type(content)
            captured["body"] = b"".join(content)
            return _Response()

    monkeypatch.setattr(httpx, "Client", _HttpxClientStub)

    etag = upload_client._upload_part_with_retry(
        file_path=file_path,
        offset=2,
        length=4,
        url="http://example.com/upload-part",
        required_headers={"x-test": "1"},
    )

    assert etag == "etag-1"
    assert captured["url"] == "http://example.com/upload-part"
    assert captured["headers"]["Content-Length"] == "4"
    assert captured["body"] == b"cdef"
    assert captured["content_type"] is not _FileSliceStream
