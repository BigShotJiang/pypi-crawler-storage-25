"""Command-layer publish conflict handling tests."""

from __future__ import annotations

from types import SimpleNamespace
from typing import Any

import pytest
from rich.console import Console

from aimp_cli.commands.common import CommandRuntime
from aimp_cli.commands.publish import run_publish_command
from aimp_cli.core.config import build_command_context
from aimp_cli.core.errors import CliError, remote_state_error
from aimp_cli.core.launcher import LauncherOption
from aimp_cli.domain.models import CliPublishResult, PublishBuildGroup, PublishBuildProfile
from aimp_cli.domain.project import default_project_config, load_project_config, write_project_config


def _conflict_error(*, job_id: str = "group-existing") -> CliError:
    return remote_state_error(
        "Publish intent for 'demo-model:0.1.0' does not match existing publish build group intent.",
        code="publish_build_intent_conflict",
        http_status=409,
        extra={
            "existing_job_id": job_id,
            "existing_status": "running",
            "existing_stage": "release_bundle_prepare",
            "model_slug": "demo-model",
            "version": "0.1.0",
        },
    )


def _build_group(*, job_id: str = "group-existing", status: str = "running") -> PublishBuildGroup:
    return PublishBuildGroup(
        job_id=job_id,
        slug="demo-model",
        version="0.1.0",
        status=status,
        stage="release_bundle_prepare",
        phase="release_bundle_prepare",
        current_step_message="Preparing release bundle",
        requested_profiles=[
            PublishBuildProfile(
                runtime_profile="cpu",
                supported_hardware_tiers=["cpu-basic"],
            )
        ],
        registration_result=(
            {
                "id": "asset-1",
                "slug": "demo-model",
                "visibility": "private",
                "readiness": {"is_ready": True, "blocking_reasons": []},
                "url": "https://example.com/models/demo-model",
            }
            if status == "succeeded"
            else {}
        ),
    )


class _ClientStub:
    def __init__(self, *, build_group: PublishBuildGroup | None = None) -> None:
        self.closed = False
        self.build_group = build_group or _build_group()
        self.get_publish_build_group_calls: list[str] = []
        self.get_publish_metadata_calls = 0

    def close(self) -> None:
        self.closed = True

    def get_publish_build_group(self, job_id: str) -> PublishBuildGroup:
        self.get_publish_build_group_calls.append(job_id)
        return self.build_group

    def get_publish_metadata(self) -> Any:
        self.get_publish_metadata_calls += 1
        return SimpleNamespace(
            hardware_tiers=[
                SimpleNamespace(id="cpu-basic", label="CPU Basic", description="Baseline CPU tier"),
                SimpleNamespace(id="gpu-a10", label="GPU A10", description="Accelerated GPU tier"),
            ]
        )


def _build_runtime(
    *,
    client: _ClientStub,
    run_publish_impl: Any,
    interactive: bool,
    emitted: list[dict[str, Any]],
) -> CommandRuntime:
    return CommandRuntime(
        console=Console(record=True, force_terminal=False),
        build_command_context=build_command_context,
        emit_result=lambda payload, **kwargs: emitted.append({"payload": payload, **kwargs}),
        config_store=SimpleNamespace(),
        has_interactive_terminal=lambda: interactive,
        can_prompt_for_input=lambda: interactive,
        require_tty=lambda: None,
        resolve_auth_context=lambda gateway, api_key: SimpleNamespace(api_key="pk-test"),
        prompt_text=lambda *args, **kwargs: "",
        prompt_secret=lambda *args, **kwargs: "",
        confirm_action=lambda *args, **kwargs: True,
        gateway_client_cls=lambda auth_context, context: client,
        upload_client_cls=lambda gateway: None,
        docker_client_cls=lambda: None,
        run_publish=run_publish_impl,
    )


def _publish_config_stub() -> SimpleNamespace:
    return SimpleNamespace(
        studio=SimpleNamespace(name="Demo Model"),
        pricing={"developer_margin": 0},
    )


def _patch_publish_config(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        "aimp_cli.commands.publish.ensure_publish_config",
        lambda **kwargs: _publish_config_stub(),
    )


def _write_project_config(project_dir: Any, *, selected_hardware_tier: str | None = None) -> None:
    config = default_project_config()
    config.publish.selected_hardware_tier = selected_hardware_tier
    write_project_config(project_dir, config)


def test_run_publish_command_uses_saved_hardware_without_prompt(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Any,
) -> None:
    emitted: list[dict[str, Any]] = []
    client = _ClientStub()
    publish_calls: list[dict[str, Any]] = []
    monkeypatch.chdir(tmp_path)
    _write_project_config(tmp_path, selected_hardware_tier="cpu-basic")

    runtime = _build_runtime(
        client=client,
        run_publish_impl=lambda **kwargs: publish_calls.append(kwargs)
        or CliPublishResult(
            slug="demo-model",
            id="asset-1",
            visibility="private",
            url="https://example.com/models/demo-model",
        ),
        interactive=True,
        emitted=emitted,
    )
    _patch_publish_config(monkeypatch)
    monkeypatch.setattr(
        "aimp_cli.commands.publish.select_menu",
        lambda *args, **kwargs: (_ for _ in ()).throw(AssertionError("prompt should not run")),
    )

    run_publish_command(
        runtime=runtime,
        gateway=None,
        api_key=None,
        slug=None,
        parallel=3,
        hardware=None,
        verbose=False,
        json_output=False,
        debug=False,
        python_bin=None,
        configure_only=False,
        force=False,
        detach=False,
        build_publish_success_message=lambda result: f"published {result.id}",
    )

    assert publish_calls[0]["selected_hardware_tier"] == "cpu-basic"
    assert client.get_publish_metadata_calls == 1
    assert load_project_config(tmp_path).publish.selected_hardware_tier == "cpu-basic"


def test_run_publish_command_saves_selected_hardware_from_prompt(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Any,
) -> None:
    emitted: list[dict[str, Any]] = []
    client = _ClientStub()
    publish_calls: list[dict[str, Any]] = []
    monkeypatch.chdir(tmp_path)
    _write_project_config(tmp_path)

    runtime = _build_runtime(
        client=client,
        run_publish_impl=lambda **kwargs: publish_calls.append(kwargs)
        or CliPublishResult(
            slug="demo-model",
            id="asset-1",
            visibility="private",
            url="https://example.com/models/demo-model",
        ),
        interactive=True,
        emitted=emitted,
    )
    _patch_publish_config(monkeypatch)
    monkeypatch.setattr(
        "aimp_cli.commands.publish.select_menu",
        lambda *args, **kwargs: LauncherOption(
            key="cpu-basic",
            label="CPU Basic",
            description="",
            handler=lambda: None,
        ),
    )

    run_publish_command(
        runtime=runtime,
        gateway=None,
        api_key=None,
        slug=None,
        parallel=3,
        hardware=None,
        verbose=False,
        json_output=False,
        debug=False,
        python_bin=None,
        configure_only=False,
        force=False,
        detach=False,
        build_publish_success_message=lambda result: f"published {result.id}",
    )

    assert publish_calls[0]["selected_hardware_tier"] == "cpu-basic"
    assert load_project_config(tmp_path).publish.selected_hardware_tier == "cpu-basic"


def test_run_publish_command_updates_saved_hardware_from_flag(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Any,
) -> None:
    emitted: list[dict[str, Any]] = []
    client = _ClientStub()
    publish_calls: list[dict[str, Any]] = []
    monkeypatch.chdir(tmp_path)
    _write_project_config(tmp_path, selected_hardware_tier="cpu-basic")

    runtime = _build_runtime(
        client=client,
        run_publish_impl=lambda **kwargs: publish_calls.append(kwargs)
        or CliPublishResult(
            slug="demo-model",
            id="asset-1",
            visibility="private",
            url="https://example.com/models/demo-model",
        ),
        interactive=True,
        emitted=emitted,
    )
    _patch_publish_config(monkeypatch)

    run_publish_command(
        runtime=runtime,
        gateway=None,
        api_key=None,
        slug=None,
        parallel=3,
        hardware="gpu-a10",
        verbose=False,
        json_output=False,
        debug=False,
        python_bin=None,
        configure_only=False,
        force=False,
        detach=False,
        build_publish_success_message=lambda result: f"published {result.id}",
    )

    assert publish_calls[0]["selected_hardware_tier"] == "gpu-a10"
    assert client.get_publish_metadata_calls == 0
    assert load_project_config(tmp_path).publish.selected_hardware_tier == "gpu-a10"


def test_run_publish_command_non_interactive_requires_saved_or_explicit_hardware(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Any,
) -> None:
    emitted: list[dict[str, Any]] = []
    client = _ClientStub()
    captured_error: dict[str, Any] = {}
    monkeypatch.chdir(tmp_path)
    _write_project_config(tmp_path)

    runtime = _build_runtime(
        client=client,
        run_publish_impl=lambda **kwargs: CliPublishResult(
            slug="demo-model",
            id="asset-1",
            visibility="private",
            url="https://example.com/models/demo-model",
        ),
        interactive=False,
        emitted=emitted,
    )
    _patch_publish_config(monkeypatch)

    def _capture_exit(error: Exception, **kwargs: Any) -> None:
        captured_error["error"] = error
        raise RuntimeError("captured")

    monkeypatch.setattr("aimp_cli.commands.publish.exit_with_error", _capture_exit)

    with pytest.raises(RuntimeError, match="captured"):
        run_publish_command(
            runtime=runtime,
            gateway=None,
            api_key=None,
            slug=None,
            parallel=3,
            hardware=None,
            verbose=False,
            json_output=True,
            debug=False,
            python_bin=None,
            configure_only=False,
            force=False,
            detach=False,
            build_publish_success_message=lambda result: f"published {result.id}",
        )

    error = captured_error["error"]
    assert isinstance(error, CliError)
    assert error.code == "selected_hardware_tier_missing"


def test_run_publish_command_interactive_replaces_unavailable_saved_hardware(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Any,
) -> None:
    emitted: list[dict[str, Any]] = []
    client = _ClientStub()
    publish_calls: list[dict[str, Any]] = []
    monkeypatch.chdir(tmp_path)
    _write_project_config(tmp_path, selected_hardware_tier="gpu-old")

    runtime = _build_runtime(
        client=client,
        run_publish_impl=lambda **kwargs: publish_calls.append(kwargs)
        or CliPublishResult(
            slug="demo-model",
            id="asset-1",
            visibility="private",
            url="https://example.com/models/demo-model",
        ),
        interactive=True,
        emitted=emitted,
    )
    _patch_publish_config(monkeypatch)
    monkeypatch.setattr(
        "aimp_cli.commands.publish.select_menu",
        lambda *args, **kwargs: LauncherOption(
            key="cpu-basic",
            label="CPU Basic",
            description="",
            handler=lambda: None,
        ),
    )

    run_publish_command(
        runtime=runtime,
        gateway=None,
        api_key=None,
        slug=None,
        parallel=3,
        hardware=None,
        verbose=False,
        json_output=False,
        debug=False,
        python_bin=None,
        configure_only=False,
        force=False,
        detach=False,
        build_publish_success_message=lambda result: f"published {result.id}",
    )

    assert publish_calls[0]["selected_hardware_tier"] == "cpu-basic"
    assert load_project_config(tmp_path).publish.selected_hardware_tier == "cpu-basic"


def test_run_publish_command_non_interactive_rejects_unavailable_saved_hardware(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Any,
) -> None:
    emitted: list[dict[str, Any]] = []
    client = _ClientStub()
    captured_error: dict[str, Any] = {}
    monkeypatch.chdir(tmp_path)
    _write_project_config(tmp_path, selected_hardware_tier="gpu-old")

    runtime = _build_runtime(
        client=client,
        run_publish_impl=lambda **kwargs: CliPublishResult(
            slug="demo-model",
            id="asset-1",
            visibility="private",
            url="https://example.com/models/demo-model",
        ),
        interactive=False,
        emitted=emitted,
    )
    _patch_publish_config(monkeypatch)

    def _capture_exit(error: Exception, **kwargs: Any) -> None:
        captured_error["error"] = error
        raise RuntimeError("captured")

    monkeypatch.setattr("aimp_cli.commands.publish.exit_with_error", _capture_exit)

    with pytest.raises(RuntimeError, match="captured"):
        run_publish_command(
            runtime=runtime,
            gateway=None,
            api_key=None,
            slug=None,
            parallel=3,
            hardware=None,
            verbose=False,
            json_output=True,
            debug=False,
            python_bin=None,
            configure_only=False,
            force=False,
            detach=False,
            build_publish_success_message=lambda result: f"published {result.id}",
        )

    error = captured_error["error"]
    assert isinstance(error, CliError)
    assert error.code == "selected_hardware_tier_unavailable"


def test_run_publish_command_watchs_existing_build_after_conflict(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Any,
) -> None:
    emitted: list[dict[str, Any]] = []
    client = _ClientStub()
    publish_calls: list[dict[str, Any]] = []
    monkeypatch.chdir(tmp_path)
    _write_project_config(tmp_path, selected_hardware_tier="cpu-basic")

    def _run_publish(**kwargs: Any) -> CliPublishResult:
        publish_calls.append(kwargs)
        raise _conflict_error()

    runtime = _build_runtime(
        client=client,
        run_publish_impl=_run_publish,
        interactive=True,
        emitted=emitted,
    )
    _patch_publish_config(monkeypatch)
    monkeypatch.setattr(
        "aimp_cli.commands.publish.select_menu",
        lambda *args, **kwargs: LauncherOption(
            key="watch_existing_build",
            label="Watch Existing Build",
            description="",
            handler=lambda: None,
        ),
    )
    monkeypatch.setattr(
        "aimp_cli.commands.publish.resolve_publish_build_group_result",
        lambda **kwargs: CliPublishResult(
            slug="demo-model",
            id="asset-1",
            visibility="private",
            url="https://example.com/models/demo-model",
        ),
    )

    run_publish_command(
        runtime=runtime,
        gateway=None,
        api_key=None,
        slug=None,
        parallel=3,
        hardware="cpu-basic",
        verbose=False,
        json_output=False,
        debug=False,
        python_bin=None,
        configure_only=False,
        force=False,
        detach=False,
        build_publish_success_message=lambda result: f"published {result.id}",
    )

    assert len(publish_calls) == 1
    assert client.get_publish_build_group_calls == ["group-existing"]
    assert emitted == [
        {
            "payload": {
                "slug": "demo-model",
                "id": "asset-1",
                "visibility": "private",
                "url": "https://example.com/models/demo-model",
                "readiness": {"is_ready": False, "blocking_reasons": []},
                "request_id": emitted[0]["payload"]["request_id"],
            },
            "json_output": False,
            "success_message": "published asset-1",
            "title": "PUBLISH",
        }
    ]


def test_run_publish_command_cancels_and_rebuilds_after_conflict(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Any,
) -> None:
    emitted: list[dict[str, Any]] = []
    client = _ClientStub()
    publish_calls: list[dict[str, Any]] = []
    canceled_jobs: list[dict[str, Any]] = []
    monkeypatch.chdir(tmp_path)
    _write_project_config(tmp_path, selected_hardware_tier="cpu-basic")

    def _run_publish(**kwargs: Any) -> CliPublishResult:
        publish_calls.append(kwargs)
        if len(publish_calls) == 1:
            raise _conflict_error()
        return CliPublishResult(
            slug="demo-model",
            id="asset-2",
            visibility="private",
            url="https://example.com/models/demo-model",
        )

    runtime = _build_runtime(
        client=client,
        run_publish_impl=_run_publish,
        interactive=True,
        emitted=emitted,
    )
    _patch_publish_config(monkeypatch)
    monkeypatch.setattr(
        "aimp_cli.commands.publish.select_menu",
        lambda *args, **kwargs: LauncherOption(
            key="cancel_and_rebuild",
            label="Cancel And Rebuild",
            description="",
            handler=lambda: None,
        ),
    )
    monkeypatch.setattr(
        "aimp_cli.commands.publish.cancel_publish_build_group",
        lambda **kwargs: canceled_jobs.append(kwargs),
    )

    run_publish_command(
        runtime=runtime,
        gateway=None,
        api_key=None,
        slug=None,
        parallel=3,
        hardware="cpu-basic",
        verbose=False,
        json_output=False,
        debug=False,
        python_bin=None,
        configure_only=False,
        force=False,
        detach=True,
        build_publish_success_message=lambda result: f"published {result.id}",
    )

    assert len(publish_calls) == 2
    assert publish_calls[0]["force"] is False
    assert publish_calls[1]["force"] is True
    assert publish_calls[1]["detach"] is True
    assert canceled_jobs == [
        {
            "gateway": client,
            "job_id": "group-existing",
            "poll_interval_seconds": 1.0,
        }
    ]
    assert emitted[0]["success_message"] == "published asset-2"


def test_run_publish_command_keeps_existing_build_and_exits_cleanly(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Any,
) -> None:
    emitted: list[dict[str, Any]] = []
    client = _ClientStub()
    publish_calls: list[dict[str, Any]] = []
    monkeypatch.chdir(tmp_path)
    _write_project_config(tmp_path, selected_hardware_tier="cpu-basic")

    def _run_publish(**kwargs: Any) -> CliPublishResult:
        publish_calls.append(kwargs)
        raise _conflict_error()

    runtime = _build_runtime(
        client=client,
        run_publish_impl=_run_publish,
        interactive=True,
        emitted=emitted,
    )
    _patch_publish_config(monkeypatch)
    monkeypatch.setattr(
        "aimp_cli.commands.publish.select_menu",
        lambda *args, **kwargs: LauncherOption(
            key="keep_existing_and_exit",
            label="Keep Existing And Exit",
            description="",
            handler=lambda: None,
        ),
    )

    run_publish_command(
        runtime=runtime,
        gateway=None,
        api_key=None,
        slug=None,
        parallel=3,
        hardware="cpu-basic",
        verbose=False,
        json_output=False,
        debug=False,
        python_bin=None,
        configure_only=False,
        force=False,
        detach=False,
        build_publish_success_message=lambda result: f"published {result.id}",
    )

    assert len(publish_calls) == 1
    assert client.get_publish_build_group_calls == ["group-existing"]
    assert emitted[0]["payload"]["detached"] is True
    assert emitted[0]["payload"]["publish_build_group_id"] == "group-existing"
    assert "Existing remote build kept running." in emitted[0]["success_message"]
    assert "ai jobs watch --type build --job group-existing" in emitted[0]["success_message"]


def test_run_publish_command_non_interactive_conflict_preserves_structured_error_with_hint(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Any,
) -> None:
    emitted: list[dict[str, Any]] = []
    client = _ClientStub()
    captured_error: dict[str, Any] = {}
    monkeypatch.chdir(tmp_path)
    _write_project_config(tmp_path, selected_hardware_tier="cpu-basic")

    runtime = _build_runtime(
        client=client,
        run_publish_impl=lambda **kwargs: (_ for _ in ()).throw(_conflict_error()),
        interactive=False,
        emitted=emitted,
    )
    _patch_publish_config(monkeypatch)

    def _capture_exit(error: Exception, **kwargs: Any) -> None:
        captured_error["error"] = error
        raise RuntimeError("captured")

    monkeypatch.setattr("aimp_cli.commands.publish.exit_with_error", _capture_exit)

    with pytest.raises(RuntimeError, match="captured"):
        run_publish_command(
            runtime=runtime,
            gateway=None,
            api_key=None,
            slug=None,
            parallel=3,
            hardware="cpu-basic",
            verbose=False,
            json_output=True,
            debug=False,
            python_bin=None,
            configure_only=False,
            force=False,
            detach=False,
            build_publish_success_message=lambda result: f"published {result.id}",
        )

    error = captured_error["error"]
    assert isinstance(error, CliError)
    assert error.code == "publish_build_intent_conflict"
    assert error.hint is not None
    assert "ai jobs watch --type build --job group-existing" in error.hint
    assert "ai jobs cancel --type build --job group-existing" in error.hint
    assert "ai push --force" in error.hint


def test_run_publish_command_retry_conflict_does_not_loop(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Any,
) -> None:
    emitted: list[dict[str, Any]] = []
    client = _ClientStub()
    publish_calls: list[dict[str, Any]] = []
    canceled_jobs: list[dict[str, Any]] = []
    captured_error: dict[str, Any] = {}
    monkeypatch.chdir(tmp_path)
    _write_project_config(tmp_path, selected_hardware_tier="cpu-basic")

    def _run_publish(**kwargs: Any) -> CliPublishResult:
        publish_calls.append(kwargs)
        raise _conflict_error()

    runtime = _build_runtime(
        client=client,
        run_publish_impl=_run_publish,
        interactive=True,
        emitted=emitted,
    )
    _patch_publish_config(monkeypatch)
    monkeypatch.setattr(
        "aimp_cli.commands.publish.select_menu",
        lambda *args, **kwargs: LauncherOption(
            key="cancel_and_rebuild",
            label="Cancel And Rebuild",
            description="",
            handler=lambda: None,
        ),
    )
    monkeypatch.setattr(
        "aimp_cli.commands.publish.cancel_publish_build_group",
        lambda **kwargs: canceled_jobs.append(kwargs),
    )

    def _capture_exit(error: Exception, **kwargs: Any) -> None:
        captured_error["error"] = error
        raise RuntimeError("captured")

    monkeypatch.setattr("aimp_cli.commands.publish.exit_with_error", _capture_exit)

    with pytest.raises(RuntimeError, match="captured"):
        run_publish_command(
            runtime=runtime,
            gateway=None,
            api_key=None,
            slug=None,
            parallel=3,
            hardware="cpu-basic",
            verbose=False,
            json_output=False,
            debug=False,
            python_bin=None,
            configure_only=False,
            force=False,
            detach=False,
            build_publish_success_message=lambda result: f"published {result.id}",
        )

    assert len(publish_calls) == 2
    assert publish_calls[0]["force"] is False
    assert publish_calls[1]["force"] is True
    assert len(canceled_jobs) == 1
    error = captured_error["error"]
    assert isinstance(error, CliError)
    assert error.code == "publish_build_intent_conflict"
