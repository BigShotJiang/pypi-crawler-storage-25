"""Documentation guardrails for CLI publish flow."""

from __future__ import annotations

from pathlib import Path


def test_cli_readme_describes_platform_build_only_publish_flow() -> None:
    """CLI README should describe source-bundle upload plus platform build only."""
    readme = (Path(__file__).resolve().parents[1] / "README.md").read_text(encoding="utf-8")

    assert "CLI creates a source bundle from the local build context" in readme
    assert "Build Service builds the image inside the platform" in readme
    assert "final model publish resolves artifacts from the succeeded build job only" in readme
    assert "Registry credentials configured for the registry returned by Gateway" not in readme
