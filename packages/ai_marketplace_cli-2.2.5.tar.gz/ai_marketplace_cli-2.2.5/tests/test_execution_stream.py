"""Tests for unified CLI job SSE helpers."""

from __future__ import annotations

import json
from contextlib import contextmanager
from typing import Any

import pytest

from aimp_cli.core.config import build_command_context
from aimp_cli.core.errors import CliError, network_error
from aimp_cli.utils.execution_stream import (
    ExecutionStreamCallbacks,
    parse_execution_stream_events,
    watch_execution_stream,
)


def test_parse_execution_stream_events_supports_all_event_types_and_comments() -> None:
    """The SSE parser should decode all supported event frames and ignore comments."""
    context = build_command_context("job.stream", debug=False, json_output=True)
    snapshot_payload = {"job": {"job_id": "exec-1"}, "timeline_count": 0, "log_count": 0}
    status_payload = {
        "job_id": "exec-1",
        "job_type": "build",
        "status": "running",
    }
    timeline_payload = {
        "job_id": "exec-1",
        "job_type": "build",
        "offset": 0,
        "count": 1,
        "items": [{"status": "running"}],
    }
    logs_payload = {
        "job_id": "exec-1",
        "job_type": "build",
        "offset": 0,
        "count": 1,
        "items": [{"message": "hello"}],
    }
    terminal_payload = {"job": {"job_id": "exec-1"}, "timeline_count": 1, "log_count": 1}
    lines = [
        ": keep-alive",
        "",
        "event: snapshot",
        f"data: {json.dumps(snapshot_payload)}",
        "",
        "event: status",
        f"data: {json.dumps(status_payload)}",
        "",
        "event: timeline",
        f"data: {json.dumps(timeline_payload)}",
        "",
        "event: logs",
        f"data: {json.dumps(logs_payload)}",
        "",
        "event: terminal",
        f"data: {json.dumps(terminal_payload)}",
        "",
    ]

    events = list(parse_execution_stream_events(lines, context=context))

    assert [event.event for event in events] == [
        "snapshot",
        "status",
        "timeline",
        "logs",
        "terminal",
    ]
    assert events[1].payload["status"] == "running"
    assert events[3].payload["items"][0]["message"] == "hello"


def test_watch_execution_stream_reconnects_once_without_replaying_seen_items() -> None:
    """Reconnect should dedupe already seen timeline/log entries across snapshots."""
    context = build_command_context("job.watch", debug=False, json_output=False)
    seen_timeline: list[str] = []
    seen_logs: list[str] = []

    class _InterruptingIterator:
        def __init__(self, lines: list[str]) -> None:
            self._lines = iter(lines)

        def __iter__(self) -> _InterruptingIterator:
            return self

        def __next__(self) -> str:
            try:
                return next(self._lines)
            except StopIteration as exc:
                raise network_error(
                    "stream interrupted",
                    code="job_stream_unavailable",
                    request_id=context.request_id,
                ) from exc

    class _Gateway:
        def __init__(self) -> None:
            self.attempt = 0

        @contextmanager
        def stream_job(self, job_id: str) -> Any:
            self.attempt += 1
            if self.attempt == 1:
                yield _InterruptingIterator(
                    [
                        "event: snapshot",
                        (
                            "data: "
                            + json.dumps(
                                {
                                    "job": {
                                        "job_id": job_id,
                                        "job_type": "build",
                                        "model_slug": "demo-model",
                                        "status": "running",
                                        "timeline": [{"status": "queued"}],
                                        "logs": [{"message": "first"}],
                                    },
                                    "timeline_count": 1,
                                    "log_count": 1,
                                }
                            )
                        ),
                        "",
                        "event: timeline",
                        (
                            "data: "
                            + json.dumps(
                                {
                                    "job_id": job_id,
                                    "job_type": "build",
                                    "offset": 1,
                                    "count": 1,
                                    "items": [{"status": "running"}],
                                }
                            )
                        ),
                        "",
                        "event: logs",
                        (
                            "data: "
                            + json.dumps(
                                {
                                    "job_id": job_id,
                                    "job_type": "build",
                                    "offset": 1,
                                    "count": 1,
                                    "items": [{"message": "warning"}],
                                }
                            )
                        ),
                        "",
                    ]
                )
                return

            yield iter(
                [
                    "event: snapshot",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job": {
                                    "job_id": job_id,
                                    "job_type": "build",
                                    "model_slug": "demo-model",
                                    "status": "running",
                                    "timeline": [
                                        {"status": "queued"},
                                        {"status": "running"},
                                    ],
                                    "logs": [
                                        {"message": "first"},
                                        {"message": "warning"},
                                    ],
                                },
                                "timeline_count": 2,
                                "log_count": 2,
                            }
                        )
                    ),
                    "",
                    "event: terminal",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job": {
                                    "job_id": job_id,
                                    "job_type": "build",
                                    "model_slug": "demo-model",
                                    "status": "succeeded",
                                    "timeline": [
                                        {"status": "queued"},
                                        {"status": "running"},
                                    ],
                                    "logs": [
                                        {"message": "first"},
                                        {"message": "warning"},
                                        {"message": "final"},
                                    ],
                                },
                                "timeline_count": 2,
                                "log_count": 3,
                            }
                        )
                    ),
                    "",
                ]
            )

    job = watch_execution_stream(
        gateway=_Gateway(),
        job_id="exec-1",
        context=context,
        callbacks=ExecutionStreamCallbacks(
            on_timeline=lambda items, _payload: seen_timeline.extend(
                str(item.get("status") or "") for item in items
            ),
            on_logs=lambda items, _payload: seen_logs.extend(
                str(item.get("message") or "") for item in items
            ),
        ),
    )

    assert job["status"] == "succeeded"
    assert seen_timeline == ["queued", "running"]
    assert seen_logs == ["first", "warning", "final"]


def test_watch_execution_stream_processes_fine_tune_logs_from_snapshot_and_terminal() -> None:
    """Fine-tune streams should surface logs via snapshot backfill and terminal delta."""
    context = build_command_context("job.watch", debug=False, json_output=False)
    seen_logs: list[str] = []

    class _Gateway:
        @contextmanager
        def stream_job(self, job_id: str) -> Any:
            yield iter(
                [
                    "event: snapshot",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job": {
                                    "job_id": job_id,
                                    "job_type": "fine-tune",
                                    "model_slug": "vision-pro",
                                    "status": "running",
                                    "timeline": [{"status": "queued"}],
                                    "logs": [{"message": "Creating tuning study"}],
                                    "details": {"adapter_format": "lora"},
                                },
                                "timeline_count": 1,
                                "log_count": 1,
                            }
                        )
                    ),
                    "",
                    "event: terminal",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job": {
                                    "job_id": job_id,
                                    "job_type": "fine-tune",
                                    "model_slug": "vision-pro",
                                    "status": "succeeded",
                                    "timeline": [{"status": "queued"}, {"status": "succeeded"}],
                                    "logs": [
                                        {"message": "Creating tuning study"},
                                        {"message": "Fine-tune job succeeded"},
                                    ],
                                    "details": {"adapter_format": "lora"},
                                },
                                "timeline_count": 2,
                                "log_count": 2,
                            }
                        )
                    ),
                    "",
                ]
            )

    job = watch_execution_stream(
        gateway=_Gateway(),
        job_id="ft-1",
        context=context,
        callbacks=ExecutionStreamCallbacks(
            on_logs=lambda items, _payload: seen_logs.extend(
                str(item.get("message") or "") for item in items
            )
        ),
    )

    assert job["status"] == "succeeded"
    assert seen_logs == ["Creating tuning study", "Fine-tune job succeeded"]


def test_watch_execution_stream_fails_after_second_stream_error() -> None:
    """A second SSE failure should surface the canonical job stream error."""
    context = build_command_context("job.watch", debug=False, json_output=False)

    class _Gateway:
        @contextmanager
        def stream_job(self, job_id: str) -> Any:
            raise network_error(
                f"gateway offline for {job_id}",
                code="gateway_unreachable",
                request_id=context.request_id,
            )
            yield iter(())

    with pytest.raises(CliError) as exc_info:
        watch_execution_stream(
            gateway=_Gateway(),
            job_id="exec-2",
            context=context,
        )

    assert exc_info.value.code == "job_stream_unavailable"
    assert exc_info.value.request_id == context.request_id
    assert exc_info.value.extra["job_id"] == "exec-2"
