"""Command-layer jobs detail/watch regression tests."""

from __future__ import annotations

import json
from contextlib import contextmanager
from types import SimpleNamespace
from typing import Any

from rich.console import Console

from aimp_cli.commands.common import CommandRuntime
from aimp_cli.commands.jobs import jobs_get_command, jobs_watch_command
from aimp_cli.core.config import build_command_context


class _ClientStub:
    def __init__(self) -> None:
        self.closed = False

    def close(self) -> None:
        self.closed = True

    def get_job(self, *, job_id: str) -> dict[str, Any]:
        return {
            "job_type": "build",
            "job_id": job_id,
            "model_slug": "zzz",
            "slug": "zzz",
            "version": "0.1.0",
            "status": "running",
            "stage": "runtime_matrix_build",
            "current_step_message": "Installing runtime dependencies",
            "timeline": [],
            "logs": [],
            "details": {"version": "0.1.0"},
        }

    @contextmanager
    def stream_job(self, job_id: str) -> Any:
        yield iter(
            [
                "event: snapshot",
                (
                    "data: "
                    + json.dumps(
                        {
                            "job": self.get_job(job_id=job_id),
                            "timeline_count": 0,
                            "log_count": 0,
                        }
                    )
                ),
                "",
                "event: terminal",
                (
                    "data: "
                    + json.dumps(
                        {
                            "job": {
                                **self.get_job(job_id=job_id),
                                "status": "succeeded",
                            },
                            "timeline_count": 0,
                            "log_count": 0,
                        }
                    )
                ),
                "",
            ]
        )


def _build_runtime(*, client: _ClientStub, emitted: list[dict[str, Any]]) -> CommandRuntime:
    return CommandRuntime(
        console=Console(record=True, force_terminal=False),
        build_command_context=build_command_context,
        emit_result=lambda payload, **kwargs: emitted.append({"payload": payload, **kwargs}),
        config_store=SimpleNamespace(),
        has_interactive_terminal=lambda: False,
        can_prompt_for_input=lambda: False,
        require_tty=lambda: None,
        resolve_auth_context=lambda gateway, api_key: SimpleNamespace(api_key="pk-test"),
        prompt_text=lambda *args, **kwargs: "",
        prompt_secret=lambda *args, **kwargs: "",
        confirm_action=lambda *args, **kwargs: True,
        gateway_client_cls=lambda auth_context, context: client,
        upload_client_cls=lambda gateway: None,
        docker_client_cls=lambda: None,
        run_publish=lambda **kwargs: None,
    )


def test_jobs_get_command_accepts_raw_execution_payload() -> None:
    emitted: list[dict[str, Any]] = []
    client = _ClientStub()
    runtime = _build_runtime(client=client, emitted=emitted)

    jobs_get_command(
        runtime=runtime,
        job_type="build",
        job="job-build-1",
        gateway=None,
        api_key=None,
        json_output=True,
        debug=False,
        render_job_detail=lambda payload: payload,
    )

    assert client.closed is True
    assert emitted[0]["payload"]["job_type"] == "build"
    assert emitted[0]["payload"]["job"]["job_id"] == "job-build-1"


def test_jobs_watch_command_accepts_raw_execution_payload() -> None:
    emitted: list[dict[str, Any]] = []
    client = _ClientStub()
    runtime = _build_runtime(client=client, emitted=emitted)

    jobs_watch_command(
        runtime=runtime,
        job_type="build",
        job="job-build-2",
        gateway=None,
        api_key=None,
        json_output=False,
        debug=False,
    )

    output = runtime.console.export_text()
    assert client.closed is True
    assert "Stage: runtime_matrix_build" in output
    assert "Step: Installing runtime dependencies" in output
