"""Tests for constrained MDX Studio article helpers."""

from __future__ import annotations

from pathlib import Path

import pytest

from aimp_cli.clients.studio_article import (
    collect_local_media_references,
    parse_constrained_mdx,
    replace_media_sources,
    tiptap_to_constrained_mdx,
)


def test_parse_constrained_mdx_accepts_media_tags() -> None:
    payload = parse_constrained_mdx(
        '## Overview\n\n<Image src="./media/cover.png" alt="Cover" width="md" align="center" />\n'
    )
    image_node = payload["content"]["content"][1]
    assert image_node["type"] == "image"
    assert image_node["attrs"]["src"] == "./media/cover.png"
    assert image_node["attrs"]["width"] == "md"


def test_parse_constrained_mdx_accepts_h1_and_h4() -> None:
    payload = parse_constrained_mdx("# Overview\n\n#### Details\n")
    content = payload["content"]["content"]

    assert content[0]["type"] == "heading"
    assert content[0]["attrs"]["level"] == 1
    assert content[1]["type"] == "heading"
    assert content[1]["attrs"]["level"] == 4


def test_parse_constrained_mdx_rejects_imports() -> None:
    with pytest.raises(RuntimeError, match="does not allow import/export"):
        parse_constrained_mdx('import X from "y"\n')


def test_parse_constrained_mdx_rejects_h5() -> None:
    with pytest.raises(RuntimeError, match="#, ##, ###, or #### only"):
        parse_constrained_mdx("##### Too Deep\n")


def test_collect_and_replace_local_media_references(tmp_path: Path) -> None:
    article_path = tmp_path / "studio" / "article.mdx"
    article_path.parent.mkdir(parents=True)
    article_path.write_text("## Overview\n", encoding="utf-8")
    payload = parse_constrained_mdx(
        "## Overview\n\n"
        '<Image src="./media/pic.png" alt="Cover" />\n\n'
        '<Video src="./media/demo.mp4" />\n'
    )
    refs = collect_local_media_references(payload, article_path=article_path)
    assert {ref.source for ref in refs} == {"./media/pic.png", "./media/demo.mp4"}

    replaced = replace_media_sources(
        payload,
        {
            "./media/pic.png": "https://cdn.example.com/pic.png",
            "./media/demo.mp4": "https://cdn.example.com/demo.mp4",
        },
    )
    content = replaced["content"]["content"]
    assert content[1]["attrs"]["src"] == "https://cdn.example.com/pic.png"
    assert content[2]["attrs"]["src"] == "https://cdn.example.com/demo.mp4"


def test_tiptap_to_constrained_mdx_emits_media_tags() -> None:
    mdx = tiptap_to_constrained_mdx(
        {
            "format": "tiptap-json",
            "schema_version": 1,
            "content": {
                "type": "doc",
                "content": [
                    {
                        "type": "heading",
                        "attrs": {"level": 2},
                        "content": [{"type": "text", "text": "Overview"}],
                    },
                    {
                        "type": "image",
                        "attrs": {"src": "https://cdn.example.com/pic.png", "alt": "Cover"},
                    },
                ],
            },
        }
    )
    assert "## Overview" in mdx
    assert '<Image src="https://cdn.example.com/pic.png" alt="Cover" />' in mdx


def test_tiptap_to_constrained_mdx_preserves_h1_and_h4() -> None:
    mdx = tiptap_to_constrained_mdx(
        {
            "format": "tiptap-json",
            "schema_version": 1,
            "content": {
                "type": "doc",
                "content": [
                    {
                        "type": "heading",
                        "attrs": {"level": 1},
                        "content": [{"type": "text", "text": "Overview"}],
                    },
                    {
                        "type": "heading",
                        "attrs": {"level": 4},
                        "content": [{"type": "text", "text": "Details"}],
                    },
                ],
            },
        }
    )

    assert "# Overview" in mdx
    assert "#### Details" in mdx
