"""Tests for project-aware interactive launcher behavior."""

from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

from rich.console import Console

import aimp_cli.utils.interactive as interactive_module
from aimp_cli.core.config import ConfigStore
from aimp_cli.core.launcher import LauncherActionResult


def _callbacks() -> interactive_module.LauncherCallbacks:
    return interactive_module.LauncherCallbacks(
        init_project=lambda name: None,
        configure_project=lambda: None,
        validate_contract=lambda: None,
        show_contract=lambda: None,
        configure_publish=lambda: None,
        publish_project=lambda: None,
        create_fine_tune_job=lambda model_slug, dataset_path: None,
        list_jobs=lambda job_type: None,
        get_job_detail=lambda job_type, job_id: None,
        cancel_job=lambda job_type, job_id: None,
        delete_job=lambda job_type, job_id: None,
        login=lambda gateway, api_key: None,
        auth=lambda: None,
        logout=lambda: None,
        inspect_model=lambda slug: None,
        pull_model=lambda slug: None,
        list_active_build=lambda slug: None,
        cancel_build=lambda job_id: None,
    )


def test_launcher_home_shows_create_project_without_local_project(
    tmp_path: Path,
    monkeypatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    captured_sections: list[list[interactive_module.LauncherSection]] = []

    def fake_run_interactive_launcher(sections_factory, **kwargs) -> str:
        _ = kwargs
        captured_sections.append(sections_factory())
        return "quit"

    monkeypatch.setattr(
        interactive_module,
        "run_interactive_launcher",
        fake_run_interactive_launcher,
    )
    config_store = ConfigStore(tmp_path / "config.json")

    interactive_module.interactive_launcher(
        console=Console(),
        config_store=config_store,
        callbacks=_callbacks(),
    )

    project_options = captured_sections[0][0].options
    assert [option.label for option in project_options] == ["Create project"]
    jobs_options = captured_sections[0][1].options
    assert [option.label for option in jobs_options] == [
        "Login required",
    ]


def test_launcher_home_shows_project_actions_when_local_project_exists(
    tmp_path: Path,
    monkeypatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    contract_path = tmp_path / ".aimp" / "project.toml"
    contract_path.parent.mkdir(parents=True)
    contract_path.write_text("schema_version = 2\n", encoding="utf-8")
    captured_sections: list[list[interactive_module.LauncherSection]] = []

    def fake_run_interactive_launcher(sections_factory, **kwargs) -> str:
        _ = kwargs
        captured_sections.append(sections_factory())
        return "quit"

    monkeypatch.setattr(
        interactive_module,
        "run_interactive_launcher",
        fake_run_interactive_launcher,
    )
    config_store = ConfigStore(tmp_path / "config.json")

    interactive_module.interactive_launcher(
        console=Console(),
        config_store=config_store,
        callbacks=_callbacks(),
    )

    project_options = captured_sections[0][0].options
    labels = [option.label for option in project_options]
    assert labels == [
        "Configure project",
        "Validate contract",
        "Show contract",
        "Configure publish",
        "Publish project",
    ]
    assert "Create project" not in labels
    jobs_options = captured_sections[0][1].options
    assert [option.label for option in jobs_options] == [
        "Login required",
    ]


def test_launcher_home_keeps_account_and_marketplace_sections_for_local_project(
    tmp_path: Path,
    monkeypatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    contract_path = tmp_path / ".aimp" / "project.toml"
    contract_path.parent.mkdir(parents=True)
    contract_path.write_text("schema_version = 2\n", encoding="utf-8")
    captured_sections: list[list[interactive_module.LauncherSection]] = []

    def fake_run_interactive_launcher(sections_factory, **kwargs) -> str:
        _ = kwargs
        captured_sections.append(sections_factory())
        return "quit"

    monkeypatch.setattr(
        interactive_module,
        "run_interactive_launcher",
        fake_run_interactive_launcher,
    )
    config_store = ConfigStore(tmp_path / "config.json")
    config_store._config = SimpleNamespace(
        api_key="pk_test",
        username="alice",
        default_workspace="acme",
    )

    interactive_module.interactive_launcher(
        console=Console(),
        config_store=config_store,
        callbacks=_callbacks(),
    )

    sections = captured_sections[0]
    assert [section.title for section in sections] == [
        "Project",
        "Workflows & Jobs",
        "Marketplace",
        "Account",
    ]
    assert [option.label for option in sections[2].options] == ["Marketplace Models"]
    assert sections[3].options[0].label == "Session: alice (acme)"


def test_marketplace_models_submenu_lists_remote_model_actions(monkeypatch) -> None:
    captured_home_sections: list[list[interactive_module.LauncherSection]] = []
    captured_submenu_sections: list[list[interactive_module.LauncherSection]] = []
    run_calls = {"count": 0}

    def fake_run_interactive_launcher(sections_factory, **kwargs) -> str:
        _ = kwargs
        run_calls["count"] += 1
        if run_calls["count"] == 1:
            captured_home_sections.append(sections_factory())
            return "quit"
        captured_submenu_sections.append(sections_factory())
        return "back"

    monkeypatch.setattr(
        interactive_module,
        "run_interactive_launcher",
        fake_run_interactive_launcher,
    )
    monkeypatch.setattr(
        interactive_module,
        "prompt_text",
        lambda *args, **kwargs: "vision-pro",
    )

    inspect_calls: list[str] = []
    pull_calls: list[str] = []
    callbacks = interactive_module.LauncherCallbacks(
        init_project=lambda name: None,
        configure_project=lambda: None,
        validate_contract=lambda: None,
        show_contract=lambda: None,
        configure_publish=lambda: None,
        publish_project=lambda: None,
        create_fine_tune_job=lambda model_slug, dataset_path: None,
        list_jobs=lambda job_type: None,
        get_job_detail=lambda job_type, job_id: None,
        cancel_job=lambda job_type, job_id: None,
        delete_job=lambda job_type, job_id: None,
        login=lambda gateway, api_key: None,
        auth=lambda: None,
        logout=lambda: None,
        inspect_model=lambda slug: inspect_calls.append(slug),
        pull_model=lambda slug: pull_calls.append(slug),
        list_active_build=lambda slug: None,
        cancel_build=lambda job_id: None,
    )

    config_store = ConfigStore(Path("/tmp/nonexistent-config.json"))
    config_store._config = SimpleNamespace(
        api_key="pk_test",
        username="alice",
        default_workspace="acme",
    )

    interactive_module.interactive_launcher(
        console=Console(),
        config_store=config_store,
        callbacks=callbacks,
    )

    marketplace_handler = captured_home_sections[0][2].options[0].handler
    marketplace_handler()

    submenu_options = captured_submenu_sections[0][0].options
    assert [option.label for option in submenu_options] == [
        "Inspect model",
        "Pull metadata",
        "Go Back",
    ]
    assert inspect_calls == []
    assert pull_calls == []


def test_jobs_launcher_browse_flow_dispatches_without_manual_job_id(monkeypatch) -> None:
    create_calls: list[tuple[str, str]] = []
    job_detail_calls: list[tuple[str, str]] = []
    list_calls: list[str] = []
    captured_sections: list[tuple[str | None, list[interactive_module.LauncherSection]]] = []
    run_calls: dict[str, int] = {"count": 0}

    def fake_run_interactive_launcher(sections_factory, **kwargs) -> str:
        run_calls["count"] += 1
        captured_sections.append((kwargs.get("title"), sections_factory()))
        return "quit"

    prompt_values = iter(["vision-pro", "./vision-pro-fine-tune"])

    monkeypatch.setattr(
        interactive_module,
        "run_interactive_launcher",
        fake_run_interactive_launcher,
    )
    monkeypatch.setattr(
        interactive_module,
        "prompt_text",
        lambda *args, **kwargs: next(prompt_values),
    )

    callbacks = interactive_module.LauncherCallbacks(
        init_project=lambda name: None,
        configure_project=lambda: None,
        validate_contract=lambda: None,
        show_contract=lambda: None,
        configure_publish=lambda: None,
        publish_project=lambda: None,
        create_fine_tune_job=lambda model_slug, dataset_path: create_calls.append(
            (model_slug, dataset_path)
        ),
        list_jobs=lambda job_type: list_calls.append(job_type)
        or [
            interactive_module.LauncherJobItem(
                job_id="build-1-abcdef",
                job_type="build",
                model_slug="vision-pro",
                status="running",
                created_at="2026-03-18T10:00:00Z",
            )
        ],
        get_job_detail=lambda job_type, job_id: job_detail_calls.append((job_type, job_id))
        or LauncherActionResult(
            title="Job Details",
            content=f"{job_type}:{job_id}",
            status="info",
        ),
        cancel_job=lambda job_type, job_id: LauncherActionResult(
            title="Cancel Job",
            content=f"cancel:{job_type}:{job_id}",
            status="success",
        ),
        delete_job=lambda job_type, job_id: LauncherActionResult(
            title="Delete Job",
            content=f"delete:{job_type}:{job_id}",
            status="success",
        ),
        login=lambda gateway, api_key: None,
        auth=lambda: None,
        logout=lambda: None,
        inspect_model=lambda slug: None,
        pull_model=lambda slug: None,
        list_active_build=lambda slug: None,
        cancel_build=lambda job_id: None,
    )

    config_store = ConfigStore(Path("/tmp/nonexistent-config.json"))
    config_store._config = SimpleNamespace(
        api_key="pk_test",
        username="alice",
        default_workspace="acme",
    )

    interactive_module.interactive_launcher(
        console=Console(),
        config_store=config_store,
        callbacks=callbacks,
    )

    home_jobs_options = captured_sections[0][1][1].options
    home_jobs_options[0].handler()
    home_jobs_options[1].handler()

    assert "all" in list_calls
    assert captured_sections[1][0] == "Jobs"
    job_options = captured_sections[1][1][0].options
    assert job_options[0].label == "[build] vision-pro (build-1-) · running"

    # Selecting a job now opens the per-job action submenu (captured as section 2)
    job_options[0].handler()
    assert captured_sections[2][0] == "vision-pro · running"
    action_options = captured_sections[2][1][0].options
    action_labels = [o.label for o in action_options]
    # Active job: View Details + Cancel + Go Back (no Delete)
    assert "View Details" in action_labels
    assert "Cancel Job" in action_labels
    assert "Go Back" in action_labels
    assert "Delete Job" not in action_labels

    # Triggering View Details calls get_job_detail
    view_option = next(o for o in action_options if o.label == "View Details")
    detail_result = view_option.handler()
    assert job_detail_calls == [("build", "build-1-abcdef")]
    assert isinstance(detail_result, LauncherActionResult)
    assert detail_result.content == "build:build-1-abcdef"


def test_jobs_launcher_browse_shows_empty_state(monkeypatch) -> None:
    list_calls: list[str] = []
    captured_sections: list[tuple[str | None, list[interactive_module.LauncherSection]]] = []

    def fake_run_interactive_launcher(sections_factory, **kwargs) -> str:
        captured_sections.append((kwargs.get("title"), sections_factory()))
        return "quit"

    monkeypatch.setattr(
        interactive_module,
        "run_interactive_launcher",
        fake_run_interactive_launcher,
    )

    callbacks = interactive_module.LauncherCallbacks(
        init_project=lambda name: None,
        configure_project=lambda: None,
        validate_contract=lambda: None,
        show_contract=lambda: None,
        configure_publish=lambda: None,
        publish_project=lambda: None,
        create_fine_tune_job=lambda model_slug, dataset_path: None,
        list_jobs=lambda job_type: list_calls.append(job_type) or [],
        get_job_detail=lambda job_type, job_id: None,
        cancel_job=lambda job_type, job_id: None,
        delete_job=lambda job_type, job_id: None,
        login=lambda gateway, api_key: None,
        auth=lambda: None,
        logout=lambda: None,
        inspect_model=lambda slug: None,
        pull_model=lambda slug: None,
        list_active_build=lambda slug: None,
        cancel_build=lambda job_id: None,
    )

    config_store = ConfigStore(Path("/tmp/nonexistent-config.json"))
    config_store._config = SimpleNamespace(
        api_key="pk_test",
        username="alice",
        default_workspace="acme",
    )

    interactive_module.interactive_launcher(
        console=Console(),
        config_store=config_store,
        callbacks=callbacks,
    )

    home_jobs_handler = captured_sections[0][1][1].options[1].handler
    result = home_jobs_handler()

    assert list_calls == ["all"]
    assert isinstance(result, LauncherActionResult)
    assert result.title == "Jobs"
    assert "No jobs found" in result.content


def test_session_submenu_uses_persistent_launcher_loop(monkeypatch) -> None:
    captured_home_sections: list[list[interactive_module.LauncherSection]] = []
    captured_submenu_sections: list[list[interactive_module.LauncherSection]] = []
    run_calls = {"count": 0}

    def fake_run_interactive_launcher(sections_factory, **kwargs) -> str:
        _ = kwargs
        run_calls["count"] += 1
        if run_calls["count"] == 1:
            captured_home_sections.append(sections_factory())
            return "quit"
        captured_submenu_sections.append(sections_factory())
        return "back"

    monkeypatch.setattr(
        interactive_module,
        "run_interactive_launcher",
        fake_run_interactive_launcher,
    )

    config_store = ConfigStore(Path("/tmp/nonexistent-config.json"))
    config_store._config = SimpleNamespace(
        api_key="pk_test",
        username="alice",
        default_workspace="acme",
    )

    interactive_module.interactive_launcher(
        console=Console(),
        config_store=config_store,
        callbacks=_callbacks(),
    )

    session_handler = captured_home_sections[0][3].options[0].handler
    session_handler()

    submenu_options = captured_submenu_sections[0][0].options
    assert [option.label for option in submenu_options] == [
        "View Status",
        "Logout",
        "Go Back",
    ]


def test_jobs_browse_job_submenu_shows_cancel_for_active_job(monkeypatch) -> None:
    """An active (queued/running) job submenu shows View Details + Cancel, not Delete."""
    captured_sections: list[tuple[str | None, list[interactive_module.LauncherSection]]] = []
    run_calls: dict[str, int] = {"count": 0}

    def fake_run_interactive_launcher(sections_factory, **kwargs) -> str:
        run_calls["count"] += 1
        captured_sections.append((kwargs.get("title"), sections_factory()))
        return "back"

    monkeypatch.setattr(
        interactive_module, "run_interactive_launcher", fake_run_interactive_launcher
    )

    callbacks = interactive_module.LauncherCallbacks(
        init_project=lambda name: None,
        configure_project=lambda: None,
        validate_contract=lambda: None,
        show_contract=lambda: None,
        configure_publish=lambda: None,
        publish_project=lambda: None,
        create_fine_tune_job=lambda model_slug, dataset_path: None,
        list_jobs=lambda job_type: [
            interactive_module.LauncherJobItem(
                job_id="queued-job-uuid",
                job_type="build",
                model_slug="my-model",
                status="queued",
                created_at="2026-03-19T00:00:00Z",
            )
        ],
        get_job_detail=lambda job_type, job_id: None,
        cancel_job=lambda job_type, job_id: None,
        delete_job=lambda job_type, job_id: None,
        login=lambda gateway, api_key: None,
        auth=lambda: None,
        logout=lambda: None,
        inspect_model=lambda slug: None,
        pull_model=lambda slug: None,
        list_active_build=lambda slug: None,
        cancel_build=lambda job_id: None,
    )

    config_store = ConfigStore(Path("/tmp/nonexistent-config.json"))
    config_store._config = SimpleNamespace(
        api_key="pk_test", username="alice", default_workspace="acme"
    )

    interactive_module.interactive_launcher(
        console=Console(), config_store=config_store, callbacks=callbacks
    )

    # Trigger jobs browse (home Jobs section, second option)
    home_browse_handler = captured_sections[0][1][1].options[1].handler
    home_browse_handler()

    # Trigger per-job action submenu
    job_list_options = captured_sections[1][1][0].options
    job_list_options[0].handler()

    action_titles = [o.label for o in captured_sections[2][1][0].options]
    assert "View Details" in action_titles
    assert "Cancel Job" in action_titles
    assert "Go Back" in action_titles
    assert "Delete Job" not in action_titles


def test_jobs_browse_job_submenu_shows_delete_for_terminal_job(monkeypatch) -> None:
    """A terminal (failed/succeeded/canceled) job submenu shows View Details + Delete, not Cancel."""
    captured_sections: list[tuple[str | None, list[interactive_module.LauncherSection]]] = []

    def fake_run_interactive_launcher(sections_factory, **kwargs) -> str:
        captured_sections.append((kwargs.get("title"), sections_factory()))
        return "back"

    monkeypatch.setattr(
        interactive_module, "run_interactive_launcher", fake_run_interactive_launcher
    )

    callbacks = interactive_module.LauncherCallbacks(
        init_project=lambda name: None,
        configure_project=lambda: None,
        validate_contract=lambda: None,
        show_contract=lambda: None,
        configure_publish=lambda: None,
        publish_project=lambda: None,
        create_fine_tune_job=lambda model_slug, dataset_path: None,
        list_jobs=lambda job_type: [
            interactive_module.LauncherJobItem(
                job_id="failed-job-uuid",
                job_type="fine-tune",
                model_slug="my-model",
                status="failed",
                created_at="2026-03-19T00:00:00Z",
            )
        ],
        get_job_detail=lambda job_type, job_id: None,
        cancel_job=lambda job_type, job_id: None,
        delete_job=lambda job_type, job_id: None,
        login=lambda gateway, api_key: None,
        auth=lambda: None,
        logout=lambda: None,
        inspect_model=lambda slug: None,
        pull_model=lambda slug: None,
        list_active_build=lambda slug: None,
        cancel_build=lambda job_id: None,
    )

    config_store = ConfigStore(Path("/tmp/nonexistent-config.json"))
    config_store._config = SimpleNamespace(
        api_key="pk_test", username="alice", default_workspace="acme"
    )

    interactive_module.interactive_launcher(
        console=Console(), config_store=config_store, callbacks=callbacks
    )

    home_browse_handler = captured_sections[0][1][1].options[1].handler
    home_browse_handler()

    job_list_options = captured_sections[1][1][0].options
    job_list_options[0].handler()

    action_titles = [o.label for o in captured_sections[2][1][0].options]
    assert "View Details" in action_titles
    assert "Delete Job" in action_titles
    assert "Go Back" in action_titles
    assert "Cancel Job" not in action_titles


def test_jobs_browse_cancel_job_calls_confirm_then_cancel_callback(monkeypatch) -> None:
    """Selecting Cancel Job shows confirm_action, then calls cancel_job callback on confirm."""
    captured_sections: list[tuple[str | None, list[interactive_module.LauncherSection]]] = []
    cancel_calls: list[tuple[str, str]] = []
    confirm_calls: list[str] = []

    def fake_run_interactive_launcher(sections_factory, **kwargs) -> str:
        captured_sections.append((kwargs.get("title"), sections_factory()))
        return "back"

    def fake_confirm_action(message, **kwargs) -> bool:
        confirm_calls.append(message)
        return True  # always confirm

    monkeypatch.setattr(
        interactive_module, "run_interactive_launcher", fake_run_interactive_launcher
    )
    monkeypatch.setattr(interactive_module, "confirm_action", fake_confirm_action)

    callbacks = interactive_module.LauncherCallbacks(
        init_project=lambda name: None,
        configure_project=lambda: None,
        validate_contract=lambda: None,
        show_contract=lambda: None,
        configure_publish=lambda: None,
        publish_project=lambda: None,
        create_fine_tune_job=lambda model_slug, dataset_path: None,
        list_jobs=lambda job_type: [
            interactive_module.LauncherJobItem(
                job_id="running-job-uuid",
                job_type="build",
                model_slug="my-model",
                status="running",
            )
        ],
        get_job_detail=lambda job_type, job_id: None,
        cancel_job=lambda job_type, job_id: cancel_calls.append((job_type, job_id))
        or LauncherActionResult(title="Cancel", content="Canceled", status="success"),
        delete_job=lambda job_type, job_id: None,
        login=lambda gateway, api_key: None,
        auth=lambda: None,
        logout=lambda: None,
        inspect_model=lambda slug: None,
        pull_model=lambda slug: None,
        list_active_build=lambda slug: None,
        cancel_build=lambda job_id: None,
    )

    config_store = ConfigStore(Path("/tmp/nonexistent-config.json"))
    config_store._config = SimpleNamespace(
        api_key="pk_test", username="alice", default_workspace="acme"
    )

    interactive_module.interactive_launcher(
        console=Console(), config_store=config_store, callbacks=callbacks
    )

    home_browse_handler = captured_sections[0][1][1].options[1].handler
    home_browse_handler()

    job_list_options = captured_sections[1][1][0].options
    job_list_options[0].handler()

    cancel_option = next(o for o in captured_sections[2][1][0].options if o.label == "Cancel Job")
    result = cancel_option.handler()

    assert len(confirm_calls) == 1
    assert "running-job-uuid"[:8] in confirm_calls[0]
    assert cancel_calls == [("build", "running-job-uuid")]
    assert isinstance(result, LauncherActionResult)
    assert result.status == "success"
