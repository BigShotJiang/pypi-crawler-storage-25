"""Tests for Docker build-context resolution."""

from __future__ import annotations

from pathlib import Path

from aimp_cli.domain.project import (
    extract_docker_context_sources,
    resolve_docker_build_spec,
)


def test_extract_docker_context_sources_and_resolve_root(tmp_path: Path) -> None:
    project_dir = tmp_path / "qa" / "codex"
    project_dir.mkdir(parents=True)
    (tmp_path / "shared").mkdir()
    (tmp_path / "shared" / "requirements.txt").write_text("requests\n", encoding="utf-8")
    (project_dir / "Dockerfile").write_text(
        "FROM python:3.13-slim\nCOPY shared/requirements.txt /app/requirements.txt\n",
        encoding="utf-8",
    )
    sources = extract_docker_context_sources(
        (project_dir / "Dockerfile").read_text(encoding="utf-8")
    )
    assert sources == ["shared/requirements.txt"]
    context, dockerfile = resolve_docker_build_spec(project_dir)
    assert context == tmp_path
    assert dockerfile == "qa/codex/Dockerfile"
