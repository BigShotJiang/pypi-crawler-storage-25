"""Tests for Studio media upload Gateway timeout resolution."""

from __future__ import annotations

import pytest

from aimp_cli.clients import gateway as gateway_module


def test_studio_media_upload_gateway_timeout_default(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("AIMP_STUDIO_MEDIA_UPLOAD_GATEWAY_TIMEOUT_SECONDS", raising=False)
    assert gateway_module._studio_media_upload_gateway_timeout_seconds() == 60.0


def test_studio_media_upload_gateway_timeout_from_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AIMP_STUDIO_MEDIA_UPLOAD_GATEWAY_TIMEOUT_SECONDS", "120")
    assert gateway_module._studio_media_upload_gateway_timeout_seconds() == 120.0


def test_studio_media_upload_gateway_timeout_invalid_env_falls_back(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("AIMP_STUDIO_MEDIA_UPLOAD_GATEWAY_TIMEOUT_SECONDS", "not-a-float")
    assert gateway_module._studio_media_upload_gateway_timeout_seconds() == 60.0


def test_studio_media_upload_gateway_timeout_sub_one_second_falls_back(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("AIMP_STUDIO_MEDIA_UPLOAD_GATEWAY_TIMEOUT_SECONDS", "0.25")
    assert gateway_module._studio_media_upload_gateway_timeout_seconds() == 60.0


def test_studio_media_upload_gateway_timeout_empty_env_falls_back(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("AIMP_STUDIO_MEDIA_UPLOAD_GATEWAY_TIMEOUT_SECONDS", "")
    assert gateway_module._studio_media_upload_gateway_timeout_seconds() == 60.0
