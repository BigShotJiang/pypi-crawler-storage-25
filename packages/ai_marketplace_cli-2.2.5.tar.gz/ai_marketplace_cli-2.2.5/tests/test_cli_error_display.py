"""Tests for HTTP-status CLI errors and human-readable error emission."""

from __future__ import annotations

from rich.console import Console

from aimp_cli.core.config import emit_error
from aimp_cli.core.errors import CliError, ErrorCategory, ExitCode, cli_error_from_http_status


def test_cli_error_from_http_status_upstream_invalid_sets_default_hint() -> None:
    error = cli_error_from_http_status(
        status_code=502,
        message="Backend service returned a non-JSON error response",
        code="UPSTREAM_INVALID_ERROR_RESPONSE",
        request_id="req-upstream",
        extra={"content_type": "text/html; charset=utf-8"},
    )
    assert error.hint is not None
    assert "non-JSON" in error.hint
    assert "Django" in error.hint or "backend" in error.hint
    assert "request_id" in error.hint


def test_cli_error_from_http_status_upstream_invalid_respects_explicit_hint() -> None:
    error = cli_error_from_http_status(
        status_code=500,
        message="Backend service returned a non-JSON error response",
        code="UPSTREAM_INVALID_ERROR_RESPONSE",
        hint="Custom upstream guidance.",
        request_id="req-1",
    )
    assert error.hint == "Custom upstream guidance."


def test_emit_error_human_includes_http_status_and_extra(monkeypatch: object) -> None:
    import aimp_cli.core.config as config_module

    capture = Console(
        record=True,
        width=100,
        force_terminal=False,
        theme=config_module.ZINC_THEME,
    )
    monkeypatch.setattr(config_module, "console", capture)
    error = CliError(
        "Backend service returned a non-JSON error response",
        code="UPSTREAM_INVALID_ERROR_RESPONSE",
        category=ErrorCategory.NETWORK,
        exit_code=ExitCode.NETWORK,
        request_id="cli-test-req",
        hint="Check logs.",
        http_status=502,
        extra={"content_type": "text/html; charset=utf-8"},
    )
    emit_error(error, json_output=False)
    text = capture.export_text(clear=False)
    assert "Backend service returned a non-JSON error response" in text
    assert "Hint: Check logs." in text
    assert "HTTP status: 502" in text
    assert "content_type: text/html; charset=utf-8" in text
    assert "Request ID: cli-test-req" in text


def test_emit_error_json_unchanged(monkeypatch: object) -> None:
    capture = Console(record=True, width=100, force_terminal=False)
    import aimp_cli.core.config as config_module

    monkeypatch.setattr(config_module, "console", capture)
    error = CliError(
        "x",
        code="UPSTREAM_INVALID_ERROR_RESPONSE",
        category=ErrorCategory.NETWORK,
        exit_code=ExitCode.NETWORK,
        http_status=500,
        extra={"content_type": "application/xml"},
    )
    emit_error(error, json_output=True)
    text = capture.export_text(clear=False)
    assert '"ok": false' in text
    assert "UPSTREAM_INVALID_ERROR_RESPONSE" in text
    assert "application/xml" in text
