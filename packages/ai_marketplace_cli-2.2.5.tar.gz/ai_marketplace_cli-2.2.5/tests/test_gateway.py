"""Tests for Gateway client behavior."""

from __future__ import annotations

import json

import httpx
import pytest

from aimp_cli.core.config import build_command_context
from aimp_cli.core.errors import CliError
from aimp_cli.clients.gateway import GatewayClient
from aimp_cli.domain.models import (
    AuthContext,
    ModeReadinessPayload,
    PublishBuildGroupCreateRequest,
    PublishBuildProfile,
)


def _build_publish_request_payload() -> dict[str, object]:
    """Return a publish payload that matches the current CLI contract."""
    return {
        "slug": "demo",
        "version": "0.1.0",
        "publish_build_group_id": "build-1",
        "resources": {"vector_db": True},
        "modes": {
            "generate": {
                "inputs": [{"name": "text", "kind": "text", "required": True}],
                "outputs": [{"name": "result", "kind": "text", "required": True}],
            },
            "search": {
                "inputs": [{"name": "text", "kind": "text", "required": True}],
                "outputs": [{"name": "results", "kind": "json", "required": True}],
            },
            "index": {
                "inputs": [{"name": "text", "kind": "text", "required": True}],
                "outputs": [{"name": "indexed", "kind": "json", "required": True}],
            },
        },
        "mode_readiness": ModeReadinessPayload.model_validate(
            {
                "generate": {
                    "declared": True,
                    "implemented": True,
                    "reason": None,
                },
                "search": {
                    "declared": True,
                    "implemented": True,
                    "reason": None,
                },
                "index": {
                    "declared": True,
                    "implemented": True,
                    "reason": None,
                },
            }
        ).model_dump(),
        "pricing": {"developer_margin": 0},
        "profiles": [
            {
                "runtime_profile": "cpu",
                "supported_hardware_tiers": ["cpu-basic"],
            }
        ],
        "studio": {
            "name": "Demo",
            "tags": ["example"],
            "visibility": "private",
            "article": {
                "format": "tiptap-json",
                "schema_version": 1,
                "content": {"type": "doc"},
            },
        },
    }


def _build_registration_intent_payload() -> dict[str, object]:
    """Return one canonical registration intent payload."""
    payload = _build_publish_request_payload()
    mode_readiness = {
        name: {key: value for key, value in entry.items() if value is not None}
        for name, entry in dict(payload["mode_readiness"]).items()
    }
    return {
        "resources": payload["resources"],
        "modes": payload["modes"],
        "mode_readiness": mode_readiness,
        "required_secrets": [],
        "parameters": {},
        "pricing": payload["pricing"],
        "profiles": payload["profiles"],
        "studio": payload["studio"],
    }


def _build_execution_publish_job_payload(**overrides: object) -> dict[str, object]:
    """Return a V2 execution payload for a publish-build job."""
    payload: dict[str, object] = {
        "id": "build-1",
        "type": "publish-build",
        "model_slug": "vision-pro",
        "operation": "publish-build",
        "status": "running",
        "timeline": [],
        "error_code": None,
        "error_message": None,
        "created_at": "2026-03-19T00:00:00+00:00",
        "started_at": None,
        "finished_at": None,
        "details": {
            "version": "1.0.0",
        },
    }
    payload.update(overrides)
    return payload


def _build_execution_fine_tune_payload(**overrides: object) -> dict[str, object]:
    """Return a V2 execution payload for a fine-tune job."""
    payload: dict[str, object] = {
        "id": "ft-1",
        "type": "fine-tune",
        "model_slug": "vision-pro",
        "operation": "fine-tune",
        "status": "running",
        "timeline": [],
        "error_code": None,
        "error_message": None,
        "created_at": "2026-03-19T00:00:00+00:00",
        "started_at": None,
        "finished_at": None,
        "details": {
            "dataset_ref": "s3://bucket/data.jsonl",
            "adapter_format": "lora",
            "output_asset_id": "asset-1",
        },
    }
    payload.update(overrides)
    return payload


def test_publish_surfaces_gateway_detail() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            409,
            json={
                "detail": {
                    "code": "slug_conflict",
                    "message": "slug conflict",
                    "retryable": False,
                }
            },
            request=request,
        )

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        try:
            client.publish(_build_publish_request_payload())
        except CliError as error:
            assert error.code == "slug_conflict"
            assert error.http_status == 409
            assert error.message == "slug conflict"
        else:
            raise AssertionError("Expected CliError")
    finally:
        client.close()


def test_publish_parses_gateway_publish_response() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "id": "8ac15d57-4705-4a1f-86c1-ff81eb477c60",
                "slug": "demo",
                "visibility": "private",
                "readiness": {
                    "is_ready": False,
                    "blocking_reasons": ["publish_pricing_not_configured"],
                },
                "url": "http://localhost:3000/studio/models/demo",
            },
            request=request,
        )

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        response = client.publish(_build_publish_request_payload())
    finally:
        client.close()

    assert response.id == "8ac15d57-4705-4a1f-86c1-ff81eb477c60"
    assert response.visibility == "private"
    assert response.readiness is not None
    assert response.readiness.is_ready is False
    assert response.url == "http://localhost:3000/studio/models/demo"


def test_publish_serializes_canonical_mode_inputs_in_request_body() -> None:
    captured_body: dict[str, object] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal captured_body
        captured_body = json.loads(request.content.decode("utf-8"))
        return httpx.Response(
            200,
            json={
                "id": "8ac15d57-4705-4a1f-86c1-ff81eb477c60",
                "slug": "demo",
                "visibility": "private",
                "readiness": {
                    "is_ready": True,
                    "blocking_reasons": [],
                },
                "url": "http://localhost:3000/studio/models/demo",
            },
            request=request,
        )

    payload = _build_publish_request_payload()
    payload["modes"] = {
        "generate": {
            "inputs": [
                {
                    "name": "text",
                    "kind": "text",
                    "required": True,
                }
            ],
            "outputs": [{"name": "result", "kind": "text", "required": True}],
            "description": "",
        }
    }
    payload["mode_readiness"] = {
        "generate": {
            "declared": True,
            "implemented": True,
        },
    }

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        client.publish(payload)
    finally:
        client.close()

    assert captured_body["modes"] == {
        "generate": {
            "inputs": [
                {
                    "name": "text",
                    "kind": "text",
                    "required": True,
                    "description": "",
                    "multiple": False,
                }
            ],
            "outputs": [
                {
                    "name": "result",
                    "kind": "text",
                    "required": True,
                    "description": "",
                    "multiple": False,
                }
            ],
            "description": "",
        }
    }
    assert captured_body["mode_readiness"] == {
        "generate": {
            "declared": True,
            "implemented": True,
        }
    }


def test_publish_preserves_multi_input_metadata_in_request_body() -> None:
    captured_body: dict[str, object] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal captured_body
        captured_body = json.loads(request.content.decode("utf-8"))
        return httpx.Response(
            200,
            json={
                "id": "8ac15d57-4705-4a1f-86c1-ff81eb477c60",
                "slug": "demo",
                "visibility": "private",
                "readiness": {
                    "is_ready": True,
                    "blocking_reasons": [],
                },
                "url": "http://localhost:3000/studio/models/demo",
            },
            request=request,
        )

    payload = _build_publish_request_payload()
    payload["modes"] = {
        "generate": {
            "inputs": [
                {
                    "name": "query",
                    "kind": "text",
                    "required": True,
                    "description": "Search query",
                    "label": "Query",
                },
                {
                    "name": "gallery",
                    "kind": "image",
                    "required": False,
                    "multiple": True,
                },
            ],
            "outputs": [
                {
                    "name": "report",
                    "kind": "json",
                    "required": True,
                }
            ],
            "description": "Rank images",
        }
    }
    payload["mode_readiness"] = {
        "generate": {
            "declared": True,
            "implemented": True,
        },
    }

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        client.publish(payload)
    finally:
        client.close()

    assert captured_body["modes"] == {
        "generate": {
            "inputs": [
                {
                    "name": "query",
                    "kind": "text",
                    "required": True,
                    "description": "Search query",
                    "multiple": False,
                    "label": "Query",
                },
                {
                    "name": "gallery",
                    "kind": "image",
                    "required": False,
                    "description": "",
                    "multiple": True,
                },
            ],
            "outputs": [
                {
                    "name": "report",
                    "kind": "json",
                    "required": True,
                    "description": "",
                    "multiple": False,
                }
            ],
            "description": "Rank images",
        }
    }


def test_publish_model_by_slug_parses_gateway_publish_response() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/v1/cli/models/vision-pro-tuned/publish/"
        return httpx.Response(
            200,
            json={
                "id": "derived-1",
                "slug": "vision-pro-tuned",
                "visibility": "public",
                "readiness": {
                    "is_ready": True,
                    "blocking_reasons": [],
                },
                "url": "http://localhost:3000/studio/models/vision-pro-tuned",
            },
            request=request,
        )

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        response = client.publish_model_by_slug("vision-pro-tuned")
    finally:
        client.close()

    assert response.id == "derived-1"
    assert response.slug == "vision-pro-tuned"
    assert response.visibility == "public"
    assert response.url == "http://localhost:3000/studio/models/vision-pro-tuned"


def test_get_publish_metadata_parses_gateway_response() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "hardware_tiers": [
                    {
                        "id": "cpu-basic",
                        "label": "CPU Basic",
                        "description": (
                            "General-purpose CPU runtime for standard inference workloads."
                        ),
                        "base_cost_hourly": 0.05,
                    }
                ],
                "platform_fee_pct": 0.3,
            },
            request=request,
        )

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        response = client.get_publish_metadata()
    finally:
        client.close()

    assert response.platform_fee_pct == 0.3
    assert response.hardware_tiers[0].id == "cpu-basic"


def test_get_publish_metadata_surfaces_outdated_gateway_route() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(404, json={"detail": "Not Found"}, request=request)

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        try:
            client.get_publish_metadata()
        except CliError as error:
            assert error.code == "gateway_publish_metadata_unsupported"
            assert "up -d gateway" in str(error.hint)
            assert error.extra == {"route": "/v1/cli/publish/metadata"}
        else:
            raise AssertionError("Expected CliError")
    finally:
        client.close()


def test_get_model_parses_gateway_model_lookup_response() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "id": "asset-123",
                "slug": "demo-model",
                "name": "Demo Model",
                "version": "0.1.0",
                "visibility": "private",
                "release_state": "live",
                "asset_type": "model",
                "runtime_state": None,
            },
            request=request,
        )

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        response = client.get_model("demo-model")
    finally:
        client.close()

    assert response is not None
    assert response.slug == "demo-model"
    assert response.visibility == "private"
    assert response.release_state == "live"
    assert response.asset_type == "model"
    assert response.runtime_state is None


def test_get_model_parses_gateway_model_lookup_response_without_runtime_state() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "id": "asset-123",
                "slug": "demo-model",
                "name": "Demo Model",
                "version": "0.1.0",
                "visibility": "private",
                "release_state": "live",
                "asset_type": "model",
            },
            request=request,
        )

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        response = client.get_model("demo-model")
    finally:
        client.close()

    assert response is not None
    assert response.slug == "demo-model"
    assert response.release_state == "live"
    assert response.runtime_state is None


def test_get_model_version_parses_gateway_exact_release_lookup_response() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/v1/cli/models/demo-model/versions/0.2.0"
        return httpx.Response(
            200,
            json={
                "id": "asset-456",
                "slug": "demo-model",
                "name": "Demo Model",
                "version": "0.2.0",
                "visibility": "private",
                "release_state": "ready",
                "asset_type": "model",
                "runtime_state": {
                    "state": "warm_idle",
                    "ready_workers": 1,
                    "busy_workers": 0,
                    "warming_workers": 0,
                    "last_state_changed_at": "2026-04-05T18:00:00+00:00",
                    "last_warm_hit_at": None,
                    "last_cold_start_at": None,
                },
            },
            request=request,
        )

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        response = client.get_model_version("demo-model", "0.2.0")
    finally:
        client.close()

    assert response is not None
    assert response.version == "0.2.0"
    assert response.release_state == "ready"
    assert response.runtime_state is not None
    assert response.runtime_state.state == "warm_idle"
    assert response.runtime_state.ready_workers == 1


def test_create_publish_build_group_posts_jobs_command() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.method == "POST"
        assert request.url.path == "/api/jobs/publish-build/"
        payload = json.loads(request.read().decode())
        assert payload["model"] == "vision-pro"
        assert payload["mode"] == "publish-build"
        input_payload = payload["input"]
        assert input_payload["version"] == "1.0.0"
        assert input_payload["source_artifact_uri"] == "s3://uploads/vision-pro.tar.gz"
        assert input_payload["dockerfile_path"] == "Dockerfile"
        assert input_payload["build_context_path"] == "."
        assert input_payload["profiles"] == [
            {
                "runtime_profile": "cpu",
                "supported_hardware_tiers": ["cpu-basic"],
            }
        ]
        assert input_payload["python_package_index"] == {
            "extra_index_url": "https://test.pypi.org/simple/",
            "username": "ci-user",
            "password": "ci-pass",
        }
        assert isinstance(input_payload.get("registration_intent"), dict)
        assert input_payload["registration_intent"]["pricing"] == {"developer_margin": 0}
        assert input_payload["registration_intent"]["studio"]["name"] == "Demo"
        return httpx.Response(
            200,
            json={
                "decision": "created",
                "job": {
                    "job_id": "build-1",
                    "job_type": "build",
                    "slug": "vision-pro",
                    "version": "1.0.0",
                    "status": "queued",
                    "timeline": [],
                    "error_code": None,
                    "error_message": None,
                    "logs": [],
                    "created_at": "2026-03-19T00:00:00+00:00",
                    "started_at": None,
                    "finished_at": None,
                }
            },
            request=request,
        )

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        job = client.create_publish_build_group(
            PublishBuildGroupCreateRequest(
                slug="vision-pro",
                version="1.0.0",
                source_artifact_uri="s3://uploads/vision-pro.tar.gz",
                dockerfile_path="Dockerfile",
                build_context_path=".",
                profiles=[
                    PublishBuildProfile(
                        runtime_profile="cpu",
                        supported_hardware_tiers=["cpu-basic"],
                    )
                ],
                registration_intent=_build_registration_intent_payload(),
                python_package_index={
                    "extra_index_url": "https://test.pypi.org/simple/",
                    "username": "ci-user",
                    "password": "ci-pass",
                },
            )
        )
    finally:
        client.close()

    assert job.job_id == "build-1"
    assert job.job_type == "build"
    assert job.slug == "vision-pro"
    assert job.version == "1.0.0"
    assert job.status == "queued"


def test_create_publish_build_group_normalizes_canonical_payload_with_backend_extras() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.method == "POST"
        assert request.url.path == "/api/jobs/publish-build/"
        return httpx.Response(
            200,
            json={
                "decision": "created",
                "job": _build_execution_publish_job_payload(
                    status="queued",
                    cancel_requested_at="2026-03-19T00:00:20+00:00",
                    details={
                        "version": "1.0.0",
                        "active_runtime_profile": "cpu",
                        "requested_profiles": [
                            {
                                "runtime_profile": "cpu",
                                "supported_hardware_tiers": ["cpu-basic"],
                                "target_image_ref": "registry/ws/vision-pro:1.0.0-cpu",
                            }
                        ],
                        "successful_runtime_profiles": ["cpu"],
                        "child_jobs": [
                            {
                                "id": "child-1",
                                "type": "publish-build",
                                "operation": "publish-build",
                                "model_slug": "vision-pro",
                                "runtime_profile": "cpu",
                                "status": "running",
                                "timeline": [],
                                "logs": [],
                                "cache_ref": "cache:v1",
                                "cache_imported": True,
                                "cache_exported": False,
                                "cancel_requested_at": "2026-03-19T00:00:21+00:00",
                                "details": {
                                    "version": "1.0.0",
                                    "runtime_profile": "cpu",
                                    "result_image_ref": "registry/ws/vision-pro:1.0.0-cpu",
                                },
                            }
                        ],
                    },
                )
            },
            request=request,
        )

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        job = client.create_publish_build_group(
            PublishBuildGroupCreateRequest(
                slug="vision-pro",
                version="1.0.0",
                source_artifact_uri="s3://uploads/vision-pro.tar.gz",
                dockerfile_path="Dockerfile",
                build_context_path=".",
                profiles=[
                    PublishBuildProfile(
                        runtime_profile="cpu",
                        supported_hardware_tiers=["cpu-basic"],
                    )
                ],
                registration_intent=_build_registration_intent_payload(),
            )
        )
    finally:
        client.close()

    assert job.job_id == "build-1"
    assert job.slug == "vision-pro"
    assert job.version == "1.0.0"
    assert job.active_runtime_profile == "cpu"
    assert job.requested_profiles[0].runtime_profile == "cpu"
    assert job.successful_runtime_profiles == ["cpu"]
    assert len(job.child_jobs) == 1
    child_job = job.child_jobs[0]
    assert child_job.job_id == "child-1"
    assert child_job.slug == "vision-pro"
    assert child_job.version == "1.0.0"
    assert child_job.runtime_profile == "cpu"
    assert child_job.cache_ref == "cache:v1"
    assert child_job.cache_imported is True
    assert child_job.cache_exported is False
    assert "cancel_requested_at" not in child_job.model_dump()


def test_create_publish_build_group_forwards_force_intent() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.method == "POST"
        assert request.url.path == "/api/jobs/publish-build/"
        payload = json.loads(request.read().decode())
        assert payload["input"]["force"] is True
        return httpx.Response(
            201,
            json={
                "decision": "replaced",
                "job": _build_execution_publish_job_payload(status="running"),
            },
            request=request,
        )

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        job = client.create_publish_build_group(
            PublishBuildGroupCreateRequest(
                slug="vision-pro",
                version="1.0.0",
                source_artifact_uri="s3://uploads/vision-pro.tar.gz",
                dockerfile_path="Dockerfile",
                build_context_path=".",
                profiles=[
                    PublishBuildProfile(
                        runtime_profile="cpu",
                        supported_hardware_tiers=["cpu-basic"],
                    )
                ],
                registration_intent=_build_registration_intent_payload(),
                force=True,
            )
        )
    finally:
        client.close()

    assert job.job_id == "build-1"
    assert job.status == "running"


def test_publish_build_create_get_list_share_one_canonical_normalization_contract() -> None:
    execution_payload = _build_execution_publish_job_payload(
        stage="build",
        phase="dispatch",
        details={
            "version": "1.0.0",
            "requested_profiles": [
                {
                    "runtime_profile": "cpu",
                    "supported_hardware_tiers": ["cpu-basic"],
                    "target_image_ref": "registry/ws/vision-pro:1.0.0-cpu",
                }
            ],
            "active_runtime_profile": "cpu",
            "successful_runtime_profiles": ["cpu"],
        },
        child_jobs=[
            {
                "id": "child-1",
                "type": "publish-build",
                "operation": "publish-build",
                "model_slug": "vision-pro",
                "status": "queued",
                "runtime_profile": "cpu",
                "timeline": [],
                "logs": [],
                "cache_ref": "cache:v1",
                "cache_imported": True,
                "cache_exported": False,
                "details": {
                    "version": "1.0.0",
                    "runtime_profile": "cpu",
                },
            }
        ],
    )

    def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "POST" and request.url.path == "/api/jobs/publish-build/":
            return httpx.Response(
                200,
                json={"decision": "created", "job": execution_payload},
                request=request,
            )
        if request.method == "GET" and request.url.path == "/api/jobs/build-1/":
            return httpx.Response(200, json=execution_payload, request=request)
        if request.method == "GET" and request.url.path == "/api/jobs/":
            return httpx.Response(
                200,
                json={
                    "results": [execution_payload],
                    "pagination": {
                        "page": 1,
                        "page_size": 20,
                        "total_items": 1,
                        "total_pages": 1,
                        "has_next": False,
                        "has_previous": False,
                    },
                },
                request=request,
            )
        raise AssertionError(f"Unexpected request: {request.method} {request.url.path}")

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        create_job = client.create_publish_build_group(
            PublishBuildGroupCreateRequest(
                slug="vision-pro",
                version="1.0.0",
                source_artifact_uri="s3://uploads/vision-pro.tar.gz",
                dockerfile_path="Dockerfile",
                build_context_path=".",
                profiles=[
                    PublishBuildProfile(
                        runtime_profile="cpu",
                        supported_hardware_tiers=["cpu-basic"],
                    )
                ],
                registration_intent=_build_registration_intent_payload(),
            )
        )
        get_job = client.get_publish_build_group("build-1")
        list_job = client.list_publish_build_groups(model_slug="vision-pro").results[0]
    finally:
        client.close()

    assert create_job.model_dump() == get_job.model_dump()
    assert create_job.model_dump() == list_job.model_dump()


def test_list_publish_build_groups_parses_gateway_response() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/jobs/"
        assert request.url.params["type"] == "build"
        assert request.url.params["model_slug"] == "vision-pro"
        assert request.url.params["status"] == "running"
        return httpx.Response(
            200,
            json={
                "results": [
                    {
                        "job_id": "build-1",
                        "job_type": "build",
                        "model_slug": "vision-pro",
                        "version": "1.0.0",
                        "status": "running",
                        "created_at": "2026-03-19T00:00:00+00:00",
                        "started_at": None,
                        "finished_at": None,
                    }
                ],
                "pagination": {
                    "page": 1,
                    "page_size": 20,
                    "total_items": 1,
                    "total_pages": 1,
                    "has_next": False,
                    "has_previous": False,
                },
            },
            request=request,
        )

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        response = client.list_publish_build_groups(model_slug="vision-pro", status="running")
    finally:
        client.close()

    assert response.results[0].job_id == "build-1"
    assert response.results[0].slug == "vision-pro"
    assert response.results[0].version == "1.0.0"
    assert response.pagination["total_items"] == 1


def test_get_publish_build_group_normalizes_job_response() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/jobs/build-1/"
        return httpx.Response(
            200,
            json=_build_execution_publish_job_payload(
                details={
                    "version": "1.0.0",
                    "requested_profiles": [
                        {
                            "runtime_profile": "cpu",
                            "supported_hardware_tiers": ["cpu-basic"],
                            "target_image_ref": "127.0.0.1:5050/ws/demo-model:1.0.0-cpu",
                        }
                    ],
                    "child_jobs": [
                        {
                            "job_id": "child-1",
                            "slug": "vision-pro",
                            "version": "1.0.0",
                            "runtime_profile": "cpu",
                            "status": "queued",
                            "timeline": [],
                            "logs": [],
                            "lease_expires_at": None,
                        }
                    ],
                }
            ),
            request=request,
        )

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        job = client.get_publish_build_group("build-1")
    finally:
        client.close()

    assert job.job_id == "build-1"
    assert job.slug == "vision-pro"
    assert job.version == "1.0.0"
    assert job.requested_profiles[0].runtime_profile == "cpu"
    assert job.requested_profiles[0].target_image_ref == "127.0.0.1:5050/ws/demo-model:1.0.0-cpu"
    assert job.child_jobs[0].lease_expires_at is None


def test_cancel_publish_build_group_normalizes_job_response() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/jobs/build-1/cancel/"
        return httpx.Response(
            200,
            json={
                "job_type": "build",
                "cancel_state": "canceled",
                "job": {
                    "job_id": "build-1",
                    "status": "canceled",
                    "job_type": "build",
                    "model_slug": "vision-pro",
                },
            },
            request=request,
        )

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        payload = client.cancel_publish_build_group("build-1")
    finally:
        client.close()

    assert payload.job_type == "build"
    assert payload.cancel_state == "canceled"
    assert payload.job["job_id"] == "build-1"
    assert payload.job["status"] == "canceled"


def test_cancel_publish_build_group_accepts_canceling_response() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/jobs/build-1/cancel/"
        return httpx.Response(
            200,
            json={
                "job": {
                    "job_id": "build-1",
                    "status": "canceling",
                },
                "job_type": "build",
                "cancel_state": "canceling",
            },
            request=request,
        )

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        payload = client.cancel_publish_build_group("build-1")
    finally:
        client.close()

    assert payload.job_type == "build"
    assert payload.cancel_state == "canceling"
    assert payload.job["job_id"] == "build-1"
    assert payload.job["status"] == "canceling"


def test_list_fine_tune_jobs_normalizes_job_response() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/jobs/"
        assert request.url.params["type"] == "fine-tune"
        assert request.url.params["model_slug"] == "vision-pro"
        assert request.url.params["status"] == "running"
        return httpx.Response(
            200,
            json={
                "results": [_build_execution_fine_tune_payload()],
                "pagination": {
                    "page": 1,
                    "page_size": 20,
                    "total_items": 1,
                    "total_pages": 1,
                    "has_next": False,
                    "has_previous": False,
                },
            },
            request=request,
        )

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        response = client.list_fine_tune_jobs(model_slug="vision-pro", status="running")
    finally:
        client.close()

    assert response.results[0].job_id == "ft-1"
    assert response.results[0].model_slug == "vision-pro"
    assert response.results[0].adapter_format == "lora"
    assert response.results[0].output_asset_id == "asset-1"


def test_get_fine_tune_job_normalizes_job_response() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/jobs/ft-1/"
        return httpx.Response(200, json=_build_execution_fine_tune_payload(), request=request)

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        job = client.get_fine_tune_job(job_id="ft-1")
    finally:
        client.close()

    assert job.job_id == "ft-1"
    assert job.model_slug == "vision-pro"
    assert job.adapter_format == "lora"
    assert job.output_asset_id == "asset-1"


def test_cancel_fine_tune_job_normalizes_job_response() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/jobs/ft-1/cancel/"
        return httpx.Response(
            200,
            json={
                "job_type": "fine-tune",
                "cancel_state": "canceled",
                "job": {
                    "job_id": "ft-1",
                    "status": "canceled",
                    "job_type": "fine-tune",
                    "model_slug": "vision-pro",
                },
            },
            request=request,
        )

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        payload = client.cancel_fine_tune_job(job_id="ft-1")
    finally:
        client.close()

    assert payload.job_type == "fine-tune"
    assert payload.cancel_state == "canceled"
    assert payload.job["job_id"] == "ft-1"
    assert payload.job["status"] == "canceled"


def test_list_publish_build_groups_surfaces_gateway_error_payload() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            500,
            json={
                "error": {
                    "code": "UPSTREAM_INVALID_ERROR_RESPONSE",
                    "message": "Backend service returned a non-JSON error response",
                    "details": {"content_type": "text/html; charset=utf-8"},
                }
            },
            request=request,
        )

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        try:
            client.list_publish_build_groups()
        except CliError as error:
            assert error.code == "UPSTREAM_INVALID_ERROR_RESPONSE"
            assert error.http_status == 500
            assert error.message == "Backend service returned a non-JSON error response"
            assert error.extra == {"content_type": "text/html; charset=utf-8"}
        else:
            raise AssertionError("Expected CliError")
    finally:
        client.close()


def test_list_publish_build_groups_hides_raw_html_gateway_errors() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            500,
            text=(
                "<!DOCTYPE html><html><head><title>ProgrammingError</title></head>"
                "<body>broken</body></html>"
            ),
            headers={"content-type": "text/html; charset=utf-8"},
            request=request,
        )

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        try:
            client.list_publish_build_groups()
        except CliError as error:
            assert error.code == "invalid_gateway_error_response"
            assert error.http_status == 500
            assert error.message == "Gateway returned a non-JSON error response"
            assert "<!DOCTYPE html>" not in error.message
            assert error.extra == {"content_type": "text/html; charset=utf-8"}
        else:
            raise AssertionError("Expected CliError")
    finally:
        client.close()


def test_get_current_user_returns_none_for_invalid_api_key() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            401,
            json={
                "detail": {
                    "code": "invalid_api_key",
                    "message": "Invalid API key",
                    "retryable": False,
                }
            },
            request=request,
        )

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_invalid"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        assert client.get_current_user() is None
    finally:
        client.close()


def test_get_current_user_raises_for_connectivity_failure() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("down", request=request)

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        try:
            client.get_current_user()
        except CliError as error:
            assert error.code == "gateway_unreachable"
            assert error.exit_code == 5
        else:
            raise AssertionError("Expected CliError")
    finally:
        client.close()


def test_upload_studio_media_init_http_failure_uses_canonical_publish_code(
    tmp_path,
) -> None:
    file_path = tmp_path / "cover.png"
    file_path.write_bytes(b"png")

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/studio/media/upload/init"
        return httpx.Response(
            400,
            json={
                "detail": {
                    "code": "studio_media_upload_failed",
                    "message": "upload rejected",
                    "retryable": False,
                    "details": {"field": "content_type"},
                }
            },
            request=request,
        )

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        with pytest.raises(CliError) as exc_info:
            client.upload_studio_media(file_path=file_path, media_type="image")
    finally:
        client.close()

    assert exc_info.value.code == "publish_registration_failed"
    assert exc_info.value.message == "upload rejected"
    assert exc_info.value.extra["reason"] == "studio_media_upload"
    assert exc_info.value.extra["stage"] == "registration"
    assert exc_info.value.extra["upload_phase"] == "init"
    assert exc_info.value.extra["upstream_code"] == "studio_media_upload_failed"
    assert exc_info.value.extra["field"] == "content_type"


def test_upload_studio_media_single_part_failure_uses_canonical_publish_code(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path,
) -> None:
    file_path = tmp_path / "cover.png"
    file_path.write_bytes(b"png")

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/studio/media/upload/init"
        return httpx.Response(
            200,
            json={
                "upload_id": "upload-1",
                "upload_strategy": "single",
                "upload_url": "https://storage.example/upload",
                "required_headers": {},
            },
            request=request,
        )

    def _failing_put(
        url: str,
        *,
        content=None,
        headers=None,
        timeout: float | None = None,
    ) -> httpx.Response:
        _ = content, headers, timeout
        return httpx.Response(503, request=httpx.Request("PUT", url))

    monkeypatch.setattr("aimp_cli.clients.gateway.httpx.put", _failing_put)

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        with pytest.raises(CliError) as exc_info:
            client.upload_studio_media(file_path=file_path, media_type="image")
    finally:
        client.close()

    assert exc_info.value.code == "publish_registration_failed"
    assert exc_info.value.extra["reason"] == "studio_media_upload"
    assert exc_info.value.extra["stage"] == "registration"
    assert exc_info.value.extra["upload_phase"] == "single_part_upload"
    assert exc_info.value.extra["upstream_code"] == "studio_media_upload_failed"
    assert exc_info.value.extra["current_step_message"] == "Final publish registration failed"


def test_extract_gateway_detail_reads_streaming_error_body() -> None:
    """Streaming httpx responses must buffer before json/text (e.g. execution SSE errors)."""
    body = json.dumps(
        {
            "detail": {
                "code": "execution_not_found",
                "message": "Execution not found",
                "retryable": False,
            }
        }
    ).encode()
    request = httpx.Request("GET", "http://localhost:8080/api/jobs/job-id/stream/")
    response = httpx.Response(
        404,
        stream=httpx.ByteStream(body),
        headers={"content-type": "application/json"},
        request=request,
    )

    def handler(req: httpx.Request) -> httpx.Response:
        return httpx.Response(500, request=req)

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        detail = client._extract_gateway_detail(response)
    finally:
        client.close()

    assert detail["code"] == "execution_not_found"
    assert detail["message"] == "Execution not found"


def test_extract_gateway_detail_merges_gateway_request_id_from_error_envelope() -> None:
    """Gateway JSON errors may carry error.request_id for log correlation."""
    response = httpx.Response(
        404,
        json={
            "error": {
                "code": "UPSTREAM_INVALID_ERROR_RESPONSE",
                "message": "Backend service returned a non-JSON error response",
                "request_id": "gw-trace-9f2a",
                "details": {
                    "content_type": "text/html; charset=utf-8",
                    "method": "POST",
                    "upstream_path": "/api/v1/missing/",
                },
            }
        },
        request=httpx.Request("GET", "http://localhost:8080/api/jobs/"),
    )
    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(lambda req: httpx.Response(500, request=req)),
    )
    try:
        detail = client._extract_gateway_detail(response)
    finally:
        client.close()

    assert detail["extra"]["gateway_request_id"] == "gw-trace-9f2a"
    assert detail["extra"]["upstream_path"] == "/api/v1/missing/"


def test_stream_job_surfaces_gateway_detail_before_stream_close() -> None:
    """HTTP errors on SSE open must parse JSON while httpx stream context is still open."""
    job_id = "8ac15d57-4705-4a1f-86c1-ff81eb477c60"
    stream_path = f"/api/jobs/{job_id}/stream/"

    def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "GET" and request.url.path == stream_path:
            return httpx.Response(
                403,
                json={
                    "detail": {
                        "code": "forbidden_job",
                        "message": "Not allowed to stream this job",
                        "retryable": False,
                    }
                },
                request=request,
            )
        return httpx.Response(500, request=request)

    client = GatewayClient(
        AuthContext(gateway_url="http://localhost:8080", api_key="pk_local"),
        build_command_context("test", debug=False, json_output=False),
        transport=httpx.MockTransport(handler),
    )
    try:
        with pytest.raises(CliError) as exc_info:
            with client.stream_job(job_id) as lines:
                next(iter(lines), "")
        error = exc_info.value
        assert error.code == "forbidden_job"
        assert error.http_status == 403
        assert "Not allowed" in error.message
        assert "closed" not in error.message.lower()
    finally:
        client.close()
