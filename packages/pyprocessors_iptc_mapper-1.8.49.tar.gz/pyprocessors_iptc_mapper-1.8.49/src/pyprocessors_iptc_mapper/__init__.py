"""Sherpa IPTC category mapper"""

__version__ = "1.8.49"
