from __future__ import annotations

import httpx

DEFAULT_BASE_URL = "https://positive-wisdom-production-acc3.up.railway.app"


class AgentCRM:
    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
    ):
        self._client = httpx.Client(
            base_url=base_url,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=30.0,
        )
        self.contacts = ContactsResource(self._client)
        self.lists = ListsResource(self._client)
        self.sends = SendsResource(self._client)

    def close(self):
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()


class ContactsResource:
    def __init__(self, client: httpx.Client):
        self._client = client

    def create(
        self, email: str, metadata: dict | None = None
    ) -> dict:
        resp = self._client.post(
            "/contacts",
            json={"email": email, "metadata": metadata},
        )
        resp.raise_for_status()
        return resp.json()

    def list(self, cursor: int | None = None, limit: int = 50) -> dict:
        params = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        resp = self._client.get("/contacts", params=params)
        resp.raise_for_status()
        return resp.json()

    def get(self, contact_id: int) -> dict:
        resp = self._client.get(f"/contacts/{contact_id}")
        resp.raise_for_status()
        return resp.json()

    def update(
        self,
        contact_id: int,
        email: str | None = None,
        metadata: dict | None = None,
    ) -> dict:
        body = {}
        if email is not None:
            body["email"] = email
        if metadata is not None:
            body["metadata"] = metadata
        resp = self._client.put(f"/contacts/{contact_id}", json=body)
        resp.raise_for_status()
        return resp.json()

    def delete(self, contact_id: int) -> None:
        resp = self._client.delete(f"/contacts/{contact_id}")
        resp.raise_for_status()


class ListsResource:
    def __init__(self, client: httpx.Client):
        self._client = client

    def create(self, name: str) -> dict:
        resp = self._client.post("/lists", json={"name": name})
        resp.raise_for_status()
        return resp.json()

    def list(self) -> dict:
        resp = self._client.get("/lists")
        resp.raise_for_status()
        return resp.json()

    def get(self, list_id: int) -> dict:
        resp = self._client.get(f"/lists/{list_id}")
        resp.raise_for_status()
        return resp.json()

    def delete(self, list_id: int) -> None:
        resp = self._client.delete(f"/lists/{list_id}")
        resp.raise_for_status()

    def add_contacts(self, list_id: int, contact_ids: list[int]) -> None:
        resp = self._client.post(
            f"/lists/{list_id}/contacts",
            json={"contact_ids": contact_ids},
        )
        resp.raise_for_status()

    def remove_contact(self, list_id: int, contact_id: int) -> None:
        resp = self._client.delete(
            f"/lists/{list_id}/contacts/{contact_id}"
        )
        resp.raise_for_status()

    def members(self, list_id: int) -> dict:
        resp = self._client.get(f"/lists/{list_id}/contacts")
        resp.raise_for_status()
        return resp.json()

    def send(
        self,
        list_id: int,
        subject: str,
        sender_name: str,
        body_text: str | None = None,
        body_html: str | None = None,
    ) -> dict:
        resp = self._client.post(
            f"/lists/{list_id}/send",
            json={
                "subject": subject,
                "sender_name": sender_name,
                "body_text": body_text,
                "body_html": body_html,
            },
        )
        resp.raise_for_status()
        return resp.json()


class SendsResource:
    def __init__(self, client: httpx.Client):
        self._client = client

    def get(self, send_id: int) -> dict:
        resp = self._client.get(f"/sends/{send_id}")
        resp.raise_for_status()
        return resp.json()
