# sw2023

**Nonparametric Multiple-Output Stochastic Frontier Analysis**

Python implementation of Simar & Wilson (2023):

> Simar, L., Wilson, P.W. (2023). *Nonparametric, Stochastic Frontier Models with Multiple Inputs and Outputs.* Journal of Business & Economic Statistics, 41(4), 1391–1403.

Extended with a 4-component panel decomposition (transient + persistent inefficiency).

---

## Features

| Feature | Status |
|---------|--------|
| Multiple inputs & outputs (distance function) | ✅ |
| Local Linear Least Squares (LLLS) frontier | ✅ |
| SVKZ / HMS σ_η estimator | ✅ |
| JLMS individual efficiency | ✅ |
| 4-component panel (transient + persistent) | ✅ |
| Pairs / Cluster bootstrap CI | ✅ |
| Asymptotic CI (CLT + delta method) | ✅ |
| Wild bootstrap significance test (PSVKZ 2024) | ✅ |
| Cross-validation bandwidth selection (LOO-CV) | ✅ |
| Stata 16.1+ integration | ✅ |
| Visualization | ✅ |

---

## Installation

```bash
pip install sw2023                  # core (numpy, scipy, pandas)
pip install sw2023[viz]             # + matplotlib
pip install sw2023[dev]             # + jupyter, pytest
```

---

## Quick Start

### Cross-sectional model

```python
import numpy as np
from sw2023 import SW2023Model

X = np.random.lognormal(0, 0.5, size=(200, 2))   # 2 inputs
Y = np.random.lognormal(0, 0.5, size=(200, 3))   # 3 outputs

m = SW2023Model(X, Y, method='HMS')
m.fit()

print(m.efficiency_.mean())          # mean efficiency
m.summary()
```

### Panel model (4-component)

```python
from sw2023 import PanelSW2023

m = PanelSW2023(X, Y, firm_id, time_id, method='HMS')
m.fit()

print(m.eff_transient_.mean())       # transient efficiency
print(m.eff_persistent_.mean())      # persistent efficiency
```

### Bootstrap confidence intervals

```python
from sw2023 import bootstrap_sw

result = bootstrap_sw(X, Y, B=200, alpha=0.05)
print(result['eff_mean_ci'])          # [lower, upper]
print(result['phi_hat_ci'])           # (n, 2) frontier CI
print(result['eff_individual_ci'])    # (n, 2) individual efficiency CI
```

### Asymptotic CI (CLT-based, fast)

```python
m = SW2023Model(X, Y, method='HMS')
m.fit()
ci = m.confint_asymptotic(alpha=0.05)
print(ci['phi_hat_ci'])               # (n, 2)
print(ci['se_phi'])                   # (n,) standard errors
```

### Significance test for inefficiency heterogeneity (PSVKZ 2024)

```python
from sw2023 import test_r3_significance

res = test_r3_significance(X, Y, B=499)
print(res['p_value'])                 # H₀: E(ε³|Z) = const
```

---

## Stata Integration (16.1+)

```stata
* Set Python path (once)
python set exec "/usr/local/bin/python3"

* Cross-sectional
local sw_args "x1 x2 x3 | y1 y2 y3 y4 | method=HMS"
python script "sw2023_stata.py"

* Panel (4-component)
local sw_args "x1 x2 x3 | y1 y2 y3 y4 | method=HMS firm=farmid time=year"
python script "sw2023_stata.py", args("panel")
```

Results are stored as new Stata variables: `sw_efficiency`, `swp_te`, `swp_pe`, etc.

---

## Methodology

The SW(2023) method handles **multiple outputs** without imposing a functional form on the frontier. Key steps:

1. **Direction vector** `d ∈ R^(p+q)`: defines the efficiency direction in joint (input, output) space
2. **Rotation** `(X, Y) → (Z, U)`: projects onto frontier coordinates
3. **LLLS**: nonparametric kernel regression of `U` on `Z` → conditional moments r̂₁, r̂₂, r̂₃
4. **σ_η estimation**: `σ̂_η = max(0, (-r̂₃/a₃)^(1/3))` (SVKZ) or HMS for wrong-skewness
5. **JLMS**: `E[η | ξ̂]` → individual efficiency `exp(-η̂)`

The **4-component panel extension** decomposes:

```
U_it = φ(Z_it) + ‖d‖·v_it − ‖d‖·u_it + ‖d‖·α_i − ‖d‖·μ_i
```

- `v_it`: transient noise
- `u_it ~ N⁺(0, σ_u²)`: transient inefficiency
- `α_i ~ N(0, σ_α²)`: individual heterogeneity
- `μ_i ~ N⁺(0, σ_μ²)`: persistent inefficiency

---

## References

- Simar, L. & Wilson, P.W. (2023). Nonparametric, Stochastic Frontier Models with Multiple Inputs and Outputs. *Journal of Business & Economic Statistics*, 41(4), 1391–1403.
- Parmeter, C.F., Simar, L., Van Keilegom, I. & Zelenyuk, V. (2024). Inference in the Nonparametric Stochastic Frontier Model. Econometric Reviews.
- Jondrow, J., Lovell, C.A.K., Materov, I.S. & Schmidt, P. (1982). On the estimation of technical inefficiency in the stochastic frontier production function model. Journal of Econometrics.

---

## License

MIT License
