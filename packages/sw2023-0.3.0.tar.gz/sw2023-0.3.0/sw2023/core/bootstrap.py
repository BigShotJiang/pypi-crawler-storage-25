"""
부트스트랩 신뢰구간 (Bootstrap Confidence Intervals)

참고 문헌:
  Parmeter, Simar, Van Keilegom & Zelenyuk (2024, Econometric Reviews):
    "Inference in the Nonparametric Stochastic Frontier Model"
    → Wild bootstrap for hypothesis tests (significance / specification)

  Simar & Wilson (2023, JBES):
    → "variances have to be evaluated by bootstrap techniques"
    → Pairs bootstrap for phi_hat(z), sigma_eta(z), efficiency CIs

구현:
  bootstrap_sw       : 쌍별 부트스트랩 — phi_hat, efficiency 신뢰구간
  bootstrap_panel    : 클러스터 부트스트랩 — 패널 모형
  test_r3_significance: Wild bootstrap — r3(z)가 특정 공변량에 의존하는지 검정

올바른 개별 CI 계산:
  ① 원본 표본 피팅 → Z_orig, U_orig, d_fixed 저장
  ② 재표본 후 동일 방향벡터 d_fixed로 변환 → Z_b, U_b
  ③ Z_b, U_b로 적률 추정
  ④ 추정된 적률 함수를 Z_orig에서 평가 (local_linear eval_points)
  ⑤ phi_hat_b(Z_orig), eff_b(Z_orig) 수집 → 분위수로 CI

주의: n_jobs>1 (joblib 병렬화) 금지 — iMac 2017 커널 패닉 원인
"""

import numpy as np
import pandas as pd

from .transform  import transform
from .frontier   import estimate_moments, local_linear
from .decompose  import (estimate_sigma_eta, estimate_sigma_eps,
                         estimate_frontier, jlms_efficiency)
from .preprocess import preprocess_apply


# ─────────────────────────────────────────────────────────────
# 내부: 단일 반복 함수
# ─────────────────────────────────────────────────────────────

def _boot_iter_sw(seed, X_prep, Y_prep, d, norm_d,
                  Z_orig, U_orig, method, bandwidth_method):
    """
    SW 모형 부트스트랩 1회 반복.

    재표본 → 동일 d로 변환 → 적률 추정 → Z_orig에서 평가.

    Returns
    -------
    phi_hat_b  : (n,) 원래 Z 점에서의 부트스트랩 프론티어 추정
    sigma_eta_b: (n,)
    sigma_eps_b: (n,)
    eff_b      : (n,) 원래 U 값 기반 BC 효율성
    """
    rng = np.random.default_rng(seed)
    n   = len(X_prep)
    idx = rng.integers(0, n, size=n)

    X_b = X_prep[idx]
    Y_b = Y_prep[idx]

    # 동일 방향벡터로 회전
    Z_b, U_b, _ = transform(X_b, Y_b, d)

    # 부트스트랩 표본에서 적률 추정
    moments = estimate_moments(Z_b, U_b, bandwidth_method=bandwidth_method)
    h1   = moments['h']
    h2   = moments['h_r2']
    h3   = moments['h_r3']
    eps_b = moments['eps']   # = U_b - r̂_1(Z_b)

    # 원래 Z 점에서 평가 (eval_points 사용)
    r1_b = local_linear(Z_b, U_b,       h=h1, eval_points=Z_orig)
    r2_b = local_linear(Z_b, eps_b**2,  h=h2, eval_points=Z_orig)
    r3_b = local_linear(Z_b, eps_b**3,  h=h3, eval_points=Z_orig)

    sigma_eta_b = estimate_sigma_eta(r3_b, method=method)
    sigma_eps_b = estimate_sigma_eps(r2_b, sigma_eta_b)
    phi_hat_b, _ = estimate_frontier(r1_b, sigma_eta_b, norm_d)
    eff_b, _     = jlms_efficiency(U_orig, phi_hat_b, sigma_eta_b, sigma_eps_b)

    return phi_hat_b, sigma_eta_b, sigma_eps_b, eff_b


def _boot_iter_panel(seed, X_prep, Y_prep, firm_id, time_id, firms,
                     d, norm_d, Z_orig, U_orig, method, bandwidth_method):
    """
    패널 모형 부트스트랩 1회 반복 (클러스터 재표본).

    개체(firm) 단위로 재표본하여 패널 내 시계열 의존성 보존.
    """
    from ..panel.four_component import PanelSW2023
    rng    = np.random.default_rng(seed)
    N      = len(firms)
    chosen = rng.choice(firms, size=N, replace=True)

    idx_list, new_fid = [], []
    for k, f in enumerate(chosen):
        mask = firm_id == f
        idx_list.append(np.where(mask)[0])
        new_fid.extend([k] * mask.sum())
    idx_all = np.concatenate(idx_list)
    new_fid = np.array(new_fid)

    X_b = X_prep[idx_all]
    Y_b = Y_prep[idx_all]

    Z_b, U_b, _ = transform(X_b, Y_b, d)
    moments = estimate_moments(Z_b, U_b, bandwidth_method=bandwidth_method)
    h1, h2, h3 = moments['h'], moments['h_r2'], moments['h_r3']
    eps_b = moments['eps']

    r1_b = local_linear(Z_b, U_b,       h=h1, eval_points=Z_orig)
    r2_b = local_linear(Z_b, eps_b**2,  h=h2, eval_points=Z_orig)
    r3_b = local_linear(Z_b, eps_b**3,  h=h3, eval_points=Z_orig)

    sigma_eta_b = estimate_sigma_eta(r3_b, method=method)
    sigma_eps_b = estimate_sigma_eps(r2_b, sigma_eta_b)
    phi_hat_b, _ = estimate_frontier(r1_b, sigma_eta_b, norm_d)
    eff_b, _     = jlms_efficiency(U_orig, phi_hat_b, sigma_eta_b, sigma_eps_b)

    return phi_hat_b, sigma_eta_b, sigma_eps_b, eff_b


# ─────────────────────────────────────────────────────────────
# 공개 API: bootstrap_sw
# ─────────────────────────────────────────────────────────────

def bootstrap_sw(X, Y, B=200, alpha=0.05,
                 direction='mean', method='HMS',
                 log_transform=True, standardize=True,
                 bandwidth_method='silverman',
                 seed=None, verbose=True):
    """
    SW2023Model에 대한 쌍별 부트스트랩 신뢰구간.

    개별 관측치 CI를 올바르게 계산하기 위해:
      - 원본 방향벡터 d를 고정하고
      - 재표본 표본의 적률 함수를 원래 Z 점에서 평가.

    Parameters
    ----------
    X, Y             : 원본 데이터
    B                : 부트스트랩 반복 수
    alpha            : 유의수준 (1-alpha 신뢰구간)
    direction        : 방향벡터 지정 ('mean' | 'median' | array)
    method           : 'HMS' | 'SVKZ'
    log_transform    : bool
    standardize      : bool
    bandwidth_method : 'silverman' | 'loocv'  (부트스트랩에는 'silverman' 권장)
    seed             : 랜덤 시드
    verbose          : 진행 상황 출력

    Returns
    -------
    dict:
        phi_hat_point      : (n,) 원본 프론티어 추정값
        phi_hat_ci         : (n, 2) 프론티어 신뢰구간
        eff_mean_point     : float 평균 효율성 추정값
        eff_mean_ci        : (2,) 평균 효율성 신뢰구간
        eff_individual_point: (n,) 개별 효율성 추정값
        eff_individual_ci  : (n, 2) 개별 효율성 신뢰구간
        sigma_eta_ci       : (n, 2) σ_η 신뢰구간
        B, alpha           : 사용된 파라미터
    """
    import gc
    from .model      import SW2023Model
    from .preprocess import preprocess
    from .transform  import make_direction

    X = np.asarray(X, dtype=float)
    Y = np.asarray(Y, dtype=float)

    # ── 원본 모형 피팅 ──────────────────────────────────────────
    if verbose:
        print("원본 모형 추정 중...")
    m0 = SW2023Model(X, Y, direction=direction, method=method,
                     log_transform=log_transform, standardize=standardize,
                     bandwidth_method=bandwidth_method)
    m0.fit(verbose=False)

    # 원본 모형에서 고정할 파라미터
    d_fixed   = m0.d_
    norm_d    = m0.norm_d_
    Z_orig    = m0.Z_
    U_orig    = m0.U_
    prep_info = m0.preprocess_info_

    if verbose:
        print(f"부트스트랩 시작 (B={B}, bandwidth={bandwidth_method})...")

    # ── 전처리된 X, Y (고정 파라미터 적용) ────────────────────
    X_prep, Y_prep = preprocess_apply(X, Y, prep_info)

    # ── 부트스트랩 루프 ─────────────────────────────────────────
    rng   = np.random.default_rng(seed)
    seeds = rng.integers(0, 2**31, size=B)
    n     = len(X)

    boot_phi      = np.full((B, n), np.nan)
    boot_sigma_eta = np.full((B, n), np.nan)
    boot_sigma_eps = np.full((B, n), np.nan)
    boot_eff      = np.full((B, n), np.nan)

    n_fail = 0
    for b, s in enumerate(seeds):
        if verbose and (b % 50 == 0):
            print(f"  Bootstrap {b+1}/{B}...")
        try:
            phi_b, seta_b, seps_b, eff_b = _boot_iter_sw(
                s, X_prep, Y_prep, d_fixed, norm_d,
                Z_orig, U_orig, method, bandwidth_method
            )
            boot_phi[b]       = phi_b
            boot_sigma_eta[b] = seta_b
            boot_sigma_eps[b] = seps_b
            boot_eff[b]       = eff_b
        except Exception:
            n_fail += 1
        finally:
            gc.collect()

    if n_fail > 0 and verbose:
        print(f"  경고: {n_fail}/{B}회 실패")

    lo, hi = alpha / 2 * 100, (1 - alpha / 2) * 100

    result = {
        # 프론티어 φ̂(z)
        'phi_hat_point'       : m0.phi_hat_,
        'phi_hat_ci'          : np.column_stack([
            np.nanpercentile(boot_phi, lo, axis=0),
            np.nanpercentile(boot_phi, hi, axis=0),
        ]),
        # 평균 효율성
        'eff_mean_point'      : float(np.nanmean(m0.efficiency_)),
        'eff_mean_ci'         : np.nanpercentile(
                                    np.nanmean(boot_eff, axis=1), [lo, hi]),
        # 개별 효율성
        'eff_individual_point': m0.efficiency_,
        'eff_individual_ci'   : np.column_stack([
            np.nanpercentile(boot_eff, lo, axis=0),
            np.nanpercentile(boot_eff, hi, axis=0),
        ]),
        # σ_η
        'sigma_eta_point'     : m0.sigma_eta_,
        'sigma_eta_ci'        : np.column_stack([
            np.nanpercentile(boot_sigma_eta, lo, axis=0),
            np.nanpercentile(boot_sigma_eta, hi, axis=0),
        ]),
        'B'    : B,
        'alpha': alpha,
        'n_fail': n_fail,
    }

    if verbose:
        ci = result['eff_mean_ci']
        print(f"\n평균 효율성: {result['eff_mean_point']:.4f}  "
              f"{int((1-alpha)*100)}% CI: [{ci[0]:.4f}, {ci[1]:.4f}]")

    return result


# ─────────────────────────────────────────────────────────────
# 공개 API: bootstrap_panel
# ─────────────────────────────────────────────────────────────

def bootstrap_panel(X, Y, firm_id, time_id,
                    B=200, alpha=0.05,
                    direction='mean', method='HMS',
                    log_transform=True, standardize=True,
                    bandwidth_method='silverman',
                    seed=None, verbose=True):
    """
    PanelSW2023에 대한 클러스터 부트스트랩 신뢰구간.

    개체(firm) 단위로 재표본하여 패널 내 시계열 의존성 보존.
    개별 관측치 CI는 bootstrap_sw와 동일한 방식으로 수정:
      재표본 → 동일 d로 변환 → 원래 Z 점에서 평가.

    Parameters
    ----------
    X, Y             : 원본 데이터 (n_total × ...)
    firm_id, time_id : 개체·시점 식별자 (n_total,)
    (나머지: bootstrap_sw와 동일)

    Returns
    -------
    dict: bootstrap_sw 결과 + 분해된 일시적/영구적 효율성 CI
    """
    import gc
    from ..panel.four_component import PanelSW2023
    from .preprocess import preprocess
    from .transform  import make_direction

    X       = np.asarray(X, dtype=float)
    Y       = np.asarray(Y, dtype=float)
    firm_id = np.asarray(firm_id)
    time_id = np.asarray(time_id)
    firms   = np.unique(firm_id)

    # ── 원본 모형 피팅 ──────────────────────────────────────────
    if verbose:
        print("원본 패널 모형 추정 중...")
    m0 = PanelSW2023(X, Y, firm_id, time_id,
                     direction=direction, method=method,
                     log_transform=log_transform, standardize=standardize,
                     bandwidth_method=bandwidth_method)
    m0.fit(verbose=False)

    d_fixed   = m0.d_
    norm_d    = m0.norm_d_
    Z_orig    = m0.Z_
    U_orig    = m0.U_
    prep_info = m0.preprocess_info_

    if verbose:
        print(f"클러스터 부트스트랩 시작 (B={B}, N_firms={len(firms)})...")

    X_prep, Y_prep = preprocess_apply(X, Y, prep_info)

    rng   = np.random.default_rng(seed)
    seeds = rng.integers(0, 2**31, size=B)
    n     = len(X)

    boot_phi       = np.full((B, n), np.nan)
    boot_sigma_eta = np.full((B, n), np.nan)
    boot_sigma_eps = np.full((B, n), np.nan)
    boot_eff       = np.full((B, n), np.nan)

    n_fail = 0
    for b, s in enumerate(seeds):
        if verbose and (b % 50 == 0):
            print(f"  Bootstrap {b+1}/{B}...")
        try:
            phi_b, seta_b, seps_b, eff_b = _boot_iter_panel(
                s, X_prep, Y_prep, firm_id, time_id, firms,
                d_fixed, norm_d, Z_orig, U_orig, method, bandwidth_method
            )
            boot_phi[b]        = phi_b
            boot_sigma_eta[b]  = seta_b
            boot_sigma_eps[b]  = seps_b
            boot_eff[b]        = eff_b
        except Exception:
            n_fail += 1
        finally:
            gc.collect()

    if n_fail > 0 and verbose:
        print(f"  경고: {n_fail}/{B}회 실패")

    lo, hi = alpha / 2 * 100, (1 - alpha / 2) * 100

    result = {
        'phi_hat_point'       : m0.phi_hat_,
        'phi_hat_ci'          : np.column_stack([
            np.nanpercentile(boot_phi, lo, axis=0),
            np.nanpercentile(boot_phi, hi, axis=0),
        ]),
        'eff_mean_point'      : float(np.nanmean(m0.efficiency_)),
        'eff_mean_ci'         : np.nanpercentile(
                                    np.nanmean(boot_eff, axis=1), [lo, hi]),
        'eff_individual_point': m0.efficiency_,
        'eff_individual_ci'   : np.column_stack([
            np.nanpercentile(boot_eff, lo, axis=0),
            np.nanpercentile(boot_eff, hi, axis=0),
        ]),
        'sigma_eta_point'     : m0.sigma_eta_,
        'sigma_eta_ci'        : np.column_stack([
            np.nanpercentile(boot_sigma_eta, lo, axis=0),
            np.nanpercentile(boot_sigma_eta, hi, axis=0),
        ]),
        'B'     : B,
        'alpha' : alpha,
        'n_fail': n_fail,
    }

    if verbose:
        ci = result['eff_mean_ci']
        print(f"\n평균 효율성: {result['eff_mean_point']:.4f}  "
              f"{int((1-alpha)*100)}% CI: [{ci[0]:.4f}, {ci[1]:.4f}]")

    return result


# ─────────────────────────────────────────────────────────────
# PSVKZ Wild Bootstrap: 비효율성 유의성 검정
# ─────────────────────────────────────────────────────────────

def test_r3_significance(X, Y, direction='mean', method='HMS',
                         log_transform=True, standardize=True,
                         bandwidth_method='silverman',
                         B=499, seed=None, verbose=True):
    """
    비효율성(η)이 관측 가능한 공변량 Z에 실제로 의존하는지 검정.

    귀무가설 H₀: E(ε³|Z) = const  (공간적으로 균일한 비효율성)
    대립가설 H₁: E(ε³|Z) ≠ const  (이질적 비효율성)

    PSVKZ(2024) Section 3.1 wild bootstrap (Rademacher 교란):
      ① r̂_3(Z_i) 추정 → 잔차 η_i = ε̂³_i - r̂_3(Z_i)
      ② 중심화: η^c_i = η_i - mean(η)
      ③ Wild 교란: η*_i = η^c_i × V_i,  V_i ~ Rademacher(±1, 각 50%)
      ④ 부트스트랩 응답: ε̂³'*_i = r̂_3(Z_i) + η*_i
      ⑤ r̂*_3(Z)를 ε̂³'*로 재추정 → 검정통계량 T*_b 계산
      ⑥ p-값 = #{T*_b ≥ T_obs} / B

    검정통계량 (분산 가중 평균 비균질성):
      T = (1/n) × Σ_i (r̂_3(Z_i) - mean(r̂_3))² / Var(ε̂³)

    Parameters
    ----------
    X, Y             : 원본 데이터
    direction        : 방향벡터
    method           : 'HMS' | 'SVKZ'
    bandwidth_method : 대역폭 방법
    B                : 부트스트랩 반복 수 (기본 499)
    seed             : 랜덤 시드
    verbose          : 출력 여부

    Returns
    -------
    dict:
        statistic : float  관측 검정통계량 T
        p_value   : float  부트스트랩 p-값
        r3_hat    : (n,)   추정된 r̂_3(Z)
        B         : int
    """
    import gc
    from .model      import SW2023Model
    from .preprocess import preprocess

    if verbose:
        print("비효율성 유의성 검정 (PSVKZ Wild Bootstrap)...")

    # ── 원본 모형 피팅 ──────────────────────────────────────────
    m0 = SW2023Model(X, Y, direction=direction, method=method,
                     log_transform=log_transform, standardize=standardize,
                     bandwidth_method=bandwidth_method)
    m0.fit(verbose=False)

    eps_cubed = m0.eps_ ** 3
    r3_obs    = m0.r3_
    resid     = eps_cubed - r3_obs
    resid_c   = resid - resid.mean()   # 중심화 잔차

    # 관측 검정통계량: r3 공간적 변동 / 총 분산
    r3_var  = np.var(r3_obs, ddof=1)
    eps_var = np.var(eps_cubed, ddof=1)
    T_obs   = r3_var / max(eps_var, 1e-15)

    if verbose:
        print(f"  관측 통계량 T = {T_obs:.6f}")
        print(f"  Wild bootstrap 시작 (B={B})...")

    # ── Wild bootstrap ──────────────────────────────────────────
    rng   = np.random.default_rng(seed)
    T_boot = np.empty(B)

    for b in range(B):
        if verbose and (b % 100 == 0):
            print(f"  Bootstrap {b+1}/{B}...")

        # Rademacher 교란: ±1 각 50%
        V        = rng.choice([-1.0, 1.0], size=len(resid_c))
        eps3_star = r3_obs + resid_c * V

        # r̂*_3(Z) 재추정
        r3_star = local_linear(m0.Z_, eps3_star, h=m0.h_r3_)

        r3_star_var  = np.var(r3_star, ddof=1)
        eps3_var_star = np.var(eps3_star, ddof=1)
        T_boot[b]    = r3_star_var / max(eps3_var_star, 1e-15)

        gc.collect()

    p_value = float((T_boot >= T_obs).mean())

    if verbose:
        print(f"\n  p-값 = {p_value:.4f}  "
              f"({'유의 (이질적 비효율성)' if p_value < 0.05 else '비유의 (균일 비효율성)'})")

    return {
        'statistic': T_obs,
        'p_value'  : p_value,
        'r3_hat'   : r3_obs,
        'T_boot'   : T_boot,
        'B'        : B,
    }
