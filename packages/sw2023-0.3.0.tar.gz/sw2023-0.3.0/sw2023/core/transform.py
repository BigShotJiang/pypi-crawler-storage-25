"""
SW (2023) Step 1-3: 회전 변환 (Rotation Transformation)

Simar & Wilson (2023), JBES 41(4), 1391-1403.
Eq. (2.10)-(2.17): 방향벡터 d로 (X,Y) → (Z,U) 변환
"""

import numpy as np
from scipy.linalg import null_space


def make_direction(X, Y, method='mean'):
    """
    방향벡터 d 생성.
    SW(2023) 권고: 투입물 방향 음수, 산출물 방향 양수.

    Parameters
    ----------
    X : (n, p) 투입물
    Y : (n, q) 산출물
    method : 'mean' | 'median' | array-like

    Returns
    -------
    d : (p+q,) 정규화된 방향벡터
    """
    if isinstance(method, (np.ndarray, list)):
        d = np.asarray(method, dtype=float)
    elif method == 'mean':
        d = np.concatenate([-np.mean(X, axis=0), np.mean(Y, axis=0)])
    elif method == 'median':
        d = np.concatenate([-np.median(X, axis=0), np.median(Y, axis=0)])
    else:
        raise ValueError(f"method must be 'mean', 'median', or array. Got {method}")

    norm = np.linalg.norm(d)
    if norm == 0:
        raise ValueError("방향벡터의 크기가 0입니다.")
    return d / norm


def rotation_matrix(d):
    """
    회전행렬 R_d 계산. SW(2023) Eq. (2.10).

    R_d = [V_d'; d'] 형태의 직교행렬
    - V_d: d에 직교하는 (r x r-1) 기저행렬
    - 마지막 행 = d (정규화됨)

    Parameters
    ----------
    d : (r,) 정규화된 방향벡터

    Returns
    -------
    R : (r, r) 직교 회전행렬
    """
    d = d / np.linalg.norm(d)
    V = null_space(d.reshape(1, -1))   # (r, r-1)
    R = np.vstack([V.T, d.reshape(1, -1)])  # (r, r)
    return R


def transform(X, Y, d):
    """
    (X, Y) → (Z, U) 회전 변환. SW(2023) Eq. (2.15).

    W_i = (X_i, Y_i) ∈ R^r
    [Z_i; U_i] = R_d @ W_i

    여기서 U_i = d' @ W_i / ||d|| 는 방향 d로의 스칼라 거리 (종속변수)
    Z_i ∈ R^(r-1) 는 나머지 좌표 (독립변수)

    Parameters
    ----------
    X : (n, p) 투입물
    Y : (n, q) 산출물
    d : (p+q,) 정규화된 방향벡터

    Returns
    -------
    Z : (n, r-1) 회전 후 독립변수
    U : (n,)    회전 후 종속변수
    R : (r, r)  회전행렬 (역변환용)
    """
    X = np.asarray(X, dtype=float)
    Y = np.asarray(Y, dtype=float)
    W = np.hstack([X, Y])              # (n, r)
    R = rotation_matrix(d)             # (r, r)
    WR = W @ R.T                       # (n, r)
    Z = WR[:, :-1]                     # (n, r-1)
    U = WR[:, -1]                      # (n,)
    return Z, U, R


def inverse_transform(Z, U, R):
    """
    (Z, U) → (X, Y) 역변환.

    Parameters
    ----------
    Z : (n, r-1)
    U : (n,)
    R : (r, r) 회전행렬

    Returns
    -------
    W : (n, r) = (X, Y) 복원
    """
    ZU = np.column_stack([Z, U])       # (n, r)
    W = ZU @ R                         # (n, r)
    return W
