"""
데이터 전처리: 로그 변환 + 표준화

SW(2023) Sec 4: "We standardize each of our variables by dividing by
their standard deviations (this amounts to merely changing units)."
"""

import numpy as np


def preprocess(X, Y, log_transform=True, standardize=True):
    """
    투입물·산출물 전처리.

    Parameters
    ----------
    X            : (n, p)  투입물
    Y            : (n, q)  산출물
    log_transform: bool    로그 변환 여부 (생산함수 분석 시 권장)
    standardize  : bool    표준화 여부 (변수 단위 차이 제거)

    Returns
    -------
    X_out, Y_out  : 전처리된 배열
    scaler_info   : 역변환에 필요한 정보 dict
    """
    X = np.asarray(X, dtype=float).copy()
    Y = np.asarray(Y, dtype=float).copy()

    info = {
        'log_transform': log_transform,
        'standardize'  : standardize,
        'X_log_shift'  : None,
        'Y_log_shift'  : None,
        'X_std'        : None,
        'Y_std'        : None,
    }

    # 로그 변환 (0 또는 음수 값 처리)
    if log_transform:
        X_shift = np.where(X <= 0, -X.min(axis=0) + 1e-6, 0)
        Y_shift = np.where(Y <= 0, -Y.min(axis=0) + 1e-6, 0)
        info['X_log_shift'] = X_shift.max(axis=0)
        info['Y_log_shift'] = Y_shift.max(axis=0)

        X = np.log(X + info['X_log_shift'])
        Y = np.log(Y + info['Y_log_shift'])

    # 표준화 (표준편차로 나누기)
    if standardize:
        info['X_std'] = np.std(X, axis=0, ddof=1)
        info['Y_std'] = np.std(Y, axis=0, ddof=1)
        info['X_std'] = np.where(info['X_std'] == 0, 1.0, info['X_std'])
        info['Y_std'] = np.where(info['Y_std'] == 0, 1.0, info['Y_std'])

        X = X / info['X_std']
        Y = Y / info['Y_std']

    return X, Y, info


def preprocess_apply(X, Y, info):
    """
    기존 scaler_info를 사용해 새 데이터에 동일한 전처리 적용.

    부트스트랩에서 원본 표본의 변환 파라미터를 재사용할 때 사용.

    Parameters
    ----------
    X, Y  : 원시 데이터
    info  : preprocess()가 반환한 scaler_info dict

    Returns
    -------
    X_out, Y_out : 전처리된 배열
    """
    X = np.asarray(X, dtype=float).copy()
    Y = np.asarray(Y, dtype=float).copy()

    if info['log_transform']:
        X = np.log(X + info['X_log_shift'])
        Y = np.log(Y + info['Y_log_shift'])

    if info['standardize']:
        X = X / info['X_std']
        Y = Y / info['Y_std']

    return X, Y
