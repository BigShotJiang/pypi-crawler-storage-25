"""
대역폭 선택 (Bandwidth Selection)

SW(2023) 논문 방식:
  Leave-One-Out Cross-Validation (LOO-CV)
  - U ~ Z 회귀, ε̂² ~ Z 회귀, ε̂³ ~ Z 회귀 각각 독립적으로 최적화
  - 하한: 0.1 × σ̂_k × n^{-1/(d+4)}
  - 상한: 3 × [max(Z_k) - min(Z_k)]
  - 스칼라 배율 c 탐색: h_k = c × h_ref_k

핵 trick (hat-matrix LOO):
  ŷ_{-i} = (ŷ_i − h_{ii} × y_i) / (1 − h_{ii})
  h_{ii} = [(XtWX_i)^{-1}]_{00}   (K[i,i]=1 이므로 성립)
  → n번 재적합 없이 O(n²) 1회로 LOO-CV 계산 가능

참고: Fan & Gijbels (1996) Ch.4, Simar & Wilson (2023) Sec.4
"""

import numpy as np
from scipy.optimize import minimize_scalar

from .frontier import (_compute_K_full, _compute_XtWX_batch,
                        _compute_XtWy_batch, _llls_from_normal_equations)


# ─────────────────────────────────────────────────────────────
# 참조 거리 행렬 (c 탐색 핵심 가속)
# ─────────────────────────────────────────────────────────────

def _precompute_S(Z, h_ref, chunk_size=512):
    """
    참조 스케일 기준 제곱 거리 행렬.

    S[i,j] = 0.5 × Σ_k ((Z_ik - Z_jk) / h_ref_k)²

    스칼라 배율 c에 대해 K_c[i,j] = exp(−S[i,j] / c²)
    → S를 한 번만 계산하면 c마다 K를 O(n²)에 얻을 수 있음.

    Parameters
    ----------
    Z         : (n, d)
    h_ref     : (d,) 참조 대역폭
    chunk_size: int

    Returns
    -------
    S : (n, n)  ≥ 0, S[i,i] = 0
    """
    n, d = Z.shape
    Zh   = Z / h_ref                      # (n, d) 스케일 조정
    S    = np.empty((n, n), dtype=float)

    for start in range(0, n, chunk_size):
        end  = min(start + chunk_size, n)
        diff = Zh[start:end, None, :] - Zh[None, :, :]   # (bs, n, d)
        S[start:end] = 0.5 * np.sum(diff ** 2, axis=-1)  # (bs, n)

    return S


# ─────────────────────────────────────────────────────────────
# LOO-CV 점수 (hat-matrix trick)
# ─────────────────────────────────────────────────────────────

def _loocv_score_from_K(K, Z, y):
    """
    주어진 K 행렬로 LOO-CV 점수 계산.

    hat-matrix trick:
      h_{ii} = [(XtWX_i)^{-1}]_{00}   (K[i,i] = 1 보장됨)
      LOO 잔차 = (y_i − ŷ_i) / (1 − h_{ii})
      CV = mean(LOO 잔차²)

    Parameters
    ----------
    K : (n, n) 커널 행렬 (K[i,i] = 1)
    Z : (n, d)
    y : (n,)

    Returns
    -------
    cv : float  LOO-CV 점수 (낮을수록 좋음)
    """
    n, d = Z.shape
    reg  = 1e-10 * np.eye(d + 1)

    ZZT  = np.einsum('ij,ik->ijk', Z, Z)          # (n, d, d)
    XtWX = _compute_XtWX_batch(K, Z, ZZT, reg)    # (n, d+1, d+1)
    XtWy = _compute_XtWy_batch(K, Z, y)           # (n, d+1)

    # 적합값
    beta  = np.linalg.solve(XtWX, XtWy[:, :, np.newaxis])[:, :, 0]  # (n, d+1)
    y_hat = beta[:, 0]                             # (n,)

    # 레버리지: h_{ii} = (XtWX^{-1})[0,0]
    # solve(XtWX, e0): XtWX는 (n,d+1,d+1), RHS는 (1,d+1,1) → (n,d+1,1)
    e0        = np.zeros((1, d + 1, 1));  e0[0, 0, 0] = 1.0
    lev_mat   = np.linalg.solve(XtWX, e0)         # (n, d+1, 1)
    h_ii      = lev_mat[:, 0, 0]                   # (n,)

    # LOO 잔차
    # h_ii → 1 이면 ŷ_i → y_i (보간), resid → 0, denom → 0 동시 발생
    # 0/0 수치 문제 처리: h_ii > 0.95 구간은 전역 평균 잔차로 대체
    # (대역폭이 너무 작아 이웃을 못 찾는 경우 → 최악 예측 = 전역 평균 사용)
    resid       = y - y_hat
    global_resid = y - np.mean(y)        # 전역 평균 기반 잔차 (패널티)

    denom = 1.0 - h_ii
    hat_loo = resid / np.where(denom > 1e-6, denom, 1e-6)

    # h_ii > 0.95: 대역폭 과소 → 패널티 부과
    loo_sq = np.where(h_ii > 0.95, global_resid ** 2, hat_loo ** 2)

    return float(np.mean(loo_sq))


# ─────────────────────────────────────────────────────────────
# 유효 이웃 수 기반 하한 계산
# ─────────────────────────────────────────────────────────────

def _find_c_neff(S, k_min):
    """
    평균 유효 이웃 수(average effective sample size)가 k_min 이상이 되는
    최소 c를 이진 탐색으로 찾는다.

    avg_neff(c) = (1/n) × Σ_i Σ_j K_c[i,j]  (K_c[i,j] = exp(−S[i,j]/c²))

    c가 너무 작으면 K[i,j]≈0 (j≠i), 각 점이 자신만의 이웃 → 보간 발생.
    c_low = max(논문 하한, c_neff)으로 설정하면 퇴화 구간을 탐색하지 않는다.

    Parameters
    ----------
    S     : (n, n) 참조 거리 행렬
    k_min : float  목표 최소 유효 이웃 수

    Returns
    -------
    c_low : float  avg_neff(c_low) ≈ k_min
    """
    n = S.shape[0]
    lo_lc, hi_lc = -4.0, 5.0   # c ∈ [exp(-4), exp(5)] ≈ [0.018, 148]

    for _ in range(60):
        mid_lc = 0.5 * (lo_lc + hi_lc)
        K = np.exp(-S / np.exp(2.0 * mid_lc))
        avg_neff = float(K.sum()) / n       # K[i,i]=1 포함
        if avg_neff < k_min:
            lo_lc = mid_lc
        else:
            hi_lc = mid_lc

    return float(np.exp(0.5 * (lo_lc + hi_lc)))


# ─────────────────────────────────────────────────────────────
# 스칼라 LOO-CV 대역폭 최적화
# ─────────────────────────────────────────────────────────────

def bandwidth_loocv(Z, y, h_ref=None, n_grid=15, verbose=False):
    """
    스칼라 배율 LOO-CV 대역폭 최적화.

    h_k = c* × h_ref_k  를 최소화하는 c*를 탐색.
    h_ref_k = σ̂_k × n^{-1/(d+4)}  (최적 수렴 차수 기준)

    SW(2023) 제약:
      하한: c ≥ max(0.1, c_neff)  — 평균 유효 이웃 ≥ max(5, 2(d+2))
            c=0.1처럼 너무 작으면 보간 발생, CV 곡선 퇴화
      상한: h_k ≤ 3 × range(Z_k) →  c ≤ 3×range/h_ref (차원별 최솟값)

    Parameters
    ----------
    Z       : (n, d) 설명변수
    y       : (n,)  종속변수
    h_ref   : (d,) 참조 대역폭 (None이면 자동 계산)
    n_grid  : coarse grid 탐색 점 수
    verbose : 탐색 과정 출력 여부

    Returns
    -------
    h_opt : (d,) 최적 대역폭
    """
    Z = np.asarray(Z, dtype=float)
    y = np.asarray(y, dtype=float)
    n, d = Z.shape

    # 참조 대역폭
    std_Z = Z.std(axis=0)
    std_Z = np.where(std_Z < 1e-10, 1e-10, std_Z)

    if h_ref is None:
        h_ref = std_Z * n ** (-1.0 / (d + 4))

    # SW(2023) 경계
    range_Z = Z.max(0) - Z.min(0)
    range_Z = np.where(range_Z < 1e-10, 1e-10, range_Z)
    c_high = float(np.min(3.0 * range_Z / h_ref))
    c_high = min(max(c_high, 1.0), 20.0)   # 최소 1.0, 최대 20.0으로 클리핑

    # 참조 거리 행렬 (S는 c와 무관 → 한 번만 계산)
    S = _precompute_S(Z, h_ref)

    # 적응형 하한: 평균 유효 이웃 수 ≥ k_min = max(5, 2×(d+2))
    # c=0.1 처럼 너무 작은 값은 보간(interpolation) 발생 → CV 곡선이 퇴화
    k_min = max(5.0, 2.0 * (d + 2))
    c_neff = _find_c_neff(S, k_min)
    c_low  = max(0.1, c_neff)
    c_low  = min(c_low, c_high * 0.5)      # 상한의 절반 이하로 제한

    if verbose:
        print(f"    LOO-CV 경계: c_low={c_low:.3f} (neff≥{k_min:.0f}), "
              f"c_high={c_high:.3f}")

    def cv_loss(log_c):
        c = np.exp(log_c)
        K = np.exp(-S / (c ** 2))           # K[i,i] = exp(0) = 1
        return _loocv_score_from_K(K, Z, y)

    # 1단계: coarse grid
    log_c_lo   = np.log(c_low)
    log_c_hi   = np.log(c_high)
    log_c_grid = np.linspace(log_c_lo, log_c_hi, n_grid)
    cv_vals    = [cv_loss(lc) for lc in log_c_grid]
    best_idx   = int(np.argmin(cv_vals))
    best_lc    = log_c_grid[best_idx]

    if verbose:
        print(f"    LOO-CV grid: c={np.exp(best_lc):.3f}, "
              f"CV={cv_vals[best_idx]:.6f}")

    # 2단계: 황금분할 세밀화
    lo = log_c_grid[max(0, best_idx - 1)]
    hi = log_c_grid[min(n_grid - 1, best_idx + 1)]
    result = minimize_scalar(cv_loss, bounds=(lo, hi),
                              method='bounded',
                              options={'xatol': 0.02})
    c_opt = float(np.exp(result.x))

    if verbose:
        print(f"    LOO-CV refined: c={c_opt:.3f}, "
              f"CV={result.fun:.6f}")

    return c_opt * h_ref


# ─────────────────────────────────────────────────────────────
# Silverman 규칙 (기본값, 하위 호환)
# ─────────────────────────────────────────────────────────────

def bandwidth_silverman(Z):
    """
    Silverman 규칙 대역폭.

    h_j = 1.06 × σ̂_j × n^{-1/(d+4)}
    """
    Z = np.asarray(Z, dtype=float)
    n, d = Z.shape
    h = 1.06 * Z.std(axis=0) * n ** (-1.0 / (d + 4))
    return np.where(h == 0, 1e-6, h)
