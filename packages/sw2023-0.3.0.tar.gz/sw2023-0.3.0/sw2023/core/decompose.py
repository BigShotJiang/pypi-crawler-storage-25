"""
SW (2023) Step 7-9: 비효율성 분해 및 효율성 지수

SVKZ 추정량 (Simar, Van Keilegom, Zelenyuk):
  σ̂_η(z) = max{0, cbrt(-r̂_3(z) / a₃⁺)}

HMS 추정량 (Hafner, Manner, Simar):
  r̂_3(z) ≤ 0 이면: σ̂_η(z) = cbrt(-r̂_3(z) / a₃⁺)
  r̂_3(z) > 0 이면: σ̂_η(z) = cbrt( r̂_3(z) / a₃⁻)  ← wrong skewness 처리

상수 (half-normal 분포 기반):
  a₃⁺ = (4-π)/π × √(2/π) ≈ 0.2177   ← r3 ≤ 0일 때 (third central moment)
  a₃⁻ ≈ 0.016741474                   ← r3 > 0일 때 (HMS 논문 제공)

참고: LOO-CV 대역폭을 사용할 때 r3 추정에 큰 bandwidth가 선택되어
      wrong skewness 비율이 낮아지면 a₃⁻는 거의 사용되지 않음.
      rho=0(sigma_eps=0)의 경우 Table F.1과 일치.
"""

import numpy as np
from scipy.stats import norm as scipy_norm

PI = np.pi
A3_PLUS  = (4 - PI) / PI * np.sqrt(2 / PI)   # ≈ 0.2177
A3_MINUS = 0.016741474                          # HMS 논문 제공값


def estimate_sigma_eta(r3, method='HMS'):
    """
    3차 조건부 적률 r̂_3(z)로부터 σ̂_η(z) 추정.

    Parameters
    ----------
    r3     : (n,) r̂_3(Z_i) 값
    method : 'SVKZ' | 'HMS'

    Returns
    -------
    sigma_eta : (n,) ≥ 0
    """
    r3 = np.asarray(r3, dtype=float)

    if method == 'SVKZ':
        # max{0, cbrt(-r3 / a3+)}
        # r3 ≤ 0 → -r3 ≥ 0 → cbrt ≥ 0
        # r3 > 0 → -r3 < 0 → cbrt < 0 → max → 0
        val = -r3 / A3_PLUS
        sigma_eta = np.maximum(0.0, np.cbrt(val))

    elif method == 'HMS':
        # wrong skewness(r3 > 0) 시 대안 공식 적용
        val_neg = np.cbrt(-r3 / A3_PLUS)    # r3 ≤ 0인 경우
        val_pos = np.cbrt( r3 / A3_MINUS)   # r3 > 0인 경우 (HMS)
        sigma_eta = np.where(r3 <= 0, val_neg, val_pos)
        sigma_eta = np.maximum(0.0, sigma_eta)

    else:
        raise ValueError(f"method must be 'SVKZ' or 'HMS'. Got: {method}")

    return sigma_eta


def estimate_sigma_eps(r2, sigma_eta):
    """
    2차 조건부 적률로부터 σ̂_ε(z) 추정. SW(2023) Eq. (3.10).

    r_2(z) = σ_ε²(z) + (π-2)/π × σ_η²(z)
    → σ_ε²(z) = r_2(z) - (π-2)/π × σ_η²(z)

    Parameters
    ----------
    r2        : (n,)
    sigma_eta : (n,)

    Returns
    -------
    sigma_eps : (n,) ≥ 0
    """
    sigma_eps_sq = r2 - (PI - 2) / PI * sigma_eta ** 2
    return np.sqrt(np.maximum(0.0, sigma_eps_sq))


def estimate_frontier(r1, sigma_eta, norm_d=1.0):
    """
    프론티어 함수 φ̂(z) 추정. SW(2023) Eq. (3.9).

    r̂_1(z) = φ(z) - ||d|| × μ_η(z)
    μ_η(z) = √(2/π) × σ_η(z)

    → φ̂(z) = r̂_1(z) + ||d|| × μ_η(z)

    Parameters
    ----------
    r1        : (n,) 조건부 평균 추정값
    sigma_eta : (n,) σ̂_η
    norm_d    : float ||d|| (정규화된 경우 1.0)

    Returns
    -------
    phi_hat : (n,) 프론티어 추정값
    mu_eta  : (n,) 조건부 평균 비효율성
    """
    mu_eta = np.sqrt(2 / PI) * sigma_eta
    phi_hat = r1 + norm_d * mu_eta
    return phi_hat, mu_eta


def jlms_efficiency(U, phi_hat, sigma_eta, sigma_eps):
    """
    개별 효율성 지수 추정 (JLMS 방식). SW(2023) Sec 3.1.

    ξ̂_i = U_i - φ̂(Z_i) ≈ ||d||(ε_i - η_i)

    조건부 기대값:
      μ*_i = -ξ̂_i × σ_η² / (σ_ε² + σ_η²)
      σ*_i = σ_ε × σ_η / √(σ_ε² + σ_η²)
      Ê[η_i | ξ̂_i] = μ*_i + σ*_i × φ(μ*_i/σ*_i) / Φ(μ*_i/σ*_i)

    BC 효율성: exp(-Ê[η|ξ̂])

    Parameters
    ----------
    U         : (n,)
    phi_hat   : (n,)
    sigma_eta : (n,)
    sigma_eps : (n,)

    Returns
    -------
    eff_bc   : (n,) Battese-Coelli 효율성 지수 ∈ (0,1]
    eta_hat  : (n,) 비효율성 추정값 E[η|ξ̂]
    """
    xi_hat = U - phi_hat                               # 복합 잔차

    sigma_eta_sq = sigma_eta ** 2
    sigma_eps_sq = sigma_eps ** 2
    sigma_sq = sigma_eta_sq + sigma_eps_sq

    # 분모가 0인 경우 처리
    safe_sq = np.where(sigma_sq > 0, sigma_sq, np.nan)

    mu_star    = -xi_hat * sigma_eta_sq / safe_sq
    sigma_star = np.sqrt(sigma_eps_sq * sigma_eta_sq / safe_sq)

    # Φ(·), φ(·) 계산 (sigma_star=0이면 ratio=0으로 처리)
    safe_star = np.where(sigma_star > 0, sigma_star, 1.0)
    ratio = np.where(sigma_star > 0, mu_star / safe_star, 0.0)
    pdf_r = scipy_norm.pdf(ratio)
    cdf_r = scipy_norm.cdf(ratio)

    # 분모가 0에 가까울 때 처리
    safe_cdf = np.where(cdf_r > 1e-15, cdf_r, 1e-15)

    eta_hat = mu_star + sigma_star * pdf_r / safe_cdf
    eta_hat = np.maximum(0.0, eta_hat)                 # 비효율성 ≥ 0

    eff_bc = np.exp(-eta_hat)

    return eff_bc, eta_hat
