"""
시각화 모듈 (Visualization)

SW2023Model 및 PanelSW2023 결과 시각화.

함수 목록:
  plot_efficiency_dist   : 효율성 분포 히스토그램
  plot_efficiency_rank   : 효율성 순위 그래프
  plot_frontier_1d       : 1D 프론티어 (U vs Z[0])
  plot_panel_trend       : 패널 연도별 효율성 추이
  plot_decomposition     : 4-component 분해 (TE vs PE)
"""

import numpy as np
import warnings

try:
    import matplotlib
    import matplotlib.pyplot as plt
    import matplotlib.gridspec as gridspec
    import matplotlib.font_manager as _fm

    # 한국어 폰트 자동 설정 (Noto Sans CJK KR → Apple SD Gothic → fallback)
    _korean_candidates = ['Noto Sans CJK KR', 'Apple SD Gothic Neo',
                           'Malgun Gothic', 'NanumGothic']
    _available = {f.name for f in _fm.fontManager.ttflist}
    _kor_font  = next((f for f in _korean_candidates if f in _available), None)
    if _kor_font:
        matplotlib.rcParams['font.family'] = _kor_font
    matplotlib.rcParams['axes.unicode_minus'] = False  # 마이너스 깨짐 방지

    HAS_MPL = True
except ImportError:
    HAS_MPL = False
    warnings.warn(
        "matplotlib을 찾을 수 없습니다. 시각화 기능을 사용하려면 "
        "`pip install matplotlib`을 실행하세요.",
        ImportWarning
    )


def _check_mpl():
    if not HAS_MPL:
        raise ImportError(
            "matplotlib이 필요합니다. `pip install matplotlib`을 실행하세요."
        )


# ─────────────────────────────────────────────────────────────
# 1. 효율성 분포
# ─────────────────────────────────────────────────────────────
def plot_efficiency_dist(efficiency, title='효율성 분포',
                          bins=30, figsize=(7, 4),
                          color='steelblue', ax=None):
    """
    효율성 지수의 히스토그램.

    Parameters
    ----------
    efficiency : array-like  (n,) 효율성 값 [0,1]
    title      : str
    bins       : int
    figsize    : tuple
    color      : str
    ax         : matplotlib Axes or None
    """
    _check_mpl()
    eff = np.asarray(efficiency)
    eff = eff[~np.isnan(eff)]

    if ax is None:
        fig, ax = plt.subplots(figsize=figsize)
    else:
        fig = ax.figure

    ax.hist(eff, bins=bins, color=color, edgecolor='white',
             alpha=0.8, density=True)

    mean_e = eff.mean()
    med_e  = np.median(eff)
    ax.axvline(mean_e, color='firebrick', linestyle='--', linewidth=1.5,
                label=f'평균 = {mean_e:.3f}')
    ax.axvline(med_e,  color='darkorange', linestyle=':', linewidth=1.5,
                label=f'중앙값 = {med_e:.3f}')

    ax.set_xlabel('효율성 지수')
    ax.set_ylabel('밀도')
    ax.set_title(title)
    ax.legend(fontsize=9)
    ax.set_xlim(0, 1)

    plt.tight_layout()
    return fig, ax


# ─────────────────────────────────────────────────────────────
# 2. 효율성 순위 그래프
# ─────────────────────────────────────────────────────────────
def plot_efficiency_rank(efficiency, labels=None,
                          ci=None, title='효율성 순위',
                          figsize=(10, 5), ax=None,
                          top_n=None):
    """
    효율성 순위 그래프 (Caterpillar plot).

    Parameters
    ----------
    efficiency : (n,) 효율성 값
    labels     : (n,) 레이블 (None → 인덱스)
    ci         : (n, 2) 신뢰구간 [lo, hi] (선택사항)
    title      : str
    figsize    : tuple
    ax         : Axes or None
    top_n      : int, 상위·하위 n개만 표시 (None → 전체)
    """
    _check_mpl()
    eff = np.asarray(efficiency)
    mask = ~np.isnan(eff)
    eff  = eff[mask]

    order = np.argsort(eff)
    eff_s = eff[order]

    if labels is not None:
        labels = np.asarray(labels)[mask][order]
    else:
        labels = order

    if ci is not None:
        ci = np.asarray(ci)[mask][order]

    if top_n is not None:
        half = top_n // 2
        idx  = np.concatenate([np.arange(half),
                                 np.arange(len(eff_s)-half, len(eff_s))])
        eff_s  = eff_s[idx]
        labels = labels[idx]
        if ci is not None:
            ci = ci[idx]

    n = len(eff_s)
    x = np.arange(n)

    if ax is None:
        fig, ax = plt.subplots(figsize=figsize)
    else:
        fig = ax.figure

    ax.scatter(x, eff_s, s=8, color='steelblue', zorder=3)

    if ci is not None:
        lo = ci[:, 0]
        hi = ci[:, 1]
        ax.vlines(x, lo, hi, colors='gray', alpha=0.4, linewidth=0.8)

    ax.axhline(eff_s.mean(), color='firebrick', linestyle='--',
                linewidth=1, label=f'평균={eff_s.mean():.3f}')
    ax.set_xlabel('순위')
    ax.set_ylabel('효율성 지수')
    ax.set_title(title)
    ax.legend(fontsize=9)
    ax.set_ylim(0, 1)
    plt.tight_layout()
    return fig, ax


# ─────────────────────────────────────────────────────────────
# 3. 1D 프론티어 산포도 (Z vs U)
# ─────────────────────────────────────────────────────────────
def plot_frontier_1d(model, dim=0, n_grid=200,
                      title='프론티어 추정 (U vs Z)',
                      figsize=(7, 5), ax=None):
    """
    U vs Z[dim] 산포도와 추정된 프론티어 φ̂(Z).

    Parameters
    ----------
    model : SW2023Model (fit 완료)
    dim   : int  Z의 어느 차원을 x축으로 사용할지
    """
    _check_mpl()

    Z   = model.Z_
    U   = model.U_
    phi = model.phi_hat_
    eff = model.efficiency_

    z_dim = Z[:, dim] if Z.ndim > 1 else Z

    if ax is None:
        fig, ax = plt.subplots(figsize=figsize)
    else:
        fig = ax.figure

    sc = ax.scatter(z_dim, U, c=eff, cmap='RdYlGn',
                     s=8, alpha=0.6, vmin=0, vmax=1)
    plt.colorbar(sc, ax=ax, label='효율성')

    # φ̂ 선
    sort_idx = np.argsort(z_dim)
    ax.plot(z_dim[sort_idx], phi[sort_idx],
             color='navy', linewidth=1.5, label='φ̂(Z)')

    ax.set_xlabel(f'Z[{dim}]')
    ax.set_ylabel('U')
    ax.set_title(title)
    ax.legend(fontsize=9)
    plt.tight_layout()
    return fig, ax


# ─────────────────────────────────────────────────────────────
# 4. 패널 연도별 추이
# ─────────────────────────────────────────────────────────────
def plot_panel_trend(model, time_id, figsize=(8, 5),
                      title='연도별 평균 효율성',
                      ax=None):
    """
    PanelSW2023 결과의 연도별 효율성 추이.

    Parameters
    ----------
    model   : PanelSW2023 (fit 완료)
    time_id : array-like (n,) 기간 ID
    """
    _check_mpl()

    import pandas as pd
    df = pd.DataFrame({
        'time'   : time_id,
        'eff'    : model.efficiency_,
        'te'     : model.eff_transient_,
        'pe'     : model.eff_persistent_,
    }).groupby('time').mean()

    if ax is None:
        fig, ax = plt.subplots(figsize=figsize)
    else:
        fig = ax.figure

    ax.plot(df.index, df['eff'], 'o-', label='전체', color='steelblue')
    ax.plot(df.index, df['te'],  's--', label='일시적', color='tomato')
    ax.plot(df.index, df['pe'],  '^:', label='영구적', color='seagreen')

    ax.set_xlabel('기간')
    ax.set_ylabel('평균 효율성')
    ax.set_title(title)
    ax.legend(fontsize=9)
    ax.set_ylim(0, 1)
    plt.tight_layout()
    return fig, ax


# ─────────────────────────────────────────────────────────────
# 5. 4-component 분해 산포도
# ─────────────────────────────────────────────────────────────
def plot_decomposition(model, figsize=(6, 6),
                        title='일시적 vs 영구적 효율성',
                        ax=None):
    """
    TE vs PE 산포도 (4-component 분해).

    Parameters
    ----------
    model : PanelSW2023 (fit 완료)
    """
    _check_mpl()

    te = model.eff_transient_
    pe = model.eff_persistent_

    if ax is None:
        fig, ax = plt.subplots(figsize=figsize)
    else:
        fig = ax.figure

    ax.scatter(pe, te, s=8, alpha=0.4, color='steelblue')
    ax.axline((0.5, 0.5), slope=1, color='gray',
               linestyle='--', linewidth=0.8, label='TE=PE')

    ax.set_xlabel('영구적 효율성 (PE)')
    ax.set_ylabel('일시적 효율성 (TE)')
    ax.set_title(title)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.legend(fontsize=9)
    plt.tight_layout()
    return fig, ax


# ─────────────────────────────────────────────────────────────
# 6. 종합 대시보드
# ─────────────────────────────────────────────────────────────
def dashboard_crosssection(model, figsize=(12, 8), title='SW(2023) 결과'):
    """
    2-component 모형 종합 대시보드.

    패널:
      [0,0] 효율성 분포
      [0,1] 효율성 순위
      [1,0] Z vs U 산포도
      [1,1] 잔차 분포 (r3 부호 분포)
    """
    _check_mpl()
    fig = plt.figure(figsize=figsize)
    fig.suptitle(title, fontsize=13)

    gs = gridspec.GridSpec(2, 2, figure=fig, hspace=0.4, wspace=0.35)

    # (0,0) 효율성 분포
    ax0 = fig.add_subplot(gs[0, 0])
    plot_efficiency_dist(model.efficiency_, title='효율성 분포', ax=ax0)

    # (0,1) 효율성 순위
    ax1 = fig.add_subplot(gs[0, 1])
    plot_efficiency_rank(model.efficiency_, title='효율성 순위', ax=ax1)

    # (1,0) Z vs U
    ax2 = fig.add_subplot(gs[1, 0])
    plot_frontier_1d(model, dim=0,
                      title='프론티어 추정 (Z[0] vs U)', ax=ax2)

    # (1,1) r3 분포
    ax3 = fig.add_subplot(gs[1, 1])
    r3_vals = model.r3_
    ax3.hist(r3_vals[r3_vals < 0], bins=25, color='steelblue',
              alpha=0.7, label=f'r3<0: {(r3_vals<0).mean()*100:.1f}%',
              density=True)
    ax3.hist(r3_vals[r3_vals >= 0], bins=25, color='tomato',
              alpha=0.7, label=f'r3≥0: {(r3_vals>=0).mean()*100:.1f}%',
              density=True)
    ax3.set_xlabel('r3 (3차 조건부 적률)')
    ax3.set_ylabel('밀도')
    ax3.set_title('r3 부호 분포 (음수가 정상)')
    ax3.legend(fontsize=9)

    return fig
