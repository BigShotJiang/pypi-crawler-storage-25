"""
SW (2023) Step 4-6: 비모수 프론티어 추정
Local Linear Least Squares (LLLS) 기반 추정

추정 순서:
  r̂_1(z) = E[U|Z=z]        → 조건부 평균 (국소 선형 회귀)
  ε̂_i = U_i - r̂_1(Z_i)    → 잔차
  r̂_2(z) = E[ε̂²|Z=z]      → 2차 조건부 적률
  r̂_3(z) = E[ε̂³|Z=z]      → 3차 조건부 적률

성능 최적화 전략:
  1. K_full (n×n) 한 번 계산 → r1, r2, r3에 재사용
  2. XtWX (n, d+1, d+1) 한 번 구성 → 3번 재사용 (K, Z에만 의존)
  3. XtWy는 y만 달라지므로 3번 계산 (K @ y BLAS 연산)
  4. 모든 연산 numpy 행렬 수준 → Python 루프 없음
"""

import numpy as np


def _bandwidth_silverman(Z):
    """
    Silverman 룰 기반 대역폭.
    각 차원 독립적으로 계산 후 곱 커널에 사용.

    h_j = 1.06 * std(Z_j) * n^(-1/(d+4))
    """
    n, d = Z.shape
    h = 1.06 * np.std(Z, axis=0) * n ** (-1.0 / (d + 4))
    h = np.where(h == 0, 1e-6, h)
    return h


def _kernel_weights(Z, z0, h):
    """
    가우시안 곱 커널 가중치 계산 (단일 평가점, 호환성 유지용).

    Parameters
    ----------
    Z  : (n, d)
    z0 : (d,)
    h  : (d,) 대역폭

    Returns
    -------
    w : (n,) 커널 가중치
    """
    diff  = (Z - z0) / h
    log_w = -0.5 * np.sum(diff ** 2, axis=1)
    log_w -= log_w.max()
    return np.exp(log_w)


def _compute_K_full(Z, h, chunk_size=512):
    """
    전체 커널 행렬 K (n×n) 계산.

    K[i,j] = exp(-0.5 × Σ_d ((Z[i,d]-Z[j,d])/h[d])²)

    청크 단위로 계산하여 메모리 사용 제어:
      최대 peak 메모리: chunk × n × d × 8 bytes

    Parameters
    ----------
    Z          : (n, d)
    h          : (d,)
    chunk_size : int

    Returns
    -------
    K : (n, n)  K[i,j] = eval point i에서 data point j의 커널 가중치
    """
    n, d = Z.shape
    K    = np.empty((n, n), dtype=float)
    Zh   = Z / h                          # (n, d) 스케일 조정

    for start in range(0, n, chunk_size):
        end   = min(start + chunk_size, n)
        Z0h   = Zh[start:end]             # (bs, d)

        diff  = Z0h[:, None, :] - Zh[None, :, :]  # (bs, n, d)
        log_K = -0.5 * np.sum(diff ** 2, axis=-1) # (bs, n)
        log_K -= log_K.max(axis=1, keepdims=True)
        K[start:end] = np.exp(log_K)

    return K


def _compute_XtWX_batch(K, Z, ZZT, reg):
    """
    K 행렬로부터 모든 평가점의 XtWX 한 번에 구성.

    XtWX[i] = (X_loc[i]')·diag(K[i])·X_loc[i]
    X_loc[i][j] = [1, Z[j] - Z[i]]

    K, Z에만 의존 → y 무관 → 한 번 계산 후 재사용.

    수식 (K행렬 + 통계량 분해):
      S00[i]           = Σ_j K[i,j]
      cross[i,k]       = Σ_j K[i,j](Z[j,k]-Z[i,k])  = (KZ)[i,k] - S00[i]·Z[i,k]
      block[i,k,l]     = Σ_j K[i,j](Z[j,k]-Z[i,k])(Z[j,l]-Z[i,l])
                       = KZZ[i,k,l] - (KZ[i,k]·Z[i,l]+Z[i,k]·KZ[i,l])
                         + S00[i]·Z[i,k]·Z[i,l]

    Parameters
    ----------
    K   : (n, n)
    Z   : (n, d)
    ZZT : (n, d, d)  Z[j]⊗Z[j] (사전 계산)
    reg : (d+1, d+1) 정칙화 행렬

    Returns
    -------
    XtWX : (n, d+1, d+1)
    """
    n, d = Z.shape

    S00 = K.sum(axis=1)                          # (n,)
    KZ  = K @ Z                                  # (n, d)  — BLAS
    KZZ = np.einsum('ij,jkl->ikl', K, ZZT)      # (n, d, d)

    cross    = KZ - S00[:, None] * Z             # (n, d)
    Z_outer  = np.einsum('ik,il->ikl', Z, Z)     # (n, d, d)
    KZ_ZT    = np.einsum('ik,il->ikl', KZ, Z)    # (n, d, d)
    Z_KZT    = np.einsum('ik,il->ikl', Z, KZ)    # (n, d, d)

    XtWX = np.empty((n, d+1, d+1))
    XtWX[:, 0,  0]  = S00
    XtWX[:, 0,  1:] = cross
    XtWX[:, 1:, 0]  = cross
    XtWX[:, 1:, 1:] = KZZ - KZ_ZT - Z_KZT + S00[:, None, None] * Z_outer
    XtWX += reg

    return XtWX


def _compute_XtWy_batch(K, Z, y):
    """
    K 행렬과 y 벡터로부터 모든 평가점의 XtWy 한 번에 구성.

    XtWy[i, 0]   = Σ_j K[i,j] y[j]                = (K @ y)[i]
    XtWy[i, k+1] = Σ_j K[i,j] (Z[j,k]-Z[i,k]) y[j]
                 = (K @ (Z[:,k]*y))[i] - Z[i,k] * (K @ y)[i]

    Parameters
    ----------
    K : (n, n)
    Z : (n, d)
    y : (n,)

    Returns
    -------
    XtWy : (n, d+1)
    """
    Ky  = K @ y                           # (n,)   — BLAS
    KZy = K @ (Z * y[:, None])           # (n, d) — BLAS

    XtWy = np.empty((K.shape[0], Z.shape[1] + 1))
    XtWy[:, 0]  = Ky
    XtWy[:, 1:] = KZy - Z * Ky[:, None]
    return XtWy


def _llls_from_normal_equations(XtWX, XtWy, y_fallback):
    """
    배치 선형방정식 XtWX @ beta = XtWy 풀기.

    Returns β₀ (intercept) for each eval point.
    """
    try:
        beta = np.linalg.solve(XtWX, XtWy[:, :, np.newaxis])[:, :, 0]
        return beta[:, 0]
    except np.linalg.LinAlgError:
        # 개별 fallback
        n = XtWX.shape[0]
        result = np.full(n, np.nanmean(y_fallback))
        for i in range(n):
            try:
                result[i] = np.linalg.solve(XtWX[i], XtWy[i])[0]
            except np.linalg.LinAlgError:
                pass
        return result


def local_linear(Z, y, h=None, eval_points=None, chunk_size=512,
                 _K_precomputed=None, _XtWX_precomputed=None):
    """
    국소 선형 회귀 (Local Linear Least Squares).

    각 평가점 z0에서:
      min_{β} Σ_j K(Z_j, z0; h) × (y_j - β0 - β1'(Z_j - z0))²

    추정값: m̂(z0) = β̂_0

    Parameters
    ----------
    Z                  : (n, d) 독립변수
    y                  : (n,)   종속변수
    h                  : (d,) 대역폭 (None이면 Silverman)
    eval_points        : (m, d) 평가점 (None이면 Z 자체)
    chunk_size         : int    K 계산 청크 크기
    _K_precomputed     : (n, n) 사전 계산된 K (재사용시)
    _XtWX_precomputed  : (n, d+1, d+1) 사전 계산된 XtWX (재사용시)

    Returns
    -------
    m_hat : (m,) 추정된 조건부 평균
    """
    Z = np.asarray(Z, dtype=float)
    y = np.asarray(y, dtype=float)
    n, d = Z.shape

    if h is None:
        h = _bandwidth_silverman(Z)
    h = np.broadcast_to(np.atleast_1d(h), (d,)).copy()

    # eval_points == Z (self-evaluation)만 최적화 경로 지원
    if eval_points is not None and not np.array_equal(eval_points, Z):
        # eval_points가 Z와 다른 경우: 단순 청크 방식 fallback
        eval_points = np.asarray(eval_points, dtype=float)
        return _local_linear_external(Z, y, h, eval_points, chunk_size)

    reg = 1e-10 * np.eye(d + 1)

    # ── K 계산 (미리 제공된 경우 재사용) ──────────────────────
    if _K_precomputed is not None:
        K = _K_precomputed
    else:
        K = _compute_K_full(Z, h, chunk_size)

    # ── XtWX 계산 (미리 제공된 경우 재사용) ───────────────────
    if _XtWX_precomputed is not None:
        XtWX = _XtWX_precomputed
    else:
        ZZT  = np.einsum('ij,ik->ijk', Z, Z)    # (n, d, d) — 한 번만
        XtWX = _compute_XtWX_batch(K, Z, ZZT, reg)

    # ── XtWy (y에 따라 매번 계산) ─────────────────────────────
    XtWy  = _compute_XtWy_batch(K, Z, y)

    return _llls_from_normal_equations(XtWX, XtWy, y)


def _local_linear_external(Z, y, h, eval_points, chunk_size):
    """eval_points ≠ Z인 경우 청크 방식 fallback."""
    n, d  = Z.shape
    m_pts = len(eval_points)
    m_hat = np.full(m_pts, np.nan)
    reg   = 1e-10 * np.eye(d + 1)
    Zh    = Z / h
    ZZT   = np.einsum('ij,ik->ijk', Z, Z)
    y_mean = np.nanmean(y)

    for start in range(0, m_pts, chunk_size):
        end = min(start + chunk_size, m_pts)
        Z0h = eval_points[start:end] / h
        diff  = Z0h[:, None, :] - Zh[None, :, :]
        log_K = -0.5 * np.sum(diff ** 2, axis=-1)
        log_K -= log_K.max(axis=1, keepdims=True)
        K_bs  = np.exp(log_K)

        XtWX, XtWy = _build_normal_eq_external(K_bs, Z, eval_points[start:end], y, ZZT, reg)
        try:
            beta = np.linalg.solve(XtWX, XtWy[:, :, np.newaxis])[:, :, 0]
            m_hat[start:end] = beta[:, 0]
        except np.linalg.LinAlgError:
            for i in range(end - start):
                try:
                    m_hat[start+i] = np.linalg.solve(XtWX[i], XtWy[i])[0]
                except np.linalg.LinAlgError:
                    m_hat[start+i] = y_mean
    return m_hat


def _build_normal_eq_external(K, Z_data, Z_eval, y, ZZT, reg):
    """eval_points ≠ Z_data인 경우용 XtWX, XtWy 구성."""
    d  = Z_data.shape[1]
    S00 = K.sum(axis=1)
    KZ  = K @ Z_data
    KZZ = np.einsum('ij,jkl->ikl', K, ZZT)
    cross    = KZ - S00[:, None] * Z_eval
    Z0_outer = np.einsum('ik,il->ikl', Z_eval, Z_eval)
    KZ_Z0T   = np.einsum('ik,il->ikl', KZ, Z_eval)
    Z0_KZT   = np.einsum('ik,il->ikl', Z_eval, KZ)
    XtWX = np.empty((K.shape[0], d+1, d+1))
    XtWX[:, 0, 0]   = S00
    XtWX[:, 0, 1:]  = cross
    XtWX[:, 1:, 0]  = cross
    XtWX[:, 1:, 1:] = KZZ - KZ_Z0T - Z0_KZT + S00[:, None, None] * Z0_outer
    XtWX += reg
    Ky  = K @ y
    KZy = K @ (Z_data * y[:, None])
    XtWy = np.empty((K.shape[0], d+1))
    XtWy[:, 0]  = Ky
    XtWy[:, 1:] = KZy - Z_eval * Ky[:, None]
    return XtWX, XtWy


def estimate_moments(Z, U, h=None, bandwidth_method='silverman', chunk_size=512):
    """
    SVKZ/HMS 추정에 필요한 조건부 적률 추정.

    bandwidth_method='silverman' (기본):
      K, XtWX를 한 번 계산 후 r1, r2, r3에 재사용.

    bandwidth_method='loocv' (SW 2023 논문 방식):
      r1, r2, r3 각각에 대해 LOO-CV로 최적 대역폭을 독립적으로 선택.
      → K, XtWX를 3번 계산 (대역폭이 다르므로)

    Parameters
    ----------
    Z                : (n, d) 독립변수
    U                : (n,)   종속변수
    h                : 대역폭 (silverman 모드에서만 사용; None이면 자동)
    bandwidth_method : 'silverman' | 'loocv'
    chunk_size       : int

    Returns
    -------
    dict: r1, r2, r3, eps, h, h_r2, h_r3
    """
    Z = np.asarray(Z, dtype=float)
    U = np.asarray(U, dtype=float)
    n, d = Z.shape

    reg = 1e-10 * np.eye(d + 1)
    ZZT = np.einsum('ij,ik->ijk', Z, Z)   # (n, d, d)

    if bandwidth_method == 'loocv':
        # ── LOO-CV: 각 회귀별 최적 대역폭 독립 선택 ─────────────
        from .bandwidth import bandwidth_loocv

        # Step 1: r1 — U ~ Z
        h_r1  = bandwidth_loocv(Z, U)
        K1    = _compute_K_full(Z, h_r1, chunk_size)
        XtWX1 = _compute_XtWX_batch(K1, Z, ZZT, reg)
        XtWy1 = _compute_XtWy_batch(K1, Z, U)
        r1    = _llls_from_normal_equations(XtWX1, XtWy1, U)
        eps   = U - r1

        # Step 2: r2 — ε̂² ~ Z
        h_r2  = bandwidth_loocv(Z, eps ** 2)
        K2    = _compute_K_full(Z, h_r2, chunk_size)
        XtWX2 = _compute_XtWX_batch(K2, Z, ZZT, reg)
        XtWy2 = _compute_XtWy_batch(K2, Z, eps ** 2)
        r2    = _llls_from_normal_equations(XtWX2, XtWy2, eps ** 2)

        # Step 3: r3 — ε̂³ ~ Z
        h_r3  = bandwidth_loocv(Z, eps ** 3)
        K3    = _compute_K_full(Z, h_r3, chunk_size)
        XtWX3 = _compute_XtWX_batch(K3, Z, ZZT, reg)
        XtWy3 = _compute_XtWy_batch(K3, Z, eps ** 3)
        r3    = _llls_from_normal_equations(XtWX3, XtWy3, eps ** 3)

        return {'r1': r1, 'r2': r2, 'r3': r3, 'eps': eps,
                'h': h_r1, 'h_r2': h_r2, 'h_r3': h_r3}

    else:
        # ── Silverman (기본): K, XtWX 한 번 계산 후 재사용 ───────
        if h is None:
            h = _bandwidth_silverman(Z)
        h = np.broadcast_to(np.atleast_1d(h), (d,)).copy()

        K    = _compute_K_full(Z, h, chunk_size)
        XtWX = _compute_XtWX_batch(K, Z, ZZT, reg)

        XtWy1 = _compute_XtWy_batch(K, Z, U)
        r1    = _llls_from_normal_equations(XtWX, XtWy1, U)
        eps   = U - r1

        XtWy2 = _compute_XtWy_batch(K, Z, eps ** 2)
        r2    = _llls_from_normal_equations(XtWX, XtWy2, eps ** 2)

        XtWy3 = _compute_XtWy_batch(K, Z, eps ** 3)
        r3    = _llls_from_normal_equations(XtWX, XtWy3, eps ** 3)

        return {'r1': r1, 'r2': r2, 'r3': r3, 'eps': eps,
                'h': h, 'h_r2': h, 'h_r3': h}


def compute_leverages(K, Z):
    """
    국소 선형 회귀의 hat-matrix 대각원소 h_ii 계산.

    h_ii = [(XtWX_i)^{-1}]_{00}   (K[i,i]=1 조건 하)

    점근 분산 추정에 사용:
      AVar(r̂(z_i)) ≈ h_ii × σ²(z_i)

    Parameters
    ----------
    K : (n, n) 커널 행렬
    Z : (n, d) 독립변수

    Returns
    -------
    h_ii : (n,) 레버리지 값
    """
    n, d = Z.shape
    reg  = 1e-10 * np.eye(d + 1)
    ZZT  = np.einsum('ij,ik->ijk', Z, Z)
    XtWX = _compute_XtWX_batch(K, Z, ZZT, reg)

    e0 = np.zeros((1, d + 1, 1))
    e0[0, 0, 0] = 1.0
    lev_mat = np.linalg.solve(XtWX, e0)    # (n, d+1, 1)
    return lev_mat[:, 0, 0]                 # (n,)
