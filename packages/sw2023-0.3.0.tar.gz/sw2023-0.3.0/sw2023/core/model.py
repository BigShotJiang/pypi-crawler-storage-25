"""
SW2023Model: 메인 추정 클래스

사용 예시:
    model = SW2023Model(X, Y, direction='mean', method='HMS')
    model.fit()
    print(model.summary())
"""

import numpy as np
import pandas as pd

from .transform  import make_direction, transform, inverse_transform
from .frontier   import estimate_moments, local_linear, compute_leverages, _compute_K_full
from .decompose  import (estimate_sigma_eta, estimate_sigma_eps,
                         estimate_frontier, jlms_efficiency)
from .preprocess import preprocess


class SW2023Model:
    """
    Simar & Wilson (2023) 비모수 다수 산출물 확률변경 모형.

    Parameters
    ----------
    X         : array-like (n, p) 투입물
    Y         : array-like (n, q) 산출물
    direction : 'mean' | 'median' | array (p+q,) 방향벡터
    method    : 'SVKZ' | 'HMS'  비효율성 추정 방법
    h         : 대역폭 (None이면 Silverman 자동 계산)
    """

    def __init__(self, X, Y, direction='mean', method='HMS', h=None,
                 log_transform=True, standardize=True,
                 bandwidth_method='silverman'):
        self.X_raw = np.asarray(X, dtype=float)
        self.Y_raw = np.asarray(Y, dtype=float)
        self.direction_spec  = direction
        self.method          = method
        self.h               = h
        self.log_transform   = log_transform
        self.standardize     = standardize
        self.bandwidth_method = bandwidth_method
        self._fitted = False

    def fit(self, verbose=True):
        """Estimate the SW(2023) nonparametric stochastic frontier model.

        Executes Steps 1--10 of Simar & Wilson (2023): data preprocessing,
        direction-vector rotation, three-moment LLLS regressions with
        LOO-CV bandwidth selection, sigma_eta estimation (SVKZ or HMS),
        frontier recovery, and JLMS individual efficiency scoring.

        Parameters
        ----------
        verbose : bool, default True
            If True, print progress messages during estimation.

        Returns
        -------
        self : SW2023Model
            Fitted model.  Key attributes set after calling fit():

            phi_hat\_ : ndarray, shape (n,)
                Estimated frontier values at each observation.
            efficiency\_ : ndarray, shape (n,)
                JLMS efficiency scores exp(-eta_hat) in (0, 1].
            sigma_eta\_ : ndarray, shape (n,)
                Estimated inefficiency std dev at each observation.
            r1\\_, r2\\_, r3\\_ : ndarray, shape (n,)
                Estimated first, second, and third conditional moments.
            h\\_ : ndarray, shape (n,)
                Hat-matrix leverages for r1 regression (used in CI).
        """
        # 전처리
        self.X, self.Y, self.preprocess_info_ = preprocess(
            self.X_raw, self.Y_raw,
            log_transform=self.log_transform,
            standardize=self.standardize
        )
        X, Y = self.X, self.Y
        n, p = X.shape
        q = Y.shape[1]

        if verbose:
            print(f"SW(2023) 추정 시작: n={n}, p={p}, q={q}, method={self.method}")
            if self.log_transform:
                print(f"  데이터 전처리: 로그 변환 + 표준화" if self.standardize
                      else "  데이터 전처리: 로그 변환")

        # Step 1: 방향벡터
        self.d_ = make_direction(X, Y, method=self.direction_spec)
        self.norm_d_ = np.linalg.norm(self.d_)

        if verbose:
            print(f"  방향벡터 d = {np.round(self.d_, 4)}")

        # Step 2: 회전 변환
        self.Z_, self.U_, self.R_ = transform(X, Y, self.d_)

        if verbose:
            print(f"  회전 변환 완료: Z {self.Z_.shape}, U {self.U_.shape}")

        # Step 3-6: 조건부 적률 추정
        if verbose:
            print(f"  국소 선형 회귀 추정 중 (n={n}개 점, 시간이 걸릴 수 있습니다)...")

        moments = estimate_moments(self.Z_, self.U_, h=self.h,
                                   bandwidth_method=self.bandwidth_method)
        self.r1_   = moments['r1']
        self.r2_   = moments['r2']
        self.r3_   = moments['r3']
        self.eps_  = moments['eps']
        self.h_    = moments['h']
        self.h_r2_ = moments['h_r2']
        self.h_r3_ = moments['h_r3']

        if verbose:
            print(f"  대역폭 h(r1) = {np.round(self.h_, 4)}")
            if self.bandwidth_method == 'loocv':
                print(f"  대역폭 h(r2) = {np.round(self.h_r2_, 4)}")
                print(f"  대역폭 h(r3) = {np.round(self.h_r3_, 4)}")

        # Step 7: σ_η 추정
        self.sigma_eta_ = estimate_sigma_eta(self.r3_, method=self.method)

        # Step 8: σ_ε 추정
        self.sigma_eps_ = estimate_sigma_eps(self.r2_, self.sigma_eta_)

        # Step 9: 프론티어 추정
        self.phi_hat_, self.mu_eta_ = estimate_frontier(
            self.r1_, self.sigma_eta_, self.norm_d_
        )

        # Step 10: JLMS 효율성
        self.efficiency_, self.eta_hat_ = jlms_efficiency(
            self.U_, self.phi_hat_, self.sigma_eta_, self.sigma_eps_
        )

        self._fitted = True

        if verbose:
            print(f"  추정 완료.")
            print(f"  평균 효율성: {np.nanmean(self.efficiency_):.4f}")
            print(f"  wrong skewness 비율: "
                  f"{(self.r3_ > 0).mean()*100:.1f}%")

        return self

    def summary(self):
        """추정 결과 요약."""
        if not self._fitted:
            raise RuntimeError("fit()을 먼저 실행하세요.")

        eff = self.efficiency_
        eta = self.eta_hat_
        s_eta = self.sigma_eta_
        s_eps = self.sigma_eps_

        df = pd.DataFrame({
            'efficiency'  : eff,
            'eta_hat'     : eta,
            'sigma_eta'   : s_eta,
            'sigma_eps'   : s_eps,
            'mu_eta'      : self.mu_eta_,
            'phi_hat'     : self.phi_hat_,
        })

        print("=" * 50)
        print("SW(2023) 추정 결과 요약")
        print("=" * 50)
        print(f"관측치 수 : {len(eff)}")
        print(f"방법      : {self.method}")
        print(f"방향벡터  : {np.round(self.d_, 4)}")
        print(f"대역폭    : {np.round(self.h_, 4)}")
        print()
        print(df[['efficiency', 'eta_hat', 'sigma_eta', 'sigma_eps']].describe().round(4))
        print("=" * 50)

        return df

    def confint_asymptotic(self, alpha=0.05):
        """
        점근 정규 신뢰구간 (SW 2023 CLT + 델타 메서드).

        SW(2023) Eq.(3.8) CLT:
          (nh^{d-1})^{1/2} (r̂_j(z) − r_j(z)) →^L N(0, s²_j(z))

        Hat-matrix 기반 분산 추정:
          AVar(r̂_1(z_i)) ≈ h_ii(r1) × r̂_2(z_i)
          AVar(r̂_3(z_i)) ≈ h_ii(r3) × V̂ar(ε³ | Z=z_i)

        φ̂(z) = r̂_1(z) + ||d|| √(2/π) σ̂_η(z) 델타 메서드:
          ∂φ/∂r1 = 1
          ∂φ/∂r3 = −||d|| √(2/π) / (3 × A3_PLUS × σ̂²_η)   [r3 ≤ 0 경우]

        주의: 점근 CI는 n이 충분히 클 때 유효.
              소표본에는 bootstrap_sw() CI가 더 적합.

        Parameters
        ----------
        alpha : 유의수준 (1-alpha 신뢰구간)

        Returns
        -------
        dict:
            phi_hat_ci  : (n, 2)
            r1_ci       : (n, 2)
            r3_ci       : (n, 2)
            se_phi      : (n,) 표준오차
            se_r1       : (n,)
            se_r3       : (n,)
            alpha       : float
        """
        if not self._fitted:
            raise RuntimeError("fit()을 먼저 실행하세요.")

        from scipy.stats import norm as scipy_norm
        from .decompose import A3_PLUS

        z_crit = float(scipy_norm.ppf(1.0 - alpha / 2))

        # ── r̂_1 레버리지 ──────────────────────────────────────────
        K1   = _compute_K_full(self.Z_, self.h_)
        hii1 = compute_leverages(K1, self.Z_)
        del K1

        var_r1 = hii1 * np.maximum(self.r2_, 1e-15)
        se_r1  = np.sqrt(var_r1)

        # ── r̂_3 레버리지 + 조건부 분산 ────────────────────────────
        K3   = _compute_K_full(self.Z_, self.h_r3_)
        hii3 = compute_leverages(K3, self.Z_)
        del K3

        # Var(ε³|z) 국소 추정: E((ε³ - r̂₃)²|z)
        resid3_sq = (self.eps_ ** 3 - self.r3_) ** 2
        var_eps3  = local_linear(self.Z_, resid3_sq, h=self.h_r3_)
        var_eps3  = np.maximum(var_eps3, 1e-15)

        var_r3 = hii3 * var_eps3
        se_r3  = np.sqrt(var_r3)

        # ── φ̂ 델타 메서드 ─────────────────────────────────────────
        # ∂φ/∂r3 = -||d|| × √(2/π) / (3 × A3_PLUS × σ̂²_η)
        sigma_sq   = np.where(self.sigma_eta_ > 1e-8,
                              self.sigma_eta_ ** 2, np.nan)
        dphi_dr3   = (-self.norm_d_ * np.sqrt(2.0 / np.pi)
                      / (3.0 * A3_PLUS * sigma_sq))
        # wrong skewness 점(σ̂_η 불안정): 기울기 0으로 처리
        dphi_dr3   = np.where(self.r3_ <= 0, dphi_dr3, 0.0)
        dphi_dr3   = np.nan_to_num(dphi_dr3, nan=0.0)

        var_phi = var_r1 + dphi_dr3 ** 2 * var_r3
        se_phi  = np.sqrt(np.maximum(var_phi, 0.0))

        # ── CI 구성 ────────────────────────────────────────────────
        return {
            'phi_hat_ci': np.column_stack([
                self.phi_hat_ - z_crit * se_phi,
                self.phi_hat_ + z_crit * se_phi,
            ]),
            'r1_ci': np.column_stack([
                self.r1_ - z_crit * se_r1,
                self.r1_ + z_crit * se_r1,
            ]),
            'r3_ci': np.column_stack([
                self.r3_ - z_crit * se_r3,
                self.r3_ + z_crit * se_r3,
            ]),
            'se_phi': se_phi,
            'se_r1' : se_r1,
            'se_r3' : se_r3,
            'alpha' : alpha,
        }

    def predict_at(self, Z_eval, U_eval=None):
        """
        학습된 모형으로 새 평가점 Z_eval에서 예측.

        부트스트랩 CI 계산 시 부트스트랩 표본으로 피팅 후
        원래 Z 점에서 평가하는 데 사용.

        Parameters
        ----------
        Z_eval : (m, d) 평가점 (회전 좌표계, 학습 Z와 같은 좌표)
        U_eval : (m,) 관측 방향거리 (있으면 efficiency도 계산)

        Returns
        -------
        dict: phi_hat, sigma_eta, sigma_eps, mu_eta, [efficiency, eta_hat]
        """
        if not self._fitted:
            raise RuntimeError("fit()을 먼저 실행하세요.")

        Z_eval = np.asarray(Z_eval, dtype=float)

        r1 = local_linear(self.Z_, self.U_,       h=self.h_,    eval_points=Z_eval)
        r2 = local_linear(self.Z_, self.eps_**2,  h=self.h_r2_, eval_points=Z_eval)
        r3 = local_linear(self.Z_, self.eps_**3,  h=self.h_r3_, eval_points=Z_eval)

        sigma_eta = estimate_sigma_eta(r3, method=self.method)
        sigma_eps = estimate_sigma_eps(r2, sigma_eta)
        phi_hat, mu_eta = estimate_frontier(r1, sigma_eta, self.norm_d_)

        out = {
            'phi_hat'   : phi_hat,
            'sigma_eta' : sigma_eta,
            'sigma_eps' : sigma_eps,
            'mu_eta'    : mu_eta,
            'r1': r1, 'r2': r2, 'r3': r3,
        }

        if U_eval is not None:
            U_eval = np.asarray(U_eval, dtype=float)
            eff_bc, eta_hat = jlms_efficiency(U_eval, phi_hat, sigma_eta, sigma_eps)
            out['efficiency'] = eff_bc
            out['eta_hat']    = eta_hat

        return out

    def results_dataframe(self):
        """추정 결과를 DataFrame으로 반환."""
        if not self._fitted:
            raise RuntimeError("fit()을 먼저 실행하세요.")
        return pd.DataFrame({
            'U'          : self.U_,
            'phi_hat'    : self.phi_hat_,
            'r1'         : self.r1_,
            'r2'         : self.r2_,
            'r3'         : self.r3_,
            'sigma_eta'  : self.sigma_eta_,
            'sigma_eps'  : self.sigma_eps_,
            'mu_eta'     : self.mu_eta_,
            'eta_hat'    : self.eta_hat_,
            'efficiency' : self.efficiency_,
        })
