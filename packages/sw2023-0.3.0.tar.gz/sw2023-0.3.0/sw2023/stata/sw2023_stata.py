"""
sw2023 Stata 인터페이스 (Stata 16.1+)

Stata 16.1부터 사용 가능한 `python script` 명령으로 실행됩니다.
`sfi` (Stata Function Interface) 모듈을 통해 데이터를 교환합니다.

사용법 (Stata do-file):
    * 횡단면 (2-component)
    local sw_args "x1 x2 x3 | y1 y2 y3 y4 | method=HMS"
    python script "sw2023_stata.py"

    * 패널 (4-component)
    local sw_args "x1 x2 x3 | y1 y2 y3 y4 | method=HMS firm=farmid time=year"
    python script "sw2023_stata.py", args("panel")

출력 변수 (자동 생성):
    횡단면: sw_efficiency, sw_sigma_eta, sw_r1, sw_r3
    패널:   swp_efficiency, swp_te, swp_pe

요구사항:
    - Stata 16.1 이상
    - `python set exec`로 Python 3.8+ 지정
    - sw2023 패키지 설치 (pip install sw2023 또는 경로 설정)
"""

import sys
import os
import numpy as np

# ── sw2023 패키지 경로 자동 탐색 ─────────────────────────────
_this_dir = os.path.dirname(os.path.abspath(__file__))
for _candidate in [
    os.path.dirname(_this_dir),          # 패키지 루트 (sw2023/)
    os.path.dirname(os.path.dirname(_this_dir)),  # 상위 디렉터리
]:
    if _candidate not in sys.path:
        sys.path.insert(0, _candidate)


# ── Stata 16.1 호환 sfi 헬퍼 ──────────────────────────────────
def _sfi_get_data(sfi, varnames):
    """
    Stata 변수를 numpy 배열로 가져옵니다.
    Stata 16/17 공통 방식 사용.
    """
    if isinstance(varnames, str):
        varnames = [varnames]

    n = sfi.Data.getObsTotal()
    result = np.full((n, len(varnames)), np.nan)

    for j, vname in enumerate(varnames):
        vidx = sfi.Data.varIndex(vname)
        if vidx < 0:
            raise ValueError(f"Stata 변수를 찾을 수 없습니다: '{vname}'")
        for i in range(n):
            val = sfi.Data.getAt(vidx, i)
            result[i, j] = val if not sfi.Missing.isMissing(val) else np.nan

    return result.squeeze() if len(varnames) == 1 else result


def _sfi_add_var(sfi, varname, label=''):
    """
    Stata에 새 변수를 추가합니다. 이미 존재하면 재사용.
    Stata 16.1 호환: varIndex() 기반 존재 확인.
    """
    if sfi.Data.varIndex(varname) < 0:
        sfi.Data.addVarDouble(varname)
    # setVarLabel은 Stata 16.1+에서 사용 가능
    try:
        sfi.Data.setVarLabel(varname, label)
    except AttributeError:
        pass  # Stata 버전이 낮은 경우 무시


def _sfi_store(sfi, varname, values, label=''):
    """
    numpy 배열을 Stata 변수에 저장.
    NaN → Stata 결측값 처리.
    """
    _sfi_add_var(sfi, varname, label)
    vidx = sfi.Data.varIndex(varname)
    n    = sfi.Data.getObsTotal()

    for i in range(min(n, len(values))):
        v = values[i]
        if np.isnan(v):
            sfi.Data.storeAt(vidx, i, sfi.Missing.getValue())
        else:
            sfi.Data.storeAt(vidx, i, float(v))


def _sfi_display(sfi, msg):
    """Stata 출력창에 메시지 출력."""
    try:
        sfi.SFIToolkit.displayln(msg)
    except AttributeError:
        # Stata 16.1 이하 fallback
        try:
            sfi.SFIToolkit.display(msg + '\n')
        except Exception:
            pass


# ── 인수 파싱 ─────────────────────────────────────────────────
def _parse_args(args_str):
    """
    'x1 x2 | y1 y2 | key=val key=val' 형식 파싱.

    반환:
        dict: x_vars, y_vars, options
    """
    parts = [p.strip() for p in args_str.split('|')]
    if len(parts) < 2:
        raise ValueError(
            "인수 형식 오류. '|'로 X변수와 Y변수를 구분하세요.\n"
            "예: 'x1 x2 | y1 y2 | method=HMS'"
        )

    x_vars = [v for v in parts[0].split() if v]
    y_vars = [v for v in parts[1].split() if v]

    opts = {}
    if len(parts) >= 3:
        for tok in parts[2].split():
            if '=' in tok:
                k, v = tok.split('=', 1)
                opts[k.strip()] = v.strip()

    # 기본값
    opts.setdefault('method',        'HMS')
    opts.setdefault('direction',     'mean')
    opts.setdefault('log_transform', '1')
    opts.setdefault('standardize',   '1')
    opts.setdefault('verbose',       '0')

    # 타입 변환
    def _bool(s):
        return str(s).strip() not in ('0', 'False', 'false', 'no', 'off')

    opts['log_transform'] = _bool(opts['log_transform'])
    opts['standardize']   = _bool(opts['standardize'])
    opts['verbose']       = _bool(opts['verbose'])

    return {'x_vars': x_vars, 'y_vars': y_vars, 'options': opts}


# ── 횡단면 모형 ───────────────────────────────────────────────
def run_crosssection(args_str=None, sfi=None):
    """
    SW2023Model (2-component) 실행.

    Parameters
    ----------
    args_str : str, optional
        'x1 x2 | y1 y2 | method=HMS'
        None이면 Stata local macro `sw_args`에서 읽음
    sfi : module, optional
    """
    if sfi is None:
        import sfi as _sfi
        sfi = _sfi

    if args_str is None:
        args_str = sfi.Macro.getLocal('sw_args')

    cfg   = _parse_args(args_str)
    x_vars = cfg['x_vars']
    y_vars = cfg['y_vars']
    opt    = cfg['options']

    _sfi_display(sfi,
        f"\n[SW2023] 2-component 모형\n"
        f"  투입물({len(x_vars)}): {' '.join(x_vars)}\n"
        f"  산출물({len(y_vars)}): {' '.join(y_vars)}\n"
        f"  방법: {opt['method']}"
    )

    # 데이터
    X_raw = _sfi_get_data(sfi, x_vars)
    Y_raw = _sfi_get_data(sfi, y_vars)

    if X_raw.ndim == 1: X_raw = X_raw.reshape(-1, 1)
    if Y_raw.ndim == 1: Y_raw = Y_raw.reshape(-1, 1)

    n_total = X_raw.shape[0]
    mask    = (~np.any(np.isnan(X_raw), axis=1) &
               ~np.any(np.isnan(Y_raw), axis=1))
    n_valid = mask.sum()

    if n_valid < n_total:
        _sfi_display(sfi, f"  경고: 결측치 {n_total-n_valid}개 제외 (유효: {n_valid})")

    X = X_raw[mask]
    Y = Y_raw[mask]

    # 추정
    from sw2023.core.model import SW2023Model
    m = SW2023Model(X, Y,
                     direction=opt['direction'],
                     method=opt['method'],
                     log_transform=opt['log_transform'],
                     standardize=opt['standardize'])
    m.fit(verbose=opt['verbose'])

    # 결과 저장
    def _expand(vals):
        out = np.full(n_total, np.nan)
        out[mask] = vals
        return out

    _sfi_store(sfi, 'sw_efficiency', _expand(m.efficiency_),  'SW(2023) 효율성')
    _sfi_store(sfi, 'sw_sigma_eta',  _expand(m.sigma_eta_),   'SW(2023) sigma_eta')
    _sfi_store(sfi, 'sw_r1',         _expand(m.r1_),          'SW(2023) 조건부 1차 적률')
    _sfi_store(sfi, 'sw_r3',         _expand(m.r3_),          'SW(2023) 조건부 3차 적률')

    _sfi_display(sfi,
        f"\n  평균 효율성: {np.nanmean(m.efficiency_):.4f}\n"
        f"  생성 변수: sw_efficiency, sw_sigma_eta, sw_r1, sw_r3\n"
        f"  완료."
    )
    return m


# ── 패널 모형 ─────────────────────────────────────────────────
def run_panel(args_str=None, sfi=None):
    """
    PanelSW2023 (4-component) 실행.

    options에 firm=<변수명>, time=<변수명>으로 ID 지정.
    """
    if sfi is None:
        import sfi as _sfi
        sfi = _sfi

    if args_str is None:
        args_str = sfi.Macro.getLocal('sw_args')

    cfg    = _parse_args(args_str)
    x_vars = cfg['x_vars']
    y_vars = cfg['y_vars']
    opt    = cfg['options']

    firm_var = opt.get('firm', 'firmid')
    time_var = opt.get('time', 'year')

    _sfi_display(sfi,
        f"\n[SW2023] 4-component 패널 모형\n"
        f"  투입물({len(x_vars)}): {' '.join(x_vars)}\n"
        f"  산출물({len(y_vars)}): {' '.join(y_vars)}\n"
        f"  개체: {firm_var}, 기간: {time_var}\n"
        f"  방법: {opt['method']}"
    )

    # 데이터
    X_raw   = _sfi_get_data(sfi, x_vars)
    Y_raw   = _sfi_get_data(sfi, y_vars)
    firm_id = _sfi_get_data(sfi, firm_var)
    time_id = _sfi_get_data(sfi, time_var)

    if X_raw.ndim == 1: X_raw = X_raw.reshape(-1, 1)
    if Y_raw.ndim == 1: Y_raw = Y_raw.reshape(-1, 1)

    n_total = X_raw.shape[0]
    mask    = (~np.any(np.isnan(X_raw), axis=1) &
               ~np.any(np.isnan(Y_raw), axis=1) &
               ~np.isnan(firm_id) & ~np.isnan(time_id))

    X       = X_raw[mask]
    Y       = Y_raw[mask]
    firm_id = firm_id[mask].astype(int)
    time_id = time_id[mask].astype(int)

    # 추정
    from sw2023.panel.four_component import PanelSW2023
    m = PanelSW2023(X, Y, firm_id, time_id,
                     direction=opt['direction'],
                     method=opt['method'],
                     log_transform=opt['log_transform'],
                     standardize=opt['standardize'])
    m.fit(verbose=opt['verbose'])

    # 결과 저장
    def _expand(vals):
        out = np.full(n_total, np.nan)
        out[mask] = vals
        return out

    _sfi_store(sfi, 'swp_efficiency', _expand(m.efficiency_),     'SW(2023) 전체 효율성')
    _sfi_store(sfi, 'swp_te',         _expand(m.eff_transient_),  'SW(2023) 일시적 효율성')
    _sfi_store(sfi, 'swp_pe',         _expand(m.eff_persistent_), 'SW(2023) 영구적 효율성')

    _sfi_display(sfi,
        f"\n  전체 효율성:   {np.nanmean(m.efficiency_):.4f}\n"
        f"  일시적 효율성: {np.nanmean(m.eff_transient_):.4f}\n"
        f"  영구적 효율성: {np.nanmean(m.eff_persistent_):.4f}\n"
        f"  생성 변수: swp_efficiency, swp_te, swp_pe\n"
        f"  완료."
    )
    return m


# ── 진입점 ───────────────────────────────────────────────────
if __name__ == '__main__':
    try:
        import sfi

        mode = sys.argv[1] if len(sys.argv) > 1 else 'cross'
        if mode == 'panel':
            run_panel(sfi=sfi)
        else:
            run_crosssection(sfi=sfi)

    except ImportError:
        print("Stata sfi 모듈을 찾을 수 없습니다.")
        print("이 스크립트는 Stata 16.1 이상 환경에서 실행해야 합니다.")
        print("\nStata do-file 예시:")
        print('  python set exec "/usr/local/bin/python3"')
        print('  local sw_args "x1 x2 | y1 y2 | method=HMS"')
        print('  python script "sw2023_stata.py"')
