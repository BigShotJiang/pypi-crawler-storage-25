"""
sw2023: Simar & Wilson (2023) 비모수 다수 산출물 확률변경 분석

참고 문헌:
  Simar, L., Wilson, P.W. (2023). Nonparametric, Econometric Analysis of
  Production, Cost, Revenue and Profit Functions.
  Econometric Reviews, 42(4), 1391-1403.

주요 클래스:
  SW2023Model   - 횡단면 모형 (2-component: v, η)
  PanelSW2023   - 패널 확장 (4-component: v_it, u_it, α_i, μ_i)

보조 함수:
  bootstrap_sw, bootstrap_panel  - 부트스트랩 신뢰구간
  bandwidth_loocv                - LOO-CV 대역폭 선택 (SW 2023 논문 방식)
  bandwidth_silverman            - Silverman 규칙 대역폭
"""

from .core.model           import SW2023Model
from .panel.four_component import PanelSW2023
from .core.bootstrap       import bootstrap_sw, bootstrap_panel, test_r3_significance
from .core.bandwidth       import bandwidth_loocv, bandwidth_silverman

__version__ = '0.3.0'
__author__  = 'SW2023 Python Package'
__all__     = [
    'SW2023Model',
    'PanelSW2023',
    'bootstrap_sw',
    'bootstrap_panel',
    'test_r3_significance',
    'bandwidth_loocv',
    'bandwidth_silverman',
]
