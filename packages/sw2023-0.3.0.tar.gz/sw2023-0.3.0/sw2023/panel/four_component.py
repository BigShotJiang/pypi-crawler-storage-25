"""
4-Component Panel Stochastic Frontier Model
SW(2023) 회전 변환 + Colombi et al.(2014) / Parmeter & Kumbhakar(2025) 4성분 분해

모형 구조:
  U_it = φ(Z_it) + ||d||·v_it - ||d||·u_it + ||d||·α_i - ||d||·μ_i

  v_it  ~ N(0, σ_v²(Z_it))     : 일시적 노이즈 (시변, 대칭)
  u_it  ~ N⁺(0, σ_u²(Z_it))    : 일시적 비효율성 (시변, 단측)
  α_i   ~ N(0, σ_α²)            : 개인 이질성 (시불변, 대칭)
  μ_i   ~ N⁺(0, σ_μ²)           : 영구적 비효율성 (시불변, 단측)

식별 전략 (Colombi et al. 2014 / Parmeter & Kumbhakar 2025):
  - 개체 내(within) 변동   → 일시적 성분 (v_it, u_it) 식별
  - 개체 간(between) 변동  → 영구적 성분 (α_i, μ_i) 식별

추정 절차:
  Step 1: 풀링된 LLLS로 φ̂(Z_it) 추정 → 잔차 ε̂_it
  Step 2: 개체 내 잔차(w_it) / 개체 간 잔차(b_i) 분리
  Step 3: w_it의 3차 적률 → σ̂_u (일시적 비효율)
  Step 4: b_i의 3차 적률  → σ̂_μ (영구적 비효율)
  Step 5: JLMS 방식으로 개별 효율성 지수 계산
"""

import numpy as np
import pandas as pd
from scipy.stats import norm as scipy_norm

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from core.transform  import make_direction, transform
from core.frontier   import estimate_moments, local_linear, _bandwidth_silverman
from core.decompose  import (A3_PLUS, A3_MINUS,
                              estimate_sigma_eta, estimate_sigma_eps,
                              estimate_frontier)
from core.preprocess import preprocess

PI = np.pi


# ─────────────────────────────────────────────────────────────
# 헬퍼: JLMS 효율성 (범용)
# ─────────────────────────────────────────────────────────────
def _jlms(composite_resid, sigma_u, sigma_v):
    """
    JLMS 방식 조건부 기대 비효율성.

    E[u | ε] = μ* + σ* × φ(μ*/σ*) / Φ(μ*/σ*)
    여기서 ε = v - u, μ* = -ε·σ_u²/(σ_u²+σ_v²), σ*² = σ_u²σ_v²/(σ_u²+σ_v²)

    Edge case 처리:
      - σ_u = σ_v = 0: u_hat = 0
      - σ_v = 0 (σ_u > 0): σ* = 0 → E[u|ε] = max(0, -ε)
      - σ_u = 0 (σ_v > 0): E[u|ε] = 0

    Parameters
    ----------
    composite_resid : (n,)  ε̂ = v - u (또는 b_i = α_i - μ_i)
    sigma_u         : (n,)  σ_u (단측 성분 표준편차)
    sigma_v         : (n,)  σ_v (양측 성분 표준편차)

    Returns
    -------
    eff  : (n,) exp(-E[u|ε]) ∈ (0,1]
    u_hat: (n,) E[u|ε]
    """
    eps  = np.asarray(composite_resid, dtype=float)
    su   = np.asarray(sigma_u, dtype=float)
    sv   = np.asarray(sigma_v, dtype=float)
    su2  = su ** 2
    sv2  = sv ** 2
    s2   = su2 + sv2

    # Case 1: σ_u = σ_v = 0 → u_hat = 0
    # Case 2: σ_v = 0, σ_u > 0 → σ* = 0, E[u|ε] = max(0, -ε)
    # Case 3: σ_u = 0, σ_v > 0 → E[u|ε] = 0
    # Case 4: 일반적인 경우

    u_hat = np.zeros_like(eps)

    # Case 2: sigma_v ≈ 0, sigma_u > 0
    case2 = (sv < 1e-10) & (su > 1e-10)
    u_hat[case2] = np.maximum(0.0, -eps[case2])

    # Case 4: 일반적인 경우 (su > 0, sv > 0)
    case4 = (su > 1e-10) & (sv > 1e-10)
    if case4.any():
        s2_4   = s2[case4]
        mu_s   = -eps[case4] * su2[case4] / s2_4
        sig_s  = np.sqrt(su2[case4] * sv2[case4] / s2_4)
        ratio  = mu_s / sig_s
        pdf_r  = scipy_norm.pdf(ratio)
        cdf_r  = np.maximum(scipy_norm.cdf(ratio), 1e-15)
        u_hat[case4] = np.maximum(0.0, mu_s + sig_s * pdf_r / cdf_r)

    eff = np.exp(-u_hat)
    return eff, u_hat


# ─────────────────────────────────────────────────────────────
# 메인 클래스
# ─────────────────────────────────────────────────────────────
class PanelSW2023:
    """
    4-Component Panel SFA with SW(2023) Rotation Transformation.

    Parameters
    ----------
    X          : (n, p)  투입물
    Y          : (n, q)  산출물
    firm_id    : (n,)    개체 식별자 (농가ID 등)
    time_id    : (n,)    시간 식별자 (연도 등)
    direction  : 'mean' | 'median' | array  방향벡터
    method     : 'SVKZ' | 'HMS'
    h          : 대역폭 (None = Silverman)
    log_transform : bool
    standardize   : bool
    """

    def __init__(self, X, Y, firm_id, time_id,
                 direction='mean', method='HMS', h=None,
                 log_transform=True, standardize=True):
        self.X_raw     = np.asarray(X, dtype=float)
        self.Y_raw     = np.asarray(Y, dtype=float)
        self.firm_id   = np.asarray(firm_id)
        self.time_id   = np.asarray(time_id)
        self.direction_spec = direction
        self.method    = method
        self.h         = h
        self.log_transform = log_transform
        self.standardize   = standardize
        self._fitted   = False

    # ── 추정 메인 ──────────────────────────────────────────────
    def fit(self, verbose=True):
        """4-component 모형 추정."""

        # 0. 전처리
        self.X, self.Y, self.preprocess_info_ = preprocess(
            self.X_raw, self.Y_raw,
            log_transform=self.log_transform,
            standardize=self.standardize
        )
        X, Y = self.X, self.Y
        n, p = X.shape
        q    = Y.shape[1]

        firms  = self.firm_id
        times  = self.time_id
        uniq_firms = np.unique(firms)
        N = len(uniq_firms)
        T_vec = np.array([np.sum(firms == f) for f in uniq_firms])

        if verbose:
            print(f"4-Component Panel SW(2023) 추정 시작")
            print(f"  n={n}, p={p}, q={q}, N={N}개 개체, "
                  f"평균 T={T_vec.mean():.1f}")
            print(f"  method={self.method}")

        # 1. 방향벡터 + 회전 변환
        self.d_ = make_direction(X, Y, method=self.direction_spec)
        self.norm_d_ = np.linalg.norm(self.d_)
        self.Z_, self.U_, self.R_ = transform(X, Y, self.d_)

        if verbose:
            print(f"  방향벡터 d = {np.round(self.d_, 3)}")
            print(f"  Z shape: {self.Z_.shape}")

        # 2. 풀링 LLLS → φ̂(Z_it), 복합 잔차 ε̂_it
        if verbose:
            print(f"  [Step 1] 풀링 LLLS 추정 중...")
        moments = estimate_moments(self.Z_, self.U_, h=self.h)
        self.r1_   = moments['r1']
        self.h_    = moments['h']
        eps_hat    = moments['eps']   # ε̂_it = U_it - r̂_1(Z_it)

        # 3. Within / Between 분리
        if verbose:
            print(f"  [Step 2] 개체 내(within) / 개체 간(between) 분리...")

        # 개체별 평균 잔차 (between: b_i)
        eps_mean_firm = np.zeros(n)
        for f in uniq_firms:
            mask = firms == f
            eps_mean_firm[mask] = eps_hat[mask].mean()

        # Within 잔차 (일시적 성분)
        w_it = eps_hat - eps_mean_firm    # (n,)  일시적: v_it - u_it (centered)

        # Between 잔차 (영구적 성분) - 개체별 1개 값
        firm_idx   = {f: i for i, f in enumerate(uniq_firms)}
        b_i_vals   = np.array([eps_hat[firms == f].mean() for f in uniq_firms])
        # 개체별 Z 평균 (between에서 사용할 보조변수)
        Z_mean_firm = np.array([self.Z_[firms == f].mean(axis=0)
                                 for f in uniq_firms])

        # 4. 일시적 성분: w_it의 3차 적률 → σ̂_u(z)
        if verbose:
            print(f"  [Step 3] 일시적 비효율성 추정 (within)...")

        r2_w = local_linear(self.Z_, w_it ** 2, h=self.h_)
        r3_w = local_linear(self.Z_, w_it ** 3, h=self.h_)

        self.sigma_u_ = estimate_sigma_eta(r3_w, method=self.method)
        self.sigma_v_ = estimate_sigma_eps(r2_w, self.sigma_u_)

        # 5. 영구적 성분: b_i의 3차 적률 → σ̂_μ(z̄_i)
        if verbose:
            print(f"  [Step 4] 영구적 비효율성 추정 (between)...")

        h_between = _bandwidth_silverman(Z_mean_firm) if self.h is None else self.h_

        r2_b = local_linear(Z_mean_firm, b_i_vals ** 2, h=h_between)
        r3_b = local_linear(Z_mean_firm, b_i_vals ** 3, h=h_between)

        self.sigma_mu_firm_  = estimate_sigma_eta(r3_b, method=self.method)
        self.sigma_alp_firm_ = estimate_sigma_eps(r2_b, self.sigma_mu_firm_)

        # 개체별 값을 관측치 수준으로 확장
        sigma_mu_n  = np.array([self.sigma_mu_firm_[firm_idx[f]]
                                 for f in firms])
        sigma_alp_n = np.array([self.sigma_alp_firm_[firm_idx[f]]
                                 for f in firms])
        b_i_n = np.array([b_i_vals[firm_idx[f]] for f in firms])

        # 6. 프론티어 추정
        #    r̂_1(z) = φ(z) - ||d||(μ_u + μ_μ)
        #    φ̂(z)   = r̂_1(z) + ||d||·(μ_u(z) + μ_μ(z))
        mu_u_n  = np.sqrt(2 / PI) * self.sigma_u_    # 일시적 평균 비효율
        mu_mu_n = np.sqrt(2 / PI) * sigma_mu_n       # 영구적 평균 비효율
        self.phi_hat_ = self.r1_ + self.norm_d_ * (mu_u_n + mu_mu_n)

        # 7. JLMS 효율성 지수
        if verbose:
            print(f"  [Step 5] JLMS 효율성 지수 계산...")

        # 일시적 효율성: TE_it = exp(-u_it)
        self.eff_transient_, self.u_hat_ = _jlms(
            w_it, self.sigma_u_, self.sigma_v_
        )

        # 영구적 효율성: PE_i = exp(-μ_i)  (개체수준 → 관측치 확장)
        pe_firm, mu_hat_firm = _jlms(
            b_i_vals, self.sigma_mu_firm_, self.sigma_alp_firm_
        )
        self.eff_persistent_ = np.array([pe_firm[firm_idx[f]] for f in firms])
        self.mu_hat_         = np.array([mu_hat_firm[firm_idx[f]] for f in firms])

        # 전체 효율성: OE_it = TE_it × PE_i
        self.efficiency_ = self.eff_transient_ * self.eff_persistent_

        # 부가 정보 저장
        self.eps_hat_    = eps_hat
        self.w_it_       = w_it
        self.b_i_n_      = b_i_n
        self.uniq_firms_ = uniq_firms
        self._fitted     = True

        if verbose:
            print(f"  추정 완료.")
            print(f"  평균 전체 효율성    : {np.nanmean(self.efficiency_):.4f}")
            print(f"  평균 일시적 효율성  : {np.nanmean(self.eff_transient_):.4f}")
            print(f"  평균 영구적 효율성  : {np.nanmean(self.eff_persistent_):.4f}")
            ws_w = (r3_w > 0).mean() * 100
            ws_b = (r3_b > 0).mean() * 100
            print(f"  Wrong skewness(within)  : {ws_w:.1f}%")
            print(f"  Wrong skewness(between) : {ws_b:.1f}%")

        return self

    # ── 결과 요약 ──────────────────────────────────────────────
    def summary(self):
        """추정 결과 요약 출력 및 DataFrame 반환."""
        if not self._fitted:
            raise RuntimeError("fit()을 먼저 실행하세요.")

        print("=" * 55)
        print("4-Component Panel SW(2023) 추정 결과")
        print("=" * 55)
        print(f"관측치: {len(self.efficiency_)}, "
              f"개체: {len(self.uniq_firms_)}")
        print(f"방법: {self.method}")

        df = pd.DataFrame({
            'firm_id'        : self.firm_id,
            'time_id'        : self.time_id,
            'U'              : self.U_,
            'phi_hat'        : self.phi_hat_,
            'efficiency'     : self.efficiency_,
            'eff_transient'  : self.eff_transient_,
            'eff_persistent' : self.eff_persistent_,
            'u_hat'          : self.u_hat_,
            'mu_hat'         : self.mu_hat_,
            'sigma_u'        : self.sigma_u_,
            'sigma_mu'       : self.b_i_n_,
        })

        for col in ['efficiency', 'eff_transient', 'eff_persistent']:
            vals = df[col]
            print(f"\n{col}:")
            print(f"  평균={vals.mean():.4f}  중앙={vals.median():.4f}  "
                  f"std={vals.std():.4f}  "
                  f"[{vals.min():.4f}, {vals.max():.4f}]")

        print("=" * 55)
        return df

    def results_dataframe(self):
        """전체 결과를 DataFrame으로 반환."""
        if not self._fitted:
            raise RuntimeError("fit()을 먼저 실행하세요.")
        return pd.DataFrame({
            'firm_id'        : self.firm_id,
            'time_id'        : self.time_id,
            'U'              : self.U_,
            'phi_hat'        : self.phi_hat_,
            'eps_hat'        : self.eps_hat_,
            'w_it'           : self.w_it_,
            'sigma_u'        : self.sigma_u_,
            'sigma_v'        : self.sigma_v_,
            'u_hat'          : self.u_hat_,
            'mu_hat'         : self.mu_hat_,
            'efficiency'     : self.efficiency_,
            'eff_transient'  : self.eff_transient_,
            'eff_persistent' : self.eff_persistent_,
        })
