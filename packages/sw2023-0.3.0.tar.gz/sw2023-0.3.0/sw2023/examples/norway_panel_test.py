"""
Norway 농업 패널 데이터: 4-Component Panel SW(2023) 테스트

비교:
  - SW2023Model    : 기본 횡단면 (2-component)
  - PanelSW2023   : 4-component 패널 (일시적 + 영구적 비효율)
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

import numpy as np
import pandas as pd
import time
from sw2023 import SW2023Model, PanelSW2023

# ── 데이터 로드 ────────────────────────────────────────────────
df = pd.read_stata('/Users/mac/Documents/msfa/sfbook_data/norway.dta')
df = df.sort_values(['farmid', 'year']).reset_index(drop=True)

input_vars  = ['x1', 'x2', 'x3', 'x4', 'x5', 'x6']
output_vars = ['y1', 'y2', 'y3', 'y4']

X       = df[input_vars].values.astype(float)
Y       = df[output_vars].values.astype(float)
firm_id = df['farmid'].values
time_id = df['year'].values

print(f"데이터: n={len(df)}, 농가={df['farmid'].nunique()}, "
      f"연도={df['year'].min()}~{df['year'].max()}")
print()

# ══════════════════════════════════════════════════════════════
# 모형 1: 기본 SW(2023) — 2-component
# ══════════════════════════════════════════════════════════════
print("▶ 모형 1: SW(2023) 기본 모형 (2-component)")
t0 = time.time()
m1 = SW2023Model(X, Y, method='HMS')
m1.fit(verbose=True)
print(f"  소요시간: {time.time()-t0:.1f}초\n")

# ══════════════════════════════════════════════════════════════
# 모형 2: 4-Component Panel SW
# ══════════════════════════════════════════════════════════════
print("▶ 모형 2: 4-Component Panel SW")
t0 = time.time()
m2 = PanelSW2023(X, Y, firm_id, time_id, method='HMS')
m2.fit(verbose=True)
print(f"  소요시간: {time.time()-t0:.1f}초\n")

# ══════════════════════════════════════════════════════════════
# 결과 비교
# ══════════════════════════════════════════════════════════════
print("=" * 60)
print("모형 비교")
print("=" * 60)

res2 = m2.summary()

print("\n[2-component vs. 4-component 전체 효율성 비교]")
comp = pd.DataFrame({
    '2comp_eff' : m1.efficiency_,
    '4comp_eff' : m2.efficiency_,
    '4comp_TE'  : m2.eff_transient_,
    '4comp_PE'  : m2.eff_persistent_,
    'year'      : time_id,
    'farmid'    : firm_id,
})
print(comp[['2comp_eff','4comp_eff','4comp_TE','4comp_PE']].describe().round(4))

print("\n[연도별 평균 효율성]")
yearly = comp.groupby('year')[['2comp_eff','4comp_eff','4comp_TE','4comp_PE']].mean()
print(yearly.round(4))

print("\n[영구적 비효율: 최하위/최상위 10개 농가]")
firm_pe = comp.groupby('farmid')['4comp_PE'].mean().sort_values()
print("최하위 (가장 비효율):")
print(firm_pe.head(5).round(4))
print("최상위 (가장 효율):")
print(firm_pe.tail(5).round(4))
