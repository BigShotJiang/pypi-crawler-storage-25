"""
Norway 농업 패널 데이터로 SW(2023) 기본 모형 테스트.

데이터: Kumbhakar, Wang & Horncastle (2015) 교재 norway.dta
  - 산출물 4개: y1, y2, y3, y4
  - 투입물 6개: x1 ~ x6
  - 패널: 460 농가 × 최대 9년 (1998-2006)
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

import numpy as np
import pandas as pd
from sw2023 import SW2023Model

# ── 데이터 로드 ────────────────────────────────────────────
DATA_PATH = '/Users/mac/Documents/msfa/sfbook_data/norway.dta'
df = pd.read_stata(DATA_PATH)

print(f"데이터 크기: {df.shape}")
print(f"농가 수: {df['farmid'].nunique()}, 연도: {df['year'].min()}~{df['year'].max()}")
print()

# ── 변수 선택 ──────────────────────────────────────────────
input_vars  = ['x1', 'x2', 'x3', 'x4', 'x5', 'x6']
output_vars = ['y1', 'y2', 'y3', 'y4']

X = df[input_vars].values.astype(float)
Y = df[output_vars].values.astype(float)

print(f"투입물: {input_vars}")
print(f"산출물: {output_vars}")
print()

# ── 소규모 테스트 (첫 200개 관측치) ────────────────────────
print("=== 소규모 테스트 (n=200) ===")
n_test = 200
X_small = X[:n_test]
Y_small = Y[:n_test]

model = SW2023Model(
    X_small, Y_small,
    direction='mean',
    method='HMS'
)
model.fit(verbose=True)

results = model.summary()

# 효율성 분포 확인
eff = model.efficiency_
print(f"\n효율성 분포:")
print(f"  최솟값: {eff.min():.4f}")
print(f"  25%   : {np.percentile(eff, 25):.4f}")
print(f"  중앙값: {np.median(eff):.4f}")
print(f"  75%   : {np.percentile(eff, 75):.4f}")
print(f"  최댓값: {eff.max():.4f}")
print(f"  평균  : {eff.mean():.4f}")
