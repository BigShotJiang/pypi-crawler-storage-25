"""
Monte Carlo 검증 (Validation)

목적: 알려진 DGP(Data Generating Process)에서 데이터를 생성하고
      추정량이 참값을 얼마나 잘 복원하는지 확인.

DGP 설계:
  - 생산기술: Cobb-Douglas (다수 투입물, 다수 산출물)
  - 2-component: y = f(x) + v - u
  - 4-component: y = f(x) + α_i + v_it - u_it - μ_i

검증 기준:
  1. 평균 효율성 편향 (Bias)
  2. 효율성 순위 상관 (Spearman rank correlation)
  3. RMSE (root mean squared error)
  4. 잔차 왜도 방향 (r3 < 0 비율)
  5. σ_η 추정 정확도

참고:
  SW(2023) Appendix F: Monte Carlo 실험 설계
  Parmeter & Kumbhakar(2025): 4-component 검증
"""

import numpy as np
import pandas as pd
from scipy.stats import spearmanr, halfnorm
from scipy.linalg import null_space


# ─────────────────────────────────────────────────────────────
# DGP 생성 함수
# ─────────────────────────────────────────────────────────────

def dgp_2component(n=500, p=2, q=2, seed=42,
                   sigma_v=0.2, sigma_u=0.3,
                   alpha_inputs=None, alpha_outputs=None):
    """
    2-component DGP: 다수 투입물 + 다수 산출물 Cobb-Douglas.

    생산기술:
      각 산출물 m: ln(y_m) = Σ_j α_mj × ln(x_j) + v - u_m

    실제로는 산출물 거리함수를 사용:
      ln D_O(x,y) = -ln(y1) - α × Σ_m ln(y_m/y1) - β × Σ_j ln(x_j)
    여기서 정규화: y1을 기준으로 IDF 공식 적용

    간단한 DGP (SW 2023 Appendix F 방식):
      프론티어: (x-1)'(x-1) + y'y = 1 (구의 표면)
      + noise ε ~ N(0, σ_v²)
      - ineff η ~ N⁺(0, σ_u²)

    Parameters
    ----------
    n            : 표본 크기
    p            : 투입물 수
    q            : 산출물 수
    sigma_v      : 노이즈 표준편차
    sigma_u      : 비효율성 표준편차
    alpha_inputs : (p,) 투입 탄력성 (None=균등)
    alpha_outputs: (q,) 산출 탄력성 (None=균등)

    Returns
    -------
    dict:
        X, Y         : 관측 데이터
        X_true, Y_true: 프론티어 위 데이터
        u_true       : 진짜 비효율성
        eff_true     : 진짜 효율성 exp(-u)
        sigma_u, sigma_v : 사용된 모수
    """
    rng = np.random.default_rng(seed)

    # 투입 탄력성
    if alpha_inputs is None:
        alpha_inputs = np.ones(p) / p       # 균등
    if alpha_outputs is None:
        alpha_outputs = np.ones(q) / q      # 균등

    # 투입물 생성: log-normal (mean=1 in log space → non-zero direction vector)
    ln_X = rng.normal(1.0, 0.5, size=(n, p))
    X    = np.exp(ln_X)

    # 산출물 프론티어: Cobb-Douglas
    # ln(y_m*) = α_m × Σ_j β_j × ln(x_j)  (균등 탄력성)
    ln_X_weighted = ln_X @ alpha_inputs.reshape(-1, 1)  # (n, 1)
    ln_Y_true = ln_X_weighted * alpha_outputs.reshape(1, -1)  # (n, q)
    Y_true = np.exp(ln_Y_true)

    # 비효율성: η ~ N⁺(0, σ_u²)
    u_true = halfnorm.rvs(scale=sigma_u, size=n, random_state=rng)

    # 노이즈: ε ~ N(0, σ_v²)
    v = rng.normal(0, sigma_v, size=(n, q))

    # 관측 산출물: 비효율 → 산출물 감소
    ln_Y_obs = ln_Y_true - u_true.reshape(-1, 1) + v
    Y_obs    = np.exp(ln_Y_obs)

    eff_true = np.exp(-u_true)

    return {
        'X'        : X,
        'Y'        : Y_obs,
        'X_true'   : X,
        'Y_true'   : Y_true,
        'u_true'   : u_true,
        'eff_true' : eff_true,
        'sigma_u'  : sigma_u,
        'sigma_v'  : sigma_v,
        'p': p, 'q': q, 'n': n,
    }


def dgp_4component(N=100, T=5, p=2, q=2, seed=42,
                   sigma_v=0.15, sigma_u=0.20,
                   sigma_alpha=0.10, sigma_mu=0.20,
                   alpha_inputs=None, alpha_outputs=None):
    """
    4-component 패널 DGP.

    U_it = φ(Z_it) + v_it - u_it + α_i - μ_i

    v_it   ~ N(0, σ_v²)     : 일시적 노이즈
    u_it   ~ N⁺(0, σ_u²)    : 일시적 비효율
    α_i    ~ N(0, σ_α²)     : 개인 이질성
    μ_i    ~ N⁺(0, σ_μ²)    : 영구적 비효율

    Parameters
    ----------
    N, T : 개체 수, 기간 수
    p, q : 투입물 수, 산출물 수
    sigma_v, sigma_u, sigma_alpha, sigma_mu : 표준편차

    Returns
    -------
    dict: X, Y, firm_id, time_id, 진짜 효율성 성분들
    """
    rng = np.random.default_rng(seed)
    n   = N * T

    if alpha_inputs is None:
        alpha_inputs = np.ones(p) / p
    if alpha_outputs is None:
        alpha_outputs = np.ones(q) / q

    # 개인별 고정 성분
    alpha_i = rng.normal(0, sigma_alpha, size=N)
    mu_i    = halfnorm.rvs(scale=sigma_mu, size=N, random_state=rng)

    # 관측치 생성
    X_list, Y_list = [], []
    firm_ids, time_ids = [], []
    u_list, v_list = [], []
    eff_t_list, eff_p_list = [], []

    for i in range(N):
        for t in range(T):
            # 투입물 (mean=1 in log space → non-zero direction vector)
            ln_x = rng.normal(1.0, 0.5, size=p)
            x    = np.exp(ln_x)

            # 프론티어 산출물
            ln_y_star = (ln_x @ alpha_inputs) * alpha_outputs

            # 일시적 성분
            u_it = halfnorm.rvs(scale=sigma_u, random_state=rng)
            v_it = rng.normal(0, sigma_v, size=q)

            # 관측 산출물
            ln_y = ln_y_star + alpha_i[i] - u_it - mu_i[i] + v_it
            y    = np.exp(ln_y)

            X_list.append(x)
            Y_list.append(y)
            firm_ids.append(i)
            time_ids.append(t)
            u_list.append(u_it)
            eff_t_list.append(np.exp(-u_it))
            eff_p_list.append(np.exp(-mu_i[i]))

    X       = np.array(X_list)
    Y       = np.array(Y_list)
    firm_id = np.array(firm_ids)
    time_id = np.array(time_ids)
    u_arr   = np.array(u_list)
    eff_t   = np.array(eff_t_list)
    eff_p   = np.array([np.exp(-mu_i[f]) for f in firm_id])
    eff_all = eff_t * eff_p

    return {
        'X': X, 'Y': Y,
        'firm_id': firm_id, 'time_id': time_id,
        'u_true'         : u_arr,
        'mu_true'        : np.array([mu_i[f] for f in firm_id]),
        'alpha_true'     : np.array([alpha_i[f] for f in firm_id]),
        'eff_true'       : eff_all,
        'eff_transient'  : eff_t,
        'eff_persistent' : eff_p,
        'sigma_u': sigma_u, 'sigma_v': sigma_v,
        'sigma_mu': sigma_mu, 'sigma_alpha': sigma_alpha,
        'N': N, 'T': T, 'p': p, 'q': q, 'n': n,
    }


# ─────────────────────────────────────────────────────────────
# 검증 지표 계산
# ─────────────────────────────────────────────────────────────

def validation_metrics(eff_true, eff_est, label=''):
    """
    추정 효율성과 진짜 효율성 비교.

    지표:
      - 편향 (Bias): E[ê - e]
      - RMSE: √E[(ê - e)²]
      - Spearman 순위 상관
      - 평균 추정값 vs. 진짜 평균
    """
    mask = ~(np.isnan(eff_true) | np.isnan(eff_est))
    et = eff_true[mask]
    ee = eff_est[mask]

    bias   = np.mean(ee - et)
    rmse   = np.sqrt(np.mean((ee - et) ** 2))
    rho, p = spearmanr(et, ee)

    metrics = {
        'label'       : label,
        'n_valid'     : mask.sum(),
        'true_mean'   : et.mean(),
        'est_mean'    : ee.mean(),
        'bias'        : bias,
        'abs_bias'    : abs(bias),
        'rmse'        : rmse,
        'spearman_rho': rho,
        'spearman_p'  : p,
    }
    return metrics


# ─────────────────────────────────────────────────────────────
# SW(2023)-native DGP
# ─────────────────────────────────────────────────────────────

def dgp_sw_native(n=500, p=2, q=2, seed=42,
                  sigma_v=0.2, sigma_u=0.3,
                  intercept=2.0):
    """
    SW(2023) 모형과 완전히 일치하는 DGP.

    데이터를 직접 회전 좌표계 (Z, U)에서 생성:
      U_i = φ(Z_i) + v_i - η_i     ← 모형 구조와 동일

    생성 절차:
      1. 방향벡터 d = (0,...,0, 1/√q,...,1/√q)  (산출 방향)
      2. 회전 기저 V = null_space(d')  : (r, r-1)
      3. Z ~ N(0,1)  (r-1차원 잠재 공변량)
      4. φ(Z) = intercept + Z @ β  (선형 프론티어)
      5. v ~ N(0,σ_v²), η ~ half-normal(σ_u)
      6. U = φ(Z) + v - η
      7. W = Z @ V' + U[:,None] @ d[None,:]
      8. X = exp(W[:,:p]), Y = exp(W[:,p:])

    intercept 역할:
      mean(W[:,p:]) ≈ intercept × (1/√q) > 0  →  방향벡터 d_Y > 0 보장
    """
    rng = np.random.default_rng(seed)
    r   = p + q

    # 진짜 방향 벡터
    d_true = np.zeros(r)
    d_true[p:] = 1.0 / np.sqrt(q)

    # 회전 기저 (d에 직교)
    V = null_space(d_true.reshape(1, -1))     # (r, r-1)

    # 잠재 공변량 (표준 정규)
    Z    = rng.normal(0.0, 1.0, size=(n, r-1))
    beta = np.ones(r-1) / (r-1)
    phi  = intercept + Z @ beta               # (n,)

    # 노이즈 + 비효율
    v   = rng.normal(0, sigma_v, size=n)
    eta = halfnorm.rvs(scale=sigma_u, size=n, random_state=rng)
    U   = phi + v - eta
    eff_true = np.exp(-eta)

    # 원래 공간 복원
    W = Z @ V.T + U[:, None] @ d_true[None, :]
    X = np.exp(W[:, :p])
    Y = np.exp(W[:, p:])

    return {
        'X'       : X,
        'Y'       : Y,
        'eff_true': eff_true,
        'eta_true': eta,
        'sigma_u' : sigma_u,
        'sigma_v' : sigma_v,
        'd_true'  : d_true,
        'n': n, 'p': p, 'q': q,
    }


# ─────────────────────────────────────────────────────────────
# 2-component Monte Carlo
# ─────────────────────────────────────────────────────────────

def run_mc_2component(n_sims=50, n=500, p=2, q=2,
                      sigma_v=0.2, sigma_u=0.3,
                      verbose=True):
    """
    2-component Monte Carlo 실험.

    각 반복에서:
      1. DGP 생성
      2. SW2023Model 추정
      3. 효율성 검증 지표 계산
    """
    import sys, os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
    from core.model import SW2023Model

    results = []

    for sim in range(n_sims):
        if verbose and sim % 10 == 0:
            print(f"  Simulation {sim+1}/{n_sims}...")

        data = dgp_2component(n=n, p=p, q=q, seed=sim,
                               sigma_v=sigma_v, sigma_u=sigma_u)
        try:
            m = SW2023Model(data['X'], data['Y'],
                             direction='mean', method='HMS',
                             log_transform=True, standardize=True)
            m.fit(verbose=False)

            m_ = validation_metrics(data['eff_true'], m.efficiency_,
                                     label=f'sim_{sim}')
            m_['wrong_skew_pct'] = (m.r3_ > 0).mean() * 100
            m_['sigma_u_est']    = np.nanmean(m.sigma_eta_)
            m_['sigma_u_true']   = sigma_u
            results.append(m_)

        except Exception as e:
            if verbose:
                print(f"    오류 (sim={sim}): {e}")

    df = pd.DataFrame(results)

    if verbose:
        print(f"\n=== 2-Component MC 결과 요약 (n_sims={len(df)}) ===")
        print(f"  평균 편향      : {df['bias'].mean():.4f} ± {df['bias'].std():.4f}")
        print(f"  평균 RMSE      : {df['rmse'].mean():.4f} ± {df['rmse'].std():.4f}")
        print(f"  평균 Spearman ρ: {df['spearman_rho'].mean():.4f}")
        print(f"  진짜 평균 효율 : {df['true_mean'].mean():.4f}")
        print(f"  추정 평균 효율 : {df['est_mean'].mean():.4f}")
        print(f"  Wrong skew (%) : {df['wrong_skew_pct'].mean():.1f}")
        print(f"  σ_u 진짜       : {sigma_u:.4f}")
        print(f"  σ_u 추정       : {df['sigma_u_est'].mean():.4f}")

    return df


def run_mc_native(n_sims=50, n=500, p=2, q=2,
                  sigma_v=0.2, sigma_u=0.3,
                  verbose=True):
    """
    SW(2023)-native DGP를 사용한 2-component MC.

    DGP-모형 불일치가 없으므로 더 깨끗한 검증 결과를 제공.
    """
    import sys, os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
    from core.model import SW2023Model

    results = []

    for sim in range(n_sims):
        if verbose and sim % 10 == 0:
            print(f"  Simulation {sim+1}/{n_sims}...")

        data = dgp_sw_native(n=n, p=p, q=q, seed=sim,
                              sigma_v=sigma_v, sigma_u=sigma_u)
        try:
            m = SW2023Model(data['X'], data['Y'],
                             direction='mean', method='HMS',
                             log_transform=True, standardize=True)
            m.fit(verbose=False)

            m_ = validation_metrics(data['eff_true'], m.efficiency_,
                                     label=f'sim_{sim}')
            m_['wrong_skew_pct'] = (m.r3_ > 0).mean() * 100
            m_['sigma_u_est']    = np.nanmean(m.sigma_eta_)
            m_['sigma_u_true']   = sigma_u
            results.append(m_)
        except Exception as e:
            if verbose:
                print(f"    오류 (sim={sim}): {e}")

    df = pd.DataFrame(results)

    if verbose:
        print(f"\n=== Native DGP MC 결과 (n_sims={len(df)}, n={n}, p={p}, q={q}) ===")
        print(f"  평균 편향      : {df['bias'].mean():.4f} ± {df['bias'].std():.4f}")
        print(f"  평균 RMSE      : {df['rmse'].mean():.4f} ± {df['rmse'].std():.4f}")
        print(f"  평균 Spearman ρ: {df['spearman_rho'].mean():.4f}")
        print(f"  진짜 평균 효율 : {df['true_mean'].mean():.4f}")
        print(f"  추정 평균 효율 : {df['est_mean'].mean():.4f}")
        print(f"  Wrong skew (%) : {df['wrong_skew_pct'].mean():.1f}")
        print(f"  σ_u 진짜       : {sigma_u:.4f}")
        print(f"  σ_u 추정       : {df['sigma_u_est'].mean():.4f}")

    return df


# ─────────────────────────────────────────────────────────────
# 4-component Monte Carlo
# ─────────────────────────────────────────────────────────────

def run_mc_4component(n_sims=50, N=100, T=5, p=2, q=2,
                      sigma_v=0.15, sigma_u=0.20,
                      sigma_alpha=0.10, sigma_mu=0.20,
                      verbose=True):
    """
    4-component 패널 Monte Carlo 실험.
    """
    import sys, os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
    from panel.four_component import PanelSW2023

    results = []

    for sim in range(n_sims):
        if verbose and sim % 10 == 0:
            print(f"  Simulation {sim+1}/{n_sims}...")

        data = dgp_4component(N=N, T=T, p=p, q=q, seed=sim,
                               sigma_v=sigma_v, sigma_u=sigma_u,
                               sigma_alpha=sigma_alpha, sigma_mu=sigma_mu)
        try:
            m = PanelSW2023(data['X'], data['Y'],
                             data['firm_id'], data['time_id'],
                             direction='mean', method='HMS',
                             log_transform=True, standardize=True)
            m.fit(verbose=False)

            # 전체 효율성
            m_all = validation_metrics(data['eff_true'], m.efficiency_,
                                        label='overall')
            # 일시적 효율성
            m_te  = validation_metrics(data['eff_transient'], m.eff_transient_,
                                        label='transient')
            # 영구적 효율성
            m_pe  = validation_metrics(data['eff_persistent'], m.eff_persistent_,
                                        label='persistent')

            results.append({
                'sim'             : sim,
                'bias_all'        : m_all['bias'],
                'rmse_all'        : m_all['rmse'],
                'rho_all'         : m_all['spearman_rho'],
                'bias_te'         : m_te['bias'],
                'rmse_te'         : m_te['rmse'],
                'rho_te'          : m_te['spearman_rho'],
                'bias_pe'         : m_pe['bias'],
                'rmse_pe'         : m_pe['rmse'],
                'rho_pe'          : m_pe['spearman_rho'],
                'est_mean_all'    : np.nanmean(m.efficiency_),
                'true_mean_all'   : data['eff_true'].mean(),
            })
        except Exception as e:
            if verbose:
                print(f"    오류 (sim={sim}): {e}")

    df = pd.DataFrame(results)

    if verbose:
        print(f"\n=== 4-Component MC 결과 요약 (n_sims={len(df)}) ===")
        for comp, label in [('all','전체'), ('te','일시적'), ('pe','영구적')]:
            print(f"\n  [{label} 효율성]")
            print(f"    편향  : {df[f'bias_{comp}'].mean():.4f}")
            print(f"    RMSE  : {df[f'rmse_{comp}'].mean():.4f}")
            print(f"    ρ     : {df[f'rho_{comp}'].mean():.4f}")

    return df


# ─────────────────────────────────────────────────────────────
# SW(2023) 논문 재현용 DGP 및 IMSE 계산
# ─────────────────────────────────────────────────────────────

def dgp_sw_sphere(n, p, q, sigma_eta=0.5, rho=1.0, seed=42):
    """
    SW(2023) Appendix F의 구(sphere) 기반 DGP.

    Muller(1959)/Marsaglia(1972) 방법으로 (p+q)차원 구 표면 위에
    균등 분포한 점을 생성하고, 이를 투입물/산출물 프론티어로 변환.

    절차:
      1. a_i ~ Uniform(S^{p+q-1})  (표준 정규 → 정규화)
      2. X^∂_i = 1 - |a_{p,i}|,  Y^∂_i = |a_{q,i}|
      3. d = normalized([-1_p, 1_q])
      4. U^∂_i = d' W^∂_i  (프론티어의 U 값)
      5. σ_ε = ρ × √((π-2)/π) × σ_η   (SW 논문 식 F.1)
      6. ε_i ~ N(0,σ_ε²),  η_i ~ N⁺(0,σ_η²)
      7. U_i = U^∂_i + ε_i - η_i
      8. Z_i = Z^∂_i  (동일)
      9. (X_i,Y_i) 역변환

    Parameters
    ----------
    n          : 표본 크기
    p, q       : 투입물/산출물 수
    sigma_eta  : η 표준편차 (논문 고정값 0.5)
    rho        : 잡음-신호 비율 (σ_ε / √((π-2)/π) / σ_η)
    seed       : 난수 시드

    Returns
    -------
    dict: X, Y (관측), X_star, Y_star (프론티어), U_star (진짜 U^∂),
          Z_star, d, sigma_eta, sigma_eps, rho
    """
    rng = np.random.default_rng(seed)
    r   = p + q

    # ── 1. 구 표면 균등 분포 (Muller/Marsaglia) ──────────────
    a_raw = rng.standard_normal(size=(n, r))
    a     = a_raw / np.linalg.norm(a_raw, axis=1, keepdims=True)

    # ── 2. 프론티어 점 ────────────────────────────────────────
    X_star = 1.0 - np.abs(a[:, :p])   # (n, p) ∈ [0, 1]
    Y_star = np.abs(a[:, p:])          # (n, q) ∈ [0, 1]
    W_star = np.hstack([X_star, Y_star])  # (n, r)

    # ── 3. 방향벡터 (SW 논문과 동일) ──────────────────────────
    d_raw = np.concatenate([-np.ones(p), np.ones(q)])
    d     = d_raw / np.linalg.norm(d_raw)     # (r,) 정규화

    # ── 4. 회전 기저 ───────────────────────────────────────────
    V = null_space(d.reshape(1, -1))   # (r, r-1): d에 직교하는 기저

    # ── 5. 프론티어 → (Z^∂, U^∂) 변환 ────────────────────────
    U_star = W_star @ d         # (n,)
    Z_star = W_star @ V         # (n, r-1)

    # ── 6. σ_ε 결정 (SW 논문 식 F.1) ─────────────────────────
    sigma_eps = rho * np.sqrt((np.pi - 2) / np.pi) * sigma_eta

    # ── 7. 잡음 및 비효율성 생성 ──────────────────────────────
    eps = rng.normal(0.0, sigma_eps, size=n) if sigma_eps > 0 \
          else np.zeros(n)
    eta = halfnorm.rvs(scale=sigma_eta, size=n, random_state=rng)

    # ── 8. 관측값 ─────────────────────────────────────────────
    xi    = eps - eta
    U_obs = U_star + xi
    Z_obs = Z_star.copy()

    # ── 9. (Z, U) → (X, Y) 역변환 ─────────────────────────────
    W_obs = Z_obs @ V.T + U_obs[:, None] * d[None, :]
    X_obs = W_obs[:, :p]
    Y_obs = W_obs[:, p:]

    return {
        'X': X_obs, 'Y': Y_obs,
        'X_star': X_star, 'Y_star': Y_star,
        'U_star': U_star, 'Z_star': Z_star,
        'd': d, 'V': V,
        'eta': eta, 'eps': eps,
        'sigma_eta': sigma_eta, 'sigma_eps': sigma_eps, 'rho': rho,
        'n': n, 'p': p, 'q': q,
    }


def run_imse_grid(n_sims=100,
                  n_list=None, pq_list=None, rho_list=None,
                  sigma_eta=0.5,
                  method='HMS',
                  bandwidth_method='loocv',
                  out_csv='mc_imse_results.csv',
                  verbose=True):
    """
    SW(2023) Table F.1 재현용 IMSE 격자 실험.

    IMSE_m = (1/n) × Σ_i (φ̂(Z_i) − U^∂_i)²   [per-observation 정규화]

    모델은 log_transform=False, standardize=False로 실행하고
    방향벡터를 DGP와 동일하게 지정.

    Parameters
    ----------
    n_sims    : 셀당 Monte Carlo 반복 수 (논문: 1000, 기본: 100)
    n_list    : 표본 크기 목록
    pq_list   : (p,q) 쌍 목록
    rho_list  : 잡음-신호 비율 목록
    sigma_eta : 비효율성 표준편차 (논문 고정값 0.5)
    method    : 'HMS' | 'SVKZ'
    out_csv   : 결과 CSV 경로
    verbose   : 진행 출력 여부

    Returns
    -------
    pd.DataFrame : IMSE 격자 결과 + 논문 Table F.1 값 (있는 경우)
    """
    import gc, os, sys
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
    from core.model import SW2023Model

    if n_list   is None: n_list   = [100, 200, 400, 800]
    if pq_list  is None: pq_list  = [(1,1), (2,2)]
    if rho_list is None: rho_list = [0.0, 0.5, 1.0, 2.0]

    # SW(2023) Table F.1 HMS 참조값 (부분)
    # key: (p,q,rho,n) → IMSE   (출처: Simar & Wilson 2023 Supplementary, Table F.1)
    TABLE_F1_HMS = {
        # rho=0.0 (sigma_eps=0, 순수 half-normal)
        (1,1,0.0,100):0.0161,(1,1,0.0,200):0.0082,(1,1,0.0,400):0.0042,
        (1,1,0.0,800):0.0021,(1,1,0.0,1600):0.0010,(1,1,0.0,3200):0.0006,
        (1,2,0.0,100):0.0274,(1,2,0.0,200):0.0187,(1,2,0.0,400):0.0113,
        (1,2,0.0,800):0.0066,(1,2,0.0,1600):0.0036,(1,2,0.0,3200):0.0020,
        (2,2,0.0,100):0.0344,(2,2,0.0,200):0.0228,(2,2,0.0,400):0.0153,
        (2,2,0.0,800):0.0111,(2,2,0.0,1600):0.0077,(2,2,0.0,3200):0.0051,
        (2,3,0.0,100):0.0388,(2,3,0.0,200):0.0263,(2,3,0.0,400):0.0170,
        (2,3,0.0,800):0.0121,(2,3,0.0,1600):0.0092,(2,3,0.0,3200):0.0073,
        (3,3,0.0,100):0.0437,(3,3,0.0,200):0.0293,(3,3,0.0,400):0.0192,
        (3,3,0.0,800):0.0125,(3,3,0.0,1600):0.0094,(3,3,0.0,3200):0.0075,
        # rho=0.25
        (1,1,0.25,100):0.0174,(1,1,0.25,200):0.0090,
        # rho=0.5
        (1,1,0.5,100):0.0216,(1,1,0.5,200):0.0118,(1,1,0.5,400):0.0063,
        (2,2,0.5,100):0.0438,(2,2,0.5,200):0.0293,(2,2,0.5,400):0.0198,
        # rho=1.0
        (1,1,1.0,100):0.0571,(1,1,1.0,200):0.0303,(1,1,1.0,400):0.0166,
        (2,2,1.0,100):0.1057,(2,2,1.0,200):0.0686,(2,2,1.0,400):0.0408,
        # rho=2.0
        (1,1,2.0,100):0.4107,(1,1,2.0,200):0.2902,(1,1,2.0,400):0.1980,
        (2,2,2.0,100):0.5573,(2,2,2.0,200):0.4266,(2,2,2.0,400):0.2907,
    }

    # 기존 결과 재개
    done_keys = set()
    if os.path.exists(out_csv):
        existing = pd.read_csv(out_csv)
        for _, row in existing.iterrows():
            done_keys.add((int(row['n']), int(row['p']), int(row['q']),
                           float(row['rho'])))
        if verbose:
            print(f"[재개] 기존 {len(existing)}행 → {len(done_keys)}개 셀 건너뜀")

    total = len(n_list) * len(pq_list) * len(rho_list)
    cell_idx = 0
    all_rows  = []

    for n in n_list:
        for (p, q) in pq_list:
            for rho in rho_list:
                cell_idx += 1
                key = (n, p, q, rho)
                if key in done_keys:
                    if verbose:
                        print(f"[{cell_idx}/{total}] 건너뜀: "
                              f"n={n}, ({p},{q}), ρ={rho}")
                    continue

                ref = TABLE_F1_HMS.get((p, q, rho, n), float('nan'))
                if verbose:
                    print(f"\n[{cell_idx}/{total}] "
                          f"n={n}, (p,q)=({p},{q}), ρ={rho}  "
                          f"[논문 참조값: {ref:.4f}]" if not np.isnan(ref)
                          else f"\n[{cell_idx}/{total}] "
                          f"n={n}, (p,q)=({p},{q}), ρ={rho}")

                imse_list = []
                n_fail = 0

                for sim in range(n_sims):
                    data = dgp_sw_sphere(n=n, p=p, q=q,
                                         sigma_eta=sigma_eta,
                                         rho=rho, seed=sim)
                    try:
                        m = SW2023Model(
                            data['X'], data['Y'],
                            direction=data['d'],
                            method=method,
                            log_transform=False,
                            standardize=False,
                            bandwidth_method=bandwidth_method,
                        )
                        m.fit(verbose=False)

                        # IMSE: (1/n) × Σ (φ̂_i − U^∂_i)²
                        imse = np.mean((m.phi_hat_ - data['U_star']) ** 2)
                        imse_list.append(imse)

                        del m, data
                    except Exception as e:
                        n_fail += 1
                        del data
                    finally:
                        gc.collect()

                if not imse_list:
                    if verbose:
                        print(f"  → 전체 실패, 건너뜀")
                    continue

                imse_arr = np.array(imse_list)
                summary = {
                    'n'          : n,
                    'p'          : p,
                    'q'          : q,
                    'rho'        : rho,
                    'method'     : method,
                    'n_sims'     : len(imse_list),
                    'n_fail'     : n_fail,
                    'imse_mean'  : imse_arr.mean(),
                    'imse_std'   : imse_arr.std(),
                    'imse_median': np.median(imse_arr),
                    'ref_paper'  : ref,
                }
                all_rows.append(summary)

                pd.DataFrame([summary]).to_csv(
                    out_csv, mode='a',
                    header=not os.path.exists(out_csv)
                           or os.path.getsize(out_csv) == 0,
                    index=False)

                if verbose:
                    ratio = imse_arr.mean() / ref if not np.isnan(ref) else float('nan')
                    print(f"  IMSE={imse_arr.mean():.4f} "
                          f"(±{imse_arr.std():.4f})  "
                          f"논문={ref:.4f}  비율={ratio:.2f}"
                          if not np.isnan(ref) else
                          f"  IMSE={imse_arr.mean():.4f} "
                          f"(±{imse_arr.std():.4f})  실패={n_fail}")

                del imse_list, imse_arr
                gc.collect()

    if verbose:
        print(f"\nIMSE 격자 실험 완료. 저장: {out_csv}")

    if os.path.exists(out_csv):
        return pd.read_csv(out_csv)
    return pd.DataFrame(all_rows)


def print_imse_comparison(df):
    """
    IMSE 결과를 논문 Table F.1과 나란히 출력.
    """
    for (p, q) in df[['p', 'q']].drop_duplicates().itertuples(index=False):
        sub = df[(df['p'] == p) & (df['q'] == q)].copy()
        sub['ratio'] = (sub['imse_mean'] / sub['ref_paper']).round(2)

        print(f"\n[p={p}, q={q}]  IMSE 비교")
        print(f"{'ρ':>5}  {'n':>5}  {'추정값':>10}  {'논문값':>10}  {'비율':>6}")
        print("-" * 46)
        for _, row in sub.sort_values(['rho', 'n']).iterrows():
            ref = row['ref_paper']
            ref_str = f"{ref:.4f}" if not np.isnan(ref) else "   —  "
            print(f"{row['rho']:>5.2f}  {int(row['n']):>5}  "
                  f"{row['imse_mean']:>10.4f}  {ref_str:>10}  "
                  f"{row['ratio']:>6.2f}" if not np.isnan(row['ratio'])
                  else f"{row['rho']:>5.2f}  {int(row['n']):>5}  "
                  f"{row['imse_mean']:>10.4f}  {ref_str:>10}     —")


# ─────────────────────────────────────────────────────────────
# 격자 실험 (JSS 논문 핵심)
# ─────────────────────────────────────────────────────────────

def run_mc_grid(n_sims=30,
                n_list=None, pq_list=None, ratio_list=None,
                sigma_v_base=0.2,
                out_csv='mc_grid_results.csv',
                verbose=True):
    """
    표본 크기 × (p,q) 차원 × σ_u/σ_v 비율 격자 Monte Carlo 실험.

    SW(2023) Appendix F 비교용.  n_jobs=1 순차 실행 (커널 패닉 방지).

    Parameters
    ----------
    n_sims     : 격자 셀당 반복 수 (기본 30)
    n_list     : 표본 크기 목록 (기본 [300, 500, 1000])
    pq_list    : (p, q) 쌍 목록 (기본 [(1,1),(2,2),(3,2)])
    ratio_list : σ_u/σ_v 비율 목록 (기본 [0.5, 1.0, 2.0])
    sigma_v_base : 기준 σ_v (기본 0.2)
    out_csv    : 결과를 저장할 CSV 파일 경로
    verbose    : 진행 상황 출력 여부

    Returns
    -------
    pd.DataFrame : 격자 전체 결과
    """
    import gc, os, sys
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
    from core.model import SW2023Model

    if n_list    is None: n_list    = [300, 500, 1000]
    if pq_list   is None: pq_list   = [(1, 1), (2, 2), (3, 2)]
    if ratio_list is None: ratio_list = [0.5, 1.0, 2.0]

    # 기존 결과 불러오기 (중단 후 재개 지원)
    done_keys = set()
    if os.path.exists(out_csv):
        existing = pd.read_csv(out_csv)
        for _, row in existing.iterrows():
            done_keys.add((int(row['n']), int(row['p']), int(row['q']),
                           float(row['ratio'])))
        if verbose:
            print(f"[재개] 기존 결과 {len(existing)}행 로드 → "
                  f"{len(done_keys)}개 셀 건너뜀")

    all_rows = []
    total_cells = len(n_list) * len(pq_list) * len(ratio_list)
    cell_idx    = 0

    for n in n_list:
        for (p, q) in pq_list:
            for ratio in ratio_list:
                cell_idx += 1
                key = (n, p, q, ratio)

                if key in done_keys:
                    if verbose:
                        print(f"[{cell_idx}/{total_cells}] 건너뜀: "
                              f"n={n}, p={p}, q={q}, ratio={ratio}")
                    continue

                sigma_u = sigma_v_base * ratio

                if verbose:
                    print(f"\n[{cell_idx}/{total_cells}] "
                          f"n={n}, p={p}, q={q}, "
                          f"σ_u={sigma_u:.3f}, σ_v={sigma_v_base:.3f} "
                          f"(ratio={ratio})")

                cell_results = []
                n_fail = 0

                for sim in range(n_sims):
                    data = dgp_sw_native(n=n, p=p, q=q, seed=sim,
                                         sigma_v=sigma_v_base,
                                         sigma_u=sigma_u)
                    try:
                        m = SW2023Model(data['X'], data['Y'],
                                        direction='mean', method='HMS',
                                        log_transform=True, standardize=True)
                        m.fit(verbose=False)

                        met = validation_metrics(
                            data['eff_true'], m.efficiency_,
                            label=f'sim_{sim}')
                        met['wrong_skew_pct'] = (m.r3_ > 0).mean() * 100
                        met['sigma_u_est']    = float(np.nanmean(m.sigma_eta_))
                        cell_results.append(met)

                        # 즉시 메모리 해제
                        del m, data, met
                    except Exception as e:
                        n_fail += 1
                        del data
                    finally:
                        gc.collect()

                if not cell_results:
                    if verbose:
                        print(f"  → 전체 실패 (n_fail={n_fail}), 건너뜀")
                    continue

                df_cell = pd.DataFrame(cell_results)
                summary = {
                    'n'            : n,
                    'p'            : p,
                    'q'            : q,
                    'ratio'        : ratio,
                    'sigma_u_true' : sigma_u,
                    'sigma_v'      : sigma_v_base,
                    'n_sims'       : len(cell_results),
                    'n_fail'       : n_fail,
                    'bias_mean'    : df_cell['bias'].mean(),
                    'bias_std'     : df_cell['bias'].std(),
                    'rmse_mean'    : df_cell['rmse'].mean(),
                    'rmse_std'     : df_cell['rmse'].std(),
                    'rho_mean'     : df_cell['spearman_rho'].mean(),
                    'rho_std'      : df_cell['spearman_rho'].std(),
                    'wrong_skew_pct': df_cell['wrong_skew_pct'].mean(),
                    'sigma_u_est_mean': df_cell['sigma_u_est'].mean(),
                    'true_eff_mean': df_cell['true_mean'].mean(),
                    'est_eff_mean' : df_cell['est_mean'].mean(),
                }
                all_rows.append(summary)

                # 셀 결과 즉시 CSV에 추가
                pd.DataFrame([summary]).to_csv(
                    out_csv, mode='a',
                    header=not os.path.exists(out_csv) or os.path.getsize(out_csv) == 0,
                    index=False)

                if verbose:
                    print(f"  편향={summary['bias_mean']:.4f}  "
                          f"RMSE={summary['rmse_mean']:.4f}  "
                          f"ρ={summary['rho_mean']:.4f}  "
                          f"wrong_skew={summary['wrong_skew_pct']:.1f}%  "
                          f"실패={n_fail}/{n_sims}")

                del df_cell, cell_results
                gc.collect()

    if verbose:
        print(f"\n격자 실험 완료. 결과 저장: {out_csv}")

    if os.path.exists(out_csv):
        return pd.read_csv(out_csv)
    return pd.DataFrame(all_rows)


def print_grid_table(df, metric='rmse_mean'):
    """
    격자 결과를 n × ratio 피벗 테이블로 출력.

    Parameters
    ----------
    df     : run_mc_grid() 반환 DataFrame
    metric : 출력할 지표 (기본 'rmse_mean')
    """
    for (p, q) in df[['p', 'q']].drop_duplicates().itertuples(index=False):
        sub = df[(df['p'] == p) & (df['q'] == q)]
        pivot = sub.pivot(index='n', columns='ratio', values=metric)
        print(f"\n[p={p}, q={q}]  {metric}")
        print(pivot.to_string(float_format='{:.4f}'.format))


# ─────────────────────────────────────────────────────────────
# 실행
# ─────────────────────────────────────────────────────────────
if __name__ == '__main__':
    import sys
    mode = sys.argv[1] if len(sys.argv) > 1 else 'quick'

    if mode == 'quick':
        # 가장 단순한 경우: p=1, q=1, Z가 1차원
        print("=" * 55)
        print("Monte Carlo 검증 (빠른 테스트: p=1,q=1,n=500)")
        print("=" * 55)

        print("\n▶ 2-Component (n=500, p=1, q=1)")
        df2 = run_mc_2component(n_sims=20, n=500, p=1, q=1,
                                 sigma_v=0.2, sigma_u=0.3, verbose=True)

        print("\n▶ 4-Component 패널 (N=100, T=5, p=1, q=1)")
        df4 = run_mc_4component(n_sims=20, N=100, T=5, p=1, q=1,
                                 sigma_v=0.15, sigma_u=0.20,
                                 sigma_alpha=0.10, sigma_mu=0.20,
                                 verbose=True)

    elif mode == 'native':
        # Native DGP 검증 (DGP-모형 완전 일치)
        print("=" * 55)
        print("Monte Carlo 검증 (Native DGP: p=2,q=2)")
        print("=" * 55)

        for n_obs in [300, 500, 1000]:
            print(f"\n▶ Native DGP (n={n_obs}, p=2, q=2)")
            run_mc_native(n_sims=30, n=n_obs, p=2, q=2,
                          sigma_v=0.2, sigma_u=0.3, verbose=True)

    elif mode == 'full':
        print("=" * 55)
        print("Monte Carlo 검증 (전체: p=2,q=2,n=1000)")
        print("=" * 55)

        print("\n▶ 2-Component (n=1000, p=2, q=2)")
        df2 = run_mc_2component(n_sims=50, n=1000, p=2, q=2,
                                 sigma_v=0.2, sigma_u=0.3, verbose=True)

        print("\n▶ 4-Component 패널 (N=200, T=5, p=2, q=2)")
        df4 = run_mc_4component(n_sims=50, N=200, T=5, p=2, q=2,
                                 sigma_v=0.15, sigma_u=0.20,
                                 sigma_alpha=0.10, sigma_mu=0.20,
                                 verbose=True)

    elif mode == 'grid':
        # JSS 논문 핵심: 격자 실험 (n_jobs=1 순차, 재개 가능)
        print("=" * 55)
        print("Monte Carlo 격자 실험 (SW 2023 Appendix F 비교)")
        print("=" * 55)
        df_grid = run_mc_grid(
            n_sims=30,
            n_list=[300, 500, 1000],
            pq_list=[(1, 1), (2, 2), (3, 2)],
            ratio_list=[0.5, 1.0, 2.0],
            sigma_v_base=0.2,
            out_csv='mc_grid_results.csv',
            verbose=True,
        )
        print("\n=== RMSE 요약 테이블 ===")
        print_grid_table(df_grid, metric='rmse_mean')
        print("\n=== Spearman ρ 요약 테이블 ===")
        print_grid_table(df_grid, metric='rho_mean')

    elif mode == 'imse':
        # SW(2023) Table F.1 재현 (논문과 직접 비교)
        print("=" * 60)
        print("SW(2023) Table F.1 IMSE 재현 실험")
        print("=" * 60)
        df_imse = run_imse_grid(
            n_sims=100,
            n_list=[100, 200, 400, 800],
            pq_list=[(1,1), (2,2)],
            rho_list=[0.0, 0.5, 1.0, 2.0],
            sigma_eta=0.5,
            method='HMS',
            out_csv='mc_imse_results.csv',
            verbose=True,
        )
        print_imse_comparison(df_imse)

    elif mode == 'imse_quick':
        # 빠른 확인 (n_sims=20, 소규모)
        print("=" * 60)
        print("SW(2023) Table F.1 IMSE 빠른 확인")
        print("=" * 60)
        df_imse = run_imse_grid(
            n_sims=20,
            n_list=[100, 400],
            pq_list=[(1,1), (2,2)],
            rho_list=[0.0, 0.5, 1.0, 2.0],
            sigma_eta=0.5,
            method='HMS',
            bandwidth_method='loocv',
            out_csv='mc_imse_quick.csv',
            verbose=True,
        )
        print_imse_comparison(df_imse)

    elif mode == 'grid_quick':
        # 빠른 격자 확인 (셀당 n_sims=10, 소규모)
        print("=" * 55)
        print("Monte Carlo 격자 실험 (빠른 확인)")
        print("=" * 55)
        df_grid = run_mc_grid(
            n_sims=10,
            n_list=[300, 500],
            pq_list=[(1, 1), (2, 2)],
            ratio_list=[0.5, 1.0, 2.0],
            sigma_v_base=0.2,
            out_csv='mc_grid_quick.csv',
            verbose=True,
        )
        print_grid_table(df_grid, metric='rmse_mean')

    else:
        # 원래 설정
        print("=" * 55)
        print("Monte Carlo 검증 (n_sims=10, p=2, q=2)")
        print("=" * 55)

        print("\n▶ 2-Component 검증 (n=300, p=2, q=2)")
        df2 = run_mc_2component(n_sims=10, n=300, p=2, q=2,
                                 sigma_v=0.2, sigma_u=0.3, verbose=True)

        print("\n▶ 4-Component 패널 검증 (N=80, T=5, p=2, q=2)")
        df4 = run_mc_4component(n_sims=10, N=80, T=5, p=2, q=2,
                                 sigma_v=0.15, sigma_u=0.20,
                                 sigma_alpha=0.10, sigma_mu=0.20,
                                 verbose=True)
