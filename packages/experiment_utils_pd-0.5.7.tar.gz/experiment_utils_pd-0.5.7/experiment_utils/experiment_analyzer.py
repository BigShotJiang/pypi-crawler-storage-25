"""
ExperimentAnalyzer class to analyze and design experiments
"""

import re as _re

import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from scipy import stats
from scipy.stats import gaussian_kde
from statsmodels.stats.proportion import proportions_ztest

from .bootstrap import BootstrapMixin
from .estimators import Estimators
from .meta_analysis import MetaAnalysisMixin
from .retrodesign import RetrodesignMixin
from .utils import detect_categorical_covariates, generate_comparison_pairs, get_logger, log_and_raise_error


def _clean_category_name(cat):
    """Convert category to lowercase and replace spaces/special chars with underscores"""
    cat_str = str(cat).lower()
    cat_str = _re.sub(r"[^\w]+", "_", cat_str)
    cat_str = cat_str.strip("_")
    return cat_str


class ExperimentAnalyzer(BootstrapMixin, RetrodesignMixin, MetaAnalysisMixin):
    """
    Class ExperimentAnalyzer to analyze and design experiments

    Parameters
    ----------
    data : pd.DataFrame
        Pandas Dataframe
    outcomes : List
        List of outcome variables
    balance_covariates : list[str], optional
        Covariates used exclusively for balance checking (SMD tables). They are never
        included in the regression formula. Can include:
        - Numeric columns (continuous)
        - Binary columns (0/1)
        - Categorical columns (object/category dtype or integers with low cardinality)
          Categorical columns are automatically dummy-encoded. The reference category
          (most frequent) is excluded from regression but shown in balance tables.
          Use ``categorical_max_unique`` to control the integer-cardinality threshold.
        By default None.
    covariates : list[str], optional
        Deprecated alias for ``balance_covariates``. Use ``balance_covariates`` instead.
    treatment_col : str
        Column name for the treatment variable
    experiment_identifier : List
        List of columns to identify an experiment
    adjustment : str, optional
        Covariate adjustment method ('balance', 'IV'), by default None
    exp_sample_ratio : str or float, optional
        Expected sample ratio for the SRM test. Either a column name containing
        per-row expected ratios, or a single float constant (e.g. 0.5), by default None
    estimand : str, optional
        Target estimand (ATT, ATE, ATC, ATO), by default "ATT".
        ATO uses overlap weights (Li, Morgan & Zaslavsky 2018): treated units receive weight
        (1 - ps), control units receive weight ps. Naturally downweights extreme-PS units
        without requiring a trimming threshold. Only supported with PS-based balance methods.
    balance_method : str, optional
        Balance method ('ps-logistic', 'ps-xgboost', 'entropy'), by default 'ps-logistic'
    min_ps_score : float, optional
        Minimum propensity score, by default 0.05
    max_ps_score : float, optional
        Maximum propensity score, by default 0.95
    trim_ps : bool, optional
        Drop units with propensity scores outside [trim_ps_lower, trim_ps_upper] after PS
        estimation and recompute weights on the trimmed sample. Only applied for PS-based
        balance methods ('ps-logistic', 'ps-xgboost'). By default False.
    trim_ps_lower : float, optional
        Lower PS bound for trimming. Units with PS below this value are dropped. By default 0.1.
    trim_ps_upper : float, optional
        Upper PS bound for trimming. Units with PS above this value are dropped. By default 0.9.
    trim_overlap_threshold : float | None, optional
        If set, trimming is only applied when the overlap coefficient (KDE-based) is at or
        above this value. Useful to skip trimming when overlap is already poor and many units
        would be dropped. By default None (trimming always applied when trim_ps=True).
    polynomial_ipw : bool, optional
        Use polynomial and interaction features for IPW, by default False. It can be slow for large datasets.
    assess_overlap : bool, optional
        Assess overlap between treatment and control groups (slow) when using balance to adjust covariates, by default False
    overlap_plot: bool, optional
        Plot overlap between treatment and control groups, by default False
    instrument_col : str, optional
        Column name for the instrument variable, by default None
    alpha : float, optional
        Significance level, by default 0.05
    regression_covariates : list[str], optional
        Covariates added as main effects to the regression formula. These columns are also
        subject to the same balance checks as ``balance_covariates`` and do not need to be
        listed in ``balance_covariates`` separately. By default None.
    unit_identifier : str, optional
        Column name for the unit/user identifier to connect weights to specific units, by default None
    bootstrap : bool, optional
        Whether to use bootstrap inference for p-values and confidence intervals, by default False
    bootstrap_iterations : int, optional
        Number of bootstrap iterations, by default 1000
    bootstrap_ci_method : str, optional
        Bootstrap CI method ('percentile', 'basic'), by default 'percentile'
    bootstrap_pvalue_method : str, optional
        Method for computing the bootstrap p-value ('percentile' or 'studentized'),
        by default 'studentized'.

        - ``'percentile'``: ``P(|β* − mean(β*)| ≥ |β_obs|)``. Fast and always available.
        - ``'studentized'``: Studentized bootstrap-t. Uses each resample's analytical SE to
          pivot the statistic: ``t* = (β* − β_obs) / SE*``, then ``P(|t*| ≥ |t_obs|)``.
          Better Type I error control for non-normal distributions and small samples because
          it accounts for SE variability across resamples. Recommended when data is clearly
          non-normal or N < 100 per group.
    bootstrap_stratify : bool, optional
        Whether to stratify bootstrap resampling by treatment group, by default True
    bootstrap_seed : int, optional
        Random seed for bootstrap reproducibility, by default None
    skip_bootstrap_for_survival : bool, optional
        Skip bootstrap for Cox survival models and use model's robust standard errors instead.
        Recommended when event rate < 30% or with IPW adjustment. By default False.
        Even when bootstrap=True, this will skip bootstrap specifically for Cox models.
    bootstrap_fixed_weights : bool, optional
        For IPW adjustment (adjustment='balance'), use fixed weights from original data
        instead of recalculating on each bootstrap sample. Faster and reduces variance.
        By default False (recalculates weights on each sample).
    bootstrap_backend : str, optional
        Parallelization backend for bootstrap: 'threading' (memory-efficient, shares data),
        'loky' (process-based, better CPU isolation but higher memory overhead),
        or 'hybrid' (two-pass threading: separate data prep and model fitting phases).
        By default 'threading'. The 'hybrid' strategy uses threading for both stages
        (unlike PowerSim which uses threading+multiprocessing) because: (1) DataFrames
        benefit from shared memory, (2) statsmodels releases the GIL, (3) avoids
        expensive serialization. Use 'hybrid' for potentially better cache utilization.
    prob_threshold_abs : float, optional
        Threshold used to compute ``P(absolute_effect > prob_threshold_abs)`` from the
        bootstrap distribution. In outcome units. By default 0.0 (i.e., probability of
        a positive effect). Only applied when ``bootstrap=True``; emitted as the
        ``prob_abs_effect_gt`` column.
    prob_threshold_rel : float, optional
        Threshold used to compute ``P(relative_effect > prob_threshold_rel)`` from the
        bootstrap distribution. Expressed as a fraction of the control mean (e.g.
        ``0.02`` = 2%). By default 0.0. Only applied when ``bootstrap=True``; emitted
        as the ``prob_rel_effect_gt`` column.
    rope_abs : tuple[float, float], optional
        Region of Practical Equivalence for the absolute effect, as ``(lo, hi)`` in
        outcome units. When set (and ``bootstrap=True``), emits
        ``prob_abs_effect_in_rope`` / ``_above_rope`` / ``_below_rope`` columns —
        probability mass of the bootstrap distribution inside, above, or below the
        band. ``None`` (default) disables; those columns are ``NaN``.
    rope_rel : tuple[float, float], optional
        ROPE for the relative effect, as ``(lo, hi)`` on the fractional scale
        (e.g. ``(-0.02, 0.02)`` = ±2%). Emits ``prob_rel_effect_in_rope`` /
        ``_above_rope`` / ``_below_rope`` when set. ``None`` (default) disables.
    correction : str, optional
        P-value adjustment method to apply automatically after get_effects ('bonferroni', 'holm', 'fdr_bh', 'sidak', 'hommel', 'hochberg', 'by', or None for no adjustment), by default 'bonferroni'
    categorical_max_unique : int, optional
        Maximum number of unique values for numeric columns to be treated as categorical.
        Numeric columns (int or float) with 2 to categorical_max_unique unique values
        will be converted to dummy variables, excluding natural binary {0, 1} columns
        which are kept as-is. A reference category (most frequent) is picked and excluded
        from regression but included in balance tables.
        Set to 1 to disable categorical treatment for numeric columns.
        Set to 5, 10, or higher for more inclusive behavior.
        By default 2.
    outcome_models : dict[str, str | list[str]] | str | list[str] | None, optional
        Specify model type(s) per outcome or globally. By default None (uses OLS for all outcomes).
        - Dict: {"revenue": "ols", "clicked": "logistic", "orders": "poisson"}
        - Dict with lists: {"clicked": ["ols", "logistic"], "orders": ["poisson", "negative_binomial"]}
        - String: "logistic" applies to all outcomes
        - List: ["ols", "logistic"] applies all models to all outcomes
        Supported models: "ols", "logistic", "poisson", "negative_binomial", "cox"
        When multiple models specified for same outcome, results include all model outputs with model_type column
    cluster_col : str, optional
        Column name for clustered standard errors (e.g., "user_id" for repeated measures).
        By default None (no clustering).
    compute_marginal_effects : str | bool, optional
        For GLMs, control marginal effects computation. By default "overall".
        - "overall": Average Marginal Effect (AME) - average across all observations
        - "mean": Marginal Effect at the Mean (MEM) - at mean of covariates
        - "median": Marginal effect at median of covariates
        - True: Same as "overall" (backward compatibility)
        - False: Return odds ratios / rate ratios instead of marginal effects
        Results interpretation:
        - Logistic: change in probability (percentage points) or odds ratio
        - Poisson/NegBin: change in expected count or rate ratio
    min_binary_count : int, optional
        Minimum number of observations required for a binary/dummy covariate to be included
        in the analysis. Covariates with fewer observations are excluded. By default 10.
    store_fitted_models : bool, optional
        Store fitted model instances for retrieval via get_fitted_models(). By default True.
        Enables post-hoc analysis, diagnostics, predictions, and accurate retrodesign simulation.
    event_col : str, optional
        Column name for event indicator in survival analysis (1=event, 0=censored).
        By default None. Alternative: specify Cox outcomes as tuples in the outcomes list.

        Two ways to specify Cox models:
        1. Tuple notation (recommended): outcomes=[("time_col", "event_col")]
        2. Separate parameter: outcomes=["time_col"], event_col="event_col"
    ratio_outcomes : dict[str, tuple[str, str]], optional
        Ratio metrics where both numerator and denominator contain randomness (e.g., leads per
        converter). Specify as ``{"metric_name": ("numerator_col", "denominator_col")}``.

        Uses OLS on the delta-method linearized metric (Deng et al. 2018):

        .. code-block:: text

            linearized_i = numerator_i - R_control * denominator_i
            where R_control = mean(numerator_control) / mean(denominator_control)

        This gives a statistically valid estimate of the difference in population-average
        ratios (E[num/den]), avoiding the selection bias of conditioning on converters.
        R_control is computed separately for each (treatment, control) comparison pair.
        Results appear alongside regular outcomes with ``effect_type="ratio_difference"``.
        By default None.

        Example::

            ratio_outcomes={"leads_per_converter": ("leads", "converters")}

    interaction_covariates : list[str], optional
        Covariates added to OLS formulas as a CUPED-style treatment interaction:
        ``z_{col} + treatment:z_{col}``. Each covariate is automatically centered and
        standardized (mean=0, std=1) so that the ``treatment`` coefficient is the ATE at
        the mean of the covariate — making it directly interpretable.

        Primary use case is **CUPED** (Controlled-experiment Using Pre-Experiment Data,
        Deng et al. 2013): pass the pre-experiment version of each outcome metric to
        reduce variance and increase statistical power. This is equivalent to Lin (2013)'s
        efficient regression estimator with per-group θ*.

        These columns are also subject to balance checks and do not need to be listed
        in ``balance_covariates`` separately. Must be numeric. By default None.

        Important notes:
        - Only applied for OLS models. For GLMs (logistic, Poisson, etc.) a warning is
          logged and the interactions are skipped — interactions on a log/logit scale do
          not produce the same variance reduction.
        - The point estimate (``absolute_effect``) will differ from the naive
          difference-in-means by a finite-sample correction θ* × (X̄_t − X̄_c). This is
          expected: the adjusted estimate is unbiased with lower variance and tends to
          shrink overestimated effects toward the true value.
        - Stacks with ``regression_covariates`` (additive) and all ``adjustment`` modes.
    """  # noqa: E501

    def __init__(
        self,
        data: pd.DataFrame,
        outcomes: list[str],
        treatment_col: str,
        experiment_identifier: list[str] | None = None,
        balance_covariates: list[str] | None = None,
        covariates: list[str] | None = None,
        adjustment: str | None = None,
        exp_sample_ratio: str | float | None = None,
        estimand: str = "ATT",
        balance_method: str = "ps-logistic",
        min_ps_score: float = 0.05,
        max_ps_score: float = 0.95,
        trim_ps: bool = False,
        trim_ps_lower: float = 0.1,
        trim_ps_upper: float = 0.9,
        trim_overlap_threshold: float | None = None,
        polynomial_ipw: bool = False,
        instrument_col: str | None = None,
        alpha: float = 0.05,
        regression_covariates: list[str] | None = None,
        assess_overlap: bool = False,
        overlap_plot: bool = False,
        unit_identifier: str | None = None,
        bootstrap: bool = False,
        bootstrap_iterations: int = 1000,
        bootstrap_ci_method: str = "percentile",
        bootstrap_pvalue_method: str = "studentized",
        bootstrap_stratify: bool = True,
        bootstrap_seed: int | None = None,
        skip_bootstrap_for_survival: bool = False,
        bootstrap_fixed_weights: bool = False,
        bootstrap_backend: str = "threading",
        prob_threshold_abs: float = 0.0,
        prob_threshold_rel: float = 0.0,
        rope_abs: tuple[float, float] | list[float] | None = None,
        rope_rel: tuple[float, float] | list[float] | None = None,
        treatment_comparisons: list[tuple] | None = None,
        correction: str | None = None,
        categorical_max_unique: int = 2,
        outcome_models: dict[str, str | list[str]] | str | list[str] | None = None,
        cluster_col: str | None = None,
        compute_marginal_effects: str | bool = True,
        min_binary_count: int = 10,
        store_fitted_models: bool = True,
        event_col: str | None = None,
        interaction_covariates: list[str] | None = None,
        ratio_outcomes: dict[str, tuple[str, str]] | None = None,
    ) -> None:
        self._logger = get_logger("Experiment Analyzer")
        self._data = data.copy()

        # process outcomes - can be strings or tuples for Cox models
        self._outcomes = []
        self._outcome_event_cols = {}  # Map outcome -> event_col for Cox models
        for outcome in self.__ensure_list(outcomes):
            if isinstance(outcome, tuple):
                # cox model: (time_col, event_col)
                if len(outcome) != 2:
                    log_and_raise_error(
                        self._logger,
                        f"Cox outcome tuple must have exactly 2 elements: (time_col, event_col). Got: {outcome}",
                    )
                time_col, event_col_name = outcome
                self._outcomes.append(time_col)
                self._outcome_event_cols[time_col] = event_col_name
            else:
                # regular outcome
                self._outcomes.append(outcome)

        if covariates is not None and balance_covariates is None:
            self._logger.warning("`covariates` is deprecated; use `balance_covariates` instead.")
            balance_covariates = covariates

        self._balance_covariates = self.__ensure_list(balance_covariates)
        self._treatment_col = treatment_col
        self._experiment_identifier = self.__ensure_list(experiment_identifier)
        self._adjustment = adjustment
        self._exp_sample_ratio_col = exp_sample_ratio
        self._balance_method = balance_method
        self._target_effect = estimand
        self._trim_ps = trim_ps
        self._trim_ps_lower = trim_ps_lower
        self._trim_ps_upper = trim_ps_upper
        self._trim_overlap_threshold = trim_overlap_threshold
        self._assess_overlap = assess_overlap
        self._overlap_plot = overlap_plot
        self._instrument_col = instrument_col
        self._regression_covariates = self.__ensure_list(regression_covariates)
        self._unit_identifier = unit_identifier

        self._bootstrap = bootstrap
        self._bootstrap_iterations = bootstrap_iterations
        self._bootstrap_ci_method = bootstrap_ci_method
        self._bootstrap_pvalue_method = bootstrap_pvalue_method
        self._bootstrap_stratify = bootstrap_stratify
        self._bootstrap_seed = bootstrap_seed
        self._skip_bootstrap_for_survival = skip_bootstrap_for_survival
        self._bootstrap_fixed_weights = bootstrap_fixed_weights
        self._bootstrap_backend = bootstrap_backend
        self._prob_threshold_abs = self.__validate_prob_threshold(prob_threshold_abs, "prob_threshold_abs")
        self._prob_threshold_rel = self.__validate_prob_threshold(prob_threshold_rel, "prob_threshold_rel")
        self._rope_abs = self.__validate_rope(rope_abs, "rope_abs")
        self._rope_rel = self.__validate_rope(rope_rel, "rope_rel")
        self._correction = correction
        self._treatment_comparisons = treatment_comparisons
        self._categorical_max_unique = categorical_max_unique
        self._outcome_models = outcome_models
        self._cluster_col = cluster_col
        self._compute_marginal_effects = compute_marginal_effects
        self._min_binary_count = min_binary_count
        self._store_fitted_models = store_fitted_models
        self._event_col = event_col
        self._interaction_covariates = self.__ensure_list(interaction_covariates)
        self._all_covariates = list(dict.fromkeys(self._balance_covariates + self._regression_covariates))

        # Validate and store ratio outcomes: {name: (numerator_col, denominator_col)}
        self._ratio_outcomes: dict[str, tuple[str, str]] = {}
        if ratio_outcomes:
            for name, pair in ratio_outcomes.items():
                if not (isinstance(pair, tuple | list) and len(pair) == 2):
                    log_and_raise_error(
                        self._logger,
                        f"ratio_outcomes['{name}'] must be a (numerator, denominator) tuple.",
                    )
                num_col, den_col = pair
                for col in (num_col, den_col):
                    if col not in self._data.columns:
                        log_and_raise_error(
                            self._logger,
                            f"Column '{col}' not found in data (required for ratio outcome '{name}').",
                        )
                self._ratio_outcomes[name] = (num_col, den_col)

        self.__check_input()
        self._alpha = alpha
        self._results = None
        self._balance = []
        self._adjusted_balance = []
        self._weights = None
        self._final_covariates = []
        self._fitted_models = {}
        self._bootstrap_distributions = {}  # Store bootstrap distributions for MCP adjustment
        self._bootstrap_indices_cache = {}  # Cache bootstrap indices for reuse across outcomes/models
        self.meta_stats_ = None  # Populated by combine_effects(); holds per-group heterogeneity diagnostics
        self._target_weights = {
            "ATT": "tips_stabilized_weight",
            "ATE": "ips_stabilized_weight",
            "ATC": "cips_stabilized_weight",
            "ATO": "overlap_weight",
        }  # noqa: E501

        if estimand == "ATO" and balance_method == "entropy":
            log_and_raise_error(
                self._logger,
                "estimand='ATO' (overlap weights) is not supported with balance_method='entropy'. "
                "Use 'ps-logistic' or 'ps-xgboost'.",
            )
        self._estimator = Estimators(
            treatment_col,
            instrument_col,
            estimand,
            self._target_weights,
            alpha,
            min_ps_score,
            max_ps_score,
            polynomial_ipw,
        )  # noqa: E501

    def __check_input(self) -> None:
        if self._data.empty:
            log_and_raise_error(self._logger, "Dataframe is empty!")

        string_cols = [c for c in self._all_covariates if pd.api.types.is_string_dtype(self._data[c])]
        if string_cols:
            self._logger.info(f"Detected categorical covariates (will create dummies): {string_cols}")

        if len(self._experiment_identifier) == 0:
            self._data["experiment_id"] = 1
            self._experiment_identifier = ["experiment_id"]
            self._logger.warning("No experiment identifier, assuming data is from a single experiment!")

        # Collect numerator and denominator columns for ratio outcomes
        ratio_raw_cols = [col for pair in self._ratio_outcomes.values() for col in pair]

        required_columns = (
            self._experiment_identifier
            + [self._treatment_col]
            + self._outcomes
            + list(self._outcome_event_cols.values())  # Event columns from tuple notation
            + self._all_covariates
            + ([self._instrument_col] if self._instrument_col is not None else [])
            + ([self._exp_sample_ratio_col] if isinstance(self._exp_sample_ratio_col, str) else [])
            + ([self._unit_identifier] if self._unit_identifier is not None else [])
            + ([self._cluster_col] if self._cluster_col is not None else [])
            + ([self._event_col] if self._event_col is not None else [])
            + (self._interaction_covariates if self._interaction_covariates else [])
            + ratio_raw_cols
        )

        missing_columns = set(required_columns) - set(self._data.columns)

        if missing_columns:
            log_and_raise_error(
                self._logger, f"The following required columns are missing from the dataframe: {missing_columns}"
            )  # noqa: E501

        no_covariates = len(self._all_covariates) == 0 and not self._interaction_covariates
        if no_covariates:
            self._logger.warning("No covariates specified, balance can't be assessed!")

        if self._outcome_models is not None:
            valid_models = {"ols", "logistic", "poisson", "negative_binomial", "cox"}
            if isinstance(self._outcome_models, dict):
                invalid_outcomes = set(self._outcome_models.keys()) - set(self._outcomes)
                if invalid_outcomes:
                    log_and_raise_error(
                        self._logger,
                        f"outcome_models contains invalid outcome names: {invalid_outcomes}. "
                        f"Valid outcomes: {self._outcomes}",
                    )
                all_invalid_models = set()
                for outcome, models in self._outcome_models.items():
                    if isinstance(models, str):
                        if models not in valid_models:
                            all_invalid_models.add(models)
                    elif isinstance(models, list):
                        if len(models) != len(set(models)):
                            log_and_raise_error(
                                self._logger, f"outcome_models for '{outcome}' contains duplicate models: {models}"
                            )
                        if len(models) == 0:
                            log_and_raise_error(self._logger, f"outcome_models for '{outcome}' cannot be an empty list")
                        for model in models:
                            if not isinstance(model, str):
                                log_and_raise_error(
                                    self._logger,
                                    f"outcome_models for '{outcome}' must contain strings. Got: {type(model)}",
                                )
                            if model not in valid_models:
                                all_invalid_models.add(model)
                    else:
                        log_and_raise_error(
                            self._logger,
                            f"outcome_models values must be str or list[str]. Got {type(models)} for '{outcome}'",
                        )
                if all_invalid_models:
                    log_and_raise_error(
                        self._logger,
                        f"outcome_models contains invalid model types: {all_invalid_models}. "
                        f"Valid models: {valid_models}",
                    )
            elif isinstance(self._outcome_models, str):
                if self._outcome_models not in valid_models:
                    log_and_raise_error(
                        self._logger,
                        f"outcome_models '{self._outcome_models}' is invalid. Valid models: {valid_models}",
                    )
            elif isinstance(self._outcome_models, list):
                if len(self._outcome_models) != len(set(self._outcome_models)):
                    log_and_raise_error(
                        self._logger, f"outcome_models list contains duplicates: {self._outcome_models}"
                    )
                if len(self._outcome_models) == 0:
                    log_and_raise_error(self._logger, "outcome_models cannot be an empty list")
                for model in self._outcome_models:
                    if not isinstance(model, str):
                        log_and_raise_error(
                            self._logger, f"outcome_models list must contain strings. Got: {type(model)}"
                        )
                    if model not in valid_models:
                        log_and_raise_error(
                            self._logger,
                            f"outcome_models contains invalid model type '{model}'. Valid models: {valid_models}",
                        )
            else:
                log_and_raise_error(
                    self._logger, f"outcome_models must be dict, str, list, or None. Got: {type(self._outcome_models)}"
                )

        if self._outcome_models is not None:
            models_to_check = []
            if isinstance(self._outcome_models, dict):
                for models in self._outcome_models.values():
                    if isinstance(models, str):
                        models_to_check.append(models)
                    elif isinstance(models, list):
                        models_to_check.extend(models)
            elif isinstance(self._outcome_models, str):
                models_to_check = [self._outcome_models]
            elif isinstance(self._outcome_models, list):
                models_to_check = self._outcome_models

            if "cox" in models_to_check:
                cox_outcomes = []
                if isinstance(self._outcome_models, dict):
                    for k, v in self._outcome_models.items():
                        if v == "cox" or (isinstance(v, list) and "cox" in v):
                            cox_outcomes.append(k)
                elif self._outcome_models == "cox" or (
                    isinstance(self._outcome_models, list) and "cox" in self._outcome_models
                ):
                    cox_outcomes = self._outcomes

                for outcome in cox_outcomes:
                    if outcome not in self._outcome_event_cols and self._event_col is None:
                        log_and_raise_error(
                            self._logger,
                            f"Cox model for outcome '{outcome}' requires event column. "
                            f"Use tuple notation: outcomes=[('{outcome}', 'event_col')] "
                            f"or set event_col parameter.",
                        )

        self._normalized_outcome_models = {}
        if self._outcome_models is not None:
            if isinstance(self._outcome_models, str):
                self._normalized_outcome_models = {outcome: [self._outcome_models] for outcome in self._outcomes}
            elif isinstance(self._outcome_models, list):
                self._normalized_outcome_models = {outcome: self._outcome_models.copy() for outcome in self._outcomes}
            elif isinstance(self._outcome_models, dict):
                for outcome in self._outcomes:
                    models = self._outcome_models.get(outcome, ["ols"])
                    if isinstance(models, str):
                        self._normalized_outcome_models[outcome] = [models]
                    else:
                        self._normalized_outcome_models[outcome] = models.copy()
        else:
            self._normalized_outcome_models = {outcome: ["ols"] for outcome in self._outcomes}

        valid_me_values = {False, "overall", "mean", "median", True}
        if self._compute_marginal_effects not in valid_me_values:
            log_and_raise_error(
                self._logger,
                f"compute_marginal_effects must be one of {valid_me_values}. Got: {self._compute_marginal_effects}",
            )
        if self._compute_marginal_effects is True:
            self._compute_marginal_effects = "overall"

        if self._interaction_covariates:
            missing_int = [c for c in self._interaction_covariates if c not in self._data.columns]
            if missing_int:
                self._logger.warning(
                    f"interaction_covariates columns not found in data and will be skipped: {missing_int}"
                )
                self._interaction_covariates = [c for c in self._interaction_covariates if c in self._data.columns]
            non_numeric_int = [
                c
                for c in self._interaction_covariates
                if c in self._data.columns and not pd.api.types.is_numeric_dtype(self._data[c])
            ]
            if non_numeric_int:
                log_and_raise_error(
                    self._logger,
                    f"interaction_covariates must be numeric columns. Non-numeric found: {non_numeric_int}",
                )

        self._data = self._data[list(dict.fromkeys(required_columns))]

    def __get_binary_covariates(self, data: pd.DataFrame, exclude_categoricals: set[str] = None) -> list[str]:
        """Get binary covariates, optionally excluding categorical columns that were converted to dummies.

        Only detects columns that are already natural binary indicators (values are {0, 1}).
        Numeric columns with 2 unique non-{0,1} values (e.g., {10.0, 11.0}) are handled
        by __get_categorical_covariates and dummy-encoded instead.
        """
        binary_covariates = []
        if exclude_categoricals is None:
            exclude_categoricals = set()
        for c in self._all_covariates:
            if c in exclude_categoricals:
                continue  # Skip categorical columns that are now dummies
            if data[c].nunique() == 2 and set(data[c].dropna().unique()) <= {0, 1}:
                binary_covariates.append(c)
        return binary_covariates

    def __get_numeric_covariates(self, data: pd.DataFrame, exclude_categoricals: set[str] = None) -> list[str]:
        """Get numeric covariates, optionally excluding categorical columns that were converted to dummies."""
        numeric_covariates = []
        if exclude_categoricals is None:
            exclude_categoricals = set()
        for c in self._all_covariates:
            if c in exclude_categoricals:
                continue  # Skip categorical columns that are now dummies
            if data[c].nunique() > 2:
                numeric_covariates.append(c)
        return numeric_covariates

    def __get_categorical_covariates(self, data: pd.DataFrame) -> dict[str, list]:
        """
        Detect categorical covariates and return their unique categories.

        This method wraps the shared detect_categorical_covariates function
        from utils.py for use within ExperimentAnalyzer.

        Detection rules:
        - object/category dtype columns
        - numeric columns (int or float) with 2 to categorical_max_unique unique values,
          excluding natural binary columns (values already {0, 1})

        Returns dict: {covariate_name: [list_of_categories]}
        """
        return detect_categorical_covariates(
            data=data,
            covariates=self._all_covariates,
            categorical_max_unique=self._categorical_max_unique,
        )

    def __create_dummy_variables(
        self,
        data: pd.DataFrame,
        categorical_info: dict[str, list],
        reference_categories: dict[str, any] | None = None,
        include_reference: bool = False,
    ) -> tuple[pd.DataFrame, dict[str, str], dict[str, any]]:
        """
        Create dummy variables for categorical covariates.

        Parameters
        ----------
        data : pd.DataFrame
            Input data
        categorical_info : dict
            Dict of {covariate: [categories]}
        reference_categories : dict, optional
            Dict of {covariate: reference_category}. If not provided, uses most frequent.
        include_reference : bool
            If True, include reference category dummy (for balance tables)
            If False, drop reference category (for regression models)

        Returns
        -------
        data : pd.DataFrame
            Data with dummy columns added
        dummy_cols_map : dict
            Mapping of {dummy_col_name: original_covariate}
        reference_map : dict
            Mapping of {covariate: reference_category_used}
        """
        dummy_cols_map = {}
        reference_map = {}

        for covariate, categories in categorical_info.items():
            if reference_categories and covariate in reference_categories:
                ref_cat = reference_categories[covariate]
                if ref_cat not in categories:
                    self._logger.warning(f"Reference category {ref_cat} not found in {covariate}, using most frequent")
                    ref_cat = data[covariate].value_counts().idxmax()
            else:
                ref_cat = data[covariate].value_counts().idxmax()

            reference_map[covariate] = ref_cat

            for cat in categories:
                if not include_reference and cat == ref_cat:
                    continue

                cat_clean = _clean_category_name(cat)
                dummy_col = f"{covariate}_{cat_clean}"
                data[dummy_col] = (data[covariate] == cat).astype(int)
                dummy_cols_map[dummy_col] = covariate

        return data, dummy_cols_map, reference_map

    def impute_missing_values(
        self, data: pd.DataFrame, num_covariates: list[str] | None = None, bin_covariates: list[str] | None = None
    ) -> pd.DataFrame:  # noqa: E501
        """
        Impute missing values for numeric and binary covariates.
        Optimized with vectorized operations for better performance.
        """
        # Vectorized imputation for numeric covariates
        if num_covariates:
            # Check for all-missing columns first
            for cov in num_covariates:
                if data[cov].isna().all():
                    log_and_raise_error(self._logger, f"Column {cov} has only missing values")

            # Vectorized fillna with means computed once
            means = data[num_covariates].mean()
            data[num_covariates] = data[num_covariates].fillna(means)

        # Vectorized imputation for binary covariates
        if bin_covariates:
            for cov in bin_covariates:
                if data[cov].isna().all():
                    log_and_raise_error(self._logger, f"Column {cov} has only missing values.")
                # Mode requires per-column calculation
                data[cov] = data[cov].fillna(data[cov].mode()[0])

        return data

    def __handle_missing_data(self, data: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
        """
        Handle missing data in treatment and categorical covariates.

        Missing data handling strategy:
        - Treatment column: Drop rows with missing values (REQUIRED)
        - Categorical covariates: Create explicit 'Missing' category

        Parameters
        ----------
        data : pd.DataFrame
            Input data

        Returns
        -------
        data : pd.DataFrame
            Data with missing values handled
        summary : dict
            Summary of missing data handling
        """
        original_n = len(data)
        rows_dropped = 0
        missing_info = []

        treatment_missing = data[self._treatment_col].isna().sum()
        if treatment_missing > 0:
            pct_missing = (treatment_missing / original_n) * 100
            self._logger.warning(
                f"Treatment column '{self._treatment_col}' has {treatment_missing} missing values "
                f"({pct_missing:.1f}%). Dropping these rows."
            )
            data = data[data[self._treatment_col].notna()].copy()
            rows_dropped += treatment_missing
            missing_info.append(f"treatment: {treatment_missing} rows")

        all_covs = list(dict.fromkeys(self._all_covariates + self._interaction_covariates))
        if all_covs:
            for cov in all_covs:
                if cov not in data.columns:
                    continue

                n_unique = data[cov].nunique()
                is_natural_binary = n_unique == 2 and set(data[cov].dropna().unique()) <= {0, 1}
                is_likely_categorical = (
                    pd.api.types.is_object_dtype(data[cov])
                    or isinstance(data[cov].dtype, pd.CategoricalDtype)
                    or (
                        pd.api.types.is_numeric_dtype(data[cov])
                        and 2 <= n_unique <= self._categorical_max_unique
                        and not is_natural_binary
                    )
                )

                cov_missing = data[cov].isna().sum()
                if cov_missing > 0 and is_likely_categorical:
                    pct_missing = (cov_missing / len(data)) * 100
                    self._logger.warning(
                        f"Categorical covariate '{cov}' has {cov_missing} missing values "
                        f"({pct_missing:.1f}%). Creating explicit 'Missing' category."
                    )
                    data[cov] = data[cov].fillna("Missing")
                    missing_info.append(f"{cov}: {cov_missing} values")

        summary = {
            "rows_dropped": rows_dropped,
            "pct_dropped": (rows_dropped / original_n * 100) if original_n > 0 else 0,
            "missing_details": missing_info,
        }

        return data, summary

    def standardize_covariates(self, data: pd.DataFrame, covariates: list[str]) -> pd.DataFrame:
        """
        Standardize covariates in the data.
        Optimized with vectorized operations for better performance.

        Parameters
        ----------
        data : pd.DataFrame
            Data to standardize
        covariates : list[str]
            List of covariates to standardize

        Returns
        -------
        pd.DataFrame
            Data with standardized covariates
        """
        if not covariates:
            return data

        # Vectorized standardization: compute all means and stds at once
        subset = data[covariates]
        means = subset.mean()
        stds = subset.std()
        standardized = (subset - means) / stds

        # Add z_ prefix to column names
        standardized.columns = [f"z_{c}" for c in covariates]

        # Assign standardized columns back to data
        for col in standardized.columns:
            data[col] = standardized[col]

        return data

    def calculate_smd(
        self,
        data: pd.DataFrame,
        treatment_col: str = None,
        covariates: list[str] | None = None,
        weights_col: str = "weights",
        threshold: float = 0.1,
    ) -> pd.DataFrame:  # noqa: E501
        """
        Calculate standardized mean differences (SMDs) between treatment and control groups.

        Parameters
        ----------
        data : DataFrame, optional
            DataFrame containing the data to calculate SMDs on. If None, uses the data from the class.
        treatment_col : str, optional
            Name of the column containing the treatment assignment.
        covariates : list, optional
            List of column names to calculate SMDs for. If None, uses all numeric and binary covariates.
        weights_col : str, optional
            Name of the column to use for weighting the means. Defaults to 'weights'.
        threshold : float, optional
            Threshold to determine if a covariate is balanced. Defaults to 0.1.

        Returns
        -------
        DataFrame
            DataFrame containing the SMDs and balance flags for each covariate.
        """

        if treatment_col is None:
            treatment_col = self._treatment_col

        treated = data[data[treatment_col] == 1]
        control = data[data[treatment_col] == 0]

        if covariates is None:
            covariates = self._final_covariates

        smd_results = []
        for cov in covariates:
            mean_treated = np.average(treated[cov], weights=treated[weights_col])
            mean_control = np.average(control[cov], weights=control[weights_col])

            var_treated = np.average((treated[cov] - mean_treated) ** 2, weights=treated[weights_col])
            var_control = np.average((control[cov] - mean_control) ** 2, weights=control[weights_col])

            pooled_std = np.sqrt((var_treated + var_control) / 2)

            smd = (mean_treated - mean_control) / pooled_std if pooled_std != 0 else 0

            balance_flag = 1 if abs(smd) <= threshold else 0

            smd_results.append(
                {
                    "covariate": cov,
                    "mean_treated": mean_treated,
                    "mean_control": mean_control,
                    "smd": smd,
                    "balance_flag": balance_flag,
                }
            )

        smd_df = pd.DataFrame(smd_results)

        return smd_df

    def __get_estimator_function(self, model_type: str, adjustment: str | None, outcome: str):
        """
        Get the appropriate estimator function based on model type and adjustment.

        Parameters
        ----------
        model_type : str
            Model type: 'ols', 'logistic', 'poisson', 'negative_binomial', 'cox'
        adjustment : str | None
            Adjustment type: None, 'balance', 'IV'
        outcome : str
            Outcome name (for error messages)

        Returns
        -------
        callable
            Estimator function
        """
        if adjustment == "IV" and model_type != "ols":
            self._logger.warning(
                f"IV adjustment not supported for {model_type} model. "
                f"Falling back to unadjusted estimation for outcome '{outcome}'."
            )
            adjustment = None

        if adjustment == "aipw" and model_type == "cox":
            self._logger.warning(
                "AIPW adjustment not supported for Cox survival models "
                "(requires specialized survival AIPW methodology). "
                f"Falling back to unadjusted estimation for outcome '{outcome}'."
            )
            adjustment = None

        if adjustment == "balance" and model_type == "cox":
            regression_covs_for_outcome = set(self._final_covariates) & set(self._regression_covariates)
            if len(regression_covs_for_outcome) == 0:
                self._logger.warning(
                    "IPW without regression covariates for Cox models estimates the marginal hazard ratio, "
                    "which differs from the conditional HR due to non-collapsibility of the hazard ratio. "
                    "Consider adding regression_covariates for IPW+Regression to recover the conditional HR."
                )

        estimator_map = {
            ("ols", None): self._estimator.linear_regression,
            ("ols", "balance"): self._estimator.weighted_least_squares,
            ("ols", "IV"): self._estimator.iv_regression,
            ("ols", "aipw"): self._estimator.aipw_ols,
            ("logistic", None): self._estimator.logistic_regression,
            ("logistic", "balance"): self._estimator.weighted_logistic_regression,
            ("logistic", "aipw"): self._estimator.aipw_logistic,
            ("poisson", None): self._estimator.poisson_regression,
            ("poisson", "balance"): self._estimator.weighted_poisson_regression,
            ("poisson", "aipw"): self._estimator.aipw_poisson,
            ("negative_binomial", None): self._estimator.negative_binomial_regression,
            ("negative_binomial", "balance"): self._estimator.weighted_negative_binomial_regression,
            ("negative_binomial", "aipw"): self._estimator.aipw_negative_binomial,
            ("cox", None): self._estimator.cox_proportional_hazards,
            ("cox", "balance"): self._estimator.weighted_cox_proportional_hazards,
        }

        key = (model_type, adjustment)
        if key not in estimator_map:
            log_and_raise_error(
                self._logger, f"No estimator found for model_type='{model_type}' with adjustment='{adjustment}'"
            )

        return estimator_map[key]

    def get_overlap_coefficient(
        self,
        treatment_scores: np.ndarray,
        control_scores: np.ndarray,
        grid_points: int = 1000,
        bw_method: float | None = None,
    ) -> float:  # noqa: E501
        """
        Calculate the Overlap Coefficient between treatment and control propensity scores.

        Parameters
        ----------
        treatment_scores : array-like
            Array of treatment propensity scores.
        control_scores : array-like
            Array of control propensity scores.
        grid_points : int, optional
            number of points to evaluate KDE on (default is 10000 for higher resolution)
        bw_method : float, optional
            Bandwidth method for the KDE estimation. Defaults to 0.1

        Returns
        -------
        float
        """

        kde_treatment = gaussian_kde(treatment_scores, bw_method=bw_method)
        kde_control = gaussian_kde(control_scores, bw_method=bw_method)

        min_score = min(treatment_scores.min(), control_scores.min())
        max_score = max(treatment_scores.max(), control_scores.max())
        x_grid = np.linspace(min_score, max_score, grid_points)
        kde_treatment_values = kde_treatment(x_grid)
        kde_control_values = kde_control(x_grid)

        overlap_coefficient = np.trapz(np.minimum(kde_treatment_values, kde_control_values), x_grid)

        return overlap_coefficient

    def get_effects(
        self,
        min_binary_count: int | None = None,
        adjustment: str | None = None,
        bootstrap: bool | None = None,
        compute_marginal_effects: str | bool | None = None,
    ) -> None:
        """ "
        Calculate effects (uplifts), given the data and experimental units.

        Parameters
        ----------
        min_binary_count : int, optional
            The minimum number of observations required for a binary covariate to be included
            in the analysis. If None, uses the value set in __init__ (default 10).
        adjustment : str, optional
            The type of adjustment to apply to estimation: 'IPW', 'IV'. Default is None.
        bootstrap : bool, optional
            Whether to use bootstrap inference. If None, uses the value set in __init__. Default is None.
        compute_marginal_effects : str | bool | None, optional
            Override the marginal effects setting from __init__. If None, uses the value set in __init__.
            - "overall": Average Marginal Effect (AME)
            - "mean": Marginal Effect at the Mean (MEM)
            - "median": Marginal effect at median
            - True: Same as "overall"
            - False: Return odds ratios / rate ratios

        Updates
        -------
        self._results: A Pandas DataFrame with effects.
        self._balance: A list of Pandas DataFrames with balance metrics per experiment.
        self._adjusted_balance: A list of Pandas DataFrames with adjusted balance metrics per experiment.

        Results
        -------
        The results are stored in self._results, which contains the following columns:
        - experiment: The experiment identifier.
        - outcome: The outcome variable.
        - treatment_group: The treatment/comparison group.
        - control_group: The control/reference group.
        - sample_ratio: The sample ratio of the treatment group to the control group.
        - adjustment: The type of adjustment applied.
        - method: The balance method used (when adjustment is "balance" or "aipw").
        - estimand: The target estimand (ATT, ATE, ATC, ATO) when using IPW (only present for "balance" or "aipw").
        - balance: The balance metric for the covariates (when applicable).
        - inference_method: "asymptotic" or "bootstrap"
        - model_type: Type of statistical model used ("ols", "logistic", "poisson", "negative_binomial", "cox")
        - effect_type: Type of effect reported in absolute_effect column.
          - "mean_difference": OLS models (difference in means)
          - "probability_change": Logistic with marginal effects (percentage points)
          - "count_change": Poisson/NegBin with marginal effects (change in expected count)
          - "log_hazard_ratio": Cox models (log HR, the coefficient)
          - "log_odds": Logistic without marginal effects (log odds, the coefficient)
          - "log_rate_ratio": Poisson/NegBin without marginal effects (log IRR, the coefficient)
        - treatment_units: The number of units in the treatment group.
        - control_units: The number of units in the control group.
        - control_value: The mean value of the outcome variable in the control group.
        - treatment_value: The mean value of the outcome variable in the treatment group.
        - absolute_effect: The absolute effect of the treatment vs control.
        - standard_error: The standard error of the effect estimate.
        - pvalue: The p-value of the effect estimate.
        - stat_significance: The statistical significance of the effect.
        - abs_effect_lower: Lower bound of absolute effect CI.
        - abs_effect_upper: Upper bound of absolute effect CI.
        - relative_effect: The relative effect of the treatment.
        - rel_effect_lower: Lower bound of relative effect CI (if available).
        - rel_effect_upper: Upper bound of relative effect CI (if available).
        - srm_detected: Whether sample ratio mismatch was detected.
        - srm_pvalue: The p-value for the sample ratio mismatch test.

        Bootstrap-only columns (emitted when bootstrap=True):
        - prob_abs_effect_gt: P(absolute_effect > prob_threshold_abs).
        - prob_rel_effect_gt: P(relative_effect > prob_threshold_rel).
        - prob_abs_effect_in_rope / _above_rope / _below_rope: probability mass of
          the absolute effect inside / above / below rope_abs (NaN if rope_abs is None).
        - prob_rel_effect_in_rope / _above_rope / _below_rope: same for the relative
          effect and rope_rel (NaN if rope_rel is None).

        Note:
        - Columns with all NaN values are automatically removed from results.
        - Model-specific metrics (odds_ratio, hazard_ratio, etc.) are not included in results.
        - Use effect_type to understand what absolute_effect and relative_effect represent.
        """  # noqa: E501

        if compute_marginal_effects is not None:
            valid_me_values = {False, "overall", "mean", "median", True}
            if compute_marginal_effects not in valid_me_values:
                log_and_raise_error(
                    self._logger,
                    f"compute_marginal_effects must be one of {valid_me_values}. Got: {compute_marginal_effects}",
                )
            if compute_marginal_effects is True:
                compute_marginal_effects = "overall"
            me_setting = compute_marginal_effects
        else:
            me_setting = self._compute_marginal_effects

        if min_binary_count is None:
            min_binary_count = self._min_binary_count

        get_balance_method = self._estimator.get_balance_method

        temp_results = []
        output = {}
        weights_list = []

        if adjustment is None:
            adjustment = self._adjustment

        if bootstrap is not None:
            original_bootstrap = self._bootstrap
            self._bootstrap = bootstrap
        else:
            original_bootstrap = None

        self._balance = []
        self._adjusted_balance = []

        if self._experiment_identifier:
            grouped_data = self._data.groupby(self._experiment_identifier)
        else:
            grouped_data = [(None, self._data)]

        for experiment_tuple, temp_pd in grouped_data:
            if experiment_tuple is None:
                self._logger.info("Processing experiment")
            elif isinstance(experiment_tuple, tuple):
                if len(experiment_tuple) == 1:
                    self._logger.info(f"Processing experiment: {experiment_tuple[0]}")
                else:
                    self._logger.info(f"Processing experiment: {experiment_tuple}")
            else:
                self._logger.info(f"Processing experiment: {experiment_tuple}")

            if self._correction:
                self._logger.info(f"P-value adjustment: {self._correction}")
            final_covariates = []

            temp_pd, missing_summary = self.__handle_missing_data(temp_pd)
            if missing_summary["rows_dropped"] > 0:
                self._logger.warning(
                    f"Dropped {missing_summary['rows_dropped']} rows due to missing values "
                    f"({missing_summary['pct_dropped']:.1f}% of data)"
                )

            categorical_info = self.__get_categorical_covariates(data=temp_pd)
            dummy_map = {}
            ref_map = {}
            categorical_col_names = set()

            if categorical_info:
                categorical_col_names = set(categorical_info.keys())
                temp_pd, dummy_map, ref_map = self.__create_dummy_variables(
                    data=temp_pd,
                    categorical_info=categorical_info,
                    reference_categories=None,
                    include_reference=False,
                )
                self._logger.info(
                    f"Created {len(dummy_map)} dummy variables from {len(categorical_info)} categorical covariates"
                )
                for cov, ref in ref_map.items():
                    self._logger.info(f"  {cov}: reference category = {ref}")

            numeric_covariates = self.__get_numeric_covariates(data=temp_pd, exclude_categoricals=categorical_col_names)
            binary_covariates = self.__get_binary_covariates(data=temp_pd, exclude_categoricals=categorical_col_names)

            if dummy_map:
                binary_covariates.extend(list(dummy_map.keys()))

            treatvalues = set(temp_pd[self._treatment_col].unique())
            if len(treatvalues) < 2:
                self._logger.warning(f"Skipping {experiment_tuple} as there are not enough treatment groups!")
                continue

            comparison_pairs = self.__get_comparison_pairs(treatvalues, temp_pd)
            if not comparison_pairs:
                self._logger.warning(f"Skipping {experiment_tuple} as no valid comparison pairs were found!")
                continue

            for treatment_val, control_val in comparison_pairs:
                self._logger.info(f"Processing comparison: {treatment_val} vs {control_val}")

                comparison_data = temp_pd[temp_pd[self._treatment_col].isin([treatment_val, control_val])].copy()

                if comparison_data.empty:
                    self._logger.warning(f"No data for comparison {treatment_val} vs {control_val}. Skipping.")
                    continue

                # Check if we have both treatment and control groups before proceeding
                n_treatment_before = (comparison_data[self._treatment_col] == treatment_val).sum()
                n_control_before = (comparison_data[self._treatment_col] == control_val).sum()

                if n_treatment_before == 0:
                    self._logger.warning(
                        f"No treatment units ({treatment_val}) found for comparison {treatment_val} vs {control_val}. "
                        f"Cannot estimate treatment effect. Skipping."
                    )
                    continue

                if n_control_before == 0:
                    self._logger.warning(
                        f"No control units ({control_val}) found for comparison {treatment_val} vs {control_val}. "
                        f"Cannot estimate treatment effect. Skipping."
                    )
                    continue

                comparison_data[self._treatment_col] = (comparison_data[self._treatment_col] == treatment_val).astype(
                    int
                )

                sample_ratio, srm_detected, srm_pvalue = self.__check_sample_ratio_mismatch(comparison_data)

                comparison_data = self.impute_missing_values(
                    data=comparison_data.copy(),
                    num_covariates=numeric_covariates,
                    bin_covariates=binary_covariates,
                )

                comp_numeric_covariates = [c for c in numeric_covariates if comparison_data[c].std(ddof=0) != 0]
                comp_binary_covariates = [c for c in binary_covariates if comparison_data[c].sum() >= min_binary_count]
                comp_binary_covariates = [c for c in comp_binary_covariates if comparison_data[c].std(ddof=0) != 0]

                # exclude dummies that only appear in one treatment group
                removed_single_group = []
                if dummy_map:
                    treated_mask = comparison_data[self._treatment_col] == 1
                    control_mask = comparison_data[self._treatment_col] == 0
                    comp_binary_covariates_filtered = []
                    for c in comp_binary_covariates:
                        if c in dummy_map:
                            t_sum = comparison_data.loc[treated_mask, c].sum()
                            c_sum = comparison_data.loc[control_mask, c].sum()
                            if t_sum > 0 and c_sum > 0:
                                comp_binary_covariates_filtered.append(c)
                            else:
                                removed_single_group.append(c)
                        else:
                            comp_binary_covariates_filtered.append(c)
                    comp_binary_covariates = comp_binary_covariates_filtered

                removed_numeric_var = set(numeric_covariates) - set(comp_numeric_covariates)
                removed_binary_freq = [c for c in binary_covariates if comparison_data[c].sum() < min_binary_count]
                removed_binary_var = [
                    c for c in binary_covariates if c not in removed_binary_freq and comparison_data[c].std(ddof=0) == 0
                ]

                final_covariates = comp_numeric_covariates + comp_binary_covariates
                self._final_covariates = final_covariates

                if removed_numeric_var or removed_binary_freq or removed_binary_var or removed_single_group:
                    self._logger.warning(f"Removed covariates for comparison {treatment_val} vs {control_val}:")
                    if removed_numeric_var:
                        self._logger.warning(f"  - Zero variance (numeric): {sorted(removed_numeric_var)}")
                    if removed_binary_freq:
                        self._logger.warning(f"  - Low frequency (< {min_binary_count}): {sorted(removed_binary_freq)}")
                    if removed_binary_var:
                        self._logger.warning(f"  - Zero variance (binary): {sorted(removed_binary_var)}")
                    if removed_single_group:
                        self._logger.warning(f"  - Single group only (dummy): {sorted(removed_single_group)}")

                # Valid interaction covariates for balance display (non-zero variance in this comparison)
                active_int_covs_for_balance = [
                    c
                    for c in self._interaction_covariates
                    if c in comparison_data.columns and comparison_data[c].std(ddof=0) != 0
                ]
                # balance_final_covariates extends final_covariates with interaction covariates for SMD only
                balance_final_covariates = list(dict.fromkeys(final_covariates + active_int_covs_for_balance))

                has_any_covariates = bool(self._all_covariates or self._interaction_covariates)
                if len(balance_final_covariates) == 0 and has_any_covariates:
                    self._logger.warning(
                        f"No valid covariates for comparison {treatment_val} vs {control_val}, "
                        f"balance can't be assessed!"
                    )

                balance = pd.DataFrame()
                adjusted_balance = pd.DataFrame()

                if len(balance_final_covariates) > 0 or categorical_info:
                    comparison_data["weights"] = 1

                    if categorical_info:
                        comparison_data_balance = comparison_data.copy()
                        comparison_data_balance, _, _ = self.__create_dummy_variables(
                            data=comparison_data_balance,
                            categorical_info=categorical_info,
                            reference_categories=ref_map,  # Use same references as models
                            include_reference=True,  # Include all for balance
                        )

                        balance_covariates = []

                        for cov in categorical_info.keys():
                            for cat in categorical_info[cov]:
                                cat_clean = _clean_category_name(cat)
                                dummy_col = f"{cov}_{cat_clean}"
                                if dummy_col in comparison_data_balance.columns:
                                    if comparison_data_balance[dummy_col].sum() >= min_binary_count:
                                        if comparison_data_balance[dummy_col].std(ddof=0) != 0:
                                            # Also check that dummy appears in both treatment and control groups
                                            treated_sum = comparison_data_balance[
                                                comparison_data_balance[self._treatment_col] == 1
                                            ][dummy_col].sum()
                                            control_sum = comparison_data_balance[
                                                comparison_data_balance[self._treatment_col] == 0
                                            ][dummy_col].sum()
                                            if treated_sum > 0 and control_sum > 0:
                                                balance_covariates.append(dummy_col)

                        for cov in balance_final_covariates:
                            if cov not in balance_covariates:
                                balance_covariates.append(cov)

                        if balance_covariates:
                            comparison_data_balance = self.standardize_covariates(
                                comparison_data_balance, balance_covariates
                            )
                            balance = self.calculate_smd(data=comparison_data_balance, covariates=balance_covariates)

                        if len(final_covariates) > 0:
                            comparison_data = self.standardize_covariates(comparison_data, final_covariates)
                    else:
                        comparison_data = self.standardize_covariates(comparison_data, balance_final_covariates)
                        balance = self.calculate_smd(data=comparison_data, covariates=balance_final_covariates)

                    if not balance.empty:
                        balance["experiment"] = [experiment_tuple] * balance.shape[0]
                        balance = self.__transform_tuple_column(balance, "experiment", self._experiment_identifier)
                        self._balance.append(balance)
                        balance_mean = balance["balance_flag"].mean()
                        self._logger.info(f"Balance: {balance_mean:.2%}")

                n_trimmed = 0

                if len(final_covariates) > 0 and adjustment in ("balance", "aipw"):
                    balance_func = get_balance_method(self._balance_method)
                    comparison_data = balance_func(
                        data=comparison_data, covariates=[f"z_{cov}" for cov in final_covariates]
                    )

                    # PS trimming: drop units with extreme propensity scores and recompute weights.
                    # Only applicable for PS-based balance methods (not entropy balancing).
                    if (
                        self._trim_ps
                        and self._balance_method in ("ps-logistic", "ps-xgboost")
                        and "propensity_score" in comparison_data.columns
                    ):
                        should_trim = True
                        if self._trim_overlap_threshold is not None:
                            treat_ps = comparison_data.loc[
                                comparison_data[self._treatment_col] == 1, "propensity_score"
                            ].values
                            ctrl_ps = comparison_data.loc[
                                comparison_data[self._treatment_col] == 0, "propensity_score"
                            ].values
                            if len(treat_ps) > 0 and len(ctrl_ps) > 0:
                                oc = self.get_overlap_coefficient(treat_ps, ctrl_ps)
                                self._logger.info(f"Overlap coefficient before trimming: {oc:.3f}")
                                should_trim = oc >= self._trim_overlap_threshold
                                if not should_trim:
                                    self._logger.info(
                                        f"Trimming skipped: overlap ({oc:.3f}) below threshold "
                                        f"({self._trim_overlap_threshold})."
                                    )
                            else:
                                should_trim = False

                        if should_trim:
                            n_before = len(comparison_data)
                            mask = comparison_data["propensity_score"].between(self._trim_ps_lower, self._trim_ps_upper)
                            comparison_data = comparison_data[mask].copy()
                            n_trimmed = n_before - len(comparison_data)
                            self._logger.info(
                                f"PS trimming [{self._trim_ps_lower}, {self._trim_ps_upper}]: "
                                f"dropped {n_trimmed} units ({n_trimmed / n_before:.1%}), "
                                f"{len(comparison_data)} remain."
                            )
                            # Recompute weights on the trimmed sample (marginal treatment
                            # probability changes when units are dropped).
                            comparison_data = self._estimator._calculate_stabilized_weights(comparison_data)

                    adjusted_balance = self.calculate_smd(
                        data=comparison_data,
                        covariates=final_covariates,
                        weights_col=self._target_weights[self._target_effect],
                    )
                    adjusted_balance["experiment"] = [experiment_tuple] * adjusted_balance.shape[0]
                    adjusted_balance = self.__transform_tuple_column(
                        adjusted_balance, "experiment", self._experiment_identifier
                    )
                    self._adjusted_balance.append(adjusted_balance)
                    adj_balance_mean = adjusted_balance["balance_flag"].mean() if not adjusted_balance.empty else np.nan
                    self._logger.info(f"Adjusted balance: {adj_balance_mean:.2%}")

                    # When using entropy balancing, compute propensity scores via
                    # logistic regression for overlap diagnostics only (not for weighting).
                    if "propensity_score" not in comparison_data.columns and (
                        self._assess_overlap or self._overlap_plot
                    ):
                        try:
                            from sklearn.linear_model import LogisticRegression

                            z_covs = [f"z_{cov}" for cov in final_covariates]
                            X_diag = comparison_data[z_covs]
                            y_diag = comparison_data[self._treatment_col]
                            lr = LogisticRegression(max_iter=1000)
                            lr.fit(X_diag, y_diag)
                            comparison_data["propensity_score"] = lr.predict_proba(X_diag)[:, 1]
                            self._logger.info(
                                "Computed propensity scores via logistic regression for overlap diagnostics "
                                "(entropy balancing weights used for estimation)."
                            )
                        except Exception as e:
                            self._logger.warning(f"Could not compute diagnostic propensity scores for overlap: {e}")

                    if self._assess_overlap:
                        if "propensity_score" in comparison_data.columns:
                            treatment_scores = comparison_data.loc[
                                comparison_data[self._treatment_col] == 1, "propensity_score"
                            ]
                            control_scores = comparison_data.loc[
                                comparison_data[self._treatment_col] == 0, "propensity_score"
                            ]
                            if not treatment_scores.empty and not control_scores.empty:
                                overlap = self.get_overlap_coefficient(treatment_scores.values, control_scores.values)
                                self._logger.info("::::: Overlap: %.2f", np.round(overlap, 2))
                            else:
                                self._logger.warning(
                                    "Could not calculate overlap due to missing scores for treatment or control."
                                )  # noqa: E501
                        else:
                            self._logger.warning("Propensity score column not found, skipping overlap assessment.")
                    if self._overlap_plot:
                        # Check if overlap plot can be generated (requires propensity scores from balance adjustment)
                        if adjustment not in ("balance", "aipw") or len(final_covariates) == 0:
                            self._logger.warning(
                                "Overlap plot requested but no balance adjustment method or covariates specified. "
                                "Overlap plots require propensity scores from balance adjustment. Skipping plot."
                            )
                        elif "propensity_score" in comparison_data.columns:
                            from .plotting import plot_overlap

                            exp_label = (
                                " | ".join(str(v) for v in experiment_tuple)
                                if isinstance(experiment_tuple, tuple)
                                else str(experiment_tuple)
                            )
                            plot_overlap(
                                comparison_data,
                                treatment_col=self._treatment_col,
                                propensity_col="propensity_score",
                                title=f"Common Support — {exp_label}",
                            )
                        else:
                            self._logger.warning("Propensity score column not found, skipping overlap plot.")
                elif len(final_covariates) == 0 and adjustment in ("balance", "aipw"):
                    # No covariates to balance on: assign uniform weights so the pipeline
                    # proceeds without error and produces results equivalent to unadjusted analysis.
                    weight_col = self._target_weights[self._target_effect]
                    comparison_data[weight_col] = 1.0
                    self._logger.info(
                        "No covariates for balance adjustment — assigning uniform weights (1.0). "
                        "Results will be equivalent to unadjusted analysis."
                    )

                if len(final_covariates) > 0 and adjustment == "balance":
                    weight_col = self._target_weights[self._target_effect]
                    if weight_col in comparison_data.columns:
                        weight_columns = [*self._experiment_identifier, weight_col]
                        if self._unit_identifier and self._unit_identifier in comparison_data.columns:
                            weight_columns.insert(-1, self._unit_identifier)
                        weights_df = comparison_data[weight_columns].copy()
                        weights_df["treatment_group"] = treatment_val
                        weights_df["control_group"] = control_val
                        weights_df[self._treatment_col] = comparison_data[self._treatment_col].values
                        if "propensity_score" in comparison_data.columns:
                            weights_df["propensity_score"] = comparison_data["propensity_score"].values
                        weights_list.append(weights_df)

                if len(final_covariates) > 0 and adjustment == "IV":
                    if self._instrument_col is None:
                        log_and_raise_error(self._logger, "Instrument column is required for IV estimation!")
                    iv_balance = self.calculate_smd(
                        data=comparison_data, treatment_col=self._instrument_col, covariates=final_covariates
                    )
                    iv_balance_mean = iv_balance["balance_flag"].mean() if not iv_balance.empty else np.nan
                    self._logger.info(f"IV Balance: {iv_balance_mean:.2%}")

                if adjustment == "aipw":
                    # AIPW always uses all covariates in the outcome model
                    relevant_covariates = set(self._final_covariates)
                else:
                    relevant_covariates = set(self._final_covariates) & set(self._regression_covariates)

                adjustment_labels = {"balance": "balance", "IV": "IV", "aipw": "aipw"}
                has_interactions = bool(self._interaction_covariates)

                if adjustment == "aipw":
                    adjustment_label = "aipw"
                elif adjustment in adjustment_labels and len(relevant_covariates) > 0:
                    adjustment_label = adjustment_labels[adjustment] + "+regression"
                elif adjustment in adjustment_labels:
                    adjustment_label = adjustment_labels[adjustment]
                elif len(relevant_covariates) > 0:
                    adjustment_label = "regression"
                else:
                    adjustment_label = "no adjustment"

                if has_interactions:
                    if adjustment_label == "no adjustment":
                        adjustment_label = "regression"
                    adjustment_label += "+interactions"

                # Compute linearized ratio metrics for this comparison (delta method).
                # For each ratio outcome Y/X, the linearized metric is:
                #   lin_i = Y_i - R_control * X_i   where R_control = mean(Y_control) / mean(X_control)
                # OLS on lin_i estimates the difference in ratios with correct variance.
                _ratio_lin_cols: dict[str, tuple[str, str, str, float]] = {}  # lin_col -> (name, num, den, R)
                _c_mask = comparison_data[self._treatment_col] == 0
                for _ratio_name, (_num_col, _den_col) in self._ratio_outcomes.items():
                    _den_ctrl_mean = comparison_data.loc[_c_mask, _den_col].mean()
                    if _den_ctrl_mean == 0 or np.isnan(_den_ctrl_mean):
                        self._logger.warning(
                            f"Denominator mean is 0 or NaN for ratio outcome '{_ratio_name}' "
                            f"in comparison {treatment_val} vs {control_val}. Skipping."
                        )
                        continue
                    _R = comparison_data.loc[_c_mask, _num_col].mean() / _den_ctrl_mean
                    _lin_col = f"__ratio_lin_{_ratio_name}"
                    # Divide by den_ctrl_mean so OLS coefficient ≈ R_t - R_c.
                    # Without scaling the coefficient equals (R_t - R_c) * mu_X_t, not the ratio difference.
                    comparison_data[_lin_col] = (
                        comparison_data[_num_col] - _R * comparison_data[_den_col]
                    ) / _den_ctrl_mean
                    _ratio_lin_cols[_lin_col] = (_ratio_name, _num_col, _den_col, _R)

                _all_outcomes = list(self._outcomes) + list(_ratio_lin_cols.keys())

                for outcome in _all_outcomes:
                    _is_ratio = outcome in _ratio_lin_cols
                    if not pd.api.types.is_numeric_dtype(comparison_data[outcome]):
                        self._logger.warning(
                            f"Outcome '{outcome}' is not numeric for comparison {treatment_val} vs {control_val}. "
                            f"Skipping."
                        )
                        continue
                    if comparison_data[outcome].var() == 0:
                        self._logger.warning(
                            f"Outcome '{outcome}' has zero variance for comparison {treatment_val} vs {control_val}. "
                            f"Skipping."
                        )
                        continue

                    # Ratio outcomes always use OLS on the linearized column
                    model_types = ["ols"] if _is_ratio else self._normalized_outcome_models.get(outcome, ["ols"])

                    for model_type in model_types:
                        # Auto-detect binary outcomes: when using AIPW with OLS on a binary outcome,
                        # switch to logistic to avoid predicted values outside [0, 1]
                        if (
                            adjustment == "aipw"
                            and model_type == "ols"
                            and comparison_data[outcome].dropna().isin([0, 1]).all()
                        ):
                            self._logger.info(
                                f"Outcome '{outcome}' is binary — switching from OLS to logistic for AIPW "
                                f"to ensure predicted values stay within [0, 1]."
                            )
                            model_type = "logistic"

                        estimator_func = self.__get_estimator_function(model_type, adjustment, outcome)

                        try:
                            estimator_params = {
                                "data": comparison_data,
                                "outcome_variable": outcome,
                                "covariates": list(relevant_covariates),
                                "cluster_col": self._cluster_col,
                                "store_model": self._store_fitted_models,
                                # Skip Fieller CI when bootstrap is enabled (CIs come from percentiles)
                                "compute_relative_ci": not self._bootstrap,
                            }

                            if model_type in ["logistic", "poisson", "negative_binomial"]:
                                estimator_params["compute_marginal_effects"] = me_setting

                            if model_type == "cox":
                                if outcome in self._outcome_event_cols:
                                    estimator_params["event_col"] = self._outcome_event_cols[outcome]
                                elif self._event_col:
                                    estimator_params["event_col"] = self._event_col
                                else:
                                    log_and_raise_error(
                                        self._logger,
                                        f"Cox model for outcome '{outcome}' requires event column. "
                                        f"Use tuple notation: outcomes=[('{outcome}', 'event_col')] "
                                        f"or set event_col parameter.",
                                    )

                            if adjustment == "balance":
                                weight_col = self._target_weights[self._target_effect]
                                if weight_col not in comparison_data.columns:
                                    log_and_raise_error(
                                        self._logger,
                                        f"Weight column '{weight_col}' not found after balance calculation.",
                                    )
                                if len(final_covariates) > 0 and comparison_data[weight_col].var() == 0:
                                    self._logger.warning(
                                        f"Weight column '{weight_col}' has zero variance for comparison {treatment_val} vs {control_val}. Results might be unreliable."  # noqa: E501
                                    )
                                estimator_params["weight_column"] = weight_col

                            active_int_covs = None
                            if self._interaction_covariates and model_type == "ols":
                                for col in self._interaction_covariates:
                                    if col in comparison_data.columns and f"z_{col}" not in comparison_data.columns:
                                        comparison_data = self.standardize_covariates(comparison_data, [col])
                                active_int_covs = [
                                    c for c in self._interaction_covariates if f"z_{c}" in comparison_data.columns
                                ]
                                if active_int_covs:
                                    estimator_params["interaction_covariates"] = active_int_covs
                            elif self._interaction_covariates and model_type != "ols":
                                self._logger.warning(
                                    f"interaction_covariates ignored for outcome '{outcome}' "
                                    f"with model_type='{model_type}' — only supported for OLS."
                                )

                            output = estimator_func(**estimator_params)

                            # Compute control group SD for retrodesign simulation
                            # Treatment column has been recoded to 0/1 (control=0, treatment=1)
                            control_mask = comparison_data[self._treatment_col] == 0
                            output["control_std"] = comparison_data.loc[control_mask, outcome].std()

                            # Compute pooled SD for equivalence testing (Cohen's d bounds)
                            treatment_mask = comparison_data[self._treatment_col] == 1
                            control_outcome = comparison_data.loc[control_mask, outcome]
                            treatment_outcome = comparison_data.loc[treatment_mask, outcome]
                            n_c, n_t = len(control_outcome), len(treatment_outcome)
                            if n_c > 1 and n_t > 1:
                                s_c = control_outcome.std(ddof=1)
                                s_t = treatment_outcome.std(ddof=1)
                                output["pooled_sd"] = np.sqrt(
                                    ((n_c - 1) * s_c**2 + (n_t - 1) * s_t**2) / (n_c + n_t - 2)
                                )
                            else:
                                output["pooled_sd"] = np.nan

                            # For ratio outcomes: fix control_value, treatment_value,
                            # and all relative-effect fields.
                            # The OLS linearized column has control mean ≈ 0 by
                            # construction, so the estimator's relative_effect =
                            # absolute_effect / ~0 is meaningless. Override everything
                            # with values based on the actual ratio R.
                            if _is_ratio:
                                _ratio_name, _num_col, _den_col, _R = _ratio_lin_cols[outcome]
                                output["effect_type"] = "ratio_difference"
                                output["control_value"] = _R
                                output["treatment_value"] = (
                                    comparison_data.loc[~control_mask, _num_col].mean()
                                    / comparison_data.loc[~control_mask, _den_col].mean()
                                )
                                # Recompute relative effect and CI bounds using R
                                if _R != 0:
                                    output["relative_effect"] = output["absolute_effect"] / _R
                                    for _lo, _hi in (
                                        ("abs_effect_lower", "rel_effect_lower"),
                                        ("abs_effect_upper", "rel_effect_upper"),
                                    ):
                                        if _lo in output and output[_lo] is not None:
                                            output[_hi] = output[_lo] / _R
                                else:
                                    output["relative_effect"] = np.nan
                                    output["rel_effect_lower"] = np.nan
                                    output["rel_effect_upper"] = np.nan

                            if self._store_fitted_models and "fitted_model" in output:
                                if experiment_tuple not in self._fitted_models:
                                    self._fitted_models[experiment_tuple] = {}
                                if (treatment_val, control_val) not in self._fitted_models[experiment_tuple]:
                                    self._fitted_models[experiment_tuple][(treatment_val, control_val)] = {}
                                if outcome not in self._fitted_models[experiment_tuple][(treatment_val, control_val)]:
                                    self._fitted_models[experiment_tuple][(treatment_val, control_val)][outcome] = {}
                                fitted = output.pop("fitted_model")
                                comp_key = (treatment_val, control_val)
                                if len(model_types) > 1:
                                    self._fitted_models[experiment_tuple][comp_key][outcome][model_type] = fitted
                                else:
                                    self._fitted_models[experiment_tuple][comp_key][outcome] = fitted

                            if self._bootstrap:
                                skip_bootstrap = False
                                if model_type == "cox" and self._skip_bootstrap_for_survival:
                                    self._logger.info(
                                        f"Skipping bootstrap for survival outcome '{outcome}' "
                                        f"(skip_bootstrap_for_survival=True). Using Cox model robust standard errors."
                                    )
                                    skip_bootstrap = True

                                if not skip_bootstrap and model_type == "cox":
                                    event_col = (
                                        self._outcome_event_cols.get(outcome)
                                        if outcome in self._outcome_event_cols
                                        else self._event_col
                                    )
                                    if event_col and event_col in comparison_data.columns:
                                        event_rate = comparison_data[event_col].mean()
                                        n_events_treated = comparison_data[
                                            (comparison_data[self._treatment_col] == 1)
                                            & (comparison_data[event_col] == 1)
                                        ].shape[0]
                                        n_events_control = comparison_data[
                                            (comparison_data[self._treatment_col] == 0)
                                            & (comparison_data[event_col] == 1)
                                        ].shape[0]

                                        if event_rate < 0.3:
                                            self._logger.warning(
                                                f"Low event rate ({event_rate:.1%}) for outcome '{outcome}'. "
                                                f"Events: {n_events_treated} treated, {n_events_control} control. "
                                                f"Bootstrap may fail frequently with Cox models. "
                                                f"Consider: (1) skip_bootstrap_for_survival=True, "
                                                f"(2) reduce bootstrap_iterations, (3) remove covariates."
                                            )

                                        min_events = min(n_events_treated, n_events_control)
                                        if min_events < 10:
                                            self._logger.warning(
                                                f"Very few events in one group ({n_events_treated} treated, "
                                                f"{n_events_control} control) for outcome '{outcome}'. "
                                                f"Bootstrap will likely fail. "
                                                f"Recommend skip_bootstrap_for_survival=True."
                                            )

                                if not skip_bootstrap:
                                    bootstrap_abs_effects, bootstrap_rel_effects, bootstrap_ses = (
                                        self._bootstrap_single_effect(
                                            data=comparison_data,
                                            outcome=outcome,
                                            adjustment=adjustment,
                                            model_func=estimator_func,
                                            relevant_covariates=list(relevant_covariates),
                                            numeric_covariates=comp_numeric_covariates,
                                            binary_covariates=comp_binary_covariates,
                                            min_binary_count=min_binary_count,
                                            model_type=model_type,
                                            compute_marginal_effects=me_setting,
                                            interaction_covariates=active_int_covs,
                                            ratio_cols=(_ratio_lin_cols[outcome][1], _ratio_lin_cols[outcome][2])
                                            if _is_ratio
                                            else None,
                                        )
                                    )
                                    bootstrap_results = self._calculate_bootstrap_inference(
                                        bootstrap_abs_effects,
                                        bootstrap_rel_effects,
                                        output["absolute_effect"],
                                        output["relative_effect"],
                                        bootstrap_ses=bootstrap_ses,
                                        observed_se=output.get("standard_error"),
                                    )
                                    output["standard_error"] = bootstrap_results["standard_error"]
                                    output["pvalue"] = bootstrap_results["pvalue"]
                                    output["abs_effect_lower"] = bootstrap_results["abs_effect_lower"]
                                    output["abs_effect_upper"] = bootstrap_results["abs_effect_upper"]
                                    output["rel_effect_lower"] = bootstrap_results["rel_effect_lower"]
                                    output["rel_effect_upper"] = bootstrap_results["rel_effect_upper"]
                                    for _prob_key in (
                                        "prob_abs_effect_gt",
                                        "prob_rel_effect_gt",
                                        "prob_abs_effect_in_rope",
                                        "prob_abs_effect_above_rope",
                                        "prob_abs_effect_below_rope",
                                        "prob_rel_effect_in_rope",
                                        "prob_rel_effect_above_rope",
                                        "prob_rel_effect_below_rope",
                                    ):
                                        output[_prob_key] = bootstrap_results[_prob_key]
                                    # Derive significance from whether bootstrap CI excludes zero
                                    # to ensure visual consistency with forest plots
                                    lo = bootstrap_results["abs_effect_lower"]
                                    hi = bootstrap_results["abs_effect_upper"]
                                    if np.isfinite(lo) and np.isfinite(hi):
                                        output["stat_significance"] = 1 if (lo > 0 or hi < 0) else 0
                                    else:
                                        output["stat_significance"] = 1 if output["pvalue"] < self._alpha else 0

                                    if self._correction:
                                        if experiment_tuple not in self._bootstrap_distributions:
                                            self._bootstrap_distributions[experiment_tuple] = {}
                                        comp_key = (treatment_val, control_val)
                                        if comp_key not in self._bootstrap_distributions[experiment_tuple]:
                                            self._bootstrap_distributions[experiment_tuple][comp_key] = {}
                                        boot_key = f"{outcome}_{model_type}" if len(model_types) > 1 else outcome
                                        self._bootstrap_distributions[experiment_tuple][comp_key][boot_key] = {
                                            "abs_effects": bootstrap_abs_effects,
                                            "rel_effects": bootstrap_rel_effects,
                                        }
                            else:
                                output["abs_effect_lower"] = output.get("abs_effect_lower", np.nan)
                                output["abs_effect_upper"] = output.get("abs_effect_upper", np.nan)
                                output["rel_effect_lower"] = output.get("rel_effect_lower", np.nan)
                                output["rel_effect_upper"] = output.get("rel_effect_upper", np.nan)

                            output["inference_method"] = "bootstrap" if self._bootstrap else "asymptotic"
                            output["adjustment"] = adjustment_label
                            if adjustment in ("balance", "aipw"):
                                output["method"] = self._balance_method
                                output["estimand"] = self._target_effect
                            if adjustment in ("balance", "aipw") and not adjusted_balance.empty:
                                output["balance"] = np.round(adjusted_balance["balance_flag"].mean(), 2)
                            elif not balance.empty:  # Use initial balance if no adjustment or balance failed
                                output["balance"] = np.round(balance["balance_flag"].mean(), 2)
                            else:
                                output["balance"] = np.nan  # No balance calculated

                            if adjustment == "balance":
                                weight_col = self._target_weights[self._target_effect]
                                if weight_col in comparison_data.columns:
                                    treat_mask = comparison_data[self._treatment_col] == 1
                                    control_mask = comparison_data[self._treatment_col] == 0
                                    treat_weights = comparison_data.loc[treat_mask, weight_col]
                                    control_weights = comparison_data.loc[control_mask, weight_col]
                                    ess_treat = self.compute_ess(weights=treat_weights)
                                    ess_control = self.compute_ess(weights=control_weights)
                                    n_treat = treat_mask.sum()
                                    n_control = control_mask.sum()
                                    output["ess_treatment"] = np.floor(ess_treat)
                                    output["ess_control"] = np.floor(ess_control)
                                    output["ess_treatment_reduction"] = (
                                        np.round(1 - (ess_treat / n_treat), 3) if n_treat > 0 else np.nan
                                    )  # noqa: E501
                                    output["ess_control_reduction"] = (
                                        np.round(1 - (ess_control / n_control), 3) if n_control > 0 else np.nan
                                    )  # noqa: E501
                                else:
                                    output["ess_treatment"] = np.nan
                                    output["ess_control"] = np.nan
                                    output["ess_treatment_reduction"] = np.nan
                                    output["ess_control_reduction"] = np.nan

                            output["treatment_group"] = treatment_val
                            output["control_group"] = control_val
                            output["experiment"] = experiment_tuple
                            output["sample_ratio"] = sample_ratio
                            output["srm_detected"] = srm_detected
                            output["srm_pvalue"] = srm_pvalue
                            output["trimmed_units"] = n_trimmed

                            # For ratio outcomes: rename outcome from the temp linearized column
                            # to the user-specified ratio name
                            if _is_ratio:
                                output["outcome"] = _ratio_lin_cols[outcome][0]

                            temp_results.append(output)

                        except Exception as e:
                            self._logger.error(
                                f"Error processing outcome '{outcome}' model '{model_type}' for comparison {treatment_val} vs {control_val} with adjustment '{adjustment_label}': {e}"  # noqa: E501
                            )  # noqa: E501
                            error_output = {
                                "outcome": outcome,
                                "model_type": model_type,
                                "adjustment": adjustment_label,
                                "treatment_group": treatment_val,
                                "control_group": control_val,
                                "treatment_units": np.nan,
                                "control_units": np.nan,
                                "control_value": np.nan,
                                "treatment_value": np.nan,
                                "absolute_effect": np.nan,
                                "relative_effect": np.nan,
                                "stat_significance": np.nan,
                                "standard_error": np.nan,
                                "pooled_sd": np.nan,
                                "pvalue": np.nan,
                                "experiment": experiment_tuple,
                                "sample_ratio": sample_ratio,
                                "srm_detected": srm_detected,
                                "srm_pvalue": srm_pvalue,
                            }
                            temp_results.append(error_output)

        if not temp_results:
            self._logger.warning("No results were generated. Check input data and experiment configurations.")
            self._results = pd.DataFrame()
            return

        clean_temp_results = pd.DataFrame(temp_results)

        if weights_list:
            self._weights = pd.concat(weights_list, ignore_index=True)
        else:
            self._weights = None

        result_columns = [
            "experiment",
            "outcome",
            "treatment_group",
            "control_group",
            "sample_ratio",
            "adjustment",
            "inference_method",
            "model_type",
            "effect_type",
            "treatment_units",
            "control_units",
            "treatment_value",
            "control_value",
            "absolute_effect",
            "abs_effect_lower",
            "abs_effect_upper",
            "relative_effect",
            "rel_effect_lower",
            "rel_effect_upper",
            "standard_error",
            "pvalue",
            "stat_significance",
            "se_intercept",
            "cov_coef_intercept",
            "df_resid",
            "control_std",
            "pooled_sd",
            "alpha_param",
        ]

        balance_calculated = len(self._balance) > 0 or len(self._adjusted_balance) > 0
        if balance_calculated and "balance" in clean_temp_results.columns:
            index_to_insert = result_columns.index("adjustment") + 1
            result_columns.insert(index_to_insert, "method")
            index_to_insert = result_columns.index("method") + 1
            result_columns.insert(index_to_insert, "estimand")
            index_to_insert = result_columns.index("estimand") + 1
            result_columns.insert(index_to_insert, "balance")
            result_columns.extend(
                [
                    "ess_treatment",
                    "ess_control",
                    "ess_treatment_reduction",
                    "ess_control_reduction",
                ]
            )
        if srm_detected is not None and "srm_detected" not in result_columns:
            result_columns.append("srm_detected")
        if srm_pvalue is not None and "srm_pvalue" not in result_columns:
            result_columns.append("srm_pvalue")
        if self._trim_ps and "trimmed_units" not in result_columns:
            result_columns.append("trimmed_units")

        # Bootstrap-only probability columns: include whenever the bootstrap
        # path populated them (i.e., any row has inference_method="bootstrap").
        if (
            "inference_method" in clean_temp_results.columns
            and (clean_temp_results["inference_method"] == "bootstrap").any()
        ):
            result_columns.extend(
                [
                    "prob_abs_effect_gt",
                    "prob_rel_effect_gt",
                    "prob_abs_effect_in_rope",
                    "prob_abs_effect_above_rope",
                    "prob_abs_effect_below_rope",
                    "prob_rel_effect_in_rope",
                    "prob_rel_effect_above_rope",
                    "prob_rel_effect_below_rope",
                ]
            )

        final_result_columns = [col for col in result_columns if col in clean_temp_results.columns]
        clean_temp_results = clean_temp_results[final_result_columns]

        if self._balance:
            self._balance = pd.concat(self._balance, ignore_index=True)
        else:
            self._balance = pd.DataFrame()

        if self._adjusted_balance:
            self._adjusted_balance = pd.concat(self._adjusted_balance, ignore_index=True)
        else:
            self._adjusted_balance = pd.DataFrame()

        results_df = self.__transform_tuple_column(clean_temp_results, "experiment", self._experiment_identifier)

        if not results_df.empty and "absolute_effect" in results_df.columns and "standard_error" in results_df.columns:
            alpha = getattr(self, "_alpha", 0.05)

            if "abs_effect_lower" not in results_df.columns:
                results_df["abs_effect_lower"] = np.nan
            if "abs_effect_upper" not in results_df.columns:
                results_df["abs_effect_upper"] = np.nan

            if "inference_method" in results_df.columns:
                async_mask = results_df["inference_method"] == "asymptotic"
                if async_mask.any():
                    has_df = (
                        async_mask & results_df["df_resid"].notna()
                        if "df_resid" in results_df.columns
                        else pd.Series(False, index=results_df.index)
                    )
                    no_df = async_mask & ~has_df

                    # t-distribution CI for rows with df_resid (OLS models)
                    if has_df.any():
                        df_vals = results_df.loc[has_df, "df_resid"]
                        t_crit = df_vals.apply(lambda d: stats.t.ppf(1 - alpha / 2, d))
                        results_df.loc[has_df, "abs_effect_lower"] = (
                            results_df.loc[has_df, "absolute_effect"]
                            - t_crit * results_df.loc[has_df, "standard_error"]
                        )
                        results_df.loc[has_df, "abs_effect_upper"] = (
                            results_df.loc[has_df, "absolute_effect"]
                            + t_crit * results_df.loc[has_df, "standard_error"]
                        )

                    # z-distribution fallback for rows without df_resid
                    if no_df.any():
                        z_critical = stats.norm.ppf(1 - alpha / 2)
                        results_df.loc[no_df, "abs_effect_lower"] = (
                            results_df.loc[no_df, "absolute_effect"]
                            - z_critical * results_df.loc[no_df, "standard_error"]
                        )
                        results_df.loc[no_df, "abs_effect_upper"] = (
                            results_df.loc[no_df, "absolute_effect"]
                            + z_critical * results_df.loc[no_df, "standard_error"]
                        )

        self._results = results_df

        if not results_df.empty:
            cols_to_check = ["rel_effect_lower", "rel_effect_upper", "se_intercept", "cov_coef_intercept"]
            cols_to_drop = []
            for col in cols_to_check:
                if col in results_df.columns and results_df[col].isna().all():
                    cols_to_drop.append(col)

            if cols_to_drop:
                self._logger.debug(f"Removing columns with all NaN values: {cols_to_drop}")
                self._results = self._results.drop(columns=cols_to_drop)

        if self._correction:
            self._logger.info(f"Applying {self._correction} p-value adjustment")
            self.adjust_pvalues(method=self._correction)

        if original_bootstrap is not None:
            self._bootstrap = original_bootstrap

    def test_equivalence(
        self,
        test_type: str = "equivalence",
        absolute_bound: float | None = None,
        relative_bound: float | None = None,
        cohens_d_bound: float | None = None,
        alpha: float = 0.05,
        direction: str = "higher_is_better",
    ) -> None:
        """
        Unified equivalence, non-inferiority, and non-superiority testing.

        Implements the Two One-Sided Tests (TOST) procedure following Lakens (2017).
        Non-inferiority and non-superiority are one-sided special cases of the same
        framework.

        Parameters
        ----------
        test_type : {"equivalence", "non_inferiority", "non_superiority"}
            ``"equivalence"``: TOST — tests both bounds, concludes equivalence
            when effect falls within [-delta, +delta].
            ``"non_inferiority"``: one-sided test against the lower (or upper) bound.
            ``"non_superiority"``: one-sided test against the opposite bound.
        absolute_bound : float, optional
            Equivalence bound in raw outcome units (must be > 0).
        relative_bound : float, optional
            Equivalence bound as a fraction of |control_value|
            (e.g. 0.10 = 10%). Must be > 0.
        cohens_d_bound : float, optional
            Equivalence bound in standardized units (Cohen's d). Converted to
            raw units via pooled_sd. Only valid for OLS model types.
        alpha : float, optional
            Significance level (default 0.05). For TOST the confidence interval
            is (1 - 2*alpha), i.e. 90% by default.
        direction : {"higher_is_better", "lower_is_better"}
            Only used for non_inferiority and non_superiority test types.

        Updates
        -------
        self._results : pd.DataFrame
            Adds columns prefixed with eq_.
        """
        if self._results is None:
            log_and_raise_error(self._logger, "Must run get_effects() before test_equivalence().")

        valid_test_types = {"equivalence", "non_inferiority", "non_superiority"}
        if test_type not in valid_test_types:
            log_and_raise_error(self._logger, f"test_type must be one of {valid_test_types}.")

        if not (0 < alpha < 1):
            log_and_raise_error(self._logger, "alpha must be between 0 and 1 (exclusive).")

        valid_directions = {"higher_is_better", "lower_is_better"}
        if direction not in valid_directions:
            log_and_raise_error(self._logger, f"direction must be one of {valid_directions}.")

        # Exactly one bound type
        bounds_specified = sum(b is not None for b in [absolute_bound, relative_bound, cohens_d_bound])
        if bounds_specified != 1:
            log_and_raise_error(
                self._logger,
                "Provide exactly one of absolute_bound, relative_bound, or cohens_d_bound.",
            )

        if absolute_bound is not None and absolute_bound <= 0:
            log_and_raise_error(self._logger, "absolute_bound must be > 0.")
        if relative_bound is not None and relative_bound <= 0:
            log_and_raise_error(self._logger, "relative_bound must be > 0.")
        if cohens_d_bound is not None and cohens_d_bound <= 0:
            log_and_raise_error(self._logger, "cohens_d_bound must be > 0.")

        results_df = self._results.copy()

        # Resolve bounds to absolute units (delta per row)
        if absolute_bound is not None:
            results_df["_delta"] = float(absolute_bound)
            bound_type = "absolute"
        elif relative_bound is not None:
            results_df["_delta"] = relative_bound * results_df["control_value"].abs()
            bound_type = "relative"
        else:
            # Cohen's d: only valid for OLS
            if "model_type" in results_df.columns:
                non_ols = results_df["model_type"] != "ols"
                if non_ols.any():
                    self._logger.warning(
                        "cohens_d_bound is only valid for OLS models. "
                        "Non-OLS rows will have NaN equivalence results. "
                        "Use absolute_bound or relative_bound for non-OLS models."
                    )
            if "pooled_sd" not in results_df.columns:
                log_and_raise_error(self._logger, "pooled_sd column not found. Re-run get_effects().")
            results_df["_delta"] = cohens_d_bound * results_df["pooled_sd"]
            bound_type = "cohens_d"

        # For Cohen's d with non-OLS, set delta to NaN
        if cohens_d_bound is not None and "model_type" in results_df.columns:
            non_ols_mask = results_df["model_type"] != "ols"
            results_df.loc[non_ols_mask, "_delta"] = np.nan

        # Store bounds
        results_df["eq_test_type"] = test_type
        results_df["eq_bound_type"] = bound_type
        results_df["eq_bound_lower"] = -results_df["_delta"]
        results_df["eq_bound_upper"] = results_df["_delta"]

        # Two one-sided test statistics
        effect = results_df["absolute_effect"]
        se = results_df["standard_error"]
        delta = results_df["_delta"]

        z_lower = (effect + delta) / se  # H0: effect <= -delta
        z_upper = (delta - effect) / se  # H0: effect >= +delta

        results_df["eq_pvalue_lower"] = 1 - stats.norm.cdf(z_lower)
        results_df["eq_pvalue_upper"] = 1 - stats.norm.cdf(z_upper)

        # (1-2*alpha) confidence interval
        z_crit = stats.norm.ppf(1 - alpha)
        results_df["eq_ci_lower"] = effect - z_crit * se
        results_df["eq_ci_upper"] = effect + z_crit * se

        # Cohen's d for observed effect
        if "pooled_sd" in results_df.columns:
            results_df["eq_cohens_d"] = effect / results_df["pooled_sd"]
        else:
            results_df["eq_cohens_d"] = np.nan

        # Determine the reported p-value based on test type
        if test_type == "equivalence":
            results_df["eq_pvalue"] = results_df[["eq_pvalue_lower", "eq_pvalue_upper"]].max(axis=1)
        elif test_type == "non_inferiority":
            if direction == "higher_is_better":
                results_df["eq_pvalue"] = results_df["eq_pvalue_lower"]
            else:
                results_df["eq_pvalue"] = results_df["eq_pvalue_upper"]
        else:  # non_superiority
            if direction == "higher_is_better":
                results_df["eq_pvalue"] = results_df["eq_pvalue_upper"]
            else:
                results_df["eq_pvalue"] = results_df["eq_pvalue_lower"]

        # Conclusion logic (Lakens' four-cell matrix)
        tost_sig = results_df["eq_pvalue"] < alpha

        # Use unadjusted NHST significance to match unadjusted TOST p-values
        nhst_sig = results_df["stat_significance"] == 1

        if test_type == "equivalence":
            labels = {
                (False, True): "equivalent",
                (False, False): "inconclusive",
                (True, True): "equivalent_with_difference",
                (True, False): "not_equivalent",
            }
        elif test_type == "non_inferiority":
            labels = {
                (False, True): "non_inferior",
                (False, False): "inconclusive",
                (True, True): "non_inferior_with_difference",
                (True, False): "not_non_inferior",
            }
        else:  # non_superiority
            labels = {
                (False, True): "non_superior",
                (False, False): "inconclusive",
                (True, True): "non_superior_with_difference",
                (True, False): "not_non_superior",
            }

        results_df["eq_conclusion"] = [
            labels.get((bool(n), bool(t)), "inconclusive") for n, t in zip(nhst_sig, tost_sig, strict=True)
        ]

        # NaN out conclusions for invalid rows (e.g., Cohen's d with non-OLS)
        nan_mask = results_df["_delta"].isna()
        eq_cols = [c for c in results_df.columns if c.startswith("eq_") and c not in ("eq_test_type", "eq_bound_type")]
        for col in eq_cols:
            results_df.loc[nan_mask, col] = np.nan

        results_df = results_df.drop(columns=["_delta"])
        self._results = results_df

    def plot_effects(
        self,
        outcomes: list[str] | str | None = None,
        effect: str | list[str] = "absolute",
        meta_analysis: bool | pd.DataFrame | None = None,
        meta_method: str = "fixed",
        comparison: tuple | list[tuple] | None = None,
        figsize: tuple | None = None,
        title: str | None = None,
        show_zero_line: bool = True,
        sort_by_magnitude: bool = True,
        group_by: str | list[str] | None = None,
        y: str = "experiment",
        panel_titles: str | list | dict | None = None,
        show_panel_titles: bool = True,
        row_labels: dict | None = None,
        show_values: bool = True,
        value_decimals: int | None = None,
        panel_spacing: float | None = None,
        repeat_ylabels: bool = False,
        pct_points: bool = False,
        combine_values: bool = False,
        relative_cap: float = 5.0,
        save_path: str | None = None,
        color_direction: bool = False,
        color_palette: dict[str, str] | None = None,
        **kwargs,
    ) -> "plt.Figure | dict | None":
        if kwargs:
            raise TypeError(f"plot_effects() got unexpected keyword argument(s): {list(kwargs.keys())}")
        """
        Cleveland dot plot of treatment effects across experiments.

        Each outcome gets its own panel.  Experiments are shown as rows with
        a dot at the point estimate and a bracketed confidence interval.
        An optional pooled (meta-analysis) row is appended at the bottom.

        Parameters
        ----------
        outcomes : str or list[str], optional
            Outcomes to include.  If None all outcomes in results are shown.
        effect : {"absolute", "relative"} or list, optional
            Which effect metric(s) to display (default "absolute").
            Pass ``["absolute", "relative"]`` to produce a side-by-side figure
            with one column group per effect type.
        meta_analysis : bool or pd.DataFrame, optional
            - True  → compute pooled estimate via ``combine_effects()``
            - pd.DataFrame → use a pre-computed ``combine_effects()`` result
            - None (default) → no pooled row
        meta_method : {"fixed", "random"}, optional
            Meta-analysis method to use when ``meta_analysis=True``.
            ``"fixed"`` (default) uses IVW fixed effects; ``"random"`` uses
            Paule-Mandel + HKSJ random effects. Ignored when ``meta_analysis``
            is a pre-computed DataFrame.
        comparison : tuple or list of tuple, optional
            ``(treatment_group, control_group)`` to restrict the plot to one
            specific comparison, or a list of such tuples to include multiple
            comparisons, e.g.
            ``[('variant_1', 'control'), ('variant_1', 'variant_2')]``.
        figsize : tuple, optional
            ``(width, height)`` in inches.  Auto-sized when None.
        title : str, optional
            Figure-level suptitle.
        show_zero_line : bool, optional
            Vertical reference line at zero (default True).
        sort_by_magnitude : bool, optional
            Sort rows within each panel by effect value descending (default ``True``).
        group_by : str or list[str], optional
            Column(s) to split into separate figures — one figure per unique value.
            Row labels are built from ``experiment_identifier`` minus these columns.
            Returns a ``dict`` keyed by group value instead of a single figure.
        y : {"experiment", "outcome"}, optional
            What to place on the y-axis rows.
            ``"experiment"`` (default) — rows = experiments, panels = outcomes.
            ``"outcome"`` — rows = outcomes, panels = experiment labels.
        panel_titles : str or list or dict, optional
            Override the auto-generated panel (subplot) titles.

            - ``None`` (default) — use the panel value as the title.
            - ``str`` — same string for every panel (``""`` hides all).
            - ``list`` — titles in panel order, e.g. ``["Revenue ($)", "CVR"]``.
            - ``dict`` — map each panel value to a display string.

            What counts as a "panel value" depends on *y*:

            - ``y="experiment"`` (default): one panel per **outcome**, so
              keys are outcome names, e.g.
              ``{"revenue": "Revenue ($)", "converted": "Conversion rate"}``.
            - ``y="outcome"``: one panel per **experiment label**, so keys
              are the ``experiment_identifier`` column values joined with
              ``" | "``, e.g. ``{"US | email": "US — Email campaign"}``.
        show_panel_titles : bool, optional
            Show subplot titles for the panel values (outcomes when
            ``y="experiment"``, experiments when ``y="outcome"``).  Set to
            ``False`` to hide redundant panel headings.  Default ``True``.
        row_labels : dict, optional
            Rename individual y-axis row labels.  Keys are the auto-generated
            labels (``experiment_identifier`` column values joined with ``" | "``);
            values are the display strings to show instead.
            e.g. ``{"US | email": "Email (US)", "EU | push": "Push (EU)"}``.
            Rows not present in the dict keep their auto-generated label.
        show_values : bool, optional
            Annotate each dot with its effect value (and ``*`` when significant).
            Default ``True``.
        value_decimals : int, optional
            Number of decimal places for the value labels shown when
            ``show_values=True``.  Defaults to ``1`` when ``pct_points=True``
            or a relative effect is shown, otherwise ``2``.
        pct_points : bool, optional
            Multiply absolute effect values by 100 for display, expressing them
            as percentage points (pp).  The x-axis label becomes
            ``"Absolute Effect (pp)"`` and annotations gain a ``"pp"`` suffix.
            Default ``False``.
        combine_values : bool, optional
            When ``True`` and ``show_values=True``, append the secondary effect
            in parentheses to each dot annotation — e.g. ``+3.0pp (+15.4%)``
            when plotting absolute, or ``+15.4% (+3.0pp)`` when plotting
            relative.  Default ``False``.
        save_path : str or path-like, optional
            File path to save the figure.  When ``group_by`` produces multiple
            figures the group key is inserted before the file extension, e.g.
            ``"effects.png"`` → ``"effects_US.png"``, ``"effects_EU.png"``.
            Supports any format recognised by matplotlib (``png``, ``pdf``,
            ``svg``, …).  ``None`` (default) skips saving.
        color_direction : bool, optional
            When ``True``, color effects by significance and sign. Default
            ``False``.
        color_palette : dict, optional
            Override effect colors. Keys are ``"sig_pos"``, ``"sig_neg"``,
            ``"nsig_pos"``, ``"nsig_neg"``, and ``"nsig_zero"``. Omitted keys
            use the defaults. Most useful with ``color_direction=True``.

        Returns
        -------
        matplotlib.figure.Figure, dict, or None
        """
        from .plotting import plot_effects as _plot_effects

        if self._results is None or self._results.empty:
            self._logger.warning("No results available. Run get_effects() first.")
            return None

        meta_df = None
        if meta_analysis is True:
            extra_group_cols: list[str] = []
            if group_by is not None:
                extra_group_cols = [group_by] if isinstance(group_by, str) else list(group_by)
            meta_df = self.combine_effects(
                grouping_cols=self._resolve_grouping_cols(self._results, extra_group_cols or None),
                method=meta_method,
            )
            meta_df["_label"] = "Pooled"
        elif isinstance(meta_analysis, pd.DataFrame):
            meta_df = meta_analysis.copy()
            if "_label" not in meta_df.columns:
                meta_df["_label"] = "Pooled"

        return _plot_effects(
            results=self._results,
            experiment_identifier=self._experiment_identifier,
            alpha=self._alpha,
            outcomes=outcomes,
            effect=effect,
            meta_df=meta_df,
            comparison=comparison,
            figsize=figsize,
            title=title,
            show_zero_line=show_zero_line,
            sort_by_magnitude=sort_by_magnitude,
            group_by=group_by,
            y=y,
            panel_titles=panel_titles,
            show_panel_titles=show_panel_titles,
            row_labels=row_labels,
            show_values=show_values,
            value_decimals=value_decimals,
            panel_spacing=panel_spacing,
            repeat_ylabels=repeat_ylabels,
            pct_points=pct_points,
            combine_values=combine_values,
            relative_cap=relative_cap,
            save_path=save_path,
            color_direction=color_direction,
            color_palette=color_palette,
        )

    def plot_equivalence(
        self,
        outcomes: list[str] | str | None = None,
        figsize: tuple | None = None,
        title: str | None = None,
        show_values: bool = True,
        value_decimals: int = 2,
        sort_by_magnitude: bool = True,
        save_path: str | None = None,
    ) -> "plt.Figure":
        """
        Plot equivalence test results (TOST visualization).

        Requires :meth:`test_equivalence` to have been called first.
        Delegates to the standalone :func:`plot_equivalence` function.

        Parameters
        ----------
        outcomes : list[str] or str, optional
            Subset of outcomes to plot.
        figsize : tuple, optional
            Figure size ``(width, height)``.
        title : str, optional
            Overall figure title.
        show_values : bool
            Annotate each row with effect and conclusion.
        value_decimals : int
            Decimal places for annotations.
        sort_by_magnitude : bool
            Sort rows by |effect|.
        save_path : str, optional
            Path to save the figure.

        Returns
        -------
        matplotlib.figure.Figure
        """
        if self._results is None or "eq_conclusion" not in self._results.columns:
            log_and_raise_error(
                self._logger,
                "Must run test_equivalence() before plot_equivalence().",
            )

        from .plotting import plot_equivalence as _plot_equivalence

        return _plot_equivalence(
            data=self._results,
            outcomes=outcomes,
            figsize=figsize,
            title=title,
            show_values=show_values,
            value_decimals=value_decimals,
            sort_by_magnitude=sort_by_magnitude,
            save_path=save_path,
        )

    @property
    def imbalance(self) -> pd.DataFrame | None:
        """
        Returns the imbalance DataFrame. Checks adjusted balance first, then unadjusted.
        """
        if not self._adjusted_balance.empty:
            ab = self._adjusted_balance[self._adjusted_balance.balance_flag == 0]
            if not ab.empty:
                self._logger.info("Imbalance after adjustments!")
                return ab
        elif not self._balance.empty:
            b = self._balance[self._balance.balance_flag == 0]
            if not b.empty:
                self._logger.info("Imbalance without adjustments!")
                return b
        else:
            self._logger.warning("No balance information available to determine imbalance!")
            return None

    def __transform_tuple_column(self, df: pd.DataFrame, tuple_column: str, new_columns: list[str]) -> pd.DataFrame:
        """
        Transforms a column containing tuples or single values
        into separate columns named according to new_columns.
        Handles the case where a single identifier results in a single-element tuple.

        Parameters:
        df (pd.DataFrame): The DataFrame containing the column to transform.
        tuple_column (str): The name of the column with tuples or single values.
        new_columns (list): A list of new column names. Should match self._experiment_identifier.

        Returns:
        pd.DataFrame: A new DataFrame with the elements as separate columns.
        """
        if df.empty or tuple_column not in df.columns:
            return df

        if not new_columns:
            self._logger.warning("No new column names provided for transformation. Skipping.")
            return df

        df = df.copy()

        if len(new_columns) == 1:
            new_col_name = new_columns[0]

            def extract_single_element(x):
                if isinstance(x, tuple) and len(x) == 1:
                    return x[0]  # Extract the first (and only) element, regardless of type
                return x  # Return as is if not a single-element tuple

            df.loc[:, tuple_column] = df[tuple_column].apply(extract_single_element)

            df = df.rename(columns={tuple_column: new_col_name})

            cols_order = [new_col_name] + [col for col in df.columns if col != new_col_name]
            df = df[cols_order]

        elif len(new_columns) > 1:

            def check_tuple(x):
                return isinstance(x, tuple) and len(x) == len(new_columns)

            if not df.empty and df[tuple_column].apply(check_tuple).all():
                columns_to_keep = [col for col in df.columns if col != tuple_column]
                try:
                    split_cols = pd.DataFrame(df[tuple_column].tolist(), index=df.index, columns=new_columns)
                    df_transformed = pd.concat([split_cols, df[columns_to_keep]], axis=1)
                    ordered_columns = new_columns + columns_to_keep
                    df = df_transformed[ordered_columns]
                except Exception as e:
                    self._logger.error(f"Failed to split tuple column '{tuple_column}' into {new_columns}. Error: {e}")
            elif not df.empty:
                self._logger.warning(
                    f"Column '{tuple_column}' does not contain consistent tuples of length {len(new_columns)}. Transformation skipped."  # noqa: E501
                )  # noqa: E501

        return df

    def __ensure_list(self, item: str | list[str] | None) -> list[str]:
        """Ensure the input is a list."""
        if item is None:
            return []
        return item if isinstance(item, list) else [item]

    def __validate_prob_threshold(self, value: float, name: str) -> float:
        try:
            v = float(value)
        except (TypeError, ValueError):
            log_and_raise_error(self._logger, f"{name} must be a finite number, got {value!r}.")
        if not np.isfinite(v):
            log_and_raise_error(self._logger, f"{name} must be finite, got {value!r}.")
        return v

    def __validate_rope(self, value: tuple[float, float] | list[float] | None, name: str) -> tuple[float, float] | None:
        if value is None:
            return None
        if not (isinstance(value, tuple | list) and len(value) == 2):
            log_and_raise_error(
                self._logger,
                f"{name} must be a 2-element tuple/list (lo, hi), got {value!r}.",
            )
        try:
            lo, hi = float(value[0]), float(value[1])
        except (TypeError, ValueError):
            log_and_raise_error(self._logger, f"{name} bounds must be finite numbers, got {value!r}.")
        if not (np.isfinite(lo) and np.isfinite(hi)):
            log_and_raise_error(self._logger, f"{name} bounds must be finite, got {value!r}.")
        if lo > hi:
            log_and_raise_error(self._logger, f"{name} lower bound must be <= upper bound, got {value!r}.")
        return (lo, hi)

    @property
    def results(self) -> pd.DataFrame | None:
        """
        Returns the results DataFrame
        """
        if self._results is not None:
            internal_columns = ["se_intercept", "cov_coef_intercept", "control_std", "alpha_param"]
            return self._results.drop(columns=[col for col in internal_columns if col in self._results.columns])
        else:
            self._logger.warning("Run the `get_effects` function first!")
            return None

    @property
    def balance(self) -> pd.DataFrame | None:
        """
        Returns the balance DataFrame
        """
        if isinstance(self._balance, pd.DataFrame) and not self._balance.empty:
            return self._balance
        else:
            if self._all_covariates or self._interaction_covariates:
                self._logger.warning(
                    "No balance information available! "
                    "If you have covariates, use check_balance() or run get_effects() first."
                )
            else:
                self._logger.warning("No balance information available!")
            return None

    @property
    def adjusted_balance(self) -> pd.DataFrame | None:
        """
        Returns the adjusted balance DataFrame
        """
        if isinstance(self._adjusted_balance, pd.DataFrame) and not self._adjusted_balance.empty:
            return self._adjusted_balance
        else:
            if self._all_covariates or self._interaction_covariates:
                self._logger.warning(
                    "No adjusted balance information available! "
                    "Run get_effects() with covariate adjustment to get adjusted balance."
                )
            else:
                self._logger.warning("No adjusted balance information available!")
            return None

    @property
    def weights(self) -> pd.DataFrame | None:
        """
        Returns the weights DataFrame from balance adjustment
        """
        if self._weights is not None:
            return self._weights
        else:
            self._logger.warning("No weights available! Weights are only saved when balance adjustment is used.")
            return None

    def check_balance(
        self,
        threshold: float = 0.1,
        min_binary_count: int | None = None,
    ) -> pd.DataFrame | None:
        """
        Check covariate balance between treatment and control groups.

        This method can be called independently of get_effects() to assess balance
        on the loaded experiment data. It performs the same preprocessing as get_effects()
        including categorical variable handling, covariate filtering, and standardization.

        Parameters
        ----------
        threshold : float, optional
            SMD threshold for balance flag (default 0.1). Covariates with
            |SMD| < threshold are considered balanced.
        min_binary_count : int, optional
            Minimum count required for binary covariates.
            If None, uses the value set in __init__ (default 10).
            Binary covariates with fewer observations are excluded.

        Returns
        -------
        pd.DataFrame or None
            Balance metrics DataFrame with columns:
            - experiment columns (if experiment_identifier was specified)
            - covariate: str - covariate name
            - mean_treated: float - weighted mean for treatment group
            - mean_control: float - weighted mean for control group
            - smd: float - standardized mean difference
            - balance_flag: int - 1 if balanced (|SMD| < threshold), 0 if imbalanced

            Returns None if no covariates are specified.

        Examples
        --------
        >>> analyzer = ExperimentAnalyzer(
        ...     data=df,
        ...     outcomes=['conversion'],
        ...     treatment_col='treatment',
        ...     covariates=['age', 'income', 'region']
        ... )
        >>> balance_df = analyzer.check_balance(threshold=0.1)
        >>> print(f"Balanced: {balance_df['balance_flag'].mean():.2%}")
        >>> imbalanced = balance_df[balance_df['balance_flag'] == 0]
        >>> print(f"Imbalanced covariates: {imbalanced['covariate'].tolist()}")

        Notes
        -----
        - Categorical covariates are automatically detected and dummy-encoded
        - Covariates with zero variance or low frequency are filtered out
        - The method handles experiment identifiers (checks balance per experiment)
        - Can be called before or after get_effects()
        """
        from .utils import check_covariate_balance

        if min_binary_count is None:
            min_binary_count = self._min_binary_count

        no_covariates = not self._all_covariates and not self._interaction_covariates
        if no_covariates:
            self._logger.warning("No covariates specified, balance cannot be assessed!")
            return None

        # Identify categorical covariates
        categorical_info = self.__get_categorical_covariates(data=self._data)

        # Get experiment groups
        if self._experiment_identifier:
            experiment_groups = self._data.groupby(self._experiment_identifier)
        else:
            experiment_groups = [(None, self._data)]

        balance_results = []

        for experiment_tuple, temp_data in experiment_groups:
            if experiment_tuple is None:
                experiment_tuple = (1,)

            self._logger.info(f"Checking balance for experiment: {experiment_tuple}")

            # Get treatment values
            treatvalues = set(temp_data[self._treatment_col].unique())
            if len(treatvalues) < 2:
                self._logger.warning(f"Skipping {experiment_tuple}: not enough treatment groups!")
                continue

            # Get comparison pairs
            comparison_pairs = self.__get_comparison_pairs(treatvalues, temp_data)
            if not comparison_pairs:
                self._logger.warning(f"Skipping {experiment_tuple}: no valid comparison pairs found!")
                continue

            for treatment_val, control_val in comparison_pairs:
                self._logger.info(f"Checking balance: {treatment_val} vs {control_val}")

                # Get comparison data
                comparison_data = temp_data[temp_data[self._treatment_col].isin([treatment_val, control_val])].copy()

                if comparison_data.empty:
                    self._logger.warning(f"No data for comparison {treatment_val} vs {control_val}. Skipping.")
                    continue

                # Check if we have both treatment and control groups
                n_treatment = (comparison_data[self._treatment_col] == treatment_val).sum()
                n_control = (comparison_data[self._treatment_col] == control_val).sum()

                if n_treatment == 0 or n_control == 0:
                    self._logger.warning(
                        f"Missing treatment ({n_treatment}) or control ({n_control}) units for comparison "
                        f"{treatment_val} vs {control_val}. Cannot check balance. Skipping."
                    )
                    continue

                # Check balance using standalone function
                balance_covs = list(dict.fromkeys(self._all_covariates + self._interaction_covariates))
                balance_df = check_covariate_balance(
                    data=comparison_data,
                    treatment_col=self._treatment_col,
                    covariates=balance_covs,
                    categorical_covariates=categorical_info,
                    min_binary_count=min_binary_count,
                    threshold=threshold,
                    treatment_comparisons=[(treatment_val, control_val)],
                    categorical_max_unique=self._categorical_max_unique,
                    logger=self._logger,
                )

                if not balance_df.empty:
                    balance_df["experiment"] = [experiment_tuple] * len(balance_df)
                    balance_df = self.__transform_tuple_column(balance_df, "experiment", self._experiment_identifier)

                    # Remove treatment_group and control_group columns since we track experiment instead
                    balance_df = balance_df.drop(columns=["treatment_group", "control_group"], errors="ignore")

                    # Log balance summary
                    balance_mean = balance_df["balance_flag"].mean()
                    self._logger.info(f"Balance: {balance_mean:.2%}")

                    balance_results.append(balance_df)

        if balance_results:
            final_balance = pd.concat(balance_results, ignore_index=True)
            return final_balance
        else:
            self._logger.warning("No balance results generated")
            return pd.DataFrame()

    def get_attribute(self, attribute: str) -> str | None:
        """
        Get an attribute of the class.

        Parameters:
        attribute (str): The name of the attribute to get.

        Returns:
        str: The value of the attribute.
        """

        private_attribute = f"_{attribute}"
        if hasattr(self, private_attribute):
            return getattr(self, private_attribute)
        elif hasattr(self, attribute):
            return getattr(self, attribute)
        else:
            log_and_raise_error(self._logger, f"Attribute {attribute} not found!")

    def get_fitted_models(
        self,
        experiment: tuple | None = None,
        comparison: tuple | None = None,
        outcome: str | None = None,
        model_type: str | None = None,
    ) -> dict | object | None:
        """
        Retrieve fitted model instances.

        This method allows access to the underlying statistical models fitted during
        analysis when store_fitted_models=True was set. Useful for post-hoc analysis,
        diagnostics, predictions, and model-specific tests.

        Parameters
        ----------
        experiment : tuple, optional
            Filter by experiment identifier tuple (e.g., ('US', 'mobile'))
        comparison : tuple, optional
            Filter by (treatment, control) comparison tuple (e.g., (1, 0))
        outcome : str, optional
            Filter by outcome name (e.g., 'conversion')
        model_type : str, optional
            Filter by model type when multiple models fitted for same outcome (e.g., 'ols', 'logistic')

        Returns
        -------
        dict or object or None
            - If no filters: returns full nested dict structure
            - If filters specified: returns filtered dict, single model object, or None
            Structure: {experiment_tuple: {(treatment, control): {outcome: model_object or {model_type: model_object}}}}

        Examples
        --------
        >>> # Get all models
        >>> all_models = analyzer.get_fitted_models()

        >>> # Get models for specific outcome
        >>> clicked_models = analyzer.get_fitted_models(outcome='clicked')

        >>> # Get specific model (single model for outcome)
        >>> model = analyzer.get_fitted_models(
        ...     experiment=(1,),
        ...     comparison=(1, 0),
        ...     outcome='conversion'
        ... )
        >>> model.summary()

        >>> # Get specific model when multiple models per outcome
        >>> ols_model = analyzer.get_fitted_models(
        ...     experiment=(1,),
        ...     comparison=(1, 0),
        ...     outcome='clicked',
        ...     model_type='ols'
        ... )
        >>> logit_model = analyzer.get_fitted_models(
        ...     experiment=(1,),
        ...     comparison=(1, 0),
        ...     outcome='clicked',
        ...     model_type='logistic'
        ... )
        """
        if not self._store_fitted_models:
            self._logger.warning(
                "No models stored. Set store_fitted_models=True when initializing "
                "ExperimentAnalyzer to store fitted models."
            )
            return None

        if not self._fitted_models:
            self._logger.warning("No models have been fitted yet. Run get_effects() first.")
            return None

        if experiment is None and comparison is None and outcome is None:
            return self._fitted_models

        result = self._fitted_models
        if experiment is not None:
            result = {exp: models for exp, models in result.items() if exp == experiment}
            if not result:
                return None
            if comparison is None and outcome is None:
                return result

        def _extract_model_by_type(model_obj, model_type_filter):
            """Extract specific model from potentially nested structure."""
            if model_type_filter is None:
                return model_obj
            if isinstance(model_obj, dict) and model_type_filter in model_obj:
                return model_obj[model_type_filter]
            return model_obj if model_type_filter is None else None

        if comparison is not None:
            if experiment is not None:
                if experiment in self._fitted_models:
                    comp_models = self._fitted_models[experiment].get(comparison, {})
                    if outcome is None:
                        return comp_models if comp_models else None
                    outcome_model = comp_models.get(outcome)
                    return _extract_model_by_type(outcome_model, model_type)
                return None
            else:
                result = {
                    exp: {comp: models for comp, models in exp_models.items() if comp == comparison}
                    for exp, exp_models in result.items()
                }
                result = {exp: comps for exp, comps in result.items() if comps}
                if not result:
                    return None
                if outcome is None:
                    return result

        if outcome is not None and experiment is None and comparison is None:
            result = {}
            for exp, exp_models in self._fitted_models.items():
                exp_result = {}
                for comp, comp_models in exp_models.items():
                    if outcome in comp_models:
                        outcome_model = _extract_model_by_type(comp_models[outcome], model_type)
                        if outcome_model is not None:
                            exp_result[comp] = outcome_model
                if exp_result:
                    result[exp] = exp_result
            return result if result else None

        if outcome is not None and experiment is not None and comparison is None:
            if experiment in self._fitted_models:
                exp_result = {}
                for comp, comp_models in self._fitted_models[experiment].items():
                    if outcome in comp_models:
                        outcome_model = _extract_model_by_type(comp_models[outcome], model_type)
                        if outcome_model is not None:
                            exp_result[comp] = outcome_model
                return exp_result if exp_result else None
            return None

        if outcome is not None and comparison is not None:
            pass

        return result if result else None

    def __get_comparison_pairs(self, treatvalues: set, data: pd.DataFrame) -> list[tuple]:
        """
        Generate comparison pairs for categorical treatment analysis.

        This method wraps the shared generate_comparison_pairs function
        from utils.py for use within ExperimentAnalyzer.

        Parameters
        ----------
        treatvalues : set
            Set of unique treatment values in the data (not used, kept for API compatibility)
        data : pd.DataFrame
            DataFrame containing the treatment column

        Returns
        -------
        list[tuple]
            List of (treatment_val, control_val) tuples to compare
        """
        # Use the shared function from utils.py for consistency
        return generate_comparison_pairs(
            data=data,
            treatment_col=self._treatment_col,
            treatment_comparisons=self._treatment_comparisons,
            logger=self._logger,
        )

    def __check_sample_ratio_mismatch(self, df: pd.DataFrame):
        """
        Performs a Sample Ratio Mismatch (SRM) test to check if the observed
        treatment ratio significantly differs from the expected ratio.

        Parameters
        ----------
        df : pd.DataFrame
            DataFrame containing the treatment assignment and expected sample ratio.
        """

        n_total = len(df)
        observed_count = df[self._treatment_col].sum()
        if n_total > 0:
            sample_ratio = observed_count / n_total
        else:
            sample_ratio = None

        if self._exp_sample_ratio_col is not None:
            if isinstance(self._exp_sample_ratio_col, float):
                expected_ratio = self._exp_sample_ratio_col
            else:
                unique_expected_ratio = df[self._exp_sample_ratio_col].unique()
                if len(unique_expected_ratio) > 1:
                    log_and_raise_error(
                        self._logger, "Multiple unique values by experiment found in expected ratio column!"
                    )
                expected_ratio = unique_expected_ratio[0]

            if not (0 < expected_ratio < 1):
                log_and_raise_error(self._logger, "Expected ratio is not between 0 and 1!")

            try:
                srm_detected = False
                srm_pvalue = None

                z_stat, p_value = proportions_ztest(
                    count=observed_count, nobs=n_total, value=expected_ratio, alternative="two-sided"
                )
                srm_pvalue = p_value

                if p_value < self._alpha:
                    srm_detected = True
                    self._logger.info(
                        f"Significant mismatch detected (p < {self._alpha:.3f}). Observed ratio differs statistically from expected ratio."  # noqa: E501
                    )

                return sample_ratio, srm_detected, srm_pvalue

            except Exception as e:
                self._logger.error(f"SRM error during proportions_ztest: {e}")
        else:
            return sample_ratio, None, None

    def compute_ess(self, weights: np.ndarray) -> float:
        """
        Compute effective sample size (ESS) given a vector of weights.
        ESS = (sum(w))^2 / sum(w^2)
        """
        weights = np.asarray(weights)
        if np.all(weights == 0):
            return 0.0
        return (weights.sum()) ** 2 / (np.sum(weights**2) + 1e-12)

    def _plot_common_support(
        self, df, propensity_col, treatment_col, bw_method=None, grid_size=100, figsize=(10, 6), experiment_id=None
    ):
        """
        Create a mirror density plot for common support showing the distribution
        of propensity scores for treatment (up) and control (down).

        Parameters:
        - df: pandas DataFrame containing the data.
        - propensity_col: string, name of the column with propensity scores.
        - treatment_col: string, name of the column with treatment indicator (binary).
        - bw_method: bandwidth method for gaussian_kde (default None).
        - grid_size: number of grid points for density estimation.
        - figsize: tuple, figure size.
        - experiment_id: optional, identifier for the experiment (used in title).
        """

        treatment_scores = df.loc[df[treatment_col] == 1, propensity_col].dropna()
        control_scores = df.loc[df[treatment_col] == 0, propensity_col].dropna()

        all_scores = df[propensity_col].dropna()
        x_min, x_max = all_scores.min(), all_scores.max()
        x_grid = np.linspace(x_min, x_max, grid_size)

        kde_treat = gaussian_kde(treatment_scores, bw_method=bw_method)
        kde_control = gaussian_kde(control_scores, bw_method=bw_method)
        density_treat = kde_treat(x_grid)
        density_control = kde_control(x_grid)

        fig, ax = plt.subplots(figsize=figsize)

        ax.fill_between(x_grid, density_treat, alpha=0.3, color="blue", label="Treatment")
        ax.plot(x_grid, density_treat, color="blue")

        ax.fill_between(x_grid, -density_control, alpha=0.3, color="red", label="Control")
        ax.plot(x_grid, -density_control, color="red")

        ax.axhline(0, color="black", linewidth=0.8)

        ax.set_xlabel("Propensity Score")
        ax.set_ylabel("Density")
        ax.set_title(f"Common Support {f'for Experiment {experiment_id}' if experiment_id else ''}")
        ax.legend(loc="best")

        from matplotlib.ticker import FuncFormatter

        ax.yaxis.set_major_formatter(FuncFormatter(lambda x, _: f"{abs(x):.2f}"))

        plt.tight_layout()
        return fig

    def plot_overlap(
        self,
        group_by: str | list[str] | None = None,
        bw_method: float | None = None,
        show_overlap_region: bool = True,
        show_overlap_coef: bool = True,
        title: str | None = None,
        figsize: tuple | None = None,
        save_path: str | None = None,
    ):
        """Mirror density plot of propensity scores for common-support diagnostics.

        Requires that ``get_effects()`` has been called with ``adjustment="balance"``
        so that propensity scores are available in ``self.weights``.

        Parameters
        ----------
        group_by : str or list[str], optional
            Column(s) in ``self.weights`` to split into separate figures.
        bw_method : float, optional
            KDE bandwidth (``None`` uses Scott's rule).
        show_overlap_region : bool, optional
            Shade the region where both densities exceed 5 % of their peak.
        show_overlap_coef : bool, optional
            Annotate each figure with the KDE-based overlap coefficient.
        title : str, optional
            Figure title override.
        figsize : tuple, optional
            ``(width, height)`` in inches.
        save_path : str, optional
            File path to save the figure(s).

        Returns
        -------
        matplotlib.figure.Figure or dict[str, matplotlib.figure.Figure] or None
        """
        from .plotting import plot_overlap as _plot_overlap

        if self.weights is None or self.weights.empty:
            self._logger.warning(
                "No propensity scores available. Call get_effects() with adjustment='balance' before plot_overlap()."
            )
            return None

        if "propensity_score" not in self.weights.columns:
            self._logger.warning(
                "propensity_score column not found in weights. Use balance_method='ps-logistic' or 'ps-xgboost'."
            )
            return None

        return _plot_overlap(
            self.weights,
            treatment_col=self._treatment_col,
            propensity_col="propensity_score",
            group_by=group_by,
            bw_method=bw_method,
            show_overlap_region=show_overlap_region,
            show_overlap_coef=show_overlap_coef,
            title=title,
            figsize=figsize,
            save_path=save_path,
        )

    def _compute_fieller_ci_adjusted(
        self,
        coefficient: float,
        intercept: float,
        se_coef: float,
        se_intercept: float,
        cov: float,
        alpha: float = 0.05,
        df_resid: float | None = None,
    ) -> tuple[float, float]:
        """
        Compute Fieller confidence interval with custom alpha.

        This is a simplified version used for MCP-adjusted relative CIs.
        Uses the same Fieller's theorem as in estimators.py but with adjusted alpha.

        Parameters
        ----------
        coefficient : float
            Treatment effect (numerator)
        intercept : float
            Control mean (denominator)
        se_coef : float
            Standard error of coefficient
        se_intercept : float
            Standard error of intercept
        cov : float
            Covariance between coefficient and intercept
        alpha : float
            Adjusted significance level

        Returns
        -------
        tuple[float, float]
            (lower_bound, upper_bound) or (nan, nan) if cannot compute
        """
        from scipy import stats

        if intercept == 0 or abs(intercept) < 1e-10:
            return (np.nan, np.nan)

        # Use t-distribution when df_resid available (OLS), z otherwise
        if df_resid is not None and np.isfinite(df_resid):
            z_crit = stats.t.ppf(1 - alpha / 2, df_resid)
        else:
            z_crit = stats.norm.ppf(1 - alpha / 2)
        g_sq = z_crit**2

        a = intercept**2 - g_sq * se_intercept**2
        b = -(2 * intercept * coefficient - 2 * g_sq * cov)
        c = coefficient**2 - g_sq * se_coef**2

        if abs(a) < 1e-10:
            return (np.nan, np.nan)

        discriminant = b**2 - 4 * a * c

        if discriminant < 0:
            return (np.nan, np.nan)

        sqrt_disc = np.sqrt(discriminant)
        root1 = (-b - sqrt_disc) / (2 * a)
        root2 = (-b + sqrt_disc) / (2 * a)

        if a > 0:
            ci_lower = min(root1, root2)
            ci_upper = max(root1, root2)
        else:
            return (np.nan, np.nan)

        return (ci_lower, ci_upper)

    def adjust_pvalues(
        self,
        method: str = "bonferroni",
        groupby_cols: list[str] | None = None,
        outcomes: list[str] | None = None,
        experiments: list | None = None,
        alpha: float | None = 0.05,
    ):
        """
        Adjust p-values for multiple comparisons and compute adjusted confidence intervals.

        This method applies multiple comparison corrections to p-values and recalculates
        confidence intervals using method-appropriate alpha adjustments. Results are added
        to the existing results dataframe with '_mcp' suffix (multiple comparison procedure).

        Parameters
        ----------
        method : str, optional
            Multiple comparison adjustment method, by default "bonferroni"
            Options: 'bonferroni', 'holm', 'fdr_bh', 'sidak', 'hommel', 'hochberg', 'by'
        groupby_cols : list[str], optional
            Columns to group by when applying adjustment (default: experiment_identifier)
        outcomes : list[str], optional
            Filter to specific outcomes for adjustment
        experiments : list, optional
            Filter to specific experiments for adjustment
        alpha : float, optional
            Family-wise error rate or false discovery rate threshold, by default 0.05

        Notes
        -----
        Column naming:
        - '_mcp' suffix indicates multiple comparison procedure adjustments
        - This distinguishes from 'adjustment' parameter (balance/IV covariate adjustment)

        Confidence interval adjustments by method:
        - **Bonferroni**: Uses α_CI = α/k for simultaneous coverage
        - **Sidak**: Uses α_CI = 1-(1-α)^(1/k) for independent tests
        - **Sequential methods** (Holm/Hochberg/Hommel): Use conservative Bonferroni
          approach (α/k) since no single per-comparison alpha exists
        - **FDR methods** (BH/BY): Use conservative Bonferroni approach. Note that FDR
          controls expected proportion of false discoveries, not family-wise error rate,
          so simultaneous CI coverage is not directly comparable

        Relative effect CIs:
        - Relative effect CIs are computed using Fieller's method with adjusted alpha
        - Requires stored covariance information (se_intercept, cov_coef_intercept)
        - If covariance info unavailable (e.g., bootstrap results), CIs set to NaN

        Added columns:
        - pvalue_mcp: Adjusted p-values
        - stat_significance_mcp: Significance indicator using adjusted p-values
        - mcp_method: Method used for adjustment
        - abs_effect_lower_mcp: Adjusted lower bound for absolute effect
        - abs_effect_upper_mcp: Adjusted upper bound for absolute effect
        - rel_effect_lower_mcp: Adjusted lower bound for relative effect (Fieller method)
        - rel_effect_upper_mcp: Adjusted upper bound for relative effect (Fieller method)

        Examples
        --------
        >>> analyzer.get_effects()
        >>> analyzer.adjust_pvalues(method='holm')
        >>> results = analyzer.results
        >>> print(results[['pvalue', 'pvalue_mcp', 'stat_significance_mcp']])
        """
        if self._results is None:
            log_and_raise_error(self._logger, "Run get_effects() first.")

        df = self._results.copy()
        group_cols = groupby_cols or self._experiment_identifier or ["experiment"]
        if not all(col in df.columns for col in group_cols):
            log_and_raise_error(self._logger, f"Grouping columns {group_cols} not found in results.")

        mask = pd.Series([True] * len(df), index=df.index)
        if outcomes is not None:
            mask &= df["outcome"].isin(outcomes)
        if experiments is not None:
            for col, vals in zip(group_cols, zip(*experiments, strict=False), strict=False):
                mask &= df[col].isin(vals)
        df_adj = df[mask].copy()
        df_rest = df[~mask].copy()

        def calculate_adjustments(group):
            pvals = group["pvalue"].values
            m = method.lower()
            if m == "bonferroni":
                pvals_adj = np.minimum(pvals * len(pvals), 1.0)
            elif m in {"holm", "fdr_bh", "sidak", "hommel", "hochberg", "by"}:
                from statsmodels.stats.multitest import multipletests

                pvals_adj = multipletests(pvals, method=m)[1]
            else:
                raise ValueError(f"Unknown adjustment method: {method}")

            thres = alpha if alpha is not None else self._alpha

            from scipy import stats

            n_comparisons = len(pvals)

            if m == "bonferroni":
                alpha_ci = thres / n_comparisons
                ci_note = f"Using Bonferroni α/k = {alpha_ci:.6f} for {n_comparisons} comparisons"
            elif m == "sidak":
                alpha_ci = 1 - (1 - thres) ** (1 / n_comparisons)
                ci_note = f"Using Sidak 1-(1-α)^(1/k) = {alpha_ci:.6f} for {n_comparisons} comparisons"
            elif m in {"holm", "hochberg", "hommel"}:
                alpha_ci = thres / n_comparisons
                ci_note = (
                    f"Using conservative Bonferroni α/k = {alpha_ci:.6f} for CIs "
                    f"(sequential method {m} has no single per-comparison alpha)"
                )
                self._logger.warning(ci_note)
            elif m == "fdr_bh" or m == "by":
                alpha_ci = thres / n_comparisons
                ci_note = (
                    f"Using conservative Bonferroni α/k = {alpha_ci:.6f} for CIs "
                    f"(FDR method {m} controls false discovery rate, not family-wise error)"
                )
                self._logger.warning(ci_note)
            else:
                alpha_ci = thres / n_comparisons
                ci_note = f"Using default Bonferroni α/k = {alpha_ci:.6f}"

            # Use t-distribution when df_resid available (OLS), z otherwise
            if "df_resid" in group.columns and group["df_resid"].notna().any():
                crit_adj = (
                    group["df_resid"]
                    .apply(
                        lambda d: stats.t.ppf(1 - alpha_ci / 2, d) if pd.notna(d) else stats.norm.ppf(1 - alpha_ci / 2)
                    )
                    .values
                )
            else:
                crit_adj = stats.norm.ppf(1 - alpha_ci / 2)

            result_dict = {
                "pvalue_mcp": pvals_adj,
                "stat_significance_mcp": (pvals_adj < thres).astype(int),
                "mcp_method": method,
            }

            abs_effect = group["absolute_effect"].values
            se = group["standard_error"].values
            result_dict["abs_effect_lower_mcp"] = abs_effect - crit_adj * se
            result_dict["abs_effect_upper_mcp"] = abs_effect + crit_adj * se

            if "se_intercept" in group.columns and "cov_coef_intercept" in group.columns:
                rel_lower_adj = []
                rel_upper_adj = []

                for idx in range(len(group)):
                    coef = abs_effect[idx]
                    intercept = group["control_value"].values[idx]
                    se_coef = se[idx]
                    se_int = group["se_intercept"].values[idx]
                    cov = group["cov_coef_intercept"].values[idx]
                    df_r = group["df_resid"].values[idx] if "df_resid" in group.columns else None

                    rel_ci_lower, rel_ci_upper = self._compute_fieller_ci_adjusted(
                        coef, intercept, se_coef, se_int, cov, alpha_ci, df_r
                    )
                    rel_lower_adj.append(rel_ci_lower)
                    rel_upper_adj.append(rel_ci_upper)

                result_dict["rel_effect_lower_mcp"] = rel_lower_adj
                result_dict["rel_effect_upper_mcp"] = rel_upper_adj

            elif self._bootstrap_distributions:
                rel_lower_adj = []
                rel_upper_adj = []
                exp_key = group.name

                for idx in range(len(group)):
                    row = group.iloc[idx]
                    comp_key = (row["treatment_group"], row["control_group"])
                    outcome_key = row["outcome"]

                    if (
                        exp_key in self._bootstrap_distributions
                        and comp_key in self._bootstrap_distributions[exp_key]
                        and outcome_key in self._bootstrap_distributions[exp_key][comp_key]
                    ):
                        rel_dist = self._bootstrap_distributions[exp_key][comp_key][outcome_key]["rel_effects"]
                        rel_dist_clean = rel_dist[~np.isnan(rel_dist)]

                        if len(rel_dist_clean) > 0:
                            if self._bootstrap_ci_method == "percentile":
                                rel_lower = np.percentile(rel_dist_clean, alpha_ci / 2 * 100)
                                rel_upper = np.percentile(rel_dist_clean, (1 - alpha_ci / 2) * 100)
                            elif self._bootstrap_ci_method == "basic":
                                observed_rel = row["relative_effect"]
                                rel_lower = 2 * observed_rel - np.percentile(rel_dist_clean, (1 - alpha_ci / 2) * 100)
                                rel_upper = 2 * observed_rel - np.percentile(rel_dist_clean, alpha_ci / 2 * 100)
                            else:
                                rel_lower = np.percentile(rel_dist_clean, alpha_ci / 2 * 100)
                                rel_upper = np.percentile(rel_dist_clean, (1 - alpha_ci / 2) * 100)
                        else:
                            rel_lower = np.nan
                            rel_upper = np.nan
                    else:
                        rel_lower = np.nan
                        rel_upper = np.nan

                    rel_lower_adj.append(rel_lower)
                    rel_upper_adj.append(rel_upper)

                result_dict["rel_effect_lower_mcp"] = rel_lower_adj
                result_dict["rel_effect_upper_mcp"] = rel_upper_adj

            else:
                result_dict["rel_effect_lower_mcp"] = np.nan
                result_dict["rel_effect_upper_mcp"] = np.nan

            return pd.DataFrame(result_dict, index=group.index)

        if "se_intercept" in df_adj.columns and "cov_coef_intercept" in df_adj.columns:
            self._logger.info(
                "Computing adjusted relative effect CIs using Fieller's method with adjusted alpha. "
                "This properly accounts for uncertainty in both numerator and denominator."
            )
        elif self._bootstrap_distributions:
            self._logger.info(
                "Computing adjusted relative effect CIs from bootstrap distributions with adjusted alpha."
            )
        else:
            self._logger.warning(
                "Covariance information (se_intercept, cov_coef_intercept) not found in results, "
                "and no bootstrap distributions available. "
                "Relative effect CIs with MCP adjustment will be set to NaN. "
                "To obtain adjusted relative CIs, re-run get_effects() with bootstrap=True or bootstrap=False."
            )

        adjustments = df_adj.groupby(group_cols, group_keys=False).apply(calculate_adjustments, include_groups=False)

        cols_to_add = [
            "pvalue_mcp",
            "stat_significance_mcp",
            "mcp_method",
            "abs_effect_lower_mcp",
            "abs_effect_upper_mcp",
            "rel_effect_lower_mcp",
            "rel_effect_upper_mcp",
        ]

        df_adj = df_adj.drop(columns=cols_to_add, errors="ignore")
        df_adj = df_adj.join(adjustments)
        df_final = pd.concat([df_adj, df_rest]).sort_index()

        mcp_cols_to_check = ["rel_effect_lower_mcp", "rel_effect_upper_mcp"]
        mcp_cols_to_drop = []
        for col in mcp_cols_to_check:
            if col in df_final.columns and df_final[col].isna().all():
                mcp_cols_to_drop.append(col)

        if mcp_cols_to_drop:
            self._logger.debug(f"Removing MCP columns with all NaN values: {mcp_cols_to_drop}")
            df_final = df_final.drop(columns=mcp_cols_to_drop)

        self._results = df_final
