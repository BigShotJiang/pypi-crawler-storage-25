"""
AgentGraph Intelligence - Tree-sitter Integration Tests
Tests parser accuracy, fallback behaviour, and registry correctness.

Run:
    pytest test_tree_sitter_integration.py -v
    # or without pytest:
    python test_tree_sitter_integration.py
"""

import os
import sys
import json
import tempfile
import textwrap
from pathlib import Path
from typing import Dict, List, Any

# ─────────────────────────────────────────────────────────────────────────────
# Fixture source files per language
# ─────────────────────────────────────────────────────────────────────────────

FIXTURES: Dict[str, str] = {

    ".py": textwrap.dedent("""\
        \"\"\"Module docstring.\"\"\"
        import os
        from pathlib import Path
        from typing import List, Optional

        CONSTANT = 42

        class Animal:
            \"\"\"Base animal class.\"\"\"
            def __init__(self, name: str) -> None:
                self.name = name

            def speak(self) -> str:
                raise NotImplementedError

        class Dog(Animal):
            \"\"\"Dog speaks.\"\"\"
            def speak(self) -> str:
                return f"Woof {self.name}"

            def fetch(self, item: str) -> bool:
                if item:
                    return True
                return False

        def standalone(x: int, y: int) -> int:
            \"\"\"Standalone function.\"\"\"
            return x + y
    """),

    ".js": textwrap.dedent("""\
        import { readFile } from 'fs';
        import path from 'path';

        class Vehicle {
            constructor(make, model) {
                this.make = make;
                this.model = model;
            }
            describe() {
                return `${this.make} ${this.model}`;
            }
        }

        class Car extends Vehicle {
            constructor(make, model, doors) {
                super(make, model);
                this.doors = doors;
            }
        }

        function greet(name) {
            if (!name) return 'Hello';
            return `Hello, ${name}`;
        }

        const add = (a, b) => a + b;
    """),

    ".ts": textwrap.dedent("""\
        import { Injectable } from '@angular/core';
        import { HttpClient } from '@angular/common/http';

        interface UserData {
            id: number;
            name: string;
        }

        @Injectable()
        class UserService {
            constructor(private http: HttpClient) {}

            getUser(id: number): Promise<UserData> {
                return this.http.get<UserData>(`/api/users/${id}`).toPromise();
            }
        }

        class AdminService extends UserService {
            listAll(): Promise<UserData[]> {
                return this.http.get<UserData[]>('/api/users').toPromise();
            }
        }

        function parseDate(raw: string): Date {
            return new Date(raw);
        }
    """),

    ".java": textwrap.dedent("""\
        package com.example.service;

        import java.util.List;
        import java.util.Optional;
        import org.springframework.stereotype.Service;

        /** User service. */
        @Service
        public class UserService {
            private final UserRepository repo;

            public UserService(UserRepository repo) {
                this.repo = repo;
            }

            /** Find user by id. */
            public Optional<User> findById(Long id) {
                return repo.findById(id);
            }

            public List<User> findAll() {
                return repo.findAll();
            }
        }

        interface UserRepository {
            Optional<User> findById(Long id);
            List<User> findAll();
        }
    """),

    ".go": textwrap.dedent("""\
        package main

        import (
            "fmt"
            "strings"
        )

        // Animal interface
        type Animal interface {
            Speak() string
            Name() string
        }

        // Dog struct
        type Dog struct {
            name string
            age  int
        }

        func (d *Dog) Speak() string {
            return fmt.Sprintf("Woof! I am %s", d.name)
        }

        func (d *Dog) Name() string {
            return d.name
        }

        func NewDog(name string, age int) *Dog {
            return &Dog{name: name, age: age}
        }

        func main() {
            dog := NewDog("Rex", 3)
            fmt.Println(dog.Speak())
        }
    """),

    ".rs": textwrap.dedent("""\
        use std::fmt;
        use std::collections::HashMap;

        /// Animal trait
        pub trait Animal {
            fn speak(&self) -> String;
            fn name(&self) -> &str;
        }

        /// Dog struct
        pub struct Dog {
            name: String,
            age: u32,
        }

        impl Dog {
            pub fn new(name: &str, age: u32) -> Self {
                Dog { name: name.to_string(), age }
            }
        }

        impl Animal for Dog {
            fn speak(&self) -> String {
                format!("Woof! I am {}", self.name)
            }

            fn name(&self) -> &str {
                &self.name
            }
        }

        impl fmt::Display for Dog {
            fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
                write!(f, "Dog({})", self.name)
            }
        }

        pub fn greet(animal: &dyn Animal) -> String {
            format!("Hello, {}!", animal.name())
        }
    """),

    ".cpp": textwrap.dedent("""\
        #include <iostream>
        #include <string>
        #include <vector>

        namespace animals {

        class Animal {
        public:
            Animal(const std::string& name) : name_(name) {}
            virtual std::string speak() const = 0;
            const std::string& name() const { return name_; }
        protected:
            std::string name_;
        };

        class Dog : public Animal {
        public:
            Dog(const std::string& name) : Animal(name) {}
            std::string speak() const override {
                return "Woof! I am " + name_;
            }
        };

        } // namespace animals

        std::string greet(const animals::Animal& a) {
            return "Hello, " + a.name();
        }

        int main() {
            animals::Dog dog("Rex");
            std::cout << dog.speak() << std::endl;
            return 0;
        }
    """),
}


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _write_fixture(suffix: str, content: str) -> str:
    """Write fixture to a temp file and return its path."""
    f = tempfile.NamedTemporaryFile(suffix=suffix, mode="w", delete=False, encoding="utf-8")
    f.write(content)
    f.close()
    return f.name


def _node_names(nodes: List[Dict]) -> List[str]:
    return [n["name"] for n in nodes]


def _has_type(nodes: List[Dict], agtype: str, name_substr: str = "") -> bool:
    for n in nodes:
        if n["type"] == agtype:
            if not name_substr or name_substr in n["name"]:
                return True
    return False


def _has_edge(edges: List[Dict], rel: str, from_sub: str = "", to_sub: str = "") -> bool:
    for e in edges:
        if e["relationship"] == rel:
            if (not from_sub or from_sub in e["from_name"]) and \
               (not to_sub   or to_sub   in e["to_name"]):
                return True
    return False


# ─────────────────────────────────────────────────────────────────────────────
# Test runner (works with or without pytest)
# ─────────────────────────────────────────────────────────────────────────────

_RESULTS: List[Dict] = []

def _test(name: str, passed: bool, detail: str = ""):
    _RESULTS.append({"name": name, "passed": passed, "detail": detail})
    status = "PASS" if passed else "FAIL"
    print(f"  [{status}] {name}" + (f" — {detail}" if detail else ""))


# ─────────────────────────────────────────────────────────────────────────────
# Core tests
# ─────────────────────────────────────────────────────────────────────────────

def test_config_registry():
    print("\n── Config Registry ──")
    from tree_sitter_configs import get_config, EXT_TO_CONFIG, ALL_CONFIGS
    exts = [".py", ".js", ".ts", ".java", ".go", ".rs", ".cpp"]
    for ext in exts:
        cfg = get_config(f"file{ext}")
        _test(f"config for {ext}", cfg is not None, cfg.name if cfg else "MISSING")

    _test("all 7 configs loaded", len(ALL_CONFIGS) == 7)
    _test("EXT_TO_CONFIG has all keys", all(e in EXT_TO_CONFIG for e in exts))


def test_parser_registry():
    print("\n── Parser Registry ──")
    sys.path.insert(0, str(Path(__file__).parent))
    from __init__ import ParserRegistry

    reg = ParserRegistry()
    exts = [".py", ".js", ".ts", ".java", ".go", ".rs", ".cpp", ".h", ".tsx"]
    for ext in exts:
        _test(f"registry supports {ext}", reg.is_supported(f"file{ext}"))

    _test("status_report returns dict", isinstance(reg.status_report(), dict))


def test_language_python():
    print("\n── Python ──")
    _test_language(".py", {
        "classes":   ["Animal", "Dog"],
        "functions": ["standalone"],
        "imports":   True,
        "inherits":  ("Dog", "Animal"),
    })


def test_language_javascript():
    print("\n── JavaScript ──")
    _test_language(".js", {
        "classes":   ["Vehicle", "Car"],
        "functions": ["greet"],
        "imports":   True,
        "inherits":  ("Car", "Vehicle"),
    })


def test_language_typescript():
    print("\n── TypeScript ──")
    _test_language(".ts", {
        "classes":    ["UserService", "AdminService"],
        "functions":  ["parseDate"],
        "interfaces": ["UserData"],
        "imports":    True,
        "inherits":   ("AdminService", "UserService"),
    })


def test_language_java():
    print("\n── Java ──")
    _test_language(".java", {
        "classes":    ["UserService"],
        "interfaces": ["UserRepository"],
        "imports":    True,
    })


def test_language_go():
    print("\n── Go ──")
    _test_language(".go", {
        "imports": True,
    })


def test_language_rust():
    print("\n── Rust ──")
    _test_language(".rs", {
        "imports": True,
    })


def test_language_cpp():
    print("\n── C++ ──")
    _test_language(".cpp", {
        "classes": ["Animal", "Dog"],
        "imports": True,
    })


def _test_language(ext: str, expectations: Dict):
    """Generic language test against FIXTURES."""
    from __init__ import ParserRegistry

    reg    = ParserRegistry()
    path   = _write_fixture(ext, FIXTURES[ext])
    try:
        parser = reg.get_parser(path)
        _test(f"{ext} parser found", parser is not None)
        if not parser:
            return

        result = parser.parse(path)
        nodes  = result.get("nodes", [])
        edges  = result.get("edges", [])
        errors = result.get("errors", [])

        _test(f"{ext} no crash",         result is not None)
        _test(f"{ext} has nodes",        len(nodes) > 0, f"{len(nodes)} nodes")
        _test(f"{ext} has edges",        len(edges) > 0, f"{len(edges)} edges")
        _test(f"{ext} has module node",  _has_type(nodes, "module"), "")
        _test(f"{ext} parse errors ok",  len(errors) == 0, str(errors) if errors else "")

        # Type-specific checks
        for cls_name in expectations.get("classes", []):
            _test(f"{ext} class {cls_name}", _has_type(nodes, "class", cls_name), "")

        for fn_name in expectations.get("functions", []):
            found = any(fn_name in n["name"] and n["type"] in ("function", "method") for n in nodes)
            _test(f"{ext} function {fn_name}", found, "")

        for if_name in expectations.get("interfaces", []):
            _test(f"{ext} interface {if_name}", _has_type(nodes, "interface", if_name), "")

        if expectations.get("imports"):
            _test(f"{ext} has dependency nodes", _has_type(nodes, "dependency"), "")
            _test(f"{ext} has imports edges",    _has_edge(edges, "imports"), "")

        inherit = expectations.get("inherits")
        if inherit:
            child, parent = inherit
            found = _has_edge(edges, "inherits", child, parent) or \
                    _has_edge(edges, "extends",  child, parent)
            _test(f"{ext} {child} inherits {parent}", found, "")

        # Quality & complexity sanity
        for n in nodes:
            if n["type"] in ("function", "method", "class"):
                _test(f"{ext} quality in range [{n['name']}]",
                      0.0 <= n.get("quality", 0) <= 100.0,
                      f"q={n.get('quality')}")
                break   # just check one

        # Provenance
        for n in nodes:
            prov = n.get("provenance", "")
            _test(f"{ext} provenance set", prov in ("tree_sitter", "regex_parser"), prov)
            break

    finally:
        os.unlink(path)


def test_fallback_behaviour():
    """If tree-sitter is unavailable, regex parsers should still work."""
    print("\n── Fallback Behaviour ──")
    from __init__ import ParserRegistry
    reg = ParserRegistry(prefer_tree_sitter=False)
    path = _write_fixture(".py", FIXTURES[".py"])
    try:
        parser = reg.get_parser(path)
        _test("regex fallback parser found", parser is not None)
        if parser:
            result = parser.parse(path)
            _test("regex fallback produces nodes", len(result.get("nodes", [])) > 0)
    finally:
        os.unlink(path)


def test_confidence_provenance():
    """All nodes must carry confidence and provenance fields."""
    print("\n── Confidence / Provenance ──")
    from __init__ import ParserRegistry
    reg  = ParserRegistry()
    path = _write_fixture(".py", FIXTURES[".py"])
    try:
        result = reg.get_parser(path).parse(path)
        for node in result.get("nodes", []):
            _test("node has confidence",
                  "confidence" in node and node["confidence"] in ("EXTRACTED", "INFERRED", "AMBIGUOUS"),
                  node.get("confidence"))
            _test("node has provenance",
                  "provenance" in node,
                  node.get("provenance"))
            break
        for edge in result.get("edges", []):
            _test("edge has confidence",  "confidence" in edge, "")
            _test("edge has provenance",  "provenance" in edge, "")
            break
    finally:
        os.unlink(path)


def test_incremental_scan():
    """SHA256 caching skips unchanged files on second scan."""
    print("\n── Incremental Scan ──")
    try:
        # Minimal DB shim
        class _FakeDB:
            def __init__(self):
                self._hashes = {}
                self._nodes = []
                self._edges = []
                self._scans = []
                self._queries = []
            def is_file_changed(self, p):
                import hashlib
                h = hashlib.sha256(Path(p).read_bytes()).hexdigest()
                return self._hashes.get(p) != h
            def record_file_hash(self, p):
                import hashlib
                self._hashes[p] = hashlib.sha256(Path(p).read_bytes()).hexdigest()
            def upsert_node(self, **kw): self._nodes.append(kw)
            def upsert_edge(self, **kw): self._edges.append(kw)
            def clear_file(self, f): pass
            def log_scan(self, *a): pass
            def log_query(self, *a): pass

        from __init__ import ParserRegistry, CodebaseScanner

        with tempfile.TemporaryDirectory() as tmpdir:
            py_file = Path(tmpdir) / "sample.py"
            py_file.write_text(FIXTURES[".py"])

            db      = _FakeDB()
            scanner = CodebaseScanner(db, ParserRegistry())

            r1 = scanner.scan(tmpdir)
            n1 = r1["nodes"]

            r2 = scanner.scan(tmpdir, incremental=True)
            n2 = r2["nodes"]

            _test("first scan finds nodes",   n1 > 0, f"nodes={n1}")
            _test("second scan skips file",   r2.get("skipped", 0) >= 1,
                  f"skipped={r2.get('skipped')}")

    except Exception as e:
        _test("incremental scan test", False, str(e))


def test_schema_mapping():
    """Schema fields must match AgentGraph database expectations."""
    print("\n── Schema Mapping ──")
    REQUIRED_NODE_FIELDS  = {"name","type","file","language","line_start","line_end",
                              "complexity","quality","signature","docstring","metadata",
                              "confidence","provenance"}
    REQUIRED_EDGE_FIELDS  = {"from_name","from_file","to_name","to_file",
                              "relationship","weight","confidence","provenance"}
    from __init__ import ParserRegistry
    reg  = ParserRegistry()
    path = _write_fixture(".py", FIXTURES[".py"])
    try:
        result = reg.get_parser(path).parse(path)
        for node in result.get("nodes", []):
            missing = REQUIRED_NODE_FIELDS - set(node.keys())
            _test("node schema complete", not missing, str(missing) if missing else "")
            break
        for edge in result.get("edges", []):
            missing = REQUIRED_EDGE_FIELDS - set(edge.keys())
            _test("edge schema complete", not missing, str(missing) if missing else "")
            break
    finally:
        os.unlink(path)


def test_ts_registry_status():
    print("\n── TreeSitterRegistry Status ──")
    try:
        from tree_sitter_parser import get_global_registry
        reg = get_global_registry()
        report = reg.status_report()
        _test("status_report is list",     isinstance(report, list))
        _test("7 language entries",        len(report) == 7, f"got {len(report)}")
        for entry in report:
            _test(f"status for {entry['language']}",
                  "tree_sitter" in entry and "extensions" in entry)
    except ImportError:
        _test("TreeSitterRegistry import", False, "tree_sitter_parser not importable")


# ─────────────────────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────────────────────

def run_all():
    print("=" * 60)
    print("AgentGraph Tree-sitter Integration Tests")
    print("=" * 60)

    tests = [
        test_config_registry,
        test_parser_registry,
        test_language_python,
        test_language_javascript,
        test_language_typescript,
        test_language_java,
        test_language_go,
        test_language_rust,
        test_language_cpp,
        test_fallback_behaviour,
        test_confidence_provenance,
        test_incremental_scan,
        test_schema_mapping,
        test_ts_registry_status,
    ]

    for fn in tests:
        try:
            fn()
        except Exception as e:
            print(f"  [ERROR] {fn.__name__}: {e}")

    passed = sum(1 for r in _RESULTS if r["passed"])
    total  = len(_RESULTS)
    print("\n" + "=" * 60)
    print(f"Results: {passed}/{total} passed")
    if passed < total:
        print("\nFailures:")
        for r in _RESULTS:
            if not r["passed"]:
                print(f"  FAIL  {r['name']}  {r['detail']}")
    print("=" * 60)
    return passed == total


# ── pytest compatibility ───────────────────────────────────────────────────

def test_all_via_pytest():
    """Single pytest entry point that runs everything."""
    assert run_all(), "One or more tests failed — see output above"


if __name__ == "__main__":
    ok = run_all()
    sys.exit(0 if ok else 1)
