"""
AgentGraph Intelligence - JavaScript / TypeScript Parser
Regex + structural analysis for JS/TS. Handles ES6+, CommonJS, TypeScript.
"""

import re
from pathlib import Path
from typing import List, Dict, Any, Optional


class JavaScriptParser:
    LANGUAGE = "javascript"
    EXTENSIONS = {".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs"}

    # Patterns
    _RE_CLASS      = re.compile(r'(?:export\s+)?(?:abstract\s+)?class\s+(\w+)(?:\s+extends\s+(\w+))?(?:\s+implements\s+([\w,\s]+))?', re.M)
    _RE_FUNCTION   = re.compile(r'(?:export\s+)?(?:async\s+)?function\s*\*?\s+(\w+)\s*\(([^)]*)\)(?:\s*:\s*(\w[\w<>\[\]|&\s]*))?', re.M)
    _RE_ARROW      = re.compile(r'(?:export\s+)?(?:const|let|var)\s+(\w+)\s*(?::\s*[\w<>\[\]|&\s]+)?\s*=\s*(?:async\s+)?\(([^)]*)\)\s*(?::\s*(\w[\w<>\[\]|&\s]*))?\s*=>', re.M)
    _RE_ARROW_SIMPLE = re.compile(r'(?:export\s+)?(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s+)?(\w+)\s*=>', re.M)
    _RE_METHOD     = re.compile(r'(?:(?:public|private|protected|static|async|readonly|override)\s+)*(\w+)\s*\(([^)]*)\)(?:\s*:\s*([\w<>\[\]|&\s]+))?\s*\{', re.M)
    _RE_IMPORT_ES6 = re.compile(r'import\s+(?:\{([^}]+)\}|(\w+)|\*\s+as\s+(\w+))\s+from\s+[\'"]([^\'"]+)[\'"]', re.M)
    _RE_REQUIRE    = re.compile(r'(?:const|let|var)\s+(?:\{([^}]+)\}|(\w+))\s*=\s*require\([\'"]([^\'"]+)[\'"]\)', re.M)
    _RE_INTERFACE  = re.compile(r'(?:export\s+)?interface\s+(\w+)(?:\s+extends\s+([\w,\s]+))?', re.M)
    _RE_TYPE_ALIAS = re.compile(r'(?:export\s+)?type\s+(\w+)\s*=', re.M)
    _RE_DECORATOR  = re.compile(r'@(\w+)(?:\([^)]*\))?', re.M)
    _RE_EXPORT_DEF = re.compile(r'export\s+(?:default\s+)?(?:const|let|var)\s+(\w+)', re.M)
    _RE_CONST      = re.compile(r'^(?:export\s+)?(?:const|let|var)\s+(\w+)\s*=\s*(?!(?:async\s+)?\(?.*=>)', re.M)

    def parse(self, file_path: str) -> Dict[str, Any]:
        path = Path(file_path)
        nodes, edges, errors = [], [], []

        try:
            source = path.read_text(encoding="utf-8", errors="replace")
        except Exception as e:
            return {"nodes": [], "edges": [], "errors": [str(e)]}

        lines    = source.splitlines()
        rel_file = str(path)
        lang     = "typescript" if path.suffix in (".ts", ".tsx") else "javascript"

        module_node = {
            "name":       path.stem,
            "type":       "module",
            "file":       rel_file,
            "language":   lang,
            "line_start": 1,
            "line_end":   len(lines),
            "complexity": 0,
            "quality":    100.0,
            "signature":  f"module {path.stem}",
            "docstring":  self._extract_jsdoc(source, 0),
            "metadata":   {"framework": self._detect_framework(source)},
        }
        nodes.append(module_node)

        # ── Imports ──────────────────────────────────────────────
        for m in self._RE_IMPORT_ES6.finditer(source):
            named, default, star, mod_path = m.groups()
            symbols = []
            if named:   symbols = [s.strip().split(" as ")[0].strip() for s in named.split(",")]
            if default: symbols = [default]
            if star:    symbols = [f"* as {star}"]
            lineno = source[:m.start()].count("\n") + 1
            for sym in symbols:
                sym = sym.strip()
                if not sym: continue
                dep_name = f"{mod_path}.{sym}" if sym != "*" else mod_path
                nodes.append(self._dep_node(dep_name, rel_file, lang, lineno, f"import {{ {sym} }} from '{mod_path}'"))
                edges.append(self._edge(path.stem, rel_file, dep_name, rel_file, "imports", 6.0))

        for m in self._RE_REQUIRE.finditer(source):
            named, default, mod_path = m.groups()
            lineno = source[:m.start()].count("\n") + 1
            mod_name = default or mod_path
            nodes.append(self._dep_node(mod_name, rel_file, lang, lineno, f"require('{mod_path}')"))
            edges.append(self._edge(path.stem, rel_file, mod_name, rel_file, "imports", 5.0))

        # ── Interfaces (TypeScript) ──────────────────────────────
        for m in self._RE_INTERFACE.finditer(source):
            iname, extends = m.groups()
            lineno    = source[:m.start()].count("\n") + 1
            end_line  = self._find_closing_brace(lines, lineno)
            nodes.append({
                "name": iname, "type": "interface",
                "file": rel_file, "language": lang,
                "line_start": lineno, "line_end": end_line,
                "complexity": 0, "quality": 100.0,
                "signature": f"interface {iname}" + (f" extends {extends}" if extends else ""),
                "docstring": self._extract_jsdoc(source, m.start()),
                "metadata": {"extends": extends.split(",") if extends else []},
            })
            edges.append(self._edge(path.stem, rel_file, iname, rel_file, "defines", 8.0))
            if extends:
                for base in extends.split(","):
                    base = base.strip()
                    if base:
                        edges.append(self._edge(iname, rel_file, base, rel_file, "extends", 9.0))

        # ── Classes ──────────────────────────────────────────────
        class_names = set()
        for m in self._RE_CLASS.finditer(source):
            cname, extends, implements = m.groups()
            class_names.add(cname)
            lineno   = source[:m.start()].count("\n") + 1
            end_line = self._find_closing_brace(lines, lineno)
            cx = self._estimate_complexity(source[m.start():m.start() + 3000])

            nodes.append({
                "name": cname, "type": "class",
                "file": rel_file, "language": lang,
                "line_start": lineno, "line_end": end_line,
                "complexity": cx, "quality": 100.0,
                "signature": self._class_sig(m),
                "docstring": self._extract_jsdoc(source, m.start()),
                "metadata": {
                    "extends": extends or "",
                    "implements": [i.strip() for i in implements.split(",")] if implements else [],
                    "decorators": self._decorators_before(source, m.start()),
                },
            })
            edges.append(self._edge(path.stem, rel_file, cname, rel_file, "defines", 8.0))
            if extends:
                edges.append(self._edge(cname, rel_file, extends, rel_file, "inherits", 9.0))
            if implements:
                for iface in implements.split(","):
                    iface = iface.strip()
                    if iface:
                        edges.append(self._edge(cname, rel_file, iface, rel_file, "implements", 8.0))

        # ── Functions ────────────────────────────────────────────
        for m in self._RE_FUNCTION.finditer(source):
            fname, params, returns = m.groups()
            if fname in class_names: continue
            lineno   = source[:m.start()].count("\n") + 1
            end_line = self._find_closing_brace(lines, lineno)
            cx = self._estimate_complexity(source[m.start():m.start() + 2000])

            nodes.append({
                "name": fname, "type": "function",
                "file": rel_file, "language": lang,
                "line_start": lineno, "line_end": end_line,
                "complexity": cx, "quality": 100.0,
                "signature": f"function {fname}({params or ''})" + (f": {returns}" if returns else ""),
                "docstring": self._extract_jsdoc(source, m.start()),
                "metadata": {"params": params or "", "returns": returns or "", "is_exported": "export" in source[max(0,m.start()-10):m.start()+5]},
            })
            edges.append(self._edge(path.stem, rel_file, fname, rel_file, "defines", 7.0))

        # ── Arrow Functions ──────────────────────────────────────
        for m in self._RE_ARROW.finditer(source):
            fname, params, returns = m.groups()
            if fname in class_names: continue
            lineno = source[:m.start()].count("\n") + 1
            cx = self._estimate_complexity(source[m.start():m.start() + 1000])

            nodes.append({
                "name": fname, "type": "function",
                "file": rel_file, "language": lang,
                "line_start": lineno, "line_end": lineno + 20,
                "complexity": cx, "quality": 100.0,
                "signature": f"const {fname} = ({params or ''}) =>" + (f": {returns}" if returns else ""),
                "docstring": "",
                "metadata": {"params": params or "", "returns": returns or "", "is_arrow": True},
            })
            edges.append(self._edge(path.stem, rel_file, fname, rel_file, "defines", 6.0))

        # Quality scoring
        for node in nodes:
            node["quality"] = self._score_quality(node)

        return {"nodes": nodes, "edges": edges, "errors": errors}

    def _estimate_complexity(self, code: str) -> int:
        """Fast regex-based McCabe estimate."""
        keywords = len(re.findall(
            r'\b(if|else|for|while|switch|case|catch|&&|\|\||\?)\b', code
        ))
        return min(1 + keywords, 20)

    def _find_closing_brace(self, lines: List[str], start_line: int) -> int:
        depth = 0
        for i, line in enumerate(lines[start_line - 1:], start=start_line):
            depth += line.count("{") - line.count("}")
            if depth <= 0 and i > start_line:
                return i
        return start_line + 50

    def _extract_jsdoc(self, source: str, pos: int) -> str:
        before = source[max(0, pos - 300):pos]
        m = re.search(r'/\*\*(.*?)\*/', before, re.DOTALL)
        if m:
            doc = re.sub(r'\s*\*\s?', ' ', m.group(1)).strip()
            return re.sub(r'\s+', ' ', doc)
        return ""

    def _decorators_before(self, source: str, pos: int) -> List[str]:
        before = source[max(0, pos - 200):pos]
        return [m.group(1) for m in self._RE_DECORATOR.finditer(before)]

    def _detect_framework(self, source: str) -> str:
        if "from 'react'" in source or 'from "react"' in source:   return "react"
        if "from 'vue'"   in source or 'from "vue"'   in source:   return "vue"
        if "@angular/core" in source:                               return "angular"
        if "from 'next'"  in source or "next/app" in source:       return "nextjs"
        if "express()"    in source or "require('express')" in source: return "express"
        if "from 'fastify'" in source:                             return "fastify"
        return "vanilla"

    def _class_sig(self, m: re.Match) -> str:
        cname, extends, implements = m.groups()
        s = f"class {cname}"
        if extends:    s += f" extends {extends}"
        if implements: s += f" implements {implements}"
        return s

    def _dep_node(self, name: str, file: str, lang: str, lineno: int, sig: str) -> Dict:
        return {
            "name": name, "type": "dependency",
            "file": file, "language": lang,
            "line_start": lineno, "line_end": lineno,
            "complexity": 0, "quality": 100.0,
            "signature": sig, "docstring": "",
            "metadata": {},
        }

    def _edge(self, fn: str, ff: str, tn: str, tf: str, rel: str, w: float) -> Dict:
        return {
            "from_name": fn, "from_file": ff,
            "to_name":   tn, "to_file":   tf,
            "relationship": rel, "weight": w,
        }

    def _score_quality(self, node: Dict) -> float:
        score = 100.0
        cx    = node.get("complexity", 0)
        if cx > 10: score -= 30
        elif cx > 7: score -= 20
        elif cx > 5: score -= 10
        if not node.get("docstring") and node["type"] in ("function", "class"):
            score -= 8
        return max(0.0, min(100.0, score))
