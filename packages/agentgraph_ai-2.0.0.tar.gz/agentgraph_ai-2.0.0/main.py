"""
AgentGraph Intelligence - Main Entry Point
Single command to rule them all.

Usage:
    python main.py serve                     # Start API server
    python main.py scan /path/to/project     # Scan a codebase
    python main.py query "what does X depend on"
    python main.py watch /path/to/project    # Watch without full scan
"""

import sys
import time
import typer
import uvicorn
from pathlib import Path
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
from rich.table   import Table
from rich.panel   import Panel
from rich         import print as rprint

from agentgraph.core.database        import GraphDatabase
from agentgraph.parsers              import ParserRegistry, CodebaseScanner
from agentgraph.watcher.file_watcher import FileWatcher
from agentgraph.query.engine         import QueryEngine
from agentgraph.agents.formatter     import format_for_claude, format_universal

app_cli = typer.Typer(
    name    = "agentgraph",
    help    = "AgentGraph Intelligence — The AI brain for every coding agent.",
    add_completion = False,
)
console = Console()


def _banner():
    console.print(Panel.fit(
        "[bold cyan]AgentGraph Intelligence[/bold cyan] [dim]v2.0.0[/dim]\n"
        "[dim]Superior to Graphify. Built for AI agents.[/dim]",
        border_style = "cyan",
    ))


@app_cli.command()
def serve(
    host: str = typer.Option("0.0.0.0", help="Host to bind"),
    port: int = typer.Option(8000,       help="Port to listen on"),
    reload: bool = typer.Option(False,   help="Auto-reload on code changes"),
):
    """Start the AgentGraph API server."""
    _banner()
    console.print(f"[green]Starting server[/green] on [cyan]http://{host}:{port}[/cyan]")
    console.print(f"[dim]API docs at http://{host}:{port}/docs[/dim]")
    uvicorn.run(
        "agentgraph.api.server:app",
        host    = host,
        port    = port,
        reload  = reload,
        workers = 1,
        log_level = "warning",
    )


@app_cli.command()
def scan(
    path:  str  = typer.Argument(..., help="Path to the codebase to scan"),
    watch: bool = typer.Option(True,  help="Watch for changes after scanning"),
    serve_after: bool = typer.Option(False, "--serve", help="Start API server after scan"),
    port:  int  = typer.Option(8000,  help="Port (if --serve)"),
):
    """Scan a codebase and build the knowledge graph."""
    _banner()
    root = Path(path).resolve()
    if not root.exists():
        console.print(f"[red]Path not found:[/red] {path}")
        raise typer.Exit(1)

    db       = GraphDatabase("agentgraph.db")
    registry = ParserRegistry()

    scanned_files = []

    def on_progress(done, total, file):
        pass  # handled by rich progress

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        console = console,
    ) as progress:
        # Collect files first
        files = CodebaseScanner(db, registry)._collect_files(root)
        total = len(files)
        task  = progress.add_task(
            f"[cyan]Scanning {total} files...[/cyan]", total=total
        )

        done_count = [0]
        def on_file(file_path):
            done_count[0] += 1
            scanned_files.append(file_path)
            progress.update(task, advance=1, description=f"[cyan]{Path(file_path).name}[/cyan]")

        scanner = CodebaseScanner(db, registry, on_file_scanned=on_file)
        t0      = time.perf_counter()
        result  = scanner.scan(str(root))
        elapsed = time.perf_counter() - t0

    # Summary table
    table = Table(title="Scan Complete", border_style="cyan")
    table.add_column("Metric",  style="dim")
    table.add_column("Value",   style="cyan bold")
    table.add_row("Files scanned",  str(result["files"]))
    table.add_row("Nodes found",    str(result["nodes"]))
    table.add_row("Edges mapped",   str(result["edges"]))
    table.add_row("Parse errors",   str(result["errors"]))
    table.add_row("Duration",       f"{elapsed:.2f}s")
    table.add_row("Speed",          f"{result.get('files_per_s', 0):.0f} files/sec")
    console.print(table)

    stats = db.get_stats()
    console.print(f"\n[bold]Avg Quality:[/bold] [cyan]{stats['avg_quality']}%[/cyan]   "
                  f"[bold]Avg Complexity:[/bold] [yellow]{stats['avg_complexity']}[/yellow]")
    if stats.get("languages"):
        lang_str = "  ".join(f"[cyan]{k}[/cyan]:{v}" for k, v in stats["languages"].items())
        console.print(f"[bold]Languages:[/bold] {lang_str}")

    if watch:
        watcher = FileWatcher(db, scanner)
        watcher.watch(str(root))
        console.print(f"\n[green]Watching[/green] {root} for changes...")

    if serve_after:
        console.print(f"\n[green]Starting API server on port {port}...[/green]")
        uvicorn.run(
            "agentgraph.api.server:app",
            port=port, log_level="warning"
        )
    elif watch:
        console.print("[dim]Press Ctrl+C to stop.[/dim]")
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            watcher.stop()
            console.print("\n[yellow]Stopped.[/yellow]")

    db.close()


@app_cli.command()
def query(
    q:     str = typer.Argument(..., help="Natural language query"),
    agent: str = typer.Option("claude", help="Agent type (claude|universal|json)"),
    db:    str = typer.Option("agentgraph.db", help="Database file"),
):
    """Query the knowledge graph from the command line."""
    _banner()
    database = GraphDatabase(db)
    engine   = QueryEngine(database)
    result   = engine.query(q)

    if agent == "claude":
        output = format_for_claude(result)
    elif agent == "json":
        import json as _json
        from agentgraph.agents.formatter import format_json
        output = _json.dumps(format_json(result), indent=2)
    else:
        output = format_universal(result)

    console.print(Panel(output, title=f"[cyan]{q}[/cyan]", border_style="cyan"))
    database.close()


@app_cli.command()
def info(db: str = typer.Option("agentgraph.db", help="Database file")):
    """Show codebase stats from the current graph database."""
    _banner()
    database = GraphDatabase(db)
    stats    = database.get_stats()
    hotspots = database.get_hotspots(5)
    cycles   = database.find_cycles()

    # Stats table
    table = Table(title="Knowledge Graph Stats", border_style="cyan")
    table.add_column("Metric"); table.add_column("Value", style="cyan bold")
    table.add_row("Total nodes",     str(stats["nodes"]))
    table.add_row("Total edges",     str(stats["edges"]))
    table.add_row("Avg quality",     f"{stats['avg_quality']}%")
    table.add_row("Avg complexity",  str(stats["avg_complexity"]))
    table.add_row("Circular deps",   str(len(cycles)))
    table.add_row("Cache hit rate",  f"{stats['cache_hit_rate']}%")
    console.print(table)

    if stats.get("languages"):
        lang_table = Table(title="Languages", border_style="dim")
        lang_table.add_column("Language"); lang_table.add_column("Nodes", style="cyan")
        for lang, count in stats["languages"].items():
            lang_table.add_row(lang, str(count))
        console.print(lang_table)

    if hotspots:
        hs_table = Table(title="Top Complexity Hotspots", border_style="yellow")
        hs_table.add_column("Name"); hs_table.add_column("Type")
        hs_table.add_column("Complexity", style="yellow")
        hs_table.add_column("Quality", style="cyan")
        hs_table.add_column("File", style="dim")
        for h in hotspots:
            hs_table.add_row(
                h["name"], h["type"],
                str(h["complexity"]), f"{h['quality']:.0f}%",
                h["file"]
            )
        console.print(hs_table)

    database.close()


if __name__ == "__main__":
    app_cli()
