"""
AgentGraph Intelligence - Core Database Engine
SQLite-based graph store with WAL mode, full indexing, and microsecond queries.
"""

import sqlite3
import json
import time
import uuid
import hashlib
import threading
from pathlib import Path
from typing import Optional, List, Dict, Any, Tuple
from contextlib import contextmanager


SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;
PRAGMA cache_size=-64000;
PRAGMA temp_store=MEMORY;
PRAGMA mmap_size=268435456;

CREATE TABLE IF NOT EXISTS nodes (
    id          TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    type        TEXT NOT NULL,
    file        TEXT NOT NULL,
    language    TEXT NOT NULL,
    line_start  INTEGER DEFAULT 0,
    line_end    INTEGER DEFAULT 0,
    complexity  INTEGER DEFAULT 0,
    quality     REAL    DEFAULT 100.0,
    signature   TEXT    DEFAULT '',
    docstring   TEXT    DEFAULT '',
    metadata    TEXT    DEFAULT '{}',
    confidence  TEXT    DEFAULT 'EXTRACTED',
    provenance  TEXT    DEFAULT 'regex_parser',
    created_at  REAL    NOT NULL,
    updated_at  REAL    NOT NULL
);

CREATE TABLE IF NOT EXISTS edges (
    id           TEXT PRIMARY KEY,
    from_node    TEXT NOT NULL,
    to_node      TEXT NOT NULL,
    relationship TEXT NOT NULL,
    weight       REAL DEFAULT 1.0,
    confidence   REAL DEFAULT 1.0,
    provenance   TEXT DEFAULT 'regex_parser',
    metadata     TEXT DEFAULT '{}',
    created_at   REAL NOT NULL,
    FOREIGN KEY (from_node) REFERENCES nodes(id) ON DELETE CASCADE,
    FOREIGN KEY (to_node)   REFERENCES nodes(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS agent_sessions (
    id          TEXT PRIMARY KEY,
    agent_type  TEXT NOT NULL,
    started_at  REAL NOT NULL,
    last_active REAL NOT NULL,
    query_count INTEGER DEFAULT 0,
    metadata    TEXT DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS query_log (
    id           TEXT PRIMARY KEY,
    session_id   TEXT,
    raw_query    TEXT NOT NULL,
    resolved     TEXT NOT NULL,
    result_count INTEGER DEFAULT 0,
    latency_ms   REAL DEFAULT 0,
    timestamp    REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS scan_history (
    id         TEXT PRIMARY KEY,
    root_path  TEXT NOT NULL,
    file_count INTEGER DEFAULT 0,
    node_count INTEGER DEFAULT 0,
    edge_count INTEGER DEFAULT 0,
    duration_s REAL DEFAULT 0,
    scanned_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS file_hashes (
    file_path    TEXT PRIMARY KEY,
    content_hash TEXT NOT NULL,
    parsed_at    REAL NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_nodes_name       ON nodes(name);
CREATE INDEX IF NOT EXISTS idx_nodes_type       ON nodes(type);
CREATE INDEX IF NOT EXISTS idx_nodes_file       ON nodes(file);
CREATE INDEX IF NOT EXISTS idx_nodes_language   ON nodes(language);
CREATE INDEX IF NOT EXISTS idx_nodes_quality    ON nodes(quality);
CREATE INDEX IF NOT EXISTS idx_nodes_complexity ON nodes(complexity);
CREATE INDEX IF NOT EXISTS idx_nodes_confidence ON nodes(confidence);

CREATE INDEX IF NOT EXISTS idx_edges_from   ON edges(from_node);
CREATE INDEX IF NOT EXISTS idx_edges_to     ON edges(to_node);
CREATE INDEX IF NOT EXISTS idx_edges_rel    ON edges(relationship);
CREATE INDEX IF NOT EXISTS idx_edges_weight ON edges(weight);
CREATE INDEX IF NOT EXISTS idx_edges_pair   ON edges(from_node, to_node);

CREATE INDEX IF NOT EXISTS idx_qlog_session ON query_log(session_id);
CREATE INDEX IF NOT EXISTS idx_qlog_time    ON query_log(timestamp);
"""


class GraphDatabase:
    def __init__(self, db_path: str = "agentgraph.db"):
        self.db_path = Path(db_path)
        self._local = threading.local()
        self._lock = threading.Lock()
        self._cache: Dict[str, Any] = {}
        self._cache_hits = 0
        self._cache_misses = 0
        self._initialize()

    def _initialize(self):
        with self._get_conn() as conn:
            conn.executescript(SCHEMA)
        self._migrate()

    def _migrate(self):
        """Add new columns to existing DBs without breaking them."""
        conn = self._get_conn()
        node_cols = {row[1] for row in conn.execute("PRAGMA table_info(nodes)").fetchall()}
        edge_cols = {row[1] for row in conn.execute("PRAGMA table_info(edges)").fetchall()}
        migrations = []
        if "confidence" not in node_cols:
            migrations.append("ALTER TABLE nodes ADD COLUMN confidence TEXT DEFAULT 'EXTRACTED'")
        if "provenance" not in node_cols:
            migrations.append("ALTER TABLE nodes ADD COLUMN provenance TEXT DEFAULT 'regex_parser'")
        if "confidence" not in edge_cols:
            migrations.append("ALTER TABLE edges ADD COLUMN confidence REAL DEFAULT 1.0")
        if "provenance" not in edge_cols:
            migrations.append("ALTER TABLE edges ADD COLUMN provenance TEXT DEFAULT 'regex_parser'")
        for sql in migrations:
            try:
                conn.execute(sql)
            except Exception:
                pass

    def _get_conn(self) -> sqlite3.Connection:
        if not hasattr(self._local, "conn") or self._local.conn is None:
            conn = sqlite3.connect(
                str(self.db_path), check_same_thread=False, timeout=30, isolation_level=None,
            )
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=NORMAL")
            conn.execute("PRAGMA cache_size=-64000")
            conn.execute("PRAGMA temp_store=MEMORY")
            conn.execute("PRAGMA foreign_keys=ON")
            self._local.conn = conn
        return self._local.conn

    @contextmanager
    def transaction(self):
        conn = self._get_conn()
        conn.execute("BEGIN")
        try:
            yield conn
            conn.execute("COMMIT")
        except Exception:
            conn.execute("ROLLBACK")
            raise

    # ── Content Hash / Cache ──────────────────────────────────────

    def get_file_hash(self, file_path: str) -> str:
        sha256 = hashlib.sha256()
        try:
            with open(file_path, "rb") as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    sha256.update(chunk)
            return sha256.hexdigest()
        except (OSError, IOError):
            return ""

    def is_file_changed(self, file_path: str) -> bool:
        current = self.get_file_hash(file_path)
        if not current:
            return True
        conn = self._get_conn()
        row = conn.execute(
            "SELECT content_hash FROM file_hashes WHERE file_path=?", (file_path,)
        ).fetchone()
        return row is None or row[0] != current

    def record_file_hash(self, file_path: str):
        h = self.get_file_hash(file_path)
        if not h:
            return
        conn = self._get_conn()
        conn.execute("""
            INSERT INTO file_hashes (file_path, content_hash, parsed_at)
            VALUES (?, ?, ?)
            ON CONFLICT(file_path) DO UPDATE SET
                content_hash=excluded.content_hash, parsed_at=excluded.parsed_at
        """, (file_path, h, time.time()))

    # ── Node Operations ───────────────────────────────────────────

    def upsert_node(
        self, name: str, type: str, file: str, language: str,
        line_start: int = 0, line_end: int = 0,
        complexity: int = 0, quality: float = 100.0,
        signature: str = "", docstring: str = "",
        metadata: Dict = None,
        confidence: str = "EXTRACTED",
        provenance: str = "regex_parser",
    ) -> str:
        node_id = self._node_id(name, file)
        now = time.time()
        conn = self._get_conn()
        conn.execute("""
            INSERT INTO nodes
                (id, name, type, file, language, line_start, line_end,
                 complexity, quality, signature, docstring, metadata,
                 confidence, provenance, created_at, updated_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(id) DO UPDATE SET
                type=excluded.type, line_start=excluded.line_start,
                line_end=excluded.line_end, complexity=excluded.complexity,
                quality=excluded.quality, signature=excluded.signature,
                docstring=excluded.docstring, metadata=excluded.metadata,
                confidence=excluded.confidence, provenance=excluded.provenance,
                updated_at=excluded.updated_at
        """, (
            node_id, name, type, file, language,
            line_start, line_end, complexity, quality,
            signature, docstring, json.dumps(metadata or {}),
            confidence, provenance, now, now
        ))
        self._cache.pop(node_id, None)
        self._cache.pop(f"deps:{node_id}", None)
        self._cache.pop(f"used:{node_id}", None)
        return node_id

    def get_node(self, name: str, file: str = None) -> Optional[Dict]:
        conn = self._get_conn()
        if file:
            node_id = self._node_id(name, file)
            if node_id in self._cache:
                self._cache_hits += 1
                return self._cache[node_id]
            self._cache_misses += 1
            row = conn.execute("SELECT * FROM nodes WHERE id=?", (node_id,)).fetchone()
        else:
            row = conn.execute(
                "SELECT * FROM nodes WHERE name=? ORDER BY updated_at DESC LIMIT 1", (name,)
            ).fetchone()
        if row:
            result = dict(row)
            result["metadata"] = json.loads(result["metadata"])
            if file:
                self._cache[self._node_id(name, file)] = result
            return result
        return None

    def get_nodes_by_type(self, type: str) -> List[Dict]:
        rows = self._get_conn().execute(
            "SELECT * FROM nodes WHERE type=? ORDER BY quality DESC", (type,)
        ).fetchall()
        return [self._row_to_dict(r) for r in rows]

    def get_nodes_by_file(self, file: str) -> List[Dict]:
        rows = self._get_conn().execute(
            "SELECT * FROM nodes WHERE file=? ORDER BY line_start", (file,)
        ).fetchall()
        return [self._row_to_dict(r) for r in rows]

    def search_nodes(self, query: str, limit: int = 20) -> List[Dict]:
        pattern = f"%{query}%"
        rows = self._get_conn().execute("""
            SELECT * FROM nodes
            WHERE name LIKE ? OR file LIKE ? OR signature LIKE ?
            ORDER BY
                CASE WHEN name = ? THEN 0 WHEN name LIKE ? THEN 1 ELSE 2 END,
                quality DESC
            LIMIT ?
        """, (pattern, pattern, pattern, query, f"{query}%", limit)).fetchall()
        return [self._row_to_dict(r) for r in rows]

    def delete_node(self, name: str, file: str) -> bool:
        node_id = self._node_id(name, file)
        conn = self._get_conn()
        conn.execute("DELETE FROM nodes WHERE id=?", (node_id,))
        conn.execute("DELETE FROM edges WHERE from_node=? OR to_node=?", (node_id, node_id))
        self._cache.pop(node_id, None)
        return True

    def rename_node(self, old_name: str, new_name: str, file: str) -> bool:
        old_id = self._node_id(old_name, file)
        new_id = self._node_id(new_name, file)
        conn = self._get_conn()
        conn.execute("PRAGMA foreign_keys=OFF")
        try:
            conn.execute("BEGIN")
            conn.execute("UPDATE nodes SET id=?, name=?, updated_at=? WHERE id=?",
                         (new_id, new_name, time.time(), old_id))
            conn.execute("UPDATE edges SET from_node=? WHERE from_node=?", (new_id, old_id))
            conn.execute("UPDATE edges SET to_node=? WHERE to_node=?", (new_id, old_id))
            conn.execute("COMMIT")
        except Exception:
            conn.execute("ROLLBACK")
            raise
        finally:
            conn.execute("PRAGMA foreign_keys=ON")
        self._cache.pop(old_id, None)
        return True

    def update_node_metrics(self, name: str, file: str,
                            complexity: int = None, quality: float = None) -> bool:
        node_id = self._node_id(name, file)
        updates, params = [], []
        if complexity is not None:
            updates.append("complexity=?"); params.append(complexity)
        if quality is not None:
            updates.append("quality=?"); params.append(quality)
        if not updates:
            return False
        updates.append("updated_at=?"); params.append(time.time())
        params.append(node_id)
        self._get_conn().execute(f"UPDATE nodes SET {', '.join(updates)} WHERE id=?", params)
        self._cache.pop(node_id, None)
        return True

    # ── Edge Operations ───────────────────────────────────────────

    def upsert_edge(
        self, from_name: str, from_file: str, to_name: str, to_file: str,
        relationship: str, weight: float = 1.0, metadata: Dict = None,
        confidence: float = 1.0, provenance: str = "regex_parser",
    ) -> str:
        from_id = self._node_id(from_name, from_file)
        to_id   = self._node_id(to_name, to_file)
        edge_id = self._edge_id(from_id, to_id, relationship)
        conn = self._get_conn()
        conn.execute("""
            INSERT INTO edges (id, from_node, to_node, relationship, weight,
                               confidence, provenance, metadata, created_at)
            VALUES (?,?,?,?,?,?,?,?,?)
            ON CONFLICT(id) DO UPDATE SET
                weight=excluded.weight, confidence=excluded.confidence,
                provenance=excluded.provenance, metadata=excluded.metadata
        """, (edge_id, from_id, to_id, relationship, weight,
              confidence, provenance, json.dumps(metadata or {}), time.time()))
        self._cache.pop(f"deps:{from_id}", None)
        self._cache.pop(f"used:{to_id}", None)
        return edge_id

    def get_dependencies(self, name: str, file: str = None) -> List[Dict]:
        node_id = self._get_node_id_flexible(name, file)
        if not node_id:
            return []
        cache_key = f"deps:{node_id}"
        if cache_key in self._cache:
            self._cache_hits += 1
            return self._cache[cache_key]
        self._cache_misses += 1
        rows = self._get_conn().execute("""
            SELECT n.*, e.relationship, e.weight, e.confidence, e.provenance
            FROM edges e JOIN nodes n ON e.to_node = n.id
            WHERE e.from_node = ? ORDER BY e.weight DESC
        """, (node_id,)).fetchall()
        result = [self._row_to_dict(r) for r in rows]
        self._cache[cache_key] = result
        return result

    def get_dependents(self, name: str, file: str = None) -> List[Dict]:
        node_id = self._get_node_id_flexible(name, file)
        if not node_id:
            return []
        cache_key = f"used:{node_id}"
        if cache_key in self._cache:
            self._cache_hits += 1
            return self._cache[cache_key]
        self._cache_misses += 1
        rows = self._get_conn().execute("""
            SELECT n.*, e.relationship, e.weight, e.confidence, e.provenance
            FROM edges e JOIN nodes n ON e.from_node = n.id
            WHERE e.to_node = ? ORDER BY e.weight DESC
        """, (node_id,)).fetchall()
        result = [self._row_to_dict(r) for r in rows]
        self._cache[cache_key] = result
        return result

    def delete_edge(self, from_name: str, from_file: str,
                    to_name: str, to_file: str, relationship: str = None) -> bool:
        from_id = self._node_id(from_name, from_file)
        to_id   = self._node_id(to_name, to_file)
        conn = self._get_conn()
        if relationship:
            conn.execute("DELETE FROM edges WHERE id=?",
                         (self._edge_id(from_id, to_id, relationship),))
        else:
            conn.execute("DELETE FROM edges WHERE from_node=? AND to_node=?", (from_id, to_id))
        self._cache.pop(f"deps:{from_id}", None)
        self._cache.pop(f"used:{to_id}", None)
        return True

    # ── Graph Analytics ───────────────────────────────────────────

    def find_cycles(self) -> List[List[str]]:
        """Detect circular dependencies. Returns lists of human-readable names."""
        conn = self._get_conn()
        edges = conn.execute("SELECT from_node, to_node FROM edges").fetchall()
        id_to_name = {r[0]: r[1] for r in conn.execute("SELECT id, name FROM nodes").fetchall()}

        graph: Dict[str, List[str]] = {}
        for e in edges:
            graph.setdefault(e[0], []).append(e[1])

        cycles, visited, rec_stack = [], set(), set()

        def dfs(node, path):
            visited.add(node)
            rec_stack.add(node)
            for nb in graph.get(node, []):
                if nb not in visited:
                    dfs(nb, path + [nb])
                elif nb in rec_stack and nb in path:
                    idx = path.index(nb)
                    cycle = [id_to_name.get(n, n) for n in path[idx:]] + [id_to_name.get(nb, nb)]
                    cycles.append(cycle)
            rec_stack.discard(node)

        for node in list(graph.keys()):
            if node not in visited:
                dfs(node, [node])

        # Deduplicate
        seen, unique = set(), []
        for c in cycles:
            key = tuple(sorted(c))
            if key not in seen:
                seen.add(key)
                unique.append(c)
        return unique

    def get_impact(self, name: str, file: str = None, depth: int = 3,
                   min_weight: float = 0.0) -> Dict:
        node_id = self._get_node_id_flexible(name, file)
        if not node_id:
            return {"affected_count": 0, "affected_nodes": [], "risk_level": "LOW"}

        conn = self._get_conn()
        affected, queue, visited = set(), [(node_id, 0)], {node_id}

        while queue:
            current, d = queue.pop(0)
            if d >= depth:
                continue
            for row in conn.execute(
                "SELECT from_node, weight FROM edges WHERE to_node=?", (current,)
            ).fetchall():
                nid, w = row[0], row[1]
                if nid not in visited and w >= min_weight:
                    visited.add(nid)
                    affected.add(nid)
                    queue.append((nid, d + 1))

        nodes = []
        for nid in affected:
            row = conn.execute("SELECT * FROM nodes WHERE id=?", (nid,)).fetchone()
            if row:
                nodes.append(self._row_to_dict(row))

        count = len(nodes)
        return {
            "affected_count": count,
            "affected_nodes": sorted(nodes, key=lambda x: x.get("complexity", 0), reverse=True),
            "risk_level": "CRITICAL" if count > 10 else "HIGH" if count > 5 else "MEDIUM" if count > 2 else "LOW",
        }

    def get_hotspots(self, limit: int = 10) -> List[Dict]:
        rows = self._get_conn().execute("""
            SELECT n.*,
                   COUNT(DISTINCT e_out.id) as out_degree,
                   COUNT(DISTINCT e_in.id)  as in_degree
            FROM nodes n
            LEFT JOIN edges e_out ON e_out.from_node = n.id
            LEFT JOIN edges e_in  ON e_in.to_node    = n.id
            GROUP BY n.id
            ORDER BY (n.complexity * 3) +
                     (COUNT(DISTINCT e_out.id) + COUNT(DISTINCT e_in.id)) +
                     ((100 - n.quality) / 10) DESC
            LIMIT ?
        """, (limit,)).fetchall()
        return [self._row_to_dict(r) for r in rows]

    def find_god_nodes(self, limit: int = 10) -> List[Dict]:
        """Highest-degree nodes — nodes that connect everything."""
        rows = self._get_conn().execute("""
            SELECT n.*,
                   COUNT(DISTINCT e_out.id) + COUNT(DISTINCT e_in.id) as total_degree,
                   COUNT(DISTINCT e_out.id) as out_degree,
                   COUNT(DISTINCT e_in.id)  as in_degree
            FROM nodes n
            LEFT JOIN edges e_out ON e_out.from_node = n.id
            LEFT JOIN edges e_in  ON e_in.to_node    = n.id
            WHERE n.type NOT IN ('dependency', 'module')
            GROUP BY n.id
            ORDER BY total_degree DESC
            LIMIT ?
        """, (limit,)).fetchall()
        return [self._row_to_dict(r) for r in rows]

    def find_surprising_connections(self) -> List[Dict]:
        """Edges between nodes in different top-level directories."""
        rows = self._get_conn().execute("""
            SELECT nf.name as from_name, nf.file as from_file,
                   nt.name as to_name,   nt.file as to_file,
                   e.relationship, e.weight, e.confidence
            FROM edges e
            JOIN nodes nf ON e.from_node = nf.id
            JOIN nodes nt ON e.to_node   = nt.id
            WHERE nf.file != nt.file
              AND e.relationship NOT IN ('imports', 'defines')
            ORDER BY e.weight DESC LIMIT 100
        """).fetchall()

        results, seen = [], set()
        for row in rows:
            r = dict(row)
            from_top = r["from_file"].split("/")[0]
            to_top   = r["to_file"].split("/")[0]
            key = (r["from_name"], r["to_name"])
            if from_top != to_top and key not in seen:
                seen.add(key)
                results.append(r)
        return results[:20]

    def get_orphans(self) -> List[Dict]:
        rows = self._get_conn().execute("""
            SELECT n.* FROM nodes n
            WHERE n.id NOT IN (
                SELECT DISTINCT from_node FROM edges
                UNION SELECT DISTINCT to_node FROM edges
            )
        """).fetchall()
        return [self._row_to_dict(r) for r in rows]

    def get_stats(self) -> Dict:
        conn = self._get_conn()
        node_count = conn.execute("SELECT COUNT(*) FROM nodes").fetchone()[0]
        edge_count = conn.execute("SELECT COUNT(*) FROM edges").fetchone()[0]
        lang_dist  = conn.execute(
            "SELECT language, COUNT(*) FROM nodes GROUP BY language ORDER BY 2 DESC"
        ).fetchall()
        type_dist  = conn.execute(
            "SELECT type, COUNT(*) FROM nodes GROUP BY type ORDER BY 2 DESC"
        ).fetchall()
        avg_q = conn.execute("SELECT AVG(quality) FROM nodes").fetchone()[0] or 0
        avg_c = conn.execute("SELECT AVG(complexity) FROM nodes").fetchone()[0] or 0
        conf_dist = conn.execute(
            "SELECT confidence, COUNT(*) FROM nodes GROUP BY confidence"
        ).fetchall()
        return {
            "nodes": node_count, "edges": edge_count,
            "avg_quality": round(avg_q, 1), "avg_complexity": round(avg_c, 1),
            "languages": {r[0]: r[1] for r in lang_dist},
            "types":     {r[0]: r[1] for r in type_dist},
            "confidence_distribution": {r[0]: r[1] for r in conf_dist},
            "cache_hit_rate": round(
                self._cache_hits / max(1, self._cache_hits + self._cache_misses) * 100, 1
            ),
        }

    def clear_file(self, file: str):
        conn = self._get_conn()
        node_ids = [r[0] for r in conn.execute(
            "SELECT id FROM nodes WHERE file=?", (file,)
        ).fetchall()]
        if node_ids:
            ph = ",".join("?" * len(node_ids))
            conn.execute(f"DELETE FROM edges WHERE from_node IN ({ph}) OR to_node IN ({ph})",
                         node_ids + node_ids)
            conn.execute(f"DELETE FROM nodes WHERE id IN ({ph})", node_ids)
        conn.execute("DELETE FROM file_hashes WHERE file_path=?", (file,))
        for nid in node_ids:
            self._cache.pop(nid, None)
            self._cache.pop(f"deps:{nid}", None)
            self._cache.pop(f"used:{nid}", None)

    def clear_all(self):
        conn = self._get_conn()
        conn.execute("DELETE FROM edges")
        conn.execute("DELETE FROM nodes")
        conn.execute("DELETE FROM file_hashes")
        self._cache.clear()

    def log_scan(self, root_path, file_count, node_count, edge_count, duration_s):
        self._get_conn().execute("""
            INSERT INTO scan_history (id, root_path, file_count, node_count, edge_count, duration_s, scanned_at)
            VALUES (?,?,?,?,?,?,?)
        """, (str(uuid.uuid4()), root_path, file_count, node_count, edge_count, duration_s, time.time()))

    def log_query(self, session_id, raw_query, resolved, result_count, latency_ms):
        self._get_conn().execute("""
            INSERT INTO query_log (id, session_id, raw_query, resolved, result_count, latency_ms, timestamp)
            VALUES (?,?,?,?,?,?,?)
        """, (str(uuid.uuid4()), session_id, raw_query, resolved, result_count, latency_ms, time.time()))

    # ── Helpers ───────────────────────────────────────────────────

    def _node_id(self, name: str, file: str) -> str:
        return f"{file}::{name}".lower().replace(" ", "_")

    def _edge_id(self, from_id: str, to_id: str, rel: str) -> str:
        return f"{from_id}--{rel}--{to_id}"

    def _get_node_id_flexible(self, name: str, file: str = None) -> Optional[str]:
        if file:
            return self._node_id(name, file)
        row = self._get_conn().execute(
            "SELECT id FROM nodes WHERE name=? ORDER BY updated_at DESC LIMIT 1", (name,)
        ).fetchone()
        return row[0] if row else None

    def _row_to_dict(self, row) -> Dict:
        d = dict(row)
        if "metadata" in d and isinstance(d["metadata"], str):
            d["metadata"] = json.loads(d["metadata"])
        return d

    def invalidate_cache(self):
        self._cache.clear()

    def close(self):
        if hasattr(self._local, "conn") and self._local.conn:
            self._local.conn.close()
            self._local.conn = None