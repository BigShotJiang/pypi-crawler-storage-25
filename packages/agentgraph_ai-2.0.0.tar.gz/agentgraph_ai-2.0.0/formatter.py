"""
AgentGraph Intelligence - Agent Output Formatter
Produces agent-optimized output for every supported AI agent.
"""

from typing import Dict, Any, List, Optional
import json
import re


# ── Write-Back Command Parser ─────────────────────────────────────────────────

WRITEBACK_PATTERNS = [
    (re.compile(r'GRAPH_UPDATE::RENAME::(.+?)->(.+?)(?:\s|$)'),          "rename"),
    (re.compile(r'GRAPH_UPDATE::ADD_NODE::(\w+)\[([^\]]+)\]'),           "add_node"),
    (re.compile(r'GRAPH_UPDATE::DELETE_NODE::(\w+)'),                    "delete_node"),
    (re.compile(r'GRAPH_UPDATE::ADD_EDGE::(.+?)->(.+?)\[([^\]]+)\]'),    "add_edge"),
    (re.compile(r'GRAPH_UPDATE::DELETE_EDGE::(.+?)->(.+?)(?:\s|$)'),     "delete_edge"),
    (re.compile(r'GRAPH_UPDATE::UPDATE_METRIC::(\w+)\[([^\]]+)\]'),      "update_metric"),
    (re.compile(r'GRAPH_UPDATE::MOVE::(\w+)->(.+?)(?:\s|$)'),            "move_node"),
    (re.compile(r'GRAPH_UPDATE::ADD_RELATIONSHIP::(.+?)->(.+?)\[(\w+)\]'), "add_rel"),
]


def parse_writeback_commands(text: str) -> List[Dict]:
    commands = []
    for pattern, cmd_type in WRITEBACK_PATTERNS:
        for m in pattern.finditer(text):
            cmd = {"type": cmd_type, "raw": m.group(0)}
            groups = list(m.groups())

            if cmd_type == "rename":
                cmd.update({"old_name": groups[0].strip(), "new_name": groups[1].strip()})

            elif cmd_type == "add_node":
                parts = {k: v for k, v in
                         (p.split(":") for p in groups[1].split("|") if ":" in p)}
                cmd.update({
                    "name": groups[0], "type": parts.get("type", "function"),
                    "file": parts.get("file", "unknown"), "language": parts.get("lang", "unknown"),
                })

            elif cmd_type == "delete_node":
                cmd.update({"name": groups[0]})

            elif cmd_type in ("add_edge", "add_rel"):
                parts = {k: v for k, v in
                         (p.split(":") for p in groups[2].split("|") if ":" in p)} \
                    if "|" in groups[2] else {}
                cmd.update({
                    "from_name": groups[0].strip(), "to_name": groups[1].strip(),
                    "relationship": parts.get("rel", groups[2].strip()),
                    "weight": float(parts.get("w", 5.0)),
                })

            elif cmd_type == "delete_edge":
                cmd.update({"from_name": groups[0].strip(), "to_name": groups[1].strip()})

            elif cmd_type == "update_metric":
                parts = {k: v for k, v in
                         (p.split(":") for p in groups[1].split("|") if ":" in p)}
                cmd.update({
                    "name": groups[0],
                    "complexity": int(parts["complexity"]) if "complexity" in parts else None,
                    "quality":    float(parts["quality"])  if "quality"    in parts else None,
                })

            elif cmd_type == "move_node":
                cmd.update({"name": groups[0], "new_file": groups[1].strip()})

            commands.append(cmd)
    return commands


def apply_writeback_commands(db, commands: List[Dict]) -> List[Dict]:
    results = []
    for cmd in commands:
        try:
            t = cmd["type"]
            if t == "rename":
                node = db.get_node(cmd["old_name"])
                if node:
                    db.rename_node(cmd["old_name"], cmd["new_name"], node["file"])
                    results.append({"cmd": cmd["raw"], "status": "ok"})
                else:
                    results.append({"cmd": cmd["raw"], "status": "error", "reason": "node not found"})

            elif t == "add_node":
                db.upsert_node(name=cmd["name"], type=cmd["type"],
                               file=cmd["file"], language=cmd["language"])
                results.append({"cmd": cmd["raw"], "status": "ok"})

            elif t == "delete_node":
                node = db.get_node(cmd["name"])
                if node:
                    db.delete_node(cmd["name"], node["file"])
                    results.append({"cmd": cmd["raw"], "status": "ok"})
                else:
                    results.append({"cmd": cmd["raw"], "status": "error", "reason": "node not found"})

            elif t in ("add_edge", "add_rel"):
                fn = db.get_node(cmd["from_name"])
                tn = db.get_node(cmd["to_name"])
                if fn and tn:
                    db.upsert_edge(from_name=cmd["from_name"], from_file=fn["file"],
                                   to_name=cmd["to_name"], to_file=tn["file"],
                                   relationship=cmd["relationship"], weight=cmd.get("weight", 5.0))
                    results.append({"cmd": cmd["raw"], "status": "ok"})
                else:
                    results.append({"cmd": cmd["raw"], "status": "error", "reason": "node(s) not found"})

            elif t == "delete_edge":
                fn = db.get_node(cmd["from_name"])
                tn = db.get_node(cmd["to_name"])
                if fn and tn:
                    db.delete_edge(cmd["from_name"], fn["file"], cmd["to_name"], tn["file"])
                    results.append({"cmd": cmd["raw"], "status": "ok"})
                else:
                    results.append({"cmd": cmd["raw"], "status": "error", "reason": "node(s) not found"})

            elif t == "update_metric":
                node = db.get_node(cmd["name"])
                if node:
                    db.update_node_metrics(cmd["name"], node["file"],
                                           complexity=cmd.get("complexity"),
                                           quality=cmd.get("quality"))
                    results.append({"cmd": cmd["raw"], "status": "ok"})
                else:
                    results.append({"cmd": cmd["raw"], "status": "error", "reason": "node not found"})

        except Exception as e:
            results.append({"cmd": cmd.get("raw", "?"), "status": "error", "reason": str(e)})

    return results


# ── Risk / Quality Helpers ────────────────────────────────────────────────────

def _risk_level(node: Dict) -> str:
    cx = node.get("complexity", 0)
    q  = node.get("quality", 100)
    if cx >= 10 or q < 50: return "CRITICAL"
    if cx >= 7  or q < 70: return "HIGH"
    if cx >= 5  or q < 85: return "MEDIUM"
    return "LOW"


def _confidence_tag(node: Dict) -> str:
    return node.get("confidence", "EXTRACTED")


def _node_tag(node: Dict, extended: bool = False) -> str:
    risk  = _risk_level(node)
    conf  = _confidence_tag(node)
    prov  = node.get("provenance", "")
    base  = (
        f"NODE::{node['name']}"
        f"[{node['type']}|{node['file']}"
        f"|risk:{risk}|cx:{node.get('complexity',0)}|q:{node.get('quality',100):.0f}%"
        f"|conf:{conf}]"
    )
    if prov:
        base += f"\nPROV::{prov}"
    if extended and node.get("signature"):
        base += f"\nSIG::{node['signature'][:120]}"
    return base


# ── Claude Format ─────────────────────────────────────────────────────────────

def format_for_claude(result: Dict) -> str:
    lines   = []
    intent  = result.get("intent", "")
    message = result.get("message", "")
    items   = result.get("items", [])
    focus   = result.get("focus")

    lines.append("# SUMMARY")
    lines.append(message)

    if focus:
        lines.append("\n# FOCUS NODE")
        lines.append(_node_tag(focus, extended=True))
        if focus.get("docstring"):
            lines.append(f"DOC::{focus['docstring'][:200]}")

    if intent == "dependencies" and items:
        lines.append(f"\n# DEPENDENCIES ({len(items)})")
        for dep in items[:20]:
            conf = dep.get("confidence", 1.0)
            prov = dep.get("provenance", "")
            lines.append(
                f"DEPS::{dep['name']}[{dep.get('type','?')}|w:{dep.get('weight',1):.0f}"
                f"|{dep.get('relationship','')}|conf:{conf:.2f}|via:{prov}]"
            )

    elif intent == "dependents" and items:
        lines.append(f"\n# USED BY ({len(items)})")
        for dep in items[:20]:
            lines.append(f"USED_BY::{dep['name']}[{dep.get('type','?')}|w:{dep.get('weight',1):.0f}]")

    elif intent == "impact":
        risk = result.get("risk_level", "UNKNOWN")
        lines.append(f"\n# BLAST RADIUS  RISK:{risk}")
        for item in items[:15]:
            lines.append(f"AFFECTED::{item['name']}[{item.get('type','?')}|{item.get('file','')}]")

    elif intent == "cycles":
        if isinstance(items, list) and items and isinstance(items[0], list):
            lines.append("\n# CIRCULAR DEPENDENCIES")
            for cycle in items[:10]:
                lines.append(f"CYCLE::{'->'.join(cycle)}")
        else:
            lines.append("\n# NO CYCLES DETECTED")

    elif intent == "god_nodes" and items:
        lines.append(f"\n# GOD NODES ({len(items)})")
        for n in items[:10]:
            deg = n.get("degree") or n.get("total_degree", "?")
            lines.append(f"GOD_NODE::{n['name']}[{n.get('type','?')}|degree:{deg}|cx:{n.get('complexity',0)}|q:{n.get('quality',100):.0f}%]")

    elif intent == "communities" and items:
        lines.append(f"\n# COMMUNITIES ({len(items)})")
        for comm in items[:15]:
            lines.append(f"COMMUNITY::{comm['community_id']}[size:{comm['size']}|top:{','.join(comm['members'][:3])}]")

    elif intent == "surprising" and items:
        lines.append(f"\n# SURPRISING CONNECTIONS ({len(items)})")
        for e in items[:10]:
            from_n = e.get('from') or e.get('from_name', '?')
            to_n   = e.get('to')   or e.get('to_name', '?')
            lines.append(f"SURPRISE::{from_n}->{to_n}[{e.get('relationship','?')}|w:{e.get('weight',1)}]")

    elif items:
        lines.append(f"\n# RESULTS ({len(items)})")
        for item in items[:20]:
            if isinstance(item, dict) and "name" in item:
                lines.append(_node_tag(item))

    if "stats" in result:
        stats = result["stats"]
        lines.append("\n# CODEBASE STATS")
        lines.append(
            f"STATS::nodes:{stats['nodes']}|edges:{stats['edges']}"
            f"|avg_quality:{stats['avg_quality']}%|avg_complexity:{stats['avg_complexity']}"
        )
        conf_dist = stats.get("confidence_distribution", {})
        if conf_dist:
            conf_str = "|".join(f"{k}:{v}" for k, v in conf_dist.items())
            lines.append(f"CONFIDENCE::{conf_str}")
        if stats.get("languages"):
            lang_str = "|".join(f"{k}:{v}" for k, v in list(stats["languages"].items())[:5])
            lines.append(f"LANGS::{lang_str}")

    lines.append(f"\nLATENCY::{result.get('latency_ms', 0):.2f}ms")
    return "\n".join(lines)


# ── Universal Format ──────────────────────────────────────────────────────────

def format_universal(result: Dict) -> str:
    """Compressed format for Codex, Copilot, Cursor, etc. Text risk levels, no emojis."""
    lines  = []
    intent = result.get("intent", "")
    items  = result.get("items", [])
    focus  = result.get("focus")

    lines.append(f"AGRAPH::v1|intent:{intent}|q:{result.get('query','')[:60]}")

    if focus:
        risk = _risk_level(focus)
        conf = _confidence_tag(focus)
        lines.append(
            f"FOCUS::{focus['name']}[{focus['type']}|{focus['file']}"
            f":{focus.get('line_start',0)}-{focus.get('line_end',0)}"
            f"|cx:{focus.get('complexity',0)}|q:{focus.get('quality',100):.0f}"
            f"|risk:{risk}|conf:{conf}]"
        )

    if intent == "dependencies":
        deps_str = ",".join(
            f"{d['name']}[{d.get('relationship','')}:w{d.get('weight',1):.0f}:conf{d.get('confidence',1):.1f}]"
            for d in items[:20]
        )
        lines.append(f"DEPS::{deps_str}" if deps_str else "DEPS::none")

    elif intent == "dependents":
        used_str = ",".join(f"{d['name']}[w{d.get('weight',1):.0f}]" for d in items[:20])
        lines.append(f"USED_BY::{used_str}" if used_str else "USED_BY::none")

    elif intent == "impact":
        risk = result.get("risk_level", "UNKNOWN")
        lines.append(f"IMPACT::risk:{risk}|count:{len(items)}")
        aff_str = ",".join(d["name"] for d in items[:15])
        if aff_str:
            lines.append(f"AFFECTED::{aff_str}")

    elif intent == "cycles":
        if isinstance(items, list) and items and isinstance(items[0], list):
            for cycle in items[:5]:
                lines.append(f"CYCLE::{'->'.join(cycle)}")
        else:
            lines.append("CYCLES::none")

    elif intent == "god_nodes":
        gn_str = ",".join(
            f"{n['name']}[deg:{n.get('degree') or n.get('total_degree','?')}]"
            for n in items[:10]
        )
        lines.append(f"GOD_NODES::{gn_str}")

    elif intent == "communities":
        c_str = ",".join(f"c{c['community_id']}:size{c['size']}" for c in items[:10])
        lines.append(f"COMMUNITIES::{c_str}")

    elif intent == "surprising":
        s_str = ",".join(
            f"{e.get('from') or e.get('from_name','?')}->{e.get('to') or e.get('to_name','?')}"
            for e in items[:10]
        )
        lines.append(f"SURPRISING::{s_str}")

    elif intent == "stats":
        stats = result.get("stats", {})
        lines.append(
            f"STATS::n:{stats.get('nodes',0)}|e:{stats.get('edges',0)}"
            f"|avgq:{stats.get('avg_quality',0)}|avgcx:{stats.get('avg_complexity',0)}"
        )

    elif items:
        node_strs = []
        for item in items[:20]:
            if isinstance(item, dict) and "name" in item:
                risk = _risk_level(item)
                conf = _confidence_tag(item)
                node_strs.append(
                    f"{item['name']}[{item.get('type','?')}|cx:{item.get('complexity',0)}"
                    f"|q:{item.get('quality',100):.0f}|risk:{risk}|conf:{conf}]"
                )
        if node_strs:
            lines.append(f"NODES::{','.join(node_strs)}")

    lines.append(f"META::count:{result.get('count', len(items))}|ms:{result.get('latency_ms',0):.1f}")
    return "\n".join(lines)


def format_json(result: Dict) -> Dict:
    return {
        "query":      result.get("query"),
        "intent":     result.get("intent"),
        "entity":     result.get("entity"),
        "message":    result.get("message"),
        "count":      result.get("count", len(result.get("items", []))),
        "latency_ms": result.get("latency_ms"),
        "focus":      result.get("focus"),
        "items":      result.get("items", []),
        "stats":      result.get("stats"),
        "risk_level": result.get("risk_level"),
    }


def format_for_agent(agent_type: str, result: Dict) -> Any:
    agent_lower = agent_type.lower()
    if "claude" in agent_lower:
        return format_for_claude(result)
    if agent_lower in ("json", "api", "sdk", "raw"):
        return format_json(result)
    return format_universal(result)


AGENT_SIGNATURES = {
    "claude":  ["anthropic", "claude", "claude-code", "claude-sonnet", "claude-opus"],
    "codex":   ["openai", "codex", "gpt-4", "gpt-3", "chatgpt"],
    "copilot": ["copilot", "github-copilot"],
    "cursor":  ["cursor"],
    "codeium": ["codeium"],
    "gemini":  ["gemini", "google", "bard"],
}


def detect_agent_type(user_agent: str = "", api_key_prefix: str = "") -> str:
    text = (user_agent + " " + api_key_prefix).lower()
    for agent, sigs in AGENT_SIGNATURES.items():
        if any(s in text for s in sigs):
            return agent
    return "universal"