"""CalcEngine ABC and the registry."""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Dict

from sheetwright.model.cell import CellValue
from sheetwright.security import SecurityLimits

CalcResult = Dict[str, Dict[str, CellValue]]


class CalcEngine(ABC):
    """Abstract calc engine: evaluate a built .xlsx and return values."""

    @abstractmethod
    def evaluate(
        self, xlsx_path: Path, *, limits: SecurityLimits
    ) -> CalcResult:
        """Return calculated values keyed by sheet, then by A1 address."""
