import tempfile
from contextlib import contextmanager
from pathlib import Path

from testsweet import test

from sheetwright.diff.check import (
    check_workbook,
)
from sheetwright.model.cell import Cell
from sheetwright.model.workbook import NamedRange, Sheet, Workbook
from sheetwright.project import Project


@contextmanager
def _tmp_path():
    with tempfile.TemporaryDirectory() as td:
        yield Path(td)


def _project(tmp_path: Path, sheets: list[str]) -> Project:
    p = tmp_path / 'proj'
    p.mkdir(exist_ok=True)
    (p / 'sheetwright.toml').write_text(
        '[project]\nname = "x"\n[build]\ncalc_engine = "libreoffice"\n'
    )
    sheets_toml = '\n'.join(f'    "{s}",' for s in sheets)
    (p / 'workbook.toml').write_text(
        f'[workbook]\nname = "x"\nsheets = [\n{sheets_toml}\n]\n'
    )
    (p / 'sheets').mkdir(exist_ok=True)
    (p / 'data').mkdir(exist_ok=True)
    return Project.open(p)


@test
def clean_workbook_has_no_issues():
    with _tmp_path() as tmp_path:
        # workbook.toml stores DISPLAY NAMES; the source reader/writer
        # reconstruct stems via slugify+index. Mirror that here.
        project = _project(tmp_path, ['Inputs'])
        (project.sheets_dir / '01_inputs.md').write_text(
            '| (cell) | A |\n| --- | --- |\n'
        )
        wb = Workbook(name='x', sheets=[Sheet(name='Inputs')])
        issues = check_workbook(wb, project)
        assert issues == []


@test
def clean_after_real_import_has_no_issues():
    """Regression: after `sheetwright import`, check_workbook
    must not false-positive on the manifest/stem mismatch.

    `sheetwright import` writes display names to workbook.toml and
    files at `<NN>_<slug(name)>.md`. check_workbook should reconcile.
    """
    from click.testing import CliRunner

    from sheetwright.cli import main
    from tests.fixtures.workbooks import write_simple_xlsx

    with _tmp_path() as tmp_path:
        src = tmp_path / 'in.xlsx'
        write_simple_xlsx(src)
        p = tmp_path / 'proj'
        p.mkdir()
        (p / 'sheetwright.toml').write_text(
            '[project]\nname = "in"\n[build]\ncalc_engine = "libreoffice"\n'
        )
        (p / 'workbook.toml').write_text(
            '[workbook]\nname = "in"\nsheets = []\n'
        )
        (p / 'sheets').mkdir()
        (p / 'data').mkdir()
        CliRunner().invoke(main, ['import', str(src), '--project', str(p)])

        project = Project.open(p)
        from sheetwright.source.reader import read_source

        wb = read_source(project.root)
        issues = check_workbook(wb, project)
        kinds = {i.kind for i in issues}
        assert 'manifest_sheet_missing' not in kinds
        assert 'sheet_file_missing_from_manifest' not in kinds


@test
def dangling_sheet_ref_reported():
    with _tmp_path() as tmp_path:
        project = _project(tmp_path, [])
        wb = Workbook(name='x', sheets=[Sheet(name='Inputs')])
        wb.sheet('Inputs').set('A1', Cell(formula='=Outputs!B1'))
        issues = check_workbook(wb, project)
        kinds = {i.kind for i in issues}
        assert 'dangling_sheet_ref' in kinds


@test
def dangling_named_range_reported():
    with _tmp_path() as tmp_path:
        project = _project(tmp_path, [])
        wb = Workbook(name='x', sheets=[Sheet(name='S')])
        wb.sheet('S').set('A1', Cell(formula='=growth_rate*2'))
        issues = check_workbook(wb, project)
        kinds = {i.kind for i in issues}
        assert 'dangling_named_range' in kinds


@test
def named_reference_resolved_when_defined():
    with _tmp_path() as tmp_path:
        project = _project(tmp_path, [])
        wb = Workbook(name='x', sheets=[Sheet(name='S')])
        wb.sheet('S').set('A1', Cell(formula='=growth_rate*2'))
        wb.named_ranges.append(NamedRange(name='growth_rate', ref='S!$B$1'))
        issues = check_workbook(wb, project)
        kinds = {i.kind for i in issues}
        assert 'dangling_named_range' not in kinds


@test
def manifest_sheet_missing():
    with _tmp_path() as tmp_path:
        # Manifest lists 'Missing' (display name); expected stem is
        # '01_missing'. No file exists → manifest_sheet_missing fires.
        project = _project(tmp_path, ['Missing'])
        wb = Workbook(name='x', sheets=[Sheet(name='Inputs')])
        issues = check_workbook(wb, project)
        kinds = {i.kind for i in issues}
        assert 'manifest_sheet_missing' in kinds


@test
def sheet_file_missing_from_manifest():
    with _tmp_path() as tmp_path:
        project = _project(tmp_path, [])
        (project.sheets_dir / '01_orphan.md').write_text(
            '| (cell) | A |\n| --- | --- |\n'
        )
        wb = Workbook(name='x', sheets=[Sheet(name='Orphan')])
        issues = check_workbook(wb, project)
        kinds = {i.kind for i in issues}
        assert 'sheet_file_missing_from_manifest' in kinds
