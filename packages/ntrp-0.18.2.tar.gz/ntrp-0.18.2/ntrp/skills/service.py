from pathlib import Path

from ntrp.settings import NTRP_DIR
from ntrp.skills.installer import install_from_github
from ntrp.skills.registry import SkillMeta, SkillRegistry

BUILTIN_SKILLS_DIR = Path(__file__).resolve().parent.parent.parent / "skills"


def get_skills_dirs() -> list[tuple[Path, str]]:
    return [
        (BUILTIN_SKILLS_DIR, "builtin"),
        (Path.cwd() / ".skills", "project"),
        (NTRP_DIR / "skills", "global"),
    ]


class SkillService:
    def __init__(self, registry: SkillRegistry):
        self._registry = registry

    def list_all(self) -> list[SkillMeta]:
        return self._registry.list_all()

    def get(self, name: str) -> SkillMeta | None:
        return self._registry.get(name)

    async def install(self, source: str) -> SkillMeta | None:
        target_dir = NTRP_DIR / "skills"
        name = await install_from_github(source, target_dir)
        self._registry.reload(get_skills_dirs())
        return self._registry.get(name)

    def remove(self, name: str) -> bool:
        return self._registry.remove(name)
