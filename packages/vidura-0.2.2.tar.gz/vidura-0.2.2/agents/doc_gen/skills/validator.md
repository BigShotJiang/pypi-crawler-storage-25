---
name: validator
type: rules
description: Validates documentation against the API delta using declarative rules
---

## Rules

- id: required_header
  severity: error
  check: contains
  pattern: "# Feature: {feature}"
  message: "Missing required header: # Feature: {feature}"

- id: no_speculation
  severity: error
  check: regex_absent
  patterns:
    - "(?:may|might|could)\\s+(?:want to|consider|think about)"
    - "in\\s+the\\s+(?:near\\s+)?future"
    - "it\\s+is\\s+(?:recommended|suggested)\\s+that\\s+you"
    - "you\\s+(?:should|might want to|could)\\s+(?:also|consider)"
    - "note:\\s+this\\s+is\\s+not\\s+yet\\s+implemented"
  message: "Speculative language detected: {match}"

- id: no_invented_endpoints
  severity: error
  check: endpoints_in_delta
  message: "Invented endpoint not in structured data"

- id: coverage
  severity: warning
  check: delta_coverage
  message: "New endpoint not mentioned in docs"

- id: valid_http_methods
  severity: error
  check: http_methods
  allowed:
    - GET
    - POST
    - PUT
    - PATCH
    - DELETE
    - HEAD
    - OPTIONS
  message: "Invalid HTTP method in documentation"
