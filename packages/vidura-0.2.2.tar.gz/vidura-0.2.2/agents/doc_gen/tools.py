"""Doc-gen agent tool handler — API extraction, validation, writing, critique, evaluation."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from agents.doc_gen.document import DocumentGenerator, DocumentMetadata
from agents.doc_gen.extractor import extract_api_delta
from agents.doc_gen.validator_engine import ValidatorEngine
from core.config import AgentConfig
from core.extractor.types import ChangedFile, ExtractedApiDelta
from core.logger import logger
from core.memory import MemoryManager
from core.skill_loader import load_skill
from core.skill_runner import SkillRunner
from core.tools.executor import ToolResult

import re
# ─── Tool definitions exposed to the LLM ─────────────────────────────────────

TOOL_DEFINITIONS: list[dict] = [
    {
    "name": "extract_api_changes",
    "description": (
        "Extract structured API changes from the changed files. "
        "Automatically detects the framework (django, fastapi, flask) from file contents. "
        "Call this once — it runs all extractors and returns combined results."
    ),
    "input_schema": {
        "type": "object",
        "properties": {},
        "required": [],
    },
},
    {
        "name": "validate_documentation",
        "description": (
            "Validate the stored draft against the extracted API delta. "
            "Returns valid (boolean), errors[], and warnings[]. "
            "Fix all errors before calling write_documentation. "
            "Requires store_draft to be called first."
        ),
        "input_schema": {
            "type": "object",
            "properties": {},
            "required": [],
        },
    },
    {
        "name": "write_documentation",
        "description": (
            "Write the stored draft to disk as both .md and .docx files. "
            "This is a TERMINAL action — the agent loop exits after this call. "
            "Only call after validate_documentation returns valid=true with no errors. "
            "Requires store_draft to be called first."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "featureName": {
                    "type": "string",
                    "description": (
                        'The feature name used for the output filename (e.g. "user-auth", "payment-api")'
                    ),
                },
            },
            "required": ["featureName"],
        },
    },
    {
        "name": "critique_documentation",
        "description": (
            "Submit the stored draft for critic review by a separate LLM instance. "
            "Returns scores (1-10) for completeness, clarity, accuracy, structure, and tone, "
            "plus actionable suggestions. Requires store_draft to be called first."
        ),
        "input_schema": {
            "type": "object",
            "properties": {},
            "required": [],
        },
    },
    {
        "name": "evaluate_quality",
        "description": (
            "Evaluate the quality of the stored draft using LLM-based scoring. "
            "Returns a quality score and dimension-level scores for target audience fit, "
            "completeness, code examples, and consistency. Requires store_draft to be called first."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "compareWithExisting": {
                    "type": "boolean",
                    "description": "Whether to compare against existing docs in the output dir for style consistency",
                },
            },
            "required": [],
        },
    },
]

_HANDLED_TOOLS = {t["name"] for t in TOOL_DEFINITIONS}


# ─── Tool handler ─────────────────────────────────────────────────────────────


class ToolHandler:
    """Handles doc-gen specific tools: extraction, validation, writing, critique, evaluation."""

    def __init__(
        self,
        repo_path: str,
        config: AgentConfig,
        branch: str,
        memory: MemoryManager,
        secondary_providers: dict[str, Any],
        skills_dir: Path,
        executor: Any,
    ) -> None:
        self.repo_path = repo_path
        self.config = config
        self.branch = branch
        self._memory = memory
        self._secondary_providers = secondary_providers
        self._skills_dir = skills_dir
        self._executor = executor

        self._merged_delta: ExtractedApiDelta | None = None
        self._doc_gen = DocumentGenerator()
        self._validator = ValidatorEngine()
        self._last_quality_score: float | None = None
        self._last_critique_result: dict | None = None
        self._last_validation_errors: list[str] = []
        self._steps_log: list[str] = []

            
        self._validate_calls = 0
        self._critique_calls = 0
        self._evaluate_calls = 0

    def can_handle(self, tool_name: str) -> bool:
        return tool_name in _HANDLED_TOOLS

    async def handle(self, tool_name: str, tool_input: dict[str, Any]) -> ToolResult:
        handlers = {
            "extract_api_changes": lambda: self._extract_api_changes(
                # tool_input.get("framework", "fastapi"),
            ),
            "validate_documentation": lambda: self._validate_documentation(),
            "critique_documentation": lambda: self._critique_documentation(),
            "evaluate_quality": lambda: self._evaluate_quality(
                tool_input.get("compareWithExisting", False),
            ),
        }

        if tool_name == "write_documentation":
            return await self._write_documentation(tool_input.get("featureName", ""))

        handler = handlers.get(tool_name)
        if handler:
            return handler()

        return ToolResult(
            content=json.dumps({"error": f"Unknown doc-gen tool: {tool_name}"}),
            is_terminal=False,
        )

    # ─── Tool implementations ─────────────────────────────────────────────────

    def _extract_api_changes(self, framework: str = "") -> ToolResult:
        changed_files = getattr(self._executor, "_changed_files", [])
        if not changed_files:
            return ToolResult(
                content=json.dumps({"error": "No changed files available. Call get_changed_files first."}),
                is_terminal=False,
            )

        from agents.doc_gen.git_helpers import filter_api_files
        api_files = filter_api_files(changed_files)

        # Always run ALL extractors — never trust the LLM's framework guess.
        # Each extractor's detect() method checks file content to self-select.
        all_frameworks = ["django", "fastapi", "flask"]
        combined: dict = {"new": [], "modified": [], "removed": [],
                        "contract_changes": [], "auth_changes": [], "versioning_changes": []}

        for fw in all_frameworks:
            delta = extract_api_delta(
                api_files,
                self.branch,
                self.branch,
                self.config.base_branch,
                [fw],
            )
            combined["new"].extend(delta.new)
            combined["modified"].extend(delta.modified)
            combined["removed"].extend(delta.removed)
            combined["contract_changes"].extend(delta.contract_changes)
            combined["auth_changes"].extend(delta.auth_changes)
            combined["versioning_changes"].extend(delta.versioning_changes)
            logger.debug(
                f"[{fw}] new: {len(delta.new)}, modified: {len(delta.modified)}, removed: {len(delta.removed)}"
            )

        # Merge into the session-level delta
        if self._merged_delta is None:
            self._merged_delta = extract_api_delta(
                api_files, self.branch, self.branch, self.config.base_branch, all_frameworks
            )
        else:
            self._merged_delta.new.extend(combined["new"])
            self._merged_delta.modified.extend(combined["modified"])
            self._merged_delta.removed.extend(combined["removed"])
            self._merged_delta.contract_changes.extend(combined["contract_changes"])
            self._merged_delta.auth_changes.extend(combined["auth_changes"])
            self._merged_delta.versioning_changes.extend(combined["versioning_changes"])

            # Log after merge regardless of which branch ran
        self._steps_log.append(
            f"extract_api_changes — "
            f"{len(self._merged_delta.new)} new, "
            f"{len(self._merged_delta.modified)} modified, "
            f"{len(self._merged_delta.removed)} removed endpoints"
        )

        return ToolResult(
            content=json.dumps(_delta_to_dict(self._merged_delta)),
            is_terminal=False,
        )

    def _validate_documentation(self) -> ToolResult:
        draft = self._executor._current_draft

        if not draft:
            return ToolResult(
                content=json.dumps({
                    "valid": False,
                    "errors": ["No draft available. Call store_draft first."],
                    "warnings": [],
                }),
                is_terminal=False,
            )

        if not self._merged_delta:
            return ToolResult(
                content=json.dumps({
                    "valid": False,
                    "errors": ["No API delta available. Call extract_api_changes first."],
                    "warnings": [],
                }),
                is_terminal=False,
            )

        # 🚨 Enforce critique + evaluate BEFORE validation
        if self._critique_calls == 0:
            return ToolResult(
                content=json.dumps({
                    "valid": False,
                    "errors": ["You must call critique_documentation before validate_documentation."],
                    "warnings": [],
                }),
                is_terminal=False,
            )

        if self._evaluate_calls == 0:
            return ToolResult(
                content=json.dumps({
                    "valid": False,
                    "errors": ["You must call evaluate_quality before validate_documentation."],
                    "warnings": [],
                }),
                is_terminal=False,
            )

        # 🚨 Hard cap: max 2 validations
        if self._validate_calls >= 2:
            return ToolResult(
                content=json.dumps({
                    "valid": False,
                    "errors": [
                        "validate_documentation hard cap exceeded (max 2). "
                        "Do NOT validate again. Add Known Limitations and call write_documentation immediately."
                    ],
                    "warnings": [],
                }),
                is_terminal=False,
            )

        self._validate_calls += 1

        # Load validator
        validator_path = self._skills_dir / "validator.md"
        if not validator_path.exists():
            return ToolResult(
                content=json.dumps({
                    "valid": True,
                    "errors": [],
                    "warnings": ["No validator.md skill found — skipping validation."],
                }),
                is_terminal=False,
            )

        skill = load_skill(validator_path)
        result = self._validator.validate(draft, self._merged_delta, skill)

        message = (
            "Documentation is valid. Call write_documentation now."
            if result.valid
            else (
                f"Validation failed with {len(result.errors)} error(s). "
                "Fix ONLY these errors. Do NOT re-explore. Then call write_documentation."
            )
        )
        self._last_validation_errors = result.errors
        self._steps_log.append(
            f"validate_documentation — "
            f"{'passed' if result.valid else f'failed: {len(result.errors)} error(s): {result.errors[:2]}'}"
        )
        return ToolResult(
            content=json.dumps({
                "valid": result.valid,
                "errors": result.errors,
                "warnings": result.warnings,
                "validateCallsUsed": self._validate_calls,
                "validateCallsRemaining": max(0, 2 - self._validate_calls),
                "message": message,
            }),
            is_terminal=False,
        )

    async def _write_documentation(self, feature_name: str) -> ToolResult:
        draft = self._executor._current_draft
        if not draft:
            return ToolResult(
                content=json.dumps({
                    "success": False,
                    "error": "No draft available. Call store_draft before writing.",
                }),
                is_terminal=True,
                terminal_status="GENERATED",
            )

        if not self._merged_delta:
            return ToolResult(
                content=json.dumps({
                    "success": False,
                    "error": "No API delta available. Call extract_api_changes before writing.",
                }),
                is_terminal=True,
                terminal_status="GENERATED",
            )

        output_dir = str(Path(self.repo_path) / self.config.output_dir)

        # Read doc-specific config from extra fields
        extra = getattr(self.config, "extra", {}) or {}
        doc_title_template = extra.get("doc_title_template", "{feature} - API Documentation")

        # Gather git metadata for the metadata block in the DOCX
        git_meta = self._executor._git.get_commit_metadata(self.config.base_branch)
        changed_files = getattr(self._executor, "_changed_files", [])
        doc_changed_files = [
            f"{f.path} ({f.status.lower()})"
            for f in changed_files
            if not (
                f.path.startswith("skills/")
                or f.path.startswith(".agent/")
                or f.path.startswith(".git")
                or f.path == ".gitignore"
            )
        ]

        metadata = DocumentMetadata(
            feature_name=feature_name,
            version=git_meta.get("version", ""),
            repo_name=self.config.repo_name or git_meta["repo_name"],
            project_name=self.config.project_name or git_meta["repo_name"],
            org_name=self.config.org_name or "",
            branch_name=self.branch,
            authors=git_meta.get("authors", "Engineering Team"),
            previous_commit=git_meta.get("previous_commit", ""),
            current_commit=git_meta.get("current_commit", ""),
            commit_message=git_meta.get("commit_message", ""),
            commit_time=git_meta.get("commit_time", ""),
            changed_files=doc_changed_files,
            
        )

        # Give the generator the repo root so it can resolve relative logo paths
        self._doc_gen._repo_path = self.repo_path

        output = await self._doc_gen.generate(
            draft,
            feature_name,
            output_dir,
            metadata=metadata,
            doc_title_template=doc_title_template,
            org_name=self.config.org_name,
            project_name=self.config.project_name,
            repo_name=self.config.repo_name,
        )

        # Update memory from delta
        self._memory.update_from_delta(self._merged_delta)

        # Store automated run summary as feedback so future runs learn from it
        self._store_run_summary(feature_name, extra)
        # Log write step BEFORE store_run_summary so it appears in feedback
        self._steps_log.append(
            f"write_documentation — "
            f"md: {output.markdown_path}, "
            f"docx: {output.docx_path}"
        )

        # Update memory from delta
        self._memory.update_from_delta(self._merged_delta)

        # Store automated run summary as feedback so future runs learn from it
        self._store_run_summary(feature_name, extra)

        logger.success(f"Documentation written -> {output.docx_path}")

        return ToolResult(
            content=json.dumps({
                "success": True,
                "markdownPath": output.markdown_path,
                "docxPath": output.docx_path,
            }),
            is_terminal=True,
            terminal_status="GENERATED",
            output_path=output.docx_path,
            feature_name=feature_name,
        )

    def _critique_documentation(self) -> ToolResult:
        self._critique_calls += 1
        draft = self._executor._current_draft
        if not draft:
            return ToolResult(
                content=json.dumps({"error": "No draft available. Call store_draft first."}),
                is_terminal=False,
            )

        critic_provider = self._secondary_providers.get("critic")
        if not critic_provider:
            return ToolResult(
                content=json.dumps({"error": "Critic agent is not configured (no LLM provider available)."}),
                is_terminal=False,
            )

        if not self._merged_delta:
            return ToolResult(
                content=json.dumps({"error": "No API delta available. Call extract_api_changes first."}),
                is_terminal=False,
            )

        # Load critic skill and run via SkillRunner
        critic_path = self._skills_dir / "critic.md"
        if not critic_path.exists():
            return ToolResult(
                content=json.dumps({"error": "No critic.md skill found in skills directory."}),
                is_terminal=False,
            )

        skill = load_skill(critic_path)
        runner = SkillRunner(critic_provider)
        result = runner.run(skill, {
            "documentation": draft,
            "delta_summary": json.dumps(_delta_to_dict(self._merged_delta)),
        })

        if isinstance(result, dict):
            self._last_critique_result = result
            overall = (
                result.get("overallScore")
                or result.get("overall_score")
                or result.get("score")
                or "?"
            )
            self._steps_log.append(
                f"critique_documentation — overall score: {overall}/10"
            )

        return ToolResult(
            content=json.dumps(result),
            is_terminal=False,
        )

    def _evaluate_quality(self, compare_with_existing: bool = False) -> ToolResult:
        self._evaluate_calls += 1
        draft = self._executor._current_draft
        if not draft:
            return ToolResult(
                content=json.dumps({"error": "No draft available. Call store_draft first."}),
                is_terminal=False,
            )

        evaluator_provider = self._secondary_providers.get("evaluator")
        if not evaluator_provider:
            return ToolResult(
                content=json.dumps({"error": "Quality evaluator is not configured (no LLM provider available)."}),
                is_terminal=False,
            )

        # Skip evaluator for small changes
        if self._merged_delta:
            total_endpoints = (
                len(self._merged_delta.new)
                + len(self._merged_delta.modified)
                + len(self._merged_delta.removed)
            )
            if total_endpoints <= 2:
                return ToolResult(
                    content=json.dumps({
                        "skipped": True,
                        "reason": f"Only {total_endpoints} endpoint(s) changed — critic review is sufficient.",
                        "qualityScore": None,
                    }),
                    is_terminal=False,
                )

        # Load evaluator skill and run
        evaluator_path = self._skills_dir / "evaluator.md"
        if not evaluator_path.exists():
            return ToolResult(
                content=json.dumps({"error": "No evaluator.md skill found in skills directory."}),
                is_terminal=False,
            )

        skill = load_skill(evaluator_path)
        runner = SkillRunner(evaluator_provider)

        context: dict[str, Any] = {"documentation": draft}

        if compare_with_existing:
            output_dir = Path(self.repo_path) / self.config.output_dir
            existing = _read_existing_docs(output_dir)
            if existing:
                context["existing_docs"] = existing

        result = runner.run(skill, context)

        # Cache the score so write_documentation can store an automated feedback entry
        # Cache the score so write_documentation can store an automated feedback entry
        if isinstance(result, dict):
            score = result.get("qualityScore") or result.get("overallScore")
            if score is not None:
                try:
                    self._last_quality_score = float(score)
                except (TypeError, ValueError):
                    pass
                self._steps_log.append(
        f"evaluate_quality — score: {self._last_quality_score or '?'}/10"
    )

        return ToolResult(
            content=json.dumps(result),
            is_terminal=False,
        )

    def _store_run_summary(self, feature_name: str, extra: dict) -> None:
        """Store rich feedback after every successful write.
        All scores, steps, and lessons come from actual run data — nothing hardcoded.
        """
        if not self._merged_delta:
            return

        score = self._last_quality_score
        style = extra.get("doc_style", "detailed")
        n_new = len(self._merged_delta.new)
        n_mod = len(self._merged_delta.modified)
        n_rem = len(self._merged_delta.removed)
        rating = "good" if (score is not None and score >= 7) else "improved"

        lines = []

        # ── Run overview ──────────────────────────────────────────────────────
        lines.append(f"Style: {style}.")
        lines.append(
            f"Endpoints: {n_new} new, {n_mod} modified, {n_rem} removed."
        )
        # Helper used in critic notes and lessons blocks
        def _extract_msg(s: Any) -> str:
            if isinstance(s, str):
                return s
            if isinstance(s, dict):
                return (s.get("message") or s.get("suggestion")
                        or s.get("issue") or str(s))
            return str(s)
        
        # ── Quality scores (real — from evaluator + critic LLM calls) ─────────
        if score is not None or self._last_critique_result:
            lines.append("\nQuality Scores:")
            if score is not None:
                lines.append(f"  Evaluator overall: {score:.1f}/10")
            if self._last_critique_result:
                cr = self._last_critique_result
                critic_overall = cr.get("overallScore") or cr.get("overall_score")
                if critic_overall is not None:
                    lines.append(f"  Critic overall: {critic_overall}/10")
                # Dimensions are nested under 'scores' key
                scores_dict = cr.get("scores") or {}
                for dim in ("completeness", "clarity", "accuracy",
                            "structure", "developerExperience"):
                    val = scores_dict.get(dim) or cr.get(dim)
                    if val is not None:
                        lines.append(f"  {dim}: {val}/10")

        # ── Critic notes (real — from critic LLM output) ──────────────────────
        # ── Critic notes (real — from critic LLM output) ──────────────────────
        if self._last_critique_result:
            cr = self._last_critique_result

            def _extract_msg(s: Any) -> str:
                if isinstance(s, str):
                    return s
                if isinstance(s, dict):
                    return (s.get("message") or s.get("suggestion")
                            or s.get("issue") or str(s))
                return str(s)

            critical = cr.get("criticalIssues") or []
            suggestions = cr.get("suggestions") or cr.get("improvements") or []

            if critical:
                lines.append("\nCritical Issues (fix first):")
                for s in critical[:5]:
                    lines.append(f"  - {_extract_msg(s)}")

            if suggestions:
                lines.append("\nSuggestions:")
                for s in suggestions[:5]:
                    lines.append(f"  - {_extract_msg(s)}")

        # ── Validation gaps (real — from validator engine) ────────────────────
        if self._last_validation_errors:
            lines.append("\nValidation Gaps:")
            for e in self._last_validation_errors[:5]:
                lines.append(f"  - {e}")

        # ── Steps (real — logged during actual execution) ─────────────────────
        if self._steps_log:
            lines.append("\nSteps This Run:")
            for i, step in enumerate(self._steps_log, 1):
                lines.append(f"  {i}. {step}")

        # ── Lessons (real — derived from actual critic + validator output) ─────
        # ── Lessons (actionable instructions for next run's first draft) ────────
        lines.append("\nLessons — Apply Before Writing First Draft Next Run:")
        lessons_added = False

        # Validation errors → direct fix instructions
        if self._last_validation_errors:
            for e in self._last_validation_errors[:3]:
                if "Feature" in e or "header" in e.lower():
                    clean = re.sub(
                        r"^(feature|feat|fix|chore|hotfix|release)/", "",
                        self._merged_delta.feature
                    )
                    lines.append(
                        f"  - Start document with exactly: '# Feature: {clean}'"
                    )
                elif "Invented endpoint" in e:
                    lines.append(
                        "  - Only document endpoints from extract_api_changes — "
                        "never from memory or inference"
                    )
                else:
                    lines.append(f"  - Fix before drafting: {e}")
                lessons_added = True

        # Critical issues → must-fix instructions
        if self._last_critique_result:
            cr = self._last_critique_result
            critical = cr.get("criticalIssues") or []
            for c in critical[:3]:
                lines.append(f"  - Must fix: {_extract_msg(c)}")
                lessons_added = True

            # Low dimension scores → targeted instructions
            scores_dict = cr.get("scores") or {}
            dim_instructions = {
                "completeness": "Include all path params, query params, request body, response schema, and error codes",
                "developerExperience": "Add runnable cURL with Authorization: Bearer <token> for every endpoint",
                "accuracy": "Verify all field names and types against source using read_file — no guessing",
                "structure": "Use ### METHOD /path heading format for every endpoint",
                "clarity": "Write 2-3 sentence description per endpoint: what, when, expected output",
            }
            for dim, instruction in dim_instructions.items():
                val = scores_dict.get(dim) or cr.get(dim)
                if val is not None and float(val) < 7:
                    lines.append(f"  - {instruction} ({dim} scored {val}/10 last run)")
                    lessons_added = True

        if not lessons_added:
            lines.append("  - All dimensions scored well — maintain current approach")

        note = "\n".join(lines)
        self._memory.record_feedback(feature_name, rating, note, scope="global")

    def get_merged_delta(self) -> ExtractedApiDelta | None:
        return self._merged_delta


# ─── Helpers ──────────────────────────────────────────────────────────────────


def _delta_to_dict(delta: ExtractedApiDelta) -> dict:
    """Serialize an ExtractedApiDelta to a JSON-friendly dict."""

    def endpoint_dict(ep: Any) -> dict:
        d: dict[str, Any] = {"method": ep.method, "path": ep.path}
        if ep.handler:
            d["handler"] = ep.handler
        if ep.request_schema:
            d["requestSchema"] = [
                {"name": s.name, "type": s.type, "required": s.required}
                for s in ep.request_schema
            ]
        if ep.response_schema:
            d["responseSchema"] = [
                {"name": s.name, "type": s.type, "required": s.required}
                for s in ep.response_schema
            ]
        if ep.auth:
            d["auth"] = {"type": ep.auth.type}
            if ep.auth.scopes:
                d["auth"]["scopes"] = ep.auth.scopes
        if ep.tags:
            d["tags"] = ep.tags
        return d

    return {
        "feature": delta.feature,
        "branch": delta.branch,
        "baseBranch": delta.base_branch,
        "timestamp": delta.timestamp,
        "new": [endpoint_dict(e) for e in delta.new],
        "modified": [
            {
                "before": endpoint_dict(m.before),
                "after": endpoint_dict(m.after),
                "changeType": m.change_type,
            }
            for m in delta.modified
        ],
        "removed": [endpoint_dict(e) for e in delta.removed],
        "contractChanges": [
            {"endpoint": c.endpoint, "changeType": c.change_type, "description": c.description}
            for c in delta.contract_changes
        ],
        "authChanges": [
            {"file": a.file, "type": a.type, "description": a.description}
            for a in delta.auth_changes
        ],
        "versioningChanges": [
            {"type": v.type, "description": v.description}
            for v in delta.versioning_changes
        ],
    }


def _read_existing_docs(output_dir: Path) -> str:
    """Read existing markdown docs for style comparison."""
    if not output_dir.exists():
        return ""

    docs: list[str] = []
    for md_file in sorted(output_dir.glob("*-api-docs.md"))[:3]:
        try:
            content = md_file.read_text(encoding="utf-8", errors="replace")
            docs.append(f"### {md_file.name}\n{content[:2000]}")
        except Exception:
            continue

    return "\n\n".join(docs) if docs else ""