"""Document generation (L7). Writes both Markdown and DOCX."""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

from docx import Document
from docx.shared import Pt, Twips, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

from core.logger import logger
from datetime import datetime


@dataclass
class DocumentOutput:
    markdown_path: str
    docx_path: str


@dataclass
class DocumentMetadata:
    feature_name: str
    version: str
    repo_name: str
    project_name: str
    branch_name: str
    authors: str
    previous_commit: str
    current_commit: str
    commit_message: str
    commit_time: str
    changed_files: list[str]
    # Branding — both optional; header is skipped if neither is set
    logo_path: str | None = None        # path to logo image (absolute or repo-relative)
    company_name: str | None = None     # e.g. "VISHLESHAN SOFTWARE SOLUTIONS PVT. LTD."
    org_name: str | None = None

@dataclass
class ParsedSection:
    type: str  # h1, h2, h3, code, bullet, text
    content: str
    level: int = 0  # bullet indent level


class DocumentGenerator:
    async def generate(
        self,
        markdown_content: str,
        feature_name: str,
        output_dir: str,
        metadata: DocumentMetadata | None = None,
        doc_title_template: str = "{feature} - API Documentation",
        org_name: str | None = None,
        project_name: str | None = None,
        repo_name: str | None = None,
    ) -> DocumentOutput:
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        file_name = re.sub(r"[^a-zA-Z0-9-]", "-", feature_name)
        timestamp = datetime.now().strftime("%Y%m%d-%H%M")

        markdown_path = str(output_path / f"{file_name}-api-docs-{timestamp}.md")
        docx_path = str(output_path / f"{file_name}-api-docs-{timestamp}.docx")

        # Build document title from template
        self._doc_title = doc_title_template.format(
            org=org_name or "",
            project=project_name or "",
            repo=repo_name or "",
            feature=feature_name,
        ).strip(" -")

        Path(markdown_path).write_text(markdown_content, encoding="utf-8")
        logger.debug(f"Markdown written: {markdown_path}")

        self._generate_docx(markdown_content, docx_path, metadata)
        logger.debug(f"DOCX written: {docx_path}")

        return DocumentOutput(markdown_path=markdown_path, docx_path=docx_path)

    # ─── Private helpers ──────────────────────────────────────────────────────

    def _generate_docx(self, markdown: str, output_path: str, metadata: "DocumentMetadata | None" = None) -> None:
        sections = self._parse_markdown(markdown)
        doc = Document()

        # Set document title from template (or fallback to first heading)
        if hasattr(self, "_doc_title") and self._doc_title:
            doc.core_properties.title = self._doc_title
        else:
            first_line = markdown.split("\n")[0]
            doc.core_properties.title = re.sub(r"^#+\s*", "", first_line)
        doc.core_properties.author = metadata.authors if metadata else "agentic-docs"

        # ── Per-page header (logo + company name) ─────────────────────────────
        if metadata:
            self._add_page_header(doc, metadata)

        # ── Title (centered, below header) ─────────────────────────────
        if hasattr(self, "_doc_title") and self._doc_title:
            title_para = doc.add_paragraph()
            title_para.alignment = WD_ALIGN_PARAGRAPH.CENTER

            run = title_para.add_run(self._doc_title)
            run.bold = True
            run.font.size = Pt(20)

            title_para.paragraph_format.space_before = Twips(120)
            title_para.paragraph_format.space_after = Twips(200)

        # ── Metadata block (bullet list) ──────────────────────────────────────
        if metadata:
            generated_date = datetime.now().strftime("%Y-%m-%d")

            meta_items = [
                ("Feature",         metadata.feature_name),
                ("Version",         metadata.version),
                ("Organization",    metadata.org_name),
                ("Repository",      metadata.repo_name),
                ("Project",         metadata.project_name),
                ("Branch",          metadata.branch_name),
                ("Authors",         metadata.authors),
                ("Previous Commit", metadata.previous_commit),
                ("Current Commit",  metadata.current_commit),
                ("Commit Message",  metadata.commit_message),
                ("Commit Time",     metadata.commit_time),
                ("Generated Date",  generated_date),
            ]

            for label, value in meta_items:
                p = doc.add_paragraph(style="List Bullet")
                bold_run = p.add_run(f"{label}: ")
                bold_run.bold = True
                p.add_run(value or "—")
                p.paragraph_format.space_before = Twips(40)
                p.paragraph_format.space_after = Twips(40)

            # Changed files sub-list
            if metadata.changed_files:
                cf_p = doc.add_paragraph(style="List Bullet")
                cf_bold = cf_p.add_run("Changed Files:")
                cf_bold.bold = True
                cf_p.paragraph_format.space_before = Twips(40)
                cf_p.paragraph_format.space_after = Twips(20)

                for file_path in metadata.changed_files:
                    fp = doc.add_paragraph(style="List Bullet 2")
                    fp.add_run(file_path)
                    fp.paragraph_format.space_before = Twips(20)
                    fp.paragraph_format.space_after = Twips(20)

            # Spacer before the main content
            doc.add_paragraph().paragraph_format.space_after = Twips(80)

        # ── Main document content ─────────────────────────────────────────────
        for s in sections:
            if s.type == "h1":
                p = doc.add_heading(s.content, level=1)
                pf = p.paragraph_format
                pf.space_before = Twips(480)
                pf.space_after = Twips(240)

            elif s.type == "h2":
                p = doc.add_heading(s.content, level=2)
                pf = p.paragraph_format
                pf.space_before = Twips(360)
                pf.space_after = Twips(160)

            elif s.type == "h3":
                p = doc.add_heading(s.content, level=3)
                pf = p.paragraph_format
                pf.space_before = Twips(240)
                pf.space_after = Twips(120)

            elif s.type == "code":
                p = doc.add_paragraph()
                run = p.add_run(s.content)
                run.font.name = "Courier New"
                run.font.size = Pt(9)
                pf = p.paragraph_format
                pf.space_before = Twips(120)
                pf.space_after = Twips(120)
                pf.left_indent = Twips(360)

            elif s.type == "bullet":
                indent = "  " * s.level
                p = doc.add_paragraph()
                run = p.add_run(f"{indent}\u2022 {s.content}")
                pf = p.paragraph_format
                pf.space_before = Twips(60)
                pf.space_after = Twips(60)
                pf.left_indent = Twips(360 * (s.level + 1))

            elif s.type == "text":
                p = doc.add_paragraph(s.content)
                pf = p.paragraph_format
                if s.content.endswith(":"):
                    pf.space_before = Twips(160)
                    pf.space_after = Twips(40)
                else:
                    pf.space_before = Twips(120)
                    pf.space_after = Twips(120)

        doc.save(output_path)

    def _add_page_header(self, doc: Document, metadata: "DocumentMetadata") -> None:
        COMPANY_NAME = "VISHLESHAN SOFTWARE SOLUTIONS PVT. LTD."
        LOGO_PATH = Path(__file__).parent / "assets" / "VSS_logo.png"

        for section in doc.sections:
            section.header_distance = Twips(360)
            header = section.header
            header.is_linked_to_previous = False

            table = header.add_table(rows=1, cols=2, width=Inches(7.5))
            table.autofit = False
            table.columns[0].width = Inches(0.6)
            table.columns[1].width = Inches(6.9)

            tbl_pr = table._tbl.tblPr
            borders = OxmlElement("w:tblBorders")
            for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
                b = OxmlElement(f"w:{edge}")
                b.set(qn("w:val"), "nil")
                borders.append(b)
            tbl_pr.append(borders)

            # ── Left cell: logo ───────────────────────────────────────────────
            logo_cell = table.cell(0, 0)
            logo_para = logo_cell.paragraphs[0]
            logo_para.alignment = WD_ALIGN_PARAGRAPH.LEFT
            try:
                run = logo_para.add_run()
                run.add_picture(str(LOGO_PATH), width=Inches(0.38))
            except Exception as e:
                logger.warn(f"Could not embed header logo ({LOGO_PATH}): {e}")

            # ── Right cell: company name ──────────────────────────────────────
            name_cell = table.cell(0, 1)
            name_para = name_cell.paragraphs[0]
            name_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run = name_para.add_run(COMPANY_NAME)
            run.bold = True
            run.italic = True
            run.font.size = Pt(10)
            run.font.color.rgb = RGBColor(0x8B, 0x8B, 0x8B)

            tc_pr = name_cell._tc.get_or_add_tcPr()
            v_align = OxmlElement("w:vAlign")
            v_align.set(qn("w:val"), "center")
            tc_pr.append(v_align)

            for cell in (logo_cell, name_cell):
                tc_pr2 = cell._tc.get_or_add_tcPr()
                tc_borders = OxmlElement("w:tcBorders")
                bottom = OxmlElement("w:bottom")
                bottom.set(qn("w:val"), "single")
                bottom.set(qn("w:sz"), "6")
                bottom.set(qn("w:space"), "0")
                bottom.set(qn("w:color"), "4F81BD")
                tc_borders.append(bottom)
                tc_pr2.append(tc_borders)

    # def _resolve_logo_path(self, metadata: "DocumentMetadata") -> "Path | None":
    #     """Resolve logo_path to an absolute Path, or None if not found."""
    #     if not metadata.logo_path:
    #         return None
    #     logo = Path(metadata.logo_path)
    #     if logo.is_absolute():
    #         return logo if logo.exists() else None
    #     # Try relative to repo root
    #     if hasattr(self, "_repo_path") and self._repo_path:
    #         resolved = (Path(self._repo_path) / logo).resolve()
    #         if resolved.exists():
    #             return resolved
    #     return None

    @staticmethod
    def _strip_bold(text: str) -> str:
        """Remove **bold** and *italic* markdown markers from text."""
        text = re.sub(r"\*\*(.+?)\*\*", r"\1", text)
        text = re.sub(r"\*(.+?)\*", r"\1", text)
        text = re.sub(r"_(.+?)_", r"\1", text)
        return text

    @staticmethod
    def _table_row_to_bullets(line: str) -> list[ParsedSection]:
        """Convert a markdown table row like | Name | Type | Desc | into bullet items."""
        # Skip separator rows (---|---|---)
        if re.match(r"^\s*\|[\s\-|]+\|\s*$", line):
            return []
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        cells = [c for c in cells if c]
        if not cells:
            return []
        # If this looks like a header row (all bold or title-case), skip it
        # otherwise render as a bullet: "Name | Type | Description"
        result_sections = []
        for cell in cells:
            clean = re.sub(r"\*\*(.+?)\*\*", r"\1", cell)
            clean = re.sub(r"`(.+?)`", r"\1", clean)
            if clean:
                result_sections.append(ParsedSection(type="bullet", content=clean, level=1))
        return result_sections

    @staticmethod
    def _parse_markdown(markdown: str) -> list[ParsedSection]:
        result: list[ParsedSection] = []
        in_code = False
        code_lines: list[str] = []
        in_table = False
        table_header_cols: list[str] = []

        for line in markdown.split("\n"):
            if line.lstrip().startswith("```"):
                if in_code:
                    result.append(ParsedSection(type="code", content="\n".join(code_lines)))
                    code_lines.clear()
                    in_code = False
                else:
                    in_code = True
                in_table = False
                continue

            if in_code:
                code_lines.append(line)
                continue

            # Detect table rows
            stripped = line.strip()
            if stripped.startswith("|") and stripped.endswith("|"):
                # Separator row — skip
                if re.match(r"^\s*\|[\s\-:|]+\|\s*$", line):
                    in_table = True
                    continue
                cells = [c.strip() for c in stripped.strip("|").split("|")]
                cells = [re.sub(r"\*\*(.+?)\*\*", r"\1", c).strip() for c in cells]
                cells = [re.sub(r"`(.+?)`", r"\1", c).strip() for c in cells]
                cells = [c for c in cells if c]
                if not in_table:
                    # First row is a header — save cols for labelling data rows
                    table_header_cols = cells
                    in_table = True
                    continue
                else:
                    # Data row — emit as sub-bullets paired with header labels
                    for i, cell in enumerate(cells):
                        label = table_header_cols[i] if i < len(table_header_cols) else ""
                        content = f"{label}: {cell}" if label else cell
                        result.append(ParsedSection(type="bullet", content=content, level=1))
                continue
            else:
                in_table = False
                table_header_cols = []

            if line.startswith("#### "):
                # #### treated as h3
                content = DocumentGenerator._strip_bold(line[5:].strip().lstrip("#").strip())
                result.append(ParsedSection(type="h3", content=content))
            elif line.startswith("# "):
                result.append(ParsedSection(type="h1", content=DocumentGenerator._strip_bold(line[2:].strip())))
            elif line.startswith("## "):
                result.append(ParsedSection(type="h2", content=DocumentGenerator._strip_bold(line[3:].strip())))
            elif line.startswith("### "):
                result.append(ParsedSection(type="h3", content=DocumentGenerator._strip_bold(line[4:].strip())))
            elif re.match(r"^\s{0,3}[-*+]\s+", line):
                indent_match = re.match(r"^(\s*)", line)
                indent = len(indent_match.group(1)) if indent_match else 0
                content = re.sub(r"^\s*[-*+]\s+", "", line).strip()
                content = DocumentGenerator._strip_bold(content)
                result.append(ParsedSection(type="bullet", content=content, level=indent // 2))
            elif stripped:
                result.append(ParsedSection(type="text", content=DocumentGenerator._strip_bold(stripped)))

        # Flush unclosed code block
        if code_lines:
            result.append(ParsedSection(type="code", content="\n".join(code_lines)))

        return result