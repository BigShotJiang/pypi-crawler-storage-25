"""Flask route extractor.

Detects:
  - @app.route("/api/users", methods=["GET", "POST"])
  - @app.get("/api/users")
  - @app.post("/api/users")
  - @blueprint.route("/api/orders/<int:order_id>")
  - @bp.get("/api/orders")
  - app.add_url_rule("/api/...", view_func=...)
"""

from __future__ import annotations

import re

from core.extractor.types import (
    ApiEndpoint,
    AuthRequirement,
    ChangedFile,
    ModifiedEndpoint,
    SchemaField,
)

# @app.route("/path", methods=["GET","POST"]) | @blueprint.route("/path")
ROUTE_DECORATOR_PATTERN = re.compile(
    r"@(\w+)\s*\.\s*route\s*\(\s*['\"]([^'\"]+)['\"](?:.*?methods\s*=\s*\[([^\]]+)\])?",
    re.IGNORECASE | re.DOTALL,
)

# @app.get("/path") | @bp.post("/path") | @app.put("/path")
SHORTHAND_PATTERN = re.compile(
    r"@(\w+)\s*\.\s*(get|post|put|patch|delete|head|options)\s*\(\s*['\"]([^'\"]+)['\"]",
    re.IGNORECASE,
)

# app.add_url_rule("/path", methods=["GET"], view_func=...)
ADD_URL_RULE_PATTERN = re.compile(
    r"\.add_url_rule\s*\(\s*['\"]([^'\"]+)['\"](?:.*?methods\s*=\s*\[([^\]]+)\])?",
    re.IGNORECASE | re.DOTALL,
)


class FlaskExtractor:
    def detect(self, files: list[ChangedFile]) -> list[ChangedFile]:
        return [
            f
            for f in files
            if f.path.endswith(".py") and self._looks_like_flask(f.diff + (f.content or ""))
        ]

    def extract(self, file: ChangedFile, full_content: str) -> dict:
        added = self._parse_routes(self._diff_lines(file.diff, "+"), full_content)
        removed = self._parse_routes(self._diff_lines(file.diff, "-"), "")
        return self._categorise(added, removed)

    # ─── Private helpers ─────────────────────────────────────────────────────

    @staticmethod
    def _looks_like_flask(src: str) -> bool:
        return bool(
            re.search(
                r"from\s+flask\s+import|Flask\s*\(|Blueprint\s*\(|@\w+\.route\s*\(|\.add_url_rule\s*\(",
                src,
                re.IGNORECASE,
            )
        )

    @staticmethod
    def _diff_lines(diff: str, marker: str) -> str:
        triple = marker * 3
        return "\n".join(
            line[1:] for line in diff.split("\n") if line.startswith(marker) and not line.startswith(triple)
        )

    def _parse_routes(self, src: str, full_content: str) -> list[ApiEndpoint]:
        results: list[ApiEndpoint] = []

        # 1) @app.route("/path", methods=["GET", "POST"])
        for m in ROUTE_DECORATOR_PATTERN.finditer(src):
            path = self._normalise_path(m.group(2))
            methods_str = m.group(3)
            auth = self._detect_auth(full_content or src, m.start())
            handler = self._find_function_after(src, m.end())
            schema = self._extract_schema(full_content or src, m.start())

            if methods_str:
                methods = [s.strip().strip("'\"").upper() for s in methods_str.split(",")]
            else:
                methods = ["GET"]

            for method in methods:
                if method in ("GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"):
                    results.append(ApiEndpoint(
                        method=method, path=path, handler=handler,
                        request_schema=schema if method in ("POST", "PUT", "PATCH") else None,
                        auth=auth,
                    ))

        # 2) @app.get("/path") shorthand (Flask 2.0+)
        for m in SHORTHAND_PATTERN.finditer(src):
            method = m.group(2).upper()
            path = self._normalise_path(m.group(3))
            auth = self._detect_auth(full_content or src, m.start())
            handler = self._find_function_after(src, m.end())
            schema = self._extract_schema(full_content or src, m.start())

            results.append(ApiEndpoint(
                method=method, path=path, handler=handler,
                request_schema=schema if method in ("POST", "PUT", "PATCH") else None,
                auth=auth,
            ))

        # 3) app.add_url_rule("/path", methods=[...])
        for m in ADD_URL_RULE_PATTERN.finditer(src):
            path = self._normalise_path(m.group(1))
            methods_str = m.group(2)
            auth = self._detect_auth(full_content or src, m.start())

            if methods_str:
                methods = [s.strip().strip("'\"").upper() for s in methods_str.split(",")]
            else:
                methods = ["GET"]

            for method in methods:
                if method in ("GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"):
                    results.append(ApiEndpoint(method=method, path=path, auth=auth))

        return results

    @staticmethod
    def _normalise_path(raw: str) -> str:
        path = raw.strip("/")
        path = re.sub(r"<(?:\w+:)?(\w+)>", r"{\1}", path)
        return f"/{path}" if path else "/"

    @staticmethod
    def _find_function_after(src: str, pos: int) -> str | None:
        rest = src[pos : pos + 300]
        m = re.search(r"def\s+(\w+)", rest)
        return m.group(1) if m else None

    @staticmethod
    def _extract_schema(src: str, pos: int) -> list[SchemaField]:
        ctx = src[pos : pos + 800]
        fields: list[SchemaField] = []
        for m in re.finditer(
            r"request\.(?:json|form)\s*(?:\.get\s*\(\s*['\"](\w+)['\"]|(?:\[)['\"](\w+)['\"])",
            ctx,
        ):
            name = m.group(1) or m.group(2)
            if name:
                fields.append(SchemaField(name=name, type="any", required=True))
            if len(fields) >= 12:
                break
        return fields

    @staticmethod
    def _detect_auth(src: str, pos: int) -> AuthRequirement:
        ctx = src[max(0, pos - 400) : pos + 400]
        if re.search(r"login_required|jwt_required|@token_required|verify_token|current_user", ctx, re.IGNORECASE):
            return AuthRequirement(type="bearer")
        if re.search(r"api_key|x-api-key", ctx, re.IGNORECASE):
            return AuthRequirement(type="api-key")
        if re.search(r"HTTPBasicAuth|basic_auth", ctx, re.IGNORECASE):
            return AuthRequirement(type="basic")
        return AuthRequirement(type="none")

    @staticmethod
    def _categorise(added: list[ApiEndpoint], removed: list[ApiEndpoint]) -> dict:
        new_eps: list[ApiEndpoint] = []
        modified: list[ModifiedEndpoint] = []
        removed_eps: list[ApiEndpoint] = []

        for ep in added:
            prev = next((r for r in removed if r.path == ep.path and r.method == ep.method), None)
            if prev:
                modified.append(ModifiedEndpoint(before=prev, after=ep, change_type="request-schema"))
            else:
                new_eps.append(ep)

        for ep in removed:
            if not any(a.path == ep.path and a.method == ep.method for a in added):
                removed_eps.append(ep)

        return {
            "new": new_eps,
            "modified": modified,
            "removed": removed_eps,
            "contract_changes": [],
            "auth_changes": [],
            "versioning_changes": [],
        }
