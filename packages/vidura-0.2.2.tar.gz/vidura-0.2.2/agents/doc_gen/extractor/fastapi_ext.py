# """FastAPI decorator extractor."""

# from __future__ import annotations

# import re

# from core.extractor.types import (
#     ApiEndpoint,
#     AuthRequirement,
#     ChangedFile,
#     ModifiedEndpoint,
#     SchemaField,
#     PathParam,
#     QueryParam,
# )

# # @app.get("/path") | @router.post("/path/{id}")
# ROUTE_PATTERN = re.compile(
#     r"@(?:app|router)\s*\.\s*(get|post|put|patch|delete|head|options)\s*\(\s*['\"]([^'\"]+)['\"]",
#     re.IGNORECASE,
# )


# class FastApiExtractor:
#     def detect(self, files: list[ChangedFile]) -> list[ChangedFile]:
#         return [f for f in files if f.path.endswith(".py") and self._looks_like_fastapi(f.diff + (f.content or ""))]

#     def extract(self, file: ChangedFile, full_content: str) -> dict:
#         added   = self._parse_routes(self._diff_lines(file.diff, "+"), full_content)
#         # FIX: was passing "" — every removed-endpoint auth/schema call sliced into
#         # an empty string, so auth always returned "none" and schema returned [].
#         removed = self._parse_routes(self._diff_lines(file.diff, "-"), full_content)
#         return self._categorise(added, removed)

#     # ─── Private helpers ────────────────────────────────────────────────────────

#     @staticmethod
#     def _looks_like_fastapi(src: str) -> bool:
#         pattern = r"from\s+fastapi\s+import|@(?:app|router)\.(get|post|put|patch|delete)"
#         return bool(re.search(pattern, src, re.IGNORECASE))

#     @staticmethod
#     def _diff_lines(diff: str, marker: str) -> str:
#         triple = marker * 3
#         return "\n".join(
#             line[1:] for line in diff.split("\n") if line.startswith(marker) and not line.startswith(triple)
#         )

#     def _parse_routes(self, src: str, full_content: str) -> list[ApiEndpoint]:
#         results: list[ApiEndpoint] = []
#         for m in ROUTE_PATTERN.finditer(src):
#             method = m.group(1).upper()
#             path   = m.group(2)

#             # FIX: m.start() is an offset inside the diff-stripped string, not inside
#             # full_content. Every helper (_extract_pydantic_fields, _detect_auth,
#             # _extract_query_params, _extract_response_schema) was receiving a stale
#             # offset and slicing into the wrong section of the file.
#             # Re-find the same route in full_content to get a valid position.
#             fc_pos = 0
#             for fc_m in ROUTE_PATTERN.finditer(full_content):
#                 if fc_m.group(1).upper() == method and fc_m.group(2) == path:
#                     fc_pos = fc_m.start()
#                     break

#             results.append(
#                 ApiEndpoint(
#                     method=method,
#                     path=path,
#                     request_schema=self._extract_pydantic_fields(full_content, fc_pos),
#                     response_schema=self._extract_response_schema(full_content, fc_pos),
#                     params=self._extract_path_params(path),
#                     query=self._extract_query_params(full_content, fc_pos),
#                     auth=self._detect_auth(full_content, fc_pos),
#                 )
#             )
#         return results

#     @staticmethod
#     def _extract_pydantic_fields(src: str, pos: int) -> list[SchemaField]:
#         """Pull field names/types from the Pydantic BaseModel defined BEFORE the route."""
#         # FIX: was scanning pos→pos+1000 (after the decorator). The model is always
#         # declared above the route, so scan backwards: pos-2000→pos instead.
#         ctx = src[max(0, pos - 2000) : pos]
#         fields: list[SchemaField] = []

#         model_matches = list(re.finditer(r"class\s+\w+\s*\(\s*BaseModel\s*\)", ctx))
#         if not model_matches:
#             return fields

#         # Take the closest model before this route.
#         model_body = ctx[model_matches[-1].start():]
#         for m in re.finditer(
#             r"^\s+(\w+)\s*:\s*(Optional\[[\w\[\], ]+\]|List\[[\w\[\], ]+\]|str|int|float|bool|[\w]+)",
#             model_body,
#             re.MULTILINE,
#         ):
#             fields.append(
#                 SchemaField(name=m.group(1), type=m.group(2), required=not m.group(2).startswith("Optional"))
#             )
#             if len(fields) >= 12:
#                 break
#         return fields

#     @staticmethod
#     def _detect_auth(src: str, pos: int) -> AuthRequirement:
#         # FIX: widened forward window from +400 to +800 to reliably capture
#         # Depends(...) inside the function signature/body after the decorator.
#         ctx = src[max(0, pos - 200) : pos + 800]
#         if re.search(r"Depends\s*\(\s*(?:get_current_user|oauth2_scheme|bearer)", ctx, re.IGNORECASE):
#             return AuthRequirement(type="bearer")
#         if re.search(r"api_key|APIKey", ctx, re.IGNORECASE):
#             return AuthRequirement(type="api-key")
#         return AuthRequirement(type="none")

#     @staticmethod
#     def _categorise(added: list[ApiEndpoint], removed: list[ApiEndpoint]) -> dict:
#         new_eps: list[ApiEndpoint]      = []
#         modified: list[ModifiedEndpoint] = []
#         removed_eps: list[ApiEndpoint]  = []
#         auth_changes: list[dict]        = []  # FIX: was always returned as [] even when auth changed

#         for ep in added:
#             prev = next((r for r in removed if r.path == ep.path and r.method == ep.method), None)
#             if prev:
#                 modified.append(ModifiedEndpoint(before=prev, after=ep, change_type="request-schema"))
#                 # Populate auth_changes when auth type changed between old and new version.
#                 if prev.auth.type != ep.auth.type:
#                     auth_changes.append({
#                         "method": ep.method,
#                         "path":   ep.path,
#                         "before": prev.auth.type,
#                         "after":  ep.auth.type,
#                     })
#             else:
#                 new_eps.append(ep)

#         for ep in removed:
#             if not any(a.path == ep.path and a.method == ep.method for a in added):
#                 removed_eps.append(ep)

#         return {
#             "new": new_eps,
#             "modified": modified,
#             "removed": removed_eps,
#             "contract_changes": [],
#             "auth_changes": auth_changes,
#             "versioning_changes": [],
#         }

#     def _extract_path_params(self, path: str) -> list[PathParam]:
#         return [PathParam(name=p, type="string") for p in re.findall(r"{(\w+)}", path)]

#     def _extract_query_params(self, src: str, pos: int) -> list[QueryParam]:
#         # Scan the function signature that follows the decorator (pos→pos+400).
#         # fc_pos is already correct here — passed in from _parse_routes after the fix.
#         ctx = src[pos : pos + 400]
#         params: list[QueryParam] = []
#         for m in re.finditer(
#             r"(\w+)\s*:\s*(Optional\[[^\]]+\]|List\[[^\]]+\]|int|str|float|bool)\s*=",
#             ctx,
#         ):
#             name = m.group(1)
#             typ  = m.group(2)
#             params.append(
#                 QueryParam(
#                     name=name,
#                     type=typ.replace("Optional[", "").replace("]", ""),
#                     required="Optional" not in typ,
#                 )
#             )
#         return params

#     def _extract_response_schema(self, src: str, pos: int) -> list[SchemaField] | None:
#         # Scan forward from the decorator line (pos→pos+400).
#         # fc_pos is already correct here — passed in from _parse_routes after the fix.
#         ctx = src[pos : pos + 400]
#         m = re.search(r"response_model\s*=\s*(\w+)", ctx)
#         if not m:
#             return None
#         return [SchemaField(name="body", type=m.group(1), required=True)]

"""FastAPI decorator extractor."""

from __future__ import annotations

import re

from core.extractor.types import (
    ApiEndpoint,
    AuthChange,
    AuthRequirement,
    ChangedFile,
    ModifiedEndpoint,
    SchemaField,
    PathParam,
    QueryParam,
)

# @app.get("/path") | @router.post("/path/{id}")
ROUTE_PATTERN = re.compile(
    r"@(?:app|router)\s*\.\s*(get|post|put|patch|delete|head|options)\s*\(\s*['\"]([^'\"]+)['\"]",
    re.IGNORECASE,
)


class FastApiExtractor:
    def detect(self, files: list[ChangedFile]) -> list[ChangedFile]:
        return [
            f for f in files
            if f.path.endswith(".py") and self._looks_like_fastapi(f.diff + (f.content or ""))
        ]

    def extract(self, file: ChangedFile, full_content: str) -> dict:
        added = self._parse_routes(self._diff_lines(file.diff, "+"), full_content)
        removed = self._parse_routes(self._diff_lines(file.diff, "-"), full_content)
        return self._categorise(file.path, added, removed)

    # ─── Private helpers ────────────────────────────────────────────────────────

    @staticmethod
    def _looks_like_fastapi(src: str) -> bool:
        pattern = r"from\s+fastapi\s+import|@(?:app|router)\.(get|post|put|patch|delete)"
        return bool(re.search(pattern, src, re.IGNORECASE))

    @staticmethod
    def _diff_lines(diff: str, marker: str) -> str:
        triple = marker * 3
        return "\n".join(
            line[1:] for line in diff.split("\n") if line.startswith(marker) and not line.startswith(triple)
        )

    def _parse_routes(self, src: str, full_content: str) -> list[ApiEndpoint]:
        results: list[ApiEndpoint] = []

        for m in ROUTE_PATTERN.finditer(src):
            method = m.group(1).upper()
            path = m.group(2)

            # Re-find the same route in full_content to get a valid position.
            fc_pos = 0
            for fc_m in ROUTE_PATTERN.finditer(full_content):
                if fc_m.group(1).upper() == method and fc_m.group(2) == path:
                    fc_pos = fc_m.start()
                    break

            results.append(
                ApiEndpoint(
                    method=method,
                    path=path,
                    handler=self._extract_handler_name(full_content, fc_pos),
                    request_schema=self._extract_request_schema(full_content, fc_pos),
                    response_schema=self._extract_response_schema(full_content, fc_pos),
                    params=self._extract_path_params(path),
                    query=self._extract_query_params(full_content, fc_pos),
                    auth=self._detect_auth(full_content, fc_pos),
                )
            )

        return results

    @staticmethod
    def _extract_signature_block(src: str, pos: int) -> str:
        ctx = src[pos: pos + 1800]
        m = re.search(r"def\s+\w+\s*\((.*?)\)\s*:", ctx, re.DOTALL)
        return m.group(1) if m else ""

    @staticmethod
    def _extract_handler_name(src: str, pos: int) -> str | None:
        ctx = src[pos: pos + 500]
        m = re.search(r"def\s+(\w+)\s*\(", ctx)
        return m.group(1) if m else None

    def _extract_request_schema(self, src: str, pos: int) -> list[SchemaField] | None:
        """
        Extract request body fields.

        Supports:
        1. Inline Body(...) params in function signatures
        2. Closest Pydantic BaseModel declared before the route
        """
        fields: list[SchemaField] = []
        signature = self._extract_signature_block(src, pos)

        # Inline Body(...) params like:
        # payload: dict = Body(...)
        # reviewed_by: str = Body(...)
        # notes: Optional[str] = Body(None)
        for m in re.finditer(
            r"(\w+)\s*:\s*(Optional\[[^\]]+\]|List\[[^\]]+\]|list\[[^\]]+\]|dict|str|int|float|bool|\w+)\s*=\s*Body\((.*?)\)",
            signature,
            re.DOTALL,
        ):
            name = m.group(1)
            typ = m.group(2).strip()
            default_expr = m.group(3)

            required = "None" not in default_expr and not typ.startswith("Optional[")
            clean_type = typ.replace("Optional[", "").replace("]", "")

            fields.append(
                SchemaField(
                    name=name,
                    type=clean_type,
                    required=required,
                    description=None,
                )
            )

        if fields:
            return fields

        # Fallback: nearest Pydantic BaseModel before route
        ctx = src[max(0, pos - 2500): pos]
        model_matches = list(re.finditer(r"class\s+(\w+)\s*\(\s*BaseModel\s*\)\s*:", ctx))
        if not model_matches:
            return None

        model_body = ctx[model_matches[-1].start():]

        for m in re.finditer(
            r"^\s+(\w+)\s*:\s*(Optional\[[\w\[\], ]+\]|List\[[\w\[\], ]+\]|str|int|float|bool|dict|list|\w+)",
            model_body,
            re.MULTILINE,
        ):
            typ = m.group(2).strip()
            fields.append(
                SchemaField(
                    name=m.group(1),
                    type=typ.replace("Optional[", "").replace("]", ""),
                    required=not typ.startswith("Optional"),
                    description=None,
                )
            )
            if len(fields) >= 20:
                break

        return fields or None

    @staticmethod
    def _detect_auth(src: str, pos: int) -> AuthRequirement:
        """
        Detect auth from:
        - authorization/token headers
        - Depends(get_current_user / oauth2 / bearer / auth...)
        - api key patterns
        """
        ctx = src[max(0, pos - 200): pos + 1400]

        # Header-based auth like authorization: str = Header(...)
        if re.search(
            r"(authorization|auth|access_token|token)\s*:\s*[\w\[\], ]+\s*=\s*Header\s*\(",
            ctx,
            re.IGNORECASE,
        ):
            return AuthRequirement(type="bearer")

        # Depends-based auth
        if re.search(
            r"Depends\s*\(\s*(?:get_current_user|oauth2_scheme|bearer|jwt|auth)",
            ctx,
            re.IGNORECASE,
        ):
            return AuthRequirement(type="bearer")

        if re.search(r"api_key|APIKey", ctx, re.IGNORECASE):
            return AuthRequirement(type="api-key")

        if re.search(r"basic\s+auth|HTTPBasic|BasicAuth", ctx, re.IGNORECASE):
            return AuthRequirement(type="basic")

        if re.search(r"oauth2", ctx, re.IGNORECASE):
            return AuthRequirement(type="oauth2")

        return AuthRequirement(type="none")

    @staticmethod
    def _extract_path_params(path: str) -> list[PathParam]:
        return [PathParam(name=p, type="string") for p in re.findall(r"{(\w+)}", path)]

    def _extract_query_params(self, src: str, pos: int) -> list[QueryParam] | None:
        """
        Extract only params explicitly declared with Query(...).
        """
        signature = self._extract_signature_block(src, pos)
        params: list[QueryParam] = []

        for m in re.finditer(
            r"(\w+)\s*:\s*(Optional\[[^\]]+\]|List\[[^\]]+\]|int|str|float|bool)\s*=\s*Query\((.*?)\)",
            signature,
            re.DOTALL,
        ):
            name = m.group(1)
            typ = m.group(2).strip()
            default_expr = m.group(3)

            required = "None" not in default_expr and not typ.startswith("Optional[")

            params.append(
                QueryParam(
                    name=name,
                    type=typ.replace("Optional[", "").replace("]", ""),
                    required=required,
                )
            )

        return params or None

    def _extract_response_schema(self, src: str, pos: int) -> list[SchemaField] | None:
        """
        Extract response schema from:
        1. response_model=...
        2. top-level keys in returned dict
        """
        ctx = src[pos: pos + 3000]

        # response_model=SomeModel
        m = re.search(r"response_model\s*=\s*(\w+)", ctx)
        if m:
            return [
                SchemaField(
                    name="body",
                    type=m.group(1),
                    required=True,
                    description=None,
                )
            ]

        # fallback: capture first return { ... }
        ret = re.search(r"return\s*\{(.*?)\n\s*\}", ctx, re.DOTALL)
        if not ret:
            return None

        fields: list[SchemaField] = []
        return_body = ret.group(1)

        for key_match in re.finditer(
            r'["\']([\w_]+)["\']\s*:\s*([^,\n]+)', return_body
        ):
            name = key_match.group(1)
            value = key_match.group(2).strip().rstrip(",").strip()

            # Only infer from actual literals visible in the source code.
            # Never guess from variable names — that is project-specific.
            if value.startswith('"') or value.startswith("'"):
                inferred = "string"
            elif value in ("True", "False"):
                inferred = "boolean"
            elif value.lstrip("-").isdigit():
                inferred = "integer"
            elif re.match(r"^-?\d+\.\d+$", value):
                inferred = "float"
            elif value.startswith("{"):
                inferred = "object"
            elif value.startswith("["):
                inferred = "array"
            elif value == "None":
                inferred = "null"
            else:
                # Variable reference — type cannot be determined statically.
                # Agent must use read_file to find the actual type.
                inferred = "unknown"

            fields.append(
                SchemaField(
                    name=name,
                    type=inferred,
                    required=True,
                    description=None,
                )
            )

        return fields or None

    @staticmethod
    def _categorise(file_path: str, added: list[ApiEndpoint], removed: list[ApiEndpoint]) -> dict:
        new_eps: list[ApiEndpoint] = []
        modified: list[ModifiedEndpoint] = []
        removed_eps: list[ApiEndpoint] = []
        auth_changes: list[AuthChange] = []

        for ep in added:
            prev = next((r for r in removed if r.path == ep.path and r.method == ep.method), None)
            if prev:
                change_type = "request-schema"

                before_auth = prev.auth.type if prev.auth else "none"
                after_auth = ep.auth.type if ep.auth else "none"

                if before_auth != after_auth:
                    change_type = "auth"
                    auth_changes.append(
                        AuthChange(
                            file=file_path,
                            type="modified",
                            description=f"{ep.method} {ep.path} auth changed: {before_auth} -> {after_auth}",
                        )
                    )

                modified.append(
                    ModifiedEndpoint(
                        before=prev,
                        after=ep,
                        change_type=change_type,
                    )
                )
            else:
                new_eps.append(ep)

        for ep in removed:
            if not any(a.path == ep.path and a.method == ep.method for a in added):
                removed_eps.append(ep)

        return {
            "new": new_eps,
            "modified": modified,
            "removed": removed_eps,
            "contract_changes": [],
            "auth_changes": auth_changes,
            "versioning_changes": [],
        }