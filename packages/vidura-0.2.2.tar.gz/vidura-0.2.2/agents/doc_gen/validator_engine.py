"""Declarative validation engine — reads rules from validator.md skill file."""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from core.extractor.types import ApiEndpoint, ExtractedApiDelta
from core.logger import logger
from core.skill_loader import SkillDefinition

VALID_METHODS = {"GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"}


@dataclass
class ValidationResult:
    valid: bool
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


class ValidatorEngine:
    """Applies declarative validation rules from a skill definition."""

    def validate(self, documentation: str, delta: ExtractedApiDelta, skill: SkillDefinition) -> ValidationResult:
        """Run all rules from the skill definition against the documentation."""
        errors: list[str] = []
        warnings: list[str] = []

        for rule in skill.rules:
            rule_id = rule.get("id", "unknown")
            severity = rule.get("severity", "error")
            check = rule.get("check", "")
            message_template = rule.get("message", f"Rule '{rule_id}' failed")

            issues = self._run_check(check, rule, documentation, delta, message_template)

            if severity == "error":
                errors.extend(issues)
            else:
                warnings.extend(issues)

        logger.debug(f"Validation — errors: {len(errors)}, warnings: {len(warnings)}")
        return ValidationResult(valid=len(errors) == 0, errors=errors, warnings=warnings)

    def _run_check(
        self,
        check: str,
        rule: dict,
        doc: str,
        delta: ExtractedApiDelta,
        message_template: str,
    ) -> list[str]:
        """Dispatch to the appropriate check handler."""
        handlers = {
            "contains": self._check_contains,
            "regex_absent": self._check_regex_absent,
            "http_methods": self._check_http_methods,
            "endpoints_in_delta": self._check_endpoints_in_delta,
            "delta_coverage": self._check_delta_coverage,
        }

        handler = handlers.get(check)
        if not handler:
            return []

        return handler(rule, doc, delta, message_template)

    @staticmethod
    def _check_contains(rule: dict, doc: str, delta: ExtractedApiDelta, message: str) -> list[str]:
        import re as _re
        feature_name = _re.sub(r"^(feature|feat|fix|chore|hotfix|release)/", "", delta.feature)
        pattern = rule.get("pattern", "")
        pattern = pattern.replace("{feature}", feature_name)

        if pattern not in doc:
            return [message.replace("{feature}", feature_name)]
        return []

    @staticmethod
    def _check_regex_absent(rule: dict, doc: str, delta: ExtractedApiDelta, message: str) -> list[str]:
        """Check that none of the regex patterns match (they should be absent)."""
        issues: list[str] = []
        for pattern_str in rule.get("patterns", []):
            compiled = re.compile(pattern_str, re.IGNORECASE)
            m = compiled.search(doc)
            if m:
                issues.append(message.replace("{match}", m.group(0)))
        return issues

    @staticmethod
    def _check_http_methods(rule: dict, doc: str, delta: ExtractedApiDelta, message: str) -> list[str]:
        """Check that only valid HTTP methods appear in endpoint references."""
        allowed = set(rule.get("allowed", VALID_METHODS))
        issues: list[str] = []
        for m in re.finditer(r"`([A-Z]+)\s+/[^\s`]*`", doc):
            if m.group(1) not in allowed:
                issues.append(f"Invalid HTTP method in documentation: {m.group(1)}")
        return issues

    def _check_endpoints_in_delta(self, rule: dict, doc: str, delta: ExtractedApiDelta, message: str) -> list[str]:
        """Check that every documented endpoint exists in the delta (no invented endpoints)."""
        all_ground_truth = self._all_endpoints(delta)
        documented = self._extract_documented_endpoints(doc)

        issues: list[str] = []
        for d in documented:
            found = any(
                ep.method == d["method"] and self._paths_match(ep.path, d["path"])
                for ep in all_ground_truth
            )
            if not found:
                issues.append(f"Invented endpoint not in structured data: {d['method']} {d['path']}")
        return issues

    def _check_delta_coverage(self, rule: dict, doc: str, delta: ExtractedApiDelta, message: str) -> list[str]:
        """Check that new endpoints are mentioned in the docs (non-blocking)."""
        documented = self._extract_documented_endpoints(doc)
        issues: list[str] = []
        for ep in delta.new:
            covered = any(
                d["method"] == ep.method and self._paths_match(d["path"], ep.path)
                for d in documented
            )
            if not covered:
                issues.append(f"New endpoint not mentioned in docs: {ep.method} {ep.path}")
        return issues

    # ─── Helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _all_endpoints(delta: ExtractedApiDelta) -> list[ApiEndpoint]:
        return [
            *delta.new,
            *(m.after for m in delta.modified),
            *(m.before for m in delta.modified),
            *delta.removed,
        ]

    @staticmethod
    def _extract_documented_endpoints(doc: str) -> list[dict[str, str]]:
        results: list[dict[str, str]] = []
        for m in re.finditer(
            r"[`*]{0,2}(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)\s+(/[^\s`*\"']+)[`*]{0,2}", doc
        ):
            results.append({"method": m.group(1), "path": m.group(2)})
        return results

    @staticmethod
    def _paths_match(a: str, b: str) -> bool:
        def norm(p: str) -> str:
            p = re.sub(r":[a-zA-Z_]\w*", "{p}", p)
            p = re.sub(r"\{[^}]+\}", "{p}", p)
            return p

        return norm(a) == norm(b) or a == b
