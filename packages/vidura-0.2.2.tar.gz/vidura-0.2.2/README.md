# Vidura

Universal Agent Orchestrator — skill-driven AI agents for software development workflows.

Vidura runs any agent by swapping skill `.md` files and an `agent.yaml` manifest. One PyPI package, multiple agents. Each agent is defined by markdown skill files (behavior) and a YAML manifest (tools, memory, workflow config) — no Python changes needed to customize or add agents.

---

## How it works

```
CI trigger ──▶ vidura run --agent doc-gen --config-url $URL --token $TOKEN
                    │
                    ├── loads agent.yaml manifest
                    ├── loads skills/*.md (system prompt, critic, evaluator, validator)
                    ├── runs multi-turn LLM agent loop with tool-use
                    └── produces structured JSON output (AgentOutput)
                              │
                              ▼
                    SaaS platform translates to VCS API calls
                    (commits, PR comments, issues, check statuses)
```

Vidura is **VCS-agnostic** — it produces structured JSON output. A separate SaaS platform translates that output into GitHub/GitLab/Bitbucket/Azure DevOps API calls.

---

## Available Agents

| Agent | Output Type | Description |
|-------|-------------|-------------|
| `doc-gen` | `file_commit` | Detects API changes via git diff, generates Word + Markdown documentation |
| `readme-updater` | `pull_request` | Detects config/setup changes and updates README.md to stay in sync |

More agents planned: `code-review`, `pr-description`, `changelog-gen`, `security-scan`, `test-gen`.

---

## Installation

```bash
pip install vidura
```

Anthropic (Claude) is included. Verify:

```bash
vidura --version
vidura doctor   # check environment + connectivity
```

---

## Quick Start

### SaaS mode (recommended for teams)

The platform admin configures everything. The developer sets **zero env vars** — just two CI secrets.

```bash
# 1. Store two secrets in your CI:
#    VIDURA_TOKEN       ← install token from platform admin
#    VIDURA_CONFIG_URL  ← platform config endpoint (e.g. https://api.vidura.dev/api/v1/config)

# 2. Add to your CI workflow:
vidura sync --agent doc-gen --config-url $VIDURA_CONFIG_URL --token $VIDURA_TOKEN
vidura run  --agent doc-gen --config-url $VIDURA_CONFIG_URL --token $VIDURA_TOKEN
```

### Local mode (individual developer)

```bash
# 1. Install
pip install vidura

# 2. Set required env vars (doc-gen uses AGENTIC_DOCS_ prefix)
export ANTHROPIC_API_KEY=sk-ant-...
export AGENTIC_DOCS_MODEL=claude-sonnet-4-6
export AGENTIC_DOCS_MAX_INPUT_TOKENS=100000
export AGENTIC_DOCS_MAX_OUTPUT_TOKENS=8192

# 3. Initialise in your repo
cd /path/to/your/repo
vidura init --agent doc-gen

# 4. Run
vidura run --agent doc-gen --verbose
```

---

## SaaS Configuration

### What the platform provides

When `--config-url` and `--token` are passed, the platform resolves and delivers:

| Field | Source |
|-------|--------|
| Provider + model | Org subscription (e.g. `claude-sonnet-4-6`) |
| API key | Fetched separately from `/credentials/{id}` — never in the main response |
| Token budgets | Per-org quota, per-run limit |
| Global memory token | Fetched separately from `/memory-token` — short-lived GitHub App token (~1 hr) |
| Callback + progress URLs | Platform-assigned per run |
| Run ID | Platform-assigned UUID |

The developer CI workflow contains **only** `VIDURA_TOKEN` (install token) and `VIDURA_CONFIG_URL`. No API keys, no model names, no token numbers.

### GitHub Actions example

```yaml
name: Vidura doc-gen

on:
  pull_request:
    branches: [main]

jobs:
  doc-gen:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0        # full history needed for git diff

      - name: Install Vidura
        run: pip install vidura

      - name: Sync skills from platform
        run: vidura sync --agent doc-gen --config-url ${{ secrets.VIDURA_CONFIG_URL }} --token ${{ secrets.VIDURA_TOKEN }}

      - name: Run doc-gen agent
        run: vidura run --agent doc-gen --config-url ${{ secrets.VIDURA_CONFIG_URL }} --token ${{ secrets.VIDURA_TOKEN }}
```

### Platform onboarding (operator)

The platform admin runs these once per org/repo:

```bash
BASE=https://api.vidura.dev
SECRET=<admin_secret>

# 1. Create org
curl -X POST $BASE/api/v1/admin/orgs \
  -H "X-Admin-Secret: $SECRET" -H "Content-Type: application/json" \
  -d '{
    "name": "acme",
    "plan": "pro",
    "monthly_token_quota": 5000000,
    "global_memory_repo_url": "https://github.com/acme/vidura-memory",
    "global_memory_app_id": "123456",
    "global_memory_installation_id": "987654",
    "global_memory_private_key": "-----BEGIN RSA PRIVATE KEY-----\n..."
  }' | jq .
# → {"id": "<org_id>", ...}

# 2. Add repo
curl -X POST $BASE/api/v1/admin/orgs/<org_id>/repos \
  -H "X-Admin-Secret: $SECRET" -H "Content-Type: application/json" \
  -d '{"full_name": "acme/backend", "vcs_platform": "github", "vcs_token": "ghp_..."}' | jq .
# → {"id": "<repo_id>", ...}

# 3. Configure agent (stores encrypted API key)
curl -X POST $BASE/api/v1/admin/orgs/<org_id>/agent-configs \
  -H "X-Admin-Secret: $SECRET" -H "Content-Type: application/json" \
  -d '{
    "repo_id": "<repo_id>",
    "agent_name": "doc-gen",
    "api_key": "sk-ant-...",
    "model": "claude-sonnet-4-6",
    "max_input_tokens": 100000,
    "per_run_token_limit": 100000
  }' | jq .

# 4. Generate install token (shown once — store as VIDURA_TOKEN CI secret)
curl -X POST $BASE/api/v1/admin/orgs/<org_id>/install-tokens \
  -H "X-Admin-Secret: $SECRET" -H "Content-Type: application/json" \
  -d '{"repo_id": "<repo_id>", "agent_name": "doc-gen", "label": "ci-prod"}' | jq .
# → {"token": "vidt_...", ...}
```

### Global memory (SaaS)

Global memory is a shared Git repo where agents accumulate knowledge across runs and projects. In SaaS mode it is configured entirely on the platform — the CLI never sees the long-lived credentials.

The platform uses a **GitHub App** to mint short-lived tokens (~1 hour TTL) at the start of each run:

```
Platform stores:  App ID + Installation ID + RSA private key (encrypted)
                              ↓  at run time
                  Calls GitHub API → fresh 1-hour installation token
                              ↓
CLI receives:     Token valid for this run only
```

The memory repo is structured per agent:

```
vidura-memory/
├── doc-gen/
│   ├── common-patterns.md
│   ├── auth-strategies.md
│   └── style-guide.md
└── readme-updater/
    └── common-patterns.md
```

---

## Local Configuration

All configuration is from environment variables. The prefix is per-agent (set in `agent.yaml` → `config.env_prefix`).

### doc-gen agent (prefix: `AGENTIC_DOCS`)

#### Required

| Variable | Description |
|----------|-------------|
| `ANTHROPIC_API_KEY` | Anthropic API key |
| `AGENTIC_DOCS_MODEL` | Model ID (e.g. `claude-sonnet-4-6`, `claude-opus-4-6`) |
| `AGENTIC_DOCS_MAX_INPUT_TOKENS` | Total input token budget for the run |
| `AGENTIC_DOCS_MAX_OUTPUT_TOKENS` | Total output token budget for the run |

#### Optional

| Variable | Default | Description |
|----------|---------|-------------|
| `AGENTIC_DOCS_BASE_BRANCH` | `main` | Branch to diff against |
| `AGENTIC_DOCS_OUTPUT_DIR` | `docs` | Where to write generated files |
| `AGENTIC_DOCS_MEMORY_DIR` | `.agent/skills` | Skill memory directory |
| `AGENTIC_DOCS_MAX_TURNS` | `20` | Max agent loop turns (1–50) |
| `AGENTIC_DOCS_DOC_STYLE` | `detailed` | `concise`, `detailed`, or `enterprise` |
| `AGENTIC_DOCS_FRAMEWORKS` | `django,fastapi,flask` | Frameworks to extract API changes from |
| `AGENTIC_DOCS_NO_AUTO_COMMIT` | `false` | Set to `1` to skip auto-commit |
| `AGENTIC_DOCS_LANGUAGES` | (empty) | Comma-separated language hints |
| `AGENTIC_DOCS_CRITIC_MODEL` | (inherit) | Cheaper model for the critic pass |
| `AGENTIC_DOCS_EVALUATOR_MODEL` | (inherit) | Model for the DX evaluator pass |

#### Global memory (local mode)

| Variable | Description |
|----------|-------------|
| `VIDURA_GLOBAL_MEMORY_REPO` | Git repo URL for shared cross-project memory |
| `VIDURA_GLOBAL_MEMORY_TOKEN` | Git access token (PAT or GitHub App token) |
| `VIDURA_GLOBAL_MEMORY_BRANCH` | Branch (default: `main`) |

### readme-updater agent (prefix: `VIDURA_README`)

Same structure — replace `AGENTIC_DOCS_` with `VIDURA_README_`.

### Minimal local `.env`

```bash
ANTHROPIC_API_KEY=sk-ant-...
AGENTIC_DOCS_MODEL=claude-sonnet-4-6
AGENTIC_DOCS_MAX_INPUT_TOKENS=100000
AGENTIC_DOCS_MAX_OUTPUT_TOKENS=8192
```

---

## Token Control

Vidura enforces multiple layers of token control to prevent runaway costs.

### How token budgets work

```
SaaS mode:   platform sets max_input_tokens + max_output_tokens per org/agent config
Local mode:  AGENTIC_DOCS_MAX_INPUT_TOKENS + AGENTIC_DOCS_MAX_OUTPUT_TOKENS env vars
```

Both are **hard limits** — the agent loop aborts with exit code `1` if either is exceeded.

### Budget thresholds

| Threshold | Trigger | What happens |
|-----------|---------|--------------|
| **Every 5 turns** | Periodic | Agent receives exact token counts + percentage used — allows self-regulation |
| **85%** | Warning | Agent instructed to address only critical issues (missing endpoints, wrong methods) — skip style and suggestions |
| **95%** | Critical | All exploration locked. Agent must call `write_documentation` or `signal_no_change` immediately |
| **100%** | Hard stop | Loop aborts, `TOKEN_BUDGET_EXCEEDED` error returned |

### Adaptive tool sizing

As the token budget tightens, tool responses automatically shrink:

| Tool | Budget < 70% | Budget 70–85% | Budget > 85% |
|------|-------------|---------------|--------------|
| `read_file` max lines | 300 | 150 | 60 |
| `search_codebase` max results | 50 | 20 | 10 |

The agent still controls what it requests — but the hard cap shrinks, preventing large reads from burning the last tokens.

### Per-turn output cap

Each LLM call is capped at `min(8192, remaining_output_budget)` output tokens. This prevents a single turn from exhausting the entire output budget.

### Recommended token budgets

| Use case | `MAX_INPUT_TOKENS` | `MAX_OUTPUT_TOKENS` |
|----------|--------------------|---------------------|
| Small PR (< 5 files) | `40,000` | `4,000` |
| Medium PR (5–20 files) | `80,000` | `6,000` |
| Large PR (20+ files) | `150,000` | `8,192` |
| Maximum quality | `200,000` | `8,192` |

Set a cheaper model for the critic/evaluator passes to save tokens:

```bash
AGENTIC_DOCS_MODEL=claude-opus-4-6          # main agent — best quality
AGENTIC_DOCS_CRITIC_MODEL=claude-haiku-4-5  # critic — cheaper, fast
AGENTIC_DOCS_EVALUATOR_MODEL=claude-haiku-4-5
```

---

## Loop Control

Multiple mechanisms prevent agents from running indefinitely or getting stuck.

### Turn limit

```bash
AGENTIC_DOCS_MAX_TURNS=20   # default, range 1–50
```

If the agent hasn't called a terminal tool (`write_documentation` or `signal_no_change`) by the last turn, the run fails with `MAX_TURNS_EXCEEDED`.

### Plan revision cap

The agent can call `revise_plan` at most **3 times** per run. After 3 revisions the tool returns an error instructing the agent to execute the current plan rather than keep replanning.

### Repetitive call detection

If the agent calls the same tool with identical arguments **3 times in a row**, a `[SYSTEM]` message is injected:

```
[SYSTEM] You have called `read_file` with identical arguments 3 times in a row.
This is not producing new information. Move to the next step in your plan.
If you cannot proceed, call `signal_no_change`.
```

This catches loops like repeatedly reading the same file or running the same search.

### Stall detection

If **12 turns pass without a `store_draft` call** (and there are changes to document), a push message is injected forcing the agent to write:

```
[SYSTEM] 12 turns have passed without a draft.
You must call `store_draft` immediately with whatever documentation you have,
or `signal_no_change` if there is nothing to document. Do not explore further.
```

### Quality loop cap

The critic/evaluator loop is capped at **2 iterations**. After 2 critique cycles the agent must proceed to validation and writing regardless of the score, preventing infinite polish loops.

### Summary of loop limits

| Mechanism | Limit | Behaviour on trigger |
|-----------|-------|----------------------|
| Max turns | 20 (configurable) | Hard abort, `MAX_TURNS_EXCEEDED` |
| Plan revisions | 3 | Tool returns error, agent must proceed |
| Repetitive calls | 3 consecutive identical | `[SYSTEM]` warning injected |
| Stall (no draft) | 12 turns | `[SYSTEM]` push to write injected |
| Critique loop | 2 cycles | Agent must proceed regardless of score |
| Critical budget | 95% | Locks all tools except terminal ones |

---

## CLI Reference

### `vidura run --agent <name>`

```bash
# SaaS mode
vidura run --agent doc-gen \
  --config-url $VIDURA_CONFIG_URL \
  --token $VIDURA_TOKEN

# Local mode
vidura run --agent doc-gen --verbose

# Dry run — prints changed files without calling LLM
vidura run --agent doc-gen --dry-run

# Override branch / skip auto-commit
vidura run --agent doc-gen --base-branch development --no-commit

# Write output JSON to file
vidura run --agent doc-gen --output-file output.json
```

| Flag | Description |
|------|-------------|
| `--agent` | **Required.** Agent name (`doc-gen`, `readme-updater`) |
| `--config-url` | SaaS platform config endpoint URL |
| `--token` | SaaS install token |
| `--base-branch` | Override the base branch to diff against |
| `--no-commit` | Skip auto-commit after generating output |
| `--dry-run` | Show changed files and exit — no LLM calls |
| `--output-file` | Write `AgentOutput` JSON to this path |
| `--callback-url` | POST `AgentOutput` JSON to this URL |
| `-v, --verbose` | Enable debug logging |

### `vidura init --agent <name>`

Initialise an agent for the current repo. Creates `skills/` (copies bundled skill files), `.agent/skills/` (memory files), and the output directory.

```bash
vidura init --agent doc-gen
vidura init --agent readme-updater
```

### `vidura sync --agent <name>`

Pull the latest skill files from the platform and update local copies. Skips files you have modified locally (warns instead).

```bash
vidura sync --agent doc-gen \
  --config-url $VIDURA_CONFIG_URL \
  --token $VIDURA_TOKEN
```

### `vidura doctor`

Check that your environment is correctly set up.

```bash
vidura doctor
# ✓ Python 3.11
# ✓ anthropic installed
# ✓ ANTHROPIC_API_KEY set
# ✓ agent.yaml found for doc-gen
# ✓ skills/ directory exists (7 files)
# ✓ .agent/skills/ directory exists
# ✓ Platform reachable (200)
```

### `vidura agents list`

```bash
vidura agents list
#   doc-gen              API documentation generation agent
#   readme-updater       Detects config/setup changes and updates README.md
```

### `vidura run-pipeline`

Run multiple agents sequentially.

```bash
vidura run-pipeline doc-gen readme-updater \
  --config-url $VIDURA_CONFIG_URL \
  --token $VIDURA_TOKEN

# Continue even if one agent fails
vidura run-pipeline doc-gen readme-updater --continue-on-failure
```

### Exit codes

| Code | Meaning |
|------|---------|
| `0` | Success — output generated or no changes detected |
| `1` | Failure — validation failed, token budget exceeded, max turns exceeded, API error |

---

## Agent Manifest (`agent.yaml`)

Every agent is defined by an `agent.yaml` manifest.

```yaml
name: doc-gen
version: "0.1.0"
description: "API documentation generation agent"
output_type: file_commit    # file_commit | pull_request | review | issue | check_status | report

skills:
  primary: primary-agent.md       # Main agent system prompt
  secondary:
    critic: critic.md             # Quality reviewer (single-shot)
    evaluator: evaluator.md       # DX evaluator (single-shot)
  validator: validator.md         # Declarative rules (no LLM)
  styles:
    concise: style-concise.md
    detailed: style-detailed.md
    enterprise: style-enterprise.md

tools:
  core:                           # Always-available generic tools
    - read_file
    - search_codebase
    - create_plan
    - store_draft
    - get_changed_files
  agent_specific:                 # Python module with custom tools
    - agents.doc_gen.tools
  exploration_only:               # Gated until store_draft is called
    - critique_documentation
    - validate_documentation
    - write_documentation

memory:
  local_files:                    # Per-project memory, stored in .agent/skills/
    master: agentic-system-master.md
    api: api-patterns.md
  global_files:                   # Shared across projects (Git repo)
    common-patterns: common-patterns.md
  categories:
    api: api-patterns.md
    general: agentic-system-master.md

workflow:
  initial_message_template: >
    Analyze branch '{branch}' against '{base_branch}'.
    Explore changes, extract API modifications, generate documentation.
  terminal_tools:                 # Tools that end the agent loop
    - write_documentation
    - signal_no_change
  progressive_gate_field: _current_draft   # gate_field must be truthy to unlock exploration_only tools
  budget_warning_message: >
    Wrap up now. Fix only critical issues. Call validate_documentation then write_documentation.

config:
  env_prefix: AGENTIC_DOCS
  user_configurable:              # Fields users may override via SaaS preferences
    - doc_style
    - output_dir
    - base_branch
  extra_fields:
    doc_style:
      type: string
      default: detailed
      env_key: DOC_STYLE
```

---

## Skill Files (`skills/*.md`)

Agent behavior lives in markdown files, not Python code.

### Skill types

| Type | Execution | Description |
|------|-----------|-------------|
| `agent` | Multi-turn tool loop | Main agent — plans, explores, drafts, revises |
| `single-shot` | One LLM call | Critic, evaluator — returns structured JSON |
| `rules` | No LLM | Declarative validation — pattern matching only |

### Customising behavior

Edit the `.md` files in `skills/`. No Python changes needed.

```bash
# After vidura init, your skills/ directory contains editable copies:
skills/
├── primary-agent.md    ← edit to change agent behavior
├── critic.md           ← edit quality scoring rubrics
├── validator.md        ← edit declarative validation rules
└── style-detailed.md   ← edit documentation style instructions
```

To receive platform updates while keeping your changes:

```bash
vidura sync --agent doc-gen --config-url $URL --token $TOKEN
# Files you modified locally are skipped (warned, not overwritten)
```

---

## Output Types

Vidura produces structured JSON (`AgentOutput`) that is VCS-agnostic:

```json
{
  "agent": "doc-gen",
  "status": "completed",
  "output_type": "file_commit",
  "metadata": {
    "run_id": "uuid",
    "branch": "feature/auth",
    "base_branch": "main",
    "tokens_used": {"inputTokens": 12000, "outputTokens": 3000},
    "duration_ms": 45000
  },
  "result": {
    "files": [
      {"path": "docs/auth-api-docs.md"},
      {"path": "docs/auth-api-docs.docx"}
    ]
  }
}
```

| Output Type | Agent produces | Platform translates to |
|-------------|---------------|----------------------|
| `file_commit` | `{files: [{path, content}]}` | Git commit via VCS API |
| `review` | `{summary, items: [{file, line, message}], verdict}` | PR/MR review comments |
| `issue` | `{title, body, labels}` | New issue on VCS |
| `check_status` | `{status: pass/fail, summary}` | Pipeline/check status |
| `pull_request` | `{branch, title, body, files}` | New PR/MR |
| `report` | `{sections: [{title, body}]}` | Dashboard display |

---

## Architecture

### Core runtime

| Module | Role |
|--------|------|
| `core/workflow.py` | Manifest-driven workflow engine — loads skills, runs agent loop, enforces token + loop limits |
| `core/tools/executor.py` | Stateful tool dispatcher — core tools + agent-specific handlers, token-aware sizing |
| `core/config.py` | Config from env vars or SaaS API (credential + memory token fetched separately) |
| `core/memory.py` | Two-tier skill memory — local `.agent/skills/` + optional global Git repo |
| `core/skill_loader.py` | Parses `.md` frontmatter into `SkillDefinition` |
| `core/skill_runner.py` | Executes skills — multi-turn agent, single-shot LLM, or rules engine |
| `core/errors.py` | Typed error codes (`TOKEN_BUDGET_EXCEEDED`, `MAX_TURNS_EXCEEDED`, etc.) |
| `core/retry.py` | Exponential backoff for transient LLM/platform errors |
| `core/progress.py` | Fire-and-forget progress reporting to platform |
| `core/sync.py` | SHA-256 checksum tracking for safe skill file updates |
| `core/git.py` | Git diff analysis (`merge-base` + `diff --name-status`) |
| `core/llm/` | Provider abstraction: Anthropic + OpenAI-compatible |
| `core/storage/` | Memory store: local filesystem + Git repo backends |

### Memory system

Two-tier persistent memory:

- **Local** (per-project): stored in `.agent/skills/`, committed to git. Tracks API patterns, auth patterns, versioning conventions for this repo.
- **Global** (shared): stored in a private Git repo, shared across all projects in the org. Tracks cross-project patterns, style guides, feedback.

Memory files auto-prune at 8,000 chars — older entries are trimmed, keeping the most recent 60%.

---

## Project Structure

```
vidura/
├── bin/
│   └── cli.py                          # CLI entry point
├── core/
│   ├── workflow.py                     # Agent loop + token/loop controls
│   ├── tools/
│   │   ├── executor.py                 # Tool dispatcher (token-aware sizing)
│   │   ├── core_tools.py              # Generic tool definitions
│   │   └── handler.py                 # AgentToolHandler protocol
│   ├── config.py                       # Config from env or SaaS API
│   ├── memory.py                       # Two-tier memory manager
│   ├── errors.py                       # Typed error codes + exceptions
│   ├── retry.py                        # Exponential backoff
│   ├── progress.py                     # Progress reporting
│   ├── sync.py                         # Skill file checksum tracking
│   ├── git.py                          # Git diff analysis
│   ├── llm/
│   │   ├── base.py                     # LLMProvider ABC
│   │   ├── anthropic_provider.py       # Anthropic Claude
│   │   └── factory.py                  # Provider factory
│   └── storage/
│       ├── local_store.py              # Filesystem memory backend
│       └── git_store.py               # Git repo memory backend
├── agents/
│   ├── doc_gen/
│   │   ├── agent.yaml                  # Manifest
│   │   ├── tools.py                    # Custom tool handler
│   │   ├── document.py                 # Markdown + DOCX generation
│   │   └── skills/
│   │       ├── primary-agent.md        # Main agent (grounding, efficiency, loop rules)
│   │       ├── critic.md               # Quality critic
│   │       ├── evaluator.md            # DX evaluator
│   │       ├── validator.md            # Declarative validation rules
│   │       └── style-{concise,detailed,enterprise}.md
│   └── readme_updater/
│       ├── agent.yaml
│       └── skills/primary-agent.md
└── pyproject.toml
```

---

## Development

```bash
pip install -e "."

# Run in development
python -m bin.cli run --agent doc-gen --verbose

# Dry run (no LLM calls)
python -m bin.cli run --agent doc-gen --dry-run

# Build distribution
pip install build && python -m build
```

---

## Requirements

- Python >= 3.10
- Git (must be run inside a git repository)
- `ANTHROPIC_API_KEY` (local mode) or a Vidura install token + config URL (SaaS mode)

---

## License

MIT
