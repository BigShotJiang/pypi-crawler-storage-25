"""Agent manifest loader — reads agent.yaml and returns an AgentManifest."""

from __future__ import annotations

import importlib
from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, Field


# ── Manifest sub-models ──────────────────────────────────────────────────────


class SkillsManifest(BaseModel):
    primary: str
    secondary: dict[str, str] = Field(default_factory=dict)
    validator: str | None = None
    styles: dict[str, str] = Field(default_factory=dict)


class ToolsManifest(BaseModel):
    core: list[str] = Field(default_factory=lambda: [
        "read_file", "search_codebase", "create_plan", "revise_plan",
        "read_memory", "search_memory", "store_memory", "get_changed_files",
    ])
    agent_specific: list[str] = Field(default_factory=list)
    exploration_only: list[str] = Field(default_factory=list)


class MemoryManifest(BaseModel):
    local_files: dict[str, str] = Field(default_factory=dict)
    local_initial_content: dict[str, str] = Field(default_factory=dict)
    global_files: dict[str, str] = Field(default_factory=dict)
    global_initial_content: dict[str, str] = Field(default_factory=dict)
    categories: dict[str, str] = Field(default_factory=dict)


class WorkflowManifest(BaseModel):
    initial_message_template: str = "Analyze branch '{branch}' against '{base_branch}'."
    terminal_tools: list[str] = Field(default_factory=lambda: ["write_output", "signal_no_change"])
    progressive_gate_field: str | None = None
    budget_warning_message: str = "Token budget nearly exhausted. Wrap up now."


class ConfigManifest(BaseModel):
    env_prefix: str = "VIDURA"
    extra_fields: dict[str, dict[str, Any]] = Field(default_factory=dict)
    # Fields users are allowed to pass via --set (or the platform's user_preferences block).
    # Everything NOT in this list is platform-controlled and cannot be overridden by the user.
    user_configurable: list[str] = Field(default_factory=list)


# ── Top-level manifest ───────────────────────────────────────────────────────


class AgentManifest(BaseModel):
    name: str
    version: str = "0.1.0"
    description: str = ""
    output_type: str = "file_commit"

    skills: SkillsManifest
    tools: ToolsManifest = Field(default_factory=ToolsManifest)
    memory: MemoryManifest = Field(default_factory=MemoryManifest)
    workflow: WorkflowManifest = Field(default_factory=WorkflowManifest)
    config: ConfigManifest = Field(default_factory=ConfigManifest)


# ── Loader ───────────────────────────────────────────────────────────────────


def load_manifest(path: Path) -> AgentManifest:
    """Load an agent manifest from a YAML file."""
    if not path.exists():
        raise FileNotFoundError(f"Agent manifest not found: {path}")

    raw = path.read_text(encoding="utf-8")
    data = yaml.safe_load(raw)
    if not isinstance(data, dict):
        raise ValueError(f"Invalid manifest format in {path}")

    return AgentManifest(**data)


def resolve_agent_dir(agent_name: str) -> Path:
    """Resolve the directory for a bundled agent.

    Looks for agents/{agent_name}/ relative to the package root.
    Agent names use hyphens in CLI but underscores in directory names.
    """
    dir_name = agent_name.replace("-", "_")

    # Check relative to the package (installed via pip)
    package_root = Path(__file__).resolve().parent.parent
    agent_dir = package_root / "agents" / dir_name

    if agent_dir.exists():
        return agent_dir

    raise FileNotFoundError(
        f"Agent '{agent_name}' not found. Looked in: {agent_dir}\n"
        f"Available agents: {list_agents()}"
    )


def list_agents() -> list[str]:
    """List all bundled agent names."""
    package_root = Path(__file__).resolve().parent.parent
    agents_dir = package_root / "agents"

    if not agents_dir.exists():
        return []

    agents = []
    for child in sorted(agents_dir.iterdir()):
        if child.is_dir() and (child / "agent.yaml").exists():
            agents.append(child.name.replace("_", "-"))

    return agents


def load_agent_tool_handler(module_path: str):
    """Dynamically import an agent-specific tool handler module.

    The module must export:
      - TOOL_DEFINITIONS: list[dict]
      - ToolHandler: class with handle(tool_name, tool_input) -> ToolResult
    """
    try:
        return importlib.import_module(module_path)
    except ImportError as err:
        raise ImportError(
            f"Failed to load agent tool module '{module_path}': {err}"
        ) from err
