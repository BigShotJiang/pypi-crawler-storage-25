"""Exponential backoff retry for transient failures.

Used for LLM API calls (rate limits, server errors) and platform HTTP calls.
"""

from __future__ import annotations

import asyncio
import time
from typing import Callable, TypeVar

from core.logger import logger

T = TypeVar("T")

# HTTP status codes that are safe to retry
_RETRYABLE_STATUS = {429, 500, 502, 503, 529}

# How long to wait on a 429 — Anthropic TPM windows reset every 60s.
# Normal exponential backoff (1s, 2s) does nothing against a per-minute limit.
_RATE_LIMIT_WAIT = 62

# Keywords in exception messages that indicate a retryable condition
_RETRYABLE_KEYWORDS = (
    "rate limit", "too many requests", "overloaded",
    "server error", "internal server", "service unavailable",
    "connection", "timeout", "timed out",
)

_NON_RETRYABLE_KEYWORDS = (
    "authentication", "api key", "invalid key", "unauthorized",
    "forbidden", "not found", "bad request",
)


def _is_retryable(err: Exception) -> bool:
    msg = str(err).lower()
    if any(kw in msg for kw in _NON_RETRYABLE_KEYWORDS):
        return False
    for code in _RETRYABLE_STATUS:
        if str(code) in msg:
            return True
    return any(kw in msg for kw in _RETRYABLE_KEYWORDS)


def _is_rate_limit(err: Exception) -> bool:
    msg = str(err).lower()
    return "429" in msg or "rate_limit_error" in msg or "rate limit" in msg


def retry_sync(
    fn: Callable[[], T],
    max_attempts: int = 3,
    base_delay: float = 1.0,
    label: str = "",
) -> T:
    """Call fn() with exponential backoff. Raises on final failure."""
    last_err: Exception | None = None
    for attempt in range(1, max_attempts + 1):
        try:
            return fn()
        except Exception as err:
            last_err = err
            if not _is_retryable(err) or attempt == max_attempts:
                raise
            delay = _RATE_LIMIT_WAIT if _is_rate_limit(err) else base_delay * (2 ** (attempt - 1))
            logger.warn(
                f"{'[' + label + '] ' if label else ''}Transient error (attempt {attempt}/{max_attempts}): "
                f"{err}. Retrying in {delay:.1f}s..."
            )
            time.sleep(delay)
    raise last_err  # type: ignore[misc]


async def retry_async(
    fn: Callable[[], "asyncio.coroutine[T]"],  # type: ignore[type-arg]
    max_attempts: int = 3,
    base_delay: float = 1.0,
    label: str = "",
) -> T:
    """Async version of retry_sync."""
    last_err: Exception | None = None
    for attempt in range(1, max_attempts + 1):
        try:
            return await fn()  # type: ignore[misc]
        except Exception as err:
            last_err = err
            if not _is_retryable(err) or attempt == max_attempts:
                raise
            delay = _RATE_LIMIT_WAIT if _is_rate_limit(err) else base_delay * (2 ** (attempt - 1))
            logger.warn(
                f"{'[' + label + '] ' if label else ''}Transient error (attempt {attempt}/{max_attempts}): "
                f"{err}. Retrying in {delay:.1f}s..."
            )
            await asyncio.sleep(delay)
    raise last_err  # type: ignore[misc]