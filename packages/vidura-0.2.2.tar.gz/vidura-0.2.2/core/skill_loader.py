"""Skill loader — parses .md files with YAML frontmatter into SkillDefinition objects."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

import yaml

SkillType = Literal["agent", "single-shot", "rules"]


@dataclass
class SkillDefinition:
    """Parsed skill from a markdown file with YAML frontmatter."""

    name: str
    type: SkillType
    description: str = ""
    max_turns: int = 1
    tools: list[str] = field(default_factory=list)
    output_format: str | None = None  # "json" | "markdown" | None
    provider: str | None = None  # None = inherit from primary
    model: str | None = None  # None = inherit from primary
    body: str = ""  # The markdown body (system prompt / rules)

    # For rules-type skills: parsed rule definitions
    rules: list[dict] = field(default_factory=list)


_FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.DOTALL)


def load_skill(path: Path) -> SkillDefinition:
    """Load a skill definition from a markdown file with YAML frontmatter."""
    raw = path.read_text(encoding="utf-8")
    return parse_skill(raw)


def parse_skill(raw: str) -> SkillDefinition:
    """Parse raw markdown+frontmatter into a SkillDefinition."""
    match = _FRONTMATTER_RE.match(raw)
    if not match:
        raise ValueError("Skill file must start with YAML frontmatter (--- ... ---)")

    frontmatter = yaml.safe_load(match.group(1)) or {}
    body = raw[match.end():].strip()

    name = frontmatter.get("name", "unnamed")
    skill_type = frontmatter.get("type", "single-shot")
    if skill_type not in ("agent", "single-shot", "rules"):
        raise ValueError(f"Invalid skill type: {skill_type}. Must be agent, single-shot, or rules")

    skill = SkillDefinition(
        name=name,
        type=skill_type,
        description=frontmatter.get("description", ""),
        max_turns=frontmatter.get("max_turns", 20 if skill_type == "agent" else 1),
        tools=frontmatter.get("tools", []),
        output_format=frontmatter.get("output_format"),
        provider=frontmatter.get("provider"),
        model=frontmatter.get("model"),
        body=body,
    )

    # For rules-type skills, parse the rule blocks from the body
    if skill.type == "rules":
        skill.rules = _parse_rules(body)

    return skill


def _parse_rules(body: str) -> list[dict]:
    """Parse declarative validation rules from the skill body.

    Rules are defined as YAML blocks under ## Rules:
    - id: rule_name
      severity: error|warning
      check: contains|regex_absent|http_methods|endpoints_in_delta|delta_coverage
      ...
    """
    # Find the ## Rules section
    rules_match = re.search(r"^## Rules\s*\n(.*?)(?=^## |\Z)", body, re.MULTILINE | re.DOTALL)
    if not rules_match:
        return []

    rules_text = rules_match.group(1).strip()

    # Split on "- id:" to get individual rule blocks
    rule_blocks = re.split(r"(?=^- id:)", rules_text, flags=re.MULTILINE)
    rules = []

    for block in rule_blocks:
        block = block.strip()
        if not block:
            continue

        # Parse the YAML-like block (it's a single list item)
        try:
            parsed = yaml.safe_load(block)
            if isinstance(parsed, list) and parsed:
                rules.append(parsed[0])
            elif isinstance(parsed, dict):
                rules.append(parsed)
        except yaml.YAMLError:
            continue

    return rules


def load_skills_from_dir(skills_dir: Path) -> dict[str, SkillDefinition]:
    """Load all agent/rules skill files from a directory.

    Only loads files that have valid YAML frontmatter with a type field.
    Skips memory files (those without frontmatter).
    """
    skills: dict[str, SkillDefinition] = {}

    if not skills_dir.exists():
        return skills

    for md_file in skills_dir.glob("*.md"):
        try:
            raw = md_file.read_text(encoding="utf-8")
            if not _FRONTMATTER_RE.match(raw):
                continue  # Skip memory files (no frontmatter)
            skill = parse_skill(raw)
            skills[skill.name] = skill
        except (ValueError, yaml.YAMLError):
            continue

    return skills
