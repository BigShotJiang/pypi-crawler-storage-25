"""Structured error codes for agent runs.

All errors that can occur during a run are classified here so the SaaS
platform can surface the right fix to the user without parsing free-form
error strings.
"""

from __future__ import annotations


# ── Error code constants ──────────────────────────────────────────────────────

# Platform / auth
TOKEN_INVALID       = "TOKEN_INVALID"        # 401 from platform
NOT_ENTITLED        = "NOT_ENTITLED"         # 403 — org plan doesn't include this agent
AGENT_NOT_FOUND     = "AGENT_NOT_FOUND"      # 404 — unknown agent name
PLATFORM_ERROR      = "PLATFORM_ERROR"       # 5xx from platform
PLATFORM_UNREACHABLE = "PLATFORM_UNREACHABLE" # network error reaching platform
CREDENTIALS_MISSING = "CREDENTIALS_MISSING"  # platform gave no API key

# LLM
LLM_AUTH_ERROR      = "LLM_AUTH_ERROR"       # bad API key
LLM_RATE_LIMIT      = "LLM_RATE_LIMIT"       # 429 — quota exceeded with LLM provider
LLM_SERVER_ERROR    = "LLM_SERVER_ERROR"     # 5xx from LLM API
LLM_API_ERROR       = "LLM_API_ERROR"        # other LLM API error

# Agent
QUOTA_EXCEEDED      = "QUOTA_EXCEEDED"       # org token budget exhausted
TOKEN_BUDGET_EXCEEDED = "TOKEN_BUDGET_EXCEEDED" # per-run token budget exhausted
VALIDATION_FAILED   = "VALIDATION_FAILED"    # documentation failed validation rules
MAX_TURNS_EXCEEDED  = "MAX_TURNS_EXCEEDED"   # agent loop hit turn limit
AGENT_LOGIC_ERROR   = "AGENT_LOGIC_ERROR"    # agent ended without terminal tool

# Setup
SKILLS_MISSING      = "SKILLS_MISSING"       # required skill file not found
CONFIG_ERROR        = "CONFIG_ERROR"         # bad / missing configuration

# Normal exits
NO_CHANGES          = "NO_CHANGES"           # agent signalled no actionable changes
SUCCESS             = "SUCCESS"              # run completed successfully

# Fallback
UNKNOWN_ERROR       = "UNKNOWN_ERROR"


# ── Typed exceptions ──────────────────────────────────────────────────────────

class ViduraError(Exception):
    """Base exception — all vidura errors carry an error_code."""

    def __init__(self, message: str, code: str = UNKNOWN_ERROR) -> None:
        super().__init__(message)
        self.code = code


class PlatformError(ViduraError):
    """Raised when the SaaS platform returns an error or is unreachable."""


class EntitlementError(PlatformError):
    """Raised when the org's plan does not include the requested agent."""

    def __init__(self, agent: str) -> None:
        super().__init__(
            f"Your plan does not include the '{agent}' agent. "
            "Upgrade your Vidura plan to access it.",
            code=NOT_ENTITLED,
        )


class CredentialError(PlatformError):
    """Raised when the platform fails to deliver API credentials."""


class LLMError(ViduraError):
    """Raised for LLM API errors (rate limits, auth, server errors)."""


class SkillsMissingError(ViduraError):
    """Raised when a required skill file is not present."""

    def __init__(self, path: str) -> None:
        super().__init__(
            f"Required skill file not found: {path}\n"
            "Run 'vidura init --agent <name>' to create skill files.",
            code=SKILLS_MISSING,
        )


def classify_llm_error(err: Exception) -> str:
    """Map an LLM SDK exception to an error code."""
    msg = str(err).lower()
    if "401" in msg or "authentication" in msg or "api key" in msg:
        return LLM_AUTH_ERROR
    if "429" in msg or "rate limit" in msg or "too many requests" in msg:
        return LLM_RATE_LIMIT
    if any(code in msg for code in ("500", "502", "503", "529")):
        return LLM_SERVER_ERROR
    return LLM_API_ERROR
