"""Anthropic Claude provider implementation."""

from __future__ import annotations

from typing import Any

from core.llm.base import LLMProvider, LLMResponse, TokenUsage, ToolCall, ToolCallResult
from core.logger import logger


class AnthropicProvider(LLMProvider):
    """LLM provider backed by Anthropic's Claude API."""

    def __init__(self, api_key: str, model: str) -> None:
        try:
            import anthropic
        except ImportError:
            raise ImportError(
                "anthropic package is required for the Anthropic provider. "
                "Install with: pip install agentic-docs[anthropic]"
            )

        self.client = anthropic.Anthropic(api_key=api_key)
        self.model = model

    def chat(
        self,
        system: str,
        messages: list,
        tools: list[dict] | None = None,
        max_tokens: int = 8192,
    ) -> LLMResponse:
        # Use structured system with cache_control for prompt caching
        kwargs: dict[str, Any] = {
            "model": self.model,
            "max_tokens": max_tokens,
            "system": [
                {
                    "type": "text",
                    "text": system,
                    "cache_control": {"type": "ephemeral"},
                }
            ],
            "messages": messages,
        }
        if tools:
            # Clone tools and add cache_control to the last one to cache the entire tool block
            cached_tools = [t.copy() for t in tools]
            cached_tools[-1] = {**cached_tools[-1], "cache_control": {"type": "ephemeral"}}
            kwargs["tools"] = cached_tools

        response = self.client.messages.create(**kwargs)

        # Log cache performance for debugging token optimization
        usage = response.usage
        cache_creation = getattr(usage, "cache_creation_input_tokens", 0) or 0
        cache_read = getattr(usage, "cache_read_input_tokens", 0) or 0
        if cache_creation or cache_read:
            logger.debug(
                f"Anthropic cache — created: {cache_creation}, read: {cache_read}, "
                f"non-cached input: {usage.input_tokens}"
            )

        text_parts = [b.text for b in response.content if b.type == "text"]
        text = "\n".join(text_parts)

        tool_calls = [
            ToolCall(
                id=b.id,
                name=b.name,
                input=b.input if isinstance(b.input, dict) else {},
            )
            for b in response.content
            if b.type == "tool_use"
        ]

        return LLMResponse(
            content=text,
            stop_reason=response.stop_reason,
            tool_calls=tool_calls,
            usage=TokenUsage(
                input_tokens=response.usage.input_tokens,
                output_tokens=response.usage.output_tokens,
            ),
            _raw=response.content,
        )

    def build_assistant_message(self, response: LLMResponse) -> dict:
        return {"role": "assistant", "content": response._raw}

    def build_tool_result_messages(self, results: list[ToolCallResult]) -> list:
        return [
            {
                "role": "user",
                "content": [
                    {
                        "type": "tool_result",
                        "tool_use_id": r.tool_call_id,
                        "content": r.content,
                    }
                    for r in results
                ],
            }
        ]

    def get_tool_definitions(self, canonical_tools: list[dict]) -> list:
        return canonical_tools
