"""Shared extraction types used by core and agent plugins."""
