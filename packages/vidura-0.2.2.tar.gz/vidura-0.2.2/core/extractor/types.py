"""Canonical types for the extraction layer (L2). No LLM allowed here."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal, Protocol

# ─── Primitive building blocks ───────────────────────────────────────────────


@dataclass
class SchemaField:
    name: str
    type: str
    required: bool
    description: str | None = None


@dataclass
class PathParam:
    name: str
    type: str


@dataclass
class QueryParam:
    name: str
    type: str
    required: bool


@dataclass
class AuthRequirement:
    type: Literal["none", "bearer", "api-key", "basic", "oauth2"]
    scopes: list[str] | None = None


# ─── Endpoint representation ─────────────────────────────────────────────────

HttpMethod = Literal["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"]


@dataclass
class ApiEndpoint:
    method: HttpMethod
    path: str
    handler: str | None = None
    request_schema: list[SchemaField] | None = None
    response_schema: list[SchemaField] | None = None
    auth: AuthRequirement | None = None
    params: list[PathParam] | None = None
    query: list[QueryParam] | None = None
    tags: list[str] | None = None


# ─── Change representations ───────────────────────────────────────────────────

ModificationKind = Literal["request-schema", "response-schema", "auth", "path", "method"]


@dataclass
class ModifiedEndpoint:
    before: ApiEndpoint
    after: ApiEndpoint
    change_type: ModificationKind


@dataclass
class ContractChange:
    endpoint: str
    change_type: Literal["breaking", "non-breaking", "new", "removed"]
    description: str
    field: str | None = None


@dataclass
class AuthChange:
    file: str
    type: Literal["added", "removed", "modified"]
    description: str


@dataclass
class VersioningChange:
    type: Literal["major", "minor", "patch"]
    description: str
    from_version: str | None = None
    to_version: str | None = None


# ─── The canonical output of L2 ──────────────────────────────────────────────


@dataclass
class ExtractedApiDelta:
    feature: str
    branch: str
    base_branch: str
    timestamp: str
    new: list[ApiEndpoint] = field(default_factory=list)
    modified: list[ModifiedEndpoint] = field(default_factory=list)
    removed: list[ApiEndpoint] = field(default_factory=list)
    contract_changes: list[ContractChange] = field(default_factory=list)
    auth_changes: list[AuthChange] = field(default_factory=list)
    versioning_changes: list[VersioningChange] = field(default_factory=list)


# ─── Input to extractors ─────────────────────────────────────────────────────


@dataclass
class ChangedFile:
    path: str
    status: Literal["added", "modified", "deleted"]
    diff: str
    content: str | None = None


Framework = Literal["django", "fastapi", "flask", "unknown"]


class FrameworkExtractor(Protocol):
    """Protocol that all framework extractors must implement."""

    def detect(self, files: list[ChangedFile]) -> list[ChangedFile]:
        """Return only the files that this extractor handles."""
        ...

    def extract(self, file: ChangedFile, full_content: str) -> dict:
        """Extract API changes from a single file. Returns partial delta as dict."""
        ...
