"""Core tool definitions — always available to every agent.

These are generic tools that any agent can use: file reading, codebase search,
planning, memory, and draft storage.
"""

CORE_TOOL_DEFINITIONS: list[dict] = [
    {
        "name": "get_changed_files",
        "description": (
            "Get files changed between the current branch and the base branch. "
            "Returns a list of changed files with their status and a short diff preview. "
            "Always call this first before any other tool."
        ),
        "input_schema": {
            "type": "object",
            "properties": {},
            "required": [],
        },
    },
    {
        "name": "read_file",
        "description": (
            "Read an arbitrary file from the repository for additional context. "
            "Use this to explore source code beyond the diff when you need to understand "
            "how something works, what types are used, or how logic is structured."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Relative path from the repo root (e.g. 'src/routes/users.ts')",
                },
                "offset": {
                    "type": "integer",
                    "description": "Line offset to start reading from (0-based, default 0)",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum number of lines to return (default 100, max 300)",
                },
            },
            "required": ["path"],
        },
    },
    {
        "name": "search_codebase",
        "description": (
            "Search the repository codebase using a regex pattern. "
            "Returns matching lines with file paths and line numbers. "
            "Use this to find usages, imports, type definitions, or related code."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "pattern": {
                    "type": "string",
                    "description": "Regex pattern to search for",
                },
                "glob": {
                    "type": "string",
                    "description": "Optional glob filter for file paths (e.g. '*.py', 'src/**/*.ts')",
                },
                "maxResults": {
                    "type": "integer",
                    "description": "Maximum number of matching lines to return (default 20, max 50)",
                },
            },
            "required": ["pattern"],
        },
    },
    {
        "name": "create_plan",
        "description": (
            "Create a goal-oriented plan for the task. "
            "Formulate a high-level goal and ordered steps. "
            "Call this early to structure your approach. You can revise later."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "goal": {
                    "type": "string",
                    "description": "The high-level goal for this run",
                },
                "steps": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Ordered list of steps to achieve the goal",
                },
            },
            "required": ["goal", "steps"],
        },
    },
    {
        "name": "revise_plan",
        "description": (
            "Revise the current plan mid-execution. "
            "Use this when you discover new information that changes the approach."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "reason": {
                    "type": "string",
                    "description": "Why the plan needs to change",
                },
                "updatedSteps": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "The revised ordered list of steps",
                },
            },
            "required": ["reason", "updatedSteps"],
        },
    },
    {
        "name": "read_memory",
        "description": (
            "Read a skill memory file. "
            "These contain patterns and conventions learned from previous runs."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "skill": {
                    "type": "string",
                    "description": "Skill file key to read (check available keys from agent context)",
                },
                "scope": {
                    "type": "string",
                    "enum": ["project", "global"],
                    "description": "Memory scope (default: project)",
                },
            },
            "required": ["skill"],
        },
    },
    {
        "name": "search_memory",
        "description": (
            "Search across skill memory files using keywords. "
            "Returns ranked sections matching the query. "
            "Set scope to 'all' to search both project and global memory."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Keywords to search for in skill memory",
                },
                "maxResults": {
                    "type": "integer",
                    "description": "Maximum number of sections to return (default 5)",
                },
                "scope": {
                    "type": "string",
                    "enum": ["project", "global", "all"],
                    "description": "Which memory scope to search (default: all)",
                },
            },
            "required": ["query"],
        },
    },
    {
        "name": "store_memory",
        "description": (
            "Store a new insight or pattern in skill memory for future runs. "
            "Use scope 'project' for repo-specific patterns. "
            "Use scope 'global' for cross-project insights."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "category": {
                    "type": "string",
                    "description": "Which category to store under (agent-specific categories)",
                },
                "content": {
                    "type": "string",
                    "description": "The insight or pattern to remember",
                },
                "title": {
                    "type": "string",
                    "description": "Short title for this memory entry",
                },
                "scope": {
                    "type": "string",
                    "enum": ["project", "global"],
                    "description": "Where to store: project (local repo) or global (shared across projects)",
                },
            },
            "required": ["category", "content", "title"],
        },
    },
    {
        "name": "store_draft",
        "description": (
            "Store your draft output for use by quality and writing tools. "
            "Call this once with your full draft. Subsequent calls to downstream tools "
            "will automatically use the stored draft. Call again to update after revisions."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "documentation": {
                    "type": "string",
                    "description": "The full draft content",
                },
            },
            "required": ["documentation"],
        },
    },
    {
        "name": "signal_no_change",
        "description": (
            "Signal that no actionable changes were found and no output is needed. "
            "This is a TERMINAL action — the agent loop exits after this call."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "reason": {
                    "type": "string",
                    "description": "Brief explanation of why no changes were found",
                },
            },
            "required": ["reason"],
        },
    },
]


def get_core_tools_by_names(names: list[str]) -> list[dict]:
    """Return core tool definitions filtered by the given names."""
    name_set = set(names)
    return [t for t in CORE_TOOL_DEFINITIONS if t["name"] in name_set]


def build_tool_set(
    core_tools: list[dict],
    agent_tools: list[dict],
    exclude: set[str] | None = None,
) -> list[dict]:
    """Combine core and agent tools, optionally excluding some."""
    all_tools = core_tools + agent_tools
    if exclude:
        return [t for t in all_tools if t["name"] not in exclude]
    return all_tools
