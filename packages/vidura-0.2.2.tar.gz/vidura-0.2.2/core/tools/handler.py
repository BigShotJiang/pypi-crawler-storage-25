"""Agent tool handler protocol — the contract for agent-specific tool plugins."""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

from core.tools.executor import ToolResult


@runtime_checkable
class AgentToolHandler(Protocol):
    """Protocol that agent-specific tool modules must implement.

    Each agent can provide a ToolHandler class that handles
    tools specific to that agent (e.g., doc-gen has extract_api_changes,
    code-review has post_review_comment, etc.).
    """

    def get_tool_definitions(self) -> list[dict]:
        """Return tool schema definitions for this agent's tools."""
        ...

    async def handle(self, tool_name: str, tool_input: dict[str, Any]) -> ToolResult:
        """Handle a tool call. Returns ToolResult."""
        ...
