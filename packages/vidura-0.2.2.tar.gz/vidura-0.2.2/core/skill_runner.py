"""Skill runner — generic executor for agent and single-shot skills."""

from __future__ import annotations

import json

from core.llm.base import LLMProvider
from core.logger import logger
from core.retry import retry_sync
from core.skill_loader import SkillDefinition


class SkillRunner:
    """Executes any skill by loading its definition and calling the LLM."""

    def __init__(self, provider: LLMProvider) -> None:
        self.provider = provider

    def run(self, skill: SkillDefinition, context: dict) -> dict:
        """Run a single-shot skill (critic, evaluator, etc.).

        Args:
            skill: The parsed skill definition.
            context: Dict with keys to format into the user message.
                     Expected keys depend on the skill body's {placeholders}.
                     Common: documentation, delta_summary, existing_docs.

        Returns:
            Parsed JSON dict (for output_format=json) or {"content": str}.
        """
        system_prompt = skill.body
        user_message = self._build_user_message(skill, context)

        try:
            response = retry_sync(
                lambda: self.provider.chat(
                    system=system_prompt,
                    messages=[{"role": "user", "content": user_message}],
                    max_tokens=context.get("max_tokens", 2048),
                ),
                label=skill.name,
            )

            if skill.output_format == "json":
                return self._parse_json(response.content, skill.name)

            return {"content": response.content}

        except Exception as err:
            logger.warn(f"Skill '{skill.name}' failed: {err}")
            return self._fallback(skill, str(err))

    def _build_user_message(self, skill: SkillDefinition, context: dict) -> str:
        """Build the user message from context.

        The skill body is the system prompt. The user message is built
        from the context dict — each key becomes a section.
        """
        parts: list[str] = []

        if "documentation" in context:
            parts.append(f"## Documentation Draft\n```markdown\n{context['documentation']}\n```")

        if "delta_summary" in context:
            parts.append(f"## API Delta (ground truth)\n```json\n{context['delta_summary']}\n```")

        if "existing_docs" in context:
            parts.append(f"## Existing Documentation (for style comparison)\n```markdown\n{context['existing_docs']}\n```")

        # Any extra context keys become sections
        skip = {"documentation", "delta_summary", "existing_docs", "max_tokens"}
        for key, value in context.items():
            if key not in skip and isinstance(value, str) and value.strip():
                parts.append(f"## {key.replace('_', ' ').title()}\n{value}")

        return "\n\n".join(parts) if parts else "Review the provided content."

    @staticmethod
    def _parse_json(content: str, skill_name: str) -> dict:
        """Parse JSON from LLM response, stripping markdown fences if present."""
        text = content.strip()

        # Strip markdown code fences
        if text.startswith("```"):
            lines = text.split("\n")
            lines = lines[1:]  # drop opening fence
            if lines and lines[-1].strip() == "```":
                lines = lines[:-1]
            text = "\n".join(lines).strip()

        try:
            return json.loads(text)
        except json.JSONDecodeError:
            logger.warn(f"Skill '{skill_name}' returned non-JSON response")
            return {"error": f"Could not parse JSON from {skill_name}", "raw": content[:500]}

    @staticmethod
    def _fallback(skill: SkillDefinition, error_msg: str) -> dict:
        """Return a sensible fallback based on the skill name."""
        summary = f"{skill.name} failed: {error_msg}"

        if skill.name == "critic":
            return {
                "scores": {
                    "completeness": 0, "clarity": 0, "accuracy": 0,
                    "structure": 0, "developerExperience": 0,
                },
                "overallScore": 0,
                "criticalIssues": [],
                "suggestions": [summary],
                "summary": summary,
            }
        elif skill.name == "evaluator":
            return {
                "qualityScore": 0,
                "dimensions": {
                    "targetAudienceFit": 0, "completeness": 0,
                    "codeExamples": 0, "consistency": 0,
                    "styleConsistency": None,
                },
                "integratorBlockers": [],
                "suggestions": [summary],
                "summary": summary,
            }

        return {"error": summary}
