"""Mid-run progress reporting to the SaaS platform.

The platform provides a ``progress_url`` in the config response.
The agent POSTs structured events here during the run so the platform
has visibility without waiting for the final callback.

All calls are fire-and-forget — a failure never aborts the agent run.
"""

from __future__ import annotations

import asyncio
import json
import os
import urllib.request
from datetime import datetime, timezone
from typing import Any


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class ProgressReporter:
    """Posts structured progress events to the platform's progress_url.

    Events emitted:
      run_started      — once, before the agent loop begins
      turn_complete    — after each agent loop turn
      run_completed    — once, on successful terminal tool call
      run_failed       — once, on any failure
    """

    def __init__(
        self,
        progress_url: str | None = None,
        token: str | None = None,
        run_id: str = "",
        agent: str = "",
    ) -> None:
        self._url = progress_url or os.environ.get("VIDURA_PROGRESS_URL", "")
        self._token = token or os.environ.get("VIDURA_INSTALL_TOKEN", "")
        self._run_id = run_id or os.environ.get("VIDURA_RUN_ID", "")
        self._agent = agent
        self._enabled = bool(self._url)

    # ── Public API ────────────────────────────────────────────────────────────

    async def run_started(self, branch: str, base_branch: str, max_turns: int) -> None:
        await self._send({
            "event": "run_started",
            "branch": branch,
            "base_branch": base_branch,
            "max_turns": max_turns,
        })

    async def turn_complete(
        self,
        turn: int,
        max_turns: int,
        tool_called: str,
        cumulative_tokens: dict[str, int],
    ) -> None:
        await self._send({
            "event": "turn_complete",
            "turn": turn,
            "max_turns": max_turns,
            "tool_called": tool_called,
            "cumulative_tokens": cumulative_tokens,
        })

    async def run_completed(
        self,
        turns_used: int,
        tokens: dict[str, int],
        output_path: str = "",
    ) -> None:
        await self._send({
            "event": "run_completed",
            "turns_used": turns_used,
            "tokens": tokens,
            "output_path": output_path,
        })

    async def run_failed(
        self,
        error: str,
        error_code: str,
        turns_used: int,
        tokens: dict[str, int],
    ) -> None:
        await self._send({
            "event": "run_failed",
            "error": error,
            "error_code": error_code,
            "turns_used": turns_used,
            "tokens": tokens,
        })

    # ── Internal ──────────────────────────────────────────────────────────────

    async def _send(self, payload: dict[str, Any]) -> None:
        if not self._enabled:
            return

        payload["run_id"] = self._run_id
        payload["agent"] = self._agent
        payload["timestamp"] = _now()

        try:
            await asyncio.get_event_loop().run_in_executor(None, self._post, payload)
        except Exception:
            pass  # Never abort the run due to a progress reporting failure

    def _post(self, payload: dict[str, Any]) -> None:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            self._url,
            data=data,
            headers={
                "Authorization": f"Bearer {self._token}",
                "Content-Type": "application/json",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=5) as _:
            pass
