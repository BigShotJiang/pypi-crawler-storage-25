"""Skill-driven workflow engine — manifest-driven, agent-agnostic.

Reads skill definitions from .md files (declared in agent.yaml manifest)
and runs the multi-turn agent loop generically.
"""

from __future__ import annotations

import asyncio
import json
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from core.agent_manifest import AgentManifest, load_agent_tool_handler
from core.config import AgentConfig, load_global_memory_config
from core.errors import MAX_TURNS_EXCEEDED, TOKEN_BUDGET_EXCEEDED, AGENT_LOGIC_ERROR, classify_llm_error
from core.progress import ProgressReporter
from core.git import GitAnalyzer
from core.llm import LLMProvider, create_provider, resolve_api_base, resolve_api_key
from core.llm.base import ToolCallResult
from core.logger import logger
from core.memory import MemoryManager
from core.retry import retry_sync
from core.skill_loader import SkillDefinition, load_skill
from core.storage.memory_store import MemoryStore
from core.tools.executor import ToolExecutor

# ── Constants ─────────────────────────────────────────────────────────────────

BUDGET_WARNING_THRESHOLD = 0.85   # warn + instruct agent to wrap up
CRITICAL_BUDGET_THRESHOLD = 0.90  # force immediate completion
FULL_CONTEXT_WINDOW = 3
MAX_SAME_TOOL_REPETITIONS = 3     # inject warning after this many consecutive identical calls
STALL_TURNS_WITHOUT_DRAFT = 12    # inject push message if no store_draft by this turn
TOKEN_STATUS_INTERVAL = 5         # inject token status every N turns so agent can self-regulate

RunStatus = Literal["NO_API_CHANGE", "GENERATED", "FAILED", "VALIDATION_FAILED"]


@dataclass
class RunResult:
    status: RunStatus
    feature_name: str | None = None
    output_path: str | None = None
    error: str | None = None
    error_code: str = ""
    usage: dict | None = None


# ── Workflow Engine ───────────────────────────────────────────────────────────


class Workflow:
    """Manifest-driven agent workflow. Loads skills declared in agent.yaml,
    resolves providers, and runs the multi-turn agent loop."""

    def __init__(
        self,
        repo_path: str,
        config: AgentConfig,
        manifest: AgentManifest,
        memory: MemoryManager | None = None,
        skills_dir: str | None = None,
    ) -> None:
        self.repo_path = repo_path
        self.config = config
        self._manifest = manifest

        # ── Resolve skills directory ─────────────────────────────────────
        self._skills_dir = Path(skills_dir) if skills_dir else Path(repo_path) / "skills"

        # ── Load skill definitions from manifest ─────────────────────────
        self._primary_skill = self._load_skill(manifest.skills.primary)

        self._secondary_skills: dict[str, SkillDefinition] = {}
        for role, filename in manifest.skills.secondary.items():
            self._secondary_skills[role] = self._load_skill(filename)

        self._validator_skill = (
            self._load_skill(manifest.skills.validator)
            if manifest.skills.validator
            else None
        )

        # ── Load style skill (if styles declared in manifest) ────────────
        self._style_skill: SkillDefinition | None = None
        if manifest.skills.styles:
            style_name = config.extra.get("doc_style", "detailed")
            style_file = manifest.skills.styles.get(style_name)
            if style_file:
                try:
                    self._style_skill = self._load_skill(style_file)
                except FileNotFoundError:
                    pass

        # ── Resolve primary API key and build LLM provider ───────────────
        self._api_key = resolve_api_key(config.provider)
        base_url = resolve_api_base(config.provider)
        self._provider = create_provider(config.provider, config.model, self._api_key, base_url=base_url)

        # ── Build secondary providers (critic, evaluator, etc.) ──────────
        self._secondary_providers: dict[str, LLMProvider] = {}
        for role, skill in self._secondary_skills.items():
            provider_name = skill.provider or getattr(config, f"{role}_provider", None) or config.provider
            model_name = skill.model or getattr(config, f"{role}_model", None) or config.model
            self._secondary_providers[role] = self._build_secondary_provider(provider_name, model_name)

        # ── Git analyser ─────────────────────────────────────────────────
        self._git = GitAnalyzer(repo_path)

        # ── Memory manager (manifest-driven) ─────────────────────────────
        if memory is not None:
            self._memory = memory
        else:
            global_store = self._build_global_store(manifest.name)
            self._memory = MemoryManager(
                repo_path,
                config.memory_dir,
                global_store=global_store,
                local_files=manifest.memory.local_files,
                local_initial_content=manifest.memory.local_initial_content,
                global_files=manifest.memory.global_files,
                global_initial_content=manifest.memory.global_initial_content,
                categories=manifest.memory.categories,
            )

    async def run(self) -> RunResult:
        logger.info("════════════════ Agent Loop Start ════════════════")

        self._memory.initialize()

        branch = self._git.get_current_branch()
        logger.info(f"Branch: {branch}")

        executor = ToolExecutor(
            repo_path=self.repo_path,
            config=self.config,
            branch=branch,
            memory=self._memory,
            manifest=self._manifest,
            secondary_providers=self._secondary_providers,
            skills_dir=self._skills_dir,
        )

        progress = ProgressReporter(agent=self._manifest.name)
        await progress.run_started(branch, self.config.base_branch, self.config.max_turns)

        result = await self._run_agent_loop(executor, branch, progress=progress)

        if result.status == "GENERATED":
            await progress.run_completed(
                turns_used=result.usage.get("turns", 0) if result.usage else 0,
                tokens=result.usage or {},
                output_path=result.output_path or "",
            )
        elif result.status == "FAILED":
            await progress.run_failed(
                error=result.error or "",
                error_code=result.error_code,
                turns_used=result.usage.get("turns", 0) if result.usage else 0,
                tokens=result.usage or {},
            )

        if (
            result.status == "GENERATED"
            and self.config.auto_commit
            and result.output_path
            and result.feature_name
        ):
            self._auto_commit(result.output_path, result.feature_name)

        logger.info("════════════════ Agent Loop Complete ════════════════")
        return result

    # ── Agent loop ────────────────────────────────────────────────────────────

    async def _run_agent_loop(
        self,
        executor: ToolExecutor,
        branch: str,
        progress: ProgressReporter | None = None,
    ) -> RunResult:
        max_turns = self._primary_skill.max_turns or self.config.max_turns
        max_in = self.config.max_input_tokens
        max_out = self.config.max_output_tokens

        system_prompt = self._build_system_prompt()

        # Build initial message from manifest template
        initial_msg = self._manifest.workflow.initial_message_template.format(
            branch=branch,
            base_branch=self.config.base_branch,
            languages=", ".join(self.config.languages) if self.config.languages else "auto-detect",
        )

        initial_parts = [initial_msg]

        if self.config.languages:
            initial_parts.append(f"\nCode languages in this project: {', '.join(self.config.languages)}")

        auto_context = self._memory.get_auto_context(branch, [])
        if auto_context:
            initial_parts.append(f"\n\n{auto_context}")

        messages: list = [{"role": "user", "content": "\n".join(initial_parts)}]
        total_usage = {"inputTokens": 0, "outputTokens": 0}
        budget_warning_sent = False
        critical_budget_sent = False
        stall_warning_sent = False
        _recent_calls: list[tuple[str, str]] = []  # (tool_name, args_fingerprint)

        # Terminal tools from manifest
        terminal_tools = set(self._manifest.workflow.terminal_tools)

        for turn in range(1, max_turns + 1):
            # 🚨 HARD STOP: force write near end (turn 17+)
            if turn >= 17 and executor._current_draft:
                logger.warn(f"[FORCE WRITE] Turn {turn} reached. Forcing write_documentation.")

                result = await executor.execute(
                    "write_documentation",
                    {
                        "featureName": branch.replace("feature/", "").replace("feat/", "")
                    }
                )

                total_usage["turns"] = turn

                return RunResult(
                    status="GENERATED",
                    feature_name=result.feature_name,
                    output_path=result.output_path,
                    usage=total_usage,
                )
            logger.info(f"Agent turn {turn}/{max_turns}")

            # Progressive tool availability from manifest
            tool_set = executor.get_tool_definitions()
            tools = self._provider.get_tool_definitions(tool_set)

            # Budget check
            if total_usage["inputTokens"] >= max_in:
                return RunResult(status="FAILED", error=f"Input token budget exhausted: {total_usage['inputTokens']}/{max_in}", error_code=TOKEN_BUDGET_EXCEEDED, usage=total_usage)
            if total_usage["outputTokens"] >= max_out:
                return RunResult(status="FAILED", error=f"Output token budget exhausted: {total_usage['outputTokens']}/{max_out}", error_code=TOKEN_BUDGET_EXCEEDED, usage=total_usage)

            in_pct = total_usage["inputTokens"] / max_in
            out_pct = total_usage["outputTokens"] / max_out
            budget_pct = max(in_pct, out_pct)

            # Share budget pct with executor so tools can tighten their responses
            executor.token_budget_pct = budget_pct

            # Periodic token status — injected every TOKEN_STATUS_INTERVAL turns so
            # the agent can self-regulate without waiting for a warning
            if turn > 1 and turn % TOKEN_STATUS_INTERVAL == 0:
                turns_left = max_turns - turn
                messages.append({
                    "role": "user",
                    "content": (
                        f"[SYSTEM] Token status at turn {turn}/{max_turns}: "
                        f"input {total_usage['inputTokens']:,}/{max_in:,} ({in_pct:.0%}), "
                        f"output {total_usage['outputTokens']:,}/{max_out:,} ({out_pct:.0%}). "
                        f"Turns remaining: {turns_left}. "
                        + ("Pace yourself — you have enough budget to finish carefully." if budget_pct < 0.6
                           else "Budget is tightening — be concise and targeted in remaining reads.")
                    ),
                })

            # Critical budget — 95%: force immediate completion, no more exploration
            if not critical_budget_sent and budget_pct >= CRITICAL_BUDGET_THRESHOLD:
                critical_budget_sent = True
                messages.append({
                    "role": "user",
                    "content": (
                        f"[SYSTEM] CRITICAL: token budget at {budget_pct:.0%}. "
                        "Stop ALL exploration immediately. "
                        "If you have a draft, call `validate_documentation` then `write_documentation` now. "
                        "If you have no draft, call `signal_no_change`. Do not call any other tool."
                    ),
                })

            # Budget warning — 85%: wrap up, prioritise critical issues only
            elif not budget_warning_sent and budget_pct >= BUDGET_WARNING_THRESHOLD:
                budget_warning_sent = True
                warning_msg = self._manifest.workflow.budget_warning_message
                messages.append({
                    "role": "user",
                    "content": (
                        f"[SYSTEM] Token budget at {budget_pct:.0%} "
                        f"(input {total_usage['inputTokens']:,}/{max_in:,}, "
                        f"output {total_usage['outputTokens']:,}/{max_out:,}). "
                        f"{warning_msg} "
                        "Address only critical issues (missing endpoints, wrong HTTP methods, broken auth). "
                        "Skip suggestions and style improvements."
                    ),
                })

            # Compact old messages
            if turn > FULL_CONTEXT_WINDOW + 1:
                messages = _compact_old_messages(messages)

            # Per-turn output cap
            remaining_out = max_out - total_usage["outputTokens"]
            per_turn_max = min(8_192, max(1_024, remaining_out))

            # Call LLM with rate-limit-aware retry.
            # The org-level TPM limit resets every 60 seconds. The default
            # retry_sync uses base_delay=1.0 with exponential backoff — max
            # cumulative wait of ~3s across 3 attempts — nowhere near enough
            # to let a per-minute window reset. We intercept 429s here and
            # wait 60s before handing back to the normal retry logic.
            def _chat_with_rate_limit_backoff() -> object:
                RATE_LIMIT_WAIT = 62  # slightly over 60s to clear the TPM window
                MAX_RATE_RETRIES = 3
                for attempt in range(1, MAX_RATE_RETRIES + 1):
                    try:
                        return retry_sync(
                            lambda: self._provider.chat(
                                system=system_prompt,
                                messages=messages,
                                tools=tools,
                                max_tokens=per_turn_max,
                            ),
                            max_attempts=3,
                            base_delay=1.0,
                            label=f"turn {turn}",
                        )
                    except Exception as exc:
                        err_str = str(exc)
                        is_rate_limit = (
                            "rate_limit_error" in err_str
                            or "rate limit" in err_str.lower()
                            or "429" in err_str
                        )
                        if is_rate_limit and attempt < MAX_RATE_RETRIES:
                            logger.warn(
                                f"[turn {turn}] Rate limit hit (attempt {attempt}/{MAX_RATE_RETRIES}). "
                                f"Waiting {RATE_LIMIT_WAIT}s for TPM window to reset..."
                            )
                            time.sleep(RATE_LIMIT_WAIT)
                            continue
                        raise  # non-429 error or exhausted retries — bubble up

            try:
                response = await asyncio.get_event_loop().run_in_executor(
                    None,
                    _chat_with_rate_limit_backoff,
                )
            except Exception as err:
                code = classify_llm_error(err)
                return RunResult(status="FAILED", error=f"LLM API error on turn {turn}: {err}", error_code=code, usage=total_usage)

            total_usage["inputTokens"] += response.usage.input_tokens
            total_usage["outputTokens"] += response.usage.output_tokens
            logger.debug(
                f"Turn {turn} — stop: {response.stop_reason}, "
                f"in: {response.usage.input_tokens}, out: {response.usage.output_tokens} | "
                f"cumulative in: {total_usage['inputTokens']}/{max_in}, out: {total_usage['outputTokens']}/{max_out}"
            )

            # ── Strip large args BEFORE building the assistant message ────────
            # The 'documentation' arg of store_draft can be 20k+ chars (~5k tokens).
            # It gets embedded in the assistant message and re-sent to the API on
            # EVERY subsequent turn. Nullify it here — the draft is already saved
            # in executor._current_draft so the history copy is never needed again.
            for tc in response.tool_calls:
                if tc.name == "store_draft" and isinstance(tc.input, dict):
                    doc = tc.input.get("documentation", "")

                    if len(doc) > 200:
                        # DO NOT mutate original input
                        # Only log / strip for debug if needed

                        logger.debug(
                            f"[context] store_draft documentation large ({len(doc)} chars) — kept out of history"
                        )
            # ─────────────────────────────────────────────────────────────────

            messages.append(self._provider.build_assistant_message(response))

            if response.stop_reason == "end_turn":
                if executor._current_draft:
                    logger.warn(f"[FORCE WRITE] Model ended turn on {turn} with a stored draft. Forcing write_documentation.")
                    result = await executor.execute(
                        "write_documentation",
                        {
                            "featureName": branch.replace("feature/", "").replace("feat/", "")
                        }
                    )
                    total_usage["turns"] = turn
                    return RunResult(
                        status="GENERATED",
                        feature_name=result.feature_name,
                        output_path=result.output_path,
                        usage=total_usage,
                    )

                return RunResult(
                    status="FAILED",
                    error="Agent ended without calling a terminal tool",
                    error_code=AGENT_LOGIC_ERROR,
                    usage=total_usage,
                )

            if response.stop_reason == "max_tokens":
                logger.warn(f"[FORCE WRITE] Model hit max_tokens on turn {turn}.")

                if executor._current_draft:
                    result = await executor.execute(
                        "write_documentation",
                        {
                            "featureName": branch.replace("feature/", "").replace("feat/", "")
                        }
                    )
                    total_usage["turns"] = turn
                    return RunResult(
                        status="GENERATED",
                        feature_name=result.feature_name,
                        output_path=result.output_path,
                        usage=total_usage,
                    )

                return RunResult(
                    status="FAILED",
                    error="Model hit max_tokens before producing a tool call and no draft was available.",
                    error_code=AGENT_LOGIC_ERROR,
                    usage=total_usage,
                )

            if response.stop_reason != "tool_use":
                return RunResult(
                    status="FAILED",
                    error=f"Unexpected stop_reason: {response.stop_reason}",
                    error_code=AGENT_LOGIC_ERROR,
                    usage=total_usage,
                )

            # Dispatch tool calls
            tool_results: list[ToolCallResult] = []
            terminal_result: RunResult | None = None

            for tc in response.tool_calls:
                result = await executor.execute(tc.name, tc.input)

                tool_results.append(ToolCallResult(tool_call_id=tc.id, content=result.content))

                if result.is_terminal and terminal_result is None:
                    terminal_result = RunResult(
                        status="GENERATED" if result.terminal_status == "GENERATED" else "NO_API_CHANGE",
                        feature_name=result.feature_name,
                        output_path=result.output_path,
                        usage=total_usage,
                    )

            messages.extend(self._provider.build_tool_result_messages(tool_results))

            # ── Loop-prevention checks ────────────────────────────────────────

            # 1. Repetitive tool call detection
            for tc in response.tool_calls:
                # Fingerprint: tool name + first 120 chars of sorted args JSON
                args_fp = json.dumps(sorted(tc.input.items()), separators=(",", ":"))[:120]
                _recent_calls.append((tc.name, args_fp))

            if len(_recent_calls) >= MAX_SAME_TOOL_REPETITIONS:
                last_n = _recent_calls[-MAX_SAME_TOOL_REPETITIONS:]
                if all(c == last_n[0] for c in last_n):
                    tool_name_rep = last_n[0][0]
                    messages.append({
                        "role": "user",
                        "content": (
                            f"[SYSTEM] You have called `{tool_name_rep}` with identical arguments "
                            f"{MAX_SAME_TOOL_REPETITIONS} times in a row. This is not producing new information. "
                            "Move to the next step in your plan. If you cannot proceed, call `signal_no_change`."
                        ),
                    })
                    _recent_calls.clear()  # reset after warning to avoid re-firing immediately

            # 2. Stall detection — no store_draft by the threshold turn
            if (
                not stall_warning_sent
                and not executor._current_draft
                and turn >= STALL_TURNS_WITHOUT_DRAFT
            ):
                stall_warning_sent = True
                messages.append({
                    "role": "user",
                    "content": (
                        f"[SYSTEM] {turn} turns have passed without a draft. "
                        "You must call `store_draft` immediately with whatever documentation you have, "
                        "or `signal_no_change` if there is nothing to document. Do not explore further."
                    ),
                })

            # Report turn progress (last tool called this turn)
            last_tool = response.tool_calls[-1].name if response.tool_calls else ""
            if progress:
                await progress.turn_complete(
                    turn=turn,
                    max_turns=max_turns,
                    tool_called=last_tool,
                    cumulative_tokens=total_usage,
                )

            if terminal_result:
                total_usage["turns"] = turn
                logger.info(
                    f"Agent completed in {turn} turn(s) | "
                    f"tokens: {total_usage['inputTokens']} in + {total_usage['outputTokens']} out"
                )
                return terminal_result

        return RunResult(status="FAILED", error=f"Agent exceeded maximum turns ({max_turns})", error_code=MAX_TURNS_EXCEEDED, usage=total_usage)

    # ── System prompt (from skills) ───────────────────────────────────────────

    def _build_system_prompt(self) -> str:
        """Build system prompt from primary skill body + style + context."""
        parts = [self._primary_skill.body]

        # Inject style from style skill
        if self._style_skill:
            parts.append(f"\n\n## Style Instructions\n{self._style_skill.body}")

        # Inject org/project/repo context
        context_parts = []
        if self.config.org_name:
            context_parts.append(f"Organization: {self.config.org_name}")
        if self.config.project_name:
            context_parts.append(f"Project: {self.config.project_name}")
        if self.config.repo_name:
            context_parts.append(f"Repository: {self.config.repo_name}")
        if context_parts:
            parts.append("\n\n## Context\n" + "\n".join(context_parts))

        # Inject custom instructions
        if self.config.custom_instructions:
            parts.append(f"\n\n## Additional Instructions\n{self.config.custom_instructions}")

        return "".join(parts)

    # ── Skill loading ─────────────────────────────────────────────────────────

    def _load_skill(self, filename: str) -> SkillDefinition:
        """Load a skill from the skills directory."""
        path = self._skills_dir / filename
        if not path.exists():
            raise FileNotFoundError(
                f"Required skill file not found: {path}\n"
                f"Run 'vidura init --agent {self._manifest.name}' to create skill files."
            )
        return load_skill(path)

    # ── Provider helpers ──────────────────────────────────────────────────────

    def _build_secondary_provider(
        self, provider_name: str | None, model_name: str | None,
    ) -> LLMProvider:
        effective_provider = provider_name or self.config.provider
        effective_model = model_name or self.config.model

        if effective_provider == self.config.provider:
            key = self._api_key
        else:
            key = resolve_api_key(effective_provider)

        base_url = resolve_api_base(effective_provider)
        return create_provider(effective_provider, effective_model, key, base_url=base_url)

    def _build_global_store(self, agent_name: str = "") -> MemoryStore | None:
        gm = load_global_memory_config()
        if not gm.enabled or not gm.repo_url:
            return None

        from core.storage.git_store import GitMemoryStore

        logger.info(f"Global memory: git repo ({gm.branch}) [{agent_name or 'root'}]")
        return GitMemoryStore(
            repo_url=gm.repo_url,
            branch=gm.branch,
            token=gm.token,
            subdir=agent_name,
        )

    def _auto_commit(self, output_path: str, feature_name: str) -> None:
        try:
            message = self.config.commit_message.replace("{feature}", feature_name)
            # Add all files in the output directory related to this feature
            subprocess.run(
                f'git add "{output_path}"',
                shell=True, cwd=self.repo_path, capture_output=True, check=True,
            )
            # Also add the .md version if .docx was provided
            md_path = output_path.replace(".docx", ".md")
            if Path(md_path).exists() and md_path != output_path:
                subprocess.run(
                    f'git add "{md_path}"',
                    shell=True, cwd=self.repo_path, capture_output=True, check=True,
                )
            subprocess.run(
                f'git commit -m "{message}"',
                shell=True, cwd=self.repo_path, capture_output=True, check=True,
            )
            logger.success(f"Auto-committed: {message}")
        except subprocess.CalledProcessError as err:
            logger.warn(f"Auto-commit skipped: {err}")


# ── Message compaction (stateless helpers) ────────────────────────────────────


def _compact_old_messages(messages: list) -> list:
    """Compact tool results from older turns to reduce token usage."""
    if len(messages) <= (FULL_CONTEXT_WINDOW * 2 + 1):
        return messages

    keep_tail = FULL_CONTEXT_WINDOW * 2
    first_msg = messages[0]
    middle = messages[1:-keep_tail]
    tail = messages[-keep_tail:]

    compacted: list = [first_msg]
    for msg in middle:
        role = msg.get("role", "")
        content = msg.get("content", "")

        if role == "user" and isinstance(content, list):
            summaries = []
            for block in content:
                if isinstance(block, dict) and block.get("type") == "tool_result":
                    raw = block.get("content", "")
                    summaries.append({
                        "type": "tool_result",
                        "tool_use_id": block.get("tool_use_id", ""),
                        "content": _summarize_tool_result(raw),
                    })
                else:
                    summaries.append(block)
            compacted.append({"role": "user", "content": summaries})
        elif role == "tool":
            compacted.append({
                "role": "tool",
                "tool_call_id": msg.get("tool_call_id", ""),
                "content": _summarize_tool_result(msg.get("content", "")),
            })
        elif role == "assistant":
            compacted.append(_compact_assistant_message(msg))
        else:
            compacted.append(msg)

    compacted.extend(tail)
    return compacted


def _compact_assistant_message(msg: dict) -> dict:
    content = msg.get("content")

    if isinstance(content, list):
        compacted_blocks = []
        for block in content:
            if (
                isinstance(block, dict)
                and block.get("type") == "tool_use"
                and isinstance(block.get("input"), dict)
            ):
                # Compact any large string values in tool inputs
                new_input = {}
                for k, v in block["input"].items():
                    if isinstance(v, str) and len(v) > 500:
                        new_input[k] = f"[{k} — see store_draft]"
                    else:
                        new_input[k] = v
                if new_input != block["input"]:
                    compacted_blocks.append({**block, "input": new_input})
                else:
                    compacted_blocks.append(block)
            else:
                compacted_blocks.append(block)
        return {**msg, "content": compacted_blocks}

    tool_calls = msg.get("tool_calls")
    if isinstance(tool_calls, list):
        compacted_calls = []
        for tc in tool_calls:
            func = tc.get("function", {})
            args_str = func.get("arguments", "")
            if isinstance(args_str, str) and len(args_str) > 500:
                try:
                    args = json.loads(args_str)
                    changed = False
                    for k, v in args.items():
                        if isinstance(v, str) and len(v) > 500:
                            args[k] = f"[{k} — see store_draft]"
                            changed = True
                    if changed:
                        tc = {**tc, "function": {**func, "arguments": json.dumps(args)}}
                except (json.JSONDecodeError, TypeError):
                    pass
            compacted_calls.append(tc)
        return {**msg, "tool_calls": compacted_calls}

    return msg


def _summarize_tool_result(raw: str) -> str:
    if len(raw) <= 200:
        return raw

    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return raw[:150] + "...[compacted]"

    # Generic summarization patterns
    if "total" in data and "apiRelated" in data:
        return json.dumps({"total": data["total"], "apiRelated": data["apiRelated"]})

    if "new" in data and "modified" in data:
        return json.dumps({
            "feature": data.get("feature", ""),
            "new": len(data.get("new", [])),
            "modified": len(data.get("modified", [])),
            "removed": len(data.get("removed", [])),
        })

    if "valid" in data:
        return json.dumps({"valid": data["valid"], "errors": len(data.get("errors", [])), "warnings": len(data.get("warnings", []))})

    if "planCreated" in data or "planRevised" in data:
        return json.dumps({"ok": True})

    if "totalResults" in data:
        return json.dumps({"totalResults": data["totalResults"]})

    if "overallScore" in data or "qualityScore" in data:
        score_key = "overallScore" if "overallScore" in data else "qualityScore"
        return json.dumps({score_key: data[score_key], "suggestions": len(data.get("suggestions", []))})

    if "stored" in data and "charCount" in data:
        return json.dumps({"stored": True, "charCount": data["charCount"]})

    if "stored" in data:
        return json.dumps({"stored": True})

    if "skipped" in data:
        return json.dumps({"skipped": True})

    if "noChange" in data:
        return raw

    return raw[:150] + "...[compacted]"