"""CI platform detection from environment variables.

Reads env vars to populate metadata — no VCS API calls.
The SaaS platform uses this metadata to dispatch to the correct VCS adapter.
"""

from __future__ import annotations

import os
import re
from typing import Any


def detect_ci_context() -> dict[str, Any]:
    """Detect CI platform and extract context from environment variables.

    Returns a dict with: vcs_platform, ci_platform, pr_number, commit_sha, repo_url, etc.
    All values are strings or None. No API calls are made.
    """
    ctx: dict[str, Any] = {
        "vcs_platform": None,
        "ci_platform": None,
        "pr_number": None,
        "commit_sha": None,
        "repo_url": None,
    }

    if os.environ.get("GITHUB_ACTIONS") == "true":
        ctx["ci_platform"] = "github_actions"
        ctx["vcs_platform"] = "github"
        ctx["commit_sha"] = os.environ.get("GITHUB_SHA")
        ctx["repo_url"] = _build_github_url()
        ctx["pr_number"] = _extract_github_pr_number()

    elif os.environ.get("GITLAB_CI") == "true":
        ctx["ci_platform"] = "gitlab_ci"
        ctx["vcs_platform"] = "gitlab"
        ctx["commit_sha"] = os.environ.get("CI_COMMIT_SHA")
        ctx["repo_url"] = os.environ.get("CI_PROJECT_URL")
        ctx["pr_number"] = os.environ.get("CI_MERGE_REQUEST_IID")

    elif os.environ.get("BITBUCKET_BUILD_NUMBER"):
        ctx["ci_platform"] = "bitbucket_pipelines"
        ctx["vcs_platform"] = "bitbucket"
        ctx["commit_sha"] = os.environ.get("BITBUCKET_COMMIT")
        ctx["repo_url"] = _build_bitbucket_url()
        ctx["pr_number"] = os.environ.get("BITBUCKET_PR_ID")

    elif os.environ.get("TF_BUILD") == "True":
        ctx["ci_platform"] = "azure_pipelines"
        ctx["vcs_platform"] = "azure_devops"
        ctx["commit_sha"] = os.environ.get("BUILD_SOURCEVERSION")
        ctx["repo_url"] = os.environ.get("BUILD_REPOSITORY_URI")
        ctx["pr_number"] = os.environ.get("SYSTEM_PULLREQUEST_PULLREQUESTNUMBER")

    elif os.environ.get("JENKINS_URL"):
        ctx["ci_platform"] = "jenkins"
        ctx["commit_sha"] = os.environ.get("GIT_COMMIT")
        ctx["repo_url"] = os.environ.get("GIT_URL")
        ctx["pr_number"] = os.environ.get("CHANGE_ID")

    elif os.environ.get("CIRCLECI") == "true":
        ctx["ci_platform"] = "circleci"
        ctx["commit_sha"] = os.environ.get("CIRCLE_SHA1")
        ctx["repo_url"] = os.environ.get("CIRCLE_REPOSITORY_URL")
        ctx["pr_number"] = _extract_circleci_pr_number()

    # Strip None values
    return {k: v for k, v in ctx.items() if v is not None}


def _build_github_url() -> str | None:
    server = os.environ.get("GITHUB_SERVER_URL", "https://github.com")
    repo = os.environ.get("GITHUB_REPOSITORY")
    if repo:
        return f"{server}/{repo}"
    return None


def _extract_github_pr_number() -> str | None:
    ref = os.environ.get("GITHUB_REF", "")
    # GITHUB_REF is refs/pull/123/merge for PR events
    match = re.match(r"refs/pull/(\d+)/", ref)
    if match:
        return match.group(1)
    # Also check GITHUB_EVENT for pull_request events
    return os.environ.get("GITHUB_PR_NUMBER")


def _build_bitbucket_url() -> str | None:
    workspace = os.environ.get("BITBUCKET_WORKSPACE")
    repo = os.environ.get("BITBUCKET_REPO_SLUG")
    if workspace and repo:
        return f"https://bitbucket.org/{workspace}/{repo}"
    return None


def _extract_circleci_pr_number() -> str | None:
    pr_url = os.environ.get("CIRCLE_PULL_REQUEST", "")
    # URL format: https://github.com/org/repo/pull/123
    match = re.search(r"/pull/(\d+)", pr_url)
    if match:
        return match.group(1)
    return None
