"""Storage abstraction layer — local filesystem and Git repo backends."""

from core.storage.memory_store import MemoryStore

__all__ = ["MemoryStore"]
