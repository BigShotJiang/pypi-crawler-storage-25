"""Git repo-backed memory store for shared global memory across projects.

The admin creates a private Git repo and sets the URL as an env var.
The agent clones it locally, reads/writes skill files, and pushes changes.
The end user never sees the repo URL or knows it exists.
"""

from __future__ import annotations

import subprocess
from pathlib import Path

from core.logger import logger
from core.storage.memory_store import MemoryStore


class GitMemoryStore(MemoryStore):
    """Reads / writes skill files to a shared Git repository.

    On first use, clones the repo to ~/.agentic-docs/global-memory-repo/.
    On subsequent uses, pulls latest changes before reading.
    After writes, commits and pushes automatically.

    Files are stored under ``<local_dir>/<subdir>/`` when *subdir* is set,
    enabling per-agent isolation inside a single shared repo.
    """

    def __init__(
        self,
        repo_url: str,
        branch: str = "main",
        token: str | None = None,
        local_path: str | None = None,
        subdir: str = "",
    ) -> None:
        self.branch = branch
        self.subdir = subdir.strip("/") if subdir else ""

        if token and repo_url.startswith("https://"):
            parts = repo_url.split("://", 1)
            self.repo_url = f"{parts[0]}://x-access-token:{token}@{parts[1]}"
        else:
            self.repo_url = repo_url

        self.local_dir = Path(local_path) if local_path else Path.home() / ".agentic-docs" / "global-memory-repo"
        self._ensure_repo()

    def _file_path(self, filename: str) -> Path:
        """Resolve the full path to a memory file, honouring subdir."""
        if self.subdir:
            return self.local_dir / self.subdir / filename
        return self.local_dir / filename

    def _ensure_repo(self) -> None:
        """Clone or pull the repo, then create the agent subdir if needed."""
        if (self.local_dir / ".git").exists():
            try:
                self._git("remote", "set-url", "origin", self.repo_url)
            except Exception as err:
                logger.warn(f"Failed to refresh global memory remote URL: {err}")

            self._git("fetch", "origin", self.branch)
            self._git("reset", "--hard", f"origin/{self.branch}")
        else:
            self.local_dir.mkdir(parents=True, exist_ok=True)
            self._git_global(
                "clone", "--branch", self.branch, "--single-branch",
                "--depth", "1", self.repo_url, str(self.local_dir),
            )

        if self.subdir:
            (self.local_dir / self.subdir).mkdir(parents=True, exist_ok=True)

        suffix = f"/{self.subdir}" if self.subdir else ""
        logger.debug(f"Global memory repo ready: {self.local_dir}{suffix}")

    def _pull(self) -> None:
        try:
            self._git("remote", "set-url", "origin", self.repo_url)
        except Exception as err:
            logger.warn(f"Failed to refresh global memory remote URL before pull: {err}")

        try:
            self._git("pull", "--rebase", "origin", self.branch)
        except Exception:
            pass

    def _push(self, message: str) -> None:
        try:
            self._git("add", ".")
            result = subprocess.run(
                ["git", "status", "--porcelain"],
                cwd=str(self.local_dir),
                capture_output=True,
                text=True,
            )
            if not result.stdout.strip():
                return

            self._git("commit", "-m", message)
            self._git("push", "origin", self.branch)
            logger.debug(f"Global memory pushed: {message}")
        except Exception as err:
            logger.warn(f"Global memory push failed: {err}")

    def read(self, filename: str) -> str:
        self._pull()
        path = self._file_path(filename)
        try:
            return path.read_text(encoding="utf-8")
        except FileNotFoundError:
            return ""
        except Exception as err:
            logger.warn(f"Git store read failed for {filename}: {err}")
            return ""

    def write(self, filename: str, content: str) -> None:
        try:
            path = self._file_path(filename)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding="utf-8")
            self._push(f"update {self.subdir + '/' if self.subdir else ''}{filename}")
        except Exception as err:
            logger.warn(f"Git store write failed for {filename}: {err}")

    def append(self, filename: str, content: str) -> None:
        self._pull()
        existing = self.read(filename)
        self.write(filename, existing + content + "\n")

    def exists(self, filename: str) -> bool:
        self._pull()
        return self._file_path(filename).exists()

    def list_files(self) -> list[str]:
        self._pull()
        base = self.local_dir / self.subdir if self.subdir else self.local_dir
        if not base.exists():
            return []
        return [f.name for f in base.iterdir() if f.is_file() and f.suffix == ".md"]

    def initialize(self, initial_content: dict[str, str]) -> None:
        self._pull()
        created = False
        for filename, content in initial_content.items():
            path = self._file_path(filename)
            path.parent.mkdir(parents=True, exist_ok=True)
            if not path.exists():
                path.write_text(content, encoding="utf-8")
                created = True
                logger.debug(f"Initialized global skill: {filename}")
        if created:
            self._push("initialize global memory skill files")

    def _git(self, *args: str) -> subprocess.CompletedProcess:
        return subprocess.run(
            ["git", *args],
            cwd=str(self.local_dir),
            capture_output=True,
            text=True,
            check=True,
        )

    def _git_global(self, *args: str) -> subprocess.CompletedProcess:
        return subprocess.run(
            ["git", *args],
            capture_output=True,
            text=True,
            check=True,
        )
