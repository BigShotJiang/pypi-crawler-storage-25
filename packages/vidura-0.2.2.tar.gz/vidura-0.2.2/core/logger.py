"""Colored logging module matching the TypeScript logger."""

import sys

from colorama import Fore
from colorama import init as colorama_init

colorama_init(autoreset=True)

_silent = False
_verbose = False


def set_silent(value: bool) -> None:
    global _silent
    _silent = value


def set_verbose(value: bool) -> None:
    global _verbose
    _verbose = value


class _Logger:
    def debug(self, msg: str, *args: object) -> None:
        if not _verbose or _silent:
            return
        print(f"{Fore.LIGHTBLACK_EX}[DEBUG] {msg}", *args, file=sys.stdout)

    def info(self, msg: str, *args: object) -> None:
        if _silent:
            return
        print(f"{Fore.BLUE}[INFO]  {msg}", *args, file=sys.stdout)

    def warn(self, msg: str, *args: object) -> None:
        if _silent:
            return
        print(f"{Fore.YELLOW}[WARN]  {msg}", *args, file=sys.stderr)

    def error(self, msg: str, *args: object) -> None:
        print(f"{Fore.RED}[ERROR] {msg}", *args, file=sys.stderr)

    def success(self, msg: str, *args: object) -> None:
        if _silent:
            return
        print(f"{Fore.GREEN}[OK]    {msg}", *args, file=sys.stdout)


logger = _Logger()
