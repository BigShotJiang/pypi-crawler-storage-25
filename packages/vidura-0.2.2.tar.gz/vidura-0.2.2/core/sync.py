"""Skills versioning and sync.

On init, checksums of installed skill files are stored in
``.agent/skills/.vidura-checksums.json``.

On sync, the platform returns updated skill content. Files that match
their installed checksum (i.e. not user-modified) are updated silently.
Files the user has edited are left alone with a warning.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

from core.logger import logger


CHECKSUMS_FILE = ".vidura-checksums.json"


def _sha256(content: str) -> str:
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


def save_checksums(skills_dir: Path, checksums: dict[str, str]) -> None:
    """Write the checksum index to disk."""
    path = skills_dir / CHECKSUMS_FILE
    path.write_text(json.dumps(checksums, indent=2), encoding="utf-8")


def load_checksums(skills_dir: Path) -> dict[str, str]:
    """Read the checksum index. Returns empty dict if not found."""
    path = skills_dir / CHECKSUMS_FILE
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def record_installed_skills(skills_dir: Path) -> dict[str, str]:
    """Hash every .md skill file and save the checksum index.

    Called at the end of ``vidura init`` so future sync can detect
    user modifications.
    """
    checksums: dict[str, str] = {}
    for md_file in sorted(skills_dir.glob("*.md")):
        content = md_file.read_text(encoding="utf-8")
        checksums[md_file.name] = _sha256(content)
    save_checksums(skills_dir, checksums)
    return checksums


def sync_skills(
    skills_dir: Path,
    updated_skills: dict[str, str],  # {filename: new_content}
) -> tuple[list[str], list[str], list[str]]:
    """Apply updated skills, skipping user-modified files.

    Returns:
        updated  — files that were updated
        skipped  — files skipped because user modified them
        new      — brand-new files that didn't exist before
    """
    installed = load_checksums(skills_dir)
    updated: list[str] = []
    skipped: list[str] = []
    new_files: list[str] = []

    for filename, new_content in updated_skills.items():
        dest = skills_dir / filename

        if not dest.exists():
            dest.write_text(new_content, encoding="utf-8")
            new_files.append(filename)
            installed[filename] = _sha256(new_content)
            continue

        current_content = dest.read_text(encoding="utf-8")
        current_hash = _sha256(current_content)
        installed_hash = installed.get(filename, "")

        if current_hash != installed_hash:
            # User has modified this file — don't overwrite
            skipped.append(filename)
            logger.warn(
                f"  Skipped {filename} — local modifications detected. "
                "To accept the platform version, delete the file and re-run sync."
            )
            continue

        new_hash = _sha256(new_content)
        if current_hash == new_hash:
            # Already up to date
            continue

        dest.write_text(new_content, encoding="utf-8")
        installed[filename] = new_hash
        updated.append(filename)

    save_checksums(skills_dir, installed)
    return updated, skipped, new_files
