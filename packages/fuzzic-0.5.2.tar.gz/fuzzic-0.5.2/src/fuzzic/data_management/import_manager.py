import sys
import ast
import xml.etree.ElementTree as ET
import os
import fuzzic.interpretability.rulebase as rbm
import fuzzic.interpretability.dataset as dataset



# IMPORT DATASET ==============================================================

def import_dataset(filepath, rulebase):
    """
    Returns a Dataset object from the given filepath

    Parameters
    ----------
    filepath : str
        path of the dataset file.

    Returns
    -------
    dataset
        a dataset object from fuzzic.interpretability.rulebase.py
    """

    with open(filepath, "r") as f:
        read_data = []
        line_str = f.readline()
        while line_str != "":
            line_str = line_str[:len(line_str)-1]
            if line_str != "" and line_str != "\n":
                read_data.append(line_str)
            line_str = f.readline()
        datalist = [read_data[i].split(",") for i in range(len(read_data))]
    the_dataset_object = dataset.Dataset(datalist, rulebase)
    return the_dataset_object



def import_rulebase(filepath, specified_dataset = None):
    """
    Returns a rulebase object from the given filepath

    Parameters
    ----------
    filepath : str
        path of the rulebase file, either fispro or XML type file.
    specified_dataset : str or Dataset object
        a given dataset either already in a Dataset object, or the filepath of it.

    Returns
    -------
    rulebase
        a Rulebase object from fuzzic.interpretability.rulebase.py
    """

    typefile = os.path.splitext(filepath)[1]

    if typefile == ".fis":
        rb = import_fispro(filepath)
        if type(specified_dataset) is str:
            rb.dataset = import_dataset(specified_dataset, rb)
        else:
            rb.dataset = specified_dataset
        return rb

    elif typefile == ".xml":
        rb = import_xml(filepath)
        if type(specified_dataset) is str:
            rb.dataset = import_dataset(specified_dataset, rb)
        else:
            rb.dataset = specified_dataset
        return rb
    else:
        print("Unknown rule base file format.", file=sys.stderr, flush=True)
        return None

# IMPORT RULEBASE FROM TREE, XML OR FISPRO ==========================================

def import_xml(filepath):
    """
    Returns a rulebase object from the given filepath of a XML file.

    Parameters
    ----------
    filepath : str
        path of the XML file representing a rulebase.

    Returns
    -------
    rulebase
        a Rulebase object from fuzzic.interpretability.rulebase.py
    """
    tree = ET.parse(filepath)
    return import_tree(tree, filepath=filepath)


def import_tree(tree, filepath=None):
    """
    Returns a rulebase object from a xml.etree.ElementTree.

    Parameters
    ----------
    tree : ElementTree from xml.etree.ElementTree
        A tree representation of an XML file.
    filepath : str
        path of the origin rulebase XML file if available.

    Returns
    -------
    rulebase
        a Rulebase object from fuzzic.interpretability.rulebase.py
    """

    root = tree.getroot()

    rule_base = rbm.Rulebase()
    if filepath is not None:
        rule_base.filename = os.path.basename(filepath)

    for label in root.iter("label"):
        rule_base.label = label.text
        break

    for var in root.iter("variable"):
        var_bounds = [float(var[1][0].text), float(var[1][1].text)]

        one_variable = rbm.Variable(label = str(var[0].text),
                                rulebase = rule_base,
                                unit = str(var[1].attrib["unit"]),
                                bounds = var_bounds,
                                all_mf = [],
                                ident = str(var.attrib["ident"]))

        for mf_elem in var.iter("sef"):

            all_points = []
            is_linear = False
            for point in mf_elem.iter("point"):
                is_linear = True
                P = rbm.Point(float(point[0].text), float(point[1].text))
                all_points.append(P)
            if is_linear:
                if len(all_points) == 1:
                    the_shape = "one_point"
                elif len(all_points) == 2:
                    the_shape = "triangle"
                elif len(all_points) == 3:
                    if all_points[0].y == all_points[2].y:
                        the_shape = "triangle"
                    else:
                        the_shape = "trapeze"
                else:
                    assert len(all_points) == 4, "Unknown MF shape."
                    the_shape = "trapeze"
                one_mf = rbm.MF(label = str(mf_elem[0].text),
                              shape = the_shape,
                              var = one_variable,
                              points = all_points,
                              ident = str(mf_elem.attrib["ident"]))
            else:
                for gaus in mf_elem.iter("gaussian"):
                    deviation = float(gaus[1].text)
                    if deviation == 0:
                        one_point = rbm.Point(x = float(gaus[0].text), y = 1)
                        one_mf = rbm.MF(label = str(mf_elem[0].text),
                                      shape = "one_point",
                                      var = one_variable,
                                      points = [one_point],
                                      ident = str(mf_elem.attrib["ident"]))
                    else:
                        G = rbm.Gaussian(mean = float(gaus[0].text),
                                     deviation = float(gaus[1].text))
                        one_mf = rbm.MF(label = str(mf_elem[0].text),
                                      shape = "gaussian",
                                      var = one_variable,
                                      gaussian = G,
                                      ident = str(mf_elem.attrib["ident"]))

            one_variable.all_mf.append(one_mf)

        rule_base.var[one_variable.ident] = one_variable

    for rule in root.iter("rule"):
        idd = str(rule.attrib["ident"])
        one_rule = rbm.Rule(ident = idd,
                        premise = set(),
                        conclusion = set())
        assert len(one_rule.conclusion) == 0
        for premise in rule.iter("premise"):
            the_var = rule_base.var[str(premise[0].text)]
            for the_mf_item in the_var.all_mf:
                if the_mf_item.ident == str(premise[1].text):
                    the_mf = the_mf_item
                    break
            one_term = rbm.Term(var = the_var,
                            mf = the_mf)
            one_rule.premise.add(one_term)

        for conclusion in rule.iter("conclusion"):
            the_var = rule_base.var[str(conclusion[0].text)]
            for the_mf_item in the_var.all_mf:
                if the_mf_item.ident == str(conclusion[1].text):
                    the_mf = the_mf_item
                    break
            one_term = rbm.Term(var = the_var,
                            mf = the_mf)
            one_rule.conclusion.add(one_term)

        rule_base.rules[str(rule.attrib["ident"])] = one_rule

    rule_base.used_variables = rule_base.get_used_variables()

    return rule_base





def import_fispro(filepath):
    """
    Returns a rulebase object from a FisPro file

    Parameters
    ----------
    filepath : str
        path of a FisPro file.

    Returns
    -------
    rulebase
        a Rulebase object from fuzzic.interpretability.rulebase.py
    """

    def parse_key(line):
        i = 0
        while line[i] != "=":
            i += 1
        return str(line[:i])

    def parse_value(line):
        i = 0
        while line[i] != "=":
            i += 1
        return ast.literal_eval(line[i+1:])

    def process_variable(all_lines, indice_line, var_num):
        assert indice_line > 8, "Probably not a variable line (rule base description paragraph)."
        i = indice_line + 1
        while all_lines[i] != "\n":
            line = all_lines[i]
            t = parse_key(line)
            if t == "Name":
                the_label = parse_value(line)
            elif t == "Range":
                the_bounds = list(parse_value(line))
                one_variable = rbm.Variable(label = the_label,
                                        rulebase = None,
                                        unit = "N/A",
                                        bounds = the_bounds,
                                        all_mf = [],
                                        ident = "Var_" + str(var_num))
            elif t[:2] == "MF":
                value = parse_value(line)
                the_label = value[0]
                the_points_x = value[2]
                assert value[1] in ["SemiTrapezoidalInf","SemiTrapezoidalSup", "triangular", "trapezoidal", "gaussian"], "The shape is not known: " + str(value[1])

                if value[1] == "gaussian":
                    the_shape = "gaussian"
                    G = rbm.Gaussian(mean = the_points_x[0], deviation = the_points_x[1])
                    one_mf = rbm.MF(label = the_label,
                                  shape = the_shape,
                                  var = one_variable,
                                  gaussian = G,
                                  ident = "var_" + str(var_num) + "_sef_" + str(t[2]))
                else:
                    if value[1] == "SemiTrapezoidalInf":
                        P1 = rbm.Point(x = the_points_x[0], y = 1)
                        P2 = rbm.Point(x = the_points_x[1], y = 1)
                        P3 = rbm.Point(x = the_points_x[2], y = 0)
                        the_points = [P1, P2, P3]
                        the_shape = "trapeze"
                    elif value[1] == "SemiTrapezoidalSup":
                        P1 = rbm.Point(x = the_points_x[0], y = 0)
                        P2 = rbm.Point(x = the_points_x[1], y = 1)
                        P3 = rbm.Point(x = the_points_x[2], y = 1)
                        the_points = [P1, P2, P3]
                        the_shape = "trapeze"
                    elif value[1] == "triangular":
                       P1 = rbm.Point(x = the_points_x[0], y = 0)
                       P2 = rbm.Point(x = the_points_x[1], y = 1)
                       P3 = rbm.Point(x = the_points_x[2], y = 0)
                       the_points = [P1, P2, P3]
                       the_shape = "triangle"
                    elif value[1] == "trapezoidal":
                       P1 = rbm.Point(x = the_points_x[0], y = 0)
                       P2 = rbm.Point(x = the_points_x[1], y = 1)
                       P3 = rbm.Point(x = the_points_x[2], y = 1)
                       P4 = rbm.Point(x = the_points_x[3], y = 0)
                       the_points = [P1, P2, P3, P4]
                       the_shape = "trapeze"

                    one_mf = rbm.MF(label = the_label,
                                  shape = the_shape,
                                  var = one_variable,
                                  points = the_points,
                                  ident = "var_" + str(var_num) + "_sef_" + str(t[2]))

                one_variable.all_mf.append(one_mf)
            i += 1

        return one_variable, i

    def parse_variables(all_lines):
        var_dict = dict()
        num_var = 1
        i = 1
        while i < len(all_lines):
            line = all_lines[i]
            if all_lines[i] != "\n":
                t = line
                if t[:6] == "[Input" or t[:6] == "[Outpu":
                    var, i = process_variable(all_lines, i, num_var)
                    num_var += 1
                    var_dict[var.ident] = var
            i += 1
        return var_dict


    def process_rule(all_lines, indice_line, rule_num, var_dict):
        #assert all_lines[indice_line] == "[Rules]\n", "Not the rules line: " + str(all_lines[indice_line])
        idd = str("rule_" + str(rule_num))
        one_rule = rbm.Rule(ident = idd,
                        premise = set(),
                        conclusion = set())
        line = all_lines[indice_line]
        value = ast.literal_eval(line)
        for j in range(len(value)):
            if j < len(value) -1:
                mf_num = value[j] -1
                var_num = j + 1
                one_term = rbm.Term(var = var_dict["Var_" + str(var_num)],
                                mf = var_dict["Var_" + str(var_num)].all_mf[int(mf_num)])
                one_rule.premise.add(one_term)
            else:
                mf_num = value[j] -1
                var_num = j + 1
                one_term = rbm.Term(var = var_dict["Var_" + str(var_num)],
                                mf = var_dict["Var_" + str(var_num)].all_mf[int(mf_num)])
                one_rule.conclusion.add(one_term)
        return one_rule

    def parse_rules(all_lines, var_dict):
        rules_dict = dict()
        num_rule = 1
        i = 0
        while all_lines[i] != "[Rules]\n":
            i+=1
        line_str = i + 2
        while all_lines[line_str] != "\n":
            rule = process_rule(all_lines, line_str, num_rule, var_dict)
            rules_dict[rule.ident] = rule
            line_str += 1
            num_rule += 1

        return rules_dict

    with open(filepath, "r") as f:
        all_lines = f.readlines()

    var_dict = parse_variables(all_lines)
    rules_dict = parse_rules(all_lines, var_dict)

    r = rbm.Rulebase(rules = rules_dict,
                 all_var = var_dict,
                 label = parse_value(all_lines[1]))
    for key in r.var.keys():
        r.var[key].rulebase = r

    r.filename = os.path.basename(filepath)
    r.used_variables = r.get_used_variables()

    return r

