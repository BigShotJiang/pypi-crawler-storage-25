import argparse
import os
import sys
import shutil
import datetime
from fuzzic.study import study

def study_folder(folder_path):

    current_path = os.getcwd()
    study_name = folder_path
    study_folder = os.path.join(current_path, study_name)

    study.create_project(study_name = study_name, path = study_folder)

    dir_b = os.path.join(current_path, study_name, "rulebases")
    dir_a = study_folder

    # Name of the current script, used to skip it
    script_name = study_name


    # 3. Iterate and copy files
    copied_files = 0

    # List all elements (files and folders) in directory A
    for element_name in os.listdir(dir_a):
        element_path_a = os.path.join(dir_a, element_name)

        # Skip the current script and directories
        if element_name == script_name:
            continue

        if os.path.isfile(element_path_a) and (element_name.lower().endswith('.xml') or element_name.lower().endswith('.fis')):
            try:
                dest_path_b = os.path.join(dir_b, element_name)
                shutil.copy2(element_path_a, dest_path_b)
                os.remove(element_path_a)
                copied_files += 1
            except Exception as e:
                print(f"Error while copying {element_name}: {e}")

    if copied_files == 0:
        print("No rulebase found in the format XML.")
    else:
        S = study.Study(ref_study = study_name, path = folder_path)
        S.evaluate()
        S.generate_dashboard()


def study_file(file):
    current_path = os.getcwd()
    study_name = os.path.splitext(file)[0]
    destination_path = os.path.join(current_path, study_name)
    file_path = os.path.join(current_path, file)
    if os.path.isdir(destination_path):
        time = datetime.datetime.today().strftime('%d-%m-%Y--%H:%M:%S')
        destination_path = os.path.join(current_path, time + "_" + study_name)
    os.mkdir(destination_path)
    file_path_destination = os.path.join(destination_path, file)
    shutil.copy2(file_path, file_path_destination)
    study_folder(destination_path)


def main():
    parser = argparse.ArgumentParser(
        description="Fuzzic: A library for analyzing and visualizing fuzzy rule bases."
    )

    # 1. Add the main positional argument for the path
    parser.add_argument(
        'path',
        type=str,
        help='The path to the file or folder to be analyzed.'
    )

    args = parser.parse_args()
    input_path = args.path

    # 2. Check if the path exists
    if not os.path.exists(input_path):
        sys.exit(f"Error: Path not found: {input_path}")

    # 3. Determine if the path is a file or a folder
    if os.path.isdir(input_path):
        study_folder(input_path)
    elif os.path.isfile(input_path):
        study_file(input_path)
    else:
        # Handle cases like broken symlinks, special devices, etc.
        sys.exit(f"Error: The path '{input_path}' is neither a file nor a folder.")

if __name__ == "__main__":
    main()
