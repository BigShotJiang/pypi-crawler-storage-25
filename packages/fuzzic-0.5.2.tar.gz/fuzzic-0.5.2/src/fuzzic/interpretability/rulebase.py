import random
import numpy as np
import os
import copy
from fuzzic.configuration.config import config
import fuzzic.visualization.plot as plot
import fuzzic.interpretability.dataset as dataset


# ALL CLASSES NEEDED TO MANAGE FUZZY SETS AND FUZZY RULE BASES ================

class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        
    def __repr__(self):
        return "point" + "_" + str(self.x) + str(self.y)


class Line:
    def __init__(self, p1, p2):
        self.p1 = p1
        self.p2 = p2

    def __repr__(self):
        return "line" + "_" + repr(self.p1) + "_" + repr(self.p2)

    def forward(self, x):
        x1 = self.p1.x
        x2 = self.p2.x
        y1 = self.p1.y
        y2 = self.p2.y
        if x1 == x2:
            return y2
        m = (y2-y1)/(x2-x1)
        p = y1 - m * x1
        return m*x + p

class Gaussian:
    def __init__(self, mean, deviation):
        self.mean = mean
        self.deviation = deviation
        self.height = self.forward(self.mean)
    
    def __repr__(self):
        return "gaussian" + "_" + str(self.deviation) + "_" + str(self.mean)
    
    def forward(self,x):
        return  np.exp(-(x - self.mean)**2 / (2 * self.deviation**2))


# ==================================

class Variable:
    def __init__(self, label, rulebase, unit, bounds, all_mf = None, ident = None, prototypes = None):
        self.ident = ident
        self.label = label
        self.rulebase = rulebase
        self.unit = unit
        self.bounds = bounds
        self.all_mf = [] if all_mf is None else all_mf
        self.space_discretization = config.space_discretization
        self.universe = self.define_linear_space(xmin = self.bounds[0], 
                                               xmax = self.bounds[1])
    
    def __repr__(self):
        return "variable_" + str(self.ident) + "_" + str(self.label) + "_" + str(self.unit) + "_" + repr(self.bounds)
    
    def display(self):
        print("\t====================")
        print("\tVARIABLE : " + str(self.ident))
        print("\tLabel :", self.label)
        print("\tUnit :", self.unit)
        print("\tBounds : from " + str(self.bounds[0]) + " to " + str(self.bounds[1]) + " " + str(self.unit))
        print()
    
    def define_linear_space(self, xmin, xmax):
        total_div = self.space_discretization
        return np.linspace(xmin, xmax, total_div).tolist()
    
    def find_mf(self, label_mf):
        for i in range(len(self.all_mf)):
            s = self.all_mf[i]
            if s.label == label_mf:
                return s
        return None
    
    def plot(self):
        captions = [mf.label for mf in self.all_mf]
        plot.plot_membership_functions(self.all_mf, captions, self.label, step=(self.bounds[1]-self.bounds[0])//10, unit=self.unit)




# =============================================================================

class MF:
    # fuzzy set class
    def __init__(self, label, shape, var = None, points = None, gaussian = None, ident = None):
        assert gaussian is not None or points is not None, "The MF has no shape."
        self.ident = ident
        self.label = label
        self.shape = shape
        self.points = points
        self.gaussian = gaussian
        self.var = var
        self._cardinal = self.cardinal()
        if self.gaussian is not None:
            self.peak_x = self.gaussian.mean
            self.peak_y = self.gaussian.height
        else:
            self.peak_y = max([self.points[i].y for i in range(len(self.points))])
            self.peak_x = min([self.points[i].x for i in range(len(self.points)) if self.points[i].y == self.peak_y])

    def __repr__(self):
        if self.shape == "gaussian":
            return "mf_" + str(self.ident) + "_" + str(self.label) + "_" + str(self.shape) + "_" + repr(self.gaussian) + "_" + repr(self.var)
        else:
            return "mf_" + str(self.ident) + "_" + str(self.label) + "_" + str(self.shape) + "_" + repr(self.points) + "_" + repr(self.var)
    
    def display(self):
        print("\t\tMF : " + self.ident)
        print("\t\tLabel : " + str(self.label))
        if self.shape == "gaussian":
            print("\t\t" + str(self.shape) + " --> mean : " + str(self.gaussian.mean) + " and deviation : " + str(self.gaussian.deviation))
        else:
            print("\t\t" + str(self.shape) + " --> " + repr([[p.x, p.y] for p in self.points]))
        print()
    
    def cardinal(self):
        U = 0
        for x in self.var.universe:
            y1 = self.forward(x)
            U += y1
        return U
    
    def forward(self, x):
        assert x >= self.var.bounds[0] and x <= self.var.bounds[1], "x = " + str(x) + " outside universe " + repr(self.var.bounds)
        if self.shape == "gaussian":
            return self.gaussian.forward(x)
        else:
            for po in self.points:
                if po.x == x:
                    return po.y
                
            if self.shape == "one_point":
                if x != self.points[0].x:
                    return 0
                else:
                    return self.points[0].y
            else:
                all_points = copy.deepcopy(self.points)
                slots = [all_points[j].x for j in range (len(all_points))]
                
                if all_points[0].x > self.var.bounds[0]:
                    slots = [self.var.bounds[0]] + slots
                    P = Point(x = self.var.bounds[0], y = all_points[0].y)
                    all_points = [P] + all_points
                
                if all_points[len(all_points)-1].x < self.var.bounds[1]:
                    slots = slots +[self.var.bounds[1]]
                    P = Point(x = self.var.bounds[1], y = all_points[len(all_points)-1].y)
                    all_points =  all_points + [P]
                
                i = 0
                while x > slots[i+1]:
                    i = i+1
                #print(str(x) +  " is between " + str(slots[i]) + " and " + str(slots[i+1]))
    
                p1 = all_points[i]
                p2 = all_points[i+1]
                d = Line(p1, p2)
                #print("d is the line through points (" + str(p1.x) + " " + str(p1.y) + ") and (" + str(p2.x) + " " + str(p2.y) + ").")
                return d.forward(x)
    
    def starting_point(self):
        assert self.shape != "gaussian", "not possible to generate linear functions since functions are gaussian."
        if self.points[0].y > 0:
            return self.points[0]
        else:
            return self.points[1]
    
    def linear_functions(self):
        assert self.shape != "gaussian", "not possible to generate linear functions since functions are gaussian."
        i = 0
        L = []
        while i < len(self.points)-1:
            if self.points[i].y != self.points[i+1].y:
                d = Line(self.points[i], self.points[i+1])
                L.append(d)
            i += 1
        return L


# =============================================================================

class Term:
    def __init__(self, var, mf):
        self.var = var
        self.mf = mf

    def __repr__(self):
        return "term_" + repr(self.var) + repr(self.mf)

    def forward(self,x):
        return self.mf.forward(x)
    
    
# =============================================================================

class Rule:
    def __init__(self, ident = None, premise =None, conclusion = None):
        self.ident = ident
        self.premise = set() if premise is None else premise
        self.conclusion = set() if conclusion is None else conclusion
        
    def __repr__(self):
        return "rule_" + repr(self.ident) + repr(self.premise) + "_" + repr(self.conclusion)
    
    def display(self):
        print("Rule : " + str(self.ident))
        p = self.premise
        stri = "If "
        for pre in p:
            stri += str(pre.var.label) + " is " + str(pre.mf.label) + " and "
        stri = stri[:len(stri)-5]
        stri += ", then "
        c = self.conclusion
        for concl in c:
            stri += str(concl.var.label) + " is " + str(concl.mf.label) + " and "
        stri = stri[:len(stri)-5]
        stri += "."
        print(stri)


# =============================================================================
    
class Rulebase:
    def __init__(self, rules = None, all_var = None, label = None):
        self.filename = None
        self.label = label
        self.rules = dict() if rules is None else rules
        self.var = dict() if all_var is None else all_var
        self.dataset = None
        self.used_variables = None
        self.study = None
        self.interpretability = None
    
    def __repr__(self):
        return "rulebase_" + repr(self.label) + repr({k: self.rules[k] for k in sorted(self.rules)})
    
    def get_var(self, ident):
        for key in self.var.keys():
            if self.var[key].ident == ident:
                return self.var[key]
        return None
    
    def get_all_mf(self):
        the_mf = []
        for key in self.var.keys():
            var = self.var[key]
            for s in var.all_mf:
                the_mf.append(s)
        return the_mf
    
    # Gaussian sampling: generates synthetic data from scratch using a normal
    # distribution centered on each variable's bounds. Used when no observed
    # dataset is available. Complementary to KDE resampling in
    # Dataset/MultivariateSampler (see dataset.py), which generates new samples
    # that follow the distribution of an existing observed dataset.
    def create_dataset(self):
        print("Creating dataset...")
        all_var = []
        for key in self.var.keys():
            the_var = self.var[key]
            one_var = [the_var.label]
            for i in range(config.sample_size):
                #x = random.uniform(the_var.bounds[0],the_var.bounds[1])
                mu = (the_var.bounds[0] + the_var.bounds[1]) / 2
                sigma = (the_var.bounds[1] - the_var.bounds[0]) / 6
                x = random.gauss(mu, sigma)
                if x < the_var.bounds[0]:
                    x = the_var.bounds[0]
                if x > the_var.bounds[1]:
                    x = the_var.bounds[1]
                one_var.append(x)
            all_var.append(one_var)
        all_var = np.transpose(all_var).tolist()
        self.dataset = dataset.Dataset(all_var, self)
        return self.dataset
            
    def get_dataset(self):
        if self.dataset is None:
            dataset_path = os.path.join(self.study.study_directory, "datasets")
            dataset_file = os.path.join(dataset_path, "one_dataset.data")
            if os.path.isfile(dataset_file):
                # Lazy import to avoid a circular import: import_manager imports rulebase at module load.
                from fuzzic.data_management import import_manager
                self.dataset = import_manager.import_dataset(dataset_file, self)
            else:
                self.dataset = self.create_dataset()
        return self.dataset
    
    def update_dataset(self, the_dataset):
        self.dataset = dataset.Dataset(the_dataset, self)
        
    def plot_variables(self):
        for key in self.var.keys():
            self.var[key].plot()
    
    def get_used_variables(self):
        used_vars = dict()
        rules = self.rules
        for key in rules.keys():
            rule = rules[key]
            for term in rule.premise:
                used_vars[term.var.ident] = self.get_var(term.var.ident)
            for term in rule.conclusion:
                used_vars[term.var.ident] = self.get_var(term.var.ident)
        return used_vars
    
    def display(self):
        print("====================")
        print("\tRULE BASE : " + self.label)
        print()
        for key in self.var.keys():
            v = self.var[key]
            v.display()
            for mf in self.var[key].all_mf:
                mf.display()
        for key in self.rules.keys():
            rule = self.rules[key]
            print("====================")
            rule.display()
        print("\n")








