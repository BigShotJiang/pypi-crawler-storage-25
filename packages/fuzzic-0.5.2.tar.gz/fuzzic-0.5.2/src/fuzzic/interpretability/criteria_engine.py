import numpy as np
from fuzzic.configuration.config import config
from fuzzic.interpretability.interpretability_manager import CRITERIA

# CRITERIA SCORING INFRASTRUCTURE =============================================

def rounding(value):
    """
    Returns the rounded value of an integer

    Parameters
    ----------
    value : float
        a real value

    Returns
    -------
    value : float
        the rounded value with the number of decimals given in configuration object
    """

    return round(value, config.rounding)

def criteria_aggregator(collection):
    """
    Aggregate the scores in the collection according to the config.criteria_aggregation method
    to establish one global score for the criterion

    Parameters
    ----------
    collection : list
        a list of scores to aggregate

    Returns
    -------
    value : float
        The aggregated score for a criterion
    """
    if config.criteria_aggregation == "average":
        return np.average(collection)
    elif config.criteria_aggregation == "worst":
        return min(collection)
    else:
        raise ValueError(f"Unknown criteria_aggregation method: '{config.criteria_aggregation}'. "
                         f"Valid options: 'average', 'worst'.")

def score_pooling(dictionary_of_scores, type="all"):
    """
    Return a global pooling of criteria scores given.
    Parameters
    ----------
    dictionary_of_scores : dictionary of criteria results
    type : str, optional
        Subset of active criteria to pool: "all" (default), "semantics", or "complexity".
    Returns
    -------
    value : float or None
        The global interpretability score of the selected criteria, to maximize.
        Returns None if no active criterion matches the requested type.
    """
    if type not in ("all", "semantics", "complexity"):
        raise ValueError(f"Unknown type: '{type}'. "
                         f"Valid options: 'all', 'semantics', 'complexity'.")

    scores = [dictionary_of_scores[key]["score"] for key in dictionary_of_scores.keys()]
    assert min(scores) >= 0 and max(scores) <= 1, "scores are not normalized"

    active_criteria = [c for c in CRITERIA if c.active]
    if type != "all":
        active_criteria = [c for c in active_criteria if c.type == type]
    if not active_criteria:
        return None
    scores_list = [dictionary_of_scores[c.criterion_name]["score"] for c in active_criteria]
    weights_list = [c.weight for c in active_criteria]
    total_weight = sum(weights_list)
    norm_weights = [w / total_weight for w in weights_list]  # normalization a posteriori

    # ── 1. worst ──────────────────────────────────────────────────────────────
    if config.criteria_pooling == "worst":
        return min(scores_list)

    # ── 2. average (weighted) ─────────────────────────────────────────────────
    elif config.criteria_pooling in ["weighted_sum", "weighted_average", "average"]:
        return sum(s * w for s, w in zip(scores_list, norm_weights))

    # ── 3. weighted median ────────────────────────────────────────────────────
    elif config.criteria_pooling == "weighted_median":
        # Sort by score, then find the first index where cumulative weight >= 0.5
        sorted_pairs = sorted(zip(scores_list, norm_weights), key=lambda x: x[0])
        cumulative = 0.0
        for s, w in sorted_pairs:
            cumulative += w
            if cumulative >= 0.5:
                return s
        return sorted_pairs[-1][0]  # fallback (floating-point safety)

    else:
        raise ValueError(f"Unknown criteria_pooling method: '{config.criteria_pooling}'. "
                         f"Valid options: 'worst', 'average', "
                         f"'weighted_median'.")
