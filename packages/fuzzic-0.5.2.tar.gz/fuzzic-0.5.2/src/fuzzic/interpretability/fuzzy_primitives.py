from fuzzic.configuration.config import config

# FUZZY LOGIC OPERATIONS ======================================================

def t_norm(x, y):
    """
    Return the t-norm of two values.

    Parameters
    ----------
    x : float
        a real value
    y : float
        a real value

    Returns
    -------
    value : float
        The t-norm of x and y according to the config.t_norm method
    """
    assert config.t_norm in ["zadeh", "probabiliste", "lukasiewicz", "drastique"], "t norm unknown"
    if config.t_norm == "zadeh":
        return min(x,y)
    elif config.t_norm == "probabiliste":
        return x * y
    elif config.t_norm == "lukasiewicz":
        return max(x + y - 1, 0)
    elif config.t_norm == "drastique":
        if y == 1:
            return x
        if x == 1:
            return y
        else:
            return 0

def t_conorm(x, y):
    """
    Return the t-conorm of two values.

    Parameters
    ----------
    x : float
        a real value
    y : float
        a real value

    Returns
    -------
    value : float
        The t-conorm of x and y according to the config.t_conorm method
    """
    valid = ["dual", "zadeh", "probabiliste", "lukasiewicz", "drastique"]
    assert config.t_conorm in valid, "t conorm unknown"
    mode = config.t_conorm
    if mode == "dual":
        return 1 - t_norm(1 - x, 1 - y)
    if mode == "zadeh":
        return max(x,y)
    elif mode == "probabiliste":
        return x + y - (x * y)
    elif mode == "lukasiewicz":
        return min(x + y, 1)
    elif mode == "drastique":
        if y == 0:
            return x
        if x == 0:
            return y
        else:
            return 1

def difference(x, y): # A \ B = A intersect B_complement
    """
    Return the t-norm of x and 1-y.

    Parameters
    ----------
    x : float
        a real value
    y : float
        a real value

    Returns
    -------
    value : float
        The t-norm of x and 1-y according to the config.t_norm method
    """

    assert config.t_norm in ["zadeh", "probabiliste", "lukasiewicz", "drastique"], "t-norm unknown"
    return t_norm(x, 1-y)

def check_activation(rule, labels, the_data):
    """
    Verify if a rule is activated by the data.

    Parameters
    ----------
    rule : Rule object
        a real value
    labels : list
        ordered list of the labels of a dataset
    the_data : float
        ordered list of one data of a dataset among all labels

    Returns
    -------
    value : boolean
        True if the t-norm of the activations of all terms or the given rule is greater than the threshold (see config)
    """

    final_result = None
    threshold = config.activation_rule_threshold
    for term in rule.premise:
        idx = labels.index(term.var.label)
        x = float(the_data[idx])
        result = term.mf.forward(x)
        if final_result is None:
            final_result = result
        else:
            final_result = t_norm(final_result, result)
    return final_result > threshold

def is_greater_than(mf1, mf2):
    """
    Verify if the fuzzy set mf1 is greater than mf2 with the order relationship of the configuration object.

    Parameters
    ----------
    mf1 : MembershipFunction object
        a fuzzy set object
    mf2 : MembershipFunction object
        a fuzzy set object

    Returns
    -------
    value : boolean
        True if mf1 is greater than mf2
    """

    order_relationship = config.order_relationship
    assert order_relationship in ["min_kernel"], "unknown order relationship."
    if order_relationship == "min_kernel":
        a = mf1.peak_x
        b = mf2.peak_x
        return a >= b


# SIMILARITY MEASURES =========================================================

def similarity(mf1, mf2):
    """
    Computes the similarity between two fuzzy sets.

    Parameters
    ----------
    mf1 : MembershipFunction object
        a fuzzy set object
    mf2 : MembershipFunction object
        a fuzzy set object

    Returns
    -------
    float
        Similarity result (from config object) of the two given fuzzy sets.
    """

    if config.similarity == "dice":
        return dice(mf1, mf2)

    elif config.similarity == "jaccard":
        return jaccard(mf1, mf2)

    elif config.similarity == "tversky":
        return tversky(mf1, mf2, config.similarity_param["alpha"], config.similarity_param["beta"])


def dice(mf1, mf2):
    """
    Computes the Dice similarity between two fuzzy sets.

    Parameters
    ----------
    mf1 : MembershipFunction object
        a fuzzy set object
    mf2 : MembershipFunction object
        a fuzzy set object

    Returns
    -------
    float
        Dice similarity result of the two given fuzzy sets.
    """

    if mf1.var.bounds[0] == mf2.var.bounds[0] and mf1.var.bounds[1] == mf2.var.bounds[1]:
        U = 0
        V = 0
        inter_UV = 0
        for x in mf1.var.universe:
            y1 = mf1.forward(x)
            y2 = mf2.forward(x)
            U += y1
            V += y2
            inter_UV += t_norm(y1, y2)
        if U == 0 and V == 0:
            return 0
        else:
            dice_result = (2 * inter_UV) / (U + V)
            return dice_result
    else:
        return -1


def jaccard(mf1, mf2):
    """
    Computes the Jaccard similarity between two fuzzy sets.

    Parameters
    ----------
    mf1 : MembershipFunction object
        a fuzzy set object
    mf2 : MembershipFunction object
        a fuzzy set object

    Returns
    -------
    float
        Jaccard similarity result of the two given fuzzy sets.
    """

    if mf1.var.bounds[0] == mf2.var.bounds[0] and mf1.var.bounds[1] == mf2.var.bounds[1]:

        inter_UV = 0
        union_UV = 0
        for x in mf1.var.universe:
            y1 = mf1.forward(x)
            y2 = mf2.forward(x)
            inter_UV += t_norm(y1, y2)
            union_UV += t_conorm(y1, y2)
        if union_UV == 0:
            return 0
        else:
            result = inter_UV / union_UV
            return result
    else:
        return -1


def tversky(mf1, mf2, alpha, beta):
    """
    Computes the Tversky similarity between two fuzzy sets.

    Parameters
    ----------
    mf1 : MembershipFunction object
        a fuzzy set object
    mf2 : MembershipFunction object
        a fuzzy set object

    Returns
    -------
    float
        Tversky similarity result of the two given fuzzy sets.
    """

    if mf1.var.bounds[0] == mf2.var.bounds[0] and mf1.var.bounds[1] == mf2.var.bounds[1]:
        inter_UV = 0
        U_minus_V = 0
        V_minus_U = 0
        for x in mf1.var.universe:
            y1 = mf1.forward(x)
            y2 = mf2.forward(x)
            U_minus_V += difference(y1, y2)
            V_minus_U += difference(y2, y1)
            inter_UV += t_norm(y1, y2)
        div = inter_UV + alpha * U_minus_V + beta * V_minus_U
        if div == 0:
            return 0
        else:
            result = inter_UV / div
            return result
    else:
        return -1
