import copy
import fuzzic.interpretability.criteria_engine as criteria_engine
from fuzzic.interpretability.interpretability_manager import criterion, CRITERIA

def interpretability(rulebase):
    all_var = rulebase.used_variables
    total = 0
    nb_erreurs = 0
    war = ""
    all_results = []

    for key in all_var.keys():
        var = all_var[key]
        all_extremas = copy.copy(var.bounds)
        total += len(all_extremas)
        Tv = var.all_mf
        for extrema in all_extremas:
            if max([mf.forward(extrema) for mf in Tv]) != 1:
                war ="Variable \"" + str(var.label) + "\" with input " + str(extrema) + " does not belong to a fuzzy set with membership degree 1."
                nb_erreurs += 1
        nb_ok = total - nb_erreurs
        score = (nb_ok / total)
        all_results.append(score)

    result = criteria_engine.criteria_aggregator(collection=all_results)
    dico = {"warning" : war, "score" : criteria_engine.rounding(result)}
    return dico

CRITERIA.append(criterion(criterion_name="extremas", category="linguistic variables",
          active=True, func_interpretability=interpretability,
          criterion_type="semantics"))
