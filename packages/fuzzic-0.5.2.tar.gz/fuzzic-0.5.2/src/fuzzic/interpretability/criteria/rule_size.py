import fuzzic.interpretability.criteria_engine as criteria_engine
from fuzzic.interpretability.interpretability_manager import criterion, CRITERIA
from fuzzic.configuration.config import config

def interpretability(rulebase):
    '''
    If the size of the rule is less than the interpretability threshold number (see config), then the rule contributes to interpretability with 100%.
    If not, its contribution is interpretability threshold number / length.
    '''
    rules = rulebase.rules
    collection = []
    threshold = config.interpretability_threshold_number
    for key in rules.keys():
        length = len(rules[key].premise) + len(rules[key].conclusion)
        if length <= threshold:
            collection.append(1)
        else:
            collection.append(threshold/length)

    result = criteria_engine.criteria_aggregator(collection = collection)
    dico = {"warning" : "", "score" : result}
    return dico

CRITERIA.append(criterion(criterion_name="rule size", category="fuzzy rule",
          active=True, func_interpretability=interpretability,
          criterion_type="complexity"))
