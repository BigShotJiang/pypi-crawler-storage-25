import fuzzic.interpretability.criteria_engine as criteria_engine
from fuzzic.interpretability.interpretability_manager import criterion, CRITERIA

def interpretability(rulebase):
    '''
    Computes the proportion of unimodal fuzzy sets.
    '''
    all_mf = [mf for key in rulebase.used_variables
               for mf in rulebase.var[key].all_mf]
    total = len(all_mf)
    if total == 0:
        return {"warning" : "", "score" : 1.0}
    count = len(all_mf)
    war = ""
    for mf in all_mf:
        if mf.peak_y != 1:
            count = count - 1
            if war == "":
                war = "Fuzzy set: \"" + mf.label + "\" from variable: \"" + mf.var.label + "\" is not unimodal."
    dico = {"warning" : war, "score" : criteria_engine.rounding(count / total)}
    return dico

CRITERIA.append(criterion(criterion_name="unimodality", category="fuzzy sets",
          active=True, func_interpretability=interpretability,
          criterion_type="semantics"))
