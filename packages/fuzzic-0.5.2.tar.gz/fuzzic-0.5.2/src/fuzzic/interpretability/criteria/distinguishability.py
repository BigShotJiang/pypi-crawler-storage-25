import fuzzic.interpretability.fuzzy_primitives as fuzzy_primitives
import fuzzic.interpretability.criteria_engine as criteria_engine
from fuzzic.interpretability.interpretability_manager import criterion, CRITERIA

def interpretability(rulebase):
    all_var = rulebase.used_variables
    all_results = []
    for key in all_var.keys():
        var = all_var[key]
        Tv = var.all_mf
        var_results = []
        for i in range(len(Tv)-1):
            for j in range(i+1, len(Tv)):
                sim = fuzzy_primitives.similarity(Tv[i], Tv[j])
                var_results.append(1 - sim)
        if len(var_results) == 0:
            all_results.append(1)
        else:
            all_results.append(criteria_engine.criteria_aggregator(collection=var_results))
    if len(all_results) == 0:
        result = 1
    else:
        result = criteria_engine.criteria_aggregator(collection = all_results)
    dico = {"warning" : "", "score" : criteria_engine.rounding(result)}
    return dico

CRITERIA.append(criterion(criterion_name="distinguishability", category="linguistic variables",
          active=True, func_interpretability=interpretability,
          criterion_type="semantics"))
