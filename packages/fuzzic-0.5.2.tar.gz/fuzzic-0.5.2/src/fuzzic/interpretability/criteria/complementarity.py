import fuzzic.interpretability.criteria_engine as criteria_engine
from fuzzic.configuration.config import config
from fuzzic.interpretability.interpretability_manager import criterion, CRITERIA
import numpy as np

def interpretability(rulebase):
    '''
    Discretise the universe of all variables and establish for each input if
    complementarity is filled.
    Collection contains all such inputs.
    '''
    all_var = rulebase.used_variables
    war = ""
    all_results = []
    for key in all_var.keys():
        var = all_var[key]
        Tv = var.all_mf
        respect_of_complementarity = []
        for x in var.universe:
            total_sum = 0
            for S in Tv:
                total_sum += S.forward(x)
            total_sum = criteria_engine.rounding(total_sum)
            if abs(total_sum - 1) > config.precision:
                respect_of_complementarity.append(0)
                if war == "":
                    war += "Complementarity not filled for variable \"" + str(var.label) + "\" with input : " + str(round(x, 2)) + ", the sum of membership values is: " + str(round(total_sum, 2))
            else:
                respect_of_complementarity.append(1)
        percentage_complementarity = np.mean(respect_of_complementarity)
        all_results.append(percentage_complementarity)

    result = criteria_engine.criteria_aggregator(collection = all_results)
    score = criteria_engine.rounding(result)
    dico = {"warning" : war, "score" : score}
    return dico

CRITERIA.append(criterion(criterion_name="complementarity", category="linguistic variables",
          active=True, func_interpretability=interpretability,
          criterion_type="semantics"))
