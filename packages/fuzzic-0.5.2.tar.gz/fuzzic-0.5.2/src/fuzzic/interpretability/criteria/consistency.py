import fuzzic.interpretability.fuzzy_primitives as fuzzy_primitives
import fuzzic.interpretability.criteria_engine as criteria_engine
from fuzzic.interpretability.interpretability_manager import criterion, CRITERIA

def interpretability(rulebase):
    '''
    If 2 premises give different conclusions, compute the similarity between the conclusions (must be maximised for consistency).
    '''

    def check_two_premises(pre1, pre2):
        representation1 = hash(repr({t.mf.var.label + t.mf.label for t in pre1}))
        representation2 = hash(repr({t.mf.var.label + t.mf.label for t in pre2}))
        return representation1 == representation2

    def check_same_premise_give_same_conclusion(rules):
        all_results = []
        war = ""
        for i in range(len(rules)-1):
            for j in range(i+1, len(rules)):
                if check_two_premises(rules[i].premise, rules[j].premise):
                    for t1 in rules[i].conclusion:
                        for t2 in rules[j].conclusion:
                            if t1.var.ident == t2.var.ident and t1.mf.ident != t2.mf.ident:
                                sim = fuzzy_primitives.similarity(t1.mf, t2.mf)
                                all_results.append(sim)
                                if sim < 1 and war == "":
                                    war = "Rule \"" + rules[i].ident + "\" and \"" + rules[j].ident + "\" are unconsistents. (For conclusion variable \"" + t1.mf.var.label + "\", fuzzy sets: \"" + t1.mf.label + "\" and \"" + t2.mf.label + "\"have a similarity of " + str(round(sim, 2)) + ")"

        if len(all_results) == 0:
            all_results = [1]
        #print("all_results",all_results)
        return all_results, war

    rules = [rulebase.rules[key] for key in rulebase.rules.keys()]
    all_results, war = check_same_premise_give_same_conclusion(rules)
    score = criteria_engine.criteria_aggregator(collection = all_results)
    dico = {"warning" : war, "score" : criteria_engine.rounding(score)}
    return dico

CRITERIA.append(criterion(criterion_name="consistency", category="fuzzy rule base",
          active=True, func_interpretability=interpretability,
          criterion_type="semantics"))
