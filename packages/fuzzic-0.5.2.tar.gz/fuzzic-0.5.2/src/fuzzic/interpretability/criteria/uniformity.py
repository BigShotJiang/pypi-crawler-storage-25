import fuzzic.interpretability.criteria_engine as criteria_engine
from fuzzic.interpretability.interpretability_manager import criterion, CRITERIA

def interpretability(rulebase):
    '''
    For all variables, computes the minimal cardinal / the maximum cardinal.
    '''
    all_var = rulebase.var
    all_results = []
    for key in all_var.keys():
        var = all_var[key]
        Tv = var.all_mf
        all_cardinals = [s._cardinal for s in Tv]
        result = min(all_cardinals) / max(all_cardinals)
        all_results.append(result)

    final_result = criteria_engine.criteria_aggregator(collection = all_results)
    score = criteria_engine.rounding(final_result)
    dico = {"warning" : "", "score" : score}
    return dico

CRITERIA.append(criterion(criterion_name="uniformity", category="linguistic variables",
          active=True, func_interpretability=interpretability,
          criterion_type="semantics"))
