import fuzzic.interpretability.criteria_engine as criteria_engine
from fuzzic.interpretability.interpretability_manager import criterion, CRITERIA
from fuzzic.configuration.config import config

def interpretability(rulebase):
    alpha = config.alpha_coverage
    all_var = rulebase.used_variables
    war = ""
    all_results = []

    for key in all_var.keys():
        var = all_var[key]
        Tv = var.all_mf
        total_inputs = 0
        total_uncovered = 0
        for x in var.universe:
            total_inputs += 1
            cover = False
            for S in Tv:
                if S.forward(x) > alpha:
                    cover = True
            if cover is False:
                total_uncovered += 1
                if war == "":
                    war +=  "Variable \"" + str(var.label) + "\" with input " + str(criteria_engine.rounding(x)) + " is not covered by a fuzzy set with a membership degree of at least: " + str(alpha)
        total_covered = total_inputs - total_uncovered
        all_results.append(total_covered / total_inputs)

    result = criteria_engine.criteria_aggregator(collection=all_results)
    dico = {"warning" : war, "score" : criteria_engine.rounding(result)}
    return dico

CRITERIA.append(criterion(criterion_name="coverage", category="linguistic variables",
          active=True, func_interpretability=interpretability,
          criterion_type="semantics"))
