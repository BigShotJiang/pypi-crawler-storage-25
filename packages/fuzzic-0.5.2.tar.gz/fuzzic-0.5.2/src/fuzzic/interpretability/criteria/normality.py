import fuzzic.interpretability.criteria_engine as criteria_engine
from fuzzic.interpretability.interpretability_manager import criterion, CRITERIA

def interpretability(rulebase):
    total = 0
    count = 0
    war = ""
    all_var = rulebase.used_variables
    for key in all_var.keys():
        all_mf = rulebase.var[key].all_mf
        for mf in all_mf:
            total += 1
            if mf.peak_y < 1:
                war ="Fuzzy set: \"" + str(mf.label) + "\" from variable \"" + str(mf.var.label) + "\" has a height below 1 (height: " + str(mf.peak_y) + ")"
                count += 1

    dico = dict()
    dico["warning"] = war
    dico["score"] = criteria_engine.rounding( (total - count) / total)
    return dico

CRITERIA.append(criterion(criterion_name="normality", category="fuzzy sets",
          active=True, func_interpretability=interpretability,
          criterion_type="semantics"))
