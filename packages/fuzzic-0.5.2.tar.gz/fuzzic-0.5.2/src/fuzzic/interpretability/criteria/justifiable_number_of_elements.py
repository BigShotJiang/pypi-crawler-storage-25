import fuzzic.interpretability.criteria_engine as criteria_engine
from fuzzic.interpretability.interpretability_manager import criterion, CRITERIA
from fuzzic.configuration.config import config


def interpretability(rulebase):
    '''
    If the number of elements for a variable is less than the interpretability threshold number (see config), then it contributes to interpretability with 100%.
    If not, its contribution is interpretability threshold number / size of partition.
    '''
    all_results = []
    threshold = config.interpretability_threshold_number
    for key in rulebase.var.keys():
        var = rulebase.var[key]
        Tv = var.all_mf
        taille = len(Tv)
        assert taille > 0, "Variable" + str(var.label) + "has no fuzzy set"
        if taille <= threshold:
            all_results.append(1)
        else:
            all_results.append(threshold/taille)
    result = criteria_engine.criteria_aggregator(collection = all_results)
    dico = {"warning" : "", "score" : criteria_engine.rounding(result)}
    return dico
CRITERIA.append(criterion(criterion_name="justifiable number of elements", category="linguistic variables",
          active=True, func_interpretability=interpretability,
          criterion_type="complexity"))
