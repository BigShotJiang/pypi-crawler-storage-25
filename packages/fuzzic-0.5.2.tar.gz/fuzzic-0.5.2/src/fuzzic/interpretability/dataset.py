import random
import numpy as np
import os
import copy
from fuzzic.configuration.config import config
import fuzzic.data_management.import_manager as import_manager
import fuzzic.visualization.plot as plot
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats
    

class Dataset:
    def __init__(self, the_dataset, rulebase):
        
        self.rulebase = rulebase
        
        if type(the_dataset) is list:
            self.origin_labels = the_dataset[0]
            self.origin_data = the_dataset[1:]
            self.origin_df = pd.DataFrame(data=self.origin_data, columns=self.origin_labels, dtype=np.float64)
        else:
            assert isinstance(the_dataset, pd.DataFrame), "The dataset is neither a list nor a DataFrame."
            self.origin_labels = the_dataset.columns.tolist()
            self.origin_data = the_dataset.values.tolist()
            self.origin_df = the_dataset.astype(np.float64)
        
        bounds = dict()
        for key in self.rulebase.var.keys():
            var = self.rulebase.var[key]
            bounds[var.label] = var.bounds

        self.sampler = MultivariateSampler(self.origin_df, bounds)
        
        df_new, labels, data = self.sample()
        self.df = df_new
        self.labels = labels
        self.data = data
        
        # print("Correlation of generated data (should be close to the original):")
        # print(self.df.corr())
    
    
    def sample(self):
        n = config.sample_size
        df_new = self.sampler.sample(n)
        labels = df_new.columns.tolist()
        data = df_new.values.tolist()
        return df_new, labels, data


    def display(self, label1, label2):
        """
        Display side-by-side scatter plots of two variables to compare
        original and generated data.

        Arguments:
        df_original  -- DataFrame of real data
        df_generated -- DataFrame of synthetic (sampled) data
        col_x        -- Column name for the X axis (str)
        col_y        -- Column name for the Y axis (str)
        """
        
        df_original = self.origin_df
        df_generated = self.df
        col_x = label1
        col_y = label2
        
        # 1. Verify that the columns exist
        for col in [col_x, col_y]:
            if col not in df_original.columns or col not in df_generated.columns:
                print(f"Error: Column '{col}' not found.")
                return

        # 2. Compute common axis limits (for a fair comparison)
        # Use the global min and max for X and Y
        x_min = min(df_original[col_x].min(), df_generated[col_x].min())
        x_max = max(df_original[col_x].max(), df_generated[col_x].max())
        y_min = min(df_original[col_y].min(), df_generated[col_y].min())
        y_max = max(df_original[col_y].max(), df_generated[col_y].max())
        
        # Add a small 5% padding margin for aesthetics
        x_margin = (x_max - x_min) * 0.05
        y_margin = (y_max - y_min) * 0.05
        xlims = (x_min - x_margin, x_max + x_margin)
        ylims = (y_min - y_margin, y_max + y_margin)
    
        # 3. Compute correlations for display
        corr_orig = df_original[col_x].corr(df_original[col_y])
        corr_gen = df_generated[col_x].corr(df_generated[col_y])
    
        # 4. Create the figure
        fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    
        # --- Plot 1: Original Data ---
        axes[0].scatter(df_original[col_x], df_original[col_y], 
                        alpha=0.5, s=15, label='Original', c='tab:blue')
        axes[0].set_title(f"Original Data\nCorrelation: {corr_orig:.3f}")
        axes[0].set_xlabel(col_x)
        axes[0].set_ylabel(col_y)
        axes[0].set_xlim(xlims)
        axes[0].set_ylim(ylims)
        axes[0].grid(True, linestyle='--', alpha=0.5)
    
        # --- Plot 2: Generated Data ---
        axes[1].scatter(df_generated[col_x], df_generated[col_y],
                        alpha=0.5, s=15, label='Generated', c='tab:orange')
        axes[1].set_title(f"Generated Data (KDE)\nCorrelation: {corr_gen:.3f}")
        axes[1].set_xlabel(col_x)
        axes[1].set_ylabel(col_y)  # Optional on the 2nd plot, but clear
        axes[1].set_xlim(xlims)
        axes[1].set_ylim(ylims)
        axes[1].grid(True, linestyle='--', alpha=0.5)
    
        plt.tight_layout()
        plt.show()
        
        
        
    def moustache(self):
        """
        Generate comparative boxplots for all numeric columns.

        :param df_original: DataFrame of real data.
        :param df_generated: DataFrame of synthetic data.
        """
        
        df_original = self.origin_df
        df_generated = self.df
        
        # --- 1. Prepare data for plotting ---

        # Identify numeric columns common to both DataFrames
        cols_orig = df_original.select_dtypes(include=[np.number]).columns
        cols_gen = df_generated.select_dtypes(include=[np.number]).columns
        
        numeric_cols = list(set(cols_orig) & set(cols_gen))
        if not numeric_cols:
            print("No common numeric columns found between the two DataFrames.")
            return

        # Create a list of tuples (variable, value, origin)
        plot_data = []
        
        for col in numeric_cols:
            # Safe cleaning to avoid type errors
            # Use to_numeric to ensure min/max/quartiles are computed correctly.
            orig_series = pd.to_numeric(df_original[col], errors='coerce').dropna()
            gen_series = pd.to_numeric(df_generated[col], errors='coerce').dropna()
    
            # Add data in 'long' format for plotting
            plot_data.extend([
                (col, val, 'Original') for val in orig_series.values
            ])
            plot_data.extend([
                (col, val, 'Synthetic') for val in gen_series.values
            ])
            
        # Create a single DataFrame for plotting
        df_plot = pd.DataFrame(plot_data, columns=['Variable', 'Value', 'Origin'])
        
        
        # --- 2. Figure configuration ---

        n_vars = len(numeric_cols)
        # Compute optimal figure size (adjustable)
        fig_width = max(8, n_vars * 2.5) 
        fig, ax = plt.subplots(figsize=(fig_width, 7))
        
        # --- 3. Generate boxplots ---

        # Define X axis positions for box pairs
        positions = np.arange(n_vars)
        width = 0.35  # Box width
        
        box_sets = []
        labels = []
    
        # Iterate over each variable to draw box pairs
        for i, col in enumerate(numeric_cols):
            # Data for the current variable
            data_orig = df_plot[(df_plot['Variable'] == col) & (df_plot['Origin'] == 'Original')]['Value']
            data_gen = df_plot[(df_plot['Variable'] == col) & (df_plot['Origin'] == 'Synthetic')]['Value']
            
            # Original boxplot
            bp_orig = ax.boxplot(data_orig, positions=[i - width/2], widths=width, patch_artist=True, 
                                 boxprops=dict(facecolor='lightblue', color='blue'))
            
            # Synthetic boxplot
            bp_gen = ax.boxplot(data_gen, positions=[i + width/2], widths=width, patch_artist=True, 
                                boxprops=dict(facecolor='lightcoral', color='red'))
            
            # Store one element from each set for the legend
            if i == 0:
                box_sets = [bp_orig['boxes'][0], bp_gen['boxes'][0]]
                labels = ['Original', 'Synthetic']
    
    
        # --- 4. Finalize the figure ---
        
        ax.set_xticks(positions)
        ax.set_xticklabels(numeric_cols, rotation=45, ha='right')
        
        ax.set_title("Distribution Comparison (Boxplots): Original vs Synthetic")
        ax.set_ylabel("Value")
        ax.legend(box_sets, labels, loc='upper right')
        ax.grid(axis='y', linestyle='--', alpha=0.6)
        
        plt.tight_layout()
        plt.show()

# ---------------------------------------------------------
# Usage example (with variables from the previous script)
# ---------------------------------------------------------
# display_comparison(df, df_new, 'Experience', 'Salary')
        
        
        
        
        
class MultivariateSampler:
    def __init__(self, dataframe, bounds):
        """
        Initialize the multivariate density estimator.
        Automatically handles data dimensionality.
        """
        # 1. Keep only numeric columns
        self.numeric_df = dataframe                
        self.columns = self.numeric_df.columns

        self.bounds = bounds
        
        # 2. Clean NaN values (KDE does not support NaN)
        # Transpose (.T) because gaussian_kde expects shape (n_features, n_samples)
        # while Pandas uses (n_samples, n_features)
        self.data = self.numeric_df.dropna().values.T
                
        # 3. Joint density estimation
        # This creates an N-dimensional density 'map' of the data
        self.kde = stats.gaussian_kde(self.data)
        
    def sample(self, n):
        """
        Generate a DataFrame of n rows preserving correlations.
        """
        # Generate raw data (numpy matrix)
        new_data = self.kde.resample(size=n)
        
        # 2. Convert back to DataFrame format
        df_sampled = pd.DataFrame(new_data.T, columns=self.columns)
        
        # 3. Apply clamping (truncation)
        for col, (min_val, max_val) in self.bounds.items():
            if col in df_sampled.columns:
                # np.clip forces values to stay between min_val and max_val
                df_sampled[col] = np.clip(df_sampled[col], min_val, max_val)
            else:
                print(f"Warning: Column '{col}' does not exist in the sampled data (or was not numeric).")
        
        return df_sampled
