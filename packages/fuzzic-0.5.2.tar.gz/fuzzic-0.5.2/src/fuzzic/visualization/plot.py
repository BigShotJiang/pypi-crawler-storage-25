import matplotlib.pyplot as plt
import numpy as np
import pylab
from matplotlib.ticker import MultipleLocator, PercentFormatter, FixedLocator
import math
from fuzzic.configuration.config import  config


def one_trapeze(mf):
    points = mf.points
    if len(points) == 4:
        return [(points[0].x,points[0].y), (points[1].x,points[1].y), (points[2].x,points[2].y), (points[3].x,points[3].y)]
    else:
        return [(points[0].x,points[0].y), (points[1].x,points[1].y), (points[2].x,points[2].y)]

def one_gaussian(mf):
    d = {"mu" : mf.gaussian.mean,
         "variance" : mf.gaussian.deviation,
         "caption" : mf.label,
         "min" : mf.var.bounds[0],
         "max" : mf.var.bounds[1]}
    return d


def plot_membership_functions(all_mf, captions, variable_name, step = 10, add_annotation = False, unit=""):
    """
    Plots trapezoidal membership functions given their vertices and adds captions below each function.

    Parameters:
    trapezoids (list of lists of tuples): A list where each element is a list of tuples representing the vertices of a trapezoidal membership function.
                                         Each trapezoid should have 4 vertices.
    captions (list of str): A list of captions to be placed below each membership function.
    """
    fig, ax = plt.subplots(figsize=(config.size_of_plot_x, config.size_of_plot_y), dpi=200)

    maxi_x_for_unit = all_mf[0].var.bounds[1]

    unit_y = -0.06
    all_mf_ready_to_plot = []
    all_shapes = []
    for mf in all_mf:
        if mf.shape == "gaussian":
            all_mf_ready_to_plot.append(one_gaussian(mf))
            all_shapes.append("gaussian")

        else:
            all_mf_ready_to_plot.append(one_trapeze(mf))
            all_shapes.append("trapezoid")

    colors = ['blue', 'green', 'red', 'purple', 'orange', 'cyan', 'magenta']  # Colors for the curves

    for i, fuzzy_set in enumerate(all_mf_ready_to_plot):
        if all_shapes[i] == "gaussian":

            mu = fuzzy_set["mu"]
            variance = fuzzy_set["variance"]
            sigma = math.sqrt(variance)
            x = np.linspace(fuzzy_set["min"], fuzzy_set["max"], 500)
            ax.plot(x, np.exp(-(x - mu)**2 / (2 * sigma**2)), color=colors[i % len(colors)])

            # Add caption below the membership function
            caption_x = mu


            caption_y = -0.2  # Adjust this value to place the caption below the x-axis
            ax.text(caption_x, caption_y, fuzzy_set["caption"], ha='center', va='center', fontsize=12, fontweight='bold', color=colors[i % len(colors)])
            i = i+1

        else:

            trapezoid = fuzzy_set
            if len(trapezoid) not in [3,4]:
                raise ValueError("Each trapezoid must have exactly 3 or 4 vertices.")

            if len(trapezoid) == 4:
                # Extract the vertices
                (x1, y1), (x2, y2), (x3, y3), (x4, y4) = trapezoid

                # Create the x and y values for the trapezoidal membership function
                x = np.linspace(x1, x4, 500)
                y = np.piecewise(x,
                     [x < x1, (x >= x1) & (x < x2), (x >= x2) & (x < x3), (x >= x3) & (x < x4), x >= x4],
                     [0, lambda x: (x - x1) / (x2 - x1) * y2, y2, lambda x: (x4 - x) / (x4 - x3) * y2, 0])
                # Plot the trapezoidal membership function with a unique color
                ax.plot(x, y, color=colors[i % len(colors)])

                #add annotation
                if add_annotation:
                    t = 19
                    ax.plot([t,t],[0,0.8], color ='gray',  linewidth=1, linestyle="--")
                    ax.plot([15,19],[0.2,0.2], color ='green',  linewidth=1, linestyle="--")
                    ax.plot([15,19],[0.8,0.8], color ='blue',  linewidth=1, linestyle="--")
                    pylab.annotate(r'$20\%$', xy=(14.7, 0.2),  xycoords='data',
                                   xytext=(+10, +30), textcoords='offset points', fontsize=14, color = "green",
                                   arrowprops=dict(arrowstyle="->", connectionstyle="arc3,rad=.2"))
                    pylab.annotate(r'$80\%$', xy=(14.7, 0.8),  xycoords='data',
                                   xytext=(+10, +20), textcoords='offset points', fontsize=14, color = "blue",
                                   arrowprops=dict(arrowstyle="->", connectionstyle="arc3,rad=.2"))


                # Add caption below the membership function
                caption_x = (x2 + x3) / 2


            else:
                # Extract the vertices
                (x1, y1), (x2, y2), (x3, y3)= trapezoid

                # Create the x and y values for the trapezoidal membership function
                x = np.linspace(x1, x3, 500)
                if y1 > 0:
                    # lower trapezoid
                    y = np.piecewise(x,
                         [x < x1, (x >= x1) & (x < x2), (x >= x2) & (x < x3), (x >= x3)],
                         [y1, y1, lambda x: (x3 - x) / (x3 - x2) * y1, 0])
                    caption_x = (x1 + x2) / 2

                elif y3 > 0:
                    # upper trapezoid
                    y = np.piecewise(x,
                         [x < x1, (x >= x1) & (x < x2), (x >= x2) & (x < x3), (x >= x3)],
                         [0, lambda x: (x - x1) / (x2 - x1) * y3, y3, y3])
                    caption_x = (x2 + x3) / 2
                else:
                    # triangle
                    y = np.piecewise(x,
                         [x < x1, (x >= x1) & (x < x2), (x >= x2) & (x < x3), (x >= x3)],
                         [0, lambda x: (x - x1) / (x2 - x1) * y2, lambda x: (x3 - x) / (x3 - x2) * y2, y3])
                    caption_x = (x2 + x3) / 2


                # Plot the trapezoidal membership function with a unique color
                ax.plot(x, y, color=colors[i % len(colors)])

            ax.set_ylim(0, 1.1)

            caption_y = -0.2  # Adjust this value to place the caption below the x-axis
            ax.text(caption_x, caption_y, captions[i], ha='center', va='center', fontsize=12, fontweight='bold', color=colors[i % len(colors)])
            i = i+1

    ax.text(maxi_x_for_unit + step, unit_y + 0.06, unit, ha='center', va='center', fontsize=12, color="black")

    # Add grid with precise intervals

    pas_x_axis = step

    ax.yaxis.set_major_locator(FixedLocator([0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]))  # Major grid at specific intervals
    ax.grid(which='major', linestyle='--', linewidth=0.5)

    # Set y-axis to show percentages
    ax.yaxis.set_major_formatter(PercentFormatter(1))

    # Set aspect ratio to be equal
    ax.set_aspect('auto', adjustable='box')

    # Label the y-axis
    ax.set_ylabel("Membership degree (%)")
    ax.set_title(variable_name + " - rulebase : " + all_mf[0].var.rulebase.label)

    plt.show()
