"""Shared fixtures for FuzzIC tests."""
import pytest
import os
import json
import tempfile
import shutil
import numpy as np
from fuzzic.configuration.config import Config
from fuzzic.interpretability.rulebase import (
    Point, Line, Gaussian, Variable, MF, Term, Rule, Rulebase
)


@pytest.fixture
def fresh_config():
    """Return a fresh Config instance (not the module-level singleton)."""
    return Config()


@pytest.fixture
def simple_variable():
    """A variable with bounds [0, 10] and 3 triangular fuzzy sets forming a proper partition."""
    rb = Rulebase(label="test_rb")
    var = Variable(
        label="temperature",
        rulebase=rb,
        unit="C",
        bounds=[0.0, 10.0],
        all_mf=[],
        ident="v1",
    )
    # Low: semi-trapezoid [0,0,5] with heights [1,1,0]
    mf_low = MF(
        label="low", shape="trapeze", var=var,
        points=[Point(0, 1), Point(0, 1), Point(5, 0)], ident="s1"
    )
    # Medium: triangle [0,5,10]
    mf_med = MF(
        label="medium", shape="triangle", var=var,
        points=[Point(0, 0), Point(5, 1), Point(10, 0)], ident="s2"
    )
    # High: semi-trapezoid [5,10,10] with heights [0,1,1]
    mf_high = MF(
        label="high", shape="trapeze", var=var,
        points=[Point(5, 0), Point(10, 1), Point(10, 1)], ident="s3"
    )
    var.all_mf = [mf_low, mf_med, mf_high]
    rb.var["v1"] = var
    rb.used_variables = rb.get_used_variables()
    return var


@pytest.fixture
def simple_rulebase(simple_variable):
    """A rulebase with one variable and two rules."""
    rb = simple_variable.rulebase
    var = simple_variable

    rule1 = Rule(
        ident="r1",
        premise={Term(var=var, mf=var.all_mf[0])},
        conclusion={Term(var=var, mf=var.all_mf[2])},
    )
    rule2 = Rule(
        ident="r2",
        premise={Term(var=var, mf=var.all_mf[1])},
        conclusion={Term(var=var, mf=var.all_mf[1])},
    )
    rb.rules = {"r1": rule1, "r2": rule2}
    rb.used_variables = rb.get_used_variables()
    return rb


@pytest.fixture
def study_directory(simple_rulebase):
    """Create a temporary study directory structure with specifics files."""
    tmpdir = tempfile.mkdtemp()
    specifics = os.path.join(tmpdir, "specifics")
    datasets = os.path.join(tmpdir, "datasets")
    rulebases = os.path.join(tmpdir, "rulebases")
    results = os.path.join(tmpdir, "results")
    dashboard = os.path.join(tmpdir, "dashboard")
    for d in [specifics, datasets, rulebases, results, dashboard]:
        os.makedirs(d, exist_ok=True)

    # label_orders.json
    label_orders = {"v1": {"low": 1, "medium": 2, "high": 3}}
    with open(os.path.join(specifics, "label_orders.json"), "w") as f:
        json.dump(label_orders, f)

    # prototypes.json
    prototypes = {"v1": [0.0, 5.0, 10.0]}
    with open(os.path.join(specifics, "prototypes.json"), "w") as f:
        json.dump(prototypes, f)

    # similar_variables.dat (empty)
    with open(os.path.join(specifics, "similar_variables.dat"), "w") as f:
        pass

    yield tmpdir
    shutil.rmtree(tmpdir)
