"""Tests for rulebase domain model: MF.forward, Gaussian, Line."""
import pytest
import numpy as np
from fuzzic.interpretability.rulebase import (
    Point, Line, Gaussian, Variable, MF, Rulebase
)


class TestLine:
    def test_linear_interpolation(self):
        d = Line(Point(0, 0), Point(10, 1))
        assert d.forward(0) == pytest.approx(0.0)
        assert d.forward(5) == pytest.approx(0.5)
        assert d.forward(10) == pytest.approx(1.0)

    def test_horizontal_line(self):
        d = Line(Point(0, 0.5), Point(10, 0.5))
        assert d.forward(5) == pytest.approx(0.5)

    def test_vertical_line(self):
        """Line.forward returns p2.y when p1.x == p2.x (vertical line)."""
        d = Line(Point(5, 0), Point(5, 1))
        assert d.forward(5) == 1


class TestGaussian:
    def test_peak_at_mean(self):
        g = Gaussian(mean=5.0, deviation=1.0)
        assert g.forward(5.0) == pytest.approx(1.0)

    def test_symmetry(self):
        g = Gaussian(mean=5.0, deviation=2.0)
        assert g.forward(3.0) == pytest.approx(g.forward(7.0))

    def test_away_from_mean(self):
        g = Gaussian(mean=0.0, deviation=1.0)
        assert g.forward(3.0) < 0.02  # very small

    def test_height_equals_one(self):
        g = Gaussian(mean=5.0, deviation=1.0)
        assert g.height == pytest.approx(1.0)


class TestMFForward:
    def _make_var(self, bounds=None):
        if bounds is None:
            bounds = [0.0, 10.0]
        rb = Rulebase(label="test")
        var = Variable(label="x", rulebase=rb, unit="", bounds=bounds,
                       all_mf=[], ident="v1")
        return var

    def test_triangle_at_peak(self):
        var = self._make_var()
        mf = MF(label="A", shape="triangle", var=var,
                 points=[Point(0, 0), Point(5, 1), Point(10, 0)], ident="s1")
        assert mf.forward(5.0) == pytest.approx(1.0)

    def test_triangle_at_base(self):
        var = self._make_var()
        mf = MF(label="A", shape="triangle", var=var,
                 points=[Point(0, 0), Point(5, 1), Point(10, 0)], ident="s1")
        assert mf.forward(0.0) == pytest.approx(0.0)
        assert mf.forward(10.0) == pytest.approx(0.0)

    def test_triangle_midpoint(self):
        var = self._make_var()
        mf = MF(label="A", shape="triangle", var=var,
                 points=[Point(0, 0), Point(5, 1), Point(10, 0)], ident="s1")
        assert mf.forward(2.5) == pytest.approx(0.5)

    def test_trapeze_plateau(self):
        var = self._make_var()
        mf = MF(label="A", shape="trapeze", var=var,
                 points=[Point(0, 0), Point(3, 1), Point(7, 1), Point(10, 0)],
                 ident="s1")
        assert mf.forward(5.0) == pytest.approx(1.0)

    def test_gaussian_forward(self):
        var = self._make_var()
        g = Gaussian(mean=5.0, deviation=2.0)
        mf = MF(label="G", shape="gaussian", var=var, gaussian=g, ident="sg")
        assert mf.forward(5.0) == pytest.approx(1.0)
        assert mf.forward(0.0) < 0.1

    def test_out_of_bounds_raises(self):
        var = self._make_var([0.0, 10.0])
        mf = MF(label="A", shape="triangle", var=var,
                 points=[Point(0, 0), Point(5, 1), Point(10, 0)], ident="s1")
        with pytest.raises(AssertionError):
            mf.forward(-1.0)
        with pytest.raises(AssertionError):
            mf.forward(11.0)

    def test_cardinal_positive(self):
        var = self._make_var()
        mf = MF(label="A", shape="triangle", var=var,
                 points=[Point(0, 0), Point(5, 1), Point(10, 0)], ident="s1")
        assert mf._cardinal > 0

    def test_peak_y_for_triangle(self):
        var = self._make_var()
        mf = MF(label="A", shape="triangle", var=var,
                 points=[Point(0, 0), Point(5, 1), Point(10, 0)], ident="s1")
        assert mf.peak_y == 1.0
        assert mf.peak_x == 5.0

    def test_non_normal_mf(self):
        var = self._make_var()
        mf = MF(label="A", shape="triangle", var=var,
                 points=[Point(0, 0), Point(5, 0.7), Point(10, 0)], ident="s1")
        assert mf.peak_y == 0.7
