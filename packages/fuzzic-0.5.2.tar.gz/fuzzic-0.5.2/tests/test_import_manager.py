"""Tests for import_manager: XML parsing."""
import pytest
import os
import tempfile
from fuzzic.data_management.import_manager import import_xml, import_rulebase


MINIMAL_XML = """\
<?xml version="1.0" encoding="ISO-8859-1" standalone="yes"?>
<rulebase>
    <label>test_rulebase</label>
    <variable ident="v1">
        <label>temperature</label>
        <universe unit="C">
            <bound type="Inf">0</bound>
            <bound type="Sup">40</bound>
        </universe>
        <sef ident="s1">
            <label>cold</label>
            <point><x>0</x><y>1</y></point>
            <point><x>0</x><y>1</y></point>
            <point><x>20</x><y>0</y></point>
        </sef>
        <sef ident="s2">
            <label>hot</label>
            <point><x>20</x><y>0</y></point>
            <point><x>40</x><y>1</y></point>
            <point><x>40</x><y>1</y></point>
        </sef>
    </variable>
    <rule ident="r1">
        <premise><variableID>v1</variableID><fuzzysetID>s1</fuzzysetID></premise>
        <conclusion><variableID>v1</variableID><fuzzysetID>s2</fuzzysetID></conclusion>
    </rule>
</rulebase>
"""


@pytest.fixture
def xml_file():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".xml", delete=False) as f:
        f.write(MINIMAL_XML)
        path = f.name
    yield path
    os.unlink(path)


class TestImportXml:
    def test_basic_parse(self, xml_file):
        rb = import_xml(xml_file)
        assert rb.label == "test_rulebase"
        assert len(rb.var) == 1
        assert len(rb.rules) == 1

    def test_variable_bounds(self, xml_file):
        rb = import_xml(xml_file)
        var = rb.var["v1"]
        assert var.bounds == [0.0, 40.0]
        assert var.unit == "C"

    def test_fuzzy_sets_loaded(self, xml_file):
        rb = import_xml(xml_file)
        var = rb.var["v1"]
        assert len(var.all_mf) == 2
        labels = {s.label for s in var.all_mf}
        assert labels == {"cold", "hot"}

    def test_rule_structure(self, xml_file):
        rb = import_xml(xml_file)
        rule = rb.rules["r1"]
        assert len(rule.premise) == 1
        assert len(rule.conclusion) == 1

    def test_used_variables_populated(self, xml_file):
        rb = import_xml(xml_file)
        assert rb.used_variables is not None
        assert "v1" in rb.used_variables

    def test_import_rulebase_dispatches_xml(self, xml_file):
        rb = import_rulebase(xml_file)
        assert rb is not None
        assert rb.label == "test_rulebase"

    def test_import_rulebase_unknown_format(self, tmp_path):
        unknown = tmp_path / "test.txt"
        unknown.write_text("not a rulebase")
        rb = import_rulebase(str(unknown))
        assert rb is None
