"""Tests for individual interpretability criteria."""
import pytest
import os
import json
from unittest.mock import MagicMock
from fuzzic.configuration.config import config
from fuzzic.interpretability.rulebase import (
    Point, Gaussian, Variable, MF, Term, Rule, Rulebase
)


def _make_rulebase_with_partition(points_list, bounds=None, shape="triangle"):
    """Helper: create a rulebase with one variable and given fuzzy sets."""
    if bounds is None:
        bounds = [0.0, 10.0]
    rb = Rulebase(label="test_rb")
    var = Variable(label="x", rulebase=rb, unit="", bounds=bounds,
                   all_mf=[], ident="v1")
    for i, pts in enumerate(points_list):
        mf = MF(label=f"s{i}", shape=shape, var=var, points=pts,
                 ident=f"s{i}")
        var.all_mf.append(mf)
    rb.var["v1"] = var

    # Create a dummy rule using first and last fuzzy sets
    if len(var.all_mf) >= 2:
        rule = Rule(
            ident="r1",
            premise={Term(var=var, mf=var.all_mf[0])},
            conclusion={Term(var=var, mf=var.all_mf[-1])},
        )
        rb.rules = {"r1": rule}
    rb.used_variables = rb.get_used_variables()
    return rb


class TestNormality:
    def test_all_normal(self):
        from fuzzic.interpretability.criteria.normality import interpretability
        rb = _make_rulebase_with_partition([
            [Point(0, 0), Point(5, 1), Point(10, 0)],
            [Point(0, 0), Point(3, 1), Point(6, 0)],
        ])
        result = interpretability(rb)
        assert result["score"] == 1.0

    def test_one_non_normal(self):
        from fuzzic.interpretability.criteria.normality import interpretability
        rb = _make_rulebase_with_partition([
            [Point(0, 0), Point(5, 1), Point(10, 0)],
            [Point(0, 0), Point(3, 0.5), Point(6, 0)],  # height 0.5
        ])
        result = interpretability(rb)
        assert result["score"] == 0.5
        assert result["warning"] != ""


class TestUnimodality:
    def test_all_triangles_normal(self):
        from fuzzic.interpretability.criteria.unimodality import interpretability
        rb = _make_rulebase_with_partition([
            [Point(0, 0), Point(3, 1), Point(6, 0)],
            [Point(4, 0), Point(7, 1), Point(10, 0)],
        ])
        result = interpretability(rb)
        assert result["score"] == 1.0

    def test_trapeze_with_height_1_is_unimodal(self):
        """Trapezoids with height 1 are unimodal (single plateau at max)."""
        from fuzzic.interpretability.criteria.unimodality import interpretability
        rb = _make_rulebase_with_partition([
            [Point(0, 0), Point(3, 1), Point(7, 1), Point(10, 0)],
            [Point(0, 0), Point(2, 1), Point(8, 1), Point(10, 0)],
        ], shape="trapeze")
        result = interpretability(rb)
        assert result["score"] == 1.0

    def test_subnormal_not_unimodal(self):
        """A fuzzy set with height < 1 is not unimodal."""
        from fuzzic.interpretability.criteria.unimodality import interpretability
        rb = _make_rulebase_with_partition([
            [Point(0, 0), Point(5, 0.8), Point(10, 0)],
            [Point(0, 0), Point(5, 1), Point(10, 0)],
        ])
        result = interpretability(rb)
        assert result["score"] == 0.5


class TestCoverage:
    def test_full_coverage(self):
        from fuzzic.interpretability.criteria.coverage import interpretability
        config.alpha_coverage = 0.0  # any membership > 0 counts
        # Two sets covering [0,10]
        rb = _make_rulebase_with_partition([
            [Point(0, 1), Point(0, 1), Point(10, 0)],
            [Point(0, 0), Point(10, 1), Point(10, 1)],
        ], shape="trapeze")
        result = interpretability(rb)
        assert result["score"] >= 0.99

    def test_gap_in_coverage(self):
        from fuzzic.interpretability.criteria.coverage import interpretability
        config.alpha_coverage = 0.1
        # Two narrow sets leaving a gap in the middle
        rb = _make_rulebase_with_partition([
            [Point(0, 0), Point(1, 1), Point(2, 0)],
            [Point(8, 0), Point(9, 1), Point(10, 0)],
        ])
        result = interpretability(rb)
        assert result["score"] < 0.5  # large gap


class TestComplementarity:
    def test_perfect_complementarity(self):
        """Two complementary semi-trapezoids whose membership sums to 1 everywhere."""
        from fuzzic.interpretability.criteria.complementarity import interpretability
        config.precision = 0.05
        # Set A: linearly from 1 to 0; Set B: linearly from 0 to 1
        rb = _make_rulebase_with_partition([
            [Point(0, 1), Point(0, 1), Point(10, 0)],
            [Point(0, 0), Point(10, 1), Point(10, 1)],
        ], shape="trapeze")
        result = interpretability(rb)
        assert result["score"] >= 0.95


class TestUniformity:
    def test_identical_sets_uniform(self):
        from fuzzic.interpretability.criteria.uniformity import interpretability
        rb = _make_rulebase_with_partition([
            [Point(0, 0), Point(5, 1), Point(10, 0)],
            [Point(0, 0), Point(5, 1), Point(10, 0)],
        ])
        result = interpretability(rb)
        assert result["score"] == pytest.approx(1.0, abs=0.01)


class TestExtrema:
    def test_extrema_covered(self):
        from fuzzic.interpretability.criteria.extrema import interpretability
        # Semi-trapezoids at boundaries with membership 1
        rb = _make_rulebase_with_partition([
            [Point(0, 1), Point(0, 1), Point(5, 0)],
            [Point(5, 0), Point(10, 1), Point(10, 1)],
        ], shape="trapeze")
        result = interpretability(rb)
        assert result["score"] == 1.0



class TestJustifiableNumberOfElements:
    def test_below_threshold(self):
        from fuzzic.interpretability.criteria.justifiable_number_of_elements import interpretability
        config.interpretability_threshold_number = 7
        rb = _make_rulebase_with_partition([
            [Point(0, 0), Point(3, 1), Point(6, 0)],
            [Point(4, 0), Point(7, 1), Point(10, 0)],
        ])
        result = interpretability(rb)
        assert result["score"] == 1.0  # 2 <= 7

    def test_above_threshold(self):
        from fuzzic.interpretability.criteria.justifiable_number_of_elements import interpretability
        config.interpretability_threshold_number = 2
        pts_list = [[Point(i, 0), Point(i + 1, 1), Point(i + 2, 0)]
                    for i in range(0, 8, 2)]  # 4 fuzzy sets
        rb = _make_rulebase_with_partition(pts_list, bounds=[0.0, 10.0])
        result = interpretability(rb)
        assert result["score"] == pytest.approx(2 / 4)  # threshold/count = 0.5


class TestNumberOfRules:
    def test_few_rules(self):
        from fuzzic.interpretability.criteria.number_of_rules import interpretability
        config.interpretability_threshold_number = 7
        rb = _make_rulebase_with_partition([
            [Point(0, 0), Point(5, 1), Point(10, 0)],
            [Point(0, 0), Point(3, 1), Point(6, 0)],
        ])
        # 1 rule <= 7
        result = interpretability(rb)
        assert result["score"] == 1.0


class TestNumberOfVariables:
    def test_counts_only_used_variables(self):
        """number_of_variables should count only used variables, not all declared ones."""
        from fuzzic.interpretability.criteria.number_of_variables import interpretability
        config.interpretability_threshold_number = 7
        rb = Rulebase(label="test")
        # Add 10 variables but no rules (none are 'used')
        for i in range(10):
            var = Variable(label=f"v{i}", rulebase=rb, unit="", bounds=[0, 1],
                           all_mf=[], ident=f"v{i}")
            rb.var[f"v{i}"] = var
        rb.rules = {}
        rb.used_variables = rb.get_used_variables()
        result = interpretability(rb)
        # 0 used variables <= threshold → score 1.0
        assert result["score"] == 1.0
