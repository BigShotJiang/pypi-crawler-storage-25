"""Tests for fuzzy_primitives and criteria_engine modules."""
import pytest
import numpy as np
from fuzzic.configuration.config import Config, config
from fuzzic.interpretability import fuzzy_primitives as fp
from fuzzic.interpretability import criteria_engine as ce
from fuzzic.interpretability.rulebase import Point, Variable, MF, Rulebase


# ── t-norm tests ─────────────────────────────────────────────────────────────

class TestTNorm:
    def setup_method(self):
        config.t_norm = "zadeh"

    def test_zadeh_min(self):
        config.t_norm = "zadeh"
        assert fp.t_norm(0.3, 0.7) == 0.3
        assert fp.t_norm(1.0, 0.5) == 0.5
        assert fp.t_norm(0.0, 1.0) == 0.0

    def test_probabilistic_product(self):
        config.t_norm = "probabiliste"
        assert fp.t_norm(0.5, 0.4) == pytest.approx(0.2)

    def test_lukasiewicz(self):
        """Lukasiewicz t-norm: max(x + y - 1, 0)."""
        config.t_norm = "lukasiewicz"
        assert fp.t_norm(0.6, 0.7) == pytest.approx(0.3)
        assert fp.t_norm(0.2, 0.3) == pytest.approx(0.0)
        assert fp.t_norm(1.0, 0.8) == pytest.approx(0.8)

    def test_drastic(self):
        config.t_norm = "drastique"
        assert fp.t_norm(0.5, 1.0) == 0.5
        assert fp.t_norm(1.0, 0.3) == 0.3
        assert fp.t_norm(0.5, 0.3) == 0.0

    def test_boundary_conditions(self):
        config.t_norm = "zadeh"
        assert fp.t_norm(0.0, 0.0) == 0.0
        assert fp.t_norm(1.0, 1.0) == 1.0


# ── t-conorm tests ───────────────────────────────────────────────────────────

class TestTConorm:
    def setup_method(self):
        config.t_norm = "zadeh"
        config.t_conorm = "dual"

    def test_dual_uses_t_norm_setting(self):
        """When t_conorm='dual', behavior mirrors the t_norm choice."""
        config.t_norm = "zadeh"
        config.t_conorm = "dual"
        assert fp.t_conorm(0.3, 0.7) == 0.7  # max (dual of Zadeh min)

    def test_explicit_t_conorm_overrides_dual(self):
        """When t_conorm is set explicitly, it ignores t_norm."""
        config.t_norm = "zadeh"
        config.t_conorm = "probabiliste"
        result = fp.t_conorm(0.3, 0.5)
        assert result == pytest.approx(0.3 + 0.5 - 0.15)  # probabilistic sum

    def test_zadeh_max(self):
        config.t_conorm = "zadeh"
        assert fp.t_conorm(0.3, 0.7) == 0.7

    def test_probabilistic_sum(self):
        config.t_conorm = "probabiliste"
        assert fp.t_conorm(0.3, 0.5) == pytest.approx(0.3 + 0.5 - 0.15)

    def test_lukasiewicz_conorm(self):
        config.t_conorm = "lukasiewicz"
        assert fp.t_conorm(0.6, 0.7) == pytest.approx(1.0)
        assert fp.t_conorm(0.2, 0.3) == pytest.approx(0.5)


# ── Similarity tests ─────────────────────────────────────────────────────────

class TestSimilarity:
    def _make_var_with_two_mfs(self, points1, points2):
        rb = Rulebase(label="test")
        var = Variable(label="x", rulebase=rb, unit="", bounds=[0.0, 10.0],
                       all_mf=[], ident="v1")
        mf1 = MF(label="A", shape="triangle", var=var, points=points1, ident="s1")
        mf2 = MF(label="B", shape="triangle", var=var, points=points2, ident="s2")
        var.all_mf = [mf1, mf2]
        return mf1, mf2

    def test_dice_identical_sets(self):
        config.t_norm = "zadeh"
        config.similarity = "dice"
        pts = [Point(0, 0), Point(5, 1), Point(10, 0)]
        mf1, mf2 = self._make_var_with_two_mfs(pts, pts)
        result = fp.dice(mf1, mf2)
        assert result == pytest.approx(1.0, abs=0.01)

    def test_dice_non_overlapping_sets(self):
        config.t_norm = "zadeh"
        config.similarity = "dice"
        pts1 = [Point(0, 0), Point(1, 1), Point(2, 0)]
        pts2 = [Point(8, 0), Point(9, 1), Point(10, 0)]
        mf1, mf2 = self._make_var_with_two_mfs(pts1, pts2)
        result = fp.dice(mf1, mf2)
        assert result == pytest.approx(0.0, abs=0.01)

    def test_dice_both_empty(self):
        """Edge case: two fuzzy sets with zero cardinality."""
        config.t_norm = "zadeh"
        # All-zero membership: points at y=0
        pts = [Point(0, 0), Point(5, 0), Point(10, 0)]
        mf1, mf2 = self._make_var_with_two_mfs(pts, pts)
        result = fp.dice(mf1, mf2)
        assert result == 0  # Guarded by if U==0 and V==0

    def test_jaccard_identical_sets(self):
        config.t_norm = "zadeh"
        config.t_conorm = "dual"
        config.similarity = "jaccard"
        pts = [Point(0, 0), Point(5, 1), Point(10, 0)]
        mf1, mf2 = self._make_var_with_two_mfs(pts, pts)
        result = fp.jaccard(mf1, mf2)
        assert result == pytest.approx(1.0, abs=0.01)

    def test_jaccard_non_overlapping(self):
        config.t_norm = "zadeh"
        config.t_conorm = "dual"
        config.similarity = "jaccard"
        pts1 = [Point(0, 0), Point(1, 1), Point(2, 0)]
        pts2 = [Point(8, 0), Point(9, 1), Point(10, 0)]
        mf1, mf2 = self._make_var_with_two_mfs(pts1, pts2)
        result = fp.jaccard(mf1, mf2)
        assert result == pytest.approx(0.0, abs=0.01)

    def test_tversky_identical_sets(self):
        """With Zadeh t-norm, difference(y,y)=min(y,1-y)!=0 for intermediate values,
        so Tversky on identical sets is less than 1. Verify it runs and returns a
        value in (0,1]."""
        config.t_norm = "zadeh"
        config.t_conorm = "dual"
        config.similarity = "tversky"
        pts = [Point(0, 0), Point(5, 1), Point(10, 0)]
        mf1, mf2 = self._make_var_with_two_mfs(pts, pts)
        result = fp.tversky(mf1, mf2, 0.5, 0.5)
        assert 0 < result <= 1.0


# ── Aggregation tests ────────────────────────────────────────────────────────

class TestAggregation:
    def test_criteria_aggregator_average(self):
        config.criteria_aggregation = "average"
        assert ce.criteria_aggregator([0.5, 0.5]) == pytest.approx(0.5)
        assert ce.criteria_aggregator([0.0, 1.0]) == pytest.approx(0.5)

    def test_criteria_aggregator_worst(self):
        config.criteria_aggregation = "worst"
        assert ce.criteria_aggregator([0.3, 0.7, 0.9]) == pytest.approx(0.3)

    def test_score_pooling_weighted_average(self):
        """Test weighted average pooling with equal weights."""
        from fuzzic.interpretability.interpretability_manager import CRITERIA
        config.criteria_pooling = "average"
        # We need active criteria with scores
        active = [c for c in CRITERIA if c.active]
        if len(active) < 2:
            pytest.skip("Need at least 2 active criteria")
        scores = {c.criterion_name: {"score": 0.8} for c in active}
        result = ce.score_pooling(scores)
        assert result == pytest.approx(0.8, abs=0.01)

    def test_score_pooling_worst(self):
        from fuzzic.interpretability.interpretability_manager import CRITERIA
        config.criteria_pooling = "worst"
        active = [c for c in CRITERIA if c.active]
        if len(active) < 2:
            pytest.skip("Need at least 2 active criteria")
        scores = {}
        for i, c in enumerate(active):
            scores[c.criterion_name] = {"score": 0.5 + i * 0.01}
        result = ce.score_pooling(scores)
        assert result == pytest.approx(0.5)
