# revst_advanced/ferramentas.py
# revst_advanced/ferramentas.py
import customtkinter as ctk

# Configurações Globais
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

# ==========================================
# JANELA E SISTEMA
# ==========================================
def criar_janela(titulo="Sistema Revst Advanced", largura=900, altura=700):
    janela = ctk.CTk()
    janela.title(titulo)
    janela.geometry(f"{largura}x{altura}")
    return janela

def iniciar_janela(janela): janela.mainloop()
def fechar_janela(janela): janela.destroy()
def mudar_tamanho_janela(janela, w, h): janela.geometry(f"{w}x{h}")
def mudar_titulo(janela, titulo): janela.title(titulo)
def centralizar_janela(janela): janela.eval('tk::PlaceWindow . center')
def definir_icone(janela, caminho_icone): janela.iconbitmap(caminho_icone)
def transparente(janela, nivel=0.9): janela.attributes("-alpha", nivel)
def sempre_no_topo(janela, estado=True): janela.attributes("-topmost", estado)
def mudar_tema(modo="dark"): ctk.set_appearance_mode(modo)
def mudar_cor_padrao(cor="blue"): ctk.set_default_color_theme(cor)

# ==========================================
# TEXTOS
# ==========================================
def criar_texto(pai, texto="Texto", x=0, y=0, tamanho=15, cor=None):
    lbl = ctk.CTkLabel(pai, text=texto, font=("Ubuntu", tamanho), text_color=cor)
    lbl.place(x=x, y=y)
    return lbl

def mudar_texto(elemento, novo): elemento.configure(text=novo)
def mudar_cor_texto(elemento, cor): elemento.configure(text_color=cor)
def mudar_tamanho_fonte(elemento, tam): elemento.configure(font=("Ubuntu", tam))

# ==========================================
# BOTÕES
# ==========================================
def criar_botao(pai, texto="Confirmar", comando=None, x=0, y=0, largura=150, cor=None):
    btn = ctk.CTkButton(pai, text=texto, command=comando, width=largura, corner_radius=10, fg_color=cor)
    btn.place(x=x, y=y)
    return btn

def mudar_comando_botao(botao, comando): botao.configure(command=comando)
def mudar_cor_botao(botao, cor): botao.configure(fg_color=cor)
def desativar_botao(botao): botao.configure(state="disabled")
def ativar_botao(botao): botao.configure(state="normal")

def criar_botao_segmentado(pai, lista_opcoes, x=0, y=0, comando=None):
    seg = ctk.CTkSegmentedButton(pai, values=lista_opcoes, command=comando)
    seg.place(x=x, y=y)
    return seg

def pegar_valor_segmentado(seg): return seg.get()

# ==========================================
# ENTRADAS E CAIXAS DE TEXTO
# ==========================================
def criar_entrada(pai, dica="...", x=0, y=0, largura=200):
    ent = ctk.CTkEntry(pai, width=largura, placeholder_text=dica, corner_radius=10)
    ent.place(x=x, y=y)
    return ent

def pegar_texto_entrada(entrada): return entrada.get()
def limpar_entrada(entrada): entrada.delete(0, 'end')
def modo_senha(entrada, caractere="*"): entrada.configure(show=caractere)

def criar_caixa_texto(pai, x=0, y=0, largura=300, altura=150):
    txt = ctk.CTkTextbox(pai, width=largura, height=altura, corner_radius=10)
    txt.place(x=x, y=y)
    return txt

def inserir_na_caixa_texto(caixa, texto): caixa.insert("0.0", texto)
def pegar_caixa_texto(caixa): return caixa.get("0.0", "end")

# ==========================================
# MENUS E SELEÇÃO
# ==========================================
def criar_menu_opcoes(pai, lista, x=0, y=0, comando=None):
    menu = ctk.CTkOptionMenu(pai, values=lista, command=comando, corner_radius=10)
    menu.place(x=x, y=y)
    return menu

def pegar_valor_menu(menu): return menu.get()
def mudar_valor_menu(menu, valor): menu.set(valor)

def criar_caixa_combinada(pai, lista, x=0, y=0, comando=None):
    cmb = ctk.CTkComboBox(pai, values=lista, command=comando, corner_radius=10)
    cmb.place(x=x, y=y)
    return cmb

def pegar_valor_combinada(caixa): return caixa.get()

# ==========================================
# INTERRUPTORES E CHECKBOXES
# ==========================================
def criar_caixa_selecao(pai, texto, x=0, y=0):
    chk = ctk.CTkCheckBox(pai, text=texto)
    chk.place(x=x, y=y)
    return chk

def pegar_estado_selecao(chk): return chk.get()
def marcar_selecao(chk): chk.select()
def desmarcar_selecao(chk): chk.deselect()

def criar_interruptor(pai, texto="Ativar", x=0, y=0):
    sw = ctk.CTkSwitch(pai, text=texto)
    sw.place(x=x, y=y)
    return sw

def pegar_estado_interruptor(sw): return sw.get()

# ==========================================
# PAINÉIS E ABAS
# ==========================================
def criar_painel(pai, largura=200, altura=200, x=0, y=0, cor_fundo=None):
    frame = ctk.CTkFrame(pai, width=largura, height=altura, corner_radius=15, fg_color=cor_fundo)
    frame.place(x=x, y=y)
    return frame

def criar_painel_rolagem(pai, largura=200, altura=200, x=0, y=0, titulo=None):
    frame = ctk.CTkScrollableFrame(pai, width=largura, height=altura, label_text=titulo, corner_radius=15)
    frame.place(x=x, y=y)
    return frame

def criar_abas(pai, x=0, y=0, largura=300, altura=200):
    tabview = ctk.CTkTabview(pai, width=largura, height=altura, corner_radius=15)
    tabview.place(x=x, y=y)
    return tabview

def adicionar_aba(abas, nome): return abas.add(nome)
def pegar_aba(abas, nome): return abas.tab(nome)

# ==========================================
# SLIDERS E PROGRESSO
# ==========================================
def criar_deslizante(pai, min_val=0, max_val=100, x=0, y=0, comando=None):
    sld = ctk.CTkSlider(pai, from_=min_val, to=max_val, command=comando)
    sld.set(min_val)
    sld.place(x=x, y=y)
    return sld

def definir_valor_deslizante(sld, val): sld.set(val)
def pegar_valor_deslizante(sld): return sld.get()

def criar_barra_progresso(pai, x=0, y=0, largura=200):
    bar = ctk.CTkProgressBar(pai, width=largura)
    bar.set(0)
    bar.place(x=x, y=y)
    return bar

def atualizar_barra_progresso(bar, val): bar.set(val)
def iniciar_progresso_infinito(bar): bar.start()

# ==========================================
# DIÁLOGOS
# ==========================================
def caixa_pergunta(titulo, msg):
    # Retorna True (OK) ou False (Cancelar)
    dialogo = ctk.CTkInputDialog(text=msg, title=titulo)
    resposta = dialogo.get_input()
    return True if resposta else False

def caixa_entrada_texto(titulo, msg):
    # Retorna o texto digitado
    dialogo = ctk.CTkInputDialog(text=msg, title=titulo)
    return dialogo.get_input()

# ==========================================
# UTILIDADES GERAIS
# ==========================================
def esconder(elemento): elemento.place_forget()
def mostrar(elemento, x, y): elemento.place(x=x, y=y)
def configurar_elemento(elemento, **kwargs): elemento.configure(**kwargs)

# ==========================================
# DATASTORE V14
# ==========================================
def v14_conectar(projeto):
    print(f"[DATASTORE V14] Sistema de Arquivos Profissional Ativado: {projeto}")

def v14_salvar(chave, valor):
    print(f"[DATASTORE V14] Gravando: {chave} -> {valor}")

def v14_carregar(chave):
    return f"Resultado de {chave}"