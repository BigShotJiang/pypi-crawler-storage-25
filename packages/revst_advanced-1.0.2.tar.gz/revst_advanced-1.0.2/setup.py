from setuptools import setup, find_packages

setup(
    name="revst-advanced", # Nome que vai pro PyPI (com traço é liberado aqui no nome, só não pode na pasta)
    version="1.0.2",
    author="Max",
    description="Interface gráfica profissional e moderna, 100% em português, baseada em CustomTkinter.",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    # A MÁGICA ACONTECE AQUI:
    install_requires=[
        "customtkinter>=5.2.0" # Diz pro pip baixar isso junto com a sua biblioteca
    ],
)