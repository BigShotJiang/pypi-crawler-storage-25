"""F90 — `code: NO_CHANNEL_ASSIGNED` mapping (BD sprint 12 + SDK 0.4.4).

Two surfaces:
- AccountsClient REST raises `NoChannelAssigned(ChannelError)`
- Agent.send_message returns `SendResult` with `error_code="NO_CHANNEL_ASSIGNED"`,
  `error_channel="whatsapp"`, and the server-supplied `remediation`.
"""

from __future__ import annotations

import json
from typing import Any

import pytest

from buttdial.errors import (
    ChannelError,
    NoChannelAssigned,
    parse_error_response,
)
from buttdial.models import SendResult


def test_no_channel_assigned_is_in_public_api() -> None:
    """The exception is importable from the top-level package (0.4.4+)."""
    from buttdial import NoChannelAssigned as Exported

    assert Exported is NoChannelAssigned
    assert issubclass(NoChannelAssigned, ChannelError)


def test_parse_error_response_maps_no_channel_assigned() -> None:
    """A REST 4xx with code=NO_CHANNEL_ASSIGNED maps to the typed exception."""
    body = {
        "error": 'Agent "abc" has no WhatsApp sender assigned',
        "code": "NO_CHANNEL_ASSIGNED",
        "channel": "whatsapp",
        "remediation": "Call /provision first",
    }
    exc = parse_error_response(status_code=400, body=body, headers=None)
    assert isinstance(exc, NoChannelAssigned)
    assert exc.code == "NO_CHANNEL_ASSIGNED"
    assert exc.channel == "whatsapp"
    assert exc.body == body


def test_parse_error_response_does_not_match_other_codes() -> None:
    """Unrelated codes don't accidentally route to NoChannelAssigned."""
    body = {"error": "x", "code": "NOT_PROVISIONED"}
    exc = parse_error_response(status_code=404, body=body, headers=None)
    assert not isinstance(exc, NoChannelAssigned)


def test_send_result_carries_error_code_and_channel() -> None:
    """SendResult exposes the new envelope fields (0.4.4+)."""
    r = SendResult(
        failed=True,
        error="no sender",
        error_code="NO_CHANNEL_ASSIGNED",
        error_channel="whatsapp",
        stage_failed="server",
        remediation="Call /provision first",
    )
    assert r.error_code == "NO_CHANNEL_ASSIGNED"
    assert r.error_channel == "whatsapp"
    assert r.remediation == "Call /provision first"
    assert not r.ok


def test_send_result_error_code_defaults_none_for_back_compat() -> None:
    """Existing call sites that don't pass error_code still work."""
    r = SendResult(failed=True, error="boom", stage_failed="transport")
    assert r.error_code is None
    assert r.error_channel is None


def test_extract_error_envelope_pulls_top_level_fields() -> None:
    """The Agent's static envelope extractor returns (code, channel, remediation)."""
    from buttdial.agent import Agent

    parsed: dict[str, Any] = {
        "error": "no sender",
        "code": "NO_CHANNEL_ASSIGNED",
        "channel": "whatsapp",
        "remediation": "call /provision",
    }
    code, channel, rem = Agent._extract_error_envelope(parsed)
    assert code == "NO_CHANNEL_ASSIGNED"
    assert channel == "whatsapp"
    assert rem == "call /provision"


def test_extract_error_envelope_handles_nested_error_dict() -> None:
    """Some endpoints nest under `error: {...}` instead of flat top-level."""
    from buttdial.agent import Agent

    parsed: dict[str, Any] = {
        "error": {
            "message": "no sender",
            "code": "NO_CHANNEL_ASSIGNED",
            "channel": "whatsapp",
            "remediation": "call /provision",
        }
    }
    code, channel, rem = Agent._extract_error_envelope(parsed)
    assert code == "NO_CHANNEL_ASSIGNED"
    assert channel == "whatsapp"
    assert rem == "call /provision"


def test_extract_error_envelope_returns_none_on_unknown_shape() -> None:
    """Plain string error / list / non-dict body returns (None, None, None)."""
    from buttdial.agent import Agent

    assert Agent._extract_error_envelope("plain string") == (None, None, None)
    assert Agent._extract_error_envelope({"error": "no fields"}) == (None, None, None)
    assert Agent._extract_error_envelope(None) == (None, None, None)


# NOTE: End-to-end coverage through FakeButtDialServer would also be useful,
# but the fake's `on_send(error=...)` path simulates a transport-level failure
# (no JSON body to parse), so it bypasses the envelope extractor. The
# unit-level coverage above (extract + parse + SendResult fields) is the
# load-bearing test, and round-7 live validation against call.95percent.ai
# confirmed the server emits the correct envelope shape.
