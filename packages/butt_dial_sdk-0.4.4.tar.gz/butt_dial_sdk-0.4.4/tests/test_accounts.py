"""Tests for `buttdial.accounts` — the onboarding + token-rotation REST surface.

Uses `httpx.MockTransport` (built into httpx, no extra dep) to intercept
requests. `AccountsClient.__init__` accepts a `transport=` kwarg so tests can
inject the mock; production passes nothing and gets the real httpx transport.
"""

from __future__ import annotations

import json
from collections.abc import Callable

import httpx
import pytest

from buttdial import (
    AccountsClient,
    AccountsError,
    AuthInvalidTokenError,
    AuthLockedOutError,
    AuthMissingHeaderError,
    AuthTokenRevokedError,
    ChallengeNotFound,
    ConfigError,
    EmailAlreadyRegistered,
    OTPExpired,
    OTPInvalid,
    OTPMaxAttempts,
    PhoneNotConfigured,
    RevokedToken,
    TokenRevoked,
    TransportError,
    VerificationTokenExpired,
)

BASE = "https://bd.test"


def _json_handler(
    routes: dict[tuple[str, str], httpx.Response],
    *,
    recorded: list[httpx.Request] | None = None,
) -> Callable[[httpx.Request], httpx.Response]:
    """Build a MockTransport handler from a (method, path) → Response map.

    Records each incoming request on `recorded` if provided so tests can
    assert on headers/body.
    """

    def handler(request: httpx.Request) -> httpx.Response:
        if recorded is not None:
            recorded.append(request)
        key = (request.method.upper(), request.url.path)
        if key not in routes:
            return httpx.Response(404, json={"code": "UNMOCKED", "message": f"no mock for {key}"})
        resp = routes[key]
        # Return a fresh Response so the stream isn't drained between calls.
        return httpx.Response(
            status_code=resp.status_code,
            headers=resp.headers,
            content=resp.content,
        )

    return handler


def _client(
    routes: dict[tuple[str, str], httpx.Response] | None = None,
    *,
    team_token: str | None = None,
    recorded: list[httpx.Request] | None = None,
) -> AccountsClient:
    transport = httpx.MockTransport(_json_handler(routes or {}, recorded=recorded))
    return AccountsClient(BASE, team_token=team_token, transport=transport)


# ---------------------------------------------------------------------------
# Configuration guardrails
# ---------------------------------------------------------------------------


def test_construct_requires_base_url() -> None:
    with pytest.raises(ConfigError):
        AccountsClient("")


def test_with_token_returns_a_new_instance() -> None:
    a = AccountsClient(BASE)
    b = a.with_token("tok-1")
    assert a.team_token is None
    assert b.team_token == "tok-1"
    assert a is not b


@pytest.mark.asyncio
async def test_authenticated_call_without_token_raises_config_error() -> None:
    c = _client()
    with pytest.raises(ConfigError):
        await c.set_phone("+14155550123")


# ---------------------------------------------------------------------------
# Happy path
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_register_returns_org_id_and_verification_sent() -> None:
    recorded: list[httpx.Request] = []
    c = _client(
        {
            ("POST", "/api/orgs/register"): httpx.Response(
                200, json={"org_id": "org-1", "verification_sent": True}
            ),
        },
        recorded=recorded,
    )

    result = await c.register("Acme", "alice@acme.com")
    assert result == {"org_id": "org-1", "verification_sent": True}
    assert len(recorded) == 1
    body = json.loads(recorded[0].content)
    # Server contract is camelCase.
    assert body == {"orgName": "Acme", "ownerEmail": "alice@acme.com"}
    # Register is unauthenticated — no bearer header attached.
    assert "authorization" not in {k.lower(): v for k, v in recorded[0].headers.items()}


@pytest.mark.asyncio
async def test_register_forwards_branding_return_url_webhook_email() -> None:
    """All four optional blocks land on the wire under camelCase keys."""
    recorded: list[httpx.Request] = []
    c = _client(
        {
            ("POST", "/api/orgs/register"): httpx.Response(
                200,
                json={
                    "orgId": "org-1",
                    "verificationSent": True,
                    "webhookSecret": "wh_secret_64chars",
                },
            ),
        },
        recorded=recorded,
    )

    result = await c.register(
        "Acme",
        "alice@acme.com",
        branding={
            "logoUrl": "https://x/logo.svg",
            "primaryColor": "#00C9A7",
            "productName": "iv",
            "supportEmail": "support@x",
        },
        return_url="https://x/welcome",
        webhook_url="https://x/webhook",
        verification_email={
            "subject": "Verify your iv workspace",
            "html": '<p>Click <a href="{{verifyUrl}}">here</a>.</p>',
        },
    )
    assert result["orgId"] == "org-1"
    assert result["webhookSecret"] == "wh_secret_64chars"

    body = json.loads(recorded[0].content)
    assert body["orgName"] == "Acme"
    assert body["ownerEmail"] == "alice@acme.com"
    assert body["branding"]["productName"] == "iv"
    assert body["returnUrl"] == "https://x/welcome"
    assert body["webhookUrl"] == "https://x/webhook"
    assert body["verificationEmail"]["subject"] == "Verify your iv workspace"
    assert "{{verifyUrl}}" in body["verificationEmail"]["html"]


@pytest.mark.asyncio
async def test_register_surfaces_poll_token() -> None:
    """sprint 10: pollToken is now in every register response (rotated per call)."""
    c = _client(
        {
            ("POST", "/api/orgs/register"): httpx.Response(
                200,
                json={
                    "orgId": "org-1",
                    "verificationSent": True,
                    "pollToken": "poll_token_24bytes_hex_aaaaaaaaaaaaaaaaaaaaaaaa",
                    "webhookSecret": "wh_64",
                },
            ),
        }
    )
    result = await c.register("Acme", "alice@acme.com", webhook_url="https://x/h")
    assert result["pollToken"] == "poll_token_24bytes_hex_aaaaaaaaaaaaaaaaaaaaaaaa"
    assert result["orgId"] == "org-1"
    # pollToken is host-supplied for /verification-status?poll_token=...
    # SDK doesn't auto-poll; the host wires the polling loop with this value.


@pytest.mark.asyncio
async def test_register_omits_optional_blocks_when_not_passed() -> None:
    """Backward-compat: callers that don't pass new kwargs send the original payload."""
    recorded: list[httpx.Request] = []
    c = _client(
        {
            ("POST", "/api/orgs/register"): httpx.Response(
                200, json={"orgId": "org-1", "verificationSent": True}
            ),
        },
        recorded=recorded,
    )

    await c.register("Acme", "alice@acme.com")
    body = json.loads(recorded[0].content)
    assert set(body.keys()) == {"orgName", "ownerEmail"}


@pytest.mark.asyncio
async def test_register_bare_form_emits_deprecation_warning() -> None:
    """0.4.1: bare register() call (no branding/return_url/webhook_url/verification_email)
    emits a DeprecationWarning to nudge agents toward the onboarding-handshake pattern."""
    c = _client(
        {
            ("POST", "/api/orgs/register"): httpx.Response(
                200, json={"orgId": "org-1", "verificationSent": True}
            ),
        }
    )
    with pytest.warns(DeprecationWarning, match="branding"):
        await c.register("Acme", "alice@acme.com")


@pytest.mark.asyncio
async def test_register_with_any_handshake_kwarg_does_not_warn() -> None:
    """0.4.1: passing ANY one of the new kwargs is enough to suppress the warning —
    the host has clearly engaged with the new surface, even if partially."""
    import warnings

    c = _client(
        {
            ("POST", "/api/orgs/register"): httpx.Response(
                200, json={"orgId": "org-1", "verificationSent": True, "webhookSecret": "wh"}
            ),
        }
    )
    # webhook_url alone — should not warn.
    with warnings.catch_warnings():
        warnings.simplefilter("error", DeprecationWarning)
        await c.register("Acme", "alice@acme.com", webhook_url="https://x/h")
    # branding alone — should not warn.
    with warnings.catch_warnings():
        warnings.simplefilter("error", DeprecationWarning)
        await c.register("Acme", "alice@acme.com", branding={"productName": "x"})


@pytest.mark.asyncio
async def test_register_template_missing_verify_url_raises_accounts_error() -> None:
    """Server emits TEMPLATE_MISSING_VERIFY_URL when html/text lacks {{verifyUrl}}."""
    c = _client(
        {
            ("POST", "/api/orgs/register"): httpx.Response(
                400,
                json={
                    "error": "verificationEmail.html must include the {{verifyUrl}} placeholder",
                    "code": "TEMPLATE_MISSING_VERIFY_URL",
                    "retryable": False,
                },
            ),
        }
    )
    with pytest.raises(AccountsError) as exc:
        await c.register(
            "Acme",
            "alice@acme.com",
            verification_email={"html": "<p>no placeholder</p>"},
        )
    assert exc.value.code == "TEMPLATE_MISSING_VERIFY_URL"
    assert exc.value.status_code == 400


@pytest.mark.asyncio
async def test_register_template_too_large_raises_accounts_error() -> None:
    """Server emits TEMPLATE_TOO_LARGE for >200 KB html/text bodies."""
    c = _client(
        {
            ("POST", "/api/orgs/register"): httpx.Response(
                400,
                json={
                    "error": "verificationEmail.html exceeds 200 KB limit",
                    "code": "TEMPLATE_TOO_LARGE",
                    "retryable": False,
                },
            ),
        }
    )
    with pytest.raises(AccountsError) as exc:
        await c.register(
            "Acme",
            "alice@acme.com",
            verification_email={"html": "x" * 250_000},
        )
    assert exc.value.code == "TEMPLATE_TOO_LARGE"


@pytest.mark.asyncio
async def test_verify_returns_team_token() -> None:
    c = _client(
        {
            ("POST", "/api/orgs/verify"): httpx.Response(
                200,
                json={
                    "team_token": "tok-alpha",
                    "org_id": "org-1",
                    "mode": "aggregated",
                },
            ),
        }
    )
    result = await c.verify("email-link-token")
    assert result["team_token"] == "tok-alpha"


@pytest.mark.asyncio
async def test_set_and_confirm_phone_attach_bearer_token() -> None:
    recorded: list[httpx.Request] = []
    c = _client(
        {
            ("POST", "/api/orgs/me/phone/set"): httpx.Response(200, json={"challenge_id": "ch-1"}),
            ("POST", "/api/orgs/me/phone/confirm"): httpx.Response(
                200, json={"ok": True, "phone_hint": "+1********23"}
            ),
        },
        team_token="tok-alpha",
        recorded=recorded,
    )

    ch = await c.set_phone("+14155550123")
    assert ch == {"challenge_id": "ch-1"}
    result = await c.confirm_phone("ch-1", "654321")
    assert result["ok"] is True

    for req in recorded:
        assert req.headers["authorization"] == "Bearer tok-alpha"


@pytest.mark.asyncio
async def test_rotate_token_convenience_chains_request_then_confirm() -> None:
    recorded: list[httpx.Request] = []
    c = _client(
        {
            ("POST", "/api/orgs/me/rotate-token/request"): httpx.Response(
                200, json={"challenge_id": "ch-rot", "phone_hint": "+1********23"}
            ),
            ("POST", "/api/orgs/me/rotate-token/confirm"): httpx.Response(
                200, json={"token": "tok-beta"}
            ),
        },
        team_token="tok-alpha",
        recorded=recorded,
    )

    prompted_hints: list[str] = []

    def prompt(hint: str) -> str:
        prompted_hints.append(hint)
        return "999888"

    result = await c.rotate_token(otp_prompt=prompt)
    assert result == {"token": "tok-beta"}
    assert prompted_hints == ["+1********23"]

    # Confirm request carried the OTP and the challenge id.
    confirm_body = json.loads(recorded[-1].content)
    assert confirm_body == {"challengeId": "ch-rot", "otp": "999888"}


@pytest.mark.asyncio
async def test_rotate_token_supports_async_prompt() -> None:
    recorded: list[httpx.Request] = []
    c = _client(
        {
            ("POST", "/api/orgs/me/rotate-token/request"): httpx.Response(
                200, json={"challenge_id": "ch", "phone_hint": "+1***"}
            ),
            ("POST", "/api/orgs/me/rotate-token/confirm"): httpx.Response(
                200, json={"token": "tok-new"}
            ),
        },
        team_token="tok-alpha",
        recorded=recorded,
    )

    async def prompt(_hint: str) -> str:
        return "111222"

    result = await c.rotate_token(otp_prompt=prompt)
    assert result["token"] == "tok-new"
    confirm_body = json.loads(recorded[-1].content)
    assert confirm_body["otp"] == "111222"


@pytest.mark.asyncio
async def test_get_account_returns_account_shape() -> None:
    c = _client(
        {
            ("GET", "/api/orgs/me"): httpx.Response(
                200,
                json={
                    "org_id": "org-1",
                    "name": "Acme",
                    "owner_email": "alice@acme.com",
                    "owner_phone_hint": "+1********23",
                    "mode": "aggregated",
                    "created_at": "2026-04-24T12:00:00Z",
                    "status": "active",
                },
            ),
        },
        team_token="tok-alpha",
    )
    info = await c.get_account()
    assert info["org_id"] == "org-1"
    assert info["owner_phone_hint"] == "+1********23"


# ---------------------------------------------------------------------------
# Error-code → exception mapping
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_email_already_registered() -> None:
    c = _client(
        {
            ("POST", "/api/orgs/register"): httpx.Response(
                409,
                json={
                    "code": "EMAIL_ALREADY_REGISTERED",
                    "message": "alice@acme.com already owns an org",
                },
            ),
        }
    )
    with pytest.raises(EmailAlreadyRegistered) as exc:
        await c.register("Acme", "alice@acme.com")
    assert exc.value.code == "EMAIL_ALREADY_REGISTERED"
    assert exc.value.status_code == 409
    assert isinstance(exc.value, AccountsError)


@pytest.mark.asyncio
async def test_verification_token_expired() -> None:
    c = _client(
        {
            ("POST", "/api/orgs/verify"): httpx.Response(
                400,
                json={
                    "code": "VERIFICATION_TOKEN_EXPIRED",
                    "message": "Link expired",
                },
            ),
        }
    )
    with pytest.raises(VerificationTokenExpired):
        await c.verify("stale-token")


@pytest.mark.asyncio
async def test_phone_not_configured_on_rotate() -> None:
    c = _client(
        {
            ("POST", "/api/orgs/me/rotate-token/request"): httpx.Response(
                400,
                json={
                    "code": "PHONE_NOT_CONFIGURED",
                    "message": "Set an admin phone before rotating",
                },
            ),
        },
        team_token="tok-alpha",
    )
    with pytest.raises(PhoneNotConfigured):
        await c.rotate_token_request()


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("code", "cls"),
    [
        ("OTP_INVALID", OTPInvalid),
        ("OTP_EXPIRED", OTPExpired),
        ("OTP_MAX_ATTEMPTS", OTPMaxAttempts),
        ("CHALLENGE_NOT_FOUND", ChallengeNotFound),
    ],
)
async def test_otp_and_challenge_errors_map_to_typed_exceptions(code, cls) -> None:
    c = _client(
        {
            ("POST", "/api/orgs/me/phone/confirm"): httpx.Response(
                400, json={"code": code, "message": "nope"}
            ),
        },
        team_token="tok-alpha",
    )
    with pytest.raises(cls) as exc:
        await c.confirm_phone("ch-1", "000000")
    assert exc.value.code == code


@pytest.mark.asyncio
async def test_token_revoked_on_get_account_after_rotation() -> None:
    c = _client(
        {
            ("GET", "/api/orgs/me"): httpx.Response(
                401,
                json={
                    "code": "TOKEN_REVOKED",
                    "message": "This token was rotated out",
                },
            ),
        },
        team_token="tok-old",
    )
    with pytest.raises(TokenRevoked):
        await c.get_account()


@pytest.mark.asyncio
async def test_unknown_error_code_falls_back_to_base_accounts_error() -> None:
    c = _client(
        {
            ("POST", "/api/orgs/register"): httpx.Response(
                500,
                json={
                    "code": "INTERNAL_UNKNOWN",
                    "message": "something exploded",
                },
            ),
        }
    )
    with pytest.raises(AccountsError) as exc:
        await c.register("Acme", "alice@acme.com")
    # Not one of the typed subclasses — raw AccountsError.
    assert type(exc.value) is AccountsError
    assert exc.value.code == "INTERNAL_UNKNOWN"
    assert exc.value.status_code == 500


@pytest.mark.asyncio
async def test_error_without_code_uses_reason_phrase() -> None:
    c = _client(
        {
            ("POST", "/api/orgs/register"): httpx.Response(503, text=""),
        }
    )
    with pytest.raises(AccountsError) as exc:
        await c.register("Acme", "alice@acme.com")
    assert "503" in str(exc.value)


# ---------------------------------------------------------------------------
# Transport errors
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_network_error_surfaces_as_transport_error() -> None:
    def handler(_request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("dns blackhole")

    transport = httpx.MockTransport(handler)
    c = AccountsClient(BASE, transport=transport)

    with pytest.raises(TransportError):
        await c.register("Acme", "alice@acme.com")


# ---------------------------------------------------------------------------
# Auth-middleware errors (new wire shape with code/retryable/remainingAttempts)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_401_auth_invalid_token_raises_typed_exception() -> None:
    c = _client(
        {
            ("GET", "/api/orgs/me"): httpx.Response(
                401,
                json={
                    "error": "Invalid or revoked token",
                    "code": "AUTH_INVALID_TOKEN",
                    "retryable": False,
                    "remainingAttempts": 7,
                },
            ),
        },
        team_token="tok-bogus",
    )
    with pytest.raises(AuthInvalidTokenError) as exc:
        await c.get_account()
    assert exc.value.retryable is False
    assert exc.value.remaining_attempts == 7


@pytest.mark.asyncio
async def test_401_auth_token_revoked_uses_new_typed_class() -> None:
    """AUTH_TOKEN_REVOKED is the auth-middleware signal — distinct from accounts.TokenRevoked."""
    c = _client(
        {
            ("GET", "/api/orgs/me"): httpx.Response(
                401,
                json={
                    "error": "Token revoked",
                    "code": "AUTH_TOKEN_REVOKED",
                    "retryable": False,
                    "remainingAttempts": 9,
                },
            ),
        },
        team_token="tok-revoked",
    )
    with pytest.raises(AuthTokenRevokedError):
        await c.get_account()


@pytest.mark.asyncio
async def test_401_auth_missing_header_typed_class() -> None:
    c = _client(
        {
            ("GET", "/api/orgs/me"): httpx.Response(
                401,
                json={
                    "error": "Missing Authorization header",
                    "code": "AUTH_MISSING_HEADER",
                    "retryable": False,
                    "remainingAttempts": 9,
                },
            ),
        },
        team_token="tok-x",
    )
    with pytest.raises(AuthMissingHeaderError):
        await c.get_account()


@pytest.mark.asyncio
async def test_429_auth_locked_out_carries_retry_after() -> None:
    c = _client(
        {
            ("GET", "/api/orgs/me"): httpx.Response(
                429,
                headers={"Retry-After": "873"},
                json={
                    "error": "Too many failed attempts. Try again later.",
                    "code": "AUTH_LOCKED_OUT",
                    "retryable": True,
                    "lockedUntil": "2026-04-25T11:42:13Z",
                    "retryAfterSeconds": 873,
                },
            ),
        },
        team_token="tok-x",
    )
    with pytest.raises(AuthLockedOutError) as exc:
        await c.get_account()
    assert exc.value.retry_after_seconds == 873
    assert exc.value.locked_until is not None


@pytest.mark.asyncio
async def test_legacy_token_revoked_still_maps_to_accounts_class() -> None:
    """Back-compat: code=TOKEN_REVOKED (no AUTH_ prefix) keeps mapping to AccountsError.TokenRevoked."""
    c = _client(
        {
            ("GET", "/api/orgs/me"): httpx.Response(
                401,
                json={"code": "TOKEN_REVOKED", "message": "rotated out"},
            ),
        },
        team_token="tok-old",
    )
    with pytest.raises(TokenRevoked):
        await c.get_account()


def test_revoked_token_is_alias_of_auth_token_revoked_error() -> None:
    """RevokedToken is an ergonomic alias — same class, both names work."""
    assert RevokedToken is AuthTokenRevokedError


# ---------------------------------------------------------------------------
# Agent registration (host owns agent_id UUID)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_register_agent_passes_host_supplied_agent_id() -> None:
    """The host generates the UUID; BD echoes it back with a runtime token."""
    recorded: list[httpx.Request] = []
    c = _client(
        {
            ("POST", "/api/v1/agents"): httpx.Response(
                200, json={"agent_id": "agt-host-uuid", "token": "agent-runtime-tok"}
            ),
        },
        team_token="team-tok",
        recorded=recorded,
    )

    result = await c.register_agent("agt-host-uuid", display_name="Yuna")
    assert result == {"agent_id": "agt-host-uuid", "token": "agent-runtime-tok"}

    # Verify the host's UUID was sent in the body, not generated server-side.
    body = json.loads(recorded[0].content)
    assert body["agent_id"] == "agt-host-uuid"
    assert body["display_name"] == "Yuna"
    # Authenticated with the team_token (org admin credential).
    assert recorded[0].headers["authorization"] == "Bearer team-tok"


@pytest.mark.asyncio
async def test_register_agent_forwards_extra_fields() -> None:
    """Extra kwargs land in the request body — useful for email/phone/etc."""
    recorded: list[httpx.Request] = []
    c = _client(
        {
            ("POST", "/api/v1/agents"): httpx.Response(
                200, json={"agent_id": "agt-1", "token": "tok"}
            ),
        },
        team_token="team-tok",
        recorded=recorded,
    )

    await c.register_agent(
        "agt-1",
        display_name="Yuna",
        email="yuna@acme.com",
        phone="+15551234567",
    )
    body = json.loads(recorded[0].content)
    assert body["email"] == "yuna@acme.com"
    assert body["phone"] == "+15551234567"


@pytest.mark.asyncio
async def test_register_agent_rejects_empty_agent_id() -> None:
    """The SDK refuses to call BD without an agent_id — host must provide one."""
    c = _client(team_token="team-tok")
    with pytest.raises(ConfigError, match="agent_id is required"):
        await c.register_agent("", display_name="Yuna")


@pytest.mark.asyncio
async def test_provision_channels_forwards_to_provision_endpoint() -> None:
    """provision_channels wraps POST /api/v1/provision and preserves agent_id."""
    recorded: list[httpx.Request] = []
    c = _client(
        {
            ("POST", "/api/v1/provision"): httpx.Response(
                200,
                json={
                    "success": True,
                    "agentId": "agt-host-uuid",
                    "agentName": "Maya",
                    "token": "tok-provisioned",
                    "channels": {
                        "whatsapp": {"number": "+14155550100", "status": "active"},
                    },
                },
            ),
        },
        team_token="team-tok",
        recorded=recorded,
    )

    result = await c.provision_channels(
        "agt-host-uuid",
        display_name="Maya",
        callback_url="https://host.example/webhook/maya",
        capabilities={"whatsapp": True},
    )

    assert result["agentId"] == "agt-host-uuid"
    assert result["token"] == "tok-provisioned"
    assert result["channels"]["whatsapp"]["status"] == "active"

    # Wire shape is BD's existing camelCase /provision contract.
    body = json.loads(recorded[0].content)
    assert body["agentId"] == "agt-host-uuid"
    assert body["agentName"] == "Maya"
    assert body["callbackUrl"] == "https://host.example/webhook/maya"
    assert body["capabilities"] == {"whatsapp": True}
    assert body["country"] == "US"  # default
    assert body["identityMode"] == "dedicated"  # default


@pytest.mark.asyncio
async def test_provision_channels_omits_optional_fields_when_unset() -> None:
    """Unset optional kwargs are NOT sent (avoids overwriting server defaults)."""
    recorded: list[httpx.Request] = []
    c = _client(
        {
            ("POST", "/api/v1/provision"): httpx.Response(
                200,
                json={"success": True, "agentId": "x", "token": "t", "channels": {}},
            ),
        },
        team_token="team-tok",
        recorded=recorded,
    )

    await c.provision_channels(
        "x",
        display_name="X",
        callback_url="https://x/cb",
        capabilities=["whatsapp"],
    )

    body = json.loads(recorded[0].content)
    for k in (
        "preferredWhatsappNumber",
        "preferredPhoneNumber",
        "language",
        "gender",
        "voiceId",
        "greeting",
        "systemPrompt",
        "emailDomain",
    ):
        assert k not in body, f"{k} should be omitted when unset"


@pytest.mark.asyncio
async def test_provision_channels_rejects_empty_agent_id() -> None:
    c = _client(team_token="team-tok")
    with pytest.raises(ConfigError, match="agent_id is required"):
        await c.provision_channels(
            "",
            display_name="Y",
            callback_url="https://y/cb",
            capabilities={"whatsapp": True},
        )


@pytest.mark.asyncio
async def test_verify_normalizes_legacy_owner_token_response() -> None:
    """Server still uses owner_token in the wire shape; SDK presents it as team_token."""
    c = _client(
        {
            ("POST", "/api/orgs/verify"): httpx.Response(
                200,
                json={
                    "owner_token": "tok-legacy",
                    "org_id": "org-1",
                    "mode": "aggregated",
                },
            ),
        }
    )
    result = await c.verify("email-link-token")
    assert result["team_token"] == "tok-legacy"
    assert "owner_token" not in result


@pytest.mark.asyncio
async def test_error_carries_status_code_and_body() -> None:
    """Every typed error exposes .status_code, .code, .body (spec section 5)."""
    payload = {
        "error": "Invalid or revoked token",
        "code": "AUTH_INVALID_TOKEN",
        "retryable": False,
        "remainingAttempts": 5,
    }
    c = _client(
        {
            ("GET", "/api/orgs/me"): httpx.Response(401, json=payload),
        },
        team_token="bad",
    )
    with pytest.raises(AuthInvalidTokenError) as exc:
        await c.get_account()
    assert exc.value.status_code == 401
    assert exc.value.code == "AUTH_INVALID_TOKEN"
    assert exc.value.body == payload
