"""Per-agent runtime tunnel to a Butt-Dial MCP server.

The :class:`Agent` is a thin client that holds three things:

- ``base_url``    — BD server root (the SSE endpoint is ``<base>/sse``)
- ``agent_id``    — host-supplied UUID for this agent. BD echoes it on
  registration but does not generate it; the host owns identity.
- ``agent_token`` — per-agent runtime bearer token

The Agent is intentionally narrow: it sends and receives. Org-level
admin work (registering this agent, rotating tokens, billing) lives on
:class:`buttdial.AccountsClient` with its own ``team_token``.

Token resolution
----------------

Per-call ``agent_token`` overrides the instance default — useful for
multi-tenant hosts that hold one ``Agent`` for transport but multiplex
different agent tokens onto it. If neither is set, ``send_message``
returns ``SendResult(failed=True, stage_failed="config")``.

Retries + auth contract
-----------------------

3 attempts with exponential backoff (2s, 4s, 8s, capped at 10s). On
exhaustion, returns ``SendResult(failed=True)`` — does not raise.

Auth errors (``AuthInvalidTokenError``, ``RevokedToken`` /
``AuthTokenRevokedError``, ``AuthMissingHeaderError``) propagate
immediately as typed exceptions — they are ``retryable=false`` per BD's
contract, and naive retry walks straight into the per-IP brute-force
lockout.

WhatsApp actions
----------------

Beyond ``send_message`` the Agent exposes :meth:`whatsapp_action` and
13 typed helpers (``typing``, ``mark_read``, ``react``, ``edit``,
``forward``, ``delete``, ``send_poll``, ``send_buttons``,
``send_location``, ``send_contact``, ``post_status``, ``set_chat_ttl``,
``send_view_once``) that wrap BD's ``comms_whatsapp_action`` MCP tool.
Provider mismatches (e.g. greenapi cannot ``post_status``) raise
:class:`ProviderCapabilityError`.
"""

from __future__ import annotations

import asyncio
import json
import logging
import uuid
from typing import Any

from buttdial.errors import (
    AuthInvalidTokenError,
    AuthMissingHeaderError,
    AuthTokenRevokedError,
    ProviderCapabilityError,
)
from buttdial.models import Channel, SendResult
from buttdial.settings import load as load_settings

logger = logging.getLogger(__name__)

SEND_TOOL = "comms_send_message"
WA_ACTION_TOOL = "comms_whatsapp_action"


# Server-error substring → remediation text. Used when BD returns a
# business-level ``{"error": "..."}`` so callers see actionable next
# steps, not just the raw server string.
_SERVER_ERROR_REMEDIATIONS: list[tuple[str, str]] = [
    (
        "agentid is required",
        "This tool needs agent context. Either pass `agent_token=<per-agent token>` "
        "to send_message(), or construct Agent(..., agent_token=<per-agent token>).",
    ),
    (
        "agent id is required",
        "Pass `agent_token=<per-agent token>` or set agent_token on the Agent constructor.",
    ),
    (
        "invalid recipient",
        "Recipient must be E.164 format (+country code). Example: +14155550123.",
    ),
    (
        "invalid_recipient",
        "Recipient must be E.164 format (+country code). Example: +14155550123.",
    ),
    (
        "consent",
        "Recipient has not consented / is opted out. Check the opt-in status "
        "before sending, or configure consent-on-first-message in the Butt-Dial admin console.",
    ),
    (
        "rate limit",
        "Rate limit hit. Back off and retry with exponential delay, or request a higher quota.",
    ),
    (
        "not provisioned",
        "The sending channel is not provisioned for this team. Provision the channel "
        "in the Butt-Dial admin console before sending.",
    ),
]


def _server_error_remediation(error_text: str) -> str | None:
    """Map a server-returned error string to an actionable remediation. None if unknown."""
    lower = (error_text or "").lower()
    for trigger, remedy in _SERVER_ERROR_REMEDIATIONS:
        if trigger in lower:
            return remedy
    return None


# WhatsApp actions the SDK knows about. Used to short-circuit unknown
# actions before hitting the wire. The server is the authority on what
# each provider supports — we surface mismatches via
# :class:`ProviderCapabilityError` from the response.
_WA_ACTIONS = frozenset(
    {
        "typing",
        "mark_read",
        "react",
        "edit",
        "forward",
        "delete",
        "send_poll",
        "send_buttons",
        "send_location",
        "send_contact",
        "post_status",
        "set_chat_ttl",
        "send_view_once",
    }
)


class Agent:
    """Per-agent runtime tunnel to a Butt-Dial MCP server.

    Parameters
    ----------
    base_url:
        BD server root (without ``/sse`` and without ``/api/...``).
        Example: ``"https://call.95percent.ai"``. The Agent appends
        ``/sse`` for MCP and ``/api/v1/...`` for REST internally.
    agent_id:
        Host-chosen UUID for this agent. Optional — required only by
        actions that resolve agent context server-side.
    agent_token:
        Per-agent runtime bearer token. Required for all transport.
        Per-call ``agent_token`` overrides this (multi-tenant pattern).
    send_tool:
        MCP tool name for sending. Defaults to ``"comms_send_message"``.
    max_send_attempts:
        Retries for transient transport failures. Default 3.
    sse_timeout:
        SSE connect timeout in seconds. Default 30.
    """

    def __init__(
        self,
        base_url: str | None = None,
        *,
        agent_id: str | None = None,
        agent_token: str | None = None,
        send_tool: str = SEND_TOOL,
        max_send_attempts: int = 3,
        sse_timeout: float = 30.0,
    ) -> None:
        if not base_url:
            raise ValueError("Agent requires `base_url` (Butt-Dial server root).")
        cleaned = base_url.rstrip("/")
        # Tolerate base_url given with /sse already (legacy callers).
        if cleaned.endswith("/sse"):
            self.base_url = cleaned[:-4]
            self.sse_url = cleaned
        else:
            self.base_url = cleaned
            self.sse_url = f"{cleaned}/sse"
        self.agent_id = agent_id or ""
        self.agent_token = agent_token or ""
        self.send_tool = send_tool
        self.max_send_attempts = max_send_attempts
        self.sse_timeout = sse_timeout

    @classmethod
    def from_env(cls, **overrides: Any) -> Agent:
        """Build an Agent from ``BUTT_DIAL_*`` env vars."""
        s = load_settings()
        # Prefer BUTT_DIAL_BASE_URL; fall back to BUTT_DIAL_URL (legacy).
        base = overrides.pop("base_url", s.base_url or s.url)
        return cls(
            base_url=base,
            agent_id=overrides.pop("agent_id", s.agent_id),
            agent_token=overrides.pop("agent_token", s.agent_token),
            **overrides,
        )

    def _resolve_token(self, agent_token: str | None) -> str:
        return agent_token or self.agent_token

    # ----- send_message ---------------------------------------------------

    async def send_message(
        self,
        to: str,
        body: str | None = None,
        channel: Channel = "whatsapp",
        *,
        agent_token: str | None = None,
        media_url: str | None = None,
        sender_sid: str | None = None,
        sender_name: str | None = None,
        language: str | None = None,
        fallback_channels: list[str] | None = None,
        scheduled_at: str | None = None,
        thread_id: str | None = None,
        entity_id: str | None = None,
        reply_msg_id: str | None = None,
        idempotency_key: str | None = None,
        extra: dict[str, Any] | None = None,
    ) -> SendResult:
        """Send a single message via Butt-Dial.

        Either ``body`` or ``media_url`` must be set. ``sender_sid``
        explicitly routes through a specific provisioned number, which
        is how callers control provider failover (greenapi vs twilio
        vs waha) when the org has multiple senders.

        Returns a ``SendResult``; does not raise on transient failures
        (retried internally). On exhaustion returns
        ``SendResult(failed=True)`` with ``stage_failed`` +
        ``remediation`` set. Auth errors propagate as typed exceptions
        (``RevokedToken`` / ``AuthInvalidTokenError`` /
        ``AuthMissingHeaderError``) so the host can prompt re-auth
        instead of retrying into a lockout.
        """
        if not body and not media_url:
            return SendResult(
                failed=True,
                error="send_message requires either `body` or `media_url`",
                stage_failed="config",
                remediation="Pass body=... for text or media_url=... for media.",
            )

        token = self._resolve_token(agent_token)
        if not token:
            logger.error("send_message: no agent_token configured")
            return SendResult(
                failed=True,
                error="No Butt-Dial agent_token configured",
                stage_failed="config",
                remediation=(
                    "Set BUTT_DIAL_AGENT_TOKEN, or pass agent_token=... to "
                    "Agent(), or agent_token=... to send_message()."
                ),
            )

        args: dict[str, Any] = {
            "to": to,
            "channel": channel,
            "idempotencyKey": idempotency_key or str(uuid.uuid4()),
        }
        if body:
            args["body"] = body
        if media_url:
            args["mediaUrl"] = media_url
        if sender_sid:
            args["senderSid"] = sender_sid
        if sender_name:
            args["senderName"] = sender_name
        if language:
            args["language"] = language
        if fallback_channels:
            args["fallbackChannels"] = fallback_channels
        if scheduled_at:
            args["scheduledAt"] = scheduled_at
        if thread_id:
            args["threadId"] = thread_id
        if entity_id:
            args["entityId"] = entity_id
        if reply_msg_id:
            args["replyMsgId"] = reply_msg_id
        if extra:
            args.update(extra)

        last_exc: BaseException | None = None
        parsed: Any = None
        raw: Any = None

        for attempt_num in range(self.max_send_attempts):
            try:
                parsed, raw = await self._call_tool(token, self.send_tool, args)
                last_exc = None
                break
            except (AuthInvalidTokenError, AuthTokenRevokedError, AuthMissingHeaderError):
                # `retryable=False` per BD's auth contract. Re-trying the
                # same bad credentials walks straight into the per-IP
                # brute-force lockout (10 fails → 15 min). Surface
                # immediately so the integrator can prompt for a fresh
                # token instead of looping.
                raise
            except Exception as exc:
                last_exc = exc
                logger.warning(
                    "send_message attempt %d/%d failed: %s",
                    attempt_num + 1,
                    self.max_send_attempts,
                    exc,
                )
                if attempt_num < self.max_send_attempts - 1:
                    delay = min(10.0, 2.0 ** (attempt_num + 1))
                    await asyncio.sleep(delay)

        if last_exc is not None:
            return SendResult(
                failed=True,
                error=str(last_exc),
                stage_failed="transport",
                remediation=(
                    "Check Butt-Dial server reachability and token validity — "
                    "run `buttdial doctor` for a staged diagnostic."
                ),
            )

        message_sid = self._extract_sid(parsed)
        if message_sid:
            logger.info("send_message: to=%s channel=%s sid=%s", to, channel, message_sid)
            return SendResult(message_sid=message_sid, raw=raw)

        # No SID — did the server tell us why?
        server_error = self._extract_server_error(parsed)
        if server_error:
            logger.warning("send_message: server returned error: %s", server_error)
            code, channel, server_remediation = self._extract_error_envelope(parsed)
            return SendResult(
                failed=True,
                error=server_error,
                error_code=code,
                error_channel=channel,
                stage_failed="server",
                # Prefer the server-supplied remediation when present (BD F90+).
                # Fall back to the SDK's curated remediation map.
                remediation=server_remediation or _server_error_remediation(server_error),
                raw=raw,
            )

        logger.warning("send_message: no message_sid and no error in response: %r", parsed)
        return SendResult(
            failed=True,
            error="server response contained no message_sid and no error",
            stage_failed="parse",
            remediation=(
                "Butt-Dial server returned an unrecognized response shape. "
                "Check the server version and the SDK's Agent.send_tool name."
            ),
            raw=raw,
        )

    # ----- WhatsApp actions ----------------------------------------------

    async def whatsapp_action(
        self,
        action: str,
        *,
        agent_token: str | None = None,
        sender_sid: str | None = None,
        **params: Any,
    ) -> dict[str, Any]:
        """Generic dispatch into ``comms_whatsapp_action``.

        Prefer the typed helpers (:meth:`typing`, :meth:`react`, etc.) —
        they pin the right argument names. This method is the escape
        hatch for forward-compat or actions added server-side that the
        SDK does not yet have a typed wrapper for.

        Raises :class:`ProviderCapabilityError` if BD rejects the
        provider/action combination (e.g. greenapi + post_status).
        Returns the parsed response dict (``{ok: bool, ...}`` or
        ``{messageId: ...}`` depending on action).
        """
        if action not in _WA_ACTIONS:
            raise ValueError(f"Unknown WhatsApp action {action!r}. Known: {sorted(_WA_ACTIONS)}")
        token = self._resolve_token(agent_token)
        if not token:
            raise ValueError("whatsapp_action requires agent_token (per-call or on the Agent).")
        args: dict[str, Any] = {"action": action, **params}
        if sender_sid:
            args["senderSid"] = sender_sid
        parsed, _raw = await self._call_tool(token, WA_ACTION_TOOL, args)
        # Translate BD's provider-capability error into a typed exception.
        if isinstance(parsed, dict):
            err_code = parsed.get("code")
            if err_code in ("PROVIDER_UNSUPPORTED", "CHANNEL_UNSUPPORTED"):
                raise ProviderCapabilityError(
                    str(parsed.get("error") or f"Provider does not support {action}"),
                    code=str(err_code),
                    action=action,
                    channel=parsed.get("channel"),
                    provider=parsed.get("provider"),
                    body=parsed,
                )
        return parsed if isinstance(parsed, dict) else {"raw": parsed}

    # Typed helpers — one per documented action. Argument names match
    # BD's MCP tool schema (camelCase preserved on the wire).

    async def typing(self, *, to: str, **kw: Any) -> dict[str, Any]:
        """Send a 'typing…' indicator."""
        return await self.whatsapp_action("typing", to=to, **kw)

    async def mark_read(self, *, messageId: str, **kw: Any) -> dict[str, Any]:
        """Mark a received message as read."""
        return await self.whatsapp_action("mark_read", messageId=messageId, **kw)

    async def react(self, *, messageId: str, emoji: str, **kw: Any) -> dict[str, Any]:
        """React to a message with an emoji."""
        return await self.whatsapp_action("react", messageId=messageId, emoji=emoji, **kw)

    async def edit(self, *, messageId: str, body: str, **kw: Any) -> dict[str, Any]:
        """Edit a previously-sent message's body."""
        return await self.whatsapp_action("edit", messageId=messageId, body=body, **kw)

    async def forward(self, *, messageId: str, to: str, **kw: Any) -> dict[str, Any]:
        """Forward a message to a new recipient."""
        return await self.whatsapp_action("forward", messageId=messageId, to=to, **kw)

    async def delete(self, *, messageId: str, **kw: Any) -> dict[str, Any]:
        """Delete (revoke) a previously-sent message."""
        return await self.whatsapp_action("delete", messageId=messageId, **kw)

    async def send_poll(
        self, *, to: str, title: str, options: list[str], **kw: Any
    ) -> dict[str, Any]:
        """Send a poll. Returns ``{messageId}``."""
        return await self.whatsapp_action("send_poll", to=to, title=title, options=options, **kw)

    async def send_buttons(
        self,
        *,
        to: str,
        body: str,
        buttons: list[dict[str, Any]],
        **kw: Any,
    ) -> dict[str, Any]:
        """Send an interactive-buttons message. Returns ``{messageId}``."""
        return await self.whatsapp_action("send_buttons", to=to, body=body, buttons=buttons, **kw)

    async def send_location(
        self,
        *,
        to: str,
        lat: float,
        lng: float,
        name: str | None = None,
        **kw: Any,
    ) -> dict[str, Any]:
        """Send a location pin. Returns ``{messageId}``."""
        if name is not None:
            kw["name"] = name
        return await self.whatsapp_action("send_location", to=to, lat=lat, lng=lng, **kw)

    async def send_contact(self, *, to: str, vcard: str, **kw: Any) -> dict[str, Any]:
        """Send a contact card (vCard). Returns ``{messageId}``."""
        return await self.whatsapp_action("send_contact", to=to, vcard=vcard, **kw)

    async def post_status(
        self, *, body: str, mediaUrl: str | None = None, **kw: Any
    ) -> dict[str, Any]:
        """Post a status / story.

        Provider-only: greenapi rejects this; only twilio supports it.
        Raises :class:`ProviderCapabilityError` on rejection.
        """
        if mediaUrl is not None:
            kw["mediaUrl"] = mediaUrl
        return await self.whatsapp_action("post_status", body=body, **kw)

    async def set_chat_ttl(self, *, chatId: str, ttlSeconds: int, **kw: Any) -> dict[str, Any]:
        """Set disappearing-message TTL on a chat."""
        return await self.whatsapp_action(
            "set_chat_ttl", chatId=chatId, ttlSeconds=ttlSeconds, **kw
        )

    async def send_view_once(
        self,
        *,
        to: str,
        mediaUrl: str,
        body: str | None = None,
        **kw: Any,
    ) -> dict[str, Any]:
        """Send a view-once media message. Returns ``{messageId}``."""
        if body is not None:
            kw["body"] = body
        return await self.whatsapp_action("send_view_once", to=to, mediaUrl=mediaUrl, **kw)

    # ----- internals -----------------------------------------------------

    async def _call_tool(
        self,
        token: str,
        tool_name: str,
        args: dict[str, Any],
    ) -> tuple[Any, Any]:
        """Open SSE, initialize session, invoke an MCP tool. Returns (parsed, raw_result)."""
        import httpx
        from mcp import ClientSession
        from mcp.client.sse import sse_client

        from buttdial.errors import AuthError as _AuthError

        headers = {"Authorization": f"Bearer {token}"}
        try:
            async with sse_client(  # noqa: SIM117  (read,write tuple-unpack feeds the inner CM)
                self.sse_url, headers=headers, timeout=self.sse_timeout
            ) as (read, write):
                async with ClientSession(read, write) as session:
                    await session.initialize()
                    result = await session.call_tool(tool_name, arguments=args)
                    text = result.content[0].text if result.content else None
                    try:
                        parsed = json.loads(text) if text else None
                    except (json.JSONDecodeError, TypeError):
                        parsed = text
                    return parsed, result
        except httpx.HTTPStatusError as exc:
            self._raise_typed_error_for_response(exc.response)
            raise  # pragma: no cover - parse_error_response handles 401/429
        except _AuthError:
            raise

    @staticmethod
    def _raise_typed_error_for_response(response: Any) -> None:
        """Inspect an HTTP error response; raise typed BD error if recognized."""
        from buttdial.errors import parse_error_response

        status = getattr(response, "status_code", 0)
        if status not in (401, 429):
            return
        try:
            body = response.json()
        except Exception:
            body = None
        try:
            response_headers = dict(response.headers)
        except Exception:  # pragma: no cover - defensive
            response_headers = {}
        raise parse_error_response(
            status_code=status,
            body=body,
            headers=response_headers,
        )

    @staticmethod
    def _extract_sid(parsed: Any) -> str | None:
        if isinstance(parsed, dict):
            return parsed.get("messageId") or parsed.get("sid") or parsed.get("message_sid")
        return None

    @staticmethod
    def _extract_server_error(parsed: Any) -> str | None:
        """Pull a human-readable error text from a business-level failure response."""
        if not isinstance(parsed, dict):
            return None
        err = parsed.get("error")
        if isinstance(err, str) and err:
            return err
        errors = parsed.get("errors")
        if isinstance(errors, list) and errors:
            return "; ".join(str(e) for e in errors)
        return None

    @staticmethod
    def _extract_error_envelope(parsed: Any) -> tuple[str | None, str | None, str | None]:
        """Pull (code, channel, remediation) from BD's structured error envelope.

        BD's `/api/v1/*` envelopes ship as
            ``{"error": "...", "code": "NO_CHANNEL_ASSIGNED", "channel": "whatsapp",
               "remediation": "Call /provision first"}``
        Returns ``(None, None, None)`` for shapes the SDK doesn't recognize so
        existing string-based ``SendResult.error`` handling continues to work.
        """
        if not isinstance(parsed, dict):
            return (None, None, None)
        # Top-level shape (`{error, code, channel, remediation}`)
        code = parsed.get("code")
        channel = parsed.get("channel")
        remediation = parsed.get("remediation")
        # Some endpoints nest under `error: {...}` instead of flat top-level.
        nested = parsed.get("error")
        if isinstance(nested, dict):
            code = code or nested.get("code")
            channel = channel or nested.get("channel")
            remediation = remediation or nested.get("remediation")
        return (
            code if isinstance(code, str) else None,
            channel if isinstance(channel, str) else None,
            remediation if isinstance(remediation, str) else None,
        )

    # ----- admin / introspection -----------------------------------------

    async def list_tools(self) -> list[str]:
        """Return the names of MCP tools the BD server exposes.

        Returns an empty list on any error (disconnected, auth failure, etc.).
        """
        token = self._resolve_token(None)
        if not token:
            return []
        try:
            from mcp import ClientSession
            from mcp.client.sse import sse_client

            headers = {"Authorization": f"Bearer {token}"}
            async with sse_client(  # noqa: SIM117  (read,write tuple-unpack feeds the inner CM)
                self.sse_url, headers=headers, timeout=self.sse_timeout
            ) as (read, write):
                async with ClientSession(read, write) as session:
                    await session.initialize()
                    result = await session.list_tools()
                    return [t.name for t in result.tools]
        except Exception as exc:
            logger.warning("list_tools failed: %s", exc)
            return []

    async def ping(self, tool_name: str = "comms_ping") -> bool:
        """Call the server's ping tool. True if it returned anything; False on error."""
        token = self._resolve_token(None)
        if not token:
            return False
        try:
            from mcp import ClientSession
            from mcp.client.sse import sse_client

            headers = {"Authorization": f"Bearer {token}"}
            async with sse_client(  # noqa: SIM117  (read,write tuple-unpack feeds the inner CM)
                self.sse_url, headers=headers, timeout=self.sse_timeout
            ) as (read, write):
                async with ClientSession(read, write) as session:
                    await session.initialize()
                    result = await session.call_tool(tool_name, arguments={})
                    return bool(result and result.content)
        except Exception as exc:
            logger.debug("ping failed: %s", exc)
            return False

    async def fetch_usage_summary(self, path: str = "/api/v1/usage") -> dict[str, Any] | None:
        """Fetch the BD usage summary via REST.

        Returns the parsed JSON body on 200; None on any error.
        """
        import httpx

        token = self._resolve_token(None)
        if not token:
            return None
        try:
            async with httpx.AsyncClient(timeout=15.0) as client:
                resp = await client.get(
                    f"{self.base_url}{path}",
                    headers={"Authorization": f"Bearer {token}"},
                )
                if resp.status_code == 200:
                    data = resp.json()
                    return data if isinstance(data, dict) else None
        except Exception as exc:
            logger.debug("fetch_usage_summary failed: %s", exc)
        return None
