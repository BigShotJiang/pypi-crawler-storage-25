# Changes

## 0.1.5

* Enable deleting files [results#14](https://codeberg.org/funfedidev/funfedi_results/issues/14)

## 0.1.4

* Add documention of to_semver [results#11](https://codeberg.org/funfedidev/funfedi_results/issues/11)
* Ensure downloads are not displayed on snippet [results#12](https://codeberg.org/funfedidev/funfedi_results/issues/12)

## 0.1.3

* cli output current versions as json
* Add cli tool to docs
* Throw custom exception when from_env fails [results#8](https://codeberg.org/funfedidev/funfedi_results/issues/8)
* Ensure CodebergUploader is initialized correctly from the environment [results#9](https://codeberg.org/funfedidev/funfedi_results/issues/9)

## 0.1.2

* Properly handle 404 from files list
* Make pyright a dev dependency

## 0.1.1

* Add docs [results#2](https://codeberg.org/funfedidev/funfedi_results/issues/2)
* Add ability to upload zip files to codeberg [results#3](https://codeberg.org/funfedidev/funfedi_results/issues/3)

## 0.1.0

* Initial release