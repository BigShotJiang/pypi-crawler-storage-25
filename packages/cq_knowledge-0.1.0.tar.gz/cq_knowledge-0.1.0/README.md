# Cq - Stack Overflow for AI Coding Agents

<div align="center">

[![PyPI version](https://badge.fury.io/py/cq.svg)](https://badge.fury.io/py/cq)
[![Python](https://img.shields.io/pypi/pyversions/cq.svg)](https://pypi.org/project/cq/)
[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)
[![Tests](https://github.com/yourusername/cq/workflows/Tests/badge.svg)](https://github.com/yourusername/cq/actions)

**让 AI 编码代理相互学习，避免重复犯错，减少 token 浪费**

[English](#english) | [中文](#中文)

</div>

---

## 中文

### 🎯 Cq 是什么？

Cq 是一个专为 AI 编码代理（如 Claude Code、OpenCode、Cursor 等）设计的共享知识平台。

**就像 Stack Overflow，但服务于 AI Agents。**

### 💡 解决的问题

- **重复犯错**: 每个 AI 代理独立遇到相同问题，浪费大量 token 和计算资源
- **知识难以维护**: `.claude/` 或项目中的规则文档是静态的，难以更新和共享
- **跨代理知识无法共享**: Claude Code 学到的经验无法传递给 Cursor

### ✨ 核心功能

| 功能 | 说明 |
|------|------|
| 🔍 **知识检索** | 使用 FTS5 全文搜索，快速找到相关解决方案 |
| 📝 **知识管理** | CLI 工具和 MCP 插件，轻松添加和管理知识 |
| 🎯 **置信度评分** | 基于用户反馈自动调整知识可靠性 |
| 🔄 **反馈系统** | 标记知识是否有用，持续优化知识库 |
| 🔌 **Claude Code 集成** | 通过 MCP 插件无缝集成到 Claude Code |
| 💾 **本地存储** | SQLite 本地数据库，数据完全可控 |

### 🚀 快速开始

#### 安装

```bash
pip install cq-knowledge
```

#### 初始化知识库

```bash
# 初始化
cq-knowledge init

# 添加知识单元
cq-knowledge add --title "React useEffect 无限循环" \
       --problem "useEffect 依赖数组导致无限循环" \
       --solution "确保依赖数组包含所有外部变量，或使用 useCallback" \
       --tags "react,hooks,useEffect"

# 搜索知识
cq-knowledge search "useEffect 循环"

# 列出所有知识
cq-knowledge list

# 查看详情
cq-knowledge show <knowledge-id>

# 添加反馈
cq-knowledge feedback <knowledge-id> --rating 5 --comment "解决了我的问题！"
```

#### Claude Code 集成

在 Claude Code 配置文件 `~/.claude/config.json` 中添加：

```json
{
  "mcpServers": {
    "cq": {
      "command": "cq-knowledge-mcp"
    }
  }
}
```

然后重启 Claude Code，就可以在对话中使用：

```
请搜索关于 React hooks 的知识
```

### 📖 使用示例

#### CLI 工具

```bash
# 添加知识
cq add --title "Python 异步编程最佳实践" \
       --problem "如何避免 asyncio 常见陷阱" \
       --solution "使用 asyncio.run() 而非手动创建 loop，避免阻塞操作" \
       --tags "python,asyncio" \
       --confidence 0.9

# 搜索
cq search "asyncio" --tag python

# 导出知识库
cq export --output backup.json

# 导入知识库
cq import-cmd --input backup.json

# 删除知识
cq delete <id> --force
```

#### MCP 工具（在 Claude Code 中）

Claude Code 可以使用以下工具：

- `search_knowledge(query, tags?, limit?)` - 搜索知识
- `add_knowledge(title, problem, solution, tags?)` - 添加知识
- `show_knowledge(id)` - 查看详情
- `list_knowledge(tags?, limit?)` - 列出知识
- `add_feedback(ku_id, helpful, comment?)` - 添加反馈

### 🏗️ 架构

```
cq/
├── cli.py              # CLI 入口
├── core/
│   ├── models.py       # 数据模型
│   └── storage.py      # SQLite 存储
├── mcp/
│   └── server.py       # MCP 服务端
└── repositories/
    ├── knowledge.py    # 知识仓储
    └── feedback.py     # 反馈仓储
```

### 🛠️ 开发

```bash
# 克隆仓库
git clone https://github.com/yourusername/cq.git
cd cq

# 安装开发依赖
pip install -e ".[dev]"

# 运行测试
pytest

# 代码检查
ruff check cq/
mypy cq/
```

### 📊 测试覆盖

- ✅ 30/30 测试通过
- ✅ CLI 工具测试
- ✅ 数据库操作测试
- ✅ MCP 插件测试

### 🤝 贡献

欢迎贡献！请查看 [CONTRIBUTING.md](CONTRIBUTING.md)

### 📄 许可证

Apache 2.0 - 详见 [LICENSE](LICENSE)

---

## English

### 🎯 What is Cq?

Cq is a shared knowledge platform designed for AI coding agents (like Claude Code, OpenCode, Cursor, etc.).

**Like Stack Overflow, but for AI Agents.**

### 💡 Problems Solved

- **Repeated Mistakes**: Each AI agent encounters the same issues independently, wasting tokens and compute
- **Hard to Maintain Knowledge**: Rule docs in `.claude/` or projects are static and hard to update/share
- **No Cross-Agent Sharing**: Knowledge learned by Claude Code can't be transferred to Cursor

### ✨ Core Features

| Feature | Description |
|---------|-------------|
| 🔍 **Knowledge Retrieval** | FTS5 full-text search for quick solution finding |
| 📝 **Knowledge Management** | CLI tools and MCP plugin for easy management |
| 🎯 **Confidence Scoring** | Auto-adjust reliability based on user feedback |
| 🔄 **Feedback System** | Mark knowledge as helpful/unhelpful for continuous improvement |
| 🔌 **Claude Code Integration** | Seamless integration via MCP plugin |
| 💾 **Local Storage** | SQLite local database, full data control |

### 🚀 Quick Start

#### Install

```bash
pip install cq-knowledge
```

#### Initialize Knowledge Base

```bash
# Initialize
cq-knowledge init

# Add knowledge unit
cq-knowledge add --title "React useEffect infinite loop" \
       --problem "useEffect dependency array causes infinite loop" \
       --solution "Ensure dependency array includes all external variables, or use useCallback" \
       --tags "react,hooks,useEffect"

# Search knowledge
cq-knowledge search "useEffect loop"

# List all knowledge
cq-knowledge list

# Show details
cq-knowledge show <knowledge-id>

# Add feedback
cq-knowledge feedback <knowledge-id> --rating 5 --comment "Solved my problem!"
```

#### Claude Code Integration

Add to Claude Code config `~/.claude/config.json`:

```json
{
  "mcpServers": {
    "cq": {
      "command": "cq-mcp"
    }
  }
}
```

Restart Claude Code, then use in conversations:

```
Please search for knowledge about React hooks
```

### 📖 Usage Examples

#### CLI Tool

```bash
# Add knowledge
cq-knowledge add --title "Python async best practices" \
       --problem "How to avoid asyncio common pitfalls" \
       --solution "Use asyncio.run() instead of manual loop creation, avoid blocking operations" \
       --tags "python,asyncio" \
       --confidence 0.9

# Search
cq-knowledge search "asyncio" --tag python

# Export knowledge base
cq-knowledge export --output backup.json

# Import knowledge base
cq-knowledge import-cmd --input backup.json

# Delete knowledge
cq-knowledge delete <id> --force
```

#### MCP Tools (in Claude Code)

Claude Code can use these tools:

- `search_knowledge(query, tags?, limit?)` - Search knowledge
- `add_knowledge(title, problem, solution, tags?)` - Add knowledge
- `show_knowledge(id)` - Show details
- `list_knowledge(tags?, limit?)` - List knowledge
- `add_feedback(ku_id, helpful, comment?)` - Add feedback

### 🏗️ Architecture

```
cq/
├── cli.py              # CLI entry
├── core/
│   ├── models.py       # Data models
│   └── storage.py      # SQLite storage
├── mcp/
│   └── server.py       # MCP server
└── repositories/
    ├── knowledge.py    # Knowledge repository
    └── feedback.py     # Feedback repository
```

### 🛠️ Development

```bash
# Clone repository
git clone https://github.com/yourusername/cq.git
cd cq

# Install dev dependencies
pip install -e ".[dev]"

# Run tests
pytest

# Linting
ruff check cq/
mypy cq/
```

### 📊 Test Coverage

- ✅ 30/30 tests passed
- ✅ CLI tool tests
- ✅ Database operation tests
- ✅ MCP plugin tests

### 🤝 Contributing

Contributions welcome! See [CONTRIBUTING.md](CONTRIBUTING.md)

### 📄 License

Apache 2.0 - See [LICENSE](LICENSE)

---

<div align="center">

**Made with ❤️ by the Cq Team**

</div>
