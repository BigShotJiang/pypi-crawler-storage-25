"""
Local link audit — scan HTML files for broken local links.
Exit codes:
  0 = PASS (no broken links)
  2 = FAIL (broken links found)
  3 = config/access error
"""

from pathlib import Path
import re
import sys


def audit_local_links(month: str, channels: list, local_root: str = "test_dir") -> tuple[int, list]:
    """
    Audit local links in HTML files.
    Returns: (exit_code, missing_links_list)
    """
    local_root = Path(local_root).expanduser().resolve()
    roots = [local_root / ch / month for ch in channels]

    href_re = re.compile(r'href=["\']([^"\']+)["\']', re.I)
    missing = []
    scanned = 0
    links = 0

    for r in roots:
        if not r.exists():
            print(f"ERROR: missing local dir: {r}")
            return 3, []

        for f in r.rglob("*.html"):
            scanned += 1
            txt = f.read_text(errors="ignore")
            for href in href_re.findall(txt):
                links += 1
                if href.startswith(("http://", "https://", "mailto:", "#", "javascript:")):
                    continue
                target = (f.parent / href).resolve()
                target = Path(str(target).split("?", 1)[0].split("#", 1)[0])
                if not target.exists():
                    missing.append((str(f), href, str(target)))

    print(f"Scanned files: {scanned}")
    print(f"Links found: {links}")
    print(f"Missing targets: {len(missing)}")

    for src, href, resolved in missing[:80]:
        print(f"\nSRC: {src}\nHREF: {href}\nRESOLVED: {resolved}")

    return (2 if missing else 0), missing
