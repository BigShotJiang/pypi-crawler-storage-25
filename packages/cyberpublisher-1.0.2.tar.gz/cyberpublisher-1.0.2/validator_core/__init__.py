"""
Validator core — local and remote verification tools.
"""
