"""
Log receipt — append a run receipt to a log file with structured data.
"""

from datetime import datetime
from pathlib import Path


def log_receipt(
    month: str,
    channels: str,
    ship: str,
    publish: str,
    validate_local: str,
    verify_remote: str,
    result: str,
    notes: str = "",
    log_path: str = "logs/run_receipts.log",
) -> None:
    """
    Append a structured run receipt to log file.
    """
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_file = Path(log_path).expanduser()

    block = (
        "--- RUN ---\n"
        f"ts: {ts}\n"
        f"month: {month}\n"
        f"channels: {channels}\n"
        f"ship: {ship}\n"
        f"publish: {publish}\n"
        f"validate_local: {validate_local}\n"
        f"verify_remote: {verify_remote}\n"
        f"result: {result}\n"
        f"notes: {notes}\n\n"
    )

    log_file.parent.mkdir(parents=True, exist_ok=True)
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(block)

    print(f"OK: appended receipt to {log_file}")
