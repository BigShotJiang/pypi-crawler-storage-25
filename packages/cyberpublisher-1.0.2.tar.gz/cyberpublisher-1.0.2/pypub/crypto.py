#!/usr/bin/env python3
"""
========================================================
pyPub — Crypto (pypub)
========================================================
Purpose:
--------
Fernet encryption for pyPub's own data-at-rest.

Key location (staged migration):
---------------------------------
  Legacy / transition:  ~/.pypub/crypto.key
    Used when this path already exists. Preserves decryption
    continuity for existing encrypted passwords in
    destinations.json. Key must NOT move until an explicit
    migration tool re-encrypts all stored credentials.

  New install:          ~/.pypub/instances/<id>/crypto.key
    Used only when no legacy key exists. New installs get
    an instance-scoped key from the start.

Design mirrors suite_core/crypto_utils.py intentionally —
same pattern, different key location, full autonomy.
========================================================
"""

from cryptography.fernet import Fernet
from pathlib import Path


# --------------------------------------------------------
# Key management
# --------------------------------------------------------

_LEGACY_KEY_PATH = Path.home() / ".pypub" / "crypto.key"


def _key_path() -> Path:
    """
    Resolve the encryption key path.

    Priority:
      1. Legacy key at ~/.pypub/crypto.key — if it exists, use it.
         Encrypted passwords in destinations.json were encoded with
         this key. Moving it without migration = unreadable credentials.
      2. Instance-scoped key at ~/.pypub/instances/<id>/crypto.key —
         for new installs only (no legacy key present).
    """
    if _LEGACY_KEY_PATH.exists():
        return _LEGACY_KEY_PATH

    from pypub.instance_manager import get_active_instance_root
    return get_active_instance_root() / "crypto.key"


def get_or_create_key() -> bytes:
    """Load existing pypub encryption key or create one if missing."""
    key_file = _key_path()

    if not key_file.exists():
        key_file.parent.mkdir(parents=True, exist_ok=True)
        key = Fernet.generate_key()
        key_file.write_bytes(key)
        key_file.chmod(0o600)
        return key

    return key_file.read_bytes()


def _fernet() -> Fernet:
    return Fernet(get_or_create_key())


def encrypt_bytes(data: bytes) -> bytes:
    return _fernet().encrypt(data)


def decrypt_bytes(data: bytes) -> bytes:
    return _fernet().decrypt(data)
