#!/usr/bin/env python3
"""
========================================================
pypub — Instance Manager (pypub)
========================================================
Handles install-location detection, slug derivation,
instance ID generation, manifest read/write, legacy
detection, and instance safehouse path provision.

Design constraints:
  • Zero imports from pypub_utils, publisher_core, or other
    internal modules — stdlib only
  • Safe to import early in startup sequence
  • Must be called before any destination or crypto access

Safehouse state (pypub-specific):
  ~/.pypub/crypto.key   — active, must not be moved yet
  ~/.pypub/instances/<id>/common_policy/destinations.json
                        — seeded with generic placeholder on first bootstrap

Startup call:
    from pypub.instance_manager import bootstrap_instance
    instance_id = bootstrap_instance()
========================================================
"""

import sys
import re
import json
import secrets
import datetime
from pathlib import Path
from typing import Optional


# --------------------------------------------------------
# Constants
# --------------------------------------------------------

# Folders that identify tool infrastructure — not domain context.
# Walk-up slug derivation skips these.
# NOTE: Versioned wrappers (cyberSuite1.01, prnt_shop_env1.01) are
# intentionally NOT in this list — they carry meaningful identity.
TOOL_NAMES = {
    "proj_root",
    "prnt_shop",
    "cyberSuite",
    "prnt_shop_env",
    "pypub",
    "cyberSuite.app",
}

_SYSTEM_PATH_PREFIXES = (
    "/usr/",
    "/opt/",
    "/bin/",
    "/sbin/",
    "/lib/",
    "/etc/",
    "/snap/",
)

_TOOL_NAME = "pypub"
_SAFEHOUSE_ROOT = Path.home() / ".pypub"
_INSTANCES_ROOT = _SAFEHOUSE_ROOT / "instances"
_INSTALL_BINDINGS_PATH = _SAFEHOUSE_ROOT / "install_bindings.json"
_INSTANCE_SUBDIRS = ("creds", "prefs", "mapper", "logs", "tmp", "common_policy", "common_policy/tracking")
_MANIFEST_FILENAME = "instance.json"
_SCHEMA_VERSION = 1

_SUFFIX_CHARS = "abcdefghijklmnopqrstuvwxyz0123456789"


# --------------------------------------------------------
# Logging
# --------------------------------------------------------

def _log(msg: str) -> None:
    """Centralised bootstrap output. Swap body to use logging if needed."""
    print(f"[instance_manager] {msg}")


# --------------------------------------------------------
# Module state — set by bootstrap_instance()
# --------------------------------------------------------
_active_instance_id: Optional[str] = None


# --------------------------------------------------------
# Policy file templates (embedded — no external files needed)
# --------------------------------------------------------

# Tracking snippet templates — seeded into instance/tracking/ on first launch.
# Replace placeholder comments with real analytics or tag manager code.
_TRACKING_TEMPLATES = {
    "prod_head.html": (
        "<!-- pypub prod tracking — head snippet -->\n"
        "<!-- Replace this placeholder with your production analytics or tag manager snippet -->\n"
    ),
    "prod_footer.html": (
        "<!-- pypub prod tracking — footer snippet -->\n"
        "<!-- Replace this placeholder with your production analytics footer snippet -->\n"
    ),
    "stage_head.html": (
        "<!-- pypub stage tracking — head snippet -->\n"
        "<!-- Replace this placeholder with your staging analytics or tag manager snippet -->\n"
    ),
    "stage_footer.html": (
        "<!-- pypub stage tracking — footer snippet -->\n"
        "<!-- Replace this placeholder with your staging analytics footer snippet -->\n"
    ),
}

_TEMPLATE_INCLUSION_FILTER = """\
{
  "include_exts": [".html", ".htm", ".php"],
  "exclude_dirs": [],
  "exclude_exts": []
}
"""

_TEMPLATE_ROBOTS_DISALLOW = """\
# pypub robots_disallow.txt
# One path per line — these are injected as Disallow: rules in robots.txt output.
# Example:
# /admin/
# /private/
"""

_TEMPLATE_SITEMAP_FILTERS = """\
{
  "exclude_paths": [],
  "exclude_extensions": [],
  "notes": "Paths and extensions to omit from sitemap output."
}
"""

_TEMPLATE_SITE_CHART_FILTERS = """\
{
  "exclude_paths": [],
  "notes": "Paths to omit from site chart output."
}
"""

_TEMPLATE_DESTINATIONS = """\
{
  "dev": {
    "host": "your-server.example.com",
    "user": "your-ssh-user",
    "path": "/var/www/html/yoursite/dev/",
    "key_filename": "~/.ssh/id_rsa",
    "publish_target": "dev",
    "_note": "Replace host, user, path, key_filename with your server details."
  },
  "stage": {
    "host": "your-server.example.com",
    "user": "your-ssh-user",
    "path": "/var/www/html/yoursite/stage/",
    "key_filename": "~/.ssh/id_rsa",
    "publish_target": "stage",
    "_note": "Replace with your staging server details."
  },
  "prod": {
    "host": "your-server.example.com",
    "user": "your-ssh-user",
    "path": "/var/www/html/yoursite/",
    "key_filename": "~/.ssh/id_rsa",
    "publish_target": "prod",
    "_note": "Replace with your production server details."
  }
}
"""

_COMMON_POLICY_SEEDS = {
    "inclusion_filter.json": _TEMPLATE_INCLUSION_FILTER,
    "robots_disallow.txt": _TEMPLATE_ROBOTS_DISALLOW,
    "sitemap_filters.json": _TEMPLATE_SITEMAP_FILTERS,
    "site_chart_filters.json": _TEMPLATE_SITE_CHART_FILTERS,
    "destinations.json": _TEMPLATE_DESTINATIONS,
}


# --------------------------------------------------------
# Install location resolution (Appendix A)
# --------------------------------------------------------

def get_install_location() -> Path:
    """
    Determine install location for policy file discovery.

    Handles four launch scenarios:
      1. Bundled binary (PyInstaller/Nuitka) — sys.executable
      2. macOS .app bundle — policy lives beside the .app, not inside it
      3. Python script — sys.argv[0]
      4. REPL / no argv — falls back to cwd with warning

    Returns:
        Absolute, symlink-resolved path to the directory
        containing the running application.
    """
    # Case 1 & 2: bundled binary
    if getattr(sys, "frozen", False):
        binary = Path(sys.executable).resolve()

        # Case 2: macOS .app bundle
        if sys.platform == "darwin" and ".app/" in str(binary):
            app_bundle = binary
            while app_bundle.suffix != ".app" and app_bundle.parent != app_bundle:
                app_bundle = app_bundle.parent
            return app_bundle.parent

        # Case 1: standard bundled binary
        return binary.parent

    # Case 3: Python script
    argv0 = sys.argv[0] if sys.argv and sys.argv[0] not in ("", "-") else None
    if argv0 is None:
        import warnings
        warnings.warn(
            "instance_manager: cannot determine install location "
            "(REPL or no argv). Falling back to cwd.",
            RuntimeWarning,
            stacklevel=2,
        )
        return Path.cwd()

    return Path(argv0).resolve().parent


# --------------------------------------------------------
# Slug derivation
# --------------------------------------------------------

def _is_system_path(path: Path) -> bool:
    s = str(path)
    return any(s.startswith(pfx) for pfx in _SYSTEM_PATH_PREFIXES)


def _sanitize_slug(name: str) -> str:
    """
    Sanitize a folder name into a clean, URL-safe slug.

    Rules:
      - Strip .app suffix
      - Lowercase
      - Replace non-alphanumeric runs with a single dash
      - Strip leading/trailing dashes
    """
    if name.endswith(".app"):
        name = name[:-4]
    name = name.lower()
    name = re.sub(r"[^a-z0-9]+", "-", name)
    name = name.strip("-")
    return name or "unknown"


def derive_slug(install_location: Path) -> str:
    """
    Derive a human-readable slug from the install location.

    Walk-up logic:
      1. Start at install_location
      2. Walk up directory tree
      3. Skip folders whose name is in TOOL_NAMES
      4. First non-tool folder = slug source
      5. If system path is reached → "global-default"

    Examples:
      ~/my-dinner/prnt_shop_env/prnt_shop/ → "my-dinner"
      ~/cyber_parity/prnt_shop_env1.01/prnt_shop/ → "prnt-shop-env1-01"
      /usr/local/bin/pypub/ → "global-default"
    """
    if _is_system_path(install_location):
        return "global-default"

    current = install_location
    while True:
        if current.name not in TOOL_NAMES:
            slug_source = current.name
            return _sanitize_slug(slug_source) if slug_source else "global-default"

        parent = current.parent
        if parent == current:
            return "global-default"
        if _is_system_path(parent):
            return "global-default"

        current = parent


# --------------------------------------------------------
# Instance ID generation
# --------------------------------------------------------

def _generate_suffix() -> str:
    """Generate a 6-character random lowercase alphanumeric suffix."""
    return "".join(secrets.choice(_SUFFIX_CHARS) for _ in range(6))


def generate_instance_id(slug: str) -> str:
    """
    Mint a new instance ID.

    Format: <slug>__<6-char-suffix>
    Example: my-dinner__q41mzc
    """
    return f"{slug}__{_generate_suffix()}"


# --------------------------------------------------------
# Manifest read / write
# --------------------------------------------------------

def _read_install_bindings() -> dict:
    """
    Read ~/.pypub/install_bindings.json (maps install location → instance_id).
    Returns empty dict if missing or corrupt.
    """
    if not _INSTALL_BINDINGS_PATH.exists():
        return {}
    try:
        with _INSTALL_BINDINGS_PATH.open("r", encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _write_install_bindings(bindings: dict) -> None:
    """Write ~/.pypub/install_bindings.json. Creates parent dirs if needed."""
    _SAFEHOUSE_ROOT.mkdir(parents=True, exist_ok=True)
    with _INSTALL_BINDINGS_PATH.open("w", encoding="utf-8") as fh:
        json.dump(bindings, fh, indent=2)


def _get_binding_key(install_location: Path) -> str:
    """Return normalized install location string for bindings dict."""
    return str(install_location.resolve())


# --------------------------------------------------------
# Instance safehouse
# --------------------------------------------------------

def get_instance_root(instance_id: str) -> Path:
    """Return ~/.pypub/instances/<instance_id>/"""
    return _INSTANCES_ROOT / instance_id


def _seed_common_policy_files(instance_root: Path) -> None:
    """
    Write policy placeholders into instance/common_policy/ on first creation.
    Never overwrites existing files — user edits are preserved.

    Seeded files:
      common_policy/inclusion_filter.json
      common_policy/robots_disallow.txt
      common_policy/sitemap_filters.json
      common_policy/site_chart_filters.json
      common_policy/tracking/prod_head.html
      common_policy/tracking/prod_footer.html
      common_policy/tracking/stage_head.html
      common_policy/tracking/stage_footer.html
    """
    policy_dir = instance_root / "common_policy"
    for filename, content in _COMMON_POLICY_SEEDS.items():
        dest = policy_dir / filename
        if not dest.exists():
            dest.write_text(content, encoding="utf-8")

    tracking_dir = policy_dir / "tracking"
    for filename, content in _TRACKING_TEMPLATES.items():
        dest = tracking_dir / filename
        if not dest.exists():
            dest.write_text(content, encoding="utf-8")


def ensure_instance_safehouse(instance_id: str) -> None:
    """
    Create the full instance safehouse directory tree if it does not exist.

    Tree:
      ~/.pypub/instances/<id>/
        ├── creds/
        ├── prefs/
        ├── mapper/
        ├── logs/
        ├── tmp/
        └── tracking/
    """
    instance_root = get_instance_root(instance_id)
    for subdir in _INSTANCE_SUBDIRS:
        (instance_root / subdir).mkdir(parents=True, exist_ok=True)
    _seed_common_policy_files(instance_root)


# --------------------------------------------------------
# Bootstrap — main startup sequence
# --------------------------------------------------------

def bootstrap_instance() -> str:
    """
    Full startup sequence. Must be called before any destination or crypto access.

    Decision logic:
      1. Check ~/.pypub/install_bindings.json for this install location
      2. If found, use that instance_id
      3. If not found, generate new instance_id and record in bindings

    All mutable state lives in ~/.pypub/instances/<id>/, never in proj_root/.

    Returns:
        Active instance_id string.
    """
    global _active_instance_id

    if _active_instance_id is not None:
        return _active_instance_id

    install_location = get_install_location()
    binding_key = _get_binding_key(install_location)

    # Read existing bindings
    bindings = _read_install_bindings()

    # Check if we have a binding for this install location
    if binding_key in bindings:
        instance_id = bindings[binding_key]
        if instance_id and "__" in instance_id:
            _log(f"Bound to existing instance: {instance_id}")
            ensure_instance_safehouse(instance_id)
            _active_instance_id = instance_id
            return instance_id

    # No valid binding — create new instance and record it
    slug = derive_slug(install_location)
    instance_id = generate_instance_id(slug)
    bindings[binding_key] = instance_id
    _write_install_bindings(bindings)

    ensure_instance_safehouse(instance_id)
    _active_instance_id = instance_id
    _log(f"New instance: {instance_id}")
    return instance_id


# --------------------------------------------------------
# Active instance root (post-bootstrap)
# --------------------------------------------------------

def get_active_instance_root() -> Path:
    """
    Return the active instance root: ~/.pypub/instances/<id>/
    Must be called after bootstrap_instance().
    """
    return get_instance_root(_active_instance_id)
