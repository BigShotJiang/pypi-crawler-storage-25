#!/usr/bin/env python3
"""
pypub_utils — Logging

Persistent run log for pypub. Mirrors cyberSuite logging behavior.

File:
  ~/.pypub/instances/<instance>/logs/runlog.jsonl

Policy:
- Always write job_start + job_end to runlog.jsonl on each publish run.
- Trim: after each job_end, keep last 5 completed jobs.
- scope = output channel scope (local|remote)

Shim API (log_cli, get_logger) is preserved — used by input_matrix.py.
"""

from __future__ import annotations

import json
import logging as _logging
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional


# ---------------------------------------------------------
# Shim API — preserved (used by input_matrix.py)
# ---------------------------------------------------------

def log_cli(msg: str):
    print(msg)


def get_logger(name: str):
    return _logging.getLogger(name)


# ---------------------------------------------------------
# Path normalization (home paths → ~)
# ---------------------------------------------------------

_HOME = os.path.expanduser("~")


def _norm_path(p: str) -> str:
    if not p or not isinstance(p, str):
        return p
    return "~" + p[len(_HOME):] if p.startswith(_HOME) else p


def _normalize_snapshot(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {k: _normalize_snapshot(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_normalize_snapshot(v) for v in obj]
    if isinstance(obj, str):
        return _norm_path(obj)
    return obj


# ---------------------------------------------------------
# Path resolution
# ---------------------------------------------------------

TRIM_KEEP = 5  # keep last N completed jobs in runlog


def _log_dir() -> Path:
    """Resolve per-instance log directory. Safe after bootstrap_instance()."""
    from pypub import instance_manager
    return instance_manager.get_active_instance_root() / "logs"


def _runlog_path() -> Path:
    return _log_dir() / "runlog.jsonl"


# ---------------------------------------------------------
# Low-level I/O
# ---------------------------------------------------------

def _ensure_dirs() -> None:
    _log_dir().mkdir(parents=True, exist_ok=True)


def _jsonl_append(path: Path, obj: Dict[str, Any]) -> None:
    _ensure_dirs()
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":")))
        f.write("\n")


def _read_jsonl(path: Path) -> List[Dict[str, Any]]:
    if not path.exists():
        return []
    out = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except Exception:
                continue  # skip corrupt lines, don't brick logging
    return out


# ---------------------------------------------------------
# Event schema (mirrors cyberSuite RunlogEvent shape)
# ---------------------------------------------------------

@dataclass(frozen=True)
class RunlogEvent:
    ts: str
    run_id: str
    job_id: str
    tool: str           # "pypub"
    event: str          # "job_start" | "job_end"
    status: str         # "ok" | "fail"
    scope: str          # "local" | "remote"
    timing_ms: Optional[int] = None
    snapshot: Optional[Dict[str, Any]] = None
    counts: Optional[Dict[str, Any]] = None
    errors: Optional[List[str]] = None


def emit_run_event(e: RunlogEvent) -> None:
    payload: Dict[str, Any] = {
        "ts": e.ts,
        "run_id": e.run_id,
        "job_id": e.job_id,
        "tool": e.tool,
        "event": e.event,
        "status": e.status,
        "scope": e.scope,
    }
    if e.timing_ms is not None:
        payload["timing_ms"] = e.timing_ms
    if e.snapshot is not None:
        payload["snapshot"] = _normalize_snapshot(e.snapshot)
    if e.counts is not None:
        payload["counts"] = e.counts
    if e.errors:
        payload["errors"] = e.errors

    _jsonl_append(_runlog_path(), payload)

    if e.event == "job_end":
        _trim_runlog(TRIM_KEEP)


# ---------------------------------------------------------
# Trim — keep last N completed jobs
# ---------------------------------------------------------

def _trim_runlog(keep: int) -> None:
    runlog = _runlog_path()
    events = _read_jsonl(runlog)
    if not events:
        return

    # Collect job_ids that have a job_end, in order
    completed: list[str] = []
    for ev in events:
        if ev.get("event") == "job_end":
            jid = str(ev.get("job_id", ""))
            if jid and jid not in completed:
                completed.append(jid)

    keep_ids = set(completed[-keep:] if keep > 0 else [])
    if not keep_ids:
        return

    kept = [ev for ev in events if ev.get("job_id") in keep_ids]

    _ensure_dirs()
    tmp = runlog.with_suffix(".jsonl.tmp")
    with tmp.open("w", encoding="utf-8") as f:
        for ev in kept:
            f.write(json.dumps(ev, ensure_ascii=False, separators=(",", ":")))
            f.write("\n")
    tmp.replace(runlog)


# ---------------------------------------------------------
# ID / timestamp helpers
# ---------------------------------------------------------

def new_run_id() -> str:
    return f"run_{int(time.time() * 1000)}"


def new_job_id() -> str:
    return f"job_{int(time.time() * 1000)}"


def now_ts() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
