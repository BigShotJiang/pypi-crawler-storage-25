use hnsw_rs::prelude::*;
use pyo3::prelude::*;
use rayon::prelude::*;
use std::cmp::Ordering;
use std::collections::BinaryHeap;

/// Maximum vectors per shard. Shards use sequential insert to guarantee
/// fully connected HNSW graphs. 2500 sits in the sweet spot between
/// 1K (99% recall) and 5K (98% recall), yielding ~98.5-99% per shard.
const SHARD_SIZE: usize = 2500;

/// Internal storage: single graph for small datasets, sharded for large.
enum IndexInner {
    Single {
        hnsw: Hnsw<'static, f32, DistCosine>,
    },
    Sharded {
        shards: Vec<Hnsw<'static, f32, DistCosine>>,
        shard_offsets: Vec<usize>,
        shard_sizes: Vec<usize>,
    },
}

// SAFETY: Hnsw from hnsw_rs is Sync+Send. IndexInner only holds Vec<Hnsw>
// and primitive fields, so it is also Send.
unsafe impl Send for IndexInner {}

/// HNSW approximate nearest neighbor index.
///
/// Build once from a collection of embedding vectors, then search many times.
/// The index lives in Rust memory — Python holds a reference.
///
/// For datasets larger than 2500 vectors, the index is automatically sharded
/// into smaller HNSW graphs that are built and searched in parallel. This
/// maintains 98%+ recall at any scale.
///
/// Args:
///     vectors: List of embedding vectors (each a list of f32).
///     ef_construction: Build-time search effort. Default 100 gives 98%+ recall on
///         real-world embeddings. Increase to 200+ for higher recall on very large
///         datasets (1M+ vectors).
///
/// Example:
///     idx = VectorIndex(vectors)                       # 98%+ recall (default)
///     idx = VectorIndex(vectors, ef_construction=200)  # higher recall at 1M+ vectors
///     results = idx.search(query_vector, top_k=10)
#[pyclass]
pub struct VectorIndex {
    inner: IndexInner,
    count: usize,
}

/// Compute ef_search for a given top_k and index size.
fn compute_ef_search(top_k: usize, count: usize) -> usize {
    if top_k >= count {
        count * 2
    } else if top_k >= count / 2 {
        count
    } else {
        top_k.max(100)
    }
}

/// A scored result for min-heap merging.
struct ScoredId {
    id: usize,
    score: f32,
}

impl PartialEq for ScoredId {
    fn eq(&self, other: &Self) -> bool {
        self.score == other.score && self.id == other.id
    }
}

impl Eq for ScoredId {}

impl PartialOrd for ScoredId {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

impl Ord for ScoredId {
    fn cmp(&self, other: &Self) -> Ordering {
        // Reverse: smallest score is "greatest" so it gets popped first from the min-heap
        other
            .score
            .partial_cmp(&self.score)
            .unwrap_or(Ordering::Equal)
    }
}

/// Merge top-k results from multiple shards using a bounded min-heap.
fn merge_top_k(shard_results: Vec<Vec<(usize, f32)>>, top_k: usize) -> Vec<(usize, f32)> {
    let mut heap: BinaryHeap<ScoredId> = BinaryHeap::with_capacity(top_k + 1);

    for results in shard_results {
        for (id, score) in results {
            if heap.len() < top_k {
                heap.push(ScoredId { id, score });
            } else if let Some(min) = heap.peek() {
                if score > min.score {
                    heap.pop();
                    heap.push(ScoredId { id, score });
                }
            }
        }
    }

    let mut result: Vec<(usize, f32)> = heap.into_iter().map(|s| (s.id, s.score)).collect();
    result.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(Ordering::Equal));
    result
}

impl VectorIndex {
    /// Build index without requiring Python token (used internally by pipeline)
    pub fn build(vectors: Vec<Vec<f32>>, ef_construction: usize) -> Self {
        let n = vectors.len();
        let max_nb_connection = 16;
        let max_layer = 16;

        if n <= SHARD_SIZE {
            // Small dataset: single index, sequential insert
            let hnsw = Hnsw::new(max_nb_connection, n, max_layer, ef_construction, DistCosine);
            for (i, v) in vectors.iter().enumerate() {
                hnsw.insert((v.as_slice(), i));
            }
            VectorIndex {
                inner: IndexInner::Single { hnsw },
                count: n,
            }
        } else {
            // Large dataset: shard and build each in parallel with sequential insert
            let chunks: Vec<&[Vec<f32>]> = vectors.chunks(SHARD_SIZE).collect();
            let shard_sizes: Vec<usize> = chunks.iter().map(|c| c.len()).collect();
            let shard_offsets: Vec<usize> = shard_sizes
                .iter()
                .scan(0usize, |acc, &size| {
                    let offset = *acc;
                    *acc += size;
                    Some(offset)
                })
                .collect();

            let shards: Vec<Hnsw<'static, f32, DistCosine>> = chunks
                .par_iter()
                .map(|chunk| {
                    let shard_n = chunk.len();
                    let hnsw = Hnsw::new(
                        max_nb_connection,
                        shard_n,
                        max_layer,
                        ef_construction,
                        DistCosine,
                    );
                    for (local_id, v) in chunk.iter().enumerate() {
                        hnsw.insert((v.as_slice(), local_id));
                    }
                    hnsw
                })
                .collect();

            VectorIndex {
                inner: IndexInner::Sharded {
                    shards,
                    shard_offsets,
                    shard_sizes,
                },
                count: n,
            }
        }
    }

    /// Search without requiring Python token (used internally by pipeline)
    pub fn query(&self, query: &[f32], top_k: usize) -> Vec<(usize, f32)> {
        if self.count == 0 {
            return vec![];
        }

        match &self.inner {
            IndexInner::Single { hnsw } => {
                let ef_search = compute_ef_search(top_k, self.count);
                let neighbours = hnsw.search(query, top_k, ef_search);
                neighbours
                    .iter()
                    .map(|n| {
                        let similarity = 1.0 - n.distance;
                        (n.d_id, similarity)
                    })
                    .collect()
            }
            IndexInner::Sharded {
                shards,
                shard_offsets,
                shard_sizes,
            } => {
                let per_shard_results: Vec<Vec<(usize, f32)>> = shards
                    .par_iter()
                    .enumerate()
                    .map(|(s, hnsw)| {
                        let ef_search = compute_ef_search(top_k, shard_sizes[s]);
                        let neighbours = hnsw.search(query, top_k, ef_search);
                        neighbours
                            .iter()
                            .map(|n| {
                                let global_id = shard_offsets[s] + n.d_id;
                                let similarity = 1.0 - n.distance;
                                (global_id, similarity)
                            })
                            .collect()
                    })
                    .collect();

                merge_top_k(per_shard_results, top_k)
            }
        }
    }
}

#[pymethods]
impl VectorIndex {
    /// Build a new HNSW index from a list of embedding vectors.
    #[new]
    #[pyo3(signature = (vectors, ef_construction=100))]
    pub fn new(py: Python<'_>, vectors: Vec<Vec<f32>>, ef_construction: usize) -> Self {
        // Release the GIL during index construction — this is pure Rust compute
        py.allow_threads(|| Self::build(vectors, ef_construction))
    }

    /// Search for the top_k nearest neighbors to the query vector.
    ///
    /// Returns a list of (original_index, similarity_score) tuples,
    /// sorted by similarity (highest first).
    #[pyo3(signature = (query, top_k=10))]
    pub fn search(&self, py: Python<'_>, query: Vec<f32>, top_k: usize) -> Vec<(usize, f32)> {
        // Release the GIL during search — this is pure Rust compute
        py.allow_threads(|| self.query(&query, top_k))
    }

    /// Returns the number of vectors in the index.
    fn len(&self) -> usize {
        self.count
    }

    /// Returns True if the index contains no vectors.
    fn is_empty(&self) -> bool {
        self.count == 0
    }
}
