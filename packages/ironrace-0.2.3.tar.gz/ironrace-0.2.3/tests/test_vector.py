"""Tests for ironrace._core.VectorIndex (HNSW approximate nearest neighbor)."""

import math
import random

import pytest
from ironrace._core import VectorIndex


def _unit_vector(dim=768, seed=None):
    """Generate a random unit vector."""
    if seed is not None:
        random.seed(seed)
    v = [random.gauss(0, 1) for _ in range(dim)]
    norm = math.sqrt(sum(x * x for x in v))
    return [x / norm for x in v]


def _known_vectors():
    """Generate a small set of known vectors for deterministic tests."""
    return [
        [1.0, 0.0, 0.0],
        [0.0, 1.0, 0.0],
        [0.0, 0.0, 1.0],
        [0.707, 0.707, 0.0],  # ~45 degrees between x and y
        [0.577, 0.577, 0.577],  # ~equidistant from all axes
    ]


class TestVectorIndexBuild:
    def test_build_basic(self):
        vecs = [_unit_vector(dim=64, seed=i) for i in range(100)]
        idx = VectorIndex(vecs)
        assert idx.len() == 100

    def test_build_single_vector(self):
        idx = VectorIndex([[1.0, 0.0, 0.0]])
        assert idx.len() == 1

    def test_build_large(self):
        vecs = [_unit_vector(dim=768, seed=i) for i in range(1000)]
        idx = VectorIndex(vecs)
        assert idx.len() == 1000

    def test_build_custom_ef(self):
        vecs = [_unit_vector(dim=64, seed=i) for i in range(50)]
        idx = VectorIndex(vecs, ef_construction=50)
        assert idx.len() == 50

    def test_is_empty(self):
        vecs = [_unit_vector(dim=64, seed=0)]
        idx = VectorIndex(vecs)
        assert not idx.is_empty()


class TestVectorIndexSearch:
    def test_self_search(self):
        """Searching for a vector in the index should return itself as the top result."""
        vecs = [_unit_vector(dim=128, seed=i) for i in range(500)]
        idx = VectorIndex(vecs)
        results = idx.search(vecs[42], 5)
        assert results[0][0] == 42
        assert results[0][1] > 0.99  # near-perfect similarity

    def test_known_vectors(self):
        """Test with known geometric vectors."""
        vecs = _known_vectors()
        idx = VectorIndex(vecs, ef_construction=50)
        # Search for [1, 0, 0] — closest should be itself, then [0.707, 0.707, 0]
        results = idx.search([1.0, 0.0, 0.0], 3)
        assert results[0][0] == 0  # exact match
        assert results[0][1] > 0.99

    def test_top_k_count(self):
        vecs = [_unit_vector(dim=64, seed=i) for i in range(100)]
        idx = VectorIndex(vecs)
        results = idx.search(vecs[0], 10)
        assert len(results) == 10

    def test_top_k_greater_than_n(self):
        """Requesting more results than vectors should return nearly all vectors."""
        vecs = [_unit_vector(dim=64, seed=i) for i in range(50)]
        idx = VectorIndex(vecs)
        results = idx.search(vecs[0], 200)
        assert len(results) >= 46  # HNSW graph isolation can miss 3-4% of vectors

    def test_results_sorted_by_similarity(self):
        vecs = [_unit_vector(dim=128, seed=i) for i in range(200)]
        idx = VectorIndex(vecs)
        results = idx.search(vecs[0], 20)
        scores = [score for _, score in results]
        assert scores == sorted(scores, reverse=True)

    def test_similarity_score_range(self):
        """Similarity scores should be in [-1, 1] for unit vectors."""
        vecs = [_unit_vector(dim=128, seed=i) for i in range(100)]
        idx = VectorIndex(vecs)
        results = idx.search(vecs[0], 10)
        for _, score in results:
            assert -1.0 <= score <= 1.001  # small epsilon for float precision

    def test_high_dimensional(self):
        """Test with 1536-dimensional vectors (OpenAI embedding size)."""
        vecs = [_unit_vector(dim=1536, seed=i) for i in range(100)]
        idx = VectorIndex(vecs)
        results = idx.search(vecs[0], 5)
        assert results[0][0] == 0
        assert len(results) == 5


try:
    import numpy as np

    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False


class TestShardedIndex:
    """Tests for sharded HNSW behavior at >2500 vectors."""

    def _generate_clustered_vectors(self, n, dim=768, n_clusters=50):
        """Generate clustered unit vectors simulating real embeddings."""

        rng = np.random.default_rng(42)
        n_per_cluster = n // n_clusters
        remainder = n - (n_per_cluster * n_clusters)

        centers = rng.standard_normal((n_clusters, dim)).astype(np.float32)
        centers /= np.linalg.norm(centers, axis=1, keepdims=True)

        chunks = []
        for i, center in enumerate(centers):
            count = n_per_cluster + (1 if i < remainder else 0)
            noise = rng.standard_normal((count, dim)).astype(np.float32) * 0.1
            chunks.append(center + noise)

        vecs = np.vstack(chunks).astype(np.float32)
        vecs /= np.linalg.norm(vecs, axis=1, keepdims=True)
        return vecs

    def _brute_force_top_k(self, query, vectors_np, top_k=10):
        """Ground truth cosine similarity search."""
        import numpy as np

        sims = vectors_np @ query
        return set(np.argsort(sims)[::-1][:top_k].tolist())

    @pytest.mark.skipif(not HAS_NUMPY, reason="numpy not installed")
    def test_recall_10k(self):
        """10K vectors should achieve 98%+ recall with sharding."""

        n = 10000
        vectors_np = self._generate_clustered_vectors(n, n_clusters=50)
        vectors = vectors_np.tolist()
        idx = VectorIndex(vectors)
        assert idx.len() == n

        n_queries = 100
        query_indices = np.linspace(0, n - 1, n_queries, dtype=int)
        total_recall = 0
        for qi in query_indices:
            q = vectors[qi]
            hnsw_ids = set(r[0] for r in idx.search(q, 10))
            gt_ids = self._brute_force_top_k(vectors_np[qi], vectors_np, 10)
            total_recall += len(hnsw_ids & gt_ids) / 10.0
        avg_recall = total_recall / n_queries

        assert avg_recall >= 0.98, f"Recall@10 at 10K: {avg_recall:.3f} (expected >= 0.98)"

    def test_global_ids_correct(self):
        """Returned IDs must be global indices, not shard-local."""
        # Build with >2500 vectors to trigger sharding
        # Use 64d vectors so self-search reliably returns the query vector
        dim = 64
        vecs = [_unit_vector(dim=dim, seed=i) for i in range(5000)]
        idx = VectorIndex(vecs)

        # Search for a vector in a later shard (index > 2500)
        target = 4500
        results = idx.search(vecs[target], 20)
        result_ids = [r[0] for r in results]
        # Target must appear in results with a global (not shard-local) ID
        assert target in result_ids, (
            f"Expected global ID {target} in results, got {result_ids}"
        )

    def test_shard_boundary_neighbor(self):
        """Nearest neighbor in a different shard should still be found."""
        dim = 64
        # Place near-duplicates at low indices in their respective shards
        # so they are well-connected (early inserts are never isolated).
        # Shard 0: indices 0-2499, shard 1: indices 2500-4999
        # We make index 100 (shard 0) ≈ index 2600 (shard 1).
        vecs = [_unit_vector(dim=dim, seed=i) for i in range(5000)]
        vecs[2600] = [x + 0.001 for x in vecs[100]]
        norm = math.sqrt(sum(x * x for x in vecs[2600]))
        vecs[2600] = [x / norm for x in vecs[2600]]

        idx = VectorIndex(vecs)
        results = idx.search(vecs[100], 20)
        result_ids = [r[0] for r in results]

        assert 100 in result_ids, "Self-match should be in results"
        assert 2600 in result_ids, "Near-duplicate across shard boundary should be found"

    def test_top_k_ordering_sharded(self):
        """Results from sharded search must be globally sorted by score."""
        vecs = [_unit_vector(dim=128, seed=i) for i in range(5000)]
        idx = VectorIndex(vecs)
        results = idx.search(vecs[0], 20)
        scores = [score for _, score in results]
        assert scores == sorted(scores, reverse=True)


class TestVectorIndexPerformance:
    def test_search_returns_quickly(self):
        """Search over 1K vectors should be fast (< 10ms)."""
        import time

        vecs = [_unit_vector(dim=256, seed=i) for i in range(1000)]
        idx = VectorIndex(vecs)
        query = _unit_vector(dim=256, seed=99999)

        start = time.perf_counter()
        for _ in range(50):
            idx.search(query, 10)
        elapsed = (time.perf_counter() - start) / 50 * 1000  # ms per search

        assert elapsed < 10, f"Search took {elapsed:.1f}ms (expected < 10ms)"
