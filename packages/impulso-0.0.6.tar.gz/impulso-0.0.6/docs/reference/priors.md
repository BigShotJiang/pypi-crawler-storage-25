# Priors

::: impulso.priors
