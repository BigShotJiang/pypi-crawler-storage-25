# VAR Specification

::: impulso.spec
