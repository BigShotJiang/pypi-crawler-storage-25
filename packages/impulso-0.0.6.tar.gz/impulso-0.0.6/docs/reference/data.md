# Data

::: impulso.data
