from setuptools import setup, find_packages

setup(
    name="lostplace", 
    version="1.0.5",
    packages=find_packages(),
    install_requires=[
        "discord.py>=2.0.0",
    ],
    author="hactoer", 
    description="Lostplace Software Store: Hepsi bir arada bot altyapısı.",
    python_requires='>=3.8',
)
