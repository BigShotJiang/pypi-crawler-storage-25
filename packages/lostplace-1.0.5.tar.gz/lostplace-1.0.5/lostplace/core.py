import discord
from discord.ext import commands
import random
import asyncio
import json
from datetime import datetime, timedelta
import os

# --- YARDIMCI: EMBED MOTORU ---
def lp_embed(bot, title, description, member=None):
    footer_text = getattr(bot, "sunucu_ismi", "Lost Place")
    embed = discord.Embed(title=title, description=description, color=0x2f3136)
    if member: embed.set_thumbnail(url=member.display_avatar.url)
    embed.set_footer(text=footer_text)
    return embed

# --- 1. GÜVENLİK ---
def guvenlik(bot, kanal_id: int):
    @bot.listen()
    async def on_member_join(member):
        kanal = bot.get_channel(kanal_id)
        if kanal: await kanal.send(embed=lp_embed(bot, "Hoş Geldin!", f"Aramıza hoş geldin {member.mention}!", member))

    @bot.listen()
    async def on_member_remove(member):
        kanal = bot.get_channel(kanal_id)
        if kanal: await kanal.send(embed=lp_embed(bot, "Görüşürüz...", f"{member.name} aramızdan ayrıldı.", member))

# --- 2. DİNAMİK OTO CEVAP (BUTON -> MODAL SİSTEMİ) ---
def oto_cevap(bot, dosya_adi="otocevaplar.json"):
    def veri_yukle():
        if not os.path.exists(dosya_adi): return {}
        with open(dosya_adi, "r", encoding="utf-8") as f: return json.load(f)
    def veri_kaydet(data):
        with open(dosya_adi, "w", encoding="utf-8") as f: json.dump(data, f, ensure_ascii=False, indent=4)

    class OtoCevapModal(discord.ui.Modal, title='Oto Cevap Ekle'):
        tetik = discord.ui.TextInput(label='Tetikleyici', placeholder='sa')
        cevap = discord.ui.TextInput(label='Botun Cevabı', style=discord.TextStyle.paragraph)
        async def on_submit(self, interaction: discord.Interaction):
            veriler = veri_yukle()
            veriler[self.tetik.value.lower()] = self.cevap.value
            veri_kaydet(veriler)
            await interaction.response.send_message(f"✅ **{self.tetik.value}** tetiği eklendi!", ephemeral=True)

    @bot.command(name="otocevap-ekle")
    @commands.has_permissions(administrator=True)
    async def oc_ekle(ctx):
        view = discord.ui.View()
        btn = discord.ui.Button(label="Formu Aç", style=discord.ButtonStyle.green)
        async def callback(inter): await inter.response.send_modal(OtoCevapModal())
        btn.callback = callback
        view.add_item(btn)
        await ctx.send("Oto cevap eklemek için butona tıkla:", view=view, delete_after=15)

    @bot.command(name="otocevap-sil")
    @commands.has_permissions(administrator=True)
    async def oc_sil(ctx, tetik: str):
        veriler = veri_yukle()
        if tetik.lower() in veriler:
            del veriler[tetik.lower()]
            veri_kaydet(veriler)
            msg = await ctx.send(f"🗑️ **{tetik}** tetiği silindi.")
            await asyncio.sleep(5)
            await msg.delete()
        else:
            await ctx.send("❌ Bulunamadı.", delete_after=5)

    @bot.listen()
    async def on_message(message):
        if message.author.bot: return
        veriler = veri_yukle()
        if message.content.lower() in veriler:
            await message.reply(veriler[message.content.lower()])

# --- 3. MODERASYON ---
def moderasyon(bot):
    @bot.command()
    @commands.has_permissions(ban_members=True)
    async def ban(ctx, member: discord.Member, *, sebep="Yok"):
        await member.ban(reason=sebep)
        await ctx.send(embed=lp_embed(bot, "Yasaklandı", f"{member.mention} yasaklandı."), delete_after=5)

    @bot.command()
    @commands.has_permissions(manage_messages=True)
    async def sil(ctx, miktar: int):
        await ctx.channel.purge(limit=miktar + 1)
        await ctx.send(f"✅ {miktar} mesaj silindi.", delete_after=5)

# --- 4. GELİŞMİŞ ÇEKİLİŞ (MODAL & AYRIL & BİTİR) ---
def cekilis(bot):
    class CekilisView(discord.ui.View):
        def __init__(self, odul, kazanan_sayisi):
            super().__init__(timeout=None)
            self.katilimcilar = []
            self.odul = odul
            self.kazanan_sayisi = kazanan_sayisi

        @discord.ui.button(label="Katıl", style=discord.ButtonStyle.green, emoji="🎉")
        async def katil(self, interaction: discord.Interaction):
            if interaction.user.id in self.katilimcilar:
                return await interaction.response.send_message("Zaten katıldın!", ephemeral=True)
            self.katilimcilar.append(interaction.user.id)
            embed = interaction.message.embeds[0]
            embed.description = f"**Ödül:** {self.odul}\n**Kazanan:** {self.kazanan_sayisi}\n**Katılımcı:** {len(self.katilimcilar)}"
            await interaction.message.edit(embed=embed)
            await interaction.response.send_message("Çekilişe katıldın!", ephemeral=True)

        @discord.ui.button(label="Ayrıl", style=discord.ButtonStyle.red)
        async def ayril(self, interaction: discord.Interaction):
            if interaction.user.id not in self.katilimcilar:
                return await interaction.response.send_message("Listede değilsin!", ephemeral=True)
            self.katilimcilar.remove(interaction.user.id)
            embed = interaction.message.embeds[0]
            embed.description = f"**Ödül:** {self.odul}\n**Kazanan:** {self.kazanan_sayisi}\n**Katılımcı:** {len(self.katilimcilar)}"
            await interaction.message.edit(embed=embed)
            await interaction.response.send_message("Ayrıldın.", ephemeral=True)

        @discord.ui.button(label="Bitir (Admin)", style=discord.ButtonStyle.gray)
        async def bitir(self, interaction: discord.Interaction):
            if not interaction.user.guild_permissions.administrator:
                return await interaction.response.send_message("Yetkin yok!", ephemeral=True)
            if not self.katilimcilar: return await interaction.response.send_message("Katılımcı yok!", ephemeral=True)
            kazananlar = random.sample(self.katilimcilar, k=min(len(self.katilimcilar), self.kazanan_sayisi))
            mentions = ", ".join([f"<@{uid}>" for uid in kazananlar])
            await interaction.channel.send(f"🎊 Tebrikler {mentions}! **{self.odul}** kazandınız!")
            await interaction.message.delete()
            self.stop()

    class CekilisModal(discord.ui.Modal, title='Çekiliş Başlat'):
        odul = discord.ui.TextInput(label='Ödül')
        sayi = discord.ui.TextInput(label='Kazanan Sayısı', default='1')
        async def on_submit(self, interaction: discord.Interaction):
            view = CekilisView(self.odul.value, int(self.sayi.value))
            await interaction.response.send_message(embed=lp_embed(bot, "🎉 Çekiliş!", f"**Ödül:** {self.odul.value}\n**Kazanan:** {self.sayi.value}\n**Katılımcı:** 0"), view=view)

    @bot.command()
    @commands.has_permissions(administrator=True)
    async def çekiliş(ctx):
        view = discord.ui.View()
        btn = discord.ui.Button(label="Çekilişi Kur", style=discord.ButtonStyle.blurple)
        async def callback(inter): await inter.response.send_modal(CekilisModal())
        btn.callback = callback
        view.add_item(btn)
        await ctx.send("Formu açmak için butona bas:", view=view, delete_after=15)

# --- 5. TICKET (KAPATMA BUTONLU) ---
def destek(bot):
    @bot.command()
    async def destekkur(ctx):
        view = discord.ui.View(timeout=None)
        btn = discord.ui.Button(label="Destek Aç", style=discord.ButtonStyle.blurple)
        async def open_callback(inter: discord.Interaction):
            ch = await inter.guild.create_text_channel(f"ticket-{inter.user.name}")
            await ch.set_permissions(inter.guild.default_role, read_messages=False)
            await ch.set_permissions(inter.user, read_messages=True, send_messages=True)
            k_view = discord.ui.View(timeout=None)
            k_btn = discord.ui.Button(label="Talebi Kapat", style=discord.ButtonStyle.red)
            async def close_callback(i): 
                await i.response.send_message("Kanal siliniyor...")
                await asyncio.sleep(2); await i.channel.delete()
            k_btn.callback = close_callback
            k_view.add_item(k_btn)
            await ch.send(f"{inter.user.mention} talebin açıldı.", view=k_view)
            await inter.response.send_message(f"Açıldı: {ch.mention}", ephemeral=True)
        btn.callback = open_callback
        view.add_item(btn)
        await ctx.send(embed=lp_embed(bot, "Destek Sistemi", "Yardım için tıkla."), view=view)

# --- 6. DOĞRULAMA ---
def dogrulama(bot, rol_id: int):
    @bot.command()
    async def dogrulamakur(ctx):
        view = discord.ui.View(timeout=None)
        btn = discord.ui.Button(label="Doğrula", style=discord.ButtonStyle.green)
        async def callback(inter):
            rol = inter.guild.get_role(rol_id)
            if rol: await inter.user.add_roles(rol)
            await inter.response.send_message("Başarılı!", ephemeral=True)
        btn.callback = callback
        view.add_item(btn)
        await ctx.send(embed=lp_embed(bot, "Doğrulama", "Kayıt için tıkla."), view=view)

class Client(commands.Bot):
    def __init__(self, token, prefix, sunucu_ismi="Lost Place"):
        self.token = token; self.sunucu_ismi = sunucu_ismi
        super().__init__(command_prefix=prefix, intents=discord.Intents.all())
    def run_bot(self): super().run(self.token)
    