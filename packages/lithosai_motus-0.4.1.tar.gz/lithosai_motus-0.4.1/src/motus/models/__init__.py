"""
Chat client abstraction layer.

Provides a unified interface for different LLM providers (OpenAI, Anthropic, Gemini, etc.)
"""

from .anthropic_client import AnthropicChatClient
from .base import (
    BaseChatClient,
    CachePolicy,
    ChatCompletion,
    ChatMessage,
    FunctionCall,
    ReasoningConfig,
    ToolCall,
    ToolDefinition,
)
from .gemini_client import GeminiChatClient
from .openai_client import OpenAIChatClient
from .openrouter_client import OpenRouterChatClient

try:
    from .volcengine_client import VolcEngineChatClient
except ImportError:
    VolcEngineChatClient = None  # type: ignore[assignment,misc]

__all__ = [
    "BaseChatClient",
    "CachePolicy",
    "ChatCompletion",
    "ReasoningConfig",
    "ChatMessage",
    "FunctionCall",
    "ToolCall",
    "ToolDefinition",
    "AnthropicChatClient",
    "GeminiChatClient",
    "OpenAIChatClient",
    "OpenRouterChatClient",
    "VolcEngineChatClient",
]
