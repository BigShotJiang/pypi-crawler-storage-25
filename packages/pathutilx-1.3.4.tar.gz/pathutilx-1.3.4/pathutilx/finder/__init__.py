import sys
from typing import cast

from .linux import linux_root
from .macos import mac_root
from .windows import (
    PathNode,
    build_path,
    listdir,
    parent_path,
    resolve_path,
    search,
    win_root,
    windows_root,
)


def platform_root() -> PathNode:
    platform = cast(str, sys.platform)
    if platform == "win32":
        return win_root()
    if platform == "darwin":
        return mac_root()
    if platform == "linux":
        return linux_root()
    raise NotImplementedError(f"Unsupported platform: {platform}")


__all__ = [
    "PathNode",
    "build_path",
    "platform_root",
    "win_root",
    "linux_root",
    "mac_root",
    "windows_root",
    "listdir",
    "search",
    "resolve_path",
    "parent_path",
]
