from __future__ import annotations

import fnmatch
import os
from pathlib import Path
from typing import Iterable


PathLike = str | os.PathLike[str]


def _as_path(value: PathLike | "PathNode") -> Path:
    if isinstance(value, PathNode):
        return value.path
    return Path(value)


def _normalize_part(part: PathLike | "PathNode") -> Path:
    raw = os.fspath(_as_path(part))
    expanded = os.path.expandvars(os.path.expanduser(raw))
    return Path(expanded)


def build_path(
    *parts: PathLike | "PathNode",
    base: PathLike | "PathNode" | None = None,
) -> Path:
    if base is None and not parts:
        raise ValueError("build_path requires at least one path part or a base path")

    path = _normalize_part(base) if base is not None else _normalize_part(parts[0])
    remaining_parts: Iterable[PathLike | PathNode] = parts if base is not None else parts[1:]

    for part in remaining_parts:
        path = path / _normalize_part(part)

    return path


def resolve_path(value: PathLike | "PathNode") -> Path:
    """Resolve a path-like value to an absolute path."""
    return _normalize_part(value).resolve()


def parent_path(value: PathLike | "PathNode") -> Path:
    """Return the parent directory of a path-like value."""
    return _normalize_part(value).parent


def listdir(
    *parts: PathLike | "PathNode",
    base: PathLike | "PathNode" | None = None,
) -> list[Path]:
    """List files and folders in a specified directory."""
    path = build_path(*parts, base=base)
    if not path.exists():
        raise FileNotFoundError(path)
    if not path.is_dir():
        raise NotADirectoryError(path)
    return sorted(path.iterdir(), key=lambda item: item.name.lower())


def search(
    pattern: str | Iterable[str],
    *parts: PathLike | "PathNode",
    base: PathLike | "PathNode" | None = None,
    recursive: bool = True,
) -> list[Path]:
    """Search for files and folders by name pattern in a specified directory."""
    path = build_path(*parts, base=base)
    if not path.exists():
        raise FileNotFoundError(path)
    if not path.is_dir():
        raise NotADirectoryError(path)

    patterns = [pattern] if isinstance(pattern, str) else [str(p) for p in pattern]
    matches: list[Path] = []
    iterator = path.rglob("*") if recursive else path.iterdir()

    for item in iterator:
        if any(fnmatch.fnmatch(item.name, pat) for pat in patterns):
            matches.append(item)

    return sorted(matches, key=lambda item: (str(item.parent).lower(), item.name.lower()))


class PathNode:
    def __init__(self, path: PathLike, **children: "PathNode") -> None:
        self._path = _normalize_part(path)
        for name, child in children.items():
            setattr(self, name, child)

    @property
    def path(self) -> Path:
        return self._path

    @property
    def name(self) -> str:
        return self._path.name

    @property
    def parent(self) -> Path:
        return self._path.parent

    def build(self, *parts: PathLike | "PathNode") -> Path:
        return build_path(*parts, base=self)

    def joinpath(self, *parts: PathLike | "PathNode") -> Path:
        return self.build(*parts)

    def exists(self) -> bool:
        return self._path.exists()

    def is_dir(self) -> bool:
        return self._path.is_dir()

    def is_file(self) -> bool:
        return self._path.is_file()

    def __call__(self, *parts: PathLike | "PathNode") -> Path:
        return self.build(*parts)

    def __truediv__(self, other: PathLike | "PathNode") -> Path:
        return self._path / _normalize_part(other)

    def __fspath__(self) -> str:
        return os.fspath(self._path)

    def __str__(self) -> str:
        return str(self._path)

    def __repr__(self) -> str:
        return f"PathNode({self._path!s})"


def _env_path(name: str, fallback: PathLike) -> Path:
    value = os.environ.get(name)
    if value:
        return Path(value)
    return _normalize_part(fallback)


def win_root() -> PathNode:
    home = _env_path("USERPROFILE", Path.home())
    cwd = Path.cwd()
    appdata_roaming = _env_path("APPDATA", home / "AppData" / "Roaming")
    appdata_local = _env_path("LOCALAPPDATA", home / "AppData" / "Local")
    appdata_local_low = appdata_local.parent / "LocalLow"
    desktop = home / "Desktop"
    documents = home / "Documents"
    downloads = home / "Downloads"
    pictures = home / "Pictures"
    videos = home / "Videos"
    music = home / "Music"
    favorites = home / "Favorites"
    saved_games = home / "Saved Games"
    contacts = home / "Contacts"
    links = home / "Links"

    system_drive = _env_path("SystemDrive", r"C:")
    windows_dir = _env_path("WINDIR", system_drive / "Windows")
    system32 = windows_dir / "System32"
    temp = _env_path("TEMP", appdata_local / "Temp")
    tmp = _env_path("TMP", temp)
    program_files = _env_path("ProgramFiles", r"C:\Program Files")
    program_files_x86 = _env_path("ProgramFiles(x86)", r"C:\Program Files (x86)")
    program_data = _env_path("ProgramData", r"C:\ProgramData")
    public = _env_path("PUBLIC", system_drive / "Users" / "Public")
    onedrive = _env_path("OneDrive", home / "OneDrive")
    startup = appdata_roaming / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"
    recent = appdata_roaming / "Microsoft" / "Windows" / "Recent"
    send_to = appdata_roaming / "Microsoft" / "Windows" / "SendTo"

    return PathNode(
        system_drive,
        appdata=PathNode(
            appdata_roaming,
            roaming=PathNode(appdata_roaming),
            local=PathNode(appdata_local),
            local_low=PathNode(appdata_local_low),
        ),
        contacts=PathNode(contacts),
        desktop=PathNode(desktop),
        documents=PathNode(documents),
        downloads=PathNode(downloads),
        favorites=PathNode(favorites),
        home=PathNode(home),
        cwd=PathNode(cwd),
        links=PathNode(links),
        music=PathNode(music),
        pictures=PathNode(pictures),
        program_data=PathNode(program_data),
        program_files=PathNode(program_files),
        program_files_x86=PathNode(program_files_x86),
        public=PathNode(public),
        saved_games=PathNode(saved_games),
        send_to=PathNode(send_to),
        system32=PathNode(system32),
        system_drive=PathNode(system_drive),
        startup=PathNode(startup),
        temp=PathNode(temp),
        tmp=PathNode(tmp),
        user_profile=PathNode(home),
        videos=PathNode(videos),
        windows_dir=PathNode(windows_dir),
        windows_root=PathNode(system_drive),
        onedrive=PathNode(onedrive),
        recent=PathNode(recent),
    )


# backwards compatibility
windows_root = win_root
