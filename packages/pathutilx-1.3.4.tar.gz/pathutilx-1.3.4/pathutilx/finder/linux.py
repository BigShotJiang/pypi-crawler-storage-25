from __future__ import annotations

import tempfile
from pathlib import Path

from .windows import PathNode, _env_path


def linux_root() -> PathNode:
    home = Path.home()
    cwd = Path.cwd()
    xdg_config = _env_path("XDG_CONFIG_HOME", home / ".config")
    xdg_data = _env_path("XDG_DATA_HOME", home / ".local" / "share")
    xdg_cache = _env_path("XDG_CACHE_HOME", home / ".cache")
    desktop = home / "Desktop"
    documents = home / "Documents"
    downloads = home / "Downloads"
    pictures = home / "Pictures"
    videos = home / "Videos"
    music = home / "Music"
    templates = home / "Templates"
    temp = Path(tempfile.gettempdir())
    tmp = temp

    return PathNode(
        Path("/"),
        appdata=PathNode(
            xdg_config,
            config=PathNode(xdg_config),
            data=PathNode(xdg_data),
            cache=PathNode(xdg_cache),
        ),
        cache=PathNode(xdg_cache),
        config=PathNode(xdg_config),
        data=PathNode(xdg_data),
        desktop=PathNode(desktop),
        documents=PathNode(documents),
        downloads=PathNode(downloads),
        home=PathNode(home),
        cwd=PathNode(cwd),
        music=PathNode(music),
        pictures=PathNode(pictures),
        temp=PathNode(temp),
        tmp=PathNode(tmp),
        templates=PathNode(templates),
        user_profile=PathNode(home),
        videos=PathNode(videos),
    )
