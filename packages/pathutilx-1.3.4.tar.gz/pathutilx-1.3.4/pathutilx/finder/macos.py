from __future__ import annotations

import tempfile
from pathlib import Path

from .windows import PathNode, _env_path


def mac_root() -> PathNode:
    home = Path.home()
    cwd = Path.cwd()
    app_support = _env_path("XDG_CONFIG_HOME", home / "Library" / "Application Support")
    cache = _env_path("XDG_CACHE_HOME", home / "Library" / "Caches")
    data = _env_path("XDG_DATA_HOME", home / "Library" / "Application Support")
    desktop = home / "Desktop"
    documents = home / "Documents"
    downloads = home / "Downloads"
    pictures = home / "Pictures"
    videos = home / "Movies"
    music = home / "Music"
    templates = home / "Templates"
    temp = Path(tempfile.gettempdir())
    tmp = temp

    return PathNode(
        Path("/"),
        appdata=PathNode(
            app_support,
            config=PathNode(app_support),
            data=PathNode(data),
            cache=PathNode(cache),
        ),
        cache=PathNode(cache),
        config=PathNode(app_support),
        data=PathNode(data),
        desktop=PathNode(desktop),
        documents=PathNode(documents),
        downloads=PathNode(downloads),
        home=PathNode(home),
        cwd=PathNode(cwd),
        music=PathNode(music),
        pictures=PathNode(pictures),
        temp=PathNode(temp),
        tmp=PathNode(tmp),
        templates=PathNode(templates),
        user_profile=PathNode(home),
        videos=PathNode(videos),
    )
