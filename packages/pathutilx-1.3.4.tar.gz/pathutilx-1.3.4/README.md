# pathutilx

![PyPI](https://img.shields.io/pypi/v/pathutilx.svg?cacheSeconds=60)
![Python Versions](https://img.shields.io/pypi/pyversions/pathutilx.svg?cacheSeconds=60)
![Status](https://img.shields.io/badge/status-production%20stable-brightgreen.svg?cacheSeconds=60)
![Windows](https://img.shields.io/badge/windows-stable-brightgreen?cacheSeconds=60)
![Linux](https://img.shields.io/badge/linux-experimental-yellow?cacheSeconds=60)
![macOS](https://img.shields.io/badge/macos-experimental-yellow?cacheSeconds=60)

`pathutilx` is a lightweight Python package for readable Windows path shortcuts and helpers. It makes it easy to build paths, resolve common Windows folder locations, and perform directory listing and search operations consistently.

## Install

```bash
pip install pathutilx
```
```bash
pip install pathutilx==1.3.4
```
```bash
pip install --upgrade pathutilx
```

## Build and check
*First, make sure you have `build` and `twine` modules installed.*
```bash
pip install build twine
```
*Then, build and check.*
```bash
python -m build
twine check dist/*
```

## Quick Start

```python
from pathutilx import desktop, join

notes = join("notes.txt", base=desktop)
print(notes)
```

```python
import pathutilx as p

print(p.downloads)
print(p.appdata.local)
print(p.cwd)
```

```python
from pathutilx import listdir, search, documents

items = listdir(documents)
print(items)

matches = search("*.docx", documents)
print(matches)
```

## Features

- `build(*parts, base=None)` — build a normalized path from parts
- `join(*parts, base=None)` — alias for `build`
- `listdir(*parts, base=None)` — list files and folders in a directory
- `search(pattern, *parts, base=None, recursive=True)` — search names using glob patterns
- `platform_root()` — access common folders for the current OS
- `win_root()` — access common Windows system folders
- `linux_root()` — access common Linux folders
- `mac_root()` — access common macOS folders
- `windows_root()` — backward-compatible alias for `win_root()`
- Direct access to common locations such as `desktop`, `downloads`, `documents`, `appdata`, `temp`, and more
- `cwd` — current working directory path node

## Usage

Use `win_root()` to access common Windows folders from the package root object:

```python
import pathutilx as p

print(p.win_root().desktop)
print(p.win_root().appdata.local)
```

Use `listdir()` and `search()` to explore filesystem contents:

```python
from pathutilx import listdir, search, desktop

for item in listdir(desktop):
    print(item)

for item in search("*.txt", desktop, recursive=False):
    print(item)
```

Use `platform_root()` to access root folders for the current OS:

```python
import pathutilx as p

root = p.platform_root()
print(root.desktop)
```

## Changelog

### 1.3.4
- Badges fix on `README.md`

## Roadmap

### 1.4.0:

- Stabilized macOS and Linux support
- New features