"""Meta-discovery tool: search_tools.

Provides BM25 Okapi ranked search over MCP tool metadata. The LLM uses
this to discover relevant tools on demand instead of having every tool
schema loaded into the context window.

Supports lazy resolution: when a search matches an unresolved server
category, the tool fetches the server's tools via the resolver before
searching.
"""

from __future__ import annotations

import json
import logging
from typing import Literal, Type

from langchain_core.tools import BaseTool
from oidcauthlib.auth.exceptions.authorization_needed_exception import (
    AuthorizationNeededException,
)
from pydantic import BaseModel, ConfigDict, Field

from languagemodelcommon.mcp.tool_catalog import ToolCatalog, ToolResolverProtocol
from languagemodelcommon.utilities.logger.exception_logger import ExceptionLogger
from languagemodelcommon.utilities.logger.log_levels import SRC_LOG_LEVELS

logger = logging.getLogger(__name__)
logger.setLevel(SRC_LOG_LEVELS.MCP)


class SearchToolsInput(BaseModel):
    category: str | None = Field(
        None,
        description="Optional category to filter tools by. Use one of the category names from the system message.",
    )
    query: str = Field(
        ...,
        description="Natural language search query to find relevant tools.",
    )


class SearchToolsTool(BaseTool):
    """Search for available MCP tools by keyword using BM25 ranking.

    When a resolver is provided, unresolved servers matching the search
    category are lazily resolved (their tools fetched from the MCP server)
    before the BM25 search runs.
    """

    name: str = "search_tools"
    description: str = (
        "Search for available tools by keyword. Returns tool names, descriptions, "
        "and parameter schemas ranked by relevance. Use this to discover tools "
        "before calling them with call_tool."
    )
    args_schema: Type[BaseModel] = SearchToolsInput
    response_format: Literal["content", "content_and_artifact"] = "content"

    catalog: ToolCatalog
    resolver: ToolResolverProtocol | None = None
    max_results: int = 10

    model_config = ConfigDict(arbitrary_types_allowed=True)

    def _run(self, query: str, category: str | None = None) -> str:
        raise NotImplementedError(
            "search_tools requires async execution for lazy tool resolution. "
            "Use _arun instead."
        )

    async def _arun(self, query: str, category: str | None = None) -> str:
        # Lazily resolve any unresolved servers matching the category
        resolution_errors: list[str] = []
        if self.resolver is not None:
            unresolved = self.catalog.get_unresolved_servers(category)
            for server in unresolved:
                try:
                    await self.catalog.resolve_server(server.server_name, self.resolver)
                except AuthorizationNeededException:
                    # Re-raise auth exceptions so the user sees login links
                    raise
                except Exception as e:
                    server_url = (
                        server.agent_config.url if server.agent_config else "unknown"
                    )
                    error_msg = (
                        f"Failed to connect to {server.server_name} "
                        f"(url: {server_url}): "
                        f"{ExceptionLogger.format_exception_message(e)}"
                    )
                    resolution_errors.append(error_msg)
                    logger.warning(
                        "Failed to resolve server %s at %s during search: %s: %s",
                        server.server_name,
                        server_url,
                        type(e).__name__,
                        e,
                    )

        try:
            results = self.catalog.search(
                query=query,
                category=category,
                max_results=self.max_results,
            )
        except Exception as e:
            logger.error(
                "search_tools catalog search failed: %s: %s",
                type(e).__name__,
                e,
            )
            return f"Error searching tools: {type(e).__name__}: {e}"

        if not results:
            # List all tools in the category so the LLM knows what's available
            all_tools = self.catalog.list_tools(category=category)
            if all_tools:
                tool_names = [t["name"] for t in all_tools]
                return (
                    f"No tools matched your search query, but the following "
                    f"tools are available in {category} category:\n"
                    f"{', '.join(tool_names)}. "
                    f"Try searching with different keywords."
                )
            if resolution_errors:
                errors_detail = "\n".join(resolution_errors)
                return (
                    f"No tools found in {category}. "
                    f"Tool discovery failed for the following servers:\n"
                    f"{errors_detail}"
                )
            return f"No tools found matching your query in {category}."
        return json.dumps(results, indent=2)
