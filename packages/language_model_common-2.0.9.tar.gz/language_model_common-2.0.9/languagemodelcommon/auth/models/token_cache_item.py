from typing import Optional

from bson import ObjectId
from oidcauthlib.auth.models.base_db_model import BaseDbModel
from pydantic import Field

from datetime import datetime, UTC

from oidcauthlib.auth.models.token import Token


class TokenCacheItem(BaseDbModel):
    """
    Represents a token cache item in the database.
    """

    created: datetime = Field(
        description="The creation time of the token as a datetime object."
    )
    updated: Optional[datetime] = Field(
        default=None,
        description="The last update time of the token as a datetime object.",
    )
    refreshed: Optional[datetime] = Field(
        default=None,
        description="The last refresh time of the token as a datetime object.",
    )

    auth_provider: str = Field(
        description="The authentication provider associated with the token."
    )
    client_id: Optional[str] = Field(
        default=None,
        description="The client ID associated with the token, if applicable.",
    )
    issuer: str | None = Field(
        default=None,
        description="The issuer of the token, typically the authorization server.",
    )
    audience: str = Field(
        description="The intended audience for the token, usually the resource server."
    )
    email: Optional[str] = Field(
        description="The email associated with the token, used for user identification."
    )
    subject: str = Field(
        description="The subject of the token, typically the user ID or unique identifier."
    )
    referring_email: Optional[str] = Field(
        description="The email of the original token that is linked to this token, if applicable."
    )
    referring_subject: str = Field(
        description="The subject of the original token that is linked to this token, if applicable."
    )
    referrer: Optional[str] = Field(
        default=None, description="The URL associated with the token, if applicable."
    )
    access_token: Optional[Token] = Field(
        default=None, description="The access token used for authentication."
    )
    id_token: Optional[Token] = Field(
        default=None, description="The ID token containing user information."
    )
    refresh_token: Optional[Token] = Field(
        default=None, description="The refresh token used to obtain new access tokens."
    )

    access_token_raw: Optional[str] = Field(
        default=None,
        description="The raw access token string. Stored because the access token may be opaque (non-JWT) for some providers (e.g., Atlassian).",
    )

    refresh_token_raw: Optional[str] = Field(
        default=None,
        description="The raw refresh token string, stored for use in token refresh operations. This is necessary because the refresh token may not be a JWT and may not have the same structure as access or ID tokens.",
    )

    def is_valid_id_token(self) -> bool:
        """
        Check if the token is valid based on its expiration time.
        Returns:
            bool: True if the token is valid, False otherwise.
        """
        return self.id_token.is_valid() if self.id_token else False

    def is_valid_refresh_token(self) -> bool:
        """
        Check if the refresh token is valid based on its expiration time.
        Returns:
            bool: True if the refresh token is valid, False otherwise.
        """
        return self.refresh_token.is_valid() if self.refresh_token else False

    def is_valid_access_token(self) -> bool:
        """
        Check if the access token is valid based on its expiration time.
        For opaque tokens (no decoded Token object), returns True if a raw
        access token string exists since expiry cannot be determined locally.
        Returns:
            bool: True if the access token is valid, False otherwise.
        """
        if self.access_token:
            return self.access_token.is_valid()
        # Opaque token — we have the raw string but can't check expiry locally
        return self.access_token_raw is not None

    def get_access_token_string(self) -> Optional[str]:
        """
        Gets the raw access token string, preferring the decoded Token's string
        but falling back to access_token_raw for opaque tokens.
        """
        if self.access_token:
            return self.access_token.token
        return self.access_token_raw

    def get_access_token(self) -> Optional[Token]:
        """
        Gets the access token Token object if available.
        Returns:
            Optional[Token]: The access token if present, otherwise None.
        """
        return self.access_token if self.access_token else None

    def get_id_token(self) -> Optional[Token]:
        """
        Gets the ID token if it is valid, otherwise returns the access token.
        Returns:
            Optional[str]: The id token if valid, otherwise the access token.
        """
        return self.id_token if self.id_token else None

    def get_refresh_token(self) -> Optional[Token]:
        """
        Gets the refresh token if it is valid.
        Returns:
            Optional[str]: The refresh token if valid, otherwise None.
        """
        return self.refresh_token if self.refresh_token else None

    @classmethod
    def create(
        cls,
        *,
        token: Token,
        auth_provider: str,
        referring_email: Optional[str],
        referring_subject: str,
    ) -> "TokenCacheItem":
        # see what the token this is

        audience: str | None = None
        if isinstance(token.audience, list):
            if len(token.audience) == 1:
                audience = token.audience[0]
        elif isinstance(token.audience, str):
            audience = token.audience

        if audience is None:
            raise ValueError("Audience must be a string or a list with one string.")

        if token.subject is None:
            raise ValueError("Token must have a subject claim.")

        token_cache_item: TokenCacheItem = TokenCacheItem(
            id=ObjectId(),
            created=datetime.now(UTC),
            updated=None,
            refreshed=None,
            auth_provider=auth_provider,
            issuer=token.issuer,
            audience=audience,
            email=token.email or referring_email,
            subject=token.subject or referring_subject,
            referrer=None,
            access_token=token,
            id_token=None,
            refresh_token=None,
            referring_email=referring_email,
            referring_subject=referring_subject,
        )
        if token.is_id_token:
            token_cache_item.id_token = token
        elif token.is_access_token:
            token_cache_item.access_token = token
        elif token.is_refresh_token:
            token_cache_item.refresh_token = token
        else:
            raise ValueError(
                f"Token type must be id, bearer or refresh but was: {token.token_type}"
            )

        return token_cache_item

    def is_expired(self) -> bool:
        """
        Check if the token cache item is expired based on the access token.
        For opaque tokens, returns False (not expired) if a raw access token exists.
        Returns:
            bool: True if the access token is expired, False otherwise.
        """
        return (
            not self.id_token.is_valid()
            if self.id_token
            else not self.access_token.is_valid()
            if self.access_token
            else self.access_token_raw is None
        )
