"""Tests for xonsh-lsp."""
