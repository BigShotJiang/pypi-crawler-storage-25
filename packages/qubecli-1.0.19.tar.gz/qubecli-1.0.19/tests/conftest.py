"""Shared fixtures for qubecli tests."""
import json
import pytest
from pathlib import Path
from typing import Generator
from unittest.mock import MagicMock, patch


@pytest.fixture()
def tmp_config(tmp_path: Path) -> Generator[Path, None, None]:
    """Patch _CONFIG_PATH to a temporary file and reset globals between tests."""
    config_file = tmp_path / "config.json"
    with patch("qubecli.main._CONFIG_PATH", config_file):
        yield config_file


@pytest.fixture()
def config_with_tokens(tmp_path: Path) -> Generator[Path, None, None]:
    """Config file that already has access/refresh tokens (and valid host)."""
    config_file = tmp_path / "config.json"
    config_file.write_text(
        json.dumps(
            {
                "host": "localhost:50051",
                "access_token": "tok_access",
                "refresh_token": "tok_refresh",
            }
        )
    )
    with patch("qubecli.main._CONFIG_PATH", config_file):
        yield config_file


@pytest.fixture()
def mock_qubecore_auth() -> Generator[dict, None, None]:
    """Patch auth helpers so they don't make real network calls.

    NOTE: This fixture does NOT write tokens to the config. Use
    ``authed_config`` (or ``config_with_tokens``) for commands that call
    ``_load_token()``.
    """
    with (
        patch("qubecli.main.login") as mock_login,
        patch("qubecli.main.logout") as mock_logout,
        patch("qubecli.main.refresh_token") as mock_refresh,
        patch("qubecli.main.is_token_expired") as mock_expired,
    ):
        mock_expired.return_value = False  # token is valid by default
        yield {
            "login": mock_login,
            "logout": mock_logout,
            "refresh_token": mock_refresh,
            "is_token_expired": mock_expired,
        }


@pytest.fixture()
def authed_config(tmp_path: Path) -> Generator[tuple[Path, dict], None, None]:
    """Combine a config file with tokens AND patched auth helpers.

    Yields (config_path, auth_mocks) so tests can inspect both.
    """
    config_file = tmp_path / "config.json"
    config_file.write_text(
        json.dumps(
            {
                "host": "localhost:50051",
                "access_token": "tok_access",
                "refresh_token": "tok_refresh",
            }
        )
    )
    with (
        patch("qubecli.main._CONFIG_PATH", config_file),
        patch("qubecli.main.login") as mock_login,
        patch("qubecli.main.logout") as mock_logout,
        patch("qubecli.main.refresh_token") as mock_refresh,
        patch("qubecli.main.is_token_expired") as mock_expired,
    ):
        mock_expired.return_value = False
        yield config_file, {
            "login": mock_login,
            "logout": mock_logout,
            "refresh_token": mock_refresh,
            "is_token_expired": mock_expired,
        }
