"""End-to-end tests for qubecli — real gRPC server, no mocks.

Requirements:
  - QubeCore gRPC server running at localhost:50051
  - Admin credentials: admin / admin
  - Backend: kreo.sc-20 (20-qubit QPU)

Run (skip hardware tests):
    uv run pytest tests/test_e2e.py -v --tb=short -m "not hardware"

Run all including hardware:
    uv run pytest tests/test_e2e.py -v --tb=short
"""
import json
import time
from pathlib import Path
from typing import Generator
from unittest.mock import patch

import pytest
from typer.testing import CliRunner

from qubecli.main import app

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

HOST = "localhost:50051"
ADMIN_USER = "admin"
ADMIN_PASS = "admin"

BELL_CIRCUIT = (
    'OPENQASM 2.0; include "qelib1.inc"; '
    "qreg q[2]; creg c[2]; "
    "h q[0]; cx q[0],q[1]; "
    "measure q->c;"
)

SINGLE_QUBIT_CIRCUIT = (
    'OPENQASM 2.0; include "qelib1.inc"; '
    "qreg q[1]; creg c[1]; "
    "h q[0]; "
    "measure q[0]->c[0];"
)

VALID_JOB_STATUSES = {"PENDING", "RUNNING", "COMPLETED", "FAILED", "CANCELLED"}
TERMINAL_STATUSES = {"COMPLETED", "FAILED", "CANCELLED"}

runner = CliRunner()


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def e2e_config(tmp_path: Path) -> Generator[Path, None, None]:
    """Isolated config file for each E2E test, pointing away from ~/.qubecore/config.json."""
    config_file = tmp_path / "e2e_config.json"
    with patch("qubecli.main._CONFIG_PATH", config_file):
        yield config_file


@pytest.fixture()
def logged_in_config(tmp_path: Path) -> Generator[Path, None, None]:
    """Config file that already has a valid admin session (real login performed once)."""
    config_file = tmp_path / "e2e_config.json"
    with patch("qubecli.main._CONFIG_PATH", config_file):
        result = runner.invoke(
            app,
            ["--host", HOST, "login", "--username", ADMIN_USER, "--password", ADMIN_PASS],
        )
        if result.exit_code != 0:
            pytest.skip(f"Server unavailable or login failed: {result.output}")
        yield config_file


# ---------------------------------------------------------------------------
# Helper: invoke with host + config patch
# ---------------------------------------------------------------------------


def _invoke(config_file: Path, args: list[str]) -> object:
    """Invoke the CLI with the given args, patching _CONFIG_PATH to config_file."""
    with patch("qubecli.main._CONFIG_PATH", config_file):
        return runner.invoke(app, args)


# ---------------------------------------------------------------------------
# 1. Full auth E2E
# ---------------------------------------------------------------------------


class TestAuthE2E:
    """1. Full auth flow: login → config tokens → me."""

    def test_login_exit_code_zero(self, e2e_config: Path) -> None:
        """Login with valid admin credentials should succeed."""
        result = _invoke(
            e2e_config,
            ["--host", HOST, "login", "--username", ADMIN_USER, "--password", ADMIN_PASS],
        )
        assert result.exit_code == 0, f"Login failed: {result.output}"

    def test_login_saves_tokens_to_config(self, e2e_config: Path) -> None:
        """Successful login must persist access_token and refresh_token."""
        _invoke(
            e2e_config,
            ["--host", HOST, "login", "--username", ADMIN_USER, "--password", ADMIN_PASS],
        )
        assert e2e_config.exists(), "Config file was not created"
        cfg = json.loads(e2e_config.read_text())
        assert "access_token" in cfg, "access_token missing from config"
        assert "refresh_token" in cfg, "refresh_token missing from config"
        assert cfg["access_token"], "access_token is empty"
        assert cfg["refresh_token"], "refresh_token is empty"

    def test_login_json_output(self, e2e_config: Path) -> None:
        """--output json login should return parseable JSON with success=true."""
        result = _invoke(
            e2e_config,
            [
                "--host", HOST, "-o", "json",
                "login", "--username", ADMIN_USER, "--password", ADMIN_PASS,
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["success"] is True
        assert data["username"] == ADMIN_USER

    def test_me_shows_admin_info(self, logged_in_config: Path) -> None:
        """After login, 'me' should return admin's user info."""
        result = _invoke(logged_in_config, ["--host", HOST, "-o", "json", "me"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["username"] == ADMIN_USER
        assert data["role"] == "admin"
        assert "user_id" in data
        assert "created_at" in data

    def test_login_bad_password_fails(self, e2e_config: Path) -> None:
        """Login with wrong password should exit non-zero."""
        result = _invoke(
            e2e_config,
            ["--host", HOST, "login", "--username", ADMIN_USER, "--password", "WRONG_PASSWORD"],
        )
        assert result.exit_code != 0, "Expected failure with bad password"

    def test_login_wrong_host_fails(self, e2e_config: Path) -> None:
        """Login pointing at a non-existent server should exit non-zero."""
        result = _invoke(
            e2e_config,
            ["--host", "localhost:19999", "login", "--username", ADMIN_USER, "--password", ADMIN_PASS],
        )
        assert result.exit_code != 0, "Expected failure with wrong host"


# ---------------------------------------------------------------------------
# 2. Full job submit E2E
# ---------------------------------------------------------------------------


class TestJobSubmitE2E:
    """2. Submit → status flow."""

    def test_submit_returns_job_id(self, logged_in_config: Path) -> None:
        """Submitting a valid circuit should return a non-empty job_id."""
        result = _invoke(
            logged_in_config,
            [
                "--host", HOST, "-o", "json",
                "submit",
                "--circuit", BELL_CIRCUIT,
                "--shots", "100",
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["success"] is True
        assert data["job_id"], "job_id is empty"

    def test_submit_job_id_appears_in_status(self, logged_in_config: Path) -> None:
        """After submit, status --job-id should return a recognized status."""
        # Submit
        submit_result = _invoke(
            logged_in_config,
            [
                "--host", HOST, "-o", "json",
                "submit",
                "--circuit", SINGLE_QUBIT_CIRCUIT,
                "--shots", "50",
            ],
        )
        assert submit_result.exit_code == 0, submit_result.output
        job_id = json.loads(submit_result.output)["job_id"]

        # Status check
        status_result = _invoke(
            logged_in_config,
            ["--host", HOST, "-o", "json", "status", "--job-id", job_id],
        )
        assert status_result.exit_code == 0, status_result.output
        status_data = json.loads(status_result.output)
        assert status_data["job_id"] == job_id
        assert status_data["status"] in VALID_JOB_STATUSES

    def test_submit_default_priority_is_normal(self, logged_in_config: Path) -> None:
        """Submitting without priority should default to 3 (NORMAL)."""
        result = _invoke(
            logged_in_config,
            [
                "--host", HOST, "-o", "json",
                "submit",
                "--circuit", SINGLE_QUBIT_CIRCUIT,
                "--shots", "10",
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["priority"] == 3

    def test_submit_with_explicit_priority(self, logged_in_config: Path) -> None:
        """Submitting with --priority 2 should be reflected in JSON output."""
        result = _invoke(
            logged_in_config,
            [
                "--host", HOST, "-o", "json",
                "submit",
                "--circuit", SINGLE_QUBIT_CIRCUIT,
                "--shots", "10",
                "--priority", "2",
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["priority"] == 2

    def test_submit_with_optimization_level(self, logged_in_config: Path) -> None:
        """Submitting with --optimization-level should succeed."""
        result = _invoke(
            logged_in_config,
            [
                "--host", HOST, "-o", "json",
                "submit",
                "--circuit", BELL_CIRCUIT,
                "--shots", "10",
                "--optimization-level", "1",
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["success"] is True

    def test_status_has_required_fields(self, logged_in_config: Path) -> None:
        """Status response must include all required fields."""
        submit_result = _invoke(
            logged_in_config,
            [
                "--host", HOST, "-o", "json",
                "submit",
                "--circuit", SINGLE_QUBIT_CIRCUIT,
                "--shots", "10",
            ],
        )
        job_id = json.loads(submit_result.output)["job_id"]

        status_result = _invoke(
            logged_in_config,
            ["--host", HOST, "-o", "json", "status", "--job-id", job_id],
        )
        data = json.loads(status_result.output)
        required = {"job_id", "status", "priority", "submitted_at"}
        assert required.issubset(data.keys()), f"Missing fields: {required - data.keys()}"


# ---------------------------------------------------------------------------
# 3. Full job cancel E2E
# ---------------------------------------------------------------------------


class TestJobCancelE2E:
    """3. Submit → cancel → verify CANCELLED (or already RUNNING)."""

    def test_cancel_pending_job(self, logged_in_config: Path) -> None:
        """Cancel a freshly-submitted job; expect CANCELLED status."""
        # Submit
        submit_result = _invoke(
            logged_in_config,
            [
                "--host", HOST, "-o", "json",
                "submit",
                "--circuit", SINGLE_QUBIT_CIRCUIT,
                "--shots", "100",
            ],
        )
        assert submit_result.exit_code == 0, submit_result.output
        job_id = json.loads(submit_result.output)["job_id"]

        # Check current status - only attempt cancel if PENDING
        status_result = _invoke(
            logged_in_config,
            ["--host", HOST, "-o", "json", "status", "--job-id", job_id],
        )
        current_status = json.loads(status_result.output)["status"]

        if current_status not in ("PENDING",):
            pytest.skip(f"Job already past PENDING (status={current_status}); cannot cancel")

        # Cancel
        cancel_result = _invoke(
            logged_in_config,
            ["--host", HOST, "-o", "json", "cancel", "--job-id", job_id],
        )
        assert cancel_result.exit_code == 0, cancel_result.output
        cancel_data = json.loads(cancel_result.output)
        assert cancel_data["success"] is True

        # Verify status is CANCELLED
        final_status_result = _invoke(
            logged_in_config,
            ["--host", HOST, "-o", "json", "status", "--job-id", job_id],
        )
        final_status = json.loads(final_status_result.output)["status"]
        assert final_status == "CANCELLED", f"Expected CANCELLED, got {final_status}"

    def test_cancel_nonexistent_job_fails(self, logged_in_config: Path) -> None:
        """Cancelling a non-existent job_id should exit non-zero."""
        result = _invoke(
            logged_in_config,
            ["--host", HOST, "cancel", "--job-id", "00000000-0000-0000-0000-000000000000"],
        )
        assert result.exit_code != 0, "Expected failure cancelling non-existent job"

    def test_cancel_json_response_structure(self, logged_in_config: Path) -> None:
        """Cancel JSON response must have success and message fields."""
        submit_result = _invoke(
            logged_in_config,
            [
                "--host", HOST, "-o", "json",
                "submit",
                "--circuit", SINGLE_QUBIT_CIRCUIT,
                "--shots", "100",
            ],
        )
        job_id = json.loads(submit_result.output)["job_id"]

        status_result = _invoke(
            logged_in_config,
            ["--host", HOST, "-o", "json", "status", "--job-id", job_id],
        )
        if json.loads(status_result.output)["status"] != "PENDING":
            pytest.skip("Job not in PENDING state, skipping cancel structure test")

        cancel_result = _invoke(
            logged_in_config,
            ["--host", HOST, "-o", "json", "cancel", "--job-id", job_id],
        )
        assert cancel_result.exit_code == 0, cancel_result.output
        data = json.loads(cancel_result.output)
        assert "success" in data
        assert "message" in data


# ---------------------------------------------------------------------------
# 4. Backend info E2E
# ---------------------------------------------------------------------------


class TestBackendInfoE2E:
    """4. backend-info and characterization commands."""

    def test_backend_info_returns_valid_json(self, logged_in_config: Path) -> None:
        """backend-info --output json must return parseable JSON."""
        result = _invoke(
            logged_in_config,
            ["--host", HOST, "-o", "json", "backend-info"],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert "name" in data
        assert "num_qubits" in data

    def test_backend_info_has_expected_fields(self, logged_in_config: Path) -> None:
        """backend-info JSON must include all required fields with sensible values."""
        result = _invoke(
            logged_in_config,
            ["--host", HOST, "-o", "json", "backend-info"],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert isinstance(data["name"], str) and data["name"], "name must be non-empty string"
        assert isinstance(data["num_qubits"], int) and data["num_qubits"] > 0, "num_qubits must be positive int"
        assert isinstance(data["coupling_map"], list), "coupling_map must be a list"
        assert isinstance(data["native_gates"], list), "native_gates must be a list"
        assert isinstance(data["qasm_supported_gates"], list), "qasm_supported_gates must be a list"

    def test_backend_info_kreo_sc20(self, logged_in_config: Path) -> None:
        """Backend should be kreo.sc-20 with 20 qubits."""
        result = _invoke(
            logged_in_config,
            ["--host", HOST, "-o", "json", "backend-info"],
        )
        data = json.loads(result.output)
        assert data["name"] == "kreo.sc-20", f"Expected kreo.sc-20, got {data['name']}"
        assert data["num_qubits"] == 20, f"Expected 20 qubits, got {data['num_qubits']}"

    def test_characterization_returns_valid_json(self, logged_in_config: Path) -> None:
        """characterization --output json must return parseable JSON."""
        result = _invoke(
            logged_in_config,
            ["--host", HOST, "-o", "json", "characterization"],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert "last_calibrated" in data
        assert "qubits" in data

    def test_characterization_has_qubit_data(self, logged_in_config: Path) -> None:
        """characterization must include qubit data with T1, T2, frequency."""
        result = _invoke(
            logged_in_config,
            ["--host", HOST, "-o", "json", "characterization"],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert isinstance(data["qubits"], list), "qubits must be a list"
        assert len(data["qubits"]) > 0, "qubits list must not be empty"
        qubit = data["qubits"][0]
        assert "index" in qubit
        assert "t1" in qubit
        assert "t2" in qubit
        assert "frequency" in qubit

    def test_characterization_qubit_count_matches_backend(self, logged_in_config: Path) -> None:
        """Number of qubits in characterization should match backend num_qubits."""
        backend_result = _invoke(
            logged_in_config,
            ["--host", HOST, "-o", "json", "backend-info"],
        )
        char_result = _invoke(
            logged_in_config,
            ["--host", HOST, "-o", "json", "characterization"],
        )
        backend_data = json.loads(backend_result.output)
        char_data = json.loads(char_result.output)
        assert len(char_data["qubits"]) == backend_data["num_qubits"]

    def test_backend_info_text_output(self, logged_in_config: Path) -> None:
        """backend-info in text mode should contain name and num_qubits labels."""
        result = _invoke(
            logged_in_config,
            ["--host", HOST, "backend-info"],
        )
        assert result.exit_code == 0, result.output
        assert "name" in result.output
        assert "num_qubits" in result.output


# ---------------------------------------------------------------------------
# 5. Jobs list E2E
# ---------------------------------------------------------------------------


class TestJobsListE2E:
    """5. Submit then verify job appears in jobs list."""

    def test_jobs_returns_valid_json(self, logged_in_config: Path) -> None:
        """jobs --output json must return parseable JSON with total and jobs."""
        result = _invoke(
            logged_in_config,
            ["--host", HOST, "-o", "json", "jobs"],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert "total" in data
        assert "jobs" in data
        assert isinstance(data["total"], int)
        assert isinstance(data["jobs"], list)

    def test_submitted_job_appears_in_list(self, logged_in_config: Path) -> None:
        """A newly-submitted job must appear in the jobs list."""
        # Submit a job
        submit_result = _invoke(
            logged_in_config,
            [
                "--host", HOST, "-o", "json",
                "submit",
                "--circuit", SINGLE_QUBIT_CIRCUIT,
                "--shots", "10",
            ],
        )
        assert submit_result.exit_code == 0, submit_result.output
        submitted_job_id = json.loads(submit_result.output)["job_id"]

        # Fetch jobs list (page 1, large enough size)
        jobs_result = _invoke(
            logged_in_config,
            ["--host", HOST, "-o", "json", "jobs", "--page", "1", "--size", "50"],
        )
        assert jobs_result.exit_code == 0, jobs_result.output
        jobs_data = json.loads(jobs_result.output)

        job_ids = [j["job_id"] for j in jobs_data["jobs"]]
        assert submitted_job_id in job_ids, (
            f"Submitted job {submitted_job_id} not found in jobs list. Got: {job_ids[:5]}"
        )

    def test_jobs_list_job_has_required_fields(self, logged_in_config: Path) -> None:
        """Each job in the list must have required fields."""
        result = _invoke(
            logged_in_config,
            ["--host", HOST, "-o", "json", "jobs", "--size", "5"],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        if data["jobs"]:
            job = data["jobs"][0]
            required = {"job_id", "type", "status", "priority", "submitted_at"}
            assert required.issubset(job.keys()), f"Missing fields: {required - job.keys()}"

    def test_jobs_pagination(self, logged_in_config: Path) -> None:
        """Pagination parameters should be passed through correctly."""
        result_p1 = _invoke(
            logged_in_config,
            ["--host", HOST, "-o", "json", "jobs", "--page", "1", "--size", "3"],
        )
        result_p2 = _invoke(
            logged_in_config,
            ["--host", HOST, "-o", "json", "jobs", "--page", "2", "--size", "3"],
        )
        assert result_p1.exit_code == 0, result_p1.output
        assert result_p2.exit_code == 0, result_p2.output

        data_p1 = json.loads(result_p1.output)
        data_p2 = json.loads(result_p2.output)

        # Totals should be identical
        assert data_p1["total"] == data_p2["total"]

        # If there are enough jobs, page 1 and page 2 should differ
        if data_p1["total"] > 3:
            ids_p1 = {j["job_id"] for j in data_p1["jobs"]}
            ids_p2 = {j["job_id"] for j in data_p2["jobs"]}
            assert ids_p1 != ids_p2, "Page 1 and page 2 should have different jobs"

    def test_jobs_status_values_are_valid(self, logged_in_config: Path) -> None:
        """All job statuses in the list must be one of the known statuses."""
        result = _invoke(
            logged_in_config,
            ["--host", HOST, "-o", "json", "jobs", "--size", "20"],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        for job in data["jobs"]:
            assert job["status"] in VALID_JOB_STATUSES, f"Unknown status: {job['status']}"


# ---------------------------------------------------------------------------
# 6. Hardware E2E (marked, may require QPU)
# ---------------------------------------------------------------------------


@pytest.mark.hardware
class TestHardwareE2E:
    """6. Hardware tests — require live QPU connection (may time out if no QPU)."""

    POLL_INTERVAL_S = 3
    TIMEOUT_S = 60

    def _wait_for_terminal(self, config_file: Path, job_id: str) -> str:
        """Poll job status until terminal or timeout. Returns final status string."""
        deadline = time.time() + self.TIMEOUT_S
        while time.time() < deadline:
            status_result = _invoke(
                config_file,
                ["--host", HOST, "-o", "json", "status", "--job-id", job_id],
            )
            assert status_result.exit_code == 0, status_result.output
            status = json.loads(status_result.output)["status"]
            if status in TERMINAL_STATUSES:
                return status
            time.sleep(self.POLL_INTERVAL_S)
        return "TIMEOUT"

    def test_bell_state_job_completes(self, logged_in_config: Path) -> None:
        """Submit Bell state, poll until COMPLETED, verify counts dict exists."""
        submit_result = _invoke(
            logged_in_config,
            [
                "--host", HOST, "-o", "json",
                "submit",
                "--circuit", BELL_CIRCUIT,
                "--shots", "100",
            ],
        )
        assert submit_result.exit_code == 0, submit_result.output
        job_id = json.loads(submit_result.output)["job_id"]

        final_status = self._wait_for_terminal(logged_in_config, job_id)

        if final_status == "TIMEOUT":
            pytest.skip(f"Job {job_id} did not complete within {self.TIMEOUT_S}s (no QPU?)")

        if final_status == "FAILED":
            # Get error details
            status_result = _invoke(
                logged_in_config,
                ["--host", HOST, "-o", "json", "status", "--job-id", job_id],
            )
            error = json.loads(status_result.output).get("error", "unknown")
            pytest.skip(f"Job FAILED (hardware may not be available): {error}")

        assert final_status == "COMPLETED", f"Expected COMPLETED, got {final_status}"

        # Fetch result and verify counts dict exists
        result_resp = _invoke(
            logged_in_config,
            ["--host", HOST, "-o", "json", "result", "--job-id", job_id],
        )
        assert result_resp.exit_code == 0, result_resp.output
        result_data = json.loads(result_resp.output)
        assert result_data["status"] == "COMPLETED"
        assert "results" in result_data, "Expected 'results' key in job result"
        assert len(result_data["results"]) > 0, "Expected at least one result"
        assert "counts" in result_data["results"][0], "Expected 'counts' key in first result"
        counts = result_data["results"][0]["counts"]
        assert isinstance(counts, dict), "counts must be a dict"
        assert len(counts) > 0, "counts dict must not be empty"

    def test_single_qubit_job_result_has_shots(self, logged_in_config: Path) -> None:
        """Single-qubit H gate result counts should sum to the requested shots."""
        shots = 200
        submit_result = _invoke(
            logged_in_config,
            [
                "--host", HOST, "-o", "json",
                "submit",
                "--circuit", SINGLE_QUBIT_CIRCUIT,
                "--shots", str(shots),
            ],
        )
        assert submit_result.exit_code == 0, submit_result.output
        job_id = json.loads(submit_result.output)["job_id"]

        final_status = self._wait_for_terminal(logged_in_config, job_id)

        if final_status in ("TIMEOUT", "FAILED"):
            pytest.skip(f"Job did not complete (status={final_status})")

        result_resp = _invoke(
            logged_in_config,
            ["--host", HOST, "-o", "json", "result", "--job-id", job_id],
        )
        result_data = json.loads(result_resp.output)
        counts = result_data["results"][0]["counts"]
        total_counts = sum(counts.values())
        assert total_counts == shots, f"Expected {shots} total counts, got {total_counts}"


# ---------------------------------------------------------------------------
# 7. Additional integration / edge-case E2E
# ---------------------------------------------------------------------------


class TestEdgeCaseE2E:
    """Additional E2E edge-case tests."""

    def test_status_unknown_job_id_fails(self, logged_in_config: Path) -> None:
        """status with a non-existent job_id should exit non-zero."""
        result = _invoke(
            logged_in_config,
            ["--host", HOST, "status", "--job-id", "00000000-0000-0000-0000-000000000000"],
        )
        assert result.exit_code != 0, "Expected failure for unknown job_id"

    def test_me_without_login_fails(self, e2e_config: Path) -> None:
        """Calling 'me' without logging in first should fail."""
        result = _invoke(e2e_config, ["--host", HOST, "me"])
        assert result.exit_code != 0, "Expected failure when not logged in"

    def test_jobs_without_login_fails(self, e2e_config: Path) -> None:
        """Calling 'jobs' without logging in should fail."""
        result = _invoke(e2e_config, ["--host", HOST, "jobs"])
        assert result.exit_code != 0, "Expected failure when not logged in"

    def test_submit_without_login_fails(self, e2e_config: Path) -> None:
        """submit without login should fail."""
        result = _invoke(
            e2e_config,
            [
                "--host", HOST,
                "submit",
                "--circuit", SINGLE_QUBIT_CIRCUIT,
                "--shots", "10",
            ],
        )
        assert result.exit_code != 0, "Expected failure when not logged in"

    def test_backend_info_no_auth_required(self, e2e_config: Path) -> None:
        """backend-info should be accessible (may or may not require auth depending on server config).

        We just verify the command runs without crashing.
        """
        # First login to get a valid session, then test backend-info
        _invoke(
            e2e_config,
            ["--host", HOST, "login", "--username", ADMIN_USER, "--password", ADMIN_PASS],
        )
        result = _invoke(e2e_config, ["--host", HOST, "-o", "json", "backend-info"])
        # If server requires auth, exit_code=0 only after login which we did.
        # Just check the JSON is well-formed on success
        if result.exit_code == 0:
            data = json.loads(result.output)
            assert "name" in data
            assert "num_qubits" in data

    def test_multiple_jobs_submitted_sequentially(self, logged_in_config: Path) -> None:
        """Submit 3 jobs in sequence; all should get distinct job_ids."""
        job_ids = []
        for i in range(3):
            r = _invoke(
                logged_in_config,
                [
                    "--host", HOST, "-o", "json",
                    "submit",
                    "--circuit", SINGLE_QUBIT_CIRCUIT,
                    "--shots", "10",
                ],
            )
            assert r.exit_code == 0, f"Submit {i} failed: {r.output}"
            job_ids.append(json.loads(r.output)["job_id"])
        assert len(set(job_ids)) == 3, f"Expected 3 distinct job_ids, got {job_ids}"

    def test_submit_text_output_contains_job_id(self, logged_in_config: Path) -> None:
        """Text-mode submit output should contain the job_id (UUID format)."""
        result = _invoke(
            logged_in_config,
            [
                "--host", HOST,
                "submit",
                "--circuit", SINGLE_QUBIT_CIRCUIT,
                "--shots", "10",
            ],
        )
        assert result.exit_code == 0, result.output
        assert "job_id" in result.output or "job" in result.output.lower()

    def test_jobs_total_increases_after_submit(self, logged_in_config: Path) -> None:
        """Total job count should increase by at least 1 after a submission."""
        before = json.loads(
            _invoke(logged_in_config, ["--host", HOST, "-o", "json", "jobs", "--size", "1"]).output
        )["total"]

        _invoke(
            logged_in_config,
            [
                "--host", HOST, "-o", "json",
                "submit",
                "--circuit", SINGLE_QUBIT_CIRCUIT,
                "--shots", "10",
            ],
        )

        after = json.loads(
            _invoke(logged_in_config, ["--host", HOST, "-o", "json", "jobs", "--size", "1"]).output
        )["total"]
        assert after > before, f"Expected total to increase: before={before}, after={after}"

    def test_full_stack_flow(self, logged_in_config: Path) -> None:
        """Complete CLI → SDK → QubeCore → DB flow: login → submit → status → jobs list."""
        # 1. Submit
        submit_result = _invoke(
            logged_in_config,
            [
                "--host", HOST, "-o", "json",
                "submit",
                "--circuit", BELL_CIRCUIT,
                "--shots", "100",
            ],
        )
        assert submit_result.exit_code == 0, submit_result.output
        job_id = json.loads(submit_result.output)["job_id"]
        assert job_id, "Expected a non-empty job_id"

        # 2. Status is valid
        status_result = _invoke(
            logged_in_config,
            ["--host", HOST, "-o", "json", "status", "--job-id", job_id],
        )
        assert status_result.exit_code == 0, status_result.output
        status_data = json.loads(status_result.output)
        assert status_data["status"] in VALID_JOB_STATUSES

        # 3. Job appears in list
        jobs_result = _invoke(
            logged_in_config,
            ["--host", HOST, "-o", "json", "jobs", "--size", "50"],
        )
        assert jobs_result.exit_code == 0, jobs_result.output
        jobs_data = json.loads(jobs_result.output)
        all_ids = [j["job_id"] for j in jobs_data["jobs"]]
        assert job_id in all_ids, f"Job {job_id} not found in jobs list"


# ---------------------------------------------------------------------------
# 8. Logout E2E
# ---------------------------------------------------------------------------


class TestLogoutE2E:
    """8. Logout flow tests."""

    def test_logout_clears_tokens(self, tmp_path: Path) -> None:
        """Login then logout — access_token and refresh_token must be removed from config."""
        config_file = tmp_path / "e2e_config.json"
        with patch("qubecli.main._CONFIG_PATH", config_file):
            # Login first
            login_result = runner.invoke(
                app,
                ["--host", HOST, "login", "--username", ADMIN_USER, "--password", ADMIN_PASS],
            )
            if login_result.exit_code != 0:
                pytest.skip(f"Server unavailable or login failed: {login_result.output}")

            assert config_file.exists(), "Config file must exist after login"
            cfg_before = json.loads(config_file.read_text())
            assert "access_token" in cfg_before, "access_token must be present after login"
            assert "refresh_token" in cfg_before, "refresh_token must be present after login"

            # Logout
            logout_result = _invoke(config_file, ["--host", HOST, "logout"])
            assert logout_result.exit_code == 0, f"Logout failed: {logout_result.output}"

            cfg_after = json.loads(config_file.read_text())
            assert "access_token" not in cfg_after, "access_token must be removed after logout"
            assert "refresh_token" not in cfg_after, "refresh_token must be removed after logout"

    def test_logout_json_response(self, logged_in_config: Path) -> None:
        """-o json logout must return {"success": true}."""
        result = _invoke(logged_in_config, ["--host", HOST, "-o", "json", "logout"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["success"] is True

    def test_logout_without_login_fails(self, e2e_config: Path) -> None:
        """Logout without prior login must exit with code 1."""
        result = _invoke(e2e_config, ["--host", HOST, "logout"])
        assert result.exit_code != 0, "Expected exit code 1 when not logged in"


# ---------------------------------------------------------------------------
# 9. Submit pulse E2E
# ---------------------------------------------------------------------------

# Minimal pulse JSON accepted by QubeCore's pulse-job endpoint.
_MINIMAL_PULSE = json.dumps({"program": [], "lo_config": {}})


class TestSubmitPulseE2E:
    """9. submit-pulse command tests."""

    def test_submit_pulse_returns_job_id(self, logged_in_config: Path) -> None:
        """submit-pulse with a valid pulse string should return a non-empty job_id."""
        result = _invoke(
            logged_in_config,
            [
                "--host", HOST, "-o", "json",
                "submit-pulse",
                "--pulse", _MINIMAL_PULSE,
                "--shots", "100",
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["success"] is True
        assert data["job_id"], "job_id must not be empty"

    def test_submit_pulse_json_output(self, logged_in_config: Path) -> None:
        """-o json submit-pulse must return JSON with job_id, success, and priority."""
        result = _invoke(
            logged_in_config,
            [
                "--host", HOST, "-o", "json",
                "submit-pulse",
                "--pulse", _MINIMAL_PULSE,
                "--shots", "50",
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert "job_id" in data
        assert "success" in data
        assert "priority" in data


# ---------------------------------------------------------------------------
# 10. Submit calibration E2E
# ---------------------------------------------------------------------------

_WIDESCAN_PARAMS = json.dumps(
    {"qubit": "qubit_0", "span": 100_000_000, "n_points": 51, "num_shots": 100}
)


class TestSubmitCalibrationE2E:
    """10. submit-calibration command tests."""

    def test_submit_calibration_widescan(self, logged_in_config: Path) -> None:
        """submit-calibration widescan should return a non-empty job_id."""
        result = _invoke(
            logged_in_config,
            [
                "--host", HOST, "-o", "json",
                "submit-calibration",
                "--calibration-type", "widescan",
                "--params", _WIDESCAN_PARAMS,
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["success"] is True
        assert data["job_id"], "job_id must not be empty"
        assert data["calibration_type"] == "widescan"

    def test_submit_calibration_invalid_json_fails(self, logged_in_config: Path) -> None:
        """submit-calibration with malformed --params JSON must exit with code 1."""
        result = _invoke(
            logged_in_config,
            [
                "--host", HOST,
                "submit-calibration",
                "--calibration-type", "widescan",
                "--params", "not-valid-json",
            ],
        )
        assert result.exit_code != 0, "Expected failure for invalid JSON params"

    def test_submit_calibration_json_output(self, logged_in_config: Path) -> None:
        """-o json submit-calibration must return JSON with expected fields."""
        result = _invoke(
            logged_in_config,
            [
                "--host", HOST, "-o", "json",
                "submit-calibration",
                "--calibration-type", "widescan",
                "--params", _WIDESCAN_PARAMS,
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert "job_id" in data
        assert "success" in data
        assert "calibration_type" in data
        assert "priority" in data


# ---------------------------------------------------------------------------
# 11. Result E2E
# ---------------------------------------------------------------------------


class TestResultE2E:
    """11. result command tests."""

    def test_result_pending_job(self, logged_in_config: Path) -> None:
        """result for a freshly-submitted job must return a response with job_id and status."""
        # Submit a job to get a real job_id
        submit_result = _invoke(
            logged_in_config,
            [
                "--host", HOST, "-o", "json",
                "submit",
                "--circuit", SINGLE_QUBIT_CIRCUIT,
                "--shots", "10",
            ],
        )
        assert submit_result.exit_code == 0, submit_result.output
        job_id = json.loads(submit_result.output)["job_id"]

        # Fetch result — job may still be PENDING/RUNNING; that is acceptable.
        result = _invoke(
            logged_in_config,
            ["--host", HOST, "-o", "json", "result", "--job-id", job_id],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["job_id"] == job_id
        assert "status" in data

    def test_result_json_output(self, logged_in_config: Path) -> None:
        """-o json result must return parseable JSON with at least job_id and status."""
        submit_result = _invoke(
            logged_in_config,
            [
                "--host", HOST, "-o", "json",
                "submit",
                "--circuit", SINGLE_QUBIT_CIRCUIT,
                "--shots", "10",
            ],
        )
        assert submit_result.exit_code == 0, submit_result.output
        job_id = json.loads(submit_result.output)["job_id"]

        result = _invoke(
            logged_in_config,
            ["--host", HOST, "-o", "json", "result", "--job-id", job_id],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert "job_id" in data
        assert "status" in data

    def test_result_unknown_job_fails(self, logged_in_config: Path) -> None:
        """result for a non-existent job_id must exit non-zero or output a not-found message."""
        result = _invoke(
            logged_in_config,
            ["--host", HOST, "result", "--job-id", "00000000-0000-0000-0000-000000000000"],
        )
        # Either the server returns an error (exit code != 0) or a not-found message.
        if result.exit_code == 0:
            output_lower = result.output.lower()
            assert (
                "not found" in output_lower or "error" in output_lower
            ), f"Expected not-found or error message, got: {result.output}"
        else:
            assert result.exit_code != 0


# ---------------------------------------------------------------------------
# 12. Update characterization E2E (admin only)
# ---------------------------------------------------------------------------


class TestUpdateCharacterizationE2E:
    """12. update-characterization admin command tests."""

    def _get_characterization(self, config_file: Path) -> dict:
        """Helper: fetch current characterization JSON from the server."""
        result = _invoke(config_file, ["--host", HOST, "-o", "json", "characterization"])
        assert result.exit_code == 0, f"Failed to fetch characterization: {result.output}"
        return json.loads(result.output)

    def test_update_characterization_succeeds(self, logged_in_config: Path) -> None:
        """Read current characterization then write it back — must succeed."""
        current = self._get_characterization(logged_in_config)
        data_json = json.dumps(current)

        result = _invoke(
            logged_in_config,
            [
                "--host", HOST, "-o", "json",
                "update-characterization",
                "--data", data_json,
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["success"] is True

    def test_update_characterization_invalid_json_fails(self, logged_in_config: Path) -> None:
        """update-characterization with malformed JSON must exit with code 1."""
        result = _invoke(
            logged_in_config,
            [
                "--host", HOST,
                "update-characterization",
                "--data", "not-valid-json",
            ],
        )
        assert result.exit_code != 0, "Expected failure for invalid JSON"

    def test_update_characterization_json_output(self, logged_in_config: Path) -> None:
        """-o json update-characterization must return JSON with success and message fields."""
        current = self._get_characterization(logged_in_config)
        data_json = json.dumps(current)

        result = _invoke(
            logged_in_config,
            [
                "--host", HOST, "-o", "json",
                "update-characterization",
                "--data", data_json,
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert "success" in data
        assert "message" in data


# ---------------------------------------------------------------------------
# 13. Update QChip E2E (admin only)
# ---------------------------------------------------------------------------

_VALID_QCHIP_UPDATE = json.dumps(
    [{"qubit": "qubit_0", "freq": 4.85e9, "readfreq": 6.5e9, "gates": []}]
)


class TestUpdateQChipE2E:
    """13. update-qchip admin command tests."""

    def test_update_qchip_succeeds_or_unimplemented(self, logged_in_config: Path) -> None:
        """update-qchip should either succeed or raise a known server-side error (NotImplemented)."""
        result = _invoke(
            logged_in_config,
            [
                "--host", HOST,
                "update-qchip",
                "--updates", _VALID_QCHIP_UPDATE,
            ],
        )
        if result.exit_code != 0:
            output_lower = result.output.lower()
            if any(kw in output_lower for kw in ("unimplemented", "not implemented", "grpc error")):
                pytest.skip(f"update-qchip not implemented on this server: {result.output.strip()}")
            pytest.fail(f"update-qchip failed unexpectedly: {result.output.strip()}")

    def test_update_qchip_invalid_json_fails(self, logged_in_config: Path) -> None:
        """update-qchip with malformed JSON must exit with code 1."""
        result = _invoke(
            logged_in_config,
            [
                "--host", HOST,
                "update-qchip",
                "--updates", "not-valid-json",
            ],
        )
        assert result.exit_code != 0, "Expected failure for invalid JSON"

    def test_update_qchip_not_array_fails(self, logged_in_config: Path) -> None:
        """update-qchip --updates with a JSON object (not array) must exit with code 1."""
        result = _invoke(
            logged_in_config,
            [
                "--host", HOST,
                "update-qchip",
                "--updates", '{"qubit": "qubit_0"}',
            ],
        )
        assert result.exit_code != 0, "Expected failure when updates is a JSON object, not array"


# ---------------------------------------------------------------------------
# 14. Submit reset E2E
# ---------------------------------------------------------------------------


class TestSubmitResetE2E:
    """14. submit-reset command tests."""

    def test_submit_reset_returns_job_id(self, logged_in_config: Path) -> None:
        """submit-reset with valid qubit name and shots should return a non-empty job_id."""
        result = _invoke(
            logged_in_config,
            [
                "--host", HOST, "-o", "json",
                "submit-reset",
                "--qubits", "qubit_0",
                "--shots", "100",
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["success"] is True
        assert data["job_id"], "job_id must not be empty"
        assert "qubit_0" in data["qubits"]


# ---------------------------------------------------------------------------
# 15. Config E2E (local file I/O, no server needed)
# ---------------------------------------------------------------------------


class TestConfigE2E:
    """15. config set / get / unset commands — operate on local config file only."""

    def test_config_set_host_persists(self, e2e_config: Path) -> None:
        """config set host → value is written to config file."""
        result = _invoke(e2e_config, ["config", "set", "host", "10.0.0.1:50051"])
        assert result.exit_code == 0, result.output
        cfg = json.loads(e2e_config.read_text())
        assert cfg["host"] == "10.0.0.1:50051"

    def test_config_get_shows_value(self, e2e_config: Path) -> None:
        """config set then config get → displays the saved host."""
        _invoke(e2e_config, ["config", "set", "host", "server.internal:50051"])
        result = _invoke(e2e_config, ["config", "get", "host"])
        assert result.exit_code == 0, result.output
        assert "server.internal:50051" in result.output

    def test_config_get_json_output(self, e2e_config: Path) -> None:
        """config get -o json → parseable JSON containing the host key."""
        _invoke(e2e_config, ["config", "set", "host", "localhost:50051"])
        result = _invoke(e2e_config, ["-o", "json", "config", "get", "host"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert "host" in data
        assert data["host"] == "localhost:50051"

    def test_config_unset_removes_key(self, e2e_config: Path) -> None:
        """config set then config unset → key is removed from config file."""
        _invoke(e2e_config, ["config", "set", "host", "localhost:50051"])
        result = _invoke(e2e_config, ["config", "unset", "host"])
        assert result.exit_code == 0, result.output
        cfg = json.loads(e2e_config.read_text())
        assert "host" not in cfg

    def test_config_set_unknown_key_fails(self, e2e_config: Path) -> None:
        """config set with an unknown key → exit non-zero."""
        result = _invoke(e2e_config, ["config", "set", "bad_key", "value"])
        assert result.exit_code != 0, "Expected failure for unknown config key"

    def test_config_get_empty_config(self, e2e_config: Path) -> None:
        """config get when nothing is saved → exit 0 and prints no-config message."""
        result = _invoke(e2e_config, ["config", "get"])
        assert result.exit_code == 0, result.output
        assert "No config saved" in result.output


# ---------------------------------------------------------------------------
# 8. Stream E2E
# ---------------------------------------------------------------------------


class TestStreamE2E:
    """stream command — bidirectional streaming gate job."""

    TEMPLATE = (
        'OPENQASM 2.0;\\n'
        'include "qelib1.inc";\\n'
        'qreg q[1];\\n'
        'creg c[1];\\n'
        'rx({theta}) q[0];\\n'
        'measure q[0]->c[0];'
    )
    PARAMS = '[{"theta": 0.0}, {"theta": 1.5707963}]'

    def test_stream_invalid_params_json_fails(self, logged_in_config: Path) -> None:
        """stream with invalid --params JSON → exit 1."""
        result = _invoke(
            logged_in_config,
            ["--host", HOST, "stream",
             "--template", self.TEMPLATE,
             "--params", "not-valid-json",
             "--shots", "10"],
        )
        assert result.exit_code != 0

    def test_stream_params_not_array_fails(self, logged_in_config: Path) -> None:
        """stream with --params as object (not array) → exit 1."""
        result = _invoke(
            logged_in_config,
            ["--host", HOST, "stream",
             "--template", self.TEMPLATE,
             "--params", '{"theta": 0.0}',
             "--shots", "10"],
        )
        assert result.exit_code != 0

    @pytest.mark.hardware
    def test_stream_two_params_yields_two_results(self, logged_in_config: Path) -> None:
        """stream with 2 param sets → 2 results returned (hardware)."""
        result = _invoke(
            logged_in_config,
            ["--host", HOST, "-o", "json",
             "stream",
             "--template", self.TEMPLATE,
             "--params", self.PARAMS,
             "--shots", "100"],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert isinstance(data, list)
        assert len(data) == 2
        for item in data:
            assert "counts" in item
