"""Unit tests for qubecli CLI using typer.testing.CliRunner."""
import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import grpc
import pytest
from typer.testing import CliRunner

from qubecli.main import app

runner = CliRunner()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_client_mock(
    *,
    job_status: dict | None = None,
    jobs_result: dict | None = None,
    cancel_message: str = "Job cancelled",
    job_id: str = "job-abc-123",
) -> MagicMock:
    """Return a fully-configured mock QubeClient instance."""
    mock_client = MagicMock()
    mock_client.close = MagicMock()

    # status
    if job_status is None:
        job_status = {
            "job_id": job_id,
            "status": "COMPLETED",
            "priority": 3,
            "submitted_at": "2024-01-01T00:00:00Z",
            "started_at": "2024-01-01T00:00:01Z",
            "finished_at": "2024-01-01T00:00:02Z",
            "error": None,
        }
    mock_client.get_job_status.return_value = job_status

    # jobs list
    if jobs_result is None:
        jobs_result = {
            "total": 1,
            "jobs": [
                {
                    "job_id": job_id,
                    "type": "GATE",
                    "status": "COMPLETED",
                    "priority": 3,
                    "submitted_at": "2024-01-01T00:00:00Z",
                    "finished_at": "2024-01-01T00:00:02Z",
                }
            ],
        }
    mock_client.get_my_jobs.return_value = jobs_result

    # submit
    mock_client.submit_gate_job.return_value = job_id
    mock_client.submit_reset_job.return_value = job_id

    # cancel
    mock_client.cancel_job.return_value = cancel_message

    return mock_client


def _patch_client(mock_client: MagicMock):
    """Return a context-manager patch for QubeClient at the module level."""
    return patch("qubecli.main.QubeClient", return_value=mock_client)


class _FakeRpcError(grpc.RpcError):
    """Minimal concrete grpc.RpcError for testing."""

    def __init__(self, status_code: grpc.StatusCode, detail: str = "error") -> None:
        super().__init__(detail)
        self._status_code = status_code
        self._detail = detail

    def code(self) -> grpc.StatusCode:
        return self._status_code

    def details(self) -> str:
        return self._detail


def _make_grpc_error(status_code: grpc.StatusCode, detail: str = "error") -> _FakeRpcError:
    """Build a real grpc.RpcError subclass instance so it can be raised and caught."""
    return _FakeRpcError(status_code, detail)


# ---------------------------------------------------------------------------
# 1. --output / -o flag
# ---------------------------------------------------------------------------

class TestOutputFlag:
    def test_json_output_for_status(self, authed_config: tuple):
        mock_client = _make_client_mock()
        with _patch_client(mock_client):
            result = runner.invoke(app, ["-o", "json", "status", "--job-id", "abc"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["job_id"] == "job-abc-123"
        assert data["status"] == "COMPLETED"

    def test_text_output_for_status(self, authed_config: tuple):
        mock_client = _make_client_mock()
        with _patch_client(mock_client):
            result = runner.invoke(app, ["status", "--job-id", "abc"])
        assert result.exit_code == 0, result.output
        assert "job_id" in result.output
        assert "COMPLETED" in result.output
        # Should NOT be parseable as a single JSON object
        with pytest.raises(json.JSONDecodeError):
            json.loads(result.output)

    def test_invalid_output_flag(self, tmp_config: Path):
        result = runner.invoke(app, ["-o", "invalid", "status", "--job-id", "abc"])
        assert result.exit_code != 0
        assert "--output must be" in result.output


# ---------------------------------------------------------------------------
# 2. status --watch flag
# ---------------------------------------------------------------------------

class TestStatusWatch:
    def test_watch_polls_until_terminal(self, authed_config: tuple):
        """--watch should keep calling get_job_status until a terminal state is reached."""
        pending = {
            "job_id": "job-abc-123",
            "status": "PENDING",
            "priority": 3,
            "submitted_at": "2024-01-01T00:00:00Z",
            "started_at": None,
            "finished_at": None,
            "error": None,
        }
        running = {**pending, "status": "RUNNING", "started_at": "2024-01-01T00:00:01Z"}
        completed = {
            **running,
            "status": "COMPLETED",
            "finished_at": "2024-01-01T00:00:02Z",
        }

        mock_client = _make_client_mock()
        mock_client.get_job_status.side_effect = [pending, running, completed]

        with _patch_client(mock_client), patch("time.sleep"):
            result = runner.invoke(app, ["status", "--job-id", "job-abc-123", "--watch", "--interval", "1"])

        assert result.exit_code == 0, result.output
        assert mock_client.get_job_status.call_count == 3
        assert "COMPLETED" in result.output

    def test_watch_json_exits_on_terminal(self, authed_config: tuple):
        """--watch with -o json should still exit when terminal state reached."""
        completed = {
            "job_id": "job-xyz",
            "status": "COMPLETED",
            "priority": 3,
            "submitted_at": "2024-01-01T00:00:00Z",
            "started_at": "2024-01-01T00:00:01Z",
            "finished_at": "2024-01-01T00:00:02Z",
            "error": None,
        }
        mock_client = _make_client_mock(job_status=completed)

        with _patch_client(mock_client), patch("time.sleep"):
            result = runner.invoke(app, ["-o", "json", "status", "--job-id", "job-xyz", "--watch"])

        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["status"] == "COMPLETED"

    def test_watch_json_multi_poll_outputs_only_once(self, authed_config: tuple):
        """--watch -o json 에서 여러 번 폴링해도 JSON은 terminal 도달 시 한 번만 출력돼야 한다."""
        pending = {
            "job_id": "job-multi",
            "status": "PENDING",
            "priority": 3,
            "submitted_at": "2024-01-01T00:00:00Z",
            "started_at": None,
            "finished_at": None,
            "error": None,
        }
        running = {**pending, "status": "RUNNING", "started_at": "2024-01-01T00:00:01Z"}
        completed = {**running, "status": "COMPLETED", "finished_at": "2024-01-01T00:00:02Z"}

        mock_client = _make_client_mock()
        mock_client.get_job_status.side_effect = [pending, running, completed]

        with _patch_client(mock_client), patch("time.sleep"):
            result = runner.invoke(
                app, ["-o", "json", "status", "--job-id", "job-multi", "--watch", "--interval", "1"]
            )

        assert result.exit_code == 0, result.output
        # 단 하나의 JSON 객체만 출력돼야 함
        data = json.loads(result.output)
        assert data["status"] == "COMPLETED"
        assert mock_client.get_job_status.call_count == 3

    def test_watch_stops_on_failed_state(self, authed_config: tuple):
        """--watch should stop when job reaches FAILED state."""
        failed = {
            "job_id": "job-fail",
            "status": "FAILED",
            "priority": 3,
            "submitted_at": "2024-01-01T00:00:00Z",
            "started_at": "2024-01-01T00:00:01Z",
            "finished_at": "2024-01-01T00:00:05Z",
            "error": "execution error",
        }
        mock_client = _make_client_mock(job_status=failed)

        with _patch_client(mock_client), patch("time.sleep"):
            result = runner.invoke(app, ["status", "--job-id", "job-fail", "--watch"])

        assert result.exit_code == 0, result.output
        assert mock_client.get_job_status.call_count == 1
        assert "FAILED" in result.output


# ---------------------------------------------------------------------------
# 3. submit command
# ---------------------------------------------------------------------------

class TestSubmitCommand:
    def test_missing_shots_returns_error(self, authed_config: tuple):
        """Omitting --shots is a typer/click validation error."""
        mock_client = _make_client_mock()
        with _patch_client(mock_client):
            result = runner.invoke(app, ["submit", "--circuit", "OPENQASM 2.0;"])
        assert result.exit_code != 0

    def test_valid_submit_shows_job_id(self, authed_config: tuple):
        """A valid submit call should display the returned job_id."""
        mock_client = _make_client_mock(job_id="job-new-999")
        with _patch_client(mock_client):
            result = runner.invoke(
                app,
                ["submit", "--circuit", "OPENQASM 2.0;", "--shots", "1000"],
            )
        assert result.exit_code == 0, result.output
        assert "job-new-999" in result.output

    def test_valid_submit_json_output(self, authed_config: tuple):
        """JSON output from a valid submit should contain job_id and success."""
        mock_client = _make_client_mock(job_id="job-json-001")
        with _patch_client(mock_client):
            result = runner.invoke(
                app,
                ["-o", "json", "submit", "--circuit", "OPENQASM 2.0;", "--shots", "500"],
            )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["success"] is True
        assert data["job_id"] == "job-json-001"

    def test_invalid_priority_validation(self, authed_config: tuple):
        """priority outside 1-4 should fail before hitting the server."""
        mock_client = _make_client_mock()
        with _patch_client(mock_client):
            result = runner.invoke(
                app,
                ["submit", "--circuit", "OPENQASM 2.0;", "--shots", "100", "--priority", "9"],
            )
        assert result.exit_code != 0
        assert mock_client.submit_gate_job.call_count == 0

    def test_invalid_optimization_level_validation(self, authed_config: tuple):
        """optimization-level outside 0-3 should fail before hitting the server."""
        mock_client = _make_client_mock()
        with _patch_client(mock_client):
            result = runner.invoke(
                app,
                ["submit", "--circuit", "OPENQASM 2.0;", "--shots", "100", "--optimization-level", "5"],
            )
        assert result.exit_code != 0
        assert mock_client.submit_gate_job.call_count == 0

    def test_submit_calls_client_correctly(self, authed_config: tuple):
        """Verify the client is called with expected arguments."""
        mock_client = _make_client_mock(job_id="job-check")
        with _patch_client(mock_client):
            result = runner.invoke(
                app,
                ["submit", "--circuit", "OPENQASM 2.0;", "--shots", "200", "--priority", "2"],
            )
        assert result.exit_code == 0, result.output
        mock_client.submit_gate_job.assert_called_once()
        call_kwargs = mock_client.submit_gate_job.call_args
        assert call_kwargs.kwargs.get("shots") == 200 or call_kwargs.args[1] == 200


# ---------------------------------------------------------------------------
# 4. login command
# ---------------------------------------------------------------------------

class TestLoginCommand:
    def test_successful_login_saves_tokens(self, tmp_config: Path, mock_qubecore_auth: dict):
        mock_qubecore_auth["login"].return_value = ("access_tok", "refresh_tok")
        result = runner.invoke(
            app,
            ["login", "--username", "alice", "--password", "secret"],
        )
        assert result.exit_code == 0, result.output
        assert "alice" in result.output or "Logged in" in result.output
        saved = json.loads(tmp_config.read_text())
        assert saved["access_token"] == "access_tok"
        assert saved["refresh_token"] == "refresh_tok"

    def test_failed_login_shows_error(self, tmp_config: Path, mock_qubecore_auth: dict):
        mock_qubecore_auth["login"].side_effect = RuntimeError("bad credentials")
        result = runner.invoke(
            app,
            ["login", "--username", "alice", "--password", "wrong"],
        )
        assert result.exit_code != 0
        assert "Login failed" in result.output

    def test_successful_login_json_output(self, tmp_config: Path, mock_qubecore_auth: dict):
        mock_qubecore_auth["login"].return_value = ("tok_a", "tok_r")
        result = runner.invoke(
            app,
            ["-o", "json", "login", "--username", "bob", "--password", "pass"],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["success"] is True
        assert data["username"] == "bob"

    def test_login_grpc_unavailable(self, tmp_config: Path, mock_qubecore_auth: dict):
        """gRPC UNAVAILABLE during login should show a helpful message."""
        err = _make_grpc_error(grpc.StatusCode.UNAVAILABLE, "connection refused")
        mock_qubecore_auth["login"].side_effect = err
        result = runner.invoke(
            app,
            ["login", "--username", "alice", "--password", "secret"],
        )
        assert result.exit_code != 0
        assert "Cannot connect" in result.output or "connect" in result.output.lower()


# ---------------------------------------------------------------------------
# 5. config commands
# ---------------------------------------------------------------------------

class TestConfigCommands:
    def test_config_set_host(self, tmp_config: Path):
        result = runner.invoke(app, ["config", "set", "host", "192.168.1.1:50051"])
        assert result.exit_code == 0, result.output
        assert "saved" in result.output or "192.168.1.1:50051" in result.output
        saved = json.loads(tmp_config.read_text())
        assert saved["host"] == "192.168.1.1:50051"

    def test_config_set_unknown_key_errors(self, tmp_config: Path):
        result = runner.invoke(app, ["config", "set", "unknown_key", "value"])
        assert result.exit_code != 0
        assert "Unknown key" in result.output

    def test_config_get_all_masks_tokens(self, config_with_tokens: Path):
        result = runner.invoke(app, ["config", "get"])
        assert result.exit_code == 0, result.output
        assert "***" in result.output
        # actual token values should NOT appear
        assert "tok_access" not in result.output
        assert "tok_refresh" not in result.output

    def test_config_get_json_masks_tokens(self, config_with_tokens: Path):
        result = runner.invoke(app, ["-o", "json", "config", "get"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["access_token"] == "***"
        assert data["refresh_token"] == "***"
        assert data["host"] == "localhost:50051"

    def test_config_get_specific_key(self, config_with_tokens: Path):
        result = runner.invoke(app, ["config", "get", "host"])
        assert result.exit_code == 0, result.output
        assert "localhost:50051" in result.output

    def test_config_get_empty_config(self, tmp_config: Path):
        result = runner.invoke(app, ["config", "get"])
        assert result.exit_code == 0, result.output
        assert "No config saved" in result.output

    def test_config_unset_removes_key(self, config_with_tokens: Path):
        result = runner.invoke(app, ["config", "unset", "host"])
        assert result.exit_code == 0, result.output
        assert "removed" in result.output or "host" in result.output
        saved = json.loads(config_with_tokens.read_text())
        assert "host" not in saved

    def test_config_unset_missing_key(self, tmp_config: Path):
        result = runner.invoke(app, ["config", "unset", "host"])
        assert result.exit_code == 0, result.output
        assert "not set" in result.output

    def test_config_set_host_json(self, tmp_config: Path):
        result = runner.invoke(app, ["-o", "json", "config", "set", "host", "10.0.0.1:50051"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["success"] is True
        assert data["value"] == "10.0.0.1:50051"

    def test_config_unset_json_output(self, config_with_tokens: Path):
        result = runner.invoke(app, ["-o", "json", "config", "unset", "host"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["success"] is True
        assert data["key"] == "host"


# ---------------------------------------------------------------------------
# 6. jobs command
# ---------------------------------------------------------------------------

class TestJobsCommand:
    def test_jobs_json_output_is_valid_json(self, authed_config: tuple):
        mock_client = _make_client_mock()
        with _patch_client(mock_client):
            result = runner.invoke(app, ["-o", "json", "jobs"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert "total" in data
        assert "jobs" in data

    def test_jobs_text_output_formatted(self, authed_config: tuple):
        mock_client = _make_client_mock()
        with _patch_client(mock_client):
            result = runner.invoke(app, ["jobs"])
        assert result.exit_code == 0, result.output
        # Expect the summary line and at least one job entry
        assert "total" in result.output
        assert "job-abc-123" in result.output

    def test_jobs_empty_list(self, authed_config: tuple):
        mock_client = _make_client_mock(jobs_result={"total": 0, "jobs": []})
        with _patch_client(mock_client):
            result = runner.invoke(app, ["jobs"])
        assert result.exit_code == 0, result.output
        assert "no jobs" in result.output.lower() or "total" in result.output

    def test_jobs_pagination_params(self, authed_config: tuple):
        mock_client = _make_client_mock()
        with _patch_client(mock_client):
            result = runner.invoke(app, ["jobs", "--page", "2", "--size", "5"])
        assert result.exit_code == 0, result.output
        mock_client.get_my_jobs.assert_called_once_with(page=2, page_size=5)

    def test_jobs_json_contains_job_fields(self, authed_config: tuple):
        mock_client = _make_client_mock()
        with _patch_client(mock_client):
            result = runner.invoke(app, ["-o", "json", "jobs"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["total"] == 1
        job = data["jobs"][0]
        assert job["job_id"] == "job-abc-123"
        assert job["status"] == "COMPLETED"


# ---------------------------------------------------------------------------
# 7. cancel command
# ---------------------------------------------------------------------------

class TestCancelCommand:
    def test_cancel_success_shows_message(self, authed_config: tuple):
        mock_client = _make_client_mock(cancel_message="Job cancelled successfully")
        with _patch_client(mock_client):
            result = runner.invoke(app, ["cancel", "--job-id", "job-abc-123"])
        assert result.exit_code == 0, result.output
        assert "cancelled" in result.output.lower() or "Job cancelled" in result.output

    def test_cancel_json_output(self, authed_config: tuple):
        mock_client = _make_client_mock(cancel_message="cancelled ok")
        with _patch_client(mock_client):
            result = runner.invoke(app, ["-o", "json", "cancel", "--job-id", "job-abc-123"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["success"] is True
        assert data["message"] == "cancelled ok"

    def test_cancel_grpc_failure(self, authed_config: tuple):
        """A gRPC error during cancel should print an error and exit non-zero."""
        mock_client = _make_client_mock()
        rpc_error = _make_grpc_error(grpc.StatusCode.NOT_FOUND, "job not found")
        mock_client.cancel_job.side_effect = rpc_error

        with _patch_client(mock_client):
            result = runner.invoke(app, ["cancel", "--job-id", "no-such-job"])
        assert result.exit_code != 0

    def test_cancel_unauthenticated(self, authed_config: tuple):
        """UNAUTHENTICATED gRPC error should hint to re-login."""
        mock_client = _make_client_mock()
        rpc_error = _make_grpc_error(grpc.StatusCode.UNAUTHENTICATED, "unauthenticated")
        mock_client.cancel_job.side_effect = rpc_error

        with _patch_client(mock_client):
            result = runner.invoke(app, ["cancel", "--job-id", "job-abc-123"])
        assert result.exit_code != 0
        assert "login" in result.output.lower() or "Authentication" in result.output


# ---------------------------------------------------------------------------
# 8. Additional edge-case / extra tests
# ---------------------------------------------------------------------------

class TestEdgeCases:
    def test_version_flag(self):
        result = runner.invoke(app, ["-v"])
        assert result.exit_code == 0
        assert result.output.startswith("v")

    def test_logout_not_logged_in(self, tmp_config: Path, mock_qubecore_auth: dict):
        result = runner.invoke(app, ["logout"])
        assert result.exit_code != 0
        assert "Not logged in" in result.output

    def test_logout_clears_tokens(self, config_with_tokens: Path, mock_qubecore_auth: dict):
        mock_qubecore_auth["logout"].return_value = None
        result = runner.invoke(app, ["logout"])
        assert result.exit_code == 0, result.output
        saved = json.loads(config_with_tokens.read_text())
        assert "access_token" not in saved
        assert "refresh_token" not in saved

    def test_status_missing_job_id(self, authed_config: tuple):
        mock_client = _make_client_mock()
        with _patch_client(mock_client):
            result = runner.invoke(app, ["status"])
        assert result.exit_code != 0

    def test_submit_reset_valid(self, authed_config: tuple):
        mock_client = _make_client_mock(job_id="reset-001")
        mock_client.submit_reset_job.return_value = "reset-001"
        with _patch_client(mock_client):
            result = runner.invoke(
                app,
                ["submit-reset", "--qubits", "qubit_0,qubit_1", "--shots", "100"],
            )
        assert result.exit_code == 0, result.output
        assert "reset-001" in result.output

    def test_submit_reset_empty_qubits(self, authed_config: tuple):
        """Empty qubit list should be rejected before calling the server."""
        mock_client = _make_client_mock()
        with _patch_client(mock_client):
            result = runner.invoke(
                app,
                ["submit-reset", "--qubits", "  ", "--shots", "100"],
            )
        assert result.exit_code != 0
        assert mock_client.submit_reset_job.call_count == 0

    def test_status_no_watch_calls_once(self, authed_config: tuple):
        """Without --watch, get_job_status should be called exactly once."""
        mock_client = _make_client_mock()
        with _patch_client(mock_client):
            result = runner.invoke(app, ["status", "--job-id", "job-abc-123"])
        assert result.exit_code == 0, result.output
        assert mock_client.get_job_status.call_count == 1

    def test_token_expired_refresh(self, tmp_path: Path):
        """If access token is expired but refresh token exists, it should refresh."""
        config_file = tmp_path / "config.json"
        config_file.write_text(
            json.dumps(
                {
                    "host": "localhost:50051",
                    "access_token": "expired_tok",
                    "refresh_token": "valid_refresh",
                }
            )
        )
        mock_client = _make_client_mock()
        with (
            patch("qubecli.main._CONFIG_PATH", config_file),
            patch("qubecli.main.is_token_expired", return_value=True),
            patch("qubecli.main.refresh_token", return_value="new_access_tok") as mock_refresh,
            _patch_client(mock_client),
        ):
            result = runner.invoke(app, ["status", "--job-id", "job-abc-123"])
        assert result.exit_code == 0, result.output
        mock_refresh.assert_called_once()
        saved = json.loads(config_file.read_text())
        assert saved["access_token"] == "new_access_tok"

    def test_token_expired_no_refresh_token_exits(self, tmp_path: Path):
        """Expired access token with no refresh token → 'Session expired' exit 1."""
        config_file = tmp_path / "config.json"
        config_file.write_text(
            json.dumps({"host": "localhost:50051", "access_token": "expired_tok"})
        )
        with (
            patch("qubecli.main._CONFIG_PATH", config_file),
            patch("qubecli.main.is_token_expired", return_value=True),
        ):
            result = runner.invoke(app, ["status", "--job-id", "job-abc-123"])
        assert result.exit_code != 0

    def test_token_expired_refresh_fails_exits(self, tmp_path: Path):
        """Expired access token + refresh call raises → 'Session expired' exit 1."""
        config_file = tmp_path / "config.json"
        config_file.write_text(
            json.dumps({
                "host": "localhost:50051",
                "access_token": "expired_tok",
                "refresh_token": "bad_refresh",
            })
        )
        with (
            patch("qubecli.main._CONFIG_PATH", config_file),
            patch("qubecli.main.is_token_expired", return_value=True),
            patch("qubecli.main.refresh_token", side_effect=RuntimeError("expired")),
        ):
            result = runner.invoke(app, ["status", "--job-id", "job-abc-123"])
        assert result.exit_code != 0

    def test_help_command(self):
        result = runner.invoke(app, ["help"])
        assert result.exit_code == 0
        assert "Commands" in result.output
        assert "submit" in result.output.lower()

    def test_no_subcommand_prints_banner(self, tmp_config: Path):
        """Invoking with no subcommand should print the ASCII banner."""
        result = runner.invoke(app, [])
        assert result.exit_code == 0
        # Banner contains the product name
        assert "QUBECORE" in result.output or "QubeCore" in result.output or "SDT" in result.output


# ---------------------------------------------------------------------------
# 9. me command
# ---------------------------------------------------------------------------

class TestMeCommand:
    def _make_me_client(self) -> MagicMock:
        client = _make_client_mock()
        client.get_me.return_value = {
            "user_id": "uid-001",
            "username": "alice",
            "role": "user",
            "created_at": "2024-01-01T00:00:00Z",
        }
        return client

    def test_me_text_output(self, authed_config: tuple):
        mock_client = self._make_me_client()
        with _patch_client(mock_client):
            result = runner.invoke(app, ["me"])
        assert result.exit_code == 0, result.output
        assert "alice" in result.output
        assert "uid-001" in result.output
        assert "user" in result.output
        assert "2024-01-01T00:00:00Z" in result.output

    def test_me_json_output(self, authed_config: tuple):
        mock_client = self._make_me_client()
        with _patch_client(mock_client):
            result = runner.invoke(app, ["-o", "json", "me"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["username"] == "alice"
        assert data["user_id"] == "uid-001"
        assert data["role"] == "user"
        assert data["created_at"] == "2024-01-01T00:00:00Z"


# ---------------------------------------------------------------------------
# 10. submit-pulse command
# ---------------------------------------------------------------------------

class TestSubmitPulseCommand:
    def test_submit_pulse_shows_job_id(self, authed_config: tuple):
        mock_client = _make_client_mock(job_id="pulse-job-001")
        mock_client.submit_pulse_job.return_value = "pulse-job-001"
        with _patch_client(mock_client):
            result = runner.invoke(
                app,
                ["submit-pulse", "--pulse", '{"channel":"ch0"}', "--shots", "512"],
            )
        assert result.exit_code == 0, result.output
        assert "pulse-job-001" in result.output

    def test_submit_pulse_json_output(self, authed_config: tuple):
        mock_client = _make_client_mock(job_id="pulse-json-002")
        mock_client.submit_pulse_job.return_value = "pulse-json-002"
        with _patch_client(mock_client):
            result = runner.invoke(
                app,
                ["-o", "json", "submit-pulse", "--pulse", '{"channel":"ch0"}', "--shots", "256"],
            )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["success"] is True
        assert data["job_id"] == "pulse-json-002"

    def test_submit_pulse_missing_shots_returns_error(self, authed_config: tuple):
        mock_client = _make_client_mock()
        with _patch_client(mock_client):
            result = runner.invoke(app, ["submit-pulse", "--pulse", '{"channel":"ch0"}'])
        assert result.exit_code != 0
        assert mock_client.submit_pulse_job.call_count == 0


# ---------------------------------------------------------------------------
# 11. submit-calibration command
# ---------------------------------------------------------------------------

class TestSubmitCalibrationCommand:
    _VALID_PARAMS = '{"qubit": "qubit_0", "freq_start": 4e9}'

    def test_submit_calibration_shows_job_id(self, authed_config: tuple):
        mock_client = _make_client_mock(job_id="cal-job-001")
        mock_client.submit_calibration_job.return_value = "cal-job-001"
        with _patch_client(mock_client):
            result = runner.invoke(
                app,
                [
                    "submit-calibration",
                    "--calibration-type", "widescan",
                    "--params", self._VALID_PARAMS,
                ],
            )
        assert result.exit_code == 0, result.output
        assert "cal-job-001" in result.output

    def test_submit_calibration_json_output(self, authed_config: tuple):
        mock_client = _make_client_mock(job_id="cal-json-002")
        mock_client.submit_calibration_job.return_value = "cal-json-002"
        with _patch_client(mock_client):
            result = runner.invoke(
                app,
                [
                    "-o", "json",
                    "submit-calibration",
                    "--calibration-type", "punchout",
                    "--params", self._VALID_PARAMS,
                ],
            )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["success"] is True
        assert data["job_id"] == "cal-json-002"
        assert data["calibration_type"] == "punchout"

    def test_submit_calibration_invalid_json_params_exits(self, authed_config: tuple):
        mock_client = _make_client_mock()
        with _patch_client(mock_client):
            result = runner.invoke(
                app,
                [
                    "submit-calibration",
                    "--calibration-type", "widescan",
                    "--params", "not-json",
                ],
            )
        assert result.exit_code != 0
        assert mock_client.submit_calibration_job.call_count == 0

    def test_submit_calibration_params_not_object_exits(self, authed_config: tuple):
        """params JSON must be an object, not an array."""
        mock_client = _make_client_mock()
        with _patch_client(mock_client):
            result = runner.invoke(
                app,
                [
                    "submit-calibration",
                    "--calibration-type", "widescan",
                    "--params", "[1, 2, 3]",
                ],
            )
        assert result.exit_code != 0
        assert mock_client.submit_calibration_job.call_count == 0


# ---------------------------------------------------------------------------
# 12. result command
# ---------------------------------------------------------------------------

class TestResultCommand:
    def _make_result_client(self, status: str = "COMPLETED") -> MagicMock:
        client = _make_client_mock()
        client.get_job_result.return_value = {
            "job_id": "job-res-001",
            "status": status,
            "results": [
                {
                    "counts": {"00": 512, "11": 488},
                    "s11": None,
                    "qubit_mapping": {"q0": "qubit_0"},
                }
            ],
        }
        return client

    def test_result_completed_text_output(self, authed_config: tuple):
        mock_client = self._make_result_client("COMPLETED")
        with _patch_client(mock_client):
            result = runner.invoke(app, ["result", "--job-id", "job-res-001"])
        assert result.exit_code == 0, result.output
        assert "job-res-001" in result.output
        assert "COMPLETED" in result.output
        assert "counts" in result.output

    def test_result_json_output(self, authed_config: tuple):
        mock_client = self._make_result_client("COMPLETED")
        with _patch_client(mock_client):
            result = runner.invoke(app, ["-o", "json", "result", "--job-id", "job-res-001"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["job_id"] == "job-res-001"
        assert data["status"] == "COMPLETED"
        assert "results" in data

    def test_result_pending_status(self, authed_config: tuple):
        mock_client = self._make_result_client("PENDING")
        # Override to return minimal pending result
        mock_client.get_job_result.return_value = {
            "job_id": "job-res-002",
            "status": "PENDING",
            "results": [],
        }
        with _patch_client(mock_client):
            result = runner.invoke(app, ["result", "--job-id", "job-res-002"])
        assert result.exit_code == 0, result.output
        assert "PENDING" in result.output


# ---------------------------------------------------------------------------
# 13. backend-info command
# ---------------------------------------------------------------------------

class TestBackendInfoCommand:
    def _make_backend_client(self) -> MagicMock:
        client = _make_client_mock()
        client.get_backend_info.return_value = {
            "name": "sdt-q5",
            "num_qubits": 5,
            "native_gates": ["X90", "ZX90"],
            "qasm_supported_gates": ["h", "cx", "rz"],
            "coupling_map": [
                {"qubit_a": "qubit_0", "qubit_b": "qubit_1"},
                {"qubit_a": "qubit_1", "qubit_b": "qubit_2"},
            ],
        }
        return client

    def test_backend_info_text_output(self, authed_config: tuple):
        mock_client = self._make_backend_client()
        with _patch_client(mock_client):
            result = runner.invoke(app, ["backend-info"])
        assert result.exit_code == 0, result.output
        assert "sdt-q5" in result.output
        assert "5" in result.output
        assert "X90" in result.output or "native_gates" in result.output

    def test_backend_info_json_output(self, authed_config: tuple):
        mock_client = self._make_backend_client()
        with _patch_client(mock_client):
            result = runner.invoke(app, ["-o", "json", "backend-info"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["name"] == "sdt-q5"
        assert data["num_qubits"] == 5
        assert "native_gates" in data


# ---------------------------------------------------------------------------
# 14. characterization command
# ---------------------------------------------------------------------------

class TestCharacterizationCommand:
    def _make_char_client(self) -> MagicMock:
        client = _make_client_mock()
        client.get_characterization.return_value = {
            "last_calibrated": "2024-06-01T12:00:00Z",
            "qubits": [
                {"index": 0, "t1": 1e-4, "t2": 9e-5, "frequency": 4.85e9},
                {"index": 1, "t1": 1.1e-4, "t2": 8.5e-5, "frequency": 4.92e9},
            ],
        }
        return client

    def test_characterization_text_output(self, authed_config: tuple):
        mock_client = self._make_char_client()
        with _patch_client(mock_client):
            result = runner.invoke(app, ["characterization"])
        assert result.exit_code == 0, result.output
        assert "2024-06-01T12:00:00Z" in result.output
        assert "last_calibrated" in result.output

    def test_characterization_json_output(self, authed_config: tuple):
        mock_client = self._make_char_client()
        with _patch_client(mock_client):
            result = runner.invoke(app, ["-o", "json", "characterization"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["last_calibrated"] == "2024-06-01T12:00:00Z"
        assert len(data["qubits"]) == 2
        assert data["qubits"][0]["index"] == 0


# ---------------------------------------------------------------------------
# 15. update-characterization command
# ---------------------------------------------------------------------------

class TestUpdateCharacterizationCommand:
    _VALID_DATA = json.dumps({
        "last_calibrated": "2024-06-01T12:00:00Z",
        "qubits": [{"index": 0, "t1": 1e-4, "t2": 9e-5, "frequency": 4.85e9}],
    })

    def test_update_characterization_success_message(self, authed_config: tuple):
        mock_client = _make_client_mock()
        mock_client.update_characterization.return_value = "Characterization updated"
        with _patch_client(mock_client):
            result = runner.invoke(app, ["update-characterization", "--data", self._VALID_DATA])
        assert result.exit_code == 0, result.output
        assert "Characterization updated" in result.output

    def test_update_characterization_json_output(self, authed_config: tuple):
        mock_client = _make_client_mock()
        mock_client.update_characterization.return_value = "Characterization updated"
        with _patch_client(mock_client):
            result = runner.invoke(app, ["-o", "json", "update-characterization", "--data", self._VALID_DATA])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["success"] is True
        assert data["message"] == "Characterization updated"

    def test_update_characterization_invalid_json_exits(self, authed_config: tuple):
        mock_client = _make_client_mock()
        with _patch_client(mock_client):
            result = runner.invoke(app, ["update-characterization", "--data", "not-valid-json{"])
        assert result.exit_code != 0
        assert mock_client.update_characterization.call_count == 0


# ---------------------------------------------------------------------------
# 16. update-qchip command
# ---------------------------------------------------------------------------

class TestUpdateQchipCommand:
    _VALID_UPDATES = json.dumps([
        {
            "qubit": "qubit_0",
            "freq": 4.85e9,
            "readfreq": 6.5e9,
            "gates": [{"gate_name": "X90", "amp": 0.5, "twidth": 20e-9}],
        }
    ])

    def test_update_qchip_success_message(self, authed_config: tuple):
        mock_client = _make_client_mock()
        mock_client.update_qchip.return_value = "QChip updated"
        with _patch_client(mock_client):
            result = runner.invoke(app, ["update-qchip", "--updates", self._VALID_UPDATES])
        assert result.exit_code == 0, result.output
        assert "QChip updated" in result.output

    def test_update_qchip_json_output(self, authed_config: tuple):
        mock_client = _make_client_mock()
        mock_client.update_qchip.return_value = "QChip updated"
        with _patch_client(mock_client):
            result = runner.invoke(app, ["-o", "json", "update-qchip", "--updates", self._VALID_UPDATES])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["success"] is True
        assert data["message"] == "QChip updated"

    def test_update_qchip_invalid_json_exits(self, authed_config: tuple):
        mock_client = _make_client_mock()
        with _patch_client(mock_client):
            result = runner.invoke(app, ["update-qchip", "--updates", "{{bad json"])
        assert result.exit_code != 0
        assert mock_client.update_qchip.call_count == 0

    def test_update_qchip_not_list_exits(self, authed_config: tuple):
        """updates must be a JSON array, not an object."""
        mock_client = _make_client_mock()
        with _patch_client(mock_client):
            result = runner.invoke(app, ["update-qchip", "--updates", '{"qubit":"qubit_0"}'])
        assert result.exit_code != 0
        assert mock_client.update_qchip.call_count == 0


# ---------------------------------------------------------------------------
# 17. stream command
# ---------------------------------------------------------------------------

class TestStreamCommand:
    _TEMPLATE = "OPENQASM 2.0; include \"qelib1.inc\"; qreg q[1]; creg c[1]; rx({theta}) q[0]; measure q[0]->c[0];"
    _PARAMS = '[{"theta": 0.0}, {"theta": 1.5707}]'

    def _make_stream_client(self) -> MagicMock:
        client = _make_client_mock()
        client.stream_gate_job.return_value = iter([
            {"counts": {"0": 480, "1": 544}},
            {"counts": {"0": 100, "1": 924}},
        ])
        return client

    def test_stream_text_output(self, authed_config: tuple):
        mock_client = self._make_stream_client()
        with _patch_client(mock_client):
            result = runner.invoke(
                app,
                [
                    "stream",
                    "--template", self._TEMPLATE,
                    "--params", self._PARAMS,
                    "--shots", "1024",
                ],
            )
        assert result.exit_code == 0, result.output
        assert "counts" in result.output

    def test_stream_json_output(self, authed_config: tuple):
        mock_client = self._make_stream_client()
        with _patch_client(mock_client):
            result = runner.invoke(
                app,
                [
                    "-o", "json",
                    "stream",
                    "--template", self._TEMPLATE,
                    "--params", self._PARAMS,
                    "--shots", "1024",
                ],
            )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert isinstance(data, list)
        assert len(data) == 2
        assert "counts" in data[0]

    def test_stream_invalid_params_json_exits(self, authed_config: tuple):
        mock_client = self._make_stream_client()
        with _patch_client(mock_client):
            result = runner.invoke(
                app,
                [
                    "stream",
                    "--template", self._TEMPLATE,
                    "--params", "not-valid-json",
                    "--shots", "1024",
                ],
            )
        assert result.exit_code != 0
        assert mock_client.stream_gate_job.call_count == 0

    def test_stream_params_not_list_exits(self, authed_config: tuple):
        """params must be a JSON array, not an object."""
        mock_client = self._make_stream_client()
        with _patch_client(mock_client):
            result = runner.invoke(
                app,
                [
                    "stream",
                    "--template", self._TEMPLATE,
                    "--params", '{"theta": 0.0}',
                    "--shots", "1024",
                ],
            )
        assert result.exit_code != 0
        assert mock_client.stream_gate_job.call_count == 0

    def test_stream_params_boolean_value_exits(self, authed_config: tuple):
        """params with boolean value must be rejected (proto uses map<string,double>)."""
        mock_client = self._make_stream_client()
        with _patch_client(mock_client):
            result = runner.invoke(
                app,
                [
                    "stream",
                    "--template", self._TEMPLATE,
                    "--params", '[{"theta": true}]',
                    "--shots", "1024",
                ],
            )
        assert result.exit_code != 0
        assert mock_client.stream_gate_job.call_count == 0

    def test_stream_params_string_value_exits(self, authed_config: tuple):
        """params with string value must be rejected (proto uses map<string,double>)."""
        mock_client = self._make_stream_client()
        with _patch_client(mock_client):
            result = runner.invoke(
                app,
                [
                    "stream",
                    "--template", self._TEMPLATE,
                    "--params", '[{"theta": "not-a-number"}]',
                    "--shots", "1024",
                ],
            )
        assert result.exit_code != 0
        assert mock_client.stream_gate_job.call_count == 0
