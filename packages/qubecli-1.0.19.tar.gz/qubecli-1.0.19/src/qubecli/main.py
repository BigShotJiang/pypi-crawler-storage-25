import json
import time
from contextlib import contextmanager
from importlib.metadata import version
from pathlib import Path
from typing import Annotated, Generator

import grpc
import typer
from qubecore_client import (
    QubeClient,
    QChipUpdateDict,
    QubitCharacterizationDict,
    is_token_expired,
    login,
    logout,
    refresh_token,
)

_CONFIG_PATH = Path.home() / ".qubecore" / "config.json"

app = typer.Typer(help="QubeCore CLI — Quantum Computing Operating System", invoke_without_command=True)
config_app = typer.Typer(help="Manage server configuration")
app.add_typer(config_app, name="config")


_address: str = "localhost:50051"
_output: str = "text"


def _load_config() -> dict:
    if _CONFIG_PATH.exists():
        try:
            return json.loads(_CONFIG_PATH.read_text())
        except (json.JSONDecodeError, OSError) as e:
            typer.echo(f"Warning: failed to read config ({e}), using defaults.", err=True)
    return {}


def _save_config(data: dict) -> None:
    _CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    _CONFIG_PATH.write_text(json.dumps(data, indent=2))
    _CONFIG_PATH.chmod(0o600)


def _resolve_address(host: str | None) -> str:
    if host is not None:
        return host
    return _load_config().get("host", "localhost:50051")


def _load_token() -> str:
    """Load access token from config, auto-refreshing if expired. Exits with error if not logged in."""
    cfg = _load_config()
    access_token: str = cfg.get("access_token", "")
    stored_refresh: str = cfg.get("refresh_token", "")

    if not access_token and not stored_refresh:
        typer.echo("Not logged in. Run 'qubecore login' first.", err=True)
        raise typer.Exit(1)

    if is_token_expired(access_token):
        if not stored_refresh:
            typer.echo("Session expired. Run 'qubecore login' again.", err=True)
            raise typer.Exit(1)
        try:
            access_token = refresh_token(_address, stored_refresh)
            cfg["access_token"] = access_token
            _save_config(cfg)
        except RuntimeError:
            typer.echo("Session expired. Run 'qubecore login' again.", err=True)
            raise typer.Exit(1)

    return access_token


@contextmanager
def _get_client(address: str, require_auth: bool = True) -> Generator[QubeClient, None, None]:
    token = _load_token() if require_auth else None
    client = QubeClient(address=address, token=token)
    try:
        yield client
    except grpc.RpcError as e:
        if e.code() == grpc.StatusCode.UNAVAILABLE:
            typer.echo(f"Cannot connect to server: {address}", err=True)
            typer.echo("  Run 'qubecore config set host <host:port>' to update the server address.", err=True)
        elif e.code() == grpc.StatusCode.UNAUTHENTICATED:
            typer.echo("Authentication failed. Run 'qubecore login' again.", err=True)
        elif e.code() == grpc.StatusCode.PERMISSION_DENIED:
            typer.echo(f"Permission denied: {e.details()}", err=True)
        else:
            typer.echo(f"gRPC error: {e.details()}", err=True)
        raise typer.Exit(1)
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)
    finally:
        client.close()


def _out(data: dict | list) -> None:
    """Print data as JSON if --output json, otherwise caller handles text output."""
    if _output == "json":
        typer.echo(json.dumps(data, indent=2))


def _is_json() -> bool:
    return _output == "json"


def _priority_label(priority: int) -> str:
    return {1: "CRITICAL", 2: "HIGH", 3: "NORMAL", 4: "LOW"}.get(priority, str(priority))


def _validate_priority(priority: int | None) -> None:
    if priority is not None and priority not in (1, 2, 3, 4):
        typer.echo("priority must be between 1 and 4.", err=True)
        raise typer.Exit(1)


def _validate_optimization_level(optimization_level: int | None) -> None:
    if optimization_level is not None and optimization_level not in (0, 1, 2, 3):
        typer.echo("optimization-level must be between 0 and 3.", err=True)
        raise typer.Exit(1)


def _normalize_stream_params(params_list: list[dict]) -> list[dict[str, float]]:
    """StreamGateJobRequest.params is map<string,double> in qubecore.proto — coerce numbers, reject invalid types."""
    out: list[dict[str, float]] = []
    for i, p in enumerate(params_list):
        norm: dict[str, float] = {}
        for k, v in p.items():
            if not isinstance(k, str):
                typer.echo(f"params[{i}] keys must be strings (got {type(k).__name__}).", err=True)
                raise typer.Exit(1)
            if isinstance(v, bool) or not isinstance(v, (int, float)):
                typer.echo(
                    f"params[{i}][{k!r}] must be a JSON number "
                    "(StreamGateJob uses map<string,double>; bool/string/object/array are not allowed).",
                    err=True,
                )
                raise typer.Exit(1)
            norm[k] = float(v)
        out.append(norm)
    return out


_ASCII = r"""
   ___  _   _ ____  _____ ____ ___  ____  _____
  / _ \| | | | __ )| ____/ ___/ _ \|  _ \| ____|
 | | | | | | |  _ \|  _|| |  | | | | |_) |  _|
 | |_| | |_| | |_) | |__| |__| |_| |  _ <| |___
  \__\_\\___/|____/|_____\____\___/|_| \_\_____|
"""

_W  = 59


def _line(text: str = "", pad: int = 2) -> str:
    inner = " " * pad + text + " " * pad
    total = _W - 2
    left  = (total - len(inner)) // 2
    right = total - len(inner) - left
    return "│" + " " * left + inner + " " * right + "│"


def _c(s: str, fg: str, bold: bool = False) -> str:
    return typer.style(s, fg=fg, bold=bold)


def _print_banner() -> None:
    ver  = version("qubecli")

    border_top    = _c("┌" + "─" * (_W - 2) + "┐", typer.colors.BRIGHT_BLACK)
    border_bottom = _c("└" + "─" * (_W - 2) + "┘", typer.colors.BRIGHT_BLACK)
    border_sep    = _c("├" + "─" * (_W - 2) + "┤", typer.colors.BRIGHT_BLACK)
    empty         = _c("│" + " " * (_W - 2) + "│", typer.colors.BRIGHT_BLACK)
    pipe          = _c("│", typer.colors.BRIGHT_BLACK)

    typer.echo(border_top)
    typer.echo(empty)
    for art_line in _ASCII.strip("\n").splitlines():
        padding = (_W - 2 - len(art_line)) // 2
        right   = _W - 2 - padding - len(art_line)
        typer.echo(pipe + " " * padding + _c(art_line, typer.colors.CYAN, bold=True) + " " * right + pipe)
    typer.echo(empty)
    tagline = "Quantum Computing Operating System"
    tpad    = (_W - 2 - len(tagline)) // 2
    typer.echo(pipe + " " * tpad + _c(tagline, typer.colors.WHITE, bold=True) + " " * (_W - 2 - tpad - len(tagline)) + pipe)
    company = "by SDT"
    cpad    = (_W - 2 - len(company)) // 2
    typer.echo(pipe + " " * cpad + _c(company, typer.colors.BRIGHT_BLACK) + " " * (_W - 2 - cpad - len(company)) + pipe)
    typer.echo(empty)
    typer.echo(border_sep)
    info = "  " + _c("version", typer.colors.GREEN) + f"  {ver}"
    info_len = 2 + 7 + 2 + len(ver)
    typer.echo(pipe + info + " " * (_W - 2 - info_len) + pipe)
    hint     = "  Run 'qubecore help' to see all available commands"
    typer.echo(pipe + _c(hint + " " * (_W - 2 - len(hint)), typer.colors.BRIGHT_BLACK) + pipe)
    typer.echo(border_bottom)
    typer.echo("")


@app.callback()
def _callback(
    ctx: typer.Context,
    host: Annotated[str | None, typer.Option(help="QubeCore server address (host:port)")] = None,
    ver: Annotated[bool, typer.Option("-v", "--version", help="Print version", is_eager=True)] = False,
    output: Annotated[str, typer.Option("-o", "--output", help="Output format: text or json")] = "text",
) -> None:
    global _address, _output
    if ver:
        typer.echo(f"v{version('qubecli')}")
        raise typer.Exit()
    if output not in ("text", "json"):
        typer.echo("--output must be 'text' or 'json'.", err=True)
        raise typer.Exit(1)
    _address = _resolve_address(host)
    _output = output
    if ctx.invoked_subcommand is None:
        _print_banner()


@app.command("login")
def login_cmd(
    username: Annotated[str | None, typer.Option(help="Username")] = None,
    password: Annotated[str | None, typer.Option(help="Password")] = None,
) -> None:
    """Log in to QubeCore and save credentials"""
    if username is None:
        username = typer.prompt("Username")
    if password is None:
        password = typer.prompt("Password", hide_input=True)

    try:
        access_token, refresh_tok = login(_address, username, password)
    except RuntimeError as e:
        typer.echo(f"Login failed: {e}", err=True)
        raise typer.Exit(1)
    except grpc.RpcError as e:
        if e.code() == grpc.StatusCode.UNAVAILABLE:
            typer.echo(f"Cannot connect to server: {_address}", err=True)
        else:
            typer.echo(f"gRPC error: {e.details()}", err=True)
        raise typer.Exit(1)

    cfg = _load_config()
    cfg["access_token"] = access_token
    cfg["refresh_token"] = refresh_tok
    _save_config(cfg)

    if _is_json():
        typer.echo(json.dumps({"success": True, "username": username}))
    else:
        typer.echo(f"✓ Logged in as {username}")


@app.command("logout")
def logout_cmd() -> None:
    """Log out and remove saved credentials"""
    cfg = _load_config()
    if not cfg.get("access_token") and not cfg.get("refresh_token"):
        typer.echo("Not logged in.", err=True)
        raise typer.Exit(1)
    access_token = cfg.get("access_token", "")
    if access_token:
        try:
            logout(_address, access_token)
        except grpc.RpcError:
            typer.echo("Warning: server logout failed (credentials cleared locally).", err=True)
        except Exception:
            pass
    cfg.pop("access_token", None)
    cfg.pop("refresh_token", None)
    _save_config(cfg)

    if _is_json():
        typer.echo(json.dumps({"success": True}))
    else:
        typer.echo("✓ Logged out")


@app.command()
def me() -> None:
    """Show current user info"""
    with _get_client(_address) as client:
        info = client.get_me()

    if _is_json():
        typer.echo(json.dumps(info, indent=2))
    else:
        typer.echo(f"  user_id    : {info['user_id']}")
        typer.echo(f"  username   : {info['username']}")
        typer.echo(f"  role       : {info['role']}")
        typer.echo(f"  created_at : {info['created_at']}")


@app.command()
def jobs(
    page: Annotated[int, typer.Option(help="Page number (1-based)")] = 1,
    size: Annotated[int, typer.Option(help="Results per page")] = 20,
) -> None:
    """List my jobs"""
    with _get_client(_address) as client:
        result = client.get_my_jobs(page=page, page_size=size)

    if _is_json():
        typer.echo(json.dumps(result, indent=2))
        return

    total = result["total"]
    job_list = result["jobs"]
    typer.echo(f"  total : {total}  (page {page}, size {size})")
    if not job_list:
        typer.echo("  (no jobs)")
        return
    for j in job_list:
        finished = j["finished_at"] or "(running)"
        typer.echo(
            f"  {j['job_id']}  {j['type']:<22}  {j['status']:<10}"
            f"  {_priority_label(j['priority']):<8}  {j['submitted_at']}  {finished}"
        )


@config_app.command("set")
def config_set(
    key: Annotated[str, typer.Argument(help="Config key")],
    value: Annotated[str, typer.Argument(help="Config value")],
) -> None:
    """Save a config value (e.g. qubecore config set host 192.168.1.100:50051)"""
    if key != "host":
        typer.echo(f"Unknown key: {key}. Available: host", err=True)
        raise typer.Exit(1)
    cfg = _load_config()
    cfg[key] = value
    _save_config(cfg)

    if _is_json():
        typer.echo(json.dumps({"success": True, "key": key, "value": value}))
    else:
        typer.echo(f"✓ {key} = {value} saved ({_CONFIG_PATH})")


@config_app.command("get")
def config_get(
    key: Annotated[str | None, typer.Argument(help="Config key (omit to show all)")] = None,
) -> None:
    """Show config value(s)"""
    cfg = _load_config()
    if not cfg:
        if _is_json():
            typer.echo(json.dumps({}))
        else:
            typer.echo("No config saved")
        return

    if _is_json():
        masked = {k: ("***" if k in ("access_token", "refresh_token") else v) for k, v in cfg.items()}
        typer.echo(json.dumps(masked if key is None else {key: masked.get(key)}, indent=2))
    else:
        if key:
            typer.echo(f"  {key} : {cfg.get(key, '(not set)')}")
        else:
            for k, v in cfg.items():
                display_v = "***" if k in ("access_token", "refresh_token") else v
                typer.echo(f"  {k} : {display_v}")


@config_app.command("unset")
def config_unset(
    key: Annotated[str, typer.Argument(help="Config key to remove")],
) -> None:
    """Remove a config value"""
    cfg = _load_config()
    if key not in cfg:
        if _is_json():
            typer.echo(json.dumps({"success": False, "message": f"{key} not set"}))
        else:
            typer.echo(f"  {key} : (not set)")
        return
    del cfg[key]
    _save_config(cfg)

    if _is_json():
        typer.echo(json.dumps({"success": True, "key": key}))
    else:
        typer.echo(f"✓ {key} removed")


@app.command()
def submit(
    circuit: Annotated[str, typer.Option(help="Circuit string (QASM2/QASM3/JSON)")],
    shots: Annotated[int, typer.Option(help="Number of shots")],
    priority: Annotated[int | None, typer.Option(help="Priority 1–4 (default: 3=NORMAL)")] = None,
    optimization_level: Annotated[int | None, typer.Option(help="Transpile optimization level 0–3")] = None,
) -> None:
    """Submit a gate-circuit execution job"""
    _validate_priority(priority)
    _validate_optimization_level(optimization_level)
    with _get_client(_address) as client:
        job_id = client.submit_gate_job(
            gate_circuits=[circuit.replace("\\n", "\n").replace("\\t", "\t")],
            shots=shots,
            priority=priority,
            optimization_level=optimization_level,
        )

    if _is_json():
        typer.echo(json.dumps({"success": True, "job_id": job_id, "priority": priority or 3}))
    else:
        typer.echo("✓ Job submitted")
        typer.echo(f"  job_id   : {job_id}")
        typer.echo(f"  priority : {_priority_label(priority if priority is not None else 3)}")


@app.command("submit-pulse")
def submit_pulse(
    pulse: Annotated[str, typer.Option(help="Pulse program string (backend-specific JSON)")],
    shots: Annotated[int, typer.Option(help="Number of shots")],
    priority: Annotated[int | None, typer.Option(help="Priority 1–4 (default: 3=NORMAL)")] = None,
) -> None:
    """Submit a pulse-program execution job"""
    _validate_priority(priority)
    with _get_client(_address) as client:
        job_id = client.submit_pulse_job(
            pulse_circuits=[pulse],
            shots=shots,
            priority=priority,
        )

    if _is_json():
        typer.echo(json.dumps({"success": True, "job_id": job_id, "priority": priority or 3}))
    else:
        typer.echo("✓ Job submitted")
        typer.echo(f"  job_id   : {job_id}")
        typer.echo(f"  priority : {_priority_label(priority if priority is not None else 3)}")


@app.command("submit-reset")
def submit_reset(
    qubits: Annotated[str, typer.Option(help="Comma-separated qubit names (e.g. qubit_0,qubit_1)")],
    shots: Annotated[int, typer.Option(help="Number of verification shots after reset")],
    priority: Annotated[int | None, typer.Option(help="Priority 1–4 (default: 3=NORMAL)")] = None,
) -> None:
    """Submit a qubit active-reset job"""
    _validate_priority(priority)
    qubit_list = [q.strip() for q in qubits.split(",") if q.strip()]
    if not qubit_list:
        typer.echo("qubits must include at least one non-empty qubit name.", err=True)
        raise typer.Exit(1)
    with _get_client(_address) as client:
        job_id = client.submit_reset_job(
            qubits=qubit_list,
            shots=shots,
            priority=priority,
        )

    if _is_json():
        typer.echo(json.dumps({"success": True, "job_id": job_id, "qubits": qubit_list, "priority": priority or 3}))
    else:
        typer.echo("✓ Job submitted")
        typer.echo(f"  job_id   : {job_id}")
        typer.echo(f"  qubits   : {qubit_list}")
        typer.echo(f"  priority : {_priority_label(priority if priority is not None else 3)}")


@app.command("submit-calibration")
def submit_calibration(
    calibration_type: Annotated[str, typer.Option(help="Calibration type: widescan or punchout")],
    params: Annotated[str, typer.Option(help="Calibration parameters as JSON string")],
    priority: Annotated[int | None, typer.Option(help="Priority 1–4 (default: 3=NORMAL)")] = None,
) -> None:
    """Submit a calibration job"""
    _validate_priority(priority)
    try:
        params_dict = json.loads(params)
    except json.JSONDecodeError as e:
        typer.echo(f"Failed to parse params JSON: {e}", err=True)
        raise typer.Exit(1)
    if not isinstance(params_dict, dict):
        typer.echo("params must be a JSON object.", err=True)
        raise typer.Exit(1)
    with _get_client(_address) as client:
        job_id = client.submit_calibration_job(
            calibration_type=calibration_type,
            params=params_dict,
            priority=priority,
        )

    if _is_json():
        typer.echo(json.dumps({"success": True, "job_id": job_id, "calibration_type": calibration_type, "priority": priority or 3}))
    else:
        typer.echo("✓ Job submitted")
        typer.echo(f"  job_id           : {job_id}")
        typer.echo(f"  calibration_type : {calibration_type}")
        typer.echo(f"  priority         : {_priority_label(priority if priority is not None else 3)}")


@app.command()
def status(
    job_id: Annotated[str, typer.Option(help="Job ID")],
    watch: Annotated[bool, typer.Option("--watch", "-w", help="Poll until job reaches terminal state")] = False,
    interval: Annotated[int, typer.Option(help="Poll interval in seconds (used with --watch)")] = 3,
) -> None:
    """Show job status"""
    _TERMINAL = {"COMPLETED", "FAILED", "CANCELLED"}

    def _print_status(job: dict) -> None:
        if _is_json():
            typer.echo(json.dumps(job, indent=2))
        else:
            typer.echo(f"  job_id    : {job['job_id']}")
            typer.echo(f"  status    : {job['status']}")
            typer.echo(f"  priority  : {_priority_label(job['priority'])}")
            typer.echo(f"  submitted : {job['submitted_at']}")
            typer.echo(f"  started   : {job['started_at'] or '(not started)'}")
            typer.echo(f"  finished  : {job['finished_at'] or '(not finished)'}")
            if job["error"]:
                typer.echo(f"  error     : {job['error']}")

    with _get_client(_address) as client:
        while True:
            try:
                job = client.get_job_status(job_id)
            except ValueError as e:
                typer.echo(f"Error: {e}", err=True)
                raise typer.Exit(1)

            in_terminal = job["status"] in _TERMINAL

            if watch and not _is_json():
                typer.echo(f"\r  {job_id}  {job['status']:<12}", nl=False)
                if in_terminal:
                    typer.echo("")
                    _print_status(job)
            elif not watch or in_terminal:
                # json 모드에서 watch 중이면 terminal 도달 시에만 한 번 출력
                _print_status(job)

            if in_terminal:
                break

            if not watch:
                break

            time.sleep(interval)


@app.command()
def result(
    job_id: Annotated[str, typer.Option(help="Job ID")],
) -> None:
    """Show job result"""
    try:
        with _get_client(_address) as client:
            job = client.get_job_result(job_id)
    except ValueError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)

    if _is_json():
        typer.echo(json.dumps(job, indent=2))
    else:
        typer.echo(f"  job_id : {job['job_id']}")
        typer.echo(f"  status : {job['status']}")
        if "calibration_result" in job:
            typer.echo(f"  calibration_result : {json.dumps(job['calibration_result'], indent=2)}")
        else:
            for i, r in enumerate(job.get("results", [])):
                typer.echo(f"  [circuit {i}] counts        : {r['counts']}")
                if r.get("s11"):
                    typer.echo(f"  [circuit {i}] s11           : {r['s11']}")
                if r.get("qubit_mapping"):
                    typer.echo(f"  [circuit {i}] qubit_mapping : {r['qubit_mapping']}")



@app.command()
def cancel(
    job_id: Annotated[str, typer.Option(help="Job ID")],
) -> None:
    """Cancel a job (only possible while status is PENDING)"""
    with _get_client(_address) as client:
        message = client.cancel_job(job_id)

    if _is_json():
        typer.echo(json.dumps({"success": True, "message": message}))
    else:
        typer.echo(f"✓ {message}")


@app.command("backend-info")
def backend_info() -> None:
    """Show backend info (name, qubits, coupling map, gates)"""
    with _get_client(_address) as client:
        info = client.get_backend_info()

    if _is_json():
        typer.echo(json.dumps(info, indent=2))
    else:
        typer.echo(f"  name                 : {info['name']}")
        typer.echo(f"  num_qubits           : {info['num_qubits']}")
        typer.echo(f"  native_gates         : {info['native_gates']}")
        typer.echo(f"  qasm_supported_gates : {info['qasm_supported_gates']}")
        typer.echo(f"  coupling_map         : {[[p['qubit_a'], p['qubit_b']] for p in info['coupling_map']]}")


@app.command("characterization")
def characterization() -> None:
    """Show qubit characterization (T1, T2, frequency)"""
    with _get_client(_address) as client:
        data = client.get_characterization()

    if _is_json():
        typer.echo(json.dumps(data, indent=2))
    else:
        typer.echo(f"  last_calibrated : {data['last_calibrated']}")
        typer.echo(f"  {'index':<6} {'t1':<12} {'t2':<12} {'frequency'}")
        typer.echo(f"  {'─'*6} {'─'*12} {'─'*12} {'─'*12}")
        for q in data["qubits"]:
            typer.echo(f"  {q['index']:<6} {q['t1']:<12.2e} {q['t2']:<12.2e} {q['frequency']:.4e}")


@app.command("update-characterization")
def update_characterization(
    data: Annotated[str, typer.Option(help='JSON: {"last_calibrated": "...", "qubits": [{"index":0,"t1":1e-4,"t2":9e-5,"frequency":4.85e9},...]}')],
) -> None:
    """Update qubit characterization data (admin only)"""
    try:
        parsed = json.loads(data)
    except json.JSONDecodeError as e:
        typer.echo(f"Failed to parse JSON: {e}", err=True)
        raise typer.Exit(1)
    last_calibrated: str = parsed.get("last_calibrated", "")
    qubits: list[QubitCharacterizationDict] = parsed.get("qubits", [])
    with _get_client(_address) as client:
        message = client.update_characterization(last_calibrated=last_calibrated, qubits=qubits)

    if _is_json():
        typer.echo(json.dumps({"success": True, "message": message}))
    else:
        typer.echo(f"✓ {message}")


@app.command("update-qchip")
def update_qchip(
    updates: Annotated[str, typer.Option(help='JSON array: [{"qubit":"qubit_0","freq":4.85e9,"readfreq":6.5e9,"gates":[{"gate_name":"X90","amp":0.5,"twidth":20e-9}]}]')],
) -> None:
    """Update QChip parameters (admin only)"""
    try:
        parsed: list[QChipUpdateDict] = json.loads(updates)
    except json.JSONDecodeError as e:
        typer.echo(f"Failed to parse JSON: {e}", err=True)
        raise typer.Exit(1)
    if not isinstance(parsed, list):
        typer.echo("updates must be a JSON array.", err=True)
        raise typer.Exit(1)
    with _get_client(_address) as client:
        message = client.update_qchip(parsed)

    if _is_json():
        typer.echo(json.dumps({"success": True, "message": message}))
    else:
        typer.echo(f"✓ {message}")


@app.command()
def stream(
    template: Annotated[str, typer.Option(help="QASM circuit template with {param} placeholders")],
    params: Annotated[str, typer.Option(help='JSON array of parameter dicts, e.g. \'[{"theta": 0.0}, {"theta": 1.57}]\'')],
    shots: Annotated[int, typer.Option(help="Number of shots per iteration")],
    priority: Annotated[int | None, typer.Option(help="Priority 1–4 (default: 3=NORMAL)")] = None,
    optimization_level: Annotated[int | None, typer.Option(help="Transpile optimization level 0–3")] = None,
) -> None:
    """Stream gate-circuit jobs with a parameter sweep (bidirectional streaming)"""
    _validate_priority(priority)
    _validate_optimization_level(optimization_level)
    try:
        params_list = json.loads(params)
    except json.JSONDecodeError as e:
        typer.echo(f"Failed to parse params JSON: {e}", err=True)
        raise typer.Exit(1)
    if not isinstance(params_list, list):
        typer.echo("params must be a JSON array.", err=True)
        raise typer.Exit(1)
    if not all(isinstance(p, dict) for p in params_list):
        typer.echo("Each element of params must be a JSON object.", err=True)
        raise typer.Exit(1)

    params_list = _normalize_stream_params(params_list)
    circuit_template = template.replace("\\n", "\n").replace("\\t", "\t")

    with _get_client(_address) as client:
        if not _is_json():
            typer.echo(f"Streaming {len(params_list)} iteration(s) → shots={shots}")
        try:
            results = []
            for i, res in enumerate(client.stream_gate_job(
                circuit_template=circuit_template,
                params_list=params_list,
                shots=shots,
                priority=priority,
                optimization_level=optimization_level,
            )):
                if _is_json():
                    results.append(res)
                else:
                    typer.echo(f"  [{i + 1}/{len(params_list)}] counts={res['counts']}")
            if _is_json():
                typer.echo(json.dumps(results, indent=2))
        except (RuntimeError, ValueError) as e:
            typer.echo(f"Stream error: {e}", err=True)
            raise typer.Exit(1)


@app.command("help")
def help_cmd() -> None:
    """Show all commands with usage examples"""
    typer.echo("""
Commands
────────────────────────────────────────────────────────────

  Auth
    qubecore login [--username TEXT] [--password TEXT]
    qubecore logout
    qubecore me

  Config
    qubecore config set host <host:port>
    qubecore config get [KEY]
    qubecore config unset <KEY>

  Submit
    qubecore submit --circuit <QASM> --shots <N>
                    [--priority 1-4] [--optimization-level 0-3]

    qubecore submit-pulse --pulse <JSON> --shots <N>
                          [--priority 1-4]

    qubecore submit-reset --qubits <qubit_0,qubit_1,...> --shots <N>
                          [--priority 1-4]

    qubecore submit-calibration --calibration-type <widescan|punchout>
                                --params <JSON> [--priority 1-4]

  Backend
    qubecore backend-info
    qubecore characterization
    qubecore update-characterization --data <JSON>    (admin)
    qubecore update-qchip --updates <JSON>            (admin)

  Job
    qubecore status --job-id <ID>
    qubecore status --job-id <ID> --watch [--interval N]
    qubecore result --job-id <ID>
    qubecore cancel --job-id <ID>
    qubecore jobs [--page N] [--size N]

  Stream
    qubecore stream --template <QASM_WITH_{PARAM}> --params <JSON_ARRAY>
                    --shots <N> [--priority 1-4] [--optimization-level 0-3]

  Global options (before command)
    --host <host:port>       Connect to specific server (one-time)
    --output / -o <format>   Output format: text (default) or json
    --version / -v           Print version

────────────────────────────────────────────────────────────
  Priority  1=CRITICAL  2=HIGH  3=NORMAL(default)  4=LOW
────────────────────────────────────────────────────────────

Examples
    qubecore login --username admin --password Admin1234!
    qubecore submit --circuit 'OPENQASM 2.0; include "qelib1.inc"; qreg q[2]; creg c[2]; h q[0]; cx q[0],q[1]; measure q->c;' --shots 1000
    qubecore status --job-id <ID>
    qubecore status --job-id <ID> --watch
    qubecore status --job-id <ID> --watch --interval 5
    qubecore -o json status --job-id <ID>
    qubecore result --job-id <ID>
    qubecore stream --template 'OPENQASM 2.0; include "qelib1.inc"; qreg q[1]; creg c[1]; rx({theta}) q[0]; measure q[0]->c[0];' --params '[{"theta": 0.0}, {"theta": 1.5707}, {"theta": 3.1415}]' --shots 200
""")


def main() -> None:
    app()


if __name__ == "__main__":
    main()
