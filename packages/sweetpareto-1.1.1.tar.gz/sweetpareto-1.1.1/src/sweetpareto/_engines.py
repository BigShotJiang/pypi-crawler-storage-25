# Copyright Andrew Johnson, 2026
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
import contextlib
import typing

from sweetpareto.py import py_front_indices
from sweetpareto.types import EngineT, SupportedEngineT

cython_front_indices: None | EngineT = None

with contextlib.suppress(ImportError):
    from sweetpareto_cython import cython_front_indices


def engine_factory(engine: typing.Any | SupportedEngineT, /):
    """Factory for determining how the pareto indices should be found.

    Parameters
    ----------
    engine
        If a string, name of the engine to be discovered and used.
        Otherwise, should be a function that can be called like
        ``indices: list[int] = engine(x, y, maxx, maxy)``.
        The integers should be the pareto front
        ``x[indices]`` and ``y[indices]``  that maximizes or minimizes
        ``x`` and ``y`` according to the ``maxx`` and ``maxy`` booleans.

    Returns
    -------
    Callable[[np.ndarray, np.ndarray, bool, bool], list[int]]

    Raises
    ------
    KeyError
        If a string is provided and it cannot be interpreted.
    ImportError
        If you request a supported engine, e.g., ``"cython"`` but you don't have it installed.

    Notes
    -----
    The default engine, ``"python"`` requires no additional installation. It's a compact,
    flexible implementation that finds the pareto front for just about any non-complex numeric
    data type.

    The engine ``"cython"`` uses a Cython-ized implementation. It is likely to be faster than
    the ``"python"`` engine, but only supports ``numpy.float64``. This is _probably_ what you
    have in your data frame and want to plot. If you don't, and you still want to use the
    ``"cython"`` engine, the unsatisfying answers are

    1. Up or down cast your data to ``numpy.float64``, or
    2. Reach out on the Issue Tracker.
    """
    if not isinstance(engine, str):
        return engine
    if engine == "python":
        return py_front_indices
    if engine == "cython":
        if cython_front_indices is not None:
            return cython_front_indices
        raise ImportError("Cython engine not installed")
    msg = f"Engine {engine} is not available. Only  is supported at this time."
    raise KeyError(msg)
