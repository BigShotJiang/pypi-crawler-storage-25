# Copyright Andrew Johnson, 2026
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

import math
import operator
import typing

from sweetpareto.types import VectorT

if typing.TYPE_CHECKING:
    from collections.abc import Iterator


def py_front_indices(x: VectorT, y: VectorT, maxx: bool, maxy: bool, /):
    """Pure python implementation."""
    rows = x.argsort()
    if maxx:
        rows = rows[::-1]
    points: list[int] = []
    # Use the same iterator so when we resume at the next row
    # after the find the first non-nan pair
    riter: Iterator[int] = iter(rows)
    for row in riter:
        if not (math.isnan(x[row]) or math.isnan(y[row])):
            points.append(row)
            break
    else:
        return points
    current_y = y[points[0]]
    check_dominated = operator.gt if maxy else operator.lt
    for ix in riter:
        new_y = y[ix]
        if math.isnan(x[ix]) or math.isnan(new_y):
            continue
        is_dominated = check_dominated(new_y, current_y)
        if is_dominated:
            if x[ix] == x[points[-1]]:
                points.pop()
            current_y = new_y
            points.append(ix)
    return points
