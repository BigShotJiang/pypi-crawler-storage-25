# Chinese_Error
中文报错信息

## 功能
自动将Python原生英文报错转为中文提示
显示报错文件、行数、出错代码
保留完整报错

## 依赖
text-discoloration

## 怎么使用
```python
from Chinese_Error import enable
enable()
