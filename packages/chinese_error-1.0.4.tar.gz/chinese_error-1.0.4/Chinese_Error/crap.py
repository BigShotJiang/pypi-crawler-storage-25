import os
import sys
import traceback



try:
    import text_discoloration as tcd
except ImportError:
    HAS_TCD = False
    class tcd:
        @staticmethod
        def error(text):
            print(f"\033[91m[ERROR] {text}\033[0m")
        @staticmethod
        def success(text):
            print(f"\033[92m[SUCCESS] {text}\033[0m")
        @staticmethod
        def info(text):
            print(f"\033[94m[INFO] {text}\033[0m")
        @staticmethod
        def warn(text):
            print(f"\033[93m[WARNING] {text}\033[0m")
else:
    HAS_TCD = True



err_msg = {
    "NameError": "变量未定义",
    "IndexError": "索引超出范围",
    "SyntaxError": "语法错误",
    "IndentationError": "缩进错误",
    "TypeError": "类型错误",
    "ValueError": "值错误",
    "KeyError": "字典键不存在",
    "AttributeError": "属性不存在",
    "ModuleNotFoundError": "模块未找到",
    "ImportError": "导入失败",
    "FileNotFoundError": "文件不存在",
    "PermissionError": "权限不足",
    "ZeroDivisionError": "除零错误",
    "OverflowError": "数值溢出",
    "RecursionError": "递归深度超限",
    "MemoryError": "内存不足",
    "OSError": "系统错误",
    "RuntimeError": "运行时错误",
    "AssertionError": "断言失败",
    "StopIteration": "迭代终止",
    "UnicodeError": "编码错误",
    "TimeoutError": "超时错误",
    "ConnectionError": "连接错误",
    "TabError": "空格制表符混用",
    "ArithmeticError": "算术运算错误",
    "LookupError": "查找异常基类",
    "BufferError": "缓冲区错误",
    "EOFError": "读取到文件末尾",
    "FloatingPointError": "浮点运算错误",
    "GeneratorExit": "生成器退出",
    "NotImplementedError": "方法未实现",
    "BlockingIOError": "阻塞IO异常",
    "ChildProcessError": "子进程异常",
    "ConnectionAbortedError": "连接已中止",
    "ConnectionRefusedError": "连接被拒绝",
    "ConnectionResetError": "连接被重置",
    "IsADirectoryError": "路径是目录而非文件",
    "NotADirectoryError": "不是有效目录",
    "InterruptedError": "系统调用被中断",
    "ProcessLookupError": "进程不存在",
    "ReferenceError": "弱引用失效",
    "SystemError": "Python内部系统错误",
    "SystemExit": "程序主动退出",
    "UnicodeDecodeError": "解码失败",
    "UnicodeEncodeError": "编码失败",
    "UnicodeTranslateError": "字符转换失败",
    "UnboundLocalError": "局部变量未绑定",
    "BrokenPipeError": "管道破裂异常"
}

original_hook = sys.excepthook
origin_stderr = sys.__stderr__
switch_status = False



def get_all_causes(exc):
    causes = []
    cur = exc.__cause__
    while cur:
        causes.append(cur)
        cur = cur.__cause__
    cur = exc.__context__
    while cur:
        causes.append(cur)
        cur = cur.__context__
    return causes


def custom_handle(typ, val, tb):
    if issubclass(typ, (KeyboardInterrupt, SystemExit)):
        original_hook(typ, val, tb)
        return


    try:
        cause_data = get_all_causes(val)
        if cause_data:
            tcd.error("======== 链式根源异常 ========")
            for c_exc in reversed(cause_data):
                c_type = type(c_exc)
                c_name = c_type.__name__
                tip = err_msg.get(c_name, f"自定义异常[{c_name}]")
                tcd.error(f"根源错误：{tip}")

        exc_name = typ.__name__
        tip = err_msg.get(exc_name, f"自定义异常 {exc_name}")

        info = traceback.extract_tb(tb)
        if not info:
            tcd.error(f"报错原因: {tip}")
            original_hook(typ, val, tb)
            return

        last = info[-1]
        file = last.filename
        line = last.lineno
        code = last.line if last.line else "无代码行"

        tcd.error(f"报错原因: {tip}")
        tcd.error(f"文件: {file} 行数: {line}")
        tcd.error(f"报错代码：{code}\n")
        traceback.print_exception(typ, val, tb)

    except Exception:
        original_hook(typ, val, tb)


def enable():
    global switch_status
    if not switch_status:
        sys.excepthook = custom_handle
        switch_status = True


def disable():
    global switch_status
    if switch_status:
        sys.excepthook = original_hook
        sys.stderr = origin_stderr
        switch_status = False


__all__ = ["enable", "disable"]