from setuptools import setup, find_packages

setup(
    name="Chinese_Error",
    version="1.0.4",
    author="",
    description="中文错误信息提示",
    packages=find_packages(),
    install_requires=[
        "text-discoloration"
    ],
    python_requires=">=3.6"
)
