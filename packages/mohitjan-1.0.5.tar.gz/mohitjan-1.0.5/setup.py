from setuptools import setup, find_packages

setup(
    name='MohitJan',
    version='1.0.5',
    options={'bdist_wheel': {'universal': True}},
    packages=find_packages(),
    install_requires=[
        'click',
        'rich',
    ],
    entry_points={
        'console_scripts': [
            'mohitjan=MohitJan.main:cli',
        ],
    },
    author='Mohit Janbandhu',
    description='Interactive CLI Portfolio for Mohit Janbandhu'
)
