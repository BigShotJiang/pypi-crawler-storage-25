import sys
import difflib
import click
from rich.prompt import Prompt
from rich.text import Text

from MohitJan.utils.path_check import check_and_fix_path

from MohitJan.utils.ascii import print_banner
from MohitJan.utils.formatter import console, clear_screen
from MohitJan.commands.about import display_about
from MohitJan.commands.skills import display_skills
from MohitJan.commands.projects import display_projects
from MohitJan.commands.certifications import display_certifications
from MohitJan.commands.participation import display_participation
from MohitJan.commands.contact import display_contact
from MohitJan.commands.help import display_help
from MohitJan.commands.website import website

COMMANDS = {
    'help': display_help,
    'about': display_about,
    'skills': display_skills,
    'internships_projects': display_projects,
    'certifications': display_certifications,
    'recent_participation': display_participation,
    'contact': display_contact,
    'website': website
}

def print_welcome_text():
    content = Text()
    content.append("A ", style="dim white")
    content.append("Certified Data Scientist", style="bold blue")
    content.append(" by IABAC & NASSCOM\n\n", style="white")
    content.append("Bridging the gap between technology, data and business with advanced analytics, machine learning and AI solutions.\n\n", style="white")
    content.append("|| Software Engineer - Data Scientist - AI/ML/DL Practitioner - Problem Solver ||\n\n", style="bold cyan")
    content.append("Bachelor of Engineering in Information Technology\n", style="white")
    content.append("Masters of Business Administration in Business Analytics\n\n", style="white")
    
    help_instruction = Text("Type '")
    help_instruction.append("help", style="bold blue")
    help_instruction.append("' to explore commands\n")
    
    console.print(content)
    console.print(help_instruction)

@click.command()
def cli():
    """Interactive CLI Portfolio for Mohit Janbandhu"""
    check_and_fix_path()
    clear_screen()
    print_banner()
    print_welcome_text()
    
    while True:
        try:
            cmd_input = Prompt.ask("\n[bold magenta]mohitjan[/] >").strip().lower()
            
            if not cmd_input:
                continue
                
            if cmd_input in ('exit', 'quit'):
                console.print("\n[bold green]Thank you for exploring Mohit Janbandhu CLI Portfolio[/]\n")
                break
                
            if cmd_input == 'clear':
                clear_screen()
                continue
                
            if cmd_input in COMMANDS:
                clear_screen()
                COMMANDS[cmd_input]()
            else:
                matches = difflib.get_close_matches(cmd_input, list(COMMANDS.keys()), n=1, cutoff=0.6)
                if matches:
                    console.print(f"[bold red]Command not found.[/] Did you mean [bold green]'{matches[0]}'[/]?")
                else:
                    console.print("[bold red]Command not found.[/] Type [bold blue]'help'[/] to see available commands.")
                    
        except KeyboardInterrupt:
            console.print("\n\n[bold green]Thank you for exploring Mohit Janbandhu CLI Portfolio[/]\n")
            break
        except EOFError:
            break



if __name__ == "__main__":
    cli()
