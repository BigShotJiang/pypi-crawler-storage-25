import webbrowser
import click

def website():
    """Open portfolio website"""
    
    url = "https://mjanbandhu.github.io/MohitJanbandhu/"
    
    click.echo("Opening portfolio website...")
    webbrowser.open(url)