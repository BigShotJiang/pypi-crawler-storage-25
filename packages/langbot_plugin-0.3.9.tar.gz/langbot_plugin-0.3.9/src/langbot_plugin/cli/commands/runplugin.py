from __future__ import annotations

import asyncio
import dotenv
import os

from langbot_plugin.utils.discover.engine import ComponentDiscoveryEngine
from langbot_plugin.utils.log import configure_process_logging
from langbot_plugin.cli.run.controller import PluginRuntimeController
from langbot_plugin.cli.i18n import cli_print
from langbot_plugin.cli.utils.page_components import (
    discover_plugin_components,
    populate_plugin_pages,
)


async def arun_plugin_process(
    stdio: bool = False, prod_mode: bool = False, plugin_debug_key: str = ""
) -> None:
    # read .env file
    dotenv.load_dotenv(".env")

    # Set plugin debug key from command line argument if provided
    if plugin_debug_key:
        os.environ["PLUGIN_DEBUG_KEY"] = plugin_debug_key

    discovery_engine = ComponentDiscoveryEngine()

    if not os.path.exists("manifest.yaml"):
        cli_print("manifest_not_found")
        return

    plugin_manifest = discovery_engine.load_component_manifest(
        path="manifest.yaml",
        owner="builtin",
        no_save=True,
    )

    if plugin_manifest is None:
        cli_print("manifest_not_found")
        return

    ws_debug_url = ""

    if not stdio:
        ws_debug_url = os.getenv(
            "DEBUG_RUNTIME_WS_URL", os.getenv("RUNTIME_WS_URL", "")
        )
        if ws_debug_url == "":
            cli_print("debug_url_not_set")
            return

    component_manifests = discover_plugin_components(plugin_manifest, discovery_engine)
    populate_plugin_pages(plugin_manifest, component_manifests)

    controller = PluginRuntimeController(
        plugin_manifest,
        component_manifests,
        stdio,
        ws_debug_url,
        prod_mode,
    )

    controller_run_task = asyncio.create_task(controller.run())
    await controller.mount()

    await controller_run_task


def run_plugin_process(
    stdio: bool = False, prod_mode: bool = False, plugin_debug_key: str = ""
) -> None:
    configure_process_logging()

    try:
        asyncio.run(arun_plugin_process(stdio, prod_mode, plugin_debug_key))
    except asyncio.CancelledError:
        cli_print("plugin_process_cancelled")
        return
    except KeyboardInterrupt:
        cli_print("keyboard_interrupt")
        return
