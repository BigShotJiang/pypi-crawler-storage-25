# Changelog

All notable changes to this project will be documented in this file.

Format follows [Keep a Changelog](https://keepachangelog.com/). This project
adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.5.0] - 2026-05-12

### Added

- cultureagent/clients/shared/config.py — single source for ServerConn/Supervisor/Agent/Telemetry/Daemon config dataclasses + all YAML I/O helpers (load/save/add/rename/remove/archive). Per-backend modules subclass Base*Config and override defaults via _SERVER_CLS/_AGENT_CLS/etc. classmethod hooks.

### Changed

- cultureagent/clients/{claude,codex,copilot,acp}/config.py shrunk from 240-303 lines to 41-48 lines each — backend-specific defaults + re-exports only. Total cultureagent/ statement count: 4781 -> 4229 (552 stmts deduplicated).
- sonar-project.properties: cpd.exclusions narrowed from per-backend tree wildcards to the still-duplicated files only (agent_runner.py, supervisor.py, daemon.py, __main__.py, skill/irc_client.py).
- tests/harness/test_all_backends_parity.py: telemetry parity check now unions per-backend dataclass fields with their Base*Config ancestor in shared/config.py.

### Fixed

- #13, #16: ~90% duplicated config.py across the four backends — closes both issues.

## [0.4.4] - 2026-05-12

### Changed

- sonar scan moved into tests.yml (steward pattern) so it runs in the same job that produces coverage.xml — coverage now actually flows to SonarCloud instead of the prior standalone sonarcloud.yml whose scan step was no-opping without SONAR_TOKEN. Fork PRs / repos without the secret still no-op cleanly.

## [0.4.3] - 2026-05-12

### Fixed

- sonarcloud.yml: skip the scan job entirely on fork PRs (job-level if matching publish.yml:test-publish pattern) — no more wasted runner time + green-but-no-scan reports when SONAR_TOKEN is unavailable (Qodo PR #19 bug 1).
- sonarcloud.yml: drop continue-on-error on the pytest step so a missing/empty coverage.xml does not silently produce a degraded Sonar scan (Qodo PR #19 bug 2).

## [0.4.2] - 2026-05-12

### Added

- SonarCloud workflow (.github/workflows/sonarcloud.yml) — runs scan on PR + push to main, gated on SONAR_TOKEN presence; coverage uploaded from pytest --cov-report=xml.
- sonar.python.coverage.reportPaths + sonar.python.version pinned in sonar-project.properties.

## [0.4.1] - 2026-05-12

### Changed

- Resync `.claude/skills/cicd/` from steward 0.12.0 — rebased on `agex pr`; replaces stale local `create-pr-and-wait.sh` / `pr-batch.sh` / `pr-comments.sh` / `wait-and-check.sh` / `poll-readiness.sh` / `_fetch-review-threads.sh` with the new 5-file set (`workflow.sh`, `pr-status.sh`, `pr-reply.sh`, `_resolve-nick.sh`, `portability-lint.sh`). Closes #14.
- Add `.claude/skills/communicate/` vendored from steward 0.12.0 — `agtag`-backed cross-repo issue I/O (`post-issue.sh`, `post-comment.sh`, `fetch-issues.sh`) plus `mesh-message.sh`; signature resolves to `- cultureagent (Claude)` via the `agtag` repo-basename fallback. Closes #15.
- `docs/skill-sources.md` — new provenance ledger covering `cicd`, `communicate`, `version-bump`.
- `CLAUDE.md` — Skills-vendored block + Common-commands table refreshed for the new `workflow.sh` surface (`lint` / `open` / `read` / `reply` / `delta` / `status` / `await`) and the `communicate` verbs.

## [0.4.0] - 2026-05-10

### Changed

- Extracted BaseDaemon + QueuedBaseDaemon to cultureagent/clients/shared/. Per-backend daemons collapse from ~1000 LOC each to ~150-260 LOC subclasses. claude uses BaseDaemon (synchronous mention routing); codex/copilot/acp use QueuedBaseDaemon (FIFO mention queue topology). Net -2210 LOC across daemon surface.
- Codex retains `_META_RESPONSE_RE` + `_clean_relay_lines` + meta-stripping override of `_send_relay_lines`
- ACP retains `_delayed_restart` override (retry-on-failure with `_on_agent_exit(-1)` on retry crash)
- `tests/harness/test_no_per_backend_copy_of_shared_modules.py` guards extended with `base_daemon.py` and `queued_base_daemon.py`
- docs/reference/architecture/shared-vs-cited.md: BaseDaemon + QueuedBaseDaemon added to shared list, per-backend daemon.py reclassified as thin subclass

## [0.3.3] - 2026-05-10

### Changed

- tests/harness/test_attention_config.py, test_record_llm_call.py, test_telemetry_module.py — switched from importorskip(config) reference module to direct import from cultureagent.clients.claude.config (canonical per-backend surface)
- tests/harness/conftest.py — dropped sys.path injection of packages/agent-harness/

## [0.3.2] - 2026-05-10

### Changed

- Extracted Supervisor class + SupervisorVerdict + _format_window from claude/acp supervisors into cultureagent.clients.shared.supervisor
- Codex/copilot supervisors now import SupervisorVerdict from shared (drops their local copy and unifies parse() behavior with claude/acp)

### Fixed

- SupervisorVerdict.parse() with an unknown action no longer preserves the trailing message — codex/copilot now match claude/acp behavior asserted in tests/test_supervisor.py

## [0.3.1] - 2026-05-10

### Changed

- Extracted `__main__.py` boilerplate to `cultureagent.clients.shared.main_runner`
- Extracted `skill/irc_client.py` to `cultureagent.clients.shared.skill_irc_client` (consolidated `_fail_pending` helper)

## [0.3.0] - 2026-05-10

### Added

- cultureagent/clients/{claude,codex,copilot,acp}/* — four backend implementations migrated from culture
- cultureagent/clients/{claude,codex,copilot,acp}/__main__.py — subprocess entry points (codex/copilot/acp are net-new; claude carried over)
- packages/agent-harness/* — citation reference impl moved verbatim from culture
- tests/harness/test_{agent_runner_*,all_backends_parity,daemon_telemetry,no_per_backend_copy_of_shared_modules}.py and tests/test_{supervisor,acp_daemon,codex_daemon,copilot_daemon,daemon,daemon_config,daemon_ipc,agent_runner,skill_client}.py — backend-tier harness tests
- Optional dependencies: backend-claude (claude-agent-sdk, anthropic), backend-copilot (github-copilot-sdk), backend-acp (claude-agent-sdk, anthropic), backend-codex (no extras), all-backends meta
- wheel force-include for 4 backend culture.yaml + 4 backend SKILL.md + reference-impl tree

### Changed

- Migration driver allowlist extended for culture.clients.BACKEND placeholder, culture.cli.agent and culture.config (latter two scoped to test_daemon_config bridge tests)

## [0.2.0] - 2026-05-09

### Added

- cultureagent/clients/shared/* — 9 modules (attention, ipc, irc_transport, message_buffer, rooms, socket_server, telemetry, webhook, webhook_types) migrated from culture
- cultureagent/{aio,pidfile,_constants,constants}.py and cultureagent/{telemetry/{__init__,context,audit,metrics,tracing},protocol/{__init__,message},cli/shared/constants}.py — vendored utility modules from culture (private)
- tests/conftest.py — slim agentirc IRCd server fixture (no culture-side imports) for harness transport tests
- tests/harness/* and tests/test_{irc_transport,irc_transport_tags,message_buffer,socket_server,webhook,webhook}.py — harness unit tests migrated; 5 deferred to 0.3.0 via pytest.importorskip (need backend modules or packages/agent-harness/)
- Runtime deps: pyyaml, agentirc-cli (>=9.6,<10), opentelemetry-{api,sdk,exporter-otlp-proto-grpc,semantic-conventions,instrumentation-aiohttp-server}
- Dev deps: pytest-asyncio, libcst (for migration tooling)
- .claude/skills/cicd/scripts/_migrate_{rewriter,driver}.py + migrate-from-culture.sh — TDD'd migration tooling that copies culture/.../ files into cultureagent/ with import rewrites, telemetry-namespace parity guards, and a JSON receipt

### Changed

- .flake8 ignore set aligned with culture/.flake8 (E303,E402,E501,E741,F401,F541,F811,F841) so migrated harness code lints clean without behavior-altering reformat

## [0.1.2] - 2026-05-09

### Added

- docs/superpowers/plans/2026-05-09-phase-0b-receive-harness.md — Implementation plan for Phase 0b (incremental 0.2.0 + 0.3.0 PRs); paired with docs/superpowers/specs/2026-05-09-phase-0b-receive-harness-design.md

## [0.1.1] - 2026-05-09

### Added

- docs/superpowers/specs/2026-05-09-phase-0b-receive-harness-design.md — Phase 0b design spec receiving the agent harness from culture (issue #3)

## [0.1.0] - 2026-05-09

### Added

- `cultureagent` Python package shape with `[project.scripts]` entry point
  (`uv tool install cultureagent` once published). Version read from package
  metadata via `importlib.metadata`.
- Agent First CLI frame satisfying the [afi-cli](https://github.com/agentculture/afi-cli)
  rubric: `learn`, `learn --json`, `explain [<path>]`, `explain --json`,
  `overview`, `overview --json`, `doctor`. Exit-code policy
  (`0` success / `1` user error / `2` env error), `hint:` remediation
  markers on stderr, no traceback leaks.
- `CultureagentError` dataclass + `_dispatch` wrapper that route every
  failure path through `cli/_output.py`'s structured emit helpers.
- Explain catalog (`cultureagent/explain/catalog.py`) with one entry per
  global verb and a root entry. Future noun groups extend the catalog
  alongside their `_commands/` registration.
- `.github/workflows/tests.yml` — pytest+coverage, lint
  (black/isort/flake8/bandit/markdownlint-cli2), and a PR-only
  `version-check` job that fails when `pyproject.toml`'s version
  matches `main`.
- `.github/workflows/publish.yml` — Trusted Publishing to PyPI on push to
  main and `cultureagent==<version>.dev<run_number>` to TestPyPI on PRs.
  Fork PRs skip the publish step (no OIDC context).
- `.claude/skills/version-bump/` — vendored verbatim from `../steward`.
  Run `python3 .claude/skills/version-bump/scripts/bump.py {patch,minor,major}`
  before opening a PR.
- `.flake8`, `.markdownlint-cli2.yaml`, `[tool.{black,isort,bandit,coverage}]`
  — lint/format conventions copied from `../steward` to keep AgentCulture
  siblings aligned.
- `tests/test_cli.py` — smoke tests for every verb plus an unknown-path
  failure mode.
- `tests/test_self_doctor.py` — acceptance gate that runs `afi cli doctor .`
  in-process when `afi-cli` is available; skipped otherwise so CI without
  `afi-cli` still passes.
- `docs/architecture.md` — outside-in architecture reference: today's
  CLI frame, tomorrow's agent-runtime migration from `../culture`, and
  how cultureagent relates to its sibling repos (culture, afi-cli,
  steward).

### Fixed

- `tests/test_self_doctor.py` — switched `# noqa: S603 — text` to the
  two-hash form (`# noqa: S603  # text`) so SonarPython's S7632
  suppression-syntax check stops flagging it.

### Changed

- `README.md` — extends the one-line stub into an agent-oriented
  orientation paragraph (install, `learn`, pointer to `CLAUDE.md`).
- `CLAUDE.md` — flips the bootstrap rows in the command table to "works"
  and points at the migration playbook for the next PR.
