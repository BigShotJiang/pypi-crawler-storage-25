"""Tests for ``cultureagent.clients.shared.main_runner``.

Cover the CLI argparse paths without actually starting a daemon.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import pytest

from cultureagent.clients.shared import main_runner


@dataclass
class _FakeAgent:
    nick: str = "alice"


@dataclass
class _FakeConfig:
    agents: list = field(default_factory=list)

    def get_agent(self, nick: str):
        for a in self.agents:
            if a.nick == nick:
                return a
        return None


class _FakeDaemon:
    instances: list = []

    def __init__(self, config, agent):
        self.config = config
        self.agent = agent
        type(self).instances.append(self)

    async def start(self) -> None:
        """Test stub — argparse-only tests never reach the daemon path."""

    async def stop(self) -> None:
        """Test stub — symmetric with ``start``."""


def _make_load_config(config: _FakeConfig):
    def load_config(_path: str) -> _FakeConfig:
        return config

    return load_config


def _make_failing_load_config(exc: Exception):
    def load_config(_path: str):
        raise exc

    return load_config


def test_run_main_no_subcommand_prints_help_and_exits_1(monkeypatch, capsys):
    monkeypatch.setattr("sys.argv", ["culture"])
    with pytest.raises(SystemExit) as excinfo:
        main_runner.run_main(_FakeDaemon, _make_load_config(_FakeConfig(agents=[])))
    assert excinfo.value.code == 1
    out = capsys.readouterr().out
    assert "usage:" in out.lower()


def test_run_main_help_exits_zero(monkeypatch):
    monkeypatch.setattr("sys.argv", ["culture", "--help"])
    with pytest.raises(SystemExit) as excinfo:
        main_runner.run_main(_FakeDaemon, _make_load_config(_FakeConfig(agents=[])))
    assert excinfo.value.code == 0


def test_run_main_load_config_oserror_exits_2(monkeypatch, capsys):
    monkeypatch.setattr("sys.argv", ["culture", "start", "alice"])
    with pytest.raises(SystemExit) as excinfo:
        main_runner.run_main(
            _FakeDaemon,
            _make_failing_load_config(FileNotFoundError("missing")),
        )
    assert excinfo.value.code == 2
    err = capsys.readouterr().err
    assert "hint:" in err
    assert "missing" in err


def test_run_main_unknown_nick_exits_1(monkeypatch):
    monkeypatch.setattr("sys.argv", ["culture", "start", "bob"])
    cfg = _FakeConfig(agents=[_FakeAgent(nick="alice")])
    with pytest.raises(SystemExit) as excinfo:
        main_runner.run_main(_FakeDaemon, _make_load_config(cfg))
    assert excinfo.value.code == 1


def test_run_main_no_args_to_start_subparser_exits_1(monkeypatch):
    """`start` with neither nick nor --all prints subparser help and exits 1."""
    monkeypatch.setattr("sys.argv", ["culture", "start"])
    cfg = _FakeConfig(agents=[_FakeAgent(nick="alice")])
    with pytest.raises(SystemExit) as excinfo:
        main_runner.run_main(_FakeDaemon, _make_load_config(cfg))
    assert excinfo.value.code == 1


def test_run_main_all_with_no_agents_exits_1(monkeypatch):
    monkeypatch.setattr("sys.argv", ["culture", "start", "--all"])
    cfg = _FakeConfig(agents=[])
    with pytest.raises(SystemExit) as excinfo:
        main_runner.run_main(_FakeDaemon, _make_load_config(cfg))
    assert excinfo.value.code == 1
