# Public API stability

cultureagent's public surface is the set of imports and subprocess entry
points listed below. Everything else — module internals, helper functions,
test scaffolds, vendored utility modules — is private and may change at any
0.x or 1.x release.

## Stability promise

- All symbols on this page are behavior-stable through the entire 0.x line.
- Breaking changes only at major bumps (0.x → 1.0, 1.x → 2.0).
- Deprecation: a symbol moves to "deprecated" for one minor cycle (warning
  at import) before removal at the next major.
- "Behavior-stable" means: name, signature, and observable behavior.
  Internal refactoring (renaming private helpers, changing internal data
  flow, reorganizing module internals) does not require a major bump.

## Shared tier — Python imports (since 0.2.0)

| Import path                                                     | Stable since |
|-----------------------------------------------------------------|--------------|
| `cultureagent.clients.shared.attention.AttentionTracker`        | 0.2.0        |
| `cultureagent.clients.shared.attention.Band`                    | 0.2.0        |
| `cultureagent.clients.shared.message_buffer.MessageBuffer`      | 0.2.0        |
| `cultureagent.clients.shared.ipc.decode_message`                | 0.2.0        |
| `cultureagent.clients.shared.ipc.encode_message`                | 0.2.0        |
| `cultureagent.clients.shared.ipc.make_request`                  | 0.2.0        |
| `cultureagent.clients.shared.ipc.make_response`                 | 0.2.0        |
| `cultureagent.clients.shared.irc_transport.IRCTransport`        | 0.2.0        |
| `cultureagent.clients.shared.socket_server.SocketServer`        | 0.2.0        |
| `cultureagent.clients.shared.telemetry.init_harness_telemetry`  | 0.2.0        |
| `cultureagent.clients.shared.webhook.AlertEvent`                | 0.2.0        |
| `cultureagent.clients.shared.webhook.WebhookClient`             | 0.2.0        |
| `cultureagent.clients.shared.webhook_types.WebhookConfig`       | 0.2.0        |
| `cultureagent.clients.shared.rooms.parse_room_meta`             | 0.2.0        |

Modules may export additional helpers at the same dotted path; consult
each module's `__all__` (or its absence) at release time. This table is
the contract; anything not listed is not promised stable.

## Per-backend — Python imports (since 0.3.0)

For each backend `B` in `{claude, codex, copilot, acp}`:

| Import path                                              | Stable since | Notes |
|----------------------------------------------------------|--------------|-------|
| `cultureagent.clients.B.config.AgentConfig`              | 0.3.0        | dataclass — fields are part of the contract |
| `cultureagent.clients.B.config.DaemonConfig`             | 0.3.0        | dataclass — top-level config schema |
| `cultureagent.clients.B.config.ServerConnConfig`         | 0.3.0        | dataclass |
| `cultureagent.clients.B.config.SupervisorConfig`         | 0.3.0        | dataclass |
| `cultureagent.clients.B.config.TelemetryConfig`          | 0.3.0        | dataclass — OTEL wiring |
| `cultureagent.clients.B.config.load_config`              | 0.3.0        | parses YAML at the given path |
| `cultureagent.clients.B.config.load_config_or_default`   | 0.3.0        | same, but returns defaults if path missing |
| `cultureagent.clients.B.config.save_config`              | 0.3.0        | round-trips a `DaemonConfig` to disk |
| `cultureagent.clients.B.config.add_agent_to_config`      | 0.3.0        | |
| `cultureagent.clients.B.config.remove_agent`             | 0.3.0        | |
| `cultureagent.clients.B.config.rename_agent`             | 0.3.0        | |
| `cultureagent.clients.B.config.rename_server`            | 0.3.0        | |
| `cultureagent.clients.B.config.sanitize_agent_name`      | 0.3.0        | |
| `cultureagent.clients.B.config.resolve_attention_config` | 0.3.0        | |
| `cultureagent.clients.B.constants.DEFAULT_TURN_TIMEOUT_SECONDS` | 0.3.0  | every backend |
| `cultureagent.clients.claude.config.archive_agent`       | 0.3.0        | claude-only (operator UX) |
| `cultureagent.clients.claude.config.archive_server`      | 0.3.0        | claude-only |
| `cultureagent.clients.claude.config.unarchive_agent`     | 0.3.0        | claude-only |
| `cultureagent.clients.claude.config.unarchive_server`    | 0.3.0        | claude-only |

Per-backend `constants` modules expose additional timeouts (e.g.
`INNER_REQUEST_TIMEOUT_SECONDS` for codex/acp,
`INNER_SDK_TIMEOUT_SECONDS` for copilot,
`STOP_GRACE_SECONDS` for claude). Names that appear in a single backend
are part of that backend's contract only.

## Subprocess entry points (since 0.3.0)

The supported invocation contract for downstream operators:

- `python -m cultureagent.clients.<backend>` — daemon entry per backend.
  Argv: `start [<nick> | --all] [--config PATH]`. Exit codes: `0` clean
  shutdown, `1` config or arg error.
- `python -m cultureagent.clients.<backend>.skill.irc_client` — whisper
  IPC client used by the in-skill `irc-skill` shell-out. Requires
  `CULTURE_NICK` set in the environment.

The four backends produce identical CLI shape (`culture <backend>
agent daemon` argparse tree); see `tests/harness/test_all_backends_parity.py`
for the parity assertions that gate this contract.

## Explicitly NOT public

The following are **private** and may change without major bumps:

- `cultureagent.clients.<backend>.{agent_runner,supervisor,daemon}.*`
  (internals — access only via the subprocess entry points above)
- `cultureagent.clients.<backend>.skill.irc_client.*` (internals; the
  module's `__main__` subprocess shape is the contract, not the symbols)
- `cultureagent.{aio,pidfile,_constants,constants,protocol,telemetry}.*`
  (vendored utility modules; private — may move to an external package
  later)
- `cultureagent.cli.shared.constants.*` (private; supports the AFI CLI
  frame)
<!-- packages/agent-harness/* was the citation-pattern reference impl
through 0.3.2. It was removed in 0.3.3 — the shared modules under
cultureagent/clients/shared/ are now the canonical implementation. -->

- Any test scaffolds (`IRCTestClient`, conftest fixtures)

### Note on `cultureagent.protocol.message.Message`

The `Message` class is vendored from culture's IRCv3 wire-format parser.
It is currently private in cultureagent. The arguably correct long-term
home is `agentirc` (the IRCd package). Tracked as a future move alongside
the agentirc-10.0 cleanup; kept private here so the move doesn't require
a major bump.

## What this means for culture

Culture imports through re-export shims that map old `culture.clients.*`
paths onto the symbols above. Shim mechanics live on culture's side; this
contract just says: if it's listed above, you can rely on it. If it's
not, don't import it.

If you find a symbol you need that isn't listed, file a brief on this
repo in the round-trip protocol shape (see issue
[#3](https://github.com/agentculture/cultureagent/issues/3)) so we can
either promote it to the surface or instruct toward a covered alternative.
