from __future__ import annotations

import datetime
import os
import re

import numpy as np
import rasterio
from rasterio.windows import Window
from pathlib import Path

__all__ = [
    "read_input_file_info",
    "read_time_vector_data",
    "read_file_lists",
    "open_image_data",
    "strip_band_ref",
]

_BAND_REF_RE = re.compile(r"^(.*)::band=(\d+)$")


def _parse_band_ref(path: str) -> tuple[str, int | None]:
    """
    Parse an encoded band reference: "path::band=N".
    Returns (path, band) where band is 1-based, or (path, None) if not encoded.
    """
    m = _BAND_REF_RE.match(path)
    if not m:
        return path, None
    return m.group(1), int(m.group(2))


def _encode_band_ref(path: str, band: int) -> str:
    return f"{path}::band={band}"


def strip_band_ref(path: str) -> str:
    real_path, _ = _parse_band_ref(path)
    return real_path

def _read_stack_band_names(stack_path: str) -> list[str]:
    with rasterio.open(stack_path, "r") as ds:
        names = list(ds.descriptions or [])
        if not names or all(n is None or str(n).strip() == "" for n in names):
            # Fallback: try per-band tags, else use generic names
            names = []
            for i in range(1, ds.count + 1):
                tag_name = ds.tags(i).get("BAND_NAME")
                names.append(tag_name if tag_name else f"band_{i}")
    return [str(n) for n in names]


def read_input_file_info(path_str):
    """
    Read basic input file information without loading data.

    Returns:
        dict with keys:
            - path (Path)
            - suffix (str)
            - input_type (str)
    Raises:
        ValueError if path is invalid or unsupported
    """
    if not path_str:
        raise ValueError("Empty path")

    p = Path(path_str).expanduser().resolve()

    if not p.exists():
        raise ValueError(f"Path not found: {p}")

    suffix = p.suffix.lower()

    if suffix == ".txt":
        input_type = "imagelist"
    elif suffix in (".tif", ".tiff"):
        input_type = "imagestack"
    elif suffix in (".csv", ".xls", ".xlsx"):
        input_type = "table"
    else:
        raise ValueError(f"Unsupported file type: {suffix}")

    return {
        "path": p,
        "suffix": suffix,
        "input_type": input_type,
    }


def read_time_vector_data(lines):
    """
    Extract dates from band names (strings in `lines`).

    Returns:
        tv_yyyymmdd (np.ndarray, dtype=object): [YYYYMMDD or None, ...]
        tv_yyyydoy  (np.ndarray, dtype=object): [YYYYDOY  or None, ...]
        nyear       (int or None): number of years covered (inclusive)
        yrstart     (int or None): first year
        yrend       (int or None): last year
    """
    # Precompile patterns once
    patterns = [
        re.compile(r"(\d{4})(\d{2})(\d{2})"),          # YYYYMMDD
        re.compile(r"(\d{4})(\d{3})"),                 # YYYYDOY
        re.compile(r"(\d{4})[-_](\d{2})[-_](\d{2})"),  # YYYY-MM-DD or YYYY_MM_DD
        re.compile(r"(\d{4})[-_](\d{3})"),             # YYYY-DOY or YYYY_DOY
    ]

    def parse_date(text):
        """Return a datetime.date if a supported pattern is found; else None."""
        for pat in patterns:
            m = pat.search(text)
            if not m:
                continue

            g = m.groups()
            try:
                if len(g) == 3:  # YYYY MM DD
                    year, month, day = map(int, g)
                    return datetime.datetime(year, month, day).date()

                # len(g) == 2: YYYY + DOY
                year = int(g[0])
                doy = int(g[1])
                if 1 <= doy <= 366:  # basic sanity
                    return (datetime.datetime(year, 1, 1) + datetime.timedelta(days=doy - 1)).date()
            except ValueError:
                return None

        return None

    # Build lists aligned to `lines`
    yyyymmdd_list = []
    yyyydoy_list = []

    for name in lines:
        d = parse_date(str(name))
        if d is None:
            yyyymmdd_list.append(None)
            yyyydoy_list.append(None)
        else:
            yyyymmdd_list.append(int(d.strftime("%Y%m%d")))
            yyyydoy_list.append(int(d.strftime("%Y%j")))

    # Preserve missing values so callers can decide whether to retry with a
    # different source string (for example, a full path instead of basename).
    yyyymmdd_dtype = "uint32" if all(v is not None for v in yyyymmdd_list) else object
    yyyydoy_dtype = "uint32" if all(v is not None for v in yyyydoy_list) else object
    tv_yyyymmdd = np.array(yyyymmdd_list, order="F", dtype=yyyymmdd_dtype)
    tv_yyyydoy = np.array(yyyydoy_list, order="F", dtype=yyyydoy_dtype)

    # Compute year stats from valid entries only
    valid_years = [v // 10000 for v in tv_yyyymmdd if v is not None]
    if not valid_years:
        return tv_yyyymmdd, tv_yyyydoy, None, None, None

    yrstart = int(min(valid_years))
    yrend = int(max(valid_years))
    nyear = yrend - yrstart + 1

    return tv_yyyymmdd, tv_yyyydoy, nyear, yrstart, yrend



def _read_time_vector(tlist: str, filepaths: list[str]):
    """Return (timevector, yr, yrstart, yrend) in YYYYDOY format."""
    flist = [os.path.basename(p) for p in filepaths]
    if tlist == "":
        # Prefer compact names, but fall back to full paths when the basename
        # does not contain a parseable date and the directory does.
        tv_yyyymmdd, timevector, yr, yrstart, yrend = read_time_vector_data(flist)
        if any(v is None for v in tv_yyyymmdd):
            lines = [
                filepath if parsed is None else basename
                for filepath, basename, parsed in zip(filepaths, flist, tv_yyyymmdd)
            ]
            tv_yyyymmdd, timevector, yr, yrstart, yrend = read_time_vector_data(lines)
        return timevector, yr, yrstart, yrend
    else:
        with open(tlist, "r") as f:
            lines = f.read().splitlines()

    tv_yyyymmdd, timevector, yr, yrstart, yrend = read_time_vector_data(lines)

    return timevector, yr, yrstart, yrend


def _unique_by_timevector(flist: list[str], qlist: list[str], timevector):
    tv_unique, indices = np.unique(timevector, return_index=True)
    flist2 = [flist[i] for i in indices]
    qlist2 = [qlist[i] for i in indices] if qlist else []
    return tv_unique, flist2, qlist2


def read_file_lists(
    tlist: str, data_list: str, qa_list: str
) -> tuple[np.ndarray, list[str], list[str], int, int, int]:
    qlist: list[str] | str = ""

    data_info = read_input_file_info(data_list)

    if data_info["input_type"] == "imagelist":
        with open(data_list, "r") as f:
            flist = f.read().splitlines()
        timevector, yr, yrstart, yrend = _read_time_vector(tlist, flist)
    elif data_info["input_type"] == "imagestack":
        stack_path = str(data_info["path"])
        band_names = _read_stack_band_names(stack_path)
        if tlist == "":
            lines = band_names
        else:
            with open(tlist, "r") as f:
                lines = f.read().splitlines()
            if len(lines) != len(band_names):
                raise ValueError(
                    f"Time vector length ({len(lines)}) does not match number of bands ({len(band_names)})"
                )
        _, timevector, yr, yrstart, yrend = read_time_vector_data(lines)
        flist = [_encode_band_ref(stack_path, i + 1) for i in range(len(band_names))]
    else:
        raise ValueError(f"Unsupported input type: {data_info['input_type']}")

    if qa_list != "":
        qa_info = read_input_file_info(qa_list)

        if qa_info["input_type"] == "imagelist":
            with open(qa_list, "r") as f:
                qlist = f.read().splitlines()
            if len(flist) != len(qlist):
                raise ValueError("No. of Data and QA are not consistent")
            timevector_q, yr_q, yrstart_q, yrend_q = _read_time_vector("", qlist)
        elif qa_info["input_type"] == "imagestack":
            qa_stack_path = str(qa_info["path"])
            qa_band_names = _read_stack_band_names(qa_stack_path)
            if len(flist) != len(qa_band_names):
                raise ValueError("No. of Data and QA are not consistent")
            qlist = [_encode_band_ref(qa_stack_path, i + 1) for i in range(len(qa_band_names))]
            _, timevector_q, yr_q, yrstart_q, yrend_q = read_time_vector_data(qa_band_names)
        else:
            raise ValueError(f"Unsupported QA input type: {qa_info['input_type']}")

        # Check if timevector and timevector_q are the same, otherwise align QA to data timeline
        if not (len(timevector) == len(timevector_q) and np.array_equal(timevector, timevector_q)):

            # Map QA timestamps -> QA path
            qa_map: dict[float, str] = {float(t): p for t, p in zip(timevector_q, qlist)}

            aligned_qlist: list[str] = []
            missing_times: list[float] = []

            for t in timevector:
                key = float(t)
                if key in qa_map:
                    aligned_qlist.append(qa_map[key])
                else:
                    aligned_qlist.append("")  # placeholder
                    missing_times.append(key)

            if missing_times:
                raise ValueError(
                    "QA list does not cover all data timestamps. Missing QA for "
                    f"{len(missing_times)} timestamps (first 10 shown): {missing_times[:10]}"
                )

            qlist = aligned_qlist

    timevector, flist, qlist = _unique_by_timevector(flist, qlist, timevector)
    return (
        timevector,
        flist,
        (qlist if isinstance(qlist, list) else []),
        yr,
        yrstart,
        yrend,
    )

def open_image_data(
    x_map: int,
    y_map: int,
    x: int,
    y: int,
    data_files: list[str],
    qa_files: list[str],
    lc_file: str | None,
    data_type: str | None,
    layer: int,
):
    """
    Open each raster, read the window immediately, and close it.
    Suitable for local paths or presigned HTTPS URLs.

    NOTE: This does not use rasterio.Env (AWS options blocked in your env).
    """
    z = len(data_files)
    if qa_files and len(qa_files) != z:
        raise ValueError(f"qa_files length ({len(qa_files)}) must match data_files length ({z})")

    win = Window(x_map, y_map, x, y)

    if data_type is None:
        first_path, first_band = _parse_band_ref(data_files[0])
        with rasterio.open(first_path, "r") as ds:
            band = first_band if first_band is not None else layer
            data_type = np.dtype(ds.dtypes[band - 1])
    else:
        data_type = np.dtype(data_type)
        
    # Allocate final outputs
    vi = np.empty((y, x, z), order="F", dtype=data_type)
    qa = np.empty((y, x, z), order="F", dtype=data_type)
    lc = np.empty((y, x), order="F", dtype=np.uint8)

    # 1) VI: open -> read -> close (per file)
    for i, path in enumerate(data_files):
        real_path, band = _parse_band_ref(path)
        band_id = band if band is not None else layer
        with rasterio.open(real_path, "r") as ds:
            # Read returns (y, x) when a single band is selected
            vi[:, :, i] = ds.read(band_id, window=win, out_dtype=vi.dtype)

    # 2) QA: open -> read -> close (per file), or fill with ones
    if not qa_files:
        qa.fill(1)
    else:
        for i, path in enumerate(qa_files):
            real_path, band = _parse_band_ref(path)
            band_id = band if band is not None else 1
            with rasterio.open(real_path, "r") as ds:
                # QA is commonly band 1; change if needed
                qa[:, :, i] = ds.read(band_id, window=win, out_dtype=qa.dtype)
        print('data read')

    # 3) LC: open -> read -> close (once)
    if not lc_file:
        lc.fill(1)
    else:
        with rasterio.open(lc_file, "r") as ds:
            lc[:, :] = ds.read(1, window=win, out_dtype=lc.dtype)
        if lc.dtype != np.uint8:
            lc[:] = lc.astype(np.uint8, copy=False)

    return vi, qa, lc
