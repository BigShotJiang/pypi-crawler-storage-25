"""SHA-256 content hash utility for content-addressed cache keys."""

import hashlib
from pathlib import Path


def sha256_digest(data: bytes) -> str:
    """Return the SHA-256 hex digests of the given bytes.

    Returns a 64-character lowercase hex string.
    """
    return hashlib.sha256(data).hexdigest()


def sha256_digest_file(path: Path) -> str:
    """Return the SHA-256 hex digests of a file's contents.

    Streams the file in 64KB chunks to handle large files efficiently.
    """
    hasher = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(65536)
            if not chunk:
                break
            hasher.update(chunk)
    return hasher.hexdigest()
