"""CLI argument parsing for Code Puppy."""

import argparse

from code_puppy import __version__


def build_parser():
    """Build and return the argument parser."""
    parser = argparse.ArgumentParser(description="Code Puppy - A code generation agent")
    parser.add_argument(
        "--version",
        "-v",
        action="version",
        version=f"{__version__}",
        help="Show version and exit",
    )
    parser.add_argument(
        "--interactive",
        "-i",
        action="store_true",
        help="Run in interactive mode",
    )
    parser.add_argument(
        "--prompt",
        "-p",
        type=str,
        help="Execute a single prompt and exit (no interactive mode)",
    )
    parser.add_argument(
        "--agent",
        "-a",
        type=str,
        help="Specify which agent to use (e.g., --agent code-puppy)",
    )
    parser.add_argument(
        "--model",
        "-m",
        type=str,
        help="Specify which model to use (e.g., --model gpt-5)",
    )
    parser.add_argument(
        "--resume",
        "-r",
        type=str,
        metavar="PATH",
        help=(
            "Resume a saved session from a .json file "
            "(e.g. ~/.code_puppy/contexts/foo.json)"
        ),
    )
    parser.add_argument(
        "--import-legacy-pickle-session",
        action="store_true",
        help=(
            "DANGER: allow loading a legacy .pkl session file "
            "(pickle can execute arbitrary code)"
        ),
    )
    parser.add_argument(
        "command", nargs="*", help="Run a single command (deprecated, use -p instead)"
    )
    return parser
