"""BM25 relevance scorer for memory extraction.

Pure Python implementation — no external dependencies.
Scores text chunks against a project context to identify
which session turns contain useful information.
"""

import math
import re
from collections import Counter


class BM25Scorer:
    """BM25 relevance scoring for text chunks.

    BM25 is a proven information retrieval model that scores
    document relevance against a query based on term frequency,
    inverse document frequency, and document length normalization.

    Formula: score(D,Q) = Σ IDF(qi) * (tf(qi,D) * (k1+1)) / (tf(qi,D) + k1 * (1-b + b*|D|/avgdl))
    """

    def __init__(
        self,
        k1: float = 1.5,
        b: float = 0.75,
        epsilon: float = 0.25,
    ) -> None:
        """Initialize BM25 scorer.

        Args:
            k1: Term frequency saturation parameter (default 1.5).
            b: Length normalization parameter (default 0.75).
            epsilon: IDF floor to avoid zero scores (default 0.25).
        """
        self.k1 = k1
        self.b = b
        self.epsilon = epsilon

    def fit(self, documents: list[str]) -> None:
        """Compute corpus statistics for IDF calculation.

        Args:
            documents: Full document collection (all chunks across all sessions).
        """
        self._doc_count = len(documents)
        # Tokenize and compute document frequencies
        tokenized = [self._tokenize(doc) for doc in documents]
        # Average document length
        self._avgdl = sum(len(tokens) for tokens in tokenized) / max(self._doc_count, 1)

        # Document frequency for each term
        df: Counter[str] = Counter()
        for tokens in tokenized:
            unique_terms = set(tokens)
            for term in unique_terms:
                df[term] += 1

        # IDF: log((N - df + 0.5) / (df + 0.5)) + 1, with epsilon floor
        self._idf: dict[str, float] = {}
        for term, freq in df.items():
            idf = math.log((self._doc_count - freq + 0.5) / (freq + 0.5) + 1.0)
            self._idf[term] = max(idf, self.epsilon)

    def score(self, query: str, document: str) -> float:
        """Score a single document against a query.

        Args:
            query: The query/project context string.
            document: The document/chunk to score.

        Returns:
            BM25 score (higher = more relevant).
        """
        if not hasattr(self, "_idf"):
            raise RuntimeError("Scorer not fitted. Call fit() first.")

        query_tokens = self._tokenize(query)
        doc_tokens = self._tokenize(document)
        doc_len = len(doc_tokens)

        # Term frequencies in document
        tf = Counter(doc_tokens)

        score = 0.0
        for term in query_tokens:
            idf = self._idf.get(term, self.epsilon)
            term_tf = tf.get(term, 0)
            if term_tf == 0:
                continue
            numerator = term_tf * (self.k1 + 1)
            denominator = term_tf + self.k1 * (
                1 - self.b + self.b * doc_len / max(self._avgdl, 1)
            )
            score += idf * numerator / denominator

        return score

    def score_batch(self, query: str, documents: list[str]) -> list[float]:
        """Score multiple documents against a query.

        Args:
            query: The query/project context.
            documents: List of document strings.

        Returns:
            List of scores, one per document.
        """
        return [self.score(query, doc) for doc in documents]

    @staticmethod
    def _tokenize(text: str) -> list[str]:
        """Simple tokenization: lowercase, split on whitespace + punctuation.

        Keeps tokens >= 2 characters to filter noise.
        """
        # Lowercase
        text = text.lower()
        # Split on non-alphanumeric boundaries
        tokens = re.findall(r"[a-z0-9]{2,}", text)
        return tokens


def select_top_chunks(
    chunks: list[str],
    scores: list[float],
    threshold: float | None = None,
    top_n: int | None = None,
    min_keep: int = 3,
) -> list[str]:
    """Select the most relevant chunks.

    Args:
        chunks: List of text chunks.
        scores: Corresponding relevance scores.
        threshold: Minimum score to include (absolute). If None, uses top_n.
        top_n: Number of top chunks to keep. If None, uses threshold.
        min_keep: Always keep at least this many chunks (prevents empty results).

    Returns:
        Selected chunks in original order.
    """
    if not chunks:
        return []

    # Pair chunks with scores and original indices
    indexed = list(enumerate(zip(chunks, scores, strict=False)))

    if threshold is not None:
        # Filter by threshold
        kept = [(i, (c, s)) for i, (c, s) in indexed if s >= threshold]
        if len(kept) < min_keep:
            # Ensure minimum kept: take top by score
            sorted_by_score = sorted(indexed, key=lambda x: x[1][1], reverse=True)
            kept = sorted_by_score[: max(min_keep, min(len(chunks), min_keep))]
    elif top_n is not None:
        sorted_by_score = sorted(indexed, key=lambda x: x[1][1], reverse=True)
        kept = sorted_by_score[: max(top_n, min_keep)]
    else:
        # Default: keep top 30% or at least min_keep
        n = max(min_keep, len(chunks) // 3)
        sorted_by_score = sorted(indexed, key=lambda x: x[1][1], reverse=True)
        kept = sorted_by_score[:n]

    # Return in original order
    kept_sorted = sorted(kept, key=lambda x: x[0])
    return [chunk for _, (chunk, _) in kept_sorted]


def score_chunks_against_context(
    chunks: list[str],
    context: str,
    k1: float = 1.5,
    b: float = 0.75,
) -> list[float]:
    """Convenience: fit scorer on chunks, score them against context.

    Uses chunks as the document corpus and context as the query.
    """
    scorer = BM25Scorer(k1=k1, b=b)
    scorer.fit(chunks)
    return scorer.score_batch(context, chunks)
