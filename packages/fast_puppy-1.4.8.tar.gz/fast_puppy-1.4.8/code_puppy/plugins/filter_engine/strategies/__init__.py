"""Compression strategies for the filter engine."""
