"""AST-aware code compressors for Python, JavaScript, and Go.

Keeps semantic essentials (signatures, imports, error paths), drops
bodies, docstrings, and whitespace.
"""

import logging
from typing import Any

from code_puppy.plugins.filter_engine.strategies.ast_parser import (
    ASTNode,
    CodeLanguage,
    LanguageParser,
)
from code_puppy.plugins.filter_engine.verbosity import VerbosityLevel

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Node importance classification
# ---------------------------------------------------------------------------

# Python node types to KEEP (structural/signature)
PYTHON_KEEP_TYPES: set[str] = {
    "function_definition",
    "class_definition",
    "import_statement",
    "import_from_statement",
    "try_statement",
    "except_clause",
    "raise_statement",
    "return_statement",
    "decorated_definition",
    "parameters",
    "lambda",
}

# JavaScript/TypeScript node types to KEEP
JS_KEEP_TYPES: set[str] = {
    "function_declaration",
    "method_definition",
    "class_declaration",
    "export_statement",
    "import_statement",
    "try_statement",
    "catch_clause",
    "throw_statement",
    "return_statement",
    "arrow_function",
    "variable_declarator",
    "lexical_declaration",
    "interface_declaration",
    "type_alias_declaration",
}

# Go node types to KEEP
GO_KEEP_TYPES: set[str] = {
    "function_declaration",
    "method_declaration",
    "type_declaration",
    "import_declaration",
    "return_statement",
    "if_statement",
    "for_statement",
    "call_expression",
}


# ---------------------------------------------------------------------------
# Line-collection helpers
# ---------------------------------------------------------------------------


def _collect_lines(
    source: str,
    ast: ASTNode,
    keep_types: set[str],
    level: int,
    extra_handler: Any | None = None,
) -> set[int]:
    """Walk an AST and collect line numbers to keep."""
    lines = source.split("\n")
    kept_lines: set[int] = set()

    def _walk(node: ASTNode, depth: int = 0) -> None:
        node_type = node.type
        start_line = source[: node.start_byte].count("\n")
        end_line = source[: node.end_byte].count("\n")

        if node_type in keep_types:
            for i in range(start_line, min(end_line + 1, len(lines))):
                if node_type == "function_definition" and i == start_line:
                    kept_lines.add(i)
                    if level >= 3:
                        for j in range(start_line + 1, min(start_line + 4, len(lines))):
                            kept_lines.add(j)
                    elif level >= 1:
                        kept_lines.add(start_line + 1)
                    break
                elif node_type in ("class_definition", "decorated_definition"):
                    kept_lines.add(i)
                    if level >= 2:
                        for j in range(start_line + 1, min(start_line + 3, len(lines))):
                            kept_lines.add(j)
                    break
                elif (
                    node_type in ("import_statement", "import_from_statement")
                    or node_type == "try_statement"
                    or node_type == "except_clause"
                    or node_type == "raise_statement"
                    or node_type == "return_statement"
                ):
                    kept_lines.add(i)
                else:
                    kept_lines.add(i)

        if extra_handler is not None:
            extra_handler(node, start_line, end_line, kept_lines, lines, level)

        for child in node.children:
            _walk(child, depth + 1)

    _walk(ast)
    return kept_lines


def _build_output(source: str, kept_lines: set[int], comment_prefix: str = "#") -> str:
    """Build compressed output from kept line numbers."""
    lines = source.split("\n")
    if not kept_lines:
        return source[:200] + "..." if len(source) > 200 else source

    result_lines: list[str] = []
    last_kept = -1
    for i in sorted(kept_lines):
        if i >= len(lines):
            continue
        if last_kept >= 0 and i > last_kept + 1:
            gap = i - last_kept - 1
            result_lines.append(f"{comment_prefix} ... {gap} lines omitted ...")
        result_lines.append(lines[i])
        last_kept = i

    if last_kept < len(lines) - 1:
        remaining = len(lines) - 1 - last_kept
        if remaining > 1:
            result_lines.append(f"{comment_prefix} ... {remaining} lines omitted ...")
        elif remaining == 1:
            result_lines.append(lines[-1])

    return "\n".join(result_lines)


# ---------------------------------------------------------------------------
# Compressors
# ---------------------------------------------------------------------------


def compress_python(
    source: str, verbosity: VerbosityLevel | int = VerbosityLevel.COMPACT
) -> str:
    """Compress Python source code — keep signatures, drop bodies.

    Args:
        source: Python source code string.
        verbosity: 0 = signatures only, 4 = keep brief bodies.

    Returns:
        Compressed Python code.
    """
    level = verbosity.value if isinstance(verbosity, VerbosityLevel) else verbosity

    ast = LanguageParser.parse(source, CodeLanguage.PYTHON)
    if ast is None:
        return _fallback_compress(source)

    kept_lines = _collect_lines(source, ast, PYTHON_KEEP_TYPES, level)
    return _build_output(source, kept_lines, comment_prefix="#")


def compress_javascript(
    source: str, verbosity: VerbosityLevel | int = VerbosityLevel.COMPACT
) -> str:
    """Compress JavaScript/TypeScript — keep signatures, drop bodies."""
    level = verbosity.value if isinstance(verbosity, VerbosityLevel) else verbosity

    lang = LanguageParser.detect_language(source)
    ast = LanguageParser.parse(source, lang)
    if ast is None:
        return _fallback_compress(source)

    lines = source.split("\n")
    kept_lines: set[int] = set()

    def _walk(node: ASTNode, depth: int = 0) -> None:
        start_line = source[: node.start_byte].count("\n")

        if node.type in JS_KEEP_TYPES:
            for i in range(start_line, min(start_line + 1, len(lines))):
                kept_lines.add(i)
            if level >= 3:
                for j in range(start_line + 1, min(start_line + 3, len(lines))):
                    kept_lines.add(j)

        for child in node.children:
            _walk(child, depth + 1)

    _walk(ast)
    return _build_output(source, kept_lines, comment_prefix="//")


def compress_go(
    source: str, verbosity: VerbosityLevel | int = VerbosityLevel.COMPACT
) -> str:
    """Compress Go source — keep func/method/type signatures, drop bodies."""
    level = verbosity.value if isinstance(verbosity, VerbosityLevel) else verbosity

    ast = LanguageParser.parse(source, CodeLanguage.GO)
    if ast is None:
        return _fallback_compress(source)

    kept_lines: set[int] = set()

    def _extra_handler(
        node: ASTNode,
        start_line: int,
        end_line: int,
        kept: set[int],
        lines: list[str],
        level: int,
    ) -> None:
        if node.type in ("function_declaration", "method_declaration"):
            for i in range(start_line, min(start_line + 2, len(lines))):
                kept.add(i)
            for i in range(start_line, min(end_line + 1, len(lines))):
                if "{" in lines[i]:
                    kept.add(i)
                    break
        if level >= 3:
            for j in range(start_line + 1, min(start_line + 4, len(lines))):
                kept.add(j)

    kept_lines = _collect_lines(
        source, ast, GO_KEEP_TYPES, level, extra_handler=_extra_handler
    )
    return _build_output(source, kept_lines, comment_prefix="//")


def _fallback_compress(source: str) -> str:
    """Fallback: strip comments when AST parsing fails."""
    lines = source.split("\n")
    result: list[str] = []
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("#") or stripped.startswith("//"):
            continue
        if "#" in line and not line.startswith("#"):
            line = line[: line.index("#")].rstrip()
        if "//" in line and not line.startswith("//"):
            line = line[: line.index("//")].rstrip()
        result.append(line)
    return "\n".join(result)


def compress_ast_code(
    source: str,
    language: CodeLanguage | None = None,
    verbosity: VerbosityLevel | int = VerbosityLevel.COMPACT,
    filename: str | None = None,
) -> str:
    """Compress source code using the appropriate language compressor.

    Args:
        source: Source code string.
        language: Optional pre-detected language.
        verbosity: Compression level.
        filename: Optional filename for language detection.

    Returns:
        Compressed source code.
    """
    if language is None and filename:
        language = LanguageParser.detect_language(source, filename)
    elif language is None:
        language = LanguageParser.detect_language(source)

    compressors = {
        CodeLanguage.PYTHON: compress_python,
        CodeLanguage.JAVASCRIPT: compress_javascript,
        CodeLanguage.TYPESCRIPT: compress_javascript,
        CodeLanguage.GO: compress_go,
    }

    compressor = compressors.get(language)
    if compressor:
        return compressor(source, verbosity)

    return _fallback_compress(source)
