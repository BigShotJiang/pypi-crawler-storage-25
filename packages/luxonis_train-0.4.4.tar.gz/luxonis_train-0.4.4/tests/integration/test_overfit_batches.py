from collections.abc import Generator

import pytest
import torch
from luxonis_ml.data import LuxonisDataset
from luxonis_ml.typing import Params

from luxonis_train.core import LuxonisModel


@pytest.fixture(autouse=True)
def reset_deterministic_state() -> Generator[None]:
    """Reset PyTorch deterministic state after test.

    Setting a seed auto-enables deterministic mode, which is global
    state that would otherwise leak into the next performed tests.
    """
    yield
    torch.use_deterministic_algorithms(False)


def test_overfit_batches_training(
    parking_lot_dataset: LuxonisDataset, opts: Params
):
    """Smoke test for overfit_batches passed."""
    cfg = "configs/detection_light_model.yaml"
    opts |= {
        "model.predefined_model.params.task_name": "vehicles",
        "loader.params.dataset_name": parking_lot_dataset.identifier,
        "loader.train_view": "train",
        "loader.val_view": "train",
        "loader.test_view": "train",
        "trainer.overfit_batches": 1,
        "trainer.seed": 42,
        "trainer.deterministic": "warn",
        "trainer.epochs": 1,
    }
    model = LuxonisModel(cfg, opts)

    assert model.cfg.trainer.overfit_batches == 1
    # Ignore because PyTorch Lightning's type stubs don't expose
    # overfit_batches as a public attribute on the Trainer class
    assert model.pl_trainer.overfit_batches == 1  # type: ignore[attr-defined]

    model.train()
