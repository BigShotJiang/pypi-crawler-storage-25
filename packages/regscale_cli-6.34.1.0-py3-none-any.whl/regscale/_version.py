"""Version information for regscale-cli."""

from pathlib import Path


def get_version_from_metadata() -> str:
    """
    Extract version from package metadata.

    Reads directly from pyproject.toml first to ensure bumped versions
    are reflected immediately without requiring reinstall. Falls back
    to installed package metadata, then a hardcoded fallback.

    :return: Version string from package metadata or fallback
    :rtype: str
    """
    # Try reading directly from pyproject.toml (always reflects latest bump)
    try:
        import re

        pyproject_path = Path(__file__).parent.parent / "pyproject.toml"
        if pyproject_path.is_file():
            content = pyproject_path.read_text()
            match = re.search(r'version\s*=\s*["\']([^"\']+)["\']', content)
            if match:
                return match.group(1)
    except Exception:
        pass

    # Fall back to installed package metadata
    try:
        from importlib.metadata import version

        return version("regscale-cli")
    except Exception:
        pass

    return "0.0.0"  # fallback version - pyproject.toml or package metadata should always resolve first


__version__ = get_version_from_metadata()
