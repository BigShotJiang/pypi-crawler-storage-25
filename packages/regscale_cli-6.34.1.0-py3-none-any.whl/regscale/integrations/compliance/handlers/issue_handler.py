#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Compliance Issue Handler

Extracts issue processing methods from ComplianceIntegration into a dedicated handler class.
This handler manages issue creation, updating, milestone creation, and finding-to-issue conversion
for compliance integrations.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, List, Optional

from regscale.integrations.scanner_integration import IntegrationFinding
from regscale.integrations.variables import get_vulnerability_creation_mode
from regscale.models import regscale_models

if TYPE_CHECKING:
    from regscale.integrations.compliance_integration import ComplianceIntegration

logger = logging.getLogger("regscale")


class ComplianceIssueHandler:
    """Handler for issue processing in compliance integrations.

    Receives the ComplianceIntegration instance and reads/writes its attributes directly.
    """

    def __init__(self, integration: "ComplianceIntegration") -> None:
        self._integration = integration

    def log_sample_finding(self, findings: list) -> None:
        """Log a sample finding for debugging purposes."""
        if findings:
            sample = findings[0]
            logger.debug(
                f"Sample finding: title='{sample.title}', control_labels={sample.control_labels}, "
                f"affected_controls='{sample.affected_controls}', external_id='{sample.external_id}'"
            )
        elif self._integration.create_issues:
            logger.debug("No findings were returned by fetch_findings()")

    def create_pending_issues_individually(self) -> tuple[int, list]:
        """Create pending issues via IssueHandler batch submission."""
        pending_count = self._integration._issue_handler.get_pending_count()
        logger.info(f"Creating {pending_count} pending new issues individually...")

        if pending_count == 0:
            return 0, []

        try:
            created_issues = self._integration._issue_handler.flush_batch()
            created_count = len(created_issues) if created_issues else 0
            return created_count, []
        except Exception as e:
            logger.error(f"Failed to submit pending issues: {e}")
            return 0, [{"title": "batch", "error": str(e)}]

    def log_creation_failures(self, failed_issues: list, created_count: int, pending_count: int) -> None:
        """Log summary of issue creation failures."""
        failed_count = len(failed_issues)
        success_rate = (created_count / pending_count * 100) if pending_count > 0 else 0

        logger.warning(
            "Issue creation completed with failures: %d/%d succeeded (%.1f%%). Failed issues: %d",
            created_count,
            pending_count,
            success_rate,
            failed_count,
        )

        # Log first 3 failures
        sample_failures = failed_issues[:3]
        for idx, failure in enumerate(sample_failures, 1):
            logger.warning(
                "  Failed issue %d: '%s' - Error: %s",
                idx,
                failure["title"][:80],
                failure["error"][:200],
            )

        if failed_count > 3:
            logger.warning("  ... and %d more failures (check logs for details)", failed_count - 3)

    def sync_issues(self) -> None:
        """
        Process and sync issues from failed compliance items.

        :return: None
        :rtype: None
        """
        if not self._integration.create_issues:
            logger.info("Issue creation disabled (create_issues=False), skipping issue sync")
            return

        # Check vulnerabilityCreation setting — keep NoIssue as default behavior
        vuln_creation = get_vulnerability_creation_mode()
        if vuln_creation.lower() == "noissue":
            logger.info(
                "Issue creation from failed assessments is turned off (vulnerabilityCreation=%s)",
                vuln_creation,
            )
            return

        logger.debug("Fetching findings from failed compliance items...")
        findings = list(self._integration.fetch_findings())
        logger.info(f"Fetched {len(findings)} finding(s) to process into issues")

        self._integration._log_sample_finding(findings)

        if not findings:
            logger.info("No findings to process into issues (all findings returned None or list is empty)")
            return

        # Ensure asset map is populated before processing issues
        if not self._integration.asset_map_by_identifier:
            logger.debug("Loading asset map before issue processing...")
            self._integration.asset_map_by_identifier.update(self._integration.get_asset_map())

        findings_processed, findings_skipped = self._integration._process_findings_to_issues(findings)
        logger.debug(f"Findings processed={findings_processed}, skipped={findings_skipped}")

        # Create new issues individually
        created_count, failed_issues = self._integration._create_pending_issues_individually()

        # Validate and log failures
        failed_count = len(failed_issues)
        pending_count = created_count + len(failed_issues)

        if failed_count > 0:
            self._integration._log_creation_failures(failed_issues, created_count, pending_count)

            # Raise exception if ALL creations failed
            if created_count == 0 and pending_count > 0:
                raise RuntimeError(
                    f"Failed to create any issues ({pending_count} attempts, 0 successes). "
                    "Check API connectivity and credentials."
                )
        elif pending_count > 0:
            logger.info(f"Issue creation completed successfully - created: {created_count}/{pending_count}")

        update_results = regscale_models.Issue.bulk_save()
        logger.debug(f"Bulk save completed - updated: {update_results.get('updated_count', 0)}")

        # Combine and store results
        issue_results = {
            "created_count": created_count,
            "updated_count": update_results.get("updated_count", 0),
        }

        if hasattr(self._integration, "_results"):
            if "issues" not in self._integration._results:
                self._integration._results["issues"] = {}
            self._integration._results["issues"].update(issue_results)

        # Log final results
        issues_created = issue_results.get("created_count", 0)
        issues_updated = issue_results.get("updated_count", 0)
        self._integration._log_issue_results_accurate(
            issues_created, issues_updated, findings_processed, findings_skipped
        )

        # Validate end-to-end consistency
        self._integration._validate_issue_creation_e2e(findings_processed, issues_created)

    def validate_issue_creation_e2e(self, findings_processed: int, issues_created: int) -> None:
        """
        Validate end-to-end issue creation consistency.

        Compares expected findings count with actual issues created to detect:
        - Silent failures during finding-to-issue conversion
        - API rejections that don't raise exceptions
        - Deduplication or filtering that wasn't logged

        :param int findings_processed: Number of findings processed into issues
        :param int issues_created: Number of issues actually created in RegScale
        :return: None
        """
        expected_count = getattr(self._integration, "_expected_findings_count", None)

        if expected_count is None:
            logger.debug("No expected findings count available for validation")
            return

        # Calculate discrepancies
        finding_gap = expected_count - findings_processed
        creation_gap = findings_processed - issues_created
        total_gap = expected_count - issues_created

        # Scenario 1: Perfect match (ideal case)
        if total_gap == 0:
            logger.info(
                "[PASS] Issue creation validation PASSED: Expected %d, Processed %d, Created %d",
                expected_count,
                findings_processed,
                issues_created,
            )
            return

        # Scenario 2: Some findings didn't convert to issues
        if finding_gap > 0 and creation_gap == 0:
            logger.warning(
                "[WARN] %d failed compliance items did not convert to findings (%d expected, %d processed). "
                "Check create_finding_from_compliance_item() for None returns.",
                finding_gap,
                expected_count,
                findings_processed,
            )

        # Scenario 3: Findings processed but issues not created (API failure)
        elif finding_gap == 0 and creation_gap > 0:
            logger.error(
                "[FAIL] Issue creation validation FAILED: %d findings processed but only %d issues created "
                "(%d missing). Check API logs for creation failures or silent rejections.",
                findings_processed,
                issues_created,
                creation_gap,
            )

        # Scenario 4: Both stages had failures
        elif finding_gap > 0 and creation_gap > 0:
            logger.error(
                "[FAIL] Issue creation validation FAILED: Expected %d -> Processed %d (-%d) -> Created %d (-%d). "
                "Total missing: %d issues. Check both finding conversion and API creation logs.",
                expected_count,
                findings_processed,
                finding_gap,
                issues_created,
                creation_gap,
                total_gap,
            )

        # Scenario 5: More created than expected
        else:
            logger.warning(
                "[WARN] Created more issues (%d) than expected (%d). May indicate duplicate processing or retries.",
                issues_created,
                expected_count,
            )

    def process_findings_to_issues(self, findings: List[IntegrationFinding]) -> tuple[int, int]:
        """
        Process findings into issues and return counts.

        :param findings: List of findings to process
        :return: Tuple of (issues_created, issues_skipped)
        """
        issues_created = 0
        issues_skipped = 0
        filtered_by_control = 0
        matched_ids = getattr(self._integration, "_matched_control_ids", None)

        logger.info(f"[TRACE] Processing {len(findings)} findings into issues...")
        for i, finding in enumerate(findings):
            try:
                logger.info(
                    f"[TRACE] Processing finding {i + 1}/{len(findings)}: external_id='{finding.external_id}', asset_identifier='{finding.asset_identifier}'"
                )
                # Track control-filtered findings separately for summary
                if matched_ids and not self._integration._finding_has_matching_control(finding):
                    filtered_by_control += 1
                    issues_skipped += 1
                    logger.info(f"[TRACE]   -> Finding {i + 1} skipped (no matching SSP control)")
                    continue
                if self._integration._process_single_finding(finding):
                    issues_created += 1
                    logger.info(f"[TRACE]   -> Finding {i + 1} processed successfully")
                else:
                    issues_skipped += 1
                    logger.info(f"[TRACE]   -> Finding {i + 1} skipped")
            except Exception as e:
                logger.error(f"Error processing finding {i + 1}: {e}")
                issues_skipped += 1

        logger.info(f"[TRACE] Completed processing: {issues_created} created, {issues_skipped} skipped")
        if filtered_by_control > 0:
            logger.info(
                "Issue filtering: %d of %d findings skipped — control not implemented in SSP",
                filtered_by_control,
                len(findings),
            )
        return issues_created, issues_skipped

    def process_single_finding(self, finding: IntegrationFinding) -> bool:
        """
        Process a single finding into an issue.

        :param finding: Finding to process
        :return: True if issue was created/updated, False if skipped
        """
        logger.info(
            f"[TRACE]   -> Processing finding: external_id='{finding.external_id}', asset_identifier='{finding.asset_identifier}'"
        )

        # LOG: Asset identifier details
        logger.info(
            f"[TRACE]   -> asset_identifier type={type(finding.asset_identifier)}, "
            f"value='{finding.asset_identifier}', is_empty={not finding.asset_identifier}"
        )

        asset = self._integration._get_or_create_asset_for_finding(finding)

        # LOG: Asset lookup result
        logger.info(
            f"[TRACE]   -> Asset lookup result: asset={'Found' if asset else 'None'}, asset.id={asset.id if asset else 'None'}"
        )

        if not asset:
            logger.info(
                f"[TRACE]   -> Asset not found/created for identifier '{finding.asset_identifier}', skipping finding"
            )
            self._integration._log_asset_not_found_error(finding)
            return False

        logger.debug(f"  -> Found/created asset {asset.id} for identifier '{finding.asset_identifier}'")
        issue_title = self._integration.get_issue_title(finding)
        issue = self._integration.create_or_update_issue_from_finding(title=issue_title, finding=finding)
        success = issue is not None
        if success and issue:
            logger.debug(f"  -> Successfully processed finding -> issue {issue.id}")
        else:
            logger.debug("  -> Failed to create/update issue for finding")
        return success

    def finding_has_matching_control(self, finding: IntegrationFinding) -> bool:
        """
        Check whether a finding's control ID maps to a matched SSP implementation.

        Extracts the control ID from ``control_labels`` or ``rule_id`` and checks it
        against ``_matched_control_ids`` and ``_control_lookup_cache``.

        :param IntegrationFinding finding: The finding to check
        :return: True if the control has a matching SSP implementation
        :rtype: bool
        """
        control_id = None
        if finding.control_labels:
            control_id = (
                finding.control_labels[0] if isinstance(finding.control_labels, list) else finding.control_labels
            )
        if not control_id and finding.rule_id:
            control_id = finding.rule_id

        if not control_id:
            # No control association — let it through
            return True

        # Case-insensitive match against tracked controls (source data may differ in case)
        control_id_lower = control_id.lower()
        if any(cid.lower() == control_id_lower for cid in self._integration._matched_control_ids):
            return True

        # Fallback: check the control lookup cache directly
        variations = self._integration._control_matcher._get_control_id_variations(control_id)
        for variation in variations:
            if variation in self._integration._control_lookup_cache:
                return True

        # Cross-framework fallback: translate the control and check if the translated ID matches
        crosswalk_match = self._integration._try_cross_framework_match(control_id)
        if crosswalk_match[0] is not None:
            return True

        logger.warning(
            "Skipping issue for finding '%s' — control '%s' has no matching SSP implementation.",
            finding.external_id,
            control_id,
        )
        return False

    def get_or_create_asset_for_finding(self, finding: IntegrationFinding) -> Optional[regscale_models.Asset]:
        """
        Get existing asset or create one on-demand for the finding.

        :param IntegrationFinding finding: Finding needing an asset
        :return: Asset if found/created, None otherwise
        :rtype: Optional[regscale_models.Asset]
        """
        asset = self._integration.get_asset_by_identifier(finding.asset_identifier)
        if not asset:
            # Fallback: check compliance integration's own cache (indexed by otherTrackingNumber)
            asset = self._integration._find_existing_asset_cached(finding.asset_identifier)
        if not asset:
            asset = self._integration._ensure_asset_for_finding(finding)
        return asset

    def log_asset_not_found_error(self, finding: IntegrationFinding) -> None:
        """
        Log error when asset is not found for a finding.

        :param IntegrationFinding finding: Finding with missing asset
        :return: None
        :rtype: None
        """
        if not getattr(self._integration, "suppress_asset_not_found_errors", False):
            logger.warning(
                f"Asset not found for identifier {finding.asset_identifier} — skipping issue creation for this finding"
            )

    def log_issue_results(self, issues_created: int, issues_skipped: int) -> None:
        """
        Log issue processing results.
        DEPRECATED: Use log_issue_results_accurate for accurate reporting.

        :param int issues_created: Number of issues created/updated
        :param int issues_skipped: Number of issues skipped
        :return: None
        :rtype: None
        """
        if issues_created > 0:
            logger.info(f"Issues processed: {issues_created} created/updated, {issues_skipped} skipped")
        elif issues_skipped > 0:
            logger.warning(f"Issues processed: 0 created, {issues_skipped} skipped (assets not found)")
        else:
            logger.debug("No issues processed")

    def log_issue_results_accurate(
        self,
        issues_created: int,
        issues_updated: int,
        findings_processed: int,
        findings_skipped: int,
    ) -> None:
        """
        Log accurate issue processing results based on actual database operations.

        :param int issues_created: Number of new issues created in database
        :param int issues_updated: Number of existing issues updated in database
        :param int findings_processed: Number of findings that were processed
        :param int findings_skipped: Number of findings that were skipped
        :return: None
        :rtype: None
        """
        total_db_operations = issues_created + issues_updated

        if total_db_operations > 0:
            logger.info(
                f"Processed {findings_processed} findings into issues: {issues_created} new issues created, {issues_updated} existing issues updated"
            )
            if findings_skipped > 0:
                logger.info(f"Skipped {findings_skipped} findings (no matching SSP control or asset not found)")
        elif findings_skipped > 0:
            logger.warning(
                f"Issues processed: 0 created/updated, {findings_skipped} findings skipped (no matching SSP control or asset not found)"
            )
        else:
            logger.debug(
                f"Processed {findings_processed} findings but no database changes were needed (all issues up-to-date)"
            )

    def ensure_asset_for_finding(self, finding: IntegrationFinding) -> Optional[regscale_models.Asset]:
        """
        Ensure an asset exists for the given finding.

        Attempts to locate the asset by identifier. If missing, it will try to
        build an IntegrationAsset from the first compliance item associated with
        the resource id and upsert it into RegScale, then return the created asset.

        :param IntegrationFinding finding: Finding referencing the asset identifier
        :return: The located or newly created Asset, or None if it cannot be created
        :rtype: Optional[regscale_models.Asset]
        """
        try:
            resource_id = getattr(finding, "asset_identifier", None)
            if not resource_id:
                return None

            # Re-check cache/DB
            asset = self._integration.get_asset_by_identifier(resource_id)
            if asset:
                return asset

            # Use compliance items we already processed to construct an asset
            related_items = self._integration.asset_compliance_map.get(resource_id, [])
            if not related_items:
                return None

            candidate_item = related_items[0]
            integration_asset = self._integration.create_asset_from_compliance_item(candidate_item)
            if not integration_asset:
                return None

            # Persist the asset and refresh lookup
            _ = self._integration.update_regscale_assets(iter([integration_asset]))
            return self._integration.get_asset_by_identifier(resource_id)

        except Exception as ensure_exc:
            logger.debug(
                f"On-demand asset creation failed for {getattr(finding, 'asset_identifier', None)}: {ensure_exc}"
            )
            return None

    def update_issue_affected_controls(
        self, existing_issue: regscale_models.Issue, finding: IntegrationFinding
    ) -> None:
        """Update the affectedControls field from finding data."""
        try:
            if getattr(finding, "control_labels", None):
                existing_issue.affectedControls = ",".join(finding.control_labels)
            else:
                # Fall back to normalized control id
                ctl = self._integration._extract_control_from_finding(finding)
                if ctl:
                    base, sub = self._integration._normalize_control_id(ctl)
                    existing_issue.affectedControls = f"{base}({sub})" if sub else base
        except Exception:
            pass

    def extract_control_from_finding(self, finding: IntegrationFinding) -> str | None:
        """Extract control ID from finding's rule_id or control_labels."""
        if getattr(finding, "rule_id", None):
            return finding.rule_id
        if getattr(finding, "control_labels", None):
            labels = list(finding.control_labels)
            return labels[0] if labels else None
        return None

    def update_existing_issue(
        self, existing_issue: regscale_models.Issue, title: str, finding: IntegrationFinding
    ) -> regscale_models.Issue:
        """Update an existing issue with new finding data."""
        logger.info(
            f"[TRACE] EXISTING ISSUE FOUND - Taking UPDATE path for external_id '{finding.external_id}' -> issue {existing_issue.id}"
        )

        original_status = existing_issue.status

        # Update issue fields
        existing_issue.title = title
        existing_issue.description = finding.description
        existing_issue.severityLevel = finding.severity
        existing_issue.status = finding.status
        self._integration._update_issue_affected_controls(existing_issue, finding)
        existing_issue.dateLastUpdated = self._integration.scan_date
        existing_issue.orgId = self._integration.determine_issue_organization_id(existing_issue.issueOwnerId)
        existing_issue.save()

        # Create milestones if status changed
        original_issue = regscale_models.Issue()
        original_issue.status = original_status
        self._integration._create_milestones_for_updated_issue(existing_issue, finding, original_issue)

        return existing_issue

    def create_new_issue(self, title: str, finding: IntegrationFinding, external_id: str) -> regscale_models.Issue:
        """Create a new issue from finding data."""
        logger.info(f"[TRACE] NO EXISTING ISSUE - Taking CREATE path for external_id '{external_id}'")
        logger.debug(f"No existing issue found for external_id {external_id}, creating new issue")

        result = self._integration._create_or_update_issue(
            finding=finding, issue_status=finding.status, title=title, _existing_issue=None
        )
        logger.info(
            f"[TRACE] _create_or_update_issue returned: issue={'object' if result else 'None'}, "
            f"pending_issues count={len(self._integration._pending_issues) if hasattr(self._integration, '_pending_issues') else 'NO ATTRIBUTE'}"
        )
        return result

    def create_or_update_issue_from_finding(self, title: str, finding: IntegrationFinding) -> regscale_models.Issue:
        """
        Create an issue from a finding and queue it for batch submission.

        Deduplication is handled server-side by the BatchCreateOrUpdate API
        using the configured uniqueKeyFields (e.g. integrationFindingId).

        :param str title: Issue title
        :param IntegrationFinding finding: The finding to create issue from
        :return: Created issue
        :rtype: regscale_models.Issue
        """
        external_id = finding.external_id
        logger.debug("Queuing issue for external_id: '%s'", external_id)
        return self._integration._create_new_issue(title, finding, external_id)

    def create_milestones_for_updated_issue(
        self,
        issue: regscale_models.Issue,
        finding: IntegrationFinding,
        original_issue: regscale_models.Issue,
    ) -> None:
        """
        Create milestones for an updated issue in compliance integration.

        This method handles both status transition milestones and backfilling of missing
        creation milestones for existing issues.

        :param regscale_models.Issue issue: The updated issue
        :param IntegrationFinding finding: The finding data
        :param regscale_models.Issue original_issue: Original state for comparison
        """
        milestone_manager = self._integration.get_milestone_manager()

        # First, ensure the issue has a creation milestone (backfill if missing)
        milestone_manager.ensure_creation_milestone_exists(issue=issue, finding=finding)

        # Then, handle status transition milestones
        milestone_manager.create_milestones_for_issue(
            issue=issue,
            finding=finding,
            existing_issue=original_issue,
        )
