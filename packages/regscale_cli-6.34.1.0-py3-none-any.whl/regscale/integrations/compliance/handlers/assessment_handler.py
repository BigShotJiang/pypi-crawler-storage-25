#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Compliance Assessment Handler

Extracts control assessment processing methods from ComplianceIntegration
into a dedicated handler class. The handler receives the ComplianceIntegration
instance and reads/writes its attributes directly.
"""

from __future__ import annotations

import logging
import re
import time
from typing import TYPE_CHECKING, Dict, List, Optional

from regscale.core.app.utils.app_utils import (
    get_current_datetime,
    regscale_string_to_datetime,
)
from regscale.integrations.framework_handlers.iso_mapping import (
    get_cross_edition_variations,
)
from regscale.models import regscale_models
from regscale.models.regscale_models import (
    Assessment,
    ComplianceSettings,
    ControlImplementation,
    ImplementationObjective,
    SecurityControl,
    SecurityPlan,
)

if TYPE_CHECKING:
    from regscale.integrations.compliance_integration import ComplianceIntegration, ComplianceItem

logger = logging.getLogger("regscale")


class ComplianceAssessmentHandler:
    """Handler for control assessment processing in compliance integrations."""

    def __init__(self, integration: "ComplianceIntegration") -> None:
        self._integration = integration

    def process_control_assessments(self) -> None:
        """
        Process control assessments based on compliance results.

        This follows the same pattern as the original Wiz compliance integration:
        1. Get control implementations
        2. For each implementation, get the security control using controlID
        3. Match the security control's controlId with the extracted control ID from compliance items

        :return: None
        :rtype: None
        """
        logger.info("Processing control assessments...")

        # Ensure existing records cache (including assessments) is loaded to prevent duplicates
        self._integration._load_existing_records_cache()

        implementations = self._integration._get_control_implementations()
        if not implementations:
            logger.warning("No control implementations found for assessment processing")
            return

        # Build control lookup cache for fast O(1) matching
        self._integration._build_control_lookup_cache(implementations)

        all_control_ids = (
            set(self._integration.passing_controls.keys())
            | set(self._integration.failing_controls.keys())
            | set(getattr(self._integration, "not_applicable_controls", {}).keys())
        )

        # Initialize cross-framework mapper when SSP and source frameworks differ
        self._integration._init_cross_framework_mapper(list(all_control_ids))

        logger.info(f"Processing assessments for {len(all_control_ids)} controls with compliance data")
        logger.info(f"Control IDs with data: {sorted(list(all_control_ids))}")
        self._integration._log_sample_controls(implementations)

        assessments_created = 0
        processed_impl_today: set[int] = set()
        for control_id in all_control_ids:
            created = self._integration._process_single_control_assessment(
                control_id=control_id,
                implementations=implementations,
                processed_impl_today=processed_impl_today,
            )
            assessments_created += created

        if assessments_created > 0:
            logger.info(f"Successfully created {assessments_created} control assessments")
        passing_assessments = len([cid for cid in all_control_ids if cid in self._integration.passing_controls])
        failing_assessments = len([cid for cid in all_control_ids if cid in self._integration.failing_controls])
        not_applicable_assessments = len(
            [cid for cid in all_control_ids if cid in getattr(self._integration, "not_applicable_controls", {})]
        )
        logger.info(
            f"Assessment breakdown: {passing_assessments} passing, {failing_assessments} failing, {not_applicable_assessments} not applicable"
        )
        logger.debug(f"Control implementation mappings created: {len(self._integration._impl_id_by_control)}")
        if self._integration._impl_id_by_control:
            logger.debug(f"Sample mappings: {dict(list(self._integration._impl_id_by_control.items())[:5])}")
        logger.debug(f"Today's assessments by implementation: {len(self._integration._assessment_by_impl_today)}")
        if self._integration._assessment_by_impl_today:
            logger.debug(
                f"Sample assessment mappings: {dict(list(self._integration._assessment_by_impl_today.items())[:5])}"
            )

    def get_control_implementations(self) -> List[ControlImplementation]:
        """
        Get all control implementations for the current plan with embedded SecurityControl objects.

        Uses the bulk endpoint (getAllByPlanWithControls) which returns implementations with
        their SecurityControl data in a single API call, eliminating N+1 queries during
        cache building.

        :return: List of control implementations with control field populated
        :rtype: List[ControlImplementation]
        """
        implementations = ControlImplementation.get_all_by_plan_with_controls(plan_id=self._integration.plan_id)
        if not implementations:
            # Fallback to standard method if plan-specific endpoint fails
            implementations = ControlImplementation.get_all_by_parent(
                parent_module=self._integration.parent_module, parent_id=self._integration.plan_id
            )
        logger.info("Found %d control implementations", len(implementations))
        return implementations

    def build_control_lookup_cache(self, implementations: List[ControlImplementation]) -> None:
        """
        Build a lookup cache mapping control ID variations to implementations and security controls.

        This dramatically improves performance by:
        1. Fetching all SecurityControl objects once (instead of once per match attempt)
        2. Pre-computing all control ID variations
        3. Creating a dictionary for O(1) lookup instead of O(n) iteration

        For 1011 implementations x 71 controls = 71,781 iterations in the old code.
        New code: 1011 fetches + 71 dictionary lookups = ~1082 operations (67x faster!)

        Also builds a reverse cache (_impl_to_control_id_cache) mapping implementation IDs
        to control IDs for better logging.

        :param List[ControlImplementation] implementations: List of control implementations to cache
        :return: None
        :rtype: None
        """
        if self._integration._control_lookup_cache:
            return

        logger.debug(
            "Building control lookup cache for %d implementations...",
            len(implementations),
        )
        start_time = time.time()

        # Initialize reverse cache for implementation ID -> control ID lookup
        self._integration._impl_to_control_id_cache: Dict[int, str] = {}

        for implementation in implementations:
            self.cache_single_implementation(implementation)

        elapsed = time.time() - start_time
        logger.info(
            "Built control lookup cache with %d control ID variations in %.2fs",
            len(self._integration._control_lookup_cache),
            elapsed,
        )
        distinct_control_ids = sorted(set(self._integration._impl_to_control_id_cache.values()))
        to_log = (
            distinct_control_ids
            if len(distinct_control_ids) <= 50
            else distinct_control_ids[:50] + [f"...+{len(distinct_control_ids) - 50} more"]
        )
        logger.info("SSP control IDs in cache (distinct): %s", to_log)
        self.log_cached_frameworks_debug()

    def cache_single_implementation(self, implementation: ControlImplementation) -> None:
        """
        Cache a single implementation's control ID variations.

        Uses the pre-loaded control field from the bulk API call when available,
        falling back to individual fetch only if needed.

        :param ControlImplementation implementation: The implementation to cache
        :return: None
        :rtype: None
        """
        try:
            # Use pre-loaded control from bulk fetch (no API call needed)
            security_control = implementation.control
            if isinstance(security_control, dict):
                security_control = SecurityControl(**security_control)
            if not isinstance(security_control, SecurityControl):
                # Fallback to individual fetch only if control wasn't pre-loaded
                security_control = SecurityControl.get_object(object_id=implementation.controlID)
            if not security_control or not security_control.controlId:
                return

            control_variations = self._integration._control_matcher._get_control_id_variations(
                security_control.controlId
            )

            # When syncing ISO 27001, add forms so AWS subcontrols and parent lookups match
            if self._integration.framework and "iso27001" in str(self._integration.framework).lower():
                cid = (security_control.controlId or "").strip()
                if cid and re.match(r"^\d+(?:\.\d+){1,2}$", cid):
                    # Catalog has numeric-only (e.g. 12.4): add A. prefix for AWS
                    control_variations = set(control_variations) | {"A." + cid, "a." + cid}
                elif cid and re.match(r"^[Aa]\.\d+(?:\.\d+){1,2}$", cid):
                    # Catalog has A. prefix (e.g. A.12.4): add numeric form so parent lookup "12.4" finds it
                    numeric_only = cid[2:].strip()  # strip "A." or "a."
                    control_variations = set(control_variations) | {
                        numeric_only,
                        "A." + numeric_only,
                        "a." + numeric_only,
                    }

                # Cross-edition mapping: if SSP uses 2022 IDs (e.g. 8.6), also register
                # the 2013 Annex A equivalents (e.g. A.12.1.3) so AWS controls can match
                cross_edition = get_cross_edition_variations(cid)
                if cross_edition:
                    control_variations = set(control_variations) | cross_edition

            self.add_variations_to_cache(control_variations, implementation, security_control)

        except Exception as e:  # noqa: BLE001
            logger.error(
                "Error caching implementation %d with controlID %s: %s",
                implementation.id,
                implementation.controlID,
                e,
            )

    def add_variations_to_cache(
        self,
        variations: List[str],
        implementation: ControlImplementation,
        security_control: SecurityControl,
    ) -> None:
        """
        Add control ID variations to the lookup cache.

        :param List[str] variations: Control ID variations to add
        :param ControlImplementation implementation: The implementation to cache
        :param SecurityControl security_control: The security control to cache
        :return: None
        :rtype: None
        """
        for variation in variations:
            if variation not in self._integration._control_lookup_cache:
                self._integration._control_lookup_cache[variation] = (
                    implementation,
                    security_control,
                )

        # Also populate reverse cache for implementation ID -> control ID lookup
        if implementation.id and security_control.controlId:
            self._integration._impl_to_control_id_cache[implementation.id] = security_control.controlId

    def log_cached_frameworks_debug(self) -> None:
        """
        Log sample controls grouped by framework type for debugging.

        :return: None
        :rtype: None
        """
        if not logger.isEnabledFor(logging.DEBUG):
            return

        frameworks: Dict[str, List[str]] = {}
        for control_id in self._integration._control_lookup_cache.keys():
            framework = self._integration._control_matcher._detect_framework(control_id)
            framework_list = frameworks.setdefault(framework, [])
            if len(framework_list) < 5:
                framework_list.append(control_id)

        for framework, controls in frameworks.items():
            logger.debug("  %s controls (sample): %s", framework, controls)

    def log_sample_controls(self, implementations: List[ControlImplementation]) -> None:
        """
        Log sample control IDs for debugging purposes.

        :param List[ControlImplementation] implementations: List of implementations to sample from
        :return: None
        :rtype: None
        """
        sample_regscale_controls: List[str] = []
        for impl in implementations[:10]:
            try:
                sec_control = SecurityControl.get_object(object_id=impl.controlID)
                if sec_control and sec_control.controlId:
                    sample_regscale_controls.append(f"{sec_control.controlId}")
                else:
                    sample_regscale_controls.append(f"NoControlId-impl:{impl.id}-controlID:{impl.controlID}")
            except Exception as e:  # noqa: BLE001
                sample_regscale_controls.append(f"ERROR-impl:{impl.id}-controlID:{impl.controlID}-error:{str(e)[:50]}")
                logger.error(
                    f"Error fetching SecurityControl for implementation {impl.id} with controlID {impl.controlID}: {e}"
                )
        logger.info(f"Sample RegScale control IDs available: {sample_regscale_controls}")

    def process_single_control_assessment(
        self,
        *,
        control_id: str,
        implementations: List[ControlImplementation],
        processed_impl_today: set[int],
    ) -> int:
        """
        Process assessment for a single control.

        :param str control_id: Control identifier to process
        :param List[ControlImplementation] implementations: Available control implementations
        :param set[int] processed_impl_today: Set of implementation IDs already processed today
        :return: Number of assessments created (0 or 1)
        :rtype: int
        """
        try:
            logger.debug(f"Processing control assessment for '{control_id}'")
            impl, sec_control = self._integration._find_matching_implementation(control_id, implementations)
            if not impl or not sec_control:
                self.log_no_match(control_id, implementations)
                return 0

            # Track that this control ID successfully matched an SSP implementation
            self._integration._matched_control_ids.add(control_id)

            result = self._integration._determine_overall_result(control_id)
            items = self._integration._get_control_compliance_items(control_id)
            logger.debug(f"Control '{control_id}' assessment: {result} (based on {len(items)} policy assessments)")

            if impl.id in processed_impl_today and self._integration._find_existing_assessment_cached(
                impl.id, self._integration.scan_date
            ):
                logger.debug(f"Skipping duplicate assessment for implementation {impl.id} (already processed today)")
                # IMPORTANT: Still update the control implementation status even when skipping assessment creation
                # This ensures status is updated on subsequent runs
                if self._integration.update_control_status:
                    logger.debug(f"Updating control implementation status for {control_id} (existing assessment)")
                    self._integration._update_implementation_status(impl, result)
            else:
                self._integration._create_control_assessment(
                    implementation=impl,
                    catalog_control={
                        "id": sec_control.id,
                        "controlId": sec_control.controlId,
                    },
                    result=result,
                    control_id=control_id,
                    compliance_items=items,
                )
                processed_impl_today.add(impl.id)

            self._integration._record_control_mapping(control_id, impl.id)
            return 1
        except Exception as e:  # noqa: BLE001
            logger.error(f"Error processing control assessment for '{control_id}': {e}")
            import traceback

            logger.debug(traceback.format_exc())
            return 0

    def find_matching_implementation(
        self, control_id: str, implementations: List[ControlImplementation]
    ) -> tuple[Optional[ControlImplementation], Optional[SecurityControl]]:
        """
        Find matching implementation and security control for a control ID.

        Uses ControlMatcher for robust control ID matching with leading zero normalization.
        Performance optimized with pre-built lookup cache for O(1) matching.

        :param str control_id: Control identifier to match
        :param List[ControlImplementation] implementations: Available implementations (used for fallback only)
        :return: Tuple of matching implementation and security control, or (None, None)
        :rtype: tuple[Optional[ControlImplementation], Optional[SecurityControl]]
        """
        # Generate all variations of the search control ID for matching
        search_variations = self._integration._control_matcher._get_control_id_variations(control_id)
        if not search_variations:
            logger.warning(f"Could not generate control ID variations for: {control_id}")
            return None, None

        # Log the variations being searched
        logger.debug(f"Searching for control '{control_id}' using variations: {search_variations}")

        # Try to find a match using the pre-built lookup cache (O(1) lookup)
        for variation in search_variations:
            if variation in self._integration._control_lookup_cache:
                implementation, security_control = self._integration._control_lookup_cache[variation]
                logger.debug(
                    f"MATCH FOUND: '{security_control.controlId}' == '{control_id}' "
                    f"(implementation: {implementation.id})"
                )
                return implementation, security_control

        # Fallback order: cross-edition first (exact 1:1 ISO mapping), then parent
        # (lossy approximation). Cross-edition is more precise because the mapping
        # comes from the official ISO/IEC 27002:2022 Annex B correspondence table,
        # whereas parent fallback drops the subcontrol segment (A.12.4.3 -> 12.4).

        # ISO 27001 cross-edition: AWS sends 2013 Annex A IDs (e.g. A.12.1.3)
        # but SSP may use 2022 IDs (e.g. 8.6), or vice versa.
        cross_edition = get_cross_edition_variations(control_id)
        if cross_edition:
            logger.info(
                "Trying ISO cross-edition mapping for '%s' -> %s",
                control_id,
                sorted(cross_edition),
            )
            for variation in cross_edition:
                if variation in self._integration._control_lookup_cache:
                    implementation, security_control = self._integration._control_lookup_cache[variation]
                    logger.info(
                        "MATCH FOUND (cross-edition): '%s' -> '%s' (implementation: %s)",
                        control_id,
                        security_control.controlId,
                        implementation.id,
                    )
                    return implementation, security_control

        # ISO 27001 parent fallback: AWS sends subcontrols (e.g. A.12.4.3) while
        # SSP may have top-level only (12.4). Last resort since it loses specificity.
        parent_variations = self._integration._get_iso_parent_control_variations(control_id)
        if parent_variations:
            logger.info(
                "Trying parent control fallback for '%s' -> %s",
                control_id,
                sorted(parent_variations),
            )
            for variation in parent_variations:
                if variation in self._integration._control_lookup_cache:
                    implementation, security_control = self._integration._control_lookup_cache[variation]
                    logger.debug(
                        f"MATCH FOUND (parent): '{security_control.controlId}' for subcontrol '{control_id}' "
                        f"(implementation: {implementation.id})"
                    )
                    return implementation, security_control

        # Cross-framework fallback: translate control ID via crosswalk (e.g., NIST -> SOC2)
        crosswalk_result = self._integration._try_cross_framework_match(control_id)
        if crosswalk_result[0] is not None:
            return crosswalk_result

        # No match found in cache -- expected when crosswalk doesn't cover all subcontrols
        logger.info("NO MATCH for control '%s' (tried %d variations + crosswalk)", control_id, len(search_variations))
        if logger.isEnabledFor(logging.DEBUG):
            # Only show sample of cache keys in debug mode to avoid spam
            cache_keys = list(self._integration._control_lookup_cache.keys())[:10]
            logger.debug(f"Sample of available controls in cache: {cache_keys}")
            logger.debug(f"Total controls in cache: {len(self._integration._control_lookup_cache)}")
        return None, None

    def log_no_match(self, control_id: str, implementations: List[ControlImplementation]) -> None:
        """
        Log when no matching implementation is found for a control.

        :param str control_id: Control identifier that couldn't be matched
        :param List[ControlImplementation] implementations: Available implementations for context
        :return: None
        :rtype: None
        """
        logger.info("No matching implementation found for control ID '%s'", control_id)
        sample_impl_controls = []
        for impl in implementations[:5]:
            try:
                sec_control = SecurityControl.get_object(object_id=impl.controlID)
                if sec_control and sec_control.controlId:
                    sample_impl_controls.append(f"{sec_control.controlId} (impl:{impl.id})")
            except Exception:
                sample_impl_controls.append(f"Unknown (impl:{impl.id})")
        logger.debug(f"Sample implementation control IDs (first 5): {sample_impl_controls}")

    def determine_overall_result(self, control_id: str) -> str:
        """
        Determine overall assessment result for a control.

        :param str control_id: Control identifier to check
        :return: Assessment result ('Pass', 'Fail', or 'Not Applicable')
        :rtype: str
        """
        is_failing = (
            control_id in self._integration.failing_controls
            or control_id.lower() in self._integration.failing_controls
            or control_id.upper() in self._integration.failing_controls
        )
        if is_failing:
            return "Fail"

        is_not_applicable = (
            control_id in self._integration.not_applicable_controls
            or control_id.lower() in self._integration.not_applicable_controls
            or control_id.upper() in self._integration.not_applicable_controls
        )
        if is_not_applicable:
            return self._integration.NOT_APPLICABLE_LABEL

        return "Pass"

    def get_control_compliance_items(self, control_id: str) -> List["ComplianceItem"]:
        """
        Get all compliance items for a specific control, supporting multi-control items.

        Uses get_all_control_ids() when available so that items mapping to multiple
        controls (e.g., Wiz rows with comma-separated control references) are matched
        for every control they reference, not just the first.

        :param str control_id: Control identifier to filter by
        :return: List of compliance items for the control
        :rtype: List[ComplianceItem]
        """
        target = control_id.lower()
        items: List["ComplianceItem"] = []
        for item in self._integration.all_compliance_items:
            item_control_ids = self._integration._get_all_control_ids_for_item(item)
            if any(cid.lower() == target for cid in item_control_ids):
                items.append(item)
        return items

    def record_control_mapping(self, control_id: str, implementation_id: int) -> None:
        """
        Record mapping between normalized control ID and implementation ID.

        :param str control_id: Control identifier to map
        :param int implementation_id: Implementation ID to associate
        :return: None
        :rtype: None
        """
        try:
            base, sub = self._integration._normalize_control_id(control_id)
            canonical = f"{base}({sub})" if sub else base
            self._integration._impl_id_by_control[canonical] = implementation_id
            logger.debug(f"Mapped control '{canonical}' -> implementation ID {implementation_id}")
        except Exception:
            pass

    def create_control_assessment(
        self,
        implementation: ControlImplementation,
        catalog_control: Dict,
        result: str,
        control_id: str,
        compliance_items: List["ComplianceItem"] = None,
    ) -> None:
        """
        Create or update an assessment for a control implementation.
        If an assessment for the same day exists, update it instead of creating a duplicate.

        :param ControlImplementation implementation: The control implementation to assess
        :param Dict catalog_control: The catalog control data dictionary
        :param str result: Assessment result ('Pass' or 'Fail')
        :param str control_id: Control identifier string
        :param List[ComplianceItem] compliance_items: Pre-aggregated compliance items for this control
        :return: None
        :rtype: None
        """
        try:
            # Use provided compliance items or get them for this control
            compliance_items = self._integration._get_compliance_items_for_control(control_id, compliance_items)

            # Create assessment report
            assessment_report = self._integration._create_assessment_report(control_id, result, compliance_items)

            # Check for existing assessment on the same day using cache
            existing_assessment = self._integration._find_existing_assessment_cached(
                implementation.id, self._integration.scan_date
            )

            if existing_assessment:
                self.update_existing_control_assessment(
                    existing_assessment, result, assessment_report, control_id, implementation.id
                )
            else:
                self._integration._create_new_control_assessment(implementation, control_id, result, assessment_report)

            # Update implementation status if needed
            if self._integration.update_control_status:
                self._integration._update_implementation_status(implementation, result)

        except Exception as e:
            logger.error(f"Error creating control assessment: {e}")

    def get_compliance_items_for_control(
        self, control_id: str, compliance_items: List["ComplianceItem"] = None
    ) -> List["ComplianceItem"]:
        """Get compliance items for a control, either from provided list or by filtering.

        Supports multi-control items by checking all control IDs via
        _get_all_control_ids_for_item() instead of only item.control_id.
        """
        if compliance_items is not None:
            return compliance_items

        # Check if control is in failing controls (case-insensitive)
        is_failing = (
            control_id in self._integration.failing_controls
            or control_id.lower() in self._integration.failing_controls
            or control_id.upper() in self._integration.failing_controls
        )

        target = control_id.lower()
        source = self._integration.failed_compliance_items if is_failing else self._integration.all_compliance_items
        return [
            item
            for item in source
            if any(cid.lower() == target for cid in self._integration._get_all_control_ids_for_item(item))
        ]

    def get_day_key_from_scan_date(self) -> str:
        """Extract day key from scan_date for cache indexing."""
        try:
            return regscale_string_to_datetime(self._integration.scan_date).date().isoformat()
        except Exception:
            return str(self._integration.scan_date).split(" ")[0]

    def track_assessment_for_today(self, implementation_id: int, assessment) -> None:
        """Track assessment by implementation ID for linking to issues later."""
        try:
            self._integration._assessment_by_impl_today[implementation_id] = assessment
        except Exception:
            pass

    def update_existing_control_assessment(
        self, existing_assessment, result: str, assessment_report: str, control_id: str, implementation_id: int
    ) -> None:
        """Update an existing assessment with new report and refresh caches."""
        existing_assessment.assessmentResult = result
        existing_assessment.assessmentReport = assessment_report
        existing_assessment.actualFinish = get_current_datetime()
        existing_assessment.dateLastUpdated = get_current_datetime()
        existing_assessment.save()
        logger.info(
            "Updated existing assessment %d for control %s with new report",
            existing_assessment.id,
            control_id,
        )
        # Refresh cache for today
        day_key = self.get_day_key_from_scan_date()
        self._integration._existing_assessments_cache[f"{implementation_id}_{day_key}"] = existing_assessment
        self.track_assessment_for_today(implementation_id, existing_assessment)

    def create_new_control_assessment(
        self, implementation: ControlImplementation, control_id: str, result: str, assessment_report: str
    ) -> None:
        """Create a new assessment and add it to caches."""
        assessment = Assessment(
            title=f"{self._integration.title} compliance assessment for {control_id.upper()}",
            assessmentType="Control Testing",
            plannedStart=get_current_datetime(),
            plannedFinish=get_current_datetime(),
            actualFinish=get_current_datetime(),
            assessmentResult=result,
            assessmentReport=assessment_report,
            status="Complete",
            parentId=implementation.id,
            parentModule="controls",
            isPublic=True,
        ).create()
        logger.debug(f"Created new assessment {assessment.id} for control {control_id}")
        # Add to cache for today
        day_key = self.get_day_key_from_scan_date()
        self._integration._existing_assessments_cache[f"{implementation.id}_{day_key}"] = assessment
        self.track_assessment_for_today(implementation.id, assessment)

    def find_existing_assessment(self, implementation: ControlImplementation, scan_date) -> Optional:
        """
        Find existing assessment for the same implementation on the same day.
        DEPRECATED: Use _find_existing_assessment_cached instead.

        :param ControlImplementation implementation: The control implementation
        :param scan_date: The scan date to check
        :return: Existing assessment or None
        :rtype: Optional[regscale_models.Assessment]
        """
        logger.warning("_find_existing_assessment is deprecated, use _find_existing_assessment_cached")
        return self._integration._find_existing_assessment_cached(implementation.id, scan_date)

    # ---------------------------------------------------------------------------
    # Compliance settings and implementation status methods
    # ---------------------------------------------------------------------------

    def get_security_plan(self) -> Optional[regscale_models.SecurityPlan]:
        """
        Get the security plan for this integration.

        :return: SecurityPlan instance or None
        :rtype: Optional[regscale_models.SecurityPlan]
        """
        if not self._integration._security_plan_loaded:
            self._integration._security_plan_loaded = True  # Mark as attempted to prevent repeated calls
            try:
                logger.info(f"[SECURITY PLAN] Retrieving security plan with ID: {self._integration.plan_id}")
                self._integration._security_plan = SecurityPlan.get_object(object_id=self._integration.plan_id)
                if self._integration._security_plan:
                    logger.info(
                        "[SECURITY PLAN] Retrieved security plan: %s",
                        getattr(self._integration._security_plan, "systemName", "N/A"),
                    )
                    logger.info(
                        "[SECURITY PLAN] complianceSettingsId: %s",
                        getattr(self._integration._security_plan, "complianceSettingsId", None),
                    )
                else:
                    logger.warning(f"[SECURITY PLAN] No security plan found with ID: {self._integration.plan_id}")
            except Exception as e:
                logger.error(f"[SECURITY PLAN] Error getting security plan {self._integration.plan_id}: {e}")
                # Don't set to None - keep as None but mark as loaded to prevent retry
        return self._integration._security_plan

    def get_compliance_settings(self) -> Optional[regscale_models.ComplianceSettings]:
        """
        Get compliance settings for the security plan.

        :return: ComplianceSettings instance or None
        :rtype: Optional[regscale_models.ComplianceSettings]
        """
        if not self._integration._compliance_settings_loaded:
            self._integration._compliance_settings_loaded = True  # Mark as attempted to prevent repeated calls
            try:
                security_plan = self._integration._get_security_plan()
                logger.debug(f"[COMPLIANCE SETTINGS] Security plan retrieved: {security_plan is not None}")
                if security_plan:
                    logger.debug(
                        "[COMPLIANCE SETTINGS] Security plan systemName: %s",
                        getattr(security_plan, "systemName", "N/A"),
                    )
                    logger.debug(
                        "[COMPLIANCE SETTINGS] Security plan ID: %s",
                        getattr(security_plan, "id", "N/A"),
                    )
                    logger.debug(
                        "[COMPLIANCE SETTINGS] Has complianceSettingsId attribute: %s",
                        hasattr(security_plan, "complianceSettingsId"),
                    )
                    logger.debug(
                        "[COMPLIANCE SETTINGS] complianceSettingsId value: %s",
                        getattr(security_plan, "complianceSettingsId", "None"),
                    )

                if self.has_valid_compliance_settings_id(security_plan):
                    self._integration._compliance_settings = self.fetch_compliance_settings(security_plan)
                else:
                    self.log_missing_compliance_settings_reason(security_plan)
            except Exception as e:
                logger.debug(f"Error getting compliance settings: {e}")
                import traceback

                logger.debug(f"Full traceback: {traceback.format_exc()}")
                # Don't set to None - keep as None but mark as loaded to prevent retry
        return self._integration._compliance_settings

    def has_valid_compliance_settings_id(self, security_plan) -> bool:
        """Check if security plan has valid compliance settings ID."""
        return security_plan and hasattr(security_plan, "complianceSettingsId") and security_plan.complianceSettingsId

    def fetch_compliance_settings(self, security_plan) -> Optional[regscale_models.ComplianceSettings]:
        """Fetch and log compliance settings."""
        logger.debug(f"Retrieving compliance settings with ID: {security_plan.complianceSettingsId}")
        compliance_settings = ComplianceSettings.get_object(object_id=security_plan.complianceSettingsId)

        if compliance_settings:
            logger.debug(f"Using compliance settings: {compliance_settings.title}")
            logger.debug(
                "Compliance settings has field groups: %s",
                bool(getattr(compliance_settings, "complianceSettingsFieldGroups", None)),
            )
        else:
            logger.debug(f"No compliance settings found for ID: {security_plan.complianceSettingsId}")

        return compliance_settings

    def log_missing_compliance_settings_reason(self, security_plan) -> None:
        """Log specific reason why compliance settings are not available."""
        if not security_plan:
            logger.debug("Security plan not found")
        elif not hasattr(security_plan, "complianceSettingsId"):
            logger.debug("Security plan does not have complianceSettingsId attribute")
        elif not security_plan.complianceSettingsId:
            logger.debug("Security plan has no complianceSettingsId set")

    def detect_compliance_framework(self) -> str:
        """
        Detect the compliance framework from the integration's framework attribute.

        Used as a fallback when no compliance settings are available.

        :return: Framework name ("DoD", "FedRAMP", "NIST", or "Default")
        :rtype: str
        """
        if not self._integration.framework:
            return "Default"

        framework_lower = str(self._integration.framework).lower()
        if any(kw in framework_lower for kw in ["dod", "rmf", "defense"]):
            return "DoD"
        if "fedramp" in framework_lower:
            return "FedRAMP"
        if any(kw in framework_lower for kw in ["nist", "800-53", "fisma"]):
            return "NIST"
        return "Default"

    def get_implementation_status_from_result(self, result: str, override: Optional[str] = None) -> str:
        """
        Get implementation status based on assessment result using enum-based mappings.
        Results are cached to avoid repeated calculations for the same input.

        :param str result: Assessment result ('Pass', 'Fail', 'Not Applicable', etc.)
        :param Optional[str] override: Optional override value to use instead of the mapping
        :return: Implementation status string
        :rtype: str
        """
        # Use override directly if provided
        if override:
            return override

        # Handle None or empty result
        if not result:
            logger.warning("Received None or empty result for status mapping, defaulting to 'Unknown'")
            return "Unknown"

        # Check cache first to avoid repeated calculations
        cache_key = result.lower().strip()
        if cache_key in self._integration._status_mapping_cache:
            cached_status = self._integration._status_mapping_cache[cache_key]
            logger.debug(f"[STATUS MAPPING] Using cached mapping for '{result}': '{cached_status}'")
            return cached_status

        logger.info(f"[STATUS MAPPING] Getting implementation status for result: {result}")

        # Try to use the compliance settings mapping function
        compliance_settings = self._integration._get_compliance_settings()
        if compliance_settings:
            logger.info(f"[STATUS MAPPING] Using compliance settings '{compliance_settings.title}' for mapping")
            try:
                mapped_status = compliance_settings.get_implementation_status_for_result(result, None)
                logger.info(f"[STATUS MAPPING] Mapped '{result}' to '{mapped_status}' using compliance settings")
                # Cache the result
                self._integration._status_mapping_cache[cache_key] = mapped_status
                return mapped_status
            except Exception as e:
                logger.warning(f"[STATUS MAPPING] Error using compliance settings mapping: {e}")

        # Fallback: Use the class method directly if no compliance settings instance
        framework = self._integration._detect_compliance_framework()
        logger.info(f"[STATUS MAPPING] Using framework '{framework}' for fallback mapping")
        mapped_status = ComplianceSettings.get_status_mapping(framework, result, None)
        logger.info(f"[STATUS MAPPING] Mapped '{result}' to '{mapped_status}' using fallback")
        # Cache the result
        self._integration._status_mapping_cache[cache_key] = mapped_status
        return mapped_status

    def update_implementation_status(self, implementation: ControlImplementation, result: str) -> None:
        """
        Update control implementation status based on assessment result.
        Uses compliance settings from the security plan if available, otherwise falls back to defaults.

        :param ControlImplementation implementation: Control implementation to update
        :param str result: Assessment result ('Pass' or 'Fail')
        :return: None
        :rtype: None
        """
        try:
            # Get status from compliance settings or fallback to default
            new_status = self._integration._get_implementation_status_from_result(result)

            # Capture original data before mutation so has_changed() can detect the diff.
            # The lazy snapshot is only taken on first access -- if we mutate first, the
            # snapshot captures the already-mutated state and save() becomes a silent no-op.
            implementation._get_original_data()

            # Update implementation status
            implementation.status = new_status
            implementation.dateLastAssessed = get_current_datetime()
            implementation.lastAssessmentResult = result

            # Force save -- _original_data snapshot is captured lazily on first access, which
            # can happen AFTER field modifications, making has_changed() return False incorrectly.
            implementation._ignore_has_changed = True

            # Ensure required fields are set if empty
            if not implementation.responsibility:
                implementation.responsibility = ControlImplementation.get_default_responsibility(
                    parent_id=implementation.parentId
                )
                logger.debug(
                    f"Setting default responsibility for implementation {implementation.id}: "
                    f"{implementation.responsibility}"
                )

            if not implementation.implementation:
                control_id = (
                    getattr(implementation.control, "controlId", "control") if implementation.control else "control"
                )
                implementation.implementation = f"Implementation details for {control_id} will be documented."
                logger.debug(f"Setting default implementation statement for implementation {implementation.id}")

            implementation.save()

            # Look up control ID from cache for better logging
            control_id_display = "unknown"
            if (
                hasattr(self._integration, "_impl_to_control_id_cache")
                and implementation.id in self._integration._impl_to_control_id_cache
            ):
                control_id_display = self._integration._impl_to_control_id_cache[implementation.id]

            logger.info(
                "Updated control implementation %d status to '%s' (control: %s)",
                implementation.id,
                new_status,
                control_id_display,
            )

            # Update objectives if they exist
            objectives = ImplementationObjective.get_all_by_parent(
                parent_module=implementation.get_module_slug(),
                parent_id=implementation.id,
            )

            for objective in objectives:
                objective.status = new_status
                objective.save()
                logger.debug("Updated objective %d status to '%s'", objective.id, new_status)

        except Exception as e:
            logger.error(f"Error updating implementation status: {e}")
