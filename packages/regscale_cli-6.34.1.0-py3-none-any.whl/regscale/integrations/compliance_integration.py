#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Abstract Compliance Integration Base Class

This module provides a base class for implementing compliance integrations
that follow common patterns across different compliance tools (Wiz, Tenable, Sicura).
"""

import logging
import re
import threading
from abc import ABC, abstractmethod
from collections import defaultdict
from typing import Any, Dict, Iterator, List, Optional

from regscale.core.app.utils.app_utils import get_current_datetime
from regscale.integrations.control_matcher import ControlMatcher
from regscale.integrations.framework_handlers.iso_mapping import (
    get_cross_edition_variations,
)
from regscale.integrations.scanner_integration import (
    IntegrationAsset,
    IntegrationFinding,
    ScannerIntegration,
)
from regscale.models import regscale_models
from regscale.models.regscale_models import (
    Assessment,  # noqa: F401 - imported for test patching at module level
    Catalog,
    ComplianceSettings,  # noqa: F401 - imported for test patching at module level
    ControlImplementation,
    ImplementationObjective,  # noqa: F401 - imported for test patching at module level
    SecurityControl,
    SecurityPlan,  # noqa: F401 - imported for test patching at module level
)

logger = logging.getLogger("regscale")

# ---------------------------------------------------------------------------
# Framework auto-detection (lifted from CrowdStrike for shared use)
# ---------------------------------------------------------------------------

# Patterns for detecting frameworks from control IDs
_NIST_PATTERN = re.compile(r"^[A-Z]{2}-\d+", re.IGNORECASE)
_CSF_PATTERN = re.compile(r"^(ID|PR|DE|RS|RC|GV)\.", re.IGNORECASE)
_SOC2_PATTERN = re.compile(r"^(CC|A|C|PI|P)\d+\.\d+", re.IGNORECASE)
_CMMC_PATTERN = re.compile(r"^[A-Z]{2}\.L\d+-", re.IGNORECASE)
_OWASP_PATTERN = re.compile(r"^V\d+\.\d+\.\d+", re.IGNORECASE)


class FrameworkDetectionError(Exception):
    """Raised when the compliance framework cannot be auto-detected from SSP controls."""


def detect_framework_from_control_ids(control_names: List[str]) -> str:
    """
    Auto-detect the compliance framework from SSP control implementation IDs.

    Examines control ID patterns to determine the framework: NIST 800-53 (e.g., AC-2, SI-4),
    CSF (e.g., ID.AM-1, PR.AC-1), SOC2 (e.g., CC6.8, A1.2), CMMC (e.g., AC.L1-3.1.1),
    or OWASP (e.g., V1.1.1, V5.3.3).
    Logs confidence metrics and warnings for edge cases.

    :param List[str] control_names: List of control ID strings from the SSP
    :return: Detected framework name ("NIST", "CSF", "SOC2", "CMMC", or "OWASP")
    :rtype: str
    :raises FrameworkDetectionError: If no controls are provided or none match known frameworks
    """
    nist_count = 0
    csf_count = 0
    soc2_count = 0
    cmmc_count = 0
    owasp_count = 0

    for name in control_names:
        if _CSF_PATTERN.match(name):
            csf_count += 1
        elif _SOC2_PATTERN.match(name):
            soc2_count += 1
        elif _CMMC_PATTERN.match(name):
            cmmc_count += 1
        elif _OWASP_PATTERN.match(name):
            owasp_count += 1
        elif _NIST_PATTERN.match(name):
            nist_count += 1

    total = len(control_names)
    matched = nist_count + csf_count + soc2_count + cmmc_count + owasp_count
    unmatched = total - matched

    if unmatched > 0:
        logger.warning(
            "Framework detection: %d of %d control IDs did not match known patterns.",
            unmatched,
            total,
        )

    if matched == 0:
        raise FrameworkDetectionError(
            "No control IDs matched known framework patterns (checked %d controls). "
            "Cannot auto-detect framework. Please specify a framework explicitly." % total
        )

    counts = {"NIST": nist_count, "CSF": csf_count, "SOC2": soc2_count, "CMMC": cmmc_count, "OWASP": owasp_count}
    detected = max(counts, key=lambda k: counts[k])
    confidence = counts[detected] / total if total > 0 else 0.0

    # Require at least 10% of controls to match to avoid false positives
    if confidence < 0.10:
        raise FrameworkDetectionError(
            "Low confidence in framework detection: %d/%d controls matched '%s' (%.0f%%). "
            "Please specify a framework explicitly." % (counts[detected], total, detected, confidence * 100)
        )

    if confidence < 0.30:
        logger.warning(
            "Low-confidence framework detection: '%s' (%.0f%%). Consider using an explicit --framework flag.",
            detected,
            confidence * 100,
        )

    if sum(1 for c in counts.values() if c > 0) > 1:
        logger.info(
            "Mixed framework controls detected: %s. Selecting '%s' (majority, %.0f%% confidence).",
            ", ".join("%s=%d" % (k, v) for k, v in counts.items() if v > 0),
            detected,
            confidence * 100,
        )
    else:
        logger.debug("Detected framework '%s' with %.0f%% confidence.", detected, confidence * 100)

    return detected


# Safer, linear-time regex for control-id parsing/normalization used across
# compliance integrations. Supports: 'AC-4', 'AC-4(2)', 'AC-4 (2)', 'AC-4-2', 'AC-4 2'
# Distinct branches ('(', '-' or whitespace) avoid ambiguous nested alternation
# and excessive backtracking that could be used for DoS.
SAFE_CONTROL_ID_RE = re.compile(  # NOSONAR
    r"^([A-Za-z]{2}-\d+)(?:\s*\(\s*(\d+)\s*\)|-\s*(\d+)|\s+(\d+))?$",  # NOSONAR
    re.IGNORECASE,  # NOSONAR
)


class ComplianceItem(ABC):
    """
    Abstract base class representing a compliance assessment item.

    This represents a single compliance check result for a specific
    resource against a specific control.
    """

    @property
    @abstractmethod
    def resource_id(self) -> str:
        """Unique identifier for the resource being assessed."""
        pass

    @property
    @abstractmethod
    def resource_name(self) -> str:
        """Human-readable name of the resource."""
        pass

    @property
    @abstractmethod
    def control_id(self) -> str:
        """Control identifier (e.g., AC-3, SI-2)."""
        pass

    @property
    @abstractmethod
    def compliance_result(self) -> str:
        """Result of compliance check (PASS, FAIL, etc)."""
        pass

    @property
    @abstractmethod
    def severity(self) -> Optional[str]:
        """Severity level of the compliance violation (if failed)."""
        pass

    @property
    @abstractmethod
    def description(self) -> str:
        """Description of the compliance check."""
        pass

    @property
    @abstractmethod
    def framework(self) -> str:
        """Compliance framework (e.g., NIST800-53R5, CSF)."""
        pass


class ComplianceIntegration(ScannerIntegration, ABC):
    """
    Abstract base class for compliance integrations.

    This class provides common patterns for:
    - Processing compliance data
    - Creating assets from compliance items
    - Creating findings/issues for failed compliance
    - Mapping compliance items to controls
    - Creating assessments and updating control status
    """

    # String literal constants
    NOT_APPLICABLE_LABEL = "Not Applicable"
    NOT_APPLICABLE_LOWER = "not applicable"
    NOT_APPLICABLE_UNDERSCORE = "not_applicable"

    # Status mapping constants
    PASS_STATUSES = [
        "PASS",
        "PASSED",
        "Pass",
        "Passed",
        "pass",
        "passed",
        "COMPLIANT",
        "Compliant",
        "compliant",
    ]
    FAIL_STATUSES = [
        "FAIL",
        "FAILED",
        "Fail",
        "Failed",
        "fail",
        "failed",
        "NONCOMPLIANT",
        "NonCompliant",
        "noncompliant",
    ]

    NOT_APPLICABLE_STATUSES = [
        "NOT_APPLICABLE",
        NOT_APPLICABLE_LABEL,
        "not_applicable",
        "NA",
        "N/A",
    ]
    INCONCLUSIVE_STATUSES = [
        "INCONCLUSIVE",
        "Inconclusive",
        "inconclusive",
        "UNKNOWN",
        "Unknown",
        "unknown",
        "MANUAL",
        "Manual",
        "manual",
    ]

    def __init__(
        self,
        plan_id: int,
        catalog_id: Optional[int] = None,
        framework: str = "NIST800-53R5",
        create_issues: bool = True,
        update_control_status: bool = True,
        create_poams: bool = False,
        parent_module: str = "securityplans",
        **kwargs,
    ):
        """
        Initialize compliance integration.

        :param int plan_id: RegScale plan ID
        :param Optional[int] catalog_id: RegScale catalog ID
        :param str framework: Compliance framework
        :param bool create_issues: Whether to create issues for failed compliance
        :param bool update_control_status: Whether to update control implementation status
        :param bool create_poams: Whether to mark issues as POAMs
        """
        super().__init__(plan_id=plan_id, **kwargs)

        self.catalog_id = catalog_id
        self.framework = framework
        self.create_issues = create_issues
        self.update_control_status = update_control_status
        self.create_poams = create_poams

        # Compliance data storage
        self.all_compliance_items: List[ComplianceItem] = []
        self.failed_compliance_items: List[ComplianceItem] = []
        self.passing_controls: Dict[str, ComplianceItem] = {}
        self.failing_controls: Dict[str, ComplianceItem] = {}
        self.not_applicable_controls: Dict[str, ComplianceItem] = {}

        # Asset mapping for compliance to asset correlation
        self.asset_compliance_map: Dict[str, List[ComplianceItem]] = defaultdict(list)

        # Initialize caches for existing records to prevent duplicates
        self._existing_assets_cache: Dict[str, regscale_models.Asset] = {}
        self._existing_assessments_cache: Dict[str, regscale_models.Assessment] = {}
        self._cache_loaded = False

        # Mapping caches for linking issues to implementations and assessments
        # Key: canonical control id string (e.g., "AC-2(1)") -> ControlImplementation.id
        self._impl_id_by_control: Dict[str, int] = {}
        # Key: ControlImplementation.id -> Assessment created/updated today
        self._assessment_by_impl_today: Dict[int, regscale_models.Assessment] = {}
        # suppress asset not found errors in non-debug modes
        self.suppress_asset_not_found_errors = logger.level != logging.DEBUG
        # Set scan date
        self.scan_date = get_current_datetime()

        # Cache for compliance settings
        self._compliance_settings = None
        self._security_plan = None
        self._security_plan_loaded = False  # Track if we've attempted to load
        self._compliance_settings_loaded = False  # Track if we've attempted to load
        self._status_mapping_cache = {}  # Cache for status mappings to avoid repeated calculations

        # Initialize control matcher for robust control ID matching
        self._control_matcher = ControlMatcher()

        # Performance optimization: cache for control lookups
        # Key: control ID variation (e.g., 'ac-2(1)') -> (ControlImplementation, SecurityControl)
        self._control_lookup_cache: Dict[str, tuple[ControlImplementation, SecurityControl]] = {}

        # Cross-framework mapping support
        self._cross_framework_mapper = None
        self._detected_ssp_framework: Optional[str] = None
        self._detected_source_framework: Optional[str] = None

        # Track which control IDs matched an SSP implementation during assessment processing
        self._matched_control_ids: set[str] = set()

        # Handlers are lazily initialized via _ensure_handlers() to support
        # tests that bypass __init__ using __new__ or frozenset(__abstractmethods__).
        self._handlers_initialized = False
        self._handlers_lock = threading.Lock()

    def _ensure_handlers(self) -> None:
        """Initialize compliance handlers if not already initialized (thread-safe).

        Uses double-checked locking: the fast path (already initialized) avoids
        the lock entirely, while the slow path (first call) holds the lock to
        prevent duplicate initialization from concurrent threads.
        """
        if getattr(self, "_handlers_initialized", False):
            return
        lock = getattr(self, "_handlers_lock", None)
        if lock is None:
            self._handlers_lock = threading.Lock()
            lock = self._handlers_lock
        with lock:
            if getattr(self, "_handlers_initialized", False):
                return
            from regscale.integrations.compliance.handlers import (
                ComplianceAssessmentHandler,
                ComplianceAssessmentReportHandler,
                ComplianceCacheHandler,
                ComplianceIssueHandler,
            )

            self._compliance_cache_handler = ComplianceCacheHandler(self)
            self._compliance_report_handler = ComplianceAssessmentReportHandler(self)
            self._compliance_assessment_handler = ComplianceAssessmentHandler(self)
            self._compliance_issue_handler = ComplianceIssueHandler(self)
            self._handlers_initialized = True

    def __getattr__(self, name: str):
        """Fallback: auto-initialize handlers when accessed before _ensure_handlers()."""
        handler_names = {
            "_compliance_cache_handler",
            "_compliance_report_handler",
            "_compliance_assessment_handler",
            "_compliance_issue_handler",
        }
        if name in handler_names:
            self._ensure_handlers()
            return getattr(self, name)
        raise AttributeError(f"'{type(self).__name__}' object has no attribute '{name}'")

    def _detect_ssp_framework(self) -> Optional[str]:
        """
        Detect the compliance framework used by the SSP's control implementations.

        :return: Detected framework name or None if detection fails
        :rtype: Optional[str]
        """
        if self._detected_ssp_framework is not None:
            return self._detected_ssp_framework
        try:
            control_ids = list(self._control_lookup_cache.keys())[:200]
            if not control_ids:
                return None
            self._detected_ssp_framework = detect_framework_from_control_ids(control_ids)
            logger.info("Detected SSP framework: %s", self._detected_ssp_framework)
        except FrameworkDetectionError:
            logger.debug("Could not auto-detect SSP framework from control lookup cache.")
        return self._detected_ssp_framework

    def _detect_source_framework(self, control_ids: List[str]) -> Optional[str]:
        """
        Detect the compliance framework of the source data (e.g., findings from Wiz).

        :param List[str] control_ids: Control IDs from the source data
        :return: Detected framework name or None if detection fails
        :rtype: Optional[str]
        """
        if self._detected_source_framework is not None:
            return self._detected_source_framework
        try:
            sample = control_ids[:200]
            self._detected_source_framework = detect_framework_from_control_ids(sample)
            logger.info("Detected source framework: %s", self._detected_source_framework)
        except FrameworkDetectionError:
            logger.debug("Could not auto-detect source framework.")
        return self._detected_source_framework

    def is_poam(self, finding: IntegrationFinding) -> bool:  # type: ignore[override]
        """
        Determines if an issue should be considered a POAM for compliance integrations.

        - If the integration was initialized with `create_poams=True` (e.g., via `--create-poams/-cp`),
          always return True so newly created and updated issues are POAMs.
        - Otherwise, defer to the generic scanner behavior.
        """
        try:
            if getattr(self, "create_poams", False):
                return True
            if finding.due_date >= get_current_datetime():
                return True
        except Exception:
            pass
        return super().is_poam(finding)

    def _load_existing_records_cache(self) -> None:
        """
        Load existing RegScale records into cache to prevent duplicates.
        This method populates caches for assets, issues, and assessments.

        :return: None
        :rtype: None
        """
        self._ensure_handlers()
        self._compliance_cache_handler.load_existing_records_cache()

    def _load_existing_assets(self) -> None:
        """
        Load existing assets into cache.

        :return: None
        :rtype: None
        """
        self._compliance_cache_handler.load_existing_assets()

    def _get_assessment_cache_key(self, implementation_id: int, assessment) -> str | None:
        """Generate cache key for assessment (impl_id + day)."""
        return self._compliance_cache_handler.get_assessment_cache_key(implementation_id, assessment)

    def _cache_implementation_assessments(self, implementation) -> None:
        """Load and cache assessments for a single implementation."""
        self._compliance_cache_handler.cache_implementation_assessments(implementation)

    def _load_existing_assessments(self) -> None:
        """
        Load existing assessments into cache.

        :return: None
        :rtype: None
        """
        self._compliance_cache_handler.load_existing_assessments()

    def _find_existing_asset_cached(self, resource_id: str) -> Optional[regscale_models.Asset]:
        """
        Find existing asset by resource ID using cache.

        :param str resource_id: Resource identifier to search for
        :return: Existing asset or None if not found
        :rtype: Optional[regscale_models.Asset]
        """
        return self._compliance_cache_handler.find_existing_asset_cached(resource_id)

    def _find_existing_assessment_cached(
        self, implementation_id: int, scan_date
    ) -> Optional[regscale_models.Assessment]:
        """
        Find existing assessment by implementation ID and date using cache.

        :param int implementation_id: Control implementation ID
        :param scan_date: Scan date to check against existing assessments
        :return: Existing assessment or None if not found
        :rtype: Optional[regscale_models.Assessment]
        """
        return self._compliance_cache_handler.find_existing_assessment_cached(implementation_id, scan_date)

    def check_for_existing_evidence(self, file_name_pattern: str) -> bool:
        """
        Check if an evidence file matching the pattern already exists in RegScale.

        This method fetches existing files for the plan and checks if any match
        the provided pattern, helping prevent duplicate evidence uploads.

        :param str file_name_pattern: Pattern to match against existing file names
        :return: True if a matching file exists, False otherwise
        :rtype: bool
        """
        return self._compliance_cache_handler.check_for_existing_evidence(file_name_pattern)

    @abstractmethod
    def fetch_compliance_data(self) -> List[Any]:
        """
        Fetch raw compliance data from the external system.

        :return: List of raw compliance data (will be converted to ComplianceItems)
        :rtype: List[Any]
        """
        pass

    @abstractmethod
    def create_compliance_item(self, raw_data: Any) -> ComplianceItem:
        """
        Create a ComplianceItem from raw compliance data.

        :param Any raw_data: Raw compliance data from external system
        :return: ComplianceItem instance
        :rtype: ComplianceItem
        """
        pass

    def process_compliance_data(self) -> None:
        """
        Process compliance data and categorize items.

        Separates passing and failing compliance items and builds
        control status mappings.

        :return: None
        :rtype: None
        """
        logger.info("Processing compliance data...")

        self._reset_compliance_state()
        allowed_controls = self._build_allowed_controls_set()
        raw_compliance_data = self.fetch_compliance_data()

        processing_stats = self._process_raw_compliance_items(raw_compliance_data, allowed_controls)
        self._log_processing_summary(raw_compliance_data, processing_stats)

        # Perform control-level categorization based on aggregated results
        self._categorize_controls_by_aggregation()
        self._log_final_results()

    def _reset_compliance_state(self) -> None:
        """Reset state to avoid double counting on repeated calls."""
        self.all_compliance_items = []
        self.failed_compliance_items = []
        self.passing_controls = {}
        self.failing_controls = {}
        self.not_applicable_controls = {}
        self.asset_compliance_map.clear()

    def _build_allowed_controls_set(self) -> set[str]:
        """Build allowed control IDs from plan/catalog controls to restrict scope."""
        allowed_controls_normalized: set[str] = set()
        try:
            controls = self._get_controls()
            logger.debug(f"Loaded {len(controls)} controls from plan/catalog")

            for ctl in controls:
                cid = (ctl.get("controlId") or "").strip()
                if not cid:
                    continue
                base, sub = self._normalize_control_id(cid)
                normalized = f"{base}({sub})" if sub else base
                allowed_controls_normalized.add(normalized)
                # For ISO 27001, allow Annex A forms (A.12.4.2) so AWS compliance items are not skipped
                if self.framework and "iso27001" in str(self.framework).lower():
                    if re.match(r"^\d+(?:\.\d+){1,2}$", cid):
                        allowed_controls_normalized.add("A." + cid)
                        allowed_controls_normalized.add("a." + cid)
                    # Cross-edition mapping: if SSP uses 2022 IDs (e.g. 8.6), also allow
                    # the 2013 Annex A equivalents (e.g. A.12.1.3) so AWS items aren't skipped
                    cross_edition = get_cross_edition_variations(cid)
                    allowed_controls_normalized.update(cross_edition)

            logger.info(
                "Loaded %d control ID(s) from plan/catalog for allowed_controls",
                len(allowed_controls_normalized),
            )
            logger.debug(f"Built allowed_controls_normalized set with {len(allowed_controls_normalized)} entries")
            if allowed_controls_normalized:
                sample = sorted(allowed_controls_normalized)[:5]
                logger.debug(f"Sample allowed controls: {sample}")
        except Exception as e:
            logger.warning(f"Could not load controls from plan/catalog: {e}")
            allowed_controls_normalized = set()

        return allowed_controls_normalized

    def _process_raw_compliance_items(self, raw_compliance_data: list, allowed_controls: set) -> dict:
        """Process raw compliance items and return processing statistics.
        :param list raw_compliance_data: Raw compliance data from external system
        :param set allowed_controls: Allowed control IDs
        :return: Processed compliance items
        :rtype: dict
        """
        stats = {
            "skipped_no_control": 0,
            "skipped_no_resource": 0,
            "skipped_not_in_plan": 0,
            "processed_count": 0,
        }

        for raw_item in raw_compliance_data:
            try:
                compliance_item = self.create_compliance_item(raw_item)
                if not self._process_single_compliance_item(compliance_item, allowed_controls, stats):
                    continue
            except Exception as e:
                logger.error(f"Error processing compliance item: {e}")
                continue

        return stats

    def _process_single_compliance_item(self, compliance_item: Any, allowed_controls: set, stats: dict) -> bool:
        """Process a single compliance item and update statistics. Returns True if processed successfully."""
        control_id = getattr(compliance_item, "control_id", "")
        resource_id = getattr(compliance_item, "resource_id", "")

        if not control_id:
            stats["skipped_no_control"] += 1
            return False
        if not resource_id:
            stats["skipped_no_resource"] += 1
            return False

        if not self._should_process_item(compliance_item, control_id, allowed_controls, stats):
            return False

        self._add_processed_item(compliance_item, stats)
        return True

    def _should_process_item(self, compliance_item: Any, control_id: str, allowed_controls: set, stats: dict) -> bool:
        """Determine if an item should be processed based on control filtering."""
        if not allowed_controls:
            return True

        base, sub = self._normalize_control_id(control_id)
        norm_item = f"{base}({sub})" if sub else base

        if norm_item in allowed_controls:
            return True

        # Allow PASS controls through even if they don't have existing implementations
        if compliance_item.compliance_result in self.PASS_STATUSES:
            return True

        stats["skipped_not_in_plan"] += 1
        if stats["skipped_not_in_plan"] <= 3:
            logger.debug(f"Skipping control {norm_item} - not in plan (result: {compliance_item.compliance_result})")
        return False

    def _add_processed_item(self, compliance_item: Any, stats: dict) -> None:
        """Add a processed item to collections and update statistics."""
        self.all_compliance_items.append(compliance_item)
        stats["processed_count"] += 1

        # Build asset mapping
        self.asset_compliance_map[compliance_item.resource_id].append(compliance_item)

        # Categorize by result
        if compliance_item.compliance_result in self.FAIL_STATUSES:
            self.failed_compliance_items.append(compliance_item)
            logger.debug(
                f"Added failing compliance item: control={compliance_item.control_id}, "
                f"result={compliance_item.compliance_result}, resource={compliance_item.resource_id}"
            )

    def _log_processing_summary(self, raw_compliance_data: list, stats: dict) -> None:
        """Log summary of compliance data processing."""
        logger.info(
            "Compliance items: %d raw, %d processed, %d skipped (not in plan), %d no control_id, %d no resource_id",
            len(raw_compliance_data),
            stats["processed_count"],
            stats["skipped_not_in_plan"],
            stats["skipped_no_control"],
            stats["skipped_no_resource"],
        )
        logger.debug("Compliance item processing summary:")
        logger.debug(f"  - Total raw items: {len(raw_compliance_data)}")
        logger.debug(f"  - Skipped (no control_id): {stats['skipped_no_control']}")
        logger.debug(f"  - Skipped (no resource_id): {stats['skipped_no_resource']}")
        logger.debug(f"  - Skipped (not in plan): {stats['skipped_not_in_plan']}")
        logger.debug(f"  - Processed successfully: {stats['processed_count']}")

    def _log_final_results(self) -> None:
        """Log final processing results."""
        logger.debug(
            f"Processed {len(self.all_compliance_items)} compliance items: "
            f"{len(self.all_compliance_items) - len(self.failed_compliance_items)} passing, "
            f"{len(self.failed_compliance_items)} failing"
        )
        logger.debug(
            f"Control categorization: {len(self.passing_controls)} passing controls, "
            f"{len(self.failing_controls)} failing controls"
        )

    def _categorize_controls_by_aggregation(self) -> None:
        """
        Categorize controls as passing or failing based on aggregated results across all compliance items.

        This method uses project-scoped aggregation logic instead of the previous "any fail = control fails"
        approach. For project-scoped integrations (like Wiz), this provides more accurate control status.
        """

        # Group all compliance items by control ID
        control_items = self._group_items_by_control()

        # Analyze each control's results
        for control_key, items in control_items.items():
            self._categorize_single_control(control_key, items)

    @staticmethod
    def _get_all_control_ids_for_item(item: ComplianceItem) -> List[str]:
        """
        Get all control IDs for a compliance item, supporting multi-control items.

        Checks for get_all_control_ids() method first (used by Wiz and other integrations
        where a single compliance check maps to multiple controls), then falls back
        to the single control_id property.

        :param ComplianceItem item: Compliance item to extract control IDs from
        :return: List of control ID strings
        :rtype: List[str]
        """
        if hasattr(item, "get_all_control_ids"):
            return item.get_all_control_ids()
        if hasattr(item, "control_id") and item.control_id:
            return [item.control_id]
        return []

    def _group_items_by_control(self) -> dict:
        """Group compliance items by control ID, supporting multi-control items."""
        from collections import defaultdict

        control_items = defaultdict(list)
        for item in self.all_compliance_items:
            for control_key in self._get_all_control_ids_for_item(item):
                control_items[control_key.lower()].append(item)

        return control_items

    def _categorize_single_control(self, control_key: str, items: list) -> None:
        """Categorize a single control based on its compliance items."""
        from collections import Counter

        results = [item.compliance_result for item in items]
        result_counts = Counter(results)
        total_items = len(results)

        fail_count, pass_count, not_applicable_count = self._count_results(result_counts)

        if fail_count == 0 and pass_count > 0:
            self._mark_control_as_passing(control_key, items, pass_count, fail_count)
        elif fail_count > 0:
            self._handle_control_with_failures(control_key, items, fail_count, pass_count, total_items)
        elif not_applicable_count > 0 and pass_count == 0 and fail_count == 0:
            self._mark_control_as_not_applicable(control_key, items, not_applicable_count)
        elif total_items > 0 and pass_count == 0 and fail_count == 0 and not_applicable_count == 0:
            # All results were None — no actual evidence for this control. Skip it entirely so
            # the integration only updates controls that the source system explicitly reported on.
            logger.debug(
                "Control %s: no evidence/compliance result (all None) - skipping (not updating SSP control status)",
                control_key,
            )
        else:
            logger.debug(f"Control {control_key} has unclear results: {dict(result_counts)}")

    def _count_results(self, result_counts: dict) -> tuple[int, int, int]:
        """Count pass, fail, and not applicable results from result counts."""
        fail_statuses_lower = [status.lower() for status in self.FAIL_STATUSES]
        pass_statuses_lower = [status.lower() for status in self.PASS_STATUSES]
        not_applicable_statuses_lower = [status.lower() for status in self.NOT_APPLICABLE_STATUSES]

        fail_count = 0
        pass_count = 0
        not_applicable_count = 0

        for result, count in result_counts.items():
            if result is None:  # Skip None results (controls without evidence)
                continue
            result_lower = result.lower()
            if result_lower in fail_statuses_lower:
                fail_count += count
            elif result_lower in pass_statuses_lower:
                pass_count += count
            elif result_lower in not_applicable_statuses_lower:
                not_applicable_count += count

        return fail_count, pass_count, not_applicable_count

    def _count_pass_fail_results(self, result_counts: dict) -> tuple[int, int]:
        """Count pass and fail results from result counts (legacy method)."""
        fail_count, pass_count, _ = self._count_results(result_counts)
        return fail_count, pass_count

    def _mark_control_as_passing(self, control_key: str, items: list, pass_count: int, fail_count: int) -> None:
        """Mark a control as passing."""
        self.passing_controls[control_key] = items[0]  # Use first item as representative
        logger.debug(f"Control {control_key} marked as PASSING: {pass_count}P/{fail_count}F")

    def _mark_control_as_not_applicable(self, control_key: str, items: list, not_applicable_count: int) -> None:
        """Mark a control as not applicable."""
        self.not_applicable_controls[control_key] = items[0]  # Use first item as representative
        logger.debug(f"Control {control_key} marked as NOT_APPLICABLE: {not_applicable_count} items")

    def _handle_control_with_failures(
        self,
        control_key: str,
        items: list,
        fail_count: int,
        pass_count: int,
        total_items: int,
    ) -> None:
        """Handle a control that has some failures."""
        fail_ratio = fail_count / total_items
        failure_threshold = getattr(self, "control_failure_threshold", 0.2)

        if fail_ratio > failure_threshold:
            self._mark_control_as_failing(
                control_key,
                items,
                pass_count,
                fail_count,
                fail_ratio,
                failure_threshold,
            )
        else:
            self._mark_control_as_passing_with_warnings(
                control_key,
                items,
                pass_count,
                fail_count,
                fail_ratio,
                failure_threshold,
            )

    def _mark_control_as_failing(
        self,
        control_key: str,
        items: list,
        pass_count: int,
        fail_count: int,
        fail_ratio: float,
        failure_threshold: float,
    ) -> None:
        """Mark a control as failing due to significant failures."""
        fail_statuses_lower = [status.lower() for status in self.FAIL_STATUSES]
        failing_item = next(item for item in items if item.compliance_result.lower() in fail_statuses_lower)
        self.failing_controls[control_key] = failing_item
        logger.debug(
            f"Control {control_key} marked as FAILING: {pass_count}P/{fail_count}F "
            f"({fail_ratio:.1%} fail rate > {failure_threshold:.1%} threshold)"
        )

    def _mark_control_as_passing_with_warnings(
        self,
        control_key: str,
        items: list,
        pass_count: int,
        fail_count: int,
        fail_ratio: float,
        failure_threshold: float,
    ) -> None:
        """Mark a control as passing despite low failure rate."""
        self.passing_controls[control_key] = items[0]
        logger.debug(
            f"Control {control_key} marked as PASSING (low fail rate): {pass_count}P/{fail_count}F "
            f"({fail_ratio:.1%} fail rate < {failure_threshold:.1%} threshold)"
        )

    def create_asset_from_compliance_item(self, compliance_item: ComplianceItem) -> Optional[IntegrationAsset]:
        """
        Create an IntegrationAsset from a compliance item.

        :param ComplianceItem compliance_item: The compliance item
        :return: IntegrationAsset or None
        :rtype: Optional[IntegrationAsset]
        """
        try:
            # Check if asset already exists
            existing_asset = self._find_existing_asset_by_resource_id(compliance_item.resource_id)
            if existing_asset:
                return None

            asset_type = self._map_resource_type_to_asset_type(compliance_item)

            asset = IntegrationAsset(
                name=compliance_item.resource_name,
                identifier=compliance_item.resource_id,
                external_id=compliance_item.resource_id,
                other_tracking_number=compliance_item.resource_id,  # For deduplication
                asset_type=asset_type,
                asset_category=regscale_models.AssetCategory.Hardware,
                description=f"Asset from {self.title} compliance scan",
                parent_id=self.plan_id,
                parent_module=self.parent_module,
                status=regscale_models.AssetStatus.Active,
                date_last_updated=self.scan_date,
            )

            return asset

        except Exception as e:
            logger.error(f"Error creating asset from compliance item: {e}")
            return None

    def create_finding_from_compliance_item(self, compliance_item: ComplianceItem) -> Optional[IntegrationFinding]:
        """
        Create an IntegrationFinding from a failed compliance item.

        :param ComplianceItem compliance_item: The compliance item
        :return: IntegrationFinding or None
        :rtype: Optional[IntegrationFinding]
        """
        try:
            control_labels = [compliance_item.control_id] if compliance_item.control_id else []
            severity = self._map_severity(compliance_item.severity)

            # Extract ARNs if available (for AWS Audit Manager and other integrations)
            arns = None
            arns_string = None
            if hasattr(compliance_item, "resource_arns"):
                arns = compliance_item.resource_arns
                # Only use ARNs if they're non-empty
                if arns:
                    # Convert array to comma-separated string for assetIdentifier field
                    arns_string = ", ".join(str(arn) for arn in arns) if isinstance(arns, list) else str(arns)
                else:
                    arns = None

            # Also check for pre-computed string value (preferred if available)
            if (
                hasattr(compliance_item, "issue_asset_identifier_value")
                and compliance_item.issue_asset_identifier_value
            ):
                arns_string = compliance_item.issue_asset_identifier_value

            finding = IntegrationFinding(
                control_labels=control_labels,
                title=f"Compliance Violation: {compliance_item.control_id}",
                category="Compliance",
                plugin_name=f"{self.title} Compliance Scanner",
                severity=severity,
                description=compliance_item.description,
                status=regscale_models.IssueStatus.Open,
                priority=self._map_severity_to_priority(severity),
                external_id=f"{self.title.lower()}-{compliance_item.control_id}-{compliance_item.resource_id}",
                first_seen=self.scan_date,
                last_seen=self.scan_date,
                scan_date=self.scan_date,
                asset_identifier=compliance_item.resource_id,
                issue_asset_identifier_value=arns_string,
                vulnerability_type="Compliance Violation",
                rule_id=compliance_item.control_id,
                baseline=compliance_item.framework,
                affected_controls=compliance_item.control_id,
            )

            # Ensure affected controls are set to the normalized control label (e.g., RA-5, AC-2(1))
            if compliance_item.control_id:
                base, sub = self._normalize_control_id(compliance_item.control_id)
                finding.affected_controls = f"{base}({sub})" if sub else base

            # Link finding to the matching control implementation so the issue is correctly
            # associated with the SSP control.  Uses the pre-built _control_lookup_cache
            # (keyed by all ID variations) for an O(1) case-insensitive match.
            if compliance_item.control_id and self._control_lookup_cache:
                for variation in self._control_matcher._get_control_id_variations(compliance_item.control_id):
                    if variation in self._control_lookup_cache:
                        impl, _ = self._control_lookup_cache[variation]
                        if impl and impl.id:
                            finding._control_implementation_ids = [impl.id]
                        break

            return finding

        except Exception as e:
            logger.error(f"Error creating finding from compliance item: {e}")
            return None

    def fetch_assets(self, *args, **kwargs) -> Iterator[IntegrationAsset]:
        """
        Fetch assets from compliance items, avoiding duplicates.

        :param args: Variable positional arguments
        :param kwargs: Variable keyword arguments
        :return: Iterator of integration assets
        :rtype: Iterator[IntegrationAsset]
        """
        logger.info("Fetching assets from compliance items...")

        # Load cache if not already loaded
        self._load_existing_records_cache()

        processed_resources = set()
        for compliance_item in self.all_compliance_items:
            if compliance_item.resource_id not in processed_resources:
                # Check if asset already exists in RegScale
                existing_asset = self._find_existing_asset_cached(compliance_item.resource_id)
                if existing_asset:
                    logger.debug(f"Asset already exists for resource {compliance_item.resource_id}, skipping creation")
                    processed_resources.add(compliance_item.resource_id)
                    continue

                asset = self.create_asset_from_compliance_item(compliance_item)
                if asset:
                    processed_resources.add(compliance_item.resource_id)
                    yield asset

    def _can_use_progress_method(self, method_name: str) -> bool:
        """Check if progress tracker has a specific method (backwards compatibility helper)."""
        return self.finding_progress is not None and hasattr(self.finding_progress, method_name)

    def _log_sample_failed_items(self) -> None:
        """Log a sample of failed compliance items for debugging."""
        if not self.failed_compliance_items:
            return

        sample_size = min(5, len(self.failed_compliance_items))
        sample = self.failed_compliance_items[:sample_size]
        logger.debug(f"Sample failed items (first {sample_size}):")
        for item in sample:
            logger.debug(
                f"  - Control: {item.control_id}, Result: {item.compliance_result}, Resource: {item.resource_id}"
            )

    def _warn_if_low_conversion_rate(self, findings_created: int, total: int) -> None:
        """Warn if finding conversion rate is below 90%."""
        if total == 0:
            return

        conversion_rate = findings_created / total * 100
        if conversion_rate < 90:
            missing_count = total - findings_created
            logger.warning(
                "Low finding conversion rate detected: %d/%d compliance items did not convert to findings (%.1f%%). "
                "Check create_finding_from_compliance_item() for None returns or filtering logic.",
                missing_count,
                total,
                100 - conversion_rate,
            )

    def fetch_findings(self, *args, **kwargs) -> Iterator[IntegrationFinding]:
        """
        Fetch findings from failed compliance items to create RegScale issues.

        :param args: Variable positional arguments
        :param kwargs: Variable keyword arguments
        :return: Iterator of integration findings (will be converted to RegScale Issue objects)
        :rtype: Iterator[IntegrationFinding]
        """
        expected_findings_count = len(self.failed_compliance_items)
        logger.info(f"Preparing to create issues from {expected_findings_count} failed compliance items...")
        self._expected_findings_count = expected_findings_count  # Store for validation

        self._log_sample_failed_items()

        total = len(self.failed_compliance_items)
        task_id = None
        if self._can_use_progress_method("add_task"):
            task_id = self.finding_progress.add_task(
                f"[#f68d1f]Creating issues from {total} failed compliance item(s)...",
                total=total or None,
            )

        findings_created = 0
        for compliance_item in self.failed_compliance_items:
            finding = self.create_finding_from_compliance_item(compliance_item)
            if finding:
                findings_created += 1
                if task_id is not None and self._can_use_progress_method("advance"):
                    self.finding_progress.advance(task_id, 1)
                yield finding

        # Complete progress task
        if total and task_id is not None and self._can_use_progress_method("update"):
            self.finding_progress.update(task_id, completed=total)

        conversion_rate = (findings_created / total * 100) if total > 0 else 0
        logger.info(
            f"Prepared {findings_created} issue records from {total} failed compliance items "
            f"(conversion rate: {conversion_rate:.1f}%)"
        )

        self._warn_if_low_conversion_rate(findings_created, total)

    def sync_compliance(self) -> None:
        """
        Main method to sync compliance data.

        This method orchestrates the entire compliance sync process:
        1. Process compliance data
        2. Create assets and findings
        3. Create/update control assessments
        4. Update control implementation status

        :return: None
        :rtype: None
        """
        logger.info(f"Starting {self.title} compliance sync...")

        try:
            scan_history = self.create_scan_history()
            self.process_compliance_data()

            self._sync_assets()
            self._sync_control_assessments()
            self._sync_issues()
            self._finalize_scan_history(scan_history)

            logger.info(f"Completed {self.title} compliance sync")

        except Exception as e:
            logger.error(f"Error during compliance sync: {e}")
            raise

    def _sync_assets(self) -> None:
        """
        Process and sync assets from compliance items.

        :return: None
        :rtype: None
        """
        assets = list(self.fetch_assets())
        if not assets:
            logger.debug("No assets generated from compliance items")
            return

        assets_processed = self.update_regscale_assets(iter(assets))
        self._log_asset_results(assets_processed)

        # Refresh the asset map after creating/updating assets to ensure
        # the map contains all assets for issue creation
        logger.debug("Refreshing asset map after asset sync...")
        self.asset_map_by_identifier.update(self.get_asset_map())

    def _log_asset_results(self, assets_processed: int) -> None:
        """
        Log asset processing results.

        :param int assets_processed: Number of assets processed
        :return: None
        :rtype: None
        """
        results = getattr(self, "_results", {}).get("assets", {})
        created = results.get("created_count", 0)
        updated = results.get("updated_count", 0)
        deleted = results.get("deleted_count", 0) if isinstance(results, dict) else 0

        if deleted > 0:
            logger.info(
                f"Assets processed: {assets_processed} (created: {created}, updated: {updated}, deleted: {deleted})"
            )
        elif created > 0 or updated > 0:
            logger.info(f"Assets processed: {assets_processed} (created: {created}, updated: {updated})")
        else:
            logger.debug(f"Assets processed: {assets_processed} (no changes made)")

    def _sync_control_assessments(self) -> None:
        """
        Process control assessments if enabled.

        :return: None
        :rtype: None
        """
        if self.update_control_status:
            self._process_control_assessments()

    def _log_sample_finding(self, findings: list) -> None:
        """Log a sample finding for debugging purposes."""
        self._ensure_handlers()
        self._compliance_issue_handler.log_sample_finding(findings)

    def _create_pending_issues_individually(self) -> tuple[int, list]:
        """Create pending issues via IssueHandler batch submission."""
        return self._compliance_issue_handler.create_pending_issues_individually()

    def _log_creation_failures(self, failed_issues: list, created_count: int, pending_count: int) -> None:
        """Log summary of issue creation failures."""
        self._compliance_issue_handler.log_creation_failures(failed_issues, created_count, pending_count)

    def _sync_issues(self) -> None:
        """
        Process and sync issues from failed compliance items.

        :return: None
        :rtype: None
        """
        self._compliance_issue_handler.sync_issues()

    def _validate_issue_creation_e2e(self, findings_processed: int, issues_created: int) -> None:
        """
        Validate end-to-end issue creation consistency.

        Compares expected findings count with actual issues created to detect:
        - Silent failures during finding-to-issue conversion
        - API rejections that don't raise exceptions
        - Deduplication or filtering that wasn't logged

        :param int findings_processed: Number of findings processed into issues
        :param int issues_created: Number of issues actually created in RegScale
        :return: None
        """
        self._compliance_issue_handler.validate_issue_creation_e2e(findings_processed, issues_created)

    def _process_findings_to_issues(self, findings: List[IntegrationFinding]) -> tuple[int, int]:
        """
        Process findings into issues and return counts.

        :param findings: List of findings to process
        :return: Tuple of (issues_created, issues_skipped)
        """
        return self._compliance_issue_handler.process_findings_to_issues(findings)

    def _process_single_finding(self, finding: IntegrationFinding) -> bool:
        """
        Process a single finding into an issue.

        :param finding: Finding to process
        :return: True if issue was created/updated, False if skipped
        """
        return self._compliance_issue_handler.process_single_finding(finding)

    def _finding_has_matching_control(self, finding: IntegrationFinding) -> bool:
        """
        Check whether a finding's control ID maps to a matched SSP implementation.

        Extracts the control ID from ``control_labels`` or ``rule_id`` and checks it
        against ``_matched_control_ids`` and ``_control_lookup_cache``.

        :param IntegrationFinding finding: The finding to check
        :return: True if the control has a matching SSP implementation
        :rtype: bool
        """
        control_id = None
        if finding.control_labels:
            control_id = (
                finding.control_labels[0] if isinstance(finding.control_labels, list) else finding.control_labels
            )
        if not control_id and finding.rule_id:
            control_id = finding.rule_id

        if not control_id:
            # No control association — let it through
            return True

        # Case-insensitive match against tracked controls (source data may differ in case)
        control_id_lower = control_id.lower()
        if any(cid.lower() == control_id_lower for cid in self._matched_control_ids):
            return True

        # Fallback: check the control lookup cache directly
        variations = self._control_matcher._get_control_id_variations(control_id)
        for variation in variations:
            if variation in self._control_lookup_cache:
                return True

        # Cross-framework fallback: translate the control and check if the translated ID matches
        crosswalk_match = self._try_cross_framework_match(control_id)
        if crosswalk_match[0] is not None:
            return True

        logger.warning(
            "Skipping issue for finding '%s' — control '%s' has no matching SSP implementation.",
            finding.external_id,
            control_id,
        )
        return False

    def _get_or_create_asset_for_finding(self, finding: IntegrationFinding) -> Optional[regscale_models.Asset]:
        """
        Get existing asset or create one on-demand for the finding.

        :param IntegrationFinding finding: Finding needing an asset
        :return: Asset if found/created, None otherwise
        :rtype: Optional[regscale_models.Asset]
        """
        return self._compliance_issue_handler.get_or_create_asset_for_finding(finding)

    def _log_asset_not_found_error(self, finding: IntegrationFinding) -> None:
        """
        Log error when asset is not found for a finding.

        :param IntegrationFinding finding: Finding with missing asset
        :return: None
        :rtype: None
        """
        self._compliance_issue_handler.log_asset_not_found_error(finding)

    def _log_issue_results(self, issues_created: int, issues_skipped: int) -> None:
        """
        Log issue processing results.
        DEPRECATED: Use _log_issue_results_accurate for accurate reporting.

        :param int issues_created: Number of issues created/updated
        :param int issues_skipped: Number of issues skipped
        :return: None
        :rtype: None
        """
        self._compliance_issue_handler.log_issue_results(issues_created, issues_skipped)

    def _log_issue_results_accurate(
        self,
        issues_created: int,
        issues_updated: int,
        findings_processed: int,
        findings_skipped: int,
    ) -> None:
        """
        Log accurate issue processing results based on actual database operations.

        :param int issues_created: Number of new issues created in database
        :param int issues_updated: Number of existing issues updated in database
        :param int findings_processed: Number of findings that were processed
        :param int findings_skipped: Number of findings that were skipped
        :return: None
        :rtype: None
        """
        self._compliance_issue_handler.log_issue_results_accurate(
            issues_created, issues_updated, findings_processed, findings_skipped
        )

    def _finalize_scan_history(self, scan_history: regscale_models.ScanHistory) -> None:
        """
        Finalize scan history with error handling.

        :param regscale_models.ScanHistory scan_history: Scan history to update
        :return: None
        :rtype: None
        """
        try:
            if getattr(self, "enable_scan_history", True):
                self._update_scan_history(scan_history)
        except Exception:
            self._update_scan_history(scan_history)

    def _ensure_asset_for_finding(self, finding: IntegrationFinding) -> Optional[regscale_models.Asset]:
        """
        Ensure an asset exists for the given finding.

        Attempts to locate the asset by identifier. If missing, it will try to
        build an IntegrationAsset from the first compliance item associated with
        the resource id and upsert it into RegScale, then return the created asset.

        :param IntegrationFinding finding: Finding referencing the asset identifier
        :return: The located or newly created Asset, or None if it cannot be created
        :rtype: Optional[regscale_models.Asset]
        """
        return self._compliance_issue_handler.ensure_asset_for_finding(finding)

    def _process_control_assessments(self) -> None:
        """
        Process control assessments based on compliance results.

        This follows the same pattern as the original Wiz compliance integration:
        1. Get control implementations
        2. For each implementation, get the security control using controlID
        3. Match the security control's controlId with the extracted control ID from compliance items

        :return: None
        :rtype: None
        """
        self._ensure_handlers()
        self._compliance_assessment_handler.process_control_assessments()

    def _get_control_implementations(self) -> List[ControlImplementation]:
        """
        Get all control implementations for the current plan with embedded SecurityControl objects.

        Uses the bulk endpoint (getAllByPlanWithControls) which returns implementations with
        their SecurityControl data in a single API call, eliminating N+1 queries during
        cache building.

        :return: List of control implementations with control field populated
        :rtype: List[ControlImplementation]
        """
        return self._compliance_assessment_handler.get_control_implementations()

    def _build_control_lookup_cache(self, implementations: List[ControlImplementation]) -> None:
        """
        Build a lookup cache mapping control ID variations to implementations and security controls.

        This dramatically improves performance by:
        1. Fetching all SecurityControl objects once (instead of once per match attempt)
        2. Pre-computing all control ID variations
        3. Creating a dictionary for O(1) lookup instead of O(n) iteration

        For 1011 implementations x 71 controls = 71,781 iterations in the old code.
        New code: 1011 fetches + 71 dictionary lookups = ~1082 operations (67x faster!)

        Also builds a reverse cache (_impl_to_control_id_cache) mapping implementation IDs
        to control IDs for better logging.

        :param List[ControlImplementation] implementations: List of control implementations to cache
        :return: None
        :rtype: None
        """
        self._compliance_assessment_handler.build_control_lookup_cache(implementations)

    def _cache_single_implementation(self, implementation: ControlImplementation) -> None:
        """
        Cache a single implementation's control ID variations.

        Uses the pre-loaded control field from the bulk API call when available,
        falling back to individual fetch only if needed.

        :param ControlImplementation implementation: The implementation to cache
        :return: None
        :rtype: None
        """
        self._compliance_assessment_handler.cache_single_implementation(implementation)

    def _add_variations_to_cache(
        self,
        variations: List[str],
        implementation: ControlImplementation,
        security_control: SecurityControl,
    ) -> None:
        """
        Add control ID variations to the lookup cache.

        :param List[str] variations: Control ID variations to add
        :param ControlImplementation implementation: The implementation to cache
        :param SecurityControl security_control: The security control to cache
        :return: None
        :rtype: None
        """
        self._compliance_assessment_handler.add_variations_to_cache(variations, implementation, security_control)

    def _log_cached_frameworks_debug(self) -> None:
        """
        Log sample controls grouped by framework type for debugging.

        :return: None
        :rtype: None
        """
        self._compliance_assessment_handler.log_cached_frameworks_debug()

    def _log_sample_controls(self, implementations: List[ControlImplementation]) -> None:
        """
        Log sample control IDs for debugging purposes.

        :param List[ControlImplementation] implementations: List of implementations to sample from
        :return: None
        :rtype: None
        """
        self._compliance_assessment_handler.log_sample_controls(implementations)

    def _process_single_control_assessment(
        self,
        *,
        control_id: str,
        implementations: List[ControlImplementation],
        processed_impl_today: set[int],
    ) -> int:
        """
        Process assessment for a single control.

        :param str control_id: Control identifier to process
        :param List[ControlImplementation] implementations: Available control implementations
        :param set[int] processed_impl_today: Set of implementation IDs already processed today
        :return: Number of assessments created (0 or 1)
        :rtype: int
        """
        return self._compliance_assessment_handler.process_single_control_assessment(
            control_id=control_id,
            implementations=implementations,
            processed_impl_today=processed_impl_today,
        )

    def _get_iso_parent_control_variations(self, control_id: str) -> set:
        """
        For ISO 27001 subcontrols (e.g. A.12.4.3), return parent control ID variations
        so we can match to top-level controls in the SSP (e.g. 12.4, 12).

        :param str control_id: Control ID from source (e.g. a.12.4.3, 12.4.3)
        :return: Set of parent variations to try in lookup cache, or empty set
        :rtype: set
        """
        if not control_id:
            return set()
        raw = control_id.strip()
        if raw.lower().startswith("a."):
            raw = raw[2:].strip()
        parts = raw.split(".")
        # Need at least 3 segments to have a parent (e.g. 12.4.3 -> 12.4, 12)
        if len(parts) < 3:
            return set()
        out = set()
        for i in range(len(parts) - 1, 0, -1):
            parent = ".".join(parts[:i])
            out.add(parent)
            out.add("a." + parent)
            out.add("A." + parent)
        return out

    def _init_cross_framework_mapper(self, source_control_ids: List[str]) -> None:
        """
        Initialize cross-framework mapper when SSP and source frameworks differ.

        Lazily creates a CrossFrameworkMapper instance only when needed, storing it
        as ``self._cross_framework_mapper`` for use in ``_try_cross_framework_match``.

        :param List[str] source_control_ids: Control IDs from the source data
        """
        ssp_fw = self._detect_ssp_framework()
        source_fw = self._detect_source_framework(source_control_ids)

        if not ssp_fw or not source_fw:
            if not ssp_fw:
                logger.warning("Could not detect SSP framework — cross-framework matching disabled.")
            if not source_fw:
                logger.warning("Could not detect source data framework — cross-framework matching disabled.")
            return

        if ssp_fw == source_fw:
            logger.debug("SSP and source share the same framework (%s) — crosswalk not needed.", ssp_fw)
            return

        try:
            from regscale.integrations.cross_framework_mapper import CrossFrameworkMapper
        except ImportError as e:
            logger.error(
                "CrossFrameworkMapper unavailable — cross-framework matching disabled. "
                "Control mappings between %s and %s will not work. Error: %s",
                source_fw,
                ssp_fw,
                e,
            )
            return

        mapper = CrossFrameworkMapper()
        if mapper.has_crosswalk(source_fw, ssp_fw):
            self._cross_framework_mapper = mapper
            logger.info(
                "Cross-framework mapper initialized: %s -> %s",
                source_fw,
                ssp_fw,
            )
        else:
            logger.warning(
                "Framework mismatch detected (source=%s, SSP=%s) but no crosswalk data available. "
                "Controls will not be matched across frameworks. "
                "Assessments and issues may be incomplete.",
                source_fw,
                ssp_fw,
            )

    def _try_cross_framework_match(
        self, control_id: str
    ) -> tuple[Optional[ControlImplementation], Optional[SecurityControl]]:
        """
        Attempt to match a control ID by translating it via the cross-framework mapper.

        :param str control_id: Source control ID that did not match directly
        :return: Matching (implementation, security_control) or (None, None)
        :rtype: tuple[Optional[ControlImplementation], Optional[SecurityControl]]
        """
        mapper = getattr(self, "_cross_framework_mapper", None)
        source_fw = getattr(self, "_detected_source_framework", None)
        ssp_fw = getattr(self, "_detected_ssp_framework", None)
        if not mapper or not source_fw or not ssp_fw:
            return None, None

        translated = mapper.map_controls(
            source_fw,
            ssp_fw,
            [control_id],
        )
        target_ids = translated.get(control_id, [])
        if not target_ids:
            return None, None

        if len(target_ids) > 1:
            logger.info(
                "Control '%s' maps to %d SSP controls via crosswalk: %s",
                control_id,
                len(target_ids),
                target_ids,
            )

        for target_id in target_ids:
            target_variations = self._control_matcher._get_control_id_variations(target_id)
            for variation in target_variations:
                if variation in self._control_lookup_cache:
                    implementation, security_control = self._control_lookup_cache[variation]
                    logger.info(
                        "MATCH FOUND (crosswalk): '%s' -> '%s' -> '%s' (implementation: %s)",
                        control_id,
                        target_id,
                        security_control.controlId,
                        implementation.id,
                    )
                    # Track both source and translated IDs for consistent filtering
                    matched_ids = getattr(self, "_matched_control_ids", None)
                    if matched_ids is not None:
                        matched_ids.add(control_id)
                        matched_ids.add(target_id)
                    return implementation, security_control

        return None, None

    def _find_matching_implementation(
        self, control_id: str, implementations: List[ControlImplementation]
    ) -> tuple[Optional[ControlImplementation], Optional[SecurityControl]]:
        """
        Find matching implementation and security control for a control ID.

        Uses ControlMatcher for robust control ID matching with leading zero normalization.
        Performance optimized with pre-built lookup cache for O(1) matching.

        :param str control_id: Control identifier to match
        :param List[ControlImplementation] implementations: Available implementations (used for fallback only)
        :return: Tuple of matching implementation and security control, or (None, None)
        :rtype: tuple[Optional[ControlImplementation], Optional[SecurityControl]]
        """
        return self._compliance_assessment_handler.find_matching_implementation(control_id, implementations)

    def _log_no_match(self, control_id: str, implementations: List[ControlImplementation]) -> None:
        """
        Log when no matching implementation is found for a control.

        :param str control_id: Control identifier that couldn't be matched
        :param List[ControlImplementation] implementations: Available implementations for context
        :return: None
        :rtype: None
        """
        self._compliance_assessment_handler.log_no_match(control_id, implementations)

    def _determine_overall_result(self, control_id: str) -> str:
        """
        Determine overall assessment result for a control.

        :param str control_id: Control identifier to check
        :return: Assessment result ('Pass', 'Fail', or 'Not Applicable')
        :rtype: str
        """
        return self._compliance_assessment_handler.determine_overall_result(control_id)

    def _get_control_compliance_items(self, control_id: str) -> List[ComplianceItem]:
        """
        Get all compliance items for a specific control, supporting multi-control items.

        Uses get_all_control_ids() when available so that items mapping to multiple
        controls (e.g., Wiz rows with comma-separated control references) are matched
        for every control they reference, not just the first.

        :param str control_id: Control identifier to filter by
        :return: List of compliance items for the control
        :rtype: List[ComplianceItem]
        """
        return self._compliance_assessment_handler.get_control_compliance_items(control_id)

    def _record_control_mapping(self, control_id: str, implementation_id: int) -> None:
        """
        Record mapping between normalized control ID and implementation ID.

        :param str control_id: Control identifier to map
        :param int implementation_id: Implementation ID to associate
        :return: None
        :rtype: None
        """
        self._compliance_assessment_handler.record_control_mapping(control_id, implementation_id)

    @staticmethod
    def _parse_control_id(control_id: str) -> tuple[str, Optional[str]]:
        """
        Parse a control id like 'AC-2(1)', 'AC-2 (1)', 'AC-2-1' into (base, sub).
        Normalizes leading zeros (e.g., AC-01 becomes AC-1).

        Returns (base, None) when no subcontrol.

        :param str control_id: Control identifier to parse
        :return: Tuple of (base_control, subcontrol) where subcontrol may be None
        :rtype: tuple[str, Optional[str]]
        """
        cid = control_id.strip()
        # Use precompiled safe regex to avoid catastrophic backtracking on crafted input
        m = SAFE_CONTROL_ID_RE.match(cid)
        if not m:
            return cid.upper(), None
        base = m.group(1).upper()
        # Normalize leading zeros in base control number (e.g., AC-01 -> AC-1)
        if "-" in base:
            prefix, number = base.split("-", 1)
            try:
                normalized_number = str(int(number))
                base = f"{prefix}-{normalized_number}"
            except ValueError:
                pass  # Keep original if conversion fails
        # Subcontrol may be captured in group 2, 3, or 4 depending on the branch matched
        sub = m.group(2) or m.group(3) or m.group(4)
        # Normalize leading zeros in subcontrol (e.g., 01 -> 1)
        if sub:
            try:
                sub = str(int(sub))
            except ValueError:
                pass  # Keep original if conversion fails
        return base, sub

    @classmethod
    def _control_ids_match(cls, a: str, b: str) -> bool:
        """
        Strict match of control ids. Exact match if equal.
        If subcontrols exist on either side, both must exist and be equal.

        :param str a: First control ID to compare
        :param str b: Second control ID to compare
        :return: True if control IDs match according to strict rules
        :rtype: bool
        """
        if not a or not b:
            return False
        if a.strip().lower() == b.strip().lower():
            return True
        base_a, sub_a = cls._parse_control_id(a)
        base_b, sub_b = cls._parse_control_id(b)
        if base_a != base_b:
            return False
        # If either has a subcontrol, require both and equality
        if sub_a or sub_b:
            return (sub_a is not None) and (sub_b is not None) and (sub_a == sub_b)
        # No subcontrols -> base equals
        return True

    @staticmethod
    def _normalize_control_id(control_id: str) -> tuple[str, Optional[str]]:
        """
        Normalize control id to a canonical tuple (BASE, SUB) for set membership.
        Normalizes leading zeros (e.g., AC-01 becomes AC-1).

        :param str control_id: Control identifier to normalize
        :return: Tuple of (base_control, subcontrol) in canonical form
        :rtype: tuple[str, Optional[str]]
        """
        cid = (control_id or "").strip()
        # Use precompiled safe regex to avoid catastrophic backtracking on crafted input
        m = SAFE_CONTROL_ID_RE.match(cid)
        if not m:
            return cid.upper(), None
        base = m.group(1).upper()
        # Normalize leading zeros in base control number (e.g., AC-01 -> AC-1)
        if "-" in base:
            prefix, number = base.split("-", 1)
            try:
                normalized_number = str(int(number))
                base = f"{prefix}-{normalized_number}"
            except ValueError:
                pass  # Keep original if conversion fails
        sub = m.group(2) or m.group(3) or m.group(4)
        # Normalize leading zeros in subcontrol (e.g., 01 -> 1)
        if sub:
            try:
                sub = str(int(sub))
            except ValueError:
                pass  # Keep original if conversion fails
        return base, sub

    def _create_control_assessment(
        self,
        implementation: ControlImplementation,
        catalog_control: Dict,
        result: str,
        control_id: str,
        compliance_items: List[ComplianceItem] = None,
    ) -> None:
        """
        Create or update an assessment for a control implementation.
        If an assessment for the same day exists, update it instead of creating a duplicate.

        :param ControlImplementation implementation: The control implementation to assess
        :param Dict catalog_control: The catalog control data dictionary
        :param str result: Assessment result ('Pass' or 'Fail')
        :param str control_id: Control identifier string
        :param List[ComplianceItem] compliance_items: Pre-aggregated compliance items for this control
        :return: None
        :rtype: None
        """
        self._compliance_assessment_handler.create_control_assessment(
            implementation=implementation,
            catalog_control=catalog_control,
            result=result,
            control_id=control_id,
            compliance_items=compliance_items,
        )

    def _get_compliance_items_for_control(
        self, control_id: str, compliance_items: List[ComplianceItem] = None
    ) -> List[ComplianceItem]:
        """Get compliance items for a control, either from provided list or by filtering.

        Supports multi-control items by checking all control IDs via
        _get_all_control_ids_for_item() instead of only item.control_id.
        """
        return self._compliance_assessment_handler.get_compliance_items_for_control(control_id, compliance_items)

    def _get_day_key_from_scan_date(self) -> str:
        """Extract day key from scan_date for cache indexing."""
        return self._compliance_assessment_handler.get_day_key_from_scan_date()

    def _track_assessment_for_today(self, implementation_id: int, assessment) -> None:
        """Track assessment by implementation ID for linking to issues later."""
        self._compliance_assessment_handler.track_assessment_for_today(implementation_id, assessment)

    def _update_existing_control_assessment(
        self, existing_assessment, result: str, assessment_report: str, control_id: str, implementation_id: int
    ) -> None:
        """Update an existing assessment with new report and refresh caches."""
        self._compliance_assessment_handler.update_existing_control_assessment(
            existing_assessment,
            result,
            assessment_report,
            control_id,
            implementation_id,
        )

    def _create_new_control_assessment(
        self, implementation: ControlImplementation, control_id: str, result: str, assessment_report: str
    ) -> None:
        """Create a new assessment and add it to caches."""
        self._compliance_assessment_handler.create_new_control_assessment(
            implementation,
            control_id,
            result,
            assessment_report,
        )

    def _find_existing_assessment(self, implementation: ControlImplementation, scan_date) -> Optional:
        """
        Find existing assessment for the same implementation on the same day.
        DEPRECATED: Use _find_existing_assessment_cached instead.

        :param ControlImplementation implementation: The control implementation
        :param scan_date: The scan date to check
        :return: Existing assessment or None
        :rtype: Optional[regscale_models.Assessment]
        """
        return self._compliance_assessment_handler.find_existing_assessment(implementation, scan_date)

    def _create_assessment_report(self, control_id: str, result: str, compliance_items: List[ComplianceItem]) -> str:
        """
        Create HTML assessment report.

        :param str control_id: Control identifier
        :param str result: Assessment result ('Pass' or 'Fail')
        :param List[ComplianceItem] compliance_items: Compliance items for this control
        :return: Formatted HTML report string
        :rtype: str
        """
        self._ensure_handlers()
        return self._compliance_report_handler.create_assessment_report(control_id, result, compliance_items)

    def _create_report_header(
        self, control_id: str, result: str, result_color: str, compliance_items: List[ComplianceItem]
    ) -> str:
        """Create the header section of the assessment report."""
        return self._compliance_report_handler.create_report_header(control_id, result, result_color, compliance_items)

    def _calculate_assessment_statistics(self, compliance_items: List[ComplianceItem]) -> Dict:
        """Calculate compliance statistics from compliance items."""
        return self._compliance_report_handler.calculate_assessment_statistics(compliance_items)

    @staticmethod
    def _get_policy_name_for_item(item: ComplianceItem) -> str:
        """
        Extract a human-readable policy/check name from a compliance item.

        Checks integration-specific attributes (policy_name for Wiz, policy dict for AWS)
        before falling back to the generic description.

        :param ComplianceItem item: Compliance item to extract policy name from
        :return: Policy name string
        :rtype: str
        """
        # Wiz items have a policy_name attribute with the actual check name
        if hasattr(item, "policy_name") and item.policy_name:
            return item.policy_name
        # AWS Audit Manager items store policy as a dict
        if hasattr(item, "policy") and isinstance(item.policy, dict):
            return item.policy.get("name", "Unknown Policy")
        # Generic fallback — use description truncated to a reasonable length
        if hasattr(item, "description") and item.description:
            desc = item.description
            return desc[:80] + "..." if len(desc) > 80 else desc
        return "Unknown Policy"

    def _collect_unique_resources_and_policies(self, compliance_items: List[ComplianceItem]) -> tuple[set, set]:
        """Collect unique resources and policies from compliance items."""
        return self._compliance_report_handler.collect_unique_resources_and_policies(compliance_items)

    def _create_summary_section(
        self,
        control_id: str,
        result: str,
        result_color: str,
        stats: Dict,
        compliance_items: List[ComplianceItem],
        unique_resources: set,
        unique_policies: set,
    ) -> str:
        """Create the aggregated assessment summary section."""
        return self._compliance_report_handler.create_summary_section(
            control_id, result, result_color, stats, compliance_items, unique_resources, unique_policies
        )

    def _create_policies_tested_section(self, compliance_items: List[ComplianceItem]) -> str:
        """
        Create a section listing what policies/checks were evaluated and their results.

        Groups compliance items by policy name and shows each policy's result
        along with the resources it was tested against.

        :param List[ComplianceItem] compliance_items: Compliance items for this control
        :return: HTML section with per-policy details
        :rtype: str
        """
        return self._compliance_report_handler.create_policies_tested_section(compliance_items)

    def _create_failure_details_section(self, failed_items: List[ComplianceItem]) -> str:
        """
        Create detailed failure information section for failed compliance items.

        :param List[ComplianceItem] failed_items: List of failed compliance items
        :return: HTML section with detailed failure information
        :rtype: str
        """
        return self._compliance_report_handler.create_failure_details_section(failed_items)

    def _get_failure_section_header(self) -> str:
        """Get the HTML header for failure details section."""
        return self._compliance_report_handler.get_failure_section_header()

    def _process_failed_item(self, idx: int, item: ComplianceItem) -> str:
        """
        Process a single failed item and return HTML.

        :param int idx: The index of the failed item
        :param ComplianceItem item: The failed compliance item
        :return: HTML for the failed item
        :rtype: str
        """
        return self._compliance_report_handler.process_failed_item(idx, item)

    def _has_aws_evidence(self, item: ComplianceItem) -> bool:
        """Check if item has AWS Audit Manager evidence."""
        return self._compliance_report_handler.has_aws_evidence(item)

    def _process_aws_item_with_evidence(self, idx: int, item: ComplianceItem) -> str:
        """Process AWS item with evidence details."""
        return self._compliance_report_handler.process_aws_item_with_evidence(idx, item)

    def _categorize_evidence(self, item: ComplianceItem) -> Dict[str, List[Any]]:
        """
        Categorize evidence items by compliance status.

        :param ComplianceItem item: The compliance item with evidence
        :return: Dictionary with categorized evidence
        :rtype: Dict[str, List[Any]]
        """
        return self._compliance_report_handler.categorize_evidence(item)

    def _get_evidence_compliance_check(self, item: ComplianceItem, evidence: Any) -> Optional[str]:
        """Get compliance check result for evidence."""
        return self._compliance_report_handler.get_evidence_compliance_check(item, evidence)

    def _create_failed_check_header(
        self, idx: int, item: ComplianceItem, evidence_categories: Dict[str, List[Any]]
    ) -> str:
        """Create HTML header for failed check."""
        return self._compliance_report_handler.create_failed_check_header(idx, item, evidence_categories)

    def _create_failed_evidence_details(self, failed_evidence: List[Any]) -> str:
        """Create HTML for failed evidence details."""
        return self._compliance_report_handler.create_failed_evidence_details(failed_evidence)

    def _format_single_evidence(self, evidence: Dict[str, Any]) -> str:
        """Format a single evidence item as HTML."""
        return self._compliance_report_handler.format_single_evidence(evidence)

    def _get_resources_info(self, evidence: Dict[str, Any]) -> List[str]:
        """Extract resource information from evidence."""
        return self._compliance_report_handler.get_resources_info(evidence)

    def _format_resource(self, resource: Dict[str, Any]) -> Optional[str]:
        """Format a single resource as a string."""
        return self._compliance_report_handler.format_resource(resource)

    def _add_remediation_guidance(self, item: ComplianceItem) -> str:
        """Add remediation guidance if available."""
        return self._compliance_report_handler.add_remediation_guidance(item)

    def _process_non_aws_item(self, idx: int, item: ComplianceItem) -> str:
        """Process non-AWS items or items without evidence."""
        return self._compliance_report_handler.process_non_aws_item(idx, item)

    def _get_item_description(self, item: ComplianceItem) -> str:
        """Get description from item without truncation to show full failure details."""
        return self._compliance_report_handler.get_item_description(item)

    def _get_security_plan(self) -> Optional[regscale_models.SecurityPlan]:
        """
        Get the security plan for this integration.

        :return: SecurityPlan instance or None
        :rtype: Optional[regscale_models.SecurityPlan]
        """
        return self._compliance_assessment_handler.get_security_plan()

    def _get_compliance_settings(self) -> Optional[regscale_models.ComplianceSettings]:
        """
        Get compliance settings for the security plan.

        :return: ComplianceSettings instance or None
        :rtype: Optional[regscale_models.ComplianceSettings]
        """
        return self._compliance_assessment_handler.get_compliance_settings()

    def _has_valid_compliance_settings_id(self, security_plan) -> bool:
        """Check if security plan has valid compliance settings ID."""
        return self._compliance_assessment_handler.has_valid_compliance_settings_id(security_plan)

    def _fetch_compliance_settings(self, security_plan) -> Optional[regscale_models.ComplianceSettings]:
        """Fetch and log compliance settings."""
        return self._compliance_assessment_handler.fetch_compliance_settings(security_plan)

    def _log_missing_compliance_settings_reason(self, security_plan) -> None:
        """Log specific reason why compliance settings are not available."""
        self._compliance_assessment_handler.log_missing_compliance_settings_reason(security_plan)

    def _detect_compliance_framework(self) -> str:
        """
        Detect the compliance framework from the integration's framework attribute.

        Used as a fallback when no compliance settings are available.

        :return: Framework name ("DoD", "FedRAMP", "NIST", or "Default")
        :rtype: str
        """
        return self._compliance_assessment_handler.detect_compliance_framework()

    def _get_implementation_status_from_result(self, result: str, override: Optional[str] = None) -> str:
        """
        Get implementation status based on assessment result using enum-based mappings.
        Results are cached to avoid repeated calculations for the same input.

        :param str result: Assessment result ('Pass', 'Fail', 'Not Applicable', etc.)
        :param Optional[str] override: Optional override value to use instead of the mapping
        :return: Implementation status string
        :rtype: str
        """
        return self._compliance_assessment_handler.get_implementation_status_from_result(result, override)

    def _update_implementation_status(self, implementation: ControlImplementation, result: str) -> None:
        """
        Update control implementation status based on assessment result.
        Uses compliance settings from the security plan if available, otherwise falls back to defaults.

        :param ControlImplementation implementation: Control implementation to update
        :param str result: Assessment result ('Pass' or 'Fail')
        :return: None
        :rtype: None
        """
        self._compliance_assessment_handler.update_implementation_status(implementation, result)

    def _get_controls(self) -> List[Dict]:
        """
        Get controls from catalog or plan.

        :return: List of control dictionaries from catalog or plan
        :rtype: List[Dict]
        """
        if self.catalog_id:
            catalog = Catalog.get_with_all_details(catalog_id=self.catalog_id)
            return catalog.get("controls", []) if catalog else []
        else:
            return SecurityControl.get_controls_by_parent_id_and_module(
                parent_module=self.parent_module,
                parent_id=self.plan_id,
                return_dicts=True,
            )

    def _find_existing_asset_by_resource_id(self, resource_id: str) -> Optional[regscale_models.Asset]:
        """
        Find existing asset by resource ID.

        :param str resource_id: Resource identifier to search for
        :return: Existing asset or None if not found
        :rtype: Optional[regscale_models.Asset]
        """
        try:
            if hasattr(self, "asset_map_by_identifier") and self.asset_map_by_identifier:
                return self.asset_map_by_identifier.get(resource_id)

            # Query database
            existing_assets = regscale_models.Asset.get_all_by_parent(
                parent_id=self.plan_id,
                parent_module=self.parent_module,
            )

            for asset in existing_assets:
                if hasattr(asset, "otherTrackingNumber") and asset.otherTrackingNumber == resource_id:
                    return asset

            return None

        except Exception as e:
            logger.error(f"Error finding existing asset: {e}")
            return None

    def _map_resource_type_to_asset_type(self, compliance_item: ComplianceItem) -> str:
        """
        Map compliance item resource type to RegScale asset type.

        :param ComplianceItem compliance_item: Compliance item with resource type information
        :return: Asset type string suitable for RegScale
        :rtype: str
        """
        # Default implementation - can be overridden by subclasses
        return "Cloud Resource"

    def _map_severity(self, severity: Optional[str]) -> regscale_models.IssueSeverity:
        """
        Map compliance severity to RegScale severity.

        :param Optional[str] severity: Severity string from compliance source
        :return: Mapped RegScale severity enum value
        :rtype: regscale_models.IssueSeverity
        """
        if not severity:
            return regscale_models.IssueSeverity.Moderate

        severity_mapping = {
            "CRITICAL": regscale_models.IssueSeverity.Critical,
            "HIGH": regscale_models.IssueSeverity.High,
            "MEDIUM": regscale_models.IssueSeverity.Moderate,
            "LOW": regscale_models.IssueSeverity.Low,
        }

        return severity_mapping.get(severity.upper(), regscale_models.IssueSeverity.Moderate)

    def _map_severity_to_priority(self, severity: regscale_models.IssueSeverity) -> str:
        """
        Map severity to priority string.

        :param regscale_models.IssueSeverity severity: Issue severity enum value
        :return: Priority string for issues
        :rtype: str
        """
        priority_mapping = {
            regscale_models.IssueSeverity.Critical: "Critical",
            regscale_models.IssueSeverity.High: "High",
            regscale_models.IssueSeverity.Moderate: "Medium",
            regscale_models.IssueSeverity.Low: "Low",
        }

        return priority_mapping.get(severity, "Medium")

    def _update_scan_history(self, scan_history: regscale_models.ScanHistory) -> None:
        """
        Update scan history with results.

        :param regscale_models.ScanHistory scan_history: Scan history record to update
        :return: None
        :rtype: None
        """
        try:
            scan_history.dateLastUpdated = get_current_datetime()
            scan_history.save()
            logger.debug(f"Updated scan history {scan_history.id}")
        except Exception as e:
            logger.error(f"Error updating scan history: {e}")

    def create_scan_history(self) -> regscale_models.ScanHistory:
        """
        Create or reuse a ScanHistory for the same day and tool.

        If a scan history exists for this plan/module with the same
        scanning tool and scan date (day-level), update and reuse it
        instead of creating a duplicate.

        :return: Created or reused scan history record
        :rtype: regscale_models.ScanHistory
        """
        try:
            # Load existing scans for the plan/module
            existing_scans = regscale_models.ScanHistory.get_all_by_parent(
                parent_id=self.plan_id, parent_module=self.parent_module
            )

            # Normalize target date to date component only
            target_dt = self.scan_date
            target_date_only = target_dt.split("T")[0] if isinstance(target_dt, str) else str(target_dt)[:10]

            # Find an existing scan for today and this tool
            for scan in existing_scans:
                try:
                    if getattr(scan, "scanningTool", None) == self.title and getattr(scan, "scanDate", None):
                        scan_date = str(scan.scanDate)
                        scan_date_only = scan_date.split("T")[0]
                        if scan_date_only == target_date_only:
                            # Reuse this scan history; refresh last updated
                            scan.dateLastUpdated = get_current_datetime()
                            scan.save()
                            return scan
                except Exception:
                    # Skip any malformed scan records
                    continue

            # No existing same-day scan found, create new via base behavior
            return super().create_scan_history()
        except Exception:
            # Fallback: create new scan history
            return super().create_scan_history()

    def _update_issue_affected_controls(
        self, existing_issue: regscale_models.Issue, finding: IntegrationFinding
    ) -> None:
        """Update the affectedControls field from finding data."""
        self._compliance_issue_handler.update_issue_affected_controls(existing_issue, finding)

    def _extract_control_from_finding(self, finding: IntegrationFinding) -> str | None:
        """Extract control ID from finding's rule_id or control_labels."""
        return self._compliance_issue_handler.extract_control_from_finding(finding)

    def _create_new_issue(self, title: str, finding: IntegrationFinding, external_id: str) -> regscale_models.Issue:
        """Create a new issue from finding data."""
        return self._compliance_issue_handler.create_new_issue(title, finding, external_id)

    def create_or_update_issue_from_finding(self, title: str, finding: IntegrationFinding) -> regscale_models.Issue:
        """
        Create an issue from a finding and queue it for batch submission.

        Deduplication is handled server-side by the BatchCreateOrUpdate API.

        :param str title: Issue title
        :param IntegrationFinding finding: The finding to create issue from
        :return: Created issue
        :rtype: regscale_models.Issue
        """
        return self._compliance_issue_handler.create_or_update_issue_from_finding(title, finding)

    def _create_milestones_for_updated_issue(
        self,
        issue: regscale_models.Issue,
        finding: IntegrationFinding,
        original_issue: regscale_models.Issue,
    ) -> None:
        """
        Create milestones for an updated issue in compliance integration.

        This method handles both status transition milestones and backfilling of missing
        creation milestones for existing issues.

        :param regscale_models.Issue issue: The updated issue
        :param IntegrationFinding finding: The finding data
        :param regscale_models.Issue original_issue: Original state for comparison
        """
        self._compliance_issue_handler.create_milestones_for_updated_issue(issue, finding, original_issue)
