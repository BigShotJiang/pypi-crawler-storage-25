#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Scanner Variables"""

import logging

from regscale.core.app.utils.variables import RsVariablesMeta, RsVariableType

logger = logging.getLogger("regscale")

_ISSUE_CREATION_DEPRECATION_WARNED = False


def get_vulnerability_creation_mode() -> str:
    """Return the effective vulnerabilityCreation mode, mapping deprecated values.

    'IssueCreation' was renamed to 'PoamCreation' in 6.33.x. Callers that still
    have 'IssueCreation' in their init.yaml receive a one-time deprecation warning
    and the value is silently promoted to 'PoamCreation' so existing pipelines
    keep working until they can migrate.

    :return: Normalised vulnerabilityCreation value ('NoIssue' or 'PoamCreation')
    :rtype: str
    """
    global _ISSUE_CREATION_DEPRECATION_WARNED  # noqa: PLW0603
    value = getattr(ScannerVariables, "vulnerabilityCreation", "NoIssue") or "NoIssue"
    if value.lower() == "issuecreation":
        if not _ISSUE_CREATION_DEPRECATION_WARNED:
            logger.warning(
                "vulnerabilityCreation='IssueCreation' is deprecated and will be removed in a future release. "
                "Update your init.yaml or CLI flag to use 'PoamCreation' instead. "
                "Auto-mapping to 'PoamCreation' for this run."
            )
            _ISSUE_CREATION_DEPRECATION_WARNED = True
        return "PoamCreation"
    return value


class ScannerVariables(metaclass=RsVariablesMeta):
    """
    Scanner Variables class to define class-level attributes with type annotations and examples
    """

    # Define class-level attributes with type annotations and examples
    issueCreation: RsVariableType(str, "PerAsset|Consolidated", default="Consolidated", required=False)  # type: ignore # noqa: F722,F821
    vulnerabilityCreation: RsVariableType(
        str,
        "NoIssue|PoamCreation|IssueCreation",
        default="NoIssue",
        required=False,
    )  # type: ignore  # noqa: F722,F821  # IssueCreation kept for backwards-compat; maps to PoamCreation
    userId: RsVariableType(str, "00000000-0000-0000-0000-000000000000")  # type: ignore # noqa: F722,F821
    poamTitleType: RsVariableType(str, "Cve|PluginId", default="Cve", required=False)  # type: ignore # noqa: F722,F821
    tenableGroupByPlugin: RsVariableType(bool, "true|false", default=False, required=False)  # type: ignore # noqa: F722,F821
    threadMaxWorkers: RsVariableType(int, "1-8", default=4, required=False)  # type: ignore # noqa: F722,F821
    stigMapperFile: RsVariableType(str, "stig_mapper.json", default="stig_mapper_rules.json", required=False)  # type: ignore # noqa: F722,F821
    ingestClosedIssues: RsVariableType(bool, "true|false", default=False, required=False)  # type: ignore # noqa: F722,F821
    # Increment the POAM identifier by 1 for each new POAM created in the format of V-0001
    incrementPoamIdentifier: RsVariableType(bool, "true|false", default=False, required=False)  # type: ignore # noqa: F722,F821
    sslVerify: RsVariableType(bool, "true|false", default=True, required=False)  # type: ignore # noqa: F722,F821
    # Custom CA certificate bundle path for SSL verification (for corporate proxies like Netskope)
    # Priority: customCaCert > SSL_CERT_FILE env var > REQUESTS_CA_BUNDLE env var > system default
    customCaCert: RsVariableType(str, "/path/to/ca-bundle.crt", default=None, required=False)  # type: ignore # noqa: F722,F821
    issueDueDates: RsVariableType(
        dict,
        "dueDates",
        default="{'high': 60, 'moderate': 120, 'low': 364}",
        required=False,
    )  # type: ignore # noqa: F722,F821
    maxRetries: RsVariableType(int, "3", default=3, required=False)  # type: ignore
    timeout: RsVariableType(int, "60", default=60, required=False)  # type: ignore
    complianceCreation: RsVariableType(str, "Assessment|Issue|POAM", default="Assessment", required=False)  # type: ignore # noqa: F722,F821
    useMilestones: RsVariableType(bool, "true|false", default=False, required=False)  # type: ignore # noqa: F722,F722,F821
    closeFindingsNotInScan: RsVariableType(bool, "true|false", default=True, required=False)  # type: ignore # noqa: F722,F821
    findingChunkSize: RsVariableType(int, "5000", default=5000, required=False)  # type: ignore # noqa: F722,F821
    createScanAssessments: RsVariableType(bool, "true|false", default=False, required=False)  # type: ignore # noqa: F722,F821
    defaultVulnControls: RsVariableType(str, "SI-2,RA-5", default="SI-2,RA-5", required=False)  # type: ignore # noqa: F722,F821
