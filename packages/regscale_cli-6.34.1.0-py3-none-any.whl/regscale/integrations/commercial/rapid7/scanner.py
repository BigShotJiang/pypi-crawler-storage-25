#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Rapid7 InsightVM Scanner Integration for RegScale.

This module provides the Rapid7Scanner class that fetches assets and
vulnerabilities from Rapid7 InsightVM and syncs them to RegScale.
"""

import logging
from typing import Dict, Generator, Optional

from regscale.integrations.commercial.rapid7.api_client import Rapid7ApiClient, Rapid7ApiException
from regscale.integrations.commercial.rapid7.models import Rapid7Asset, Rapid7Vulnerability
from regscale.integrations.commercial.rapid7.variables import Rapid7Variables
from regscale.integrations.scanner_integration import (
    IntegrationAsset,
    IntegrationFinding,
    ScannerIntegration,
    ScannerIntegrationType,
)
from regscale.models import regscale_models

logger = logging.getLogger("regscale")

# Asset type mapping from Rapid7 type strings to RegScale asset types
ASSET_TYPE_MAP = {
    "hypervisor": "Virtual Machine (VM)",
    "guest": "Virtual Machine (VM)",
    "physical": "Physical Server",
    "mobile": "Phone",
}

# OS family mapping from Rapid7 os_family strings to RegScale operating system enums
OS_FAMILY_MAP = {
    "Windows": regscale_models.AssetOperatingSystem.WindowsServer,
    "Linux": regscale_models.AssetOperatingSystem.Linux,
    "Mac OS X": regscale_models.AssetOperatingSystem.MacOSX,
    "macOS": regscale_models.AssetOperatingSystem.MacOSX,
    "AIX": regscale_models.AssetOperatingSystem.Unix,
}


def asset_to_integration_asset(asset: Rapid7Asset) -> IntegrationAsset:
    """
    Convert a Rapid7Asset to an IntegrationAsset.

    Args:
        asset: Rapid7Asset instance from the API response.

    Returns:
        IntegrationAsset for use with ScannerIntegration.
    """
    name = asset.host_name or asset.ip or "rapid7-asset-%d" % asset.id

    return IntegrationAsset(
        name=name,
        identifier=str(asset.id),
        asset_type=ASSET_TYPE_MAP.get(asset.asset_type or "", "Other"),
        asset_category="Hardware",
        ip_address=asset.ip,
        mac_address=asset.mac or "",
        fqdn=asset.host_name or "",
        operating_system=OS_FAMILY_MAP.get(asset.os_family or "", regscale_models.AssetOperatingSystem.Other),
        os_version=asset.os_version or "",
        cpe=asset.os_cpe or "",
        external_id=str(asset.id),
        other_tracking_number=str(asset.id),
        is_authenticated_scan=asset.assessed_for_vulnerabilities,
        scanning_tool="Rapid7 InsightVM",
        description=", ".join(asset.tags) if asset.tags else "",
        status="Active (On Network)",
    )


def vulnerability_to_integration_finding(
    vuln: Rapid7Vulnerability,
    asset: Optional[Rapid7Asset] = None,
) -> IntegrationFinding:
    """
    Convert a Rapid7Vulnerability to an IntegrationFinding.

    Args:
        vuln: Rapid7Vulnerability instance from the API response.
        asset: Optional Rapid7Asset for IP/DNS enrichment and asset linkage.

    Returns:
        IntegrationFinding for use with ScannerIntegration.
    """
    severity = _map_severity(vuln)
    status = _map_status(vuln.status)

    return IntegrationFinding(
        control_labels=[],
        title=vuln.title or vuln.id,
        category="Vulnerability",
        plugin_name=vuln.id,
        plugin_id=vuln.id,
        severity=severity,
        description=vuln.description or "",
        status=status,
        cve=vuln.cves[0] if vuln.cves else None,
        cvss_v3_score=vuln.cvss_v3_score,
        cvss_v2_score=vuln.cvss_v2_score,
        cvss_v3_vector=vuln.cvss_v3_vector,
        cvss_v2_vector=vuln.cvss_v2_vector,
        remediation=vuln.solution_fix or vuln.solution_summary or "",
        plugin_text=vuln.solution_summary or "",
        asset_identifier=str(asset.id) if asset else "",
        ip_address=asset.ip if asset else "",
        dns=asset.host_name if asset else "",
        first_seen=vuln.first_found or vuln.added or "",
        last_seen=vuln.last_found or "",
        evidence=vuln.proof or "",
        vpr_score=vuln.risk_score if vuln.risk_score else None,
        issue_type="Risk",
        identification="Vulnerability Assessment",
        external_id=vuln.id,
    )


def _map_severity(vuln: Rapid7Vulnerability) -> regscale_models.IssueSeverity:
    """
    Map severity from CVSS score, falling back to Rapid7 severity string.

    Prefers CVSS v3 score, then CVSS v2 score, then the Rapid7 severity label.

    Args:
        vuln: Rapid7Vulnerability instance.

    Returns:
        RegScale IssueSeverity enum value.
    """
    score = vuln.cvss_v3_score or vuln.cvss_v2_score
    if score is not None:
        if score >= 9.0:
            return regscale_models.IssueSeverity.Critical
        if score >= 7.0:
            return regscale_models.IssueSeverity.High
        if score >= 4.0:
            return regscale_models.IssueSeverity.Moderate
        return regscale_models.IssueSeverity.Low

    severity_map = {
        "Critical": regscale_models.IssueSeverity.Critical,
        "Severe": regscale_models.IssueSeverity.High,
        "Moderate": regscale_models.IssueSeverity.Moderate,
        "Low": regscale_models.IssueSeverity.Low,
    }
    return severity_map.get(vuln.severity, regscale_models.IssueSeverity.Low)


def _map_status(status: str) -> regscale_models.IssueStatus:
    """
    Map Rapid7 vulnerability status string to RegScale IssueStatus.

    Args:
        status: Rapid7 vulnerability status string.

    Returns:
        RegScale IssueStatus enum value.
    """
    status_map = {
        "vulnerable": regscale_models.IssueStatus.Open,
        "VULNERABLE_EXPL": regscale_models.IssueStatus.Open,
        "VULNERABLE_VERSION": regscale_models.IssueStatus.Open,
        "not-vulnerable": regscale_models.IssueStatus.Closed,
        "NOT_VULNERABLE": regscale_models.IssueStatus.Closed,
        "EXCEPTION_APPLIED": regscale_models.IssueStatus.Draft,
    }
    return status_map.get(status, regscale_models.IssueStatus.Open)


class Rapid7Scanner(ScannerIntegration):
    """
    Rapid7 InsightVM Scanner Integration for RegScale.

    Fetches assets and vulnerabilities from Rapid7 InsightVM
    and syncs them to RegScale.
    """

    title = "Rapid7 InsightVM"
    type = ScannerIntegrationType.VULNERABILITY
    asset_identifier_field = "otherTrackingNumber"

    def __init__(self, *args, **kwargs):
        """
        Initialize the Rapid7 InsightVM Scanner Integration.

        Args:
            *args: Arguments to pass to parent class.
            **kwargs: Keyword arguments to pass to parent class.
        """
        super().__init__(*args, **kwargs)

        deployment_type = Rapid7Variables.rapid7DeploymentType or "console"

        # Validate configuration based on deployment type
        if deployment_type == "console":
            console_url = Rapid7Variables.rapid7Url or ""
            if not console_url.strip():
                raise Rapid7ApiException("Rapid7 Console URL is not configured. Please set 'rapid7Url' in init.yaml")
        else:
            api_key = Rapid7Variables.rapid7ApiKey or ""
            if not api_key.strip() or api_key == "your-api-key-here":
                raise Rapid7ApiException("Rapid7 API key is not configured. Please set 'rapid7ApiKey' in init.yaml")

        self.api_client = Rapid7ApiClient(
            deployment_type=deployment_type,
            console_url=Rapid7Variables.rapid7Url or "",
            username=Rapid7Variables.rapid7Username or "",
            password=Rapid7Variables.rapid7Password or "",
            verify_ssl=Rapid7Variables.rapid7VerifySsl,
            api_key=Rapid7Variables.rapid7ApiKey or "",
            region=Rapid7Variables.rapid7Region or "us",
            page_size=Rapid7Variables.rapid7PageSize or 500,
        )

        self._site_ids = self._parse_site_ids()
        self._rapid7_asset_cache: Dict[int, Rapid7Asset] = {}
        self._vuln_detail_cache: Dict[str, dict] = {}

    def _parse_site_ids(self) -> list:
        """
        Parse comma-separated site IDs from configuration.

        Returns:
            List of integer site IDs, or empty list for all sites.
        """
        raw = Rapid7Variables.rapid7SiteIds or ""
        if not raw.strip():
            return []
        return [int(s.strip()) for s in raw.split(",") if s.strip().isdigit()]

    def fetch_assets(self, **kwargs) -> Generator[IntegrationAsset, None, None]:
        """
        Fetch assets from Rapid7 InsightVM.

        Yields:
            IntegrationAsset objects for each Rapid7 asset.
        """
        logger.info("Fetching assets from Rapid7 InsightVM (%s)...", self.api_client.deployment_type)

        count = 0
        if self._site_ids:
            for site_id in self._site_ids:
                logger.info("Fetching assets from site %d...", site_id)
                for raw_asset in self.api_client.get_assets(site_id=site_id):
                    asset = self._parse_asset(raw_asset)
                    if asset:
                        count += 1
                        yield asset
        else:
            for raw_asset in self.api_client.get_assets():
                asset = self._parse_asset(raw_asset)
                if asset:
                    count += 1
                    yield asset

        self.num_assets_to_process = count
        logger.info("Fetched %d assets from Rapid7 InsightVM", count)

    def _parse_asset(self, raw: dict) -> Optional[IntegrationAsset]:
        """
        Convert raw API response to IntegrationAsset and cache the parsed model.

        Args:
            raw: Raw asset dictionary from the Rapid7 API.

        Returns:
            IntegrationAsset instance, or None if parsing fails.
        """
        try:
            if self.api_client.deployment_type == "console":
                asset = Rapid7Asset.from_v3_response(raw)
            else:
                asset = Rapid7Asset.from_v4_response(raw)

            # Cache for linking findings to assets later
            self._rapid7_asset_cache[asset.id] = asset

            return asset_to_integration_asset(asset)
        except Exception as exc:
            logger.warning("Failed to parse Rapid7 asset: %s", exc)
            return None

    def fetch_findings(self, **kwargs) -> Generator[IntegrationFinding, None, None]:
        """
        Fetch vulnerabilities from Rapid7 InsightVM.

        Yields:
            IntegrationFinding objects for each vulnerability.
        """
        logger.info("Fetching findings from Rapid7 InsightVM...")

        # Pre-populate asset cache if empty so findings can be linked to assets
        self._ensure_asset_cache()

        count = 0
        if self.api_client.deployment_type == "console":
            yield from self._fetch_findings_v3()
        else:
            for raw_vuln in self.api_client.get_asset_vulnerabilities(0):
                finding = self._parse_finding_v4(raw_vuln)
                if finding:
                    count += 1
                    yield finding

        self.num_findings_to_process = count
        logger.info("Fetched %d findings from Rapid7 InsightVM", count)

    def _ensure_asset_cache(self) -> None:
        """
        Populate the asset cache if it is empty.

        When sync_findings runs without a prior sync_assets call the cache
        is empty, which causes all findings to have blank asset_identifier
        values and prevents asset linkage.
        """
        if self._rapid7_asset_cache:
            return

        logger.info("Pre-loading Rapid7 assets for finding-to-asset linkage...")
        try:
            for raw_asset in self.api_client.get_assets():
                try:
                    if self.api_client.deployment_type == "console":
                        asset = Rapid7Asset.from_v3_response(raw_asset)
                    else:
                        asset = Rapid7Asset.from_v4_response(raw_asset)
                    self._rapid7_asset_cache[asset.id] = asset
                except Exception as exc:
                    logger.warning("Failed to cache Rapid7 asset: %s", exc)
        except Rapid7ApiException as exc:
            logger.warning("Could not pre-load assets for finding linkage: %s", exc)
            return

        logger.info("Pre-loaded %d assets into cache", len(self._rapid7_asset_cache))

    def _fetch_findings_v3(self) -> Generator[IntegrationFinding, None, None]:
        """
        Fetch vulnerabilities via Console API v3 (per-asset iteration).

        The per-asset endpoint ``GET /api/3/assets/{id}/vulnerabilities``
        returns lightweight ``VulnerabilityFinding`` objects that only
        contain ``id``, ``status``, ``since``, ``port``, ``protocol``,
        and ``proof``.  Full details (title, CVSS, CVEs, severity,
        solutions) are fetched from ``GET /api/3/vulnerabilities/{id}``
        and cached so each definition is retrieved at most once.

        Yields:
            IntegrationFinding objects for each vulnerability.
        """
        for asset_id, asset in self._rapid7_asset_cache.items():
            try:
                for raw_finding in self.api_client.get_asset_vulnerabilities(asset_id):
                    finding = self._parse_finding_v3(raw_finding, asset)
                    if finding:
                        yield finding
            except Rapid7ApiException as exc:
                logger.warning("Failed to fetch vulns for asset %d: %s", asset_id, exc)
                continue

    def _get_vuln_details_cached(self, vuln_id: str) -> dict:
        """
        Fetch and cache full vulnerability definition from Console API v3.

        Args:
            vuln_id: The vulnerability identifier string.

        Returns:
            Full vulnerability detail dictionary, or empty dict on failure.
        """
        if vuln_id in self._vuln_detail_cache:
            return self._vuln_detail_cache[vuln_id]

        try:
            details = self.api_client.get_vulnerability_details(vuln_id)
        except Exception as exc:
            logger.debug("Could not fetch details for vuln %s: %s", vuln_id, exc)
            details = {}

        self._vuln_detail_cache[vuln_id] = details
        return details

    def _parse_finding_v3(self, raw_finding: dict, asset: Rapid7Asset) -> Optional[IntegrationFinding]:
        """
        Convert Console v3 per-asset VulnerabilityFinding to IntegrationFinding.

        The per-asset response only has ``id``, ``status``, ``since``,
        ``port``, ``protocol``, and ``proof``.  This method enriches the
        finding by merging the full vulnerability definition retrieved
        from ``GET /api/3/vulnerabilities/{id}``.

        Args:
            raw_finding: Raw VulnerabilityFinding dict from the per-asset endpoint.
            asset: Parent Rapid7Asset for IP/DNS enrichment.

        Returns:
            IntegrationFinding instance, or None if parsing fails.
        """
        try:
            vuln_id = raw_finding.get("id", "")
            details = self._get_vuln_details_cached(vuln_id)

            # Merge: finding-level fields override definition-level fields
            merged = {**details, **raw_finding}
            vuln = Rapid7Vulnerability.from_v3_response(merged, asset_id=asset.id)
            return vulnerability_to_integration_finding(vuln, asset)
        except Exception as exc:
            logger.warning("Failed to parse finding: %s", exc)
            return None

    def _parse_finding_v4(self, raw: dict) -> Optional[IntegrationFinding]:
        """
        Convert Cloud v4 vulnerability response to IntegrationFinding.

        Args:
            raw: Raw vulnerability dictionary from the API.

        Returns:
            IntegrationFinding instance, or None if parsing fails.
        """
        try:
            vuln = Rapid7Vulnerability.from_v4_response(raw)
            asset = self._rapid7_asset_cache.get(vuln.asset_id) if vuln.asset_id else None
            return vulnerability_to_integration_finding(vuln, asset)
        except Exception as exc:
            logger.warning("Failed to parse v4 finding: %s", exc)
            return None
