#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Tanium CLI commands for RegScale.

This module provides Click commands for syncing Tanium data to RegScale.
"""

import logging
import sys
from typing import Optional

import click

from regscale.models import regscale_id, regscale_module
from regscale.models.app_models.orchestration_options import orchestration_options

logger = logging.getLogger("regscale")

# Log message constants to avoid duplication
LOG_TARGET_REGSCALE_ID = "Target RegScale ID: %s"
LOG_TARGET_REGSCALE_MODULE = "Target RegScale Module: %s"
LOG_ERROR_SYNCING_ASSETS = "Error syncing assets: %s"
LOG_ERROR_SYNCING_FINDINGS = "Error syncing findings: %s"
LOG_ERROR_DURING_SYNC = "Error during sync: %s"


def _is_component_module(module_name: str) -> bool:
    """
    Determine if the module name indicates a component.

    Accepts both singular and plural forms, case-insensitive.

    :param str module_name: The RegScale module name (e.g., "components", "securityplans")
    :return: True if module is "components" or "component", False otherwise
    :rtype: bool

    Examples:
        >>> _is_component_module("components")
        True
        >>> _is_component_module("Component")
        True
        >>> _is_component_module("securityplans")
        False
    """
    return module_name.lower() in ("components", "component")


@click.group()
def tanium():
    """
    Tanium Integration.

    Commands for syncing assets, vulnerabilities, and compliance findings
    from Tanium to RegScale.
    """
    pass


@tanium.command(name="test_connection")
def test_connection():
    """
    Test connection to Tanium API.

    Verifies that the configured Tanium credentials are valid
    and the API is accessible.
    """
    try:
        from regscale.integrations.commercial.tanium.tanium_api_client import (
            TaniumAPIClient,
            TaniumAPIException,
        )
        from regscale.integrations.commercial.tanium.variables import TaniumVariables

        logger.info("Testing connection to Tanium...")

        client = TaniumAPIClient(
            base_url=TaniumVariables.taniumUrl,
            api_token=TaniumVariables.taniumToken,
            verify_ssl=TaniumVariables.taniumVerifySsl,
            timeout=TaniumVariables.taniumTimeout,
            protocols=TaniumVariables.taniumProtocols,
            api_type=TaniumVariables.taniumApiType,
            is_cloud=TaniumVariables.taniumIsCloud,
        )

        if client.test_connection():
            server_info = client.get_server_info()
            version = server_info.get("version", "Unknown")
            logger.info("Successfully connected to Tanium")
            logger.info("Tanium Server Version: %s", version)
            click.echo("Successfully connected to Tanium (version: %s)" % version)
        else:
            logger.error("Failed to connect to Tanium")
            click.echo("Failed to connect to Tanium", err=True)
            sys.exit(1)

    except TaniumAPIException as e:
        logger.error("Tanium API error: %s", str(e))
        click.echo("Error connecting to Tanium: %s" % str(e), err=True)
        sys.exit(1)
    except Exception as e:
        logger.error("Unexpected error testing Tanium connection: %s", str(e))
        click.echo("Error: %s" % str(e), err=True)
        sys.exit(1)


@tanium.command(name="sync_assets")
@regscale_id()
@regscale_module()
@orchestration_options()
def sync_assets(
    regscale_id: int,
    regscale_module: str,
    dry_run: bool = False,
    offset: Optional[int] = None,
    limit: Optional[int] = None,
):
    """
    Sync Tanium endpoints to RegScale assets.

    Fetches all endpoints from Tanium and synchronizes them as assets
    into the specified RegScale record.
    """
    try:
        from regscale.core.app.utils.regscale_utils import verify_provided_module
        from regscale.integrations.commercial.tanium.scanner import TaniumScanner
        from regscale.integrations.commercial.tanium.tanium_api_client import (
            TaniumAPIException,
        )

        # Verify the module is valid
        verify_provided_module(regscale_module)

        # Determine if this is a component based on module name
        is_component = _is_component_module(regscale_module)

        logger.info("Starting Tanium asset synchronization...")
        logger.info(LOG_TARGET_REGSCALE_ID, regscale_id)
        logger.info(LOG_TARGET_REGSCALE_MODULE, regscale_module)
        logger.info("Target is component: %s", is_component)

        TaniumScanner.sync_assets(
            plan_id=regscale_id, is_component=is_component, dry_run=dry_run, offset=offset, limit=limit
        )

        logger.info("Tanium asset synchronization complete.")
        click.echo("Tanium asset synchronization complete.")

    except TaniumAPIException as e:
        logger.error("Tanium API error during asset sync: %s", str(e))
        click.echo(LOG_ERROR_SYNCING_ASSETS % str(e), err=True)
        sys.exit(1)
    except Exception as e:
        logger.error(LOG_ERROR_SYNCING_ASSETS, str(e), exc_info=True)
        click.echo(LOG_ERROR_SYNCING_ASSETS % str(e), err=True)
        sys.exit(1)


@tanium.command(name="sync_findings")
@regscale_id()
@regscale_module()
@click.option(
    "--include_compliance/--no-include_compliance",
    default=False,
    help="[Deprecated] Include compliance findings as vulnerabilities. Use sync_compliance instead.",
)
@orchestration_options()
def sync_findings(
    regscale_id: int,
    regscale_module: str,
    include_compliance: bool,
    dry_run: bool = False,
    offset: Optional[int] = None,
    limit: Optional[int] = None,
):
    """
    Sync Tanium vulnerabilities and compliance findings to RegScale.

    Fetches vulnerabilities from Tanium and optionally compliance findings
    from Tanium Comply, then synchronizes them as findings into the
    specified RegScale record.
    """
    try:
        from regscale.core.app.utils.api_handler import APIInsertionError
        from regscale.core.app.utils.regscale_utils import verify_provided_module
        from regscale.integrations.commercial.tanium.scanner import TaniumScanner
        from regscale.integrations.commercial.tanium.tanium_api_client import (
            TaniumAPIException,
        )

        # Verify the module is valid
        verify_provided_module(regscale_module)

        # Determine if this is a component based on module name
        is_component = _is_component_module(regscale_module)

        logger.info("Starting Tanium findings synchronization...")
        logger.info(LOG_TARGET_REGSCALE_ID, regscale_id)
        logger.info(LOG_TARGET_REGSCALE_MODULE, regscale_module)
        logger.info("Target is component: %s", is_component)
        logger.info("Include compliance findings: %s", include_compliance)

        TaniumScanner.sync_findings(
            plan_id=regscale_id,
            is_component=is_component,
            include_compliance=include_compliance,
            dry_run=dry_run,
            offset=offset,
            limit=limit,
        )

        logger.info("Tanium findings synchronization complete.")
        click.echo("Tanium findings synchronization complete.")

    except APIInsertionError as e:
        logger.error(
            "Failed to create ScanHistory record in RegScale. "
            "Verify the target module (%s) and ID (%s) are correct: %s",
            regscale_module,
            regscale_id,
            str(e),
        )
        click.echo(
            "Error: Failed to create ScanHistory record. Check that regscale_id and regscale_module are valid.",
            err=True,
        )
        sys.exit(1)
    except TaniumAPIException as e:
        logger.error("Tanium API error during findings sync: %s", str(e))
        click.echo(LOG_ERROR_SYNCING_FINDINGS % str(e), err=True)
        sys.exit(1)
    except Exception as e:
        logger.error(LOG_ERROR_SYNCING_FINDINGS, str(e), exc_info=True)
        click.echo(LOG_ERROR_SYNCING_FINDINGS % str(e), err=True)
        sys.exit(1)


@tanium.command(name="sync_compliance")
@regscale_id()
@click.option(
    "--framework",
    type=click.STRING,
    default=None,
    help="Compliance framework override (e.g. NIST, CSF). Auto-detected from SSP if omitted.",
)
def sync_compliance(regscale_id: int, framework: Optional[str] = None):
    """Sync Tanium Comply benchmark/compliance data as control assessments.

    Fetches compliance findings from Tanium Comply, maps them to NIST controls,
    and creates proper control assessments (Assessment + ControlTest + ControlTestResult)
    in RegScale. This replaces the deprecated --include_compliance flag on sync_findings.
    """
    try:
        from regscale.integrations.commercial.tanium.compliance_integration import TaniumComplianceIntegration
        from regscale.integrations.commercial.tanium.tanium_api_client import TaniumAPIException

        logger.info("Starting Tanium compliance synchronization...")
        logger.info(LOG_TARGET_REGSCALE_ID, regscale_id)

        integration = TaniumComplianceIntegration(plan_id=regscale_id, framework=framework)
        integration.sync_compliance()

        logger.info("Tanium compliance synchronization complete.")
        click.echo("Tanium compliance synchronization complete.")

    except TaniumAPIException as e:
        logger.error("Tanium API error during compliance sync: %s", str(e))
        click.echo("Error syncing compliance: %s" % str(e), err=True)
        sys.exit(1)
    except Exception as e:
        logger.error("Error syncing compliance: %s", str(e), exc_info=True)
        click.echo("Error syncing compliance: %s" % str(e), err=True)
        sys.exit(1)


@tanium.command(name="sync_all")
@regscale_id()
@regscale_module()
@click.option(
    "--framework",
    type=click.STRING,
    default=None,
    help="Compliance framework override for sync_compliance (e.g. NIST, CSF). Auto-detected if omitted.",
)
@orchestration_options()
def sync_all(
    regscale_id: int,
    regscale_module: str,
    framework: Optional[str] = None,
    dry_run: bool = False,
    offset: Optional[int] = None,
    limit: Optional[int] = None,
):
    """
    Sync all Tanium data to RegScale.

    Synchronizes assets (endpoints), vulnerability findings, and compliance
    assessments from Tanium to the specified RegScale record.
    """
    try:
        from regscale.core.app.utils.regscale_utils import verify_provided_module
        from regscale.integrations.commercial.tanium.compliance_integration import TaniumComplianceIntegration
        from regscale.integrations.commercial.tanium.scanner import TaniumScanner
        from regscale.integrations.commercial.tanium.tanium_api_client import (
            TaniumAPIException,
        )

        # Verify the module is valid
        verify_provided_module(regscale_module)

        # Determine if this is a component based on module name
        is_component = _is_component_module(regscale_module)

        logger.info("Starting full Tanium synchronization...")
        logger.info(LOG_TARGET_REGSCALE_ID, regscale_id)
        logger.info(LOG_TARGET_REGSCALE_MODULE, regscale_module)
        logger.info("Target is component: %s", is_component)

        # Step 1: Sync assets
        logger.info("Syncing assets...")
        TaniumScanner.sync_assets(
            plan_id=regscale_id, is_component=is_component, dry_run=dry_run, offset=offset, limit=limit
        )

        # Step 2: Sync vulnerability findings (no compliance)
        logger.info("Syncing vulnerability findings...")
        TaniumScanner.sync_findings(
            plan_id=regscale_id,
            is_component=is_component,
            include_compliance=False,
            dry_run=dry_run,
            offset=offset,
            limit=limit,
        )

        # Step 3: Sync compliance as assessments
        logger.info("Syncing compliance assessments...")
        compliance = TaniumComplianceIntegration(plan_id=regscale_id, framework=framework)
        compliance.sync_compliance()

        logger.info("Full Tanium synchronization complete.")
        click.echo("Full Tanium synchronization complete.")

    except TaniumAPIException as e:
        logger.error("Tanium API error during sync: %s", str(e))
        click.echo(LOG_ERROR_DURING_SYNC % str(e), err=True)
        sys.exit(1)
    except Exception as e:
        logger.error(LOG_ERROR_DURING_SYNC, str(e), exc_info=True)
        click.echo(LOG_ERROR_DURING_SYNC % str(e), err=True)
        sys.exit(1)
