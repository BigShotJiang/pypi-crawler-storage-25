import logging

import jinja2

# Jinja vulnerability is not a concern since this is used to format a string prompt, not to render HTML
PROMPT_ENVIRONMENT = jinja2.Environment()

logger = logging.getLogger("rao_agent")
