import importlib.resources
import os.path


def render_template(template_name, path, args):
    template = importlib.resources.files("rao_agent") / "template" / template_name
    with template.open("r") as f:
        content = f.read()

    rendered = content.format(**args)

    os.makedirs(path, exist_ok=True)
    with open(os.path.join(path, template_name), "w") as f:
        f.write(rendered)


def generate(agent: str):
    agent_id = agent.lower()
    package = f"rao_agent_{agent_id}"
    args = {
        "agent": agent,
        "agent_id": agent_id,
        "package": package,
    }
    src = os.path.join(agent_id, "src", package)
    render_template("agent.py", src, args)
    render_template("run.py", src, args)
    render_template("__init__.py", src, args)
    render_template("test_agent.py", os.path.join(agent_id, "tests"), args)
    render_template("pyproject.toml", agent_id, args)


def run():
    import argparse

    parser = argparse.ArgumentParser(description="Generate a new agent from template")
    parser.add_argument(
        "agent", type=str, help="Name of the agent to generate, e.g: NucliaDB"
    )
    args = parser.parse_args()

    generate(args.agent)


if __name__ == "__main__":
    run()
