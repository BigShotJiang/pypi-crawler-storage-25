import os
from typing import Dict, Optional
from uuid import uuid4

import pytest
from nuclia.lib.nua import AsyncNuaClient
from nuclia.lib.nua_responses import Image, Message
from nuclia.sdk import AsyncNucliaAuth
from nucliadb_models.search import KnowledgeboxFindResults

from rao_agent.configure import get_driver_config_instance
from rao_agent.interaction import Feedback, OAuthAuthenticateURL
from rao_agent.manager import Manager
from rao_agent.memory import (
    AnswerCitations,
    Chunk,
    Context,
    Rule,
    Source,
    Visualization,
)
from rao_agent.memory import (
    QuestionMemory as QuestionMemoryInterface,
)
from rao_agent.pubsub import UserToAgentInteraction


async def connect(key: str) -> AsyncNuaClient:
    na = AsyncNucliaAuth()
    client_id, account_type, account, base_region = await na.validate_nua(key)
    if account is None or base_region is None:
        raise Exception("Could not connect to NUA")
    return AsyncNuaClient(token=key, account=account, region=base_region)


class QuestionMemory(QuestionMemoryInterface):
    def context_user_info(self) -> str:
        """Returns a string with user information that can be used in the context of the agent. This can include information such as user preferences, user history, or any other relevant information about the user that can help the agent to generate a more personalized and accurate response."""
        return "user"

    def get_session_id(self) -> str:
        """Returns the session ID for the current question. The session ID is a unique identifier that is shared across all questions and interactions that belong to the same session. This can be used to group related interactions together, and to keep track of the conversation history in a coherent way."""
        return "session_id"

    def get_agent_id(self) -> str:
        """Returns the agent ID for the current question. The agent ID is a unique identifier that is shared across all questions and interactions that belong to the same agent. This can be used to group related interactions together, and to keep track of the conversation history in a coherent way."""
        return "agent_id"

    def get_workflow_id(self) -> str:
        """Returns the workflow ID for the current question. The workflow ID is a unique identifier that is shared across all questions and interactions that belong to the same workflow. This can be used to group related interactions together, and to keep track of the conversation history in a coherent way."""
        return "workflow_id"

    def get_rules(self) -> list[Rule | str]:
        """Returns the rules for the current question. The rules are a unique identifier that is shared across all questions and interactions that belong to the same set of rules. This can be used to group related interactions together, and to keep track of the conversation history in a coherent way."""
        return []

    async def search_in_questions(
        self, question: str, all: bool = False
    ) -> KnowledgeboxFindResults:
        """Searches for similar questions in the conversation history. This can be used to find relevant information that has been previously discussed in the conversation, and to provide a more accurate and personalized response."""
        return KnowledgeboxFindResults(resources={}, total=0)

    def user_info(self) -> Dict[str, str]:
        """Returns a dictionary with user information that can be used in the context of the agent. This can include information such as user preferences, user history, or any other relevant information about the user that can help the agent to generate a more personalized and accurate response."""
        return {"user": "user"}

    async def set_session_source(self, source: Source):
        """Sets the source of the session. This can be used to keep track of where the information in the conversation is coming from, and to provide more context to the agent when generating a response."""
        pass

    async def get_session_source(self, source_id: str) -> Optional[Source]:
        """Gets the source of the session. This can be used to keep track of where the information in the conversation is coming from, and to provide more context to the agent when generating a response."""
        return None

    async def context_history(self) -> tuple[str, int]:
        """Returns a string with the context history of the conversation. This can include information such as previous questions and answers, previous interactions, or any other relevant information about the conversation history that can help the agent to generate a more accurate and personalized response. The integer returned is the token count of the context history."""
        return "", 0

    async def get_chat_history(self) -> list[Message]:
        """Returns a list of tuples with the chat history of the conversation. Each tuple contains a question and an answer. This can be used to keep track of the conversation history in a more structured way, and to provide more context to the agent when generating a response."""
        return []

    async def save_context(self, flow_id: str, context: Context):
        """Saves a context to the memory, associated with a flow ID. This can be used to keep track of the conversation history in a more structured way, and to provide more context to the agent when generating a response."""
        context.original_question_uuid = self.original_question_uuid
        context.actual_question_uuid = self.actual_question_uuid
        self.contexts.append(context)
        if self.agent_contexts.get(flow_id) is None:
            self.agent_contexts[flow_id] = {}
        if self.agent_contexts[flow_id].get(context.agent_id) is None:
            self.agent_contexts[flow_id][context.agent_id] = []
        self.agent_contexts[flow_id][context.agent_id].append(context)

    async def save_image_urls(self, image_urls: list[str]):
        """Saves a list of image URLs to the memory, associated with the current question. This can be used to keep track of any images that are relevant to the conversation, and to provide more context to the agent when generating a response."""
        print(f"Saving image URLs: {image_urls}")

    def get_agent_contexts(self, flow_id: str, agent_id: str) -> list[Context]:
        """Returns a list of contexts for the given agent and flow."""
        if self.agent_contexts.get(flow_id) is None:
            return []
        if self.agent_contexts[flow_id].get(agent_id) is None:
            return []
        return self.agent_contexts[flow_id][agent_id]

    def get_agent_answer_summaries(self, flow_id: str, agent_id: str) -> list[str]:
        """Returns a list of answer summaries for the given agent and flow. If an answer summary is not available, it should return the full context text as a fallback."""
        return []

    def list_contexts_markdown(self) -> list[str]:
        """Returns a list of contexts in markdown format, including summaries if available, otherwise full context (i.e: the chunk texts)"""
        return []

    def contexts_markdown(self) -> str:
        """
        Returns the concatenated contexts as a single string. Includes full context (i.e: all the chunk texts)
        """
        return ""

    def list_contexts_minimal(
        self,
    ) -> list[str]:
        """
        Returns a list of minimal contexts. Minimal contexts include summaries if available, otherwise full context (i.e: the chunk texts)
        """
        return []

    def contexts_minimal(self) -> str:
        """
        Returns the concatenated minimal contexts as a single string.
        Minimal contexts include summaries if available, otherwise full context (i.e: the chunk texts)
        """
        return ""

    def get_prompt_texts(self) -> list[str]:
        """Returns the rendered prompt texts for all contexts."""
        return []

    async def add_generated_text(self, generation_id: str, generated_text: str):
        """Saves generated text (e.g: LLM output) to the memory, associated with a generation_id."""
        print(f"Saving generated text for generation {generation_id}: {generated_text}")

    async def add_step(
        self,
        step_module: str,
        step_title: str,
        step_agent_path: str,
        timeit: float,
        input_nuclia_tokens: Optional[float] = None,
        output_nuclia_tokens: Optional[float] = None,
        step_value: Optional[str] = None,
        step_reason: Optional[str] = None,
        error: Optional[str] = None,
    ):
        """Saves an intermediate step to the memory, associated with the current question. This can be used to keep track of the agent's reasoning process, and to provide more detailed information in the final answer if needed."""
        print(
            f"Saving step: {step_module}, {step_title}, {step_agent_path}, {timeit}, {input_nuclia_tokens}, {output_nuclia_tokens}, {step_value}, {step_reason}, {error}"
        )

    def set_actual_question(self, question: str, uuid: Optional[str] = None):
        """Sets the actual question for the current context."""
        self.actual_question = question
        self.actual_question_uuid = uuid or uuid4().hex
        print(f"Setting actual question: {question}, {self.actual_question_uuid}")

    def add_future_questions(self, questions: list[str]):
        """Adds future questions to the memory, associated with the current question."""
        print(f"Adding future questions: {questions}")

    def add_context_questions(self, questions: list[str]):
        """Adds context questions to the memory, associated with the current question. Context questions are questions that are generated by the agent in order to gather more information to answer the actual question. They are different from future questions, which are questions that are generated by the agent as potential follow-up questions after answering the actual question."""
        print(f"Adding context questions: {questions}")

    def get_questions(self) -> list[tuple[str, str]]:
        """Returns  context questions if they exist, otherwise returns the original question."""
        return []

    async def add_answer(
        self,
        answer: str,
        module: str,
        agent_path: str,
        citations: Optional[AnswerCitations] = None,
        visualization: Visualization | None = None,
        chunks: Optional[list[Chunk]] = None,
        structured: Optional[list[str]] = None,
        images: Optional[Dict[str, Image]] = None,
        image_urls: Optional[list[str]] = None,
    ):
        print(
            f"Adding answer: {answer}, {module}, {agent_path}, {citations}, {visualization}"
        )

    async def add_final_answer(self):
        """Saves the final answer to the memory. This should be called after the agent has generated the final answer, and it can be used to keep track of the final answer in the memory, and to provide more detailed information in the final answer if needed."""
        print("Adding final answer")

    async def send_final_answer(self):
        """Sends the final answer to the user. This should be called after add_final_answer, and it can be used to trigger any callbacks or notifications that are needed to send the final answer to the user."""
        print("Sending final answer")

    async def send_oauth(self, oauth: "OAuthAuthenticateURL") -> None:
        """Sends an OAuth authentication request to the user."""
        print(f"Sending OAuth request: {oauth}")

    async def recv_oauth_callback(
        self, question_id: str, oauth_uuid: str
    ) -> Optional[str]:
        """Receive OAuth callback credentials."""
        print(f"Receiving OAuth callback: {question_id}, {oauth_uuid}")
        return None

    async def send_feedback(
        self, feedback: "Feedback"
    ) -> Optional["UserToAgentInteraction"]:
        """Sends feedback request to the user, and returns the user response if applicable."""
        print(f"Sending feedback request: {feedback}")
        return None

    async def save(self):
        """Saves the memory to a persistent storage. This should be called after the agent has finished processing the question, and it can be used to keep track of the memory in a database or any other persistent storage."""
        print("Saving memory")


@pytest.fixture
async def manager(request) -> Manager:
    nua = await connect(os.environ.get("NUA_KEY", ""))
    driver_id, driver_config = request.param
    return await Manager.from_config(
        drivers=[get_driver_config_instance(driver_id, driver_config)],
        nua=nua,
    )


@pytest.fixture
def question_memory():

    qm = QuestionMemory()
    qm.original_question_uuid = uuid4().hex
    return qm
