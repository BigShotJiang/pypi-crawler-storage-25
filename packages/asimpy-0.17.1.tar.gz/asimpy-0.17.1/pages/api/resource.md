# Resource

::: asimpy.resource
