# Preemptive

::: asimpy.preemptive
