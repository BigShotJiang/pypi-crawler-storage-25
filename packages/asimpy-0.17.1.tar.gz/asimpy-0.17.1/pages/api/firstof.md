# First Of

::: asimpy.firstof
