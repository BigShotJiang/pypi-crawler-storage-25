# Core

::: asimpy.core
