# Barrier

::: asimpy.barrier
