"""Graylog API CLI — main entry point."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Annotated, Optional

import typer
from rich import print as rprint
from rich.console import Console
from rich.table import Table

from . import __version__
from .client import GraylogClient

EPILOG = (
    "Docs:  https://mmackenna.github.io/grapicli\n"
    "PyPI:  https://pypi.org/project/grapicli"
)

app = typer.Typer(
    name="grapicli",
    help="Query your Graylog server from the command line.",
    no_args_is_help=True,
    epilog=EPILOG,
)

console = Console()


def _version_callback(value: bool) -> None:
    if value:
        rprint(f"grapicli [bold cyan]{__version__}[/bold cyan]")
        raise typer.Exit()


@app.callback()
def _callback(
    version: Annotated[
        Optional[bool],
        typer.Option(
            "--version",
            "-v",
            help="Show the installed version and exit.",
            callback=_version_callback,
            is_eager=True,
        ),
    ] = None,
) -> None:
    """Query your Graylog server from the command line."""


def _parse_datetime(value: str) -> datetime:

    """Parse a datetime string in several common formats."""
    formats = [
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%Y-%m-%d",
    ]
    for fmt in formats:
        try:
            return datetime.strptime(value, fmt).replace(tzinfo=timezone.utc)
        except ValueError:
            continue
    raise typer.BadParameter(
        f"Cannot parse datetime '{value}'. "
        "Expected formats: 'YYYY-MM-DD HH:MM:SS', 'YYYY-MM-DDTHH:MM:SS', "
        "'YYYY-MM-DD HH:MM', or 'YYYY-MM-DD'."
    )


def _lucene_term(field: str, value: str) -> str:
    """Build a Lucene field:value term.

    Values containing wildcard characters (* or ?) must not be quoted —
    Lucene only resolves wildcards in unquoted term queries, not phrase queries.
    All other values are quoted to handle spaces and special characters safely.
    """
    if "*" in value or "?" in value:
        return f"{field}:{value}"
    return f'{field}:"{value}"'


def _build_query(source: Optional[str], message: Optional[str]) -> str:
    """Build a Graylog Lucene query string from filter options."""
    parts: list[str] = []
    if source:
        parts.append(_lucene_term("source", source))
    if message:
        parts.append(_lucene_term("message", message))
    return " AND ".join(parts) if parts else "*"


def _render_results(data: dict, query: str, total_requested: int) -> None:
    """Pretty-print search results using Rich."""
    messages = data.get("messages", [])
    total_results = data.get("total_results", len(messages))

    rprint(
        f"\n[bold cyan]Query:[/bold cyan] [green]{query}[/green]  "
        f"[bold]Matches:[/bold] {total_results}  "
        f"[bold]Showing:[/bold] {len(messages)}/{total_requested}"
    )

    if not messages:
        rprint("[yellow]No messages found.[/yellow]")
        return

    table = Table(show_header=True, header_style="bold magenta", show_lines=True)
    table.add_column("Timestamp", style="dim", no_wrap=True)
    table.add_column("Source", style="cyan")
    table.add_column("Message")

    for entry in messages:
        msg = entry.get("message", {})
        timestamp = msg.get("timestamp", "")
        source = msg.get("source", "")
        message = msg.get("message", "")
        table.add_row(timestamp, source, message)

    console.print(table)


@app.command(epilog=EPILOG)
def search(
    source: Annotated[
        Optional[str],
        typer.Option("--source", "-s", help="Filter by source host/identifier."),
    ] = None,
    message: Annotated[
        Optional[str],
        typer.Option("--message", "-m", help="Filter by message text (Lucene substring match)."),
    ] = None,
    limit: Annotated[
        int,
        typer.Option("--limit", "-n", help="Maximum number of messages to return."),
    ] = 30,
    since: Annotated[
        Optional[str],
        typer.Option(
            "--since",
            "-S",
            help=(
                "Show messages no earlier than this timestamp. "
                "Formats: 'YYYY-MM-DD HH:MM:SS', 'YYYY-MM-DDTHH:MM:SS', "
                "'YYYY-MM-DD HH:MM', 'YYYY-MM-DD'. Implies absolute range."
            ),
        ),
    ] = None,
    until: Annotated[
        Optional[str],
        typer.Option(
            "--until",
            "-U",
            help=(
                "Show messages no later than this timestamp (same formats as --since). "
                "Defaults to now when --since is provided."
            ),
        ),
    ] = None,
    last: Annotated[
        Optional[int],
        typer.Option(
            "--last",
            "-l",
            help="Show messages from the last N minutes. Defaults to 15 when no time range is given.",
        ),
    ] = None,
) -> None:
    """Search Graylog logs with optional source, message, and time filters."""

    query = _build_query(source, message)

    try:
        client = GraylogClient()

        if since or until:
            # Absolute range
            from_dt = _parse_datetime(since) if since else (datetime.now(timezone.utc) - timedelta(hours=1))
            to_dt = _parse_datetime(until) if until else datetime.now(timezone.utc)
            data = client.search_absolute(query, from_dt, to_dt, limit)
        else:
            # Relative range
            minutes = last if last is not None else 15
            data = client.search_relative(query, range_seconds=minutes * 60, limit=limit)

        _render_results(data, query, limit)

    except Exception as exc:  # noqa: BLE001
        rprint(f"[bold red]Error:[/bold red] {exc}")
        raise typer.Exit(code=1)
