"""Graylog API CLI."""

__version__ = "0.8.0"
