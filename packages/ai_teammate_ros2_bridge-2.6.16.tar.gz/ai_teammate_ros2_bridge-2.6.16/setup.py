from setuptools import setup, find_packages

setup(
    name="ai-teammate-ros2-bridge",
    version="2.6.2",
    packages=find_packages(),
)
