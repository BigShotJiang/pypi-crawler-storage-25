#!/usr/bin/env python3
"""
Test onex-rocket MCP tools end-to-end.

Calls each rocket tool via the HTTP API and verifies responses.
Requires: onex-rocket server running at 10.0.0.3:7432 with repos indexed.

Usage:
    python3 tests/test_rocket_mcp.py
    python3 tests/test_rocket_mcp.py --verbose
    python3 tests/test_rocket_mcp.py --api-url http://10.0.0.3:7432
"""

import argparse
import json
import sys
import time
import urllib.parse

import httpx

# ============================================================
# Test configuration
# ============================================================

DEFAULT_API = "http://10.0.0.3:7432"
REPO = "onex-service@dev"  # must be indexed
PATH = "services/qa"       # directory that exists in the repo
SYMBOL_NAME = "create"     # common function name

# ============================================================
# Test cases: (name, method, path, params, checks)
# checks: list of lambdas that take the parsed response
# ============================================================

def build_tests(repo, path, symbol):
    return [
        # --- Health & Stats ---
        {
            "name": "health",
            "method": "GET",
            "path": "/api/v1/health",
            "checks": [
                lambda r: r.get("status") == "ok",
                lambda r: r.get("nodes", 0) > 0,
            ],
        },
        {
            "name": "stats",
            "method": "GET",
            "path": "/api/v1/stats",
            "checks": [
                lambda r: r.get("total_nodes", 0) > 0,
                lambda r: repo.split("@")[0] in str(r.get("by_repo", {})) or repo in str(r.get("by_repo", {})),
            ],
        },

        # --- Repo Map ---
        {
            "name": "repo_map (full)",
            "method": "GET",
            "path": f"/api/v1/repo/{repo}/map",
            "checks": [
                lambda r: isinstance(r.get("files"), list),
                lambda r: len(r.get("files", [])) > 10,
            ],
            "max_size": 500_000,  # should be large
        },
        {
            "name": "repo_map (path filtered)",
            "method": "GET",
            "path": f"/api/v1/repo/{repo}/map?path={path}",
            "checks": [
                lambda r: isinstance(r.get("files"), list),
                lambda r: len(r.get("files", [])) > 0,
                lambda r: all(f["path"].startswith(path) for f in r.get("files", []) if f.get("path")),
            ],
            "max_size": 50_000,  # should be much smaller
        },

        # --- Dead Code ---
        {
            "name": "dead_code (full)",
            "method": "GET",
            "path": f"/api/v1/repo/{repo}/dead-code",
            "checks": [
                lambda r: isinstance(r, list),
            ],
        },
        {
            "name": "dead_code (path filtered)",
            "method": "GET",
            "path": f"/api/v1/repo/{repo}/dead-code?path={path}",
            "checks": [
                lambda r: isinstance(r, list),
                lambda r: all(s.get("file_path", "").startswith(path) for s in r) if r else True,
            ],
        },

        # --- Hotspots ---
        {
            "name": "hotspots (limit=5)",
            "method": "GET",
            "path": f"/api/v1/repo/{repo}/hotspots?limit=5",
            "checks": [
                lambda r: isinstance(r, list),
                lambda r: len(r) <= 5,
            ],
        },
        {
            "name": "hotspots (path filtered)",
            "method": "GET",
            "path": f"/api/v1/repo/{repo}/hotspots?limit=5&path={path}",
            "checks": [
                lambda r: isinstance(r, list),
                lambda r: all(
                    s.get("symbol", {}).get("file_path", "").startswith(path)
                    for s in r
                ) if r else True,
            ],
        },

        # --- Cycles ---
        {
            "name": "cycles",
            "method": "GET",
            "path": f"/api/v1/repo/{repo}/cycles",
            "checks": [
                lambda r: isinstance(r, list) or r is None,
            ],
        },

        # --- Find Symbol ---
        {
            "name": "find_symbol",
            "method": "GET",
            "path": f"/api/v1/symbols?name={symbol}&repo={repo}",
            "checks": [
                lambda r: isinstance(r, list),
                lambda r: len(r) > 0,
                lambda r: all("global_id" in s for s in r),
                lambda r: all("file_path" in s for s in r),
            ],
        },
        {
            "name": "find_symbol (by kind)",
            "method": "GET",
            "path": f"/api/v1/symbols?name={symbol}&repo={repo}&kind=function",
            "checks": [
                lambda r: isinstance(r, list),
                lambda r: all(s.get("kind") == "function" for s in r),
            ],
        },
        {
            "name": "find_symbol (no results)",
            "method": "GET",
            "path": f"/api/v1/symbols?name=zzz_nonexistent_symbol_zzz&repo={repo}",
            "checks": [
                lambda r: isinstance(r, list) or r is None,
                lambda r: len(r) == 0 if isinstance(r, list) else r is None,
            ],
        },

        # --- Symbol-scoped queries (need a real global_id) ---
        # We use a two-pass approach: first find a symbol, then query it.
        # For static tests, use a known global_id pattern.
        {
            "name": "get_references",
            "method": "GET",
            "path": f"/api/v1/symbols/{urllib.parse.quote(f'{repo}:{path}/src/apis/webhook.py:_verify_bearer:function', safe='')}/references",
            "checks": [
                lambda r: isinstance(r, list) or r is None,
            ],
        },
        {
            "name": "get_dependents",
            "method": "GET",
            "path": f"/api/v1/symbols/{urllib.parse.quote(f'{repo}:{path}/src/apis/webhook.py:_verify_bearer:function', safe='')}/dependents?max_hops=3",
            "checks": [
                lambda r: isinstance(r, (list, dict)) or r is None,
            ],
        },
        {
            "name": "get_dependencies",
            "method": "GET",
            "path": f"/api/v1/symbols/{urllib.parse.quote(f'{repo}:{path}/src/apis/webhook.py:_verify_bearer:function', safe='')}/dependencies?max_hops=3",
            "checks": [
                lambda r: isinstance(r, (list, dict)) or r is None,
            ],
        },
        {
            "name": "get_symbol_context",
            "method": "GET",
            "path": f"/api/v1/symbols/{urllib.parse.quote(f'{repo}:{path}/src/apis/webhook.py:_verify_bearer:function', safe='')}/context",
            "checks": [
                lambda r: isinstance(r, dict),
            ],
        },
        {
            "name": "get_usage_examples",
            "method": "GET",
            "path": f"/api/v1/symbols/{urllib.parse.quote(f'{repo}:{path}/src/apis/webhook.py:_verify_bearer:function', safe='')}/usage?limit=5",
            "checks": [
                lambda r: isinstance(r, list) or r is None,
            ],
        },
        {
            "name": "get_impact",
            "method": "GET",
            "path": f"/api/v1/symbols/{urllib.parse.quote(f'{repo}:{path}/src/apis/webhook.py:_verify_bearer:function', safe='')}/impact?max_hops=3",
            "checks": [
                lambda r: isinstance(r, dict),
            ],
        },

        # --- Trace Path ---
        {
            "name": "trace_path",
            "method": "GET",
            "path": f"/api/v1/trace?from={symbol}&to=get&max_hops=5",
            "checks": [
                lambda r: isinstance(r, (dict, list)) or r is None,
            ],
        },

        # --- Rename Impact ---
        {
            "name": "rename_impact",
            "method": "GET",
            "path": f"/api/v1/rename-impact?name={symbol}&repo={repo}",
            "checks": [
                lambda r: isinstance(r, (dict, list)),
            ],
        },

        # --- Test Coverage ---
        {
            "name": "test_coverage",
            "method": "GET",
            "path": f"/api/v1/test-coverage?name={symbol}&repo={repo}",
            "checks": [
                lambda r: isinstance(r, dict),
                lambda r: "tests" in r or "test_count" in r,
            ],
        },

        # --- File Churn ---
        {
            "name": "file_churn (limit=5)",
            "method": "GET",
            "path": f"/api/v1/repo/{repo}/churn?limit=5",
            "checks": [
                lambda r: isinstance(r, list),
                lambda r: len(r) <= 5,
            ],
        },
        {
            "name": "file_churn (path filtered)",
            "method": "GET",
            "path": f"/api/v1/repo/{repo}/churn?limit=5&path={path}",
            "checks": [
                lambda r: isinstance(r, list),
            ],
        },

        # --- Path filtering edge cases ---
        {
            "name": "repo_map (nonexistent path)",
            "method": "GET",
            "path": f"/api/v1/repo/{repo}/map?path=zzz/nonexistent",
            "checks": [
                lambda r: r is None or isinstance(r, dict),
                lambda r: not (r.get("files") if isinstance(r, dict) else None),
            ],
        },
        {
            "name": "dead_code (nonexistent path)",
            "method": "GET",
            "path": f"/api/v1/repo/{repo}/dead-code?path=zzz/nonexistent",
            "checks": [
                lambda r: isinstance(r, list) or r is None,
                lambda r: len(r) == 0 if isinstance(r, list) else r is None,
            ],
        },
        {
            "name": "hotspots (nonexistent path)",
            "method": "GET",
            "path": f"/api/v1/repo/{repo}/hotspots?limit=5&path=zzz/nonexistent",
            "checks": [
                lambda r: isinstance(r, list) or r is None,
                lambda r: len(r) == 0 if isinstance(r, list) else r is None,
            ],
        },

        # --- Nonexistent repo ---
        {
            "name": "repo_map (nonexistent repo)",
            "method": "GET",
            "path": "/api/v1/repo/zzz-nonexistent-repo/map",
            "checks": [
                lambda r: r is None or isinstance(r, dict),
                lambda r: not (r.get("files") if isinstance(r, dict) else None),
            ],
        },

        # --- Index Status ---
        {
            "name": "index_status (all)",
            "method": "GET",
            "path": "/api/v1/index/status",
            "checks": [
                lambda r: isinstance(r, dict),
            ],
        },
        {
            "name": "index_status (repo)",
            "method": "GET",
            "path": f"/api/v1/index/status/{repo}",
            "checks": [
                lambda r: r.get("status") in ("done", "indexing", "not_found"),
            ],
        },
        {
            "name": "index_status (nonexistent)",
            "method": "GET",
            "path": "/api/v1/index/status/zzz-nonexistent",
            "checks": [
                lambda r: r.get("status") == "not_found",
            ],
        },

        # --- Savings ---
        {
            "name": "savings (user)",
            "method": "GET",
            "path": "/api/v1/savings/test-runner",
            "checks": [
                lambda r: "user" in r or "status" in r,
            ],
        },
        {
            "name": "savings (all users)",
            "method": "GET",
            "path": "/api/v1/savings",
            "checks": [
                lambda r: isinstance(r, dict),
            ],
        },
        {
            "name": "savings (nonexistent user)",
            "method": "GET",
            "path": "/api/v1/savings/zzz-nobody",
            "checks": [
                lambda r: r.get("status") == "no_data",
            ],
        },

        # --- Async Index (test with already-indexed repo) ---
        {
            "name": "async_index (already indexed)",
            "method": "POST",
            "path": "/api/v1/index",
            "body": {
                "url": "https://github.com/OneXApis/onex-platform.git",
                "name": "test-async",
                "branch": "main",
                "async": True,
            },
            "checks": [
                lambda r: r.get("status") in ("accepted", "already_indexing"),
            ],
        },
    ]


# ============================================================
# Runner
# ============================================================

def run_tests(api_url: str, verbose: bool = False):
    client = httpx.Client(base_url=api_url, timeout=30.0, headers={"X-User": "test-runner"})
    tests = build_tests(REPO, PATH, SYMBOL_NAME)

    passed = 0
    failed = 0
    errors = []

    print(f"\n{'='*60}")
    print(f"  onex-rocket MCP Tool Tests")
    print(f"  API: {api_url}")
    print(f"  Repo: {REPO} | Path: {PATH}")
    print(f"{'='*60}\n")

    for test in tests:
        name = test["name"]
        start = time.time()

        try:
            if test["method"] == "GET":
                resp = client.get(test["path"])
            else:
                resp = client.post(test["path"], json=test.get("body", {}))

            elapsed = time.time() - start
            resp.raise_for_status()

            # Parse response
            try:
                data = resp.json()
            except Exception:
                data = resp.text

            # Size check
            size = len(resp.text)
            max_size = test.get("max_size")

            # Run checks
            check_results = []
            for i, check in enumerate(test.get("checks", [])):
                try:
                    result = check(data)
                    check_results.append(("PASS" if result else "FAIL", i))
                except Exception as e:
                    check_results.append(("ERROR", f"check[{i}]: {e}"))

            all_passed = all(r[0] == "PASS" for r in check_results)
            size_ok = max_size is None or size <= max_size

            if all_passed and size_ok:
                status = "PASS"
                passed += 1
                icon = "✓"
            else:
                status = "FAIL"
                failed += 1
                icon = "✗"
                fail_reasons = []
                for r in check_results:
                    if r[0] != "PASS":
                        fail_reasons.append(str(r))
                if not size_ok:
                    fail_reasons.append(f"size {size} > max {max_size}")
                errors.append((name, fail_reasons))

            # Print result
            size_str = f"{size:,}" if size < 10000 else f"{size//1024}KB"
            print(f"  {icon} {name:35s} {elapsed:5.1f}s  {size_str:>8s}  {status}")

            if verbose and (not all_passed or not size_ok):
                for r in check_results:
                    if r[0] != "PASS":
                        print(f"      check {r[1]}: {r[0]}")
                if not size_ok:
                    print(f"      size: {size} > max {max_size}")

            if verbose and status == "PASS":
                # Show a preview of the response
                preview = json.dumps(data)[:200] if isinstance(data, (dict, list)) else str(data)[:200]
                print(f"      → {preview}...")

        except Exception as e:
            elapsed = time.time() - start
            failed += 1
            errors.append((name, [str(e)]))
            print(f"  ✗ {name:35s} {elapsed:5.1f}s  {'ERROR':>8s}  {e}")

    # Summary
    total = passed + failed
    print(f"\n{'='*60}")
    print(f"  Results: {passed}/{total} passed", end="")
    if failed:
        print(f", {failed} failed")
    else:
        print(" — all good!")
    print(f"{'='*60}")

    if errors:
        print(f"\n  Failures:")
        for name, reasons in errors:
            print(f"    {name}:")
            for r in reasons:
                print(f"      {r}")

    print()
    return failed == 0


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Test onex-rocket MCP tools")
    parser.add_argument("--api-url", default=DEFAULT_API, help=f"Rocket API URL (default: {DEFAULT_API})")
    parser.add_argument("--verbose", "-v", action="store_true", help="Show response previews")
    parser.add_argument("--repo", default=REPO, help=f"Repo to test (default: {REPO})")
    parser.add_argument("--path", default=PATH, help=f"Path filter to test (default: {PATH})")
    args = parser.parse_args()

    REPO = args.repo
    PATH = args.path

    success = run_tests(args.api_url, args.verbose)
    sys.exit(0 if success else 1)
