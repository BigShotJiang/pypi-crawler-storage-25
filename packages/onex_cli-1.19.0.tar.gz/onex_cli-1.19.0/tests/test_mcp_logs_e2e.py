"""
E2E tests for MCP onex_logs tool.

Runs against the live dev platform to verify:
1. Auth headers are sent (no 401 on authenticated endpoints)
2. follow parameter is removed from the signature
3. 401 handling returns actionable guidance
4. All filter parameters work correctly
"""

import asyncio
import inspect
import re

import httpx
import pytest

from onex.mcp.server import onex_logs, onex_executions, _get_platform_url, _auth_headers


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

ENV = "dev"


def run(coro):
    """Run an async coroutine synchronously."""
    return asyncio.get_event_loop().run_until_complete(coro)


# ---------------------------------------------------------------------------
# 1. Signature — follow parameter removed
# ---------------------------------------------------------------------------

class TestSignature:
    def test_follow_param_removed(self):
        """follow parameter should NOT be in the function signature."""
        sig = inspect.signature(onex_logs)
        assert "follow" not in sig.parameters, (
            "follow parameter should be removed — MCP is request-response"
        )

    def test_required_params_present(self):
        """All expected filter params should still be in the signature."""
        sig = inspect.signature(onex_logs)
        expected = [
            "service_name", "env", "lines", "level", "trace_id",
            "user_id", "company_id", "path", "method", "event",
            "function_name", "invocation_source", "grep", "last",
        ]
        for param in expected:
            assert param in sig.parameters, f"Missing parameter: {param}"

    def test_executions_signature(self):
        """onex_executions exposes the expected filter parameters."""
        sig = inspect.signature(onex_executions)
        expected = [
            "function_name", "invocation_source", "status",
            "trace_id", "last", "limit", "env",
        ]
        for param in expected:
            assert param in sig.parameters, f"Missing parameter: {param}"

    def test_executions_docstring_has_examples(self):
        """The tool description Claude sees must include usage examples."""
        doc = onex_executions.__doc__ or ""
        assert "invoice_automation_contract" in doc, (
            "docstring should include the canonical stream-trigger example "
            "so Claude picks up the pattern"
        )
        assert "invocation_source=\"stream\"" in doc
        assert "invocation_source=\"schedule\"" in doc


# ---------------------------------------------------------------------------
# 2. Auth headers — sent on every request
# ---------------------------------------------------------------------------

class TestAuthHeaders:
    def test_auth_headers_returned(self):
        """_auth_headers should return a dict (possibly with Bearer token)."""
        headers = _auth_headers(ENV)
        assert isinstance(headers, dict)
        # If a token is configured, it should be a Bearer token
        if headers:
            assert "Authorization" in headers
            assert headers["Authorization"].startswith("Bearer ")


# ---------------------------------------------------------------------------
# 3. Basic log fetch — gateway always has logs
# ---------------------------------------------------------------------------

class TestBasicLogFetch:
    def test_fetch_gateway_logs(self):
        """Fetching gateway logs should return entries (gateway is always running)."""
        result = run(onex_logs(service_name="gateway", env=ENV, lines=5, last="1h"))
        assert "Logs for gateway" in result
        assert "entries" in result

    def test_fetch_with_lines_limit(self):
        """lines parameter should cap the number of returned entries."""
        result = run(onex_logs(service_name="gateway", env=ENV, lines=3, last="1h"))
        # Count actual log lines (skip the header line)
        lines = [l for l in result.strip().split("\n") if l.strip()]
        # Header + up to 3 log entries = max 4 non-empty lines
        assert len(lines) <= 4


# ---------------------------------------------------------------------------
# 4. Filter parameters — all should work without errors
# ---------------------------------------------------------------------------

class TestFilters:
    def test_level_filter(self):
        """level filter should return results or 'No logs found' — never an error."""
        result = run(onex_logs(service_name="gateway", env=ENV, level="ERROR", lines=5, last="24h"))
        assert "Error fetching logs" not in result
        assert "Failed to fetch logs" not in result

    def test_grep_filter(self):
        """grep filter should work without errors."""
        result = run(onex_logs(service_name="gateway", env=ENV, grep="health", lines=5, last="1h"))
        assert "Error fetching logs" not in result
        assert "Failed to fetch logs" not in result

    def test_method_filter(self):
        """method filter should work without errors."""
        result = run(onex_logs(service_name="gateway", env=ENV, method="GET", lines=5, last="1h"))
        assert "Error fetching logs" not in result

    def test_path_filter(self):
        """path filter should work without errors."""
        result = run(onex_logs(service_name="gateway", env=ENV, path="/health", lines=5, last="1h"))
        assert "Error fetching logs" not in result

    def test_multiple_filters_combined(self):
        """Combining multiple filters should work without errors."""
        result = run(onex_logs(
            service_name="gateway", env=ENV,
            level="INFO", method="GET", lines=3, last="1h"
        ))
        assert "Error fetching logs" not in result


# ---------------------------------------------------------------------------
# 5. Error handling
# ---------------------------------------------------------------------------

class TestErrorHandling:
    def test_404_unknown_service(self):
        """Querying a non-existent service should return a helpful 404 message."""
        result = run(onex_logs(service_name="nonexistent-service-xyz", env=ENV, lines=5))
        assert "not found" in result.lower() or "no logs found" in result.lower()

    def test_401_handling(self):
        """Simulate 401 by calling the endpoint with an invalid token directly."""
        platform_url = _get_platform_url(ENV)
        logs_url = f"{platform_url}/_internal/services/gateway/logs"

        async def _do_request():
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.get(
                    logs_url,
                    params={"lines": 1},
                    headers={"Authorization": "Bearer invalid-token-xyz"},
                )
                return resp.status_code

        status = run(_do_request())
        # If the platform enforces auth, we get 401; if not yet enforced, 200 is fine
        # The important thing is our code handles 401 — we test the message format
        if status == 401:
            # Verify the function returns actionable guidance
            # (We can't easily force 401 through onex_logs since it uses real creds,
            #  so we just verify the status code path exists in the source)
            pass

        # Verify the 401 message format is correct in the source
        import onex.mcp.server as mod
        source = inspect.getsource(mod.onex_logs)
        assert "401" in source
        assert "onex login" in source


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
