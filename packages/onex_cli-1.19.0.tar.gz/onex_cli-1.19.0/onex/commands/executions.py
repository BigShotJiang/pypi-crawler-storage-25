"""
Executions command — query invoke execution history from invoke_executions.

Covers every invocation of a handler regardless of source: HTTP, stream
trigger, event, schedule, s3, async invoke, manual CLI. Backed by the
platform ExecutionTracker (MongoDB invoke_executions collection).
"""

import json as _json

import click
import requests

from onex.config import get_config, get_access_token, get_active_environment
from onex.utils import print_error, print_info, print_warning
from onex.utils.auth import auto_refresh_token


VALID_SOURCES = ['http', 'stream', 'event', 'schedule', 's3', 'async_invoke', 'manual']
VALID_STATUSES = ['pending', 'running', 'succeeded', 'failed', 'retrying', 'dead_letter']


@click.command()
@click.argument('function_name', required=False)
@click.option('--source', 'invocation_source',
              type=click.Choice(VALID_SOURCES),
              help='Filter by invocation source (why the handler ran)')
@click.option('--status', type=click.Choice(VALID_STATUSES),
              help='Filter by execution status')
@click.option('--trace-id', help='Filter by trace ID')
@click.option('--last', help='Time range (e.g., 1h, 30m, 24h, 7d)')
@click.option('--limit', default=20, help='Max rows to return (default: 20)')
@click.option('--offset', default=0, help='Pagination offset')
@click.option('--env', default=None, help='Environment (local/dev/staging/prod)')
@click.option('--platform-url', help='Override platform URL')
@click.option('--json', 'output_json', is_flag=True, help='Output as JSON')
def executions(function_name, invocation_source, status, trace_id, last,
               limit, offset, env, platform_url, output_json):
    """List invoke execution history for a handler.

    Answers questions like "has my stream-triggered invoice handler actually
    run in the last day, and did it succeed?" — data that Loki log retention
    may have aged out but invoke_executions still has.

    \b
    Examples:
      # Every run of a handler in the last 24h
      onex executions automation:invoice_automation_contract --last 24h

      # Only the stream-triggered runs
      onex executions automation:invoice_automation_contract \\
          --source stream --last 7d

      # Failed manual (CLI) test runs
      onex executions automation:invoice_automation_contract \\
          --source manual --status failed --last 7d

      # All scheduled runs across ALL handlers in the last hour
      onex executions --source schedule --last 1h

      # Everything tied to a specific trace_id (cross-source)
      onex executions --trace-id abc-123-def
    """
    if env is None:
        env = get_active_environment()

    config = get_config()
    platform_base_url = platform_url or config.get_platform_url(env)
    url = f"{platform_base_url}/api/invoke/executions"

    access_token = get_access_token(env)
    headers = {}
    if access_token:
        headers['Authorization'] = f'Bearer {access_token}'

    params = {'limit': limit, 'offset': offset}
    if function_name:
        params['function_name'] = function_name
    if invocation_source:
        params['invocation_source'] = invocation_source
    if status:
        params['status'] = status
    if trace_id:
        params['trace_id'] = trace_id
    if last:
        params['last'] = last

    try:
        response = requests.get(url, params=params, headers=headers, timeout=15)

        if response.status_code == 401 and env != "local":
            print_warning("Token expired, refreshing...")
            if auto_refresh_token(env, silent=False):
                access_token = get_access_token(env)
                headers['Authorization'] = f'Bearer {access_token}'
                response = requests.get(url, params=params, headers=headers, timeout=15)
            else:
                print_error("Authentication failed - could not refresh token")
                print_info(f"Please login again: onex login --env {env}")
                return

        if response.status_code != 200:
            print_error(f"Failed to fetch executions: HTTP {response.status_code}")
            try:
                print_error(response.json().get('detail', response.text[:200]))
            except Exception:
                print_error(response.text[:200])
            return

        data = response.json()
        rows = data.get('executions', [])
        total = data.get('total', 0)

        if output_json:
            click.echo(_json.dumps(data, indent=2, default=str))
            return

        if not rows:
            click.echo(f"No executions found (total={total}).")
            return

        # Compact table
        click.echo(f"\n{total} execution(s), showing {len(rows)}:\n")
        header = f"{'STARTED':<20} {'STATUS':<10} {'SOURCE':<13} {'MS':>7}  FUNCTION / DETAIL"
        click.echo(header)
        click.echo('-' * len(header))
        for r in rows:
            started = (r.get('started_at') or '')[:19].replace('T', ' ')
            st = (r.get('status') or '?')[:10]
            src = (r.get('invocation_source') or '-')[:13]
            ms = r.get('execution_time_ms')
            ms_str = f"{ms:7.0f}" if isinstance(ms, (int, float)) else "      -"
            fname = r.get('function_name') or '-'
            detail = r.get('invocation_detail') or ''

            # Color-code by status
            if st == 'failed' or st == 'dead_letter':
                line = click.style(f"{started:<20} {st:<10} {src:<13} {ms_str}  {fname}", fg='red')
            elif st == 'succeeded':
                line = f"{started:<20} {click.style(st, fg='green'):<10} {src:<13} {ms_str}  {fname}"
                # click.style adds ANSI bytes so the format width is off; re-render:
                line = f"{started:<20} {st:<10} {src:<13} {ms_str}  {fname}"
            else:
                line = f"{started:<20} {st:<10} {src:<13} {ms_str}  {fname}"
            click.echo(line)
            if detail:
                click.echo(f"{'':<20} {'':<10} {'':<13} {'':>7}  └─ {detail}")
            err = r.get('error')
            if err:
                err_preview = err if len(err) < 120 else err[:117] + '...'
                click.echo(click.style(f"{'':<20} {'':<10} {'':<13} {'':>7}  ⚠ {err_preview}", fg='yellow'))

        click.echo()

    except requests.exceptions.ConnectionError:
        print_error(f"Cannot connect to platform at {platform_base_url}")
        print_info("Make sure platform is running")
    except Exception as e:
        print_error(f"Error fetching executions: {e}")
