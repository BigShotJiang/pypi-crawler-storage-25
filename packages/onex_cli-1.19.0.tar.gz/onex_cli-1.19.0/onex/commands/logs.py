"""
Logs command - View service logs from platform
"""

import click
import requests
import time
from onex.config import get_config, get_access_token
from onex.utils import print_error, print_info, print_warning
from onex.utils.auth import auto_refresh_token


@click.command()
@click.argument('service_name')
@click.option('--follow', '-f', is_flag=True, help='Follow log output')
@click.option('--lines', '-n', default=100, help='Number of lines to show')
@click.option('--env', default=None, help='Environment (local/dev/staging/prod, defaults to active)')
@click.option('--platform-url', help='Override platform URL')
# Filter options
@click.option('--level', help='Filter by level (ERROR, WARNING, INFO, DEBUG) - comma-separated')
@click.option('--trace-id', help='Filter by trace ID')
@click.option('--user-id', help='Filter by user ID')
@click.option('--company-id', help='Filter by company/tenant ID')
@click.option('--path', help='Filter by API path')
@click.option('--method', help='Filter by HTTP method (GET, POST, etc.)')
@click.option('--event', help='Filter by event type (service_ready, error, etc.)')
@click.option('--function', 'function_name',
              help='Filter by invoke handler function name (e.g. invoice_automation_contract)')
@click.option('--invocation-source',
              type=click.Choice(['http', 'stream', 'event', 'schedule', 's3', 'async_invoke', 'manual']),
              help='Filter by why the handler ran (stream trigger, schedule, manual, etc.)')
@click.option('--grep', help='Search message with regex pattern')
@click.option('--last', help='Time range (e.g., 1h, 30m, 24h)')
# Output options
@click.option('--json', 'output_json', is_flag=True, help='Output as JSON')
def logs(service_name, follow, lines, env, platform_url, level, trace_id, user_id,
         company_id, path, method, event, function_name, invocation_source,
         grep, last, output_json):
    """View service logs from platform with powerful filtering.

    \b
    Examples:
      # Find all errors in last hour
      onex logs auth --level ERROR --last 1h

      # Track specific user's requests
      onex logs product --user-id user123 --last 24h

      # Debug specific trace
      onex logs auth --trace-id abc-123-def --lines 500

      # Search for specific message
      onex logs product --grep "validation failed" --level ERROR

      # Debug API endpoint
      onex logs auth --path "/auth/login" --method POST --last 6h

      # Multiple filters combined
      onex logs product --level ERROR,WARNING --company-id comp123 --last 2h

    \b
    Invoke handler tracing (stream/schedule/event/s3 triggers):
      # Every run of a specific invoke handler in the last 24h
      onex logs automation --function invoice_automation_contract --last 24h

      # Only the stream-triggered runs (e.g. contract updates)
      onex logs automation --function invoice_automation_contract \\
          --invocation-source stream --last 24h

      # Only the manual (CLI/MCP) test runs that failed
      onex logs automation --function invoice_automation_contract \\
          --invocation-source manual --level ERROR --last 7d

      # All scheduled (cron) invocations across a service
      onex logs automation --invocation-source schedule --last 1h
    """
    from onex.config import get_active_environment

    # Use active environment if not specified
    if env is None:
        env = get_active_environment()

    config = get_config()
    platform_base_url = platform_url or config.get_platform_url(env)

    click.echo(f"📋 Fetching logs for {service_name} ({env} environment)...")
    click.echo()

    logs_url = f"{platform_base_url}/_internal/services/{service_name}/logs"

    # Build auth headers
    access_token = get_access_token(env)
    headers = {}
    if access_token:
        headers['Authorization'] = f'Bearer {access_token}'

    # Build query parameters with filters
    params = {'lines': lines}

    # Add filter parameters if provided
    if level:
        params['level'] = level
    if trace_id:
        params['trace_id'] = trace_id
    if user_id:
        params['user_id'] = user_id
    if company_id:
        params['company_id'] = company_id
    if path:
        params['path'] = path
    if method:
        params['method'] = method
    if event:
        params['event'] = event
    if function_name:
        params['function_name'] = function_name
    if invocation_source:
        params['invocation_source'] = invocation_source
    if grep:
        params['grep'] = grep
    if last:
        params['last'] = last

    try:
        if follow:
            # Stream logs
            print_info("Following logs (CTRL+C to stop)...")
            click.echo()

            last_timestamp = None

            while True:
                follow_params = params.copy()
                if last_timestamp:
                    follow_params['since'] = last_timestamp

                response = requests.get(logs_url, params=follow_params, headers=headers, timeout=10)

                if response.status_code == 401 and env != "local":
                    print_warning("Token expired, refreshing...")
                    if auto_refresh_token(env, silent=False):
                        access_token = get_access_token(env)
                        headers['Authorization'] = f'Bearer {access_token}'
                        response = requests.get(logs_url, params=follow_params, headers=headers, timeout=10)
                    else:
                        print_error("Authentication failed - could not refresh token")
                        print_info(f"Please login again: onex login --env {env}")
                        return

                if response.status_code == 200:
                    data = response.json()
                    logs = data.get('logs', [])

                    for log_entry in logs:
                        timestamp = log_entry.get('timestamp', '')
                        message = log_entry.get('message', '')
                        level = log_entry.get('level', 'INFO')

                        # Color code by level
                        if level == 'ERROR':
                            click.echo(click.style(f"{timestamp} {level:5} {message}", fg='red'))
                        elif level == 'WARNING':
                            click.echo(click.style(f"{timestamp} {level:5} {message}", fg='yellow'))
                        else:
                            click.echo(f"{timestamp} {level:5} {message}")

                        last_timestamp = timestamp

                time.sleep(2)  # Poll every 2 seconds

        else:
            # Get logs once
            response = requests.get(logs_url, params=params, headers=headers, timeout=10)

            if response.status_code == 401 and env != "local":
                print_warning("Token expired, refreshing...")
                if auto_refresh_token(env, silent=False):
                    access_token = get_access_token(env)
                    headers['Authorization'] = f'Bearer {access_token}'
                    response = requests.get(logs_url, params=params, headers=headers, timeout=10)
                else:
                    print_error("Authentication failed - could not refresh token")
                    print_info(f"Please login again: onex login --env {env}")
                    return

            if response.status_code == 200:
                data = response.json()
                logs = data.get('logs', [])

                # JSON output mode
                if output_json:
                    import json
                    click.echo(json.dumps(data, indent=2))
                    return

                # Default formatted output
                for log_entry in logs:
                    timestamp = log_entry.get('timestamp', '')
                    message = log_entry.get('message', '')
                    log_level = log_entry.get('level', 'INFO')

                    # Color-code by level
                    if log_level == 'ERROR':
                        click.echo(click.style(f"{timestamp} {log_level:5} {message}", fg='red'))
                    elif log_level == 'WARNING':
                        click.echo(click.style(f"{timestamp} {log_level:5} {message}", fg='yellow'))
                    else:
                        click.echo(f"{timestamp} {log_level:5} {message}")

            elif response.status_code == 404:
                print_error(f"Service '{service_name}' not found")
                print_info("Check deployed services with: onex status")

            else:
                print_error(f"Failed to fetch logs: {response.status_code}")

    except KeyboardInterrupt:
        click.echo()
        print_info("Stopped following logs")

    except requests.exceptions.ConnectionError:
        print_error(f"Cannot connect to platform at {platform_base_url}")
        print_info("Make sure platform is running")

    except Exception as e:
        print_error(f"Error fetching logs: {e}")
