"""
Generated Python class from game-paused-event-for-observer.schema.yaml
This file is auto-generated. Do not edit manually.
"""

from enum import Enum
from .message import Message

class GamePausedEventForObserver(Message):
    """Event occurring when a game has been paused"""


    class Pause_cause(str, Enum):
        PAUSE = "pause"
        DEBUG_STEP = "debug_step"
        BREAKPOINT = "breakpoint"

    def __init__(self, type: 'Message.Type | None', pause_cause: 'Message.Pause_cause | None' = None):
        if type is None:
            raise ValueError("The 'type' parameter must be provided.")
        super().__init__(type)
        self.pause_cause = pause_cause
