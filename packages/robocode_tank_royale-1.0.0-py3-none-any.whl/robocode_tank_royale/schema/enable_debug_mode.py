"""
Generated Python class from enable-debug-mode.schema.yaml
This file is auto-generated. Do not edit manually.
"""

from .message import Message

class EnableDebugMode(Message):
    """Sent by a controller to put the server into debug mode. In debug mode, the server pauses after each turn instead of auto-advancing to the next turn.
"""

    def __init__(self, type: 'Message.Type | None'):
        if type is None:
            raise ValueError("The 'type' parameter must be provided.")
        super().__init__(type)
