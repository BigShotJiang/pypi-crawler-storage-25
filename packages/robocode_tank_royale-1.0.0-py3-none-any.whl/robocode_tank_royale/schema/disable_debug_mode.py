"""
Generated Python class from disable-debug-mode.schema.yaml
This file is auto-generated. Do not edit manually.
"""

from .message import Message

class DisableDebugMode(Message):
    """Sent by a controller to take the server out of debug mode. The server returns to normal auto-advancing behavior. Also triggered implicitly by resume-game.
"""

    def __init__(self, type: 'Message.Type | None'):
        if type is None:
            raise ValueError("The 'type' parameter must be provided.")
        super().__init__(type)
