from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from algosec.connectors.indexer_client import IndexerClient
from algosec.constants import ZERO_ADDRESS
from algosec.models import Finding, Location, ScanResult, Severity

@dataclass(slots=True)
class AccountScanner:
    """On-chain account risk scanner (rekey/trust/asset exposure)."""

    indexer_client: IndexerClient

    def run(self, address: str) -> ScanResult:
        result = ScanResult(target=Path(f"account:{address}"))
        payload = self.indexer_client.account_info(address)
        account = payload.get("account", {})

        auth_addr = account.get("auth-addr")
        if auth_addr and auth_addr != address:
            result.findings.append(
                Finding(
                    rule_id="ALG301",
                    title="Account is rekeyed",
                    severity=Severity.HIGH,
                    message=f"Account has auth-addr set to {auth_addr}; verify delegated signer control.",
                    location=Location(file_path=Path(f"account:{address}"), line=None),
                    confidence=0.95,
                    tags=["account", "rekey"],
                    evidence={"auth_addr": str(auth_addr)},
                )
            )

        amount = int(account.get("amount", 0) or 0)
        min_balance = int(account.get("min-balance", 0) or 0)
        margin = amount - min_balance
        if margin < 100_000:
            result.findings.append(
                Finding(
                    rule_id="ALG302",
                    title="Low spendable balance margin",
                    severity=Severity.MEDIUM,
                    message="Account balance is near minimum; operations may fail unexpectedly.",
                    location=Location(file_path=Path(f"account:{address}"), line=None),
                    confidence=0.85,
                    tags=["account", "operational-risk"],
                    evidence={"amount": str(amount), "min_balance": str(min_balance), "margin": str(margin)},
                )
            )

        created_assets = account.get("created-assets", [])
        risky_assets = 0
        for asset in created_assets:
            params = asset.get("params", {})
            for field in ("manager", "clawback", "freeze"):
                value = str(params.get(field, ""))
                if value and value != ZERO_ADDRESS:
                    risky_assets += 1
                    break

        if risky_assets > 0:
            result.findings.append(
                Finding(
                    rule_id="ALG303",
                    title="Created assets retain admin privileges",
                    severity=Severity.MEDIUM,
                    message="One or more created assets have non-zero manager/clawback/freeze addresses.",
                    location=Location(file_path=Path(f"account:{address}"), line=None),
                    confidence=0.76,
                    tags=["account", "asa", "centralization"],
                    evidence={"risky_created_assets": str(risky_assets)},
                )
            )

        result.metadata["account"] = {
            "address": address,
            "amount": amount,
            "min_balance": min_balance,
            "created_assets": len(created_assets),
        }
        return result
