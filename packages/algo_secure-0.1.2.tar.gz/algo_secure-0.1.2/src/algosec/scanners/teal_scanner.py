from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from algosec.engine import scan_path
from algosec.models import ScanResult


@dataclass(slots=True)
class TealScanner:
    """Semantic TEAL scanner for local file/folder targets."""

    def run(self, target: Path) -> ScanResult:
        return scan_path(target)
