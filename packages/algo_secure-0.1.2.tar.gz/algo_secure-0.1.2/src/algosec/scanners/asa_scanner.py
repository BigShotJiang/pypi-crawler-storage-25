from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from algosec.connectors.indexer_client import IndexerClient
from algosec.constants import ZERO_ADDRESS
from algosec.models import Finding, Location, ScanResult, Severity

@dataclass(slots=True)
class AsaScanner:
    """ASA parameter and metadata integrity scanner."""

    indexer_client: IndexerClient

    def run(self, asset_id: int) -> ScanResult:
        result = ScanResult(target=Path(f"asset:{asset_id}"))
        payload = self.indexer_client.asset_info(asset_id)
        asset = payload.get("asset", {})
        params = asset.get("params", {})

        for field, sev in (("manager", Severity.MEDIUM), ("freeze", Severity.HIGH), ("clawback", Severity.HIGH)):
            addr = str(params.get(field, ""))
            if addr and addr != ZERO_ADDRESS:
                result.findings.append(
                    Finding(
                        rule_id="ALG321",
                        title=f"ASA {field} address is active",
                        severity=sev,
                        message=f"Asset keeps non-zero {field} address; this implies centralized controls.",
                        location=Location(file_path=Path(f"asset:{asset_id}"), line=None),
                        confidence=0.92,
                        tags=["asa", "centralization", field],
                        evidence={field: addr},
                    )
                )

        if bool(params.get("default-frozen", False)):
            result.findings.append(
                Finding(
                    rule_id="ALG322",
                    title="ASA is default-frozen",
                    severity=Severity.MEDIUM,
                    message="New holdings are frozen by default; verify this matches token policy.",
                    location=Location(file_path=Path(f"asset:{asset_id}"), line=None),
                    confidence=0.9,
                    tags=["asa", "freeze-policy"],
                )
            )

        url = str(params.get("url", "") or "")
        if url.startswith("http://"):
            result.findings.append(
                Finding(
                    rule_id="ALG323",
                    title="ASA metadata URL is plain HTTP",
                    severity=Severity.LOW,
                    message="Asset URL uses insecure transport; prefer HTTPS or content-addressed references.",
                    location=Location(file_path=Path(f"asset:{asset_id}"), line=None),
                    confidence=0.85,
                    tags=["asa", "metadata", "transport"],
                    evidence={"url": url},
                )
            )

        result.metadata["asset"] = {
            "asset_id": asset_id,
            "name": params.get("name"),
            "unit_name": params.get("unit-name"),
            "total": params.get("total"),
            "decimals": params.get("decimals"),
        }
        return result
