from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from algosec.connectors.indexer_client import IndexerClient
from algosec.models import Finding, Location, ScanResult, Severity

@dataclass(slots=True)
class TransactionScanner:
    """Indexer-backed transaction risk scanner."""

    indexer_client: IndexerClient

    def run(
        self,
        *,
        address: str | None = None,
        app_id: int | None = None,
        asset_id: int | None = None,
        limit: int = 200,
    ) -> ScanResult:
        target_name = f"txns:{address or app_id or asset_id or 'all'}"
        result = ScanResult(target=Path(target_name))
        payload = self.indexer_client.search_transactions(
            address=address,
            application_id=app_id,
            asset_id=asset_id,
            limit=limit,
        )
        txns = payload.get("transactions", [])

        rekey_count = 0
        close_count = 0
        asset_close_count = 0
        high_fee_count = 0

        for txn in txns:
            txid = str(txn.get("id", "unknown"))
            rekey_to = txn.get("rekey-to")
            close_to = txn.get("close-remainder-to")
            fee = int(txn.get("fee", 0) or 0)

            if rekey_to:
                rekey_count += 1
                result.findings.append(
                    Finding(
                        rule_id="ALG311",
                        title="Transaction contains rekey-to",
                        severity=Severity.HIGH,
                        message=f"Transaction {txid} sets rekey-to; review signer delegation intent.",
                        location=Location(file_path=Path(f"tx:{txid}"), line=None),
                        confidence=0.94,
                        tags=["transaction", "rekey"],
                    )
                )

            if close_to:
                close_count += 1
                result.findings.append(
                    Finding(
                        rule_id="ALG312",
                        title="Transaction closes remainder",
                        severity=Severity.HIGH,
                        message=f"Transaction {txid} includes close remainder destination.",
                        location=Location(file_path=Path(f"tx:{txid}"), line=None),
                        confidence=0.9,
                        tags=["transaction", "close-remainder"],
                    )
                )

            axfer = txn.get("asset-transfer-transaction", {})
            if isinstance(axfer, dict) and axfer.get("close-to"):
                asset_close_count += 1
                result.findings.append(
                    Finding(
                        rule_id="ALG313",
                        title="Asset transfer uses close-to",
                        severity=Severity.HIGH,
                        message=f"Transaction {txid} has asset close-to destination.",
                        location=Location(file_path=Path(f"tx:{txid}"), line=None),
                        confidence=0.88,
                        tags=["transaction", "asset-close"],
                    )
                )

            if fee > 10_000:
                high_fee_count += 1
                result.findings.append(
                    Finding(
                        rule_id="ALG314",
                        title="High-fee transaction",
                        severity=Severity.MEDIUM,
                        message=f"Transaction {txid} fee={fee} microAlgos exceeds threshold.",
                        location=Location(file_path=Path(f"tx:{txid}"), line=None),
                        confidence=0.8,
                        tags=["transaction", "fee-anomaly"],
                        evidence={"fee": str(fee)},
                    )
                )

        result.metadata["transactions"] = {
            "analyzed": len(txns),
            "rekey_count": rekey_count,
            "close_remainder_count": close_count,
            "asset_close_count": asset_close_count,
            "high_fee_count": high_fee_count,
            "filters": {
                "address": address,
                "app_id": app_id,
                "asset_id": asset_id,
                "limit": limit,
            },
        }
        return result
