"""Scanner module namespace for future analyzers."""
