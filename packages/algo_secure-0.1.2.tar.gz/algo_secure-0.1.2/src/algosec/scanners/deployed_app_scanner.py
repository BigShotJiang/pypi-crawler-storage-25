from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from algosec.connectors.algod_client import AlgodClient
from algosec.models import Finding, Location, ScanResult, Severity

@dataclass(slots=True)
class DeployedAppScanner:
    """Deployed app scanner for live Algorand application analysis."""

    algod_client: AlgodClient

    def run(self, app_id: int) -> ScanResult:
        result = ScanResult(target=Path(f"onchain-app-{app_id}"))
        payload = self.algod_client.application_info(app_id)
        params = payload.get("params", {})

        approval = params.get("approval-program")
        clear = params.get("clear-state-program")
        gschema = params.get("global-state-schema", {})

        result.metadata["application"] = {
            "app_id": app_id,
            "creator": params.get("creator"),
            "global_schema": gschema,
        }

        if not approval or not clear:
            result.findings.append(
                Finding(
                    rule_id="ALG201",
                    title="Missing deployed program payload",
                    severity=Severity.HIGH,
                    message="Application response does not include complete approval/clear programs.",
                    location=Location(file_path=Path(f"app:{app_id}"), line=None),
                    confidence=0.88,
                    tags=["deployed-app", "integrity"],
                )
            )

        global_ints = int(gschema.get("num-uint", 0) or 0)
        global_bytes = int(gschema.get("num-byte-slice", 0) or 0)
        if global_ints + global_bytes == 0:
            result.findings.append(
                Finding(
                    rule_id="ALG202",
                    title="No global state schema declared",
                    severity=Severity.MEDIUM,
                    message="Deployed app has zero global schema. Verify this is intentional for protocol logic.",
                    location=Location(file_path=Path(f"app:{app_id}"), line=None),
                    confidence=0.7,
                    tags=["deployed-app", "state-model"],
                )
            )

        return result
