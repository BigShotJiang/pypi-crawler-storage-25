from __future__ import annotations

from rich import box
from rich.console import Console
from rich.columns import Columns
from rich.panel import Panel
from rich.rule import Rule
from rich.table import Table
from rich.text import Text


def render_home() -> None:
    console = Console()
    banner = Text()
    banner.append(" █████╗       ███████╗███████╗ ██████╗ ██╗   ██╗██████╗ ███████╗\n", style="bold bright_cyan")
    banner.append("██╔══██╗      ██╔════╝██╔════╝██╔════╝ ██║   ██║██╔══██╗██╔════╝\n", style="bold cyan")
    banner.append("███████║█████╗███████╗█████╗  ██║      ██║   ██║██████╔╝█████╗  \n", style="bold bright_magenta")
    banner.append("██╔══██║╚════╝╚════██║██╔══╝  ██║      ██║   ██║██╔══██╗██╔══╝  \n", style="bold magenta")
    banner.append("██║  ██║      ███████║███████╗╚██████╗ ╚██████╔╝██║  ██║███████╗\n", style="bold white")
    banner.append("╚═╝  ╚═╝      ╚══════╝╚══════╝ ╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚══════╝\n", style="bold white")
    banner.append("\n", style="bold white")
    banner.append("                           A Secure", style="bold bright_cyan")
    banner.append("\n", style="bold white")
    banner.append("            Advanced Contract Risk Intelligence Suite", style="bright_white")
    console.print(Panel(banner, border_style="bright_magenta", box=box.DOUBLE_EDGE, padding=(0, 2)))

    command_map = Table(title="[bold bright_cyan]Workflow Map[/bold bright_cyan]", box=box.ROUNDED, header_style="bold bright_cyan")
    command_map.add_column("Workflow", style="bold white")
    command_map.add_column("Commands", style="bright_white")
    command_map.add_row("Analyze", "scan, alg_scan, test-pyteal")
    command_map.add_row("On-chain", "scan-account, scan-asset, scan-transactions, scan-deployed-app")
    command_map.add_row("AI", "ai-status, ai-run, alg_ai_run")
    command_map.add_row("Remediation", "fix-contract, alg_fix_contract")
    command_map.add_row("Premium / Deploy", "premium-status, deploy-token-registry-testnet, deploy-subscription-testnet")
    command_map.add_row("API", "serve")

    examples = Table(title="[bold bright_magenta]Quick Start[/bold bright_magenta]", box=box.ROUNDED, header_style="bold bright_magenta")
    examples.add_column("#", justify="right", style="bold white", no_wrap=True)
    examples.add_column("Command", style="white")
    examples.add_row("1", "alg alg_scan examples/incoming_contracts/random_user_contract.py")
    examples.add_row("2", "alg ai-run \"Assess transfer risk\" --scan-target <file> --action transfer")
    examples.add_row("3", "alg fix-contract <vulnerable.py> --verify")
    examples.add_row("4", "alg alg_scan <path> -f html -o report.html")
    examples.add_row("5", "alg premium-status <wallet> --asset-id <id> --min-balance 100")

    tips = Panel(
        "[bold]Tips[/bold]\n"
        "• Use [bright_cyan]alg <command> --help[/bright_cyan] for command options\n"
        "• Compare versions: [bright_cyan]alg diff <baseline_contract> <current_contract>[/bright_cyan]\n"
        "• Best visual report: [bright_cyan]-f html -o report.html[/bright_cyan]",
        border_style="bright_magenta",
        box=box.ROUNDED,
    )

    console.print(Columns([command_map, examples], expand=True, equal=True))
    console.print(tips)

    footer = Text()
    footer.append("Formats: ", style="bold white")
    footer.append("console", style="bold bright_cyan")
    footer.append(" | ", style="dim")
    footer.append("json", style="bold bright_cyan")
    footer.append(" | ", style="dim")
    footer.append("sarif", style="bold bright_cyan")
    footer.append(" | ", style="dim")
    footer.append("markdown", style="bold bright_cyan")
    footer.append(" | ", style="dim")
    footer.append("html", style="bold bright_cyan")
    console.print(Rule(style="bright_magenta"))
    console.print(footer)
