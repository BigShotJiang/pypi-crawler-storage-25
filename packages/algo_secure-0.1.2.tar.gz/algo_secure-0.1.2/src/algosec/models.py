from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path


class Severity(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


@dataclass(slots=True)
class Location:
    file_path: Path
    line: int | None = None


@dataclass(slots=True)
class Finding:
    rule_id: str
    title: str
    severity: Severity
    message: str
    location: Location
    confidence: float = 0.5
    tags: list[str] = field(default_factory=list)
    evidence: dict[str, str] = field(default_factory=dict)


@dataclass(slots=True)
class ScanResult:
    target: Path
    findings: list[Finding] = field(default_factory=list)
    analyzed_files: list[Path] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    metadata: dict[str, object] = field(default_factory=dict)

    def add_findings(self, items: list[Finding]) -> None:
        self.findings.extend(items)
