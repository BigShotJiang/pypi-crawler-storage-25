from __future__ import annotations

from dataclasses import dataclass

from algosec.agent.decision_wrapper import build_agent_explanation
from algosec.models import ScanResult
from algosec.policy.engine import evaluate_policy
from algosec.simulator.engine import simulate_intent
from algosec.simulator.models import TxIntent


@dataclass(slots=True)
class SafeExecutionDecision:
    allowed: bool
    status: str
    explanation: dict
    simulation: dict


def evaluate_safe_execution(
    *,
    scan_result: ScanResult,
    intent: TxIntent,
    profile: str = "strict-defi",
    state: dict[str, int] | None = None,
) -> SafeExecutionDecision:
    simulation = simulate_intent(intent, current_state=state)
    sim_signals = [
        {
            "code": s.code,
            "message": s.message,
            "severity": s.severity,
            "exploitability": s.exploitability,
        }
        for s in simulation.signals
    ]

    policy_eval = evaluate_policy(scan_result=scan_result, simulation_signals=sim_signals, profile=profile)
    explanation = build_agent_explanation(
        policy_eval=policy_eval,
        context={
            "action": intent.action,
            "simulation_outcome": simulation.outcome,
            "signals": sim_signals,
        },
    )

    allowed = policy_eval.decision.value == "ALLOW"
    status = "safe" if allowed else "unsafe" if policy_eval.decision.value == "BLOCK" else "review"

    return SafeExecutionDecision(
        allowed=allowed,
        status=status,
        explanation=explanation,
        simulation={
            "action": simulation.action,
            "outcome": simulation.outcome,
            "signals": sim_signals,
            "state": simulation.state,
        },
    )
