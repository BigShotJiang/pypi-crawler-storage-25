from __future__ import annotations

import hashlib
import random
import tempfile
from dataclasses import asdict
from pathlib import Path

from algosec.analysis.pyteal_adapter import looks_like_pyteal_source
from algosec.discovery import discover_targets
from algosec.engine import scan_path
from algosec.testing.models import PyTealTestReport, TestCaseResult


def _collect_pyteal_contracts(target: Path) -> list[Path]:
    items = discover_targets(target)
    out: list[Path] = []
    for path in items:
        if path.suffix.lower() not in {".py", ".pyteal"}:
            continue
        if looks_like_pyteal_source(path):
            out.append(path)
    return sorted(out)


def _rules(scan_result) -> list[str]:
    return sorted({f.rule_id for f in scan_result.findings})


def _has_any(observed: list[str], expected: list[str]) -> bool:
    return bool(set(observed).intersection(expected))


def _static_case(path: Path) -> TestCaseResult:
    res = scan_path(path)
    observed = _rules(res)
    if res.errors:
        return TestCaseResult(
            case_id=f"{path.stem}-static",
            contract=path.name,
            title="Static scan should execute successfully",
            status="failed",
            error_type="scan-runtime-error",
            explanation="Engine reported runtime errors while scanning this contract.",
            observed_rules=observed,
            findings_count=len(res.findings),
            errors_count=len(res.errors),
        )

    return TestCaseResult(
        case_id=f"{path.stem}-static",
        contract=path.name,
        title="Static scan should execute successfully",
        status="passed",
        error_type=None,
        explanation="Scan completed without runtime errors.",
        observed_rules=observed,
        findings_count=len(res.findings),
        errors_count=0,
    )


def _expectation_oracles(path: Path) -> list[tuple[str, list[str], str]]:
    text = path.read_text(encoding="utf-8")
    cases: list[tuple[str, list[str], str]] = []

    if "Txn.on_completion()" in text and (
        "OnComplete.UpdateApplication" in text or "OnComplete.DeleteApplication" in text
    ) and "Txn.sender() == Global.creator_address()" not in text:
        cases.append(("unguarded update/delete path", ["ALG401", "ALG003"], "admin-path-auth"))

    if "Txn.rekey_to()" in text and "Txn.rekey_to() == Global.zero_address()" not in text:
        cases.append(("missing rekey guard", ["ALG402", "ALG001"], "rekey-guard"))

    if "Txn.close_remainder_to()" in text and "Txn.close_remainder_to() == Global.zero_address()" not in text:
        cases.append(("missing close remainder guard", ["ALG403", "ALG002"], "close-remainder-guard"))

    if "Txn.asset_close_to()" in text and "Txn.asset_close_to() == Global.zero_address()" not in text:
        cases.append(("missing asset close guard", ["ALG404", "ALG104"], "asset-close-guard"))

    if "Txn.application_args[" in text and (
        "Txn.application_args.length()" not in text and "Txn.num_app_args()" not in text
    ):
        cases.append(("missing app args bounds check", ["ALG405", "ALG106"], "args-bounds"))

    if "TxnField.receiver: Txn.sender()" in text:
        cases.append(("tainted receiver path", ["ALG105"], "taint-receiver"))

    return cases


def _oracle_case(path: Path, title: str, expected: list[str], family: str) -> TestCaseResult:
    res = scan_path(path)
    observed = _rules(res)

    if res.errors:
        return TestCaseResult(
            case_id=f"{path.stem}-oracle-{family}",
            contract=path.name,
            title=f"Oracle: {title}",
            status="failed",
            error_type="scan-runtime-error",
            explanation="Oracle test could not run due to scan runtime errors.",
            expected_rules=expected,
            observed_rules=observed,
            findings_count=len(res.findings),
            errors_count=len(res.errors),
        )

    if not _has_any(observed, expected):
        return TestCaseResult(
            case_id=f"{path.stem}-oracle-{family}",
            contract=path.name,
            title=f"Oracle: {title}",
            status="failed",
            error_type="oracle-miss",
            explanation="Expected vulnerability family was inferred from code but matching rule did not trigger.",
            expected_rules=expected,
            observed_rules=observed,
            findings_count=len(res.findings),
            errors_count=0,
        )

    return TestCaseResult(
        case_id=f"{path.stem}-oracle-{family}",
        contract=path.name,
        title=f"Oracle: {title}",
        status="passed",
        error_type=None,
        explanation="Expected vulnerability family was detected.",
        expected_rules=expected,
        observed_rules=observed,
        findings_count=len(res.findings),
        errors_count=0,
    )


def _mutations_for_text(text: str) -> list[tuple[str, str, list[str], str]]:
    mutations: list[tuple[str, str, list[str], str]] = []

    if "Txn.rekey_to() == Global.zero_address()" in text:
        mutated = text.replace(
            "Txn.rekey_to() == Global.zero_address()",
            "Txn.rekey_to() == Global.creator_address()",
            1,
        )
        mutations.append(("break-rekey-guard", mutated, ["ALG402", "ALG001"], "guard-regression"))

    if "Txn.close_remainder_to() == Global.zero_address()" in text:
        mutated = text.replace(
            "Txn.close_remainder_to() == Global.zero_address()",
            "Txn.close_remainder_to() == Global.creator_address()",
            1,
        )
        mutations.append(("break-close-guard", mutated, ["ALG403", "ALG002"], "guard-regression"))

    if "Txn.asset_close_to() == Global.zero_address()" in text:
        mutated = text.replace(
            "Txn.asset_close_to() == Global.zero_address()",
            "Txn.asset_close_to() == Global.creator_address()",
            1,
        )
        mutations.append(("break-asset-close-guard", mutated, ["ALG404", "ALG104"], "guard-regression"))

    if "Txn.sender() == Global.creator_address()" in text and "Txn.on_completion()" in text:
        mutated = text.replace(
            "Txn.sender() == Global.creator_address()",
            "Txn.sender() == Txn.sender()",
            1,
        )
        mutations.append(("break-admin-auth", mutated, ["ALG401", "ALG003"], "auth-regression"))

    if "Txn.application_args.length() >=" in text and "Txn.application_args[" in text:
        mutated = text.replace(
            "Txn.application_args.length() >=",
            "Txn.application_args.length() <",
            1,
        )
        mutations.append(("break-args-bound", mutated, ["ALG405", "ALG106"], "bounds-regression"))

    return mutations


def _fuzz_cases(path: Path, fuzz_rounds: int, max_mutations: int) -> list[TestCaseResult]:
    text = path.read_text(encoding="utf-8")
    candidates = _mutations_for_text(text)
    if not candidates:
        return [
            TestCaseResult(
                case_id=f"{path.stem}-fuzz-skip",
                contract=path.name,
                title="Mutation fuzz coverage",
                status="skipped",
                error_type=None,
                explanation="No applicable guard/auth mutation templates found for this contract.",
            )
        ]

    digest = int(hashlib.sha1(str(path).encode("utf-8")).hexdigest(), 16)  # noqa: S324
    rng = random.Random(digest)

    rounds = min(max_mutations, max(1, fuzz_rounds), len(candidates))
    selected = rng.sample(candidates, k=rounds)

    cases: list[TestCaseResult] = []
    with tempfile.TemporaryDirectory(prefix="aplussec-fuzz-") as td:
        tmp_dir = Path(td)
        for i, (name, mutated, expected, family) in enumerate(selected, start=1):
            mutant_path = tmp_dir / f"{path.stem}__mut_{i}.py"
            mutant_path.write_text(mutated, encoding="utf-8")
            res = scan_path(mutant_path)
            observed = _rules(res)

            if res.errors:
                cases.append(
                    TestCaseResult(
                        case_id=f"{path.stem}-fuzz-{name}-{i}",
                        contract=path.name,
                        title=f"Fuzz mutation {name}",
                        status="failed",
                        error_type="mutation-compile-error",
                        explanation="Mutated contract did not compile/scan successfully.",
                        expected_rules=expected,
                        observed_rules=observed,
                        findings_count=len(res.findings),
                        errors_count=len(res.errors),
                    )
                )
                continue

            if not _has_any(observed, expected):
                cases.append(
                    TestCaseResult(
                        case_id=f"{path.stem}-fuzz-{name}-{i}",
                        contract=path.name,
                        title=f"Fuzz mutation {name}",
                        status="failed",
                        error_type="mutation-oracle-miss",
                        explanation="Mutation injected expected risk but scanner did not emit matching rule family.",
                        expected_rules=expected,
                        observed_rules=observed,
                        findings_count=len(res.findings),
                        errors_count=0,
                    )
                )
                continue

            cases.append(
                TestCaseResult(
                    case_id=f"{path.stem}-fuzz-{name}-{i}",
                    contract=path.name,
                    title=f"Fuzz mutation {name}",
                    status="passed",
                    error_type=None,
                    explanation="Mutation produced expected rule family detection.",
                    expected_rules=expected,
                    observed_rules=observed,
                    findings_count=len(res.findings),
                    errors_count=0,
                )
            )

    return cases


def run_pyteal_test_lab(target: Path, *, fuzz_rounds: int = 3, max_mutations: int = 4) -> PyTealTestReport:
    contracts = _collect_pyteal_contracts(target)
    cases: list[TestCaseResult] = []

    for contract in contracts:
        cases.append(_static_case(contract))

        for title, expected, family in _expectation_oracles(contract):
            cases.append(_oracle_case(contract, title, expected, family))

        cases.extend(_fuzz_cases(contract, fuzz_rounds=fuzz_rounds, max_mutations=max_mutations))

    passed = sum(1 for c in cases if c.status == "passed")
    failed = sum(1 for c in cases if c.status == "failed")
    skipped = sum(1 for c in cases if c.status == "skipped")

    contracts_with_engine_errors = len(
        {
            c.contract
            for c in cases
            if c.error_type in {"scan-runtime-error", "mutation-compile-error"}
        }
    )

    return PyTealTestReport(
        target=target,
        total_contracts=len(contracts),
        total_cases=len(cases),
        passed_cases=passed,
        failed_cases=failed,
        skipped_cases=skipped,
        contracts_with_engine_errors=contracts_with_engine_errors,
        cases=cases,
    )


def report_to_dict(report: PyTealTestReport) -> dict:
    return {
        "target": str(report.target),
        "total_contracts": report.total_contracts,
        "total_cases": report.total_cases,
        "passed_cases": report.passed_cases,
        "failed_cases": report.failed_cases,
        "skipped_cases": report.skipped_cases,
        "contracts_with_engine_errors": report.contracts_with_engine_errors,
        "cases": [asdict(case) for case in report.cases],
    }
