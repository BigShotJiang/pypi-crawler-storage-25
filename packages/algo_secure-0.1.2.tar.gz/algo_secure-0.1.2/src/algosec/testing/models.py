from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass(slots=True)
class TestCaseResult:
    case_id: str
    contract: str
    title: str
    status: str
    error_type: str | None
    explanation: str
    expected_rules: list[str] = field(default_factory=list)
    observed_rules: list[str] = field(default_factory=list)
    findings_count: int = 0
    errors_count: int = 0


@dataclass(slots=True)
class PyTealTestReport:
    target: Path
    total_contracts: int
    total_cases: int
    passed_cases: int
    failed_cases: int
    skipped_cases: int
    contracts_with_engine_errors: int
    cases: list[TestCaseResult] = field(default_factory=list)
