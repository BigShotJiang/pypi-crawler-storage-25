from __future__ import annotations

from collections import Counter

from algosec.models import ScanResult


def compute_security_score(result: ScanResult) -> dict[str, object]:
    if result.errors and not result.analyzed_files:
        return {
            "security_score": 0,
            "risk_score": 100,
            "grade": "F",
            "max_score": 100,
            "model": "weighted-severity-confidence-v2",
            "status": "incomplete",
            "reason": "scan-errors-no-analysis",
            "deploy_verdict": "BLOCKED",
            "summary": "Analysis blocked by runtime/syntax errors. Fix scanner input errors before security verdict.",
        }

    severity_weight = {
        "critical": 25.0,
        "high": 12.0,
        "medium": 5.0,
        "low": 2.0,
        "info": 0.5,
    }

    risk_points = 0.0
    for finding in result.findings:
        weight = severity_weight.get(finding.severity.value, 5.0)
        confidence = min(1.0, max(0.1, float(finding.confidence)))
        risk_points += weight * confidence

    risk_points += min(70.0, len(result.errors) * 20.0)
    risk_score = int(min(100, round(risk_points)))
    security_score = 100 - risk_score

    sev = Counter(f.severity.value for f in result.findings)

    if result.errors:
        deploy_verdict = "BLOCKED"
    elif sev.get("critical", 0) > 0:
        deploy_verdict = "DO_NOT_DEPLOY"
    elif sev.get("high", 0) > 0:
        deploy_verdict = "REVIEW_REQUIRED"
    else:
        deploy_verdict = "READY"

    summary = (
        f"critical={sev.get('critical',0)}, high={sev.get('high',0)}, "
        f"medium={sev.get('medium',0)}, low={sev.get('low',0)}, errors={len(result.errors)}"
    )

    if security_score >= 90:
        grade = "A"
    elif security_score >= 80:
        grade = "B"
    elif security_score >= 70:
        grade = "C"
    elif security_score >= 60:
        grade = "D"
    else:
        grade = "F"

    return {
        "security_score": security_score,
        "risk_score": risk_score,
        "grade": grade,
        "max_score": 100,
        "model": "weighted-severity-confidence-v3",
        "status": "complete" if not result.errors else "complete-with-errors",
        "deploy_verdict": deploy_verdict,
        "summary": summary,
    }
