from __future__ import annotations

import base64
from dataclasses import dataclass

from algosdk import mnemonic
from algosdk.v2client import algod
from algosdk import transaction
from pyteal import App, Approve, Assert, Btoi, Bytes, Cond, Global, Int, Mode, Seq, Txn, compileTeal


@dataclass(slots=True)
class DeployResult:
    app_id: int
    tx_id: str
    creator: str
    algod_address: str


def _approval_program() -> str:
    admin_key = Bytes("admin")
    asa_key = Bytes("asa")
    min_key = Bytes("min")

    on_create = Seq(
        Assert(Txn.application_args.length() == Int(2)),
        App.globalPut(admin_key, Txn.sender()),
        App.globalPut(asa_key, Btoi(Txn.application_args[0])),
        App.globalPut(min_key, Btoi(Txn.application_args[1])),
        Approve(),
    )

    is_admin = Txn.sender() == App.globalGet(admin_key)

    update_min = Seq(
        Assert(Txn.application_args.length() == Int(2)),
        Assert(is_admin),
        App.globalPut(min_key, Btoi(Txn.application_args[1])),
        Approve(),
    )

    update_asa = Seq(
        Assert(Txn.application_args.length() == Int(2)),
        Assert(is_admin),
        App.globalPut(asa_key, Btoi(Txn.application_args[1])),
        Approve(),
    )

    program = Seq(
        Assert(Txn.rekey_to() == Global.zero_address()),
        Assert(Txn.close_remainder_to() == Global.zero_address()),
        Assert(Txn.asset_close_to() == Global.zero_address()),
        Cond(
            [Txn.application_id() == Int(0), on_create],
            [Txn.application_args[0] == Bytes("set_min"), update_min],
            [Txn.application_args[0] == Bytes("set_asa"), update_asa],
        ),
    )
    return compileTeal(program, Mode.Application, version=8)


def _clear_program() -> str:
    return compileTeal(Approve(), Mode.Application, version=8)


def _compile(client: algod.AlgodClient, source: str) -> bytes:
    compiled = client.compile(source)
    return base64.b64decode(compiled["result"])


def deploy_token_registry_testnet(
    *,
    algod_address: str,
    algod_token: str,
    creator_mnemonic: str,
    entitlement_asa_id: int,
    min_balance: int,
) -> DeployResult:
    if "testnet" not in algod_address.lower():
        raise ValueError("Refusing deploy: algod_address must target testnet")

    client = algod.AlgodClient(algod_token=algod_token, algod_address=algod_address)

    approval = _compile(client, _approval_program())
    clear = _compile(client, _clear_program())

    private_key = mnemonic.to_private_key(creator_mnemonic)
    creator = mnemonic.to_public_key(creator_mnemonic)

    sp = client.suggested_params()
    app_args = [int(entitlement_asa_id).to_bytes(8, "big"), int(min_balance).to_bytes(8, "big")]

    txn = transaction.ApplicationCreateTxn(
        sender=creator,
        sp=sp,
        on_complete=transaction.OnComplete.NoOpOC,
        approval_program=approval,
        clear_program=clear,
        global_schema=transaction.StateSchema(num_uints=2, num_byte_slices=1),
        local_schema=transaction.StateSchema(num_uints=0, num_byte_slices=0),
        app_args=app_args,
    )

    signed = txn.sign(private_key)
    tx_id = client.send_transaction(signed)
    confirmed = transaction.wait_for_confirmation(client, tx_id, 8)
    app_id = int(confirmed["application-index"])

    return DeployResult(app_id=app_id, tx_id=tx_id, creator=creator, algod_address=algod_address)
