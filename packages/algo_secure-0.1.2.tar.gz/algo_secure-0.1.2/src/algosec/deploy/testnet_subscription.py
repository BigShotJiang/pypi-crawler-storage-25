from __future__ import annotations

import base64
from dataclasses import dataclass

from algosdk import mnemonic, transaction
from algosdk.v2client import algod
from pyteal import App, Approve, Assert, Btoi, Bytes, Cond, Gtxn, Global, If, InnerTxnBuilder, Int, Mode, Seq, Txn, TxnField, TxnType, compileTeal


@dataclass(slots=True)
class SubscriptionDeployResult:
    app_id: int
    tx_id: str
    creator: str
    algod_address: str


def _approval_program() -> str:
    admin_key = Bytes("admin")
    treasury_key = Bytes("treasury")
    price_key = Bytes("price")
    dur_key = Bytes("dur")
    grace_key = Bytes("grace")
    paused_key = Bytes("paused")

    tier_key = Bytes("tier")
    exp_key = Bytes("exp")
    active_key = Bytes("active")
    last_amt_key = Bytes("last_amt")
    last_ts_key = Bytes("last_ts")
    last_rnd_key = Bytes("last_rnd")

    on_create = Seq(
        Assert(Txn.application_args.length() == Int(3)),
        App.globalPut(admin_key, Txn.sender()),
        App.globalPut(treasury_key, Txn.sender()),
        App.globalPut(price_key, Btoi(Txn.application_args[0])),
        App.globalPut(dur_key, Btoi(Txn.application_args[1])),
        App.globalPut(grace_key, Btoi(Txn.application_args[2])),
        App.globalPut(paused_key, Int(0)),
        Approve(),
    )

    is_admin = Txn.sender() == App.globalGet(admin_key)

    common_guards = Seq(
        Assert(Txn.rekey_to() == Global.zero_address()),
        Assert(Txn.close_remainder_to() == Global.zero_address()),
        Assert(Txn.asset_close_to() == Global.zero_address()),
        Assert(App.globalGet(paused_key) == Int(0)),
    )

    subscribe = Seq(
        common_guards,
        Assert(Global.group_size() == Int(2)),
        Assert(Txn.group_index() == Int(1)),
        Assert(Gtxn[0].type_enum() == TxnType.Payment),
        Assert(Gtxn[0].sender() == Txn.sender()),
        Assert(Gtxn[0].receiver() == Global.current_application_address()),
        Assert(Gtxn[0].amount() == App.globalGet(price_key)),
        App.localPut(Txn.sender(), tier_key, Int(1)),
        App.localPut(
            Txn.sender(),
            exp_key,
            If(App.localGet(Txn.sender(), exp_key) > Global.latest_timestamp())
            .Then(App.localGet(Txn.sender(), exp_key) + App.globalGet(dur_key))
            .Else(Global.latest_timestamp() + App.globalGet(dur_key)),
        ),
        App.localPut(Txn.sender(), active_key, Int(1)),
        App.localPut(Txn.sender(), last_amt_key, Gtxn[0].amount()),
        App.localPut(Txn.sender(), last_ts_key, Global.latest_timestamp()),
        App.localPut(Txn.sender(), last_rnd_key, Global.round()),
        Approve(),
    )

    set_plan = Seq(
        Assert(is_admin),
        Assert(Txn.application_args.length() == Int(3)),
        App.globalPut(price_key, Btoi(Txn.application_args[1])),
        App.globalPut(dur_key, Btoi(Txn.application_args[2])),
        Approve(),
    )

    set_pause = Seq(
        Assert(is_admin),
        Assert(Txn.application_args.length() == Int(2)),
        App.globalPut(paused_key, Btoi(Txn.application_args[1])),
        Approve(),
    )

    set_treasury = Seq(
        Assert(is_admin),
        Assert(Txn.application_args.length() == Int(2)),
        App.globalPut(treasury_key, Txn.accounts[1]),
        Approve(),
    )

    withdraw = Seq(
        Assert(is_admin),
        Assert(Txn.application_args.length() == Int(2)),
        InnerTxnBuilder.Begin(),
        InnerTxnBuilder.SetFields(
            {
                TxnField.type_enum: TxnType.Payment,
                TxnField.receiver: App.globalGet(treasury_key),
                TxnField.amount: Btoi(Txn.application_args[1]),
                TxnField.fee: Int(0),
            }
        ),
        InnerTxnBuilder.Submit(),
        Approve(),
    )

    status = Seq(common_guards, Approve())

    program = Cond(
        [Txn.application_id() == Int(0), on_create],
        [Txn.application_args[0] == Bytes("subscribe"), subscribe],
        [Txn.application_args[0] == Bytes("renew"), subscribe],
        [Txn.application_args[0] == Bytes("set_plan"), set_plan],
        [Txn.application_args[0] == Bytes("set_pause"), set_pause],
        [Txn.application_args[0] == Bytes("set_treasury"), set_treasury],
        [Txn.application_args[0] == Bytes("withdraw"), withdraw],
        [Txn.application_args[0] == Bytes("status"), status],
    )

    return compileTeal(program, Mode.Application, version=8)


def _clear_program() -> str:
    return compileTeal(Approve(), Mode.Application, version=8)


def _compile(client: algod.AlgodClient, source: str) -> bytes:
    compiled = client.compile(source)
    return base64.b64decode(compiled["result"])


def deploy_subscription_testnet(
    *,
    algod_address: str,
    algod_token: str,
    creator_mnemonic: str,
    price_microalgos: int,
    duration_seconds: int,
    grace_seconds: int,
) -> SubscriptionDeployResult:
    if "testnet" not in algod_address.lower():
        raise ValueError("Refusing deploy: algod_address must target testnet")

    client = algod.AlgodClient(algod_token=algod_token, algod_address=algod_address)
    approval = _compile(client, _approval_program())
    clear = _compile(client, _clear_program())

    private_key = mnemonic.to_private_key(creator_mnemonic)
    creator = mnemonic.to_public_key(creator_mnemonic)

    sp = client.suggested_params()
    app_args = [
        int(price_microalgos).to_bytes(8, "big"),
        int(duration_seconds).to_bytes(8, "big"),
        int(grace_seconds).to_bytes(8, "big"),
    ]

    txn = transaction.ApplicationCreateTxn(
        sender=creator,
        sp=sp,
        on_complete=transaction.OnComplete.NoOpOC,
        approval_program=approval,
        clear_program=clear,
        global_schema=transaction.StateSchema(num_uints=4, num_byte_slices=2),
        local_schema=transaction.StateSchema(num_uints=6, num_byte_slices=0),
        app_args=app_args,
    )

    signed = txn.sign(private_key)
    tx_id = client.send_transaction(signed)
    confirmed = transaction.wait_for_confirmation(client, tx_id, 8)
    app_id = int(confirmed["application-index"])

    return SubscriptionDeployResult(app_id=app_id, tx_id=tx_id, creator=creator, algod_address=algod_address)
