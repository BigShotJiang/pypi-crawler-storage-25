from __future__ import annotations

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from algosec.api.config import load_api_settings
from algosec.api.routes.agent import router as agent_router
from algosec.api.routes.analyze_tx import router as analyze_tx_router
from algosec.api.routes.auth import router as auth_router
from algosec.api.routes.safe_execute import router as safe_execute_router
from algosec.api.routes.scan import router as scan_router
from algosec.api.routes.simulate import router as simulate_router
from algosec.monetization.auth_service import verify_access_token

settings = load_api_settings()

PREMIUM_PATH_PREFIXES = ("/agent", "/safe_execute", "/analyze_tx")

app = FastAPI(
    title="A+ SEC Agentic Smart Contract Firewall",
    version="0.2.0",
    description=(
        "Agent-powered runtime security layer for Algorand contracts: "
        "scan, simulate, transaction analysis, and policy-gated safe execution."
    ),
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins or ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def startup_validation() -> None:
    if settings.require_api_key and not settings.api_key:
        raise RuntimeError("ALGOSEC_REQUIRE_API_KEY is enabled but ALGOSEC_API_KEY is not set")
    if settings.entitlement_enabled and settings.entitlement_mode == "subscription" and settings.entitlement_subscription_app_id is None:
        raise RuntimeError("ALGOSEC_ENTITLEMENT_MODE=subscription requires ALGOSEC_ENTITLEMENT_SUBSCRIPTION_APP_ID")


@app.middleware("http")
async def api_key_guard(request: Request, call_next):
    if settings.require_api_key and request.url.path not in {"/health", "/docs", "/openapi.json", "/redoc"}:
        provided = request.headers.get("x-api-key") or request.headers.get("authorization")
        token = provided.removeprefix("Bearer ").strip() if provided else ""
        if token != (settings.api_key or ""):
            return JSONResponse(status_code=401, content={"detail": "Unauthorized"})

    if settings.entitlement_enabled and request.url.path.startswith(PREMIUM_PATH_PREFIXES):
        provided = request.headers.get("authorization", "")
        token = provided.removeprefix("Bearer ").strip()
        payload = verify_access_token(token)
        if payload is None:
            return JSONResponse(status_code=401, content={"detail": "Premium access token required"})
        if str(payload.get("tier", "free")).lower() != "premium":
            return JSONResponse(status_code=403, content={"detail": "Premium token entitlement required"})

    return await call_next(request)


@app.get("/health")
def health() -> dict:
    return {
        "status": "ok",
        "service": "aplussec-firewall",
        "llm_provider": settings.llm_provider,
        "auth_required": settings.require_api_key,
        "entitlement_enabled": settings.entitlement_enabled,
        "entitlement_mode": settings.entitlement_mode,
        "premium_paths": list(PREMIUM_PATH_PREFIXES),
    }


app.include_router(scan_router)
app.include_router(analyze_tx_router)
app.include_router(simulate_router)
app.include_router(safe_execute_router)
app.include_router(agent_router)
app.include_router(auth_router)
