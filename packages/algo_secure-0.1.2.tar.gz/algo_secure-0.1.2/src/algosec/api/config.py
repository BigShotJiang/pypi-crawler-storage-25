from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(slots=True)
class ApiSettings:
    host: str = "127.0.0.1"
    port: int = 8080
    cors_origins: list[str] | None = None
    api_key: str | None = None
    require_api_key: bool = False
    llm_provider: str = "gemini"
    gemini_model: str = "gemini-flash-latest"
    entitlement_enabled: bool = False
    entitlement_mode: str = "asa"
    entitlement_asset_id: int | None = None
    entitlement_min_balance: int = 100
    entitlement_indexer_url: str = "http://localhost:8980"
    entitlement_indexer_token: str = ""
    entitlement_algod_url: str = "https://testnet-api.algonode.cloud"
    entitlement_algod_token: str = ""
    entitlement_subscription_app_id: int | None = None
    entitlement_required_tier: str = "premium"
    auth_secret: str = ""


def _to_bool(value: str | None, *, default: bool = False) -> bool:
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def load_api_settings() -> ApiSettings:
    raw_origins = os.getenv("ALGOSEC_CORS_ORIGINS", "*")
    origins = [item.strip() for item in raw_origins.split(",") if item.strip()]
    if not origins:
        origins = ["*"]

    api_key = os.getenv("ALGOSEC_API_KEY")
    require_api_key = _to_bool(os.getenv("ALGOSEC_REQUIRE_API_KEY"), default=bool(api_key))

    return ApiSettings(
        host=os.getenv("ALGOSEC_HOST", "127.0.0.1"),
        port=int(os.getenv("ALGOSEC_PORT", "8080")),
        cors_origins=origins,
        api_key=api_key,
        require_api_key=require_api_key,
        llm_provider=os.getenv("ALGOSEC_LLM_PROVIDER", "gemini").strip().lower(),
        gemini_model=os.getenv("ALGOSEC_GEMINI_MODEL", "gemini-flash-latest"),
        entitlement_enabled=_to_bool(os.getenv("ALGOSEC_ENTITLEMENT_ENABLED"), default=False),
        entitlement_mode=os.getenv("ALGOSEC_ENTITLEMENT_MODE", "asa").strip().lower(),
        entitlement_asset_id=int(os.getenv("ALGOSEC_ENTITLEMENT_ASA_ID")) if os.getenv("ALGOSEC_ENTITLEMENT_ASA_ID") else None,
        entitlement_min_balance=int(os.getenv("ALGOSEC_ENTITLEMENT_MIN_BALANCE", "100")),
        entitlement_indexer_url=os.getenv("ALGOSEC_ENTITLEMENT_INDEXER_URL", "http://localhost:8980"),
        entitlement_indexer_token=os.getenv("ALGOSEC_ENTITLEMENT_INDEXER_TOKEN", ""),
        entitlement_algod_url=os.getenv("ALGOSEC_ENTITLEMENT_ALGOD_URL", "https://testnet-api.algonode.cloud"),
        entitlement_algod_token=os.getenv("ALGOSEC_ENTITLEMENT_ALGOD_TOKEN", ""),
        entitlement_subscription_app_id=(
            int(os.getenv("ALGOSEC_ENTITLEMENT_SUBSCRIPTION_APP_ID"))
            if os.getenv("ALGOSEC_ENTITLEMENT_SUBSCRIPTION_APP_ID")
            else None
        ),
        entitlement_required_tier=os.getenv("ALGOSEC_ENTITLEMENT_REQUIRED_TIER", "premium").strip().lower(),
        auth_secret=os.getenv("ALGOSEC_AUTH_SECRET", ""),
    )
