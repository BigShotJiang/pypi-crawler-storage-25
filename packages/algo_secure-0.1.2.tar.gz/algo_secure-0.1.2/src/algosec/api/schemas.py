from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field, model_validator

PolicyProfile = Literal["strict-defi", "balanced"]


class ScanRequest(BaseModel):
    target: str | None = Field(default=None, description="File or directory path to scan")
    source_code: str | None = Field(default=None, description="Inline source code to scan")
    source_suffix: str = Field(default=".py", description="Suffix used when scanning inline source")

    @model_validator(mode="after")
    def validate_scan_source(self) -> "ScanRequest":
        if self.target and self.source_code:
            raise ValueError("Provide either target or source_code, not both")
        if not self.target and not self.source_code:
            raise ValueError("Either target or source_code must be provided")
        return self


class TxAnalyzeRequest(BaseModel):
    payload: dict | None = None
    indexer_url: str | None = None
    indexer_token: str = ""
    address: str | None = None
    app_id: int | None = None
    asset_id: int | None = None
    limit: int = 200


class SimulateRequest(BaseModel):
    action: str
    sender: str | None = None
    receiver: str | None = None
    amount: int | None = None
    app_args: list[str] = Field(default_factory=list)
    group_size: int | None = None
    payment_in_group: bool = False
    payment_sender: str | None = None
    payment_receiver: str | None = None
    state: dict[str, int] = Field(default_factory=dict)


class SafeExecuteRequest(BaseModel):
    scan_target: str | None = None
    scan_source_code: str | None = None
    scan_source_suffix: str = ".py"
    profile: PolicyProfile = "strict-defi"

    action: str
    sender: str | None = None
    receiver: str | None = None
    amount: int | None = None
    app_args: list[str] = Field(default_factory=list)
    group_size: int | None = None
    payment_in_group: bool = False
    payment_sender: str | None = None
    payment_receiver: str | None = None
    state: dict[str, int] = Field(default_factory=dict)
    save_explanation_markdown_path: str | None = None
    save_explanation_text_path: str | None = None

    @model_validator(mode="after")
    def validate_scan_input(self) -> "SafeExecuteRequest":
        if self.scan_target and self.scan_source_code:
            raise ValueError("Provide either scan_target or scan_source_code, not both")
        if not self.scan_target and not self.scan_source_code:
            raise ValueError("scan_target or scan_source_code is required")
        return self


class AgentRunRequest(BaseModel):
    objective: str = Field(..., description="High-level user goal for the security copilot")
    session_id: str | None = Field(default=None, description="Optional session id for multi-turn runs")
    profile: PolicyProfile = "strict-defi"

    scan_target: str | None = None
    scan_source_code: str | None = None
    scan_source_suffix: str = ".py"

    action: str = "simulate"
    sender: str | None = None
    receiver: str | None = None
    amount: int | None = None
    app_args: list[str] = Field(default_factory=list)
    group_size: int | None = None
    payment_in_group: bool = False
    payment_sender: str | None = None
    payment_receiver: str | None = None
    state: dict[str, int] = Field(default_factory=dict)

    @model_validator(mode="after")
    def validate_scan_input(self) -> "AgentRunRequest":
        if self.scan_target and self.scan_source_code:
            raise ValueError("Provide either scan_target or scan_source_code, not both")
        if not self.scan_target and not self.scan_source_code:
            raise ValueError("scan_target or scan_source_code is required")
        return self


class AuthChallengeRequest(BaseModel):
    address: str = Field(..., description="Algorand wallet address")


class AuthVerifyRequest(BaseModel):
    address: str = Field(..., description="Algorand wallet address")
    nonce: str = Field(..., description="Nonce returned by challenge endpoint")
    signature_b64: str = Field(..., description="Base64 signature of challenge message")
