from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request

from algosec.api.config import load_api_settings
from algosec.api.schemas import AuthChallengeRequest, AuthVerifyRequest
from algosec.monetization.auth_service import create_challenge, issue_access_token, verify_access_token, verify_challenge_signature
from algosec.monetization.entitlement_service import resolve_subscription_entitlement, resolve_wallet_entitlement

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/challenge")
def auth_challenge(request: AuthChallengeRequest) -> dict:
    challenge = create_challenge(address=request.address)
    return {
        "address": challenge.address,
        "nonce": challenge.nonce,
        "expires_at": challenge.expires_at,
        "message": challenge.message,
        "note": "Sign this exact message with your Algorand wallet and submit signature_b64 to /auth/verify.",
    }


@router.post("/verify")
def auth_verify(request: AuthVerifyRequest) -> dict:
    ok, msg = verify_challenge_signature(
        address=request.address,
        nonce=request.nonce,
        signature_b64=request.signature_b64,
    )
    if not ok:
        raise HTTPException(status_code=401, detail=msg)

    settings = load_api_settings()
    if settings.entitlement_mode == "subscription":
        if settings.entitlement_subscription_app_id is None:
            raise HTTPException(status_code=500, detail="Subscription entitlement app id is not configured")
        snapshot = resolve_subscription_entitlement(
            address=request.address,
            algod_url=settings.entitlement_algod_url,
            algod_token=settings.entitlement_algod_token,
            subscription_app_id=settings.entitlement_subscription_app_id,
            required_tier=settings.entitlement_required_tier,
        )
    else:
        snapshot = resolve_wallet_entitlement(
            address=request.address,
            indexer_url=settings.entitlement_indexer_url,
            indexer_token=settings.entitlement_indexer_token,
            entitlement_asset_id=settings.entitlement_asset_id,
            entitlement_min_balance=settings.entitlement_min_balance,
        )

    token = issue_access_token(address=request.address, tier=snapshot.tier)
    return {
        "access_token": token,
        "token_type": "bearer",
        "tier": snapshot.tier,
        "entitled": snapshot.entitled,
        "wallet": snapshot.wallet,
        "required_asset_id": snapshot.required_asset_id,
        "required_min_balance": snapshot.required_min_balance,
        "current_balance": snapshot.current_balance,
    }


@router.get("/me")
def auth_me(request: Request) -> dict:
    auth_header = request.headers.get("authorization", "")
    token = auth_header.removeprefix("Bearer ").strip()
    payload = verify_access_token(token)
    if payload is None:
        raise HTTPException(status_code=401, detail="Invalid or expired token")
    return payload
