from __future__ import annotations

from fastapi import APIRouter, HTTPException

from algosec.agent.session_memory import get_session
from algosec.api.schemas import AgentRunRequest
from algosec.services.agentic_service import AgenticRequest, run_agentic_workflow

router = APIRouter(prefix="/agent", tags=["agentic-ai"])


@router.post("/run")
def run_agent(request: AgentRunRequest) -> dict:
    try:
        result = run_agentic_workflow(
            AgenticRequest(
                objective=request.objective,
                session_id=request.session_id,
                profile=request.profile,
                scan_target=request.scan_target,
                scan_source_code=request.scan_source_code,
                scan_source_suffix=request.scan_source_suffix,
                action=request.action,
                sender=request.sender,
                receiver=request.receiver,
                amount=request.amount,
                app_args=request.app_args,
                group_size=request.group_size,
                payment_in_group=request.payment_in_group,
                payment_sender=request.payment_sender,
                payment_receiver=request.payment_receiver,
                state=request.state,
            )
        )
        return result
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.get("/session/{session_id}")
def get_agent_session(session_id: str) -> dict:
    session = get_session(session_id)
    if session is None:
        raise HTTPException(status_code=404, detail="Session not found")

    return {
        "session_id": session.session_id,
        "objective": session.objective,
        "created_at": session.created_at,
        "updated_at": session.updated_at,
        "runs": session.runs,
    }
