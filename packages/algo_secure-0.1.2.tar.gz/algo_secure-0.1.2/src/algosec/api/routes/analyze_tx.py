from __future__ import annotations

from fastapi import APIRouter, HTTPException

from algosec.api.schemas import TxAnalyzeRequest
from algosec.services.tx_analysis_service import analyze_tx_as_dict

router = APIRouter(prefix="/analyze_tx", tags=["tx-analysis"])


@router.post("")
def analyze_tx(request: TxAnalyzeRequest) -> dict:
    try:
        return analyze_tx_as_dict(
            payload=request.payload,
            indexer_url=request.indexer_url,
            indexer_token=request.indexer_token,
            address=request.address,
            app_id=request.app_id,
            asset_id=request.asset_id,
            limit=request.limit,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=500, detail=str(exc)) from exc
