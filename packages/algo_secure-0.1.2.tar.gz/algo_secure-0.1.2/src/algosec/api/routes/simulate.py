from __future__ import annotations

from fastapi import APIRouter, HTTPException

from algosec.api.schemas import SimulateRequest
from algosec.simulator.engine import simulate_intent
from algosec.simulator.models import TxIntent

router = APIRouter(prefix="/simulate", tags=["simulation"])


@router.post("")
def simulate_transaction(request: SimulateRequest) -> dict:
    try:
        intent = TxIntent(
            action=request.action,
            sender=request.sender,
            receiver=request.receiver,
            amount=request.amount,
            app_args=request.app_args,
            group_size=request.group_size,
            payment_in_group=request.payment_in_group,
            payment_sender=request.payment_sender,
            payment_receiver=request.payment_receiver,
        )
        simulation = simulate_intent(intent, current_state=request.state)
        return {
            "action": simulation.action,
            "outcome": simulation.outcome,
            "signals": [
                {
                    "code": s.code,
                    "message": s.message,
                    "severity": s.severity,
                    "exploitability": s.exploitability,
                }
                for s in simulation.signals
            ],
            "state": simulation.state,
        }
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=500, detail=str(exc)) from exc
