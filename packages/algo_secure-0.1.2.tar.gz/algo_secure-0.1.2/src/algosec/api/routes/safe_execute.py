from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, HTTPException

from algosec.agent.explanation_export import build_explanation_markdown, build_explanation_text
from algosec.api.schemas import SafeExecuteRequest
from algosec.executor.safe_executor import evaluate_safe_execution
from algosec.services.scan_service import run_scan_for_source, run_scan_for_target
from algosec.simulator.models import TxIntent

router = APIRouter(prefix="/safe_execute", tags=["safe-executor"])


@router.post("")
def safe_execute(request: SafeExecuteRequest) -> dict:
    try:
        if request.scan_source_code is not None:
            scan_result = run_scan_for_source(source_code=request.scan_source_code, suffix=request.scan_source_suffix)
        elif request.scan_target is not None:
            scan_result = run_scan_for_target(Path(request.scan_target))
        else:
            raise HTTPException(status_code=400, detail="scan_target or scan_source_code is required")

        intent = TxIntent(
            action=request.action,
            sender=request.sender,
            receiver=request.receiver,
            amount=request.amount,
            app_args=request.app_args,
            group_size=request.group_size,
            payment_in_group=request.payment_in_group,
            payment_sender=request.payment_sender,
            payment_receiver=request.payment_receiver,
        )

        decision = evaluate_safe_execution(
            scan_result=scan_result,
            intent=intent,
            profile=request.profile,
            state=request.state,
        )

        explanation_markdown = build_explanation_markdown(
            explanation=decision.explanation,
            simulation=decision.simulation,
        )
        explanation_text = build_explanation_text(
            explanation=decision.explanation,
            simulation=decision.simulation,
        )

        if request.save_explanation_markdown_path:
            md_path = Path(request.save_explanation_markdown_path)
            md_path.parent.mkdir(parents=True, exist_ok=True)
            md_path.write_text(explanation_markdown, encoding="utf-8")

        if request.save_explanation_text_path:
            txt_path = Path(request.save_explanation_text_path)
            txt_path.parent.mkdir(parents=True, exist_ok=True)
            txt_path.write_text(explanation_text, encoding="utf-8")

        return {
            "allowed": decision.allowed,
            "status": decision.status,
            "explanation": decision.explanation,
            "simulation": decision.simulation,
            "explanation_markdown": explanation_markdown,
            "explanation_text": explanation_text,
            "note": "This endpoint provides policy-gated decisioning. It does not broadcast transactions.",
        }
    except HTTPException:
        raise
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=500, detail=str(exc)) from exc
