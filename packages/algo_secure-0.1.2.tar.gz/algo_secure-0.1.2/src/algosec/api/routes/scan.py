from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, HTTPException

from algosec.api.schemas import ScanRequest
from algosec.services.scan_service import run_scan_as_dict

router = APIRouter(prefix="/scan", tags=["scan"])


@router.post("")
def scan_contract(request: ScanRequest) -> dict:
    try:
        if request.source_code is not None:
            return run_scan_as_dict(source_code=request.source_code, suffix=request.source_suffix)
        if request.target is None:
            raise HTTPException(status_code=400, detail="Either target or source_code must be provided")
        return run_scan_as_dict(target=Path(request.target))
    except HTTPException:
        raise
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=500, detail=str(exc)) from exc
