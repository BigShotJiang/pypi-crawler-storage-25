from __future__ import annotations

import hashlib
import time
from pathlib import Path

from algosec.analysis.pyteal_adapter import compile_pyteal_file, looks_like_pyteal_source
from algosec.analysis.contract_summary import ContractSummary, summarize_program
from algosec.analysis.cfg import build_cfg
from algosec.analysis.project_workflow import build_workflow_graph
from algosec.analysis.teal_parser import TealProgram, parse_teal_file
from algosec.detector_catalog import build_detector_list
from algosec.diagnostics import diagnose_scan_error
from algosec.discovery import discover_targets
from algosec.models import ScanResult
from algosec.rules.base import RuleContext
from algosec.rules.defi_rules import DEFI_RULES
from algosec.rules.pyteal_precheck_rules import run_pyteal_prechecks
from algosec.rules.semantic_rules import SEMANTIC_RULES
from algosec.rules.teal_rules import DEFAULT_TEAL_RULES


def _derive_attack_paths(result: ScanResult) -> list[dict[str, object]]:
    ids = {f.rule_id for f in result.findings}
    paths: list[dict[str, object]] = []

    if {"ALG407", "ALG406", "ALG105"}.issubset(ids):
        paths.append(
            {
                "id": "AP-001",
                "title": "Liquidity inflation -> under-collateralized borrow -> drain",
                "severity": "critical",
                "exploitability": "easy",
                "steps": [
                    "Attacker submits grouped transaction with mismatched payment linkage (sender/receiver/type not strictly tied).",
                    "Contract credits deposit/liquidity accounting from grouped payment amount without robust linkage assertions.",
                    "Borrow branch permits borrowing without explicit collateral-ratio / borrow-cap enforcement.",
                    "Inner transfer executes along attacker-controlled path and drains protocol liquidity.",
                ],
                "impact": [
                    "Full liquidity pool drain is possible.",
                    "User deposits become directly exposed to insolvency risk.",
                    "Protocol can become under-collateralized / insolvent.",
                ],
                "related_rules": ["ALG407", "ALG406", "ALG105"],
            }
        )

    if {"ALG106", "ALG105"}.issubset(ids):
        paths.append(
            {
                "id": "AP-002",
                "title": "Unchecked args -> tainted transfer parameters",
                "severity": "high",
                "exploitability": "easy",
                "steps": [
                    "Application arguments are consumed without strict bounds/shape checks.",
                    "Untrusted user-controlled values influence transfer-critical fields.",
                    "Inner transaction receiver/value path can be steered to unauthorized endpoints.",
                ],
                "impact": [
                    "Unauthorized transfer routing may occur.",
                    "Direct asset loss is possible for contract-controlled funds.",
                ],
                "related_rules": ["ALG106", "ALG105"],
            }
        )

    return paths


def _compiled_dir(target: Path) -> Path:
    base = target if target.is_dir() else target.parent
    out = base / ".aplussec_build"
    out.mkdir(parents=True, exist_ok=True)
    return out


def _persist_compiled_teal(*, source: Path, name: str, teal: str, out_dir: Path) -> Path:
    digest = hashlib.sha1(str(source).encode("utf-8")).hexdigest()[:8]  # noqa: S324
    output = out_dir / f"{source.stem}_{name}_{digest}.teal"
    output.write_text(teal, encoding="utf-8")
    return output


def _line_hint_in_source(source_file: Path, rule_id: str) -> int | None:
    try:
        lines = source_file.read_text(encoding="utf-8").splitlines()
    except Exception:  # noqa: BLE001
        return None

    patterns: dict[str, list[str]] = {
        "ALG102": ["InnerTxnBuilder.SetFields(", "InnerTxnBuilder.Begin()"],
        "ALG103": ["App.globalPut(", "App.localPut("],
        "ALG105": ["TxnField.receiver", "TxnField.asset_receiver", "TxnField.assetreceiver"],
        "ALG106": ["Txn.application_args[", "Btoi(Txn.application_args["],
    }

    targets = patterns.get(rule_id, [])
    if not targets:
        return None

    for idx, line in enumerate(lines, start=1):
        if any(token in line for token in targets):
            return idx

    return None


def scan_path(path: Path) -> ScanResult:
    started = time.perf_counter()
    result = ScanResult(target=path)
    targets = discover_targets(path)
    pyteal_precheck_ids = ["ALG401", "ALG402", "ALG403", "ALG404", "ALG405", "ALG406", "ALG407"]
    has_pyteal_inputs = any(p.suffix.lower() in {".py", ".pyteal"} for p in targets)
    program_summaries: list[ContractSummary] = []
    parsed_programs: list[tuple[Path, TealProgram, ContractSummary]] = []
    compiled_outputs: list[dict[str, str | int]] = []
    error_diagnostics: list[dict[str, str]] = []

    if not targets:
        msg = "No supported files found (.teal/.pyteal/.py)."
        result.errors.append(msg)
        diag = diagnose_scan_error(msg)
        error_diagnostics.append(
            {
                "target": str(path),
                "type": diag.error_type,
                "cause": diag.likely_cause,
                "fix": diag.fix,
            }
        )
        result.metadata["error_diagnostics"] = error_diagnostics
        result.metadata["duration_ms"] = int((time.perf_counter() - started) * 1000)
        result.metadata["files_discovered"] = 0
        detector_ids = [
            *[rule.rule_id for rule in DEFAULT_TEAL_RULES],
            *[rule.rule_id for rule in DEFI_RULES],
            *[rule.rule_id for rule in SEMANTIC_RULES],
        ]
        result.metadata["detectors_run"] = detector_ids
        result.metadata["detectors"] = build_detector_list(detector_ids)
        return result

    build_dir = _compiled_dir(path)

    for file_path in targets:
        try:
            teal_sources: list[tuple[Path, Path | None]] = []

            suffix = file_path.suffix.lower()
            if suffix == ".teal":
                teal_sources.append((file_path, None))
            elif suffix in {".py", ".pyteal"}:
                if not looks_like_pyteal_source(file_path):
                    continue

                result.add_findings(run_pyteal_prechecks(file_path))

                artifacts = compile_pyteal_file(file_path)
                for artifact in artifacts:
                    compiled_path = _persist_compiled_teal(
                        source=artifact.source_path,
                        name=artifact.name,
                        teal=artifact.teal,
                        out_dir=build_dir,
                    )
                    teal_sources.append((compiled_path, artifact.source_path))
                    compiled_outputs.append(
                        {
                            "source": str(artifact.source_path),
                            "compiled": str(compiled_path),
                            "name": artifact.name,
                            "mode": artifact.mode,
                            "version": artifact.version,
                        }
                    )
            else:
                continue

            for teal_path, origin in teal_sources:
                program = parse_teal_file(teal_path)
                _ = build_cfg(program)
                summary = summarize_program(program)
                program_summaries.append(summary)
                parsed_programs.append((origin or teal_path, program, summary))

            result.analyzed_files.append(file_path)
        except Exception as exc:  # noqa: BLE001
            err_msg = f"{file_path}: {exc}"
            result.errors.append(err_msg)
            diag = diagnose_scan_error(err_msg)
            error_diagnostics.append(
                {
                    "target": str(file_path),
                    "type": diag.error_type,
                    "cause": diag.likely_cause,
                    "fix": diag.fix,
                }
            )

    workflow_graph = build_workflow_graph(program_summaries)
    result.metadata["workflow"] = workflow_graph
    if compiled_outputs:
        result.metadata["compiled_pyteal"] = compiled_outputs

    rules = [*DEFAULT_TEAL_RULES, *DEFI_RULES, *SEMANTIC_RULES]
    detector_ids = [rule.rule_id for rule in rules]
    if has_pyteal_inputs:
        detector_ids.extend(pyteal_precheck_ids)
    result.metadata["detectors_run"] = detector_ids
    result.metadata["detectors"] = build_detector_list(detector_ids)
    for origin, program, summary in parsed_programs:
        context = RuleContext(
            program=program,
            contract_summary=summary,
            project_metadata=result.metadata,
        )
        for rule in rules:
            findings = rule.check(context)
            if origin != program.path:
                for finding in findings:
                    finding.evidence.setdefault("compiled_teal", str(program.path))
                    finding.evidence.setdefault("source_file", str(origin))
                    source_hint = _line_hint_in_source(origin, finding.rule_id)
                    if source_hint is not None:
                        finding.evidence.setdefault("source_line_hint", str(source_hint))
            result.add_findings(findings)

    result.metadata["duration_ms"] = int((time.perf_counter() - started) * 1000)
    result.metadata["files_discovered"] = len(targets)
    if error_diagnostics:
        result.metadata["error_diagnostics"] = error_diagnostics
    attack_paths = _derive_attack_paths(result)
    if attack_paths:
        result.metadata["attack_paths"] = attack_paths

    return result
