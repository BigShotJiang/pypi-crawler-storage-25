from __future__ import annotations

import json
import os
from collections import Counter
from pathlib import Path

import typer
from rich import box
from rich.console import Console
from rich.table import Table

from algosec.baseline import filter_new_findings
from algosec.agent.gemini import can_use_gemini
from algosec.connectors.algod_client import AlgodClient
from algosec.connectors.indexer_client import IndexerClient
from algosec.engine import scan_path
from algosec.models import ScanResult
from algosec.monetization.entitlement_service import resolve_subscription_entitlement, resolve_wallet_entitlement
from algosec.reporters.console import render_console
from algosec.reporters.html_reporter import write_html
from algosec.reporters.json_reporter import write_json
from algosec.reporters.markdown_reporter import write_markdown
from algosec.reporters.sarif_reporter import write_sarif
from algosec.reporters.test_reporter import render_test_console, write_test_json, write_test_markdown
from algosec.remediation.auto_fix import fix_pyteal_contract
from algosec.scoring import compute_security_score
from algosec.scanners.account_scanner import AccountScanner
from algosec.scanners.asa_scanner import AsaScanner
from algosec.scanners.deployed_app_scanner import DeployedAppScanner
from algosec.scanners.transaction_scanner import TransactionScanner
from algosec.services.agentic_service import AgenticRequest, run_agentic_workflow
from algosec.testing.pyteal_test_runner import run_pyteal_test_lab
from algosec.ui.home import render_home

app = typer.Typer(
    help=(
        "🛡️  A+ SEC — Algorand smart contract security workbench\n\n"
        "Fast semantic analysis, visual security scoring, AI-assisted review, and remediation."
    ),
    epilog=(
        "Quick Start:\n"
        "  1) algosec analyze <path>\n"
        "  2) algosec stats <path> --graph\n"
        "  3) algosec diff <old> <new>\n"
        "  4) algosec fix-contract <vulnerable.py> --verify\n"
        "  5) algosec ai-run \"Assess risk\" --scan-target <path> --action transfer"
    ),
    rich_markup_mode="rich",
    invoke_without_command=True,
)


@app.callback()
def main(ctx: typer.Context) -> None:
    if ctx.invoked_subcommand is None:
        render_home()
        raise typer.Exit(code=0)


def _emit_result(
    result: ScanResult,
    *,
    fmt: str,
    output: Path | None,
    baseline: Path | None,
    only_new: bool,
) -> None:
    normalized = fmt.lower().strip()

    if only_new:
        if baseline is None:
            raise typer.BadParameter("--baseline is required when using --only-new")
        result = filter_new_findings(result, baseline)

    result.metadata["score"] = compute_security_score(result)
    compact = bool(os.getenv("CI")) or os.getenv("APLUSSEC_COMPACT", "").lower() in {"1", "true", "yes"}

    if normalized == "console":
        render_console(result, compact=compact)
        raise typer.Exit(code=1 if (result.findings or result.errors) else 0)

    if output is None:
        raise typer.BadParameter("--output is required for json/sarif/markdown/html formats")

    if normalized == "json":
        write_json(result, output)
    elif normalized == "sarif":
        write_sarif(result, output)
    elif normalized in {"md", "markdown"}:
        write_markdown(result, output)
    elif normalized == "html":
        write_html(result, output)
    else:
        raise typer.BadParameter("Unsupported format. Use: console|json|sarif|markdown|html")

    raise typer.Exit(code=1 if (result.findings or result.errors) else 0)


def _as_error_result(target: str, error: Exception) -> ScanResult:
    result = ScanResult(target=Path(target))
    result.errors.append(str(error))
    return result


@app.command()
def scan(
    target: Path = typer.Argument(..., help="File or folder to scan"),
    fmt: str = typer.Option("console", "--format", "-f", help="console|json|sarif|markdown|html"),
    output: Path | None = typer.Option(None, "--output", "-o", help="Output file for non-console formats"),
    baseline: Path | None = typer.Option(None, "--baseline", help="Baseline JSON report path"),
    only_new: bool = typer.Option(False, "--only-new", help="Show only findings not present in baseline"),
) -> None:
    """Scan contracts from a file or folder."""
    result = scan_path(target)
    _emit_result(result, fmt=fmt, output=output, baseline=baseline, only_new=only_new)


@app.command("alg_scan")
def alg_scan(
    target: Path = typer.Argument(..., help="File or folder to scan"),
    fmt: str = typer.Option("console", "--format", "-f", help="console|json|sarif|markdown|html"),
    output: Path | None = typer.Option(None, "--output", "-o", help="Output file for non-console formats"),
    baseline: Path | None = typer.Option(None, "--baseline", help="Baseline JSON report path"),
    only_new: bool = typer.Option(False, "--only-new", help="Show only findings not present in baseline"),
) -> None:
    """Alias: scan contracts from a file or folder."""
    scan(target=target, fmt=fmt, output=output, baseline=baseline, only_new=only_new)


@app.command("analyze")
def analyze(
    target: Path = typer.Argument(..., help="File or folder to analyze"),
    fmt: str = typer.Option("console", "--format", "-f", help="console|json|sarif|markdown|html"),
    output: Path | None = typer.Option(None, "--output", "-o", help="Output file for non-console formats"),
    baseline: Path | None = typer.Option(None, "--baseline", help="Baseline JSON report path"),
    only_new: bool = typer.Option(False, "--only-new", help="Show only findings not present in baseline"),
    presentation: bool = typer.Option(False, "--presentation", help="Single-screen demo mode (concise visual dashboard)"),
    hide_hotspots: bool = typer.Option(False, "--hide-hotspots", help="Hide hotspot files graph in console mode"),
) -> None:
    """Analyze contract security posture (friendly alias for scan)."""
    prev_presentation = os.environ.get("APLUSSEC_PRESENTATION_MODE")
    prev_hotspots = os.environ.get("APLUSSEC_HIDE_HOTSPOTS")
    try:
        if presentation:
            os.environ["APLUSSEC_PRESENTATION_MODE"] = "1"
        if hide_hotspots or presentation:
            os.environ["APLUSSEC_HIDE_HOTSPOTS"] = "1"
        scan(target=target, fmt=fmt, output=output, baseline=baseline, only_new=only_new)
    finally:
        if prev_presentation is None:
            os.environ.pop("APLUSSEC_PRESENTATION_MODE", None)
        else:
            os.environ["APLUSSEC_PRESENTATION_MODE"] = prev_presentation

        if prev_hotspots is None:
            os.environ.pop("APLUSSEC_HIDE_HOTSPOTS", None)
        else:
            os.environ["APLUSSEC_HIDE_HOTSPOTS"] = prev_hotspots


@app.command("stats")
def stats(
    target: Path = typer.Argument(..., help="File or folder to summarize"),
    graph: bool = typer.Option(True, "--graph/--no-graph", help="Show visual bars"),
) -> None:
    """Show concise security stats with visual summary."""
    result = scan_path(target)
    result.metadata["score"] = compute_security_score(result)
    score = result.metadata.get("score", {}) if isinstance(result.metadata.get("score"), dict) else {}

    sev = Counter(item.severity.value.lower() for item in result.findings)
    total = max(1, len(result.findings))

    def _bar(count: int, width: int = 24) -> str:
        filled = int((count / total) * width) if total else 0
        return "█" * filled + "░" * (width - filled)

    console = Console()
    table = Table(title="Security stats", box=box.SIMPLE_HEAVY, header_style="bold cyan")
    table.add_column("Metric", style="bold white")
    table.add_column("Value", style="white")
    table.add_row("Target", str(target))
    table.add_row("Files analyzed", str(len(result.analyzed_files)))
    table.add_row("Findings", str(len(result.findings)))
    table.add_row("Errors", str(len(result.errors)))
    table.add_row("Security score", f"{score.get('security_score', '-')}/100")
    table.add_row("Risk score", f"{score.get('risk_score', '-')}/100")
    table.add_row("Grade", str(score.get("grade", "-")))
    table.add_row("Deploy verdict", str(score.get("deploy_verdict", "-")))
    console.print(table)

    if graph:
        graph_table = Table(title="Severity graph", box=box.SIMPLE, header_style="bold cyan")
        graph_table.add_column("Severity", style="bold white")
        graph_table.add_column("Count", justify="right")
        graph_table.add_column("Graph")
        for level in ["critical", "high", "medium", "low", "info"]:
            count = sev.get(level, 0)
            if count == 0 and len(result.findings) > 0:
                continue
            graph_table.add_row(level.upper(), str(count), _bar(count))
        console.print(graph_table)

    raise typer.Exit(code=1 if (result.findings or result.errors) else 0)


@app.command("diff")
def diff_contracts(
    baseline_target: Path = typer.Argument(..., help="Baseline contract/file/folder"),
    current_target: Path = typer.Argument(..., help="Current contract/file/folder"),
) -> None:
    """Compare two contract security scans side-by-side."""
    base = scan_path(baseline_target)
    curr = scan_path(current_target)
    base.metadata["score"] = compute_security_score(base)
    curr.metadata["score"] = compute_security_score(curr)

    base_score = base.metadata.get("score", {}) if isinstance(base.metadata.get("score"), dict) else {}
    curr_score = curr.metadata.get("score", {}) if isinstance(curr.metadata.get("score"), dict) else {}

    base_sev = Counter(item.severity.value.lower() for item in base.findings)
    curr_sev = Counter(item.severity.value.lower() for item in curr.findings)

    console = Console()
    table = Table(title="Security diff", box=box.SIMPLE_HEAVY, header_style="bold cyan")
    table.add_column("Metric", style="bold white")
    table.add_column("Baseline", justify="right")
    table.add_column("Current", justify="right")
    table.add_column("Δ", justify="right")

    def _delta(a: int, b: int) -> str:
        d = b - a
        return f"{d:+d}"

    base_sec = int(base_score.get("security_score", 0)) if isinstance(base_score, dict) else 0
    curr_sec = int(curr_score.get("security_score", 0)) if isinstance(curr_score, dict) else 0

    table.add_row("Findings", str(len(base.findings)), str(len(curr.findings)), _delta(len(base.findings), len(curr.findings)))
    table.add_row("Errors", str(len(base.errors)), str(len(curr.errors)), _delta(len(base.errors), len(curr.errors)))
    table.add_row("Security score", str(base_sec), str(curr_sec), _delta(base_sec, curr_sec))
    for level in ["critical", "high", "medium", "low", "info"]:
        table.add_row(level.upper(), str(base_sev.get(level, 0)), str(curr_sev.get(level, 0)), _delta(base_sev.get(level, 0), curr_sev.get(level, 0)))

    console.print(table)
    console.print(
        f"Baseline verdict={base_score.get('deploy_verdict', '-')}, Current verdict={curr_score.get('deploy_verdict', '-')}"
    )

    raise typer.Exit(code=1 if (curr.findings or curr.errors) else 0)

@app.command("scan-deployed-app")
def scan_deployed_app(
    app_id: int = typer.Argument(..., help="Algorand application ID"),
    algod_url: str = typer.Option("http://localhost:4001", "--algod-url", help="Algod URL"),
    algod_token: str = typer.Option("", "--algod-token", help="Algod API token"),
    fmt: str = typer.Option("console", "--format", "-f", help="console|json|sarif|markdown|html"),
    output: Path | None = typer.Option(None, "--output", "-o", help="Output file for non-console formats"),
    baseline: Path | None = typer.Option(None, "--baseline", help="Baseline JSON report path"),
    only_new: bool = typer.Option(False, "--only-new", help="Show only findings not present in baseline"),
) -> None:
    """Scan a deployed application by app id using algod."""
    try:
        client = AlgodClient(base_url=algod_url, token=algod_token)
        result = DeployedAppScanner(client).run(app_id)
    except Exception as exc:  # noqa: BLE001
        result = _as_error_result(f"app:{app_id}", exc)
    _emit_result(result, fmt=fmt, output=output, baseline=baseline, only_new=only_new)


@app.command("alg_scan_deployed_app")
def alg_scan_deployed_app(
    app_id: int = typer.Argument(..., help="Algorand application ID"),
    algod_url: str = typer.Option("http://localhost:4001", "--algod-url", help="Algod URL"),
    algod_token: str = typer.Option("", "--algod-token", help="Algod API token"),
    fmt: str = typer.Option("console", "--format", "-f", help="console|json|sarif|markdown|html"),
    output: Path | None = typer.Option(None, "--output", "-o", help="Output file for non-console formats"),
    baseline: Path | None = typer.Option(None, "--baseline", help="Baseline JSON report path"),
    only_new: bool = typer.Option(False, "--only-new", help="Show only findings not present in baseline"),
) -> None:
    """Alias: scan a deployed application by app id using algod."""
    scan_deployed_app(
        app_id=app_id,
        algod_url=algod_url,
        algod_token=algod_token,
        fmt=fmt,
        output=output,
        baseline=baseline,
        only_new=only_new,
    )


@app.command("scan-account")
def scan_account(
    address: str = typer.Argument(..., help="Algorand account address"),
    indexer_url: str = typer.Option("http://localhost:8980", "--indexer-url", help="Indexer URL"),
    indexer_token: str = typer.Option("", "--indexer-token", help="Indexer API token"),
    fmt: str = typer.Option("console", "--format", "-f", help="console|json|sarif|markdown|html"),
    output: Path | None = typer.Option(None, "--output", "-o", help="Output file for non-console formats"),
    baseline: Path | None = typer.Option(None, "--baseline", help="Baseline JSON report path"),
    only_new: bool = typer.Option(False, "--only-new", help="Show only findings not present in baseline"),
) -> None:
    """Scan an account for risk signals using indexer data."""
    try:
        client = IndexerClient(base_url=indexer_url, token=indexer_token)
        result = AccountScanner(client).run(address)
    except Exception as exc:  # noqa: BLE001
        result = _as_error_result(f"account:{address}", exc)
    _emit_result(result, fmt=fmt, output=output, baseline=baseline, only_new=only_new)


@app.command("alg_scan_account")
def alg_scan_account(
    address: str = typer.Argument(..., help="Algorand account address"),
    indexer_url: str = typer.Option("http://localhost:8980", "--indexer-url", help="Indexer URL"),
    indexer_token: str = typer.Option("", "--indexer-token", help="Indexer API token"),
    fmt: str = typer.Option("console", "--format", "-f", help="console|json|sarif|markdown|html"),
    output: Path | None = typer.Option(None, "--output", "-o", help="Output file for non-console formats"),
    baseline: Path | None = typer.Option(None, "--baseline", help="Baseline JSON report path"),
    only_new: bool = typer.Option(False, "--only-new", help="Show only findings not present in baseline"),
) -> None:
    """Alias: scan an account for risk signals using indexer data."""
    scan_account(
        address=address,
        indexer_url=indexer_url,
        indexer_token=indexer_token,
        fmt=fmt,
        output=output,
        baseline=baseline,
        only_new=only_new,
    )


@app.command("scan-asset")
def scan_asset(
    asset_id: int = typer.Argument(..., help="Algorand asset ID"),
    indexer_url: str = typer.Option("http://localhost:8980", "--indexer-url", help="Indexer URL"),
    indexer_token: str = typer.Option("", "--indexer-token", help="Indexer API token"),
    fmt: str = typer.Option("console", "--format", "-f", help="console|json|sarif|markdown|html"),
    output: Path | None = typer.Option(None, "--output", "-o", help="Output file for non-console formats"),
    baseline: Path | None = typer.Option(None, "--baseline", help="Baseline JSON report path"),
    only_new: bool = typer.Option(False, "--only-new", help="Show only findings not present in baseline"),
) -> None:
    """Scan ASA configuration and metadata risk signals."""
    try:
        client = IndexerClient(base_url=indexer_url, token=indexer_token)
        result = AsaScanner(client).run(asset_id)
    except Exception as exc:  # noqa: BLE001
        result = _as_error_result(f"asset:{asset_id}", exc)
    _emit_result(result, fmt=fmt, output=output, baseline=baseline, only_new=only_new)


@app.command("alg_scan_asset")
def alg_scan_asset(
    asset_id: int = typer.Argument(..., help="Algorand asset ID"),
    indexer_url: str = typer.Option("http://localhost:8980", "--indexer-url", help="Indexer URL"),
    indexer_token: str = typer.Option("", "--indexer-token", help="Indexer API token"),
    fmt: str = typer.Option("console", "--format", "-f", help="console|json|sarif|markdown|html"),
    output: Path | None = typer.Option(None, "--output", "-o", help="Output file for non-console formats"),
    baseline: Path | None = typer.Option(None, "--baseline", help="Baseline JSON report path"),
    only_new: bool = typer.Option(False, "--only-new", help="Show only findings not present in baseline"),
) -> None:
    """Alias: scan ASA configuration and metadata risk signals."""
    scan_asset(
        asset_id=asset_id,
        indexer_url=indexer_url,
        indexer_token=indexer_token,
        fmt=fmt,
        output=output,
        baseline=baseline,
        only_new=only_new,
    )


@app.command("scan-transactions")
def scan_transactions(
    address: str | None = typer.Option(None, "--address", help="Filter by account address"),
    app_id: int | None = typer.Option(None, "--app-id", help="Filter by application id"),
    asset_id: int | None = typer.Option(None, "--asset-id", help="Filter by asset id"),
    limit: int = typer.Option(200, "--limit", help="Max transactions to analyze (1..1000)"),
    indexer_url: str = typer.Option("http://localhost:8980", "--indexer-url", help="Indexer URL"),
    indexer_token: str = typer.Option("", "--indexer-token", help="Indexer API token"),
    fmt: str = typer.Option("console", "--format", "-f", help="console|json|sarif|markdown|html"),
    output: Path | None = typer.Option(None, "--output", "-o", help="Output file for non-console formats"),
    baseline: Path | None = typer.Option(None, "--baseline", help="Baseline JSON report path"),
    only_new: bool = typer.Option(False, "--only-new", help="Show only findings not present in baseline"),
) -> None:
    """Scan transactions for high-risk patterns and anomalies."""
    if not any((address, app_id, asset_id)):
        raise typer.BadParameter("Provide at least one filter: --address or --app-id or --asset-id")

    try:
        client = IndexerClient(base_url=indexer_url, token=indexer_token)
        result = TransactionScanner(client).run(
            address=address,
            app_id=app_id,
            asset_id=asset_id,
            limit=limit,
        )
    except Exception as exc:  # noqa: BLE001
        result = _as_error_result(f"txns:{address or app_id or asset_id or 'unknown'}", exc)
    _emit_result(result, fmt=fmt, output=output, baseline=baseline, only_new=only_new)


@app.command("alg_scan_transactions")
def alg_scan_transactions(
    address: str | None = typer.Option(None, "--address", help="Filter by account address"),
    app_id: int | None = typer.Option(None, "--app-id", help="Filter by application id"),
    asset_id: int | None = typer.Option(None, "--asset-id", help="Filter by asset id"),
    limit: int = typer.Option(200, "--limit", help="Max transactions to analyze (1..1000)"),
    indexer_url: str = typer.Option("http://localhost:8980", "--indexer-url", help="Indexer URL"),
    indexer_token: str = typer.Option("", "--indexer-token", help="Indexer API token"),
    fmt: str = typer.Option("console", "--format", "-f", help="console|json|sarif|markdown|html"),
    output: Path | None = typer.Option(None, "--output", "-o", help="Output file for non-console formats"),
    baseline: Path | None = typer.Option(None, "--baseline", help="Baseline JSON report path"),
    only_new: bool = typer.Option(False, "--only-new", help="Show only findings not present in baseline"),
) -> None:
    """Alias: scan transactions for high-risk patterns and anomalies."""
    scan_transactions(
        address=address,
        app_id=app_id,
        asset_id=asset_id,
        limit=limit,
        indexer_url=indexer_url,
        indexer_token=indexer_token,
        fmt=fmt,
        output=output,
        baseline=baseline,
        only_new=only_new,
    )


@app.command("test-pyteal")
def test_pyteal(
    target: Path = typer.Argument(..., help="PyTeal file or folder to test"),
    fmt: str = typer.Option("console", "--format", "-f", help="console|json|markdown"),
    output: Path | None = typer.Option(None, "--output", "-o", help="Output path for json/markdown"),
    fuzz_rounds: int = typer.Option(3, "--fuzz-rounds", min=1, max=10, help="Mutation fuzz rounds per contract"),
    max_mutations: int = typer.Option(4, "--max-mutations", min=1, max=10, help="Max mutation templates per contract"),
) -> None:
    """Run unit+oracle+mutation-fuzz tests for any PyTeal contract set."""
    report = run_pyteal_test_lab(target, fuzz_rounds=fuzz_rounds, max_mutations=max_mutations)
    normalized = fmt.lower().strip()

    if normalized == "console":
        render_test_console(report)
    elif normalized == "json":
        if output is None:
            raise typer.BadParameter("--output is required for json format")
        write_test_json(report, output)
    elif normalized in {"md", "markdown"}:
        if output is None:
            raise typer.BadParameter("--output is required for markdown format")
        write_test_markdown(report, output)
    else:
        raise typer.BadParameter("Unsupported format. Use: console|json|markdown")

    raise typer.Exit(code=1 if report.failed_cases > 0 or report.contracts_with_engine_errors > 0 else 0)


@app.command("alg_test_pyteal")
def alg_test_pyteal(
    target: Path = typer.Argument(..., help="PyTeal file or folder to test"),
    fmt: str = typer.Option("console", "--format", "-f", help="console|json|markdown"),
    output: Path | None = typer.Option(None, "--output", "-o", help="Output path for json/markdown"),
    fuzz_rounds: int = typer.Option(3, "--fuzz-rounds", min=1, max=10, help="Mutation fuzz rounds per contract"),
    max_mutations: int = typer.Option(4, "--max-mutations", min=1, max=10, help="Max mutation templates per contract"),
) -> None:
    """Alias: run unit+oracle+mutation-fuzz tests for any PyTeal contract set."""
    test_pyteal(
        target=target,
        fmt=fmt,
        output=output,
        fuzz_rounds=fuzz_rounds,
        max_mutations=max_mutations,
    )


def _emit_ai_result(*, result: dict, fmt: str, output: Path | None) -> None:
    normalized = fmt.strip().lower()

    if normalized == "console":
        decision = result.get("decision", {}) if isinstance(result.get("decision"), dict) else {}
        scan = result.get("scan", {}) if isinstance(result.get("scan"), dict) else {}
        simulation = result.get("simulation", {}) if isinstance(result.get("simulation"), dict) else {}

        typer.echo(f"session_id={result.get('session_id', '')}")
        typer.echo(f"objective={result.get('objective', '')}")
        typer.echo(f"decision={decision.get('decision', '')}")
        typer.echo(f"risk={decision.get('risk', '')}")
        typer.echo(f"score={decision.get('score', '')}")
        typer.echo(f"narrative_provider={decision.get('narrative_provider', 'deterministic')}")
        typer.echo(
            f"scan_findings={scan.get('findings_count', 0)} errors={scan.get('errors_count', 0)} "
            f"simulation_outcome={simulation.get('outcome', '')}"
        )
        typer.echo("---")
        typer.echo(result.get("artifacts", {}).get("explanation_text", ""))
        return

    if output is None:
        raise typer.BadParameter("--output is required for json/markdown format")

    output.parent.mkdir(parents=True, exist_ok=True)

    if normalized == "json":
        output.write_text(json.dumps(result, indent=2), encoding="utf-8")
        return

    if normalized in {"md", "markdown"}:
        markdown = result.get("artifacts", {}).get("explanation_markdown", "")
        output.write_text(str(markdown), encoding="utf-8")
        return

    raise typer.BadParameter("Unsupported format. Use: console|json|markdown")


@app.command("ai-status")
def ai_status(
    gemini_model: str | None = typer.Option(None, "--gemini-model", help="Optional Gemini model override"),
    gemini_api_key: str | None = typer.Option(None, "--gemini-api-key", help="Optional Gemini API key override for this process"),
) -> None:
    """Show AI provider readiness for Gemini-backed explanations."""
    if gemini_api_key:
        os.environ["ALGOSEC_GEMINI_API_KEY"] = gemini_api_key.strip()
    if gemini_model:
        os.environ["ALGOSEC_GEMINI_MODEL"] = gemini_model.strip()

    key_present = bool(
        os.getenv("ALGOSEC_GEMINI_API_KEY")
        or os.getenv("GEMINI_API_KEY")
        or os.getenv("GOOGLE_API_KEY")
    )
    model = os.getenv("ALGOSEC_GEMINI_MODEL", "gemini-flash-latest")
    ready = can_use_gemini()

    typer.echo(f"provider=gemini")
    typer.echo(f"ready={str(ready).lower()}")
    typer.echo(f"api_key_present={str(key_present).lower()}")
    typer.echo(f"model={model}")


@app.command("ai-run")
def ai_run(
    objective: str = typer.Argument(..., help="High-level objective for the AI security copilot"),
    scan_target: Path | None = typer.Option(None, "--scan-target", help="Contract file or folder to scan"),
    scan_source_code: str | None = typer.Option(None, "--scan-source-code", help="Inline source code to scan"),
    scan_source_suffix: str = typer.Option(".py", "--scan-source-suffix", help="Suffix used for inline source scanning"),
    profile: str = typer.Option("strict-defi", "--profile", help="strict-defi|balanced"),
    action: str = typer.Option("simulate", "--action", help="Intent action name"),
    sender: str | None = typer.Option(None, "--sender", help="Sender address"),
    receiver: str | None = typer.Option(None, "--receiver", help="Receiver address"),
    amount: int | None = typer.Option(None, "--amount", help="Amount for transfer actions"),
    app_arg: list[str] = typer.Option([], "--app-arg", help="Repeatable app arg"),
    group_size: int | None = typer.Option(None, "--group-size", help="Group transaction size"),
    payment_in_group: bool = typer.Option(False, "--payment-in-group", help="Whether a payment exists in group"),
    payment_sender: str | None = typer.Option(None, "--payment-sender", help="Payment sender address"),
    payment_receiver: str | None = typer.Option(None, "--payment-receiver", help="Payment receiver address"),
    state_kv: list[str] = typer.Option([], "--state", help="Repeatable state key=value"),
    session_id: str | None = typer.Option(None, "--session-id", help="Optional session id for continuity"),
    fmt: str = typer.Option("console", "--format", "-f", help="console|json|markdown"),
    output: Path | None = typer.Option(None, "--output", "-o", help="Output path for json/markdown"),
    gemini_model: str | None = typer.Option(None, "--gemini-model", help="Optional Gemini model override"),
    gemini_api_key: str | None = typer.Option(None, "--gemini-api-key", help="Optional Gemini API key override for this process"),
) -> None:
    """Run the agentic AI workflow (scan + simulate + policy + explanation)."""
    if scan_target is not None and scan_source_code is not None:
        raise typer.BadParameter("Provide either --scan-target or --scan-source-code, not both")
    if scan_target is None and scan_source_code is None:
        raise typer.BadParameter("--scan-target or --scan-source-code is required")

    if gemini_api_key:
        os.environ["ALGOSEC_GEMINI_API_KEY"] = gemini_api_key.strip()
    if gemini_model:
        os.environ["ALGOSEC_GEMINI_MODEL"] = gemini_model.strip()

    state: dict[str, int] = {}
    for item in state_kv:
        if "=" not in item:
            raise typer.BadParameter("Each --state value must be key=value")
        key, raw_value = item.split("=", 1)
        key = key.strip()
        if not key:
            raise typer.BadParameter("State key cannot be empty")
        try:
            state[key] = int(raw_value.strip())
        except ValueError as exc:
            raise typer.BadParameter(f"State value must be integer for key '{key}'") from exc

    result = run_agentic_workflow(
        AgenticRequest(
            objective=objective,
            session_id=session_id,
            profile=profile,
            scan_target=str(scan_target) if scan_target is not None else None,
            scan_source_code=scan_source_code,
            scan_source_suffix=scan_source_suffix,
            action=action,
            sender=sender,
            receiver=receiver,
            amount=amount,
            app_args=app_arg,
            group_size=group_size,
            payment_in_group=payment_in_group,
            payment_sender=payment_sender,
            payment_receiver=payment_receiver,
            state=state,
        )
    )
    _emit_ai_result(result=result, fmt=fmt, output=output)


@app.command("alg_ai_run")
def alg_ai_run(
    objective: str = typer.Argument(..., help="High-level objective for the AI security copilot"),
    scan_target: Path | None = typer.Option(None, "--scan-target", help="Contract file or folder to scan"),
    scan_source_code: str | None = typer.Option(None, "--scan-source-code", help="Inline source code to scan"),
    scan_source_suffix: str = typer.Option(".py", "--scan-source-suffix", help="Suffix used for inline source scanning"),
    profile: str = typer.Option("strict-defi", "--profile", help="strict-defi|balanced"),
    action: str = typer.Option("simulate", "--action", help="Intent action name"),
    sender: str | None = typer.Option(None, "--sender", help="Sender address"),
    receiver: str | None = typer.Option(None, "--receiver", help="Receiver address"),
    amount: int | None = typer.Option(None, "--amount", help="Amount for transfer actions"),
    app_arg: list[str] = typer.Option([], "--app-arg", help="Repeatable app arg"),
    group_size: int | None = typer.Option(None, "--group-size", help="Group transaction size"),
    payment_in_group: bool = typer.Option(False, "--payment-in-group", help="Whether a payment exists in group"),
    payment_sender: str | None = typer.Option(None, "--payment-sender", help="Payment sender address"),
    payment_receiver: str | None = typer.Option(None, "--payment-receiver", help="Payment receiver address"),
    state_kv: list[str] = typer.Option([], "--state", help="Repeatable state key=value"),
    session_id: str | None = typer.Option(None, "--session-id", help="Optional session id for continuity"),
    fmt: str = typer.Option("console", "--format", "-f", help="console|json|markdown"),
    output: Path | None = typer.Option(None, "--output", "-o", help="Output path for json/markdown"),
    gemini_model: str | None = typer.Option(None, "--gemini-model", help="Optional Gemini model override"),
    gemini_api_key: str | None = typer.Option(None, "--gemini-api-key", help="Optional Gemini API key override for this process"),
) -> None:
    """Alias: run the agentic AI workflow (scan + simulate + policy + explanation)."""
    ai_run(
        objective=objective,
        scan_target=scan_target,
        scan_source_code=scan_source_code,
        scan_source_suffix=scan_source_suffix,
        profile=profile,
        action=action,
        sender=sender,
        receiver=receiver,
        amount=amount,
        app_arg=app_arg,
        group_size=group_size,
        payment_in_group=payment_in_group,
        payment_sender=payment_sender,
        payment_receiver=payment_receiver,
        state_kv=state_kv,
        session_id=session_id,
        fmt=fmt,
        output=output,
        gemini_model=gemini_model,
        gemini_api_key=gemini_api_key,
    )


@app.command("fix-contract")
def fix_contract(
    source: Path = typer.Argument(..., help="Vulnerable PyTeal contract file (.py)"),
    output: Path | None = typer.Option(None, "--output", "-o", help="Output file path (default: <source>.fixed.py)"),
    in_place: bool = typer.Option(False, "--in-place", help="Overwrite source file"),
    verify: bool = typer.Option(True, "--verify/--no-verify", help="Re-scan fixed file and print summary"),
) -> None:
    """Apply auto-fixes to common PyTeal vulnerabilities and write a hardened contract."""
    if not source.exists() or not source.is_file():
        raise typer.BadParameter("source must be an existing file")

    try:
        result = fix_pyteal_contract(source=source, output=output, in_place=in_place)
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc

    typer.echo(f"source={result.source}")
    typer.echo(f"output={result.output}")
    typer.echo(f"changed={str(result.changed).lower()}")

    if result.changes:
        typer.echo("applied_changes:")
        for idx, change in enumerate(result.changes, start=1):
            typer.echo(f"  {idx}. {change}")
    else:
        typer.echo("applied_changes:\n  none")

    if verify:
        scan = scan_path(result.output)
        scan.metadata["score"] = compute_security_score(scan)
        score = scan.metadata.get("score", {}) if isinstance(scan.metadata.get("score"), dict) else {}
        typer.echo(
            f"post_fix_findings={len(scan.findings)} errors={len(scan.errors)} "
            f"security_score={score.get('score', '-')} deploy_verdict={score.get('deploy_verdict', '-')}"
        )


@app.command("alg_fix_contract")
def alg_fix_contract(
    source: Path = typer.Argument(..., help="Vulnerable PyTeal contract file (.py)"),
    output: Path | None = typer.Option(None, "--output", "-o", help="Output file path (default: <source>.fixed.py)"),
    in_place: bool = typer.Option(False, "--in-place", help="Overwrite source file"),
    verify: bool = typer.Option(True, "--verify/--no-verify", help="Re-scan fixed file and print summary"),
) -> None:
    """Alias: auto-fix common PyTeal vulnerabilities."""
    fix_contract(source=source, output=output, in_place=in_place, verify=verify)


@app.command("premium-status")
def premium_status(
    address: str = typer.Argument(..., help="Algorand wallet address"),
    mode: str = typer.Option("asa", "--mode", help="asa|subscription"),
    indexer_url: str = typer.Option("http://localhost:8980", "--indexer-url", help="Indexer URL"),
    indexer_token: str = typer.Option("", "--indexer-token", help="Indexer API token"),
    asset_id: int | None = typer.Option(None, "--asset-id", help="Entitlement ASA asset ID"),
    min_balance: int = typer.Option(100, "--min-balance", help="Minimum ASA amount required"),
    algod_url: str = typer.Option("https://testnet-api.algonode.cloud", "--algod-url", help="Algod URL for on-chain checks"),
    algod_token: str = typer.Option("", "--algod-token", help="Algod API token"),
    subscription_app_id: int | None = typer.Option(None, "--subscription-app-id", help="Subscription app id"),
    required_tier: str = typer.Option("premium", "--required-tier", help="premium|enterprise"),
) -> None:
    """Check premium entitlement status from on-chain token balance."""
    normalized = mode.strip().lower()
    if normalized == "subscription":
        if subscription_app_id is None:
            raise typer.BadParameter("--subscription-app-id is required when --mode subscription")
        snapshot = resolve_subscription_entitlement(
            address=address,
            algod_url=algod_url,
            algod_token=algod_token,
            subscription_app_id=subscription_app_id,
            required_tier=required_tier,
        )
    else:
        if asset_id is None:
            raise typer.BadParameter("--asset-id is required when --mode asa")
        snapshot = resolve_wallet_entitlement(
            address=address,
            indexer_url=indexer_url,
            indexer_token=indexer_token,
            entitlement_asset_id=asset_id,
            entitlement_min_balance=min_balance,
        )

    tier = snapshot.tier.upper()
    status = "ENTITLED" if snapshot.entitled else "NOT_ENTITLED"
    typer.echo(
        (
            f"wallet={snapshot.wallet}\n"
            f"source={snapshot.source}\n"
            f"tier={tier}\n"
            f"status={status}\n"
            f"asset_id={snapshot.required_asset_id}\n"
            f"subscription_app_id={snapshot.subscription_app_id}\n"
            f"current_balance={snapshot.current_balance}\n"
            f"required_min_balance={snapshot.required_min_balance}\n"
            f"active={snapshot.active}\n"
            f"expires_at={snapshot.expires_at}"
        )
    )


@app.command("deploy-token-registry-testnet")
def deploy_token_registry_testnet(
    asa_id: int = typer.Option(..., "--asa-id", help="Entitlement ASA asset id"),
    min_balance: int = typer.Option(100, "--min-balance", help="Minimum ASA amount for premium"),
    algod_address: str = typer.Option("https://testnet-api.algonode.cloud", "--algod-address", help="Testnet algod address"),
    algod_token: str = typer.Option("", "--algod-token", help="Algod API token (empty for algonode)"),
    mnemonic_phrase: str | None = typer.Option(None, "--mnemonic", help="Creator mnemonic phrase"),
    execute: bool = typer.Option(False, "--execute", help="Actually broadcast create-app tx on testnet"),
) -> None:
    """Deploy token entitlement registry contract to Algorand testnet."""
    from algosec.deploy.testnet_token_registry import deploy_token_registry_testnet as deploy_service

    if "testnet" not in algod_address.lower():
        raise typer.BadParameter("For safety, this command only supports testnet endpoints")

    phrase = mnemonic_phrase or os.getenv("ALGOSEC_TESTNET_MNEMONIC")
    if not execute:
        typer.echo(
            "Dry run only. Pass --execute with --mnemonic (or ALGOSEC_TESTNET_MNEMONIC) to deploy on testnet."
        )
        typer.echo(
            f"plan: asa_id={asa_id}, min_balance={min_balance}, algod_address={algod_address}"
        )
        raise typer.Exit(code=0)

    if not phrase:
        raise typer.BadParameter("Mnemonic required. Provide --mnemonic or set ALGOSEC_TESTNET_MNEMONIC")

    result = deploy_service(
        algod_address=algod_address,
        algod_token=algod_token,
        creator_mnemonic=phrase,
        entitlement_asa_id=asa_id,
        min_balance=min_balance,
    )
    typer.echo(
        (
            f"deployed=true\n"
            f"network=testnet\n"
            f"app_id={result.app_id}\n"
            f"tx_id={result.tx_id}\n"
            f"creator={result.creator}\n"
            f"algod_address={result.algod_address}"
        )
    )


@app.command("deploy-subscription-testnet")
def deploy_subscription_testnet(
    price_microalgos: int = typer.Option(..., "--price", help="Plan price in microAlgos"),
    duration_seconds: int = typer.Option(..., "--duration", help="Plan duration in seconds"),
    grace_seconds: int = typer.Option(3600, "--grace", help="Grace period in seconds"),
    algod_address: str = typer.Option("https://testnet-api.algonode.cloud", "--algod-address", help="Testnet algod address"),
    algod_token: str = typer.Option("", "--algod-token", help="Algod API token (empty for algonode)"),
    mnemonic_phrase: str | None = typer.Option(None, "--mnemonic", help="Creator mnemonic phrase"),
    execute: bool = typer.Option(False, "--execute", help="Actually broadcast create-app tx on testnet"),
) -> None:
    """Deploy subscription entitlement app to Algorand testnet."""
    from algosec.deploy.testnet_subscription import deploy_subscription_testnet as deploy_service

    if "testnet" not in algod_address.lower():
        raise typer.BadParameter("For safety, this command only supports testnet endpoints")

    phrase = mnemonic_phrase or os.getenv("ALGOSEC_TESTNET_MNEMONIC")
    if not execute:
        typer.echo("Dry run only. Pass --execute with --mnemonic (or ALGOSEC_TESTNET_MNEMONIC) to deploy on testnet.")
        typer.echo(
            f"plan: price={price_microalgos}, duration={duration_seconds}, grace={grace_seconds}, algod_address={algod_address}"
        )
        raise typer.Exit(code=0)

    if not phrase:
        raise typer.BadParameter("Mnemonic required. Provide --mnemonic or set ALGOSEC_TESTNET_MNEMONIC")

    result = deploy_service(
        algod_address=algod_address,
        algod_token=algod_token,
        creator_mnemonic=phrase,
        price_microalgos=price_microalgos,
        duration_seconds=duration_seconds,
        grace_seconds=grace_seconds,
    )
    typer.echo(
        (
            f"deployed=true\n"
            f"network=testnet\n"
            f"app_id={result.app_id}\n"
            f"tx_id={result.tx_id}\n"
            f"creator={result.creator}\n"
            f"algod_address={result.algod_address}"
        )
    )


@app.command("serve")
def serve(
    host: str | None = typer.Option(None, "--host", help="Host interface"),
    port: int | None = typer.Option(None, "--port", help="Port to bind"),
    reload: bool = typer.Option(False, "--reload", help="Enable autoreload (dev only)"),
) -> None:
    """Run the Agentic Smart Contract Firewall API server."""
    try:
        import uvicorn
        from algosec.api.config import load_api_settings
    except Exception as exc:  # noqa: BLE001
        raise typer.BadParameter("uvicorn is required. Install dependencies and retry.") from exc

    settings = load_api_settings()
    bind_host = host or settings.host
    bind_port = port or settings.port

    uvicorn.run("algosec.api.app:app", host=bind_host, port=bind_port, reload=reload)


if __name__ == "__main__":
    app()
