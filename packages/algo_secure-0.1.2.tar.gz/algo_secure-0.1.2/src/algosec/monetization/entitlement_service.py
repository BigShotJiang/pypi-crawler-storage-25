from __future__ import annotations

import base64
import time
from dataclasses import dataclass

from algosec.connectors.algod_client import AlgodClient
from algosec.connectors.indexer_client import IndexerClient


@dataclass(slots=True)
class EntitlementSnapshot:
    wallet: str
    tier: str
    entitled: bool
    required_asset_id: int | None
    required_min_balance: int
    current_balance: int
    source: str = "asa-indexer"
    subscription_app_id: int | None = None
    expires_at: int | None = None
    active: bool | None = None


def _decode_state(items: list[dict] | None) -> dict[str, object]:
    decoded: dict[str, object] = {}
    for item in items or []:
        if not isinstance(item, dict):
            continue
        key_raw = item.get("key")
        val = item.get("value")
        if not isinstance(key_raw, str) or not isinstance(val, dict):
            continue
        try:
            key = base64.b64decode(key_raw).decode("utf-8")
        except Exception:  # noqa: BLE001
            continue
        vtype = int(val.get("type", 0) or 0)
        if vtype == 2:
            decoded[key] = int(val.get("uint", 0) or 0)
        elif vtype == 1:
            bytes_raw = val.get("bytes", "")
            if isinstance(bytes_raw, str):
                try:
                    decoded[key] = base64.b64decode(bytes_raw).decode("utf-8", errors="ignore")
                except Exception:  # noqa: BLE001
                    decoded[key] = bytes_raw
            else:
                decoded[key] = ""
    return decoded


def resolve_wallet_entitlement(
    *,
    address: str,
    indexer_url: str,
    indexer_token: str,
    entitlement_asset_id: int | None,
    entitlement_min_balance: int,
) -> EntitlementSnapshot:
    if entitlement_asset_id is None:
        return EntitlementSnapshot(
            wallet=address,
            tier="free",
            entitled=False,
            required_asset_id=None,
            required_min_balance=entitlement_min_balance,
            current_balance=0,
        )

    client = IndexerClient(base_url=indexer_url, token=indexer_token)
    info = client.account_info(address)
    account = info.get("account", {}) if isinstance(info, dict) else {}
    assets = account.get("assets", []) if isinstance(account, dict) else []

    balance = 0
    for asset in assets:
        if not isinstance(asset, dict):
            continue
        if int(asset.get("asset-id", -1)) == int(entitlement_asset_id):
            balance = int(asset.get("amount", 0) or 0)
            break

    entitled = balance >= int(entitlement_min_balance)
    return EntitlementSnapshot(
        wallet=address,
        tier="premium" if entitled else "free",
        entitled=entitled,
        required_asset_id=entitlement_asset_id,
        required_min_balance=entitlement_min_balance,
        current_balance=balance,
    )


def resolve_subscription_entitlement(
    *,
    address: str,
    algod_url: str,
    algod_token: str,
    subscription_app_id: int,
    required_tier: str = "premium",
) -> EntitlementSnapshot:
    client = AlgodClient(base_url=algod_url, token=algod_token)

    app_info = client.application_info(subscription_app_id)
    app_params = app_info.get("params", {}) if isinstance(app_info, dict) else {}
    global_state = _decode_state(app_params.get("global-state") if isinstance(app_params, dict) else [])

    local = client.account_application_info(address, subscription_app_id)
    local_state_obj = local.get("app-local-state", {}) if isinstance(local, dict) else {}
    local_state = _decode_state(local_state_obj.get("key-value") if isinstance(local_state_obj, dict) else [])

    tier_num = int(local_state.get("tier", 0) or 0)
    exp = int(local_state.get("exp", 0) or 0)
    active = int(local_state.get("active", 0) or 0) == 1

    required_tier_num = 2 if required_tier.lower() == "enterprise" else 1
    paused = int(global_state.get("paused", 0) or 0) == 1
    grace = int(global_state.get("grace", 0) or 0)
    now_ts = int(time.time())

    entitled = (not paused) and active and (tier_num >= required_tier_num) and ((exp + grace) >= now_ts)

    tier = "enterprise" if tier_num >= 2 else "premium" if tier_num >= 1 else "free"
    return EntitlementSnapshot(
        wallet=address,
        tier=tier,
        entitled=entitled,
        required_asset_id=None,
        required_min_balance=0,
        current_balance=0,
        source="subscription-algod",
        subscription_app_id=subscription_app_id,
        expires_at=exp,
        active=active,
    )
