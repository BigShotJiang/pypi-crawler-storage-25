from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import secrets
import time
from dataclasses import dataclass


@dataclass(slots=True)
class Challenge:
    address: str
    nonce: str
    expires_at: int
    message: str


_CHALLENGES: dict[str, Challenge] = {}
_RUNTIME_SECRET = secrets.token_bytes(32)


def _b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("utf-8").rstrip("=")


def _b64url_decode(value: str) -> bytes:
    padding = "=" * (-len(value) % 4)
    return base64.urlsafe_b64decode((value + padding).encode("utf-8"))


def _secret() -> bytes:
    configured = os.getenv("ALGOSEC_AUTH_SECRET", "").strip()
    if configured:
        return configured.encode("utf-8")
    return _RUNTIME_SECRET


def _sign(data: bytes) -> str:
    digest = hmac.new(_secret(), data, hashlib.sha256).digest()
    return _b64url_encode(digest)


def create_challenge(*, address: str, ttl_seconds: int = 300) -> Challenge:
    nonce = secrets.token_urlsafe(24)
    expires_at = int(time.time()) + ttl_seconds
    message = f"AlgoSec auth challenge\naddress={address}\nnonce={nonce}\nexpires_at={expires_at}"
    challenge = Challenge(address=address, nonce=nonce, expires_at=expires_at, message=message)
    _CHALLENGES[f"{address}:{nonce}"] = challenge
    return challenge


def _verify_algorand_signature(*, message: str, signature_b64: str, address: str) -> bool:
    try:
        from algosdk.util import verify_bytes

        signature_bytes = base64.b64decode(signature_b64)
        return bool(verify_bytes(message.encode("utf-8"), signature_bytes, address))
    except Exception:  # noqa: BLE001
        return False


def verify_challenge_signature(*, address: str, nonce: str, signature_b64: str) -> tuple[bool, str]:
    key = f"{address}:{nonce}"
    challenge = _CHALLENGES.get(key)
    if challenge is None:
        return False, "Challenge not found"

    if int(time.time()) > challenge.expires_at:
        _CHALLENGES.pop(key, None)
        return False, "Challenge expired"

    if challenge.address != address:
        return False, "Address mismatch"

    if not _verify_algorand_signature(message=challenge.message, signature_b64=signature_b64, address=address):
        return False, "Signature verification failed"

    _CHALLENGES.pop(key, None)
    return True, "ok"


def issue_access_token(*, address: str, tier: str, ttl_seconds: int = 900) -> str:
    payload = {
        "wallet": address,
        "tier": tier,
        "iat": int(time.time()),
        "exp": int(time.time()) + ttl_seconds,
    }
    encoded = _b64url_encode(json.dumps(payload, separators=(",", ":")).encode("utf-8"))
    signature = _sign(encoded.encode("utf-8"))
    return f"{encoded}.{signature}"


def verify_access_token(token: str) -> dict | None:
    if "." not in token:
        return None
    encoded, signature = token.split(".", 1)
    if not hmac.compare_digest(signature, _sign(encoded.encode("utf-8"))):
        return None

    try:
        payload = json.loads(_b64url_decode(encoded).decode("utf-8"))
    except Exception:  # noqa: BLE001
        return None

    if int(payload.get("exp", 0)) < int(time.time()):
        return None
    return payload
