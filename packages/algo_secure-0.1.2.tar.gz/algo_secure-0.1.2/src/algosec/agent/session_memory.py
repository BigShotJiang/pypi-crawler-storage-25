from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime


@dataclass(slots=True)
class AgentSession:
    session_id: str
    objective: str
    created_at: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    runs: list[dict] = field(default_factory=list)


_SESSIONS: dict[str, AgentSession] = {}


def get_or_create_session(*, session_id: str, objective: str) -> AgentSession:
    session = _SESSIONS.get(session_id)
    if session is None:
        session = AgentSession(session_id=session_id, objective=objective)
        _SESSIONS[session_id] = session
    return session


def add_session_run(*, session_id: str, run_payload: dict) -> AgentSession:
    session = _SESSIONS[session_id]
    session.runs.append(run_payload)
    session.updated_at = datetime.now(UTC).isoformat()
    return session


def get_session(session_id: str) -> AgentSession | None:
    return _SESSIONS.get(session_id)
