from __future__ import annotations

from algosec.agent.gemini import can_use_gemini, generate_gemini_explanation
from algosec.policy.models import PolicyEvaluation


def build_agent_explanation(*, policy_eval: PolicyEvaluation, context: dict | None = None) -> dict:
    context = context or {}
    reasons = [r.message for r in policy_eval.reasons]

    if policy_eval.decision.value == "BLOCK":
        decision_text = "Unsafe request: execution should be blocked."
    elif policy_eval.decision.value == "REVIEW":
        decision_text = "Risky request: manual security review required before execution."
    else:
        decision_text = "No blocking risk detected for current policy profile."

    explanation = {
        "decision": policy_eval.decision.value,
        "profile": policy_eval.profile,
        "score": policy_eval.score,
        "risk": policy_eval.risk,
        "reasoning": [decision_text, *reasons],
        "action": "block" if policy_eval.decision.value == "BLOCK" else "review" if policy_eval.decision.value == "REVIEW" else "allow",
        "narrative": None,
        "narrative_provider": "deterministic",
        "context": context,
    }

    if can_use_gemini():
        narrative = generate_gemini_explanation(policy_eval=policy_eval, context=context)
        if narrative:
            explanation["narrative"] = narrative
            explanation["narrative_provider"] = "gemini"

    return explanation
