from __future__ import annotations

import os

from algosec.policy.models import PolicyEvaluation


def _load_client():
    try:
        from google import genai

        return {"provider": "google.genai", "client": genai}
    except Exception:  # noqa: BLE001
        pass

    try:
        import google.generativeai as genai

        return {"provider": "google.generativeai", "client": genai}
    except Exception:  # noqa: BLE001
        return None


def _api_key() -> str:
    return os.getenv("ALGOSEC_GEMINI_API_KEY") or os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY") or ""


def can_use_gemini() -> bool:
    return bool(_api_key()) and _load_client() is not None


def generate_gemini_explanation(*, policy_eval: PolicyEvaluation, context: dict | None = None) -> str | None:
    loaded = _load_client()
    key = _api_key()
    if loaded is None or not key:
        return None

    provider = str(loaded.get("provider", ""))
    client = loaded.get("client")

    configured_model = os.getenv("ALGOSEC_GEMINI_MODEL", "gemini-flash-latest")
    model_candidates = [
        configured_model,
        "gemini-flash-latest",
        "models/gemini-2.0-flash",
        "models/gemini-2.5-flash",
    ]
    context = context or {}

    prompt = (
        "You are Algorand Security Copilot. Produce a concise runtime firewall explanation. "
        "Use exactly 3 bullet points and keep each under 22 words.\n"
        f"Decision: {policy_eval.decision.value}\n"
        f"Profile: {policy_eval.profile}\n"
        f"Security score: {policy_eval.score}\n"
        f"Risk score: {policy_eval.risk}\n"
        f"Reasons: {[r.message for r in policy_eval.reasons]}\n"
        f"Context: {context}\n"
    )

    try:
        for model_name in model_candidates:
            try:
                if provider == "google.genai":
                    sdk_client = client.Client(api_key=key)
                    response = sdk_client.models.generate_content(model=model_name, contents=prompt)
                    text = getattr(response, "text", None)
                else:
                    client.configure(api_key=key)
                    model = client.GenerativeModel(model_name)
                    response = model.generate_content(prompt)
                    text = getattr(response, "text", None)

                if isinstance(text, str) and text.strip():
                    return text.strip()
            except Exception:  # noqa: BLE001
                continue
    except Exception:  # noqa: BLE001
        return None

    return None
