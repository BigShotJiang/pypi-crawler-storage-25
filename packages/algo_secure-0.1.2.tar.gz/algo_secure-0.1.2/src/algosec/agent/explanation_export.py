from __future__ import annotations

from datetime import UTC, datetime


def _format_reasons(reasoning: list[str]) -> str:
    if not reasoning:
        return "- No explicit reasons provided."
    return "\n".join(f"- {item}" for item in reasoning)


def build_explanation_markdown(*, explanation: dict, simulation: dict | None = None) -> str:
    simulation = simulation or {}
    decision = str(explanation.get("decision", "UNKNOWN"))
    profile = str(explanation.get("profile", "-"))
    score = explanation.get("score", "-")
    risk = explanation.get("risk", "-")
    provider = str(explanation.get("narrative_provider", "deterministic"))
    narrative = explanation.get("narrative") or "No LLM narrative available."
    action = str(explanation.get("action", "review"))
    reasoning = explanation.get("reasoning", [])
    if not isinstance(reasoning, list):
        reasoning = [str(reasoning)]

    signals = simulation.get("signals", [])
    signal_lines = []
    if isinstance(signals, list):
        for signal in signals:
            if not isinstance(signal, dict):
                continue
            signal_lines.append(
                f"| {signal.get('severity', '-')} | {signal.get('code', '-')} | {signal.get('exploitability', '-')} | {signal.get('message', '-')} |"
            )

    if not signal_lines:
        signal_lines = ["| - | - | - | No simulation signals |"]

    lines = [
        "# A+ SEC Agent Decision Report",
        "",
        f"Generated: {datetime.now(UTC).isoformat()}",
        "",
        "## Decision Summary",
        "",
        "| Field | Value |",
        "|---|---|",
        f"| Decision | {decision} |",
        f"| Action | {action} |",
        f"| Policy profile | {profile} |",
        f"| Security score | {score} |",
        f"| Risk score | {risk} |",
        f"| Narrative provider | {provider} |",
        "",
        "## Why",
        "",
        _format_reasons([str(item) for item in reasoning]),
        "",
        "## AI Narrative",
        "",
        str(narrative),
        "",
        "## Simulation Signals",
        "",
        "| Severity | Code | Exploitability | Message |",
        "|---|---|---|---|",
        *signal_lines,
        "",
    ]

    return "\n".join(lines) + "\n"


def build_explanation_text(*, explanation: dict, simulation: dict | None = None) -> str:
    simulation = simulation or {}
    lines = [
        "A+ SEC AGENT DECISION",
        f"Decision: {explanation.get('decision', '-')}",
        f"Action: {explanation.get('action', '-')}",
        f"Profile: {explanation.get('profile', '-')}",
        f"Security score: {explanation.get('score', '-')}",
        f"Risk score: {explanation.get('risk', '-')}",
        f"Narrative provider: {explanation.get('narrative_provider', '-')}",
        "",
        "Reasoning:",
    ]

    reasoning = explanation.get("reasoning", [])
    if isinstance(reasoning, list) and reasoning:
        for idx, item in enumerate(reasoning, start=1):
            lines.append(f"  {idx}. {item}")
    else:
        lines.append("  1. No explicit reasons provided.")

    narrative = explanation.get("narrative")
    if narrative:
        lines.extend(["", "AI Narrative:", str(narrative)])

    signals = simulation.get("signals", []) if isinstance(simulation, dict) else []
    lines.extend(["", "Simulation Signals:"])
    if isinstance(signals, list) and signals:
        for signal in signals:
            if not isinstance(signal, dict):
                continue
            lines.append(
                f"  - [{signal.get('severity', '-')}] {signal.get('code', '-')}: {signal.get('message', '-')}")
    else:
        lines.append("  - None")

    return "\n".join(lines) + "\n"
