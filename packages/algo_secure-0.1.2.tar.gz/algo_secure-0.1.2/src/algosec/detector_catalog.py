from __future__ import annotations

from typing import TypedDict


class DetectorMeta(TypedDict):
    id: str
    name: str
    stage: str
    method: str
    description: str


_DETECTOR_CATALOG: dict[str, DetectorMeta] = {
    "ALG001": {
        "id": "ALG001",
        "name": "Missing RekeyTo safety guard",
        "stage": "TEAL static",
        "method": "pattern",
        "description": "Flags usage of RekeyTo without proven ZeroAddress guard.",
    },
    "ALG002": {
        "id": "ALG002",
        "name": "Missing CloseRemainderTo safety guard",
        "stage": "TEAL static",
        "method": "pattern",
        "description": "Flags CloseRemainderTo paths missing ZeroAddress guard.",
    },
    "ALG003": {
        "id": "ALG003",
        "name": "Potentially unguarded update/delete path",
        "stage": "TEAL static",
        "method": "pattern",
        "description": "Flags update/delete on-completion without creator auth guard.",
    },
    "ALG101": {
        "id": "ALG101",
        "name": "Group access without group-size validation",
        "stage": "DeFi static",
        "method": "pattern",
        "description": "Flags gtxn reads without explicit GroupSize validation.",
    },
    "ALG102": {
        "id": "ALG102",
        "name": "Inner transaction fee not explicitly set",
        "stage": "DeFi static",
        "method": "pattern",
        "description": "Flags inner txns missing explicit Fee assignment.",
    },
    "ALG103": {
        "id": "ALG103",
        "name": "State mutation without clear authorization",
        "stage": "DeFi static",
        "method": "pattern",
        "description": "Flags state writes with no clear sender/creator auth guard.",
    },
    "ALG104": {
        "id": "ALG104",
        "name": "AssetCloseTo without zero-address guard",
        "stage": "DeFi static",
        "method": "pattern",
        "description": "Flags AssetCloseTo usage without proven ZeroAddress guard.",
    },
    "ALG105": {
        "id": "ALG105",
        "name": "Tainted value to inner receiver",
        "stage": "Semantic",
        "method": "dataflow",
        "description": "Tracks untrusted values flowing into inner transfer receiver fields.",
    },
    "ALG106": {
        "id": "ALG106",
        "name": "ApplicationArgs read without bounds guard",
        "stage": "Semantic",
        "method": "semantic",
        "description": "Flags txna ApplicationArgs reads lacking NumAppArgs bound checks.",
    },
    "ALG401": {
        "id": "ALG401",
        "name": "PyTeal update/delete path without creator auth",
        "stage": "PyTeal precheck",
        "method": "ast-pattern",
        "description": "Flags update/delete branch without sender==creator guard.",
    },
    "ALG402": {
        "id": "ALG402",
        "name": "PyTeal missing RekeyTo guard",
        "stage": "PyTeal precheck",
        "method": "ast-pattern",
        "description": "Flags Txn.rekey_to() usage missing Global.zero_address() guard.",
    },
    "ALG403": {
        "id": "ALG403",
        "name": "PyTeal missing CloseRemainderTo guard",
        "stage": "PyTeal precheck",
        "method": "ast-pattern",
        "description": "Flags Txn.close_remainder_to() usage missing Global.zero_address() guard.",
    },
    "ALG404": {
        "id": "ALG404",
        "name": "PyTeal missing AssetCloseTo guard",
        "stage": "PyTeal precheck",
        "method": "ast-pattern",
        "description": "Flags Txn.asset_close_to() usage missing Global.zero_address() guard.",
    },
    "ALG405": {
        "id": "ALG405",
        "name": "PyTeal ApplicationArgs read without bound check",
        "stage": "PyTeal precheck",
        "method": "ast-pattern",
        "description": "Flags Txn.application_args[i] reads without explicit length guard.",
    },
    "ALG406": {
        "id": "ALG406",
        "name": "Borrow path lacks collateral ratio check",
        "stage": "PyTeal precheck",
        "method": "ast+regex",
        "description": "Flags lending borrow branches with no explicit LTV/collateral-ratio or borrow-cap check.",
    },
    "ALG407": {
        "id": "ALG407",
        "name": "Deposit accounting missing payment linkage checks",
        "stage": "PyTeal precheck",
        "method": "ast+regex",
        "description": "Flags grouped-payment deposits without robust sender/receiver/type linkage assertions.",
    },
}


def detector_meta(rule_id: str) -> DetectorMeta:
    return _DETECTOR_CATALOG.get(
        rule_id,
        {
            "id": rule_id,
            "name": "Unknown detector",
            "stage": "Unknown",
            "method": "unknown",
            "description": "No detector metadata available.",
        },
    )


def build_detector_list(rule_ids: list[str]) -> list[DetectorMeta]:
    return [detector_meta(rule_id) for rule_id in rule_ids]


def detector_name(rule_id: str) -> str:
    return detector_meta(rule_id)["name"]


def detector_label(rule_id: str, *, max_length: int = 44) -> str:
    name = detector_name(rule_id)
    if max_length <= 0:
        return name
    if len(name) <= max_length:
        return name
    if max_length <= 3:
        return name[:max_length]
    return f"{name[: max_length - 3].rstrip()}..."
