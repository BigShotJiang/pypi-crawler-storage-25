from __future__ import annotations

from algosec.simulator.models import SimulationResult, SimulationSignal, TxIntent


def simulate_intent(intent: TxIntent, *, current_state: dict[str, int] | None = None) -> SimulationResult:
    state = dict(current_state or {})
    liquidity = int(state.get("liquidity", 0))
    user_balance = int(state.get("user_balance", 0))

    signals: list[SimulationSignal] = []
    action = intent.action.lower().strip()

    if action == "deposit":
        if not intent.payment_in_group:
            signals.append(
                SimulationSignal(
                    code="deposit-no-group-payment",
                    message="Deposit requested without grouped payment transaction.",
                    severity="high",
                    exploitability="easy",
                )
            )
        if intent.payment_sender and intent.sender and intent.payment_sender != intent.sender:
            signals.append(
                SimulationSignal(
                    code="deposit-payment-sender-mismatch",
                    message="Grouped payment sender does not match app-call sender.",
                    severity="high",
                    exploitability="easy",
                )
            )
        if intent.payment_receiver is None:
            signals.append(
                SimulationSignal(
                    code="deposit-no-receiver-validation",
                    message="Payment receiver missing in simulation input; linkage cannot be validated.",
                    severity="medium",
                )
            )

        amt = int(intent.amount or 0)
        liquidity += amt
        user_balance += amt

    elif action in {"borrow", "withdraw"}:
        amt = int(intent.amount or 0)
        if not intent.app_args or len(intent.app_args) < 2:
            signals.append(
                SimulationSignal(
                    code="args-bounds-missing",
                    message="Action reads amount from app args but args length is insufficient.",
                    severity="high",
                    exploitability="easy",
                )
            )

        # Heuristic risk: positive balance check only, no ratio/cap context.
        if user_balance > 0 and state.get("ltv_bps") is None:
            signals.append(
                SimulationSignal(
                    code="missing-collateral-ratio",
                    message="Borrow/withdraw path has no explicit collateral ratio or borrow-cap guard in simulation context.",
                    severity="high",
                    exploitability="easy",
                )
            )

        if intent.receiver and intent.sender and intent.receiver != intent.sender:
            signals.append(
                SimulationSignal(
                    code="tainted-receiver",
                    message="Receiver differs from caller; transfer path may be user-controlled.",
                    severity="critical",
                    exploitability="easy",
                )
            )

        liquidity -= amt
        user_balance -= amt
        if liquidity < 0:
            signals.append(
                SimulationSignal(
                    code="liquidity-negative",
                    message="Post-simulation liquidity is negative, indicating insolvency/drain path.",
                    severity="critical",
                    exploitability="easy",
                )
            )

    elif action == "update_admin":
        signals.append(
            SimulationSignal(
                code="admin-auth-missing",
                message="Admin update action requires strict sender authorization; not present in simulation constraints.",
                severity="high",
                exploitability="easy",
            )
        )
    else:
        signals.append(
            SimulationSignal(
                code="unknown-action",
                message="Action not recognized by simulator profile.",
                severity="medium",
            )
        )

    outcome = "unsafe" if any(s.severity in {"critical", "high"} for s in signals) else "safe"
    return SimulationResult(action=action, outcome=outcome, signals=signals, state={"liquidity": liquidity, "user_balance": user_balance})
