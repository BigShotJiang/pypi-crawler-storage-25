from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(slots=True)
class TxIntent:
    action: str
    sender: str | None = None
    receiver: str | None = None
    amount: int | None = None
    app_args: list[str] = field(default_factory=list)
    group_size: int | None = None
    payment_in_group: bool = False
    payment_sender: str | None = None
    payment_receiver: str | None = None


@dataclass(slots=True)
class SimulationSignal:
    code: str
    message: str
    severity: str
    exploitability: str = "medium"


@dataclass(slots=True)
class SimulationResult:
    action: str
    outcome: str
    signals: list[SimulationSignal] = field(default_factory=list)
    state: dict[str, int] = field(default_factory=dict)
