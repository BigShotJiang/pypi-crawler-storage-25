from __future__ import annotations

from dataclasses import dataclass, field

from algosec.analysis.teal_parser import TealProgram

JUMP_OPS = {"b", "bz", "bnz"}
TERMINATORS = {"return", "err", "retsub"}


@dataclass(slots=True)
class BasicBlock:
    block_id: int
    start: int
    end: int
    successors: set[int] = field(default_factory=set)


def build_cfg(program: TealProgram) -> list[BasicBlock]:
    if not program.instructions:
        return []

    leaders = {0}
    for idx, ins in enumerate(program.instructions):
        if ins.opcode in JUMP_OPS and ins.args:
            target_idx = program.labels.get(ins.args[0])
            if target_idx is not None:
                leaders.add(target_idx)
            if idx + 1 < len(program.instructions):
                leaders.add(idx + 1)
        elif ins.opcode in TERMINATORS and idx + 1 < len(program.instructions):
            leaders.add(idx + 1)

    ordered = sorted(leaders)
    blocks: list[BasicBlock] = []
    for b_id, start in enumerate(ordered):
        end = (ordered[b_id + 1] - 1) if b_id + 1 < len(ordered) else len(program.instructions) - 1
        blocks.append(BasicBlock(block_id=b_id, start=start, end=end))

    ins_to_block = {}
    for block in blocks:
        for i in range(block.start, block.end + 1):
            ins_to_block[i] = block.block_id

    for block in blocks:
        tail = program.instructions[block.end]
        if tail.opcode in {"b", "bz", "bnz"} and tail.args:
            target = program.labels.get(tail.args[0])
            if target is not None:
                block.successors.add(ins_to_block[target])
            if tail.opcode in {"bz", "bnz"} and block.end + 1 < len(program.instructions):
                block.successors.add(ins_to_block[block.end + 1])
        elif tail.opcode not in TERMINATORS and block.end + 1 < len(program.instructions):
            block.successors.add(ins_to_block[block.end + 1])

    return blocks
