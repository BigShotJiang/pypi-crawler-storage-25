from __future__ import annotations

from dataclasses import dataclass, field

from algosec.analysis.teal_parser import TealProgram


@dataclass(slots=True)
class ContractSummary:
    file_path: str
    has_inner_txn: bool = False
    writes_global_state: bool = False
    writes_local_state: bool = False
    reads_group_txn: bool = False
    validates_group_size: bool = False
    guards_rekey: bool = False
    guards_close_remainder: bool = False
    guards_asset_close: bool = False
    guards_sender_creator: bool = False
    opcodes: set[str] = field(default_factory=set)
    labels: list[str] = field(default_factory=list)


def summarize_program(program: TealProgram) -> ContractSummary:
    summary = ContractSummary(file_path=str(program.path), labels=sorted(program.labels.keys()))

    comparisons: set[tuple[str, str, str]] = set()
    stack: list[str] = []
    saw_groupsize = False

    for ins in program.instructions:
        op = ins.opcode
        summary.opcodes.add(op)

        if op in {"itxn_begin", "itxn_submit", "itxn_field", "inner_txn_begin", "inner_txn_submit"}:
            summary.has_inner_txn = True
        if op in {"app_global_put", "app_global_del", "app_global_put_ex"}:
            summary.writes_global_state = True
        if op in {"app_local_put", "app_local_del"}:
            summary.writes_local_state = True
        if op == "gtxn":
            summary.reads_group_txn = True

        if op == "global" and ins.args and ins.args[0].lower() == "groupsize":
            saw_groupsize = True

        if op == "txn" and ins.args:
            stack.append(f"txn:{ins.args[0].lower()}")
            continue

        if op == "global" and ins.args:
            stack.append(f"global:{ins.args[0].lower()}")
            continue

        if op == "int" and ins.args:
            stack.append(f"int:{ins.args[0].lower()}")
            continue

        if op in {"==", "!=", ">", "<", ">=", "<="} and len(stack) >= 2:
            right = stack.pop()
            left = stack.pop()
            comparisons.add((left, op, right))
            stack.append(f"cmp:{left}{op}{right}")
            continue

        if op in {"assert", "return", "err", "b", "bnz", "bz"}:
            stack.clear()

    def has_eq(lhs: str, rhs: str) -> bool:
        for left, cmp_op, right in comparisons:
            if cmp_op != "==":
                continue
            if {lhs, rhs}.issubset({left, right}):
                return True
        return False

    summary.guards_rekey = has_eq("txn:rekeyto", "global:zeroaddress")
    summary.guards_close_remainder = has_eq("txn:closeremainderto", "global:zeroaddress")
    summary.guards_asset_close = has_eq("txn:assetcloseto", "global:zeroaddress")
    summary.guards_sender_creator = has_eq("txn:sender", "global:creatoraddress")
    summary.validates_group_size = saw_groupsize
    return summary
