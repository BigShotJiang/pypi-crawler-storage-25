from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass(slots=True)
class TealInstruction:
    line_no: int
    opcode: str
    args: list[str] = field(default_factory=list)
    raw: str = ""


@dataclass(slots=True)
class TealProgram:
    path: Path
    instructions: list[TealInstruction]
    labels: dict[str, int]


def parse_teal_file(path: Path) -> TealProgram:
    instructions: list[TealInstruction] = []
    labels: dict[str, int] = {}

    with path.open("r", encoding="utf-8") as handle:
        for i, line in enumerate(handle, start=1):
            raw = line.rstrip("\n")
            code = raw.split("//", maxsplit=1)[0].strip()
            if not code:
                continue

            if code.endswith(":"):
                label = code[:-1].strip()
                if label:
                    labels[label] = len(instructions)
                continue

            parts = code.split()
            instructions.append(
                TealInstruction(
                    line_no=i,
                    opcode=parts[0].lower(),
                    args=parts[1:],
                    raw=raw,
                )
            )

    return TealProgram(path=path, instructions=instructions, labels=labels)
