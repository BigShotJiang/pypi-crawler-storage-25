from __future__ import annotations

from dataclasses import dataclass, field

from algosec.analysis.teal_parser import TealInstruction, TealProgram


@dataclass(slots=True)
class ExprToken:
    kind: str
    value: str
    line_no: int
    tainted: bool = False


@dataclass(slots=True)
class CompareEvent:
    left: ExprToken
    op: str
    right: ExprToken
    line_no: int


@dataclass(slots=True)
class FieldAssignment:
    field: str
    source: ExprToken
    line_no: int


@dataclass(slots=True)
class SemanticModel:
    compares: list[CompareEvent] = field(default_factory=list)
    asserted_compares: list[CompareEvent] = field(default_factory=list)
    inner_field_assignments: list[FieldAssignment] = field(default_factory=list)
    app_args_reads: list[tuple[int, int | None]] = field(default_factory=list)

    def has_asserted_equality(self, lhs: str, rhs: str) -> bool:
        for cmp_ev in self.asserted_compares:
            if cmp_ev.op != "==":
                continue
            pair = {cmp_ev.left.value, cmp_ev.right.value}
            if {lhs, rhs}.issubset(pair):
                return True
        return False

    def has_update_delete_assert(self) -> bool:
        targets = {"int:updateapplication", "int:deleteapplication"}
        for cmp_ev in self.asserted_compares:
            pair = {cmp_ev.left.value, cmp_ev.right.value}
            if "txn:oncompletion" in pair and pair.intersection(targets):
                return True
        return False

    def has_num_app_args_guard(self, min_required: int) -> bool:
        for cmp_ev in self.asserted_compares:
            left, right = cmp_ev.left.value, cmp_ev.right.value
            if left.startswith("txn:numappargs") and right.startswith("int:"):
                lit = _int_from_token(right)
                if lit is None:
                    continue
                if cmp_ev.op == ">=" and lit >= min_required:
                    return True
                if cmp_ev.op == ">" and lit >= (min_required - 1):
                    return True
                if cmp_ev.op == "==" and lit >= min_required:
                    return True
            if right.startswith("txn:numappargs") and left.startswith("int:"):
                lit = _int_from_token(left)
                if lit is None:
                    continue
                if cmp_ev.op == "<=" and lit >= min_required:
                    return True
                if cmp_ev.op == "<" and lit >= (min_required + 1):
                    return True
                if cmp_ev.op == "==" and lit >= min_required:
                    return True
        return False


def _int_from_token(token: str) -> int | None:
    if not token.startswith("int:"):
        return None
    raw = token.split(":", maxsplit=1)[1]
    try:
        return int(raw)
    except ValueError:
        return None


def _push_for_ins(stack: list[ExprToken], ins: TealInstruction) -> bool:
    if ins.opcode == "txn" and ins.args:
        field = ins.args[0].lower()
        stack.append(ExprToken(kind="txn", value=f"txn:{field}", line_no=ins.line_no, tainted=True))
        return True

    if ins.opcode == "gtxn" and len(ins.args) >= 2:
        field = ins.args[1].lower()
        stack.append(ExprToken(kind="gtxn", value=f"gtxn:{field}", line_no=ins.line_no, tainted=True))
        return True

    if ins.opcode == "txna" and ins.args:
        field = ins.args[0].lower()
        index = ins.args[1].lower() if len(ins.args) >= 2 else "?"
        tainted = field == "applicationargs"
        stack.append(
            ExprToken(
                kind="txna",
                value=f"txna:{field}:{index}",
                line_no=ins.line_no,
                tainted=tainted,
            )
        )
        return True

    if ins.opcode == "global" and ins.args:
        field = ins.args[0].lower()
        stack.append(ExprToken(kind="global", value=f"global:{field}", line_no=ins.line_no, tainted=False))
        return True

    if ins.opcode == "int" and ins.args:
        value = ins.args[0].lower()
        stack.append(ExprToken(kind="int", value=f"int:{value}", line_no=ins.line_no, tainted=False))
        return True

    if ins.opcode == "byte" and ins.args:
        value = " ".join(ins.args).lower()
        stack.append(ExprToken(kind="byte", value=f"byte:{value}", line_no=ins.line_no, tainted=False))
        return True

    return False


def analyze_semantics(program: TealProgram) -> SemanticModel:
    model = SemanticModel()
    stack: list[ExprToken] = []

    for ins in program.instructions:
        if _push_for_ins(stack, ins):
            if ins.opcode == "txna" and ins.args and ins.args[0].lower() == "applicationargs":
                idx: int | None = None
                if len(ins.args) >= 2:
                    try:
                        idx = int(ins.args[1])
                    except ValueError:
                        idx = None
                model.app_args_reads.append((ins.line_no, idx))
            continue

        if ins.opcode == "btoi" and stack:
            token = stack.pop()
            stack.append(
                ExprToken(
                    kind="btoi",
                    value=f"btoi({token.value})",
                    line_no=ins.line_no,
                    tainted=token.tainted,
                )
            )
            continue

        if ins.opcode in {"==", "!=", ">", "<", ">=", "<="} and len(stack) >= 2:
            right = stack.pop()
            left = stack.pop()
            cmp_ev = CompareEvent(left=left, op=ins.opcode, right=right, line_no=ins.line_no)
            model.compares.append(cmp_ev)
            stack.append(
                ExprToken(
                    kind="cmp",
                    value=f"cmp({left.value}{ins.opcode}{right.value})",
                    line_no=ins.line_no,
                    tainted=left.tainted or right.tainted,
                )
            )
            continue

        if ins.opcode == "assert" and stack:
            top = stack.pop()
            if top.kind == "cmp":
                for cmp_ev in reversed(model.compares):
                    if cmp_ev.line_no == top.line_no:
                        model.asserted_compares.append(cmp_ev)
                        break
            continue

        if ins.opcode == "itxn_field" and ins.args:
            field = ins.args[0].lower()
            source = stack.pop() if stack else ExprToken(kind="unknown", value="unknown", line_no=ins.line_no, tainted=True)
            model.inner_field_assignments.append(FieldAssignment(field=field, source=source, line_no=ins.line_no))
            continue

        if ins.opcode in {"return", "err", "b", "bnz", "bz", "retsub"}:
            stack.clear()
            continue

        # Conservative cleanup for stack-heavy instructions where argument behavior is not modeled.
        if ins.opcode in {
            "pop",
            "dup",
            "dup2",
            "swap",
            "dig",
            "cover",
            "uncover",
            "concat",
            "len",
            "substring",
            "substring3",
            "extract",
            "extract3",
            "sha256",
            "keccak256",
            "ed25519verify",
            "add",
            "sub",
            "mul",
            "div",
            "mod",
            "&&",
            "||",
            "!",
            "~",
            "bitlen",
        }:
            if stack:
                stack.pop()

    return model
