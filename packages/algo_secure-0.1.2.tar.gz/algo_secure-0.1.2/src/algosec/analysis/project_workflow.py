from __future__ import annotations

from collections import defaultdict

from algosec.analysis.contract_summary import ContractSummary


def build_workflow_graph(summaries: list[ContractSummary]) -> dict[str, object]:
    edges: list[dict[str, str]] = []
    producers: dict[str, list[str]] = defaultdict(list)
    consumers: dict[str, list[str]] = defaultdict(list)

    for summary in summaries:
        if summary.writes_global_state:
            producers["global_state"].append(summary.file_path)
        if summary.writes_local_state:
            producers["local_state"].append(summary.file_path)
        if summary.has_inner_txn:
            producers["inner_txn"].append(summary.file_path)
        if summary.reads_group_txn:
            consumers["group_txn"].append(summary.file_path)

    for channel, srcs in producers.items():
        dsts = consumers.get("group_txn", []) if channel in {"global_state", "local_state"} else []
        for src in srcs:
            for dst in dsts:
                if src != dst:
                    edges.append({"from": src, "to": dst, "via": channel})

    return {
        "nodes": [
            {
                "file": summary.file_path,
                "capabilities": {
                    "inner_txn": summary.has_inner_txn,
                    "write_global": summary.writes_global_state,
                    "write_local": summary.writes_local_state,
                    "group_access": summary.reads_group_txn,
                },
            }
            for summary in summaries
        ],
        "edges": edges,
    }
