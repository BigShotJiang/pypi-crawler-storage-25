from __future__ import annotations

import importlib.util
import inspect
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from types import ModuleType
from uuid import uuid4


@dataclass(slots=True)
class CompiledTealArtifact:
    source_path: Path
    name: str
    teal: str
    mode: str
    version: int


def looks_like_pyteal_source(path: Path) -> bool:
    try:
        text = path.read_text(encoding="utf-8")
    except Exception:  # noqa: BLE001
        return False

    if path.suffix.lower() == ".pyteal":
        return True

    marker = re.compile(r"\b(from\s+pyteal\s+import|import\s+pyteal\b)")
    return bool(marker.search(text))


def _load_module(path: Path) -> ModuleType:
    module_name = f"algosec_pyteal_{path.stem}_{uuid4().hex}"
    spec = importlib.util.spec_from_file_location(module_name, str(path))
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load Python module from {path}")

    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    try:
        spec.loader.exec_module(module)
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError(f"Failed importing PyTeal file {path}: {exc}") from exc
    return module


def _resolve_member(value: object) -> object:
    if not callable(value):
        return value

    try:
        sig = inspect.signature(value)
    except (TypeError, ValueError):
        return value

    required = [
        p
        for p in sig.parameters.values()
        if p.default is p.empty and p.kind in {p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD}
    ]
    if required:
        return value

    try:
        return value()
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError(f"Unable to execute zero-arg PyTeal builder: {exc}") from exc


def compile_pyteal_file(path: Path, *, version: int = 8) -> list[CompiledTealArtifact]:
    try:
        from pyteal import Expr, Mode, compileTeal
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError("PyTeal support requires `pyteal` package. Install it with `pip install pyteal`.") from exc

    module = _load_module(path)

    candidates: list[tuple[str, str, object]] = []

    # Most common PyTeal conventions.
    named: list[tuple[str, str, str]] = [
        ("approval_program", "application", "approval_program"),
        ("clear_state_program", "application", "clear_state_program"),
        ("logic_signature", "signature", "logic_signature"),
        ("signature_program", "signature", "signature_program"),
        ("program", "application", "program"),
    ]
    for attr, mode, alias in named:
        if hasattr(module, attr):
            candidates.append((alias, mode, getattr(module, attr)))

    # Optional container convention: CONTRACTS = {"name": expr_or_builder}
    contracts = getattr(module, "CONTRACTS", None)
    if isinstance(contracts, dict):
        for key, value in contracts.items():
            alias = str(key).strip() or "contract"
            candidates.append((alias, "application", value))

    artifacts: list[CompiledTealArtifact] = []
    seen_names: set[str] = set()

    for alias, mode, raw in candidates:
        member = _resolve_member(raw)

        if isinstance(member, str):
            teal = member
        elif isinstance(member, Expr):
            teal_mode = Mode.Signature if mode == "signature" else Mode.Application
            teal = compileTeal(member, mode=teal_mode, version=version)
        else:
            continue

        clean_name = alias
        n = 2
        while clean_name in seen_names:
            clean_name = f"{alias}_{n}"
            n += 1
        seen_names.add(clean_name)

        artifacts.append(
            CompiledTealArtifact(
                source_path=path,
                name=clean_name,
                teal=teal,
                mode=mode,
                version=version,
            )
        )

    if artifacts:
        return artifacts

    raise RuntimeError(
        "PyTeal file found but no compile targets detected. "
        "Expected one of: approval_program, clear_state_program, logic_signature, signature_program, program, or CONTRACTS."
    )
