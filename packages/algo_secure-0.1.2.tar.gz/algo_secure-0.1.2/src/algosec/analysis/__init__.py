"""Analysis layer (parser, CFG, semantic engines)."""
