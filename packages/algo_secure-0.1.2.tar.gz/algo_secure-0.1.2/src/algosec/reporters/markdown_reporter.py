from __future__ import annotations

from pathlib import Path

from algosec.detector_catalog import detector_name
from algosec.models import ScanResult


def _exploitability_for_finding(*, severity: str, confidence: float) -> str:
    sev = severity.lower()
    if sev == "critical" and confidence >= 0.75:
        return "EASY"
    if sev in {"critical", "high"} and confidence >= 0.6:
        return "MEDIUM"
    return "HARD"


def _recommendation_for_rule(rule_id: str) -> str:
    fixes = {
        "ALG001": "Add `txn RekeyTo == global ZeroAddress` guard and assert it early.",
        "ALG002": "Add `txn CloseRemainderTo == global ZeroAddress` guard and assert it early.",
        "ALG003": "Gate Update/Delete with `txn Sender == global CreatorAddress` (or stronger governance policy).",
        "ALG101": "Validate `global GroupSize` and expected `txn GroupIndex` before reading `gtxn` fields.",
        "ALG102": "Set inner tx fee explicitly: `int 0; itxn_field Fee`.",
        "ALG103": "Protect state writes with role checks and explicit sender authorization.",
        "ALG104": "Guard `txn AssetCloseTo == global ZeroAddress` unless intentional close-out flow is enforced.",
        "ALG105": "Prevent tainted receiver flows: authorize sender/role and derive inner receivers from trusted state.",
        "ALG106": "Validate `txn NumAppArgs` bounds before reading `txna ApplicationArgs <idx>`.",
        "ALG401": "Assert `Txn.sender() == Global.creator_address()` before update/delete/admin paths.",
        "ALG402": "Add `Assert(Txn.rekey_to() == Global.zero_address())` before business logic.",
        "ALG403": "Add `Assert(Txn.close_remainder_to() == Global.zero_address())` before business logic.",
        "ALG404": "Add `Assert(Txn.asset_close_to() == Global.zero_address())` unless intentionally authorized.",
        "ALG405": "Check args length first: `Assert(Txn.application_args.length() >= N)` before reads.",
        "ALG406": "Enforce collateral ratio/cap checks, e.g. `Assert(borrow_amt * 100 <= collateral * LTV_BPS)`.",
        "ALG407": "Validate grouped payment linkage: type/sender/receiver/amount and expected group index before crediting deposits.",
    }
    return fixes.get(rule_id, "Review control flow and add explicit invariant checks around flagged operations.")


def write_markdown(result: ScanResult, output: Path) -> None:
    score = result.metadata.get("score", {}) if isinstance(result.metadata, dict) else {}
    security_score = score.get("security_score", "-")
    risk_score = score.get("risk_score", "-")
    grade = score.get("grade", "-")
    status = score.get("status", "unknown")
    deploy_verdict = score.get("deploy_verdict", "-")
    score_summary = score.get("summary", "-")

    meta = result.metadata if isinstance(result.metadata, dict) else {}
    detectors = meta.get("detectors_run", []) if isinstance(meta, dict) else []
    detector_rows = meta.get("detectors", []) if isinstance(meta, dict) else []
    duration_ms = meta.get("duration_ms", "-") if isinstance(meta, dict) else "-"
    files_discovered = meta.get("files_discovered", len(result.analyzed_files)) if isinstance(meta, dict) else len(result.analyzed_files)

    severity_counts = {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0}
    for finding in result.findings:
        if finding.severity.value in severity_counts:
            severity_counts[finding.severity.value] += 1

    lines: list[str] = []
    lines.append("# A+ SEC report")
    lines.append("")

    lines.append("## Scan profile")
    lines.append("")
    lines.append("| Field | Value |")
    lines.append("|---|---|")
    lines.append(f"| Target | {result.target} |")
    lines.append(f"| Files discovered | {files_discovered} |")
    lines.append(f"| Files analyzed | {len(result.analyzed_files)} |")
    lines.append(f"| Detectors run | {len(detectors)} |")
    lines.append(f"| Duration | {duration_ms} ms |")
    lines.append("")

    lines.append("## Security score")
    lines.append("")
    lines.append("| Score | Risk | Grade | Status | Deploy verdict |")
    lines.append("|---:|---:|---|---|---|")
    lines.append(f"| {security_score}/100 | {risk_score}/100 | {grade} | {status} | {deploy_verdict} |")
    lines.append("")
    lines.append(f"Summary: {score_summary}")
    lines.append("")

    lines.append("## Severity breakdown")
    lines.append("")
    lines.append("| Critical | High | Medium | Low | Info |")
    lines.append("|---:|---:|---:|---:|---:|")
    lines.append(
        f"| {severity_counts['critical']} | {severity_counts['high']} | {severity_counts['medium']} | {severity_counts['low']} | {severity_counts['info']} |"
    )
    lines.append("")

    if detector_rows:
        lines.append("## Detectors run")
        lines.append("")
        lines.append("| ID | Detector | Stage | Method |")
        lines.append("|---|---|---|---|")
        for detector in detector_rows:
            lines.append(
                f"| {detector.get('id','-')} | {detector.get('name','-')} | {detector.get('stage','-')} | {detector.get('method','-')} |"
            )
        lines.append("")
    elif detectors:
        lines.append("## Detectors run")
        lines.append("")
        for detector in detectors:
            lines.append(f"- {detector}")
        lines.append("")

    if result.errors:
        lines.append("## Runtime issues")
        lines.append("")
        lines.append("| Type | Target | Message |")
        lines.append("|---|---|---|")
        for err in result.errors:
            lines.append(f"| scan-runtime-error | {result.target} | {err} |")
        lines.append("")

    diagnostics = []
    if isinstance(result.metadata, dict):
        maybe = result.metadata.get("error_diagnostics")
        if isinstance(maybe, list):
            diagnostics = [d for d in maybe if isinstance(d, dict)]

    if diagnostics:
        lines.append("## Error diagnostics")
        lines.append("")
        lines.append("| Type | Likely cause | Fix |")
        lines.append("|---|---|---|")
        for diag in diagnostics:
            lines.append(
                f"| {diag.get('type','scan-runtime-error')} | {diag.get('cause','-')} | {diag.get('fix','-')} |"
            )
        lines.append("")

    attack_paths = []
    if isinstance(result.metadata, dict):
        maybe = result.metadata.get("attack_paths")
        if isinstance(maybe, list):
            attack_paths = [p for p in maybe if isinstance(p, dict)]

    if attack_paths:
        lines.append("## Attack paths")
        lines.append("")
        for path in attack_paths:
            lines.append(f"### {path.get('title', 'Attack path')}")
            lines.append("")
            lines.append(f"- Severity: {path.get('severity', '-')}")
            related = path.get("related_rules", [])
            if isinstance(related, list):
                related_labels = [f"{detector_name(str(x))} ({x})" for x in related]
                lines.append(f"- Related detectors: {', '.join(related_labels)}")
            steps = path.get("steps", [])
            if isinstance(steps, list) and steps:
                lines.append("- Flow:")
                for step in steps:
                    lines.append(f"  - {step}")
            lines.append(f"- Exploitability: {str(path.get('exploitability', '-')).upper()}")
            impact = path.get("impact", [])
            if isinstance(impact, list) and impact:
                lines.append("- Impact:")
                for item in impact:
                    lines.append(f"  - {item}")
            lines.append("")

    lines.append("## Findings")
    lines.append("")
    if not result.findings:
        lines.append("No findings.")
    else:
        lines.append("| # | Detector | ID | Title | Severity | Confidence | Exploitability | File | Line | Why |")
        lines.append("|---:|---|---|---|---|---|---|---|---:|---|")
        for idx, finding in enumerate(result.findings, start=1):
            lines.append(
                f"| {idx} | {detector_name(finding.rule_id)} | {finding.rule_id} | {finding.title} | {finding.severity.value.upper()} | {finding.confidence:.2f} | {_exploitability_for_finding(severity=finding.severity.value, confidence=finding.confidence)} | {finding.location.file_path} | {finding.location.line or '-'} | {finding.message} |"
            )

        lines.append("")
        lines.append("## Detailed findings")
        lines.append("")
        for finding in result.findings:
            lines.append(f"### {finding.severity.value.upper()} • {detector_name(finding.rule_id)} ({finding.rule_id})")
            lines.append("")
            lines.append(f"- Finding title: {finding.title}")
            lines.append(f"- Location: {finding.location.file_path}:{finding.location.line or '-'}")
            lines.append(f"- Confidence: {finding.confidence:.2f}")
            lines.append(f"- Exploitability: {_exploitability_for_finding(severity=finding.severity.value, confidence=finding.confidence)}")
            lines.append(f"- Type: {', '.join(finding.tags) if finding.tags else 'general'}")
            lines.append(f"- Description: {finding.message}")
            lines.append(f"- Fix: {_recommendation_for_rule(finding.rule_id)}")
            if finding.evidence:
                lines.append(f"- Evidence: {' | '.join(f'{k}: {v}' for k, v in finding.evidence.items())}")
            lines.append("")

    output.write_text("\n".join(lines) + "\n", encoding="utf-8")
