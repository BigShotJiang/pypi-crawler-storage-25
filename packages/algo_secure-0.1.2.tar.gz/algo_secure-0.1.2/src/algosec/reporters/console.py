from __future__ import annotations

import os
from collections import Counter
from datetime import datetime, UTC
from pathlib import Path

from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.rule import Rule
from rich.syntax import Syntax
from rich.table import Table
from rich.text import Text

from algosec.detector_catalog import detector_label, detector_meta
from algosec.models import ScanResult


def _truncate(value: object, *, max_len: int) -> str:
    text = str(value)
    if len(text) <= max_len:
        return text
    if max_len <= 3:
        return text[:max_len]
    return f"{text[: max_len - 3].rstrip()}..."


def _compact_path(path: Path, *, max_len: int = 56) -> str:
    text = str(path)
    if len(text) <= max_len:
        return text
    name = path.name
    if len(name) + 4 >= max_len:
        return _truncate(name, max_len=max_len)
    head_len = max_len - len(name) - 4
    return f"{text[:head_len]}.../{name}"


def _syntax_language_for(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix == ".py":
        return "python"
    if suffix == ".teal":
        return "nasm"
    if suffix == ".json":
        return "json"
    return "text"


def _gradient_line(line: str, palette: tuple[str, ...]) -> Text:
    text = Text()
    if not line:
        return text

    length = len(line)
    buckets = max(1, len(palette))
    for index, char in enumerate(line):
        color = palette[min((index * buckets) // max(1, length), buckets - 1)]
        text.append(char, style=f"bold {color}")
    return text


def _severity_style(level: str) -> str:
    styles = {
        "critical": "bold white on magenta",
        "high": "bold bright_magenta",
        "medium": "bold bright_cyan",
        "low": "bold green",
        "info": "bold white",
    }
    return styles.get(level.lower(), "white")


def _severity_badge(level: str) -> Text:
    labels = {
        "critical": "🔴 CRITICAL",
        "high": "🟠 HIGH",
        "medium": "🟡 MEDIUM",
        "low": "🔵 LOW",
        "info": "⚪ INFO",
    }
    return Text(labels.get(level.lower(), level.upper()), style=_severity_style(level))


def _confidence_badge(confidence: float) -> Text:
    if confidence >= 0.8:
        label = "HIGH"
        style = "bold green"
    elif confidence >= 0.6:
        label = "MEDIUM"
        style = "bold bright_cyan"
    else:
        label = "LOW"
        style = "bold bright_magenta"
    return Text(label, style=style)


def _exploitability_for_finding(*, severity: str, confidence: float) -> str:
    sev = severity.lower()
    if sev == "critical" and confidence >= 0.75:
        return "EASY"
    if sev in {"critical", "high"} and confidence >= 0.6:
        return "MEDIUM"
    return "HARD"


def _render_banner(console: Console) -> None:
    console.print(Rule("[bold bright_cyan]A+ SEC REPORT[/bold bright_cyan]", style="cyan"))


def _render_scan_profile(console: Console, result: ScanResult) -> None:
    meta = result.metadata if isinstance(result.metadata, dict) else {}
    detectors = meta.get("detectors_run", []) if isinstance(meta, dict) else []
    duration_ms = int(meta.get("duration_ms", 0)) if isinstance(meta, dict) else 0

    profile = Table(box=box.SIMPLE, header_style="bold cyan")
    profile.add_column("Field", style="bold white")
    profile.add_column("Value", style="white")
    profile.add_row("Target", str(result.target))
    profile.add_row("Files discovered", str(meta.get("files_discovered", len(result.analyzed_files))))
    profile.add_row("Files analyzed", str(len(result.analyzed_files)))
    profile.add_row("Detectors run", str(len(detectors)))
    profile.add_row("Duration", f"{duration_ms} ms")
    console.print(profile)


def _render_detectors(console: Console, result: ScanResult) -> None:
    meta = result.metadata if isinstance(result.metadata, dict) else {}
    detector_rows = meta.get("detectors", []) if isinstance(meta, dict) else []
    if not detector_rows:
        detectors = meta.get("detectors_run", []) if isinstance(meta, dict) else []
        detector_rows = [{"id": d, "name": d, "stage": "-", "method": "-", "description": "-"} for d in detectors]

    if not detector_rows:
        return

    stage_counts = Counter(str(d.get("stage", "-")).strip() or "-" for d in detector_rows)
    method_counts = Counter(str(d.get("method", "-")).strip() or "-" for d in detector_rows)

    summary = Table(title="[bold cyan]Detectors summary[/bold cyan]", box=box.SIMPLE, header_style="bold cyan")
    summary.add_column("Metric", style="bold white")
    summary.add_column("Value", style="white")
    summary.add_row("Total detectors", str(len(detector_rows)))
    summary.add_row(
        "Stages",
        " | ".join(f"{k}:{v}" for k, v in sorted(stage_counts.items(), key=lambda x: x[0])) or "-",
    )
    summary.add_row(
        "Methods",
        " | ".join(f"{k}:{v}" for k, v in sorted(method_counts.items(), key=lambda x: x[0])) or "-",
    )
    console.print(summary)

    show_full = os.getenv("APLUSSEC_SHOW_DETECTORS", "").strip().lower() in {"1", "true", "yes"}
    if not show_full:
        console.print("[dim]Tip: set APLUSSEC_SHOW_DETECTORS=1 to print full detector list.[/dim]")
        return

    table = Table(title="[bold cyan]Detectors run[/bold cyan]", box=box.SIMPLE, header_style="bold cyan")
    table.add_column("#", justify="right", style="bold white")
    table.add_column("Detector", style="white")
    table.add_column("ID", style="bold white", no_wrap=True)
    table.add_column("Stage", style="white", no_wrap=True)
    table.add_column("Method", style="white", no_wrap=True)
    for idx, detector in enumerate(detector_rows, start=1):
        table.add_row(
            str(idx),
            str(detector.get("name", "-")),
            str(detector.get("id", "-")),
            str(detector.get("stage", "-")),
            str(detector.get("method", "-")),
        )
    console.print(table)


def _score_style(score: int) -> str:
    if score >= 90:
        return "bold green"
    if score >= 75:
        return "bold spring_green3"
    if score >= 60:
        return "bold bright_cyan"
    return "bold bright_magenta"


def _score_meter(score: int) -> Text:
    width = 26
    clamped = max(0, min(100, score))
    filled = int((clamped / 100.0) * width)
    meter = Text("[")
    for i in range(width):
        if i < filled:
            meter.append("█", style=_score_style(score))
        else:
            meter.append("░", style="grey35")
    meter.append("]")
    return meter


def _render_severity_chart(console: Console, severity_counts: Counter[str]) -> None:
    total = sum(severity_counts.values())
    chart = Table(box=box.SIMPLE, header_style="bold cyan")
    chart.add_column("Severity", style="bold white")
    chart.add_column("Count", justify="right")
    chart.add_column("Chart")

    order = ["critical", "high", "medium", "low", "info"]
    if total == 0:
        chart.add_row("none", "0", Text("No findings", style="green"))
    else:
        width = 22
        for level in order:
            count = severity_counts.get(level, 0)
            if count == 0:
                continue
            filled = int((count / total) * width)
            bar = Text()
            bar.append("█" * filled, style=_severity_style(level))
            bar.append("░" * (width - filled), style="grey35")
            chart.add_row(Text(level.upper(), style=_severity_style(level)), str(count), bar)

    console.print("[bold cyan]Severity distribution[/bold cyan]")
    console.print(chart)


def _render_visual_analytics(console: Console, result: ScanResult) -> None:
    if not result.findings:
        return

    hide_hotspots = os.getenv("APLUSSEC_HIDE_HOTSPOTS", "").strip().lower() in {"1", "true", "yes"}

    confidence_counts = Counter(
        "high" if f.confidence >= 0.8 else "medium" if f.confidence >= 0.6 else "low"
        for f in result.findings
    )
    exploitability_counts = Counter(
        _exploitability_for_finding(severity=f.severity.value, confidence=f.confidence)
        for f in result.findings
    )
    file_counts = Counter(str(f.location.file_path) for f in result.findings)

    def _bar(value: int, total: int, *, width: int = 20, style: str = "bold cyan") -> Text:
        filled = int((value / max(1, total)) * width) if total else 0
        t = Text()
        t.append("█" * filled, style=style)
        t.append("░" * (width - filled), style="grey78")
        return t

    total = len(result.findings)

    conf = Table(title="[bold cyan]Confidence graph[/bold cyan]", box=box.SIMPLE, header_style="bold cyan")
    conf.add_column("Band", style="bold white")
    conf.add_column("Count", justify="right")
    conf.add_column("Graph")
    conf.add_row("HIGH", str(confidence_counts.get("high", 0)), _bar(confidence_counts.get("high", 0), total, style="bold green"))
    conf.add_row("MEDIUM", str(confidence_counts.get("medium", 0)), _bar(confidence_counts.get("medium", 0), total, style="bold bright_cyan"))
    conf.add_row("LOW", str(confidence_counts.get("low", 0)), _bar(confidence_counts.get("low", 0), total, style="bold magenta"))

    ex = Table(title="[bold cyan]Exploitability graph[/bold cyan]", box=box.SIMPLE, header_style="bold cyan")
    ex.add_column("Class", style="bold white")
    ex.add_column("Count", justify="right")
    ex.add_column("Graph")
    ex.add_row("EASY", str(exploitability_counts.get("EASY", 0)), _bar(exploitability_counts.get("EASY", 0), total, style="bold red"))
    ex.add_row("MEDIUM", str(exploitability_counts.get("MEDIUM", 0)), _bar(exploitability_counts.get("MEDIUM", 0), total, style="bold yellow"))
    ex.add_row("HARD", str(exploitability_counts.get("HARD", 0)), _bar(exploitability_counts.get("HARD", 0), total, style="bold green"))

    console.print(conf)
    console.print(ex)
    if not hide_hotspots:
        hotspots = Table(title="[bold cyan]Hotspot files[/bold cyan]", box=box.SIMPLE, header_style="bold cyan")
        hotspots.add_column("File", style="white")
        hotspots.add_column("Findings", justify="right")
        hotspots.add_column("Density")
        max_file = max(file_counts.values()) if file_counts else 1
        for path, count in file_counts.most_common(5):
            hotspots.add_row(_compact_path(Path(path), max_len=62), str(count), _bar(count, max_file, style="bold blue"))
        console.print(hotspots)


def _render_priority_queue(console: Console, result: ScanResult) -> None:
    if not result.findings:
        return

    by_rule = Counter(f.rule_id for f in result.findings)
    table = Table(title="[bold cyan]Fix first (priority queue)[/bold cyan]", box=box.SIMPLE, header_style="bold cyan")
    table.add_column("Rule", style="bold white", no_wrap=True)
    table.add_column("Occurrences", justify="right", no_wrap=True)
    table.add_column("Recommended action", style="white")

    for rule_id, count in by_rule.most_common(5):
        table.add_row(rule_id, str(count), _recommendation_for_rule(rule_id))

    console.print(table)


def _render_kpi_row(console: Console, result: ScanResult, severity_counts: Counter[str]) -> None:
    score_meta = result.metadata.get("score") if isinstance(result.metadata, dict) else {}
    security_score = int(score_meta.get("security_score", 0)) if isinstance(score_meta, dict) else 0
    grade = str(score_meta.get("grade", "-")) if isinstance(score_meta, dict) else "-"

    confidence_avg = 0.0
    if result.findings:
        confidence_avg = sum(item.confidence for item in result.findings) / len(result.findings)

    summary = Table(box=box.SIMPLE_HEAVY, header_style="bold cyan")
    summary.add_column("Score", style="bold white")
    summary.add_column("Grade", style="bold white")
    summary.add_column("Files", justify="right")
    summary.add_column("Findings", justify="right")
    summary.add_column("Errors", justify="right")
    summary.add_column("Avg Confidence", justify="right")
    summary.add_row(
        Text(f"{security_score}/100", style=_score_style(security_score)),
        Text(grade, style=_score_style(security_score)),
        str(len(result.analyzed_files)),
        str(len(result.findings)),
        str(len(result.errors)),
        f"{confidence_avg:.2f}",
    )
    console.print(summary)


def _render_score_card(console: Console, result: ScanResult) -> None:
    score_meta = result.metadata.get("score") if isinstance(result.metadata, dict) else None
    if not isinstance(score_meta, dict):
        return

    security_score = int(score_meta.get("security_score", 0))
    risk_score = int(score_meta.get("risk_score", 0))
    grade = str(score_meta.get("grade", "-"))
    verdict = str(score_meta.get("deploy_verdict", "-")).replace("_", " ")
    summary = str(score_meta.get("summary", "-"))

    risk = Table(box=box.SIMPLE, header_style="bold cyan")
    risk.add_column("Metric", style="bold white")
    risk.add_column("Value")
    risk.add_row("Security score", Text(f"{security_score}/100", style=_score_style(security_score)))
    risk.add_row("Risk score", Text(f"{risk_score}/100", style="bold bright_magenta"))
    risk.add_row("Grade", Text(grade, style=_score_style(security_score)))
    risk.add_row("Deploy verdict", Text(verdict, style="bold bright_magenta" if verdict in {"BLOCKED", "DO NOT DEPLOY"} else "bold green"))
    risk.add_row("Meter", _score_meter(security_score))
    risk.add_row("Model", Text(str(score_meta.get("model", "-")), style="dim white"))
    risk.add_row("Summary", Text(summary, style="white"))
    console.print(risk)


def _render_summary(console: Console, result: ScanResult, severity_counts: Counter[str]) -> None:
    workflow = result.metadata.get("workflow") if isinstance(result.metadata, dict) else None
    node_count = len(workflow.get("nodes", [])) if isinstance(workflow, dict) else 0
    edge_count = len(workflow.get("edges", [])) if isinstance(workflow, dict) else 0

    summary = Table(box=box.SIMPLE, header_style="bold cyan")
    summary.add_column("Attribute", style="bold white")
    summary.add_column("Value")
    summary.add_row("Files scanned", str(len(result.analyzed_files)))
    summary.add_row("Findings", str(len(result.findings)))
    summary.add_row("Errors", str(len(result.errors)))
    summary.add_row("Workflow nodes", str(node_count))
    summary.add_row("Workflow edges", str(edge_count))

    if severity_counts:
        sev_line = Text()
        ordered = ["critical", "high", "medium", "low", "info"]
        for level in ordered:
            count = severity_counts.get(level, 0)
            if count <= 0:
                continue
            if sev_line:
                sev_line.append(" | ", style="bold white")
            sev_line.append(f"{level.upper()}={count}", style=_severity_style(level))
        summary.add_row("Severity split", sev_line)

    console.print(summary)


def _render_findings_table(console: Console, result: ScanResult) -> None:
    table = Table(
        title="[bold cyan]Findings[/bold cyan]",
        box=box.SIMPLE_HEAVY,
        header_style="bold cyan",
        row_styles=["", "dim"],
    )
    table.add_column("#", justify="right", style="bold white", no_wrap=True)
    table.add_column("Rule", style="bold white", no_wrap=True)
    table.add_column("Sev", no_wrap=True)
    table.add_column("Location", style="white", no_wrap=True)
    table.add_column("Conf", no_wrap=True)
    table.add_column("Exploit", no_wrap=True)
    table.add_column("Issue", style="white", no_wrap=True, overflow="ellipsis", max_width=56)

    for idx, finding in enumerate(result.findings, start=1):
        sev = finding.severity.value
        table.add_row(
            str(idx),
            finding.rule_id,
            _severity_badge(sev),
            f"{_compact_path(finding.location.file_path, max_len=42)}:{finding.location.line or '-'}",
            _confidence_badge(finding.confidence),
            _exploitability_for_finding(severity=sev, confidence=finding.confidence),
            _truncate(" ".join(finding.message.split()), max_len=72),
        )

    console.print(table)


def _render_label_legend(console: Console) -> None:
    legend = Table(title="[bold cyan]Legend (quick meaning)[/bold cyan]", box=box.SIMPLE, header_style="bold cyan")
    legend.add_column("Label", style="bold white", no_wrap=True)
    legend.add_column("Meaning", style="white")
    legend.add_row("HIGH / MEDIUM / LOW (Severity)", "How serious the issue impact is.")
    legend.add_row("HIGH / MEDIUM / LOW (Confidence)", "How sure the detector is about this finding.")
    legend.add_row("EASY / MEDIUM / HARD (Exploit)", "Estimated attacker effort to exploit.")
    console.print(legend)


def _recommendation_for_rule(rule_id: str) -> str:
    fixes = {
        "ALG001": "Add `txn RekeyTo == global ZeroAddress` guard and assert it early.",
        "ALG002": "Add `txn CloseRemainderTo == global ZeroAddress` guard and assert it early.",
        "ALG003": "Gate Update/Delete with `txn Sender == global CreatorAddress` (or stronger governance policy).",
        "ALG101": "Validate `global GroupSize` and expected `txn GroupIndex` before reading `gtxn` fields.",
        "ALG102": "Set inner tx fee explicitly: `int 0; itxn_field Fee`.",
        "ALG103": "Protect state writes with role checks and explicit sender authorization.",
        "ALG104": "Guard `txn AssetCloseTo == global ZeroAddress` unless intentional close-out flow is enforced.",
        "ALG105": "Prevent tainted receiver flows: authorize sender/role and derive inner receivers from trusted state.",
        "ALG106": "Validate `txn NumAppArgs` bounds before reading `txna ApplicationArgs <idx>`.",
        "ALG401": "For update/delete branches, assert `Txn.sender() == Global.creator_address()` (or governance-admin role).",
        "ALG402": "Add `Assert(Txn.rekey_to() == Global.zero_address())` before business logic.",
        "ALG403": "Add `Assert(Txn.close_remainder_to() == Global.zero_address())` before business logic.",
        "ALG404": "Add `Assert(Txn.asset_close_to() == Global.zero_address())` unless intentional and tightly authorized.",
        "ALG405": "Check args length first: `Assert(Txn.application_args.length() >= N)` before any `Txn.application_args[i]` reads.",
        "ALG406": "Enforce collateral ratio/cap checks, e.g. `Assert(borrow_amt * 100 <= collateral * LTV_BPS)`.",
        "ALG407": "Validate grouped payment linkage: type/sender/receiver/amount and expected group index before crediting deposits.",
    }
    return fixes.get(rule_id, "Review control flow and add explicit invariant checks around the flagged operation.")


def _category_for_rule(rule_id: str) -> str:
    categories = {
        "ALG001": "account-safety",
        "ALG002": "account-safety",
        "ALG003": "authorization",
        "ALG101": "atomic-group",
        "ALG102": "fee-accounting",
        "ALG103": "authorization",
        "ALG104": "account-safety",
        "ALG105": "taint-flow",
        "ALG106": "input-validation",
        "ALG401": "authorization",
        "ALG402": "account-safety",
        "ALG403": "account-safety",
        "ALG404": "account-safety",
        "ALG405": "input-validation",
        "ALG406": "risk-model",
        "ALG407": "atomic-group",
    }
    return categories.get(rule_id, "general")


def _severity_border(level: str) -> str:
    palette = {
        "critical": "magenta",
        "high": "red",
        "medium": "yellow",
        "low": "blue",
        "info": "white",
    }
    return palette.get(level.lower(), "cyan")


def _impact_note(level: str) -> str:
    text = {
        "critical": "Immediate risk. Treat as a release blocker.",
        "high": "High-risk behavior. Fix before deployment.",
        "medium": "Moderate risk. Fix in next hardening pass.",
        "low": "Low risk. Track and fix with routine maintenance.",
        "info": "Informational signal. Review for best practices.",
    }
    return text.get(level.lower(), "Review and validate expected behavior.")


def _render_recommendations(console: Console, result: ScanResult) -> None:
    if not result.findings:
        return

    table = Table(title="[bold cyan]Recommendations[/bold cyan]", box=box.SIMPLE, header_style="bold cyan")
    table.add_column("Detector", style="bold white")
    table.add_column("ID", style="bold white", no_wrap=True)
    table.add_column("Line", justify="right", no_wrap=True)
    table.add_column("Fix", style="white")

    for finding in result.findings:
        table.add_row(
            detector_label(finding.rule_id, max_length=34),
            finding.rule_id,
            str(finding.location.line or "-"),
            _recommendation_for_rule(finding.rule_id),
        )

    console.print(table)


def _render_issue_explanations(console: Console, result: ScanResult, *, max_items: int = 6) -> None:
    if not result.findings:
        return

    console.print("[bold cyan]Issue explanations[/bold cyan]")

    for idx, finding in enumerate(result.findings[:max_items], start=1):
        sev = finding.severity.value
        grid = Table.grid(expand=True)
        grid.add_column(style="bold white", width=16)
        grid.add_column(style="white")
        grid.add_row("Description", _truncate(finding.message, max_len=220))
        grid.add_row("Category", _category_for_rule(finding.rule_id))
        grid.add_row("Location", f"{_compact_path(finding.location.file_path, max_len=76)}:{finding.location.line or '-'}")
        grid.add_row("Impact", _impact_note(sev))
        grid.add_row("Fix", _recommendation_for_rule(finding.rule_id))

        title = (
            f"#{idx} {_severity_badge(sev).plain}  "
            f"{detector_label(finding.rule_id, max_length=42)}  "
            f"(confidence={_confidence_badge(finding.confidence).plain})"
        )
        console.print(Panel(grid, title=title, border_style=_severity_border(sev), box=box.ROUNDED))

    if len(result.findings) > max_items:
        console.print(f"[dim]... {len(result.findings) - max_items} more issue(s) not expanded.[/dim]")


def _render_detailed_findings(console: Console, result: ScanResult) -> None:
    if not result.findings:
        return

    console.print("[bold cyan]Detailed findings[/bold cyan]")
    for idx, finding in enumerate(result.findings, start=1):
        meta = detector_meta(finding.rule_id)
        detail = Table(box=box.ROUNDED, header_style="bold cyan")
        detail.add_column("Field", style="bold white", no_wrap=True)
        detail.add_column("Value", style="white")
        detail.add_row("#", str(idx))
        detail.add_row("Detector", str(meta.get("name", "-")))
        detail.add_row("ID", finding.rule_id)
        detail.add_row("Title", finding.title)
        detail.add_row("Severity", _severity_badge(finding.severity.value))
        detail.add_row("Location", f"{finding.location.file_path}:{finding.location.line or '-'}")
        detail.add_row("Confidence", _confidence_badge(finding.confidence))
        detail.add_row("Exploitability", _exploitability_for_finding(severity=finding.severity.value, confidence=finding.confidence))
        detail.add_row("Type", ", ".join(finding.tags) if finding.tags else "general")
        detail.add_row("Description", finding.message)
        detail.add_row("Fix", _recommendation_for_rule(finding.rule_id))

        if finding.evidence:
            evidence_parts = [f"{k}: {v}" for k, v in finding.evidence.items()]
            detail.add_row("Evidence", " | ".join(evidence_parts))

        console.print(
            Rule(
                f"[bold]{idx}) {_severity_badge(finding.severity.value).plain} {detector_label(finding.rule_id, max_length=42)}[/bold]",
                style="grey35",
            )
        )
        console.print(detail)


def _resolve_path(path: Path) -> Path | None:
    if path.exists():
        return path
    candidate = Path.cwd() / path
    if candidate.exists():
        return candidate
    return None


def _render_code_snippets(console: Console, result: ScanResult) -> None:
    if not result.findings:
        return

    shown = 0
    max_snippets = 8
    console.print("[bold cyan]Highlighted source lines[/bold cyan]")

    for finding in result.findings:
        if shown >= max_snippets:
            console.print("[dim]...more findings omitted in snippet view[/dim]")
            break

        line = finding.location.line
        if not line:
            continue
        resolved = _resolve_path(finding.location.file_path)
        if not resolved:
            continue

        try:
            source = resolved.read_text(encoding="utf-8")
        except Exception:  # noqa: BLE001
            continue

        start = max(1, line - 2)
        end = line + 2
        all_lines = source.splitlines()
        slice_text = "\n".join(all_lines[start - 1:end])
        syntax = Syntax(
            slice_text,
            _syntax_language_for(resolved),
            line_numbers=True,
            start_line=start,
            highlight_lines={line},
            theme="monokai",
        )
        console.print(
            f"[bold white]{detector_label(finding.rule_id, max_length=36)}[/bold white] ({finding.rule_id}) {_compact_path(resolved, max_len=72)}:{line}"
        )
        console.print(syntax)
        shown += 1


def _render_errors(console: Console, result: ScanResult) -> None:
    if not result.errors:
        return

    diagnostics = []
    if isinstance(result.metadata, dict):
        maybe = result.metadata.get("error_diagnostics")
        if isinstance(maybe, list):
            diagnostics = [d for d in maybe if isinstance(d, dict)]

    errors = Table(box=box.SIMPLE, header_style="bold magenta")
    errors.add_column("Type", style="bold white", no_wrap=True)
    errors.add_column("Target", style="white")
    errors.add_column("Message", style="white")
    errors.add_column("Likely cause", style="white")
    errors.add_column("Fix", style="white")

    if diagnostics:
        for idx, diag in enumerate(diagnostics):
            raw_error = result.errors[idx] if idx < len(result.errors) else "Runtime issue while scanning."
            errors.add_row(
                str(diag.get("type", "scan-runtime-error")),
                str(diag.get("target", result.target)),
                raw_error,
                str(diag.get("cause", "Runtime issue while scanning.")),
                str(diag.get("fix", "Fix runtime issue and rerun.")),
            )
    else:
        for err in result.errors:
            errors.add_row(
                "scan-runtime-error",
                str(result.target),
                err,
                "Runtime issue while scanning.",
                "Fix syntax/runtime issue and rerun scan.",
            )

    console.print(errors)


def _render_attack_paths(console: Console, result: ScanResult) -> None:
    meta = result.metadata if isinstance(result.metadata, dict) else {}
    raw_paths = meta.get("attack_paths", []) if isinstance(meta, dict) else []
    if not isinstance(raw_paths, list) or not raw_paths:
        return

    console.print("[bold cyan]Attack paths[/bold cyan]")
    for path in raw_paths:
        if not isinstance(path, dict):
            continue
        title = str(path.get("title", "Attack path"))
        severity = str(path.get("severity", "high")).upper()
        exploitability = str(path.get("exploitability", "medium")).upper()
        related = path.get("related_rules", [])
        steps = path.get("steps", [])
        impact = path.get("impact", [])

        table = Table(box=box.ROUNDED, header_style="bold cyan")
        table.add_column("Field", style="bold white", no_wrap=True)
        table.add_column("Value", style="white")
        table.add_row("Title", f"[{severity}] {title}")
        table.add_row("Exploitability", exploitability)
        table.add_row("Related", ", ".join(str(r) for r in related) if isinstance(related, list) else str(related))
        if isinstance(steps, list) and steps:
            table.add_row("Flow", "\n".join(f"{idx}. {step}" for idx, step in enumerate(steps, start=1)))
        if isinstance(impact, list) and impact:
            table.add_row("Impact", "\n".join(f"- {item}" for item in impact))
        console.print(table)


def _render_success(console: Console, *, has_errors: bool) -> None:
    if has_errors:
        console.print(
            "[bold yellow]Status: INCOMPLETE[/bold yellow] - No findings emitted because scan errors occurred."
        )
        return
    console.print("[bold green]Status: CLEAN[/bold green] - No findings detected.")


def _render_footer(console: Console) -> None:
    now = datetime.now(UTC).strftime("%Y-%m-%d %H:%M:%SZ")
    console.print(Rule(style="grey35"))
    console.print(f"[dim]Generated by A+ SEC at {now}[/dim]")


def render_console(result: ScanResult, compact: bool = False) -> None:
    console = Console()
    severity_counts = Counter(item.severity.value for item in result.findings)
    verbose_details = os.getenv("APLUSSEC_VERBOSE_DETAILS", "").strip().lower() in {"1", "true", "yes"}
    presentation = os.getenv("APLUSSEC_PRESENTATION_MODE", "").strip().lower() in {"1", "true", "yes"}

    if presentation:
        _render_banner(console)
        _render_kpi_row(console, result, severity_counts)
        _render_score_card(console, result)
        _render_severity_chart(console, severity_counts)
        _render_visual_analytics(console, result)
        _render_errors(console, result)
        _render_attack_paths(console, result)
        if result.findings:
            _render_issue_explanations(console, result, max_items=3)
        else:
            _render_success(console, has_errors=bool(result.errors))
        _render_footer(console)
        return

    _render_banner(console)
    _render_scan_profile(console, result)
    _render_kpi_row(console, result, severity_counts)
    if not compact:
        _render_score_card(console, result)
    _render_severity_chart(console, severity_counts)
    _render_visual_analytics(console, result)
    _render_errors(console, result)
    _render_attack_paths(console, result)

    if result.findings:
        if not compact:
            _render_issue_explanations(console, result)
            if verbose_details:
                _render_detailed_findings(console, result)
                _render_code_snippets(console, result)
        else:
            console.print(
                f"[bold bright_magenta]Findings present:[/bold bright_magenta] {len(result.findings)} "
                "(use non-compact mode for full table)"
            )
    else:
        _render_success(console, has_errors=bool(result.errors))

    _render_footer(console)
