from __future__ import annotations

import json
from pathlib import Path

from algosec.models import ScanResult


def write_sarif(result: ScanResult, output: Path) -> None:
    rules: dict[str, dict] = {}
    results: list[dict] = []

    for finding in result.findings:
        if finding.rule_id not in rules:
            rules[finding.rule_id] = {
                "id": finding.rule_id,
                "name": finding.title,
                "shortDescription": {"text": finding.title},
                "help": {"text": finding.message},
                "properties": {"tags": finding.tags},
            }

        results.append(
            {
                "ruleId": finding.rule_id,
                "level": "error" if finding.severity.value in {"critical", "high"} else "warning",
                "message": {"text": finding.message},
                "locations": [
                    {
                        "physicalLocation": {
                            "artifactLocation": {"uri": str(finding.location.file_path)},
                            "region": {"startLine": finding.location.line or 1},
                        }
                    }
                ],
            }
        )

    payload = {
        "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
        "version": "2.1.0",
        "runs": [
            {
                "tool": {
                    "driver": {
                        "name": "A+ SEC",
                        "informationUri": "https://github.com/your-org/aplussec",
                        "rules": list(rules.values()),
                    }
                },
                "results": results,
            }
        ],
    }

    output.write_text(json.dumps(payload, indent=2), encoding="utf-8")
