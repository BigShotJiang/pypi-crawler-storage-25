from __future__ import annotations

from html import escape
from pathlib import Path

from algosec.detector_catalog import detector_name
from algosec.models import ScanResult


def _exploitability_for_finding(*, severity: str, confidence: float) -> str:
  sev = severity.lower()
  if sev == "critical" and confidence >= 0.75:
    return "EASY"
  if sev in {"critical", "high"} and confidence >= 0.6:
    return "MEDIUM"
  return "HARD"


def _recommendation_for_rule(rule_id: str) -> str:
    fixes = {
        "ALG001": "Add `txn RekeyTo == global ZeroAddress` guard and assert it early.",
        "ALG002": "Add `txn CloseRemainderTo == global ZeroAddress` guard and assert it early.",
        "ALG003": "Gate Update/Delete with `txn Sender == global CreatorAddress` (or stronger governance policy).",
        "ALG101": "Validate `global GroupSize` and expected `txn GroupIndex` before reading `gtxn` fields.",
        "ALG102": "Set inner tx fee explicitly: `int 0; itxn_field Fee`.",
        "ALG103": "Protect state writes with role checks and explicit sender authorization.",
        "ALG104": "Guard `txn AssetCloseTo == global ZeroAddress` unless intentional close-out flow is enforced.",
        "ALG105": "Prevent tainted receiver flows: authorize sender/role and derive inner receivers from trusted state.",
        "ALG106": "Validate `txn NumAppArgs` bounds before reading `txna ApplicationArgs <idx>`.",
        "ALG401": "Assert `Txn.sender() == Global.creator_address()` before update/delete/admin paths.",
        "ALG402": "Add `Assert(Txn.rekey_to() == Global.zero_address())` before business logic.",
        "ALG403": "Add `Assert(Txn.close_remainder_to() == Global.zero_address())` before business logic.",
        "ALG404": "Add `Assert(Txn.asset_close_to() == Global.zero_address())` unless intentionally authorized.",
        "ALG405": "Check args length first: `Assert(Txn.application_args.length() >= N)` before reads.",
        "ALG406": "Enforce collateral ratio/cap checks, e.g. `Assert(borrow_amt * 100 <= collateral * LTV_BPS)`.",
        "ALG407": "Validate grouped payment linkage: type/sender/receiver/amount and expected group index before crediting deposits.",
    }
    return fixes.get(rule_id, "Review control flow and add explicit invariant checks around flagged operations.")


def write_html(result: ScanResult, output: Path) -> None:
    score = result.metadata.get("score", {}) if isinstance(result.metadata, dict) else {}
    security_score = score.get("security_score", "-")
    risk_score = score.get("risk_score", "-")
    grade = score.get("grade", "-")
    status = score.get("status", "unknown")
    deploy_verdict = score.get("deploy_verdict", "-")
    score_summary = score.get("summary", "-")

    meta = result.metadata if isinstance(result.metadata, dict) else {}
    detectors = meta.get("detectors_run", []) if isinstance(meta, dict) else []
    detector_rows = meta.get("detectors", []) if isinstance(meta, dict) else []
    duration_ms = int(meta.get("duration_ms", 0)) if isinstance(meta, dict) else 0
    files_discovered = (
        int(meta.get("files_discovered", len(result.analyzed_files)))
        if isinstance(meta, dict)
        else len(result.analyzed_files)
    )

    severity_counts = {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0}
    confidence_counts = {"high": 0, "medium": 0, "low": 0}
    exploitability_counts = {"EASY": 0, "MEDIUM": 0, "HARD": 0}
    rules_counter: dict[str, int] = {}
    file_counter: dict[str, int] = {}

    for item in result.findings:
        sev = item.severity.value.lower()
        if sev in severity_counts:
            severity_counts[sev] += 1

        conf = "high" if item.confidence >= 0.8 else "medium" if item.confidence >= 0.6 else "low"
        confidence_counts[conf] += 1
        rules_counter[item.rule_id] = rules_counter.get(item.rule_id, 0) + 1
        exploitability = _exploitability_for_finding(severity=item.severity.value, confidence=item.confidence)
        exploitability_counts[exploitability] = exploitability_counts.get(exploitability, 0) + 1
        file_key = str(item.location.file_path)
        file_counter[file_key] = file_counter.get(file_key, 0) + 1

    total_findings = sum(severity_counts.values())
    total_errors = len(result.errors)

    def _pct(value: int, total: int) -> int:
        if total <= 0:
            return 0
        return int(round((value / total) * 100))

    def _bar(value: int, total: int, width: int = 28) -> str:
        filled = int((value / max(1, total)) * width) if total else 0
        return "█" * filled + "░" * (width - filled)

    def _int_or(value: object, fallback: int) -> int:
        try:
            return int(value)
        except Exception:  # noqa: BLE001
            return fallback

    sec_value = _int_or(security_score, 0)
    risk_level = (
        "Low"
        if sec_value >= 85 and total_errors == 0
        else "Medium"
        if sec_value >= 60 and total_errors == 0
        else "High"
    )

    sev_total = max(1, total_findings)
    crit_pct = _pct(severity_counts["critical"], sev_total)
    high_pct = _pct(severity_counts["high"], sev_total)
    med_pct = _pct(severity_counts["medium"], sev_total)
    low_pct = _pct(severity_counts["low"], sev_total)
    donut_style = (
        f"conic-gradient(#8e24aa 0% {crit_pct}%, "
        f"#ef5350 {crit_pct}% {crit_pct + high_pct}%, "
        f"#ffa726 {crit_pct + high_pct}% {crit_pct + high_pct + med_pct}%, "
        f"#26a69a {crit_pct + high_pct + med_pct}% {crit_pct + high_pct + med_pct + low_pct}%, "
        f"#90a4ae {crit_pct + high_pct + med_pct + low_pct}% 100%)"
    )

    rows = []
    for finding in result.findings:
        sev = finding.severity.value.lower()
        sev_class = f"sev-{sev}"
        conf = "high" if finding.confidence >= 0.8 else "medium" if finding.confidence >= 0.6 else "low"
        short_message = finding.message if len(finding.message) <= 180 else f"{finding.message[:177]}..."
        rows.append(
            "<tr>"
            f"<td>{escape(detector_name(finding.rule_id))}</td>"
            f"<td>{escape(finding.rule_id)}</td>"
            f"<td><span class='pill {sev_class}'>{escape(finding.severity.value.upper())}</span></td>"
            f"<td>{escape(str(finding.location.file_path))}</td>"
            f"<td>{escape(str(finding.location.line or '-'))}</td>"
            f"<td><span class='pill conf-{conf}'>{conf.upper()}</span></td>"
            f"<td>{escape(_exploitability_for_finding(severity=finding.severity.value, confidence=finding.confidence))}</td>"
            f"<td>{escape(finding.title)}</td>"
            f"<td>{escape(short_message)}</td>"
            "</tr>"
        )

    if not rows:
        rows.append('<tr><td colspan="9">No findings</td></tr>')

    top_rules = sorted(rules_counter.items(), key=lambda x: x[1], reverse=True)[:5]
    top_rules_rows = "".join(
        "<tr>"
        f"<td>{escape(detector_name(rule_id))} ({escape(rule_id)})</td>"
        f"<td>{count}</td>"
        f"<td>{escape(_recommendation_for_rule(rule_id))}</td>"
        "</tr>"
        for rule_id, count in top_rules
    )

    hotspot_files = sorted(file_counter.items(), key=lambda x: x[1], reverse=True)[:5]
    hotspot_max = max((count for _, count in hotspot_files), default=1)
    hotspot_rows = "".join(
        "<tr>"
        f"<td>{escape(path)}</td>"
        f"<td>{count}</td>"
        f"<td class='mono'>{_bar(count, hotspot_max, width=20)}</td>"
        "</tr>"
        for path, count in hotspot_files
    )

    errors = "".join(
        "<tr>"
        "<td>scan-runtime-error</td>"
        f"<td>{escape(str(result.target))}</td>"
        f"<td>{escape(err)}</td>"
        "</tr>"
        for err in result.errors
    )
    detectors_html = "".join(f"<li>{escape(str(detector))}</li>" for detector in detectors)
    detectors_table_rows = "".join(
        "<tr>"
        f"<td>{escape(str(detector.get('id', '-')))}</td>"
        f"<td>{escape(str(detector.get('name', '-')))}</td>"
        f"<td>{escape(str(detector.get('stage', '-')))}</td>"
        f"<td>{escape(str(detector.get('method', '-')))}</td>"
        "</tr>"
        for detector in detector_rows
    )

    diagnostics = []
    if isinstance(meta, dict):
        maybe = meta.get("error_diagnostics")
        if isinstance(maybe, list):
            diagnostics = [d for d in maybe if isinstance(d, dict)]

    diagnostics_rows = "".join(
        "<tr>"
        f"<td>{escape(str(diag.get('type', 'scan-runtime-error')))}</td>"
        f"<td>{escape(str(diag.get('target', result.target)))}</td>"
        f"<td>{escape(str(diag.get('cause', '-')))}</td>"
        f"<td>{escape(str(diag.get('fix', '-')))}</td>"
        "</tr>"
        for diag in diagnostics
    )

    attack_paths = []
    if isinstance(meta, dict):
        maybe = meta.get("attack_paths")
        if isinstance(maybe, list):
            attack_paths = [p for p in maybe if isinstance(p, dict)]

    attack_paths_html = "".join(
        "<div class='card detail'>"
        f"<h3>{escape(str(path.get('title', 'Attack path')))}</h3>"
        "<table>"
        f"<tr><th>Severity</th><td>{escape(str(path.get('severity', '-')))}</td></tr>"
        f"<tr><th>Exploitability</th><td>{escape(str(path.get('exploitability', '-')).upper())}</td></tr>"
        f"<tr><th>Related detectors</th><td>{escape(', '.join(f'{detector_name(str(x))} ({x})' for x in path.get('related_rules', [])) if isinstance(path.get('related_rules', []), list) else str(path.get('related_rules', '-')))}</td></tr>"
        f"<tr><th>Flow</th><td>{escape(' | '.join(str(x) for x in path.get('steps', [])) if isinstance(path.get('steps', []), list) else str(path.get('steps', '-')))}</td></tr>"
        f"<tr><th>Impact</th><td>{escape(' | '.join(str(x) for x in path.get('impact', [])) if isinstance(path.get('impact', []), list) else str(path.get('impact', '-')))}</td></tr>"
        "</table>"
        "</div>"
        for path in attack_paths
    )

    details = []
    for idx, finding in enumerate(result.findings, start=1):
        sev = finding.severity.value.lower()
        sev_class = f"sev-{sev}"
        conf = "high" if finding.confidence >= 0.8 else "medium" if finding.confidence >= 0.6 else "low"
        evidence = (
            " | ".join(f"{escape(str(k))}: {escape(str(v))}" for k, v in finding.evidence.items())
            if finding.evidence
            else "-"
        )
        tags = ", ".join(finding.tags) if finding.tags else "general"
        details.append(
            "<div class='card detail'>"
            f"<h3>#{idx} <span class='pill {sev_class}'>{escape(finding.severity.value.upper())}</span> {escape(finding.title)}</h3>"
            "<table>"
            f"<tr><th>Detector</th><td>{escape(detector_name(finding.rule_id))}</td></tr>"
            f"<tr><th>Rule</th><td>{escape(finding.rule_id)}</td></tr>"
            f"<tr><th>Location</th><td>{escape(str(finding.location.file_path))}:{escape(str(finding.location.line or '-'))}</td></tr>"
            f"<tr><th>Confidence</th><td><span class='pill conf-{conf}'>{conf.upper()}</span></td></tr>"
            f"<tr><th>Exploitability</th><td>{escape(_exploitability_for_finding(severity=finding.severity.value, confidence=finding.confidence))}</td></tr>"
            f"<tr><th>Type</th><td>{escape(tags)}</td></tr>"
            f"<tr><th>Description</th><td>{escape(finding.message)}</td></tr>"
            f"<tr><th>Fix</th><td>{escape(_recommendation_for_rule(finding.rule_id))}</td></tr>"
            f"<tr><th>Evidence</th><td>{evidence}</td></tr>"
            "</table>"
            "</div>"
        )

    user_summary = (
        "No issues detected by current rule set. Re-run after major code changes."
        if total_findings == 0 and total_errors == 0
        else "Scan found potential risks. Fix critical/high findings first, then re-scan to confirm improvement."
        if total_errors == 0
        else "Scan encountered runtime errors. Fix parser/runtime issues first, then run scan again for accurate risk results."
    )

    html = f"""<!doctype html>
<html>
<head>
  <meta charset=\"utf-8\" />
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
  <title>A+ SEC report</title>
  <style>
    :root {{
      --bg: #ffffff;
      --panel: #ffffff;
      --panel-2: #f8fafc;
      --text: #0f172a;
      --muted: #475569;
      --line: #dbe3ee;
      --accent: #0ea5e9;
      --critical: #8e24aa;
      --high: #ef5350;
      --medium: #ffa726;
      --low: #26a69a;
      --info: #90a4ae;
    }}
    body {{ font-family: Inter, Arial, sans-serif; background: var(--bg); color: var(--text); margin: 24px; }}
    h1, h2, h3 {{ margin-top: 0; }}
    p {{ color: var(--muted); }}
    .card {{ border: 1px solid var(--line); border-radius: 12px; padding: 16px; margin-bottom: 16px; background: var(--panel); }}
    .detail {{ background: var(--panel-2); }}
    .kpi-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 10px; }}
    .kpi {{ background: #f8fafc; border: 1px solid var(--line); border-radius: 10px; padding: 10px; overflow-wrap: anywhere; word-break: break-word; }}
    .kpi b {{ color: var(--accent); }}
    .hero {{ display: grid; grid-template-columns: 1.2fr 1fr; gap: 14px; align-items: center; }}
    .donut-wrap {{ display: flex; align-items: center; gap: 14px; }}
    .donut {{ width: 130px; height: 130px; border-radius: 50%; background: {donut_style}; position: relative; border: 1px solid var(--line); }}
    .donut::after {{ content: ''; position: absolute; inset: 20px; border-radius: 50%; background: var(--panel); border: 1px solid var(--line); }}
    .legend {{ list-style: none; margin: 0; padding: 0; font-size: 13px; color: var(--muted); }}
    .legend li {{ margin: 4px 0; }}
    .sw {{ display: inline-block; width: 10px; height: 10px; border-radius: 999px; margin-right: 8px; }}
    .flow {{ margin: 0; padding-left: 18px; color: var(--muted); }}
    .flow li {{ margin: 6px 0; }}
    table {{ width: 100%; border-collapse: collapse; table-layout: fixed; }}
    th, td {{ border: 1px solid var(--line); padding: 8px; text-align: left; vertical-align: top; overflow-wrap: anywhere; word-break: break-word; }}
    th {{ background: #f1f5f9; color: #0f172a; }}
    .mono {{ font-family: ui-monospace, SFMono-Regular, Menlo, monospace; }}
    .bars {{ display: grid; gap: 10px; }}
    .bar-row {{ display: grid; grid-template-columns: 130px 1fr 58px; align-items: center; gap: 10px; }}
    .bar-rail {{ height: 10px; background: #eef2f7; border-radius: 999px; border: 1px solid var(--line); overflow: hidden; }}
    .bar-fill {{ height: 100%; }}
    .sev-critical {{ background: var(--critical); color: #fff; }}
    .sev-high {{ background: var(--high); color: #fff; }}
    .sev-medium {{ background: var(--medium); color: #111; }}
    .sev-low {{ background: var(--low); color: #fff; }}
    .sev-info {{ background: var(--info); color: #111; }}
    .pill {{ display: inline-block; border-radius: 999px; padding: 2px 10px; font-size: 12px; font-weight: 700; }}
    .conf-high {{ background: #2e7d32; color: #fff; }}
    .conf-medium {{ background: #0277bd; color: #fff; }}
    .conf-low {{ background: #6a1b9a; color: #fff; }}
    .badge {{ font-size: 12px; border: 1px solid var(--line); border-radius: 999px; padding: 3px 8px; color: var(--muted); background: #f8fafc; }}
    @media (max-width: 900px) {{ .hero {{ grid-template-columns: 1fr; }} }}
  </style>
</head>
<body>
  <div class=\"card\">
    <h1>A+ SEC report</h1>
    <p>{escape(user_summary)}</p>
    <div class=\"kpi-grid\">
      <div class=\"kpi\">Target<br><b>{escape(str(result.target))}</b></div>
      <div class=\"kpi\">Files discovered<br><b>{files_discovered}</b></div>
      <div class=\"kpi\">Files analyzed<br><b>{len(result.analyzed_files)}</b></div>
      <div class=\"kpi\">Detectors<br><b>{len(detectors)}</b></div>
      <div class=\"kpi\">Duration<br><b>{duration_ms} ms</b></div>
      <div class=\"kpi\">Scan status<br><b>{escape(str(status)).upper()}</b></div>
    </div>
  </div>

  <div class=\"card hero\">
    <div>
      <h2>Risk overview</h2>
      <div class=\"kpi-grid\">
        <div class=\"kpi\">Security score<br><b>{security_score}/100</b></div>
        <div class=\"kpi\">Risk score<br><b>{risk_score}/100</b></div>
        <div class=\"kpi\">Grade<br><b>{escape(str(grade))}</b></div>
        <div class=\"kpi\">Deploy verdict<br><b>{escape(str(deploy_verdict))}</b></div>
        <div class=\"kpi\">Risk level<br><b>{risk_level}</b></div>
        <div class=\"kpi\">Summary<br><b>{escape(str(score_summary))}</b></div>
      </div>
      <br/>
      <span class=\"badge\">Findings: {total_findings}</span>
      <span class=\"badge\">Errors: {total_errors}</span>
    </div>
    <div>
      <h3>Severity mix</h3>
      <div class=\"donut-wrap\">
        <div class=\"donut\" title=\"Severity distribution\"></div>
        <ul class=\"legend\">
          <li><span class=\"sw\" style=\"background:#8e24aa\"></span>Critical: {severity_counts['critical']}</li>
          <li><span class=\"sw\" style=\"background:#ef5350\"></span>High: {severity_counts['high']}</li>
          <li><span class=\"sw\" style=\"background:#ffa726\"></span>Medium: {severity_counts['medium']}</li>
          <li><span class=\"sw\" style=\"background:#26a69a\"></span>Low: {severity_counts['low']}</li>
          <li><span class=\"sw\" style=\"background:#90a4ae\"></span>Info: {severity_counts['info']}</li>
        </ul>
      </div>
    </div>
  </div>

  <div class=\"card\">
    <h2>How to read this report (for normal users)</h2>
    <ol class=\"flow\">
      <li>If <b>Deploy verdict</b> is BLOCKED, do not deploy until issues are fixed.</li>
      <li>Fix <b>Critical</b> and <b>High</b> findings first.</li>
      <li>Re-run scan after fixes and compare score/finding count.</li>
      <li>If errors are shown, fix runtime/parser errors before trusting severity results.</li>
    </ol>
  </div>

  <div class=\"card\">
    <h2>Analysis graphs</h2>
    <h3>Severity distribution</h3>
    <div class=\"bars\">
      <div class=\"bar-row\"><div>Critical</div><div class=\"bar-rail\"><div class=\"bar-fill\" style=\"width:{_pct(severity_counts['critical'], sev_total)}%;background:#8e24aa\"></div></div><div>{severity_counts['critical']}</div></div>
      <div class=\"bar-row\"><div>High</div><div class=\"bar-rail\"><div class=\"bar-fill\" style=\"width:{_pct(severity_counts['high'], sev_total)}%;background:#ef5350\"></div></div><div>{severity_counts['high']}</div></div>
      <div class=\"bar-row\"><div>Medium</div><div class=\"bar-rail\"><div class=\"bar-fill\" style=\"width:{_pct(severity_counts['medium'], sev_total)}%;background:#ffa726\"></div></div><div>{severity_counts['medium']}</div></div>
      <div class=\"bar-row\"><div>Low</div><div class=\"bar-rail\"><div class=\"bar-fill\" style=\"width:{_pct(severity_counts['low'], sev_total)}%;background:#26a69a\"></div></div><div>{severity_counts['low']}</div></div>
      <div class=\"bar-row\"><div>Info</div><div class=\"bar-rail\"><div class=\"bar-fill\" style=\"width:{_pct(severity_counts['info'], sev_total)}%;background:#90a4ae\"></div></div><div>{severity_counts['info']}</div></div>
    </div>
    <br/>
    <h3>Confidence distribution</h3>
    <div class=\"bars\">
      <div class=\"bar-row\"><div>High confidence</div><div class=\"bar-rail\"><div class=\"bar-fill\" style=\"width:{_pct(confidence_counts['high'], max(1, total_findings))}%;background:#2e7d32\"></div></div><div>{confidence_counts['high']}</div></div>
      <div class=\"bar-row\"><div>Medium confidence</div><div class=\"bar-rail\"><div class=\"bar-fill\" style=\"width:{_pct(confidence_counts['medium'], max(1, total_findings))}%;background:#0277bd\"></div></div><div>{confidence_counts['medium']}</div></div>
      <div class=\"bar-row\"><div>Low confidence</div><div class=\"bar-rail\"><div class=\"bar-fill\" style=\"width:{_pct(confidence_counts['low'], max(1, total_findings))}%;background:#6a1b9a\"></div></div><div>{confidence_counts['low']}</div></div>
    </div>
  </div>

  <div class=\"card\">
    <h2>Additional analytics</h2>
    <h3>Exploitability distribution</h3>
    <div class=\"bars\">
      <div class=\"bar-row\"><div>EASY</div><div class=\"bar-rail\"><div class=\"bar-fill\" style=\"width:{_pct(exploitability_counts['EASY'], max(1, total_findings))}%;background:#8e24aa\"></div></div><div>{exploitability_counts['EASY']}</div></div>
      <div class=\"bar-row\"><div>MEDIUM</div><div class=\"bar-rail\"><div class=\"bar-fill\" style=\"width:{_pct(exploitability_counts['MEDIUM'], max(1, total_findings))}%;background:#ef5350\"></div></div><div>{exploitability_counts['MEDIUM']}</div></div>
      <div class=\"bar-row\"><div>HARD</div><div class=\"bar-rail\"><div class=\"bar-fill\" style=\"width:{_pct(exploitability_counts['HARD'], max(1, total_findings))}%;background:#26a69a\"></div></div><div>{exploitability_counts['HARD']}</div></div>
    </div>
    <br/>
    <h3>File hotspots (where most findings appear)</h3>
    {
      '<table><thead><tr><th>File</th><th>Findings</th><th>Relative density</th></tr></thead><tbody>' + hotspot_rows + '</tbody></table>'
      if hotspot_rows
      else '<p>No file hotspots. No findings detected.</p>'
    }
  </div>

  <div class=\"card\">
    <h2>Top priorities to fix first</h2>
    {
      '<table><thead><tr><th>Rule</th><th>Occurrences</th><th>Recommended fix</th></tr></thead><tbody>' + top_rules_rows + '</tbody></table>'
      if top_rules_rows
      else '<p>No findings. Nothing to prioritize.</p>'
    }
  </div>

  <div class=\"card\">
    <h2>Detectors run</h2>
    {
      '<table><thead><tr><th>ID</th><th>Detector</th><th>Stage</th><th>Method</th></tr></thead><tbody>' + detectors_table_rows + '</tbody></table>'
      if detectors_table_rows
      else '<ul>' + (detectors_html or '<li>None</li>') + '</ul>'
    }
  </div>

  <div class=\"card\">
    <h2>Executive summary table</h2>
    <table>
      <thead><tr><th>Severity</th><th>Count</th><th>Distribution</th><th>Percent</th></tr></thead>
      <tbody>
        <tr><td>Critical</td><td>{severity_counts['critical']}</td><td class=\"mono\">{_bar(severity_counts['critical'], sev_total)}</td><td>{_pct(severity_counts['critical'], sev_total)}%</td></tr>
        <tr><td>High</td><td>{severity_counts['high']}</td><td class=\"mono\">{_bar(severity_counts['high'], sev_total)}</td><td>{_pct(severity_counts['high'], sev_total)}%</td></tr>
        <tr><td>Medium</td><td>{severity_counts['medium']}</td><td class=\"mono\">{_bar(severity_counts['medium'], sev_total)}</td><td>{_pct(severity_counts['medium'], sev_total)}%</td></tr>
        <tr><td>Low</td><td>{severity_counts['low']}</td><td class=\"mono\">{_bar(severity_counts['low'], sev_total)}</td><td>{_pct(severity_counts['low'], sev_total)}%</td></tr>
        <tr><td>Info</td><td>{severity_counts['info']}</td><td class=\"mono\">{_bar(severity_counts['info'], sev_total)}</td><td>{_pct(severity_counts['info'], sev_total)}%</td></tr>
      </tbody>
    </table>
  </div>

  <div class=\"card\">
    <h2>Runtime issues</h2>
    <table>
      <thead><tr><th>Type</th><th>Target</th><th>Message</th></tr></thead>
      <tbody>{errors or '<tr><td colspan="3">None</td></tr>'}</tbody>
    </table>
  </div>

  <div class=\"card\">
    <h2>Error diagnostics</h2>
    <table>
      <thead><tr><th>Type</th><th>Target</th><th>Likely cause</th><th>Fix</th></tr></thead>
      <tbody>{diagnostics_rows or '<tr><td colspan="4">None</td></tr>'}</tbody>
    </table>
  </div>

  <div class=\"card\">
    <h2>Attack paths</h2>
    {attack_paths_html or '<p>None</p>'}
  </div>

  <div class=\"card\">
    <h2>Findings</h2>
    <table>
      <thead><tr><th>Detector</th><th>ID</th><th>Severity</th><th>File</th><th>Line</th><th>Confidence</th><th>Exploitability</th><th>Title</th><th>Why</th></tr></thead>
      <tbody>{''.join(rows)}</tbody>
    </table>
  </div>

  <div class=\"card\">
    <h2>Detailed findings</h2>
    {''.join(details) or '<p>No findings.</p>'}
  </div>
</body>
</html>
"""

    output.write_text(html, encoding="utf-8")
