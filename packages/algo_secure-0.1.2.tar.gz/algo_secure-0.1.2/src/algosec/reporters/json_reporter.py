from __future__ import annotations

import json
from pathlib import Path

from algosec.detector_catalog import detector_name
from algosec.models import ScanResult


def _to_dict(result: ScanResult) -> dict:
    return {
        "target": str(result.target),
        "analyzed_files": [str(p) for p in result.analyzed_files],
        "errors": result.errors,
        "metadata": result.metadata,
        "findings": [
            {
                "rule_id": f.rule_id,
                "detector_name": detector_name(f.rule_id),
                "title": f.title,
                "severity": f.severity.value,
                "message": f.message,
                "confidence": f.confidence,
                "tags": f.tags,
                "file": str(f.location.file_path),
                "line": f.location.line,
                "evidence": f.evidence,
            }
            for f in result.findings
        ],
    }


def write_json(result: ScanResult, output: Path) -> None:
    output.write_text(json.dumps(_to_dict(result), indent=2), encoding="utf-8")
