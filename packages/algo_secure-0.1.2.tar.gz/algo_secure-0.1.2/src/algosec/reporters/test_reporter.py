from __future__ import annotations

import json
from pathlib import Path

from rich import box
from rich.console import Console
from rich.table import Table

from algosec.testing.models import PyTealTestReport
from algosec.testing.pyteal_test_runner import report_to_dict


def write_test_json(report: PyTealTestReport, output: Path) -> None:
    output.write_text(json.dumps(report_to_dict(report), indent=2), encoding="utf-8")


def write_test_markdown(report: PyTealTestReport, output: Path) -> None:
    lines: list[str] = []
    lines.append("# A+ SEC PyTeal Test Lab Report")
    lines.append("")
    lines.append(f"Target: **{report.target}**")
    lines.append("")
    lines.append("## Summary")
    lines.append("")
    lines.append("| Contracts | Cases | Passed | Failed | Skipped | Engine error contracts |")
    lines.append("|---:|---:|---:|---:|---:|---:|")
    lines.append(
        f"| {report.total_contracts} | {report.total_cases} | {report.passed_cases} | {report.failed_cases} | {report.skipped_cases} | {report.contracts_with_engine_errors} |"
    )
    lines.append("")

    failed = [c for c in report.cases if c.status == "failed"]
    lines.append("## Failed cases")
    lines.append("")
    if not failed:
        lines.append("No failed cases.")
    else:
        lines.append("| Case | Contract | Error Type | Expected | Observed | Explanation |")
        lines.append("|---|---|---|---|---|---|")
        for c in failed:
            lines.append(
                f"| {c.case_id} | {c.contract} | {c.error_type or '-'} | {', '.join(c.expected_rules) or '-'} | {', '.join(c.observed_rules) or '-'} | {c.explanation} |"
            )

    lines.append("")
    lines.append("## All cases")
    lines.append("")
    lines.append("| Case | Status | Contract | Findings | Errors |")
    lines.append("|---|---|---|---:|---:|")
    for c in report.cases:
        lines.append(f"| {c.case_id} | {c.status} | {c.contract} | {c.findings_count} | {c.errors_count} |")

    output.write_text("\n".join(lines) + "\n", encoding="utf-8")


def render_test_console(report: PyTealTestReport) -> None:
    console = Console()

    summary = Table(box=box.SIMPLE_HEAVY, header_style="bold cyan")
    summary.add_column("Contracts", justify="right")
    summary.add_column("Cases", justify="right")
    summary.add_column("Passed", justify="right")
    summary.add_column("Failed", justify="right")
    summary.add_column("Skipped", justify="right")
    summary.add_column("EngineErrContracts", justify="right")
    summary.add_row(
        str(report.total_contracts),
        str(report.total_cases),
        str(report.passed_cases),
        str(report.failed_cases),
        str(report.skipped_cases),
        str(report.contracts_with_engine_errors),
    )
    console.print("[bold cyan]A+ SEC PyTeal Test Lab[/bold cyan]")
    console.print(summary)

    failed = [c for c in report.cases if c.status == "failed"]
    if not failed:
        console.print("[bold green]All test cases passed.[/bold green]")
        return

    table = Table(title="Failed Cases", box=box.SIMPLE, header_style="bold magenta")
    table.add_column("Case")
    table.add_column("Contract")
    table.add_column("Type")
    table.add_column("Expected")
    table.add_column("Observed")
    table.add_column("Explanation")

    for c in failed:
        table.add_row(
            c.case_id,
            c.contract,
            c.error_type or "-",
            ", ".join(c.expected_rules) or "-",
            ", ".join(c.observed_rules) or "-",
            c.explanation,
        )

    console.print(table)
