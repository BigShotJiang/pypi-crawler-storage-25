from __future__ import annotations

from dataclasses import dataclass

from algosec.analysis.teal_parser import TealInstruction, TealProgram
from algosec.models import Finding, Location, Severity
from algosec.rules.base import Rule, RuleContext


@dataclass(slots=True)
class CompareGuard:
    left: str
    op: str
    right: str
    line_no: int


def _token_from_instruction(ins: TealInstruction) -> str:
    if ins.opcode == "txn" and ins.args:
        return f"txn:{ins.args[0].lower()}"
    if ins.opcode == "gtxn" and len(ins.args) >= 2:
        return f"gtxn:{ins.args[1].lower()}"
    if ins.opcode == "global" and ins.args:
        return f"global:{ins.args[0].lower()}"
    if ins.opcode == "int" and ins.args:
        return f"int:{ins.args[0].lower()}"
    if ins.opcode == "byte" and ins.args:
        return f"byte:{' '.join(ins.args).lower()}"
    return f"op:{ins.opcode}"


def _extract_guards(program: TealProgram) -> list[CompareGuard]:
    stack: list[tuple[str, int]] = []
    guards: list[CompareGuard] = []

    for ins in program.instructions:
        op = ins.opcode
        if op in {"txn", "gtxn", "global", "int", "byte"}:
            stack.append((_token_from_instruction(ins), ins.line_no))
            continue

        if op in {"==", "!=", ">", "<", ">=", "<="} and len(stack) >= 2:
            right, _ = stack.pop()
            left, left_line = stack.pop()
            stack.append((f"cmp({left}{op}{right})", left_line))
            guards.append(CompareGuard(left=left, op=op, right=right, line_no=ins.line_no))
            continue

        if op == "assert" and stack:
            stack.pop()

        if op in {"return", "err", "b", "bnz", "bz"}:
            stack.clear()

    return guards


def _has_guard(guards: list[CompareGuard], lhs: str, rhs: str) -> bool:
    for guard in guards:
        pair = {guard.left, guard.right}
        if guard.op == "==" and {lhs, rhs}.issubset(pair):
            return True
    return False


def _first_line_for_txn_field(program: TealProgram, field: str) -> int | None:
    for ins in program.instructions:
        if ins.opcode == "txn" and ins.args and ins.args[0].lower() == field:
            return ins.line_no
    return None


def _first_line_for_oncompletion_reference(program: TealProgram) -> int | None:
    for ins in program.instructions:
        if ins.opcode == "txn" and ins.args and ins.args[0].lower() == "oncompletion":
            return ins.line_no
        if ins.opcode == "int" and ins.args and ins.args[0].lower() in {"updateapplication", "deleteapplication"}:
            return ins.line_no
    return None


class RekeyGuardRule(Rule):
    rule_id = "ALG001"

    def check(self, context: RuleContext) -> list[Finding]:
        line = _first_line_for_txn_field(context.program, "rekeyto")
        if line is None:
            return []

        guards = _extract_guards(context.program)
        if _has_guard(guards, "txn:rekeyto", "global:zeroaddress"):
            return []

        return [
            Finding(
                rule_id=self.rule_id,
                title="Missing RekeyTo safety guard",
                severity=Severity.HIGH,
                message="Program does not prove `Txn RekeyTo == Global ZeroAddress`.",
                location=Location(file_path=context.program.path, line=line),
                confidence=0.72,
                tags=["account-takeover", "rekey"],
            )
        ]


class CloseRemainderGuardRule(Rule):
    rule_id = "ALG002"

    def check(self, context: RuleContext) -> list[Finding]:
        line = _first_line_for_txn_field(context.program, "closeremainderto")
        if line is None:
            return []

        guards = _extract_guards(context.program)
        if _has_guard(guards, "txn:closeremainderto", "global:zeroaddress"):
            return []

        return [
            Finding(
                rule_id=self.rule_id,
                title="Missing CloseRemainderTo safety guard",
                severity=Severity.HIGH,
                message="Program does not prove `Txn CloseRemainderTo == Global ZeroAddress`.",
                location=Location(file_path=context.program.path, line=line),
                confidence=0.7,
                tags=["fund-drain", "close-remainder"],
            )
        ]


class UpdateDeleteAuthRule(Rule):
    rule_id = "ALG003"

    def check(self, context: RuleContext) -> list[Finding]:
        guards = _extract_guards(context.program)
        has_creator_check = _has_guard(guards, "txn:sender", "global:creatoraddress")

        op_tokens = {
            tok
            for g in guards
            for tok in (g.left, g.right)
            if tok.startswith("int:") or tok.startswith("txn:oncompletion")
        }
        mentions_update_delete = any(
            tok in {"int:updateapplication", "int:deleteapplication", "txn:oncompletion"}
            for tok in op_tokens
        )

        if not mentions_update_delete:
            return []

        if has_creator_check:
            return []

        line = _first_line_for_oncompletion_reference(context.program) or 1

        return [
            Finding(
                rule_id=self.rule_id,
                title="Potentially unguarded update/delete path",
                severity=Severity.CRITICAL,
                message="Contract references update/delete completion but no sender==creator guard was found.",
                location=Location(file_path=context.program.path, line=line),
                confidence=0.63,
                tags=["upgrade", "privilege"],
            )
        ]


DEFAULT_TEAL_RULES: list[Rule] = [
    RekeyGuardRule(),
    CloseRemainderGuardRule(),
    UpdateDeleteAuthRule(),
]
