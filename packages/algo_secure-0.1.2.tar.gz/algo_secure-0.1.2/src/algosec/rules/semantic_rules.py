from __future__ import annotations

from algosec.analysis.teal_semantics import SemanticModel, analyze_semantics
from algosec.models import Finding, Location, Severity
from algosec.rules.base import Rule, RuleContext


def _get_semantics(context: RuleContext) -> SemanticModel:
    return analyze_semantics(context.program)


class InnerTxnReceiverTaintRule(Rule):
    rule_id = "ALG105"

    def check(self, context: RuleContext) -> list[Finding]:
        model = _get_semantics(context)
        findings: list[Finding] = []

        for assign in model.inner_field_assignments:
            if assign.field not in {"receiver", "assetreceiver"}:
                continue
            if not assign.source.tainted:
                continue

            if context.contract_summary.guards_sender_creator:
                continue

            findings.append(
                Finding(
                    rule_id=self.rule_id,
                    title="Tainted value reaches inner transfer receiver",
                    severity=Severity.CRITICAL,
                    message=(
                        "Untrusted transaction-controlled data flows into `itxn_field "
                        f"{assign.field}` without creator-authorization guard."
                    ),
                    location=Location(file_path=context.program.path, line=assign.line_no),
                    confidence=0.8,
                    tags=["taint", "inner-txn", "fund-redirection"],
                    evidence={
                        "source": assign.source.value,
                        "source_line": str(assign.source.line_no),
                        "sink": assign.field,
                        "fix": "Gate sensitive paths with sender/role checks and sanitize receiver derivation.",
                    },
                )
            )

        return findings


class UnboundedAppArgsReadRule(Rule):
    rule_id = "ALG106"

    def check(self, context: RuleContext) -> list[Finding]:
        model = _get_semantics(context)
        if not model.app_args_reads:
            return []

        max_idx = max((idx for _, idx in model.app_args_reads if idx is not None), default=0)
        required = max_idx + 1

        if model.has_num_app_args_guard(required):
            return []

        line = model.app_args_reads[0][0]
        return [
            Finding(
                rule_id=self.rule_id,
                title="ApplicationArgs read without bounds guard",
                severity=Severity.HIGH,
                message=(
                    f"Reads `txna ApplicationArgs` up to index {max_idx} but no asserted "
                    "`Txn NumAppArgs` bound check was detected."
                ),
                location=Location(file_path=context.program.path, line=line),
                confidence=0.74,
                tags=["input-validation", "bounds", "semantic"],
                evidence={
                    "required_min_num_args": str(required),
                    "fix": "Assert `txn NumAppArgs >= required` before reading ApplicationArgs indices.",
                },
            )
        ]


SEMANTIC_RULES: list[Rule] = [
    InnerTxnReceiverTaintRule(),
    UnboundedAppArgsReadRule(),
]
