from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from algosec.analysis.contract_summary import ContractSummary
from algosec.analysis.teal_parser import TealProgram
from algosec.models import Finding


@dataclass(slots=True)
class RuleContext:
    program: TealProgram
    contract_summary: ContractSummary
    project_metadata: dict[str, Any]


class Rule:
    rule_id: str

    def check(self, context: RuleContext) -> list[Finding]:
        raise NotImplementedError
