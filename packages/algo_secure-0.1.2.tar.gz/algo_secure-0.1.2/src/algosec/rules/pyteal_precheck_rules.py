from __future__ import annotations

import ast
import re
from dataclasses import dataclass
from pathlib import Path

from algosec.models import Finding, Location, Severity


@dataclass(slots=True)
class _PrecheckState:
    has_sender_creator_guard: bool = False
    has_rekey_guard: bool = False
    has_close_remainder_guard: bool = False
    has_asset_close_guard: bool = False
    update_delete_lines: list[int] = None  # type: ignore[assignment]
    rekey_lines: list[int] = None  # type: ignore[assignment]
    close_remainder_lines: list[int] = None  # type: ignore[assignment]
    asset_close_lines: list[int] = None  # type: ignore[assignment]
    num_app_args_guard_max: int = 0
    app_arg_read_lines: list[tuple[int, int]] = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        self.update_delete_lines = []
        self.rekey_lines = []
        self.close_remainder_lines = []
        self.asset_close_lines = []
        self.app_arg_read_lines = []


def _call_name(expr: ast.AST) -> str | None:
    if not isinstance(expr, ast.Call):
        return None

    func = expr.func
    if isinstance(func, ast.Name):
        return func.id

    parts: list[str] = []
    while isinstance(func, ast.Attribute):
        parts.append(func.attr)
        func = func.value

    if isinstance(func, ast.Name):
        parts.append(func.id)
        parts.reverse()
        return ".".join(parts)

    return None


def _expr_name(expr: ast.AST) -> str | None:
    call = _call_name(expr)
    if call:
        return call

    if isinstance(expr, ast.Name):
        return expr.id

    if isinstance(expr, ast.Attribute):
        parts: list[str] = []
        node: ast.AST = expr
        while isinstance(node, ast.Attribute):
            parts.append(node.attr)
            node = node.value
        if isinstance(node, ast.Name):
            parts.append(node.id)
            parts.reverse()
            return ".".join(parts)

    return None


def _is_compare_pair(cmp: ast.Compare, left_name: str, right_name: str) -> bool:
    if len(cmp.ops) != 1 or not isinstance(cmp.ops[0], ast.Eq) or len(cmp.comparators) != 1:
        return False

    left = _expr_name(cmp.left)
    right = _expr_name(cmp.comparators[0])
    pair = {left, right}
    return {left_name, right_name}.issubset(pair)


def _update_num_app_args_guard(cmp: ast.Compare, state: _PrecheckState) -> None:
    if len(cmp.ops) != 1 or len(cmp.comparators) != 1:
        return

    def is_len_app_args(node: ast.AST) -> bool:
        if not isinstance(node, ast.Call):
            return False
        if isinstance(node.func, ast.Name) and node.func.id == "Len":
            if len(node.args) != 1:
                return False
            arg = node.args[0]
            return isinstance(arg, ast.Attribute) and isinstance(arg.value, ast.Name) and arg.value.id == "Txn" and arg.attr == "application_args"

        if isinstance(node.func, ast.Attribute) and node.func.attr == "length":
            recv = node.func.value
            return isinstance(recv, ast.Attribute) and isinstance(recv.value, ast.Name) and recv.value.id == "Txn" and recv.attr == "application_args"

        return False

    left_call = _expr_name(cmp.left)
    right = cmp.comparators[0]

    def lit_int(node: ast.AST) -> int | None:
        if isinstance(node, ast.Constant) and isinstance(node.value, int):
            return int(node.value)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "Int" and len(node.args) == 1:
            arg0 = node.args[0]
            if isinstance(arg0, ast.Constant) and isinstance(arg0.value, int):
                return int(arg0.value)
        return None

    right_value = lit_int(right)
    if (left_call == "Txn.num_app_args" or is_len_app_args(cmp.left)) and right_value is not None:
        value = right_value

        op = cmp.ops[0]
        guarded = 0
        if isinstance(op, ast.GtE):
            guarded = value
        elif isinstance(op, ast.Gt):
            guarded = value + 1
        elif isinstance(op, ast.Eq):
            guarded = value

        state.num_app_args_guard_max = max(state.num_app_args_guard_max, guarded)
        return

    right_call = _expr_name(right)
    left = cmp.left
    left_value = lit_int(left)
    if (right_call == "Txn.num_app_args" or is_len_app_args(right)) and left_value is not None:
        value = left_value

        op = cmp.ops[0]
        guarded = 0
        if isinstance(op, ast.LtE):
            guarded = value
        elif isinstance(op, ast.Lt):
            guarded = value - 1
        elif isinstance(op, ast.Eq):
            guarded = value

        state.num_app_args_guard_max = max(state.num_app_args_guard_max, guarded)


def _scan_tree(tree: ast.AST) -> _PrecheckState:
    state = _PrecheckState()

    for node in ast.walk(tree):
        if isinstance(node, ast.Compare):
            if _is_compare_pair(node, "Txn.sender", "Global.creator_address"):
                state.has_sender_creator_guard = True

            if _is_compare_pair(node, "Txn.rekey_to", "Global.zero_address"):
                state.has_rekey_guard = True

            if _is_compare_pair(node, "Txn.close_remainder_to", "Global.zero_address"):
                state.has_close_remainder_guard = True

            if _is_compare_pair(node, "Txn.asset_close_to", "Global.zero_address"):
                state.has_asset_close_guard = True

            if len(node.comparators) == 1 and len(node.ops) == 1 and isinstance(node.ops[0], ast.Eq):
                left = _expr_name(node.left)
                right = _expr_name(node.comparators[0])
                pair = {left, right}
                if "Txn.on_completion" in pair and (
                    "OnComplete.UpdateApplication" in pair or "OnComplete.DeleteApplication" in pair
                ):
                    state.update_delete_lines.append(getattr(node, "lineno", 1))

            _update_num_app_args_guard(node, state)

        if isinstance(node, ast.Call):
            call = _call_name(node)
            line = getattr(node, "lineno", 1)
            if call == "Txn.rekey_to":
                state.rekey_lines.append(line)
            elif call == "Txn.close_remainder_to":
                state.close_remainder_lines.append(line)
            elif call == "Txn.asset_close_to":
                state.asset_close_lines.append(line)

        if isinstance(node, ast.Subscript):
            if isinstance(node.value, ast.Attribute) and isinstance(node.value.value, ast.Name):
                if node.value.value.id == "Txn" and node.value.attr == "application_args":
                    idx = None
                    slice_node = node.slice
                    if isinstance(slice_node, ast.Constant) and isinstance(slice_node.value, int):
                        idx = int(slice_node.value)
                    if idx is not None:
                        state.app_arg_read_lines.append((getattr(node, "lineno", 1), idx))

    return state


def run_pyteal_prechecks(source: Path) -> list[Finding]:
    text = source.read_text(encoding="utf-8")
    tree = ast.parse(text, filename=str(source))
    state = _scan_tree(tree)

    findings: list[Finding] = []

    if state.update_delete_lines and not state.has_sender_creator_guard:
        findings.append(
            Finding(
                rule_id="ALG401",
                title="PyTeal update/delete path without creator authorization",
                severity=Severity.CRITICAL,
                message="PyTeal compares `Txn.on_completion()` with update/delete without a `Txn.sender()==Global.creator_address()` authorization check.",
                location=Location(file_path=source, line=min(state.update_delete_lines)),
                confidence=0.78,
                tags=["pyteal", "auth", "upgrade"],
                evidence={
                    "fix": "Add creator/role authorization guard before allowing update/delete paths.",
                },
            )
        )

    if state.rekey_lines and not state.has_rekey_guard:
        findings.append(
            Finding(
                rule_id="ALG402",
                title="PyTeal missing RekeyTo zero-address guard",
                severity=Severity.HIGH,
                message="Uses `Txn.rekey_to()` without matching `Global.zero_address()` equality guard.",
                location=Location(file_path=source, line=min(state.rekey_lines)),
                confidence=0.73,
                tags=["pyteal", "rekey"],
                evidence={"fix": "Assert `Txn.rekey_to() == Global.zero_address()` early."},
            )
        )

    if state.close_remainder_lines and not state.has_close_remainder_guard:
        findings.append(
            Finding(
                rule_id="ALG403",
                title="PyTeal missing CloseRemainderTo zero-address guard",
                severity=Severity.HIGH,
                message="Uses `Txn.close_remainder_to()` without matching `Global.zero_address()` equality guard.",
                location=Location(file_path=source, line=min(state.close_remainder_lines)),
                confidence=0.72,
                tags=["pyteal", "close-remainder"],
                evidence={"fix": "Assert `Txn.close_remainder_to() == Global.zero_address()` early."},
            )
        )

    if state.asset_close_lines and not state.has_asset_close_guard:
        findings.append(
            Finding(
                rule_id="ALG404",
                title="PyTeal missing AssetCloseTo zero-address guard",
                severity=Severity.HIGH,
                message="Uses `Txn.asset_close_to()` without matching `Global.zero_address()` equality guard.",
                location=Location(file_path=source, line=min(state.asset_close_lines)),
                confidence=0.7,
                tags=["pyteal", "asset-close"],
                evidence={"fix": "Assert `Txn.asset_close_to() == Global.zero_address()` early."},
            )
        )

    if state.app_arg_read_lines:
        max_idx = max(idx for _, idx in state.app_arg_read_lines)
        required = max_idx + 1
        if state.num_app_args_guard_max < required:
            findings.append(
                Finding(
                    rule_id="ALG405",
                    title="PyTeal ApplicationArgs read without explicit bound check",
                    severity=Severity.MEDIUM,
                    message=(
                            f"Reads `Txn.application_args[{max_idx}]` but no application-args length guard for at least {required} args was found."
                    ),
                    location=Location(file_path=source, line=min(line for line, _ in state.app_arg_read_lines)),
                    confidence=0.71,
                    tags=["pyteal", "input-validation", "bounds"],
                        evidence={"fix": "Add `Assert(Txn.application_args.length() >= required_count)` before reading args."},
                )
            )

    if _borrow_without_collateral_ratio(text):
        findings.append(
            Finding(
                rule_id="ALG406",
                title="Borrow path lacks collateral ratio / credit limit check",
                severity=Severity.HIGH,
                message=(
                    "Borrow logic appears to authorize borrowing with only minimal positive collateral checks "
                    "(for example `dep > 0`) and no explicit collateral-ratio or borrow-cap enforcement."
                ),
                location=Location(file_path=source, line=_line_of(text, "borrow = Seq(") or 1),
                confidence=0.76,
                tags=["pyteal", "defi", "lending", "risk-model"],
                evidence={
                    "fix": "Enforce explicit ratio/cap checks (for example `Assert(borrow_amt * 100 <= dep * LTV_BPS)`).",
                },
            )
        )

    if _deposit_without_payment_validation(text):
        findings.append(
            Finding(
                rule_id="ALG407",
                title="Deposit accounting without robust payment linkage checks",
                severity=Severity.HIGH,
                message=(
                    "Deposit accounting uses grouped payment amount but does not show robust sender/receiver/amount linkage "
                    "assertions tying payment txn to the depositor and contract flow."
                ),
                location=Location(file_path=source, line=_line_of(text, "deposit = Seq(") or 1),
                confidence=0.74,
                tags=["pyteal", "defi", "accounting", "atomic-group"],
                evidence={
                    "fix": "Add strict Gtxn linkage checks (type, sender, receiver/app address, amount consistency, and expected group index).",
                },
            )
        )

    return findings


def _line_of(text: str, needle: str) -> int | None:
    for idx, line in enumerate(text.splitlines(), start=1):
        if needle in line:
            return idx
    return None


def _borrow_without_collateral_ratio(text: str) -> bool:
    block = _extract_named_seq_block(text, "borrow")
    if not block:
        return False

    has_borrow_amt = "Txn.application_args[1]" in block or "Btoi(" in block
    has_dep_check = "dep" in block and "Assert(dep" in block

    ratio_patterns = [
        r"Assert\s*\(\s*.*amt.*<=.*dep.*\)",
        r"Assert\s*\(\s*.*borrow.*<=.*dep.*\)",
        r"LTV|ltv|collateral|ratio|health",
    ]
    has_ratio = any(re.search(p, block) for p in ratio_patterns)

    return has_borrow_amt and has_dep_check and not has_ratio


def _deposit_without_payment_validation(text: str) -> bool:
    block = _extract_named_seq_block(text, "deposit")
    if not block:
        return False

    uses_group_payment = "Gtxn[0].amount" in block

    # Heuristic: require at least one sender check and one receiver/type guard on the grouped payment.
    has_sender_check = bool(re.search(r"Assert\s*\(\s*.*Gtxn\[0\]\.sender\(\)", block))
    has_receiver_or_type_check = bool(
        re.search(r"Assert\s*\(\s*.*Gtxn\[0\]\.receiver\(\)|Assert\s*\(\s*.*Gtxn\[0\]\.type_enum\(\)", block)
    )

    return uses_group_payment and not (has_sender_check and has_receiver_or_type_check)


def _extract_named_seq_block(text: str, name: str) -> str | None:
    lines = text.splitlines()
    start_idx: int | None = None
    for i, line in enumerate(lines):
        if f"{name} = Seq([" in line:
            start_idx = i
            break

    if start_idx is None:
        return None

    block_lines: list[str] = []
    for line in lines[start_idx + 1 :]:
        if line.strip() == "])":
            break
        block_lines.append(line)

    return "\n".join(block_lines)
