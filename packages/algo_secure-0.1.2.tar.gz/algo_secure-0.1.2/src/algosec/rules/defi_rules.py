from __future__ import annotations

from algosec.analysis.contract_summary import ContractSummary
from algosec.models import Finding, Location, Severity
from algosec.rules.base import Rule, RuleContext


def _summary(context: RuleContext) -> ContractSummary:
    return context.contract_summary


def _first_line(context: RuleContext, *, opcode: str, arg0: str | None = None) -> int | None:
    for ins in context.program.instructions:
        if ins.opcode != opcode:
            continue
        if arg0 is None:
            return ins.line_no
        if ins.args and ins.args[0].lower() == arg0:
            return ins.line_no
    return None


class GroupSizeValidationRule(Rule):
    rule_id = "ALG101"

    def check(self, context: RuleContext) -> list[Finding]:
        summary = _summary(context)
        if not summary.reads_group_txn:
            return []
        if summary.validates_group_size:
            return []

        line = _first_line(context, opcode="gtxn") or 1
        return [
            Finding(
                rule_id=self.rule_id,
                title="Group transaction access without group-size validation",
                severity=Severity.HIGH,
                message="Contract reads `Gtxn` values but no `Global GroupSize` validation was detected.",
                location=Location(file_path=context.program.path, line=line),
                confidence=0.77,
                tags=["defi", "atomic-group", "workflow"],
            )
        ]


class InnerTxnFeeRule(Rule):
    rule_id = "ALG102"

    def check(self, context: RuleContext) -> list[Finding]:
        summary = _summary(context)
        if not summary.has_inner_txn:
            return []

        has_fee_field = any(
            ins.opcode == "itxn_field" and ins.args and ins.args[0].lower() == "fee"
            for ins in context.program.instructions
        )
        if has_fee_field:
            return []

        line = _first_line(context, opcode="itxn_begin") or _first_line(context, opcode="inner_txn_begin") or 1

        return [
            Finding(
                rule_id=self.rule_id,
                title="Inner transaction fee field not explicitly set",
                severity=Severity.MEDIUM,
                message="Detected inner transactions without explicit `itxn_field Fee` assignment.",
                location=Location(file_path=context.program.path, line=line),
                confidence=0.66,
                tags=["defi", "fee-accounting", "inner-txn"],
            )
        ]


class StateWriteAuthRule(Rule):
    rule_id = "ALG103"

    def check(self, context: RuleContext) -> list[Finding]:
        summary = _summary(context)
        if not (summary.writes_global_state or summary.writes_local_state):
            return []

        if summary.guards_sender_creator:
            return []

        line = _first_line(context, opcode="app_global_put") or _first_line(context, opcode="app_local_put") or 1

        return [
            Finding(
                rule_id=self.rule_id,
                title="State mutation without clear sender/creator authorization",
                severity=Severity.HIGH,
                message="Contract mutates state but no sender-to-creator authorization pattern was detected.",
                location=Location(file_path=context.program.path, line=line),
                confidence=0.64,
                tags=["defi", "authorization", "state"],
            )
        ]


class AssetCloseGuardRule(Rule):
    rule_id = "ALG104"

    def check(self, context: RuleContext) -> list[Finding]:
        summary = _summary(context)
        has_asset_close_field = any(
            ins.opcode == "txn" and ins.args and ins.args[0].lower() == "assetcloseto"
            for ins in context.program.instructions
        )
        if not has_asset_close_field:
            return []

        if summary.guards_asset_close:
            return []

        line = _first_line(context, opcode="txn", arg0="assetcloseto") or 1

        return [
            Finding(
                rule_id=self.rule_id,
                title="AssetCloseTo used without a proven zero-address guard",
                severity=Severity.HIGH,
                message="Contract references `Txn AssetCloseTo` and may miss `Global ZeroAddress` guard.",
                location=Location(file_path=context.program.path, line=line),
                confidence=0.7,
                tags=["asa", "asset-close", "defi"],
            )
        ]


DEFI_RULES: list[Rule] = [
    GroupSizeValidationRule(),
    InnerTxnFeeRule(),
    StateWriteAuthRule(),
    AssetCloseGuardRule(),
]
