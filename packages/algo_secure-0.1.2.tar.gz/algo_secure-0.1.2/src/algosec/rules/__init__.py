"""Rule definitions for Algosec."""
