from __future__ import annotations

from pathlib import Path
from tempfile import NamedTemporaryFile

from algosec.engine import scan_path
from algosec.models import ScanResult
from algosec.scoring import compute_security_score
from algosec.serialization import scan_result_to_dict


def run_scan_for_target(target: Path) -> ScanResult:
    result = scan_path(target)
    result.metadata["score"] = compute_security_score(result)
    return result


def run_scan_for_source(*, source_code: str, suffix: str = ".py") -> ScanResult:
    with NamedTemporaryFile("w", suffix=suffix, encoding="utf-8", delete=True) as handle:
        handle.write(source_code)
        handle.flush()
        result = run_scan_for_target(Path(handle.name))
    return result


def run_scan_as_dict(*, target: Path | None = None, source_code: str | None = None, suffix: str = ".py") -> dict:
    if source_code is not None:
        result = run_scan_for_source(source_code=source_code, suffix=suffix)
    elif target is not None:
        result = run_scan_for_target(target)
    else:
        raise ValueError("Either target or source_code must be provided")

    return scan_result_to_dict(result)
