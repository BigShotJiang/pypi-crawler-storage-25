from __future__ import annotations

from pathlib import Path

from algosec.connectors.indexer_client import IndexerClient
from algosec.models import Finding, Location, ScanResult, Severity
from algosec.scanners.transaction_scanner import TransactionScanner
from algosec.scoring import compute_security_score
from algosec.serialization import scan_result_to_dict


def analyze_transaction_payload(payload: dict) -> ScanResult:
    txid = str(payload.get("id", "simulated"))
    result = ScanResult(target=Path(f"tx:{txid}"))

    rekey_to = payload.get("rekey-to")
    close_to = payload.get("close-remainder-to")
    fee = int(payload.get("fee", 0) or 0)

    if rekey_to:
        result.findings.append(
            Finding(
                rule_id="ALG311",
                title="Transaction contains rekey-to",
                severity=Severity.HIGH,
                message=f"Transaction {txid} sets rekey-to; review signer delegation intent.",
                location=Location(file_path=Path(f"tx:{txid}"), line=None),
                confidence=0.94,
                tags=["transaction", "rekey"],
            )
        )

    if close_to:
        result.findings.append(
            Finding(
                rule_id="ALG312",
                title="Transaction closes remainder",
                severity=Severity.HIGH,
                message=f"Transaction {txid} includes close remainder destination.",
                location=Location(file_path=Path(f"tx:{txid}"), line=None),
                confidence=0.9,
                tags=["transaction", "close-remainder"],
            )
        )

    axfer = payload.get("asset-transfer-transaction", {})
    if isinstance(axfer, dict) and axfer.get("close-to"):
        result.findings.append(
            Finding(
                rule_id="ALG313",
                title="Asset transfer uses close-to",
                severity=Severity.HIGH,
                message=f"Transaction {txid} has asset close-to destination.",
                location=Location(file_path=Path(f"tx:{txid}"), line=None),
                confidence=0.88,
                tags=["transaction", "asset-close"],
            )
        )

    if fee > 10_000:
        result.findings.append(
            Finding(
                rule_id="ALG314",
                title="High-fee transaction",
                severity=Severity.MEDIUM,
                message=f"Transaction {txid} fee={fee} microAlgos exceeds threshold.",
                location=Location(file_path=Path(f"tx:{txid}"), line=None),
                confidence=0.8,
                tags=["transaction", "fee-anomaly"],
                evidence={"fee": str(fee)},
            )
        )

    result.metadata["score"] = compute_security_score(result)
    result.metadata["source"] = "payload"
    return result


def analyze_transactions_from_indexer(
    *,
    indexer_url: str,
    indexer_token: str = "",
    address: str | None = None,
    app_id: int | None = None,
    asset_id: int | None = None,
    limit: int = 200,
) -> ScanResult:
    scanner = TransactionScanner(IndexerClient(base_url=indexer_url, token=indexer_token))
    result = scanner.run(address=address, app_id=app_id, asset_id=asset_id, limit=limit)
    result.metadata["score"] = compute_security_score(result)
    result.metadata["source"] = "indexer"
    return result


def analyze_tx_as_dict(
    *,
    payload: dict | None = None,
    indexer_url: str | None = None,
    indexer_token: str = "",
    address: str | None = None,
    app_id: int | None = None,
    asset_id: int | None = None,
    limit: int = 200,
) -> dict:
    if payload is not None:
        result = analyze_transaction_payload(payload)
    else:
        if not indexer_url:
            raise ValueError("indexer_url is required when payload is not provided")
        result = analyze_transactions_from_indexer(
            indexer_url=indexer_url,
            indexer_token=indexer_token,
            address=address,
            app_id=app_id,
            asset_id=asset_id,
            limit=limit,
        )
    return scan_result_to_dict(result)
