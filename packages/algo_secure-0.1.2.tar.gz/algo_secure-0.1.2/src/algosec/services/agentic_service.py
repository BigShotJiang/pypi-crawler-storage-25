from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from uuid import uuid4

from algosec.agent.decision_wrapper import build_agent_explanation
from algosec.agent.explanation_export import build_explanation_markdown, build_explanation_text
from algosec.agent.session_memory import add_session_run, get_or_create_session
from algosec.models import ScanResult
from algosec.policy.engine import evaluate_policy
from algosec.services.scan_service import run_scan_for_source, run_scan_for_target
from algosec.simulator.engine import simulate_intent
from algosec.simulator.models import TxIntent


@dataclass(slots=True)
class AgenticRequest:
    objective: str
    session_id: str | None
    profile: str
    scan_target: str | None
    scan_source_code: str | None
    scan_source_suffix: str
    action: str
    sender: str | None
    receiver: str | None
    amount: int | None
    app_args: list[str]
    group_size: int | None
    payment_in_group: bool
    payment_sender: str | None
    payment_receiver: str | None
    state: dict[str, int]


def _resolve_scan(req: AgenticRequest) -> ScanResult:
    if req.scan_source_code is not None:
        return run_scan_for_source(source_code=req.scan_source_code, suffix=req.scan_source_suffix)
    if req.scan_target is not None:
        return run_scan_for_target(Path(req.scan_target))
    raise ValueError("scan_target or scan_source_code is required")


def run_agentic_workflow(req: AgenticRequest) -> dict:
    session_id = req.session_id or str(uuid4())
    session = get_or_create_session(session_id=session_id, objective=req.objective)

    plan: list[dict] = []

    plan.append({"step": "scan", "status": "in_progress"})
    scan_result = _resolve_scan(req)
    findings_count = len(scan_result.findings)
    plan[-1] = {
        "step": "scan",
        "status": "completed",
        "summary": f"Analyzed {len(scan_result.analyzed_files)} file(s), findings={findings_count}, errors={len(scan_result.errors)}",
    }

    plan.append({"step": "simulate", "status": "in_progress"})
    intent = TxIntent(
        action=req.action,
        sender=req.sender,
        receiver=req.receiver,
        amount=req.amount,
        app_args=req.app_args,
        group_size=req.group_size,
        payment_in_group=req.payment_in_group,
        payment_sender=req.payment_sender,
        payment_receiver=req.payment_receiver,
    )
    simulation = simulate_intent(intent, current_state=req.state)
    sim_signals = [
        {
            "code": s.code,
            "message": s.message,
            "severity": s.severity,
            "exploitability": s.exploitability,
        }
        for s in simulation.signals
    ]
    plan[-1] = {
        "step": "simulate",
        "status": "completed",
        "summary": f"Simulation outcome={simulation.outcome}, signals={len(sim_signals)}",
    }

    plan.append({"step": "policy", "status": "in_progress"})
    policy_eval = evaluate_policy(scan_result=scan_result, simulation_signals=sim_signals, profile=req.profile)
    explanation = build_agent_explanation(
        policy_eval=policy_eval,
        context={
            "objective": req.objective,
            "action": req.action,
            "simulation_outcome": simulation.outcome,
            "signals": sim_signals,
        },
    )
    plan[-1] = {
        "step": "policy",
        "status": "completed",
        "summary": f"Decision={policy_eval.decision.value}, risk={policy_eval.risk}, score={policy_eval.score}",
    }

    markdown = build_explanation_markdown(
        explanation=explanation,
        simulation={
            "action": simulation.action,
            "outcome": simulation.outcome,
            "signals": sim_signals,
            "state": simulation.state,
        },
    )
    text = build_explanation_text(
        explanation=explanation,
        simulation={
            "action": simulation.action,
            "outcome": simulation.outcome,
            "signals": sim_signals,
            "state": simulation.state,
        },
    )

    result = {
        "session_id": session.session_id,
        "objective": req.objective,
        "plan": plan,
        "decision": explanation,
        "scan": {
            "findings_count": findings_count,
            "errors_count": len(scan_result.errors),
            "score": scan_result.metadata.get("score", {}),
        },
        "simulation": {
            "action": simulation.action,
            "outcome": simulation.outcome,
            "signals": sim_signals,
            "state": simulation.state,
        },
        "artifacts": {
            "explanation_markdown": markdown,
            "explanation_text": text,
        },
    }

    add_session_run(session_id=session.session_id, run_payload=result)
    return result
