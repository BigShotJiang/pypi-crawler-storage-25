from __future__ import annotations

import json
from pathlib import Path

from algosec.models import Finding, ScanResult


def _finding_key(finding: Finding) -> str:
    return "|".join(
        [
            finding.rule_id,
            str(finding.location.file_path),
            str(finding.location.line or 0),
            finding.message,
        ]
    )


def filter_new_findings(result: ScanResult, baseline_json_path: Path) -> ScanResult:
    if not baseline_json_path.exists():
        result.errors.append(f"Baseline not found: {baseline_json_path}")
        return result

    try:
        payload = json.loads(baseline_json_path.read_text(encoding="utf-8"))
        baseline_findings = payload.get("findings", [])
    except Exception as exc:  # noqa: BLE001
        result.errors.append(f"Failed to read baseline: {exc}")
        return result

    baseline_keys: set[str] = set()
    for item in baseline_findings:
        key = "|".join(
            [
                str(item.get("rule_id", "")),
                str(item.get("file", "")),
                str(item.get("line", 0) or 0),
                str(item.get("message", "")),
            ]
        )
        baseline_keys.add(key)

    current = list(result.findings)
    result.findings = [finding for finding in current if _finding_key(finding) not in baseline_keys]
    result.metadata["baseline"] = {
        "baseline_path": str(baseline_json_path),
        "baseline_count": len(baseline_findings),
        "current_count": len(current),
        "new_count": len(result.findings),
    }
    return result
