from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path


@dataclass(slots=True)
class AutoFixResult:
    source: Path
    output: Path
    changed: bool
    changes: list[str]


def _indent_of(line: str) -> str:
    return line[: len(line) - len(line.lstrip(" "))]


def _inject_in_seq_block(text: str, block_name: str, lines_to_add: list[str]) -> tuple[str, bool]:
    marker = f"{block_name} = Seq(["
    line_list = text.splitlines()

    start_idx = None
    for i, line in enumerate(line_list):
        if marker in line:
            start_idx = i
            break

    if start_idx is None:
        return text, False

    end_idx = None
    for j in range(start_idx + 1, len(line_list)):
        if line_list[j].strip() == "])":
            end_idx = j
            break

    if end_idx is None:
        return text, False

    block = "\n".join(line_list[start_idx : end_idx + 1])
    if all(line.strip() in block for line in lines_to_add):
        return text, False

    base_indent = _indent_of(line_list[start_idx]) + "    "
    insert_lines = [f"{base_indent}{line}" for line in lines_to_add]

    insert_at = start_idx + 1
    line_list[insert_at:insert_at] = insert_lines
    return "\n".join(line_list) + ("\n" if text.endswith("\n") else ""), True


def _ensure_preflight_guards(text: str) -> tuple[str, bool]:
    if "preflight_guards = Seq([" in text:
        return text, False

    lines = text.splitlines()
    insert_idx = None
    indent = ""
    for i, line in enumerate(lines):
        if line.strip().startswith("def approval_program"):
            insert_idx = i + 1
            indent = _indent_of(line) + "    "
            break

    if insert_idx is None:
        return text, False

    guard_block = [
        f"{indent}preflight_guards = Seq([",
        f"{indent}    Assert(Txn.rekey_to() == Global.zero_address()),",
        f"{indent}    Assert(Txn.close_remainder_to() == Global.zero_address()),",
        f"{indent}    Assert(Txn.asset_close_to() == Global.zero_address()),",
        f"{indent}])",
        "",
    ]

    lines[insert_idx:insert_idx] = guard_block
    updated = "\n".join(lines) + ("\n" if text.endswith("\n") else "")

    if "return Seq([preflight_guards, program])" not in updated:
        updated = re.sub(
            r"return\s+program\s*$",
            "return Seq([preflight_guards, program])",
            updated,
            flags=re.MULTILINE,
        )

    return updated, True


def _ensure_update_admin_guard(text: str) -> tuple[str, bool]:
    guard = "Assert(Txn.sender() == App.globalGet(admin_key)),"
    return _inject_in_seq_block(text, "update_admin", [guard])


def _ensure_withdraw_args_guard(text: str) -> tuple[str, bool]:
    guard = "Assert(Txn.application_args.length() >= Int(2)),"
    return _inject_in_seq_block(text, "withdraw", [guard])


def _ensure_deposit_linkage_guards(text: str) -> tuple[str, bool]:
    lines_to_add = [
        "Assert(Gtxn[0].sender() == Txn.sender()),",
        "Assert(Gtxn[0].receiver() == Global.current_application_address()),",
    ]
    return _inject_in_seq_block(text, "deposit", lines_to_add)


def apply_pyteal_autofix(source_text: str) -> tuple[str, list[str]]:
    changes: list[str] = []
    updated = source_text

    updated, changed = _ensure_preflight_guards(updated)
    if changed:
        changes.append("Added transaction preflight guards (`rekey_to`, `close_remainder_to`, `asset_close_to`) and wrapped return flow.")

    updated, changed = _ensure_withdraw_args_guard(updated)
    if changed:
        changes.append("Added explicit `Txn.application_args.length() >= Int(2)` check in withdraw flow.")

    updated, changed = _ensure_update_admin_guard(updated)
    if changed:
        changes.append("Added `update_admin` authorization guard using `App.globalGet(admin_key)`.")

    updated, changed = _ensure_deposit_linkage_guards(updated)
    if changed:
        changes.append("Added deposit atomic-group linkage checks for sender and application receiver.")

    return updated, changes


def fix_pyteal_contract(*, source: Path, output: Path | None = None, in_place: bool = False) -> AutoFixResult:
    if source.suffix.lower() != ".py":
        raise ValueError("Auto-fix currently supports PyTeal Python files (.py) only")

    src = source.read_text(encoding="utf-8")
    fixed, changes = apply_pyteal_autofix(src)
    changed = fixed != src

    if in_place:
        out = source
    else:
        out = output or source.with_name(f"{source.stem}.fixed{source.suffix}")

    out.write_text(fixed, encoding="utf-8")
    return AutoFixResult(source=source, output=out, changed=changed, changes=changes)
