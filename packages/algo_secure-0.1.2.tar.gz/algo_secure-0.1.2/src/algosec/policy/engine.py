from __future__ import annotations

from collections import Counter

from algosec.models import ScanResult
from algosec.policy.default_policies import POLICY_PROFILES
from algosec.policy.models import DecisionReason, PolicyDecision, PolicyEvaluation


def evaluate_policy(
    *,
    scan_result: ScanResult,
    simulation_signals: list[dict] | None = None,
    profile: str = "strict-defi",
) -> PolicyEvaluation:
    if profile not in POLICY_PROFILES:
        supported = ", ".join(sorted(POLICY_PROFILES))
        raise ValueError(f"Unknown policy profile '{profile}'. Supported profiles: {supported}")

    policy = POLICY_PROFILES[profile]

    score_meta = scan_result.metadata.get("score", {}) if isinstance(scan_result.metadata, dict) else {}
    risk = int(score_meta.get("risk_score", 100)) if isinstance(score_meta, dict) else 100
    score = int(score_meta.get("security_score", 0)) if isinstance(score_meta, dict) else 0

    reasons: list[DecisionReason] = []
    severity_counts = Counter(f.severity.value for f in scan_result.findings)

    if scan_result.errors:
        reasons.append(
            DecisionReason(
                code="scan-errors",
                message="Scan produced runtime/parse errors; execution safety cannot be guaranteed.",
                severity="high",
            )
        )

    if policy["critical_block"] and severity_counts.get("critical", 0) > 0:
        reasons.append(
            DecisionReason(
                code="critical-findings",
                message="Critical vulnerabilities were detected.",
                severity="critical",
            )
        )

    if severity_counts.get("high", 0) >= int(policy["high_block_threshold"]):
        reasons.append(
            DecisionReason(
                code="many-high-findings",
                message="High-severity finding count exceeds policy threshold.",
                severity="high",
            )
        )

    if simulation_signals:
        for signal in simulation_signals:
            level = str(signal.get("severity", "medium"))
            code = str(signal.get("code", "simulation-signal"))
            msg = str(signal.get("message", "Simulation detected a risk condition."))
            reasons.append(DecisionReason(code=code, message=msg, severity=level))

    easy_exploitable = any(str(r.get("exploitability", "")).lower() == "easy" for r in simulation_signals or [])
    if policy["exploitability_block_if_easy"] and easy_exploitable:
        reasons.append(
            DecisionReason(
                code="easy-exploitability",
                message="Simulation marked path as easily exploitable.",
                severity="high",
            )
        )

    if any(r.severity == "critical" for r in reasons):
        decision = PolicyDecision.BLOCK
    elif risk <= int(policy["allow_max_risk"]) and not reasons:
        decision = PolicyDecision.ALLOW
    elif risk <= int(policy["review_max_risk"]):
        decision = PolicyDecision.REVIEW
    else:
        decision = PolicyDecision.BLOCK

    return PolicyEvaluation(decision=decision, score=score, risk=risk, reasons=reasons, profile=str(policy["profile"]))
