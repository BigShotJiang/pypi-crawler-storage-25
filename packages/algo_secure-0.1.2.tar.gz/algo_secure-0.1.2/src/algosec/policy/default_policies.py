from __future__ import annotations

STRICT_DEFI_POLICY = {
    "profile": "strict-defi",
    "allow_max_risk": 15,
    "review_max_risk": 45,
    "critical_block": True,
    "high_block_threshold": 3,
    "exploitability_block_if_easy": True,
}

BALANCED_POLICY = {
    "profile": "balanced",
    "allow_max_risk": 20,
    "review_max_risk": 55,
    "critical_block": True,
    "high_block_threshold": 4,
    "exploitability_block_if_easy": False,
}

POLICY_PROFILES = {
    "strict-defi": STRICT_DEFI_POLICY,
    "balanced": BALANCED_POLICY,
}
