from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class PolicyDecision(str, Enum):
    ALLOW = "ALLOW"
    REVIEW = "REVIEW"
    BLOCK = "BLOCK"


@dataclass(slots=True)
class DecisionReason:
    code: str
    message: str
    severity: str = "medium"


@dataclass(slots=True)
class PolicyEvaluation:
    decision: PolicyDecision
    score: int
    risk: int
    reasons: list[DecisionReason] = field(default_factory=list)
    profile: str = "strict-defi"
