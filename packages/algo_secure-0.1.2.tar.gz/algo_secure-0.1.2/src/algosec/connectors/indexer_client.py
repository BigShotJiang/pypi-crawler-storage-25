from __future__ import annotations

import json
import urllib.parse
import urllib.error
import urllib.request
from dataclasses import dataclass


@dataclass(slots=True)
class IndexerClient:
    base_url: str
    token: str = ""
    timeout: float = 20.0

    def _request_json(self, path: str, params: dict[str, object] | None = None) -> dict:
        query = ""
        if params:
            encoded = {
                key: value
                for key, value in params.items()
                if value is not None
            }
            query = "?" + urllib.parse.urlencode(encoded)

        url = f"{self.base_url.rstrip('/')}{path}{query}"
        headers = {"Accept": "application/json"}
        if self.token:
            headers["X-Indexer-API-Token"] = self.token

        req = urllib.request.Request(url, headers=headers, method="GET")
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as response:  # noqa: S310
                payload = response.read().decode("utf-8")
                return json.loads(payload)
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"Indexer HTTP {exc.code}: {body}") from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(f"Indexer connection failed: {exc.reason}") from exc

    def health(self) -> dict:
        return self._request_json("/health")

    def account_info(self, address: str) -> dict:
        return self._request_json(f"/v2/accounts/{address}")

    def asset_info(self, asset_id: int) -> dict:
        return self._request_json(f"/v2/assets/{asset_id}")

    def search_transactions(
        self,
        *,
        address: str | None = None,
        application_id: int | None = None,
        asset_id: int | None = None,
        limit: int = 200,
    ) -> dict:
        params: dict[str, object] = {
            "address": address,
            "application-id": application_id,
            "asset-id": asset_id,
            "limit": max(1, min(limit, 1000)),
        }
        return self._request_json("/v2/transactions", params=params)
