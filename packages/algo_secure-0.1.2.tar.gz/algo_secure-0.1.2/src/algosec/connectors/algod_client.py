from __future__ import annotations

import json
import urllib.error
import urllib.request
from dataclasses import dataclass


@dataclass(slots=True)
class AlgodClient:
    base_url: str
    token: str
    timeout: float = 20.0

    def _request_json(self, path: str) -> dict:
        url = f"{self.base_url.rstrip('/')}{path}"
        req = urllib.request.Request(
            url,
            headers={
                "X-Algo-API-Token": self.token,
                "Accept": "application/json",
            },
            method="GET",
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as response:  # noqa: S310
                payload = response.read().decode("utf-8")
                return json.loads(payload)
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"Algod HTTP {exc.code}: {body}") from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(f"Algod connection failed: {exc.reason}") from exc

    def health(self) -> dict:
        return self._request_json("/health")

    def status(self) -> dict:
        return self._request_json("/v2/status")

    def application_info(self, app_id: int) -> dict:
        return self._request_json(f"/v2/applications/{app_id}")

    def account_application_info(self, address: str, app_id: int) -> dict:
        return self._request_json(f"/v2/accounts/{address}/applications/{app_id}")
