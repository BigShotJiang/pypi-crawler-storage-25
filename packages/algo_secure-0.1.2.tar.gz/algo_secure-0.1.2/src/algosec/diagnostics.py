from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class ErrorDiagnostic:
    error_type: str
    likely_cause: str
    fix: str


def diagnose_scan_error(message: str) -> ErrorDiagnostic:
    lower = message.lower()

    if "no supported files found" in lower:
        return ErrorDiagnostic(
            error_type="unsupported-target",
            likely_cause="Target path has no supported scanner inputs or path is incorrect.",
            fix="Provide a valid .teal/.pyteal/.py file or directory containing supported contract files.",
        )

    if "invalid syntax" in lower and "instead of '='" in lower:
        return ErrorDiagnostic(
            error_type="pyteal-syntax-assignment-in-expression",
            likely_cause=(
                "Python assignment statements were used inside PyTeal expression blocks (for example inside `Seq([...])`)."
            ),
            fix=(
                "Replace inline assignments with expression-safe constructs (for example `ScratchVar().store(...)` and `ScratchVar().load()`), "
                "or compute values before expression lists."
            ),
        )

    if "failed importing pyteal file" in lower:
        return ErrorDiagnostic(
            error_type="pyteal-import-execution-error",
            likely_cause="The PyTeal module failed during import or top-level execution.",
            fix="Move side effects behind functions, validate imports, and ensure entrypoint builders are zero-argument callables.",
        )

    if "no compile targets detected" in lower:
        return ErrorDiagnostic(
            error_type="pyteal-entrypoint-missing",
            likely_cause="Expected compile entrypoints were not found.",
            fix="Define one of: `approval_program`, `clear_state_program`, `logic_signature`, `signature_program`, `program`, or `CONTRACTS`.",
        )

    if "pyteal support requires" in lower:
        return ErrorDiagnostic(
            error_type="pyteal-dependency-missing",
            likely_cause="PyTeal package is not installed in active environment.",
            fix="Install dependency in current environment: `pip install pyteal`.",
        )

    return ErrorDiagnostic(
        error_type="scan-runtime-error",
        likely_cause="Scanner/runtime error occurred while parsing or analyzing the contract.",
        fix="Inspect stack message, fix syntax/runtime issues, then re-run scan.",
    )
