from __future__ import annotations

from pathlib import Path

SUPPORTED_EXTENSIONS = {".teal", ".pyteal", ".py"}


def discover_targets(path: Path) -> list[Path]:
    if path.is_file():
        if ".aplussec_build" in path.parts:
            return []
        return [path] if path.suffix.lower() in SUPPORTED_EXTENSIONS else []

    files: list[Path] = []
    for ext in SUPPORTED_EXTENSIONS:
        for file_path in path.rglob(f"*{ext}"):
            if ".aplussec_build" in file_path.parts:
                continue
            files.append(file_path)
    return sorted(files)
