Bare Metal Service Features
===========================

.. toctree::
  :maxdepth: 1

   Hardware Inspection <inspection/index>
   Deployment <node-deployment>
   Cleaning <cleaning>
   Adoption <adoption>
   Retirement <retirement>
   RAID Configuration <raid>
   BIOS Settings <bios>
   Firmware Updates <firmware-updates>
   Node Rescuing <rescue>
   Booting from Volume <boot-from-volume>
   Configuring Consoles <console>
   Enabling Notifications <notifications>
   Node Multi-Tenancy <node-multitenancy>
   Booting a Ramdisk or an ISO <ramdisk-boot>
   Hardware Burn-in <hardware-burn-in>
   Vendor Passthru <vendor-passthru>
   Servicing <servicing>
   Windows Images <building-windows-images>
   Deploying without BMC Credentials <agent-power>
   Layer 3 or DHCP-less Ramdisk Booting <dhcp-less>
   Deploying with Anaconda <anaconda-deploy-interface>
   Node History <node-history>
   Node Health Monitoring <health-monitoring>
   OCI Container Registry Support <oci-container-registry>
   Runbooks for Cleaning & Servicing <runbooks>
   Container-Based Steps <container-based-steps>
   Trait Based Networking (TBN) <trait-based-networking>
