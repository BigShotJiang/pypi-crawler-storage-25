Configuration and Operation
===========================

.. toctree::
  :maxdepth: 1

   Ironic Python Agent <drivers/ipa>
   Networking <networking>
   Port Groups <portgroups>
   Conductor Groups <conductor-groups>
   Security <security>
   Troubleshooting FAQ <troubleshooting>
   Power Synchronization <power-sync>
   Fast-Track Deployment <fast-track>
   Authentication for Instance Images <user-image-basic-auth>
   OVN Networking <ovn-networking>
   Ceph Object Gateway <radosgw>
   Emitting Software Metrics <metrics>
   Auditing API Traffic <api-audit-support>
   Custom API Middleware <api-middleware>
   Tuning Ironic <tuning>
   Role Based Access Control <secure-rbac>
   Dashboard Integration <dashboard>
   Upgrade Guide <upgrade-guide>
