# Copyright 2017 Red Hat, Inc.
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from oslo_config import cfg

from ironic.common.i18n import _

opts = [
    cfg.IntOpt('connection_attempts',
               min=1,
               default=5,
               help=_('Maximum number of attempts to try to connect '
                      'to Redfish')),
    cfg.IntOpt('connection_retry_interval',
               min=1,
               default=4,
               help=_('Number of seconds to wait between attempts to '
                      'connect to Redfish')),
    cfg.IntOpt('connect_timeout',
               min=1,
               default=30,
               help=_('TCP connection timeout in seconds when connecting '
                      'to the Redfish BMC. This controls how long to wait '
                      'for the initial TCP connection to be established. '
                      'A lower value allows faster failure when a BMC is '
                      'unreachable, while the default read timeout '
                      '(60 seconds) still applies for waiting on response '
                      'data from responsive BMCs.')),
    cfg.IntOpt('connection_cache_size',
               min=0,
               default=1000,
               help=_('Maximum Redfish client connection cache size. '
                      'Redfish driver would strive to reuse authenticated '
                      'BMC connections (obtained through Redfish Session '
                      'Service). This option caps the maximum number of '
                      'connections to maintain. The value of `0` disables '
                      'client connection caching completely.')),
    cfg.StrOpt('auth_type',
               choices=[('basic', _('Use HTTP basic authentication')),
                        ('session', _('Use HTTP session authentication')),
                        ('auto', _('Try HTTP session authentication first, '
                                   'fall back to basic HTTP authentication'))],
               default='auto',
               help=_('Redfish HTTP client authentication method.')),
    cfg.BoolOpt('use_swift',
                default=False,
                mutable=True,
                help=_('Upload generated ISO images for virtual media boot to '
                       'Swift, then pass temporary URL to BMC for booting the '
                       'node. If set to false, images are placed on the '
                       'ironic-conductor node and served over its '
                       'local HTTP server.')),
    cfg.StrOpt('swift_container',
               default='ironic_redfish_container',
               mutable=True,
               help=_('The Swift container to store Redfish driver data. '
                      'Applies only when `use_swift` is enabled.')),
    cfg.IntOpt('swift_object_expiry_timeout',
               default=900,
               mutable=True,
               help=_('Amount of time in seconds for Swift objects to '
                      'auto-expire. Applies only when `use_swift` is '
                      'enabled.')),
    cfg.StrOpt('kernel_append_params',
               default='nofb vga=normal',
               mutable=True,
               help=_('Additional kernel parameters to pass down to the '
                      'instance kernel. These parameters can be consumed by '
                      'the kernel or by the applications by reading '
                      '/proc/cmdline. Mind severe cmdline size limit! Can be '
                      'overridden by `instance_info/kernel_append_params` '
                      'property.')),
    cfg.IntOpt('file_permission',
               default=0o644,
               help=_('File permission for swift-less image hosting with the '
                      'octal permission representation of file access '
                      'permissions. This setting defaults to ``644``, '
                      'or as the octal number ``0o644`` in Python. '
                      'This setting must be set to the octal number '
                      'representation, meaning starting with ``0o``.')),
    cfg.IntOpt('firmware_update_status_interval',
               min=0,
               default=60,
               help=_('Number of seconds to wait between checking for '
                      'completed firmware update tasks')),
    cfg.IntOpt('firmware_update_fail_interval',
               min=0,
               default=60,
               help=_('Number of seconds to wait between checking for '
                      'failed firmware update tasks')),
    cfg.IntOpt('firmware_update_wait_unresponsive_bmc',
               min=0,
               default=0,
               help=_('Number of seconds to wait before proceeding with the '
                      'reboot to finish the BMC firmware update step')),
    cfg.IntOpt('firmware_update_required_successes',
               min=0,
               default=3,
               help=_('Number of successful responses required to '
                      'consider post-upgrade BMC validation a success. '
                      'Set to 0 to disable post-upgrade validation '
                      'entirely.')),
    cfg.IntOpt('firmware_update_validation_interval',
               min=0,
               default=30,
               help=_('Timeout (in seconds) to wait between validation '
                      'attempts. Set to 0 for rapid succession retries '
                      'with no delay.')),
    cfg.IntOpt('firmware_update_resource_validation_timeout',
               min=0,
               default=480,
               help=_('Timeout (in seconds) to wait for BMC resources '
                      '(System, Manager, NetworkAdapters) to become stable '
                      'and consistently available after firmware update. '
                      'Set to 0 to disable post-upgrade validation '
                      'entirely.')),
    cfg.IntOpt('firmware_update_bmc_timeout',
               min=0,
               default=300,
               help=_('Timeout (in seconds) for BMC firmware updates. '
                      'BMC firmware updates may need extended time to handle '
                      'BMC transitional states during the firmware update '
                      'process.')),
    cfg.IntOpt('firmware_update_reboot_delay',
               min=0,
               default=300,
               help=_('Default wait time (in seconds) for component-specific '
                      'firmware update operations. Used for: BIOS firmware '
                      'update wait before reboot, BMC firmware version check '
                      'timeout, and NIC firmware task completion timeout.')),
    cfg.IntOpt('firmware_update_bmc_version_check_interval',
               min=0,
               default=30,
               help=_('Interval (in seconds) for checking BMC firmware '
                      'version after BMC firmware update. Used to verify '
                      'if BMC firmware has been successfully applied.')),
    cfg.IntOpt('firmware_update_nic_starting_wait',
               min=0,
               default=30,
               help=_('Time (in seconds) to wait for a NIC firmware update '
                      'task to progress beyond the STARTING state before '
                      'triggering a reboot. Some NICs need a reboot to '
                      'start applying firmware, while others can begin '
                      'immediately. This timeout helps determine which '
                      'behavior the hardware exhibits.')),
    cfg.IntOpt('firmware_update_overall_timeout',
               min=0,
               default=7200,
               help=_('Maximum time (in seconds) allowed for the entire '
                      'firmware update operation to complete. This provides '
                      'a safety net for firmware updates that get stuck. '
                      'Set to 0 to disable this timeout (not recommended). '
                      'Default is 7200 seconds (2 hours).')),
    cfg.StrOpt('firmware_source',
               choices=[('http', _('If firmware source URL is also HTTP, then '
                                   'serve from original location, otherwise '
                                   'copy to ironic\'s HTTP server. Default.')),
                        ('local', _('Download from original location and '
                                    'server from ironic\'s HTTP server.')),
                        ('swift', _('If firmware source URL is also Swift, '
                                    'serve from original location, otherwise '
                                    'copy to ironic\'s Swift server.'))],
               default='http',
               mutable=True,
               help=_('Specifies how firmware image should be served. Whether '
                      'from its original location using the firmware source '
                      'URL directly, or should serve it from ironic\'s Swift '
                      'or HTTP server.')),
    cfg.IntOpt('raid_config_status_interval',
               min=0,
               default=60,
               help=_('Number of seconds to wait between checking for '
                      'completed raid config tasks')),
    cfg.IntOpt('raid_config_fail_interval',
               min=0,
               default=60,
               help=_('Number of seconds to wait between checking for '
                      'failed raid config tasks')),
    cfg.IntOpt('boot_mode_config_timeout',
               min=0,
               default=900,
               help=_('Number of seconds to wait for boot mode or secure '
                      'boot status change to take effect after a reboot. '
                      'Set to 0 to disable waiting.')),
    cfg.StrOpt('verify_ca',
               help=_('The default verify_ca path when redfish_verify_ca '
                      'in driver_info is missing or set to True.')),
    cfg.BoolOpt('enable_verify_bmc_clock',
                default=False,
                help=_('Whether to enable the automated verify step '
                       'that checks and sets the BMC clock. '
                       'When enabled, Ironic will automatically attempt '
                       'to set the BMC\'s clock during node registration '
                       '(in the verify phase) using Redfish\'s '
                       'DateTime fields. '
                       'This helps avoid TLS certificate issues '
                       'caused by incorrect BMC time.')),
    cfg.StrOpt('default_inspection_hooks',
               default='validate-interfaces,ports,architecture',
               help=_('A comma-separated lists of inspection hooks that are '
                      'run by default for the "agent" inspection interface. '
                      'In most cases, the operators will not '
                      'modify this. The default (somewhat conservative) hooks '
                      'validate interfaces in the inventory, create '
                      'ports and set the node\'s cpu architecture property.')),
    cfg.StrOpt('inspection_hooks',
               default='$default_inspection_hooks',
               help=_('Comma-separated list of enabled hooks for processing '
                      'pipeline when using the "redfish" inspection '
                      'interface. The default for this is '
                      '$default_inspection_hooks. Hooks can be added before '
                      'or after the defaults like this: '
                      '"prehook,$default_hooks,posthook".')),
    cfg.IntOpt('post_boot_retry_attempts',
               min=1,
               default=6,
               help=_('Maximum number of retry attempts when BMC rejects '
                      'boot device changes during POST (Power-On Self-Test). '
                      'Some BMCs (e.g. HPE iLO) reject boot device '
                      'modifications while the system is in POST after a '
                      'firmware update or reboot.')),
    cfg.IntOpt('post_boot_retry_delay',
               min=1,
               default=5,
               help=_('Minimum delay in seconds between retry attempts '
                      'for POST-related boot device errors. Exponential '
                      'backoff is applied, starting from this value up to '
                      '6x this value.')),
]


def register_opts(conf):
    conf.register_opts(opts, group='redfish')
