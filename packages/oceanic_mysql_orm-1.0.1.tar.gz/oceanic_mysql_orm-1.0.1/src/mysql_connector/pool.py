"""
Async MySQL connection pool — wraps aiomysql.Pool.

Features:
  - Lazy connect with double-checked locking
  - Context managers for cursor and transaction
  - Health check / ping
  - Graceful shutdown
"""

from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager
from typing import Any, AsyncGenerator, Optional

try:
    import aiomysql
except ImportError:
    aiomysql = None  # type: ignore[assignment]

from .exceptions import ConnectionPoolError

logger = logging.getLogger(__name__)


class ConnectionPool:
    """
    Async MySQL connection pool.

    Usage:
        pool = ConnectionPool(host="localhost", user="root", password="", database="mydb")
        await pool.connect()

        async with pool.cursor() as cur:
            await cur.execute("SELECT 1")
            rows = await cur.fetchall()

        async with pool.transaction() as conn:
            async with conn.cursor(aiomysql.DictCursor) as cur:
                await cur.execute("INSERT INTO ...")

        await pool.disconnect()
    """

    def __init__(
        self,
        host:            str   = "127.0.0.1",
        port:            int   = 3306,
        user:            str   = "root",
        password:        str   = "",
        database:        str   = "",
        minsize:         int   = 2,
        maxsize:         int   = 10,
        charset:         str   = "utf8mb4",
        autocommit:      bool  = True,
        connect_timeout: int   = 10,
        echo:            bool  = False,
    ):
        self._config: dict[str, Any] = {
            "host":            host,
            "port":            port,
            "user":            user,
            "password":        password,
            "db":              database,
            "minsize":         minsize,
            "maxsize":         maxsize,
            "charset":         charset,
            "autocommit":      autocommit,
            "connect_timeout": connect_timeout,
            "echo":            echo,
            "cursorclass":     aiomysql.DictCursor,
        }
        self._pool:  Optional[aiomysql.Pool] = None
        self._lock   = asyncio.Lock()

    # ── Lifecycle ─────────────────────────────────────────────────────────

    async def connect(self) -> None:
        """Create the connection pool. Safe to call multiple times."""
        async with self._lock:
            if self._pool is not None and not self._pool.closed:
                return
            try:
                self._pool = await aiomysql.create_pool(**self._config)
                logger.info(
                    "✅ MySQL pool connected  host=%s:%s  db=%s  "
                    "min=%s  max=%s",
                    self._config["host"], self._config["port"],
                    self._config["db"],
                    self._config["minsize"], self._config["maxsize"],
                )
            except Exception as exc:
                raise ConnectionPoolError(
                    f"Cannot connect to MySQL at "
                    f"{self._config['host']}:{self._config['port']} — {exc}"
                ) from exc

    async def disconnect(self) -> None:
        """Gracefully close all connections in the pool."""
        if self._pool and not self._pool.closed:
            self._pool.close()
            await self._pool.wait_closed()
            self._pool = None
            logger.info("MySQL pool disconnected.")

    async def ping(self) -> bool:
        """Return True if the pool can issue a SELECT 1."""
        try:
            async with self.cursor() as cur:
                await cur.execute("SELECT 1")
            return True
        except Exception:
            return False

    # ── Acquire helpers ───────────────────────────────────────────────────

    @asynccontextmanager
    async def acquire(self) -> AsyncGenerator[aiomysql.Connection, None]:
        """Yield a raw connection from the pool."""
        self._assert_connected()
        async with self._pool.acquire() as conn:
            yield conn

    @asynccontextmanager
    async def cursor(self) -> AsyncGenerator[aiomysql.Cursor, None]:
        """Yield a DictCursor ready for queries."""
        async with self.acquire() as conn:
            async with conn.cursor(aiomysql.DictCursor) as cur:
                yield cur

    @asynccontextmanager
    async def transaction(self) -> AsyncGenerator[aiomysql.Connection, None]:
        """
        Yield a connection with an open transaction.
        Commits on success, rolls back on any exception.

        Usage:
            async with pool.transaction() as conn:
                async with conn.cursor(aiomysql.DictCursor) as cur:
                    await cur.execute("INSERT ...")
                    await cur.execute("UPDATE ...")
            # auto-committed here
        """
        async with self.acquire() as conn:
            await conn.begin()
            try:
                yield conn
                await conn.commit()
            except Exception:
                await conn.rollback()
                raise

    # ── Status ────────────────────────────────────────────────────────────

    @property
    def is_connected(self) -> bool:
        return self._pool is not None and not self._pool.closed

    @property
    def pool_size(self) -> int:
        return self._pool.size if self._pool else 0

    @property
    def free_connections(self) -> int:
        return self._pool.freesize if self._pool else 0

    def _assert_connected(self) -> None:
        if not self.is_connected:
            raise ConnectionPoolError(
                "Connection pool is not connected. Call connector.connect() first."
            )

    def __repr__(self) -> str:
        status = "connected" if self.is_connected else "disconnected"
        return (
            f"ConnectionPool({self._config['host']}:{self._config['port']} "
            f"db={self._config['db']} [{status}])"
        )
