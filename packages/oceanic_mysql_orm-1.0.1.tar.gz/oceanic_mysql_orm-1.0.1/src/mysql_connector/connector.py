"""
MySQLConnector — the main entry point for all database operations.

Features:
  - Full CRUD: find, find_one, find_by_id, create, update, delete, count, exists
  - LoopBack-style filter DSL (where, order, limit, skip, fields, include)
  - Nested relation loading with zero N+1 queries
  - Typed model instances returned everywhere
  - Raw SQL escape hatch
  - Transaction support
  - Async-first (FastAPI / asyncio ready)

Usage:
    connector = MySQLConnector(host="localhost", database="mydb",
                               user="root", password="secret")
    await connector.connect()

    users = await connector.find(User, {
        "where": {"active": True},
        "include": ["orders.items"],
        "order": ["name ASC"],
        "limit": 20,
    })

    for user in users:
        print(user.name, user.orders)   # fully typed
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, Optional, Type, Union

try:
    import aiomysql
except ImportError:
    aiomysql = None  # type: ignore[assignment]

from .model import MySQLModel
from .pool import ConnectionPool
from .query_builder import QueryBuilder
from .relation_resolver import RelationResolver, _dict_to_filter, _parse_include
from .types import FilterOptions, IncludeItem
from .migrator import Migrator
from .exceptions import QueryError, ConfigurationError, TransactionError

logger = logging.getLogger(__name__)


class MySQLConnector:
    """
    Production MySQL connector with nested relation support.

    Args:
        host:       MySQL server host.
        port:       MySQL server port (default 3306).
        user:       Username.
        password:   Password.
        database:   Database/schema name.
        minsize:    Minimum pool connections (default 2).
        maxsize:    Maximum pool connections (default 10).
        echo:       Log every SQL statement (debug mode).
    """

    def __init__(
        self,
        host:     str  = "127.0.0.1",
        port:     int  = 3306,
        user:     str  = "root",
        password: str  = "",
        database: str  = "",
        minsize:  int  = 2,
        maxsize:  int  = 10,
        echo:     bool = False,
    ):
        self._pool = ConnectionPool(
            host     = host,
            port     = port,
            user     = user,
            password = password,
            database = database,
            minsize  = minsize,
            maxsize  = maxsize,
            echo     = echo,
        )
        self._resolver = RelationResolver(self._pool)
        self._migrator = Migrator(self._pool)

    # ── Lifecycle ─────────────────────────────────────────────────────────

    async def connect(self) -> None:
        """Open the connection pool. Call this on app startup."""
        await self._pool.connect()

    async def disconnect(self) -> None:
        """Close all connections. Call this on app shutdown."""
        await self._pool.disconnect()

    async def ping(self) -> bool:
        """Return True if the DB is reachable."""
        return await self._pool.ping()

    async def migrate(self) -> None:
        """
        Synchronize models with database.
        Detects model changes and applies CREATE/ALTER commands automatically.
        """
        await self._migrator.migrate()

    @property
    def is_connected(self) -> bool:
        return self._pool.is_connected

    # ── find ─────────────────────────────────────────────────────────────

    async def find(
        self,
        model:  Type[MySQLModel],
        filter: Union[dict, FilterOptions] = {},
    ) -> list[MySQLModel]:
        """
        Find all records matching the filter.

        Returns a list of typed model instances with relations populated
        if `include` is specified.

        Example:
            users = await connector.find(User, {
                "where": {"active": True, "age": {"gte": 18}},
                "include": ["orders.items.product"],
                "order": ["name ASC"],
                "limit": 50,
                "skip": 0,
            })
        """
        opts = self._to_filter(filter)
        
        # Apply Soft Delete filter by default if model has deleted_at
        if "deleted_at" in model._fields:
            if not opts.where:
                opts.where = {}
            if "deleted_at" not in opts.where:
                opts.where["deleted_at"] = None

        qb   = QueryBuilder(model.__table__, model._fields)
        sql, params = qb.build_select(opts)

        rows      = await self._fetch(sql, params)
        instances = [model._from_row(row) for row in rows]

        if opts.include and instances:
            await self._resolver.resolve(instances, opts.include, model)

        return instances

    # ── find_one ──────────────────────────────────────────────────────────

    async def find_one(
        self,
        model:  Type[MySQLModel],
        filter: Union[dict, FilterOptions] = {},
    ) -> Optional[MySQLModel]:
        """
        Find the first record matching the filter, or None.

        Example:
            user = await connector.find_one(User, {
                "where": {"email": "raj@example.com"},
                "include": ["profile"],
            })
        """
        opts       = self._to_filter(filter)
        opts.limit = 1
        results    = await self.find(model, opts)
        return results[0] if results else None

    # ── find_by_id ────────────────────────────────────────────────────────

    async def find_by_id(
        self,
        model:  Type[MySQLModel],
        id:     Any,
        filter: Union[dict, FilterOptions] = {},
    ) -> Optional[MySQLModel]:
        """
        Find a record by its primary key.

        Example:
            user = await connector.find_by_id(User, 42, {
                "include": ["orders.items"]
            })
        """
        pk = self._require_pk(model)
        opts = self._to_filter(filter)
        opts.where = {**(opts.where or {}), pk: id}
        return await self.find_one(model, opts)

    # ── create ────────────────────────────────────────────────────────────

    async def create(
        self,
        model: Type[MySQLModel],
        data:  dict[str, Any],
    ) -> MySQLModel:
        """
        Insert a new row and return the created model instance.
        The primary key is auto-populated from lastrowid.

        Example:
            user = await connector.create(User, {
                "name": "Raj",
                "email": "raj@example.com",
            })
            print(user.id)   # populated
        """
        # Handle auto_now_add fields
        now = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        for name, field_def in model._fields.items():
            if field_def.auto_now_add and name not in data:
                data[name] = now

        # Create temporary instance to trigger hooks
        instance = model(**data)
        await instance._trigger_hook("before_create")
        
        # Get data back from instance (it might have been mutated in hook)
        final_data = {name: getattr(instance, name) for name in model._fields if hasattr(instance, name)}

        qb  = QueryBuilder(model.__table__, model._fields)
        sql, params = qb.build_insert(final_data)

        logger.debug("INSERT: %s  PARAMS: %s", sql, params)
        async with self._pool.cursor() as cur:
            await cur.execute(sql, params)
            insert_id = cur.lastrowid

        pk = model._get_primary_key()
        if pk and insert_id:
            object.__setattr__(instance, pk, insert_id)

        await instance._trigger_hook("after_create")
        return instance

    # ── update_all ────────────────────────────────────────────────────────

    async def update_all(
        self,
        model: Type[MySQLModel],
        where: dict[str, Any],
        data:  dict[str, Any],
    ) -> int:
        """
        Update all records matching `where`. Returns affected row count.

        Example:
            count = await connector.update_all(
                User,
                where={"active": False},
                data={"deleted_at": datetime.utcnow()},
            )
        """
        # Handle auto_now fields
        now = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        for name, field_def in model._fields.items():
            if field_def.auto_now:
                data[name] = now

        qb  = QueryBuilder(model.__table__, model._fields)
        sql, params = qb.build_update(where, data)
        return await self._execute(sql, params)

    # ── update_by_id ──────────────────────────────────────────────────────

    async def update_by_id(
        self,
        model: Type[MySQLModel],
        id:    Any,
        data:  dict[str, Any],
    ) -> Optional[MySQLModel]:
        """
        Update a single record by PK and return the updated instance.

        Example:
            user = await connector.update_by_id(User, 42, {"name": "Rajesh"})
        """
        pk = self._require_pk(model)
        await self.update_all(model, {pk: id}, data)
        return await self.find_by_id(model, id)

    # ── delete_all ────────────────────────────────────────────────────────

    async def delete_all(
        self,
        model: Type[MySQLModel],
        where: dict[str, Any],
    ) -> int:
        """
        Delete all records matching `where`. Returns affected row count.

        Example:
            count = await connector.delete_all(User, {"active": False})
        """
        # If soft delete is supported, perform UPDATE instead of DELETE
        if "deleted_at" in model._fields:
            now = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
            return await self.update_all(model, where, {"deleted_at": now})

        qb  = QueryBuilder(model.__table__, model._fields)
        sql, params = qb.build_delete(where)
        return await self._execute(sql, params)

    # ── delete_by_id ──────────────────────────────────────────────────────

    async def delete_by_id(
        self,
        model: Type[MySQLModel],
        id:    Any,
    ) -> bool:
        """
        Delete a record by PK. Returns True if a row was deleted.

        Example:
            deleted = await connector.delete_by_id(User, 42)
        """
        pk      = self._require_pk(model)
        affected = await self.delete_all(model, {pk: id})
        return affected > 0

    # ── count / exists ────────────────────────────────────────────────────

    async def count(
        self,
        model: Type[MySQLModel],
        where: dict[str, Any] = {},
    ) -> int:
        """
        Count records matching `where`.

        Example:
            n = await connector.count(User, {"active": True})
        """
        qb  = QueryBuilder(model.__table__, model._fields)
        sql, params = qb.build_count(where)
        rows = await self._fetch(sql, params)
        return int(rows[0].get("_count", 0)) if rows else 0

    async def exists(
        self,
        model: Type[MySQLModel],
        where: dict[str, Any],
    ) -> bool:
        """
        Return True if at least one record matches `where`.

        Example:
            taken = await connector.exists(User, {"email": "raj@example.com"})
        """
        return await self.count(model, where) > 0

    # ── Raw SQL ───────────────────────────────────────────────────────────

    async def raw(
        self,
        sql:    str,
        params: list[Any] = [],
    ) -> list[dict]:
        """
        Execute a raw SELECT and return a list of plain dicts.

        Use sparingly — prefer typed methods where possible.

        Example:
            rows = await connector.raw(
                "SELECT u.*, COUNT(o.id) AS order_count "
                "FROM users u LEFT JOIN orders o ON o.user_id = u.id "
                "WHERE u.active = %s GROUP BY u.id",
                [True],
            )
        """
        return await self._fetch(sql, params)

    async def raw_execute(
        self,
        sql:    str,
        params: list[Any] = [],
    ) -> int:
        """
        Execute a raw INSERT / UPDATE / DELETE and return affected row count.
        """
        return await self._execute(sql, params)

    # ── Transactions ──────────────────────────────────────────────────────

    def transaction(self):
        """
        Async context manager for explicit transactions.
        Commits on clean exit, rolls back on exception.

        Example:
            async with connector.transaction() as conn:
                async with conn.cursor(aiomysql.DictCursor) as cur:
                    await cur.execute("INSERT INTO orders ...")
                    await cur.execute("UPDATE inventory SET ...")
            # auto-committed
        """
        return self._pool.transaction()

    # ── Pool status ───────────────────────────────────────────────────────

    @property
    def pool_size(self) -> int:
        return self._pool.pool_size

    @property
    def free_connections(self) -> int:
        return self._pool.free_connections

    # ── Internal helpers ──────────────────────────────────────────────────

    def _to_filter(self, filter: Union[dict, FilterOptions]) -> FilterOptions:
        if isinstance(filter, FilterOptions):
            # Return a shallow copy so we can mutate (e.g. set limit=1)
            return FilterOptions(
                where   = filter.where,
                order   = filter.order,
                limit   = filter.limit,
                skip    = filter.skip,
                fields  = filter.fields,
                include = filter.include,
            )
        if isinstance(filter, dict):
            return _dict_to_filter(filter)
        raise ConfigurationError(
            f"filter must be a dict or FilterOptions, got {type(filter).__name__}"
        )

    def _require_pk(self, model: Type[MySQLModel]) -> str:
        pk = model._get_primary_key()
        if not pk:
            raise QueryError(
                f"Model '{model.__name__}' has no primary key defined."
            )
        return pk

    async def _fetch(self, sql: str, params: list[Any]) -> list[dict]:
        logger.debug("FETCH: %s  PARAMS: %s", sql, params)
        async with self._pool.cursor() as cur:
            await cur.execute(sql, params)
            return list(await cur.fetchall())

    async def _execute(self, sql: str, params: list[Any]) -> int:
        logger.debug("EXEC:  %s  PARAMS: %s", sql, params)
        async with self._pool.cursor() as cur:
            await cur.execute(sql, params)
            return cur.rowcount

    def __repr__(self) -> str:
        return f"MySQLConnector({self._pool!r})"
