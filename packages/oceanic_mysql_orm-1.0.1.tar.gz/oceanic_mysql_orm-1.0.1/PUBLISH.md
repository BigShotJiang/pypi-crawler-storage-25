# Publishing Guide — mysql-connector-async-orm

This document is the end-to-end checklist for cutting a release of
`mysql-connector-async-orm` to PyPI.

---

## 0. One-time setup

### Accounts

1. Register on [pypi.org](https://pypi.org/) **and** [test.pypi.org](https://test.pypi.org/).
2. Enable 2FA on both accounts.

### Trusted Publishing (recommended — no tokens)

1. On PyPI, go to *Your projects → mysql-connector-async-orm → Publishing*.
2. Add a **pending publisher** with:
   - Owner: `maheshpulivarthi`
   - Repository name: `mysql-connector-async-orm`
   - Workflow filename: `publish.yml`
   - Environment name: `pypi`
3. Repeat on TestPyPI with environment `testpypi`.

With Trusted Publishing, the included GitHub Actions workflow
(`.github/workflows/publish.yml`) publishes automatically on every
`v*.*.*` tag — no API tokens stored anywhere.

### API Tokens (fallback if you publish locally)

1. PyPI → *Account settings → API tokens → Add token* (scope:
   `mysql-connector-async-orm`).
2. Save to `~/.pypirc`:

   ```ini
   [distutils]
   index-servers = pypi testpypi

   [pypi]
   username = __token__
   password = pypi-AgEI...your-token...

   [testpypi]
   repository = https://test.pypi.org/legacy/
   username = __token__
   password = pypi-AgEI...your-test-token...
   ```

   `chmod 600 ~/.pypirc`.

---

## 1. Prepare a release

1. Update `__version__` in `src/mysql_connector/__init__.py` (single
   source of truth — `pyproject.toml` reads it dynamically via hatchling).
2. Add a new section to `CHANGELOG.md` describing what shipped.
3. Commit everything:

   ```bash
   git add -A
   git commit -m "Release v1.0.1"
   ```

---

## 2. Build locally

```bash
# install build tooling once
python3 -m pip install --upgrade build twine

# clean any old artifacts
rm -rf dist/ build/ *.egg-info src/*.egg-info

# build sdist + wheel
python3 -m build

# validate the metadata that will land on PyPI
python3 -m twine check dist/*
```

You should see `PASSED` for both the `.tar.gz` and the `.whl`.

---

## 3. Smoke-test the wheel in a clean venv

```bash
python3 -m venv /tmp/release-check
source /tmp/release-check/bin/activate
pip install dist/mysql_connector_async_orm-*.whl
python3 -c "import mysql_connector as m; print(m.__version__); print(m.__all__)"
deactivate
```

---

## 4. Upload to TestPyPI

```bash
python3 -m twine upload --repository testpypi dist/*
```

Verify at `https://test.pypi.org/project/mysql-connector-async-orm/`
and install from there:

```bash
pip install --index-url https://test.pypi.org/simple/ \
            --extra-index-url https://pypi.org/simple/ \
            mysql-connector-async-orm
```

---

## 5. Publish to PyPI

### Option A — via GitHub tag (recommended)

```bash
git tag v1.0.1
git push origin v1.0.1
```

The `publish.yml` workflow builds, uploads to TestPyPI, then uploads to
PyPI using Trusted Publishing.

### Option B — local upload

```bash
python3 -m twine upload dist/*
```

---

## 6. Post-release

- Create a GitHub release tagged `v1.0.1` and paste the changelog
  section into the release notes.
- Bump `__version__` to the next dev version (e.g. `1.0.2.dev0`) on
  `main` if you want the in-tree version to diverge from the latest
  published one.
- Run a final smoke test:

  ```bash
  pip install --upgrade mysql-connector-async-orm
  python3 -c "from mysql_connector import MySQLConnector; print('ok')"
  ```

---

## Release checklist (copy into PR description)

- [ ] `__version__` bumped in `src/mysql_connector/__init__.py`
- [ ] `CHANGELOG.md` updated
- [ ] `python -m build` succeeds
- [ ] `twine check dist/*` passes
- [ ] Smoke-tested wheel in clean venv
- [ ] Uploaded to TestPyPI and verified install
- [ ] Tag pushed / workflow green
- [ ] GitHub release created
