# Usage Guide — mysql-connector-async-orm

This guide provides a concise overview of how to use the `mysql-connector-async-orm` package.

## 1. Installation

```bash
pip install mysql-connector-async-orm
```

## 2. Model Definition

Define your models by inheriting from `MySQLModel`. Use `Field` for attributes and `Relation` for associations.

```python
from mysql_connector import MySQLModel, Field, Relation

class User(MySQLModel):
    __table__ = "users"

    id:    int = Field(primary_key=True)
    name:  str = Field(max_length=100)
    email: str = Field(unique=True)

    # Relationship: One-to-Many
    posts: list["Post"] = Relation(type="hasMany", foreign_key="author_id")

class Post(MySQLModel):
    __table__ = "posts"

    id:        int = Field(primary_key=True)
    author_id: int = Field(foreign_key="users.id")
    title:     str = Field(max_length=200)

    # Relationship: BelongsTo
    author: "User" = Relation(type="belongsTo", foreign_key="author_id")
```

## 3. Connecting to MySQL

Initialize the `MySQLConnector` and connect it during your application's startup.

```python
from mysql_connector import MySQLConnector

connector = MySQLConnector(
    host="localhost",
    port=3306,
    user="root",
    password="secret",
    database="my_database"
)

await connector.connect()
```

## 4. Basic CRUD Operations

### Create
```python
user = await connector.create(User, {
    "name": "Jane Doe",
    "email": "jane@example.com"
})
```

### Find
```python
# Find many with filters
users = await connector.find(User, {
    "where": {"name": {"like": "Jane%"}},
    "limit": 10
})

# Find one by primary key
user = await connector.find_by_id(User, 1)
```

### Update
```python
updated_user = await connector.update_by_id(User, 1, {"name": "Jane Smith"})
```

### Delete
```python
success = await connector.delete_by_id(User, 1)
```

## 5. Nested Relation Queries (LoopBack Style)

One of the most powerful features is loading nested relations in a single call without N+1 queries.

```python
users = await connector.find(User, {
    "include": [
        {
            "relation": "posts",
            "scope": {
                "limit": 5,
                "order": ["created_at DESC"],
                "include": ["comments"] # Deep nesting
            }
        }
    ]
})
```

## 6. Migrations

Automatically synchronize your model definitions with the database schema.

```python
await connector.migrate()
```

## 7. Advanced Features

### JSON Fields
```python
from mysql_connector import JSONField
# ... in model ...
settings: dict = JSONField(default={})
```

### Hooks
```python
class MyModel(MySQLModel):
    async def before_create(self):
        self.status = "pending"
```

### Transactions
```python
async with connector.transaction() as conn:
    # Use standard aiomysql cursor logic here
    pass
```
