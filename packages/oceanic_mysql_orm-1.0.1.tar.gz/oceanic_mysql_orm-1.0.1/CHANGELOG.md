# Changelog

All notable changes to **oceanic-mysql-orm** are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.0.1] - 2026-04-19

### Changed
- Repository cleanup: Removed `examples/` directory and `docker-compose.yml` to keep the source distribution lightweight and focused.
- Updated `README.md`, `pyproject.toml`, and `MANIFEST.in` to reflect the cleaner project structure.


## [1.0.0] - 2026-04-19

### Added
- Declarative `MySQLModel` base class with auto-registration via metaclass.
- `Field()`, `Relation()`, and `JSONField()` descriptors.
- Full async connection pool built on `aiomysql`.
- LoopBack-style filter DSL: `where`, `order`, `limit`, `skip`, `fields`, `include`.
- Supported operators: `eq`, `neq`, `gt`, `gte`, `lt`, `lte`, `like`, `nlike`,
  `inq`, `nin`, `between`, `regexp`, plus logical `or`.
- All four relation types: `hasOne`, `hasMany`, `belongsTo`, `hasManyThrough`.
- Nested relation loading with a batched IN-clause strategy (no N+1).
- Scoped includes — filter, sort, and limit inside each relation independently.
- Typed model instances with full autocomplete.
- `RelationNotLoadedError` raised on access to an unloaded relation.
- Transaction support via `async with connector.transaction()`.
- Raw SQL escape hatch via `connector.raw(...)`.
- Schema `Migrator` — auto-create tables and add missing columns from model
  definitions.
- FastAPI integration example (`examples/social_sphere/`).
- PEP 561 `py.typed` marker for downstream type checkers.

### Packaging
- Hatchling build backend.
- Dynamic `__version__` (single source of truth in `src/mysql_connector/__init__.py`).
- SPDX license metadata (`license = "MIT"`, `license-files = ["LICENSE"]`).
- Optional extras: `fastapi`, `test`, `dev`.

[Unreleased]: https://github.com/maheshpulivarthi/mysql-connector-async-orm/compare/v1.0.1...HEAD
[1.0.1]: https://github.com/maheshpulivarthi/mysql-connector-async-orm/compare/v1.0.0...v1.0.1
[1.0.0]: https://github.com/maheshpulivarthi/mysql-connector-async-orm/releases/tag/v1.0.0
