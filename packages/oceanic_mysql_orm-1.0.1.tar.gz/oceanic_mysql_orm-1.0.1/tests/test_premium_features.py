import pytest
import json
from mysql_connector import MySQLModel, Field, JSONField
from mysql_connector.query_builder import QueryBuilder

class PremiumUser(MySQLModel):
    __table__ = "premium_users"
    id:         int            = Field(primary_key=True)
    name:       str            = Field(max_length=100)
    settings:   dict           = JSONField(default={})
    created_at: str            = Field(auto_now_add=True)
    updated_at: str            = Field(auto_now=True)
    deleted_at: str            = Field(nullable=True)

def test_json_serialization_logic():
    """Unit test for JSON serialization in QueryBuilder."""
    qb = QueryBuilder("premium_users", PremiumUser._fields)
    sql, params = qb.build_insert({"name": "Raj", "settings": {"theme": "dark"}})
    
    # params[1] should be the settings field, serialized as a JSON string
    assert isinstance(params[1], str)
    assert json.loads(params[1]) == {"theme": "dark"}

def test_json_deserialization_logic():
    """Unit test for JSON deserialization in MySQLModel."""
    row = {
        "id": 1,
        "name": "Raj",
        "settings": '{"theme": "light", "notifications": true}'
    }
    user = PremiumUser._from_row(row)
    assert isinstance(user.settings, dict)
    assert user.settings["theme"] == "light"
    assert user.settings["notifications"] is True

@pytest.mark.asyncio
async def test_hooks(connector):
    """Test model hooks (before/after create)."""
    
    class HookedUser(MySQLModel):
        __table__ = "hooked_users"
        id:   int = Field(primary_key=True)
        name: str = Field(max_length=50)
        
        async def before_create(self):
            self.name = f"PRE-{self.name}"
            
    from mysql_connector.registry import registry
    registry.register(HookedUser)
    await connector.migrate()
    
    user = await connector.create(HookedUser, {"name": "Test"})
    assert user.name == "PRE-Test"
    
    await connector.raw_execute("DROP TABLE hooked_users")
