import pytest
import asyncio
from mysql_connector import MySQLConnector

@pytest.fixture(scope="session")
def event_loop():
    """Create an instance of the default event loop for each test case."""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()

@pytest.fixture(scope="session")
async def connector():
    """Session-wide connector fixture."""
    conn = MySQLConnector(
        host="127.0.0.1",
        port=3307,
        user="root",
        password="secret",
        database="test_db"
    )
    
    # Create test database if it doesn't exist (using raw pymysql for bootstrapping)
    import pymysql
    bootstrap = pymysql.connect(host='127.0.0.1', port=3307, user='root', password='secret')
    with bootstrap.cursor() as cursor:
        cursor.execute("CREATE DATABASE IF NOT EXISTS test_db")
    bootstrap.commit()
    bootstrap.close()

    await conn.connect()
    yield conn
    await conn.disconnect()

@pytest.fixture(autouse=True)
async def cleanup_db(connector):
    """Clean up the database before each test."""
    # We can't easily truncate all without knowing models, 
    # but tests should probably handle their own tables or we can drop all here.
    # For now, let's just provide the connector.
    yield
