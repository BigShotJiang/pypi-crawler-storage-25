"""Handler for JWT token authentication."""

from hivelms_client.http_client import HiveHttpClient
from hivelms_client.models.auth import (
    AuthTokenResponse,
    AuthTokenRefreshRequest,
    AuthTokenRequest,
)

TOKEN_ENDPOINT = "token/"
TOKEN_REFRESH_ENDPOINT = "token/refresh/"


class TokenHandler:
    """Handler for obtaining and refreshing JWT access tokens."""

    def __init__(self, http_client: HiveHttpClient):
        self._http_client = http_client

    def create(self, request: AuthTokenRequest) -> AuthTokenResponse:
        """Fetch a new JWT token pair using credentials.

        Args:
            request: Username and password credentials.

        Returns:
            The access and refresh token pair.
        """
        return self._http_client.post(
            TOKEN_ENDPOINT, body=request, response_model=AuthTokenResponse
        )

    def refresh(self, request: AuthTokenRefreshRequest) -> AuthTokenResponse:
        """Obtain a new access token using a refresh token.

        Args:
            request: The refresh token.

        Returns:
            A new access and refresh token pair.
        """
        return self._http_client.post(
            TOKEN_REFRESH_ENDPOINT, body=request, response_model=AuthTokenResponse
        )
