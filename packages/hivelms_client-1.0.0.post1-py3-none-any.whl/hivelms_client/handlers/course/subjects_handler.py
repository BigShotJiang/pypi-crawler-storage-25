"""Handler for the subjects resource."""

from hivelms_client.http_client import HiveHttpClient
from hivelms_client.models.course.subject import Subject, SubjectInput, SubjectPatch


class SubjectsHandler:
    """CRUD handler for course subjects."""

    def __init__(self, http_client: HiveHttpClient):
        self._http_client = http_client

    def search(self, *, parent_program_id_in: list[int] | None = None) -> list:
        """Return subjects, optionally filtered by parent program IDs.

        Args:
            parent_program_id_in: Restrict results to subjects belonging to these program IDs.

        Returns:
            A list of subjects as dicts.
        """
        return self._http_client.get(
            "/", response_model=list[dict], parent_program__id__in=parent_program_id_in
        )

    def create(self, subject_request: SubjectInput) -> Subject:
        """Create a new subject.

        Args:
            subject_request: Data for the subject to create.

        Returns:
            The newly created subject.
        """
        return self._http_client.post("/", body=subject_request, response_model=Subject)

    def get(self, id_: int) -> Subject:
        """Retrieve a single subject by ID.

        Args:
            id_: The subject ID.

        Returns:
            The matching subject.
        """
        return self._http_client.get(f"/{id_}/", response_model=Subject)

    def update(self, id_: int, subject_request: SubjectInput) -> Subject:
        """Fully replace a subject.

        Args:
            id_: The subject ID.
            subject_request: Replacement data for the subject.

        Returns:
            The updated subject.
        """
        return self._http_client.put(
            f"/{id_}/", body=subject_request, response_model=Subject
        )

    def patch(self, id_: int, subject_patch: SubjectPatch) -> Subject:
        """Partially update a subject.

        Args:
            id_: The subject ID.
            subject_patch: Fields to update on the subject.

        Returns:
            The updated subject.
        """
        return self._http_client.patch(
            f"/{id_}/", body=subject_patch, response_model=Subject
        )

    def delete(self, id_: int) -> None:
        """Delete a subject.

        Args:
            id_: The subject ID.
        """
        self._http_client.delete(f"/{id_}/", response_model=None)
