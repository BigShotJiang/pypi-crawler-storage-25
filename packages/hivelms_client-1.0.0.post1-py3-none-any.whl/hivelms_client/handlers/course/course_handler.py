"""Handler for all course-structure resources."""

from hivelms_client.handlers.course.exercises_handler import ExercisesHandler
from hivelms_client.handlers.course.modules_handler import ModulesHandler
from hivelms_client.handlers.course.programs_handler import ProgramsHandler
from hivelms_client.handlers.course.subjects_handler import SubjectsHandler
from hivelms_client.http_client import HiveHttpClient


class CourseHandler:
    """Namespace handler for course-structure sub-resources.

    Attributes:
        modules: Handler for modules.
        exercises: Handler for exercises (includes ``fields`` sub-handler).
        subjects: Handler for subjects.
        programs: Handler for programs.
    """

    def __init__(self, http_client: HiveHttpClient) -> None:
        """Initialize."""
        self._http_client = http_client

        self.modules = ModulesHandler(http_client.get_subclient("/modules"))
        self.exercises = ExercisesHandler(http_client.get_subclient("/exercises"))
        self.subjects = SubjectsHandler(http_client.get_subclient("/subjects"))
        self.programs = ProgramsHandler(http_client.get_subclient("/programs"))
