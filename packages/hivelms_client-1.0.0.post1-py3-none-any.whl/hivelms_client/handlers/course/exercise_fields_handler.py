"""Handler for exercise form fields resource."""

from hivelms_client.http_client import HiveHttpClient
from hivelms_client.models.course.exercise.form_field import (
    FormField,
    FormFieldInput,
    FormFieldPatch,
    FormFieldDuplicationRequest,
)

EXERCISES_ENDPOINT = "course/exercises"
FIELDS_ENDPOINT = "fields"


class ExerciseFieldsHandler:
    """CRUD handler for exercise form fields."""

    def __init__(self, http_client: HiveHttpClient):
        self._http_client = http_client

    def search(self, exercise_id: int) -> list[FormField]:
        """Return all fields for an exercise.

        Args:
            exercise_id: The exercise ID.

        Returns:
            A list of form fields for the exercise.
        """
        return self._http_client.get(
            f"/{exercise_id}/{FIELDS_ENDPOINT}/", response_model=list[FormField]
        )

    def create(self, exercise_id: int, creation_request: FormFieldInput) -> FormField:
        """Create a new field on an exercise.

        Args:
            exercise_id: The exercise ID.
            creation_request: Data for the field to create.

        Returns:
            The newly created form field.
        """
        return self._http_client.post(
            f"/{exercise_id}/{FIELDS_ENDPOINT}/",
            body=creation_request,
            response_model=FormField,
        )

    def get(self, exercise_id: int, field_id: int) -> FormField:
        """Retrieve a single exercise field.

        Args:
            exercise_id: The exercise ID.
            field_id: The field ID.

        Returns:
            The matching form field.
        """
        return self._http_client.get(
            f"/{exercise_id}/{FIELDS_ENDPOINT}/{field_id}/", response_model=FormField
        )

    def update(
        self, exercise_id: int, field_id: int, field_request: FormFieldInput
    ) -> FormField:
        """Fully replace an exercise field.

        Args:
            exercise_id: The exercise ID.
            field_id: The field ID.
            field_request: Replacement data for the field.

        Returns:
            The updated form field.
        """
        return self._http_client.put(
            f"/{exercise_id}/{FIELDS_ENDPOINT}/{field_id}/",
            body=field_request,
            response_model=FormField,
        )

    def patch(
        self, exercise_id: int, field_id: int, field_patch: FormFieldPatch
    ) -> FormField:
        """Partially update an exercise field.

        Args:
            exercise_id: The exercise ID.
            field_id: The field ID.
            field_patch: Fields to update on the form field.

        Returns:
            The updated form field.
        """
        return self._http_client.patch(
            f"/{exercise_id}/{FIELDS_ENDPOINT}/{field_id}/",
            body=field_patch,
            response_model=FormField,
        )

    def delete(self, exercise_id: int, field_id: int) -> None:
        """Delete an exercise field.

        Args:
            exercise_id: The exercise ID.
            field_id: The field ID.
        """
        return self._http_client.delete(
            f"/{exercise_id}/{FIELDS_ENDPOINT}/{field_id}/", response_model=None
        )

    def duplicate(
        self,
        exercise_id: int,
        field_id: int,
        duplication_request: FormFieldDuplicationRequest,
    ) -> FormField:
        """Duplicate an exercise field.

        Args:
            exercise_id: The exercise ID.
            field_id: The field ID to duplicate.
            duplication_request: Options controlling the duplication.

        Returns:
            The newly duplicated form field.
        """
        return self._http_client.post(
            f"/{exercise_id}/{FIELDS_ENDPOINT}/{field_id}/duplicate/",
            body=duplication_request,
            response_model=FormField,
        )

    def list_with_top_results(self, exercise_id: int) -> list[FormField]:
        """Return fields for an exercise annotated with top submission results.

        Args:
            exercise_id: The exercise ID.

        Returns:
            A list of form fields with top result data.
        """
        return self._http_client.get(
            f"/{exercise_id}/{FIELDS_ENDPOINT}/list_with_top_results/",
            response_model=list[FormField],
        )
