"""Handler for the exercises resource."""

from hivelms_client.http_client import HiveHttpClient
from hivelms_client.handlers.course.exercise_fields_handler import ExerciseFieldsHandler
from hivelms_client.models.course.exercise.exercise import (
    Exercise,
    ExerciseInput,
    ExercisePatch,
)
from hivelms_client.models.assignments.assignment_response import (
    AssignmentBulkCommentInput,
)
from hivelms_client.models.file_response import FileResponse


class ExercisesHandler:
    """CRUD handler for exercises, with a nested fields sub-handler.

    Attributes:
        fields: Handler for exercise form fields.
    """

    def __init__(self, http_client: HiveHttpClient):
        self._http_client = http_client
        self.fields = ExerciseFieldsHandler(http_client)

    def search(
        self,
        *,
        id: int | None = None,
        parent_module_id: int | None = None,
        parent_module_parent_subject_id: int | None = None,
        parent_program_id_in: list[int] | None = None,
        queue_id: int | None = None,
        tags_id_in: list[int] | None = None,
    ) -> list[Exercise]:
        """Return exercises, optionally filtered by module, subject, program, queue, or tags.

        Args:
            id: Exact exercise ID.
            parent_module_id: Restrict to exercises in this module.
            parent_module_parent_subject_id: Restrict to exercises whose module belongs to this subject.
            parent_program_id_in: Restrict to exercises belonging to these program IDs.
            queue_id: Restrict to exercises assigned to this queue.
            tags_id_in: Restrict to exercises tagged with any of these tag IDs.

        Returns:
            A list of matching exercises.
        """
        return self._http_client.get(
            "/",
            response_model=list[Exercise],
            id=id,
            parent_module__id=parent_module_id,
            parent_module__parent_subject__id=parent_module_parent_subject_id,
            parent_module__parent_subject__parent_program__id__in=parent_program_id_in,
            queue__id=queue_id,
            tags__id__in=tags_id_in,
        )

    def create(self, exercise_request: ExerciseInput) -> Exercise:
        """Create a new exercise.

        Args:
            exercise_request: Data for the exercise to create.

        Returns:
            The newly created exercise.
        """
        return self._http_client.post(
            "/", body=exercise_request, response_model=Exercise
        )

    def get(self, id_: int) -> Exercise:
        """Retrieve a single exercise by ID.

        Args:
            id_: The exercise ID.

        Returns:
            The matching exercise.
        """
        return self._http_client.get(f"/{id_}/", response_model=Exercise)

    def update(self, id_: int, exercise_request: ExerciseInput) -> Exercise:
        """Fully replace an exercise.

        Args:
            id_: The exercise ID.
            exercise_request: Replacement data for the exercise.

        Returns:
            The updated exercise.
        """
        return self._http_client.put(
            f"/{id_}/", body=exercise_request, response_model=Exercise
        )

    def patch(self, id_: int, exercise_patch: ExercisePatch) -> Exercise:
        """Partially update an exercise.

        Args:
            id_: The exercise ID.
            exercise_patch: Fields to update on the exercise.

        Returns:
            The updated exercise.
        """
        return self._http_client.patch(
            f"/{id_}/", body=exercise_patch, response_model=Exercise
        )

    def delete(self, id_: int) -> None:
        """Delete an exercise.

        Args:
            id_: The exercise ID.
        """
        self._http_client.delete(f"/{id_}/", response_model=None)

    def notify_students(self, id_: int, request: AssignmentBulkCommentInput) -> None:
        """Send a bulk notification to students assigned to this exercise.

        Args:
            id_: The exercise ID.
            request: Notification content.
        """
        return self._http_client.post(
            f"/{id_}/notify_students/", body=request, response_model=None
        )

    def get_patbas_files(self, id_: int) -> FileResponse:
        """Retrieve the patbas files for an exercise.

        Args:
            id_: The exercise ID.

        Returns:
            The file response containing patbas files.
        """
        return self._http_client.get(
            f"/{id_}/patbas_files/", response_model=FileResponse
        )

    def get_patbas_preview(self, id_: int) -> FileResponse:
        """Retrieve the patbas preview for an exercise.

        Args:
            id_: The exercise ID.

        Returns:
            The file response containing the patbas preview.
        """
        return self._http_client.get(
            f"/{id_}/patbas_preview/", response_model=FileResponse
        )

    def get_preview(self, id_: int) -> FileResponse:
        """Retrieve the exercise preview file.

        Args:
            id_: The exercise ID.

        Returns:
            The file response containing the preview.
        """
        return self._http_client.get(f"/{id_}/preview/", response_model=FileResponse)

    def get_student_files(self, id_: int) -> FileResponse:
        """Retrieve the student-facing files for an exercise.

        Args:
            id_: The exercise ID.

        Returns:
            The file response containing student files.
        """
        return self._http_client.get(
            f"/{id_}/student_files/", response_model=FileResponse
        )
