"""Handler for the programs resource."""

from hivelms_client.http_client import HiveHttpClient
from hivelms_client.models.course.program import Program, ProgramInput, ProgramPatch


class ProgramsHandler:
    """CRUD handler for course programs."""

    def __init__(self, http_client: HiveHttpClient):
        self._http_client = http_client

    def search(self) -> list[Program]:
        """Return all programs.

        Returns:
            A list of all programs.
        """
        return self._http_client.get("/", response_model=list[Program])

    def create(self, program_request: ProgramInput) -> Program:
        """Create a new program.

        Args:
            program_request: Data for the program to create.

        Returns:
            The newly created program.
        """
        return self._http_client.post("/", body=program_request, response_model=Program)

    def get(self, id_: int) -> Program:
        """Retrieve a single program by ID.

        Args:
            id_: The program ID.

        Returns:
            The matching program.
        """
        return self._http_client.get(f"/{id_}/", response_model=Program)

    def update(self, id_: int, program_request: ProgramInput) -> Program:
        """Fully replace a program.

        Args:
            id_: The program ID.
            program_request: Replacement data for the program.

        Returns:
            The updated program.
        """
        return self._http_client.put(
            f"/{id_}/", body=program_request, response_model=Program
        )

    def patch(self, id_: int, program_patch: ProgramPatch) -> Program:
        """Partially update a program.

        Args:
            id_: The program ID.
            program_patch: Fields to update on the program.

        Returns:
            The updated program.
        """
        return self._http_client.patch(
            f"/{id_}/", body=program_patch, response_model=Program
        )

    def delete(self, id_: int) -> None:
        """Delete a program.

        Args:
            id_: The program ID.
        """
        self._http_client.delete(f"/{id_}/", response_model=None)
