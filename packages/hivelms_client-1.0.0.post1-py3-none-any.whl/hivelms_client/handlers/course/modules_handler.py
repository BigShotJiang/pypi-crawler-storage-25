"""Handler for the modules resource."""

from hivelms_client.http_client import HiveHttpClient
from hivelms_client.models.course.module import Module, ModuleInput, ModulePatch


class ModulesHandler:
    """CRUD handler for course modules."""

    def __init__(self, http_client: HiveHttpClient):
        self._http_client = http_client

    def search(self, *, parent_subject: int | None = None) -> list[Module]:
        """Return modules, optionally filtered by parent subject.

        Args:
            parent_subject: Restrict results to modules belonging to this subject ID.

        Returns:
            A list of matching modules.
        """
        return self._http_client.get(
            "/", response_model=list[Module], parent_subject__id=parent_subject
        )

    def create(self, module_request: ModuleInput) -> Module:
        """Create a new module.

        Args:
            module_request: Data for the module to create.

        Returns:
            The newly created module.
        """
        return self._http_client.post("/", body=module_request, response_model=Module)

    def get(self, id_: int) -> Module:
        """Retrieve a single module by ID.

        Args:
            id_: The module ID.

        Returns:
            The matching module.
        """
        return self._http_client.get(f"/{id_}/", response_model=Module)

    def update(self, id_: int, module_request: ModuleInput) -> Module:
        """Fully replace a module.

        Args:
            id_: The module ID.
            module_request: Replacement data for the module.

        Returns:
            The updated module.
        """
        return self._http_client.put(
            f"/{id_}/", body=module_request, response_model=Module
        )

    def patch(self, id_: int, module_patch: ModulePatch) -> Module:
        """Partially update a module.

        Args:
            id_: The module ID.
            module_patch: Fields to update on the module.

        Returns:
            The updated module.
        """
        return self._http_client.patch(
            f"/{id_}/", body=module_patch, response_model=Module
        )

    def delete(self, id_: int) -> None:
        """Delete a module.

        Args:
            id_: The module ID.
        """
        return self._http_client.delete(f"/{id_}/", response_model=None)
