"""Handler for the users resource."""

from hivelms_client.http_client import HiveHttpClient
from hivelms_client.models.file_response import FileResponse
from hivelms_client.models.management.users.current_user import (
    CurrentUserCore,
    BaseCurrentUserPatch,
    CurrentUser,
)
from hivelms_client.models.management.users.user import UserInput, User, UserPatch


class UsersHandler:
    """CRUD handler for user accounts, with a nested me sub-handler.

    Attributes:
        me: Handler for the currently authenticated user's own profile.
    """

    def __init__(self, http_client: HiveHttpClient):
        self._http_client = http_client
        self.me = MeHandler(http_client.get_subclient("/me"))

    def search(self) -> list[User]:
        """Return all users.

        Returns:
            A list of all users.
        """
        return self._http_client.get("/", response_model=list[User])

    def create(self, new_user: UserInput) -> User:
        """Create a new user account.

        Args:
            new_user: Data for the user to create.

        Returns:
            The newly created user.
        """
        return self._http_client.post("/", body=new_user, response_model=User)

    def get(self, id_: int) -> User:
        """Retrieve a single user by ID.

        Args:
            id_: The user ID.

        Returns:
            The matching user.
        """
        return self._http_client.get(f"/{id_}/", response_model=User)

    def update(self, id_: int, updated_user: UserInput) -> User:
        """Fully replace a user account.

        Args:
            id_: The user ID.
            updated_user: Replacement data for the user.

        Returns:
            The updated user.
        """
        return self._http_client.put(f"/{id_}/", body=updated_user, response_model=User)

    def patch(self, id_: int, request: UserPatch) -> User:
        """Partially update a user account.

        Args:
            id_: The user ID.
            request: Fields to update on the user.

        Returns:
            The updated user.
        """
        return self._http_client.patch(f"/{id_}/", body=request, response_model=User)

    def delete(self, id_: int) -> None:
        """Delete a user account.

        Args:
            id_: The user ID.
        """
        self._http_client.delete(f"/{id_}/", response_model=None)

    def get_avatar(self, id_: int) -> FileResponse:
        """Retrieve a user's avatar image.

        Args:
            id_: The user ID.

        Returns:
            The file response containing the avatar.
        """
        return self._http_client.get(f"/{id_}/avatar/", response_model=FileResponse)

    def check_in(self) -> None:
        """Mark the current user as checked in."""
        self._http_client.put("/check_in/", response_model=None)


class MeHandler:
    """Handler for the authenticated user's own profile."""

    def __init__(self, http_client: HiveHttpClient):
        self._http_client = http_client

    def get(self) -> CurrentUserCore:
        """Retrieve the current user's profile.

        Returns:
            The current user's profile data.
        """
        return self._http_client.get("/", response_model=CurrentUser)

    def patch(self, request: BaseCurrentUserPatch) -> CurrentUserCore:
        """Partially update the current user's profile.

        Args:
            request: Fields to update on the current user's profile.

        Returns:
            The updated current user profile.
        """
        return self._http_client.patch("/", body=request, response_model=CurrentUser)
