"""Handler for the classes resource."""

from hivelms_client.http_client import HiveHttpClient
from hivelms_client.models.management.class_ import (
    Class,
    ClassInput,
    ClassPatch,
    SetClassLessonRequest,
    SetClassQueueRequest,
)

MANAGEMENT_CLASSES_ENDPOINT = "management/classes"


class ClassesHandler:
    """CRUD handler for student classes."""

    def __init__(self, http_client: HiveHttpClient):
        self._http_client = http_client

    def search(self) -> list[Class]:
        """Return all classes.

        Returns:
            A list of all classes.
        """
        return self._http_client.get("/", response_model=list[Class])

    def create(self, student_group_request: ClassInput) -> Class:
        """Create a new class.

        Args:
            student_group_request: Data for the class to create.

        Returns:
            The newly created class.
        """
        return self._http_client.post(
            "/", body=student_group_request, response_model=Class
        )

    def get(self, id_: int) -> Class:
        """Retrieve a single class by ID.

        Args:
            id_: The class ID.

        Returns:
            The matching class.
        """
        return self._http_client.get(f"/{id_}/", response_model=Class)

    def update(self, id_: int, student_group_request: ClassInput) -> Class:
        """Fully replace a class.

        Args:
            id_: The class ID.
            student_group_request: Replacement data for the class.

        Returns:
            The updated class.
        """
        return self._http_client.put(
            f"/{id_}/", body=student_group_request, response_model=Class
        )

    def patch(self, id_: int, student_group_patch: ClassPatch) -> Class:
        """Partially update a class.

        Args:
            id_: The class ID.
            student_group_patch: Fields to update on the class.

        Returns:
            The updated class.
        """
        return self._http_client.patch(
            f"/{id_}/", body=student_group_patch, response_model=Class
        )

    def delete(self, id_: int) -> None:
        """Delete a class.

        Args:
            id_: The class ID.
        """
        return self._http_client.delete(f"/{id_}/", response_model=None)

    def auto_seat(self, id_: int) -> None:
        """Automatically assign seats for all students in a class.

        Args:
            id_: The class ID.
        """
        return self._http_client.post(f"/{id_}/auto_seat/", response_model=None)

    def set_lesson(self, id_: int, request: SetClassLessonRequest) -> None:
        """Assign a lesson to a class.

        Args:
            id_: The class ID.
            request: The lesson assignment details.
        """
        return self._http_client.post(
            f"/{id_}/lesson/", body=request, response_model=None
        )

    def set_queue(self, id_: int, request: SetClassQueueRequest) -> None:
        """Assign a queue to a class.

        Args:
            id_: The class ID.
            request: The queue assignment details.
        """
        return self._http_client.post(
            f"/{id_}/queue/", body=request, response_model=None
        )

    def unassign_override_queues(self, id_: int) -> None:
        """Remove all override queue assignments from a class.

        Args:
            id_: The class ID.
        """
        self._http_client.patch(
            f"/{id_}/unassign_override_queues/", response_model=None
        )
