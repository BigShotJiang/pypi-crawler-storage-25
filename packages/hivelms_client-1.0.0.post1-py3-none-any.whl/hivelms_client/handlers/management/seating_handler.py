"""Handler for the seating resource."""

from hivelms_client.http_client import HiveHttpClient
from hivelms_client.models.management.seating import Seating, SeatingInput, SeatingPatch

MANAGEMENT_SEATING_ENDPOINT = "management/seating"


class SeatingHandler:
    """CRUD handler for seating arrangements."""

    def __init__(self, http_client: HiveHttpClient):
        self._http_client = http_client

    def search(self) -> list[Seating]:
        """Return all seating records.

        Returns:
            A list of all seating arrangements.
        """
        return self._http_client.get("/", response_model=list[Seating])

    def create(self, request: SeatingInput) -> Seating:
        """Create a new seating record.

        Args:
            request: Data for the seating arrangement to create.

        Returns:
            The newly created seating arrangement.
        """
        return self._http_client.post("/", body=request, response_model=Seating)

    def get(self, id_: int) -> Seating:
        """Retrieve a single seating record by ID.

        Args:
            id_: The seating record ID.

        Returns:
            The matching seating arrangement.
        """
        return self._http_client.get(f"/{id_}/", response_model=Seating)

    def update(self, id_: int, request: SeatingInput) -> Seating:
        """Fully replace a seating record.

        Args:
            id_: The seating record ID.
            request: Replacement data for the seating arrangement.

        Returns:
            The updated seating arrangement.
        """
        return self._http_client.put(f"/{id_}/", body=request, response_model=Seating)

    def patch(self, id_: int, request: SeatingPatch) -> Seating:
        """Partially update a seating record.

        Args:
            id_: The seating record ID.
            request: Fields to update on the seating arrangement.

        Returns:
            The updated seating arrangement.
        """
        return self._http_client.patch(f"/{id_}/", body=request, response_model=Seating)

    def delete(self, id_: int) -> None:
        """Delete a seating record.

        Args:
            id_: The seating record ID.
        """
        self._http_client.delete(f"/{id_}/", response_model=None)
