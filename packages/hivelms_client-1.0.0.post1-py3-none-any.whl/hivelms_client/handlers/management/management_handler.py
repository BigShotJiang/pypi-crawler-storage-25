"""Handler for the management resource."""

from hivelms_client.http_client import HiveHttpClient
from hivelms_client.models.management.registration import (
    RegistrationRequest,
    Registration,
)
from hivelms_client.handlers.management.classes_handler import ClassesHandler
from hivelms_client.handlers.management.seating_handler import SeatingHandler
from hivelms_client.handlers.management.users_handler import UsersHandler


class ManagementHandler:
    """Top-level handler for management resources.

    Attributes:
        classes: Handler for student classes.
        seating: Handler for seating arrangements.
        users: Handler for user accounts.
    """

    def __init__(self, http_client: HiveHttpClient):
        self._http_client = http_client
        self.classes = ClassesHandler(http_client.get_subclient("/classes"))
        self.seating = SeatingHandler(http_client.get_subclient("/seating"))
        self.users = UsersHandler(http_client.get_subclient("/users"))

    def register(self, request: RegistrationRequest) -> Registration:
        """Register a new user account.

        Args:
            request: Registration details for the new user.

        Returns:
            The completed registration record.
        """
        return self._http_client.post(
            "/register/", body=request, response_model=Registration
        )
