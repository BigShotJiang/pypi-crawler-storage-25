"""Handler for the lessons resource."""

from hivelms_client.http_client import HiveHttpClient
from hivelms_client.models.schedule.lesson import Lesson, LessonInput, LessonPatch
from hivelms_client.handlers.schedule.lesson_rules_handler import LessonRulesHandler


class LessonsHandler:
    """CRUD handler for lessons, with a nested rules sub-handler.

    Attributes:
        rules: Handler for lesson recurrence rules.
    """

    def __init__(self, http_client: HiveHttpClient):
        self._http_client = http_client
        self.rules = LessonRulesHandler(http_client)

    def search(
        self, *, start: str | None = None, end: str | None = None
    ) -> list[Lesson]:
        """Return lessons, optionally filtered by date range.

        Args:
            start: Return lessons that start on or after this datetime string.
            end: Return lessons that end on or before this datetime string.

        Returns:
            A list of matching lessons.
        """
        return self._http_client.get(
            "/", response_model=list[Lesson], start__gte=start, end__lte=end
        )

    def create(self, creation_request: LessonInput) -> Lesson:
        """Create a new lesson.

        Args:
            creation_request: Data for the lesson to create.

        Returns:
            The newly created lesson.
        """
        return self._http_client.post("/", body=creation_request, response_model=Lesson)

    def get(self, id_: int) -> Lesson:
        """Retrieve a single lesson by ID.

        Args:
            id_: The lesson ID.

        Returns:
            The matching lesson.
        """
        return self._http_client.get(f"/{id_}/", response_model=Lesson)

    def update(self, id_: int, update_request: LessonInput) -> Lesson:
        """Fully replace a lesson.

        Args:
            id_: The lesson ID.
            update_request: Replacement data for the lesson.

        Returns:
            The updated lesson.
        """
        return self._http_client.put(
            f"/{id_}/", body=update_request, response_model=Lesson
        )

    def patch(self, id_: int, patch_request: LessonPatch) -> Lesson:
        """Partially update a lesson.

        Args:
            id_: The lesson ID.
            patch_request: Fields to update on the lesson.

        Returns:
            The updated lesson.
        """
        return self._http_client.patch(
            f"/{id_}/", body=patch_request, response_model=Lesson
        )

    def delete(self, id_: int) -> None:
        """Delete a lesson.

        Args:
            id_: The lesson ID.
        """
        return self._http_client.delete(f"/{id_}/", response_model=None)
