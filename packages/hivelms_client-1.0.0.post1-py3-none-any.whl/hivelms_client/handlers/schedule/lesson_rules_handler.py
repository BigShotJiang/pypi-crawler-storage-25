"""Handler for lesson recurrence rules resource."""

from hivelms_client.http_client import HiveHttpClient
from hivelms_client.models.schedule.lesson import (
    LessonRule,
    LessonRuleInput,
    LessonRulePatch,
)


class LessonRulesHandler:
    """CRUD handler for lesson recurrence rules."""

    def __init__(self, http_client: HiveHttpClient):
        self._http_client = http_client

    def search(self, lesson_id: int) -> list[LessonRule]:
        """Return all recurrence rules for a lesson.

        Args:
            lesson_id: The lesson ID.

        Returns:
            A list of recurrence rules for the lesson.
        """
        return self._http_client.get(
            f"/{lesson_id}/rules/", response_model=list[LessonRule]
        )

    def create(self, lesson_id: int, request: LessonRuleInput) -> LessonRule:
        """Create a new recurrence rule on a lesson.

        Args:
            lesson_id: The lesson ID.
            request: Data for the rule to create.

        Returns:
            The newly created lesson rule.
        """
        return self._http_client.post(
            f"/{lesson_id}/rules/", body=request, response_model=LessonRule
        )

    def get(self, lesson_id: int, id_: int) -> LessonRule:
        """Retrieve a single lesson rule.

        Args:
            lesson_id: The lesson ID.
            id_: The rule ID.

        Returns:
            The matching lesson rule.
        """
        return self._http_client.get(
            f"/{lesson_id}/rules/{id_}/", response_model=LessonRule
        )

    def update(self, lesson_id: int, id_: int, request: LessonRuleInput) -> LessonRule:
        """Fully replace a lesson rule.

        Args:
            lesson_id: The lesson ID.
            id_: The rule ID.
            request: Replacement data for the rule.

        Returns:
            The updated lesson rule.
        """
        return self._http_client.put(
            f"/{lesson_id}/rules/{id_}/", body=request, response_model=LessonRule
        )

    def patch(self, lesson_id: int, id_: int, request: LessonRulePatch) -> LessonRule:
        """Partially update a lesson rule.

        Args:
            lesson_id: The lesson ID.
            id_: The rule ID.
            request: Fields to update on the lesson rule.

        Returns:
            The updated lesson rule.
        """
        return self._http_client.patch(
            f"/{lesson_id}/rules/{id_}/", body=request, response_model=LessonRule
        )

    def delete(self, lesson_id: int, id_: int) -> None:
        """Delete a lesson rule.

        Args:
            lesson_id: The lesson ID.
            id_: The rule ID.
        """
        return self._http_client.delete(
            f"/{lesson_id}/rules/{id_}/", response_model=None
        )
