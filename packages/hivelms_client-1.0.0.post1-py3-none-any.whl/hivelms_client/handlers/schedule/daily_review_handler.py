"""Handler for the daily review resource."""

from hivelms_client.http_client import HiveHttpClient
from hivelms_client.models.course.module import Module
from hivelms_client.models.schedule.daily_review import DailyReviewInput


class DailyReviewHandler:
    """Handler for creating daily review modules."""

    def __init__(self, http_client: HiveHttpClient):
        self._http_client = http_client

    def create(self, creation_request: DailyReviewInput) -> Module:
        """Create a daily review module for a given date.

        Args:
            creation_request: Data specifying the daily review to create.

        Returns:
            The newly created module for the daily review.
        """
        return self._http_client.post(
            "/daily_review/", body=creation_request, response_model=Module
        )
