"""Handler for the schedule resource."""

from hivelms_client.handlers.schedule.daily_review_handler import DailyReviewHandler
from hivelms_client.handlers.schedule.schedule_colors_handler import (
    ScheduleColorsHandler,
)
from hivelms_client.handlers.schedule.schedule_events_handler import (
    ScheduleEventsHandler,
)
from hivelms_client.handlers.schedule.lessons_handler import LessonsHandler
from hivelms_client.http_client import HiveHttpClient


class ScheduleHandler:
    """Top-level handler for schedule resources.

    Attributes:
        colors: Handler for schedule event colors.
        events: Handler for schedule events (read-only).
        lessons: Handler for lessons and lesson rules.
        daily_review: Handler for daily review module creation.
    """

    def __init__(self, http_client: HiveHttpClient):
        self._http_client = http_client
        self.colors = ScheduleColorsHandler(http_client.get_subclient("/colors"))
        self.events = ScheduleEventsHandler(http_client.get_subclient("/events"))
        self.lessons = LessonsHandler(http_client.get_subclient("/lessons"))
        self.daily_review = DailyReviewHandler(http_client)
