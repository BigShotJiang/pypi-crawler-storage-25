"""Handler for the schedule events resource (read-only)."""

from hivelms_client.http_client import HiveHttpClient
from hivelms_client.models.schedule.event import Event


class ScheduleEventsHandler:
    """Read-only handler for schedule events."""

    def __init__(self, http_client: HiveHttpClient):
        self._http_client = http_client

    def search(
        self,
        *,
        start: str | None = None,
        end: str | None = None,
        lesson_id: int | None = None,
    ) -> list[Event]:
        """Return schedule events, optionally filtered by date range or lesson.

        Args:
            start: Return events that start on or after this datetime string.
            end: Return events that end on or before this datetime string.
            lesson_id: Filter to events belonging to this lesson.

        Returns:
            A list of matching schedule events.
        """
        return self._http_client.get(
            "/",
            response_model=list[Event],
            start__gte=start,
            end__lte=end,
            lesson__id=lesson_id,
        )

    def get(self, event_id: int) -> Event:
        """Retrieve a single schedule event by ID.

        Args:
            event_id: The schedule event ID.

        Returns:
            The matching schedule event.
        """
        return self._http_client.get(f"/{event_id}/", response_model=Event)
