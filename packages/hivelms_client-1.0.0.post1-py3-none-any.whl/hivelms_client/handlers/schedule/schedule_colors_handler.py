"""Handler for the schedule event colors resource."""

from hivelms_client.http_client import HiveHttpClient
from hivelms_client.models.schedule.event_color import (
    EventColor,
    EventColorInput,
    EventColorPatch,
)

SCHEDULE_COLORS_ENDPOINT = "schedule/colors"


class ScheduleColorsHandler:
    """CRUD handler for schedule event colors."""

    def __init__(self, http_client: HiveHttpClient):
        self._http_client = http_client

    def search(self) -> list[EventColor]:
        """Return all event colors.

        Returns:
            A list of all event colors.
        """
        return self._http_client.get("/", response_model=list[EventColor])

    def create(self, request: EventColorInput) -> EventColor:
        """Create a new event color.

        Args:
            request: Data for the event color to create.

        Returns:
            The newly created event color.
        """
        return self._http_client.post("/", body=request, response_model=EventColor)

    def get(self, id_: int) -> EventColor:
        """Retrieve a single event color by ID.

        Args:
            id_: The event color ID.

        Returns:
            The matching event color.
        """
        return self._http_client.get(f"/{id_}/", response_model=EventColor)

    def update(self, id_: int, request: EventColorInput) -> EventColor:
        """Fully replace an event color.

        Args:
            id_: The event color ID.
            request: Replacement data for the event color.

        Returns:
            The updated event color.
        """
        return self._http_client.put(
            f"/{id_}/", body=request, response_model=EventColor
        )

    def patch(self, id_: int, request: EventColorPatch) -> EventColor:
        """Partially update an event color.

        Args:
            id_: The event color ID.
            request: Fields to update on the event color.

        Returns:
            The updated event color.
        """
        return self._http_client.patch(
            f"/{id_}/", body=request, response_model=EventColor
        )

    def delete(self, id_: int) -> None:
        """Delete an event color.

        Args:
            id_: The event color ID.
        """
        return self._http_client.delete(f"/{id_}/", response_model=None)
