"""Handler for the tags resource."""

from hivelms_client.http_client import HiveHttpClient
from hivelms_client.models.tag import Tag, TagInput, TagPatch


class TagsHandler:
    """CRUD handler for exercise tags."""

    def __init__(self, http_client: HiveHttpClient):
        self._http_client = http_client

    def search(self) -> list[Tag]:
        """Return all tags.

        Returns:
            A list of all tags.
        """
        return self._http_client.get("/", response_model=list[Tag])

    def create(self, tag_request: TagInput) -> Tag:
        """Create a new tag.

        Args:
            tag_request: Data for the tag to create.

        Returns:
            The newly created tag.
        """
        return self._http_client.post("/", body=tag_request, response_model=Tag)

    def get(self, id_: int) -> Tag:
        """Retrieve a single tag by ID.

        Args:
            id_: The tag ID.

        Returns:
            The matching tag.
        """
        return self._http_client.get(f"/{id_}/", response_model=Tag)

    def update(self, id_: int, tag_request: TagInput) -> Tag:
        """Fully replace a tag.

        Args:
            id_: The tag ID.
            tag_request: Replacement data for the tag.

        Returns:
            The updated tag.
        """
        return self._http_client.put(f"/{id_}/", body=tag_request, response_model=Tag)

    def patch(self, id_: int, tag_patch: TagPatch) -> Tag:
        """Partially update a tag.

        Args:
            id_: The tag ID.
            tag_patch: Fields to update on the tag.

        Returns:
            The updated tag.
        """
        return self._http_client.patch(f"/{id_}/", body=tag_patch, response_model=Tag)

    def delete(self, id_: int) -> None:
        """Delete a tag.

        Args:
            id_: The tag ID.
        """
        self._http_client.delete(f"/{id_}/", response_model=None)
