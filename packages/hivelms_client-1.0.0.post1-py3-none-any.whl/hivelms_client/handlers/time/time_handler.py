"""Handler for the server time resource."""

from datetime import datetime

from hivelms_client.http_client import HiveHttpClient


class TimeHandler:
    """Handler for retrieving the server's current time."""

    def __init__(self, http_client: HiveHttpClient):
        self._http_client = http_client

    def get(self) -> datetime:
        """Retrieve the server's current datetime.

        Returns:
            The server's current datetime.
        """
        return self._http_client.get("/", response_model=datetime)
