"""Handler for the queues resource."""

from typing_extensions import overload

from hivelms_client.handlers.queues.queues_items_handler import QueueItemsHandler
from hivelms_client.http_client import HiveHttpClient
from hivelms_client.models.queues.queue import (
    Queue,
    QueueInput,
    QueuePatch,
    QueueDuplicationRequest,
    UserQueueInput,
    ModuleQueueInput,
    ModuleQueue,
    UserQueue,
)

ITEMS_ENDPOINT = "items"

DUPLICATE_ENDPOINT = "duplicate"
DELETE_NEW_ENDPOINT = "delete_new"


class QueuesHandler:
    """CRUD handler for exercise queues, with a nested items sub-handler.

    Attributes:
        items: Handler for individual queue items.
    """

    def __init__(self, http_client: HiveHttpClient):
        self._http_client = http_client
        self.items = QueueItemsHandler(http_client)

    def search(
        self,
        *,
        class_id: int | None = None,
        mentor_id: int | None = None,
        module: int | None = None,
        module_is_null: bool | None = None,
        program_id_in: list[int] | None = None,
        user: int | None = None,
        user_is_null: bool | None = None,
    ) -> list[Queue]:
        """Return queues, optionally filtered by class, mentor, module, or user.

        Args:
            class_id: Filter by class ID.
            mentor_id: Filter by mentor user ID.
            module: Filter by module ID.
            module_is_null: Filter to queues without a module when True.
            program_id_in: Restrict to queues belonging to these program IDs.
            user: Filter by user ID.
            user_is_null: Filter to queues without an assigned user when True.

        Returns:
            A list of matching queues.
        """
        return self._http_client.get(
            "/",
            response_model=list[Queue],
            class__id=class_id,
            mentor__id=mentor_id,
            module=module,
            module__isnull=module_is_null,
            program__id__in=program_id_in,
            user=user,
            user__isnull=user_is_null,
        )

    @overload
    def create(self, queue: UserQueueInput) -> UserQueue: ...
    @overload
    def create(self, queue: ModuleQueueInput) -> ModuleQueue: ...

    def create(self, queue: QueueInput) -> Queue:
        """Create a new queue (user or module type).

        Args:
            queue: Data for the queue to create.

        Returns:
            The newly created queue.
        """
        return self._http_client.post("/", body=queue, response_model=Queue)

    def get(self, id_: int) -> Queue:
        """Retrieve a single queue by ID.

        Args:
            id_: The queue ID.

        Returns:
            The matching queue.
        """
        return self._http_client.get(f"/{id_}/", response_model=Queue)

    def update(self, id_: int, updated_queue: QueueInput) -> Queue:
        """Fully replace a queue.

        Args:
            id_: The queue ID.
            updated_queue: Replacement data for the queue.

        Returns:
            The updated queue.
        """
        return self._http_client.put(
            f"/{id_}/", body=updated_queue, response_model=Queue
        )

    def patch(self, id_: int, queue_patch: QueuePatch) -> Queue:
        """Partially update a queue.

        Args:
            id_: The queue ID.
            queue_patch: Fields to update on the queue.

        Returns:
            The updated queue.
        """
        return self._http_client.patch(
            f"/{id_}/", body=queue_patch, response_model=Queue
        )

    def delete(self, id_: int) -> None:
        """Delete a queue.

        Args:
            id_: The queue ID.
        """
        self._http_client.delete(f"/{id_}/", response_model=None)

    def duplicate(
        self, id_: int, duplication_request: QueueDuplicationRequest
    ) -> Queue:
        """Duplicate an existing queue.

        Args:
            id_: The queue ID to duplicate.
            duplication_request: Options controlling the duplication.

        Returns:
            The newly duplicated queue.
        """
        return self._http_client.post(
            f"/{id_}/{DUPLICATE_ENDPOINT}/",
            body=duplication_request,
            response_model=Queue,
        )

    def delete_new_assignments(self, queue_id: int) -> None:
        """Delete all new (unstarted) assignments in a queue.

        Args:
            queue_id: The queue ID.
        """
        self._http_client.post(
            f"/{queue_id}/{DELETE_NEW_ENDPOINT}/", response_model=None
        )
