"""Handler for queue items resource."""

from hivelms_client.http_client import HiveHttpClient
from hivelms_client.models.queues.queue_items import (
    QueueItem,
    QueueItemPatch,
    QueueItemInput,
    QueueItemMoveRequest,
)

ITEMS_ENDPOINT = "items"
EXPAND_ITEMS_ENDPOINT = "expand"
MOVE_ITEMS_ENDPOINT = "move"


class QueueItemsHandler:
    """CRUD handler for items within a queue."""

    def __init__(self, http_client: HiveHttpClient):
        self._http_client = http_client

    def search(self, queue_id: int) -> list[QueueItem]:
        """Return all items in a queue.

        Args:
            queue_id: The queue ID.

        Returns:
            A list of queue items.
        """
        return self._http_client.get(
            f"/{queue_id}/{ITEMS_ENDPOINT}/", response_model=list[QueueItem]
        )

    def create(self, queue_id: int, item: QueueItemInput) -> QueueItem:
        """Add a new item to a queue.

        Args:
            queue_id: The queue ID.
            item: Data for the queue item to create.

        Returns:
            The newly created queue item.
        """
        return self._http_client.post(
            f"/{queue_id}/{ITEMS_ENDPOINT}/", body=item, response_model=QueueItem
        )

    def get(self, queue_id: int, item_id: int) -> QueueItem:
        """Retrieve a single queue item.

        Args:
            queue_id: The queue ID.
            item_id: The queue item ID.

        Returns:
            The matching queue item.
        """
        return self._http_client.get(
            f"/{queue_id}/{ITEMS_ENDPOINT}/{item_id}/", response_model=QueueItem
        )

    def update(
        self, queue_id: int, item_id: int, updated_item: QueueItemInput
    ) -> QueueItem:
        """Fully replace a queue item.

        Args:
            queue_id: The queue ID.
            item_id: The queue item ID.
            updated_item: Replacement data for the queue item.

        Returns:
            The updated queue item.
        """
        return self._http_client.put(
            f"/{queue_id}/{ITEMS_ENDPOINT}/{item_id}/",
            body=updated_item,
            response_model=QueueItem,
        )

    def patch(
        self, queue_id: int, item_id: int, item_patch: QueueItemPatch
    ) -> QueueItem:
        """Partially update a queue item.

        Args:
            queue_id: The queue ID.
            item_id: The queue item ID.
            item_patch: Fields to update on the queue item.

        Returns:
            The updated queue item.
        """
        return self._http_client.patch(
            f"/{queue_id}/{ITEMS_ENDPOINT}/{item_id}/",
            body=item_patch,
            response_model=QueueItem,
        )

    def delete(self, queue_id: int, item_id: int) -> None:
        """Delete a queue item.

        Args:
            queue_id: The queue ID.
            item_id: The queue item ID.
        """
        return self._http_client.delete(
            f"/{queue_id}/{ITEMS_ENDPOINT}/{item_id}/", response_model=None
        )

    def expand(self, queue_id: int, item_id: int) -> None:
        """Expand a queue item (e.g. unfold its sub-exercises).

        Args:
            queue_id: The queue ID.
            item_id: The queue item ID.
        """
        return self._http_client.post(
            f"/{queue_id}/{ITEMS_ENDPOINT}/{item_id}/{EXPAND_ITEMS_ENDPOINT}/",
            response_model=None,
        )

    def move(
        self, queue_id: int, item_id: int, move_request: QueueItemMoveRequest
    ) -> QueueItem:
        """Move a queue item to a different position or queue.

        Args:
            queue_id: The source queue ID.
            item_id: The queue item ID.
            move_request: Target position or queue details.

        Returns:
            The moved queue item in its new position.
        """
        return self._http_client.post(
            f"/{queue_id}/{ITEMS_ENDPOINT}/{item_id}/{MOVE_ITEMS_ENDPOINT}/",
            body=move_request,
            response_model=QueueItem,
        )
