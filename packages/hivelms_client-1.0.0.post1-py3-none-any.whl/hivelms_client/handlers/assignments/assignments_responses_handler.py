"""Handler for assignment submission responses."""

from hivelms_client.http_client import HiveHttpClient
from hivelms_client.models.assignments.assignment_response import (
    AssignmentResponse,
    AssignmentResponseInput,
    AssignmentResponsePatch,
)
from hivelms_client.models.file_response import FileResponse

ASSIGNMENTS_ENDPOINT = "assignments"
RESPONSES_ENDPOINT = "responses"
RERUN_AUTOCHECKS_ENDPOINT = "rerun_autochecks"
STUDENT_FILES_ENDPOINT = "student_files"


class AssignmentResponsesHandler:
    """Handler for responses (submissions, comments, etc.) on an assignment."""

    def __init__(self, http_client: HiveHttpClient) -> None:
        """Initialize."""
        self._http_client = http_client

    def search(self, assignment_id: int) -> list[AssignmentResponse]:
        """Return all responses for an assignment.

        Args:
            assignment_id: Parent assignment ID.

        Returns:
            List of assignment responses.
        """
        return self._http_client.get(
            f"/{assignment_id}/{RESPONSES_ENDPOINT}/",
            response_model=list[AssignmentResponse],
        )

    def create(
        self, assignment_id: int, response_creation_request: AssignmentResponseInput
    ) -> AssignmentResponse:
        """Add a new response to an assignment.

        Args:
            assignment_id: Parent assignment ID.
            response_creation_request: Response data.

        Returns:
            The created response.
        """
        return self._http_client.post(
            f"/{assignment_id}/{RESPONSES_ENDPOINT}/",
            body=response_creation_request,
            response_model=AssignmentResponse,
        )

    def get(self, assignment_id: int, response_id: int) -> AssignmentResponse:
        """Fetch a single response.

        Args:
            assignment_id: Parent assignment ID.
            response_id: Response ID.

        Returns:
            The response.
        """
        return self._http_client.get(
            f"/{assignment_id}/{RESPONSES_ENDPOINT}/{response_id}/",
            response_model=AssignmentResponse,
        )

    def patch(
        self,
        assignment_id: int,
        response_id: int,
        response_patch: AssignmentResponsePatch,
    ) -> AssignmentResponse:
        """Partially update a response.

        Args:
            assignment_id: Parent assignment ID.
            response_id: Response ID.
            response_patch: Fields to change.

        Returns:
            The updated response.
        """
        return self._http_client.patch(
            f"/{assignment_id}/{RESPONSES_ENDPOINT}/{response_id}/",
            body=response_patch,
            response_model=AssignmentResponse,
        )

    def delete(self, assignment_id: int, response_id: int) -> None:
        """Delete a response.

        Args:
            assignment_id: Parent assignment ID.
            response_id: Response ID.
        """
        return self._http_client.delete(
            f"/{assignment_id}/{RESPONSES_ENDPOINT}/{response_id}/", response_model=None
        )

    def get_files(self, assignment_id: int, response_id: int) -> FileResponse:
        """Download the file attached to a response.

        Args:
            assignment_id: Parent assignment ID.
            response_id: Response ID.

        Returns:
            File response with filename, mimetype, and raw content.
        """
        return self._http_client.get(
            f"/{assignment_id}/{RESPONSES_ENDPOINT}/{response_id}/{STUDENT_FILES_ENDPOINT}/",
            response_model=FileResponse,
        )

    def rerun_autochecks(self, assignment_id: int, response_id: int) -> None:
        """Trigger autocheck re-evaluation for a response.

        Args:
            assignment_id: Parent assignment ID.
            response_id: Response ID.
        """
        return self._http_client.post(
            f"/{assignment_id}"
            f"/{RESPONSES_ENDPOINT}/{response_id}"
            f"/{RERUN_AUTOCHECKS_ENDPOINT}/",
            response_model=None,
        )
