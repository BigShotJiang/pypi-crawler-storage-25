"""Handler for the assignments resource."""

from hivelms_client.handlers.assignments.assignments_responses_handler import (
    AssignmentResponsesHandler,
)
from hivelms_client.http_client import HiveHttpClient
from hivelms_client.models.assignments.assignment import (
    AssignmentInput,
    Assignment,
    AssignmentNotification,
    AssignmentPatch,
)

LOCK_ENDPOINT = "lock"
UNLOCK_ENDPOINT = "unlock"
SUBSCRIBE_ENDPOINT = "subscribe"
UNSUBSCRIBE_ENDPOINT = "unsubscribe"
LATEST_ENDPOINT = "latest"

RERUN_AUTOCHECKS_ENDPOINT = "rerun_autochecks"
STUDENT_FILES_ENDPOINT = "student_files"


class AssignmentsHandler:
    """Handler for student assignments.

    Attributes:
        responses: Sub-handler for assignment submission responses.
    """

    def __init__(self, http_client: HiveHttpClient) -> None:
        """Initialize."""
        self._http_client = http_client
        self.responses = AssignmentResponsesHandler(http_client)

    def search(
        self,
        *,
        exercise_id: int | None = None,
        exercise_parent_module_id: int | None = None,
        exercise_parent_module_parent_subject_id: int | None = None,
        exercise_tags_id_in: list[int] | None = None,
        queue_id: int | None = None,
        user_classes_id: int | None = None,
        user_classes_id_in: list[int] | None = None,
        user_id_in: list[int] | None = None,
        user_mentor_id: int | None = None,
        user_mentor_id_in: list[int] | None = None,
        user_program_id_in: list[int] | None = None,
    ) -> list[Assignment]:
        """Return assignments, optionally filtered.

        Args:
            exercise_id: Filter by exercise ID.
            exercise_parent_module_id: Filter by parent module ID.
            exercise_parent_module_parent_subject_id: Filter by parent subject ID.
            exercise_tags_id_in: Filter by tag IDs (any match).
            queue_id: Filter by queue ID.
            user_classes_id: Filter by class ID.
            user_classes_id_in: Filter by class IDs (any match).
            user_id_in: Filter by user IDs (any match).
            user_mentor_id: Filter by mentor ID.
            user_mentor_id_in: Filter by mentor IDs (any match).
            user_program_id_in: Filter by program IDs (any match).

        Returns:
            List of matching assignments.
        """
        return self._http_client.get(
            "/",
            response_model=list[Assignment],
            exercise__id=exercise_id,
            exercise__parent_module__id=exercise_parent_module_id,
            exercise__parent_module__parent_subject__id=exercise_parent_module_parent_subject_id,
            exercise__tags__id__in=exercise_tags_id_in,
            queue__id=queue_id,
            user__classes__id=user_classes_id,
            user__classes__id__in=user_classes_id_in,
            user__id__in=user_id_in,
            user__mentor__id=user_mentor_id,
            user__mentor__id__in=user_mentor_id_in,
            user__program__id__in=user_program_id_in,
        )

    def create(self, assignment_request: AssignmentInput) -> Assignment:
        """Create a new assignment.

        Args:
            assignment_request: Assignment data.

        Returns:
            The created assignment.
        """
        return self._http_client.post(
            "/", body=assignment_request, response_model=Assignment
        )

    def get(self, id_: int) -> Assignment:
        """Fetch a single assignment by ID.

        Args:
            id_: Assignment ID.

        Returns:
            The assignment.
        """
        return self._http_client.get(f"/{id_}/", response_model=Assignment)

    def update(self, id_: int, assignment_request: AssignmentInput) -> Assignment:
        """Replace an assignment (full update).

        Args:
            id_: Assignment ID.
            assignment_request: Replacement data.

        Returns:
            The updated assignment.
        """
        return self._http_client.put(
            f"/{id_}/", body=assignment_request, response_model=Assignment
        )

    def patch(self, id_: int, assignment_patch: AssignmentPatch) -> Assignment:
        """Partially update an assignment.

        Args:
            id_: Assignment ID.
            assignment_patch: Fields to change; omitted fields are left unchanged.

        Returns:
            The updated assignment.
        """
        return self._http_client.patch(
            f"/{id_}/", body=assignment_patch, response_model=Assignment
        )

    def delete(self, id_: int) -> None:
        """Delete an assignment.

        Args:
            id_: Assignment ID.
        """
        self._http_client.delete(f"/{id_}/", response_model=None)

    def lock(self, id_: int) -> None:
        """Claim the assignment as the checking staff member.

        Args:
            id_: Assignment ID.
        """
        self._http_client.put(f"/{id_}/{LOCK_ENDPOINT}/", response_model=None)

    def unlock(self, id_: int) -> None:
        """Release the checker claim on an assignment.

        Args:
            id_: Assignment ID.
        """
        self._http_client.put(f"/{id_}/{UNLOCK_ENDPOINT}/", response_model=None)

    def subscribe(self, id_: int) -> None:
        """Subscribe to update notifications for an assignment.

        Args:
            id_: Assignment ID.
        """
        self._http_client.put(f"/{id_}/{SUBSCRIBE_ENDPOINT}/", response_model=None)

    def unsubscribe(self, id_: int) -> None:
        """Unsubscribe from update notifications for an assignment.

        Args:
            id_: Assignment ID.
        """
        self._http_client.put(f"/{id_}/{UNSUBSCRIBE_ENDPOINT}/", response_model=None)

    def get_latest(
        self,
        *,
        last_staff_updated_gt: str | None = None,
        user_classes_id: int | None = None,
        user_id_in: list[int] | None = None,
        user_mentor_id: int | None = None,
    ) -> list[AssignmentNotification]:
        """Return the latest assignment notification summaries.

        Args:
            last_staff_updated_gt: Include only assignments updated after this ISO datetime.
            user_classes_id: Filter by class ID.
            user_id_in: Filter by user IDs (any match).
            user_mentor_id: Filter by mentor ID.

        Returns:
            List of assignment notification items.
        """
        return self._http_client.get(
            f"/{LATEST_ENDPOINT}/",
            response_model=list[AssignmentNotification],
            last_staff_updated__gt=last_staff_updated_gt,
            user__classes__id=user_classes_id,
            user__id__in=user_id_in,
            user__mentor__id=user_mentor_id,
        )
