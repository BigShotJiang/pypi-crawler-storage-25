"""Handler for the notifications resource."""

from hivelms_client.http_client import HiveHttpClient
from hivelms_client.models.notification.notification import (
    Notification,
    NotificationInput,
    NotificationPatch,
)


class NotificationHandler:
    """CRUD handler for user notifications."""

    def __init__(self, http_client: HiveHttpClient):
        self._http_client = http_client

    def search(
        self,
        *,
        assignment: int | None = None,
        assignment_exercise: int | None = None,
        assignment_exercise_in: list[int] | None = None,
        from_user_isnull: bool | None = None,
        help_id: int | None = None,
        help_in: list[int] | None = None,
        was_read: bool | None = None,
    ) -> list[Notification]:
        """Return notifications, optionally filtered by assignment, help thread, or read status.

        Args:
            assignment: Filter by assignment ID.
            assignment_exercise: Filter by the assignment's exercise ID.
            assignment_exercise_in: Filter by any of these exercise IDs.
            from_user_isnull: Filter by whether the sender is null.
            help_id: Filter by help thread ID.
            help_in: Filter by any of these help thread IDs.
            was_read: Filter by read status.

        Returns:
            A list of matching notifications.
        """
        return self._http_client.get(
            "/",
            response_model=list[Notification],
            assignment=assignment,
            assignment__exercise=assignment_exercise,
            assignment__exercise__in=assignment_exercise_in,
            from_user__isnull=from_user_isnull,
            help=help_id,
            help__in=help_in,
            was_read=was_read,
        )

    def create(self, notification_data: NotificationInput) -> Notification:
        """Create a new notification.

        Args:
            notification_data: Data for the notification to create.

        Returns:
            The newly created notification.
        """
        return self._http_client.post(
            "/", body=notification_data, response_model=Notification
        )

    def get(self, id_: int) -> Notification:
        """Retrieve a single notification by ID.

        Args:
            id_: The notification ID.

        Returns:
            The matching notification.
        """
        return self._http_client.get(f"/{id_}/", response_model=Notification)

    def update(self, id_: int, notification_data: NotificationInput) -> Notification:
        """Fully replace a notification.

        Args:
            id_: The notification ID.
            notification_data: Replacement data for the notification.

        Returns:
            The updated notification.
        """
        return self._http_client.put(
            f"/{id_}/", body=notification_data, response_model=Notification
        )

    def patch(self, id_: int, notification_patch: NotificationPatch) -> Notification:
        """Partially update a notification.

        Args:
            id_: The notification ID.
            notification_patch: Fields to update on the notification.

        Returns:
            The updated notification.
        """
        return self._http_client.patch(
            f"/{id_}/", body=notification_patch, response_model=Notification
        )

    def delete(self, id_: int) -> None:
        """Delete a notification.

        Args:
            id_: The notification ID.
        """
        self._http_client.delete(f"/{id_}/", response_model=None)
