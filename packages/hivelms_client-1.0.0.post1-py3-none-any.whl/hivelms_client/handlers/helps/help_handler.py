"""Handler for the help threads resource."""

from typing import overload, Literal

from hivelms_client.handlers.helps.help_responses_handler import HelpResponsesHandler
from hivelms_client.http_client import HiveHttpClient
from hivelms_client.models.help.help import Help, HelpInput
from hivelms_client.models.help.help_response import HelpResponseContents
from hivelms_client.models.hive_common.pagination import ResultsPage

HELP_ENDPOINT = "help"
RESPONSES_ENDPOINT = "responses"


class HelpHandler:
    """CRUD handler for help threads, with a nested responses sub-handler.

    Attributes:
        responses: Handler for help thread responses.
    """

    def __init__(self, http_client: HiveHttpClient):
        self._http_client = http_client
        self.responses = HelpResponsesHandler(http_client)

    @overload  # No pagination if limit is None
    def search(
        self,
        *,
        created_by: int | None = None,
        current: bool | None = None,
        exercise_id: int | None = None,
        exercise_parent_module_id: int | None = None,
        exercise_subject_id: int | None = None,
        free_text: str | None = None,
        help_status_in: list[str] | None = None,
        help_type_in: list[str] | None = None,
        limit: Literal[None] = None,
        offset: int | None = None,
        ordering: str | None = None,
        user_classes_id: int | None = None,
        user_classes_id_in: list[int] | None = None,
        user_id_in: list[int] | None = None,
        user_mentor_id: int | None = None,
        user_mentor_id_in: list[int] | None = None,
        user_program_id_in: list[int] | None = None,
    ) -> list[Help]: ...

    @overload  # Pagination if limit not null
    def search(
        self,
        *,
        created_by: int | None = None,
        current: bool | None = None,
        exercise_id: int | None = None,
        exercise_parent_module_id: int | None = None,
        exercise_subject_id: int | None = None,
        free_text: str | None = None,
        help_status_in: list[str] | None = None,
        help_type_in: list[str] | None = None,
        limit: int,
        offset: int | None = None,
        ordering: str | None = None,
        user_classes_id: int | None = None,
        user_classes_id_in: list[int] | None = None,
        user_id_in: list[int] | None = None,
        user_mentor_id: int | None = None,
        user_mentor_id_in: list[int] | None = None,
        user_program_id_in: list[int] | None = None,
    ) -> ResultsPage[Help]: ...

    def search(
        self,
        *,
        created_by: int | None = None,
        current: bool | None = None,
        exercise_id: int | None = None,
        exercise_parent_module_id: int | None = None,
        exercise_subject_id: int | None = None,
        free_text: str | None = None,
        help_status_in: list[str] | None = None,
        help_type_in: list[str] | None = None,
        limit: int | None = None,
        offset: int | None = None,
        ordering: str | None = None,
        user_classes_id: int | None = None,
        user_classes_id_in: list[int] | None = None,
        user_id_in: list[int] | None = None,
        user_mentor_id: int | None = None,
        user_mentor_id_in: list[int] | None = None,
        user_program_id_in: list[int] | None = None,
    ) -> ResultsPage[Help] | list[Help]:
        """Return help threads, paginated when ``limit`` is provided.

        Args:
            created_by: Filter by the user ID who created the thread.
            current: Filter by whether the thread is current.
            exercise_id: Filter by the associated exercise ID.
            exercise_parent_module_id: Filter by the exercise's parent module ID.
            exercise_subject_id: Filter by the exercise's subject ID.
            free_text: Full-text search term.
            help_status_in: Restrict to threads with these statuses.
            help_type_in: Restrict to threads of these types.
            limit: Page size; when provided the result is paginated.
            offset: Pagination offset.
            ordering: Ordering field.
            user_classes_id: Filter by the student's class ID.
            user_classes_id_in: Filter by any of these class IDs.
            user_id_in: Filter by any of these user IDs.
            user_mentor_id: Filter by the student's mentor ID.
            user_mentor_id_in: Filter by any of these mentor IDs.
            user_program_id_in: Filter by any of these program IDs.

        Returns:
            A paginated results page when ``limit`` is set, otherwise a plain list.
        """
        return self._http_client.get(
            "/",
            response_model=ResultsPage[Help] if limit is not None else list[Help],
            created_by=created_by,
            current=current,
            for_exercise__id=exercise_id,
            for_exercise__parent_module__id=exercise_parent_module_id,
            for_exercise__parent_module__parent_subject__id=exercise_subject_id,
            free_text=free_text,
            help_status__in=help_status_in,
            help_type__in=help_type_in,
            limit=limit,
            offset=offset,
            ordering=ordering,
            user__classes__id=user_classes_id,
            user__classes__id__in=user_classes_id_in,
            user__id__in=user_id_in,
            user__mentor__id=user_mentor_id,
            user__mentor__id__in=user_mentor_id_in,
            user__program__id__in=user_program_id_in,
        )

    def create(self, help_request: HelpInput) -> Help:
        """Create a new help thread.

        Args:
            help_request: Data for the help thread to create.

        Returns:
            The newly created help thread.
        """
        return self._http_client.post("/", body=help_request, response_model=Help)

    def get(self, id_: int) -> Help:
        """Retrieve a single help thread by ID.

        Args:
            id_: The help thread ID.

        Returns:
            The matching help thread.
        """
        return self._http_client.get(f"/{id_}/", response_model=Help)

    def update(self, id_: int, help_request: HelpInput) -> Help:
        """Fully replace a help thread.

        Args:
            id_: The help thread ID.
            help_request: Replacement data for the help thread.

        Returns:
            The updated help thread.
        """
        return self._http_client.put(f"/{id_}/", body=help_request, response_model=Help)

    def patch(self, id_: int, help_patch: HelpInput) -> Help:
        """Partially update a help thread.

        Args:
            id_: The help thread ID.
            help_patch: Fields to update on the help thread.

        Returns:
            The updated help thread.
        """
        return self._http_client.patch(f"/{id_}/", body=help_patch, response_model=Help)

    def delete(self, id_: int) -> None:
        """Delete a help thread.

        Args:
            id_: The help thread ID.
        """
        return self._http_client.delete(f"/{id_}/", response_model=None)

    def lock(self, id_: int) -> None:
        """Lock a help thread, preventing further responses.

        Args:
            id_: The help thread ID.
        """
        return self._http_client.put(f"/{id_}/lock/", response_model=None)

    def unlock(self, id_: int) -> None:
        """Unlock a help thread to allow responses again.

        Args:
            id_: The help thread ID.
        """
        return self._http_client.put(f"/{id_}/unlock/", response_model=None)

    def subscribe(self, id_: int) -> None:
        """Subscribe the current user to a help thread.

        Args:
            id_: The help thread ID.
        """
        return self._http_client.put(f"/{id_}/subscribe/", response_model=None)

    def unsubscribe(self, id_: int) -> None:
        """Unsubscribe the current user from a help thread.

        Args:
            id_: The help thread ID.
        """
        return self._http_client.put(f"/{id_}/unsubscribe/", response_model=None)

    def get_top_responses(self, id_: int) -> list[HelpResponseContents]:
        """Retrieve the top responses for a help thread.

        Args:
            id_: The help thread ID.

        Returns:
            A list of top response contents.
        """
        return self._http_client.get(
            f"/{id_}/top_responses/", response_model=list[HelpResponseContents]
        )
