"""Handler for help thread responses resource."""

from hivelms_client.http_client import HiveHttpClient
from hivelms_client.models.file_response import FileResponse
from hivelms_client.models.help.help import HelpLatestItem
from hivelms_client.models.help.help_response import (
    HelpResponse,
    HelpResponsePatch,
    HelpResponseInput,
)

RESPONSES_ENDPOINT = "responses"


class HelpResponsesHandler:
    """CRUD handler for help thread responses."""

    def __init__(self, http_client: HiveHttpClient):
        self._http_client = http_client

    def search(self, help_id: int) -> list[HelpResponse]:
        """Return all responses for a help thread.

        Args:
            help_id: The help thread ID.

        Returns:
            A list of responses for the thread.
        """
        return self._http_client.get(
            f"/{help_id}/{RESPONSES_ENDPOINT}/", response_model=list[HelpResponse]
        )

    def create(self, help_id: int, response_request: HelpResponseInput) -> HelpResponse:
        """Create a new response on a help thread.

        Args:
            help_id: The help thread ID.
            response_request: Data for the response to create.

        Returns:
            The newly created response.
        """
        return self._http_client.post(
            f"/{help_id}/{RESPONSES_ENDPOINT}/",
            body=response_request,
            response_model=HelpResponse,
        )

    def get(self, help_id: int, response_id: int) -> HelpResponse:
        """Retrieve a single response from a help thread.

        Args:
            help_id: The help thread ID.
            response_id: The response ID.

        Returns:
            The matching response.
        """
        return self._http_client.get(
            f"/{help_id}/{RESPONSES_ENDPOINT}/{response_id}/",
            response_model=HelpResponse,
        )

    def update(
        self, help_id: int, response_id: int, updated_response: HelpResponseInput
    ) -> HelpResponse:
        """Fully replace a help thread response.

        Args:
            help_id: The help thread ID.
            response_id: The response ID.
            updated_response: Replacement data for the response.

        Returns:
            The updated response.
        """
        return self._http_client.put(
            f"/{help_id}/{RESPONSES_ENDPOINT}/{response_id}/",
            body=updated_response,
            response_model=HelpResponse,
        )

    def patch(
        self, help_id: int, response_id: int, response_patch: HelpResponsePatch
    ) -> HelpResponse:
        """Partially update a help thread response.

        Args:
            help_id: The help thread ID.
            response_id: The response ID.
            response_patch: Fields to update on the response.

        Returns:
            The updated response.
        """
        return self._http_client.patch(
            f"/{help_id}/{RESPONSES_ENDPOINT}/{response_id}/",
            body=response_patch,
            response_model=HelpResponse,
        )

    def delete(self, help_id: int, response_id: int) -> None:
        """Delete a help thread response.

        Args:
            help_id: The help thread ID.
            response_id: The response ID.
        """
        return self._http_client.delete(
            f"/{help_id}/{RESPONSES_ENDPOINT}/{response_id}/", response_model=None
        )

    def bulk_respond(
        self,
        response_data: HelpResponseInput,
        *,
        created_by: int | None = None,
        current: bool | None = None,
        for_exercise__id: int | None = None,
        for_exercise__parent_module__id: int | None = None,
        for_exercise__parent_module__parent_subject__id: int | None = None,
        free_text: str | None = None,
        help_status__in: list[str] | None = None,
        help_type__in: list[str] | None = None,
        ordering: str | None = None,
        user__classes__id: int | None = None,
        user__classes__id__in: list[int] | None = None,
        user__id__in: list[int] | None = None,
        user__mentor__id: int | None = None,
        user__mentor__id__in: list[int] | None = None,
        user__program__id__in: list[int] | None = None,
    ) -> list[HelpResponse]:
        """Post the same response to multiple help threads matching the given filters.

        Args:
            response_data: The response body to post to each matched thread.
            created_by: Filter threads by creator user ID.
            current: Filter threads by current status.
            for_exercise__id: Filter threads by exercise ID.
            for_exercise__parent_module__id: Filter threads by the exercise's module ID.
            for_exercise__parent_module__parent_subject__id: Filter threads by the exercise's subject ID.
            free_text: Full-text search term.
            help_status__in: Restrict to threads with these statuses.
            help_type__in: Restrict to threads of these types.
            ordering: Ordering field.
            user__classes__id: Filter by the student's class ID.
            user__classes__id__in: Filter by any of these class IDs.
            user__id__in: Filter by any of these user IDs.
            user__mentor__id: Filter by the student's mentor ID.
            user__mentor__id__in: Filter by any of these mentor IDs.
            user__program__id__in: Filter by any of these program IDs.

        Returns:
            A list of the created responses.
        """
        return self._http_client.post(
            "/bulk_respond/",
            body=response_data,
            response_model=list[HelpResponse],
            created_by=created_by,
            current=current,
            for_exercise__id=for_exercise__id,
            for_exercise__parent_module__id=for_exercise__parent_module__id,
            for_exercise__parent_module__parent_subject__id=for_exercise__parent_module__parent_subject__id,
            free_text=free_text,
            help_status__in=help_status__in,
            help_type__in=help_type__in,
            ordering=ordering,
            user__classes__id=user__classes__id,
            user__classes__id__in=user__classes__id__in,
            user__id__in=user__id__in,
            user__mentor__id=user__mentor__id,
            user__mentor__id__in=user__mentor__id__in,
            user__program__id__in=user__program__id__in,
        )

    def get_files(self, help_id: int, response_id: int) -> FileResponse:
        """Retrieve the student files attached to a help response.

        Args:
            help_id: The help thread ID.
            response_id: The response ID.

        Returns:
            The file response containing student files.
        """
        return self._http_client.get(
            f"/{help_id}/{RESPONSES_ENDPOINT}/{response_id}/student_files/",
            response_model=FileResponse,
        )

    def get_latest(
        self,
        *,
        help_type_in: list[str] | None = None,
        last_staff_updated_gt: str | None = None,
        user_classes_id: int | None = None,
        user_id_in: list[int] | None = None,
        user_mentor_id: int | None = None,
    ) -> list[HelpLatestItem]:
        """Return the latest help items, optionally filtered.

        Args:
            help_type_in: Restrict to these help types.
            last_staff_updated_gt: Filter to items updated after this timestamp.
            user_classes_id: Filter by the student's class ID.
            user_id_in: Filter by any of these user IDs.
            user_mentor_id: Filter by the student's mentor ID.

        Returns:
            A list of the latest help items.
        """
        return self._http_client.get(
            "/latest/",
            response_model=list[HelpLatestItem],
            help_type__in=help_type_in,
            last_staff_updated__gt=last_staff_updated_gt,
            user__classes__id=user_classes_id,
            user__id__in=user_id_in,
            user__mentor__id=user_mentor_id,
        )
