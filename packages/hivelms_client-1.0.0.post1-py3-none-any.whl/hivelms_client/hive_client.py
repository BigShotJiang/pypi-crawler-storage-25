"""Main HiveClient entry point."""

from typing import Literal

import urllib3
from urllib3.exceptions import InsecureRequestWarning

from hivelms_client.handlers.assignments.assignments_handler import AssignmentsHandler
from hivelms_client.handlers.course.course_handler import CourseHandler
from hivelms_client.handlers.helps.help_handler import HelpHandler
from hivelms_client.handlers.management.management_handler import ManagementHandler
from hivelms_client.handlers.notifications.notification_handler import (
    NotificationHandler,
)
from hivelms_client.handlers.queues.queues_handler import QueuesHandler
from hivelms_client.handlers.schedule.schedule_handler import ScheduleHandler
from hivelms_client.handlers.tags.tags_handler import TagsHandler
from hivelms_client.handlers.time.time_handler import TimeHandler
from hivelms_client.http_client import HiveHttpClient, ServerPath, ServerAuth

HIVE_PATH_PREFIX = "/api/core"
AUTH_PATH = "/token/"


class HiveClient:
    """Client for the Hive LMS API.

    Assumes staff or admin clearance. Endpoints that require lower clearance (student,
    checker) are not tested and may return reduced response shapes.
    """

    def __init__(
        self,
        host: str,
        username: str,
        password: str,
        port: int = 443,
        use_https: bool = True,
        verify_certs: bool = True,
        path_prefix: str = HIVE_PATH_PREFIX,
    ):
        protocol: Literal["http", "https"] = "https" if use_https else "http"
        base_http_client = HiveHttpClient(
            ServerPath(
                protocol=protocol, host=host, port=port, path_prefix=path_prefix
            ),
            ServerAuth(username=username, password=password, token_path=AUTH_PATH),
            verify_certs=verify_certs,
        )

        self.course_handler = CourseHandler(base_http_client.get_subclient("/course"))
        self.tags_handler = TagsHandler(base_http_client.get_subclient("/tags"))
        self.management_handler = ManagementHandler(
            base_http_client.get_subclient("/management")
        )
        self.assignments_handler = AssignmentsHandler(
            base_http_client.get_subclient("/assignments")
        )
        self.help_handler = HelpHandler(base_http_client.get_subclient("/help"))
        self.queues_handler = QueuesHandler(base_http_client.get_subclient("/queues"))
        self.schedule_handler = ScheduleHandler(
            base_http_client.get_subclient("/schedule")
        )
        self.notification_handler = NotificationHandler(
            base_http_client.get_subclient("/notification")
        )
        self.time_handler = TimeHandler(base_http_client.get_subclient("/time"))


if __name__ == "__main__":
    urllib3.disable_warnings(InsecureRequestWarning)
    admin_client = HiveClient(
        host="hive.test", username="admin", password="Password1", verify_certs=False
    )
    print(f"{admin_client.management_handler.users.me.get()!r}")
