"""Low-level HTTP client and configuration models for Hive API communication."""

from copy import deepcopy
from http import HTTPMethod
from json import JSONDecodeError
from typing import Any, Literal, Self, TypeVar, overload

from pydantic import ValidationError, BaseModel, TypeAdapter
from requests import Response, Session
from requests.exceptions import RequestException

from hivelms_client.exceptions.hive_exceptions import (
    InputValidationException,
    ClientErrorException,
    ErrorResponseException,
    UnauthenticatedException,
    SystemException,
    HiveException,
    ServerErrorException,
    ResourceNotFoundException,
    PermissionDeniedException,
    MethodNotAllowedException,
    NotAcceptableException,
    UnsupportedMediaTypeException,
)
from hivelms_client.models.auth import AuthTokenRequest, AuthTokenResponse
from hivelms_client.models.error_responses import ErrorType, ErrorResponse
from hivelms_client.models.file_response import FileResponse

# This will be used as a fallback to using hive's error codes. Workaround for a bug on file responses
# where errors are empty responses. We prefer using error codes from the response body.
STATUS_CODE_TO_EXCEPTIONS = {
    401: UnauthenticatedException,
    403: PermissionDeniedException,
    404: ResourceNotFoundException,
    405: MethodNotAllowedException,
    406: NotAcceptableException,
    415: UnsupportedMediaTypeException,
    422: InputValidationException,
    500: ServerErrorException,
}

TResponse = TypeVar("TResponse")


class ServerPath(BaseModel):
    """Server address and path prefix configuration."""

    protocol: Literal["http", "https"]
    host: str
    port: int
    path_prefix: str

    def __str__(self) -> str:
        """Return the full base URL string."""
        return f"{self.protocol}://{self.host}:{self.port}{self.path_prefix}"


class ServerAuth(BaseModel):
    """Credentials used to authenticate against the Hive server."""

    username: str
    password: str
    token_path: str


class HiveHttpClient:
    """Authenticated HTTP client that transparently re-authenticates on 401 responses."""

    def __init__(
        self,
        server_path: ServerPath,
        auth: ServerAuth,
        *,
        verify_certs: bool = True,
        login_handler: Self | None = None,
    ):

        self._server_path = server_path
        self._auth = auth
        self._verify_certs = verify_certs
        self._login_handler = login_handler or self

        self._session = Session()
        self._session.verify = verify_certs
        self._session.max_redirects = 0

    def get_subclient(self, prefix: str) -> "HiveHttpClient":
        """Return a new client whose base path is extended by ``prefix``.

        Args:
            prefix: Path segment to append to the current path prefix.

        Returns:
            A new ``HiveHttpClient`` scoped to the extended path.
        """
        new_path = deepcopy(self._server_path)
        new_path.path_prefix += prefix
        return HiveHttpClient(
            server_path=new_path,
            auth=self._auth,
            verify_certs=self._verify_certs,
            login_handler=self._login_handler,
        )

    @overload
    def post(
        self,
        path: str,
        *,
        body: BaseModel | None = ...,
        response_model: type[TResponse],
        **params: Any,
    ) -> TResponse: ...

    @overload
    def post(
        self,
        path: str,
        *,
        body: BaseModel | None = ...,
        response_model: None,
        **params: Any,
    ) -> None: ...

    def post(
        self,
        path: str,
        *,
        body: BaseModel | None = None,
        response_model: type[TResponse] | None = None,
        **params: Any,
    ) -> TResponse | None:
        """Send a POST request.

        Args:
            path: URL path relative to the client's base path.
            body: Optional request body serialized as JSON.
            response_model: Pydantic model used to deserialize the response.
            **params: Query parameters passed to the request.

        Returns:
            Deserialized response, or ``None`` when ``response_model`` is ``None``.
        """
        return self._make_request_with_login(
            HTTPMethod.POST, path, body=body, response_model=response_model, **params
        )

    @overload
    def patch(
        self,
        path: str,
        *,
        body: BaseModel | None = ...,
        response_model: type[TResponse],
        **params: Any,
    ) -> TResponse: ...

    @overload
    def patch(
        self,
        path: str,
        *,
        body: BaseModel | None = ...,
        response_model: None,
        **params: Any,
    ) -> None: ...

    def patch(
        self,
        path: str,
        *,
        body: BaseModel | None = None,
        response_model: type[TResponse] | None = None,
        **params: Any,
    ) -> TResponse | None:
        """Send a PATCH request.

        Args:
            path: URL path relative to the client's base path.
            body: Optional request body serialized as JSON.
            response_model: Pydantic model used to deserialize the response.
            **params: Query parameters passed to the request.

        Returns:
            Deserialized response, or ``None`` when ``response_model`` is ``None``.
        """
        return self._make_request_with_login(
            HTTPMethod.PATCH, path, body=body, response_model=response_model, **params
        )

    @overload
    def put(
        self,
        path: str,
        *,
        body: BaseModel | None = ...,
        response_model: type[TResponse],
        **params: Any,
    ) -> TResponse: ...

    @overload
    def put(
        self,
        path: str,
        *,
        body: BaseModel | None = ...,
        response_model: None,
        **params: Any,
    ) -> None: ...

    def put(
        self,
        path: str,
        *,
        body: BaseModel | None = None,
        response_model: type[TResponse] | None = None,
        **params: Any,
    ) -> TResponse | None:
        """Send a PUT request.

        Args:
            path: URL path relative to the client's base path.
            body: Optional request body serialized as JSON.
            response_model: Pydantic model used to deserialize the response.
            **params: Query parameters passed to the request.

        Returns:
            Deserialized response, or ``None`` when ``response_model`` is ``None``.
        """
        return self._make_request_with_login(
            HTTPMethod.PUT, path, body=body, response_model=response_model, **params
        )

    @overload
    def delete(
        self,
        path: str,
        *,
        body: BaseModel | None = ...,
        response_model: type[TResponse],
        **params: Any,
    ) -> TResponse: ...

    @overload
    def delete(
        self,
        path: str,
        *,
        body: BaseModel | None = ...,
        response_model: None,
        **params: Any,
    ) -> None: ...

    def delete(
        self,
        path: str,
        *,
        body: BaseModel | None = None,
        response_model: type[TResponse] | None = None,
        **params: Any,
    ) -> TResponse | None:
        """Send a DELETE request.

        Args:
            path: URL path relative to the client's base path.
            body: Optional request body serialized as JSON.
            response_model: Pydantic model used to deserialize the response.
            **params: Query parameters passed to the request.

        Returns:
            Deserialized response, or ``None`` when ``response_model`` is ``None``.
        """
        return self._make_request_with_login(
            HTTPMethod.DELETE, path, body=body, response_model=response_model, **params
        )

    @overload
    def get(
        self,
        path: str,
        *,
        body: BaseModel | None = ...,
        response_model: type[TResponse],
        **params: Any,
    ) -> TResponse: ...

    @overload
    def get(
        self,
        path: str,
        *,
        body: BaseModel | None = ...,
        response_model: None,
        **params: Any,
    ) -> None: ...

    def get(
        self,
        path: str,
        *,
        body: BaseModel | None = None,
        response_model: type[TResponse] | None = None,
        **params: Any,
    ) -> TResponse | None:
        """Send a GET request.

        Args:
            path: URL path relative to the client's base path.
            body: Optional request body serialized as JSON.
            response_model: Pydantic model used to deserialize the response.
            **params: Query parameters passed to the request.

        Returns:
            Deserialized response, or ``None`` when ``response_model`` is ``None``.
        """
        return self._make_request_with_login(
            HTTPMethod.GET, path, body=body, response_model=response_model, **params
        )

    @overload
    def _make_request_with_login(
        self,
        method: str,
        path: str,
        *,
        body: BaseModel | None,
        response_model: type[TResponse],
        **params: Any,
    ) -> TResponse: ...

    @overload
    def _make_request_with_login(
        self,
        method: str,
        path: str,
        *,
        body: BaseModel | None,
        response_model: None,
        **params: Any,
    ) -> None: ...

    def _make_request_with_login(
        self,
        method: str,
        path: str,
        *,
        body: BaseModel | None = None,
        response_model: type[TResponse] | None = None,
        **params: Any,
    ) -> TResponse | None:
        try:
            return self._make_request(
                method, path, body=body, response_model=response_model, **params
            )
        except UnauthenticatedException:
            self._login()
            return self._make_request(
                method, path, body=body, response_model=response_model, **params
            )

    def _login(self) -> None:
        try:
            tokens = self._login_handler._make_request(
                HTTPMethod.POST,
                self._auth.token_path,
                body=AuthTokenRequest(
                    username=self._auth.username, password=self._auth.password
                ),
                response_model=AuthTokenResponse,
            )
        except HiveException as e:
            if e.status_code == 401:
                raise UnauthenticatedException(
                    detail="Failed to authenticate for token", status_code=e.status_code
                ) from e
            raise e

        self._session.headers = {"Authorization": f"Bearer {tokens.access}"}

    @overload
    def _make_request(
        self,
        method: str,
        path: str,
        *,
        body: BaseModel | None,
        response_model: type[TResponse],
        **params: Any,
    ) -> TResponse: ...

    @overload
    def _make_request(
        self,
        method: str,
        path: str,
        *,
        body: BaseModel | None,
        response_model: None,
        **params: Any,
    ) -> None: ...

    def _make_request(
        self,
        method: str,
        path: str,
        *,
        body: BaseModel | None = None,
        response_model: type[TResponse] | None = None,
        **params: Any,
    ) -> TResponse | None:
        full_path = f"{self._server_path}{path}"
        try:
            response = self._session.request(
                method,
                full_path,
                params=params,
                json=body.model_dump(mode="json", by_alias=True) if body else None,
                allow_redirects=False,
            )
        except RequestException as e:
            raise SystemException(
                "Failed to make request to hive. Are you sure the service is reachable?"
            ) from e

        self._validate_response(
            response,
            is_file_response=isinstance(response_model, type)
            and issubclass(response_model, FileResponse),
        )
        if response_model:
            return self._get_response_data(response, model=response_model)
        return None

    @classmethod
    def _validate_response(cls, response: Response, is_file_response: bool) -> None:
        if response.status_code < 300:
            return

        if 300 <= response.status_code < 400:
            raise ErrorResponseException(
                detail="Encountered redirect. Are your paths up-to-date?",
                status_code=response.status_code,
            )

        if (
            is_file_response
        ):  # Workaround due to hive bug - errors on file operations have empty body
            raise STATUS_CODE_TO_EXCEPTIONS.get(
                response.status_code, ErrorResponseException
            )(
                detail="Error response for file download",
                status_code=response.status_code,
            )

        response_data = cls._get_response_data(response, model=ErrorResponse)
        cls._raise_from_error_response(response.status_code, response_data)

    @staticmethod
    def _get_response_data[T](response: Response, model: type[T]) -> T:
        if isinstance(model, type) and issubclass(model, FileResponse):
            # FileResponse.from_http_response returns Self, but mypy can't verify
            # the covariant relationship through the generic T bound here.
            return model.from_http_response(response)  # type: ignore[return-value]

        try:
            return TypeAdapter(model).validate_python(response.json())
        except (JSONDecodeError, ValidationError) as e:
            try:
                response_text = response.text
            except UnicodeDecodeError:
                response_text = "<binary data>"

            raise HiveException(
                detail=f"Unexpected error response format:\n{response_text}",
                status_code=response.status_code,
            ) from e

    @staticmethod
    def _raise_from_error_response(
        status_code: int, error_response: ErrorResponse
    ) -> None:
        match error_response.type_:
            case ErrorType.VALIDATION_ERROR:
                raise InputValidationException(
                    status_code=status_code,
                    detail="Received validation errors",
                    errors=error_response.errors,
                )
            case ErrorType.CLIENT_ERROR:
                ClientErrorException.raise_from_error_data(
                    status_code, error_response.errors[0]
                )

            case ErrorType.SERVER_ERROR:
                raise ServerErrorException(
                    status_code, "Encountered server error", error_response.errors
                )
