"""Tag resource models."""

from typing import Annotated

from pydantic import StringConstraints
from pydantic_core import MISSING

from hivelms_client.models.hive_common.modeling import HiveModel, BaseHiveResource
from hivelms_client.models.hive_common.data_types import HiveColor

TagName = Annotated[str, StringConstraints(min_length=1, max_length=100)]


class TagCore(HiveModel):
    """Shared core fields for a tag.

    Attributes:
        name: Display name of the tag.
        color: Hex colour used to represent the tag in the UI.
    """

    name: TagName
    color: HiveColor


class Tag(TagCore, BaseHiveResource):
    """Tag resource returned by the API.

    Attributes:
        id: Unique numeric identifier assigned by the API.
        name: Display name of the tag.
        color: Hex colour used to represent the tag in the UI.
    """


class TagInput(TagCore):
    """Input payload for creating a tag.

    Attributes:
        name: Display name of the tag.
        color: Hex colour used to represent the tag in the UI.
    """


class TagPatch(HiveModel):
    """Partial update payload for a tag.

    Attributes:
        name: Replacement display name.
        color: Replacement hex colour.
    """

    name: TagName = MISSING
    color: HiveColor = MISSING
