"""Notification-related Pydantic models."""
