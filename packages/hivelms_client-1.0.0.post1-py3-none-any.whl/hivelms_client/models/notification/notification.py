"""Notification resource models for exercise and help events."""

from datetime import datetime
from enum import auto

from pydantic import BaseModel
from pydantic_core import MISSING

from hivelms_client.models.hive_common.data_types import OptionalString
from hivelms_client.models.hive_common.modeling import (
    HiveOption,
    ResourceId,
    BaseHiveResource,
)


class NotificationResponseType(HiveOption):
    """Enum of response actions that can trigger a notification.

    Attributes:
        COMMENT: A comment was posted on an assignment or help thread.
        WORK_IN_PROGRESS: Student saved progress without submitting.
        SUBMISSION: Student formally submitted their work.
        AUTOCHECK: An automated grading run was triggered.
        REDO: Teacher requested the student revise and resubmit.
        DONE: Teacher marked the assignment as complete.
        RESOLVE: Staff resolved a help thread.
        OPEN: A help thread was (re)opened.
    """

    COMMENT = auto()
    WORK_IN_PROGRESS = auto()
    SUBMISSION = auto()
    AUTOCHECK = auto()
    REDO = auto()
    DONE = auto()
    RESOLVE = auto()
    OPEN = auto()


class NestedNotification(BaseModel):
    """Lightweight notification reference embedded in another resource.

    Attributes:
        id: Unique identifier of the notification.
        from_user: ID of the user who triggered the notification, or ``None``.
        comment: Short comment text accompanying the notification.
    """

    id: ResourceId
    from_user: ResourceId | None
    comment: str


class BaseNotificationCore(BaseModel):
    """Shared core fields for all notification types.

    Attributes:
        comment: Short comment text accompanying the notification, or ``None``.
        was_read: Whether the notification has been read, or ``None`` if unknown.
    """

    comment: str | None
    was_read: bool | None


class ExerciseNotificationCore(BaseNotificationCore):
    """Core fields for notifications linked to an exercise assignment.

    Attributes:
        assignment: ID of the assignment this notification relates to.
    """

    assignment: ResourceId


class HelpNotificationCore(BaseNotificationCore):
    """Core fields for notifications linked to a help thread.

    Attributes:
        help: ID of the help thread this notification relates to.
    """

    help: ResourceId


class BaseNotificationInput(BaseNotificationCore):
    """Base input payload for creating any notification.

    Attributes:
        user: ID of the user this notification is for.
        comment: Short comment text to include with the notification.
        was_read: Initial read state of the notification.
    """

    user: ResourceId
    comment: str = MISSING
    was_read: bool | None = MISSING


class ExerciseNotificationInput(BaseNotificationInput, ExerciseNotificationCore):
    """Input payload for creating an exercise assignment notification.

    Attributes:
        comment: Short comment text to include with the notification.
        was_read: Initial read state of the notification.
        user: ID of the user this notification is for.
        assignment: ID of the assignment this notification relates to.
    """


class HelpNotificationInput(BaseNotificationInput, HelpNotificationCore):
    """Input payload for creating a help thread notification.

    Attributes:
        comment: Short comment text to include with the notification.
        was_read: Initial read state of the notification.
        user: ID of the user this notification is for.
        help: ID of the help thread this notification relates to.
    """


class BaseNotification(BaseHiveResource, BaseNotificationCore):
    """Full notification resource fields shared across all notification types.

    Attributes:
        id: Unique numeric identifier assigned by the API.
        comment: Short comment text accompanying the notification, or ``None``.
        was_read: Whether the notification has been read, or ``None`` if unknown.
        response_type: The response action that triggered this notification, if any.
        from_user: ID of the user who triggered the notification.
        from_user_name: Display name of the triggering user.
        time: Timestamp when the notification was created.
        for_user: ID of the user this notification is addressed to.
        for_user_name: Display name of the recipient user.
    """

    response_type: OptionalString[NotificationResponseType]
    from_user: ResourceId
    from_user_name: str
    time: datetime
    for_user: ResourceId
    for_user_name: str


class ExerciseNotification(BaseNotification, ExerciseNotificationCore):
    """Notification resource for an exercise assignment event.

    Attributes:
        id: Unique numeric identifier assigned by the API.
        comment: Short comment text accompanying the notification, or ``None``.
        was_read: Whether the notification has been read, or ``None`` if unknown.
        assignment: ID of the assignment this notification relates to.
        response_type: The response action that triggered this notification, if any.
        from_user: ID of the user who triggered the notification.
        from_user_name: Display name of the triggering user.
        time: Timestamp when the notification was created.
        for_user: ID of the user this notification is addressed to.
        for_user_name: Display name of the recipient user.
        exercise: ID of the exercise related to this notification.
        exercise_name: Display name of the exercise.
        module: ID of the module the exercise belongs to.
        subject: ID of the subject the exercise belongs to.
        program: ID of the program the exercise belongs to.
    """

    exercise: ResourceId
    exercise_name: str
    module: ResourceId
    subject: ResourceId
    program: ResourceId


class HelpNotification(BaseNotification, HelpNotificationCore):
    """Notification resource for a help thread event.

    Attributes:
        id: Unique numeric identifier assigned by the API.
        comment: Short comment text accompanying the notification, or ``None``.
        was_read: Whether the notification has been read, or ``None`` if unknown.
        help: ID of the help thread this notification relates to.
        response_type: The response action that triggered this notification, if any.
        from_user: ID of the user who triggered the notification.
        from_user_name: Display name of the triggering user.
        time: Timestamp when the notification was created.
        for_user: ID of the user this notification is addressed to.
        for_user_name: Display name of the recipient user.
        help_type: Category of the help request that triggered this notification.
        help_title: Title of the help thread.
    """

    help_type: str
    help_title: str


Notification = ExerciseNotification | HelpNotification
NotificationInput = ExerciseNotificationInput | HelpNotificationInput


class NotificationPatch(BaseNotificationCore):
    """Partial update payload for a notification.

    Attributes:
        assignment: Replacement assignment ID, or ``None`` to clear.
        comment: Replacement comment text.
        was_read: Replacement read state.
        user: Replacement recipient user ID.
    """

    assignment: int | None = MISSING
    comment: str | None = MISSING
    was_read: bool | None = MISSING
    user: int | None = MISSING
