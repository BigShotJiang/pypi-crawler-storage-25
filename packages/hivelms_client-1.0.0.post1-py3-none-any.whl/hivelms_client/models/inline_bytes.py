"""Type alias for bytes that serialise as a base64 data URI."""

from base64 import b64encode
from typing import Annotated

from pydantic import PlainSerializer

RAW_BYTES_MIMETYPE = "application/octet-stream"


def serialize_bytes_to_data_uri(data: bytes) -> str:
    """Encode raw bytes as a base64 data URI string."""
    encoded_bytes = b64encode(data).decode("utf-8")
    return f"data:{RAW_BYTES_MIMETYPE};base64,{encoded_bytes}"


InlineBytes = Annotated[bytes, PlainSerializer(serialize_bytes_to_data_uri)]
