"""User registration models."""

from typing import Annotated

from pydantic import BaseModel, StringConstraints

from hivelms_client.models.hive_common.data_types import Username, Password
from hivelms_client.models.management.users.user_options import Gender

NameComponent = Annotated[str, StringConstraints(min_length=1, max_length=150)]
Secret = Annotated[str, StringConstraints(min_length=1, max_length=256)]


class RegistrationCore(BaseModel):
    """Shared core fields for a user registration.

    Attributes:
        username: Chosen username for the new account.
        first_name: User's first name.
        last_name: User's last name.
        gender: User's gender.
        password: Chosen password for the new account.
    """

    username: Username
    first_name: NameComponent
    last_name: NameComponent
    gender: Gender
    password: Password


class Registration(RegistrationCore):
    """Standard user registration payload.

    Attributes:
        username: Chosen username for the new account.
        first_name: User's first name.
        last_name: User's last name.
        gender: User's gender.
        password: Chosen password for the new account.
    """


class RegistrationRequest(RegistrationCore):
    """Registration payload that also requires an invite secret.

    Attributes:
        username: Chosen username for the new account.
        first_name: User's first name.
        last_name: User's last name.
        gender: User's gender.
        password: Chosen password for the new account.
        secret: Invite secret code required to complete self-registration.
    """

    secret: Secret
