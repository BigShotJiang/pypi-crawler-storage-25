"""Class (room/student-group) resource models."""

from enum import auto
from typing import Annotated
from pydantic import BaseModel, StringConstraints, Field, NameEmail
from pydantic_core import MISSING

from hivelms_client.models.hive_common.data_types import OptionalString
from hivelms_client.models.hive_common.modeling import (
    HiveOption,
    ResourceId,
    BaseHiveResource,
    HiveModel,
)

ClassName = Annotated[str, StringConstraints(min_length=1, max_length=100)]
ClassDescription = Annotated[str, StringConstraints(min_length=1, max_length=100)]


class ClassType(HiveOption):
    """Enum distinguishing physical rooms from student groups.

    Attributes:
        ROOM: A physical classroom or room used for seating arrangements.
        STUDENT_GROUP: A logical grouping of students for queue or scheduling purposes.
    """

    ROOM = auto()
    STUDENT_GROUP = auto()


class ClassInput(HiveModel):
    """Input payload for creating a class.

    Attributes:
        name: Display name of the class.
        program: ID of the program this class belongs to.
        users: IDs of users (students or staff) in this class.
        email: Contact email address for the class, if any.
        type: Whether this is a physical room or a student group.
        classes: IDs of nested sub-classes, if applicable.
        description: Optional short description of the class.
    """

    name: ClassName
    program: ResourceId
    users: list[ResourceId]
    email: OptionalString[NameEmail] = MISSING
    type: ClassType = MISSING
    classes: list[ResourceId] = MISSING
    description: OptionalString[ClassDescription] = MISSING


class Class(BaseHiveResource):
    """Full class resource returned by the API.

    Attributes:
        id: Unique numeric identifier assigned by the API.
        name: Display name of the class.
        program: ID of the program this class belongs to.
        users: IDs of users (students or staff) in this class.
        email: Contact email address for the class, if any.
        type: Whether this is a physical room or a student group.
        description: Optional short description of the class.
        display_name: Formatted display name shown in the UI.
        program_name: Display name of the parent program.
    """

    name: ClassName
    program: ResourceId
    users: list[ResourceId]
    email: OptionalString[str]
    type: ClassType
    description: OptionalString[ClassDescription]
    display_name: str
    program_name: str = Field(alias="program__name")


class ClassPatch(HiveModel):
    """Partial update payload for a class.

    Attributes:
        name: Replacement display name.
        program: Replacement parent program ID.
        users: Replacement list of user IDs.
        email: Replacement contact email address.
        type: Replacement class type.
        classes: Replacement list of nested sub-class IDs.
        description: Replacement short description.
    """

    name: ClassName = MISSING
    program: ResourceId = MISSING
    users: list[ResourceId] = MISSING
    email: OptionalString[str] = MISSING
    type: ClassType = MISSING
    classes: list[ResourceId] = MISSING
    description: OptionalString[ClassDescription] = MISSING


class SetClassQueueRequest(BaseModel):
    """Request body for assigning a queue to a class.

    Attributes:
        queue: ID of the queue to assign, or ``None`` to clear the assignment.
    """

    queue: ResourceId | None


class SetClassLessonRequest(BaseModel):
    """Request body for assigning a lesson to a class.

    Attributes:
        lesson: ID of the lesson to assign, or ``None`` to clear the assignment.
    """

    lesson: ResourceId | None
