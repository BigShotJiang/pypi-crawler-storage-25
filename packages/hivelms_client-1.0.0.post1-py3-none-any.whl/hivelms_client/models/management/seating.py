"""Seating arrangement resource models."""

from typing import Annotated

from pydantic import StringConstraints
from pydantic_core import MISSING

from hivelms_client.models.hive_common.modeling import (
    ResourceId,
    BaseHiveResource,
    HiveModel,
)

SeatHostname = Annotated[str, StringConstraints(min_length=1, max_length=255)]


class SeatingInput(HiveModel):
    """Input payload for creating a seating assignment.

    Attributes:
        classroom: ID of the classroom this seat belongs to.
        x: Column position of the seat in the room grid.
        y: Row position of the seat in the room grid.
        hanich: ID of the student assigned to this seat, or ``None``.
        hostname: Hostname of the machine at this seat, or ``None``.
    """

    classroom: ResourceId
    x: int
    y: int
    hanich: ResourceId | None = MISSING
    hostname: str | None = MISSING


class Seating(BaseHiveResource):
    """Full seating resource returned by the API.

    Attributes:
        id: Unique numeric identifier assigned by the API.
        classroom: ID of the classroom this seat belongs to.
        x: Column position of the seat in the room grid.
        y: Row position of the seat in the room grid.
        hanich: ID of the student assigned to this seat, or ``None``.
        hostname: Hostname of the machine at this seat, or ``None``.
    """

    classroom: ResourceId
    x: int
    y: int
    hanich: ResourceId | None
    hostname: str | None


class SeatingPatch(HiveModel):
    """Partial update payload for a seating assignment.

    Attributes:
        classroom: Replacement classroom ID.
        x: Replacement column position.
        y: Replacement row position.
        hanich: Replacement student ID, or ``None`` to vacate the seat.
        hostname: Replacement machine hostname, or ``None`` to clear it.
    """

    classroom: ResourceId = MISSING
    x: int = MISSING
    y: int = MISSING
    hanich: ResourceId | None = MISSING
    hostname: str | None = MISSING
