"""Discriminated union types and patch model for all user variants."""

from typing import Annotated

from pydantic import BaseModel, Discriminator
from pydantic_core import MISSING

from hivelms_client.models.hive_common.modeling import ResourceId
from hivelms_client.models.inline_bytes import InlineBytes
from hivelms_client.models.hive_common.data_types import Username
from hivelms_client.models.management.users.checker import CheckerUser, CheckerUserInput
from hivelms_client.models.management.users.staff import StaffUserInput, StaffUser
from hivelms_client.models.management.users.student import StudentUserInput, StudentUser
from hivelms_client.models.management.users.user_options import (
    Clearance,
    Gender,
    StudentStatus,
)

UserInput = Annotated[
    CheckerUserInput | StaffUserInput | StudentUserInput, Discriminator("clearance")
]
User = Annotated[CheckerUser | StaffUser | StudentUser, Discriminator("clearance")]


class UserPatch(BaseModel):
    """Partial update payload for any user, admin-facing.

    Attributes:
        clearance: Replacement permission level.
        avatar: Raw replacement avatar image bytes.
        avatar_filename: Replacement avatar filename.
        gender: Replacement gender.
        number: Replacement roll number, or ``None`` to clear.
        program: Replacement program ID, or ``None`` to clear.
        checkers_brief: Replacement staff-facing notes for checkers.
        mentor: Replacement mentor ID, or ``None`` to clear.
        classes: Replacement list of class IDs.
        mentees: Replacement list of mentee IDs.
        username: Replacement username.
        first_name: Replacement first name.
        last_name: Replacement last name.
        status: Replacement presence status.
        queue: Replacement class queue ID, or ``None`` to clear.
        disable_queue: Whether to disable the class queue.
        user_queue: Replacement personal queue ID.
        disable_user_queue: Whether to disable the personal queue, or ``None``.
        override_queue: Replacement override queue ID, or ``None`` to clear.
        confirmed: Whether to mark the account as confirmed.
        teacher: Whether the account has teacher privileges.
        hostname: Replacement machine hostname.
        password: Replacement password.
    """

    clearance: Clearance = MISSING
    avatar: InlineBytes = MISSING
    avatar_filename: str = MISSING
    gender: Gender = MISSING
    number: int | None = MISSING
    program: ResourceId | None = MISSING
    checkers_brief: str = MISSING
    mentor: ResourceId | None = MISSING
    classes: list[ResourceId] = MISSING
    mentees: list[ResourceId] = MISSING
    username: Username = MISSING
    first_name: str = MISSING
    last_name: str = MISSING
    status: StudentStatus = MISSING
    queue: ResourceId | None = MISSING
    disable_queue: bool = MISSING
    user_queue: ResourceId = MISSING
    disable_user_queue: bool | None = MISSING
    override_queue: ResourceId | None = MISSING
    confirmed: bool = MISSING
    teacher: bool = MISSING
    hostname: str = MISSING
    password: str = MISSING
