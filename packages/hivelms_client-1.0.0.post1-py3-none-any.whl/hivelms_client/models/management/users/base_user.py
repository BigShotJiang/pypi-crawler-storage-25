"""Base user resource models shared across all clearance levels."""

from pydantic_core import MISSING

from hivelms_client.models.hive_common.data_types import Username
from hivelms_client.models.hive_common.modeling import BaseHiveResource, HiveModel
from hivelms_client.models.inline_bytes import InlineBytes
from hivelms_client.models.management.users.user_options import (
    Clearance,
    Gender,
    StudentStatus,
)


class BaseUserInput(HiveModel):
    """Input payload shared by all user types.

    Attributes:
        username: Unique username for the account.
        password: Account password.
        clearance: Permission level assigned to the user.
        gender: User's gender.
        status: Initial real-time presence status.
        first_name: User's first name.
        last_name: User's last name.
        avatar_filename: Filename of the user's avatar image.
        hostname: Hostname of the machine associated with this user.
        avatar: Raw avatar image bytes, serialised as a base64 data URI.
    """

    username: Username
    password: str
    clearance: Clearance
    gender: Gender
    status: StudentStatus
    first_name: str | None = MISSING
    last_name: str | None = MISSING
    avatar_filename: str | None = MISSING
    hostname: str | None = MISSING

    avatar: InlineBytes | None = MISSING


class BaseUser(BaseHiveResource):
    """Base user resource fields returned by the API.

    Attributes:
        id: Unique numeric identifier assigned by the API.
        username: Unique username for the account.
        first_name: User's first name, or ``None`` if not set.
        last_name: User's last name, or ``None`` if not set.
        clearance: Permission level assigned to the user.
        gender: User's gender.
        avatar_filename: Filename of the user's avatar image, or ``None``.
        hostname: Hostname of the machine associated with this user, or ``None``.
        display_name: Formatted display name shown in the UI.
    """

    username: Username
    first_name: str | None
    last_name: str | None
    clearance: Clearance
    gender: Gender
    # status: StudentStatus
    avatar_filename: str | None
    hostname: str | None

    display_name: str
