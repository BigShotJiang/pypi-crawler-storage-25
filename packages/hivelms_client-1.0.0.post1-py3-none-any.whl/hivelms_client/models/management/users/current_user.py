"""Models representing the currently authenticated user."""

from typing import Annotated, Literal

from pydantic import BaseModel, Field
from pydantic_core import MISSING

from hivelms_client.models.hive_common.modeling import ResourceId, BaseHiveResource
from hivelms_client.models.management.users.student import StudentAssignmentOptions
from hivelms_client.models.management.users.user_options import StudentStatus, Clearance


class CurrentUserCore(BaseModel):
    """Minimal fields shared across all current-user variants.

    Attributes:
        username: Unique username of the currently authenticated user.
        clearance: Permission level of the currently authenticated user.
        display_name: Formatted display name shown in the UI.
    """

    username: str
    clearance: Clearance
    display_name: str


class StudentCurrentUser(CurrentUserCore, BaseHiveResource):
    """Current-user representation for a student.

    Attributes:
        id: Unique numeric identifier assigned by the API.
        username: Unique username of the currently authenticated user.
        display_name: Formatted display name shown in the UI.
        clearance: Always ``Clearance.STUDENT``; used as the discriminator.
        status: Real-time presence status of the student.
        schedule_enabled: Whether the student has access to the schedule view.
        current_assignment: ID of the student's active assignment, or ``None``.
        number: Student's roll number, or ``None`` if unassigned.
        program: ID of the student's program, or ``None``.
        program__name: Display name of the student's program.
        show_only_today_schedule: Whether the student sees only today's schedule.
        confirmed: Whether the student account is confirmed, or ``None``.
        current_assignment_options: Selectable assignment options for choose-queue, if any.
        current_assignment__exercise_name: Name of the exercise in the active assignment.
        current_assignment__exercise_id: ID of the exercise in the active assignment.
        current_assignment__module_id: Module ID of the exercise in the active assignment.
        current_assignment__subject_id: Subject ID of the exercise in the active assignment.
        hanich_raise_hand: Whether the student can raise their hand via the UI.
        teacher: Whether the student account also has teacher privileges.
    """

    clearance: Literal[Clearance.STUDENT]
    status: StudentStatus
    schedule_enabled: bool
    current_assignment: ResourceId | None
    number: int | None
    program: ResourceId | None
    program__name: str
    show_only_today_schedule: Annotated[bool, Field(alias="only_today")]
    confirmed: bool | None = None
    current_assignment_options: list[StudentAssignmentOptions] | None = None
    current_assignment__exercise_name: str = MISSING
    current_assignment__exercise_id: ResourceId = MISSING
    current_assignment__module_id: ResourceId = MISSING
    current_assignment__subject_id: ResourceId = MISSING
    hanich_raise_hand: bool
    teacher: bool


class CheckerCurrentUser(CurrentUserCore, BaseHiveResource):
    """Current-user representation for a checker.

    Attributes:
        id: Unique numeric identifier assigned by the API.
        username: Unique username of the currently authenticated user.
        display_name: Formatted display name shown in the UI.
        clearance: Always ``Clearance.CHECKER``; used as the discriminator.
    """

    clearance: Literal[Clearance.CHECKER]


class StaffCurrentUser(CurrentUserCore, BaseHiveResource):
    """Current-user representation for a staff member or admin.

    Attributes:
        id: Unique numeric identifier assigned by the API.
        username: Unique username of the currently authenticated user.
        display_name: Formatted display name shown in the UI.
        clearance: Staff or admin clearance level; used as the discriminator.
    """

    clearance: Literal[Clearance.STAFF, Clearance.ADMIN]


CurrentUser = Annotated[
    StudentCurrentUser | CheckerCurrentUser | StaffCurrentUser,
    Field(discriminator="clearance"),
]


class BaseCurrentUserPatch(BaseModel):
    """Base partial update payload for the current user's own profile.

    Attributes:
        password: New password to set.
        current_password: Current password for verification.
        hostname: Replacement machine hostname.
    """

    password: str = MISSING
    current_password: str = MISSING
    hostname: str = MISSING


class CheckerCurrentUserPatch(BaseCurrentUserPatch):
    """Partial update payload for a checker's own profile.

    Attributes:
        password: New password to set.
        current_password: Current password for verification.
        hostname: Replacement machine hostname.
    """


class StaffCurrentUserPatch(BaseCurrentUserPatch):
    """Partial update payload for a staff member's own profile.

    Attributes:
        password: New password to set.
        current_password: Current password for verification.
        hostname: Replacement machine hostname.
    """


class StudentCurrentUserPatch(BaseCurrentUserPatch):
    """Partial update payload for a student's own profile.

    Attributes:
        password: New password to set.
        current_password: Current password for verification.
        hostname: Replacement machine hostname.
        status: Replacement real-time presence status.
        current_assignment: Replacement active assignment ID, or ``None`` to clear.
        confirmed: Whether to mark the student account as confirmed.
    """

    status: StudentStatus = MISSING
    current_assignment: int | None = MISSING
    confirmed: bool = MISSING


CurrentUserPatch = (
    StudentCurrentUserPatch | CheckerCurrentUserPatch | StaffCurrentUserPatch
)
