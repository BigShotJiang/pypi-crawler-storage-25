"""User option enumerations for gender, status, and clearance."""

from enum import IntEnum, auto
from hivelms_client.models.hive_common.modeling import HiveOption


class Gender(HiveOption):
    """Enum of gender options for a user.

    Attributes:
        MALE: User identifies as male.
        FEMALE: User identifies as female.
        NONBINARY: User identifies as non-binary or outside the male/female binary.
    """

    MALE = auto()
    FEMALE = auto()
    NONBINARY = "NonBinary"


class StudentStatus(HiveOption):
    """Enum of real-time presence statuses for a student.

    Attributes:
        PRESENT: Student is present and working at their seat.
        RAISED_HAND: Student has raised their hand and is waiting for assistance.
        TOILET_REQUEST: Student has requested a toilet break and is awaiting approval.
        TOILET: Student has been approved for a toilet break and has left their seat.
        PERSONAL_TALK: Student is engaged in a personal conversation with staff.
        WORK_TALK: Student is discussing work-related topics with staff.
        MEDICAL: Student is away for a medical reason.
        PRAYER: Student is away for prayer.
        ROOM: Student is in a separate room.
        HOME: Student is working from home and not physically present.
    """

    PRESENT = auto()
    RAISED_HAND = auto()
    TOILET_REQUEST = auto()
    TOILET = auto()
    PERSONAL_TALK = auto()
    WORK_TALK = auto()
    MEDICAL = auto()
    PRAYER = auto()
    ROOM = auto()
    HOME = auto()


class Clearance(IntEnum):
    """Integer-valued permission levels, ordered from student to admin.

    Attributes:
        STUDENT: Basic student access with no management capabilities.
        CHECKER: Elevated access for reviewing and checking student submissions.
        STAFF: Teacher-level access for managing courses, exercises, and students.
        ADMIN: Full administrative access to all system features and settings.
    """

    STUDENT = 1
    CHECKER = 2
    STAFF = 3
    ADMIN = 5
