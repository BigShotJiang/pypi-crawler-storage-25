"""User-related Pydantic models for management endpoints."""
