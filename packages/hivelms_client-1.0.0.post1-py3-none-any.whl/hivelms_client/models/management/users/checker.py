"""Checker-level user models."""

from typing import Literal

from hivelms_client.models.management.users.base_user import BaseUser, BaseUserInput
from hivelms_client.models.management.users.user_options import Clearance


class CheckerUserInput(BaseUserInput):
    """Input payload for creating a checker user.

    Attributes:
        username: Unique username for the account.
        password: Account password.
        clearance: Must be ``Clearance.CHECKER``; enforced at the type level.
        gender: User's gender.
        status: Initial real-time presence status.
        first_name: User's first name.
        last_name: User's last name.
        avatar_filename: Filename of the user's avatar image.
        hostname: Hostname of the machine associated with this user.
        avatar: Raw avatar image bytes, serialised as a base64 data URI.
    """

    clearance: Literal[Clearance.CHECKER]


class CheckerUser(BaseUser):
    """Checker-level user resource returned by the API.

    Attributes:
        id: Unique numeric identifier assigned by the API.
        username: Unique username for the account.
        first_name: User's first name, or ``None`` if not set.
        last_name: User's last name, or ``None`` if not set.
        clearance: Always ``Clearance.CHECKER``; used as the discriminator.
        gender: User's gender.
        avatar_filename: Filename of the user's avatar image, or ``None``.
        hostname: Hostname of the machine associated with this user, or ``None``.
        display_name: Formatted display name shown in the UI.
    """

    clearance: Literal[Clearance.CHECKER]
