"""Student user models."""

from datetime import datetime
from typing import Literal

from pydantic import BaseModel
from pydantic_core import MISSING

from hivelms_client.models.assignments.assignment_status import AssignmentStatus
from hivelms_client.models.hive_common.modeling import ResourceId
from hivelms_client.models.management.users.base_user import BaseUser, BaseUserInput
from hivelms_client.models.management.users.user_options import Clearance
from hivelms_client.models.management.users.user_options import StudentStatus


class StudentAssignmentOptions(BaseModel):
    """A selectable assignment option presented to a student in a choose-queue.

    Attributes:
        id: ID of the assignment option.
        exercise: ID of the exercise.
        exercise_name: Display name of the exercise.
        parent_module: ID of the module the exercise belongs to.
        parent_subject: ID of the subject the exercise belongs to.
        parent_module_name: Display name of the parent module.
        parent_subject_symbol: Symbol identifier of the parent subject.
        parent_subject_color: Hex colour of the parent subject.
        assignment_status: Current status of this assignment.
    """

    id: int
    exercise: int
    exercise_name: str
    parent_module: int
    parent_subject: int
    parent_module_name: str
    parent_subject_symbol: str
    parent_subject_color: str
    assignment_status: AssignmentStatus


class StudentUserInput(BaseUserInput):
    """Input payload for creating a student user.

    Attributes:
        username: Unique username for the account.
        password: Account password.
        clearance: Must be ``Clearance.STUDENT``; enforced at the type level.
        gender: User's gender.
        first_name: User's first name.
        last_name: User's last name.
        avatar_filename: Filename of the user's avatar image.
        hostname: Hostname of the machine associated with this user.
        avatar: Raw avatar image bytes, serialised as a base64 data URI.
        number: Student's roll number.
        status: Initial real-time presence status.
        current_assignment: ID of the student's initial active assignment, or ``None``.
        program: ID of the program to enrol the student in.
        current_assignment_options: IDs of assignments available in a choose-queue.
        checkers_brief: Staff-facing notes visible to checkers.
        mentor: ID of the staff member mentoring this student.
        classes: IDs of classes to enrol the student in.
        queue: ID of the class queue assigned to the student.
        disable_queue: Whether to disable the class queue for this student.
        user_queue: ID of the personal queue assigned to the student.
        disable_user_queue: Whether to disable the personal queue.
        override_queue: ID of an override queue that takes precedence.
        confirmed: Whether the student account starts as confirmed.
        teacher: Whether the student account also has teacher privileges.
        mentees: Must be an empty list for student users.
    """

    clearance: Literal[Clearance.STUDENT]
    number: int
    status: StudentStatus
    current_assignment: ResourceId | None
    program: ResourceId | None = MISSING
    current_assignment_options: list[ResourceId] = MISSING
    checkers_brief: str = MISSING
    mentor: ResourceId | None = MISSING
    classes: list[ResourceId] = MISSING
    queue: ResourceId | None = MISSING
    disable_queue: bool = MISSING
    user_queue: ResourceId | None = MISSING
    disable_user_queue: bool = MISSING
    override_queue: ResourceId | None = MISSING
    confirmed: bool = MISSING
    teacher: bool = MISSING

    mentees: Literal[[]] = []


class StudentUser(BaseUser):
    """Student user resource returned by the API.

    Attributes:
        id: Unique numeric identifier assigned by the API.
        username: Unique username for the account.
        first_name: User's first name, or ``None`` if not set.
        last_name: User's last name, or ``None`` if not set.
        clearance: Always ``Clearance.STUDENT``; used as the discriminator.
        gender: User's gender.
        avatar_filename: Filename of the user's avatar image, or ``None``.
        hostname: Hostname of the machine associated with this user, or ``None``.
        display_name: Formatted display name shown in the UI.
        number: Student's roll number, or ``None`` if unassigned.
        status: Real-time presence status.
        program: ID of the student's program, or ``None``.
        current_assignment: ID of the student's active assignment, or ``None``.
        current_assignment_options: Assignment IDs available in a choose-queue.
        checkers_brief: Staff-facing notes visible to checkers.
        mentor: ID of the student's mentor, or ``None``.
        classes: IDs of classes the student is enrolled in.
        queue: ID of the class queue, or ``None``.
        disable_queue: Whether the class queue is disabled for this student.
        user_queue: ID of the personal queue, or ``None``.
        disable_user_queue: Whether the personal queue is disabled.
        override_queue: ID of the override queue, or ``None``.
        confirmed: Whether the student account is confirmed.
        teacher: Whether the student account also has teacher privileges.
        status_date: Timestamp when the student's status last changed.
    """

    clearance: Literal[Clearance.STUDENT]
    number: int | None
    status: StudentStatus
    program: ResourceId | None
    current_assignment: ResourceId | None = None
    current_assignment_options: list[ResourceId]
    """Used with choose queue rules - list of assignments for user to choose from"""
    checkers_brief: str
    mentor: ResourceId | None
    classes: list[ResourceId]
    queue: ResourceId | None
    disable_queue: bool
    user_queue: ResourceId | None
    disable_user_queue: bool
    override_queue: ResourceId | None
    confirmed: bool
    teacher: bool

    status_date: datetime
