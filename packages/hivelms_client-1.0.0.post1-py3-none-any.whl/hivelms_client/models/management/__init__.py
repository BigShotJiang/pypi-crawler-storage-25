"""Management-related Pydantic models."""
