"""Authentication request and response models."""

from pydantic import BaseModel


class AuthTokenRequest(BaseModel):
    """Request body for obtaining a JWT token pair.

    Attributes:
        password: The user's password.
        username: The user's username.
    """

    password: str
    username: str


class AuthTokenRefreshRequest(BaseModel):
    """Request body for refreshing an access token.

    Attributes:
        refresh: The refresh token issued at login.
    """

    refresh: str


class AuthTokenResponse(BaseModel):
    """Response containing a JWT refresh and access token pair.

    Attributes:
        refresh: Long-lived refresh token for obtaining new access tokens.
        access: Short-lived access token for authorising API requests.
    """

    refresh: str
    access: str
