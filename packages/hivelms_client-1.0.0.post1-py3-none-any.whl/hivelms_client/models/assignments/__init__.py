"""Assignment-related Pydantic models."""
