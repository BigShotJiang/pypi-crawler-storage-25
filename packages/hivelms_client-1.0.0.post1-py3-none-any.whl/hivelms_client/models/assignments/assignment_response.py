"""Assignment response resource models."""

from datetime import datetime
from enum import auto

from pydantic import BaseModel
from pydantic.experimental.missing_sentinel import MISSING

from hivelms_client.models.assignments.autocheck_status import AutocheckStatus
from hivelms_client.models.inline_bytes import InlineBytes
from hivelms_client.models.hive_common.modeling import (
    HiveOption,
    ResourceId,
    BaseHiveResource,
)


class AssignmentResponseType(HiveOption):
    """Enum of possible response types on an assignment.

    Attributes:
        COMMENT: A free-text comment left by staff or the student.
        WORK_IN_PROGRESS: Student saved intermediate progress without submitting.
        SUBMISSION: Student formally submitted their work for review.
        AUTOCHECK: An automated grading run was triggered for this response.
        REDO: Teacher requested the student revise and resubmit.
        DONE: Teacher marked the assignment as complete.
    """

    COMMENT = auto()
    WORK_IN_PROGRESS = auto()
    SUBMISSION = auto()
    AUTOCHECK = auto()
    REDO = auto()
    DONE = auto()


class AssignmentResponseContents(BaseModel):
    """A single field-content pair within a response.

    Attributes:
        content: The text content submitted for the field.
        field: ID of the form field this content belongs to.
    """

    content: str
    field: ResourceId


class AssignmentResponseCore(BaseModel):
    """Shared core fields for all assignment response variants.

    Attributes:
        response_type: Category of this response (e.g. submission, comment).
        contents: List of field-content pairs submitted with this response.
    """

    response_type: AssignmentResponseType
    contents: list[AssignmentResponseContents]


class AssignmentResponse(AssignmentResponseCore, BaseHiveResource):
    """Full assignment response resource returned by the API.

    Attributes:
        id: Unique numeric identifier assigned by the API.
        response_type: Category of this response (e.g. submission, comment).
        contents: List of field-content pairs submitted with this response.
        file_name: Name of the attached file, if any.
        dear_student: Whether this response is addressed directly to the student.
        hide_checker_name: Whether the checker's identity is hidden from the student.
        segel_only: Whether this response is visible to staff only.
        user: ID of the user who authored this response.
        date: Timestamp when the response was created.
        autocheck_statuses: List of autocheck events triggered by this response.
    """

    file_name: str
    dear_student: bool
    hide_checker_name: bool
    segel_only: bool

    user: ResourceId
    date: datetime
    autocheck_statuses: list[AutocheckStatus] | None


class AssignmentResponseInput(AssignmentResponseCore):
    """Input payload for creating an assignment response.

    Attributes:
        response_type: Category of this response (e.g. submission, comment).
        contents: List of field-content pairs submitted with this response.
        file_name: Name of the file to attach.
        dear_student: Address this response directly to the student.
        hide_checker_name: Hide the checker's identity from the student.
        segel_only: Restrict visibility to staff only.
        file: Raw file bytes to attach, serialised as a base64 data URI.
    """

    file_name: str = MISSING
    dear_student: bool = MISSING
    hide_checker_name: bool = MISSING
    segel_only: bool = MISSING

    file: InlineBytes | None = MISSING


class AssignmentBulkCommentInput(AssignmentResponseInput):
    """Input payload for posting a bulk comment across multiple classes.

    Attributes:
        response_type: Category of this response (e.g. submission, comment).
        contents: List of field-content pairs submitted with this response.
        file_name: Name of the file to attach.
        dear_student: Address this response directly to the student.
        hide_checker_name: Hide the checker's identity from the student.
        segel_only: Restrict visibility to staff only.
        file: Raw file bytes to attach, serialised as a base64 data URI.
        currently_assigned: Restrict the bulk comment to currently-assigned students only.
        classes: IDs of the classes to target with the bulk comment.
    """

    currently_assigned: bool
    classes: list[ResourceId]


class AssignmentResponsePatch(AssignmentResponseCore):
    """Partial update payload for an assignment response.

    Attributes:
        response_type: Category of this response.
        contents: List of field-content pairs to update.
        file_name: Name of the replacement file.
        dear_student: Address this response directly to the student.
        hide_checker_name: Hide the checker's identity from the student.
        segel_only: Restrict visibility to staff only.
        file: Raw replacement file bytes, serialised as a base64 data URI.
    """

    response_type: AssignmentResponseType = MISSING
    contents: list[AssignmentResponseContents] = MISSING
    file_name: str = MISSING
    dear_student: bool = MISSING
    hide_checker_name: bool = MISSING
    segel_only: bool = MISSING

    file: InlineBytes | None = MISSING
