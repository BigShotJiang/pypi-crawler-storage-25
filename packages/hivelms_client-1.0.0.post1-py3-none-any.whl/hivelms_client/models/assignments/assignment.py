"""Assignment resource models."""

from datetime import datetime
from typing import Annotated

from pydantic import StringConstraints, Field
from pydantic_core import MISSING

from hivelms_client.models.assignments.assignment_status import AssignmentStatus
from hivelms_client.models.hive_common.modeling import (
    ResourceId,
    HiveModel,
    BaseHiveResource,
)
from hivelms_client.models.notification.notification import NestedNotification

Description = Annotated[str, StringConstraints(min_length=1)]
Timer = Annotated[str, StringConstraints(max_length=100)]


class AssignmentNotification(BaseHiveResource):
    """Notification summary attached to an assignment.

    Attributes:
        id: Unique numeric identifier assigned by the API.
        user: ID of the student the notification belongs to.
        user_name: Display name of the student.
        exercise: ID of the related exercise.
        module: ID of the parent module.
        subject: ID of the parent subject.
        last_staff_updated: Timestamp of the last staff action.
    """

    user: ResourceId
    user_name: str
    exercise: ResourceId
    module: ResourceId
    subject: ResourceId
    last_staff_updated: datetime


class AssignmentInput(HiveModel):
    """Input payload for creating an assignment.

    Attributes:
        assignment_status: Teacher-visible status of the assignment.
        student_assignment_status: Student-visible status override.
        description: Free-text notes on the assignment.
        submission_count: Number of submissions made.
        total_check_count: Total number of checks performed.
        manual_check_count: Number of manual checks performed.
        flagged: Whether the assignment is flagged for attention.
        timer: Optional timer string associated with the assignment.
    """

    assignment_status: AssignmentStatus
    student_assignment_status: AssignmentStatus | None = MISSING
    description: str = MISSING
    submission_count: int = MISSING
    total_check_count: int = MISSING
    manual_check_count: int = MISSING
    flagged: bool = MISSING
    timer: str | None = MISSING


class Assignment(BaseHiveResource):
    """Full assignment resource returned by the API.

    Attributes:
        id: Unique numeric identifier assigned by the API.
        assignment_status: Teacher-visible status of the assignment.
        student_assignment_status: Student-visible status override.
        description: Free-text notes on the assignment.
        submission_count: Number of submissions made.
        total_check_count: Total number of checks performed.
        manual_check_count: Number of manual checks performed.
        flagged: Whether the assignment is flagged for attention.
        timer: Optional timer string associated with the assignment.
        user: ID of the student who owns the assignment.
        checker: ID of the checker assigned to review it, if any.
        checker_first_name: First name of the assigned checker.
        checker_last_name: Last name of the assigned checker.
        is_subscribed: Whether the current user is subscribed to updates.
        exercise: ID of the exercise being assigned.
        reveal_solution_to_student: Whether the solution is visible to the student.
        notifications: Nested notification summaries attached to this assignment.
        last_staff_updated: Timestamp of the last staff action.
        work_time: Cumulative work time in seconds.
    """

    assignment_status: AssignmentStatus
    student_assignment_status: AssignmentStatus | None
    description: str
    submission_count: int
    total_check_count: int
    manual_check_count: int
    flagged: bool
    timer: str | None

    user: ResourceId
    checker: ResourceId | None
    checker_first_name: str | None
    checker_last_name: str | None
    is_subscribed: bool
    exercise: ResourceId
    reveal_solution_to_student: Annotated[bool, Field(alias="patbas")]
    notifications: list[NestedNotification]
    last_staff_updated: datetime
    work_time: int


class AssignmentPatch(HiveModel):
    """Partial update payload for an assignment.

    Attributes:
        assignment_status: Teacher-visible status of the assignment.
        student_assignment_status: Student-visible status override.
        description: Free-text notes on the assignment.
        submission_count: Number of submissions made.
        total_check_count: Total number of checks performed.
        manual_check_count: Number of manual checks performed.
        flagged: Whether the assignment is flagged for attention.
        timer: Optional timer string associated with the assignment.
    """

    assignment_status: AssignmentStatus = MISSING
    student_assignment_status: AssignmentStatus | None = MISSING
    description: str = MISSING
    submission_count: int = MISSING
    total_check_count: int = MISSING
    manual_check_count: int = MISSING
    flagged: bool = MISSING
    timer: str | None = MISSING
