"""Autocheck action and status models."""

from datetime import datetime
from enum import auto

from pydantic import BaseModel

from hivelms_client.models.hive_common.modeling import HiveOption


class AutocheckAction(HiveOption):
    """Enum of actions produced during an autocheck run.

    Attributes:
        HANDLING: The autocheck runner has picked up the submission.
        NO_CHECK: No autocheck configuration exists for this exercise; skipped.
        BUILT: The submission was successfully built.
        FINISHED: The autocheck run has completed all steps.
        SENDING: Results are being dispatched back to the server.
        ERROR: An error occurred during the autocheck run.
        SUCCESS: The autocheck run completed and all checks passed.
    """

    HANDLING = auto()
    NO_CHECK = auto()
    BUILT = auto()
    FINISHED = auto()
    SENDING = auto()
    ERROR = auto()
    SUCCESS = auto()


class AutocheckStatus(BaseModel):
    """A timestamped autocheck event for a submission.

    Attributes:
        id: Unique identifier for this autocheck status record.
        time: Timestamp when the autocheck action occurred.
        action: The autocheck action that was taken.
        payload: Optional extra data produced by the action.
    """

    id: int
    time: datetime
    action: AutocheckAction
    payload: str | None = None
