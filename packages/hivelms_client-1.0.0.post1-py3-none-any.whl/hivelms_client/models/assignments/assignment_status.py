"""Assignment status enumeration."""

from enum import auto
from hivelms_client.models.hive_common.modeling import HiveOption


class AssignmentStatus(HiveOption):
    """Enum of possible states for an assignment.

    Attributes:
        NEW: Assignment has been created but the student has not yet started.
        WORK_IN_PROGRESS: Student has saved progress but not yet submitted.
        REDO: Teacher has sent the assignment back for revision.
        SUBMITTED: Student has submitted their work for review.
        AUTOCHECKED: Automated grading has been run on the submission.
        DONE: Assignment has been reviewed and marked complete.
    """

    NEW = auto()
    WORK_IN_PROGRESS = auto()
    REDO = auto()
    SUBMITTED = auto()
    AUTOCHECKED = auto()
    DONE = auto()
