"""Pydantic model package for Hive LMS resources."""
