"""Queue-related Pydantic models."""
