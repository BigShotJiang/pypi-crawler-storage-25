"""Queue item resource models."""

from enum import auto
from typing import Literal, Annotated

from pydantic import Field
from pydantic_core import MISSING

from hivelms_client.models.course.exercise.exercise import Exercise
from hivelms_client.models.hive_common.modeling import (
    HiveOption,
    ResourceId,
    HiveModel,
    BaseHiveResource,
)
from hivelms_client.models.queues.queue import Queue


class QueueRule(HiveOption):
    """Enum of rules controlling how a queue item advances a student.

    Attributes:
        CHOOSE: Student chooses which exercise to work on from this item.
        WAIT_FOR_SUBMITTED: Student must submit before advancing past this item.
        WAIT_FOR_AUTOCHECKS: Autocheck must pass before the student advances.
        WAIT_FOR_DONE: Assignment must be marked done before the student advances.
    """

    CHOOSE = auto()
    WAIT_FOR_SUBMITTED = auto()
    WAIT_FOR_AUTOCHECKS = auto()
    WAIT_FOR_DONE = auto()


class BaseQueueItem(BaseHiveResource):
    """Shared fields for all queue item variants.

    Attributes:
        order: Position of this item within its queue.
        enabled: Whether this queue item is active.
        queue_rule: Rule controlling how this item advances a student.
        continue_on_redo: Whether the student continues past this item on redo.
    """

    order: int
    enabled: bool
    queue_rule: QueueRule
    continue_on_redo: bool


class ExerciseQueueItem(BaseQueueItem):
    """Queue item that points to a specific exercise.

    Attributes:
        id: Unique numeric identifier assigned by the API.
        order: Position of this item within its queue.
        enabled: Whether this queue item is active.
        queue_rule: Rule controlling how this item advances a student.
        continue_on_redo: Whether the student continues past this item on redo.
        exercise: Full exercise resource this queue item points to.
    """

    exercise: Exercise


class NestedQueueQueueItem(BaseQueueItem):
    """Queue item that embeds another queue as a nested step.

    Attributes:
        id: Unique numeric identifier assigned by the API.
        order: Position of this item within its queue.
        enabled: Whether this queue item is active.
        queue_rule: Rule controlling how this item advances a student.
        continue_on_redo: Whether the student continues past this item on redo.
        nested_queue: The queue embedded as a step within this queue item.
    """

    nested_queue: Queue


QueueItem = ExerciseQueueItem | NestedQueueQueueItem


class BaseQueueItemInput(HiveModel):
    """Shared input fields for creating any queue item.

    Attributes:
        order: Position of this item within its queue.
        enabled: Whether this queue item is active.
        queue_rule: Rule controlling how this item advances a student.
        continue_on_redo: Whether the student continues past this item on redo.
    """

    order: int
    enabled: bool
    queue_rule: QueueRule
    continue_on_redo: bool = MISSING


class ExerciseQueueItemInput(BaseQueueItemInput):
    """Input payload for creating an exercise-based queue item.

    Attributes:
        order: Position of this item within its queue.
        enabled: Whether this queue item is active.
        queue_rule: Rule controlling how this item advances a student.
        continue_on_redo: Whether the student continues past this item on redo.
        exercise_id: ID of the exercise to assign to this queue item.
        set_nested_queue_id: Always ``None`` for exercise queue items.
        set_module_id: Always ``None`` for exercise queue items.
        set_tags_id: Always an empty list for exercise queue items.
    """

    exercise_id: ResourceId = Field(alias="set_exercise_id")
    set_nested_queue_id: Literal[None] = None
    set_module_id: Literal[None] = None
    set_tags_id: Literal[[]] = []


class NestedQueueQueueItemInput(BaseQueueItemInput):
    """Input payload for creating a nested-queue queue item.

    Attributes:
        order: Position of this item within its queue.
        enabled: Whether this queue item is active.
        queue_rule: Rule controlling how this item advances a student.
        continue_on_redo: Whether the student continues past this item on redo.
        nested_queue_id: ID of the queue to embed as a nested step.
        set_exercise_id: Always ``None`` for nested-queue items.
        set_module_id: Always ``None`` for nested-queue items.
        set_tags_id: Always an empty list for nested-queue items.
    """

    nested_queue_id: ResourceId = Field(alias="set_nested_queue_id")
    set_exercise_id: Literal[None] = None
    set_module_id: Literal[None] = None
    set_tags_id: Literal[[]] = []


class ModuleQueueItemInput(BaseQueueItemInput):
    """Input payload for creating a module-scoped queue item.

    Attributes:
        order: Position of this item within its queue.
        enabled: Whether this queue item is active.
        queue_rule: Rule controlling how this item advances a student.
        continue_on_redo: Whether the student continues past this item on redo.
        module_id: ID of the module to draw exercises from.
        filter_for_tags: IDs of tags to filter exercises by within the module.
        set_exercise_id: Always ``None`` for module queue items.
        set_nested_queue_id: Always ``None`` for module queue items.
    """

    module_id: ResourceId = Field(alias="set_module_id")
    filter_for_tags: list[ResourceId] = Field(alias="set_tags_id")
    set_exercise_id: Literal[None] = None
    set_nested_queue_id: Literal[None] = None


QueueItemInput = (
    ModuleQueueItemInput | ExerciseQueueItemInput | NestedQueueQueueItemInput
)


class QueueItemPatch(HiveModel):
    """Partial update payload for a queue item.

    Attributes:
        order: Replacement position within the queue.
        enabled: Whether this queue item should be active.
        queue_rule: Replacement advancement rule.
        continue_on_redo: Whether the student continues past this item on redo.
        exercise_id: Replacement exercise ID for exercise-based items.
        nested_queue_id: Replacement nested queue ID for nested-queue items.
    """

    order: int = MISSING
    enabled: bool = MISSING
    queue_rule: QueueRule = MISSING
    continue_on_redo: bool = MISSING
    exercise_id: Annotated[ResourceId, Field(alias="set_exercise_id")] = MISSING
    nested_queue_id: Annotated[ResourceId, Field(alias="set_nested_queue_id")] = MISSING


class QueueItemMoveRequest(HiveModel):
    """Request body for changing the order position of a queue item.

    Attributes:
        new_order: The target position to move this queue item to.
    """

    new_order: int
