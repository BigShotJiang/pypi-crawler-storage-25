"""Queue resource models."""

from typing import Annotated, Literal

from pydantic import BaseModel, StringConstraints
from pydantic_core import MISSING

from hivelms_client.models.hive_common.modeling import (
    ResourceId,
    BaseHiveResource,
    HiveModel,
)

QueueName = Annotated[str, StringConstraints(min_length=1, max_length=100)]
QueueDescription = Annotated[str, StringConstraints(max_length=150)]


class BaseQueueInput(HiveModel):
    """Shared input fields for creating any queue.

    Attributes:
        name: Display name of the queue.
        description: Optional description of the queue's purpose.
    """

    name: QueueName
    description: str | None = MISSING


class UserQueueInput(BaseQueueInput):
    """Input payload for creating a per-user queue.

    Attributes:
        user: ID of the user this queue is scoped to.
        module: Always ``None`` for user queues.
    """

    user: ResourceId
    module: Literal[None] = None


class ModuleQueueInput(BaseQueueInput):
    """Input payload for creating a module-scoped queue.

    Attributes:
        module: ID of the module this queue is scoped to.
        user: Always ``None`` for module queues.
    """

    module: ResourceId
    user: Literal[None] = None


class BaseQueue(BaseHiveResource):
    """Shared fields for all queue resources.

    Attributes:
        name: Display name of the queue.
        description: Description of the queue's purpose.
    """

    name: QueueName
    description: str


QueueInput = UserQueueInput | ModuleQueueInput


class ModuleQueue(BaseQueue):
    """Queue resource scoped to a specific module.

    Attributes:
        id: Unique numeric identifier assigned by the API.
        name: Display name of the queue.
        description: Description of the queue's purpose.
        module_id: ID of the module this queue is scoped to.
        module_name: Display name of the module.
        module_order: Ordering key of the module within its subject.
        program_id: ID of the grandparent program.
        program_name: Display name of the program.
        subject_id: ID of the parent subject.
        subject_name: Display name of the subject.
        subject_symbol: Symbol identifier of the subject.
        subject_color: Hex colour string of the subject.
    """

    module_id: ResourceId
    module_name: str
    module_order: str

    program_id: ResourceId
    program_name: str

    subject_id: int
    subject_name: str
    subject_symbol: str
    subject_color: str


class UserQueue(BaseQueue):
    """Queue resource scoped to a specific user.

    Attributes:
        id: Unique numeric identifier assigned by the API.
        name: Display name of the queue.
        description: Description of the queue's purpose.
        user_id: ID of the user this queue is scoped to.
        user_name: Display name of the user.
    """

    user_id: int
    user_name: str


Queue = UserQueue | ModuleQueue


class QueuePatch(BaseModel):
    """Partial update payload for a queue.

    Attributes:
        name: Replacement display name.
        description: Replacement description.
        module: Replacement module ID for module-scoped queues.
        user: Replacement user ID for user-scoped queues.
    """

    name: QueueName = MISSING
    description: QueueDescription | None = MISSING
    module: ResourceId = MISSING
    user: ResourceId = MISSING


class QueueDuplicationRequest(BaseModel):
    """Request body for duplicating a queue under a new name.

    Attributes:
        name: Name to give the duplicated queue.
        module: Module ID to associate with the duplicate, if module-scoped.
        user: User ID to associate with the duplicate, if user-scoped.
    """

    name: QueueName
    module: ResourceId | None = MISSING
    user: ResourceId | None = MISSING
