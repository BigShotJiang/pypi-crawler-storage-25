"""Subject resource models."""

from typing import Annotated

from pydantic import BaseModel, StringConstraints
from pydantic_core import MISSING

from hivelms_client.models.hive_common.modeling import ResourceId
from hivelms_client.models.course.exercise.exercise_options import SyncStatus

SubjectSymbol = Annotated[
    str, StringConstraints(min_length=1, pattern=r"[^-<>:/\\\"?*]+", max_length=100)
]
SubjectName = Annotated[
    str, StringConstraints(min_length=1, pattern=r"[^-<>:/\\\"?*]+", max_length=100)
]
Color = Annotated[
    str, StringConstraints(pattern=r"^#(?:[0-9a-fA-F]{6})$", max_length=7)
]


class SubjectCore(BaseModel):
    """Shared core fields for a subject.

    Attributes:
        symbol: Short identifier symbol for the subject (e.g. ``"ל"``).
        parent_program: ID of the program this subject belongs to.
        color: Hex colour string used to represent the subject in the UI.
        name: Human-readable name of the subject.
    """

    symbol: SubjectSymbol
    parent_program: ResourceId
    color: Color
    name: SubjectName


class Subject(SubjectCore):
    """Full subject resource returned by the API.

    Attributes:
        id: Unique numeric identifier assigned by the API.
        parent_program_name: Display name of the parent program.
        sync_status: Current GitLab synchronisation state.
        sync_message: Human-readable message describing the sync state.
        segel_path: Filesystem path to the subject on the staff server.
    """

    id: ResourceId
    parent_program_name: str
    sync_status: SyncStatus
    sync_message: str | None
    segel_path: str | None


class SubjectInput(SubjectCore):
    """Input payload for creating a subject.

    Attributes:
        symbol: Short identifier symbol for the subject (e.g. ``"ל"``).
        parent_program: ID of the program this subject belongs to.
        color: Hex colour string used to represent the subject in the UI.
        name: Human-readable name of the subject.
    """


class SubjectPatch(BaseModel):
    """Partial update payload for a subject.

    Attributes:
        symbol: Replacement short identifier symbol.
        parent_program: Replacement parent program ID.
        color: Replacement hex colour string.
        name: Replacement human-readable name.
    """

    symbol: SubjectSymbol = MISSING
    parent_program: ResourceId = MISSING
    color: Color = MISSING
    name: SubjectName = MISSING
