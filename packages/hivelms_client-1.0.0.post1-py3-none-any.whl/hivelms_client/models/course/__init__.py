"""Course-related Pydantic models."""
