"""Program resource models."""

from typing import Annotated

from pydantic import BaseModel, Field
from pydantic.experimental.missing_sentinel import MISSING

from hivelms_client.models.hive_common.data_types import HiveFilenameComponent
from hivelms_client.models.hive_common.modeling import ResourceId, BaseHiveResource
from hivelms_client.models.course.exercise.exercise_options import SyncStatus

RaiseHand = Annotated[bool, Field(alias="hanich_raise_hand")]
ShowOneDaySchedule = Annotated[bool, Field(alias="hanich_day_only")]
ShowLessonNames = Annotated[bool, Field(alias="hanich_work_name")]


class ProgramCore(BaseModel):
    """Shared core fields for a program.

    Attributes:
        name: Filename-safe display name of the program.
        checker: ID of the default checker assigned to this program.
    """

    name: HiveFilenameComponent
    checker: ResourceId


class Program(BaseHiveResource, ProgramCore):
    """Full program resource returned by the API.

    Attributes:
        id: Unique numeric identifier assigned by the API.
        name: Filename-safe display name of the program.
        checker: ID of the default checker assigned to this program.
        default_class: ID of the default class for new students, if set.
        auto_toilet: Whether toilet requests are handled automatically.
        allow_raising_hands: Whether students can raise their hands via the UI.
        auto_schedule: Whether the schedule is generated automatically.
        auto_room: Whether room assignment is automatic.
        show_one_day_schedule: Whether students see only today's schedule.
        show_lesson_names: Whether lesson names are visible to students.
        auto_toilet_count: Maximum concurrent automatic toilet allowances.
        hanich_classes_only: Whether students see only their own classes.
        hanich_schedule: Whether students have access to the schedule view.
        sync_status: Current GitLab synchronisation state.
        sync_message: Human-readable message describing the sync state.
    """

    default_class: ResourceId | None
    auto_toilet: bool
    allow_raising_hands: RaiseHand
    auto_schedule: bool
    auto_room: bool
    show_one_day_schedule: ShowOneDaySchedule
    show_lesson_names: ShowLessonNames
    auto_toilet_count: int
    hanich_classes_only: bool
    hanich_schedule: bool

    sync_status: SyncStatus
    sync_message: str


class ProgramInput(ProgramCore):
    """Input payload for creating a program.

    Attributes:
        name: Filename-safe display name of the program.
        checker: ID of the default checker assigned to this program.
        default_class: ID of the default class for new students.
        auto_toilet: Whether toilet requests are handled automatically.
        allow_raising_hands: Whether students can raise their hands via the UI.
        auto_schedule: Whether the schedule is generated automatically.
        auto_room: Whether room assignment is automatic.
        show_one_day_schedule: Whether students see only today's schedule.
        show_lesson_names: Whether lesson names are visible to students.
        auto_toilet_count: Maximum concurrent automatic toilet allowances.
        hanich_classes_only: Whether students see only their own classes.
        hanich_schedule: Whether students have access to the schedule view.
    """

    default_class: int | None = MISSING
    auto_toilet: bool = MISSING
    allow_raising_hands: RaiseHand = MISSING
    auto_schedule: bool = MISSING
    auto_room: bool = MISSING
    show_one_day_schedule: ShowOneDaySchedule = MISSING
    show_lesson_names: ShowLessonNames = MISSING
    auto_toilet_count: int = MISSING
    hanich_classes_only: bool = MISSING
    hanich_schedule: bool = MISSING


class ProgramPatch(ProgramCore):
    """Partial update payload for a program.

    Attributes:
        name: Replacement filename-safe name.
        checker: Replacement default checker ID.
        default_class: Replacement default class ID.
        auto_toilet: Whether toilet requests are handled automatically.
        allow_raising_hands: Whether students can raise their hands via the UI.
        auto_schedule: Whether the schedule is generated automatically.
        auto_room: Whether room assignment is automatic.
        show_one_day_schedule: Whether students see only today's schedule.
        show_lesson_names: Whether lesson names are visible to students.
        auto_toilet_count: Maximum concurrent automatic toilet allowances.
        hanich_classes_only: Whether students see only their own classes.
        hanich_schedule: Whether students have access to the schedule view.
    """

    name: HiveFilenameComponent = MISSING
    checker: int = MISSING
    default_class: int | None = MISSING
    auto_toilet: bool = MISSING
    allow_raising_hands: RaiseHand = MISSING
    auto_schedule: bool = MISSING
    auto_room: bool = MISSING
    show_one_day_schedule: ShowOneDaySchedule = MISSING
    show_lesson_names: ShowLessonNames = MISSING
    auto_toilet_count: int = MISSING
    hanich_classes_only: bool = MISSING
    hanich_schedule: bool = MISSING
