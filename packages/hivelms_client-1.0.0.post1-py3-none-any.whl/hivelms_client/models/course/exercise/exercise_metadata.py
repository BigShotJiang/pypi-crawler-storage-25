"""Exercise metadata models for GitLab and autocheck configuration."""

from typing import Any

from pydantic import ConfigDict
from pydantic_core import MISSING

from hivelms_client.models.hive_common.modeling import HiveModel


class ExerciseGitlabParameters(HiveModel):
    """GitLab repository parameters used when creating an exercise.

    Attributes:
        namespace: GitLab namespace (group or user) in which to create the repo.
        source_repo: URL or path of the template repository to fork from.
        new_repo_name: Name for the newly created repository.
        base_branch_name: Name of the base/solution branch.
        work_branch_name: Name of the student work branch.
        detailed_instructions: Whether to include detailed instructions in the repo.
    """

    namespace: str = MISSING
    source_repo: str = MISSING
    new_repo_name: str = MISSING
    base_branch_name: str = MISSING
    work_branch_name: str = MISSING
    detailed_instructions: bool = MISSING


class ExerciseMetadata(HiveModel):
    """Metadata bag for exercise creation, covering GitLab and autocheck config.

    Attributes:
        gitlab: GitLab repository parameters for this exercise.
        autocheck: Arbitrary autocheck configuration passed to the grading runner.
    """

    gitlab: ExerciseGitlabParameters = MISSING
    autocheck: dict[str, Any] = MISSING

    model_config = ConfigDict(extra="allow")
