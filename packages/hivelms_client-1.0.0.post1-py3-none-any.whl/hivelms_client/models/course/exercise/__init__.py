"""Exercise-related Pydantic models."""
