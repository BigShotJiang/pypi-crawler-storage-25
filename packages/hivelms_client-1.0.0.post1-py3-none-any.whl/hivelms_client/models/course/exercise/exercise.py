"""Exercise resource models."""

from typing import Annotated

from pydantic import BaseModel, StringConstraints
from pydantic_core import MISSING

from hivelms_client.models.course.exercise.exercise_metadata import ExerciseMetadata
from hivelms_client.models.course.exercise.exercise_options import (
    ExercisePreviewMode,
    SolutionRevealCondition,
    SyncStatus,
)
from hivelms_client.models.hive_common.data_types import (
    HiveFilenameComponent,
    HiveColor,
    HiveDuration,
    OptionalString,
    DockerTag,
)
from hivelms_client.models.hive_common.modeling import (
    ResourceId,
    BaseHiveResource,
    HiveModel,
)

ExerciseStyle = Annotated[str, StringConstraints(max_length=100)]


class ExerciseCore(HiveModel):
    """Shared core fields common to all exercise variants.

    Attributes:
        name: Filename-safe name of the exercise.
        parent_module: ID of the module this exercise belongs to.
        download: Whether students can download exercise materials.
        preview: How exercise content is previewed for students.
        patbas: Condition under which the solution is revealed to students.
        order: Ordering key within the parent module.
        tags: List of tag names attached to this exercise.
        patbas_preview: Preview mode applied to the revealed solution.
        patbas_download: Whether the solution is downloadable when revealed.
        is_lecture: Whether this exercise is a lecture rather than a task.
        style: Optional CSS class or style string for display customisation.
        on_creation_data: Metadata used when provisioning exercise resources on creation.
        autocheck_tag: Docker image tag for the autocheck runner, if any.
        autodone: Whether the exercise is automatically marked done after autocheck passes.
        expected_duration: Expected time to complete the exercise.
        segel_brief: Staff-facing brief description of the exercise.
    """

    name: HiveFilenameComponent
    parent_module: ResourceId
    download: bool
    preview: ExercisePreviewMode
    patbas: SolutionRevealCondition
    order: HiveFilenameComponent
    tags: list[str]

    patbas_preview: ExercisePreviewMode
    patbas_download: bool
    is_lecture: bool
    style: ExerciseStyle | None
    on_creation_data: ExerciseMetadata
    autocheck_tag: OptionalString[DockerTag]
    autodone: bool
    expected_duration: HiveDuration | None
    segel_brief: str


class Exercise(ExerciseCore, BaseHiveResource):
    """Full exercise resource returned by the API.

    Attributes:
        id: Unique numeric identifier assigned by the API.
        name: Filename-safe name of the exercise.
        parent_module: ID of the module this exercise belongs to.
        download: Whether students can download exercise materials.
        preview: How exercise content is previewed for students.
        patbas: Condition under which the solution is revealed to students.
        order: Ordering key within the parent module.
        tags: List of tag names attached to this exercise.
        patbas_preview: Preview mode applied to the revealed solution.
        patbas_download: Whether the solution is downloadable when revealed.
        is_lecture: Whether this exercise is a lecture rather than a task.
        style: Optional CSS class or style string for display customisation.
        on_creation_data: Metadata used when provisioning exercise resources on creation.
        autocheck_tag: Docker image tag for the autocheck runner, if any.
        autodone: Whether the exercise is automatically marked done after autocheck passes.
        expected_duration: Expected time to complete the exercise.
        segel_brief: Staff-facing brief description of the exercise.
        parent_subject: ID of the subject this exercise belongs to.
        parent_module_name: Display name of the parent module.
        parent_subject_symbol: Symbol identifier of the parent subject.
        parent_subject_color: Hex colour of the parent subject.
        parent_subject_name: Display name of the parent subject.
        parent_module_order: Ordering key of the parent module.
        segel_path: Filesystem path to the exercise on the staff server.
        sync_status: Current GitLab synchronisation state.
        sync_message: Human-readable message describing the sync state.
    """

    parent_subject: ResourceId
    parent_module_name: str
    parent_subject_symbol: str
    parent_subject_color: HiveColor
    parent_subject_name: str
    parent_module_order: str

    segel_path: str
    sync_status: SyncStatus
    sync_message: str


class ExerciseInput(ExerciseCore):
    """Input payload for creating an exercise.

    Attributes:
        name: Filename-safe name of the exercise.
        parent_module: ID of the module this exercise belongs to.
        download: Whether students can download exercise materials.
        preview: How exercise content is previewed for students.
        patbas: Condition under which the solution is revealed to students.
        order: Ordering key within the parent module.
        tags: List of tag names attached to this exercise.
        patbas_preview: Preview mode applied to the revealed solution.
        patbas_download: Whether the solution is downloadable when revealed.
        is_lecture: Whether this exercise is a lecture rather than a task.
        style: Optional CSS class or style string for display customisation.
        on_creation_data: Metadata used when provisioning exercise resources on creation.
        autocheck_tag: Docker image tag for the autocheck runner, if any.
        autodone: Whether the exercise is automatically marked done after autocheck passes.
        expected_duration: Expected time to complete the exercise.
        segel_brief: Staff-facing brief description of the exercise.
    """

    patbas_preview: ExercisePreviewMode = MISSING
    patbas_download: bool = MISSING
    is_lecture: bool = MISSING
    style: ExerciseStyle = MISSING
    on_creation_data: ExerciseMetadata = MISSING
    autocheck_tag: OptionalString[DockerTag] = MISSING
    autodone: bool = MISSING
    expected_duration: HiveDuration | None = MISSING
    segel_brief: str = MISSING


class ExercisePatch(BaseModel):
    """Partial update payload for an exercise.

    Attributes:
        name: Replacement filename-safe name.
        parent_module: Replacement parent module ID.
        download: Whether students can download exercise materials.
        preview: How exercise content is previewed for students.
        patbas: Condition under which the solution is revealed to students.
        order: Replacement ordering key within the parent module.
        tags: Replacement list of tag names.
        patbas_preview: Preview mode applied to the revealed solution.
        patbas_download: Whether the solution is downloadable when revealed.
        is_lecture: Whether this exercise is a lecture rather than a task.
        style: Replacement CSS class or style string.
        on_creation_data: Replacement exercise creation metadata.
        autocheck_tag: Replacement Docker image tag for the autocheck runner.
        autodone: Whether to auto-mark done after autocheck passes.
        expected_duration: Replacement expected duration.
        segel_brief: Replacement staff-facing brief description.
    """

    name: HiveFilenameComponent = MISSING
    parent_module: ResourceId = MISSING
    download: bool = MISSING
    preview: ExercisePreviewMode = MISSING
    patbas: SolutionRevealCondition = MISSING
    order: HiveFilenameComponent = MISSING
    tags: list[str] = MISSING
    patbas_preview: ExercisePreviewMode = MISSING
    patbas_download: bool = MISSING
    is_lecture: bool = MISSING
    style: ExerciseStyle | None = MISSING
    on_creation_data: ExerciseMetadata = MISSING
    autocheck_tag: OptionalString[DockerTag] = MISSING
    autodone: bool = MISSING
    expected_duration: HiveDuration | None = MISSING
    segel_brief: str = MISSING
