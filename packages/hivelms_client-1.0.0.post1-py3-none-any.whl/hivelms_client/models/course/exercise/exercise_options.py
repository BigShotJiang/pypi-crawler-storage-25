"""Exercise option enumerations."""

from enum import auto

from hivelms_client.models.hive_common.modeling import HiveOption


class ExercisePreviewMode(HiveOption):
    """Enum controlling how exercise content is previewed.

    Attributes:
        DISABLED: No preview is shown; students must download the content.
        MARKDOWN: Content is rendered as Markdown in the browser.
        PDF: Content is displayed as an embedded PDF viewer.
    """

    DISABLED = auto()
    MARKDOWN = auto()
    PDF = "PDF"


class SolutionRevealCondition(HiveOption):
    """Enum defining when the solution may be revealed to students.

    Attributes:
        NEVER: The solution is never shown to students.
        ON_DONE: The solution becomes visible once the assignment is marked done.
        ALWAYS: The solution is always visible to students.
        STAFF_ONLY: The solution is restricted to staff and never shown to students.
    """

    NEVER = auto()
    ON_DONE = auto()
    ALWAYS = auto()
    STAFF_ONLY = auto()


class SyncStatus(HiveOption):
    """Enum representing the GitLab sync state of a course resource.

    Attributes:
        CREATING: GitLab repository creation is in progress.
        DELETING: GitLab repository deletion is in progress.
        NORMAL: The resource is fully synced with its GitLab repository.
        ERROR: An error occurred during the last GitLab sync operation.
    """

    CREATING = auto()
    DELETING = auto()
    NORMAL = auto()
    ERROR = auto()
