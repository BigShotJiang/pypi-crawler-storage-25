"""Form field models for exercise submission fields."""

from typing import Annotated, Literal

from pydantic import BaseModel, JsonValue, StringConstraints, Discriminator
from pydantic_core import MISSING

from hivelms_client.models.hive_common.modeling import (
    HiveOption,
    ResourceId,
    HiveModel,
    BaseHiveResource,
)


class FormFieldType(HiveOption):
    """Enum of supported form field types.

    Attributes:
        TEXT: A free-text input field accepting arbitrary string content.
        NUMBER: A numeric input field accepting integer values.
        MULTIPLE: A single-choice field presented as a radio button group.
        MULTI_RESPONSE: A multi-choice field allowing multiple selections.
    """

    TEXT = ("text",)
    NUMBER = ("number",)
    MULTIPLE = ("multiple",)
    MULTI_RESPONSE = "multiResponse"


FormFieldMetadata = dict[str, JsonValue]


class BaseFormFieldCore(HiveModel):
    """Shared core fields for all form field types.

    Attributes:
        name: Internal name of the field used as a key in submissions.
        description: Human-readable label shown to the student.
        order: Display order within the exercise form.
        required: Whether the student must fill in this field.
        staff_responses: Whether staff can respond using this field.
        hanich_responses: Whether students can respond using this field.
        segel_only: Whether this field is visible to staff only.
        metadata: Arbitrary extra metadata attached to the field.
        groups: IDs of form groups this field belongs to.
    """

    name: str
    description: str
    order: int
    required: bool
    staff_responses: bool
    hanich_responses: bool
    segel_only: bool
    metadata: FormFieldMetadata
    groups: list[ResourceId]


class BaseFormFieldInput(BaseFormFieldCore):
    """Base input payload for creating any form field.

    Attributes:
        description: Human-readable label shown to the student.
        metadata: Arbitrary extra metadata for the field.
        groups: IDs of form groups to assign this field to.
    """

    description: str = MISSING
    metadata: FormFieldMetadata = MISSING
    groups: list[ResourceId] = MISSING


class UnfillableFormFieldCore(BaseFormFieldCore):
    """Core mixin for form fields that cannot hold a student value.

    Attributes:
        type: Discriminator field identifying the form field kind.
        has_value: Always ``False``; marks this field as unfillable.
    """

    type: FormFieldType
    has_value: Literal[False] = False


class BaseFillableFormFieldCore(BaseFormFieldCore):
    """Core mixin for form fields that accept a student value.

    Attributes:
        has_value: Always ``True``; marks this field as fillable.
    """

    has_value: Literal[True] = True


class TextFormFieldCore(BaseFillableFormFieldCore):
    """Core mixin for a free-text form field.

    Attributes:
        type: Discriminator literal identifying this as a text field.
    """

    type: Literal[FormFieldType.TEXT] = FormFieldType.TEXT


class NumericFormFieldCore(BaseFillableFormFieldCore):
    """Core mixin for a numeric form field with optional range limits.

    Attributes:
        type: Discriminator literal identifying this as a numeric field.
        lower_limit: Minimum accepted value, or ``None`` for no lower bound.
        upper_limit: Maximum accepted value, or ``None`` for no upper bound.
    """

    type: Literal[FormFieldType.NUMBER] = FormFieldType.NUMBER
    lower_limit: int | None = MISSING
    upper_limit: int | None = MISSING


class ChoicesFormFieldCore(BaseFillableFormFieldCore):
    """Core mixin for form fields that present a list of choices.

    Attributes:
        type: Discriminator literal identifying this as a choices-based field.
        choices: Ordered list of option strings the student can select from.
    """

    type: Literal[FormFieldType.MULTIPLE, FormFieldType.MULTI_RESPONSE]
    choices: list[str]


class RadioFormFieldCore(ChoicesFormFieldCore):
    """Core mixin for a single-choice (radio) form field.

    Attributes:
        type: Discriminator literal identifying this as a radio field.
    """

    type: Literal[FormFieldType.MULTIPLE] = FormFieldType.MULTIPLE


class CheckboxesFormFieldCore(ChoicesFormFieldCore):
    """Core mixin for a multi-choice (checkboxes) form field.

    Attributes:
        type: Discriminator literal identifying this as a checkboxes field.
    """

    type: Literal[FormFieldType.MULTI_RESPONSE] = FormFieldType.MULTI_RESPONSE


class UnfillableFormFieldInput(BaseFormFieldInput, UnfillableFormFieldCore):
    """Input payload for creating an unfillable form field."""


class TextFormFieldInput(BaseFormFieldInput, TextFormFieldCore):
    """Input payload for creating a text form field."""


class NumericFormFieldInput(BaseFormFieldInput, NumericFormFieldCore):
    """Input payload for creating a numeric form field."""


class RadioFormFieldInput(BaseFormFieldInput, RadioFormFieldCore):
    """Input payload for creating a radio (single-choice) form field."""


class CheckboxesFormFieldInput(BaseFormFieldInput, CheckboxesFormFieldCore):
    """Input payload for creating a checkboxes (multi-choice) form field."""


class UnfillableFormField(UnfillableFormFieldCore, BaseHiveResource):
    """Unfillable form field resource returned by the API.

    Attributes:
        id: Unique numeric identifier assigned by the API.
        name: Internal name of the field used as a key in submissions.
        description: Human-readable label shown to the student.
        order: Display order within the exercise form.
        required: Whether the student must fill in this field.
        staff_responses: Whether staff can respond using this field.
        hanich_responses: Whether students can respond using this field.
        segel_only: Whether this field is visible to staff only.
        metadata: Arbitrary extra metadata attached to the field.
        groups: IDs of form groups this field belongs to.
        type: Discriminator field identifying the form field kind.
        has_value: Always ``False``; marks this field as unfillable.
    """


class TextFormField(TextFormFieldCore, BaseHiveResource):
    """Text form field resource returned by the API.

    Attributes:
        id: Unique numeric identifier assigned by the API.
        name: Internal name of the field used as a key in submissions.
        description: Human-readable label shown to the student.
        order: Display order within the exercise form.
        required: Whether the student must fill in this field.
        staff_responses: Whether staff can respond using this field.
        hanich_responses: Whether students can respond using this field.
        segel_only: Whether this field is visible to staff only.
        metadata: Arbitrary extra metadata attached to the field.
        groups: IDs of form groups this field belongs to.
        has_value: Always ``True``; marks this field as fillable.
        type: Discriminator literal identifying this as a text field.
    """


class NumericFormField(NumericFormFieldCore, BaseHiveResource):
    """Numeric form field resource returned by the API.

    Attributes:
        id: Unique numeric identifier assigned by the API.
        name: Internal name of the field used as a key in submissions.
        description: Human-readable label shown to the student.
        order: Display order within the exercise form.
        required: Whether the student must fill in this field.
        staff_responses: Whether staff can respond using this field.
        hanich_responses: Whether students can respond using this field.
        segel_only: Whether this field is visible to staff only.
        metadata: Arbitrary extra metadata attached to the field.
        groups: IDs of form groups this field belongs to.
        has_value: Always ``True``; marks this field as fillable.
        type: Discriminator literal identifying this as a numeric field.
        lower_limit: Minimum accepted value, or ``None`` for no lower bound.
        upper_limit: Maximum accepted value, or ``None`` for no upper bound.
    """


class RadioFormField(RadioFormFieldCore, BaseHiveResource):
    """Radio form field resource returned by the API.

    Attributes:
        id: Unique numeric identifier assigned by the API.
        name: Internal name of the field used as a key in submissions.
        description: Human-readable label shown to the student.
        order: Display order within the exercise form.
        required: Whether the student must fill in this field.
        staff_responses: Whether staff can respond using this field.
        hanich_responses: Whether students can respond using this field.
        segel_only: Whether this field is visible to staff only.
        metadata: Arbitrary extra metadata attached to the field.
        groups: IDs of form groups this field belongs to.
        has_value: Always ``True``; marks this field as fillable.
        type: Discriminator literal identifying this as a radio field.
        choices: Ordered list of option strings the student can select from.
    """


class CheckboxesFormField(CheckboxesFormFieldCore, BaseHiveResource):
    """Checkboxes form field resource returned by the API.

    Attributes:
        id: Unique numeric identifier assigned by the API.
        name: Internal name of the field used as a key in submissions.
        description: Human-readable label shown to the student.
        order: Display order within the exercise form.
        required: Whether the student must fill in this field.
        staff_responses: Whether staff can respond using this field.
        hanich_responses: Whether students can respond using this field.
        segel_only: Whether this field is visible to staff only.
        metadata: Arbitrary extra metadata attached to the field.
        groups: IDs of form groups this field belongs to.
        has_value: Always ``True``; marks this field as fillable.
        type: Discriminator literal identifying this as a checkboxes field.
        choices: Ordered list of option strings the student can select from.
    """


FillableFormField = Annotated[
    TextFormField | NumericFormField | RadioFormField | CheckboxesFormField,
    Discriminator("type"),
]

FormField = Annotated[
    FillableFormField | UnfillableFormField, Discriminator("has_value")
]

FillableFormFieldInput = Annotated[
    TextFormFieldInput
    | NumericFormFieldInput
    | RadioFormFieldInput
    | CheckboxesFormFieldInput,
    Discriminator("type"),
]
FormFieldInput = Annotated[
    FillableFormFieldInput | UnfillableFormFieldInput, Discriminator("has_value")
]


class FormFieldPatch(BaseModel):
    """Partial update payload for a form field.

    Attributes:
        name: Replacement internal field name.
        order: Replacement display order within the form.
        required: Whether the student must fill in this field.
        staff_responses: Whether staff can respond using this field.
        hanich_responses: Whether students can respond using this field.
        has_value: Whether this field accepts a student value.
        type: Replacement field type discriminator.
        description: Replacement human-readable label.
        lower_limit: Replacement minimum accepted value for numeric fields.
        upper_limit: Replacement maximum accepted value for numeric fields.
        choices: Replacement list of selectable options.
        segel_only: Whether this field is visible to staff only.
        metadata: Replacement extra metadata.
        groups: Replacement list of form group IDs.
    """

    name: str = MISSING
    order: int = MISSING
    required: bool = MISSING
    staff_responses: bool = MISSING
    hanich_responses: bool = MISSING
    has_value: bool = MISSING
    type: FormFieldType = MISSING

    description: str = MISSING
    lower_limit: int | None = MISSING
    upper_limit: int | None = MISSING
    choices: list[str] | None = MISSING
    segel_only: bool = MISSING
    metadata: FormFieldMetadata = MISSING
    groups: list[ResourceId] = MISSING


class FormFieldTopResponse(BaseHiveResource):
    """Most common student responses for a given form field.

    Attributes:
        name: Internal name of the form field.
        top_results: Most frequently submitted values, or ``None`` if unavailable.
    """

    name: str
    top_results: list[str] | None = None


class FormFieldDuplicationRequest(BaseModel):
    """Request body for duplicating a form field under a new name.

    Attributes:
        name: Name to give the newly duplicated form field.
    """

    name: Annotated[str, StringConstraints(min_length=1)]
