"""Module resource models."""

from pydantic import BaseModel
from pydantic_core import MISSING

from hivelms_client.models.hive_common.modeling import HiveModel, BaseHiveResource
from hivelms_client.models.hive_common.data_types import HiveFilenameComponent
from hivelms_client.models.course.exercise.exercise_options import SyncStatus


class ModuleCore(HiveModel):
    """Shared core fields for a course module.

    Attributes:
        name: Filename-safe display name of the module.
        parent_subject: ID of the subject this module belongs to.
        order: Ordering key within the parent subject.
    """

    name: HiveFilenameComponent
    parent_subject: int
    order: HiveFilenameComponent


class Module(ModuleCore, BaseHiveResource):
    """Full module resource returned by the API.

    Attributes:
        id: Unique numeric identifier assigned by the API.
        name: Filename-safe display name of the module.
        parent_subject: ID of the subject this module belongs to.
        order: Ordering key within the parent subject.
        sync_status: Current GitLab synchronisation state.
        sync_message: Human-readable message describing the sync state.
        parent_program_name: Display name of the grandparent program.
        parent_subject_name: Display name of the parent subject.
        parent_subject_symbol: Symbol identifier of the parent subject.
        segel_path: Filesystem path to the module on the staff server.
    """

    sync_status: SyncStatus
    sync_message: str
    parent_program_name: str
    parent_subject_name: str
    parent_subject_symbol: str
    segel_path: str


class ModuleInput(ModuleCore):
    """Input payload for creating a module.

    Attributes:
        name: Filename-safe display name of the module.
        parent_subject: ID of the subject this module belongs to.
        order: Ordering key within the parent subject.
    """


class ModulePatch(BaseModel):
    """Partial update payload for a module.

    Attributes:
        name: Replacement filename-safe name.
        parent_subject: Replacement parent subject ID.
        order: Replacement ordering key within the parent subject.
    """

    name: HiveFilenameComponent = MISSING
    parent_subject: int = MISSING
    order: HiveFilenameComponent = MISSING
