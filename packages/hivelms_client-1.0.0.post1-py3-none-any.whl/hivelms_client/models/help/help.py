"""Help thread resource models."""

from datetime import datetime
from enum import auto
from typing import Annotated

from pydantic import BaseModel, StringConstraints
from pydantic_core import MISSING

from hivelms_client.models.course.exercise.exercise import Exercise
from hivelms_client.models.help.help_response import HelpResponse
from hivelms_client.models.hive_common.modeling import (
    HiveOption,
    ResourceId,
    BaseHiveResource,
)
from hivelms_client.models.notification.notification import NestedNotification

HelpTitle = Annotated[str, StringConstraints(max_length=30)]


class HelpType(HiveOption):
    """Enum of help request categories.

    Attributes:
        EXERCISE: Help request related to a specific exercise.
        MEDICAL: Student is requesting help for a medical reason.
        ERROR: Student is reporting a technical error or bug.
        MUSIC: Request related to music or background audio in the classroom.
        REQUEST: A general request directed at staff.
        OTHER: Any help request that does not fit another category.
        CHAT: An chat thread opened by staff.
    """

    EXERCISE = auto()
    MEDICAL = auto()
    ERROR = auto()
    MUSIC = auto()
    REQUEST = auto()
    OTHER = auto()
    CHAT = auto()


class HelpStatus(HiveOption):
    """Enum of possible states for a help thread.

    Attributes:
        RESOLVED: The help thread has been addressed and closed by staff.
        OPEN: The help thread is awaiting a staff response.
    """

    RESOLVED = auto()
    OPEN = auto()


class HelpVisibility(HiveOption):
    """Enum controlling who can see a help thread.

    Attributes:
        ALL_STAFF: Visible to all staff members.
        ALL_STAFF_AND_CHECKERS: Visible to staff and checkers.
        AUTHOR_ONLY: Visible only to the student who opened the thread.
    """

    ALL_STAFF = auto()
    ALL_STAFF_AND_CHECKERS = auto()
    AUTHOR_ONLY = auto()


class HelpCore(BaseModel):
    """Minimal shared fields for a help thread.

    Attributes:
        user: ID of the student who opened the help thread.
        help_type: Category of the help request.
    """

    user: ResourceId
    help_type: HelpType


class HelpInput(HelpCore):
    """Input payload for opening a help thread.

    Attributes:
        user: ID of the student who opened the help thread.
        help_type: Category of the help request.
        title: Short title summarising the help request.
        visibility: Who is allowed to see this help thread.
        exercise_id: ID of the exercise this help request relates to, if any.
    """

    title: HelpTitle = MISSING
    visibility: HelpVisibility = MISSING
    exercise_id: int | None


class Help(HelpCore, BaseHiveResource):
    """Full help thread resource returned by the API.

    Attributes:
        id: Unique numeric identifier assigned by the API.
        user: ID of the student who opened the help thread.
        help_type: Category of the help request.
        title: Short title summarising the help request.
        visibility: Who is allowed to see this help thread.
        is_subscribed: Whether current user is subscribed to this help.
        for_exercise: Full exercise resource this thread relates to, if any.
        checker: ID of the checker handling this thread, if assigned.
        checker_first_name: First name of the assigned checker.
        checker_last_name: Last name of the assigned checker.
        help_status: Current open/resolved state of the thread.
        responses: Ordered list of responses within this thread.
        notifications: Nested notification summaries attached to this thread.
    """

    title: HelpTitle
    visibility: HelpVisibility

    is_subscribed: bool
    """Whether current user is subscribed to this help."""

    for_exercise: Exercise | None = None

    checker: ResourceId | None
    checker_first_name: str | None
    checker_last_name: str | None

    help_status: HelpStatus
    responses: list[HelpResponse]
    notifications: list[NestedNotification]


class HelpPatch(BaseModel):
    """Partial update payload for a help thread.

    Attributes:
        user: Replacement student ID for the thread owner.
        title: Replacement title for the help thread.
        help_type: Replacement category for the help request.
        visibility: Replacement visibility setting.
        exercise_id: Replacement exercise ID, or ``None`` to clear it.
    """

    user: ResourceId = MISSING
    title: HelpTitle = MISSING
    help_type: HelpType = MISSING
    visibility: HelpVisibility = MISSING
    exercise_id: int | None = MISSING


class HelpNotification(BaseModel):
    """A notification event associated with a help thread.

    Attributes:
        id: Unique identifier for this notification record.
        help_id: ID of the related help thread.
        user: ID of the user this notification is for.
        date: ISO timestamp string of the notification, if available.
        message: Optional human-readable notification message.
    """

    id: int
    help_id: int
    user: int
    date: str | None = None
    message: str | None = None


class HelpLatestItem(BaseModel):
    """Summary of the most-recently-updated help thread for a user.

    Attributes:
        id: ID of the help thread.
        user_name: Display name of the student who opened the thread.
        last_staff_updated: Timestamp of the last staff action on the thread.
    """

    id: int
    user_name: str
    last_staff_updated: datetime
