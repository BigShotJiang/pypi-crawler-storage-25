"""Help-related Pydantic models."""
