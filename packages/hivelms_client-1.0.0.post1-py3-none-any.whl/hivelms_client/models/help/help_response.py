"""Help thread response resource models."""

from enum import auto

from pydantic_core import MISSING

from hivelms_client.models.inline_bytes import InlineBytes
from hivelms_client.models.hive_common.modeling import (
    HiveOption,
    BaseHiveResource,
    ResourceId,
    HiveModel,
)


class HelpResponseType(HiveOption):
    """Enum of possible response actions on a help thread.

    Attributes:
        RESOLVE: Staff marked the help thread as resolved.
        OPEN: Staff or student reopened a previously resolved thread.
        COMMENT: A comment was posted without changing the thread's status.
    """

    RESOLVE = auto()
    OPEN = auto()
    COMMENT = auto()


class HelpResponse(BaseHiveResource):
    """A single response entry within a help thread.

    Attributes:
        id: Unique numeric identifier assigned by the API.
        response_type: Action taken in this response (resolve, open, or comment).
        contents: Text body of the response, if any.
        file_name: Name of the attached file.
        dear_student: Whether this response is addressed directly to the student.
        segel_only: Whether this response is visible to staff only.
        hide_checker_name: Whether the checker's identity is hidden from the student.
        user: ID of the user who authored this response.
        date: Timestamp string when the response was created.
    """

    response_type: HelpResponseType
    contents: str | None
    file_name: str
    dear_student: bool
    segel_only: bool
    hide_checker_name: bool

    user: ResourceId
    date: str


class HelpResponseInput(HiveModel):
    """Input payload for creating a help thread response.

    Attributes:
        response_type: Action to record for this response.
        contents: Text body of the response.
        file_name: Name of the file to attach.
        dear_student: Address this response directly to the student.
        segel_only: Restrict visibility to staff only.
        hide_checker_name: Hide the checker's identity from the student.
        file: Raw file bytes to attach, serialised as a base64 data URI.
    """

    response_type: HelpResponseType
    contents: str | None = MISSING
    file_name: str = MISSING
    dear_student: bool = MISSING
    segel_only: bool = MISSING
    hide_checker_name: bool = MISSING

    file: InlineBytes = MISSING


class HelpResponseContents(HiveModel):
    """Wraps the text contents of a help response.

    Attributes:
        contents: Text body of the response, or ``None`` if absent.
    """

    contents: str | None = None


class HelpResponsePatch(HiveModel):
    """Partial update payload for a help thread response.

    Attributes:
        response_type: Replacement action for this response.
        contents: Replacement text body.
        file_name: Replacement file name.
        dear_student: Address this response directly to the student.
        segel_only: Restrict visibility to staff only.
        hide_checker_name: Hide the checker's identity from the student.
    """

    response_type: HelpResponseType = MISSING
    contents: str | None = MISSING
    file_name: str = MISSING
    dear_student: bool = MISSING
    segel_only: bool = MISSING
    hide_checker_name: bool = MISSING
