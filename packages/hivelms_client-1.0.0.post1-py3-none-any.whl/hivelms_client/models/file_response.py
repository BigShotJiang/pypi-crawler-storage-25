"""File download response model and HTTP helper."""

from email.header import make_header, decode_header
from typing import Self

import pyrfc6266
from pydantic import BaseModel
from requests import Response


def _get_filename_from_dispositions(raw_disposition: str) -> str:
    """Extract the filename from a raw Content-Disposition header string."""
    dispositions = pyrfc6266.parse(str(make_header(decode_header(raw_disposition))))[1]
    filenames = [
        disposition.value
        for disposition in dispositions
        if disposition.name == "filename"
    ]
    if not filenames:
        raise ValueError("Filename not found in Content-Disposition header")
    elif len(filenames) > 1:
        raise ValueError("Multiple filenames found in Content-Disposition header")
    return filenames[0]


class FileResponse(BaseModel):
    """A downloaded file with its name, MIME type, and raw content.

    Attributes:
        filename: Name of the downloaded file extracted from the Content-Disposition header.
        mimetype: MIME type of the file from the Content-Type header.
        content: Raw binary content of the downloaded file.
    """

    filename: str
    mimetype: str
    content: bytes

    @classmethod
    def from_http_response(cls, response: Response) -> Self:
        """Build a FileResponse from a raw requests HTTP response."""
        try:
            filename = _get_filename_from_dispositions(
                response.headers["Content-Disposition"]
            )
            mimetype = response.headers["Content-Type"]
            content = response.content
            return cls(filename=filename, mimetype=mimetype, content=content)
        except KeyError as e:
            raise ValueError(f"Response is missing required header: {e}") from e
