"""Lesson and lesson rule resource models."""

from typing import Annotated

from pydantic import StringConstraints
from pydantic_core import MISSING

from hivelms_client.models.hive_common.modeling import (
    BaseHiveResource,
    ResourceId,
    HiveModel,
)
from hivelms_client.models.management.class_ import Class
from hivelms_client.models.queues.queue import Queue

LessonName = Annotated[str, StringConstraints(min_length=1, max_length=100)]


class Lesson(BaseHiveResource):
    """A scheduled lesson resource returned by the API.

    Attributes:
        id: Unique numeric identifier assigned by the API.
        name: Display name of the lesson.
        module: ID of the module associated with this lesson.
        module_order: Ordering key of the associated module.
        module_name: Display name of the associated module.
        subject_symbol: Symbol identifier of the parent subject.
        subject_name: Display name of the parent subject.
        program_name: Display name of the grandparent program.
        description: Optional description of the lesson.
    """

    name: LessonName
    module: ResourceId
    module_order: str
    module_name: str
    subject_symbol: str
    subject_name: str
    program_name: str
    description: str


class LessonInput(HiveModel):
    """Input payload for creating a lesson.

    Attributes:
        name: Display name of the lesson.
        module: ID of the module to associate with the lesson.
        description: Optional description of the lesson.
    """

    name: LessonName
    module: int
    description: str = MISSING


class LessonPatch(HiveModel):
    """Partial update payload for a lesson.

    Attributes:
        name: Replacement display name.
        module: Replacement associated module ID.
        description: Replacement description.
    """

    name: LessonName = MISSING
    module: int = MISSING
    description: str = MISSING


class LessonRule(BaseHiveResource):
    """A routing rule that maps student groups to a queue within a lesson.

    Attributes:
        id: Unique numeric identifier assigned by the API.
        parent_rule: ID of the parent rule this rule falls under, or ``None``.
        student_groups: IDs of student groups this rule applies to.
        queue: ID of the queue assigned by this rule, or ``None``.
        queue_data: Full queue resource for the assigned queue, or ``None``.
        student_groups_data: Full class resources for the student groups, or ``None``.
    """

    parent_rule: ResourceId | None
    student_groups: list[ResourceId]
    queue: ResourceId | None
    queue_data: Queue | None
    student_groups_data: list[Class] | None


class LessonRuleInput(HiveModel):
    """Input payload for creating a lesson rule.

    Attributes:
        parent_rule: ID of the parent rule, or ``None`` for a top-level rule.
        student_groups: IDs of student groups this rule applies to.
        queue: ID of the queue to assign via this rule, or ``None``.
    """

    parent_rule: ResourceId | None = MISSING
    student_groups: list[ResourceId] = MISSING
    queue: ResourceId | None = MISSING


class LessonRulePatch(HiveModel):
    """Partial update payload for a lesson rule.

    Attributes:
        parent_rule: Replacement parent rule ID, or ``None`` to make it top-level.
        student_groups: Replacement list of student group IDs.
        queue: Replacement queue ID, or ``None`` to clear the assignment.
    """

    parent_rule: ResourceId | None = MISSING
    student_groups: list[ResourceId] = MISSING
    queue: ResourceId | None = MISSING
