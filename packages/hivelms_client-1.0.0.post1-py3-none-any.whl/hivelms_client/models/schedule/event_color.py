"""Event colour resource models."""

from typing import Annotated

from pydantic import StringConstraints
from pydantic_core import MISSING

from hivelms_client.models.hive_common.data_types import HiveColor
from hivelms_client.models.hive_common.modeling import BaseHiveResource, HiveModel

EventColorName = Annotated[str, StringConstraints(min_length=1, max_length=20)]


class EventColor(BaseHiveResource):
    """A named colour swatch used to categorise calendar events.

    Attributes:
        id: Unique numeric identifier for this colour swatch.
        name: Display name of the colour swatch.
        color: Hex colour value of the swatch.
    """

    id: int
    name: EventColorName
    color: HiveColor


class EventColorInput(HiveModel):
    """Input payload for creating an event colour.

    Attributes:
        name: Display name for the new colour swatch.
        color: Hex colour value for the new swatch.
    """

    name: EventColorName
    color: HiveColor


class EventColorPatch(HiveModel):
    """Partial update payload for an event colour.

    Attributes:
        name: Replacement display name, or ``None`` to clear.
        color: Replacement hex colour value, or ``None`` to clear.
    """

    name: EventColorName | None = MISSING
    color: HiveColor | None = MISSING
