"""Schedule-related Pydantic models."""
