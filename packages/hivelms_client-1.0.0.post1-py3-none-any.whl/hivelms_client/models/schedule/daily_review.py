"""Daily review report input model."""

from datetime import datetime

from pydantic import BaseModel


class DailyReviewInput(BaseModel):
    """Input payload for generating a daily review report.

    Attributes:
        date: The date for which to generate the review report.
        show_lesson_names: Whether to include lesson names in the report.
        hide_work_details: Whether to omit per-exercise work details from the report.
    """

    date: datetime
    show_lesson_names: bool
    hide_work_details: bool
