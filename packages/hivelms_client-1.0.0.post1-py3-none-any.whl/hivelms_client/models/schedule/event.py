"""Calendar event resource models."""

from datetime import datetime
from enum import StrEnum
from typing import Annotated

from pydantic import BaseModel, StringConstraints

from hivelms_client.models.hive_common.modeling import BaseHiveResource
from hivelms_client.models.hive_common.data_types import HiveColor

LocationName = Annotated[str, StringConstraints(max_length=100)]


class EventType(StrEnum):
    """Enum of calendar event categories.

    Attributes:
        SCHOOL_SOLUTION: A session where the school presents the model solution.
        LECTURE: A teacher-led lecture or instructional session.
        SELF_STUDY: An unguided period where students work independently.
    """

    SCHOOL_SOLUTION = "פתבס"
    LECTURE = "הרצאה"
    SELF_STUDY = "עע"


class EventAttendee(BaseHiveResource):
    """An attendee record linked to a calendar event.

    Attributes:
        id: Unique numeric identifier assigned by the API.
        name: Display name of the attendee.
        description: Optional extra description for the attendee.
    """

    name: str
    description: str | None = None


class Event(BaseModel):
    """A scheduled calendar event.

    Attributes:
        start: Start timestamp of the event.
        end: End timestamp of the event.
        title: Optional display title for the event.
        attendees: List of attendee records, or ``None``.
        subject_id: ID of the related subject, or ``None``.
        subject_name: Display name of the related subject, or ``None``.
        color: Display colour of the event, or ``None``.
        type: Category of the event.
        location: Name of the event location, or ``None``.
        module_id: ID of the related module, or ``None``.
        lesson_name: Name of the related lesson, or ``None``.
    """

    start: datetime
    end: datetime
    title: str | None = None
    attendees: list[EventAttendee] | None = None
    subject_id: int | None = None
    subject_name: str | None = None
    color: HiveColor | None = None
    type: EventType
    location: LocationName | None = None
    module_id: int | None = None
    lesson_name: str | None = None
