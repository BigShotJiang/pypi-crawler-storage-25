"""Standardised error response models for the Hive API."""

from enum import StrEnum, auto
from typing import Annotated, Literal

from pydantic import BaseModel, Field


class ErrorType(StrEnum):
    """Top-level category of an API error.

    Attributes:
        CLIENT_ERROR: The request was rejected due to a client mistake (4xx).
        SERVER_ERROR: The server encountered an unexpected failure (5xx).
        VALIDATION_ERROR: Request data failed schema or field-level validation.
    """

    CLIENT_ERROR = auto()
    SERVER_ERROR = auto()
    VALIDATION_ERROR = auto()


class ErrorCode(StrEnum):
    """Machine-readable error codes returned by the API.

    Attributes:
        AUTHENTICATION_FAILED: Credentials were provided but could not be verified.
        NOT_AUTHENTICATED: The request requires authentication but none was provided.
        NO_ACTIVE_ACCOUNT: The credentials matched no active user account.
        PERMISSION_DENIED: The authenticated user lacks permission for this action.
        NOT_FOUND: The requested resource does not exist.
        METHOD_NOT_ALLOWED: The HTTP method is not supported on this endpoint.
        NOT_ACCEPTABLE: The server cannot produce a response in the requested format.
        UNSUPPORTED_MEDIA_TYPE: The request body content type is not supported.
        PARSE_ERROR: The request body could not be parsed.
    """

    AUTHENTICATION_FAILED = auto()
    NOT_AUTHENTICATED = auto()
    NO_ACTIVE_ACCOUNT = auto()
    PERMISSION_DENIED = auto()
    NOT_FOUND = auto()
    METHOD_NOT_ALLOWED = auto()
    NOT_ACCEPTABLE = auto()
    UNSUPPORTED_MEDIA_TYPE = auto()
    PARSE_ERROR = auto()


class ErrorData(BaseModel):
    """A single error entry within an error response.

    Attributes:
        code: Machine-readable error code identifying the failure reason.
        detail: Human-readable explanation of the error.
        attr: Name of the request field that caused the error, if applicable.
    """

    code: ErrorCode | str
    detail: str
    attr: str | None


class ErrorResponse(BaseModel):
    """Base error response envelope returned by the Hive API.

    Attributes:
        type_: Top-level category of the error (deserialized from the ``type`` key).
        errors: List of individual error entries describing what went wrong.
    """

    type_: Annotated[ErrorType, Field(alias="type")]
    errors: list[ErrorData]


class ClientErrorResponse(ErrorResponse):
    """Error response for 4xx client errors (exactly one error entry).

    Attributes:
        type_: Always ``ErrorType.CLIENT_ERROR``; used as the discriminator.
        errors: A single-element list containing the error detail.
    """

    type_: Literal[ErrorType.CLIENT_ERROR]
    errors: Annotated[list[ErrorData], Field(min_length=1, max_length=1)]


class ServerErrorResponse(ErrorResponse):
    """Error response for 5xx server errors.

    Attributes:
        type_: Always ``ErrorType.SERVER_ERROR``; used as the discriminator.
        errors: List of individual error entries describing what went wrong.
    """

    type_: Literal[ErrorType.SERVER_ERROR]


class ValidationErrorResponse(ErrorResponse):
    """Error response for request validation failures.

    Attributes:
        type_: Always ``ErrorType.VALIDATION_ERROR``; used as the discriminator.
        errors: List of field-level validation errors.
    """

    type_: Literal[ErrorType.VALIDATION_ERROR]
