"""Annotated type aliases for common Hive field constraints."""

import re
from datetime import timedelta
from pydantic import StringConstraints, PlainSerializer, BeforeValidator, WrapSerializer
from pydantic_extra_types.color import Color
from typing_extensions import Annotated

_FILENAME_FORBIDDEN_CHARS = {"<", ">", ":", '"', "\\", "/", "?", "|", "*"}
_ORDERED_TITLE_DELIMITER = "-"
_HIVE_TITLE_REGEX = (
    f"[^{re.escape(''.join(_FILENAME_FORBIDDEN_CHARS | {_ORDERED_TITLE_DELIMITER}))}]+"
)

type OptionalString[T] = Annotated[
    T | None,
    BeforeValidator(lambda v: v if v != "" else None),
    PlainSerializer(lambda v: v or ""),
]

HiveFilenameComponent = Annotated[
    str, StringConstraints(pattern=_HIVE_TITLE_REGEX, min_length=1, max_length=100)
]

HiveColor = Annotated[
    OptionalString[Color],
    WrapSerializer(
        lambda color, serialize: (
            serialize(color.as_hex(format="long")) if color else serialize(color)
        )
    ),
]

HiveDuration = Annotated[timedelta, PlainSerializer(lambda duration: str(duration))]

Username = Annotated[str, StringConstraints(pattern=r"^[\w.@+-]+$", max_length=150)]
Password = Annotated[str, StringConstraints(min_length=1, max_length=128)]
DockerTag = Annotated[
    str, StringConstraints(max_length=20, pattern=r"([a-z]_?)+[a-z]+")
]
