"""Shared Pydantic model helpers and common schemas."""
