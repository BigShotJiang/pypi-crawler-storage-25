"""Generic paginated results wrapper."""

from pydantic import BaseModel, HttpUrl


class ResultsPage[TResource: BaseModel](BaseModel):
    """Generic paginated results page wrapping a list of resources.

    Attributes:
        count: Total number of resources matching the query across all pages.
        next: URL of the next page, or ``None`` if this is the last page.
        previous: URL of the previous page, or ``None`` if this is the first page.
        results: Resources on the current page.
    """

    count: int
    next: HttpUrl | None = None
    previous: HttpUrl | None = None
    results: list[TResource]
