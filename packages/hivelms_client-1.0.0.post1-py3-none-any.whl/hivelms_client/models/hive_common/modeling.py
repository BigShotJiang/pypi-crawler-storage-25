"""Core Pydantic base classes and type aliases used across all models."""

from enum import StrEnum, auto

from pydantic import BaseModel, ConfigDict
from typing_extensions import TypeAlias

ResourceId: TypeAlias = int


class ModelType(StrEnum):
    """Enum classifying a model as input, patch, or response.

    Attributes:
        INPUT: Model carries fields for creating a new resource.
        PATCH: Model carries fields for partially updating an existing resource.
        RESPONSE: Model represents a resource returned by the API.
    """

    INPUT = auto()
    PATCH = auto()
    RESPONSE = auto()


class HiveOption(StrEnum):
    """StrEnum base class that generates title-cased values from member names."""

    @staticmethod
    def _generate_next_value_(  # type: ignore[override]
        name: str, start: int, count: int, last_values: list[str]
    ) -> str:
        """Return a title-cased string value derived from the member name."""
        return name.replace("_", " ").title().replace("Autocheck", "AutoCheck")


class HiveModel(BaseModel):
    """Pydantic base model configured to accept both field name and alias."""

    model_config = ConfigDict(validate_by_name=True)


class BaseHiveResource(BaseModel):
    """Base class for all Hive API resources that have a numeric id.

    Attributes:
        id: Unique numeric identifier assigned by the API.
    """

    id: ResourceId
