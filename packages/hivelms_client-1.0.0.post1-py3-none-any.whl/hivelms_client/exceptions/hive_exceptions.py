import json
from typing import Self

from hivelms_client.models.error_responses import ErrorCode, ErrorData


class HttpException(Exception):
    pass


class ErrorResponseException(HttpException):
    def __init__(self, detail: str, status_code: int):
        super().__init__(detail)
        self.status_code = status_code
        self.detail = detail

    def __str__(self) -> str:
        return f"Status code {self.status_code}, {self.detail}"


class ClientErrorException(ErrorResponseException):
    _errors_by_code: dict[str, type[Self]] = {}

    def __init_subclass__(cls, error_code: ErrorCode):
        super().__init_subclass__()
        cls._errors_by_code[error_code.value] = cls  # type: ignore[assignment]

    @classmethod
    def raise_from_error_data(cls, status_code: int, error_data: ErrorData) -> None:
        exception_class = cls._errors_by_code.get(error_data.code)
        if exception_class:
            raise exception_class(status_code=status_code, detail=error_data.detail)
        else:
            raise ClientErrorException(
                detail=f'Unknown error code "{error_data.code}"; {error_data.detail}',
                status_code=status_code,
            )


class InputValidationException(ErrorResponseException):
    def __init__(self, status_code: int, detail: str, errors: list[ErrorData]):
        super().__init__(detail, status_code)
        self.errors = errors

    def __str__(self):
        return (
            f"Status code {self.status_code}, {self.detail}\n"
            f"{json.dumps([error.model_dump(mode='json') for error in self.errors])}"
        )


class SystemException(HttpException):
    """Error unrelated to client request, including connection issues and server errors"""


class HiveException(ErrorResponseException):
    """Server errors, including malformed responses"""


class ServerErrorException(HiveException, SystemException):
    """Handled server errors with structured info"""

    def __init__(self, status_code: int, detail: str, errors: list[ErrorData]):
        super().__init__(detail, status_code)
        self.detail = detail
        self.errors = errors

    def __str__(self):
        return (
            f"Status code {self.status_code}, {self.detail}\n"
            f"{json.dumps([error.model_dump(mode='json') for error in self.errors])}"
        )


class FailedAuthenticationException(
    ClientErrorException, error_code=ErrorCode.AUTHENTICATION_FAILED
):
    pass


class UnauthenticatedException(
    ClientErrorException, error_code=ErrorCode.NOT_AUTHENTICATED
):
    pass


class NoActiveAccountException(
    ClientErrorException, error_code=ErrorCode.NO_ACTIVE_ACCOUNT
):
    pass


class PermissionDeniedException(
    ClientErrorException, error_code=ErrorCode.PERMISSION_DENIED
):
    pass


class ResourceNotFoundException(ClientErrorException, error_code=ErrorCode.NOT_FOUND):
    pass


class MethodNotAllowedException(
    ClientErrorException, error_code=ErrorCode.METHOD_NOT_ALLOWED
):
    pass


class NotAcceptableException(ClientErrorException, error_code=ErrorCode.NOT_ACCEPTABLE):
    pass


class UnsupportedMediaTypeException(
    ClientErrorException, error_code=ErrorCode.UNSUPPORTED_MEDIA_TYPE
):
    pass


class ParseErrorException(ClientErrorException, error_code=ErrorCode.PARSE_ERROR):
    pass
