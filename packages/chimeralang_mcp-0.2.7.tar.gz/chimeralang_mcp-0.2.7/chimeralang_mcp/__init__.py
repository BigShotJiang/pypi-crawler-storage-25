"""ChimeraLang MCP Server."""
__version__ = "0.2.7"
