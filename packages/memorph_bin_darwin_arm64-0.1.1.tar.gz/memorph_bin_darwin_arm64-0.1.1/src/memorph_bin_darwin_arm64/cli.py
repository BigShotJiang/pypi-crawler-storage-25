""" memorph-bin-darwin-arm64 """


def main() -> None:
    print("  memorph-bin-darwin-arm64  ")
