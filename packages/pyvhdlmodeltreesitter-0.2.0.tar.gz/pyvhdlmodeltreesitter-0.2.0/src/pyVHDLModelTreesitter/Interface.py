"""Submodule defining the various interfaces that are available."""

from __future__ import annotations

__all__ = [
    "GenericConstantInterfaceItem",
    "PortSignalInterfaceItem",
]

import sys
from typing import TYPE_CHECKING, cast

if sys.version_info >= (3, 11):
    from typing import Self
else:
    from typing_extensions import Self

import pyVHDLModel

from pyVHDLModelTreesitter._error import (
    ExtraNodeError,
    MissingNodeError,
    NodeTextIsNoneError,
)
from pyVHDLModelTreesitter.Base import parse_as_mode
from pyVHDLModelTreesitter.Expression import (
    EnumerationLiteral,
    FloatingPointLiteral,
    IntegerLiteral,
    StringLiteral,
)
from pyVHDLModelTreesitter.Name import SimpleName
from pyVHDLModelTreesitter.Symbol import SimpleSubtypeSymbol
from pyVHDLModelTreesitter.treesitter import get_node_or_raise
from pyVHDLModelTreesitter.treesitter.query import InterfaceDeclaration

if TYPE_CHECKING:
    from tree_sitter import Node


def parse_simple_expression(node: Node) -> pyVHDLModel.Expression.BaseExpression:
    """
    Parse a 'simple_expression' to a model object.

    Raises
    ------
    MissingNodeError:
        If `node` doesn't have exactly one child.

    """
    if node.child_count != 1:
        raise MissingNodeError(
            node,
            InterfaceDeclaration.TEXT,
            "simple_expression",
        )
    expression_child_node = node.children[0]
    assert expression_child_node.text is not None  # noqa: S101
    # TODO: support more simple expressions
    if expression_child_node.type == "decimal_float":
        return FloatingPointLiteral(
            float(expression_child_node.text.decode()),
        )
    if expression_child_node.type == "decimal_integer":
        return IntegerLiteral(
            int(expression_child_node.text.decode()),
        )
    if expression_child_node.type == "library_constant_boolean":
        return EnumerationLiteral(
            expression_child_node.text.decode(),
        )
    if expression_child_node.type == "name":
        assert expression_child_node.child_count == 1  # noqa: S101
        name_node = expression_child_node.children[0]
        assert name_node.text is not None  # noqa: S101
        if name_node.type == "library_constant_std_logic":
            return EnumerationLiteral(
                name_node.text.decode()[1:-1],
            )
    if expression_child_node.type == "string_literal":
        return StringLiteral(
            expression_child_node.text.decode()[1:-1],
        )
    message = f"Default of type '{expression_child_node.type}' is not yet implemented"
    raise NotImplementedError(message)


class GenericConstantInterfaceItem(pyVHDLModel.Interface.GenericConstantInterfaceItem):  # noqa: D101
    @classmethod
    def from_treesitter_node(
        cls,
        node: Node,
    ) -> Self:
        """
        Create a GenericConstantInterfaceItem from a treesitter node.

        Raises
        ------
        MissingNodeError:
            If `default` is present but isn't a simple expression.
        NodeTextIsNoneError:
            If the `name`, `type`, or `default` capture has no text.
        ExtraNodeError:
            If there is more than one `default`.

        """
        captures = InterfaceDeclaration.capture(node)
        name_node = get_node_or_raise(
            node,
            captures,
            "name",
            InterfaceDeclaration.TEXT,
        )
        type_node = get_node_or_raise(
            node,
            captures,
            "type",
            InterfaceDeclaration.TEXT,
        )
        default_nodes = captures.get("default")

        if name_node.text is None:
            raise NodeTextIsNoneError(node, InterfaceDeclaration.TEXT, "name")
        name_text = name_node.text.decode()

        mode = pyVHDLModel.Base.Mode.In

        if type_node.text is None:
            raise NodeTextIsNoneError(node, InterfaceDeclaration.TEXT, "type")
        type_text = type_node.text.decode()

        default_expression: pyVHDLModel.Expression.BaseExpression | None = None
        if default_nodes is not None:
            if len(default_nodes) > 1:
                raise ExtraNodeError(node, InterfaceDeclaration.TEXT, "default")
            default_node = default_nodes[0]
            # TODO: support non simple expressions
            assert default_node.child_count == 1  # noqa: S101
            simple_expression_node = default_node.children[0]
            assert simple_expression_node.type == "simple_expression"  # noqa: S101
            if simple_expression_node is None:
                raise MissingNodeError(
                    default_node,
                    InterfaceDeclaration.TEXT,
                    "simple_expression",
                )
            default_expression = parse_simple_expression(simple_expression_node)

        return cls(
            # TODO: why is there a list of identifiers?
            identifiers=[name_text],
            mode=mode,
            # TODO: support types that aren't simple
            subtype=SimpleSubtypeSymbol(SimpleName(type_text)),
            defaultExpression=default_expression,
            documentation=None,
        )

    def __eq__(self, other: object) -> bool:  # noqa: D105
        if not isinstance(other, GenericConstantInterfaceItem):
            return False
        # Required for LSP completions
        other = cast("GenericConstantInterfaceItem", other)  # type: ignore[redundant-cast]
        return (
            self._identifiers == other._identifiers
            and self._mode == other._mode
            and self._subtype == other._subtype
            and self._defaultExpression == other._defaultExpression
        )

    def __hash__(self) -> int:  # noqa: D105
        return hash(
            (
                self._identifiers,
                self._mode,
                self._subtype,
                self._defaultExpression,
            ),
        )

    def __repr__(self) -> str:  # noqa: D105
        return (
            f"{self.__class__.__name__}("
            f"_identifiers={self._identifiers}, "
            f"_mode={self._mode}, "
            f"_subtype={self._subtype!r}, "
            f"_defaultExpression={self._defaultExpression!r}, "
            ")"
        )


class PortSignalInterfaceItem(pyVHDLModel.Interface.PortSignalInterfaceItem):  # noqa: D101
    @classmethod
    def from_treesitter_node(
        cls,
        node: Node,
    ) -> Self:
        """
        Create a PortSignalInterfaceItem from a treesitter node.

        Raises
        ------
        ExtraNodeError:
            If `default` is captured more than once.
        MissingNodeError:
            If `default` is present but isn't a simple expression.
        NodeTextIsNoneError:
            If the `name`, `type`, `mode`, or `default` capture has no text.
        ValueError:
            If `mode` is not a valid mode.

        """
        captures = InterfaceDeclaration.capture(node)
        name_node = get_node_or_raise(
            node,
            captures,
            "name",
            InterfaceDeclaration.TEXT,
        )
        mode_node = get_node_or_raise(
            node,
            captures,
            "mode",
            InterfaceDeclaration.TEXT,
        )
        type_node = get_node_or_raise(
            node,
            captures,
            "type",
            InterfaceDeclaration.TEXT,
        )
        default_nodes = captures.get("default")

        if name_node.text is None:
            raise NodeTextIsNoneError(node, InterfaceDeclaration.TEXT, "name")
        name_text = name_node.text.decode()

        if mode_node.text is None:
            raise NodeTextIsNoneError(node, InterfaceDeclaration.TEXT, "mode")
        mode_text = mode_node.text.decode()

        if type_node.text is None:
            raise NodeTextIsNoneError(node, InterfaceDeclaration.TEXT, "type")
        type_text = type_node.text.decode()

        default_expression: pyVHDLModel.Expression.BaseExpression | None = None
        if default_nodes is not None:
            if len(default_nodes) > 1:
                raise ExtraNodeError(node, InterfaceDeclaration.TEXT, "default")
            default_node = default_nodes[0]
            # TODO: support non simple expressions
            assert default_node.child_count == 1  # noqa: S101
            simple_expression_node = default_node.children[0]
            assert simple_expression_node.type == "simple_expression"  # noqa: S101
            if simple_expression_node is None:
                raise MissingNodeError(
                    default_node,
                    InterfaceDeclaration.TEXT,
                    "simple_expression",
                )
            default_expression = parse_simple_expression(simple_expression_node)

        mode = parse_as_mode(mode_text)
        if mode is None:
            message = f"'{mode_text}' is not a valid VHDL interface mode"
            raise ValueError(message)

        return cls(
            # TODO: why is there a list of identifiers?
            identifiers=[name_text],
            mode=mode,
            # TODO: support types that aren't simple
            subtype=SimpleSubtypeSymbol(SimpleName(type_text)),
            defaultExpression=default_expression,
            documentation=None,
        )

    def __eq__(self, other: object) -> bool:  # noqa: D105
        if not isinstance(other, PortSignalInterfaceItem):
            return False
        # Required for LSP completions
        other = cast("PortSignalInterfaceItem", other)  # type: ignore[redundant-cast]
        return (
            self._identifiers == other._identifiers
            and self._mode == other._mode
            and self._subtype == other._subtype
            and self._defaultExpression == other._defaultExpression
        )

    def __hash__(self) -> int:  # noqa: D105
        return hash(
            (
                self._identifiers,
                self._mode,
                self._subtype,
                self._defaultExpression,
            ),
        )

    def __repr__(self) -> str:  # noqa: D105
        return (
            f"{self.__class__.__name__}("
            f"_identifiers={self._identifiers}, "
            f"_mode={self._mode}, "
            f"_subtype={self._subtype!r}, "
            f"_defaultExpression={self._defaultExpression!r}, "
            ")"
        )
