"""Submodule mirroring modified aspects of pyVHDLModel.DesignUnit."""

from __future__ import annotations

__all__ = [
    "Entity",
    "LibraryClause",
    "UseClause",
]

import sys
from functools import cmp_to_key
from typing import TYPE_CHECKING, cast

if sys.version_info >= (3, 11):
    from typing import Self
else:
    from typing_extensions import Self

import pyVHDLModel
from pyVHDLModel.DesignUnit import LibraryClause as BaseLibraryClause
from pyVHDLModel.DesignUnit import UseClause as BaseUseClause

from pyVHDLModelTreesitter._error import ExtraNodeError, NodeTextIsNoneError
from pyVHDLModelTreesitter.Interface import (
    GenericConstantInterfaceItem,
    PortSignalInterfaceItem,
)
from pyVHDLModelTreesitter.Name import SelectedName, SimpleName
from pyVHDLModelTreesitter.Symbol import LibraryReferenceSymbol, PackageReferenceSymbol
from pyVHDLModelTreesitter.treesitter import get_node_or_raise, get_nodes_or_raise
from pyVHDLModelTreesitter.treesitter.query import (
    EntityDeclaration,
    InterfaceDeclarations,
    LibraryClauses,
    LibraryNamespaces,
    SelectedNames,
    UseClauses,
)

if TYPE_CHECKING:
    from collections.abc import Iterable

    import tree_sitter


class LibraryClause(BaseLibraryClause):  # noqa: D101
    @classmethod
    def from_treesitter_node(
        cls,
        node: tree_sitter.Node,
    ) -> list[Self]:
        """
        Create one or more LibraryClauses from a treesitter node.

        Raises
        ------
        NodeTextIsNoneError:
            If the `library_namespace` treesitter node contains no text.

        """
        captures = LibraryClauses.capture(node)
        library_clause_nodes = get_nodes_or_raise(
            node,
            captures,
            "library-clause",
            LibraryClauses.TEXT,
        )
        ret = []
        for library_clause_node in library_clause_nodes:
            captures = LibraryNamespaces.capture(library_clause_node)
            library_namespace_nodes = get_nodes_or_raise(
                node,
                captures,
                "library",
                LibraryNamespaces.TEXT,
            )
            symbols = []
            for library_namespace_node in library_namespace_nodes:
                if library_namespace_node.text is None:
                    raise NodeTextIsNoneError(node, LibraryNamespaces.TEXT, "library")
                library = library_namespace_node.text.decode()
                symbols.append(LibraryReferenceSymbol(SimpleName(library)))
            ret.append(cls(symbols))
        return ret

    def __eq__(self, other: object) -> bool:  # noqa: D105
        if not isinstance(other, LibraryClause):
            return False
        # Required for LSP completions
        other = cast("LibraryClause", other)  # type: ignore[redundant-cast]
        return self._symbols == other._symbols

    def __hash__(self) -> int:  # noqa: D105
        return hash(
            (self._symbols,),
        )

    def __repr__(self) -> str:  # noqa: D105
        return f"{self.__class__.__name__}(_symbols={self._symbols!r}, )"


class UseClause(BaseUseClause):  # noqa: D101
    @classmethod
    def from_treesitter_node(
        cls,
        node: tree_sitter.Node,
    ) -> list[Self]:
        """
        Create one or more UseClauses from a treesitter node.

        Raises
        ------
        NodeTextIsNoneError:
            If the `library_namespace` treesitter node contains no text.

        """
        captures = UseClauses.capture(node)
        use_clause_nodes = get_nodes_or_raise(
            node,
            captures,
            "use-clause",
            UseClauses.TEXT,
        )
        ret = []
        for use_clause_node in use_clause_nodes:
            captures = SelectedNames.capture(use_clause_node)
            selected_name_nodes = get_nodes_or_raise(
                node,
                captures,
                "selected-name",
                SelectedNames.TEXT,
            )
            symbols = []
            for selected_name_node in selected_name_nodes:
                if selected_name_node.text is None:
                    raise NodeTextIsNoneError(node, SelectedNames.TEXT, "selected-name")
                selected_name = selected_name_node.text.decode()
                selected_name_parts = selected_name.split(".")
                selected_name_obj: SimpleName | SelectedName = SimpleName(
                    selected_name_parts[0],
                )
                for part in selected_name_parts[1:]:
                    selected_name_obj = SelectedName(part, selected_name_obj)
                symbols.append(PackageReferenceSymbol(selected_name_obj))
            ret.append(cls(symbols))
        return ret

    def __eq__(self, other: object) -> bool:  # noqa: D105
        if not isinstance(other, UseClause):
            return False
        # Required for LSP completions
        other = cast("UseClause", other)  # type: ignore[redundant-cast]
        return self._symbols == other._symbols

    def __hash__(self) -> int:  # noqa: D105
        return hash(
            (self._symbols,),
        )

    def __repr__(self) -> str:  # noqa: D105
        return f"{self.__class__.__name__}(_symbols={self._symbols!r}, )"


class Entity(pyVHDLModel.Entity):  # noqa: D101
    @classmethod
    def from_treesitter_node(
        cls,
        node: tree_sitter.Node,
        *,
        contextItems: Iterable[LibraryClause | UseClause] = [],  # noqa: N803
    ) -> Self:
        """
        Create an Entity from a treesitter node.

        Raises
        ------
        ExtraNodeError:
            If there is more than one `generics` or `ports` capture.
        NodeTextIsNoneError:
            If the `name` capture has no text.

        """
        captures = EntityDeclaration.capture(node)
        name_node = get_node_or_raise(
            node,
            captures,
            "name",
            EntityDeclaration.TEXT,
        )
        if name_node.text is None:
            raise NodeTextIsNoneError(node, EntityDeclaration.TEXT, "name")
        name_text = name_node.text.decode()
        generics_nodes = captures.get("generics", [])
        if len(generics_nodes) > 1:
            raise ExtraNodeError(node, EntityDeclaration.TEXT, "generics")
        ports_nodes = captures.get("ports", [])
        if len(ports_nodes) > 1:
            raise ExtraNodeError(node, EntityDeclaration.TEXT, "generics")
        generic_items = None
        if len(generics_nodes) == 1:
            generics_node = generics_nodes[0]
            captures = InterfaceDeclarations.capture(generics_node)
            generic_items_with_nodes = [
                (
                    GenericConstantInterfaceItem.from_treesitter_node(interface_node),
                    interface_node,
                )
                for interface_node in captures.get("interface", [])
            ]
            generic_items = [
                obj
                for obj, _ in sorted(
                    generic_items_with_nodes,
                    key=cmp_to_key(lambda l, r: l[1].start_byte - r[1].start_byte),  # type: ignore[index]  # noqa: E741
                )
            ]
        port_items = None
        if len(ports_nodes) == 1:
            ports_node = ports_nodes[0]
            captures = InterfaceDeclarations.capture(ports_node)
            port_items_with_nodes = [
                (
                    PortSignalInterfaceItem.from_treesitter_node(interface_node),
                    interface_node,
                )
                for interface_node in captures.get("interface", [])
            ]
            port_items = [
                obj
                for obj, _ in sorted(
                    port_items_with_nodes,
                    key=cmp_to_key(lambda l, r: l[1].start_byte - r[1].start_byte),  # type: ignore[index]  # noqa: E741
                )
            ]
        return cls(
            identifier=name_text,
            contextItems=contextItems,
            genericItems=generic_items,
            portItems=port_items,
            declaredItems=None,  # TODO: implement
            statements=None,  # TODO: implement
            documentation=None,  # TODO: implement
            allowBlackbox=None,  # TODO: implement
        )

    def __eq__(self, other: object) -> bool:  # noqa: D105
        if not isinstance(other, Entity):
            return False
        # Required for LSP completions
        other = cast("Entity", other)  # type: ignore[redundant-cast]
        return (
            self._identifier == other._identifier
            and self._contextItems == other._contextItems
            and self._genericItems == other._genericItems
            and self._portItems == other._portItems
            and self._declaredItems == other._declaredItems
            and self._statements == other._statements
            and self._documentation == other._documentation
            and self._allowBlackbox == other._allowBlackbox
        )

    def __hash__(self) -> int:  # noqa: D105
        return hash(
            (
                self._identifier,
                self._contextItems,
                self._genericItems,
                self._portItems,
                self._declaredItems,
                self._statements,
                self._documentation,
                self._allowBlackbox,
            ),
        )

    def __repr__(self) -> str:  # noqa: D105
        return (
            f"{self.__class__.__name__}("
            f"_identifier={self._identifier!r}, "
            f"_contextItems={self._contextItems!r}, "
            f"_genericItems={self._genericItems!r}, "
            f"_portItems={self._portItems!r}, "
            f"_declaredItems={self._declaredItems}, "
            f"_statements={self._statements}, "
            f"_documentation={self._documentation}, "
            f"_allowBlackbox={self._allowBlackbox}, "
            ")"
        )
