"""Submodule defining errors."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tree_sitter import Node


class BaseQueryCaptureError(RuntimeError):
    """Error raised when a capture fails for some reason."""

    def __init__(self, node: Node, query: str, name: str, message: str) -> None:
        """Construct."""
        assert node.text is not None  # noqa: S101
        super().__init__(f"Capture '@{name}': {message}: {node.text.decode()}: {node}")
        self._node = node
        self._query = query
        self._name = name


class MissingNodeError(BaseQueryCaptureError):
    """Error raised when an expected node is not found."""

    def __init__(self, node: Node, query: str, name: str) -> None:
        """Construct."""
        super().__init__(node, query, name, "Not found in node")


class ExtraNodeError(BaseQueryCaptureError):
    """Error raised when an expected node is found too many times."""

    def __init__(self, node: Node, query: str, name: str) -> None:
        """Construct."""
        super().__init__(node, query, name, "Found too many times in node")


class NodeTextIsNoneError(BaseQueryCaptureError):
    """Error raised when a node that is expected to have a `text` field doesn't."""

    def __init__(self, node: Node, query: str, name: str) -> None:
        """Construct."""
        super().__init__(node, query, name, "`text` attribute not found for node")
