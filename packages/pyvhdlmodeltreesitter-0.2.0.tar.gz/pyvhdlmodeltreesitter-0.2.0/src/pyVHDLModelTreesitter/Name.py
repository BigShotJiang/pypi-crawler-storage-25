"""Submodule mirroring modified aspects of pyVHDLModel.Name."""

from __future__ import annotations

__all__ = [
    "SelectedName",
    "SimpleName",
]

from typing import cast

from pyVHDLModel.Name import (
    SelectedName as BaseSelectedName,
)
from pyVHDLModel.Name import (
    SimpleName as BaseSimpleName,
)


class SimpleName(BaseSimpleName):  # noqa: D101
    def __eq__(self, other: object) -> bool:  # noqa: D105
        if not isinstance(other, SimpleName):
            return False
        # Required for LSP completions
        other = cast("SimpleName", other)  # type: ignore[redundant-cast]
        return self._identifier == other._identifier

    def __hash__(self) -> int:  # noqa: D105
        return hash(
            (self._identifier,),
        )


class SelectedName(BaseSelectedName):  # noqa: D101
    def __eq__(self, other: object) -> bool:  # noqa: D105
        if not isinstance(other, SelectedName):
            return False
        # Required for LSP completions
        other = cast("SelectedName", other)  # type: ignore[redundant-cast]
        return self._identifier == other._identifier and self._prefix == other._prefix

    def __hash__(self) -> int:  # noqa: D105
        return hash(
            (
                self._identifier,
                self._prefix,
            ),
        )
