"""Submodule mirroring modified aspects of pyVHDLModel.Expression."""

from __future__ import annotations

__all__ = [
    "EnumerationLiteral",
    "FloatingPointLiteral",
    "IntegerLiteral",
    "StringLiteral",
]

from typing import cast

import pyVHDLModel


class EnumerationLiteral(pyVHDLModel.Expression.EnumerationLiteral):  # noqa: D101
    def __eq__(self, other: object) -> bool:  # noqa: D105
        if not isinstance(other, EnumerationLiteral):
            return False
        # Required for LSP completions
        other = cast("EnumerationLiteral", other)  # type: ignore[redundant-cast]
        return self._value.lower() == other._value.lower()

    def __hash__(self) -> int:  # noqa: D105
        return hash(
            (self._value,),
        )

    def __repr__(self) -> str:  # noqa: D105
        return f"{self.__class__.__name__}(_value={self._value!r}, )"


class FloatingPointLiteral(pyVHDLModel.Expression.FloatingPointLiteral):  # noqa: D101
    def __eq__(self, other: object) -> bool:  # noqa: D105
        if not isinstance(other, FloatingPointLiteral):
            return False
        # Required for LSP completions
        other = cast("FloatingPointLiteral", other)  # type: ignore[redundant-cast]
        return self._value == other._value

    def __hash__(self) -> int:  # noqa: D105
        return hash(
            (self._value,),
        )

    def __repr__(self) -> str:  # noqa: D105
        return f"{self.__class__.__name__}(_value={self._value!r}, )"


class IntegerLiteral(pyVHDLModel.Expression.IntegerLiteral):  # noqa: D101
    def __eq__(self, other: object) -> bool:  # noqa: D105
        if not isinstance(other, IntegerLiteral):
            return False
        # Required for LSP completions
        other = cast("IntegerLiteral", other)  # type: ignore[redundant-cast]
        return self._value == other._value

    def __hash__(self) -> int:  # noqa: D105
        return hash(
            (self._value,),
        )

    def __repr__(self) -> str:  # noqa: D105
        return f"{self.__class__.__name__}(_value={self._value!r}, )"


class StringLiteral(pyVHDLModel.Expression.StringLiteral):  # noqa: D101
    def __eq__(self, other: object) -> bool:  # noqa: D105
        if not isinstance(other, StringLiteral):
            return False
        # Required for LSP completions
        other = cast("StringLiteral", other)  # type: ignore[redundant-cast]
        return self._value == other._value

    def __hash__(self) -> int:  # noqa: D105
        return hash(
            (self._value,),
        )

    def __repr__(self) -> str:  # noqa: D105
        return f"{self.__class__.__name__}(_value={self._value!r}, )"
