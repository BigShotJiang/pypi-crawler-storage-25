"""Classes that are at the root of the pyVHDLModel library."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import cast

if sys.version_info >= (3, 11):
    from typing import Self
else:
    from typing_extensions import Self

from pyVHDLModel import (
    Design as BaseDesign,
)
from pyVHDLModel import (
    Document as BaseDocument,
)
from pyVHDLModel import (
    Library as BaseLibrary,
)

from pyVHDLModelTreesitter._error import MissingNodeError
from pyVHDLModelTreesitter.DesignUnit import Entity, LibraryClause, UseClause
from pyVHDLModelTreesitter.treesitter.query import PARSER, DesignUnits


class Library(BaseLibrary):
    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Library):
            return False
        # Required for LSP completions
        other = cast("Library", other)  # type: ignore[redundant-cast]
        return (
            self._allowBlackbox == other._allowBlackbox
            and self._contexts == other._contexts
            and self._configurations == other._configurations
            and self._entities == other._entities
            and self._architectures == other._architectures
            and self._packages == other._packages
            and self._packageBodies == other._packageBodies
        )

    def __hash__(self) -> int:
        return hash(
            (
                self._allowBlackbox,
                self._contexts,
                self._configurations,
                self._entities,
                self._architectures,
                self._packages,
                self._packageBodies,
            ),
        )

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"_allowBlackbox={self._allowBlackbox}, "
            f"_contexts={self._contexts}, "
            f"_configurations={self._configurations}, "
            f"_entities={list(self._entities.values())!r}, "
            f"_architectures={self._architectures}, "
            f"_packages={self._packages}, "
            f"_packageBodies={self._packageBodies}, "
            ")"
        )


class Document(BaseDocument):
    @classmethod
    def from_file(cls, path: str | Path) -> Self:  # noqa: C901  # TODO: refactor
        """
        Create a Document, and all ModelEntities it contains.

        Raises
        ------
        MissingNodeError:
            - There are no `design_unit` nodes.
            - Any `design_unit` node has no children.
        NotImplementedError:
            - If a node is encountered that isn't implemented.

        """
        if isinstance(path, str):
            path = Path(path)
        document = cls(path)

        tree = PARSER.parse(path.read_bytes())
        node = tree.root_node
        captures = DesignUnits.capture(node)
        design_unit_captures = captures.get("design-unit")
        if design_unit_captures is None:
            raise MissingNodeError(node, DesignUnits.TEXT, "design-unit")
        for design_unit_capture in design_unit_captures:
            if len(design_unit_capture.children) == 0:
                raise MissingNodeError(node, DesignUnits.TEXT, "design-unit")
            design_unit_child = design_unit_capture.children[-1]
            context_children = design_unit_capture.children[:-1]
            context_items: list[LibraryClause | UseClause] = []
            for context_child in context_children:
                if context_child is None:
                    raise MissingNodeError(node, DesignUnits.TEXT, "design-unit")
                if context_child.type == "library_clause":
                    context_items.extend(
                        LibraryClause.from_treesitter_node(context_child),
                    )
                elif context_child.type == "use_clause":
                    context_items.extend(
                        UseClause.from_treesitter_node(context_child),
                    )
                else:
                    message = f"Node of type '{context_child.type}' is not supported"
                    raise NotImplementedError(message)
            if design_unit_child is None:
                raise MissingNodeError(node, DesignUnits.TEXT, "design-unit")
            if design_unit_child.type == "entity_declaration":
                entity = Entity.from_treesitter_node(node, contextItems=context_items)
                document._AddEntity(entity)
            else:
                message = f"Node of type '{design_unit_child.type}' is not supported"
                raise NotImplementedError(message)
        return document

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Document):
            return False
        # Required for LSP completions
        other = cast("Document", other)  # type: ignore[redundant-cast]
        return (
            self._path == other._path
            and self._contexts == other._contexts
            and self._configurations == other._configurations
            and self._entities == other._entities
            and self._architectures == other._architectures
            and self._packages == other._packages
            and self._packageBodies == other._packageBodies
            and self._verificationUnits == other._verificationUnits
            and self._verificationProperties == other._verificationProperties
            and self._verificationModes == other._verificationModes
        )

    def __hash__(self) -> int:
        return hash(
            (
                self._path,
                self._contexts,
                self._configurations,
                self._entities,
                self._architectures,
                self._packages,
                self._packageBodies,
                self._verificationUnits,
                self._verificationProperties,
                self._verificationModes,
            ),
        )

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"_path={self._path}, "
            f"_contexts={self._contexts}, "
            f"_configurations={self._configurations}, "
            f"_entities={list(self._entities.values())!r}, "
            f"_architectures={self._architectures}, "
            f"_packages={self._packages}, "
            f"_packageBodies={self._packageBodies}, "
            f"_verificationUnits={self._verificationUnits}, "
            f"_verificationProperties={self._verificationProperties}, "
            f"_verificationModes={self._verificationModes}, "
            ")"
        )


class Design(BaseDesign):
    def GetLibrary(  # noqa: N802
        self,
        name: str,
    ) -> Library:
        library = self.Libraries.get(name)
        if library is not None:
            return cast("Library", library)
        library = Library(
            name,
            allowBlackbox=self._allowBlackbox,
        )
        self.AddLibrary(library)
        return library

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Design):
            return False
        # Required for LSP completions
        other = cast("Design", other)  # type: ignore[redundant-cast]
        return (
            self._name == other._name
            and self._allowBlackbox == other._allowBlackbox
            and self._libraries == other._libraries
            and self._documents == other._documents
        )

    def __hash__(self) -> int:
        return hash(
            (
                self._name,
                self._allowBlackbox,
                self._libraries,
                self._documents,
            ),
        )

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"_name={self._name}, "
            f"_allowBlackbox={self._allowBlackbox}, "
            f"_libraries={list(self._libraries.values())!r}, "
            f"_documents={self._documents!r}, "
            ")"
        )
