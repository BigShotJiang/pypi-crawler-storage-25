"""Submodule mirroring modified aspects of pyVHDLModel.Base."""

from __future__ import annotations

__all__ = [
    "parse_as_mode",
]

import pyVHDLModel


def parse_as_mode(string: str) -> pyVHDLModel.Base.Mode | None:
    """
    Try and convert incorrect inputs.

    This will accept any mix of the following:
        - Incorrect capitalisation
            - "IN"
            - "iN"
            - "in"
        - Split words with whitespace
            - "in out"
    """
    # TODO: make a PR on pyVHDLModel to add this
    string = "".join(string.split()).lower().capitalize()
    if string == "Inout":
        string = "InOut"
    try:
        return pyVHDLModel.Base.Mode[string]
    except IndexError:
        return None
