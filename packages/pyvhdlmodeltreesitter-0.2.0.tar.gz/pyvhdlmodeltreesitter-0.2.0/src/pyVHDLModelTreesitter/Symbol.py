"""Submodule mirroring modified aspects of pyVHDLModel.Symbol."""

from __future__ import annotations

__all__ = [
    "LibraryReferenceSymbol",
    "PackageReferenceSymbol",
    "SimpleSubtypeSymbol",
]

from typing import cast

import pyVHDLModel


class LibraryReferenceSymbol(pyVHDLModel.Symbol.LibraryReferenceSymbol):  # noqa: D101
    def __eq__(self, other: object) -> bool:  # noqa: D105
        if not isinstance(other, LibraryReferenceSymbol):
            return False
        # Required for LSP completions
        other = cast("LibraryReferenceSymbol", other)  # type: ignore[redundant-cast]
        return self._name == other._name

    def __hash__(self) -> int:  # noqa: D105
        return hash(
            (self._name,),
        )

    def __repr__(self) -> str:  # noqa: D105
        return f"{self.__class__.__name__}(_name={self._name}, )"


class PackageReferenceSymbol(pyVHDLModel.Symbol.PackageReferenceSymbol):  # noqa: D101
    def __eq__(self, other: object) -> bool:  # noqa: D105
        if not isinstance(other, PackageReferenceSymbol):
            return False
        # Required for LSP completions
        other = cast("PackageReferenceSymbol", other)  # type: ignore[redundant-cast]
        return self._name == other._name

    def __hash__(self) -> int:  # noqa: D105
        return hash(
            (self._name,),
        )

    def __repr__(self) -> str:  # noqa: D105
        return f"{self.__class__.__name__}(_name={self._name}, )"


class SimpleSubtypeSymbol(pyVHDLModel.Symbol.SimpleSubtypeSymbol):  # noqa: D101
    def __eq__(self, other: object) -> bool:  # noqa: D105
        if not isinstance(other, SimpleSubtypeSymbol):
            return False
        # Required for LSP completions
        other = cast("SimpleSubtypeSymbol", other)  # type: ignore[redundant-cast]
        return self._name == other._name

    def __hash__(self) -> int:  # noqa: D105
        return hash(
            (self._name,),
        )

    def __repr__(self) -> str:  # noqa: D105
        return f"{self.__class__.__name__}(_name={self._name}, )"
