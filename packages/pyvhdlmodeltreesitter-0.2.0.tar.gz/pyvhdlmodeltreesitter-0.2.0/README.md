# pyVHDLModelTreesitter

`pyVHDLModelTreesitter` is an implementation of the `pyVHDLModel` API using
`tree-sitter-vhdl`.
