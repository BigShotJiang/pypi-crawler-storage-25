import sys
    
#CONVERTS SECONDS, TO FULL TIME FORMAT
def convert_seconds(SECONDS):
    SECONDS = str(SECONDS).strip()
    if SECONDS:
        if SECONDS.isnumeric():
            SECONDS = int(SECONDS)
            YEARS = f'{SECONDS // 31536000}y:' if (SECONDS // 31536000) > 0 else ''
            REMAINDER_SECONDS = SECONDS % 31536000
            MONTHS = f'{REMAINDER_SECONDS // 2628000}M:' if (REMAINDER_SECONDS // 2628000) > 0 else ''
            REMAINDER_SECONDS %= 2628000
            WEEKS = f'{REMAINDER_SECONDS // 604800}w:' if (REMAINDER_SECONDS // 604800) > 0 else ''
            REMAINDER_SECONDS %= 604800
            DAYS = f'{REMAINDER_SECONDS // 86400}d:' if (REMAINDER_SECONDS // 86400) > 0 else ''
            REMAINDER_SECONDS %= 86400
            HOURS = f'{REMAINDER_SECONDS // 3600}h:' if (REMAINDER_SECONDS // 3600) > 0 else ''
            REMAINDER_SECONDS %= 3600
            MINUTES = f'{REMAINDER_SECONDS // 60}m:' if (REMAINDER_SECONDS // 60) > 0 else ''
            REMAINDER_SECONDS %= 60
            SECONDS = f'{REMAINDER_SECONDS % 60}s'
            CONVERTED_SECONDS = f'{YEARS}{MONTHS}{WEEKS}{DAYS}{HOURS}{MINUTES}{SECONDS}'
            return CONVERTED_SECONDS
        else:
            raise TypeError('"convert_seconds()": The "SECONDS" variable, must be an integer')
    else:
        raise EOFError('"convert_seconds()": The "SECONDS" variable, cannot be empty')
    
#DISPLAY A PROGRESS BAR, FOR THE "recursive_copy_with_progress()" FUNCTION   
def recursive_copy_progress_bar(COPIED_BYTES, TOTAL_BYTES, ETA_SECONDS, PADDING_WIDTH = 20):
    COPIED_BYTES, TOTAL_BYTES, ETA_SECONDS = str(COPIED_BYTES).strip(), str(TOTAL_BYTES).strip(), str(ETA_SECONDS).strip()
    if all([COPIED_BYTES, TOTAL_BYTES, ETA_SECONDS]):      
        if all([COPIED_BYTES.isnumeric(), TOTAL_BYTES.isnumeric(), ETA_SECONDS.isnumeric()]):
            COPIED_BYTES, TOTAL_BYTES, ETA_SECONDS = int(COPIED_BYTES), int(TOTAL_BYTES), int(ETA_SECONDS)
            PERCENT = (COPIED_BYTES / TOTAL_BYTES) * 100
            BARS_FILLED = (30 * COPIED_BYTES) // TOTAL_BYTES
            PROGRESS_BAR = '=' * BARS_FILLED + '-' * (30 - BARS_FILLED)
            ETA = convert_seconds(ETA_SECONDS)
            sys.stdout.write(f'\rProgress: [{PROGRESS_BAR}]({round(PERCENT)}%) ETA: {ETA.ljust((PADDING_WIDTH))}')
            sys.stdout.flush()
        else:
            raise TypeError('"recursive_copy_progress_bar()": One or more non-integer variables, were supplied')   
    else:
        raise EOFError('"recursive_copy_progress_bar()": One or more empty variables, were supplied')
    if PERCENT == 100.0:
        print('\nFinished!')