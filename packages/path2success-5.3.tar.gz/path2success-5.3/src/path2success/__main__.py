import sys, signal
from .main import recursive_copy_with_progress

def exit(signum, frame):
    sys.exit(1)

#CLI CODE
def recursive_copy_with_progress_CLI():
    try:
        SOURCE_PATH = sys.argv[2]
        DESTINATION_PATH = sys.argv[3]
        recursive_copy_with_progress(SOURCE_PATH, DESTINATION_PATH)
    except Exception as ERROR:
        print(ERROR)
        input('Press Enter: ')

if __name__ == '__main__':
    signal.signal(signal.SIGINT, exit)
    COMMAND = sys.argv[1]
    if len(sys.argv) == 4 and COMMAND == 'recursive_copy_with_progress':
        print('Press "ctrl" + "c", to quit')
        recursive_copy_with_progress_CLI()
    else:
        print('CLI usage: python -m path2success recursive_copy_with_progress [SOURCE_PATH] [DESTINATION_PATH]')
        print('Note: Ensure any spaced paths, are quoted')
        input('Press Enter: ')