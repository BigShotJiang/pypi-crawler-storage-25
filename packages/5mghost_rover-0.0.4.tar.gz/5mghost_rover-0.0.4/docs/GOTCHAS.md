# reddit-mcp GOTCHAS

- Reddit JSON API requests can return 403 with non-browser TLS fingerprints; keep using `curl_cffi` with browser impersonation.
- `reddit_session` expiry parsing depends on JWT base64url padding; missing padding makes expiry checks silently fail.
- Reddit quota is 100 requests / 10 minutes; batch calls must stay bounded (`max 25`) to avoid hitting 429 too quickly.
- `setup-cookies` and auto-refresh only read cookies from copied local browser profiles (Chrome/Edge/Chromium); never attach to a live browser process, to avoid accidental account/session side effects.
- Cookie freshness fallback uses file age when JWT expiry cannot be decoded, so `meta.json` timestamps must be persisted reliably.
