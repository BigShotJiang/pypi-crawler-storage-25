"""reddit-mcp — Reddit MCP server for batch Reddit data access."""

__version__ = "0.0.4"
