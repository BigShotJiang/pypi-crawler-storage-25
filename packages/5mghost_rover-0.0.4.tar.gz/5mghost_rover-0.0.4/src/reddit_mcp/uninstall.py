"""Uninstall helpers for reddit-mcp client registrations and local config."""

from __future__ import annotations

import shutil

from fivemghost_shared_client.registration import unregister_all

from .config import CONFIG_DIR


def run_uninstall() -> None:
    """Remove reddit-mcp registrations and local config."""
    print("\n🧹 reddit-mcp uninstall\n")
    unregister_all(server_name="reddit-mcp")

    if CONFIG_DIR.exists():
        # Why: ~/.reddit-mcp is owned by this package and only stores its launcher/auth/cookies/cache.
        shutil.rmtree(CONFIG_DIR)
        print(f"  ✅ Removed local reddit-mcp config: {CONFIG_DIR}")
    else:
        print(f"  ℹ️  Local reddit-mcp config already absent: {CONFIG_DIR}")

    print("  ℹ️  If you installed globally, remove the package with: pip uninstall 5mghost-rover")
    print("")
