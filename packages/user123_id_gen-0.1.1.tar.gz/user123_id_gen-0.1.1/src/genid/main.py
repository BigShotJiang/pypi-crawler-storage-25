import random

last = set()

def Random_id(min, max): return random.randint(min, max)

RanId = Random_id

def Gen_ID(min_id, max_id, verbose=False):
    global last

    options = set(range(min_id, max_id + 1))

    if last >= options:
        return "No_More_Options_Left"
    
    if max_id >= 2100000:
        return "max_id_too_big"
    
    while True:
        if verbose:
            print("Generating ID")

        n = random.randint(min_id, max_id)

        if n not in last:
            last.add(n)

            if verbose:
                print("Successfully generated ID that does not match any other")

            return n

        if verbose:
            print("Failed, matched old ID")
            print("Retrying")

def clear():
    global last
    last = set()

gID = Gen_ID
Genrate_ID = Gen_ID

def cmd():
    print("Random_id, RanId: Randoms id, WARNING: Can genrate same ids as before, example: Random_id(1, 10)")
    print("Gen_ID, gID, Genrate_ID: Genrates an ID that does not match your preves IDs for example: Gen_ID(1, 10) or Gen_ID(1, 10, True) # shows detals")
    print("clear: clears the histry of Gen_ID")
    print("cmd: this help prints command")

__all__ = ["Random_id", "RanId", "gID", "Genrate_ID", "Gen_ID", "cmd", "clear"]