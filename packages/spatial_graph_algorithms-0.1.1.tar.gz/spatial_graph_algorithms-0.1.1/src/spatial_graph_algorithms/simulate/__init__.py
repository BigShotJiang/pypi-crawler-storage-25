"""Simulation API for generating SpatialGraph instances.

The main entry point is :func:`generate`, which creates a synthetic spatial
graph from a point cloud using one of nine connectivity modes, with optional
false-edge injection for noise simulation.
"""

from __future__ import annotations

from typing import Optional

import numpy as np
import pandas as pd
import scipy.sparse

from spatial_graph_algorithms.network import SpatialGraph

from .false_edges import inject_false_edges
from .generation import generate_points
from .graphs import build_edges

SUPPORTED_MODES = {
    "knn",
    "epsilon",
    "epsilon-ball",
    "delaunay",
    "delaunay_corrected",
    "distance_decay",
    "knn_bipartite",
    "epsilon_bipartite",
    "lattice",
}


def _validate_inputs(
    *,
    n: int,
    dim: int,
    shape: str,
    mode: str,
    k: int,
    epsilon: float,
    false_edges_number: Optional[int],
    false_edges_fraction: Optional[float],
) -> None:
    if n <= 1:
        raise ValueError("n must be > 1")
    if dim not in {2, 3}:
        raise ValueError("dim must be 2 or 3")
    if mode not in SUPPORTED_MODES:
        raise ValueError(f"Unsupported mode '{mode}'")
    if k <= 0:
        raise ValueError("k must be > 0")
    if epsilon <= 0:
        raise ValueError("epsilon must be > 0")
    if false_edges_number is not None and false_edges_fraction is not None:
        raise ValueError("Provide only one of false_edges_number or false_edges_fraction")
    if false_edges_fraction is not None and false_edges_fraction < 0:
        raise ValueError("false_edges_fraction must be >= 0")
    if false_edges_number is not None and false_edges_number < 0:
        raise ValueError("false_edges_number must be >= 0")


def _edges_to_adjacency(n: int, edges: set[tuple[int, int]]) -> scipy.sparse.csr_matrix:
    if not edges:
        return scipy.sparse.csr_matrix((n, n), dtype=float)
    row = np.array([e[0] for e in edges] + [e[1] for e in edges], dtype=int)
    col = np.array([e[1] for e in edges] + [e[0] for e in edges], dtype=int)
    data = np.ones(len(row), dtype=float)
    return scipy.sparse.csr_matrix((data, (row, col)), shape=(n, n))


def generate(
    *,
    n: int = 1000,
    dim: int = 2,
    shape: str = "circle",
    mode: str = "delaunay_corrected",
    seed: Optional[int] = None,
    scale: float = 1.0,
    image_path: Optional[str] = None,
    k: int = 8,
    epsilon: float = 0.15,
    bipartite_ratio: int = 2,
    quantile_scale: float = 0.05,
    power_law_exp: float = 4.0,
    false_edges_number: Optional[int] = None,
    false_edges_fraction: Optional[float] = None,
) -> SpatialGraph:
    """Generate a simulated spatial graph and return it as a SpatialGraph.

    Points are sampled uniformly inside the chosen *shape*, then connected
    according to *mode*.  False (shortcut) edges can be injected to simulate
    the sequencing noise present in real spatial omics data.

    Parameters
    ----------
    n : int
        Number of nodes to generate.  Must be > 1.
    dim : int
        Spatial dimension.  Must be 2 or 3.
    shape : str
        Point-cloud geometry.  One of: ``"circle"``, ``"square"``,
        ``"sphere"``, ``"cube"``, ``"image"`` / ``"image_2d"``.
    mode : str
        Edge-construction rule.  Supported modes:

        - ``"delaunay_corrected"`` — Delaunay triangulation (recommended default)
        - ``"delaunay"`` — standard Delaunay
        - ``"knn"`` — *k* nearest neighbours
        - ``"epsilon"`` / ``"epsilon-ball"`` — epsilon-ball connectivity
        - ``"lattice"`` — regular grid
        - ``"distance_decay"`` — Gaussian-decay connection probability
        - ``"knn_bipartite"`` — *k*-NN on two disjoint node sets
        - ``"epsilon_bipartite"`` — epsilon-ball on two disjoint node sets

    seed : int, optional
        Random seed for reproducible results.
    scale : float
        Characteristic length scale of the point cloud.  Default is 1.0.
    image_path : str, optional
        Path to a binary image for ``shape="image"``.  Black pixels are used
        as valid sampling regions.
    k : int
        Number of neighbours for ``knn`` and ``knn_bipartite`` modes.
    epsilon : float
        Neighbourhood radius for ``epsilon`` and ``epsilon_bipartite`` modes.
    bipartite_ratio : int
        Ratio of the two node sets for bipartite modes (e.g. 2 → equal halves).
    quantile_scale : float
        Distance quantile used as the length-scale for ``distance_decay`` mode.
    power_law_exp : float
        Exponent controlling the steepness of the distance-decay kernel.
    false_edges_number : int, optional
        Exact number of false (random long-range) edges to inject.  Mutually
        exclusive with *false_edges_fraction*.
    false_edges_fraction : float, optional
        Fraction of existing edges to replace with random false edges.
        Mutually exclusive with *false_edges_number*.

    Returns
    -------
    SpatialGraph
        A new graph with *positions*, *adjacency_matrix*, *node_metadata*, and
        *edge_metadata* populated.  ``edge_metadata["is_false"]`` is a boolean
        column marking injected edges.

    Raises
    ------
    ValueError
        If *n* ≤ 1, *dim* not in {2, 3}, *mode* is unsupported, *k* ≤ 0,
        *epsilon* ≤ 0, or both *false_edges_number* and *false_edges_fraction*
        are provided.

    Examples
    --------
    Minimal usage:

    >>> from spatial_graph_algorithms.simulate import generate
    >>> sn = generate(n=500, seed=42)

    With false-edge noise:

    >>> sn = generate(n=500, mode="knn", k=6, false_edges_fraction=0.05, seed=42)
    >>> sn.edge_metadata["is_false"].sum()
    # number of injected false edges
    """
    _validate_inputs(
        n=n,
        dim=dim,
        shape=shape,
        mode=mode,
        k=k,
        epsilon=epsilon,
        false_edges_number=false_edges_number,
        false_edges_fraction=false_edges_fraction,
    )

    rng = np.random.default_rng(seed)

    positions = generate_points(
        n=n,
        dim=dim,
        shape=shape,
        rng=rng,
        scale=scale,
        image_path=image_path,
    )

    edges = build_edges(
        positions=positions,
        mode=mode,
        k=k,
        epsilon=epsilon,
        bipartite_ratio=bipartite_ratio,
        quantile_scale=quantile_scale,
        power_law_exp=power_law_exp,
        rng=rng,
        dim=dim,
    )

    is_bipartite = "bipartite" in mode
    all_edges, false_edges, requested_false = inject_false_edges(
        edges,
        n_nodes=len(positions),
        is_bipartite=is_bipartite,
        bipartite_ratio=bipartite_ratio,
        false_edges_number=false_edges_number,
        false_edges_fraction=false_edges_fraction,
        rng=rng,
    )

    adjacency = _edges_to_adjacency(len(positions), all_edges)

    edge_df = pd.DataFrame(sorted(all_edges), columns=["source", "target"])
    edge_df["edge_id"] = np.arange(len(edge_df), dtype=int)
    edge_df["is_false"] = edge_df.apply(
        lambda r: (int(r["source"]), int(r["target"])) in false_edges,
        axis=1,
    )

    node_df = pd.DataFrame({"node_id": np.arange(len(positions), dtype=int)})
    node_df.attrs["simulation"] = {
        "seed": seed,
        "shape": shape,
        "mode": mode,
        "n": int(n),
        "dim": int(dim),
        "k": int(k),
        "epsilon": float(epsilon),
        "requested_false_edges": int(requested_false),
        "is_bipartite": bool(is_bipartite),
    }

    return SpatialGraph(
        adjacency_matrix=adjacency,
        positions=positions,
        node_metadata=node_df,
        edge_metadata=edge_df,
        keep_lcc=False,
    )


__all__ = ["generate"]
