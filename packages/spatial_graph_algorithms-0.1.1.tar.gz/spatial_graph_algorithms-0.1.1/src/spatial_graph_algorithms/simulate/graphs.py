"""Graph construction modes for spatial_graph_algorithms.simulate."""

from __future__ import annotations

import warnings
from collections.abc import Iterable, Sequence
from typing import Set, Tuple

import numpy as np
from scipy.spatial import Delaunay
from scipy.spatial.distance import pdist, squareform
from sklearn.neighbors import NearestNeighbors

Edge = Tuple[int, int]


def _edge(i: int, j: int) -> Edge:
    return (i, j) if i < j else (j, i)


def _from_neighbor_indices(indices: Sequence[Iterable[int]]) -> Set[Edge]:
    edges: Set[Edge] = set()
    for i, neigh in enumerate(indices):
        for j in neigh:
            if i != j:
                edges.add(_edge(i, int(j)))
    return edges


def mode_knn(positions: np.ndarray, k: int) -> Set[Edge]:
    """Return edges from k-nearest-neighbour connectivity."""
    nbrs = NearestNeighbors(n_neighbors=k + 1).fit(positions)
    _, indices = nbrs.kneighbors(positions)
    return _from_neighbor_indices(indices[:, 1:])


def mode_epsilon(positions: np.ndarray, radius: float) -> Set[Edge]:
    """Return edges from epsilon-ball connectivity."""
    nbrs = NearestNeighbors(radius=radius).fit(positions)
    _, indices = nbrs.radius_neighbors(positions, sort_results=True)
    trimmed = [idx[1:] if len(idx) > 0 else idx for idx in indices]
    return _from_neighbor_indices(trimmed)


def mode_delaunay(positions: np.ndarray) -> Set[Edge]:
    """Return edges from Delaunay triangulation."""
    tess = Delaunay(positions)
    edges: Set[Edge] = set()
    for simplex in tess.simplices:
        for i in range(len(simplex)):
            for j in range(i + 1, len(simplex)):
                edges.add(_edge(int(simplex[i]), int(simplex[j])))
    return edges


def mode_delaunay_corrected(positions: np.ndarray, cutoff_percentile: float = 95.0) -> Set[Edge]:
    """Return Delaunay edges with long-range outlier edges removed."""
    edges = mode_delaunay(positions)
    if not edges:
        return edges
    dist_map = {e: float(np.linalg.norm(positions[e[0]] - positions[e[1]])) for e in edges}
    distances = np.asarray(list(dist_map.values()), dtype=float)
    cutoff = np.percentile(distances, cutoff_percentile)
    kept = {e for e, d in dist_map.items() if d <= cutoff}

    if not kept:
        kept = {min(dist_map, key=dist_map.get)}

    # ensure weak connectivity by adding shortest remaining edges gradually
    n = len(positions)
    parent = list(range(n))

    def find(x: int) -> int:
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a: int, b: int) -> None:
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra

    for a, b in kept:
        union(a, b)

    if len({find(i) for i in range(n)}) > 1:
        for edge, _ in sorted(dist_map.items(), key=lambda kv: kv[1]):
            if edge in kept:
                continue
            kept.add(edge)
            union(edge[0], edge[1])
            if len({find(i) for i in range(n)}) == 1:
                break
    return kept


def mode_distance_decay(
    positions: np.ndarray,
    rng: np.random.Generator,
    quantile_scale: float = 0.05,
    power_law_exp: float = 4.0,
) -> Set[Edge]:
    """Return edges sampled with Gaussian-decay probability based on distance."""
    raw_distances = squareform(pdist(positions))
    scale = np.quantile(raw_distances.flatten(), quantile_scale)
    probabilities = 1.0 / (np.power(raw_distances / max(scale, 1e-9), power_law_exp) + 1e-3)
    probabilities /= np.max(probabilities)
    np.fill_diagonal(probabilities, 0)

    n = len(positions)
    edges: Set[Edge] = set()
    for i in range(n):
        for j in range(i + 1, n):
            if rng.random() < probabilities[i, j]:
                edges.add((i, j))
    return edges


def _split_bipartite(positions: np.ndarray, ratio: int) -> tuple[np.ndarray, np.ndarray, int]:
    n = len(positions)
    split = n // ratio
    if split <= 0 or split >= n:
        raise ValueError("Invalid bipartite_ratio for given n")
    return positions[:split], positions[split:], split


def mode_knn_bipartite(positions: np.ndarray, k: int, ratio: int = 2) -> Set[Edge]:
    """Return k-NN edges between two bipartite node partitions."""
    left, right, split = _split_bipartite(positions, ratio)
    if len(right) < k or len(left) < k:
        raise ValueError("k too large for bipartite partition")

    nbrs_l = NearestNeighbors(n_neighbors=k).fit(right)
    _, idx_l = nbrs_l.kneighbors(left)

    nbrs_r = NearestNeighbors(n_neighbors=k).fit(left)
    _, idx_r = nbrs_r.kneighbors(right)

    edges: Set[Edge] = set()
    for i, neigh in enumerate(idx_l):
        for j in neigh:
            edges.add(_edge(i, int(j) + split))
    for j, neigh in enumerate(idx_r):
        for i in neigh:
            edges.add(_edge(int(i), j + split))
    return edges


def mode_epsilon_bipartite(positions: np.ndarray, radius: float, ratio: int = 2) -> Set[Edge]:
    """Return epsilon-ball edges between two bipartite node partitions."""
    left, right, split = _split_bipartite(positions, ratio)

    nbrs_l = NearestNeighbors(radius=radius).fit(right)
    _, idx_l = nbrs_l.radius_neighbors(left, sort_results=True)

    nbrs_r = NearestNeighbors(radius=radius).fit(left)
    _, idx_r = nbrs_r.radius_neighbors(right, sort_results=True)

    edges: Set[Edge] = set()
    for i, neigh in enumerate(idx_l):
        for j in neigh:
            edges.add(_edge(i, int(j) + split))
    for j, neigh in enumerate(idx_r):
        for i in neigh:
            edges.add(_edge(int(i), j + split))
    return edges


def mode_lattice(positions: np.ndarray, dim: int) -> Set[Edge]:
    """Return edges from a regular grid (4-connected in 2-D, 6-connected in 3-D)."""
    n_neighbors = 4 if dim == 2 else 6
    return mode_knn(positions, k=n_neighbors)


def build_edges(
    positions: np.ndarray,
    mode: str,
    *,
    k: int,
    epsilon: float,
    bipartite_ratio: int,
    quantile_scale: float,
    power_law_exp: float,
    rng: np.random.Generator,
    dim: int,
) -> Set[Edge]:
    """Dispatch to the appropriate edge-construction function for *mode*."""
    mode_key = mode.lower().replace("-", "_")
    aliases = {"epsilon_ball": "epsilon", "epsilon_ball_bipartite": "epsilon_bipartite"}
    mode_key = aliases.get(mode_key, mode_key)

    if mode_key == "knn":
        return mode_knn(positions, k=k)
    if mode_key == "epsilon":
        edges = mode_epsilon(positions, radius=epsilon)
        if not edges:
            warnings.warn("epsilon produced no edges; falling back to k=1 knn", UserWarning, stacklevel=2)
            return mode_knn(positions, k=1)
        return edges
    if mode_key == "delaunay":
        return mode_delaunay(positions)
    if mode_key == "delaunay_corrected":
        return mode_delaunay_corrected(positions)
    if mode_key == "distance_decay":
        return mode_distance_decay(
            positions,
            rng=rng,
            quantile_scale=quantile_scale,
            power_law_exp=power_law_exp,
        )
    if mode_key == "knn_bipartite":
        return mode_knn_bipartite(positions, k=k, ratio=bipartite_ratio)
    if mode_key == "epsilon_bipartite":
        edges = mode_epsilon_bipartite(positions, radius=epsilon, ratio=bipartite_ratio)
        if not edges:
            warnings.warn(
                "epsilon_bipartite produced no edges; falling back to knn_bipartite(k=1)",
                UserWarning,
                stacklevel=2,
            )
            return mode_knn_bipartite(positions, k=1, ratio=bipartite_ratio)
        return edges
    if mode_key == "lattice":
        return mode_lattice(positions, dim=dim)

    raise ValueError(f"Unsupported mode '{mode}'")
