"""Point-cloud generation utilities for spatial_graph_algorithms.simulate."""

from __future__ import annotations

from typing import Optional

import numpy as np
from PIL import Image


def _generate_square_or_cube(n: int, dim: int, scale: float, rng: np.random.Generator) -> np.ndarray:
    return rng.random((n, dim)) * scale


def _generate_circle_or_sphere(n: int, dim: int, radius: float, rng: np.random.Generator) -> np.ndarray:
    points = []
    while len(points) < n:
        candidate = rng.uniform(-radius, radius, size=dim)
        if np.sum(candidate ** 2) <= radius ** 2:
            points.append(candidate)
    return np.asarray(points, dtype=float)


def _generate_from_image(n: int, image_path: str, rng: np.random.Generator) -> np.ndarray:
    with Image.open(image_path) as img:
        img = img.convert("1")
        image_data = np.array(img)
        height, width = image_data.shape

    points = []
    max_tries = max(n * 100, 1000)
    tries = 0
    while len(points) < n and tries < max_tries:
        x = rng.uniform(0, width)
        y = rng.uniform(0, height)
        ix, iy = int(x), int(y)
        if image_data[iy, ix] == 0:
            points.append((x, height - y))
        tries += 1

    if len(points) < n:
        raise ValueError(
            f"Could only sample {len(points)} black-pixel points from image; requested {n}."
        )
    return np.asarray(points, dtype=float)


def generate_points(
    n: int,
    dim: int,
    shape: str,
    rng: np.random.Generator,
    *,
    scale: float = 1.0,
    image_path: Optional[str] = None,
) -> np.ndarray:
    """Generate a point cloud for a given shape and dimensionality.

    Parameters
    ----------
    n : int
        Number of points to sample.
    dim : int
        Spatial dimension (2 or 3).
    shape : str
        Geometry name.  Supported values: ``"circle"``, ``"square"``,
        ``"sphere"``, ``"cube"``, ``"image"`` / ``"image_2d"``.
    rng : np.random.Generator
        Seeded random-number generator (created via ``np.random.default_rng``).
    scale : float
        Characteristic length scale.  For circle/sphere this is the radius;
        for square/cube this is the side length.
    image_path : str, optional
        Path to a binary image.  Required when *shape* is ``"image"``.

    Returns
    -------
    np.ndarray
        Float array of shape ``(n, dim)`` containing the sampled coordinates.

    Raises
    ------
    ValueError
        If *shape* is unknown, *dim* is incompatible with *shape*, or the image
        does not contain enough valid pixels.
    """
    shape_key = shape.lower()

    if shape_key == "square":
        if dim != 2:
            raise ValueError("shape='square' requires dim=2")
        return _generate_square_or_cube(n=n, dim=2, scale=scale, rng=rng)

    if shape_key == "cube":
        if dim != 3:
            raise ValueError("shape='cube' requires dim=3")
        return _generate_square_or_cube(n=n, dim=3, scale=scale, rng=rng)

    if shape_key == "circle":
        if dim != 2:
            raise ValueError("shape='circle' requires dim=2")
        return _generate_circle_or_sphere(n=n, dim=2, radius=scale, rng=rng)

    if shape_key == "sphere":
        if dim != 3:
            raise ValueError("shape='sphere' requires dim=3")
        return _generate_circle_or_sphere(n=n, dim=3, radius=scale, rng=rng)

    if shape_key in {"image_2d", "image"}:
        if dim != 2:
            raise ValueError("image mode requires dim=2")
        if not image_path:
            raise ValueError("image mode requires image_path")
        return _generate_from_image(n=n, image_path=image_path, rng=rng)

    raise ValueError(f"Unsupported shape '{shape}'")
