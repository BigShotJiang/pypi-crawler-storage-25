"""False-edge injection policies for simulation graphs."""

from __future__ import annotations

from collections.abc import Iterable
from itertools import combinations
from typing import Set, Tuple

import numpy as np

Edge = Tuple[int, int]


def _edge(i: int, j: int) -> Edge:
    return (i, j) if i < j else (j, i)


def _resolve_false_edge_count(
    edge_count: int,
    false_edges_number: int | None,
    false_edges_fraction: float | None,
) -> int:
    if false_edges_number is not None and false_edges_fraction is not None:
        raise ValueError("Provide only one of false_edges_number or false_edges_fraction")
    if false_edges_number is not None:
        if false_edges_number < 0:
            raise ValueError("false_edges_number must be >= 0")
        return int(false_edges_number)
    if false_edges_fraction is not None:
        if false_edges_fraction < 0:
            raise ValueError("false_edges_fraction must be >= 0")
        return int(round(edge_count * false_edges_fraction))
    return 0


def _candidate_edges_unipartite(n_nodes: int, existing: Set[Edge]) -> list[Edge]:
    return [e for e in combinations(range(n_nodes), 2) if e not in existing]


def _candidate_edges_bipartite(n_nodes: int, existing: Set[Edge], ratio: int) -> list[Edge]:
    split = n_nodes // ratio
    if split <= 0 or split >= n_nodes:
        raise ValueError("Invalid bipartite_ratio for false-edge injection")
    candidates = []
    for i in range(split):
        for j in range(split, n_nodes):
            e = _edge(i, j)
            if e not in existing:
                candidates.append(e)
    return candidates


def inject_false_edges(
    edges: Iterable[Edge],
    *,
    n_nodes: int,
    is_bipartite: bool,
    bipartite_ratio: int,
    false_edges_number: int | None,
    false_edges_fraction: float | None,
    rng: np.random.Generator,
) -> tuple[set[Edge], set[Edge], int]:
    """Inject random false edges into an existing edge set.

    False edges are sampled uniformly from the set of non-existing edges
    (respecting bipartite structure when applicable) and added to the graph.
    They are returned as a separate set so callers can label them.

    Parameters
    ----------
    edges : iterable of (int, int)
        Existing (true) edges.  Each pair ``(i, j)`` is stored canonically
        as ``(min(i, j), max(i, j))``.
    n_nodes : int
        Total number of nodes.
    is_bipartite : bool
        If ``True``, false edges are sampled only between the two node
        partitions.
    bipartite_ratio : int
        Size ratio of the two partitions used to compute the split index.
        Ignored when *is_bipartite* is ``False``.
    false_edges_number : int or None
        Exact count of false edges to inject.
    false_edges_fraction : float or None
        Fraction of existing edges to inject as false.  Mutually exclusive
        with *false_edges_number*.
    rng : np.random.Generator
        Seeded random-number generator.

    Returns
    -------
    all_edges : set of (int, int)
        Original edges plus injected false edges.
    false_edges : set of (int, int)
        Only the injected false edges.
    requested_count : int
        Number of false edges that were requested (and injected).

    Raises
    ------
    ValueError
        If both *false_edges_number* and *false_edges_fraction* are provided,
        or if the requested count exceeds the available candidate space.
    """
    existing = {_edge(a, b) for a, b in edges}
    requested = _resolve_false_edge_count(
        edge_count=len(existing),
        false_edges_number=false_edges_number,
        false_edges_fraction=false_edges_fraction,
    )
    if requested == 0:
        return existing, set(), 0

    if is_bipartite:
        candidates = _candidate_edges_bipartite(n_nodes=n_nodes, existing=existing, ratio=bipartite_ratio)
    else:
        candidates = _candidate_edges_unipartite(n_nodes=n_nodes, existing=existing)

    if requested > len(candidates):
        mode_label = "bipartite" if is_bipartite else "unipartite"
        raise ValueError(
            f"Requested {requested} false edges exceeds max allowed {len(candidates)} for {mode_label} candidate space"
        )

    choice_idx = rng.choice(len(candidates), size=requested, replace=False)
    chosen = {candidates[int(i)] for i in np.atleast_1d(choice_idx)}
    return existing.union(chosen), chosen, requested
