"""Spatial coherence analysis. Not yet implemented — stub for Phase 4."""


def score(*args, **kwargs):
    """Compute a spatial coherence score for a SpatialGraph. Not yet implemented."""
    raise NotImplementedError(
        "spatial_graph_algorithms.coherence is not yet implemented. "
        "This stub will be replaced in Phase 4."
    )
