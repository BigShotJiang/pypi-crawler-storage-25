"""Spatial graph denoising. Not yet implemented — stub for Phase 3."""


def denoise(*args, **kwargs):
    """Remove likely-false edges from a SpatialGraph. Not yet implemented."""
    raise NotImplementedError(
        "spatial_graph_algorithms.denoise is not yet implemented. "
        "This stub will be replaced in Phase 3."
    )
