"""spatial_graph_algorithms — unified toolkit for sequencing-based spatial microscopy analysis."""

from importlib.metadata import PackageNotFoundError, version as _version

try:
    __version__ = _version("spatial_graph_algorithms")
except PackageNotFoundError:
    __version__ = "0.1.0"

from . import coherence, denoise, metrics, reconstruct, simulate
from .network import SpatialGraph

__all__ = [
    "SpatialGraph",
    "simulate",
    "reconstruct",
    "metrics",
    "denoise",
    "coherence",
]
