"""Quality evaluation combining reconstruction metrics and graph structure.

Main entry point is :func:`evaluate`, which accepts a ``SpatialGraph`` after
reconstruction and returns a flat dictionary of all structural and quality
metrics, with an optional CSV export.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

from spatial_graph_algorithms.network import SpatialGraph
from spatial_graph_algorithms.reconstruct.quality import cpd, distortion, knn

from .graph_properties import degree_distribution, degree_sequence, graph_summary


def evaluate(
    sn: SpatialGraph,
    *,
    k_neighbors: int = 10,
    compute_distortion: bool = False,
    output_csv: Optional[str | Path] = None,
) -> dict:
    """Compute graph structure properties and reconstruction quality metrics.

    Always computes structural properties from the adjacency matrix.  When
    both :attr:`~spatial_graph_algorithms.network.SpatialGraph.positions` and
    :attr:`~spatial_graph_algorithms.network.SpatialGraph.reconstructed_positions` are
    set, also computes reconstruction quality metrics.

    Parameters
    ----------
    sn : SpatialGraph
        Input graph.  Should have *reconstructed_positions* set (via
        :func:`spatial_graph_algorithms.reconstruct.reconstruct`) for quality metrics to
        be populated.
    k_neighbors : int
        Number of neighbours used in the KNN metric.  Default 10.
    compute_distortion : bool
        If ``True``, also compute the median relative pairwise-distance
        distortion.  Disabled by default because it is O(n²) and rarely
        needed.  Default ``False``.
    output_csv : str or Path, optional
        If given, the result dictionary is written as a one-row CSV to this
        path.  Parent directories are created if needed.

    Returns
    -------
    dict
        Flat dictionary with the following keys:

        **Graph structure**

        - ``n_nodes`` — number of nodes.
        - ``n_edges`` — number of undirected edges.
        - ``min_degree``, ``max_degree``, ``mean_degree``, ``degree_std``
        - ``density`` — edge density in ``[0, 1]``.
        - ``transitivity`` — global clustering coefficient.
        - ``largest_component_fraction`` — fraction of nodes in the LCC.

        **Reconstruction quality** (``None`` if positions unavailable)

        - ``cpd`` — R² of pairwise distances ``[0, 1]``.
        - ``knn`` — Mean k-NN overlap ``[0, 1]``.
        - ``distortion`` — Median relative distance distortion ``>= 0``
          (``None`` unless ``compute_distortion=True``).

    Examples
    --------
    >>> from spatial_graph_algorithms.simulate import generate
    >>> from spatial_graph_algorithms.reconstruct import reconstruct
    >>> from spatial_graph_algorithms.metrics import evaluate
    >>> sn = generate(n=300, seed=42)
    >>> sn_rec = reconstruct(sn, method="mds", seed=42)
    >>> m = evaluate(sn_rec)
    >>> m["cpd"] > 0.7
    True
    """
    import networkx as nx

    results = graph_summary(sn)

    seq = degree_sequence(sn)
    results["degree_std"] = float(np.std(seq)) if len(seq) else 0.0

    G = sn.graph
    results["transitivity"] = float(nx.transitivity(G))
    n_lcc = max((len(c) for c in nx.connected_components(G)), default=0)
    results["largest_component_fraction"] = (
        n_lcc / results["n_nodes"] if results["n_nodes"] > 0 else 0.0
    )

    if sn.positions is not None and sn.reconstructed_positions is not None:
        results["cpd"] = cpd(sn.positions, sn.reconstructed_positions)
        results["knn"] = knn(sn.positions, sn.reconstructed_positions, k=k_neighbors)
        results["distortion"] = (
            distortion(sn.positions, sn.reconstructed_positions)
            if compute_distortion
            else None
        )
    else:
        results["cpd"] = None
        results["knn"] = None
        results["distortion"] = None

    if output_csv is not None:
        out = Path(output_csv)
        out.parent.mkdir(parents=True, exist_ok=True)
        pd.DataFrame([results]).to_csv(out, index=False)

    return results


__all__ = [
    "evaluate",
    "degree_sequence",
    "degree_distribution",
    "graph_summary",
]
