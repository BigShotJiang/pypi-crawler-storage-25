"""Structural property helpers for SpatialGraph objects."""

from __future__ import annotations

import numpy as np

from spatial_graph_algorithms.network import SpatialGraph


def degree_sequence(sn: SpatialGraph) -> np.ndarray:
    """Return the per-node degree sequence.

    Parameters
    ----------
    sn : SpatialGraph
        Input graph.

    Returns
    -------
    np.ndarray
        Float array of shape ``(n_nodes,)`` where entry *i* is the degree of
        node *i*.
    """
    deg = np.asarray(sn.adjacency_matrix.sum(axis=1)).ravel()
    return deg.astype(float)


def degree_distribution(sn: SpatialGraph) -> dict:
    """Compute the degree distribution as counts and proportions.

    Parameters
    ----------
    sn : SpatialGraph
        Input graph.

    Returns
    -------
    dict
        A dictionary with two sub-dicts:

        - ``"counts"`` — ``{degree: node_count}`` mapping.
        - ``"proportions"`` — ``{degree: fraction}`` mapping.  Proportions
          sum to 1.0.

    Examples
    --------
    >>> from spatial_graph_algorithms.simulate import generate
    >>> from spatial_graph_algorithms.metrics import degree_distribution
    >>> sn = generate(n=100, seed=0)
    >>> dist = degree_distribution(sn)
    >>> sum(dist["proportions"].values())
    1.0
    """
    seq = degree_sequence(sn).astype(int)
    if len(seq) == 0:
        return {"counts": {}, "proportions": {}}
    unique, counts = np.unique(seq, return_counts=True)
    total = counts.sum()
    cdict = {int(k): int(v) for k, v in zip(unique, counts)}
    pdict = {int(k): float(v / total) for k, v in zip(unique, counts)}
    return {"counts": cdict, "proportions": pdict}


def graph_summary(sn: SpatialGraph) -> dict:
    """Return a high-level structural summary of the graph.

    Parameters
    ----------
    sn : SpatialGraph
        Input graph.

    Returns
    -------
    dict
        Dictionary with keys:

        - ``n_nodes`` — number of nodes.
        - ``n_edges`` — number of undirected edges.
        - ``min_degree`` — minimum node degree.
        - ``max_degree`` — maximum node degree.
        - ``mean_degree`` — mean node degree.
        - ``density`` — edge density in ``[0, 1]``
          (``2 * n_edges / (n * (n-1))``).

    Examples
    --------
    >>> from spatial_graph_algorithms.simulate import generate
    >>> from spatial_graph_algorithms.metrics import graph_summary
    >>> sn = generate(n=200, seed=0)
    >>> s = graph_summary(sn)
    >>> s["n_nodes"]
    200
    """
    seq = degree_sequence(sn)
    n = sn.adjacency_matrix.shape[0]
    edge_count = int(sn.adjacency_matrix.nnz // 2)
    max_edges = (n * (n - 1)) / 2 if n > 1 else 1
    return {
        "n_nodes": int(n),
        "n_edges": edge_count,
        "min_degree": float(np.min(seq)) if len(seq) else 0.0,
        "max_degree": float(np.max(seq)) if len(seq) else 0.0,
        "mean_degree": float(np.mean(seq)) if len(seq) else 0.0,
        "density": float(edge_count / max_edges) if max_edges else 0.0,
    }
