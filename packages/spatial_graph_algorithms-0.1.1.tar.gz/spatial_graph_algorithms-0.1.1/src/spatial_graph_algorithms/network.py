"""Core data container for spatial network analysis.

Public exports
--------------
SpatialGraph : dataclass
    Central object that holds the adjacency matrix, node positions, and metadata.
to_igraph : function
    Convert a SpatialGraph to an undirected igraph.Graph.
"""

from __future__ import annotations

import warnings
from dataclasses import dataclass
from typing import Any, Dict, Optional, Union

import igraph
import networkx as nx
import numpy as np
import pandas as pd
import scipy.sparse


@dataclass(eq=False)
class SpatialGraph:
    """Core graph and coordinate container for spatial network analysis.

    All pipeline functions accept and return ``SpatialGraph`` objects.  The
    adjacency matrix is stored internally as a CSR sparse matrix with the
    diagonal forced to zero.  When *keep_lcc* is ``True`` (the default), only
    the largest connected component is retained on construction.

    Parameters
    ----------
    adjacency_matrix : scipy.sparse.csr_matrix
        Symmetric, unweighted adjacency matrix.  Any format accepted by
        ``scipy.sparse.csr_matrix`` is converted automatically.  Self-loops are
        removed silently.
    positions : np.ndarray, optional
        Ground-truth node coordinates, shape ``(n_nodes, dim)``.
    reconstructed_positions : np.ndarray, optional
        Coordinates recovered by a reconstruction algorithm, same shape as
        *positions*.  Set by :func:`spatial_graph_algorithms.reconstruct.reconstruct`.
    node_metadata : pd.DataFrame, optional
        Per-node attributes.  Row *i* corresponds to node *i*.
    edge_metadata : pd.DataFrame, optional
        Per-edge attributes with columns ``source``, ``target``, and optionally
        ``is_false`` (bool) when the graph was created by
        :func:`spatial_graph_algorithms.simulate.generate`.
    node_id_map : dict, optional
        Mapping from original node identifiers to integer indices ``0..n-1``.
        Built automatically when using :meth:`from_edge_list`.
    keep_lcc : bool
        If ``True`` (default), only the largest connected component is kept on
        construction.  Set to ``False`` when you know the graph is connected or
        want to preserve all nodes.

    Examples
    --------
    Build from a scipy sparse matrix:

    >>> import scipy.sparse
    >>> adj = scipy.sparse.eye(3, format="csr") * 0  # 3 isolated nodes
    >>> sn = SpatialGraph(adjacency_matrix=adj, keep_lcc=False)
    >>> sn.adjacency_matrix.shape
    (3, 3)
    """

    adjacency_matrix: scipy.sparse.csr_matrix
    positions: Optional[np.ndarray] = None
    reconstructed_positions: Optional[np.ndarray] = None
    node_metadata: Optional[pd.DataFrame] = None
    edge_metadata: Optional[pd.DataFrame] = None
    node_id_map: Optional[Dict[Any, int]] = None
    keep_lcc: bool = True
    _nx_cache: Optional[nx.Graph] = None

    def __post_init__(self) -> None:
        # Move to backing field once, then route all future writes via property setter.
        initial_adj = self._normalize_adjacency(self.adjacency_matrix)
        object.__setattr__(self, "_adjacency_matrix", initial_adj)
        self.__dict__.pop("adjacency_matrix", None)

        if self.node_id_map is None:
            n = self._adjacency_matrix.shape[0]
            self.node_id_map = {i: i for i in range(n)}

        if self.positions is not None and self.positions.shape[0] != self._adjacency_matrix.shape[0]:
            raise ValueError(
                "positions row count must match adjacency_matrix shape[0] "
                f"({self.positions.shape[0]} != {self._adjacency_matrix.shape[0]})"
            )

        if self.keep_lcc:
            self._extract_lcc()

    @staticmethod
    def _normalize_adjacency(value: scipy.sparse.csr_matrix) -> scipy.sparse.csr_matrix:
        adj = scipy.sparse.csr_matrix(value).copy()
        adj.setdiag(0)
        adj.eliminate_zeros()
        return adj

    @property
    def adjacency_matrix(self) -> scipy.sparse.csr_matrix:
        """CSR adjacency matrix with zero diagonal and no duplicate entries."""
        return self._adjacency_matrix

    @adjacency_matrix.setter
    def adjacency_matrix(self, value: scipy.sparse.csr_matrix) -> None:
        self._adjacency_matrix = self._normalize_adjacency(value)
        self._nx_cache = None

    @property
    def graph(self) -> nx.Graph:
        """NetworkX undirected graph built lazily from the adjacency matrix.

        The result is cached; assigning a new *adjacency_matrix* invalidates
        the cache automatically.

        Returns
        -------
        nx.Graph
            Undirected graph with integer node labels ``0..n-1``.
        """
        if self._nx_cache is None:
            self._nx_cache = nx.from_scipy_sparse_array(self._adjacency_matrix)
        return self._nx_cache

    def _extract_lcc(self) -> None:
        n_components, labels = scipy.sparse.csgraph.connected_components(
            self._adjacency_matrix, directed=False
        )
        if n_components <= 1:
            return

        counts = np.bincount(labels)
        lcc_label = int(np.argmax(counts))
        keep_idx = np.where(labels == lcc_label)[0]

        warnings.warn(
            f"Found {n_components} connected components; keeping largest with {len(keep_idx)} nodes.",
            UserWarning,
            stacklevel=2,
        )

        self._adjacency_matrix = self._adjacency_matrix[keep_idx][:, keep_idx].tocsr()
        self._nx_cache = None

        if self.positions is not None:
            self.positions = self.positions[keep_idx]
        if self.reconstructed_positions is not None:
            self.reconstructed_positions = self.reconstructed_positions[keep_idx]
        if self.node_metadata is not None:
            self.node_metadata = self.node_metadata.iloc[keep_idx].reset_index(drop=True)

        if self.node_id_map is not None:
            inverse = {v: k for k, v in self.node_id_map.items()}
            kept_original = [inverse[int(i)] for i in keep_idx]
            self.node_id_map = {orig: new_i for new_i, orig in enumerate(kept_original)}

    @classmethod
    def from_edge_list(
        cls,
        source: Union[str, pd.DataFrame],
        source_col: str = "source",
        target_col: str = "target",
        **kwargs: Any,
    ) -> SpatialGraph:
        """Construct a SpatialGraph from a CSV edge list or a DataFrame.

        Node identifiers in the edge list can be arbitrary (strings, integers,
        etc.).  They are remapped to a contiguous integer range ``0..n-1`` and
        the mapping is stored in :attr:`node_id_map`.

        Parameters
        ----------
        source : str or pd.DataFrame
            Path to a CSV file or a DataFrame with at least two columns
            containing source and target node identifiers.
        source_col : str
            Column name for the source node.  Default is ``"source"``.
        target_col : str
            Column name for the target node.  Default is ``"target"``.
        **kwargs
            Additional keyword arguments forwarded to the constructor (e.g.
            ``positions``, ``keep_lcc``).

        Returns
        -------
        SpatialGraph
            A new instance with *adjacency_matrix* and *node_id_map* populated.

        Raises
        ------
        KeyError
            If *source_col* or *target_col* are not present in the data.

        Examples
        --------
        >>> sn = SpatialGraph.from_edge_list("edges.csv")
        >>> sn = SpatialGraph.from_edge_list(df, source_col="u", target_col="v")
        """
        if isinstance(source, str):
            df = pd.read_csv(source)
        else:
            df = source

        node_ids = sorted(set(df[source_col].tolist()).union(df[target_col].tolist()))
        id_map = {orig: i for i, orig in enumerate(node_ids)}

        n = len(node_ids)
        rows = np.array([id_map[v] for v in df[source_col]], dtype=int)
        cols = np.array([id_map[v] for v in df[target_col]], dtype=int)
        data = np.ones(len(rows), dtype=float)

        adj = scipy.sparse.csr_matrix(
            (
                np.concatenate([data, data]),
                (np.concatenate([rows, cols]), np.concatenate([cols, rows])),
            ),
            shape=(n, n),
        )

        return cls(adjacency_matrix=adj, node_id_map=id_map, **kwargs)

    @classmethod
    def from_positions(
        cls,
        source: Union[str, pd.DataFrame, np.ndarray],
        **kwargs: Any,
    ) -> SpatialGraph:
        """Construct a SpatialGraph from a point-cloud (no edges).

        The adjacency matrix is initialised as an empty *n × n* matrix.  Use
        :func:`spatial_graph_algorithms.simulate.generate` if you want edges built
        automatically from the positions.

        Parameters
        ----------
        source : str, pd.DataFrame, or np.ndarray
            Node coordinates.  A CSV path or DataFrame is converted to a float
            array; numeric columns are used as spatial dimensions.
        **kwargs
            Additional keyword arguments forwarded to the constructor.  Note
            that *keep_lcc* defaults to ``False`` here because an empty graph
            has no connected components.

        Returns
        -------
        SpatialGraph
            A new instance with *positions* set and an empty adjacency matrix.

        Examples
        --------
        >>> import numpy as np
        >>> pts = np.random.default_rng(0).random((50, 2))
        >>> sn = SpatialGraph.from_positions(pts)
        >>> sn.positions.shape
        (50, 2)
        """
        if isinstance(source, str):
            positions = pd.read_csv(source).values.astype(float)
        elif isinstance(source, pd.DataFrame):
            positions = source.values.astype(float)
        else:
            positions = np.asarray(source, dtype=float)

        n = positions.shape[0]
        adj = scipy.sparse.csr_matrix((n, n))
        id_map = {i: i for i in range(n)}

        keep_lcc = kwargs.pop("keep_lcc", False)
        return cls(
            adjacency_matrix=adj,
            positions=positions,
            node_id_map=id_map,
            keep_lcc=keep_lcc,
            **kwargs,
        )

    def to_edge_dataframe(self) -> pd.DataFrame:
        """Export unique edges as a DataFrame.

        Returns
        -------
        pd.DataFrame
            Two-column DataFrame with integer columns ``source`` and ``target``.
            Only the upper-triangle edges are returned (each edge once).
        """
        coo = self._adjacency_matrix.tocoo()
        mask = coo.row < coo.col
        return pd.DataFrame({"source": coo.row[mask], "target": coo.col[mask]})

    def to_positions_dataframe(self) -> pd.DataFrame:
        """Export node positions as a DataFrame.

        Column names are ``x``, ``y`` for 2-D and ``x``, ``y``, ``z`` for 3-D.
        Higher-dimensional arrays use ``x0``, ``x1``, ... notation.

        Returns
        -------
        pd.DataFrame
            One row per node, one column per spatial dimension.

        Raises
        ------
        ValueError
            If :attr:`positions` is ``None``.
        """
        if self.positions is None:
            raise ValueError("positions is None — nothing to export")

        dim = self.positions.shape[1]
        if dim == 2:
            cols = ["x", "y"]
        elif dim == 3:
            cols = ["x", "y", "z"]
        else:
            cols = [f"x{i}" for i in range(dim)]

        return pd.DataFrame(self.positions, columns=cols)

    def copy(self) -> SpatialGraph:
        """Return a deep copy of this SpatialGraph.

        The copy is constructed with ``keep_lcc=False`` because LCC extraction
        has already been applied to the source object.

        Returns
        -------
        SpatialGraph
            Independent copy with all arrays and DataFrames deep-copied.
        """
        return SpatialGraph(
            adjacency_matrix=self._adjacency_matrix.copy(),
            positions=None if self.positions is None else self.positions.copy(),
            reconstructed_positions=(
                None if self.reconstructed_positions is None else self.reconstructed_positions.copy()
            ),
            node_metadata=None if self.node_metadata is None else self.node_metadata.copy(deep=True),
            edge_metadata=None if self.edge_metadata is None else self.edge_metadata.copy(deep=True),
            node_id_map=None if self.node_id_map is None else dict(self.node_id_map),
            keep_lcc=False,
        )


def to_igraph(sn: SpatialGraph) -> igraph.Graph:
    """Convert a SpatialGraph to an undirected igraph.Graph.

    Parameters
    ----------
    sn : SpatialGraph
        Source graph.  Only the adjacency matrix is used; metadata is not
        transferred.

    Returns
    -------
    igraph.Graph
        Undirected unweighted graph with ``n`` vertices and the same edge set as
        *sn.adjacency_matrix*.

    Examples
    --------
    >>> from spatial_graph_algorithms.simulate import generate
    >>> from spatial_graph_algorithms.network import to_igraph
    >>> sn = generate(n=100, seed=0)
    >>> g = to_igraph(sn)
    >>> g.vcount()
    100
    """
    adj = sn._adjacency_matrix.tocoo()
    edges = [(int(r), int(c)) for r, c in zip(adj.row, adj.col) if r < c]
    return igraph.Graph(n=adj.shape[0], edges=edges)
