"""Network visualization helpers for SpatialGraph objects."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.figure import Figure

from spatial_graph_algorithms.network import SpatialGraph

DEFAULT_VISUALIZATION_DIR = Path(".planning/artifacts/visualizations")


def _maybe_save(fig: Figure, output_path: Optional[str | Path]) -> None:
    if output_path is None:
        return
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out, dpi=300, bbox_inches="tight")


def _extract_unique_edges(sn: SpatialGraph) -> np.ndarray:
    coo = sn.adjacency_matrix.tocoo()
    mask = coo.row < coo.col
    return np.column_stack([coo.row[mask], coo.col[mask]])


def _false_edge_set(sn: SpatialGraph) -> set[tuple[int, int]]:
    false_edge_set = set()
    if sn.edge_metadata is not None and {"source", "target", "is_false"}.issubset(sn.edge_metadata.columns):
        false_rows = sn.edge_metadata[sn.edge_metadata["is_false"] == True]  # noqa: E712
        false_edge_set = {
            (int(min(s, t)), int(max(s, t)))
            for s, t in false_rows[["source", "target"]].to_numpy()
        }
    return false_edge_set


def plot_network(
    sn: SpatialGraph,
    *,
    figsize: tuple[float, float] = (6.0, 4.5),
    node_size: float = 14.0,
    edge_alpha: float = 0.25,
    true_edge_color: str = "#777777",
    false_edge_color: str = "#d62728",
    false_edge_linewidth: float = 1.4,
    true_edge_linewidth: float = 0.7,
    save: bool = False,
    output_dir: str | Path = DEFAULT_VISUALIZATION_DIR,
    filename: str = "network.png",
) -> Figure:
    """Plot a 2-D spatial graph with optional false-edge highlighting.

    True edges are drawn in grey; false (injected noise) edges are drawn in
    red dashed lines when ``edge_metadata["is_false"]`` is present.

    Parameters
    ----------
    sn : SpatialGraph
        Graph to plot.  Must have 2-D *positions*.
    figsize : tuple of float
        Figure size ``(width, height)`` in inches.
    node_size : float
        Scatter marker size.
    edge_alpha : float
        Opacity of true edges.
    true_edge_color : str
        Hex colour for true edges.
    false_edge_color : str
        Hex colour for false edges.
    false_edge_linewidth : float
        Line width for false edges.
    true_edge_linewidth : float
        Line width for true edges.
    save : bool
        If ``True``, save the figure to *output_dir* / *filename*.
    output_dir : str or Path
        Directory for saved output.
    filename : str
        Filename for saved output.

    Returns
    -------
    matplotlib.figure.Figure
        The rendered figure.

    Raises
    ------
    ValueError
        If *positions* is ``None`` or not 2-D.
    """
    if sn.positions is None:
        raise ValueError("SpatialGraph.positions is None — cannot plot network")
    if sn.positions.shape[1] != 2:
        raise ValueError("plot_network currently supports only 2D positions")

    edges = _extract_unique_edges(sn)
    pos = sn.positions

    fig, ax = plt.subplots(figsize=figsize, dpi=300)
    false_edge_set = _false_edge_set(sn)

    for a, b in edges:
        key = (int(a), int(b))
        x = [pos[a, 0], pos[b, 0]]
        y = [pos[a, 1], pos[b, 1]]
        if key in false_edge_set:
            ax.plot(x, y, color=false_edge_color, alpha=0.9, linewidth=false_edge_linewidth, linestyle="--")
        else:
            ax.plot(x, y, color=true_edge_color, alpha=edge_alpha, linewidth=true_edge_linewidth)

    ax.scatter(pos[:, 0], pos[:, 1], s=node_size, c="#1f77b4", alpha=0.9, edgecolors="none")
    ax.set_title("Simulated Network")
    ax.set_xlabel("x")
    ax.set_ylabel("y")
    ax.set_aspect("equal", adjustable="box")

    if false_edge_set:
        from matplotlib.lines import Line2D

        handles = [
            Line2D([0], [0], color=true_edge_color, lw=true_edge_linewidth, label="true edges"),
            Line2D([0], [0], color=false_edge_color, lw=false_edge_linewidth, linestyle="--", label="false edges"),
        ]
        ax.legend(handles=handles, loc="best", frameon=False)

    if save:
        _maybe_save(fig, Path(output_dir) / filename)

    return fig


def plot_network_3d(
    sn: SpatialGraph,
    *,
    figsize: tuple[float, float] = (6.0, 4.5),
    save: bool = False,
    output_dir: str | Path = DEFAULT_VISUALIZATION_DIR,
    filename: str = "network_3d.png",
) -> Figure:
    """Plot a 3-D spatial graph using matplotlib's 3-D projection.

    Parameters
    ----------
    sn : SpatialGraph
        Graph to plot.  Must have 3-D *positions*.
    figsize : tuple of float
        Figure size in inches.
    save : bool
        Save figure to *output_dir* / *filename* when ``True``.
    output_dir : str or Path
        Directory for saved output.
    filename : str
        Filename for saved output.

    Returns
    -------
    matplotlib.figure.Figure
        The rendered figure.

    Raises
    ------
    ValueError
        If *positions* is ``None`` or not 3-D.
    """
    if sn.positions is None:
        raise ValueError("SpatialGraph.positions is None — cannot plot 3D network")
    if sn.positions.shape[1] != 3:
        raise ValueError("plot_network_3d requires 3D positions")

    edges = _extract_unique_edges(sn)
    pos = sn.positions
    false_edge_set = _false_edge_set(sn)

    fig = plt.figure(figsize=figsize, dpi=300)
    ax = fig.add_subplot(111, projection='3d')

    for a, b in edges:
        key = (int(a), int(b))
        xs = [pos[a, 0], pos[b, 0]]
        ys = [pos[a, 1], pos[b, 1]]
        zs = [pos[a, 2], pos[b, 2]]
        if key in false_edge_set:
            ax.plot(xs, ys, zs, color='#d62728', linestyle='--', linewidth=1.0, alpha=0.9)
        else:
            ax.plot(xs, ys, zs, color='#777777', linewidth=0.5, alpha=0.2)

    ax.scatter(pos[:, 0], pos[:, 1], pos[:, 2], s=8, c='#1f77b4', alpha=0.9)
    ax.set_title('Simulated 3D Network')
    ax.set_xlabel('x')
    ax.set_ylabel('y')
    ax.set_zlabel('z')

    if save:
        _maybe_save(fig, Path(output_dir) / filename)

    return fig


def plot_edge_length_histogram(
    sn: SpatialGraph,
    *,
    bins: int = 30,
    figsize: tuple[float, float] = (6.0, 4.5),
    density: bool = False,
    save: bool = False,
    output_dir: str | Path = DEFAULT_VISUALIZATION_DIR,
    filename: str = "edge_length_histogram.png",
) -> Figure:
    """Plot the distribution of Euclidean edge lengths.

    Parameters
    ----------
    sn : SpatialGraph
        Graph to analyse.  Requires *positions*.
    bins : int
        Number of histogram bins.
    figsize : tuple of float
        Figure size in inches.
    density : bool
        If ``True``, normalise the histogram to a probability density.
    save : bool
        Save figure to *output_dir* / *filename* when ``True``.
    output_dir : str or Path
        Directory for saved output.
    filename : str
        Filename for saved output.

    Returns
    -------
    matplotlib.figure.Figure
        The rendered figure.

    Raises
    ------
    ValueError
        If *positions* is ``None`` or the graph has no edges.
    """
    if sn.positions is None:
        raise ValueError("SpatialGraph.positions is None — cannot compute edge lengths")

    edges = _extract_unique_edges(sn)
    if len(edges) == 0:
        raise ValueError("No edges available for edge-length histogram")

    p = sn.positions
    diffs = p[edges[:, 0]] - p[edges[:, 1]]
    lengths = np.linalg.norm(diffs, axis=1)

    fig, ax = plt.subplots(figsize=figsize, dpi=300)
    ax.hist(lengths, bins=bins, density=density, color="#2ca02c", alpha=0.85)
    ax.set_title("Edge Length Distribution")
    ax.set_xlabel("edge length")
    ax.set_ylabel("density" if density else "count")

    if save:
        _maybe_save(fig, Path(output_dir) / filename)

    return fig


def plot_comparison(
    sn: SpatialGraph,
    *,
    figsize: tuple[float, float] = (12.0, 4.5),
    node_size: float = 8.0,
    cmap: str = "viridis",
    save: bool = False,
    output_dir: str | Path = DEFAULT_VISUALIZATION_DIR,
    filename: str = "reconstruction_comparison.png",
) -> Figure:
    """Plot original and reconstructed positions side by side.

    Nodes are coloured by their angle from the centroid in the original space,
    using the same colour map in both panels.  Consistent colouring makes it
    easy to judge whether the spatial structure was recovered.

    Procrustes alignment (optimal rotation + reflection, no scaling) is applied
    to the reconstructed positions before plotting so that orientation
    differences do not obscure reconstruction quality.

    Parameters
    ----------
    sn : SpatialGraph
        Graph with both *positions* and *reconstructed_positions* set.
    figsize : tuple of float
        Total figure size ``(width, height)`` in inches.  Default is wide enough
        for two side-by-side panels.
    node_size : float
        Scatter marker size.
    cmap : str
        Matplotlib colour map name for node colouring.
    save : bool
        Save figure to *output_dir* / *filename* when ``True``.
    output_dir : str or Path
        Directory for saved output.
    filename : str
        Filename for saved output.

    Returns
    -------
    matplotlib.figure.Figure
        Figure containing two subplots: original (left) and reconstructed
        (right).

    Raises
    ------
    ValueError
        If *positions* or *reconstructed_positions* is ``None``, or if either
        is not 2-D.
    """
    from scipy.spatial import procrustes as scipy_procrustes

    if sn.positions is None:
        raise ValueError("SpatialGraph.positions is None")
    if sn.reconstructed_positions is None:
        raise ValueError("SpatialGraph.reconstructed_positions is None — run reconstruct() first")
    if sn.positions.shape[1] > 2 or sn.reconstructed_positions.shape[1] > 2:
        raise ValueError("plot_comparison currently supports only 2D positions")

    orig = sn.positions.copy().astype(float)
    recon = sn.reconstructed_positions.copy().astype(float)

    _, recon_aligned, _ = scipy_procrustes(orig, recon)

    centroid = orig.mean(axis=0)
    angles = np.arctan2(orig[:, 1] - centroid[1], orig[:, 0] - centroid[0])
    colors = (angles - angles.min()) / ((angles.max() - angles.min()) + 1e-12)

    fig, axes = plt.subplots(1, 2, figsize=figsize, dpi=150)

    sc0 = axes[0].scatter(orig[:, 0], orig[:, 1], c=colors, cmap=cmap, s=node_size, alpha=0.85, edgecolors="none")
    axes[0].set_title("Original positions")
    axes[0].set_xlabel("x")
    axes[0].set_ylabel("y")
    axes[0].set_aspect("equal", adjustable="box")

    axes[1].scatter(recon_aligned[:, 0], recon_aligned[:, 1], c=colors, cmap=cmap, s=node_size, alpha=0.85, edgecolors="none")
    axes[1].set_title("Reconstructed positions")
    axes[1].set_xlabel("x")
    axes[1].set_ylabel("y")
    axes[1].set_aspect("equal", adjustable="box")

    fig.colorbar(sc0, ax=axes, label="angle from centroid (normalized)", shrink=0.8)
    fig.suptitle("Spatial Reconstruction Comparison", fontsize=12)

    if save:
        _maybe_save(fig, Path(output_dir) / filename)

    return fig


def render_simulation_visualization_bundle(
    sn: SpatialGraph,
    *,
    output_dir: str | Path = DEFAULT_VISUALIZATION_DIR,
    prefix: str = "simulation",
) -> dict[str, Path]:
    """Save the standard visualisation bundle (network + edge-length histogram) to disk.

    Parameters
    ----------
    sn : SpatialGraph
        Graph to visualise.
    output_dir : str or Path
        Directory where plots are written.
    prefix : str
        Filename prefix for all saved plots.

    Returns
    -------
    dict
        Mapping of ``"network"`` (or ``"network_3d"`` for 3-D graphs) and
        ``"edge_length_histogram"`` to their :class:`pathlib.Path` on disk.
    """
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    network_path = out / f"{prefix}_network.png"
    hist_path = out / f"{prefix}_edge_length_histogram.png"

    result = {"edge_length_histogram": hist_path}

    if sn.positions is not None and sn.positions.shape[1] == 3:
        p3 = out / f"{prefix}_network_3d.png"
        fig3 = plot_network_3d(sn, save=True, output_dir=out, filename=p3.name)
        fig2 = plot_edge_length_histogram(sn, save=True, output_dir=out, filename=hist_path.name)
        plt.close(fig3)
        plt.close(fig2)
        result['network_3d'] = p3
    else:
        fig1 = plot_network(sn, save=True, output_dir=out, filename=network_path.name)
        fig2 = plot_edge_length_histogram(sn, save=True, output_dir=out, filename=hist_path.name)
        plt.close(fig1)
        plt.close(fig2)
        result['network'] = network_path

    return result
