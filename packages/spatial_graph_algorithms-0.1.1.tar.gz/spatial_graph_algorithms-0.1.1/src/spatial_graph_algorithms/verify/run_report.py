"""End-to-end pipeline: simulate → visualise → reconstruct → evaluate → report."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.sparse.csgraph import connected_components, shortest_path

from spatial_graph_algorithms.metrics import degree_distribution, evaluate, graph_summary
from spatial_graph_algorithms.plot import plot_comparison, render_simulation_visualization_bundle
from spatial_graph_algorithms.reconstruct import reconstruct
from spatial_graph_algorithms.simulate import generate

from .config import VerifyConfig


def _run_id(cfg: VerifyConfig) -> str:
    return cfg.run_id or datetime.utcnow().strftime('%Y%m%d_%H%M%S')


def _shortest_path_stats(adjacency) -> dict:
    ncomp, labels = connected_components(adjacency, directed=False)
    largest = np.argmax(np.bincount(labels))
    idx = np.where(labels == largest)[0]
    sub = adjacency[idx][:, idx]
    D = shortest_path(sub, directed=False, unweighted=True)
    finite = D[np.isfinite(D)]
    finite = finite[finite > 0]
    if len(finite) == 0:
        return {"mean_sp": 0.0, "median_sp": 0.0, "max_sp": 0.0, "reachable_pairs": 0}
    return {
        "mean_sp": float(np.mean(finite)),
        "median_sp": float(np.median(finite)),
        "max_sp": float(np.max(finite)),
        "reachable_pairs": int(len(finite)),
    }


def _false_edge_stats(sn) -> dict:
    if sn.edge_metadata is None or 'is_false' not in sn.edge_metadata.columns:
        return {'false_edge_count': 0, 'false_edge_percent': 0.0, 'false_mean_len': 0.0, 'true_mean_len': 0.0}
    df = sn.edge_metadata.copy()
    p = sn.positions
    lens = []
    for s, t in df[['source', 'target']].to_numpy():
        lens.append(float(np.linalg.norm(p[int(s)] - p[int(t)])))
    df['length'] = lens
    false_df = df[df['is_false'] == True]  # noqa
    true_df = df[df['is_false'] == False]  # noqa
    total = max(1, len(df))
    return {
        'false_edge_count': int(len(false_df)),
        'false_edge_percent': float(len(false_df) / total),
        'false_mean_len': float(false_df['length'].mean()) if len(false_df) else 0.0,
        'true_mean_len': float(true_df['length'].mean()) if len(true_df) else 0.0,
    }


def run_report(*, simulation_kwargs: dict, config: VerifyConfig | None = None) -> dict:
    """Run a full simulation + analysis pipeline and write all artefacts to disk.

    Generates a synthetic graph, computes graph properties, optionally runs
    reconstruction and quality evaluation, and saves everything to a
    timestamped run directory.

    Parameters
    ----------
    simulation_kwargs : dict
        Keyword arguments forwarded to :func:`~spatial_graph_algorithms.simulate.generate`
        (e.g. ``n``, ``mode``, ``false_edges_fraction``, ``seed``).
    config : VerifyConfig, optional
        Pipeline configuration.  If ``None``, defaults are used.

    Returns
    -------
    dict
        A dictionary with keys:

        - ``"run_id"`` — string identifier for this run.
        - ``"run_dir"`` — :class:`pathlib.Path` to the output directory.
        - ``"report_file"`` — :class:`pathlib.Path` to ``report.csv``.

    Notes
    -----
    The following files are always written to ``run_dir``:

    - ``report.csv`` — graph properties + shortest-path stats + false-edge stats.
    - ``degree_distribution.csv`` — per-degree counts and proportions.
    - ``run_parameters.csv`` — the ``simulation_kwargs`` dict as a single row.
    - ``{prefix}_network.png`` — 2-D graph layout plot.
    - ``{prefix}_edge_length_histogram.png`` — edge-length distribution.

    When :attr:`~VerifyConfig.reconstruct_methods` is non-empty, these are also written:

    - ``reconstruction_quality.csv`` — CPD, KNN, distortion per method.
    - ``comparison_{method}.png`` — original vs reconstructed side-by-side.

    Examples
    --------
    >>> from spatial_graph_algorithms.verify import VerifyConfig, run_report
    >>> out = run_report(
    ...     simulation_kwargs=dict(n=300, mode="delaunay_corrected", seed=42),
    ...     config=VerifyConfig(
    ...         output_root="results/",
    ...         run_id="demo",
    ...         reconstruct_methods=["mds", "strnd"],
    ...     ),
    ... )
    >>> out["run_dir"].exists()
    True
    """
    cfg = config or VerifyConfig()
    rid = _run_id(cfg)
    run_dir = Path(cfg.output_root) / rid
    run_dir.mkdir(parents=True, exist_ok=True)

    sn = generate(**simulation_kwargs)

    viz_paths = render_simulation_visualization_bundle(sn, output_dir=run_dir, prefix=cfg.prefix)

    deg = degree_distribution(sn)
    deg_df = pd.DataFrame({
        'degree': list(deg['counts'].keys()),
        'count': list(deg['counts'].values()),
        'proportion': [deg['proportions'][k] for k in deg['counts'].keys()],
    }).sort_values('degree')
    deg_df.to_csv(run_dir / 'degree_distribution.csv', index=False)

    gsum = graph_summary(sn)
    sp = _shortest_path_stats(sn.adjacency_matrix)
    fst = _false_edge_stats(sn)

    params_path = run_dir / 'run_parameters.csv'
    pd.DataFrame([simulation_kwargs]).to_csv(params_path, index=False)

    report_row = {
        'run_id': rid,
        'params_file': str(params_path),
        **gsum,
        **sp,
        **fst,
        'network_plot': str(viz_paths.get('network', viz_paths.get('network_3d', ''))),
        'edge_length_histogram_plot': str(viz_paths['edge_length_histogram']),
    }

    recon_rows = []
    for method in cfg.reconstruct_methods:
        snr = reconstruct(sn, method=method, dim=simulation_kwargs.get('dim', 2), seed=simulation_kwargs.get('seed'))
        if sn.positions is None or snr.reconstructed_positions is None:
            continue

        quality = evaluate(snr, compute_distortion=True)
        recon_rows.append({
            'method': method,
            'cpd': quality['cpd'],
            'knn': quality['knn'],
            'distortion': quality['distortion'],
        })

        if sn.positions.shape[1] == 2:
            comp_filename = f"comparison_{method}.png"
            try:
                fig = plot_comparison(snr, save=True, output_dir=run_dir, filename=comp_filename)
                import matplotlib.pyplot as plt
                plt.close(fig)
            except Exception:
                pass

    if recon_rows:
        recon_path = run_dir / 'reconstruction_quality.csv'
        pd.DataFrame(recon_rows).to_csv(recon_path, index=False)
        report_row['reconstruction_quality_file'] = str(recon_path)

    report_path = run_dir / 'report.csv'
    pd.DataFrame([report_row]).to_csv(report_path, index=False)

    return {'run_id': rid, 'run_dir': run_dir, 'report_file': report_path}
