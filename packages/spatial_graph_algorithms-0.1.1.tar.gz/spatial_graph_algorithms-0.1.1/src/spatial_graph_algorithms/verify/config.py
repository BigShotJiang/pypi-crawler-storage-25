"""Configuration dataclass for the verify pipeline."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class VerifyConfig:
    """Configuration for :func:`~spatial_graph_algorithms.verify.run_report`.

    Parameters
    ----------
    output_root : Path
        Root directory under which a subdirectory named *run_id* is created
        for all output artefacts.  Default is
        ``".planning/artifacts/verification_runs"``.
    run_id : str, optional
        Identifier for this run.  If ``None``, a UTC timestamp is used
        (``YYYYMMDD_HHMMSS``).
    prefix : str
        Filename prefix for generated plots.  Default is ``"verify"``.
    reconstruct_methods : list of str
        Reconstruction methods to run.  Each element must be a valid method
        name accepted by :func:`~spatial_graph_algorithms.reconstruct.reconstruct`
        (e.g. ``["mds", "strnd"]``).  An empty list skips reconstruction.

    Examples
    --------
    >>> from spatial_graph_algorithms.verify import VerifyConfig
    >>> cfg = VerifyConfig(
    ...     output_root="results/",
    ...     run_id="experiment_01",
    ...     reconstruct_methods=["mds", "strnd"],
    ... )
    """

    output_root: Path = Path(".planning/artifacts/verification_runs")
    run_id: Optional[str] = None
    prefix: str = "verify"
    reconstruct_methods: list[str] = field(default_factory=list)
