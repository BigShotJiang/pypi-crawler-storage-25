"""STRND reconstruction: Node2Vec embeddings (pecanpy) → UMAP.

Requires the ``[strnd]`` optional dependencies:
``pip install "spatial_graph_algorithms[strnd]"``
"""

from __future__ import annotations

import os
import tempfile

import numpy as np
import pandas as pd
import scipy.sparse


def _ensure_strnd_deps():
    """Raise a clear ImportError if the [strnd] extras are not installed."""
    try:
        import scipy.linalg  # noqa: F401
        if not hasattr(scipy.linalg, "triu"):
            # scipy.linalg.triu removed in newer scipy; gensim still imports it
            scipy.linalg.triu = np.triu
        from pecanpy import pecanpy  # noqa: F401
        import umap as _umap  # noqa: F401
        import sklearn.utils.validation as _skval
        import sklearn.utils as _skutils
        # umap 0.5.x passes force_all_finite which was renamed in sklearn 1.6+
        _orig = _skval.check_array
        def _compat(*args, **kwargs):
            kwargs.pop("force_all_finite", None)
            return _orig(*args, **kwargs)
        _skval.check_array = _compat
        _skutils.check_array = _compat
        import umap.umap_ as _umap_module
        _umap_module.check_array = _compat
    except ImportError as exc:
        raise ImportError(
            "STRND reconstruction requires optional dependencies. "
            'Install them with: pip install "spatial_graph_algorithms[strnd]"'
        ) from exc


def _adjacency_to_edge_df(adjacency: scipy.sparse.spmatrix) -> pd.DataFrame:
    coo = adjacency.tocoo()
    mask = coo.row < coo.col  # unique undirected edges only
    return pd.DataFrame({
        "source": coo.row[mask].astype(int),
        "target": coo.col[mask].astype(int),
    })


def _pecanpy_embeddings(
    edge_df: pd.DataFrame,
    embedding_dim: int,
    p: float,
    q: float,
    workers: int,
    verbose: bool,
) -> np.ndarray:
    """Port of NSC compute_pecanpy_embeddings_from_df using PreComp mode."""
    from pecanpy import pecanpy as _pecanpy

    with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False) as tmp:
        temp_filename = tmp.name
        edge_df[["source", "target"]].to_csv(temp_filename, index=False, header=False)

    try:
        g = _pecanpy.PreComp(p=p, q=q, workers=workers, verbose=verbose)
        g.read_edg(temp_filename, weighted=False, directed=False, delimiter=",")
        g.preprocess_transition_probs()
        raw_embeddings = g.embed(dim=embedding_dim)

        # g.nodes may not be in 0..N-1 order — reorder so row i = node i
        idx_to_id = {idx: int(node_id) for idx, node_id in enumerate(g.nodes)}
        reordered = np.empty_like(raw_embeddings)
        for idx, emb in enumerate(raw_embeddings):
            reordered[idx_to_id[idx]] = emb
    finally:
        os.remove(temp_filename)

    return reordered


def run_strnd(
    adjacency: scipy.sparse.spmatrix,
    dim: int = 2,
    random_state: int | None = None,
    embedding_dim: int = 64,
    p: float = 1.0,
    q: float = 1.0,
    workers: int = 4,
    umap_n_neighbors: int = 15,
    umap_min_dist: float = 1.0,
    verbose: bool = False,
) -> np.ndarray:
    """Reconstruct coordinates using STRND: Node2Vec embeddings → UMAP.

    This is an exact port of the NSC ``compute_pecanpy_embeddings_from_df`` +
    UMAP pipeline.  Node2Vec biased random walks are computed by pecanpy's
    ``PreComp`` mode, producing a high-dimensional embedding which is then
    reduced to *dim* dimensions by UMAP.

    .. note::
       Requires ``pip install "spatial_graph_algorithms[strnd]"``.

       Two runtime compatibility shims are applied on first call:

       * ``scipy.linalg.triu`` is restored for gensim/pecanpy (removed in
         newer scipy).
       * sklearn's ``check_array`` ``force_all_finite`` argument is silently
         dropped (renamed ``ensure_all_finite`` in sklearn 1.6+).

    Parameters
    ----------
    adjacency : scipy.sparse matrix
        Symmetric, unweighted adjacency matrix.
    dim : int
        Number of output dimensions.  Default is 2.
    random_state : int, optional
        Seed for UMAP.
    embedding_dim : int
        Dimensionality of the Node2Vec embedding before UMAP reduction.
        Default is 64 (matches NSC defaults).
    p : float
        Node2Vec return parameter.  ``p=1`` (default) gives unbiased walks.
    q : float
        Node2Vec in-out parameter.  ``q=1`` (default) gives unbiased walks.
    workers : int
        Number of worker threads for pecanpy.  Default is 4.
    umap_n_neighbors : int
        UMAP ``n_neighbors`` parameter.  Default is 15.
    umap_min_dist : float
        UMAP ``min_dist`` parameter.  Default is 1.0 (preserves global
        structure over local clustering).
    verbose : bool
        If ``True``, pecanpy prints timing information.

    Returns
    -------
    np.ndarray
        Float array of shape ``(n, dim)`` with the embedded coordinates.

    Raises
    ------
    ImportError
        If ``pecanpy`` or ``umap-learn`` are not installed.

    Examples
    --------
    >>> from spatial_graph_algorithms.simulate import generate
    >>> from spatial_graph_algorithms.reconstruct.strnd import run_strnd
    >>> sn = generate(n=200, seed=0)
    >>> coords = run_strnd(sn.adjacency_matrix, dim=2, random_state=0)
    >>> coords.shape
    (200, 2)
    """
    _ensure_strnd_deps()
    import umap as _umap

    edge_df = _adjacency_to_edge_df(adjacency)
    embeddings = _pecanpy_embeddings(
        edge_df,
        embedding_dim=embedding_dim,
        p=p,
        q=q,
        workers=workers,
        verbose=verbose,
    )
    reducer = _umap.UMAP(
        n_components=dim,
        n_neighbors=umap_n_neighbors,
        min_dist=umap_min_dist,
        random_state=random_state,
    )
    return reducer.fit_transform(embeddings)
