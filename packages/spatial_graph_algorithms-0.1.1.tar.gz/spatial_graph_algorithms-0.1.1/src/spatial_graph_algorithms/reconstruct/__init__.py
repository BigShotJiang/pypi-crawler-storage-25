"""Spatial coordinate reconstruction from graph topology.

Given only the edge structure, these methods recover 2-D or 3-D node
coordinates that approximate the original spatial layout.

Available methods
-----------------
mds
    Classical MDS on all-pairs shortest-path distances.
strnd
    Node2Vec graph embeddings (pecanpy PreComp) reduced by UMAP.
    Exact port of the NSC pipeline.  Requires the ``[strnd]`` extras.
"""

from __future__ import annotations

from spatial_graph_algorithms.network import SpatialGraph

from .mds import run_mds
from .strnd import run_strnd


def reconstruct(
    sn: SpatialGraph,
    method: str = "mds",
    dim: int = 2,
    seed: int | None = None,
) -> SpatialGraph:
    """Reconstruct node coordinates from graph topology.

    Returns a copy of *sn* with :attr:`~spatial_graph_algorithms.network.SpatialGraph.reconstructed_positions`
    set.  The original *sn* is never modified.

    Parameters
    ----------
    sn : SpatialGraph
        Input graph.  Only the adjacency matrix is used; positions are not
        required (they are used only for quality evaluation afterwards).
    method : str
        Reconstruction algorithm.  One of:

        - ``"mds"`` — Metric MDS on shortest-path distances.  Fast; no extra
          dependencies.
        - ``"strnd"`` — Node2Vec (pecanpy) embeddings → UMAP.  Higher quality;
          requires ``pip install "spatial_graph_algorithms[strnd]"``.

    dim : int
        Target number of output dimensions (2 or 3).
    seed : int, optional
        Random seed for reproducibility.

    Returns
    -------
    SpatialGraph
        Deep copy of *sn* with *reconstructed_positions* of shape
        ``(n_nodes, dim)``.

    Raises
    ------
    ValueError
        If *method* is not one of the supported values.

    Examples
    --------
    >>> from spatial_graph_algorithms.simulate import generate
    >>> from spatial_graph_algorithms.reconstruct import reconstruct
    >>> sn = generate(n=300, seed=42)
    >>> sn_rec = reconstruct(sn, method="mds", dim=2, seed=42)
    >>> sn_rec.reconstructed_positions.shape
    (300, 2)
    """
    method = method.lower()
    if method == "mds":
        coords = run_mds(sn.adjacency_matrix, dim=dim, random_state=seed)
    elif method == "strnd":
        coords = run_strnd(sn.adjacency_matrix, dim=dim, random_state=seed)
    else:
        raise ValueError(f"Unsupported reconstruction method '{method}'")

    sn2 = sn.copy()
    sn2.reconstructed_positions = coords
    return sn2


__all__ = ["reconstruct"]
