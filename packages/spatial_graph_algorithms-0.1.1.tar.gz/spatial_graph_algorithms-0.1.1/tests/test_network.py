"""RED/GREEN contract tests for SpatialGraph behavior (Phase 1)."""

import warnings

import networkx as nx
import numpy as np
import pandas as pd
import pytest
import scipy.sparse

from spatial_graph_algorithms import SpatialGraph
from spatial_graph_algorithms.network import to_igraph


def test_from_edge_list(small_edge_csv):
    sn = SpatialGraph.from_edge_list(small_edge_csv)
    assert isinstance(sn, SpatialGraph)
    assert sn.adjacency_matrix.shape == (4, 4)
    assert sn.adjacency_matrix.nnz >= 4
    assert len(sn.node_id_map) == 4


def test_from_edge_list_df(small_edge_df):
    sn = SpatialGraph.from_edge_list(small_edge_df)
    assert sn.adjacency_matrix.shape == (4, 4)
    assert len(sn.node_id_map) == 4


def test_from_positions(small_positions_csv):
    sn = SpatialGraph.from_positions(small_positions_csv)
    assert sn.positions.shape == (4, 2)
    assert sn.adjacency_matrix.shape == (4, 4)
    assert sn.adjacency_matrix.nnz == 0


def test_fields(small_edge_df):
    sn = SpatialGraph.from_edge_list(small_edge_df, keep_lcc=False)
    assert hasattr(sn, "adjacency_matrix")
    assert hasattr(sn, "positions")
    assert hasattr(sn, "reconstructed_positions")
    assert hasattr(sn, "node_metadata")
    assert hasattr(sn, "edge_metadata")
    assert hasattr(sn, "node_id_map")
    assert hasattr(sn, "keep_lcc")
    assert hasattr(sn, "_nx_cache")
    assert sn.reconstructed_positions is None
    assert sn.node_metadata is None
    assert sn.edge_metadata is None


def test_lcc_extraction(small_disconnected_adj):
    with pytest.warns(UserWarning, match="connected components"):
        sn = SpatialGraph(adjacency_matrix=small_disconnected_adj, keep_lcc=True)
    assert sn.adjacency_matrix.shape == (3, 3)


def test_shape_validation():
    adj = scipy.sparse.eye(3, format="csr")
    pos = np.zeros((5, 2))
    with pytest.raises(ValueError):
        SpatialGraph(adjacency_matrix=adj, positions=pos)


def test_graph_property(small_edge_df):
    sn = SpatialGraph.from_edge_list(small_edge_df, keep_lcc=False)
    assert isinstance(sn.graph, nx.Graph)
    assert sn.graph.number_of_nodes() == 4
    assert sn.graph.number_of_edges() == 4


def test_to_igraph(small_edge_df):
    sn = SpatialGraph.from_edge_list(small_edge_df, keep_lcc=False)
    g = to_igraph(sn)
    assert g.vcount() == 4
    assert g.ecount() == 4


def test_to_edge_df(small_edge_df):
    sn = SpatialGraph.from_edge_list(small_edge_df, keep_lcc=False)
    df = sn.to_edge_dataframe()
    assert isinstance(df, pd.DataFrame)
    assert list(df.columns) == ["source", "target"]
    assert len(df) == 4


def test_to_positions_df(small_edge_df, small_positions_array):
    sn = SpatialGraph.from_edge_list(small_edge_df, keep_lcc=False)
    sn.positions = small_positions_array
    df = sn.to_positions_dataframe()
    assert isinstance(df, pd.DataFrame)
    assert len(df) == 4
    assert set(["x", "y"]).issubset(df.columns)


def test_copy_independence(small_edge_df):
    sn = SpatialGraph.from_edge_list(small_edge_df, keep_lcc=False)
    _ = sn.graph
    sn2 = sn.copy()
    assert sn2._nx_cache is None
    assert sn2.adjacency_matrix is not sn.adjacency_matrix


def test_cache_invalidation(small_edge_df):
    sn = SpatialGraph.from_edge_list(small_edge_df, keep_lcc=False)
    _ = sn.graph
    assert sn._nx_cache is not None

    new_adj = scipy.sparse.eye(4, format="csr")
    sn.adjacency_matrix = new_adj
    assert sn._nx_cache is None

    g = sn.graph
    assert isinstance(g, nx.Graph)
    assert g.number_of_nodes() == 4
    assert g.number_of_edges() == 0

