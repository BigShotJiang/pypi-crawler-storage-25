from pathlib import Path

import pandas as pd

from spatial_graph_algorithms.verify import VerifyConfig, run_report


def test_run_report_creates_csv_and_png_bundle(tmp_path):
    cfg = VerifyConfig(output_root=tmp_path, run_id='run1')
    out = run_report(
        simulation_kwargs=dict(n=120, dim=2, shape='square', mode='knn', k=5, false_edges_number=6, seed=7),
        config=cfg,
    )
    run_dir = out['run_dir']
    assert (run_dir / 'report.csv').exists()
    assert (run_dir / 'degree_distribution.csv').exists()
    assert (run_dir / 'run_parameters.csv').exists()
    assert (run_dir / 'verify_network.png').exists()
    assert (run_dir / 'verify_edge_length_histogram.png').exists()

    report = pd.read_csv(run_dir / 'report.csv')
    for c in ['run_id', 'mean_sp', 'false_edge_count', 'network_plot', 'params_file']:
        assert c in report.columns


def test_run_report_with_reconstruction_outputs_quality_csv(tmp_path):
    cfg = VerifyConfig(output_root=tmp_path, run_id='run2', reconstruct_methods=['mds', 'strnd'])
    out = run_report(
        simulation_kwargs=dict(n=100, dim=2, shape='circle', mode='delaunay_corrected', seed=3),
        config=cfg,
    )
    q = out['run_dir'] / 'reconstruction_quality.csv'
    assert q.exists()
    df = pd.read_csv(q)
    assert set(df['method']) == {'mds', 'strnd'}
