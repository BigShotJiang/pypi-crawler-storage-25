import matplotlib.figure

from spatial_graph_algorithms.plot import (
    DEFAULT_VISUALIZATION_DIR,
    plot_edge_length_histogram,
    plot_network,
    render_simulation_visualization_bundle,
)
from spatial_graph_algorithms.simulate import generate


def test_plot_network_returns_figure():
    sn = generate(n=100, dim=2, shape="square", mode="knn", k=5, seed=10)
    fig = plot_network(sn)
    assert isinstance(fig, matplotlib.figure.Figure)


def test_plot_network_false_edge_styling_path_runs():
    sn = generate(
        n=100,
        dim=2,
        shape="square",
        mode="knn",
        k=5,
        false_edges_number=8,
        seed=10,
    )
    fig = plot_network(sn)
    assert isinstance(fig, matplotlib.figure.Figure)
    assert sn.edge_metadata is not None
    assert int(sn.edge_metadata["is_false"].sum()) > 0


def test_plot_edge_length_histogram_returns_figure():
    sn = generate(n=120, dim=2, shape="circle", mode="delaunay", seed=12)
    fig = plot_edge_length_histogram(sn, bins=20)
    assert isinstance(fig, matplotlib.figure.Figure)


def test_visualization_bundle_saves_output_files(tmp_path):
    sn = generate(n=90, dim=2, shape="square", mode="knn", k=4, false_edges_number=5, seed=99)
    paths = render_simulation_visualization_bundle(sn, output_dir=tmp_path, prefix="uat")
    assert paths["network"].exists()
    assert paths["edge_length_histogram"].exists()


def test_default_output_dir_constant():
    assert str(DEFAULT_VISUALIZATION_DIR).endswith(".planning/artifacts/visualizations")
