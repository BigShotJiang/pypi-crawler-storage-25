import pytest

from spatial_graph_algorithms.metrics import graph_summary
from spatial_graph_algorithms.simulate import generate


def test_knn_k_parameter_affects_mean_degree():
    sn_k2 = generate(n=140, dim=2, shape="square", mode="knn", k=2, seed=20)
    sn_k8 = generate(n=140, dim=2, shape="square", mode="knn", k=8, seed=20)

    mean2 = graph_summary(sn_k2)["mean_degree"]
    mean8 = graph_summary(sn_k8)["mean_degree"]
    assert mean8 > mean2


def test_mode_parameter_mismatch_fails_clearly():
    with pytest.raises(ValueError):
        generate(n=100, dim=2, shape="square", mode="knn", k=0, seed=1)
    with pytest.raises(ValueError):
        generate(n=100, dim=2, shape="square", mode="epsilon", epsilon=0.0, seed=1)
