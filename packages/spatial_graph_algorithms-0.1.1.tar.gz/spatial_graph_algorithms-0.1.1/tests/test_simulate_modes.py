import pytest

from spatial_graph_algorithms.simulate import generate


@pytest.mark.parametrize(
    "mode,kwargs",
    [
        ("knn", {"k": 6}),
        ("epsilon", {"epsilon": 0.3}),
        ("delaunay", {}),
        ("delaunay_corrected", {}),
        ("distance_decay", {"quantile_scale": 0.1}),
        ("knn_bipartite", {"k": 4, "bipartite_ratio": 2}),
        ("epsilon_bipartite", {"epsilon": 0.25, "bipartite_ratio": 2}),
        ("lattice", {}),
    ],
)
def test_mode_returns_valid_graph(mode, kwargs):
    sn = generate(n=120, dim=2, shape="square", mode=mode, seed=5, **kwargs)
    assert sn.adjacency_matrix.shape == (120, 120)
    assert sn.adjacency_matrix.nnz > 0


def test_epsilon_ball_alias_supported():
    sn = generate(n=100, dim=2, shape="square", mode="epsilon-ball", epsilon=0.25, seed=12)
    assert sn.adjacency_matrix.nnz > 0
