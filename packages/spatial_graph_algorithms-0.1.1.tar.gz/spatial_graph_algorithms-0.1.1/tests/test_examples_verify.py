from pathlib import Path

from spatial_graph_algorithms.verify import VerifyConfig, run_report


def test_example_like_run_creates_expected_artifacts(tmp_path):
    cfg = VerifyConfig(output_root=tmp_path, run_id='ex', reconstruct_methods=['mds', 'strnd'])
    out = run_report(
        simulation_kwargs={
            'n': 120,
            'dim': 2,
            'shape': 'circle',
            'mode': 'knn',
            'k': 6,
            'seed': 42,
            'false_edges_number': 6,
        },
        config=cfg,
    )
    rd = out['run_dir']
    for fname in ['report.csv', 'degree_distribution.csv', 'run_parameters.csv', 'reconstruction_quality.csv']:
        assert (rd / fname).exists()
