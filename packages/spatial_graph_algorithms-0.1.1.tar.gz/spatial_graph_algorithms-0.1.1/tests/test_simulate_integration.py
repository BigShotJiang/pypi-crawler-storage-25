from spatial_graph_algorithms import SpatialGraph
from spatial_graph_algorithms.simulate import generate


def test_roadmap_reference_call_returns_spatialnetwork():
    sn = generate(n=1000, dim=2, shape="circle", mode="delaunay_corrected", seed=1)
    assert isinstance(sn, SpatialGraph)
    assert sn.positions is not None
    assert sn.adjacency_matrix.nnz > 0


def test_all_required_modes_smoke():
    modes = [
        "knn",
        "epsilon",
        "delaunay",
        "delaunay_corrected",
        "distance_decay",
        "knn_bipartite",
        "epsilon_bipartite",
        "lattice",
    ]
    for mode in modes:
        kwargs = {"epsilon": 0.25} if "epsilon" in mode else {}
        kwargs.update({"k": 4} if "knn" in mode else {})
        sn = generate(n=120, dim=2, shape="square", mode=mode, seed=2, **kwargs)
        assert sn.adjacency_matrix.shape == (120, 120)


def test_3d_generation_works_for_sphere_and_cube():
    sphere = generate(n=100, dim=3, shape="sphere", mode="knn", seed=3)
    cube = generate(n=100, dim=3, shape="cube", mode="knn", seed=3)
    assert sphere.positions.shape == (100, 3)
    assert cube.positions.shape == (100, 3)
