from spatial_graph_algorithms.metrics import degree_sequence, degree_distribution, graph_summary
from spatial_graph_algorithms.simulate import generate


def test_degree_sequence_and_distribution_shapes():
    sn = generate(n=90, dim=2, shape="square", mode="knn", k=4, seed=7)
    seq = degree_sequence(sn)
    dist = degree_distribution(sn)

    assert len(seq) == 90
    assert isinstance(dist["counts"], dict)
    assert isinstance(dist["proportions"], dict)
    assert abs(sum(dist["proportions"].values()) - 1.0) < 1e-9


def test_graph_summary_fields():
    sn = generate(n=100, dim=2, shape="square", mode="epsilon", epsilon=0.25, seed=8)
    summary = graph_summary(sn)
    for k in ["n_nodes", "n_edges", "min_degree", "max_degree", "mean_degree", "density"]:
        assert k in summary
    assert summary["n_nodes"] == 100
    assert summary["n_edges"] > 0
