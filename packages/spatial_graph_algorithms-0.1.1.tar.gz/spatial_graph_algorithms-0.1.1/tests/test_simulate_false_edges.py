import pytest

from spatial_graph_algorithms.simulate import generate


def test_false_edge_fraction_injection_metadata():
    sn = generate(
        n=80,
        dim=2,
        shape="square",
        mode="knn",
        k=4,
        false_edges_fraction=0.2,
        seed=11,
    )
    edge_meta = sn.edge_metadata
    assert "is_false" in edge_meta.columns
    assert "edge_id" in edge_meta.columns
    assert int(edge_meta["is_false"].sum()) > 0


def test_false_edge_number_conflict_rejected():
    with pytest.raises(ValueError):
        generate(
            n=50,
            dim=2,
            shape="square",
            mode="knn",
            false_edges_number=3,
            false_edges_fraction=0.1,
        )


def test_bipartite_false_edge_cap_enforced():
    with pytest.raises(ValueError):
        generate(
            n=20,
            dim=2,
            shape="square",
            mode="knn_bipartite",
            k=1,
            bipartite_ratio=2,
            false_edges_number=500,
            seed=9,
        )


def test_deterministic_false_edge_selection_with_seed():
    a = generate(
        n=70,
        dim=2,
        shape="square",
        mode="knn",
        false_edges_number=10,
        seed=42,
    )
    b = generate(
        n=70,
        dim=2,
        shape="square",
        mode="knn",
        false_edges_number=10,
        seed=42,
    )
    a_false = set(map(tuple, a.edge_metadata.loc[a.edge_metadata["is_false"], ["source", "target"]].to_numpy()))
    b_false = set(map(tuple, b.edge_metadata.loc[b.edge_metadata["is_false"], ["source", "target"]].to_numpy()))
    assert a_false == b_false
