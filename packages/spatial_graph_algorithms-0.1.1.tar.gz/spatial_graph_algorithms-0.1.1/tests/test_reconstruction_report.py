from spatial_graph_algorithms.simulate import generate
from spatial_graph_algorithms.reconstruct import reconstruct


def test_reconstruct_supports_mds_and_strnd():
    sn = generate(n=80, dim=2, shape='square', mode='knn', k=4, seed=4)
    mds = reconstruct(sn, method='mds', dim=2, seed=1)
    strnd = reconstruct(sn, method='strnd', dim=2, seed=1)
    assert mds.reconstructed_positions.shape == (80, 2)
    assert strnd.reconstructed_positions.shape == (80, 2)
