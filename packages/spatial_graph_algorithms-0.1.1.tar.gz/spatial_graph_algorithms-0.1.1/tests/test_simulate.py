import numpy as np
import pytest
from PIL import Image, ImageDraw

from spatial_graph_algorithms import SpatialGraph
from spatial_graph_algorithms.simulate import generate


def _make_test_image(path: str) -> None:
    img = Image.new("1", (32, 32), color=1)
    draw = ImageDraw.Draw(img)
    draw.rectangle((8, 8, 24, 24), fill=0)
    img.save(path)


def test_generate_square_2d_shape_and_output_type():
    sn = generate(n=128, dim=2, shape="square", mode="knn", seed=7)
    assert isinstance(sn, SpatialGraph)
    assert sn.positions.shape == (128, 2)


def test_generate_cube_3d_shape():
    sn = generate(n=100, dim=3, shape="cube", mode="knn", seed=7)
    assert sn.positions.shape == (100, 3)


def test_generate_circle_2d_shape():
    sn = generate(n=80, dim=2, shape="circle", mode="delaunay", seed=3)
    assert sn.positions.shape == (80, 2)


def test_generate_sphere_3d_shape():
    sn = generate(n=80, dim=3, shape="sphere", mode="knn", seed=3)
    assert sn.positions.shape == (80, 3)


def test_image_mode_2d(tmp_path):
    image_path = tmp_path / "shape.png"
    _make_test_image(str(image_path))
    sn = generate(n=60, dim=2, shape="image_2d", mode="knn", image_path=str(image_path), seed=13)
    assert sn.positions.shape == (60, 2)


def test_seed_determinism():
    a = generate(n=64, dim=2, shape="square", mode="knn", seed=123)
    b = generate(n=64, dim=2, shape="square", mode="knn", seed=123)
    assert np.allclose(a.positions, b.positions)
    assert (a.adjacency_matrix != b.adjacency_matrix).nnz == 0


def test_validation_errors():
    with pytest.raises(ValueError):
        generate(n=1)
    with pytest.raises(ValueError):
        generate(n=20, dim=4)
    with pytest.raises(ValueError):
        generate(n=20, mode="unknown")
    with pytest.raises(ValueError):
        generate(n=20, shape="image_2d", dim=2, mode="knn")
