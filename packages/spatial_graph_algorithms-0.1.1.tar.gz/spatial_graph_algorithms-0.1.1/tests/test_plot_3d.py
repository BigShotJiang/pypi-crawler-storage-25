import matplotlib.figure

from spatial_graph_algorithms.plot import plot_network_3d, render_simulation_visualization_bundle
from spatial_graph_algorithms.simulate import generate


def test_plot_network_3d_returns_figure():
    sn = generate(n=80, dim=3, shape='sphere', mode='knn', k=4, seed=22)
    fig = plot_network_3d(sn)
    assert isinstance(fig, matplotlib.figure.Figure)


def test_bundle_includes_3d_plot_for_3d_positions(tmp_path):
    sn = generate(n=80, dim=3, shape='cube', mode='knn', k=4, seed=22)
    out = render_simulation_visualization_bundle(sn, output_dir=tmp_path, prefix='three_d')
    assert 'network_3d' in out
    assert out['network_3d'].exists()
