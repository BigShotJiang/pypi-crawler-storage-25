from __future__ import annotations

import re
from pathlib import Path
from typing import List, Tuple

from triclick_doc_toolset.common import TableItem
from triclick_doc_toolset.common.utils import (
    load_footnote_patterns,
    load_label_patterns,
    load_title_patterns,
)
from triclick_doc_toolset.common.word.docx_file_parse_util import extract_title_label

from .rtf_text_util import rtf_to_plain_lines

"""RTF parsing — produce one TableItem per logical table.

Title-anchored approach: convert the RTF body to plain text, find every line
that matches a configured title pattern (Table N.N.N / Listing / Figure),
treat each match as the start of an independent logical table. The text
between consecutive titles (with binary blobs stripped) is that table's
footnote region.

Why title-anchored, not table-block-anchored:
    RTF uses ``\\trowd...\\row`` for individual table ROWS, not entire tables.
    A single CDISC document with 6 tables typically contains hundreds of
    ``\\trowd`` blocks (rows + page-header rows + nested table rows). Anchoring
    on ``\\trowd`` boundaries can never recover the logical table boundary.
    The DOCX equivalent (``docx_file_parse_util``) does the same anchoring
    against heading-styled paragraphs.

Invariants this implementation upholds:
    * One TableItem per unique section ID — page-header repeats deduped.
    * Every returned TableItem has a non-empty ``section`` containing at
      least one digit (avoids false positives like ``"table of authorities"``
      from RTF stylesheet declarations).
    * Footnote text never contains hex-encoded RTF binary objects.
"""

TITLE_PATTERNS: List[re.Pattern] = load_title_patterns()
LABEL_PATTERNS: List[re.Pattern] = load_label_patterns()
FOOTNOTE_PATTERNS: List[re.Pattern] = load_footnote_patterns()

# RTF \object blocks (embedded OLE artifacts — typically Office files) survive
# rtf_to_plain as long unbroken hex strings. Any line that's 80+ characters of
# pure hex is treated as binary noise and excluded from footnote text.
_BINARY_HEX_RE = re.compile(r"^[0-9a-fA-F]{80,}$")

# Lines >100 chars OR matching a known same-as pattern are footnote candidates
# — preserves the heuristic from the previous implementation.
_FOOTNOTE_LONG_LINE_THRESHOLD = 100


def extract_rtf_content_with_metadata(rtf_path: str) -> List[TableItem]:
    """Parse a single RTF file into a list of TableItems, one per logical table.

    Returns ``[]`` when no title pattern matches anywhere in the document — a
    document without recognizable table titles produces no partition rows
    downstream, which is the correct outcome.

    Args:
        rtf_path: Filesystem path to the RTF file.

    Returns:
        One TableItem per unique section ID encountered, in document order.
    """
    raw = Path(rtf_path).read_text(encoding="utf-8", errors="ignore")
    lines = rtf_to_plain_lines(raw)

    candidates = _scan_title_candidates(lines)
    if not candidates:
        return []

    deduped = _dedupe_by_section(candidates)
    return _build_table_items(deduped, lines)


def _scan_title_candidates(lines: List[str]) -> List[Tuple[int, str, str, str]]:
    """Find every line that looks like a real table title.

    Returns a list of ``(line_index, line_text, label, section)`` tuples in
    document order. False positives (lines that match a title pattern but
    have no digit in their section — e.g., ``"table of authorities"``) are
    excluded here so downstream consumers never see them.
    """
    candidates: List[Tuple[int, str, str, str]] = []
    for i, ln in enumerate(lines):
        text = (ln or "").strip()
        if not text:
            continue
        if not any(p.match(text) for p in TITLE_PATTERNS):
            continue

        label = extract_title_label(text)
        if not label:
            continue

        # Section ID = the bit after the "Table"/"Listing"/"Figure" keyword.
        # Mirrors the DOCX parser's derivation so partition IDs match across
        # input formats (see docx_file_parse_util).
        parts = label.split(None, 1)
        section = (parts[1] if len(parts) == 2 else parts[0]).strip()

        if not _is_real_section(section):
            continue

        candidates.append((i, text, label, section))

    return candidates


def _is_real_section(section: str) -> bool:
    """A real CDISC section ID contains at least one digit.

    Filters false positives where the title regex catches RTF stylesheet
    declarations like ``"table of authorities;   macro;   toa heading"`` —
    those produce a section like ``"of"`` which has no digits.
    """
    return bool(section) and any(ch.isdigit() for ch in section)


def _dedupe_by_section(
    candidates: List[Tuple[int, str, str, str]],
) -> List[Tuple[int, str, str, str]]:
    """Keep only the first occurrence of each section ID.

    Multi-page tables repeat their title in the page header on every page.
    Without dedup we'd create one PartitionNode per page rather than per
    table. Dedup must happen before ``normalize_duplicate_labels_rule`` runs
    (in ``RtfFileParseCommand``) — that rule would otherwise treat the
    repeats as distinct tables and suffix them ``.1``, ``.2`` etc.
    """
    seen: set = set()
    deduped: List[Tuple[int, str, str, str]] = []
    for c in candidates:
        section = c[3]
        if section in seen:
            continue
        seen.add(section)
        deduped.append(c)
    return deduped


def _build_table_items(
    deduped: List[Tuple[int, str, str, str]],
    lines: List[str],
) -> List[TableItem]:
    """Construct one TableItem per deduped title, collecting footnote text
    from the lines between this title and the next (or end of document)."""
    items: List[TableItem] = []
    for idx, (line_idx, text, label, section) in enumerate(deduped):
        next_line_idx = deduped[idx + 1][0] if idx + 1 < len(deduped) else len(lines)

        footnote_indices: List[int] = []
        footnote_parts: List[str] = []
        for j in range(line_idx + 1, next_line_idx):
            ft = (lines[j] or "").strip()
            if not ft:
                continue
            if _looks_like_binary_blob(ft):
                continue
            if any(p.search(ft) for p in FOOTNOTE_PATTERNS) or len(ft) > _FOOTNOTE_LONG_LINE_THRESHOLD:
                footnote_indices.append(j)
                footnote_parts.append(ft)

        item = TableItem(
            label=label,
            section=section,
            title=text,
            level=section.count("."),
            title_indices=[line_idx],
            footnote_indices=footnote_indices,
        )
        item.set_table(idx)
        for ft in footnote_parts:
            item.append_footnote_text(ft)
        items.append(item)

    return items


def _looks_like_binary_blob(text: str) -> bool:
    """True for lines that are RTF embedded-object hex (e.g., OLE artifacts).

    Without this filter, the customer-facing footnote field can leak the raw
    bytes of an embedded Office document — the bug that motivated this
    rewrite stored a ZIP file's hex into ``partition.content_preview``.
    """
    return bool(_BINARY_HEX_RE.match(text))
