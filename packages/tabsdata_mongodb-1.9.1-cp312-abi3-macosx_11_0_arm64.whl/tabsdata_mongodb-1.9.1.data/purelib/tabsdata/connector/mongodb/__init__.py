#
# Copyright 2025 Tabs Data Inc.
#

import importlib.metadata

from tabsdata.connector.mongodb._connector import MongoDBDestination

__all__ = ["MongoDBDestination"]

# noinspection PyBroadException
try:
    __version__ = importlib.metadata.version("tabsdata-mongodb")
except Exception:
    __version__ = "unknown"

version = __version__
