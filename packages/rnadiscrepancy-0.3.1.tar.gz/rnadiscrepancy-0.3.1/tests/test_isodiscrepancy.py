import numpy as np


import RNADiscrepancy.measures as measures
import RNADiscrepancy.rna as rna
import RNADiscrepancy.utilities as utilities


def test_2gdi_cww_tww():
    path_cif = './tests/2gdi_truncated.cif'
    to_find = [('B', '4'), ('B', '78'), #a CWW
               ('B', '51'),('B', '69')  #a CWH
              ]
    positions = utilities.get_cif_positions(path_cif, to_find, 
                                            author_chain=False, 
                                            author_position=False)
    first_base_pair = (positions['B', '4'], positions['B', '78'])
    second_base_pair = (positions['B', '51'], positions['B', '69'])

    assert np.isclose(measures.isodiscrepancy(first_base_pair, second_base_pair), 15.130358196427407)


