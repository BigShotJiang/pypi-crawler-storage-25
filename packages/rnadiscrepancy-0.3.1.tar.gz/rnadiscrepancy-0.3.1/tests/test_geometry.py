import numpy as np


from RNADiscrepancy import geometry

def test_triangle_xy_opposite_sign():

    for _ in range(100):
        a = np.random.rand(2,)
        b = np.random.rand(2,)
        c = np.random.rand(2,)
        assert geometry.triangle_xy_sign(a, b, c) != geometry.triangle_xy_sign(a, c, b)
