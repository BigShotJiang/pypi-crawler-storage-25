import numpy as np


import RNADiscrepancy.measures as measures
import RNADiscrepancy.rna as rna
import RNADiscrepancy.utilities as utilities


def test_2gdi_cww_tww():
    path_cif = './tests/2gdi_truncated.cif'
    to_find = [('B', '4'), ('B', '78'), #a CWW
               ('B', '51'),('B', '69')  #a TWH
              ]
    positions = utilities.get_cif_positions(path_cif, to_find, 
                                            author_chain=False, 
                                            author_position=False)
    first_base_pair = (positions['B', '4'], positions['B', '78'])
    second_base_pair = (positions['B', '51'], positions['B', '69'])

    assert np.isclose(measures.discrepancy(first_base_pair, second_base_pair),
                      4.833960422452675)




def test_2gdi_cww_tww_neighb():
    path_cif = './tests/2gdi_truncated.cif'
    to_find = [('B', '4'), ('B', '78'), ('B', '5'), #a CWW + neighbor
               ('B', '51'),('B', '69'), ('B', '52')  #a TWH + neighbor
              ]
    positions = utilities.get_cif_positions(path_cif, to_find, 
                                            author_chain=False, 
                                            author_position=False)
    first_module = (positions['B', '4'], positions['B', '78'], positions['B', '5'], positions['B', '51'])
    second_module = (positions['B', '51'], positions['B', '69'], positions['B', '52'], positions['B', '4'])

    assert np.isclose(measures.discrepancy(first_module, second_module),
                      1.7206629733676666)



