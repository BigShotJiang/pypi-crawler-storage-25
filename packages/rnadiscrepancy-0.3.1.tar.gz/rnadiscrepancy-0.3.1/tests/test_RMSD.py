import numpy as np


from RNADiscrepancy import measures


def test_RMSD():
    A = np.array([1,2,3])
    B = np.array([2,3,4])
    assert np.isclose(1, measures.RMSD(A, B))
