from unittest.mock import patch
import importlib



def test_version():
    """Import the library to check if version works
    """
    import RNADiscrepancy
    importlib.reload(RNADiscrepancy)
    assert RNADiscrepancy.__version__ != "unknown"


def test_version_not():
    """Import the library to check if error works
    fun trick with patch to remove the module!
    """
    with patch.dict("sys.modules", {"RNADiscrepancy._version": None}):
        import RNADiscrepancy
        importlib.reload(RNADiscrepancy)
        assert RNADiscrepancy.__version__ == "unknown"

