RNADiscrepancy
==============

A python library for RNA isodiscrepancy and discrepancy

Quick Start
-----------

Install from PyPI::

   pip install RNADiscrepancy

Basic usage::

   from RNADiscrepancy import measures, utilities
   path_cif = '../../test/2gdi.cif'
   to_find = [('B', '4'), ('B', '78'), #a CWW
              ('B', '51'),('B', '69')  #a TWH
             ]
   positions = utilities.get_cif_positions(path_cif, to_find,
                                           author_chain=False,
                                           author_position=False)
   first_base_pair = (positions['B', '4'], positions['B', '78'])
   second_base_pair = (positions['B', '51'], positions['B', '69'])
   print(measures.isodiscrepancy(first_base_pair, second_base_pair))
   #15.130358196427407

Modules discrepancy::

   from RNADiscrepancy import measures, utilities

   path_cif = '2gdi.cif'
   to_find = [('B', '4'), ('B', '78'), ('B', '5'), #a CWW + neighbor
              ('B', '51'),('B', '69'), ('B', '52')  #a TWH + neighbor
             ]
   positions = utilities.get_cif_positions(path_cif, to_find,
                                           author_chain=False,
                                           author_position=False)
   first_module = (positions['B', '4'], positions['B', '78'], positions['B', '5'], positions['B', '51'])
   second_module = (positions['B', '51'], positions['B', '69'], positions['B', '52'], positions['B', '4'])
   print(measures.discrepancy(first_module, second_module)
   #1.7206629733676666





Modules
-------


.. toctree::
   :maxdepth: 1

   Index <apidocs/index>
   Geometry <apidocs/RNADiscrepancy/RNADiscrepancy.geometry>
   Graphics <apidocs/RNADiscrepancy/RNADiscrepancy.graphics>
   Measures <apidocs/RNADiscrepancy/RNADiscrepancy.measures>
   References <apidocs/RNADiscrepancy/RNADiscrepancy.references>
   RNA <apidocs/RNADiscrepancy/RNADiscrepancy.rna>
   Utilities <apidocs/RNADiscrepancy/RNADiscrepancy.utilities>

