project = "RNADiscrepancy"
extensions = ["autodoc2", "sphinx_rtd_theme", "sphinx.ext.autodoc", "sphinx_autodoc_typehints"] 
autodoc2_packages = ["../src/RNADiscrepancy"]
autodoc2_render_plugin = "rst"
html_theme = "sphinx_rtd_theme"
