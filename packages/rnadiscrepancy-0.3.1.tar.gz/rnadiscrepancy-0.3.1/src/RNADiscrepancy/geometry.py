from typing import Sequence


import numpy as np
import numpy.typing as npt
from scipy.spatial.transform import Rotation


def RMSD(A, B)-> float:
    return np.sqrt(((A - B)**2).mean())


def angle_rotation(rotation_matrix) -> float:
    """Given a rotation matrix return its angle of rotation
    uses the fact that trace(rotation_matrix) = 1 + 2cos(theta)

    Args:
        rotation_matrix (matrix n x 3): rotation matrix

    Returns:
        The angle in radian
    """

    return np.arccos((rotation_matrix.trace() - 1)/2)


def rotation_align_2D_points(p1 : Sequence[float] , p2 : Sequence[float])-> npt.NDArray[[float]] :
    """
    Given two points will return the rotation matrix
    R such that p2 @ R.T is aligned with p1
    """
    x1, y1, *_ = p1
    x2, y2, *_ = p2
    theta = np.atan2(x2, y2) - np.atan2(x1, y1)
    rotation = np.array([[np.cos(theta), -np.sin(theta), 0],
                         [np.sin(theta), np.cos(theta), 0],
                         [0 , 0, 1]])
    return rotation


def best_rotation(A : npt.NDArray[[float]], center_A : npt.NDArray[float], B : npt.NDArray[[float]], center_B : npt.NDArray[float])-> [npt.NDArray[[float]], npt.NDArray[float], npt.NDArray[float], float, float] :
    """Given two sets of points and for each an "origin" computes the best rotation to go from set B -> A

    Args:
        A (Matrix n X 3) : set of points A
        center_A (Vector 1 x 3) : center point of A
        B (Matrix n X 3) : set of points B
        center_B (Vector 1 x 3) : center point of B

    Returns:
        Rotation B->A
        Rotation object B on A
        center_A
        center_B
        sum squared errors
        RMSD
    """
    A_centered = A - center_A
    B_centered = B - center_B
    rotation, _ = Rotation.align_vectors(A_centered, B_centered)
    rotation = rotation.as_matrix()
    B2A = B_centered @ rotation.T + center_A
    difference = A_centered - B2A + center_A
    sum_square_error = float(np.sum(difference ** 2))
    RMSD = float(np.sqrt(sum_square_error / len(A)))
    return rotation, B2A, center_A, center_B, sum_square_error, RMSD


def best_mean_centered_rotation(A : npt.NDArray[[float]], B : npt.NDArray[[float]])-> npt.NDArray[[float]] :
    """Least-squares rigid-body fit transform of two numpy array
    The center of mass of the nucleotide is at (0, 0, 0)
    returns 
    rotation :  matrix
    B2A : B moved to over A
    mean_A, 
    mean_B,
    sum_square_error,
    RMSD
    """
    mean_A = A.mean(axis=0)
    mean_B = B.mean(axis=0)
    return best_rotation(A, mean_A, B, mean_B)


def best_rotation_translation(A : npt.NDArray[[float]], B : npt.NDArray[[float]])-> [npt.NDArray[[float]], npt.NDArray[[float]], float,  float, float] :
    """Given two sets of points and for each an "origin" computes the best rotation + translation to go from set B -> A
    A = B @ R.T + t
    Follows Kabsch algorithm

    Args:
        A (Matrix n X 3) : set of points A
        B (Matrix n X 3) : set of points B

    Returns:
        Rotation R
        translation t
        B2A
        sum squared errors
        RMSD
    """

    #Center on centroids
    center_A = A.mean(axis=0)
    center_B = B.mean(axis=0)
    Ac = A - center_A
    Bc = B - center_B

    #Cross-covariance and SVD
    H = Bc.T @ Ac
    U, _, Vt = np.linalg.svd(H)

    #Correct reflection (ensures a proper rotation, det = +1)
    d = np.linalg.det(Vt.T @ U.T)
    S = np.diag([1.0, 1.0, np.sign(d)])

    #Get Rotation
    R = Vt.T @ S @ U.T

    #Get optimal translation given centers
    t = center_A - R @ center_B

    B2A = B @ R.T + t

    difference = A - B2A
    sum_square_error = float(np.sum(difference ** 2))
    RMSD = float(np.sqrt(sum_square_error / len(A)))

    return R, t, B2A, sum_square_error, RMSD


def triangle_xy_sign(p1: npt.NDArray[float], p2: npt.NDArray[float], p3: npt.NDArray[float])-> int:
    """Return a direction +-1 of a triangle in the xy plane (ignores 3th dimension)
    by comparing to p1, p3, p2 it allows to check if two triangles are in the same orientation or not
    Relies on the computation (p3 - p1) X ( p2 - p1) =  sign
    https://math.stackexchange.com/questions/4560043/orientation-of-a-triangles-vertices-in-3d-space-clockwise-or-counter-clockwise

    Args:
        p1 (npt.NDArray[float]) : position in space of point1
        p2 (npt.NDArray[float]) : position in space of point2
        p3 (npt.NDArray[float]) : position in space of point3

    Return:
        A value +-1 of the normal
    """
    p1 = p1[:2]
    p2 = p2[:2]
    p3 = p3[:2]

    return np.sign(np.cross((p3 - p1), (p2 - p1)))
