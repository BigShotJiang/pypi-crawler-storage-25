import numpy as np
import tempfile
import os


INSTALL_MSG = (
    "\n\nVisualization dependencies not installed.\n"
    "Run:  pip install RNADiscrepancy[viz]\n"
)

try:
    import matplotlib.pyplot as plt
    import pymol
    pymol.finish_launching(["pymol", "-cq"])
    from pymol import cmd
except ImportError as e:
    raise ImportError(str(e) + _INSTALL_MSG) from e


def plot_positions_names(*args):
    """list of alternating datapoints / names
    e.g. [[1,2,0], [2,3,4], [2,5,3]], ['a', 'b', 'c'], ...
    """

    fig, ax = plt.subplots()

    data = []
    names = []
    all_data = (x for x in args)
    for i, (d, n) in enumerate(zip(all_data, all_data)):
        data.extend(d)
        names.extend([f'{x}_{i}' for x in n])
        ax.scatter([x[0] for x in d], [x[1] for x in d])

    for i, txt in enumerate(names):
        ax.annotate(txt, (data[i][0], data[i][1]))
    plt.show()



def plots_compare_first(*args):
    """list of alternating datapoints / names
    e.g. [[1,2,0], [2,3,4], [2,5,3]], ['a', 'b', 'c'], ...
    """

    nb_comparisons = len(args)//2

    fig, ax = plt.subplots(1, nb_comparisons)

    all_data = (x for x in args)
    for i, (d, n) in enumerate(zip(all_data, all_data)):
        ax[i].set_xlim([-1.1, 1.1])
        ax[i].set_ylim([-1.1, 1.1])
        ax[i].scatter([x[0] for x in d], [x[1] for x in d])

        for j, txt in enumerate(n):
            ax[i].annotate(txt, (d[j][0], d[j][1]))
    plt.show()

