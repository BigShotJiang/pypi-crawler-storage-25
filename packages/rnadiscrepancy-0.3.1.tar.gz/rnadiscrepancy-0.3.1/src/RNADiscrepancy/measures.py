import math
from collections.abc import Sequence


import numpy as np
import numpy.typing as npt


from RNADiscrepancy import references
from RNADiscrepancy.geometry import angle_rotation, best_rotation, best_rotation_translation, RMSD, triangle_xy_sign, rotation_align_2D_points
from RNADiscrepancy.rna import Atom, Nucleotide


def c1prime_distance_difference(pair1, pair2):
    """Returns the difference in distance between the C1' atoms (connecting sugar to residue) in the two pairs
    always positive
    """


    (nt1_left, nt1_right), (nt2_left, nt2_right) = pair1, pair2
    dist_c1 = abs(nt1_left["C1'"].distance(nt1_right["C1'"]) - nt2_left["C1'"].distance(nt2_right["C2'"]))

    return dist_c1


def c1prime_translation(pair1, pair2):
    """
    Here we have to do things in regards to the _left and _right side symmetricaly

    1'. Use N1/N9 of their reference as (0, 0)
    2'. Rotate to align the first base to the reference (and apply rotation to the pair)
    """

    (nt1_left, nt1_right), (nt2_left, nt2_right) = pair1, pair2

    #Rotate all 4 nucleotides towards their respective reference
    nt1_left_rotation = nt1_left.rotation_matrix
    nt1_right_rotation = nt1_right.rotation_matrix
    nt2_left_rotation = nt2_left.rotation_matrix
    nt2_right_rotation = nt2_right.rotation_matrix


    #Compute new c1' atom position and inter-distance
    c1p_1right = nt1_right["C1'"].position
    c1p_1right = (c1p_1right - np.array(nt1_left.ribose_fulcrum.position)) @ nt1_left_rotation.T
    c1p_2right = nt2_right["C1'"].position
    c1p_2right = (c1p_2right - np.array(nt2_left.ribose_fulcrum.position)) @ nt2_left_rotation.T
    c1p_t1 = math.sqrt((c1p_1right[0] - c1p_2right[0])**2 + (c1p_1right[1] - c1p_2right[1])**2)


    c1p_1left = nt1_left["C1'"].position
    c1p_1left = (c1p_1left - np.array(nt1_right.ribose_fulcrum.position)) @ nt1_right_rotation.T
    c1p_2left = nt2_left["C1'"].position
    c1p_2left = (c1p_2left - np.array(nt2_right.ribose_fulcrum.position)) @ nt2_right_rotation.T
    c1p_t2 = math.sqrt((c1p_1left[0] - c1p_2left[0])**2 + (c1p_1left[1] - c1p_2left[1])**2)


    #Now we compute the diff in angle for the "other" side
    #First in left reference frame 

    # module1 : delta right in function of left
    delta1 = nt1_right_rotation @ nt1_left_rotation
    # module2: delta right in function of lef
    delta2 = nt2_right_rotation @ nt1_left_rotation

    # Rotation to go from module2 right -> module1 right
    deltadelta1 = delta1 @ delta2
    #Rotation to now on the left side
    #module left (transpose of delta1) -> module2 left
    deltadetal2 = delta2.T @ delta1.T

    theta_r = angle_rotation(deltadelta1)
    theta_l = angle_rotation(deltadetal2)


    #BUT maybe we are in wrong reference (at least one side is flipped ( => sugar different side )
    # C2(C4)   C6(C8)
    #    \       /
    #      N1(N9)
    #          \
    #            Ribose
    #          /
    #     Phosphate              
    #We grab for each fulcrum (N1 | N9) and sides (C2, C6 | C4, C8)
    triangle1_left = [nt1_left.ribose_fulcrum.position] + [x.position for x in nt1_left.neighbors_fulcrum]
    triangle2_left = [nt2_left.ribose_fulcrum.position] + [x.position for x in nt2_left.neighbors_fulcrum]
    triangle1_right = [nt1_right.ribose_fulcrum.position] + [x.position for x in nt1_right.neighbors_fulcrum]
    triangle2_right = [nt2_right.ribose_fulcrum.position] + [x.position for x in nt2_right.neighbors_fulcrum]
    #We align each triangle in relation the the alignment of the OTHER nucleotide (e.g. left -> when right side nucleotides are aligned together) 
    triangle1_left = (triangle1_left - np.array(nt1_right.ribose_fulcrum.position)) @ nt1_right_rotation.T
    triangle2_left = (triangle2_left - np.array(nt2_right.ribose_fulcrum.position)) @ nt2_right_rotation.T
    triangle1_right = (triangle1_right - np.array(nt1_left.ribose_fulcrum.position)) @ nt1_left_rotation.T
    triangle2_right = (triangle2_right - np.array(nt2_left.ribose_fulcrum.position)) @ nt2_left_rotation.T
    #We check compare normal direction for each tryiangle project in xy plane
    flip_left = triangle_xy_sign(*triangle1_left) != triangle_xy_sign(*triangle2_left)
    flip_right = triangle_xy_sign(*triangle1_right) != triangle_xy_sign(*triangle2_right)

    flipped = 0
    if flip_left or flip_right:
        theta_l = 0
        theta_r = 0
        flipped = 3 * np.pi

    return c1p_t1, c1p_t2, theta_l, theta_r, flipped




def isodiscrepancy(pair1, pair2):
    """
    Return IDI between pairs (nt1_left, nt1_right) and (nt2_left, nt2_right)
    it assumes the orientation is to align nt1_left with nt2_left  / nt1_right with nt2_right

    we follow https://doi.org/10.1093/nar/gkp011

    1) delta c1' distances
    2) align on one N1/N9 and see other C1' translation distance
    3) rotation in plane to orient same second base in relation to first
    """

    c1prime_dist_delta = c1prime_distance_difference(pair1, pair2)
    c1prime_t1, c1prime_t2, theta1, theta2, flipped = c1prime_translation(pair1, pair2)

    return math.sqrt(c1prime_dist_delta**2
                     + (c1prime_t1**2 + c1prime_t2**2)/2
                     + ((2 * theta1)**2 + (2 * theta2)**2)/2
                     + flipped**2
                     )




def discrepancy(module1 : Sequence[Nucleotide], module2 : Sequence[Nucleotide])-> float :
    """Compute the discrepancy between set of nucleotides between the two modules.

    We follow the steps in https://doi.org/10.1007/s00285-007-0110-x

    Args:
        module1 (Sequence[Nucleotide]): List of nucleotides of the first module
        module2 (Sequence[Nucleotide]): List of nucleotides of the second module

    Returns:
        The discrepancy value (float) when aligning pairwise atoms between the modules
    """

    assert len(module1) == len(module2)
    assert len(module1) > 1


    center1 = np.array([x.center_heavy_atoms_residue for x in module1])
    rotation1 = [x.rotation_matrix for x in module1]
    center2 = np.array([x.center_heavy_atoms_residue for x in module2])
    rotation2 = [x.rotation_matrix for x in module2]

    if len(module1) == 2:
        # module1 : delta right in function of left
        delta1 = rotation1[1].T @ rotation1[0]
        # module2: delta right in function of lef
        delta2 = rotation2[1].T @ rotation2[0]

        # Rotation to go from module2 right -> module1 right
        deltadelta1 = delta1 @ delta2
        #Rotation to now on the left side
        #module left (transpose of delta1) -> module2 left
        deltadetal2 = delta2.T @ delta1.T

        theta_r = angle_rotation(deltadelta1)
        theta_l = angle_rotation(deltadetal2)

        #Move position right when center on left
        lc_r1 = (center1[1] - np.array(module1[0].ribose_fulcrum.position)) @ rotation1[0]
        lc_r2 = (center2[1] - np.array(module2[0].ribose_fulcrum.position)) @ rotation2[0]
        dist_r = np.sqrt(((lc_r1 - lc_r2)**2).sum())

        #Move position left when center on right
        rc_l1 = (center1[0] - np.array(module1[1].ribose_fulcrum.position)) @ rotation1[1]
        rc_l2 = (center2[0] - np.array(module2[1].ribose_fulcrum.position)) @ rotation2[1]
        dist_l = np.sqrt(((rc_l1 - rc_l2)**2).sum())

        discrepancy = np.sqrt(dist_l**2 + theta_l**2) + np.sqrt(dist_r**2 + theta_r**2)
        return 0.25 / np.sqrt(2) * discrepancy

    else:

        #First compute best rotation + translation 
        # sse is the L^2 term
        R, t, B2A, sse, rmsd = best_rotation_translation(center1, center2)

        #Compute orientation error now
        #it's simply the angle of r1 @ r2.T @ R.T
        orientation_error = 0
        for r1, r2 in zip(rotation1, rotation2):
            theta = angle_rotation(r1 @ r2.T @ R.T)
            orientation_error += theta**2

        return np.sqrt(sse + orientation_error) / len(module1)







