import math


import numpy as np


from RNADiscrepancy import references
from RNADiscrepancy.geometry import best_rotation

class Atom:
    def __init__(self, name, element, x, y, z, virtual=False):
        self.name = name
        self.element = element
        self.x = x
        self.y = y
        self.z = z
        self.virtual = virtual

    @property
    def position(self):
        return self.x, self.y, self.z


    def distance(self, other):
        x, y, z = self.position
        x2, y2, z2 = other.position
        return math.sqrt((x - x2)**2 + (y - y2)**2 + (z - z2)**2)


    def __eq__(self, other):
        if isinstance(other, self.__class__):
            return self.name == other.name
        else:
            return False

    def __neq__(self, other):
        return not self.__eq__(other)

    def __str__(self):
        return f"Atom class: {self.name}, {self.element}, {self.x}, {self.y}, {self.z}"

    def __repr__(self):
        return f"Atom class: {self.name}, {self.element}, {self.x}, {self.y}, {self.z}"



class Nucleotide(dict):
    def __init__(self, name, atoms):

        if name not in ('A', 'C', 'G', 'U'):
            raise Exception(f"WTF this should be ACGU not {name}")

        self.name = name
        for atom in atoms:
            self[atom.name] = atom


    @property
    def ribose_fulcrum(self):
        if self.name in ('C', 'U'):
            return self['N1']
        elif self.name in ('A', 'G'):
            return self['N9']

    @property
    def neighbors_fulcrum(self):
        if self.name in ('C', 'U'):
            return self['C2'], self['C6']
        elif self.name in ('A', 'G'):
            return self['C4'], self['C8']


    @property
    def heavy_atoms_residue(self):
        return [self[x] for x in references.heavy_atoms_residue[self.name]]


    @property
    def center_heavy_atoms_residue(self):
        return np.array([x.position for x in self.heavy_atoms_residue]).mean(axis=0)

    @property
    def rotation_matrix(self):
        """Returns a rotation matrix towards the reference orientation
        with sugar at the bottom WCF edge on +x+y quadrant

        Args:
            self
        Returns:
            3x3 matrix
        """
        ref = references.nucleotide[self.name]
        pos = []
        ref_pos = []
        for atom_name, atom in ref.items():
            try:
                pos.append(self[atom_name].position)
                ref_pos.append(atom.position)
            except KeyError:
                continue


        rotation = best_rotation(ref_pos, np.array(ref.ribose_fulcrum.position),
                                 pos, np.array(self.ribose_fulcrum.position))[0]
        self._rotation_matrix = rotation
        return self._rotation_matrix




    def add_virtual_atoms_from_ref(self):
        """Adds virtual atoms from reference
        """
        ref_nt = references.nucleotide[self.name]

        #Retrieve position of nucleotide + ref for alignment
        nt_pos = []
        ref_pos = []
        to_add = []
        for atom_name, atom in ref_nt.items():
            try:
                nt_pos.append(atom.position)
                ref_pos.append(ref_nt[atom_name].position)
            except KeyError:
                to_add.append(atom_name)
        if not to_add:
            return

        #We must have a common atom to align the nucleotides
        #We would like to use ribose_fulcrum but if not available 
        #First one in the list of heavy atoms for each type
        try:
            fulcrum = self.ribose_fulcrum
            ref_fulcrum = ref_nt.ribose_fulcrum
        except KeyError:
            for atom in references.heavy_atoms_residue[self.name]:
                try:
                    fulcrum = self[atom]
                    ref_fulcrum = ref_nt[atom]
                    break
                except KeyError:
                    continue


        rotation = best_rotation(nt_pos, np.array(fulcrum.position),
                                 ref_pos, np.array(ref_fulcrum.position))[0]

        for atom in to_add:
            new_pos = (ref_nt[atom].position - ref_fulcrum.position) @ rotation + fulcrum.position
            new_atom = [atom, atom[0], new_pos[0], new_pos[1], new_pos[2], True]
            self[atom] = new_atom

