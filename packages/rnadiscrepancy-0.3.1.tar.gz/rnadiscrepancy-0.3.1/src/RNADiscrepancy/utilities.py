from RNADiscrepancy import rna


def rawdata_format_nucleotide(nucleotide_name: str, list_atoms_names: [str], list_atoms_elements: [str], list_positions: [[float, float, float]]) -> rna.Nucleotide:
    """From a list of atoms with their properties, and right nucleotide name, will build the Nucleotide object

    Args:
        nucleotide_name: A, C, G, U
        list_atoms_names : [str]
        list_atoms_elements : [str]
        list_positions : [[float, float, float]]

    Returns:
        rna.Nucleotide
    """
    atoms = []
    for name, element, pos in zip(list_atoms_names, list_atoms_elements, list_positions):
        atoms.append(rna.Atom(name, element, *pos))
    return rna.Nucleotide(nucleotide_name, atoms)


def get_cif_positions(path_cif: str, to_find: [(str, str)], author_chain: bool = False, author_position: bool = False, add_virtual: bool = True)-> dict[(str, str), rna.Nucleotide]:
    """ From a cif file will extract all pairs [(chain1, position1), (chain2, position2), ... (chainZ, positionZ)]
    (chainX, positionX) must both be strings

    if author_chain or author_position are set to True:
        - chain will be checked with author_chain
        - position will be checked with position + PDB_insertion_code (as one string)

    add_virtual will complete the Nucleotide object with virtual atoms fitted from the ideal positions to the ones observed


    Returns them in a dictio as rna.Nucleotide objects
    """
    nucleotides = {}
    col_atom_elem = None
    col_atom_name = None
    col_residue_name = None
    col_chain = None
    col_position = None
    col_insertion_code = None
    col_x = None
    col_y = None
    col_z = None

    in_atom_site = False
    col = 0
    with open(path_cif) as f:
        for line in f:
            if line.startswith('#'):
                continue
            if line.startswith('_atom_site.'):
                in_atom_site = True
                line = line.strip()
                if line.endswith('type_symbol'):
                    col_atom_elem = col
                elif line.endswith('label_atom_id'):
                    col_atom_name = col
                elif line.endswith('label_comp_id'):
                    col_residue_name = col
                elif line.endswith('label_asym_id'):
                    col_chain = col
                elif line.endswith('auth_asym_id') and author_chain:
                    col_chain = col
                elif line.endswith('label_seq_id'):
                    col_position = col
                elif line.endswith('auth_seq_id') and author_position:
                    col_position = col
                elif line.endswith('.pdbx_PDB_ins_code'):
                    col_insertion_code = col
                elif line.endswith('Cartn_x'):
                    col_x = col
                elif line.endswith('Cartn_y'):
                    col_y = col
                elif line.endswith('Cartn_z'):
                    col_z = col
                col += 1
                continue

            elif in_atom_site and line[0] == '_':
                in_atom_site = False
            if not in_atom_site:
                continue

            line = line.split()
            atom_elem, atom_name, residue_name, chain, position, insertion_code, x, y, z = (line[col_atom_elem], line[col_atom_name], line[col_residue_name],
                                                                                            line[col_chain], line[col_position], line[col_insertion_code],
                                                                                            line[col_x], line[col_y], line[col_z])
            if author_position and insertion_code != '?':
                position = position + insertion_code
            if atom_name[0] == '"':
                atom_name = atom_name[1:-1]

            if (chain, position) in to_find:
                if (chain, position) not in nucleotides:
                    nucleotides[chain, position] = {'list_atoms_names':[],
                                                    'list_atoms_elements':[],
                                                    'list_positions':[],
                                                    'name':None}
                nucleotides[chain, position]['list_atoms_names'].append(atom_name)
                nucleotides[chain, position]['list_atoms_elements'].append(atom_name)
                nucleotides[chain, position]['list_positions'].append((float(x), float(y), float(z)))
                nucleotides[chain, position]['name'] = residue_name

    for key, val in nucleotides.items():
        nt = rawdata_format_nucleotide(val['name'], val['list_atoms_names'], val['list_atoms_elements'], val['list_positions'])
        if add_virtual:
            nt.add_virtual_atoms_from_ref()
        nucleotides[key] = nt
    return nucleotides
