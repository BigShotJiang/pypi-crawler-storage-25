import warnings

warnings.simplefilter('ignore', FutureWarning)
__version__ = '1.8.14'
