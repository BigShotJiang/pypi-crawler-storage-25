"""Tests for InMemoryDedupStore."""

from __future__ import annotations

import asyncio

from platform_commons.dedup.memory_store import InMemoryDedupStore
from platform_commons.dedup.store import DedupStore


async def test_is_dedup_store_subclass() -> None:
    assert issubclass(InMemoryDedupStore, DedupStore)


async def test_acquire_new() -> None:
    store = InMemoryDedupStore()
    assert await store.try_acquire("e1") is True


async def test_acquire_duplicate_completed() -> None:
    store = InMemoryDedupStore()
    await store.try_acquire("e2")
    await store.mark_completed("e2")
    assert await store.try_acquire("e2") is False


async def test_acquire_duplicate_processing() -> None:
    store = InMemoryDedupStore()
    await store.try_acquire("e3")
    assert await store.try_acquire("e3") is False


async def test_acquire_retry_after_failed() -> None:
    store = InMemoryDedupStore()
    await store.try_acquire("e4")
    await store.mark_failed("e4")
    assert await store.try_acquire("e4") is True


async def test_concurrent_only_one_wins() -> None:
    store = InMemoryDedupStore()
    results = await asyncio.gather(*[store.try_acquire("same") for _ in range(10)])
    assert results.count(True) == 1


async def test_cleanup() -> None:
    store = InMemoryDedupStore()
    await store.try_acquire("old", ttl_seconds=0)
    count = await store.cleanup_stale(max_age_seconds=0)
    assert count >= 1
