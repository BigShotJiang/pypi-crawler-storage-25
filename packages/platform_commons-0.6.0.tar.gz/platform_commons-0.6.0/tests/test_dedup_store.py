"""Tests for PostgresDedupStore with SQLite in-memory."""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator

import pytest
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from platform_commons.dedup.postgres_store import PostgresDedupStore

_CREATE_TABLE = """
CREATE TABLE dedup_events (
    event_id VARCHAR(255) PRIMARY KEY,
    status VARCHAR(20) NOT NULL DEFAULT 'processing',
    acquired_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP,
    ttl_expires_at TIMESTAMP NOT NULL,
    service_name VARCHAR(64) NOT NULL
)
"""


@pytest.fixture()
async def session_factory() -> AsyncIterator[async_sessionmaker[AsyncSession]]:
    engine = create_async_engine("sqlite+aiosqlite://", echo=False)
    async with engine.begin() as conn:
        await conn.execute(text(_CREATE_TABLE))
    factory = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
    yield factory
    await engine.dispose()


@pytest.fixture()
def store(session_factory: async_sessionmaker[AsyncSession]) -> PostgresDedupStore:
    return PostgresDedupStore(session_factory, service_name="test-svc")


async def test_try_acquire_new_event(store: PostgresDedupStore) -> None:
    assert await store.try_acquire("evt_001") is True


async def test_try_acquire_duplicate_completed(store: PostgresDedupStore) -> None:
    await store.try_acquire("evt_002")
    await store.mark_completed("evt_002")
    assert await store.try_acquire("evt_002") is False


async def test_try_acquire_duplicate_processing(store: PostgresDedupStore) -> None:
    await store.try_acquire("evt_003")
    assert await store.try_acquire("evt_003") is False


async def test_try_acquire_retry_after_failed(store: PostgresDedupStore) -> None:
    await store.try_acquire("evt_004")
    await store.mark_failed("evt_004")
    assert await store.try_acquire("evt_004") is True


async def test_mark_completed_makes_permanent(store: PostgresDedupStore) -> None:
    await store.try_acquire("evt_005")
    await store.mark_completed("evt_005")
    assert await store.try_acquire("evt_005") is False


async def test_mark_failed_allows_retry(store: PostgresDedupStore) -> None:
    await store.try_acquire("evt_006")
    await store.mark_failed("evt_006")
    result = await store.try_acquire("evt_006")
    assert result is True


async def test_concurrent_acquire_only_one_wins(store: PostgresDedupStore) -> None:
    results = await asyncio.gather(*[store.try_acquire("evt_concurrent") for _ in range(10)])
    assert results.count(True) == 1
    assert results.count(False) == 9


async def test_cleanup_stale_removes_expired(
    store: PostgresDedupStore,
    session_factory: async_sessionmaker[AsyncSession],
) -> None:
    # Insert with past ttl_expires_at
    async with session_factory() as session:
        await session.execute(
            text(
                "INSERT INTO dedup_events "
                "(event_id, status, acquired_at, ttl_expires_at, service_name) "
                "VALUES ('stale_001', 'processing', '2020-01-01', "
                "'2020-01-01', 'test')"
            )
        )
        await session.commit()
    count = await store.cleanup_stale(max_age_seconds=1)
    assert count >= 1


async def test_cleanup_stale_preserves_active(store: PostgresDedupStore) -> None:
    await store.try_acquire("active_001", ttl_seconds=3600)
    count = await store.cleanup_stale(max_age_seconds=86400)
    assert count == 0


async def test_cleanup_stale_removes_old_completed(
    store: PostgresDedupStore,
    session_factory: async_sessionmaker[AsyncSession],
) -> None:
    async with session_factory() as session:
        await session.execute(
            text(
                "INSERT INTO dedup_events "
                "(event_id, status, acquired_at, completed_at, "
                "ttl_expires_at, service_name) "
                "VALUES ('old_001', 'completed', '2020-01-01', "
                "'2020-01-01', '2020-01-01', 'test')"
            )
        )
        await session.commit()
    count = await store.cleanup_stale(max_age_seconds=1)
    assert count >= 1


async def test_service_name_stored(
    store: PostgresDedupStore,
    session_factory: async_sessionmaker[AsyncSession],
) -> None:
    await store.try_acquire("svc_001")
    async with session_factory() as session:
        result = await session.execute(
            text("SELECT service_name FROM dedup_events WHERE event_id = 'svc_001'")
        )
        row = result.fetchone()
    assert row is not None
    assert row[0] == "test-svc"
