"""PostgreSQL-backed persistent dedup store."""

from __future__ import annotations

import logging
from datetime import UTC, datetime, timedelta

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from platform_commons.dedup.store import DedupStore

logger = logging.getLogger(__name__)


class PostgresDedupStore(DedupStore):
    """Persistent dedup using PostgreSQL (or SQLite for tests)."""

    def __init__(
        self,
        session_factory: async_sessionmaker[AsyncSession],
        *,
        service_name: str = "unknown",
        table_name: str = "dedup_events",
    ) -> None:
        self._session_factory = session_factory
        self._service_name = service_name
        self._table = table_name

    async def try_acquire(self, event_id: str, *, ttl_seconds: int = 300) -> bool:
        """Atomic acquire: INSERT new or UPDATE failed -> processing."""
        now = datetime.now(UTC)
        expires = now + timedelta(seconds=ttl_seconds)

        async with self._session_factory() as session:
            # Try INSERT (new event)
            result = await session.execute(
                text(
                    f"INSERT INTO {self._table} "  # noqa: S608
                    "(event_id, status, acquired_at, ttl_expires_at, service_name) "
                    "VALUES (:eid, 'processing', :now, :expires, :svc) "
                    "ON CONFLICT (event_id) DO NOTHING"
                ),
                {"eid": event_id, "now": now, "expires": expires, "svc": self._service_name},
            )
            if getattr(result, "rowcount", 0) and getattr(result, "rowcount", 0) > 0:
                await session.commit()
                return True

            # INSERT failed (conflict) — check if retry allowed (status=failed)
            result = await session.execute(
                text(
                    f"UPDATE {self._table} "  # noqa: S608
                    "SET status = 'processing', acquired_at = :now, ttl_expires_at = :expires "
                    "WHERE event_id = :eid AND status = 'failed'"
                ),
                {"eid": event_id, "now": now, "expires": expires},
            )
            await session.commit()
            return bool(getattr(result, "rowcount", 0) and getattr(result, "rowcount", 0) > 0)

    async def mark_completed(self, event_id: str) -> None:
        """Mark as completed (permanent duplicate)."""
        now = datetime.now(UTC)
        async with self._session_factory() as session:
            result = await session.execute(
                text(
                    f"UPDATE {self._table} "  # noqa: S608
                    "SET status = 'completed', completed_at = :now "
                    "WHERE event_id = :eid AND status = 'processing'"
                ),
                {"eid": event_id, "now": now},
            )
            await session.commit()
            if not getattr(result, "rowcount", 0):
                logger.warning("mark_completed: no processing entry for %s", event_id)

    async def mark_failed(self, event_id: str) -> None:
        """Mark as failed (allows retry)."""
        now = datetime.now(UTC)
        async with self._session_factory() as session:
            result = await session.execute(
                text(
                    f"UPDATE {self._table} "  # noqa: S608
                    "SET status = 'failed', completed_at = :now "
                    "WHERE event_id = :eid AND status = 'processing'"
                ),
                {"eid": event_id, "now": now},
            )
            await session.commit()
            if not getattr(result, "rowcount", 0):
                logger.warning("mark_failed: no processing entry for %s", event_id)

    async def cleanup_stale(self, *, max_age_seconds: int = 86400) -> int:
        """Remove expired processing + old completed/failed entries."""
        now = datetime.now(UTC)
        cutoff = now - timedelta(seconds=max_age_seconds)

        async with self._session_factory() as session:
            result = await session.execute(
                text(
                    f"DELETE FROM {self._table} "  # noqa: S608
                    "WHERE (status = 'processing' AND ttl_expires_at < :now) "
                    "OR (status IN ('completed', 'failed') AND acquired_at < :cutoff)"
                ),
                {"now": now, "cutoff": cutoff},
            )
            await session.commit()
            count = getattr(result, "rowcount", 0) or 0
            if count:
                logger.info("Cleaned %d stale dedup entries", count)
            return count
