"""In-memory dedup store for testing and local development."""

from __future__ import annotations

import threading
import time

from platform_commons.dedup.store import DedupStatus, DedupStore


class InMemoryDedupStore(DedupStore):
    """In-memory dedup store. NOT persistent — loses state on restart."""

    def __init__(self) -> None:
        self._store: dict[str, tuple[DedupStatus, float, float]] = {}
        self._lock = threading.Lock()

    async def try_acquire(self, event_id: str, *, ttl_seconds: int = 300) -> bool:
        """Acquire lock. Returns True for new or failed events."""
        now = time.monotonic()
        expires = now + ttl_seconds
        with self._lock:
            entry = self._store.get(event_id)
            if entry is None:
                self._store[event_id] = (DedupStatus.PROCESSING, now, expires)
                return True
            status, _acquired, ttl_exp = entry
            if status == DedupStatus.FAILED:
                self._store[event_id] = (DedupStatus.PROCESSING, now, expires)
                return True
            if status == DedupStatus.PROCESSING and now > ttl_exp:
                self._store[event_id] = (DedupStatus.PROCESSING, now, expires)
                return True
            return False

    async def mark_completed(self, event_id: str) -> None:
        """Mark as completed."""
        with self._lock:
            if event_id in self._store:
                _, acquired, expires = self._store[event_id]
                self._store[event_id] = (DedupStatus.COMPLETED, acquired, expires)

    async def mark_failed(self, event_id: str) -> None:
        """Mark as failed (allows retry)."""
        with self._lock:
            if event_id in self._store:
                _, acquired, expires = self._store[event_id]
                self._store[event_id] = (DedupStatus.FAILED, acquired, expires)

    async def cleanup_stale(self, *, max_age_seconds: int = 86400) -> int:
        """Remove old entries."""
        now = time.monotonic()
        cutoff = now - max_age_seconds
        with self._lock:
            to_remove = [
                eid
                for eid, (status, acquired, ttl_exp) in self._store.items()
                if (status == DedupStatus.PROCESSING and now > ttl_exp) or acquired < cutoff
            ]
            for eid in to_remove:
                del self._store[eid]
            return len(to_remove)
