"""Persistent deduplication for exactly-once event processing."""

from platform_commons.dedup.memory_store import InMemoryDedupStore
from platform_commons.dedup.store import DedupStatus, DedupStore

__all__ = ["DedupStatus", "DedupStore", "InMemoryDedupStore"]

try:
    from platform_commons.dedup.postgres_store import PostgresDedupStore  # noqa: F401

    __all__.append("PostgresDedupStore")
except ImportError:
    pass  # sqlalchemy not installed
