"""Abstract dedup store interface."""

from __future__ import annotations

from abc import ABC, abstractmethod
from enum import StrEnum


class DedupStatus(StrEnum):
    """Event processing status in dedup store."""

    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"


class DedupStore(ABC):
    """Abstract dedup store for exactly-once event processing.

    Two-phase protocol:
      1. try_acquire(event_id) -> True (proceed) or False (duplicate)
      2. mark_completed(event_id) or mark_failed(event_id)

    Failed events CAN be retried. Completed events are permanent duplicates.
    """

    @abstractmethod
    async def try_acquire(self, event_id: str, *, ttl_seconds: int = 300) -> bool:
        """Try to acquire processing lock. Returns True if acquired."""

    @abstractmethod
    async def mark_completed(self, event_id: str) -> None:
        """Mark event as successfully processed. Permanent."""

    @abstractmethod
    async def mark_failed(self, event_id: str) -> None:
        """Mark event as failed. Can be retried via try_acquire."""

    @abstractmethod
    async def cleanup_stale(self, *, max_age_seconds: int = 86400) -> int:
        """Clean up old entries. Returns count removed."""
