"""pqsafe — umbrella package. Re-exports pqsafe_agent_pay for convenience."""
__version__ = "0.1.1"

try:
    from pqsafe_agent_pay import *  # noqa: F401,F403
except ImportError:
    pass
