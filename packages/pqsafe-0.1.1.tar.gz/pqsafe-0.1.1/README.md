# pqsafe

**Umbrella package for PQSafe AgentPay.** Installing `pqsafe` pulls in the real SDK, `pqsafe-agent-pay`.

```bash
pip install pqsafe
```

is equivalent to:

```bash
pip install pqsafe-agent-pay
```

## Why this package exists

The bare `pqsafe` name on PyPI is reserved here so the brand namespace is not squatted. The actual SDK ships under `pqsafe-agent-pay`; framework integrations under `langchain-pqsafe` and `crewai-pqsafe`.

## Use

```python
from pqsafe_agent_pay import create_envelope, sign_envelope, execute_agent_payment
```

## Links

- Website: https://pqsafe.xyz
- Handbook: https://pqsafe.xyz/handbook
- FIDO Alliance open letter: https://pqsafe.xyz/fido-pq-letter
- AP2-PQ Profile RFC: https://pqsafe.xyz/ap2-pq-rfc
- Test vectors: https://github.com/PQSafe/ap2-pq-test-vectors
- License: Apache-2.0
