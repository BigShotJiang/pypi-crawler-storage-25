"""Tests for mosesaic.team.serve — server startup logic."""
from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import MagicMock, patch
import pytest

from mosesaic.team.serve import _write_template, _handle_no_config, main


# ── Template writer ───────────────────────────────────────────────────────────

def test_write_template_creates_file(tmp_path, monkeypatch):
    """_write_template() writes mosesaic.toml to cwd."""
    monkeypatch.chdir(tmp_path)
    _write_template()
    toml = tmp_path / "mosesaic.toml"
    assert toml.exists()
    content = toml.read_text()
    assert "[server]" in content
    assert "[[provider]]" in content


def test_write_template_does_not_overwrite(tmp_path, monkeypatch):
    """_write_template() is a no-op if mosesaic.toml already exists."""
    monkeypatch.chdir(tmp_path)
    existing = tmp_path / "mosesaic.toml"
    existing.write_text("# existing")
    _write_template()
    assert existing.read_text() == "# existing"


# ── No-config MCP mode ────────────────────────────────────────────────────────

def test_handle_no_config_mcp_writes_template_and_exits(tmp_path, monkeypatch, capsys):
    """In --with-mcp mode: write template, print to stderr, exit 1."""
    monkeypatch.chdir(tmp_path)
    with pytest.raises(SystemExit) as exc_info:
        _handle_no_config(with_mcp=True, host=None, port=None)
    assert exc_info.value.code == 1
    assert (tmp_path / "mosesaic.toml").exists()
    captured = capsys.readouterr()
    assert "No providers configured" in captured.err


# ── No-config terminal mode ───────────────────────────────────────────────────

def test_handle_no_config_terminal_no_answer_exits(tmp_path, monkeypatch):
    """In terminal mode, answering 'n' prints instructions and returns."""
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr("builtins.input", lambda _: "n")
    # Should not raise
    _handle_no_config(with_mcp=False, host=None, port=None)
    # No mosesaic.toml written (user declined)
    assert not (tmp_path / "mosesaic.toml").exists()


def test_handle_no_config_terminal_yes_calls_init(tmp_path, monkeypatch):
    """In terminal mode, answering 'y' runs `mosesaic init --interactive`."""
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr("builtins.input", lambda _: "y")
    mock_run = MagicMock(return_value=MagicMock(returncode=0))
    with patch("subprocess.run", mock_run):
        with patch("mosesaic.team.serve.main") as mock_main:
            _handle_no_config(with_mcp=False, host=None, port=None)
    mock_run.assert_called_once()
    args = mock_run.call_args[0][0]
    assert "init" in args
    assert "--interactive" in args


# ── main() dispatch ───────────────────────────────────────────────────────────

def test_main_calls_handle_no_config_on_missing_config(tmp_path, monkeypatch):
    """main() calls _handle_no_config when load_config() raises RuntimeError."""
    monkeypatch.chdir(tmp_path)
    with patch("mosesaic.team.serve._handle_no_config") as mock_handle:
        with patch("mosesaic.server.config.load_config", side_effect=RuntimeError("no config")):
            main(host=None, port=None, with_mcp=False)
    mock_handle.assert_called_once_with(with_mcp=False, host=None, port=None)


def test_main_no_mcp_calls_serve_rest(monkeypatch):
    """main() with with_mcp=False calls anyio.run(_serve_rest, ...)."""
    fake_config = MagicMock()
    fake_config.host = "127.0.0.1"
    fake_config.port = 8000
    with patch("mosesaic.server.config.load_config", return_value=fake_config):
        with patch("anyio.run") as mock_anyio:
            main(host=None, port=None, with_mcp=False)
    mock_anyio.assert_called_once()
    args = mock_anyio.call_args[0]
    from mosesaic.team.serve import _serve_rest
    assert args[0] is _serve_rest
    assert args[1] is fake_config
    assert args[2] is None   # host forwarded
    assert args[3] is None   # port forwarded


def test_main_with_mcp_calls_serve_with_mcp(monkeypatch):
    """main() with with_mcp=True calls anyio.run(_serve_with_mcp, ...)."""
    fake_config = MagicMock()
    fake_config.host = "127.0.0.1"
    fake_config.port = 8000
    with patch("mosesaic.server.config.load_config", return_value=fake_config):
        with patch("anyio.run") as mock_anyio:
            main(host="0.0.0.0", port=9000, with_mcp=True)
    mock_anyio.assert_called_once()
    args = mock_anyio.call_args[0]
    from mosesaic.team.serve import _serve_with_mcp
    assert args[0] is _serve_with_mcp
    assert args[1] is fake_config
    assert args[2] == "0.0.0.0"  # host forwarded
    assert args[3] == 9000        # port forwarded
