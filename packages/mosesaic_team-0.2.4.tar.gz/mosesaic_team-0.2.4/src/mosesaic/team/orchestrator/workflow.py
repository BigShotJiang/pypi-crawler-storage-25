"""orchestrate_workflow — chains chief_director → phase directors in sequence."""
from __future__ import annotations

from mosesaic.workflow.definition import workflow
from mosesaic.workflow.context import WorkflowContext
from mosesaic.workflow.step import step
from mosesaic.team.orchestrator.context import ProjectContext
from mosesaic.team.orchestrator.director import DirectorInput, DirectorPlan
from mosesaic.team.orchestrator.protocol import PhaseInput, PhaseOutput, OrchestrateResult, RunLogEntry


@workflow(name="orchestrate", timeout_seconds=600, budget_usd=5.0)
async def orchestrate_workflow(ctx: WorkflowContext) -> OrchestrateResult:
    """Full orchestration pipeline.

    1. chief_director analyses the prompt and selects phases.
    2. Each selected phase director runs in sequence, updating ProjectContext.
    3. Returns OrchestrateResult with the final context, run log, and costs.

    Args:
        ctx.input: DirectorInput(prompt=...) from the caller.
    """
    req: DirectorInput = ctx.input

    # Phase 0: Chief Director decides which phases to run
    plan: DirectorPlan = await step("chief_director", req)

    # Initialise shared project context from the director's decision
    project_ctx = ProjectContext(
        goal=req.prompt,
        request_type=plan.request_type,
    )

    run_log: list[RunLogEntry] = []
    total_cost_usd: float = 0.0

    # Run each selected phase in sequence
    for phase in plan.phases:
        phase_output: PhaseOutput = await step(
            f"{phase}_director",
            PhaseInput(context=project_ctx, phase=phase),
            key=f"phase_{phase}",
        )
        project_ctx = phase_output.context
        run_log.append(RunLogEntry(
            phase=phase_output.phase,
            summary=phase_output.summary,
            cost_usd=phase_output.cost_usd,
        ))
        total_cost_usd += phase_output.cost_usd

    return OrchestrateResult(
        request_type=plan.request_type,
        phases_run=plan.phases,
        context=project_ctx,
        reasoning=plan.reasoning,
        run_log=run_log,
        total_cost_usd=total_cost_usd,
    )
