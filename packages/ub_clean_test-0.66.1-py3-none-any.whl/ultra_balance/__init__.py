__version__ = "0.66.1"
__author__ = "pengyeqin"
__email__ = "xxbj433@qq.com"

from .reasoning.logical import LogicalReasoning
from .reasoning.common_sense import CommonSense
from .reasoning.decision import DecisionReasoning
from .reasoning.metacognition import MetaCognition
from .reasoning.active_learning import ActiveLearning
from .reasoning.error_reflection import ErrorReflection
from .reasoning.knowledge_update import KnowledgeUpdate
from .reasoning.transfer_learning import TransferLearning
from .reasoning.dialogue import DialogueManager

def hello():
    print("Hello from ub-clean-test!")