# CodeLedger Security

## Reporting a vulnerability

Email `security@codeledger.dev`. Include steps to reproduce, expected vs
actual behaviour, and CVE references if applicable. We commit to a
48-hour initial response.

**Scope:** Anything in `backend/`, `frontend/`, `npm/`, and `scripts/`.

**Out of scope:** Third-party MCP clients, local-only misconfigurations
that require an attacker already on the machine (rotate your credentials
first), the development fixtures under `tests/`.

## Threat model

CodeLedger's threat model assumes:

* An attacker can reach the HTTP(S) endpoint of a self-hosted CodeLedger
  server in team mode. In solo mode the server binds to loopback only
  and is inaccessible from outside the machine.
* An attacker may compromise one MCP client's credentials; the blast
  radius must be limited to that client's own data.
* An attacker **cannot** have local filesystem read access to
  `~/.codeledger/` (vault) or `.git/hooks/` (webhook secret
  installation).

## Credential storage architecture

| Location | What lives there |
| --- | --- |
| Database | User profiles. Argon2id password hashes. SHA-256 PAT hashes. Service connection metadata. All application data. **Zero** tokens, keys, or plaintext secrets. |
| Credential vault (`~/.codeledger/`) | JWT signing key, OAuth refresh tokens, API keys, OAuth client secrets, solo-mode bearer token, per-provider webhook secrets. OS keyring primary; AES-256-GCM encrypted file fallback; env vars for CI. |
| Memory only | OAuth access tokens, active JWT session tokens, OAuth state + PKCE verifiers, vault decryption key. |
| Never stored anywhere | User plaintext passwords, OAuth authorization codes, Google/GitHub identity tokens (consumed and discarded). |

## Security invariants (SEC-01 through SEC-11)

1. **SEC-01** — No credentials in the database. Only one-way hashes (Argon2id, SHA-256).
2. **SEC-02** — No credentials in logs. `log_sanitizer` redacts Bearer tokens, API keys, JWTs, and `password=…` patterns.
3. **SEC-03** — No credentials in MCP tool responses. Tool response schemas are validated in tests.
4. **SEC-04** — No plaintext credentials on disk. AES-256-GCM + PBKDF2 (600 000 iterations, random salt).
5. **SEC-05** — Authentication on every endpoint. Only `/health`, `/api/setup/status`, `/api/setup/complete`, `/api/hooks/post-commit`, and `/api/hooks/file-change` are exempt from bearer auth — the webhook endpoints require `X-Webhook-Secret`; the setup endpoints are intentionally reachable before auth is configured so the first-time walkthrough can run.
6. **SEC-06** — OAuth `state` + PKCE S256 on every OAuth flow.
7. **SEC-07** — Argon2id for passwords (memory cost 64 MB, time cost 3, parallelism 4). No bcrypt, no SHA-256 on passwords.
8. **SEC-08** — JWT signing key lives in the credential vault only. Loaded at startup, never written elsewhere.
9. **SEC-09** — File permissions validated. Config, vault, and SQLite files must not be world-readable (POSIX `o+r` bits denied; Windows ACL check via `pywin32`). Server refuses to start otherwise.
10. **SEC-10** — PATs are SHA-256 hashed before storage. Plaintext PAT exists only in the vault and in the user's MCP client config.
11. **SEC-11** — No structural change without an audit record. Every change-detection event (git post-commit hook or file watcher) that detects structural AST changes produces either a linked decision or an `unlinked_commit` / `unlinked_file_change` record.

## Hardened request pipeline

The FastAPI runtime applies the following layered defences on every request:

* **Security headers** — `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY`, `X-XSS-Protection`, `Referrer-Policy: strict-origin-when-cross-origin`, `Permissions-Policy` locked down, `Strict-Transport-Security` on TLS. The server banner is removed.
* **Body size limit** — requests larger than 10 MB are rejected with `413` before reaching any handler.
* **Global exception handler** — unhandled exceptions return `500 {"detail": "Internal server error"}` with no stack trace.
* **Rate limiting** — `/api/auth/*` limited to 5/minute, `/mcp` to 120/minute, embedding-heavy `/api/context/relevant` and `/api/context/for-file` to 30/minute. Keyed by remote address.
* **CORS** — solo mode allows only `http://localhost` and `http://127.0.0.1` at the configured port plus the Vite dev server. Team mode reads an explicit allow-list from `CODELEDGER_ALLOWED_ORIGINS`. Wildcard origins are rejected because they are incompatible with credentialed requests.
* **Input size validation** — `backend/mcp/tool_handlers.py` enforces per-field ceilings (decision title 512 bytes, description 16 KB, context content 1 MB, file content 5 MB) before any handler touches the DB, embedder, or AST tracker.
* **Path traversal defence** — `backend/utils/snapshot_store.py` and `backend/utils/file_watcher.py` both resolve every candidate path against the configured project root and raise `ValueError` on any path that escapes.

## Dependency audits

Every commit that changes `pyproject.toml` or `package.json` runs
`pip-audit` and `npm audit`. No findings above `high` severity are
allowed to ship.

## Known limitations

* **File-watcher mode lacks CI verification** — no commit hash means no
  CI webhook can attach. Operators who need `verify.status` must `git
  init` and run `codeledger init --reinstall-hooks`.
* **Coverage delta sensor** is unavailable for snapshot events. The
  `HarnessScore.coverage_delta` field is `None` in file-watcher
  projects by design.
* **Team mode requires a reverse proxy for TLS** — CodeLedger does not
  terminate TLS itself. Put nginx, Caddy, or a cloud load balancer in
  front of the server for anything beyond a trusted LAN.

## Known dev-tool audit findings (not shipped to users)

A pre-launch audit surfaces the following advisories in *development* or
*scanner* tooling that never ships with `pip install codeledger-ai`:

| Package | Severity | Scope | Notes |
|---|---|---|---|
| `gitpython 3.0.6` | moderate | trufflehog dependency; pulled in only when running the secret scanner | Not imported by the runtime; affects only the QA scanner environment. |
| `pip 24.0` | moderate | installer tool | Upgrade `pip` in the developer environment. |
| `pytest 8.3.5` | moderate | dev-only | Not shipped. |
| `diskcache 5.6.3` | moderate | orphan — leftover from fastmcp 2.x; no package requires it | Can be safely uninstalled. |
| `vite` / `vite-node` / `vitest` (frontend dev deps) | moderate | dev/test tooling; the built bundle does not include them | Upgrade when `vitest 2.x` stabilises. |

All four *runtime* advisories surfaced pre-launch (cryptography, fastmcp,
pyjwt, starlette) were closed by the dependency bump recorded in
`pyproject.toml`. `npm audit --audit-level=high` returns zero findings
across the `npm/` wrapper and zero HIGH/CRITICAL for the frontend.
