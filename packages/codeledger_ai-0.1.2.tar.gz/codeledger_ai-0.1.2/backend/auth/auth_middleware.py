"""FastAPI authentication middleware.

Extracts credentials from incoming requests in priority order:

1. ``Authorization: Bearer <token>`` header (MCP clients, dashboard API)
2. ``codeledger_session`` HttpOnly cookie (dashboard browser)
3. ``CODELEDGER_TOKEN`` environment variable (CI, headless Docker)

A token that matches either a JWT session token or a PAT is accepted. On
success, the resolved ``User`` is attached to ``request.state.user``. On any
failure, the request is rejected with HTTP 401.

Security invariants enforced:
- SEC-05: Every endpoint requires auth (except paths listed in the optional
  whitelist). There is no anonymous access beyond ``/health``.
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse

from backend.auth.auth_service import AuthError

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from starlette.requests import Request
    from starlette.responses import Response
    from starlette.types import ASGIApp

    from backend.auth.auth_service import AuthService


_COOKIE_NAME = "codeledger_session"
_ENV_TOKEN_NAME = "CODELEDGER_TOKEN"


class AuthMiddleware(BaseHTTPMiddleware):
    """Starlette middleware that gates every request on a valid credential."""

    def __init__(
        self,
        app: ASGIApp,
        auth_service: AuthService,
        *,
        public_paths: frozenset[str] | None = None,
    ) -> None:
        super().__init__(app)
        self._auth = auth_service
        self._public_paths: frozenset[str] = public_paths or frozenset({"/health"})

    async def dispatch(
        self,
        request: Request,
        call_next: Callable[[Request], Awaitable[Response]],
    ) -> Response:
        if request.url.path in self._public_paths:
            return await call_next(request)

        token = self._extract_token(request)
        if not token:
            return _unauthorized("Missing credentials")

        try:
            user = await self._resolve_user(token)
        except AuthError as exc:
            return _unauthorized(str(exc))

        request.state.user = user
        return await call_next(request)

    def _extract_token(self, request: Request) -> str | None:
        auth_header = request.headers.get("authorization", "")
        if auth_header.lower().startswith("bearer "):
            return auth_header[7:].strip() or None

        cookie_value = request.cookies.get(_COOKIE_NAME)
        if cookie_value:
            return cookie_value

        env_token = os.environ.get(_ENV_TOKEN_NAME)
        if env_token:
            return env_token

        return None

    async def _resolve_user(self, token: str) -> object:
        """Return a User for the token, trying JWT first, then PAT."""
        # JWT session tokens are structured (three dot-separated segments).
        if token.count(".") == 2:
            try:
                payload = self._auth.verify_jwt(token)
            except AuthError:
                pass
            else:
                from backend.models import User

                rows = await self._auth._db.query("users", {"id": payload["sub"]})
                if not rows:
                    raise AuthError("User not found for JWT subject")
                return User.from_dict(rows[0])

        return await self._auth.validate_pat(token)


def _unauthorized(detail: str) -> JSONResponse:
    return JSONResponse(
        status_code=401,
        content={"detail": detail},
        headers={"WWW-Authenticate": "Bearer"},
    )
