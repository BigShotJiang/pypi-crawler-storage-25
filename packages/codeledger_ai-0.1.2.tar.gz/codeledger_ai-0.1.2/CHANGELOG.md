# Changelog

## 0.1.2 — 2026-04-16

### Fixed
- **Windows compatibility.** Replaced `sqlite-vss` (no Windows wheel
  published) with `sqlite-vec`, the actively-maintained successor by
  the same author. Windows wheels are available for all supported
  CPython versions, so `pip install codeledger-ai` now works on
  Windows, macOS, and Linux without additional native-toolchain
  prerequisites.

### Changed
- Internal vector index now uses `sqlite-vec`'s `vec0` virtual table
  with `distance_metric=cosine` (was `sqlite-vss`'s `vss0` with
  squared-L2). Scoring semantics are preserved: `score = 1 - distance`
  gives cosine similarity in `[-1.0, 1.0]`. Vectors are serialized as
  packed `float32` bytes instead of JSON strings — smaller index size
  for the same data.
- Internal table renamed: `vss_items` → `vec_items`. The
  `SqliteVssStore` class name is retained for API stability.

### Migration
- New installs on 0.1.2 get the new schema automatically.
- Upgrading from 0.1.1 on Linux/macOS: existing vectors live in the
  old `vss_items` virtual table, which no longer exists in 0.1.2. The
  simplest reset is to delete `data/codeledger.db` and re-run
  `codeledger init` for a clean slate — decisions, stories, sessions,
  and provenance records rebuild from source via the change-detection
  backend on the next commit or file save. 0.1.1 was available for
  under a day, so the migration impact is minimal.

## 0.1.1 — 2026-04-16

First real PyPI release. Full MCP server with ~50 tools:
bidirectional code provenance, active context injection via Claude
Code hooks, independent quality harness, drift detection,
tautological-test detection, rollback impact planning. Solo mode
free; team mode with shared decision history. Onboarding walkthrough
at `http://localhost:8100`. Linux and macOS support (Windows blocked
by sqlite-vss native wheel — fixed in 0.1.2).

## 0.0.1 — 0.0.2

Name-reservation placeholders. Yanked.
