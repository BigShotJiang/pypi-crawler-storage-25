"""Test the Google Maps MCP server using OpenAI Agents SDK."""

import asyncio
import os
import sys
from pathlib import Path
from dotenv import load_dotenv

# Add project root to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root / "src"))

# Load environment variables
env_path = project_root / ".env"
load_dotenv(env_path)

from agents import Agent, Runner, HostedMCPTool
from agents.mcp import MCPServerStdio


async def test_mcp_server():
    """Test the MCP server with OpenAI Agents SDK."""
    
    # Check required environment variables
    openai_key = os.getenv("OPENAI_API_KEY")
    mcp_api_key = os.getenv("MCP_API_KEY")
    mcp_host = os.getenv("MCP_HOST", "localhost")
    mcp_port = os.getenv("MCP_PORT", "8000")
    
    if not openai_key:
        print("ERROR: OPENAI_API_KEY environment variable is required for testing.")
        print("Please set it in your .env file.")
        return
    
    if not mcp_api_key:
        print("WARNING: MCP_API_KEY not set. Testing without authentication.")
        print("Make sure your server is running in development mode (no auth).")
    
    # MCP server URL
    mcp_url = f"http://{mcp_host}:{mcp_port}/mcp"
    
    print("=" * 70)
    print("Google Maps MCP Server - Test with OpenAI Agents SDK")
    print("=" * 70)
    print(f"MCP Server URL: {mcp_url}")
    print(f"Authentication: {'Enabled' if mcp_api_key else 'Disabled'}")
    print()
    
    # Create agent with MCP tool
    try:
        tool_config = {
            "type": "mcp",
            "server_label": "google-maps",
            "server_url": mcp_url,
            "require_approval": "never",
        }
        
        # Some clients support headers, but HostedMCPTool may need different setup
        # For now, we'll test without auth if MCP_API_KEY is not set
        # In production, you'd configure headers properly
        
        agent = Agent(
            name="Maps Search Assistant",
            instructions=(
                "You are a helpful assistant that searches Google Maps for places. "
                "When a user asks about finding places, use the search_places tool to find "
                "relevant locations. Format your responses clearly with the place name, "
                "address, phone number (if available), website (if available), rating, "
                "and whether it's currently open. Provide the Google Maps URL for easy access."
            ),
            tools=[
                HostedMCPTool(tool_config=tool_config)
            ],
        )
        
        print("Agent created successfully!")
        print()
        
        # Test queries
        test_queries = [
            "Find specialty coffee shops in San Francisco",
            "Search for pizza restaurants in New York City, limit to 5 results",
            "Find cafes with high ratings near me",
        ]
        
        for i, query in enumerate(test_queries, 1):
            print(f"\n{'=' * 70}")
            print(f"Test {i}/{len(test_queries)}: {query}")
            print(f"{'=' * 70}")
            print()
            
            try:
                result = await Runner.run(agent, query)
                
                print("Agent Response:")
                print("-" * 70)
                print(result.final_output)
                print("-" * 70)
                
                # Check if agent used the tool
                if result.steps:
                    print("\nExecution Steps:")
                    for step in result.steps:
                        if hasattr(step, 'tool_calls') and step.tool_calls:
                            for tool_call in step.tool_calls:
                                print(f"  - Tool: {tool_call.name}")
                                if hasattr(tool_call, 'arguments'):
                                    print(f"    Arguments: {tool_call.arguments}")
                
            except Exception as e:
                print(f"ERROR during test: {str(e)}")
                print(f"Error type: {type(e).__name__}")
                import traceback
                traceback.print_exc()
            
            print()
        
        print("=" * 70)
        print("Testing completed!")
        print("=" * 70)
        
    except Exception as e:
        print(f"ERROR creating agent: {str(e)}")
        print(f"Error type: {type(e).__name__}")
        import traceback
        traceback.print_exc()
        print()
        print("Make sure:")
        print("  1. The MCP server is running: python run.py")
        print("  2. OPENAI_API_KEY is set in .env")
        print("  3. The server URL is correct")


async def test_direct_tool_call():
    """Test direct tool call without agent (for debugging)."""
    
    print("\n" + "=" * 70)
    print("Direct Tool Test (Debug Mode)")
    print("=" * 70)
    
    # Import the tools directly
    from google_maps_mcp.tools import GoogleMapsTools
    
    tools = GoogleMapsTools()
    
    try:
        result = await tools.search_places(
            "coffee in San Francisco",
            max_results=5
        )
        
        print(f"\nQuery: {result['query']}")
        print(f"Total Results: {result['total_results']}")
        print("\nPlaces Found:")
        print("-" * 70)
        
        for place in result['places']:
            print(f"\n📍 {place['name']}")
            print(f"   Address: {place['address']}")
            if place.get('phone'):
                print(f"   Phone: {place['phone']}")
            if place.get('website'):
                print(f"   Website: {place['website']}")
            if place.get('rating'):
                print(f"   Rating: {place['rating']}/5 ({place.get('reviews_count', 0)} reviews)")
            if place.get('is_open_now') is not None:
                status = "🟢 Open Now" if place['is_open_now'] else "🔴 Closed"
                print(f"   Status: {status}")
            print(f"   Maps: {place['google_maps_url']}")
        
        await tools.close()
        
    except Exception as e:
        print(f"ERROR: {str(e)}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    print("\n")
    print("🔍 Google Maps MCP Server Test Suite")
    print("\nChoose test mode:")
    print("  1. Full Agent Test (requires OpenAI API key)")
    print("  2. Direct Tool Test (debug mode, no OpenAI needed)")
    print("  3. Run both")
    print()
    
    choice = input("Enter choice (1/2/3) [default: 3]: ").strip() or "3"
    
    if choice in ["1", "3"]:
        asyncio.run(test_mcp_server())
    
    if choice in ["2", "3"]:
        asyncio.run(test_direct_tool_call())

