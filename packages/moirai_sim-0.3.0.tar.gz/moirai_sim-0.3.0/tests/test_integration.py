"""
Integration tests — multiple modules working together.

These tests verify cross-module interactions (events, shared resources,
phased execution) rather than single-module behaviour in isolation.
"""

from __future__ import annotations

import pytest

from moirai import Simulation, SimulationState
from moirai.clock import Clock
from moirai.examples.economy import EconomyModule
from moirai.examples.epidemic import EpidemicModule
from moirai.examples.population import PopulationModule
from moirai.examples.weather import WeatherModule
from moirai.scenario import Scenario
from moirai.snapshot import Snapshot


# ---------------------------------------------------------------------------
# Weather + Population
# ---------------------------------------------------------------------------


class TestWeatherPopulationIntegration:
    @pytest.fixture()
    def sim(self) -> Simulation:
        s = Simulation(seed=42)
        s.attach(WeatherModule(initial_temp=20.0, max_daily_delta=0))
        s.attach(PopulationModule(initial_mood=100.0))
        return s

    def test_mood_increases_in_comfort_zone(self, sim: Simulation) -> None:
        """With max_delta=0 and initial_temp=20, mood should rise."""
        sim.run(10)
        assert sim.resources.get("population_mood") > 100.0

    def test_event_pipeline(self, sim: Simulation) -> None:
        """WeatherModule emits temperature_changed, PopulationModule reacts."""
        events: list[float] = []
        sim.eventbus.subscribe(
            "temperature_changed", lambda value, **_: events.append(value)
        )
        sim.run(5)
        assert len(events) == 5

    def test_phase_ordering_respected(self, sim: Simulation) -> None:
        """environment phase runs before agents phase."""
        order: list[str] = []
        sim.eventbus.subscribe(
            "temperature_changed", lambda **_: order.append("weather")
        )
        # PopulationModule records mood after weather runs, so weather event
        # should appear before the tick increments
        sim.run(1)
        assert order == ["weather"]


# ---------------------------------------------------------------------------
# Full stack: Weather + Population + Epidemic + Economy
# ---------------------------------------------------------------------------


class TestFullStackIntegration:
    @pytest.fixture()
    def sim(self) -> Simulation:
        s = Simulation(
            seed=1,
            clock=Clock(time_step=1.0, unit="day"),
        )
        s.attach(WeatherModule(initial_temp=15.0, seasonal=True))
        s.attach(PopulationModule(initial_mood=80.0))
        s.attach(
            EpidemicModule(population=10_000, initial_infected=50, beta=0.35, gamma=0.12)
        )
        s.attach(EconomyModule(initial_gdp=1_000_000.0))
        return s

    def test_all_resources_set_after_attach(self, sim: Simulation) -> None:
        assert sim.resources.has("temperature")
        assert sim.resources.has("population_mood")
        assert sim.resources.has("sir_S")
        assert sim.resources.has("gdp")

    def test_all_metrics_tracked_after_run(self, sim: Simulation) -> None:
        sim.run(30)
        for key in ("temperature", "population_mood", "I", "gdp"):
            assert key in sim.metrics

    def test_ticks_correct(self, sim: Simulation) -> None:
        sim.run(90)
        assert sim.ticks == 90

    def test_state_idle_after_run(self, sim: Simulation) -> None:
        sim.run(10)
        assert sim.state is SimulationState.IDLE

    def test_population_conserved(self, sim: Simulation) -> None:
        sim.run(100)
        s = sim.resources.get_typed("sir_S", float)
        i = sim.resources.get_typed("sir_I", float)
        r = sim.resources.get_typed("sir_R", float)
        assert abs(s + i + r - 10_000) < 1e-4

    def test_reproducibility_full_stack(self) -> None:
        def make(seed: int) -> Simulation:
            s = Simulation(seed=seed, clock=Clock())
            s.attach(WeatherModule())
            s.attach(PopulationModule())
            s.attach(EpidemicModule(population=1_000, initial_infected=10))
            s.attach(EconomyModule())
            return s

        s1 = make(99)
        s1.run(50)
        s2 = make(99)
        s2.run(50)
        assert s1.resources.get("gdp") == s2.resources.get("gdp")
        assert s1.resources.get("temperature") == s2.resources.get("temperature")


# ---------------------------------------------------------------------------
# Snapshot round-trip
# ---------------------------------------------------------------------------


class TestSnapshotIntegration:
    def test_snapshot_captures_all_module_names(self) -> None:
        sim = Simulation(seed=0)
        sim.attach(WeatherModule())
        sim.attach(EpidemicModule())
        sim.run(10)
        snap = sim.snapshot()
        assert "WeatherModule" in snap.module_names
        assert "EpidemicModule" in snap.module_names

    def test_snapshot_metrics_match_simulation(self) -> None:
        sim = Simulation(seed=0)
        sim.attach(WeatherModule())
        sim.run(20)
        snap = sim.snapshot()
        assert snap.metrics["temperature"] == sim.metrics.history("temperature")

    def test_snapshot_resources_match(self) -> None:
        sim = Simulation(seed=0)
        sim.attach(WeatherModule())
        sim.run(20)
        snap = sim.snapshot()
        assert snap.resources["temperature"] == sim.resources.get("temperature")


# ---------------------------------------------------------------------------
# Scenario integration
# ---------------------------------------------------------------------------


class TestScenarioIntegration:
    def test_n_seeds_produce_n_snapshots(self) -> None:
        result = Scenario(
            lambda seed: _make_full(seed),
            seeds=range(5),
        ).run(steps=30)
        assert result.n == 5

    def test_ensemble_peak_I_positive(self) -> None:
        result = Scenario(
            lambda seed: _epi_sim(seed),
            seeds=range(8),
        ).run(steps=100)
        peaks = result.peak_values("I")
        assert all(p > 0 for p in peaks)

    def test_cross_run_summary_sane(self) -> None:
        result = Scenario(
            lambda seed: _epi_sim(seed),
            seeds=range(10),
        ).run(steps=100)
        s = result.cross_run_summary("I")
        assert s.n == 10
        assert 0 <= s.min <= s.mean <= s.max


# ---------------------------------------------------------------------------
# Clock integration
# ---------------------------------------------------------------------------


class TestClockIntegration:
    def test_time_advances_correctly(self) -> None:
        from datetime import datetime

        sim = Simulation(
            seed=0,
            clock=Clock(time_step=1.0, unit="day", start_date=datetime(2025, 1, 1)),
        )
        sim.attach(WeatherModule())
        sim.run(31)
        assert sim.clock.format_time(sim.ticks) == "2025-02-01"

    def test_time_property_matches_clock(self) -> None:
        sim = Simulation(seed=0, clock=Clock(time_step=7.0, unit="day"))
        sim.attach(WeatherModule())
        sim.run(4)
        assert sim.time == pytest.approx(28.0)


# ---------------------------------------------------------------------------
# Seasonal weather integration
# ---------------------------------------------------------------------------


class TestSeasonalWeatherIntegration:
    def test_temperature_oscillates_over_year(self) -> None:
        """Seasonal mode should produce different temps in summer vs winter."""
        sim = Simulation(seed=42)
        sim.attach(WeatherModule(initial_temp=10.0, seasonal=True, seasonal_amplitude=12.0))
        sim.run(365)
        history = sim.metrics.history("temperature")

        # Summer (days 150-200) should be warmer than winter (days 330-365)
        summer = history[150:200]
        winter = history[330:365]
        assert sum(summer) / len(summer) > sum(winter) / len(winter)

    def test_invalid_damping_raises(self) -> None:
        with pytest.raises(ValueError):
            WeatherModule(damping=0.0)

        with pytest.raises(ValueError):
            WeatherModule(damping=1.5)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_full(seed: int) -> Simulation:
    sim = Simulation(seed=seed)
    sim.attach(WeatherModule())
    sim.attach(PopulationModule())
    return sim


def _epi_sim(seed: int) -> Simulation:
    sim = Simulation(seed=seed)
    sim.attach(EpidemicModule(population=1_000, initial_infected=10))
    return sim
