"""
Shared pytest fixtures for Moirai test suite.
"""

from __future__ import annotations

import pytest

from moirai import Simulation
from moirai.clock import Clock
from moirai.examples.economy import EconomyModule
from moirai.examples.epidemic import EpidemicModule
from moirai.examples.population import PopulationModule
from moirai.examples.weather import WeatherModule


@pytest.fixture()
def sim() -> Simulation:
    """Bare simulation with seed=42."""
    return Simulation(seed=42)


@pytest.fixture()
def sim_with_clock() -> Simulation:
    """Simulation with a daily clock starting 2025-01-01."""
    from datetime import datetime

    return Simulation(
        seed=42,
        clock=Clock(time_step=1.0, unit="day", start_date=datetime(2025, 1, 1)),
    )


@pytest.fixture()
def weather_sim() -> Simulation:
    """Simulation with a WeatherModule attached."""
    s = Simulation(seed=0)
    s.attach(WeatherModule(initial_temp=20.0, max_daily_delta=2))
    return s


@pytest.fixture()
def full_sim() -> Simulation:
    """Simulation with WeatherModule + PopulationModule."""
    s = Simulation(seed=42)
    s.attach(WeatherModule(initial_temp=20.0))
    s.attach(PopulationModule(initial_mood=100.0))
    return s


@pytest.fixture()
def epidemic_sim() -> Simulation:
    """Simulation with EpidemicModule (small population for fast tests)."""
    s = Simulation(seed=1)
    s.attach(EpidemicModule(population=1_000, initial_infected=10))
    return s


@pytest.fixture()
def economy_sim() -> Simulation:
    """Simulation with EconomyModule."""
    s = Simulation(seed=5)
    s.attach(EconomyModule(initial_gdp=100_000.0, base_growth=0.03))
    return s
