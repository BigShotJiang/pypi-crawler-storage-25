"""
Unit tests for moirai.scheduler.Scheduler.
"""

from __future__ import annotations

import pytest

from moirai.scheduler import Scheduler


class TestScheduleAt:
    def test_fires_at_correct_tick(self) -> None:
        sched = Scheduler()
        log: list[int] = []
        sched.schedule_at(5, lambda: log.append(5))
        for t in range(10):
            sched.process(t)
        assert log == [5]

    def test_fires_only_once(self) -> None:
        sched = Scheduler()
        log: list[int] = []
        sched.schedule_at(3, lambda: log.append(1))
        for t in range(10):
            sched.process(t)
        assert len(log) == 1

    def test_multiple_one_shots_at_same_tick(self) -> None:
        sched = Scheduler()
        log: list[str] = []
        sched.schedule_at(2, lambda: log.append("a"))
        sched.schedule_at(2, lambda: log.append("b"))
        sched.process(2)
        assert set(log) == {"a", "b"}

    def test_fires_at_tick_zero(self) -> None:
        sched = Scheduler()
        fired: list[bool] = []
        sched.schedule_at(0, lambda: fired.append(True))
        sched.process(0)
        assert fired == [True]

    def test_negative_tick_raises(self) -> None:
        with pytest.raises(ValueError):
            Scheduler().schedule_at(-1, lambda: None)

    def test_not_fired_before_tick(self) -> None:
        sched = Scheduler()
        log: list[int] = []
        sched.schedule_at(10, lambda: log.append(1))
        for t in range(10):
            sched.process(t)
        assert log == []


class TestScheduleEvery:
    def test_fires_repeatedly(self) -> None:
        sched = Scheduler()
        log: list[int] = []
        sched.schedule_every(3, lambda: log.append(1))
        for t in range(12):
            sched.process(t)
        # fires at t=0, 3, 6, 9
        assert len(log) == 4

    def test_delay_respected(self) -> None:
        sched = Scheduler()
        log: list[int] = []
        sched.schedule_every(3, lambda: log.append(1), delay=2)
        for t in range(10):
            sched.process(t)
        # fires at t=2, 5, 8
        assert len(log) == 3

    def test_interval_less_than_1_raises(self) -> None:
        with pytest.raises(ValueError):
            Scheduler().schedule_every(0, lambda: None)

    def test_independent_recurring_schedules(self) -> None:
        sched = Scheduler()
        a: list[int] = []
        b: list[int] = []
        sched.schedule_every(2, lambda: a.append(1))
        sched.schedule_every(3, lambda: b.append(1))
        for t in range(7):
            sched.process(t)
        # a: 0, 2, 4, 6 → 4 fires
        # b: 0, 3, 6 → 3 fires
        assert len(a) == 4
        assert len(b) == 3


class TestCancel:
    def test_cancel_prevents_firing(self) -> None:
        sched = Scheduler()
        log: list[int] = []
        handle = sched.schedule_at(5, lambda: log.append(1))
        sched.cancel(handle)
        for t in range(10):
            sched.process(t)
        assert log == []

    def test_cancel_recurring(self) -> None:
        sched = Scheduler()
        log: list[int] = []
        handle = sched.schedule_every(2, lambda: log.append(1))
        sched.process(0)  # fires once
        sched.cancel(handle)
        for t in range(1, 10):
            sched.process(t)
        assert len(log) == 1

    def test_cancel_unknown_handle_returns_false(self) -> None:
        sched = Scheduler()
        result = sched.cancel(9999)
        assert result is False

    def test_cancel_valid_handle_returns_true(self) -> None:
        sched = Scheduler()
        handle = sched.schedule_at(5, lambda: None)
        assert sched.cancel(handle) is True


class TestClear:
    def test_clear_removes_all(self) -> None:
        sched = Scheduler()
        log: list[int] = []
        sched.schedule_at(1, lambda: log.append(1))
        sched.schedule_every(2, lambda: log.append(2))
        sched.clear()
        for t in range(10):
            sched.process(t)
        assert log == []

    def test_len_after_clear(self) -> None:
        sched = Scheduler()
        sched.schedule_at(1, lambda: None)
        sched.schedule_at(2, lambda: None)
        sched.clear()
        assert len(sched) == 0


class TestErrorIsolation:
    def test_raising_callback_does_not_abort_others(self) -> None:
        sched = Scheduler()
        log: list[str] = []

        def bad() -> None:
            raise RuntimeError("boom")

        sched.schedule_at(1, bad)
        sched.schedule_at(1, lambda: log.append("ok"))
        sched.process(1)
        assert log == ["ok"]


class TestIntrospection:
    def test_pending_entries(self) -> None:
        sched = Scheduler()
        h1 = sched.schedule_at(5, lambda: None)
        h2 = sched.schedule_every(3, lambda: None, delay=2)
        pending = sched.pending()
        handles = {p[0] for p in pending}
        assert h1 in handles
        assert h2 in handles

    def test_len(self) -> None:
        sched = Scheduler()
        assert len(sched) == 0
        sched.schedule_at(1, lambda: None)
        sched.schedule_at(2, lambda: None)
        assert len(sched) == 2

    def test_repr(self) -> None:
        sched = Scheduler()
        sched.schedule_at(1, lambda: None)
        assert "pending=1" in repr(sched)
