"""
Unit tests for moirai.snapshot.Snapshot.
"""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

import pytest

from moirai import Simulation
from moirai.examples.weather import WeatherModule
from moirai.snapshot import Snapshot


@pytest.fixture()
def ran_sim() -> Simulation:
    sim = Simulation(seed=7)
    sim.attach(WeatherModule(initial_temp=15.0))
    sim.run(20)
    return sim


class TestCapture:
    def test_tick_matches(self, ran_sim: Simulation) -> None:
        snap = ran_sim.snapshot()
        assert snap.tick == ran_sim.ticks

    def test_seed_matches(self, ran_sim: Simulation) -> None:
        snap = ran_sim.snapshot()
        assert snap.seed == ran_sim.seed

    def test_metrics_captured(self, ran_sim: Simulation) -> None:
        snap = ran_sim.snapshot()
        assert "temperature" in snap.metrics
        assert len(snap.metrics["temperature"]) == 21  # setup + 20 ticks

    def test_resources_captured(self, ran_sim: Simulation) -> None:
        snap = ran_sim.snapshot()
        assert "temperature" in snap.resources

    def test_module_names_captured(self, ran_sim: Simulation) -> None:
        snap = ran_sim.snapshot()
        assert "WeatherModule" in snap.module_names

    def test_state_string(self, ran_sim: Simulation) -> None:
        snap = ran_sim.snapshot()
        assert snap.state == "idle"

    def test_time_elapsed(self, ran_sim: Simulation) -> None:
        snap = ran_sim.snapshot()
        assert snap.time_elapsed == pytest.approx(ran_sim.clock.elapsed(ran_sim.ticks))

    def test_captured_at_is_iso(self, ran_sim: Simulation) -> None:
        snap = ran_sim.snapshot()
        # Should not raise
        from datetime import datetime

        datetime.fromisoformat(snap.captured_at)


class TestSaveLoad:
    def test_round_trip(self, ran_sim: Simulation) -> None:
        snap = ran_sim.snapshot()
        with tempfile.NamedTemporaryFile(
            suffix=".json", delete=False, mode="w"
        ) as f:
            tmp = Path(f.name)
        try:
            snap.save(tmp)
            loaded = Snapshot.load(tmp)
            assert loaded.tick == snap.tick
            assert loaded.seed == snap.seed
            assert loaded.metrics == snap.metrics
        finally:
            tmp.unlink(missing_ok=True)

    def test_saved_file_is_valid_json(self, ran_sim: Simulation) -> None:
        snap = ran_sim.snapshot()
        with tempfile.NamedTemporaryFile(
            suffix=".json", delete=False, mode="w"
        ) as f:
            tmp = Path(f.name)
        try:
            snap.save(tmp)
            data = json.loads(tmp.read_text(encoding="utf-8"))
            assert "tick" in data
            assert "seed" in data
        finally:
            tmp.unlink(missing_ok=True)

    def test_load_invalid_json_raises(self) -> None:
        with tempfile.NamedTemporaryFile(
            suffix=".json", delete=False, mode="w", encoding="utf-8"
        ) as f:
            f.write("not valid json {{{{")
            tmp = Path(f.name)
        try:
            with pytest.raises(ValueError, match="Invalid JSON"):
                Snapshot.load(tmp)
        finally:
            tmp.unlink(missing_ok=True)

    def test_load_missing_file_raises(self) -> None:
        with pytest.raises(FileNotFoundError):
            Snapshot.load(Path("does_not_exist_xyz.json"))


class TestSummary:
    def test_summary_contains_tick(self, ran_sim: Simulation) -> None:
        snap = ran_sim.snapshot()
        text = snap.summary()
        assert "tick=20" in text

    def test_summary_contains_seed(self, ran_sim: Simulation) -> None:
        snap = ran_sim.snapshot()
        assert str(snap.seed) in snap.summary()


class TestRepr:
    def test_repr(self, ran_sim: Simulation) -> None:
        snap = ran_sim.snapshot()
        r = repr(snap)
        assert "Snapshot" in r
        assert str(snap.tick) in r
