"""
Unit tests for :class:`moirai.Simulation`.

Covers: init, attach/detach, tick/run, state machine, pause, on() decorator,
scheduler integration, clock integration, summary, snapshot, reset, repr.
"""

from __future__ import annotations

import pytest

from moirai import Simulation, SimulationState
from moirai.clock import Clock
from moirai.exceptions import (
    ModuleAlreadyAttachedError,
    ModuleNotFoundError,
    SimulationAlreadyRunningError,
)
from moirai.module import Module


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class CounterModule(Module):
    phase: str = "default"

    def __init__(self, phase: str = "default", priority: int = 0) -> None:
        self.phase = phase
        self.priority = priority
        self.setup_calls = 0
        self.update_calls = 0
        self.teardown_calls = 0
        self.reset_calls = 0

    def setup(self, sim: Simulation) -> None:
        self.setup_calls += 1

    def update(self, sim: Simulation) -> None:
        self.update_calls += 1

    def teardown(self, sim: Simulation) -> None:
        self.teardown_calls += 1

    def reset(self, sim: Simulation) -> None:
        self.reset_calls += 1


class PhaseTrackerModule(Module):
    """Records the order in which update() is called across modules."""

    call_log: list[str]  # shared across instances via injection

    def __init__(self, label: str, phase: str, priority: int = 0) -> None:
        self._label = label
        self.phase = phase
        self.priority = priority
        self.call_log = []  # overridden from outside

    def setup(self, sim: Simulation) -> None:
        pass

    def update(self, sim: Simulation) -> None:
        self.call_log.append(self._label)

    def teardown(self, sim: Simulation) -> None:
        pass


# ---------------------------------------------------------------------------
# Initialisation
# ---------------------------------------------------------------------------


class TestSimulationInit:
    def test_explicit_seed(self, sim: Simulation) -> None:
        assert sim.seed == 42

    def test_no_seed_auto_assigned(self) -> None:
        s = Simulation()
        assert isinstance(s.seed, int)
        assert s.seed >= 1

    def test_reproducible_rng(self) -> None:
        s1, s2 = Simulation(seed=7), Simulation(seed=7)
        assert [s1.rng.random() for _ in range(5)] == [s2.rng.random() for _ in range(5)]

    def test_initial_state_idle(self, sim: Simulation) -> None:
        assert sim.state is SimulationState.IDLE

    def test_initial_ticks_zero(self, sim: Simulation) -> None:
        assert sim.ticks == 0

    def test_initial_modules_empty(self, sim: Simulation) -> None:
        assert sim.modules == []

    def test_default_clock(self, sim: Simulation) -> None:
        assert sim.clock.unit == "day"
        assert sim.clock.time_step == 1.0

    def test_custom_clock(self) -> None:
        c = Clock(time_step=7.0, unit="week")
        s = Simulation(seed=1, clock=c)
        assert s.clock is c

    def test_subsystems_present(self, sim: Simulation) -> None:
        assert sim.eventbus is not None
        assert sim.metrics is not None
        assert sim.resources is not None
        assert sim.scheduler is not None


# ---------------------------------------------------------------------------
# time property
# ---------------------------------------------------------------------------


class TestTimeProperty:
    def test_time_zero_at_start(self, sim: Simulation) -> None:
        assert sim.time == 0.0

    def test_time_advances_after_run(self, sim: Simulation) -> None:
        sim.attach(CounterModule())
        sim.run(10)
        assert sim.time == pytest.approx(10.0)

    def test_time_with_custom_step(self) -> None:
        s = Simulation(seed=1, clock=Clock(time_step=7.0, unit="week"))
        s.attach(CounterModule())
        s.run(4)
        assert s.time == pytest.approx(28.0)


# ---------------------------------------------------------------------------
# attach()
# ---------------------------------------------------------------------------


class TestAttach:
    def test_setup_called_on_attach(self, sim: Simulation) -> None:
        m = CounterModule()
        sim.attach(m)
        assert m.setup_calls == 1

    def test_module_in_property(self, sim: Simulation) -> None:
        m = CounterModule()
        sim.attach(m)
        assert m in sim.modules

    def test_returns_self_for_chaining(self, sim: Simulation) -> None:
        assert sim.attach(CounterModule()) is sim

    def test_double_attach_raises(self, sim: Simulation) -> None:
        m = CounterModule()
        sim.attach(m)
        with pytest.raises(ModuleAlreadyAttachedError):
            sim.attach(m)

    def test_phase_priority_ordering(self, sim: Simulation) -> None:
        log: list[str] = []
        modules = [
            PhaseTrackerModule("z_p0", "z", priority=0),
            PhaseTrackerModule("a_p1", "a", priority=1),
            PhaseTrackerModule("a_p0", "a", priority=0),
        ]
        for m in modules:
            m.call_log = log
            sim.attach(m)
        sim.tick()
        # a_p0 first, then a_p1, then z_p0
        assert log == ["a_p0", "a_p1", "z_p0"]

    def test_attachment_order_tiebreaker(self, sim: Simulation) -> None:
        """Same phase+priority → attachment order preserved."""
        log: list[str] = []
        m1 = PhaseTrackerModule("first", "default")
        m2 = PhaseTrackerModule("second", "default")
        m1.call_log = m2.call_log = log
        sim.attach(m1).attach(m2)
        sim.tick()
        assert log == ["first", "second"]


# ---------------------------------------------------------------------------
# detach()
# ---------------------------------------------------------------------------


class TestDetach:
    def test_teardown_called_on_detach(self, sim: Simulation) -> None:
        m = CounterModule()
        sim.attach(m)
        sim.detach(m)
        assert m.teardown_calls == 1

    def test_module_removed_from_list(self, sim: Simulation) -> None:
        m = CounterModule()
        sim.attach(m)
        sim.detach(m)
        assert m not in sim.modules

    def test_returns_self_for_chaining(self, sim: Simulation) -> None:
        m = CounterModule()
        sim.attach(m)
        assert sim.detach(m) is sim

    def test_detach_unknown_raises(self, sim: Simulation) -> None:
        with pytest.raises(ModuleNotFoundError):
            sim.detach(CounterModule())


# ---------------------------------------------------------------------------
# enabled flag
# ---------------------------------------------------------------------------


class TestEnabledFlag:
    def test_disabled_module_skipped_in_tick(self, sim: Simulation) -> None:
        m = CounterModule()
        m.enabled = False
        sim.attach(m)
        sim.run(5)
        assert m.update_calls == 0

    def test_re_enabling_resumes_updates(self, sim: Simulation) -> None:
        m = CounterModule()
        m.enabled = False
        sim.attach(m)
        sim.run(3)
        m.enabled = True
        sim.run(2)
        assert m.update_calls == 2


# ---------------------------------------------------------------------------
# tick() and run()
# ---------------------------------------------------------------------------


class TestTick:
    def test_tick_updates_all_enabled_modules(self, sim: Simulation) -> None:
        m1, m2 = CounterModule(), CounterModule()
        sim.attach(m1).attach(m2)
        sim.tick()
        assert m1.update_calls == 1 and m2.update_calls == 1

    def test_tick_increments_counter(self, sim: Simulation) -> None:
        sim.tick()
        assert sim.ticks == 1

    def test_tick_fires_scheduler(self, sim: Simulation) -> None:
        fired: list[bool] = []
        sim.scheduler.schedule_at(0, lambda: fired.append(True))
        sim.tick()
        assert fired == [True]

    def test_tick_emits_start_end_events(self, sim: Simulation) -> None:
        log: list[str] = []
        sim.eventbus.subscribe("tick_start", lambda **_: log.append("start"))
        sim.eventbus.subscribe("tick_end", lambda **_: log.append("end"))
        sim.tick()
        assert log == ["start", "end"]


class TestRun:
    def test_run_n_steps(self, sim: Simulation) -> None:
        m = CounterModule()
        sim.attach(m)
        sim.run(10)
        assert m.update_calls == 10 and sim.ticks == 10

    def test_run_default_one_step(self, sim: Simulation) -> None:
        sim.attach(CounterModule())
        sim.run()
        assert sim.ticks == 1

    def test_run_returns_ticks_run(self, sim: Simulation) -> None:
        sim.attach(CounterModule())
        result = sim.run(5)
        assert result == 5

    def test_run_invalid_steps_raises(self, sim: Simulation) -> None:
        with pytest.raises(ValueError):
            sim.run(0)

    def test_run_emits_lifecycle_events(self, sim: Simulation) -> None:
        log: list[str] = []
        sim.eventbus.subscribe("run_start", lambda **_: log.append("start"))
        sim.eventbus.subscribe("run_end", lambda **_: log.append("end"))
        sim.run(3)
        assert log == ["start", "end"]

    def test_run_accumulates_ticks(self, sim: Simulation) -> None:
        sim.run(3)
        sim.run(7)
        assert sim.ticks == 10

    def test_run_while_running_raises(self, sim: Simulation) -> None:
        """Calling run() from inside a module update should raise."""

        class ReentrantModule(Module):
            def setup(self, s: Simulation) -> None:
                pass

            def update(self, s: Simulation) -> None:
                with pytest.raises(SimulationAlreadyRunningError):
                    s.run(1)

            def teardown(self, s: Simulation) -> None:
                pass

        sim.attach(ReentrantModule())
        sim.run(1)  # outer call must not raise


# ---------------------------------------------------------------------------
# State machine
# ---------------------------------------------------------------------------


class TestState:
    def test_state_idle_initially(self, sim: Simulation) -> None:
        assert sim.state is SimulationState.IDLE

    def test_state_running_during_run(self, sim: Simulation) -> None:
        states_seen: list[str] = []

        class StateObserver(Module):
            def setup(self, s: Simulation) -> None:
                pass

            def update(self, s: Simulation) -> None:
                states_seen.append(s.state.value)

            def teardown(self, s: Simulation) -> None:
                pass

        sim.attach(StateObserver())
        sim.run(1)
        assert "running" in states_seen

    def test_state_idle_after_run(self, sim: Simulation) -> None:
        sim.run(1)
        assert sim.state is SimulationState.IDLE


# ---------------------------------------------------------------------------
# pause()
# ---------------------------------------------------------------------------


class TestPause:
    def test_pause_stops_loop_early(self, sim: Simulation) -> None:
        class PausingModule(Module):
            def setup(self, s: Simulation) -> None:
                pass

            def update(self, s: Simulation) -> None:
                if s.ticks == 2:
                    s.pause()

            def teardown(self, s: Simulation) -> None:
                pass

        sim.attach(PausingModule())
        ticks_run = sim.run(10)
        assert ticks_run < 10
        assert sim.state is SimulationState.PAUSED

    def test_can_resume_after_pause(self, sim: Simulation) -> None:
        class OneShotPauser(Module):
            _paused = False

            def setup(self, s: Simulation) -> None:
                pass

            def update(self, s: Simulation) -> None:
                if not self._paused and s.ticks == 3:
                    self._paused = True
                    s.pause()

            def teardown(self, s: Simulation) -> None:
                pass

        sim.attach(OneShotPauser())
        sim.run(10)
        assert sim.state is SimulationState.PAUSED
        sim.run(5)  # resume
        assert sim.ticks > 4

    def test_pause_outside_run_is_noop(self, sim: Simulation) -> None:
        sim.pause()  # should not raise or change state
        assert sim.state is SimulationState.IDLE


# ---------------------------------------------------------------------------
# on() decorator
# ---------------------------------------------------------------------------


class TestOnDecorator:
    def test_on_subscribes_handler(self, sim: Simulation) -> None:
        received: list[float] = []

        @sim.on("temperature_changed")
        def handler(value: float, **_):  # type: ignore[misc]
            received.append(value)

        sim.eventbus.emit("temperature_changed", value=22.0)
        assert received == [22.0]

    def test_on_returns_original_function(self, sim: Simulation) -> None:
        def handler(**_):  # type: ignore[misc]
            pass

        result = sim.on("e")(handler)
        assert result is handler

    def test_on_wildcard(self, sim: Simulation) -> None:
        log: list[str] = []

        @sim.on("*")
        def catch_all(**_):  # type: ignore[misc]
            log.append("caught")

        sim.eventbus.emit("anything")
        assert "caught" in log


# ---------------------------------------------------------------------------
# Scheduler integration in simulation
# ---------------------------------------------------------------------------


class TestSchedulerIntegration:
    def test_scheduler_fires_within_run(self, sim: Simulation) -> None:
        log: list[int] = []
        sim.scheduler.schedule_at(3, lambda: log.append(sim.ticks))
        sim.run(5)
        assert log == [3]

    def test_scheduler_recurring_within_run(self, sim: Simulation) -> None:
        log: list[int] = []
        sim.scheduler.schedule_every(2, lambda: log.append(sim.ticks))
        sim.run(6)
        # fires at t=0, 2, 4 → before module updates
        assert len(log) == 3


# ---------------------------------------------------------------------------
# summary()
# ---------------------------------------------------------------------------


class TestSummary:
    def test_summary_contains_seed(self, sim: Simulation) -> None:
        assert "42" in sim.summary()

    def test_summary_contains_state(self, sim: Simulation) -> None:
        assert "idle" in sim.summary()

    def test_summary_lists_modules(self, sim: Simulation) -> None:
        sim.attach(CounterModule())
        assert "CounterModule" in sim.summary()

    def test_summary_disabled_marked(self, sim: Simulation) -> None:
        m = CounterModule()
        m.enabled = False
        sim.attach(m)
        text = sim.summary()
        # disabled marker ○ should appear
        assert "○" in text


# ---------------------------------------------------------------------------
# reset()
# ---------------------------------------------------------------------------


class TestReset:
    def test_reset_calls_module_reset(self, sim: Simulation) -> None:
        m = CounterModule()
        sim.attach(m)
        sim.run(5)
        sim.reset()
        assert m.reset_calls == 1

    def test_reset_clears_ticks(self, sim: Simulation) -> None:
        sim.run(5)
        sim.reset()
        assert sim.ticks == 0

    def test_reset_clears_metrics(self, sim: Simulation) -> None:
        sim.metrics.track("x", 1)
        sim.reset()
        assert sim.metrics.history("x") == []

    def test_reset_clears_resources(self, sim: Simulation) -> None:
        sim.resources.set("k", 42)
        sim.reset()
        assert not sim.resources.has("k")

    def test_reset_restores_rng_reproducibility(self, sim: Simulation) -> None:
        first = [sim.rng.random() for _ in range(5)]
        sim.reset()
        second = [sim.rng.random() for _ in range(5)]
        assert first == second

    def test_reset_clears_scheduler(self, sim: Simulation) -> None:
        sim.scheduler.schedule_at(100, lambda: None)
        sim.reset()
        assert len(sim.scheduler) == 0

    def test_state_idle_after_reset(self, sim: Simulation) -> None:
        sim.run(1)
        sim.reset()
        assert sim.state is SimulationState.IDLE


# ---------------------------------------------------------------------------
# repr
# ---------------------------------------------------------------------------


class TestRepr:
    def test_repr_contains_seed(self, sim: Simulation) -> None:
        assert "seed=42" in repr(sim)

    def test_repr_contains_ticks(self, sim: Simulation) -> None:
        sim.run(3)
        assert "ticks=3" in repr(sim)

    def test_repr_contains_state(self, sim: Simulation) -> None:
        assert "idle" in repr(sim)
