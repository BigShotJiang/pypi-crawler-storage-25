"""
Unit tests for moirai.clock.Clock.
"""

from __future__ import annotations

from datetime import datetime

import pytest

from moirai.clock import Clock


class TestClockDefaults:
    def test_defaults(self) -> None:
        c = Clock()
        assert c.time_step == 1.0
        assert c.unit == "day"
        assert c.start_date is None

    def test_elapsed_equals_ticks_times_step(self) -> None:
        c = Clock(time_step=7.0)
        assert c.elapsed(4) == 28.0

    def test_elapsed_zero_ticks(self) -> None:
        assert Clock().elapsed(0) == 0.0


class TestClockTicksFor:
    def test_exact_division(self) -> None:
        assert Clock(time_step=2.0).ticks_for(10.0) == 5

    def test_ceiling(self) -> None:
        # 10 / 3 = 3.33... → 4
        assert Clock(time_step=3.0).ticks_for(10.0) == 4

    def test_fractional_step(self) -> None:
        # 0.5 units/tick → 2 ticks per unit → 20 ticks for 10 units
        assert Clock(time_step=0.5).ticks_for(10.0) == 20

    def test_invalid_step_raises(self) -> None:
        with pytest.raises(ValueError):
            Clock(time_step=0.0).ticks_for(1.0)


class TestClockCurrentDate:
    def test_no_start_date_returns_none(self) -> None:
        assert Clock().current_date(10) is None

    def test_start_date_advances(self) -> None:
        c = Clock(time_step=1.0, start_date=datetime(2025, 1, 1))
        date = c.current_date(30)
        assert date is not None
        assert date.year == 2025
        assert date.month == 1 or date.month == 2  # within January or February

    def test_90_days_from_jan1(self) -> None:
        c = Clock(time_step=1.0, start_date=datetime(2025, 1, 1))
        d = c.current_date(90)
        assert d is not None
        assert d == datetime(2025, 4, 1)


class TestClockFormatTime:
    def test_format_without_start_date(self) -> None:
        c = Clock(time_step=1.0, unit="day")
        assert c.format_time(10) == "t=10 day(s)"

    def test_format_with_start_date(self) -> None:
        c = Clock(time_step=1.0, start_date=datetime(2025, 1, 1))
        assert c.format_time(0) == "2025-01-01"
        assert c.format_time(31) == "2025-02-01"

    def test_format_fractional(self) -> None:
        c = Clock(time_step=0.5, unit="hour")
        result = c.format_time(3)
        assert "1.50" in result or "1.5" in result

    def test_step_label(self) -> None:
        c = Clock(time_step=7.0, unit="week")
        assert "7.0" in c.step_label
        assert "week" in c.step_label


class TestClockRepr:
    def test_repr_no_start_date(self) -> None:
        r = repr(Clock(time_step=2.0, unit="hour"))
        assert "time_step=2.0" in r
        assert "unit='hour'" in r
        assert "start_date" not in r

    def test_repr_with_start_date(self) -> None:
        r = repr(Clock(start_date=datetime(2025, 6, 1)))
        assert "start_date" in r
