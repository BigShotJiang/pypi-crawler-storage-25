"""
Unit tests for moirai.scenario.Scenario and ScenarioResult.
"""

from __future__ import annotations

import pytest

from moirai import Simulation
from moirai.examples.epidemic import EpidemicModule
from moirai.examples.weather import WeatherModule
from moirai.scenario import CrossRunSummary, Scenario, ScenarioResult


# ---------------------------------------------------------------------------
# Factory helpers
# ---------------------------------------------------------------------------


def _make_weather_sim(seed: int) -> Simulation:
    sim = Simulation(seed=seed)
    sim.attach(WeatherModule(initial_temp=20.0, max_daily_delta=2))
    return sim


def _make_epidemic_sim(seed: int) -> Simulation:
    sim = Simulation(seed=seed)
    sim.attach(EpidemicModule(population=1_000, initial_infected=10))
    return sim


# ---------------------------------------------------------------------------
# Scenario
# ---------------------------------------------------------------------------


class TestScenario:
    @pytest.fixture()
    def result(self) -> ScenarioResult:
        return Scenario(_make_weather_sim, seeds=range(5)).run(steps=30)

    def test_correct_number_of_snapshots(self, result: ScenarioResult) -> None:
        assert result.n == 5

    def test_seeds_recorded(self, result: ScenarioResult) -> None:
        assert result.seeds == list(range(5))

    def test_steps_recorded(self, result: ScenarioResult) -> None:
        assert result.steps == 30

    def test_all_snapshots_have_correct_tick(self, result: ScenarioResult) -> None:
        for snap in result.snapshots:
            assert snap.tick == 30

    def test_snapshots_have_temperature_metric(self, result: ScenarioResult) -> None:
        for snap in result.snapshots:
            assert "temperature" in snap.metrics

    def test_different_seeds_different_outcomes(self) -> None:
        result = Scenario(_make_weather_sim, seeds=[0, 1, 2, 3, 4]).run(steps=50)
        finals = result.final_values("temperature")
        # Not all final temperatures should be identical
        assert len(set(f"{v:.3f}" for v in finals)) > 1

    def test_repr(self) -> None:
        s = Scenario(_make_weather_sim, seeds=[1, 2])
        assert "Scenario" in repr(s)


class TestScenarioSingleSeed:
    def test_single_seed(self) -> None:
        result = Scenario(_make_weather_sim, seeds=[42]).run(steps=10)
        assert result.n == 1
        assert result.seeds == [42]


class TestScenarioEpidemic:
    @pytest.fixture()
    def epi_result(self) -> ScenarioResult:
        return Scenario(_make_epidemic_sim, seeds=range(10)).run(steps=150)

    def test_population_conserved_per_seed(self, epi_result: ScenarioResult) -> None:
        for snap in epi_result.snapshots:
            s = snap.resources.get("sir_S", 0)
            i = snap.resources.get("sir_I", 0)
            r = snap.resources.get("sir_R", 0)
            assert abs(s + i + r - 1_000.0) < 1e-4

    def test_cross_run_summary_I(self, epi_result: ScenarioResult) -> None:
        crs = epi_result.cross_run_summary("I")
        assert crs.n == 10
        assert crs.min <= crs.mean <= crs.max


# ---------------------------------------------------------------------------
# ScenarioResult
# ---------------------------------------------------------------------------


class TestScenarioResult:
    @pytest.fixture()
    def result(self) -> ScenarioResult:
        return Scenario(_make_weather_sim, seeds=range(8)).run(steps=20)

    def test_final_values_length(self, result: ScenarioResult) -> None:
        finals = result.final_values("temperature")
        assert len(finals) == 8

    def test_final_values_unknown_metric_empty(self, result: ScenarioResult) -> None:
        assert result.final_values("nonexistent") == []

    def test_peak_values_length(self, result: ScenarioResult) -> None:
        peaks = result.peak_values("temperature")
        assert len(peaks) == 8

    def test_peaks_ge_finals(self, result: ScenarioResult) -> None:
        for peak, final in zip(
            result.peak_values("temperature"), result.final_values("temperature")
        ):
            assert peak >= final - 1e-9  # allow float epsilon


# ---------------------------------------------------------------------------
# CrossRunSummary
# ---------------------------------------------------------------------------


class TestCrossRunSummary:
    def test_basic_statistics(self) -> None:
        result = Scenario(_make_weather_sim, seeds=range(20)).run(steps=50)
        crs = result.cross_run_summary("temperature")
        assert crs.n == 20
        assert crs.min <= crs.mean <= crs.max
        assert crs.std >= 0.0

    def test_empty_metric_returns_zero_summary(self) -> None:
        result = Scenario(_make_weather_sim, seeds=range(3)).run(steps=5)
        crs = result.cross_run_summary("nonexistent")
        assert crs.n == 0
        assert crs.mean == 0.0

    def test_str_with_data(self) -> None:
        result = Scenario(_make_weather_sim, seeds=range(5)).run(steps=10)
        crs = result.cross_run_summary("temperature")
        text = str(crs)
        assert "CrossRunSummary" in text
        assert "n=5" in text

    def test_str_no_data(self) -> None:
        crs = CrossRunSummary(metric="x", n=0, min=0, max=0, mean=0, std=0)
        assert "no data" in str(crs)


# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------


class TestScenarioResultSummary:
    def test_summary_string(self) -> None:
        result = Scenario(_make_weather_sim, seeds=range(3)).run(steps=10)
        text = result.summary("temperature")
        assert "ScenarioResult" in text
        assert "temperature" in text

    def test_summary_auto_metrics(self) -> None:
        result = Scenario(_make_weather_sim, seeds=range(2)).run(steps=5)
        text = result.summary()
        assert "temperature" in text
