"""
Unit tests for all Moirai modules and subsystems.

Covers: EventBus (once, wildcard), Metrics (summary, export),
ResourceContainer (get_typed, update, setdefault), Module (enabled, name,
priority), WeatherModule, PopulationModule, EpidemicModule, EconomyModule.
"""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

import pytest

from moirai import Simulation
from moirai.eventbus import EventBus
from moirai.exceptions import ResourceNotFoundError, ResourceTypeError
from moirai.metrics import MetricSummary, Metrics
from moirai.module import Module
from moirai.resources import ResourceContainer
from moirai.examples.economy import EconomyModule
from moirai.examples.epidemic import EpidemicModule
from moirai.examples.population import PopulationModule
from moirai.examples.weather import WeatherModule


# ===========================================================================
# EventBus
# ===========================================================================


class TestEventBus:
    @pytest.fixture()
    def bus(self) -> EventBus:
        return EventBus()

    # --- basics ---
    def test_subscribe_and_emit(self, bus: EventBus) -> None:
        received: list[float] = []
        bus.subscribe("e", lambda value: received.append(value))
        bus.emit("e", value=42.0)
        assert received == [42.0]

    def test_multiple_subscribers_ordered(self, bus: EventBus) -> None:
        log: list[str] = []
        bus.subscribe("e", lambda: log.append("a"))
        bus.subscribe("e", lambda: log.append("b"))
        bus.emit("e")
        assert log == ["a", "b"]

    def test_emit_no_subscribers_silent(self, bus: EventBus) -> None:
        bus.emit("ghost")  # must not raise

    def test_duplicate_subscribe_idempotent(self, bus: EventBus) -> None:
        log: list[int] = []
        h = lambda: log.append(1)  # noqa: E731
        bus.subscribe("e", h)
        bus.subscribe("e", h)
        bus.emit("e")
        assert log == [1]

    def test_unsubscribe(self, bus: EventBus) -> None:
        log: list[int] = []
        h = lambda value: log.append(value)  # noqa: E731
        bus.subscribe("e", h)
        bus.unsubscribe("e", h)
        bus.emit("e", value=1)
        assert log == []

    def test_unsubscribe_unknown_silent(self, bus: EventBus) -> None:
        bus.unsubscribe("e", lambda: None)  # must not raise

    def test_unsubscribe_all_for_event(self, bus: EventBus) -> None:
        log: list[int] = []
        bus.subscribe("e", lambda value: log.append(value))
        bus.unsubscribe_all("e")
        bus.emit("e", value=1)
        assert log == []

    def test_unsubscribe_all(self, bus: EventBus) -> None:
        log: list[int] = []
        bus.subscribe("a", lambda: log.append(1))
        bus.subscribe("b", lambda: log.append(2))
        bus.unsubscribe_all()
        bus.emit("a")
        bus.emit("b")
        assert log == []

    def test_handler_exception_isolated(self, bus: EventBus) -> None:
        log: list[str] = []
        bus.subscribe("e", lambda: (_ for _ in ()).throw(RuntimeError("boom")))
        bus.subscribe("e", lambda: log.append("ok"))
        bus.emit("e")
        assert log == ["ok"]

    # --- once ---
    def test_once_fires_exactly_once(self, bus: EventBus) -> None:
        log: list[int] = []
        bus.once("e", lambda value: log.append(value))
        bus.emit("e", value=1)
        bus.emit("e", value=2)
        assert log == [1]

    def test_once_auto_unsubscribed(self, bus: EventBus) -> None:
        bus.once("e", lambda: None)
        bus.emit("e")
        assert bus.subscribers("e") == []

    # --- wildcard ---
    def test_wildcard_receives_all_events(self, bus: EventBus) -> None:
        log: list[str] = []
        bus.subscribe("*", lambda **_: log.append("*"))
        bus.emit("a")
        bus.emit("b")
        assert log == ["*", "*"]

    def test_wildcard_fires_before_specific(self, bus: EventBus) -> None:
        log: list[str] = []
        bus.subscribe("*", lambda **_: log.append("wildcard"))
        bus.subscribe("e", lambda **_: log.append("specific"))
        bus.emit("e")
        assert log == ["wildcard", "specific"]

    # --- introspection ---
    def test_subscribers_snapshot(self, bus: EventBus) -> None:
        h = lambda: None  # noqa: E731
        bus.subscribe("e", h)
        assert h in bus.subscribers("e")

    def test_events_sorted(self, bus: EventBus) -> None:
        bus.subscribe("z", lambda: None)
        bus.subscribe("a", lambda: None)
        assert bus.events() == ["a", "z"]

    def test_repr(self, bus: EventBus) -> None:
        bus.subscribe("e", lambda: None)
        assert "e" in repr(bus)


# ===========================================================================
# Metrics
# ===========================================================================


class TestMetrics:
    @pytest.fixture()
    def metrics(self) -> Metrics:
        return Metrics()

    def test_track_and_history(self, metrics: Metrics) -> None:
        metrics.track("x", 1)
        metrics.track("x", 2)
        assert metrics.history("x") == [1, 2]

    def test_history_unknown_empty(self, metrics: Metrics) -> None:
        assert metrics.history("nope") == []

    def test_latest(self, metrics: Metrics) -> None:
        metrics.track("x", 10)
        metrics.track("x", 20)
        assert metrics.latest("x") == 20

    def test_latest_unknown_none(self, metrics: Metrics) -> None:
        assert metrics.latest("nope") is None

    def test_snapshot(self, metrics: Metrics) -> None:
        metrics.track("a", 1)
        assert metrics.snapshot() == {"a": [1]}

    def test_all_latest(self, metrics: Metrics) -> None:
        metrics.track("a", 1)
        metrics.track("a", 5)
        metrics.track("b", 9)
        assert metrics.all() == {"a": 5, "b": 9}

    def test_reset_single(self, metrics: Metrics) -> None:
        metrics.track("a", 1)
        metrics.track("b", 2)
        metrics.reset("a")
        assert metrics.history("a") == []
        assert metrics.history("b") == [2]

    def test_reset_all(self, metrics: Metrics) -> None:
        metrics.track("a", 1)
        metrics.reset()
        assert len(metrics) == 0

    def test_contains(self, metrics: Metrics) -> None:
        metrics.track("k", 1)
        assert "k" in metrics
        assert "z" not in metrics

    def test_keys_sorted(self, metrics: Metrics) -> None:
        metrics.track("b", 1)
        metrics.track("a", 1)
        assert metrics.keys() == ["a", "b"]

    # --- summary ---
    def test_summary_basic_stats(self, metrics: Metrics) -> None:
        for v in [1.0, 2.0, 3.0, 4.0, 5.0]:
            metrics.track("x", v)
        s = metrics.summary("x")
        assert isinstance(s, MetricSummary)
        assert s.count == 5
        assert s.min == pytest.approx(1.0)
        assert s.max == pytest.approx(5.0)
        assert s.mean == pytest.approx(3.0)
        assert s.latest == pytest.approx(5.0)

    def test_summary_empty_key(self, metrics: Metrics) -> None:
        s = metrics.summary("nothing")
        assert s.count == 0
        assert s.latest is None

    def test_summary_single_value_std_zero(self, metrics: Metrics) -> None:
        metrics.track("x", 5.0)
        assert metrics.summary("x").std == 0.0

    def test_summary_str(self, metrics: Metrics) -> None:
        metrics.track("x", 1.0)
        metrics.track("x", 2.0)
        text = str(metrics.summary("x"))
        assert "MetricSummary" in text

    # --- export ---
    def test_export_json(self, metrics: Metrics) -> None:
        metrics.track("a", 1)
        metrics.track("a", 2)
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as f:
            tmp = Path(f.name)
        try:
            metrics.export_json(tmp)
            data = json.loads(tmp.read_text(encoding="utf-8"))
            assert data == {"a": [1, 2]}
        finally:
            tmp.unlink(missing_ok=True)

    def test_to_frame(self, metrics: Metrics) -> None:
        metrics.track("x", 1)
        frame = metrics.to_frame()
        assert frame == {"x": [1]}


# ===========================================================================
# ResourceContainer
# ===========================================================================


class TestResourceContainer:
    @pytest.fixture()
    def rc(self) -> ResourceContainer:
        return ResourceContainer()

    def test_set_get(self, rc: ResourceContainer) -> None:
        rc.set("k", 42)
        assert rc.get("k") == 42

    def test_get_default(self, rc: ResourceContainer) -> None:
        assert rc.get("missing", default=99) == 99

    def test_get_missing_raises(self, rc: ResourceContainer) -> None:
        with pytest.raises(ResourceNotFoundError):
            rc.get("nope")

    def test_delete(self, rc: ResourceContainer) -> None:
        rc.set("k", 1)
        rc.delete("k")
        assert not rc.has("k")

    def test_delete_missing_raises(self, rc: ResourceContainer) -> None:
        with pytest.raises(ResourceNotFoundError):
            rc.delete("nope")

    def test_has(self, rc: ResourceContainer) -> None:
        rc.set("k", 1)
        assert rc.has("k") and not rc.has("z")

    def test_clear(self, rc: ResourceContainer) -> None:
        rc.set("a", 1)
        rc.clear()
        assert len(rc) == 0

    def test_snapshot_copy(self, rc: ResourceContainer) -> None:
        rc.set("x", 10)
        snap = rc.snapshot()
        snap["x"] = 999
        assert rc.get("x") == 10  # original unchanged

    def test_overwrite(self, rc: ResourceContainer) -> None:
        rc.set("k", 1)
        rc.set("k", 2)
        assert rc.get("k") == 2

    # --- update ---
    def test_update_batch(self, rc: ResourceContainer) -> None:
        rc.update({"a": 1, "b": 2})
        assert rc.get("a") == 1 and rc.get("b") == 2

    def test_update_overwrites(self, rc: ResourceContainer) -> None:
        rc.set("a", 0)
        rc.update({"a": 99})
        assert rc.get("a") == 99

    # --- setdefault ---
    def test_setdefault_absent(self, rc: ResourceContainer) -> None:
        val = rc.setdefault("new_key", 42)
        assert val == 42
        assert rc.get("new_key") == 42

    def test_setdefault_present(self, rc: ResourceContainer) -> None:
        rc.set("k", 10)
        val = rc.setdefault("k", 99)
        assert val == 10
        assert rc.get("k") == 10

    # --- get_typed ---
    def test_get_typed_correct_type(self, rc: ResourceContainer) -> None:
        rc.set("temp", 20.0)
        result = rc.get_typed("temp", float)
        assert result == 20.0

    def test_get_typed_wrong_type_raises(self, rc: ResourceContainer) -> None:
        rc.set("temp", "hot")
        with pytest.raises(ResourceTypeError):
            rc.get_typed("temp", float)

    def test_get_typed_missing_raises(self, rc: ResourceContainer) -> None:
        with pytest.raises(ResourceNotFoundError):
            rc.get_typed("missing", float)

    def test_get_typed_with_default(self, rc: ResourceContainer) -> None:
        result = rc.get_typed("missing", float, default=0.0)
        assert result == 0.0


# ===========================================================================
# Module (abstract)
# ===========================================================================


class TestModuleAbstract:
    def test_cannot_instantiate(self) -> None:
        with pytest.raises(TypeError):
            Module()  # type: ignore[abstract]

    def test_enabled_default_true(self) -> None:
        assert WeatherModule().enabled is True

    def test_priority_default_zero(self) -> None:
        assert WeatherModule().priority == 0

    def test_name_property(self) -> None:
        assert WeatherModule().name == "WeatherModule"

    def test_repr_contains_phase(self) -> None:
        m = WeatherModule()
        assert "environment" in repr(m)

    def test_repr_enabled_disabled(self) -> None:
        m = WeatherModule()
        assert "enabled" in repr(m)
        m.enabled = False
        assert "disabled" in repr(m)

    def test_default_reset_calls_teardown_then_setup(self) -> None:
        sim = Simulation(seed=0)
        m = WeatherModule(initial_temp=15.0)
        sim.attach(m)
        sim.run(5)
        m.reset(sim)
        # After reset, temperature should be back to initial value
        assert sim.resources.get("temperature") == 15.0


# ===========================================================================
# WeatherModule
# ===========================================================================


class TestWeatherModule:
    def test_setup_seeds_temperature(self, weather_sim: Simulation) -> None:
        assert weather_sim.resources.get("temperature") == 20.0

    def test_setup_seeds_metrics(self, weather_sim: Simulation) -> None:
        assert weather_sim.metrics.history("temperature")[0] == 20.0

    def test_run_adds_history_entries(self, weather_sim: Simulation) -> None:
        weather_sim.run(10)
        assert len(weather_sim.metrics.history("temperature")) == 11

    def test_update_emits_event(self, weather_sim: Simulation) -> None:
        events: list[float] = []
        weather_sim.eventbus.subscribe(
            "temperature_changed", lambda value, **_: events.append(value)
        )
        weather_sim.run(5)
        assert len(events) == 5

    def test_temperature_bounded(self) -> None:
        sim = Simulation(seed=42)
        sim.attach(WeatherModule(initial_temp=20.0))
        sim.run(1000)
        temp = sim.resources.get_typed("temperature", float)
        assert -30.0 <= temp <= 50.0

    def test_reproducibility(self) -> None:
        def get_temp(seed: int) -> float:
            s = Simulation(seed=seed)
            s.attach(WeatherModule())
            s.run(100)
            return s.resources.get_typed("temperature", float)

        assert get_temp(7) == get_temp(7)

    def test_phase_is_environment(self) -> None:
        assert WeatherModule().phase == "environment"


# ===========================================================================
# PopulationModule
# ===========================================================================


class TestPopulationModule:
    def test_setup_seeds_mood(self, full_sim: Simulation) -> None:
        assert full_sim.resources.get("population_mood") == 100.0

    def test_run_changes_mood(self, full_sim: Simulation) -> None:
        full_sim.run(30)
        assert isinstance(full_sim.resources.get("population_mood"), float)

    def test_metrics_tracked(self, full_sim: Simulation) -> None:
        full_sim.run(10)
        assert len(full_sim.metrics.history("population_mood")) == 11

    def test_mood_bounded(self, full_sim: Simulation) -> None:
        full_sim.run(1000)
        mood = full_sim.resources.get_typed("population_mood", float)
        assert 0.0 <= mood <= 200.0

    def test_teardown_unsubscribes(self, full_sim: Simulation) -> None:
        pop = next(m for m in full_sim.modules if isinstance(m, PopulationModule))
        full_sim.detach(pop)
        assert pop._on_temperature_changed not in full_sim.eventbus.subscribers(  # type: ignore[attr-defined]
            "temperature_changed"
        )

    def test_cold_reduces_mood(self) -> None:
        sim = Simulation(seed=0)
        sim.attach(WeatherModule(initial_temp=5.0, max_daily_delta=0))
        sim.attach(PopulationModule(initial_mood=100.0))
        sim.run(1)
        assert sim.resources.get("population_mood") < 100.0

    def test_hot_reduces_mood(self) -> None:
        sim = Simulation(seed=0)
        sim.attach(WeatherModule(initial_temp=35.0, max_daily_delta=0))
        sim.attach(PopulationModule(initial_mood=100.0))
        sim.run(1)
        assert sim.resources.get("population_mood") < 100.0

    def test_comfortable_improves_mood(self) -> None:
        sim = Simulation(seed=0)
        sim.attach(WeatherModule(initial_temp=20.0, max_daily_delta=0))
        sim.attach(PopulationModule(initial_mood=100.0))
        sim.run(1)
        assert sim.resources.get("population_mood") > 100.0


# ===========================================================================
# EpidemicModule
# ===========================================================================


class TestEpidemicModule:
    def test_setup_seeds_compartments(self, epidemic_sim: Simulation) -> None:
        assert epidemic_sim.resources.has("sir_S")
        assert epidemic_sim.resources.has("sir_I")
        assert epidemic_sim.resources.has("sir_R")

    def test_initial_infected_correct(self, epidemic_sim: Simulation) -> None:
        assert epidemic_sim.resources.get_typed("sir_I", float) == pytest.approx(10.0)

    def test_population_conserved(self, epidemic_sim: Simulation) -> None:
        epidemic_sim.run(50)
        s = epidemic_sim.resources.get_typed("sir_S", float)
        i = epidemic_sim.resources.get_typed("sir_I", float)
        r = epidemic_sim.resources.get_typed("sir_R", float)
        assert s + i + r == pytest.approx(1000.0, abs=1e-6)

    def test_metrics_tracked(self, epidemic_sim: Simulation) -> None:
        epidemic_sim.run(10)
        assert len(epidemic_sim.metrics.history("I")) == 11

    def test_sir_updated_event_emitted(self, epidemic_sim: Simulation) -> None:
        events: list[dict] = []
        epidemic_sim.eventbus.subscribe(
            "sir_updated", lambda **kw: events.append(kw)
        )
        epidemic_sim.run(5)
        assert len(events) == 5

    def test_epidemic_ends_eventually(self, epidemic_sim: Simulation) -> None:
        ended: list[bool] = []
        epidemic_sim.eventbus.subscribe("epidemic_ended", lambda **_: ended.append(True))
        epidemic_sim.run(500)
        assert ended, "Epidemic should end within 500 ticks"

    def test_invalid_initial_infected_raises(self) -> None:
        with pytest.raises(ValueError):
            EpidemicModule(population=100, initial_infected=200)

    def test_phase_is_simulation(self) -> None:
        assert EpidemicModule().phase == "simulation"


# ===========================================================================
# EconomyModule
# ===========================================================================


class TestEconomyModule:
    def test_setup_seeds_resources(self, economy_sim: Simulation) -> None:
        assert economy_sim.resources.has("gdp")
        assert economy_sim.resources.has("inflation")
        assert economy_sim.resources.has("unemployment")

    def test_initial_gdp(self, economy_sim: Simulation) -> None:
        assert economy_sim.resources.get_typed("gdp", float) == pytest.approx(
            100_000.0
        )

    def test_gdp_changes_after_run(self, economy_sim: Simulation) -> None:
        economy_sim.run(10)
        gdp = economy_sim.resources.get_typed("gdp", float)
        assert gdp != pytest.approx(100_000.0)

    def test_metrics_tracked(self, economy_sim: Simulation) -> None:
        economy_sim.run(10)
        assert len(economy_sim.metrics.history("gdp")) == 11

    def test_economy_updated_event(self, economy_sim: Simulation) -> None:
        events: list[dict] = []
        economy_sim.eventbus.subscribe(
            "economy_updated", lambda **kw: events.append(kw)
        )
        economy_sim.run(3)
        assert len(events) == 3

    def test_reproducibility(self) -> None:
        def get_gdp(seed: int) -> float:
            s = Simulation(seed=seed)
            s.attach(EconomyModule())
            s.run(50)
            return s.resources.get_typed("gdp", float)

        assert get_gdp(99) == get_gdp(99)
