# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.3.0] - 2026-04-11

### Added
- `Scenario` system for multi-run experiments and cross-run analysis
- `Snapshot` for JSON serialization of simulation state
- `Scheduler` for deferred and recurring callbacks
- `Clock` with real-world time mapping and configurable units
- `ResourceContainer` for shared data between modules
- `py.typed` marker for PEP 561 type checking support
- Full test suite with coverage reporting
- Four built-in example simulations: weather, population, economy, epidemic

### Changed
- Complete rewrite of the core engine into the `src/moirai` package layout
- `Module` base class now typed and documented
- `EventBus` redesigned with typed event payloads
- `Metrics` now supports summaries and history

## [0.2.0] - 2026-04-01

### Added
- Initial `Simulation`, `Module`, `EventBus`, `Metrics` primitives
- Basic phase-based module ordering

## [0.1.0] - 2026-03-15

### Added
- Project bootstrap
