"""
Simulation clock — maps integer ticks to real-world time units.

:class:`Clock` is a lightweight value object attached to every
:class:`~moirai.Simulation`. It lets modules reason about *time* rather than
raw tick indices, making inter-module communication more expressive and
simulations easier to parameterise.

Example::

    from datetime import datetime
    from moirai.clock import Clock

    # 1 tick = 1 day, starting 1 Jan 2025
    clock = Clock(time_step=1.0, unit="day", start_date=datetime(2025, 1, 1))
    clock.format_time(90)    # "2025-04-01"
    clock.elapsed(90)        # 90.0  (days)
    clock.ticks_for(365)     # 365   (ticks to simulate one year)

    # 1 tick = 1 hour
    hourly = Clock(time_step=1.0, unit="hour")
    hourly.format_time(48)   # "t=48.0 hour(s)"
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import datetime, timedelta


@dataclass
class Clock:
    """Maps simulation ticks to real-world time units.

    Args:
        time_step: How many *units* one tick represents.
            Defaults to ``1.0`` (one unit per tick).
        unit: Human-readable label for the time unit (e.g. ``"day"``,
            ``"hour"``, ``"year"``).
        start_date: Optional calendar anchor. When set,
            :meth:`current_date` and :meth:`format_time` return actual
            calendar dates rather than elapsed counts.

    Attributes:
        time_step: Units per tick.
        unit: Name of the time unit.
        start_date: Optional calendar start.
    """

    time_step: float = 1.0
    unit: str = "day"
    start_date: datetime | None = field(default=None)

    # ------------------------------------------------------------------
    # Time conversion
    # ------------------------------------------------------------------

    def elapsed(self, ticks: int) -> float:
        """Real-world time elapsed after *ticks* simulation steps.

        Args:
            ticks: Number of completed simulation ticks.

        Returns:
            ``ticks * time_step`` in the configured unit.

        Example::

            Clock(time_step=7.0, unit="day").elapsed(4)  # 28.0 days
        """
        return ticks * self.time_step

    def ticks_for(self, duration: float) -> int:
        """Number of ticks needed to cover *duration* real-world units.

        Args:
            duration: Real-world time in the configured unit.

        Returns:
            Ceiling of ``duration / time_step``.

        Example::

            Clock(time_step=0.5).ticks_for(10)  # 20 ticks
        """
        if self.time_step <= 0:
            raise ValueError("time_step must be > 0")
        return math.ceil(duration / self.time_step)

    def current_date(self, ticks: int) -> datetime | None:
        """Calendar date after *ticks* steps, if :attr:`start_date` is set.

        The implementation assumes the unit is *days*; for other units set
        :attr:`time_step` accordingly (e.g. ``time_step=1/24`` for hours).

        Args:
            ticks: Number of completed simulation ticks.

        Returns:
            The calendar date, or ``None`` if no :attr:`start_date` was
            provided.
        """
        if self.start_date is None:
            return None
        return self.start_date + timedelta(days=self.elapsed(ticks))

    # ------------------------------------------------------------------
    # Formatting
    # ------------------------------------------------------------------

    def format_time(self, ticks: int) -> str:
        """Human-readable representation of the simulation time.

        Returns a calendar date string when :attr:`start_date` is set,
        otherwise a plain elapsed-time string.

        Args:
            ticks: Number of completed simulation ticks.

        Returns:
            Calendar date (``"YYYY-MM-DD"``) or ``"t=N.N unit(s)"``.
        """
        date = self.current_date(ticks)
        if date is not None:
            return date.strftime("%Y-%m-%d")
        total = self.elapsed(ticks)
        # Format without trailing zeros when the value is a whole number.
        formatted = f"{total:.0f}" if total == int(total) else f"{total:.2f}"
        return f"t={formatted} {self.unit}(s)"

    @property
    def step_label(self) -> str:
        """Short label for one tick (e.g. ``"1.0 day"``)."""
        return f"{self.time_step} {self.unit}"

    # ------------------------------------------------------------------
    # Dunder helpers
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        parts = [f"time_step={self.time_step}", f"unit={self.unit!r}"]
        if self.start_date is not None:
            parts.append(f"start_date={self.start_date.date()}")
        return f"Clock({', '.join(parts)})"
