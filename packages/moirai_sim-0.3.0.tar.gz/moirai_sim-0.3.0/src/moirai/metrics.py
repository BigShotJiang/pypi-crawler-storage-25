"""
Metrics collector with time-series storage and statistical summaries.

New in v0.2
-----------
* :class:`MetricSummary` — dataclass with min/max/mean/std/count/latest.
* :meth:`Metrics.summary` — compute a :class:`MetricSummary` for any key.
* :meth:`Metrics.export_json` — write the full history to a JSON file.
* :meth:`Metrics.to_frame` — return a dict compatible with ``pandas.DataFrame``.

Example::

    metrics = Metrics()
    for t in range(100):
        metrics.track("temperature", 15 + t * 0.1)

    s = metrics.summary("temperature")
    print(s.mean, s.std, s.min, s.max)

    metrics.export_json("metrics.json")
"""

from __future__ import annotations

import json
import statistics
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class MetricSummary:
    """Statistical summary for a single metric key.

    Attributes:
        key: Metric name.
        count: Number of recorded samples.
        min: Minimum value.
        max: Maximum value.
        mean: Arithmetic mean.
        std: Sample standard deviation (0.0 when count ≤ 1).
        latest: Most recently recorded value, or ``None`` if empty.
    """

    key: str
    count: int
    min: float
    max: float
    mean: float
    std: float
    latest: float | None

    def __str__(self) -> str:
        if self.count == 0:
            return f"MetricSummary({self.key!r}: no data)"
        return (
            f"MetricSummary({self.key!r}:"
            f" n={self.count}"
            f" min={self.min:.4g}"
            f" max={self.max:.4g}"
            f" mean={self.mean:.4g}"
            f" std={self.std:.4g}"
            f" latest={self.latest:.4g})"
        )


class Metrics:
    """Per-key time-series store for simulation observability.

    Values are stored in insertion order under a string key. Any numeric or
    JSON-serialisable value is accepted.

    Attributes:
        _data: Internal mapping of metric keys to recorded-value lists.
    """

    def __init__(self) -> None:
        self._data: dict[str, list[Any]] = defaultdict(list)

    # ------------------------------------------------------------------
    # Writing
    # ------------------------------------------------------------------

    def track(self, key: str, value: Any) -> None:
        """Append *value* to the series identified by *key*.

        Args:
            key: The metric name.
            value: The value to record (typically a ``float`` or ``int``).

        Example::

            metrics.track("temperature", 18.5)
        """
        self._data[key].append(value)

    def reset(self, key: str | None = None) -> None:
        """Clear recorded values for *key*, or everything if ``None``.

        Args:
            key: Metric name to clear, or ``None`` for all.
        """
        if key is None:
            self._data.clear()
        else:
            self._data.pop(key, None)

    # ------------------------------------------------------------------
    # Reading
    # ------------------------------------------------------------------

    def history(self, key: str) -> list[Any]:
        """Return the full value history for *key*.

        Args:
            key: The metric name.

        Returns:
            Copy of the recorded values list, or ``[]`` if never tracked.
        """
        return list(self._data.get(key, []))

    def latest(self, key: str) -> Any | None:
        """Return the most recently recorded value for *key*.

        Args:
            key: The metric name.

        Returns:
            The last recorded value, or ``None`` if never tracked.
        """
        series = self._data.get(key)
        return series[-1] if series else None

    def snapshot(self) -> dict[str, list[Any]]:
        """Return a shallow copy of the entire metrics store.

        Returns:
            ``{metric_name: [value, ...]}``.
        """
        return {k: list(v) for k, v in self._data.items()}

    def all(self) -> dict[str, Any]:
        """Return the latest value for every tracked key.

        Returns:
            ``{metric_name: latest_value}``.
        """
        return {k: v[-1] for k, v in self._data.items() if v}

    def keys(self) -> list[str]:
        """Return sorted names of all tracked metrics.

        Returns:
            Sorted list of key strings.
        """
        return sorted(self._data.keys())

    # ------------------------------------------------------------------
    # Statistical analysis
    # ------------------------------------------------------------------

    def summary(self, key: str) -> MetricSummary:
        """Compute a statistical summary for the series *key*.

        Values that cannot be cast to ``float`` are silently skipped.

        Args:
            key: The metric name.

        Returns:
            A :class:`MetricSummary` dataclass; all numeric fields are
            ``0.0`` and ``latest`` is ``None`` if the series is empty.
        """
        raw = self._data.get(key, [])
        data: list[float] = []
        for v in raw:
            try:
                data.append(float(v))
            except (TypeError, ValueError):
                pass

        if not data:
            return MetricSummary(
                key=key, count=0, min=0.0, max=0.0, mean=0.0, std=0.0, latest=None
            )

        return MetricSummary(
            key=key,
            count=len(data),
            min=min(data),
            max=max(data),
            mean=statistics.mean(data),
            std=statistics.stdev(data) if len(data) > 1 else 0.0,
            latest=data[-1],
        )

    # ------------------------------------------------------------------
    # Export
    # ------------------------------------------------------------------

    def export_json(self, path: str | Path) -> None:
        """Write the full metrics history to a JSON file.

        Args:
            path: Destination file path. Parent directory must exist.

        Example::

            metrics.export_json("results/metrics.json")
        """
        Path(path).write_text(
            json.dumps(self.snapshot(), default=str, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

    def to_frame(self) -> dict[str, list[Any]]:
        """Return a dict suitable for ``pandas.DataFrame(metrics.to_frame())``.

        All series are included as-is. Series with different lengths will
        produce a ragged frame if loaded directly into pandas — pad manually
        if needed.

        Returns:
            Same structure as :meth:`snapshot`.
        """
        return self.snapshot()

    # ------------------------------------------------------------------
    # Dunder helpers
    # ------------------------------------------------------------------

    def __contains__(self, key: str) -> bool:
        return key in self._data

    def __len__(self) -> int:
        return len(self._data)

    def __repr__(self) -> str:
        return f"Metrics(keys={list(self._data.keys())!r})"
