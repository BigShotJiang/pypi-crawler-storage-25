"""
Tick-based event scheduler.

:class:`Scheduler` lets you fire callbacks at a specific future tick or on a
recurring interval, without needing a dedicated module. It is integrated into
the :class:`~moirai.Simulation` runtime and is accessible via
``sim.scheduler``.

Example::

    # One-shot: fire once at tick 10
    sim.scheduler.schedule_at(10, lambda: print("Tick 10 reached!"))

    # Recurring: fire every 7 ticks
    handle = sim.scheduler.schedule_every(7, lambda: print("Weekly event"))

    # Cancel the recurring callback
    sim.scheduler.cancel(handle)

    # Schedule using the sim context (close over sim)
    sim.scheduler.schedule_every(
        30,
        lambda: sim.metrics.track("monthly_gdp", sim.resources.get("gdp", default=0)),
    )
"""

from __future__ import annotations

import itertools
import logging
from dataclasses import dataclass, field
from typing import Callable

logger = logging.getLogger(__name__)

# Handle type — an opaque integer returned by schedule_* methods.
ScheduleHandle = int

# Callback type — a zero-argument callable.
SchedulerCallback = Callable[[], None]


@dataclass(order=True)
class _Entry:
    """Internal scheduler entry, sorted by next firing tick."""

    next_tick: int
    handle: ScheduleHandle = field(compare=False)
    callback: SchedulerCallback = field(compare=False)
    interval: int | None = field(default=None, compare=False)
    # insertion_order is used as secondary sort key when next_tick is equal.
    insertion_order: int = field(default=0, compare=False)


class Scheduler:
    """A tick-aligned callback scheduler.

    Callbacks are either *one-shot* (fire once at a given tick) or
    *recurring* (fire every N ticks). All callbacks are zero-argument
    callables; use closures to capture simulation state.

    Exceptions raised by a callback are logged and suppressed so that a
    faulty callback cannot abort the simulation loop.

    Attributes:
        _entries: Heap of pending schedule entries (sorted by next_tick).
    """

    def __init__(self) -> None:
        self._entries: list[_Entry] = []
        self._counter: itertools.count[int] = itertools.count()
        self._insertion_counter: itertools.count[int] = itertools.count()

    # ------------------------------------------------------------------
    # Scheduling
    # ------------------------------------------------------------------

    def schedule_at(self, tick: int, callback: SchedulerCallback) -> ScheduleHandle:
        """Fire *callback* once at the start of *tick*.

        Args:
            tick: The tick at which to fire the callback. Must be ≥ 0.
            callback: A zero-argument callable.

        Returns:
            An opaque handle that can be passed to :meth:`cancel`.

        Raises:
            ValueError: If *tick* is negative.
        """
        if tick < 0:
            raise ValueError(f"tick must be ≥ 0, got {tick!r}")
        handle = next(self._counter)
        entry = _Entry(
            next_tick=tick,
            handle=handle,
            callback=callback,
            interval=None,
            insertion_order=next(self._insertion_counter),
        )
        self._entries.append(entry)
        self._entries.sort()
        logger.debug("Scheduled one-shot callback at tick %d (handle=%d)", tick, handle)
        return handle

    def schedule_every(
        self,
        interval: int,
        callback: SchedulerCallback,
        *,
        delay: int = 0,
    ) -> ScheduleHandle:
        """Fire *callback* repeatedly every *interval* ticks.

        Args:
            interval: Number of ticks between firings. Must be ≥ 1.
            callback: A zero-argument callable.
            delay: Number of ticks to wait before the *first* firing.
                Defaults to ``0`` (fire at the current tick on next
                :meth:`process` call).

        Returns:
            An opaque handle that can be passed to :meth:`cancel`.

        Raises:
            ValueError: If *interval* < 1.
        """
        if interval < 1:
            raise ValueError(f"interval must be ≥ 1, got {interval!r}")
        handle = next(self._counter)
        entry = _Entry(
            next_tick=delay,
            handle=handle,
            callback=callback,
            interval=interval,
            insertion_order=next(self._insertion_counter),
        )
        self._entries.append(entry)
        self._entries.sort()
        logger.debug(
            "Scheduled recurring callback every %d tick(s), delay=%d (handle=%d)",
            interval,
            delay,
            handle,
        )
        return handle

    # ------------------------------------------------------------------
    # Cancellation
    # ------------------------------------------------------------------

    def cancel(self, handle: ScheduleHandle) -> bool:
        """Remove the callback associated with *handle*.

        Args:
            handle: The handle returned by :meth:`schedule_at` or
                :meth:`schedule_every`.

        Returns:
            ``True`` if the handle was found and cancelled, ``False`` if it
            had already fired or was never registered.
        """
        before = len(self._entries)
        self._entries = [e for e in self._entries if e.handle != handle]
        cancelled = len(self._entries) < before
        if cancelled:
            logger.debug("Cancelled schedule handle %d", handle)
        return cancelled

    def clear(self) -> None:
        """Remove all pending callbacks."""
        self._entries.clear()
        logger.debug("Scheduler cleared")

    # ------------------------------------------------------------------
    # Processing
    # ------------------------------------------------------------------

    def process(self, current_tick: int) -> int:
        """Fire all callbacks whose next_tick equals *current_tick*.

        Called automatically by :meth:`~moirai.Simulation.tick` before
        module updates.

        Args:
            current_tick: The tick currently being processed.

        Returns:
            Number of callbacks fired.
        """
        due = [e for e in self._entries if e.next_tick == current_tick]
        if not due:
            return 0

        fired = 0
        reschedule: list[_Entry] = []
        fired_handles: set[ScheduleHandle] = set()

        for entry in due:
            logger.debug("Firing callback (handle=%d) at tick %d", entry.handle, current_tick)
            try:
                entry.callback()
            except Exception:  # noqa: BLE001
                logger.exception(
                    "Scheduler callback (handle=%d) raised at tick %d",
                    entry.handle,
                    current_tick,
                )
            fired += 1
            fired_handles.add(entry.handle)

            if entry.interval is not None:
                # Re-queue the recurring entry
                reschedule.append(
                    _Entry(
                        next_tick=current_tick + entry.interval,
                        handle=entry.handle,
                        callback=entry.callback,
                        interval=entry.interval,
                        insertion_order=entry.insertion_order,
                    )
                )

        # Remove fired entries, add re-queued recurring ones
        self._entries = [e for e in self._entries if e.handle not in fired_handles]
        self._entries.extend(reschedule)
        self._entries.sort()
        return fired

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    def pending(self) -> list[tuple[ScheduleHandle, int, bool]]:
        """Return information about all pending callbacks.

        Returns:
            List of ``(handle, next_tick, is_recurring)`` tuples, ordered
            by next firing tick.
        """
        return [(e.handle, e.next_tick, e.interval is not None) for e in self._entries]

    def __len__(self) -> int:
        return len(self._entries)

    def __repr__(self) -> str:
        return f"Scheduler(pending={len(self._entries)})"
