"""Moirai built-in example modules."""

from moirai.examples.weather import WeatherModule
from moirai.examples.population import PopulationModule
from moirai.examples.epidemic import EpidemicModule
from moirai.examples.economy import EconomyModule

__all__ = [
    "WeatherModule",
    "PopulationModule",
    "EpidemicModule",
    "EconomyModule",
]
