"""
Example ``PopulationModule`` — demonstrates cross-module communication.

This module reacts to temperature events published by
:class:`~moirai.examples.weather.WeatherModule` and adjusts a shared
``population_mood`` resource accordingly. It shows how modules can be
fully decoupled yet still collaborate through the event bus and resource
container.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from moirai.module import Module

if TYPE_CHECKING:
    from moirai.simulation import Simulation

# Thresholds for mood adjustments
_COLD_THRESHOLD: float = 10.0
_HOT_THRESHOLD: float = 28.0
_MOOD_MIN: float = 0.0
_MOOD_MAX: float = 200.0


class PopulationModule(Module):
    """Simulates population mood as a function of environmental temperature.

    The module subscribes to ``temperature_changed`` events emitted by
    :class:`~moirai.examples.weather.WeatherModule` and adjusts the shared
    ``population_mood`` resource on each update.

    Args:
        initial_mood: Starting mood value (0–200 scale).

    Attributes:
        phase: ``"agents"`` — runs after ``"environment"`` modules so
            temperature is already updated before mood is recalculated.

    Example::

        sim = Simulation(seed=0)
        sim.attach(WeatherModule())
        sim.attach(PopulationModule(initial_mood=100))
        sim.run(30)

        print(sim.resources.get("population_mood"))
        print(sim.metrics.history("population_mood"))
    """

    phase: str = "agents"

    def __init__(self, initial_mood: float = 100.0) -> None:
        self._initial_mood = initial_mood

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def setup(self, sim: "Simulation") -> None:
        """Seed mood into resources and subscribe to temperature events.

        Args:
            sim: The parent simulation.
        """
        sim.resources.set("population_mood", self._initial_mood)
        sim.metrics.track("population_mood", self._initial_mood)
        sim.eventbus.subscribe("temperature_changed", self._on_temperature_changed)

        # Keep a ref to the sim so the event handler can reach resources.
        self._sim = sim

    def update(self, sim: "Simulation") -> None:
        """Record the current mood to the metrics store.

        Mood adjustments happen reactively inside the event handler
        ``_on_temperature_changed``; this method simply snapshots the value
        for the metrics history.

        Args:
            sim: The parent simulation.
        """
        mood: float = sim.resources.get("population_mood")
        sim.metrics.track("population_mood", mood)

    def teardown(self, sim: "Simulation") -> None:
        """Unsubscribe from temperature events.

        Args:
            sim: The parent simulation.
        """
        sim.eventbus.unsubscribe("temperature_changed", self._on_temperature_changed)

    # ------------------------------------------------------------------
    # Event handler
    # ------------------------------------------------------------------

    def _on_temperature_changed(self, value: float, **_kwargs: object) -> None:
        """Adjust population mood based on the new temperature.

        Comfort range is [10 °C – 28 °C]. Temperatures outside this range
        reduce mood; temperatures within it improve mood slightly.

        Args:
            value: The new temperature in degrees Celsius.
            **_kwargs: Ignored extra payload keys (e.g. ``delta``).
        """
        if not hasattr(self, "_sim"):
            return  # setup not yet called (guard for edge cases)

        current_mood: float = self._sim.resources.get("population_mood")

        if value < _COLD_THRESHOLD:
            delta = -2.0
        elif value > _HOT_THRESHOLD:
            delta = -1.0
        else:
            delta = +1.0

        new_mood = max(_MOOD_MIN, min(_MOOD_MAX, current_mood + delta))
        self._sim.resources.set("population_mood", new_mood)
