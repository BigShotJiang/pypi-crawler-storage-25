"""
Example ``EpidemicModule`` — SIR compartmental disease model.

Implements the classic **Susceptible → Infected → Recovered** model:

.. math::
    \\frac{dS}{dt} = -\\beta \\frac{SI}{N}

    \\frac{dI}{dt} = \\beta \\frac{SI}{N} - \\gamma I

    \\frac{dR}{dt} = \\gamma I

Each simulation tick corresponds to one day (adjust ``time_step`` on the
:class:`~moirai.clock.Clock` to model other intervals).

Resources written
-----------------
``sir_S``, ``sir_I``, ``sir_R``
    Current compartment sizes (floats).

Metrics tracked
---------------
``S``, ``I``, ``R``
    Daily history of each compartment.

Events emitted
--------------
``sir_updated``
    Payload: ``S``, ``I``, ``R``, ``N`` (total population).
``epidemic_ended``
    Emitted once when ``I`` drops below 1 infected individual.
    Payload: ``tick``, ``total_recovered``.

Example::

    from moirai import Simulation
    from moirai.clock import Clock
    from moirai.examples.epidemic import EpidemicModule

    sim = Simulation(seed=0, clock=Clock(unit="day"))
    sim.attach(EpidemicModule(population=100_000, initial_infected=10))
    sim.run(200)

    print(sim.metrics.summary("I"))
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from moirai.module import Module

if TYPE_CHECKING:
    from moirai.simulation import Simulation


class EpidemicModule(Module):
    """SIR compartmental epidemic simulator.

    Args:
        population: Total population size (S + I + R).
        initial_infected: Seed infections at simulation start.
        beta: Transmission rate (contacts per day × probability of transmission).
            Typical range: 0.1 – 0.5.
        gamma: Recovery rate (1 / average infectious period in days).
            Typical range: 0.05 – 0.3.

    Attributes:
        phase: ``"simulation"`` — runs after environmental modules.
    """

    phase: str = "simulation"

    def __init__(
        self,
        population: int = 10_000,
        initial_infected: int = 10,
        beta: float = 0.3,
        gamma: float = 0.1,
    ) -> None:
        if initial_infected > population:
            raise ValueError("initial_infected cannot exceed population")
        self._population = population
        self._initial_infected = initial_infected
        self.beta = beta
        self.gamma = gamma
        self._ended = False

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def setup(self, sim: "Simulation") -> None:
        """Seed initial compartment values into resources and metrics.

        Args:
            sim: The parent simulation.
        """
        s = float(self._population - self._initial_infected)
        i = float(self._initial_infected)
        r = 0.0
        self._ended = False

        sim.resources.update({"sir_S": s, "sir_I": i, "sir_R": r})
        sim.metrics.track("S", s)
        sim.metrics.track("I", i)
        sim.metrics.track("R", r)

    def update(self, sim: "Simulation") -> None:
        """Advance the SIR model by one day (tick).

        Args:
            sim: The parent simulation.
        """
        s: float = sim.resources.get_typed("sir_S", float)
        i: float = sim.resources.get_typed("sir_I", float)
        r: float = sim.resources.get_typed("sir_R", float)
        n: float = s + i + r

        if n <= 0:
            return

        new_infected = self.beta * s * i / n
        new_recovered = self.gamma * i

        new_s = max(0.0, s - new_infected)
        new_i = max(0.0, i + new_infected - new_recovered)
        new_r = max(0.0, r + new_recovered)

        sim.resources.update({"sir_S": new_s, "sir_I": new_i, "sir_R": new_r})
        sim.metrics.track("S", new_s)
        sim.metrics.track("I", new_i)
        sim.metrics.track("R", new_r)

        sim.eventbus.emit("sir_updated", S=new_s, I=new_i, R=new_r, N=n)

        # Fire "epidemic_ended" once when infections drop below 1
        if not self._ended and new_i < 1.0:
            self._ended = True
            sim.eventbus.emit(
                "epidemic_ended",
                tick=sim.ticks,
                total_recovered=new_r,
            )

    def teardown(self, sim: "Simulation") -> None:
        """No cleanup required.

        Args:
            sim: The parent simulation.
        """

    def reset(self, sim: "Simulation") -> None:
        """Re-seed the epidemic from the beginning.

        Args:
            sim: The parent simulation.
        """
        self.teardown(sim)
        self.setup(sim)
