"""
Updated ``WeatherModule`` with optional seasonal temperature variation.

New in v0.2
-----------
* ``seasonal`` parameter — adds a sinusoidal annual temperature cycle.
* ``seasonal_amplitude`` — peak-to-peak half-amplitude in degrees Celsius.
* Damped random walk — temperature is pulled toward the seasonal baseline
  each day, preventing unbounded drift.

Example::

    from moirai import Simulation
    from moirai.clock import Clock
    from moirai.examples.weather import WeatherModule
    from datetime import datetime

    sim = Simulation(
        seed=42,
        clock=Clock(time_step=1.0, unit="day", start_date=datetime(2025, 1, 1)),
    )
    sim.attach(WeatherModule(initial_temp=10.0, seasonal=True, seasonal_amplitude=12.0))
    sim.run(365)

    temps = sim.metrics.history("temperature")
    # Peak around day 170 (late June), trough around day 355 (late December)
"""

from __future__ import annotations

import math
from typing import TYPE_CHECKING

from moirai.module import Module

if TYPE_CHECKING:
    from moirai.simulation import Simulation

# Hard bounds
_MIN_TEMP: float = -40.0
_MAX_TEMP: float = 55.0

# Seasonal phase offset: shift the sinusoid so peak is around mid-summer
# (day ~172 of the year for northern hemisphere summer).
_SEASONAL_PHASE_OFFSET: int = 80  # days


class WeatherModule(Module):
    """Simulates daily temperature with optional seasonal variation.

    Without seasonality the temperature follows a *damped random walk* — a
    bounded random step that also pulls toward ``initial_temp`` each tick.

    With seasonality (``seasonal=True``) the pull target follows a sinusoidal
    annual cycle centred on ``initial_temp``, so the temperature oscillates
    realistically through the year.

    Args:
        initial_temp: Starting temperature and long-run mean (°C).
        max_daily_delta: Maximum absolute random change per tick (°C).
        seasonal: If ``True``, add a sinusoidal annual temperature cycle.
        seasonal_amplitude: Half-amplitude of the annual cycle (°C).
            The temperature will swing roughly ± this value around
            ``initial_temp``.
        damping: Fraction of the gap between current temperature and the
            target baseline that is closed each tick (0 < damping ≤ 1).
            Lower values → slower mean reversion.  Default: ``0.05``.

    Attributes:
        phase: ``"environment"`` — runs before agent/population modules.

    Resources written
    -----------------
    ``temperature`` : float
        Current temperature in °C.

    Metrics tracked
    ---------------
    ``temperature`` : float
        Daily temperature history.

    Events emitted
    --------------
    ``temperature_changed``
        Payload: ``value`` (new temperature), ``delta`` (random component),
        ``baseline`` (seasonal/static target for this tick).
    """

    phase: str = "environment"

    def __init__(
        self,
        initial_temp: float = 20.0,
        max_daily_delta: int = 2,
        seasonal: bool = False,
        seasonal_amplitude: float = 10.0,
        damping: float = 0.05,
    ) -> None:
        if not 0 < damping <= 1:
            raise ValueError(f"damping must be in (0, 1], got {damping!r}")
        self._initial_temp = initial_temp
        self._max_daily_delta = max_daily_delta
        self._seasonal = seasonal
        self._seasonal_amplitude = seasonal_amplitude
        self._damping = damping

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def setup(self, sim: "Simulation") -> None:
        """Seed the initial temperature into resources and metrics.

        Args:
            sim: The parent simulation.
        """
        sim.resources.set("temperature", self._initial_temp)
        sim.metrics.track("temperature", self._initial_temp)

    def update(self, sim: "Simulation") -> None:
        """Advance temperature by one tick using a damped random walk.

        Args:
            sim: The parent simulation.
        """
        current: float = sim.resources.get_typed("temperature", float)

        # Compute the seasonal baseline for this tick
        baseline = self._baseline(sim.ticks)

        # Damped pull toward baseline + random daily noise
        pull = self._damping * (baseline - current)
        delta = sim.rng.randint(-self._max_daily_delta, self._max_daily_delta)
        new_temp = max(_MIN_TEMP, min(_MAX_TEMP, current + pull + float(delta)))

        sim.resources.set("temperature", new_temp)
        sim.metrics.track("temperature", new_temp)
        sim.eventbus.emit(
            "temperature_changed",
            value=new_temp,
            delta=delta,
            baseline=baseline,
        )

    def teardown(self, sim: "Simulation") -> None:
        """No cleanup required.

        Args:
            sim: The parent simulation.
        """

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _baseline(self, tick: int) -> float:
        """Return the target temperature for *tick*.

        When seasonal mode is off this is simply ``initial_temp``.
        When seasonal mode is on the baseline follows a sinusoidal cycle
        with a period of 365 ticks (days), shifted so the peak falls
        approximately at day 172 (northern-hemisphere summer solstice).

        Args:
            tick: Current simulation tick (0-indexed).

        Returns:
            Target temperature in °C.
        """
        if not self._seasonal:
            return self._initial_temp
        day_of_year = tick % 365
        angle = 2.0 * math.pi * (day_of_year - _SEASONAL_PHASE_OFFSET) / 365.0
        return self._initial_temp + self._seasonal_amplitude * math.sin(angle)
