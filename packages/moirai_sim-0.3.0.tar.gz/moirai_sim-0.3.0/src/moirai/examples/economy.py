"""
Example ``EconomyModule`` — stochastic macroeconomic model.

Simulates a minimal economy with three indicators:

* **GDP** — grows at a configurable base rate with Gaussian noise.
* **Inflation** — mean-reverting random walk around a target rate.
* **Unemployment** — inversely correlated with GDP growth (Okun's law proxy).

Resources written
-----------------
``gdp``, ``inflation``, ``unemployment``

Metrics tracked
---------------
``gdp``, ``inflation``, ``unemployment``

Events emitted
--------------
``economy_updated``
    Payload: ``gdp``, ``inflation``, ``unemployment``.
``recession_started``
    Emitted when GDP growth turns negative for the first time in a run.
    Payload: ``tick``, ``gdp``.
``recession_ended``
    Emitted when GDP growth turns positive again after a recession.
    Payload: ``tick``, ``gdp``.

Example::

    from moirai import Simulation
    from moirai.clock import Clock
    from moirai.examples.economy import EconomyModule

    sim = Simulation(seed=7, clock=Clock(unit="day"))
    sim.attach(EconomyModule(initial_gdp=1_000_000.0, base_growth=0.03))
    sim.run(365)

    print(sim.metrics.summary("gdp"))
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from moirai.module import Module

if TYPE_CHECKING:
    from moirai.simulation import Simulation

# Bounds
_INFLATION_MIN: float = -0.05   # -5 %
_INFLATION_MAX: float = 0.20    # 20 %
_UNEMPLOYMENT_MIN: float = 0.0
_UNEMPLOYMENT_MAX: float = 1.0


class EconomyModule(Module):
    """Stochastic economy module with GDP / inflation / unemployment dynamics.

    GDP follows a biased random walk with drift ``base_growth / 365`` per tick
    (one tick = one day by default) and Gaussian noise of ``volatility``
    standard deviation.

    Inflation and unemployment follow mean-reverting random walks.

    Args:
        initial_gdp: Starting GDP value in arbitrary currency units.
        base_growth: Annual growth rate (e.g. ``0.03`` = 3 %).
        volatility: Standard deviation of daily Gaussian noise applied to
            the growth factor.
        inflation_target: Long-run inflation target (default 2 %).
        initial_unemployment: Starting unemployment rate (default 5 %).

    Attributes:
        phase: ``"economy"`` — runs after environmental modules.
    """

    phase: str = "economy"

    def __init__(
        self,
        initial_gdp: float = 1_000_000.0,
        base_growth: float = 0.03,
        volatility: float = 0.005,
        inflation_target: float = 0.02,
        initial_unemployment: float = 0.05,
    ) -> None:
        self._initial_gdp = initial_gdp
        self.base_growth = base_growth
        self.volatility = volatility
        self.inflation_target = inflation_target
        self._initial_unemployment = initial_unemployment
        self._in_recession: bool = False

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def setup(self, sim: "Simulation") -> None:
        """Seed initial economic indicators.

        Args:
            sim: The parent simulation.
        """
        self._in_recession = False
        sim.resources.update(
            {
                "gdp": self._initial_gdp,
                "inflation": self.inflation_target,
                "unemployment": self._initial_unemployment,
            }
        )
        sim.metrics.track("gdp", self._initial_gdp)
        sim.metrics.track("inflation", self.inflation_target)
        sim.metrics.track("unemployment", self._initial_unemployment)

    def update(self, sim: "Simulation") -> None:
        """Advance economic indicators by one day.

        Args:
            sim: The parent simulation.
        """
        gdp: float = sim.resources.get_typed("gdp", float)
        inflation: float = sim.resources.get_typed("inflation", float)
        unemployment: float = sim.resources.get_typed("unemployment", float)

        # ---------- GDP -------------------------------------------
        daily_drift = self.base_growth / 365.0
        noise = sim.rng.gauss(0.0, self.volatility)
        growth_factor = 1.0 + daily_drift + noise
        new_gdp = gdp * growth_factor

        # Recession detection
        is_growing = growth_factor >= 1.0
        if not is_growing and not self._in_recession:
            self._in_recession = True
            sim.eventbus.emit("recession_started", tick=sim.ticks, gdp=new_gdp)
        elif is_growing and self._in_recession:
            self._in_recession = False
            sim.eventbus.emit("recession_ended", tick=sim.ticks, gdp=new_gdp)

        # ---------- Inflation (mean-reverting) ----------------------
        inflation_shock = sim.rng.gauss(0.0, 0.001)
        # Gently pull toward target
        inflation_pull = 0.01 * (self.inflation_target - inflation)
        new_inflation = max(
            _INFLATION_MIN,
            min(_INFLATION_MAX, inflation + inflation_pull + inflation_shock),
        )

        # ---------- Unemployment (Okun's-law proxy) -----------------
        # Growth above drift → unemployment falls, below → rises
        okun_effect = -2.5 * (daily_drift + noise - daily_drift)
        unemp_noise = sim.rng.gauss(0.0, 0.001)
        new_unemployment = max(
            _UNEMPLOYMENT_MIN,
            min(_UNEMPLOYMENT_MAX, unemployment + okun_effect * 0.01 + unemp_noise),
        )

        sim.resources.update(
            {
                "gdp": new_gdp,
                "inflation": new_inflation,
                "unemployment": new_unemployment,
            }
        )
        sim.metrics.track("gdp", new_gdp)
        sim.metrics.track("inflation", new_inflation)
        sim.metrics.track("unemployment", new_unemployment)

        sim.eventbus.emit(
            "economy_updated",
            gdp=new_gdp,
            inflation=new_inflation,
            unemployment=new_unemployment,
        )

    def teardown(self, sim: "Simulation") -> None:
        """No cleanup required.

        Args:
            sim: The parent simulation.
        """
