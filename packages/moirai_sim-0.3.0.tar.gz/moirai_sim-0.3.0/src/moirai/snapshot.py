"""
Simulation snapshots — serialize observable state to / from JSON.

A :class:`Snapshot` captures the tick counter, metrics history, shared
resources, and module roster at a point in time. Snapshots are useful for:

* **Checkpointing** — save progress and inspect state offline.
* **Reproducibility auditing** — attach snapshots to experiment logs.
* **Post-hoc analysis** — load a snapshot and compute statistics without
  re-running the simulation.

Note:
    Full simulation *restoration* (recreating attached modules and their
    internal state) is out of scope. Snapshots capture only the *observable*
    state (metrics + resources) that flows through the public API.

Example::

    from moirai import Simulation
    from moirai.examples.weather import WeatherModule

    sim = Simulation(seed=42)
    sim.attach(WeatherModule())
    sim.run(100)

    snap = sim.snapshot()
    snap.save("checkpoint.json")

    # Later — load and inspect
    from moirai.snapshot import Snapshot
    snap = Snapshot.load("checkpoint.json")
    print(snap.tick)              # 100
    print(snap.resources)         # {"temperature": ...}
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from moirai.simulation import Simulation


@dataclass
class Snapshot:
    """Immutable record of a simulation's observable state at one point in time.

    Args:
        tick: Value of :attr:`~moirai.Simulation.ticks` when captured.
        seed: The simulation's RNG seed.
        state: String representation of the simulation state
            (e.g. ``"idle"``).
        time_elapsed: Real-world time elapsed (``clock.elapsed(ticks)``).
        time_unit: The clock's time unit label.
        metrics: Full metrics history at capture time.
        resources: All shared resources at capture time.
        module_names: Class names of all attached modules in execution order.
        captured_at: ISO 8601 UTC timestamp of when the snapshot was taken.
    """

    tick: int
    seed: int
    state: str
    time_elapsed: float
    time_unit: str
    metrics: dict[str, list[Any]]
    resources: dict[str, Any]
    module_names: list[str]
    captured_at: str

    # ------------------------------------------------------------------
    # Factory
    # ------------------------------------------------------------------

    @classmethod
    def capture(cls, sim: "Simulation") -> "Snapshot":
        """Capture the observable state of *sim* right now.

        Args:
            sim: The simulation to snapshot.

        Returns:
            A new :class:`Snapshot` instance.
        """
        return cls(
            tick=sim.ticks,
            seed=sim.seed,
            state=sim.state.value,
            time_elapsed=sim.clock.elapsed(sim.ticks),
            time_unit=sim.clock.unit,
            metrics=sim.metrics.snapshot(),
            resources=_safe_resources(sim.resources.snapshot()),
            module_names=[m.name for m in sim.modules],
            captured_at=datetime.now(tz=timezone.utc).isoformat(),
        )

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def save(self, path: str | Path) -> None:
        """Serialize the snapshot to a JSON file at *path*.

        The file is written with UTF-8 encoding. Non-JSON-serialisable
        resource values are converted to their string representation.

        Args:
            path: Destination file path. Parent directories must exist.
        """
        data = asdict(self)
        Path(path).write_text(
            json.dumps(data, default=str, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

    @classmethod
    def load(cls, path: str | Path) -> "Snapshot":
        """Deserialise a snapshot from a JSON file.

        Args:
            path: Path to a file previously written by :meth:`save`.

        Returns:
            A restored :class:`Snapshot` instance.

        Raises:
            FileNotFoundError: If *path* does not exist.
            ValueError: If the file contains invalid JSON or is missing
                required fields.
        """
        try:
            raw = json.loads(Path(path).read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise ValueError(f"Invalid JSON in snapshot file {path!r}: {exc}") from exc
        try:
            return cls(**raw)
        except TypeError as exc:
            raise ValueError(f"Snapshot file {path!r} has unexpected fields: {exc}") from exc

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def summary(self) -> str:
        """Return a one-line human-readable summary of this snapshot.

        Returns:
            String like ``"Snapshot @ tick=100 (seed=42, 2025-01-10)"``.
        """
        date = self.captured_at[:10]
        return (
            f"Snapshot @ tick={self.tick}"
            f"  seed={self.seed}"
            f"  elapsed={self.time_elapsed:.1f} {self.time_unit}(s)"
            f"  captured={date}"
        )

    def __repr__(self) -> str:
        return (
            f"Snapshot(tick={self.tick}, seed={self.seed},"
            f" captured_at={self.captured_at!r})"
        )


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _safe_resources(data: dict[str, Any]) -> dict[str, Any]:
    """Return a copy of *data* with values coerced to JSON-safe types."""
    safe: dict[str, Any] = {}
    for key, value in data.items():
        try:
            json.dumps(value)
            safe[key] = value
        except (TypeError, ValueError):
            safe[key] = str(value)
    return safe
