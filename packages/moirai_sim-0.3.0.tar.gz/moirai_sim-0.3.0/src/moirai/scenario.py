"""
Multi-seed scenario runner for systematic simulation experiments.

In stochastic simulations a single run is rarely meaningful in isolation.
:class:`Scenario` runs the same simulation factory across an ensemble of seeds
and aggregates the results into a :class:`ScenarioResult`, making it easy to
report ensemble statistics.

Example::

    from moirai import Simulation
    from moirai.scenario import Scenario
    from moirai.examples.epidemic import EpidemicModule

    def make_sim(seed: int) -> Simulation:
        sim = Simulation(seed=seed)
        sim.attach(EpidemicModule(population=10_000, initial_infected=10))
        return sim

    result = Scenario(make_sim, seeds=range(20)).run(steps=200)

    print(result.cross_run_summary("I"))
    # CrossRunSummary('I': n=20  min=...  max=...  mean=...  std=...)

    for seed, snap in zip(result.seeds, result.snapshots):
        print(f"seed={seed}  peak_I={max(snap.metrics['I']):.0f}")
"""

from __future__ import annotations

import logging
import statistics
from dataclasses import dataclass
from typing import Callable, Iterable

from moirai.simulation import Simulation
from moirai.snapshot import Snapshot

logger = logging.getLogger(__name__)

# A factory takes a seed and returns a configured, ready-to-run Simulation.
SimFactory = Callable[[int], Simulation]


@dataclass(frozen=True)
class CrossRunSummary:
    """Statistical summary of a metric's final value across all scenario seeds.

    Attributes:
        metric: The metric key.
        n: Number of runs contributing data.
        min: Minimum final value across runs.
        max: Maximum final value across runs.
        mean: Mean of final values across runs.
        std: Standard deviation of final values (0.0 when n ≤ 1).
    """

    metric: str
    n: int
    min: float
    max: float
    mean: float
    std: float

    def __str__(self) -> str:
        if self.n == 0:
            return f"CrossRunSummary({self.metric!r}: no data)"
        return (
            f"CrossRunSummary({self.metric!r}:"
            f" n={self.n}"
            f" min={self.min:.4g}"
            f" max={self.max:.4g}"
            f" mean={self.mean:.4g}"
            f" std={self.std:.4g})"
        )


@dataclass
class ScenarioResult:
    """Aggregated results from a multi-seed scenario run.

    Attributes:
        seeds: The seed values that were used.
        snapshots: One :class:`~moirai.snapshot.Snapshot` per seed,
            in the same order as :attr:`seeds`.
        steps: The number of simulation steps requested.
    """

    seeds: list[int]
    snapshots: list[Snapshot]
    steps: int

    @property
    def n(self) -> int:
        """Number of completed simulation runs."""
        return len(self.snapshots)

    # ------------------------------------------------------------------
    # Data access
    # ------------------------------------------------------------------

    def final_values(self, metric: str) -> list[float]:
        """Return the final value of *metric* for each seed.

        Seeds whose snapshot does not contain *metric* are silently skipped.

        Args:
            metric: The metric key to inspect.

        Returns:
            List of ``float`` values, one per contributing seed.
        """
        values: list[float] = []
        for snap in self.snapshots:
            series = snap.metrics.get(metric, [])
            if series:
                try:
                    values.append(float(series[-1]))
                except (TypeError, ValueError):
                    pass
        return values

    def peak_values(self, metric: str) -> list[float]:
        """Return the *maximum* value of *metric* observed across all ticks
        for each seed.

        Args:
            metric: The metric key to inspect.

        Returns:
            List of peak ``float`` values, one per contributing seed.
        """
        peaks: list[float] = []
        for snap in self.snapshots:
            series = snap.metrics.get(metric, [])
            numeric = [float(v) for v in series if _is_numeric(v)]
            if numeric:
                peaks.append(max(numeric))
        return peaks

    # ------------------------------------------------------------------
    # Statistics
    # ------------------------------------------------------------------

    def cross_run_summary(self, metric: str) -> CrossRunSummary:
        """Compute ensemble statistics of the *final* value of *metric*.

        Args:
            metric: The metric key.

        Returns:
            A :class:`CrossRunSummary` dataclass.
        """
        values = self.final_values(metric)
        return _make_summary(metric, values)

    def cross_run_peak_summary(self, metric: str) -> CrossRunSummary:
        """Compute ensemble statistics of the *peak* value of *metric*.

        Args:
            metric: The metric key.

        Returns:
            A :class:`CrossRunSummary` dataclass describing peak values.
        """
        values = self.peak_values(metric)
        return _make_summary(metric, values)

    # ------------------------------------------------------------------
    # Display
    # ------------------------------------------------------------------

    def summary(self, *metrics: str) -> str:
        """Return a human-readable multi-line summary for the given metrics.

        Args:
            *metrics: Metric keys to include. If none given, all metrics
                found in any snapshot are included.

        Returns:
            Formatted string.
        """
        if not metrics:
            seen: set[str] = set()
            for snap in self.snapshots:
                seen.update(snap.metrics.keys())
            metrics = tuple(sorted(seen))

        lines = [
            f"ScenarioResult — {self.n} run(s), {self.steps} step(s) each",
            "─" * 56,
        ]
        for m in metrics:
            s = self.cross_run_summary(m)
            lines.append(str(s))
        return "\n".join(lines)

    def __repr__(self) -> str:
        return (
            f"ScenarioResult(n={self.n}, steps={self.steps},"
            f" seeds={self.seeds!r})"
        )


class Scenario:
    """Runs a simulation factory across multiple seeds.

    Args:
        factory: A callable that accepts an integer seed and returns a
            fully configured (but not yet run) :class:`~moirai.Simulation`.
        seeds: Iterable of integer seeds. Use ``range(N)`` to generate N
            seeds automatically.

    Example::

        def make_epidemic(seed: int) -> Simulation:
            sim = Simulation(seed=seed)
            sim.attach(EpidemicModule(population=100_000))
            return sim

        result = Scenario(make_epidemic, seeds=range(30)).run(steps=365)
        print(result.cross_run_summary("I"))
        print(result.cross_run_peak_summary("I"))
    """

    def __init__(
        self,
        factory: SimFactory,
        seeds: Iterable[int],
    ) -> None:
        self.factory = factory
        self.seeds: list[int] = list(seeds)

    def run(self, steps: int = 1, *, verbose: bool = False) -> ScenarioResult:
        """Execute the factory for each seed and return aggregated results.

        Args:
            steps: Number of simulation steps per run.
            verbose: If ``True``, log progress for each seed.

        Returns:
            A :class:`ScenarioResult` containing one snapshot per seed.
        """
        snapshots: list[Snapshot] = []
        for i, seed in enumerate(self.seeds, start=1):
            logger.debug(
                "Scenario run %d/%d (seed=%d)", i, len(self.seeds), seed
            )
            if verbose:
                print(f"  [{i:>3}/{len(self.seeds)}] seed={seed}", flush=True)
            sim = self.factory(seed)
            sim.run(steps)
            snapshots.append(sim.snapshot())

        return ScenarioResult(seeds=self.seeds, snapshots=snapshots, steps=steps)

    def __repr__(self) -> str:
        return f"Scenario(seeds={self.seeds!r})"


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _is_numeric(value: object) -> bool:
    try:
        float(value)  # type: ignore[arg-type]
        return True
    except (TypeError, ValueError):
        return False


def _make_summary(metric: str, values: list[float]) -> CrossRunSummary:
    if not values:
        return CrossRunSummary(metric=metric, n=0, min=0.0, max=0.0, mean=0.0, std=0.0)
    return CrossRunSummary(
        metric=metric,
        n=len(values),
        min=min(values),
        max=max(values),
        mean=statistics.mean(values),
        std=statistics.stdev(values) if len(values) > 1 else 0.0,
    )
