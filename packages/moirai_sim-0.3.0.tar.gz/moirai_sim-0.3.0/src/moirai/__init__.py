"""
Moirai — Universal Simulation Orchestrator.

Public API surface. Import everything from here.

Example::

    from moirai import Simulation
    from moirai.module import Module
    from moirai.clock import Clock
    from moirai.examples.weather import WeatherModule
    from moirai.examples.population import PopulationModule

    sim = Simulation(seed=42, clock=Clock(unit="day"))
    sim.attach(WeatherModule())
    sim.attach(PopulationModule())
    sim.run(365)

    print(sim.summary())
    sim.snapshot().save("run.json")
"""

from moirai.simulation import Simulation, SimulationState
from moirai.module import Module
from moirai.eventbus import EventBus
from moirai.metrics import Metrics, MetricSummary
from moirai.resources import ResourceContainer
from moirai.clock import Clock
from moirai.scheduler import Scheduler
from moirai.snapshot import Snapshot
from moirai.scenario import Scenario, ScenarioResult, CrossRunSummary
from moirai import exceptions

__all__ = [
    # Core
    "Simulation",
    "SimulationState",
    "Module",
    # Subsystems
    "EventBus",
    "Metrics",
    "MetricSummary",
    "ResourceContainer",
    "Clock",
    "Scheduler",
    "Snapshot",
    # Scenario / experiments
    "Scenario",
    "ScenarioResult",
    "CrossRunSummary",
    # Exceptions module
    "exceptions",
]

__version__ = "0.3.0"
