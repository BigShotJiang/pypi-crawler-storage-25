"""
Shared resource container for structured inter-module data exchange.

New in v0.2
-----------
* :meth:`ResourceContainer.get_typed` — runtime type-checked retrieval.
* :meth:`ResourceContainer.update` — batch set from a mapping.
* :meth:`ResourceContainer.setdefault` — set-if-absent helper.

Example::

    rc = ResourceContainer()
    rc.set("gdp", 1_000_000.0)
    rc.update({"population": 5_000_000, "inflation": 0.02})

    # Typed get — raises ResourceTypeError if type doesn't match
    gdp = rc.get_typed("gdp", float)

    # set-if-absent
    rc.setdefault("mortality_rate", 0.01)
"""

from __future__ import annotations

from typing import Any, TypeVar

from moirai.exceptions import ResourceNotFoundError, ResourceTypeError

_T = TypeVar("_T")

_MISSING = object()  # sentinel for "no default provided"


class ResourceContainer:
    """A key-value store for sharing state between simulation modules.

    Resources are arbitrary Python objects stored under string keys.
    All reads are O(1). The container raises typed exceptions on access
    violations to provide clear error messages during development.

    Attributes:
        _store: Internal mapping of resource keys to values.
    """

    def __init__(self) -> None:
        self._store: dict[str, Any] = {}

    # ------------------------------------------------------------------
    # Writing
    # ------------------------------------------------------------------

    def set(self, key: str, value: Any) -> None:
        """Store *value* under *key*, overwriting any existing value.

        Args:
            key: Resource identifier.
            value: Any Python object to store.
        """
        self._store[key] = value

    def update(self, data: dict[str, Any]) -> None:
        """Batch-set multiple resources from a mapping.

        Equivalent to calling :meth:`set` for each key-value pair.

        Args:
            data: Mapping of ``{key: value}`` pairs to store.

        Example::

            rc.update({"temperature": 20.0, "humidity": 0.65})
        """
        for key, value in data.items():
            self._store[key] = value

    def setdefault(self, key: str, default: Any) -> Any:
        """Set *key* to *default* only if it is not already present.

        Args:
            key: Resource identifier.
            default: Value to store if *key* is absent.

        Returns:
            The existing value if *key* is present, otherwise *default*.
        """
        if key not in self._store:
            self._store[key] = default
        return self._store[key]

    def delete(self, key: str) -> None:
        """Remove the resource identified by *key*.

        Args:
            key: Resource identifier.

        Raises:
            ResourceNotFoundError: If *key* does not exist.
        """
        if key not in self._store:
            raise ResourceNotFoundError(key)
        del self._store[key]

    def clear(self) -> None:
        """Remove all stored resources."""
        self._store.clear()

    # ------------------------------------------------------------------
    # Reading
    # ------------------------------------------------------------------

    def get(self, key: str, default: Any = _MISSING) -> Any:
        """Retrieve the value stored under *key*.

        Args:
            key: Resource identifier.
            default: Returned when *key* is absent. If omitted and *key*
                does not exist, raises :exc:`ResourceNotFoundError`.

        Returns:
            The stored value, or *default* if provided.

        Raises:
            ResourceNotFoundError: If *key* is absent and no *default* was given.
        """
        if key in self._store:
            return self._store[key]
        if default is not _MISSING:
            return default
        raise ResourceNotFoundError(key)

    def get_typed(self, key: str, type_: type[_T], default: Any = _MISSING) -> _T:
        """Retrieve *key* and assert it is an instance of *type_*.

        Args:
            key: Resource identifier.
            type_: The expected Python type.
            default: Returned when *key* is absent (bypasses type check).

        Returns:
            The stored value cast to *type_*.

        Raises:
            ResourceNotFoundError: If *key* is absent and no *default* given.
            ResourceTypeError: If the stored value is not an instance of
                *type_*.

        Example::

            temp = rc.get_typed("temperature", float)
        """
        value = self.get(key, default)
        if value is default and default is not _MISSING:
            return value  # type: ignore[return-value]
        if not isinstance(value, type_):
            raise ResourceTypeError(
                key,
                expected=type_.__name__,
                got=type(value).__name__,
            )
        return value

    def has(self, key: str) -> bool:
        """Return ``True`` if *key* is present in the container.

        Args:
            key: Resource identifier.
        """
        return key in self._store

    def keys(self) -> list[str]:
        """Return all resource keys in insertion order."""
        return list(self._store.keys())

    def snapshot(self) -> dict[str, Any]:
        """Return a shallow copy of the entire store.

        Returns:
            ``{key: value}`` mapping.
        """
        return dict(self._store)

    # ------------------------------------------------------------------
    # Dunder helpers
    # ------------------------------------------------------------------

    def __contains__(self, key: str) -> bool:
        return key in self._store

    def __len__(self) -> int:
        return len(self._store)

    def __repr__(self) -> str:
        return f"ResourceContainer(keys={list(self._store.keys())!r})"
