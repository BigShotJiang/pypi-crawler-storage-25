"""
Pub/sub event bus for loose inter-module communication.

Modules should **not** call each other directly. Instead, they publish named
events via :class:`EventBus` and subscribe to events they care about. This
keeps modules fully decoupled and makes the simulation easy to test and extend.

New in v0.2
-----------
* :meth:`once` — register a one-shot handler that auto-unsubscribes.
* **Wildcard subscriptions** — subscribe to ``"*"`` to receive every event.

Example::

    bus = EventBus()

    # Standard subscription
    bus.subscribe("temperature_changed", lambda value, **_: print(value))

    # One-shot
    bus.once("run_start", lambda **_: print("Simulation started!"))

    # Wildcard — receives all events
    bus.subscribe("*", lambda **kw: logging.debug("Event: %s", kw))

    bus.emit("temperature_changed", value=25.0)
"""

from __future__ import annotations

import logging
from collections import defaultdict
from typing import Any, Callable

logger = logging.getLogger(__name__)

Handler = Callable[..., None]

# Sentinel key for wildcard subscriptions.
_WILDCARD = "*"


class EventBus:
    """A synchronous, in-process publish/subscribe event bus.

    Handlers are called synchronously in subscription order. Exceptions
    raised by a handler are caught and logged so that a faulty handler cannot
    break the simulation loop.

    Special event names
    -------------------
    ``"*"``
        Wildcard — handlers subscribed to ``"*"`` receive *every* emitted
        event, before regular handlers.

    Attributes:
        _handlers: Mapping of event names to ordered handler lists.
    """

    def __init__(self) -> None:
        self._handlers: dict[str, list[Handler]] = defaultdict(list)

    # ------------------------------------------------------------------
    # Subscription management
    # ------------------------------------------------------------------

    def subscribe(self, event: str, handler: Handler) -> None:
        """Register *handler* to be called when *event* is emitted.

        Subscribing the same handler instance twice for the same event is
        idempotent — only one copy is stored.

        Args:
            event: The event name (or ``"*"`` for wildcard).
            handler: A callable accepting keyword arguments from the event
                payload.
        """
        if handler not in self._handlers[event]:
            self._handlers[event].append(handler)
            logger.debug("Subscribed %r to event %r", handler, event)

    def once(self, event: str, handler: Handler) -> None:
        """Register *handler* to fire exactly once for *event*.

        The handler is automatically unsubscribed immediately before it is
        invoked for the first time.

        Args:
            event: The event name.
            handler: A callable that will be called at most once.

        Example::

            bus.once("run_start", lambda **_: print("First run!"))
        """

        def _wrapper(**kwargs: Any) -> None:
            # Unsubscribe before calling so re-entrant emits don't fire again.
            self.unsubscribe(event, _wrapper)
            try:
                handler(**kwargs)
            except Exception:  # noqa: BLE001
                logger.exception(
                    "One-shot handler %r raised for event %r", handler, event
                )

        # Tag wrapper so it can be identified in subscriber lists
        _wrapper.__wrapped__ = handler  # type: ignore[attr-defined]
        self.subscribe(event, _wrapper)

    def unsubscribe(self, event: str, handler: Handler) -> None:
        """Remove *handler* from listeners for *event*.

        Silently ignored if the handler is not currently subscribed.

        Args:
            event: The event name.
            handler: The handler to remove.
        """
        try:
            self._handlers[event].remove(handler)
            logger.debug("Unsubscribed %r from event %r", handler, event)
        except ValueError:
            pass

    def unsubscribe_all(self, event: str | None = None) -> None:
        """Remove all handlers for *event*, or for every event if ``None``.

        Args:
            event: If given, clear only this event. If ``None``, clear all.
        """
        if event is None:
            self._handlers.clear()
        else:
            self._handlers.pop(event, None)

    # ------------------------------------------------------------------
    # Emitting
    # ------------------------------------------------------------------

    def emit(self, event: str, **payload: Any) -> None:
        """Publish *event* with an optional keyword payload.

        Wildcard handlers (subscribed to ``"*"``) are called first, then
        event-specific handlers, each in registration order. Exceptions are
        caught, logged, and suppressed.

        Args:
            event: The event name.
            **payload: Arbitrary keyword arguments forwarded to each handler.
        """
        # Wildcard handlers fire first
        all_handlers: list[Handler] = list(self._handlers.get(_WILDCARD, []))
        # Then specific handlers (skip duplicates already in wildcard list)
        all_handlers += [
            h for h in self._handlers.get(event, []) if h not in all_handlers
        ]

        logger.debug(
            "Emitting %r to %d handler(s)", event, len(all_handlers)
        )
        for handler in all_handlers:
            try:
                handler(**payload)
            except Exception:  # noqa: BLE001
                logger.exception(
                    "Handler %r raised an exception for event %r", handler, event
                )

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    def subscribers(self, event: str) -> list[Handler]:
        """Return a snapshot of handlers registered for *event*.

        Args:
            event: The event name.

        Returns:
            Immutable copy of the handler list.
        """
        return list(self._handlers.get(event, []))

    def events(self) -> list[str]:
        """Return names of all events with at least one subscriber.

        Returns:
            Sorted list of event names (excluding ``"*"`` if empty).
        """
        return sorted(k for k, v in self._handlers.items() if v)

    def __repr__(self) -> str:
        counts = {k: len(v) for k, v in self._handlers.items() if v}
        return f"EventBus({counts!r})"
