"""
Central simulation orchestrator for Moirai.

New in v0.2
-----------
* :class:`SimulationState` enum — IDLE / RUNNING / PAUSED.
* :attr:`Simulation.state` — read the current state.
* :meth:`Simulation.pause` — request a pause after the current tick.
* :meth:`Simulation.on` — decorator for subscribing to sim events inline.
* :meth:`Simulation.summary` — rich human-readable state dump.
* :meth:`Simulation.snapshot` — capture observable state to a
  :class:`~moirai.snapshot.Snapshot`.
* :attr:`Simulation.clock` — :class:`~moirai.clock.Clock` for time mapping.
* :attr:`Simulation.scheduler` — :class:`~moirai.scheduler.Scheduler` for
  deferred / recurring callbacks.
* :attr:`Simulation.time` — convenience property for elapsed real-world time.
* Module phase+priority ordering — modules sort by ``(phase, priority)``.
* Disabled modules are skipped in :meth:`tick`.
* :meth:`run` returns the number of ticks actually executed.

Example::

    from moirai import Simulation
    from moirai.clock import Clock
    from moirai.examples.weather import WeatherModule
    from moirai.examples.population import PopulationModule

    sim = Simulation(seed=42, clock=Clock(time_step=1.0, unit="day"))

    @sim.on("temperature_changed")
    def log_temp(value, **_):
        print(f"[{sim.clock.format_time(sim.ticks)}] Temp: {value:.1f} °C")

    sim.scheduler.schedule_every(30, lambda: print("Monthly checkpoint"))

    sim.attach(WeatherModule())
    sim.attach(PopulationModule())
    sim.run(365)

    print(sim.summary())
    snap = sim.snapshot()
    snap.save("run.json")
"""

from __future__ import annotations

import logging
import random as _random
from enum import Enum
from typing import TYPE_CHECKING, Callable

from moirai.clock import Clock
from moirai.eventbus import EventBus
from moirai.exceptions import (
    ModuleAlreadyAttachedError,
    ModuleNotFoundError,
    SimulationAlreadyRunningError,
)
from moirai.metrics import Metrics
from moirai.resources import ResourceContainer
from moirai.scheduler import Scheduler

if TYPE_CHECKING:
    from moirai.module import Module
    from moirai.snapshot import Snapshot

logger = logging.getLogger(__name__)

Handler = Callable[..., None]


# ---------------------------------------------------------------------------
# State machine
# ---------------------------------------------------------------------------


class SimulationState(Enum):
    """Lifecycle states of a :class:`Simulation`.

    Attributes:
        IDLE: Not currently running. This is the initial state and the state
            after a :meth:`~Simulation.run` call completes normally.
        RUNNING: Inside an active :meth:`~Simulation.run` call.
        PAUSED: :meth:`~Simulation.pause` was called during a run; the loop
            exited early. The simulation is ready to resume via another
            :meth:`~Simulation.run` call.
    """

    IDLE = "idle"
    RUNNING = "running"
    PAUSED = "paused"


# ---------------------------------------------------------------------------
# Simulation
# ---------------------------------------------------------------------------


class Simulation:
    """Universal simulation runtime and module orchestrator.

    The simulation owns the global clock, the module registry, the event bus,
    the metrics store, the shared resource container, and the scheduler.
    Modules are attached via :meth:`attach`, removed via :meth:`detach`, and
    executed each tick in ascending ``(phase, priority)`` order.

    Args:
        seed: Integer seed for the RNG. If ``None``, a random seed is chosen
            and stored in :attr:`seed` for later inspection.
        clock: Optional :class:`~moirai.clock.Clock` instance. If ``None``,
            a default ``Clock(time_step=1.0, unit="day")`` is created.

    Attributes:
        seed: The integer seed used to initialise the RNG.
        rng: A dedicated :class:`random.Random` instance. Modules **must**
            use this (or a sub-generator derived from it) for reproducibility.
        ticks: Number of completed simulation steps.
        clock: The :class:`~moirai.clock.Clock` for time mapping.
        eventbus: The shared :class:`~moirai.EventBus`.
        metrics: The shared :class:`~moirai.Metrics` collector.
        resources: The shared :class:`~moirai.ResourceContainer`.
        scheduler: The :class:`~moirai.scheduler.Scheduler` for deferred
            and recurring callbacks.
    """

    def __init__(
        self,
        seed: int | None = None,
        clock: Clock | None = None,
    ) -> None:
        # ---- Reproducibility ----------------------------------------
        self.seed: int = seed if seed is not None else _random.randint(1, 2**32 - 1)
        self.rng: _random.Random = _random.Random(self.seed)

        # ---- Clock ---------------------------------------------------
        self.clock: Clock = clock if clock is not None else Clock()

        # ---- Tick counter -------------------------------------------
        self.ticks: int = 0

        # ---- Module registry ----------------------------------------
        # Stored in attachment order; execution order is derived on demand.
        self._modules: list[Module] = []

        # ---- Subsystems ---------------------------------------------
        self.eventbus: EventBus = EventBus()
        self.metrics: Metrics = Metrics()
        self.resources: ResourceContainer = ResourceContainer()
        self.scheduler: Scheduler = Scheduler()

        # ---- State machine ------------------------------------------
        self._state: SimulationState = SimulationState.IDLE
        self._pause_requested: bool = False

        logger.info("Simulation initialised (seed=%d)", self.seed)

    # ------------------------------------------------------------------
    # State
    # ------------------------------------------------------------------

    @property
    def state(self) -> SimulationState:
        """Current lifecycle state of the simulation.

        Returns:
            One of :attr:`SimulationState.IDLE`, :attr:`SimulationState.RUNNING`,
            or :attr:`SimulationState.PAUSED`.
        """
        return self._state

    @property
    def time(self) -> float:
        """Elapsed real-world time according to the :attr:`clock`.

        Returns:
            ``clock.elapsed(ticks)`` — the number of real-world units that
            have passed in the simulation.
        """
        return self.clock.elapsed(self.ticks)

    # ------------------------------------------------------------------
    # Module management
    # ------------------------------------------------------------------

    def attach(self, module: "Module") -> "Simulation":
        """Attach *module* to the simulation and call its :meth:`~Module.setup`.

        Args:
            module: A concrete :class:`~moirai.Module` instance.

        Returns:
            ``self`` — enables fluent chaining:
            ``sim.attach(A).attach(B)``.

        Raises:
            ModuleAlreadyAttachedError: If this exact instance is already
                attached.
        """
        if module in self._modules:
            raise ModuleAlreadyAttachedError(type(module).__name__)
        self._modules.append(module)
        logger.debug("Attaching %r", module)
        module.setup(self)
        return self

    def detach(self, module: "Module") -> "Simulation":
        """Detach *module* and call its :meth:`~Module.teardown`.

        Args:
            module: The module instance to remove.

        Returns:
            ``self`` — enables fluent chaining.

        Raises:
            ModuleNotFoundError: If *module* is not currently attached.
        """
        if module not in self._modules:
            raise ModuleNotFoundError(type(module).__name__)
        module.teardown(self)
        self._modules.remove(module)
        logger.debug("Detached %r", module)
        return self

    @property
    def modules(self) -> list["Module"]:
        """Attached modules in *execution* order (``(phase, priority)`` ascending).

        Returns:
            Sorted list of :class:`~moirai.Module` instances. Mutations to
            this list do not affect the internal registry.
        """
        return self._execution_order

    @property
    def _execution_order(self) -> list["Module"]:
        """Derive the ordered module list from the attachment list."""
        return sorted(self._modules, key=lambda m: (m.phase, m.priority))

    # ------------------------------------------------------------------
    # Event subscription shorthand
    # ------------------------------------------------------------------

    def on(self, event: str) -> Callable[[Handler], Handler]:
        """Decorator — subscribe a function to *event* on this simulation's bus.

        Args:
            event: The event name (or ``"*"`` for wildcard).

        Returns:
            A decorator that registers the function and returns it unchanged.

        Example::

            @sim.on("temperature_changed")
            def log_temp(value, **_):
                print(f"Temp: {value}")
        """

        def _decorator(fn: Handler) -> Handler:
            self.eventbus.subscribe(event, fn)
            return fn

        return _decorator

    # ------------------------------------------------------------------
    # Simulation loop
    # ------------------------------------------------------------------

    def pause(self) -> None:
        """Request the simulation to pause after the *current* tick completes.

        Has no effect if the simulation is not running. After the loop exits,
        :attr:`state` is set to :attr:`SimulationState.PAUSED` and the
        simulation can be resumed by calling :meth:`run` again.
        """
        if self._state is SimulationState.RUNNING:
            self._pause_requested = True
            logger.debug("Pause requested")

    def tick(self) -> None:
        """Advance the simulation by exactly one step.

        1. Emits ``"tick_start"`` (payload: ``tick``).
        2. Processes the :attr:`scheduler`.
        3. Calls :meth:`~Module.update` on every *enabled* module in
           execution order.
        4. Increments :attr:`ticks`.
        5. Emits ``"tick_end"`` (payload: ``tick``).
        """
        self.eventbus.emit("tick_start", tick=self.ticks)
        self.scheduler.process(self.ticks)
        for module in self._execution_order:
            if module.enabled:
                module.update(self)
        self.ticks += 1
        self.eventbus.emit("tick_end", tick=self.ticks)

    def run(self, steps: int = 1) -> int:
        """Run the simulation for up to *steps* ticks.

        The loop exits early if :meth:`pause` is called from inside a module
        or event handler. In that case, :attr:`state` becomes
        :attr:`SimulationState.PAUSED` and can be resumed by calling
        :meth:`run` again.

        Args:
            steps: Maximum number of ticks to execute. Must be ≥ 1.

        Returns:
            The number of ticks actually executed (may be less than *steps*
            if :meth:`pause` was called mid-run).

        Raises:
            SimulationAlreadyRunningError: If called while the simulation is
                already in state :attr:`SimulationState.RUNNING`.
            ValueError: If *steps* < 1.

        Emits:
            ``"run_start"`` — before the first tick, payload: ``steps``.
            ``"run_end"`` — after the last tick (or pause), payload:
                ``steps``, ``ticks_run``, ``total_ticks``.
        """
        if steps < 1:
            raise ValueError(f"steps must be ≥ 1, got {steps!r}")
        if self._state is SimulationState.RUNNING:
            raise SimulationAlreadyRunningError(
                "Cannot call run() while the simulation is already running."
            )

        self._state = SimulationState.RUNNING
        self._pause_requested = False
        self.eventbus.emit("run_start", steps=steps)
        logger.info("run(steps=%d) — tick=%d, seed=%d", steps, self.ticks, self.seed)

        ticks_run = 0
        try:
            for _ in range(steps):
                if self._pause_requested:
                    self._state = SimulationState.PAUSED
                    logger.info("Simulation paused at tick %d", self.ticks)
                    break
                self.tick()
                ticks_run += 1
        finally:
            if self._state is SimulationState.RUNNING:
                self._state = SimulationState.IDLE

        self.eventbus.emit(
            "run_end",
            steps=steps,
            ticks_run=ticks_run,
            total_ticks=self.ticks,
        )
        logger.info("run() complete — ticks_run=%d, total=%d", ticks_run, self.ticks)
        return ticks_run

    # ------------------------------------------------------------------
    # Lifecycle utilities
    # ------------------------------------------------------------------

    def reset(self) -> None:
        """Reset the simulation to its initial state.

        Calls :meth:`~Module.reset` on every attached module, then clears
        metrics, resources, the scheduler, and the event bus. The seed and
        RNG are re-initialised so the next :meth:`run` produces identical
        output.

        Note:
            Attached modules are preserved; only their state is reset.
        """
        logger.info("Resetting simulation (seed=%d)", self.seed)
        for module in self._modules:
            module.reset(self)
        self.metrics.reset()
        self.resources.clear()
        self.scheduler.clear()
        self.eventbus.unsubscribe_all()
        self.ticks = 0
        self._state = SimulationState.IDLE
        self._pause_requested = False
        self.rng = _random.Random(self.seed)

    def snapshot(self) -> "Snapshot":
        """Capture the current observable state as a :class:`~moirai.snapshot.Snapshot`.

        Returns:
            A new :class:`~moirai.snapshot.Snapshot` populated from this
            simulation's metrics, resources, and clock.
        """
        from moirai.snapshot import Snapshot  # local import avoids cycle at module level

        return Snapshot.capture(self)

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    def summary(self) -> str:
        """Return a rich multi-line summary of the simulation state.

        Returns:
            A box-drawing string ready to ``print()``.

        Example::

            print(sim.summary())
        """
        bar = "─" * 48
        lines: list[str] = [
            f"┌{bar}",
            f"│  Simulation",
            f"│  {'seed':<14}: {self.seed}",
            f"│  {'state':<14}: {self._state.value}",
            f"│  {'time':<14}: {self.clock.format_time(self.ticks)}"
            f" (tick {self.ticks})",
            f"│  {'clock step':<14}: {self.clock.step_label}",
            f"├{'─' * 48}",
            f"│  Modules ({len(self._modules)})",
        ]

        if self._modules:
            for mod in self._execution_order:
                status = "●" if mod.enabled else "○"
                lines.append(
                    f"│    {status} {mod.name:<28}"
                    f"  phase={mod.phase!r}  priority={mod.priority}"
                )
        else:
            lines.append("│    (none)")

        lines += [
            f"├{'─' * 48}",
            f"│  Metrics  keys : {', '.join(self.metrics.keys()) or '(none)'}",
            f"│  Resources keys: {', '.join(self.resources.keys()) or '(none)'}",
            f"│  Scheduler jobs: {len(self.scheduler)}",
            f"└{bar}",
        ]
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Dunder helpers
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return (
            f"Simulation("
            f"seed={self.seed},"
            f" ticks={self.ticks},"
            f" state={self._state.value!r},"
            f" modules={[m.name for m in self._execution_order]!r}"
            f")"
        )
