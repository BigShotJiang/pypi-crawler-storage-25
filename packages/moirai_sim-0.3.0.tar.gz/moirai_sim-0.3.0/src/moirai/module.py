"""
Abstract base class for all Moirai simulation modules.

New in v0.2
-----------
* :attr:`Module.enabled` — toggle a module on/off without detaching it.
* :attr:`Module.name` — human-readable identifier (defaults to class name).
* :attr:`Module.priority` — numeric sub-ordering within a phase.

A :class:`Module` encapsulates a single domain of logic (weather, economy,
agents, …) that is plugged into a :class:`~moirai.Simulation` via
:meth:`~moirai.Simulation.attach`. The simulation runtime calls the module's
lifecycle methods in order:

1. :meth:`setup`    — once, when the module is attached.
2. :meth:`update`   — once per tick, in ``(phase, priority)`` order.
3. :meth:`teardown` — once, when the module is detached or the sim ends.

The optional :meth:`reset` hook lets a module reinitialise its state between
runs without being fully detached.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from moirai.simulation import Simulation


class Module(ABC):
    """Abstract base for all simulation modules.

    Subclasses **must** implement :meth:`setup`, :meth:`update`, and
    :meth:`teardown`.

    Execution order
    ---------------
    Modules are executed each tick in ascending ``(phase, priority)`` order.
    Within the same ``(phase, priority)``, they run in attachment order.

    * Lexicographically earlier phases run first
      (``"agents"`` before ``"environment"``).
    * Lower :attr:`priority` values run first within a phase.

    Attributes:
        phase: Execution phase label. Defaults to ``"default"``.
        priority: Numeric sub-ordering within a phase. Lower = earlier.
            Defaults to ``0``.
        enabled: When ``False``, :meth:`update` is skipped for this module
            every tick. :meth:`setup` and :meth:`teardown` are unaffected.
            Defaults to ``True``.

    Example::

        class EconomyModule(Module):
            phase = "economy"
            priority = 10

            def setup(self, sim):
                sim.resources.set("gdp", 1_000_000.0)

            def update(self, sim):
                growth = sim.rng.uniform(0.98, 1.03)
                gdp = sim.resources.get("gdp")
                sim.resources.set("gdp", gdp * growth)
                sim.metrics.track("gdp", sim.resources.get("gdp"))

            def teardown(self, sim):
                pass
    """

    phase: str = "default"
    priority: int = 0
    enabled: bool = True

    # ------------------------------------------------------------------
    # Lifecycle — must override
    # ------------------------------------------------------------------

    @abstractmethod
    def setup(self, sim: "Simulation") -> None:
        """Initialise module state.

        Called exactly once when the module is attached. Use this to allocate
        resources, subscribe to events, or seed initial simulation state.

        Args:
            sim: The parent :class:`~moirai.Simulation` instance.
        """

    @abstractmethod
    def update(self, sim: "Simulation") -> None:
        """Advance the module by one tick.

        Called once per simulation step when :attr:`enabled` is ``True``.

        Args:
            sim: The parent :class:`~moirai.Simulation` instance.
        """

    @abstractmethod
    def teardown(self, sim: "Simulation") -> None:
        """Clean up module state.

        Called when the module is detached or the simulation ends.

        Args:
            sim: The parent :class:`~moirai.Simulation` instance.
        """

    # ------------------------------------------------------------------
    # Optional hooks
    # ------------------------------------------------------------------

    def reset(self, sim: "Simulation") -> None:
        """Re-initialise module state without detaching.

        The default implementation calls :meth:`teardown` then :meth:`setup`.
        Override when you need a lighter reset (e.g. clearing only counters).

        Args:
            sim: The parent :class:`~moirai.Simulation` instance.
        """
        self.teardown(sim)
        self.setup(sim)

    # ------------------------------------------------------------------
    # Identity
    # ------------------------------------------------------------------

    @property
    def name(self) -> str:
        """Human-readable module name.

        Defaults to the class name. Override in a subclass or set as an
        instance attribute to customise.

        Returns:
            The module's display name.
        """
        return self.__class__.__name__

    # ------------------------------------------------------------------
    # Dunder helpers
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        status = "enabled" if self.enabled else "disabled"
        return (
            f"{self.__class__.__name__}("
            f"phase={self.phase!r},"
            f" priority={self.priority},"
            f" {status})"
        )
