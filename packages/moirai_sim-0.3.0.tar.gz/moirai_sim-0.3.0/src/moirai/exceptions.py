"""
Custom exception hierarchy for Moirai.

All Moirai exceptions derive from :class:`MoiraiError`, enabling callers to
catch only Moirai-related errors in a single ``except`` clause.
"""


class MoiraiError(Exception):
    """Base class for all Moirai exceptions."""


# ---------------------------------------------------------------------------
# Module lifecycle
# ---------------------------------------------------------------------------


class ModuleAlreadyAttachedError(MoiraiError):
    """Raised when a module instance is attached more than once.

    Args:
        module_name: The class name of the offending module.
    """

    def __init__(self, module_name: str) -> None:
        super().__init__(
            f"Module '{module_name}' is already attached to this simulation."
        )
        self.module_name = module_name


class ModuleNotFoundError(MoiraiError):
    """Raised when attempting to detach a module that is not attached.

    Args:
        module_name: The class name of the missing module.
    """

    def __init__(self, module_name: str) -> None:
        super().__init__(
            f"Module '{module_name}' is not attached to this simulation."
        )
        self.module_name = module_name


# ---------------------------------------------------------------------------
# Simulation runtime
# ---------------------------------------------------------------------------


class SimulationAlreadyRunningError(MoiraiError):
    """Raised when :meth:`~moirai.Simulation.run` is called on an already
    running simulation."""


class SimulationStateError(MoiraiError):
    """Raised when an operation is invalid given the current simulation state.

    Args:
        operation: Name of the attempted operation.
        current_state: String label of the current state.
    """

    def __init__(self, operation: str, current_state: str) -> None:
        super().__init__(
            f"Cannot call '{operation}' while simulation is in state '{current_state}'."
        )
        self.operation = operation
        self.current_state = current_state


# ---------------------------------------------------------------------------
# Resources
# ---------------------------------------------------------------------------


class ResourceNotFoundError(MoiraiError):
    """Raised when a requested resource key does not exist.

    Args:
        key: The missing resource key.
    """

    def __init__(self, key: str) -> None:
        super().__init__(f"Resource '{key}' not found in the container.")
        self.key = key


class ResourceTypeError(MoiraiError):
    """Raised when a resource value does not match the expected type.

    Args:
        key: The resource key.
        expected: The expected type name.
        got: The actual type name.
    """

    def __init__(self, key: str, expected: str, got: str) -> None:
        super().__init__(
            f"Resource '{key}' expected type '{expected}', got '{got}'."
        )
        self.key = key
        self.expected = expected
        self.got = got
