"""
python -m moirai — interactive demonstration of the Moirai framework.

Runs a 365-day simulation combining:
- WeatherModule with seasonal variation
- PopulationModule reacting to temperature
- EpidemicModule (SIR model)
- EconomyModule with GDP / inflation / unemployment

Usage::

    python -m moirai
    python -m moirai --seed 99
    python -m moirai --steps 730 --seed 7
"""

from __future__ import annotations

import argparse
import sys
from datetime import datetime


def _bar(value: float, lo: float, hi: float, width: int = 30, fill: str = "█") -> str:
    """Return a filled ASCII progress bar."""
    proportion = max(0.0, min(1.0, (value - lo) / (hi - lo) if hi != lo else 0.0))
    filled = round(proportion * width)
    return f"[{fill * filled}{'░' * (width - filled)}] {value:.1f}"


def main(argv: list[str] | None = None) -> None:  # noqa: C901
    # Ensure Unicode output works on Windows terminals (cp1252 → UTF-8)
    if sys.stdout.encoding and sys.stdout.encoding.lower() not in ("utf-8", "utf-8-sig"):
        try:
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
        except AttributeError:
            pass  # not all stdout implementations support reconfigure

    parser = argparse.ArgumentParser(
        prog="python -m moirai",
        description="Moirai universal simulation orchestrator — demo run",
    )
    parser.add_argument("--seed", type=int, default=42, help="RNG seed (default: 42)")
    parser.add_argument(
        "--steps", type=int, default=365, help="Number of ticks to simulate (default: 365)"
    )
    args = parser.parse_args(argv)

    from moirai import Simulation
    from moirai.clock import Clock
    from moirai.examples.economy import EconomyModule
    from moirai.examples.epidemic import EpidemicModule
    from moirai.examples.population import PopulationModule
    from moirai.examples.weather import WeatherModule

    BOLD = "\033[1m"
    RESET = "\033[0m"
    GREEN = "\033[32m"
    CYAN = "\033[36m"
    YELLOW = "\033[33m"
    RED = "\033[31m"
    MAGENTA = "\033[35m"

    def h(text: str, color: str = CYAN) -> str:
        return f"{BOLD}{color}{text}{RESET}"

    W = 60
    print()
    print(h("═" * W, CYAN))
    print(h(f"  🌀  MOIRAI  —  Universal Simulation Orchestrator  v0.2", CYAN))
    print(h("═" * W, CYAN))
    print(f"  Seed  : {args.seed}")
    print(f"  Steps : {args.steps} day(s)")
    print(h("─" * W, CYAN))

    sim = Simulation(
        seed=args.seed,
        clock=Clock(time_step=1.0, unit="day", start_date=datetime(2025, 1, 1)),
    )

    epidemic_end_tick: int | None = None
    recessions: list[int] = []

    @sim.on("epidemic_ended")
    def _on_epidemic_end(tick: int, **_: object) -> None:
        nonlocal epidemic_end_tick
        epidemic_end_tick = tick

    @sim.on("recession_started")
    def _on_recession(tick: int, **_: object) -> None:
        recessions.append(tick)

    # Mid-run checkpoint via the scheduler
    mid = args.steps // 2
    sim.scheduler.schedule_at(
        mid,
        lambda: print(
            f"\n  {h('[CHECKPOINT]', YELLOW)}"
            f" Day {mid} — "
            f"T={sim.resources.get('temperature', 0):.1f}°C  "
            f"Infected={sim.resources.get('sir_I', 0):.0f}  "
            f"GDP={sim.resources.get('gdp', 0):,.0f}"
        ),
    )

    # Attach modules
    sim.attach(WeatherModule(initial_temp=10.0, seasonal=True, seasonal_amplitude=12.0))
    sim.attach(PopulationModule(initial_mood=80.0))
    sim.attach(EpidemicModule(population=100_000, initial_infected=100, beta=0.3, gamma=0.1))
    sim.attach(EconomyModule(initial_gdp=500_000_000.0, base_growth=0.03))

    print(f"\n  Running {args.steps}-day simulation…\n")

    sim.run(args.steps)

    print()
    print(h("═" * W, CYAN))
    print(h(f"  Results: {sim.clock.format_time(0)} → {sim.clock.format_time(sim.ticks)}", GREEN))
    print(h("═" * W, CYAN))

    # Weather
    ts = sim.metrics.summary("temperature")
    print(h("\n  🌡  Weather", CYAN))
    print(f"    Min: {ts.min:.1f}°C  /  Max: {ts.max:.1f}°C  /  Mean: {ts.mean:.1f}°C")
    print(f"    Final: {_bar(ts.latest or 0, -40, 55)}")

    # Population
    ms = sim.metrics.summary("population_mood")
    print(h("\n  👥  Population mood", CYAN))
    print(f"    Final: {_bar(ms.latest or 0, 0, 200)}/200")

    # Epidemic
    i_s = sim.metrics.summary("I")
    r_final = sim.resources.get("sir_R", 0)
    print(h("\n  🦠  Epidemic (SIR)", CYAN))
    print(f"    Peak infections : {i_s.max:>10,.0f}")
    print(f"    Total recovered : {r_final:>10,.0f}")
    if epidemic_end_tick is not None:
        print(f"    Epidemic ended  : day {epidemic_end_tick}")
    else:
        print(f"    Still ongoing at tick {sim.ticks}")

    # Economy
    gdp_s = sim.metrics.summary("gdp")
    initial_gdp = 500_000_000.0
    growth_pct = ((gdp_s.latest or initial_gdp) - initial_gdp) / initial_gdp * 100
    infl = sim.resources.get("inflation", 0)
    unemp = sim.resources.get("unemployment", 0)
    print(h("\n  💰  Economy", CYAN))
    print(f"    GDP growth      : {growth_pct:>+.2f}%")
    print(f"    Inflation       : {infl * 100:.2f}%")
    print(f"    Unemployment    : {unemp * 100:.2f}%")
    print(f"    Recessions      : {len(recessions)}")

    # Scheduler / metrics
    print(h("\n  📊  Simulation", CYAN))
    print(f"    Ticks completed : {sim.ticks}")
    print(f"    Seed            : {sim.seed}")
    print(f"    Metrics tracked : {', '.join(sim.metrics.keys())}")

    # Snapshot
    snap_path = f"moirai_snapshot_seed{args.seed}.json"
    sim.snapshot().save(snap_path)
    print(h(f"\n  💾  Snapshot saved → {snap_path}", YELLOW))
    print(h("═" * W, CYAN))
    print()


if __name__ == "__main__":
    main()
