from typing import TypeVar

from tortoise import Model
from pydantic import BaseModel

T_Model = TypeVar("T_Model", bound=Model)
T_BaseModel = TypeVar("T_BaseModel", bound=BaseModel)


