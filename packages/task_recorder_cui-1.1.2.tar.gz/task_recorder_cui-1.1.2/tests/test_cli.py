"""cli.py のディスパッチとエントリ動作のテスト。

記録系コマンド (start/stop/now/add) の実ロジックは tests/test_start.py 等で
検証するため、本ファイルでは argparse の振る舞いと未実装スタブの応答を確認する。
"""

import pytest

from task_recorder_cui import __version__
from task_recorder_cui.cli import build_parser, main


def test_parserはversionを返す(capsys: pytest.CaptureFixture[str]) -> None:
    parser = build_parser()
    with pytest.raises(SystemExit) as ex:
        parser.parse_args(["--version"])
    assert ex.value.code == 0
    captured = capsys.readouterr()
    assert __version__ in captured.out


def test_helpは正常終了(capsys: pytest.CaptureFixture[str]) -> None:
    with pytest.raises(SystemExit) as ex:
        main(["--help"])
    assert ex.value.code == 0
    assert "tsk" in capsys.readouterr().out


def test_main_no_command_calls_menu(monkeypatch: pytest.MonkeyPatch) -> None:
    called = {"n": 0}

    def fake_run() -> int:
        called["n"] += 1
        return 0

    monkeypatch.setattr("task_recorder_cui.menu.run", fake_run)

    rc = main([])
    assert rc == 0
    assert called["n"] == 1


def test_catサブコマンド無しはexit2(capsys: pytest.CaptureFixture[str]) -> None:
    with pytest.raises(SystemExit) as ex:
        main(["cat"])
    assert ex.value.code == 2


def test_未知コマンドはexit2(capsys: pytest.CaptureFixture[str]) -> None:
    with pytest.raises(SystemExit) as ex:
        main(["no_such_command"])
    assert ex.value.code == 2


def test_start引数不足はexit2(capsys: pytest.CaptureFixture[str]) -> None:
    with pytest.raises(SystemExit) as ex:
        main(["start"])  # category_key 必須
    assert ex.value.code == 2


def test_add_minutesは整数必須(capsys: pytest.CaptureFixture[str]) -> None:
    with pytest.raises(SystemExit) as ex:
        main(["add", "study", "abc"])  # 整数でない
    assert ex.value.code == 2


def test_cli_timer_set_dispatches(isolated_db, monkeypatch: pytest.MonkeyPatch) -> None:
    from task_recorder_cui.db import open_db
    from task_recorder_cui.repo import insert_record
    from task_recorder_cui.utils.time import now_utc

    with open_db() as conn, conn:
        insert_record(conn, category_key="dev", description="x", started_at=now_utc())

    monkeypatch.setattr("task_recorder_cui.commands.timer.spawn_daemon", lambda r: None)
    rc = main(["timer", "set", "30m"])
    assert rc == 0


def test_cli_timer_cancel_dispatches(isolated_db, monkeypatch: pytest.MonkeyPatch) -> None:
    from datetime import timedelta

    from task_recorder_cui.db import open_db
    from task_recorder_cui.repo import insert_record, set_timer_target
    from task_recorder_cui.utils.time import now_utc

    with open_db() as conn, conn:
        rec_id = insert_record(conn, category_key="dev", description="x", started_at=now_utc())
        set_timer_target(conn, rec_id, target_at=now_utc() + timedelta(minutes=30))
    rc = main(["timer", "cancel"])
    assert rc == 0


def test_cli_config_list(
    isolated_db,
    tmp_path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setenv("TSK_CONFIG_PATH", str(tmp_path / "cfg.toml"))
    rc = main(["config", "list"])
    assert rc == 0
    assert "timer.enabled" in capsys.readouterr().out


def test_cli_start_with_timer_flag(isolated_db, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("task_recorder_cui.commands.start.spawn_daemon", lambda r: None)
    rc = main(["start", "dev", "desc", "--timer", "1h"])
    assert rc == 0


def test_cli_lang_flag_switches_output(isolated_db) -> None:
    """--lang en で current_lang が 'en' になる。"""
    from task_recorder_cui.cli import main
    from task_recorder_cui.i18n import current_lang, set_lang

    try:
        rc = main(["--lang", "en", "now"])
        assert rc in (0, 1)  # セッション有無に関わらず
        assert current_lang() == "en"
    finally:
        set_lang(None)


def test_cli_lang_flag_ja(isolated_db) -> None:
    """--lang ja で current_lang が 'ja' になる。"""
    from task_recorder_cui.cli import main
    from task_recorder_cui.i18n import current_lang, set_lang

    try:
        rc = main(["--lang", "ja", "now"])
        assert rc in (0, 1)
        assert current_lang() == "ja"
    finally:
        set_lang(None)


def test_cli_invalid_lang_rejected() -> None:
    """--lang fr は argparse が reject する (choices 制限)。"""
    from task_recorder_cui.cli import main

    with pytest.raises(SystemExit):
        main(["--lang", "fr", "now"])


def test_cli_cat_rename_dispatches(isolated_db, monkeypatch: pytest.MonkeyPatch) -> None:
    captured: list[tuple[str, str]] = []
    from task_recorder_cui.commands import cat as cat_cmd

    monkeypatch.setattr(
        cat_cmd,
        "rename_category",
        lambda key, new_display_name: captured.append((key, new_display_name)) or 0,
    )
    rc = main(["cat", "rename", "dev", "開発2"])
    assert rc == 0
    assert captured == [("dev", "開発2")]


def test_cli_config_get_dispatches(
    isolated_db,
    tmp_path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setenv("TSK_CONFIG_PATH", str(tmp_path / "cfg.toml"))
    rc = main(["config", "get", "timer.enabled"])
    assert rc == 0


def test_cli_config_set_dispatches(isolated_db, tmp_path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("TSK_CONFIG_PATH", str(tmp_path / "cfg.toml"))
    rc = main(["config", "set", "ui.bar_color", "red"])
    assert rc == 0


def test_cli_config_reset_dispatches(
    isolated_db, tmp_path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("TSK_CONFIG_PATH", str(tmp_path / "cfg.toml"))
    rc = main(["config", "reset", "ui.bar_color"])
    assert rc == 0


def test_cli_timer_daemon_hidden_dispatches(isolated_db, monkeypatch: pytest.MonkeyPatch) -> None:
    """hidden subcommand `_timer-daemon` が daemon_main を呼ぶ。"""
    calls: list[list[str]] = []

    def _fake_daemon_main(argv: list[str]) -> int:
        calls.append(argv)
        return 0

    import task_recorder_cui._timer_daemon as daemon_mod

    monkeypatch.setattr(daemon_mod, "main", _fake_daemon_main)
    rc = main(["_timer-daemon", "42"])
    assert rc == 0
    assert calls == [["42"]]
