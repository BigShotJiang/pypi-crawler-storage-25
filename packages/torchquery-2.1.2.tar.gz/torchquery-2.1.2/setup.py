from setuptools import setup, find_packages
import os

# Read the contents of your README file for the long description
# This is what pulls your logo and professional description into PyPI
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="torchquery",
    version="2.1.2",
    author="Sundaram Gupta",
    author_email="your-email@example.com", # Update this with your email
    description="A high-performance SDC detection and neural healing engine for billion-scale tensors.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/powerofaisinstudy-debug/torchquery",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Framework :: PyTorch",
    ],
    python_requires='>=3.7',
    install_requires=[
        "torch>=1.9.0",
        "numpy",
    ],
    include_package_data=True,
)