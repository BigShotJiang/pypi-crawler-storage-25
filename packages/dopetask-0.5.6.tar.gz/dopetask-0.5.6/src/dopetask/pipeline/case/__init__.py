"""Case audit pipeline components."""
