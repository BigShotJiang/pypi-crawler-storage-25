import pandas as pd
import numpy as np
import math
from datetime import datetime, timezone
from .fc_address import fc_address_list


def bgdeldup(dateName:str, minDate: datetime, client: str, bgTable:str):
    """
    Delete the data from the declared minDate to avoid duplicate in the database

    Parameters:
    - dateName: the name of the date column
    - minDate: the start date that will be deleted to avoid duplicate
    - client: the BigQuery client name
    - bgTable: the BigQuery Table address

    Returns:
    - delete the data to avoid duplicate
    """
    delDataQuery = f"""
    DELETE FROM
    `{bgTable}`
    WHERE
    {dateName} >= '{minDate}'
    """

    delData = client.query(delDataQuery)
    delData = delData.result()

    return delData

def bgdeldupM(dateName:str, minDate: datetime, marketplaceName:str, marketplacesArray,  client: str, bgTable:str):
    marketplaces_str = ", ".join(f"'{marketplace}'" for marketplace in marketplacesArray)

    delDataQuery = f"""
    DELETE FROM
        `{bgTable}`
    WHERE
        {dateName} >= '{minDate}'
        AND {marketplaceName} IN ({marketplaces_str})
    """

    delData = client.query(delDataQuery)
    delData = delData.result()

    return delData

def bgdeldupf(dateName:str, minDate: datetime, client: str, bgTable:str):
    """
    Delete the data from the declared minDate to avoid duplicate in the database
    (free version of BigQuery)

    Parameters:
    - dateName: the name of the date column
    - minDate: the start date that will be deleted to avoid duplicate
    - client: the BigQuery client name
    - bgTable: the BigQuery Table address

    Returns:
    - delete the data to avoid duplicate
    """
    delDataQuery = f"""
    CREATE OR REPLACE TABLE `{bgTable}` AS

    SELECT *
    FROM `{bgTable}`
    WHERE
    {dateName} < '{minDate}'
    """

    delData = client.query(delDataQuery)
    delData = delData.result()

    return delData

def bgdeldupfM(dateName:str, minDate: datetime, marketplaceName:str, marketplacesArray,  client: str, bgTable:str):
    marketplaces_str = ", ".join(f"'{marketplace}'" for marketplace in marketplacesArray)

    delDataQuery = f"""
    CREATE OR REPLACE TABLE `{bgTable}` AS

    SELECT *
    FROM `{bgTable}`
    WHERE NOT(
        {dateName} >= '{minDate}'
        AND IFNULL({marketplaceName}, 'nan') IN ({marketplaces_str})
    )
    """

    delData = client.query(delDataQuery)
    delData = delData.result()

    return delData

def dfbgcolcheck(df: pd.DataFrame, client: str, bgTable: str, username: str = None):
    """
    Compare DataFrame columns with the existing BigQuery Table.

    Non-fatal behavior:
    - If df has NEW columns not in BQ: drops them from df in place (so append won't
      break), and optionally notifies via zvdataautomation.com schema alert endpoint.
    - If df is MISSING columns that exist in BQ: logs a warning but proceeds.
    - Returns a dict with drift info. Never raises on schema drift.

    Parameters:
    - df: Data frame to check (modified in place if new columns exist)
    - client: BigQuery client
    - bgTable: the address of BigQuery Table
    - username: optional client username — if provided, new-column drift is
      reported to the central schema alert endpoint (deduplicated server-side)

    Returns:
    - dict: {'status': 'match'|'drift', 'new_columns': [...], 'missing_columns': [...], 'dropped_from_df': [...]}
    """
    existingDataQuery = f"""
    SELECT
    *
    FROM
    `{bgTable}`
    LIMIT 10
    """

    existingData = client.query(existingDataQuery).to_dataframe()

    if existingData.columns.equals(df.columns):
        print("Column names and positions are the same.")
        return {
            'status': 'match',
            'new_columns': [],
            'missing_columns': [],
            'dropped_from_df': []
        }

    missingColumns = sorted(set(existingData.columns) - set(df.columns))
    newColumns = sorted(set(df.columns) - set(existingData.columns))

    if newColumns:
        print(f"[dfbgcolcheck] NEW columns detected in df (dropping before append): {newColumns}")
        df.drop(columns=newColumns, inplace=True, errors='ignore')

    if missingColumns:
        print(f"[dfbgcolcheck] MISSING columns (exist in BQ, not in df — will be NULL on append): {missingColumns}")

    # Fire schema alert for new columns only (missing cols are not Amazon-side drift)
    if newColumns and username:
        try:
            from .api import notify_schema_alert
            notify_schema_alert(username, bgTable, newColumns, missingColumns)
        except Exception as e:
            print(f"[dfbgcolcheck] schema alert notification failed (ignored): {e!r}")

    return {
        'status': 'drift',
        'new_columns': newColumns,
        'missing_columns': missingColumns,
        'dropped_from_df': newColumns
    }

def lowfeereport(filePath:str):
    """
    This function process and clean the Amazon Economics Report.
    It extracts the low level inventory data

    Paremeters:
    - filePath: the path where the report is saved

    Returns:
    - DataFrame of the cleaned report
    - Flase if there is no data related to low level inventory fee
    """
    lowFeeDf = pd.read_csv(filePath)

    checkCol = [
        'Low-inventory-level fee per unit',
        'Low-inventory-level fee quantity',
        'Low-inventory-level fee total'
    ]

    colCheck = all(col in lowFeeDf.columns for col in checkCol)

    if colCheck:
        lowFeeDf = lowFeeDf[[
            'Start date',
            'End date',
            'ASIN',
            'MSKU',
            'Low-inventory-level fee per unit',
            'Low-inventory-level fee quantity',
            'Low-inventory-level fee total'
        ]]

        lowFeeDf = lowFeeDf.rename(columns=lambda x:x.replace('-','_').replace(' ','_').lower())
        lowFeeDf['start_date'] = pd.to_datetime(lowFeeDf['start_date'])
        lowFeeDf['end_date'] = pd.to_datetime(lowFeeDf['end_date'])

        schema = {
                'start_date': 'datetime64[ns]',
                'end_date': 'datetime64[ns]',
                'asin': str,
                'msku': str,
                'low_inventory_level_fee_per_unit': float,
                'low_inventory_level_fee_quantity': float,
                'low_inventory_level_fee_total': float
        }

        lowFeeDf = lowFeeDf.astype(schema)
        return lowFeeDf
    else:
        return False
    
def promoreport(filePath:str):
    """
    Clean the raw file downloaded in Amazon Seller Central Promotions Report

    Parameter:
    - filePath: the path where the downloaded Promotions Report is located

    Return:
    - DataFrame of the cleaned report
    """
    promoDf = pd.read_csv(filePath)
    promoDf = promoDf.rename(columns=lambda x:x.replace('?','').replace('"','').replace('-','_').lower())
    promoDf['shipment_date'] = pd.to_datetime(promoDf['shipment_date'], utc=True)

    schema = {
        'shipment_date': 'datetime64[ns, UTC]',
        'currency': str,
        'item_promotion_discount': float,
        'item_promotion_id': str,
        'description': str,
        'promotion_rule_value': str,
        'amazon_order_id': str,
        'shipment_id': str,
        'shipment_item_id': str
    }
    promoDf = promoDf.astype(schema)

    return promoDf

def spstreport(filePath:str, marketplace:str):
    spSearchTermDf = pd.read_excel(filePath)
    spSearchTermDf = spSearchTermDf.rename(columns=lambda X:X.replace('7','_7').replace('-','').replace('#','').replace('(','').replace(')','').replace(' ','_').lower())

    reqColumns = [
        'marketplace',
        'date',
        'portfolio_name',
        'currency',
        'campaign_name',
        'ad_group_name',
        'targeting',
        'match_type',
        'customer_search_term',
        'impressions',
        'clicks',
        'clickthru_rate_ctr',
        'cost_per_click_cpc',
        'spend',
        '_7_day_total_sales_',
        'total_advertising_cost_of_sales_acos_',
        'total_return_on_advertising_spend_roas',
        '_7_day_total_orders_',
        '_7_day_total_units_',
        '_7_day_conversion_rate',
        '_7_day_advertised_sku_units_',
        '_7_day_other_sku_units_',
        '_7_day_advertised_sku_sales_',
        '_7_day_other_sku_sales_',
        'retailer'
    ]

    spSearchTermDf.insert(0,'marketplace',marketplace)

    addColumns = [
        'retailer'
    ]

    for col in addColumns:
        if col not in spSearchTermDf:
            spSearchTermDf[col] = np.nan

    missingColumns = set(reqColumns) - set(spSearchTermDf.columns)
    newColumns = set(spSearchTermDf.columns) - set(reqColumns)

    if missingColumns:
        message = f"Missing columns: {', '.join(missingColumns)}"
        raise ValueError(message)

    if newColumns:
        print(f"New columns: {', '.join(newColumns)}")

    spSearchTermDf = spSearchTermDf[reqColumns]

    schema = {
        'marketplace': str,
        'date': 'datetime64[ns]',
        'portfolio_name': str,
        'currency': str,
        'campaign_name': str,
        'ad_group_name': str,
        'targeting': str,
        'match_type': str,
        'customer_search_term': str,
        'impressions': float,
        'clicks': float,
        'clickthru_rate_ctr': float,
        'cost_per_click_cpc': float,
        'spend': float,
        '_7_day_total_sales_': float,
        'total_advertising_cost_of_sales_acos_': float,
        'total_return_on_advertising_spend_roas': float,
        '_7_day_total_orders_': float,
        '_7_day_total_units_': float,
        '_7_day_conversion_rate': float,
        '_7_day_advertised_sku_units_': float,
        '_7_day_other_sku_units_': float,
        '_7_day_advertised_sku_sales_': float,
        '_7_day_other_sku_sales_': float,
        'retailer': str
    }

    spSearchTermDf = spSearchTermDf.astype(schema)

    return spSearchTermDf

def sbstreport(filePath:str, marketplace:str):
    sbSearchTermDf = pd.read_excel(filePath)
    sbSearchTermDf = sbSearchTermDf.rename(columns=lambda X:X.replace('14','_14').replace('-','').replace('#','').replace('(','').replace(')','').replace(',','').replace(' ','_').lower())
    sbSearchTermDf.insert(0,'marketplace',marketplace)
    
    reqColumns = [
        'marketplace',
        'date',
        'portfolio_name',
        'currency',
        'campaign_name',
        'ad_group_name',
        'targeting',
        'match_type',
        'customer_search_term',
        'cost_type',
        'impressions',
        'viewable_impressions',
        'clicks',
        'clickthru_rate_ctr',
        'spend',
        'cost_per_click_cpc',
        'cost_per_1000_viewable_impressions_vcpm',
        'total_advertising_cost_of_sales_acos_',
        'total_return_on_advertising_spend_roas',
        '_14_day_total_sales_',
        '_14_day_total_orders_',
        '_14_day_total_units_',
        '_14_day_conversion_rate',
        'total_advertising_cost_of_sales_acos__click',
        'total_return_on_advertising_spend_roas__click',
        '_14_day_total_sales__click',
        '_14_day_total_orders___click',
        '_14_day_total_units___click'
    ]

    missingColumns = set(reqColumns) - set(sbSearchTermDf.columns)
    newColumns = set(sbSearchTermDf.columns) - set(reqColumns)

    if missingColumns:
        raise ValueError(f"Missing columns: {', '.join(missingColumns)}")

    if newColumns:
        print(f"New columns: {', '.join(newColumns)}")

    sbSearchTermDf = sbSearchTermDf[reqColumns]

    schema = {
        'marketplace': str,
        'date': 'datetime64[ns]',
        'portfolio_name': str,
        'currency': str,
        'campaign_name': str,
        'ad_group_name': str,
        'targeting': str,
        'match_type': str,
        'customer_search_term': str,
        'cost_type': str,
        'impressions': float,
        'viewable_impressions': float,
        'clicks': float,
        'clickthru_rate_ctr': float,
        'spend': float,
        'cost_per_click_cpc': float,
        'cost_per_1000_viewable_impressions_vcpm': float,
        'total_advertising_cost_of_sales_acos_': float,
        'total_return_on_advertising_spend_roas': float,
        '_14_day_total_sales_': float,
        '_14_day_total_orders_': float,
        '_14_day_total_units_': float,
        '_14_day_conversion_rate': float,
        'total_advertising_cost_of_sales_acos__click': float,
        'total_return_on_advertising_spend_roas__click': float,
        '_14_day_total_sales__click': float,
        '_14_day_total_orders___click': float,
        '_14_day_total_units___click': float
    }

    sbSearchTermDf = sbSearchTermDf.astype(schema)

    return sbSearchTermDf

def sdtreport(filePath:str, marketplace:str):
    sdTargetingDf = pd.read_excel(filePath)
    sdTargetingDf = sdTargetingDf.rename(columns=lambda X:X.replace('14','_14').replace('-','').replace('#','').replace('(','').replace(')','').replace(',','').replace(' ','_').lower())

    sdTargetingDf.insert(0,'marketplace',marketplace)

    reqColumns = [
        'marketplace',
        'date',
        'currency',
        'campaign_name',
        'portfolio_name',
        'cost_type',
        'ad_group_name',
        'targeting',
        'bid_optimization',
        'impressions',
        'viewable_impressions',
        'clicks',
        'clickthru_rate_ctr',
        '_14_day_detail_page_views_dpv',
        'spend',
        'cost_per_click_cpc',
        'cost_per_1000_viewable_impressions_vcpm',
        'total_advertising_cost_of_sales_acos_',
        'total_return_on_advertising_spend_roas',
        '_14_day_total_orders_',
        '_14_day_total_units_',
        '_14_day_total_sales_',
        '_14_day_newtobrand_orders_',
        '_14_day_newtobrand_sales',
        '_14_day_newtobrand_units_',
        'total_advertising_cost_of_sales_acos__click',
        'total_return_on_advertising_spend_roas__click',
        '_14_day_total_orders___click',
        '_14_day_total_units___click',
        '_14_day_total_sales__click',
        '_14_day_newtobrand_orders___click',
        '_14_day_newtobrand_sales__click',
        '_14_day_newtobrand_units___click'
    ]

    missingColumns = set(reqColumns) - set(sdTargetingDf.columns)
    newColumns = set(sdTargetingDf.columns) - set(reqColumns)

    if missingColumns:
        raise ValueError(f"Missing columns: {', '.join(missingColumns)}")

    if newColumns:
        print(f"New columns: {', '.join(newColumns)}")

    sdTargetingDf = sdTargetingDf[reqColumns]

    schema = {
        'date': 'datetime64[ns]',
        'currency': str,
        'campaign_name': str,
        'portfolio_name': str,
        'cost_type': str,
        'ad_group_name': str,
        'targeting': str,
        'bid_optimization': str,
        'impressions': float,
        'viewable_impressions': float,
        'clicks': float,
        'clickthru_rate_ctr': float,
        '_14_day_detail_page_views_dpv': float,
        'spend': float,
        'cost_per_click_cpc': float,
        'cost_per_1000_viewable_impressions_vcpm': float,
        'total_advertising_cost_of_sales_acos_': float,
        'total_return_on_advertising_spend_roas': float,
        '_14_day_total_orders_': float,
        '_14_day_total_units_': float,
        '_14_day_total_sales_': float,
        '_14_day_newtobrand_orders_': float,
        '_14_day_newtobrand_sales': float,
        '_14_day_newtobrand_units_': float,
        'total_advertising_cost_of_sales_acos__click': float,
        'total_return_on_advertising_spend_roas__click': float,
        '_14_day_total_orders___click': float,
        '_14_day_total_units___click': float,
        '_14_day_total_sales__click': float,
        '_14_day_newtobrand_orders___click': float,
        '_14_day_newtobrand_sales__click': float,
        '_14_day_newtobrand_units___click': float
    }

    sdTargetingDf = sdTargetingDf.astype(schema)

    return sdTargetingDf

def spcreport(filePath:str):
    spCampaignDf = pd.read_csv(filePath)
    spCampaignDf = spCampaignDf.rename(columns=lambda X:X.replace('7','_7').replace('-','').replace('#','').replace('(','').replace(')','').replace(',','').replace(' ','_').lower())

    colRange = spCampaignDf.columns[7:]
    spCampaignDf[colRange] = spCampaignDf[colRange].replace({'%':'','\$':'',',':''}, regex=True)
    spCampaignDf['date'] = pd.to_datetime(spCampaignDf['date'])

    schema = {
        'date': 'datetime64[ns]',
        'portfolio_name': str,
        'campaign_type': str,
        'campaign_name': str,
        'country': str,
        'status': str,
        'currency': str,
        'budget': float,
        'targeting_type': str,
        'bidding_strategy': str,
        'impressions': float,
        'last_year_impressions': float,
        'clicks': float,
        'last_year_clicks': float,
        'clickthru_rate_ctr': float,
        'spend': float,
        'last_year_spend': float,
        'cost_per_click_cpc': float,
        'last_year_cost_per_click_cpc': float,
        '_7_day_total_orders_': float,
        'total_advertising_cost_of_sales_acos_': float,
        'total_return_on_advertising_spend_roas': float,
        '_7_day_total_sales_': float
    }

    spCampaignDf = spCampaignDf.astype(schema)

    return spCampaignDf

def sbcreport(filePath:str):
    sbCampaignDf = pd.read_excel(filePath)
    sbCampaignDf = sbCampaignDf.rename(columns=lambda X:X.replace('14','_14').replace('5','_5').replace('-','').replace('#','').replace('(','').replace(')','').replace(',','').replace(' ','_').lower())

    colRange = sbCampaignDf.columns[6:]
    sbCampaignDf[colRange] = sbCampaignDf[colRange].replace({'%':'','\$':'',',':''}, regex=True)
    sbCampaignDf['date'] = pd.to_datetime(sbCampaignDf['date'])

    schema = {
        'date': 'datetime64[ns]',
        'portfolio_name': str,
        'currency': str,
        'campaign_name': str,
        'cost_type': str,
        'country': str,
        'impressions': float,
        'clicks': float,
        'clickthru_rate_ctr': float,
        'cost_per_click_cpc': float,
        'spend': float,
        'total_advertising_cost_of_sales_acos_': float,
        'total_return_on_advertising_spend_roas': float,
        '_14_day_total_sales_': float,
        '_14_day_total_orders_': float,
        '_14_day_total_units_': float,
        '_14_day_conversion_rate': float,
        'viewable_impressions': float,
        'cost_per_1000_viewable_impressions_vcpm': float,
        'viewthrough_rate_vtr': float,
        'clickthrough_rate_for_views_vctr': float,
        'video_first_quartile_views': float,
        'video_midpoint_views': float,
        'video_third_quartile_views': float,
        'video_complete_views': float,
        'video_unmutes': float,
        '_5_second_views': float,
        '_5_second_view_rate': float,
        '_14_day_branded_searches': float,
        '_14_day_detail_page_views_dpv': float,
        '_14_day_newtobrand_orders_': float,
        '_14_day_%_of_orders_newtobrand': float,
        '_14_day_newtobrand_sales': float,
        '_14_day_%_of_sales_newtobrand': float,
        '_14_day_newtobrand_units_': float,
        '_14_day_%_of_units_newtobrand': float,
        '_14_day_newtobrand_order_rate': float,
        'total_advertising_cost_of_sales_acos__click': float,
        'total_return_on_advertising_spend_roas__click': float,
        '_14_day_total_sales__click': float,
        '_14_day_total_orders___click': float,
        '_14_day_total_units___click': float,
        'newtobrand_detail_page_views': float,
        'newtobrand_detail_page_view_clickthrough_conversions': float,
        'newtobrand_detail_page_view_rate': float,
        'effective_cost_per_newtobrand_detail_page_view': float,
        '_14_day_atc': float,
        '_14_day_atc_clicks': float,
        '_14_day_atcr': float,
        'effective_cost_per_add_to_cart_ecpatc': float,
        'branded_searches_clickthrough_conversions': float,
        'branded_searches_rate': float,
        'effective_cost_per_branded_search': float
    }

    sbCampaignDf = sbCampaignDf.astype(schema)
    
    return sbCampaignDf

def sdcreport(filePath:str):
    sdCampaignDf = pd.read_excel(filePath)
    sdCampaignDf = sdCampaignDf.rename(columns=lambda X:X.replace('14','_14').replace('-','').replace('#','').replace('(','').replace(')','').replace(',','').replace(' ','_').lower())

    colRange = sdCampaignDf.columns[4:]
    sdCampaignDf[colRange] = sdCampaignDf[colRange].replace({'%':'','\$':'',',':''}, regex=True)
    sdCampaignDf['date'] = pd.to_datetime(sdCampaignDf['date'])

    schema = {
        'date': 'datetime64[ns]',
        'country': str,
        'status': str,
        'currency': str,
        'budget': float,
        'campaign_name': str,
        'portfolio_name': str,
        'cost_type': str,
        'impressions': float,
        'viewable_impressions': float,
        'clicks': float,
        'clickthru_rate_ctr': float,
        '_14_day_detail_page_views_dpv': float,
        'spend': float,
        'cost_per_click_cpc': float,
        'cost_per_1000_viewable_impressions_vcpm': float,
        'total_advertising_cost_of_sales_acos_': float,
        'total_return_on_advertising_spend_roas': float,
        '_14_day_total_orders_': float,
        '_14_day_total_units_': float,
        '_14_day_total_sales_': float,
        '_14_day_newtobrand_orders_': float,
        '_14_day_newtobrand_sales': float,
        '_14_day_newtobrand_units_': float,
        'total_advertising_cost_of_sales_acos__click': float,
        'total_return_on_advertising_spend_roas__click': float,
        '_14_day_total_orders___click': float,
        '_14_day_total_units___click': float,
        '_14_day_total_sales__click': float,
        '_14_day_newtobrand_orders___click': float,
        '_14_day_newtobrand_sales__click': float,
        '_14_day_newtobrand_units___click': float,
        'newtobrand_detail_page_views': float,
        'newtobrand_detail_page_view_viewthrough_conversions': float,
        'newtobrand_detail_page_view_clickthrough_conversions': float,
        'newtobrand_detail_page_view_rate': float,
        'effective_cost_per_newtobrand_detail_page_view': float,
        '_14_day_atc': float,
        '_14_day_atc_views': float,
        '_14_day_atc_clicks': float,
        '_14_day_atcr': float,
        'effective_cost_per_add_to_cart_ecpatc': float,
        '_14_day_branded_searches': float,
        'branded_searches_viewthrough_conversions': float,
        'branded_searches_clickthrough_conversions': float,
        'branded_searches_rate': float,
        'effective_cost_per_branded_search': float
    }

    sdCampaignDf = sdCampaignDf.astype(schema)

    return sdCampaignDf

def unifiedRepo(filePath:str):
    unifiedDf = pd.read_csv(filePath, skiprows=9)
    unifiedDf = unifiedDf.rename(columns=lambda x:x.replace(' ','_').replace('-','_').replace('(','').replace(')','').replace('/','_'))

    unifiedDf['quantity'] = unifiedDf['quantity'].replace({np.nan:0},regex=True)
    colmChange = unifiedDf.columns[14:]
    unifiedDf[colmChange] = unifiedDf[colmChange].replace({',':''},regex=True)

    unifiedDf['date_time'] = pd.to_datetime(unifiedDf['date_time'].replace({' PDT':'', ' PST':''}, regex=True))
    unifiedDf['date_time'] = unifiedDf['date_time'].dt.tz_localize('America/Los_Angeles', ambiguous=True)

    req_columns = [
        'date_time',
        'settlement_id',
        'type',
        'order_id',
        'sku',
        'description',
        'quantity',
        'marketplace',
        'account_type',
        'fulfillment',
        'order_city',
        'order_state',
        'order_postal',
        'tax_collection_model',
        'product_sales',
        'product_sales_tax',
        'shipping_credits',
        'shipping_credits_tax',
        'gift_wrap_credits',
        'giftwrap_credits_tax',
        'Regulatory_Fee',
        'Tax_On_Regulatory_Fee',
        'promotional_rebates',
        'promotional_rebates_tax',
        'marketplace_withheld_tax',
        'selling_fees',
        'fba_fees',
        'other_transaction_fees',
        'other',
        'total'    
    ]

    for col in req_columns:
        if col not in unifiedDf.columns:
            unifiedDf[col] = np.nan

    unifiedDf = unifiedDf[req_columns]

    schema = {
        'date_time': 'datetime64[ns, America/Los_Angeles]',
        'settlement_id': str,
        'type': str,
        'order_id': str,
        'sku': str,
        'description': str,
        'quantity': int,
        'marketplace': str,
        'account_type': str,
        'fulfillment': str,
        'order_city': str,
        'order_state': str,
        'order_postal': str,
        'tax_collection_model': str,
        'product_sales': float,
        'product_sales_tax': float,
        'shipping_credits': float,
        'shipping_credits_tax': float,
        'gift_wrap_credits': float,
        'giftwrap_credits_tax': float,
        'Regulatory_Fee': float,
        'Tax_On_Regulatory_Fee': float,
        'promotional_rebates': float,
        'promotional_rebates_tax': float,
        'marketplace_withheld_tax': float,
        'selling_fees': float,
        'fba_fees': float,
        'other_transaction_fees': float,
        'other': float,
        'total': float
    }

    unifiedDf = unifiedDf.astype(schema)

    return unifiedDf

def storageFeeReport(filePath:str):
    try:
        storageFeeDf = pd.read_csv(filePath)
    except UnicodeDecodeError:
        storageFeeDf = pd.read_csv(filePath, encoding='ISO-8859-1')

    storageFeeDf['month_of_charge'] = pd.to_datetime(storageFeeDf['month_of_charge'])

    req_columns = [
        'asin',
        'fnsku',
        'product_name',
        'fulfillment_center',
        'country_code',
        'longest_side',
        'median_side',
        'shortest_side',
        'measurement_units',
        'weight',
        'weight_units',
        'item_volume',
        'volume_units',
        'product_size_tier',
        'average_quantity_on_hand',
        'average_quantity_pending_removal',
        'estimated_total_item_volume',
        'month_of_charge',
        'storage_utilization_ratio',
        'storage_utilization_ratio_units',
        'base_rate',
        'utilization_surcharge_rate',
        'avg_qty_for_sus',
        'est_vol_for_sus',
        'est_base_msf',
        'est_sus',
        'currency',
        'estimated_monthly_storage_fee',
        'dangerous_goods_storage_type',
        'eligible_for_inventory_discount',
        'qualifies_for_inventory_discount',
        'total_incentive_fee_amount',
        'breakdown_incentive_fee_amount',
        'average_quantity_customer_orders'
    ]

    for col in req_columns:
        if col not in storageFeeDf.columns:
            storageFeeDf[col] = np.nan

    storageFeeDf = storageFeeDf[req_columns]

    schema = {
        'asin': str,
        'fnsku': str,
        'product_name': str,
        'fulfillment_center': str,
        'country_code': str,
        'longest_side': float,
        'median_side': float,
        'shortest_side': float,
        'measurement_units': str,
        'weight': float,
        'weight_units': str,
        'item_volume': float,
        'volume_units': str,
        'product_size_tier': str,
        'average_quantity_on_hand': float,
        'average_quantity_pending_removal': float,
        'estimated_total_item_volume': float,
        'month_of_charge': 'datetime64[ns]',
        'storage_utilization_ratio': str,
        'storage_utilization_ratio_units': str,
        'base_rate': float,
        'utilization_surcharge_rate': float,
        'avg_qty_for_sus': float,
        'est_vol_for_sus': float,
        'est_base_msf': float,
        'est_sus': float,
        'currency': str,
        'estimated_monthly_storage_fee': float,
        'dangerous_goods_storage_type': str,
        'eligible_for_inventory_discount': str,
        'qualifies_for_inventory_discount': str,
        'total_incentive_fee_amount': float,
        'breakdown_incentive_fee_amount': str,
        'average_quantity_customer_orders': float
    }
    storageFeeDf = storageFeeDf.astype(schema)

    return storageFeeDf

def overAgeFeeReport(filepath:str):
    try:
        overAgeDf = pd.read_csv(filepath)
    except UnicodeDecodeError:
        overAgeDf = pd.read_csv(filepath, encoding='ISO-8859-1')

    overAgeDf = overAgeDf.rename(columns=lambda x:x.replace('-','_').lower())

    overAgeDf['snapshot_date'] = pd.to_datetime(overAgeDf['snapshot_date'])

    req_columns = [
        'snapshot_date',
        'sku',
        'fnsku',
        'asin',
        'product_name',
        'condition',
        'per_unit_volume',
        'currency',
        'volume_unit',
        'country',
        'qty_charged',
        'amount_charged',
        'surcharge_age_tier',
        'rate_surcharge'
    ]

    for col in req_columns:
        if col not in overAgeDf.columns:
            overAgeDf[col] = np.nan

    overAgeDf = overAgeDf[req_columns]

    schema = {
        'snapshot_date': 'datetime64[ns, UTC]',
        'sku': str,
        'fnsku': str,
        'asin': str,
        'product_name': str,
        'condition': str,
        'per_unit_volume': float,
        'currency': str,
        'volume_unit': str,
        'country': str,
        'qty_charged': float,
        'amount_charged': float,
        'surcharge_age_tier': str,
        'rate_surcharge': float
    }

    overAgeDf = overAgeDf.astype(schema)

    return overAgeDf

def returnProcessFeeReport(filepath:str):
    try:
        returnFeeDf = pd.read_csv(filepath)
    except UnicodeDecodeError:
        returnFeeDf = pd.read_csv(filepath, encoding='ISO-8859-1')

    returnFeeDf['month_of_charge'] = pd.to_datetime(returnFeeDf['month_of_charge'])
    returnFeeDf['month_of_shipment'] = pd.to_datetime(returnFeeDf['month_of_shipment'])

    req_columns = [
        'asin',
        'asin_fee_category',
        'fnsku',
        'product_name',
        'longest_side',
        'median_side',
        'shortest_side',
        'measurement-units',
        'unit_weight',
        'dimensional_weight',
        'shipping_weight',
        'weight_units',
        'sku_sizetier',
        'month_of_shipment',
        'asin_shipped_units',
        'asin_return_threshold_percent',
        'asin_return_threshold_units',
        'asin_returned_units',
        'sku_returned_units_NSP_exempted',
        'sku_returned_units_charged',
        'sku_fee_per_unit',
        'sku_returns_fee',
        'month_of_charge',
        'currency'
    ]

    for col in req_columns:
        if col not in returnFeeDf.columns:
            returnFeeDf[col] = np.nan

    returnFeeDf = returnFeeDf[req_columns]

    schema = {
        'asin': str,
        'asin_fee_category': str,
        'fnsku': str,
        'product_name': str,
        'longest_side': float,
        'median_side': float,
        'shortest_side': float,
        'measurement-units': str,
        'unit_weight': float,
        'dimensional_weight': float,
        'shipping_weight': float,
        'weight_units': str,
        'sku_sizetier': str,
        'month_of_shipment': 'datetime64[ns]',
        'asin_shipped_units': float,
        'asin_return_threshold_percent': float,
        'asin_return_threshold_units': float,
        'asin_returned_units': float,
        'sku_returned_units_NSP_exempted': float,
        'sku_returned_units_charged': float,
        'sku_fee_per_unit': float,
        'sku_returns_fee': float,
        'month_of_charge': 'datetime64[ns]',
        'currency': str
    }

    returnFeeDf = returnFeeDf.astype(schema)

    return returnFeeDf

def fbaFeeReport(filePath:str):
    try:
        fbaFeeDf = pd.read_csv(filePath)
    except UnicodeDecodeError:
        fbaFeeDf = pd.read_csv(filePath, encoding='ISO-8859-1')

    fbaFeeDf = fbaFeeDf.rename(columns=lambda x:x.replace('?"sku"','sku').replace('-','_').lower())
    fbaFeeDf.insert(0, 'date', datetime.now(timezone.utc).date())
    fbaFeeDf['date'] = pd.to_datetime(fbaFeeDf['date'])

    req_columns = [
        'date',
        'sku',
        'fnsku',
        'asin',
        'amazon_store',
        'product_name',
        'product_group',
        'brand',
        'fulfilled_by',
        'your_price',
        'sales_price',
        'longest_side',
        'median_side',
        'shortest_side',
        'length_and_girth',
        'unit_of_dimension',
        'item_package_weight',
        'unit_of_weight',
        'product_size_tier',
        'currency',
        'estimated_fee_total',
        'estimated_referral_fee_per_unit',
        'estimated_variable_closing_fee',
        'estimated_order_handling_fee_per_order',
        'estimated_pick_pack_fee_per_unit',
        'estimated_weight_handling_fee_per_unit',
        'expected_fulfillment_fee_per_unit'
    ]

    for col in req_columns:
        if col not in fbaFeeDf.columns:
            fbaFeeDf[col] = np.nan

    fbaFeeDf = fbaFeeDf[req_columns]

    schema = {
        'date': 'datetime64[ns]',
        'sku': str,
        'fnsku': str,
        'asin': str,
        'amazon_store': str,
        'product_name': str,
        'product_group': str,
        'brand': str,
        'fulfilled_by': str,
        'your_price': float,
        'sales_price': float,
        'longest_side': float,
        'median_side': float,
        'shortest_side': float,
        'length_and_girth': float,
        'unit_of_dimension': str,
        'item_package_weight': float,
        'unit_of_weight': str,
        'product_size_tier': str,
        'currency': str,
        'estimated_fee_total': float,
        'estimated_referral_fee_per_unit': float,
        'estimated_variable_closing_fee': str,
        'estimated_order_handling_fee_per_order': str,
        'estimated_pick_pack_fee_per_unit': str,
        'estimated_weight_handling_fee_per_unit': str,
        'expected_fulfillment_fee_per_unit': float
    }

    fbaFeeDf = fbaFeeDf.astype(schema)

    return fbaFeeDf

def inboundPlacementReport(filePath:str):
    try:
        inboundPlacementDf = pd.read_csv(filePath)
    except UnicodeDecodeError:
        inboundPlacementDf = pd.read_csv(filePath, encoding='ISO-8859-1')

    inboundPlacementDf = inboundPlacementDf.rename(columns=lambda x:x.replace('(','').replace(')','').replace(' ','_').lower())
    inboundPlacementDf['transaction_date'] = pd.to_datetime(inboundPlacementDf['transaction_date'])

    req_columns = [
        'transaction_date',
        'shipping_plan_id',
        'fba_shipment_id',
        'country',
        'fnsku',
        'asin',
        'planned_fba_inbound_placement_service',
        'planned_number_of_shipments',
        'compliant_number_of_shipments',
        'inbound_defect_type',
        'actual_charge_tier',
        'planned_inbound_region',
        'actual_inbound_region',
        'actual_received_quantity',
        'product_size_tier',
        'shipping_weight',
        'unit_of_weight',
        'fba_inbound_placement_service_fee_rate_per_unit',
        'eligible_applied_incentive',
        'currency',
        'total_fba_inbound_placement_service_fee_charge',
        'total_charges'
    ]

    for col in req_columns:
        if col not in inboundPlacementDf.columns:
            inboundPlacementDf[col] = np.nan

    inboundPlacementDf = inboundPlacementDf[req_columns]

    schema = {
        'transaction_date': 'datetime64[ns]',
        'shipping_plan_id': str,
        'fba_shipment_id': str,
        'country': str,
        'fnsku': str,
        'asin': str,
        'planned_fba_inbound_placement_service': str,
        'planned_number_of_shipments': float,
        'compliant_number_of_shipments': float,
        'inbound_defect_type': str,
        'actual_charge_tier': str,
        'planned_inbound_region': str,
        'actual_inbound_region': str,
        'actual_received_quantity': float,
        'product_size_tier': str,
        'shipping_weight': float,
        'unit_of_weight': str,
        'fba_inbound_placement_service_fee_rate_per_unit': float,
        'eligible_applied_incentive': float,
        'currency': str,
        'total_fba_inbound_placement_service_fee_charge': float,
        'total_charges': float
    }

    inboundPlacementDf = inboundPlacementDf.astype(schema)

    return inboundPlacementDf

def campAttribReport(filePath:str):
    attCampDf = pd.read_excel(filePath)
    attCampDf = attCampDf.rename(columns=lambda x:x.replace('14','_14').replace(' ','_').lower())

    req_columns = [
        'date',
        'advertiser_country',
        'order_currency',
        'advertiser',
        'publisher',
        'channel',
        'campaign_name',
        'ad_group_name',
        'clicks',
        '_14_day_total_dpv',
        '_14_day_total_atc',
        '_14_day_total_purchases',
        '_14_day_total_units_sold',
        '_14_day_total_sales_',
        '_14_day_total_dpvr_clicks',
        '_14_day_total_atcr_clicks',
        '_14_day_total_purchase_rate_clicks',
        '_14_day_dpv',
        '_14_day_atc',
        '_14_day_purchases',
        '_14_day_units_sold',
        '_14_day_product_sales'
    ]

    for col in req_columns:
        if col not in attCampDf.columns:
            attCampDf[col] = np.nan

    attCampDf = attCampDf[req_columns]

    schema = {
        'date': 'datetime64[ns]',
        'advertiser_country': str,
        'order_currency': str,
        'advertiser': str,
        'publisher': str,
        'channel': str,
        'campaign_name': str,
        'ad_group_name': str,
        'clicks': float,
        '_14_day_total_dpv': float,
        '_14_day_total_atc': float,
        '_14_day_total_purchases': float,
        '_14_day_total_units_sold': float,
        '_14_day_total_sales_': float,
        '_14_day_total_dpvr_clicks': float,
        '_14_day_total_atcr_clicks': float,
        '_14_day_total_purchase_rate_clicks': float,
        '_14_day_dpv': float,
        '_14_day_atc': float,
        '_14_day_purchases': float,
        '_14_day_units_sold': float,
        '_14_day_product_sales': float
    }

    attCampDf = attCampDf.astype(schema)

    return attCampDf

def invWarehouseLoc(filePath:str):
    invWarehouseDf = pd.read_csv(filePath)
    invWarehouseDf = invWarehouseDf.rename(columns=lambda x:x.replace(' ','_').replace('/','_').lower())

    invWarehouseDf['date'] = pd.to_datetime(invWarehouseDf['date'])

    req_columns = [
        'date',
        'fnsku',
        'asin',
        'msku',
        'title',
        'disposition',
        'starting_warehouse_balance',
        'in_transit_between_warehouses',
        'receipts',
        'customer_shipments',
        'customer_returns',
        'vendor_returns',
        'warehouse_transfer_in_out',
        'found',
        'lost',
        'damaged',
        'disposed',
        'other_events',
        'ending_warehouse_balance',
        'unknown_events',
        'location',
        'store'
    ]

    for col in req_columns:
        if col not in invWarehouseDf.columns:
            invWarehouseDf[col] = np.nan

    invWarehouseDf = invWarehouseDf[req_columns]

    schema = {
        'date': 'datetime64[ns]',
        'fnsku': str,
        'asin': str,
        'msku': str,
        'title': str,
        'disposition': str,
        'starting_warehouse_balance': float,
        'in_transit_between_warehouses': float,
        'receipts': float,
        'customer_shipments': float,
        'customer_returns': float,
        'vendor_returns': float,
        'warehouse_transfer_in_out': float,
        'found': float,
        'lost': float,
        'damaged': float,
        'disposed': float,
        'other_events': float,
        'ending_warehouse_balance': float,
        'unknown_events': float,
        'location': str,
        'store': str
    }

    invWarehouseDf = invWarehouseDf.astype(schema)
    return invWarehouseDf

def spAdvertisedReport(filePath:str, marketplace:str):
    spAdvertisedDf = pd.read_excel(filePath)
    spAdvertisedDf = spAdvertisedDf.rename(columns=lambda x:x.replace(' ','_').replace('-','_').replace('(','').replace(')','')
                                                                .replace('#','').replace('$','').replace('7','_7')
                                                                .lower()
                                                                .replace('total_advertising_cost_of_sales_acos_','advertising_cost_of_sales_acos_')
                                                                .replace('total_return_on_advertising_spend_roas','return_on_advertising_spend_roas')
                                            )
    
    spAdvertisedDf.insert(0, 'marketplace', marketplace)
    req_columns = [
        'marketplace',
        'date',
        'portfolio_name',
        'currency',
        'campaign_name',
        'ad_group_name',
        'advertised_sku',
        'advertised_asin',
        'impressions',
        'clicks',
        'click_thru_rate_ctr',
        'cost_per_click_cpc',
        'spend',
        '_7_day_total_sales_',
        'advertising_cost_of_sales_acos_',
        'return_on_advertising_spend_roas',
        '_7_day_total_orders_',
        '_7_day_total_units_',
        '_7_day_conversion_rate',
        '_7_day_advertised_sku_units_',
        '_7_day_other_sku_units_',
        '_7_day_advertised_sku_sales_',
        '_7_day_other_sku_sales_',
        'retailer'
    ]

    addColumns = [
        'retailer'
    ]

    for col in addColumns:
        if col not in spAdvertisedDf.columns:
            spAdvertisedDf[col] = np.nan

    missingColumns = set(req_columns) - set(spAdvertisedDf.columns)
    newColumns = set(spAdvertisedDf.columns) - set(req_columns)

    if missingColumns:
        raise ValueError(f"Missing columns: {', '.join(missingColumns)}")

    if newColumns:
        print(f"New columns: {', '.join(newColumns)}")

    spAdvertisedDf = spAdvertisedDf[req_columns]

    schema = {
        'marketplace': str,
        'date': 'datetime64[ns]',
        'portfolio_name': str,
        'currency': str,
        'campaign_name': str,
        'ad_group_name': str,
        'advertised_sku': str,
        'advertised_asin': str,
        'impressions': float,
        'clicks': float,
        'click_thru_rate_ctr': float,
        'cost_per_click_cpc': float,
        'spend': float,
        '_7_day_total_sales_': float,
        'advertising_cost_of_sales_acos_': float,
        'return_on_advertising_spend_roas': float,
        '_7_day_total_orders_': float,
        '_7_day_total_units_': float,
        '_7_day_conversion_rate': float,
        '_7_day_advertised_sku_units_': float,
        '_7_day_other_sku_units_': float,
        '_7_day_advertised_sku_sales_': float,
        '_7_day_other_sku_sales_': float,
        'retailer': str
    }

    spAdvertisedDf = spAdvertisedDf.astype(schema)

    return spAdvertisedDf

def sdAdvertisedReport(filePath:str, marketplace:str):
    sdAdvertisedDf = pd.read_excel(filePath)
    sdAdvertisedDf = sdAdvertisedDf.rename(columns=lambda x:x.replace(' ','_').replace('-','_').replace('(','').replace(')','')
                                                            .replace('#','').replace('$','').replace('14','_14').replace(',','')
                                                            .lower()
                                                            .replace('total_advertising_cost_of_sales_acos_','advertising_cost_of_sales_acos_')
                                                            .replace('total_return_on_advertising_spend_roas','return_on_advertising_spend_roas')
                                        )

    sdAdvertisedDf.insert(0, 'marketplace', marketplace)
    req_columns = [
        'marketplace',
        'date',
        'currency',
        'campaign_name',
        'portfolio_name',
        'cost_type',
        'ad_group_name',
        'bid_optimization',
        'advertised_sku',
        'advertised_asin',
        'impressions',
        'viewable_impressions',
        'clicks',
        'click_thru_rate_ctr',
        '_14_day_detail_page_views_dpv',
        'spend',
        'cost_per_click_cpc',
        'cost_per_1000_viewable_impressions_vcpm',
        'advertising_cost_of_sales_acos_',
        'return_on_advertising_spend_roas',
        '_14_day_total_orders_',
        '_14_day_total_units_',
        '_14_day_total_sales_',
        '_14_day_new_to_brand_orders_',
        '_14_day_new_to_brand_sales',
        '_14_day_new_to_brand_units_',
        'advertising_cost_of_sales_acos___click',
        'return_on_advertising_spend_roas___click',
        '_14_day_total_orders____click',
        '_14_day_total_units____click',
        '_14_day_total_sales___click',
        '_14_day_new_to_brand_orders____click',
        '_14_day_new_to_brand_sales___click',
        '_14_day_new_to_brand_units____click'
    ]

    missingColumns = set(req_columns) - set(sdAdvertisedDf.columns)
    newColumns = set(sdAdvertisedDf.columns) - set(req_columns)

    if missingColumns:
        raise ValueError(f"Missing columns: {', '.join(missingColumns)}")

    if newColumns:
        print(f"New columns: {', '.join(newColumns)}")

    sdAdvertisedDf = sdAdvertisedDf[req_columns]

    schema = {
        'marketplace': str,
        'date': 'datetime64[ns]',
        'currency': str,
        'campaign_name': str,
        'portfolio_name': str,
        'cost_type': str,
        'ad_group_name': str,
        'bid_optimization': str,
        'advertised_sku': str,
        'advertised_asin': str,
        'impressions': float,
        'viewable_impressions': float,
        'clicks': float,
        'click_thru_rate_ctr': float,
        '_14_day_detail_page_views_dpv': float,
        'spend': float,
        'cost_per_click_cpc': float,
        'cost_per_1000_viewable_impressions_vcpm': float,
        'advertising_cost_of_sales_acos_': float,
        'return_on_advertising_spend_roas': float,
        '_14_day_total_orders_': float,
        '_14_day_total_units_': float,
        '_14_day_total_sales_': float,
        '_14_day_new_to_brand_orders_': float,
        '_14_day_new_to_brand_sales': float,
        '_14_day_new_to_brand_units_': float,
        'advertising_cost_of_sales_acos___click': float,
        'return_on_advertising_spend_roas___click': float,
        '_14_day_total_orders____click': float,
        '_14_day_total_units____click': float,
        '_14_day_total_sales___click': float,
        '_14_day_new_to_brand_orders____click': float,
        '_14_day_new_to_brand_sales___click': float,
        '_14_day_new_to_brand_units____click': float
    }

    sdAdvertisedDf = sdAdvertisedDf.astype(schema)

    return sdAdvertisedDf

def spTargetingReport(filePath:str, marketplace:str):
    spTargetingDf = pd.read_excel(filePath)
    spTargetingDf = spTargetingDf.rename(columns=lambda x:x.replace(' ','_').replace('-','_').replace('(','').replace(')','')
                                                            .replace('#','').replace('$','').replace(',','').replace('7','_7')
                                                            .lower()
                                        )

    spTargetingDf.insert(0, 'marketplace', marketplace)
    req_columns = [
        'marketplace',
        'date',
        'portfolio_name',
        'currency',
        'campaign_name',
        'ad_group_name',
        'targeting',
        'match_type',
        'impressions',
        'top_of_search_impression_share',
        'clicks',
        'click_thru_rate_ctr',
        'cost_per_click_cpc',
        'spend',
        'total_advertising_cost_of_sales_acos_',
        'total_return_on_advertising_spend_roas',
        '_7_day_total_sales_',
        '_7_day_total_orders_',
        '_7_day_total_units_',
        '_7_day_conversion_rate',
        '_7_day_advertised_sku_units_',
        '_7_day_other_sku_units_',
        '_7_day_advertised_sku_sales_',
        '_7_day_other_sku_sales_',
        'retailer'
    ]

    addColumns = [
        'retailer'
    ]

    for col in addColumns:
        if col not in spTargetingDf.columns:
            spTargetingDf[col] = np.nan

    missingColumns = set(req_columns) - set(spTargetingDf.columns)
    newColumns = set(spTargetingDf.columns) - set(req_columns)

    if missingColumns:
        raise ValueError(f"Missing columns: {', '.join(missingColumns)}")

    if newColumns:
        print(f"New columns: {', '.join(newColumns)}")

    spTargetingDf = spTargetingDf[req_columns]

    schema = {
        'marketplace': str,
        'date': 'datetime64[ns]',
        'portfolio_name': str,
        'currency': str,
        'campaign_name': str,
        'ad_group_name': str,
        'targeting': str,
        'match_type': str,
        'impressions': float,
        'top_of_search_impression_share': float,
        'clicks': float,
        'click_thru_rate_ctr': float,
        'cost_per_click_cpc': float,
        'spend': float,
        'total_advertising_cost_of_sales_acos_': float,
        'total_return_on_advertising_spend_roas': float,
        '_7_day_total_sales_': float,
        '_7_day_total_orders_': float,
        '_7_day_total_units_': float,
        '_7_day_conversion_rate': float,
        '_7_day_advertised_sku_units_': float,
        '_7_day_other_sku_units_': float,
        '_7_day_advertised_sku_sales_': float,
        '_7_day_other_sku_sales_': float,
        'retailer': str
    }

    spTargetingDf = spTargetingDf.astype(schema)

    return spTargetingDf

def shipmentsReport(filePath:str):
    try:
        shipmentsDf = pd.read_csv(filePath)
    except UnicodeDecodeError:
        shipmentsDf = pd.read_csv(filePath, encoding='ISO-8859-1')
        
    shipmentsDf = shipmentsDf.rename(columns=lambda x:x.replace(' ','_').lower())
    shipmentsDf['created'] = pd.to_datetime(shipmentsDf['created'])
    shipmentsDf['last_updated'] = pd.to_datetime(shipmentsDf['last_updated'])

    req_columns = [
        'shipment_name',
        'shipment_id',
        'created',
        'last_updated',
        'ship_to',
        'skus',
        'units_expected',
        'units_located',
        'status'
    ]

    for col in req_columns:
        if col not in shipmentsDf.columns:
            shipmentsDf[col] = np.nan

    shipmentsDf = shipmentsDf[req_columns]

    schema = {
        'shipment_name': str,
        'shipment_id': str,
        'created': 'datetime64[ns]',
        'last_updated': 'datetime64[ns]',
        'ship_to': str,
        'skus': float,
        'units_expected': float,
        'units_located': float,
        'status': str
    }

    shipmentsDf = shipmentsDf.astype(schema)

    return shipmentsDf

def reimbursementReport(filePath:str):
    try:
        reimbursementDf = pd.read_csv(filePath)
    except UnicodeDecodeError:
        reimbursementDf = pd.read_csv(filePath, encoding='ISO-8859-1')

    reimbursementDf = reimbursementDf.rename(columns=lambda x:x.replace(' ','_').replace('-','_').lower())
    reimbursementDf['approval_date'] = pd.to_datetime(reimbursementDf['approval_date'])

    req_columns = [
        'approval_date',
        'reimbursement_id',
        'case_id',
        'amazon_order_id',
        'reason',
        'sku',
        'fnsku',
        'asin',
        'product_name',
        'condition',
        'currency_unit',
        'amount_per_unit',
        'amount_total',
        'quantity_reimbursed_cash',
        'quantity_reimbursed_inventory',
        'quantity_reimbursed_total',
        'original_reimbursement_id',
        'original_reimbursement_type'
    ]

    for col in req_columns:
        if col not in reimbursementDf:
            reimbursementDf[col] = np.nan

    reimbursementDf = reimbursementDf[req_columns]

    schema = {
        'approval_date': 'datetime64[ns, UTC]',
        'reimbursement_id': str,
        'case_id': str,
        'amazon_order_id': str,
        'reason': str,
        'sku': str,
        'fnsku': str,
        'asin': str,
        'product_name': str,
        'condition': str,
        'currency_unit': str,
        'amount_per_unit': float,
        'amount_total': float,
        'quantity_reimbursed_cash': float,
        'quantity_reimbursed_inventory': float,
        'quantity_reimbursed_total': float,
        'original_reimbursement_id': float,
        'original_reimbursement_type': str
    }

    reimbursementDf = reimbursementDf.astype(schema)

    return reimbursementDf

def ledgerReport(filePath:str):
    try:
        ledgerDf = pd.read_csv(filePath)
    except UnicodeDecodeError:
        ledgerDf = pd.read_csv(filePath, encoding='ISO-8859-1')

    ledgerDf = ledgerDf.rename(columns=lambda x:x.replace(' ','_').lower())
    ledgerDf['date'] = pd.to_datetime(ledgerDf['date'])
    ledgerDf['date_and_time'] = pd.to_datetime(ledgerDf['date_and_time'])

    req_columns = [
        'date',
        'fnsku',
        'asin',
        'msku',
        'title',
        'event_type',
        'reference_id',
        'quantity',
        'fulfillment_center',
        'disposition',
        'reason',
        'country',
        'reconciled_quantity',
        'unreconciled_quantity',
        'date_and_time',
        'store'
    ]

    for col in req_columns:
        if col not in ledgerDf.columns:
            ledgerDf[col] = np.nan

    ledgerDf = ledgerDf[req_columns]

    schema = {
        'date': 'datetime64[ns]',
        'fnsku': str,
        'asin': str,
        'msku': str,
        'title': str,
        'event_type': str,
        'reference_id': str,
        'quantity': float,
        'fulfillment_center': str,
        'disposition': str,
        'reason': str,
        'country': str,
        'reconciled_quantity': float,
        'unreconciled_quantity': float,
        'date_and_time': 'datetime64[ns, UTC]',
        'store': str
    }

    ledgerDf = ledgerDf.astype(schema)

    return ledgerDf

def replacementReport(filePath:str):
    try:
        replacementDf = pd.read_csv(filePath)
    except UnicodeDecodeError:
        replacementDf = pd.read_csv(filePath, encoding='ISO-8859-1')

    replacementDf = replacementDf.rename(columns=lambda x:x.replace('?"shipment-date"','shipment_date').replace(' ','_').replace('-','_').lower())
    replacementDf['shipment_date'] = pd.to_datetime(replacementDf['shipment_date'], utc=True)

    req_columns = [
        'shipment_date',
        'sku',
        'asin',
        'fulfillment_center_id',
        'original_fulfillment_center_id',
        'quantity',
        'replacement_reason_code',
        'replacement_amazon_order_id',
        'original_amazon_order_id'
    ]

    for col in req_columns:
        if col not in replacementDf.columns:
            replacementDf[col] = np.nan
        
    replacementDf = replacementDf[req_columns]

    schema = {
        'shipment_date': 'datetime64[ns, UTC]',
        'sku': str,
        'asin': str,
        'fulfillment_center_id': str,
        'original_fulfillment_center_id': str,
        'quantity': float,
        'replacement_reason_code': str,
        'replacement_amazon_order_id': str,
        'original_amazon_order_id': str
    }

    replacementDf = replacementDf.astype(schema)

    return replacementDf

def customerReturnReport(filePath:str):
    try:
        customerReturnDf = pd.read_csv(filePath)
    except UnicodeDecodeError:
        customerReturnDf = pd.read_csv(filePath, encoding='ISO-8859-1')

    customerReturnDf = customerReturnDf.rename(columns=lambda x:x.replace(' ','_').replace('-','_').lower())
    customerReturnDf['return_date'] = pd.to_datetime(customerReturnDf['return_date'], utc=True)

    req_columns = [
        'return_date',
        'order_id',
        'sku',
        'asin',
        'fnsku',
        'product_name',
        'quantity',
        'fulfillment_center_id',
        'detailed_disposition',
        'reason',
        'status',
        'license_plate_number',
        'customer_comments'
    ]

    for col in req_columns:
        if col not in customerReturnDf.columns:
            customerReturnDf[col] = np.nan

    customerReturnDf = customerReturnDf[req_columns]

    schema = {
        'return_date': 'datetime64[ns, UTC]',
        'order_id': str,
        'sku': str,
        'asin': str,
        'fnsku': str,
        'product_name': str,
        'quantity': float,
        'fulfillment_center_id': str,
        'detailed_disposition': str,
        'reason': str,
        'status': str,
        'license_plate_number': str,
        'customer_comments': str
    }

    customerReturnDf = customerReturnDf.astype(schema)

    return customerReturnDf

def spPlacementReport(filePath, marketplace):
    dfInit = pd.read_excel(filePath)
    dfInit = dfInit.rename(columns=lambda x:x.replace(' ','_').replace('-','').replace('(','')
                                            .replace(')','').replace('#','').replace('7_Day_','')
                                            .lower()
                          )
    dfInit.insert(0,'marketplace', marketplace)

    addColumns = [
        'retailer'
    ]

    for col in addColumns:
        if col not in dfInit.columns:
            dfInit[col] = np.nan

    reqColumns = [
        'date',
        'marketplace',
        'portfolio_name',
        'campaign_name',
        'bidding_strategy',
        'placement',
        'impressions',
        'clicks',
        'total_orders_',
        'total_units_',
        'currency',
        'spend',
        'total_sales_',
        'retailer',
        'total_advertising_cost_of_sales_acos_',
        'cost_per_click_cpc',
        'total_return_on_advertising_spend_roas'
    ]

    missingColumns = set(reqColumns) - set(dfInit.columns)
    newColumns = set(dfInit.columns) - set(reqColumns)

    if missingColumns:
        raise ValueError(f"Missing columns: {', '.join(missingColumns)}")

    if newColumns:
        print(f"New columns: {', '.join(newColumns)}")

    placementDfFinal = dfInit[reqColumns]

    schema = {
        'date': 'datetime64[ns]',
        'marketplace': str,
        'portfolio_name': str,
        'campaign_name': str,
        'bidding_strategy': str,
        'placement': str,
        'impressions': float,
        'clicks': float,
        'total_orders_': float,
        'total_units_': float,
        'currency': str,
        'spend': float,
        'total_sales_': float,
        'retailer': str,
        'total_advertising_cost_of_sales_acos_': float,
        'cost_per_click_cpc': float,
        'total_return_on_advertising_spend_roas': float
    }

    placementDfFinal = placementDfFinal.astype(schema)
    
    return placementDfFinal

def spBulkReport(filePath, date, marketplace):
    sheet_names = pd.ExcelFile(filePath).sheet_names
    for name in sheet_names:
        if 'products' in name.lower():
            spSheet = name
    df = pd.read_excel(filePath,spSheet)
    df = df.rename(columns=lambda x:x.replace(' ','_').replace('-','').replace('(','').replace(')','').replace('#','').lower())

    if df.empty:
        return None

    df.insert(0,'marketplace',marketplace)
    df.insert(0,'date',date)

    reqColumns = [
        'date',
        'marketplace',
        'product',
        'entity',
        'operation',
        'campaign_id',
        'ad_group_id',
        'portfolio_id',
        'ad_id',
        'keyword_id',
        'product_targeting_id',
        'campaign_name',
        'ad_group_name',
        'campaign_name_informational_only',
        'ad_group_name_informational_only',
        'portfolio_name_informational_only',
        'start_date',
        'end_date',
        'targeting_type',
        'state',
        'campaign_state_informational_only',
        'ad_group_state_informational_only',
        'daily_budget',
        'sku',
        'asin_informational_only',
        'eligibility_status_informational_only',
        'reason_for_ineligibility_informational_only',
        'ad_group_default_bid',
        'ad_group_default_bid_informational_only',
        'bid',
        'keyword_text',
        'native_language_keyword',
        'native_language_locale',
        'match_type',
        'bidding_strategy',
        'placement',
        'percentage',
        'product_targeting_expression',
        'resolved_product_targeting_expression_informational_only',
        'audience_id',
        'shopper_cohort_percentage',
        'shopper_cohort_type',
        'segment_name_informational_only',
        'sites',
        'impressions',
        'clicks',
        'clickthrough_rate',
        'spend',
        'sales',
        'orders',
        'units',
        'conversion_rate',
        'acos',
        'cpc',
        'roas'
    ]

    missingColumns = set(reqColumns) - set(df.columns)
    newColumns = set(df.columns) - set(reqColumns)

    if missingColumns:
        message = f'Missing columns: {", ".join(missingColumns)}'
        raise ValueError(message)
    if newColumns:
        message = f'New columns: {", ".join(newColumns)}'
        print(message)

    df = df[reqColumns]

    schema = {
        'date': 'datetime64[ns]',
        'marketplace': str,
        'product': str,
        'entity': str,
        'operation': str,
        'campaign_id': str,
        'ad_group_id': str,
        'portfolio_id': str,
        'ad_id': str,
        'keyword_id': str,
        'product_targeting_id': str,
        'campaign_name': str,
        'ad_group_name': str,
        'campaign_name_informational_only': str,
        'ad_group_name_informational_only': str,
        'portfolio_name_informational_only': str,
        'start_date': str,
        'end_date': str,
        'targeting_type': str,
        'state': str,
        'campaign_state_informational_only': str,
        'ad_group_state_informational_only': str,
        'daily_budget': float,
        'sku': str,
        'asin_informational_only': str,
        'eligibility_status_informational_only': str,
        'reason_for_ineligibility_informational_only': str,
        'ad_group_default_bid': float,
        'ad_group_default_bid_informational_only': float,
        'bid': float,
        'keyword_text': str,
        'native_language_keyword': str,
        'native_language_locale': str,
        'match_type': str,
        'bidding_strategy': str,
        'placement': str,
        'percentage': float,
        'product_targeting_expression': str,
        'resolved_product_targeting_expression_informational_only': str,
        'audience_id': str,
        'shopper_cohort_percentage': float,
        'shopper_cohort_type': str,
        'segment_name_informational_only': str,
        'sites': str,
        'impressions': float,
        'clicks': float,
        'clickthrough_rate': float,
        'spend': float,
        'sales': float,
        'orders': float,
        'units': float,
        'conversion_rate': float,
        'acos': float,
        'cpc': float,
        'roas': float
    }

    df = df.astype(schema)
    return df

def sbBulkReport(filePath, date, marketplace):
    sheet_names = pd.ExcelFile(filePath).sheet_names
    for name in sheet_names:
        if 'brands' in name.lower():
            spSheet = name
    df = pd.read_excel(filePath,spSheet)
    df = df.rename(columns=lambda x:x.replace(' ','_').replace('-','').replace('(','').replace(')','').replace('#','').lower())

    if df.empty:
        return None

    df.insert(0,'marketplace',marketplace)
    df.insert(0,'date',date)

    reqColumns = [
        'date',
        'marketplace',
        'product',
        'entity',
        'operation',
        'campaign_id',
        'draft_campaign_id',
        'portfolio_id',
        'ad_group_id',
        'keyword_id',
        'product_targeting_id',
        'campaign_name',
        'campaign_name_informational_only',
        'portfolio_name_informational_only',
        'start_date',
        'end_date',
        'state',
        'campaign_state_informational_only',
        'campaign_serving_status_informational_only',
        'budget_type',
        'budget',
        'bid_optimization',
        'bid_multiplier',
        'bid',
        'keyword_text',
        'match_type',
        'product_targeting_expression',
        'resolved_product_targeting_expression_informational_only',
        'ad_format',
        'ad_format_informational_only',
        'landing_page_url',
        'landing_page_asins',
        'landing_page_type_informational_only',
        'brand_entity_id',
        'brand_name',
        'brand_logo_asset_id',
        'brand_logo_url_informational_only',
        'custom_image_asset_id',
        'creative_headline',
        'creative_asins',
        'video_media_ids',
        'creative_type',
        'impressions',
        'clicks',
        'clickthrough_rate',
        'spend',
        'sales',
        'orders',
        'units',
        'conversion_rate',
        'acos',
        'cpc',
        'roas'
    ]

    missingColumns = set(reqColumns) - set(df.columns)
    newColumns = set(df.columns) - set(reqColumns)

    if missingColumns:
        raise ValueError(f"Missing columns: {', '.join(missingColumns)}")

    if newColumns:
        print(f"New columns: {', '.join(newColumns)}")

    df = df[reqColumns]

    schema = {
        'date': 'datetime64[ns]',
        'marketplace': str,
        'product': str,
        'entity': str,
        'operation': str,
        'campaign_id': str,
        'draft_campaign_id': str,
        'portfolio_id': str,
        'ad_group_id': str,
        'keyword_id': str,
        'product_targeting_id': str,
        'campaign_name': str,
        'campaign_name_informational_only': str,
        'portfolio_name_informational_only': str,
        'start_date': str,
        'end_date': str,
        'state': str,
        'campaign_state_informational_only': str,
        'campaign_serving_status_informational_only': str,
        'budget_type': str,
        'budget': float,
        'bid_optimization': str,
        'bid_multiplier': str,
        'bid': float,
        'keyword_text': str,
        'match_type': str,
        'product_targeting_expression': str,
        'resolved_product_targeting_expression_informational_only': str,
        'ad_format': str,
        'ad_format_informational_only': str,
        'landing_page_url': str,
        'landing_page_asins': str,
        'landing_page_type_informational_only': str,
        'brand_entity_id': str,
        'brand_name': str,
        'brand_logo_asset_id': str,
        'brand_logo_url_informational_only': str,
        'custom_image_asset_id': str,
        'creative_headline': str,
        'creative_asins': str,
        'video_media_ids': str,
        'creative_type': str,
        'impressions': float,
        'clicks': float,
        'clickthrough_rate': float,
        'spend': float,
        'sales': float,
        'orders': float,
        'units': float,
        'conversion_rate': float,
        'acos': float,
        'cpc': float,
        'roas': float
    }

    df = df.astype(schema)
    return df

def sdBulkReport(filePath, date, marketplace):
    sheet_names = pd.ExcelFile(filePath).sheet_names
    for name in sheet_names:
        if 'display' in name.lower():
            spSheet = name
    df = pd.read_excel(filePath,spSheet)
    df = df.rename(columns=lambda x:x.replace(' ','_').replace('-','').replace('(','').replace(')','').replace('#','').replace('&','').lower())

    if df.empty:
        return None

    df.insert(0,'marketplace',marketplace)
    df.insert(0,'date',date)

    reqColumns = [
        'date',
        'marketplace',
        'product',
        'entity',
        'operation',
        'campaign_id',
        'portfolio_id',
        'ad_group_id',
        'ad_id',
        'targeting_id',
        'campaign_name',
        'ad_group_name',
        'campaign_name_informational_only',
        'ad_group_name_informational_only',
        'portfolio_name_informational_only',
        'start_date',
        'end_date',
        'state',
        'campaign_state_informational_only',
        'ad_group_state_informational_only',
        'tactic',
        'budget_type',
        'budget',
        'sku',
        'asin_informational_only',
        'ad_group_default_bid',
        'ad_group_default_bid_informational_only',
        'bid',
        'bid_optimization',
        'cost_type',
        'targeting_expression',
        'resolved_targeting_expression_informational_only',
        'impressions',
        'clicks',
        'clickthrough_rate',
        'spend',
        'sales',
        'orders',
        'units',
        'conversion_rate',
        'acos',
        'cpc',
        'roas',
        'viewable_impressions',
        'sales_views__clicks',
        'orders_views__clicks',
        'units_views__clicks',
        'acos_views__clicks',
        'roas_views__clicks'
    ]

    missingColumns = set(reqColumns) - set(df.columns)
    newColumns = set(df.columns) - set(reqColumns)

    if missingColumns:
        raise ValueError(f"Missing columns: {', '.join(missingColumns)}")

    if newColumns:
        print(f"New columns: {', '.join(newColumns)}")

    df = df[reqColumns]

    schema = {
        'date': 'datetime64[ns]',
        'marketplace': str,
        'product': str,
        'entity': str,
        'operation': str,
        'campaign_id': str,
        'portfolio_id': str,
        'ad_group_id': str,
        'ad_id': str,
        'targeting_id': str,
        'campaign_name': str,
        'ad_group_name': str,
        'campaign_name_informational_only': str,
        'ad_group_name_informational_only': str,
        'portfolio_name_informational_only': str,
        'start_date': str,
        'end_date': str,
        'state': str,
        'campaign_state_informational_only': str,
        'ad_group_state_informational_only': str,
        'tactic': str,
        'budget_type': str,
        'budget': float,
        'sku': str,
        'asin_informational_only': str,
        'ad_group_default_bid': float,
        'ad_group_default_bid_informational_only': float,
        'bid': float,
        'bid_optimization': str,
        'cost_type': str,
        'targeting_expression': str,
        'resolved_targeting_expression_informational_only': str,
        'impressions': float,
        'clicks': float,
        'clickthrough_rate': float,
        'spend': float,
        'sales': float,
        'orders': float,
        'units': float,
        'conversion_rate': float,
        'acos': float,
        'cpc': float,
        'roas': float,
        'viewable_impressions': float,
        'sales_views__clicks': float,
        'orders_views__clicks': float,
        'units_views__clicks': float,
        'acos_views__clicks': float,
        'roas_views__clicks': float
    }

    df = df.astype(schema)
    return df

def sbMultiBulkReport(filePath, date, marketplace):
    sheet_names = pd.ExcelFile(filePath).sheet_names
    for name in sheet_names:
        if 'multi' in name.lower():
            spSheet = name
    df = pd.read_excel(filePath, spSheet)
    df = df.rename(columns=lambda x:x.replace(' ','_').replace('-','').replace('(','').replace(')','').replace('#','').lower())

    if df.empty:
        return None

    df.insert(0,'marketplace', marketplace)
    df.insert(0,'date', date)

    reqColumns = [
        'date',
        'marketplace',
        'product',
        'entity',
        'operation',
        'campaign_id',
        'portfolio_id',
        'ad_group_id',
        'ad_id',
        'keyword_id',
        'product_targeting_id',
        'campaign_name',
        'ad_group_name',
        'ad_name',
        'campaign_name_informational_only',
        'ad_group_name_informational_only',
        'portfolio_name_informational_only',
        'start_date',
        'end_date',
        'state',
        'brand_entity_id',
        'campaign_state_informational_only',
        'campaign_serving_status_informational_only',
        'campaign_serving_status_details_informational_only',
        'rule_based_budget_is_processing_informational_only',
        'rule_based_budget_name_informational_only',
        'rule_based_budget_value_informational_only',
        'rule_based_budget_id_informational_only',
        'ad_group_serving_status_informational_only',
        'ad_group_serving_status_details_informational_only',
        'budget_type',
        'budget',
        'bid_optimization',
        'product_location',
        'bid',
        'placement',
        'percentage',
        'audience_id',
        'shopper_cohort_percentage',
        'shopper_cohort_type',
        'segment_name_informational_only',
        'keyword_text',
        'match_type',
        'native_language_keyword',
        'native_language_locale',
        'product_targeting_expression',
        'resolved_product_targeting_expression_informational_only',
        'ad_serving_status_informational_only',
        'ad_serving_status_details_informational_only',
        'landing_page_url',
        'landing_page_asins',
        'landing_page_type',
        'brand_name',
        'consent_to_translate',
        'brand_logo_asset_id',
        'brand_logo_url_informational_only',
        'brand_logo_crop',
        'custom_images',
        'creative_headline',
        'creative_asins',
        'video_asset_ids',
        'original_video_asset_ids_informational_only',
        'subpages',
        'sites',
        'impressions',
        'clicks',
        'clickthrough_rate',
        'spend',
        'sales',
        'orders',
        'units',
        'conversion_rate',
        'acos',
        'cpc',
        'roas',
    ]

    missingColumns = set(reqColumns) - set(df.columns)
    newColumns = set(df.columns) - set(reqColumns)

    if missingColumns:
        raise ValueError(f"Missing columns: {', '.join(missingColumns)}")
    if newColumns:
        print(f"New columns: {', '.join(newColumns)}")

    df = df[reqColumns]

    schema = {
        'date': 'datetime64[ns]',
        'marketplace': str,
        'product': str,
        'entity': str,
        'operation': str,
        'campaign_id': str,
        'portfolio_id': str,
        'ad_group_id': str,
        'ad_id': str,
        'keyword_id': str,
        'product_targeting_id': str,
        'campaign_name': str,
        'ad_group_name': str,
        'ad_name': str,
        'campaign_name_informational_only': str,
        'ad_group_name_informational_only': str,
        'portfolio_name_informational_only': str,
        'start_date': str,
        'end_date': str,
        'state': str,
        'brand_entity_id': str,
        'campaign_state_informational_only': str,
        'campaign_serving_status_informational_only': str,
        'campaign_serving_status_details_informational_only': str,
        'rule_based_budget_is_processing_informational_only': str,
        'rule_based_budget_name_informational_only': str,
        'rule_based_budget_value_informational_only': str,
        'rule_based_budget_id_informational_only': str,
        'ad_group_serving_status_informational_only': str,
        'ad_group_serving_status_details_informational_only': str,
        'budget_type': str,
        'budget': float,
        'bid_optimization': str,
        'product_location': str,
        'bid': float,
        'placement': str,
        'percentage': float,
        'audience_id': str,
        'shopper_cohort_percentage': float,
        'shopper_cohort_type': str,
        'segment_name_informational_only': str,
        'keyword_text': str,
        'match_type': str,
        'native_language_keyword': str,
        'native_language_locale': str,
        'product_targeting_expression': str,
        'resolved_product_targeting_expression_informational_only': str,
        'ad_serving_status_informational_only': str,
        'ad_serving_status_details_informational_only': str,
        'landing_page_url': str,
        'landing_page_asins': str,
        'landing_page_type': str,
        'brand_name': str,
        'consent_to_translate': str,
        'brand_logo_asset_id': str,
        'brand_logo_url_informational_only': str,
        'brand_logo_crop': str,
        'custom_images': str,
        'creative_headline': str,
        'creative_asins': str,
        'video_asset_ids': str,
        'original_video_asset_ids_informational_only': str,
        'subpages': str,
        'sites': str,
        'impressions': float,
        'clicks': float,
        'clickthrough_rate': float,
        'spend': float,
        'sales': float,
        'orders': float,
        'units': float,
        'conversion_rate': float,
        'acos': float,
        'cpc': float,
        'roas': float,
    }

    df = df.astype(schema)
    return df

def spPlacementMulitMarketReport(file_path):
    df = pd.read_excel(file_path)
    df = df.rename(columns=lambda x:x.replace('(','')
                                    .replace(')','')
                                    .replace('#','')
                                    .replace('-','')
                                    .replace(' ','_')
                                    .replace('7','_7')
                                    .replace('__','_')
                                    .lower()
                  )
    req_columns = [
        'date',
        'portfolio_name',
        'currency_converted',
        'currency_not_converted',
        'campaign_name',
        'retailer',
        'country',
        'bidding_strategy',
        'placement',
        'impressions',
        'clicks',
        'cost_per_click_cpc_converted',
        'cost_per_click_cpc_not_converted',
        'spend_converted',
        'spend_not_converted',
        '_7_day_total_sales_converted',
        '_7_day_total_sales_not_converted',
        'total_advertising_cost_of_sales_acos_',
        'total_return_on_advertising_spend_roas',
        '_7_day_total_orders_',
        '_7_day_total_units_'
    ]

    missing_columns = set(req_columns) - set(df.columns)
    if missing_columns:
        raise ValueError(f"Missing required columns: {', '.join(missing_columns)}")
    
    new_columns = set(df.columns) - set(req_columns)
    if new_columns:
        print(f"New columns detected: {', '.join(new_columns)}")

    df = df[req_columns]

    schema = {
        'date': 'datetime64[ns]',
        'portfolio_name': str,
        'currency_converted': str,
        'currency_not_converted': str,
        'campaign_name': str,
        'retailer': str,
        'country': str,
        'bidding_strategy': str,
        'placement': str,
        'impressions': float,
        'clicks': float,
        'cost_per_click_cpc_converted': float,
        'cost_per_click_cpc_not_converted': float,
        'spend_converted': float,
        'spend_not_converted': float,
        '_7_day_total_sales_converted': float,
        '_7_day_total_sales_not_converted': float,
        'total_advertising_cost_of_sales_acos_': float,
        'total_return_on_advertising_spend_roas': float,
        '_7_day_total_orders_': float,
        '_7_day_total_units_': float,
    }
    df = df.astype(schema)

    return df

def spAdvertisedMultiMarketReport(file_path):
    df = pd.read_excel(file_path)
    df = df.rename(columns=lambda x: x.replace('7','_7')
                                      .replace('(','')
                                      .replace(')','')
                                      .replace('-','')
                                      .replace('#','')
                                      .replace(' ','_')
                                      .replace('__','_')
                                      .lower()
                   )
    
    req_columns = [
        'date',
        'portfolio_name',
        'currency_converted',
        'currency_not_converted',
        'campaign_name',
        'ad_group_name',
        'retailer',
        'country',
        'advertised_sku',
        'advertised_asin',
        'impressions',
        'clicks',
        'clickthru_rate_ctr',
        'cost_per_click_cpc_converted',
        'cost_per_click_cpc_not_converted',
        'spend_converted',
        'spend_not_converted',
        '_7_day_total_sales_converted',
        '_7_day_total_sales_not_converted',
        'total_advertising_cost_of_sales_acos_',
        'total_return_on_advertising_spend_roas',
        '_7_day_total_orders_',
        '_7_day_total_units_',
        '_7_day_conversion_rate',
        '_7_day_advertised_sku_units_',
        '_7_day_other_sku_units_',
        '_7_day_advertised_sku_sales_converted',
        '_7_day_advertised_sku_sales_not_converted',
        '_7_day_other_sku_sales_converted_',
        '_7_day_other_sku_sales_not_converted'
    ]

    missing_columns = set(req_columns) - set(df.columns)
    if missing_columns:
        raise ValueError(f"Missing required columns: {', '.join(missing_columns)}")
    new_columns = set(df.columns) - set(req_columns)
    if new_columns:
        print(f"New columns found: {', '.join(new_columns)}")

    df = df[req_columns]

    schema = {
        'date': 'datetime64[ns]',
        'portfolio_name': str,
        'currency_converted': str,
        'currency_not_converted': str,
        'campaign_name': str,
        'ad_group_name': str,
        'retailer': str,
        'country': str,
        'advertised_sku': str,
        'advertised_asin': str,
        'impressions': float,
        'clicks': float,
        'clickthru_rate_ctr': float,
        'cost_per_click_cpc_converted': float,
        'cost_per_click_cpc_not_converted': float,
        'spend_converted': float,
        'spend_not_converted': float,
        '_7_day_total_sales_converted': float,
        '_7_day_total_sales_not_converted': float,
        'total_advertising_cost_of_sales_acos_': float,
        'total_return_on_advertising_spend_roas': float,
        '_7_day_total_orders_': float,
        '_7_day_total_units_': float,
        '_7_day_conversion_rate': float,
        '_7_day_advertised_sku_units_': float,
        '_7_day_other_sku_units_': float,
        '_7_day_advertised_sku_sales_converted': float,
        '_7_day_advertised_sku_sales_not_converted': float,
        '_7_day_other_sku_sales_converted_': float,
        '_7_day_other_sku_sales_not_converted': float
    }
    df = df.astype(schema)

    return df

def spSearchTermMultiMarketReport(file_path):
    df = pd.read_excel(file_path)
    df = df.rename(columns=lambda x: x.replace('7','_7')
                                      .replace('(','')
                                      .replace(')','')
                                      .replace('-','')
                                      .replace('#','')
                                      .replace(' ','_')
                                      .replace('__','_')
                                      .lower()
                   )
    req_columns = [
        'date',
        'portfolio_name',
        'currency',
        'campaign_name',
        'ad_group_name',
        'retailer',
        'country',
        'targeting',
        'match_type',
        'customer_search_term',
        'impressions',
        'clicks',
        'clickthru_rate_ctr',
        'cost_per_click_cpc',
        'spend',
        '_7_day_total_sales_',
        'total_advertising_cost_of_sales_acos_',
        'total_return_on_advertising_spend_roas',
        '_7_day_total_orders_',
        '_7_day_total_units_',
        '_7_day_conversion_rate',
        '_7_day_advertised_sku_units_',
        '_7_day_other_sku_units_',
        '_7_day_advertised_sku_sales_',
        '_7_day_other_sku_sales_'
    ]

    missing_columns = set(req_columns) - set(df.columns)
    if missing_columns:
        raise ValueError(f"Missing required columns: {', '.join(missing_columns)}")
    new_columns = set(df.columns) - set(req_columns)
    if new_columns:
        print(f"New columns found: {', '.join(new_columns)}")

    df = df[req_columns]

    schema = {
        'date': 'datetime64[ns]',
        'portfolio_name': str,
        'currency': str,
        'campaign_name': str,
        'ad_group_name': str,
        'retailer': str,
        'country': str,
        'targeting': str,
        'match_type': str,
        'customer_search_term': str,
        'impressions': float,
        'clicks': float,
        'clickthru_rate_ctr': float,
        'cost_per_click_cpc': float,
        'spend': float,
        '_7_day_total_sales_': float,
        'total_advertising_cost_of_sales_acos_': float,
        'total_return_on_advertising_spend_roas': float,
        '_7_day_total_orders_': float,
        '_7_day_total_units_': float,
        '_7_day_conversion_rate': float,
        '_7_day_advertised_sku_units_': float,
        '_7_day_other_sku_units_': float,
        '_7_day_advertised_sku_sales_': float,
        '_7_day_other_sku_sales_': float
    }

    df = df.astype(schema)
    
    return df

def spTargetingMultiMarketReport(file_path):
    df = pd.read_excel(file_path)
    df = df.rename(columns=lambda x: x.replace('7','_7')
                                      .replace('(','')
                                      .replace(')','')
                                      .replace('-','')
                                      .replace('#','')
                                      .replace(' ','_')
                                      .replace('__','_')
                                      .lower()
                   )
    req_columns = [
        'date',
        'portfolio_name',
        'currency',
        'campaign_name',
        'country',
        'ad_group_name',
        'retailer',
        'targeting',
        'match_type',
        'impressions',
        'topofsearch_impression_share',
        'clicks',
        'clickthru_rate_ctr',
        'cost_per_click_cpc',
        'spend',
        'total_advertising_cost_of_sales_acos_',
        'total_return_on_advertising_spend_roas',
        '_7_day_total_sales_',
        '_7_day_total_orders_',
        '_7_day_total_units_',
        '_7_day_conversion_rate',
        '_7_day_advertised_sku_units_',
        '_7_day_other_sku_units_',
        '_7_day_advertised_sku_sales_',
        '_7_day_other_sku_sales_'
    ]

    missing_columns = set(req_columns) - set(df.columns)
    if missing_columns:
        raise ValueError(f"Missing required columns: {', '.join(missing_columns)}")
    new_columns = set(df.columns) - set(req_columns)
    if new_columns:
        print(f"New columns found: {', '.join(new_columns)}")

    df = df[req_columns]

    schema = {
        'date': 'datetime64[ns]',
        'portfolio_name': str,
        'currency': str,
        'campaign_name': str,
        'country': str,
        'ad_group_name': str,
        'retailer': str,
        'targeting': str,
        'match_type': str,
        'impressions': float,
        'topofsearch_impression_share': float,
        'clicks': float,
        'clickthru_rate_ctr': float,
        'cost_per_click_cpc': float,
        'spend': float,
        'total_advertising_cost_of_sales_acos_': float,
        'total_return_on_advertising_spend_roas': float,
        '_7_day_total_sales_': float,
        '_7_day_total_orders_': float,
        '_7_day_total_units_': float,
        '_7_day_conversion_rate': float,
        '_7_day_advertised_sku_units_': float,
        '_7_day_other_sku_units_': float,
        '_7_day_advertised_sku_sales_': float,
        '_7_day_other_sku_sales_': float
    }

    df = df.astype(schema)
    
    return df

def _calculate_fulfillment_fee_us(tier, weight_lb, weight_oz, price_tier, is_peak):
    """
    Calculate the fulfillment fee based on size tier, weight, price tier, and peak/off-peak period.
    Internal helper function.
    """
    
    if tier == 'Small standard-size':
        # Fee tables for Small standard-size
        if is_peak:
            fees = {
                '<$10': {2: 2.48, 4: 2.57, 6: 2.67, 8: 2.76, 10: 2.87, 12: 2.97, 14: 3.05, 16: 3.10},
                '$10-$50': {2: 3.25, 4: 3.34, 6: 3.44, 8: 3.53, 10: 3.64, 12: 3.74, 14: 3.82, 16: 3.87},
                '>$50': {2: 3.25, 4: 3.34, 6: 3.44, 8: 3.53, 10: 3.64, 12: 3.74, 14: 3.82, 16: 3.87}
            }
        else:
            fees = {
                '<$10': {2: 2.43, 4: 2.49, 6: 2.56, 8: 2.66, 10: 2.77, 12: 2.82, 14: 2.92, 16: 2.95},
                '$10-$50': {2: 3.32, 4: 3.42, 6: 3.45, 8: 3.54, 10: 3.68, 12: 3.78, 14: 3.91, 16: 3.96},
                '>$50': {2: 3.58, 4: 3.68, 6: 3.71, 8: 3.80, 10: 3.94, 12: 4.04, 14: 4.17, 16: 4.22}
            }
        
        # Determine weight bracket
        if weight_oz <= 2:
            bracket = 2
        elif weight_oz <= 4:
            bracket = 4
        elif weight_oz <= 6:
            bracket = 6
        elif weight_oz <= 8:
            bracket = 8
        elif weight_oz <= 10:
            bracket = 10
        elif weight_oz <= 12:
            bracket = 12
        elif weight_oz <= 14:
            bracket = 14
        else:
            bracket = 16
        
        return fees[price_tier][bracket]
    
    elif tier == 'Large standard-size':
        # For weights 3+ lb to 20 lb, use incremental formula
        if weight_lb > 3:
            weight_above_3lb = weight_lb - 3
            intervals_4oz = np.ceil(weight_above_3lb * 16 / 4)
            
            if is_peak:
                base_fees = {'<$10': 6.69, '$10-$50': 7.46, '>$50': 7.46}
            else:
                base_fees = {'<$10': 6.15, '$10-$50': 6.97, '>$50': 7.23}
            
            return base_fees[price_tier] + (intervals_4oz * 0.08)
        
        # For weights under 3 lb, use lookup table
        if is_peak:
            fees = {
                '<$10': {4: 3.15, 8: 3.39, 12: 3.66, 16: 4.07, 1.25: 4.52, 1.5: 4.91, 1.75: 5.07, 
                        2: 5.33, 2.25: 5.47, 2.5: 5.67, 2.75: 5.84, 3: 6.26},
                '$10-$50': {4: 3.92, 8: 4.16, 12: 4.43, 16: 4.84, 1.25: 5.29, 1.5: 5.68, 1.75: 5.84, 
                           2: 6.10, 2.25: 6.24, 2.5: 6.44, 2.75: 6.61, 3: 7.03},
                '>$50': {4: 3.92, 8: 4.16, 12: 4.43, 16: 4.84, 1.25: 5.29, 1.5: 5.68, 1.75: 5.84, 
                        2: 6.10, 2.25: 6.24, 2.5: 6.44, 2.75: 6.61, 3: 7.03}
            }
        else:
            fees = {
                '<$10': {4: 2.91, 8: 3.13, 12: 3.38, 16: 3.78, 1.25: 4.22, 1.5: 4.60, 1.75: 4.75, 
                        2: 5.00, 2.25: 5.10, 2.5: 5.28, 2.75: 5.44, 3: 5.85},
                '$10-$50': {4: 3.73, 8: 3.95, 12: 4.20, 16: 4.60, 1.25: 5.04, 1.5: 5.42, 1.75: 5.57, 
                           2: 5.82, 2.25: 5.92, 2.5: 6.10, 2.75: 6.26, 3: 6.67},
                '>$50': {4: 3.99, 8: 4.21, 12: 4.46, 16: 4.86, 1.25: 5.30, 1.5: 5.68, 1.75: 5.83, 
                        2: 6.08, 2.25: 6.18, 2.5: 6.36, 2.75: 6.52, 3: 6.93}
            }
        
        # Determine weight bracket
        if weight_oz <= 4:
            bracket = 4
        elif weight_oz <= 8:
            bracket = 8
        elif weight_oz <= 12:
            bracket = 12
        elif weight_oz <= 16:
            bracket = 16
        elif weight_lb <= 1.25:
            bracket = 1.25
        elif weight_lb <= 1.5:
            bracket = 1.5
        elif weight_lb <= 1.75:
            bracket = 1.75
        elif weight_lb <= 2:
            bracket = 2
        elif weight_lb <= 2.25:
            bracket = 2.25
        elif weight_lb <= 2.5:
            bracket = 2.5
        elif weight_lb <= 2.75:
            bracket = 2.75
        else:
            bracket = 3
        
        return fees[price_tier][bracket]
    
    elif tier == 'Small Bulky':
        if is_peak:
            base_fees = {'<$10': 9.88, '$10-$50': 10.65, '>$50': 10.65}
        else:
            base_fees = {'<$10': 6.78, '$10-$50': 7.55, '>$50': 7.55}
        
        intervals = np.ceil(max(0, weight_lb - 1))
        return base_fees[price_tier] + (intervals * 0.38)
    
    elif tier == 'Large Bulky':
        if is_peak:
            base_fees = {'<$10': 9.88, '$10-$50': 10.65, '>$50': 10.65}
        else:
            base_fees = {'<$10': 8.58, '$10-$50': 9.35, '>$50': 9.35}
        
        intervals = np.ceil(max(0, weight_lb - 1))
        return base_fees[price_tier] + (intervals * 0.38)
    
    elif tier == 'Extra-Large 0 to 50 lb':
        if is_peak:
            base_fees = {'<$10': 28.29, '$10-$50': 29.06, '>$50': 29.06}
        else:
            base_fees = {'<$10': 25.56, '$10-$50': 26.33, '>$50': 26.33}
        
        intervals = np.ceil(max(0, weight_lb - 1))
        return base_fees[price_tier] + (intervals * 0.38)
    
    elif tier == 'Extra-Large 50+ to 70 lb':
        if is_peak:
            base_fees = {'<$10': 42.16, '$10-$50': 42.93, '>$50': 42.93}
        else:
            base_fees = {'<$10': 36.55, '$10-$50': 37.32, '>$50': 37.32}
        
        intervals = np.ceil(max(0, weight_lb - 51))
        return base_fees[price_tier] + (intervals * 0.75)
    
    elif tier == 'Extra-Large 70+ to 150 lb':
        if is_peak:
            base_fees = {'<$10': 58.46, '$10-$50': 59.23, '>$50': 59.23}
        else:
            base_fees = {'<$10': 50.55, '$10-$50': 51.32, '>$50': 51.32}
        
        intervals = np.ceil(max(0, weight_lb - 71))
        return base_fees[price_tier] + (intervals * 0.75)
    
    elif tier == 'Extra-large 150+ lb':
        if is_peak:
            base_fees = {'<$10': 202.69, '$10-$50': 203.46, '>$50': 203.46}
        else:
            base_fees = {'<$10': 194.18, '$10-$50': 194.95, '>$50': 194.95}
        
        intervals = np.ceil(max(0, weight_lb - 151))
        return base_fees[price_tier] + (intervals * 0.19)
    
    else:
        return 0.0

def compute_fba_fees_us(df):
    """
    Compute Amazon FBA fees for US marketplace based on 2026 product size tier definitions.
    
    Parameters:
    -----------
    df : pandas.DataFrame
        DataFrame with columns:
        - sku
        - asin
        - longest_side
        - median_side
        - shortest_side
        - unit_of_dimension (inches or centimeters)
        - item_package_weight
        - unit_of_weight (pounds or grams)
        - selling_price (optional, for price tier determination)
    
    Returns:
    --------
    pandas.DataFrame
        Original DataFrame with added columns:
        - marketplace
        - currency
        - unit_weight_lb (actual package weight)
        - dimensional_weight_lb (adjusted dimensional weight with 2" min where applicable)
        - shipping_weight_for_tier_lb (used for determining product size tier)
        - shipping_weight_for_fees_lb (used for calculating shipping fees)
        - product_size_tier (tier classification)
        - storage_size_tier (Standard Size or Oversize)
        - price_tier (based on selling_price: <$10, $10-$50, >$50)
        - off_peak_storage_fee (storage fees)
        - peak_storage_fee (storage fees)
        - off_peak_fulfillment_fee (Jan 15, 2026 - Oct 14, 2026)
        - peak_fulfillment_fee (Oct 15, 2025 - Jan 14, 2026)
        - error_message (populated if calculation fails for a SKU)
    """
    # Create a copy to avoid modifying original
    result_df = df.copy()
    
    # Add marketplace and currency columns
    result_df['marketplace'] = 'United States'
    result_df['currency'] = 'USD'
    
    # Initialize all new columns with NaN
    result_df['unit_weight_lb'] = np.nan
    result_df['dimensional_weight_lb'] = np.nan
    result_df['shipping_weight_for_tier_lb'] = np.nan
    result_df['shipping_weight_for_fees_lb'] = np.nan
    result_df['product_size_tier'] = ''
    result_df['storage_size_tier'] = ''
    result_df['price_tier'] = ''
    result_df['off_peak_storage_fee'] = np.nan
    result_df['peak_storage_fee'] = np.nan
    result_df['off_peak_fulfillment_fee'] = np.nan
    result_df['peak_fulfillment_fee'] = np.nan
    result_df['error_message'] = ''
    
    # Process each row individually with error handling
    for idx in range(len(result_df)):
        try:
            # Extract dimensions
            longest = pd.to_numeric(result_df.loc[idx, 'longest_side'], errors='coerce')
            median = pd.to_numeric(result_df.loc[idx, 'median_side'], errors='coerce')
            shortest = pd.to_numeric(result_df.loc[idx, 'shortest_side'], errors='coerce')
            
            # Check if dimensions are valid
            if pd.isna(longest) or pd.isna(median) or pd.isna(shortest):
                result_df.loc[idx, 'error_message'] = 'Invalid or missing dimensions'
                continue
            
            # Convert centimeters to inches if needed
            unit_dim = str(result_df.loc[idx, 'unit_of_dimension']).lower()
            if 'cent' in unit_dim or 'cm' in unit_dim:
                longest = longest / 2.54
                median = median / 2.54
                shortest = shortest / 2.54
            
            # Extract weight
            unit_weight = pd.to_numeric(result_df.loc[idx, 'item_package_weight'], errors='coerce')
            
            # Check if weight is valid
            if pd.isna(unit_weight):
                result_df.loc[idx, 'error_message'] = 'Invalid or missing weight'
                continue
            
            # Convert grams to pounds if needed
            unit_wt = str(result_df.loc[idx, 'unit_of_weight']).lower()
            if 'gram' in unit_wt or unit_wt == 'g':
                unit_weight = unit_weight / 453.592
            
            # Calculate dimensional weight (basic)
            dimensional_weight_basic = (longest * median * shortest) / 139
            
            # Shipping weight for determining size tiers
            shipping_weight_for_tier = max(unit_weight, dimensional_weight_basic)
            
            # Calculate length plus girth
            length_plus_girth = longest + 2 * (median + shortest)
            
            # Determine Product Size Tier
            product_size_tier = ''
            
            if (longest <= 15 and median <= 12 and shortest <= 0.75 and 
                shipping_weight_for_tier <= 16):
                product_size_tier = 'Small standard-size'
                
            elif (longest <= 18 and median <= 14 and shortest <= 8 and 
                  shipping_weight_for_tier <= 20):
                product_size_tier = 'Large standard-size'
                
            elif (longest <= 37 and median <= 28 and shortest <= 20 and 
                  length_plus_girth <= 130 and shipping_weight_for_tier <= 50):
                product_size_tier = 'Small Bulky'
                
            elif (longest <= 59 and median <= 33 and shortest <= 33 and 
                  length_plus_girth <= 130 and shipping_weight_for_tier <= 50):
                product_size_tier = 'Large Bulky'
                
            elif ((longest > 59 or median > 33 or shortest > 33 or length_plus_girth > 130) and 
                  shipping_weight_for_tier <= 50):
                product_size_tier = 'Extra-Large 0 to 50 lb'
                
            elif shipping_weight_for_tier > 50 and shipping_weight_for_tier <= 70:
                product_size_tier = 'Extra-Large 50+ to 70 lb'
                
            elif (shipping_weight_for_tier > 70 and shipping_weight_for_tier <= 150 and
                  (longest <= 96 or length_plus_girth <= 130)):
                product_size_tier = 'Extra-Large 70+ to 150 lb'
                
            elif shipping_weight_for_tier > 150:
                product_size_tier = 'Extra-large 150+ lb'
                
            else:
                product_size_tier = 'Overmax'
            
            # Calculate dimensional weight with adjustments for fee calculations
            uses_adjusted_dim_weight = product_size_tier in [
                'Large standard-size', 'Small Bulky', 'Large Bulky', 
                'Extra-Large 0 to 50 lb', 'Extra-Large 50+ to 70 lb',
                'Extra-Large 70+ to 150 lb', 'Extra-large 150+ lb', 'Overmax'
            ]
            
            if uses_adjusted_dim_weight:
                median_adj = max(median, 2)
                shortest_adj = max(shortest, 2)
                dimensional_weight_adjusted = (longest * median_adj * shortest_adj) / 139
            else:
                dimensional_weight_adjusted = dimensional_weight_basic
            
            # Shipping weight for fees
            uses_unit_weight_only = product_size_tier in ['Small standard-size', 'Extra-large 150+ lb']
            if uses_unit_weight_only:
                shipping_weight_for_fees = unit_weight
            else:
                shipping_weight_for_fees = max(unit_weight, dimensional_weight_adjusted)
            
            # Volume in cubic feet for storage fee calculation
            volume_cubic_feet = (longest * median * shortest) / 1728
            
            # Determine Storage Size Tier
            is_standard_storage = product_size_tier in ['Small standard-size', 'Large standard-size']
            storage_size_tier = "Standard Size" if is_standard_storage else "Oversize"
            
            # Compute storage fees
            off_peak_rate = 0.78 if is_standard_storage else 0.56
            peak_rate = 2.4 if is_standard_storage else 1.4
            
            off_peak_storage_fee = volume_cubic_feet * off_peak_rate
            peak_storage_fee = volume_cubic_feet * peak_rate
            
            # Determine price tier
            if 'selling_price' in result_df.columns:
                selling_price = pd.to_numeric(result_df.loc[idx, 'selling_price'], errors='coerce')
                if pd.isna(selling_price):
                    price_tier = '$10-$50'  # Default
                elif selling_price < 10:
                    price_tier = '<$10'
                elif selling_price > 50:
                    price_tier = '>$50'
                else:
                    price_tier = '$10-$50'
            else:
                price_tier = '$10-$50'  # Default if no selling_price column
            
            # Calculate fulfillment fees
            weight_lb = shipping_weight_for_fees
            weight_oz = weight_lb * 16
            
            # Off-peak fulfillment fee
            off_peak_fulfillment_fee = _calculate_fulfillment_fee_us(
                product_size_tier, weight_lb, weight_oz, price_tier, is_peak=False
            )
            
            # Peak fulfillment fee
            peak_fulfillment_fee = _calculate_fulfillment_fee_us(
                product_size_tier, weight_lb, weight_oz, price_tier, is_peak=True
            )
            
            # Store all calculated values
            result_df.loc[idx, 'unit_weight_lb'] = round(unit_weight, 2)
            result_df.loc[idx, 'dimensional_weight_lb'] = round(dimensional_weight_adjusted, 2)
            result_df.loc[idx, 'shipping_weight_for_tier_lb'] = round(shipping_weight_for_tier, 2)
            result_df.loc[idx, 'shipping_weight_for_fees_lb'] = round(shipping_weight_for_fees, 2)
            result_df.loc[idx, 'product_size_tier'] = product_size_tier
            result_df.loc[idx, 'storage_size_tier'] = storage_size_tier
            result_df.loc[idx, 'price_tier'] = price_tier
            result_df.loc[idx, 'off_peak_storage_fee'] = round(off_peak_storage_fee, 7)
            result_df.loc[idx, 'peak_storage_fee'] = round(peak_storage_fee, 7)
            result_df.loc[idx, 'off_peak_fulfillment_fee'] = round(off_peak_fulfillment_fee, 2)
            result_df.loc[idx, 'peak_fulfillment_fee'] = round(peak_fulfillment_fee, 2)
            
        except Exception as e:
            # If any error occurs, record it and skip this row
            result_df.loc[idx, 'error_message'] = str(e)
            continue
    
    return result_df

def _calculate_fulfillment_fee_ca(tier, weight_g, is_peak):
    """
    Calculate the fulfillment fee for Canada based on size tier, weight, and peak/off-peak period.
    Internal helper function.

    Parameters:
    -----------
    tier : str
        Product size tier
    weight_g : float
        Shipping weight in grams
    is_peak : bool
        True for peak period (Oct 15 - Jan 14), False for off-peak (Jan 15 - Oct 14)

    Returns:
    --------
    float
        Fulfillment fee in CAD
    """

    if tier == 'Envelope':
        # Envelope fulfillment fees
        if is_peak:
            fees = {
                100: 4.73,
                200: 4.99,
                300: 5.31,
                400: 5.60,
                500: 5.95
            }
        else:
            fees = {
                100: 4.46,
                200: 4.71,
                300: 5.01,
                400: 5.28,
                500: 5.62
            }

        # Determine weight bracket
        if weight_g <= 100:
            bracket = 100
        elif weight_g <= 200:
            bracket = 200
        elif weight_g <= 300:
            bracket = 300
        elif weight_g <= 400:
            bracket = 400
        else:
            bracket = 500

        return fees[bracket]

    elif tier == 'Standard':
        # Standard fulfillment fees
        if is_peak:
            fees = {
                100: 6.28,
                200: 6.49,
                300: 6.74,
                400: 7.13,
                500: 7.65,
                600: 7.84,
                700: 8.17,
                800: 8.43,
                900: 8.74,
                1000: 8.99,
                1100: 9.10,
                1200: 9.37,
                1300: 9.58,
                1400: 9.85,
                1500: 10.17
            }
        else:
            fees = {
                100: 5.92,
                200: 6.12,
                300: 6.36,
                400: 6.73,
                500: 7.23,
                600: 7.40,
                700: 7.71,
                800: 7.95,
                900: 8.25,
                1000: 8.49,
                1100: 8.58,
                1200: 8.84,
                1300: 9.04,
                1400: 9.29,
                1500: 9.60
            }

        # For weights above 1500g, use incremental formula
        if weight_g > 1500:
            base_fee = 11.00 if is_peak else 10.32
            weight_above_1500 = weight_g - 1500
            intervals_100g = np.ceil(weight_above_1500 / 100)
            return base_fee + (intervals_100g * 0.09)

        # Determine weight bracket for weights <= 1500g
        if weight_g <= 100:
            bracket = 100
        elif weight_g <= 200:
            bracket = 200
        elif weight_g <= 300:
            bracket = 300
        elif weight_g <= 400:
            bracket = 400
        elif weight_g <= 500:
            bracket = 500
        elif weight_g <= 600:
            bracket = 600
        elif weight_g <= 700:
            bracket = 700
        elif weight_g <= 800:
            bracket = 800
        elif weight_g <= 900:
            bracket = 900
        elif weight_g <= 1000:
            bracket = 1000
        elif weight_g <= 1100:
            bracket = 1100
        elif weight_g <= 1200:
            bracket = 1200
        elif weight_g <= 1300:
            bracket = 1300
        elif weight_g <= 1400:
            bracket = 1400
        else:
            bracket = 1500

        return fees[bracket]

    elif tier == 'Small oversize':
        # Small oversize: First 500g base fee + incremental per 500g
        base_fee = 16.77 if is_peak else 15.43

        if weight_g <= 500:
            return base_fee

        weight_above_500 = weight_g - 500
        intervals_500g = np.ceil(weight_above_500 / 500)
        return base_fee + (intervals_500g * 0.46)

    elif tier == 'Medium oversize':
        # Medium oversize: First 500g base fee + incremental per 500g
        base_fee = 41.64 if is_peak else 37.78

        if weight_g <= 500:
            return base_fee

        weight_above_500 = weight_g - 500
        intervals_500g = np.ceil(weight_above_500 / 500)
        return base_fee + (intervals_500g * 0.52)

    elif tier == 'Large oversize':
        # Large oversize: First 500g base fee + incremental per 500g
        base_fee = 89.59 if is_peak else 82.20

        if weight_g <= 500:
            return base_fee

        weight_above_500 = weight_g - 500
        intervals_500g = np.ceil(weight_above_500 / 500)
        return base_fee + (intervals_500g * 0.58)

    elif tier == 'Special oversize':
        # Special oversize: First 500g base fee + incremental per 500g
        base_fee = 166.85 if is_peak else 150.78

        if weight_g <= 500:
            return base_fee

        weight_above_500 = weight_g - 500
        intervals_500g = np.ceil(weight_above_500 / 500)
        return base_fee + (intervals_500g * 0.58)

    else:
        return 0.0

def compute_fba_fees_ca(df):
    """
    Compute Amazon FBA fees for Canada marketplace based on 2026 product size tier definitions.

    Parameters:
    -----------
    df : pandas.DataFrame
        DataFrame with columns:
        - sku
        - asin
        - longest_side
        - median_side
        - shortest_side
        - unit_of_dimension (centimeters or inches)
        - item_package_weight
        - unit_of_weight (grams or pounds)

    Returns:
    --------
    pandas.DataFrame
        Original DataFrame with added columns:
        - marketplace
        - currency
        - unit_weight_g (actual package weight in grams)
        - dimensional_weight_g (dimensional weight in grams)
        - shipping_weight_g (greater of unit or dimensional weight)
        - product_size_tier (tier classification)
        - storage_size_tier (Standard Size or Oversize)
        - off_peak_storage_fee (storage fees in CAD)
        - peak_storage_fee (storage fees in CAD)
        - off_peak_fulfillment_fee (Jan 15, 2026 - Oct 14, 2026)
        - peak_fulfillment_fee (Oct 15, 2025 - Jan 14, 2026)
        - error_message (populated if calculation fails for a SKU)
    """
    # Create a copy to avoid modifying original
    result_df = df.copy()

    # Add marketplace and currency columns
    result_df['marketplace'] = 'Canada'
    result_df['currency'] = 'CAD'

    # Initialize all new columns with NaN
    result_df['unit_weight_g'] = np.nan
    result_df['dimensional_weight_g'] = np.nan
    result_df['shipping_weight_g'] = np.nan
    result_df['product_size_tier'] = ''
    result_df['storage_size_tier'] = ''
    result_df['off_peak_storage_fee'] = np.nan
    result_df['peak_storage_fee'] = np.nan
    result_df['off_peak_fulfillment_fee'] = np.nan
    result_df['peak_fulfillment_fee'] = np.nan
    result_df['error_message'] = ''

    # Process each row individually with error handling
    for idx in range(len(result_df)):
        try:
            # Extract dimensions
            longest = pd.to_numeric(result_df.loc[idx, 'longest_side'], errors='coerce')
            median = pd.to_numeric(result_df.loc[idx, 'median_side'], errors='coerce')
            shortest = pd.to_numeric(result_df.loc[idx, 'shortest_side'], errors='coerce')

            # Check if dimensions are valid
            if pd.isna(longest) or pd.isna(median) or pd.isna(shortest):
                result_df.loc[idx, 'error_message'] = 'Invalid or missing dimensions'
                continue

            # Convert inches to centimeters if needed (1 inch = 2.54 cm)
            unit_dim = str(result_df.loc[idx, 'unit_of_dimension']).lower()
            if 'inch' in unit_dim or 'in' in unit_dim:
                longest = longest * 2.54
                median = median * 2.54
                shortest = shortest * 2.54

            # Extract weight
            unit_weight = pd.to_numeric(result_df.loc[idx, 'item_package_weight'], errors='coerce')

            # Check if weight is valid
            if pd.isna(unit_weight):
                result_df.loc[idx, 'error_message'] = 'Invalid or missing weight'
                continue

            # Convert pounds to grams if needed (1 pound = 453.592 grams)
            unit_wt = str(result_df.loc[idx, 'unit_of_weight']).lower()
            if 'pound' in unit_wt or 'lb' in unit_wt:
                unit_weight = unit_weight * 453.592

            # Calculate dimensional weight in grams
            # Formula: (L × W × H in cm) / 5 = dimensional weight in grams
            dimensional_weight = (longest * median * shortest) / 5

            # Shipping weight is the greater of unit weight or dimensional weight
            shipping_weight = max(unit_weight, dimensional_weight)

            # Convert shipping weight to kg for tier determination
            shipping_weight_kg = shipping_weight / 1000

            # Calculate length plus girth (for oversize classification)
            length_plus_girth = longest + 2 * (median + shortest)

            # Determine Product Size Tier
            product_size_tier = ''

            # Envelope size
            if (shipping_weight <= 500 and
                longest <= 38 and median <= 27 and shortest <= 2):
                product_size_tier = 'Envelope'

            # Standard size
            elif (shipping_weight_kg <= 9 and
                  longest <= 45 and median <= 35 and shortest <= 20):
                product_size_tier = 'Standard'

            # Small oversize
            elif (shipping_weight_kg <= 32 and
                  longest <= 152 and median <= 76 and
                  length_plus_girth <= 330):
                product_size_tier = 'Small oversize'

            # Medium oversize
            elif (shipping_weight_kg <= 68 and
                  longest <= 270 and
                  length_plus_girth <= 330):
                product_size_tier = 'Medium oversize'

            # Large oversize
            elif (shipping_weight_kg <= 68 and
                  longest <= 270 and
                  length_plus_girth <= 419):
                product_size_tier = 'Large oversize'

            # Special oversize
            elif (shipping_weight_kg > 68 or
                  longest > 270 or
                  length_plus_girth > 419):
                product_size_tier = 'Special oversize'

            else:
                product_size_tier = 'Overmax'

            # Volume in cubic meters for storage fee calculation
            volume_cubic_meters = (longest * median * shortest) / 1000000

            # Determine Storage Size Tier (Standard or Oversize)
            is_standard_storage = product_size_tier in ['Envelope', 'Standard']
            storage_size_tier = "Standard Size" if is_standard_storage else "Oversize"

            # Compute storage fees (per cubic meter)
            # Standard Size: off-peak = CAD 40/m³, peak = CAD 77/m³
            # Oversize: off-peak = CAD 28/m³, peak = CAD 49/m³
            off_peak_rate = 40 if is_standard_storage else 28
            peak_rate = 77 if is_standard_storage else 49

            off_peak_storage_fee = volume_cubic_meters * off_peak_rate
            peak_storage_fee = volume_cubic_meters * peak_rate

            # Calculate fulfillment fees
            off_peak_fulfillment_fee = _calculate_fulfillment_fee_ca(
                product_size_tier, shipping_weight, is_peak=False
            )

            peak_fulfillment_fee = _calculate_fulfillment_fee_ca(
                product_size_tier, shipping_weight, is_peak=True
            )

            # Store all calculated values
            result_df.loc[idx, 'unit_weight_g'] = round(unit_weight, 2)
            result_df.loc[idx, 'dimensional_weight_g'] = round(dimensional_weight, 2)
            result_df.loc[idx, 'shipping_weight_g'] = round(shipping_weight, 2)
            result_df.loc[idx, 'product_size_tier'] = product_size_tier
            result_df.loc[idx, 'storage_size_tier'] = storage_size_tier
            result_df.loc[idx, 'off_peak_storage_fee'] = round(off_peak_storage_fee, 7)
            result_df.loc[idx, 'peak_storage_fee'] = round(peak_storage_fee, 7)
            result_df.loc[idx, 'off_peak_fulfillment_fee'] = round(off_peak_fulfillment_fee, 2)
            result_df.loc[idx, 'peak_fulfillment_fee'] = round(peak_fulfillment_fee, 2)

        except Exception as e:
            # If any error occurs, record it and skip this row
            result_df.loc[idx, 'error_message'] = str(e)
            continue

    return result_df

def _calculate_fulfillment_fee_br(price_brl, outbound_shipping_weight_kg):
    """
    Calculate the fulfillment fee for Brazil (BR) based on selling price and outbound shipping weight.

    Parameters:
    -----------
    price_brl : float
        Unit selling price in BRL (used to determine price band column)

    outbound_shipping_weight_kg : int
        Outbound shipping weight in whole kilograms.

        Outbound shipping weight rule (BR):
            outbound_shipping_weight_kg = ceil(max(actual_weight_kg, dimensional_weight_kg) + 0.02)

        Where:
            dimensional_weight_kg = (L * W * H in cm) / 6000   [IATA]
            packaging weight = 0.02 kg (20g)

    Returns:
    --------
    float
        Fulfillment fee in BRL
    """
    bands = [
        ("<30", 0.0, 30.0),
        ("30-49.99", 30.0, 50.0),
        ("50-78.99", 50.0, 79.0),
        ("79-99.99", 79.0, 100.0),
        ("100-119.99", 100.0, 120.0),
        ("120-149.99", 120.0, 150.0),
        ("150-199.99", 150.0, 200.0),
        (">=200", 200.0, float("inf")),
    ]

    price_brl = float(price_brl)
    price_band = "unknown"
    for name, lo, hi in bands:
        if lo <= price_brl < hi:
            price_band = name
            break
    if price_band == "unknown":
        raise ValueError(f"Could not determine price band for price_brl={price_brl}")

    fees = {
        "750g-1kg":     {"<30": 5.65, "30-49.99": 5.85, "50-78.99": 6.05, "79-99.99": 12.45, "100-119.99": 14.45, "120-149.99": 16.45, "150-199.99": 19.05, ">=200": 19.25},
        "1.5-2kg":      {"<30": 5.65, "30-49.99": 5.85, "50-78.99": 6.05, "79-99.99": 13.05, "100-119.99": 15.05, "120-149.99": 17.05, "150-199.99": 19.95, ">=200": 21.35},
        "2-3kg":        {"<30": 5.65, "30-49.99": 5.85, "50-78.99": 6.05, "79-99.99": 14.05, "100-119.99": 16.05, "120-149.99": 18.05, "150-199.99": 20.05, ">=200": 22.35},
        "3-4kg":        {"<30": 5.65, "30-49.99": 5.85, "50-78.99": 6.05, "79-99.99": 15.05, "100-119.99": 17.05, "120-149.99": 19.05, "150-199.99": 21.95, ">=200": 23.35},
        "4-5kg":        {"<30": 5.65, "30-49.99": 5.85, "50-78.99": 6.05, "79-99.99": 16.05, "100-119.99": 18.05, "120-149.99": 20.05, "150-199.99": 22.95, ">=200": 24.35},
        "5-6kg":        {"<30": 5.65, "30-49.99": 5.85, "50-78.99": 6.05, "79-99.99": 24.05, "100-119.99": 27.05, "120-149.99": 29.05, "150-199.99": 30.05, ">=200": 30.35},
        "6-7kg":        {"<30": 5.65, "30-49.99": 5.85, "50-78.99": 6.05, "79-99.99": 25.05, "100-119.99": 28.05, "120-149.99": 30.05, "150-199.99": 31.05, ">=200": 33.35},
        "7-8kg":        {"<30": 5.65, "30-49.99": 5.85, "50-78.99": 6.05, "79-99.99": 26.05, "100-119.99": 29.05, "120-149.99": 31.05, "150-199.99": 32.05, ">=200": 35.35},
        "8-9kg":        {"<30": 5.65, "30-49.99": 5.85, "50-78.99": 6.05, "79-99.99": 27.05, "100-119.99": 30.05, "120-149.99": 32.05, "150-199.99": 33.05, ">=200": 37.35},
        "9-10kg":       {"<30": 5.65, "30-49.99": 5.85, "50-78.99": 6.05, "79-99.99": 35.05, "100-119.99": 40.05, "120-149.99": 46.05, "150-199.99": 51.05, ">=200": 51.35},
        "additional_kg": {"<30": 5.65, "30-49.99": 5.85, "50-78.99": 6.05, "79-99.99": 3.05,  "100-119.99": 3.05,  "120-149.99": 3.05,  "150-199.99": 3.50,  ">=200": 3.50},
    }

    w = int(outbound_shipping_weight_kg)
    if w <= 0:
        raise ValueError("Invalid outbound shipping weight (<=0 kg)")
    if w > 22:
        raise ValueError("Outbound shipping weight > 22 kg not supported")

    if w == 1:
        return fees["750g-1kg"][price_band]
    if w == 2:
        return fees["1.5-2kg"][price_band]
    if 3 <= w <= 10:
        return fees[f"{w-1}-{w}kg"][price_band]

    base = fees["9-10kg"][price_band]
    add = fees["additional_kg"][price_band]
    return base + (w - 10) * add

def compute_fba_fees_br(df):
    """
    Compute Amazon FBA fees for Brazil marketplace (BR).

    Required input columns:
    - sku, asin
    - longest_side, median_side, shortest_side
    - unit_of_dimension (inches or centimeters)
    - item_package_weight
    - unit_of_weight (grams, kg, or pounds)
    - selling_price (BRL)

    Output columns added:
    - marketplace, currency
    - unit_weight_g
    - dimensional_weight_g
    - shipping_weight_g                 (rounded whole-kg outbound shipping weight, in grams)
    - storage_size_tier                 ("Below 10,000 cubic cm" / ">= 10,000 cubic cm")
    - off_peak_storage_fee, peak_storage_fee     (same value in BR)
    - off_peak_fulfillment_fee, peak_fulfillment_fee (same value in BR)
    - error_message

    BR restrictions (skip if violated):
    - max side <= 105 cm
    - L + W + H <= 200 cm
    - L + 2W + 2H <= 295 cm
    - outbound shipping weight <= 22 kg
    """
    result_df = df.copy()

    result_df["marketplace"] = "Brazil"
    result_df["currency"] = "BRL"

    result_df["unit_weight_g"] = np.nan
    result_df["dimensional_weight_g"] = np.nan
    result_df["shipping_weight_g"] = np.nan
    result_df["storage_size_tier"] = ""
    result_df["off_peak_storage_fee"] = np.nan
    result_df["peak_storage_fee"] = np.nan
    result_df["off_peak_fulfillment_fee"] = np.nan
    result_df["peak_fulfillment_fee"] = np.nan
    result_df["error_message"] = ""

    for idx in range(len(result_df)):
        try:
            # --- Dimensions ---
            longest = pd.to_numeric(result_df.loc[idx, "longest_side"], errors="coerce")
            median = pd.to_numeric(result_df.loc[idx, "median_side"], errors="coerce")
            shortest = pd.to_numeric(result_df.loc[idx, "shortest_side"], errors="coerce")

            if pd.isna(longest) or pd.isna(median) or pd.isna(shortest):
                result_df.loc[idx, "error_message"] = "Invalid or missing dimensions"
                continue

            unit_dim = str(result_df.loc[idx, "unit_of_dimension"]).lower()
            if "inch" in unit_dim or unit_dim.strip() in ["in", "inches"]:
                longest, median, shortest = longest * 2.54, median * 2.54, shortest * 2.54

            dims = sorted([longest, median, shortest], reverse=True)
            longest, median, shortest = dims[0], dims[1], dims[2]

            # Restrictions
            if longest > 105 or median > 105 or shortest > 105:
                result_df.loc[idx, "error_message"] = "Dimension restriction failed: side > 105 cm"
                continue
            if (longest + median + shortest) > 200:
                result_df.loc[idx, "error_message"] = "Dimension restriction failed: L+W+H > 200 cm"
                continue
            if (longest + 2 * median + 2 * shortest) > 295:
                result_df.loc[idx, "error_message"] = "Dimension restriction failed: L+2W+2H > 295 cm"
                continue

            # --- Weight ---
            unit_weight = pd.to_numeric(result_df.loc[idx, "item_package_weight"], errors="coerce")
            if pd.isna(unit_weight):
                result_df.loc[idx, "error_message"] = "Invalid or missing weight"
                continue

            unit_wt = str(result_df.loc[idx, "unit_of_weight"]).lower()
            if "gram" in unit_wt or unit_wt.strip() in ["g", "grams"]:
                actual_kg = unit_weight / 1000.0
            elif "kg" in unit_wt:
                actual_kg = float(unit_weight)
            elif "pound" in unit_wt or "lb" in unit_wt:
                actual_kg = unit_weight * 0.453592
            else:
                actual_kg = unit_weight / 1000.0  # permissive default

            # Dimensional weight (kg) then convert to grams for output
            dim_kg = (longest * median * shortest) / 6000.0
            dim_g = dim_kg * 1000.0

            # Outbound shipping weight (whole kg) => store as grams
            outbound_kg = int(math.ceil(max(actual_kg, dim_kg) + 0.02))
            if outbound_kg > 22:
                result_df.loc[idx, "error_message"] = "Outbound weight > 22 kg (not supported)"
                continue
            shipping_weight_g = outbound_kg * 1000.0

            # --- Price ---
            if "selling_price" not in result_df.columns:
                result_df.loc[idx, "error_message"] = "Missing selling_price column (BRL required)"
                continue

            price_brl = pd.to_numeric(result_df.loc[idx, "selling_price"], errors="coerce")
            if pd.isna(price_brl):
                result_df.loc[idx, "error_message"] = "Invalid or missing selling_price"
                continue

            # --- Storage fee (per unit / per month) ---
            vol_cm3 = longest * median * shortest
            vol_m3 = vol_cm3 / 1_000_000.0
            storage_rate = 75.0 if vol_cm3 < 10_000 else 37.5
            storage_fee = vol_m3 * storage_rate

            # --- Fulfillment fee ---
            fulfillment_fee = _calculate_fulfillment_fee_br(float(price_brl), outbound_kg)

            # Save
            result_df.loc[idx, "unit_weight_g"] = round(actual_kg * 1000.0, 2)
            result_df.loc[idx, "dimensional_weight_g"] = round(dim_g, 2)
            result_df.loc[idx, "shipping_weight_g"] = round(shipping_weight_g, 2)
            result_df.loc[idx, "storage_size_tier"] = (
                "Below 10,000 cubic cm" if vol_cm3 < 10_000 else ">= 10,000 cubic cm"
            )

            # Mirror peak/off-peak (BR has one rate)
            result_df.loc[idx, "off_peak_storage_fee"] = round(storage_fee, 7)
            result_df.loc[idx, "peak_storage_fee"] = round(storage_fee, 7)
            result_df.loc[idx, "off_peak_fulfillment_fee"] = round(fulfillment_fee, 2)
            result_df.loc[idx, "peak_fulfillment_fee"] = round(fulfillment_fee, 2)

            result_df.loc[idx, "error_message"] = ""

        except Exception as e:
            result_df.loc[idx, "error_message"] = str(e)
            continue

    return result_df

def _calculate_fulfillment_fee_mx(tier, price_mxn, shipping_weight_kg):
    """
    Calculate the FBA fulfillment fee for Mexico (MX), based on:
    - Size tier (Envelope / Standard / Oversize)
    - Product price band (MXN)
    - Shipping weight (kg), using MX rounding/increment rules

    Parameters:
    -----------
    tier : str
        One of: "Envelope", "Standard", "Oversize"

    price_mxn : float
        Unit selling price in MXN, used to select the price band column:
            - "<150"
            - "150-298.99"
            - "299-498.99"
            - ">=499"

    shipping_weight_kg : float
        Shipping weight in kg (already computed upstream per MX rules).

    Returns:
    --------
    float
        Fulfillment fee in MXN
    """
    # Price banding
    p = float(price_mxn)
    if p < 150:
        band = "<150"
    elif p < 299:
        band = "150-298.99"
    elif p < 499:
        band = "299-498.99"
    else:
        band = ">=499"

    w = float(shipping_weight_kg)
    if w <= 0:
        raise ValueError("Invalid shipping_weight_kg (<= 0)")

    # Tables hard-coded from what you pasted
    envelope = {
        "<150":       [(0.10, 50.02), (0.20, 50.41), (0.30, 50.80), (0.40, 51.19), (float("inf"), 51.58)],
        "150-298.99": [(0.10, 60.02), (0.20, 60.41), (0.30, 60.80), (0.40, 61.19), (float("inf"), 61.58)],
        "299-498.99": [(0.10, 51.58), (0.20, 51.97), (0.30, 52.76), (0.40, 53.21), (float("inf"), 53.55)],
        ">=499":      [(0.10, 60.02), (0.20, 60.41), (0.30, 60.80), (0.40, 61.19), (float("inf"), 61.58)],
    }

    standard = {
        "<150": [
            (0.10, 51.79), (0.20, 53.21), (0.30, 54.62), (0.40, 56.04), (0.50, 57.45),
            (0.60, 58.86), (0.70, 59.87), (0.80, 60.88), (0.90, 61.89), (1.00, 62.89),
            (float("inf"), 64.21),  # "Over 1.00 kg" base
        ],
        "150-298.99": [
            (0.10, 61.79), (0.20, 63.21), (0.30, 64.62), (0.40, 66.04), (0.50, 67.45),
            (0.60, 68.86), (0.70, 69.87), (0.80, 70.88), (0.90, 71.89), (1.00, 72.89),
            (float("inf"), 74.21),
        ],
        "299-498.99": [
            (0.10, 51.93), (0.20, 53.21), (0.30, 54.62), (0.40, 56.04), (0.50, 57.45),
            (0.60, 58.86), (0.70, 59.87), (0.80, 60.88), (0.90, 61.89), (1.00, 62.89),
            (float("inf"), 64.21),
        ],
        ">=499": [
            (0.10, 61.79), (0.20, 63.21), (0.30, 64.62), (0.40, 66.04), (0.50, 67.45),
            (0.60, 68.86), (0.70, 69.87), (0.80, 70.88), (0.90, 71.89), (1.00, 72.89),
            (float("inf"), 74.21),
        ],
    }
    standard_add_per_025kg = 1.74

    oversize_base = {
        "<150": 65.38,
        "150-298.99": 75.38,
        "299-498.99": 65.38,
        ">=499": 75.38,
    }
    oversize_add_per_05kg = 3.83

    # Fee selection
    if tier == "Envelope":
        for upper, fee in envelope[band]:
            if w <= upper:
                return fee
        return envelope[band][-1][1]

    if tier == "Standard":
        # up to 1.00 kg uses table
        if w <= 1.00:
            for upper, fee in standard[band]:
                if w <= upper:
                    return fee

        # > 1.00 kg: base (over 1.00) + ceil((w-1.0)/0.25)*increment
        base = standard[band][-1][1]
        units = int(math.ceil((w - 1.0) / 0.25))
        return base + units * standard_add_per_025kg

    if tier == "Oversize":
        base = oversize_base[band]
        if w <= 1.0:
            return base
        units = int(math.ceil((w - 1.0) / 0.5))
        return base + units * oversize_add_per_05kg

    raise ValueError(f"Unknown tier: {tier}")

def compute_fba_fees_mx(df):
    """
    Compute Amazon FBA fees for Mexico marketplace (MX).

    Parameters:
    -----------
    df : pandas.DataFrame
        DataFrame with columns:
        - sku
        - asin
        - longest_side
        - median_side
        - shortest_side
        - unit_of_dimension (inches or centimeters)
        - item_package_weight
        - unit_of_weight (grams, kg, or pounds)
        - selling_price (MXN)

    Returns:
    --------
    pandas.DataFrame
        Original DataFrame with added columns:
        - marketplace
        - currency
        - unit_weight_g
        - dimensional_weight_g               (dim weight in grams using divisor 5000)
        - shipping_weight_g                  (shipping weight used for fulfillment, grams)
        - product_size_tier                  ("Envelope", "Standard", "Oversize")
        - storage_size_tier                  ("Envelope or Standard-size", "Oversize")
        - off_peak_storage_fee               (Jan-Sep)
        - peak_storage_fee                   (Oct-Dec)
        - off_peak_fulfillment_fee           (mirrors peak; MX fulfillment has no seasonality)
        - peak_fulfillment_fee
        - error_message

    MX dimensional weight and shipping weight rules:
    ----------------------------------------------
    - If tier is Envelope or Standard and actual_weight_kg <= 0.5:
        shipping_weight_kg = actual_weight_kg
      Else:
        shipping_weight_kg = max(actual_weight_kg, dimensional_weight_kg)
    - dimensional_weight_kg = (L*W*H in cm) / 5000

    MX dimension restrictions (skip if violated):
    --------------------------------------------
    - Envelope: <= 38 x 27 x 2 cm
    - Standard: <= 45 x 35 x 20 cm
    - Oversize: <= 550 x 270 x 270 cm
    - If item exceeds Oversize max dims: skip

    MX storage:
    ----------
    - Fees charged per dm3 (liter), dm3 = (cm3)/1000
    - Rates (MXN per dm3 per month, VAT included):
        Jan-Sep:  Standard/Envelope 0.36 ; Oversize 0.19
        Oct-Dec:  Standard/Envelope 0.53 ; Oversize 0.43
    """
    result_df = df.copy()

    result_df["marketplace"] = "Mexico"
    result_df["currency"] = "MXN"

    result_df["unit_weight_g"] = np.nan
    result_df["dimensional_weight_g"] = np.nan
    result_df["shipping_weight_g"] = np.nan
    result_df["product_size_tier"] = ""
    result_df["storage_size_tier"] = ""
    result_df["off_peak_storage_fee"] = np.nan
    result_df["peak_storage_fee"] = np.nan
    result_df["off_peak_fulfillment_fee"] = np.nan
    result_df["peak_fulfillment_fee"] = np.nan
    result_df["error_message"] = ""

    # Storage rates (MXN per dm3 per month)
    OFF_PEAK_STANDARD_RATE = 0.36  # Jan-Sep
    OFF_PEAK_OVERSIZE_RATE = 0.19
    PEAK_STANDARD_RATE = 0.53      # Oct-Dec
    PEAK_OVERSIZE_RATE = 0.43

    for idx in range(len(result_df)):
        try:
            # --- Dimensions ---
            longest = pd.to_numeric(result_df.loc[idx, "longest_side"], errors="coerce")
            median = pd.to_numeric(result_df.loc[idx, "median_side"], errors="coerce")
            shortest = pd.to_numeric(result_df.loc[idx, "shortest_side"], errors="coerce")

            if pd.isna(longest) or pd.isna(median) or pd.isna(shortest):
                result_df.loc[idx, "error_message"] = "Invalid or missing dimensions"
                continue

            unit_dim = str(result_df.loc[idx, "unit_of_dimension"]).lower()
            if "inch" in unit_dim or unit_dim.strip() in ["in", "inches"]:
                longest, median, shortest = longest * 2.54, median * 2.54, shortest * 2.54

            dims = sorted([longest, median, shortest], reverse=True)
            longest, median, shortest = dims[0], dims[1], dims[2]

            # Determine tier + apply max dimension restrictions
            if longest <= 38 and median <= 27 and shortest <= 2:
                tier = "Envelope"
            elif longest <= 45 and median <= 35 and shortest <= 20:
                tier = "Standard"
            elif longest <= 550 and median <= 270 and shortest <= 270:
                tier = "Oversize"
            else:
                result_df.loc[idx, "error_message"] = "Over max dimensions for MX (exceeds Oversize limits)"
                continue

            # --- Weight ---
            unit_weight = pd.to_numeric(result_df.loc[idx, "item_package_weight"], errors="coerce")
            if pd.isna(unit_weight):
                result_df.loc[idx, "error_message"] = "Invalid or missing weight"
                continue

            unit_wt = str(result_df.loc[idx, "unit_of_weight"]).lower()
            if "gram" in unit_wt or unit_wt.strip() in ["g", "grams"]:
                actual_kg = unit_weight / 1000.0
            elif "kg" in unit_wt:
                actual_kg = float(unit_weight)
            elif "pound" in unit_wt or "lb" in unit_wt:
                actual_kg = unit_weight * 0.453592
            else:
                actual_kg = unit_weight / 1000.0  # permissive default

            # Dimensional weight (kg) with divisor 5000
            dim_kg = (longest * median * shortest) / 5000.0

            # Shipping weight rule
            if tier in ["Envelope", "Standard"] and actual_kg <= 0.5:
                ship_kg = actual_kg
            else:
                ship_kg = max(actual_kg, dim_kg)

            # --- Price ---
            if "selling_price" not in result_df.columns:
                result_df.loc[idx, "error_message"] = "Missing selling_price column (MXN required)"
                continue
            price_mxn = pd.to_numeric(result_df.loc[idx, "selling_price"], errors="coerce")
            if pd.isna(price_mxn):
                result_df.loc[idx, "error_message"] = "Invalid or missing selling_price"
                continue

            # --- Storage volume dm3 ---
            vol_cm3 = longest * median * shortest
            vol_dm3 = vol_cm3 / 1000.0

            is_standard_storage = tier in ["Envelope", "Standard"]
            storage_size_tier = "Envelope or Standard-size" if is_standard_storage else "Oversize"

            off_peak_rate = OFF_PEAK_STANDARD_RATE if is_standard_storage else OFF_PEAK_OVERSIZE_RATE
            peak_rate = PEAK_STANDARD_RATE if is_standard_storage else PEAK_OVERSIZE_RATE

            off_peak_storage_fee = vol_dm3 * off_peak_rate
            peak_storage_fee = vol_dm3 * peak_rate

            # --- Fulfillment fee (no seasonality; mirror) ---
            fulfillment_fee = _calculate_fulfillment_fee_mx(tier, float(price_mxn), float(ship_kg))

            # Save outputs (weights in grams)
            result_df.loc[idx, "product_size_tier"] = tier
            result_df.loc[idx, "storage_size_tier"] = storage_size_tier

            result_df.loc[idx, "unit_weight_g"] = round(actual_kg * 1000.0, 2)
            result_df.loc[idx, "dimensional_weight_g"] = round(dim_kg * 1000.0, 2)
            result_df.loc[idx, "shipping_weight_g"] = round(ship_kg * 1000.0, 2)

            result_df.loc[idx, "off_peak_storage_fee"] = round(off_peak_storage_fee, 7)
            result_df.loc[idx, "peak_storage_fee"] = round(peak_storage_fee, 7)

            result_df.loc[idx, "off_peak_fulfillment_fee"] = round(fulfillment_fee, 2)
            result_df.loc[idx, "peak_fulfillment_fee"] = round(fulfillment_fee, 2)

            result_df.loc[idx, "error_message"] = ""

        except Exception as e:
            result_df.loc[idx, "error_message"] = str(e)
            continue

    return result_df

