import colorsys
import math
import random

import numpy as np

from modulitiz.multimedia.audio.musicvisualizer.util.MusicVisualizerConstants import MusicVisualizerConstants


class MusicVisualizerUtil:
	@staticmethod
	def calculateBars()->tuple[list[list],int]:
		tmp_bars=[]
		count=0
		for group in MusicVisualizerConstants.SETTINGS_FREQUENCIES_CUSTOM:
			s=group["stop"]-group["start"]
			countPartial=group["count"]
			reminder=s%countPartial
			step=int(s/countPartial)
			rng=group["start"]
			
			g=[]
			for _ in range(countPartial):
				if reminder>0:
					reminder-=1
					arr=np.arange(rng,stop=rng+step+2)
					rng+=step+3
				else:
					arr=np.arange(rng,stop=rng+step+1)
					rng+=step+2
				g.append(arr)
			count+=countPartial
			tmp_bars.append(g)
		return tmp_bars,count
	
	@staticmethod
	def clamp(minValue: int,maxValue: int,value: int) -> int:
		if value<minValue:
			return minValue
		if value>maxValue:
			return maxValue
		return value
	
	@classmethod
	def normalizePoint(cls,point: tuple[np.float32,np.float32]) -> tuple[int,int]:
		return cls.__normalizePointCoordinate(point[0]),cls.__normalizePointCoordinate(point[1])
	
	@staticmethod
	def __normalizePointCoordinate(n: np.float32) -> int:
		return int(n)
	
	@staticmethod
	def randomColor():
		hue,saturation,luminosity=random.random(),0.5+random.random()/2.0,0.4+random.random()/5.0
		return [int(256*i) for i in colorsys.hls_to_rgb(hue,luminosity,saturation)]
	
	@staticmethod
	def rotate(xy,theta):
		"""
		https://en.wikipedia.org/wiki/Rotation_matrix#In_two_dimensions
		"""
		cosTheta=math.cos(theta)
		sinTheta=math.sin(theta)
		return xy[0]*cosTheta-xy[1]*sinTheta,xy[0]*sinTheta+xy[1]*cosTheta
	
	@staticmethod
	def translate(xy,offset):
		return xy[0]+offset[0],xy[1]+offset[1]
