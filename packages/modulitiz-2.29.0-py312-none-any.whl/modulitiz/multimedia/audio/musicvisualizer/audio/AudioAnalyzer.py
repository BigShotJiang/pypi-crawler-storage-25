import librosa.display
import matplotlib.pyplot as plt
import numpy as np


class AudioAnalyzer(object):
	N_FFT=2048*4
	
	def __init__(self):
		# array for frequencies
		self.frequencies_index_ratio = 0
		# array of time periods
		self.time_index_ratio = 0
		# a matrix that contains decibel values according to frequency and time indexes
		self.spectrogram = None

	def load(self, filename:str):
		# getting information from the file
		time_series, sample_rate = librosa.load(filename)
		'''
		sample_rate=librosa.get_samplerate(filename)
		stream = librosa.stream(filename,block_length=256,frame_length=4096,hop_length=1024)
		for y_block in stream:
			time_series=y_block
		'''
		
		# getting a matrix which contains amplitude values according to frequency and time indexes
		stft = np.abs(librosa.stft(time_series, hop_length=512, n_fft=self.N_FFT))
		# converting the matrix to decibel matrix
		self.spectrogram = librosa.amplitude_to_db(stft, ref=np.max)
		
		# getting an array of time periodic
		shape:tuple[int,...]=self.spectrogram.shape
		times = librosa.core.frames_to_time(np.arange(shape[1]), sr=sample_rate, hop_length=512, n_fft=self.N_FFT)
		self.time_index_ratio = len(times)/times[-2]

		# getting an array of frequencies
		frequencies = librosa.core.fft_frequencies(n_fft=self.N_FFT)
		self.frequencies_index_ratio = len(frequencies)/frequencies[-2]
	
	def show(self):
		librosa.display.specshow(self.spectrogram, y_axis='log', x_axis='time')
		
		plt.title('spectrogram')
		plt.colorbar(format='%+2.0f dB')
		plt.tight_layout()
		plt.show()

	def get_decibel(self, target_time, freq):
		return self.spectrogram[int(freq*self.frequencies_index_ratio)][int(target_time*self.time_index_ratio)]

	def get_decibel_array(self, target_time, freq_arr):
		arr = []
		for f in freq_arr:
			arr.append(self.get_decibel(target_time,f))
		return arr
