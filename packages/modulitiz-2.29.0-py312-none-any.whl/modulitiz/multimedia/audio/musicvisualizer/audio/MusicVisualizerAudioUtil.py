from modulitiz.multimedia.audio.musicvisualizer.audio.AudioBarAverageRotated import AudioBarAverageRotated


class MusicVisualizerAudioUtil(object):
	@staticmethod
	def calculateAvgBass(bar:list[AudioBarAverageRotated])->int:
		avgBass=0
		for b in bar:
			avgBass+=b.avg
		avgBass/=len(bar)
		return avgBass
