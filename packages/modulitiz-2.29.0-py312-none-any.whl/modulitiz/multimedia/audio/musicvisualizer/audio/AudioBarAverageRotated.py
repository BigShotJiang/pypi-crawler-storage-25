import pygame

from modulitiz.multimedia.audio.musicvisualizer.audio.AudioBarAverage import AudioBarAverage
from modulitiz.multimedia.audio.musicvisualizer.audio.Rect import Rect


class AudioBarAverageRotated(AudioBarAverage):

	def __init__(self, x, y, rng, color, angle=0, width:int=50, minHeight:int=10, maxHeight:int=100, minDecibel:int=-80, maxDecibel:int=0):
		super().__init__(x, y, 0, color, width, minHeight, maxHeight, minDecibel, maxDecibel)
		self.rng = rng
		self.rect = None
		self.angle = angle

	def render(self, screen):
		pygame.draw.polygon(screen, self.color, self.rect.points)

	def render_c(self, screen, color):
		pygame.draw.polygon(screen, color, self.rect.points)

	def update_rect(self):
		self.rect = Rect(self.x, self.y, self.width, self.height)
		self.rect.rotate(self.angle)
