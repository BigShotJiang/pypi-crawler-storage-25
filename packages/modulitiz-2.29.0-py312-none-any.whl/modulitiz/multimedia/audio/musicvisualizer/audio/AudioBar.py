import pygame

from modulitiz.multimedia.audio.musicvisualizer.util.MusicVisualizerUtil import MusicVisualizerUtil


class AudioBar(object):

	def __init__(self, x, y, freq, color, width:int=50, minHeight:int=10, maxHeight:int=100, minDecibel:int=-80, maxDecibel:int=0):
		self.x, self.y, self.freq = x, y, freq
		self.color = color
		self.width, self.minHeight, self.maxHeight = width, minHeight, maxHeight
		self.height = minHeight
		self.minDecibel, self.maxDecibel = minDecibel, maxDecibel
		self.__decibel_height_ratio = (self.maxHeight - self.minHeight)/(self.maxDecibel - self.minDecibel)

	def update(self, dt, decibel):
		desired_height = decibel * self.__decibel_height_ratio + self.maxHeight
		speed = (desired_height - self.height)/0.1
		self.height += speed * dt
		self.height = MusicVisualizerUtil.clamp(self.minHeight, self.maxHeight, self.height)

	def render(self, screen):
		pygame.draw.rect(screen, self.color, (self.x, self.y + self.maxHeight - self.height, self.width, self.height))
