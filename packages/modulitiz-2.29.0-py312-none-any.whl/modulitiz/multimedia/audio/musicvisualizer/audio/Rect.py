import math

import pygame

from modulitiz.multimedia.audio.musicvisualizer.util.MusicVisualizerUtil import MusicVisualizerUtil


class Rect(object):

	def __init__(self,x,y,w,h):
		self.x, self.y, self.w, self.h = x,y,w,h

		self.points = []

		self.origin = [self.w/2,0]
		self.offset = [self.origin[0] + x, self.origin[1] + y]

		self.rotate(0)

	def rotate(self, angle:int):
		template = [
			(-self.origin[0], self.origin[1]),
			(-self.origin[0] + self.w, self.origin[1]),
			(-self.origin[0] + self.w, self.origin[1] - self.h),
			(-self.origin[0], self.origin[1] - self.h)
		]
		self.points = [MusicVisualizerUtil.translate(MusicVisualizerUtil.rotate(xy, math.radians(angle)), self.offset) for xy in template]

	def draw(self,screen):
		pygame.draw.polygon(screen, (255,255, 0), self.points)
