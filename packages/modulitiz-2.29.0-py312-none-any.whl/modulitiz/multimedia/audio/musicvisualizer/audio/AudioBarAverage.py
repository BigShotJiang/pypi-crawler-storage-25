from modulitiz.multimedia.audio.musicvisualizer.audio.AudioBar import AudioBar


class AudioBarAverage(AudioBar):

	def __init__(self, x, y, rng, color, width:int=50, minHeight:int=10, maxHeight:int=100, minDecibel:int=-80, maxDecibel:int=0):
		super().__init__(x, y, 0, color, width, minHeight, maxHeight, minDecibel, maxDecibel)
		self.rng = rng
		self.avg = 0

	def update_all(self, dt, time, analyzer):
		self.avg = 0
		for i in self.rng:
			self.avg += analyzer.get_decibel(time, i)

		self.avg /= len(self.rng)
		self.update(dt, self.avg)
