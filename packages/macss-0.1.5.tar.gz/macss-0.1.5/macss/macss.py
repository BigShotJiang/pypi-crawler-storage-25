import ctypes
import time
import numpy as np
import os

class macss:
    def __init__(self):
        current_dir = os.path.dirname(os.path.abspath(__file__))
        lib_path = os.path.join(current_dir, 'libScreenCapture.dylib')
        
        if not os.path.exists(lib_path):
            raise FileNotFoundError(f"Could not find {lib_path}")
            
        self.lib = ctypes.CDLL(lib_path)
        
        # Setup Argtypes
        self.lib.init_capture.argtypes = [ctypes.POINTER(ctypes.c_int32), ctypes.POINTER(ctypes.c_int32)]
        self.lib.start_stream.argtypes = [
            ctypes.POINTER(ctypes.c_uint8), ctypes.POINTER(ctypes.c_uint64), 
            ctypes.POINTER(ctypes.c_int32), ctypes.c_int32, ctypes.c_int32, 
            ctypes.c_int32, ctypes.c_int32, ctypes.c_int32
        ]

        self.full_w = ctypes.c_int32()
        self.full_h = ctypes.c_int32()
        self.lib.init_capture(ctypes.byref(self.full_w), ctypes.byref(self.full_h))
        
        # Avoid pyautogui dependency for scale if possible, but keeping logic consistent
        # Hardcoding 2.0 is common for Retina, but your current logic is safer.
        import pyautogui
        sw, _ = pyautogui.size()
        self.scale = self.full_w.value / sw

        # Pre-allocate one large reusable buffer
        # Added a bit of padding for stride alignment
        self.max_size = (self.full_w.value * 4 + 128) * (self.full_h.value + 64)
        self._buffer = np.zeros(self.max_size, dtype=np.uint8)
        self._ptr = self._buffer.ctypes.data_as(ctypes.POINTER(ctypes.c_uint8))
        
        self._counter = ctypes.c_uint64(0)
        self._bpr = ctypes.c_int32(0) 
        self.running = False
        self._current_region = None
        self._view = None # Cache the NumPy view

    def __enter__(self): return self
    def __exit__(self, exc_type, exc_val, exc_tb): self.stop()

    def stop(self):
        if self.running:
            self.lib.stop_stream()
            self.running = False

    def grab(self, region=None):
        # 1. Coordinate Prep (Moved out of high-frequency if region hasn't changed)
        # 1. Normalize the region immediately
        if region is None:
            region = {"top": 0, "left": 0, "width": int(self.full_w.value / self.scale), "height": int(self.full_h.value / self.scale)}

        # 2. Check if we need to re-initialize the stream
        if region != self._current_region:
            p_left = int(region['left'] * self.scale)
            p_top = int(region['top'] * self.scale)
            p_w = int(region['width'] * self.scale)
            p_h = int(region['height'] * self.scale)

            if self.running: 
                self.lib.stop_stream()
            
            self._counter.value = 0 
            self._bpr.value = 0
            self.lib.start_stream(
                self._ptr, ctypes.byref(self._counter), ctypes.byref(self._bpr),
                p_left, p_top, p_w, p_h, self.max_size
            )
            self.running = True
            self._current_region = region.copy()
            
            while self._counter.value == 0: 
                time.sleep(0.001)
            
            # This is where _active_slice is born
            stride = self._bpr.value
            self._view = self._buffer[:p_h * stride].reshape((p_h, stride))
            self._active_slice = self._view[:, :p_w * 4].view(np.uint8).reshape(p_h, p_w, 4)

        return self._active_slice

