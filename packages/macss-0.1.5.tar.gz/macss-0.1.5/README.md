# MacSS  
**Mac Alternative of MSS for Apple Silicon (M-Series) based on new ScreenCaptureKit**

MacSS is a high-performance, zero-copy screen capture utility By leveraging Apple's modern `ScreenCaptureKit` and a direct C-interop pointer to **Unified Memory**.

## Zero Copy Architecture 
**1. The macOS GPU writes screen data to a specific memory address. <br>
2. MacSS maps a Python pointer directly to that **exact address**. <br>
3. You read the data with **zero latency**. No data is moved; you are simply "looking" at the GPU's shoulder.**

<br>



## Performance Benchmarks
Tested on M1 (8GB Ram Model)

### Test Script
```bash
import time
from mss import mss
from macss import macss

region = {"top": 0, "left": 0, "width": 400, "height": 400}
N = 10_000


with macss() as sct:
    t = time.time()
    sct.grab(region)
    for _ in range(N):
        sct.grab(region)
    dt = time.time() - t
    print(f"macss: {dt:.4f}s | iterations : {N} | {1000*dt/N:.4f} ms | {N/dt:.2f} FPS")

with mss() as sct:
    t = time.time()
    for _ in range(N):
        sct.grab(region)
    dt = time.time() - t
    print(f"mss: {dt:.4f}s | iterations : {N} | {1000*dt/N:.4f} ms | {N/dt:.2f} FPS")
```
### Results 
```bash
macss: 0.2126s | iterations : 1000 | 0.2126 ms  | 4704.66 FPS
mss: 20.0145s  | iterations : 1000 | 20.0145 ms | 49.96 FPS
```
---


## Installation
```bash
pip install macss
```

## Basic Usage 
```bash
import cv2
from macss import macss

region = {"top": 0, "left": 0, "width": 400, "height": 400}

with macss() as sct:
    while True:
        frame = sct.grab(region) # Returns numpy.ndarray with RGBA Channel
        
        img = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
        
        cv2.imshow("MacSS High-Speed Feed", img)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
```
---



