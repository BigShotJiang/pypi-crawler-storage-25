"""Tests for agents and state management."""

from qamigrate.agents.state import (
    MigrationState,
    Phase,
    create_initial_state,
    update_state_timestamp,
    add_error_to_state,
)
from qamigrate.agents.supervisor import SupervisorAgent
from qamigrate.core.config import SupervisorConfig


class TestMigrationState:
    """Tests for MigrationState."""

    def test_create_initial_state(self) -> None:
        """Test creating initial migration state."""
        state = create_initial_state(
            file_path="/path/to/LoginPage.java",
            project_path="/path/to/project",
        )

        assert state["file_path"] == "/path/to/LoginPage.java"
        assert state["project_path"] == "/path/to/project"
        assert state["phase"] == Phase.INIT
        assert state["retry_count"] == 0
        assert state["errors"] == []

    def test_update_timestamp(self) -> None:
        """Test timestamp update."""
        state = create_initial_state("/test.java", "/project")
        original_time = state["updated_at"]

        import time
        time.sleep(0.01)

        state = update_state_timestamp(state)
        assert state["updated_at"] != original_time

    def test_add_error(self) -> None:
        """Test adding error to state."""
        state = create_initial_state("/test.java", "/project")

        state = add_error_to_state(
            state,
            error_type="TestError",
            message="Something went wrong",
        )

        assert len(state["errors"]) == 1
        assert state["errors"][0]["error_type"] == "TestError"
        assert state["errors"][0]["message"] == "Something went wrong"


class TestSupervisorAgent:
    """Tests for SupervisorAgent."""

    def test_supervisor_initialization(self) -> None:
        """Test supervisor agent initialization."""
        supervisor = SupervisorAgent()
        assert supervisor.max_retries == 3

    def test_supervisor_with_config(self) -> None:
        """Test supervisor with custom config."""
        config = SupervisorConfig(max_retries=5)
        supervisor = SupervisorAgent(config)
        assert supervisor.max_retries == 5

    def test_route_init_to_scanner(self) -> None:
        """Test routing from init phase to scanner."""
        supervisor = SupervisorAgent()
        state = create_initial_state("/test.java", "/project")

        next_agent = supervisor.route(state)
        assert next_agent == "scanner"

    def test_route_scanned_to_coder(self) -> None:
        """Test routing from scanned phase to coder."""
        supervisor = SupervisorAgent()
        state = create_initial_state("/test.java", "/project")
        state["phase"] = Phase.SCANNED
        state["ast_data"] = {"class_name": "TestClass"}

        next_agent = supervisor.route(state)
        assert next_agent == "coder"

    def test_route_generated_to_compiler(self) -> None:
        """Test routing from generated phase to compiler."""
        supervisor = SupervisorAgent()
        state = create_initial_state("/test.java", "/project")
        state["phase"] = Phase.GENERATED
        state["generated_code"] = "public class Test {}"

        next_agent = supervisor.route(state)
        assert next_agent == "compiler"

    def test_route_compilation_failed_to_fixer(self) -> None:
        """Test routing compilation failure to fixer."""
        supervisor = SupervisorAgent()
        state = create_initial_state("/test.java", "/project")
        state["phase"] = Phase.COMPILATION_FAILED
        state["retry_count"] = 1

        next_agent = supervisor.route(state)
        assert next_agent == "fixer"

    def test_route_compilation_failed_to_failed(self) -> None:
        """Test routing to failed after max retries."""
        supervisor = SupervisorAgent()
        state = create_initial_state("/test.java", "/project")
        state["phase"] = Phase.COMPILATION_FAILED
        state["retry_count"] = 3  # Max retries reached

        next_agent = supervisor.route(state)
        assert next_agent == "failed"

    def test_route_compiled_to_visual(self) -> None:
        """Test routing from compiled to visual."""
        supervisor = SupervisorAgent()
        state = create_initial_state("/test.java", "/project")
        state["phase"] = Phase.COMPILED

        next_agent = supervisor.route(state)
        assert next_agent == "visual"

    def test_route_verified_pass_to_end(self) -> None:
        """Test routing verified with high match to end."""
        supervisor = SupervisorAgent()
        state = create_initial_state("/test.java", "/project")
        state["phase"] = Phase.VERIFIED
        state["verification_result"] = {"match_percentage": 99.0}

        next_agent = supervisor.route(state)
        assert next_agent == "end"

    def test_route_verified_fail_to_review(self) -> None:
        """Test routing verified with low match to review."""
        supervisor = SupervisorAgent()
        state = create_initial_state("/test.java", "/project")
        state["phase"] = Phase.VERIFIED
        state["verification_result"] = {"match_percentage": 90.0}

        next_agent = supervisor.route(state)
        assert next_agent == "review"

    def test_should_continue(self) -> None:
        """Test should_continue logic."""
        supervisor = SupervisorAgent()

        # Should continue for in-progress phases
        state = create_initial_state("/test.java", "/project")
        state["phase"] = Phase.SCANNED
        assert supervisor.should_continue(state) is True

        # Should not continue for terminal phases
        state["phase"] = Phase.COMPLETE
        assert supervisor.should_continue(state) is False

        state["phase"] = Phase.FAILED
        assert supervisor.should_continue(state) is False

    def test_progress_percentage(self) -> None:
        """Test progress percentage calculation."""
        supervisor = SupervisorAgent()
        state = create_initial_state("/test.java", "/project")

        state["phase"] = Phase.INIT
        assert supervisor.get_progress_percentage(state) == 0

        state["phase"] = Phase.SCANNED
        assert supervisor.get_progress_percentage(state) == 20

        state["phase"] = Phase.COMPILED
        assert supervisor.get_progress_percentage(state) == 70

        state["phase"] = Phase.COMPLETE
        assert supervisor.get_progress_percentage(state) == 100
