package com.example.pages;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.AriaRole;

public class LoginPage {

    private final Page page;
    private final Locator usernameInput;
    private final Locator passwordInput;
    private final Locator loginButton;
    private final Locator errorMessage;
    private final Locator forgotPasswordLink;

    public LoginPage(Page page) {
    this.page = page;
    this.usernameInput = page.locator("#username");
    this.passwordInput = page.locator("#password");
    this.loginButton = page.locator("button[type='submit']");
    this.errorMessage = page.locator(".error-message");
    this.forgotPasswordLink = page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Forgot Password"));
    }

    // Migration: Removed WebDriverWait and clear() - Playwright's fill() auto-waits and clears automatically
    public void enterUsername(String username) {
        // Playwright auto-waits for element visibility - no explicit wait needed
        usernameInput.fill(username);
    }

    // Migration: Removed WebDriverWait and clear() - Playwright's fill() auto-waits and clears automatically
    public void enterPassword(String password) {
        // Playwright auto-waits for element visibility - no explicit wait needed
        passwordInput.fill(password);
    }

    // Migration: Removed WebDriverWait - Playwright's click() auto-waits for clickability
    public void clickLoginButton() {
        // Playwright auto-waits for element to be clickable - no explicit wait needed
        loginButton.click();
    }

    // Migration: Changed HomePage constructor to receive Page instead of WebDriver
    public HomePage login(String username, String password) {
        enterUsername(username);
        enterPassword(password);
        clickLoginButton();
        return new HomePage(page);
    }

    // Migration: Replaced getText() with textContent() and removed WebDriverWait
    public String getErrorMessage() {
        // Playwright auto-waits for element visibility - no explicit wait needed
        return errorMessage.textContent();
    }

    // Migration: Simplified logic - Playwright's isVisible() doesn't throw exceptions for non-existent elements
    public boolean isErrorDisplayed() {
        // Playwright locators don't throw exceptions for non-existent elements
        return errorMessage.isVisible();
    }

    // Migration: Removed WebDriverWait - Playwright's click() auto-waits for clickability
    public void clickForgotPassword() {
        // Playwright auto-waits for element to be clickable - no explicit wait needed
        forgotPasswordLink.click();
    }

    public boolean isLoginButtonEnabled() {
        return loginButton.isEnabled();
    }

    // Migration: Changed from driver.getTitle() to page.title()
    public String getPageTitle() {
        return page.title();
    }

    // Migration: Changed from driver.get() to page.navigate()
    public void navigateTo(String url) {
        page.navigate(url);
    }

}