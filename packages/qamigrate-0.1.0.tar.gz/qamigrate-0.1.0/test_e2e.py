"""
E2E Migration Test Script.

Tests the full migration flow on LoginPage.java.
"""

from pathlib import Path
from qamigrate.agents.scanner import ScannerAgent
from qamigrate.agents.coder import CoderAgent
from qamigrate.core.config import ScannerConfig, CoderConfig

# Step 1: Scan file
print("=" * 60)
print("Step 1: Scanning file...")
print("=" * 60)

scanner = ScannerAgent(ScannerConfig())
file_path = Path("sample-selenium-project/src/main/java/com/example/pages/LoginPage.java")
scan_result = scanner.scan_file(file_path)

print(f"  Is Page Object: {scan_result.is_page_object}")
print(f"  Is Test Class: {scan_result.is_test_class}")
print(f"  Complexity: {scan_result.complexity_score}")

# Step 2: Read original code
print()
print("=" * 60)
print("Step 2: Reading original code...")
print("=" * 60)

original_code = file_path.read_text()
print(f"  File size: {len(original_code)} bytes")
print(f"  Lines: {len(original_code.splitlines())}")

# Step 3: Generate Playwright code
print()
print("=" * 60)
print("Step 3: Generating Playwright code with AI...")
print("=" * 60)
print("  (This may take 30-60 seconds)")

coder = CoderAgent(CoderConfig())

try:
    # Use class info from scanner for generation
    class_info = {
        "class_name": "LoginPage",
        "package": "com.example.pages",
        "is_page_object": scan_result.is_page_object,
        "is_test_class": scan_result.is_test_class,
    }
    
    result = coder.generate(class_info, original_code)
    
    print(f"  Package: {result.package_name}")
    print(f"  Imports: {len(result.imports)}")
    print(f"  Fields: {len(result.fields)}")
    print(f"  Methods: {len(result.methods)}")
    
    # Assemble and save
    output_dir = Path("sample-selenium-project/src/main/java/com/example/pages/playwright")
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = coder.save_generated_code(result, output_dir)
    
    print()
    print("=" * 60)
    print("SUCCESS!")
    print("=" * 60)
    print(f"Generated: {output_path}")
    
    # Show preview
    print()
    print("Preview of generated code:")
    print("-" * 40)
    generated = output_path.read_text()
    lines = generated.splitlines()
    for line in lines[:30]:
        print(line)
    if len(lines) > 30:
        print(f"... ({len(lines) - 30} more lines)")
    
except Exception as e:
    print(f"ERROR: {e}")
    import traceback
    traceback.print_exc()

