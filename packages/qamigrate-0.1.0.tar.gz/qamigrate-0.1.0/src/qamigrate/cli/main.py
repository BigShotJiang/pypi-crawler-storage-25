"""
QAMigrate CLI Application.

Main entry point for all QAMigrate commands.
"""

from pathlib import Path
from typing import Annotated, Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

from qamigrate import __version__
from qamigrate.core.config import get_config

# Initialize Typer app
app = typer.Typer(
    name="qamigrate",
    help="QAMigrate - AI-powered test framework migration.",
    add_completion=False,
    rich_markup_mode="rich",
)

console = Console()


def version_callback(value: bool) -> None:
    """Show version and exit."""
    if value:
        console.print(f"[bold blue]QAMigrate[/] version [green]{__version__}[/]")
        raise typer.Exit()


@app.callback()
def main(
    version: Annotated[
        Optional[bool],
        typer.Option(
            "--version",
            "-v",
            help="Show version and exit.",
            callback=version_callback,
            is_eager=True,
        ),
    ] = None,
) -> None:
    """QAMigrate - AI-powered test framework migration."""
    pass


@app.command()
def init(
    project: Annotated[
        Path,
        typer.Option(
            "--project",
            "-p",
            help="Path to Selenium project root.",
            exists=True,
            file_okay=False,
            resolve_path=True,
        ),
    ] = Path("."),
    config_file: Annotated[
        Optional[Path],
        typer.Option(
            "--config",
            "-c",
            help="Path to configuration file.",
        ),
    ] = None,
) -> None:
    """
    Initialize QAMigrate in a Selenium project.

    Analyzes project structure and creates initial configuration.
    """
    console.print(
        Panel.fit(
            "[bold blue]QAMigrate[/] - Initializing project...",
            border_style="blue",
        )
    )

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("Scanning project structure...", total=None)

        # Check for build files
        pom_xml = project / "pom.xml"
        build_gradle = project / "build.gradle"

        if pom_xml.exists():
            build_tool = "maven"
            progress.update(task, description="Found pom.xml (Maven project)")
        elif build_gradle.exists():
            build_tool = "gradle"
            progress.update(task, description="Found build.gradle (Gradle project)")
        else:
            console.print(
                "[yellow]⚠️  No pom.xml or build.gradle found. "
                "Please specify build tool in config.[/]"
            )
            build_tool = "unknown"

        # Count Java files
        progress.update(task, description="Counting Java files...")
        java_files = list(project.rglob("*.java"))
        test_files = [f for f in java_files if "test" in str(f).lower()]

        progress.update(task, description="Creating configuration...")

        # Create qamigrate.yaml if it doesn't exist
        config_path = project / "qamigrate.yaml"
        if not config_path.exists():
            default_config = f"""# QAMigrate Configuration
# Generated for: {project.name}

compiler:
  build_tool: "{build_tool}"
  java_version: "17"

scanner:
  include_patterns:
    - "**/*.java"
  exclude_patterns:
    - "**/target/**"
    - "**/build/**"
"""
            config_path.write_text(default_config)
            console.print(f"[green]✓[/] Created configuration: {config_path}")

    # Display summary
    table = Table(title="Project Summary", show_header=False)
    table.add_column("Property", style="cyan")
    table.add_column("Value", style="green")
    table.add_row("Project Path", str(project))
    table.add_row("Build Tool", build_tool.capitalize())
    table.add_row("Total Java Files", str(len(java_files)))
    table.add_row("Test Files", str(len(test_files)))


    console.print(table)
    console.print("\n[bold green]✓ Project initialized![/]")
    console.print("\nNext steps:")
    console.print("  1. Run [cyan]qamigrate scan[/] to analyze your codebase")
    console.print("  2. Run [cyan]qamigrate migrate --all[/] to convert to Playwright")


@app.command()
def scan(
    project: Annotated[
        Path,
        typer.Option(
            "--project",
            "-p",
            help="Path to Selenium project root.",
            exists=True,
            file_okay=False,
            resolve_path=True,
        ),
    ] = Path("."),
    output: Annotated[
        Optional[Path],
        typer.Option(
            "--output",
            "-o",
            help="Output file for scan results (JSON).",
        ),
    ] = None,
    verbose: Annotated[
        bool,
        typer.Option(
            "--verbose",
            "-V",
            help="Show detailed scan output.",
        ),
    ] = False,
) -> None:
    """
    Scan and analyze a Selenium codebase.

    Extracts AST, detects patterns, and calculates complexity scores.
    """
    from qamigrate.agents.scanner import ScannerAgent

    console.print(
        Panel.fit(
            "[bold blue]QAMigrate[/] - Scanning project...",
            border_style="blue",
        )
    )

    config = get_config(project / "qamigrate.yaml")
    scanner = ScannerAgent(config.scanner)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("Analyzing source files...", total=None)

        try:
            result = scanner.scan_project(project)
        except Exception as e:
            console.print(f"[red]✗ Scan failed: {e}[/]")
            raise typer.Exit(1)

        progress.update(task, description="Generating report...")

    # Display results
    console.print("\n[bold]📊 Scan Results[/]\n")

    # File summary
    table = Table(title="File Analysis")
    table.add_column("Metric", style="cyan")
    table.add_column("Count", style="green", justify="right")
    table.add_row("Total Files Scanned", str(result.file_count))
    table.add_row("Page Objects", str(result.page_object_count))
    table.add_row("Test Classes", str(result.test_class_count))
    console.print(table)

    # Pattern summary
    if result.pattern_summary:
        console.print()
        pattern_table = Table(title="Detected Selenium Patterns")
        pattern_table.add_column("Pattern", style="cyan")
        pattern_table.add_column("Count", style="yellow", justify="right")
        pattern_table.add_column("Complexity", style="magenta", justify="right")

        for pattern_name, count in sorted(
            result.pattern_summary.items(), key=lambda x: x[1], reverse=True
        ):
            pattern_table.add_row(pattern_name, str(count), "⭐" * min(count // 10 + 1, 5))

        console.print(pattern_table)

    # Complexity distribution
    console.print()
    complexity_table = Table(title="Complexity Distribution")
    complexity_table.add_column("Level", style="cyan")
    complexity_table.add_column("Files", style="green", justify="right")
    complexity_table.add_row("Low (1-3)", str(result.complexity_distribution.get("low", 0)))
    complexity_table.add_row("Medium (4-6)", str(result.complexity_distribution.get("medium", 0)))
    complexity_table.add_row("High (7-10)", str(result.complexity_distribution.get("high", 0)))
    console.print(complexity_table)

    # Save output if requested
    if output:
        import json

        output.write_text(json.dumps(result.to_dict(), indent=2))
        console.print(f"\n[green]✓[/] Results saved to: {output}")

    console.print("\n[bold green]✓ Scan complete![/]")
    console.print(f"\nRun [cyan]qamigrate migrate --all[/] to start migration")


@app.command()
def migrate(
    file: Annotated[
        Optional[Path],
        typer.Argument(
            help="Specific Java file to migrate.",
        ),
    ] = None,
    all_files: Annotated[
        bool,
        typer.Option(
            "--all",
            "-a",
            help="Migrate all files in the project.",
        ),
    ] = False,
    project: Annotated[
        Path,
        typer.Option(
            "--project",
            "-p",
            help="Path to Selenium project root.",
            exists=True,
            file_okay=False,
            resolve_path=True,
        ),
    ] = Path("."),
    dry_run: Annotated[
        bool,
        typer.Option(
            "--dry-run",
            help="Show what would be migrated without making changes.",
        ),
    ] = False,
    interactive: Annotated[
        bool,
        typer.Option(
            "--interactive",
            "-i",
            help="Run in interactive mode with file selection.",
        ),
    ] = False,
) -> None:
    """
    Migrate Selenium test files to Playwright.

    Specify a single file or use --all to migrate the entire project.
    Use --interactive for guided file selection.
    """
    # Interactive mode
    if interactive:
        from qamigrate.cli.interactive import interactive_migrate
        from qamigrate.agents.pipeline import run_migration

        config = get_config(project / "qamigrate.yaml")

        def migrate_fn(file_path: Path, proj_path: Path):
            result = run_migration(file_path=file_path, project_path=proj_path, config=config)
            return result.success, result.error, result.output_path
        
        interactive_migrate(project, migrate_fn)
        return
    
    if not file and not all_files:
        console.print("[red]✗ Please specify a file, use --all, or try --interactive[/]")
        raise typer.Exit(1)

    console.print(
        Panel.fit(
            "[bold blue]QAMigrate[/] - Starting migration...",
            border_style="blue",
        )
    )

    if dry_run:
        console.print("[yellow]🔍 Dry run mode - no changes will be made[/]\n")

    from qamigrate.agents.pipeline import run_migration
    import time

    config = get_config(project / "qamigrate.yaml")
    start_time = time.time()

    if all_files:
        # Get all Java files with dependency ordering
        from qamigrate.core.dependencies import DependencyAnalyzer
        
        analyzer = DependencyAnalyzer()
        analyzer.analyze_project(project)
        
        # Get files in dependency order (base classes first)
        java_files = analyzer.get_compilation_order()
        
        # Filter out already migrated files
        java_files = [
            f for f in java_files
            if not any(exc in str(f) for exc in ["target", "build", "node_modules", "playwright"])
        ]
        
        console.print(f"Found [cyan]{len(java_files)}[/] files to migrate")
        console.print(f"[dim]Ordered by dependencies (base classes first)[/]\n")
    else:
        java_files = [file] if file else []

    success_count = 0
    failed_count = 0

    for java_file in java_files:
        file_start = time.time()
        try:
            console.print(f"[cyan]→[/] Migrating: {java_file.name}")

            if not dry_run:
                result = run_migration(
                    file_path=java_file,
                    project_path=project,
                    config=config,
                )

                file_time = time.time() - file_start
                if result.success:
                    console.print(f"  [green]✓[/] Success: {result.output_path} [dim]({file_time:.1f}s)[/]")
                    success_count += 1
                else:
                    console.print(f"  [red]✗[/] Failed: {result.error} [dim]({file_time:.1f}s)[/]")
                    failed_count += 1
            else:
                console.print(f"  [dim]Would migrate to Playwright[/]")
                success_count += 1

        except Exception as e:
            file_time = time.time() - file_start
            console.print(f"  [red]✗[/] Error: {e} [dim]({file_time:.1f}s)[/]")
            failed_count += 1

    total_time = time.time() - start_time
    console.print()
    console.print(f"[bold]Migration Complete[/] [dim]({total_time:.1f}s total)[/]")
    console.print(f"  [green]✓ Success:[/] {success_count}")
    console.print(f"  [red]✗ Failed:[/] {failed_count}")


@app.command()
def verify(
    test_class: Annotated[
        str,
        typer.Argument(
            help="Test class name to verify.",
        ),
    ],
    project: Annotated[
        Path,
        typer.Option(
            "--project",
            "-p",
            help="Path to project root.",
            exists=True,
            file_okay=False,
            resolve_path=True,
        ),
    ] = Path("."),
    app_url: Annotated[
        str,
        typer.Option(
            "--url",
            "-u",
            help="Application URL for test execution.",
        ),
    ] = "http://localhost:8080",
    record: Annotated[
        bool,
        typer.Option(
            "--record",
            "-r",
            help="Record video of test execution.",
        ),
    ] = True,
) -> None:
    """
    Run Blue-Green verification for a migrated test.

    Executes both Selenium and Playwright versions and compares results.
    """
    console.print(
        Panel.fit(
            "[bold blue]QAMigrate[/] - Blue-Green Verification",
            border_style="blue",
        )
    )

    console.print(f"\n[cyan]Test Class:[/] {test_class}")
    console.print(f"[cyan]App URL:[/] {app_url}")
    console.print(f"[cyan]Recording:[/] {'Enabled' if record else 'Disabled'}\n")

    from qamigrate.agents.visual import VisualAgent

    config = get_config(project / "qamigrate.yaml")
    visual = VisualAgent(config.visual)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("Starting Docker containers...", total=None)

        try:
            progress.update(task, description="Running Selenium test...")
            progress.update(task, description="Running Playwright test...")
            progress.update(task, description="Comparing results...")

            result = visual.verify(
                test_class=test_class,
                project_path=project,
                app_url=app_url,
                record=record,
            )

        except Exception as e:
            console.print(f"\n[red]✗ Verification failed: {e}[/]")
            raise typer.Exit(1)

    # Display results
    console.print("\n[bold]🔍 Verification Results[/]\n")

    table = Table(show_header=False)
    table.add_column("Metric", style="cyan")
    table.add_column("Value", style="green")

    match_color = "green" if result.match_percentage >= 98 else "yellow" if result.match_percentage >= 90 else "red"
    table.add_row("Visual Match", f"[{match_color}]{result.match_percentage:.1f}%[/]")
    table.add_row("DOM Match", "✓" if result.dom_match else "✗")
    table.add_row("Assertion Match", "✓" if result.assertion_match else "✗")
    table.add_row("Performance", f"{result.performance_improvement:.1f}x faster")

    console.print(table)

    if result.match_percentage >= 98:
        console.print("\n[bold green]✓ Verification PASSED![/]")
    else:
        console.print("\n[bold yellow]⚠️  Verification needs review[/]")
        console.print(f"See diff report: {result.artifacts.get('diff_report', 'N/A')}")


@app.command()
def dashboard(
    host: Annotated[
        str,
        typer.Option(
            "--host",
            "-h",
            help="Host to bind the server to.",
        ),
    ] = "127.0.0.1",
    port: Annotated[
        int,
        typer.Option(
            "--port",
            "-P",
            help="Port to run the server on.",
        ),
    ] = 3000,
) -> None:
    """
    Launch the QAMigrate web dashboard.

    Opens a browser to the dashboard UI at http://localhost:3000
    """
    console.print(
        Panel.fit(
            "[bold blue]QAMigrate[/] - Dashboard",
            border_style="blue",
        )
    )

    console.print(f"\n🚀 Starting server at [cyan]http://{host}:{port}[/]\n")

    from qamigrate.server.app import create_app

    import uvicorn

    app = create_app()
    uvicorn.run(app, host=host, port=port, log_level="info")


@app.command()
def export(
    project: Annotated[
        Path,
        typer.Option(
            "--project",
            "-p",
            help="Path to project root.",
            exists=True,
            file_okay=False,
            resolve_path=True,
        ),
    ] = Path("."),
    format: Annotated[
        str,
        typer.Option(
            "--format",
            "-f",
            help="Export format: zip or report",
        ),
    ] = "zip",
    output: Annotated[
        Optional[Path],
        typer.Option(
            "--output",
            "-o",
            help="Output file path.",
        ),
    ] = None,
) -> None:
    """
    Export migration results.

    Creates a ZIP archive of migrated files or a detailed report.
    """
    console.print(
        Panel.fit(
            "[bold blue]QAMigrate[/] - Export",
            border_style="blue",
        )
    )

    config = get_config(project / "qamigrate.yaml")
    output_dir = Path(config.artifacts.output_dir)

    if not output_dir.exists():
        console.print("[red]✗ No migration output found. Run migrate first.[/]")
        raise typer.Exit(1)

    if format == "zip":
        import shutil

        output_path = output or (project / "qamigrate-export.zip")
        shutil.make_archive(str(output_path.with_suffix("")), "zip", output_dir)
        console.print(f"[green]✓[/] Exported to: {output_path}")

    elif format == "report":
        from qamigrate.core.reports import ReportGenerator, MigrationStats
        from qamigrate.core.database import get_database

        output_path = output or (project / "qamigrate-report.html")
        
        # Get migration data from database
        db = get_database(project)
        migrations = db.get_migrations()
        
        # Build stats
        stats = MigrationStats(
            total_files=len(migrations),
            success_count=sum(1 for m in migrations if m.get("status") == "completed"),
            failed_count=sum(1 for m in migrations if m.get("status") == "failed"),
            total_time_seconds=sum(m.get("compile_time_ms", 0) / 1000 for m in migrations),
            patterns_detected=sum(m.get("patterns_found", 0) for m in migrations),
            files=[
                {
                    "name": m.get("source_path", "").split("/")[-1],
                    "success": m.get("status") == "completed",
                    "patterns": m.get("patterns_found", 0),
                    "lines": m.get("lines", 0),
                    "time": m.get("compile_time_ms", 0) / 1000,
                }
                for m in migrations
            ],
        )
        
        # Generate report
        generator = ReportGenerator()
        generator.generate_html(stats, output_path)
        console.print(f"[green]✓[/] Report saved to: {output_path}")

    elif format == "json":
        from qamigrate.core.reports import ReportGenerator, MigrationStats
        from qamigrate.core.database import get_database

        output_path = output or (project / "qamigrate-report.json")
        
        db = get_database(project)
        migrations = db.get_migrations()
        
        stats = MigrationStats(
            total_files=len(migrations),
            success_count=sum(1 for m in migrations if m.get("status") == "completed"),
            failed_count=sum(1 for m in migrations if m.get("status") == "failed"),
            files=[
                {
                    "name": m.get("source_path", "").split("/")[-1],
                    "success": m.get("status") == "completed",
                    "patterns": m.get("patterns_found", 0),
                    "time": m.get("compile_time_ms", 0) / 1000,
                }
                for m in migrations
            ],
        )
        
        generator = ReportGenerator()
        generator.generate_json(stats, output_path)
        console.print(f"[green]✓[/] JSON report saved to: {output_path}")

    else:
        console.print(f"[red]✗ Unknown format: {format}[/]")
        raise typer.Exit(1)


if __name__ == "__main__":
    app()
