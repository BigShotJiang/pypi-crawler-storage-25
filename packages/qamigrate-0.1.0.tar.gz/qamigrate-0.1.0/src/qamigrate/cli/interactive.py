"""
Interactive CLI Mode.

Provides interactive prompts for migration selection and configuration.
Uses InquirerPy for rich terminal UI.
"""

from pathlib import Path
from typing import Callable

import structlog
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
from rich.table import Table

logger = structlog.get_logger(__name__)
console = Console()


def interactive_migrate(
    project_path: Path,
    migrate_fn: Callable[[Path, Path], tuple[bool, str | None, Path | None]],
) -> None:
    """
    Run migration in interactive mode with prompts.

    Args:
        project_path: Project root path
        migrate_fn: Migration function
    """
    try:
        from InquirerPy import inquirer
        from InquirerPy.base.control import Choice
    except ImportError:
        console.print(
            "[yellow]Interactive mode requires InquirerPy. Install with:[/]\n"
            "  pip install InquirerPy"
        )
        return

    console.print(
        Panel.fit(
            "[bold blue]🚀 QAMigrate Interactive Mode[/]",
            border_style="blue",
        )
    )

    # Find Java files
    java_files = list(project_path.rglob("*.java"))
    java_files = [
        f for f in java_files
        if not any(exc in str(f) for exc in ["target", "build", "node_modules", "playwright"])
    ]

    if not java_files:
        console.print("[red]No Java files found in project[/]")
        return

    # Categorize files
    test_files = [f for f in java_files if "test" in str(f).lower()]
    page_files = [f for f in java_files if "page" in str(f).lower()]
    other_files = [f for f in java_files if f not in test_files and f not in page_files]

    console.print(f"\n📁 Found [cyan]{len(java_files)}[/] Java files:")
    console.print(f"   • Test classes: {len(test_files)}")
    console.print(f"   • Page objects: {len(page_files)}")
    console.print(f"   • Other files: {len(other_files)}\n")

    # Migration mode selection
    mode = inquirer.select(
        message="What would you like to migrate?",
        choices=[
            Choice(value="all", name="🌐 All files (full project migration)"),
            Choice(value="tests", name="🧪 Test classes only"),
            Choice(value="pages", name="📄 Page objects only"),
            Choice(value="select", name="✨ Select specific files"),
        ],
        default="all",
    ).execute()

    # Get files to migrate
    if mode == "all":
        selected_files = java_files
    elif mode == "tests":
        selected_files = test_files
    elif mode == "pages":
        selected_files = page_files
    else:
        # Interactive file selection
        choices = [
            Choice(value=f, name=f"  {f.relative_to(project_path)}")
            for f in java_files
        ]
        selected_files = inquirer.checkbox(
            message="Select files to migrate (space to select, enter to confirm):",
            choices=choices,
            validate=lambda result: len(result) > 0,
            invalid_message="Select at least one file",
        ).execute()

    if not selected_files:
        console.print("[yellow]No files selected[/]")
        return

    console.print(f"\n📋 Selected [cyan]{len(selected_files)}[/] files for migration\n")

    # Confirm
    confirm = inquirer.confirm(
        message=f"Proceed with migration of {len(selected_files)} files?",
        default=True,
    ).execute()

    if not confirm:
        console.print("[yellow]Migration cancelled[/]")
        return

    # Run migration with progress
    success_count = 0
    failed_count = 0
    failed_files = []

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        console=console,
    ) as progress:
        task = progress.add_task("Migrating...", total=len(selected_files))

        for file in selected_files:
            progress.update(task, description=f"Migrating {file.name}...")

            try:
                success, error, output_path = migrate_fn(file, project_path)

                if success:
                    success_count += 1
                else:
                    failed_count += 1
                    failed_files.append({"file": file.name, "error": error})
            except Exception as e:
                failed_count += 1
                failed_files.append({"file": file.name, "error": str(e)})

            progress.advance(task)

    # Show results
    console.print()
    console.print(
        Panel(
            f"[bold]Migration Complete[/]\n\n"
            f"  [green]✓ Success:[/] {success_count}\n"
            f"  [red]✗ Failed:[/]  {failed_count}",
            border_style="green" if failed_count == 0 else "yellow",
        )
    )

    # Show failed files table
    if failed_files:
        console.print()
        table = Table(title="Failed Migrations", show_header=True)
        table.add_column("File", style="cyan")
        table.add_column("Error", style="red")

        for f in failed_files[:5]:  # Show first 5
            table.add_row(f["file"], str(f["error"])[:50] + "...")

        console.print(table)

        if len(failed_files) > 5:
            console.print(f"  [dim]... and {len(failed_files) - 5} more[/]")


def interactive_scan(project_path: Path) -> None:
    """Run interactive project scan."""
    try:
        from InquirerPy import inquirer
    except ImportError:
        console.print("[yellow]Interactive mode requires InquirerPy[/]")
        return

    console.print(
        Panel.fit(
            "[bold blue]🔍 QAMigrate Project Scanner[/]",
            border_style="blue",
        )
    )

    from qamigrate.agents.scanner import ScannerAgent
    from qamigrate.core.config import ScannerConfig

    scanner = ScannerAgent(ScannerConfig())

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("Scanning project...", total=None)
        result = scanner.scan(project_path)
        progress.update(task, description="Scan complete!")

    # Display results
    console.print()
    table = Table(title="Scan Results", show_header=False)
    table.add_column("Metric", style="cyan")
    table.add_column("Value", style="green")

    table.add_row("Total Files", str(result.total_files))
    table.add_row("Test Classes", str(result.test_classes))
    table.add_row("Page Objects", str(result.page_objects))
    table.add_row("Patterns Found", str(len(result.patterns)))

    console.print(table)

    # Ask if user wants to see details
    if result.patterns:
        show_patterns = inquirer.confirm(
            message="Show detected Selenium patterns?",
            default=False,
        ).execute()

        if show_patterns:
            patterns_table = Table(title="Detected Patterns")
            patterns_table.add_column("Pattern", style="cyan")
            patterns_table.add_column("Count", justify="right", style="green")

            pattern_counts: dict[str, int] = {}
            for p in result.patterns:
                pattern_counts[p.name] = pattern_counts.get(p.name, 0) + 1

            for name, count in sorted(pattern_counts.items(), key=lambda x: -x[1])[:10]:
                patterns_table.add_row(name, str(count))

            console.print(patterns_table)


def show_welcome() -> None:
    """Show interactive welcome screen."""
    console.print()
    console.print(
        Panel(
            "[bold blue]🚀 QAMigrate[/]\n\n"
            "[dim]AI-Powered Selenium to Playwright Migration[/]\n\n"
            "Commands:\n"
            "  [cyan]migrate[/]    - Migrate Selenium tests\n"
            "  [cyan]scan[/]       - Analyze project\n"
            "  [cyan]verify[/]     - Blue-green verification\n"
            "  [cyan]dashboard[/]  - Launch web UI\n",
            border_style="blue",
            title="Welcome",
            subtitle="v1.0.0",
        )
    )
