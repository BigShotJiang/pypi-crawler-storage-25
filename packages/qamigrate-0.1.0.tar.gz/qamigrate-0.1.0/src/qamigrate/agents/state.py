"""
Migration State Schema.

Defines the shared state object used by all agents in the migration pipeline.
"""

from datetime import datetime
from enum import Enum
from typing import Any, TypedDict


class Phase(str, Enum):
    """Migration pipeline phases."""

    INIT = "init"
    SCANNED = "scanned"
    GENERATED = "generated"
    COMPILATION_FAILED = "compilation_failed"
    FIXED = "fixed"
    COMPILED = "compiled"
    VERIFIED = "verified"
    REVIEW = "review"
    FAILED = "failed"
    COMPLETE = "complete"


class CompilerErrorDict(TypedDict):
    """Structured representation of a compilation error."""

    file_path: str
    line_number: int
    column: int
    error_type: str
    message: str
    code_context: str


class VerificationResultDict(TypedDict):
    """Verification result data."""

    match_percentage: float
    dom_match: bool
    assertion_match: bool
    performance_improvement: float


class MigrationState(TypedDict, total=False):
    """Shared state object for the migration pipeline."""

    # Identification
    file_path: str
    project_path: str
    output_path: str

    # Phase tracking
    phase: Phase

    # Scanner outputs
    ast_data: dict[str, Any] | None
    patterns: list[dict[str, Any]]
    dependency_graph: dict[str, list[str]]
    complexity_score: int

    # UTOM representation
    utom_json: dict[str, Any] | None

    # Original source
    original_code: str

    # Generated code
    generated_code: str | None
    generated_file_path: str | None

    # Compilation tracking
    compilation_result: dict[str, Any] | None
    compilation_errors: list[CompilerErrorDict]
    retry_count: int

    # Fix tracking
    fix_changes: list[str]

    # Verification results
    verification_result: VerificationResultDict | None

    # Artifacts (paths to videos, screenshots, reports)
    artifacts: dict[str, str]

    # Error log
    errors: list[dict[str, Any]]

    # Timestamps
    started_at: str
    updated_at: str


def create_initial_state(
    file_path: str,
    project_path: str,
) -> MigrationState:
    """Create initial migration state for a file."""
    now = datetime.utcnow().isoformat()

    return MigrationState(
        file_path=file_path,
        project_path=project_path,
        output_path="",
        phase=Phase.INIT,
        ast_data=None,
        patterns=[],
        dependency_graph={},
        complexity_score=0,
        utom_json=None,
        original_code="",
        generated_code=None,
        generated_file_path=None,
        compilation_result=None,
        compilation_errors=[],
        retry_count=0,
        fix_changes=[],
        verification_result=None,
        artifacts={},
        errors=[],
        started_at=now,
        updated_at=now,
    )


def update_state_timestamp(state: MigrationState) -> MigrationState:
    """Update the state's updated_at timestamp."""
    state["updated_at"] = datetime.utcnow().isoformat()
    return state


def add_error_to_state(
    state: MigrationState,
    error_type: str,
    message: str,
    phase: Phase | None = None,
) -> MigrationState:
    """Add an error to the state's error log."""
    state["errors"].append(
        {
            "phase": (phase or state.get("phase", Phase.INIT)).value,
            "error_type": error_type,
            "message": message,
            "timestamp": datetime.utcnow().isoformat(),
        }
    )
    return update_state_timestamp(state)
