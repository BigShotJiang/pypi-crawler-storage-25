"""
Supervisor Agent.

Central orchestrator that manages workflow routing, state transitions,
and exception handling across all worker agents.
"""

from typing import Literal

from qamigrate.agents.state import MigrationState, Phase
from qamigrate.core.config import SupervisorConfig


class SupervisorAgent:
    """
    Orchestrates the migration pipeline using rule-based routing.

    No LLM required - uses deterministic state evaluation.
    """

    def __init__(self, config: SupervisorConfig | None = None) -> None:
        """Initialize supervisor with configuration."""
        self.config = config or SupervisorConfig()
        self.max_retries = self.config.max_retries
        self.quality_gates = self.config.quality_gates

    def route(
        self, state: MigrationState
    ) -> Literal["scanner", "coder", "compiler", "fixer", "visual", "review", "failed", "end"]:
        """
        Determine next agent based on current state.

        Returns agent name or terminal state.

        Routing Logic:
        - init -> scanner
        - scanned (with ast_data) -> coder
        - generated (with code) -> compiler
        - compilation_failed (retry < max) -> fixer
        - compilation_failed (retry >= max) -> failed
        - fixed -> compiler
        - compiled -> visual
        - verified (match >= threshold) -> end
        - verified (match < threshold) -> review
        """
        phase = state.get("phase", Phase.INIT)

        # Initial state - start with scanning
        if phase == Phase.INIT:
            return "scanner"

        # After scanning - proceed to code generation
        if phase == Phase.SCANNED and state.get("ast_data"):
            return "coder"

        # After code generation - validate compilation
        if phase == Phase.GENERATED and state.get("generated_code"):
            return "compiler"

        # Compilation failed - route to fixer or fail
        if phase == Phase.COMPILATION_FAILED:
            retry_count = state.get("retry_count", 0)
            if retry_count < self.max_retries:
                return "fixer"
            else:
                return "failed"

        # After fix attempt - retry compilation
        if phase == Phase.FIXED:
            return "compiler"

        # Compilation succeeded - proceed to verification
        if phase == Phase.COMPILED:
            # Skip visual verification if not required
            if not self.quality_gates.get("visual_required", True):
                return "end"
            return "visual"

        # Visual verification complete
        if phase == Phase.VERIFIED:
            verification = state.get("verification_result")
            if verification:
                threshold = self.quality_gates.get("visual_threshold", 98.0)
                if verification.get("match_percentage", 0) >= threshold:
                    return "end"
                else:
                    return "review"
            return "end"

        # Already complete
        if phase == Phase.COMPLETE:
            return "end"

        # Already failed
        if phase == Phase.FAILED:
            return "failed"

        # Fallback - unknown state
        return "failed"

    def should_continue(self, state: MigrationState) -> bool:
        """Check if the pipeline should continue processing."""
        phase = state.get("phase", Phase.INIT)
        terminal_phases = {Phase.COMPLETE, Phase.FAILED, Phase.REVIEW}
        return phase not in terminal_phases

    def get_progress_percentage(self, state: MigrationState) -> int:
        """Calculate approximate progress percentage."""
        phase = state.get("phase", Phase.INIT)
        progress_map = {
            Phase.INIT: 0,
            Phase.SCANNED: 20,
            Phase.GENERATED: 40,
            Phase.COMPILATION_FAILED: 50,
            Phase.FIXED: 55,
            Phase.COMPILED: 70,
            Phase.VERIFIED: 90,
            Phase.REVIEW: 95,
            Phase.COMPLETE: 100,
            Phase.FAILED: 100,
        }
        return progress_map.get(phase, 0)
