"""
Migration Pipeline.

Plain Python pipeline that runs the migration workflow:
Scanner -> Coder -> Compiler -> Fixer (retry loop) -> Done.

Replaces the LangGraph-based graph.py with a simple, debuggable flow.
"""

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Callable

import structlog

from qamigrate.agents.coder import CoderAgent
from qamigrate.agents.compiler import CompilerAgent, CompilerError, ErrorType
from qamigrate.agents.fixer import FixerAgent
from qamigrate.agents.scanner import ScannerAgent
from qamigrate.agents.state import MigrationState, Phase, create_initial_state
from qamigrate.core.config import QAMigrateConfig

logger = structlog.get_logger(__name__)


@dataclass
class MigrationResult:
    """Result of a migration run."""

    success: bool
    file_path: str
    output_path: str | None
    error: str | None
    compilation_attempts: int
    final_state: MigrationState


def run_migration(
    file_path: Path,
    project_path: Path,
    config: QAMigrateConfig | None = None,
    on_phase: Callable[[Phase, MigrationState], None] | None = None,
) -> MigrationResult:
    """
    Run the migration pipeline for a single file.

    Pipeline: Scanner -> Coder -> Compiler -> (Fixer -> Compiler)* -> Done

    Args:
        file_path: Path to the Java file to migrate
        project_path: Root path of the project
        config: Optional configuration
        on_phase: Optional callback fired on each phase transition

    Returns:
        MigrationResult with outcome
    """
    config = config or QAMigrateConfig()
    max_retries = config.supervisor.max_retries

    # Initialize agents
    scanner = ScannerAgent(config.scanner)
    coder = CoderAgent(config.coder)
    compiler = CompilerAgent(config.compiler)
    fixer = FixerAgent(config.fixer)

    # Create initial state
    state = create_initial_state(
        file_path=str(file_path),
        project_path=str(project_path),
    )

    def _notify(phase: Phase) -> None:
        state["phase"] = phase
        state["updated_at"] = datetime.utcnow().isoformat()
        if on_phase:
            on_phase(phase, state)

    try:
        # --- SCAN ---
        logger.info("Pipeline: scanning", file=str(file_path))
        _notify(Phase.INIT)

        analysis = scanner.scan_file(file_path)
        state["ast_data"] = analysis.class_info
        state["patterns"] = [
            {
                "pattern_type": p.pattern_type,
                "line_number": p.line_number,
                "migration_strategy": p.migration_strategy,
            }
            for p in analysis.patterns
        ]
        state["complexity_score"] = analysis.complexity_score
        state["original_code"] = file_path.read_text(encoding="utf-8")
        _notify(Phase.SCANNED)

        # --- GENERATE ---
        logger.info("Pipeline: generating Playwright code", file=str(file_path))

        result = coder.generate_from_class_info(
            class_info=state["ast_data"] or {},
            original_code=state["original_code"],
            patterns=state["patterns"],
        )
        generated_code = coder.assemble_file(result)

        output_path = file_path.parent / "playwright" / file_path.name
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(generated_code, encoding="utf-8")

        state["generated_code"] = generated_code
        state["generated_file_path"] = str(output_path)
        state["output_path"] = str(output_path)
        _notify(Phase.GENERATED)

        # --- SKIP COMPILATION IF CONFIGURED ---
        if config.compiler.skip:
            logger.info(
                "Pipeline: compilation skipped (compiler.skip=true)",
                file=str(file_path),
                output=str(output_path),
            )
            _notify(Phase.COMPILED)
            return MigrationResult(
                success=True,
                file_path=str(file_path),
                output_path=str(output_path),
                error=None,
                compilation_attempts=0,
                final_state=state,
            )

        # --- COMPILE + FIX LOOP ---
        for attempt in range(max_retries + 1):
            logger.info(
                "Pipeline: compiling",
                file=str(output_path),
                attempt=attempt + 1,
            )

            compile_result = compiler.compile_single_file(output_path)

            if compile_result.success:
                state["compilation_result"] = compile_result.to_dict()
                state["compilation_errors"] = []
                state["retry_count"] = attempt
                _notify(Phase.COMPILED)
                break

            # Compilation failed
            state["compilation_result"] = compile_result.to_dict()
            state["compilation_errors"] = [e.to_dict() for e in compile_result.errors]
            state["retry_count"] = attempt + 1
            _notify(Phase.COMPILATION_FAILED)

            if attempt >= max_retries:
                logger.warning(
                    "Pipeline: max retries reached",
                    file=str(file_path),
                    attempts=attempt + 1,
                )
                _notify(Phase.FAILED)
                return MigrationResult(
                    success=False,
                    file_path=str(file_path),
                    output_path=str(output_path),
                    error=f"Compilation failed after {attempt + 1} attempts",
                    compilation_attempts=attempt + 1,
                    final_state=state,
                )

            # --- FIX ---
            logger.info(
                "Pipeline: fixing errors",
                error_count=len(compile_result.errors),
                attempt=attempt + 1,
            )

            errors = []
            for e in state.get("compilation_errors", []):
                error_type_str = e.get("error_type", "unknown")
                try:
                    error_type = ErrorType(error_type_str)
                except ValueError:
                    error_type = ErrorType.UNKNOWN

                errors.append(CompilerError(
                    file_path=e["file_path"],
                    line_number=e["line_number"],
                    column=e["column"],
                    error_type=error_type,
                    message=e["message"],
                    code_context=e.get("code_context", ""),
                ))

            fixed_code, changes = fixer.fix(
                code=state["generated_code"] or "",
                errors=errors,
                retry_count=attempt,
            )

            output_path.write_text(fixed_code, encoding="utf-8")
            state["generated_code"] = fixed_code
            state["fix_changes"] = state.get("fix_changes", []) + changes
            _notify(Phase.FIXED)

        # If we got here via break (compilation succeeded)
        if state["phase"] == Phase.COMPILED:
            logger.info(
                "Pipeline: migration successful",
                file=str(file_path),
                output=str(output_path),
                attempts=state.get("retry_count", 0) + 1,
            )
            return MigrationResult(
                success=True,
                file_path=str(file_path),
                output_path=str(output_path),
                error=None,
                compilation_attempts=state.get("retry_count", 0),
                final_state=state,
            )

        # Should not reach here, but handle gracefully
        return MigrationResult(
            success=False,
            file_path=str(file_path),
            output_path=state.get("output_path"),
            error="Pipeline ended in unexpected state",
            compilation_attempts=state.get("retry_count", 0),
            final_state=state,
        )

    except Exception as e:
        logger.error("Pipeline: migration failed", error=str(e), file=str(file_path))
        state["phase"] = Phase.FAILED
        state["errors"].append({
            "phase": state.get("phase", Phase.INIT).value if isinstance(state.get("phase"), Phase) else "init",
            "error_type": type(e).__name__,
            "message": str(e),
            "timestamp": datetime.utcnow().isoformat(),
        })
        return MigrationResult(
            success=False,
            file_path=str(file_path),
            output_path=state.get("output_path"),
            error=str(e),
            compilation_attempts=state.get("retry_count", 0),
            final_state=state,
        )


def run_batch_migration(
    files: list[Path],
    project_path: Path,
    config: QAMigrateConfig | None = None,
    on_progress: Callable[[int, int, MigrationResult], None] | None = None,
) -> list[MigrationResult]:
    """
    Run migration for multiple files.

    Args:
        files: List of Java files to migrate
        project_path: Root path of the project
        config: Optional configuration
        on_progress: Optional callback for progress updates

    Returns:
        List of MigrationResult for each file
    """
    results: list[MigrationResult] = []

    for i, file_path in enumerate(files):
        logger.info(f"Migrating file {i + 1}/{len(files)}", file=str(file_path))

        result = run_migration(file_path, project_path, config)
        results.append(result)

        if on_progress:
            on_progress(i + 1, len(files), result)

    success_count = sum(1 for r in results if r.success)
    logger.info(
        "Batch migration complete",
        total=len(files),
        success=success_count,
        failed=len(files) - success_count,
    )

    return results
