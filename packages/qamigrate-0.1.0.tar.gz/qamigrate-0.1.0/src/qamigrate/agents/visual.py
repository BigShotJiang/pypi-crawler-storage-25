"""
Visual Agent.

Verifies behavioral equivalence through video comparison and visual diff analysis.
Coordinates Docker-based parallel test execution.
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import structlog

from qamigrate.core.config import VisualConfig

logger = structlog.get_logger(__name__)


@dataclass
class VerificationResult:
    """Result of visual verification between Selenium and Playwright runs."""

    match_percentage: float
    dom_match: bool
    assertion_match: bool
    performance_improvement: float
    frame_diffs: list[dict[str, Any]] = field(default_factory=list)
    artifacts: dict[str, str] = field(default_factory=dict)
    selenium_time_ms: int = 0
    playwright_time_ms: int = 0


class VisualAgent:
    """
    Visual verification using container-based execution.

    Coordinates Docker containers for parallel test execution
    and uses computer vision for frame comparison.
    """

    SELENIUM_IMAGE = "selenium/standalone-chrome:4.15.0"
    PLAYWRIGHT_IMAGE = "mcr.microsoft.com/playwright/java:v1.40.0"

    def __init__(self, config: VisualConfig | None = None) -> None:
        """Initialize visual agent with configuration."""
        self.config = config or VisualConfig()
        self.match_threshold = self.config.match_threshold
        self.capture_video = self.config.capture_video
        self.docker_client = None

    def _ensure_docker(self) -> None:
        """Ensure Docker client is initialized."""
        if self.docker_client is None:
            try:
                import docker

                self.docker_client = docker.from_env()
                logger.info("Docker client initialized")
            except Exception as e:
                logger.error("Failed to initialize Docker", error=str(e))
                raise RuntimeError(f"Docker not available: {e}")

    def verify(
        self,
        test_class: str,
        project_path: Path,
        app_url: str = "http://localhost:8080",
        record: bool = True,
    ) -> VerificationResult:
        """
        Execute tests in parallel and compare results.

        Args:
            test_class: Name of the test class to verify
            project_path: Root path of the project
            app_url: URL of the application under test
            record: Whether to record video

        Returns:
            VerificationResult with comparison data
        """
        logger.info(
            "Starting verification",
            test_class=test_class,
            app_url=app_url,
        )

        self._ensure_docker()

        # For now, return a mock result
        # Full Docker implementation would go here
        return self._mock_verification(test_class, project_path)

    def verify_files(
        self,
        selenium_test: Path,
        playwright_test: Path,
        app_url: str = "http://localhost:8080",
    ) -> VerificationResult:
        """
        Verify specific test files.

        Args:
            selenium_test: Path to Selenium test file
            playwright_test: Path to Playwright test file
            app_url: URL of the application under test

        Returns:
            VerificationResult
        """
        self._ensure_docker()

        try:
            # Start containers
            selenium_container = self._start_selenium_container(selenium_test, app_url)
            playwright_container = self._start_playwright_container(playwright_test, app_url)

            try:
                # Execute tests with video capture
                selenium_result = self._execute_with_capture(selenium_container, "selenium")
                playwright_result = self._execute_with_capture(playwright_container, "playwright")

                # Compare results
                return self._compare_executions(selenium_result, playwright_result)

            finally:
                # Cleanup containers
                self._stop_container(selenium_container)
                self._stop_container(playwright_container)

        except Exception as e:
            logger.error("Verification failed", error=str(e))
            raise

    def _start_selenium_container(self, test_file: Path, app_url: str) -> Any:
        """Start Selenium container with test mounted."""
        logger.info("Starting Selenium container")

        container = self.docker_client.containers.run(
            self.SELENIUM_IMAGE,
            detach=True,
            auto_remove=True,
            environment={
                "APP_URL": app_url,
            },
            volumes={
                str(test_file.parent): {"bind": "/tests", "mode": "ro"},
            },
            network_mode="host",  # Access localhost services
        )

        return container

    def _start_playwright_container(self, test_file: Path, app_url: str) -> Any:
        """Start Playwright container with test mounted."""
        logger.info("Starting Playwright container")

        container = self.docker_client.containers.run(
            self.PLAYWRIGHT_IMAGE,
            detach=True,
            auto_remove=True,
            environment={
                "APP_URL": app_url,
            },
            volumes={
                str(test_file.parent): {"bind": "/tests", "mode": "ro"},
            },
            network_mode="host",
        )

        return container

    def _execute_with_capture(self, container: Any, name: str) -> dict[str, Any]:
        """Execute test with video capture."""
        logger.info(f"Executing {name} test")

        # Run the test
        exit_code, output = container.exec_run("mvn test -q")

        return {
            "name": name,
            "exit_code": exit_code,
            "output": output.decode("utf-8") if output else "",
            "execution_time_ms": 0,  # Would be calculated from timing
            "assertions": [],
            "video_path": None,
            "final_screenshot": None,
            "dom_snapshot": None,
        }

    def _stop_container(self, container: Any) -> None:
        """Stop and remove container."""
        try:
            container.stop(timeout=10)
        except Exception as e:
            logger.warning("Failed to stop container", error=str(e))

    def _compare_executions(
        self,
        selenium_result: dict[str, Any],
        playwright_result: dict[str, Any],
    ) -> VerificationResult:
        """Multi-layer comparison of test executions."""
        # Calculate match percentage
        match_percentage = 100.0  # Would be calculated from screenshots

        # Compare DOM signatures
        dom_match = True  # Would compare DOM snapshots

        # Compare assertions
        assertion_match = (
            selenium_result.get("exit_code", 0) == 0
            and playwright_result.get("exit_code", 0) == 0
        )

        # Calculate performance improvement
        selenium_time = selenium_result.get("execution_time_ms", 1000)
        playwright_time = playwright_result.get("execution_time_ms", 500)
        performance_improvement = selenium_time / max(playwright_time, 1)

        return VerificationResult(
            match_percentage=match_percentage,
            dom_match=dom_match,
            assertion_match=assertion_match,
            performance_improvement=performance_improvement,
            frame_diffs=[],
            artifacts={
                "selenium_video": selenium_result.get("video_path", ""),
                "playwright_video": playwright_result.get("video_path", ""),
            },
            selenium_time_ms=selenium_time,
            playwright_time_ms=playwright_time,
        )

    def _mock_verification(
        self,
        test_class: str,
        project_path: Path,
    ) -> VerificationResult:
        """Return mock verification result for development."""
        return VerificationResult(
            match_percentage=98.5,
            dom_match=True,
            assertion_match=True,
            performance_improvement=2.5,
            frame_diffs=[],
            artifacts={
                "selenium_video": str(project_path / "artifacts" / "selenium.mp4"),
                "playwright_video": str(project_path / "artifacts" / "playwright.mp4"),
                "diff_report": str(project_path / "artifacts" / "diff.html"),
            },
            selenium_time_ms=5000,
            playwright_time_ms=2000,
        )

    def compare_screenshots(
        self,
        screenshot1: Path,
        screenshot2: Path,
    ) -> float:
        """
        Compare two screenshots and return match percentage.

        Args:
            screenshot1: Path to first screenshot
            screenshot2: Path to second screenshot

        Returns:
            Match percentage (0-100)
        """
        try:
            import cv2
            import numpy as np

            img1 = cv2.imread(str(screenshot1))
            img2 = cv2.imread(str(screenshot2))

            if img1 is None or img2 is None:
                return 0.0

            # Resize to same dimensions
            height = min(img1.shape[0], img2.shape[0])
            width = min(img1.shape[1], img2.shape[1])
            img1 = cv2.resize(img1, (width, height))
            img2 = cv2.resize(img2, (width, height))

            # Convert to grayscale
            gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
            gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)

            # Calculate structural similarity
            score = cv2.matchTemplate(gray1, gray2, cv2.TM_CCOEFF_NORMED)[0][0]

            return float(score * 100)

        except Exception as e:
            logger.error("Screenshot comparison failed", error=str(e))
            return 0.0

    def generate_diff_report(
        self,
        result: VerificationResult,
        output_path: Path,
    ) -> Path:
        """
        Generate HTML diff report.

        Args:
            result: Verification result
            output_path: Path to save the report

        Returns:
            Path to the generated report
        """
        html = f"""<!DOCTYPE html>
<html>
<head>
    <title>QAMigrate Verification Report</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 40px; }}
        .header {{ margin-bottom: 30px; }}
        .metric {{ display: inline-block; padding: 20px; margin: 10px; background: #f5f5f5; border-radius: 8px; }}
        .metric-value {{ font-size: 2em; font-weight: bold; }}
        .metric-label {{ color: #666; }}
        .pass {{ color: #22c55e; }}
        .fail {{ color: #ef4444; }}
        .comparison {{ display: flex; gap: 20px; margin-top: 30px; }}
        .video-container {{ flex: 1; }}
        video {{ width: 100%; border-radius: 8px; }}
    </style>
</head>
<body>
    <div class="header">
        <h1>🔍 QAMigrate Verification Report</h1>
    </div>

    <div class="metrics">
        <div class="metric">
            <div class="metric-value {'pass' if result.match_percentage >= 98 else 'fail'}">
                {result.match_percentage:.1f}%
            </div>
            <div class="metric-label">Visual Match</div>
        </div>
        <div class="metric">
            <div class="metric-value {'pass' if result.dom_match else 'fail'}">
                {'✓' if result.dom_match else '✗'}
            </div>
            <div class="metric-label">DOM Match</div>
        </div>
        <div class="metric">
            <div class="metric-value {'pass' if result.assertion_match else 'fail'}">
                {'✓' if result.assertion_match else '✗'}
            </div>
            <div class="metric-label">Assertions</div>
        </div>
        <div class="metric">
            <div class="metric-value pass">{result.performance_improvement:.1f}x</div>
            <div class="metric-label">Faster</div>
        </div>
    </div>

    <div class="comparison">
        <div class="video-container">
            <h3>Selenium Execution ({result.selenium_time_ms}ms)</h3>
            <video controls>
                <source src="{result.artifacts.get('selenium_video', '')}" type="video/mp4">
            </video>
        </div>
        <div class="video-container">
            <h3>Playwright Execution ({result.playwright_time_ms}ms)</h3>
            <video controls>
                <source src="{result.artifacts.get('playwright_video', '')}" type="video/mp4">
            </video>
        </div>
    </div>
</body>
</html>
"""

        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(html)

        logger.info("Generated diff report", path=str(output_path))
        return output_path
