"""
JIRA Integration Module.

Provides integration with JIRA for tracking migration progress and issues.
"""

import os
from dataclasses import dataclass
from typing import Any

import structlog

logger = structlog.get_logger(__name__)


@dataclass
class JiraConfig:
    """JIRA connection configuration."""

    base_url: str
    email: str
    api_token: str
    project_key: str

    @classmethod
    def from_env(cls) -> "JiraConfig":
        """Load configuration from environment variables."""
        return cls(
            base_url=os.getenv("JIRA_BASE_URL", ""),
            email=os.getenv("JIRA_EMAIL", ""),
            api_token=os.getenv("JIRA_API_TOKEN", ""),
            project_key=os.getenv("JIRA_PROJECT_KEY", "TEST"),
        )


class JiraClient:
    """
    JIRA client for migration tracking.

    Creates and updates issues for migration tasks.
    """

    def __init__(self, config: JiraConfig | None = None) -> None:
        """Initialize JIRA client."""
        self.config = config or JiraConfig.from_env()
        self._client = None

        if self.config.base_url and self.config.api_token:
            self._connect()

    def _connect(self) -> None:
        """Establish JIRA connection."""
        try:
            from jira import JIRA

            self._client = JIRA(
                server=self.config.base_url,
                basic_auth=(self.config.email, self.config.api_token),
            )
            logger.info("JIRA connected", url=self.config.base_url)
        except ImportError:
            logger.warning("jira package not installed")
        except Exception as e:
            logger.error("JIRA connection failed", error=str(e))

    def is_connected(self) -> bool:
        """Check if JIRA is connected."""
        return self._client is not None

    def create_migration_epic(
        self,
        project_name: str,
        file_count: int,
    ) -> str | None:
        """
        Create an epic for a migration project.

        Args:
            project_name: Name of the project being migrated
            file_count: Number of files to migrate

        Returns:
            Epic issue key or None
        """
        if not self._client:
            logger.warning("JIRA not connected, skipping epic creation")
            return None

        try:
            issue = self._client.create_issue(
                project=self.config.project_key,
                summary=f"Migrate {project_name} from Selenium to Playwright",
                description=f"""
h2. Migration Overview
* *Project*: {project_name}
* *Files to Migrate*: {file_count}
* *Framework*: Selenium → Playwright

h2. Migration Steps
# Scan project for Selenium patterns
# Generate Playwright code for each file
# Compile and validate migrated code
# Run visual verification tests
# Manual review and cleanup

h2. Acceptance Criteria
* All test files migrated to Playwright
* All tests passing
* Code reviewed and approved
                """,
                issuetype={"name": "Epic"},
            )
            logger.info("Created migration epic", key=issue.key)
            return issue.key

        except Exception as e:
            logger.error("Failed to create epic", error=str(e))
            return None

    def create_file_task(
        self,
        epic_key: str | None,
        file_name: str,
        patterns_found: int,
        complexity: str = "Medium",
    ) -> str | None:
        """
        Create a task for migrating a specific file.

        Args:
            epic_key: Parent epic key
            file_name: Name of file to migrate
            patterns_found: Number of Selenium patterns found
            complexity: Migration complexity

        Returns:
            Task issue key or None
        """
        if not self._client:
            return None

        try:
            issue_dict: dict[str, Any] = {
                "project": self.config.project_key,
                "summary": f"Migrate {file_name} to Playwright",
                "description": f"""
h3. File Details
* *File*: {file_name}
* *Patterns Found*: {patterns_found}
* *Estimated Complexity*: {complexity}

h3. Checklist
* [ ] Run QAMigrate migration
* [ ] Review generated code
* [ ] Fix any compilation errors
* [ ] Verify tests pass
                """,
                "issuetype": {"name": "Task"},
            }

            if epic_key:
                # Link to epic (field may vary by JIRA instance)
                issue_dict["parent"] = {"key": epic_key}

            issue = self._client.create_issue(**issue_dict)
            logger.info("Created file task", key=issue.key, file=file_name)
            return issue.key

        except Exception as e:
            logger.error("Failed to create task", file=file_name, error=str(e))
            return None

    def update_task_status(
        self,
        issue_key: str,
        status: str,
        comment: str | None = None,
    ) -> bool:
        """
        Update task status.

        Args:
            issue_key: Issue key to update
            status: New status (e.g., "Done", "In Progress")
            comment: Optional comment to add

        Returns:
            True if successful
        """
        if not self._client:
            return False

        try:
            issue = self._client.issue(issue_key)

            # Get available transitions
            transitions = self._client.transitions(issue)
            transition_id = None

            for t in transitions:
                if t["name"].lower() == status.lower():
                    transition_id = t["id"]
                    break

            if transition_id:
                self._client.transition_issue(issue, transition_id)
                logger.info("Updated issue status", key=issue_key, status=status)

            if comment:
                self._client.add_comment(issue, comment)

            return True

        except Exception as e:
            logger.error("Failed to update task", key=issue_key, error=str(e))
            return False

    def add_migration_result(
        self,
        issue_key: str,
        success: bool,
        output_path: str | None = None,
        error: str | None = None,
    ) -> bool:
        """
        Add migration result as a comment.

        Args:
            issue_key: Issue key
            success: Whether migration succeeded
            output_path: Path to migrated file
            error: Error message if failed

        Returns:
            True if successful
        """
        if not self._client:
            return False

        try:
            if success:
                comment = f"""
{{color:#00875A}}*Migration Successful*{{color}}

Generated file: {{{output_path}}}

Next steps:
# Review the generated code
# Run tests to verify
# Mark task as done
                """
            else:
                comment = f"""
{{color:#DE350B}}*Migration Failed*{{color}}

Error: {error}

Next steps:
# Review the error
# Fix manually or retry
# Update QAMigrate patterns if needed
                """

            self._client.add_comment(issue_key, comment)
            return True

        except Exception as e:
            logger.error("Failed to add result", key=issue_key, error=str(e))
            return False


# Singleton instance
_jira_client: JiraClient | None = None


def get_jira() -> JiraClient:
    """Get or create JIRA client instance."""
    global _jira_client
    if _jira_client is None:
        _jira_client = JiraClient()
    return _jira_client
