"""
QAMigrate - AI-powered Selenium to Playwright migration.
"""

__version__ = "0.1.0"
__author__ = "QAMigrate Team"

from qamigrate.core.config import QAMigrateConfig

__all__ = ["QAMigrateConfig", "__version__"]
