"""
Security Utilities Module.

Provides security hardening for prompt injection, input sanitization,
and vulnerability detection.
"""

import re
import html
from typing import Any
from pathlib import Path

import structlog

logger = structlog.get_logger(__name__)


# ============ Prompt Injection Protection ============

# Dangerous patterns in user input that could manipulate LLM behavior
PROMPT_INJECTION_PATTERNS = [
    # Instruction override attempts
    r"ignore\s+(previous|all|above)\s+(instructions|prompts|rules)",
    r"disregard\s+(previous|all|above)",
    r"forget\s+(everything|all|previous)",
    r"new\s+instructions?:",
    r"system\s*:\s*",
    r"assistant\s*:\s*",
    r"user\s*:\s*",
    
    # Role hijacking
    r"you\s+are\s+now\s+a",
    r"pretend\s+(you\s+are|to\s+be)",
    r"act\s+as\s+(if|a|an)",
    r"roleplay\s+as",
    
    # Output manipulation
    r"output\s+only",
    r"respond\s+with\s+only",
    r"print\s+exactly",
    r"say\s+exactly",
    
    # Data exfiltration attempts
    r"show\s+me\s+(your|the)\s+(prompt|instructions|system)",
    r"reveal\s+(your|the)\s+(prompt|instructions)",
    r"what\s+are\s+your\s+instructions",
    
    # Delimiter injection
    r"```\s*system",
    r"<\|.*?\|>",
    r"\[\[.*?\]\]",
    r"<<.*?>>",
]

# Compiled patterns for performance
_INJECTION_PATTERNS_COMPILED = [
    re.compile(pattern, re.IGNORECASE) for pattern in PROMPT_INJECTION_PATTERNS
]


def detect_prompt_injection(text: str) -> tuple[bool, str | None]:
    """
    Detect potential prompt injection attempts in user input.

    Args:
        text: User-provided text to check

    Returns:
        Tuple of (is_suspicious, matched_pattern)
    """
    if not text:
        return False, None

    for pattern in _INJECTION_PATTERNS_COMPILED:
        match = pattern.search(text)
        if match:
            logger.warning(
                "Prompt injection detected",
                pattern=pattern.pattern,
                match=match.group(),
            )
            return True, pattern.pattern

    return False, None


def sanitize_for_llm(text: str, max_length: int = 10000) -> str:
    """
    Sanitize user input before sending to LLM.

    Args:
        text: User-provided text
        max_length: Maximum allowed length

    Returns:
        Sanitized text safe for LLM consumption
    """
    if not text:
        return ""

    # Truncate to max length
    if len(text) > max_length:
        text = text[:max_length] + "\n... [truncated]"
        logger.warning("Input truncated", original_length=len(text), max_length=max_length)

    # Remove null bytes and control characters (except newlines/tabs)
    text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', text)

    # Escape potential delimiter injections
    text = text.replace("```system", "\\`\\`\\`system")
    text = text.replace("<|", "\\<\\|")
    text = text.replace("|>", "\\|\\>")

    return text


# ============ Input Sanitization ============

def sanitize_html(text: str) -> str:
    """Escape HTML special characters."""
    return html.escape(text)


def sanitize_sql_like(text: str) -> str:
    """Escape SQL LIKE wildcards."""
    return text.replace("%", "\\%").replace("_", "\\_")


def sanitize_filename(filename: str) -> str:
    """
    Sanitize filename to prevent path traversal and invalid characters.

    Args:
        filename: User-provided filename

    Returns:
        Safe filename
    """
    # Remove path separators
    filename = filename.replace("/", "_").replace("\\", "_")

    # Remove null bytes
    filename = filename.replace("\x00", "")

    # Remove parent directory references
    filename = filename.replace("..", "_")

    # Remove leading/trailing dots and spaces
    filename = filename.strip(". ")

    # Keep only safe characters
    filename = re.sub(r'[^\w\-.]', '_', filename)

    # Ensure not empty
    if not filename:
        filename = "unnamed"

    return filename


def validate_email(email: str) -> bool:
    """Validate email format (basic check)."""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))


# ============ Vulnerability Detection ============

# Dangerous patterns in generated code
CODE_VULNERABILITY_PATTERNS = {
    "hardcoded_secret": [
        r'password\s*=\s*["\'][^"\']{8,}["\']',
        r'api_key\s*=\s*["\'][^"\']{10,}["\']',
        r'secret\s*=\s*["\'][^"\']{10,}["\']',
        r'token\s*=\s*["\'][^"\']{20,}["\']',
    ],
    "sql_injection": [
        r'execute\s*\(\s*["\'].*\+',
        r'cursor\.execute\s*\(\s*f["\']',
        r'\".*\"\s*\+\s*.*\s*\+\s*\".*\"',
    ],
    "command_injection": [
        r'os\.system\s*\(',
        r'subprocess\.call\s*\(\s*["\']',
        r'Runtime\.getRuntime\(\)\.exec\s*\(',
    ],
    "path_traversal": [
        r'\.\./',
        r'\.\.\\\\'
    ],
    "unsafe_deserialization": [
        r'pickle\.loads?\s*\(',
        r'yaml\.load\s*\([^,]*\)',  # yaml.load without Loader
        r'ObjectInputStream',
    ],
}


def scan_code_vulnerabilities(code: str) -> list[dict[str, Any]]:
    """
    Scan generated code for potential vulnerabilities.

    Args:
        code: Generated code to scan

    Returns:
        List of detected vulnerabilities
    """
    vulnerabilities = []

    for vuln_type, patterns in CODE_VULNERABILITY_PATTERNS.items():
        for pattern in patterns:
            matches = re.finditer(pattern, code, re.IGNORECASE | re.MULTILINE)
            for match in matches:
                # Get line number
                line_num = code[:match.start()].count('\n') + 1

                vulnerabilities.append({
                    "type": vuln_type,
                    "pattern": pattern,
                    "match": match.group()[:100],
                    "line": line_num,
                    "severity": _get_severity(vuln_type),
                })

    if vulnerabilities:
        logger.warning(
            "Vulnerabilities detected in generated code",
            count=len(vulnerabilities),
        )

    return vulnerabilities


def _get_severity(vuln_type: str) -> str:
    """Get severity level for vulnerability type."""
    high_severity = ["sql_injection", "command_injection", "unsafe_deserialization"]
    medium_severity = ["hardcoded_secret"]

    if vuln_type in high_severity:
        return "high"
    elif vuln_type in medium_severity:
        return "medium"
    return "low"


# ============ Rate Limiting Helper ============

class RateLimiter:
    """
    Token bucket rate limiter.

    More robust than simple sliding window for burst handling.
    """

    def __init__(
        self,
        rate: float,
        capacity: int,
        redis_client=None,
    ) -> None:
        """
        Initialize rate limiter.

        Args:
            rate: Tokens per second
            capacity: Maximum tokens (burst capacity)
            redis_client: Optional Redis client for distributed limiting
        """
        self.rate = rate
        self.capacity = capacity
        self.redis = redis_client
        self._local_tokens: dict[str, tuple[float, float]] = {}

    def allow(self, key: str, tokens: int = 1) -> tuple[bool, int]:
        """
        Check if request is allowed.

        Args:
            key: Rate limit key (user ID, IP, etc.)
            tokens: Number of tokens to consume

        Returns:
            Tuple of (allowed, remaining_tokens)
        """
        import time

        now = time.time()

        if self.redis:
            return self._redis_allow(key, tokens, now)

        # Local token bucket
        if key not in self._local_tokens:
            self._local_tokens[key] = (now, self.capacity)

        last_time, current_tokens = self._local_tokens[key]

        # Add tokens based on elapsed time
        elapsed = now - last_time
        current_tokens = min(self.capacity, current_tokens + elapsed * self.rate)

        if current_tokens >= tokens:
            current_tokens -= tokens
            self._local_tokens[key] = (now, current_tokens)
            return True, int(current_tokens)

        return False, int(current_tokens)

    def _redis_allow(self, key: str, tokens: int, now: float) -> tuple[bool, int]:
        """Redis-based token bucket."""
        try:
            pipe = self.redis._client.pipeline()
            bucket_key = f"ratelimit:{key}"

            # Lua script for atomic token bucket
            script = """
            local capacity = tonumber(ARGV[1])
            local rate = tonumber(ARGV[2])
            local now = tonumber(ARGV[3])
            local tokens_needed = tonumber(ARGV[4])

            local data = redis.call('HMGET', KEYS[1], 'tokens', 'last_update')
            local current_tokens = tonumber(data[1]) or capacity
            local last_update = tonumber(data[2]) or now

            local elapsed = now - last_update
            current_tokens = math.min(capacity, current_tokens + elapsed * rate)

            if current_tokens >= tokens_needed then
                current_tokens = current_tokens - tokens_needed
                redis.call('HMSET', KEYS[1], 'tokens', current_tokens, 'last_update', now)
                redis.call('EXPIRE', KEYS[1], 3600)
                return {1, math.floor(current_tokens)}
            end

            return {0, math.floor(current_tokens)}
            """

            result = self.redis._client.eval(
                script, 1, bucket_key,
                self.capacity, self.rate, now, tokens
            )

            return bool(result[0]), int(result[1])

        except Exception as e:
            logger.error("Redis rate limit failed", error=str(e))
            return True, self.capacity  # Fail open


# ============ Performance Monitoring ============

import time
from contextlib import contextmanager
from functools import wraps


@contextmanager
def measure_time(operation: str):
    """Context manager to measure operation time."""
    start = time.perf_counter()
    try:
        yield
    finally:
        elapsed = time.perf_counter() - start
        logger.info(f"{operation} completed", time_seconds=f"{elapsed:.3f}")


def timed(func):
    """Decorator to log function execution time."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.perf_counter()
        try:
            return func(*args, **kwargs)
        finally:
            elapsed = time.perf_counter() - start
            logger.debug(
                f"{func.__name__} completed",
                time_seconds=f"{elapsed:.3f}",
            )
    return wrapper


def timed_async(func):
    """Async decorator to log function execution time."""
    @wraps(func)
    async def wrapper(*args, **kwargs):
        start = time.perf_counter()
        try:
            return await func(*args, **kwargs)
        finally:
            elapsed = time.perf_counter() - start
            logger.debug(
                f"{func.__name__} completed",
                time_seconds=f"{elapsed:.3f}",
            )
    return wrapper
