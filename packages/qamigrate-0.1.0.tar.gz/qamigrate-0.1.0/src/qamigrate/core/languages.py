"""
Multi-Language Support Module.

Provides language detection and configuration for Python, JavaScript, and C# migrations.
"""

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any

import structlog

logger = structlog.get_logger(__name__)


class Language(Enum):
    """Supported programming languages."""

    JAVA = "java"
    PYTHON = "python"
    JAVASCRIPT = "javascript"
    CSHARP = "csharp"


@dataclass
class LanguageConfig:
    """Configuration for a specific language."""

    language: Language
    file_extensions: list[str]
    test_framework: str
    playwright_package: str
    import_style: str
    locator_style: str
    patterns: dict[str, str] = field(default_factory=dict)


# Language-specific configurations
LANGUAGE_CONFIGS: dict[Language, LanguageConfig] = {
    Language.JAVA: LanguageConfig(
        language=Language.JAVA,
        file_extensions=[".java"],
        test_framework="JUnit 5",
        playwright_package="com.microsoft.playwright",
        import_style="import",
        locator_style="page.locator()",
        patterns={
            "driver.findElement": "page.locator()",
            "element.sendKeys": "locator.fill()",
            "element.click": "locator.click()",
            "WebDriverWait": "// Playwright auto-waits",
        },
    ),
    Language.PYTHON: LanguageConfig(
        language=Language.PYTHON,
        file_extensions=[".py"],
        test_framework="pytest",
        playwright_package="playwright.sync_api",
        import_style="from/import",
        locator_style="page.locator()",
        patterns={
            "driver.find_element": "page.locator()",
            "element.send_keys": "locator.fill()",
            "element.click": "locator.click()",
            "WebDriverWait": "# Playwright auto-waits",
            "time.sleep": "# page.wait_for_timeout() if needed",
        },
    ),
    Language.JAVASCRIPT: LanguageConfig(
        language=Language.JAVASCRIPT,
        file_extensions=[".js", ".ts", ".mjs"],
        test_framework="Playwright Test",
        playwright_package="@playwright/test",
        import_style="import/require",
        locator_style="page.locator()",
        patterns={
            "driver.findElement": "page.locator()",
            "element.sendKeys": "locator.fill()",
            "element.click": "locator.click()",
            "await driver.sleep": "// Playwright auto-waits",
        },
    ),
    Language.CSHARP: LanguageConfig(
        language=Language.CSHARP,
        file_extensions=[".cs"],
        test_framework="NUnit/xUnit",
        playwright_package="Microsoft.Playwright",
        import_style="using",
        locator_style="Page.Locator()",
        patterns={
            "driver.FindElement": "Page.Locator()",
            "element.SendKeys": "locator.FillAsync()",
            "element.Click": "locator.ClickAsync()",
            "WebDriverWait": "// Playwright auto-waits",
        },
    ),
}


def detect_language(file_path: Path) -> Language:
    """
    Detect the programming language of a file.

    Args:
        file_path: Path to the source file

    Returns:
        Detected Language enum value
    """
    ext = file_path.suffix.lower()

    for lang, config in LANGUAGE_CONFIGS.items():
        if ext in config.file_extensions:
            return lang

    # Default to Java if unknown
    return Language.JAVA


def detect_project_language(project_path: Path) -> Language:
    """
    Detect the primary language of a project.

    Args:
        project_path: Path to project root

    Returns:
        Primary Language enum value
    """
    language_counts: dict[Language, int] = {lang: 0 for lang in Language}

    # Check for language-specific config files
    config_files = {
        Language.JAVA: ["pom.xml", "build.gradle", "build.gradle.kts"],
        Language.PYTHON: ["pyproject.toml", "setup.py", "requirements.txt"],
        Language.JAVASCRIPT: ["package.json", "tsconfig.json"],
        Language.CSHARP: ["*.csproj", "*.sln"],
    }

    for lang, files in config_files.items():
        for pattern in files:
            if list(project_path.glob(pattern)):
                language_counts[lang] += 10  # Config files count more

    # Count source files
    for lang, config in LANGUAGE_CONFIGS.items():
        for ext in config.file_extensions:
            count = len(list(project_path.rglob(f"*{ext}")))
            language_counts[lang] += count

    # Return language with highest count
    return max(language_counts, key=lambda k: language_counts[k])


def get_language_config(language: Language) -> LanguageConfig:
    """Get configuration for a specific language."""
    return LANGUAGE_CONFIGS[language]


# Language-specific prompts for the coder agent
LANGUAGE_PROMPTS: dict[Language, str] = {
    Language.PYTHON: """You are an expert Python developer specializing in test automation migration.
Your task is to convert Selenium Python tests to Playwright Python, following these principles:

## Playwright Python Patterns

1. **Page Object Model**: All page objects receive `page` via constructor injection
2. **Locators**: Use `page.locator()` with CSS selectors (preferred) or XPath
3. **Auto-waiting**: Remove all explicit waits - Playwright handles automatically
4. **Assertions**: Use Playwright's `expect()` for assertions
5. **Sync API**: Use `playwright.sync_api` unless async is specifically needed

## Migration Rules (Python)

### Locators
- driver.find_element(By.ID, "x") → page.locator("#x")
- driver.find_element(By.CSS_SELECTOR, "x") → page.locator("x")
- driver.find_element(By.XPATH, "x") → page.locator("xpath=x")
- driver.find_element(By.CLASS_NAME, "x") → page.locator(".x")

### Interactions
- element.send_keys("text") → locator.fill("text")
- element.click() → locator.click()
- element.clear() → (removed, fill() clears automatically)
- Select(element).select_by_value("x") → locator.select_option("x")
- element.text → locator.text_content()

### Waits (REMOVE - Playwright auto-waits)
- WebDriverWait(driver, 10).until(...) → REMOVE
- time.sleep(n) → REMOVE (or page.wait_for_timeout() only if necessary)

### Assertions (pytest + Playwright)
- assert element.is_displayed() → expect(locator).to_be_visible()
- assert expected == element.text → expect(locator).to_have_text(expected)

### Test Class Structure (pytest)
```python
import pytest
from playwright.sync_api import Page, expect

class TestExample:
    def test_example(self, page: Page):
        page.goto("/")
        expect(page.locator("#element")).to_be_visible()
```

### Page Object Structure
```python
from playwright.sync_api import Page, Locator

class ExamplePage:
    def __init__(self, page: Page):
        self.page = page
        self.some_element = page.locator("#selector")

    def do_action(self):
        self.some_element.click()
```
""",
    Language.JAVASCRIPT: """You are an expert JavaScript/TypeScript developer specializing in test automation migration.
Your task is to convert Selenium JavaScript tests to Playwright Test, following these principles:

## Playwright Test Patterns

1. **Test Structure**: Use `test()` and `expect()` from @playwright/test
2. **Locators**: Use `page.locator()` with CSS selectors (preferred) or XPath
3. **Auto-waiting**: Remove all explicit waits - Playwright handles automatically
4. **Assertions**: Use Playwright's `expect()` for assertions
5. **Fixtures**: Use page fixture instead of driver setup

## Migration Rules (JavaScript/TypeScript)

### Locators
- driver.findElement(By.id("x")) → page.locator("#x")
- driver.findElement(By.css("x")) → page.locator("x")
- driver.findElement(By.xpath("x")) → page.locator("xpath=x")
- await driver.findElement(...) → page.locator(...) (no await needed)

### Interactions
- await element.sendKeys("text") → await locator.fill("text")
- await element.click() → await locator.click()
- await element.clear() → (removed, fill() clears automatically)

### Waits (REMOVE - Playwright auto-waits)
- await driver.wait(until.elementLocated(...)) → REMOVE
- await driver.sleep(ms) → REMOVE

### Test Structure (Playwright Test)
```typescript
import { test, expect } from '@playwright/test';

test('example test', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#element')).toBeVisible();
});
```

### Page Object Structure
```typescript
import { Page, Locator } from '@playwright/test';

export class ExamplePage {
    readonly page: Page;
    readonly someElement: Locator;

    constructor(page: Page) {
        this.page = page;
        this.someElement = page.locator('#selector');
    }

    async doAction() {
        await this.someElement.click();
    }
}
```
""",
    Language.CSHARP: """You are an expert C# developer specializing in test automation migration.
Your task is to convert Selenium C# tests to Playwright C#, following these principles:

## Playwright C# Patterns

1. **Page Object Model**: All page objects receive `IPage` via constructor injection
2. **Locators**: Use `Page.Locator()` with CSS selectors (preferred) or XPath
3. **Auto-waiting**: Remove all explicit waits - Playwright handles automatically
4. **Assertions**: Use Playwright's `Expect()` for assertions
5. **Async/Await**: All Playwright methods are async

## Migration Rules (C#)

### Locators
- driver.FindElement(By.Id("x")) → Page.Locator("#x")
- driver.FindElement(By.CssSelector("x")) → Page.Locator("x")
- driver.FindElement(By.XPath("x")) → Page.Locator("xpath=x")

### Interactions
- element.SendKeys("text") → await locator.FillAsync("text")
- element.Click() → await locator.ClickAsync()
- element.Clear() → (removed, FillAsync() clears automatically)
- new SelectElement(element).SelectByValue("x") → await locator.SelectOptionAsync("x")

### Waits (REMOVE - Playwright auto-waits)
- WebDriverWait(driver, TimeSpan.FromSeconds(10)).Until(...) → REMOVE
- Thread.Sleep(ms) → REMOVE

### Test Structure (NUnit)
```csharp
using Microsoft.Playwright;
using Microsoft.Playwright.NUnit;
using NUnit.Framework;

[Parallelizable(ParallelScope.Self)]
[TestFixture]
public class ExampleTests : PageTest
{
    [Test]
    public async Task ExampleTest()
    {
        await Page.GotoAsync("/");
        await Expect(Page.Locator("#element")).ToBeVisibleAsync();
    }
}
```

### Page Object Structure
```csharp
using Microsoft.Playwright;

public class ExamplePage
{
    private readonly IPage _page;
    private ILocator SomeElement => _page.Locator("#selector");

    public ExamplePage(IPage page)
    {
        _page = page;
    }

    public async Task DoActionAsync()
    {
        await SomeElement.ClickAsync();
    }
}
```
""",
}


def get_language_prompt(language: Language) -> str | None:
    """Get the migration prompt for a specific language."""
    return LANGUAGE_PROMPTS.get(language)
