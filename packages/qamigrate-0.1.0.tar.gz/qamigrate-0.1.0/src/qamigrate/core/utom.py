"""
UTOM (Universal Test Object Model) Schema Definitions.

UTOM serves as the semantic intermediate representation,
capturing test intent independent of framework syntax.
"""

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class ActionType(str, Enum):
    """Types of test actions."""

    NAVIGATE = "NAVIGATE"
    INTERACT = "INTERACT"
    ASSERTION = "ASSERTION"
    WAIT = "WAIT"
    SCRIPT = "SCRIPT"


class InteractionType(str, Enum):
    """Types of element interactions."""

    CLICK = "CLICK"
    DOUBLE_CLICK = "DOUBLE_CLICK"
    RIGHT_CLICK = "RIGHT_CLICK"
    FILL = "FILL"
    CLEAR = "CLEAR"
    SELECT = "SELECT"
    CHECK = "CHECK"
    UNCHECK = "UNCHECK"
    HOVER = "HOVER"
    DRAG_DROP = "DRAG_DROP"
    UPLOAD = "UPLOAD"
    PRESS_KEY = "PRESS_KEY"


class AssertionType(str, Enum):
    """Types of assertions."""

    VISIBLE = "VISIBLE"
    HIDDEN = "HIDDEN"
    ENABLED = "ENABLED"
    DISABLED = "DISABLED"
    TEXT_EQUALS = "TEXT_EQUALS"
    TEXT_CONTAINS = "TEXT_CONTAINS"
    ATTRIBUTE_EQUALS = "ATTRIBUTE_EQUALS"
    VALUE_EQUALS = "VALUE_EQUALS"
    COUNT_EQUALS = "COUNT_EQUALS"
    URL_EQUALS = "URL_EQUALS"
    TITLE_EQUALS = "TITLE_EQUALS"


class LocatorType(str, Enum):
    """Types of element locators."""

    CSS = "CSS"
    XPATH = "XPATH"
    ID = "ID"
    NAME = "NAME"
    CLASS = "CLASS"
    TAG = "TAG"
    LINK_TEXT = "LINK_TEXT"
    PARTIAL_LINK_TEXT = "PARTIAL_LINK_TEXT"
    DATA_TESTID = "DATA_TESTID"


class ElementTarget(BaseModel):
    """Target element specification."""

    locator_type: LocatorType = Field(description="Type of locator")
    value: str = Field(description="Locator value")
    semantic_name: str | None = Field(default=None, description="Human-readable element name")
    fallback_locators: list[str] = Field(
        default_factory=list, description="Alternative locator values"
    )
    frame: str | None = Field(default=None, description="Frame context if nested")


class TestStep(BaseModel):
    """A single step in a test case."""

    step_id: int = Field(description="Sequential step identifier")
    action_type: ActionType = Field(description="Type of action")

    # For INTERACT actions
    interaction: InteractionType | None = Field(default=None)
    target: ElementTarget | None = Field(default=None)
    data: str | None = Field(default=None, description="Input data for the action")

    # For ASSERTION actions
    assertion: AssertionType | None = Field(default=None)
    expected_value: str | None = Field(default=None)
    timeout_override_ms: int | None = Field(default=None)

    # For NAVIGATE actions
    url: str | None = Field(default=None)

    # For WAIT actions
    wait_ms: int | None = Field(default=None)
    wait_condition: str | None = Field(default=None)

    # For SCRIPT actions
    script: str | None = Field(default=None)

    # Migration metadata
    original_selenium: str | None = Field(default=None, description="Original Selenium code")
    migration_notes: list[str] = Field(
        default_factory=list, description="Notes about migration changes"
    )
    complexity_score: int = Field(default=1, ge=1, le=10)


class Precondition(BaseModel):
    """Test precondition."""

    type: str = Field(description="Type of precondition (URL, STATE, DATA)")
    value: str | None = Field(default=None)
    description: str | None = Field(default=None)


class Postcondition(BaseModel):
    """Test postcondition."""

    type: str = Field(description="Type of postcondition")
    description: str = Field(description="Expected state after test")


class TestMetadata(BaseModel):
    """Metadata about the test."""

    source_file: str = Field(description="Original source file path")
    source_line: int | None = Field(default=None)
    package_name: str | None = Field(default=None)
    class_name: str | None = Field(default=None)
    method_name: str | None = Field(default=None)
    criticality: str = Field(default="P2", description="Priority level (P0-P3)")
    tags: list[str] = Field(default_factory=list)
    last_modified: str | None = Field(default=None)


class UTOM(BaseModel):
    """
    Universal Test Object Model.

    Semantic representation of a test case independent of framework syntax.
    """

    test_id: str = Field(description="Unique test identifier")
    intent_summary: str = Field(description="Human-readable summary of test intent")
    metadata: TestMetadata = Field(description="Test metadata")
    preconditions: list[Precondition] = Field(default_factory=list)
    steps: list[TestStep] = Field(description="Test steps")
    postconditions: list[Postcondition] = Field(default_factory=list)
    data_sets: list[dict[str, Any]] = Field(
        default_factory=list, description="Data-driven test data"
    )

    # Migration tracking
    total_complexity: int = Field(default=0, description="Sum of step complexities")
    migration_warnings: list[str] = Field(default_factory=list)

    def model_post_init(self, __context: Any) -> None:
        """Calculate total complexity after initialization."""
        if self.total_complexity == 0:
            self.total_complexity = sum(step.complexity_score for step in self.steps)


class PageObjectUTOM(BaseModel):
    """UTOM representation of a Page Object class."""

    page_id: str = Field(description="Unique page object identifier")
    page_name: str = Field(description="Human-readable page name")
    metadata: TestMetadata = Field(description="Page object metadata")

    # Elements
    elements: list[ElementTarget] = Field(
        default_factory=list, description="Page elements with locators"
    )

    # Methods
    methods: list[dict[str, Any]] = Field(
        default_factory=list, description="Page object methods"
    )

    # Dependencies
    dependencies: list[str] = Field(
        default_factory=list, description="Other page objects this depends on"
    )

    # Migration tracking
    total_complexity: int = Field(default=0)
    migration_warnings: list[str] = Field(default_factory=list)
