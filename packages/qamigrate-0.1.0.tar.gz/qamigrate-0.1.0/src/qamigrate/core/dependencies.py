"""
Dependency Analyzer Module.

Analyzes Java file dependencies for proper compilation order.
"""

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import structlog

logger = structlog.get_logger(__name__)


@dataclass
class JavaClass:
    """Represents a Java class with its dependencies."""

    file_path: Path
    package: str
    class_name: str
    full_name: str
    imports: list[str] = field(default_factory=list)
    dependencies: list[str] = field(default_factory=list)  # Classes we depend on
    dependents: list[str] = field(default_factory=list)  # Classes that depend on us


class DependencyAnalyzer:
    """
    Analyze Java file dependencies for proper compilation order.

    Ensures files are migrated/compiled in the correct order
    so that dependencies are satisfied.
    """

    def __init__(self) -> None:
        """Initialize dependency analyzer."""
        self.classes: dict[str, JavaClass] = {}
        self.project_packages: set[str] = set()

    def analyze_project(self, project_path: Path) -> dict[str, JavaClass]:
        """
        Analyze all Java files in a project.

        Args:
            project_path: Project root path

        Returns:
            Dictionary of class name to JavaClass
        """
        logger.info("Analyzing project dependencies", path=str(project_path))

        # Find all Java files
        java_files = list(project_path.rglob("*.java"))
        java_files = [
            f for f in java_files
            if not any(exc in str(f) for exc in ["target", "build", "playwright"])
        ]

        # First pass: collect all classes and packages
        for file_path in java_files:
            try:
                java_class = self._parse_file(file_path)
                if java_class:
                    self.classes[java_class.full_name] = java_class
                    self.project_packages.add(java_class.package)
            except Exception as e:
                logger.warning(f"Failed to parse {file_path}: {e}")

        # Second pass: resolve dependencies
        for java_class in self.classes.values():
            self._resolve_dependencies(java_class)

        logger.info(
            "Dependency analysis complete",
            classes=len(self.classes),
            packages=len(self.project_packages),
        )

        return self.classes

    def _parse_file(self, file_path: Path) -> JavaClass | None:
        """Parse a Java file to extract class info."""
        content = file_path.read_text(encoding="utf-8", errors="ignore")

        # Extract package
        package_match = re.search(r"package\s+([\w.]+)\s*;", content)
        package = package_match.group(1) if package_match else ""

        # Extract class name
        class_match = re.search(
            r"(?:public\s+)?(?:abstract\s+)?(?:class|interface|enum)\s+(\w+)",
            content,
        )
        if not class_match:
            return None

        class_name = class_match.group(1)
        full_name = f"{package}.{class_name}" if package else class_name

        # Extract imports
        imports = re.findall(r"import\s+([\w.]+(?:\.\*)?)\s*;", content)

        # Extract class references in code (extends, implements, field types, etc.)
        type_refs = set()

        # Extends
        extends_match = re.search(r"extends\s+(\w+)", content)
        if extends_match:
            type_refs.add(extends_match.group(1))

        # Implements
        implements_match = re.search(r"implements\s+([\w,\s]+?)(?:\s*\{|\s*extends)", content)
        if implements_match:
            for iface in implements_match.group(1).split(","):
                type_refs.add(iface.strip())

        # Field types and method return types
        type_patterns = [
            r"private\s+(?:final\s+)?(\w+)\s+\w+",  # private fields
            r"public\s+(?:final\s+)?(\w+)\s+\w+",  # public fields
            r"protected\s+(?:final\s+)?(\w+)\s+\w+",  # protected fields
            r"new\s+(\w+)\s*\(",  # object creation
            r"return\s+new\s+(\w+)",  # return new
        ]
        for pattern in type_patterns:
            for match in re.findall(pattern, content):
                if match[0].isupper():  # Class names start with uppercase
                    type_refs.add(match)

        return JavaClass(
            file_path=file_path,
            package=package,
            class_name=class_name,
            full_name=full_name,
            imports=imports,
            dependencies=list(type_refs),
        )

    def _resolve_dependencies(self, java_class: JavaClass) -> None:
        """Resolve dependencies to actual project classes."""
        resolved = []

        for dep in java_class.dependencies:
            # Try to find in project classes
            for full_name, cls in self.classes.items():
                if cls.class_name == dep:
                    resolved.append(full_name)
                    cls.dependents.append(java_class.full_name)
                    break

        java_class.dependencies = resolved

    def get_compilation_order(self) -> list[Path]:
        """
        Get files in dependency order (dependencies first).

        Uses topological sort to ensure dependencies are compiled
        before the classes that use them.

        Returns:
            List of file paths in compilation order
        """
        # Build dependency graph
        in_degree: dict[str, int] = {name: 0 for name in self.classes}

        for java_class in self.classes.values():
            for dep in java_class.dependencies:
                if dep in in_degree:
                    in_degree[java_class.full_name] += 1

        # Topological sort (Kahn's algorithm)
        queue = [name for name, degree in in_degree.items() if degree == 0]
        result = []

        while queue:
            current = queue.pop(0)
            result.append(current)

            for java_class in self.classes.values():
                if current in java_class.dependencies:
                    in_degree[java_class.full_name] -= 1
                    if in_degree[java_class.full_name] == 0:
                        queue.append(java_class.full_name)

        # Handle cycles by adding remaining
        for name in self.classes:
            if name not in result:
                result.append(name)

        # Convert to file paths
        return [self.classes[name].file_path for name in result]

    def get_dependency_tree(self, class_name: str) -> dict[str, Any]:
        """Get dependency tree for a class."""
        if class_name not in self.classes:
            return {}

        java_class = self.classes[class_name]

        return {
            "name": java_class.class_name,
            "full_name": java_class.full_name,
            "dependencies": [
                self.get_dependency_tree(dep)
                for dep in java_class.dependencies
                if dep in self.classes
            ],
            "dependents": java_class.dependents,
        }

    def get_base_classes(self) -> list[Path]:
        """Get classes that have no dependencies (should be migrated first)."""
        return [
            cls.file_path
            for cls in self.classes.values()
            if not cls.dependencies
        ]

    def get_leaf_classes(self) -> list[Path]:
        """Get classes that nothing depends on (can be migrated last)."""
        return [
            cls.file_path
            for cls in self.classes.values()
            if not cls.dependents
        ]
