"""
Report Generator Module.

Generates HTML, PDF, and JSON reports for migration results.
"""

from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

import structlog

logger = structlog.get_logger(__name__)


@dataclass
class MigrationStats:
    """Statistics for a migration run."""

    total_files: int = 0
    success_count: int = 0
    failed_count: int = 0
    total_time_seconds: float = 0.0
    patterns_detected: int = 0
    lines_migrated: int = 0
    complexity_score: float = 0.0
    files: list[dict] = field(default_factory=list)


class ReportGenerator:
    """Generate migration reports in various formats."""

    def __init__(self) -> None:
        """Initialize report generator."""
        self.timestamp = datetime.now()

    def generate_html(
        self,
        stats: MigrationStats,
        output_path: Path,
    ) -> Path:
        """
        Generate an HTML report with charts and metrics.

        Args:
            stats: Migration statistics
            output_path: Path to save the report

        Returns:
            Path to the generated report
        """
        logger.info("Generating HTML report", output=str(output_path))

        html = self._build_html_report(stats)

        output_path.write_text(html, encoding="utf-8")
        logger.info("Report generated", path=str(output_path))

        return output_path

    def _build_html_report(self, stats: MigrationStats) -> str:
        """Build the HTML report content."""
        success_rate = (
            (stats.success_count / stats.total_files * 100) if stats.total_files > 0 else 0
        )

        # Build file rows
        file_rows = ""
        for f in stats.files:
            status_class = "success" if f.get("success") else "failed"
            status_icon = "✓" if f.get("success") else "✗"
            file_rows += f"""
            <tr class="{status_class}">
                <td>{f.get('name', 'Unknown')}</td>
                <td>{status_icon}</td>
                <td>{f.get('patterns', 0)}</td>
                <td>{f.get('lines', 0)}</td>
                <td>{f.get('time', 0):.1f}s</td>
            </tr>
            """

        return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QAMigrate Migration Report</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {{
            --primary: #0066cc;
            --success: #28a745;
            --danger: #dc3545;
            --bg: #f8f9fa;
            --card-bg: #ffffff;
        }}
        * {{ box-sizing: border-box; margin: 0; padding: 0; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: var(--bg);
            padding: 20px;
            line-height: 1.6;
        }}
        .container {{ max-width: 1200px; margin: 0 auto; }}
        header {{
            background: linear-gradient(135deg, var(--primary), #004499);
            color: white;
            padding: 30px;
            border-radius: 12px;
            margin-bottom: 30px;
        }}
        header h1 {{ font-size: 2em; margin-bottom: 8px; }}
        header p {{ opacity: 0.9; }}
        .stats-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }}
        .stat-card {{
            background: var(--card-bg);
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            text-align: center;
        }}
        .stat-value {{
            font-size: 2.5em;
            font-weight: bold;
            color: var(--primary);
        }}
        .stat-value.success {{ color: var(--success); }}
        .stat-value.danger {{ color: var(--danger); }}
        .stat-label {{ color: #666; margin-top: 5px; }}
        .charts-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }}
        .chart-card {{
            background: var(--card-bg);
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }}
        .chart-card h3 {{ margin-bottom: 20px; color: #333; }}
        .files-table {{
            background: var(--card-bg);
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            overflow: hidden;
        }}
        .files-table h3 {{
            padding: 20px;
            margin: 0;
            border-bottom: 1px solid #eee;
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
        }}
        th, td {{
            padding: 12px 20px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }}
        th {{ background: #f5f5f5; font-weight: 600; }}
        tr.success td:nth-child(2) {{ color: var(--success); }}
        tr.failed td:nth-child(2) {{ color: var(--danger); }}
        footer {{
            text-align: center;
            padding: 30px;
            color: #666;
        }}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>🚀 QAMigrate Migration Report</h1>
            <p>Generated on {self.timestamp.strftime('%Y-%m-%d %H:%M:%S')}</p>
        </header>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-value">{stats.total_files}</div>
                <div class="stat-label">Total Files</div>
            </div>
            <div class="stat-card">
                <div class="stat-value success">{stats.success_count}</div>
                <div class="stat-label">Successfully Migrated</div>
            </div>
            <div class="stat-card">
                <div class="stat-value danger">{stats.failed_count}</div>
                <div class="stat-label">Failed</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{success_rate:.1f}%</div>
                <div class="stat-label">Success Rate</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{stats.total_time_seconds:.1f}s</div>
                <div class="stat-label">Total Time</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{stats.patterns_detected}</div>
                <div class="stat-label">Patterns Detected</div>
            </div>
        </div>

        <div class="charts-grid">
            <div class="chart-card">
                <h3>Migration Results</h3>
                <canvas id="resultsChart"></canvas>
            </div>
            <div class="chart-card">
                <h3>Migration Time by File</h3>
                <canvas id="timeChart"></canvas>
            </div>
        </div>

        <div class="files-table">
            <h3>Migrated Files</h3>
            <table>
                <thead>
                    <tr>
                        <th>File Name</th>
                        <th>Status</th>
                        <th>Patterns</th>
                        <th>Lines</th>
                        <th>Time</th>
                    </tr>
                </thead>
                <tbody>
                    {file_rows or '<tr><td colspan="5">No files migrated</td></tr>'}
                </tbody>
            </table>
        </div>

        <footer>
            <p>Generated by QAMigrate - AI-Powered Selenium to Playwright Migration</p>
        </footer>
    </div>

    <script>
        // Results pie chart
        new Chart(document.getElementById('resultsChart'), {{
            type: 'doughnut',
            data: {{
                labels: ['Success', 'Failed'],
                datasets: [{{
                    data: [{stats.success_count}, {stats.failed_count}],
                    backgroundColor: ['#28a745', '#dc3545']
                }}]
            }},
            options: {{
                responsive: true,
                plugins: {{
                    legend: {{ position: 'bottom' }}
                }}
            }}
        }});

        // Time bar chart
        const fileNames = {[f.get('name', 'Unknown') for f in stats.files]};
        const fileTimes = {[f.get('time', 0) for f in stats.files]};
        
        new Chart(document.getElementById('timeChart'), {{
            type: 'bar',
            data: {{
                labels: fileNames,
                datasets: [{{
                    label: 'Time (seconds)',
                    data: fileTimes,
                    backgroundColor: '#0066cc'
                }}]
            }},
            options: {{
                responsive: true,
                plugins: {{
                    legend: {{ display: false }}
                }},
                scales: {{
                    y: {{ beginAtZero: true }}
                }}
            }}
        }});
    </script>
</body>
</html>"""

    def generate_json(
        self,
        stats: MigrationStats,
        output_path: Path,
    ) -> Path:
        """Generate a JSON report."""
        import json

        data = {
            "timestamp": self.timestamp.isoformat(),
            "summary": {
                "total_files": stats.total_files,
                "success_count": stats.success_count,
                "failed_count": stats.failed_count,
                "success_rate": (
                    stats.success_count / stats.total_files * 100
                    if stats.total_files > 0
                    else 0
                ),
                "total_time_seconds": stats.total_time_seconds,
                "patterns_detected": stats.patterns_detected,
                "lines_migrated": stats.lines_migrated,
            },
            "files": stats.files,
        }

        output_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        return output_path
