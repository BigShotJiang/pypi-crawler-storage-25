"""
Database Persistence Layer.

SQLite-based storage for migration history and job tracking.
"""

import json
import sqlite3
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Generator

import structlog

logger = structlog.get_logger(__name__)


@dataclass
class MigrationRecord:
    """Record of a file migration."""

    id: int | None
    file_path: str
    output_path: str | None
    status: str  # pending, running, completed, failed
    created_at: datetime
    completed_at: datetime | None
    error: str | None
    patterns_detected: int
    compilation_attempts: int
    execution_time_ms: int


@dataclass
class JobRecord:
    """Record of a background job."""

    id: str
    job_type: str  # migration, verification, scan
    status: str  # queued, running, completed, failed
    params: dict[str, Any]
    result: dict[str, Any] | None
    created_at: datetime
    started_at: datetime | None
    completed_at: datetime | None
    error: str | None


class Database:
    """SQLite database for QAMigrate persistence."""

    def __init__(self, db_path: Path | str | None = None) -> None:
        """Initialize database connection."""
        if db_path is None:
            db_path = Path.cwd() / ".qamigrate" / "qamigrate.db"
        
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        
        self._init_schema()
        logger.info("Database initialized", path=str(self.db_path))

    @contextmanager
    def _connection(self) -> Generator[sqlite3.Connection, None, None]:
        """Get database connection context manager."""
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _init_schema(self) -> None:
        """Initialize database schema."""
        with self._connection() as conn:
            cursor = conn.cursor()
            
            # Migrations table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS migrations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    file_path TEXT NOT NULL,
                    output_path TEXT,
                    status TEXT NOT NULL DEFAULT 'pending',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    completed_at TIMESTAMP,
                    error TEXT,
                    patterns_detected INTEGER DEFAULT 0,
                    compilation_attempts INTEGER DEFAULT 0,
                    execution_time_ms INTEGER DEFAULT 0
                )
            """)
            
            # Jobs table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS jobs (
                    id TEXT PRIMARY KEY,
                    job_type TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'queued',
                    params TEXT,
                    result TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    started_at TIMESTAMP,
                    completed_at TIMESTAMP,
                    error TEXT
                )
            """)
            
            # Projects table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS projects (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    path TEXT UNIQUE NOT NULL,
                    name TEXT,
                    last_scanned TIMESTAMP,
                    file_count INTEGER DEFAULT 0,
                    page_object_count INTEGER DEFAULT 0,
                    test_class_count INTEGER DEFAULT 0,
                    scan_result TEXT
                )
            """)
            
            # Settings table (key-value store)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Users table for authentication
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    email TEXT UNIQUE NOT NULL,
                    password_hash TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    last_login TIMESTAMP
                )
            """)
            
            # Indexes
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_migrations_status ON migrations(status)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_migrations_file ON migrations(file_path)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_jobs_type ON jobs(job_type)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_users_email ON users(email)")

    # =========== Migration Methods ===========

    def create_migration(
        self,
        file_path: str,
        patterns_detected: int = 0,
    ) -> int:
        """Create a new migration record."""
        with self._connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO migrations (file_path, patterns_detected)
                VALUES (?, ?)
                """,
                (file_path, patterns_detected),
            )
            return cursor.lastrowid or 0

    def update_migration(
        self,
        migration_id: int,
        status: str | None = None,
        output_path: str | None = None,
        error: str | None = None,
        compilation_attempts: int | None = None,
        execution_time_ms: int | None = None,
    ) -> None:
        """Update a migration record."""
        updates: list[str] = []
        params: list[Any] = []
        
        if status is not None:
            updates.append("status = ?")
            params.append(status)
            if status in ("completed", "failed"):
                updates.append("completed_at = CURRENT_TIMESTAMP")
        
        if output_path is not None:
            updates.append("output_path = ?")
            params.append(output_path)
        
        if error is not None:
            updates.append("error = ?")
            params.append(error)
        
        if compilation_attempts is not None:
            updates.append("compilation_attempts = ?")
            params.append(compilation_attempts)
        
        if execution_time_ms is not None:
            updates.append("execution_time_ms = ?")
            params.append(execution_time_ms)
        
        if not updates:
            return
        
        params.append(migration_id)
        
        with self._connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                f"UPDATE migrations SET {', '.join(updates)} WHERE id = ?",
                params,
            )

    def get_migration(self, migration_id: int) -> MigrationRecord | None:
        """Get a migration by ID."""
        with self._connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM migrations WHERE id = ?", (migration_id,))
            row = cursor.fetchone()
            if row:
                return self._row_to_migration(row)
            return None

    def get_migrations_by_status(self, status: str) -> list[MigrationRecord]:
        """Get all migrations with a given status."""
        with self._connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM migrations WHERE status = ? ORDER BY created_at DESC", (status,))
            return [self._row_to_migration(row) for row in cursor.fetchall()]

    def get_recent_migrations(self, limit: int = 50) -> list[MigrationRecord]:
        """Get recent migrations."""
        with self._connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM migrations ORDER BY created_at DESC LIMIT ?", (limit,))
            return [self._row_to_migration(row) for row in cursor.fetchall()]

    def _row_to_migration(self, row: sqlite3.Row) -> MigrationRecord:
        """Convert a database row to MigrationRecord."""
        return MigrationRecord(
            id=row["id"],
            file_path=row["file_path"],
            output_path=row["output_path"],
            status=row["status"],
            created_at=datetime.fromisoformat(row["created_at"]) if row["created_at"] else datetime.now(),
            completed_at=datetime.fromisoformat(row["completed_at"]) if row["completed_at"] else None,
            error=row["error"],
            patterns_detected=row["patterns_detected"],
            compilation_attempts=row["compilation_attempts"],
            execution_time_ms=row["execution_time_ms"],
        )

    # =========== Job Methods ===========

    def create_job(
        self,
        job_id: str,
        job_type: str,
        params: dict[str, Any],
    ) -> str:
        """Create a new job record."""
        with self._connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO jobs (id, job_type, params)
                VALUES (?, ?, ?)
                """,
                (job_id, job_type, json.dumps(params)),
            )
            return job_id

    def update_job(
        self,
        job_id: str,
        status: str | None = None,
        result: dict[str, Any] | None = None,
        error: str | None = None,
    ) -> None:
        """Update a job record."""
        updates: list[str] = []
        params: list[Any] = []
        
        if status is not None:
            updates.append("status = ?")
            params.append(status)
            if status == "running":
                updates.append("started_at = CURRENT_TIMESTAMP")
            elif status in ("completed", "failed"):
                updates.append("completed_at = CURRENT_TIMESTAMP")
        
        if result is not None:
            updates.append("result = ?")
            params.append(json.dumps(result))
        
        if error is not None:
            updates.append("error = ?")
            params.append(error)
        
        if not updates:
            return
        
        params.append(job_id)
        
        with self._connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                f"UPDATE jobs SET {', '.join(updates)} WHERE id = ?",
                params,
            )

    def get_job(self, job_id: str) -> JobRecord | None:
        """Get a job by ID."""
        with self._connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM jobs WHERE id = ?", (job_id,))
            row = cursor.fetchone()
            if row:
                return self._row_to_job(row)
            return None

    def get_pending_jobs(self, job_type: str | None = None) -> list[JobRecord]:
        """Get pending jobs."""
        with self._connection() as conn:
            cursor = conn.cursor()
            if job_type:
                cursor.execute(
                    "SELECT * FROM jobs WHERE status = 'queued' AND job_type = ? ORDER BY created_at",
                    (job_type,),
                )
            else:
                cursor.execute("SELECT * FROM jobs WHERE status = 'queued' ORDER BY created_at")
            return [self._row_to_job(row) for row in cursor.fetchall()]

    def _row_to_job(self, row: sqlite3.Row) -> JobRecord:
        """Convert a database row to JobRecord."""
        return JobRecord(
            id=row["id"],
            job_type=row["job_type"],
            status=row["status"],
            params=json.loads(row["params"]) if row["params"] else {},
            result=json.loads(row["result"]) if row["result"] else None,
            created_at=datetime.fromisoformat(row["created_at"]) if row["created_at"] else datetime.now(),
            started_at=datetime.fromisoformat(row["started_at"]) if row["started_at"] else None,
            completed_at=datetime.fromisoformat(row["completed_at"]) if row["completed_at"] else None,
            error=row["error"],
        )

    # =========== Project Methods ===========

    def save_project(
        self,
        path: str,
        name: str,
        file_count: int,
        page_object_count: int,
        test_class_count: int,
        scan_result: dict[str, Any] | None = None,
    ) -> int:
        """Save or update a project."""
        with self._connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO projects (path, name, file_count, page_object_count, test_class_count, scan_result, last_scanned)
                VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                ON CONFLICT(path) DO UPDATE SET
                    name = excluded.name,
                    file_count = excluded.file_count,
                    page_object_count = excluded.page_object_count,
                    test_class_count = excluded.test_class_count,
                    scan_result = excluded.scan_result,
                    last_scanned = CURRENT_TIMESTAMP
                """,
                (path, name, file_count, page_object_count, test_class_count, json.dumps(scan_result) if scan_result else None),
            )
            return cursor.lastrowid or 0

    def get_projects(self) -> list[dict[str, Any]]:
        """Get all projects."""
        with self._connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM projects ORDER BY last_scanned DESC")
            return [dict(row) for row in cursor.fetchall()]

    # =========== Stats Methods ===========

    def get_stats(self) -> dict[str, Any]:
        """Get overall statistics."""
        with self._connection() as conn:
            cursor = conn.cursor()
            
            cursor.execute("SELECT COUNT(*) as count FROM migrations")
            total_migrations = cursor.fetchone()["count"]
            
            cursor.execute("SELECT COUNT(*) as count FROM migrations WHERE status = 'completed'")
            completed = cursor.fetchone()["count"]
            
            cursor.execute("SELECT COUNT(*) as count FROM migrations WHERE status = 'failed'")
            failed = cursor.fetchone()["count"]
            
            cursor.execute("SELECT AVG(execution_time_ms) as avg FROM migrations WHERE status = 'completed'")
            avg_time = cursor.fetchone()["avg"] or 0
            
            return {
                "total_migrations": total_migrations,
                "completed": completed,
                "failed": failed,
                "success_rate": (completed / total_migrations * 100) if total_migrations > 0 else 0,
                "avg_execution_time_ms": int(avg_time),
            }

    def get_daily_stats(self, days: int = 7) -> list[dict[str, Any]]:
        """Get daily migration statistics for the last N days."""
        with self._connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                SELECT 
                    date(created_at) as date,
                    COUNT(*) as total,
                    SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
                    SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed
                FROM migrations
                WHERE created_at >= date('now', ?)
                GROUP BY date(created_at)
                ORDER BY date(created_at)
                """,
                (f"-{days} days",),
            )
            return [dict(row) for row in cursor.fetchall()]

    def get_weekly_summary(self) -> dict[str, Any]:
        """Get weekly migration summary with recent activity."""
        stats = self.get_stats()
        daily = self.get_daily_stats(7)
        
        # Calculate weekly totals
        weekly_completed = sum(d.get("completed", 0) for d in daily)
        weekly_failed = sum(d.get("failed", 0) for d in daily)
        
        return {
            **stats,
            "weekly_completed": weekly_completed,
            "weekly_failed": weekly_failed,
            "daily_stats": daily,
        }

    def get_setting(self, key: str, default: str | None = None) -> str | None:
        """Get a setting value by key."""
        with self._connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT value FROM settings WHERE key = ?", (key,))
            row = cursor.fetchone()
            return row["value"] if row else default

    def set_setting(self, key: str, value: str) -> None:
        """Set a setting value."""
        with self._connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO settings (key, value, updated_at)
                VALUES (?, ?, CURRENT_TIMESTAMP)
                ON CONFLICT(key) DO UPDATE SET
                    value = excluded.value,
                    updated_at = CURRENT_TIMESTAMP
                """,
                (key, value),
            )

    def get_all_settings(self) -> dict[str, str]:
        """Get all settings as a dictionary."""
        with self._connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT key, value FROM settings")
            return {row["key"]: row["value"] for row in cursor.fetchall()}

    def set_all_settings(self, settings: dict[str, str]) -> None:
        """Set multiple settings at once."""
        for key, value in settings.items():
            self.set_setting(key, value)

    # =========== User Methods ===========

    def create_user(self, email: str, password_hash: str) -> int:
        """Create a new user."""
        with self._connection() as conn:
            cursor = conn.cursor()
            try:
                cursor.execute(
                    """
                    INSERT INTO users (email, password_hash)
                    VALUES (?, ?)
                    """,
                    (email, password_hash),
                )
                return cursor.lastrowid or 0
            except sqlite3.IntegrityError:
                raise ValueError("Email already exists")

    def get_user_by_email(self, email: str) -> dict[str, Any] | None:
        """Get a user by email."""
        with self._connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM users WHERE email = ?", (email,))
            row = cursor.fetchone()
            if row:
                return dict(row)
            return None

    def update_last_login(self, user_id: int) -> None:
        """Update user's last login time."""
        with self._connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?",
                (user_id,),
            )


# Global database instance
_db: Database | None = None


def get_database() -> Database:
    """Get or create database instance."""
    global _db
    if _db is None:
        _db = Database()
    return _db
