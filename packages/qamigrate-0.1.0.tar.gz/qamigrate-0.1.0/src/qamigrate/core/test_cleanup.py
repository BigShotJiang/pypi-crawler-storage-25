"""
Test Class Post-Processor.

Cleans up test class migration artifacts like duplicate imports,
trailing code snippets, and malformed structures.
"""

import re
from pathlib import Path

import structlog

logger = structlog.get_logger(__name__)


def clean_test_class(code: str) -> str:
    """
    Clean up test class migration artifacts.

    Args:
        code: Raw generated test class code

    Returns:
        Cleaned test class code
    """
    # Remove duplicate imports
    code = _deduplicate_imports(code)

    # Remove trailing artifacts after class closing brace
    code = _remove_trailing_artifacts(code)

    # Fix duplicate annotations
    code = _fix_duplicate_annotations(code)

    # Remove markdown code blocks if present
    code = _remove_markdown_artifacts(code)

    # Ensure proper class structure
    code = _fix_class_structure(code)

    return code


def _deduplicate_imports(code: str) -> str:
    """Remove duplicate import statements."""
    lines = code.split("\n")
    seen_imports = set()
    result = []

    for line in lines:
        stripped = line.strip()
        if stripped.startswith("import "):
            if stripped not in seen_imports:
                seen_imports.add(stripped)
                result.append(line)
        else:
            result.append(line)

    return "\n".join(result)


def _remove_trailing_artifacts(code: str) -> str:
    """Remove code artifacts after the class closing brace."""
    # Find the package declaration
    package_match = re.search(r"^package\s+[\w.]+;", code, re.MULTILINE)

    # Find the class declaration
    class_match = re.search(
        r"public\s+(?:abstract\s+)?class\s+\w+",
        code,
    )

    if not class_match:
        return code

    # Count braces to find class end
    class_start = class_match.start()
    brace_count = 0
    class_end = len(code)
    in_class = False

    for i, char in enumerate(code[class_start:], start=class_start):
        if char == "{":
            brace_count += 1
            in_class = True
        elif char == "}":
            brace_count -= 1
            if in_class and brace_count == 0:
                class_end = i + 1
                break

    # Keep only package, imports, and class body
    result = code[:class_end]

    # Add final newline if missing
    if not result.endswith("\n"):
        result += "\n"

    return result


def _fix_duplicate_annotations(code: str) -> str:
    """Remove duplicate JUnit annotations."""
    # Remove duplicate @BeforeAll
    code = re.sub(
        r"(@BeforeAll\s*\n\s*@BeforeAll)",
        "@BeforeAll",
        code,
    )

    # Remove duplicate @AfterAll
    code = re.sub(
        r"(@AfterAll\s*\n\s*@AfterAll)",
        "@AfterAll",
        code,
    )

    # Remove duplicate @BeforeEach
    code = re.sub(
        r"(@BeforeEach\s*\n\s*@BeforeEach)",
        "@BeforeEach",
        code,
    )

    # Remove duplicate @AfterEach
    code = re.sub(
        r"(@AfterEach\s*\n\s*@AfterEach)",
        "@AfterEach",
        code,
    )

    # Remove duplicate @Test
    code = re.sub(
        r"(@Test\s*\n\s*@Test)",
        "@Test",
        code,
    )

    return code


def _remove_markdown_artifacts(code: str) -> str:
    """Remove markdown code block markers."""
    # Remove ```java and ``` markers
    code = re.sub(r"```java\s*\n?", "", code)
    code = re.sub(r"```\s*\n?", "", code)

    return code


def _fix_class_structure(code: str) -> str:
    """Ensure proper class structure with no duplicate class declarations."""
    # Find all class declarations
    class_pattern = r"public\s+(?:abstract\s+)?class\s+(\w+)"
    matches = list(re.finditer(class_pattern, code))

    if len(matches) > 1:
        # Keep only the first class declaration
        first_match = matches[0]
        logger.warning(
            "Multiple class declarations found, keeping first",
            class_name=first_match.group(1),
            count=len(matches),
        )

        # Find end of first class
        brace_count = 0
        class_start = first_match.start()
        class_end = len(code)
        in_class = False

        for i, char in enumerate(code[class_start:], start=class_start):
            if char == "{":
                brace_count += 1
                in_class = True
            elif char == "}":
                brace_count -= 1
                if in_class and brace_count == 0:
                    class_end = i + 1
                    break

        # Extract imports and package from before first class
        pre_class = code[:class_start]
        class_body = code[class_start:class_end]

        code = pre_class + class_body

    return code


def process_test_file(file_path: Path) -> bool:
    """
    Process and clean a test file in place.

    Args:
        file_path: Path to test Java file

    Returns:
        True if changes were made
    """
    try:
        original = file_path.read_text(encoding="utf-8")
        cleaned = clean_test_class(original)

        if cleaned != original:
            file_path.write_text(cleaned, encoding="utf-8")
            logger.info("Cleaned test file", file=str(file_path))
            return True

        return False

    except Exception as e:
        logger.error("Failed to process test file", file=str(file_path), error=str(e))
        return False
