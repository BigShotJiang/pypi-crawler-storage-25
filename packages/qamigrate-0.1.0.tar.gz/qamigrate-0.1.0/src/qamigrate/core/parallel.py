"""
Parallel Migration Executor.

Supports concurrent file migration with progress tracking.
"""

import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

import structlog

logger = structlog.get_logger(__name__)


@dataclass
class MigrationTask:
    """A single migration task."""

    file_path: Path
    project_path: Path
    status: str = "pending"  # pending, running, completed, failed
    error: str | None = None
    output_path: Path | None = None
    start_time: float | None = None
    end_time: float | None = None

    @property
    def duration(self) -> float:
        """Get task duration in seconds."""
        if self.start_time and self.end_time:
            return self.end_time - self.start_time
        return 0.0


@dataclass
class ParallelProgress:
    """Progress tracking for parallel execution."""

    total: int = 0
    completed: int = 0
    failed: int = 0
    current_file: str = ""
    files_in_progress: list[str] = field(default_factory=list)

    @property
    def percentage(self) -> float:
        """Get completion percentage."""
        if self.total == 0:
            return 0.0
        return (self.completed + self.failed) / self.total * 100


class ParallelExecutor:
    """
    Execute migrations in parallel with progress tracking.

    Uses ThreadPoolExecutor for controlled concurrency.
    """

    def __init__(
        self,
        max_workers: int = 4,
        on_progress: Callable[[ParallelProgress], None] | None = None,
    ) -> None:
        """
        Initialize parallel executor.

        Args:
            max_workers: Maximum concurrent migrations
            on_progress: Callback for progress updates
        """
        self.max_workers = max_workers
        self.on_progress = on_progress
        self.progress = ParallelProgress()
        self.tasks: list[MigrationTask] = []

    def migrate_batch(
        self,
        files: list[Path],
        project_path: Path,
        migrate_fn: Callable[[Path, Path], tuple[bool, str | None, Path | None]],
    ) -> list[MigrationTask]:
        """
        Migrate multiple files in parallel.

        Args:
            files: List of files to migrate
            project_path: Project root path
            migrate_fn: Migration function that takes (file_path, project_path)
                       and returns (success, error, output_path)

        Returns:
            List of completed MigrationTask objects
        """
        self.tasks = [
            MigrationTask(file_path=f, project_path=project_path) for f in files
        ]
        self.progress = ParallelProgress(total=len(files))

        logger.info(
            "Starting parallel migration",
            files=len(files),
            workers=self.max_workers,
        )

        start_time = time.time()

        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            # Submit all tasks
            future_to_task = {
                executor.submit(self._migrate_single, task, migrate_fn): task
                for task in self.tasks
            }

            # Process completed tasks
            for future in as_completed(future_to_task):
                task = future_to_task[future]
                try:
                    future.result()
                except Exception as e:
                    task.status = "failed"
                    task.error = str(e)
                    self.progress.failed += 1
                    logger.error(
                        "Migration task failed",
                        file=str(task.file_path),
                        error=str(e),
                    )

                # Update progress
                self._update_progress(task)

        total_time = time.time() - start_time

        logger.info(
            "Parallel migration complete",
            total=self.progress.total,
            completed=self.progress.completed,
            failed=self.progress.failed,
            time_seconds=f"{total_time:.1f}",
        )

        return self.tasks

    def _migrate_single(
        self,
        task: MigrationTask,
        migrate_fn: Callable[[Path, Path], tuple[bool, str | None, Path | None]],
    ) -> None:
        """Execute a single migration task."""
        task.status = "running"
        task.start_time = time.time()

        # Add to in-progress list
        self.progress.files_in_progress.append(task.file_path.name)
        self.progress.current_file = task.file_path.name

        try:
            success, error, output_path = migrate_fn(task.file_path, task.project_path)

            task.end_time = time.time()

            if success:
                task.status = "completed"
                task.output_path = output_path
                self.progress.completed += 1
            else:
                task.status = "failed"
                task.error = error
                self.progress.failed += 1

        except Exception as e:
            task.end_time = time.time()
            task.status = "failed"
            task.error = str(e)
            self.progress.failed += 1
            raise

        finally:
            # Remove from in-progress list
            if task.file_path.name in self.progress.files_in_progress:
                self.progress.files_in_progress.remove(task.file_path.name)

    def _update_progress(self, task: MigrationTask) -> None:
        """Update progress and notify callback."""
        if self.on_progress:
            try:
                self.on_progress(self.progress)
            except Exception as e:
                logger.warning("Progress callback failed", error=str(e))

    def get_summary(self) -> dict:
        """Get migration summary."""
        completed_tasks = [t for t in self.tasks if t.status == "completed"]
        failed_tasks = [t for t in self.tasks if t.status == "failed"]

        return {
            "total": len(self.tasks),
            "completed": len(completed_tasks),
            "failed": len(failed_tasks),
            "success_rate": (
                len(completed_tasks) / len(self.tasks) * 100 if self.tasks else 0
            ),
            "total_time": sum(t.duration for t in self.tasks),
            "avg_time_per_file": (
                sum(t.duration for t in self.tasks) / len(self.tasks)
                if self.tasks
                else 0
            ),
            "failed_files": [
                {"file": str(t.file_path.name), "error": t.error}
                for t in failed_tasks
            ],
        }
