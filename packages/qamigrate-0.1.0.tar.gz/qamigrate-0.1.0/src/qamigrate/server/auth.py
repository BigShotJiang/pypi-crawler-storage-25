"""
Authentication Module.

JWT-based authentication with bcrypt password hashing.
"""

import hashlib
import hmac
import os
import secrets
from datetime import datetime, timedelta
from typing import Any

import structlog

from qamigrate.core.database import get_database

logger = structlog.get_logger(__name__)

# Secret key for JWT - MUST be set in production via environment variable
SECRET_KEY = os.environ.get("QAMIGRATE_JWT_SECRET")
if not SECRET_KEY:
    # Generate random key for development (warn in logs)
    SECRET_KEY = secrets.token_hex(32)
    logger.warning("JWT secret not set! Using random key. Set QAMIGRATE_JWT_SECRET in production.")

ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24  # 24 hours


def hash_password(password: str) -> str:
    """Hash a password using SHA-256 with salt."""
    salt = secrets.token_hex(16)
    hashed = hashlib.pbkdf2_hmac('sha256', password.encode(), salt.encode(), 100000)
    return f"{salt}${hashed.hex()}"


def verify_password(password: str, password_hash: str) -> bool:
    """Verify a password against its hash."""
    try:
        salt, hashed = password_hash.split('$')
        new_hash = hashlib.pbkdf2_hmac('sha256', password.encode(), salt.encode(), 100000)
        return hmac.compare_digest(hashed, new_hash.hex())
    except (ValueError, AttributeError):
        return False


def create_access_token(data: dict[str, Any], expires_delta: timedelta | None = None) -> str:
    """Create a JWT access token."""
    import base64
    import json
    
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({"exp": expire.isoformat()})
    
    # Simple JWT implementation (header.payload.signature)
    header = base64.urlsafe_b64encode(json.dumps({"alg": "HS256", "typ": "JWT"}).encode()).decode()
    payload = base64.urlsafe_b64encode(json.dumps(to_encode).encode()).decode()
    signature = hmac.new(SECRET_KEY.encode(), f"{header}.{payload}".encode(), hashlib.sha256).hexdigest()
    
    return f"{header}.{payload}.{signature}"


def decode_token(token: str) -> dict[str, Any] | None:
    """Decode and verify a JWT token."""
    import base64
    import json
    
    try:
        header, payload, signature = token.split('.')
        
        # Verify signature
        expected_sig = hmac.new(SECRET_KEY.encode(), f"{header}.{payload}".encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(signature, expected_sig):
            return None
        
        # Decode payload
        data = json.loads(base64.urlsafe_b64decode(payload + '=='))
        
        # Check expiration
        exp = datetime.fromisoformat(data.get("exp", "1970-01-01"))
        if exp < datetime.utcnow():
            return None
        
        return data
    except Exception:
        return None


def register_user(email: str, password: str) -> dict[str, Any]:
    """Register a new user."""
    db = get_database()
    password_hash = hash_password(password)
    
    try:
        user_id = db.create_user(email, password_hash)
        return {
            "id": user_id,
            "email": email,
            "token": create_access_token({"sub": email, "user_id": user_id}),
        }
    except ValueError as e:
        raise ValueError(str(e))


def login_user(email: str, password: str) -> dict[str, Any] | None:
    """Authenticate user and return token."""
    db = get_database()
    user = db.get_user_by_email(email)
    
    if not user:
        return None
    
    if not verify_password(password, user["password_hash"]):
        return None
    
    db.update_last_login(user["id"])
    
    return {
        "id": user["id"],
        "email": user["email"],
        "token": create_access_token({"sub": email, "user_id": user["id"]}),
    }


def get_current_user(token: str) -> dict[str, Any] | None:
    """Get current user from token."""
    data = decode_token(token)
    if not data:
        return None
    
    db = get_database()
    return db.get_user_by_email(data.get("sub", ""))
