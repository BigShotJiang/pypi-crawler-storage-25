"""
Security Middleware for FastAPI.

Provides rate limiting, security headers, and request validation.
"""

import time
from typing import Callable

from fastapi import FastAPI, Request, Response
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

import structlog

from qamigrate.core.security import RateLimiter, detect_prompt_injection

logger = structlog.get_logger(__name__)


class RateLimitMiddleware(BaseHTTPMiddleware):
    """
    Rate limiting middleware using token bucket algorithm.
    """

    def __init__(
        self,
        app: FastAPI,
        rate: float = 10.0,  # tokens per second
        capacity: int = 100,  # burst capacity
        redis_client=None,
    ) -> None:
        super().__init__(app)
        self.limiter = RateLimiter(rate, capacity, redis_client)

    async def dispatch(
        self,
        request: Request,
        call_next: Callable,
    ) -> Response:
        # Get client identifier (IP or user ID)
        client_ip = request.client.host if request.client else "unknown"
        
        # Check if authenticated (use user ID instead of IP)
        auth_header = request.headers.get("Authorization", "")
        if auth_header.startswith("Bearer "):
            key = f"user:{auth_header[7:20]}"  # First 13 chars of token
        else:
            key = f"ip:{client_ip}"

        # Check rate limit
        allowed, remaining = self.limiter.allow(key)

        if not allowed:
            logger.warning(
                "Rate limit exceeded",
                client=key,
                path=request.url.path,
            )
            return JSONResponse(
                status_code=429,
                content={
                    "detail": "Rate limit exceeded. Please slow down.",
                    "retry_after": 10,
                },
                headers={
                    "X-RateLimit-Remaining": "0",
                    "Retry-After": "10",
                },
            )

        response = await call_next(request)

        # Add rate limit headers
        response.headers["X-RateLimit-Remaining"] = str(remaining)

        return response


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """
    Add security headers to all responses.
    """

    async def dispatch(
        self,
        request: Request,
        call_next: Callable,
    ) -> Response:
        response = await call_next(request)

        # Security headers
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["Permissions-Policy"] = "geolocation=(), microphone=()"

        # CORS headers (adjust for production)
        if request.headers.get("Origin"):
            response.headers["Access-Control-Allow-Origin"] = request.headers["Origin"]
            response.headers["Access-Control-Allow-Credentials"] = "true"

        # Content Security Policy for API
        if request.url.path.startswith("/api"):
            response.headers["Content-Security-Policy"] = "default-src 'none'"

        return response


class RequestValidationMiddleware(BaseHTTPMiddleware):
    """
    Validate incoming requests for prompt injection and other attacks.
    """

    # Paths that need prompt injection checking
    PROTECTED_PATHS = ["/api/migrate", "/api/scan"]

    async def dispatch(
        self,
        request: Request,
        call_next: Callable,
    ) -> Response:
        # Only check POST/PUT requests to protected paths
        if request.method in ("POST", "PUT"):
            for protected in self.PROTECTED_PATHS:
                if request.url.path.startswith(protected):
                    # Read body
                    body = await request.body()

                    if body:
                        try:
                            body_text = body.decode("utf-8")

                            # Check for prompt injection
                            is_suspicious, pattern = detect_prompt_injection(body_text)

                            if is_suspicious:
                                logger.warning(
                                    "Potential prompt injection blocked",
                                    path=request.url.path,
                                    pattern=pattern,
                                )
                                return JSONResponse(
                                    status_code=400,
                                    content={
                                        "detail": "Request contains potentially malicious content",
                                    },
                                )
                        except Exception:
                            pass  # If we can't decode, let it through for other validation

        return await call_next(request)


class TimingMiddleware(BaseHTTPMiddleware):
    """
    Add request timing headers for performance monitoring.
    """

    async def dispatch(
        self,
        request: Request,
        call_next: Callable,
    ) -> Response:
        start_time = time.perf_counter()

        response = await call_next(request)

        process_time = time.perf_counter() - start_time
        response.headers["X-Process-Time"] = f"{process_time:.3f}"

        # Log slow requests
        if process_time > 1.0:
            logger.warning(
                "Slow request",
                path=request.url.path,
                time_seconds=f"{process_time:.3f}",
            )

        return response


def setup_security_middleware(app: FastAPI, redis_client=None) -> None:
    """
    Setup all security middleware for the FastAPI app.

    Args:
        app: FastAPI application
        redis_client: Optional Redis client for distributed rate limiting
    """
    # Order matters! Add in reverse order of execution
    app.add_middleware(TimingMiddleware)
    app.add_middleware(RequestValidationMiddleware)
    app.add_middleware(SecurityHeadersMiddleware)
    app.add_middleware(RateLimitMiddleware, redis_client=redis_client)

    logger.info("Security middleware configured")
