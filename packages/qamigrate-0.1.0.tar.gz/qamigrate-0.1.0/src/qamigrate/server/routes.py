"""
REST API Routes.

Endpoints for migration management and status.
"""

import os
from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException, Header
from pydantic import BaseModel, EmailStr

from qamigrate.agents.pipeline import run_migration
from qamigrate.agents.scanner import ScannerAgent
from qamigrate.core.config import get_config
from qamigrate.core.database import get_database

router = APIRouter(tags=["migrations"])

# Security: Blocked system paths (case-insensitive on Windows)
BLOCKED_PATHS = [
    "/etc", "/var", "/usr", "/bin", "/sbin", "/root", "/boot", "/proc", "/sys",
    "c:/windows", "c:/program files", "c:/program files (x86)", "c:/programdata",
    "c:/users/all users", "c:/system volume information",
]

# Security: Allowed project roots (if set, only these paths allowed)
ALLOWED_ROOTS = os.environ.get("QAMIGRATE_ALLOWED_PATHS", "").split(",") if os.environ.get("QAMIGRATE_ALLOWED_PATHS") else []


def validate_path(path: Path, operation: str = "access") -> None:
    """
    Validate that a path is safe to access.
    
    Raises HTTPException if path is blocked or outside allowed roots.
    """
    resolved = path.resolve()
    path_lower = str(resolved).lower().replace("\\", "/")
    
    # Check blocked system paths
    for blocked in BLOCKED_PATHS:
        if path_lower.startswith(blocked):
            raise HTTPException(
                status_code=403, 
                detail=f"Access to system directory '{blocked}' is not allowed"
            )
    
    # If allowed roots configured, check path is within one of them
    if ALLOWED_ROOTS and ALLOWED_ROOTS[0]:
        allowed = False
        for root in ALLOWED_ROOTS:
            root_path = Path(root.strip()).resolve()
            try:
                resolved.relative_to(root_path)
                allowed = True
                break
            except ValueError:
                continue
        
        if not allowed:
            raise HTTPException(
                status_code=403,
                detail=f"Path must be within allowed project directories"
            )


async def get_optional_user(authorization: str = Header(None)) -> dict[str, Any] | None:
    """
    Get current user from Authorization header (optional).
    
    Returns user dict if valid token, None if no token, raises 401 if invalid token.
    """
    if not authorization:
        return None
    
    if not authorization.startswith("Bearer "):
        return None
    
    from qamigrate.server.auth import get_current_user
    token = authorization[7:]
    user = get_current_user(token)
    
    return user


async def require_user(authorization: str = Header(...)) -> dict[str, Any]:
    """
    Require authenticated user.
    
    Raises 401 if not authenticated.
    """
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    from qamigrate.server.auth import get_current_user
    token = authorization[7:]
    user = get_current_user(token)
    
    if not user:
        raise HTTPException(status_code=401, detail="Invalid or expired token")
    
    return user


class ScanRequest(BaseModel):
    """Request to scan a project."""

    project_path: str


class MigrateRequest(BaseModel):
    """Request to migrate a file."""

    file_path: str
    project_path: str


class MigrationStatus(BaseModel):
    """Status of a migration."""

    file_path: str
    status: str
    phase: str
    progress: int
    error: str | None = None
    output_path: str | None = None


# In-memory storage for active migrations (would be Redis/DB in production)
_migrations: dict[str, MigrationStatus] = {}


# Rate limiting state (simple in-memory, use Redis in production)
_rate_limit_state: dict[str, list[float]] = {}


@router.post("/scan")
async def scan_project(request: ScanRequest) -> dict[str, Any]:
    """
    Scan a Selenium project and return analysis.

    Args:
        request: ScanRequest with project path

    Returns:
        Scan results including patterns and complexity
    """
    project_path = Path(request.project_path)
    
    # Security: Validate path is safe
    validate_path(project_path, "scan")

    if not project_path.exists():
        raise HTTPException(status_code=404, detail="Project path not found")

    config = get_config()
    scanner = ScannerAgent(config.scanner)

    try:
        result = scanner.scan_project(project_path)
        result_dict = result.to_dict()
        
        # Save to database for history
        db = get_database()
        db.save_project(
            path=str(project_path),
            name=project_path.name,
            file_count=result.file_count,
            page_object_count=result.page_object_count,
            test_class_count=result.test_class_count,
            scan_result=result_dict,
        )
        
        return result_dict
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/migrate")
async def start_migration(request: MigrateRequest) -> MigrationStatus:
    """
    Start migration for a file.

    Args:
        request: MigrateRequest with file and project paths

    Returns:
        Initial migration status
    """
    from qamigrate.server.websocket import send_progress_update, send_migration_complete
    import asyncio
    
    file_path = Path(request.file_path)
    project_path = Path(request.project_path)
    
    # Security: Validate paths are safe
    validate_path(file_path, "migrate")
    validate_path(project_path, "migrate")

    if not file_path.exists():
        raise HTTPException(status_code=404, detail="File not found")

    # Create initial status
    status = MigrationStatus(
        file_path=str(file_path),
        status="running",
        phase="init",
        progress=0,
    )
    _migrations[str(file_path)] = status
    
    # Send initial progress
    await send_progress_update(str(file_path), "init", 0, "Starting migration...")

    # Run migration (in production, this would be async/background)
    try:
        config = get_config()
        
        # Update progress: scanning
        await send_progress_update(str(file_path), "scanning", 20, "Analyzing file patterns...")
        
        # Run migration in thread pool to avoid blocking event loop
        result = await asyncio.to_thread(run_migration, file_path, project_path, config)
        
        # Update final status
        if result.success:
            await send_progress_update(str(file_path), "complete", 100, "Migration complete!")
            await send_migration_complete(str(file_path), True, result.output_path)
        else:
            await send_progress_update(str(file_path), "failed", 100, result.error or "Migration failed")
            await send_migration_complete(str(file_path), False, error=result.error)

        status.status = "complete" if result.success else "failed"
        status.phase = result.final_state.get("phase", "unknown")
        status.progress = 100
        status.output_path = result.output_path
        status.error = result.error

        _migrations[str(file_path)] = status
        return status

    except Exception as e:
        await send_progress_update(str(file_path), "failed", 100, str(e))
        await send_migration_complete(str(file_path), False, error=str(e))
        status.status = "failed"
        status.error = str(e)
        _migrations[str(file_path)] = status
        return status


@router.get("/migrations")
async def list_migrations() -> list[MigrationStatus]:
    """List all migrations."""
    return list(_migrations.values())


@router.get("/migrations/{file_path:path}")
async def get_migration_status(file_path: str) -> MigrationStatus:
    """
    Get status of a specific migration.

    Args:
        file_path: Path to the file

    Returns:
        Current migration status
    """
    if file_path not in _migrations:
        raise HTTPException(status_code=404, detail="Migration not found")

    return _migrations[file_path]


@router.get("/files")
async def list_project_files(project_path: str) -> list[dict[str, Any]]:
    """
    List Java files in a project.

    Args:
        project_path: Root path of the project

    Returns:
        List of file information
    """
    path = Path(project_path)

    if not path.exists():
        raise HTTPException(status_code=404, detail="Project path not found")

    files: list[dict[str, Any]] = []
    config = get_config()
    scanner = ScannerAgent(config.scanner)

    for java_file in path.rglob("*.java"):
        # Skip excluded patterns
        excluded = any(
            exc in str(java_file)
            for exc in ["target", "build", "node_modules"]
        )
        if excluded:
            continue

        try:
            analysis = scanner.scan_file(java_file)
            files.append(
                {
                    "path": str(java_file),
                    "name": java_file.name,
                    "is_page_object": analysis.is_page_object,
                    "is_test_class": analysis.is_test_class,
                    "complexity": analysis.complexity_score,
                    "pattern_count": len(analysis.patterns),
                }
            )
        except Exception:
            files.append(
                {
                    "path": str(java_file),
                    "name": java_file.name,
                    "error": "Failed to analyze",
                }
            )

    return files


@router.get("/files/{file_path:path}/code")
async def get_file_code(file_path: str) -> dict[str, str]:
    """
    Get source code of a file.

    Args:
        file_path: Path to the file

    Returns:
        Dict with original and generated code
    """
    path = Path(file_path)

    if not path.exists():
        raise HTTPException(status_code=404, detail="File not found")

    original_code = path.read_text(encoding="utf-8")

    # Check for generated Playwright version
    playwright_path = path.parent / "playwright" / path.name
    generated_code = None
    if playwright_path.exists():
        generated_code = playwright_path.read_text(encoding="utf-8")

    return {
        "original": original_code,
        "generated": generated_code or "",
    }


class VerifyRequest(BaseModel):
    """Request to verify a migration."""

    test_class: str
    project_path: str
    app_url: str = "http://host.docker.internal:8080"
    record_video: bool = True


@router.post("/verify")
async def verify_migration(request: VerifyRequest) -> dict[str, Any]:
    """
    Verify migration by running tests in Docker containers.

    Note: Docker-based verification is planned for a future release.
    Currently returns a placeholder indicating the feature is not yet available.
    """
    raise HTTPException(
        status_code=501,
        detail="Visual verification via Docker is not available yet. Coming in a future release.",
    )


# ============ Settings Endpoints ============

class SettingsRequest(BaseModel):
    """Request to update settings."""

    theme: str = "dark"
    notifications: bool = True
    autoMigrate: bool = False
    parallelJobs: int = 2
    apiKey: str = ""
    outputDir: str = "./playwright"
    language: str = "en"


@router.get("/settings")
async def get_settings() -> dict[str, Any]:
    """
    Get all application settings.

    Returns:
        Dictionary of all settings with default values
    """
    db = get_database()
    stored = db.get_all_settings()
    
    # Return stored settings with defaults
    defaults = {
        "theme": "dark",
        "notifications": "true",
        "autoMigrate": "false",
        "parallelJobs": "2",
        "apiKey": "",
        "outputDir": "./playwright",
        "language": "en",
    }
    
    # Merge stored with defaults
    for key, default in defaults.items():
        if key not in stored:
            stored[key] = default
    
    # Convert string booleans to actual booleans for frontend
    result = {}
    for key, value in stored.items():
        if value == "true":
            result[key] = True
        elif value == "false":
            result[key] = False
        elif key == "parallelJobs":
            result[key] = int(value)
        else:
            result[key] = value
    
    return result


@router.post("/settings")
async def save_settings(request: SettingsRequest) -> dict[str, str]:
    """
    Save application settings.

    Args:
        request: SettingsRequest with all settings

    Returns:
        Success message
    """
    db = get_database()
    
    # Convert to string values for storage
    settings = {
        "theme": request.theme,
        "notifications": "true" if request.notifications else "false",
        "autoMigrate": "true" if request.autoMigrate else "false",
        "parallelJobs": str(request.parallelJobs),
        "apiKey": request.apiKey,
        "outputDir": request.outputDir,
        "language": request.language,
    }
    
    db.set_all_settings(settings)
    
    return {"message": "Settings saved successfully"}


# ============ Reports Endpoints ============

@router.get("/reports")
async def get_reports() -> dict[str, Any]:
    """
    Get migration reports and statistics.

    Returns:
        Statistics including totals, success rates, and daily breakdown
    """
    db = get_database()
    
    # Get weekly summary with daily breakdown
    summary = db.get_weekly_summary()
    
    # Get recent migrations for activity feed
    recent = db.get_recent_migrations(10)
    
    return {
        **summary,
        "recent_migrations": [
            {
                "id": m.id,
                "file_path": m.file_path,
                "status": m.status,
                "created_at": m.created_at.isoformat() if m.created_at else None,
                "execution_time_ms": m.execution_time_ms,
            }
            for m in recent
        ],
    }


# ============ Auth Endpoints ============

import time
import re
from fastapi import Request


def check_rate_limit(key: str, max_requests: int, window_seconds: int) -> bool:
    """
    Simple rate limiting check.
    
    Returns True if within limit, False if exceeded.
    """
    now = time.time()
    
    if key not in _rate_limit_state:
        _rate_limit_state[key] = []
    
    # Remove old entries
    _rate_limit_state[key] = [t for t in _rate_limit_state[key] if now - t < window_seconds]
    
    if len(_rate_limit_state[key]) >= max_requests:
        return False
    
    _rate_limit_state[key].append(now)
    return True


def validate_password_strength(password: str) -> str | None:
    """
    Validate password meets complexity requirements.
    
    Returns error message if invalid, None if valid.
    """
    if len(password) < 8:
        return "Password must be at least 8 characters"
    if not re.search(r'[A-Z]', password):
        return "Password must contain at least one uppercase letter"
    if not re.search(r'[0-9]', password):
        return "Password must contain at least one number"
    return None


class RegisterRequest(BaseModel):
    """Request to register a new user."""

    email: EmailStr  # Pydantic email validation
    password: str


class LoginRequest(BaseModel):
    """Request to login."""

    email: EmailStr
    password: str


@router.post("/auth/register")
async def register(request: RegisterRequest, req: Request) -> dict[str, Any]:
    """
    Register a new user.

    Args:
        request: RegisterRequest with email and password

    Returns:
        User info with access token
    """
    from qamigrate.server.auth import register_user
    
    # Rate limit: 3 registrations per minute per IP
    client_ip = req.client.host if req.client else "unknown"
    if not check_rate_limit(f"register:{client_ip}", 3, 60):
        raise HTTPException(status_code=429, detail="Too many registration attempts. Try again later.")
    
    if not request.email or not request.password:
        raise HTTPException(status_code=400, detail="Email and password required")
    
    # Password complexity check
    password_error = validate_password_strength(request.password)
    if password_error:
        raise HTTPException(status_code=400, detail=password_error)
    
    try:
        result = register_user(request.email, request.password)
        return result
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/auth/login")
async def login(request: LoginRequest, req: Request) -> dict[str, Any]:
    """
    Login and get access token.

    Args:
        request: LoginRequest with email and password

    Returns:
        User info with access token
    """
    from qamigrate.server.auth import login_user
    
    # Rate limit: 5 login attempts per minute per IP
    client_ip = req.client.host if req.client else "unknown"
    if not check_rate_limit(f"login:{client_ip}", 5, 60):
        raise HTTPException(status_code=429, detail="Too many login attempts. Try again later.")
    
    result = login_user(request.email, request.password)
    if not result:
        raise HTTPException(status_code=401, detail="Invalid email or password")
    
    return result


@router.get("/auth/me")
async def get_me(authorization: str = "") -> dict[str, Any]:
    """
    Get current user info.

    Args:
        authorization: Bearer token from header

    Returns:
        Current user info
    """
    from qamigrate.server.auth import get_current_user
    
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    token = authorization[7:]
    user = get_current_user(token)
    
    if not user:
        raise HTTPException(status_code=401, detail="Invalid or expired token")
    
    return {
        "id": user["id"],
        "email": user["email"],
        "created_at": user.get("created_at"),
    }


# ============ History Endpoints ============

@router.get("/history")
async def get_history() -> list[dict[str, Any]]:
    """
    Get project scan history.

    Returns:
        List of previously scanned projects
    """
    db = get_database()
    projects = db.get_projects()
    
    # Clean up the results for JSON serialization
    return [
        {
            "id": p.get("id"),
            "path": p.get("path"),
            "name": p.get("name"),
            "last_scanned": p.get("last_scanned"),
            "file_count": p.get("file_count"),
            "page_object_count": p.get("page_object_count"),
            "test_class_count": p.get("test_class_count"),
        }
        for p in projects
    ]


# ============ Export Endpoints ============

class ExportRequest(BaseModel):
    """Request to export migrated files."""

    project_path: str


@router.post("/export")
async def export_migrations(request: ExportRequest) -> dict[str, Any]:
    """
    Export all migrated Playwright files as a zip.

    Args:
        request: ExportRequest with project path

    Returns:
        Path to the generated zip file
    """
    import zipfile
    import tempfile
    from datetime import datetime
    
    project_path = Path(request.project_path)
    
    # Security: Validate path is safe
    validate_path(project_path, "export")
    
    playwright_dir = project_path / "playwright"
    
    if not playwright_dir.exists():
        raise HTTPException(status_code=404, detail="No migrated files found")
    
    # Find all Java files in the playwright directory
    java_files = list(playwright_dir.glob("**/*.java"))
    
    if not java_files:
        raise HTTPException(status_code=404, detail="No migrated Java files found")
    
    # Create zip file
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    zip_filename = f"qamigrate_export_{project_path.name}_{timestamp}.zip"
    zip_path = Path(tempfile.gettempdir()) / zip_filename
    
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for file_path in java_files:
            arcname = file_path.relative_to(playwright_dir)
            zipf.write(file_path, arcname)
    
    return {
        "success": True,
        "zip_path": str(zip_path),
        "file_count": len(java_files),
        "filename": zip_filename,
    }
