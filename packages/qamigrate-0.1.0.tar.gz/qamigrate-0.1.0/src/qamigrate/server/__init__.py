"""Server module for QAMigrate dashboard."""

from qamigrate.server.app import create_app

__all__ = ["create_app"]
