"""
FastAPI Application Factory.

Creates and configures the QAMigrate dashboard server.
"""

from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import RedirectResponse
from fastapi.staticfiles import StaticFiles

from qamigrate import __version__
from qamigrate.core.config import get_config
from qamigrate.server.routes import router
from qamigrate.server.websocket import ws_router


def create_app() -> FastAPI:
    """
    Create and configure the FastAPI application.

    Returns:
        Configured FastAPI instance
    """
    config = get_config()

    app = FastAPI(
        title="QAMigrate Dashboard",
        description="The Universal QA Hypervisor - Migration Dashboard",
        version=__version__,
        docs_url="/api/docs",
        redoc_url="/api/redoc",
    )

    # Configure CORS - include Vite dev server
    cors_origins = config.server.cors_origins + [
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ]
    app.add_middleware(
        CORSMiddleware,
        allow_origins=cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Include routers
    app.include_router(router, prefix="/api")
    app.include_router(ws_router, prefix="/ws")

    # Root route - redirect to API docs or dashboard
    @app.get("/")
    async def root():
        """Redirect to API docs or dashboard."""
        dashboard_dist = Path(__file__).parent.parent.parent.parent / "dashboard" / "dist"
        if dashboard_dist.exists():
            return RedirectResponse(url="/index.html")
        return {
            "message": "QAMigrate API Server",
            "version": __version__,
            "docs": "/api/docs",
            "dashboard": "Run 'npm run dev' in dashboard/ folder on port 5173"
        }

    @app.get("/api/health")
    async def health_check() -> dict:
        """Health check endpoint."""
        return {
            "status": "healthy",
            "version": __version__,
        }

    # Serve static files for the dashboard (if built)
    dashboard_dist = Path(__file__).parent.parent.parent.parent / "dashboard" / "dist"
    if dashboard_dist.exists():
        app.mount("/", StaticFiles(directory=str(dashboard_dist), html=True), name="dashboard")

    return app
