"""
WebSocket Support.

Real-time progress streaming for migrations.
"""

import asyncio
import json
from typing import Any

from fastapi import APIRouter, WebSocket, WebSocketDisconnect
import structlog

logger = structlog.get_logger(__name__)

ws_router = APIRouter(tags=["websocket"])


class ConnectionManager:
    """Manages WebSocket connections."""

    def __init__(self) -> None:
        """Initialize connection manager."""
        self.active_connections: list[WebSocket] = []

    async def connect(self, websocket: WebSocket) -> None:
        """Accept and track a new connection."""
        await websocket.accept()
        self.active_connections.append(websocket)
        logger.info("WebSocket connected", total=len(self.active_connections))

    def disconnect(self, websocket: WebSocket) -> None:
        """Remove a connection."""
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
        logger.info("WebSocket disconnected", total=len(self.active_connections))

    async def broadcast(self, message: dict[str, Any]) -> None:
        """Send message to all connected clients."""
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except Exception:
                # Connection might be closed
                pass

    async def send_personal(self, websocket: WebSocket, message: dict[str, Any]) -> None:
        """Send message to a specific client."""
        try:
            await websocket.send_json(message)
        except Exception:
            pass


manager = ConnectionManager()


@ws_router.websocket("/progress")
async def migration_progress(websocket: WebSocket) -> None:
    """
    WebSocket endpoint for migration progress updates.

    Clients can subscribe to real-time updates for ongoing migrations.
    """
    await manager.connect(websocket)

    try:
        while True:
            # Receive messages from client
            data = await websocket.receive_text()

            try:
                message = json.loads(data)
                message_type = message.get("type")

                if message_type == "subscribe":
                    # Client wants to subscribe to a migration
                    file_path = message.get("file_path")
                    await manager.send_personal(
                        websocket,
                        {
                            "type": "subscribed",
                            "file_path": file_path,
                        },
                    )

                elif message_type == "ping":
                    await manager.send_personal(
                        websocket,
                        {"type": "pong"},
                    )

            except json.JSONDecodeError:
                await manager.send_personal(
                    websocket,
                    {"type": "error", "message": "Invalid JSON"},
                )

    except WebSocketDisconnect:
        manager.disconnect(websocket)


async def send_progress_update(
    file_path: str,
    phase: str,
    progress: int,
    message: str,
) -> None:
    """
    Send progress update to all connected clients.

    Args:
        file_path: Path of the file being migrated
        phase: Current migration phase
        progress: Progress percentage (0-100)
        message: Status message
    """
    await manager.broadcast(
        {
            "type": "progress",
            "file_path": file_path,
            "phase": phase,
            "progress": progress,
            "message": message,
        }
    )


async def send_migration_complete(
    file_path: str,
    success: bool,
    output_path: str | None = None,
    error: str | None = None,
) -> None:
    """
    Send migration complete notification.

    Args:
        file_path: Path of the file that was migrated
        success: Whether migration succeeded
        output_path: Path to generated file (if successful)
        error: Error message (if failed)
    """
    await manager.broadcast(
        {
            "type": "complete",
            "file_path": file_path,
            "success": success,
            "output_path": output_path,
            "error": error,
        }
    )
