# QAMigrate Helm Chart

Deploy QAMigrate to Kubernetes with built-in Redis support, autoscaling, and persistence.

## Prerequisites

- Kubernetes 1.23+
- Helm 3.8+
- PV provisioner support (for persistence)

## Installation

```bash
# Add repo (if published)
helm repo add qamigrate https://charts.qamigrate.io
helm repo update

# Or install from local chart
helm install qamigrate ./helm/qamigrate \
  --namespace qamigrate \
  --create-namespace \
  --set secrets.anthropicApiKey.secretName=my-api-secrets
```

## Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `replicaCount` | Number of replicas | `2` |
| `image.repository` | Image repository | `qamigrate/qamigrate` |
| `image.tag` | Image tag | `1.0.0` |
| `service.port` | Service port | `3000` |
| `ingress.enabled` | Enable ingress | `false` |
| `autoscaling.enabled` | Enable HPA | `true` |
| `autoscaling.minReplicas` | Min replicas | `2` |
| `autoscaling.maxReplicas` | Max replicas | `10` |
| `redis.enabled` | Enable Redis subchart | `true` |
| `persistence.enabled` | Enable PVC | `true` |
| `persistence.size` | PVC size | `10Gi` |

## Secrets Setup

Create a secret with your API keys before installing:

```bash
kubectl create secret generic qamigrate-secrets \
  --namespace qamigrate \
  --from-literal=anthropic-api-key=YOUR_API_KEY

kubectl create secret generic qamigrate-redis-secret \
  --namespace qamigrate \
  --from-literal=redis-password=YOUR_REDIS_PASSWORD
```

## Production Configuration

```yaml
# production-values.yaml
replicaCount: 3

autoscaling:
  enabled: true
  minReplicas: 3
  maxReplicas: 20

ingress:
  enabled: true
  className: nginx
  hosts:
    - host: qamigrate.example.com
      paths:
        - path: /
          pathType: Prefix
  tls:
    - secretName: qamigrate-tls
      hosts:
        - qamigrate.example.com

resources:
  limits:
    cpu: 2000m
    memory: 4Gi
  requests:
    cpu: 1000m
    memory: 2Gi
```

Install with production values:

```bash
helm install qamigrate ./helm/qamigrate \
  --namespace qamigrate \
  -f production-values.yaml
```
