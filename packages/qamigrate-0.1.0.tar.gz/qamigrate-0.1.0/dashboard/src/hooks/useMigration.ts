import { useState, useEffect, useCallback, useRef } from 'react'

interface MigrationProgress {
    file_path: string
    status: 'pending' | 'scanning' | 'generating' | 'compiling' | 'fixing' | 'verifying' | 'completed' | 'failed'
    progress: number
    phase: string
    message?: string
    retry_count?: number
}

interface WebSocketMessage {
    type: 'progress' | 'complete' | 'error' | 'log'
    data: any
}

export function useMigrationWebSocket(enabled: boolean = true) {
    const [isConnected, setIsConnected] = useState(false)
    const [progress, setProgress] = useState<Record<string, MigrationProgress>>({})
    const [logs, setLogs] = useState<string[]>([])
    const [error, setError] = useState<string | null>(null)
    const wsRef = useRef<WebSocket | null>(null)
    const reconnectTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null)

    const connect = useCallback(() => {
        if (!enabled) return

        const wsUrl = 'ws://localhost:3000/ws/progress'

        try {
            const ws = new WebSocket(wsUrl)
            wsRef.current = ws

            ws.onopen = () => {
                console.log('WebSocket connected')
                setIsConnected(true)
                setError(null)
            }

            ws.onmessage = (event) => {
                try {
                    const message: WebSocketMessage = JSON.parse(event.data)

                    switch (message.type) {
                        case 'progress':
                            setProgress(prev => ({
                                ...prev,
                                [message.data.file_path]: message.data
                            }))
                            break
                        case 'complete':
                            setProgress(prev => ({
                                ...prev,
                                [message.data.file_path]: {
                                    ...message.data,
                                    status: 'completed',
                                    progress: 100
                                }
                            }))
                            break
                        case 'error':
                            setProgress(prev => ({
                                ...prev,
                                [message.data.file_path]: {
                                    ...message.data,
                                    status: 'failed'
                                }
                            }))
                            break
                        case 'log':
                            setLogs(prev => [...prev.slice(-99), message.data.message])
                            break
                    }
                } catch (e) {
                    console.error('Failed to parse WebSocket message:', e)
                }
            }

            ws.onclose = () => {
                console.log('WebSocket disconnected')
                setIsConnected(false)

                // Attempt to reconnect after 3 seconds
                reconnectTimeoutRef.current = setTimeout(() => {
                    connect()
                }, 3000)
            }

            ws.onerror = (e) => {
                console.error('WebSocket error:', e)
                setError('Connection error')
            }

        } catch (e) {
            console.error('Failed to connect WebSocket:', e)
            setError('Failed to connect')
        }
    }, [enabled])

    const disconnect = useCallback(() => {
        if (reconnectTimeoutRef.current) {
            clearTimeout(reconnectTimeoutRef.current)
        }
        if (wsRef.current) {
            wsRef.current.close()
            wsRef.current = null
        }
        setIsConnected(false)
    }, [])

    const sendMessage = useCallback((message: object) => {
        if (wsRef.current?.readyState === WebSocket.OPEN) {
            wsRef.current.send(JSON.stringify(message))
        }
    }, [])

    const startMigration = useCallback((filePath: string) => {
        sendMessage({
            action: 'start_migration',
            file_path: filePath
        })
    }, [sendMessage])

    const clearProgress = useCallback(() => {
        setProgress({})
        setLogs([])
    }, [])

    useEffect(() => {
        connect()
        return () => disconnect()
    }, [connect, disconnect])

    return {
        isConnected,
        progress,
        logs,
        error,
        startMigration,
        clearProgress,
        reconnect: connect
    }
}

// Hook for polling-based progress (fallback)
export function useMigrationPolling(interval: number = 1000) {
    const [progress, setProgress] = useState<Record<string, MigrationProgress>>({})
    const [isPolling, setIsPolling] = useState(false)
    const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null)

    const startPolling = useCallback(async () => {
        setIsPolling(true)

        const poll = async () => {
            try {
                const response = await fetch('http://localhost:3000/api/migration/status')
                if (response.ok) {
                    const data = await response.json()
                    setProgress(data.progress || {})
                }
            } catch (e) {
                console.error('Polling failed:', e)
            }
        }

        // Initial poll
        await poll()

        // Set up interval
        intervalRef.current = setInterval(poll, interval)
    }, [interval])

    const stopPolling = useCallback(() => {
        if (intervalRef.current) {
            clearInterval(intervalRef.current)
            intervalRef.current = null
        }
        setIsPolling(false)
    }, [])

    useEffect(() => {
        return () => stopPolling()
    }, [stopPolling])

    return {
        progress,
        isPolling,
        startPolling,
        stopPolling
    }
}
