import { useLocation, useNavigate } from 'react-router-dom'
import {
    Home,
    FolderSearch,
    ArrowRightLeft,
    CheckCircle2,
    BarChart3,
    Settings,
    HelpCircle,
    Zap,
    ChevronRight
} from 'lucide-react'

const navItems = [
    { icon: Home, label: 'Dashboard', path: '/' },
    { icon: FolderSearch, label: 'Scan', path: '/scan' },
    { icon: ArrowRightLeft, label: 'Migrate', path: '/migrate' },
    { icon: CheckCircle2, label: 'Verify', path: '/verify' },
    { icon: BarChart3, label: 'Reports', path: '/reports' },
]

const bottomItems = [
    { icon: Settings, label: 'Settings', path: '/settings' },
    { icon: HelpCircle, label: 'Help', path: '/help' },
]

export default function Sidebar() {
    const location = useLocation()
    const navigate = useNavigate()

    const isActive = (path: string) => {
        if (path === '/') return location.pathname === '/'
        return location.pathname.startsWith(path)
    }

    return (
        <aside className="w-64 min-w-[256px] glass border-r border-white/5 flex flex-col">
            {/* Logo */}
            <div className="p-5 pb-4">
                <div className="flex items-center gap-3 cursor-pointer" onClick={() => navigate('/')}>
                    <div className="relative">
                        <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 flex items-center justify-center shadow-lg shadow-purple-500/30">
                            <Zap className="w-5 h-5 text-white" />
                        </div>
                        <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-green-400 rounded-full border-2 border-gray-900"></div>
                    </div>
                    <div>
                        <h1 className="text-lg font-bold gradient-text">QAMigrate</h1>
                        <p className="text-xs text-gray-500">v1.0.0</p>
                    </div>
                </div>
            </div>

            {/* Divider */}
            <div className="mx-4 h-px bg-gradient-to-r from-transparent via-gray-700 to-transparent"></div>

            {/* Navigation */}
            <nav className="flex-1 p-4">
                <p className="text-[10px] font-semibold text-gray-500 uppercase tracking-widest mb-3 px-3">
                    Navigation
                </p>
                <ul className="space-y-1.5">
                    {navItems.map((item) => (
                        <li key={item.path}>
                            <button
                                onClick={() => navigate(item.path)}
                                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-all duration-200 group ${isActive(item.path)
                                        ? 'bg-gradient-to-r from-blue-500/15 to-purple-500/15 text-white border border-blue-500/25'
                                        : 'text-gray-400 hover:bg-white/5 hover:text-white'
                                    }`}
                            >
                                <div className="flex items-center gap-3">
                                    <div className={`p-1.5 rounded-lg ${isActive(item.path)
                                            ? 'bg-gradient-to-br from-blue-500 to-purple-500'
                                            : 'bg-gray-800 group-hover:bg-gray-700'
                                        }`}>
                                        <item.icon className={`w-4 h-4 ${isActive(item.path) ? 'text-white' : 'text-gray-400 group-hover:text-white'}`} />
                                    </div>
                                    <span className="font-medium text-sm">{item.label}</span>
                                </div>
                                {isActive(item.path) && (
                                    <ChevronRight className="w-4 h-4 text-blue-400" />
                                )}
                            </button>
                        </li>
                    ))}
                </ul>
            </nav>

            {/* Bottom Section */}
            <div className="p-4 space-y-1.5 border-t border-white/5">
                {bottomItems.map((item) => (
                    <button
                        key={item.path}
                        onClick={() => navigate(item.path)}
                        className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all ${isActive(item.path)
                                ? 'bg-white/10 text-white'
                                : 'text-gray-400 hover:bg-white/5 hover:text-white'
                            }`}
                    >
                        <div className={`p-1.5 rounded-lg ${isActive(item.path) ? 'bg-gray-700' : 'bg-gray-800'}`}>
                            <item.icon className="w-4 h-4" />
                        </div>
                        <span className="font-medium text-sm">{item.label}</span>
                    </button>
                ))}
            </div>

            {/* Pro Card */}
            <div className="p-4 pt-0">
                <div className="p-4 rounded-xl bg-gradient-to-br from-amber-500/10 to-orange-500/5 border border-amber-500/20">
                    <div className="flex items-center gap-2 mb-2">
                        <Zap className="w-4 h-4 text-amber-400" />
                        <span className="font-semibold text-white text-sm">Pro Features</span>
                    </div>
                    <p className="text-xs text-gray-400 mb-3 leading-relaxed">
                        Unlock parallel migration & team collaboration.
                    </p>
                    <button className="w-full py-2 rounded-lg bg-gradient-to-r from-amber-500 to-orange-500 text-white text-xs font-semibold hover:opacity-90 transition-opacity">
                        Upgrade Now
                    </button>
                </div>
            </div>
        </aside>
    )
}
