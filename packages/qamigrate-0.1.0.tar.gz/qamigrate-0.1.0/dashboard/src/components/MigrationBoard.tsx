import { useState, useEffect } from 'react'
import {
    Play,
    CheckCircle,
    XCircle,
    Clock,
    Loader2,
    ArrowRight,
    Sparkles,
    FileCode,
    Filter
} from 'lucide-react'

interface FileInfo {
    file_path: string
    class_name: string
    is_page_object: boolean
    is_test_class: boolean
    complexity_score: number
    pattern_count: number
}

interface MigrationBoardProps {
    files: FileInfo[]
}

type Status = 'pending' | 'migrating' | 'completed' | 'failed'

interface FileWithStatus extends FileInfo {
    status: Status
}

export default function MigrationBoard({ files }: MigrationBoardProps) {
    const [fileStatuses, setFileStatuses] = useState<FileWithStatus[]>([])
    const [isMigrating, setIsMigrating] = useState(false)

    useEffect(() => {
        setFileStatuses(files.map(f => ({ ...f, status: 'pending' as Status })))
    }, [files])

    const handleMigrate = async (file: FileWithStatus) => {
        setFileStatuses(prev =>
            prev.map(f => f.file_path === file.file_path ? { ...f, status: 'migrating' } : f)
        )

        try {
            const response = await fetch('http://localhost:3000/api/migrate', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ file_path: file.file_path }),
            })

            setFileStatuses(prev =>
                prev.map(f => f.file_path === file.file_path
                    ? { ...f, status: response.ok ? 'completed' : 'failed' }
                    : f
                )
            )
        } catch {
            setFileStatuses(prev =>
                prev.map(f => f.file_path === file.file_path ? { ...f, status: 'failed' } : f)
            )
        }
    }

    const handleMigrateAll = async () => {
        setIsMigrating(true)
        for (const file of fileStatuses) {
            if (file.status === 'pending') {
                await handleMigrate(file)
            }
        }
        setIsMigrating(false)
    }

    const getStatusInfo = (status: Status) => {
        switch (status) {
            case 'pending':
                return { icon: Clock, color: 'text-gray-400', bg: 'bg-gray-700/30', border: 'border-gray-600/30' }
            case 'migrating':
                return { icon: Loader2, color: 'text-blue-400', bg: 'bg-blue-500/15', border: 'border-blue-500/30', animate: true }
            case 'completed':
                return { icon: CheckCircle, color: 'text-green-400', bg: 'bg-green-500/15', border: 'border-green-500/30' }
            case 'failed':
                return { icon: XCircle, color: 'text-red-400', bg: 'bg-red-500/15', border: 'border-red-500/30' }
        }
    }

    const pendingCount = fileStatuses.filter(f => f.status === 'pending').length
    const completedCount = fileStatuses.filter(f => f.status === 'completed').length
    const progressPercent = fileStatuses.length > 0 ? (completedCount / fileStatuses.length) * 100 : 0

    return (
        <div className="glass-card rounded-2xl overflow-hidden">
            {/* Header */}
            <div className="p-6 border-b border-white/5">
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                        <div className="p-3 rounded-xl bg-gradient-to-br from-purple-500/15 to-pink-500/15 border border-purple-500/20">
                            <Sparkles className="w-6 h-6 text-purple-400" />
                        </div>
                        <div>
                            <h2 className="text-xl font-bold text-white">Migration Board</h2>
                            <p className="text-gray-400 text-sm mt-0.5">
                                {completedCount} of {fileStatuses.length} files migrated
                            </p>
                        </div>
                    </div>

                    <div className="flex items-center gap-3">
                        <button className="p-2.5 rounded-xl glass hover:bg-white/10 transition-all">
                            <Filter className="w-5 h-5 text-gray-400" />
                        </button>
                        <button
                            onClick={handleMigrateAll}
                            disabled={isMigrating || pendingCount === 0}
                            className="btn-primary flex items-center gap-3"
                        >
                            {isMigrating ? (
                                <>
                                    <Loader2 className="w-5 h-5 animate-spin" />
                                    <span>Migrating...</span>
                                </>
                            ) : (
                                <>
                                    <Play className="w-5 h-5" />
                                    <span>Migrate All ({pendingCount})</span>
                                </>
                            )}
                        </button>
                    </div>
                </div>

                {/* Progress Bar */}
                <div className="mt-6">
                    <div className="flex items-center justify-between text-sm mb-2">
                        <span className="text-gray-400 font-medium">Migration Progress</span>
                        <span className="text-white font-semibold">{Math.round(progressPercent)}%</span>
                    </div>
                    <div className="h-2 bg-gray-800/60 rounded-full overflow-hidden">
                        <div
                            className="h-full bg-gradient-to-r from-green-500 via-emerald-400 to-cyan-400 transition-all duration-700 ease-out rounded-full relative"
                            style={{ width: `${progressPercent}%` }}
                        >
                            <div className="absolute inset-0 shimmer"></div>
                        </div>
                    </div>
                </div>
            </div>

            {/* File List */}
            <div className="p-4">
                <div className="space-y-3 max-h-[480px] overflow-y-auto pr-2">
                    {fileStatuses.map((file) => {
                        const statusInfo = getStatusInfo(file.status)
                        const StatusIcon = statusInfo.icon

                        return (
                            <div
                                key={file.file_path}
                                className={`flex items-center justify-between p-5 rounded-xl border transition-all duration-300 ${file.status === 'migrating'
                                        ? 'border-blue-500/40 bg-blue-500/5'
                                        : file.status === 'completed'
                                            ? 'border-green-500/40 bg-green-500/5'
                                            : file.status === 'failed'
                                                ? 'border-red-500/40 bg-red-500/5'
                                                : 'border-gray-700/40 bg-gray-800/20 hover:bg-gray-800/40 hover:border-gray-600/50'
                                    }`}
                            >
                                <div className="flex items-center gap-4">
                                    <div className={`p-3 rounded-xl border ${statusInfo.bg} ${statusInfo.border}`}>
                                        <StatusIcon
                                            className={`w-5 h-5 ${statusInfo.color} ${statusInfo.animate ? 'animate-spin' : ''}`}
                                        />
                                    </div>
                                    <div>
                                        <div className="flex items-center gap-2">
                                            <FileCode className="w-4 h-4 text-gray-500" />
                                            <p className="font-semibold text-white">{file.class_name}</p>
                                        </div>
                                        <p className="text-sm text-gray-500 mt-1">
                                            {file.file_path.split(/[/\\]/).slice(-3).join(' / ')}
                                        </p>
                                    </div>
                                </div>

                                <div className="flex items-center gap-4">
                                    <div className="flex items-center gap-2">
                                        {file.is_page_object && (
                                            <span className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-purple-500/15 text-purple-300 border border-purple-500/25">
                                                Page Object
                                            </span>
                                        )}
                                        {file.is_test_class && (
                                            <span className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-blue-500/15 text-blue-300 border border-blue-500/25">
                                                Test
                                            </span>
                                        )}
                                        <span className={`px-3 py-1.5 rounded-lg text-xs font-semibold border ${file.complexity_score <= 3
                                                ? 'bg-green-500/15 text-green-300 border-green-500/25'
                                                : file.complexity_score <= 6
                                                    ? 'bg-yellow-500/15 text-yellow-300 border-yellow-500/25'
                                                    : 'bg-red-500/15 text-red-300 border-red-500/25'
                                            }`}>
                                            Score: {file.complexity_score}
                                        </span>
                                    </div>

                                    {file.status === 'pending' && (
                                        <button
                                            onClick={() => handleMigrate(file)}
                                            className="p-3 rounded-xl bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-400 hover:to-purple-400 text-white transition-all duration-300 hover:scale-105 shadow-lg shadow-blue-500/25"
                                        >
                                            <ArrowRight className="w-4 h-4" />
                                        </button>
                                    )}
                                </div>
                            </div>
                        )
                    })}
                </div>

                {/* Empty state */}
                {fileStatuses.length === 0 && (
                    <div className="text-center py-16 text-gray-500">
                        <FileCode className="w-16 h-16 mx-auto mb-4 opacity-30" />
                        <p className="text-lg">No files to migrate</p>
                        <p className="text-sm mt-1">Scan a project first to see files here</p>
                    </div>
                )}
            </div>
        </div>
    )
}
