import { useState, useRef, useEffect, useCallback } from 'react'
import {
    Play,
    Pause,
    RotateCcw,
    Maximize2,
    Volume2,
    VolumeX,
    ChevronLeft,
    ChevronRight,
    Clock,
    Zap
} from 'lucide-react'

interface TruthPlayerProps {
    seleniumVideoUrl: string
    playwrightVideoUrl: string
    seleniumTime: number
    playwrightTime: number
    onTimeUpdate?: (currentTime: number) => void
}

export default function TruthPlayer({
    seleniumVideoUrl,
    playwrightVideoUrl,
    seleniumTime,
    playwrightTime,
}: TruthPlayerProps) {
    const [isPlaying, setIsPlaying] = useState(false)
    const [isMuted, setIsMuted] = useState(true)
    const [currentTime, setCurrentTime] = useState(0)
    const [duration, setDuration] = useState(0)
    const [isFullscreen, setIsFullscreen] = useState(false)
    const [playbackRate, setPlaybackRate] = useState(1)

    const seleniumRef = useRef<HTMLVideoElement>(null)
    const playwrightRef = useRef<HTMLVideoElement>(null)
    const containerRef = useRef<HTMLDivElement>(null)

    const performanceImprovement = seleniumTime / Math.max(playwrightTime, 1)

    // Sync both videos
    const syncVideos = useCallback((time: number) => {
        if (seleniumRef.current) {
            seleniumRef.current.currentTime = time
        }
        if (playwrightRef.current) {
            playwrightRef.current.currentTime = time
        }
        setCurrentTime(time)
    }, [])

    // Play/Pause both videos
    const togglePlay = useCallback(() => {
        if (isPlaying) {
            seleniumRef.current?.pause()
            playwrightRef.current?.pause()
        } else {
            seleniumRef.current?.play()
            playwrightRef.current?.play()
        }
        setIsPlaying(!isPlaying)
    }, [isPlaying])

    // Reset to beginning
    const reset = useCallback(() => {
        syncVideos(0)
        setIsPlaying(false)
        seleniumRef.current?.pause()
        playwrightRef.current?.pause()
    }, [syncVideos])

    // Handle time update from Selenium video (primary)
    const handleTimeUpdate = useCallback(() => {
        if (seleniumRef.current) {
            setCurrentTime(seleniumRef.current.currentTime)
        }
    }, [])

    // Handle metadata loaded
    const handleLoadedMetadata = useCallback(() => {
        if (seleniumRef.current) {
            setDuration(seleniumRef.current.duration)
        }
    }, [])

    // Handle seek
    const handleSeek = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
        const time = parseFloat(e.target.value)
        syncVideos(time)
    }, [syncVideos])

    // Toggle fullscreen
    const toggleFullscreen = useCallback(() => {
        if (!document.fullscreenElement && containerRef.current) {
            containerRef.current.requestFullscreen()
            setIsFullscreen(true)
        } else {
            document.exitFullscreen()
            setIsFullscreen(false)
        }
    }, [])

    // Change playback rate
    const changePlaybackRate = useCallback((rate: number) => {
        setPlaybackRate(rate)
        if (seleniumRef.current) seleniumRef.current.playbackRate = rate
        if (playwrightRef.current) playwrightRef.current.playbackRate = rate
    }, [])

    // Skip forward/backward
    const skip = useCallback((seconds: number) => {
        const newTime = Math.max(0, Math.min(duration, currentTime + seconds))
        syncVideos(newTime)
    }, [currentTime, duration, syncVideos])

    // Format time
    const formatTime = (seconds: number) => {
        const mins = Math.floor(seconds / 60)
        const secs = Math.floor(seconds % 60)
        return `${mins}:${secs.toString().padStart(2, '0')}`
    }

    // Keyboard shortcuts
    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            if (e.code === 'Space') {
                e.preventDefault()
                togglePlay()
            } else if (e.code === 'ArrowLeft') {
                skip(-5)
            } else if (e.code === 'ArrowRight') {
                skip(5)
            } else if (e.code === 'KeyM') {
                setIsMuted(!isMuted)
            }
        }

        window.addEventListener('keydown', handleKeyDown)
        return () => window.removeEventListener('keydown', handleKeyDown)
    }, [togglePlay, skip, isMuted])

    return (
        <div
            ref={containerRef}
            className={`glass-card rounded-2xl overflow-hidden ${isFullscreen ? 'fixed inset-0 z-50 rounded-none' : ''}`}
        >
            {/* Header */}
            <div className="p-4 border-b border-white/5 flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-gradient-to-br from-green-500/15 to-emerald-500/15 border border-green-500/20">
                        <Play className="w-5 h-5 text-green-400" />
                    </div>
                    <div>
                        <h3 className="font-semibold text-white">Truth Player</h3>
                        <p className="text-xs text-gray-500">Synchronized Video Comparison</p>
                    </div>
                </div>

                <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2 text-sm">
                        <Clock className="w-4 h-4 text-gray-500" />
                        <span className="text-gray-400">{seleniumTime}ms</span>
                        <Zap className="w-4 h-4 text-green-400" />
                        <span className="text-green-400">{playwrightTime}ms</span>
                        <span className="px-2 py-0.5 rounded text-xs font-semibold bg-green-500/15 text-green-400 border border-green-500/20">
                            {performanceImprovement.toFixed(1)}x faster
                        </span>
                    </div>
                </div>
            </div>

            {/* Video Grid */}
            <div className="grid grid-cols-2 gap-1 bg-black">
                {/* Selenium Video */}
                <div className="relative">
                    <div className="absolute top-2 left-2 z-10 px-2 py-1 rounded bg-black/70 text-xs font-medium text-red-400">
                        Selenium
                    </div>
                    <video
                        ref={seleniumRef}
                        src={seleniumVideoUrl}
                        className="w-full aspect-video object-cover"
                        muted={isMuted}
                        onTimeUpdate={handleTimeUpdate}
                        onLoadedMetadata={handleLoadedMetadata}
                        onEnded={() => setIsPlaying(false)}
                    />
                </div>

                {/* Playwright Video */}
                <div className="relative">
                    <div className="absolute top-2 left-2 z-10 px-2 py-1 rounded bg-black/70 text-xs font-medium text-green-400">
                        Playwright
                    </div>
                    <video
                        ref={playwrightRef}
                        src={playwrightVideoUrl}
                        className="w-full aspect-video object-cover"
                        muted
                    />
                </div>
            </div>

            {/* Controls */}
            <div className="p-4 space-y-3">
                {/* Progress Bar */}
                <div className="flex items-center gap-3">
                    <span className="text-xs text-gray-400 w-12">{formatTime(currentTime)}</span>
                    <input
                        type="range"
                        min="0"
                        max={duration || 100}
                        value={currentTime}
                        onChange={handleSeek}
                        className="flex-1 h-1.5 bg-gray-700 rounded-full appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-blue-500"
                    />
                    <span className="text-xs text-gray-400 w-12 text-right">{formatTime(duration)}</span>
                </div>

                {/* Control Buttons */}
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                        {/* Play/Pause */}
                        <button
                            onClick={togglePlay}
                            className="p-2.5 rounded-lg bg-blue-500 hover:bg-blue-400 text-white transition-colors"
                        >
                            {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                        </button>

                        {/* Skip buttons */}
                        <button
                            onClick={() => skip(-5)}
                            className="p-2 rounded-lg hover:bg-white/5 text-gray-400 transition-colors"
                        >
                            <ChevronLeft className="w-5 h-5" />
                        </button>
                        <button
                            onClick={() => skip(5)}
                            className="p-2 rounded-lg hover:bg-white/5 text-gray-400 transition-colors"
                        >
                            <ChevronRight className="w-5 h-5" />
                        </button>

                        {/* Reset */}
                        <button
                            onClick={reset}
                            className="p-2 rounded-lg hover:bg-white/5 text-gray-400 transition-colors"
                        >
                            <RotateCcw className="w-5 h-5" />
                        </button>

                        {/* Mute */}
                        <button
                            onClick={() => setIsMuted(!isMuted)}
                            className="p-2 rounded-lg hover:bg-white/5 text-gray-400 transition-colors"
                        >
                            {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
                        </button>
                    </div>

                    <div className="flex items-center gap-2">
                        {/* Playback Speed */}
                        <div className="flex items-center gap-1 bg-gray-800/50 rounded-lg p-1">
                            {[0.5, 1, 1.5, 2].map((rate) => (
                                <button
                                    key={rate}
                                    onClick={() => changePlaybackRate(rate)}
                                    className={`px-2 py-1 rounded text-xs font-medium transition-colors ${playbackRate === rate
                                            ? 'bg-blue-500 text-white'
                                            : 'text-gray-400 hover:text-white'
                                        }`}
                                >
                                    {rate}x
                                </button>
                            ))}
                        </div>

                        {/* Fullscreen */}
                        <button
                            onClick={toggleFullscreen}
                            className="p-2 rounded-lg hover:bg-white/5 text-gray-400 transition-colors"
                        >
                            <Maximize2 className="w-5 h-5" />
                        </button>
                    </div>
                </div>
            </div>
        </div>
    )
}
