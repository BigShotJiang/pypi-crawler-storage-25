import { Wifi, WifiOff, Activity, Clock, CheckCircle, XCircle, Loader2 } from 'lucide-react'

interface MigrationProgressData {
    file_path: string
    status: string
    progress: number
    phase: string
    message?: string
}

interface MigrationProgressProps {
    progress: Record<string, MigrationProgressData>
    isConnected: boolean
    logs?: string[]
}

const phaseColors: Record<string, string> = {
    scanning: 'from-cyan-500 to-blue-500',
    generating: 'from-blue-500 to-purple-500',
    compiling: 'from-purple-500 to-pink-500',
    fixing: 'from-amber-500 to-orange-500',
    verifying: 'from-green-500 to-emerald-500',
}

const phaseLabels: Record<string, string> = {
    scanning: 'Analyzing AST',
    generating: 'Generating Code',
    compiling: 'Validating',
    fixing: 'Applying Fixes',
    verifying: 'Verification',
}

export default function MigrationProgress({ progress, isConnected, logs = [] }: MigrationProgressProps) {
    const activeFiles = Object.values(progress).filter(p =>
        p.status !== 'completed' && p.status !== 'failed' && p.status !== 'pending'
    )

    const completedCount = Object.values(progress).filter(p => p.status === 'completed').length
    const failedCount = Object.values(progress).filter(p => p.status === 'failed').length
    const totalCount = Object.keys(progress).length

    return (
        <div className="glass-card rounded-2xl overflow-hidden">
            {/* Header */}
            <div className="p-4 border-b border-white/5 flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${isConnected ? 'bg-green-500/15' : 'bg-gray-700/50'}`}>
                        {isConnected ? (
                            <Wifi className="w-5 h-5 text-green-400" />
                        ) : (
                            <WifiOff className="w-5 h-5 text-gray-500" />
                        )}
                    </div>
                    <div>
                        <h3 className="font-semibold text-white flex items-center gap-2">
                            Real-Time Progress
                            {isConnected && (
                                <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></span>
                            )}
                        </h3>
                        <p className="text-xs text-gray-500">
                            {isConnected ? 'Connected to migration server' : 'Disconnected'}
                        </p>
                    </div>
                </div>

                <div className="flex items-center gap-4 text-sm">
                    <div className="flex items-center gap-2 text-green-400">
                        <CheckCircle className="w-4 h-4" />
                        <span>{completedCount}</span>
                    </div>
                    <div className="flex items-center gap-2 text-red-400">
                        <XCircle className="w-4 h-4" />
                        <span>{failedCount}</span>
                    </div>
                    <div className="flex items-center gap-2 text-gray-400">
                        <Clock className="w-4 h-4" />
                        <span>{totalCount - completedCount - failedCount}</span>
                    </div>
                </div>
            </div>

            {/* Active Migrations */}
            {activeFiles.length > 0 && (
                <div className="p-4 space-y-4">
                    {activeFiles.map((file) => {
                        const fileName = file.file_path.split(/[/\\]/).pop() || file.file_path
                        const phaseColor = phaseColors[file.phase] || 'from-gray-500 to-gray-600'
                        const phaseLabel = phaseLabels[file.phase] || file.phase

                        return (
                            <div key={file.file_path} className="space-y-2">
                                <div className="flex items-center justify-between">
                                    <div className="flex items-center gap-3">
                                        <Loader2 className="w-4 h-4 text-blue-400 animate-spin" />
                                        <span className="font-medium text-white text-sm">{fileName}</span>
                                        <span className={`px-2 py-0.5 rounded text-[10px] font-semibold bg-gradient-to-r ${phaseColor} text-white`}>
                                            {phaseLabel}
                                        </span>
                                    </div>
                                    <span className="text-sm font-semibold text-white">{file.progress}%</span>
                                </div>

                                <div className="h-1.5 bg-gray-800/60 rounded-full overflow-hidden">
                                    <div
                                        className={`h-full bg-gradient-to-r ${phaseColor} transition-all duration-500 ease-out rounded-full relative`}
                                        style={{ width: `${file.progress}%` }}
                                    >
                                        <div className="absolute inset-0 shimmer"></div>
                                    </div>
                                </div>

                                {file.message && (
                                    <p className="text-xs text-gray-500">{file.message}</p>
                                )}
                            </div>
                        )
                    })}
                </div>
            )}

            {/* Logs Panel */}
            {logs.length > 0 && (
                <div className="border-t border-white/5">
                    <div className="px-4 py-2 bg-gray-800/30 flex items-center gap-2">
                        <Activity className="w-4 h-4 text-gray-500" />
                        <span className="text-xs font-medium text-gray-400">Activity Log</span>
                    </div>
                    <div className="p-4 max-h-32 overflow-y-auto font-mono text-xs text-gray-500 space-y-1">
                        {logs.slice(-10).map((log, i) => (
                            <div key={i} className="flex items-start gap-2">
                                <span className="text-gray-600 select-none">&gt;</span>
                                <span>{log}</span>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {/* Empty State */}
            {activeFiles.length === 0 && logs.length === 0 && (
                <div className="p-8 text-center text-gray-500">
                    <Activity className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">No active migrations</p>
                </div>
            )}
        </div>
    )
}
