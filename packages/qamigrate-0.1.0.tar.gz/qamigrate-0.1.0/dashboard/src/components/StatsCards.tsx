import { FileCode, Layers, TestTube, AlertTriangle, TrendingUp } from 'lucide-react'

interface StatsCardsProps {
    scanResult: {
        file_count?: number
        page_object_count?: number
        test_class_count?: number
        complexity_distribution?: {
            low: number
            medium: number
            high: number
        }
    } | null
}

export default function StatsCards({ scanResult }: StatsCardsProps) {
    const stats = [
        {
            label: 'Total Files',
            value: scanResult?.file_count || 0,
            icon: FileCode,
            gradient: 'from-blue-500 to-cyan-400',
            bgGradient: 'from-blue-500/10 to-cyan-500/5',
            iconBg: 'bg-blue-500/15 border-blue-500/20',
            iconColor: 'text-blue-400',
            change: '+12%',
            changePositive: true,
        },
        {
            label: 'Page Objects',
            value: scanResult?.page_object_count || 0,
            icon: Layers,
            gradient: 'from-purple-500 to-pink-400',
            bgGradient: 'from-purple-500/10 to-pink-500/5',
            iconBg: 'bg-purple-500/15 border-purple-500/20',
            iconColor: 'text-purple-400',
            change: '+8%',
            changePositive: true,
        },
        {
            label: 'Test Classes',
            value: scanResult?.test_class_count || 0,
            icon: TestTube,
            gradient: 'from-emerald-500 to-green-400',
            bgGradient: 'from-emerald-500/10 to-green-500/5',
            iconBg: 'bg-emerald-500/15 border-emerald-500/20',
            iconColor: 'text-emerald-400',
            change: '+5%',
            changePositive: true,
        },
        {
            label: 'High Complexity',
            value: scanResult?.complexity_distribution?.high || 0,
            icon: AlertTriangle,
            gradient: 'from-amber-500 to-orange-400',
            bgGradient: 'from-amber-500/10 to-orange-500/5',
            iconBg: 'bg-amber-500/15 border-amber-500/20',
            iconColor: 'text-amber-400',
            change: '-3%',
            changePositive: false,
        },
    ]

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
            {stats.map((stat) => (
                <div
                    key={stat.label}
                    className={`glass-card rounded-2xl p-6 bg-gradient-to-br ${stat.bgGradient} hover:scale-[1.02] transition-all duration-300`}
                >
                    {/* Header */}
                    <div className="flex items-center justify-between mb-5">
                        <div className={`p-3 rounded-xl border ${stat.iconBg}`}>
                            <stat.icon className={`w-5 h-5 ${stat.iconColor}`} />
                        </div>
                        <div className={`flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full ${stat.changePositive
                                ? 'bg-green-500/15 text-green-400 border border-green-500/20'
                                : 'bg-amber-500/15 text-amber-400 border border-amber-500/20'
                            }`}>
                            <TrendingUp className={`w-3 h-3 ${!stat.changePositive && 'rotate-180'}`} />
                            {stat.change}
                        </div>
                    </div>

                    {/* Value */}
                    <div className="space-y-1 mb-5">
                        <p className="text-4xl font-bold text-white tracking-tight">
                            {stat.value}
                        </p>
                        <p className="text-sm text-gray-400 font-medium">{stat.label}</p>
                    </div>

                    {/* Progress bar */}
                    <div className="h-1.5 bg-gray-800/50 rounded-full overflow-hidden">
                        <div
                            className={`h-full bg-gradient-to-r ${stat.gradient} transition-all duration-1000 ease-out rounded-full`}
                            style={{ width: stat.value > 0 ? `${Math.min(100, stat.value * 12)}%` : '0%' }}
                        />
                    </div>
                </div>
            ))}
        </div>
    )
}
