import { useState } from 'react'
import Editor, { DiffEditor } from '@monaco-editor/react'
import {
    Code2,
    Copy,
    Check,
    Maximize2,
    X,
    ArrowLeftRight,
    FileCode
} from 'lucide-react'

interface CodeViewerProps {
    originalCode: string
    generatedCode: string
    fileName: string
    onClose?: () => void
}

export default function CodeViewer({
    originalCode,
    generatedCode,
    fileName,
    onClose
}: CodeViewerProps) {
    const [viewMode, setViewMode] = useState<'diff' | 'split' | 'original' | 'generated'>('diff')
    const [copied, setCopied] = useState(false)
    const [isFullscreen, setIsFullscreen] = useState(false)

    const handleCopy = async (code: string) => {
        await navigator.clipboard.writeText(code)
        setCopied(true)
        setTimeout(() => setCopied(false), 2000)
    }

    const editorOptions = {
        minimap: { enabled: false },
        fontSize: 13,
        lineHeight: 20,
        padding: { top: 16, bottom: 16 },
        scrollBeyondLastLine: false,
        renderLineHighlight: 'none' as const,
        overviewRulerBorder: false,
        hideCursorInOverviewRuler: true,
        automaticLayout: true,
        wordWrap: 'on' as const,
    }

    return (
        <div className={`glass-card rounded-2xl overflow-hidden ${isFullscreen ? 'fixed inset-4 z-50' : ''
            }`}>
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-white/5">
                <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-gradient-to-br from-blue-500/15 to-purple-500/15 border border-blue-500/20">
                        <Code2 className="w-5 h-5 text-blue-400" />
                    </div>
                    <div>
                        <h3 className="font-semibold text-white flex items-center gap-2">
                            <FileCode className="w-4 h-4 text-gray-500" />
                            {fileName}
                        </h3>
                        <p className="text-xs text-gray-500">Selenium → Playwright Migration</p>
                    </div>
                </div>

                <div className="flex items-center gap-2">
                    {/* View Mode Tabs */}
                    <div className="flex items-center bg-gray-800/50 rounded-lg p-1">
                        {(['diff', 'split', 'original', 'generated'] as const).map((mode) => (
                            <button
                                key={mode}
                                onClick={() => setViewMode(mode)}
                                className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all ${viewMode === mode
                                        ? 'bg-blue-500 text-white'
                                        : 'text-gray-400 hover:text-white'
                                    }`}
                            >
                                {mode === 'diff' ? 'Diff' : mode === 'split' ? 'Split' : mode === 'original' ? 'Original' : 'Generated'}
                            </button>
                        ))}
                    </div>

                    <div className="w-px h-6 bg-gray-700"></div>

                    <button
                        onClick={() => handleCopy(generatedCode)}
                        className="p-2 rounded-lg hover:bg-white/5 transition-colors"
                        title="Copy generated code"
                    >
                        {copied ? (
                            <Check className="w-4 h-4 text-green-400" />
                        ) : (
                            <Copy className="w-4 h-4 text-gray-400" />
                        )}
                    </button>

                    <button
                        onClick={() => setIsFullscreen(!isFullscreen)}
                        className="p-2 rounded-lg hover:bg-white/5 transition-colors"
                    >
                        <Maximize2 className="w-4 h-4 text-gray-400" />
                    </button>

                    {onClose && (
                        <button
                            onClick={onClose}
                            className="p-2 rounded-lg hover:bg-white/5 transition-colors"
                        >
                            <X className="w-4 h-4 text-gray-400" />
                        </button>
                    )}
                </div>
            </div>

            {/* Editor Area */}
            <div className={`${isFullscreen ? 'h-[calc(100%-64px)]' : 'h-[500px]'}`}>
                {viewMode === 'diff' && (
                    <DiffEditor
                        original={originalCode}
                        modified={generatedCode}
                        language="java"
                        theme="vs-dark"
                        options={{
                            ...editorOptions,
                            readOnly: true,
                            renderSideBySide: true,
                        }}
                    />
                )}

                {viewMode === 'split' && (
                    <div className="flex h-full">
                        <div className="flex-1 border-r border-white/5">
                            <div className="px-4 py-2 bg-gray-800/50 border-b border-white/5 flex items-center gap-2">
                                <span className="text-xs font-medium text-gray-400">Original (Selenium)</span>
                                <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-red-500/15 text-red-400 border border-red-500/20">
                                    Before
                                </span>
                            </div>
                            <Editor
                                value={originalCode}
                                language="java"
                                theme="vs-dark"
                                options={{ ...editorOptions, readOnly: true }}
                            />
                        </div>
                        <div className="flex-1">
                            <div className="px-4 py-2 bg-gray-800/50 border-b border-white/5 flex items-center gap-2">
                                <span className="text-xs font-medium text-gray-400">Generated (Playwright)</span>
                                <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-green-500/15 text-green-400 border border-green-500/20">
                                    After
                                </span>
                            </div>
                            <Editor
                                value={generatedCode}
                                language="java"
                                theme="vs-dark"
                                options={{ ...editorOptions, readOnly: true }}
                            />
                        </div>
                    </div>
                )}

                {viewMode === 'original' && (
                    <Editor
                        value={originalCode}
                        language="java"
                        theme="vs-dark"
                        options={{ ...editorOptions, readOnly: true }}
                    />
                )}

                {viewMode === 'generated' && (
                    <Editor
                        value={generatedCode}
                        language="java"
                        theme="vs-dark"
                        options={editorOptions}
                    />
                )}
            </div>

            {/* Footer Stats */}
            <div className="px-4 py-3 border-t border-white/5 flex items-center justify-between text-xs text-gray-500">
                <div className="flex items-center gap-4">
                    <span>Original: {originalCode.split('\n').length} lines</span>
                    <ArrowLeftRight className="w-3 h-3" />
                    <span>Generated: {generatedCode.split('\n').length} lines</span>
                </div>
                <span className="text-green-400">
                    {Math.abs(generatedCode.split('\n').length - originalCode.split('\n').length)} lines {
                        generatedCode.split('\n').length > originalCode.split('\n').length ? 'added' : 'removed'
                    }
                </span>
            </div>
        </div>
    )
}
