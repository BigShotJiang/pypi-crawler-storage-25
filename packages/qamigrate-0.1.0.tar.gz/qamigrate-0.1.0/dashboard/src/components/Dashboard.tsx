import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
    GitBranch,
    Play,
    Settings,
    FolderOpen,
    Sparkles,
    Zap,
    Search
} from 'lucide-react'
import StatsCards from './StatsCards'
import MigrationBoard from './MigrationBoard'

export default function Dashboard() {
    const [projectPath, setProjectPath] = useState('./sample-selenium-project')
    const [isScanning, setIsScanning] = useState(false)
    const [scanResult, setScanResult] = useState<any>(null)
    const navigate = useNavigate()

    const handleScan = async () => {
        if (!projectPath) return
        setIsScanning(true)
        try {
            const response = await fetch(`http://localhost:3000/api/scan`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ project_path: projectPath }),
            })
            const data = await response.json()
            setScanResult(data)
        } catch (error) {
            console.error('Scan failed:', error)
        } finally {
            setIsScanning(false)
        }
    }

    return (
        <>
            {/* Top Header Bar */}
            <header className="sticky top-0 z-10 glass border-b border-white/5">
                <div className="px-10 py-5">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-5">
                            <div className="p-3 rounded-2xl bg-gradient-to-br from-blue-500 to-purple-600 shadow-lg shadow-blue-500/25">
                                <GitBranch className="w-6 h-6 text-white" />
                            </div>
                            <div>
                                <h1 className="text-2xl font-bold text-white flex items-center gap-3">
                                    QAMigrate Dashboard
                                    <Sparkles className="w-5 h-5 text-amber-400" />
                                </h1>
                                <p className="text-gray-400 text-sm flex items-center gap-2 mt-0.5">
                                    <Zap className="w-3.5 h-3.5 text-cyan-400" />
                                    Selenium to Playwright Migration Control Center
                                </p>
                            </div>
                        </div>
                        <div className="flex items-center gap-4">
                            <button className="p-2.5 rounded-xl glass hover:bg-white/10 transition-all duration-300">
                                <Search className="w-5 h-5 text-gray-400" />
                            </button>
                            <button
                                onClick={() => navigate('/settings')}
                                className="p-2.5 rounded-xl glass hover:bg-white/10 transition-all duration-300"
                            >
                                <Settings className="w-5 h-5 text-gray-400" />
                            </button>
                        </div>
                    </div>
                </div>
            </header>

            {/* Main Content Area */}
            <div className="px-10 py-8 space-y-8">
                {/* Project Selector Card */}
                <section>
                    <div className="glass-card rounded-2xl p-8">
                        <div className="flex items-center gap-4 mb-6">
                            <div className="p-3 rounded-xl bg-gradient-to-br from-cyan-500/20 to-blue-500/20 border border-cyan-500/20">
                                <FolderOpen className="w-6 h-6 text-cyan-400" />
                            </div>
                            <div>
                                <h2 className="text-xl font-semibold text-white">Select Selenium Project</h2>
                                <p className="text-gray-500 text-sm mt-0.5">
                                    Point to your Selenium Java project root containing pom.xml or build.gradle
                                </p>
                            </div>
                        </div>

                        <div className="flex gap-4">
                            <div className="flex-1 relative">
                                <input
                                    type="text"
                                    value={projectPath}
                                    onChange={(e) => setProjectPath(e.target.value)}
                                    placeholder="Enter project path (e.g., ./sample-selenium-project)"
                                    className="w-full input-dark text-base"
                                />
                            </div>
                            <button
                                onClick={handleScan}
                                disabled={isScanning || !projectPath}
                                className="btn-primary flex items-center gap-3 px-8"
                            >
                                {isScanning ? (
                                    <>
                                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                                        <span>Scanning...</span>
                                    </>
                                ) : (
                                    <>
                                        <Play className="w-5 h-5" />
                                        <span>Scan Project</span>
                                    </>
                                )}
                            </button>
                        </div>
                    </div>
                </section>

                {/* Stats Section */}
                {scanResult && (
                    <section>
                        <div className="flex items-center justify-between mb-6">
                            <h2 className="text-lg font-semibold text-white">Project Analysis</h2>
                            <span className="text-sm text-gray-500">Last scanned: Just now</span>
                        </div>
                        <StatsCards scanResult={scanResult} />
                    </section>
                )}

                {/* Migration Board Section */}
                {scanResult && (
                    <section>
                        <MigrationBoard files={scanResult.files || []} />
                    </section>
                )}

                {/* Empty State */}
                {!scanResult && (
                    <section>
                        <div className="glass-card rounded-2xl p-16 text-center">
                            <div className="w-24 h-24 mx-auto mb-8 rounded-3xl bg-gradient-to-br from-blue-500/20 to-purple-500/20 border border-blue-500/20 flex items-center justify-center">
                                <GitBranch className="w-12 h-12 text-blue-400" />
                            </div>
                            <h3 className="text-2xl font-bold text-white mb-4">Ready to Migrate</h3>
                            <p className="text-gray-400 max-w-lg mx-auto mb-8 leading-relaxed">
                                Scan your Selenium project to analyze test files, detect patterns,
                                and prepare for seamless migration to Playwright.
                            </p>
                            <div className="flex items-center justify-center gap-8 text-sm">
                                <div className="flex items-center gap-3 text-gray-400">
                                    <span className="w-3 h-3 rounded-full bg-green-400 shadow-lg shadow-green-400/50"></span>
                                    <span>AST Analysis</span>
                                </div>
                                <div className="flex items-center gap-3 text-gray-400">
                                    <span className="w-3 h-3 rounded-full bg-blue-400 shadow-lg shadow-blue-400/50"></span>
                                    <span>Pattern Detection</span>
                                </div>
                                <div className="flex items-center gap-3 text-gray-400">
                                    <span className="w-3 h-3 rounded-full bg-purple-400 shadow-lg shadow-purple-400/50"></span>
                                    <span>AI-Powered Migration</span>
                                </div>
                            </div>
                        </div>
                    </section>
                )}
            </div>
        </>
    )
}
