const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000/api'

// ============ Types ============
export interface ScanResult {
    project_path: string
    project_manifest: Record<string, unknown>
    file_count: number
    page_object_count: number
    test_class_count: number
    pattern_summary: Record<string, number>
    complexity_distribution: { low: number; medium: number; high: number }
    patterns_detected: number  // computed from pattern_summary
    patterns: Array<{
        pattern_type: string
        category: string
        file_path: string
        line_number: number
        code_snippet: string
        migration_strategy: string
        complexity_score: number
    }>
    files: FileInfo[]
    dependency_graph: Record<string, string[]>
}

export interface FileInfo {
    path: string
    name: string
    is_page_object?: boolean
    is_test_class?: boolean
    complexity?: number
    pattern_count?: number
    error?: string
}

export interface MigrationStatus {
    file_path: string
    status: 'pending' | 'running' | 'complete' | 'failed'
    phase: string
    progress: number
    error?: string
    output_path?: string
}

export interface VerifyResult {
    success: boolean
    selenium: {
        success: boolean
        exit_code: number
        execution_time_ms: number
        video_path?: string
        error?: string
    }
    playwright: {
        success: boolean
        exit_code: number
        execution_time_ms: number
        video_path?: string
        error?: string
    }
    performance_improvement: number
    docker_available: boolean
}

export interface FileCode {
    original: string
    generated: string
}

// ============ Scan API ============
export async function scanProject(projectPath: string): Promise<ScanResult> {
    const response = await fetch(`${API_BASE_URL}/scan`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ project_path: projectPath }),
    })
    if (!response.ok) {
        const error = await response.json().catch(() => ({ detail: 'Scan failed' }))
        throw new Error(error.detail || 'Scan failed')
    }
    return response.json()
}

// ============ Files API ============
export async function listProjectFiles(projectPath: string): Promise<FileInfo[]> {
    const response = await fetch(`${API_BASE_URL}/files?project_path=${encodeURIComponent(projectPath)}`)
    if (!response.ok) throw new Error('Failed to list files')
    return response.json()
}

export async function getFileCode(filePath: string): Promise<FileCode> {
    const response = await fetch(`${API_BASE_URL}/files/${encodeURIComponent(filePath)}/code`)
    if (!response.ok) throw new Error('Failed to get file code')
    return response.json()
}

// ============ Migration API ============
export async function startMigration(filePath: string, projectPath: string): Promise<MigrationStatus> {
    const response = await fetch(`${API_BASE_URL}/migrate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ file_path: filePath, project_path: projectPath }),
    })
    if (!response.ok) {
        const error = await response.json().catch(() => ({ detail: 'Migration failed' }))
        throw new Error(error.detail || 'Migration failed')
    }
    return response.json()
}

export async function getMigrationStatus(filePath: string): Promise<MigrationStatus> {
    const response = await fetch(`${API_BASE_URL}/migrations/${encodeURIComponent(filePath)}`)
    if (!response.ok) throw new Error('Migration not found')
    return response.json()
}

export async function listMigrations(): Promise<MigrationStatus[]> {
    const response = await fetch(`${API_BASE_URL}/migrations`)
    if (!response.ok) throw new Error('Failed to list migrations')
    return response.json()
}

// ============ Verify API ============
export async function verifyMigration(
    testClass: string,
    projectPath: string,
    appUrl: string = 'http://host.docker.internal:8080',
    recordVideo: boolean = true
): Promise<VerifyResult> {
    const response = await fetch(`${API_BASE_URL}/verify`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            test_class: testClass,
            project_path: projectPath,
            app_url: appUrl,
            record_video: recordVideo,
        }),
    })
    if (!response.ok) {
        const error = await response.json().catch(() => ({ detail: 'Verification failed' }))
        throw new Error(error.detail || 'Verification failed')
    }
    return response.json()
}

// ============ WebSocket ============
export function createProgressWebSocket(onMessage: (data: MigrationStatus) => void) {
    const wsUrl = import.meta.env.VITE_WS_URL || 'ws://localhost:3000/ws/migration'
    const ws = new WebSocket(wsUrl)

    ws.onmessage = (event) => {
        const data = JSON.parse(event.data)
        onMessage(data)
    }

    ws.onerror = (error) => {
        console.error('WebSocket error:', error)
    }

    return ws
}

// ============ Settings API ============
export interface Settings {
    theme: string
    notifications: boolean
    autoMigrate: boolean
    parallelJobs: number
    apiKey: string
    outputDir: string
    language: string
}

export async function getSettings(): Promise<Settings> {
    const response = await fetch(`${API_BASE_URL}/settings`)
    if (!response.ok) throw new Error('Failed to get settings')
    return response.json()
}

export async function saveSettings(settings: Settings): Promise<{ message: string }> {
    const response = await fetch(`${API_BASE_URL}/settings`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
    })
    if (!response.ok) {
        const error = await response.json().catch(() => ({ detail: 'Failed to save settings' }))
        throw new Error(error.detail || 'Failed to save settings')
    }
    return response.json()
}

// ============ Reports API ============
export interface Reports {
    total_migrations: number
    completed: number
    failed: number
    success_rate: number
    avg_execution_time_ms: number
    weekly_completed: number
    weekly_failed: number
    daily_stats: Array<{
        date: string
        total: number
        completed: number
        failed: number
    }>
    recent_migrations: Array<{
        id: number
        file_path: string
        status: string
        created_at: string | null
        execution_time_ms: number
    }>
}

export async function getReports(): Promise<Reports> {
    const response = await fetch(`${API_BASE_URL}/reports`)
    if (!response.ok) throw new Error('Failed to get reports')
    return response.json()
}


