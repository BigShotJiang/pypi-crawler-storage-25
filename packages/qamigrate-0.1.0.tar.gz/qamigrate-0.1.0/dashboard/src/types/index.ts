// QAMigrate API types

export interface ScanResult {
    project_path: string
    project_manifest: {
        name: string
        build_tool: string
        selenium_version: string | null
        test_framework: string | null
    }
    file_count: number
    page_object_count: number
    test_class_count: number
    pattern_summary: Record<string, number>
    complexity_distribution: {
        low: number
        medium: number
        high: number
    }
    files: FileInfo[]
}

export interface FileInfo {
    file_path: string
    class_name: string
    is_page_object: boolean
    is_test_class: boolean
    complexity_score: number
    pattern_count: number
}

export interface MigrationProgress {
    file_path: string
    status: 'pending' | 'scanning' | 'generating' | 'compiling' | 'fixing' | 'verifying' | 'completed' | 'failed'
    progress: number
    current_phase: string
    retry_count: number
    error?: string
}

export interface MigrationResult {
    file_path: string
    output_path: string | null
    success: boolean
    compilation_attempts: number
    error?: string
}

export interface VerificationResult {
    match_percentage: number
    dom_match: boolean
    assertion_match: boolean
    performance_improvement: number
    artifacts: {
        selenium_video?: string
        playwright_video?: string
        diff_report?: string
    }
}
