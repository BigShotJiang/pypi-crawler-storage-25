import { useState, useEffect } from 'react'
import { useLocation } from 'react-router-dom'
import {
    ArrowRightLeft,
    CheckCircle,
    XCircle,
    Clock,
    Loader2,
    ArrowRight,
    FileCode,
    Filter,
    Sparkles,
    Wifi,
    WifiOff
} from 'lucide-react'
import { useToast } from '../components/Toast'
import { scanProject, startMigration as apiMigrate } from '../api/client'
import { useMigrationWebSocket } from '../hooks/useMigration'

interface FileInfo {
    file_path: string
    class_name: string
    is_page_object: boolean
    is_test_class: boolean
    complexity_score: number
}

type Status = 'pending' | 'migrating' | 'completed' | 'failed'

interface FileWithStatus extends FileInfo {
    status: Status
    progress?: number
    phase?: string
}

export default function MigratePage() {
    const location = useLocation()
    const [files, setFiles] = useState<FileWithStatus[]>([])
    const [isMigrating, setIsMigrating] = useState(false)
    const [filter, setFilter] = useState<'all' | 'pending' | 'completed' | 'failed'>('all')
    const [projectPath, setProjectPath] = useState('./sample-selenium-project')
    const { showToast } = useToast()

    // WebSocket for real-time updates
    const { isConnected, progress: wsProgress } = useMigrationWebSocket(true)

    useEffect(() => {
        // Load from navigation state or fetch
        if (location.state?.scanResult?.files) {
            setFiles(location.state.scanResult.files.map((f: FileInfo) => ({ ...f, status: 'pending' as Status })))
            setProjectPath(location.state.projectPath || projectPath)
        } else {
            fetchFiles()
        }
    }, [location.state])

    // Update file statuses from WebSocket progress
    useEffect(() => {
        if (Object.keys(wsProgress).length > 0) {
            setFiles(prev => prev.map(file => {
                const wsFile = wsProgress[file.file_path]
                if (wsFile) {
                    let status: Status = 'migrating'
                    if (wsFile.status === 'completed') status = 'completed'
                    else if (wsFile.status === 'failed') status = 'failed'
                    return { ...file, status, progress: wsFile.progress, phase: wsFile.phase }
                }
                return file
            }))
        }
    }, [wsProgress])

    const fetchFiles = async () => {
        try {
            const data = await scanProject(projectPath)
            setFiles(data.files?.map((f) => ({
                file_path: f.path,
                class_name: f.name.replace('.java', ''),
                is_page_object: f.is_page_object || false,
                is_test_class: f.is_test_class || false,
                complexity_score: f.complexity || 0,
                status: 'pending' as Status
            })) || [])
        } catch (err) {
            console.error('Failed to fetch files:', err)
            showToast('error', 'Failed to Load Files', 'Could not scan project for files')
        }
    }

    const handleMigrate = async (file: FileWithStatus) => {
        setFiles(prev => prev.map(f =>
            f.file_path === file.file_path ? { ...f, status: 'migrating' } : f
        ))

        try {
            const result = await apiMigrate(file.file_path, projectPath)
            const success = result.status === 'complete'

            setFiles(prev => prev.map(f =>
                f.file_path === file.file_path
                    ? { ...f, status: success ? 'completed' : 'failed' }
                    : f
            ))

            if (success) {
                showToast('success', 'Migration Complete', `${file.class_name} migrated successfully`)
            } else {
                showToast('error', 'Migration Failed', result.error || `Failed to migrate ${file.class_name}`)
            }
        } catch (err) {
            setFiles(prev => prev.map(f =>
                f.file_path === file.file_path ? { ...f, status: 'failed' } : f
            ))
            showToast('error', 'Migration Error', err instanceof Error ? err.message : 'Unknown error')
        }
    }

    const handleMigrateAll = async () => {
        setIsMigrating(true)
        const pendingFiles = files.filter(f => f.status === 'pending')
        let successCount = 0
        let failCount = 0

        for (const file of pendingFiles) {
            await handleMigrate(file)
        }

        // Recount after all migrations
        const updatedFiles = files
        successCount = updatedFiles.filter(f => f.status === 'completed').length
        failCount = updatedFiles.filter(f => f.status === 'failed').length

        setIsMigrating(false)
        showToast(
            failCount === 0 ? 'success' : 'warning',
            'Batch Migration Complete',
            `${successCount} succeeded, ${failCount} failed`
        )
    }

    const filteredFiles = files.filter(f => {
        if (filter === 'all') return true
        return f.status === filter
    })

    const stats = {
        total: files.length,
        pending: files.filter(f => f.status === 'pending').length,
        completed: files.filter(f => f.status === 'completed').length,
        failed: files.filter(f => f.status === 'failed').length,
    }

    const progressPercent = stats.total > 0 ? (stats.completed / stats.total) * 100 : 0

    return (
        <div className="p-8 space-y-8">
            {/* Header */}
            <div className="flex items-center justify-between">
                <div>
                    <div className="flex items-center gap-3 mb-2">
                        <h1 className="text-3xl font-bold text-white">Migration Center</h1>
                        {/* WebSocket Connection Status */}
                        <div className={`flex items-center gap-1.5 px-2 py-1 rounded-full text-xs font-medium ${isConnected
                                ? 'bg-green-500/15 text-green-400'
                                : 'bg-gray-500/15 text-gray-400'
                            }`}>
                            {isConnected ? (
                                <>
                                    <Wifi className="w-3 h-3" />
                                    <span>Live</span>
                                </>
                            ) : (
                                <>
                                    <WifiOff className="w-3 h-3" />
                                    <span>Offline</span>
                                </>
                            )}
                        </div>
                    </div>
                    <p className="text-gray-400">
                        Transform your Selenium tests to Playwright with AI-powered migration
                    </p>
                </div>
                <button
                    onClick={handleMigrateAll}
                    disabled={isMigrating || stats.pending === 0}
                    className="btn-primary flex items-center gap-3 px-6"
                >
                    {isMigrating ? (
                        <>
                            <Loader2 className="w-5 h-5 animate-spin" />
                            <span>Migrating...</span>
                        </>
                    ) : (
                        <>
                            <Sparkles className="w-5 h-5" />
                            <span>Migrate All ({stats.pending})</span>
                        </>
                    )}
                </button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-4 gap-4">
                <div className="glass-card rounded-xl p-4 flex items-center gap-4">
                    <div className="p-3 rounded-xl bg-blue-500/15">
                        <FileCode className="w-5 h-5 text-blue-400" />
                    </div>
                    <div>
                        <p className="text-2xl font-bold text-white">{stats.total}</p>
                        <p className="text-sm text-gray-500">Total Files</p>
                    </div>
                </div>
                <div className="glass-card rounded-xl p-4 flex items-center gap-4">
                    <div className="p-3 rounded-xl bg-gray-500/15">
                        <Clock className="w-5 h-5 text-gray-400" />
                    </div>
                    <div>
                        <p className="text-2xl font-bold text-white">{stats.pending}</p>
                        <p className="text-sm text-gray-500">Pending</p>
                    </div>
                </div>
                <div className="glass-card rounded-xl p-4 flex items-center gap-4">
                    <div className="p-3 rounded-xl bg-green-500/15">
                        <CheckCircle className="w-5 h-5 text-green-400" />
                    </div>
                    <div>
                        <p className="text-2xl font-bold text-white">{stats.completed}</p>
                        <p className="text-sm text-gray-500">Completed</p>
                    </div>
                </div>
                <div className="glass-card rounded-xl p-4 flex items-center gap-4">
                    <div className="p-3 rounded-xl bg-red-500/15">
                        <XCircle className="w-5 h-5 text-red-400" />
                    </div>
                    <div>
                        <p className="text-2xl font-bold text-white">{stats.failed}</p>
                        <p className="text-sm text-gray-500">Failed</p>
                    </div>
                </div>
            </div>

            {/* Progress */}
            <div className="glass-card rounded-2xl p-6">
                <div className="flex items-center justify-between mb-3">
                    <span className="text-gray-400 font-medium">Overall Progress</span>
                    <span className="text-white font-semibold">{Math.round(progressPercent)}%</span>
                </div>
                <div className="h-3 bg-gray-800/60 rounded-full overflow-hidden">
                    <div
                        className="h-full bg-gradient-to-r from-green-500 via-emerald-400 to-cyan-400 rounded-full transition-all duration-700"
                        style={{ width: `${progressPercent}%` }}
                    />
                </div>
            </div>

            {/* File List */}
            <div className="glass-card rounded-2xl overflow-hidden">
                <div className="p-4 border-b border-white/5 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <ArrowRightLeft className="w-5 h-5 text-purple-400" />
                        <span className="font-semibold text-white">Files to Migrate</span>
                    </div>
                    <div className="flex items-center gap-2">
                        <Filter className="w-4 h-4 text-gray-500" />
                        {(['all', 'pending', 'completed', 'failed'] as const).map(f => (
                            <button
                                key={f}
                                onClick={() => setFilter(f)}
                                className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors ${filter === f ? 'bg-blue-500 text-white' : 'text-gray-400 hover:text-white'
                                    }`}
                            >
                                {f.charAt(0).toUpperCase() + f.slice(1)}
                            </button>
                        ))}
                    </div>
                </div>

                <div className="p-4 space-y-2 max-h-[500px] overflow-y-auto">
                    {filteredFiles.map(file => (
                        <div
                            key={file.file_path}
                            className={`flex items-center justify-between p-4 rounded-xl border transition-all ${file.status === 'migrating'
                                ? 'border-blue-500/40 bg-blue-500/5'
                                : file.status === 'completed'
                                    ? 'border-green-500/40 bg-green-500/5'
                                    : file.status === 'failed'
                                        ? 'border-red-500/40 bg-red-500/5'
                                        : 'border-gray-700/40 bg-gray-800/20 hover:bg-gray-800/40'
                                }`}
                        >
                            <div className="flex items-center gap-4">
                                <div className={`p-2 rounded-lg ${file.status === 'completed' ? 'bg-green-500/15' :
                                    file.status === 'failed' ? 'bg-red-500/15' :
                                        file.status === 'migrating' ? 'bg-blue-500/15' : 'bg-gray-700/50'
                                    }`}>
                                    {file.status === 'completed' ? <CheckCircle className="w-4 h-4 text-green-400" /> :
                                        file.status === 'failed' ? <XCircle className="w-4 h-4 text-red-400" /> :
                                            file.status === 'migrating' ? <Loader2 className="w-4 h-4 text-blue-400 animate-spin" /> :
                                                <Clock className="w-4 h-4 text-gray-400" />}
                                </div>
                                <div>
                                    <p className="font-medium text-white">{file.class_name}</p>
                                    <p className="text-sm text-gray-500">{file.file_path}</p>
                                </div>
                            </div>

                            <div className="flex items-center gap-3">
                                {file.is_page_object && (
                                    <span className="px-2 py-1 rounded text-xs font-medium bg-purple-500/15 text-purple-300">
                                        Page Object
                                    </span>
                                )}
                                {file.is_test_class && (
                                    <span className="px-2 py-1 rounded text-xs font-medium bg-blue-500/15 text-blue-300">
                                        Test
                                    </span>
                                )}
                                {file.status === 'pending' && (
                                    <button
                                        onClick={() => handleMigrate(file)}
                                        className="p-2 rounded-lg bg-blue-500 hover:bg-blue-400 text-white transition-colors"
                                    >
                                        <ArrowRight className="w-4 h-4" />
                                    </button>
                                )}
                            </div>
                        </div>
                    ))}

                    {filteredFiles.length === 0 && (
                        <div className="text-center py-12 text-gray-500">
                            <FileCode className="w-12 h-12 mx-auto mb-3 opacity-30" />
                            <p>No files match the current filter</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    )
}
