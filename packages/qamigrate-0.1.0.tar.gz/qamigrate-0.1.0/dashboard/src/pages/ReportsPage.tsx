import { useState, useEffect } from 'react'
import {
    BarChart3,
    TrendingUp,
    Clock,
    CheckCircle,
    XCircle,
    Activity,
    ArrowUpRight,
    ArrowDownRight,
    Calendar,
    Loader2
} from 'lucide-react'
import { getReports, type Reports } from '../api/client'

export default function ReportsPage() {
    const [stats, setStats] = useState<Reports | null>(null)
    const [loading, setLoading] = useState(true)
    const [timeRange, setTimeRange] = useState<'day' | 'week' | 'month'>('week')

    useEffect(() => {
        loadReports()
    }, [])

    const loadReports = async () => {
        try {
            const data = await getReports()
            setStats(data)
        } catch (err) {
            console.error('Failed to load reports:', err)
        } finally {
            setLoading(false)
        }
    }

    // Transform daily stats for chart
    const weeklyData = stats?.daily_stats?.length
        ? stats.daily_stats.map(d => ({
            day: new Date(d.date).toLocaleDateString('en-US', { weekday: 'short' }),
            migrations: d.total,
            success: d.completed,
        }))
        : [
            { day: 'Mon', migrations: 0, success: 0 },
            { day: 'Tue', migrations: 0, success: 0 },
            { day: 'Wed', migrations: 0, success: 0 },
            { day: 'Thu', migrations: 0, success: 0 },
            { day: 'Fri', migrations: 0, success: 0 },
            { day: 'Sat', migrations: 0, success: 0 },
            { day: 'Sun', migrations: 0, success: 0 },
        ]

    const maxMigrations = Math.max(...weeklyData.map(d => d.migrations), 1)

    if (loading) {
        return (
            <div className="p-8 flex items-center justify-center">
                <Loader2 className="w-8 h-8 text-blue-400 animate-spin" />
            </div>
        )
    }

    return (
        <div className="p-8 space-y-8">
            {/* Header */}
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-3xl font-bold text-white mb-2">Reports & Analytics</h1>
                    <p className="text-gray-400">
                        Track migration progress and performance metrics
                    </p>
                </div>
                <div className="flex items-center gap-2 bg-gray-800/50 rounded-lg p-1">
                    {(['day', 'week', 'month'] as const).map(range => (
                        <button
                            key={range}
                            onClick={() => setTimeRange(range)}
                            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${timeRange === range ? 'bg-blue-500 text-white' : 'text-gray-400 hover:text-white'
                                }`}
                        >
                            {range.charAt(0).toUpperCase() + range.slice(1)}
                        </button>
                    ))}
                </div>
            </div>

            {/* Stats Grid */}
            {stats && (
                <div className="grid grid-cols-4 gap-6">
                    <div className="glass-card rounded-2xl p-6">
                        <div className="flex items-center justify-between mb-4">
                            <div className="p-3 rounded-xl bg-blue-500/15">
                                <Activity className="w-6 h-6 text-blue-400" />
                            </div>
                            <div className="flex items-center gap-1 text-green-400 text-sm">
                                <ArrowUpRight className="w-4 h-4" />
                                <span>12%</span>
                            </div>
                        </div>
                        <p className="text-3xl font-bold text-white mb-1">{stats.total_migrations}</p>
                        <p className="text-gray-500 text-sm">Total Migrations</p>
                    </div>

                    <div className="glass-card rounded-2xl p-6">
                        <div className="flex items-center justify-between mb-4">
                            <div className="p-3 rounded-xl bg-green-500/15">
                                <CheckCircle className="w-6 h-6 text-green-400" />
                            </div>
                            <div className="flex items-center gap-1 text-green-400 text-sm">
                                <ArrowUpRight className="w-4 h-4" />
                                <span>8%</span>
                            </div>
                        </div>
                        <p className="text-3xl font-bold text-white mb-1">{stats.completed}</p>
                        <p className="text-gray-500 text-sm">Successful</p>
                    </div>

                    <div className="glass-card rounded-2xl p-6">
                        <div className="flex items-center justify-between mb-4">
                            <div className="p-3 rounded-xl bg-red-500/15">
                                <XCircle className="w-6 h-6 text-red-400" />
                            </div>
                            <div className="flex items-center gap-1 text-red-400 text-sm">
                                <ArrowDownRight className="w-4 h-4" />
                                <span>3%</span>
                            </div>
                        </div>
                        <p className="text-3xl font-bold text-white mb-1">{stats.failed}</p>
                        <p className="text-gray-500 text-sm">Failed</p>
                    </div>

                    <div className="glass-card rounded-2xl p-6">
                        <div className="flex items-center justify-between mb-4">
                            <div className="p-3 rounded-xl bg-purple-500/15">
                                <TrendingUp className="w-6 h-6 text-purple-400" />
                            </div>
                            <div className="flex items-center gap-1 text-green-400 text-sm">
                                <ArrowUpRight className="w-4 h-4" />
                                <span>5%</span>
                            </div>
                        </div>
                        <p className="text-3xl font-bold text-white mb-1">{stats.success_rate.toFixed(1)}%</p>
                        <p className="text-gray-500 text-sm">Success Rate</p>
                    </div>
                </div>
            )}

            {/* Chart */}
            <div className="glass-card rounded-2xl p-6">
                <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-3">
                        <BarChart3 className="w-5 h-5 text-purple-400" />
                        <h2 className="text-lg font-semibold text-white">Migration Activity</h2>
                    </div>
                    <div className="flex items-center gap-4 text-sm">
                        <span className="flex items-center gap-2">
                            <span className="w-3 h-3 rounded-full bg-blue-500"></span>
                            <span className="text-gray-400">Total</span>
                        </span>
                        <span className="flex items-center gap-2">
                            <span className="w-3 h-3 rounded-full bg-green-500"></span>
                            <span className="text-gray-400">Success</span>
                        </span>
                    </div>
                </div>

                <div className="flex items-end gap-4 h-48">
                    {weeklyData.map((d, i) => (
                        <div key={i} className="flex-1 flex flex-col items-center gap-2">
                            <div className="w-full flex gap-1 justify-center" style={{ height: '160px' }}>
                                <div
                                    className="w-4 bg-blue-500/30 rounded-t-md transition-all hover:bg-blue-500/50"
                                    style={{ height: `${(d.migrations / maxMigrations) * 100}%`, marginTop: 'auto' }}
                                />
                                <div
                                    className="w-4 bg-green-500/50 rounded-t-md transition-all hover:bg-green-500/70"
                                    style={{ height: `${(d.success / maxMigrations) * 100}%`, marginTop: 'auto' }}
                                />
                            </div>
                            <span className="text-xs text-gray-500">{d.day}</span>
                        </div>
                    ))}
                </div>
            </div>

            {/* Performance */}
            <div className="grid grid-cols-2 gap-6">
                <div className="glass-card rounded-2xl p-6">
                    <div className="flex items-center gap-3 mb-6">
                        <Clock className="w-5 h-5 text-cyan-400" />
                        <h2 className="text-lg font-semibold text-white">Average Execution Time</h2>
                    </div>
                    <p className="text-4xl font-bold text-white mb-2">
                        {stats ? (stats.avg_execution_time_ms / 1000).toFixed(1) : 0}s
                    </p>
                    <p className="text-gray-500">Per file migration</p>
                    <div className="mt-6 h-2 bg-gray-800 rounded-full overflow-hidden">
                        <div className="h-full w-3/4 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full" />
                    </div>
                </div>

                <div className="glass-card rounded-2xl p-6">
                    <div className="flex items-center gap-3 mb-6">
                        <Calendar className="w-5 h-5 text-amber-400" />
                        <h2 className="text-lg font-semibold text-white">This Week Summary</h2>
                    </div>
                    <div className="space-y-4">
                        <div className="flex items-center justify-between">
                            <span className="text-gray-400">Files Migrated</span>
                            <span className="font-semibold text-white">42</span>
                        </div>
                        <div className="flex items-center justify-between">
                            <span className="text-gray-400">Tests Verified</span>
                            <span className="font-semibold text-white">18</span>
                        </div>
                        <div className="flex items-center justify-between">
                            <span className="text-gray-400">Projects Scanned</span>
                            <span className="font-semibold text-white">3</span>
                        </div>
                        <div className="flex items-center justify-between">
                            <span className="text-gray-400">Time Saved</span>
                            <span className="font-semibold text-green-400">~4.5 hours</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
