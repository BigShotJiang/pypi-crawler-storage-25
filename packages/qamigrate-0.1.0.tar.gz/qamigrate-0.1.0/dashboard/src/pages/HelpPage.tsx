import {
    HelpCircle,
    Book,
    MessageCircle,
    Github,
    ExternalLink,
    Zap,
    ArrowRight,
} from 'lucide-react'

export default function HelpPage() {
    const faqs = [
        {
            question: "How does QAMigrate migrate Selenium to Playwright?",
            answer: "QAMigrate uses AST (Abstract Syntax Tree) analysis with Tree-sitter to parse your Selenium Java code, then uses AI (Claude) to generate equivalent Playwright code while preserving test logic and patterns."
        },
        {
            question: "What Selenium patterns are supported?",
            answer: "We support Page Object Model, WebDriver APIs, WebElement operations, explicit waits, assertions, and most common Selenium patterns. Complex custom implementations may require manual review."
        },
        {
            question: "How does verification work?",
            answer: "QAMigrate runs both Selenium and Playwright tests in Docker containers, captures video recordings, and compares execution to ensure behavioral equivalence."
        },
        {
            question: "Can I use QAMigrate without Docker?",
            answer: "Yes! Docker is optional and only required for verification. Scanning and migration work without Docker. Local test execution is used as a fallback."
        }
    ]

    const resources = [
        {
            title: "Documentation",
            description: "Full API reference and guides",
            icon: Book,
            url: "#",
            color: "blue"
        },
        {
            title: "GitHub Repository",
            description: "Source code and issues",
            icon: Github,
            url: "https://github.com/qamigrate/qamigrate",
            color: "gray"
        },
        {
            title: "Discord Community",
            description: "Get help from the community",
            icon: MessageCircle,
            url: "#",
            color: "purple"
        },
    ]

    return (
        <div className="p-8 space-y-8 max-w-5xl">
            {/* Header */}
            <div>
                <h1 className="text-3xl font-bold text-white mb-2">Help Center</h1>
                <p className="text-gray-400">
                    Learn how to use QAMigrate and get support
                </p>
            </div>

            {/* Quick Start */}
            <div className="glass-card rounded-2xl p-6">
                <div className="flex items-center gap-3 mb-6">
                    <div className="p-2 rounded-lg bg-green-500/15">
                        <Zap className="w-5 h-5 text-green-400" />
                    </div>
                    <h2 className="text-lg font-semibold text-white">Quick Start Guide</h2>
                </div>

                <div className="grid grid-cols-3 gap-4">
                    <div className="p-4 rounded-xl bg-gray-800/30 border border-gray-700/50">
                        <div className="flex items-center gap-3 mb-3">
                            <span className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center text-white font-bold text-sm">1</span>
                            <h3 className="font-medium text-white">Scan Project</h3>
                        </div>
                        <p className="text-sm text-gray-400 mb-3">
                            Point QAMigrate to your Selenium Java project to analyze patterns and complexity.
                        </p>
                        <a href="/scan" className="text-blue-400 text-sm flex items-center gap-1 hover:underline">
                            Go to Scan <ArrowRight className="w-3 h-3" />
                        </a>
                    </div>

                    <div className="p-4 rounded-xl bg-gray-800/30 border border-gray-700/50">
                        <div className="flex items-center gap-3 mb-3">
                            <span className="w-8 h-8 rounded-full bg-purple-500 flex items-center justify-center text-white font-bold text-sm">2</span>
                            <h3 className="font-medium text-white">Migrate Files</h3>
                        </div>
                        <p className="text-sm text-gray-400 mb-3">
                            Use AI-powered migration to convert Selenium code to Playwright automatically.
                        </p>
                        <a href="/migrate" className="text-purple-400 text-sm flex items-center gap-1 hover:underline">
                            Go to Migrate <ArrowRight className="w-3 h-3" />
                        </a>
                    </div>

                    <div className="p-4 rounded-xl bg-gray-800/30 border border-gray-700/50">
                        <div className="flex items-center gap-3 mb-3">
                            <span className="w-8 h-8 rounded-full bg-green-500 flex items-center justify-center text-white font-bold text-sm">3</span>
                            <h3 className="font-medium text-white">Verify Tests</h3>
                        </div>
                        <p className="text-sm text-gray-400 mb-3">
                            Run both versions in Docker and compare behavior with video recordings.
                        </p>
                        <a href="/verify" className="text-green-400 text-sm flex items-center gap-1 hover:underline">
                            Go to Verify <ArrowRight className="w-3 h-3" />
                        </a>
                    </div>
                </div>
            </div>

            {/* FAQ */}
            <div className="glass-card rounded-2xl p-6">
                <div className="flex items-center gap-3 mb-6">
                    <div className="p-2 rounded-lg bg-amber-500/15">
                        <HelpCircle className="w-5 h-5 text-amber-400" />
                    </div>
                    <h2 className="text-lg font-semibold text-white">Frequently Asked Questions</h2>
                </div>

                <div className="space-y-4">
                    {faqs.map((faq, i) => (
                        <details key={i} className="group">
                            <summary className="flex items-center justify-between p-4 rounded-xl bg-gray-800/30 cursor-pointer hover:bg-gray-800/50 transition-colors">
                                <span className="font-medium text-white">{faq.question}</span>
                                <span className="text-gray-500 group-open:rotate-180 transition-transform">▼</span>
                            </summary>
                            <div className="p-4 text-gray-400 text-sm leading-relaxed">
                                {faq.answer}
                            </div>
                        </details>
                    ))}
                </div>
            </div>

            {/* Resources */}
            <div className="glass-card rounded-2xl p-6">
                <div className="flex items-center gap-3 mb-6">
                    <div className="p-2 rounded-lg bg-cyan-500/15">
                        <Book className="w-5 h-5 text-cyan-400" />
                    </div>
                    <h2 className="text-lg font-semibold text-white">Resources</h2>
                </div>

                <div className="grid grid-cols-3 gap-4">
                    {resources.map((resource, i) => (
                        <a
                            key={i}
                            href={resource.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-4 rounded-xl bg-gray-800/30 border border-gray-700/50 hover:border-gray-600/50 transition-colors group"
                        >
                            <div className="flex items-center justify-between mb-3">
                                <resource.icon className={`w-6 h-6 text-${resource.color}-400`} />
                                <ExternalLink className="w-4 h-4 text-gray-600 group-hover:text-gray-400 transition-colors" />
                            </div>
                            <h3 className="font-medium text-white mb-1">{resource.title}</h3>
                            <p className="text-sm text-gray-500">{resource.description}</p>
                        </a>
                    ))}
                </div>
            </div>

            {/* Support */}
            <div className="glass-card rounded-2xl p-6 bg-gradient-to-r from-blue-500/10 to-purple-500/10 border-blue-500/20">
                <div className="flex items-center justify-between">
                    <div>
                        <h2 className="text-lg font-semibold text-white mb-2">Need More Help?</h2>
                        <p className="text-gray-400">Get priority support and advanced features with QAMigrate Pro</p>
                    </div>
                    <button className="btn-primary">
                        Upgrade to Pro
                    </button>
                </div>
            </div>
        </div>
    )
}
