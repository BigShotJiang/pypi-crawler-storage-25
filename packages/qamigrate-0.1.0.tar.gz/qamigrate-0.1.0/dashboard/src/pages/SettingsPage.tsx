import { useState, useEffect } from 'react'
import {
    Moon,
    Sun,
    Bell,
    Key,
    Database,
    Save,
    CheckCircle,
    Loader2
} from 'lucide-react'
import { getSettings, saveSettings, type Settings as SettingsType } from '../api/client'
import { useToast } from '../components/Toast'

export default function SettingsPage() {
    const [saved, setSaved] = useState(false)
    const [loading, setLoading] = useState(true)
    const [_saving, setSaving] = useState(false)
    const { showToast } = useToast()
    const [settings, setSettings] = useState<SettingsType>({
        theme: 'dark',
        notifications: true,
        autoMigrate: false,
        parallelJobs: 2,
        apiKey: '',
        outputDir: './playwright',
        language: 'en',
    })

    useEffect(() => {
        loadSettings()
    }, [])

    const loadSettings = async () => {
        try {
            const data = await getSettings()
            setSettings(data)
        } catch (err) {
            console.error('Failed to load settings:', err)
        } finally {
            setLoading(false)
        }
    }

    const handleSave = async () => {
        setSaving(true)
        try {
            await saveSettings(settings)
            setSaved(true)
            showToast('success', 'Settings Saved', 'Your preferences have been saved successfully')
            setTimeout(() => setSaved(false), 2000)
        } catch (err) {
            showToast('error', 'Save Failed', err instanceof Error ? err.message : 'Failed to save settings')
        } finally {
            setSaving(false)
        }
    }

    if (loading) {
        return (
            <div className="p-8 flex items-center justify-center">
                <Loader2 className="w-8 h-8 text-blue-400 animate-spin" />
            </div>
        )
    }

    return (
        <div className="p-8 space-y-8 max-w-4xl">
            {/* Header */}
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-3xl font-bold text-white mb-2">Settings</h1>
                    <p className="text-gray-400">
                        Configure QAMigrate preferences and integrations
                    </p>
                </div>
                <button
                    onClick={handleSave}
                    className="btn-primary flex items-center gap-2"
                >
                    {saved ? (
                        <>
                            <CheckCircle className="w-5 h-5" />
                            <span>Saved!</span>
                        </>
                    ) : (
                        <>
                            <Save className="w-5 h-5" />
                            <span>Save Changes</span>
                        </>
                    )}
                </button>
            </div>

            {/* Appearance */}
            <div className="glass-card rounded-2xl p-6">
                <div className="flex items-center gap-3 mb-6">
                    <div className="p-2 rounded-lg bg-purple-500/15">
                        <Moon className="w-5 h-5 text-purple-400" />
                    </div>
                    <h2 className="text-lg font-semibold text-white">Appearance</h2>
                </div>

                <div className="space-y-4">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="text-white font-medium">Theme</p>
                            <p className="text-sm text-gray-500">Choose your preferred color scheme</p>
                        </div>
                        <div className="flex items-center gap-2 bg-gray-800/50 rounded-lg p-1">
                            <button
                                onClick={() => setSettings({ ...settings, theme: 'dark' })}
                                className={`px-4 py-2 rounded-md flex items-center gap-2 ${settings.theme === 'dark' ? 'bg-blue-500 text-white' : 'text-gray-400'
                                    }`}
                            >
                                <Moon className="w-4 h-4" /> Dark
                            </button>
                            <button
                                onClick={() => setSettings({ ...settings, theme: 'light' })}
                                className={`px-4 py-2 rounded-md flex items-center gap-2 ${settings.theme === 'light' ? 'bg-blue-500 text-white' : 'text-gray-400'
                                    }`}
                            >
                                <Sun className="w-4 h-4" /> Light
                            </button>
                        </div>
                    </div>

                    <div className="flex items-center justify-between">
                        <div>
                            <p className="text-white font-medium">Language</p>
                            <p className="text-sm text-gray-500">Select your language preference</p>
                        </div>
                        <select
                            value={settings.language}
                            onChange={(e) => setSettings({ ...settings, language: e.target.value })}
                            className="input-dark w-40"
                        >
                            <option value="en">English</option>
                            <option value="es">Español</option>
                            <option value="fr">Français</option>
                            <option value="de">Deutsch</option>
                        </select>
                    </div>
                </div>
            </div>

            {/* Notifications */}
            <div className="glass-card rounded-2xl p-6">
                <div className="flex items-center gap-3 mb-6">
                    <div className="p-2 rounded-lg bg-amber-500/15">
                        <Bell className="w-5 h-5 text-amber-400" />
                    </div>
                    <h2 className="text-lg font-semibold text-white">Notifications</h2>
                </div>

                <div className="space-y-4">
                    <label className="flex items-center justify-between cursor-pointer">
                        <div>
                            <p className="text-white font-medium">Migration Notifications</p>
                            <p className="text-sm text-gray-500">Get notified when migrations complete</p>
                        </div>
                        <div className={`w-12 h-6 rounded-full p-1 transition-colors ${settings.notifications ? 'bg-blue-500' : 'bg-gray-700'
                            }`}>
                            <div className={`w-4 h-4 rounded-full bg-white transition-transform ${settings.notifications ? 'translate-x-6' : ''
                                }`} />
                        </div>
                    </label>

                    <label className="flex items-center justify-between cursor-pointer">
                        <div>
                            <p className="text-white font-medium">Auto-Migrate</p>
                            <p className="text-sm text-gray-500">Automatically migrate files after scanning</p>
                        </div>
                        <div className={`w-12 h-6 rounded-full p-1 transition-colors ${settings.autoMigrate ? 'bg-blue-500' : 'bg-gray-700'
                            }`}>
                            <div className={`w-4 h-4 rounded-full bg-white transition-transform ${settings.autoMigrate ? 'translate-x-6' : ''
                                }`} />
                        </div>
                    </label>
                </div>
            </div>

            {/* API Configuration */}
            <div className="glass-card rounded-2xl p-6">
                <div className="flex items-center gap-3 mb-6">
                    <div className="p-2 rounded-lg bg-cyan-500/15">
                        <Key className="w-5 h-5 text-cyan-400" />
                    </div>
                    <h2 className="text-lg font-semibold text-white">API Configuration</h2>
                </div>

                <div className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-400 mb-2">Anthropic API Key</label>
                        <input
                            type="password"
                            value={settings.apiKey}
                            onChange={(e) => setSettings({ ...settings, apiKey: e.target.value })}
                            className="w-full input-dark"
                            placeholder="sk-ant-..."
                        />
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-400 mb-2">Parallel Jobs</label>
                        <input
                            type="number"
                            min="1"
                            max="10"
                            value={settings.parallelJobs}
                            onChange={(e) => setSettings({ ...settings, parallelJobs: parseInt(e.target.value) })}
                            className="w-40 input-dark"
                        />
                    </div>
                </div>
            </div>

            {/* Output Configuration */}
            <div className="glass-card rounded-2xl p-6">
                <div className="flex items-center gap-3 mb-6">
                    <div className="p-2 rounded-lg bg-green-500/15">
                        <Database className="w-5 h-5 text-green-400" />
                    </div>
                    <h2 className="text-lg font-semibold text-white">Output Configuration</h2>
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-400 mb-2">Output Directory</label>
                    <input
                        type="text"
                        value={settings.outputDir}
                        onChange={(e) => setSettings({ ...settings, outputDir: e.target.value })}
                        className="w-full input-dark"
                        placeholder="./playwright"
                    />
                    <p className="mt-2 text-sm text-gray-500">
                        Directory where migrated Playwright files will be saved
                    </p>
                </div>
            </div>
        </div>
    )
}
