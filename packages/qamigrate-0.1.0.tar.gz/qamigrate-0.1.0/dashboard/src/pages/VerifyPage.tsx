import { useState } from 'react'
import {
    CheckCircle2,
    Play,
    Loader2,
    AlertCircle,
    Clock,
    Video,
    FileCode,
    Zap
} from 'lucide-react'
import TruthPlayer from '../components/TruthPlayer'
import { useToast } from '../components/Toast'
import { verifyMigration, type VerifyResult } from '../api/client'

export default function VerifyPage() {
    const [testClass, setTestClass] = useState('com.example.tests.LoginTest')
    const [projectPath, setProjectPath] = useState('./sample-selenium-project')
    const [appUrl, setAppUrl] = useState('http://localhost:8080')
    const [isVerifying, setIsVerifying] = useState(false)
    const [result, setResult] = useState<VerifyResult | null>(null)
    const [error, setError] = useState<string | null>(null)
    const { showToast } = useToast()

    const handleVerify = async () => {
        setIsVerifying(true)
        setError(null)
        setResult(null)

        try {
            const data = await verifyMigration(testClass, projectPath, appUrl, true)
            setResult(data)

            if (data.success) {
                showToast('success', 'Verification Passed', `Playwright is ${data.performance_improvement.toFixed(1)}x faster than Selenium`)
            } else {
                showToast('warning', 'Verification Issues', 'One or more tests failed - check results for details')
            }
        } catch (err) {
            const message = err instanceof Error ? err.message : 'Verification failed'
            setError(message)
            showToast('error', 'Verification Failed', message)
        } finally {
            setIsVerifying(false)
        }
    }

    return (
        <div className="p-8 space-y-8">
            {/* Header */}
            <div>
                <h1 className="text-3xl font-bold text-white mb-2">Verification Center</h1>
                <p className="text-gray-400">
                    Run tests in Docker containers and compare Selenium vs Playwright execution
                </p>
            </div>

            {/* Configuration */}
            <div className="glass-card rounded-2xl p-6">
                <div className="flex items-center gap-3 mb-6">
                    <div className="p-2 rounded-lg bg-green-500/15">
                        <CheckCircle2 className="w-5 h-5 text-green-400" />
                    </div>
                    <h2 className="text-lg font-semibold text-white">Test Configuration</h2>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-6">
                    <div>
                        <label className="block text-sm font-medium text-gray-400 mb-2">Test Class</label>
                        <input
                            type="text"
                            value={testClass}
                            onChange={(e) => setTestClass(e.target.value)}
                            placeholder="com.example.tests.LoginTest"
                            className="w-full input-dark"
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-400 mb-2">Project Path</label>
                        <input
                            type="text"
                            value={projectPath}
                            onChange={(e) => setProjectPath(e.target.value)}
                            placeholder="./sample-selenium-project"
                            className="w-full input-dark"
                        />
                    </div>
                </div>

                <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-400 mb-2">Application URL</label>
                    <input
                        type="text"
                        value={appUrl}
                        onChange={(e) => setAppUrl(e.target.value)}
                        placeholder="http://localhost:8080"
                        className="w-full input-dark"
                    />
                </div>

                <button
                    onClick={handleVerify}
                    disabled={isVerifying}
                    className="btn-primary flex items-center gap-3"
                >
                    {isVerifying ? (
                        <>
                            <Loader2 className="w-5 h-5 animate-spin" />
                            <span>Running Tests...</span>
                        </>
                    ) : (
                        <>
                            <Play className="w-5 h-5" />
                            <span>Start Verification</span>
                        </>
                    )}
                </button>

                {error && (
                    <div className="mt-4 p-4 rounded-xl bg-red-500/10 border border-red-500/20 flex items-center gap-3">
                        <AlertCircle className="w-5 h-5 text-red-400" />
                        <span className="text-red-400">{error}</span>
                    </div>
                )}
            </div>

            {/* Results */}
            {result && (
                <>
                    {/* Summary Cards */}
                    <div className="grid grid-cols-4 gap-4">
                        <div className={`glass-card rounded-xl p-4 ${result.success ? 'border-green-500/30' : 'border-red-500/30'}`}>
                            <div className="flex items-center gap-3 mb-2">
                                {result.success ? (
                                    <CheckCircle2 className="w-5 h-5 text-green-400" />
                                ) : (
                                    <AlertCircle className="w-5 h-5 text-red-400" />
                                )}
                                <span className="text-gray-400 text-sm">Overall</span>
                            </div>
                            <p className={`text-xl font-bold ${result.success ? 'text-green-400' : 'text-red-400'}`}>
                                {result.success ? 'PASSED' : 'FAILED'}
                            </p>
                        </div>

                        <div className="glass-card rounded-xl p-4">
                            <div className="flex items-center gap-3 mb-2">
                                <Clock className="w-5 h-5 text-red-400" />
                                <span className="text-gray-400 text-sm">Selenium Time</span>
                            </div>
                            <p className="text-xl font-bold text-white">{result.selenium.execution_time_ms}ms</p>
                        </div>

                        <div className="glass-card rounded-xl p-4">
                            <div className="flex items-center gap-3 mb-2">
                                <Zap className="w-5 h-5 text-green-400" />
                                <span className="text-gray-400 text-sm">Playwright Time</span>
                            </div>
                            <p className="text-xl font-bold text-white">{result.playwright.execution_time_ms}ms</p>
                        </div>

                        <div className="glass-card rounded-xl p-4 border-green-500/30">
                            <div className="flex items-center gap-3 mb-2">
                                <Zap className="w-5 h-5 text-green-400" />
                                <span className="text-gray-400 text-sm">Improvement</span>
                            </div>
                            <p className="text-xl font-bold text-green-400">{result.performance_improvement.toFixed(1)}x faster</p>
                        </div>
                    </div>

                    {/* Video Comparison */}
                    {result.selenium.video_path && result.playwright.video_path && (
                        <TruthPlayer
                            seleniumVideoUrl={result.selenium.video_path}
                            playwrightVideoUrl={result.playwright.video_path}
                            seleniumTime={result.selenium.execution_time_ms}
                            playwrightTime={result.playwright.execution_time_ms}
                        />
                    )}

                    {/* No video placeholder */}
                    {(!result.selenium.video_path || !result.playwright.video_path) && (
                        <div className="glass-card rounded-2xl p-12 text-center">
                            <Video className="w-12 h-12 mx-auto mb-4 text-gray-600" />
                            <h3 className="text-lg font-semibold text-white mb-2">No Videos Available</h3>
                            <p className="text-gray-500">
                                Videos are recorded when running in Docker containers.
                                Run verification with Docker to see video comparison.
                            </p>
                        </div>
                    )}
                </>
            )}

            {/* Empty State */}
            {!result && !isVerifying && (
                <div className="glass-card rounded-2xl p-12 text-center">
                    <div className="w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-green-500/15 to-emerald-500/15 flex items-center justify-center">
                        <CheckCircle2 className="w-10 h-10 text-green-400" />
                    </div>
                    <h3 className="text-xl font-semibold text-white mb-3">Ready to Verify</h3>
                    <p className="text-gray-400 max-w-md mx-auto mb-6">
                        Run both Selenium and Playwright tests in parallel Docker containers,
                        then compare execution times and video recordings.
                    </p>
                    <div className="flex items-center justify-center gap-6 text-sm text-gray-500">
                        <span className="flex items-center gap-2">
                            <FileCode className="w-4 h-4" /> Test Execution
                        </span>
                        <span className="flex items-center gap-2">
                            <Video className="w-4 h-4" /> Video Recording
                        </span>
                        <span className="flex items-center gap-2">
                            <Zap className="w-4 h-4" /> Performance Analysis
                        </span>
                    </div>
                </div>
            )}
        </div>
    )
}
