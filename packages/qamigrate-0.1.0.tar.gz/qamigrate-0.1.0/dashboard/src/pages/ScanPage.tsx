import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
    FolderSearch,
    Play,
    FileCode,
    AlertCircle,
    CheckCircle2,
    Loader2,
    FolderOpen,
    History
} from 'lucide-react'
import { useToast } from '../components/Toast'
import { scanProject, type ScanResult } from '../api/client'

export default function ScanPage() {
    const [projectPath, setProjectPath] = useState('./sample-selenium-project')
    const [isScanning, setIsScanning] = useState(false)
    const [scanResult, setScanResult] = useState<ScanResult | null>(null)
    const [error, setError] = useState<string | null>(null)
    const [recentScans, setRecentScans] = useState([
        { path: './sample-selenium-project', date: '2 min ago', files: 9 },
        { path: './another-project', date: '1 hour ago', files: 24 },
    ])
    const navigate = useNavigate()
    const { showToast } = useToast()

    const handleScan = async () => {
        if (!projectPath) return
        setIsScanning(true)
        setError(null)

        try {
            const data = await scanProject(projectPath)
            setScanResult(data)
            showToast('success', 'Scan Complete', `Found ${data.file_count} files with ${data.patterns?.length || 0} Selenium patterns`)

            // Update recent scans
            setRecentScans(prev => [
                { path: projectPath, date: 'Just now', files: data.file_count },
                ...prev.filter(s => s.path !== projectPath).slice(0, 4)
            ])
        } catch (err) {
            const message = err instanceof Error ? err.message : 'Scan failed'
            setError(message)
            showToast('error', 'Scan Failed', message)
        } finally {
            setIsScanning(false)
        }
    }

    const handleMigrate = () => {
        navigate('/migrate', { state: { scanResult, projectPath } })
    }

    return (
        <div className="p-8 space-y-8">
            {/* Header */}
            <div>
                <h1 className="text-3xl font-bold text-white mb-2">Scan Project</h1>
                <p className="text-gray-400">
                    Analyze your Selenium project to detect patterns and prepare for migration
                </p>
            </div>

            {/* Scan Card */}
            <div className="glass-card rounded-2xl p-8">
                <div className="flex items-start gap-6 mb-8">
                    <div className="p-4 rounded-2xl bg-gradient-to-br from-cyan-500/20 to-blue-500/20 border border-cyan-500/20">
                        <FolderSearch className="w-8 h-8 text-cyan-400" />
                    </div>
                    <div className="flex-1">
                        <h2 className="text-xl font-semibold text-white mb-2">Select Project Directory</h2>
                        <p className="text-gray-500 text-sm">
                            Enter the path to your Selenium Java project containing pom.xml or build.gradle
                        </p>
                    </div>
                </div>

                <div className="flex gap-4 mb-6">
                    <div className="flex-1 relative">
                        <FolderOpen className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                        <input
                            type="text"
                            value={projectPath}
                            onChange={(e) => setProjectPath(e.target.value)}
                            placeholder="./path/to/selenium-project"
                            className="w-full input-dark pl-12 text-base"
                        />
                    </div>
                    <button
                        onClick={handleScan}
                        disabled={isScanning || !projectPath}
                        className="btn-primary flex items-center gap-3 px-8"
                    >
                        {isScanning ? (
                            <>
                                <Loader2 className="w-5 h-5 animate-spin" />
                                <span>Scanning...</span>
                            </>
                        ) : (
                            <>
                                <Play className="w-5 h-5" />
                                <span>Start Scan</span>
                            </>
                        )}
                    </button>
                </div>

                {error && (
                    <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/20 flex items-center gap-3">
                        <AlertCircle className="w-5 h-5 text-red-400" />
                        <span className="text-red-400">{error}</span>
                    </div>
                )}
            </div>

            {/* Results */}
            {scanResult && (
                <div className="glass-card rounded-2xl p-8">
                    <div className="flex items-center justify-between mb-6">
                        <div className="flex items-center gap-3">
                            <CheckCircle2 className="w-6 h-6 text-green-400" />
                            <h2 className="text-xl font-semibold text-white">Scan Complete</h2>
                        </div>
                        <button onClick={handleMigrate} className="btn-primary">
                            Continue to Migration →
                        </button>
                    </div>

                    <div className="grid grid-cols-4 gap-6">
                        <div className="p-6 rounded-xl bg-gradient-to-br from-blue-500/10 to-cyan-500/5 border border-blue-500/20">
                            <div className="flex items-center gap-3 mb-3">
                                <FileCode className="w-5 h-5 text-blue-400" />
                                <span className="text-gray-400 text-sm">Total Files</span>
                            </div>
                            <p className="text-3xl font-bold text-white">{scanResult.file_count}</p>
                        </div>
                        <div className="p-6 rounded-xl bg-gradient-to-br from-purple-500/10 to-pink-500/5 border border-purple-500/20">
                            <div className="flex items-center gap-3 mb-3">
                                <FileCode className="w-5 h-5 text-purple-400" />
                                <span className="text-gray-400 text-sm">Page Objects</span>
                            </div>
                            <p className="text-3xl font-bold text-white">{scanResult.page_object_count}</p>
                        </div>
                        <div className="p-6 rounded-xl bg-gradient-to-br from-emerald-500/10 to-green-500/5 border border-emerald-500/20">
                            <div className="flex items-center gap-3 mb-3">
                                <FileCode className="w-5 h-5 text-emerald-400" />
                                <span className="text-gray-400 text-sm">Test Classes</span>
                            </div>
                            <p className="text-3xl font-bold text-white">{scanResult.test_class_count}</p>
                        </div>
                        <div className="p-6 rounded-xl bg-gradient-to-br from-amber-500/10 to-orange-500/5 border border-amber-500/20">
                            <div className="flex items-center gap-3 mb-3">
                                <AlertCircle className="w-5 h-5 text-amber-400" />
                                <span className="text-gray-400 text-sm">High Complexity</span>
                            </div>
                            <p className="text-3xl font-bold text-white">{scanResult.complexity_distribution?.high || 0}</p>
                        </div>
                    </div>
                </div>
            )}

            {/* Recent Scans */}
            <div className="glass-card rounded-2xl p-6">
                <div className="flex items-center gap-3 mb-6">
                    <History className="w-5 h-5 text-gray-400" />
                    <h2 className="text-lg font-semibold text-white">Recent Scans</h2>
                </div>
                <div className="space-y-3">
                    {recentScans.map((scan, i) => (
                        <div
                            key={i}
                            className="flex items-center justify-between p-4 rounded-xl bg-gray-800/30 hover:bg-gray-800/50 cursor-pointer transition-colors"
                            onClick={() => setProjectPath(scan.path)}
                        >
                            <div className="flex items-center gap-3">
                                <FolderOpen className="w-5 h-5 text-gray-500" />
                                <span className="text-white">{scan.path}</span>
                            </div>
                            <div className="flex items-center gap-4 text-sm text-gray-500">
                                <span>{scan.files} files</span>
                                <span>{scan.date}</span>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    )
}
