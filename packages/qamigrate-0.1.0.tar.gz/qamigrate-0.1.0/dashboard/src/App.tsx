import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import Sidebar from './components/Sidebar'
import Dashboard from './components/Dashboard'
import { ToastProvider } from './components/Toast'
import { ScanPage, MigratePage, VerifyPage, ReportsPage, SettingsPage, HelpPage, LoginPage } from './pages'
import './App.css'

const queryClient = new QueryClient()

function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <main className="flex-1 overflow-auto">
        {children}
      </main>
    </div>
  )
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ToastProvider>
        <BrowserRouter>
          <Routes>
            {/* Login page - no sidebar */}
            <Route path="/login" element={<LoginPage />} />

            {/* Main app with sidebar */}
            <Route path="/*" element={
              <AppLayout>
                <Routes>
                  <Route path="/" element={<Dashboard />} />
                  <Route path="/scan" element={<ScanPage />} />
                  <Route path="/migrate" element={<MigratePage />} />
                  <Route path="/verify" element={<VerifyPage />} />
                  <Route path="/reports" element={<ReportsPage />} />
                  <Route path="/settings" element={<SettingsPage />} />
                  <Route path="/help" element={<HelpPage />} />
                </Routes>
              </AppLayout>
            } />
          </Routes>
        </BrowserRouter>
      </ToastProvider>
    </QueryClientProvider>
  )
}

export default App

