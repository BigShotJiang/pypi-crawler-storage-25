import * as vscode from 'vscode';
import axios from 'axios';

let outputChannel: vscode.OutputChannel;

export function activate(context: vscode.ExtensionContext) {
    outputChannel = vscode.window.createOutputChannel('QAMigrate');
    outputChannel.appendLine('QAMigrate extension activated');

    // Register commands
    context.subscriptions.push(
        vscode.commands.registerCommand('qamigrate.migrateFile', migrateFile),
        vscode.commands.registerCommand('qamigrate.migrateProject', migrateProject),
        vscode.commands.registerCommand('qamigrate.scanProject', scanProject),
        vscode.commands.registerCommand('qamigrate.previewMigration', previewMigration)
    );

    // Auto-scan on workspace open if enabled
    const config = vscode.workspace.getConfiguration('qamigrate');
    if (config.get('autoScan')) {
        scanProjectOnOpen();
    }

    outputChannel.appendLine('QAMigrate commands registered');
}

async function getServerUrl(): Promise<string> {
    const config = vscode.workspace.getConfiguration('qamigrate');
    return config.get('serverUrl') || 'http://localhost:3000';
}

async function migrateFile() {
    const editor = vscode.window.activeTextEditor;
    if (!editor) {
        vscode.window.showErrorMessage('No file is currently open');
        return;
    }

    const filePath = editor.document.uri.fsPath;
    if (!filePath.endsWith('.java')) {
        vscode.window.showErrorMessage('Only Java files can be migrated');
        return;
    }

    const serverUrl = await getServerUrl();

    await vscode.window.withProgress({
        location: vscode.ProgressLocation.Notification,
        title: 'QAMigrate: Migrating file...',
        cancellable: false
    }, async (progress) => {
        try {
            progress.report({ message: 'Connecting to QAMigrate server...' });

            // Get workspace root
            const workspaceFolder = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
            if (!workspaceFolder) {
                throw new Error('No workspace folder found');
            }

            progress.report({ message: 'Generating Playwright code...' });

            const response = await axios.post(`${serverUrl}/api/migrate`, {
                file_path: filePath,
                project_path: workspaceFolder
            }, { timeout: 300000 }); // 5 minute timeout

            if (response.data.success) {
                vscode.window.showInformationMessage(
                    `✓ Migration successful: ${response.data.output_path}`,
                    'Open File'
                ).then(selection => {
                    if (selection === 'Open File') {
                        vscode.workspace.openTextDocument(response.data.output_path)
                            .then(doc => vscode.window.showTextDocument(doc));
                    }
                });
            } else {
                vscode.window.showErrorMessage(
                    `Migration failed: ${response.data.error}`
                );
            }
        } catch (error: any) {
            outputChannel.appendLine(`Error: ${error.message}`);
            vscode.window.showErrorMessage(
                `QAMigrate error: ${error.message}. Is the server running?`
            );
        }
    });
}

async function migrateProject() {
    const workspaceFolder = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
    if (!workspaceFolder) {
        vscode.window.showErrorMessage('No workspace folder found');
        return;
    }

    const confirm = await vscode.window.showWarningMessage(
        'This will migrate all Java files in the project. Continue?',
        'Yes', 'No'
    );

    if (confirm !== 'Yes') {
        return;
    }

    const serverUrl = await getServerUrl();

    await vscode.window.withProgress({
        location: vscode.ProgressLocation.Notification,
        title: 'QAMigrate: Migrating project...',
        cancellable: true
    }, async (progress, token) => {
        try {
            const response = await axios.post(`${serverUrl}/api/migrate/batch`, {
                project_path: workspaceFolder,
                all_files: true
            }, { timeout: 600000 }); // 10 minute timeout

            if (response.data.success_count > 0) {
                vscode.window.showInformationMessage(
                    `✓ Migration complete: ${response.data.success_count} files migrated, ${response.data.failed_count} failed`
                );
            } else {
                vscode.window.showWarningMessage(
                    `Migration completed with ${response.data.failed_count} failures`
                );
            }
        } catch (error: any) {
            vscode.window.showErrorMessage(
                `QAMigrate error: ${error.message}`
            );
        }
    });
}

async function scanProject() {
    const workspaceFolder = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
    if (!workspaceFolder) {
        vscode.window.showErrorMessage('No workspace folder found');
        return;
    }

    const serverUrl = await getServerUrl();

    await vscode.window.withProgress({
        location: vscode.ProgressLocation.Notification,
        title: 'QAMigrate: Scanning project...',
        cancellable: false
    }, async () => {
        try {
            const response = await axios.post(`${serverUrl}/api/scan`, {
                project_path: workspaceFolder
            }, { timeout: 60000 });

            const data = response.data;
            vscode.window.showInformationMessage(
                `Scan complete: ${data.total_files} files, ${data.page_objects} page objects, ${data.test_classes} test classes`
            );

            outputChannel.appendLine(`Scan results: ${JSON.stringify(data, null, 2)}`);
            outputChannel.show();
        } catch (error: any) {
            vscode.window.showErrorMessage(
                `Scan error: ${error.message}`
            );
        }
    });
}

async function scanProjectOnOpen() {
    // Delay scan to allow workspace to fully load
    setTimeout(() => scanProject(), 3000);
}

async function previewMigration() {
    const editor = vscode.window.activeTextEditor;
    if (!editor) {
        vscode.window.showErrorMessage('No file is currently open');
        return;
    }

    const filePath = editor.document.uri.fsPath;
    if (!filePath.endsWith('.java')) {
        vscode.window.showErrorMessage('Only Java files can be previewed');
        return;
    }

    const serverUrl = await getServerUrl();

    try {
        const response = await axios.post(`${serverUrl}/api/preview`, {
            file_path: filePath,
            content: editor.document.getText()
        }, { timeout: 60000 });

        // Show preview in a new panel
        const panel = vscode.window.createWebviewPanel(
            'qamigratePreview',
            'QAMigrate: Migration Preview',
            vscode.ViewColumn.Beside,
            { enableScripts: true }
        );

        panel.webview.html = getPreviewHtml(response.data);
    } catch (error: any) {
        vscode.window.showErrorMessage(
            `Preview error: ${error.message}`
        );
    }
}

function getPreviewHtml(data: any): string {
    return `<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; padding: 20px; }
        h1 { color: #0066cc; }
        .stats { display: flex; gap: 20px; margin-bottom: 20px; }
        .stat { background: #f5f5f5; padding: 15px; border-radius: 8px; }
        .stat-value { font-size: 24px; font-weight: bold; color: #0066cc; }
        .patterns { margin-top: 20px; }
        .pattern { background: #fff3cd; padding: 10px; margin: 5px 0; border-radius: 4px; }
        pre { background: #1e1e1e; color: #d4d4d4; padding: 15px; border-radius: 8px; overflow-x: auto; }
    </style>
</head>
<body>
    <h1>🚀 QAMigrate Migration Preview</h1>
    
    <div class="stats">
        <div class="stat">
            <div class="stat-value">${data.patterns_found || 0}</div>
            <div>Selenium Patterns</div>
        </div>
        <div class="stat">
            <div class="stat-value">${data.complexity || 0}</div>
            <div>Complexity Score</div>
        </div>
        <div class="stat">
            <div class="stat-value">${data.estimated_time || '~30s'}</div>
            <div>Est. Migration Time</div>
        </div>
    </div>

    <h2>Detected Patterns</h2>
    <div class="patterns">
        ${(data.patterns || []).map((p: string) => `<div class="pattern">${p}</div>`).join('')}
    </div>

    <h2>Preview Code</h2>
    <pre>${data.preview_code || 'Run migration to generate code'}</pre>
</body>
</html>`;
}

export function deactivate() {
    outputChannel?.dispose();
}
