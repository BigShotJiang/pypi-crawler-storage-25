# QAMigrate - VS Code Extension

AI-powered Selenium to Playwright migration right in your IDE.

## Features

- **Migrate File**: Right-click any Java file → "QAMigrate: Migrate File to Playwright"
- **Migrate Project**: Migrate all Selenium tests in your project
- **Scan Project**: Detect Selenium patterns and get migration insights
- **Preview Migration**: See what Playwright code will look like before migrating

## Installation

### From VSIX (Local)
```bash
cd vscode-extension
npm install
npm run compile
npm run package
# Install the generated .vsix file in VS Code
```

### Requirements
- VS Code 1.85.0 or higher
- QAMigrate server running locally (`uv run qamigrate dashboard`)

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `qamigrate.serverUrl` | `http://localhost:3000` | QAMigrate server URL |
| `qamigrate.autoScan` | `true` | Auto-scan on project open |
| `qamigrate.showMigrationHints` | `true` | Show inline migration hints |

## Usage

1. Start the QAMigrate server: `uv run qamigrate dashboard`
2. Open a Selenium Java project in VS Code
3. Right-click a Java file → "QAMigrate: Migrate File to Playwright"
4. View migrated code in the generated `playwright/` folder

## Commands

| Command | Description |
|---------|-------------|
| `QAMigrate: Migrate File to Playwright` | Migrate current file |
| `QAMigrate: Migrate Entire Project` | Migrate all Java files |
| `QAMigrate: Scan Project for Selenium Patterns` | Analyze project |
| `QAMigrate: Preview Migration` | Preview without saving |
