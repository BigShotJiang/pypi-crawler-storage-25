package com.example.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

/**
 * Home Page Object after successful login.
 * Contains navigation and main dashboard elements.
 */
public class HomePage {
    
    private final WebDriver driver;
    private final WebDriverWait wait;
    
    @FindBy(css = ".welcome-message")
    private WebElement welcomeMessage;
    
    @FindBy(id = "logout-btn")
    private WebElement logoutButton;
    
    @FindBy(css = "nav.main-navigation a")
    private List<WebElement> navigationLinks;
    
    @FindBy(id = "search-input")
    private WebElement searchInput;
    
    @FindBy(css = "button.search-btn")
    private WebElement searchButton;
    
    @FindBy(id = "user-dropdown")
    private WebElement userDropdown;
    
    @FindBy(css = ".notification-badge")
    private WebElement notificationBadge;
    
    @FindBy(xpath = "//select[@id='language-selector']")
    private WebElement languageSelector;
    
    public HomePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        PageFactory.initElements(driver, this);
    }
    
    public String getWelcomeMessage() {
        wait.until(ExpectedConditions.visibilityOf(welcomeMessage));
        return welcomeMessage.getText();
    }
    
    public void clickLogout() {
        wait.until(ExpectedConditions.elementToBeClickable(logoutButton));
        logoutButton.click();
    }
    
    public void navigateToSection(String sectionName) {
        for (WebElement link : navigationLinks) {
            if (link.getText().equalsIgnoreCase(sectionName)) {
                link.click();
                break;
            }
        }
    }
    
    public void search(String query) {
        wait.until(ExpectedConditions.visibilityOf(searchInput));
        searchInput.clear();
        searchInput.sendKeys(query);
        searchButton.click();
    }
    
    public void openUserMenu() {
        wait.until(ExpectedConditions.elementToBeClickable(userDropdown));
        userDropdown.click();
    }
    
    public int getNotificationCount() {
        try {
            String badgeText = notificationBadge.getText();
            return Integer.parseInt(badgeText);
        } catch (Exception e) {
            return 0;
        }
    }
    
    public void selectLanguage(String language) {
        wait.until(ExpectedConditions.visibilityOf(languageSelector));
        Select select = new Select(languageSelector);
        select.selectByVisibleText(language);
    }
    
    public boolean isUserLoggedIn() {
        try {
            return welcomeMessage.isDisplayed() && logoutButton.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }
    
    public String getCurrentUrl() {
        return driver.getCurrentUrl();
    }
    
    public void waitForPageLoad() {
        wait.until(ExpectedConditions.visibilityOf(welcomeMessage));
    }
}
