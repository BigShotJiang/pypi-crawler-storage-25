package com.example.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.interactions.Actions;

import java.time.Duration;
import java.util.List;

/**
 * Products Page Object for e-commerce functionality.
 * Demonstrates more complex Selenium patterns.
 */
public class ProductsPage {
    
    private final WebDriver driver;
    private final WebDriverWait wait;
    private final Actions actions;
    
    @FindBy(css = ".product-card")
    private List<WebElement> productCards;
    
    @FindBy(id = "price-filter-min")
    private WebElement minPriceInput;
    
    @FindBy(id = "price-filter-max")
    private WebElement maxPriceInput;
    
    @FindBy(css = "button.apply-filters")
    private WebElement applyFiltersButton;
    
    @FindBy(css = ".add-to-cart-btn")
    private List<WebElement> addToCartButtons;
    
    @FindBy(id = "cart-count")
    private WebElement cartCount;
    
    @FindBy(css = ".product-image")
    private List<WebElement> productImages;
    
    @FindBy(xpath = "//div[@class='pagination']//a")
    private List<WebElement> paginationLinks;
    
    public ProductsPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        this.actions = new Actions(driver);
        PageFactory.initElements(driver, this);
    }
    
    public int getProductCount() {
        wait.until(ExpectedConditions.visibilityOfAllElements(productCards));
        return productCards.size();
    }
    
    public void filterByPriceRange(double min, double max) {
        minPriceInput.clear();
        minPriceInput.sendKeys(String.valueOf(min));
        maxPriceInput.clear();
        maxPriceInput.sendKeys(String.valueOf(max));
        applyFiltersButton.click();
    }
    
    public void addProductToCart(int index) {
        if (index < addToCartButtons.size()) {
            WebElement button = addToCartButtons.get(index);
            wait.until(ExpectedConditions.elementToBeClickable(button));
            button.click();
        }
    }
    
    public int getCartItemCount() {
        try {
            return Integer.parseInt(cartCount.getText());
        } catch (Exception e) {
            return 0;
        }
    }
    
    public void hoverOverProduct(int index) {
        if (index < productCards.size()) {
            WebElement product = productCards.get(index);
            actions.moveToElement(product).perform();
        }
    }
    
    public void clickProductImage(int index) {
        if (index < productImages.size()) {
            WebElement image = productImages.get(index);
            wait.until(ExpectedConditions.elementToBeClickable(image));
            image.click();
        }
    }
    
    public void goToPage(int pageNumber) {
        for (WebElement link : paginationLinks) {
            if (link.getText().equals(String.valueOf(pageNumber))) {
                link.click();
                break;
            }
        }
    }
    
    public void scrollToBottom() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
    }
    
    public void scrollToElement(WebElement element) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", element);
    }
    
    public String getProductName(int index) {
        if (index < productCards.size()) {
            WebElement card = productCards.get(index);
            return card.findElement(By.cssSelector(".product-name")).getText();
        }
        return "";
    }
    
    public double getProductPrice(int index) {
        if (index < productCards.size()) {
            WebElement card = productCards.get(index);
            String priceText = card.findElement(By.cssSelector(".product-price")).getText();
            return Double.parseDouble(priceText.replace("$", "").trim());
        }
        return 0.0;
    }
}
