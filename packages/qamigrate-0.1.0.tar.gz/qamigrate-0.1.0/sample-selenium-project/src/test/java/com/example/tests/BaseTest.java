package com.example.tests;

import com.example.utils.DriverFactory;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

/**
 * Base test class with common setup and teardown.
 */
public class BaseTest {
    
    protected WebDriver driver;
    protected static final String BASE_URL = "https://demo.qamigrate.dev";
    
    @BeforeMethod
    @Parameters({"browser"})
    public void setUp(String browser) {
        if (browser == null || browser.isEmpty()) {
            browser = "chrome";
        }
        DriverFactory.initDriver(browser);
        driver = DriverFactory.getDriver();
    }
    
    @AfterMethod
    public void tearDown() {
        DriverFactory.quitDriver();
    }
    
    protected void navigateTo(String path) {
        driver.get(BASE_URL + path);
    }
    
    protected void sleep(int milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
