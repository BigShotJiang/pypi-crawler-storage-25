package com.example.tests;

import com.example.pages.LoginPage;
import com.example.pages.HomePage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * Login functionality test class.
 */
public class LoginTest extends BaseTest {
    
    private LoginPage loginPage;
    
    @BeforeMethod
    public void initPage() {
        navigateTo("/login");
        loginPage = new LoginPage(driver);
    }
    
    @Test(description = "Verify successful login with valid credentials")
    public void testValidLogin() {
        HomePage homePage = loginPage.login("testuser", "password123");
        
        Assert.assertTrue(homePage.isUserLoggedIn(), "User should be logged in");
        Assert.assertTrue(homePage.getWelcomeMessage().contains("Welcome"));
    }
    
    @Test(description = "Verify error message for invalid credentials")
    public void testInvalidLogin() {
        loginPage.enterUsername("invalid@email.com");
        loginPage.enterPassword("wrongpassword");
        loginPage.clickLoginButton();
        
        Assert.assertTrue(loginPage.isErrorDisplayed(), "Error message should be displayed");
        Assert.assertEquals(loginPage.getErrorMessage(), "Invalid username or password");
    }
    
    @Test(description = "Verify login button is disabled when fields are empty")
    public void testEmptyFields() {
        Assert.assertFalse(loginPage.isLoginButtonEnabled(), 
            "Login button should be disabled with empty fields");
    }
    
    @Test(description = "Verify password field masks input")
    public void testPasswordMasking() {
        loginPage.enterPassword("secretpassword");
        // Password field should have type="password"
    }
    
    @Test(description = "Verify forgot password link navigation")
    public void testForgotPasswordLink() {
        loginPage.clickForgotPassword();
        
        Assert.assertTrue(driver.getCurrentUrl().contains("/forgot-password"),
            "Should navigate to forgot password page");
    }
    
    @Test(description = "Verify page title")
    public void testPageTitle() {
        Assert.assertEquals(loginPage.getPageTitle(), "Login - Demo App");
    }
}
