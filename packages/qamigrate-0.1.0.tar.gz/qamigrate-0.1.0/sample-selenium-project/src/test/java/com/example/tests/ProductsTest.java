package com.example.tests;

import com.example.pages.ProductsPage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * Products page test class.
 */
public class ProductsTest extends BaseTest {
    
    private ProductsPage productsPage;
    
    @BeforeMethod
    public void initPage() {
        navigateTo("/products");
        productsPage = new ProductsPage(driver);
    }
    
    @Test(description = "Verify products are displayed")
    public void testProductsDisplayed() {
        int productCount = productsPage.getProductCount();
        Assert.assertTrue(productCount > 0, "Products should be displayed");
    }
    
    @Test(description = "Verify price filter works")
    public void testPriceFilter() {
        productsPage.filterByPriceRange(10.0, 50.0);
        sleep(1000);
        
        int count = productsPage.getProductCount();
        Assert.assertTrue(count > 0, "Filtered products should be displayed");
    }
    
    @Test(description = "Verify add to cart functionality")
    public void testAddToCart() {
        int initialCount = productsPage.getCartItemCount();
        productsPage.addProductToCart(0);
        sleep(500);
        
        int newCount = productsPage.getCartItemCount();
        Assert.assertEquals(newCount, initialCount + 1, "Cart count should increase");
    }
    
    @Test(description = "Verify product hover shows details")
    public void testProductHover() {
        productsPage.hoverOverProduct(0);
        // Verify hover state - quick view button becomes visible
    }
    
    @Test(description = "Verify pagination works")
    public void testPagination() {
        productsPage.goToPage(2);
        sleep(1000);
        
        Assert.assertTrue(driver.getCurrentUrl().contains("page=2"),
            "URL should contain page parameter");
    }
    
    @Test(description = "Verify scroll to bottom loads more products")
    public void testInfiniteScroll() {
        int initialCount = productsPage.getProductCount();
        productsPage.scrollToBottom();
        sleep(2000);
        
        // If infinite scroll is enabled, more products should load
    }
}
