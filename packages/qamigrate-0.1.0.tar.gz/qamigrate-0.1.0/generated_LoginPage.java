package com.example.pages;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.AriaRole;

public class LoginPage {

    private final Page page;
    private final Locator usernameInput;
    private final Locator passwordInput;
    private final Locator loginButton;
    private final Locator errorMessage;
    private final Locator forgotPasswordLink;

    public LoginPage(Page page) {
    this.page = page;
    this.usernameInput = page.locator("#username");
    this.passwordInput = page.locator("#password");
    this.loginButton = page.locator("button[type='submit']");
    this.errorMessage = page.locator(".error-message");
    this.forgotPasswordLink = page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Forgot Password"));
    }

    // Migration: Removed explicit wait - Playwright auto-waits for visibility. Replaced clear() + sendKeys() with fill() which clears automatically.
    public void enterUsername(String username) {
        // Playwright auto-waits for element to be visible and editable
        usernameInput.fill(username);
    }

    // Migration: Removed explicit wait - Playwright auto-waits for visibility. Replaced clear() + sendKeys() with fill() which clears automatically.
    public void enterPassword(String password) {
        // Playwright auto-waits for element to be visible and editable
        passwordInput.fill(password);
    }

    // Migration: Removed explicit wait - Playwright auto-waits for element to be clickable.
    public void clickLoginButton() {
        // Playwright auto-waits for element to be clickable
        loginButton.click();
    }

    // Migration: Changed HomePage constructor to accept Page instead of WebDriver.
    public HomePage login(String username, String password) {
        enterUsername(username);
        enterPassword(password);
        clickLoginButton();
        return new HomePage(page);
    }

    // Migration: Removed explicit wait - Playwright auto-waits. Replaced getText() with textContent().
    public String getErrorMessage() {
        // Playwright auto-waits for element to be visible
        return errorMessage.textContent();
    }

    // Migration: Replaced isDisplayed() with isVisible() - Playwright method.
    public boolean isErrorDisplayed() {
        try {
        return errorMessage.isVisible();
        } catch (Exception e) {
        return false;
    }
    }

    // Migration: Removed explicit wait - Playwright auto-waits for element to be clickable.
    public void clickForgotPassword() {
        // Playwright auto-waits for element to be clickable
        forgotPasswordLink.click();
    }

    public boolean isLoginButtonEnabled() {
        return loginButton.isEnabled();
    }

    // Migration: Replaced driver.getTitle() with page.title().
    public String getPageTitle() {
        return page.title();
    }

    // Migration: Replaced driver.get() with page.navigate().
    public void navigateTo(String url) {
        page.navigate(url);
    }

}