# QAMigrate Deployment Guide - Hostinger VPS

## Deployment Options

| Option | Best For | Complexity |
|--------|----------|------------|
| **Docker on VPS** ⭐ | Production web app | Medium |
| **PyPI Package** | CLI distribution | Low |
| **Docker Hub** | Easy container pulls | Low |

> **Note:** QAMigrate is a **Python application**, not a Node.js package, so it goes on **PyPI** (not npm).

---

## 🚀 Option 1: Hostinger VPS Deployment (Recommended)

### Step 1: Connect to VPS
```bash
ssh root@your-server-ip
# Or with your Hostinger SSH credentials
```

### Step 2: Install Docker
```bash
# Update system
apt update && apt upgrade -y

# Install Docker
curl -fsSL https://get.docker.com | sh

# Install Docker Compose
apt install docker-compose-plugin -y

# Verify installation
docker --version
docker compose version
```

### Step 3: Clone Repository
```bash
# Create app directory
mkdir -p /opt/qamigrate
cd /opt/qamigrate

# Clone your repo (replace with your GitHub URL)
git clone https://github.com/yourusername/qamigrate.git .
```

### Step 4: Configure Environment
```bash
# Copy environment template
cp .env.example .env

# Edit with your values
nano .env
```

**Required `.env` values:**
```bash
ANTHROPIC_API_KEY=sk-ant-xxxxx
OPENAI_API_KEY=sk-xxxxx
QAMIGRATE_JWT_SECRET=$(python3 -c "import secrets; print(secrets.token_hex(32))")
```

### Step 5: Update Domain in Code
```bash
# Update SEO URLs to your domain
sed -i 's/qamigrate.dev/yourdomain.com/g' dashboard/index.html
sed -i 's/qamigrate.dev/yourdomain.com/g' dashboard/public/sitemap.xml
```

### Step 6: Build and Run
```bash
# Build Docker image
docker build -t qamigrate:latest .

# Run container
docker run -d \
  --name qamigrate \
  --restart unless-stopped \
  -p 3000:3000 \
  --env-file .env \
  qamigrate:latest

# Check it's running
docker ps
docker logs qamigrate
```

### Step 7: Set Up Nginx Reverse Proxy
```bash
# Install Nginx
apt install nginx -y

# Create config
nano /etc/nginx/sites-available/qamigrate
```

**Nginx config:**
```nginx
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    # WebSocket support
    location /ws {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
    }
}
```

```bash
# Enable site
ln -s /etc/nginx/sites-available/qamigrate /etc/nginx/sites-enabled/
nginx -t
systemctl restart nginx
```

### Step 8: Configure SSL (Let's Encrypt)
```bash
# Install Certbot
apt install certbot python3-certbot-nginx -y

# Get SSL certificate
certbot --nginx -d yourdomain.com -d www.yourdomain.com

# Auto-renewal is configured automatically
```

### Step 9: Configure DNS (Hostinger Panel)
In your Hostinger control panel, add:
- **A Record:** `@` → Your VPS IP
- **A Record:** `www` → Your VPS IP

---

## 🐳 Option 2: Docker Compose (Easier)

Create `docker-compose.prod.yml`:
```yaml
version: '3.8'

services:
  qamigrate:
    build: .
    container_name: qamigrate
    restart: unless-stopped
    ports:
      - "3000:3000"
    environment:
      - ANTHROPIC_API_KEY=${ANTHROPIC_API_KEY}
      - OPENAI_API_KEY=${OPENAI_API_KEY}
      - QAMIGRATE_JWT_SECRET=${QAMIGRATE_JWT_SECRET}
    volumes:
      - qamigrate-data:/app/.qamigrate
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3000/api/health"]
      interval: 30s
      timeout: 10s
      retries: 3

volumes:
  qamigrate-data:
```

Run:
```bash
docker compose -f docker-compose.prod.yml up -d
```

---

## 📦 Option 3: PyPI Package (CLI Distribution)

To publish QAMigrate as a CLI tool:

```bash
# Build package
uv build

# Upload to PyPI (you need PyPI account)
uv publish

# Users can then install with:
pip install qamigrate
# or
pipx install qamigrate
```

---

## 🔄 CI/CD with GitHub Actions

Create `.github/workflows/deploy.yml`:
```yaml
name: Deploy to VPS

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Deploy to VPS
        uses: appleboy/ssh-action@v1.0.0
        with:
          host: ${{ secrets.VPS_HOST }}
          username: ${{ secrets.VPS_USER }}
          key: ${{ secrets.VPS_SSH_KEY }}
          script: |
            cd /opt/qamigrate
            git pull origin main
            docker build -t qamigrate:latest .
            docker stop qamigrate || true
            docker rm qamigrate || true
            docker run -d --name qamigrate --restart unless-stopped \
              -p 3000:3000 --env-file .env qamigrate:latest
```

**GitHub Secrets to add:**
- `VPS_HOST`: Your VPS IP
- `VPS_USER`: root (or your SSH user)
- `VPS_SSH_KEY`: Your private SSH key

---

## 🔍 Post-Deployment Verification

```bash
# Check container status
docker ps

# Check logs
docker logs qamigrate -f

# Test API
curl https://yourdomain.com/api/health

# Test WebSocket
wscat -c wss://yourdomain.com/ws/progress
```

---

## 📊 Quick Reference

| Command | Description |
|---------|-------------|
| `docker logs qamigrate -f` | View logs |
| `docker restart qamigrate` | Restart app |
| `docker stop qamigrate` | Stop app |
| `docker exec -it qamigrate sh` | Shell access |
| `certbot renew` | Renew SSL |
