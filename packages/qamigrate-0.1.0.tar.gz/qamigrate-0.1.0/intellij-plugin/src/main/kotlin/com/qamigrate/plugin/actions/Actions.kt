package com.qamigrate.plugin.actions

import com.intellij.openapi.actionSystem.AnAction
import com.intellij.openapi.actionSystem.AnActionEvent
import com.intellij.openapi.actionSystem.CommonDataKeys
import com.intellij.openapi.progress.ProgressIndicator
import com.intellij.openapi.progress.ProgressManager
import com.intellij.openapi.progress.Task
import com.intellij.openapi.project.Project
import com.intellij.openapi.ui.Messages
import com.intellij.openapi.vfs.VirtualFile
import com.qamigrate.plugin.services.QAMigrateService

class MigrateFileAction : AnAction() {

    override fun actionPerformed(e: AnActionEvent) {
        val project = e.project ?: return
        val file = e.getData(CommonDataKeys.VIRTUAL_FILE) ?: return

        if (!file.name.endsWith(".java")) {
            Messages.showErrorDialog(
                project,
                "Only Java files can be migrated",
                "QAMigrate"
            )
            return
        }

        ProgressManager.getInstance().run(object : Task.Backgroundable(
            project, "QAMigrate: Migrating ${file.name}...", true
        ) {
            override fun run(indicator: ProgressIndicator) {
                indicator.text = "Connecting to QAMigrate server..."
                indicator.fraction = 0.1

                try {
                    val service = QAMigrateService.getInstance(project)
                    
                    indicator.text = "Generating Playwright code..."
                    indicator.fraction = 0.5

                    val result = service.migrateFile(file.path, project.basePath ?: "")

                    indicator.fraction = 1.0

                    if (result.success) {
                        Messages.showInfoMessage(
                            project,
                            "Successfully migrated to: ${result.outputPath}",
                            "QAMigrate"
                        )
                    } else {
                        Messages.showErrorDialog(
                            project,
                            "Migration failed: ${result.error}",
                            "QAMigrate"
                        )
                    }
                } catch (ex: Exception) {
                    Messages.showErrorDialog(
                        project,
                        "Error: ${ex.message}\n\nIs the QAMigrate server running?",
                        "QAMigrate"
                    )
                }
            }
        })
    }

    override fun update(e: AnActionEvent) {
        val file = e.getData(CommonDataKeys.VIRTUAL_FILE)
        e.presentation.isEnabledAndVisible = file != null && file.name.endsWith(".java")
    }
}

class MigrateProjectAction : AnAction() {

    override fun actionPerformed(e: AnActionEvent) {
        val project = e.project ?: return

        val confirm = Messages.showYesNoDialog(
            project,
            "This will migrate all Java files in the project to Playwright.\n\nContinue?",
            "QAMigrate",
            Messages.getQuestionIcon()
        )

        if (confirm != Messages.YES) return

        ProgressManager.getInstance().run(object : Task.Backgroundable(
            project, "QAMigrate: Migrating project...", true
        ) {
            override fun run(indicator: ProgressIndicator) {
                indicator.text = "Starting project migration..."
                
                try {
                    val service = QAMigrateService.getInstance(project)
                    val result = service.migrateProject(project.basePath ?: "")

                    Messages.showInfoMessage(
                        project,
                        "Migration complete:\n- Success: ${result.successCount}\n- Failed: ${result.failedCount}",
                        "QAMigrate"
                    )
                } catch (ex: Exception) {
                    Messages.showErrorDialog(
                        project,
                        "Error: ${ex.message}",
                        "QAMigrate"
                    )
                }
            }
        })
    }
}

class ScanProjectAction : AnAction() {

    override fun actionPerformed(e: AnActionEvent) {
        val project = e.project ?: return

        ProgressManager.getInstance().run(object : Task.Backgroundable(
            project, "QAMigrate: Scanning project...", false
        ) {
            override fun run(indicator: ProgressIndicator) {
                try {
                    val service = QAMigrateService.getInstance(project)
                    val result = service.scanProject(project.basePath ?: "")

                    Messages.showInfoMessage(
                        project,
                        """
                        Scan Results:
                        - Total Files: ${result.totalFiles}
                        - Test Classes: ${result.testClasses}
                        - Page Objects: ${result.pageObjects}
                        - Patterns Found: ${result.patternsFound}
                        """.trimIndent(),
                        "QAMigrate"
                    )
                } catch (ex: Exception) {
                    Messages.showErrorDialog(
                        project,
                        "Scan error: ${ex.message}",
                        "QAMigrate"
                    )
                }
            }
        })
    }
}

class PreviewMigrationAction : AnAction() {

    override fun actionPerformed(e: AnActionEvent) {
        val project = e.project ?: return
        val file = e.getData(CommonDataKeys.VIRTUAL_FILE) ?: return

        Messages.showInfoMessage(
            project,
            "Preview feature coming soon!\n\nThis will show a diff view of the migration.",
            "QAMigrate"
        )
    }

    override fun update(e: AnActionEvent) {
        val file = e.getData(CommonDataKeys.VIRTUAL_FILE)
        e.presentation.isEnabledAndVisible = file != null && file.name.endsWith(".java")
    }
}
