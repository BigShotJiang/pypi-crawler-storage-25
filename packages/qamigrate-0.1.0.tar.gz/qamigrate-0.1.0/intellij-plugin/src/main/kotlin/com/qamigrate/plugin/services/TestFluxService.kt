package com.qamigrate.plugin.services

import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import com.intellij.openapi.components.Service
import com.intellij.openapi.components.service
import com.intellij.openapi.project.Project
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

@Service(Service.Level.PROJECT)
class QAMigrateService(private val project: Project) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(300, TimeUnit.SECONDS) // Long timeout for migrations
        .build()

    private val gson = Gson()
    private val jsonMediaType = "application/json".toMediaType()

    var serverUrl: String = "http://localhost:3000"

    fun migrateFile(filePath: String, projectPath: String): MigrationResult {
        val request = MigrateRequest(filePath, projectPath)
        val requestBody = gson.toJson(request).toRequestBody(jsonMediaType)

        val httpRequest = Request.Builder()
            .url("$serverUrl/api/migrate")
            .post(requestBody)
            .build()

        val response = client.newCall(httpRequest).execute()
        val body = response.body?.string() ?: throw Exception("Empty response")

        return gson.fromJson(body, MigrationResult::class.java)
    }

    fun migrateProject(projectPath: String): ProjectMigrationResult {
        val request = ProjectMigrateRequest(projectPath, allFiles = true)
        val requestBody = gson.toJson(request).toRequestBody(jsonMediaType)

        val httpRequest = Request.Builder()
            .url("$serverUrl/api/migrate/batch")
            .post(requestBody)
            .build()

        val response = client.newCall(httpRequest).execute()
        val body = response.body?.string() ?: throw Exception("Empty response")

        return gson.fromJson(body, ProjectMigrationResult::class.java)
    }

    fun scanProject(projectPath: String): ScanResult {
        val request = ScanRequest(projectPath)
        val requestBody = gson.toJson(request).toRequestBody(jsonMediaType)

        val httpRequest = Request.Builder()
            .url("$serverUrl/api/scan")
            .post(requestBody)
            .build()

        val response = client.newCall(httpRequest).execute()
        val body = response.body?.string() ?: throw Exception("Empty response")

        return gson.fromJson(body, ScanResult::class.java)
    }

    companion object {
        fun getInstance(project: Project): QAMigrateService = project.service()
    }
}

// Request/Response data classes
data class MigrateRequest(
    @SerializedName("file_path") val filePath: String,
    @SerializedName("project_path") val projectPath: String
)

data class ProjectMigrateRequest(
    @SerializedName("project_path") val projectPath: String,
    @SerializedName("all_files") val allFiles: Boolean
)

data class ScanRequest(
    @SerializedName("project_path") val projectPath: String
)

data class MigrationResult(
    val success: Boolean,
    val error: String?,
    @SerializedName("output_path") val outputPath: String?
)

data class ProjectMigrationResult(
    @SerializedName("success_count") val successCount: Int,
    @SerializedName("failed_count") val failedCount: Int
)

data class ScanResult(
    @SerializedName("total_files") val totalFiles: Int,
    @SerializedName("test_classes") val testClasses: Int,
    @SerializedName("page_objects") val pageObjects: Int,
    @SerializedName("patterns_found") val patternsFound: Int
)
