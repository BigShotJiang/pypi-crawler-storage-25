package com.example.base;

import com.microsoft.playwright.*;
import org.junit.jupiter.api.*;
import java.util.Map;

public abstract class BaseTest {

    protected static Playwright playwright;
    protected static Browser browser;
    protected BrowserContext context;
    protected Page page;
    protected String baseUrl;


    // Migration: Migrated ChromeOptions to Playwright launch options
    @BeforeAll
    static void beforeAll() {
        // Migrate ChromeDriver initialization to Playwright browser launch
        playwright = Playwright.create();
        browser = playwright.chromium().launch(new BrowserType.LaunchOptions()
        .setHeadless(true) // Equivalent to --headless
        .setArgs(java.util.List.of("--no-sandbox", "--disable-dev-shm-usage"))
        );
    }

    // Migration: Replaces driver.quit() with playwright.close()
    @AfterAll
    static void afterAll() {
        if (playwright != null) {
            playwright.close();
        }
    }

    // Migration: Migrated WebDriver setup to Playwright page/context creation
    protected void setUp(String browserName, String url) {
        this.baseUrl = url;
        // Create new context and page for each test
        context = browser.newContext(new Browser.NewContextOptions()
        .setViewportSize(1920, 1080) // Equivalent to maximize()
        );
        page = context.newPage();
        // Playwright handles timeouts automatically, no need for implicit waits
    }

    // Migration: Context cleanup replaces WebDriver quit()
    @AfterEach
    public void tearDown() {
        if (context != null) {
            context.close();
        }
    }

    // Migration: Migrated driver.get() to page.navigate()
    protected void navigateTo(String path) {
        page.navigate(baseUrl + path);
    }

    // Migration: Migrated driver.getCurrentUrl() to page.url()
    protected String getCurrentUrl() {
        return page.url();
    }

    // Migration: Migrated driver.getTitle() to page.title()
    protected String getTitle() {
        return page.title();
    }

}