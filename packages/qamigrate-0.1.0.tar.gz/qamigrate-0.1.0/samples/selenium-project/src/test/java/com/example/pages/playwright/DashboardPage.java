package com.example.pages;

import com.microsoft.playwright.FrameLocator;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.AriaRole;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Dashboard page with complex interactions:
 * - Dropdowns (Select)
 * - Hover menus (Actions)
 * - Dynamic lists
 * - iframes
 * - Alerts
 */
public class DashboardPage {

    private final Page page;
    private final Locator userMenu;
    private final Locator notificationBadge;
    private final Locator searchInput;
    private final Locator tableRows;
    private final Locator timezoneDropdown;
    private final Locator sidebarLinks;
    private final Locator chartIframe;
    private final Locator exportButton;
    private final Locator modalOverlay;
    private final Locator confirmButton;

    public DashboardPage(Page page) {
        this.page = page;
        // Initialize locators using Playwright selectors
        this.userMenu = page.locator("#user-menu");
        this.notificationBadge = page.locator(".notification-badge");
        this.searchInput = page.locator("#search-input");
        this.tableRows = page.locator("table.data-table tbody tr");
        this.timezoneDropdown = page.locator("#timezone-select");
        this.sidebarLinks = page.locator(".sidebar-nav a");
        this.chartIframe = page.locator("#chart-iframe");
        this.exportButton = page.locator("xpath=//button[contains(@class, 'btn-export')]");
        this.modalOverlay = page.locator(".modal-overlay");
        this.confirmButton = page.locator("#confirm-btn");
    }

    // Migration: Replaced Selenium Actions with Playwright's built-in hover() method
    public void hoverUserMenu() {
        // Playwright's hover replaces Selenium Actions
        userMenu.hover();
    }

    // Migration: Removed WebDriverWait and ExpectedConditions - Playwright auto-waits for element to be clickable
    public void clickLogout() {
        hoverUserMenu();
        // Use getByRole for link text - auto-waiting replaces WebDriverWait
        page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Logout")).click();
    }

    // Migration: Replaced Selenium Select with Playwright's selectOption() method
    public void selectTimezone(String timezone) {
        // selectOption replaces Selenium Select class
        timezoneDropdown.selectOption(timezone);
    }

    // Migration: Replaced Select.getFirstSelectedOption() with evaluate() to access DOM properties
    public String getSelectedTimezone() {
        // Get selected option using evaluate to access DOM properties
        return timezoneDropdown.evaluate("el => el.options[el.selectedIndex].text").toString();
    }

    // Migration: Replaced clear() and sendKeys() with fill() and press() - fill() automatically clears
    public void searchFor(String query) {
        // fill() automatically clears input and types text
        searchInput.fill(query);
        // Use keyboard press for Enter key
        searchInput.press("Enter");
    }

    // Migration: Replaced driver.findElements() with locator.allTextContents() for better performance
    public List<String> getTableData() {
        // Use allTextContents() for better performance with lists
        return tableRows.allTextContents();
    }

    // Migration: Replaced findElements().size() with locator.count() method
    public int getRowCount() {
        // count() method returns the number of matching elements
        return tableRows.count();
    }

    // Migration: Playwright handles frames differently - use page.frameLocator() for iframe interactions
    public void switchToChartFrame() {
        // Note: Playwright handles iframes differently - return FrameLocator for chaining
        // For this migration, we'll use the iframe element if frame switching is needed elsewhere
        // Typically you would use: page.frameLocator("#chart-iframe") for iframe interactions
    }

    // Migration: Playwright doesn't require explicit frame switching - context is maintained automatically
    public void switchToMainContent() {
        // In Playwright, no explicit frame switching needed - page context is maintained
        // This method kept for compatibility but does nothing in Playwright
    }

    // Migration: Replaced WebDriverWait and alert handling with Playwright's onDialog event handler
    public void clickExportAndAcceptAlert() {
        // Handle dialog before triggering the action that shows it
        page.onDialog(dialog -> dialog.accept());
        exportButton.click();
    }

    // Migration: Replaced WebDriverWait and alert handling with Playwright's onDialog event handler
    public void clickExportAndDismissAlert() {
        // Handle dialog before triggering the action that shows it
        page.onDialog(dialog -> dialog.dismiss());
        exportButton.click();
    }

    // Migration: Removed WebDriverWait and ExpectedConditions - Playwright auto-waits for clickable elements
    public void waitForModalAndConfirm() {
        // Playwright auto-waits - no explicit waits needed
        // Modal visibility is automatically waited for when clicking
        confirmButton.click();
        // Wait for modal to disappear
        modalOverlay.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.HIDDEN));
    }

    // Migration: Replaced getText() with textContent() method
    public int getNotificationCount() {
        String text = notificationBadge.textContent().trim();
        return text.isEmpty() ? 0 : Integer.parseInt(text);
    }

    // Migration: Replaced try-catch with isDisplayed() with Playwright's isVisible() which handles non-existence
    public boolean isNotificationBadgeVisible() {
        // isVisible() handles element existence and visibility checks
        return notificationBadge.isVisible();
    }

    // Migration: Replaced findElements() and stream mapping with allTextContents()
    public List<String> getSidebarLinkTexts() {
        // Use allTextContents() for better performance with multiple elements
        return sidebarLinks.allTextContents();
    }

    // Migration: Replaced manual loop with Playwright's filter() method for cleaner element selection
    public void clickSidebarLink(String linkText) {
        // Use filter to find specific link by text and click
        Locator targetLink = sidebarLinks.filter(new Locator.FilterOptions().setHasText(linkText));
        if (targetLink.count() == 0) {
            throw new RuntimeException("Sidebar link not found: " + linkText);
        }
        targetLink.first().click();
    }

}