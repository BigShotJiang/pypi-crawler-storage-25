package com.example.tests;

import com.example.base.BaseTest;
import com.example.pages.DashboardPage;
import com.example.pages.LoginPage;
import com.microsoft.playwright.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;
import java.util.stream.Stream;

public class DashboardTest extends BaseTest {

    private LoginPage loginPage;
    private DashboardPage dashboardPage;

    // Constructor not needed - using @BeforeEach setup method

    // Migration: Replaced WebDriverWait with page.waitForURL() for cleaner navigation waiting
    @Override
    @BeforeEach
    public void setUp(String browser, String url) {
        super.setUp(browser, url);
        loginPage = new LoginPage(page);
        dashboardPage = new DashboardPage(page);
        // Login first
        loginPage.navigateTo(baseUrl + "/login");
        loginPage.login("admin@example.com", "SecurePass123!");
        // Playwright auto-waits for navigation - removed WebDriverWait
        page.waitForURL("**/dashboard");
    }

    // Migration: Converted TestNG DataProvider to JUnit 5 MethodSource
    static Stream<Arguments> searchQueries() {
        return Stream.of(
        Arguments.of("user report", 5),
        Arguments.of("revenue", 3),
        Arguments.of("empty query that returns nothing", 0)
        );
    }

    // Migration: Removed Thread.sleep as Playwright auto-waits for actionability
    @ParameterizedTest
    @MethodSource("searchQueries")
    public void testSearch(String query, int expectedMinResults) {
        dashboardPage.searchFor(query);
        // Removed Thread.sleep - Playwright auto-waits for DOM changes
        // dashboardPage.getRowCount() will wait for elements to be ready
        int rowCount = dashboardPage.getRowCount();
        assertTrue(rowCount >= expectedMinResults,
        "Expected at least " + expectedMinResults + " results for: " + query);
    }

    // Migration: No changes needed - method calls remain the same
    @Test
    public void testTimezoneSelection() {
        dashboardPage.selectTimezone("US/Pacific");
        assertEquals(dashboardPage.getSelectedTimezone(), "US/Pacific");
    }

    // Migration: No changes needed - assertions work the same way
    @Test
    public void testNotificationBadge() {
        assertTrue(dashboardPage.isNotificationBadgeVisible());
        int count = dashboardPage.getNotificationCount();
        assertTrue(count >= 0, "Notification count should be non-negative");
    }

    // Migration: No changes needed - list operations remain the same
    @Test
    public void testSidebarNavigation() {
        List<String> links = dashboardPage.getSidebarLinkTexts();
        assertTrue(links.size() > 0, "Sidebar should have navigation links");
        assertTrue(links.contains("Dashboard"));
        assertTrue(links.contains("Reports"));
    }

    // Migration: Replaced WebElement + driver.findElement with page.locator and Playwright assertion
    @Test
    public void testExportWithAlert() {
        dashboardPage.clickExportAndAcceptAlert();
        // After accepting, check for success indication
        // Replaced driver.findElement with page.locator for direct assertion
        assertThat(page.locator(".alert-success")).isVisible();
    }

    // Migration: Replaced WebDriverWait and getCurrentUrl() with page.waitForURL() and page.url()
    @Test
    public void testUserMenuLogout() {
        dashboardPage.clickLogout();
        // Replaced WebDriverWait with page.waitForURL()
        page.waitForURL("**/login");
        assertTrue(page.url().contains("/login"));
    }

    // Migration: No changes needed - method logic remains the same
    @Test
    public void testTableDataPresent() {
        List<String> data = dashboardPage.getTableData();
        assertFalse(data.isEmpty(), "Dashboard table should contain data");
    }

    // Migration: Replaced WebDriverWait and getCurrentUrl() with page.waitForURL() and page.url()
    @Test
    public void testSidebarLinkNavigation() {
        dashboardPage.clickSidebarLink("Reports");
        // Replaced WebDriverWait with page.waitForURL()
        page.waitForURL("**/reports");
        assertTrue(page.url().contains("/reports"));
    }

}