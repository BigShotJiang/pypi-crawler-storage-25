package com.example.pages;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import java.nio.file.Paths;

public class RegistrationPage {

    private final Page page;
    private final Locator firstNameInput;
    private final Locator lastNameInput;
    private final Locator emailInput;
    private final Locator passwordInput;
    private final Locator confirmPasswordInput;
    private final Locator countryDropdown;
    private final Locator termsCheckbox;
    private final Locator avatarUpload;
    private final Locator submitButton;
    private final Locator fieldError;
    private final Locator successMessage;
    private final Locator passwordStrengthMeter;

    public RegistrationPage(Page page) {
        this.page = page;
        // Initialize locators - Playwright auto-waits remove need for PageFactory
        this.firstNameInput = page.locator("#first-name");
        this.lastNameInput = page.locator("#last-name");
        this.emailInput = page.locator("#email");
        this.passwordInput = page.locator("#password");
        this.confirmPasswordInput = page.locator("#confirm-password");
        this.countryDropdown = page.locator("#country-select");
        this.termsCheckbox = page.locator("#terms-checkbox");
        this.avatarUpload = page.locator("#avatar-upload");
        this.submitButton = page.locator("button[type='submit']");
        this.fieldError = page.locator(".field-error");
        this.successMessage = page.locator("#success-message");
        this.passwordStrengthMeter = page.locator(".password-strength-meter");
    }

    // Migration: Replaced driver.get() with page.navigate() and removed WebDriverWait - Playwright handles auto-waiting
    public void navigateTo(String url) {
        page.navigate(url);
        // Removed explicit wait - Playwright auto-waits for element visibility
    }

    // Migration: Replaced clear() + sendKeys() with fill() - Playwright automatically clears before filling
    public void fillRegistrationForm(String firstName, String lastName, String email,
    String password, String confirmPassword) {
        // Playwright's fill() automatically clears before filling
        firstNameInput.fill(firstName);
        lastNameInput.fill(lastName);
        emailInput.fill(email);
        passwordInput.fill(password);
        confirmPasswordInput.fill(confirmPassword);
    }

    // Migration: Replaced Selenium Select class with Playwright's selectOption() method
    public void selectCountry(String country) {
        // Playwright's selectOption() handles dropdown selection directly
        countryDropdown.selectOption(new String[]{country});
    }

    // Migration: Replaced isSelected() with isChecked() and used check() method for better checkbox handling
    public void acceptTerms() {
        // Check if checkbox is not already checked before clicking
        if (!termsCheckbox.isChecked()) {
            termsCheckbox.check();
        }
    }

    // Migration: Replaced sendKeys() with setInputFiles() and Path object for file upload
    public void uploadAvatar(String filePath) {
        // Playwright requires Path object for file uploads
        avatarUpload.setInputFiles(Paths.get(filePath));
    }

    // Migration: Replaced JavaScript execution with Playwright's built-in scrollIntoViewIfNeeded() method
    public void scrollToSubmitButton() {
        // Playwright's scrollIntoViewIfNeeded() replaces JavaScript scrollIntoView
        submitButton.scrollIntoViewIfNeeded();
    }

    // Migration: Replaced JavascriptExecutor with Playwright's evaluate() method
    public void setHiddenFieldValue(String fieldId, String value) {
        // Use Playwright's evaluate() for JavaScript execution
        page.evaluate("fieldId => { document.getElementById('" + fieldId + "').value = '" + value + "'; }", fieldId);
    }

    // Migration: Replaced JavascriptExecutor with Playwright's evaluate() method for style computation
    public String getPasswordStrengthColor() {
        // Use Playwright's evaluate() to get computed style
        return (String) page.evaluate("element => window.getComputedStyle(element).backgroundColor", passwordStrengthMeter.elementHandle());
    }

    // Migration: Removed WebDriverWait as Playwright automatically waits for element to be clickable
    public void submitForm() {
        scrollToSubmitButton();
        // Removed explicit wait - Playwright auto-waits for clickable state
        submitButton.click();
    }

    // Migration: No changes needed - isEnabled() works the same in Playwright
    public boolean isSubmitButtonEnabled() {
        return submitButton.isEnabled();
    }

    // Migration: Replaced getText() with textContent() and removed explicit wait
    public String getFieldError() {
        // Removed explicit wait - Playwright auto-waits for element visibility
        return fieldError.textContent();
    }

    // Migration: Replaced getText() with textContent() and removed explicit wait
    public String getSuccessMessage() {
        // Removed explicit wait - Playwright auto-waits for element visibility
        return successMessage.textContent();
    }

    // Migration: Simplified with isVisible() - no need for try-catch as Playwright handles waiting gracefully
    public boolean isSuccessMessageDisplayed() {
        // Use Playwright's isVisible() which handles waiting internally
        return successMessage.isVisible();
    }

    // Migration: Replaced driver.findElement(By.id()) with page.locator() using CSS selector
    public String getFieldAttribute(String fieldId, String attribute) {
        // Use page.locator() instead of driver.findElement()
        Locator field = page.locator("#" + fieldId);
        return field.getAttribute(attribute);
    }

}