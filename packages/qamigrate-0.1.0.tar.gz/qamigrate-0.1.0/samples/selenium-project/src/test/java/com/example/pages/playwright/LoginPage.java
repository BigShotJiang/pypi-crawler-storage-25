package com.example.pages;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

public class LoginPage {

    private final Page page;
    private final Locator usernameInput;
    private final Locator passwordInput;
    private final Locator loginButton;
    private final Locator errorMessage;
    private final Locator forgotPasswordLink;
    private final Locator rememberMeCheckbox;

    public LoginPage(Page page) {
        this.page = page;
        // Initialize locators using Playwright's page.locator() - replaces @FindBy annotations
        this.usernameInput = page.locator("#username");
        this.passwordInput = page.locator("#password");
        this.loginButton = page.locator("button[type='submit']");
        this.errorMessage = page.locator(".error-message");
        this.forgotPasswordLink = page.locator("xpath=//a[text()='Forgot Password?']");
        this.rememberMeCheckbox = page.locator("#remember-me");
    }

    // Migration: Replaced driver.get() with page.navigate() and removed WebDriverWait as Playwright auto-waits
    public void navigateTo(String url) {
        page.navigate(url);
        // Removed explicit wait - Playwright auto-waits for element visibility
    }

    // Migration: Replaced clear() + sendKeys() with fill() which handles clearing automatically
    public void enterUsername(String username) {
        // Playwright's fill() automatically clears the field before typing
        usernameInput.fill(username);
    }

    // Migration: Replaced clear() + sendKeys() with fill() which handles clearing automatically
    public void enterPassword(String password) {
        // Playwright's fill() automatically clears the field before typing
        passwordInput.fill(password);
    }

    // Migration: Removed WebDriverWait as Playwright automatically waits for clickability
    public void clickLogin() {
        // Removed explicit wait - Playwright auto-waits for element to be clickable
        loginButton.click();
    }

    // Migration: No changes needed - method delegates to other methods
    public void login(String username, String password) {
        enterUsername(username);
        enterPassword(password);
        clickLogin();
    }

    // Migration: Replaced getText() with textContent() and removed explicit wait
    public String getErrorMessage() {
        // Removed explicit wait - Playwright auto-waits for element visibility
        return errorMessage.textContent();
    }

    // Migration: Replaced isDisplayed() with isVisible() - Playwright method
    public boolean isErrorDisplayed() {
        try {
            return errorMessage.isVisible();
        } catch (Exception e) {
            return false;
        }
    }

    // Migration: No changes needed - direct click operation
    public void clickForgotPassword() {
        forgotPasswordLink.click();
    }

    // Migration: No changes needed - direct click operation
    public void toggleRememberMe() {
        rememberMeCheckbox.click();
    }

    // Migration: Replaced driver.getTitle() with page.title()
    public String getPageTitle() {
        return page.title();
    }

    // Migration: Replaced driver.getCurrentUrl() with page.url()
    public String getCurrentUrl() {
        return page.url();
    }

    // Migration: No changes needed - isEnabled() method exists in Playwright
    public boolean isLoginButtonEnabled() {
        return loginButton.isEnabled();
    }

}