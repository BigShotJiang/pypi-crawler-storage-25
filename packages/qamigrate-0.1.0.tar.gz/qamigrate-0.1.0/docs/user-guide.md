# QAMigrate Documentation

> AI-Powered Selenium to Playwright Migration Tool

---

## Quick Start

### Installation

```bash
# Clone repository
git clone https://github.com/qamigrate/qamigrate.git
cd qamigrate

# Install with uv
uv sync

# Set API key
export ANTHROPIC_API_KEY=your_key_here
```

### Basic Usage

```bash
# Scan project for Selenium patterns
uv run qamigrate scan --project ./my-selenium-project

# Migrate a single file
uv run qamigrate migrate ./MyTest.java --project ./my-project

# Migrate entire project
uv run qamigrate migrate --all --project ./my-project

# Interactive mode (file selection)
uv run qamigrate migrate --interactive --project ./my-project

# Launch dashboard
uv run qamigrate dashboard
```

---

## Command Reference

### `scan`
Analyze project for Selenium patterns.

```bash
uv run qamigrate scan --project <path> [--output <file>]
```

| Option | Description |
|--------|-------------|
| `--project, -p` | Path to project root |
| `--output, -o` | Output file for results (JSON) |

### `migrate`
Convert Selenium files to Playwright.

```bash
uv run qamigrate migrate [FILE] --project <path> [options]
```

| Option | Description |
|--------|-------------|
| `FILE` | Specific file to migrate |
| `--all, -a` | Migrate all files |
| `--project, -p` | Project root path |
| `--interactive, -i` | Interactive file selection |
| `--dry-run` | Preview without changes |

### `verify`
Run blue-green visual verification.

```bash
uv run qamigrate verify --project <path> [--threshold <0-1>]
```

### `dashboard`
Launch web dashboard.

```bash
uv run qamigrate dashboard [--port <port>]
```

### `export`
Export migration results.

```bash
uv run qamigrate export --project <path> --format <format>
```

| Format | Description |
|--------|-------------|
| `zip` | ZIP archive of migrated files |
| `report` | HTML report with charts |
| `json` | JSON data export |

---

## Supported Patterns

### Locators

| Selenium | Playwright |
|----------|------------|
| `@FindBy(id="x")` | `page.locator("#x")` |
| `@FindBy(css="x")` | `page.locator("x")` |
| `@FindBy(xpath="x")` | `page.locator("xpath=x")` |
| `By.id("x")` | `page.locator("#x")` |
| `By.className("x")` | `page.locator(".x")` |
| `By.name("x")` | `page.locator("[name='x']")` |

### Interactions

| Selenium | Playwright |
|----------|------------|
| `element.sendKeys("text")` | `locator.fill("text")` |
| `element.click()` | `locator.click()` |
| `element.clear()` | *(removed - fill() clears)* |
| `new Select(el).selectByValue()` | `locator.selectOption()` |
| `element.getText()` | `locator.textContent()` |

### Actions

| Selenium | Playwright |
|----------|------------|
| `actions.moveToElement()` | `locator.hover()` |
| `actions.doubleClick()` | `locator.dblclick()` |
| `actions.contextClick()` | `locator.click({button:'right'})` |
| `actions.dragAndDrop()` | `locator.dragTo()` |

### Lifecycle (JUnit 4 → JUnit 5)

| Selenium/JUnit 4 | Playwright/JUnit 5 |
|------------------|-------------------|
| `@Before` | `@BeforeEach` |
| `@After` | `@AfterEach` |
| `@BeforeClass` | `@BeforeAll` |
| `@AfterClass` | `@AfterAll` |

---

## Configuration

### qamigrate.yaml

```yaml
# QAMigrate configuration
scanner:
  include_patterns:
    - "**/*.java"
  exclude_patterns:
    - "**/target/**"
    - "**/build/**"

coder:
  model: "claude-sonnet-4-20250514"
  max_tokens: 8192
  temperature: 0.1

compiler:
  java_home: "/path/to/java"
  
migration:
  output_suffix: "playwright"
  preserve_structure: true
```

### Environment Variables

| Variable | Description |
|----------|-------------|
| `ANTHROPIC_API_KEY` | Required. Claude API key |
| `REDIS_HOST` | Redis host for caching |
| `REDIS_PORT` | Redis port (default: 6379) |
| `JIRA_BASE_URL` | JIRA instance URL |
| `JIRA_API_TOKEN` | JIRA API token |

---

## IDE Integration

### VS Code Extension

1. Open VS Code
2. Install `qamigrate-vscode` extension
3. Right-click Java file → "QAMigrate: Migrate to Playwright"

### IntelliJ IDEA

1. Install `QAMigrate` plugin from Marketplace
2. Right-click Java file → QAMigrate → Migrate to Playwright

---

## API Reference

### REST API

The dashboard exposes a REST API at `http://localhost:3000`:

```http
POST /api/scan
Content-Type: application/json

{"project_path": "/path/to/project"}
```

```http
POST /api/migrate
Content-Type: application/json

{
  "file_path": "/path/to/file.java",
  "project_path": "/path/to/project"
}
```

```http
POST /api/migrate/batch
Content-Type: application/json

{
  "project_path": "/path/to/project",
  "all_files": true
}
```

---

## Deployment

### Docker

```bash
docker build -t qamigrate .
docker run -p 3000:3000 -e ANTHROPIC_API_KEY=xxx qamigrate
```

### Kubernetes (Helm)

```bash
helm install qamigrate ./helm/qamigrate \
  --namespace qamigrate \
  --create-namespace \
  --set secrets.anthropicApiKey.secretName=my-secrets
```

---

## Troubleshooting

### Common Issues

**"Migration failed: compilation error"**
- Ensure JDK 11+ is installed
- Check classpath includes Playwright JAR
- Run with `--verbose` for detailed errors

**"Rate limit exceeded"**
- Add API key with higher limits
- Enable Redis caching to reduce API calls

**"Connection refused"**
- Start QAMigrate server: `uv run qamigrate dashboard`
- Check server URL in IDE settings

---

## License

MIT License - see LICENSE file for details.
