# QAMigrate API Reference

## Python API

### Scanner Agent

```python
from qamigrate.agents.scanner import ScannerAgent
from qamigrate.core.config import ScannerConfig

# Initialize
scanner = ScannerAgent(ScannerConfig())

# Scan project
result = scanner.scan(Path("/path/to/project"))

# Access results
print(f"Total files: {result.total_files}")
print(f"Test classes: {result.test_classes}")
print(f"Page objects: {result.page_objects}")
print(f"Patterns: {len(result.patterns)}")
```

### Coder Agent

```python
from qamigrate.agents.coder import CoderAgent
from qamigrate.core.config import CoderConfig

# Initialize
coder = CoderAgent(CoderConfig())

# Generate Playwright code
code = coder.generate(utom_dict, original_code)

# Save to file
output_path = coder.save_generated_code(code, Path("output/"))
```

### Compiler Agent

```python
from qamigrate.agents.compiler import CompilerAgent

# Initialize
compiler = CompilerAgent()

# Compile single file
result = compiler.compile_single_file(Path("MyTest.java"))

# Compile batch (for dependencies)
result = compiler.compile_batch(
    files=[Path("Base.java"), Path("Derived.java")],
    source_root=Path("src/")
)
```

### Fixer Agent

```python
from qamigrate.agents.fixer import FixerAgent
from qamigrate.core.config import FixerConfig

# Initialize
fixer = FixerAgent(FixerConfig())

# Fix compilation errors
fixed_code = fixer.fix(code, errors)
```

---

## Core Modules

### Dependency Analyzer

```python
from qamigrate.core.dependencies import DependencyAnalyzer

analyzer = DependencyAnalyzer()
analyzer.analyze_project(Path("/path/to/project"))

# Get compilation order (dependencies first)
ordered_files = analyzer.get_compilation_order()

# Get base classes (no dependencies)
base_classes = analyzer.get_base_classes()
```

### Redis Client

```python
from qamigrate.core.redis_client import get_redis

redis = get_redis()

# Rate limiting
allowed, remaining = redis.check_rate_limit(
    key="user_123",
    limit=100,
    window_seconds=60
)

# Caching
redis.cache_set("key", {"data": "value"}, ttl_seconds=3600)
value = redis.cache_get("key")

# Job queue
job_id = redis.enqueue_job("migrations", {"file": "test.java"})
job = redis.dequeue_job("migrations")

# Distributed locking
token = redis.acquire_lock("migration_lock", ttl_seconds=30)
if token:
    # Do work
    redis.release_lock("migration_lock", token)
```

### Parallel Executor

```python
from qamigrate.core.parallel import ParallelExecutor

def progress_callback(progress):
    print(f"Progress: {progress.percentage:.1f}%")

executor = ParallelExecutor(
    max_workers=4,
    on_progress=progress_callback
)

tasks = executor.migrate_batch(
    files=[Path("a.java"), Path("b.java")],
    project_path=Path("/project"),
    migrate_fn=my_migrate_function
)

summary = executor.get_summary()
```

### Report Generator

```python
from qamigrate.core.reports import ReportGenerator, MigrationStats

stats = MigrationStats(
    total_files=10,
    success_count=8,
    failed_count=2,
    files=[{"name": "Test.java", "success": True}]
)

generator = ReportGenerator()
generator.generate_html(stats, Path("report.html"))
generator.generate_json(stats, Path("report.json"))
```

### PDF Reports

```python
from qamigrate.core.pdf_reports import generate_pdf_report

stats = {
    "total_files": 10,
    "success_count": 8,
    "failed_count": 2,
    "files": [...]
}

generate_pdf_report(stats, Path("report.pdf"))
```

---

## Language Support

```python
from qamigrate.core.languages import (
    Language,
    detect_language,
    detect_project_language,
    get_language_config,
    get_language_prompt
)

# Detect file language
lang = detect_language(Path("test.py"))  # Language.PYTHON

# Detect project language
lang = detect_project_language(Path("/project"))

# Get language config
config = get_language_config(Language.PYTHON)
print(config.test_framework)  # "pytest"

# Get migration prompt
prompt = get_language_prompt(Language.JAVASCRIPT)
```

---

## BDD Framework Support

```python
from qamigrate.core.bdd_support import (
    BDDFramework,
    detect_bdd_framework,
    get_bdd_prompt
)

# Detect BDD framework
framework = detect_bdd_framework(Path("/project"))
if framework == BDDFramework.CUCUMBER_JAVA:
    prompt = get_bdd_prompt()
```

---

## JIRA Integration

```python
from qamigrate.integrations.jira_client import get_jira

jira = get_jira()

# Create migration epic
epic_key = jira.create_migration_epic(
    project_name="MyProject",
    file_count=10
)

# Create file task
task_key = jira.create_file_task(
    epic_key=epic_key,
    file_name="LoginTest.java",
    patterns_found=5
)

# Update status
jira.update_task_status(task_key, "Done")

# Add result
jira.add_migration_result(
    task_key,
    success=True,
    output_path="playwright/LoginTest.java"
)
```

---

## Interactive CLI

```python
from qamigrate.cli.interactive import (
    interactive_migrate,
    interactive_scan,
    show_welcome
)

# Show welcome screen
show_welcome()

# Interactive migration
interactive_migrate(Path("/project"), migrate_function)

# Interactive scan
interactive_scan(Path("/project"))
```
