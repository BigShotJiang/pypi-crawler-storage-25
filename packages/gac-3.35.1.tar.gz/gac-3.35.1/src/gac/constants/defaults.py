"""Default values for environment variables and provider configurations."""

import os


class EnvDefaults:
    """Default values for environment variables."""

    MAX_RETRIES: int = 3
    TEMPERATURE: float = 1
    MAX_OUTPUT_TOKENS: int = 4096  # includes reasoning tokens
    WARNING_LIMIT_TOKENS: int = 32768
    ALWAYS_INCLUDE_SCOPE: bool = False
    SKIP_SECRET_SCAN: bool = False
    VERBOSE: bool = False
    NO_VERIFY_SSL: bool = False  # Skip SSL certificate verification (for corporate proxies)
    HOOK_TIMEOUT: int = 120  # Timeout for pre-commit and lefthook hooks in seconds
    USE_50_72_RULE: bool = False  # Enforce 50/72 rule for commit messages
    SIGNOFF: bool = False  # Add Signed-off-by line to commit message
    REASONING_EFFORT: str | None = None  # "none", "low", "medium", "high", or None (use model default)


class ProviderDefaults:
    """Default values for provider configurations."""

    HTTP_TIMEOUT: int = 120  # seconds - timeout for HTTP requests to LLM providers


class Logging:
    """Logging configuration constants."""

    DEFAULT_LEVEL: str = "WARNING"
    LEVELS: list[str] = ["DEBUG", "INFO", "WARNING", "ERROR"]


class Utility:
    """General utility constants."""

    DEFAULT_DIFF_TOKEN_LIMIT: int = 192000  # Max tokens for combined diff
    PER_FILE_DIFF_TOKEN_LIMIT: int = 16000  # Max tokens per individual file diff
    DIFF_CONTEXT_LINES: int = 5  # Lines of context around changed lines in git diffs (git default: 3)
    MAX_WORKERS: int = os.cpu_count() or 4  # Maximum number of parallel workers
    MAX_DISPLAYED_SECRET_LENGTH: int = 50  # Maximum length for displaying secrets
