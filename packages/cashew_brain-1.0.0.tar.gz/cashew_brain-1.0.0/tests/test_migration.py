#!/usr/bin/env python3
"""
Test suite for cashew brain migration
Validates Phase 1 migration from graph.db to brain.db
"""

import sqlite3
import json
import pytest
import tempfile
import os
from pathlib import Path
from datetime import datetime, timezone

VALID_NODE_TYPES = {'observation', 'belief', 'decision', 'insight', 'fact'}
VALID_DOMAINS = {'work', 'personal', 'fitness', 'engineering', 'philosophy', 'music', 'relationships', 'meta'}

@pytest.fixture
def migration_test_setup():
    """Create source and target databases for migration testing"""
    # Create source DB
    source_fd, source_path = tempfile.mkstemp(suffix='_source.db')
    os.close(source_fd)
    
    # Create target DB
    target_fd, target_path = tempfile.mkstemp(suffix='_target.db')
    os.close(target_fd)
    
    # Setup source database with old schema
    source_conn = sqlite3.connect(source_path)
    cursor = source_conn.cursor()
    
    cursor.execute('''
        CREATE TABLE thought_nodes (
            id TEXT PRIMARY KEY,
            content TEXT NOT NULL,
            node_type TEXT NOT NULL,
            timestamp TEXT,
            confidence REAL,
            mood_state TEXT,
            metadata TEXT DEFAULT '{}',
            source_file TEXT,
            decayed INTEGER DEFAULT 0,
            last_updated TEXT
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE derivation_edges (
            parent_id TEXT,
            child_id TEXT,
            relation TEXT,
            weight REAL,
            reasoning TEXT,
            PRIMARY KEY (parent_id, child_id, relation)
        )
    ''')
    
    # Add sample data to source
    now = datetime.now(timezone.utc).isoformat()
    sample_nodes = [
        ("old1", "Sample observation about work", "observation", "work", 0.8),
        ("old2", "Belief about productivity", "belief", "work", 0.7),
        ("old3", "Decision about project direction", "decision", "engineering", 0.9)
    ]
    
    for node_id, content, node_type, domain, confidence in sample_nodes:
        cursor.execute("""
            INSERT INTO thought_nodes 
            (id, content, node_type, timestamp, confidence, metadata, source_file, last_updated)
            VALUES (?, ?, ?, ?, ?, ?, 'original', ?)
        """, (node_id, content, node_type, now, confidence, json.dumps({"domain": domain}), now))
    
    # Add sample edges to source
    cursor.execute("""
        INSERT INTO derivation_edges (parent_id, child_id, relation, weight, reasoning)
        VALUES ('old1', 'old2', 'supports', 0.8, 'Work observations support productivity beliefs')
    """)
    
    source_conn.commit()
    source_conn.close()
    
    # Setup target database with new schema
    target_conn = sqlite3.connect(target_path)
    cursor = target_conn.cursor()
    
    cursor.execute('''
        CREATE TABLE thought_nodes (
            id TEXT PRIMARY KEY,
            content TEXT NOT NULL,
            node_type TEXT NOT NULL,
            domain TEXT,
            timestamp TEXT,
            access_count INTEGER DEFAULT 0,
            last_accessed TEXT,
            confidence REAL,
            source TEXT DEFAULT 'migration',
            session_id TEXT,
            created_at TEXT,
            source_file TEXT,
            decayed INTEGER DEFAULT 0
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE edges (
            source_id TEXT,
            target_id TEXT,
            weight REAL,
            timestamp TEXT,
            PRIMARY KEY (source_id, target_id)
        )
    ''')
    
    # Migrate the data (simulate migration)
    source_conn = sqlite3.connect(source_path)
    for row in source_conn.execute("SELECT * FROM thought_nodes"):
        node_id, content, node_type, timestamp, confidence, mood_state, metadata, source_file, decayed, last_updated = row
        domain_data = json.loads(metadata) if metadata else {}
        domain = domain_data.get('domain', 'general')
        
        cursor.execute("""
            INSERT INTO thought_nodes 
            (id, content, node_type, domain, timestamp, confidence, source, source_file, decayed, created_at)
            VALUES (?, ?, ?, ?, ?, ?, 'migration', ?, ?, ?)
        """, (node_id, content, node_type, domain, timestamp, confidence, source_file, decayed, now))
    
    # Migrate edges (remove relation, simplify)
    for row in source_conn.execute("SELECT parent_id, child_id, weight FROM derivation_edges"):
        parent_id, child_id, weight = row
        cursor.execute("""
            INSERT INTO edges (source_id, target_id, weight, timestamp)
            VALUES (?, ?, ?, ?)
        """, (parent_id, child_id, weight or 0.5, now))
    
    source_conn.close()
    target_conn.commit()
    target_conn.close()
    
    yield source_path, target_path
    
    # Cleanup
    os.unlink(source_path)
    os.unlink(target_path)

def test_databases_exist(migration_test_setup):
    """Verify both source and target databases exist"""
    source_path, target_path = migration_test_setup
    assert os.path.exists(source_path), f"Source database missing: {source_path}"
    assert os.path.exists(target_path), f"Target database missing: {target_path}"

def test_original_db_untouched(migration_test_setup):
    """Verify source database was not modified"""
    source_path, target_path = migration_test_setup
    
    # Check that original tables still exist with original schema
    source_conn = sqlite3.connect(source_path)
    cursor = source_conn.cursor()
    
    # Check thought_nodes table exists with original columns
    cursor.execute("PRAGMA table_info(thought_nodes)")
    columns = [row[1] for row in cursor.fetchall()]
    expected_columns = ['id', 'content', 'node_type', 'timestamp', 'confidence', 
                       'mood_state', 'metadata', 'source_file', 'decayed', 'last_updated']
    
    for col in expected_columns:
        assert col in columns, f"Original column {col} missing from source database"
    
    # Check derivation_edges table exists with relation column
    cursor.execute("PRAGMA table_info(derivation_edges)")
    edge_columns = [row[1] for row in cursor.fetchall()]
    assert 'relation' in edge_columns, "Original relation column missing from source database"
    
    source_conn.close()

def test_new_columns_exist(migration_test_setup):
    """Verify new brain.db schema has correct columns"""
    source_path, target_path = migration_test_setup
    
    target_conn = sqlite3.connect(target_path)
    cursor = target_conn.cursor()
    
    # Check thought_nodes table
    cursor.execute("PRAGMA table_info(thought_nodes)")
    columns = [row[1] for row in cursor.fetchall()]
    expected_new_columns = ['domain', 'created_at', 'last_accessed', 'access_count', 'source', 'session_id']
    
    for col in expected_new_columns:
        assert col in columns, f"New column {col} missing from target database"
    
    # Check edges table (no relation column)
    cursor.execute("PRAGMA table_info(edges)")
    edge_columns = [row[1] for row in cursor.fetchall()]
    expected_edge_columns = ['source_id', 'target_id', 'weight', 'timestamp']
    
    for col in expected_edge_columns:
        assert col in edge_columns, f"Edge column {col} missing from target database"
    
    target_conn.close()

def test_all_nodes_preserved(migration_test_setup):
    """Verify all nodes from migration are in target"""
    source_path, target_path = migration_test_setup
    
    source_conn = sqlite3.connect(source_path)
    target_conn = sqlite3.connect(target_path)
    
    source_count = source_conn.execute('SELECT COUNT(*) FROM thought_nodes').fetchone()[0]
    target_count = target_conn.execute('SELECT COUNT(*) FROM thought_nodes').fetchone()[0]
    
    assert target_count >= source_count, f"Target has fewer nodes ({target_count}) than source ({source_count})"
    
    # Check that all source content exists in target
    source_contents = {row[0] for row in source_conn.execute('SELECT content FROM thought_nodes')}
    target_contents = {row[0] for row in target_conn.execute('SELECT content FROM thought_nodes')}
    
    assert source_contents.issubset(target_contents), "Some source content missing from target"
    
    source_conn.close()
    target_conn.close()

def test_edge_count_preserved(migration_test_setup):
    """Verify brain.db has reasonable edge count"""
    source_path, target_path = migration_test_setup
    
    target_conn = sqlite3.connect(target_path)
    target_count = target_conn.execute('SELECT COUNT(*) FROM edges').fetchone()[0]
    
    assert target_count > 0, "Target database should have at least some edges"
    target_conn.close()

def test_edges_untyped(migration_test_setup):
    """Verify edges have no relation column"""
    source_path, target_path = migration_test_setup
    
    target_conn = sqlite3.connect(target_path)
    cursor = target_conn.cursor()
    
    cursor.execute("PRAGMA table_info(edges)")
    columns = [row[1] for row in cursor.fetchall()]
    
    assert 'relation' not in columns, "Edges should not have relation column"
    assert 'source_id' in columns, "Edges should have source_id column"
    assert 'target_id' in columns, "Edges should have target_id column"
    
    target_conn.close()

def test_no_data_loss(migration_test_setup):
    """Verify content integrity — brain.db content matches source for migrated nodes"""
    source_path, target_path = migration_test_setup
    
    source_conn = sqlite3.connect(source_path)
    target_conn = sqlite3.connect(target_path)
    
    # Check content matches for all nodes
    source_data = {row[0]: row[1] for row in source_conn.execute('SELECT id, content FROM thought_nodes')}
    target_data = {row[0]: row[1] for row in target_conn.execute('SELECT id, content FROM thought_nodes')}
    
    for node_id, content in source_data.items():
        assert node_id in target_data, f"Node {node_id} missing from target"
        assert target_data[node_id] == content, f"Content mismatch for node {node_id}"
    
    source_conn.close()
    target_conn.close()

def test_every_node_has_domain(migration_test_setup):
    """Verify all nodes have a valid domain"""
    source_path, target_path = migration_test_setup
    
    target_conn = sqlite3.connect(target_path)
    
    # Check no NULL domains
    null_domains = target_conn.execute('SELECT COUNT(*) FROM thought_nodes WHERE domain IS NULL').fetchone()[0]
    assert null_domains == 0, f"Found {null_domains} nodes with NULL domain"
    
    # Check domains are reasonable
    domains = {row[0] for row in target_conn.execute('SELECT DISTINCT domain FROM thought_nodes')}
    
    # Should have some known domains and/or 'general' fallback
    assert len(domains) > 0, "No domains found"
    valid_domains = VALID_DOMAINS | {'general'}
    for domain in domains:
        assert domain in valid_domains, f"Invalid domain found: {domain}"
    
    target_conn.close()

def test_every_node_has_valid_type(migration_test_setup):
    """Verify all nodes have valid node_type"""
    source_path, target_path = migration_test_setup
    
    target_conn = sqlite3.connect(target_path)
    
    # Check no NULL node_types
    null_types = target_conn.execute('SELECT COUNT(*) FROM thought_nodes WHERE node_type IS NULL').fetchone()[0]
    assert null_types == 0, f"Found {null_types} nodes with NULL node_type"
    
    # Check all types are valid
    types = {row[0] for row in target_conn.execute('SELECT DISTINCT node_type FROM thought_nodes')}
    
    for node_type in types:
        assert node_type in VALID_NODE_TYPES, f"Invalid node_type found: {node_type}"
    
    target_conn.close()

def test_node_type_distribution_reasonable(migration_test_setup):
    """Verify node types are reasonably distributed (not all one type)"""
    source_path, target_path = migration_test_setup
    
    target_conn = sqlite3.connect(target_path)
    
    # Get distribution
    types = target_conn.execute('SELECT node_type, COUNT(*) FROM thought_nodes GROUP BY node_type').fetchall()
    
    assert len(types) > 1, "All nodes have the same type (should be diverse)"
    
    # Check total nodes
    total_nodes = sum(count for _, count in types)
    assert total_nodes >= 3, "Should have migrated at least 3 test nodes"
    
    target_conn.close()

def test_migration_metadata_correct(migration_test_setup):
    """Verify migration metadata fields"""
    source_path, target_path = migration_test_setup
    
    target_conn = sqlite3.connect(target_path)
    
    # Check all nodes have source='migration'
    non_migration = target_conn.execute("SELECT COUNT(*) FROM thought_nodes WHERE source != 'migration'").fetchone()[0]
    assert non_migration == 0, f"Found {non_migration} nodes not marked as migration"
    
    # Check created_at is populated
    null_created = target_conn.execute('SELECT COUNT(*) FROM thought_nodes WHERE created_at IS NULL').fetchone()[0]
    assert null_created == 0, f"Found {null_created} nodes without created_at timestamp"
    
    target_conn.close()

def test_migration_report_exists():
    """Verify migration report was created (if expected)"""
    # This test just ensures we don't crash - migration reports are optional for testing
    report_path = Path(__file__).parent.parent / "docs" / "migration_report.json"
    
    # If report exists, validate it's valid JSON
    if report_path.exists():
        with open(report_path) as f:
            report = json.load(f)
            assert 'timestamp' in report or 'migration_date' in report
            assert 'node_count' in report or 'nodes_migrated' in report