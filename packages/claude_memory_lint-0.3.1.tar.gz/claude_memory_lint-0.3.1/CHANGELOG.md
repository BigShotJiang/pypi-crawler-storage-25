# CHANGELOG — claude-memory-lint

## v0.3.1 — 2026-05-09 (patch follow-up)

### Added

* `SECURITY.md` — disclosure policy, supported-version table, the
  in-scope / out-of-scope list, and the hardening posture summary
  (atomic write, `.bak` mode 600, `realpath` confinement, OIDC
  publishing, privacy-scan + pre-commit secret scan). Earlier release
  notes referenced an "updated `SECURITY.md`" before the file
  actually existed; this release closes that gap and the relevant
  CHANGELOG line has been corrected.
* PEP 740 attestations on PyPI publishes via
  `pypa/gh-action-pypi-publish@release/v1` `with: attestations: true`.
  Starting from this release, downstream consumers can verify
  artifact origin through Sigstore without trust-on-first-use.
* `pyproject.toml` `[tool.pytest.ini_options].pythonpath = ["src"]`
  so a fresh clone runs `pytest` cleanly without the editable install.
  Without the line, contributors hit 17 `KeyError` failures because
  the system-installed older wheel shadows the source tree; the
  config change makes the source layout authoritative for the test
  run.

### Fixed

* `README.md` pre-commit example: `rev: v0.2.1` → `rev: v0.3.1` so
  pre-commit users actually pin a release that contains R012 / R013 /
  R014.
* `README.md` testing section: replaced "Aim for `45+` passing tests"
  with the current actual suite size (66) and an enumeration of the
  rules covered. The "aim" wording predated multiple rule additions
  and had become misleading.
* `CHANGELOG.md` v0.1.2 entry: replaced placeholder
  `[PR/discussion link]` with the concrete PR reference.

### Notes

No rule logic changed in this release; the rule registry, the
default-on/off matrix, and the CLI surface are byte-identical to
`v0.3.0`. This is a documentation / CI / build-process patch only,
so consumers who already run `v0.3.0` get no behavioural difference
from upgrading — but they do gain Sigstore-attested artifacts and a
working pre-commit pin.

## v0.3.0 — 2026-05-09 (minor)

### Added — three new rules from a second pollution-investigation wave

`R001-R011` defended frontmatter integrity, size, kebab naming, orphan
links, stop-word density, duplicate stems, mtime, secret literals,
dangling markdown links, and stale backups. A follow-up investigation
into how Claude Code memory pollutes attention surfaced three classes
of failure those rules cannot see. v0.3.0 adds the minimum lint surface
that catches each.

* **R012 `--trigger-stopwords`** (WARN, opt-in)
  Catches frontmatter `aliases:` / `triggers:` items that reduce to
  stop-words only ("agent", "task", "github", …). The companion
  `claude-memory-router` runtime treats curated keywords as a high-
  confidence signal. When the curated keyword is itself a generic
  stop-word, every prompt mentioning the term boosts the file — the
  exact 1-hit pollution `R006` removes from `name+description`,
  re-introduced via the curated surface. R012 closes the loop at
  write time. The detector flags an item only when *every* token is
  a stop-word, so mixed phrases ("agent debate") survive unchanged.
  Default off — enable with `--trigger-stopwords` or
  `check_trigger_stopwords: true` once your alias/trigger conventions
  are mature enough to forbid generic terms.

* **R013 `--emphasis-density`** (WARN, opt-in)
  Counts high-salience emphasis emoji (🔥 🚨 ⚠ 🛑 ❌ ✅ 💥 ❗) across
  frontmatter values plus body. When the count exceeds the threshold
  (`emphasis_max`, default 5), R013 emits a single WARN. Fixed-emoji
  scope on purpose: ASCII analogues like `**CRITICAL**` vary by
  language and culture; requiring users to enumerate them in config
  invites drift. The chosen emoji set is the "stop-sign / alert"
  subset that maps to the same salience signal across locales.
  Why bounded by emphasis count: large language models distribute
  attention by *relative* salience. A file in which every section
  claims highest priority loses the ability to differentiate
  genuinely critical content; R013 catches that dilution at write
  time the same way R006 catches the noise on the keyword surface.
  Default off because some users intentionally use one or two
  markers as visual landmarks.

* **R014 `--no-supersedes-check`** (WARN, default ON)
  Validates the frontmatter `supersedes:` target. When a file
  declares it supersedes another, the named target must exist either
  as a sibling or somewhere under `<parent>/archive/**`. `null`,
  `none`, empty string and the absent key are all skipped — only a
  non-null string that fails to resolve trips the warning. This is
  `R010` lifted from body markdown to a structured frontmatter field:
  users who disable body-link scanning still get frontmatter
  integrity for free, which is the contract `claude-memory-router`
  relies on at runtime. Default on. Disable with
  `--no-supersedes-check` or `check_supersedes_dangling: false`.

### Why three rules, not eight

A wider candidate list — archive sub-directory naming conventions,
completion-marker drift, body-text references to archived files,
language-specific "important" word checks, runtime-info-driven
checks, manifest/lint parity rules, settings-file lints — was
rejected during design review. Accept criteria:

1. Generic across users (no `n=1` cultural assumptions such as a
   specific archive bucket layout).
2. Resolvable statically from a single file (or the directory tree)
   without runtime instrumentation.
3. Non-overlapping with R001-R011.
4. False-positive risk low enough to ship default-on (R014) or
   well-bounded enough to ship default-off without forcing config
   churn (R012, R013).

The three rules above are the subset that cleared all four bars. The
remaining candidates either failed the genericity test, duplicated
an existing rule's coverage area, or required runtime data that a
static linter cannot see.

### Rule budget

v0.3.0 ships with R001-R014 active (R007 and R011 are corpus rules;
R012-R014 are per-file). The lint registry now carries 14 rule ids.
Mental model: integrity (R001-R002), structure (R003-R004), graph
(R005, R007, R010, R011, R014), prompt-effect (R006, R012-R013),
lifecycle (R008), security (R009).

### Compatibility

No existing rule changed semantics. Default-config consumers see no
new violations from R012/R013 (opt-in). They may see R014 warnings
only when their existing `supersedes:` values reference a missing
path — that signal is the bug R014 is built to surface. Running
v0.3.0 against a corpus that passed v0.2.1 should produce a strict
superset of the previous report.

### Upgrade

```
pip install --upgrade claude-memory-lint
```

Or from source:

```
git pull origin main
pip install -e .
```

To opt in to R012/R013 in `memory-lint.yaml`:

```yaml
check_trigger_stopwords: true
check_emphasis_density: true
emphasis_max: 5
```

## v0.2.1 — 2026-05-09 (patch)

### Fixed — version single source of truth

`src/cml/__init__.py` carried a hard-coded ``__version__ = "0.1.2"`` that
stayed behind when `pyproject.toml` was bumped to `0.2.0` for the
R009/R010/R011 release. The PyPI package metadata reported `0.2.0`
correctly (it is read from `pyproject.toml`), but every Python consumer
using `from cml import __version__` or `cml --version` saw `0.1.2` —
the kind of drift that exists precisely because the source of truth was
duplicated.

`__init__.py` now reads the version through `importlib.metadata`:

```python
from importlib.metadata import version as _pkg_version
__version__ = _pkg_version("claude-memory-lint")
```

`pyproject.toml` is now the single source. A regression test asserts
the two stay equal, so the next release that bumps one but forgets the
other fails CI instead of shipping broken metadata.

There is no API or behavioural change. Users on `0.2.0` should upgrade
to `0.2.1` only if they care about `__version__` reporting the correct
string; the rule logic is identical.

## v0.2.0 — 2026-05-09 (later)

Three new rules driven by a single live debugging session in which the
companion harness — and several memory files — degraded simultaneously
from a tangle of write-side anti-patterns the existing R001–R008 set
did not cover. Two of the three are opt-in; the third (R009) is on by
default because it backstops an R11-class privacy violation that
slipped past `.gitignore` for several days.

### Added — R009 secret literal detection (default ON, ERROR)

Catches credential-shaped strings (GitHub Classic / OAuth / fine-grained
PAT, AWS access + temporary keys, Anthropic / OpenAI keys, Google API
key, Slack `xox[abprs]-…` tokens, Stripe live / test keys) inside the
file body.

Three properties were non-negotiable in the design:

1. **The match itself is never written to the violation message.**
   Reporters print only file path, line, and the *type* of pattern
   that matched. A lint that leaks the secret it just caught is
   strictly worse than no lint at all — the leak now also lives in CI
   logs, SARIF artifacts, and pre-commit output. A regression test
   asserts the literal does not appear in the message for every
   supported pattern type.
2. **Allowlist for legitimate documentation context.** Lines whose
   surrounding text strongly indicates the literal is a placeholder
   (`<REVOKED-…>`, `<EXAMPLE-…>`, `<REDACTED-…>`, `[REDACTED]`,
   `your_token_here`, `dummy_token`, …) or a regex describing the
   *shape* of a secret (character classes like `[A-Za-z0-9]`,
   quantifiers like `{36}`, the words `regex` / `pattern`) are
   skipped. This keeps security-tooling repos that document token
   shapes from drowning in false positives.
3. **Default ON.** R009 backstops a TIER-1 privacy rule the OSS author
   already had in place. A user who genuinely needs to paste a token
   into a memory file (rare; nearly always a different pathology) can
   disable the rule via `--rule R001 --rule R002 …` selection or by
   marking the file appropriately for the allowlist.

### Added — R010 dangling markdown link (opt-in, WARN)

Reports markdown links of the form `](path.md)` whose target cannot be
resolved against the file's parent directory or against a sibling
`archive/` subtree (the convention used by `claude-memory-router`).

Opt-in via `--dangling-links` or `check_dangling_links: true` because
projects with multi-worktree memory layouts, symlinked corpora, or
non-standard archive paths produce false positives. The flat
`memory/` + `memory/archive/<bucket>/` layout — the one the router was
built around — gets the cleanest signal.

### Added — R011 stale backup file (opt-in, WARN, corpus-level)

Walks the active directory for files matching `*.bak`, `*.backup`,
`*.orig`, trailing `~`, or snapshot patterns like `foo.md.bak.<ts>`,
and warns when their mtime is older than `backup_stale_days` (default
7).

Opt-in because `cml fix` itself writes a sibling `.bak` while adding
frontmatter — turning the rule on by default would have the lint warn
about its own auto-fix output the moment the user ran it. Once an
archive flow exists, switching the rule on (`--stale-backup` or
`check_stale_backup: true`) catches the stragglers that never got
moved.

### Fixed — R003 default error threshold consistency

`cli.py` still carried the v0.1.1 default of `size_error_kb: 50`
despite the v0.1.2 release lowering the rule's effective threshold to
30 KiB elsewhere (rule docstring, README, CHANGELOG, tests). The CLI
default is now `30`, matching the rest of the release. Users who pin a
config file with `size_error_kb` set explicitly are unaffected.

### Tests

- 5 new R009 cases (clean / GitHub PAT / message-never-leaks-match
  defence-in-depth across 7 token types / placeholder allowlist / regex
  pattern allowlist).
- 5 new R010 cases (disabled-by-default / dangling / existing target /
  archive fallback / external URL skip).
- 5 new R011 cases (disabled-by-default / stale `.bak` /  fresh `.bak`
  ok / snapshot-style `.bak.<ts>` / `.orig` + `~` detection).
- Total: +15 tests, no existing test changed.

### Discussion record

The release went through R14 large-scope discussion (analyst + critic
agents debating in parallel before any code was written). Four
candidate rules — archive subdirectory naming consistency, completed
✅ task in active directory, a `MEMORY.md`-style required-reading
length cap, bare-text mentions of moved files — were rejected for
being either user-individual conventions (n=1 generalisation failures)
or for overlapping with R005 / R008. The two retained opt-in rules
(R010, R011) survived the same review because their detection logic
was cleanly orthogonal to existing rules and the false-positive risk
could be confined behind an explicit flag.

## v0.1.2 — 2026-05-09

Companion release to `claude-memory-router` v0.1.2. The router fixed
two pollution sources at *read time*; this release tightens the
*write-time* warning that the router itself relied on staying loose.

### Changed — R003 default error threshold lowered from 50 KiB to 30 KiB

A 50 KiB ceiling was generous to the point of letting one rule file
push past 30 KiB unchallenged. In real workloads, a 30 KiB pinned
file already costs 30 KiB on every single turn — orders of magnitude
more than any other line item in the auto-load budget — and the
warning fires too late to be useful. v0.1.2 lowers the default
**error** to 30 KiB so the lint flags the file before it becomes a
chronic context-pollution source. The 25 KiB warn threshold is
unchanged.

This is technically a breaking change (a file at 35 KiB that was
WARN under v0.1.1 is now ERROR under v0.1.2), but it is the kind of
breaking change you actually want — the file was almost certainly
contributing to the symptoms that bring users to this lint in the
first place. Users who explicitly want the v0.1.1 behaviour can opt
back in:

```yaml
# .pre-commit-config.yaml or equivalent
- id: cml
  args: [--config, cml.toml]
```

```toml
# cml.toml
[rules.R003]
size_error_kb = 50
```

No new rules are added in v0.1.2. The 5 candidate new rules
(safety-word-density / body-line-overrun / draft-in-active-file /
vocabulary-collision / opt-in-error-size) considered for this
release were rejected during a 2-agent design review for being
either user-specific symptom projections (not generalisable to the
OSS user base) or implementations whose false-positive rate would
overwhelm their signal — see PR #4 (and adjacent design discussion)
for the rationale and the rejected candidates list.
The conservative outcome here is intentional: lint rules are easier
to add than to retract, and v0.1.1 was already addressing 90%+ of
the in-scope failure modes.

### Tests

- `test_R003_v012_default_error_30kb` — 28 KiB is now WARN (was WARN), the new ERROR threshold is 30 KiB.
- `test_R003_v012_legacy_50kb_opt_in` — verifies the `size_error_kb: 50` opt-in still works.
- Existing `test_R003_error_threshold` adjusted from 51 KiB to 31 KiB to match the new default.

## v0.1.1 — 2026-05-08

- **R007 false-positive fix**: pure-date stems (`2026-01-01.md`)
  fall back to the original stem when `_normalize_stem` returns
  empty.
- **CLI `run_fix` exit code**: now returns 1 when any rule failed,
  so CI integrations actually fail.
- **CLI `_filter_rules`**: invalid rule names raise `ValueError`
  instead of silently disabling all rules.
- **Atomic .bak**: tmpfile + replace, mode 600. (`SECURITY.md` was
  referenced here at the time of v0.1.1 hardening but the dedicated
  policy document was not landed until `v0.3.1`; see that release for
  the actual disclosure policy.)

## v0.1.0 — 2026-05-08

Initial public release. 8 rules (R001–R008), pre-commit integration,
SARIF reporter, fix subcommand for R002 alias backfill.
