# Design notes

## Why a lint, given that a router already exists

A runtime router can rescue a moderately-bad memory directory by
pruning, re-scoring, and capping injected context. It cannot
manufacture frontmatter that does not exist, nor split a 60-KiB file
into five focused ones. **Routing precision is upper-bounded by data
quality, full stop.**

`claude-memory-lint` exists to push data quality high enough that the
router's best case is the typical case.

## Severity choices

ERROR is reserved for two failures that statically guarantee runtime
degradation:

- **R001 (no frontmatter)** — the router cannot read aliases / triggers
  from a file that has no header. The file is invisible to the
  high-confidence selection rule.
- **R002 (no aliases or triggers)** — same outcome: invisible to
  human-curated keyword routing. The file falls onto inferred-keyword
  matching, which is exactly the noisy path responsible for context
  pollution.

Anything else (oversized, stale, orphan, stop-word-heavy) is a
WARN/INFO: still worth fixing, but you can ship without it.

## Why heuristics, not LLM

The lint runs in pre-commit and CI loops. Both demand:

- **Speed.** A heuristic check on 100 files finishes in < 1 second.
- **Determinism.** Same input → same output, every run.
- **Privacy.** No file body leaves the machine.
- **Zero dependencies.** No PyPI for `openai`, no API keys, no model
  shoulder-checks.

`cml fix --auto` therefore synthesises aliases from the filename stem
plus the first H1 heading. This is intentionally weaker than what a
human would write — the goal is to *bootstrap* a frontmatter block
that humans can then refine, not to replace human judgement.

## Why eight rules, not eighty

Most lints suffer from rule sprawl: the n-th rule's signal-to-noise
ratio is bad enough that users learn to disable it, which corrodes
trust in the whole tool. The eight rules here cover the four failure
modes that produced context pollution in practice (no frontmatter,
empty aliases, oversize, stop-word heavy) and four hygiene rules
(filename, orphan, duplicate, stale). Future rules need to clear a
high bar: either they prevent a documented failure mode, or they stay
out.

## File parser is YAML-lite

Three reasons to avoid PyYAML:

1. **No PyPI dependency.** `pip install claude-memory-lint` should
   not pull in a 500 KB transitive package for a 30-line job.
2. **The frontmatter we care about is tiny.** Scalars, inline lists,
   multi-line lists with `-` bullets. Nothing else.
3. **YAML's default loader has historical safety footguns.** Avoiding
   it eliminates an entire class of issues.

## Rule plug-in surface

Each rule is a free function:

```python
def check(parsed: ParsedFile, config: dict) -> list[Violation]: ...
```

with the convention that an empty list means "this rule had no
findings on this file". Corpus rules (R007 today) take
`list[ParsedFile]` instead. New rules drop into
`src/cml/rules/RNNN_*.py` and register themselves via the
`PER_FILE_RULES` / `CORPUS_RULES` dicts in `rules/__init__.py`.

## What this lint deliberately does not do

- **Does not call an LLM.** Aliases are derived heuristically from
  filename and first H1. If you want LLM-generated aliases, build it
  on top — and accept the privacy and dependency cost yourself.
- **Does not enforce content style.** Use `markdownlint` / `vale` for
  prose-level lint; `cml` operates on metadata and structure only.
- **Does not delete files.** `R005` and `R008` only INFO the candidate;
  removal is the user's choice.
