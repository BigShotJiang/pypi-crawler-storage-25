# Contributing

Welcome! Quick rules:

1. **No personal data in PRs or issues.** Reduce reproducers to
   synthetic fixtures (the existing tests do this).
2. New rules add a row to `docs/DESIGN.md#severity-choices` with
   justification before code review.
3. `pytest` and `ruff check src/` should pass on Python 3.10–3.13.
4. Privacy invariant: no rule may emit file body content; only rule
   ids, paths, line numbers, severities, and concise messages.

## Local development

```bash
git clone https://github.com/hinanohart/claude-memory-lint.git
cd claude-memory-lint
pip install -e .[dev]
pytest -v
ruff check src/
```

## Adding a rule

1. Create `src/cml/rules/r0NN_short_name.py` with a `check(parsed,
   config) -> list[Violation]` function.
2. Register it in `src/cml/rules/__init__.py` under either
   `PER_FILE_RULES` or `CORPUS_RULES`.
3. Add at least one positive and one negative test case in
   `tests/test_rules.py`.
4. Document the rule in `README.md` and `docs/DESIGN.md`.

## Releasing

Tag with `vMAJOR.MINOR.PATCH`. Any rule reclassification (e.g. INFO →
WARN) is a minor bump. New ERROR rules are a major bump because they
break existing CI configurations.
