"""Shared pytest fixtures for claude-memory-lint."""

from __future__ import annotations

from pathlib import Path

import pytest


@pytest.fixture
def memory_dir(tmp_path: Path) -> Path:
    """A clean ad-hoc memory directory the tests can populate."""
    return tmp_path
