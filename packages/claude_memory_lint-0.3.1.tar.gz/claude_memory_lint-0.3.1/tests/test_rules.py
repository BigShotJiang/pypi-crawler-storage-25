"""Per-rule tests using synthetic fixtures."""

from __future__ import annotations

import os
import time
from importlib.metadata import version as _pkg_version
from pathlib import Path

import cml
from cml.parser import parse_file
from cml.rules import CORPUS_RULES, PER_FILE_RULES
from cml.violation import Severity

# ---------------------------------------------------------------------------
# Meta — version single source of truth
# ---------------------------------------------------------------------------

def test_version_matches_package_metadata() -> None:
    """``cml.__version__`` must read through ``importlib.metadata``.

    Regression for the v0.2.0 release where ``__init__.py`` carried a
    stale ``__version__ = "0.1.2"`` literal while ``pyproject.toml`` had
    been bumped to ``0.2.0``. The assertion below catches the next
    occurrence at CI time instead of after upload.
    """
    assert cml.__version__ == _pkg_version("claude-memory-lint")
    assert cml.__version__ != "0+unknown", (
        "package metadata could not be resolved; either the editable install "
        "is broken or `importlib.metadata.version` cannot find the dist-info"
    )


def _w(p: Path, content: str) -> Path:
    p.write_text(content, encoding="utf-8")
    return p


# ---------------------------------------------------------------------------
# R001 — frontmatter present
# ---------------------------------------------------------------------------

def test_R001_missing_frontmatter(memory_dir: Path) -> None:
    p = _w(memory_dir / "no-fm.md", "# heading\nbody\n")
    out = PER_FILE_RULES["R001"](parse_file(p), {})
    assert len(out) == 1 and out[0].severity is Severity.ERROR


def test_R001_present_frontmatter(memory_dir: Path) -> None:
    src = "---\nname: x\ndescription: y\n---\n\nbody\n"
    p = _w(memory_dir / "ok.md", src)
    assert PER_FILE_RULES["R001"](parse_file(p), {}) == []


def test_R001_unterminated(memory_dir: Path) -> None:
    p = _w(memory_dir / "bad.md", "---\nname: oops\nno close\n")
    out = PER_FILE_RULES["R001"](parse_file(p), {})
    assert len(out) == 1 and "no closing" in out[0].message


# ---------------------------------------------------------------------------
# R002 — aliases or triggers required
# ---------------------------------------------------------------------------

def test_R002_empty_aliases_and_triggers(memory_dir: Path) -> None:
    src = "---\nname: x\ndescription: y\naliases: []\ntriggers: []\n---\n"
    p = _w(memory_dir / "x.md", src)
    out = PER_FILE_RULES["R002"](parse_file(p), {})
    assert len(out) == 1 and out[0].severity is Severity.ERROR


def test_R002_aliases_present(memory_dir: Path) -> None:
    src = "---\nname: x\ndescription: y\naliases: [alpha]\n---\n"
    p = _w(memory_dir / "x.md", src)
    assert PER_FILE_RULES["R002"](parse_file(p), {}) == []


def test_R002_triggers_only(memory_dir: Path) -> None:
    src = "---\nname: x\ndescription: y\ntriggers: [beta]\n---\n"
    p = _w(memory_dir / "x.md", src)
    assert PER_FILE_RULES["R002"](parse_file(p), {}) == []


# ---------------------------------------------------------------------------
# R003 — size thresholds
# ---------------------------------------------------------------------------

def test_R003_under_warn(memory_dir: Path) -> None:
    p = _w(memory_dir / "small.md", "x" * 1000)
    assert PER_FILE_RULES["R003"](parse_file(p), {}) == []


def test_R003_warn_threshold(memory_dir: Path) -> None:
    p = _w(memory_dir / "big.md", "x" * (26 * 1024))
    out = PER_FILE_RULES["R003"](parse_file(p), {})
    assert len(out) == 1 and out[0].severity is Severity.WARN


def test_R003_error_threshold(memory_dir: Path) -> None:
    # v0.1.2: error default lowered from 50 KiB to 30 KiB
    p = _w(memory_dir / "huge.md", "x" * (31 * 1024))
    out = PER_FILE_RULES["R003"](parse_file(p), {})
    assert len(out) == 1 and out[0].severity is Severity.ERROR


def test_R003_v012_default_error_30kb(memory_dir: Path) -> None:
    # 28 KiB is between warn (25) and new error (30) — should WARN, not ERROR.
    p = _w(memory_dir / "midsize.md", "x" * (28 * 1024))
    out = PER_FILE_RULES["R003"](parse_file(p), {})
    assert len(out) == 1 and out[0].severity is Severity.WARN


def test_R003_v012_legacy_50kb_opt_in(memory_dir: Path) -> None:
    # Users who want the v0.1.1 ceiling can set size_error_kb: 50 explicitly.
    p = _w(memory_dir / "huge.md", "x" * (40 * 1024))
    out = PER_FILE_RULES["R003"](parse_file(p), {"size_error_kb": 50})
    assert len(out) == 1 and out[0].severity is Severity.WARN  # WARN, not ERROR


# ---------------------------------------------------------------------------
# R004 — filename convention
# ---------------------------------------------------------------------------

def test_R004_kebab_ok(memory_dir: Path) -> None:
    p = _w(memory_dir / "kebab-name.md", "body")
    assert PER_FILE_RULES["R004"](parse_file(p), {}) == []


def test_R004_uppercase_warn(memory_dir: Path) -> None:
    p = _w(memory_dir / "CamelName.md", "body")
    out = PER_FILE_RULES["R004"](parse_file(p), {})
    assert len(out) == 1 and out[0].severity is Severity.WARN


# ---------------------------------------------------------------------------
# R005 — orphan reference
# ---------------------------------------------------------------------------

def test_R005_referenced_ok(memory_dir: Path) -> None:
    target = _w(memory_dir / "node.md", "stub")
    _w(memory_dir / "MEMORY.md", "see [node](node.md) for details")
    assert PER_FILE_RULES["R005"](parse_file(target), {}) == []


def test_R005_orphan_info(memory_dir: Path) -> None:
    target = _w(memory_dir / "lonely.md", "stub")
    _w(memory_dir / "other.md", "no reference here")
    out = PER_FILE_RULES["R005"](parse_file(target), {})
    assert len(out) == 1 and out[0].severity is Severity.INFO


def test_R005_disabled(memory_dir: Path) -> None:
    target = _w(memory_dir / "lonely.md", "stub")
    _w(memory_dir / "other.md", "no reference here")
    assert PER_FILE_RULES["R005"](parse_file(target), {"check_orphan": False}) == []


# ---------------------------------------------------------------------------
# R006 — stop-word density
# ---------------------------------------------------------------------------

def test_R006_high_density(memory_dir: Path) -> None:
    src = (
        "---\nname: api github code\n"
        "description: claude code task tool with config and hooks\n---\n"
    )
    p = _w(memory_dir / "noisy.md", src)
    out = PER_FILE_RULES["R006"](parse_file(p), {})
    assert len(out) == 1 and out[0].severity is Severity.WARN


def test_R006_discriminative(memory_dir: Path) -> None:
    src = (
        "---\nname: widget renderer benchmark\n"
        "description: notes for the widget renderer subsystem benchmark\n---\n"
    )
    p = _w(memory_dir / "ok.md", src)
    assert PER_FILE_RULES["R006"](parse_file(p), {}) == []


# ---------------------------------------------------------------------------
# R007 — duplicate stem
# ---------------------------------------------------------------------------

def test_R007_dup_stems(memory_dir: Path) -> None:
    p1 = _w(memory_dir / "report-2026-01-01.md", "old")
    p2 = _w(memory_dir / "report-2026-02-01.md", "newer")
    parsed = [parse_file(p1), parse_file(p2)]
    out = CORPUS_RULES["R007"](parsed, {})
    assert len(out) == 2  # one INFO per duplicate file


def test_R007_unique(memory_dir: Path) -> None:
    p1 = _w(memory_dir / "alpha.md", "a")
    p2 = _w(memory_dir / "beta.md", "b")
    out = CORPUS_RULES["R007"]([parse_file(p1), parse_file(p2)], {})
    assert out == []


# ---------------------------------------------------------------------------
# R008 — stale age
# ---------------------------------------------------------------------------

def test_R008_fresh(memory_dir: Path) -> None:
    p = _w(memory_dir / "fresh.md", "body")
    assert PER_FILE_RULES["R008"](parse_file(p), {}) == []


def test_R008_stale(memory_dir: Path) -> None:
    p = _w(memory_dir / "stale.md", "body")
    old = time.time() - (200 * 86400)
    os.utime(p, (old, old))
    out = PER_FILE_RULES["R008"](parse_file(p), {})
    assert len(out) == 1 and out[0].severity is Severity.INFO


# ---------------------------------------------------------------------------
# R009 — secret literal detection (default ON, ERROR; never reveals match)
# ---------------------------------------------------------------------------

def test_R009_clean(memory_dir: Path) -> None:
    p = _w(memory_dir / "clean.md", "---\nname: x\n---\nno secrets here\n")
    assert PER_FILE_RULES["R009"](parse_file(p), {}) == []


def test_R009_github_pat(memory_dir: Path) -> None:
    # Built via concat so the test file itself never contains a full PAT-shaped substring.
    fake = "ghp" + "_" + "A" * 36
    p = _w(memory_dir / "leak.md", f"---\nname: x\n---\ntoken={fake}\n")
    out = PER_FILE_RULES["R009"](parse_file(p), {})
    assert len(out) == 1 and out[0].severity is Severity.ERROR
    # CRITICAL: matched literal must NEVER appear in the violation message.
    assert fake not in out[0].message
    assert "GitHub Classic PAT" in out[0].message


def test_R009_allowlist_redacted(memory_dir: Path) -> None:
    # ghp prefix split for the same reason as the fixture above.
    body = "placeholder <REVOKED-2026> " + "ghp" + "_" + "Z" * 36
    p = _w(memory_dir / "doc.md", f"---\nname: x\n---\n{body}\n")
    assert PER_FILE_RULES["R009"](parse_file(p), {}) == []


def test_R009_message_never_contains_match(memory_dir: Path) -> None:
    """Defence-in-depth: every supported pattern must be name-checked, not value-leaked.

    Each fixture literal is built by string concatenation so the file itself
    does not contain a complete credential-shaped substring on disk — pre-commit
    secret scanners (and R009 itself) must not flag the test source.
    """
    cases: list[tuple[str, str]] = [
        ("gho" + "_" + "B" * 36, "GitHub OAuth"),
        ("github" + "_pat_" + "C" * 82, "GitHub fine-grained"),
        ("AKIA" + "D" * 16, "AWS"),
        ("AIza" + "E" * 35, "Google"),
        ("xox" + "b-1234567890-1234567890-abcdefghij", "Slack"),
        ("sk-" + "ant-api01-" + "F" * 50, "Anthropic"),
        ("sk-" + "live-" + "G" * 30, "Stripe"),
    ]
    for literal, _kind in cases:
        p = _w(memory_dir / f"leak-{_kind.lower()}.md",
               f"---\nname: x\n---\nbody {literal} extra\n")
        out = PER_FILE_RULES["R009"](parse_file(p), {})
        assert len(out) >= 1, f"failed to detect {_kind}"
        for v in out:
            assert literal not in v.message, (
                f"R009 leaked the matched literal in its message for {_kind}"
            )


def test_R009_allowlist_regex_pattern(memory_dir: Path) -> None:
    # A line documenting the *shape* of a secret should not fire — a regex
    # describing ``ghp_[A-Za-z0-9]{36}`` is not a leak.
    p = _w(memory_dir / "spec.md",
           "---\nname: x\n---\nregex: `ghp_[A-Za-z0-9]{36}` for GitHub PAT\n")
    assert PER_FILE_RULES["R009"](parse_file(p), {}) == []


# ---------------------------------------------------------------------------
# R010 — dangling markdown link (opt-in WARN)
# ---------------------------------------------------------------------------

def test_R010_disabled_by_default(memory_dir: Path) -> None:
    p = _w(memory_dir / "doc.md",
           "---\nname: x\n---\nsee [missing](nope.md) for details\n")
    assert PER_FILE_RULES["R010"](parse_file(p), {}) == []


def test_R010_dangling_warn(memory_dir: Path) -> None:
    p = _w(memory_dir / "doc.md",
           "---\nname: x\n---\nsee [missing](nope.md) for details\n")
    out = PER_FILE_RULES["R010"](parse_file(p), {"check_dangling_links": True})
    assert len(out) == 1 and out[0].severity is Severity.WARN
    assert "nope.md" in out[0].message


def test_R010_existing_target_ok(memory_dir: Path) -> None:
    _w(memory_dir / "target.md", "stub")
    p = _w(memory_dir / "doc.md",
           "---\nname: x\n---\nsee [target](target.md)\n")
    assert PER_FILE_RULES["R010"](parse_file(p), {"check_dangling_links": True}) == []


def test_R010_archive_fallback(memory_dir: Path) -> None:
    archive_sub = memory_dir / "archive" / "_completed"
    archive_sub.mkdir(parents=True)
    (archive_sub / "moved.md").write_text("archived stub", encoding="utf-8")
    p = _w(memory_dir / "doc.md",
           "---\nname: x\n---\nsee [moved](moved.md)\n")
    # Bare basename resolves via archive/ rglob fallback.
    assert PER_FILE_RULES["R010"](parse_file(p), {"check_dangling_links": True}) == []


def test_R010_skips_external_url(memory_dir: Path) -> None:
    p = _w(memory_dir / "doc.md",
           "---\nname: x\n---\n[gh](https://github.com/x/y.md)\n")
    assert PER_FILE_RULES["R010"](parse_file(p), {"check_dangling_links": True}) == []


# ---------------------------------------------------------------------------
# R011 — stale backup files (corpus-level, opt-in WARN)
# ---------------------------------------------------------------------------

def test_R011_disabled_by_default(memory_dir: Path) -> None:
    md = _w(memory_dir / "x.md", "body")
    bak = memory_dir / "x.md.bak"
    bak.write_text("old", encoding="utf-8")
    old = time.time() - (30 * 86400)
    os.utime(bak, (old, old))
    assert CORPUS_RULES["R011"]([parse_file(md)], {}) == []


def test_R011_stale_backup_warns(memory_dir: Path) -> None:
    md = _w(memory_dir / "x.md", "body")
    bak = memory_dir / "x.md.bak"
    bak.write_text("old", encoding="utf-8")
    old = time.time() - (30 * 86400)
    os.utime(bak, (old, old))
    out = CORPUS_RULES["R011"]([parse_file(md)], {"check_stale_backup": True})
    assert len(out) == 1 and out[0].severity is Severity.WARN


def test_R011_fresh_backup_ok(memory_dir: Path) -> None:
    md = _w(memory_dir / "x.md", "body")
    bak = memory_dir / "x.md.bak"
    bak.write_text("recent", encoding="utf-8")
    # Default-fresh mtime; younger than 7-day threshold.
    out = CORPUS_RULES["R011"]([parse_file(md)], {"check_stale_backup": True})
    assert out == []


def test_R011_detects_snapshot_style(memory_dir: Path) -> None:
    md = _w(memory_dir / "x.md", "body")
    snap = memory_dir / "x.md.bak.20260101-120000"
    snap.write_text("snap", encoding="utf-8")
    old = time.time() - (30 * 86400)
    os.utime(snap, (old, old))
    out = CORPUS_RULES["R011"]([parse_file(md)], {"check_stale_backup": True})
    assert len(out) == 1


def test_R011_detects_orig_and_tilde(memory_dir: Path) -> None:
    md = _w(memory_dir / "x.md", "body")
    for stem in ("y.md.orig", "z.md~"):
        e = memory_dir / stem
        e.write_text("old", encoding="utf-8")
        old = time.time() - (30 * 86400)
        os.utime(e, (old, old))
    out = CORPUS_RULES["R011"]([parse_file(md)], {"check_stale_backup": True})
    assert len(out) == 2


# ---------------------------------------------------------------------------
# R012 — aliases/triggers stop-word check (opt-in WARN)
# ---------------------------------------------------------------------------

def test_R012_disabled_by_default(memory_dir: Path) -> None:
    p = _w(memory_dir / "f.md",
           "---\nname: x\ntriggers: [agent, task, github]\n---\nbody\n")
    assert PER_FILE_RULES["R012"](parse_file(p), {}) == []


def test_R012_pure_stopword_trigger_warn(memory_dir: Path) -> None:
    p = _w(memory_dir / "f.md",
           "---\nname: x\ntriggers: [agent, task]\n---\nbody\n")
    out = PER_FILE_RULES["R012"](parse_file(p), {"check_trigger_stopwords": True})
    assert len(out) == 2
    assert all(v.severity is Severity.WARN for v in out)
    assert any("triggers" in v.message for v in out)


def test_R012_discriminative_alias_ok(memory_dir: Path) -> None:
    p = _w(memory_dir / "f.md",
           "---\nname: x\naliases: [orphan-rescue, semver-policy]\n---\nbody\n")
    assert PER_FILE_RULES["R012"](parse_file(p), {"check_trigger_stopwords": True}) == []


def test_R012_mixed_term_not_flagged(memory_dir: Path) -> None:
    # An item is flagged only when *every* token is a stop-word; "agent debate"
    # contains a discriminative token so it survives.
    p = _w(memory_dir / "f.md",
           "---\nname: x\ntriggers: [\"agent debate\"]\n---\nbody\n")
    assert PER_FILE_RULES["R012"](parse_file(p), {"check_trigger_stopwords": True}) == []


def test_R012_no_frontmatter_skipped(memory_dir: Path) -> None:
    p = _w(memory_dir / "f.md", "no fm here\n")
    assert PER_FILE_RULES["R012"](parse_file(p), {"check_trigger_stopwords": True}) == []


# ---------------------------------------------------------------------------
# R013 — emphasis emoji density (opt-in WARN)
# ---------------------------------------------------------------------------

def test_R013_disabled_by_default(memory_dir: Path) -> None:
    p = _w(memory_dir / "f.md",
           "---\nname: x\n---\n🔥🔥🔥🔥🔥🔥🔥🔥\n")
    assert PER_FILE_RULES["R013"](parse_file(p), {}) == []


def test_R013_over_threshold_warn(memory_dir: Path) -> None:
    p = _w(memory_dir / "f.md",
           "---\nname: x\n---\n🔥 a 🚨 b ⚠ c 🛑 d ❌ e ✅ f 💥\n")
    out = PER_FILE_RULES["R013"](parse_file(p), {"check_emphasis_density": True})
    assert len(out) == 1 and out[0].severity is Severity.WARN
    assert "emphasis" in out[0].message


def test_R013_under_threshold_ok(memory_dir: Path) -> None:
    p = _w(memory_dir / "f.md",
           "---\nname: x\n---\nonly two markers: 🔥 and ⚠.\n")
    assert PER_FILE_RULES["R013"](parse_file(p),
                                   {"check_emphasis_density": True}) == []


def test_R013_threshold_override(memory_dir: Path) -> None:
    p = _w(memory_dir / "f.md",
           "---\nname: x\n---\n🔥 a 🚨 b ⚠ c\n")
    # Three markers with threshold 2 should trip.
    out = PER_FILE_RULES["R013"](
        parse_file(p),
        {"check_emphasis_density": True, "emphasis_max": 2},
    )
    assert len(out) == 1


def test_R013_frontmatter_emphasis_counted(memory_dir: Path) -> None:
    # Markers inside frontmatter values are counted: they leak into router
    # routing context just as body markers do.
    p = _w(memory_dir / "f.md",
           "---\nname: 🔥🔥🔥 important\ndescription: 🔥 🚨 🛑 🚨\n---\nbody\n")
    out = PER_FILE_RULES["R013"](parse_file(p), {"check_emphasis_density": True})
    assert len(out) == 1


def test_R013_ignores_ascii_words(memory_dir: Path) -> None:
    # ASCII tokens like "CRITICAL" are intentionally out of scope.
    p = _w(memory_dir / "f.md",
           "---\nname: x\n---\n" + ("CRITICAL " * 50) + "\n")
    assert PER_FILE_RULES["R013"](parse_file(p),
                                   {"check_emphasis_density": True}) == []


# ---------------------------------------------------------------------------
# R014 — frontmatter supersedes target resolution (default WARN)
# ---------------------------------------------------------------------------

def test_R014_null_supersedes_ok(memory_dir: Path) -> None:
    p = _w(memory_dir / "f.md",
           "---\nname: x\nsupersedes: null\n---\nbody\n")
    assert PER_FILE_RULES["R014"](parse_file(p), {}) == []


def test_R014_missing_supersedes_ok(memory_dir: Path) -> None:
    p = _w(memory_dir / "f.md", "---\nname: x\n---\nbody\n")
    assert PER_FILE_RULES["R014"](parse_file(p), {}) == []


def test_R014_dangling_target_warn(memory_dir: Path) -> None:
    p = _w(memory_dir / "f.md",
           "---\nname: x\nsupersedes: gone.md\n---\nbody\n")
    out = PER_FILE_RULES["R014"](parse_file(p), {})
    assert len(out) == 1 and out[0].severity is Severity.WARN
    assert "gone.md" in out[0].message


def test_R014_existing_sibling_ok(memory_dir: Path) -> None:
    _w(memory_dir / "old.md", "stub")
    p = _w(memory_dir / "f.md",
           "---\nname: x\nsupersedes: old.md\n---\nbody\n")
    assert PER_FILE_RULES["R014"](parse_file(p), {}) == []


def test_R014_archive_fallback_ok(memory_dir: Path) -> None:
    archive_sub = memory_dir / "archive" / "_old"
    archive_sub.mkdir(parents=True)
    (archive_sub / "predecessor.md").write_text("archived stub", encoding="utf-8")
    p = _w(memory_dir / "f.md",
           "---\nname: x\nsupersedes: predecessor.md\n---\nbody\n")
    assert PER_FILE_RULES["R014"](parse_file(p), {}) == []


def test_R014_disabled_via_config(memory_dir: Path) -> None:
    p = _w(memory_dir / "f.md",
           "---\nname: x\nsupersedes: gone.md\n---\nbody\n")
    assert PER_FILE_RULES["R014"](
        parse_file(p), {"check_supersedes_dangling": False}
    ) == []
