"""Parser unit tests."""

from __future__ import annotations

from pathlib import Path

from cml.parser import first_h1, parse_file


def _w(p: Path, content: str) -> Path:
    p.write_text(content, encoding="utf-8")
    return p


def test_no_frontmatter(memory_dir: Path) -> None:
    p = _w(memory_dir / "no-fm.md", "# title\n\nbody only\n")
    parsed = parse_file(p)
    assert not parsed.had_frontmatter
    assert parsed.frontmatter == {}
    assert "body only" in parsed.body


def test_well_formed_frontmatter(memory_dir: Path) -> None:
    src = (
        "---\n"
        "name: example\n"
        "description: a fixture\n"
        "aliases: [alpha, beta]\n"
        "triggers:\n"
        "  - gamma\n"
        "  - delta\n"
        "---\n\n"
        "# heading\nbody\n"
    )
    p = _w(memory_dir / "good.md", src)
    parsed = parse_file(p)
    assert parsed.had_frontmatter
    assert parsed.frontmatter["name"] == "example"
    assert parsed.frontmatter["aliases"] == ["alpha", "beta"]
    assert parsed.frontmatter["triggers"] == ["gamma", "delta"]
    assert parsed.frontmatter_end_line is not None


def test_unterminated_frontmatter(memory_dir: Path) -> None:
    src = "---\nname: oops\nno_closing_marker_here\n"
    p = _w(memory_dir / "bad.md", src)
    parsed = parse_file(p)
    assert parsed.had_frontmatter
    assert parsed.frontmatter_end_line is None


def test_first_h1() -> None:
    assert first_h1("not a heading") == ""
    assert first_h1("# the title\n## sub") == "the title"
    assert first_h1("body\n# later\n") == "later"
