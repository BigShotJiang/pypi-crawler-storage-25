"""End-to-end CLI tests."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from cml.cli import main


def _w(p: Path, content: str) -> Path:
    p.write_text(content, encoding="utf-8")
    return p


def test_check_ok(memory_dir: Path, capsys: pytest.CaptureFixture) -> None:
    src = "---\nname: w\ndescription: widget renderer\naliases: [widget]\n---\n"
    _w(memory_dir / "widget.md", src)
    rc = main(["check", str(memory_dir)])
    out = capsys.readouterr().out
    assert rc == 0
    assert "ERROR=0" in out


def test_check_error_exit(memory_dir: Path, capsys: pytest.CaptureFixture) -> None:
    _w(memory_dir / "no-fm.md", "# heading\nbody\n")
    rc = main(["check", str(memory_dir)])
    out = capsys.readouterr().out
    assert rc == 1
    assert "R001" in out


def test_check_json(memory_dir: Path, capsys: pytest.CaptureFixture) -> None:
    _w(memory_dir / "no-fm.md", "body")
    rc = main(["check", "--format", "json", str(memory_dir)])
    out = capsys.readouterr().out
    payload = json.loads(out)
    assert "violations" in payload
    assert any(v["rule_id"] == "R001" for v in payload["violations"])
    assert rc == 1


def test_check_sarif(memory_dir: Path, capsys: pytest.CaptureFixture) -> None:
    _w(memory_dir / "no-fm.md", "body")
    main(["check", "--format", "sarif", str(memory_dir)])
    out = capsys.readouterr().out
    payload = json.loads(out)
    assert payload["version"] == "2.1.0"
    assert payload["runs"][0]["results"]


def test_fix_adds_frontmatter(memory_dir: Path, capsys: pytest.CaptureFixture) -> None:
    p = _w(memory_dir / "widget-renderer.md", "# Widget renderer\n\nbody\n")
    rc = main(["fix", str(memory_dir)])
    capsys.readouterr()
    assert rc == 0
    new = p.read_text(encoding="utf-8")
    assert new.startswith("---\n")
    assert "aliases:" in new
    # idempotent check on rerun
    rc2 = main(["fix", str(memory_dir)])
    assert rc2 == 0


def test_stats(memory_dir: Path, capsys: pytest.CaptureFixture) -> None:
    _w(memory_dir / "no-fm.md", "body")
    rc = main(["stats", str(memory_dir)])
    out = capsys.readouterr().out
    assert rc == 0
    assert "files scanned" in out


def test_rule_filter(memory_dir: Path, capsys: pytest.CaptureFixture) -> None:
    # missing-frontmatter file would normally trigger R001 + R005
    _w(memory_dir / "lonely.md", "body")
    main(["check", "--rule", "R001", str(memory_dir)])
    out = capsys.readouterr().out
    assert "R001" in out
    assert "R005" not in out
