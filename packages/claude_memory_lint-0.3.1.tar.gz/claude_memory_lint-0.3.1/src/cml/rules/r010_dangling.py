"""R010 — markdown link targets must resolve to an existing file.

WARN (opt-in via ``check_dangling_links: true``): the file body
contains a markdown link of the form ``[text](path.md)`` whose target
cannot be found in the file's directory or under a sibling
``archive/`` subtree.

Why opt-in: memory directories that span multiple worktrees, that
reference files via symlink, or that use a non-standard archive layout
will produce false positives. Users who keep a flat ``memory/`` +
``memory/archive/<bucket>/`` layout (the convention used by the
companion ``claude-memory-router`` runtime) get the most value.

Detection:
1. Extract every ``](...md)`` target inside the body.
2. Skip absolute URLs and root-anchored paths.
3. Resolve relative to the file's parent directory.
4. If still missing, search ``<parent>/archive/**`` for the same
   basename — this catches references that were valid before the
   target was archived.
5. Otherwise, emit a single WARN per (line, target) pair.
"""

from __future__ import annotations

import re
from pathlib import Path

from cml.parser import ParsedFile
from cml.violation import Severity, Violation

RULE_ID = "R010"

_LINK_RE = re.compile(r"\]\(([^)\s]+\.md)(?:#[^)]*)?\)")


def check(parsed: ParsedFile, config: dict) -> list[Violation]:
    if not config.get("check_dangling_links", False):
        return []
    body = parsed.body
    if not body:
        return []
    parent = parsed.path.parent
    archive_root = parent / "archive"
    body_line_offset = parsed.frontmatter_end_line or 0
    out: list[Violation] = []
    seen: set[tuple[int, str]] = set()
    for lineno0, line in enumerate(body.splitlines()):
        for m in _LINK_RE.finditer(line):
            target = m.group(1).strip()
            if target.startswith(("http://", "https://", "//", "/")):
                continue
            try:
                resolved = (parent / target).resolve(strict=False)
            except OSError:
                continue
            if resolved.exists():
                continue
            # Fallback: same basename anywhere under archive/.
            if archive_root.is_dir():
                basename = Path(target).name
                if next(archive_root.rglob(basename), None) is not None:
                    continue
            key = (lineno0, target)
            if key in seen:
                continue
            seen.add(key)
            out.append(
                Violation(
                    rule_id=RULE_ID,
                    severity=Severity.WARN,
                    path=parsed.path,
                    message=(
                        f"dangling markdown link to '{target}' — "
                        "target not found in directory tree or archive/."
                    ),
                    line=body_line_offset + lineno0 + 1,
                    fixable=False,
                )
            )
    return out
