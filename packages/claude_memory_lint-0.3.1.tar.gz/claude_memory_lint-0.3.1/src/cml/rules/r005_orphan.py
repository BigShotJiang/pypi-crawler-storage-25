"""R005 — file should be referenced from at least one index file.

INFO if no other ``.md`` in the directory mentions this file's name
in a Markdown link or bare filename. Orphan files are likely to grow
stale and bloat the auto-load budget without ever being read.
"""

from __future__ import annotations

import re
from pathlib import Path

from cml.parser import ParsedFile
from cml.violation import Severity, Violation

RULE_ID = "R005"

_INDEX_NAMES = {"MEMORY.md", "INDEX.md", "README.md"}


def check(parsed: ParsedFile, config: dict) -> list[Violation]:
    if parsed.path.name in _INDEX_NAMES:
        return []  # the index files themselves cannot be orphan-referenced
    memory_dir: Path = parsed.path.parent
    needle = parsed.path.name
    pattern = re.compile(re.escape(needle))
    for other in memory_dir.iterdir():
        if other == parsed.path or other.suffix != ".md":
            continue
        try:
            content = other.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if pattern.search(content):
            return []
    if not bool(config.get("check_orphan", True)):
        return []
    return [
        Violation(
            rule_id=RULE_ID,
            severity=Severity.INFO,
            path=parsed.path,
            message="not referenced by any other memory file — consider linking from MEMORY.md or archiving.",
            line=None,
            fixable=False,
        )
    ]
