"""R011 — stale backup files in the active memory directory.

WARN (opt-in via ``check_stale_backup: true``): the active memory
directory contains a file whose name ends in a backup-style suffix
(``.bak``, ``.backup``, ``.orig``, trailing ``~``, or ``.bak.<digits>``
style snapshots) and whose mtime is older than ``backup_stale_days``
(default 7).

Why opt-in: ``cml fix`` itself writes a sibling ``foo.md.bak`` when
adding frontmatter, so reporting backups unconditionally would create
a self-referential warning the moment the user runs auto-fix. Once an
archive flow is in place, switching the rule on catches the stragglers
that never got moved.

This is a corpus-level rule: backup files do not match the CLI's
``*.md`` glob, so the rule walks each parsed file's parent directory
itself. Only the parent directories of parsed files are scanned; no
recursion into ``archive/`` (backups inside an archive are intended
artefacts of a previous fix run).
"""

from __future__ import annotations

import time
from pathlib import Path

from cml.parser import ParsedFile
from cml.violation import Severity, Violation

RULE_ID = "R011"

_BACKUP_SUFFIXES: tuple[str, ...] = (".bak", ".backup", ".orig")


def _looks_like_backup(name: str) -> bool:
    if name.endswith("~"):
        return True
    if any(name.endswith(s) for s in _BACKUP_SUFFIXES):
        return True
    # Snapshot-style: foo.md.bak.20260509-044314 or foo.md.bak.1778163464
    return ".bak." in name


def check(files: list[ParsedFile], config: dict) -> list[Violation]:
    if not config.get("check_stale_backup", False):
        return []
    if not files:
        return []
    stale_days = int(config.get("backup_stale_days", 7))
    parents: set[Path] = {f.path.parent for f in files}
    now = time.time()
    out: list[Violation] = []
    for parent in parents:
        try:
            entries = list(parent.iterdir())
        except OSError:
            continue
        for entry in entries:
            if not entry.is_file():
                continue
            if not _looks_like_backup(entry.name):
                continue
            try:
                mtime = entry.stat().st_mtime
            except OSError:
                continue
            age_days = (now - mtime) / 86400
            if age_days < stale_days:
                continue
            out.append(
                Violation(
                    rule_id=RULE_ID,
                    severity=Severity.WARN,
                    path=entry,
                    message=(
                        f"stale backup file ({age_days:.0f} days old) — "
                        "move to archive/ or delete."
                    ),
                    line=None,
                    fixable=False,
                )
            )
    return out
