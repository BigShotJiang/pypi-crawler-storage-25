"""R001 — frontmatter must be present and well-formed.

ERROR: file has no opening ``---`` or has an opening ``---`` without a
closing one. The router cannot extract aliases/triggers from such files,
so they collapse onto the inferred-keyword fallback (the noisy path).
"""

from __future__ import annotations

from cml.parser import ParsedFile
from cml.violation import Severity, Violation

RULE_ID = "R001"


def check(parsed: ParsedFile, _config: dict) -> list[Violation]:
    if not parsed.had_frontmatter:
        return [
            Violation(
                rule_id=RULE_ID,
                severity=Severity.ERROR,
                path=parsed.path,
                message="frontmatter missing — add a `---`-delimited YAML header with at least `name:` and `description:`.",
                line=1,
                fixable=True,
            )
        ]
    if parsed.frontmatter_end_line is None:
        return [
            Violation(
                rule_id=RULE_ID,
                severity=Severity.ERROR,
                path=parsed.path,
                message="frontmatter has opening `---` but no closing `---` line.",
                line=1,
                fixable=False,
            )
        ]
    return []
