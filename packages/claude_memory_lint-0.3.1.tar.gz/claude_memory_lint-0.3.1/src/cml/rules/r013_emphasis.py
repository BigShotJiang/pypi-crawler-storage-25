"""R013 — emphasis emoji density.

WARN (opt-in via ``check_emphasis_density: true``): the file contains more
than ``emphasis_max`` (default 5) high-salience emphasis emoji such as
🔥 🚨 ⚠️ 🛑 ❌ ✅ 💥 ❗ ️.

Why this matters: large language models distribute attention across the
prompt by relative salience. When a single file marks every section as
"most important", every marker dilutes the others — the prompt loses the
ability to differentiate genuinely critical content from background. This
is the dual of R006: R006 prevents *generic* terms from inflating relevance
score; R013 prevents *uniform-priority* signalling from collapsing it.

Detection scope is intentionally narrow:

* Emoji set is fixed and Unicode-only (no ASCII ``**CRITICAL**`` or natural
  language) — those vary by language and culture, so requiring users to
  enumerate them in config invites drift. The emoji set chosen is the
  "stop sign / alert" subset used near-identically across locales.
* Counts cover frontmatter values (joined) and body. Curated frontmatter
  emphasis often leaks into prompts via the router so it counts equally.
* No fix is offered: the user must decide which emphasis to keep.

Default off because some users intentionally use one or two markers as
visual landmarks; the rule activates when emphasis becomes the norm.
"""

from __future__ import annotations

import re

from cml.parser import ParsedFile
from cml.violation import Severity, Violation

RULE_ID = "R013"

# High-salience markers that LLM attention treats as "stop and weight this".
# Unicode-only on purpose: ASCII analogues (CRITICAL/IMPORTANT) are
# language-dependent and invite false positives in non-English memory.
_EMPHASIS_RE = re.compile(
    "[\U0001F525"  # 🔥
    "\U0001F6A8"  # 🚨
    "⚠"       # ⚠
    "\U0001F6D1"  # 🛑
    "❌"       # ❌
    "✅"       # ✅
    "\U0001F4A5"  # 💥
    "❗"       # ❗
    "]"
)


def check(parsed: ParsedFile, config: dict) -> list[Violation]:
    if not config.get("check_emphasis_density", False):
        return []
    threshold = int(config.get("emphasis_max", 5))
    if threshold < 0:
        return []
    fm_text = ""
    if parsed.had_frontmatter:
        for v in parsed.frontmatter.values():
            if isinstance(v, str):
                fm_text += " " + v
            elif isinstance(v, list):
                fm_text += " " + " ".join(str(x) for x in v)
    haystack = fm_text + "\n" + (parsed.body or "")
    count = len(_EMPHASIS_RE.findall(haystack))
    if count > threshold:
        return [
            Violation(
                rule_id=RULE_ID,
                severity=Severity.WARN,
                path=parsed.path,
                message=(
                    f"emphasis emoji density {count} > threshold {threshold} — "
                    "uniform high-priority signalling collapses LLM attention "
                    "weighting; keep emphasis for genuinely critical sections only."
                ),
                line=None,
                fixable=False,
            )
        ]
    return []
