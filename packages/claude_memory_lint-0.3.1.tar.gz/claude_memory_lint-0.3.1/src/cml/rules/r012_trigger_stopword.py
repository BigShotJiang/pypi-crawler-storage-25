"""R012 — frontmatter ``aliases``/``triggers`` must not consist of stop-words.

WARN (opt-in via ``check_trigger_stopwords: true``): an item inside the
``aliases`` or ``triggers`` frontmatter list reduces to a single stop-word
after tokenisation (e.g. ``triggers: [discussion]``, ``aliases: [agent]``).

Why this matters: the companion runtime ``claude-memory-router`` boosts
files whose curated keywords appear in the prompt. Curated keywords that
are themselves generic stop-words ("agent", "task", "github", …) re-introduce
the 1-hit pollution that R006 prevents on ``name+description``: the router
cannot distinguish a topical hit from a filler match. R012 catches this at
write-time, mirroring R006 but on the curated-keyword surface that the
router actually scores against.

Detection:
1. Skip when ``check_trigger_stopwords`` is false (default).
2. For each ``aliases`` and ``triggers`` list item, tokenise via the same
   splitter as R006, lower-case, and reject the item only if **every**
   non-empty token is in the shared ``_STOP_WORDS`` set.
3. Emit one WARN per offending item; the message names both the field and
   the offending value so ``cml fix`` reviewers can edit in place.

Default off because curated keyword conventions vary; users running the
router get the most value with ``check_trigger_stopwords: true``.
"""

from __future__ import annotations

from cml.parser import ParsedFile
from cml.rules.r006_stopword import _STOP_WORDS, _tokenize
from cml.violation import Severity, Violation

RULE_ID = "R012"


def _all_tokens_are_stopwords(value: str) -> bool:
    tokens = _tokenize(value)
    if not tokens:
        return False
    return all(t in _STOP_WORDS for t in tokens)


def check(parsed: ParsedFile, config: dict) -> list[Violation]:
    if not config.get("check_trigger_stopwords", False):
        return []
    if not parsed.had_frontmatter:
        return []
    out: list[Violation] = []
    for field_name in ("aliases", "triggers"):
        field = parsed.frontmatter.get(field_name)
        if not isinstance(field, list):
            continue
        for item in field:
            if not isinstance(item, str) or not item.strip():
                continue
            if _all_tokens_are_stopwords(item):
                out.append(
                    Violation(
                        rule_id=RULE_ID,
                        severity=Severity.WARN,
                        path=parsed.path,
                        message=(
                            f"frontmatter {field_name!r} item {item!r} reduces "
                            "to stop-words only — replace with a discriminative "
                            "keyword so the router can distinguish topical hits."
                        ),
                        line=None,
                        fixable=False,
                    )
                )
    return out
