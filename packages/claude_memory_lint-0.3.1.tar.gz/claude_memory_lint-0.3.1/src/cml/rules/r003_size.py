"""R003 — file size must stay under ``size_warn_kb`` / ``size_error_kb``.

WARN at ``size_warn_kb`` (default 25 KiB), ERROR at ``size_error_kb``
(default 30 KiB, **lowered from 50 in v0.1.2**). A single oversized
memory file dominates the auto-load budget and degrades attention.
The 30 KiB ceiling roughly corresponds to one full pinned-rule file
or two large project notes; past that, the per-turn injection cost
becomes painful even before the multi-file router lands on top.
Users who need the v0.1.1 behaviour can opt back in via
``size_error_kb: 50`` in their pre-commit config.
"""

from __future__ import annotations

from cml.parser import ParsedFile
from cml.violation import Severity, Violation

RULE_ID = "R003"


def check(parsed: ParsedFile, config: dict) -> list[Violation]:
    warn_kb = int(config.get("size_warn_kb", 25))
    error_kb = int(config.get("size_error_kb", 30))
    size_kb = parsed.size_bytes // 1024
    if size_kb >= error_kb:
        return [
            Violation(
                rule_id=RULE_ID,
                severity=Severity.ERROR,
                path=parsed.path,
                message=f"file is {size_kb} KiB, exceeds error threshold {error_kb} KiB — consider archiving older sections.",
                line=None,
                fixable=False,
            )
        ]
    if size_kb >= warn_kb:
        return [
            Violation(
                rule_id=RULE_ID,
                severity=Severity.WARN,
                path=parsed.path,
                message=f"file is {size_kb} KiB, above warn threshold {warn_kb} KiB.",
                line=None,
                fixable=False,
            )
        ]
    return []
