"""R002 — frontmatter must declare at least one alias or trigger.

ERROR: ``aliases: []`` (or absent) AND ``triggers: []`` (or absent).
Without explicit human-curated keywords the file is invisible to the
high-confidence selection rule; it can only be reached via inferred
matching, which routers correctly downweight.
"""

from __future__ import annotations

from cml.parser import ParsedFile
from cml.violation import Severity, Violation

RULE_ID = "R002"


def _is_nonempty_list(v: object) -> bool:
    return isinstance(v, list) and any(isinstance(x, str) and x.strip() for x in v)


def check(parsed: ParsedFile, _config: dict) -> list[Violation]:
    if not parsed.had_frontmatter:
        return []  # R001 already covers it
    fm = parsed.frontmatter
    if _is_nonempty_list(fm.get("aliases")) or _is_nonempty_list(fm.get("triggers")):
        return []
    return [
        Violation(
            rule_id=RULE_ID,
            severity=Severity.ERROR,
            path=parsed.path,
            message="aliases and triggers are both empty/missing — add at least 3 keywords to `aliases:`.",
            line=parsed.frontmatter_end_line or 1,
            fixable=True,
        )
    ]
