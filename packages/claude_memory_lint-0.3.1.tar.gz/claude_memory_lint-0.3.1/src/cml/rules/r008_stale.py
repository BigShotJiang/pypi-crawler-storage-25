"""R008 — file has not been modified for too long.

INFO when mtime is older than ``stale_days`` (default 180). Old
unreferenced files often describe completed projects whose memory is no
longer load-worthy; archiving them keeps the auto-load budget healthy.
"""

from __future__ import annotations

import time

from cml.parser import ParsedFile
from cml.violation import Severity, Violation

RULE_ID = "R008"


def check(parsed: ParsedFile, config: dict) -> list[Violation]:
    days = int(config.get("stale_days", 180))
    age_seconds = time.time() - parsed.path.stat().st_mtime
    age_days = int(age_seconds // 86400)
    if age_days < days:
        return []
    return [
        Violation(
            rule_id=RULE_ID,
            severity=Severity.INFO,
            path=parsed.path,
            message=f"last modified {age_days} days ago (threshold {days}) — consider archiving.",
            line=None,
            fixable=False,
        )
    ]
