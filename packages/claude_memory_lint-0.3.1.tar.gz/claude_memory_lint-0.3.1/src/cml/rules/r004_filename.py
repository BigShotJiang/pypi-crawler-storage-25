"""R004 — filename should be kebab-case ASCII, optionally followed by a date.

WARN if the filename contains uppercase letters, spaces, or non-ASCII
characters in the stem. Inconsistent naming makes filename-boost
matching less effective in routers and harder to glob in shell.
"""

from __future__ import annotations

import re

from cml.parser import ParsedFile
from cml.violation import Severity, Violation

RULE_ID = "R004"

# allowed: lowercase letters, digits, hyphens, underscores, dots (only as date separator),
# plus an optional trailing -YYYY-MM-DD or -YYYYMMDD.
_VALID = re.compile(r"^[a-z0-9][a-z0-9._-]*$")


def check(parsed: ParsedFile, _config: dict) -> list[Violation]:
    stem = parsed.path.stem
    if _VALID.match(stem):
        return []
    return [
        Violation(
            rule_id=RULE_ID,
            severity=Severity.WARN,
            path=parsed.path,
            message=f"filename stem '{stem}' is not kebab-case ASCII — prefer lowercase letters, digits, hyphens.",
            line=None,
            fixable=False,
        )
    ]
