"""R009 — secret literal must not appear in memory file body.

ERROR (default ON): file body contains a string matching a known
credential pattern (GitHub PAT, AWS access key, Anthropic / OpenAI key,
Google API key, Slack, Stripe). Memory files are routinely loaded into
LLM prompts and committed to git history; a leaked literal there is
one auto-load away from being echoed back into a chat transcript.

**The matched substring is never included in the violation message.**
Leaking the secret into the lint output itself would defeat the
purpose, would persist in CI logs / SARIF artifacts / pre-commit
output, and would re-create the very leak the rule exists to detect.
The report contains the file path, the line number, and the *type* of
pattern that matched, nothing more.

Lines whose surrounding context strongly suggests the literal is a
placeholder, redacted token, or a regex pattern *describing* the shape
of a secret are skipped via :data:`_LINE_ALLOWLIST_TOKENS`. This keeps
documentation and security-tooling repos (which routinely embed token
shapes inside grep / regex examples) from drowning in false positives.
"""

from __future__ import annotations

import re

from cml.parser import ParsedFile
from cml.violation import Severity, Violation

RULE_ID = "R009"

# (pattern, label) tuples. More specific prefixes first; ``\b`` anchors
# avoid matching when a real prefix sits inside a longer alphanumeric
# blob. Length floors are conservative — short matches generate too
# many false positives in source-prefix-rich text.
_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    (re.compile(r"\bghp_[A-Za-z0-9]{36,}"), "GitHub Classic PAT"),
    (re.compile(r"\bgho_[A-Za-z0-9]{36,}"), "GitHub OAuth token"),
    (re.compile(r"\bghu_[A-Za-z0-9]{36,}"), "GitHub user-to-server token"),
    (re.compile(r"\bghs_[A-Za-z0-9]{36,}"), "GitHub server-to-server token"),
    (re.compile(r"\bghr_[A-Za-z0-9]{36,}"), "GitHub refresh token"),
    (re.compile(r"\bgithub_pat_[A-Za-z0-9_]{82,}"), "GitHub fine-grained PAT"),
    (re.compile(r"\bsk-ant-api\d{2}-[A-Za-z0-9_-]{40,}"), "Anthropic API key"),
    (re.compile(r"\bsk-proj-[A-Za-z0-9_-]{40,}"), "OpenAI project key"),
    (re.compile(r"\bsk-live-[A-Za-z0-9]{20,}"), "Stripe live key"),
    (re.compile(r"\bsk-test-[A-Za-z0-9]{20,}"), "Stripe test key"),
    (re.compile(r"\bAIza[0-9A-Za-z_-]{35}\b"), "Google API key"),
    (re.compile(r"\bAKIA[0-9A-Z]{16}\b"), "AWS Access Key"),
    (re.compile(r"\bASIA[0-9A-Z]{16}\b"), "AWS temporary credentials"),
    (re.compile(r"\bxox[abprs]-\d+-\d+-[A-Za-z0-9]+"), "Slack token"),
]

# Heuristic allowlist: when any of these substrings appears on the same
# line as a credential-shaped match, treat it as documentation /
# regex / placeholder rather than a live secret. Stored lower-case so a
# single ``str.lower()`` per line suffices.
_LINE_ALLOWLIST_TOKENS: tuple[str, ...] = (
    "<revoked",
    "<example",
    "<redacted",
    "[redacted]",
    "<placeholder",
    "fake_token",
    "dummy_token",
    "example_token",
    "your_token_here",
    # Regex / character-class fragments — if the line documents the
    # *shape* of a secret it almost always sits next to syntax like
    # ``[A-Za-z0-9]{36}`` or quantifiers / "regex" / "pattern" prose.
    "[a-z",
    "[a-za-z",
    "[0-9",
    "[a-z0-9",
    "{36}",
    "{35}",
    "{16}",
    "{20,",
    "{40,",
    "{82,",
    "regex",
    "pattern",
)


def _is_allowlisted_line(line: str) -> bool:
    low = line.lower()
    return any(t in low for t in _LINE_ALLOWLIST_TOKENS)


def check(parsed: ParsedFile, _config: dict) -> list[Violation]:
    """Scan ``parsed.body`` line-by-line for credential-shaped literals."""
    body = parsed.body
    if not body:
        return []
    body_line_offset = parsed.frontmatter_end_line or 0
    out: list[Violation] = []
    seen: set[tuple[int, str]] = set()
    for lineno0, line in enumerate(body.splitlines()):
        if _is_allowlisted_line(line):
            continue
        for pat, label in _PATTERNS:
            if pat.search(line) is None:
                continue
            key = (lineno0, label)
            if key in seen:
                continue
            seen.add(key)
            out.append(
                Violation(
                    rule_id=RULE_ID,
                    severity=Severity.ERROR,
                    path=parsed.path,
                    # NEVER include the matched substring; see module docstring.
                    message=(
                        f"possible secret literal ({label}) — "
                        "redact the value and rotate the credential."
                    ),
                    line=body_line_offset + lineno0 + 1,
                    fixable=False,
                )
            )
    return out
