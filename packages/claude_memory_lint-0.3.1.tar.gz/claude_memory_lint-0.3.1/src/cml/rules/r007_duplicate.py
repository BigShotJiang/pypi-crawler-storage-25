"""R007 — pair-wise filename / topic similarity.

INFO when two files share an identical or near-identical filename stem
(after stripping date suffixes), suggesting one is a stale copy of the
other. The check is intentionally conservative — semantic deduplication
needs an LLM and is out of scope for this lint.
"""

from __future__ import annotations

import re

from cml.parser import ParsedFile
from cml.violation import Severity, Violation

RULE_ID = "R007"

_DATE_SUFFIX = re.compile(r"[-_]?\d{4}([-_]\d{1,2}){0,2}$")


def _normalize_stem(stem: str) -> str:
    s = stem.lower()
    s_stripped = _DATE_SUFFIX.sub("", s)
    s_stripped = re.sub(r"[-_]+v\d+(\.\d+)*$", "", s_stripped)
    s_stripped = s_stripped.strip("-_")
    # If date stripping leaves nothing (e.g. ``2026-01-01``), fall back to
    # the original lower-cased stem so we do not bucket every pure-date
    # filename into the same empty key (false-positive R007).
    return s_stripped or s


def check(files: list[ParsedFile], _config: dict) -> list[Violation]:
    buckets: dict[str, list[ParsedFile]] = {}
    for pf in files:
        key = _normalize_stem(pf.path.stem)
        buckets.setdefault(key, []).append(pf)

    violations: list[Violation] = []
    for key, members in buckets.items():
        if len(members) < 2:
            continue
        names = ", ".join(sorted(m.path.name for m in members))
        for pf in members:
            violations.append(
                Violation(
                    rule_id=RULE_ID,
                    severity=Severity.INFO,
                    path=pf.path,
                    message=f"shares normalized stem '{key}' with: {names}.",
                    line=None,
                    fixable=False,
                )
            )
    return violations
