"""R006 — stop-word density check.

WARN if more than ``stopword_density_pct`` (default 40) percent of the
*name + description* tokens are generic stop-words (api, github, claude,
agent, …). Such files tend to match many prompts on weak signals,
producing exactly the 1-hit context pollution this lint is built to
prevent.
"""

from __future__ import annotations

import re

from cml.parser import ParsedFile
from cml.violation import Severity, Violation

RULE_ID = "R006"

_TOKEN_SPLIT = re.compile(r"[\s,，、。:;:/／()（）\[\]【】\-_–—『』「」'\"`!\?！？]+")

_STOP_WORDS = frozenset({
    # Japanese particles
    "の", "を", "が", "は", "に", "で", "と", "も", "や", "から", "まで",
    "した", "する", "して", "された", "等", "用", "化", "性", "的",
    # English filler
    "this", "that", "the", "and", "or", "for", "with", "by", "to", "of", "in", "on", "at",
    # Generic dev tokens (the noise generators)
    "claude", "code", "api", "ai", "llm", "ml", "gpu", "cpu",
    "github", "git", "repo", "repository", "branch", "commit",
    "tool", "tools", "task", "tasks", "status", "run", "running",
    "model", "models", "version", "file", "files", "config",
    "system", "hook", "hooks", "build", "install", "setup",
    "fix", "bug", "issue", "test", "tests", "agent", "agents",
})


def _tokenize(text: str) -> list[str]:
    return [t.strip().lower() for t in _TOKEN_SPLIT.split(text) if t.strip()]


def check(parsed: ParsedFile, config: dict) -> list[Violation]:
    threshold = int(config.get("stopword_density_pct", 40))
    if not parsed.had_frontmatter:
        return []
    name = parsed.frontmatter.get("name", "")
    description = parsed.frontmatter.get("description", "")
    if not isinstance(name, str):
        name = ""
    if not isinstance(description, str):
        description = ""
    tokens = _tokenize(f"{name} {description}")
    if len(tokens) < 5:
        return []  # too short to judge
    stop_count = sum(1 for t in tokens if t in _STOP_WORDS)
    pct = (100 * stop_count) // len(tokens)
    if pct >= threshold:
        return [
            Violation(
                rule_id=RULE_ID,
                severity=Severity.WARN,
                path=parsed.path,
                message=f"stop-word density {pct}% in name+description (threshold {threshold}%) — rewrite with more discriminative terms.",
                line=None,
                fixable=False,
            )
        ]
    return []
