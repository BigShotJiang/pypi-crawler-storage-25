"""R014 — frontmatter ``supersedes:`` target must resolve.

WARN (default on, ``check_supersedes_dangling: true``): when a memory file
declares ``supersedes: <path>`` in its frontmatter, the referenced file
must exist either in the same directory tree or somewhere under a sibling
``archive/`` subtree. ``supersedes: null`` and an absent key are both
treated as "no claim" and skipped silently.

This is R010 ("dangling markdown link") applied to a structured frontmatter
field rather than body markdown. Keeping it as a separate rule lets users
opt out of body-link scanning while retaining frontmatter integrity, which
is the contract the runtime relies on.

Detection:
1. Skip if ``check_supersedes_dangling`` is false or no frontmatter is
   present.
2. Treat ``""``, ``"null"``, ``"none"`` (case-insensitive) and the Python
   ``None`` value as no-op.
3. Resolve the target relative to the file's directory; existence ends the
   check.
4. Otherwise, search ``<parent>/archive/**`` for the same basename — this
   models the common workflow where superseded files are moved into an
   archive bucket but the marker stays.
5. If neither finds the target, emit a single WARN.
"""

from __future__ import annotations

from pathlib import Path

from cml.parser import ParsedFile
from cml.violation import Severity, Violation

RULE_ID = "R014"

_SENTINEL_NONE = {"", "null", "none", "n/a", "-"}


def check(parsed: ParsedFile, config: dict) -> list[Violation]:
    if not config.get("check_supersedes_dangling", True):
        return []
    if not parsed.had_frontmatter:
        return []
    raw = parsed.frontmatter.get("supersedes")
    if raw is None:
        return []
    if not isinstance(raw, str):
        return []
    target = raw.strip().strip('"').strip("'")
    if target.lower() in _SENTINEL_NONE:
        return []
    parent = parsed.path.parent
    try:
        resolved = (parent / target).resolve(strict=False)
    except OSError:
        resolved = None
    if resolved is not None and resolved.exists():
        return []
    archive_root = parent / "archive"
    if archive_root.is_dir():
        basename = Path(target).name
        if basename and next(archive_root.rglob(basename), None) is not None:
            return []
    return [
        Violation(
            rule_id=RULE_ID,
            severity=Severity.WARN,
            path=parsed.path,
            message=(
                f"frontmatter supersedes target '{target}' not found in tree "
                "or archive/ — update the path, archive the target, or set "
                "supersedes: null."
            ),
            line=None,
            fixable=False,
        )
    ]
