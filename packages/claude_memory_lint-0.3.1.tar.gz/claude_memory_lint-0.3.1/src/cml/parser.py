"""Frontmatter and body parser for memory files (YAML-lite, no PyYAML)."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

_KEY_RE = re.compile(r"^([a-zA-Z_][a-zA-Z0-9_]*):\s*(.*)$")


@dataclass
class ParsedFile:
    """Output of :func:`parse_file`.

    Attributes:
        path: absolute path to the file.
        frontmatter: ``{}`` if missing or malformed; otherwise key→value or list.
        body: content after the closing ``---\\n`` (or the whole file if no fm).
        size_bytes: on-disk size.
        had_frontmatter: True iff a ``---\\n`` opening line was found.
        frontmatter_end_line: 1-based line number of the closing ``---``,
            or ``None`` if missing.
    """

    path: Path
    frontmatter: dict = field(default_factory=dict)
    body: str = ""
    size_bytes: int = 0
    had_frontmatter: bool = False
    frontmatter_end_line: int | None = None


def _parse_frontmatter_body(body: str) -> dict:
    fm: dict = {}
    cur_key: str | None = None
    for raw in body.splitlines():
        line = raw.rstrip()
        if not line or line.startswith("#"):
            continue
        m = _KEY_RE.match(line)
        if m:
            cur_key = m.group(1)
            val = m.group(2).strip()
            if val == "":
                fm[cur_key] = ""
            elif val.startswith("[") and val.endswith("]"):
                inner = val[1:-1]
                fm[cur_key] = [
                    s.strip().strip('"').strip("'")
                    for s in inner.split(",")
                    if s.strip()
                ]
            elif val == "null":
                fm[cur_key] = None
            else:
                fm[cur_key] = val.strip('"').strip("'")
        elif (line.startswith("  - ") or line.startswith("- ")) and cur_key:
            item = line.split("-", 1)[1].strip().strip('"').strip("'")
            if not isinstance(fm.get(cur_key), list):
                fm[cur_key] = []
            fm[cur_key].append(item)
        elif line.startswith("  ") and cur_key and not isinstance(fm.get(cur_key), list):
            fm[cur_key] = (fm.get(cur_key, "") + " " + line.strip()).strip()
    return fm


def parse_file(path: Path) -> ParsedFile:
    """Parse a memory file's frontmatter (if any) and body.

    Returns a :class:`ParsedFile` even when the file has no frontmatter or
    is malformed — callers can distinguish via the ``had_frontmatter`` flag.
    Reading errors propagate (let the CLI decide the policy).
    """
    raw = path.read_text(encoding="utf-8", errors="replace")
    size = path.stat().st_size

    if not raw.startswith("---\n"):
        return ParsedFile(path=path, body=raw, size_bytes=size, had_frontmatter=False)

    try:
        end = raw.index("\n---\n", 4)
    except ValueError:
        # opening --- but no closing one: malformed
        return ParsedFile(path=path, body=raw, size_bytes=size, had_frontmatter=True,
                           frontmatter_end_line=None)

    body_text = raw[4:end]
    fm = _parse_frontmatter_body(body_text)
    end_line = raw[: end + 1].count("\n") + 1
    return ParsedFile(
        path=path,
        frontmatter=fm,
        body=raw[end + 5 :],
        size_bytes=size,
        had_frontmatter=True,
        frontmatter_end_line=end_line,
    )


def first_h1(text: str) -> str:
    """Return the first ``# H1`` heading text, or empty string."""
    for line in text.splitlines():
        if line.startswith("# "):
            return line[2:].strip()
    return ""
