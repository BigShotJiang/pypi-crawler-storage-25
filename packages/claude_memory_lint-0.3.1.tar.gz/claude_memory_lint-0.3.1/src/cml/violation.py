"""Violation dataclass — every rule yields zero or more of these."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from pathlib import Path


class Severity(str, Enum):
    """Severity of a lint finding."""

    ERROR = "ERROR"
    WARN = "WARN"
    INFO = "INFO"


@dataclass(frozen=True)
class Violation:
    """A single lint finding for a memory file.

    Attributes:
        rule_id: e.g. ``R001`` — stable across versions.
        severity: ERROR fails CI; WARN/INFO do not.
        path: absolute path to the offending file.
        message: short human-readable explanation.
        line: optional line number (1-based) inside the file.
        fixable: whether ``cml fix --auto`` can repair this without LLM help.
    """

    rule_id: str
    severity: Severity
    path: Path
    message: str
    line: int | None = None
    fixable: bool = False

    def short(self) -> str:
        """One-line text representation suitable for stdout."""
        loc = f"{self.path}:{self.line}" if self.line else str(self.path)
        return f"{self.severity.value:5s} {self.rule_id} {loc} :: {self.message}"
