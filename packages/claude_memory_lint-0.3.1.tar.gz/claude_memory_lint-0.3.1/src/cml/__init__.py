"""claude-memory-lint — static lint for Claude Code memory directories."""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as _pkg_version

try:
    __version__ = _pkg_version("claude-memory-lint")
except PackageNotFoundError:
    # Editable install before the package metadata is registered (very rare).
    __version__ = "0+unknown"
