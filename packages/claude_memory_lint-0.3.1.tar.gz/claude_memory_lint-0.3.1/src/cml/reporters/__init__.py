"""Output formatters for lint results."""

from __future__ import annotations

from .json_reporter import format_json
from .sarif import format_sarif
from .text import format_text

REPORTERS = {
    "text": format_text,
    "json": format_json,
    "sarif": format_sarif,
}
