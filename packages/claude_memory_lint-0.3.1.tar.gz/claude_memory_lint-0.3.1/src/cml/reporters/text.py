"""Human-readable text reporter."""

from __future__ import annotations

from collections import Counter

from cml.violation import Severity, Violation


def format_text(violations: list[Violation], *, show_summary: bool = True) -> str:
    """Render *violations* as a multi-line string suitable for stdout.

    Sorted by severity (ERROR > WARN > INFO) then by path then by rule id.
    """
    order = {Severity.ERROR: 0, Severity.WARN: 1, Severity.INFO: 2}
    sorted_v = sorted(violations, key=lambda v: (order[v.severity], str(v.path), v.rule_id))
    lines = [v.short() for v in sorted_v]
    if show_summary:
        counts: Counter[Severity] = Counter(v.severity for v in violations)
        summary = "  ".join(f"{s.value}={counts[s]}" for s in (Severity.ERROR, Severity.WARN, Severity.INFO))
        lines.append("")
        lines.append(f"summary: {summary}  total={len(violations)}")
    return "\n".join(lines)
