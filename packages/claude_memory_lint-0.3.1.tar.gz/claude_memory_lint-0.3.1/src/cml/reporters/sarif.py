"""SARIF 2.1.0 reporter — for GitHub code scanning integration."""

from __future__ import annotations

import json

from cml.violation import Severity, Violation

_SARIF_LEVEL = {
    Severity.ERROR: "error",
    Severity.WARN: "warning",
    Severity.INFO: "note",
}


def format_sarif(violations: list[Violation], *, show_summary: bool = True) -> str:
    rules_seen: dict[str, dict] = {}
    results = []
    for v in violations:
        rules_seen.setdefault(
            v.rule_id,
            {
                "id": v.rule_id,
                "name": v.rule_id,
                "shortDescription": {"text": v.rule_id},
            },
        )
        results.append(
            {
                "ruleId": v.rule_id,
                "level": _SARIF_LEVEL[v.severity],
                "message": {"text": v.message},
                "locations": [
                    {
                        "physicalLocation": {
                            "artifactLocation": {"uri": str(v.path)},
                            **(
                                {"region": {"startLine": v.line}}
                                if v.line is not None
                                else {}
                            ),
                        }
                    }
                ],
            }
        )

    sarif = {
        "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json",
        "version": "2.1.0",
        "runs": [
            {
                "tool": {
                    "driver": {
                        "name": "claude-memory-lint",
                        "informationUri": "https://github.com/hinanohart/claude-memory-lint",
                        "rules": list(rules_seen.values()),
                    }
                },
                "results": results,
            }
        ],
    }
    return json.dumps(sarif, ensure_ascii=False, indent=2)
