"""JSON reporter — suitable for CI consumption."""

from __future__ import annotations

import json

from cml.violation import Violation


def format_json(violations: list[Violation], *, show_summary: bool = True) -> str:
    payload = {
        "violations": [
            {
                "rule_id": v.rule_id,
                "severity": v.severity.value,
                "path": str(v.path),
                "line": v.line,
                "message": v.message,
                "fixable": v.fixable,
            }
            for v in violations
        ],
    }
    return json.dumps(payload, ensure_ascii=False, indent=2)
