# %%
"""Module 2 - Isotope/Adduct Filtering.

Greedy descending-intensity main-peak iteration. For each M, scan candidates
in the mass-tolerance window at each user-selected charge-state shift; drop
candidates that pass all three gates in order:
  1. co-detection coverage  >= isotope_min_coverage_of_main %
  2. full-vector Pearson    >= isotope_corr_threshold
  3. intensity ratio        <= max_isotope_intensity_ratio
"""
from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Sequence

import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import typer
from loguru import logger

from single_cell_metabolomics.config import write_error_sentinel


_CHARGE_DELTAS_DA = {'+1': 1.0033, '+2': 0.5016, '+3': 0.3344}
_FEATURE_NAME_RE = re.compile(r'^(?P<mode>pos|neg)_(?P<mz>\d+(?:\.\d+)?)$')


def _parse_mz(name: str) -> float | None:
    """Feature names are 'pos_<mz>' or 'neg_<mz>' per scm-py concat convention."""
    m = _FEATURE_NAME_RE.match(name)
    return float(m.group('mz')) if m else None


def _pearson_full(M_vec: np.ndarray, B_vec: np.ndarray) -> float:
    """Pearson over the FULL sample vector (zero-padded). Vectorized - no per-sample loop."""
    if M_vec.size < 2:
        return 0.0
    M_centered = M_vec - M_vec.mean()
    B_centered = B_vec - B_vec.mean()
    denom = np.sqrt((M_centered ** 2).sum() * (B_centered ** 2).sum())
    if denom <= 0.0:
        return 0.0
    return float((M_centered * B_centered).sum() / denom)


class IsotopeFilterExecutor:
    def __init__(
        self,
        matrix_data_path: str,
        matrix_row_path: str,
        matrix_column_path: str,
    ) -> None:
        self.df = pq.read_table(matrix_data_path).to_pandas()
        self.df['row'] = self.df['row'].astype(str)
        self.df['col'] = self.df['col'].astype(str)
        self.df['value'] = self.df['value'].astype(np.float32)

        self.row_names = [r for r in Path(matrix_row_path).read_text().splitlines() if r]
        self.col_names = [c for c in Path(matrix_column_path).read_text().splitlines() if c]
        self.feature_number_before = len(self.row_names)
        self.sample_number = len(self.col_names)
        self.feature_number_after: int | None = None

    def _pivot_wide(self) -> tuple[np.ndarray, list[str], list[str]]:
        """Build dense float32 matrix [n_features, n_samples] in row_names order."""
        if not self.row_names or not self.col_names:
            return (np.zeros((0, 0), dtype=np.float32), self.row_names, self.col_names)
        wide = self.df.pivot_table(
            index='row', columns='col', values='value',
            fill_value=0.0, aggfunc='sum',
        ).reindex(index=self.row_names, columns=self.col_names, fill_value=0.0)
        return wide.to_numpy(dtype=np.float32, copy=False), self.row_names, self.col_names

    def filter(
        self,
        mass_tolerance_value: float,
        mass_tolerance_unit: str,
        charge_states: Sequence[str],
        isotope_min_coverage_of_main: float,
        isotope_corr_threshold: float,
        max_isotope_intensity_ratio: float,
    ) -> tuple[int, int]:
        if self.feature_number_before == 0:
            self.feature_number_after = 0
            return 0, 0

        deltas = [_CHARGE_DELTAS_DA[z] for z in charge_states if z in _CHARGE_DELTAS_DA]
        if not deltas:
            logger.warning('Module 2: no valid charge states selected; returning input unchanged')
            self.feature_number_after = self.feature_number_before
            return self.feature_number_before, 0

        matrix, row_names, _ = self._pivot_wide()
        mzs = np.array([_parse_mz(n) if _parse_mz(n) is not None else np.nan for n in row_names], dtype=np.float64)

        # Order main peaks by descending mean intensity (greedy)
        mean_intensity = matrix.mean(axis=1)
        descending = np.argsort(-mean_intensity)

        dropped: set[str] = set()
        for m_idx in descending:
            m_name = row_names[m_idx]
            if m_name in dropped:
                continue
            m_mz = mzs[m_idx]
            if np.isnan(m_mz):
                continue
            M_vec = matrix[m_idx]
            M_detected = M_vec > 0
            n_M_detected = int(M_detected.sum())
            if n_M_detected == 0:
                continue
            mean_M = float(M_vec.mean())
            if mean_M <= 0:
                continue

            for delta in deltas:
                target_mz = m_mz + delta
                if mass_tolerance_unit == 'ppm':
                    tol = target_mz * mass_tolerance_value / 1e6
                else:  # Da
                    tol = mass_tolerance_value
                # Candidate indices in window
                in_window = np.where(np.abs(mzs - target_mz) <= tol)[0]
                for c_idx in in_window:
                    c_name = row_names[c_idx]
                    if c_name == m_name or c_name in dropped:
                        continue
                    B_vec = matrix[c_idx]
                    # Gate 1: co-detection coverage
                    co_detected = M_detected & (B_vec > 0)
                    coverage = co_detected.sum() / n_M_detected * 100.0
                    if coverage < isotope_min_coverage_of_main:
                        continue
                    # Gate 2: full-vector Pearson (zeros-included)
                    pearson = _pearson_full(M_vec, B_vec)
                    if pearson < isotope_corr_threshold:
                        continue
                    # Gate 3: intensity-ratio gate
                    mean_B = float(B_vec.mean())
                    if mean_M == 0 or (mean_B / mean_M) > max_isotope_intensity_ratio:
                        continue
                    dropped.add(c_name)
                    logger.info(
                        f"Module 2 drop: M={m_name} (mz={m_mz:.4f}) -> "
                        f"B={c_name} delta={delta} cov={coverage:.1f}% "
                        f"pearson={pearson:.3f} ratio={(mean_B/mean_M):.3f}"
                    )

        if dropped:
            self.df = self.df[~self.df['row'].isin(dropped)].reset_index(drop=True)
            self.row_names = [r for r in self.row_names if r not in dropped]
        self.feature_number_after = len(self.row_names)
        return self.feature_number_after, len(dropped)

    def save(self, output_parquet_path: str, output_row_path: str, output_column_path: str) -> None:
        Path(output_parquet_path).parent.mkdir(parents=True, exist_ok=True)
        out_table = pa.Table.from_pandas(self.df[['row', 'col', 'value']], preserve_index=False)
        pq.write_table(out_table, output_parquet_path)
        Path(output_row_path).write_text('\n'.join(self.row_names) + ('\n' if self.row_names else ''))
        Path(output_column_path).write_text('\n'.join(self.col_names) + '\n')

    def emit_metadata(
        self,
        serial_number: str,
        dataset_uid: int,
        analysis_id: int,
        storage_path: str,
        row_path: str,
        column_path: str,
        metadata_path: str = 'isotope_filtered_metadata.json',
    ) -> None:
        sentinel = {
            'serial_number': serial_number,
            'dataset_uid': dataset_uid,
            'pipeline_stage': 'preparation',
            'analysis_id': analysis_id,
            'reduction_step': 'isotope_filter',
            'storage_path': os.path.abspath(storage_path),
            'row_path': os.path.abspath(row_path),
            'column_path': os.path.abspath(column_path),
            'feature_number_before': self.feature_number_before,
            'feature_number_after': self.feature_number_after,
            'sample_number': self.sample_number,
            'status': 'completed',
        }
        with open(metadata_path, 'w') as f:
            json.dump(sentinel, f)


# %%
app = typer.Typer(add_completion=False)


@app.command()
def reduce_isotope(
    serial_number: str = '',
    dataset_uid: int = 0,
    analysis_id: int = typer.Option(0, help='Always 0 for preparation'),
    parquet_path: str = '',
    row_path: str = '',
    column_path: str = '',
    mass_tolerance_value: float = 0.005,
    mass_tolerance_unit: str = 'Da',
    charge_states: list[str] = typer.Option(['+1', '+2', '+3'], help='Repeatable; e.g. +1 +2 +3'),
    isotope_corr_threshold: float = 0.85,
    max_isotope_intensity_ratio: float = 0.4,
    isotope_min_coverage_of_main: float = 80.0,
    output_parquet_path: str = 'isotope_filtered.parquet',
    output_row_path: str = 'isotope_filtered_row.tsv',
    output_column_path: str = 'isotope_filtered_col.tsv',
    metadata_path: str = 'isotope_filtered_metadata.json',
):
    try:
        ex = IsotopeFilterExecutor(parquet_path, row_path, column_path)
        ex.filter(
            mass_tolerance_value=mass_tolerance_value,
            mass_tolerance_unit=mass_tolerance_unit,
            charge_states=charge_states,
            isotope_min_coverage_of_main=isotope_min_coverage_of_main,
            isotope_corr_threshold=isotope_corr_threshold,
            max_isotope_intensity_ratio=max_isotope_intensity_ratio,
        )
        ex.save(output_parquet_path, output_row_path, output_column_path)
        ex.emit_metadata(
            serial_number=serial_number, dataset_uid=dataset_uid, analysis_id=analysis_id,
            storage_path=output_parquet_path, row_path=output_row_path,
            column_path=output_column_path, metadata_path=metadata_path,
        )
        logger.success('Module 2 complete.')
    except Exception as e:
        write_error_sentinel(metadata_path, serial_number, dataset_uid, analysis_id, e)
        raise


@app.callback()
def callback():
    pass


if __name__ == '__main__':
    app()
