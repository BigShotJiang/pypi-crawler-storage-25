# %%
"""Module 3 - Sliding Window Correlation.

m/z-ascending sweep with a windowSize-Da sliding window. Within each window
starting at F_i, compute full-vector Pearson against every in-window neighbor
F_j whose co-detection count meets the numerical-stability guard
(windowMinCoDetection = 5, fixed). For each pair whose Pearson exceeds
windowCorrThreshold, the loser of a `windowMetric` competition is flagged
for removal. All flagged features are dropped at the end.

Per Spec Req 5 (`feature-reduction-preparation`):
  - When metric(F_i) < metric(F_j), flag F_i (it lost its window) and break
    the inner loop -- F_i has no business comparing further once flagged.
  - Otherwise (>= covers the tie case) flag F_j and continue scanning F_i's
    window. Tie-break therefore drops the higher-m/z feature deterministically.

This module never builds an N x N similarity matrix; only in-window pairs
are scored.
"""
from __future__ import annotations

import json
import os
import re
from pathlib import Path

import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq
import typer
from loguru import logger

from single_cell_metabolomics.config import write_error_sentinel


# Numerical-stability guard. NOT user-tunable -- Pearson on a <5-sample
# overlap is too noisy to trust. Skipping the pair entirely is safer than
# accepting a coin-flip correlation.
_WINDOW_MIN_CO_DETECTION = 5

# Feature naming convention from scm-py concat: '<mode>_<mz>' where mode is
# 'pos' or 'neg'. Mirrors `_parse_mz` in isotope_filter.py.
_FEATURE_NAME_RE = re.compile(r'^(?P<mode>pos|neg)_(?P<mz>\d+(?:\.\d+)?)$')


def _parse_mz(name: str) -> float | None:
    m = _FEATURE_NAME_RE.match(name)
    return float(m.group('mz')) if m else None


def _pearson_full(M_vec: np.ndarray, B_vec: np.ndarray) -> float:
    """Pearson over the FULL sample vector (zero-padded). Vectorized."""
    if M_vec.size < 2:
        return 0.0
    M_centered = M_vec - M_vec.mean()
    B_centered = B_vec - B_vec.mean()
    denom = np.sqrt((M_centered ** 2).sum() * (B_centered ** 2).sum())
    if denom <= 0.0:
        return 0.0
    return float((M_centered * B_centered).sum() / denom)


def _metric_value(vec: np.ndarray, metric: str) -> float:
    """Compute the chosen competition metric over the FULL vector (zeros included).

    Variance and CV use ddof=0 (population variance) -- the spec does not
    pin sample-vs-population, so we choose population for consistency with
    numpy defaults and to avoid dividing by (N-1) when comparing features.
    """
    if vec.size == 0:
        return 0.0
    if metric == 'sampleCoverage':
        return float((vec > 0).sum())
    if metric == 'mean':
        return float(vec.mean())
    if metric == 'variance':
        return float(vec.var())  # ddof=0 (population variance)
    # default 'cv': stddev / mean over the full vector. NaN-safe: mean==0 -> 0.0.
    mean = float(vec.mean())
    if mean == 0.0:
        return 0.0
    return float(vec.std() / mean)  # ddof=0 stddev


class WindowCorrelationExecutor:
    """Loads a long-COO parquet, applies the m/z-window correlation
    competition, and writes the surviving subset back as long-COO + sidecars."""

    def __init__(
        self,
        matrix_data_path: str,
        matrix_row_path: str,
        matrix_column_path: str,
    ) -> None:
        self.df = pq.read_table(matrix_data_path).to_pandas()
        self.df['row'] = self.df['row'].astype(str)
        self.df['col'] = self.df['col'].astype(str)
        self.df['value'] = self.df['value'].astype(np.float32)

        self.row_names = [r for r in Path(matrix_row_path).read_text().splitlines() if r]
        self.col_names = [c for c in Path(matrix_column_path).read_text().splitlines() if c]
        self.feature_number_before = len(self.row_names)
        self.sample_number = len(self.col_names)
        self.feature_number_after: int | None = None

    def _pivot_wide(self) -> np.ndarray:
        """Build dense float32 matrix [n_features, n_samples] in row_names order."""
        if not self.row_names or not self.col_names:
            return np.zeros((0, 0), dtype=np.float32)
        wide = self.df.pivot_table(
            index='row', columns='col', values='value',
            fill_value=0.0, aggfunc='sum',
        ).reindex(index=self.row_names, columns=self.col_names, fill_value=0.0)
        return wide.to_numpy(dtype=np.float32, copy=False)

    def filter(
        self,
        window_size: float,
        window_corr_threshold: float,
        window_metric: str,
    ) -> tuple[int, int]:
        """Run the sliding-window competition.

        Returns (n_kept, n_dropped).
        """
        if self.feature_number_before == 0:
            self.feature_number_after = 0
            return 0, 0

        if window_metric not in ('cv', 'variance', 'mean', 'sampleCoverage'):
            raise ValueError(
                f"window_metric must be one of cv|variance|mean|sampleCoverage, got {window_metric!r}"
            )

        # Sort features by m/z ascending. Stable sort breaks ties by original
        # row order; features with unparseable names sink to the end via inf.
        mzs_unsorted = np.array(
            [_parse_mz(n) if _parse_mz(n) is not None else np.inf for n in self.row_names],
            dtype=np.float64,
        )
        order = np.argsort(mzs_unsorted, kind='stable')
        sorted_names = [self.row_names[i] for i in order]
        sorted_mzs = mzs_unsorted[order]
        matrix = self._pivot_wide()[order]

        flagged: set[str] = set()
        n = len(sorted_names)
        for i in range(n):
            name_i = sorted_names[i]
            if name_i in flagged:
                continue
            mz_i = sorted_mzs[i]
            if not np.isfinite(mz_i):
                # Unparseable m/z -- skip windowing.
                continue
            vec_i = matrix[i]
            i_detected = vec_i > 0
            metric_i = _metric_value(vec_i, window_metric)

            j = i + 1
            while j < n and sorted_mzs[j] <= mz_i + window_size:
                name_j = sorted_names[j]
                if name_j in flagged:
                    j += 1
                    continue
                vec_j = matrix[j]
                co_detected = int((i_detected & (vec_j > 0)).sum())
                if co_detected < _WINDOW_MIN_CO_DETECTION:
                    # Numerical-stability guard: too few overlapping detections.
                    j += 1
                    continue
                pearson = _pearson_full(vec_i, vec_j)
                if pearson < window_corr_threshold:
                    j += 1
                    continue
                metric_j = _metric_value(vec_j, window_metric)
                if metric_i < metric_j:
                    # F_i loses the competition. Flag and break the inner
                    # loop -- F_i has nothing to say about further neighbors.
                    flagged.add(name_i)
                    logger.info(
                        f"Module 3 drop: {name_i} (mz={mz_i:.4f}) loses to "
                        f"{name_j} on {window_metric} (pearson={pearson:.3f})"
                    )
                    break
                else:
                    # F_j loses (or ties; tie-break drops the higher-m/z
                    # feature deterministically since j > i in m/z order).
                    flagged.add(name_j)
                    logger.info(
                        f"Module 3 drop: {name_j} (mz={sorted_mzs[j]:.4f}) loses to "
                        f"{name_i} on {window_metric} (pearson={pearson:.3f})"
                    )
                    j += 1

        if flagged:
            self.df = self.df[~self.df['row'].isin(flagged)].reset_index(drop=True)
            self.row_names = [r for r in self.row_names if r not in flagged]
        self.feature_number_after = len(self.row_names)
        return self.feature_number_after, len(flagged)

    def save(
        self,
        output_parquet_path: str,
        output_row_path: str,
        output_column_path: str,
    ) -> None:
        Path(output_parquet_path).parent.mkdir(parents=True, exist_ok=True)
        out_table = pa.Table.from_pandas(self.df[['row', 'col', 'value']], preserve_index=False)
        pq.write_table(out_table, output_parquet_path)
        Path(output_row_path).write_text('\n'.join(self.row_names) + ('\n' if self.row_names else ''))
        Path(output_column_path).write_text('\n'.join(self.col_names) + '\n')

    def emit_metadata(
        self,
        serial_number: str,
        dataset_uid: int,
        analysis_id: int,
        storage_path: str,
        row_path: str,
        column_path: str,
        metadata_path: str = 'reduced_metadata.json',
    ) -> None:
        sentinel = {
            'serial_number': serial_number,
            'dataset_uid': dataset_uid,
            'pipeline_stage': 'preparation',
            'analysis_id': analysis_id,
            'reduction_step': 'window_correlation',
            'storage_path': os.path.abspath(storage_path),
            'row_path': os.path.abspath(row_path),
            'column_path': os.path.abspath(column_path),
            'feature_number_before': self.feature_number_before,
            'feature_number_after': self.feature_number_after,
            'sample_number': self.sample_number,
            'status': 'completed',
        }
        with open(metadata_path, 'w') as f:
            json.dump(sentinel, f)


# %%
app = typer.Typer(add_completion=False)


@app.command()
def reduce_window(
    serial_number: str = '',
    dataset_uid: int = 0,
    analysis_id: int = typer.Option(0, help='Always 0 for preparation'),
    parquet_path: str = '',
    row_path: str = '',
    column_path: str = '',
    window_size: float = 1.5,
    window_corr_threshold: float = 0.85,
    window_metric: str = 'cv',
    output_parquet_path: str = 'reduced.parquet',
    output_row_path: str = 'reduced_row.tsv',
    output_column_path: str = 'reduced_col.tsv',
    metadata_path: str = 'reduced_metadata.json',
):
    try:
        ex = WindowCorrelationExecutor(parquet_path, row_path, column_path)
        ex.filter(
            window_size=window_size,
            window_corr_threshold=window_corr_threshold,
            window_metric=window_metric,
        )
        ex.save(output_parquet_path, output_row_path, output_column_path)
        ex.emit_metadata(
            serial_number=serial_number,
            dataset_uid=dataset_uid,
            analysis_id=analysis_id,
            storage_path=output_parquet_path,
            row_path=output_row_path,
            column_path=output_column_path,
            metadata_path=metadata_path,
        )
        logger.success('Module 3 complete.')
    except Exception as e:
        write_error_sentinel(metadata_path, serial_number, dataset_uid, analysis_id, e)
        raise


@app.callback()
def callback():
    pass


if __name__ == '__main__':
    app()
