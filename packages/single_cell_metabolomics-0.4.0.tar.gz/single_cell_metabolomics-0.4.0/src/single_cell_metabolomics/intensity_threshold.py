# %%
"""Module 1 — Absolute Intensity Thresholding.

Drop features whose intensity reaches `abs_intensity_threshold` in fewer than
`ceil(N_non_blank × intensity_min_detection_rate / 100)` samples. Row-wise
single-pass scan — no feature-by-feature similarity matrix.
"""
from __future__ import annotations

import json
import math
import os
from pathlib import Path

import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import typer
from loguru import logger

from single_cell_metabolomics.config import write_error_sentinel


class IntensityThresholdExecutor:
    """Loads a long-COO parquet, applies the per-feature detection-count gate,
    and writes the surviving subset back as long-COO + sidecar TSVs."""

    def __init__(
        self,
        matrix_data_path: str,
        matrix_row_path: str,
        matrix_column_path: str,
    ) -> None:
        self.matrix_data_path = matrix_data_path
        self.matrix_row_path = matrix_row_path
        self.matrix_column_path = matrix_column_path

        self.df = pq.read_table(matrix_data_path).to_pandas()
        # Long-COO with VARCHAR row/col + DOUBLE value
        self.df['row'] = self.df['row'].astype(str)
        self.df['col'] = self.df['col'].astype(str)
        self.df['value'] = self.df['value'].astype(np.float32)

        self.row_names = [r for r in Path(matrix_row_path).read_text().splitlines() if r]
        self.col_names = [c for c in Path(matrix_column_path).read_text().splitlines() if c]
        self.feature_number_before = len(self.row_names)
        self.sample_number = len(self.col_names)
        self.feature_number_after: int | None = None

    def filter(
        self,
        abs_intensity_threshold: float,
        intensity_min_detection_rate: float,
    ) -> tuple[int, int]:
        """Drop features below the per-sample detection-count gate.

        Returns (n_kept, n_dropped)."""
        n_samples = self.sample_number
        min_count = int(math.ceil(n_samples * intensity_min_detection_rate / 100.0))
        logger.info(
            f"Module 1: features={self.feature_number_before} samples={n_samples} "
            f"abs_threshold={abs_intensity_threshold} min_detection_rate={intensity_min_detection_rate}% "
            f"-> min_sample_count={min_count}"
        )

        passing = self.df['value'] >= float(abs_intensity_threshold)
        per_feature_counts = (
            self.df.loc[passing].groupby('row', observed=True).size()
        )
        survivors = set(per_feature_counts[per_feature_counts >= min_count].index)
        self.df = self.df[self.df['row'].isin(survivors)].reset_index(drop=True)
        self.row_names = [r for r in self.row_names if r in survivors]
        self.feature_number_after = len(self.row_names)
        n_dropped = self.feature_number_before - self.feature_number_after
        logger.info(f"Module 1: kept={self.feature_number_after} dropped={n_dropped}")
        return self.feature_number_after, n_dropped

    def save(
        self,
        output_parquet_path: str,
        output_row_path: str,
        output_column_path: str,
    ) -> None:
        Path(output_parquet_path).parent.mkdir(parents=True, exist_ok=True)
        out_table = pa.Table.from_pandas(
            self.df[['row', 'col', 'value']], preserve_index=False
        )
        pq.write_table(out_table, output_parquet_path)
        Path(output_row_path).write_text('\n'.join(self.row_names) + ('\n' if self.row_names else ''))
        Path(output_column_path).write_text('\n'.join(self.col_names) + '\n')
        logger.info(f"Module 1 saved to {output_parquet_path}")

    def emit_metadata(
        self,
        serial_number: str,
        dataset_uid: int,
        analysis_id: int,
        storage_path: str,
        row_path: str,
        column_path: str,
        metadata_path: str = 'intensity_filtered_metadata.json',
    ) -> None:
        sentinel = {
            'serial_number': serial_number,
            'dataset_uid': dataset_uid,
            'pipeline_stage': 'preparation',
            'analysis_id': analysis_id,
            'reduction_step': 'intensity_threshold',
            'storage_path': os.path.abspath(storage_path),
            'row_path': os.path.abspath(row_path),
            'column_path': os.path.abspath(column_path),
            'feature_number_before': self.feature_number_before,
            'feature_number_after': self.feature_number_after,
            'sample_number': self.sample_number,
            'status': 'completed',
        }
        with open(metadata_path, 'w') as f:
            json.dump(sentinel, f)


# %%
app = typer.Typer(add_completion=False)


@app.command()
def reduce_intensity(
    serial_number: str = '',
    dataset_uid: int = 0,
    analysis_id: int = typer.Option(0, help='Always 0 for preparation'),
    parquet_path: str = '',
    row_path: str = '',
    column_path: str = '',
    abs_intensity_threshold: float = 1000.0,
    intensity_min_detection_rate: float = 10.0,
    output_parquet_path: str = 'intensity_filtered.parquet',
    output_row_path: str = 'intensity_filtered_row.tsv',
    output_column_path: str = 'intensity_filtered_col.tsv',
    metadata_path: str = 'intensity_filtered_metadata.json',
):
    """Drop features below the per-sample intensity-count gate."""
    try:
        ex = IntensityThresholdExecutor(parquet_path, row_path, column_path)
        ex.filter(abs_intensity_threshold, intensity_min_detection_rate)
        ex.save(output_parquet_path, output_row_path, output_column_path)
        ex.emit_metadata(
            serial_number=serial_number,
            dataset_uid=dataset_uid,
            analysis_id=analysis_id,
            storage_path=output_parquet_path,
            row_path=output_row_path,
            column_path=output_column_path,
            metadata_path=metadata_path,
        )
        logger.success('Module 1 complete.')
    except Exception as e:
        write_error_sentinel(metadata_path, serial_number, dataset_uid, analysis_id, e)
        raise


@app.callback()
def callback():
    pass


if __name__ == '__main__':
    app()
