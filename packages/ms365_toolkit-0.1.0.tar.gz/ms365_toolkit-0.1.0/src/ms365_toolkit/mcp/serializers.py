from __future__ import annotations

from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Sequence

    from ms365_toolkit.models.calendar import Attendee, CalendarEvent
    from ms365_toolkit.models.email import AttachmentInfo, EmailMessage


def isoformat_utc(value: datetime) -> str:
    return value.astimezone(UTC).isoformat().replace("+00:00", "Z")


def serialize_email(message: EmailMessage) -> dict[str, Any]:
    return {
        "id": message.id,
        "subject": message.subject,
        "sender": message.sender,
        "to": list(message.to),
        "cc": list(message.cc),
        "bcc": list(message.bcc),
        "body_preview": message.body_preview,
        "body_content": message.body_content,
        "received_at": isoformat_utc(message.received_at),
        "is_read": message.is_read,
        "is_flagged": message.is_flagged,
        "importance": message.importance,
        "has_attachments": message.has_attachments,
        "attachments": [serialize_attachment(item) for item in message.attachments],
        "conversation_id": message.conversation_id,
        "folder_id": message.folder_id,
    }


def serialize_attachment(attachment: AttachmentInfo) -> dict[str, Any]:
    return {
        "name": attachment.name,
        "content_type": attachment.content_type,
        "size": attachment.size,
        "sha256": attachment.sha256,
        "is_reference": attachment.is_reference,
    }


def serialize_event(event: CalendarEvent) -> dict[str, Any]:
    return {
        "id": event.id,
        "subject": event.subject,
        "start": isoformat_utc(event.start),
        "end": isoformat_utc(event.end),
        "timezone": event.timezone,
        "location": event.location,
        "body_content": event.body_content,
        "attendees": [serialize_attendee(item) for item in event.attendees],
        "is_online_meeting": event.is_online_meeting,
        "is_cancelled": event.is_cancelled,
        "importance": event.importance,
        "categories": list(event.categories),
        "recurrence": event.recurrence,
        "organizer": event.organizer,
        "response_status": event.response_status,
        "calendar_id": event.calendar_id,
    }


def serialize_attendee(attendee: Attendee) -> dict[str, Any]:
    return {
        "email": attendee.email,
        "name": attendee.name,
        "response": attendee.response,
        "type": attendee.type,
    }


def serialize_windows(windows: Sequence[tuple[datetime, datetime]]) -> list[dict[str, Any]]:
    serialized: list[dict[str, Any]] = []
    for start, end in windows:
        serialized.append(
            {
                "start": isoformat_utc(start),
                "end": isoformat_utc(end),
                "duration_minutes": int((end - start).total_seconds() // 60),
            }
        )
    return serialized
