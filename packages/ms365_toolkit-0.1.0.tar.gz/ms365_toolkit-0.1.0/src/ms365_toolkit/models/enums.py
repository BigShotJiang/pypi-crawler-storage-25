from __future__ import annotations

from enum import StrEnum


class Scope(StrEnum):
    MAIL_READ = "Mail.Read"
    CALENDARS_READ = "Calendars.Read"
    MAIL_READ_WRITE = "Mail.ReadWrite"
    MAIL_SEND = "Mail.Send"
    CALENDARS_READ_WRITE = "Calendars.ReadWrite"
    MAIL_READ_SHARED = "Mail.Read.Shared"
    CALENDARS_READ_SHARED = "Calendars.Read.Shared"
    MAIL_READ_WRITE_SHARED = "Mail.ReadWrite.Shared"
    MAIL_SEND_SHARED = "Mail.Send.Shared"
    CALENDARS_READ_WRITE_SHARED = "Calendars.ReadWrite.Shared"
    MAILBOX_SETTINGS_READ = "MailboxSettings.Read"
    MAILBOX_SETTINGS_READ_WRITE = "MailboxSettings.ReadWrite"


READ_SCOPES = frozenset(
    {Scope.MAIL_READ.value, Scope.CALENDARS_READ.value, Scope.MAILBOX_SETTINGS_READ.value}
)
WRITE_SCOPES = frozenset(
    {
        Scope.MAIL_READ_WRITE.value,
        Scope.MAIL_SEND.value,
        Scope.CALENDARS_READ_WRITE.value,
        Scope.MAILBOX_SETTINGS_READ_WRITE.value,
    }
)
DELEGATED_READ_SCOPES = frozenset(
    {Scope.MAIL_READ_SHARED.value, Scope.CALENDARS_READ_SHARED.value}
)
DELEGATED_WRITE_SCOPES = frozenset(
    {
        Scope.MAIL_READ_WRITE_SHARED.value,
        Scope.MAIL_SEND_SHARED.value,
        Scope.CALENDARS_READ_WRITE_SHARED.value,
    }
)


class Badge(StrEnum):
    PRIORITY = "PRIORITY"
    FLAGGED = "FLAGGED"
    VIP = "VIP"
    EXTERNAL = "EXTERNAL"
    NONE = ""
