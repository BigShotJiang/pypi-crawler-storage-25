from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import TYPE_CHECKING

from ms365_toolkit.cli.read_common import build_mailbox_index, build_read_clients
from ms365_toolkit.intelligence.email_triage import TriageResult, triage_email
from ms365_toolkit.intelligence.labels import default_labels_path, read_label_records
from ms365_toolkit.intelligence.morning_brief import morning_brief
from ms365_toolkit.intelligence.thread_classifier import ThreadClassifier, train_thread_classifier
from ms365_toolkit.safety.domains import email_matches_domain_patterns

if TYPE_CHECKING:
    from argparse import Namespace
    from collections.abc import Mapping

    from ms365_toolkit.client.email import EmailClient
    from ms365_toolkit.client.mail_index import IndexedThread
    from ms365_toolkit.config.loader import ToolkitConfig
    from ms365_toolkit.intelligence.labels import ThreadLabelRecord
    from ms365_toolkit.models.email import EmailMessage


def read_email_command(args: Namespace, config: ToolkitConfig) -> int:
    email_client, _ = build_read_clients(config, args.profile)
    message = email_client.read_email(args.message_id)
    print(f"Subject: {message.subject}")
    print(f"From: {message.sender}")
    print(f"Received: {message.received_at.isoformat()}")
    print(f"Preview: {message.body_preview}")
    print(message.body_content)
    return 0


def list_events_command(args: Namespace, config: ToolkitConfig) -> int:
    _, calendar_client = build_read_clients(config, args.profile)
    start = datetime.now(UTC)
    end = start + timedelta(hours=args.hours)
    events = calendar_client.list_events(start=start, end=end)
    if not events:
        print("No events found.")
        return 0
    for event in events:
        print(f"{event.start.isoformat()} {event.subject} @ {event.location}")
    return 0


def morning_brief_command(args: Namespace, config: ToolkitConfig) -> int:
    email_client, calendar_client = build_read_clients(config, args.profile)
    now = datetime.now(UTC)
    emails = email_client.list_inbox(mailbox_filter=None, top=args.top, skip=0)
    events = calendar_client.list_events(start=now, end=now + timedelta(hours=8))
    brief = morning_brief(emails, events, config)
    print(f"Action required: {len(brief.action_required)}")
    print(f"VIP: {len(brief.vip)}")
    print(f"Flagged: {len(brief.flagged)}")
    print(f"FYI: {len(brief.fyi)}")
    print(f"Upcoming events: {len(brief.upcoming_events)}")
    for item in brief.action_required[:3]:
        print(f"ACTION {item.email.sender} {item.email.subject}")
    for scored_event in brief.upcoming_events[:3]:
        print(
            f"EVENT {scored_event.event.start.isoformat()} "
            f"{scored_event.event.subject} [{scored_event.score}]"
        )
    return 0


def search_emails_command(args: Namespace, config: ToolkitConfig) -> int:
    email_client, _ = build_read_clients(config, args.profile)
    mailbox_filter = None if args.filter == "all" else args.filter
    messages = email_client.search_emails(args.query, mailbox_filter=mailbox_filter)
    if not messages:
        print("No messages found.")
        return 0
    for message in messages[: args.top]:
        print(
            f"{message.received_at.isoformat()} {message.id} "
            f"{message.conversation_id} {message.sender} {message.subject}"
        )
    return 0


def download_email_attachments_command(args: Namespace, config: ToolkitConfig) -> int:
    email_client, _ = build_read_clients(config, args.profile)
    attachments = email_client.download_attachments(args.message_id)
    if not attachments:
        print("No downloadable attachments found.")
        return 0
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    for attachment in attachments:
        output_path = _unique_attachment_path(output_dir, attachment.name, attachment.attachment_id)
        output_path.write_bytes(attachment.content)
        print(f"Saved {attachment.name or attachment.attachment_id} -> {output_path}")
    return 0


def sync_mail_index_command(args: Namespace, config: ToolkitConfig) -> int:
    email_client, _ = build_read_clients(config, args.profile)
    index = build_mailbox_index(args.profile)
    changed_count = index.sync(email_client, batch_size=args.batch_size, max_pages=args.max_pages)
    print(f"Indexed {changed_count} message changes into {index.path}")
    return 0


def search_local_mail_index_command(args: Namespace, config: ToolkitConfig) -> int:
    index = build_mailbox_index(args.profile)
    results = index.search(args.query, limit=args.top)
    if not results:
        print("No indexed messages found.")
        return 0
    for item in results:
        print(
            f"{item.received_at} {item.message_id} "
            f"{item.conversation_id} {item.sender} {item.subject}"
        )
    return 0


def triage_inbox_command(args: Namespace, config: ToolkitConfig) -> int:
    email_client, _ = build_read_clients(config, args.profile)
    index = build_mailbox_index(args.profile)
    if args.sync_index:
        index.sync(email_client, batch_size=args.top, max_pages=args.max_pages)
    threads = index.recent_threads(limit=args.top)
    triaged_threads = _triage_threads(threads, email_client, config, args.profile)
    if not triaged_threads:
        print("No messages found.")
        return 0
    for rank, item in enumerate(triaged_threads[: args.limit], start=1):
        triage = item.triage
        print(f"{rank}. {triage.email.subject}")
        print(f"   From: {triage.email.sender}")
        print(f"   Received: {triage.email.received_at.isoformat()}")
        print(f"   Message ID: {triage.email.id}")
        print(f"   Conversation ID: {triage.email.conversation_id}")
        print(f"   Sender type: {item.sender_type}")
        print(
            "   Classification: "
            f"{item.thread_class} ({item.prediction_source}, {item.prediction_confidence:.2f})"
        )
        if item.cluster_size > 1:
            print(f"   Similar threads: {item.cluster_size}")
        print(f"   Why it matters: {_why_it_matters(item)}")
        print(f"   Likely action: {_likely_action(item)}")
        print(f"   Preview: {_preview(triage.email.body_content)}")
    return 0


def _triage_threads(
    threads: list[IndexedThread],
    email_client: EmailClient,
    config: ToolkitConfig,
    profile: str,
) -> list[ThreadTriage]:
    labels_path = default_labels_path(profile)
    labeled_records = read_label_records(labels_path)
    classifier = train_thread_classifier(labeled_records)
    labels_by_thread = {
        record.thread_id: record
        for record in labeled_records
        if record.labels is not None
    }
    triaged: list[ThreadTriage] = []
    for thread in threads:
        full_message = email_client.read_email(thread.latest_message_id)
        triage = triage_email(full_message, config)
        sender_type = _sender_type(full_message.sender, config)
        thread_class, prediction_confidence, prediction_source = _classify_labeled_thread(
            thread_id=thread.conversation_id,
            triage=triage,
            sender_type=sender_type,
            labels_by_thread=labels_by_thread,
            classifier=classifier,
        )
        triaged.append(
            ThreadTriage(
                triage=triage,
                sender_type=sender_type,
                cluster_key=_cluster_key(full_message),
                cluster_size=1,
                thread_class=thread_class,
                prediction_confidence=prediction_confidence,
                prediction_source=prediction_source,
            )
        )
    clustered = _cluster_threads(triaged)
    clustered.sort(key=_triage_sort_key, reverse=True)
    return clustered


def _triage_sort_key(result: ThreadTriage) -> tuple[int, int, float, int, int, int, float]:
    triage = result.triage
    class_weight = {
        "approval_request": 5,
        "decision_request": 4,
        "incident_or_risk": 4,
        "contract_or_renewal": 3,
        "strategic_update": 2,
        "status_update": 1,
        "fyi_noise": 0,
    }[result.thread_class]
    importance_weight = {"high": 2, "normal": 1, "low": 0}.get(triage.email.importance, 1)
    sender_weight = _sender_weight(result.sender_type)
    source_weight = {"manual": 2, "model": 1, "heuristic": 0}[result.prediction_source]
    cluster_weight = min(result.cluster_size, 3)
    timestamp = triage.email.received_at.timestamp()
    return (
        class_weight,
        source_weight,
        result.prediction_confidence,
        sender_weight,
        importance_weight,
        cluster_weight,
        timestamp,
    )


def _sender_weight(sender_type: str) -> int:
    if sender_type == "human_internal":
        return 2
    if sender_type == "human_external":
        return 1
    if sender_type == "automated_internal":
        return -1
    if sender_type == "automated_external":
        return -1
    return 0


def _why_it_matters(result: ThreadTriage) -> str:
    triage = result.triage
    reasons = {
        "approval_request": "explicit ask for approval or action",
        "decision_request": "needs direction or decision from stakeholders",
        "incident_or_risk": "active issue, escalation, or business risk signal",
        "contract_or_renewal": "commercial or renewal-related thread",
        "strategic_update": "strategic/internal update worth reading",
        "status_update": "internal status update for awareness",
        "fyi_noise": "likely informational or automated noise",
    }
    extra: list[str] = []
    if result.sender_type == "human_internal":
        extra.append("internal human sender")
    if result.sender_type.startswith("automated") and result.cluster_size > 1:
        extra.append("repeated automated issue cluster")
    if triage.email.is_flagged:
        extra.append("flagged")
    return "; ".join([reasons[result.thread_class], *extra])


def _likely_action(result: ThreadTriage) -> str:
    actions = {
        "approval_request": "Review and approve or reassign the request",
        "decision_request": "Reply with a decision, direction, or next step",
        "incident_or_risk": "Assess urgency and determine whether intervention is needed",
        "contract_or_renewal": "Decide on renewal timing, owner, and budget",
        "strategic_update": "Read and decide whether a response or follow-up is needed",
        "status_update": "Read for situational awareness only",
        "fyi_noise": "Monitor only unless it becomes persistent or business-impacting",
    }
    return actions[result.thread_class]


def _preview(body_content: str) -> str:
    plain = re.sub(r"</?untrusted-email-content>", "", body_content)
    normalized = " ".join(plain.split())
    return normalized[:180]


def _sender_type(sender: str, config: ToolkitConfig) -> str:
    normalized = sender.lower()
    automated_markers = ("no-reply", "noreply", "alerts@", "automatic", "digest", "bot")
    if _is_internal_sender(normalized, config):
        if any(marker in normalized for marker in automated_markers):
            return "automated_internal"
        return "human_internal"
    if any(marker in normalized for marker in automated_markers):
        return "automated_external"
    return "human_external"


def _is_internal_sender(sender: str, config: ToolkitConfig) -> bool:
    if "@" not in sender:
        return False
    sender_domain = sender.rsplit("@", 1)[1]
    if config.user.user_principal_name and "@" in config.user.user_principal_name:
        own_domain = config.user.user_principal_name.strip().lower().rsplit("@", 1)[1]
        if sender_domain == own_domain:
            return True
    return email_matches_domain_patterns(sender, config.safety.domain_allowlist)


def _cluster_key(email: EmailMessage) -> str:
    text = f"{email.subject}\n{email.body_content}".lower()
    if "invoice" in text and "approval" in text:
        return "invoice-approval"
    if "payment authorization failures" in text:
        return "payment-authorization-failures"
    subject = re.sub(r"^(re|fw|fwd):\s*", "", email.subject.lower()).strip()
    subject = re.sub(r"\b\d+\b", "", subject)
    subject = re.sub(r"\s+", " ", subject)
    return subject


def _cluster_threads(items: list[ThreadTriage]) -> list[ThreadTriage]:
    clusters: dict[str, list[ThreadTriage]] = {}
    for item in items:
        clusters.setdefault(item.cluster_key, []).append(item)

    clustered: list[ThreadTriage] = []
    for values in clusters.values():
        values.sort(key=lambda item: item.triage.email.received_at, reverse=True)
        head = values[0]
        clustered.append(
            ThreadTriage(
                triage=head.triage,
                sender_type=head.sender_type,
                cluster_key=head.cluster_key,
                cluster_size=len(values),
                thread_class=head.thread_class,
                prediction_confidence=head.prediction_confidence,
                prediction_source=head.prediction_source,
            )
        )
    return clustered


def _classify_labeled_thread(
    *,
    thread_id: str,
    triage: TriageResult,
    sender_type: str,
    labels_by_thread: Mapping[str, ThreadLabelRecord],
    classifier: ThreadClassifier | None,
) -> tuple[str, float, str]:
    labeled_record = labels_by_thread.get(thread_id)
    if labeled_record is not None:
        labels = labeled_record.labels
        if labels is not None:
            return labels.thread_class, 1.0, "manual"
    if classifier is not None:
        prediction = classifier.predict(
            subject=triage.email.subject,
            sender=triage.email.sender,
            sender_type=sender_type,
            body_preview=triage.email.body_preview,
            body_content=triage.email.body_content,
        )
        adjusted_class = _adjust_model_prediction(triage, prediction.thread_class)
        adjusted_confidence = prediction.confidence
        if adjusted_class != prediction.thread_class:
            adjusted_confidence = min(adjusted_confidence, 0.49)
        if adjusted_confidence >= 0.45:
            return adjusted_class, adjusted_confidence, "model"
    return _classify_thread(triage, sender_type), 0.5, "heuristic"


def _adjust_model_prediction(triage: TriageResult, predicted_class: str) -> str:
    if predicted_class != "approval_request":
        return predicted_class
    text = (
        f"{triage.email.subject}\n"
        f"{triage.email.body_preview}\n"
        f"{triage.email.body_content}"
    ).lower()
    if any(
        pattern in text
        for pattern in (
            "shared with you",
            "invited you to edit",
            "messages in quarantine",
            "review these messages",
        )
    ):
        return "status_update"
    if any(
        pattern in text
        for pattern in (
            "subscription will renew",
            "will automatically renew",
            "renew soon",
        )
    ):
        return "contract_or_renewal"
    return predicted_class


def _classify_thread(triage: TriageResult, sender_type: str) -> str:
    text = f"{triage.email.subject}\n{triage.email.body_content}".lower()
    subject = triage.email.subject.lower()

    if any(keyword in text for keyword in ("approve", "approval pending", "approval needed")):
        return "approval_request"
    if "$ request" in text or "please share your thoughts" in text:
        return "decision_request"
    if any(keyword in text for keyword in ("urgent", "incident", "escalation", "failure", "alert")):
        return "incident_or_risk"
    if any(keyword in text for keyword in ("renew", "subscription", "contract", "agreement")):
        return "contract_or_renewal"
    if any(
        keyword in subject
        for keyword in ("update", "report", "digest", "reminder", "automatic reply")
    ):
        return "status_update"
    if any(keyword in text for keyword in ("strategic", "operating model", "data separation")):
        return "strategic_update"
    if sender_type.startswith("automated"):
        return "fyi_noise"
    return "status_update"


def _unique_attachment_path(output_dir: Path, name: str, attachment_id: str) -> Path:
    candidate = output_dir / _safe_attachment_name(name, attachment_id)
    if not candidate.exists():
        return candidate
    stem = candidate.stem
    suffix = candidate.suffix
    index = 1
    while True:
        deduped = output_dir / f"{stem}-{index}{suffix}"
        if not deduped.exists():
            return deduped
        index += 1


def _safe_attachment_name(name: str, attachment_id: str) -> str:
    filename = Path(name).name
    if filename in {"", ".", ".."}:
        return f"attachment-{attachment_id}"
    return filename


@dataclass(frozen=True)
class ThreadTriage:
    triage: TriageResult
    sender_type: str
    cluster_key: str
    cluster_size: int
    thread_class: str
    prediction_confidence: float = 0.0
    prediction_source: str = "heuristic"
