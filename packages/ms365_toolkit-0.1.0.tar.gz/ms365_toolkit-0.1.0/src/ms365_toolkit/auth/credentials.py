from __future__ import annotations

import os
from contextlib import suppress
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, cast

import keyring
import msal  # type: ignore[import-untyped]
from keyring.errors import PasswordDeleteError, PasswordSetError

from ms365_toolkit.models.enums import (
    DELEGATED_READ_SCOPES,
    DELEGATED_WRITE_SCOPES,
    READ_SCOPES,
    WRITE_SCOPES,
)

if TYPE_CHECKING:
    from ms365_toolkit.config.loader import ToolkitConfig

SERVICE_NAME = "ms365-toolkit"
READ_CACHE_KEY = "ms365-read-token-{profile}"
WRITE_CACHE_KEY = "ms365-write-token-{profile}"
READ_ENV_KEY = "MS365_READ_TOKEN_CACHE_{profile}"
WRITE_ENV_KEY = "MS365_WRITE_TOKEN_CACHE_{profile}"


@dataclass(frozen=True)
class CredentialStore:
    profile: str
    keyring_backend: Any = keyring

    def load_cache(
        self,
        *,
        kind: str,
        explicit_value: str | None = None,
        allow_env: bool = True,
    ) -> msal.SerializableTokenCache:
        cache = msal.SerializableTokenCache()
        raw_value = self._resolve_raw_cache(
            kind=kind,
            explicit_value=explicit_value,
            allow_env=allow_env,
        )
        if raw_value:
            cache.deserialize(raw_value)
        return cache

    def save_cache(
        self,
        *,
        kind: str,
        cache: msal.SerializableTokenCache,
        allow_env_write: bool = False,
    ) -> None:
        serialized = cache.serialize()
        cache_key = self._cache_key(kind)
        try:
            self.keyring_backend.set_password(
                SERVICE_NAME,
                cache_key,
                serialized,
            )
        except PasswordSetError:
            with suppress(PasswordDeleteError):
                self.keyring_backend.delete_password(SERVICE_NAME, cache_key)
            self.keyring_backend.set_password(
                SERVICE_NAME,
                cache_key,
                serialized,
            )
        if kind != "write" or not allow_env_write:
            return
        os.environ[self._env_key(kind)] = serialized

    def delete_cache(self, *, kind: str) -> None:
        with suppress(PasswordDeleteError):
            self.keyring_backend.delete_password(SERVICE_NAME, self._cache_key(kind))
        os.environ.pop(self._env_key(kind), None)

    def scopes_for(self, config: ToolkitConfig, *, write: bool) -> frozenset[str]:
        if config.user.endpoint == "users":
            return DELEGATED_WRITE_SCOPES if write else DELEGATED_READ_SCOPES
        return WRITE_SCOPES if write else READ_SCOPES

    def _resolve_raw_cache(
        self,
        *,
        kind: str,
        explicit_value: str | None,
        allow_env: bool,
    ) -> str | None:
        if explicit_value:
            return explicit_value
        value = cast(
            "str | None",
            self.keyring_backend.get_password(SERVICE_NAME, self._cache_key(kind)),
        )
        if value:
            return value
        if allow_env:
            return os.environ.get(self._env_key(kind))
        return None

    def _cache_key(self, kind: str) -> str:
        if kind == "read":
            return READ_CACHE_KEY.format(profile=self.profile)
        if kind == "write":
            return WRITE_CACHE_KEY.format(profile=self.profile)
        raise ValueError(f"unsupported cache kind: {kind}")

    def _env_key(self, kind: str) -> str:
        if kind == "read":
            return READ_ENV_KEY.format(profile=_env_profile(self.profile))
        if kind == "write":
            return WRITE_ENV_KEY.format(profile=_env_profile(self.profile))
        raise ValueError(f"unsupported cache kind: {kind}")


def _env_profile(profile: str) -> str:
    return profile.upper().replace("-", "_")
