from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, cast

from ms365_toolkit.client.exceptions import AuthenticationError

if TYPE_CHECKING:
    from collections.abc import Callable

    import msal  # type: ignore[import-untyped]

    from ms365_toolkit.auth.credentials import CredentialStore
    from ms365_toolkit.config.loader import ToolkitConfig


@dataclass(frozen=True)
class DeviceCodePrompt:
    verification_uri: str
    user_code: str
    message: str


def authenticate_device_code(
    *,
    config: ToolkitConfig,
    credential_store: CredentialStore,
    write: bool,
    presenter: Callable[[DeviceCodePrompt], None],
    app_factory: Callable[[msal.SerializableTokenCache], Any],
    allow_env_write: bool = False,
) -> dict[str, Any]:
    cache = credential_store.load_cache(kind="write" if write else "read", allow_env=not write)
    scopes = credential_store.scopes_for(config, write=write)
    app = app_factory(cache)
    flow = app.initiate_device_flow(scopes=list(scopes))
    verification_uri = flow.get("verification_uri")
    user_code = flow.get("user_code")
    message = flow.get("message")
    if not all(
        isinstance(value, str) and value for value in (verification_uri, user_code, message)
    ):
        raise AuthenticationError("device code flow did not return verification details")
    presenter(
        DeviceCodePrompt(
            verification_uri=verification_uri,
            user_code=user_code,
            message=message,
        )
    )
    result = app.acquire_token_by_device_flow(flow)
    access_token = result.get("access_token") if isinstance(result, dict) else None
    if not isinstance(access_token, str) or not access_token:
        raise AuthenticationError("device code authentication failed")
    credential_store.save_cache(
        kind="write" if write else "read",
        cache=cache,
        allow_env_write=allow_env_write,
    )
    return cast("dict[str, Any]", result)
