from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING, Any

import jwt

from ms365_toolkit.client.exceptions import AuthenticationError, InsufficientScopesError

if TYPE_CHECKING:
    from collections.abc import Callable

    import msal  # type: ignore[import-untyped]

    from ms365_toolkit.auth.credentials import CredentialStore
    from ms365_toolkit.config.loader import ToolkitConfig


@dataclass(frozen=True)
class TokenBundle:
    access_token: str
    scopes: frozenset[str]
    expires_at: datetime


class TokenManager:
    def __init__(
        self,
        *,
        config: ToolkitConfig,
        credential_store: CredentialStore,
        app_factory: Callable[[msal.SerializableTokenCache], Any],
        auth_callback: (
            Callable[[frozenset[str], msal.SerializableTokenCache, str], dict[str, Any]] | None
        ) = None,
    ) -> None:
        self.config = config
        self.credential_store = credential_store
        self.app_factory = app_factory
        self.auth_callback = auth_callback

    def get_access_token(self, *, write: bool = False) -> TokenBundle:
        kind = "write" if write else "read"
        cache = self.credential_store.load_cache(kind=kind, allow_env=not write)
        app = self.app_factory(cache)
        scopes = self.credential_store.scopes_for(self.config, write=write)
        result = self._acquire_token(app, scopes, cache, kind)
        access_token = result.get("access_token")
        if not isinstance(access_token, str) or not access_token:
            raise AuthenticationError(f"missing access token for {kind} scopes")
        if _is_expiring(access_token):
            result = self._interactive_refresh(scopes, cache, kind)
            access_token = result.get("access_token")
        if not isinstance(access_token, str) or not access_token:
            raise AuthenticationError(f"missing refreshed access token for {kind} scopes")
        token_scopes = _token_scopes(result, access_token)
        normalized_scopes = frozenset(scope.lower() for scope in scopes)
        if not normalized_scopes.issubset(token_scopes):
            raise InsufficientScopesError(scopes, token_scopes)
        self.credential_store.save_cache(kind=kind, cache=cache, allow_env_write=False)
        return TokenBundle(
            access_token=access_token,
            scopes=token_scopes,
            expires_at=_token_expiry(access_token),
        )

    def _acquire_token(
        self,
        app: Any,
        scopes: frozenset[str],
        cache: msal.SerializableTokenCache,
        kind: str,
    ) -> dict[str, Any]:
        accounts = app.get_accounts()
        account = accounts[0] if accounts else None
        result = app.acquire_token_silent(list(scopes), account=account)
        if isinstance(result, dict) and result.get("access_token"):
            return result
        return self._interactive_refresh(scopes, cache, kind)

    def _interactive_refresh(
        self,
        scopes: frozenset[str],
        cache: msal.SerializableTokenCache,
        kind: str,
    ) -> dict[str, Any]:
        if self.auth_callback is None:
            raise AuthenticationError(f"interactive authentication required for {kind} scopes")
        result = self.auth_callback(scopes, cache, kind)
        if not isinstance(result, dict):
            raise AuthenticationError("authentication callback returned invalid result")
        return result


def _token_expiry(access_token: str) -> datetime:
    payload = jwt.decode(access_token, options={"verify_signature": False, "verify_aud": False})
    exp = payload.get("exp")
    if not isinstance(exp, int):
        raise AuthenticationError("token does not contain integer exp claim")
    return datetime.fromtimestamp(exp, tz=UTC)


def _is_expiring(access_token: str, *, grace_period: timedelta = timedelta(minutes=5)) -> bool:
    return _token_expiry(access_token) <= datetime.now(UTC) + grace_period


def _token_scopes(result: dict[str, Any], access_token: str) -> frozenset[str]:
    scope_string = result.get("scope") or result.get("scopes") or result.get("scp")
    if isinstance(scope_string, str) and scope_string.strip():
        return frozenset(scope.lower() for scope in scope_string.split())
    payload = jwt.decode(access_token, options={"verify_signature": False, "verify_aud": False})
    token_scope_string = payload.get("scp")
    if not isinstance(token_scope_string, str):
        raise AuthenticationError("token does not contain scopes")
    return frozenset(scope.lower() for scope in token_scope_string.split())
