from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING, Any

import pytest

from ms365_toolkit.auth.credentials import CredentialStore
from ms365_toolkit.auth.tokens import TokenManager
from ms365_toolkit.client.exceptions import AuthenticationError, InsufficientScopesError
from ms365_toolkit.config.loader import load_config, write_config_text

if TYPE_CHECKING:
    from pathlib import Path


def test_token_manager_uses_silent_token_when_valid(tmp_path: Path) -> None:
    config = _config(tmp_path)
    backend = _FakeKeyring()
    store = CredentialStore(profile="default", keyring_backend=backend)
    token = _jwt_token(
        expiry=datetime.now(UTC) + timedelta(hours=1),
        scopes="Mail.Read Calendars.Read MailboxSettings.Read",
    )
    app = _FakeApp(
        {
            "access_token": token,
            "scope": "Mail.Read Calendars.Read MailboxSettings.Read",
        }
    )
    manager = TokenManager(config=config, credential_store=store, app_factory=lambda cache: app)

    bundle = manager.get_access_token(write=False)

    assert bundle.access_token == token
    assert "mail.read" in bundle.scopes


def test_token_manager_refreshes_when_token_is_expiring(tmp_path: Path) -> None:
    config = _config(tmp_path)
    store = CredentialStore(profile="default", keyring_backend=_FakeKeyring())
    expiring = _jwt_token(
        expiry=datetime.now(UTC) + timedelta(minutes=1),
        scopes="Mail.Read Calendars.Read",
    )
    refreshed = _jwt_token(
        expiry=datetime.now(UTC) + timedelta(hours=1),
        scopes="Mail.Read Calendars.Read",
    )
    app = _FakeApp({"access_token": expiring, "scope": "Mail.Read Calendars.Read"})
    manager = TokenManager(
        config=config,
        credential_store=store,
        app_factory=lambda cache: app,
        auth_callback=lambda scopes, cache, kind: {
            "access_token": refreshed,
            "scope": " ".join(sorted(scopes)),
        },
    )

    bundle = manager.get_access_token(write=False)

    assert bundle.access_token == refreshed


def test_token_manager_rejects_missing_write_token_without_callback(tmp_path: Path) -> None:
    config = _config(tmp_path)
    store = CredentialStore(profile="default", keyring_backend=_FakeKeyring())
    app = _FakeApp(None)
    manager = TokenManager(config=config, credential_store=store, app_factory=lambda cache: app)

    with pytest.raises(AuthenticationError, match="interactive authentication required"):
        manager.get_access_token(write=True)


def test_token_manager_rejects_insufficient_scopes(tmp_path: Path) -> None:
    config = _config(tmp_path)
    store = CredentialStore(profile="default", keyring_backend=_FakeKeyring())
    token = _jwt_token(expiry=datetime.now(UTC) + timedelta(hours=1), scopes="Mail.Read")
    app = _FakeApp({"access_token": token, "scope": "Mail.Read"})
    manager = TokenManager(config=config, credential_store=store, app_factory=lambda cache: app)

    with pytest.raises(InsufficientScopesError):
        manager.get_access_token(write=False)


def test_token_manager_accepts_scope_case_differences(tmp_path: Path) -> None:
    config = _config(tmp_path)
    store = CredentialStore(profile="default", keyring_backend=_FakeKeyring())
    token = _jwt_token(
        expiry=datetime.now(UTC) + timedelta(hours=1),
        scopes="mail.read calendars.read mailboxsettings.read",
    )
    app = _FakeApp(
        {
            "access_token": token,
            "scope": "mail.read calendars.read mailboxsettings.read",
        }
    )
    manager = TokenManager(config=config, credential_store=store, app_factory=lambda cache: app)

    bundle = manager.get_access_token(write=False)

    assert "mail.read" in bundle.scopes


class _FakeApp:
    def __init__(self, result: dict[str, Any] | None) -> None:
        self.result = result

    def get_accounts(self) -> list[dict[str, str]]:
        return [{"home_account_id": "abc"}]

    def acquire_token_silent(
        self,
        scopes: list[str],
        account: dict[str, str] | None = None,
    ) -> dict[str, Any] | None:
        return self.result


class _FakeKeyring:
    def __init__(self) -> None:
        self.values: dict[tuple[str, str], str] = {}

    def get_password(self, service_name: str, username: str) -> str | None:
        return self.values.get((service_name, username))

    def set_password(self, service_name: str, username: str, password: str) -> None:
        self.values[(service_name, username)] = password

    def delete_password(self, service_name: str, username: str) -> None:
        self.values.pop((service_name, username), None)


def _jwt_token(*, expiry: datetime, scopes: str) -> str:
    import base64
    import json

    header = base64.urlsafe_b64encode(
        json.dumps({"alg": "none", "typ": "JWT"}).encode()
    ).rstrip(b"=")
    payload = base64.urlsafe_b64encode(
        json.dumps({"exp": int(expiry.timestamp()), "scp": scopes}).encode()
    ).rstrip(b"=")
    return f"{header.decode()}.{payload.decode()}."


def _config(tmp_path: Path) -> Any:
    config_path = tmp_path / "default" / "config.toml"
    content = """
[auth]
tenant_id = "tenant"
client_id = "client"

[user]
endpoint = "me"
user_principal_name = "owner@example.com"
timezone = "America/Chicago"

[safety]
domain_allowlist = ["example.com"]
folder_allowlist = ["Archive"]
send_email_per_hour = 5
send_email_per_day = 20
draft_email_per_hour = 10
draft_email_per_day = 30
reply_email_per_hour = 5
reply_email_per_day = 20
forward_email_per_hour = 5
forward_email_per_day = 20
move_email_per_hour = 20
flag_email_per_hour = 50
create_event_per_hour = 5
create_event_per_day = 20
update_event_per_hour = 10
respond_event_per_hour = 10

[vip]
emails = []
domains = []

[intelligence]
critical_keywords = []
noise_keywords = []
action_keywords = []
""".strip()
    write_config_text(config_path, content)
    return load_config(base_dir=tmp_path)
