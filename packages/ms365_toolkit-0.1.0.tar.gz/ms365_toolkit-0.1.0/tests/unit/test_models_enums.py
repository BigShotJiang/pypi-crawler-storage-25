from __future__ import annotations

from ms365_toolkit.models.enums import (
    DELEGATED_READ_SCOPES,
    DELEGATED_WRITE_SCOPES,
    READ_SCOPES,
    WRITE_SCOPES,
    Badge,
    Scope,
)


def test_scope_sets_match_expected_values() -> None:
    assert frozenset({"Mail.Read", "Calendars.Read", "MailboxSettings.Read"}) == READ_SCOPES
    assert frozenset(
        {"Mail.ReadWrite", "Mail.Send", "Calendars.ReadWrite", "MailboxSettings.ReadWrite"}
    ) == WRITE_SCOPES
    assert frozenset({"Mail.Read.Shared", "Calendars.Read.Shared"}) == DELEGATED_READ_SCOPES
    assert frozenset(
        {"Mail.ReadWrite.Shared", "Mail.Send.Shared", "Calendars.ReadWrite.Shared"}
    ) == DELEGATED_WRITE_SCOPES


def test_badge_none_is_empty_string() -> None:
    assert Badge.NONE.value == ""
    assert Scope.MAIL_SEND.value == "Mail.Send"
