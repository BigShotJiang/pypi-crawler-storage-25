from __future__ import annotations

from argparse import Namespace
from datetime import UTC, datetime
from typing import TYPE_CHECKING

from ms365_toolkit.cli.read_tools import (
    ThreadTriage,
    _adjust_model_prediction,
    _classify_labeled_thread,
    _classify_thread,
    _cluster_threads,
    _likely_action,
    _sender_type,
    download_email_attachments_command,
    list_events_command,
    morning_brief_command,
    read_email_command,
    search_emails_command,
    triage_inbox_command,
)
from ms365_toolkit.intelligence.calendar_scoring import ScoredEvent
from ms365_toolkit.intelligence.email_triage import TriageResult
from ms365_toolkit.intelligence.labels import ThreadLabelRecord, ThreadLabels
from ms365_toolkit.intelligence.morning_brief import BriefResult
from ms365_toolkit.intelligence.thread_classifier import train_thread_classifier
from ms365_toolkit.models.calendar import Attendee, CalendarEvent
from ms365_toolkit.models.email import EmailMessage
from ms365_toolkit.models.enums import Badge

if TYPE_CHECKING:
    import pytest


def test_read_email_command_prints_message(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setattr(
        "ms365_toolkit.cli.read_tools.build_read_clients",
        lambda config, profile: (_FakeEmailClient(), _FakeCalendarClient()),
    )

    exit_code = read_email_command(Namespace(profile="default", message_id="msg-1"), _config())

    assert exit_code == 0
    output = capsys.readouterr().out
    assert "Subject: Hello" in output
    assert "sender@example.com" in output


def test_list_events_command_prints_events(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setattr(
        "ms365_toolkit.cli.read_tools.build_read_clients",
        lambda config, profile: (_FakeEmailClient(), _FakeCalendarClient()),
    )

    exit_code = list_events_command(Namespace(profile="default", hours=8), _config())

    assert exit_code == 0
    output = capsys.readouterr().out
    assert "Planning" in output


def test_morning_brief_command_prints_summary(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setattr(
        "ms365_toolkit.cli.read_tools.build_read_clients",
        lambda config, profile: (_FakeEmailClient(), _FakeCalendarClient()),
    )
    monkeypatch.setattr(
        "ms365_toolkit.cli.read_tools.morning_brief",
        lambda emails, events, config: BriefResult(
            action_required=(TriageResult(_email(), Badge.PRIORITY, True, "summary"),),
            vip=(),
            flagged=(),
            fyi=(),
            upcoming_events=(ScoredEvent(_event(), 88, "critical"),),
        ),
    )

    exit_code = morning_brief_command(Namespace(profile="default", top=5), _config())

    assert exit_code == 0
    output = capsys.readouterr().out
    assert "Action required: 1" in output
    assert "EVENT" in output


def test_search_emails_command_prints_message_ids(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setattr(
        "ms365_toolkit.cli.read_tools.build_read_clients",
        lambda config, profile: (_FakeSearchEmailClient(), _FakeCalendarClient()),
    )

    exit_code = search_emails_command(
        Namespace(profile="default", query="invoice", filter="all", top=5),
        _config(),
    )

    assert exit_code == 0
    output = capsys.readouterr().out
    assert "msg-1" in output
    assert "conv" in output


def test_download_email_attachments_command_writes_files(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
    tmp_path,
) -> None:
    monkeypatch.setattr(
        "ms365_toolkit.cli.read_tools.build_read_clients",
        lambda config, profile: (_FakeAttachmentEmailClient(), _FakeCalendarClient()),
    )

    exit_code = download_email_attachments_command(
        Namespace(profile="default", message_id="msg-1", output_dir=str(tmp_path)),
        _config(),
    )

    assert exit_code == 0
    assert (tmp_path / "report.txt").read_bytes() == b"hello"
    output = capsys.readouterr().out
    assert "report.txt" in output


def test_triage_inbox_command_deduplicates_threads_and_prints_why(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    index = _FakeMailboxIndex()
    monkeypatch.setattr(
        "ms365_toolkit.cli.read_tools.build_read_clients",
        lambda config, profile: (_FakeTriageEmailClient(), _FakeCalendarClient()),
    )
    monkeypatch.setattr(
        "ms365_toolkit.cli.read_tools.build_mailbox_index",
        lambda profile: index,
    )

    exit_code = triage_inbox_command(
        Namespace(profile="default", top=10, limit=3, sync_index=False, max_pages=5),
        _config(),
    )

    assert exit_code == 0
    output = capsys.readouterr().out
    assert "Why it matters:" in output
    assert "Likely action:" in output
    assert output.count("Conversation ID:") == 2
    assert "Classification:" in output


def test_cluster_threads_merges_similar_invoice_alerts() -> None:
    first = ThreadTriage(
        TriageResult(_email(), Badge.EXTERNAL, True, "summary"),
        "automated_external",
        "invoice-approval",
        1,
        "approval_request",
    )
    second_email = EmailMessage(
        **{
            **_email().__dict__,
            "id": "msg-2",
            "conversation_id": "conv-2",
            "subject": (
                "[EXT]Escalation Notice to InvoiceWorks Administrator: "
                "Invoice Approval Needed - 15 Day Alert"
            ),
        }
    )
    second = ThreadTriage(
        TriageResult(second_email, Badge.EXTERNAL, True, "summary"),
        "automated_external",
        "invoice-approval",
        1,
        "approval_request",
    )

    clustered = _cluster_threads([first, second])

    assert len(clustered) == 1
    assert clustered[0].cluster_size == 2


def test_likely_action_downgrades_status_updates() -> None:
    email = EmailMessage(
        **{
            **_email().__dict__,
            "subject": "D&T Strategic Program Update -3/13",
            "body_content": (
                "<untrusted-email-content>Status update with no ask"
                "</untrusted-email-content>"
            ),
        }
    )
    triage = ThreadTriage(
        TriageResult(email, Badge.NONE, False, "summary"),
        "human_internal",
        "d&t strategic program update",
        1,
        "status_update",
    )

    assert _likely_action(triage) == "Read for situational awareness only"


def test_classify_thread_distinguishes_status_update_from_decision_request() -> None:
    status_email = EmailMessage(
        **{
            **_email().__dict__,
            "subject": "D&T Strategic Program Update -3/13",
            "body_content": "<untrusted-email-content>Weekly update only</untrusted-email-content>",
        }
    )
    decision_email = EmailMessage(
        **{
            **_email().__dict__,
            "subject": "Strategic update to the state of the ExampleCo data structure",
            "body_content": (
                "<untrusted-email-content>Please share your thoughts on the future-state "
                "operating model</untrusted-email-content>"
            ),
        }
    )

    assert (
        _classify_thread(TriageResult(status_email, Badge.NONE, False, "summary"), "human_internal")
        == "status_update"
    )
    assert (
        _classify_thread(
            TriageResult(decision_email, Badge.NONE, False, "summary"),
            "human_internal",
        )
        == "decision_request"
    )


def test_sender_type_uses_config_domains() -> None:
    assert _sender_type("teammate@example.com", _config()) == "human_internal"
    assert _sender_type("teammate@alerts.example.com", _config()) == "human_internal"
    assert _sender_type("vendor@outside.com", _config()) == "human_external"


def test_classify_labeled_thread_prefers_manual_label() -> None:
    triage = TriageResult(_email(), Badge.NONE, False, "summary")
    record = ThreadLabelRecord(
        thread_id="conv",
        message_id="msg-1",
        subject="Hello",
        sender="sender@example.com",
        sender_type="human_internal",
        received_at="2026-03-12T00:00:00+00:00",
        body_preview="Preview",
        body_content="Body",
        thread_size=1,
        cluster_size=1,
        labels=ThreadLabels(
            thread_class="decision_request",
            action_needed="yes",
            urgency="high",
            acted_by_you="replied",
            confidence=0.9,
        ),
        notes="",
    )

    result = _classify_labeled_thread(
        thread_id="conv",
        triage=triage,
        sender_type="human_internal",
        labels_by_thread={"conv": record},
        classifier=None,
    )

    assert result == ("decision_request", 1.0, "manual")


def test_classify_labeled_thread_uses_model_when_confident() -> None:
    record = ThreadLabelRecord(
        thread_id="conv-1",
        message_id="msg-1",
        subject="Please approve contract renewal",
        sender="owner@example.com",
        sender_type="human_internal",
        received_at="2026-03-12T00:00:00+00:00",
        body_preview="Approve renewal",
        body_content="Please approve the contract renewal",
        thread_size=1,
        cluster_size=1,
        labels=ThreadLabels(
            thread_class="approval_request",
            action_needed="yes",
            urgency="high",
            acted_by_you="replied",
            confidence=0.9,
        ),
        notes="",
    )
    noise = ThreadLabelRecord(
        thread_id="conv-2",
        message_id="msg-2",
        subject="Daily sales report",
        sender="alerts@example.com",
        sender_type="automated_internal",
        received_at="2026-03-12T00:00:00+00:00",
        body_preview="report",
        body_content="daily report",
        thread_size=1,
        cluster_size=1,
        labels=ThreadLabels(
            thread_class="status_update",
            action_needed="no",
            urgency="low",
            acted_by_you="ignored",
            confidence=0.9,
        ),
        notes="",
    )
    decision = ThreadLabelRecord(
        thread_id="conv-3",
        message_id="msg-3",
        subject="Please share your thoughts",
        sender="peer@example.com",
        sender_type="human_internal",
        received_at="2026-03-12T00:00:00+00:00",
        body_preview="thoughts",
        body_content="Please share your thoughts on this plan",
        thread_size=1,
        cluster_size=1,
        labels=ThreadLabels(
            thread_class="decision_request",
            action_needed="yes",
            urgency="medium",
            acted_by_you="replied",
            confidence=0.9,
        ),
        notes="",
    )
    classifier = train_thread_classifier(
        [record, noise, decision, record, noise, decision, record, noise]
    )
    assert classifier is not None

    email = EmailMessage(
        **{
            **_email().__dict__,
            "conversation_id": "fresh",
            "subject": "Approve vendor contract renewal",
            "body_preview": "Please approve",
            "body_content": "Please approve the vendor contract renewal this week",
        }
    )
    result = _classify_labeled_thread(
        thread_id="fresh",
        triage=TriageResult(email, Badge.NONE, False, "summary"),
        sender_type="human_internal",
        labels_by_thread={},
        classifier=classifier,
    )

    assert result[0] == "approval_request"
    assert result[2] == "model"


def test_adjust_model_prediction_downgrades_shared_file_false_positive() -> None:
    email = EmailMessage(
        **{
            **_email().__dict__,
            "subject": "Katie shared a file with you",
            "body_preview": "invited you to edit a file",
            "body_content": "Katie invited you to edit a file and shared it with you",
        }
    )

    adjusted = _adjust_model_prediction(
        TriageResult(email, Badge.NONE, False, "summary"),
        "approval_request",
    )

    assert adjusted == "status_update"


def test_adjust_model_prediction_maps_renewal_reminder_to_contract() -> None:
    email = EmailMessage(
        **{
            **_email().__dict__,
            "subject": "Your subscription will renew soon",
            "body_preview": "will automatically renew",
            "body_content": "This is a reminder that your subscription will automatically renew",
        }
    )

    adjusted = _adjust_model_prediction(
        TriageResult(email, Badge.NONE, False, "summary"),
        "approval_request",
    )

    assert adjusted == "contract_or_renewal"


class _FakeEmailClient:
    def list_inbox(self, *, mailbox_filter: str | None, top: int, skip: int) -> list[EmailMessage]:
        return [_email()]

    def read_email(self, message_id: str) -> EmailMessage:
        return _email()


class _FakeSearchEmailClient(_FakeEmailClient):
    def search_emails(self, query: str, mailbox_filter: str | None = None) -> list[EmailMessage]:
        return [_email()]


class _FakeTriageEmailClient(_FakeEmailClient):
    def read_email(self, message_id: str) -> EmailMessage:
        if message_id == "msg-3":
            return EmailMessage(
                **{
                    **_email().__dict__,
                    "id": "msg-3",
                    "conversation_id": "conv-2",
                    "subject": "Contract renewal approval",
                    "body_content": (
                        "<untrusted-email-content>Please approve renewal"
                        "</untrusted-email-content>"
                    ),
                }
            )
        return _email()


class _FakeAttachmentEmailClient(_FakeEmailClient):
    def download_attachments(self, message_id: str):
        from ms365_toolkit.client.email import DownloadedAttachment

        return (
            DownloadedAttachment(
                attachment_id="att-1",
                name="report.txt",
                content_type="text/plain",
                size=5,
                content=b"hello",
                is_inline=False,
            ),
        )


class _FakeMailboxIndex:
    def sync(self, email_client: object, *, batch_size: int = 100, max_pages: int = 10) -> int:
        return 0

    def recent_threads(self, *, limit: int = 20) -> list[object]:
        class Thread:
            def __init__(self, conversation_id: str, latest_message_id: str) -> None:
                self.conversation_id = conversation_id
                self.latest_message_id = latest_message_id

        return [Thread("conv", "msg-1"), Thread("conv-2", "msg-3")]


class _FakeCalendarClient:
    def list_events(self, *, start: datetime, end: datetime) -> list[CalendarEvent]:
        return [_event()]


def _email() -> EmailMessage:
    return EmailMessage(
        id="msg-1",
        subject="Hello",
        sender="sender@example.com",
        to=("to@example.com",),
        cc=(),
        bcc=(),
        body_preview="Preview",
        body_content="<untrusted-email-content>Body</untrusted-email-content>",
        received_at=datetime(2026, 3, 12, tzinfo=UTC),
        is_read=False,
        is_flagged=False,
        importance="normal",
        has_attachments=False,
        attachments=(),
        conversation_id="conv",
        folder_id="folder",
    )


def _event() -> CalendarEvent:
    return CalendarEvent(
        id="event-1",
        subject="Planning",
        start=datetime(2026, 3, 12, 15, tzinfo=UTC),
        end=datetime(2026, 3, 12, 16, tzinfo=UTC),
        timezone="UTC",
        location="Room A",
        body_content="Agenda",
        attendees=(Attendee("a@example.com", "A", "accepted", "required"),),
        is_online_meeting=False,
        is_cancelled=False,
        importance="high",
        categories=("Work",),
        recurrence=None,
        organizer="owner@example.com",
        response_status="accepted",
        calendar_id="calendar-1",
    )


def _config():
    class StubAuth:
        tenant_id = "tenant"
        client_id = "client"

    class StubUser:
        endpoint = "me"
        user_principal_name = "owner@example.com"
        timezone = "UTC"

    class StubSafety:
        domain_allowlist = (".example.com",)

    class StubVip:
        emails = ()
        domains = ()

    class StubIntelligence:
        critical_keywords = ()
        noise_keywords = ()
        action_keywords = ()

    class StubConfig:
        profile = "default"
        auth = StubAuth()
        user = StubUser()
        safety = StubSafety()
        vip = StubVip()
        intelligence = StubIntelligence()
        config_hash = "hash"
        config_mtime = 0.0
        config_path = None

    return StubConfig()
