from __future__ import annotations

import json
import os
from typing import TYPE_CHECKING, Any

import msal

from ms365_toolkit.auth.credentials import (
    READ_CACHE_KEY,
    READ_ENV_KEY,
    SERVICE_NAME,
    WRITE_CACHE_KEY,
    WRITE_ENV_KEY,
    CredentialStore,
)
from ms365_toolkit.config.loader import load_config, write_config_text

if TYPE_CHECKING:
    from pathlib import Path

    import pytest


def test_load_cache_prefers_explicit_over_keyring_and_env(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    backend = _FakeKeyring({(SERVICE_NAME, READ_CACHE_KEY.format(profile="default")): "keyring"})
    monkeypatch.setenv(READ_ENV_KEY.format(profile="DEFAULT"), "env")
    store = CredentialStore(profile="default", keyring_backend=backend)

    cache = store.load_cache(kind="read", explicit_value=_serialized_cache("explicit"))

    assert json.loads(cache.serialize()) == json.loads(_serialized_cache("explicit"))


def test_load_cache_falls_back_to_env_for_read(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv(READ_ENV_KEY.format(profile="DEFAULT"), _serialized_cache("env"))
    store = CredentialStore(profile="default", keyring_backend=_FakeKeyring())

    cache = store.load_cache(kind="read")

    assert json.loads(cache.serialize()) == json.loads(_serialized_cache("env"))


def test_write_cache_does_not_read_env_by_default(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(WRITE_ENV_KEY.format(profile="DEFAULT"), _serialized_cache("env"))
    store = CredentialStore(profile="default", keyring_backend=_FakeKeyring())

    cache = store.load_cache(kind="write", allow_env=False)

    assert cache.serialize() == "{}"


def test_save_cache_writes_keyring_and_only_exports_write_env_when_allowed(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    backend = _FakeKeyring()
    store = CredentialStore(profile="default", keyring_backend=backend)
    read_cache = _cache("read")
    write_cache = _cache("write")

    monkeypatch.setenv(READ_ENV_KEY.format(profile="DEFAULT"), "existing-read-env")
    monkeypatch.delenv(WRITE_ENV_KEY.format(profile="DEFAULT"), raising=False)

    store.save_cache(kind="read", cache=read_cache)
    store.save_cache(kind="write", cache=write_cache, allow_env_write=True)

    assert json.loads(
        backend.values[(SERVICE_NAME, READ_CACHE_KEY.format(profile="default"))]
    ) == json.loads(_serialized_cache("read"))
    assert json.loads(
        backend.values[(SERVICE_NAME, WRITE_CACHE_KEY.format(profile="default"))]
    ) == json.loads(_serialized_cache("write"))
    assert os.environ[READ_ENV_KEY.format(profile="DEFAULT")] == "existing-read-env"
    assert json.loads(os.environ[WRITE_ENV_KEY.format(profile="DEFAULT")]) == json.loads(
        _serialized_cache("write")
    )


def test_delete_cache_does_not_suppress_unexpected_keyring_errors() -> None:
    import pytest

    backend = _RaisingDeleteKeyring(RuntimeError())
    store = CredentialStore(profile="default", keyring_backend=backend)

    with pytest.raises(RuntimeError):
        store.delete_cache(kind="read")


def test_save_cache_does_not_suppress_unexpected_delete_errors() -> None:
    import pytest

    store = CredentialStore(profile="default", keyring_backend=_SetFailingKeyring(RuntimeError()))

    with pytest.raises(RuntimeError):
        store.save_cache(kind="read", cache=_cache("read"))


def test_scopes_for_users_endpoint_uses_shared_scopes(tmp_path: Path) -> None:
    config = _config(tmp_path, endpoint="users")
    store = CredentialStore(profile="default", keyring_backend=_FakeKeyring())

    assert store.scopes_for(config, write=False) == frozenset(
        {"Mail.Read.Shared", "Calendars.Read.Shared"}
    )
    assert store.scopes_for(config, write=True) == frozenset(
        {"Mail.ReadWrite.Shared", "Mail.Send.Shared", "Calendars.ReadWrite.Shared"}
    )


class _FakeKeyring:
    def __init__(self, initial: dict[tuple[str, str], str] | None = None) -> None:
        self.values = initial or {}

    def get_password(self, service_name: str, username: str) -> str | None:
        return self.values.get((service_name, username))

    def set_password(self, service_name: str, username: str, password: str) -> None:
        self.values[(service_name, username)] = password

    def delete_password(self, service_name: str, username: str) -> None:
        self.values.pop((service_name, username), None)


class _RaisingDeleteKeyring(_FakeKeyring):
    def __init__(self, error: Exception) -> None:
        super().__init__()
        self.error = error

    def delete_password(self, service_name: str, username: str) -> None:
        raise self.error


class _SetFailingKeyring(_FakeKeyring):
    def __init__(self, delete_error: Exception) -> None:
        super().__init__()
        self.delete_error = delete_error

    def set_password(self, service_name: str, username: str, password: str) -> None:
        from keyring.errors import PasswordSetError

        if (service_name, username) in self.values:
            self.values[(service_name, username)] = password
            return
        self.values[(service_name, username)] = "stale"
        raise PasswordSetError("failed")

    def delete_password(self, service_name: str, username: str) -> None:
        raise self.delete_error


def _cache(label: str) -> msal.SerializableTokenCache:
    cache = msal.SerializableTokenCache()
    cache.deserialize(_serialized_cache(label))
    return cache


def _serialized_cache(label: str) -> str:
    return f'{{"AccessToken":{{"token":{{"secret":"{label}"}}}}}}'


def _config(tmp_path: Path, *, endpoint: str) -> Any:
    config_path = tmp_path / "default" / "config.toml"
    content = f"""
[auth]
tenant_id = "tenant"
client_id = "client"

[user]
endpoint = "{endpoint}"
user_principal_name = "owner@example.com"
timezone = "America/Chicago"

[safety]
domain_allowlist = ["example.com"]
folder_allowlist = ["Archive"]
send_email_per_hour = 5
send_email_per_day = 20
draft_email_per_hour = 10
draft_email_per_day = 30
reply_email_per_hour = 5
reply_email_per_day = 20
forward_email_per_hour = 5
forward_email_per_day = 20
move_email_per_hour = 20
flag_email_per_hour = 50
create_event_per_hour = 5
create_event_per_day = 20
update_event_per_hour = 10
respond_event_per_hour = 10

[vip]
emails = []
domains = []

[intelligence]
critical_keywords = []
noise_keywords = []
action_keywords = []
""".strip()
    write_config_text(config_path, content)
    return load_config(base_dir=tmp_path)
