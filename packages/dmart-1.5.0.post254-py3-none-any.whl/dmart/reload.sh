#!/bin/bash

declare -i RESULT=0
source ./login_creds.sh
RESULT+=$?

RESULT+=$?
PORT="$(./get_settings.py | jq -r .listening_port)"
RESULT+=$?
# APP_URL="$(./get_settings.py | jq -r .app_url)"
APP_URL="http://localhost:$PORT"

(which systemctl > /dev/null && systemctl --user list-unit-files dmart.service > /dev/null  && systemctl --user restart dmart.service) || \
( [[ -x "/etc/init.d/dmart" ]] && /etc/init.d/dmart restart )
RESULT+=$?
sleep 2
# RESP=$(curl --write-out '%{http_code}' --silent --output /dev/null  "${APP_URL}")
RESP="000"
COUNTER=0
while [ $RESP -ne "200" ]; do
  sleep 1
  COUNTER=$((COUNTER+1))
  echo "Waiting for the server to come up ${RESP} ${COUNTER} seconds"
  RESP=$(curl --write-out '%{http_code}' --silent --connect-timeout 0.5 --output /dev/null  "${APP_URL}")
  [[ $COUNTER -ge 30 ]] && break
done
sleep 2

TOKEN=$(curl -s "${APP_URL}/user/login" -H 'Content-Type: application/json' -d "${SUPERMAN}" | jq -r '.records[0].attributes.access_token')
curl -s -H "Authorization: Bearer ${TOKEN}" -H "$CT" $APP_URL/user/profile | jq -r '.status'
RESULT+=$?

sleep 1
curl -s -H "Authorization: Bearer ${TOKEN}" "${APP_URL}/user/profile" | jq '.records[0].attributes.roles'
RESULT+=$?

echo "Sum of exist codes = $RESULT" 
exit $RESULT
