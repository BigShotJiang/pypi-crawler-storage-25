import{w as s}from"./svelte-Dxu6Fq_F.js";const o=s(null);export{o as s};
