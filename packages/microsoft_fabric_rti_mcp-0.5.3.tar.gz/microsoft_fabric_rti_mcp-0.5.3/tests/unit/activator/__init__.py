# Unit tests for activator module
