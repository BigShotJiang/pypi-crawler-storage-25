import base64
import json
from typing import Any, cast

from fabric_rti_mcp.config import GlobalFabricRTIConfig
from fabric_rti_mcp.fabric_api_http_client import FabricHttpClientCache
from fabric_rti_mcp.services.activator import activator_entity_generators

# Microsoft Fabric API configuration
FABRIC_CONFIG = GlobalFabricRTIConfig.from_env()


class ActivatorService:
    """Service class for Fabric Activator operations."""

    # Custom headers for Activator service tracking
    _ACTIVATOR_HEADERS = {"x-ms-operation-name": "rti-mcp-py"}

    def _make_request(
        self, method: str, endpoint: str, payload: dict[str, Any] | None = None, timeout: int = 30
    ) -> dict[str, Any]:
        return FabricHttpClientCache.get_client().make_request(
            method, endpoint, payload, timeout, extra_headers=self._ACTIVATOR_HEADERS
        )

    def activator_list_artifacts(self, workspace_id: str) -> list[dict[str, Any]]:
        """
        Use this tool to list all Activator artifacts in a workspace.

        :param workspace_id: The workspace ID (UUID)
        :return: List of activator artifacts
        """
        endpoint = f"/workspaces/{workspace_id}/items"
        result = self._make_request("GET", endpoint)

        # Filter only Reflex (Activator) items if the result contains a list
        if "value" in result and isinstance(result["value"], list):
            activators = [
                cast(dict[str, Any], item)
                for item in result["value"]  # type: ignore
                if isinstance(item, dict) and item.get("type") == "Reflex"  # type: ignore
            ]
            return activators

        return [result]

    def activator_create_trigger(
        self,
        workspace_id: str,
        trigger_name: str,
        kql_cluster_url: str,
        kql_database: str,
        kql_query: str,
        alert_recipient: str,
        alert_message: str,
        alert_headline: str,
        alert_type: str = "teams",
        kql_polling_frequency_minutes: int = 5,
        artifact_id: str | None = None,
    ) -> dict[str, Any]:
        """
        Use this tool create an alert that will fire when the source generates data.

        :param workspace_id: The workspace ID (UUID)
        :param trigger_name: Name of the trigger
        :param kql_cluster_url: The KQL cluster URL
        :param kql_database: The KQL database name
        :param kql_query: The KQL query to monitor. The query MUST be appropriate for the schema of the underlying
            data, otherwise the alert will not function correctly
        :param alert_recipient: Email address of the alert recipient
        :param alert_message: Alert message for the trigger
        :param alert_headline: Alert headline for the trigger
        :param alert_type: Type of alert - "teams" or "email" (defaults to "teams")
        :param kql_polling_frequency_minutes: Polling frequency in minutes. Must be one of: 5, 15, 60, 180, 360, 720,
            1440 (defaults to 5)
        :param artifact_id: If specified, the trigger will be created in the specified Activator artifact.
            If left blank, a new Activator artifact will be created.
        :return: Created trigger details:
            * url: URL back to the trigger in Fabric UI for further management
            * id: Artifact ID if a new one was created
            * displayName: Name of newly created trigger

        Critical:
        * This API call will NOT tell the caller if a KQL query is used which does not match the source data schema,
        so any KQL query should be double-checked upfront.
        """
        (container_entity, container_guid) = activator_entity_generators.create_container_entity(trigger_name)

        (source_entity, source_guid) = activator_entity_generators.create_kql_source_entity(
            trigger_name,
            polling_frequency_minutes=kql_polling_frequency_minutes,
            kql_query=kql_query,
            database=kql_database,
            cluster_hostname=kql_cluster_url,
            container_id=container_guid,
            workspace_id=workspace_id,
        )

        return self._create_trigger_with_source(
            workspace_id=workspace_id,
            trigger_name=trigger_name,
            container_entity=container_entity,
            container_guid=container_guid,
            source_entity=source_entity,
            source_guid=source_guid,
            alert_recipient=alert_recipient,
            alert_type=alert_type,
            artifact_id=artifact_id,
            alert_message=alert_message,
            alert_headline=alert_headline,
        )

    def _create_trigger_with_source(
        self,
        workspace_id: str,
        trigger_name: str,
        container_entity: dict[str, Any],
        container_guid: str,
        source_entity: dict[str, Any],
        source_guid: str,
        alert_recipient: str,
        alert_type: str,
        alert_message: str,
        alert_headline: str,
        artifact_id: str | None = None,
    ) -> dict[str, Any]:
        event_and_rule_entities = activator_entity_generators.create_simple_event_rule_entities(
            trigger_name,
            container_id=container_guid,
            source_id=source_guid,
            message=alert_message,
            headline=alert_headline,
            alert_recipient=alert_recipient,
            alert_type=alert_type,
        )

        full_entity_list = [*event_and_rule_entities, container_entity, source_entity]

        if artifact_id is None:
            full_payload = self._get_full_payload(full_entity_list, trigger_name)
            return self._create_new_artifact(workspace_id, full_payload)
        else:
            return self._add_trigger_to_existing_artifact(workspace_id, artifact_id, full_entity_list)

    def _add_trigger_to_existing_artifact(
        self, workspace_id: str, artifact_id: str, entity_list: list[dict[str, Any]]
    ) -> dict[str, Any]:
        try:
            # Step 1: Get existing payload
            existing_payload_result = self._get_existing_payload(workspace_id, artifact_id)

            # Step 2: Create combined entities
            combined_entities = self._create_combined_entities(entity_list, existing_payload_result)

            # Step 3: Update item with combined entities
            return self._update_item(workspace_id, artifact_id, combined_entities, existing_payload_result)
        except Exception as e:
            return {"error": str(e)}

    def _get_existing_payload(self, workspace_id: str, artifact_id: str) -> dict[str, Any]:
        # Get the existing artifact definition
        get_definition_endpoint = f"/workspaces/{workspace_id}/reflexes/{artifact_id}/getDefinition"
        existing_definition_response = self._make_request("POST", get_definition_endpoint, {})

        if existing_definition_response.get("error"):
            raise Exception(f"Failed to get existing definition: {existing_definition_response.get('error')}")

        return existing_definition_response

    def _create_combined_entities(
        self, new_entities: list[dict[str, Any]], api_response: dict[str, Any]
    ) -> list[dict[str, Any]]:
        # Extract the ReflexEntities.json part from the API response
        existing_definition = api_response.get("definition", {})
        existing_parts = existing_definition.get("parts", [])

        reflex_entities_part = None
        for part in existing_parts:
            if part.get("path") == "ReflexEntities.json":
                reflex_entities_part = part
                break

        if not reflex_entities_part:
            raise Exception("ReflexEntities.json not found in API response")

        # Decode the existing base64 payload
        try:
            existing_payload_b64 = reflex_entities_part.get("payload", "")
            existing_entities_json = base64.b64decode(existing_payload_b64).decode("utf-8")
            existing_entities = json.loads(existing_entities_json)
        except Exception as e:
            raise Exception(f"Failed to decode existing entities: {str(e)}")

        # Combine the existing entities with the new entities
        combined_entities: list[dict[str, Any]] = existing_entities + new_entities

        return combined_entities

    def _update_item(
        self,
        workspace_id: str,
        artifact_id: str,
        combined_entities: list[dict[str, Any]],
        existing_payload_result: dict[str, Any],
    ) -> dict[str, Any]:
        # Get the existing parts structure (we need this to preserve other parts like .platform)
        existing_definition = existing_payload_result.get("definition", {})
        existing_parts = existing_definition.get("parts", [])

        # Create the updated payload
        combined_entities_json = json.dumps(combined_entities)
        combined_entities_b64 = base64.b64encode(combined_entities_json.encode("utf-8")).decode("utf-8")

        # Update the ReflexEntities.json part with combined entities
        updated_parts: list[dict[str, Any]] = []
        for part in existing_parts:
            if part.get("path") == "ReflexEntities.json":
                updated_part: dict[str, Any] = part.copy()
                updated_part["payload"] = combined_entities_b64
                updated_parts.append(updated_part)
            else:
                updated_parts.append(part)

        # Create the update payload
        update_payload: dict[str, Any] = {"definition": {"parts": updated_parts}}

        # Update the existing artifact
        update_endpoint = f"/workspaces/{workspace_id}/reflexes/{artifact_id}/updateDefinition"
        result = self._make_request("POST", update_endpoint, update_payload)

        if result.get("error"):
            raise Exception(f"Failed to update artifact: {result.get('error')}")

        # augment result with a url back to the artifact
        result["url"] = f"{FABRIC_CONFIG.fabric_base_url}/groups/{workspace_id}/reflexes/{artifact_id}"

        return result

    def _create_new_artifact(self, workspace_id: str, full_payload: dict[str, Any]) -> dict[str, Any]:
        endpoint = f"/workspaces/{workspace_id}/reflexes"

        result = self._make_request("POST", endpoint, full_payload)

        if not result.get("error"):
            # augment result with a url back to the artifact
            result["url"] = f"{FABRIC_CONFIG.fabric_base_url}/groups/{workspace_id}/reflexes/{result.get('id', '')}"

        return result

    def _get_full_payload(self, entity_list: list[dict[str, Any]], trigger_name: str) -> dict[str, Any]:
        reflex_json = json.dumps(entity_list)
        reflex_b64 = base64.b64encode(reflex_json.encode("utf-8")).decode("utf-8")
        schema = (
            "https://developer.microsoft.com/json-schemas/fabric/gitIntegration/platformProperties/2.0.0/schema.json"
        )
        platform_data: dict[str, Any] = {
            "$schema": schema,
            "metadata": {"type": "Reflex", "displayName": f"{trigger_name}", "description": f"{trigger_name}"},
            "config": {"version": "2.0", "logicalId": "4042fb10-1349-b4c0-4361-514b6b19c1fe"},
        }
        platform_b64 = base64.b64encode(json.dumps(platform_data).encode("utf-8")).decode("utf-8")

        payload: dict[str, Any] = {
            "displayName": trigger_name,
            "description": trigger_name,
            "definition": {
                "parts": [
                    {"path": "ReflexEntities.json", "payload": reflex_b64, "payloadType": "InlineBase64"},
                    {"path": ".platform", "payload": platform_b64, "payloadType": "InlineBase64"},
                ]
            },
        }

        return payload


DEFAULT_ACTIVATOR_SERVICE = ActivatorService()
