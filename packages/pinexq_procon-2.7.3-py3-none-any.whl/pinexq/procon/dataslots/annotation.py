import dataclasses
import logging
import warnings
from dataclasses import dataclass, field
from pathlib import Path
from typing import IO, Any, Callable, Literal, TypeAlias, Self

from ..core.types import UNSET, UNSETTYPE
from ..dataslots.datatypes import MediaTypes, SlotType


log = logging.getLogger(__name__)

DATASLOT_ANNOTATION_NAME = "__dataslots__"
RETURN_SLOT_NAME = "__returns__"

FileMode: TypeAlias = Literal["r", "rb", "w", "wb"]
ContentEncoding: TypeAlias = Literal["text", "binary"]
ReaderType: TypeAlias = Callable[[IO], Any]
WriterType: TypeAlias = Callable[[IO, Any], None]
CollectionReaderType: TypeAlias = Callable[[list[IO]], Any]
CollectionWriterType: TypeAlias = Callable[[[IO], Any], None]

_warn_skips = (str(Path(__file__).parent.parent),)

def _emit_external_warning(msg: str) -> None:
    """Emit a warning message with the source being the first stack level outside this module."""
    # log.warning(msg)
    warnings.warn(
        msg,
        # skip_file_prefixes=_warn_skips,  # skip all stack levels inside this module
        # Todo: The actual frame is not accessible; Find a workaround?
        # (maybe just output function name and parameter and the code pos doesn't really matter)
        stacklevel=8,
    )  # ty:ignore[no-matching-overload]


_TEXT_SUFFIXES = frozenset({"json", "xml", "csv", "yaml"})
_BINARY_SUFFIXES = frozenset({"zip", "gzip", "cbor"})


def _infer_encoding_from_suffix(media_type: str) -> ContentEncoding | None:
    """Infer content encoding from a MIME type's structured syntax suffix.

    Returns ``"text"`` or ``"binary"`` based on the suffix, or ``None`` if the
    suffix is absent or unrecognized.
    """
    plus_index = media_type.rfind("+")
    if plus_index == -1:
        return None
    suffix = media_type[plus_index + 1:]
    if suffix in _TEXT_SUFFIXES:
        return "text"
    if suffix in _BINARY_SUFFIXES:
        return "binary"
    return None


_MEDIA_TYPE_ENCODINGS: dict[str, ContentEncoding] = {
    MediaTypes.OCTETSTREAM: "binary",
    MediaTypes.JSON: "text",
    MediaTypes.FORMDATA: "text",
    MediaTypes.SIREN: "text",
    MediaTypes.XML: "text",
    MediaTypes.ZIP: "binary",
    MediaTypes.PDF: "binary",
    MediaTypes.TEXT: "text",
    MediaTypes.HTML: "text",
    MediaTypes.CSV: "text",
    MediaTypes.SVG: "text",
    MediaTypes.PNG: "binary",
    MediaTypes.JPEG: "binary",
    MediaTypes.BMP: "binary",
    MediaTypes.YAML: "text",
    MediaTypes.PARQUET: "binary",
    MediaTypes.WORKFLOW_DEFINITION: "text",
    MediaTypes.WORKFLOW_REPORT: "text",
}


def _to_file_mode(is_write: bool, encoding: ContentEncoding) -> FileMode:
    if is_write:
        return "wb" if encoding == "binary" else "w"
    return "rb" if encoding == "binary" else "r"


def media_type_2_file_mode(media_type: str, is_write: bool = False) -> FileMode:
    # Known media type from the enum
    encoding = _MEDIA_TYPE_ENCODINGS.get(media_type, None)
    if encoding is not None:
        return _to_file_mode(is_write, encoding)

    # Unknown media type — try to infer from structured syntax suffix
    encoding = _infer_encoding_from_suffix(media_type)
    if encoding is not None:
        return _to_file_mode(is_write, encoding)

    # No suffix or unrecognized suffix — fall back to binary with warning
    log.warning(
        f"Unknown media type {media_type} will assume binary format. "
        f"If this does not fit, please set the mode on the dataslot explicitly."
    )
    return _to_file_mode(is_write, encoding="binary")


@dataclass
class dataslot:  # noqa: N801
    """Decorator to attach metadata for a dataslot to a function.

    You can use the general Dataslot decorator `@dataslot` to parametrize all possible options
    manually or use the specialized constructors, which offer default settings and only the
    necessary options for every dataslot type.

    The available constructors are:
        - `dataslot.input`
        - `dataslot.output`
        - `dataslot.input_collection`
        - `dataslot.output_collection`
        - `dataslot.returns`
        - `dataslot.returns_collection`

    Attributes:
        name: The name has to match the function parameter that will be used as dataslot.
        alias: The name for this dataslot presented in the manifest and expected in a job offer.
        slot_type: Whether this dataslot is an input, output, or return slot.
        title: Brief description of the dataslot.
        description: More detailed description of the dataslot.
        media_type: The media type as `MediaTypes` Enum.
        reader: A callable accepting a file object as a parameter and returning the datatype
            expected by the functions' parameter.
        writer: A callable accepting a file object and data to be written as a parameter.
        collection_reader: A callable accepting a list of file objects and returning the
            datatype expected by the functions' parameter. Used for collection dataslots.
        collection_writer: A callable accepting a list of file objects and data to be
            written as parameters. Used for collection dataslots.
        mode: File mode of the IO object representing the dataslot. Usually set by the constructor
            to a reasonable value ('r' for inputs, 'w' for outputs, 'b' for binary).
        dtype: The annotated type of implicitly defined dataslots. Set by the introspection internally.
        collection: Whether the dataslot accepts more than one file as slots. (default: False)
        min_slots: Minimum number of slots required for a collection dataslot. (default: 1)
        max_slots: Maximum number of slots allowed for a collection dataslot. `None` means
            unlimited. Defaults to `min_slots` if left unset.
    """

    name: str
    alias: str | None = field(default=None, kw_only=True)
    slot_type: SlotType = field(default=SlotType.INPUT, kw_only=True)
    title: str = field(default_factory=str, kw_only=True)
    description: str = field(default_factory=str, kw_only=True)
    media_type: str = field(default=MediaTypes.OCTETSTREAM, kw_only=True)
    reader: ReaderType | None = field(default=None, kw_only=True)
    writer: WriterType | None = field(default=None, kw_only=True)
    collection_reader: CollectionReaderType | None = field(default=None, kw_only=True)
    collection_writer: CollectionWriterType | None = field(default=None, kw_only=True)
    mode: FileMode | None = field(default=None, kw_only=True)
    dtype: type | None = field(default=None, kw_only=True)
    collection: bool = field(default=False, kw_only=True)
    min_slots: int | UNSETTYPE = field(default=UNSET, kw_only=True)
    max_slots: int | None | UNSETTYPE = field(default=UNSET, kw_only=True)
    _bare_warning: bool = field(default=True, kw_only=True)

    def __post_init__(self):
        if self._bare_warning:
            _emit_external_warning(
                f"Usage of dataslot '{self.name}' without proper decorator is strongly discouraged;"
                " please use e.g. @dataslot.input() instead!",
            )

        if self.mode is None:
            self.mode = "r"  # needed for backwards compatibility

        if self.min_slots is UNSET:
            self.min_slots = 1
        if self.max_slots is UNSET:
            self.max_slots = self.min_slots
            if self.min_slots != 1:
                _emit_external_warning("Dataslot attribute 'max_slots' is unset, defaulting to min_slots.")
        if (self.max_slots is not None) and (self.min_slots > self.max_slots):
            raise ValueError("Dataslot attribute 'min_slots' must be smaller than 'max_slots'!")

        # n.b. we treat min_slots=0 as a collection, because otherwise it is not clear how to handle no IOs.
        if self.min_slots != 1 or self.max_slots != 1:
            self.collection = True

        if (self.collection_reader or self.collection_writer) and not self.collection:
            raise ValueError(
                "'collection_reader' and '*_writer' can only be used for collection-DataSlots"
                " (when the parameter 'collection=True')!"
            )

    @classmethod
    def input(
        cls,
        name: str,
        title: str = "",
        description: str = "",
        media_type: MediaTypes = MediaTypes.OCTETSTREAM,
        mode: FileMode | None = None,
        alias: str | None = None,
        reader: ReaderType | None = None,
        dtype: type | None = None,
    ) -> Self:
        """Define the parameter `name` as input dataslot.

        Attributes:
            name: The name has to match the function parameter that will be used as dataslot.
            alias: The name for this dataslot presented in the manifest and expected in a job offer.
            title: Brief description of the dataslot.
            description: More detailed description of the dataslot.
            media_type: The media type as `MediaTypes` Enum.
            reader: A callable accepting a file object as a parameter and returning the datatype
                expected by the functions' parameter.
            mode: File mode of the IO object representing the dataslot. Usually set by the constructor
                to a reasonable value ('r' for inputs, 'w' for outputs, 'b' for binary).
            dtype: The annotated type of implicitly defined dataslots. Set by the introspection internally.
        """
        # The typechecker will complain that `_mode` could be None in the return statement below, which can't be.
        _mode = media_type_2_file_mode(media_type, is_write=False) if mode is None else mode
        # Using the following if/else clause, it's recognized correctly, even though it's functionally the same.
        # if mode is None:
        #     _mode = media_type_2_file_mode(media_type, is_write=False)
        # else:
        #     _mode = mode
        return cls(
            name,
            slot_type=SlotType.INPUT,
            title=title,
            description=description,
            media_type=media_type,
            mode=_mode,
            alias=alias,
            reader=reader,
            dtype=dtype,
            min_slots=1,
            max_slots=1,
            _bare_warning=False
        )

    @classmethod
    def input_collection(
        cls,
        name: str,
        alias: str | None = None,
        title: str = "",
        description: str = "",
        media_type: MediaTypes = MediaTypes.OCTETSTREAM,
        mode: FileMode | None = None,
        collection_reader: CollectionReaderType | None = None,
        dtype: type | None = None,
        min_slots: int | UNSETTYPE = UNSET,
        max_slots: int | None | UNSETTYPE = UNSET,
    ) -> Self:
        """Define the input dataslot as a collection of files.

        Attributes:
            name: The name has to match the function parameter that will be used as dataslot.
            alias: The name for this dataslot presented in the manifest and expected in a job offer.
            title: Brief description of the dataslot.
            description: More detailed description of the dataslot.
            media_type: The media type as `MediaTypes` Enum.
            mode: File mode of the IO object representing the dataslot. Usually set by the constructor
                to a reasonable value ('r' for inputs, 'w' for outputs, 'b' for binary).
            collection_reader: A callable accepting a list of file objects and returning the
                datatype expected by the functions' parameter.
            dtype: The annotated type of implicitly defined dataslots. Set by the introspection internally.
            min_slots: Minimum number of slots required for the collection. Defaults to 0.
            max_slots: Maximum number of slots allowed for the collection. None means unlimited. Defaults to None.
        """
        _mode = media_type_2_file_mode(media_type, is_write=False) if mode is None else mode
        if min_slots == UNSET:
            min_slots = 0
        if max_slots == UNSET:
            max_slots = None
        return cls(
            name,
            slot_type=SlotType.INPUT,
            title=title,
            description=description,
            media_type=media_type,
            mode=_mode,  # see comment in input()
            alias=alias,
            collection_reader=collection_reader,
            dtype=dtype,
            min_slots=min_slots,
            max_slots=max_slots,
            _bare_warning=False
        )

    @classmethod
    def output(
        cls,
        name: str,
        title: str = "",
        description: str = "",
        media_type: MediaTypes = MediaTypes.OCTETSTREAM,
        mode: FileMode | None = None,
        alias: str | None = None,
        writer: WriterType | None = None,
        dtype: type | None = None,
    ) -> Self:
        """Define the parameter `name` as output dataslot.

        Attributes:
            name: The name has to match the function parameter that will be used as dataslot.
            alias: The name for this dataslot presented in the manifest and expected in a job offer.
            title: Brief description of the dataslot.
            description: More detailed description of the dataslot.
            media_type: The media type as `MediaTypes` Enum.
            writer: A callable accepting a file object and data to be written as a parameter.
            mode: File mode of the IO object representing the dataslot. Usually set by the constructor
                to a reasonable value ('r' for inputs, 'w' for outputs, 'b' for binary).
            dtype: The annotated type of implicitly defined dataslots. Set by the introspection internally.
        """
        _mode = media_type_2_file_mode(media_type, is_write=True) if mode is None else mode
        return cls(
            name,
            slot_type=SlotType.OUTPUT,
            title=title,
            description=description,
            media_type=media_type,
            mode=_mode,  # see comment in input()
            alias=alias,
            writer=writer,
            dtype=dtype,
            min_slots=1,
            max_slots=1,
            _bare_warning=False
        )

    @classmethod
    def output_collection(
        cls,
        name: str,
        title: str = "",
        description: str = "",
        media_type: MediaTypes = MediaTypes.OCTETSTREAM,
        mode: FileMode | None = None,
        alias: str | None = None,
        collection_writer: CollectionWriterType | None = None,
        dtype: type | None = None,
        min_slots: int | UNSETTYPE = UNSET,
        max_slots: int | None | UNSETTYPE = UNSET,
    ) -> Self:
        """Define the output dataslot as a collection of files.

        Attributes:
            name: The name has to match the function parameter that will be used as dataslot.
            alias: The name for this dataslot presented in the manifest and expected in a job offer.
            title: Brief description of the dataslot.
            description: More detailed description of the dataslot.
            media_type: The media type as `MediaTypes` Enum.
            mode: File mode of the IO object representing the dataslot. Usually set by the constructor
                to a reasonable value ('r' for inputs, 'w' for outputs, 'b' for binary).
            collection_writer: A callable accepting a list of file objects and data to be
                written as parameters.
            dtype: The annotated type of implicitly defined dataslots. Set by the introspection internally.
            min_slots: Minimum number of slots required for the collection. Defaults to 1.
            max_slots: Maximum number of slots allowed for the collection. None means unlimited. Defaults to min_slots.
        """
        _mode = media_type_2_file_mode(media_type, is_write=True) if mode is None else mode
        if min_slots == UNSET:
            min_slots = 1
        if max_slots == UNSET:
            max_slots = min_slots
            _emit_external_warning(
                f"Unconfigured parameter 'max_slots' for output collection '{name}';"
                f" defaulting to max_slots={min_slots}"
            )
        slot = cls(
            name,
            slot_type=SlotType.OUTPUT,
            title=title,
            description=description,
            media_type=media_type,
            mode=_mode,  # see comment in input()
            alias=alias,
            collection_writer=collection_writer,
            dtype=dtype,
            min_slots=min_slots,
            max_slots=max_slots,
            _bare_warning=False,
        )
        return slot

    @classmethod
    def returns(
        cls,
        title: str = "",
        description: str = "",
        alias: str | None = None,
        media_type: MediaTypes = MediaTypes.OCTETSTREAM,
        mode: FileMode | None = None,
        writer: WriterType | None = None,
        dtype: type | None = None,
    ) -> Self:
        """Define the return value of the function to be written to a dataslot.

        Attributes:
            title: Brief description of the dataslot.
            description: More detailed description of the dataslot.
            media_type: The media type as `MediaTypes` Enum.
            writer: A callable accepting a file object and data to be written as a parameter.
            mode: File mode of the IO object representing the dataslot. Usually set by the constructor
                to a reasonable value ('r' for inputs, 'w' for outputs, 'b' for binary).
            dtype: The annotated type of implicitly defined dataslots. Set by the introspection internally.
        """
        _mode = media_type_2_file_mode(media_type, is_write=True) if mode is None else mode
        return cls(
            RETURN_SLOT_NAME,
            slot_type=SlotType.RETURN,
            title=title,
            alias=alias,
            description=description,
            media_type=media_type,
            mode=_mode,  # see comment in input()
            writer=writer,
            dtype=dtype,
            min_slots=1,
            max_slots=1,
            _bare_warning=False
        )

    @classmethod
    def returns_collection(
        cls,
        title: str = "",
        description: str = "",
        alias: str | None = None,
        media_type: MediaTypes = MediaTypes.OCTETSTREAM,
        mode: FileMode | None = None,
        collection_writer: CollectionWriterType | None = None,
        dtype: type | None = None,
        min_slots: int | UNSETTYPE = UNSET,
        max_slots: int | None | UNSETTYPE = UNSET,
    ) -> Self:
        """Define that the return value of the function will be written to a return dataslot.

        Attributes:
            title: Brief description of the dataslot.
            description: More detailed description of the dataslot.
            alias: The name for this dataslot presented in the manifest and expected in a job offer.
            media_type: The media type as `MediaTypes` Enum.
            mode: File mode of the IO object representing the dataslot. Usually set by the constructor
                to a reasonable value ('r' for inputs, 'w' for outputs, 'b' for binary).
            collection_writer: A callable accepting a list of file objects and data to be
                written as parameters.
            dtype: The annotated type of implicitly defined dataslots. Set by the introspection internally.
            min_slots: Minimum number of slots required for the collection. Defaults to 1.
            max_slots: Maximum number of slots allowed for the collection. None means unlimited. Defaults to min_slots.
        """
        _mode = media_type_2_file_mode(media_type, is_write=True) if mode is None else mode
        warnings = []
        if min_slots == UNSET:
            min_slots = 1
        if max_slots == UNSET:
            max_slots = min_slots
            _emit_external_warning(
                f"Unconfigured parameter 'max_slots' for return slot collection;"
                f" defaulting to max_slots={min_slots}"
            )
        slot = cls(
            RETURN_SLOT_NAME,
            slot_type=SlotType.RETURN,
            title=title,
            description=description,
            alias=alias,
            mode=_mode,  # see comment in input()
            media_type=media_type,
            collection_writer=collection_writer,
            dtype=dtype,
            min_slots=min_slots,
            max_slots=max_slots,
            _bare_warning=False,
        )
        return slot

    # @classmethod
    # def watch(cls, name: str, **kwargs):
    #     """Watch the local filesystem and upload written files to this dataslot."""
    #     raise NotImplementedError()

    def __call__(self, function: Callable[[Any], Any]):
        """Called when used as a decorator to attach metadata to 'func'."""
        metadata = function.__dict__.setdefault(DATASLOT_ANNOTATION_NAME, {})
        if self.name in metadata:
            raise NameError(f"A dataslot with the name '{self.name}' is already defined on '{function.__name__}()'!")
        if (self.name == RETURN_SLOT_NAME) and (self.slot_type is not SlotType.RETURN):
            raise NameError(f"Invalid dataslot name. The name '{RETURN_SLOT_NAME}' is reserved for internal use.")
        metadata[self.name] = self
        return function

    def update(self, d: "dataslot") -> Self:
        """Update this dataslot with information from another dataslot."""
        if not isinstance(d, self.__class__):
            raise TypeError("Can only update with dataslots of the same type!")

        fields_with_default_value = {
            f.name  #
            for f in dataclasses.fields(d)
            if getattr(d, f.name) == f.default
        }
        set_fields = {
            name: value  #
            for name, value in dataclasses.asdict(d).items()
            if name not in fields_with_default_value
        }
        return dataclasses.replace(self, **set_fields)

    def __or__(self, other) -> Self:
        """Merge two objects by updating the current annotation with another annotation."""
        return self.update(other)


def get_dataslot_metadata(function: Callable[[Any], Any]) -> dict[str, dataslot]:
    """Retrieves dataslot metadata from a given function.

    Args:
        function: The function from which the dataslot metadata will be extracted.

    Returns:
        A dictionary containing metadata associated with dataslots in the function.
    """
    return getattr(function, DATASLOT_ANNOTATION_NAME, {})
