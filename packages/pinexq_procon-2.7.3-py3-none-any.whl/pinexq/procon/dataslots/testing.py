"""Testing utilities for DataSlots.

Provides `TestDataSlot` — a `DataSlot` backed by temporary files so that
Step functions using DataSlots can be called directly in unit tests without
the full CLI / worker machinery.
"""

import os
import tempfile
from pathlib import Path
from typing import Union

from .annotation import ReaderType, WriterType, media_type_2_file_mode
from .dataslots import DataSlot
from .datatypes import DataSlotDescription, MediaTypes, SlotDescription, SlotType


class TestDataSlot(DataSlot):
    """A DataSlot backed by temporary files for local testing.

    Allows calling Step functions that use DataSlots directly, without going
    through the full CLI / worker / RabbitMQ machinery.

    Examples::

        # --- Input: supply data inline ---
        ds = TestDataSlot(data='hello world')
        ds = TestDataSlot(data=b'\\x00\\x01', media_type=MediaTypes.OCTETSTREAM)

        # --- Input: point at existing files ---
        ds = TestDataSlot(files=['data.json'])

        # --- Input collection: multiple files ---
        ds = TestDataSlot(files=['a.txt', 'b.txt'])
        ds = TestDataSlot(data=['first', 'second'])

        # --- Output: write through the function, then read back ---
        ds_out = TestDataSlot.output()
        step.my_func(data='hello', out_blob=ds_out)
        written = ds_out.read_result()   # → 'hello'

        # --- Output collection ---
        ds_out = TestDataSlot.output(n_slots=3, media_type=MediaTypes.JSON)

        # --- Clean up temp files explicitly (optional; also auto-cleaned on GC) ---
        ds = TestDataSlot(data='hi')
        try:
            step.my_func(data_blob=ds)
        finally:
            ds.cleanup()
    """
    # Prevents pytest from mistaking this class for a test suite (its name starts with "Test").
    __test__ = False 

    _owned_paths: list[str]

    def __init__(
        self,
        data: Union[str, bytes, list[Union[str, bytes]], None] = None,
        files: Union[list[Union[str, Path]], None] = None,
        n_slots: int = 1,
        slot_type: SlotType = SlotType.INPUT,
        name: str = "test",
        media_type: MediaTypes = MediaTypes.TEXT,
        reader: ReaderType | None = None,
        writer: WriterType | None = None,
    ) -> None:
        """
        Args:
            data: String or bytes (or a list of them) to use as slot content.
                  Each item becomes one slot backed by a temp file.
            files: Existing file paths to use as slot URIs. No temp files are
                   created; the files are used as-is.
            n_slots: Number of empty temp-file slots to create when neither
                     ``data`` nor ``files`` is given (useful for output slots).
            slot_type: INPUT, OUTPUT, or RETURN. Defaults to INPUT.
            name: Internal slot name (only matters if you inspect the annotation).
            media_type: Controls the file-open mode ('r'/'rb'/'w'/'wb').
            reader: Custom deserializer passed through to the DataSlot annotation.
            writer: Custom serializer passed through to the DataSlot annotation.
        """
        self._owned_paths = []

        is_write = slot_type in (SlotType.OUTPUT, SlotType.RETURN)
        mode = media_type_2_file_mode(media_type, is_write=is_write)
        is_binary = "b" in mode

        if files is not None:
            slot_paths = [str(f) for f in files]
        elif data is not None:
            items: list[str | bytes] = [data] if isinstance(data, (str, bytes)) else list(data)
            slot_paths = []
            for item in items:
                if is_binary and isinstance(item, str):
                    item = item.encode()
                elif not is_binary and isinstance(item, bytes):
                    item = item.decode()
                tmp = tempfile.NamedTemporaryFile(
                    mode="wb" if is_binary else "w",
                    suffix=".tmp",
                    delete=False,
                )
                tmp.write(item)
                tmp.close()
                self._owned_paths.append(tmp.name)
                slot_paths.append(tmp.name)
        else:
            # Empty temp files — typical for output slots.
            for _ in range(n_slots):
                tmp = tempfile.NamedTemporaryFile(
                    mode="wb" if is_binary else "w",
                    suffix=".tmp",
                    delete=False,
                )
                tmp.close()
                self._owned_paths.append(tmp.name)
            slot_paths = list(self._owned_paths)

        n = len(slot_paths)
        from .annotation import dataslot  # local import avoids circular at module level

        description = DataSlotDescription(
            name=name,
            slots=[SlotDescription(uri=p, index=i) for i, p in enumerate(slot_paths)],
        )
        annotation = dataslot(
            name=name,
            slot_type=slot_type,
            media_type=media_type,
            mode=mode,
            reader=reader,
            writer=writer,
            min_slots=n,
            max_slots=n,
            _bare_warning=False,
        )
        super().__init__(description=description, annotation=annotation)

    # ------------------------------------------------------------------
    # Convenience constructor for output slots
    # ------------------------------------------------------------------

    @classmethod
    def output(
        cls,
        n_slots: int = 1,
        name: str = "test",
        media_type: MediaTypes = MediaTypes.TEXT,
        writer: WriterType | None = None,
    ) -> "TestDataSlot":
        """Create an output TestDataSlot backed by *n_slots* empty temp files.

        After the function under test has run, call :meth:`read_result` to
        retrieve what was written.
        """
        return cls(
            slot_type=SlotType.OUTPUT,
            n_slots=n_slots,
            name=name,
            media_type=media_type,
            writer=writer,
        )

    # ------------------------------------------------------------------
    # Reading back output data
    # ------------------------------------------------------------------

    def read_result(self) -> Union[str, bytes, list[Union[str, bytes]]]:
        """Return the content written to this slot's temp file(s).

        Returns:
            Content of the single temp file as ``str`` or ``bytes``, or a
            ``list`` thereof when the slot is a collection.
        """
        is_binary = "b" in self.annotation.mode
        results: list[str | bytes] = []
        for path in self._owned_paths:
            with open(path, "rb" if is_binary else "r") as f:
                results.append(f.read())
        return results[0] if len(results) == 1 else results

    # ------------------------------------------------------------------
    # Temp-file lifecycle
    # ------------------------------------------------------------------

    def cleanup(self) -> None:
        """Delete all temporary files owned by this instance."""
        for path in self._owned_paths:
            try:
                os.unlink(path)
            except (FileNotFoundError, OSError):
                pass
        self._owned_paths.clear()

    def __del__(self) -> None:
        self.cleanup()