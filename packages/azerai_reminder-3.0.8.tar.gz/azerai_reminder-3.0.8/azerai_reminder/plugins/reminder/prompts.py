"""
AzerAI Reminder Plugin Prompts
Reminder plugini üçün xüsusi təlimatlar
"""

PLUGIN_PROMPT = """
Reminder Plugin Capability:
You can manage reminders using the reminder plugin. Users can create, list, update, delete, complete reminders and get statistics.

Available functions:
- create_reminder() - Creates a new reminder with time, date, priority and category
- list_reminders() - Lists all active reminders with their details
- update_reminder() - Updates an existing reminder's information
- delete_reminder() - Deletes a reminder by ID
- complete_reminder() - Marks a reminder as completed
- get_reminder_stats() - Shows reminder statistics and analytics

When users ask about reminders, schedules, or tasks, use these functions to help them.

Examples:
- "Saat 5-də mənə xatıldat" -> Use create_reminder()
- "Bugün nə var?" -> Use list_reminders()
- "Tapşırığı tamamla" -> Use complete_reminder()
- "Xatırlatma sil" -> Use delete_reminder()
- "Statistikanı göstər" -> Use get_reminder_stats()

Reminder features:
- Time and date scheduling
- Priority levels (high, medium, low)
- Categories (work, personal, health, etc.)
- Completion tracking
- Azerbaijani language support

Common reminder commands:
- "Saat [vaxt]-da [mətn] xatıldat" - Create reminder
- "Bütün xatırlatmalar" - List reminders
- "[ID] nömrəli xatırlatmanı tamamla" - Complete reminder
- "[ID] nömrəli xatırlatmanı sil" - Delete reminder
- "Xatırlatma statistikası" - Get statistics

Always provide responses in Azerbaijani language unless specifically asked otherwise.
If there are any issues with reminder operations, inform the user politely with specific error details.
Use natural Azerbaijani language for all reminder-related interactions.
"""
