"""
AzerAI Reminder Plugin Info
Reminder plugini haqqında məlumatlar və metadata
"""

__version__ = "3.0.8"
__author__ = "AzStudio Dev"
__email__ = "info.azstudiodev@gmail.com"
__description__ = "AzerAI Reminder Plugin - Azərbaycan dilində hatırlatma sistemi"

PLUGIN_INFO = {
    "name": "azerai-reminder",
    "version": __version__,
    "author": __author__,
    "email": __email__,
    "description": __description__,
    "category": "utility",
    "language": "az",
    "functions": [
        "create_reminder",
        "list_reminders",
        "update_reminder",
        "delete_reminder",
        "complete_reminder",
        "get_reminder_stats"
    ],
    "capabilities": [
        "Vaxt və tarix ilə hatırlatıcılar yarat",
        "Bütün aktiv hatırlatıcıları göstər",
        "Mövcud hatırlatıcıları yenilə",
        "Hatırlatıcıları sil",
        "Hatırlatıcıları tamamlanmış kimi qeyd et",
        "Hatırlatıcı statistikası al",
        "Azərbaycan dili dəstəyi",
        "Vaxt əsaslı bildirişlər",
        "Prioritet səviyyələri",
        "Kateqoriyalar və teqlər"
    ],
    "dependencies": [
        "apscheduler",
        "livekit-agents"
    ],
    "features": [
        "Müxtəlif hatırlatma növləri",
        "Vaxt planlaşdırması",
        "Prioritet idarəsi",
        "Kateqoriya təşkilatı",
        "Tamamlanma izlənməsi",
        "Statistika və analitika"
    ],
    "tags": ["azerai", "reminder", "hatırlatma", "schedule", "time", "notification", "azerbaijani"]
}

def get_plugin_info():
    """Plugin məlumatlarını qaytarır"""
    return PLUGIN_INFO

def get_plugin_version():
    """Plugin versiyasını qaytarır"""
    return __version__

def get_plugin_description():
    """Plugin təsvirini qaytarır"""
    return __description__
