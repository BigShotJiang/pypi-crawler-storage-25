# 📅 AzerAI Reminder Plugin

**AzerAI** - Azərbaycan dilində qabaqcıl səsli AI asistenti üçün hatırlatma plugini.

## Xüsusiyyətlər

- ⏰ **Zamanlı hatırlatmalar** - Specific tarix və saatda
- 📅 **Günlük hatırlatmalar** - Hər gün təkrar olunan
- ⏸️ **Pause/Resume** - Hatırlatmaları idarə et
- 🗑️ **Sil** - Artıq lazım olmayanları sil
- 💾 **JSON saxlama** - Məlumatlar lokal olaraq saxlanılır
- 🔄 **APScheduler** - Güclü zamanlayıcı sistemi

## Quraşdırma

```bash
pip install AzerAI-Reminder
```

## İstifadə

Plugin avtomatik olaraq AzerAI tərəfindən aşkar edilir.

### Əmrlər

- `"5 dəqiqə sonra mənə xatırlat"` - Vaxtlı hatırlatma
- `"Hər gün saat 09:00da mənə xatırlat"` - Günlük hatırlatma
- `"Hatırlatmalarımı göstər"` - Siyahı
- `"X hatırlatmasını dayandır"` - Pause
- `"X hatırlatmasını davam et"` - Resume
- `"X hatırlatmasını sil"` - Sil

## Fayl struktur

```
azerai_reminder/
├── plugins/
│   └── reminder/
│       ├── __init__.py
│       └── main.py
└── __init__.py
```

## Fayllar

- `azerai_reminders.json` - Hatırlatma məlumatları

## Asılılıqlar

- `livekit-agents` - AI agent framework
- `apscheduler` - Zamanlayıcı

## 📄 Lisenziya

Bu layihə MIT Lisenziyası ilə lisenziyalaşdırılıb - [LICENSE](https://github.com/AzStudioDev/AzerAI-Reminder/blob/main/LICENSE) faylına baxın.

## 📞 Əlaqə

- **Müəllif:** AzStudio Dev
- **Email:** info.azstudiodev@gmail.com
- **GitHub:** https://github.com/AzStudioDev/AzerAI-Reminder
- **PyPI:** https://pypi.org/project/AzerAI-Reminder/

---

**🇦🇿 Azərbaycanın ilk tam plugin ekosistemli AI asistentinin Reminder plugini!** 🚀
