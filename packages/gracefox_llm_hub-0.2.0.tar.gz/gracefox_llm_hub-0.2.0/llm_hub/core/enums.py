"""枚举定义"""

from enum import Enum


class Provider(Enum):
    """LLM提供商"""
    # 云端API
    DEEPSEEK = "deepseek"
    OPENAI = "openai"
    KIMI = "kimi"
    KIMI_INTL = "kimi_intl"
    ALIYUN_BAILIAN = "aliyun_bailian"
    GOOGLE_GEMINI = "gemini"
    OPENROUTER = "openrouter"
    ANTHROPIC = "anthropic"
    
    # 国产AI
    QWEN = "qwen"
    GLM = "glm"
    ERNIE = "ernie"
    MINICPM = "minicpm"
    
    # 本地部署
    OLLAMA = "ollama"
    LLAMA_CPP = "llama_cpp"
    LOCAL = "local"
    
    # 自定义
    CUSTOM = "custom"
    
    @classmethod
    def from_string(cls, value: str):
        for member in cls:
            if member.value == value.lower():
                return member
        return cls.CUSTOM
    
    def is_local(self) -> bool:
        """是否为本地部署"""
        return self in [self.OLLAMA, self.LLAMA_CPP, self.LOCAL, self.MINICPM]
    
    def is_cloud(self) -> bool:
        """是否为云端API"""
        return not self.is_local() and self != self.CUSTOM


class ModelType(Enum):
    """模型类型"""
    CHAT = "chat"
    COMPLETION = "completion"
    EMBEDDING = "embedding"
    VISION = "vision"
    CODE = "code"


class ResponseFormat(Enum):
    """响应格式"""
    TEXT = "text"
    JSON = "json"
    STREAM = "stream"