"""LLM客户端 - 精简版"""

from typing import Optional, Dict, Any, Union, List, Generator
import threading
from contextlib import contextmanager
import time

from llm_hub.core.enums import Provider
from llm_hub.core.exceptions import RateLimitError
from llm_hub.config import LLMConfig
from llm_hub.models.message import Conversation, Message
from llm_hub.models.response import Response, StreamResponse
from llm_hub.providers import create_provider
from llm_hub.utils import get_token_counter, BaseTokenCounter
from llm_hub.utils.rate_limiter import RateLimiter
from llm_hub.config.security import SensitiveDataFilter


class LLMClient:
    """统一的LLM客户端"""
    
    def __init__(self, config: Optional[LLMConfig] = None, enable_rate_limit: bool = True):
        self.config = config or LLMConfig()
        self._provider = None
        self._token_counter: Optional[BaseTokenCounter] = None
        self._rate_limiter = RateLimiter(
            calls_per_minute=self.config.rate_limit_calls_per_minute,
            burst_limit=self.config.rate_limit_burst
        ) if enable_rate_limit and self.config.enable_rate_limit else None
        self._lock = threading.RLock()
        
        # 环境感知组件（延迟初始化）
        self._environment_enabled = self.config.enable_environment
        self._environment = None
        self._last_environment_sample = 0
        
        self._init_provider()
    
    def _init_provider(self):
        """初始化提供商"""
        with self._lock:
            self._provider = create_provider(
                self.config.provider,
                self.config.to_dict(include_sensitive=True)
            )
    
    def _get_environment(self):
        """延迟加载环境感知组件"""
        if not self._environment_enabled:
            return None
        
        current_time = time.time()
        if self._environment is not None:
            if current_time - self._last_environment_sample < self.config.environment_sample_interval:
                return self._environment
        
        if self._environment is None:
            try:
                from llm_hub.environment import EnvironmentManager
                self._environment = EnvironmentManager(self.config)
            except ImportError:
                if self.config.debug:
                    print("[LLMClient] 环境感知不可用，请安装: pip install psutil")
                self._environment_enabled = False
                return None
        
        self._last_environment_sample = current_time
        return self._environment
    
    def _get_token_counter(self) -> BaseTokenCounter:
        """获取Token计数器（使用provider自己的计数器）"""
        if self._token_counter is None:
            with self._lock:
                if self._token_counter is None:
                    # 直接使用provider的token计数器
                    self._token_counter = self._provider.get_token_counter()
        return self._token_counter
    
    def update_config(self, **kwargs):
        """更新配置"""
        with self._lock:
            for key, value in kwargs.items():
                if hasattr(self.config, key):
                    setattr(self.config, key, value)
            self._init_provider()
            self._token_counter = None
            self._environment = None
            self._environment_enabled = self.config.enable_environment
    
    @contextmanager
    def _rate_limit_context(self):
        """速率限制上下文"""
        if self._rate_limiter:
            if not self._rate_limiter.wait_and_acquire():
                raise RateLimitError(f"Rate limit exceeded. Max {self._rate_limiter.calls_per_minute} calls per minute.")
        yield
    
    # ========== 环境感知API ==========
    
    def get_environment_info(self) -> Dict[str, Any]:
        """获取环境信息"""
        env = self._get_environment()
        if env:
            return env.get_info()
        return {"enabled": False, "message": "环境感知未启用"}
    
    def get_environment_summary(self) -> str:
        """获取环境摘要"""
        env = self._get_environment()
        if env:
            return env.get_summary()
        return ""
    
    # ========== 主要API ==========
    
    def chat(
        self,
        messages: Union[List[Dict], Conversation, str],
        **kwargs
    ) -> Union[Response, StreamResponse]:
        """对话接口"""
        with self._rate_limit_context():
            # 处理环境感知
            env = self._get_environment()
            if env:
                if self.config.auto_adapt:
                    adjustments = env.apply_strategy()
                    for key, value in adjustments.items():
                        if key not in kwargs:
                            kwargs[key] = value
                
                if self.config.inject_context:
                    messages = env.inject_context(messages)
            
            # 处理消息格式
            conversation = self._normalize_messages(messages)
            
            # 构建参数
            params = self._build_params(kwargs)
            
            if self.config.debug:
                self._log_debug("Chat request", params)
            
            return self._provider.chat(conversation, **params)
    
    def _normalize_messages(self, messages) -> Conversation:
        """标准化消息格式"""
        if isinstance(messages, str):
            conv = Conversation()
            conv.add_user(messages)
        elif isinstance(messages, list):
            conv = Conversation()
            for msg in messages:
                if isinstance(msg, dict):
                    conv.add(Message(**msg))
                elif isinstance(msg, Message):
                    conv.add(msg)
        elif isinstance(messages, Conversation):
            conv = messages
        else:
            raise TypeError(f"Unsupported messages type: {type(messages)}")
        return conv
    
    def _build_params(self, kwargs: Dict) -> Dict:
        """构建请求参数"""
        return {
            "temperature": kwargs.get("temperature", self.config.temperature),
            "max_tokens": kwargs.get("max_tokens", self.config.max_tokens),
            "top_p": kwargs.get("top_p", self.config.top_p),
            "frequency_penalty": kwargs.get("frequency_penalty", self.config.frequency_penalty),
            "presence_penalty": kwargs.get("presence_penalty", self.config.presence_penalty),
            "stream": kwargs.get("stream", self.config.stream),
            "reasoning": kwargs.get("reasoning", self.config.reasoning),
        }
    
    def complete(self, prompt: str, **kwargs) -> Union[Response, StreamResponse]:
        """文本补全"""
        with self._rate_limit_context():
            params = {
                "temperature": kwargs.get("temperature", self.config.temperature),
                "max_tokens": kwargs.get("max_tokens", self.config.max_tokens),
                "top_p": kwargs.get("top_p", self.config.top_p),
                "stream": kwargs.get("stream", self.config.stream),
            }
            return self._provider.complete(prompt, **params)
    
    def stream_chat(self, messages: Union[List[Dict], Conversation, str], **kwargs) -> Generator:
        """流式对话"""
        kwargs["stream"] = True
        response = self.chat(messages, **kwargs)
        if isinstance(response, StreamResponse):
            yield from response
        else:
            from llm_hub.models.response import StreamChunk, StreamEventType
            yield StreamChunk(
                type=StreamEventType.CONTENT,
                content=response.content,
                delta=response.content
            )
    
    # ========== Token计数 ==========
    
    def count_tokens(self, text: str) -> int:
        """计算文本token数"""
        return self._get_token_counter().count(text)
    
    def count_messages_tokens(self, messages: List[Dict[str, str]]) -> int:
        """计算消息列表token数"""
        return self._get_token_counter().count_messages(messages)
    
    def count_conversation_tokens(self, conversation: Conversation) -> int:
        """计算对话token数"""
        return self._get_token_counter().count_conversation(conversation)
    
    def truncate_to_tokens(self, text: str, max_tokens: int, suffix: str = "...") -> str:
        """按token截断"""
        return self._get_token_counter().truncate(text, max_tokens, suffix)
    
    # ========== 其他 ==========
    
    def health_check(self) -> bool:
        """健康检查"""
        try:
            return self._provider.health_check()
        except Exception:
            return False
    
    def get_rate_limit_stats(self) -> Dict:
        """获取速率限制统计"""
        if self._rate_limiter:
            return self._rate_limiter.get_stats()
        return {"enabled": False}
    
    def _log_debug(self, message: str, data: Dict = None):
        """调试日志"""
        if self.config.debug:
            safe_data = SensitiveDataFilter.filter_dict(data) if data else {}
            print(f"[DEBUG] {message}: {safe_data}")