"""自定义异常"""

class LLMHubError(Exception):
    """基础异常"""
    pass

class ConfigError(LLMHubError):
    """配置错误"""
    pass

class ProviderError(LLMHubError):
    """提供商错误"""
    pass

class RateLimitError(LLMHubError):
    """速率限制错误"""
    pass

class TokenLimitError(LLMHubError):
    """Token限制错误"""
    pass

class EnvironmentError(LLMHubError):
    """环境感知错误"""
    pass