"""配置管理 - 纯配置类"""

from dataclasses import dataclass, field
from typing import Optional, Dict, Any, Union
import json
import os
from pathlib import Path
import warnings
import re

from llm_hub.core.enums import Provider
from llm_hub.core.exceptions import ConfigError


@dataclass
class LLMConfig:
    """LLM配置 - 核心数据结构"""
    
    # ========== 基本配置 ==========
    provider: Provider = Provider.OPENAI
    model: str = "gpt-3.5-turbo"
    api_key: Optional[str] = None
    api_base: Optional[str] = None
    
    # ========== 生成参数 ==========
    temperature: float = 0.7
    max_tokens: int = 2000
    top_p: float = 0.95
    frequency_penalty: float = 0.0
    presence_penalty: float = 0.0
    
    # ========== 超时和重试 ==========
    timeout: int = 60
    max_retries: int = 3
    retry_delay: float = 1.0
    retry_backoff: float = 2.0
    
    # ========== 本地模型配置 ==========
    model_path: Optional[str] = None
    ollama_url: str = "http://localhost:11434"
    llama_exe_path: Optional[str] = None
    
    # ========== 思考模式 ==========
    reasoning: bool = False
    show_thinking: bool = True
    reasoning_effort: str = "medium"
    
    # ========== 流式输出配置 ==========
    stream: bool = False
    stream_buffer_size: int = 100000
    
    # ========== 速率限制 ==========
    enable_rate_limit: bool = True
    rate_limit_calls_per_minute: int = 60
    rate_limit_burst: int = 10
    
    # ========== 安全配置 ==========
    encrypt_keys: bool = False
    log_sensitive_data: bool = False
    
    # ========== 对话管理 ==========
    max_conversation_messages: int = 50
    max_conversation_tokens: int = 8000
    auto_truncate: bool = True
    truncate_strategy: str = "smart"
    
    # ========== 缓存配置 ==========
    enable_token_cache: bool = True
    token_cache_size: int = 1000
    
    # ========== 环境感知配置 ==========
    enable_environment: bool = False
    auto_adapt: bool = True
    inject_context: bool = True
    environment_sample_interval: int = 5
    environment_high_load_threshold: float = 80.0
    
    env_low_memory_max_tokens: int = 500
    env_high_load_max_tokens: int = 1000
    env_medium_load_max_tokens: int = 1500
    env_low_battery_temperature: float = 0.5
    env_high_load_temperature: float = 0.3
    
    # ========== 其他 ==========
    debug: bool = False
    user_agent: Optional[str] = None
    
    def __post_init__(self):
        """初始化后验证"""
        if isinstance(self.provider, str):
            self.provider = Provider.from_string(self.provider)
        
        # 类型转换
        self.temperature = float(self.temperature)
        self.max_tokens = int(self.max_tokens)
        self.top_p = float(self.top_p)
        self.timeout = int(self.timeout)
        
        is_valid, error_msg = self.validate()
        if not is_valid:
            raise ConfigError(f"Invalid configuration: {error_msg}")
    
    def get_api_url(self) -> str:
        """获取API URL"""
        if self.api_base:
            return self.api_base
        
        urls = {
            Provider.OPENAI: "https://api.openai.com/v1",
            Provider.DEEPSEEK: "https://api.deepseek.com/v1",
            Provider.KIMI: "https://api.moonshot.cn/v1",
            Provider.KIMI_INTL: "https://api.moonshot.cc/v1",
            Provider.ALIYUN_BAILIAN: "https://dashscope.aliyuncs.com/compatible-mode/v1",
            Provider.OPENROUTER: "https://openrouter.ai/api/v1",
            Provider.GOOGLE_GEMINI: "https://generativelanguage.googleapis.com/v1",
            Provider.ANTHROPIC: "https://api.anthropic.com/v1",
            Provider.QWEN: "https://dashscope.aliyuncs.com/compatible-mode/v1",
            Provider.GLM: "https://open.bigmodel.cn/api/paas/v4",
            Provider.ERNIE: "https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop",
        }
        
        url = urls.get(self.provider, "")
        
        if self.provider == Provider.OPENAI and os.environ.get("OPENAI_API_BASE"):
            return os.environ["OPENAI_API_BASE"]
        
        return url
    
    def get_api_key_safe(self) -> str:
        """安全获取API密钥（脱敏）"""
        if self.api_key:
            if len(self.api_key) > 8:
                return f"{self.api_key[:4]}...{self.api_key[-4:]}"
            return "***"
        return ""
    
    def to_dict(self, include_sensitive: bool = False) -> Dict:
        """转换为字典"""
        result = {
            "provider": self.provider.value if isinstance(self.provider, Provider) else self.provider,
            "model": self.model,
            "api_base": self.api_base,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "top_p": self.top_p,
            "frequency_penalty": self.frequency_penalty,
            "presence_penalty": self.presence_penalty,
            "timeout": self.timeout,
            "max_retries": self.max_retries,
            "retry_delay": self.retry_delay,
            "retry_backoff": self.retry_backoff,
            "model_path": self.model_path,
            "ollama_url": self.ollama_url,
            "llama_exe_path": self.llama_exe_path,
            "reasoning": self.reasoning,
            "show_thinking": self.show_thinking,
            "reasoning_effort": self.reasoning_effort,
            "stream": self.stream,
            "stream_buffer_size": self.stream_buffer_size,
            "enable_rate_limit": self.enable_rate_limit,
            "rate_limit_calls_per_minute": self.rate_limit_calls_per_minute,
            "rate_limit_burst": self.rate_limit_burst,
            "encrypt_keys": self.encrypt_keys,
            "log_sensitive_data": self.log_sensitive_data,
            "max_conversation_messages": self.max_conversation_messages,
            "max_conversation_tokens": self.max_conversation_tokens,
            "auto_truncate": self.auto_truncate,
            "truncate_strategy": self.truncate_strategy,
            "enable_token_cache": self.enable_token_cache,
            "token_cache_size": self.token_cache_size,
            "debug": self.debug,
            "user_agent": self.user_agent,
            "enable_environment": self.enable_environment,
            "auto_adapt": self.auto_adapt,
            "inject_context": self.inject_context,
            "environment_sample_interval": self.environment_sample_interval,
            "environment_high_load_threshold": self.environment_high_load_threshold,
            "env_low_memory_max_tokens": self.env_low_memory_max_tokens,
            "env_high_load_max_tokens": self.env_high_load_max_tokens,
            "env_medium_load_max_tokens": self.env_medium_load_max_tokens,
            "env_low_battery_temperature": self.env_low_battery_temperature,
            "env_high_load_temperature": self.env_high_load_temperature,
        }
        
        if include_sensitive:
            result["api_key"] = self.api_key
        else:
            result["api_key"] = self.get_api_key_safe() if self.api_key else None
        
        return result
    
    def to_json(self, indent: int = 2, include_sensitive: bool = False) -> str:
        """转换为JSON字符串"""
        return json.dumps(self.to_dict(include_sensitive), ensure_ascii=False, indent=indent)
    
    @classmethod
    def from_dict(cls, data: Dict, strict: bool = False, validate: bool = True) -> "LLMConfig":
        """从字典创建配置"""
        data = data.copy()
        
        if "provider" in data and isinstance(data["provider"], str):
            data["provider"] = Provider.from_string(data["provider"])
        
        if "api_key" in data and data["api_key"] == "":
            data["api_key"] = None
        
        if not strict:
            valid_params = cls._get_valid_params()
            data = {k: v for k, v in data.items() if k in valid_params}
        
        instance = cls(**data)
        
        if validate:
            is_valid, error_msg = instance.validate()
            if not is_valid:
                raise ConfigError(f"Invalid configuration: {error_msg}")
        
        return instance
    
    @classmethod
    def _get_valid_params(cls) -> set:
        """获取所有有效的参数名"""
        import inspect
        return set(inspect.signature(cls).parameters.keys())
    
    @classmethod
    def from_json(cls, json_str: str, strict: bool = False, validate: bool = True) -> "LLMConfig":
        """从JSON字符串创建配置"""
        try:
            data = json.loads(json_str)
            return cls.from_dict(data, strict=strict, validate=validate)
        except json.JSONDecodeError as e:
            raise ConfigError(f"Invalid JSON string: {e}")
    
    @classmethod
    def from_file(cls, path: str, strict: bool = False, validate: bool = True) -> "LLMConfig":
        """从文件加载配置"""
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"Config file not found: {path}")
        
        with open(path, 'r', encoding='utf-8') as f:
            if path.suffix.lower() in ['.yaml', '.yml']:
                try:
                    import yaml
                    data = yaml.safe_load(f)
                except ImportError:
                    raise ImportError("PyYAML required for YAML support. Install: pip install pyyaml")
            else:
                data = json.load(f)
        
        return cls.from_dict(data, strict=strict, validate=validate)
    
    def save(self, path: str, format: str = "json", include_sensitive: bool = False):
        """保存配置到文件"""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        
        data = self.to_dict(include_sensitive=include_sensitive)
        
        if format == "yaml" or path.suffix.lower() in ['.yaml', '.yml']:
            try:
                import yaml
                with open(path, 'w', encoding='utf-8') as f:
                    yaml.dump(data, f, allow_unicode=True, indent=2, default_flow_style=False)
            except ImportError:
                raise ImportError("PyYAML required for YAML support. Install: pip install pyyaml")
        else:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        
        if os.name != 'nt':
            os.chmod(path, 0o600)
    
    def validate(self) -> tuple:
        """验证配置完整性"""
        if not self.provider:
            return False, "provider is required"
        
        if not self.model or not isinstance(self.model, str):
            return False, "model must be a non-empty string"
        
        if self.provider.is_cloud() and not self.api_key:
            if self.provider not in [Provider.CUSTOM]:
                return False, f"api_key is required for {self.provider.value}"
        
        if self.provider == Provider.LLAMA_CPP:
            if not self.model_path:
                return False, "model_path is required for llama.cpp"
            if not Path(self.model_path).exists():
                return False, f"model_path does not exist: {self.model_path}"
        
        if self.provider == Provider.OLLAMA:
            if not self.ollama_url:
                return False, "ollama_url is required for Ollama"
            if not re.match(r'^https?://[^/]+', self.ollama_url):
                return False, f"Invalid ollama_url format: {self.ollama_url}"
        
        if self.api_base and not re.match(r'^https?://', self.api_base):
            return False, f"Invalid api_base format: {self.api_base}"
        
        if not 0.0 <= self.temperature <= 2.0:
            return False, f"temperature must be between 0.0 and 2.0, got {self.temperature}"
        
        if self.max_tokens < 1 or self.max_tokens > 100000:
            return False, f"max_tokens must be between 1 and 100000, got {self.max_tokens}"
        
        if not 0.0 <= self.top_p <= 1.0:
            return False, f"top_p must be between 0.0 and 1.0, got {self.top_p}"
        
        if self.timeout < 1:
            return False, f"timeout must be at least 1 second, got {self.timeout}"
        
        if self.max_retries < 0:
            return False, f"max_retries cannot be negative, got {self.max_retries}"
        
        if self.reasoning_effort not in ["low", "medium", "high"]:
            return False, f"reasoning_effort must be low/medium/high, got {self.reasoning_effort}"
        
        if self.truncate_strategy not in ["oldest", "smart"]:
            return False, f"truncate_strategy must be oldest/smart, got {self.truncate_strategy}"
        
        return True, None
    
    def get_default_headers(self) -> Dict[str, str]:
        """获取默认请求头"""
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        
        if self.user_agent:
            headers["User-Agent"] = self.user_agent
        else:
            from llm_hub.version import __version__
            headers["User-Agent"] = f"LLM-Hub/{__version__}"
        
        if self.api_key and self.provider.is_cloud():
            headers["Authorization"] = f"Bearer {self.api_key}"
        
        return headers
    
    def merge(self, other: Union["LLMConfig", Dict, str]) -> "LLMConfig":
        """合并另一个配置"""
        if isinstance(other, str):
            try:
                other_dict = json.loads(other)
                other_config = LLMConfig.from_dict(other_dict, validate=False)
            except json.JSONDecodeError:
                other_config = LLMConfig.from_file(other, validate=False)
        elif isinstance(other, dict):
            other_config = LLMConfig.from_dict(other, validate=False)
        elif isinstance(other, LLMConfig):
            other_config = other
        else:
            raise TypeError(f"Cannot merge with {type(other)}")
        
        merged_dict = self.to_dict(include_sensitive=True)
        for key, value in other_config.to_dict(include_sensitive=True).items():
            if value is not None and value != "":
                merged_dict[key] = value
        
        return LLMConfig.from_dict(merged_dict)
    
    def clone(self) -> "LLMConfig":
        """深拷贝配置"""
        return LLMConfig.from_dict(self.to_dict(include_sensitive=True), validate=False)
    
    def __repr__(self) -> str:
        dict_repr = self.to_dict(include_sensitive=False)
        if dict_repr.get("api_key"):
            dict_repr["api_key"] = "***HIDDEN***"
        return f"LLMConfig({dict_repr})"


# ========== 便捷函数 ==========

def create_default_config(provider: Union[str, Provider] = "openai", **overrides) -> LLMConfig:
    """创建默认配置"""
    config_dict = {
        "provider": provider,
        "model": "gpt-3.5-turbo" if provider == "openai" else f"{provider}-chat",
        "temperature": 0.7,
        "max_tokens": 2000,
        "stream": False,
        "debug": False,
        **overrides
    }
    return LLMConfig.from_dict(config_dict)


def load_config_from_env() -> LLMConfig:
    """从环境变量加载配置"""
    config_dict = {}
    
    env_mappings = {
        "LLM_PROVIDER": "provider",
        "LLM_MODEL": "model",
        "LLM_API_KEY": "api_key",
        "LLM_API_BASE": "api_base",
        "LLM_TEMPERATURE": "temperature",
        "LLM_MAX_TOKENS": "max_tokens",
        "LLM_TIMEOUT": "timeout",
        "LLM_MAX_RETRIES": "max_retries",
        "LLM_OLLAMA_URL": "ollama_url",
        "LLM_DEBUG": "debug",
        "LLM_STREAM": "stream",
        "LLM_REASONING": "reasoning",
        "LLM_ENABLE_ENVIRONMENT": "enable_environment",
    }
    
    for env_var, config_key in env_mappings.items():
        value = os.environ.get(env_var)
        if value is not None:
            if config_key in ["temperature"]:
                try:
                    value = float(value)
                except ValueError:
                    pass
            elif config_key in ["max_tokens", "timeout", "max_retries"]:
                try:
                    value = int(value)
                except ValueError:
                    pass
            elif config_key in ["debug", "stream", "reasoning", "enable_environment"]:
                value = value.lower() in ["true", "1", "yes", "on"]
            
            config_dict[config_key] = value
    
    if not config_dict:
        return LLMConfig()
    
    return LLMConfig.from_dict(config_dict)