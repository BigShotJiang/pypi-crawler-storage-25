"""安全配置管理 - 加密存储和敏感信息保护"""

import os
import json
import base64
import re
from typing import Optional, Dict, Any
from pathlib import Path

from cryptography.fernet import Fernet


class SecureConfigManager:
    """安全配置管理器 - 加密存储API密钥"""
    
    def __init__(self, config_dir: Optional[str] = None):
        self.config_dir = Path(config_dir) if config_dir else Path.home() / ".llm-hub"
        self.config_dir.mkdir(parents=True, exist_ok=True)
        
        self._key_file = self.config_dir / ".key"
        self._cipher = None
        self._init_cipher()
    
    def _init_cipher(self):
        """初始化加密器"""
        if self._key_file.exists():
            with open(self._key_file, 'rb') as f:
                key = f.read()
        else:
            key = Fernet.generate_key()
            with open(self._key_file, 'wb') as f:
                f.write(key)
            if os.name != 'nt':
                os.chmod(self._key_file, 0o600)
        
        self._cipher = Fernet(key)
    
    def encrypt_value(self, value: str) -> str:
        """加密敏感值"""
        if not value:
            return ""
        encrypted = self._cipher.encrypt(value.encode())
        return base64.b64encode(encrypted).decode()
    
    def decrypt_value(self, encrypted: str) -> str:
        """解密敏感值"""
        if not encrypted:
            return ""
        try:
            decoded = base64.b64decode(encrypted.encode())
            decrypted = self._cipher.decrypt(decoded)
            return decrypted.decode()
        except Exception:
            return ""
    
    def save_config(self, name: str, config: Dict[str, Any], encrypt_keys: bool = True):
        """保存配置（可选加密）"""
        config_file = self.config_dir / f"{name}.json"
        
        safe_config = config.copy()
        
        if encrypt_keys and "api_key" in safe_config and safe_config["api_key"]:
            safe_config["api_key"] = self.encrypt_value(safe_config["api_key"])
        
        if encrypt_keys and "secret_key" in safe_config and safe_config["secret_key"]:
            safe_config["secret_key"] = self.encrypt_value(safe_config["secret_key"])
        
        with open(config_file, 'w', encoding='utf-8') as f:
            json.dump(safe_config, f, ensure_ascii=False, indent=2)
        
        if os.name != 'nt':
            os.chmod(config_file, 0o600)
    
    def load_config(self, name: str, decrypt_keys: bool = True) -> Optional[Dict[str, Any]]:
        """加载配置（自动解密）"""
        config_file = self.config_dir / f"{name}.json"
        
        if not config_file.exists():
            return None
        
        with open(config_file, 'r', encoding='utf-8') as f:
            config = json.load(f)
        
        if decrypt_keys:
            if "api_key" in config and config["api_key"]:
                config["api_key"] = self.decrypt_value(config["api_key"])
            if "secret_key" in config and config["secret_key"]:
                config["secret_key"] = self.decrypt_value(config["secret_key"])
        
        return config
    
    def delete_config(self, name: str) -> bool:
        """删除配置"""
        config_file = self.config_dir / f"{name}.json"
        if config_file.exists():
            config_file.unlink()
            return True
        return False
    
    def list_configs(self) -> list:
        """列出所有配置"""
        return [f.stem for f in self.config_dir.glob("*.json") if f.stem != ".key"]


class SensitiveDataFilter:
    """敏感数据过滤器 - 用于日志脱敏"""
    
    SENSITIVE_PATTERNS = [
        (r'sk-[a-zA-Z0-9]{32,}', 'sk-***REDACTED***'),
        (r'Bearer\s+[a-zA-Z0-9_-]+', 'Bearer ***REDACTED***'),
        (r'api_key["\s:]+["\']([^"\']+)["\']', 'api_key": "***REDACTED***"'),
        (r'Authorization["\s:]+["\']([^"\']+)["\']', 'Authorization": "***REDACTED***"'),
    ]
    
    @classmethod
    def filter(cls, text: str) -> str:
        """过滤敏感信息"""
        result = text
        for pattern, replacement in cls.SENSITIVE_PATTERNS:
            result = re.sub(pattern, replacement, result, flags=re.IGNORECASE)
        return result
    
    @classmethod
    def filter_dict(cls, data: dict) -> dict:
        """过滤字典中的敏感信息"""
        filtered = data.copy()
        sensitive_keys = ['api_key', 'secret_key', 'authorization', 'token', 'password']
        
        for key in sensitive_keys:
            if key in filtered and filtered[key]:
                filtered[key] = '***REDACTED***'
        
        return filtered