"""环境感知模块 - 可选依赖"""

from typing import Dict, Any, Union, List

from llm_hub.environment.sensors import SystemSensor, NetworkSensor, ProcessSensor
from llm_hub.environment.context import ContextInjector
from llm_hub.environment.strategy import AdaptiveStrategy


class EnvironmentManager:
    """环境管理器 - 整合所有环境感知功能"""
    
    def __init__(self, config):
        self.config = config
        self.system_sensor = SystemSensor()
        self.network_sensor = NetworkSensor()
        self.process_sensor = ProcessSensor()
        self.context_injector = ContextInjector()
        
        strategy_config = {
            "env_high_load_max_tokens": getattr(config, 'env_high_load_max_tokens', 500),
            "env_medium_load_max_tokens": getattr(config, 'env_medium_load_max_tokens', 1000),
            "env_low_battery_temperature": getattr(config, 'env_low_battery_temperature', 0.5),
            "env_high_load_temperature": getattr(config, 'env_high_load_temperature', 0.3),
        }
        self.adaptive_strategy = AdaptiveStrategy(strategy_config)
    
    def get_info(self) -> Dict[str, Any]:
        """获取环境信息"""
        import time
        return {
            "timestamp": time.time(),
            "system": self.system_sensor.get_all(),
            "network": self.network_sensor.get_all(),
            "process": self.process_sensor.get_relevant_info(),
        }
    
    def get_summary(self) -> str:
        """获取环境摘要"""
        return self.context_injector.get_summary(self.get_info())
    
    def apply_strategy(self) -> Dict[str, Any]:
        """应用自适应策略"""
        return self.adaptive_strategy.get_adjustments(self.get_info())
    
    def inject_context(self, messages: Union[str, List, Any]) -> Union[str, List, Any]:
        """注入环境上下文"""
        context = self.get_summary()
        if not context:
            return messages
        
        if isinstance(messages, str):
            return f"{context}\n\n{messages}"
        elif hasattr(messages, 'messages'):
            from llm_hub.models.message import Message, Conversation
            new_messages = [Message.system(context)] + messages.messages
            new_conv = Conversation()
            new_conv.messages = new_messages
            new_conv.system_prompt = getattr(messages, 'system_prompt', None)
            return new_conv
        elif isinstance(messages, list):
            return [{"role": "system", "content": context}] + messages
        return messages


__all__ = [
    "EnvironmentManager",
    "SystemSensor",
    "NetworkSensor",
    "ProcessSensor",
    "ContextInjector",
    "AdaptiveStrategy",
]