"""环境上下文注入器"""

import json
from typing import Dict, Any


class ContextInjector:
    """环境上下文注入器"""
    
    def __init__(self, format_type: str = "text"):
        self.format_type = format_type
    
    def get_summary(self, env_info: Dict[str, Any]) -> str:
        system = env_info.get("system", {})
        cpu = system.get("cpu", {})
        memory = system.get("memory", {})
        disk = system.get("disk", {})
        battery = system.get("battery", {})
        
        lines = [
            "=== 系统环境信息 ===",
            f"CPU使用率: {cpu.get('percent', 0)}%",
            f"内存使用率: {memory.get('percent', 0)}% ({self._format_bytes(memory.get('used', 0))} / {self._format_bytes(memory.get('total', 0))})",
            f"磁盘使用率: {disk.get('percent', 0)}%",
        ]
        
        if battery:
            lines.append(f"电池电量: {battery.get('percent', 0)}%")
            lines.append(f"电源状态: {'已接通' if battery.get('power_plugged') else '电池供电'}")
        
        lines.append(f"系统: {system.get('os', {}).get('system', 'Unknown')}")
        lines.append("==================")
        
        return "\n".join(lines)
    
    def inject(self, env_info: Dict[str, Any]) -> str:
        if self.format_type == "json":
            return json.dumps(env_info, ensure_ascii=False, indent=2)
        elif self.format_type == "markdown":
            return self._format_markdown(env_info)
        else:
            return self.get_summary(env_info)
    
    def _format_markdown(self, env_info: Dict[str, Any]) -> str:
        system = env_info.get("system", {})
        cpu = system.get("cpu", {})
        memory = system.get("memory", {})
        
        return f"""## 系统环境

- **CPU使用率**: {cpu.get('percent', 0)}%
- **内存使用率**: {memory.get('percent', 0)}%
- **可用内存**: {self._format_bytes(memory.get('available', 0))}

---
"""
    
    def _format_bytes(self, bytes_val: int) -> str:
        for unit in ['B', 'KB', 'MB', 'GB']:
            if bytes_val < 1024.0:
                return f"{bytes_val:.1f} {unit}"
            bytes_val /= 1024.0
        return f"{bytes_val:.1f} TB"