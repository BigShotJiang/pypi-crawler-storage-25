"""自适应策略 - 根据环境自动调整LLM参数"""

from typing import Dict, Any

from llm_hub.environment.sensors import SystemSensor


class AdaptiveStrategy:
    """自适应策略引擎"""
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or {}
        self.system_sensor = SystemSensor()
    
    def get_adjustments(self, env_info: Dict[str, Any]) -> Dict[str, Any]:
        adjustments = {}
        
        system = env_info.get("system", {})
        cpu = system.get("cpu", {})
        memory = system.get("memory", {})
        battery = system.get("battery", {})
        
        cpu_percent = cpu.get("percent", 0)
        mem_percent = memory.get("percent", 0)
        
        if cpu_percent > 85 or mem_percent > 85:
            adjustments["max_tokens"] = self.config.get("env_high_load_max_tokens", 500)
            adjustments["temperature"] = self.config.get("env_high_load_temperature", 0.3)
        elif cpu_percent > 70 or mem_percent > 70:
            adjustments["max_tokens"] = self.config.get("env_medium_load_max_tokens", 1000)
        
        if battery and not battery.get("power_plugged", True):
            if battery.get("percent", 100) < 20:
                adjustments["max_tokens"] = min(adjustments.get("max_tokens", 2000), 500)
                adjustments["temperature"] = self.config.get("env_low_battery_temperature", 0.5)
            elif battery.get("percent", 100) < 50:
                adjustments["max_tokens"] = min(adjustments.get("max_tokens", 2000), 1000)
        
        if "max_tokens" in adjustments:
            adjustments["max_tokens"] = max(100, adjustments["max_tokens"])
        
        return adjustments
    
    def should_degrade(self, env_info: Dict[str, Any]) -> bool:
        system = env_info.get("system", {})
        cpu = system.get("cpu", {})
        memory = system.get("memory", {})
        
        return cpu.get("percent", 0) > 90 or memory.get("percent", 0) > 90
    
    def should_warn(self, env_info: Dict[str, Any]) -> tuple:
        warnings = []
        
        system = env_info.get("system", {})
        cpu = system.get("cpu", {})
        memory = system.get("memory", {})
        disk = system.get("disk", {})
        battery = system.get("battery", {})
        
        if cpu.get("percent", 0) > 85:
            warnings.append("CPU负载过高")
        if memory.get("percent", 0) > 85:
            warnings.append("内存不足")
        if disk.get("percent", 0) > 90:
            warnings.append("磁盘空间不足")
        if battery and not battery.get("power_plugged", True) and battery.get("percent", 100) < 15:
            warnings.append("电量过低")
        
        return len(warnings) > 0, warnings