"""环境传感器 - 系统资源监控"""

import time
import socket
from typing import Dict, Any, Optional, List

# 延迟导入 psutil，使其成为可选依赖
_psutil = None

def _get_psutil():
    global _psutil
    if _psutil is None:
        try:
            import psutil
            _psutil = psutil
        except ImportError:
            raise ImportError("psutil is required for environment sensing. Install with: pip install psutil")
    return _psutil


class SystemSensor:
    """系统资源传感器"""
    
    def __init__(self):
        self._last_cpu_time = 0
        self._last_cpu_percent = 0
    
    def _get_psutil(self):
        return _get_psutil()
    
    def get_cpu_info(self) -> Dict[str, Any]:
        psutil = self._get_psutil()
        return {
            "percent": psutil.cpu_percent(interval=0.1),
            "count_physical": psutil.cpu_count(logical=False),
            "count_logical": psutil.cpu_count(logical=True),
        }
    
    def get_memory_info(self) -> Dict[str, Any]:
        psutil = self._get_psutil()
        mem = psutil.virtual_memory()
        return {
            "total": mem.total,
            "available": mem.available,
            "percent": mem.percent,
            "used": mem.used,
            "free": mem.free,
        }
    
    def get_disk_info(self) -> Dict[str, Any]:
        psutil = self._get_psutil()
        usage = psutil.disk_usage('/')
        return {
            "total": usage.total,
            "used": usage.used,
            "free": usage.free,
            "percent": usage.percent,
        }
    
    def get_battery_info(self) -> Optional[Dict[str, Any]]:
        psutil = self._get_psutil()
        if not hasattr(psutil, 'sensors_battery'):
            return None
        battery = psutil.sensors_battery()
        if not battery:
            return None
        return {
            "percent": battery.percent,
            "power_plugged": battery.power_plugged,
            "seconds_left": battery.secsleft if battery.secsleft != psutil.POWER_TIME_UNLIMITED else None,
        }
    
    def get_os_info(self) -> Dict[str, Any]:
        import platform
        psutil = self._get_psutil()
        return {
            "system": platform.system(),
            "release": platform.release(),
            "hostname": platform.node(),
            "uptime_seconds": time.time() - psutil.boot_time(),
        }
    
    def get_all(self) -> Dict[str, Any]:
        return {
            "cpu": self.get_cpu_info(),
            "memory": self.get_memory_info(),
            "disk": self.get_disk_info(),
            "battery": self.get_battery_info(),
            "os": self.get_os_info(),
            "timestamp": time.time(),
        }
    
    def get_summary(self) -> Dict[str, Any]:
        psutil = self._get_psutil()
        return {
            "cpu_percent": psutil.cpu_percent(interval=0.1),
            "memory_percent": psutil.virtual_memory().percent,
            "disk_percent": psutil.disk_usage('/').percent,
        }
    
    def is_high_load(self, threshold: float = 80.0) -> bool:
        psutil = self._get_psutil()
        cpu = psutil.cpu_percent(interval=0.1)
        mem = psutil.virtual_memory().percent
        return cpu > threshold or mem > threshold
    
    def get_load_level(self) -> str:
        psutil = self._get_psutil()
        cpu = psutil.cpu_percent(interval=0.1)
        mem = psutil.virtual_memory().percent
        if cpu > 85 or mem > 85:
            return "critical"
        elif cpu > 70 or mem > 70:
            return "high"
        elif cpu > 50 or mem > 50:
            return "moderate"
        else:
            return "low"


class NetworkSensor:
    """网络状态传感器"""
    
    def __init__(self):
        self._test_url = "https://www.google.com"
    
    def _get_psutil(self):
        return _get_psutil()
    
    def get_network_info(self) -> Dict[str, Any]:
        psutil = self._get_psutil()
        net = psutil.net_io_counters()
        return {
            "bytes_sent": net.bytes_sent,
            "bytes_recv": net.bytes_recv,
            "packets_sent": net.packets_sent,
            "packets_recv": net.packets_recv,
        }
    
    def get_connections(self) -> List[Dict]:
        psutil = self._get_psutil()
        conns = []
        for conn in psutil.net_connections(kind='inet'):
            conns.append({
                "status": conn.status,
                "local_port": conn.laddr.port if conn.laddr else None,
            })
        return conns
    
    def check_internet(self) -> bool:
        try:
            socket.create_connection(("8.8.8.8", 53), timeout=3)
            return True
        except OSError:
            return False
    
    def get_all(self) -> Dict[str, Any]:
        return {
            "io": self.get_network_info(),
            "internet": self.check_internet(),
            "connection_count": len(self.get_connections()),
        }
    
    def get_summary(self) -> Dict[str, Any]:
        return {
            "internet": self.check_internet(),
            "connection_count": len(self.get_connections()),
        }


class ProcessSensor:
    """进程传感器"""
    
    def __init__(self, current_pid: Optional[int] = None):
        psutil = _get_psutil()
        self.current_pid = current_pid or psutil.Process().pid
    
    def _get_psutil(self):
        return _get_psutil()
    
    def get_current_process_info(self) -> Dict[str, Any]:
        psutil = self._get_psutil()
        try:
            proc = psutil.Process(self.current_pid)
            return {
                "pid": proc.pid,
                "name": proc.name(),
                "memory_percent": proc.memory_percent(),
                "cpu_percent": proc.cpu_percent(interval=0.1),
                "status": proc.status(),
                "num_threads": proc.num_threads(),
            }
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            return {"error": "Cannot access process info"}
    
    def get_top_cpu_processes(self, n: int = 5) -> List[Dict]:
        psutil = self._get_psutil()
        processes = []
        for proc in psutil.process_iter(['pid', 'name', 'cpu_percent']):
            try:
                proc_info = proc.info
                if proc_info['cpu_percent']:
                    processes.append(proc_info)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        processes.sort(key=lambda x: x['cpu_percent'], reverse=True)
        return processes[:n]
    
    def get_top_memory_processes(self, n: int = 5) -> List[Dict]:
        psutil = self._get_psutil()
        processes = []
        for proc in psutil.process_iter(['pid', 'name', 'memory_percent']):
            try:
                proc_info = proc.info
                if proc_info['memory_percent']:
                    processes.append(proc_info)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        processes.sort(key=lambda x: x['memory_percent'], reverse=True)
        return processes[:n]
    
    def get_relevant_info(self) -> Dict[str, Any]:
        psutil = self._get_psutil()
        return {
            "current": self.get_current_process_info(),
            "top_cpu": self.get_top_cpu_processes(3),
            "top_memory": self.get_top_memory_processes(3),
            "total_processes": len(psutil.pids()),
        }
    
    def get_summary(self) -> Dict[str, Any]:
        proc = self.get_current_process_info()
        return {
            "current_memory_percent": proc.get("memory_percent", 0),
            "current_cpu_percent": proc.get("cpu_percent", 0),
            "total_processes": len(self._get_psutil().pids()),
        }