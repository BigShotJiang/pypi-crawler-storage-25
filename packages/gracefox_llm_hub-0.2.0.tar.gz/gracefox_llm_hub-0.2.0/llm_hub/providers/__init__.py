"""LLM提供商模块 - 包含工厂函数和插件系统"""

from typing import Dict, Any, Optional
import warnings

from llm_hub.core.enums import Provider
from llm_hub.core.exceptions import ProviderError
from llm_hub.providers.base import BaseProvider, BaseTokenCounter, FallbackTokenCounter


class ProviderRegistry:
    """Provider注册表 - 支持插件发现"""
    
    _instance = None
    _providers: Dict[str, type] = {}
    _loaded = False
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    @classmethod
    def discover_plugins(cls):
        """发现所有已安装的Provider插件"""
        if cls._loaded:
            return
        
        try:
            from importlib.metadata import entry_points
            
            # Python 3.8+ 兼容方式
            eps = entry_points()
            
            # Python 3.10+ 使用 select 方法
            if hasattr(eps, 'select'):
                provider_eps = eps.select(group="llm_hub.providers")
            else:
                # Python 3.8/3.9 兼容
                provider_eps = eps.get("llm_hub.providers", [])
            
            for entry in provider_eps:
                try:
                    provider_class = entry.load()
                    cls._providers[entry.name] = provider_class
                except Exception as e:
                    warnings.warn(f"Failed to load provider plugin '{entry.name}': {e}")
            
            cls._loaded = True
            
        except Exception as e:
            warnings.warn(f"Failed to discover provider plugins: {e}")
            cls._loaded = True
    
    @classmethod
    def get_provider_class(cls, name: str) -> Optional[type]:
        """获取Provider类"""
        cls.discover_plugins()
        return cls._providers.get(name)
    
    @classmethod
    def register(cls, name: str, provider_class: type):
        """手动注册Provider"""
        cls._providers[name] = provider_class
    
    @classmethod
    def list_providers(cls) -> list:
        """列出所有已注册的Provider"""
        cls.discover_plugins()
        return list(cls._providers.keys())


# 导入内置Provider类（延迟导入避免循环）
def _get_builtin_providers():
    """获取内置Provider映射（延迟导入）"""
    from llm_hub.providers.openai_compatible import OpenAICompatibleProvider
    from llm_hub.providers.deepseek import DeepSeekProvider
    from llm_hub.providers.kimi import KimiProvider
    from llm_hub.providers.qwen import QwenProvider
    from llm_hub.providers.glm import GLMProvider
    from llm_hub.providers.ernie import ErnieProvider
    from llm_hub.providers.minicpm import MiniCPMProvider
    from llm_hub.providers.ollama import OllamaProvider
    from llm_hub.providers.llama_cpp import LlamaCppProvider
    from llm_hub.providers.gemini import GeminiProvider
    from llm_hub.providers.anthropic import AnthropicProvider
    from llm_hub.providers.custom import CustomProvider
    
    return {
        "openai": OpenAICompatibleProvider,
        "deepseek": DeepSeekProvider,
        "kimi": KimiProvider,
        "qwen": QwenProvider,
        "glm": GLMProvider,
        "ernie": ErnieProvider,
        "minicpm": MiniCPMProvider,
        "ollama": OllamaProvider,
        "llama_cpp": LlamaCppProvider,
        "gemini": GeminiProvider,
        "anthropic": AnthropicProvider,
        "custom": CustomProvider,
    }


# 注册内置Provider
def _register_builtin_providers():
    """注册内置Provider"""
    for name, provider_class in _get_builtin_providers().items():
        ProviderRegistry.register(name, provider_class)


_register_builtin_providers()


def _get_default_url(provider) -> str:
    """获取默认API URL"""
    # 处理字符串和枚举类型
    if hasattr(provider, 'value'):
        provider_value = provider.value
    else:
        provider_value = str(provider).lower()
    
    urls = {
        "openai": "https://api.openai.com/v1",
        "deepseek": "https://api.deepseek.com/v1",
        "kimi": "https://api.moonshot.cn/v1",
        "kimi_intl": "https://api.moonshot.cc/v1",
        "aliyun_bailian": "https://dashscope.aliyuncs.com/compatible-mode/v1",
        "openrouter": "https://openrouter.ai/api/v1",
        "anthropic": "https://api.anthropic.com/v1",
        "gemini": "https://generativelanguage.googleapis.com/v1",
        "qwen": "https://dashscope.aliyuncs.com/compatible-mode/v1",
        "glm": "https://open.bigmodel.cn/api/paas/v4",
        "ernie": "https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop",
    }
    return urls.get(provider_value, "")


def create_provider(provider, config: dict) -> BaseProvider:
    """
    创建提供商实例（支持插件）
    
    Args:
        provider: Provider枚举或字符串名称
        config: 配置字典
    
    Returns:
        Provider实例
    """
    # 获取Provider名称
    if hasattr(provider, 'value'):
        provider_name = provider.value
    else:
        provider_name = str(provider).lower()
    
    # 尝试从插件注册表获取
    provider_class = ProviderRegistry.get_provider_class(provider_name)
    
    if not provider_class:
        raise ProviderError(f"Unknown provider: {provider_name}. Available: {ProviderRegistry.list_providers()}")
    
    config_copy = config.copy()
    
    # 设置API URL（仅云端Provider）
    local_providers = ["ollama", "llama_cpp", "local", "minicpm"]
    if provider_name not in local_providers:
        if not config_copy.get("api_url"):
            config_copy["api_url"] = _get_default_url(provider)
    
    return provider_class(config_copy)


def get_token_counter(provider, **kwargs) -> BaseTokenCounter:
    """
    获取Token计数器（便捷函数）
    
    Args:
        provider: Provider枚举或字符串名称
        **kwargs: 额外参数（api_key, model等）
    
    Returns:
        Token计数器实例
    """
    temp_config = {"provider": provider, **kwargs}
    temp_provider = create_provider(provider, temp_config)
    return temp_provider.get_token_counter()


# 导出
__all__ = [
    "BaseProvider",
    "BaseTokenCounter",
    "FallbackTokenCounter",
    "ProviderRegistry",
    "create_provider",
    "get_token_counter",
]

# 导入具体Provider类（供直接使用）
from llm_hub.providers.openai_compatible import OpenAICompatibleProvider, OpenAITokenCounter
from llm_hub.providers.deepseek import DeepSeekProvider, DeepSeekTokenCounter
from llm_hub.providers.kimi import KimiProvider, KimiTokenCounter
from llm_hub.providers.qwen import QwenProvider, QwenTokenCounter
from llm_hub.providers.glm import GLMProvider, GLMTokenCounter
from llm_hub.providers.ernie import ErnieProvider, ErnieTokenCounter
from llm_hub.providers.minicpm import MiniCPMProvider, MiniCPMTokenCounter
from llm_hub.providers.ollama import OllamaProvider, OllamaTokenCounter
from llm_hub.providers.llama_cpp import LlamaCppProvider, LlamaCppTokenCounter
from llm_hub.providers.gemini import GeminiProvider, GeminiTokenCounter
from llm_hub.providers.anthropic import AnthropicProvider, AnthropicTokenCounter
from llm_hub.providers.custom import CustomProvider, CustomTokenCounter