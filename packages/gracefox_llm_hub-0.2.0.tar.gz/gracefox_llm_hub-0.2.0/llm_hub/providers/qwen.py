"""通义千问 (Qwen) 提供商 - 包含Token计数器"""

import json
import logging
import requests
from typing import Dict, Any, List, Generator, Union

from llm_hub.providers.base import BaseProvider, BaseTokenCounter, FallbackTokenCounter
from llm_hub.models.message import Conversation
from llm_hub.models.response import Response, StreamResponse, StreamChunk, StreamEventType

logger = logging.getLogger(__name__)


class QwenTokenCounter(BaseTokenCounter):
    """通义千问 精确Token计数器"""
    
    def __init__(self):
        self._tokenizer = None
        self._init_tokenizer()
    
    def _init_tokenizer(self):
        try:
            from transformers import AutoTokenizer
            self._tokenizer = AutoTokenizer.from_pretrained(
                "Qwen/Qwen-7B-Chat",
                trust_remote_code=True
            )
            logger.info("Qwen tokenizer加载成功")
        except Exception as e:
            try:
                import tiktoken
                self._tokenizer = tiktoken.get_encoding("cl100k_base")
                logger.info("Qwen使用tiktoken作为备选")
            except ImportError:
                logger.warning(f"Qwen tokenizer加载失败: {e}")
                self._tokenizer = None
    
    def count(self, text: str) -> int:
        if self._tokenizer:
            try:
                if hasattr(self._tokenizer, 'encode'):
                    return len(self._tokenizer.encode(text))
            except Exception:
                pass
        
        chinese = sum(1 for c in text if '\u4e00' <= c <= '\u9fff')
        english = len([w for w in text.split() if any(c.isalpha() for c in w)])
        return chinese + int(english * 0.75) + 2


class QwenProvider(BaseProvider):
    """通义千问提供商"""
    
    def __init__(self, config: dict):
        super().__init__(config)
        self.api_key = config.get("api_key")
        self.model = config.get("model", "qwen-turbo")
        self.api_mode = config.get("api_mode", "dashscope")
        
        if self.api_mode == "dashscope":
            self.api_url = config.get("api_url", "https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation")
        else:
            self.api_url = config.get("api_url", "https://dashscope.aliyuncs.com/compatible-mode/v1")
        
        self.show_thinking = config.get("show_thinking", True)
    
    def get_token_counter(self) -> BaseTokenCounter:
        if self._token_counter is None:
            self._token_counter = QwenTokenCounter()
        return self._token_counter
    
    def _get_headers(self) -> Dict:
        if self.api_mode == "dashscope":
            return {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}",
                "X-DashScope-SSE": "enable" if self.config.get("stream", False) else "disable"
            }
        else:
            return {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}"
            }
    
    def chat(self, conversation: Conversation, **kwargs) -> Union[Response, StreamResponse]:
        messages = conversation.get_messages()
        stream = kwargs.get("stream", self.config.get("stream", False))
        
        if self.api_mode == "dashscope":
            return self._chat_dashscope(messages, stream, kwargs)
        else:
            return self._chat_openai_compatible(messages, stream, kwargs)
    
    def _chat_dashscope(self, messages: List[Dict], stream: bool, kwargs: Dict) -> Union[Response, StreamResponse]:
        system_prompt = None
        user_messages = []
        for msg in messages:
            if msg["role"] == "system":
                system_prompt = msg["content"]
            else:
                user_messages.append(msg)
        
        payload = {
            "model": kwargs.get("model", self.model),
            "input": {"messages": user_messages},
            "parameters": {
                "temperature": kwargs.get("temperature", self.config.get("temperature", 0.7)),
                "max_tokens": kwargs.get("max_tokens", self.config.get("max_tokens", 2000)),
                "top_p": kwargs.get("top_p", self.config.get("top_p", 0.95)),
                "result_format": "message",
                "incremental_output": stream
            }
        }
        
        if system_prompt:
            payload["parameters"]["system"] = system_prompt
        
        response = requests.post(
            self.api_url,
            json=payload,
            headers=self._get_headers(),
            stream=stream,
            timeout=self.config.get("timeout", 60)
        )
        response.raise_for_status()
        
        if stream:
            return StreamResponse(self._stream_dashscope(response))
        else:
            data = response.json()
            response.close()
            return self._parse_dashscope_response(data)
    
    def _stream_dashscope(self, response) -> Generator:
        accumulated_content = ""
        
        for line in response.iter_lines():
            if not line:
                continue
            
            try:
                line = line.decode('utf-8')
            except UnicodeDecodeError:
                continue
            
            if line.startswith("data:"):
                line = line[5:].strip()
            
            if not line:
                continue
            
            try:
                data = json.loads(line)
                
                if "output" in data and "choices" in data["output"]:
                    choices = data["output"]["choices"]
                    if choices:
                        delta = choices[0].get("message", {}).get("content", "")
                        if delta:
                            accumulated_content += delta
                            yield StreamChunk(
                                type=StreamEventType.CONTENT,
                                content=delta,
                                delta=delta,
                                accumulated=accumulated_content
                            )
                
                if data.get("output", {}).get("finish_reason"):
                    yield StreamChunk(
                        type=StreamEventType.DONE,
                        content="",
                        accumulated=accumulated_content
                    )
            except json.JSONDecodeError:
                continue
        
        response.close()
    
    def _parse_dashscope_response(self, data: Dict) -> Response:
        output = data.get("output", {})
        choices = output.get("choices", [])
        
        content = choices[0].get("message", {}).get("content", "") if choices else ""
        
        usage = data.get("usage", {})
        return Response(
            content=content,
            model=self.model,
            usage={
                "prompt_tokens": usage.get("input_tokens", 0),
                "completion_tokens": usage.get("output_tokens", 0),
                "total_tokens": usage.get("total_tokens", 0)
            },
            finish_reason=output.get("finish_reason"),
            raw=data
        )
    
    def _chat_openai_compatible(self, messages: List[Dict], stream: bool, kwargs: Dict) -> Union[Response, StreamResponse]:
        payload = {
            "model": kwargs.get("model", self.model),
            "messages": messages,
            "temperature": kwargs.get("temperature", self.config.get("temperature", 0.7)),
            "max_tokens": kwargs.get("max_tokens", self.config.get("max_tokens", 2000)),
            "top_p": kwargs.get("top_p", self.config.get("top_p", 0.95)),
            "stream": stream
        }
        
        response = requests.post(
            f"{self.api_url}/chat/completions",
            json=payload,
            headers=self._get_headers(),
            stream=stream,
            timeout=self.config.get("timeout", 60)
        )
        response.raise_for_status()
        
        if stream:
            return StreamResponse(self._stream_openai_compatible(response))
        else:
            data = response.json()
            response.close()
            return self._parse_openai_response(data)
    
    def _stream_openai_compatible(self, response) -> Generator:
        accumulated_content = ""
        
        for line in response.iter_lines():
            if not line:
                continue
            
            try:
                line = line.decode('utf-8')
            except UnicodeDecodeError:
                continue
            
            if line.startswith("data: "):
                line = line[6:]
            
            if line == "[DONE]":
                yield StreamChunk(
                    type=StreamEventType.DONE,
                    content="",
                    accumulated=accumulated_content
                )
                break
            
            try:
                data = json.loads(line)
                choices = data.get("choices", [])
                if choices:
                    delta = choices[0].get("delta", {})
                    content = delta.get("content", "")
                    if content:
                        accumulated_content += content
                        yield StreamChunk(
                            type=StreamEventType.CONTENT,
                            content=content,
                            delta=content,
                            accumulated=accumulated_content
                        )
            except json.JSONDecodeError:
                continue
        
        response.close()
    
    def _parse_openai_response(self, data: Dict) -> Response:
        choices = data.get("choices", [])
        content = choices[0].get("message", {}).get("content", "") if choices else ""
        
        return Response(
            content=content,
            model=data.get("model", self.model),
            usage=data.get("usage"),
            finish_reason=choices[0].get("finish_reason") if choices else None,
            raw=data
        )
    
    def complete(self, prompt: str, **kwargs) -> Union[Response, StreamResponse]:
        conv = Conversation()
        conv.add_user(prompt)
        return self.chat(conv, **kwargs)
    
    def health_check(self) -> bool:
        try:
            response = requests.get(
                "https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation",
                headers=self._get_headers(),
                timeout=10
            )
            success = response.status_code != 401
            response.close()
            return success
        except Exception:
            return False