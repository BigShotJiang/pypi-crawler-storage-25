"""DeepSeek 提供商 - 包含精确Token计数器"""

import json
import logging
import requests
from typing import Dict, Any, List, Generator, Union, Optional

from llm_hub.providers.base import BaseProvider, BaseTokenCounter, FallbackTokenCounter
from llm_hub.models.message import Conversation
from llm_hub.models.response import Response, StreamResponse, StreamChunk, StreamEventType
from llm_hub.utils.stream_buffer import StreamingResponseCollector
from llm_hub.config.security import SensitiveDataFilter

logger = logging.getLogger(__name__)


class DeepSeekTokenCounter(BaseTokenCounter):
    """DeepSeek 精确Token计数器"""
    
    def __init__(self):
        self._encoder = None
        self._init_encoder()
    
    def _init_encoder(self):
        """初始化编码器"""
        try:
            # 尝试使用 deepseek-tokenizer（官方）
            import deepseek_tokenizer
            self._encoder = deepseek_tokenizer
            logger.info("DeepSeek官方tokenizer加载成功")
            return
        except ImportError:
            pass
        
        try:
            # 备选：使用 tiktoken (cl100k_base 兼容)
            import tiktoken
            self._encoder = tiktoken.get_encoding("cl100k_base")
            logger.info("DeepSeek使用tiktoken作为备选")
            return
        except ImportError:
            pass
        
        logger.warning("DeepSeek token计数器使用估算模式")
        self._encoder = None
    
    def count(self, text: str) -> int:
        if self._encoder:
            try:
                if hasattr(self._encoder, 'encode'):
                    return len(self._encoder.encode(text))
                elif hasattr(self._encoder, 'encode_ordinary'):
                    return len(self._encoder.encode_ordinary(text))
                elif hasattr(self._encoder, 'encode_plus'):
                    return len(self._encoder.encode_plus(text)['input_ids'])
            except Exception as e:
                logger.warning(f"DeepSeek token计数失败: {e}")
        
        # 回退估算
        chinese = sum(1 for c in text if '\u4e00' <= c <= '\u9fff')
        english = len([w for w in text.split() if any(c.isalpha() for c in w)])
        return chinese + int(english * 0.75) + 2


class DeepSeekProvider(BaseProvider):
    """DeepSeek 提供商 - 支持思考过程和流式输出"""
    
    def __init__(self, config: dict):
        super().__init__(config)
        self.api_url = config.get("api_url", "https://api.deepseek.com/v1")
        self.api_key = config.get("api_key")
        self.model = config.get("model", "deepseek-chat")
        self.show_thinking = config.get("show_thinking", True)
        self.reasoning = config.get("reasoning", False)
    
    def get_token_counter(self) -> BaseTokenCounter:
        """获取DeepSeek精确Token计数器"""
        if self._token_counter is None:
            self._token_counter = DeepSeekTokenCounter()
        return self._token_counter
    
    def _get_headers(self) -> Dict:
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers
    
    def _safe_log(self, message: str, data: Any = None):
        if self.debug:
            if data:
                if isinstance(data, dict):
                    data = SensitiveDataFilter.filter_dict(data)
                elif isinstance(data, str):
                    data = SensitiveDataFilter.filter(data)
            print(f"[{self.__class__.__name__}] {message}: {data}" if data else message)
    
    def chat(self, conversation: Conversation, **kwargs) -> Union[Response, StreamResponse]:
        messages = conversation.get_messages()
        stream = kwargs.get("stream", self.config.get("stream", False))
        
        payload = {
            "model": kwargs.get("model", self.model),
            "messages": messages,
            "temperature": kwargs.get("temperature", self.config.get("temperature", 0.7)),
            "max_tokens": kwargs.get("max_tokens", self.config.get("max_tokens", 2000)),
            "top_p": kwargs.get("top_p", self.config.get("top_p", 0.95)),
            "stream": stream
        }
        
        reasoning = kwargs.get("reasoning", self.reasoning)
        if reasoning:
            payload["reasoning"] = True
        
        self._safe_log("Request", payload)
        
        response = requests.post(
            f"{self.api_url}/chat/completions",
            json=payload,
            headers=self._get_headers(),
            stream=stream,
            timeout=self.config.get("timeout", 60)
        )
        response.raise_for_status()
        
        if stream:
            return StreamResponse(self._stream_chat(response))
        else:
            data = response.json()
            response.close()
            return self._parse_response(data)
    
    def _stream_chat(self, response) -> Generator:
        """流式处理 - 确保response正确关闭"""
        collector = StreamingResponseCollector()
        
        try:
            for line in response.iter_lines():
                if not line:
                    continue
                
                try:
                    line = line.decode('utf-8')
                except UnicodeDecodeError:
                    continue
                
                if line.startswith("data: "):
                    line = line[6:]
                
                if line == "[DONE]":
                    stats = collector.get_stats()
                    self._safe_log(f"Stream completed - Stats: {stats}")
                    
                    yield StreamChunk(
                        type=StreamEventType.DONE,
                        content="",
                        accumulated=collector.get_content(),
                        metadata=stats
                    )
                    break
                
                try:
                    data = json.loads(line)
                    choice = data.get("choices", [{}])[0]
                    delta = choice.get("delta", {})
                    
                    reasoning_content = delta.get("reasoning_content", "")
                    if reasoning_content and self.show_thinking:
                        collector.add_thinking(reasoning_content)
                        yield StreamChunk(
                            type=StreamEventType.THINKING,
                            content=reasoning_content,
                            delta=reasoning_content,
                            accumulated=collector.get_thinking()
                        )
                    
                    content = delta.get("content", "")
                    if content:
                        collector.add_content(content)
                        yield StreamChunk(
                            type=StreamEventType.CONTENT,
                            content=content,
                            delta=content,
                            accumulated=collector.get_content()
                        )
                    
                    tool_calls = delta.get("tool_calls", [])
                    if tool_calls:
                        for tc in tool_calls:
                            yield StreamChunk(
                                type=StreamEventType.TOOL_CALL,
                                content=json.dumps(tc, ensure_ascii=False),
                                delta=json.dumps(tc, ensure_ascii=False)
                            )
                            
                except json.JSONDecodeError:
                    continue
                except Exception as e:
                    self._safe_log(f"Stream error: {e}")
                    yield StreamChunk(
                        type=StreamEventType.ERROR,
                        content=str(e),
                        delta=str(e)
                    )
        finally:
            response.close()
    
    def _parse_response(self, data: Dict) -> Response:
        choice = data.get("choices", [{}])[0]
        message = choice.get("message", {})
        
        thinking = message.get("reasoning_content", "")
        content = message.get("content", "")
        
        return Response(
            content=content,
            thinking=thinking,
            model=data.get("model", self.model),
            usage=data.get("usage"),
            finish_reason=choice.get("finish_reason"),
            raw=data
        )
    
    def complete(self, prompt: str, **kwargs) -> Union[Response, StreamResponse]:
        conv = Conversation()
        conv.add_user(prompt)
        return self.chat(conv, **kwargs)
    
    def health_check(self) -> bool:
        try:
            response = requests.get(
                f"{self.api_url}/models",
                headers=self._get_headers(),
                timeout=10
            )
            success = response.status_code == 200
            response.close()
            return success
        except Exception as e:
            self._safe_log(f"Health check failed: {e}")
            return False