"""OpenAI兼容提供商 - 包含Token计数器"""

import json
import logging
import requests
from typing import Dict, Any, List, Generator, Union

from llm_hub.providers.base import BaseProvider, BaseTokenCounter, FallbackTokenCounter
from llm_hub.models.message import Conversation
from llm_hub.models.response import Response, StreamResponse, StreamChunk, StreamEventType

logger = logging.getLogger(__name__)


class OpenAITokenCounter(BaseTokenCounter):
    """OpenAI 精确Token计数器"""
    
    def __init__(self, model: str = "gpt-3.5-turbo"):
        self.model = model
        self._encoding = None
        self._init_encoding()
    
    def _init_encoding(self):
        try:
            import tiktoken
            try:
                self._encoding = tiktoken.encoding_for_model(self.model)
            except KeyError:
                self._encoding = tiktoken.get_encoding("cl100k_base")
            logger.info(f"OpenAI tokenizer加载成功: {self.model}")
        except ImportError:
            logger.warning("tiktoken未安装，使用估算模式")
            self._encoding = None
    
    def count(self, text: str) -> int:
        if self._encoding:
            try:
                return len(self._encoding.encode(text, disallowed_special=()))
            except Exception as e:
                logger.warning(f"OpenAI token计数失败: {e}")
        
        chinese = sum(1 for c in text if '\u4e00' <= c <= '\u9fff')
        english = len([w for w in text.split() if any(c.isalpha() for c in w)])
        return chinese + int(english * 0.75) + 2


class OpenAICompatibleProvider(BaseProvider):
    """OpenAI兼容提供商"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.api_url = config.get("api_url", "https://api.openai.com/v1")
        self.api_key = config.get("api_key")
        self.model = config.get("model", "gpt-3.5-turbo")
    
    def get_token_counter(self) -> BaseTokenCounter:
        if self._token_counter is None:
            self._token_counter = OpenAITokenCounter(self.model)
        return self._token_counter
    
    def _get_headers(self) -> Dict:
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers
    
    def _build_payload(self, messages: List[Dict], **kwargs) -> Dict:
        return {
            "model": kwargs.get("model", self.model),
            "messages": messages,
            "temperature": kwargs.get("temperature", self.config.get("temperature", 0.7)),
            "max_tokens": kwargs.get("max_tokens", self.config.get("max_tokens", 2000)),
            "top_p": kwargs.get("top_p", self.config.get("top_p", 0.95)),
            "frequency_penalty": kwargs.get("frequency_penalty", self.config.get("frequency_penalty", 0)),
            "presence_penalty": kwargs.get("presence_penalty", self.config.get("presence_penalty", 0)),
            "stream": kwargs.get("stream", self.config.get("stream", False))
        }
    
    def _parse_response(self, data: Dict) -> Response:
        choice = data.get("choices", [{}])[0]
        return Response(
            content=choice.get("message", {}).get("content", ""),
            model=data.get("model", self.model),
            usage=data.get("usage"),
            finish_reason=choice.get("finish_reason"),
            raw=data
        )
    
    def chat(self, conversation: Conversation, **kwargs) -> Union[Response, StreamResponse]:
        messages = conversation.get_messages()
        payload = self._build_payload(messages, **kwargs)
        stream = payload["stream"]
        
        self._log(f"Request: {payload}")
        
        response = requests.post(
            f"{self.api_url}/chat/completions",
            json=payload,
            headers=self._get_headers(),
            stream=stream,
            timeout=self.config.get("timeout", 60)
        )
        response.raise_for_status()
        
        if stream:
            return StreamResponse(self._stream_chat(response))
        else:
            data = response.json()
            response.close()
            return self._parse_response(data)
    
    def _stream_chat(self, response) -> Generator:
        accumulated_content = ""
        
        for line in response.iter_lines():
            if not line:
                continue
            
            try:
                line = line.decode('utf-8')
            except UnicodeDecodeError:
                continue
            
            if line.startswith("data: "):
                line = line[6:]
            
            if line == "[DONE]":
                yield StreamChunk(
                    type=StreamEventType.DONE,
                    content="",
                    accumulated=accumulated_content
                )
                break
            
            try:
                data = json.loads(line)
                delta = data.get("choices", [{}])[0].get("delta", {})
                content = delta.get("content", "")
                
                if content:
                    accumulated_content += content
                    yield StreamChunk(
                        type=StreamEventType.CONTENT,
                        content=content,
                        delta=content,
                        accumulated=accumulated_content
                    )
            except json.JSONDecodeError:
                continue
        
        response.close()
    
    def complete(self, prompt: str, **kwargs) -> Union[Response, StreamResponse]:
        payload = {
            "model": kwargs.get("model", self.model),
            "prompt": prompt,
            "temperature": kwargs.get("temperature", self.config.get("temperature", 0.7)),
            "max_tokens": kwargs.get("max_tokens", self.config.get("max_tokens", 2000)),
            "stream": kwargs.get("stream", self.config.get("stream", False))
        }
        
        response = requests.post(
            f"{self.api_url}/completions",
            json=payload,
            headers=self._get_headers(),
            timeout=self.config.get("timeout", 60)
        )
        response.raise_for_status()
        data = response.json()
        response.close()
        
        choice = data.get("choices", [{}])[0]
        return Response(
            content=choice.get("text", ""),
            model=data.get("model", self.model),
            usage=data.get("usage"),
            finish_reason=choice.get("finish_reason"),
            raw=data
        )
    
    def health_check(self) -> bool:
        try:
            response = requests.get(
                f"{self.api_url}/models",
                headers=self._get_headers(),
                timeout=10
            )
            success = response.status_code == 200
            response.close()
            return success
        except Exception:
            return False