"""MiniCPM 提供商 - 包含Token计数器"""

import json
import logging
import requests
from typing import Dict, Any, List, Generator, Union

from llm_hub.providers.base import BaseProvider, BaseTokenCounter, FallbackTokenCounter
from llm_hub.models.message import Conversation
from llm_hub.models.response import Response, StreamResponse, StreamChunk, StreamEventType

logger = logging.getLogger(__name__)


class MiniCPMTokenCounter(BaseTokenCounter):
    """MiniCPM 精确Token计数器"""
    
    def __init__(self, model_name: str = "OpenBMB/MiniCPM-V-2_6"):
        self.model_name = model_name
        self._tokenizer = None
    
    def _get_tokenizer(self):
        if self._tokenizer is None:
            try:
                from transformers import AutoTokenizer
                self._tokenizer = AutoTokenizer.from_pretrained(
                    self.model_name,
                    trust_remote_code=True
                )
                logger.info(f"MiniCPM tokenizer加载成功: {self.model_name}")
            except Exception as e:
                logger.warning(f"MiniCPM tokenizer加载失败: {e}")
                raise ImportError(f"无法加载MiniCPM tokenizer: {e}")
        return self._tokenizer
    
    def count(self, text: str) -> int:
        tokenizer = self._get_tokenizer()
        return len(tokenizer.encode(text))


class MiniCPMProvider(BaseProvider):
    """MiniCPM 提供商"""
    
    def __init__(self, config: dict):
        super().__init__(config)
        self.base_url = config.get("base_url", "http://localhost:11434")
        self.api_url = f"{self.base_url}/api"
        self.model = config.get("model", "minicpm")
        self.api_mode = config.get("api_mode", "ollama")
        self.tokenizer_model = config.get("tokenizer_model", "OpenBMB/MiniCPM-V-2_6")
    
    def get_token_counter(self) -> BaseTokenCounter:
        if self._token_counter is None:
            try:
                self._token_counter = MiniCPMTokenCounter(self.tokenizer_model)
            except ImportError:
                logger.warning("MiniCPM tokenizer不可用，使用估算模式")
                self._token_counter = FallbackTokenCounter()
        return self._token_counter
    
    def _get_headers(self) -> Dict:
        return {"Content-Type": "application/json"}
    
    def chat(self, conversation: Conversation, **kwargs) -> Union[Response, StreamResponse]:
        messages = conversation.get_messages()
        stream = kwargs.get("stream", self.config.get("stream", False))
        
        if self.api_mode == "ollama":
            return self._chat_ollama(messages, stream, kwargs)
        else:
            return self._chat_openai_compatible(messages, stream, kwargs)
    
    def _chat_ollama(self, messages: List[Dict], stream: bool, kwargs: Dict) -> Union[Response, StreamResponse]:
        payload = {
            "model": kwargs.get("model", self.model),
            "messages": messages,
            "stream": stream,
            "options": {
                "temperature": kwargs.get("temperature", self.config.get("temperature", 0.7)),
                "num_predict": kwargs.get("max_tokens", self.config.get("max_tokens", 2000)),
                "top_p": kwargs.get("top_p", self.config.get("top_p", 0.95))
            }
        }
        
        response = requests.post(
            f"{self.api_url}/chat",
            json=payload,
            headers=self._get_headers(),
            stream=stream,
            timeout=self.config.get("timeout", 60)
        )
        response.raise_for_status()
        
        if stream:
            return StreamResponse(self._stream_ollama(response))
        else:
            data = response.json()
            response.close()
            return Response(
                content=data.get("message", {}).get("content", ""),
                model=self.model,
                usage=data.get("usage"),
                raw=data
            )
    
    def _stream_ollama(self, response) -> Generator:
        accumulated_content = ""
        
        for line in response.iter_lines():
            if not line:
                continue
            
            try:
                line = line.decode('utf-8')
            except UnicodeDecodeError:
                continue
            
            try:
                data = json.loads(line)
                if "message" in data and "content" in data["message"]:
                    content = data["message"]["content"]
                    if content:
                        accumulated_content += content
                        yield StreamChunk(
                            type=StreamEventType.CONTENT,
                            content=content,
                            delta=content,
                            accumulated=accumulated_content
                        )
            except json.JSONDecodeError:
                continue
        
        response.close()
    
    def _chat_openai_compatible(self, messages: List[Dict], stream: bool, kwargs: Dict) -> Union[Response, StreamResponse]:
        payload = {
            "model": kwargs.get("model", self.model),
            "messages": messages,
            "temperature": kwargs.get("temperature", self.config.get("temperature", 0.7)),
            "max_tokens": kwargs.get("max_tokens", self.config.get("max_tokens", 2000)),
            "top_p": kwargs.get("top_p", self.config.get("top_p", 0.95)),
            "stream": stream
        }
        
        response = requests.post(
            f"{self.base_url}/v1/chat/completions",
            json=payload,
            headers=self._get_headers(),
            stream=stream,
            timeout=self.config.get("timeout", 60)
        )
        response.raise_for_status()
        
        if stream:
            return StreamResponse(self._stream_openai_compatible(response))
        else:
            data = response.json()
            response.close()
            choices = data.get("choices", [])
            content = choices[0].get("message", {}).get("content", "") if choices else ""
            return Response(
                content=content,
                model=data.get("model", self.model),
                usage=data.get("usage"),
                raw=data
            )
    
    def _stream_openai_compatible(self, response) -> Generator:
        accumulated_content = ""
        
        for line in response.iter_lines():
            if not line:
                continue
            
            try:
                line = line.decode('utf-8')
            except UnicodeDecodeError:
                continue
            
            if line.startswith("data: "):
                line = line[6:]
            
            if line == "[DONE]":
                yield StreamChunk(
                    type=StreamEventType.DONE,
                    content="",
                    accumulated=accumulated_content
                )
                break
            
            try:
                data = json.loads(line)
                choices = data.get("choices", [])
                if choices:
                    delta = choices[0].get("delta", {})
                    content = delta.get("content", "")
                    if content:
                        accumulated_content += content
                        yield StreamChunk(
                            type=StreamEventType.CONTENT,
                            content=content,
                            delta=content,
                            accumulated=accumulated_content
                        )
            except json.JSONDecodeError:
                continue
        
        response.close()
    
    def complete(self, prompt: str, **kwargs) -> Union[Response, StreamResponse]:
        conv = Conversation()
        conv.add_user(prompt)
        return self.chat(conv, **kwargs)
    
    def health_check(self) -> bool:
        try:
            response = requests.get(f"{self.base_url}", timeout=5)
            success = response.status_code == 200
            response.close()
            return success
        except Exception:
            return False