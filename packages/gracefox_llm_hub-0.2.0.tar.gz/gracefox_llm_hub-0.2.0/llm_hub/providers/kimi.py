"""Kimi 提供商 - 包含Token计数器"""

import logging
import requests
from typing import Dict, Any, List, Union

from llm_hub.providers.base import BaseTokenCounter, FallbackTokenCounter
from llm_hub.providers.openai_compatible import OpenAICompatibleProvider
from llm_hub.models.message import Conversation
from llm_hub.models.response import Response, StreamResponse

logger = logging.getLogger(__name__)


class KimiTokenCounter(BaseTokenCounter):
    """Kimi 精确Token计数器 - 通过API获取"""
    
    def __init__(self, api_key: str, api_base: str):
        self.api_key = api_key
        self.api_base = api_base
        self._cache = {}
    
    def count(self, text: str) -> int:
        if text in self._cache:
            return self._cache[text]
        
        try:
            response = requests.post(
                f"{self.api_base}/tokenizers/estimate-token-count",
                headers={"Authorization": f"Bearer {self.api_key}"},
                json={"text": text},
                timeout=10
            )
            if response.status_code == 200:
                result = response.json()
                token_count = result.get("data", {}).get("total_tokens", 0)
                self._cache[text] = token_count
                return token_count
            else:
                logger.warning(f"Kimi API返回错误: {response.status_code}")
                return self._fallback_count(text)
        except Exception as e:
            logger.warning(f"Kimi token计数失败: {e}")
            return self._fallback_count(text)
    
    def _fallback_count(self, text: str) -> int:
        chinese_chars = sum(1 for c in text if '\u4e00' <= c <= '\u9fff')
        english_words = len([w for w in text.split() if any(c.isalpha() for c in w)])
        return chinese_chars + int(english_words * 1.3) + 2


class KimiProvider(OpenAICompatibleProvider):
    """Kimi 提供商"""
    
    def __init__(self, config: dict):
        super().__init__(config)
        
        # Kimi 默认配置
        if "kimi_intl" in config.get("provider", ""):
            self.api_url = config.get("api_url", "https://api.moonshot.cc/v1")
        else:
            self.api_url = config.get("api_url", "https://api.moonshot.cn/v1")
        
        self.model = config.get("model", "moonshot-v1-8k")
    
    def get_token_counter(self) -> BaseTokenCounter:
        if self._token_counter is None:
            if self.api_key:
                self._token_counter = KimiTokenCounter(self.api_key, self.api_url)
            else:
                logger.warning("Kimi token计数需要API Key，使用估算值")
                self._token_counter = FallbackTokenCounter()
        return self._token_counter