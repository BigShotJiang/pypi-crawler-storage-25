"""Google Gemini 提供商 - 包含Token计数器"""

import json
import logging
import requests
from typing import Dict, Any, List, Union

from llm_hub.providers.base import BaseProvider, BaseTokenCounter, FallbackTokenCounter
from llm_hub.models.message import Conversation
from llm_hub.models.response import Response

logger = logging.getLogger(__name__)


class GeminiTokenCounter(BaseTokenCounter):
    """Gemini 精确Token计数器"""
    
    def __init__(self, api_key: str = None):
        self.api_key = api_key
        self._encoder = None
        self._init_encoder()
    
    def _init_encoder(self):
        try:
            import tiktoken
            self._encoder = tiktoken.get_encoding("cl100k_base")
            logger.info("Gemini使用tiktoken作为token计数器")
        except ImportError:
            logger.warning("tiktoken未安装，使用估算模式")
            self._encoder = None
    
    def count(self, text: str) -> int:
        if self._encoder:
            try:
                return len(self._encoder.encode(text))
            except Exception as e:
                logger.warning(f"Gemini token计数失败: {e}")
        
        chinese = sum(1 for c in text if '\u4e00' <= c <= '\u9fff')
        english = len([w for w in text.split() if any(c.isalpha() for c in w)])
        return chinese + int(english * 0.75) + 2


class GeminiProvider(BaseProvider):
    """Google Gemini 提供商"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.api_key = config.get("api_key")
        self.model = config.get("model", "gemini-pro")
        self.api_url = "https://generativelanguage.googleapis.com/v1"
    
    def get_token_counter(self) -> BaseTokenCounter:
        if self._token_counter is None:
            self._token_counter = GeminiTokenCounter(self.api_key)
        return self._token_counter
    
    def _get_url(self) -> str:
        return f"{self.api_url}/models/{self.model}:generateContent?key={self.api_key}"
    
    def _convert_messages(self, messages: List[Dict]) -> List[Dict]:
        contents = []
        for msg in messages:
            role = "user" if msg["role"] == "user" else "model"
            contents.append({
                "role": role,
                "parts": [{"text": msg["content"]}]
            })
        return contents
    
    def chat(self, conversation: Conversation, **kwargs) -> Response:
        messages = conversation.get_messages()
        contents = self._convert_messages(messages)
        
        payload = {
            "contents": contents,
            "generationConfig": {
                "temperature": kwargs.get("temperature", self.config.get("temperature", 0.7)),
                "maxOutputTokens": kwargs.get("max_tokens", self.config.get("max_tokens", 2000)),
                "topP": kwargs.get("top_p", self.config.get("top_p", 0.95)),
                "topK": kwargs.get("top_k", 40)
            }
        }
        
        response = requests.post(
            self._get_url(),
            json=payload,
            headers={"Content-Type": "application/json"},
            timeout=self.config.get("timeout", 60)
        )
        response.raise_for_status()
        data = response.json()
        response.close()
        
        try:
            content = data["candidates"][0]["content"]["parts"][0]["text"]
            usage = data.get("usageMetadata", {})
            return Response(
                content=content,
                model=self.model,
                usage={
                    "prompt_tokens": usage.get("promptTokenCount", 0),
                    "completion_tokens": usage.get("candidatesTokenCount", 0),
                    "total_tokens": usage.get("totalTokenCount", 0)
                },
                raw=data
            )
        except (KeyError, IndexError) as e:
            raise RuntimeError(f"Failed to parse response: {data}, error: {e}")
    
    def complete(self, prompt: str, **kwargs) -> Response:
        conv = Conversation()
        conv.add_user(prompt)
        return self.chat(conv, **kwargs)
    
    def health_check(self) -> bool:
        try:
            response = requests.get(
                f"{self.api_url}/models",
                params={"key": self.api_key},
                timeout=10
            )
            success = response.status_code == 200
            response.close()
            return success
        except Exception:
            return False