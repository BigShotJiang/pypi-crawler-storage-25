"""提供商工厂 - 支持插件发现"""

from importlib.metadata import entry_points
from typing import Dict, Any, Optional
import warnings

from llm_hub.core.enums import Provider
from llm_hub.providers.base import BaseProvider
from llm_hub.core.exceptions import ProviderError


class ProviderRegistry:
    """Provider注册表 - 支持插件发现"""
    
    _instance = None
    _providers: Dict[str, type] = {}
    _loaded = False
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    @classmethod
    def discover_plugins(cls):
        """发现所有已安装的Provider插件"""
        if cls._loaded:
            return
        
        try:
            # Python 3.8+ 兼容方式
            eps = entry_points()
            
            # Python 3.10+ 使用 select 方法
            if hasattr(eps, 'select'):
                provider_eps = eps.select(group="llm_hub.providers")
            else:
                # Python 3.8/3.9 兼容
                provider_eps = eps.get("llm_hub.providers", [])
            
            for entry in provider_eps:
                try:
                    provider_class = entry.load()
                    cls._providers[entry.name] = provider_class
                except Exception as e:
                    warnings.warn(f"Failed to load provider plugin '{entry.name}': {e}")
            
            cls._loaded = True
            
        except Exception as e:
            warnings.warn(f"Failed to discover provider plugins: {e}")
    
    @classmethod
    def get_provider_class(cls, name: str) -> Optional[type]:
        """获取Provider类"""
        cls.discover_plugins()
        return cls._providers.get(name)
    
    @classmethod
    def register(cls, name: str, provider_class: type):
        """手动注册Provider（用于内置Provider）"""
        cls._providers[name] = provider_class
    
    @classmethod
    def list_providers(cls) -> list:
        """列出所有已注册的Provider"""
        cls.discover_plugins()
        return list(cls._providers.keys())


# 注册内置Provider
def _register_builtin_providers():
    """注册内置Provider"""
    from llm_hub.providers.openai_compatible import OpenAICompatibleProvider
    from llm_hub.providers.deepseek import DeepSeekProvider
    from llm_hub.providers.kimi import KimiProvider
    from llm_hub.providers.qwen import QwenProvider
    from llm_hub.providers.glm import GLMProvider
    from llm_hub.providers.ernie import ErnieProvider
    from llm_hub.providers.minicpm import MiniCPMProvider
    from llm_hub.providers.ollama import OllamaProvider
    from llm_hub.providers.llama_cpp import LlamaCppProvider
    from llm_hub.providers.gemini import GeminiProvider
    from llm_hub.providers.anthropic import AnthropicProvider
    from llm_hub.providers.custom import CustomProvider
    
    ProviderRegistry.register("openai", OpenAICompatibleProvider)
    ProviderRegistry.register("deepseek", DeepSeekProvider)
    ProviderRegistry.register("kimi", KimiProvider)
    ProviderRegistry.register("qwen", QwenProvider)
    ProviderRegistry.register("glm", GLMProvider)
    ProviderRegistry.register("ernie", ErnieProvider)
    ProviderRegistry.register("minicpm", MiniCPMProvider)
    ProviderRegistry.register("ollama", OllamaProvider)
    ProviderRegistry.register("llama_cpp", LlamaCppProvider)
    ProviderRegistry.register("gemini", GeminiProvider)
    ProviderRegistry.register("anthropic", AnthropicProvider)
    ProviderRegistry.register("custom", CustomProvider)


_register_builtin_providers()


def _get_default_url(provider: Provider) -> str:
    """获取默认API URL"""
    urls = {
        Provider.OPENAI: "https://api.openai.com/v1",
        Provider.DEEPSEEK: "https://api.deepseek.com/v1",
        Provider.KIMI: "https://api.moonshot.cn/v1",
        Provider.KIMI_INTL: "https://api.moonshot.cc/v1",
        Provider.ALIYUN_BAILIAN: "https://dashscope.aliyuncs.com/compatible-mode/v1",
        Provider.OPENROUTER: "https://openrouter.ai/api/v1",
        Provider.ANTHROPIC: "https://api.anthropic.com/v1",
        Provider.GOOGLE_GEMINI: "https://generativelanguage.googleapis.com/v1",
        Provider.QWEN: "https://dashscope.aliyuncs.com/compatible-mode/v1",
        Provider.GLM: "https://open.bigmodel.cn/api/paas/v4",
        Provider.ERNIE: "https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop",
    }
    return urls.get(provider, "")


def create_provider(provider: Provider, config: dict) -> BaseProvider:
    """创建提供商实例（支持插件）"""
    
    # 获取Provider类名
    provider_name = provider.value if isinstance(provider, Provider) else str(provider)
    
    # 尝试从插件注册表获取
    provider_class = ProviderRegistry.get_provider_class(provider_name)
    
    if not provider_class:
        # 回退到枚举映射（兼容旧代码）
        from llm_hub.core.enums import Provider as ProviderEnum
        
        fallback_map = {
            ProviderEnum.OPENAI: OpenAICompatibleProvider,
            ProviderEnum.DEEPSEEK: DeepSeekProvider,
            ProviderEnum.KIMI: KimiProvider,
            ProviderEnum.KIMI_INTL: KimiProvider,
            ProviderEnum.ALIYUN_BAILIAN: OpenAICompatibleProvider,
            ProviderEnum.OPENROUTER: OpenAICompatibleProvider,
            ProviderEnum.GOOGLE_GEMINI: GeminiProvider,
            ProviderEnum.ANTHROPIC: AnthropicProvider,
            ProviderEnum.QWEN: QwenProvider,
            ProviderEnum.GLM: GLMProvider,
            ProviderEnum.ERNIE: ErnieProvider,
            ProviderEnum.MINICPM: MiniCPMProvider,
            ProviderEnum.OLLAMA: OllamaProvider,
            ProviderEnum.LLAMA_CPP: LlamaCppProvider,
            ProviderEnum.LOCAL: LlamaCppProvider,
            ProviderEnum.CUSTOM: CustomProvider,
        }
        
        provider_class = fallback_map.get(provider)
        
        if not provider_class:
            raise ProviderError(f"Unknown provider: {provider_name}")
    
    config_copy = config.copy()
    
    # 设置API URL
    if provider not in [Provider.OLLAMA, Provider.LLAMA_CPP, Provider.LOCAL, Provider.MINICPM]:
        if not config_copy.get("api_url"):
            config_copy["api_url"] = _get_default_url(provider)
    
    return provider_class(config_copy)